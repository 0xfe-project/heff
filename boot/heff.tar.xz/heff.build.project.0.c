// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_LList 15990
#define TAG_LRec 61105
#define TAG_LStr 62546
#define TAG_LTag 62907
#define TAG_Left 13886
#define TAG_Right 62770
#define LBL_at 9882
#define LBL_backend 2032133329
#define LBL_cmt 308164
#define LBL_col 308218
#define LBL_err 310239
#define LBL_first 298798794
#define LBL_fuel 9649789
#define LBL_heff 9694020
#define LBL_i 323
#define LBL_includeDirs 161922452
#define LBL_kind 9787483
#define LBL_left 9813198
#define LBL_libDirs 396703725
#define LBL_line 9817275
#define LBL_lineStart 1964790630
#define LBL_module 878357911
#define LBL_msg 317947
#define LBL_name 9869138
#define LBL_replace 1326354680
#define LBL_require 1327554473
#define LBL_run 322821
#define LBL_ships 310766033
#define LBL_start 311115900
#define LBL_text 10052084
#define LBL_tok 324554
static uint32_t shape_at__msg[] = {LBL_at, LBL_msg};
static uint32_t shape_backend__run__ships__fuel__includeDirs__libDirs[] = {LBL_backend, LBL_run, LBL_ships, LBL_fuel, LBL_includeDirs, LBL_libDirs};
static uint32_t shape_i__line__lineStart__first__tok__err__cmt[] = {LBL_i, LBL_line, LBL_lineStart, LBL_first, LBL_tok, LBL_err, LBL_cmt};
static uint32_t shape_module__heff__require__replace[] = {LBL_module, LBL_heff, LBL_require, LBL_replace};
static uint32_t shape_name__left[] = {LBL_name, LBL_left};
HeffT2 g_heff_2ebuild_2eproject_2eallOf_24s1439570725x1912618195_24cpr(V);
V g_heff_2ebuild_2eproject_2eallOf_24s1507277824x59055423(V);
V g_heff_2ebuild_2eproject_2eallOf_24s1507277824x59055423_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2eallOf_24s1507277824x59055423_clo;
HeffT2 g_heff_2ebuild_2eproject_2eallOf_24s1507277824x59055423_24cpr(V);
HeffT2 g_heff_2ebuild_2eproject_2eallOf_24s2049964666x1020559920_24cpr(V);
V g_heff_2ebuild_2eproject_2eallOf_24s622475081x394218744(V);
V g_heff_2ebuild_2eproject_2eallOf_24s622475081x394218744_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2eallOf_24s622475081x394218744_clo;
HeffT2 g_heff_2ebuild_2eproject_2eallOf_24s622475081x394218744_24cpr(V);
V g_heff_2ebuild_2eproject_2ebuildOf(V);
V g_heff_2ebuild_2eproject_2ebuildOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2ebuildOf_clo;
V g_heff_2ebuild_2eproject_2ebuildOf_24rec0_get(void);
V g_heff_2ebuild_2eproject_2ebuildOf_24rec1_get(void);
V g_heff_2ebuild_2eproject_2ebuildOf_24rec2_get(void);
V g_heff_2ebuild_2eproject_2ebuildOf_24rec3_get(void);
HeffT2 g_heff_2ebuild_2eproject_2echeckNames_24cpr(V, V, V, V);
HeffT2 g_heff_2ebuild_2eproject_2edeclsGo_24cpr(V, V, V, V, V);
HeffT2 g_heff_2ebuild_2eproject_2efieldsAre_24cpr(V, V);
HeffT2 g_heff_2ebuild_2eproject_2efieldsIn_24cpr(V, V, V);
HeffT3 g_heff_2ebuild_2eproject_2efirstNamed_24cpr(V, V);
V g_heff_2ebuild_2eproject_2eheffModule_get(void);
V g_heff_2ebuild_2eproject_2eisMajorPart(V);
V g_heff_2ebuild_2eproject_2eisMajorPart_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2eisMajorPart_clo;
HeffT2 g_heff_2ebuild_2eproject_2eitems_24cpr(V);
HeffT2 g_heff_2ebuild_2eproject_2ekeyFrom_24cpr(V, V);
HeffT3 g_heff_2ebuild_2eproject_2elitF_24s2091287445x1103896467_24cpr(V, V);
HeffT2 g_heff_2ebuild_2eproject_2emajorMismatch_24cpr(V, V);
HeffT2 g_heff_2ebuild_2eproject_2enameOf_24cpr(V);
V g_heff_2ebuild_2eproject_2enameRule_get(void);
V g_heff_2ebuild_2eproject_2enewer(V, V);
V g_heff_2ebuild_2eproject_2enewer_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2enewer_clo;
V g_heff_2ebuild_2eproject_2enewerGo(V, V);
V g_heff_2ebuild_2eproject_2enewerGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2enewerGo_clo;
V g_heff_2ebuild_2eproject_2enextDecl(V, V);
V g_heff_2ebuild_2eproject_2enextDecl_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2enextDecl_clo;
V g_heff_2ebuild_2eproject_2epackageFields_get(void);
HeffT2 g_heff_2ebuild_2eproject_2epackageLit_24cpr(V);
HeffT2 g_heff_2ebuild_2eproject_2epackageOf_24cpr(V);
V g_heff_2ebuild_2eproject_2epseudoParts(V);
V g_heff_2ebuild_2eproject_2epseudoParts_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2epseudoParts_clo;
HeffT3 g_heff_2ebuild_2eproject_2epseudoParts_24cpr(V);
V g_heff_2ebuild_2eproject_2equoted(V);
V g_heff_2ebuild_2eproject_2equoted_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2equoted_clo;
V g_heff_2ebuild_2eproject_2erangeFrom(V, V);
V g_heff_2ebuild_2eproject_2erangeFrom_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2erangeFrom_clo;
V g_heff_2ebuild_2eproject_2erangeFrom_24dps(V, V, V);
V g_heff_2ebuild_2eproject_2erangeFrom_24dps_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2erangeFrom_24dps_clo;
V g_heff_2ebuild_2eproject_2erequireMsg_get(void);
HeffT2 g_heff_2ebuild_2eproject_2erequireOf_24cpr(V);
HeffT2 g_heff_2ebuild_2eproject_2estr_24cpr(V);
V g_heff_2ebuild_2eproject_2etestsModule_get(void);
HeffT3 g_heff_2ebuild_2eproject_2etwiceGo_24cpr(V, V);
HeffT5 g_heff_2ebuild_2eproject_2eversion_24cpr(V);
HeffT2 g_heff_2ebuild_2eproject_2ewhyNoName_24cpr(V);
HeffT3 g_heff_2esyntax_2efmt_2elex_2elexGo_24cpr(V, V, V, V, V);
V g_list_2eall_24s1432467604x1830816726(V, V, V, V, V, V);
V g_list_2eall_24s1432467604x1830816726_entry(V self, V *a);
extern Clo g_list_2eall_24s1432467604x1830816726_clo;
V g_list_2eall_24s418009941x978041577(V, V, V, V);
V g_list_2eall_24s418009941x978041577_entry(V self, V *a);
extern Clo g_list_2eall_24s418009941x978041577_clo;
V g_list_2eany_24s1006624359x760861690(V, V);
V g_list_2eany_24s1006624359x760861690_entry(V self, V *a);
extern Clo g_list_2eany_24s1006624359x760861690_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2esplit_2esplitFrom_240(V, V, V, V, V);
V g_prelude_2esplit_2esplitFrom_240_entry(V self, V *a);
extern Clo g_prelude_2esplit_2esplitFrom_240_clo;
HEFF_LIT(g_heff_2ebuild_2eproject_2enextDecl_str0, 3, "eof");
Clo g_heff_2ebuild_2eproject_2enextDecl_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eproject_2enextDecl_entry, 2, 0};

V g_heff_2ebuild_2eproject_2enextDecl(V v_ts_240, V v_box_24i_241) {
  int64_t v_i_241 = heff_unbox_word(v_box_24i_241);
top: ;
  if (((((int64_t)0ULL) <= v_i_241) && (v_i_241 < heff_unbox_word(heff_arrayLength_lent(v_ts_240, 0))))) {
    V v_t_242 = heff_arrayIndexIn_lent(v_ts_240, heff_box_word(v_i_241), 2);
    V v_kind_243 = heff_take_field(v_t_242, 0);
    V v_first_244 = heff_take_field(v_t_242, 6);
    V v_col_245 = heff_get_n(v_t_242, 5, 7);
    if ((heff_strEq_c_lent(v_kind_243, ((V)&g_heff_2ebuild_2eproject_2enextDecl_str0), 2) || ((heff_dup(v_first_244) == NTAG(TAG_True)) && heff_intEq_c_lent(v_col_245, MK_INT(0LL), 2)))) {
      heff_drop(v_kind_243);
      heff_drop(v_first_244);
      heff_drop(v_col_245);
      return heff_box_word(v_i_241);
    } else {
      heff_drop(v_kind_243);
      heff_drop(v_first_244);
      heff_drop(v_col_245);
      V t_0 = v_ts_240;
      int64_t t_1 = (v_i_241 + ((int64_t)1ULL));
      v_ts_240 = t_0;
      v_i_241 = t_1;
      goto top;
    }
  } else {
    return heff_box_word(v_i_241);
  }
}
V g_heff_2ebuild_2eproject_2enextDecl_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2eproject_2enextDecl(a0, a[1]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ebuild_2eproject_2edeclsGo_24cpr_str0, 3, "eof");
HEFF_LIT(g_heff_2ebuild_2eproject_2edeclsGo_24cpr_str1, 13, " defines no `");
HEFF_LIT(g_heff_2ebuild_2eproject_2edeclsGo_24cpr_str2, 1, "`");
HEFF_LIT(g_heff_2ebuild_2eproject_2edeclsGo_24cpr_str3, 2, "kw");
HEFF_LIT(g_heff_2ebuild_2eproject_2edeclsGo_24cpr_str4, 6, "import");
HEFF_LIT(g_heff_2ebuild_2eproject_2edeclsGo_24cpr_str5, 3, "var");
HEFF_LIT(g_heff_2ebuild_2eproject_2edeclsGo_24cpr_str6, 3, "sym");
HEFF_LIT(g_heff_2ebuild_2eproject_2edeclsGo_24cpr_str7, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eproject_2edeclsGo_24cpr_str8, 3, "var");
HEFF_LIT(g_heff_2ebuild_2eproject_2edeclsGo_24cpr_str9, 3, "sym");
HEFF_LIT(g_heff_2ebuild_2eproject_2edeclsGo_24cpr_str10, 1, "=");
HEFF_LIT(g_heff_2ebuild_2eproject_2edeclsGo_24cpr_str11, 3, "eof");
HEFF_LIT(g_heff_2ebuild_2eproject_2edeclsGo_24cpr_str12, 1, "`");
HEFF_LIT(g_heff_2ebuild_2eproject_2edeclsGo_24cpr_str13, 38, "` is a literal, and nothing follows it");
HEFF_LIT(g_heff_2ebuild_2eproject_2edeclsGo_24cpr_str14, 42, "the text ends where more of it is expected");
HEFF_LIT(g_heff_2ebuild_2eproject_2edeclsGo_24cpr_str15, 1, "`");
HEFF_LIT(g_heff_2ebuild_2eproject_2edeclsGo_24cpr_str16, 27, "` is defined more than once");
HEFF_LIT(g_heff_2ebuild_2eproject_2edeclsGo_24cpr_str17, 21, " holds imports, and `");
HEFF_LIT(g_heff_2ebuild_2eproject_2edeclsGo_24cpr_str18, 50, "` (its signature and its definition), nothing else");
HEFF_LIT(g_heff_2ebuild_2eproject_2edeclsGo_24cpr_str19, 21, " holds imports, and `");
HEFF_LIT(g_heff_2ebuild_2eproject_2edeclsGo_24cpr_str20, 50, "` (its signature and its definition), nothing else");
HEFF_LIT(g_heff_2ebuild_2eproject_2edeclsGo_24cpr_str21, 21, " holds imports, and `");
HEFF_LIT(g_heff_2ebuild_2eproject_2edeclsGo_24cpr_str22, 50, "` (its signature and its definition), nothing else");
HEFF_LIT(g_heff_2ebuild_2eproject_2edeclsGo_24cpr_str23, 21, " holds imports, and `");
HEFF_LIT(g_heff_2ebuild_2eproject_2edeclsGo_24cpr_str24, 50, "` (its signature and its definition), nothing else");
HEFF_LIT(g_heff_2ebuild_2eproject_2edeclsGo_24cpr_str25, 42, "the text ends where more of it is expected");

HeffT2 g_heff_2ebuild_2eproject_2edeclsGo_24cpr(V v_file_240, V v_name_241, V v_ts_242, V v_i_243, V v_found_244) {
top: ;
  if ((heff_intLe_c_lent(MK_INT(0LL), v_i_243, 1) && heff_intLt_c_lent(v_i_243, heff_arrayLength_lent(v_ts_242, 0), 2))) {
    V v_t_245 = heff_arrayIndex_lent(v_ts_242, v_i_243, 0);
    V v_kind_246 = heff_take_field(v_t_245, 0);
    V v_start_247 = heff_take_field(v_t_245, 2);
    V v_text_248 = heff_get_n(v_t_245, 1, 7);
    if (heff_strEq_c_lent(v_kind_246, ((V)&g_heff_2ebuild_2eproject_2edeclsGo_24cpr_str0), 2)) {
      heff_drop(v_i_243);
      heff_drop(v_kind_246);
      heff_drop(v_text_248);
      switch (heff_tag_of(v_found_244)) {
      case TAG_Nothing: {
        V v_t_249 = heff_strAppend(heff_strAppend(v_file_240, ((V)&g_heff_2ebuild_2eproject_2edeclsGo_24cpr_str1)), v_name_241);
        V v_f_2410 = heff_rec_n(2, shape_at__msg, (V[]){v_start_247, heff_strAppend(v_t_249, ((V)&g_heff_2ebuild_2eproject_2edeclsGo_24cpr_str2))});
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2410}});
      }
      case TAG_Just: {
        V v_x_2411 = heff_field(v_found_244, 0);
        heff_take_n(v_found_244, 1ULL, 1);
        heff_drop(v_file_240);
        heff_drop(v_name_241);
        heff_drop(v_start_247);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_x_2411}});
      }
      default: return ((HeffT2){{heff_nomatch(v_found_244)}});
      }
    } else {
      if ((heff_strEq_c_lent(v_kind_246, ((V)&g_heff_2ebuild_2eproject_2edeclsGo_24cpr_str3), 2) && heff_strEq_c_lent(v_text_248, ((V)&g_heff_2ebuild_2eproject_2edeclsGo_24cpr_str4), 2))) {
        heff_drop(v_kind_246);
        heff_drop(v_start_247);
        heff_drop(v_text_248);
        V v_t_2412 = (g_heff_2ebuild_2eproject_2enextDecl(v_ts_242, heff_box_word((heff_unbox_word(v_i_243) + ((int64_t)1ULL)))));
        V t_0 = v_file_240;
        V t_1 = v_name_241;
        V t_2 = v_ts_242;
        V t_3 = v_t_2412;
        V t_4 = v_found_244;
        v_file_240 = t_0;
        v_name_241 = t_1;
        v_ts_242 = t_2;
        v_i_243 = t_3;
        v_found_244 = t_4;
        goto top;
      } else {
        V v_t_2417;
        if (heff_strEq_c_lent(v_kind_246, ((V)&g_heff_2ebuild_2eproject_2edeclsGo_24cpr_str5), 2)) {
          if (heff_strEq_c_lent(v_text_248, v_name_241, 0)) {
            int64_t v_i_2413 = (heff_peek_word(v_i_243) + ((int64_t)1ULL));
            if (((((int64_t)0ULL) <= v_i_2413) && (v_i_2413 < heff_unbox_word(heff_arrayLength_lent(v_ts_242, 0))))) {
              V v_t_2414 = heff_arrayIndexIn_lent(v_ts_242, heff_box_word(v_i_2413), 2);
              V v_kind_2415 = heff_take_field(v_t_2414, 0);
              V v_text_2416 = heff_get_n(v_t_2414, 1, 7);
              v_t_2417 = heff_bool((heff_strEq_c_lent(v_kind_2415, ((V)&g_heff_2ebuild_2eproject_2edeclsGo_24cpr_str6), 2) && heff_strEq_c_lent(v_text_2416, ((V)&g_heff_2ebuild_2eproject_2edeclsGo_24cpr_str7), 2)));
              heff_drop(v_kind_2415);
              heff_drop(v_text_2416);
            } else {
              v_t_2417 = NTAG(TAG_False);
            }
          } else {
            v_t_2417 = NTAG(TAG_False);
          }
        } else {
          v_t_2417 = NTAG(TAG_False);
        }
        if ((heff_dup(v_t_2417) == NTAG(TAG_True))) {
          heff_drop(v_kind_246);
          heff_drop(v_start_247);
          heff_drop(v_text_248);
          heff_drop(v_t_2417);
          V v_t_2418 = (g_heff_2ebuild_2eproject_2enextDecl(v_ts_242, heff_box_word((heff_unbox_word(v_i_243) + ((int64_t)1ULL)))));
          V t_0 = v_file_240;
          V t_1 = v_name_241;
          V t_2 = v_ts_242;
          V t_3 = v_t_2418;
          V t_4 = v_found_244;
          v_file_240 = t_0;
          v_name_241 = t_1;
          v_ts_242 = t_2;
          v_i_243 = t_3;
          v_found_244 = t_4;
          goto top;
        } else {
          heff_drop(v_t_2417);
          if (heff_strEq_c(v_kind_246, ((V)&g_heff_2ebuild_2eproject_2edeclsGo_24cpr_str8))) {
            if (heff_strEq_c_lent(v_text_248, v_name_241, 1)) {
              int64_t v_i_2419 = (heff_peek_word(v_i_243) + ((int64_t)1ULL));
              if (((((int64_t)0ULL) <= v_i_2419) && (v_i_2419 < heff_unbox_word(heff_arrayLength_lent(v_ts_242, 0))))) {
                V v_t_2420 = heff_arrayIndexIn_lent(v_ts_242, heff_box_word(v_i_2419), 2);
                V v_kind_2421 = heff_take_field(v_t_2420, 0);
                V v_text_2422 = heff_get_n(v_t_2420, 1, 7);
                if ((heff_strEq_c_lent(v_kind_2421, ((V)&g_heff_2ebuild_2eproject_2edeclsGo_24cpr_str9), 2) && heff_strEq_c_lent(v_text_2422, ((V)&g_heff_2ebuild_2eproject_2edeclsGo_24cpr_str10), 2))) {
                  heff_drop(v_kind_2421);
                  heff_drop(v_text_2422);
                  switch (heff_tag_of(v_found_244)) {
                  case TAG_Nothing: {
                    heff_drop(v_start_247);
                    HeffT3 v_t_2423 = (g_heff_2ebuild_2eproject_2elitF_24s2091287445x1103896467_24cpr(v_ts_242, heff_box_word((heff_unbox_word(v_i_243) + ((int64_t)2ULL)))));
                    {
                      V v_field_2425 = v_t_2423.f[1];
                      V v_field_2426 = v_t_2423.f[2];
                      int64_t v_tag_2424 = ((int64_t)v_t_2423.f[0]);
                      if ((v_tag_2424 == ((int64_t)0ULL))) {
                        heff_drop(v_file_240);
                        heff_drop(v_name_241);
                        heff_drop(v_field_2426);
                        V v_p_2427 = v_field_2425;
                        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_p_2427}});
                      } else {
                        V v_x_2428 = v_field_2425;
                        V v_j_2429 = v_field_2426;
                        if ((heff_intLe_c_lent(MK_INT(0LL), v_j_2429, 1) && heff_intLt_c_lent(v_j_2429, heff_arrayLength_lent(v_ts_242, 0), 2))) {
                          V v_after_2430 = heff_arrayIndex_lent(v_ts_242, v_j_2429, 0);
                          V v_kind_2431 = heff_take_field(v_after_2430, 0);
                          V v_first_2432 = heff_take_field(v_after_2430, 6);
                          V v_col_2433 = heff_take_field(v_after_2430, 5);
                          V v_start_2434 = heff_get_n(v_after_2430, 2, 7);
                          if ((heff_strEq_c_lent(v_kind_2431, ((V)&g_heff_2ebuild_2eproject_2edeclsGo_24cpr_str11), 2) || ((heff_dup(v_first_2432) == NTAG(TAG_True)) && heff_intEq_c_lent(v_col_2433, MK_INT(0LL), 2)))) {
                            heff_drop(v_kind_2431);
                            heff_drop(v_first_2432);
                            heff_drop(v_col_2433);
                            heff_drop(v_start_2434);
                            V t_0 = v_file_240;
                            V t_1 = v_name_241;
                            V t_2 = v_ts_242;
                            V t_3 = v_j_2429;
                            V t_4 = heff_tag_n(TAG_Just, 1, (V[]){v_x_2428});
                            v_file_240 = t_0;
                            v_name_241 = t_1;
                            v_ts_242 = t_2;
                            v_i_243 = t_3;
                            v_found_244 = t_4;
                            goto top;
                          } else {
                            heff_drop(v_file_240);
                            heff_drop(v_x_2428);
                            heff_drop(v_j_2429);
                            heff_drop(v_kind_2431);
                            heff_drop(v_first_2432);
                            heff_drop(v_col_2433);
                            V v_t_2435 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2eproject_2edeclsGo_24cpr_str12), v_name_241), ((V)&g_heff_2ebuild_2eproject_2edeclsGo_24cpr_str13));
                            V v_f_2436 = heff_rec_n(2, shape_at__msg, (V[]){v_start_2434, v_t_2435});
                            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2436}});
                          }
                        } else {
                          heff_drop(v_file_240);
                          heff_drop(v_name_241);
                          heff_drop(v_x_2428);
                          heff_drop(v_j_2429);
                          int64_t v_i_2437 = (heff_unbox_word(heff_arrayLength_lent(v_ts_242, 0)) - ((int64_t)1ULL));
                          V v_t_2439;
                          if (((((int64_t)0ULL) <= v_i_2437) && (v_i_2437 < heff_unbox_word(heff_arrayLength_lent(v_ts_242, 0))))) {
                            V v_t_2438 = heff_arrayIndexIn_lent(v_ts_242, heff_box_word(v_i_2437), 2);
                            v_t_2439 = heff_get_n(v_t_2438, 2, 7);
                          } else {
                            v_t_2439 = MK_INT(0LL);
                          }
                          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_rec_n(2, shape_at__msg, (V[]){v_t_2439, ((V)&g_heff_2ebuild_2eproject_2edeclsGo_24cpr_str14)})}});
                        }
                      }
                    }
                  }
                  case TAG_Just: {
                    heff_take_n(v_found_244, 0ULL, 1);
                    heff_drop(v_file_240);
                    heff_drop(v_i_243);
                    V v_t_2441 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2eproject_2edeclsGo_24cpr_str15), v_name_241), ((V)&g_heff_2ebuild_2eproject_2edeclsGo_24cpr_str16));
                    V v_f_2442 = heff_rec_n(2, shape_at__msg, (V[]){v_start_247, v_t_2441});
                    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2442}});
                  }
                  default: return ((HeffT2){{heff_nomatch(v_found_244)}});
                  }
                } else {
                  heff_drop(v_i_243);
                  heff_drop(v_found_244);
                  heff_drop(v_kind_2421);
                  heff_drop(v_text_2422);
                  V v_t_2443 = heff_strAppend(heff_strAppend(v_file_240, ((V)&g_heff_2ebuild_2eproject_2edeclsGo_24cpr_str17)), v_name_241);
                  V v_f_2444 = heff_rec_n(2, shape_at__msg, (V[]){v_start_247, heff_strAppend(v_t_2443, ((V)&g_heff_2ebuild_2eproject_2edeclsGo_24cpr_str18))});
                  return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2444}});
                }
              } else {
                heff_drop(v_i_243);
                heff_drop(v_found_244);
                V v_t_2445 = heff_strAppend(heff_strAppend(v_file_240, ((V)&g_heff_2ebuild_2eproject_2edeclsGo_24cpr_str19)), v_name_241);
                V v_f_2446 = heff_rec_n(2, shape_at__msg, (V[]){v_start_247, heff_strAppend(v_t_2445, ((V)&g_heff_2ebuild_2eproject_2edeclsGo_24cpr_str20))});
                return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2446}});
              }
            } else {
              heff_drop(v_i_243);
              heff_drop(v_found_244);
              V v_t_2447 = heff_strAppend(heff_strAppend(v_file_240, ((V)&g_heff_2ebuild_2eproject_2edeclsGo_24cpr_str21)), v_name_241);
              V v_f_2448 = heff_rec_n(2, shape_at__msg, (V[]){v_start_247, heff_strAppend(v_t_2447, ((V)&g_heff_2ebuild_2eproject_2edeclsGo_24cpr_str22))});
              return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2448}});
            }
          } else {
            heff_drop(v_i_243);
            heff_drop(v_found_244);
            heff_drop(v_text_248);
            V v_t_2449 = heff_strAppend(heff_strAppend(v_file_240, ((V)&g_heff_2ebuild_2eproject_2edeclsGo_24cpr_str23)), v_name_241);
            V v_f_2450 = heff_rec_n(2, shape_at__msg, (V[]){v_start_247, heff_strAppend(v_t_2449, ((V)&g_heff_2ebuild_2eproject_2edeclsGo_24cpr_str24))});
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2450}});
          }
        }
      }
    }
  } else {
    heff_drop(v_file_240);
    heff_drop(v_name_241);
    heff_drop(v_i_243);
    heff_drop(v_found_244);
    int64_t v_i_2451 = (heff_unbox_word(heff_arrayLength_lent(v_ts_242, 0)) - ((int64_t)1ULL));
    V v_t_2453;
    if (((((int64_t)0ULL) <= v_i_2451) && (v_i_2451 < heff_unbox_word(heff_arrayLength_lent(v_ts_242, 0))))) {
      V v_t_2452 = heff_arrayIndexIn_lent(v_ts_242, heff_box_word(v_i_2451), 2);
      v_t_2453 = heff_get_n(v_t_2452, 2, 7);
    } else {
      v_t_2453 = MK_INT(0LL);
    }
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_rec_n(2, shape_at__msg, (V[]){v_t_2453, ((V)&g_heff_2ebuild_2eproject_2edeclsGo_24cpr_str25)})}});
  }
}
Clo g_heff_2ebuild_2eproject_2erangeFrom_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eproject_2erangeFrom_entry, 2, 0};

V g_heff_2ebuild_2eproject_2erangeFrom(V v_box_24i_240, V v_n_241) {
  int64_t v_i_240 = heff_unbox_word(v_box_24i_240);
top: ;
  if ((heff_peek_word(v_n_241) <= v_i_240)) {
    heff_drop(v_n_241);
    return NTAG(TAG_Nil);
  } else {
    V v_cell_242 = heff_tag_n(TAG_Cons, 2, (V[]){heff_box_word(v_i_240), heff_hole()});
    V v_u_243 = (g_heff_2ebuild_2eproject_2erangeFrom_24dps(heff_box_word((v_i_240 + ((int64_t)1ULL))), v_n_241, v_cell_242));
    heff_drop(v_u_243);
    return v_cell_242;
  }
}
V g_heff_2ebuild_2eproject_2erangeFrom_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eproject_2erangeFrom(a[0], a[1]);
}
Clo g_heff_2ebuild_2eproject_2erangeFrom_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eproject_2erangeFrom_24dps_entry, 3, 0};

V g_heff_2ebuild_2eproject_2erangeFrom_24dps(V v_box_24i_240, V v_box_24n_241, V v_d_242) {
  int64_t v_i_240 = heff_unbox_word(v_box_24i_240);
  int64_t v_n_241 = heff_unbox_word(v_box_24n_241);
top: ;
  if ((v_n_241 <= v_i_240)) {
    return heff_setField(heff_dup(v_d_242), MK_INT(1LL), NTAG(TAG_Nil));
  } else {
    V v_cell_243 = heff_tag_n(TAG_Cons, 2, (V[]){heff_box_word(v_i_240), heff_hole()});
    V v_u_244 = heff_setFieldPeek(v_d_242, MK_INT(1LL), v_cell_243);
    int64_t t_0 = (v_i_240 + ((int64_t)1ULL));
    int64_t t_1 = v_n_241;
    V t_2 = v_u_244;
    v_i_240 = t_0;
    v_n_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
}
V g_heff_2ebuild_2eproject_2erangeFrom_24dps_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ebuild_2eproject_2erangeFrom_24dps(a[0], a[1], a2); heff_drop(a2); return r;
}

HeffT3 g_heff_2ebuild_2eproject_2epseudoParts_24cpr(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_base_241 = heff_field(v_x1_240, 0);
    V v_x12_242 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x12_242)) {
    case TAG_Nil: {
      return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
    }
    case TAG_Cons: {
      V v_time_243 = heff_field(v_x12_242, 0);
      V v_x122_244 = heff_field(v_x12_242, 1);
      switch (heff_tag_of(v_x122_244)) {
      case TAG_Nil: {
        return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
      }
      case TAG_Cons: {
        V v_commit_245 = heff_field(v_x122_244, 0);
        V v_x1222_246 = heff_field(v_x122_244, 1);
        switch (heff_tag_of(v_x1222_246)) {
        case TAG_Nil: {
          HeffT5 v_t_247 = (g_heff_2ebuild_2eproject_2eversion_24cpr(v_base_241));
          {
            V v_field_249 = v_t_247.f[1];
            V v_field_2410 = v_t_247.f[2];
            V v_field_2411 = v_t_247.f[3];
            V v_field_2412 = v_t_247.f[4];
            int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
            if ((v_tag_248 == ((int64_t)0ULL))) {
              V v_x111_2413 = v_field_249;
              heff_drop(v_x111_2413);
              V v_b_2414 = v_field_2410;
              V v_c_2415 = v_field_2411;
              V v_x11222_2416 = v_field_2412;
              switch (heff_tag_of(v_x11222_2416)) {
              case TAG_Nil: {
                if ((heff_intEq_c_lent(v_b_2414, MK_INT(0LL), 2) && heff_intEq_c_lent(v_c_2415, MK_INT(0LL), 2))) {
                  heff_drop(v_b_2414);
                  heff_drop(v_c_2415);
                  if ((heff_unbox_word(heff_strLength_lent(v_time_243, 0)) == ((int64_t)14ULL))) {
                    V v_t_2417 = (g_heff_2ebuild_2eproject_2erangeFrom(MK_INT(0LL), heff_strLength_lent(v_time_243, 0)));
                    V v_t_2418 = ({ V a_0 = v_time_243; V a_1 = MK_INT(48LL); V a_2 = MK_INT(57LL); V a_3 = v_t_2417; V r_ = (g_list_2eall_24s418009941x978041577(a_0, a_1, a_2, a_3)); heff_drop(v_t_2417); r_; });
                    if ((heff_dup(v_t_2418) == NTAG(TAG_True))) {
                      heff_drop(v_t_2418);
                      if ((heff_unbox_word(heff_strLength_lent(v_commit_245, 0)) == ((int64_t)12ULL))) {
                        V v_t_2419 = (g_heff_2ebuild_2eproject_2erangeFrom(MK_INT(0LL), heff_strLength_lent(v_commit_245, 0)));
                        V v_t_2420 = ({ V a_0 = v_commit_245; V a_1 = MK_INT(48LL); V a_2 = MK_INT(57LL); V a_3 = MK_INT(97LL); V a_4 = MK_INT(102LL); V a_5 = v_t_2419; V r_ = (g_list_2eall_24s1432467604x1830816726(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_t_2419); r_; });
                        if ((heff_dup(v_t_2420) == NTAG(TAG_True))) {
                          heff_drop(v_t_2420);
                          return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_time_243), heff_dup(v_commit_245)}});
                        } else {
                          heff_drop(v_t_2420);
                          return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                        }
                      } else {
                        return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                      }
                    } else {
                      heff_drop(v_t_2418);
                      return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                    }
                  } else {
                    return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                  }
                } else {
                  heff_drop(v_b_2414);
                  heff_drop(v_c_2415);
                  return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                }
              }
              case TAG_Cons: {
                heff_take_n(v_x11222_2416, 0ULL, 2);
                heff_drop(v_b_2414);
                heff_drop(v_c_2415);
                return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
              }
              default: return ((HeffT3){{heff_nomatch(v_x11222_2416)}});
              }
            } else {
              heff_drop(v_field_249);
              heff_drop(v_field_2410);
              heff_drop(v_field_2411);
              heff_drop(v_field_2412);
              return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
            }
          }
        }
        case TAG_Cons: {
          return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
        }
        default: return ((HeffT3){{heff_nomatch(v_x1222_246)}});
        }
      }
      default: return ((HeffT3){{heff_nomatch(v_x122_244)}});
      }
    }
    default: return ((HeffT3){{heff_nomatch(v_x12_242)}});
    }
  }
  default: return ((HeffT3){{heff_nomatch(v_x1_240)}});
  }
}
Clo g_heff_2ebuild_2eproject_2epseudoParts_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eproject_2epseudoParts_entry, 1, 0};

V g_heff_2ebuild_2eproject_2epseudoParts(V v_x1_240) {
top: ;
  HeffT3 v_t_241 = (g_heff_2ebuild_2eproject_2epseudoParts_24cpr(v_x1_240));
  {
    V v_field_243 = v_t_241.f[1];
    V v_field_244 = v_t_241.f[2];
    int64_t v_tag_242 = ((int64_t)v_t_241.f[0]);
    if ((v_tag_242 == ((int64_t)0ULL))) {
      return heff_tag_n(TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_field_243, v_field_244})});
    } else {
      heff_drop(v_field_243);
      heff_drop(v_field_244);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_heff_2ebuild_2eproject_2epseudoParts_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2eproject_2epseudoParts(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ebuild_2eproject_2enameRule_str0, 58, "a lowercase letter, then lowercase letters, digits and `_`");

static V g_heff_2ebuild_2eproject_2enameRule_val;
static HEFF_ONCE g_heff_2ebuild_2eproject_2enameRule_st;
static V g_heff_2ebuild_2eproject_2enameRule_init(void) {
  return ((V)&g_heff_2ebuild_2eproject_2enameRule_str0);
}
V g_heff_2ebuild_2eproject_2enameRule_get(void) {
  if (HEFF_DONE(g_heff_2ebuild_2eproject_2enameRule_st)) return g_heff_2ebuild_2eproject_2enameRule_val;
  return heff_global(&g_heff_2ebuild_2eproject_2enameRule_val, &g_heff_2ebuild_2eproject_2enameRule_st, g_heff_2ebuild_2eproject_2enameRule_init);
}
HEFF_LIT(g_heff_2ebuild_2eproject_2etestsModule_str0, 4, "test");

static V g_heff_2ebuild_2eproject_2etestsModule_val;
static HEFF_ONCE g_heff_2ebuild_2eproject_2etestsModule_st;
static V g_heff_2ebuild_2eproject_2etestsModule_init(void) {
  return ((V)&g_heff_2ebuild_2eproject_2etestsModule_str0);
}
V g_heff_2ebuild_2eproject_2etestsModule_get(void) {
  if (HEFF_DONE(g_heff_2ebuild_2eproject_2etestsModule_st)) return g_heff_2ebuild_2eproject_2etestsModule_val;
  return heff_global(&g_heff_2ebuild_2eproject_2etestsModule_val, &g_heff_2ebuild_2eproject_2etestsModule_st, g_heff_2ebuild_2eproject_2etestsModule_init);
}

HeffT2 g_heff_2ebuild_2eproject_2efieldsIn_24cpr(V v_t_240, V v_x2_241, V v_written_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_t_240);
    switch (heff_tag_of(v_written_242)) {
    case TAG_Nil: {
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), NTAG(TAG_Nil)}});
    }
    case TAG_Cons: {
      heff_take_n(v_written_242, 0ULL, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    default: return ((HeffT2){{heff_nomatch(v_written_242)}});
    }
  }
  case TAG_Cons: {
    V v_f_245 = heff_field(v_x2_241, 0);
    V v_rest_246 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_left_247 = heff_take_field(v_f_245, 1);
    V v_name_248 = heff_get_n(v_f_245, 0, 2);
    switch (heff_tag_of(v_written_242)) {
    case TAG_Nil: {
      heff_drop(v_name_248);
      V v_t_249 = v_left_247;
      switch (heff_tag_of(v_t_249)) {
      case TAG_Nothing: {
        heff_drop(v_t_240);
        heff_drop(v_rest_246);
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_Just: {
        V v_mk_2410 = heff_field(v_t_249, 0);
        heff_take_n(v_t_249, 1ULL, 1);
        V v_v_2411 = heff_tr(heff_call(v_mk_2410, 1, (V[]){heff_dup(v_t_240)}));
        HeffT2 v_t_2412 = (g_heff_2ebuild_2eproject_2efieldsIn_24cpr(v_t_240, v_rest_246, v_written_242));
        {
          V v_field_2414 = v_t_2412.f[1];
          int64_t v_tag_2413 = ((int64_t)v_t_2412.f[0]);
          if ((v_tag_2413 == ((int64_t)0ULL))) {
            V v_vs_2415 = v_field_2414;
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_v_2411, v_vs_2415})}});
          } else {
            heff_drop_cell(v_ru_24x2_241_24Cons, 2);
            heff_drop(v_v_2411);
            heff_drop(v_field_2414);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_t_249)}});
      }
    }
    case TAG_Cons: {
      V v_x21_2416 = heff_dup(heff_field(v_written_242, 0));
      V v_more_2417 = heff_dup(heff_field(v_written_242, 1));
      switch (heff_tag_of(v_x21_2416)) {
      case TAG_MkPair: {
        V v_y_2418 = heff_field(v_x21_2416, 0);
        V v_v_2419 = heff_field(v_x21_2416, 1);
        heff_take_n(v_x21_2416, 3ULL, 2);
        if (heff_strEq_c(v_name_248, v_y_2418)) {
          heff_drop_tag(v_written_242, 2);
          heff_drop(v_left_247);
          V v_v_2420 = v_v_2419;
          V v_more_2421 = v_more_2417;
          HeffT2 v_t_2422 = (g_heff_2ebuild_2eproject_2efieldsIn_24cpr(v_t_240, v_rest_246, v_more_2421));
          {
            V v_field_2424 = v_t_2422.f[1];
            int64_t v_tag_2423 = ((int64_t)v_t_2422.f[0]);
            if ((v_tag_2423 == ((int64_t)0ULL))) {
              V v_vs_2425 = v_field_2424;
              return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_v_2420, v_vs_2425})}});
            } else {
              heff_drop_cell(v_ru_24x2_241_24Cons, 2);
              heff_drop(v_v_2420);
              heff_drop(v_field_2424);
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
            }
          }
        } else {
          heff_drop(v_more_2417);
          heff_drop(v_v_2419);
          V v_t_2426 = v_left_247;
          switch (heff_tag_of(v_t_2426)) {
          case TAG_Nothing: {
            heff_drop(v_t_240);
            heff_drop_tag(v_written_242, 2);
            heff_drop(v_rest_246);
            heff_drop_cell(v_ru_24x2_241_24Cons, 2);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          case TAG_Just: {
            V v_mk_2427 = heff_field(v_t_2426, 0);
            heff_take_n(v_t_2426, 1ULL, 1);
            V v_v_2428 = heff_tr(heff_call(v_mk_2427, 1, (V[]){heff_dup(v_t_240)}));
            HeffT2 v_t_2429 = (g_heff_2ebuild_2eproject_2efieldsIn_24cpr(v_t_240, v_rest_246, v_written_242));
            {
              V v_field_2431 = v_t_2429.f[1];
              int64_t v_tag_2430 = ((int64_t)v_t_2429.f[0]);
              if ((v_tag_2430 == ((int64_t)0ULL))) {
                V v_vs_2432 = v_field_2431;
                return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_v_2428, v_vs_2432})}});
              } else {
                heff_drop_cell(v_ru_24x2_241_24Cons, 2);
                heff_drop(v_v_2428);
                heff_drop(v_field_2431);
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
              }
            }
          }
          default: return ((HeffT2){{heff_nomatch(v_t_2426)}});
          }
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x21_2416)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_written_242)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
HEFF_LIT(g_heff_2ebuild_2eproject_2estr_24cpr_str0, 17, "expected a string");
HEFF_LIT(g_heff_2ebuild_2eproject_2estr_24cpr_str1, 17, "expected a string");
HEFF_LIT(g_heff_2ebuild_2eproject_2estr_24cpr_str2, 17, "expected a string");

HeffT2 g_heff_2ebuild_2eproject_2estr_24cpr(V v_x_240) {
top: ;
  switch (heff_tag_of(v_x_240)) {
  case TAG_LStr: {
    V v_s_241 = heff_field(v_x_240, 0);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), heff_dup(v_s_241)}});
  }
  case TAG_LTag: {
    V v_t_2413;
    switch (heff_tag_of(v_x_240)) {
    case TAG_LStr: {
      V v_t_246 = heff_field(v_x_240, 1);
      v_t_2413 = heff_dup(v_t_246);
      break;
    }
    case TAG_LTag: {
      V v_t_248 = heff_field(v_x_240, 1);
      v_t_2413 = heff_dup(v_t_248);
      break;
    }
    case TAG_LList: {
      V v_t_2410 = heff_field(v_x_240, 1);
      v_t_2413 = heff_dup(v_t_2410);
      break;
    }
    case TAG_LRec: {
      V v_t_2412 = heff_field(v_x_240, 1);
      v_t_2413 = heff_dup(v_t_2412);
      break;
    }
    default: heff_nomatch(v_x_240);
    }
    V v_f_2414 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2413, 2, 7), ((V)&g_heff_2ebuild_2eproject_2estr_24cpr_str0)});
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2414}});
  }
  case TAG_LList: {
    V v_t_2425;
    switch (heff_tag_of(v_x_240)) {
    case TAG_LStr: {
      V v_t_2418 = heff_field(v_x_240, 1);
      v_t_2425 = heff_dup(v_t_2418);
      break;
    }
    case TAG_LTag: {
      V v_t_2420 = heff_field(v_x_240, 1);
      v_t_2425 = heff_dup(v_t_2420);
      break;
    }
    case TAG_LList: {
      V v_t_2422 = heff_field(v_x_240, 1);
      v_t_2425 = heff_dup(v_t_2422);
      break;
    }
    case TAG_LRec: {
      V v_t_2424 = heff_field(v_x_240, 1);
      v_t_2425 = heff_dup(v_t_2424);
      break;
    }
    default: heff_nomatch(v_x_240);
    }
    V v_f_2426 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2425, 2, 7), ((V)&g_heff_2ebuild_2eproject_2estr_24cpr_str1)});
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2426}});
  }
  case TAG_LRec: {
    V v_t_2437;
    switch (heff_tag_of(v_x_240)) {
    case TAG_LStr: {
      V v_t_2430 = heff_field(v_x_240, 1);
      v_t_2437 = heff_dup(v_t_2430);
      break;
    }
    case TAG_LTag: {
      V v_t_2432 = heff_field(v_x_240, 1);
      v_t_2437 = heff_dup(v_t_2432);
      break;
    }
    case TAG_LList: {
      V v_t_2434 = heff_field(v_x_240, 1);
      v_t_2437 = heff_dup(v_t_2434);
      break;
    }
    case TAG_LRec: {
      V v_t_2436 = heff_field(v_x_240, 1);
      v_t_2437 = heff_dup(v_t_2436);
      break;
    }
    default: heff_nomatch(v_x_240);
    }
    V v_f_2438 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2437, 2, 7), ((V)&g_heff_2ebuild_2eproject_2estr_24cpr_str2)});
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2438}});
  }
  default: return ((HeffT2){{heff_nomatch(v_x_240)}});
  }
}
HEFF_LIT(g_heff_2ebuild_2eproject_2enameOf_24cpr_str0, 1, "`");
HEFF_LIT(g_heff_2ebuild_2eproject_2enameOf_24cpr_str1, 25, "` cannot name a package: ");

HeffT2 g_heff_2ebuild_2eproject_2enameOf_24cpr(V v_x_240) {
top: ;
  HeffT2 v_t_241 = (g_heff_2ebuild_2eproject_2estr_24cpr(v_x_240));
  {
    V v_field_243 = v_t_241.f[1];
    int64_t v_tag_242 = ((int64_t)v_t_241.f[0]);
    if ((v_tag_242 == ((int64_t)0ULL))) {
      V v_p_244 = v_field_243;
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_p_244}});
    } else {
      V v_n_245 = v_field_243;
      HeffT2 v_t_246 = (g_heff_2ebuild_2eproject_2ewhyNoName_24cpr(v_n_245));
      {
        V v_field_248 = v_t_246.f[1];
        int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
        if ((v_tag_247 == ((int64_t)0ULL))) {
          V v_why_249 = v_field_248;
          V v_t_2418;
          switch (heff_tag_of(v_x_240)) {
          case TAG_LStr: {
            V v_t_2411 = heff_field(v_x_240, 1);
            v_t_2418 = heff_dup(v_t_2411);
            break;
          }
          case TAG_LTag: {
            V v_t_2413 = heff_field(v_x_240, 1);
            v_t_2418 = heff_dup(v_t_2413);
            break;
          }
          case TAG_LList: {
            V v_t_2415 = heff_field(v_x_240, 1);
            v_t_2418 = heff_dup(v_t_2415);
            break;
          }
          case TAG_LRec: {
            V v_t_2417 = heff_field(v_x_240, 1);
            v_t_2418 = heff_dup(v_t_2417);
            break;
          }
          default: heff_nomatch(v_x_240);
          }
          V v_t_2419 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2eproject_2enameOf_24cpr_str0), v_n_245), ((V)&g_heff_2ebuild_2eproject_2enameOf_24cpr_str1));
          V v_f_2420 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2418, 2, 7), heff_strAppend(v_t_2419, v_why_249)});
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2420}});
        } else {
          heff_drop(v_field_248);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_n_245}});
        }
      }
    }
  }
}
HEFF_LIT(g_heff_2ebuild_2eproject_2emajorMismatch_24cpr_str0, 1, "-");
HEFF_LIT(g_heff_2ebuild_2eproject_2emajorMismatch_24cpr_str1, 1, "-");
HEFF_LIT(g_heff_2ebuild_2eproject_2emajorMismatch_24cpr_str2, 1, "v");
HEFF_LIT(g_heff_2ebuild_2eproject_2emajorMismatch_24cpr_str3, 1, "/");
HEFF_LIT(g_heff_2ebuild_2eproject_2emajorMismatch_24cpr_str4, 1, "/");
HEFF_LIT(g_heff_2ebuild_2eproject_2emajorMismatch_24cpr_str5, 8, "version ");
HEFF_LIT(g_heff_2ebuild_2eproject_2emajorMismatch_24cpr_str6, 35, " is fetched from a path ending in /");
HEFF_LIT(g_heff_2ebuild_2eproject_2emajorMismatch_24cpr_str7, 1, "/");
HEFF_LIT(g_heff_2ebuild_2eproject_2emajorMismatch_24cpr_str8, 1, "/");
HEFF_LIT(g_heff_2ebuild_2eproject_2emajorMismatch_24cpr_str9, 8, "version ");
HEFF_LIT(g_heff_2ebuild_2eproject_2emajorMismatch_24cpr_str10, 44, " is fetched from a path without a /vN ending");

HeffT2 g_heff_2ebuild_2eproject_2emajorMismatch_24cpr(V v_path_240, V v_v_241) {
top: ;
  V v_t_242 = ({ V a_0 = v_v_241; V b_1 = ((V)&g_heff_2ebuild_2eproject_2emajorMismatch_24cpr_str0); V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2eproject_2emajorMismatch_24cpr_str1), v_v_241, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplit_2esplitFrom_240(a_0, b_1, a_2, a_3, a_4)); heff_drop(b_1); r_; });
  V v_t_243 = ({ V a_0 = v_t_242; V r_ = (g_heff_2ebuild_2eproject_2epseudoParts(a_0)); heff_drop(v_t_242); r_; });
  HeffT2 v_t_244 = ({ V a_0 = v_v_241; V a_1 = v_t_243; HeffT2 r_ = (g_heff_2ebuild_2eproject_2ekeyFrom_24cpr(a_0, a_1)); heff_drop(v_t_243); r_; });
  {
    V v_field_245 = v_t_244.f[0];
    V v_field_246 = v_t_244.f[1];
    V v_x_247 = v_field_245;
    V v_y_248 = v_field_246;
    heff_drop(v_y_248);
    V v_t_249 = v_x_247;
    V v_n_2412;
    switch (heff_tag_of(v_t_249)) {
    case TAG_Nil: {
      v_n_2412 = MK_INT(0LL);
      break;
    }
    case TAG_Cons: {
      V v_x_2410 = heff_field(v_t_249, 0);
      heff_take_n(v_t_249, 1ULL, 2);
      v_n_2412 = v_x_2410;
      break;
    }
    default: heff_nomatch(v_t_249);
    }
    if (heff_intLe_c_lent(MK_INT(2LL), v_n_2412, 1)) {
      V v_suffix_2413 = heff_strAppend(((V)&g_heff_2ebuild_2eproject_2emajorMismatch_24cpr_str2), heff_intShow(v_n_2412));
      V v_xs_2414 = ({ V a_0 = v_path_240; V b_1 = ((V)&g_heff_2ebuild_2eproject_2emajorMismatch_24cpr_str3); V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2eproject_2emajorMismatch_24cpr_str4), v_path_240, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplit_2esplitFrom_240(a_0, b_1, a_2, a_3, a_4)); heff_drop(b_1); r_; });
      V v_t_2415 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2414));
      V v_t_2418;
      switch (heff_tag_of(v_t_2415)) {
      case TAG_Nil: {
        v_t_2418 = v_path_240;
        break;
      }
      case TAG_Cons: {
        V v_x_2416 = heff_field(v_t_2415, 0);
        heff_take_n(v_t_2415, 1ULL, 2);
        heff_drop(v_path_240);
        v_t_2418 = v_x_2416;
        break;
      }
      default: heff_nomatch(v_t_2415);
      }
      if (heff_strEq_c_lent(v_t_2418, v_suffix_2413, 1)) {
        heff_drop(v_v_241);
        heff_drop(v_suffix_2413);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      } else {
        V v_t_2419 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2eproject_2emajorMismatch_24cpr_str5), v_v_241), ((V)&g_heff_2ebuild_2eproject_2emajorMismatch_24cpr_str6));
        V v_f_2420 = heff_strAppend(v_t_2419, v_suffix_2413);
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2420}});
      }
    } else {
      heff_drop(v_n_2412);
      V v_xs_2421 = ({ V a_0 = v_path_240; V b_1 = ((V)&g_heff_2ebuild_2eproject_2emajorMismatch_24cpr_str7); V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2eproject_2emajorMismatch_24cpr_str8), v_path_240, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplit_2esplitFrom_240(a_0, b_1, a_2, a_3, a_4)); heff_drop(b_1); r_; });
      V v_t_2422 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2421));
      V v_t_2425;
      switch (heff_tag_of(v_t_2422)) {
      case TAG_Nil: {
        v_t_2425 = v_path_240;
        break;
      }
      case TAG_Cons: {
        V v_x_2423 = heff_field(v_t_2422, 0);
        heff_take_n(v_t_2422, 1ULL, 2);
        heff_drop(v_path_240);
        v_t_2425 = v_x_2423;
        break;
      }
      default: heff_nomatch(v_t_2422);
      }
      V v_t_2426 = ({ V a_0 = v_t_2425; V r_ = (g_heff_2ebuild_2eproject_2eisMajorPart(a_0)); heff_drop(v_t_2425); r_; });
      if ((heff_dup(v_t_2426) == NTAG(TAG_True))) {
        heff_drop(v_t_2426);
        V v_f_2427 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2eproject_2emajorMismatch_24cpr_str9), v_v_241), ((V)&g_heff_2ebuild_2eproject_2emajorMismatch_24cpr_str10));
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2427}});
      } else {
        heff_drop(v_v_241);
        heff_drop(v_t_2426);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
  }
}

HeffT3 g_heff_2ebuild_2eproject_2etwiceGo_24cpr(V v_seen_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_seen_240);
    return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_MkPair: {
      V v_n_244 = heff_field(v_x21_242, 0);
      V v_x_245 = heff_field(v_x21_242, 1);
      heff_take_n(v_x21_242, 3ULL, 2);
      V v_t_246 = (g_list_2eany_24s1006624359x760861690(v_n_244, v_seen_240));
      if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
        heff_drop(v_seen_240);
        heff_drop(v_rest_243);
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        heff_drop(v_t_246);
        return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), v_n_244, v_x_245}});
      } else {
        heff_drop(v_x_245);
        heff_drop(v_t_246);
        V t_0 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_n_244, v_seen_240});
        V t_1 = v_rest_243;
        v_seen_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
    }
    default: return ((HeffT3){{heff_nomatch(v_x21_242)}});
    }
  }
  default: return ((HeffT3){{heff_nomatch(v_x2_241)}});
  }
}
HEFF_LIT(g_heff_2ebuild_2eproject_2eheffModule_str0, 4, "heff");

static V g_heff_2ebuild_2eproject_2eheffModule_val;
static HEFF_ONCE g_heff_2ebuild_2eproject_2eheffModule_st;
static V g_heff_2ebuild_2eproject_2eheffModule_init(void) {
  return ((V)&g_heff_2ebuild_2eproject_2eheffModule_str0);
}
V g_heff_2ebuild_2eproject_2eheffModule_get(void) {
  if (HEFF_DONE(g_heff_2ebuild_2eproject_2eheffModule_st)) return g_heff_2ebuild_2eproject_2eheffModule_val;
  return heff_global(&g_heff_2ebuild_2eproject_2eheffModule_val, &g_heff_2ebuild_2eproject_2eheffModule_st, g_heff_2ebuild_2eproject_2eheffModule_init);
}
HEFF_LIT(g_heff_2ebuild_2eproject_2erequireMsg_str0, 89, "error[E0347]: the package `heff` is heff's own, which comes with heff: it is not required");

static V g_heff_2ebuild_2eproject_2erequireMsg_val;
static HEFF_ONCE g_heff_2ebuild_2eproject_2erequireMsg_st;
static V g_heff_2ebuild_2eproject_2erequireMsg_init(void) {
  return ((V)&g_heff_2ebuild_2eproject_2erequireMsg_str0);
}
V g_heff_2ebuild_2eproject_2erequireMsg_get(void) {
  if (HEFF_DONE(g_heff_2ebuild_2eproject_2erequireMsg_st)) return g_heff_2ebuild_2eproject_2erequireMsg_val;
  return heff_global(&g_heff_2ebuild_2eproject_2erequireMsg_val, &g_heff_2ebuild_2eproject_2erequireMsg_st, g_heff_2ebuild_2eproject_2erequireMsg_init);
}

HeffT3 g_heff_2ebuild_2eproject_2efirstNamed_24cpr(V v_names_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_MkPair: {
      V v_n_244 = heff_field(v_x21_242, 0);
      V v_x_245 = heff_field(v_x21_242, 1);
      V v_t_246 = (g_list_2eany_24s1006624359x760861690(v_n_244, v_names_240));
      if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
        heff_drop(v_t_246);
        return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_n_244), heff_dup(v_x_245)}});
      } else {
        heff_drop(v_t_246);
        V t_0 = v_names_240;
        V t_1 = v_rest_243;
        v_names_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
    }
    default: return ((HeffT3){{heff_nomatch(v_x21_242)}});
    }
  }
  default: return ((HeffT3){{heff_nomatch(v_x2_241)}});
  }
}

HeffT2 g_heff_2ebuild_2eproject_2eallOf_24s2049964666x1020559920_24cpr(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), NTAG(TAG_Nil)}});
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_rest_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    HeffT2 v_t_243 = ({ V a_0 = v_x_241; HeffT2 r_ = (g_heff_2ebuild_2eproject_2erequireOf_24cpr(a_0)); heff_drop(v_x_241); r_; });
    {
      V v_field_245 = v_t_243.f[1];
      int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
      HeffT2 v_t_246 = (g_heff_2ebuild_2eproject_2eallOf_24s2049964666x1020559920_24cpr(v_rest_242));
      {
        V v_field_248 = v_t_246.f[1];
        int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
        if ((v_tag_244 == ((int64_t)0ULL))) {
          heff_drop_cell(v_ru_24x2_240_24Cons, 2);
          heff_drop(v_field_248);
          V v_p_249 = v_field_245;
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_p_249}});
        } else {
          V v_y_2410 = v_field_245;
          if ((v_tag_247 == ((int64_t)0ULL))) {
            heff_drop_cell(v_ru_24x2_240_24Cons, 2);
            heff_drop(v_y_2410);
            V v_p_2411 = v_field_248;
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_p_2411}});
          } else {
            V v_ys_2412 = v_field_248;
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_y_2410, v_ys_2412})}});
          }
        }
      }
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_240)}});
  }
}
HEFF_LIT(g_heff_2ebuild_2eproject_2epackageOf_24cpr_str0, 25, "expected a record `{...}`");
HEFF_LIT(g_heff_2ebuild_2eproject_2epackageOf_24cpr_str1, 25, "expected a record `{...}`");
HEFF_LIT(g_heff_2ebuild_2eproject_2epackageOf_24cpr_str2, 25, "expected a record `{...}`");
HEFF_LIT(g_heff_2ebuild_2eproject_2epackageOf_24cpr_str3, 25, "expected a record `{...}`");
HEFF_LIT(g_heff_2ebuild_2eproject_2epackageOf_24cpr_str4, 1, "`");
HEFF_LIT(g_heff_2ebuild_2eproject_2epackageOf_24cpr_str5, 45, "` is no version: write `a.b.c`, three numbers");
HEFF_LIT(g_heff_2ebuild_2eproject_2epackageOf_24cpr_str6, 25, "expected a record `{...}`");

HeffT2 g_heff_2ebuild_2eproject_2epackageOf_24cpr(V v_x_240) {
top: ;
  HeffT2 v_t_241 = (g_heff_2ebuild_2eproject_2efieldsAre_24cpr(heff_dup(g_heff_2ebuild_2eproject_2epackageFields_get()), v_x_240));
  {
    V v_field_243 = v_t_241.f[1];
    int64_t v_tag_242 = ((int64_t)v_t_241.f[0]);
    if ((v_tag_242 == ((int64_t)0ULL))) {
      V v_p_244 = v_field_243;
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_p_244}});
    } else {
      V v_it1_245 = v_field_243;
      switch (heff_tag_of(v_it1_245)) {
      case TAG_Nil: {
        V v_t_2414;
        switch (heff_tag_of(v_x_240)) {
        case TAG_LStr: {
          V v_t_247 = heff_field(v_x_240, 1);
          v_t_2414 = heff_dup(v_t_247);
          break;
        }
        case TAG_LTag: {
          V v_t_249 = heff_field(v_x_240, 1);
          v_t_2414 = heff_dup(v_t_249);
          break;
        }
        case TAG_LList: {
          V v_t_2411 = heff_field(v_x_240, 1);
          v_t_2414 = heff_dup(v_t_2411);
          break;
        }
        case TAG_LRec: {
          V v_t_2413 = heff_field(v_x_240, 1);
          v_t_2414 = heff_dup(v_t_2413);
          break;
        }
        default: heff_nomatch(v_x_240);
        }
        V v_f_2415 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2414, 2, 7), ((V)&g_heff_2ebuild_2eproject_2epackageOf_24cpr_str0)});
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2415}});
      }
      case TAG_Cons: {
        V v_m_2416 = heff_field(v_it1_245, 0);
        V v_it12_2417 = heff_field(v_it1_245, 1);
        V v_ru_24it1_245_24Cons = heff_take_reuse_n(v_it1_245, 3ULL, 2);
        switch (heff_tag_of(v_it12_2417)) {
        case TAG_Nil: {
          heff_drop(v_m_2416);
          heff_drop_cell(v_ru_24it1_245_24Cons, 2);
          V v_t_2426;
          switch (heff_tag_of(v_x_240)) {
          case TAG_LStr: {
            V v_t_2419 = heff_field(v_x_240, 1);
            v_t_2426 = heff_dup(v_t_2419);
            break;
          }
          case TAG_LTag: {
            V v_t_2421 = heff_field(v_x_240, 1);
            v_t_2426 = heff_dup(v_t_2421);
            break;
          }
          case TAG_LList: {
            V v_t_2423 = heff_field(v_x_240, 1);
            v_t_2426 = heff_dup(v_t_2423);
            break;
          }
          case TAG_LRec: {
            V v_t_2425 = heff_field(v_x_240, 1);
            v_t_2426 = heff_dup(v_t_2425);
            break;
          }
          default: heff_nomatch(v_x_240);
          }
          V v_f_2427 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2426, 2, 7), ((V)&g_heff_2ebuild_2eproject_2epackageOf_24cpr_str1)});
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2427}});
        }
        case TAG_Cons: {
          V v_h_2428 = heff_field(v_it12_2417, 0);
          V v_it122_2429 = heff_field(v_it12_2417, 1);
          V v_ru_24it12_2417_24Cons = heff_take_reuse_n(v_it12_2417, 3ULL, 2);
          switch (heff_tag_of(v_it122_2429)) {
          case TAG_Nil: {
            heff_drop(v_m_2416);
            heff_drop_cell(v_ru_24it1_245_24Cons, 2);
            heff_drop(v_h_2428);
            heff_drop_cell(v_ru_24it12_2417_24Cons, 2);
            V v_t_2438;
            switch (heff_tag_of(v_x_240)) {
            case TAG_LStr: {
              V v_t_2431 = heff_field(v_x_240, 1);
              v_t_2438 = heff_dup(v_t_2431);
              break;
            }
            case TAG_LTag: {
              V v_t_2433 = heff_field(v_x_240, 1);
              v_t_2438 = heff_dup(v_t_2433);
              break;
            }
            case TAG_LList: {
              V v_t_2435 = heff_field(v_x_240, 1);
              v_t_2438 = heff_dup(v_t_2435);
              break;
            }
            case TAG_LRec: {
              V v_t_2437 = heff_field(v_x_240, 1);
              v_t_2438 = heff_dup(v_t_2437);
              break;
            }
            default: heff_nomatch(v_x_240);
            }
            V v_f_2439 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2438, 2, 7), ((V)&g_heff_2ebuild_2eproject_2epackageOf_24cpr_str2)});
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2439}});
          }
          case TAG_Cons: {
            V v_rq_2440 = heff_field(v_it122_2429, 0);
            V v_it1222_2441 = heff_field(v_it122_2429, 1);
            V v_ru_24it122_2429_24Cons = heff_take_reuse_n(v_it122_2429, 3ULL, 2);
            switch (heff_tag_of(v_it1222_2441)) {
            case TAG_Nil: {
              heff_drop(v_m_2416);
              heff_drop_cell(v_ru_24it1_245_24Cons, 2);
              heff_drop(v_h_2428);
              heff_drop_cell(v_ru_24it12_2417_24Cons, 2);
              heff_drop(v_rq_2440);
              heff_drop_cell(v_ru_24it122_2429_24Cons, 2);
              V v_t_2450;
              switch (heff_tag_of(v_x_240)) {
              case TAG_LStr: {
                V v_t_2443 = heff_field(v_x_240, 1);
                v_t_2450 = heff_dup(v_t_2443);
                break;
              }
              case TAG_LTag: {
                V v_t_2445 = heff_field(v_x_240, 1);
                v_t_2450 = heff_dup(v_t_2445);
                break;
              }
              case TAG_LList: {
                V v_t_2447 = heff_field(v_x_240, 1);
                v_t_2450 = heff_dup(v_t_2447);
                break;
              }
              case TAG_LRec: {
                V v_t_2449 = heff_field(v_x_240, 1);
                v_t_2450 = heff_dup(v_t_2449);
                break;
              }
              default: heff_nomatch(v_x_240);
              }
              V v_f_2451 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2450, 2, 7), ((V)&g_heff_2ebuild_2eproject_2epackageOf_24cpr_str3)});
              return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2451}});
            }
            case TAG_Cons: {
              V v_rp_2452 = heff_field(v_it1222_2441, 0);
              V v_it12222_2453 = heff_field(v_it1222_2441, 1);
              heff_take_n(v_it1222_2441, 3ULL, 2);
              switch (heff_tag_of(v_it12222_2453)) {
              case TAG_Nil: {
                V v_m_2454 = v_m_2416;
                V v_h_2455 = v_h_2428;
                V v_rq_2456 = v_rq_2440;
                V v_rp_2457 = v_rp_2452;
                HeffT2 v_t_2458 = ({ V a_0 = v_m_2454; HeffT2 r_ = (g_heff_2ebuild_2eproject_2estr_24cpr(a_0)); heff_drop(v_m_2454); r_; });
                {
                  V v_field_2460 = v_t_2458.f[1];
                  int64_t v_tag_2459 = ((int64_t)v_t_2458.f[0]);
                  if ((v_tag_2459 == ((int64_t)0ULL))) {
                    heff_drop_cell(v_ru_24it1_245_24Cons, 2);
                    heff_drop_cell(v_ru_24it12_2417_24Cons, 2);
                    heff_drop_cell(v_ru_24it122_2429_24Cons, 2);
                    heff_drop(v_h_2455);
                    heff_drop(v_rq_2456);
                    heff_drop(v_rp_2457);
                    V v_p_2461 = v_field_2460;
                    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_p_2461}});
                  } else {
                    V v_mpath_2462 = v_field_2460;
                    HeffT2 v_t_2463 = (g_heff_2ebuild_2eproject_2estr_24cpr(v_h_2455));
                    {
                      V v_field_2465 = v_t_2463.f[1];
                      int64_t v_tag_2464 = ((int64_t)v_t_2463.f[0]);
                      if ((v_tag_2464 == ((int64_t)0ULL))) {
                        heff_drop_cell(v_ru_24it1_245_24Cons, 2);
                        heff_drop_cell(v_ru_24it12_2417_24Cons, 2);
                        heff_drop_cell(v_ru_24it122_2429_24Cons, 2);
                        heff_drop(v_h_2455);
                        heff_drop(v_rq_2456);
                        heff_drop(v_rp_2457);
                        heff_drop(v_mpath_2462);
                        V v_p_2466 = v_field_2465;
                        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_p_2466}});
                      } else {
                        V v_v_2467 = v_field_2465;
                        HeffT5 v_t_2468 = (g_heff_2ebuild_2eproject_2eversion_24cpr(v_v_2467));
                        {
                          V v_field_2470 = v_t_2468.f[1];
                          V v_field_2471 = v_t_2468.f[2];
                          V v_field_2472 = v_t_2468.f[3];
                          V v_field_2473 = v_t_2468.f[4];
                          int64_t v_tag_2469 = ((int64_t)v_t_2468.f[0]);
                          if ((v_tag_2469 == ((int64_t)0ULL))) {
                            heff_drop(v_h_2455);
                            V v_t_2474 = heff_tag_at_n(v_ru_24it1_245_24Cons, TAG_Cons, 2, (V[]){v_field_2471, heff_tag_at_n(v_ru_24it12_2417_24Cons, TAG_Cons, 2, (V[]){v_field_2472, v_field_2473})});
                            V v_x_2475 = heff_tag_at_n(v_ru_24it122_2429_24Cons, TAG_Cons, 2, (V[]){v_field_2470, v_t_2474});
                            heff_drop_tag(v_x_2475, 2);
                            HeffT2 v_t_2476 = ({ V a_0 = v_rq_2456; HeffT2 r_ = (g_heff_2ebuild_2eproject_2eitems_24cpr(a_0)); heff_drop(v_rq_2456); r_; });
                            {
                              V v_field_2478 = v_t_2476.f[1];
                              int64_t v_tag_2477 = ((int64_t)v_t_2476.f[0]);
                              if ((v_tag_2477 == ((int64_t)0ULL))) {
                                heff_drop(v_rp_2457);
                                heff_drop(v_mpath_2462);
                                heff_drop(v_v_2467);
                                V v_p_2479 = v_field_2478;
                                return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_p_2479}});
                              } else {
                                V v_rxs_2480 = v_field_2478;
                                HeffT2 v_t_2481 = (g_heff_2ebuild_2eproject_2eallOf_24s2049964666x1020559920_24cpr(heff_dup(v_rxs_2480)));
                                {
                                  V v_field_2483 = v_t_2481.f[1];
                                  int64_t v_tag_2482 = ((int64_t)v_t_2481.f[0]);
                                  if ((v_tag_2482 == ((int64_t)0ULL))) {
                                    heff_drop(v_rp_2457);
                                    heff_drop(v_mpath_2462);
                                    heff_drop(v_v_2467);
                                    heff_drop(v_rxs_2480);
                                    V v_p_2484 = v_field_2483;
                                    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_p_2484}});
                                  } else {
                                    V v_rs_2485 = v_field_2483;
                                    HeffT2 v_t_2486 = ({ V a_0 = v_rp_2457; HeffT2 r_ = (g_heff_2ebuild_2eproject_2eitems_24cpr(a_0)); heff_drop(v_rp_2457); r_; });
                                    {
                                      V v_field_2488 = v_t_2486.f[1];
                                      int64_t v_tag_2487 = ((int64_t)v_t_2486.f[0]);
                                      if ((v_tag_2487 == ((int64_t)0ULL))) {
                                        heff_drop(v_mpath_2462);
                                        heff_drop(v_v_2467);
                                        heff_drop(v_rxs_2480);
                                        heff_drop(v_rs_2485);
                                        V v_p_2489 = v_field_2488;
                                        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_p_2489}});
                                      } else {
                                        V v_pxs_2490 = v_field_2488;
                                        HeffT2 v_t_2491 = (g_heff_2ebuild_2eproject_2eallOf_24s1439570725x1912618195_24cpr(heff_dup(v_pxs_2490)));
                                        {
                                          V v_field_2493 = v_t_2491.f[1];
                                          int64_t v_tag_2492 = ((int64_t)v_t_2491.f[0]);
                                          if ((v_tag_2492 == ((int64_t)0ULL))) {
                                            heff_drop(v_mpath_2462);
                                            heff_drop(v_v_2467);
                                            heff_drop(v_rxs_2480);
                                            heff_drop(v_rs_2485);
                                            heff_drop(v_pxs_2490);
                                            V v_p_2494 = v_field_2493;
                                            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_p_2494}});
                                          } else {
                                            V v_ps_2495 = v_field_2493;
                                            HeffT2 v_t_2496 = (g_heff_2ebuild_2eproject_2echeckNames_24cpr(v_rxs_2480, heff_dup(v_rs_2485), v_pxs_2490, heff_dup(v_ps_2495)));
                                            {
                                              V v_field_2498 = v_t_2496.f[1];
                                              int64_t v_tag_2497 = ((int64_t)v_t_2496.f[0]);
                                              if ((v_tag_2497 == ((int64_t)0ULL))) {
                                                heff_drop(v_mpath_2462);
                                                heff_drop(v_v_2467);
                                                heff_drop(v_rs_2485);
                                                heff_drop(v_ps_2495);
                                                V v_p_2499 = v_field_2498;
                                                return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_p_2499}});
                                              } else {
                                                V v_x_24100 = v_field_2498;
                                                heff_drop(v_x_24100);
                                                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), heff_rec_n(4, shape_module__heff__require__replace, (V[]){v_mpath_2462, v_v_2467, v_rs_2485, v_ps_2495})}});
                                              }
                                            }
                                          }
                                        }
                                      }
                                    }
                                  }
                                }
                              }
                            }
                          } else {
                            heff_drop_cell(v_ru_24it1_245_24Cons, 2);
                            heff_drop_cell(v_ru_24it12_2417_24Cons, 2);
                            heff_drop_cell(v_ru_24it122_2429_24Cons, 2);
                            heff_drop(v_rq_2456);
                            heff_drop(v_rp_2457);
                            heff_drop(v_mpath_2462);
                            heff_drop(v_field_2470);
                            heff_drop(v_field_2471);
                            heff_drop(v_field_2472);
                            heff_drop(v_field_2473);
                            V v_t_24109;
                            switch (heff_tag_of(v_h_2455)) {
                            case TAG_LStr: {
                              V v_t_24102 = heff_field(v_h_2455, 1);
                              heff_take_n(v_h_2455, 2ULL, 2);
                              v_t_24109 = v_t_24102;
                              break;
                            }
                            case TAG_LTag: {
                              V v_t_24104 = heff_field(v_h_2455, 1);
                              heff_take_n(v_h_2455, 2ULL, 2);
                              v_t_24109 = v_t_24104;
                              break;
                            }
                            case TAG_LList: {
                              V v_t_24106 = heff_field(v_h_2455, 1);
                              heff_take_n(v_h_2455, 2ULL, 2);
                              v_t_24109 = v_t_24106;
                              break;
                            }
                            case TAG_LRec: {
                              V v_t_24108 = heff_field(v_h_2455, 1);
                              heff_take_n(v_h_2455, 2ULL, 2);
                              v_t_24109 = v_t_24108;
                              break;
                            }
                            default: heff_nomatch(v_h_2455);
                            }
                            V v_t_24110 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2eproject_2epackageOf_24cpr_str4), v_v_2467), ((V)&g_heff_2ebuild_2eproject_2epackageOf_24cpr_str5));
                            V v_f_24111 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_24109, 2, 7), v_t_24110});
                            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_24111}});
                          }
                        }
                      }
                    }
                  }
                }
              }
              case TAG_Cons: {
                heff_take_n(v_it12222_2453, 0ULL, 2);
                heff_drop(v_m_2416);
                heff_drop_cell(v_ru_24it1_245_24Cons, 2);
                heff_drop(v_h_2428);
                heff_drop_cell(v_ru_24it12_2417_24Cons, 2);
                heff_drop(v_rq_2440);
                heff_drop_cell(v_ru_24it122_2429_24Cons, 2);
                heff_drop(v_rp_2452);
                V v_t_24122;
                switch (heff_tag_of(v_x_240)) {
                case TAG_LStr: {
                  V v_t_24115 = heff_field(v_x_240, 1);
                  v_t_24122 = heff_dup(v_t_24115);
                  break;
                }
                case TAG_LTag: {
                  V v_t_24117 = heff_field(v_x_240, 1);
                  v_t_24122 = heff_dup(v_t_24117);
                  break;
                }
                case TAG_LList: {
                  V v_t_24119 = heff_field(v_x_240, 1);
                  v_t_24122 = heff_dup(v_t_24119);
                  break;
                }
                case TAG_LRec: {
                  V v_t_24121 = heff_field(v_x_240, 1);
                  v_t_24122 = heff_dup(v_t_24121);
                  break;
                }
                default: heff_nomatch(v_x_240);
                }
                V v_f_24123 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_24122, 2, 7), ((V)&g_heff_2ebuild_2eproject_2epackageOf_24cpr_str6)});
                return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_24123}});
              }
              default: return ((HeffT2){{heff_nomatch(v_it12222_2453)}});
              }
            }
            default: return ((HeffT2){{heff_nomatch(v_it1222_2441)}});
            }
          }
          default: return ((HeffT2){{heff_nomatch(v_it122_2429)}});
          }
        }
        default: return ((HeffT2){{heff_nomatch(v_it12_2417)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_it1_245)}});
      }
    }
  }
}
HEFF_LIT(g_heff_2ebuild_2eproject_2epackageLit_24cpr_str0, 10, "package.hf");
HEFF_LIT(g_heff_2ebuild_2eproject_2epackageLit_24cpr_str1, 7, "package");

HeffT2 g_heff_2ebuild_2eproject_2epackageLit_24cpr(V v_src_240) {
top: ;
  V v_t_241 = heff_rec_n(7, shape_i__line__lineStart__first__tok__err__cmt, (V[]){MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_True), NTAG(TAG_Nothing), NTAG(TAG_Nothing), NTAG(TAG_Nothing)});
  HeffT3 v_t_242 = (g_heff_2esyntax_2efmt_2elex_2elexGo_24cpr(heff_dup(v_src_240), v_t_241, NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil)));
  {
    V v_field_244 = v_t_242.f[1];
    heff_drop(v_t_242.f[0]);
    heff_drop(v_t_242.f[2]);
    V v_t_246 = v_field_244;
    switch (heff_tag_of(v_t_246)) {
    case TAG_Nil: {
      V v_t_247 = heff_rec_n(7, shape_i__line__lineStart__first__tok__err__cmt, (V[]){MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_True), NTAG(TAG_Nothing), NTAG(TAG_Nothing), NTAG(TAG_Nothing)});
      HeffT3 v_t_248 = (g_heff_2esyntax_2efmt_2elex_2elexGo_24cpr(v_src_240, v_t_247, NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil)));
      {
        V v_field_249 = v_t_248.f[0];
        heff_drop(v_t_248.f[1]);
        heff_drop(v_t_248.f[2]);
        return ({ V a_0 = ((V)&g_heff_2ebuild_2eproject_2epackageLit_24cpr_str0); V a_1 = ((V)&g_heff_2ebuild_2eproject_2epackageLit_24cpr_str1); V b_2 = heff_arrayFromList(v_field_249); V a_3 = MK_INT(0LL); V a_4 = NTAG(TAG_Nothing); HeffT2 r_ = (g_heff_2ebuild_2eproject_2edeclsGo_24cpr(a_0, a_1, b_2, a_3, a_4)); heff_drop(b_2); r_; });
      }
    }
    case TAG_Cons: {
      V v_e_2412 = heff_field(v_t_246, 0);
      heff_take_n(v_t_246, 1ULL, 2);
      heff_drop(v_src_240);
      V v_start_2414 = heff_take_field(v_e_2412, 0);
      V v_msg_2415 = heff_get_n(v_e_2412, 2, 3);
      V v_f_2416 = heff_rec_n(2, shape_at__msg, (V[]){v_start_2414, v_msg_2415});
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2416}});
    }
    default: return ((HeffT2){{heff_nomatch(v_t_246)}});
    }
  }
}
Clo g_heff_2ebuild_2eproject_2eallOf_24s622475081x394218744_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eproject_2eallOf_24s622475081x394218744_entry, 1, 0};

V g_heff_2ebuild_2eproject_2eallOf_24s622475081x394218744(V v_x2_240) {
top: ;
  HeffT2 v_t_241 = (g_heff_2ebuild_2eproject_2eallOf_24s622475081x394218744_24cpr(v_x2_240));
  {
    V v_field_243 = v_t_241.f[1];
    int64_t v_tag_242 = ((int64_t)v_t_241.f[0]);
    if ((v_tag_242 == ((int64_t)0ULL))) {
      return heff_tag_n(TAG_Left, 1, (V[]){v_field_243});
    } else {
      return heff_tag_n(TAG_Right, 1, (V[]){v_field_243});
    }
  }
}
V g_heff_2ebuild_2eproject_2eallOf_24s622475081x394218744_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eproject_2eallOf_24s622475081x394218744(a[0]);
}
Clo g_heff_2ebuild_2eproject_2eallOf_24s1507277824x59055423_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eproject_2eallOf_24s1507277824x59055423_entry, 1, 0};

V g_heff_2ebuild_2eproject_2eallOf_24s1507277824x59055423(V v_x2_240) {
top: ;
  HeffT2 v_t_241 = (g_heff_2ebuild_2eproject_2eallOf_24s1507277824x59055423_24cpr(v_x2_240));
  {
    V v_field_243 = v_t_241.f[1];
    int64_t v_tag_242 = ((int64_t)v_t_241.f[0]);
    if ((v_tag_242 == ((int64_t)0ULL))) {
      return heff_tag_n(TAG_Left, 1, (V[]){v_field_243});
    } else {
      return heff_tag_n(TAG_Right, 1, (V[]){v_field_243});
    }
  }
}
V g_heff_2ebuild_2eproject_2eallOf_24s1507277824x59055423_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eproject_2eallOf_24s1507277824x59055423(a[0]);
}
HEFF_LIT(g_heff_2ebuild_2eproject_2ebuildOf_24rec0_str0, 5, "ships");
V g_heff_2ebuild_2eproject_2ebuildOf_24rec0_lam0(V self, V *args); static Clo g_heff_2ebuild_2eproject_2ebuildOf_24rec0_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eproject_2ebuildOf_24rec0_lam0, 1, 0};

static V g_heff_2ebuild_2eproject_2ebuildOf_24rec0_val;
static HEFF_ONCE g_heff_2ebuild_2eproject_2ebuildOf_24rec0_st;
static V g_heff_2ebuild_2eproject_2ebuildOf_24rec0_init(void) {
  return heff_rec_n(2, shape_name__left, (V[]){((V)&g_heff_2ebuild_2eproject_2ebuildOf_24rec0_str0), heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2ebuild_2eproject_2ebuildOf_24rec0_lam0_clo)})});
}
V g_heff_2ebuild_2eproject_2ebuildOf_24rec0_get(void) {
  if (HEFF_DONE(g_heff_2ebuild_2eproject_2ebuildOf_24rec0_st)) return g_heff_2ebuild_2eproject_2ebuildOf_24rec0_val;
  return heff_global(&g_heff_2ebuild_2eproject_2ebuildOf_24rec0_val, &g_heff_2ebuild_2eproject_2ebuildOf_24rec0_st, g_heff_2ebuild_2eproject_2ebuildOf_24rec0_init);
}
V g_heff_2ebuild_2eproject_2ebuildOf_24rec0_lam0(V self, V *args) {
  V v_t_240 = args[0];
  return heff_tag_n(TAG_LList, 2, (V[]){NTAG(TAG_Nil), v_t_240});
}
HEFF_LIT(g_heff_2ebuild_2eproject_2ebuildOf_24rec2_str0, 11, "includeDirs");
V g_heff_2ebuild_2eproject_2ebuildOf_24rec2_lam0(V self, V *args); static Clo g_heff_2ebuild_2eproject_2ebuildOf_24rec2_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eproject_2ebuildOf_24rec2_lam0, 1, 0};

static V g_heff_2ebuild_2eproject_2ebuildOf_24rec2_val;
static HEFF_ONCE g_heff_2ebuild_2eproject_2ebuildOf_24rec2_st;
static V g_heff_2ebuild_2eproject_2ebuildOf_24rec2_init(void) {
  return heff_rec_n(2, shape_name__left, (V[]){((V)&g_heff_2ebuild_2eproject_2ebuildOf_24rec2_str0), heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2ebuild_2eproject_2ebuildOf_24rec2_lam0_clo)})});
}
V g_heff_2ebuild_2eproject_2ebuildOf_24rec2_get(void) {
  if (HEFF_DONE(g_heff_2ebuild_2eproject_2ebuildOf_24rec2_st)) return g_heff_2ebuild_2eproject_2ebuildOf_24rec2_val;
  return heff_global(&g_heff_2ebuild_2eproject_2ebuildOf_24rec2_val, &g_heff_2ebuild_2eproject_2ebuildOf_24rec2_st, g_heff_2ebuild_2eproject_2ebuildOf_24rec2_init);
}
V g_heff_2ebuild_2eproject_2ebuildOf_24rec2_lam0(V self, V *args) {
  V v_t_240 = args[0];
  return heff_tag_n(TAG_LList, 2, (V[]){NTAG(TAG_Nil), v_t_240});
}
HEFF_LIT(g_heff_2ebuild_2eproject_2ebuildOf_str0, 7, "backend");
HEFF_LIT(g_heff_2ebuild_2eproject_2ebuildOf_str1, 3, "run");
HEFF_LIT(g_heff_2ebuild_2eproject_2ebuildOf_str2, 25, "expected a record `{...}`");
HEFF_LIT(g_heff_2ebuild_2eproject_2ebuildOf_str3, 25, "expected a record `{...}`");
HEFF_LIT(g_heff_2ebuild_2eproject_2ebuildOf_str4, 25, "expected a record `{...}`");
HEFF_LIT(g_heff_2ebuild_2eproject_2ebuildOf_str5, 25, "expected a record `{...}`");
HEFF_LIT(g_heff_2ebuild_2eproject_2ebuildOf_str6, 25, "expected a record `{...}`");
HEFF_LIT(g_heff_2ebuild_2eproject_2ebuildOf_str7, 25, "expected a record `{...}`");
HEFF_LIT(g_heff_2ebuild_2eproject_2ebuildOf_str8, 29, "expected a backend: C or Page");
HEFF_LIT(g_heff_2ebuild_2eproject_2ebuildOf_str9, 1, "C");
HEFF_LIT(g_heff_2ebuild_2eproject_2ebuildOf_str10, 1, "c");
HEFF_LIT(g_heff_2ebuild_2eproject_2ebuildOf_str11, 4, "Page");
HEFF_LIT(g_heff_2ebuild_2eproject_2ebuildOf_str12, 4, "page");
HEFF_LIT(g_heff_2ebuild_2eproject_2ebuildOf_str13, 11, "no backend ");
HEFF_LIT(g_heff_2ebuild_2eproject_2ebuildOf_str14, 11, ": C or Page");
HEFF_LIT(g_heff_2ebuild_2eproject_2ebuildOf_str15, 29, "expected a backend: C or Page");
HEFF_LIT(g_heff_2ebuild_2eproject_2ebuildOf_str16, 29, "expected a backend: C or Page");
HEFF_LIT(g_heff_2ebuild_2eproject_2ebuildOf_str17, 22, "expected True or False");
HEFF_LIT(g_heff_2ebuild_2eproject_2ebuildOf_str18, 4, "True");
HEFF_LIT(g_heff_2ebuild_2eproject_2ebuildOf_str19, 5, "False");
HEFF_LIT(g_heff_2ebuild_2eproject_2ebuildOf_str20, 22, "expected True or False");
HEFF_LIT(g_heff_2ebuild_2eproject_2ebuildOf_str21, 22, "expected True or False");
HEFF_LIT(g_heff_2ebuild_2eproject_2ebuildOf_str22, 22, "expected True or False");
HEFF_LIT(g_heff_2ebuild_2eproject_2ebuildOf_str23, 25, "expected a record `{...}`");
Clo g_heff_2ebuild_2eproject_2ebuildOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eproject_2ebuildOf_entry, 1, 0};

V g_heff_2ebuild_2eproject_2ebuildOf(V v_x_240) {
top: ;
  V v_t_241 = heff_rec_n(2, shape_name__left, (V[]){((V)&g_heff_2ebuild_2eproject_2ebuildOf_str0), NTAG(TAG_Nothing)});
  V v_t_242 = heff_rec_n(2, shape_name__left, (V[]){((V)&g_heff_2ebuild_2eproject_2ebuildOf_str1), NTAG(TAG_Nothing)});
  V v_t_243 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(g_heff_2ebuild_2eproject_2ebuildOf_24rec3_get()), NTAG(TAG_Nil)});
  V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(g_heff_2ebuild_2eproject_2ebuildOf_24rec1_get()), heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(g_heff_2ebuild_2eproject_2ebuildOf_24rec2_get()), v_t_243})});
  V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_242, heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(g_heff_2ebuild_2eproject_2ebuildOf_24rec0_get()), v_t_244})});
  HeffT2 v_t_246 = (g_heff_2ebuild_2eproject_2efieldsAre_24cpr(heff_tag_n(TAG_Cons, 2, (V[]){v_t_241, v_t_245}), v_x_240));
  {
    V v_field_248 = v_t_246.f[1];
    int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
    if ((v_tag_247 == ((int64_t)0ULL))) {
      V v_p_249 = v_field_248;
      return heff_tag_n(TAG_Left, 1, (V[]){v_p_249});
    } else {
      V v_it1_2410 = v_field_248;
      switch (heff_tag_of(v_it1_2410)) {
      case TAG_Nil: {
        V v_t_2419;
        switch (heff_tag_of(v_x_240)) {
        case TAG_LStr: {
          V v_t_2412 = heff_field(v_x_240, 1);
          v_t_2419 = heff_dup(v_t_2412);
          break;
        }
        case TAG_LTag: {
          V v_t_2414 = heff_field(v_x_240, 1);
          v_t_2419 = heff_dup(v_t_2414);
          break;
        }
        case TAG_LList: {
          V v_t_2416 = heff_field(v_x_240, 1);
          v_t_2419 = heff_dup(v_t_2416);
          break;
        }
        case TAG_LRec: {
          V v_t_2418 = heff_field(v_x_240, 1);
          v_t_2419 = heff_dup(v_t_2418);
          break;
        }
        default: heff_nomatch(v_x_240);
        }
        V v_t_2420 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2419, 2, 7), ((V)&g_heff_2ebuild_2eproject_2ebuildOf_str2)});
        return heff_tag_n(TAG_Left, 1, (V[]){v_t_2420});
      }
      case TAG_Cons: {
        V v_b_2421 = heff_field(v_it1_2410, 0);
        V v_it12_2422 = heff_field(v_it1_2410, 1);
        heff_take_n(v_it1_2410, 3ULL, 2);
        switch (heff_tag_of(v_it12_2422)) {
        case TAG_Nil: {
          heff_drop(v_b_2421);
          V v_t_2431;
          switch (heff_tag_of(v_x_240)) {
          case TAG_LStr: {
            V v_t_2424 = heff_field(v_x_240, 1);
            v_t_2431 = heff_dup(v_t_2424);
            break;
          }
          case TAG_LTag: {
            V v_t_2426 = heff_field(v_x_240, 1);
            v_t_2431 = heff_dup(v_t_2426);
            break;
          }
          case TAG_LList: {
            V v_t_2428 = heff_field(v_x_240, 1);
            v_t_2431 = heff_dup(v_t_2428);
            break;
          }
          case TAG_LRec: {
            V v_t_2430 = heff_field(v_x_240, 1);
            v_t_2431 = heff_dup(v_t_2430);
            break;
          }
          default: heff_nomatch(v_x_240);
          }
          V v_t_2432 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2431, 2, 7), ((V)&g_heff_2ebuild_2eproject_2ebuildOf_str3)});
          return heff_tag_n(TAG_Left, 1, (V[]){v_t_2432});
        }
        case TAG_Cons: {
          V v_r_2433 = heff_field(v_it12_2422, 0);
          V v_it122_2434 = heff_field(v_it12_2422, 1);
          heff_take_n(v_it12_2422, 3ULL, 2);
          switch (heff_tag_of(v_it122_2434)) {
          case TAG_Nil: {
            heff_drop(v_b_2421);
            heff_drop(v_r_2433);
            V v_t_2443;
            switch (heff_tag_of(v_x_240)) {
            case TAG_LStr: {
              V v_t_2436 = heff_field(v_x_240, 1);
              v_t_2443 = heff_dup(v_t_2436);
              break;
            }
            case TAG_LTag: {
              V v_t_2438 = heff_field(v_x_240, 1);
              v_t_2443 = heff_dup(v_t_2438);
              break;
            }
            case TAG_LList: {
              V v_t_2440 = heff_field(v_x_240, 1);
              v_t_2443 = heff_dup(v_t_2440);
              break;
            }
            case TAG_LRec: {
              V v_t_2442 = heff_field(v_x_240, 1);
              v_t_2443 = heff_dup(v_t_2442);
              break;
            }
            default: heff_nomatch(v_x_240);
            }
            V v_t_2444 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2443, 2, 7), ((V)&g_heff_2ebuild_2eproject_2ebuildOf_str4)});
            return heff_tag_n(TAG_Left, 1, (V[]){v_t_2444});
          }
          case TAG_Cons: {
            V v_s_2445 = heff_field(v_it122_2434, 0);
            V v_it1222_2446 = heff_field(v_it122_2434, 1);
            heff_take_n(v_it122_2434, 3ULL, 2);
            switch (heff_tag_of(v_it1222_2446)) {
            case TAG_Nil: {
              heff_drop(v_b_2421);
              heff_drop(v_r_2433);
              heff_drop(v_s_2445);
              V v_t_2455;
              switch (heff_tag_of(v_x_240)) {
              case TAG_LStr: {
                V v_t_2448 = heff_field(v_x_240, 1);
                v_t_2455 = heff_dup(v_t_2448);
                break;
              }
              case TAG_LTag: {
                V v_t_2450 = heff_field(v_x_240, 1);
                v_t_2455 = heff_dup(v_t_2450);
                break;
              }
              case TAG_LList: {
                V v_t_2452 = heff_field(v_x_240, 1);
                v_t_2455 = heff_dup(v_t_2452);
                break;
              }
              case TAG_LRec: {
                V v_t_2454 = heff_field(v_x_240, 1);
                v_t_2455 = heff_dup(v_t_2454);
                break;
              }
              default: heff_nomatch(v_x_240);
              }
              V v_t_2456 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2455, 2, 7), ((V)&g_heff_2ebuild_2eproject_2ebuildOf_str5)});
              return heff_tag_n(TAG_Left, 1, (V[]){v_t_2456});
            }
            case TAG_Cons: {
              V v_f_2457 = heff_field(v_it1222_2446, 0);
              V v_it12222_2458 = heff_field(v_it1222_2446, 1);
              heff_take_n(v_it1222_2446, 3ULL, 2);
              switch (heff_tag_of(v_it12222_2458)) {
              case TAG_Nil: {
                heff_drop(v_b_2421);
                heff_drop(v_r_2433);
                heff_drop(v_s_2445);
                heff_drop(v_f_2457);
                V v_t_2467;
                switch (heff_tag_of(v_x_240)) {
                case TAG_LStr: {
                  V v_t_2460 = heff_field(v_x_240, 1);
                  v_t_2467 = heff_dup(v_t_2460);
                  break;
                }
                case TAG_LTag: {
                  V v_t_2462 = heff_field(v_x_240, 1);
                  v_t_2467 = heff_dup(v_t_2462);
                  break;
                }
                case TAG_LList: {
                  V v_t_2464 = heff_field(v_x_240, 1);
                  v_t_2467 = heff_dup(v_t_2464);
                  break;
                }
                case TAG_LRec: {
                  V v_t_2466 = heff_field(v_x_240, 1);
                  v_t_2467 = heff_dup(v_t_2466);
                  break;
                }
                default: heff_nomatch(v_x_240);
                }
                V v_t_2468 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2467, 2, 7), ((V)&g_heff_2ebuild_2eproject_2ebuildOf_str6)});
                return heff_tag_n(TAG_Left, 1, (V[]){v_t_2468});
              }
              case TAG_Cons: {
                V v_i_2469 = heff_field(v_it12222_2458, 0);
                V v_it122222_2470 = heff_field(v_it12222_2458, 1);
                heff_take_n(v_it12222_2458, 3ULL, 2);
                switch (heff_tag_of(v_it122222_2470)) {
                case TAG_Nil: {
                  heff_drop(v_b_2421);
                  heff_drop(v_r_2433);
                  heff_drop(v_s_2445);
                  heff_drop(v_f_2457);
                  heff_drop(v_i_2469);
                  V v_t_2479;
                  switch (heff_tag_of(v_x_240)) {
                  case TAG_LStr: {
                    V v_t_2472 = heff_field(v_x_240, 1);
                    v_t_2479 = heff_dup(v_t_2472);
                    break;
                  }
                  case TAG_LTag: {
                    V v_t_2474 = heff_field(v_x_240, 1);
                    v_t_2479 = heff_dup(v_t_2474);
                    break;
                  }
                  case TAG_LList: {
                    V v_t_2476 = heff_field(v_x_240, 1);
                    v_t_2479 = heff_dup(v_t_2476);
                    break;
                  }
                  case TAG_LRec: {
                    V v_t_2478 = heff_field(v_x_240, 1);
                    v_t_2479 = heff_dup(v_t_2478);
                    break;
                  }
                  default: heff_nomatch(v_x_240);
                  }
                  V v_t_2480 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2479, 2, 7), ((V)&g_heff_2ebuild_2eproject_2ebuildOf_str7)});
                  return heff_tag_n(TAG_Left, 1, (V[]){v_t_2480});
                }
                case TAG_Cons: {
                  V v_l_2481 = heff_field(v_it122222_2470, 0);
                  V v_it1222222_2482 = heff_field(v_it122222_2470, 1);
                  heff_take_n(v_it122222_2470, 3ULL, 2);
                  switch (heff_tag_of(v_it1222222_2482)) {
                  case TAG_Nil: {
                    V v_b_2483 = v_b_2421;
                    V v_r_2484 = v_r_2433;
                    V v_s_2485 = v_s_2445;
                    V v_f_2486 = v_f_2457;
                    V v_i_2487 = v_i_2469;
                    V v_l_2488 = v_l_2481;
                    V v_x_2489 = v_b_2483;
                    V v_t_24130;
                    switch (heff_tag_of(v_x_2489)) {
                    case TAG_LStr: {
                      V v_t_24100;
                      switch (heff_tag_of(v_x_2489)) {
                      case TAG_LStr: {
                        V v_t_2493 = heff_field(v_x_2489, 1);
                        heff_take_n(v_x_2489, 2ULL, 2);
                        v_t_24100 = v_t_2493;
                        break;
                      }
                      case TAG_LTag: {
                        V v_t_2495 = heff_field(v_x_2489, 1);
                        heff_take_n(v_x_2489, 2ULL, 2);
                        v_t_24100 = v_t_2495;
                        break;
                      }
                      case TAG_LList: {
                        V v_t_2497 = heff_field(v_x_2489, 1);
                        heff_take_n(v_x_2489, 2ULL, 2);
                        v_t_24100 = v_t_2497;
                        break;
                      }
                      case TAG_LRec: {
                        V v_t_2499 = heff_field(v_x_2489, 1);
                        heff_take_n(v_x_2489, 2ULL, 2);
                        v_t_24100 = v_t_2499;
                        break;
                      }
                      default: heff_nomatch(v_x_2489);
                      }
                      V v_t_24101 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_24100, 2, 7), ((V)&g_heff_2ebuild_2eproject_2ebuildOf_str8)});
                      v_t_24130 = heff_tag_n(TAG_Left, 1, (V[]){v_t_24101});
                      break;
                    }
                    case TAG_LTag: {
                      V v_x1_24102 = heff_field(v_x_2489, 0);
                      V v_t_24103 = heff_field(v_x_2489, 1);
                      heff_take_n(v_x_2489, 3ULL, 2);
                      if (heff_strEq_c_lent(v_x1_24102, ((V)&g_heff_2ebuild_2eproject_2ebuildOf_str9), 2)) {
                        heff_drop(v_x1_24102);
                        heff_drop_rec(v_t_24103, 7);
                        v_t_24130 = heff_tag_n(TAG_Right, 1, (V[]){((V)&g_heff_2ebuild_2eproject_2ebuildOf_str10)});
                      } else {
                        if (heff_strEq_c_lent(v_x1_24102, ((V)&g_heff_2ebuild_2eproject_2ebuildOf_str11), 2)) {
                          heff_drop(v_x1_24102);
                          heff_drop_rec(v_t_24103, 7);
                          v_t_24130 = heff_tag_n(TAG_Right, 1, (V[]){((V)&g_heff_2ebuild_2eproject_2ebuildOf_str12)});
                        } else {
                          V v_t_24104 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2eproject_2ebuildOf_str13), v_x1_24102), ((V)&g_heff_2ebuild_2eproject_2ebuildOf_str14));
                          V v_t_24105 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_24103, 2, 7), v_t_24104});
                          v_t_24130 = heff_tag_n(TAG_Left, 1, (V[]){v_t_24105});
                        }
                      }
                      break;
                    }
                    case TAG_LList: {
                      V v_t_24116;
                      switch (heff_tag_of(v_x_2489)) {
                      case TAG_LStr: {
                        V v_t_24109 = heff_field(v_x_2489, 1);
                        heff_take_n(v_x_2489, 2ULL, 2);
                        v_t_24116 = v_t_24109;
                        break;
                      }
                      case TAG_LTag: {
                        V v_t_24111 = heff_field(v_x_2489, 1);
                        heff_take_n(v_x_2489, 2ULL, 2);
                        v_t_24116 = v_t_24111;
                        break;
                      }
                      case TAG_LList: {
                        V v_t_24113 = heff_field(v_x_2489, 1);
                        heff_take_n(v_x_2489, 2ULL, 2);
                        v_t_24116 = v_t_24113;
                        break;
                      }
                      case TAG_LRec: {
                        V v_t_24115 = heff_field(v_x_2489, 1);
                        heff_take_n(v_x_2489, 2ULL, 2);
                        v_t_24116 = v_t_24115;
                        break;
                      }
                      default: heff_nomatch(v_x_2489);
                      }
                      V v_t_24117 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_24116, 2, 7), ((V)&g_heff_2ebuild_2eproject_2ebuildOf_str15)});
                      v_t_24130 = heff_tag_n(TAG_Left, 1, (V[]){v_t_24117});
                      break;
                    }
                    case TAG_LRec: {
                      V v_t_24128;
                      switch (heff_tag_of(v_x_2489)) {
                      case TAG_LStr: {
                        V v_t_24121 = heff_field(v_x_2489, 1);
                        heff_take_n(v_x_2489, 2ULL, 2);
                        v_t_24128 = v_t_24121;
                        break;
                      }
                      case TAG_LTag: {
                        V v_t_24123 = heff_field(v_x_2489, 1);
                        heff_take_n(v_x_2489, 2ULL, 2);
                        v_t_24128 = v_t_24123;
                        break;
                      }
                      case TAG_LList: {
                        V v_t_24125 = heff_field(v_x_2489, 1);
                        heff_take_n(v_x_2489, 2ULL, 2);
                        v_t_24128 = v_t_24125;
                        break;
                      }
                      case TAG_LRec: {
                        V v_t_24127 = heff_field(v_x_2489, 1);
                        heff_take_n(v_x_2489, 2ULL, 2);
                        v_t_24128 = v_t_24127;
                        break;
                      }
                      default: heff_nomatch(v_x_2489);
                      }
                      V v_t_24129 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_24128, 2, 7), ((V)&g_heff_2ebuild_2eproject_2ebuildOf_str16)});
                      v_t_24130 = heff_tag_n(TAG_Left, 1, (V[]){v_t_24129});
                      break;
                    }
                    default: heff_nomatch(v_x_2489);
                    }
                    switch (heff_tag_of(v_t_24130)) {
                    case TAG_Left: {
                      V v_p_24131 = heff_field(v_t_24130, 0);
                      V v_ru_24t_24130_24Left = heff_take_reuse_n(v_t_24130, 1ULL, 1);
                      heff_drop(v_r_2484);
                      heff_drop(v_s_2485);
                      heff_drop(v_f_2486);
                      heff_drop(v_i_2487);
                      heff_drop(v_l_2488);
                      return heff_tag_re_n(v_ru_24t_24130_24Left, TAG_Left, 1, 1ULL, (V[]){v_p_24131});
                    }
                    case TAG_Right: {
                      V v_backend_24132 = heff_field(v_t_24130, 0);
                      V v_ru_24t_24130_24Right = heff_take_reuse_n(v_t_24130, 1ULL, 1);
                      HeffT2 v_t_24133 = ({ V a_0 = v_r_2484; HeffT2 r_ = (g_heff_2ebuild_2eproject_2estr_24cpr(a_0)); heff_drop(v_r_2484); r_; });
                      {
                        V v_field_24135 = v_t_24133.f[1];
                        int64_t v_tag_24134 = ((int64_t)v_t_24133.f[0]);
                        if ((v_tag_24134 == ((int64_t)0ULL))) {
                          heff_drop(v_s_2485);
                          heff_drop(v_f_2486);
                          heff_drop(v_i_2487);
                          heff_drop(v_l_2488);
                          heff_drop(v_backend_24132);
                          heff_drop_cell(v_ru_24t_24130_24Right, 1);
                          V v_p_24136 = v_field_24135;
                          return heff_tag_n(TAG_Left, 1, (V[]){v_p_24136});
                        } else {
                          V v_run_24137 = v_field_24135;
                          HeffT2 v_t_24138 = ({ V a_0 = v_s_2485; HeffT2 r_ = (g_heff_2ebuild_2eproject_2eitems_24cpr(a_0)); heff_drop(v_s_2485); r_; });
                          {
                            V v_field_24140 = v_t_24138.f[1];
                            int64_t v_tag_24139 = ((int64_t)v_t_24138.f[0]);
                            if ((v_tag_24139 == ((int64_t)0ULL))) {
                              heff_drop(v_f_2486);
                              heff_drop(v_i_2487);
                              heff_drop(v_l_2488);
                              heff_drop(v_backend_24132);
                              heff_drop_cell(v_ru_24t_24130_24Right, 1);
                              heff_drop(v_run_24137);
                              V v_p_24141 = v_field_24140;
                              return heff_tag_n(TAG_Left, 1, (V[]){v_p_24141});
                            } else {
                              V v_xs_24142 = v_field_24140;
                              HeffT2 v_t_24143 = (g_heff_2ebuild_2eproject_2eallOf_24s622475081x394218744_24cpr(v_xs_24142));
                              {
                                V v_field_24145 = v_t_24143.f[1];
                                int64_t v_tag_24144 = ((int64_t)v_t_24143.f[0]);
                                if ((v_tag_24144 == ((int64_t)0ULL))) {
                                  heff_drop(v_f_2486);
                                  heff_drop(v_i_2487);
                                  heff_drop(v_l_2488);
                                  heff_drop(v_backend_24132);
                                  heff_drop_cell(v_ru_24t_24130_24Right, 1);
                                  heff_drop(v_run_24137);
                                  V v_p_24146 = v_field_24145;
                                  return heff_tag_n(TAG_Left, 1, (V[]){v_p_24146});
                                } else {
                                  V v_ships_24147 = v_field_24145;
                                  V v_x_24148 = v_f_2486;
                                  V v_t_24197;
                                  switch (heff_tag_of(v_x_24148)) {
                                  case TAG_LStr: {
                                    heff_drop_cell(v_ru_24t_24130_24Right, 1);
                                    V v_t_24159;
                                    switch (heff_tag_of(v_x_24148)) {
                                    case TAG_LStr: {
                                      V v_t_24152 = heff_field(v_x_24148, 1);
                                      heff_take_n(v_x_24148, 2ULL, 2);
                                      v_t_24159 = v_t_24152;
                                      break;
                                    }
                                    case TAG_LTag: {
                                      V v_t_24154 = heff_field(v_x_24148, 1);
                                      heff_take_n(v_x_24148, 2ULL, 2);
                                      v_t_24159 = v_t_24154;
                                      break;
                                    }
                                    case TAG_LList: {
                                      V v_t_24156 = heff_field(v_x_24148, 1);
                                      heff_take_n(v_x_24148, 2ULL, 2);
                                      v_t_24159 = v_t_24156;
                                      break;
                                    }
                                    case TAG_LRec: {
                                      V v_t_24158 = heff_field(v_x_24148, 1);
                                      heff_take_n(v_x_24148, 2ULL, 2);
                                      v_t_24159 = v_t_24158;
                                      break;
                                    }
                                    default: heff_nomatch(v_x_24148);
                                    }
                                    V v_t_24160 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_24159, 2, 7), ((V)&g_heff_2ebuild_2eproject_2ebuildOf_str17)});
                                    v_t_24197 = heff_tag_n(TAG_Left, 1, (V[]){v_t_24160});
                                    break;
                                  }
                                  case TAG_LTag: {
                                    V v_x1_24161 = heff_dup(heff_field(v_x_24148, 0));
                                    if (heff_strEq_c_lent(v_x1_24161, ((V)&g_heff_2ebuild_2eproject_2ebuildOf_str18), 2)) {
                                      heff_drop_tag(v_x_24148, 2);
                                      heff_drop(v_x1_24161);
                                      v_t_24197 = heff_tag_at_n(v_ru_24t_24130_24Right, TAG_Right, 1, (V[]){NTAG(TAG_True)});
                                    } else {
                                      if (heff_strEq_c(v_x1_24161, ((V)&g_heff_2ebuild_2eproject_2ebuildOf_str19))) {
                                        heff_drop_tag(v_x_24148, 2);
                                        v_t_24197 = heff_tag_at_n(v_ru_24t_24130_24Right, TAG_Right, 1, (V[]){NTAG(TAG_False)});
                                      } else {
                                        heff_drop_cell(v_ru_24t_24130_24Right, 1);
                                        V v_t_24171;
                                        switch (heff_tag_of(v_x_24148)) {
                                        case TAG_LStr: {
                                          V v_t_24164 = heff_field(v_x_24148, 1);
                                          heff_take_n(v_x_24148, 2ULL, 2);
                                          v_t_24171 = v_t_24164;
                                          break;
                                        }
                                        case TAG_LTag: {
                                          V v_t_24166 = heff_field(v_x_24148, 1);
                                          heff_take_n(v_x_24148, 2ULL, 2);
                                          v_t_24171 = v_t_24166;
                                          break;
                                        }
                                        case TAG_LList: {
                                          V v_t_24168 = heff_field(v_x_24148, 1);
                                          heff_take_n(v_x_24148, 2ULL, 2);
                                          v_t_24171 = v_t_24168;
                                          break;
                                        }
                                        case TAG_LRec: {
                                          V v_t_24170 = heff_field(v_x_24148, 1);
                                          heff_take_n(v_x_24148, 2ULL, 2);
                                          v_t_24171 = v_t_24170;
                                          break;
                                        }
                                        default: heff_nomatch(v_x_24148);
                                        }
                                        V v_t_24172 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_24171, 2, 7), ((V)&g_heff_2ebuild_2eproject_2ebuildOf_str20)});
                                        v_t_24197 = heff_tag_n(TAG_Left, 1, (V[]){v_t_24172});
                                      }
                                    }
                                    break;
                                  }
                                  case TAG_LList: {
                                    heff_drop_cell(v_ru_24t_24130_24Right, 1);
                                    V v_t_24183;
                                    switch (heff_tag_of(v_x_24148)) {
                                    case TAG_LStr: {
                                      V v_t_24176 = heff_field(v_x_24148, 1);
                                      heff_take_n(v_x_24148, 2ULL, 2);
                                      v_t_24183 = v_t_24176;
                                      break;
                                    }
                                    case TAG_LTag: {
                                      V v_t_24178 = heff_field(v_x_24148, 1);
                                      heff_take_n(v_x_24148, 2ULL, 2);
                                      v_t_24183 = v_t_24178;
                                      break;
                                    }
                                    case TAG_LList: {
                                      V v_t_24180 = heff_field(v_x_24148, 1);
                                      heff_take_n(v_x_24148, 2ULL, 2);
                                      v_t_24183 = v_t_24180;
                                      break;
                                    }
                                    case TAG_LRec: {
                                      V v_t_24182 = heff_field(v_x_24148, 1);
                                      heff_take_n(v_x_24148, 2ULL, 2);
                                      v_t_24183 = v_t_24182;
                                      break;
                                    }
                                    default: heff_nomatch(v_x_24148);
                                    }
                                    V v_t_24184 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_24183, 2, 7), ((V)&g_heff_2ebuild_2eproject_2ebuildOf_str21)});
                                    v_t_24197 = heff_tag_n(TAG_Left, 1, (V[]){v_t_24184});
                                    break;
                                  }
                                  case TAG_LRec: {
                                    heff_drop_cell(v_ru_24t_24130_24Right, 1);
                                    V v_t_24195;
                                    switch (heff_tag_of(v_x_24148)) {
                                    case TAG_LStr: {
                                      V v_t_24188 = heff_field(v_x_24148, 1);
                                      heff_take_n(v_x_24148, 2ULL, 2);
                                      v_t_24195 = v_t_24188;
                                      break;
                                    }
                                    case TAG_LTag: {
                                      V v_t_24190 = heff_field(v_x_24148, 1);
                                      heff_take_n(v_x_24148, 2ULL, 2);
                                      v_t_24195 = v_t_24190;
                                      break;
                                    }
                                    case TAG_LList: {
                                      V v_t_24192 = heff_field(v_x_24148, 1);
                                      heff_take_n(v_x_24148, 2ULL, 2);
                                      v_t_24195 = v_t_24192;
                                      break;
                                    }
                                    case TAG_LRec: {
                                      V v_t_24194 = heff_field(v_x_24148, 1);
                                      heff_take_n(v_x_24148, 2ULL, 2);
                                      v_t_24195 = v_t_24194;
                                      break;
                                    }
                                    default: heff_nomatch(v_x_24148);
                                    }
                                    V v_t_24196 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_24195, 2, 7), ((V)&g_heff_2ebuild_2eproject_2ebuildOf_str22)});
                                    v_t_24197 = heff_tag_n(TAG_Left, 1, (V[]){v_t_24196});
                                    break;
                                  }
                                  default: heff_nomatch(v_x_24148);
                                  }
                                  switch (heff_tag_of(v_t_24197)) {
                                  case TAG_Left: {
                                    V v_p_24198 = heff_field(v_t_24197, 0);
                                    V v_ru_24t_24197_24Left = heff_take_reuse_n(v_t_24197, 1ULL, 1);
                                    heff_drop(v_i_2487);
                                    heff_drop(v_l_2488);
                                    heff_drop(v_backend_24132);
                                    heff_drop(v_run_24137);
                                    heff_drop(v_ships_24147);
                                    return heff_tag_re_n(v_ru_24t_24197_24Left, TAG_Left, 1, 1ULL, (V[]){v_p_24198});
                                  }
                                  case TAG_Right: {
                                    V v_fuel_24199 = heff_field(v_t_24197, 0);
                                    V v_ru_24t_24197_24Right = heff_take_reuse_n(v_t_24197, 1ULL, 1);
                                    HeffT2 v_t_24200 = ({ V a_0 = v_i_2487; HeffT2 r_ = (g_heff_2ebuild_2eproject_2eitems_24cpr(a_0)); heff_drop(v_i_2487); r_; });
                                    {
                                      V v_field_24202 = v_t_24200.f[1];
                                      int64_t v_tag_24201 = ((int64_t)v_t_24200.f[0]);
                                      if ((v_tag_24201 == ((int64_t)0ULL))) {
                                        heff_drop(v_l_2488);
                                        heff_drop(v_backend_24132);
                                        heff_drop(v_run_24137);
                                        heff_drop(v_ships_24147);
                                        heff_drop(v_fuel_24199);
                                        heff_drop_cell(v_ru_24t_24197_24Right, 1);
                                        V v_p_24203 = v_field_24202;
                                        return heff_tag_n(TAG_Left, 1, (V[]){v_p_24203});
                                      } else {
                                        V v_xs_24204 = v_field_24202;
                                        HeffT2 v_t_24205 = (g_heff_2ebuild_2eproject_2eallOf_24s1507277824x59055423_24cpr(v_xs_24204));
                                        {
                                          V v_field_24207 = v_t_24205.f[1];
                                          int64_t v_tag_24206 = ((int64_t)v_t_24205.f[0]);
                                          if ((v_tag_24206 == ((int64_t)0ULL))) {
                                            heff_drop(v_l_2488);
                                            heff_drop(v_backend_24132);
                                            heff_drop(v_run_24137);
                                            heff_drop(v_ships_24147);
                                            heff_drop(v_fuel_24199);
                                            heff_drop_cell(v_ru_24t_24197_24Right, 1);
                                            V v_p_24208 = v_field_24207;
                                            return heff_tag_n(TAG_Left, 1, (V[]){v_p_24208});
                                          } else {
                                            V v_includeDirs_24209 = v_field_24207;
                                            HeffT2 v_t_24210 = ({ V a_0 = v_l_2488; HeffT2 r_ = (g_heff_2ebuild_2eproject_2eitems_24cpr(a_0)); heff_drop(v_l_2488); r_; });
                                            {
                                              V v_field_24212 = v_t_24210.f[1];
                                              int64_t v_tag_24211 = ((int64_t)v_t_24210.f[0]);
                                              if ((v_tag_24211 == ((int64_t)0ULL))) {
                                                heff_drop(v_backend_24132);
                                                heff_drop(v_run_24137);
                                                heff_drop(v_ships_24147);
                                                heff_drop(v_fuel_24199);
                                                heff_drop_cell(v_ru_24t_24197_24Right, 1);
                                                heff_drop(v_includeDirs_24209);
                                                V v_p_24213 = v_field_24212;
                                                return heff_tag_n(TAG_Left, 1, (V[]){v_p_24213});
                                              } else {
                                                V v_xs_24214 = v_field_24212;
                                                HeffT2 v_t_24215 = (g_heff_2ebuild_2eproject_2eallOf_24s1507277824x59055423_24cpr(v_xs_24214));
                                                {
                                                  V v_field_24217 = v_t_24215.f[1];
                                                  int64_t v_tag_24216 = ((int64_t)v_t_24215.f[0]);
                                                  if ((v_tag_24216 == ((int64_t)0ULL))) {
                                                    heff_drop(v_backend_24132);
                                                    heff_drop(v_run_24137);
                                                    heff_drop(v_ships_24147);
                                                    heff_drop(v_fuel_24199);
                                                    heff_drop_cell(v_ru_24t_24197_24Right, 1);
                                                    heff_drop(v_includeDirs_24209);
                                                    V v_p_24218 = v_field_24217;
                                                    return heff_tag_n(TAG_Left, 1, (V[]){v_p_24218});
                                                  } else {
                                                    V v_libDirs_24219 = v_field_24217;
                                                    return heff_tag_at_n(v_ru_24t_24197_24Right, TAG_Right, 1, (V[]){heff_rec_n(6, shape_backend__run__ships__fuel__includeDirs__libDirs, (V[]){v_backend_24132, v_run_24137, v_ships_24147, v_fuel_24199, v_includeDirs_24209, v_libDirs_24219})});
                                                  }
                                                }
                                              }
                                            }
                                          }
                                        }
                                      }
                                    }
                                  }
                                  default: return heff_nomatch(v_t_24197);
                                  }
                                }
                              }
                            }
                          }
                        }
                      }
                    }
                    default: return heff_nomatch(v_t_24130);
                    }
                  }
                  case TAG_Cons: {
                    heff_take_n(v_it1222222_2482, 0ULL, 2);
                    heff_drop(v_b_2421);
                    heff_drop(v_r_2433);
                    heff_drop(v_s_2445);
                    heff_drop(v_f_2457);
                    heff_drop(v_i_2469);
                    heff_drop(v_l_2481);
                    V v_t_24230;
                    switch (heff_tag_of(v_x_240)) {
                    case TAG_LStr: {
                      V v_t_24223 = heff_field(v_x_240, 1);
                      v_t_24230 = heff_dup(v_t_24223);
                      break;
                    }
                    case TAG_LTag: {
                      V v_t_24225 = heff_field(v_x_240, 1);
                      v_t_24230 = heff_dup(v_t_24225);
                      break;
                    }
                    case TAG_LList: {
                      V v_t_24227 = heff_field(v_x_240, 1);
                      v_t_24230 = heff_dup(v_t_24227);
                      break;
                    }
                    case TAG_LRec: {
                      V v_t_24229 = heff_field(v_x_240, 1);
                      v_t_24230 = heff_dup(v_t_24229);
                      break;
                    }
                    default: heff_nomatch(v_x_240);
                    }
                    V v_t_24231 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_24230, 2, 7), ((V)&g_heff_2ebuild_2eproject_2ebuildOf_str23)});
                    return heff_tag_n(TAG_Left, 1, (V[]){v_t_24231});
                  }
                  default: return heff_nomatch(v_it1222222_2482);
                  }
                }
                default: return heff_nomatch(v_it122222_2470);
                }
              }
              default: return heff_nomatch(v_it12222_2458);
              }
            }
            default: return heff_nomatch(v_it1222_2446);
            }
          }
          default: return heff_nomatch(v_it122_2434);
          }
        }
        default: return heff_nomatch(v_it12_2422);
        }
      }
      default: return heff_nomatch(v_it1_2410);
      }
    }
  }
}
V g_heff_2ebuild_2eproject_2ebuildOf_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2eproject_2ebuildOf(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ebuild_2eproject_2enewer_str0, 1, "-");
HEFF_LIT(g_heff_2ebuild_2eproject_2enewer_str1, 1, "-");
HEFF_LIT(g_heff_2ebuild_2eproject_2enewer_str2, 1, "-");
HEFF_LIT(g_heff_2ebuild_2eproject_2enewer_str3, 1, "-");
HEFF_LIT(g_heff_2ebuild_2eproject_2enewer_str4, 0, "");
HEFF_LIT(g_heff_2ebuild_2eproject_2enewer_str5, 0, "");
HEFF_LIT(g_heff_2ebuild_2eproject_2enewer_str6, 0, "");
Clo g_heff_2ebuild_2eproject_2enewer_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eproject_2enewer_entry, 2, 0};

V g_heff_2ebuild_2eproject_2enewer(V v_a_240, V v_b_241) {
top: ;
  V v_t_242 = ({ V a_0 = v_a_240; V b_1 = ((V)&g_heff_2ebuild_2eproject_2enewer_str0); V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2eproject_2enewer_str1), v_a_240, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplit_2esplitFrom_240(a_0, b_1, a_2, a_3, a_4)); heff_drop(b_1); r_; });
  V v_t_243 = ({ V a_0 = v_t_242; V r_ = (g_heff_2ebuild_2eproject_2epseudoParts(a_0)); heff_drop(v_t_242); r_; });
  HeffT2 v_t_244 = ({ V a_0 = v_a_240; V a_1 = v_t_243; HeffT2 r_ = (g_heff_2ebuild_2eproject_2ekeyFrom_24cpr(a_0, a_1)); heff_drop(v_t_243); r_; });
  {
    V v_field_245 = v_t_244.f[0];
    V v_field_246 = v_t_244.f[1];
    V v_t_247 = ({ V a_0 = v_b_241; V b_1 = ((V)&g_heff_2ebuild_2eproject_2enewer_str2); V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2eproject_2enewer_str3), v_b_241, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplit_2esplitFrom_240(a_0, b_1, a_2, a_3, a_4)); heff_drop(b_1); r_; });
    V v_t_248 = ({ V a_0 = v_t_247; V r_ = (g_heff_2ebuild_2eproject_2epseudoParts(a_0)); heff_drop(v_t_247); r_; });
    HeffT2 v_t_249 = ({ V a_0 = v_b_241; V a_1 = v_t_248; HeffT2 r_ = (g_heff_2ebuild_2eproject_2ekeyFrom_24cpr(a_0, a_1)); heff_drop(v_t_248); r_; });
    {
      V v_field_2410 = v_t_249.f[0];
      V v_field_2411 = v_t_249.f[1];
      V v_xs_2412 = v_field_245;
      V v_a_2413 = v_field_246;
      V v_ys_2414 = v_field_2410;
      V v_b_2415 = v_field_2411;
      V v_t_2416 = (g_heff_2ebuild_2eproject_2enewerGo(v_xs_2412, v_ys_2414));
      V v_ret_24bool = heff_bool(((heff_dup(v_t_2416) == NTAG(TAG_True)) || ({ V v_x1_2417 = (g_heff_2ebuild_2eproject_2enewerGo(v_ys_2414, v_xs_2412)); int c_ = ((heff_dup(v_x1_2417) == NTAG(TAG_True)) ? 0 : (heff_strEq_c_lent(v_a_2413, ((V)&g_heff_2ebuild_2eproject_2enewer_str4), 2) ? !heff_strEq_c_lent(v_b_2415, ((V)&g_heff_2ebuild_2eproject_2enewer_str5), 2) : (heff_strEq_c_lent(v_b_2415, ((V)&g_heff_2ebuild_2eproject_2enewer_str6), 2) ? 0 : heff_strLt_c_lent(v_b_2415, v_a_2413, 0)))); heff_drop(v_x1_2417); c_; })));
      heff_drop(v_xs_2412);
      heff_drop(v_a_2413);
      heff_drop(v_ys_2414);
      heff_drop(v_b_2415);
      heff_drop(v_t_2416);
      return v_ret_24bool;
    }
  }
}
V g_heff_2ebuild_2eproject_2enewer_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ebuild_2eproject_2enewer(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ebuild_2eproject_2equoted_str0, 1, "\\");
HEFF_LIT(g_heff_2ebuild_2eproject_2equoted_str1, 1, "\\");
HEFF_LIT(g_heff_2ebuild_2eproject_2equoted_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2eproject_2equoted_str3, 2, "\\\\");
HEFF_LIT(g_heff_2ebuild_2eproject_2equoted_str4, 1, "\"");
HEFF_LIT(g_heff_2ebuild_2eproject_2equoted_str5, 1, "\"");
HEFF_LIT(g_heff_2ebuild_2eproject_2equoted_str6, 0, "");
HEFF_LIT(g_heff_2ebuild_2eproject_2equoted_str7, 2, "\\\"");
HEFF_LIT(g_heff_2ebuild_2eproject_2equoted_str8, 1, "\"");
HEFF_LIT(g_heff_2ebuild_2eproject_2equoted_str9, 1, "\"");
Clo g_heff_2ebuild_2eproject_2equoted_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eproject_2equoted_entry, 1, 0};

V g_heff_2ebuild_2eproject_2equoted(V v_s_240) {
top: ;
  V v_x2_241 = ({ V a_0 = v_s_240; V b_1 = ((V)&g_heff_2ebuild_2eproject_2equoted_str0); V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2eproject_2equoted_str1), v_s_240, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplit_2esplitFrom_240(a_0, b_1, a_2, a_3, a_4)); heff_drop(b_1); r_; });
  V v_s_244;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    v_s_244 = ((V)&g_heff_2ebuild_2eproject_2equoted_str2);
    break;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    v_s_244 = ({ V a_0 = ((V)&g_heff_2ebuild_2eproject_2equoted_str3); V a_1 = v_x_242; V a_2 = v_xs_243; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_243); r_; });
    break;
  }
  default: heff_nomatch(v_x2_241);
  }
  V v_x2_245 = ({ V a_0 = v_s_244; V b_1 = ((V)&g_heff_2ebuild_2eproject_2equoted_str4); V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2eproject_2equoted_str5), v_s_244, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplit_2esplitFrom_240(a_0, b_1, a_2, a_3, a_4)); heff_drop(v_s_244); heff_drop(b_1); r_; });
  V v_t_248;
  switch (heff_tag_of(v_x2_245)) {
  case TAG_Nil: {
    v_t_248 = ((V)&g_heff_2ebuild_2eproject_2equoted_str6);
    break;
  }
  case TAG_Cons: {
    V v_x_246 = heff_field(v_x2_245, 0);
    V v_xs_247 = heff_field(v_x2_245, 1);
    heff_take_n(v_x2_245, 3ULL, 2);
    v_t_248 = ({ V a_0 = ((V)&g_heff_2ebuild_2eproject_2equoted_str7); V a_1 = v_x_246; V a_2 = v_xs_247; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_247); r_; });
    break;
  }
  default: heff_nomatch(v_x2_245);
  }
  return heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2eproject_2equoted_str8), v_t_248), ((V)&g_heff_2ebuild_2eproject_2equoted_str9));
}
V g_heff_2ebuild_2eproject_2equoted_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2eproject_2equoted(a0); heff_drop(a0); return r;
}