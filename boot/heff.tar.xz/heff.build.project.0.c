// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_LList 15990
#define TAG_LRec 61105
#define TAG_LStr 62546
#define TAG_LTag 62907
#define TAG_Left 13886
#define TAG_Right 62770
#define LBL_at 9882
#define LBL_backend 2032133329
#define LBL_cmt 308164
#define LBL_col 308218
#define LBL_err 310239
#define LBL_first 298798794
#define LBL_heff 9694020
#define LBL_i 323
#define LBL_kind 9787483
#define LBL_left 9813198
#define LBL_line 9817275
#define LBL_lineStart 1964790630
#define LBL_module 878357911
#define LBL_msg 317947
#define LBL_name 9869138
#define LBL_replace 1326354680
#define LBL_require 1327554473
#define LBL_run 322821
#define LBL_ships 310766033
#define LBL_start 311115900
#define LBL_text 10052084
#define LBL_tok 324554
static uint32_t shape_at__msg[] = {LBL_at, LBL_msg};
static uint32_t shape_backend__run__ships[] = {LBL_backend, LBL_run, LBL_ships};
static uint32_t shape_i__line__lineStart__first__tok__err__cmt[] = {LBL_i, LBL_line, LBL_lineStart, LBL_first, LBL_tok, LBL_err, LBL_cmt};
static uint32_t shape_name__left[] = {LBL_name, LBL_left};
static V prim_strEq_entry(V self, V *a) { (void)self; return heff_strEq(a[0], a[1]); }
static Clo prim_strEq_clo = {{0x80000000u, K_CLO, 0}, prim_strEq_entry, 2, 0};
HeffT2 g_heff_2ebuild_2eproject_2eallOf_24s2049964666x1020559920_24cpr(V);
V g_heff_2ebuild_2eproject_2eallOf_24s622475081x394218744(V);
V g_heff_2ebuild_2eproject_2eallOf_24s622475081x394218744_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2eallOf_24s622475081x394218744_clo;
HeffT2 g_heff_2ebuild_2eproject_2eallOf_24s622475081x394218744_24cpr(V);
V g_heff_2ebuild_2eproject_2eandList(V);
V g_heff_2ebuild_2eproject_2eandList_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2eandList_clo;
HeffT2 g_heff_2ebuild_2eproject_2ebackendOf_24cpr(V);
HeffT2 g_heff_2ebuild_2eproject_2ebuildOf_24cpr(V);
HeffT2 g_heff_2ebuild_2eproject_2echeckHeff_24cpr(V, V, V, V);
V g_heff_2ebuild_2eproject_2ecompatible(V, V);
V g_heff_2ebuild_2eproject_2ecompatible_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2ecompatible_clo;
HeffT2 g_heff_2ebuild_2eproject_2edeclsGo_24cpr(V, V, V, V, V);
HeffT2 g_heff_2ebuild_2eproject_2efieldsAre_24cpr(V, V);
HeffT2 g_heff_2ebuild_2eproject_2efieldsIn_24cpr(V, V, V);
V g_heff_2ebuild_2eproject_2efieldsSaid(V);
V g_heff_2ebuild_2eproject_2efieldsSaid_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2efieldsSaid_clo;
HeffT2 g_heff_2ebuild_2eproject_2efirstNamed_24cpr(V, V);
V g_heff_2ebuild_2eproject_2eheffModule_get(void);
V g_heff_2ebuild_2eproject_2eisNumber(V);
V g_heff_2ebuild_2eproject_2eisNumber_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2eisNumber_clo;
HeffT2 g_heff_2ebuild_2eproject_2eitems_24cpr(V);
V g_heff_2ebuild_2eproject_2eleftOutNames(V);
V g_heff_2ebuild_2eproject_2eleftOutNames_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2eleftOutNames_clo;
HeffT2 g_heff_2ebuild_2eproject_2elitF_24s2091287445x1103896467_24cpr(V, V);
HeffT2 g_heff_2ebuild_2eproject_2emajorMismatch_24cpr(V, V);
HeffT2 g_heff_2ebuild_2eproject_2enameOf_24cpr(V);
V g_heff_2ebuild_2eproject_2enameRule_get(void);
V g_heff_2ebuild_2eproject_2enextDecl(V, V);
V g_heff_2ebuild_2eproject_2enextDecl_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2enextDecl_clo;
V g_heff_2ebuild_2eproject_2epackageFields_get(void);
V g_heff_2ebuild_2eproject_2epackageLit(V);
V g_heff_2ebuild_2eproject_2epackageLit_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2epackageLit_clo;
HeffT2 g_heff_2ebuild_2eproject_2epackageLit_24cpr(V);
HeffT2 g_heff_2ebuild_2eproject_2epackageOf_24cpr(V);
HeffT2 g_heff_2ebuild_2eproject_2epackageOf4_24cpr(V, V, V, V);
V g_heff_2ebuild_2eproject_2equoted(V);
V g_heff_2ebuild_2eproject_2equoted_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2equoted_clo;
V g_heff_2ebuild_2eproject_2erequireMsg_get(void);
HeffT2 g_heff_2ebuild_2eproject_2erequireOf_24cpr(V);
V g_heff_2ebuild_2eproject_2eshowPackage(V);
V g_heff_2ebuild_2eproject_2eshowPackage_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2eshowPackage_clo;
HeffT2 g_heff_2ebuild_2eproject_2estr_24cpr(V);
V g_heff_2ebuild_2eproject_2etestsModule_get(void);
HeffT2 g_heff_2ebuild_2eproject_2etwiceGo_24cpr(V, V);
HeffT2 g_heff_2ebuild_2eproject_2eversion_24cpr(V);
HeffT2 g_heff_2ebuild_2eproject_2ewhyNoName_24cpr(V);
HeffT3 g_heff_2esyntax_2efmt_2elex_2elexGo_24cpr(V, V, V, V, V);
V g_list_2eall_24s992198975x2074072147(V, V, V);
V g_list_2eall_24s992198975x2074072147_entry(V self, V *a);
extern Clo g_list_2eall_24s992198975x2074072147_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2emap_24f1156519715x726760149(V);
V g_list_2emap_24f1156519715x726760149_entry(V self, V *a);
extern Clo g_list_2emap_24f1156519715x726760149_clo;
V g_list_2emap_24f768999161x1997188166(V, V, V);
V g_list_2emap_24f768999161x1997188166_entry(V self, V *a);
extern Clo g_list_2emap_24f768999161x1997188166_clo;
V g_list_2emap_24s1381986540x1952410492(V);
V g_list_2emap_24s1381986540x1952410492_entry(V self, V *a);
extern Clo g_list_2emap_24s1381986540x1952410492_clo;
V g_list_2emap_24s404123879x745642248(V);
V g_list_2emap_24s404123879x745642248_entry(V self, V *a);
extern Clo g_list_2emap_24s404123879x745642248_clo;
V g_list_2emap_24s890213172x1049425163(V);
V g_list_2emap_24s890213172x1049425163_entry(V self, V *a);
extern Clo g_list_2emap_24s890213172x1049425163_clo;
V g_list_2ezipWith_24s1958630276x749154843(V, V);
V g_list_2ezipWith_24s1958630276x749154843_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1958630276x749154843_clo;
V g_list_2ezipWith_24s29557946x653938035(V, V);
V g_list_2ezipWith_24s29557946x653938035_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s29557946x653938035_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2esplitFrom(V, V, V, V, V);
V g_prelude_2esplitFrom_entry(V self, V *a);
extern Clo g_prelude_2esplitFrom_clo;
HEFF_LIT(g_heff_2ebuild_2eproject_2enextDecl_str0, 3, "eof");
Clo g_heff_2ebuild_2eproject_2enextDecl_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eproject_2enextDecl_entry, 2, 0};

V g_heff_2ebuild_2eproject_2enextDecl(V v_ts_240, V v_i_241) {
top: ;
  if (heff_intLe_c_lent(MK_INT(0LL), v_i_241, 1)) {
    if (heff_intLt_c(heff_dup(v_i_241), heff_arrayLength_lent(v_ts_240, 0))) {
      V v_t_244 = heff_arrayIndex_lent(v_ts_240, v_i_241, 0);
      if (heff_strEq_c(heff_dup(heff_rfield(v_t_244, 0)), ((V)&g_heff_2ebuild_2eproject_2enextDecl_str0))) {
        heff_drop_rec(v_t_244, 7);
        return v_i_241;
      } else {
        V v_t_246 = heff_take_field(v_t_244, 6);
        if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
          heff_drop(v_t_246);
          if (heff_intEq_c(heff_get_n(v_t_244, 5, 7), MK_INT(0LL))) {
            return v_i_241;
          } else {
            V t_0 = v_ts_240;
            V t_1 = heff_box_word((heff_unbox_word(v_i_241) + ((int64_t)1ULL)));
            v_ts_240 = t_0;
            v_i_241 = t_1;
            goto top;
          }
        } else {
          heff_drop_rec(v_t_244, 7);
          heff_drop(v_t_246);
          V t_0 = v_ts_240;
          V t_1 = heff_box_word((heff_unbox_word(v_i_241) + ((int64_t)1ULL)));
          v_ts_240 = t_0;
          v_i_241 = t_1;
          goto top;
        }
      }
    } else {
      return v_i_241;
    }
  } else {
    return v_i_241;
  }
}
V g_heff_2ebuild_2eproject_2enextDecl_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2eproject_2enextDecl(a0, a[1]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ebuild_2eproject_2edeclsGo_24cpr_str0, 42, "the text ends where more of it is expected");
HEFF_LIT(g_heff_2ebuild_2eproject_2edeclsGo_24cpr_str1, 3, "eof");
HEFF_LIT(g_heff_2ebuild_2eproject_2edeclsGo_24cpr_str2, 13, " defines no `");
HEFF_LIT(g_heff_2ebuild_2eproject_2edeclsGo_24cpr_str3, 1, "`");
HEFF_LIT(g_heff_2ebuild_2eproject_2edeclsGo_24cpr_str4, 2, "kw");
HEFF_LIT(g_heff_2ebuild_2eproject_2edeclsGo_24cpr_str5, 6, "import");
HEFF_LIT(g_heff_2ebuild_2eproject_2edeclsGo_24cpr_str6, 3, "var");
HEFF_LIT(g_heff_2ebuild_2eproject_2edeclsGo_24cpr_str7, 3, "sym");
HEFF_LIT(g_heff_2ebuild_2eproject_2edeclsGo_24cpr_str8, 1, ":");
HEFF_LIT(g_heff_2ebuild_2eproject_2edeclsGo_24cpr_str9, 3, "var");
HEFF_LIT(g_heff_2ebuild_2eproject_2edeclsGo_24cpr_str10, 3, "sym");
HEFF_LIT(g_heff_2ebuild_2eproject_2edeclsGo_24cpr_str11, 1, "=");
HEFF_LIT(g_heff_2ebuild_2eproject_2edeclsGo_24cpr_str12, 42, "the text ends where more of it is expected");
HEFF_LIT(g_heff_2ebuild_2eproject_2edeclsGo_24cpr_str13, 3, "eof");
HEFF_LIT(g_heff_2ebuild_2eproject_2edeclsGo_24cpr_str14, 1, "`");
HEFF_LIT(g_heff_2ebuild_2eproject_2edeclsGo_24cpr_str15, 38, "` is a literal, and nothing follows it");
HEFF_LIT(g_heff_2ebuild_2eproject_2edeclsGo_24cpr_str16, 1, "`");
HEFF_LIT(g_heff_2ebuild_2eproject_2edeclsGo_24cpr_str17, 38, "` is a literal, and nothing follows it");
HEFF_LIT(g_heff_2ebuild_2eproject_2edeclsGo_24cpr_str18, 1, "`");
HEFF_LIT(g_heff_2ebuild_2eproject_2edeclsGo_24cpr_str19, 27, "` is defined more than once");
HEFF_LIT(g_heff_2ebuild_2eproject_2edeclsGo_24cpr_str20, 21, " holds imports, and `");
HEFF_LIT(g_heff_2ebuild_2eproject_2edeclsGo_24cpr_str21, 50, "` (its signature and its definition), nothing else");

HeffT2 g_heff_2ebuild_2eproject_2edeclsGo_24cpr(V v_file_240, V v_name_241, V v_ts_242, V v_i_243, V v_found_244) {
top: ;
  V v_t_248;
  if (heff_intLe_c_lent(MK_INT(0LL), v_i_243, 1)) {
    if (heff_intLt_c(heff_dup(v_i_243), heff_arrayLength_lent(v_ts_242, 0))) {
      V v_t_247 = heff_arrayIndex_lent(v_ts_242, v_i_243, 0);
      v_t_248 = heff_tag_n(TAG_Just, 1, (V[]){v_t_247});
    } else {
      v_t_248 = NTAG(TAG_Nothing);
    }
  } else {
    v_t_248 = NTAG(TAG_Nothing);
  }
  switch (heff_tag_of(v_t_248)) {
  case TAG_Nothing: {
    heff_drop(v_file_240);
    heff_drop(v_name_241);
    heff_drop(v_i_243);
    heff_drop(v_found_244);
    int64_t v_i_249 = (heff_unbox_word(heff_arrayLength_lent(v_ts_242, 0)) - ((int64_t)1ULL));
    V v_t_2413;
    if ((((int64_t)0ULL) <= v_i_249)) {
      if ((v_i_249 < heff_unbox_word(heff_arrayLength_lent(v_ts_242, 0)))) {
        V v_t_2412 = heff_arrayIndex_lent(v_ts_242, heff_box_word(v_i_249), 2);
        v_t_2413 = heff_get_n(v_t_2412, 2, 7);
      } else {
        v_t_2413 = MK_INT(0LL);
      }
    } else {
      v_t_2413 = MK_INT(0LL);
    }
    V v_f_2414 = heff_rec_n(2, shape_at__msg, (V[]){v_t_2413, ((V)&g_heff_2ebuild_2eproject_2edeclsGo_24cpr_str0)});
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2414}});
  }
  case TAG_Just: {
    V v_t_2415 = heff_field(v_t_248, 0);
    V v_ru_24t_248_24Just = heff_take_reuse_n(v_t_248, 1ULL, 1);
    if (heff_strEq_c(heff_dup(heff_rfield(v_t_2415, 0)), ((V)&g_heff_2ebuild_2eproject_2edeclsGo_24cpr_str1))) {
      heff_drop(v_i_243);
      heff_drop_cell(v_ru_24t_248_24Just, 1);
      switch (heff_tag_of(v_found_244)) {
      case TAG_Nothing: {
        V v_t_2417 = heff_strAppend(((V)&g_heff_2ebuild_2eproject_2edeclsGo_24cpr_str2), heff_strAppend(v_name_241, ((V)&g_heff_2ebuild_2eproject_2edeclsGo_24cpr_str3)));
        V v_f_2418 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2415, 2, 7), heff_strAppend(v_file_240, v_t_2417)});
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2418}});
      }
      case TAG_Just: {
        V v_x_2419 = heff_field(v_found_244, 0);
        heff_take_n(v_found_244, 1ULL, 1);
        heff_drop(v_file_240);
        heff_drop(v_name_241);
        heff_drop_rec(v_t_2415, 7);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_x_2419}});
      }
      default: return ((HeffT2){{heff_nomatch(v_found_244)}});
      }
    } else {
      V v_t_2421 = heff_bool((heff_strEq_c(heff_dup(heff_rfield(v_t_2415, 0)), ((V)&g_heff_2ebuild_2eproject_2edeclsGo_24cpr_str4)) && heff_strEq_c(heff_dup(heff_rfield(v_t_2415, 1)), ((V)&g_heff_2ebuild_2eproject_2edeclsGo_24cpr_str5))));
      if ((heff_dup(v_t_2421) == NTAG(TAG_True))) {
        heff_drop_rec(v_t_2415, 7);
        heff_drop_cell(v_ru_24t_248_24Just, 1);
        heff_drop(v_t_2421);
        V v_t_2422 = (g_heff_2ebuild_2eproject_2enextDecl(v_ts_242, heff_intAdd(v_i_243, MK_INT(1LL))));
        V t_0 = v_file_240;
        V t_1 = v_name_241;
        V t_2 = v_ts_242;
        V t_3 = v_t_2422;
        V t_4 = v_found_244;
        v_file_240 = t_0;
        v_name_241 = t_1;
        v_ts_242 = t_2;
        v_i_243 = t_3;
        v_found_244 = t_4;
        goto top;
      } else {
        heff_drop(v_t_2421);
        V v_t_2430 = heff_bool((heff_strEq_c(heff_dup(heff_rfield(v_t_2415, 0)), ((V)&g_heff_2ebuild_2eproject_2edeclsGo_24cpr_str6)) && (heff_strEq_c(heff_dup(heff_rfield(v_t_2415, 1)), heff_dup(v_name_241)) && ({ V v_i_2425 = heff_intAdd(heff_dup(v_i_243), MK_INT(1LL)); int c_ = (heff_intLe_c_lent(MK_INT(0LL), v_i_2425, 1) && (heff_intLt_c(heff_dup(v_i_2425), heff_arrayLength_lent(v_ts_242, 0)) && ({ V v_t_2428 = heff_arrayIndex_lent(v_ts_242, v_i_2425, 0); int c_ = (heff_strEq_c(heff_dup(heff_rfield(v_t_2428, 0)), ((V)&g_heff_2ebuild_2eproject_2edeclsGo_24cpr_str7)) && heff_strEq_c(heff_dup(heff_rfield(v_t_2428, 1)), ((V)&g_heff_2ebuild_2eproject_2edeclsGo_24cpr_str8))); heff_drop(v_t_2428); c_; }))); heff_drop(v_i_2425); c_; }))));
        if ((heff_dup(v_t_2430) == NTAG(TAG_True))) {
          heff_drop_rec(v_t_2415, 7);
          heff_drop_cell(v_ru_24t_248_24Just, 1);
          heff_drop(v_t_2430);
          V v_t_2431 = (g_heff_2ebuild_2eproject_2enextDecl(v_ts_242, heff_intAdd(v_i_243, MK_INT(1LL))));
          V t_0 = v_file_240;
          V t_1 = v_name_241;
          V t_2 = v_ts_242;
          V t_3 = v_t_2431;
          V t_4 = v_found_244;
          v_file_240 = t_0;
          v_name_241 = t_1;
          v_ts_242 = t_2;
          v_i_243 = t_3;
          v_found_244 = t_4;
          goto top;
        } else {
          heff_drop(v_t_2430);
          V v_t_2439 = heff_bool((heff_strEq_c(heff_dup(heff_rfield(v_t_2415, 0)), ((V)&g_heff_2ebuild_2eproject_2edeclsGo_24cpr_str9)) && (heff_strEq_c(heff_dup(heff_rfield(v_t_2415, 1)), heff_dup(v_name_241)) && ({ V v_i_2434 = heff_intAdd(heff_dup(v_i_243), MK_INT(1LL)); int c_ = (heff_intLe_c_lent(MK_INT(0LL), v_i_2434, 1) && (heff_intLt_c(heff_dup(v_i_2434), heff_arrayLength_lent(v_ts_242, 0)) && ({ V v_t_2437 = heff_arrayIndex_lent(v_ts_242, v_i_2434, 0); int c_ = (heff_strEq_c(heff_dup(heff_rfield(v_t_2437, 0)), ((V)&g_heff_2ebuild_2eproject_2edeclsGo_24cpr_str10)) && heff_strEq_c(heff_dup(heff_rfield(v_t_2437, 1)), ((V)&g_heff_2ebuild_2eproject_2edeclsGo_24cpr_str11))); heff_drop(v_t_2437); c_; }))); heff_drop(v_i_2434); c_; }))));
          if ((heff_dup(v_t_2439) == NTAG(TAG_True))) {
            heff_drop(v_t_2439);
            switch (heff_tag_of(v_found_244)) {
            case TAG_Nothing: {
              heff_drop_rec(v_t_2415, 7);
              HeffT2 v_t_2440 = (g_heff_2ebuild_2eproject_2elitF_24s2091287445x1103896467_24cpr(v_ts_242, heff_intAdd(v_i_243, MK_INT(2LL))));
              {
                V v_field_2442 = v_t_2440.f[1];
                int64_t v_tag_2441 = ((int64_t)v_t_2440.f[0]);
                if ((v_tag_2441 == ((int64_t)0ULL))) {
                  heff_drop(v_file_240);
                  heff_drop(v_name_241);
                  heff_drop_cell(v_ru_24t_248_24Just, 1);
                  V v_p_2444 = v_field_2442;
                  return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_p_2444}});
                } else {
                  V v_it1_2445 = v_field_2442;
                  switch (heff_tag_of(v_it1_2445)) {
                  case TAG_MkPair: {
                    V v_x_2446 = heff_field(v_it1_2445, 0);
                    V v_j_2447 = heff_field(v_it1_2445, 1);
                    heff_take_n(v_it1_2445, 3ULL, 2);
                    V v_t_2451;
                    if (heff_intLe_c_lent(MK_INT(0LL), v_j_2447, 1)) {
                      if (heff_intLt_c(heff_dup(v_j_2447), heff_arrayLength_lent(v_ts_242, 0))) {
                        V v_t_2450 = heff_arrayIndex_lent(v_ts_242, v_j_2447, 0);
                        v_t_2451 = heff_tag_at_n(v_ru_24t_248_24Just, TAG_Just, 1, (V[]){v_t_2450});
                      } else {
                        heff_drop_cell(v_ru_24t_248_24Just, 1);
                        v_t_2451 = NTAG(TAG_Nothing);
                      }
                    } else {
                      heff_drop_cell(v_ru_24t_248_24Just, 1);
                      v_t_2451 = NTAG(TAG_Nothing);
                    }
                    switch (heff_tag_of(v_t_2451)) {
                    case TAG_Nothing: {
                      heff_drop(v_file_240);
                      heff_drop(v_name_241);
                      heff_drop(v_x_2446);
                      heff_drop(v_j_2447);
                      int64_t v_i_2452 = (heff_unbox_word(heff_arrayLength_lent(v_ts_242, 0)) - ((int64_t)1ULL));
                      V v_t_2456;
                      if ((((int64_t)0ULL) <= v_i_2452)) {
                        if ((v_i_2452 < heff_unbox_word(heff_arrayLength_lent(v_ts_242, 0)))) {
                          V v_t_2455 = heff_arrayIndex_lent(v_ts_242, heff_box_word(v_i_2452), 2);
                          v_t_2456 = heff_get_n(v_t_2455, 2, 7);
                        } else {
                          v_t_2456 = MK_INT(0LL);
                        }
                      } else {
                        v_t_2456 = MK_INT(0LL);
                      }
                      V v_f_2457 = heff_rec_n(2, shape_at__msg, (V[]){v_t_2456, ((V)&g_heff_2ebuild_2eproject_2edeclsGo_24cpr_str12)});
                      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2457}});
                    }
                    case TAG_Just: {
                      V v_after_2458 = heff_field(v_t_2451, 0);
                      V v_ru_24t_2451_24Just = heff_take_reuse_n(v_t_2451, 1ULL, 1);
                      if (heff_strEq_c(heff_dup(heff_rfield(v_after_2458, 0)), ((V)&g_heff_2ebuild_2eproject_2edeclsGo_24cpr_str13))) {
                        heff_drop_rec(v_after_2458, 7);
                        V t_0 = v_file_240;
                        V t_1 = v_name_241;
                        V t_2 = v_ts_242;
                        V t_3 = v_j_2447;
                        V t_4 = heff_tag_at_n(v_ru_24t_2451_24Just, TAG_Just, 1, (V[]){v_x_2446});
                        v_file_240 = t_0;
                        v_name_241 = t_1;
                        v_ts_242 = t_2;
                        v_i_243 = t_3;
                        v_found_244 = t_4;
                        goto top;
                      } else {
                        V v_t_2460 = heff_take_field(v_after_2458, 6);
                        if ((heff_dup(v_t_2460) == NTAG(TAG_True))) {
                          heff_drop(v_t_2460);
                          if (heff_intEq_c(heff_dup(heff_rfield(v_after_2458, 5)), MK_INT(0LL))) {
                            heff_drop_rec(v_after_2458, 7);
                            V t_0 = v_file_240;
                            V t_1 = v_name_241;
                            V t_2 = v_ts_242;
                            V t_3 = v_j_2447;
                            V t_4 = heff_tag_at_n(v_ru_24t_2451_24Just, TAG_Just, 1, (V[]){v_x_2446});
                            v_file_240 = t_0;
                            v_name_241 = t_1;
                            v_ts_242 = t_2;
                            v_i_243 = t_3;
                            v_found_244 = t_4;
                            goto top;
                          } else {
                            heff_drop(v_file_240);
                            heff_drop(v_x_2446);
                            heff_drop(v_j_2447);
                            heff_drop_cell(v_ru_24t_2451_24Just, 1);
                            V v_t_2462 = heff_strAppend(((V)&g_heff_2ebuild_2eproject_2edeclsGo_24cpr_str14), heff_strAppend(v_name_241, ((V)&g_heff_2ebuild_2eproject_2edeclsGo_24cpr_str15)));
                            V v_f_2463 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_after_2458, 2, 7), v_t_2462});
                            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2463}});
                          }
                        } else {
                          heff_drop(v_file_240);
                          heff_drop(v_x_2446);
                          heff_drop(v_j_2447);
                          heff_drop_cell(v_ru_24t_2451_24Just, 1);
                          heff_drop(v_t_2460);
                          V v_t_2464 = heff_strAppend(((V)&g_heff_2ebuild_2eproject_2edeclsGo_24cpr_str16), heff_strAppend(v_name_241, ((V)&g_heff_2ebuild_2eproject_2edeclsGo_24cpr_str17)));
                          V v_f_2465 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_after_2458, 2, 7), v_t_2464});
                          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2465}});
                        }
                      }
                    }
                    default: return ((HeffT2){{heff_nomatch(v_t_2451)}});
                    }
                  }
                  default: return ((HeffT2){{heff_nomatch(v_it1_2445)}});
                  }
                }
              }
            }
            case TAG_Just: {
              heff_take_n(v_found_244, 0ULL, 1);
              heff_drop(v_file_240);
              heff_drop(v_i_243);
              heff_drop_cell(v_ru_24t_248_24Just, 1);
              V v_t_2467 = heff_strAppend(((V)&g_heff_2ebuild_2eproject_2edeclsGo_24cpr_str18), heff_strAppend(v_name_241, ((V)&g_heff_2ebuild_2eproject_2edeclsGo_24cpr_str19)));
              V v_f_2468 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2415, 2, 7), v_t_2467});
              return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2468}});
            }
            default: return ((HeffT2){{heff_nomatch(v_found_244)}});
            }
          } else {
            heff_drop(v_i_243);
            heff_drop(v_found_244);
            heff_drop_cell(v_ru_24t_248_24Just, 1);
            heff_drop(v_t_2439);
            V v_t_2469 = heff_strAppend(((V)&g_heff_2ebuild_2eproject_2edeclsGo_24cpr_str20), heff_strAppend(v_name_241, ((V)&g_heff_2ebuild_2eproject_2edeclsGo_24cpr_str21)));
            V v_f_2470 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2415, 2, 7), heff_strAppend(v_file_240, v_t_2469)});
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2470}});
          }
        }
      }
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_t_248)}});
  }
}
Clo g_heff_2ebuild_2eproject_2eisNumber_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eproject_2eisNumber_entry, 1, 0};

V g_heff_2ebuild_2eproject_2eisNumber(V v_s_240) {
top: ;
  V v_ret_24bool = heff_bool(((((int64_t)0ULL) < heff_unbox_word(heff_strLength_lent(v_s_240, 0))) && ({ V v_t_242 = (g_list_2emap_24f768999161x1997188166(v_s_240, MK_INT(0LL), heff_strLength_lent(v_s_240, 0))); int c_ = ({ V v_t_243 = (g_list_2eall_24s992198975x2074072147(MK_INT(48LL), MK_INT(57LL), v_t_242)); int c_ = ((heff_dup(v_t_243) == NTAG(TAG_True)) && ((heff_unbox_word(heff_strLength_lent(v_s_240, 0)) == ((int64_t)1ULL)) || !(heff_unbox_word(heff_strByteAt_lent(v_s_240, MK_INT(0LL), 2)) == ((int64_t)48ULL)))); heff_drop(v_t_243); c_; }); heff_drop(v_t_242); c_; })));
  return v_ret_24bool;
}
V g_heff_2ebuild_2eproject_2eisNumber_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2eproject_2eisNumber(a0); heff_drop(a0); return r;
}
Clo g_heff_2ebuild_2eproject_2ecompatible_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eproject_2ecompatible_entry, 2, 0};

V g_heff_2ebuild_2eproject_2ecompatible(V v_x1_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_wa_242 = heff_field(v_x1_240, 0);
    V v_x12_243 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x12_243)) {
    case TAG_Nil: {
      return NTAG(TAG_False);
    }
    case TAG_Cons: {
      V v_wb_244 = heff_field(v_x12_243, 0);
      V v_x122_245 = heff_field(v_x12_243, 1);
      switch (heff_tag_of(v_x122_245)) {
      case TAG_Nil: {
        return NTAG(TAG_False);
      }
      case TAG_Cons: {
        V v_wc_246 = heff_field(v_x122_245, 0);
        V v_x1222_247 = heff_field(v_x122_245, 1);
        switch (heff_tag_of(v_x1222_247)) {
        case TAG_Nil: {
          switch (heff_tag_of(v_x2_241)) {
          case TAG_Nil: {
            return NTAG(TAG_False);
          }
          case TAG_Cons: {
            V v_ra_248 = heff_field(v_x2_241, 0);
            V v_x22_249 = heff_field(v_x2_241, 1);
            switch (heff_tag_of(v_x22_249)) {
            case TAG_Nil: {
              return NTAG(TAG_False);
            }
            case TAG_Cons: {
              V v_rb_2410 = heff_field(v_x22_249, 0);
              V v_x222_2411 = heff_field(v_x22_249, 1);
              switch (heff_tag_of(v_x222_2411)) {
              case TAG_Nil: {
                return NTAG(TAG_False);
              }
              case TAG_Cons: {
                V v_rc_2412 = heff_field(v_x222_2411, 0);
                V v_x2222_2413 = heff_field(v_x222_2411, 1);
                switch (heff_tag_of(v_x2222_2413)) {
                case TAG_Nil: {
                  V v_ret_24bool = heff_bool((heff_intEq_c_lent(v_wa_242, MK_INT(0LL), 2) ? (heff_intEq_c_lent(v_ra_248, MK_INT(0LL), 2) && (heff_intEq_c_lent(v_rb_2410, v_wb_244, 0) && heff_intLe_c_lent(v_wc_246, v_rc_2412, 0))) : (heff_intEq_c_lent(v_ra_248, v_wa_242, 0) && (heff_intLt_c_lent(v_wb_244, v_rb_2410, 0) || (heff_intEq_c_lent(v_rb_2410, v_wb_244, 0) && heff_intLe_c_lent(v_wc_246, v_rc_2412, 0))))));
                  return v_ret_24bool;
                }
                case TAG_Cons: {
                  return NTAG(TAG_False);
                }
                default: return heff_nomatch(v_x2222_2413);
                }
              }
              default: return heff_nomatch(v_x222_2411);
              }
            }
            default: return heff_nomatch(v_x22_249);
            }
          }
          default: return heff_nomatch(v_x2_241);
          }
        }
        case TAG_Cons: {
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_x1222_247);
        }
      }
      default: return heff_nomatch(v_x122_245);
      }
    }
    default: return heff_nomatch(v_x12_243);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2eproject_2ecompatible_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ebuild_2eproject_2ecompatible(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ebuild_2eproject_2enameRule_str0, 58, "a lowercase letter, then lowercase letters, digits and `_`");

static V g_heff_2ebuild_2eproject_2enameRule_val;
static HEFF_ONCE g_heff_2ebuild_2eproject_2enameRule_st;
static V g_heff_2ebuild_2eproject_2enameRule_init(void) {
  return ((V)&g_heff_2ebuild_2eproject_2enameRule_str0);
}
V g_heff_2ebuild_2eproject_2enameRule_get(void) {
  if (HEFF_DONE(g_heff_2ebuild_2eproject_2enameRule_st)) return g_heff_2ebuild_2eproject_2enameRule_val;
  return heff_global(&g_heff_2ebuild_2eproject_2enameRule_val, &g_heff_2ebuild_2eproject_2enameRule_st, g_heff_2ebuild_2eproject_2enameRule_init);
}
HEFF_LIT(g_heff_2ebuild_2eproject_2etestsModule_str0, 4, "test");

static V g_heff_2ebuild_2eproject_2etestsModule_val;
static HEFF_ONCE g_heff_2ebuild_2eproject_2etestsModule_st;
static V g_heff_2ebuild_2eproject_2etestsModule_init(void) {
  return ((V)&g_heff_2ebuild_2eproject_2etestsModule_str0);
}
V g_heff_2ebuild_2eproject_2etestsModule_get(void) {
  if (HEFF_DONE(g_heff_2ebuild_2eproject_2etestsModule_st)) return g_heff_2ebuild_2eproject_2etestsModule_val;
  return heff_global(&g_heff_2ebuild_2eproject_2etestsModule_val, &g_heff_2ebuild_2eproject_2etestsModule_st, g_heff_2ebuild_2eproject_2etestsModule_init);
}
HEFF_LIT(g_heff_2ebuild_2eproject_2efieldsSaid_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2eproject_2efieldsSaid_str1, 2, ", ");
HEFF_LIT(g_heff_2ebuild_2eproject_2efieldsSaid_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2eproject_2efieldsSaid_str3, 2, " (");
HEFF_LIT(g_heff_2ebuild_2eproject_2efieldsSaid_str4, 17, " may be left out)");
HEFF_LIT(g_heff_2ebuild_2eproject_2efieldsSaid_str5, 15, ", in this order");
HEFF_LIT(g_heff_2ebuild_2eproject_2efieldsSaid_str6, 15, "the fields are ");
Clo g_heff_2ebuild_2eproject_2efieldsSaid_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eproject_2efieldsSaid_entry, 1, 0};

V g_heff_2ebuild_2eproject_2efieldsSaid(V v_fields_240) {
top: ;
  V v_x2_241 = (g_list_2emap_24s890213172x1049425163(heff_dup(v_fields_240)));
  V v_t_244;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    v_t_244 = ((V)&g_heff_2ebuild_2eproject_2efieldsSaid_str0);
    break;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    v_t_244 = ({ V a_0 = ((V)&g_heff_2ebuild_2eproject_2efieldsSaid_str1); V a_1 = v_x_242; V a_2 = v_xs_243; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_243); r_; });
    break;
  }
  default: heff_nomatch(v_x2_241);
  }
  V v_x1_245 = (g_heff_2ebuild_2eproject_2eleftOutNames(heff_dup(v_fields_240)));
  V v_t_2410;
  switch (heff_tag_of(v_x1_245)) {
  case TAG_Nil: {
    heff_drop(v_fields_240);
    v_t_2410 = ((V)&g_heff_2ebuild_2eproject_2efieldsSaid_str2);
    break;
  }
  case TAG_Cons: {
    heff_take_n(v_x1_245, 0ULL, 2);
    V v_t_248 = (g_heff_2ebuild_2eproject_2eleftOutNames(v_fields_240));
    V v_t_249 = ({ V a_0 = v_t_248; V r_ = (g_heff_2ebuild_2eproject_2eandList(a_0)); heff_drop(v_t_248); r_; });
    v_t_2410 = heff_strAppend(((V)&g_heff_2ebuild_2eproject_2efieldsSaid_str3), heff_strAppend(v_t_249, ((V)&g_heff_2ebuild_2eproject_2efieldsSaid_str4)));
    break;
  }
  default: heff_nomatch(v_x1_245);
  }
  V v_t_2411 = heff_strAppend(v_t_244, heff_strAppend(((V)&g_heff_2ebuild_2eproject_2efieldsSaid_str5), v_t_2410));
  return heff_strAppend(((V)&g_heff_2ebuild_2eproject_2efieldsSaid_str6), v_t_2411);
}
V g_heff_2ebuild_2eproject_2efieldsSaid_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eproject_2efieldsSaid(a[0]);
}

HeffT2 g_heff_2ebuild_2eproject_2efieldsIn_24cpr(V v_t_240, V v_x2_241, V v_written_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_t_240);
    switch (heff_tag_of(v_written_242)) {
    case TAG_Nil: {
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), NTAG(TAG_Nil)}});
    }
    case TAG_Cons: {
      heff_take_n(v_written_242, 0ULL, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    default: return ((HeffT2){{heff_nomatch(v_written_242)}});
    }
  }
  case TAG_Cons: {
    V v_f_245 = heff_field(v_x2_241, 0);
    V v_rest_246 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_written_242)) {
    case TAG_Nil: {
      V v_t_247 = heff_get_n(v_f_245, 1, 2);
      switch (heff_tag_of(v_t_247)) {
      case TAG_Nothing: {
        heff_drop(v_t_240);
        heff_drop(v_rest_246);
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_Just: {
        V v_mk_248 = heff_field(v_t_247, 0);
        heff_take_n(v_t_247, 1ULL, 1);
        V v_v_249 = heff_tr(heff_call(v_mk_248, 1, (V[]){heff_dup(v_t_240)}));
        HeffT2 v_t_2410 = (g_heff_2ebuild_2eproject_2efieldsIn_24cpr(v_t_240, v_rest_246, v_written_242));
        {
          V v_field_2412 = v_t_2410.f[1];
          int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
          if ((v_tag_2411 == ((int64_t)0ULL))) {
            V v_vs_2414 = v_field_2412;
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_v_249, v_vs_2414})}});
          } else {
            heff_drop_cell(v_ru_24x2_241_24Cons, 2);
            heff_drop(v_v_249);
            heff_drop(v_field_2412);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_t_247)}});
      }
    }
    case TAG_Cons: {
      V v_x21_2415 = heff_dup(heff_field(v_written_242, 0));
      V v_more_2416 = heff_dup(heff_field(v_written_242, 1));
      switch (heff_tag_of(v_x21_2415)) {
      case TAG_MkPair: {
        V v_y_2417 = heff_field(v_x21_2415, 0);
        V v_v_2418 = heff_field(v_x21_2415, 1);
        heff_take_n(v_x21_2415, 3ULL, 2);
        if (heff_strEq_c(heff_dup(heff_rfield(v_f_245, 0)), v_y_2417)) {
          heff_drop_tag(v_written_242, 2);
          heff_drop_rec(v_f_245, 2);
          HeffT2 v_t_2420 = (g_heff_2ebuild_2eproject_2efieldsIn_24cpr(v_t_240, v_rest_246, v_more_2416));
          {
            V v_field_2422 = v_t_2420.f[1];
            int64_t v_tag_2421 = ((int64_t)v_t_2420.f[0]);
            if ((v_tag_2421 == ((int64_t)0ULL))) {
              V v_vs_2424 = v_field_2422;
              return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_v_2418, v_vs_2424})}});
            } else {
              heff_drop_cell(v_ru_24x2_241_24Cons, 2);
              heff_drop(v_v_2418);
              heff_drop(v_field_2422);
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
            }
          }
        } else {
          heff_drop(v_more_2416);
          heff_drop(v_v_2418);
          V v_t_2425 = heff_get_n(v_f_245, 1, 2);
          switch (heff_tag_of(v_t_2425)) {
          case TAG_Nothing: {
            heff_drop(v_t_240);
            heff_drop_tag(v_written_242, 2);
            heff_drop(v_rest_246);
            heff_drop_cell(v_ru_24x2_241_24Cons, 2);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          case TAG_Just: {
            V v_mk_2426 = heff_field(v_t_2425, 0);
            heff_take_n(v_t_2425, 1ULL, 1);
            V v_v_2427 = heff_tr(heff_call(v_mk_2426, 1, (V[]){heff_dup(v_t_240)}));
            HeffT2 v_t_2428 = (g_heff_2ebuild_2eproject_2efieldsIn_24cpr(v_t_240, v_rest_246, v_written_242));
            {
              V v_field_2430 = v_t_2428.f[1];
              int64_t v_tag_2429 = ((int64_t)v_t_2428.f[0]);
              if ((v_tag_2429 == ((int64_t)0ULL))) {
                V v_vs_2432 = v_field_2430;
                return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_v_2427, v_vs_2432})}});
              } else {
                heff_drop_cell(v_ru_24x2_241_24Cons, 2);
                heff_drop(v_v_2427);
                heff_drop(v_field_2430);
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
              }
            }
          }
          default: return ((HeffT2){{heff_nomatch(v_t_2425)}});
          }
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x21_2415)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_written_242)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
HEFF_LIT(g_heff_2ebuild_2eproject_2estr_24cpr_str0, 17, "expected a string");
HEFF_LIT(g_heff_2ebuild_2eproject_2estr_24cpr_str1, 17, "expected a string");
HEFF_LIT(g_heff_2ebuild_2eproject_2estr_24cpr_str2, 17, "expected a string");

HeffT2 g_heff_2ebuild_2eproject_2estr_24cpr(V v_x_240) {
top: ;
  switch (heff_tag_of(v_x_240)) {
  case TAG_LStr: {
    V v_s_241 = heff_field(v_x_240, 0);
    heff_take_n(v_x_240, 1ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_s_241}});
  }
  case TAG_LTag: {
    V v_t_2413;
    switch (heff_tag_of(v_x_240)) {
    case TAG_LStr: {
      V v_t_246 = heff_field(v_x_240, 1);
      heff_take_n(v_x_240, 2ULL, 2);
      v_t_2413 = v_t_246;
      break;
    }
    case TAG_LTag: {
      V v_t_248 = heff_field(v_x_240, 1);
      heff_take_n(v_x_240, 2ULL, 2);
      v_t_2413 = v_t_248;
      break;
    }
    case TAG_LList: {
      V v_t_2410 = heff_field(v_x_240, 1);
      heff_take_n(v_x_240, 2ULL, 2);
      v_t_2413 = v_t_2410;
      break;
    }
    case TAG_LRec: {
      V v_t_2412 = heff_field(v_x_240, 1);
      heff_take_n(v_x_240, 2ULL, 2);
      v_t_2413 = v_t_2412;
      break;
    }
    default: heff_nomatch(v_x_240);
    }
    V v_f_2414 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2413, 2, 7), ((V)&g_heff_2ebuild_2eproject_2estr_24cpr_str0)});
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2414}});
  }
  case TAG_LList: {
    V v_t_2425;
    switch (heff_tag_of(v_x_240)) {
    case TAG_LStr: {
      V v_t_2418 = heff_field(v_x_240, 1);
      heff_take_n(v_x_240, 2ULL, 2);
      v_t_2425 = v_t_2418;
      break;
    }
    case TAG_LTag: {
      V v_t_2420 = heff_field(v_x_240, 1);
      heff_take_n(v_x_240, 2ULL, 2);
      v_t_2425 = v_t_2420;
      break;
    }
    case TAG_LList: {
      V v_t_2422 = heff_field(v_x_240, 1);
      heff_take_n(v_x_240, 2ULL, 2);
      v_t_2425 = v_t_2422;
      break;
    }
    case TAG_LRec: {
      V v_t_2424 = heff_field(v_x_240, 1);
      heff_take_n(v_x_240, 2ULL, 2);
      v_t_2425 = v_t_2424;
      break;
    }
    default: heff_nomatch(v_x_240);
    }
    V v_f_2426 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2425, 2, 7), ((V)&g_heff_2ebuild_2eproject_2estr_24cpr_str1)});
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2426}});
  }
  case TAG_LRec: {
    V v_t_2437;
    switch (heff_tag_of(v_x_240)) {
    case TAG_LStr: {
      V v_t_2430 = heff_field(v_x_240, 1);
      heff_take_n(v_x_240, 2ULL, 2);
      v_t_2437 = v_t_2430;
      break;
    }
    case TAG_LTag: {
      V v_t_2432 = heff_field(v_x_240, 1);
      heff_take_n(v_x_240, 2ULL, 2);
      v_t_2437 = v_t_2432;
      break;
    }
    case TAG_LList: {
      V v_t_2434 = heff_field(v_x_240, 1);
      heff_take_n(v_x_240, 2ULL, 2);
      v_t_2437 = v_t_2434;
      break;
    }
    case TAG_LRec: {
      V v_t_2436 = heff_field(v_x_240, 1);
      heff_take_n(v_x_240, 2ULL, 2);
      v_t_2437 = v_t_2436;
      break;
    }
    default: heff_nomatch(v_x_240);
    }
    V v_f_2438 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2437, 2, 7), ((V)&g_heff_2ebuild_2eproject_2estr_24cpr_str2)});
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2438}});
  }
  default: return ((HeffT2){{heff_nomatch(v_x_240)}});
  }
}
HEFF_LIT(g_heff_2ebuild_2eproject_2enameOf_24cpr_str0, 25, "` cannot name a package: ");
HEFF_LIT(g_heff_2ebuild_2eproject_2enameOf_24cpr_str1, 1, "`");

HeffT2 g_heff_2ebuild_2eproject_2enameOf_24cpr(V v_x_240) {
top: ;
  HeffT2 v_t_241 = (g_heff_2ebuild_2eproject_2estr_24cpr(heff_dup(v_x_240)));
  {
    V v_field_243 = v_t_241.f[1];
    int64_t v_tag_242 = ((int64_t)v_t_241.f[0]);
    if ((v_tag_242 == ((int64_t)0ULL))) {
      heff_drop(v_x_240);
      V v_p_245 = v_field_243;
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_p_245}});
    } else {
      V v_n_246 = v_field_243;
      HeffT2 v_t_247 = (g_heff_2ebuild_2eproject_2ewhyNoName_24cpr(v_n_246));
      {
        V v_field_249 = v_t_247.f[1];
        int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
        if ((v_tag_248 == ((int64_t)0ULL))) {
          V v_why_2411 = v_field_249;
          V v_t_2420;
          switch (heff_tag_of(v_x_240)) {
          case TAG_LStr: {
            V v_t_2413 = heff_field(v_x_240, 1);
            heff_take_n(v_x_240, 2ULL, 2);
            v_t_2420 = v_t_2413;
            break;
          }
          case TAG_LTag: {
            V v_t_2415 = heff_field(v_x_240, 1);
            heff_take_n(v_x_240, 2ULL, 2);
            v_t_2420 = v_t_2415;
            break;
          }
          case TAG_LList: {
            V v_t_2417 = heff_field(v_x_240, 1);
            heff_take_n(v_x_240, 2ULL, 2);
            v_t_2420 = v_t_2417;
            break;
          }
          case TAG_LRec: {
            V v_t_2419 = heff_field(v_x_240, 1);
            heff_take_n(v_x_240, 2ULL, 2);
            v_t_2420 = v_t_2419;
            break;
          }
          default: heff_nomatch(v_x_240);
          }
          V v_t_2421 = heff_strAppend(v_n_246, heff_strAppend(((V)&g_heff_2ebuild_2eproject_2enameOf_24cpr_str0), v_why_2411));
          V v_f_2422 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2420, 2, 7), heff_strAppend(((V)&g_heff_2ebuild_2eproject_2enameOf_24cpr_str1), v_t_2421)});
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2422}});
        } else {
          heff_drop(v_x_240);
          heff_drop(v_field_249);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_n_246}});
        }
      }
    }
  }
}
HEFF_LIT(g_heff_2ebuild_2eproject_2emajorMismatch_24cpr_str0, 1, "v");
HEFF_LIT(g_heff_2ebuild_2eproject_2emajorMismatch_24cpr_str1, 1, "/");
HEFF_LIT(g_heff_2ebuild_2eproject_2emajorMismatch_24cpr_str2, 1, "/");
HEFF_LIT(g_heff_2ebuild_2eproject_2emajorMismatch_24cpr_str3, 1, "v");
HEFF_LIT(g_heff_2ebuild_2eproject_2emajorMismatch_24cpr_str4, 8, "version ");
HEFF_LIT(g_heff_2ebuild_2eproject_2emajorMismatch_24cpr_str5, 44, " is fetched from a path without a /vN ending");
HEFF_LIT(g_heff_2ebuild_2eproject_2emajorMismatch_24cpr_str6, 1, "/");
HEFF_LIT(g_heff_2ebuild_2eproject_2emajorMismatch_24cpr_str7, 1, "/");
HEFF_LIT(g_heff_2ebuild_2eproject_2emajorMismatch_24cpr_str8, 35, " is fetched from a path ending in /");
HEFF_LIT(g_heff_2ebuild_2eproject_2emajorMismatch_24cpr_str9, 8, "version ");

HeffT2 g_heff_2ebuild_2eproject_2emajorMismatch_24cpr(V v_path_240, V v_v_241) {
top: ;
  HeffT2 v_t_242 = (g_heff_2ebuild_2eproject_2eversion_24cpr(v_v_241));
  {
    V v_field_244 = v_t_242.f[1];
    int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
    V v_n_249;
    if ((v_tag_243 == ((int64_t)0ULL))) {
      V v_x_246 = v_field_244;
      switch (heff_tag_of(v_x_246)) {
      case TAG_Nil: {
        v_n_249 = MK_INT(0LL);
        break;
      }
      case TAG_Cons: {
        V v_x_247 = heff_field(v_x_246, 0);
        heff_take_n(v_x_246, 1ULL, 2);
        v_n_249 = v_x_247;
        break;
      }
      default: heff_nomatch(v_x_246);
      }
    } else {
      heff_drop(v_field_244);
      v_n_249 = MK_INT(0LL);
    }
    V v_t_2412;
    if (heff_intLe_c_lent(MK_INT(2LL), v_n_249, 1)) {
      V v_t_2411 = heff_strAppend(((V)&g_heff_2ebuild_2eproject_2emajorMismatch_24cpr_str0), heff_intShow(v_n_249));
      v_t_2412 = heff_tag_n(TAG_Just, 1, (V[]){v_t_2411});
    } else {
      heff_drop(v_n_249);
      v_t_2412 = NTAG(TAG_Nothing);
    }
    switch (heff_tag_of(v_t_2412)) {
    case TAG_Nothing: {
      V v_xs_2413 = ({ V b_0 = ((V)&g_heff_2ebuild_2eproject_2emajorMismatch_24cpr_str1); V a_1 = v_path_240; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2eproject_2emajorMismatch_24cpr_str2), v_path_240, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
      V v_t_2414 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2413));
      V v_x_2417;
      switch (heff_tag_of(v_t_2414)) {
      case TAG_Nil: {
        v_x_2417 = v_path_240;
        break;
      }
      case TAG_Cons: {
        V v_x_2415 = heff_field(v_t_2414, 0);
        heff_take_n(v_t_2414, 1ULL, 2);
        heff_drop(v_path_240);
        v_x_2417 = v_x_2415;
        break;
      }
      default: heff_nomatch(v_t_2414);
      }
      if ((((int64_t)2ULL) <= heff_unbox_word(heff_strLength_lent(v_x_2417, 0)))) {
        if (heff_strEq_c(heff_strSlice_lent(v_x_2417, MK_INT(0LL), MK_INT(1LL), 6), ((V)&g_heff_2ebuild_2eproject_2emajorMismatch_24cpr_str3))) {
          V v_t_2420 = heff_strSlice(heff_dup(v_x_2417), MK_INT(1LL), heff_strLength(v_x_2417));
          V v_t_2421 = ({ V a_0 = v_t_2420; V r_ = (g_heff_2ebuild_2eproject_2eisNumber(a_0)); heff_drop(v_t_2420); r_; });
          if ((heff_dup(v_t_2421) == NTAG(TAG_True))) {
            heff_drop(v_t_2421);
            V v_f_2422 = heff_strAppend(((V)&g_heff_2ebuild_2eproject_2emajorMismatch_24cpr_str4), heff_strAppend(v_v_241, ((V)&g_heff_2ebuild_2eproject_2emajorMismatch_24cpr_str5)));
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2422}});
          } else {
            heff_drop(v_v_241);
            heff_drop(v_t_2421);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
        } else {
          heff_drop(v_v_241);
          heff_drop(v_x_2417);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
      } else {
        heff_drop(v_v_241);
        heff_drop(v_x_2417);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
    case TAG_Just: {
      V v_suffix_2423 = heff_field(v_t_2412, 0);
      heff_take_n(v_t_2412, 1ULL, 1);
      V v_xs_2424 = ({ V b_0 = ((V)&g_heff_2ebuild_2eproject_2emajorMismatch_24cpr_str6); V a_1 = v_path_240; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2eproject_2emajorMismatch_24cpr_str7), v_path_240, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
      V v_t_2425 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2424));
      V v_t_2428;
      switch (heff_tag_of(v_t_2425)) {
      case TAG_Nil: {
        v_t_2428 = v_path_240;
        break;
      }
      case TAG_Cons: {
        V v_x_2426 = heff_field(v_t_2425, 0);
        heff_take_n(v_t_2425, 1ULL, 2);
        heff_drop(v_path_240);
        v_t_2428 = v_x_2426;
        break;
      }
      default: heff_nomatch(v_t_2425);
      }
      if (heff_strEq_c_lent(v_t_2428, v_suffix_2423, 1)) {
        heff_drop(v_v_241);
        heff_drop(v_suffix_2423);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      } else {
        V v_t_2430 = heff_strAppend(v_v_241, heff_strAppend(((V)&g_heff_2ebuild_2eproject_2emajorMismatch_24cpr_str8), v_suffix_2423));
        V v_f_2431 = heff_strAppend(((V)&g_heff_2ebuild_2eproject_2emajorMismatch_24cpr_str9), v_t_2430);
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2431}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_t_2412)}});
    }
  }
}

HeffT2 g_heff_2ebuild_2eproject_2etwiceGo_24cpr(V v_seen_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_seen_240);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_MkPair: {
      V v_n_244 = heff_field(v_x21_242, 0);
      V v_x_245 = heff_field(v_x21_242, 1);
      V v_ru_24x21_242_24MkPair = heff_take_reuse_n(v_x21_242, 3ULL, 2);
      V v_t_246 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(v_n_244)}));
      V v_t_247 = (g_list_2eany(v_t_246, v_seen_240));
      if ((heff_dup(v_t_247) == NTAG(TAG_True))) {
        heff_drop(v_seen_240);
        heff_drop(v_rest_243);
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        heff_drop(v_t_247);
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24x21_242_24MkPair, TAG_MkPair, 2, (V[]){v_n_244, v_x_245})}});
      } else {
        heff_drop(v_x_245);
        heff_drop_cell(v_ru_24x21_242_24MkPair, 2);
        heff_drop(v_t_247);
        V t_0 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_n_244, v_seen_240});
        V t_1 = v_rest_243;
        v_seen_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x21_242)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
HEFF_LIT(g_heff_2ebuild_2eproject_2eheffModule_str0, 4, "heff");

static V g_heff_2ebuild_2eproject_2eheffModule_val;
static HEFF_ONCE g_heff_2ebuild_2eproject_2eheffModule_st;
static V g_heff_2ebuild_2eproject_2eheffModule_init(void) {
  return ((V)&g_heff_2ebuild_2eproject_2eheffModule_str0);
}
V g_heff_2ebuild_2eproject_2eheffModule_get(void) {
  if (HEFF_DONE(g_heff_2ebuild_2eproject_2eheffModule_st)) return g_heff_2ebuild_2eproject_2eheffModule_val;
  return heff_global(&g_heff_2ebuild_2eproject_2eheffModule_val, &g_heff_2ebuild_2eproject_2eheffModule_st, g_heff_2ebuild_2eproject_2eheffModule_init);
}
HEFF_LIT(g_heff_2ebuild_2eproject_2erequireMsg_str0, 89, "error[E0347]: the package `heff` is heff's own, which comes with heff: it is not required");

static V g_heff_2ebuild_2eproject_2erequireMsg_val;
static HEFF_ONCE g_heff_2ebuild_2eproject_2erequireMsg_st;
static V g_heff_2ebuild_2eproject_2erequireMsg_init(void) {
  return ((V)&g_heff_2ebuild_2eproject_2erequireMsg_str0);
}
V g_heff_2ebuild_2eproject_2erequireMsg_get(void) {
  if (HEFF_DONE(g_heff_2ebuild_2eproject_2erequireMsg_st)) return g_heff_2ebuild_2eproject_2erequireMsg_val;
  return heff_global(&g_heff_2ebuild_2eproject_2erequireMsg_val, &g_heff_2ebuild_2eproject_2erequireMsg_st, g_heff_2ebuild_2eproject_2erequireMsg_init);
}

HeffT2 g_heff_2ebuild_2eproject_2efirstNamed_24cpr(V v_names_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_MkPair: {
      V v_n_244 = heff_field(v_x21_242, 0);
      V v_x_245 = heff_field(v_x21_242, 1);
      heff_take_n(v_x21_242, 3ULL, 2);
      V v_t_246 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(v_n_244)}));
      V v_t_247 = (g_list_2eany(v_t_246, v_names_240));
      if ((heff_dup(v_t_247) == NTAG(TAG_True))) {
        heff_drop(v_rest_243);
        heff_drop(v_t_247);
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_MkPair, 2, (V[]){v_n_244, v_x_245})}});
      } else {
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        heff_drop(v_n_244);
        heff_drop(v_x_245);
        heff_drop(v_t_247);
        V t_0 = v_names_240;
        V t_1 = v_rest_243;
        v_names_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x21_242)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
HEFF_LIT(g_heff_2ebuild_2eproject_2echeckHeff_24cpr_str0, 1, "`");
HEFF_LIT(g_heff_2ebuild_2eproject_2echeckHeff_24cpr_str1, 78, "` is the package `heff`, heff's own, which comes with heff: it is not replaced");
HEFF_LIT(g_heff_2ebuild_2eproject_2echeckHeff_24cpr_str2, 14, "error[E0347]: ");

HeffT2 g_heff_2ebuild_2eproject_2echeckHeff_24cpr(V v_rxs_240, V v_rs_241, V v_pxs_242, V v_ps_243) {
top: ;
  V v_t_244 = (g_list_2emap_24f1156519715x726760149(heff_dup(v_rs_241)));
  V v_t_245 = (g_list_2ezipWith_24s1958630276x749154843(v_pxs_242, v_ps_243));
  HeffT2 v_t_246 = ({ V a_0 = v_t_244; V a_1 = v_t_245; HeffT2 r_ = (g_heff_2ebuild_2eproject_2efirstNamed_24cpr(a_0, a_1)); heff_drop(v_t_244); r_; });
  {
    V v_field_248 = v_t_246.f[1];
    int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
    if ((v_tag_247 == ((int64_t)0ULL))) {
      heff_drop(v_rxs_240);
      heff_drop(v_rs_241);
      V v_it1_2410 = v_field_248;
      switch (heff_tag_of(v_it1_2410)) {
      case TAG_MkPair: {
        V v_n_2411 = heff_field(v_it1_2410, 0);
        V v_x_2412 = heff_field(v_it1_2410, 1);
        heff_take_n(v_it1_2410, 3ULL, 2);
        V v_t_2421;
        switch (heff_tag_of(v_x_2412)) {
        case TAG_LStr: {
          V v_t_2414 = heff_field(v_x_2412, 1);
          heff_take_n(v_x_2412, 2ULL, 2);
          v_t_2421 = v_t_2414;
          break;
        }
        case TAG_LTag: {
          V v_t_2416 = heff_field(v_x_2412, 1);
          heff_take_n(v_x_2412, 2ULL, 2);
          v_t_2421 = v_t_2416;
          break;
        }
        case TAG_LList: {
          V v_t_2418 = heff_field(v_x_2412, 1);
          heff_take_n(v_x_2412, 2ULL, 2);
          v_t_2421 = v_t_2418;
          break;
        }
        case TAG_LRec: {
          V v_t_2420 = heff_field(v_x_2412, 1);
          heff_take_n(v_x_2412, 2ULL, 2);
          v_t_2421 = v_t_2420;
          break;
        }
        default: heff_nomatch(v_x_2412);
        }
        V v_t_2422 = heff_strAppend(((V)&g_heff_2ebuild_2eproject_2echeckHeff_24cpr_str0), heff_strAppend(v_n_2411, ((V)&g_heff_2ebuild_2eproject_2echeckHeff_24cpr_str1)));
        V v_f_2423 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2421, 2, 7), heff_strAppend(((V)&g_heff_2ebuild_2eproject_2echeckHeff_24cpr_str2), v_t_2422)});
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2423}});
      }
      default: return ((HeffT2){{heff_nomatch(v_it1_2410)}});
      }
    } else {
      heff_drop(v_field_248);
      V v_t_2424 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(g_heff_2ebuild_2eproject_2eheffModule_get()), NTAG(TAG_Nil)});
      V v_t_2425 = (g_list_2ezipWith_24s29557946x653938035(v_rxs_240, v_rs_241));
      HeffT2 v_t_2426 = ({ V a_0 = v_t_2424; V a_1 = v_t_2425; HeffT2 r_ = (g_heff_2ebuild_2eproject_2efirstNamed_24cpr(a_0, a_1)); heff_drop_tag(v_t_2424, 2); r_; });
      {
        V v_field_2428 = v_t_2426.f[1];
        int64_t v_tag_2427 = ((int64_t)v_t_2426.f[0]);
        if ((v_tag_2427 == ((int64_t)0ULL))) {
          V v_it1_2430 = v_field_2428;
          switch (heff_tag_of(v_it1_2430)) {
          case TAG_MkPair: {
            V v_x_2432 = heff_field(v_it1_2430, 1);
            heff_take_n(v_it1_2430, 2ULL, 2);
            V v_t_2441;
            switch (heff_tag_of(v_x_2432)) {
            case TAG_LStr: {
              V v_t_2434 = heff_field(v_x_2432, 1);
              heff_take_n(v_x_2432, 2ULL, 2);
              v_t_2441 = v_t_2434;
              break;
            }
            case TAG_LTag: {
              V v_t_2436 = heff_field(v_x_2432, 1);
              heff_take_n(v_x_2432, 2ULL, 2);
              v_t_2441 = v_t_2436;
              break;
            }
            case TAG_LList: {
              V v_t_2438 = heff_field(v_x_2432, 1);
              heff_take_n(v_x_2432, 2ULL, 2);
              v_t_2441 = v_t_2438;
              break;
            }
            case TAG_LRec: {
              V v_t_2440 = heff_field(v_x_2432, 1);
              heff_take_n(v_x_2432, 2ULL, 2);
              v_t_2441 = v_t_2440;
              break;
            }
            default: heff_nomatch(v_x_2432);
            }
            V v_f_2442 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2441, 2, 7), heff_dup(g_heff_2ebuild_2eproject_2erequireMsg_get())});
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2442}});
          }
          default: return ((HeffT2){{heff_nomatch(v_it1_2430)}});
          }
        } else {
          heff_drop(v_field_2428);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), NTAG(TAG_MkUnit)}});
        }
      }
    }
  }
}

HeffT2 g_heff_2ebuild_2eproject_2eallOf_24s2049964666x1020559920_24cpr(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), NTAG(TAG_Nil)}});
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_rest_242 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    HeffT2 v_t_243 = (g_heff_2ebuild_2eproject_2erequireOf_24cpr(v_x_241));
    {
      V v_field_245 = v_t_243.f[1];
      int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
      HeffT2 v_t_246 = (g_heff_2ebuild_2eproject_2eallOf_24s2049964666x1020559920_24cpr(v_rest_242));
      {
        V v_field_248 = v_t_246.f[1];
        int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
        if ((v_tag_244 == ((int64_t)0ULL))) {
          heff_drop_cell(v_ru_24x2_240_24Cons, 2);
          heff_drop(v_field_248);
          V v_p_2410 = v_field_245;
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_p_2410}});
        } else {
          V v_y_2411 = v_field_245;
          if ((v_tag_247 == ((int64_t)0ULL))) {
            heff_drop_cell(v_ru_24x2_240_24Cons, 2);
            heff_drop(v_y_2411);
            V v_p_2413 = v_field_248;
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_p_2413}});
          } else {
            V v_ys_2414 = v_field_248;
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_y_2411, v_ys_2414})}});
          }
        }
      }
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_240)}});
  }
}
HEFF_LIT(g_heff_2ebuild_2eproject_2epackageOf_24cpr_str0, 25, "expected a record `{...}`");
HEFF_LIT(g_heff_2ebuild_2eproject_2epackageOf_24cpr_str1, 25, "expected a record `{...}`");
HEFF_LIT(g_heff_2ebuild_2eproject_2epackageOf_24cpr_str2, 25, "expected a record `{...}`");
HEFF_LIT(g_heff_2ebuild_2eproject_2epackageOf_24cpr_str3, 25, "expected a record `{...}`");
HEFF_LIT(g_heff_2ebuild_2eproject_2epackageOf_24cpr_str4, 25, "expected a record `{...}`");

HeffT2 g_heff_2ebuild_2eproject_2epackageOf_24cpr(V v_x_240) {
top: ;
  HeffT2 v_t_241 = (g_heff_2ebuild_2eproject_2efieldsAre_24cpr(heff_dup(g_heff_2ebuild_2eproject_2epackageFields_get()), heff_dup(v_x_240)));
  {
    V v_field_243 = v_t_241.f[1];
    int64_t v_tag_242 = ((int64_t)v_t_241.f[0]);
    if ((v_tag_242 == ((int64_t)0ULL))) {
      heff_drop(v_x_240);
      V v_p_245 = v_field_243;
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_p_245}});
    } else {
      V v_it1_246 = v_field_243;
      switch (heff_tag_of(v_it1_246)) {
      case TAG_Nil: {
        V v_t_2415;
        switch (heff_tag_of(v_x_240)) {
        case TAG_LStr: {
          V v_t_248 = heff_field(v_x_240, 1);
          heff_take_n(v_x_240, 2ULL, 2);
          v_t_2415 = v_t_248;
          break;
        }
        case TAG_LTag: {
          V v_t_2410 = heff_field(v_x_240, 1);
          heff_take_n(v_x_240, 2ULL, 2);
          v_t_2415 = v_t_2410;
          break;
        }
        case TAG_LList: {
          V v_t_2412 = heff_field(v_x_240, 1);
          heff_take_n(v_x_240, 2ULL, 2);
          v_t_2415 = v_t_2412;
          break;
        }
        case TAG_LRec: {
          V v_t_2414 = heff_field(v_x_240, 1);
          heff_take_n(v_x_240, 2ULL, 2);
          v_t_2415 = v_t_2414;
          break;
        }
        default: heff_nomatch(v_x_240);
        }
        V v_f_2416 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2415, 2, 7), ((V)&g_heff_2ebuild_2eproject_2epackageOf_24cpr_str0)});
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2416}});
      }
      case TAG_Cons: {
        V v_m_2417 = heff_field(v_it1_246, 0);
        V v_it12_2418 = heff_field(v_it1_246, 1);
        heff_take_n(v_it1_246, 3ULL, 2);
        switch (heff_tag_of(v_it12_2418)) {
        case TAG_Nil: {
          heff_drop(v_m_2417);
          V v_t_2427;
          switch (heff_tag_of(v_x_240)) {
          case TAG_LStr: {
            V v_t_2420 = heff_field(v_x_240, 1);
            heff_take_n(v_x_240, 2ULL, 2);
            v_t_2427 = v_t_2420;
            break;
          }
          case TAG_LTag: {
            V v_t_2422 = heff_field(v_x_240, 1);
            heff_take_n(v_x_240, 2ULL, 2);
            v_t_2427 = v_t_2422;
            break;
          }
          case TAG_LList: {
            V v_t_2424 = heff_field(v_x_240, 1);
            heff_take_n(v_x_240, 2ULL, 2);
            v_t_2427 = v_t_2424;
            break;
          }
          case TAG_LRec: {
            V v_t_2426 = heff_field(v_x_240, 1);
            heff_take_n(v_x_240, 2ULL, 2);
            v_t_2427 = v_t_2426;
            break;
          }
          default: heff_nomatch(v_x_240);
          }
          V v_f_2428 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2427, 2, 7), ((V)&g_heff_2ebuild_2eproject_2epackageOf_24cpr_str1)});
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2428}});
        }
        case TAG_Cons: {
          V v_h_2429 = heff_field(v_it12_2418, 0);
          V v_it122_2430 = heff_field(v_it12_2418, 1);
          heff_take_n(v_it12_2418, 3ULL, 2);
          switch (heff_tag_of(v_it122_2430)) {
          case TAG_Nil: {
            heff_drop(v_m_2417);
            heff_drop(v_h_2429);
            V v_t_2439;
            switch (heff_tag_of(v_x_240)) {
            case TAG_LStr: {
              V v_t_2432 = heff_field(v_x_240, 1);
              heff_take_n(v_x_240, 2ULL, 2);
              v_t_2439 = v_t_2432;
              break;
            }
            case TAG_LTag: {
              V v_t_2434 = heff_field(v_x_240, 1);
              heff_take_n(v_x_240, 2ULL, 2);
              v_t_2439 = v_t_2434;
              break;
            }
            case TAG_LList: {
              V v_t_2436 = heff_field(v_x_240, 1);
              heff_take_n(v_x_240, 2ULL, 2);
              v_t_2439 = v_t_2436;
              break;
            }
            case TAG_LRec: {
              V v_t_2438 = heff_field(v_x_240, 1);
              heff_take_n(v_x_240, 2ULL, 2);
              v_t_2439 = v_t_2438;
              break;
            }
            default: heff_nomatch(v_x_240);
            }
            V v_f_2440 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2439, 2, 7), ((V)&g_heff_2ebuild_2eproject_2epackageOf_24cpr_str2)});
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2440}});
          }
          case TAG_Cons: {
            V v_rq_2441 = heff_field(v_it122_2430, 0);
            V v_it1222_2442 = heff_field(v_it122_2430, 1);
            heff_take_n(v_it122_2430, 3ULL, 2);
            switch (heff_tag_of(v_it1222_2442)) {
            case TAG_Nil: {
              heff_drop(v_m_2417);
              heff_drop(v_h_2429);
              heff_drop(v_rq_2441);
              V v_t_2451;
              switch (heff_tag_of(v_x_240)) {
              case TAG_LStr: {
                V v_t_2444 = heff_field(v_x_240, 1);
                heff_take_n(v_x_240, 2ULL, 2);
                v_t_2451 = v_t_2444;
                break;
              }
              case TAG_LTag: {
                V v_t_2446 = heff_field(v_x_240, 1);
                heff_take_n(v_x_240, 2ULL, 2);
                v_t_2451 = v_t_2446;
                break;
              }
              case TAG_LList: {
                V v_t_2448 = heff_field(v_x_240, 1);
                heff_take_n(v_x_240, 2ULL, 2);
                v_t_2451 = v_t_2448;
                break;
              }
              case TAG_LRec: {
                V v_t_2450 = heff_field(v_x_240, 1);
                heff_take_n(v_x_240, 2ULL, 2);
                v_t_2451 = v_t_2450;
                break;
              }
              default: heff_nomatch(v_x_240);
              }
              V v_f_2452 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2451, 2, 7), ((V)&g_heff_2ebuild_2eproject_2epackageOf_24cpr_str3)});
              return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2452}});
            }
            case TAG_Cons: {
              V v_rp_2453 = heff_field(v_it1222_2442, 0);
              V v_it12222_2454 = heff_field(v_it1222_2442, 1);
              heff_take_n(v_it1222_2442, 3ULL, 2);
              switch (heff_tag_of(v_it12222_2454)) {
              case TAG_Nil: {
                heff_drop(v_x_240);
                return (g_heff_2ebuild_2eproject_2epackageOf4_24cpr(v_m_2417, v_h_2429, v_rq_2441, v_rp_2453));
              }
              case TAG_Cons: {
                heff_take_n(v_it12222_2454, 0ULL, 2);
                heff_drop(v_m_2417);
                heff_drop(v_h_2429);
                heff_drop(v_rq_2441);
                heff_drop(v_rp_2453);
                V v_t_2465;
                switch (heff_tag_of(v_x_240)) {
                case TAG_LStr: {
                  V v_t_2458 = heff_field(v_x_240, 1);
                  heff_take_n(v_x_240, 2ULL, 2);
                  v_t_2465 = v_t_2458;
                  break;
                }
                case TAG_LTag: {
                  V v_t_2460 = heff_field(v_x_240, 1);
                  heff_take_n(v_x_240, 2ULL, 2);
                  v_t_2465 = v_t_2460;
                  break;
                }
                case TAG_LList: {
                  V v_t_2462 = heff_field(v_x_240, 1);
                  heff_take_n(v_x_240, 2ULL, 2);
                  v_t_2465 = v_t_2462;
                  break;
                }
                case TAG_LRec: {
                  V v_t_2464 = heff_field(v_x_240, 1);
                  heff_take_n(v_x_240, 2ULL, 2);
                  v_t_2465 = v_t_2464;
                  break;
                }
                default: heff_nomatch(v_x_240);
                }
                V v_f_2466 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2465, 2, 7), ((V)&g_heff_2ebuild_2eproject_2epackageOf_24cpr_str4)});
                return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2466}});
              }
              default: return ((HeffT2){{heff_nomatch(v_it12222_2454)}});
              }
            }
            default: return ((HeffT2){{heff_nomatch(v_it1222_2442)}});
            }
          }
          default: return ((HeffT2){{heff_nomatch(v_it122_2430)}});
          }
        }
        default: return ((HeffT2){{heff_nomatch(v_it12_2418)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_it1_246)}});
      }
    }
  }
}
HEFF_LIT(g_heff_2ebuild_2eproject_2epackageLit_24cpr_str0, 10, "package.hf");
HEFF_LIT(g_heff_2ebuild_2eproject_2epackageLit_24cpr_str1, 7, "package");

HeffT2 g_heff_2ebuild_2eproject_2epackageLit_24cpr(V v_src_240) {
top: ;
  V v_t_241 = heff_rec_n(7, shape_i__line__lineStart__first__tok__err__cmt, (V[]){MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_True), NTAG(TAG_Nothing), NTAG(TAG_Nothing), NTAG(TAG_Nothing)});
  HeffT3 v_t_242 = (g_heff_2esyntax_2efmt_2elex_2elexGo_24cpr(v_src_240, v_t_241, NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil)));
  {
    V v_field_244 = v_t_242.f[1];
    heff_drop(v_t_242.f[0]);
    heff_drop(v_t_242.f[2]);
    switch (heff_tag_of(v_field_244)) {
    case TAG_Nil: {
      V v_t_246 = heff_rec_n(7, shape_i__line__lineStart__first__tok__err__cmt, (V[]){MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_True), NTAG(TAG_Nothing), NTAG(TAG_Nothing), NTAG(TAG_Nothing)});
      HeffT3 v_t_247 = (g_heff_2esyntax_2efmt_2elex_2elexGo_24cpr(v_src_240, v_t_246, NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil)));
      V v_t_2411;
      {
        V v_field_248 = v_t_247.f[0];
        heff_drop(v_t_247.f[1]);
        heff_drop(v_t_247.f[2]);
        v_t_2411 = v_field_248;
      }
      return ({ V a_0 = ((V)&g_heff_2ebuild_2eproject_2epackageLit_24cpr_str0); V a_1 = ((V)&g_heff_2ebuild_2eproject_2epackageLit_24cpr_str1); V b_2 = heff_arrayFromList(v_t_2411); V a_3 = MK_INT(0LL); V a_4 = NTAG(TAG_Nothing); HeffT2 r_ = (g_heff_2ebuild_2eproject_2edeclsGo_24cpr(a_0, a_1, b_2, a_3, a_4)); heff_drop(b_2); r_; });
    }
    case TAG_Cons: {
      V v_e_2412 = heff_field(v_field_244, 0);
      heff_take_n(v_field_244, 1ULL, 2);
      V v_f_2414 = heff_rec_n(2, shape_at__msg, (V[]){heff_take_field(v_e_2412, 0), heff_get_n(v_e_2412, 2, 3)});
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2414}});
    }
    default: return ((HeffT2){{heff_nomatch(v_field_244)}});
    }
  }
}
Clo g_heff_2ebuild_2eproject_2epackageLit_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eproject_2epackageLit_entry, 1, 0};

V g_heff_2ebuild_2eproject_2epackageLit(V v_src_240) {
top: ;
  HeffT2 v_t_241 = (g_heff_2ebuild_2eproject_2epackageLit_24cpr(v_src_240));
  {
    V v_field_243 = v_t_241.f[1];
    int64_t v_tag_242 = ((int64_t)v_t_241.f[0]);
    if ((v_tag_242 == ((int64_t)0ULL))) {
      return heff_tag_n(TAG_Left, 1, (V[]){v_field_243});
    } else {
      return heff_tag_n(TAG_Right, 1, (V[]){v_field_243});
    }
  }
}
V g_heff_2ebuild_2eproject_2epackageLit_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2eproject_2epackageLit(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ebuild_2eproject_2ebackendOf_24cpr_str0, 29, "expected a backend: C or Page");
HEFF_LIT(g_heff_2ebuild_2eproject_2ebackendOf_24cpr_str1, 1, "C");
HEFF_LIT(g_heff_2ebuild_2eproject_2ebackendOf_24cpr_str2, 1, "c");
HEFF_LIT(g_heff_2ebuild_2eproject_2ebackendOf_24cpr_str3, 4, "Page");
HEFF_LIT(g_heff_2ebuild_2eproject_2ebackendOf_24cpr_str4, 4, "page");
HEFF_LIT(g_heff_2ebuild_2eproject_2ebackendOf_24cpr_str5, 11, "no backend ");
HEFF_LIT(g_heff_2ebuild_2eproject_2ebackendOf_24cpr_str6, 11, ": C or Page");
HEFF_LIT(g_heff_2ebuild_2eproject_2ebackendOf_24cpr_str7, 29, "expected a backend: C or Page");
HEFF_LIT(g_heff_2ebuild_2eproject_2ebackendOf_24cpr_str8, 29, "expected a backend: C or Page");

HeffT2 g_heff_2ebuild_2eproject_2ebackendOf_24cpr(V v_x_240) {
top: ;
  switch (heff_tag_of(v_x_240)) {
  case TAG_LStr: {
    V v_t_2411;
    switch (heff_tag_of(v_x_240)) {
    case TAG_LStr: {
      V v_t_244 = heff_field(v_x_240, 1);
      heff_take_n(v_x_240, 2ULL, 2);
      v_t_2411 = v_t_244;
      break;
    }
    case TAG_LTag: {
      V v_t_246 = heff_field(v_x_240, 1);
      heff_take_n(v_x_240, 2ULL, 2);
      v_t_2411 = v_t_246;
      break;
    }
    case TAG_LList: {
      V v_t_248 = heff_field(v_x_240, 1);
      heff_take_n(v_x_240, 2ULL, 2);
      v_t_2411 = v_t_248;
      break;
    }
    case TAG_LRec: {
      V v_t_2410 = heff_field(v_x_240, 1);
      heff_take_n(v_x_240, 2ULL, 2);
      v_t_2411 = v_t_2410;
      break;
    }
    default: heff_nomatch(v_x_240);
    }
    V v_f_2412 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2411, 2, 7), ((V)&g_heff_2ebuild_2eproject_2ebackendOf_24cpr_str0)});
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2412}});
  }
  case TAG_LTag: {
    V v_x1_2413 = heff_field(v_x_240, 0);
    V v_t_2414 = heff_field(v_x_240, 1);
    heff_take_n(v_x_240, 3ULL, 2);
    if (heff_strEq_c_lent(v_x1_2413, ((V)&g_heff_2ebuild_2eproject_2ebackendOf_24cpr_str1), 2)) {
      heff_drop(v_x1_2413);
      heff_drop_rec(v_t_2414, 7);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), ((V)&g_heff_2ebuild_2eproject_2ebackendOf_24cpr_str2)}});
    } else {
      if (heff_strEq_c_lent(v_x1_2413, ((V)&g_heff_2ebuild_2eproject_2ebackendOf_24cpr_str3), 2)) {
        heff_drop(v_x1_2413);
        heff_drop_rec(v_t_2414, 7);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), ((V)&g_heff_2ebuild_2eproject_2ebackendOf_24cpr_str4)}});
      } else {
        V v_t_2417 = heff_strAppend(((V)&g_heff_2ebuild_2eproject_2ebackendOf_24cpr_str5), heff_strAppend(v_x1_2413, ((V)&g_heff_2ebuild_2eproject_2ebackendOf_24cpr_str6)));
        V v_f_2418 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2414, 2, 7), v_t_2417});
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2418}});
      }
    }
  }
  case TAG_LList: {
    V v_t_2429;
    switch (heff_tag_of(v_x_240)) {
    case TAG_LStr: {
      V v_t_2422 = heff_field(v_x_240, 1);
      heff_take_n(v_x_240, 2ULL, 2);
      v_t_2429 = v_t_2422;
      break;
    }
    case TAG_LTag: {
      V v_t_2424 = heff_field(v_x_240, 1);
      heff_take_n(v_x_240, 2ULL, 2);
      v_t_2429 = v_t_2424;
      break;
    }
    case TAG_LList: {
      V v_t_2426 = heff_field(v_x_240, 1);
      heff_take_n(v_x_240, 2ULL, 2);
      v_t_2429 = v_t_2426;
      break;
    }
    case TAG_LRec: {
      V v_t_2428 = heff_field(v_x_240, 1);
      heff_take_n(v_x_240, 2ULL, 2);
      v_t_2429 = v_t_2428;
      break;
    }
    default: heff_nomatch(v_x_240);
    }
    V v_f_2430 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2429, 2, 7), ((V)&g_heff_2ebuild_2eproject_2ebackendOf_24cpr_str7)});
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2430}});
  }
  case TAG_LRec: {
    V v_t_2441;
    switch (heff_tag_of(v_x_240)) {
    case TAG_LStr: {
      V v_t_2434 = heff_field(v_x_240, 1);
      heff_take_n(v_x_240, 2ULL, 2);
      v_t_2441 = v_t_2434;
      break;
    }
    case TAG_LTag: {
      V v_t_2436 = heff_field(v_x_240, 1);
      heff_take_n(v_x_240, 2ULL, 2);
      v_t_2441 = v_t_2436;
      break;
    }
    case TAG_LList: {
      V v_t_2438 = heff_field(v_x_240, 1);
      heff_take_n(v_x_240, 2ULL, 2);
      v_t_2441 = v_t_2438;
      break;
    }
    case TAG_LRec: {
      V v_t_2440 = heff_field(v_x_240, 1);
      heff_take_n(v_x_240, 2ULL, 2);
      v_t_2441 = v_t_2440;
      break;
    }
    default: heff_nomatch(v_x_240);
    }
    V v_f_2442 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2441, 2, 7), ((V)&g_heff_2ebuild_2eproject_2ebackendOf_24cpr_str8)});
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2442}});
  }
  default: return ((HeffT2){{heff_nomatch(v_x_240)}});
  }
}
Clo g_heff_2ebuild_2eproject_2eallOf_24s622475081x394218744_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eproject_2eallOf_24s622475081x394218744_entry, 1, 0};

V g_heff_2ebuild_2eproject_2eallOf_24s622475081x394218744(V v_x2_240) {
top: ;
  HeffT2 v_t_241 = (g_heff_2ebuild_2eproject_2eallOf_24s622475081x394218744_24cpr(v_x2_240));
  {
    V v_field_243 = v_t_241.f[1];
    int64_t v_tag_242 = ((int64_t)v_t_241.f[0]);
    if ((v_tag_242 == ((int64_t)0ULL))) {
      return heff_tag_n(TAG_Left, 1, (V[]){v_field_243});
    } else {
      return heff_tag_n(TAG_Right, 1, (V[]){v_field_243});
    }
  }
}
V g_heff_2ebuild_2eproject_2eallOf_24s622475081x394218744_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eproject_2eallOf_24s622475081x394218744(a[0]);
}
HEFF_LIT(g_heff_2ebuild_2eproject_2ebuildOf_24cpr_str0, 7, "backend");
HEFF_LIT(g_heff_2ebuild_2eproject_2ebuildOf_24cpr_str1, 3, "run");
HEFF_LIT(g_heff_2ebuild_2eproject_2ebuildOf_24cpr_str2, 5, "ships");
HEFF_LIT(g_heff_2ebuild_2eproject_2ebuildOf_24cpr_str3, 25, "expected a record `{...}`");
HEFF_LIT(g_heff_2ebuild_2eproject_2ebuildOf_24cpr_str4, 25, "expected a record `{...}`");
HEFF_LIT(g_heff_2ebuild_2eproject_2ebuildOf_24cpr_str5, 25, "expected a record `{...}`");
HEFF_LIT(g_heff_2ebuild_2eproject_2ebuildOf_24cpr_str6, 25, "expected a record `{...}`");
V g_heff_2ebuild_2eproject_2ebuildOf_24cpr_lam0(V self, V *args); static Clo g_heff_2ebuild_2eproject_2ebuildOf_24cpr_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eproject_2ebuildOf_24cpr_lam0, 1, 0};

HeffT2 g_heff_2ebuild_2eproject_2ebuildOf_24cpr(V v_x_240) {
top: ;
  V v_t_241 = heff_rec_n(2, shape_name__left, (V[]){((V)&g_heff_2ebuild_2eproject_2ebuildOf_24cpr_str0), NTAG(TAG_Nothing)});
  V v_t_242 = heff_rec_n(2, shape_name__left, (V[]){((V)&g_heff_2ebuild_2eproject_2ebuildOf_24cpr_str1), NTAG(TAG_Nothing)});
  V v_t_244 = heff_rec_n(2, shape_name__left, (V[]){((V)&g_heff_2ebuild_2eproject_2ebuildOf_24cpr_str2), heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2ebuild_2eproject_2ebuildOf_24cpr_lam0_clo)})});
  V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_244, NTAG(TAG_Nil)});
  V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_241, heff_tag_n(TAG_Cons, 2, (V[]){v_t_242, v_t_245})});
  HeffT2 v_t_247 = (g_heff_2ebuild_2eproject_2efieldsAre_24cpr(v_t_246, heff_dup(v_x_240)));
  {
    V v_field_249 = v_t_247.f[1];
    int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
    if ((v_tag_248 == ((int64_t)0ULL))) {
      heff_drop(v_x_240);
      V v_p_2411 = v_field_249;
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_p_2411}});
    } else {
      V v_it1_2412 = v_field_249;
      switch (heff_tag_of(v_it1_2412)) {
      case TAG_Nil: {
        V v_t_2421;
        switch (heff_tag_of(v_x_240)) {
        case TAG_LStr: {
          V v_t_2414 = heff_field(v_x_240, 1);
          heff_take_n(v_x_240, 2ULL, 2);
          v_t_2421 = v_t_2414;
          break;
        }
        case TAG_LTag: {
          V v_t_2416 = heff_field(v_x_240, 1);
          heff_take_n(v_x_240, 2ULL, 2);
          v_t_2421 = v_t_2416;
          break;
        }
        case TAG_LList: {
          V v_t_2418 = heff_field(v_x_240, 1);
          heff_take_n(v_x_240, 2ULL, 2);
          v_t_2421 = v_t_2418;
          break;
        }
        case TAG_LRec: {
          V v_t_2420 = heff_field(v_x_240, 1);
          heff_take_n(v_x_240, 2ULL, 2);
          v_t_2421 = v_t_2420;
          break;
        }
        default: heff_nomatch(v_x_240);
        }
        V v_f_2422 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2421, 2, 7), ((V)&g_heff_2ebuild_2eproject_2ebuildOf_24cpr_str3)});
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2422}});
      }
      case TAG_Cons: {
        V v_b_2423 = heff_field(v_it1_2412, 0);
        V v_it12_2424 = heff_field(v_it1_2412, 1);
        heff_take_n(v_it1_2412, 3ULL, 2);
        switch (heff_tag_of(v_it12_2424)) {
        case TAG_Nil: {
          heff_drop(v_b_2423);
          V v_t_2433;
          switch (heff_tag_of(v_x_240)) {
          case TAG_LStr: {
            V v_t_2426 = heff_field(v_x_240, 1);
            heff_take_n(v_x_240, 2ULL, 2);
            v_t_2433 = v_t_2426;
            break;
          }
          case TAG_LTag: {
            V v_t_2428 = heff_field(v_x_240, 1);
            heff_take_n(v_x_240, 2ULL, 2);
            v_t_2433 = v_t_2428;
            break;
          }
          case TAG_LList: {
            V v_t_2430 = heff_field(v_x_240, 1);
            heff_take_n(v_x_240, 2ULL, 2);
            v_t_2433 = v_t_2430;
            break;
          }
          case TAG_LRec: {
            V v_t_2432 = heff_field(v_x_240, 1);
            heff_take_n(v_x_240, 2ULL, 2);
            v_t_2433 = v_t_2432;
            break;
          }
          default: heff_nomatch(v_x_240);
          }
          V v_f_2434 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2433, 2, 7), ((V)&g_heff_2ebuild_2eproject_2ebuildOf_24cpr_str4)});
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2434}});
        }
        case TAG_Cons: {
          V v_r_2435 = heff_field(v_it12_2424, 0);
          V v_it122_2436 = heff_field(v_it12_2424, 1);
          heff_take_n(v_it12_2424, 3ULL, 2);
          switch (heff_tag_of(v_it122_2436)) {
          case TAG_Nil: {
            heff_drop(v_b_2423);
            heff_drop(v_r_2435);
            V v_t_2445;
            switch (heff_tag_of(v_x_240)) {
            case TAG_LStr: {
              V v_t_2438 = heff_field(v_x_240, 1);
              heff_take_n(v_x_240, 2ULL, 2);
              v_t_2445 = v_t_2438;
              break;
            }
            case TAG_LTag: {
              V v_t_2440 = heff_field(v_x_240, 1);
              heff_take_n(v_x_240, 2ULL, 2);
              v_t_2445 = v_t_2440;
              break;
            }
            case TAG_LList: {
              V v_t_2442 = heff_field(v_x_240, 1);
              heff_take_n(v_x_240, 2ULL, 2);
              v_t_2445 = v_t_2442;
              break;
            }
            case TAG_LRec: {
              V v_t_2444 = heff_field(v_x_240, 1);
              heff_take_n(v_x_240, 2ULL, 2);
              v_t_2445 = v_t_2444;
              break;
            }
            default: heff_nomatch(v_x_240);
            }
            V v_f_2446 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2445, 2, 7), ((V)&g_heff_2ebuild_2eproject_2ebuildOf_24cpr_str5)});
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2446}});
          }
          case TAG_Cons: {
            V v_s_2447 = heff_field(v_it122_2436, 0);
            V v_it1222_2448 = heff_field(v_it122_2436, 1);
            heff_take_n(v_it122_2436, 3ULL, 2);
            switch (heff_tag_of(v_it1222_2448)) {
            case TAG_Nil: {
              heff_drop(v_x_240);
              HeffT2 v_t_2449 = (g_heff_2ebuild_2eproject_2ebackendOf_24cpr(v_b_2423));
              {
                V v_field_2451 = v_t_2449.f[1];
                int64_t v_tag_2450 = ((int64_t)v_t_2449.f[0]);
                if ((v_tag_2450 == ((int64_t)0ULL))) {
                  heff_drop(v_r_2435);
                  heff_drop(v_s_2447);
                  V v_p_2453 = v_field_2451;
                  return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_p_2453}});
                } else {
                  V v_backend_2454 = v_field_2451;
                  HeffT2 v_t_2455 = (g_heff_2ebuild_2eproject_2estr_24cpr(v_r_2435));
                  {
                    V v_field_2457 = v_t_2455.f[1];
                    int64_t v_tag_2456 = ((int64_t)v_t_2455.f[0]);
                    if ((v_tag_2456 == ((int64_t)0ULL))) {
                      heff_drop(v_s_2447);
                      heff_drop(v_backend_2454);
                      V v_p_2459 = v_field_2457;
                      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_p_2459}});
                    } else {
                      V v_run_2460 = v_field_2457;
                      HeffT2 v_t_2461 = (g_heff_2ebuild_2eproject_2eitems_24cpr(v_s_2447));
                      {
                        V v_field_2463 = v_t_2461.f[1];
                        int64_t v_tag_2462 = ((int64_t)v_t_2461.f[0]);
                        if ((v_tag_2462 == ((int64_t)0ULL))) {
                          heff_drop(v_backend_2454);
                          heff_drop(v_run_2460);
                          V v_p_2465 = v_field_2463;
                          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_p_2465}});
                        } else {
                          V v_xs_2466 = v_field_2463;
                          HeffT2 v_t_2467 = (g_heff_2ebuild_2eproject_2eallOf_24s622475081x394218744_24cpr(v_xs_2466));
                          {
                            V v_field_2469 = v_t_2467.f[1];
                            int64_t v_tag_2468 = ((int64_t)v_t_2467.f[0]);
                            if ((v_tag_2468 == ((int64_t)0ULL))) {
                              heff_drop(v_backend_2454);
                              heff_drop(v_run_2460);
                              V v_p_2471 = v_field_2469;
                              return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_p_2471}});
                            } else {
                              V v_ships_2472 = v_field_2469;
                              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), heff_rec_n(3, shape_backend__run__ships, (V[]){v_backend_2454, v_run_2460, v_ships_2472})}});
                            }
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
            case TAG_Cons: {
              heff_take_n(v_it1222_2448, 0ULL, 2);
              heff_drop(v_b_2423);
              heff_drop(v_r_2435);
              heff_drop(v_s_2447);
              V v_t_2483;
              switch (heff_tag_of(v_x_240)) {
              case TAG_LStr: {
                V v_t_2476 = heff_field(v_x_240, 1);
                heff_take_n(v_x_240, 2ULL, 2);
                v_t_2483 = v_t_2476;
                break;
              }
              case TAG_LTag: {
                V v_t_2478 = heff_field(v_x_240, 1);
                heff_take_n(v_x_240, 2ULL, 2);
                v_t_2483 = v_t_2478;
                break;
              }
              case TAG_LList: {
                V v_t_2480 = heff_field(v_x_240, 1);
                heff_take_n(v_x_240, 2ULL, 2);
                v_t_2483 = v_t_2480;
                break;
              }
              case TAG_LRec: {
                V v_t_2482 = heff_field(v_x_240, 1);
                heff_take_n(v_x_240, 2ULL, 2);
                v_t_2483 = v_t_2482;
                break;
              }
              default: heff_nomatch(v_x_240);
              }
              V v_f_2484 = heff_rec_n(2, shape_at__msg, (V[]){heff_get_n(v_t_2483, 2, 7), ((V)&g_heff_2ebuild_2eproject_2ebuildOf_24cpr_str6)});
              return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2484}});
            }
            default: return ((HeffT2){{heff_nomatch(v_it1222_2448)}});
            }
          }
          default: return ((HeffT2){{heff_nomatch(v_it122_2436)}});
          }
        }
        default: return ((HeffT2){{heff_nomatch(v_it12_2424)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_it1_2412)}});
      }
    }
  }
}
V g_heff_2ebuild_2eproject_2ebuildOf_24cpr_lam0(V self, V *args) {
  V v_t_243 = args[0];
  return heff_tag_n(TAG_LList, 2, (V[]){NTAG(TAG_Nil), v_t_243});
}
HEFF_LIT(g_heff_2ebuild_2eproject_2equoted_str0, 1, "\\");
HEFF_LIT(g_heff_2ebuild_2eproject_2equoted_str1, 1, "\\");
HEFF_LIT(g_heff_2ebuild_2eproject_2equoted_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2eproject_2equoted_str3, 2, "\\\\");
HEFF_LIT(g_heff_2ebuild_2eproject_2equoted_str4, 1, "\"");
HEFF_LIT(g_heff_2ebuild_2eproject_2equoted_str5, 1, "\"");
HEFF_LIT(g_heff_2ebuild_2eproject_2equoted_str6, 0, "");
HEFF_LIT(g_heff_2ebuild_2eproject_2equoted_str7, 2, "\\\"");
HEFF_LIT(g_heff_2ebuild_2eproject_2equoted_str8, 1, "\"");
HEFF_LIT(g_heff_2ebuild_2eproject_2equoted_str9, 1, "\"");
Clo g_heff_2ebuild_2eproject_2equoted_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eproject_2equoted_entry, 1, 0};

V g_heff_2ebuild_2eproject_2equoted(V v_s_240) {
top: ;
  V v_x2_241 = ({ V b_0 = ((V)&g_heff_2ebuild_2eproject_2equoted_str0); V a_1 = v_s_240; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2eproject_2equoted_str1), v_s_240, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
  V v_s_244;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    v_s_244 = ((V)&g_heff_2ebuild_2eproject_2equoted_str2);
    break;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    v_s_244 = ({ V a_0 = ((V)&g_heff_2ebuild_2eproject_2equoted_str3); V a_1 = v_x_242; V a_2 = v_xs_243; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_243); r_; });
    break;
  }
  default: heff_nomatch(v_x2_241);
  }
  V v_x2_245 = ({ V b_0 = ((V)&g_heff_2ebuild_2eproject_2equoted_str4); V a_1 = v_s_244; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2eproject_2equoted_str5), v_s_244, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); heff_drop(v_s_244); r_; });
  V v_t_248;
  switch (heff_tag_of(v_x2_245)) {
  case TAG_Nil: {
    v_t_248 = ((V)&g_heff_2ebuild_2eproject_2equoted_str6);
    break;
  }
  case TAG_Cons: {
    V v_x_246 = heff_field(v_x2_245, 0);
    V v_xs_247 = heff_field(v_x2_245, 1);
    heff_take_n(v_x2_245, 3ULL, 2);
    v_t_248 = ({ V a_0 = ((V)&g_heff_2ebuild_2eproject_2equoted_str7); V a_1 = v_x_246; V a_2 = v_xs_247; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_247); r_; });
    break;
  }
  default: heff_nomatch(v_x2_245);
  }
  return heff_strAppend(((V)&g_heff_2ebuild_2eproject_2equoted_str8), heff_strAppend(v_t_248, ((V)&g_heff_2ebuild_2eproject_2equoted_str9)));
}
V g_heff_2ebuild_2eproject_2equoted_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2eproject_2equoted(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ebuild_2eproject_2eshowPackage_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2eproject_2eshowPackage_str1, 0, "");
HEFF_LIT(g_heff_2ebuild_2eproject_2eshowPackage_str2, 2, ", ");
HEFF_LIT(g_heff_2ebuild_2eproject_2eshowPackage_str3, 4, " = [");
HEFF_LIT(g_heff_2ebuild_2eproject_2eshowPackage_str4, 1, "]");
HEFF_LIT(g_heff_2ebuild_2eproject_2eshowPackage_str5, 2, ", ");
HEFF_LIT(g_heff_2ebuild_2eproject_2eshowPackage_str6, 7, "require");
HEFF_LIT(g_heff_2ebuild_2eproject_2eshowPackage_str7, 0, "");
HEFF_LIT(g_heff_2ebuild_2eproject_2eshowPackage_str8, 0, "");
HEFF_LIT(g_heff_2ebuild_2eproject_2eshowPackage_str9, 2, ", ");
HEFF_LIT(g_heff_2ebuild_2eproject_2eshowPackage_str10, 4, " = [");
HEFF_LIT(g_heff_2ebuild_2eproject_2eshowPackage_str11, 1, "]");
HEFF_LIT(g_heff_2ebuild_2eproject_2eshowPackage_str12, 2, ", ");
HEFF_LIT(g_heff_2ebuild_2eproject_2eshowPackage_str13, 7, "replace");
HEFF_LIT(g_heff_2ebuild_2eproject_2eshowPackage_str14, 2, " }");
HEFF_LIT(g_heff_2ebuild_2eproject_2eshowPackage_str15, 9, ", heff = ");
HEFF_LIT(g_heff_2ebuild_2eproject_2eshowPackage_str16, 11, "{ module = ");
Clo g_heff_2ebuild_2eproject_2eshowPackage_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2eproject_2eshowPackage_entry, 1, 0};

V g_heff_2ebuild_2eproject_2eshowPackage(V v_pk_240) {
top: ;
  V v_t_241 = (g_heff_2ebuild_2eproject_2equoted(heff_rfield(v_pk_240, 0)));
  V v_t_242 = (g_heff_2ebuild_2eproject_2equoted(heff_rfield(v_pk_240, 1)));
  V v_items_243 = (g_list_2emap_24s1381986540x1952410492(heff_take_field(v_pk_240, 2)));
  V v_t_2410;
  switch (heff_tag_of(v_items_243)) {
  case TAG_Nil: {
    v_t_2410 = ((V)&g_heff_2ebuild_2eproject_2eshowPackage_str0);
    break;
  }
  case TAG_Cons: {
    V v_t_248;
    switch (heff_tag_of(v_items_243)) {
    case TAG_Nil: {
      v_t_248 = ((V)&g_heff_2ebuild_2eproject_2eshowPackage_str1);
      break;
    }
    case TAG_Cons: {
      V v_x_246 = heff_field(v_items_243, 0);
      V v_xs_247 = heff_field(v_items_243, 1);
      heff_take_n(v_items_243, 3ULL, 2);
      v_t_248 = ({ V a_0 = ((V)&g_heff_2ebuild_2eproject_2eshowPackage_str2); V a_1 = v_x_246; V a_2 = v_xs_247; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_247); r_; });
      break;
    }
    default: heff_nomatch(v_items_243);
    }
    V v_t_249 = heff_strAppend(((V)&g_heff_2ebuild_2eproject_2eshowPackage_str3), heff_strAppend(v_t_248, ((V)&g_heff_2ebuild_2eproject_2eshowPackage_str4)));
    v_t_2410 = heff_strAppend(((V)&g_heff_2ebuild_2eproject_2eshowPackage_str5), heff_strAppend(((V)&g_heff_2ebuild_2eproject_2eshowPackage_str6), v_t_249));
    break;
  }
  default: heff_nomatch(v_items_243);
  }
  V v_items_2411 = (g_list_2emap_24s404123879x745642248(heff_get_n(v_pk_240, 3, 4)));
  V v_t_2418;
  switch (heff_tag_of(v_items_2411)) {
  case TAG_Nil: {
    v_t_2418 = ((V)&g_heff_2ebuild_2eproject_2eshowPackage_str7);
    break;
  }
  case TAG_Cons: {
    V v_t_2416;
    switch (heff_tag_of(v_items_2411)) {
    case TAG_Nil: {
      v_t_2416 = ((V)&g_heff_2ebuild_2eproject_2eshowPackage_str8);
      break;
    }
    case TAG_Cons: {
      V v_x_2414 = heff_field(v_items_2411, 0);
      V v_xs_2415 = heff_field(v_items_2411, 1);
      heff_take_n(v_items_2411, 3ULL, 2);
      v_t_2416 = ({ V a_0 = ((V)&g_heff_2ebuild_2eproject_2eshowPackage_str9); V a_1 = v_x_2414; V a_2 = v_xs_2415; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2415); r_; });
      break;
    }
    default: heff_nomatch(v_items_2411);
    }
    V v_t_2417 = heff_strAppend(((V)&g_heff_2ebuild_2eproject_2eshowPackage_str10), heff_strAppend(v_t_2416, ((V)&g_heff_2ebuild_2eproject_2eshowPackage_str11)));
    v_t_2418 = heff_strAppend(((V)&g_heff_2ebuild_2eproject_2eshowPackage_str12), heff_strAppend(((V)&g_heff_2ebuild_2eproject_2eshowPackage_str13), v_t_2417));
    break;
  }
  default: heff_nomatch(v_items_2411);
  }
  V v_t_2419 = heff_strAppend(v_t_2410, heff_strAppend(v_t_2418, ((V)&g_heff_2ebuild_2eproject_2eshowPackage_str14)));
  V v_t_2420 = heff_strAppend(((V)&g_heff_2ebuild_2eproject_2eshowPackage_str15), heff_strAppend(v_t_242, v_t_2419));
  return heff_strAppend(((V)&g_heff_2ebuild_2eproject_2eshowPackage_str16), heff_strAppend(v_t_241, v_t_2420));
}
V g_heff_2ebuild_2eproject_2eshowPackage_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2eproject_2eshowPackage(a[0]);
}