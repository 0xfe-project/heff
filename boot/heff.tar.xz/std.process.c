// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Args 26338
#define TAG_Exec 20138
#define TAG_Exit 20279
#define TAG_GetEnv 43934
#define TAG_Platform 55558
#define TAG_ProgramPath 46819
#define TAG_Run 29975
#define TAG_WorkingDir 28879
#define LBL_hfmap 300551096
#define LBL_hmap 9701563
static uint32_t shape_hfmap__hmap[] = {LBL_hfmap, LBL_hmap};
V g_std_2eprocess_2eprocess_get(void);
V g_std_2eprocess_2eprocess_lam1(V self, V *args);
V g_std_2eprocess_2eprocess_lam2(V self, V *args);
V g_std_2eprocess_2eprocess_lam3(V self, V *args);
V g_std_2eprocess_2eprocess_lam4(V self, V *args);
V g_std_2eprocess_2eprocess_lam5(V self, V *args);
V g_std_2eprocess_2eprocess_lam6(V self, V *args);
V g_std_2eprocess_2eprocess_lam0(V self, V *args); static Clo g_std_2eprocess_2eprocess_lam0_clo = {{0x80000000u, K_CLO, 0}, g_std_2eprocess_2eprocess_lam0, 3, 0};
V g_std_2eprocess_2eprocess_lam7(V self, V *args); static Clo g_std_2eprocess_2eprocess_lam7_clo = {{0x80000000u, K_CLO, 0}, g_std_2eprocess_2eprocess_lam7, 4, 0};

static V g_std_2eprocess_2eprocess_val;
static int g_std_2eprocess_2eprocess_st;
static V g_std_2eprocess_2eprocess_init(void) {
  return heff_rec_n(2, shape_hfmap__hmap, (V[]){((V)&g_std_2eprocess_2eprocess_lam0_clo), ((V)&g_std_2eprocess_2eprocess_lam7_clo)});
}
V g_std_2eprocess_2eprocess_get(void) {
  if (g_std_2eprocess_2eprocess_st == 2) return g_std_2eprocess_2eprocess_val;
  if (g_std_2eprocess_2eprocess_st == 1) heff_fail("defined by itself");
  g_std_2eprocess_2eprocess_st = 1;
  g_std_2eprocess_2eprocess_val = heff_tr(g_std_2eprocess_2eprocess_init());
  g_std_2eprocess_2eprocess_st = 2;
  return g_std_2eprocess_2eprocess_val;
}
V g_std_2eprocess_2eprocess_lam1(V self, V *args) {
  V v_a_244 = args[0];
  V v_k_243 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_245 = heff_tr(heff_apply(v_k_243, 1, (V[]){v_a_244}));
  V f_ = v_g_241;
  args[0] = v_t_245;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2eprocess_2eprocess_lam2(V self, V *args) {
  V v_v_248 = args[0];
  V v_k_247 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_249 = heff_tr(heff_apply(v_k_247, 1, (V[]){v_v_248}));
  V f_ = v_g_241;
  args[0] = v_t_249;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2eprocess_2eprocess_lam3(V self, V *args) {
  V v_s_2411 = args[0];
  V v_k_2410 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2412 = heff_tr(heff_apply(v_k_2410, 1, (V[]){v_s_2411}));
  V f_ = v_g_241;
  args[0] = v_t_2412;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2eprocess_2eprocess_lam4(V self, V *args) {
  V v_s_2414 = args[0];
  V v_k_2413 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2415 = heff_tr(heff_apply(v_k_2413, 1, (V[]){v_s_2414}));
  V f_ = v_g_241;
  args[0] = v_t_2415;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2eprocess_2eprocess_lam5(V self, V *args) {
  V v_s_2417 = args[0];
  V v_k_2416 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2418 = heff_tr(heff_apply(v_k_2416, 1, (V[]){v_s_2417}));
  V f_ = v_g_241;
  args[0] = v_t_2418;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2eprocess_2eprocess_lam6(V self, V *args) {
  V v_r_2429 = args[0];
  V v_k_2428 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2430 = heff_tr(heff_apply(v_k_2428, 1, (V[]){v_r_2429}));
  V f_ = v_g_241;
  args[0] = v_t_2430;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2eprocess_2eprocess_lam0(V self, V *args) {
  V v_m_240 = args[0];
  V v_g_241 = args[1];
  V v_p_242 = args[2];
  heff_drop(v_m_240);
  switch (heff_tag_of(v_p_242)) {
  case TAG_Args: {
    V v_k_243 = heff_field(v_p_242, 0);
    V v_ru_24p_242_24Args = heff_take_reuse_n(v_p_242, 1ULL, 1);
    return heff_tag_at_n(v_ru_24p_242_24Args, TAG_Args, 1, (V[]){heff_clo_n(g_std_2eprocess_2eprocess_lam1, 1, 2, (V[]){v_k_243, v_g_241})});
  }
  case TAG_GetEnv: {
    V v_name_246 = heff_field(v_p_242, 0);
    V v_k_247 = heff_field(v_p_242, 1);
    V v_ru_24p_242_24GetEnv = heff_take_reuse_n(v_p_242, 3ULL, 2);
    return heff_tag_at_n(v_ru_24p_242_24GetEnv, TAG_GetEnv, 2, (V[]){v_name_246, heff_clo_n(g_std_2eprocess_2eprocess_lam2, 1, 2, (V[]){v_k_247, v_g_241})});
  }
  case TAG_ProgramPath: {
    V v_k_2410 = heff_field(v_p_242, 0);
    V v_ru_24p_242_24ProgramPath = heff_take_reuse_n(v_p_242, 1ULL, 1);
    return heff_tag_at_n(v_ru_24p_242_24ProgramPath, TAG_ProgramPath, 1, (V[]){heff_clo_n(g_std_2eprocess_2eprocess_lam3, 1, 2, (V[]){v_k_2410, v_g_241})});
  }
  case TAG_WorkingDir: {
    V v_k_2413 = heff_field(v_p_242, 0);
    V v_ru_24p_242_24WorkingDir = heff_take_reuse_n(v_p_242, 1ULL, 1);
    return heff_tag_at_n(v_ru_24p_242_24WorkingDir, TAG_WorkingDir, 1, (V[]){heff_clo_n(g_std_2eprocess_2eprocess_lam4, 1, 2, (V[]){v_k_2413, v_g_241})});
  }
  case TAG_Platform: {
    V v_k_2416 = heff_field(v_p_242, 0);
    V v_ru_24p_242_24Platform = heff_take_reuse_n(v_p_242, 1ULL, 1);
    return heff_tag_at_n(v_ru_24p_242_24Platform, TAG_Platform, 1, (V[]){heff_clo_n(g_std_2eprocess_2eprocess_lam5, 1, 2, (V[]){v_k_2416, v_g_241})});
  }
  case TAG_Exit: {
    V v_code_2419 = heff_field(v_p_242, 0);
    V v_x_2420 = heff_field(v_p_242, 1);
    V v_ru_24p_242_24Exit = heff_take_reuse_n(v_p_242, 3ULL, 2);
    V v_t_2421 = heff_tr(heff_apply(v_g_241, 1, (V[]){v_x_2420}));
    return heff_tag_at_n(v_ru_24p_242_24Exit, TAG_Exit, 2, (V[]){v_code_2419, v_t_2421});
  }
  case TAG_Exec: {
    V v_cmd_2422 = heff_field(v_p_242, 0);
    V v_as_2423 = heff_field(v_p_242, 1);
    V v_x_2424 = heff_field(v_p_242, 2);
    V v_ru_24p_242_24Exec = heff_take_reuse_n(v_p_242, 7ULL, 3);
    V v_t_2425 = heff_tr(heff_apply(v_g_241, 1, (V[]){v_x_2424}));
    return heff_tag_at_n(v_ru_24p_242_24Exec, TAG_Exec, 3, (V[]){v_cmd_2422, v_as_2423, v_t_2425});
  }
  case TAG_Run: {
    V v_cmd_2426 = heff_field(v_p_242, 0);
    V v_as_2427 = heff_field(v_p_242, 1);
    V v_k_2428 = heff_field(v_p_242, 2);
    V v_ru_24p_242_24Run = heff_take_reuse_n(v_p_242, 7ULL, 3);
    return heff_tag_at_n(v_ru_24p_242_24Run, TAG_Run, 3, (V[]){v_cmd_2426, v_as_2427, heff_clo_n(g_std_2eprocess_2eprocess_lam6, 1, 2, (V[]){v_k_2428, v_g_241})});
  }
  default: return heff_nomatch(v_p_242);
  }
}
V g_std_2eprocess_2eprocess_lam7(V self, V *args) {
  V v_m_2431 = args[0];
  V v_n_2432 = args[1];
  V v_nt_2433 = args[2];
  V v_p_2434 = args[3];
  heff_drop(v_m_2431);
  heff_drop(v_n_2432);
  heff_drop(v_nt_2433);
  switch (heff_tag_of(v_p_2434)) {
  case TAG_Args: {
    V v_k_2435 = heff_field(v_p_2434, 0);
    V v_ru_24p_2434_24Args = heff_take_reuse_n(v_p_2434, 1ULL, 1);
    return heff_tag_at_n(v_ru_24p_2434_24Args, TAG_Args, 1, (V[]){v_k_2435});
  }
  case TAG_GetEnv: {
    V v_name_2436 = heff_field(v_p_2434, 0);
    V v_k_2437 = heff_field(v_p_2434, 1);
    V v_ru_24p_2434_24GetEnv = heff_take_reuse_n(v_p_2434, 3ULL, 2);
    return heff_tag_at_n(v_ru_24p_2434_24GetEnv, TAG_GetEnv, 2, (V[]){v_name_2436, v_k_2437});
  }
  case TAG_ProgramPath: {
    V v_k_2438 = heff_field(v_p_2434, 0);
    V v_ru_24p_2434_24ProgramPath = heff_take_reuse_n(v_p_2434, 1ULL, 1);
    return heff_tag_at_n(v_ru_24p_2434_24ProgramPath, TAG_ProgramPath, 1, (V[]){v_k_2438});
  }
  case TAG_WorkingDir: {
    V v_k_2439 = heff_field(v_p_2434, 0);
    V v_ru_24p_2434_24WorkingDir = heff_take_reuse_n(v_p_2434, 1ULL, 1);
    return heff_tag_at_n(v_ru_24p_2434_24WorkingDir, TAG_WorkingDir, 1, (V[]){v_k_2439});
  }
  case TAG_Platform: {
    V v_k_2440 = heff_field(v_p_2434, 0);
    V v_ru_24p_2434_24Platform = heff_take_reuse_n(v_p_2434, 1ULL, 1);
    return heff_tag_at_n(v_ru_24p_2434_24Platform, TAG_Platform, 1, (V[]){v_k_2440});
  }
  case TAG_Exit: {
    V v_code_2441 = heff_field(v_p_2434, 0);
    V v_x_2442 = heff_field(v_p_2434, 1);
    V v_ru_24p_2434_24Exit = heff_take_reuse_n(v_p_2434, 3ULL, 2);
    return heff_tag_at_n(v_ru_24p_2434_24Exit, TAG_Exit, 2, (V[]){v_code_2441, v_x_2442});
  }
  case TAG_Exec: {
    V v_cmd_2443 = heff_field(v_p_2434, 0);
    V v_as_2444 = heff_field(v_p_2434, 1);
    V v_x_2445 = heff_field(v_p_2434, 2);
    V v_ru_24p_2434_24Exec = heff_take_reuse_n(v_p_2434, 7ULL, 3);
    return heff_tag_at_n(v_ru_24p_2434_24Exec, TAG_Exec, 3, (V[]){v_cmd_2443, v_as_2444, v_x_2445});
  }
  case TAG_Run: {
    V v_cmd_2446 = heff_field(v_p_2434, 0);
    V v_as_2447 = heff_field(v_p_2434, 1);
    V v_k_2448 = heff_field(v_p_2434, 2);
    V v_ru_24p_2434_24Run = heff_take_reuse_n(v_p_2434, 7ULL, 3);
    return heff_tag_at_n(v_ru_24p_2434_24Run, TAG_Run, 3, (V[]){v_cmd_2446, v_as_2447, v_k_2448});
  }
  default: return heff_nomatch(v_p_2434);
  }
}