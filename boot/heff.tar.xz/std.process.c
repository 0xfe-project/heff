// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Args 26338
#define TAG_CloseInput 41785
#define TAG_Collected 38917
#define TAG_Exec 20138
#define TAG_Exit 20279
#define TAG_GetEnv 43934
#define TAG_Kill 53643
#define TAG_Left 13886
#define TAG_MkPath 49630
#define TAG_NoInput 41055
#define TAG_Platform 55558
#define TAG_Processors 11008
#define TAG_ProgramPath 46819
#define TAG_ReadErrors 12846
#define TAG_ReadOutput 34844
#define TAG_Release 43671
#define TAG_Right 62770
#define TAG_Run 29975
#define TAG_SetWorkingDir 4024
#define TAG_Start 63542
#define TAG_Terminate 62553
#define TAG_Throw 56084
#define TAG_TryWait 64330
#define TAG_Wait 10206
#define TAG_WorkingDir 28879
#define TAG_WriteInput 15010
#define LBL_args 9498020
#define LBL_bind 9519364
#define LBL_command 1182252425
#define LBL_dir 308999
#define LBL_env 310119
#define LBL_errors 652506774
#define LBL_group 299987609
#define LBL_hfmap 300551096
#define LBL_hmap 9701563
#define LBL_input 301716452
#define LBL_keep 9783372
#define LBL_malg 9839318
#define LBL_output 941629484
#define LBL_timeout 1065429926
static uint32_t shape_command__args__dir__env__input__output__errors__timeout__keep__group[] = {LBL_command, LBL_args, LBL_dir, LBL_env, LBL_input, LBL_output, LBL_errors, LBL_timeout, LBL_keep, LBL_group};
static uint32_t shape_hfmap__hmap[] = {LBL_hfmap, LBL_hmap};
V g_co_2eop_24s615738393x1686646143(V, V, V);
V g_co_2eop_24s615738393x1686646143_entry(V self, V *a);
extern Clo g_co_2eop_24s615738393x1686646143_clo;
V g_co_2eop_24s615738393x1686646143_24tok1(V, V, V, V);
V g_co_2eop_24s615738393x1686646143_24tok1_entry(V self, V *a);
extern Clo g_co_2eop_24s615738393x1686646143_24tok1_clo;
V g_co_2eop_24s615738393x1686646143_24tok2(V, V, V, V);
V g_co_2eop_24s615738393x1686646143_24tok2_entry(V self, V *a);
extern Clo g_co_2eop_24s615738393x1686646143_24tok2_clo;
V g_co_2eop_24s760975558x1999937727(V, V, V, V, V, V);
V g_co_2eop_24s760975558x1999937727_entry(V self, V *a);
extern Clo g_co_2eop_24s760975558x1999937727_clo;
V g_co_2eop_24s847889387x1388281137(V, V, V);
V g_co_2eop_24s847889387x1388281137_entry(V self, V *a);
extern Clo g_co_2eop_24s847889387x1388281137_clo;
V g_std_2epath_2ecurrent_get(void);
V g_std_2epath_2enative_get(void);
V g_std_2epath_2erender(V, V);
V g_std_2epath_2erender_entry(V self, V *a);
extern Clo g_std_2epath_2erender_clo;
V g_std_2epath_2esameSegments(V, V);
V g_std_2epath_2esameSegments_entry(V self, V *a);
extern Clo g_std_2epath_2esameSegments_clo;
V g_std_2eprocess_2edirFor(V);
V g_std_2eprocess_2edirFor_entry(V self, V *a);
extern Clo g_std_2eprocess_2edirFor_clo;
V g_std_2eprocess_2eprocess_get(void);
V g_std_2eprocess_2erun_24s1262677465x1574883892(V, V, V, V, V);
V g_std_2eprocess_2erun_24s1262677465x1574883892_entry(V self, V *a);
extern Clo g_std_2eprocess_2erun_24s1262677465x1574883892_clo;
V g_std_2eprocess_2ewithProcess_24s1345957496x637138289(V, V);
V g_std_2eprocess_2ewithProcess_24s1345957496x637138289_entry(V self, V *a);
extern Clo g_std_2eprocess_2ewithProcess_24s1345957496x637138289_clo;
V g_std_2eprocess_2ewithProcess_24s2044712421x1082792288(V, V, V);
V g_std_2eprocess_2ewithProcess_24s2044712421x1082792288_entry(V self, V *a);
extern Clo g_std_2eprocess_2ewithProcess_24s2044712421x1082792288_clo;
HEFF_LIT(g_std_2eprocess_2edirFor_str0, 0, "");
HEFF_LIT(g_std_2eprocess_2edirFor_str1, 0, "");
Clo g_std_2eprocess_2edirFor_clo = {{0x80000000u, K_CLO, 0}, g_std_2eprocess_2edirFor_entry, 1, 0};

V g_std_2eprocess_2edirFor(V v_p_240) {
top: ;
  V v_t_244;
  switch (heff_tag_of(v_p_240)) {
  case TAG_MkPath: {
    V v_d_241 = heff_field(v_p_240, 0);
    v_t_244 = heff_dup(v_d_241);
    break;
  }
  default: heff_nomatch(v_p_240);
  }
  if (heff_strEq_c(v_t_244, ((V)&g_std_2eprocess_2edirFor_str0))) {
    V v_t_248;
    switch (heff_tag_of(v_p_240)) {
    case TAG_MkPath: {
      V v_a_246 = heff_field(v_p_240, 1);
      v_t_248 = heff_dup(v_a_246);
      break;
    }
    default: heff_nomatch(v_p_240);
    }
    if (!(heff_dup(v_t_248) == NTAG(TAG_True))) {
      heff_drop(v_t_248);
      V v_t_2412;
      switch (heff_tag_of(v_p_240)) {
      case TAG_MkPath: {
        V v_xs_2411 = heff_field(v_p_240, 2);
        v_t_2412 = heff_dup(v_xs_2411);
        break;
      }
      default: heff_nomatch(v_p_240);
      }
      V v_t_2413 = ({ V a_0 = v_t_2412; V b_1 = NTAG(TAG_Nil); V r_ = (g_std_2epath_2esameSegments(a_0, b_1)); heff_drop(v_t_2412); heff_drop(b_1); r_; });
      if ((heff_dup(v_t_2413) == NTAG(TAG_True))) {
        heff_drop(v_t_2413);
        return ((V)&g_std_2eprocess_2edirFor_str1);
      } else {
        heff_drop(v_t_2413);
        return ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_p_240; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); r_; });
      }
    } else {
      heff_drop(v_t_248);
      return ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_p_240; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); r_; });
    }
  } else {
    return ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_p_240; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); r_; });
  }
}
V g_std_2eprocess_2edirFor_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_std_2eprocess_2edirFor(a0); heff_drop(a0); return r;
}
V g_std_2eprocess_2eprocess_lam1(V self, V *args);
V g_std_2eprocess_2eprocess_lam2(V self, V *args);
V g_std_2eprocess_2eprocess_lam3(V self, V *args);
V g_std_2eprocess_2eprocess_lam4(V self, V *args);
V g_std_2eprocess_2eprocess_lam5(V self, V *args);
V g_std_2eprocess_2eprocess_lam6(V self, V *args);
V g_std_2eprocess_2eprocess_lam7(V self, V *args);
V g_std_2eprocess_2eprocess_lam8(V self, V *args);
V g_std_2eprocess_2eprocess_lam9(V self, V *args);
V g_std_2eprocess_2eprocess_lam10(V self, V *args);
V g_std_2eprocess_2eprocess_lam11(V self, V *args);
V g_std_2eprocess_2eprocess_lam12(V self, V *args);
V g_std_2eprocess_2eprocess_lam13(V self, V *args);
V g_std_2eprocess_2eprocess_lam14(V self, V *args);
V g_std_2eprocess_2eprocess_lam15(V self, V *args);
V g_std_2eprocess_2eprocess_lam16(V self, V *args);
V g_std_2eprocess_2eprocess_lam0(V self, V *args); static Clo g_std_2eprocess_2eprocess_lam0_clo = {{0x80000000u, K_CLO, 0}, g_std_2eprocess_2eprocess_lam0, 3, 0};
V g_std_2eprocess_2eprocess_lam17(V self, V *args); static Clo g_std_2eprocess_2eprocess_lam17_clo = {{0x80000000u, K_CLO, 0}, g_std_2eprocess_2eprocess_lam17, 4, 0};

static V g_std_2eprocess_2eprocess_val;
static HEFF_ONCE g_std_2eprocess_2eprocess_st;
static V g_std_2eprocess_2eprocess_init(void) {
  return heff_rec_n(2, shape_hfmap__hmap, (V[]){((V)&g_std_2eprocess_2eprocess_lam0_clo), ((V)&g_std_2eprocess_2eprocess_lam17_clo)});
}
V g_std_2eprocess_2eprocess_get(void) {
  if (HEFF_DONE(g_std_2eprocess_2eprocess_st)) return g_std_2eprocess_2eprocess_val;
  return heff_global(&g_std_2eprocess_2eprocess_val, &g_std_2eprocess_2eprocess_st, g_std_2eprocess_2eprocess_init);
}
V g_std_2eprocess_2eprocess_lam1(V self, V *args) {
  V v_a_244 = args[0];
  V v_k_243 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_245 = heff_tr(heff_call(v_k_243, 1, (V[]){v_a_244}));
  V f_ = v_g_241;
  args[0] = v_t_245;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2eprocess_2eprocess_lam2(V self, V *args) {
  V v_v_248 = args[0];
  V v_k_247 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_249 = heff_tr(heff_call(v_k_247, 1, (V[]){v_v_248}));
  V f_ = v_g_241;
  args[0] = v_t_249;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2eprocess_2eprocess_lam3(V self, V *args) {
  V v_s_2411 = args[0];
  V v_k_2410 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2412 = heff_tr(heff_call(v_k_2410, 1, (V[]){v_s_2411}));
  V f_ = v_g_241;
  args[0] = v_t_2412;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2eprocess_2eprocess_lam4(V self, V *args) {
  V v_s_2414 = args[0];
  V v_k_2413 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2415 = heff_tr(heff_call(v_k_2413, 1, (V[]){v_s_2414}));
  V f_ = v_g_241;
  args[0] = v_t_2415;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2eprocess_2eprocess_lam5(V self, V *args) {
  V v_ok_2418 = args[0];
  V v_k_2417 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2419 = heff_tr(heff_call(v_k_2417, 1, (V[]){v_ok_2418}));
  V f_ = v_g_241;
  args[0] = v_t_2419;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2eprocess_2eprocess_lam6(V self, V *args) {
  V v_s_2421 = args[0];
  V v_k_2420 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2422 = heff_tr(heff_call(v_k_2420, 1, (V[]){v_s_2421}));
  V f_ = v_g_241;
  args[0] = v_t_2422;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2eprocess_2eprocess_lam7(V self, V *args) {
  V v_n_2424 = args[0];
  V v_k_2423 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2425 = heff_tr(heff_call(v_k_2423, 1, (V[]){v_n_2424}));
  V f_ = v_g_241;
  args[0] = v_t_2425;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2eprocess_2eprocess_lam8(V self, V *args) {
  V v_r_2435 = args[0];
  V v_k_2434 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2436 = heff_tr(heff_call(v_k_2434, 1, (V[]){v_r_2435}));
  V f_ = v_g_241;
  args[0] = v_t_2436;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2eprocess_2eprocess_lam9(V self, V *args) {
  V v_s_2439 = args[0];
  V v_k_2438 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2440 = heff_tr(heff_call(v_k_2438, 1, (V[]){v_s_2439}));
  V f_ = v_g_241;
  args[0] = v_t_2440;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2eprocess_2eprocess_lam10(V self, V *args) {
  V v_r_2443 = args[0];
  V v_k_2442 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2444 = heff_tr(heff_call(v_k_2442, 1, (V[]){v_r_2443}));
  V f_ = v_g_241;
  args[0] = v_t_2444;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2eprocess_2eprocess_lam11(V self, V *args) {
  V v_r_2447 = args[0];
  V v_k_2446 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2448 = heff_tr(heff_call(v_k_2446, 1, (V[]){v_r_2447}));
  V f_ = v_g_241;
  args[0] = v_t_2448;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2eprocess_2eprocess_lam12(V self, V *args) {
  V v_r_2451 = args[0];
  V v_k_2450 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2452 = heff_tr(heff_call(v_k_2450, 1, (V[]){v_r_2451}));
  V f_ = v_g_241;
  args[0] = v_t_2452;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2eprocess_2eprocess_lam13(V self, V *args) {
  V v_r_2458 = args[0];
  V v_k_2457 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2459 = heff_tr(heff_call(v_k_2457, 1, (V[]){v_r_2458}));
  V f_ = v_g_241;
  args[0] = v_t_2459;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2eprocess_2eprocess_lam14(V self, V *args) {
  V v_r_2463 = args[0];
  V v_k_2462 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2464 = heff_tr(heff_call(v_k_2462, 1, (V[]){v_r_2463}));
  V f_ = v_g_241;
  args[0] = v_t_2464;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2eprocess_2eprocess_lam15(V self, V *args) {
  V v_r_2472 = args[0];
  V v_k_2471 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2473 = heff_tr(heff_call(v_k_2471, 1, (V[]){v_r_2472}));
  V f_ = v_g_241;
  args[0] = v_t_2473;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2eprocess_2eprocess_lam16(V self, V *args) {
  V v_r_2478 = args[0];
  V v_k_2477 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2479 = heff_tr(heff_call(v_k_2477, 1, (V[]){v_r_2478}));
  V f_ = v_g_241;
  args[0] = v_t_2479;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2eprocess_2eprocess_lam0(V self, V *args) {
  V v_m_240 = args[0];
  V v_g_241 = args[1];
  V v_p_242 = args[2];
  heff_drop(v_m_240);
  switch (heff_tag_of(v_p_242)) {
  case TAG_Args: {
    V v_k_243 = heff_field(v_p_242, 0);
    V v_ru_24p_242_24Args = heff_take_reuse_n(v_p_242, 1ULL, 1);
    return heff_tag_at_n(v_ru_24p_242_24Args, TAG_Args, 1, (V[]){heff_clo_n(g_std_2eprocess_2eprocess_lam1, 1, 2, (V[]){v_k_243, v_g_241})});
  }
  case TAG_GetEnv: {
    V v_name_246 = heff_field(v_p_242, 0);
    V v_k_247 = heff_field(v_p_242, 1);
    V v_ru_24p_242_24GetEnv = heff_take_reuse_n(v_p_242, 3ULL, 2);
    return heff_tag_at_n(v_ru_24p_242_24GetEnv, TAG_GetEnv, 2, (V[]){v_name_246, heff_clo_n(g_std_2eprocess_2eprocess_lam2, 1, 2, (V[]){v_k_247, v_g_241})});
  }
  case TAG_ProgramPath: {
    V v_k_2410 = heff_field(v_p_242, 0);
    V v_ru_24p_242_24ProgramPath = heff_take_reuse_n(v_p_242, 1ULL, 1);
    return heff_tag_at_n(v_ru_24p_242_24ProgramPath, TAG_ProgramPath, 1, (V[]){heff_clo_n(g_std_2eprocess_2eprocess_lam3, 1, 2, (V[]){v_k_2410, v_g_241})});
  }
  case TAG_WorkingDir: {
    V v_k_2413 = heff_field(v_p_242, 0);
    V v_ru_24p_242_24WorkingDir = heff_take_reuse_n(v_p_242, 1ULL, 1);
    return heff_tag_at_n(v_ru_24p_242_24WorkingDir, TAG_WorkingDir, 1, (V[]){heff_clo_n(g_std_2eprocess_2eprocess_lam4, 1, 2, (V[]){v_k_2413, v_g_241})});
  }
  case TAG_SetWorkingDir: {
    V v_dir_2416 = heff_field(v_p_242, 0);
    V v_k_2417 = heff_field(v_p_242, 1);
    V v_ru_24p_242_24SetWorkingDir = heff_take_reuse_n(v_p_242, 3ULL, 2);
    return heff_tag_at_n(v_ru_24p_242_24SetWorkingDir, TAG_SetWorkingDir, 2, (V[]){v_dir_2416, heff_clo_n(g_std_2eprocess_2eprocess_lam5, 1, 2, (V[]){v_k_2417, v_g_241})});
  }
  case TAG_Platform: {
    V v_k_2420 = heff_field(v_p_242, 0);
    V v_ru_24p_242_24Platform = heff_take_reuse_n(v_p_242, 1ULL, 1);
    return heff_tag_at_n(v_ru_24p_242_24Platform, TAG_Platform, 1, (V[]){heff_clo_n(g_std_2eprocess_2eprocess_lam6, 1, 2, (V[]){v_k_2420, v_g_241})});
  }
  case TAG_Processors: {
    V v_k_2423 = heff_field(v_p_242, 0);
    V v_ru_24p_242_24Processors = heff_take_reuse_n(v_p_242, 1ULL, 1);
    return heff_tag_at_n(v_ru_24p_242_24Processors, TAG_Processors, 1, (V[]){heff_clo_n(g_std_2eprocess_2eprocess_lam7, 1, 2, (V[]){v_k_2423, v_g_241})});
  }
  case TAG_Exit: {
    V v_code_2426 = heff_field(v_p_242, 0);
    V v_x_2427 = heff_field(v_p_242, 1);
    V v_ru_24p_242_24Exit = heff_take_reuse_n(v_p_242, 3ULL, 2);
    V v_t_2428 = heff_tr(heff_call(v_g_241, 1, (V[]){v_x_2427}));
    return heff_tag_at_n(v_ru_24p_242_24Exit, TAG_Exit, 2, (V[]){v_code_2426, v_t_2428});
  }
  case TAG_Exec: {
    V v_cmd_2429 = heff_field(v_p_242, 0);
    V v_argv_2430 = heff_field(v_p_242, 1);
    V v_x_2431 = heff_field(v_p_242, 2);
    V v_ru_24p_242_24Exec = heff_take_reuse_n(v_p_242, 7ULL, 3);
    V v_t_2432 = heff_tr(heff_call(v_g_241, 1, (V[]){v_x_2431}));
    return heff_tag_at_n(v_ru_24p_242_24Exec, TAG_Exec, 3, (V[]){v_cmd_2429, v_argv_2430, v_t_2432});
  }
  case TAG_Run: {
    V v_c_2433 = heff_field(v_p_242, 0);
    V v_k_2434 = heff_field(v_p_242, 1);
    V v_ru_24p_242_24Run = heff_take_reuse_n(v_p_242, 3ULL, 2);
    return heff_tag_at_n(v_ru_24p_242_24Run, TAG_Run, 2, (V[]){v_c_2433, heff_clo_n(g_std_2eprocess_2eprocess_lam8, 1, 2, (V[]){v_k_2434, v_g_241})});
  }
  case TAG_Start: {
    V v_c_2437 = heff_field(v_p_242, 0);
    V v_k_2438 = heff_field(v_p_242, 1);
    V v_ru_24p_242_24Start = heff_take_reuse_n(v_p_242, 3ULL, 2);
    return heff_tag_at_n(v_ru_24p_242_24Start, TAG_Start, 2, (V[]){v_c_2437, heff_clo_n(g_std_2eprocess_2eprocess_lam9, 1, 2, (V[]){v_k_2438, v_g_241})});
  }
  case TAG_Release: {
    V v_s_2441 = heff_field(v_p_242, 0);
    V v_k_2442 = heff_field(v_p_242, 1);
    V v_ru_24p_242_24Release = heff_take_reuse_n(v_p_242, 3ULL, 2);
    return heff_tag_at_n(v_ru_24p_242_24Release, TAG_Release, 2, (V[]){v_s_2441, heff_clo_n(g_std_2eprocess_2eprocess_lam10, 1, 2, (V[]){v_k_2442, v_g_241})});
  }
  case TAG_Wait: {
    V v_s_2445 = heff_field(v_p_242, 0);
    V v_k_2446 = heff_field(v_p_242, 1);
    V v_ru_24p_242_24Wait = heff_take_reuse_n(v_p_242, 3ULL, 2);
    return heff_tag_at_n(v_ru_24p_242_24Wait, TAG_Wait, 2, (V[]){v_s_2445, heff_clo_n(g_std_2eprocess_2eprocess_lam11, 1, 2, (V[]){v_k_2446, v_g_241})});
  }
  case TAG_TryWait: {
    V v_s_2449 = heff_field(v_p_242, 0);
    V v_k_2450 = heff_field(v_p_242, 1);
    V v_ru_24p_242_24TryWait = heff_take_reuse_n(v_p_242, 3ULL, 2);
    return heff_tag_at_n(v_ru_24p_242_24TryWait, TAG_TryWait, 2, (V[]){v_s_2449, heff_clo_n(g_std_2eprocess_2eprocess_lam12, 1, 2, (V[]){v_k_2450, v_g_241})});
  }
  case TAG_Kill: {
    V v_s_2453 = heff_field(v_p_242, 0);
    V v_x_2454 = heff_field(v_p_242, 1);
    V v_ru_24p_242_24Kill = heff_take_reuse_n(v_p_242, 3ULL, 2);
    V v_t_2455 = heff_tr(heff_call(v_g_241, 1, (V[]){v_x_2454}));
    return heff_tag_at_n(v_ru_24p_242_24Kill, TAG_Kill, 2, (V[]){v_s_2453, v_t_2455});
  }
  case TAG_Terminate: {
    V v_s_2456 = heff_field(v_p_242, 0);
    V v_k_2457 = heff_field(v_p_242, 1);
    V v_ru_24p_242_24Terminate = heff_take_reuse_n(v_p_242, 3ULL, 2);
    return heff_tag_at_n(v_ru_24p_242_24Terminate, TAG_Terminate, 2, (V[]){v_s_2456, heff_clo_n(g_std_2eprocess_2eprocess_lam13, 1, 2, (V[]){v_k_2457, v_g_241})});
  }
  case TAG_WriteInput: {
    V v_s_2460 = heff_field(v_p_242, 0);
    V v_b_2461 = heff_field(v_p_242, 1);
    V v_k_2462 = heff_field(v_p_242, 2);
    V v_ru_24p_242_24WriteInput = heff_take_reuse_n(v_p_242, 7ULL, 3);
    return heff_tag_at_n(v_ru_24p_242_24WriteInput, TAG_WriteInput, 3, (V[]){v_s_2460, v_b_2461, heff_clo_n(g_std_2eprocess_2eprocess_lam14, 1, 2, (V[]){v_k_2462, v_g_241})});
  }
  case TAG_CloseInput: {
    V v_s_2465 = heff_field(v_p_242, 0);
    V v_x_2466 = heff_field(v_p_242, 1);
    V v_ru_24p_242_24CloseInput = heff_take_reuse_n(v_p_242, 3ULL, 2);
    V v_t_2467 = heff_tr(heff_call(v_g_241, 1, (V[]){v_x_2466}));
    return heff_tag_at_n(v_ru_24p_242_24CloseInput, TAG_CloseInput, 2, (V[]){v_s_2465, v_t_2467});
  }
  case TAG_ReadOutput: {
    V v_s_2468 = heff_field(v_p_242, 0);
    V v_n_2469 = heff_field(v_p_242, 1);
    V v_ms_2470 = heff_field(v_p_242, 2);
    V v_k_2471 = heff_field(v_p_242, 3);
    V v_ru_24p_242_24ReadOutput = heff_take_reuse_n(v_p_242, 15ULL, 4);
    return heff_tag_at_n(v_ru_24p_242_24ReadOutput, TAG_ReadOutput, 4, (V[]){v_s_2468, v_n_2469, v_ms_2470, heff_clo_n(g_std_2eprocess_2eprocess_lam15, 1, 2, (V[]){v_k_2471, v_g_241})});
  }
  case TAG_ReadErrors: {
    V v_s_2474 = heff_field(v_p_242, 0);
    V v_n_2475 = heff_field(v_p_242, 1);
    V v_ms_2476 = heff_field(v_p_242, 2);
    V v_k_2477 = heff_field(v_p_242, 3);
    V v_ru_24p_242_24ReadErrors = heff_take_reuse_n(v_p_242, 15ULL, 4);
    return heff_tag_at_n(v_ru_24p_242_24ReadErrors, TAG_ReadErrors, 4, (V[]){v_s_2474, v_n_2475, v_ms_2476, heff_clo_n(g_std_2eprocess_2eprocess_lam16, 1, 2, (V[]){v_k_2477, v_g_241})});
  }
  default: return heff_nomatch(v_p_242);
  }
}
V g_std_2eprocess_2eprocess_lam17(V self, V *args) {
  V v_m_2480 = args[0];
  V v_n_2481 = args[1];
  V v_nt_2482 = args[2];
  V v_p_2483 = args[3];
  heff_drop(v_m_2480);
  heff_drop(v_n_2481);
  heff_drop(v_nt_2482);
  return v_p_2483;
}
V g_std_2eprocess_2ewithProcess_24s1345957496x637138289_lam0(V self, V *args); static Clo g_std_2eprocess_2ewithProcess_24s1345957496x637138289_lam0_clo = {{0x80000000u, K_CLO, 0}, g_std_2eprocess_2ewithProcess_24s1345957496x637138289_lam0, 1, 0};
V g_std_2eprocess_2ewithProcess_24s1345957496x637138289_lam3(V self, V *args); static Clo g_std_2eprocess_2ewithProcess_24s1345957496x637138289_lam3_clo = {{0x80000000u, K_CLO, 0}, g_std_2eprocess_2ewithProcess_24s1345957496x637138289_lam3, 1, 0};
V g_std_2eprocess_2ewithProcess_24s1345957496x637138289_lam5(V self, V *args); static Clo g_std_2eprocess_2ewithProcess_24s1345957496x637138289_lam5_clo = {{0x80000000u, K_CLO, 0}, g_std_2eprocess_2ewithProcess_24s1345957496x637138289_lam5, 1, 0};
V g_std_2eprocess_2ewithProcess_24s1345957496x637138289_lam6(V self, V *args);
V g_std_2eprocess_2ewithProcess_24s1345957496x637138289_lam4(V self, V *args);
V g_std_2eprocess_2ewithProcess_24s1345957496x637138289_lam2(V self, V *args);
V g_std_2eprocess_2ewithProcess_24s1345957496x637138289_lam1(V self, V *args);
Clo g_std_2eprocess_2ewithProcess_24s1345957496x637138289_clo = {{0x80000000u, K_CLO, 0}, g_std_2eprocess_2ewithProcess_24s1345957496x637138289_entry, 2, 0};

V g_std_2eprocess_2ewithProcess_24s1345957496x637138289(V v_ex_240, V v_c_241) {
top: ;
  V v_command_242 = heff_take_field(v_c_241, 0);
  V v_args_243 = heff_take_field(v_c_241, 1);
  V v_dir_244 = heff_take_field(v_c_241, 2);
  V v_env_245 = heff_take_field(v_c_241, 3);
  V v_input_246 = heff_take_field(v_c_241, 4);
  V v_output_247 = heff_take_field(v_c_241, 5);
  V v_errors_248 = heff_take_field(v_c_241, 6);
  V v_timeout_249 = heff_take_field(v_c_241, 7);
  V v_keep_2410 = heff_take_field(v_c_241, 8);
  V v_group_2411 = heff_get_n(v_c_241, 9, 10);
  V v_t_2412 = ({ V a_0 = v_dir_244; V r_ = (g_std_2eprocess_2edirFor(a_0)); heff_drop(v_dir_244); r_; });
  V v_a_2414 = heff_tag_n(TAG_Start, 2, (V[]){heff_rec_n(10, shape_command__args__dir__env__input__output__errors__timeout__keep__group, (V[]){v_command_242, v_args_243, v_t_2412, v_env_245, v_input_246, v_output_247, v_errors_248, v_timeout_249, v_keep_2410, v_group_2411}), ((V)&g_std_2eprocess_2ewithProcess_24s1345957496x637138289_lam0_clo)});
  return heff_clo_n(g_std_2eprocess_2ewithProcess_24s1345957496x637138289_lam1, 2, 2, (V[]){v_a_2414, v_ex_240});
}
V g_std_2eprocess_2ewithProcess_24s1345957496x637138289_entry(V self, V *a) {
  (void)self;
  return g_std_2eprocess_2ewithProcess_24s1345957496x637138289(a[0], a[1]);
}
V g_std_2eprocess_2ewithProcess_24s1345957496x637138289_lam0(V self, V *args) {
  V v_s_2413 = args[0];
  return v_s_2413;
}
V g_std_2eprocess_2ewithProcess_24s1345957496x637138289_lam3(V self, V *args) {
  V v_a_2428 = args[0];
  return v_a_2428;
}
V g_std_2eprocess_2ewithProcess_24s1345957496x637138289_lam5(V self, V *args) {
  V v_r_2438 = args[0];
  return v_r_2438;
}
V g_std_2eprocess_2ewithProcess_24s1345957496x637138289_lam6(V self, V *args) {
  V v_x_2447 = args[0];
  V v_ex_240 = heff_env(self)[0];
  V v_hd_2415 = heff_env(self)[1];
  V v_k_2416 = heff_env(self)[2];
  V v_x_2437 = heff_env(self)[3];
  heff_clo_take(self, 4);
  switch (heff_tag_of(v_x_2447)) {
  case TAG_Left: {
    V v_err_2448 = heff_field(v_x_2447, 0);
    V v_ru_24x_2447_24Left = heff_take_reuse_n(v_x_2447, 1ULL, 1);
    heff_drop(v_x_2437);
    V v_t_2449 = heff_tr(heff_call(v_ex_240, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_err_2448})}));
    return (g_co_2eop_24s615738393x1686646143_24tok1(v_ru_24x_2447_24Left, v_t_2449, v_hd_2415, v_k_2416));
  }
  case TAG_Right: {
    heff_take_n(v_x_2447, 0ULL, 1);
    heff_drop(v_ex_240);
    heff_drop_rec(v_hd_2415, 3);
    V f_ = v_k_2416;
    args[0] = v_x_2437;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_2447);
  }
}
V g_std_2eprocess_2ewithProcess_24s1345957496x637138289_lam4(V self, V *args) {
  V v_x_2437 = args[0];
  V v_x_2427 = heff_env(self)[0];
  V v_hd_2415 = heff_env(self)[1];
  V v_ex_240 = heff_env(self)[2];
  V v_k_2416 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2439 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Release, 2, (V[]){v_x_2427, ((V)&g_std_2eprocess_2ewithProcess_24s1345957496x637138289_lam5_clo)})});
  V v_t_2440 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2439})});
  V v_t_2441 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2440})});
  V v_t_2442 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2441})});
  V v_t_2443 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2442})});
  V v_t_2444 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2443})});
  V v_t_2445 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2444})});
  V v_t_2446 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_2415, 2)), 1, (V[]){v_t_2445}));
  V f_ = heff_dup(heff_rfield(v_hd_2415, 1));
  heff_room[0] = v_t_2446;
  heff_room[1] = heff_clo_n(g_std_2eprocess_2ewithProcess_24s1345957496x637138289_lam6, 1, 4, (V[]){v_ex_240, v_hd_2415, v_k_2416, v_x_2437});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_std_2eprocess_2ewithProcess_24s1345957496x637138289_lam2(V self, V *args) {
  V v_x_2424 = args[0];
  V v_ex_240 = heff_env(self)[0];
  V v_hd_2415 = heff_env(self)[1];
  V v_k_2416 = heff_env(self)[2];
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_x_2424)) {
  case TAG_Left: {
    V v_err_2425 = heff_field(v_x_2424, 0);
    V v_ru_24x_2424_24Left = heff_take_reuse_n(v_x_2424, 1ULL, 1);
    V v_t_2426 = heff_tr(heff_call(v_ex_240, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_err_2425})}));
    return (g_co_2eop_24s615738393x1686646143_24tok1(v_ru_24x_2424_24Left, v_t_2426, v_hd_2415, v_k_2416));
  }
  case TAG_Right: {
    V v_x_2427 = heff_field(v_x_2424, 0);
    V v_ru_24x_2424_24Right = heff_take_reuse_n(v_x_2424, 1ULL, 1);
    V v_t_2429 = heff_tag_at_n(v_ru_24x_2424_24Right, TAG_InR, 1, (V[]){heff_tag_n(TAG_Wait, 2, (V[]){heff_dup(v_x_2427), ((V)&g_std_2eprocess_2ewithProcess_24s1345957496x637138289_lam3_clo)})});
    V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
    V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
    V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
    V v_t_2433 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2432})});
    V v_t_2434 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2433})});
    V v_t_2435 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2434})});
    V v_t_2436 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_2415, 2)), 1, (V[]){v_t_2435}));
    V f_ = heff_dup(heff_rfield(v_hd_2415, 1));
    heff_room[0] = v_t_2436;
    heff_room[1] = heff_clo_n(g_std_2eprocess_2ewithProcess_24s1345957496x637138289_lam4, 1, 4, (V[]){v_x_2427, v_hd_2415, v_ex_240, v_k_2416});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_x_2424);
  }
}
V g_std_2eprocess_2ewithProcess_24s1345957496x637138289_lam1(V self, V *args) {
  V v_hd_2415 = args[0];
  V v_k_2416 = args[1];
  V v_a_2414 = heff_env(self)[0];
  V v_ex_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2414})});
  V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
  V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
  V v_t_2422 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2421})});
  V v_t_2423 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_2415, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2422})}));
  V f_ = heff_dup(heff_rfield(v_hd_2415, 1));
  args[0] = v_t_2423;
  args[1] = heff_clo_n(g_std_2eprocess_2ewithProcess_24s1345957496x637138289_lam2, 1, 3, (V[]){v_ex_240, v_hd_2415, v_k_2416});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_std_2eprocess_2erun_24s1262677465x1574883892_str0, 0, "");
V g_std_2eprocess_2erun_24s1262677465x1574883892_lam0(V self, V *args); static Clo g_std_2eprocess_2erun_24s1262677465x1574883892_lam0_clo = {{0x80000000u, K_CLO, 0}, g_std_2eprocess_2erun_24s1262677465x1574883892_lam0, 1, 0};
Clo g_std_2eprocess_2erun_24s1262677465x1574883892_clo = {{0x80000000u, K_CLO, 0}, g_std_2eprocess_2erun_24s1262677465x1574883892_entry, 5, 0};

V g_std_2eprocess_2erun_24s1262677465x1574883892(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244) {
top: ;
  V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){v_lit_242, NTAG(TAG_Nil)});
  V v_t_246 = ({ V b_0 = NTAG(TAG_Nil); V b_1 = NTAG(TAG_Nil); V r_ = (g_std_2epath_2esameSegments(b_0, b_1)); heff_drop(b_0); heff_drop(b_1); r_; });
  V v_t_247;
  if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
    heff_drop(v_t_246);
    v_t_247 = ((V)&g_std_2eprocess_2erun_24s1262677465x1574883892_str0);
  } else {
    heff_drop(v_t_246);
    v_t_247 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V b_1 = heff_dup(g_std_2epath_2ecurrent_get()); V r_ = (g_std_2epath_2erender(b_0, b_1)); heff_drop(b_0); heff_drop(b_1); r_; });
  }
  V v_t_248 = heff_rec_n(10, shape_command__args__dir__env__input__output__errors__timeout__keep__group, (V[]){v_lit_240, heff_tag_n(TAG_Cons, 2, (V[]){v_lit_241, v_t_245}), v_t_247, NTAG(TAG_Nil), NTAG(TAG_NoInput), NTAG(TAG_Collected), NTAG(TAG_Collected), v_lit_243, v_lit_244, NTAG(TAG_False)});
  V v_a_2410 = heff_tag_n(TAG_Run, 2, (V[]){v_t_248, ((V)&g_std_2eprocess_2erun_24s1262677465x1574883892_lam0_clo)});
  V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2410})});
  V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
  V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
  V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
  V v_t_2416 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2415})});
  return heff_tail(((V)&g_co_2eop_24s847889387x1388281137_clo), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2416})});
}
V g_std_2eprocess_2erun_24s1262677465x1574883892_entry(V self, V *a) {
  (void)self;
  return g_std_2eprocess_2erun_24s1262677465x1574883892(a[0], a[1], a[2], a[3], a[4]);
}
V g_std_2eprocess_2erun_24s1262677465x1574883892_lam0(V self, V *args) {
  V v_r_249 = args[0];
  return v_r_249;
}
V g_std_2eprocess_2ewithProcess_24s2044712421x1082792288_lam0(V self, V *args); static Clo g_std_2eprocess_2ewithProcess_24s2044712421x1082792288_lam0_clo = {{0x80000000u, K_CLO, 0}, g_std_2eprocess_2ewithProcess_24s2044712421x1082792288_lam0, 1, 0};
V g_std_2eprocess_2ewithProcess_24s2044712421x1082792288_lam1(V self, V *args);
Clo g_std_2eprocess_2ewithProcess_24s2044712421x1082792288_clo = {{0x80000000u, K_CLO, 0}, g_std_2eprocess_2ewithProcess_24s2044712421x1082792288_entry, 3, 0};

V g_std_2eprocess_2ewithProcess_24s2044712421x1082792288(V v_ex_240, V v_c_241, V v_body_242) {
top: ;
  V v_command_243 = heff_take_field(v_c_241, 0);
  V v_args_244 = heff_take_field(v_c_241, 1);
  V v_dir_245 = heff_take_field(v_c_241, 2);
  V v_env_246 = heff_take_field(v_c_241, 3);
  V v_input_247 = heff_take_field(v_c_241, 4);
  V v_output_248 = heff_take_field(v_c_241, 5);
  V v_errors_249 = heff_take_field(v_c_241, 6);
  V v_timeout_2410 = heff_take_field(v_c_241, 7);
  V v_keep_2411 = heff_take_field(v_c_241, 8);
  V v_group_2412 = heff_get_n(v_c_241, 9, 10);
  V v_t_2413 = ({ V a_0 = v_dir_245; V r_ = (g_std_2eprocess_2edirFor(a_0)); heff_drop(v_dir_245); r_; });
  V v_a_2415 = heff_tag_n(TAG_Start, 2, (V[]){heff_rec_n(10, shape_command__args__dir__env__input__output__errors__timeout__keep__group, (V[]){v_command_243, v_args_244, v_t_2413, v_env_246, v_input_247, v_output_248, v_errors_249, v_timeout_2410, v_keep_2411, v_group_2412}), ((V)&g_std_2eprocess_2ewithProcess_24s2044712421x1082792288_lam0_clo)});
  return heff_clo_n(g_std_2eprocess_2ewithProcess_24s2044712421x1082792288_lam1, 2, 3, (V[]){v_a_2415, v_ex_240, v_body_242});
}
V g_std_2eprocess_2ewithProcess_24s2044712421x1082792288_entry(V self, V *a) {
  (void)self;
  return g_std_2eprocess_2ewithProcess_24s2044712421x1082792288(a[0], a[1], a[2]);
}
V g_std_2eprocess_2ewithProcess_24s2044712421x1082792288_lam0(V self, V *args) {
  V v_s_2414 = args[0];
  return v_s_2414;
}
V g_std_2eprocess_2ewithProcess_24s2044712421x1082792288_lam1(V self, V *args) {
  V v_hd_2416 = args[0];
  V v_k_2417 = args[1];
  V v_a_2415 = heff_env(self)[0];
  V v_ex_240 = heff_env(self)[1];
  V v_body_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2415})});
  V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
  V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
  V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
  V v_t_2423 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2422})});
  return (g_co_2eop_24s760975558x1999937727(v_ex_240, v_body_242, heff_dup(v_hd_2416), v_k_2417, heff_tag_n(TAG_InR, 1, (V[]){v_t_2423}), v_hd_2416));
}