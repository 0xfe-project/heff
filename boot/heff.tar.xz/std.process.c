// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Args 26338
#define TAG_CloseInput 41785
#define TAG_Exec 20138
#define TAG_Exit 20279
#define TAG_GetEnv 43934
#define TAG_Kill 53643
#define TAG_Platform 55558
#define TAG_Processors 11008
#define TAG_ProgramPath 46819
#define TAG_ReadErrors 12846
#define TAG_ReadOutput 34844
#define TAG_Release 43671
#define TAG_Run 29975
#define TAG_Start 63542
#define TAG_Terminate 62553
#define TAG_TryWait 64330
#define TAG_Wait 10206
#define TAG_WorkingDir 28879
#define TAG_WriteInput 15010
#define LBL_hfmap 300551096
#define LBL_hmap 9701563
static uint32_t shape_hfmap__hmap[] = {LBL_hfmap, LBL_hmap};
V g_std_2eprocess_2eprocess_get(void);
V g_std_2eprocess_2eprocess_lam1(V self, V *args);
V g_std_2eprocess_2eprocess_lam2(V self, V *args);
V g_std_2eprocess_2eprocess_lam3(V self, V *args);
V g_std_2eprocess_2eprocess_lam4(V self, V *args);
V g_std_2eprocess_2eprocess_lam5(V self, V *args);
V g_std_2eprocess_2eprocess_lam6(V self, V *args);
V g_std_2eprocess_2eprocess_lam7(V self, V *args);
V g_std_2eprocess_2eprocess_lam8(V self, V *args);
V g_std_2eprocess_2eprocess_lam9(V self, V *args);
V g_std_2eprocess_2eprocess_lam10(V self, V *args);
V g_std_2eprocess_2eprocess_lam11(V self, V *args);
V g_std_2eprocess_2eprocess_lam12(V self, V *args);
V g_std_2eprocess_2eprocess_lam13(V self, V *args);
V g_std_2eprocess_2eprocess_lam14(V self, V *args);
V g_std_2eprocess_2eprocess_lam15(V self, V *args);
V g_std_2eprocess_2eprocess_lam0(V self, V *args); static Clo g_std_2eprocess_2eprocess_lam0_clo = {{0x80000000u, K_CLO, 0}, g_std_2eprocess_2eprocess_lam0, 3, 0};
V g_std_2eprocess_2eprocess_lam16(V self, V *args); static Clo g_std_2eprocess_2eprocess_lam16_clo = {{0x80000000u, K_CLO, 0}, g_std_2eprocess_2eprocess_lam16, 4, 0};

static V g_std_2eprocess_2eprocess_val;
static HEFF_ONCE g_std_2eprocess_2eprocess_st;
static V g_std_2eprocess_2eprocess_init(void) {
  return heff_rec_n(2, shape_hfmap__hmap, (V[]){((V)&g_std_2eprocess_2eprocess_lam0_clo), ((V)&g_std_2eprocess_2eprocess_lam16_clo)});
}
V g_std_2eprocess_2eprocess_get(void) {
  if (HEFF_DONE(g_std_2eprocess_2eprocess_st)) return g_std_2eprocess_2eprocess_val;
  return heff_global(&g_std_2eprocess_2eprocess_val, &g_std_2eprocess_2eprocess_st, g_std_2eprocess_2eprocess_init);
}
V g_std_2eprocess_2eprocess_lam1(V self, V *args) {
  V v_a_244 = args[0];
  V v_k_243 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_245 = heff_tr(heff_call(v_k_243, 1, (V[]){v_a_244}));
  V f_ = v_g_241;
  args[0] = v_t_245;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2eprocess_2eprocess_lam2(V self, V *args) {
  V v_v_248 = args[0];
  V v_k_247 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_249 = heff_tr(heff_call(v_k_247, 1, (V[]){v_v_248}));
  V f_ = v_g_241;
  args[0] = v_t_249;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2eprocess_2eprocess_lam3(V self, V *args) {
  V v_s_2411 = args[0];
  V v_k_2410 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2412 = heff_tr(heff_call(v_k_2410, 1, (V[]){v_s_2411}));
  V f_ = v_g_241;
  args[0] = v_t_2412;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2eprocess_2eprocess_lam4(V self, V *args) {
  V v_s_2414 = args[0];
  V v_k_2413 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2415 = heff_tr(heff_call(v_k_2413, 1, (V[]){v_s_2414}));
  V f_ = v_g_241;
  args[0] = v_t_2415;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2eprocess_2eprocess_lam5(V self, V *args) {
  V v_s_2417 = args[0];
  V v_k_2416 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2418 = heff_tr(heff_call(v_k_2416, 1, (V[]){v_s_2417}));
  V f_ = v_g_241;
  args[0] = v_t_2418;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2eprocess_2eprocess_lam6(V self, V *args) {
  V v_n_2420 = args[0];
  V v_k_2419 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2421 = heff_tr(heff_call(v_k_2419, 1, (V[]){v_n_2420}));
  V f_ = v_g_241;
  args[0] = v_t_2421;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2eprocess_2eprocess_lam7(V self, V *args) {
  V v_r_2431 = args[0];
  V v_k_2430 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2432 = heff_tr(heff_call(v_k_2430, 1, (V[]){v_r_2431}));
  V f_ = v_g_241;
  args[0] = v_t_2432;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2eprocess_2eprocess_lam8(V self, V *args) {
  V v_s_2435 = args[0];
  V v_k_2434 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2436 = heff_tr(heff_call(v_k_2434, 1, (V[]){v_s_2435}));
  V f_ = v_g_241;
  args[0] = v_t_2436;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2eprocess_2eprocess_lam9(V self, V *args) {
  V v_r_2439 = args[0];
  V v_k_2438 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2440 = heff_tr(heff_call(v_k_2438, 1, (V[]){v_r_2439}));
  V f_ = v_g_241;
  args[0] = v_t_2440;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2eprocess_2eprocess_lam10(V self, V *args) {
  V v_r_2443 = args[0];
  V v_k_2442 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2444 = heff_tr(heff_call(v_k_2442, 1, (V[]){v_r_2443}));
  V f_ = v_g_241;
  args[0] = v_t_2444;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2eprocess_2eprocess_lam11(V self, V *args) {
  V v_r_2447 = args[0];
  V v_k_2446 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2448 = heff_tr(heff_call(v_k_2446, 1, (V[]){v_r_2447}));
  V f_ = v_g_241;
  args[0] = v_t_2448;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2eprocess_2eprocess_lam12(V self, V *args) {
  V v_r_2454 = args[0];
  V v_k_2453 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2455 = heff_tr(heff_call(v_k_2453, 1, (V[]){v_r_2454}));
  V f_ = v_g_241;
  args[0] = v_t_2455;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2eprocess_2eprocess_lam13(V self, V *args) {
  V v_r_2459 = args[0];
  V v_k_2458 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2460 = heff_tr(heff_call(v_k_2458, 1, (V[]){v_r_2459}));
  V f_ = v_g_241;
  args[0] = v_t_2460;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2eprocess_2eprocess_lam14(V self, V *args) {
  V v_r_2468 = args[0];
  V v_k_2467 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2469 = heff_tr(heff_call(v_k_2467, 1, (V[]){v_r_2468}));
  V f_ = v_g_241;
  args[0] = v_t_2469;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2eprocess_2eprocess_lam15(V self, V *args) {
  V v_r_2474 = args[0];
  V v_k_2473 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2475 = heff_tr(heff_call(v_k_2473, 1, (V[]){v_r_2474}));
  V f_ = v_g_241;
  args[0] = v_t_2475;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_std_2eprocess_2eprocess_lam0(V self, V *args) {
  V v_m_240 = args[0];
  V v_g_241 = args[1];
  V v_p_242 = args[2];
  heff_drop(v_m_240);
  switch (heff_tag_of(v_p_242)) {
  case TAG_Args: {
    V v_k_243 = heff_field(v_p_242, 0);
    V v_ru_24p_242_24Args = heff_take_reuse_n(v_p_242, 1ULL, 1);
    return heff_tag_at_n(v_ru_24p_242_24Args, TAG_Args, 1, (V[]){heff_clo_n(g_std_2eprocess_2eprocess_lam1, 1, 2, (V[]){v_k_243, v_g_241})});
  }
  case TAG_GetEnv: {
    V v_name_246 = heff_field(v_p_242, 0);
    V v_k_247 = heff_field(v_p_242, 1);
    V v_ru_24p_242_24GetEnv = heff_take_reuse_n(v_p_242, 3ULL, 2);
    return heff_tag_at_n(v_ru_24p_242_24GetEnv, TAG_GetEnv, 2, (V[]){v_name_246, heff_clo_n(g_std_2eprocess_2eprocess_lam2, 1, 2, (V[]){v_k_247, v_g_241})});
  }
  case TAG_ProgramPath: {
    V v_k_2410 = heff_field(v_p_242, 0);
    V v_ru_24p_242_24ProgramPath = heff_take_reuse_n(v_p_242, 1ULL, 1);
    return heff_tag_at_n(v_ru_24p_242_24ProgramPath, TAG_ProgramPath, 1, (V[]){heff_clo_n(g_std_2eprocess_2eprocess_lam3, 1, 2, (V[]){v_k_2410, v_g_241})});
  }
  case TAG_WorkingDir: {
    V v_k_2413 = heff_field(v_p_242, 0);
    V v_ru_24p_242_24WorkingDir = heff_take_reuse_n(v_p_242, 1ULL, 1);
    return heff_tag_at_n(v_ru_24p_242_24WorkingDir, TAG_WorkingDir, 1, (V[]){heff_clo_n(g_std_2eprocess_2eprocess_lam4, 1, 2, (V[]){v_k_2413, v_g_241})});
  }
  case TAG_Platform: {
    V v_k_2416 = heff_field(v_p_242, 0);
    V v_ru_24p_242_24Platform = heff_take_reuse_n(v_p_242, 1ULL, 1);
    return heff_tag_at_n(v_ru_24p_242_24Platform, TAG_Platform, 1, (V[]){heff_clo_n(g_std_2eprocess_2eprocess_lam5, 1, 2, (V[]){v_k_2416, v_g_241})});
  }
  case TAG_Processors: {
    V v_k_2419 = heff_field(v_p_242, 0);
    V v_ru_24p_242_24Processors = heff_take_reuse_n(v_p_242, 1ULL, 1);
    return heff_tag_at_n(v_ru_24p_242_24Processors, TAG_Processors, 1, (V[]){heff_clo_n(g_std_2eprocess_2eprocess_lam6, 1, 2, (V[]){v_k_2419, v_g_241})});
  }
  case TAG_Exit: {
    V v_code_2422 = heff_field(v_p_242, 0);
    V v_x_2423 = heff_field(v_p_242, 1);
    V v_ru_24p_242_24Exit = heff_take_reuse_n(v_p_242, 3ULL, 2);
    V v_t_2424 = heff_tr(heff_call(v_g_241, 1, (V[]){v_x_2423}));
    return heff_tag_at_n(v_ru_24p_242_24Exit, TAG_Exit, 2, (V[]){v_code_2422, v_t_2424});
  }
  case TAG_Exec: {
    V v_cmd_2425 = heff_field(v_p_242, 0);
    V v_as_2426 = heff_field(v_p_242, 1);
    V v_x_2427 = heff_field(v_p_242, 2);
    V v_ru_24p_242_24Exec = heff_take_reuse_n(v_p_242, 7ULL, 3);
    V v_t_2428 = heff_tr(heff_call(v_g_241, 1, (V[]){v_x_2427}));
    return heff_tag_at_n(v_ru_24p_242_24Exec, TAG_Exec, 3, (V[]){v_cmd_2425, v_as_2426, v_t_2428});
  }
  case TAG_Run: {
    V v_c_2429 = heff_field(v_p_242, 0);
    V v_k_2430 = heff_field(v_p_242, 1);
    V v_ru_24p_242_24Run = heff_take_reuse_n(v_p_242, 3ULL, 2);
    return heff_tag_at_n(v_ru_24p_242_24Run, TAG_Run, 2, (V[]){v_c_2429, heff_clo_n(g_std_2eprocess_2eprocess_lam7, 1, 2, (V[]){v_k_2430, v_g_241})});
  }
  case TAG_Start: {
    V v_c_2433 = heff_field(v_p_242, 0);
    V v_k_2434 = heff_field(v_p_242, 1);
    V v_ru_24p_242_24Start = heff_take_reuse_n(v_p_242, 3ULL, 2);
    return heff_tag_at_n(v_ru_24p_242_24Start, TAG_Start, 2, (V[]){v_c_2433, heff_clo_n(g_std_2eprocess_2eprocess_lam8, 1, 2, (V[]){v_k_2434, v_g_241})});
  }
  case TAG_Release: {
    V v_s_2437 = heff_field(v_p_242, 0);
    V v_k_2438 = heff_field(v_p_242, 1);
    V v_ru_24p_242_24Release = heff_take_reuse_n(v_p_242, 3ULL, 2);
    return heff_tag_at_n(v_ru_24p_242_24Release, TAG_Release, 2, (V[]){v_s_2437, heff_clo_n(g_std_2eprocess_2eprocess_lam9, 1, 2, (V[]){v_k_2438, v_g_241})});
  }
  case TAG_Wait: {
    V v_s_2441 = heff_field(v_p_242, 0);
    V v_k_2442 = heff_field(v_p_242, 1);
    V v_ru_24p_242_24Wait = heff_take_reuse_n(v_p_242, 3ULL, 2);
    return heff_tag_at_n(v_ru_24p_242_24Wait, TAG_Wait, 2, (V[]){v_s_2441, heff_clo_n(g_std_2eprocess_2eprocess_lam10, 1, 2, (V[]){v_k_2442, v_g_241})});
  }
  case TAG_TryWait: {
    V v_s_2445 = heff_field(v_p_242, 0);
    V v_k_2446 = heff_field(v_p_242, 1);
    V v_ru_24p_242_24TryWait = heff_take_reuse_n(v_p_242, 3ULL, 2);
    return heff_tag_at_n(v_ru_24p_242_24TryWait, TAG_TryWait, 2, (V[]){v_s_2445, heff_clo_n(g_std_2eprocess_2eprocess_lam11, 1, 2, (V[]){v_k_2446, v_g_241})});
  }
  case TAG_Kill: {
    V v_s_2449 = heff_field(v_p_242, 0);
    V v_x_2450 = heff_field(v_p_242, 1);
    V v_ru_24p_242_24Kill = heff_take_reuse_n(v_p_242, 3ULL, 2);
    V v_t_2451 = heff_tr(heff_call(v_g_241, 1, (V[]){v_x_2450}));
    return heff_tag_at_n(v_ru_24p_242_24Kill, TAG_Kill, 2, (V[]){v_s_2449, v_t_2451});
  }
  case TAG_Terminate: {
    V v_s_2452 = heff_field(v_p_242, 0);
    V v_k_2453 = heff_field(v_p_242, 1);
    V v_ru_24p_242_24Terminate = heff_take_reuse_n(v_p_242, 3ULL, 2);
    return heff_tag_at_n(v_ru_24p_242_24Terminate, TAG_Terminate, 2, (V[]){v_s_2452, heff_clo_n(g_std_2eprocess_2eprocess_lam12, 1, 2, (V[]){v_k_2453, v_g_241})});
  }
  case TAG_WriteInput: {
    V v_s_2456 = heff_field(v_p_242, 0);
    V v_b_2457 = heff_field(v_p_242, 1);
    V v_k_2458 = heff_field(v_p_242, 2);
    V v_ru_24p_242_24WriteInput = heff_take_reuse_n(v_p_242, 7ULL, 3);
    return heff_tag_at_n(v_ru_24p_242_24WriteInput, TAG_WriteInput, 3, (V[]){v_s_2456, v_b_2457, heff_clo_n(g_std_2eprocess_2eprocess_lam13, 1, 2, (V[]){v_k_2458, v_g_241})});
  }
  case TAG_CloseInput: {
    V v_s_2461 = heff_field(v_p_242, 0);
    V v_x_2462 = heff_field(v_p_242, 1);
    V v_ru_24p_242_24CloseInput = heff_take_reuse_n(v_p_242, 3ULL, 2);
    V v_t_2463 = heff_tr(heff_call(v_g_241, 1, (V[]){v_x_2462}));
    return heff_tag_at_n(v_ru_24p_242_24CloseInput, TAG_CloseInput, 2, (V[]){v_s_2461, v_t_2463});
  }
  case TAG_ReadOutput: {
    V v_s_2464 = heff_field(v_p_242, 0);
    V v_n_2465 = heff_field(v_p_242, 1);
    V v_ms_2466 = heff_field(v_p_242, 2);
    V v_k_2467 = heff_field(v_p_242, 3);
    V v_ru_24p_242_24ReadOutput = heff_take_reuse_n(v_p_242, 15ULL, 4);
    return heff_tag_at_n(v_ru_24p_242_24ReadOutput, TAG_ReadOutput, 4, (V[]){v_s_2464, v_n_2465, v_ms_2466, heff_clo_n(g_std_2eprocess_2eprocess_lam14, 1, 2, (V[]){v_k_2467, v_g_241})});
  }
  case TAG_ReadErrors: {
    V v_s_2470 = heff_field(v_p_242, 0);
    V v_n_2471 = heff_field(v_p_242, 1);
    V v_ms_2472 = heff_field(v_p_242, 2);
    V v_k_2473 = heff_field(v_p_242, 3);
    V v_ru_24p_242_24ReadErrors = heff_take_reuse_n(v_p_242, 15ULL, 4);
    return heff_tag_at_n(v_ru_24p_242_24ReadErrors, TAG_ReadErrors, 4, (V[]){v_s_2470, v_n_2471, v_ms_2472, heff_clo_n(g_std_2eprocess_2eprocess_lam15, 1, 2, (V[]){v_k_2473, v_g_241})});
  }
  default: return heff_nomatch(v_p_242);
  }
}
V g_std_2eprocess_2eprocess_lam16(V self, V *args) {
  V v_m_2476 = args[0];
  V v_n_2477 = args[1];
  V v_nt_2478 = args[2];
  V v_p_2479 = args[3];
  heff_drop(v_m_2476);
  heff_drop(v_n_2477);
  heff_drop(v_nt_2478);
  switch (heff_tag_of(v_p_2479)) {
  case TAG_Args: {
    V v_k_2480 = heff_field(v_p_2479, 0);
    V v_ru_24p_2479_24Args = heff_take_reuse_n(v_p_2479, 1ULL, 1);
    return heff_tag_at_n(v_ru_24p_2479_24Args, TAG_Args, 1, (V[]){v_k_2480});
  }
  case TAG_GetEnv: {
    V v_name_2481 = heff_field(v_p_2479, 0);
    V v_k_2482 = heff_field(v_p_2479, 1);
    V v_ru_24p_2479_24GetEnv = heff_take_reuse_n(v_p_2479, 3ULL, 2);
    return heff_tag_at_n(v_ru_24p_2479_24GetEnv, TAG_GetEnv, 2, (V[]){v_name_2481, v_k_2482});
  }
  case TAG_ProgramPath: {
    V v_k_2483 = heff_field(v_p_2479, 0);
    V v_ru_24p_2479_24ProgramPath = heff_take_reuse_n(v_p_2479, 1ULL, 1);
    return heff_tag_at_n(v_ru_24p_2479_24ProgramPath, TAG_ProgramPath, 1, (V[]){v_k_2483});
  }
  case TAG_WorkingDir: {
    V v_k_2484 = heff_field(v_p_2479, 0);
    V v_ru_24p_2479_24WorkingDir = heff_take_reuse_n(v_p_2479, 1ULL, 1);
    return heff_tag_at_n(v_ru_24p_2479_24WorkingDir, TAG_WorkingDir, 1, (V[]){v_k_2484});
  }
  case TAG_Platform: {
    V v_k_2485 = heff_field(v_p_2479, 0);
    V v_ru_24p_2479_24Platform = heff_take_reuse_n(v_p_2479, 1ULL, 1);
    return heff_tag_at_n(v_ru_24p_2479_24Platform, TAG_Platform, 1, (V[]){v_k_2485});
  }
  case TAG_Processors: {
    V v_k_2486 = heff_field(v_p_2479, 0);
    V v_ru_24p_2479_24Processors = heff_take_reuse_n(v_p_2479, 1ULL, 1);
    return heff_tag_at_n(v_ru_24p_2479_24Processors, TAG_Processors, 1, (V[]){v_k_2486});
  }
  case TAG_Exit: {
    V v_code_2487 = heff_field(v_p_2479, 0);
    V v_x_2488 = heff_field(v_p_2479, 1);
    V v_ru_24p_2479_24Exit = heff_take_reuse_n(v_p_2479, 3ULL, 2);
    return heff_tag_at_n(v_ru_24p_2479_24Exit, TAG_Exit, 2, (V[]){v_code_2487, v_x_2488});
  }
  case TAG_Exec: {
    V v_cmd_2489 = heff_field(v_p_2479, 0);
    V v_as_2490 = heff_field(v_p_2479, 1);
    V v_x_2491 = heff_field(v_p_2479, 2);
    V v_ru_24p_2479_24Exec = heff_take_reuse_n(v_p_2479, 7ULL, 3);
    return heff_tag_at_n(v_ru_24p_2479_24Exec, TAG_Exec, 3, (V[]){v_cmd_2489, v_as_2490, v_x_2491});
  }
  case TAG_Run: {
    V v_c_2492 = heff_field(v_p_2479, 0);
    V v_k_2493 = heff_field(v_p_2479, 1);
    V v_ru_24p_2479_24Run = heff_take_reuse_n(v_p_2479, 3ULL, 2);
    return heff_tag_at_n(v_ru_24p_2479_24Run, TAG_Run, 2, (V[]){v_c_2492, v_k_2493});
  }
  case TAG_Start: {
    V v_c_2494 = heff_field(v_p_2479, 0);
    V v_k_2495 = heff_field(v_p_2479, 1);
    V v_ru_24p_2479_24Start = heff_take_reuse_n(v_p_2479, 3ULL, 2);
    return heff_tag_at_n(v_ru_24p_2479_24Start, TAG_Start, 2, (V[]){v_c_2494, v_k_2495});
  }
  case TAG_Release: {
    V v_s_2496 = heff_field(v_p_2479, 0);
    V v_k_2497 = heff_field(v_p_2479, 1);
    V v_ru_24p_2479_24Release = heff_take_reuse_n(v_p_2479, 3ULL, 2);
    return heff_tag_at_n(v_ru_24p_2479_24Release, TAG_Release, 2, (V[]){v_s_2496, v_k_2497});
  }
  case TAG_Wait: {
    V v_s_2498 = heff_field(v_p_2479, 0);
    V v_k_2499 = heff_field(v_p_2479, 1);
    V v_ru_24p_2479_24Wait = heff_take_reuse_n(v_p_2479, 3ULL, 2);
    return heff_tag_at_n(v_ru_24p_2479_24Wait, TAG_Wait, 2, (V[]){v_s_2498, v_k_2499});
  }
  case TAG_TryWait: {
    V v_s_24100 = heff_field(v_p_2479, 0);
    V v_k_24101 = heff_field(v_p_2479, 1);
    V v_ru_24p_2479_24TryWait = heff_take_reuse_n(v_p_2479, 3ULL, 2);
    return heff_tag_at_n(v_ru_24p_2479_24TryWait, TAG_TryWait, 2, (V[]){v_s_24100, v_k_24101});
  }
  case TAG_Kill: {
    V v_s_24102 = heff_field(v_p_2479, 0);
    V v_x_24103 = heff_field(v_p_2479, 1);
    V v_ru_24p_2479_24Kill = heff_take_reuse_n(v_p_2479, 3ULL, 2);
    return heff_tag_at_n(v_ru_24p_2479_24Kill, TAG_Kill, 2, (V[]){v_s_24102, v_x_24103});
  }
  case TAG_Terminate: {
    V v_s_24104 = heff_field(v_p_2479, 0);
    V v_k_24105 = heff_field(v_p_2479, 1);
    V v_ru_24p_2479_24Terminate = heff_take_reuse_n(v_p_2479, 3ULL, 2);
    return heff_tag_at_n(v_ru_24p_2479_24Terminate, TAG_Terminate, 2, (V[]){v_s_24104, v_k_24105});
  }
  case TAG_WriteInput: {
    V v_s_24106 = heff_field(v_p_2479, 0);
    V v_b_24107 = heff_field(v_p_2479, 1);
    V v_k_24108 = heff_field(v_p_2479, 2);
    V v_ru_24p_2479_24WriteInput = heff_take_reuse_n(v_p_2479, 7ULL, 3);
    return heff_tag_at_n(v_ru_24p_2479_24WriteInput, TAG_WriteInput, 3, (V[]){v_s_24106, v_b_24107, v_k_24108});
  }
  case TAG_CloseInput: {
    V v_s_24109 = heff_field(v_p_2479, 0);
    V v_x_24110 = heff_field(v_p_2479, 1);
    V v_ru_24p_2479_24CloseInput = heff_take_reuse_n(v_p_2479, 3ULL, 2);
    return heff_tag_at_n(v_ru_24p_2479_24CloseInput, TAG_CloseInput, 2, (V[]){v_s_24109, v_x_24110});
  }
  case TAG_ReadOutput: {
    V v_s_24111 = heff_field(v_p_2479, 0);
    V v_n_24112 = heff_field(v_p_2479, 1);
    V v_ms_24113 = heff_field(v_p_2479, 2);
    V v_k_24114 = heff_field(v_p_2479, 3);
    V v_ru_24p_2479_24ReadOutput = heff_take_reuse_n(v_p_2479, 15ULL, 4);
    return heff_tag_at_n(v_ru_24p_2479_24ReadOutput, TAG_ReadOutput, 4, (V[]){v_s_24111, v_n_24112, v_ms_24113, v_k_24114});
  }
  case TAG_ReadErrors: {
    V v_s_24115 = heff_field(v_p_2479, 0);
    V v_n_24116 = heff_field(v_p_2479, 1);
    V v_ms_24117 = heff_field(v_p_2479, 2);
    V v_k_24118 = heff_field(v_p_2479, 3);
    V v_ru_24p_2479_24ReadErrors = heff_take_reuse_n(v_p_2479, 15ULL, 4);
    return heff_tag_at_n(v_ru_24p_2479_24ReadErrors, TAG_ReadErrors, 4, (V[]){v_s_24115, v_n_24116, v_ms_24117, v_k_24118});
  }
  default: return heff_nomatch(v_p_2479);
  }
}