// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Bin 14227
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EVar 52881
#define TAG_MkArm 55352
#define TAG_MkSeen 11336
#define TAG_Tip 31527
#define TAG_Unreached 46435
#define TAG_Within 10658
#define LBL_body 9524841
#define LBL_byKey 295543458
#define LBL_callers 780494982
#define LBL_callersOf 583887482
#define LBL_calls 295783919
#define LBL_changed 970801394
#define LBL_dirty 296951788
#define LBL_escapes 914714193
#define LBL_fix 310927
#define LBL_gathered 1327153563
#define LBL_given 299725719
#define LBL_grown 299987669
#define LBL_ints 9732907
#define LBL_key 315609
#define LBL_marks 305024864
#define LBL_numeric 378927440
#define LBL_params 951713969
static uint32_t shape_byKey__callers__callersOf__ints[] = {LBL_byKey, LBL_callers, LBL_callersOf, LBL_ints};
static uint32_t shape_fix__dirty__gathered[] = {LBL_fix, LBL_dirty, LBL_gathered};
static uint32_t shape_numeric__given__calls__ints__escapes[] = {LBL_numeric, LBL_given, LBL_calls, LBL_ints, LBL_escapes};
static uint32_t shape_params__gathered__changed[] = {LBL_params, LBL_gathered, LBL_changed};
static uint32_t shape_params__grown__marks[] = {LBL_params, LBL_grown, LBL_marks};
V g_heff_2ecompile_2eir_2eappendI(V, V);
V g_heff_2ecompile_2eir_2eappendI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eappendI_clo;
V g_heff_2ecompile_2eir_2epushArms(V, V);
V g_heff_2ecompile_2eir_2epushArms_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2epushArms_clo;
V g_heff_2ecompile_2eir_2epushFields(V, V);
V g_heff_2ecompile_2eir_2epushFields_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2epushFields_clo;
V g_heff_2ecompile_2eranges_2eanyRange_get(void);
V g_heff_2ecompile_2eranges_2eemptyEnv_get(void);
V g_heff_2ecompile_2eranges_2eemptyScan_get(void);
V g_heff_2ecompile_2eranges_2efnOf(V, V);
V g_heff_2ecompile_2eranges_2efnOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2efnOf_clo;
V g_heff_2ecompile_2eranges_2efnOne(V, V, V, V);
V g_heff_2ecompile_2eranges_2efnOne_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2efnOne_clo;
HeffT2 g_heff_2ecompile_2eranges_2egatherArms_24cpr(V, V, V, V, V, V);
V g_heff_2ecompile_2eranges_2egivenFrom(V, V, V, V);
V g_heff_2ecompile_2eranges_2egivenFrom_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2egivenFrom_clo;
V g_heff_2ecompile_2eranges_2egrownOne(V, V, V, V);
V g_heff_2ecompile_2eranges_2egrownOne_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2egrownOne_clo;
V g_heff_2ecompile_2eranges_2egrownTo(V, V, V, V);
V g_heff_2ecompile_2eranges_2egrownTo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2egrownTo_clo;
V g_heff_2ecompile_2eranges_2ehighMeet(V, V);
V g_heff_2ecompile_2eranges_2ehighMeet_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2ehighMeet_clo;
V g_heff_2ecompile_2eranges_2eintOps_get(void);
V g_heff_2ecompile_2eranges_2ejoin(V, V);
V g_heff_2ecompile_2eranges_2ejoin_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2ejoin_clo;
V g_heff_2ecompile_2eranges_2ejoinedFor(V, V, V, V);
V g_heff_2ecompile_2eranges_2ejoinedFor_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2ejoinedFor_clo;
V g_heff_2ecompile_2eranges_2emarkRange(V, V);
V g_heff_2ecompile_2eranges_2emarkRange_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2emarkRange_clo;
V g_heff_2ecompile_2eranges_2emarksWith(V, V, V);
V g_heff_2ecompile_2eranges_2emarksWith_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2emarksWith_clo;
V g_heff_2ecompile_2eranges_2emodR(V, V);
V g_heff_2ecompile_2eranges_2emodR_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2emodR_clo;
V g_heff_2ecompile_2eranges_2enamesW(V, V);
V g_heff_2ecompile_2eranges_2enamesW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2enamesW_clo;
V g_heff_2ecompile_2eranges_2enarrowOnce(V, V, V, V);
V g_heff_2ecompile_2eranges_2enarrowOnce_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2enarrowOnce_clo;
V g_heff_2ecompile_2eranges_2enarrowTo(V, V, V);
V g_heff_2ecompile_2eranges_2enarrowTo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2enarrowTo_clo;
V g_heff_2ecompile_2eranges_2enarrowWith(V, V, V, V);
V g_heff_2ecompile_2eranges_2enarrowWith_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2enarrowWith_clo;
V g_heff_2ecompile_2eranges_2enarrowing(V, V, V, V);
V g_heff_2ecompile_2eranges_2enarrowing_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2enarrowing_clo;
V g_heff_2ecompile_2eranges_2enatural(V);
V g_heff_2ecompile_2eranges_2enatural_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2enatural_clo;
V g_heff_2ecompile_2eranges_2enonZero(V);
V g_heff_2ecompile_2eranges_2enonZero_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2enonZero_clo;
V g_heff_2ecompile_2eranges_2erangedIn(V, V, V, V);
V g_heff_2ecompile_2eranges_2erangedIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2erangedIn_clo;
V g_heff_2ecompile_2eranges_2erangesEq(V, V);
V g_heff_2ecompile_2eranges_2erangesEq_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2erangesEq_clo;
V g_heff_2ecompile_2eranges_2erefine(V, V, V, V);
V g_heff_2ecompile_2eranges_2erefine_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2erefine_clo;
V g_heff_2ecompile_2eranges_2erootGo(V, V, V);
V g_heff_2ecompile_2eranges_2erootGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2erootGo_clo;
V g_heff_2ecompile_2eranges_2erootTo(V, V, V);
V g_heff_2ecompile_2eranges_2erootTo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2erootTo_clo;
V g_heff_2ecompile_2eranges_2eroundOf(V, V, V, V);
V g_heff_2ecompile_2eranges_2eroundOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2eroundOf_clo;
V g_heff_2ecompile_2eranges_2erounds(V, V, V, V);
V g_heff_2ecompile_2eranges_2erounds_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2erounds_clo;
V g_heff_2ecompile_2eranges_2escanCall(V, V, V, V);
V g_heff_2ecompile_2eranges_2escanCall_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2escanCall_clo;
V g_heff_2ecompile_2eranges_2escanW(V, V, V);
V g_heff_2ecompile_2eranges_2escanW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2escanW_clo;
V g_heff_2ecompile_2eranges_2escopeOne(V, V, V, V);
V g_heff_2ecompile_2eranges_2escopeOne_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2escopeOne_clo;
V g_heff_2ecompile_2eranges_2escopeWith(V, V, V, V);
V g_heff_2ecompile_2eranges_2escopeWith_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2escopeWith_clo;
V g_heff_2ecompile_2eranges_2esettled(V, V, V, V);
V g_heff_2ecompile_2eranges_2esettled_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2esettled_clo;
V g_heff_2ecompile_2eranges_2etrimLow(V, V);
V g_heff_2ecompile_2eranges_2etrimLow_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2etrimLow_clo;
V g_heff_2ecompile_2eranges_2ewalkDef(V, V);
V g_heff_2ecompile_2eranges_2ewalkDef_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2ewalkDef_clo;
HeffT2 g_heff_2ecompile_2eranges_2ewalkGo_24cpr(V, V, V);
V g_heff_2ecompile_2eranges_2ewiden(V, V, V);
V g_heff_2ecompile_2eranges_2ewiden_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2ewiden_clo;
V g_heff_2ecompile_2eranges_2ewidenHigh(V, V, V);
V g_heff_2ecompile_2eranges_2ewidenHigh_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2ewidenHigh_clo;
V g_heff_2ecompile_2eranges_2ewidenLow(V, V, V);
V g_heff_2ecompile_2eranges_2ewidenLow_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2ewidenLow_clo;
V g_heff_2ecompile_2eranges_2ewithRange(V, V, V);
V g_heff_2ecompile_2eranges_2ewithRange_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2ewithRange_clo;
HeffT2 g_heff_2ecompile_2eranges_2ewordOf_24cpr(V, V, V);
V g_list_2eall_24s525729714x658270192(V);
V g_list_2eall_24s525729714x658270192_entry(V self, V *a);
extern Clo g_list_2eall_24s525729714x658270192_clo;
V g_list_2eall_24s853093203x77424416(V);
V g_list_2eall_24s853093203x77424416_entry(V self, V *a);
extern Clo g_list_2eall_24s853093203x77424416_clo;
V g_list_2eany_24s2065989517x1307020881(V, V);
V g_list_2eany_24s2065989517x1307020881_entry(V self, V *a);
extern Clo g_list_2eany_24s2065989517x1307020881_clo;
HeffT3 g_list_2edrop_24cpr(V, V);
V g_list_2efilter(V, V);
V g_list_2efilter_entry(V self, V *a);
extern Clo g_list_2efilter_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24s518632429x1911716206(V, V);
V g_list_2efoldl_24s518632429x1911716206_entry(V self, V *a);
extern Clo g_list_2efoldl_24s518632429x1911716206_clo;
V g_list_2efoldl_24s644727442x245553729(V, V);
V g_list_2efoldl_24s644727442x245553729_entry(V self, V *a);
extern Clo g_list_2efoldl_24s644727442x245553729_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2emap_24s1835183789x486277886(V);
V g_list_2emap_24s1835183789x486277886_entry(V self, V *a);
extern Clo g_list_2emap_24s1835183789x486277886_clo;
V g_list_2emap_24s1937570095x2110149801(V);
V g_list_2emap_24s1937570095x2110149801_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_clo;
V g_list_2emap_24s258116700x992061112(V, V);
V g_list_2emap_24s258116700x992061112_entry(V self, V *a);
extern Clo g_list_2emap_24s258116700x992061112_clo;
V g_list_2ezipWith(V, V, V);
V g_list_2ezipWith_entry(V self, V *a);
extern Clo g_list_2ezipWith_clo;
V g_list_2ezipWith_24s1876717925x1404326288(V, V);
V g_list_2ezipWith_24s1876717925x1404326288_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1876717925x1404326288_clo;
V g_std_2emap_2eempty_get(void);
V g_std_2emap_2einsert_24s1305793909x1049798133(V, V, V);
V g_std_2emap_2einsert_24s1305793909x1049798133_entry(V self, V *a);
extern Clo g_std_2emap_2einsert_24s1305793909x1049798133_clo;
V g_std_2emap_2einsert_24s170109517x1206653089(V, V, V);
V g_std_2emap_2einsert_24s170109517x1206653089_entry(V self, V *a);
extern Clo g_std_2emap_2einsert_24s170109517x1206653089_clo;
HeffT2 g_std_2emap_2elookup_24s1654411661x99037275_24cpr(V, V);
HeffT2 g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(V, V);
V g_std_2emap_2etoListOnto(V, V);
V g_std_2emap_2etoListOnto_entry(V self, V *a);
extern Clo g_std_2emap_2etoListOnto_clo;
Clo g_heff_2ecompile_2eranges_2emodR_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eranges_2emodR_entry, 2, 0};

V g_heff_2ecompile_2eranges_2emodR(V v_a_240, V v_b_241) {
top: ;
  switch (heff_tag_of(v_b_241)) {
  case TAG_Unreached: {
    return heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
  }
  case TAG_Within: {
    V v_lb_242 = heff_field(v_b_241, 0);
    V v_hb_243 = heff_field(v_b_241, 1);
    V v_ru_24b_241_24Within = heff_take_reuse_n(v_b_241, 3ULL, 2);
    V v_t_245;
    switch (heff_tag_of(v_lb_242)) {
    case TAG_Nothing: {
      v_t_245 = NTAG(TAG_False);
      break;
    }
    case TAG_Just: {
      V v_a_244 = heff_dup(heff_field(v_lb_242, 0));
      v_t_245 = heff_intLt(MK_INT(0LL), v_a_244);
      break;
    }
    default: heff_nomatch(v_lb_242);
    }
    if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
      heff_drop(v_lb_242);
      heff_drop(v_t_245);
      V v_t_247;
      switch (heff_tag_of(v_hb_243)) {
      case TAG_Nothing: {
        v_t_247 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Just: {
        V v_a_246 = heff_field(v_hb_243, 0);
        V v_ru_24hb_243_24Just = heff_take_reuse_n(v_hb_243, 1ULL, 1);
        v_t_247 = heff_tag_at_n(v_ru_24hb_243_24Just, TAG_Just, 1, (V[]){heff_intAdd(v_a_246, MK_INT(-1LL))});
        break;
      }
      default: heff_nomatch(v_hb_243);
      }
      V v_t_2414;
      switch (heff_tag_of(v_a_240)) {
      case TAG_Unreached: {
        v_t_2414 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Within: {
        V v_lo_248 = heff_field(v_a_240, 0);
        switch (heff_tag_of(v_lo_248)) {
        case TAG_Nothing: {
          v_t_2414 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_Just: {
          V v_a_2410 = heff_field(v_lo_248, 0);
          if (heff_intLe_c_lent(MK_INT(0LL), v_a_2410, 1)) {
            switch (heff_tag_of(v_a_240)) {
            case TAG_Unreached: {
              v_t_2414 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_Within: {
              V v_hi_2413 = heff_field(v_a_240, 1);
              v_t_2414 = heff_dup(v_hi_2413);
              break;
            }
            default: heff_nomatch(v_a_240);
            }
          } else {
            v_t_2414 = NTAG(TAG_Nothing);
          }
          break;
        }
        default: heff_nomatch(v_lo_248);
        }
        break;
      }
      default: heff_nomatch(v_a_240);
      }
      V v_t_2415 = (g_heff_2ecompile_2eranges_2ehighMeet(v_t_247, v_t_2414));
      return heff_tag_at_n(v_ru_24b_241_24Within, TAG_Within, 2, (V[]){heff_tag_n(TAG_Just, 1, (V[]){MK_INT(0LL)}), v_t_2415});
    } else {
      heff_drop(v_t_245);
      switch (heff_tag_of(v_hb_243)) {
      case TAG_Nothing: {
        heff_drop(v_lb_242);
        heff_drop_cell(v_ru_24b_241_24Within, 2);
        return heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
      }
      case TAG_Just: {
        V v_a_2416 = heff_field(v_hb_243, 0);
        V v_ru_24hb_243_24Just = heff_take_reuse_n(v_hb_243, 1ULL, 1);
        if (heff_intLt_c(v_a_2416, MK_INT(0LL))) {
          V v_t_2419;
          switch (heff_tag_of(v_lb_242)) {
          case TAG_Nothing: {
            heff_drop_cell(v_ru_24hb_243_24Just, 1);
            v_t_2419 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_Just: {
            V v_a_2418 = heff_field(v_lb_242, 0);
            heff_take_n(v_lb_242, 1ULL, 1);
            v_t_2419 = heff_tag_at_n(v_ru_24hb_243_24Just, TAG_Just, 1, (V[]){heff_intAdd(v_a_2418, MK_INT(1LL))});
            break;
          }
          default: heff_nomatch(v_lb_242);
          }
          return heff_tag_at_n(v_ru_24b_241_24Within, TAG_Within, 2, (V[]){v_t_2419, heff_tag_n(TAG_Just, 1, (V[]){MK_INT(0LL)})});
        } else {
          heff_drop(v_lb_242);
          heff_drop_cell(v_ru_24b_241_24Within, 2);
          heff_drop_cell(v_ru_24hb_243_24Just, 1);
          return heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
        }
      }
      default: return heff_nomatch(v_hb_243);
      }
    }
  }
  default: return heff_nomatch(v_b_241);
  }
}
V g_heff_2ecompile_2eranges_2emodR_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eranges_2emodR(a0, a[1]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ecompile_2eranges_2ewordOf_24cpr_str0, 6, "intAdd");
HEFF_LIT(g_heff_2ecompile_2eranges_2ewordOf_24cpr_str1, 7, "wordAdd");
HEFF_LIT(g_heff_2ecompile_2eranges_2ewordOf_24cpr_str2, 6, "intSub");
HEFF_LIT(g_heff_2ecompile_2eranges_2ewordOf_24cpr_str3, 7, "wordSub");
HEFF_LIT(g_heff_2ecompile_2eranges_2ewordOf_24cpr_str4, 6, "intMul");
HEFF_LIT(g_heff_2ecompile_2eranges_2ewordOf_24cpr_str5, 7, "wordMul");
HEFF_LIT(g_heff_2ecompile_2eranges_2ewordOf_24cpr_str6, 6, "intDiv");
HEFF_LIT(g_heff_2ecompile_2eranges_2ewordOf_24cpr_str7, 8, "wordQuot");
HEFF_LIT(g_heff_2ecompile_2eranges_2ewordOf_24cpr_str8, 7, "wordDiv");
HEFF_LIT(g_heff_2ecompile_2eranges_2ewordOf_24cpr_str9, 6, "intMod");
HEFF_LIT(g_heff_2ecompile_2eranges_2ewordOf_24cpr_str10, 7, "wordRem");
HEFF_LIT(g_heff_2ecompile_2eranges_2ewordOf_24cpr_str11, 7, "wordMod");
HEFF_LIT(g_heff_2ecompile_2eranges_2ewordOf_24cpr_str12, 5, "intEq");
HEFF_LIT(g_heff_2ecompile_2eranges_2ewordOf_24cpr_str13, 6, "wordEq");
HEFF_LIT(g_heff_2ecompile_2eranges_2ewordOf_24cpr_str14, 5, "intLt");
HEFF_LIT(g_heff_2ecompile_2eranges_2ewordOf_24cpr_str15, 6, "wordLt");
HEFF_LIT(g_heff_2ecompile_2eranges_2ewordOf_24cpr_str16, 5, "intLe");
HEFF_LIT(g_heff_2ecompile_2eranges_2ewordOf_24cpr_str17, 6, "wordLe");
HEFF_LIT(g_heff_2ecompile_2eranges_2ewordOf_24cpr_str18, 12, "floatFromInt");
HEFF_LIT(g_heff_2ecompile_2eranges_2ewordOf_24cpr_str19, 11, "wordToFloat");

HeffT2 g_heff_2ecompile_2eranges_2ewordOf_24cpr(V v_p_240, V v_rs_241, V v_r_242) {
top: ;
  if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2eranges_2ewordOf_24cpr_str0), 2)) {
    V v_t_244 = (g_list_2eall_24s525729714x658270192(v_rs_241));
    if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
      heff_drop(v_t_244);
      switch (heff_tag_of(v_r_242)) {
      case TAG_Unreached: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_Within: {
        V v_r1_245 = heff_field(v_r_242, 0);
        V v_r2_246 = heff_field(v_r_242, 1);
        heff_take_n(v_r_242, 3ULL, 2);
        switch (heff_tag_of(v_r1_245)) {
        case TAG_Nothing: {
          heff_drop(v_r2_246);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_Just: {
          V v_lo_247 = heff_field(v_r1_245, 0);
          heff_take_n(v_r1_245, 1ULL, 1);
          switch (heff_tag_of(v_r2_246)) {
          case TAG_Nothing: {
            heff_drop(v_lo_247);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          case TAG_Just: {
            V v_hi_248 = heff_field(v_r2_246, 0);
            heff_take_n(v_r2_246, 1ULL, 1);
            if (heff_intLe_c(MK_INT(-4611686018427387904LL), v_lo_247)) {
              if (heff_intLe_c(v_hi_248, MK_INT(4611686018427387903LL))) {
                return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), ((V)&g_heff_2ecompile_2eranges_2ewordOf_24cpr_str1)}});
              } else {
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
              }
            } else {
              heff_drop(v_hi_248);
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
            }
          }
          default: return ((HeffT2){{heff_nomatch(v_r2_246)}});
          }
        }
        default: return ((HeffT2){{heff_nomatch(v_r1_245)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_r_242)}});
      }
    } else {
      heff_drop(v_r_242);
      heff_drop(v_t_244);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
  } else {
    if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2eranges_2ewordOf_24cpr_str2), 2)) {
      V v_t_2412 = (g_list_2eall_24s525729714x658270192(v_rs_241));
      if ((heff_dup(v_t_2412) == NTAG(TAG_True))) {
        heff_drop(v_t_2412);
        switch (heff_tag_of(v_r_242)) {
        case TAG_Unreached: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_Within: {
          V v_r1_2413 = heff_field(v_r_242, 0);
          V v_r2_2414 = heff_field(v_r_242, 1);
          heff_take_n(v_r_242, 3ULL, 2);
          switch (heff_tag_of(v_r1_2413)) {
          case TAG_Nothing: {
            heff_drop(v_r2_2414);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          case TAG_Just: {
            V v_lo_2415 = heff_field(v_r1_2413, 0);
            heff_take_n(v_r1_2413, 1ULL, 1);
            switch (heff_tag_of(v_r2_2414)) {
            case TAG_Nothing: {
              heff_drop(v_lo_2415);
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
            }
            case TAG_Just: {
              V v_hi_2416 = heff_field(v_r2_2414, 0);
              heff_take_n(v_r2_2414, 1ULL, 1);
              if (heff_intLe_c(MK_INT(-4611686018427387904LL), v_lo_2415)) {
                if (heff_intLe_c(v_hi_2416, MK_INT(4611686018427387903LL))) {
                  return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), ((V)&g_heff_2ecompile_2eranges_2ewordOf_24cpr_str3)}});
                } else {
                  return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                }
              } else {
                heff_drop(v_hi_2416);
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
              }
            }
            default: return ((HeffT2){{heff_nomatch(v_r2_2414)}});
            }
          }
          default: return ((HeffT2){{heff_nomatch(v_r1_2413)}});
          }
        }
        default: return ((HeffT2){{heff_nomatch(v_r_242)}});
        }
      } else {
        heff_drop(v_r_242);
        heff_drop(v_t_2412);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    } else {
      if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2eranges_2ewordOf_24cpr_str4), 2)) {
        V v_t_2420 = (g_list_2eall_24s525729714x658270192(v_rs_241));
        if ((heff_dup(v_t_2420) == NTAG(TAG_True))) {
          heff_drop(v_t_2420);
          switch (heff_tag_of(v_r_242)) {
          case TAG_Unreached: {
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          case TAG_Within: {
            V v_r1_2421 = heff_field(v_r_242, 0);
            V v_r2_2422 = heff_field(v_r_242, 1);
            heff_take_n(v_r_242, 3ULL, 2);
            switch (heff_tag_of(v_r1_2421)) {
            case TAG_Nothing: {
              heff_drop(v_r2_2422);
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
            }
            case TAG_Just: {
              V v_lo_2423 = heff_field(v_r1_2421, 0);
              heff_take_n(v_r1_2421, 1ULL, 1);
              switch (heff_tag_of(v_r2_2422)) {
              case TAG_Nothing: {
                heff_drop(v_lo_2423);
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
              }
              case TAG_Just: {
                V v_hi_2424 = heff_field(v_r2_2422, 0);
                heff_take_n(v_r2_2422, 1ULL, 1);
                if (heff_intLe_c(MK_INT(-4611686018427387904LL), v_lo_2423)) {
                  if (heff_intLe_c(v_hi_2424, MK_INT(4611686018427387903LL))) {
                    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), ((V)&g_heff_2ecompile_2eranges_2ewordOf_24cpr_str5)}});
                  } else {
                    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                  }
                } else {
                  heff_drop(v_hi_2424);
                  return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                }
              }
              default: return ((HeffT2){{heff_nomatch(v_r2_2422)}});
              }
            }
            default: return ((HeffT2){{heff_nomatch(v_r1_2421)}});
            }
          }
          default: return ((HeffT2){{heff_nomatch(v_r_242)}});
          }
        } else {
          heff_drop(v_r_242);
          heff_drop(v_t_2420);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
      } else {
        if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2eranges_2ewordOf_24cpr_str6), 2)) {
          V v_t_2428 = (g_list_2eall_24s525729714x658270192(v_rs_241));
          if ((heff_dup(v_t_2428) == NTAG(TAG_True))) {
            heff_drop(v_t_2428);
            switch (heff_tag_of(v_r_242)) {
            case TAG_Unreached: {
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
            }
            case TAG_Within: {
              V v_r1_2429 = heff_field(v_r_242, 0);
              V v_r2_2430 = heff_field(v_r_242, 1);
              heff_take_n(v_r_242, 3ULL, 2);
              switch (heff_tag_of(v_r1_2429)) {
              case TAG_Nothing: {
                heff_drop(v_r2_2430);
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
              }
              case TAG_Just: {
                V v_lo_2431 = heff_field(v_r1_2429, 0);
                heff_take_n(v_r1_2429, 1ULL, 1);
                switch (heff_tag_of(v_r2_2430)) {
                case TAG_Nothing: {
                  heff_drop(v_lo_2431);
                  return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                }
                case TAG_Just: {
                  V v_hi_2432 = heff_field(v_r2_2430, 0);
                  heff_take_n(v_r2_2430, 1ULL, 1);
                  if (heff_intLe_c(MK_INT(-4611686018427387904LL), v_lo_2431)) {
                    if (heff_intLe_c(v_hi_2432, MK_INT(4611686018427387903LL))) {
                      HeffT3 v_t_2435 = (g_list_2edrop_24cpr(MK_INT(1LL), v_rs_241));
                      V v_t_2442;
                      {
                        V v_field_2437 = v_t_2435.f[1];
                        V v_field_2438 = v_t_2435.f[2];
                        int64_t v_tag_2436 = ((int64_t)v_t_2435.f[0]);
                        if ((v_tag_2436 == ((int64_t)0ULL))) {
                          V v_x_2440 = v_field_2437;
                          V v_x12_2441 = v_field_2438;
                          heff_drop(v_x12_2441);
                          v_t_2442 = v_x_2440;
                        } else {
                          heff_drop(v_field_2437);
                          heff_drop(v_field_2438);
                          v_t_2442 = heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
                        }
                      }
                      V v_t_2443 = ({ V a_0 = v_t_2442; V r_ = (g_heff_2ecompile_2eranges_2enonZero(a_0)); heff_drop(v_t_2442); r_; });
                      if ((heff_dup(v_t_2443) == NTAG(TAG_True))) {
                        heff_drop(v_t_2443);
                        V v_t_2444 = (g_heff_2ecompile_2eranges_2enatural(v_rs_241));
                        V v_f_2445;
                        if ((heff_dup(v_t_2444) == NTAG(TAG_True))) {
                          heff_drop(v_t_2444);
                          v_f_2445 = ((V)&g_heff_2ecompile_2eranges_2ewordOf_24cpr_str7);
                        } else {
                          heff_drop(v_t_2444);
                          v_f_2445 = ((V)&g_heff_2ecompile_2eranges_2ewordOf_24cpr_str8);
                        }
                        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2445}});
                      } else {
                        heff_drop(v_t_2443);
                        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                      }
                    } else {
                      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                    }
                  } else {
                    heff_drop(v_hi_2432);
                    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                  }
                }
                default: return ((HeffT2){{heff_nomatch(v_r2_2430)}});
                }
              }
              default: return ((HeffT2){{heff_nomatch(v_r1_2429)}});
              }
            }
            default: return ((HeffT2){{heff_nomatch(v_r_242)}});
            }
          } else {
            heff_drop(v_r_242);
            heff_drop(v_t_2428);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
        } else {
          if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2eranges_2ewordOf_24cpr_str9), 2)) {
            V v_t_2447 = (g_list_2eall_24s525729714x658270192(v_rs_241));
            if ((heff_dup(v_t_2447) == NTAG(TAG_True))) {
              heff_drop(v_t_2447);
              switch (heff_tag_of(v_r_242)) {
              case TAG_Unreached: {
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
              }
              case TAG_Within: {
                V v_r1_2448 = heff_field(v_r_242, 0);
                V v_r2_2449 = heff_field(v_r_242, 1);
                heff_take_n(v_r_242, 3ULL, 2);
                switch (heff_tag_of(v_r1_2448)) {
                case TAG_Nothing: {
                  heff_drop(v_r2_2449);
                  return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                }
                case TAG_Just: {
                  V v_lo_2450 = heff_field(v_r1_2448, 0);
                  heff_take_n(v_r1_2448, 1ULL, 1);
                  switch (heff_tag_of(v_r2_2449)) {
                  case TAG_Nothing: {
                    heff_drop(v_lo_2450);
                    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                  }
                  case TAG_Just: {
                    V v_hi_2451 = heff_field(v_r2_2449, 0);
                    heff_take_n(v_r2_2449, 1ULL, 1);
                    if (heff_intLe_c(MK_INT(-4611686018427387904LL), v_lo_2450)) {
                      if (heff_intLe_c(v_hi_2451, MK_INT(4611686018427387903LL))) {
                        HeffT3 v_t_2454 = (g_list_2edrop_24cpr(MK_INT(1LL), v_rs_241));
                        V v_t_2461;
                        {
                          V v_field_2456 = v_t_2454.f[1];
                          V v_field_2457 = v_t_2454.f[2];
                          int64_t v_tag_2455 = ((int64_t)v_t_2454.f[0]);
                          if ((v_tag_2455 == ((int64_t)0ULL))) {
                            V v_x_2459 = v_field_2456;
                            V v_x12_2460 = v_field_2457;
                            heff_drop(v_x12_2460);
                            v_t_2461 = v_x_2459;
                          } else {
                            heff_drop(v_field_2456);
                            heff_drop(v_field_2457);
                            v_t_2461 = heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
                          }
                        }
                        V v_t_2462 = ({ V a_0 = v_t_2461; V r_ = (g_heff_2ecompile_2eranges_2enonZero(a_0)); heff_drop(v_t_2461); r_; });
                        if ((heff_dup(v_t_2462) == NTAG(TAG_True))) {
                          heff_drop(v_t_2462);
                          V v_t_2463 = (g_heff_2ecompile_2eranges_2enatural(v_rs_241));
                          V v_f_2464;
                          if ((heff_dup(v_t_2463) == NTAG(TAG_True))) {
                            heff_drop(v_t_2463);
                            v_f_2464 = ((V)&g_heff_2ecompile_2eranges_2ewordOf_24cpr_str10);
                          } else {
                            heff_drop(v_t_2463);
                            v_f_2464 = ((V)&g_heff_2ecompile_2eranges_2ewordOf_24cpr_str11);
                          }
                          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2464}});
                        } else {
                          heff_drop(v_t_2462);
                          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                        }
                      } else {
                        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                      }
                    } else {
                      heff_drop(v_hi_2451);
                      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                    }
                  }
                  default: return ((HeffT2){{heff_nomatch(v_r2_2449)}});
                  }
                }
                default: return ((HeffT2){{heff_nomatch(v_r1_2448)}});
                }
              }
              default: return ((HeffT2){{heff_nomatch(v_r_242)}});
              }
            } else {
              heff_drop(v_r_242);
              heff_drop(v_t_2447);
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
            }
          } else {
            heff_drop(v_r_242);
            if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2eranges_2ewordOf_24cpr_str12), 2)) {
              V v_t_2466 = (g_list_2eall_24s525729714x658270192(v_rs_241));
              if ((heff_dup(v_t_2466) == NTAG(TAG_True))) {
                heff_drop(v_t_2466);
                return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), ((V)&g_heff_2ecompile_2eranges_2ewordOf_24cpr_str13)}});
              } else {
                heff_drop(v_t_2466);
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
              }
            } else {
              if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2eranges_2ewordOf_24cpr_str14), 2)) {
                V v_t_2468 = (g_list_2eall_24s525729714x658270192(v_rs_241));
                if ((heff_dup(v_t_2468) == NTAG(TAG_True))) {
                  heff_drop(v_t_2468);
                  return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), ((V)&g_heff_2ecompile_2eranges_2ewordOf_24cpr_str15)}});
                } else {
                  heff_drop(v_t_2468);
                  return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                }
              } else {
                if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2eranges_2ewordOf_24cpr_str16), 2)) {
                  V v_t_2470 = (g_list_2eall_24s525729714x658270192(v_rs_241));
                  if ((heff_dup(v_t_2470) == NTAG(TAG_True))) {
                    heff_drop(v_t_2470);
                    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), ((V)&g_heff_2ecompile_2eranges_2ewordOf_24cpr_str17)}});
                  } else {
                    heff_drop(v_t_2470);
                    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                  }
                } else {
                  if (heff_strEq_c_lent(v_p_240, ((V)&g_heff_2ecompile_2eranges_2ewordOf_24cpr_str18), 2)) {
                    V v_t_2472 = (g_list_2eall_24s525729714x658270192(v_rs_241));
                    if ((heff_dup(v_t_2472) == NTAG(TAG_True))) {
                      heff_drop(v_t_2472);
                      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), ((V)&g_heff_2ecompile_2eranges_2ewordOf_24cpr_str19)}});
                    } else {
                      heff_drop(v_t_2472);
                      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                    }
                  } else {
                    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}
Clo g_heff_2ecompile_2eranges_2etrimLow_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eranges_2etrimLow_entry, 2, 0};

V g_heff_2ecompile_2eranges_2etrimLow(V v_v_240, V v_r_241) {
top: ;
  switch (heff_tag_of(v_r_241)) {
  case TAG_Unreached: {
    heff_drop(v_v_240);
    return v_r_241;
  }
  case TAG_Within: {
    V v_r1_242 = heff_dup(heff_field(v_r_241, 0));
    V v_hi_243 = heff_dup(heff_field(v_r_241, 1));
    switch (heff_tag_of(v_r1_242)) {
    case TAG_Nothing: {
      heff_drop(v_v_240);
      heff_drop(v_hi_243);
      return v_r_241;
    }
    case TAG_Just: {
      V v_lo_244 = heff_field(v_r1_242, 0);
      V v_ru_24r1_242_24Just = heff_take_reuse_n(v_r1_242, 1ULL, 1);
      heff_drop_tag(v_r_241, 2);
      if (heff_intEq_c_lent(v_lo_244, v_v_240, 0)) {
        heff_drop(v_lo_244);
        V v_t_246 = heff_intAdd(v_v_240, MK_INT(1LL));
        switch (heff_tag_of(v_hi_243)) {
        case TAG_Nothing: {
          return heff_tag_n(TAG_Within, 2, (V[]){heff_tag_at_n(v_ru_24r1_242_24Just, TAG_Just, 1, (V[]){v_t_246}), v_hi_243});
        }
        case TAG_Just: {
          V v_hi_247 = heff_field(v_hi_243, 0);
          V v_ru_24hi_243_24Just = heff_take_reuse_n(v_hi_243, 1ULL, 1);
          if (heff_intLt_c_lent(v_hi_247, v_t_246, 0)) {
            heff_drop_cell(v_ru_24r1_242_24Just, 1);
            heff_drop(v_t_246);
            heff_drop(v_hi_247);
            heff_drop_cell(v_ru_24hi_243_24Just, 1);
            return NTAG(TAG_Unreached);
          } else {
            return heff_tag_n(TAG_Within, 2, (V[]){heff_tag_at_n(v_ru_24r1_242_24Just, TAG_Just, 1, (V[]){v_t_246}), heff_tag_at_n(v_ru_24hi_243_24Just, TAG_Just, 1, (V[]){v_hi_247})});
          }
        }
        default: return heff_nomatch(v_hi_243);
        }
      } else {
        heff_drop(v_v_240);
        return heff_tag_n(TAG_Within, 2, (V[]){heff_tag_at_n(v_ru_24r1_242_24Just, TAG_Just, 1, (V[]){v_lo_244}), v_hi_243});
      }
    }
    default: return heff_nomatch(v_r1_242);
    }
  }
  default: return heff_nomatch(v_r_241);
  }
}
V g_heff_2ecompile_2eranges_2etrimLow_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eranges_2etrimLow(a[0], a[1]);
}
Clo g_heff_2ecompile_2eranges_2erootGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eranges_2erootGo_entry, 3, 0};

V g_heff_2ecompile_2eranges_2erootGo(V v_n_240, V v_lo_241, V v_hi_242) {
top: ;
  if (heff_intLe_c_lent(v_hi_242, v_lo_241, 0)) {
    heff_drop(v_n_240);
    heff_drop(v_hi_242);
    return v_lo_241;
  } else {
    V v_t_244 = heff_intAdd(heff_intAdd(heff_dup(v_lo_241), heff_dup(v_hi_242)), MK_INT(1LL));
    V v_t_245 = heff_intAdd(heff_intAdd(heff_dup(v_lo_241), heff_dup(v_hi_242)), MK_INT(1LL));
    V v_t_246 = heff_intMul(heff_intDiv(v_t_244, MK_INT(2LL)), heff_intDiv(v_t_245, MK_INT(2LL)));
    if (heff_intLe_c_lent(v_t_246, v_n_240, 1)) {
      V v_t_248 = heff_intAdd(heff_intAdd(v_lo_241, heff_dup(v_hi_242)), MK_INT(1LL));
      V t_0 = v_n_240;
      V t_1 = heff_intDiv(v_t_248, MK_INT(2LL));
      V t_2 = v_hi_242;
      v_n_240 = t_0;
      v_lo_241 = t_1;
      v_hi_242 = t_2;
      goto top;
    } else {
      V v_t_249 = heff_intAdd(heff_intAdd(heff_dup(v_lo_241), v_hi_242), MK_INT(1LL));
      V v_t_2410 = heff_intSub(heff_intDiv(v_t_249, MK_INT(2LL)), MK_INT(1LL));
      V t_0 = v_n_240;
      V t_1 = v_lo_241;
      V t_2 = v_t_2410;
      v_n_240 = t_0;
      v_lo_241 = t_1;
      v_hi_242 = t_2;
      goto top;
    }
  }
}
V g_heff_2ecompile_2eranges_2erootGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eranges_2erootGo(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ecompile_2eranges_2enarrowTo_str0, 6, "intMul");
HEFF_LIT(g_heff_2ecompile_2eranges_2enarrowTo_str1, 7, "wordMul");
Clo g_heff_2ecompile_2eranges_2enarrowTo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eranges_2enarrowTo_entry, 3, 0};

V g_heff_2ecompile_2eranges_2enarrowTo(V v_env_240, V v_e_241, V v_r_242) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_EVar: {
    V v_x_243 = heff_field(v_e_241, 0);
    HEFF_LAST return g_heff_2ecompile_2eranges_2ewithRange(v_env_240, heff_dup(v_x_243), v_r_242);
  }
  case TAG_EGlobal: {
    heff_drop(v_r_242);
    return v_env_240;
  }
  case TAG_ELam: {
    heff_drop(v_r_242);
    return v_env_240;
  }
  case TAG_EApp: {
    heff_drop(v_r_242);
    return v_env_240;
  }
  case TAG_ELet: {
    heff_drop(v_r_242);
    return v_env_240;
  }
  case TAG_ERecord: {
    heff_drop(v_r_242);
    return v_env_240;
  }
  case TAG_EProj: {
    heff_drop(v_r_242);
    return v_env_240;
  }
  case TAG_ETag: {
    heff_drop(v_r_242);
    return v_env_240;
  }
  case TAG_EMatch: {
    heff_drop(v_r_242);
    return v_env_240;
  }
  case TAG_EPrim: {
    heff_drop(v_r_242);
    return v_env_240;
  }
  case TAG_EPrimCall: {
    V v_p_2424 = heff_field(v_e_241, 0);
    V v_e2_2425 = heff_field(v_e_241, 1);
    switch (heff_tag_of(v_e2_2425)) {
    case TAG_Nil: {
      heff_drop(v_r_242);
      return v_env_240;
    }
    case TAG_Cons: {
      V v_e21_2426 = heff_field(v_e2_2425, 0);
      V v_e22_2427 = heff_field(v_e2_2425, 1);
      switch (heff_tag_of(v_e21_2426)) {
      case TAG_EVar: {
        V v_x_2428 = heff_field(v_e21_2426, 0);
        switch (heff_tag_of(v_e22_2427)) {
        case TAG_Nil: {
          heff_drop(v_r_242);
          return v_env_240;
        }
        case TAG_Cons: {
          V v_e221_2429 = heff_field(v_e22_2427, 0);
          V v_e222_2430 = heff_field(v_e22_2427, 1);
          switch (heff_tag_of(v_e221_2429)) {
          case TAG_EVar: {
            V v_y_2431 = heff_field(v_e221_2429, 0);
            switch (heff_tag_of(v_e222_2430)) {
            case TAG_Nil: {
              V v_t_2434 = heff_bool((heff_strEq_c_lent(v_p_2424, ((V)&g_heff_2ecompile_2eranges_2enarrowTo_str0), 2) ? heff_strEq_c_lent(v_x_2428, v_y_2431, 0) : (heff_strEq_c_lent(v_p_2424, ((V)&g_heff_2ecompile_2eranges_2enarrowTo_str1), 2) && heff_strEq_c_lent(v_x_2428, v_y_2431, 0))));
              if ((heff_dup(v_t_2434) == NTAG(TAG_True))) {
                heff_drop(v_t_2434);
                V v_t_2437;
                switch (heff_tag_of(v_r_242)) {
                case TAG_Unreached: {
                  v_t_2437 = NTAG(TAG_Nothing);
                  break;
                }
                case TAG_Within: {
                  V v_hi_2436 = heff_field(v_r_242, 1);
                  heff_take_n(v_r_242, 2ULL, 2);
                  v_t_2437 = v_hi_2436;
                  break;
                }
                default: heff_nomatch(v_r_242);
                }
                HEFF_LAST return g_heff_2ecompile_2eranges_2erootTo(v_env_240, heff_dup(v_x_2428), v_t_2437);
              } else {
                heff_drop(v_r_242);
                heff_drop(v_t_2434);
                return v_env_240;
              }
            }
            case TAG_Cons: {
              heff_drop(v_r_242);
              return v_env_240;
            }
            default: return heff_nomatch(v_e222_2430);
            }
          }
          case TAG_EGlobal: {
            heff_drop(v_r_242);
            return v_env_240;
          }
          case TAG_ELam: {
            heff_drop(v_r_242);
            return v_env_240;
          }
          case TAG_EApp: {
            heff_drop(v_r_242);
            return v_env_240;
          }
          case TAG_ELet: {
            heff_drop(v_r_242);
            return v_env_240;
          }
          case TAG_ERecord: {
            heff_drop(v_r_242);
            return v_env_240;
          }
          case TAG_EProj: {
            heff_drop(v_r_242);
            return v_env_240;
          }
          case TAG_ETag: {
            heff_drop(v_r_242);
            return v_env_240;
          }
          case TAG_EMatch: {
            heff_drop(v_r_242);
            return v_env_240;
          }
          case TAG_EPrim: {
            heff_drop(v_r_242);
            return v_env_240;
          }
          case TAG_EPrimCall: {
            heff_drop(v_r_242);
            return v_env_240;
          }
          case TAG_ECall: {
            heff_drop(v_r_242);
            return v_env_240;
          }
          case TAG_EInt: {
            heff_drop(v_r_242);
            return v_env_240;
          }
          case TAG_EFloat: {
            heff_drop(v_r_242);
            return v_env_240;
          }
          case TAG_EStr: {
            heff_drop(v_r_242);
            return v_env_240;
          }
          case TAG_EBytes: {
            heff_drop(v_r_242);
            return v_env_240;
          }
          case TAG_EFixed: {
            heff_drop(v_r_242);
            return v_env_240;
          }
          case TAG_EFloat32: {
            heff_drop(v_r_242);
            return v_env_240;
          }
          case TAG_EAbandon: {
            heff_drop(v_r_242);
            return v_env_240;
          }
          case TAG_EFix: {
            heff_drop(v_r_242);
            return v_env_240;
          }
          default: return heff_nomatch(v_e221_2429);
          }
        }
        default: return heff_nomatch(v_e22_2427);
        }
      }
      case TAG_EGlobal: {
        heff_drop(v_r_242);
        return v_env_240;
      }
      case TAG_ELam: {
        heff_drop(v_r_242);
        return v_env_240;
      }
      case TAG_EApp: {
        heff_drop(v_r_242);
        return v_env_240;
      }
      case TAG_ELet: {
        heff_drop(v_r_242);
        return v_env_240;
      }
      case TAG_ERecord: {
        heff_drop(v_r_242);
        return v_env_240;
      }
      case TAG_EProj: {
        heff_drop(v_r_242);
        return v_env_240;
      }
      case TAG_ETag: {
        heff_drop(v_r_242);
        return v_env_240;
      }
      case TAG_EMatch: {
        heff_drop(v_r_242);
        return v_env_240;
      }
      case TAG_EPrim: {
        heff_drop(v_r_242);
        return v_env_240;
      }
      case TAG_EPrimCall: {
        heff_drop(v_r_242);
        return v_env_240;
      }
      case TAG_ECall: {
        heff_drop(v_r_242);
        return v_env_240;
      }
      case TAG_EInt: {
        heff_drop(v_r_242);
        return v_env_240;
      }
      case TAG_EFloat: {
        heff_drop(v_r_242);
        return v_env_240;
      }
      case TAG_EStr: {
        heff_drop(v_r_242);
        return v_env_240;
      }
      case TAG_EBytes: {
        heff_drop(v_r_242);
        return v_env_240;
      }
      case TAG_EFixed: {
        heff_drop(v_r_242);
        return v_env_240;
      }
      case TAG_EFloat32: {
        heff_drop(v_r_242);
        return v_env_240;
      }
      case TAG_EAbandon: {
        heff_drop(v_r_242);
        return v_env_240;
      }
      case TAG_EFix: {
        heff_drop(v_r_242);
        return v_env_240;
      }
      default: return heff_nomatch(v_e21_2426);
      }
    }
    default: return heff_nomatch(v_e2_2425);
    }
  }
  case TAG_ECall: {
    heff_drop(v_r_242);
    return v_env_240;
  }
  case TAG_EInt: {
    heff_drop(v_r_242);
    return v_env_240;
  }
  case TAG_EFloat: {
    heff_drop(v_r_242);
    return v_env_240;
  }
  case TAG_EStr: {
    heff_drop(v_r_242);
    return v_env_240;
  }
  case TAG_EBytes: {
    heff_drop(v_r_242);
    return v_env_240;
  }
  case TAG_EFixed: {
    heff_drop(v_r_242);
    return v_env_240;
  }
  case TAG_EFloat32: {
    heff_drop(v_r_242);
    return v_env_240;
  }
  case TAG_EAbandon: {
    heff_drop(v_r_242);
    return v_env_240;
  }
  case TAG_EFix: {
    heff_drop(v_r_242);
    return v_env_240;
  }
  default: return heff_nomatch(v_e_241);
  }
}
V g_heff_2ecompile_2eranges_2enarrowTo_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2eranges_2enarrowTo(a[0], a1, a[2]); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2eranges_2emarkRange_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eranges_2emarkRange_entry, 2, 0};

V g_heff_2ecompile_2eranges_2emarkRange(V v_ms_240, V v_r_241) {
top: ;
  switch (heff_tag_of(v_r_241)) {
  case TAG_Unreached: {
    return v_ms_240;
  }
  case TAG_Within: {
    V v_r1_242 = heff_field(v_r_241, 0);
    V v_r2_243 = heff_field(v_r_241, 1);
    switch (heff_tag_of(v_r1_242)) {
    case TAG_Nothing: {
      return v_ms_240;
    }
    case TAG_Just: {
      V v_lo_244 = heff_field(v_r1_242, 0);
      switch (heff_tag_of(v_r2_243)) {
      case TAG_Nothing: {
        return v_ms_240;
      }
      case TAG_Just: {
        V v_hi_245 = heff_field(v_r2_243, 0);
        if (heff_intEq_c_lent(v_lo_244, v_hi_245, 0)) {
          V v_t_247 = (g_std_2emap_2einsert_24s170109517x1206653089(v_ms_240, heff_intAdd(heff_dup(v_lo_244), MK_INT(1LL)), NTAG(TAG_MkUnit)));
          V v_t_248 = (g_std_2emap_2einsert_24s170109517x1206653089(v_t_247, heff_dup(v_lo_244), NTAG(TAG_MkUnit)));
          return (g_std_2emap_2einsert_24s170109517x1206653089(v_t_248, heff_intSub(heff_dup(v_lo_244), MK_INT(1LL)), NTAG(TAG_MkUnit)));
        } else {
          return v_ms_240;
        }
      }
      default: return heff_nomatch(v_r2_243);
      }
    }
    default: return heff_nomatch(v_r1_242);
    }
  }
  default: return heff_nomatch(v_r_241);
  }
}
V g_heff_2ecompile_2eranges_2emarkRange_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2eranges_2emarkRange(a[0], a1); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ecompile_2eranges_2egatherArms_24cpr_str0, 4, "True");
HEFF_LIT(g_heff_2ecompile_2eranges_2egatherArms_24cpr_str1, 5, "False");

HeffT2 g_heff_2ecompile_2eranges_2egatherArms_24cpr(V v_c_240, V v_go_241, V v_env_242, V v_t_243, V v_st_244, V v_x6_245) {
top: ;
  switch (heff_tag_of(v_x6_245)) {
  case TAG_Nil: {
    heff_drop(v_c_240);
    heff_drop(v_go_241);
    heff_drop(v_env_242);
    return ((HeffT2){{NTAG(TAG_Unreached), v_st_244}});
  }
  case TAG_Cons: {
    V v_x61_246 = heff_field(v_x6_245, 0);
    V v_rest_247 = heff_field(v_x6_245, 1);
    heff_take_n(v_x6_245, 3ULL, 2);
    switch (heff_tag_of(v_x61_246)) {
    case TAG_MkArm: {
      V v_tag_248 = heff_field(v_x61_246, 0);
      V v_b_2410 = heff_field(v_x61_246, 2);
      heff_take_n(v_x61_246, 5ULL, 3);
      V v_t_2414;
      switch (heff_tag_of(v_t_243)) {
      case TAG_Nothing: {
        heff_drop(v_tag_248);
        v_t_2414 = heff_dup(v_env_242);
        break;
      }
      case TAG_Just: {
        V v_t_2411 = heff_field(v_t_243, 0);
        if (heff_strEq_c_lent(v_tag_248, ((V)&g_heff_2ecompile_2eranges_2egatherArms_24cpr_str0), 2)) {
          heff_drop(v_tag_248);
          v_t_2414 = ({ V a_0 = heff_dup(v_c_240); V a_1 = heff_dup(v_env_242); V a_2 = v_t_2411; V b_3 = NTAG(TAG_True); V r_ = (g_heff_2ecompile_2eranges_2erefine(a_0, a_1, a_2, b_3)); heff_drop(b_3); r_; });
        } else {
          if (heff_strEq_c(v_tag_248, ((V)&g_heff_2ecompile_2eranges_2egatherArms_24cpr_str1))) {
            v_t_2414 = ({ V a_0 = heff_dup(v_c_240); V a_1 = heff_dup(v_env_242); V a_2 = v_t_2411; V b_3 = NTAG(TAG_False); V r_ = (g_heff_2ecompile_2eranges_2erefine(a_0, a_1, a_2, b_3)); heff_drop(b_3); r_; });
          } else {
            v_t_2414 = heff_dup(v_env_242);
          }
        }
        break;
      }
      default: heff_nomatch(v_t_243);
      }
      V v_x1_2415 = heff_tr(heff_call(heff_dup(v_go_241), 3, (V[]){v_t_2414, v_st_244, v_b_2410}));
      switch (heff_tag_of(v_x1_2415)) {
      case TAG_MkSeen: {
        V v_r_2416 = heff_field(v_x1_2415, 0);
        V v_st_2417 = heff_field(v_x1_2415, 1);
        heff_take_n(v_x1_2415, 3ULL, 2);
        HeffT2 v_t_2418 = (g_heff_2ecompile_2eranges_2egatherArms_24cpr(v_c_240, v_go_241, v_env_242, v_t_243, v_st_2417, v_rest_247));
        {
          V v_field_2419 = v_t_2418.f[0];
          V v_field_2420 = v_t_2418.f[1];
          V v_rr_2421 = v_field_2419;
          V v_st_2422 = v_field_2420;
          V v_f_2423 = (g_heff_2ecompile_2eranges_2ejoin(v_r_2416, v_rr_2421));
          return ((HeffT2){{v_f_2423, v_st_2422}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x1_2415)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x61_246)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x6_245)}});
  }
}
Clo g_heff_2ecompile_2eranges_2ewalkDef_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eranges_2ewalkDef_entry, 2, 0};

V g_heff_2ecompile_2eranges_2ewalkDef(V v_c_240, V v_d_241) {
top: ;
  V v_t_242 = heff_dup(heff_rfield(v_d_241, 2));
  switch (heff_tag_of(v_t_242)) {
  case TAG_EVar: {
    heff_take_n(v_t_242, 0ULL, 1);
    HeffT2 v_t_244 = (g_heff_2ecompile_2eranges_2ewalkGo_24cpr(v_c_240, heff_dup(g_heff_2ecompile_2eranges_2eemptyEnv_get()), heff_get_n(v_d_241, 2, 3)));
    {
      V v_field_245 = v_t_244.f[0];
      V v_field_246 = v_t_244.f[1];
      V v_x11_247 = v_field_245;
      heff_drop(v_x11_247);
      V v_e_248 = v_field_246;
      return v_e_248;
    }
  }
  case TAG_EGlobal: {
    heff_take_n(v_t_242, 0ULL, 1);
    HeffT2 v_t_2410 = (g_heff_2ecompile_2eranges_2ewalkGo_24cpr(v_c_240, heff_dup(g_heff_2ecompile_2eranges_2eemptyEnv_get()), heff_get_n(v_d_241, 2, 3)));
    {
      V v_field_2411 = v_t_2410.f[0];
      V v_field_2412 = v_t_2410.f[1];
      V v_x11_2413 = v_field_2411;
      heff_drop(v_x11_2413);
      V v_e_2414 = v_field_2412;
      return v_e_2414;
    }
  }
  case TAG_ELam: {
    V v_xs_2415 = heff_field(v_t_242, 0);
    V v_b_2416 = heff_field(v_t_242, 1);
    V v_ru_24t_242_24ELam = heff_take_reuse_n(v_t_242, 3ULL, 2);
    HeffT2 v_t_2417 = ({ V a_0 = heff_rfield(v_c_240, 0); V b_1 = heff_get_n(v_d_241, 0, 3); HeffT2 r_ = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(a_0, b_1)); heff_drop(b_1); r_; });
    V v_t_2423;
    {
      V v_field_2419 = v_t_2417.f[1];
      int64_t v_tag_2418 = ((int64_t)v_t_2417.f[0]);
      if ((v_tag_2418 == ((int64_t)0ULL))) {
        V v_rs_2421 = v_field_2419;
        V v_t_2422 = (g_list_2ezipWith_24s1876717925x1404326288(heff_dup(v_xs_2415), v_rs_2421));
        v_t_2423 = ({ V a_0 = heff_dup(g_heff_2ecompile_2eranges_2eemptyEnv_get()); V a_1 = v_t_2422; V r_ = (g_list_2efoldl_24s518632429x1911716206(a_0, a_1)); heff_drop(v_t_2422); r_; });
      } else {
        heff_drop(v_field_2419);
        v_t_2423 = heff_dup(g_heff_2ecompile_2eranges_2eemptyEnv_get());
      }
    }
    HeffT2 v_t_2424 = (g_heff_2ecompile_2eranges_2ewalkGo_24cpr(v_c_240, v_t_2423, v_b_2416));
    V v_t_2429;
    {
      V v_field_2425 = v_t_2424.f[0];
      V v_field_2426 = v_t_2424.f[1];
      V v_x11_2427 = v_field_2425;
      heff_drop(v_x11_2427);
      V v_e_2428 = v_field_2426;
      v_t_2429 = v_e_2428;
    }
    return heff_tag_at_n(v_ru_24t_242_24ELam, TAG_ELam, 2, (V[]){v_xs_2415, v_t_2429});
  }
  case TAG_EApp: {
    heff_take_n(v_t_242, 0ULL, 2);
    HeffT2 v_t_2432 = (g_heff_2ecompile_2eranges_2ewalkGo_24cpr(v_c_240, heff_dup(g_heff_2ecompile_2eranges_2eemptyEnv_get()), heff_get_n(v_d_241, 2, 3)));
    {
      V v_field_2433 = v_t_2432.f[0];
      V v_field_2434 = v_t_2432.f[1];
      V v_x11_2435 = v_field_2433;
      heff_drop(v_x11_2435);
      V v_e_2436 = v_field_2434;
      return v_e_2436;
    }
  }
  case TAG_ELet: {
    heff_take_n(v_t_242, 0ULL, 3);
    HeffT2 v_t_2440 = (g_heff_2ecompile_2eranges_2ewalkGo_24cpr(v_c_240, heff_dup(g_heff_2ecompile_2eranges_2eemptyEnv_get()), heff_get_n(v_d_241, 2, 3)));
    {
      V v_field_2441 = v_t_2440.f[0];
      V v_field_2442 = v_t_2440.f[1];
      V v_x11_2443 = v_field_2441;
      heff_drop(v_x11_2443);
      V v_e_2444 = v_field_2442;
      return v_e_2444;
    }
  }
  case TAG_ERecord: {
    heff_take_n(v_t_242, 0ULL, 2);
    HeffT2 v_t_2447 = (g_heff_2ecompile_2eranges_2ewalkGo_24cpr(v_c_240, heff_dup(g_heff_2ecompile_2eranges_2eemptyEnv_get()), heff_get_n(v_d_241, 2, 3)));
    {
      V v_field_2448 = v_t_2447.f[0];
      V v_field_2449 = v_t_2447.f[1];
      V v_x11_2450 = v_field_2448;
      heff_drop(v_x11_2450);
      V v_e_2451 = v_field_2449;
      return v_e_2451;
    }
  }
  case TAG_EProj: {
    heff_take_n(v_t_242, 0ULL, 4);
    HeffT2 v_t_2456 = (g_heff_2ecompile_2eranges_2ewalkGo_24cpr(v_c_240, heff_dup(g_heff_2ecompile_2eranges_2eemptyEnv_get()), heff_get_n(v_d_241, 2, 3)));
    {
      V v_field_2457 = v_t_2456.f[0];
      V v_field_2458 = v_t_2456.f[1];
      V v_x11_2459 = v_field_2457;
      heff_drop(v_x11_2459);
      V v_e_2460 = v_field_2458;
      return v_e_2460;
    }
  }
  case TAG_ETag: {
    heff_take_n(v_t_242, 0ULL, 3);
    HeffT2 v_t_2464 = (g_heff_2ecompile_2eranges_2ewalkGo_24cpr(v_c_240, heff_dup(g_heff_2ecompile_2eranges_2eemptyEnv_get()), heff_get_n(v_d_241, 2, 3)));
    {
      V v_field_2465 = v_t_2464.f[0];
      V v_field_2466 = v_t_2464.f[1];
      V v_x11_2467 = v_field_2465;
      heff_drop(v_x11_2467);
      V v_e_2468 = v_field_2466;
      return v_e_2468;
    }
  }
  case TAG_EMatch: {
    heff_take_n(v_t_242, 0ULL, 2);
    HeffT2 v_t_2471 = (g_heff_2ecompile_2eranges_2ewalkGo_24cpr(v_c_240, heff_dup(g_heff_2ecompile_2eranges_2eemptyEnv_get()), heff_get_n(v_d_241, 2, 3)));
    {
      V v_field_2472 = v_t_2471.f[0];
      V v_field_2473 = v_t_2471.f[1];
      V v_x11_2474 = v_field_2472;
      heff_drop(v_x11_2474);
      V v_e_2475 = v_field_2473;
      return v_e_2475;
    }
  }
  case TAG_EPrim: {
    heff_take_n(v_t_242, 0ULL, 1);
    HeffT2 v_t_2477 = (g_heff_2ecompile_2eranges_2ewalkGo_24cpr(v_c_240, heff_dup(g_heff_2ecompile_2eranges_2eemptyEnv_get()), heff_get_n(v_d_241, 2, 3)));
    {
      V v_field_2478 = v_t_2477.f[0];
      V v_field_2479 = v_t_2477.f[1];
      V v_x11_2480 = v_field_2478;
      heff_drop(v_x11_2480);
      V v_e_2481 = v_field_2479;
      return v_e_2481;
    }
  }
  case TAG_EPrimCall: {
    heff_take_n(v_t_242, 0ULL, 2);
    HeffT2 v_t_2484 = (g_heff_2ecompile_2eranges_2ewalkGo_24cpr(v_c_240, heff_dup(g_heff_2ecompile_2eranges_2eemptyEnv_get()), heff_get_n(v_d_241, 2, 3)));
    {
      V v_field_2485 = v_t_2484.f[0];
      V v_field_2486 = v_t_2484.f[1];
      V v_x11_2487 = v_field_2485;
      heff_drop(v_x11_2487);
      V v_e_2488 = v_field_2486;
      return v_e_2488;
    }
  }
  case TAG_ECall: {
    heff_take_n(v_t_242, 0ULL, 2);
    HeffT2 v_t_2491 = (g_heff_2ecompile_2eranges_2ewalkGo_24cpr(v_c_240, heff_dup(g_heff_2ecompile_2eranges_2eemptyEnv_get()), heff_get_n(v_d_241, 2, 3)));
    {
      V v_field_2492 = v_t_2491.f[0];
      V v_field_2493 = v_t_2491.f[1];
      V v_x11_2494 = v_field_2492;
      heff_drop(v_x11_2494);
      V v_e_2495 = v_field_2493;
      return v_e_2495;
    }
  }
  case TAG_EInt: {
    heff_take_n(v_t_242, 0ULL, 1);
    HeffT2 v_t_2497 = (g_heff_2ecompile_2eranges_2ewalkGo_24cpr(v_c_240, heff_dup(g_heff_2ecompile_2eranges_2eemptyEnv_get()), heff_get_n(v_d_241, 2, 3)));
    {
      V v_field_2498 = v_t_2497.f[0];
      V v_field_2499 = v_t_2497.f[1];
      V v_x11_24100 = v_field_2498;
      heff_drop(v_x11_24100);
      V v_e_24101 = v_field_2499;
      return v_e_24101;
    }
  }
  case TAG_EFloat: {
    heff_take_na(v_t_242, 0ULL, 1);
    HeffT2 v_t_24103 = (g_heff_2ecompile_2eranges_2ewalkGo_24cpr(v_c_240, heff_dup(g_heff_2ecompile_2eranges_2eemptyEnv_get()), heff_get_n(v_d_241, 2, 3)));
    {
      V v_field_24104 = v_t_24103.f[0];
      V v_field_24105 = v_t_24103.f[1];
      V v_x11_24106 = v_field_24104;
      heff_drop(v_x11_24106);
      V v_e_24107 = v_field_24105;
      return v_e_24107;
    }
  }
  case TAG_EStr: {
    heff_take_n(v_t_242, 0ULL, 1);
    HeffT2 v_t_24109 = (g_heff_2ecompile_2eranges_2ewalkGo_24cpr(v_c_240, heff_dup(g_heff_2ecompile_2eranges_2eemptyEnv_get()), heff_get_n(v_d_241, 2, 3)));
    {
      V v_field_24110 = v_t_24109.f[0];
      V v_field_24111 = v_t_24109.f[1];
      V v_x11_24112 = v_field_24110;
      heff_drop(v_x11_24112);
      V v_e_24113 = v_field_24111;
      return v_e_24113;
    }
  }
  case TAG_EBytes: {
    heff_take_n(v_t_242, 0ULL, 1);
    HeffT2 v_t_24115 = (g_heff_2ecompile_2eranges_2ewalkGo_24cpr(v_c_240, heff_dup(g_heff_2ecompile_2eranges_2eemptyEnv_get()), heff_get_n(v_d_241, 2, 3)));
    {
      V v_field_24116 = v_t_24115.f[0];
      V v_field_24117 = v_t_24115.f[1];
      V v_x11_24118 = v_field_24116;
      heff_drop(v_x11_24118);
      V v_e_24119 = v_field_24117;
      return v_e_24119;
    }
  }
  case TAG_EFixed: {
    heff_take_n(v_t_242, 0ULL, 2);
    HeffT2 v_t_24122 = (g_heff_2ecompile_2eranges_2ewalkGo_24cpr(v_c_240, heff_dup(g_heff_2ecompile_2eranges_2eemptyEnv_get()), heff_get_n(v_d_241, 2, 3)));
    {
      V v_field_24123 = v_t_24122.f[0];
      V v_field_24124 = v_t_24122.f[1];
      V v_x11_24125 = v_field_24123;
      heff_drop(v_x11_24125);
      V v_e_24126 = v_field_24124;
      return v_e_24126;
    }
  }
  case TAG_EFloat32: {
    heff_take_na(v_t_242, 0ULL, 1);
    HeffT2 v_t_24128 = (g_heff_2ecompile_2eranges_2ewalkGo_24cpr(v_c_240, heff_dup(g_heff_2ecompile_2eranges_2eemptyEnv_get()), heff_get_n(v_d_241, 2, 3)));
    {
      V v_field_24129 = v_t_24128.f[0];
      V v_field_24130 = v_t_24128.f[1];
      V v_x11_24131 = v_field_24129;
      heff_drop(v_x11_24131);
      V v_e_24132 = v_field_24130;
      return v_e_24132;
    }
  }
  case TAG_EAbandon: {
    HeffT2 v_t_24133 = (g_heff_2ecompile_2eranges_2ewalkGo_24cpr(v_c_240, heff_dup(g_heff_2ecompile_2eranges_2eemptyEnv_get()), heff_get_n(v_d_241, 2, 3)));
    {
      V v_field_24134 = v_t_24133.f[0];
      V v_field_24135 = v_t_24133.f[1];
      V v_x11_24136 = v_field_24134;
      heff_drop(v_x11_24136);
      V v_e_24137 = v_field_24135;
      return v_e_24137;
    }
  }
  case TAG_EFix: {
    heff_take_n(v_t_242, 0ULL, 2);
    HeffT2 v_t_24140 = (g_heff_2ecompile_2eranges_2ewalkGo_24cpr(v_c_240, heff_dup(g_heff_2ecompile_2eranges_2eemptyEnv_get()), heff_get_n(v_d_241, 2, 3)));
    {
      V v_field_24141 = v_t_24140.f[0];
      V v_field_24142 = v_t_24140.f[1];
      V v_x11_24143 = v_field_24141;
      heff_drop(v_x11_24143);
      V v_e_24144 = v_field_24142;
      return v_e_24144;
    }
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2ecompile_2eranges_2ewalkDef_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eranges_2ewalkDef(a[0], a[1]);
}
Clo g_heff_2ecompile_2eranges_2egrownOne_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eranges_2egrownOne_entry, 4, 0};

V g_heff_2ecompile_2eranges_2egrownOne(V v_ms_240, V v_k_241, V v_old_242, V v_new_243) {
top: ;
  if (heff_intLt_c_lent(v_k_241, MK_INT(1LL), 2)) {
    heff_drop(v_ms_240);
    heff_drop(v_k_241);
    heff_drop(v_old_242);
    return v_new_243;
  } else {
    if (heff_intLt_c(v_k_241, MK_INT(3LL))) {
      switch (heff_tag_of(v_old_242)) {
      case TAG_Unreached: {
        heff_drop(v_ms_240);
        return v_new_243;
      }
      case TAG_Within: {
        V v_a_246 = heff_field(v_old_242, 0);
        V v_b_247 = heff_field(v_old_242, 1);
        V v_ru_24old_242_24Within = heff_take_reuse_n(v_old_242, 3ULL, 2);
        switch (heff_tag_of(v_new_243)) {
        case TAG_Unreached: {
          heff_drop(v_ms_240);
          heff_drop(v_a_246);
          heff_drop(v_b_247);
          heff_drop_cell(v_ru_24old_242_24Within, 2);
          return v_new_243;
        }
        case TAG_Within: {
          V v_c_248 = heff_field(v_new_243, 0);
          V v_d_249 = heff_field(v_new_243, 1);
          heff_take_n(v_new_243, 3ULL, 2);
          V v_t_2410 = (g_heff_2ecompile_2eranges_2ewidenLow(heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_ms_240)}), v_a_246, v_c_248));
          V v_t_2411 = (g_heff_2ecompile_2eranges_2ewidenHigh(heff_tag_n(TAG_Just, 1, (V[]){v_ms_240}), v_b_247, v_d_249));
          return heff_tag_at_n(v_ru_24old_242_24Within, TAG_Within, 2, (V[]){v_t_2410, v_t_2411});
        }
        default: return heff_nomatch(v_new_243);
        }
      }
      default: return heff_nomatch(v_old_242);
      }
    } else {
      heff_drop(v_ms_240);
      return (g_heff_2ecompile_2eranges_2ewiden(NTAG(TAG_Nothing), v_old_242, v_new_243));
    }
  }
}
V g_heff_2ecompile_2eranges_2egrownOne_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eranges_2egrownOne(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2eranges_2egrownTo_lam0(V self, V *args);
Clo g_heff_2ecompile_2eranges_2egrownTo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eranges_2egrownTo_entry, 4, 0};

V g_heff_2ecompile_2eranges_2egrownTo(V v_fx_240, V v_g_241, V v_old_242, V v_new_243) {
top: ;
  V v_d_244 = (g_list_2emap_24s258116700x992061112(MK_INT(0LL), heff_dup(v_old_242)));
  HeffT2 v_t_245 = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(heff_rfield(v_fx_240, 1), v_g_241));
  V v_t_2410;
  {
    V v_field_247 = v_t_245.f[1];
    int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
    if ((v_tag_246 == ((int64_t)0ULL))) {
      heff_drop(v_d_244);
      V v_x_249 = v_field_247;
      v_t_2410 = v_x_249;
    } else {
      heff_drop(v_field_247);
      v_t_2410 = v_d_244;
    }
  }
  V v_t_2411 = (g_list_2ezipWith_24s1876717925x1404326288(v_t_2410, v_old_242));
  return (g_list_2ezipWith(heff_clo_n(g_heff_2ecompile_2eranges_2egrownTo_lam0, 2, 2, (V[]){v_fx_240, heff_dup(v_g_241)}), v_t_2411, v_new_243));
}
V g_heff_2ecompile_2eranges_2egrownTo_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2eranges_2egrownTo(a[0], a1, a[2], a[3]); heff_drop(a1); return r;
}
V g_heff_2ecompile_2eranges_2egrownTo_lam0(V self, V *args) {
  V v_kr_2412 = args[0];
  V v_n_2413 = args[1];
  V v_fx_240 = heff_env(self)[0];
  V v_g_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  HeffT2 v_t_2414 = ({ V b_0 = heff_get_n(v_fx_240, 2, 3); V a_1 = v_g_241; HeffT2 r_ = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(b_0, a_1)); heff_drop(b_0); heff_drop(v_g_241); r_; });
  V v_t_2419;
  {
    V v_field_2416 = v_t_2414.f[1];
    int64_t v_tag_2415 = ((int64_t)v_t_2414.f[0]);
    if ((v_tag_2415 == ((int64_t)0ULL))) {
      V v_x_2418 = v_field_2416;
      v_t_2419 = v_x_2418;
    } else {
      heff_drop(v_field_2416);
      v_t_2419 = heff_dup(g_std_2emap_2eempty_get());
    }
  }
  V v_t_2422;
  switch (heff_tag_of(v_kr_2412)) {
  case TAG_MkPair: {
    V v_x_2420 = heff_dup(heff_field(v_kr_2412, 0));
    v_t_2422 = v_x_2420;
    break;
  }
  default: heff_nomatch(v_kr_2412);
  }
  V v_t_2425;
  switch (heff_tag_of(v_kr_2412)) {
  case TAG_MkPair: {
    V v_y_2424 = heff_field(v_kr_2412, 1);
    heff_take_n(v_kr_2412, 2ULL, 2);
    v_t_2425 = v_y_2424;
    break;
  }
  default: heff_nomatch(v_kr_2412);
  }
  return (g_heff_2ecompile_2eranges_2egrownOne(v_t_2419, v_t_2422, v_t_2425, v_n_2413));
}
Clo g_heff_2ecompile_2eranges_2emarksWith_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eranges_2emarksWith_entry, 3, 0};

V g_heff_2ecompile_2eranges_2emarksWith(V v_key_240, V v_ms_241, V v_more_242) {
top: ;
  V v_t_248;
  switch (heff_tag_of(v_more_242)) {
  case TAG_Tip: {
    v_t_248 = MK_INT(0LL);
    break;
  }
  case TAG_Bin: {
    V v_h_243 = heff_field(v_more_242, 0);
    v_t_248 = heff_dup(v_h_243);
    break;
  }
  default: heff_nomatch(v_more_242);
  }
  if (heff_intEq_c(v_t_248, MK_INT(0LL))) {
    heff_drop(v_key_240);
    return v_ms_241;
  } else {
    HeffT2 v_t_2410 = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(v_ms_241, v_key_240));
    V v_t_2417;
    {
      V v_field_2412 = v_t_2410.f[1];
      int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
      V v_ps_2413 = (g_std_2emap_2etoListOnto(v_more_242, NTAG(TAG_Nil)));
      V v_t_2416;
      if ((v_tag_2411 == ((int64_t)0ULL))) {
        V v_x_2415 = v_field_2412;
        v_t_2416 = v_x_2415;
      } else {
        heff_drop(v_field_2412);
        v_t_2416 = heff_dup(g_std_2emap_2eempty_get());
      }
      v_t_2417 = ({ V a_0 = v_t_2416; V a_1 = v_ps_2413; V r_ = (g_list_2efoldl_24s644727442x245553729(a_0, a_1)); heff_drop(v_ps_2413); r_; });
    }
    HEFF_LAST return g_std_2emap_2einsert_24s1305793909x1049798133(v_ms_241, v_key_240, v_t_2417);
  }
}
V g_heff_2ecompile_2eranges_2emarksWith_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2eranges_2emarksWith(a[0], a[1], a2); heff_drop(a2); return r;
}
Clo g_heff_2ecompile_2eranges_2escanCall_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eranges_2escanCall_entry, 4, 0};

V g_heff_2ecompile_2eranges_2escanCall(V v_ar_240, V v_s_241, V v_g_242, V v_as_243) {
top: ;
  V v_t_244 = (g_heff_2ecompile_2eranges_2egivenFrom(heff_dup(v_g_242), MK_INT(0LL), heff_take_field(v_s_241, 1), heff_dup(v_as_243)));
  V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_g_242), heff_take_field(v_s_241, 2)});
  V v_n_246 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_as_243; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_as_243); r_; });
  HeffT2 v_t_247 = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(v_ar_240, v_g_242));
  V v_t_2413;
  {
    V v_field_249 = v_t_247.f[1];
    int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
    if ((v_tag_248 == ((int64_t)0ULL))) {
      V v_m_2411 = v_field_249;
      if (heff_intEq_c(v_n_246, v_m_2411)) {
        heff_drop(v_g_242);
        v_t_2413 = heff_dup(heff_rfield(v_s_241, 4));
      } else {
        v_t_2413 = (g_std_2emap_2einsert_24s1305793909x1049798133(heff_dup(heff_rfield(v_s_241, 4)), v_g_242, NTAG(TAG_MkUnit)));
      }
    } else {
      heff_drop(v_n_246);
      heff_drop(v_field_249);
      v_t_2413 = (g_std_2emap_2einsert_24s1305793909x1049798133(heff_dup(heff_rfield(v_s_241, 4)), v_g_242, NTAG(TAG_MkUnit)));
    }
  }
  return ({ V rv_1 = v_t_244; V rv_2 = v_t_245; V rv_4 = v_t_2413; V rr_ = heff_rec_reuse_nf(v_s_241, 9ULL, 5, shape_numeric__given__calls__ints__escapes, 195u, 0u); heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 4) = rv_4; rr_; });
}
V g_heff_2ecompile_2eranges_2escanCall_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eranges_2escanCall(a0, a[1], a[2], a[3]); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2eranges_2escanW_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eranges_2escanW_entry, 3, 0};

V g_heff_2ecompile_2eranges_2escanW(V v_ar_240, V v_s_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    return v_s_241;
  }
  case TAG_Cons: {
    V v_x31_243 = heff_field(v_x3_242, 0);
    V v_rest_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    switch (heff_tag_of(v_x31_243)) {
    case TAG_EVar: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_ar_240;
      V t_1 = v_s_241;
      V t_2 = v_rest_244;
      v_ar_240 = t_0;
      v_s_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EGlobal: {
      V v_g_246 = heff_field(v_x31_243, 0);
      heff_take_n(v_x31_243, 1ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V v_t_247 = (g_std_2emap_2einsert_24s1305793909x1049798133(heff_take_field(v_s_241, 4), v_g_246, NTAG(TAG_MkUnit)));
      V v_t_248 = ({ V rv_4 = v_t_247; V rr_ = heff_rec_reuse_nf(v_s_241, 15ULL, 5, shape_numeric__given__calls__ints__escapes, 255u, 0u); heff_rfield(rr_, 4) = rv_4; rr_; });
      V t_0 = v_ar_240;
      V t_1 = v_t_248;
      V t_2 = v_rest_244;
      v_ar_240 = t_0;
      v_s_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_ELam: {
      V v_b_2410 = heff_field(v_x31_243, 1);
      heff_take_n(v_x31_243, 2ULL, 2);
      V t_0 = v_ar_240;
      V t_1 = v_s_241;
      V t_2 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_b_2410, v_rest_244});
      v_ar_240 = t_0;
      v_s_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EApp: {
      V v_f_2411 = heff_field(v_x31_243, 0);
      V v_as_2412 = heff_field(v_x31_243, 1);
      heff_take_n(v_x31_243, 3ULL, 2);
      V v_t_2413 = (g_heff_2ecompile_2eir_2eappendI(v_as_2412, v_rest_244));
      V t_0 = v_ar_240;
      V t_1 = v_s_241;
      V t_2 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_f_2411, v_t_2413});
      v_ar_240 = t_0;
      v_s_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_ELet: {
      V v_a_2415 = heff_field(v_x31_243, 1);
      V v_b_2416 = heff_field(v_x31_243, 2);
      heff_take_n(v_x31_243, 6ULL, 3);
      V v_t_2417 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_a_2415, heff_tag_n(TAG_Cons, 2, (V[]){v_b_2416, v_rest_244})});
      V t_0 = v_ar_240;
      V t_1 = v_s_241;
      V t_2 = v_t_2417;
      v_ar_240 = t_0;
      v_s_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_ERecord: {
      V v_fs_2418 = heff_field(v_x31_243, 0);
      heff_take_n(v_x31_243, 1ULL, 2);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V v_t_2420 = (g_heff_2ecompile_2eir_2epushFields(v_fs_2418, v_rest_244));
      V t_0 = v_ar_240;
      V t_1 = v_s_241;
      V t_2 = v_t_2420;
      v_ar_240 = t_0;
      v_s_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EProj: {
      V v_e_2421 = heff_field(v_x31_243, 0);
      heff_take_n(v_x31_243, 1ULL, 4);
      V t_0 = v_ar_240;
      V t_1 = v_s_241;
      V t_2 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_e_2421, v_rest_244});
      v_ar_240 = t_0;
      v_s_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_ETag: {
      V v_as_2426 = heff_field(v_x31_243, 1);
      heff_take_n(v_x31_243, 2ULL, 3);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V v_t_2428 = (g_heff_2ecompile_2eir_2eappendI(v_as_2426, v_rest_244));
      V t_0 = v_ar_240;
      V t_1 = v_s_241;
      V t_2 = v_t_2428;
      v_ar_240 = t_0;
      v_s_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EMatch: {
      V v_e_2429 = heff_field(v_x31_243, 0);
      V v_arms_2430 = heff_field(v_x31_243, 1);
      heff_take_n(v_x31_243, 3ULL, 2);
      V v_t_2431 = (g_heff_2ecompile_2eir_2epushArms(v_arms_2430, v_rest_244));
      V t_0 = v_ar_240;
      V t_1 = v_s_241;
      V t_2 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_e_2429, v_t_2431});
      v_ar_240 = t_0;
      v_s_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EPrim: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_ar_240;
      V t_1 = v_s_241;
      V t_2 = v_rest_244;
      v_ar_240 = t_0;
      v_s_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EPrimCall: {
      V v_p_2433 = heff_field(v_x31_243, 0);
      V v_as_2434 = heff_field(v_x31_243, 1);
      heff_take_n(v_x31_243, 3ULL, 2);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V v_t_2435 = ({ V a_0 = v_p_2433; V b_1 = heff_dup(g_heff_2ecompile_2eranges_2eintOps_get()); V r_ = (g_list_2eany_24s2065989517x1307020881(a_0, b_1)); heff_drop(v_p_2433); heff_drop(b_1); r_; });
      V v_t_2437;
      if ((heff_dup(v_t_2435) == NTAG(TAG_True))) {
        heff_drop(v_t_2435);
        V v_t_2436 = (g_heff_2ecompile_2eranges_2enamesW(heff_take_field(v_s_241, 0), heff_dup(v_as_2434)));
        v_t_2437 = ({ V rv_0 = v_t_2436; V rv_3 = NTAG(TAG_True); V rr_ = heff_rec_reuse_nf(v_s_241, 22ULL, 5, shape_numeric__given__calls__ints__escapes, 828u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 3) = rv_3; rr_; });
      } else {
        heff_drop(v_t_2435);
        v_t_2437 = v_s_241;
      }
      V v_t_2438 = (g_heff_2ecompile_2eir_2eappendI(v_as_2434, v_rest_244));
      V t_0 = v_ar_240;
      V t_1 = v_t_2437;
      V t_2 = v_t_2438;
      v_ar_240 = t_0;
      v_s_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_ECall: {
      V v_g_2439 = heff_field(v_x31_243, 0);
      V v_as_2440 = heff_field(v_x31_243, 1);
      heff_take_n(v_x31_243, 3ULL, 2);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V v_t_2441 = (g_heff_2ecompile_2eranges_2escanCall(v_ar_240, v_s_241, v_g_2439, heff_dup(v_as_2440)));
      V v_t_2442 = (g_heff_2ecompile_2eir_2eappendI(v_as_2440, v_rest_244));
      V t_0 = v_ar_240;
      V t_1 = v_t_2441;
      V t_2 = v_t_2442;
      v_ar_240 = t_0;
      v_s_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EInt: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_ar_240;
      V t_1 = v_s_241;
      V t_2 = v_rest_244;
      v_ar_240 = t_0;
      v_s_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EFloat: {
      heff_take_na(v_x31_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_ar_240;
      V t_1 = v_s_241;
      V t_2 = v_rest_244;
      v_ar_240 = t_0;
      v_s_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EStr: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_ar_240;
      V t_1 = v_s_241;
      V t_2 = v_rest_244;
      v_ar_240 = t_0;
      v_s_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EBytes: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_ar_240;
      V t_1 = v_s_241;
      V t_2 = v_rest_244;
      v_ar_240 = t_0;
      v_s_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EFixed: {
      heff_take_n(v_x31_243, 0ULL, 2);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_ar_240;
      V t_1 = v_s_241;
      V t_2 = v_rest_244;
      v_ar_240 = t_0;
      v_s_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EFloat32: {
      heff_take_na(v_x31_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_ar_240;
      V t_1 = v_s_241;
      V t_2 = v_rest_244;
      v_ar_240 = t_0;
      v_s_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EAbandon: {
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_ar_240;
      V t_1 = v_s_241;
      V t_2 = v_rest_244;
      v_ar_240 = t_0;
      v_s_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EFix: {
      V v_b_2451 = heff_field(v_x31_243, 1);
      heff_take_n(v_x31_243, 2ULL, 2);
      V t_0 = v_ar_240;
      V t_1 = v_s_241;
      V t_2 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_b_2451, v_rest_244});
      v_ar_240 = t_0;
      v_s_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_x31_243);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2eranges_2escanW_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eranges_2escanW(a0, a[1], a[2]); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2eranges_2efnOne_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eranges_2efnOne_entry, 4, 0};

V g_heff_2ecompile_2eranges_2efnOne(V v_esc_240, V v_scans_241, V v_m_242, V v_d_243) {
top: ;
  V v_t_244 = heff_take_field(v_d_243, 2);
  switch (heff_tag_of(v_t_244)) {
  case TAG_EVar: {
    heff_take_n(v_t_244, 0ULL, 1);
    heff_drop_rec(v_d_243, 3);
    return v_m_242;
  }
  case TAG_EGlobal: {
    heff_take_n(v_t_244, 0ULL, 1);
    heff_drop_rec(v_d_243, 3);
    return v_m_242;
  }
  case TAG_ELam: {
    V v_xs_247 = heff_field(v_t_244, 0);
    heff_take_n(v_t_244, 1ULL, 2);
    HeffT2 v_t_249 = (g_std_2emap_2elookup_24s1654411661x99037275_24cpr(v_esc_240, heff_rfield(v_d_243, 0)));
    {
      V v_field_2411 = v_t_249.f[1];
      int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
      if ((v_tag_2410 == ((int64_t)0ULL))) {
        heff_drop_rec(v_d_243, 3);
        heff_drop(v_xs_247);
        V v_x_2413 = v_field_2411;
        heff_drop(v_x_2413);
        return v_m_242;
      } else {
        heff_drop(v_field_2411);
        HeffT2 v_t_2414 = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(v_scans_241, heff_rfield(v_d_243, 0)));
        V v_t_2419;
        {
          V v_field_2416 = v_t_2414.f[1];
          int64_t v_tag_2415 = ((int64_t)v_t_2414.f[0]);
          if ((v_tag_2415 == ((int64_t)0ULL))) {
            V v_x_2418 = v_field_2416;
            v_t_2419 = v_x_2418;
          } else {
            heff_drop(v_field_2416);
            v_t_2419 = heff_dup(g_heff_2ecompile_2eranges_2eemptyScan_get());
          }
        }
        V v_t_2420 = (g_heff_2ecompile_2eranges_2efnOf(v_xs_247, v_t_2419));
        return (g_std_2emap_2einsert_24s1305793909x1049798133(v_m_242, heff_get_n(v_d_243, 0, 3), v_t_2420));
      }
    }
  }
  case TAG_EApp: {
    heff_take_n(v_t_244, 0ULL, 2);
    heff_drop_rec(v_d_243, 3);
    return v_m_242;
  }
  case TAG_ELet: {
    heff_take_n(v_t_244, 0ULL, 3);
    heff_drop_rec(v_d_243, 3);
    return v_m_242;
  }
  case TAG_ERecord: {
    heff_take_n(v_t_244, 0ULL, 2);
    heff_drop_rec(v_d_243, 3);
    return v_m_242;
  }
  case TAG_EProj: {
    heff_take_n(v_t_244, 0ULL, 4);
    heff_drop_rec(v_d_243, 3);
    return v_m_242;
  }
  case TAG_ETag: {
    heff_take_n(v_t_244, 0ULL, 3);
    heff_drop_rec(v_d_243, 3);
    return v_m_242;
  }
  case TAG_EMatch: {
    heff_take_n(v_t_244, 0ULL, 2);
    heff_drop_rec(v_d_243, 3);
    return v_m_242;
  }
  case TAG_EPrim: {
    heff_take_n(v_t_244, 0ULL, 1);
    heff_drop_rec(v_d_243, 3);
    return v_m_242;
  }
  case TAG_EPrimCall: {
    heff_take_n(v_t_244, 0ULL, 2);
    heff_drop_rec(v_d_243, 3);
    return v_m_242;
  }
  case TAG_ECall: {
    heff_take_n(v_t_244, 0ULL, 2);
    heff_drop_rec(v_d_243, 3);
    return v_m_242;
  }
  case TAG_EInt: {
    heff_take_n(v_t_244, 0ULL, 1);
    heff_drop_rec(v_d_243, 3);
    return v_m_242;
  }
  case TAG_EFloat: {
    heff_take_na(v_t_244, 0ULL, 1);
    heff_drop_rec(v_d_243, 3);
    return v_m_242;
  }
  case TAG_EStr: {
    heff_take_n(v_t_244, 0ULL, 1);
    heff_drop_rec(v_d_243, 3);
    return v_m_242;
  }
  case TAG_EBytes: {
    heff_take_n(v_t_244, 0ULL, 1);
    heff_drop_rec(v_d_243, 3);
    return v_m_242;
  }
  case TAG_EFixed: {
    heff_take_n(v_t_244, 0ULL, 2);
    heff_drop_rec(v_d_243, 3);
    return v_m_242;
  }
  case TAG_EFloat32: {
    heff_take_na(v_t_244, 0ULL, 1);
    heff_drop_rec(v_d_243, 3);
    return v_m_242;
  }
  case TAG_EAbandon: {
    heff_drop_rec(v_d_243, 3);
    return v_m_242;
  }
  case TAG_EFix: {
    heff_take_n(v_t_244, 0ULL, 2);
    heff_drop_rec(v_d_243, 3);
    return v_m_242;
  }
  default: return heff_nomatch(v_t_244);
  }
}
V g_heff_2ecompile_2eranges_2efnOne_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2eranges_2efnOne(a0, a1, a[2], a[3]); heff_drop(a0); heff_drop(a1); return r;
}
V g_heff_2ecompile_2eranges_2escopeWith_lam0(V self, V *args);
Clo g_heff_2ecompile_2eranges_2escopeWith_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eranges_2escopeWith_entry, 4, 0};

V g_heff_2ecompile_2eranges_2escopeWith(V v_sc_240, V v_d_241, V v_ints_242, V v_gs_243) {
top: ;
  switch (heff_tag_of(v_gs_243)) {
  case TAG_Nil: {
    V v_t_244 = (g_std_2emap_2einsert_24s1305793909x1049798133(heff_take_field(v_sc_240, 0), heff_dup(heff_rfield(v_d_241, 0)), heff_dup(v_d_241)));
    V v_t_245;
    if ((heff_dup(v_ints_242) == NTAG(TAG_True))) {
      v_t_245 = (g_std_2emap_2einsert_24s1305793909x1049798133(heff_dup(heff_rfield(v_sc_240, 3)), heff_get_n(v_d_241, 0, 3), NTAG(TAG_MkUnit)));
    } else {
      heff_drop_rec(v_d_241, 3);
      v_t_245 = heff_dup(heff_rfield(v_sc_240, 3));
    }
    return ({ V rv_0 = v_t_244; V rv_3 = v_t_245; V rr_ = heff_rec_reuse_nf(v_sc_240, 6ULL, 4, shape_byKey__callers__callersOf__ints, 60u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 3) = rv_3; rr_; });
  }
  case TAG_Cons: {
    V v_t_248 = (g_std_2emap_2einsert_24s1305793909x1049798133(heff_take_field(v_sc_240, 0), heff_dup(heff_rfield(v_d_241, 0)), heff_dup(v_d_241)));
    V v_t_249 = (g_std_2emap_2einsert_24s1305793909x1049798133(heff_take_field(v_sc_240, 1), heff_dup(heff_rfield(v_d_241, 0)), heff_dup(v_gs_243)));
    V v_t_2419 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2eranges_2escopeWith_lam0, 2, 1, (V[]){heff_dup(v_d_241)}); V a_1 = heff_take_field(v_sc_240, 2); V a_2 = v_gs_243; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop_tag(v_gs_243, 2); r_; });
    V v_t_2420;
    if ((heff_dup(v_ints_242) == NTAG(TAG_True))) {
      v_t_2420 = (g_std_2emap_2einsert_24s1305793909x1049798133(heff_get_n(v_sc_240, 3, 4), heff_get_n(v_d_241, 0, 3), NTAG(TAG_MkUnit)));
    } else {
      heff_drop_rec(v_d_241, 3);
      v_t_2420 = heff_get_n(v_sc_240, 3, 4);
    }
    return heff_rec_n(4, shape_byKey__callers__callersOf__ints, (V[]){v_t_248, v_t_249, v_t_2419, v_t_2420});
  }
  default: return heff_nomatch(v_gs_243);
  }
}
V g_heff_2ecompile_2eranges_2escopeWith_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2eranges_2escopeWith(a[0], a[1], a2, a[3]); heff_drop(a2); return r;
}
V g_heff_2ecompile_2eranges_2escopeWith_lam0(V self, V *args) {
  V v_m_2410 = args[0];
  V v_g_2411 = args[1];
  V v_d_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2412 = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(v_m_2410, v_g_2411));
  V v_t_2417;
  {
    V v_field_2414 = v_t_2412.f[1];
    int64_t v_tag_2413 = ((int64_t)v_t_2412.f[0]);
    if ((v_tag_2413 == ((int64_t)0ULL))) {
      V v_x_2416 = v_field_2414;
      v_t_2417 = v_x_2416;
    } else {
      heff_drop(v_field_2414);
      v_t_2417 = NTAG(TAG_Nil);
    }
  }
  V v_t_2418 = heff_tag_n(TAG_Cons, 2, (V[]){heff_get_n(v_d_241, 0, 3), v_t_2417});
  return (g_std_2emap_2einsert_24s1305793909x1049798133(v_m_2410, v_g_2411, v_t_2418));
}
V g_heff_2ecompile_2eranges_2escopeOne_lam0(V self, V *args);
Clo g_heff_2ecompile_2eranges_2escopeOne_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eranges_2escopeOne_entry, 4, 0};

V g_heff_2ecompile_2eranges_2escopeOne(V v_params_240, V v_sc_241, V v_d_242, V v_s_243) {
top: ;
  V v_m_2411 = (g_list_2efoldl(heff_clo_n(g_heff_2ecompile_2eranges_2escopeOne_lam0, 2, 1, (V[]){heff_dup(v_params_240)}), heff_dup(g_std_2emap_2eempty_get()), heff_rfield(v_s_243, 2)));
  V v_t_2412 = ({ V a_0 = v_m_2411; V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2emap_2etoListOnto(a_0, a_1)); heff_drop(v_m_2411); r_; });
  V v_t_2413 = (g_list_2emap_24s1937570095x2110149801(v_t_2412));
  return ({ V a_0 = v_sc_241; V a_1 = v_d_242; V b_2 = heff_get_n(v_s_243, 3, 5); V a_3 = v_t_2413; V r_ = (g_heff_2ecompile_2eranges_2escopeWith(a_0, a_1, b_2, a_3)); heff_drop(b_2); r_; });
}
V g_heff_2ecompile_2eranges_2escopeOne_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eranges_2escopeOne(a0, a[1], a[2], a[3]); heff_drop(a0); return r;
}
V g_heff_2ecompile_2eranges_2escopeOne_lam0(V self, V *args) {
  V v_m_244 = args[0];
  V v_g_245 = args[1];
  V v_params_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_246 = ({ V a_0 = v_params_240; V a_1 = v_g_245; HeffT2 r_ = (g_std_2emap_2elookup_24s1654411661x99037275_24cpr(a_0, a_1)); heff_drop(v_params_240); r_; });
  {
    V v_field_248 = v_t_246.f[1];
    int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
    if ((v_tag_247 == ((int64_t)0ULL))) {
      V v_x_2410 = v_field_248;
      heff_drop(v_x_2410);
      return (g_std_2emap_2einsert_24s1305793909x1049798133(v_m_244, v_g_245, NTAG(TAG_MkUnit)));
    } else {
      heff_drop(v_g_245);
      heff_drop(v_field_248);
      return v_m_244;
    }
  }
}
V g_heff_2ecompile_2eranges_2enarrowWith_lam0(V self, V *args);
Clo g_heff_2ecompile_2eranges_2enarrowWith_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eranges_2enarrowWith_entry, 4, 0};

V g_heff_2ecompile_2eranges_2enarrowWith(V v_sc_240, V v_nw_241, V v_gathered_242, V v_gs_243) {
top: ;
  V v_t_244 = ({ V rv_1 = heff_dup(v_gathered_242); V rv_2 = NTAG(TAG_Nil); V rr_ = heff_rec_reuse_nf(v_nw_241, 1ULL, 3, shape_params__gathered__changed, 3u, 0u); heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; rr_; });
  return (g_list_2efoldl(heff_clo_n(g_heff_2ecompile_2eranges_2enarrowWith_lam0, 2, 2, (V[]){v_sc_240, v_gathered_242}), v_t_244, v_gs_243));
}
V g_heff_2ecompile_2eranges_2enarrowWith_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2ecompile_2eranges_2enarrowWith(a[0], a[1], a[2], a3); heff_drop(a3); return r;
}
V g_heff_2ecompile_2eranges_2enarrowWith_lam0(V self, V *args) {
  V v_acc_245 = args[0];
  V v_g_246 = args[1];
  V v_sc_240 = heff_env(self)[0];
  V v_gathered_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  HeffT2 v_t_247 = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(heff_rfield(v_acc_245, 0), v_g_246));
  {
    V v_field_249 = v_t_247.f[1];
    int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
    if ((v_tag_248 == ((int64_t)0ULL))) {
      V v_old_2411 = v_field_249;
      V v_t_2412 = (g_list_2eall_24s853093203x77424416(v_old_2411));
      if ((heff_dup(v_t_2412) == NTAG(TAG_True))) {
        heff_drop(v_g_246);
        heff_drop(v_sc_240);
        heff_drop(v_gathered_242);
        heff_drop(v_old_2411);
        heff_drop(v_t_2412);
        return v_acc_245;
      } else {
        heff_drop(v_t_2412);
        V v_t_2413 = (g_heff_2ecompile_2eranges_2ejoinedFor(heff_dup(v_sc_240), v_gathered_242, heff_dup(v_old_2411), v_g_246));
        V v_t_2414 = ({ V a_0 = v_old_2411; V a_1 = v_t_2413; V r_ = (g_heff_2ecompile_2eranges_2erangesEq(a_0, a_1)); heff_drop(v_t_2413); r_; });
        if ((heff_dup(v_t_2414) == NTAG(TAG_True))) {
          heff_drop(v_g_246);
          heff_drop(v_sc_240);
          heff_drop(v_gathered_242);
          heff_drop(v_old_2411);
          heff_drop(v_t_2414);
          return v_acc_245;
        } else {
          heff_drop(v_t_2414);
          V v_t_2415 = ({ V a_0 = v_sc_240; V a_1 = v_gathered_242; V a_2 = v_old_2411; V a_3 = v_g_246; V r_ = (g_heff_2ecompile_2eranges_2ejoinedFor(a_0, a_1, a_2, a_3)); heff_drop(v_gathered_242); r_; });
          V v_t_2416 = (g_std_2emap_2einsert_24s1305793909x1049798133(heff_take_field(v_acc_245, 0), heff_dup(v_g_246), v_t_2415));
          V v_t_2417 = heff_tag_n(TAG_Cons, 2, (V[]){v_g_246, heff_take_field(v_acc_245, 2)});
          return ({ V rv_0 = v_t_2416; V rv_2 = v_t_2417; V rr_ = heff_rec_reuse_nf(v_acc_245, 2ULL, 3, shape_params__gathered__changed, 12u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 2) = rv_2; rr_; });
        }
      }
    } else {
      heff_drop(v_g_246);
      heff_drop(v_sc_240);
      heff_drop(v_gathered_242);
      heff_drop(v_field_249);
      return v_acc_245;
    }
  }
}
V g_heff_2ecompile_2eranges_2enarrowing_lam0(V self, V *args);
V g_heff_2ecompile_2eranges_2enarrowing_lam1(V self, V *args);
Clo g_heff_2ecompile_2eranges_2enarrowing_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eranges_2enarrowing_entry, 4, 0};

V g_heff_2ecompile_2eranges_2enarrowing(V v_consts_240, V v_sc_241, V v_box_24n_242, V v_nw_243) {
  int64_t v_n_242 = heff_unbox_word(v_box_24n_242);
top: ;
  if ((v_n_242 <= ((int64_t)0ULL))) {
    heff_drop(v_consts_240);
    heff_drop_rec(v_sc_241, 4);
    return heff_get_n(v_nw_243, 0, 3);
  } else {
    V v_x1_2411 = (g_list_2efilter(heff_clo_n(g_heff_2ecompile_2eranges_2enarrowing_lam0, 1, 1, (V[]){heff_dup(v_sc_241)}), heff_dup(heff_rfield(v_nw_243, 2))));
    switch (heff_tag_of(v_x1_2411)) {
    case TAG_Nil: {
      heff_drop(v_consts_240);
      heff_drop_rec(v_sc_241, 4);
      return heff_get_n(v_nw_243, 0, 3);
    }
    case TAG_Cons: {
      heff_take_n(v_x1_2411, 0ULL, 2);
      V v_t_2420 = (g_list_2efilter(heff_clo_n(g_heff_2ecompile_2eranges_2enarrowing_lam1, 1, 1, (V[]){heff_dup(v_sc_241)}), heff_dup(heff_rfield(v_nw_243, 2))));
      V v_t_2421 = ({ V a_0 = heff_dup(v_consts_240); V a_1 = heff_dup(v_sc_241); V a_2 = v_nw_243; V a_3 = v_t_2420; V r_ = (g_heff_2ecompile_2eranges_2enarrowOnce(a_0, a_1, a_2, a_3)); heff_drop(v_t_2420); r_; });
      V t_0 = v_consts_240;
      V t_1 = v_sc_241;
      int64_t t_2 = (v_n_242 - ((int64_t)1ULL));
      V t_3 = v_t_2421;
      v_consts_240 = t_0;
      v_sc_241 = t_1;
      v_n_242 = t_2;
      v_nw_243 = t_3;
      goto top;
    }
    default: return heff_nomatch(v_x1_2411);
    }
  }
}
V g_heff_2ecompile_2eranges_2enarrowing_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eranges_2enarrowing(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2eranges_2enarrowing_lam0(V self, V *args) {
  V v_k_245 = args[0];
  V v_sc_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_246 = ({ V b_0 = heff_get_n(v_sc_241, 1, 4); V a_1 = v_k_245; HeffT2 r_ = (g_std_2emap_2elookup_24s1654411661x99037275_24cpr(b_0, a_1)); heff_drop(b_0); heff_drop(v_k_245); r_; });
  {
    V v_field_248 = v_t_246.f[1];
    int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
    V v_ret_24bool = heff_bool(((v_tag_247 == ((int64_t)0ULL)) && ({ V v_x_2410 = heff_dup(v_field_248); int c_ = 1; heff_drop(v_x_2410); c_; })));
    heff_drop(v_field_248);
    return v_ret_24bool;
  }
}
V g_heff_2ecompile_2eranges_2enarrowing_lam1(V self, V *args) {
  V v_k_2414 = args[0];
  V v_sc_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2415 = ({ V b_0 = heff_get_n(v_sc_241, 1, 4); V a_1 = v_k_2414; HeffT2 r_ = (g_std_2emap_2elookup_24s1654411661x99037275_24cpr(b_0, a_1)); heff_drop(b_0); heff_drop(v_k_2414); r_; });
  {
    V v_field_2417 = v_t_2415.f[1];
    int64_t v_tag_2416 = ((int64_t)v_t_2415.f[0]);
    V v_ret_24bool = heff_bool(((v_tag_2416 == ((int64_t)0ULL)) && ({ V v_x_2419 = heff_dup(v_field_2417); int c_ = 1; heff_drop(v_x_2419); c_; })));
    heff_drop(v_field_2417);
    return v_ret_24bool;
  }
}
V g_heff_2ecompile_2eranges_2erangedIn_lam0(V self, V *args);
Clo g_heff_2ecompile_2eranges_2erangedIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eranges_2erangedIn_entry, 4, 0};

V g_heff_2ecompile_2eranges_2erangedIn(V v_consts_240, V v_defs_241, V v_params_242, V v_sc_243) {
top: ;
  V v_t_244 = heff_rec_n(3, shape_fix__dirty__gathered, (V[]){heff_rec_n(3, shape_params__grown__marks, (V[]){heff_dup(v_params_242), heff_dup(g_std_2emap_2eempty_get()), heff_dup(g_std_2emap_2eempty_get())}), heff_dup(g_std_2emap_2eempty_get()), heff_dup(g_std_2emap_2eempty_get())});
  V v_t_245 = (g_list_2emap_24s1835183789x486277886(heff_dup(v_defs_241)));
  V v_t_2412 = (g_list_2efilter(heff_clo_n(g_heff_2ecompile_2eranges_2erangedIn_lam0, 1, 1, (V[]){v_params_242}), v_t_245));
  V v_t_2413 = ({ V a_0 = heff_dup(v_consts_240); V a_1 = heff_dup(v_sc_243); V a_2 = v_t_244; V a_3 = v_t_2412; V r_ = (g_heff_2ecompile_2eranges_2eroundOf(a_0, a_1, a_2, a_3)); heff_drop(v_t_2412); r_; });
  V v_t_2414 = (g_heff_2ecompile_2eranges_2erounds(heff_dup(v_consts_240), heff_dup(v_sc_243), MK_INT(64LL), v_t_2413));
  return ({ V a_0 = v_consts_240; V a_1 = v_sc_243; V a_2 = v_defs_241; V a_3 = v_t_2414; V r_ = (g_heff_2ecompile_2eranges_2esettled(a_0, a_1, a_2, a_3)); heff_drop(v_t_2414); r_; });
}
V g_heff_2ecompile_2eranges_2erangedIn_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eranges_2erangedIn(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2eranges_2erangedIn_lam0(V self, V *args) {
  V v_k_246 = args[0];
  V v_params_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_247 = ({ V a_0 = v_params_242; V a_1 = v_k_246; HeffT2 r_ = (g_std_2emap_2elookup_24s1654411661x99037275_24cpr(a_0, a_1)); heff_drop(v_params_242); heff_drop(v_k_246); r_; });
  {
    V v_field_249 = v_t_247.f[1];
    int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
    V v_ret_24bool = heff_bool(((v_tag_248 == ((int64_t)0ULL)) ? ({ V v_x_2411 = heff_dup(v_field_249); int c_ = 0; heff_drop(v_x_2411); c_; }) : 1));
    heff_drop(v_field_249);
    return v_ret_24bool;
  }
}