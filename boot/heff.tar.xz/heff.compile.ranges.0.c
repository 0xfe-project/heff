// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_CFalse 2759
#define TAG_CIf 14188
#define TAG_CNot 51573
#define TAG_CRel 55099
#define TAG_CTest 64009
#define TAG_CTrue 11023
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBool 8245
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_ESet 50124
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EValues 34965
#define TAG_EVar 52881
#define TAG_FloatFromInt 61384
#define TAG_IntAdd 18227
#define TAG_IntAnd 18537
#define TAG_IntDiv 21283
#define TAG_IntEq 36665
#define TAG_IntLe 36870
#define TAG_IntLt 36885
#define TAG_IntMod 30100
#define TAG_IntMul 30294
#define TAG_IntSub 36050
#define TAG_MkArm 55352
#define TAG_MkRes 5766
#define TAG_MkResVals 58586
#define TAG_MkSeen 11336
#define TAG_MkSeenVals 17452
#define TAG_MkTest 41567
#define TAG_Unreached 46435
#define TAG_Within 10658
#define TAG_WordAdd 60179
#define TAG_WordDiv 63235
#define TAG_WordEq 48587
#define TAG_WordLe 48792
#define TAG_WordLt 48807
#define TAG_WordMod 6526
#define TAG_WordMul 6720
#define TAG_WordQuot 65290
#define TAG_WordRem 11030
#define TAG_WordSub 12476
#define TAG_WordToFloat 50865
#define LBL_byKey 295543458
#define LBL_callers 780494982
#define LBL_calls 295783919
#define LBL_changed 970801394
#define LBL_consts 592362651
#define LBL_escapes 914714193
#define LBL_gathered 1327153563
#define LBL_given 299725719
#define LBL_ints 9732907
#define LBL_marking 1071112247
#define LBL_marks 305024864
#define LBL_numeric 378927440
#define LBL_params 951713969
#define LBL_ranges 1008858625
static uint32_t shape_calls__marks[] = {LBL_calls, LBL_marks};
static uint32_t shape_numeric__given__calls__ints__escapes[] = {LBL_numeric, LBL_given, LBL_calls, LBL_ints, LBL_escapes};
static uint32_t shape_params__consts__marking[] = {LBL_params, LBL_consts, LBL_marking};
static uint32_t shape_params__gathered__changed[] = {LBL_params, LBL_gathered, LBL_changed};
V g_heff_2ecompile_2eir_2eappendI(V, V);
V g_heff_2ecompile_2eir_2eappendI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eappendI_clo;
V g_heff_2ecompile_2eir_2eappendI_24tok2(V, V, V);
V g_heff_2ecompile_2eir_2eappendI_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eappendI_24tok2_clo;
V g_heff_2ecompile_2eir_2econdOf(V);
V g_heff_2ecompile_2eir_2econdOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2econdOf_clo;
V g_heff_2ecompile_2eir_2econdOnto(V, V);
V g_heff_2ecompile_2eir_2econdOnto_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2econdOnto_clo;
V g_heff_2ecompile_2eir_2epartsOnto(V, V);
V g_heff_2ecompile_2eir_2epartsOnto_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2epartsOnto_clo;
V g_heff_2ecompile_2eranges_2eanyRange_get(void);
V g_heff_2ecompile_2eranges_2econdRefine(V, V, V, V);
V g_heff_2ecompile_2eranges_2econdRefine_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2econdRefine_clo;
V g_heff_2ecompile_2eranges_2egatherArms(V, V, V, V, V, V);
V g_heff_2ecompile_2eranges_2egatherArms_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2egatherArms_clo;
HeffT3 g_heff_2ecompile_2eranges_2egatherArms_24cpr(V, V, V, V, V, V);
V g_heff_2ecompile_2eranges_2egatherCond(V, V, V, V, V);
V g_heff_2ecompile_2eranges_2egatherCond_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2egatherCond_clo;
V g_heff_2ecompile_2eranges_2egatherDef(V, V);
V g_heff_2ecompile_2eranges_2egatherDef_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2egatherDef_clo;
HeffT2 g_heff_2ecompile_2eranges_2egatherMany_24cpr(V, V, V, V);
V g_heff_2ecompile_2eranges_2egivenFrom(V, V, V, V);
V g_heff_2ecompile_2eranges_2egivenFrom_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2egivenFrom_clo;
V g_heff_2ecompile_2eranges_2eisIntRel(V);
V g_heff_2ecompile_2eranges_2eisIntRel_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2eisIntRel_clo;
V g_heff_2ecompile_2eranges_2ejoin(V, V);
V g_heff_2ecompile_2eranges_2ejoin_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2ejoin_clo;
V g_heff_2ecompile_2eranges_2ejoinedFor(V, V, V, V);
V g_heff_2ecompile_2eranges_2ejoinedFor_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2ejoinedFor_clo;
V g_heff_2ecompile_2eranges_2emarkRange(V, V);
V g_heff_2ecompile_2eranges_2emarkRange_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2emarkRange_clo;
V g_heff_2ecompile_2eranges_2emeet(V, V);
V g_heff_2ecompile_2eranges_2emeet_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2emeet_clo;
V g_heff_2ecompile_2eranges_2emodR(V, V);
V g_heff_2ecompile_2eranges_2emodR_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2emodR_clo;
V g_heff_2ecompile_2eranges_2enamesW(V, V);
V g_heff_2ecompile_2eranges_2enamesW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2enamesW_clo;
V g_heff_2ecompile_2eranges_2enarrowTo(V, V, V);
V g_heff_2ecompile_2eranges_2enarrowTo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2enarrowTo_clo;
V g_heff_2ecompile_2eranges_2enarrowWith(V, V, V, V);
V g_heff_2ecompile_2eranges_2enarrowWith_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2enarrowWith_clo;
V g_heff_2ecompile_2eranges_2enarrowing(V, V, V, V);
V g_heff_2ecompile_2eranges_2enarrowing_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2enarrowing_clo;
V g_heff_2ecompile_2eranges_2enatural(V);
V g_heff_2ecompile_2eranges_2enatural_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2enatural_clo;
V g_heff_2ecompile_2eranges_2enonZero(V);
V g_heff_2ecompile_2eranges_2enonZero_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2enonZero_clo;
V g_heff_2ecompile_2eranges_2eoperandRange(V, V, V);
V g_heff_2ecompile_2eranges_2eoperandRange_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2eoperandRange_clo;
V g_heff_2ecompile_2eranges_2erangesEq(V, V);
V g_heff_2ecompile_2eranges_2erangesEq_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2erangesEq_clo;
V g_heff_2ecompile_2eranges_2erootGo(V, V, V);
V g_heff_2ecompile_2eranges_2erootGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2erootGo_clo;
V g_heff_2ecompile_2eranges_2escanCond(V, V);
V g_heff_2ecompile_2eranges_2escanCond_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2escanCond_clo;
V g_heff_2ecompile_2eranges_2escanW(V, V, V);
V g_heff_2ecompile_2eranges_2escanW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2escanW_clo;
V g_heff_2ecompile_2eranges_2etrimLow(V, V);
V g_heff_2ecompile_2eranges_2etrimLow_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2etrimLow_clo;
V g_heff_2ecompile_2eranges_2ewalkCond(V, V, V, V);
V g_heff_2ecompile_2eranges_2ewalkCond_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2ewalkCond_clo;
V g_heff_2ecompile_2eranges_2ewalkCond_24dps(V, V, V, V, V, V);
V g_heff_2ecompile_2eranges_2ewalkCond_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2ewalkCond_24dps_clo;
HeffT2 g_heff_2ecompile_2eranges_2ewalkMany_24cpr(V, V, V);
V g_heff_2ecompile_2eranges_2ewithRange(V, V, V);
V g_heff_2ecompile_2eranges_2ewithRange_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eranges_2ewithRange_clo;
HeffT2 g_heff_2ecompile_2eranges_2ewordOf_24cpr(V, V, V);
V g_list_2eall_24s525729714x658270192(V);
V g_list_2eall_24s525729714x658270192_entry(V self, V *a);
extern Clo g_list_2eall_24s525729714x658270192_clo;
V g_list_2eall_24s853093203x77424416(V);
V g_list_2eall_24s853093203x77424416_entry(V self, V *a);
extern Clo g_list_2eall_24s853093203x77424416_clo;
HeffT3 g_list_2edrop_24cpr(V, V);
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24s1614667250x430274379(V, V);
V g_list_2efoldl_24s1614667250x430274379_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1614667250x430274379_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2ekeepIf(V, V);
V g_list_2ekeepIf_entry(V self, V *a);
extern Clo g_list_2ekeepIf_clo;
V g_list_2emap_24s1937570095x2110149801(V);
V g_list_2emap_24s1937570095x2110149801_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_clo;
V g_list_2emap_24s1937570095x2110149801_24tok2(V, V);
V g_list_2emap_24s1937570095x2110149801_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_24tok2_clo;
V g_list_2ezipWith_24s1026658656x682908126(V, V);
V g_list_2ezipWith_24s1026658656x682908126_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1026658656x682908126_clo;
V g_std_2eordmap_2eempty_get(void);
V g_std_2eordmap_2einsert_24s1703101629x493626677(V, V, V);
V g_std_2eordmap_2einsert_24s1703101629x493626677_entry(V self, V *a);
extern Clo g_std_2eordmap_2einsert_24s1703101629x493626677_clo;
V g_std_2eordmap_2einsert_24s615484302x989744458(V, V, V);
V g_std_2eordmap_2einsert_24s615484302x989744458_entry(V self, V *a);
extern Clo g_std_2eordmap_2einsert_24s615484302x989744458_clo;
HeffT2 g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(V, V);
HeffT2 g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(V, V);
V g_std_2eordmap_2etoList_2etoListOnto_240(V, V);
V g_std_2eordmap_2etoList_2etoListOnto_240_entry(V self, V *a);
extern Clo g_std_2eordmap_2etoList_2etoListOnto_240_clo;
Clo g_heff_2ecompile_2eranges_2emodR_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eranges_2emodR_entry, 2, 0};

V g_heff_2ecompile_2eranges_2emodR(V v_a_240, V v_b_241) {
top: ;
  switch (heff_tag_of(v_b_241)) {
  case TAG_Unreached: {
    return heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
  }
  case TAG_Within: {
    V v_lb_242 = heff_field(v_b_241, 0);
    V v_hb_243 = heff_field(v_b_241, 1);
    V v_ru_24b_241_24Within = heff_take_reuse_n(v_b_241, 3ULL, 2);
    switch (heff_tag_of(v_lb_242)) {
    case TAG_Nothing: {
      switch (heff_tag_of(v_hb_243)) {
      case TAG_Nothing: {
        heff_drop_cell(v_ru_24b_241_24Within, 2);
        return heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
      }
      case TAG_Just: {
        V v_a_244 = heff_field(v_hb_243, 0);
        V v_ru_24hb_243_24Just = heff_take_reuse_n(v_hb_243, 1ULL, 1);
        if (heff_intLt_c(v_a_244, MK_INT(0LL))) {
          V v_t_246;
          switch (heff_tag_of(v_lb_242)) {
          case TAG_Nothing: {
            heff_drop_cell(v_ru_24hb_243_24Just, 1);
            v_t_246 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_Just: {
            V v_a_245 = heff_field(v_lb_242, 0);
            heff_take_n(v_lb_242, 1ULL, 1);
            v_t_246 = heff_tag_at_n(v_ru_24hb_243_24Just, TAG_Just, 1, (V[]){heff_intAdd(v_a_245, MK_INT(1LL))});
            break;
          }
          default: heff_nomatch(v_lb_242);
          }
          return heff_tag_at_n(v_ru_24b_241_24Within, TAG_Within, 2, (V[]){v_t_246, heff_tag_n(TAG_Just, 1, (V[]){MK_INT(0LL)})});
        } else {
          heff_drop_cell(v_ru_24b_241_24Within, 2);
          heff_drop_cell(v_ru_24hb_243_24Just, 1);
          return heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
        }
      }
      default: return heff_nomatch(v_hb_243);
      }
    }
    case TAG_Just: {
      V v_a_247 = heff_dup(heff_field(v_lb_242, 0));
      if (heff_intLt_c(MK_INT(0LL), v_a_247)) {
        heff_drop_tag(v_lb_242, 1);
        V v_x1_249;
        switch (heff_tag_of(v_hb_243)) {
        case TAG_Nothing: {
          v_x1_249 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_Just: {
          V v_a_248 = heff_field(v_hb_243, 0);
          V v_ru_24hb_243_24Just = heff_take_reuse_n(v_hb_243, 1ULL, 1);
          v_x1_249 = heff_tag_at_n(v_ru_24hb_243_24Just, TAG_Just, 1, (V[]){heff_intAdd(v_a_248, MK_INT(-1LL))});
          break;
        }
        default: heff_nomatch(v_hb_243);
        }
        V v_x2_2417;
        switch (heff_tag_of(v_a_240)) {
        case TAG_Unreached: {
          v_x2_2417 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_Within: {
          V v_lo_2410 = heff_field(v_a_240, 0);
          switch (heff_tag_of(v_lo_2410)) {
          case TAG_Nothing: {
            switch (heff_tag_of(v_a_240)) {
            case TAG_Within: {
              v_x2_2417 = NTAG(TAG_Nothing);
              break;
            }
            default: heff_nomatch(v_a_240);
            }
            break;
          }
          case TAG_Just: {
            V v_a_2414 = heff_field(v_lo_2410, 0);
            if (heff_intLe_c_lent(MK_INT(0LL), v_a_2414, 1)) {
              switch (heff_tag_of(v_a_240)) {
              case TAG_Unreached: {
                v_x2_2417 = NTAG(TAG_Nothing);
                break;
              }
              case TAG_Within: {
                V v_hi_2416 = heff_field(v_a_240, 1);
                v_x2_2417 = heff_dup(v_hi_2416);
                break;
              }
              default: heff_nomatch(v_a_240);
              }
            } else {
              v_x2_2417 = NTAG(TAG_Nothing);
            }
            break;
          }
          default: heff_nomatch(v_lo_2410);
          }
          break;
        }
        default: heff_nomatch(v_a_240);
        }
        V v_t_2421;
        switch (heff_tag_of(v_x1_249)) {
        case TAG_Nothing: {
          v_t_2421 = v_x2_2417;
          break;
        }
        case TAG_Just: {
          V v_a_2418 = heff_field(v_x1_249, 0);
          V v_ru_24x1_249_24Just = heff_take_reuse_n(v_x1_249, 1ULL, 1);
          switch (heff_tag_of(v_x2_2417)) {
          case TAG_Nothing: {
            v_t_2421 = heff_tag_at_n(v_ru_24x1_249_24Just, TAG_Just, 1, (V[]){v_a_2418});
            break;
          }
          case TAG_Just: {
            V v_b_2419 = heff_field(v_x2_2417, 0);
            heff_take_n(v_x2_2417, 1ULL, 1);
            V v_t_2420;
            if (heff_intLt_c_lent(v_a_2418, v_b_2419, 0)) {
              heff_drop(v_b_2419);
              v_t_2420 = v_a_2418;
            } else {
              heff_drop(v_a_2418);
              v_t_2420 = v_b_2419;
            }
            v_t_2421 = heff_tag_at_n(v_ru_24x1_249_24Just, TAG_Just, 1, (V[]){v_t_2420});
            break;
          }
          default: heff_nomatch(v_x2_2417);
          }
          break;
        }
        default: heff_nomatch(v_x1_249);
        }
        return heff_tag_at_n(v_ru_24b_241_24Within, TAG_Within, 2, (V[]){heff_tag_n(TAG_Just, 1, (V[]){MK_INT(0LL)}), v_t_2421});
      } else {
        switch (heff_tag_of(v_hb_243)) {
        case TAG_Nothing: {
          heff_drop_tag(v_lb_242, 1);
          heff_drop_cell(v_ru_24b_241_24Within, 2);
          return heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
        }
        case TAG_Just: {
          V v_a_2422 = heff_field(v_hb_243, 0);
          V v_ru_24hb_243_24Just = heff_take_reuse_n(v_hb_243, 1ULL, 1);
          if (heff_intLt_c(v_a_2422, MK_INT(0LL))) {
            V v_t_2424;
            switch (heff_tag_of(v_lb_242)) {
            case TAG_Nothing: {
              heff_drop_cell(v_ru_24hb_243_24Just, 1);
              v_t_2424 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_Just: {
              V v_a_2423 = heff_field(v_lb_242, 0);
              heff_take_n(v_lb_242, 1ULL, 1);
              v_t_2424 = heff_tag_at_n(v_ru_24hb_243_24Just, TAG_Just, 1, (V[]){heff_intAdd(v_a_2423, MK_INT(1LL))});
              break;
            }
            default: heff_nomatch(v_lb_242);
            }
            return heff_tag_at_n(v_ru_24b_241_24Within, TAG_Within, 2, (V[]){v_t_2424, heff_tag_n(TAG_Just, 1, (V[]){MK_INT(0LL)})});
          } else {
            heff_drop_tag(v_lb_242, 1);
            heff_drop_cell(v_ru_24b_241_24Within, 2);
            heff_drop_cell(v_ru_24hb_243_24Just, 1);
            return heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
          }
        }
        default: return heff_nomatch(v_hb_243);
        }
      }
    }
    default: return heff_nomatch(v_lb_242);
    }
  }
  default: return heff_nomatch(v_b_241);
  }
}
V g_heff_2ecompile_2eranges_2emodR_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eranges_2emodR(a0, a[1]); heff_drop(a0); return r;
}

HeffT2 g_heff_2ecompile_2eranges_2ewordOf_24cpr(V v_p_240, V v_rs_241, V v_r_242) {
top: ;
  switch (heff_tag_of(v_p_240)) {
  case TAG_IntAdd: {
    V v_t_243 = (g_list_2eall_24s525729714x658270192(v_rs_241));
    if ((heff_dup(v_t_243) == NTAG(TAG_True))) {
      heff_drop(v_t_243);
      switch (heff_tag_of(v_r_242)) {
      case TAG_Unreached: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_Within: {
        V v_r1_244 = heff_field(v_r_242, 0);
        V v_r2_245 = heff_field(v_r_242, 1);
        switch (heff_tag_of(v_r1_244)) {
        case TAG_Nothing: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_Just: {
          V v_lo_246 = heff_field(v_r1_244, 0);
          switch (heff_tag_of(v_r2_245)) {
          case TAG_Nothing: {
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          case TAG_Just: {
            V v_hi_247 = heff_field(v_r2_245, 0);
            if ((heff_intLe_c_lent(MK_INT(-4611686018427387904LL), v_lo_246, 1) && heff_intLe_c_lent(v_hi_247, MK_INT(4611686018427387903LL), 2))) {
              return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), NTAG(TAG_WordAdd)}});
            } else {
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
            }
          }
          default: return ((HeffT2){{heff_nomatch(v_r2_245)}});
          }
        }
        default: return ((HeffT2){{heff_nomatch(v_r1_244)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_r_242)}});
      }
    } else {
      heff_drop(v_t_243);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
  }
  case TAG_IntSub: {
    V v_t_248 = (g_list_2eall_24s525729714x658270192(v_rs_241));
    if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
      heff_drop(v_t_248);
      switch (heff_tag_of(v_r_242)) {
      case TAG_Unreached: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_Within: {
        V v_r1_249 = heff_field(v_r_242, 0);
        V v_r2_2410 = heff_field(v_r_242, 1);
        switch (heff_tag_of(v_r1_249)) {
        case TAG_Nothing: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_Just: {
          V v_lo_2411 = heff_field(v_r1_249, 0);
          switch (heff_tag_of(v_r2_2410)) {
          case TAG_Nothing: {
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          case TAG_Just: {
            V v_hi_2412 = heff_field(v_r2_2410, 0);
            if ((heff_intLe_c_lent(MK_INT(-4611686018427387904LL), v_lo_2411, 1) && heff_intLe_c_lent(v_hi_2412, MK_INT(4611686018427387903LL), 2))) {
              return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), NTAG(TAG_WordSub)}});
            } else {
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
            }
          }
          default: return ((HeffT2){{heff_nomatch(v_r2_2410)}});
          }
        }
        default: return ((HeffT2){{heff_nomatch(v_r1_249)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_r_242)}});
      }
    } else {
      heff_drop(v_t_248);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
  }
  case TAG_IntMul: {
    V v_t_2413 = (g_list_2eall_24s525729714x658270192(v_rs_241));
    if ((heff_dup(v_t_2413) == NTAG(TAG_True))) {
      heff_drop(v_t_2413);
      switch (heff_tag_of(v_r_242)) {
      case TAG_Unreached: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_Within: {
        V v_r1_2414 = heff_field(v_r_242, 0);
        V v_r2_2415 = heff_field(v_r_242, 1);
        switch (heff_tag_of(v_r1_2414)) {
        case TAG_Nothing: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_Just: {
          V v_lo_2416 = heff_field(v_r1_2414, 0);
          switch (heff_tag_of(v_r2_2415)) {
          case TAG_Nothing: {
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          case TAG_Just: {
            V v_hi_2417 = heff_field(v_r2_2415, 0);
            if ((heff_intLe_c_lent(MK_INT(-4611686018427387904LL), v_lo_2416, 1) && heff_intLe_c_lent(v_hi_2417, MK_INT(4611686018427387903LL), 2))) {
              return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), NTAG(TAG_WordMul)}});
            } else {
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
            }
          }
          default: return ((HeffT2){{heff_nomatch(v_r2_2415)}});
          }
        }
        default: return ((HeffT2){{heff_nomatch(v_r1_2414)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_r_242)}});
      }
    } else {
      heff_drop(v_t_2413);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
  }
  case TAG_IntDiv: {
    V v_t_2418 = (g_list_2eall_24s525729714x658270192(v_rs_241));
    if ((heff_dup(v_t_2418) == NTAG(TAG_True))) {
      heff_drop(v_t_2418);
      switch (heff_tag_of(v_r_242)) {
      case TAG_Unreached: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_Within: {
        V v_r1_2419 = heff_field(v_r_242, 0);
        V v_r2_2420 = heff_field(v_r_242, 1);
        switch (heff_tag_of(v_r1_2419)) {
        case TAG_Nothing: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_Just: {
          V v_lo_2421 = heff_field(v_r1_2419, 0);
          switch (heff_tag_of(v_r2_2420)) {
          case TAG_Nothing: {
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          case TAG_Just: {
            V v_hi_2422 = heff_field(v_r2_2420, 0);
            if ((heff_intLe_c_lent(MK_INT(-4611686018427387904LL), v_lo_2421, 1) && heff_intLe_c_lent(v_hi_2422, MK_INT(4611686018427387903LL), 2))) {
              HeffT3 v_t_2423 = (g_list_2edrop_24cpr(MK_INT(1LL), v_rs_241));
              V v_t_2429;
              {
                V v_field_2425 = v_t_2423.f[1];
                V v_field_2426 = v_t_2423.f[2];
                int64_t v_tag_2424 = ((int64_t)v_t_2423.f[0]);
                if ((v_tag_2424 == ((int64_t)0ULL))) {
                  V v_x_2427 = v_field_2425;
                  V v_x12_2428 = v_field_2426;
                  heff_drop(v_x12_2428);
                  v_t_2429 = v_x_2427;
                } else {
                  heff_drop(v_field_2425);
                  heff_drop(v_field_2426);
                  v_t_2429 = heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
                }
              }
              V v_t_2430 = ({ V a_0 = v_t_2429; V r_ = (g_heff_2ecompile_2eranges_2enonZero(a_0)); heff_drop(v_t_2429); r_; });
              if ((heff_dup(v_t_2430) == NTAG(TAG_True))) {
                heff_drop(v_t_2430);
                V v_t_2431 = (g_heff_2ecompile_2eranges_2enatural(v_rs_241));
                V v_f_2432;
                if ((heff_dup(v_t_2431) == NTAG(TAG_True))) {
                  heff_drop(v_t_2431);
                  v_f_2432 = NTAG(TAG_WordQuot);
                } else {
                  heff_drop(v_t_2431);
                  v_f_2432 = NTAG(TAG_WordDiv);
                }
                return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2432}});
              } else {
                heff_drop(v_t_2430);
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
              }
            } else {
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
            }
          }
          default: return ((HeffT2){{heff_nomatch(v_r2_2420)}});
          }
        }
        default: return ((HeffT2){{heff_nomatch(v_r1_2419)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_r_242)}});
      }
    } else {
      heff_drop(v_t_2418);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
  }
  case TAG_IntMod: {
    V v_t_2433 = (g_list_2eall_24s525729714x658270192(v_rs_241));
    if ((heff_dup(v_t_2433) == NTAG(TAG_True))) {
      heff_drop(v_t_2433);
      switch (heff_tag_of(v_r_242)) {
      case TAG_Unreached: {
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_Within: {
        V v_r1_2434 = heff_field(v_r_242, 0);
        V v_r2_2435 = heff_field(v_r_242, 1);
        switch (heff_tag_of(v_r1_2434)) {
        case TAG_Nothing: {
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_Just: {
          V v_lo_2436 = heff_field(v_r1_2434, 0);
          switch (heff_tag_of(v_r2_2435)) {
          case TAG_Nothing: {
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
          case TAG_Just: {
            V v_hi_2437 = heff_field(v_r2_2435, 0);
            if ((heff_intLe_c_lent(MK_INT(-4611686018427387904LL), v_lo_2436, 1) && heff_intLe_c_lent(v_hi_2437, MK_INT(4611686018427387903LL), 2))) {
              HeffT3 v_t_2438 = (g_list_2edrop_24cpr(MK_INT(1LL), v_rs_241));
              V v_t_2444;
              {
                V v_field_2440 = v_t_2438.f[1];
                V v_field_2441 = v_t_2438.f[2];
                int64_t v_tag_2439 = ((int64_t)v_t_2438.f[0]);
                if ((v_tag_2439 == ((int64_t)0ULL))) {
                  V v_x_2442 = v_field_2440;
                  V v_x12_2443 = v_field_2441;
                  heff_drop(v_x12_2443);
                  v_t_2444 = v_x_2442;
                } else {
                  heff_drop(v_field_2440);
                  heff_drop(v_field_2441);
                  v_t_2444 = heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
                }
              }
              V v_t_2445 = ({ V a_0 = v_t_2444; V r_ = (g_heff_2ecompile_2eranges_2enonZero(a_0)); heff_drop(v_t_2444); r_; });
              if ((heff_dup(v_t_2445) == NTAG(TAG_True))) {
                heff_drop(v_t_2445);
                V v_t_2446 = (g_heff_2ecompile_2eranges_2enatural(v_rs_241));
                V v_f_2447;
                if ((heff_dup(v_t_2446) == NTAG(TAG_True))) {
                  heff_drop(v_t_2446);
                  v_f_2447 = NTAG(TAG_WordRem);
                } else {
                  heff_drop(v_t_2446);
                  v_f_2447 = NTAG(TAG_WordMod);
                }
                return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2447}});
              } else {
                heff_drop(v_t_2445);
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
              }
            } else {
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
            }
          }
          default: return ((HeffT2){{heff_nomatch(v_r2_2435)}});
          }
        }
        default: return ((HeffT2){{heff_nomatch(v_r1_2434)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_r_242)}});
      }
    } else {
      heff_drop(v_t_2433);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
  }
  case TAG_IntEq: {
    V v_t_2448 = (g_list_2eall_24s525729714x658270192(v_rs_241));
    if ((heff_dup(v_t_2448) == NTAG(TAG_True))) {
      heff_drop(v_t_2448);
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), NTAG(TAG_WordEq)}});
    } else {
      heff_drop(v_t_2448);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
  }
  case TAG_IntLt: {
    V v_t_2449 = (g_list_2eall_24s525729714x658270192(v_rs_241));
    if ((heff_dup(v_t_2449) == NTAG(TAG_True))) {
      heff_drop(v_t_2449);
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), NTAG(TAG_WordLt)}});
    } else {
      heff_drop(v_t_2449);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
  }
  case TAG_IntLe: {
    V v_t_2450 = (g_list_2eall_24s525729714x658270192(v_rs_241));
    if ((heff_dup(v_t_2450) == NTAG(TAG_True))) {
      heff_drop(v_t_2450);
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), NTAG(TAG_WordLe)}});
    } else {
      heff_drop(v_t_2450);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
  }
  case TAG_FloatFromInt: {
    V v_t_2451 = (g_list_2eall_24s525729714x658270192(v_rs_241));
    if ((heff_dup(v_t_2451) == NTAG(TAG_True))) {
      heff_drop(v_t_2451);
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), NTAG(TAG_WordToFloat)}});
    } else {
      heff_drop(v_t_2451);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
  }
  default: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  }
}
Clo g_heff_2ecompile_2eranges_2eisIntRel_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eranges_2eisIntRel_entry, 1, 0};

V g_heff_2ecompile_2eranges_2eisIntRel(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_IntEq: {
    return NTAG(TAG_True);
  }
  case TAG_IntLt: {
    return NTAG(TAG_True);
  }
  case TAG_IntLe: {
    return NTAG(TAG_True);
  }
  default: {
    return NTAG(TAG_False);
  }
  }
}
V g_heff_2ecompile_2eranges_2eisIntRel_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eranges_2eisIntRel(a0); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2eranges_2etrimLow_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eranges_2etrimLow_entry, 2, 0};

V g_heff_2ecompile_2eranges_2etrimLow(V v_v_240, V v_r_241) {
top: ;
  switch (heff_tag_of(v_r_241)) {
  case TAG_Unreached: {
    heff_drop(v_v_240);
    return v_r_241;
  }
  case TAG_Within: {
    V v_r1_242 = heff_dup(heff_field(v_r_241, 0));
    switch (heff_tag_of(v_r1_242)) {
    case TAG_Nothing: {
      heff_drop(v_v_240);
      return v_r_241;
    }
    case TAG_Just: {
      V v_lo_244 = heff_field(v_r1_242, 0);
      V v_ru_24r1_242_24Just = heff_take_reuse_n(v_r1_242, 1ULL, 1);
      switch (heff_tag_of(v_r_241)) {
      case TAG_Within: {
        V v_hi_246 = heff_field(v_r_241, 1);
        V v_ru_24r_241_24Within = heff_take_reuse_n(v_r_241, 2ULL, 2);
        if (heff_intEq_c_lent(v_lo_244, v_v_240, 0)) {
          heff_drop(v_lo_244);
          V v_t_247 = heff_intAdd(v_v_240, MK_INT(1LL));
          switch (heff_tag_of(v_hi_246)) {
          case TAG_Nothing: {
            return heff_tag_at_n(v_ru_24r_241_24Within, TAG_Within, 2, (V[]){heff_tag_at_n(v_ru_24r1_242_24Just, TAG_Just, 1, (V[]){v_t_247}), v_hi_246});
          }
          case TAG_Just: {
            V v_hi_248 = heff_field(v_hi_246, 0);
            V v_ru_24hi_246_24Just = heff_take_reuse_n(v_hi_246, 1ULL, 1);
            if (heff_intLt_c_lent(v_hi_248, v_t_247, 0)) {
              heff_drop_cell(v_ru_24r1_242_24Just, 1);
              heff_drop_cell(v_ru_24r_241_24Within, 2);
              heff_drop(v_t_247);
              heff_drop(v_hi_248);
              heff_drop_cell(v_ru_24hi_246_24Just, 1);
              return NTAG(TAG_Unreached);
            } else {
              return heff_tag_at_n(v_ru_24r_241_24Within, TAG_Within, 2, (V[]){heff_tag_at_n(v_ru_24r1_242_24Just, TAG_Just, 1, (V[]){v_t_247}), heff_tag_at_n(v_ru_24hi_246_24Just, TAG_Just, 1, (V[]){v_hi_248})});
            }
          }
          default: return heff_nomatch(v_hi_246);
          }
        } else {
          heff_drop(v_v_240);
          return heff_tag_at_n(v_ru_24r_241_24Within, TAG_Within, 2, (V[]){heff_tag_at_n(v_ru_24r1_242_24Just, TAG_Just, 1, (V[]){v_lo_244}), v_hi_246});
        }
      }
      default: return heff_nomatch(v_r_241);
      }
    }
    default: return heff_nomatch(v_r1_242);
    }
  }
  default: return heff_nomatch(v_r_241);
  }
}
V g_heff_2ecompile_2eranges_2etrimLow_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eranges_2etrimLow(a[0], a[1]);
}
Clo g_heff_2ecompile_2eranges_2erootGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eranges_2erootGo_entry, 3, 0};

V g_heff_2ecompile_2eranges_2erootGo(V v_n_240, V v_lo_241, V v_hi_242) {
top: ;
  if (heff_intLe_c_lent(v_hi_242, v_lo_241, 0)) {
    heff_drop(v_n_240);
    heff_drop(v_hi_242);
    return v_lo_241;
  } else {
    V v_t_243 = heff_intAdd(heff_intAdd(heff_dup(v_lo_241), heff_dup(v_hi_242)), MK_INT(1LL));
    V v_t_244 = heff_intAdd(heff_intAdd(heff_dup(v_lo_241), heff_dup(v_hi_242)), MK_INT(1LL));
    V v_t_245 = heff_intMul(heff_intDiv(v_t_243, MK_INT(2LL)), heff_intDiv(v_t_244, MK_INT(2LL)));
    if (heff_intLe_c_lent(v_t_245, v_n_240, 1)) {
      V v_t_246 = heff_intAdd(heff_intAdd(v_lo_241, heff_dup(v_hi_242)), MK_INT(1LL));
      V t_0 = v_n_240;
      V t_1 = heff_intDiv(v_t_246, MK_INT(2LL));
      V t_2 = v_hi_242;
      v_n_240 = t_0;
      v_lo_241 = t_1;
      v_hi_242 = t_2;
      goto top;
    } else {
      V v_t_247 = heff_intAdd(heff_intAdd(heff_dup(v_lo_241), v_hi_242), MK_INT(1LL));
      V v_t_248 = heff_intSub(heff_intDiv(v_t_247, MK_INT(2LL)), MK_INT(1LL));
      V t_0 = v_n_240;
      V t_1 = v_lo_241;
      V t_2 = v_t_248;
      v_n_240 = t_0;
      v_lo_241 = t_1;
      v_hi_242 = t_2;
      goto top;
    }
  }
}
V g_heff_2ecompile_2eranges_2erootGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eranges_2erootGo(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2eranges_2enarrowTo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eranges_2enarrowTo_entry, 3, 0};

V g_heff_2ecompile_2eranges_2enarrowTo(V v_env_240, V v_e_241, V v_r_242) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_EVar: {
    V v_x_243 = heff_field(v_e_241, 0);
    heff_take_n(v_e_241, 1ULL, 1);
    HEFF_LAST return g_heff_2ecompile_2eranges_2ewithRange(v_env_240, v_x_243, v_r_242);
  }
  case TAG_EGlobal: {
    heff_take_n(v_e_241, 0ULL, 1);
    heff_drop(v_r_242);
    return v_env_240;
  }
  case TAG_ELam: {
    heff_take_n(v_e_241, 0ULL, 2);
    heff_drop(v_r_242);
    return v_env_240;
  }
  case TAG_EApp: {
    heff_take_n(v_e_241, 0ULL, 2);
    heff_drop(v_r_242);
    return v_env_240;
  }
  case TAG_ELet: {
    heff_take_n(v_e_241, 0ULL, 3);
    heff_drop(v_r_242);
    return v_env_240;
  }
  case TAG_ERecord: {
    heff_take_n(v_e_241, 0ULL, 2);
    heff_drop(v_r_242);
    return v_env_240;
  }
  case TAG_EProj: {
    heff_take_n(v_e_241, 0ULL, 4);
    heff_drop(v_r_242);
    return v_env_240;
  }
  case TAG_ETag: {
    heff_take_n(v_e_241, 0ULL, 3);
    heff_drop(v_r_242);
    return v_env_240;
  }
  case TAG_EMatch: {
    heff_take_n(v_e_241, 0ULL, 2);
    heff_drop(v_r_242);
    return v_env_240;
  }
  case TAG_EPrim: {
    heff_take_n(v_e_241, 0ULL, 1);
    heff_drop(v_r_242);
    return v_env_240;
  }
  case TAG_EPrimCall: {
    V v_p_2424 = heff_field(v_e_241, 0);
    V v_e2_2425 = heff_field(v_e_241, 1);
    V v_ru_24e_241_24EPrimCall = heff_take_reuse_n(v_e_241, 3ULL, 2);
    switch (heff_tag_of(v_e2_2425)) {
    case TAG_Nil: {
      heff_drop(v_r_242);
      heff_drop(v_p_2424);
      heff_drop_cell(v_ru_24e_241_24EPrimCall, 2);
      return v_env_240;
    }
    case TAG_Cons: {
      V v_e21_2426 = heff_field(v_e2_2425, 0);
      V v_e22_2427 = heff_field(v_e2_2425, 1);
      heff_take_n(v_e2_2425, 3ULL, 2);
      switch (heff_tag_of(v_e21_2426)) {
      case TAG_EVar: {
        V v_x_2428 = heff_field(v_e21_2426, 0);
        V v_ru_24e21_2426_24EVar = heff_take_reuse_n(v_e21_2426, 1ULL, 1);
        switch (heff_tag_of(v_e22_2427)) {
        case TAG_Nil: {
          heff_drop(v_r_242);
          heff_drop(v_p_2424);
          heff_drop_cell(v_ru_24e_241_24EPrimCall, 2);
          heff_drop(v_x_2428);
          heff_drop_cell(v_ru_24e21_2426_24EVar, 1);
          return v_env_240;
        }
        case TAG_Cons: {
          V v_e221_2429 = heff_field(v_e22_2427, 0);
          V v_e222_2430 = heff_field(v_e22_2427, 1);
          heff_take_n(v_e22_2427, 3ULL, 2);
          switch (heff_tag_of(v_e221_2429)) {
          case TAG_EVar: {
            V v_y_2431 = heff_field(v_e221_2429, 0);
            V v_ru_24e221_2429_24EVar = heff_take_reuse_n(v_e221_2429, 1ULL, 1);
            switch (heff_tag_of(v_e222_2430)) {
            case TAG_Nil: {
              V v_t_2432;
              switch (heff_tag_of(v_p_2424)) {
              case TAG_IntMul: {
                v_t_2432 = NTAG(TAG_True);
                break;
              }
              case TAG_WordMul: {
                v_t_2432 = NTAG(TAG_True);
                break;
              }
              default: {
                heff_drop(v_p_2424);
                v_t_2432 = NTAG(TAG_False);
                break;
              }
              }
              if (((heff_dup(v_t_2432) == NTAG(TAG_True)) && heff_strEq_c_lent(v_x_2428, v_y_2431, 0))) {
                heff_drop(v_y_2431);
                heff_drop(v_t_2432);
                V v_env_2433 = v_env_240;
                V v_x_2434 = v_x_2428;
                V v_x3_2437;
                switch (heff_tag_of(v_r_242)) {
                case TAG_Unreached: {
                  v_x3_2437 = NTAG(TAG_Nothing);
                  break;
                }
                case TAG_Within: {
                  V v_hi_2436 = heff_field(v_r_242, 1);
                  heff_take_n(v_r_242, 2ULL, 2);
                  v_x3_2437 = v_hi_2436;
                  break;
                }
                default: heff_nomatch(v_r_242);
                }
                switch (heff_tag_of(v_x3_2437)) {
                case TAG_Nothing: {
                  heff_drop_cell(v_ru_24e_241_24EPrimCall, 2);
                  heff_drop_cell(v_ru_24e21_2426_24EVar, 1);
                  heff_drop_cell(v_ru_24e221_2429_24EVar, 1);
                  heff_drop(v_x_2434);
                  return v_env_2433;
                }
                case TAG_Just: {
                  V v_h_2438 = heff_field(v_x3_2437, 0);
                  heff_take_n(v_x3_2437, 1ULL, 1);
                  if (heff_intLe_c_lent(MK_INT(0LL), v_h_2438, 1)) {
                    HeffT2 v_t_2439 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(heff_rfield(v_env_2433, 0), v_x_2434));
                    V v_t_2443;
                    {
                      V v_field_2441 = v_t_2439.f[1];
                      int64_t v_tag_2440 = ((int64_t)v_t_2439.f[0]);
                      if ((v_tag_2440 == ((int64_t)0ULL))) {
                        V v_x_2442 = v_field_2441;
                        v_t_2443 = v_x_2442;
                      } else {
                        heff_drop(v_field_2441);
                        v_t_2443 = heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get());
                      }
                    }
                    V v_t_2444;
                    if (heff_intLt_c_lent(v_h_2438, MK_INT(2LL), 2)) {
                      v_t_2444 = heff_dup(v_h_2438);
                    } else {
                      v_t_2444 = heff_intAdd(heff_intDiv(heff_dup(v_h_2438), MK_INT(2LL)), MK_INT(1LL));
                    }
                    V v_t_2445 = (g_heff_2ecompile_2eranges_2erootGo(heff_dup(v_h_2438), MK_INT(0LL), v_t_2444));
                    V v_t_2446 = heff_tag_at_n(v_ru_24e21_2426_24EVar, TAG_Just, 1, (V[]){heff_intSub(MK_INT(0LL), v_t_2445)});
                    V v_t_2447;
                    if (heff_intLt_c_lent(v_h_2438, MK_INT(2LL), 2)) {
                      v_t_2447 = heff_dup(v_h_2438);
                    } else {
                      v_t_2447 = heff_intAdd(heff_intDiv(heff_dup(v_h_2438), MK_INT(2LL)), MK_INT(1LL));
                    }
                    V v_t_2448 = (g_heff_2ecompile_2eranges_2erootGo(v_h_2438, MK_INT(0LL), v_t_2447));
                    V v_t_2449 = heff_tag_at_n(v_ru_24e_241_24EPrimCall, TAG_Within, 2, (V[]){v_t_2446, heff_tag_at_n(v_ru_24e221_2429_24EVar, TAG_Just, 1, (V[]){v_t_2448})});
                    V v_t_2450 = (g_heff_2ecompile_2eranges_2emeet(v_t_2443, v_t_2449));
                    HEFF_LAST return g_heff_2ecompile_2eranges_2ewithRange(v_env_2433, v_x_2434, v_t_2450);
                  } else {
                    heff_drop_cell(v_ru_24e_241_24EPrimCall, 2);
                    heff_drop_cell(v_ru_24e21_2426_24EVar, 1);
                    heff_drop_cell(v_ru_24e221_2429_24EVar, 1);
                    heff_drop(v_x_2434);
                    heff_drop(v_h_2438);
                    return v_env_2433;
                  }
                }
                default: return heff_nomatch(v_x3_2437);
                }
              } else {
                heff_drop(v_r_242);
                heff_drop_cell(v_ru_24e_241_24EPrimCall, 2);
                heff_drop(v_x_2428);
                heff_drop_cell(v_ru_24e21_2426_24EVar, 1);
                heff_drop(v_y_2431);
                heff_drop_cell(v_ru_24e221_2429_24EVar, 1);
                heff_drop(v_t_2432);
                return v_env_240;
              }
            }
            case TAG_Cons: {
              heff_take_n(v_e222_2430, 0ULL, 2);
              heff_drop(v_r_242);
              heff_drop(v_p_2424);
              heff_drop_cell(v_ru_24e_241_24EPrimCall, 2);
              heff_drop(v_x_2428);
              heff_drop_cell(v_ru_24e21_2426_24EVar, 1);
              heff_drop(v_y_2431);
              heff_drop_cell(v_ru_24e221_2429_24EVar, 1);
              return v_env_240;
            }
            default: return heff_nomatch(v_e222_2430);
            }
          }
          case TAG_EGlobal: {
            heff_take_n(v_e221_2429, 0ULL, 1);
            heff_drop(v_r_242);
            heff_drop(v_p_2424);
            heff_drop_cell(v_ru_24e_241_24EPrimCall, 2);
            heff_drop(v_x_2428);
            heff_drop_cell(v_ru_24e21_2426_24EVar, 1);
            heff_drop(v_e222_2430);
            return v_env_240;
          }
          case TAG_ELam: {
            heff_take_n(v_e221_2429, 0ULL, 2);
            heff_drop(v_r_242);
            heff_drop(v_p_2424);
            heff_drop_cell(v_ru_24e_241_24EPrimCall, 2);
            heff_drop(v_x_2428);
            heff_drop_cell(v_ru_24e21_2426_24EVar, 1);
            heff_drop(v_e222_2430);
            return v_env_240;
          }
          case TAG_EApp: {
            heff_take_n(v_e221_2429, 0ULL, 2);
            heff_drop(v_r_242);
            heff_drop(v_p_2424);
            heff_drop_cell(v_ru_24e_241_24EPrimCall, 2);
            heff_drop(v_x_2428);
            heff_drop_cell(v_ru_24e21_2426_24EVar, 1);
            heff_drop(v_e222_2430);
            return v_env_240;
          }
          case TAG_ELet: {
            heff_take_n(v_e221_2429, 0ULL, 3);
            heff_drop(v_r_242);
            heff_drop(v_p_2424);
            heff_drop_cell(v_ru_24e_241_24EPrimCall, 2);
            heff_drop(v_x_2428);
            heff_drop_cell(v_ru_24e21_2426_24EVar, 1);
            heff_drop(v_e222_2430);
            return v_env_240;
          }
          case TAG_ERecord: {
            heff_take_n(v_e221_2429, 0ULL, 2);
            heff_drop(v_r_242);
            heff_drop(v_p_2424);
            heff_drop_cell(v_ru_24e_241_24EPrimCall, 2);
            heff_drop(v_x_2428);
            heff_drop_cell(v_ru_24e21_2426_24EVar, 1);
            heff_drop(v_e222_2430);
            return v_env_240;
          }
          case TAG_EProj: {
            heff_take_n(v_e221_2429, 0ULL, 4);
            heff_drop(v_r_242);
            heff_drop(v_p_2424);
            heff_drop_cell(v_ru_24e_241_24EPrimCall, 2);
            heff_drop(v_x_2428);
            heff_drop_cell(v_ru_24e21_2426_24EVar, 1);
            heff_drop(v_e222_2430);
            return v_env_240;
          }
          case TAG_ETag: {
            heff_take_n(v_e221_2429, 0ULL, 3);
            heff_drop(v_r_242);
            heff_drop(v_p_2424);
            heff_drop_cell(v_ru_24e_241_24EPrimCall, 2);
            heff_drop(v_x_2428);
            heff_drop_cell(v_ru_24e21_2426_24EVar, 1);
            heff_drop(v_e222_2430);
            return v_env_240;
          }
          case TAG_EMatch: {
            heff_take_n(v_e221_2429, 0ULL, 2);
            heff_drop(v_r_242);
            heff_drop(v_p_2424);
            heff_drop_cell(v_ru_24e_241_24EPrimCall, 2);
            heff_drop(v_x_2428);
            heff_drop_cell(v_ru_24e21_2426_24EVar, 1);
            heff_drop(v_e222_2430);
            return v_env_240;
          }
          case TAG_EPrim: {
            heff_take_n(v_e221_2429, 0ULL, 1);
            heff_drop(v_r_242);
            heff_drop(v_p_2424);
            heff_drop_cell(v_ru_24e_241_24EPrimCall, 2);
            heff_drop(v_x_2428);
            heff_drop_cell(v_ru_24e21_2426_24EVar, 1);
            heff_drop(v_e222_2430);
            return v_env_240;
          }
          case TAG_EPrimCall: {
            heff_take_n(v_e221_2429, 0ULL, 2);
            heff_drop(v_r_242);
            heff_drop(v_p_2424);
            heff_drop_cell(v_ru_24e_241_24EPrimCall, 2);
            heff_drop(v_x_2428);
            heff_drop_cell(v_ru_24e21_2426_24EVar, 1);
            heff_drop(v_e222_2430);
            return v_env_240;
          }
          case TAG_ECall: {
            heff_take_n(v_e221_2429, 0ULL, 2);
            heff_drop(v_r_242);
            heff_drop(v_p_2424);
            heff_drop_cell(v_ru_24e_241_24EPrimCall, 2);
            heff_drop(v_x_2428);
            heff_drop_cell(v_ru_24e21_2426_24EVar, 1);
            heff_drop(v_e222_2430);
            return v_env_240;
          }
          case TAG_EInt: {
            heff_take_n(v_e221_2429, 0ULL, 1);
            heff_drop(v_r_242);
            heff_drop(v_p_2424);
            heff_drop_cell(v_ru_24e_241_24EPrimCall, 2);
            heff_drop(v_x_2428);
            heff_drop_cell(v_ru_24e21_2426_24EVar, 1);
            heff_drop(v_e222_2430);
            return v_env_240;
          }
          case TAG_EFloat: {
            heff_take_nf(v_e221_2429, 0ULL, 1);
            heff_drop(v_r_242);
            heff_drop(v_p_2424);
            heff_drop_cell(v_ru_24e_241_24EPrimCall, 2);
            heff_drop(v_x_2428);
            heff_drop_cell(v_ru_24e21_2426_24EVar, 1);
            heff_drop(v_e222_2430);
            return v_env_240;
          }
          case TAG_EStr: {
            heff_take_n(v_e221_2429, 0ULL, 1);
            heff_drop(v_r_242);
            heff_drop(v_p_2424);
            heff_drop_cell(v_ru_24e_241_24EPrimCall, 2);
            heff_drop(v_x_2428);
            heff_drop_cell(v_ru_24e21_2426_24EVar, 1);
            heff_drop(v_e222_2430);
            return v_env_240;
          }
          case TAG_EBytes: {
            heff_take_n(v_e221_2429, 0ULL, 1);
            heff_drop(v_r_242);
            heff_drop(v_p_2424);
            heff_drop_cell(v_ru_24e_241_24EPrimCall, 2);
            heff_drop(v_x_2428);
            heff_drop_cell(v_ru_24e21_2426_24EVar, 1);
            heff_drop(v_e222_2430);
            return v_env_240;
          }
          case TAG_EFixed: {
            heff_take_n(v_e221_2429, 0ULL, 2);
            heff_drop(v_r_242);
            heff_drop(v_p_2424);
            heff_drop_cell(v_ru_24e_241_24EPrimCall, 2);
            heff_drop(v_x_2428);
            heff_drop_cell(v_ru_24e21_2426_24EVar, 1);
            heff_drop(v_e222_2430);
            return v_env_240;
          }
          case TAG_EFloat32: {
            heff_take_na(v_e221_2429, 0ULL, 1);
            heff_drop(v_r_242);
            heff_drop(v_p_2424);
            heff_drop_cell(v_ru_24e_241_24EPrimCall, 2);
            heff_drop(v_x_2428);
            heff_drop_cell(v_ru_24e21_2426_24EVar, 1);
            heff_drop(v_e222_2430);
            return v_env_240;
          }
          case TAG_EAbandon: {
            heff_drop(v_r_242);
            heff_drop(v_p_2424);
            heff_drop_cell(v_ru_24e_241_24EPrimCall, 2);
            heff_drop(v_x_2428);
            heff_drop_cell(v_ru_24e21_2426_24EVar, 1);
            heff_drop(v_e222_2430);
            return v_env_240;
          }
          case TAG_EBool: {
            heff_take_n(v_e221_2429, 0ULL, 1);
            heff_drop(v_r_242);
            heff_drop(v_p_2424);
            heff_drop_cell(v_ru_24e_241_24EPrimCall, 2);
            heff_drop(v_x_2428);
            heff_drop_cell(v_ru_24e21_2426_24EVar, 1);
            heff_drop(v_e222_2430);
            return v_env_240;
          }
          case TAG_ESet: {
            heff_take_n(v_e221_2429, 0ULL, 3);
            heff_drop(v_r_242);
            heff_drop(v_p_2424);
            heff_drop_cell(v_ru_24e_241_24EPrimCall, 2);
            heff_drop(v_x_2428);
            heff_drop_cell(v_ru_24e21_2426_24EVar, 1);
            heff_drop(v_e222_2430);
            return v_env_240;
          }
          case TAG_EValues: {
            heff_take_n(v_e221_2429, 0ULL, 1);
            heff_drop(v_r_242);
            heff_drop(v_p_2424);
            heff_drop_cell(v_ru_24e_241_24EPrimCall, 2);
            heff_drop(v_x_2428);
            heff_drop_cell(v_ru_24e21_2426_24EVar, 1);
            heff_drop(v_e222_2430);
            return v_env_240;
          }
          case TAG_EFix: {
            heff_take_n(v_e221_2429, 0ULL, 2);
            heff_drop(v_r_242);
            heff_drop(v_p_2424);
            heff_drop_cell(v_ru_24e_241_24EPrimCall, 2);
            heff_drop(v_x_2428);
            heff_drop_cell(v_ru_24e21_2426_24EVar, 1);
            heff_drop(v_e222_2430);
            return v_env_240;
          }
          default: return heff_nomatch(v_e221_2429);
          }
        }
        default: return heff_nomatch(v_e22_2427);
        }
      }
      case TAG_EGlobal: {
        heff_take_n(v_e21_2426, 0ULL, 1);
        heff_drop(v_r_242);
        heff_drop(v_p_2424);
        heff_drop_cell(v_ru_24e_241_24EPrimCall, 2);
        heff_drop(v_e22_2427);
        return v_env_240;
      }
      case TAG_ELam: {
        heff_take_n(v_e21_2426, 0ULL, 2);
        heff_drop(v_r_242);
        heff_drop(v_p_2424);
        heff_drop_cell(v_ru_24e_241_24EPrimCall, 2);
        heff_drop(v_e22_2427);
        return v_env_240;
      }
      case TAG_EApp: {
        heff_take_n(v_e21_2426, 0ULL, 2);
        heff_drop(v_r_242);
        heff_drop(v_p_2424);
        heff_drop_cell(v_ru_24e_241_24EPrimCall, 2);
        heff_drop(v_e22_2427);
        return v_env_240;
      }
      case TAG_ELet: {
        heff_take_n(v_e21_2426, 0ULL, 3);
        heff_drop(v_r_242);
        heff_drop(v_p_2424);
        heff_drop_cell(v_ru_24e_241_24EPrimCall, 2);
        heff_drop(v_e22_2427);
        return v_env_240;
      }
      case TAG_ERecord: {
        heff_take_n(v_e21_2426, 0ULL, 2);
        heff_drop(v_r_242);
        heff_drop(v_p_2424);
        heff_drop_cell(v_ru_24e_241_24EPrimCall, 2);
        heff_drop(v_e22_2427);
        return v_env_240;
      }
      case TAG_EProj: {
        heff_take_n(v_e21_2426, 0ULL, 4);
        heff_drop(v_r_242);
        heff_drop(v_p_2424);
        heff_drop_cell(v_ru_24e_241_24EPrimCall, 2);
        heff_drop(v_e22_2427);
        return v_env_240;
      }
      case TAG_ETag: {
        heff_take_n(v_e21_2426, 0ULL, 3);
        heff_drop(v_r_242);
        heff_drop(v_p_2424);
        heff_drop_cell(v_ru_24e_241_24EPrimCall, 2);
        heff_drop(v_e22_2427);
        return v_env_240;
      }
      case TAG_EMatch: {
        heff_take_n(v_e21_2426, 0ULL, 2);
        heff_drop(v_r_242);
        heff_drop(v_p_2424);
        heff_drop_cell(v_ru_24e_241_24EPrimCall, 2);
        heff_drop(v_e22_2427);
        return v_env_240;
      }
      case TAG_EPrim: {
        heff_take_n(v_e21_2426, 0ULL, 1);
        heff_drop(v_r_242);
        heff_drop(v_p_2424);
        heff_drop_cell(v_ru_24e_241_24EPrimCall, 2);
        heff_drop(v_e22_2427);
        return v_env_240;
      }
      case TAG_EPrimCall: {
        heff_take_n(v_e21_2426, 0ULL, 2);
        heff_drop(v_r_242);
        heff_drop(v_p_2424);
        heff_drop_cell(v_ru_24e_241_24EPrimCall, 2);
        heff_drop(v_e22_2427);
        return v_env_240;
      }
      case TAG_ECall: {
        heff_take_n(v_e21_2426, 0ULL, 2);
        heff_drop(v_r_242);
        heff_drop(v_p_2424);
        heff_drop_cell(v_ru_24e_241_24EPrimCall, 2);
        heff_drop(v_e22_2427);
        return v_env_240;
      }
      case TAG_EInt: {
        heff_take_n(v_e21_2426, 0ULL, 1);
        heff_drop(v_r_242);
        heff_drop(v_p_2424);
        heff_drop_cell(v_ru_24e_241_24EPrimCall, 2);
        heff_drop(v_e22_2427);
        return v_env_240;
      }
      case TAG_EFloat: {
        heff_take_nf(v_e21_2426, 0ULL, 1);
        heff_drop(v_r_242);
        heff_drop(v_p_2424);
        heff_drop_cell(v_ru_24e_241_24EPrimCall, 2);
        heff_drop(v_e22_2427);
        return v_env_240;
      }
      case TAG_EStr: {
        heff_take_n(v_e21_2426, 0ULL, 1);
        heff_drop(v_r_242);
        heff_drop(v_p_2424);
        heff_drop_cell(v_ru_24e_241_24EPrimCall, 2);
        heff_drop(v_e22_2427);
        return v_env_240;
      }
      case TAG_EBytes: {
        heff_take_n(v_e21_2426, 0ULL, 1);
        heff_drop(v_r_242);
        heff_drop(v_p_2424);
        heff_drop_cell(v_ru_24e_241_24EPrimCall, 2);
        heff_drop(v_e22_2427);
        return v_env_240;
      }
      case TAG_EFixed: {
        heff_take_n(v_e21_2426, 0ULL, 2);
        heff_drop(v_r_242);
        heff_drop(v_p_2424);
        heff_drop_cell(v_ru_24e_241_24EPrimCall, 2);
        heff_drop(v_e22_2427);
        return v_env_240;
      }
      case TAG_EFloat32: {
        heff_take_na(v_e21_2426, 0ULL, 1);
        heff_drop(v_r_242);
        heff_drop(v_p_2424);
        heff_drop_cell(v_ru_24e_241_24EPrimCall, 2);
        heff_drop(v_e22_2427);
        return v_env_240;
      }
      case TAG_EAbandon: {
        heff_drop(v_r_242);
        heff_drop(v_p_2424);
        heff_drop_cell(v_ru_24e_241_24EPrimCall, 2);
        heff_drop(v_e22_2427);
        return v_env_240;
      }
      case TAG_EBool: {
        heff_take_n(v_e21_2426, 0ULL, 1);
        heff_drop(v_r_242);
        heff_drop(v_p_2424);
        heff_drop_cell(v_ru_24e_241_24EPrimCall, 2);
        heff_drop(v_e22_2427);
        return v_env_240;
      }
      case TAG_ESet: {
        heff_take_n(v_e21_2426, 0ULL, 3);
        heff_drop(v_r_242);
        heff_drop(v_p_2424);
        heff_drop_cell(v_ru_24e_241_24EPrimCall, 2);
        heff_drop(v_e22_2427);
        return v_env_240;
      }
      case TAG_EValues: {
        heff_take_n(v_e21_2426, 0ULL, 1);
        heff_drop(v_r_242);
        heff_drop(v_p_2424);
        heff_drop_cell(v_ru_24e_241_24EPrimCall, 2);
        heff_drop(v_e22_2427);
        return v_env_240;
      }
      case TAG_EFix: {
        heff_take_n(v_e21_2426, 0ULL, 2);
        heff_drop(v_r_242);
        heff_drop(v_p_2424);
        heff_drop_cell(v_ru_24e_241_24EPrimCall, 2);
        heff_drop(v_e22_2427);
        return v_env_240;
      }
      default: return heff_nomatch(v_e21_2426);
      }
    }
    default: return heff_nomatch(v_e2_2425);
    }
  }
  case TAG_ECall: {
    heff_take_n(v_e_241, 0ULL, 2);
    heff_drop(v_r_242);
    return v_env_240;
  }
  case TAG_EInt: {
    heff_take_n(v_e_241, 0ULL, 1);
    heff_drop(v_r_242);
    return v_env_240;
  }
  case TAG_EFloat: {
    heff_take_nf(v_e_241, 0ULL, 1);
    heff_drop(v_r_242);
    return v_env_240;
  }
  case TAG_EStr: {
    heff_take_n(v_e_241, 0ULL, 1);
    heff_drop(v_r_242);
    return v_env_240;
  }
  case TAG_EBytes: {
    heff_take_n(v_e_241, 0ULL, 1);
    heff_drop(v_r_242);
    return v_env_240;
  }
  case TAG_EFixed: {
    heff_take_n(v_e_241, 0ULL, 2);
    heff_drop(v_r_242);
    return v_env_240;
  }
  case TAG_EFloat32: {
    heff_take_na(v_e_241, 0ULL, 1);
    heff_drop(v_r_242);
    return v_env_240;
  }
  case TAG_EAbandon: {
    heff_drop(v_r_242);
    return v_env_240;
  }
  case TAG_EBool: {
    heff_take_n(v_e_241, 0ULL, 1);
    heff_drop(v_r_242);
    return v_env_240;
  }
  case TAG_ESet: {
    heff_take_n(v_e_241, 0ULL, 3);
    heff_drop(v_r_242);
    return v_env_240;
  }
  case TAG_EValues: {
    heff_take_n(v_e_241, 0ULL, 1);
    heff_drop(v_r_242);
    return v_env_240;
  }
  case TAG_EFix: {
    heff_take_n(v_e_241, 0ULL, 2);
    heff_drop(v_r_242);
    return v_env_240;
  }
  default: return heff_nomatch(v_e_241);
  }
}
V g_heff_2ecompile_2eranges_2enarrowTo_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eranges_2enarrowTo(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2eranges_2emarkRange_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eranges_2emarkRange_entry, 2, 0};

V g_heff_2ecompile_2eranges_2emarkRange(V v_ms_240, V v_r_241) {
top: ;
  switch (heff_tag_of(v_r_241)) {
  case TAG_Unreached: {
    return v_ms_240;
  }
  case TAG_Within: {
    V v_r1_242 = heff_field(v_r_241, 0);
    V v_r2_243 = heff_field(v_r_241, 1);
    switch (heff_tag_of(v_r1_242)) {
    case TAG_Nothing: {
      return v_ms_240;
    }
    case TAG_Just: {
      V v_lo_244 = heff_field(v_r1_242, 0);
      switch (heff_tag_of(v_r2_243)) {
      case TAG_Nothing: {
        return v_ms_240;
      }
      case TAG_Just: {
        V v_hi_245 = heff_field(v_r2_243, 0);
        if (heff_intEq_c_lent(v_lo_244, v_hi_245, 0)) {
          V v_t_246 = (g_std_2eordmap_2einsert_24s1703101629x493626677(v_ms_240, heff_intAdd(heff_dup(v_lo_244), MK_INT(1LL)), NTAG(TAG_MkUnit)));
          V v_t_247 = (g_std_2eordmap_2einsert_24s1703101629x493626677(v_t_246, heff_dup(v_lo_244), NTAG(TAG_MkUnit)));
          return (g_std_2eordmap_2einsert_24s1703101629x493626677(v_t_247, heff_intSub(heff_dup(v_lo_244), MK_INT(1LL)), NTAG(TAG_MkUnit)));
        } else {
          return v_ms_240;
        }
      }
      default: return heff_nomatch(v_r2_243);
      }
    }
    default: return heff_nomatch(v_r1_242);
    }
  }
  default: return heff_nomatch(v_r_241);
  }
}
V g_heff_2ecompile_2eranges_2emarkRange_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2eranges_2emarkRange(a[0], a1); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ecompile_2eranges_2egatherArms_24cpr_str0, 4, "True");
HEFF_LIT(g_heff_2ecompile_2eranges_2egatherArms_24cpr_str1, 5, "False");
V g_heff_2ecompile_2eranges_2egatherArms_24cpr_lam0(V self, V *args);

HeffT3 g_heff_2ecompile_2eranges_2egatherArms_24cpr(V v_c_240, V v_go_241, V v_env_242, V v_t_243, V v_st_244, V v_x6_245) {
top: ;
  switch (heff_tag_of(v_x6_245)) {
  case TAG_Nil: {
    heff_drop(v_c_240);
    heff_drop(v_go_241);
    heff_drop(v_env_242);
    return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), NTAG(TAG_Unreached), v_st_244}});
  }
  case TAG_Cons: {
    V v_x61_246 = heff_field(v_x6_245, 0);
    V v_rest_247 = heff_field(v_x6_245, 1);
    switch (heff_tag_of(v_x61_246)) {
    case TAG_MkArm: {
      V v_tag_248 = heff_field(v_x61_246, 0);
      V v_b_2410 = heff_field(v_x61_246, 2);
      V v_t_2412;
      switch (heff_tag_of(v_t_243)) {
      case TAG_Nothing: {
        v_t_2412 = heff_dup(v_env_242);
        break;
      }
      case TAG_Just: {
        V v_k_2411 = heff_field(v_t_243, 0);
        if (heff_strEq_c_lent(v_tag_248, ((V)&g_heff_2ecompile_2eranges_2egatherArms_24cpr_str0), 2)) {
          v_t_2412 = (g_heff_2ecompile_2eranges_2econdRefine(heff_dup(v_c_240), heff_dup(v_env_242), v_k_2411, NTAG(TAG_True)));
        } else {
          if (heff_strEq_c_lent(v_tag_248, ((V)&g_heff_2ecompile_2eranges_2egatherArms_24cpr_str1), 2)) {
            v_t_2412 = (g_heff_2ecompile_2eranges_2econdRefine(heff_dup(v_c_240), heff_dup(v_env_242), v_k_2411, NTAG(TAG_False)));
          } else {
            v_t_2412 = heff_dup(v_env_242);
          }
        }
        break;
      }
      default: heff_nomatch(v_t_243);
      }
      V v_x1_2413 = heff_tr(heff_call(heff_dup(v_go_241), 3, (V[]){v_t_2412, v_st_244, heff_dup(v_b_2410)}));
      V v_k_2415 = heff_clo_n(g_heff_2ecompile_2eranges_2egatherArms_24cpr_lam0, 1, 5, (V[]){v_c_240, v_go_241, v_env_242, heff_dup(v_t_243), heff_dup(v_rest_247)});
      switch (heff_tag_of(v_x1_2413)) {
      case TAG_MkSeen: {
        V v_r_2416 = heff_field(v_x1_2413, 0);
        V v_st_2417 = heff_field(v_x1_2413, 1);
        heff_take_n(v_x1_2413, 3ULL, 2);
        V v_x2_2418 = heff_tr(heff_call(v_k_2415, 1, (V[]){v_st_2417}));
        switch (heff_tag_of(v_x2_2418)) {
        case TAG_MkSeen: {
          V v_rr_2419 = heff_field(v_x2_2418, 0);
          V v_st_2420 = heff_field(v_x2_2418, 1);
          heff_take_n(v_x2_2418, 3ULL, 2);
          V v_f_2421 = (g_heff_2ecompile_2eranges_2ejoin(v_r_2416, v_rr_2419));
          return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), v_f_2421, v_st_2420}});
        }
        case TAG_MkSeenVals: {
          V v_qs_2422 = heff_field(v_x2_2418, 0);
          V v_st_2423 = heff_field(v_x2_2418, 1);
          heff_take_n(v_x2_2418, 3ULL, 2);
          switch (heff_tag_of(v_r_2416)) {
          case TAG_Unreached: {
            return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), v_qs_2422, v_st_2423}});
          }
          case TAG_Within: {
            heff_take_n(v_r_2416, 0ULL, 2);
            heff_drop(v_qs_2422);
            return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get()), v_st_2423}});
          }
          default: return ((HeffT3){{heff_nomatch(v_r_2416)}});
          }
        }
        default: return ((HeffT3){{heff_nomatch(v_x2_2418)}});
        }
      }
      case TAG_MkSeenVals: {
        V v_rs_2426 = heff_field(v_x1_2413, 0);
        V v_st_2427 = heff_field(v_x1_2413, 1);
        heff_take_n(v_x1_2413, 3ULL, 2);
        V v_x2_2428 = heff_tr(heff_call(v_k_2415, 1, (V[]){v_st_2427}));
        switch (heff_tag_of(v_x2_2428)) {
        case TAG_MkSeen: {
          V v_r_2429 = heff_field(v_x2_2428, 0);
          V v_st_2430 = heff_field(v_x2_2428, 1);
          heff_take_n(v_x2_2428, 3ULL, 2);
          switch (heff_tag_of(v_r_2429)) {
          case TAG_Unreached: {
            return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), v_rs_2426, v_st_2430}});
          }
          case TAG_Within: {
            heff_take_n(v_r_2429, 0ULL, 2);
            heff_drop(v_rs_2426);
            return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get()), v_st_2430}});
          }
          default: return ((HeffT3){{heff_nomatch(v_r_2429)}});
          }
        }
        case TAG_MkSeenVals: {
          V v_qs_2433 = heff_field(v_x2_2428, 0);
          V v_st_2434 = heff_field(v_x2_2428, 1);
          heff_take_n(v_x2_2428, 3ULL, 2);
          V v_f_2435 = (g_list_2ezipWith_24s1026658656x682908126(v_rs_2426, v_qs_2433));
          return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), v_f_2435, v_st_2434}});
        }
        default: return ((HeffT3){{heff_nomatch(v_x2_2428)}});
        }
      }
      default: return ((HeffT3){{heff_nomatch(v_x1_2413)}});
      }
    }
    default: return ((HeffT3){{heff_nomatch(v_x61_246)}});
    }
  }
  default: return ((HeffT3){{heff_nomatch(v_x6_245)}});
  }
}
V g_heff_2ecompile_2eranges_2egatherArms_24cpr_lam0(V self, V *args) {
  V v_st1_2414 = args[0];
  V v_c_240 = heff_env(self)[0];
  V v_go_241 = heff_env(self)[1];
  V v_env_242 = heff_env(self)[2];
  V v_t_243 = heff_env(self)[3];
  V v_rest_247 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return ({ V a_0 = v_c_240; V a_1 = v_go_241; V a_2 = v_env_242; V a_3 = v_t_243; V a_4 = v_st1_2414; V a_5 = v_rest_247; V r_ = (g_heff_2ecompile_2eranges_2egatherArms(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_t_243); heff_drop(v_rest_247); r_; });
}
V g_heff_2ecompile_2eranges_2egatherCond_lam0(V self, V *args);
Clo g_heff_2ecompile_2eranges_2egatherCond_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eranges_2egatherCond_entry, 5, 0};

V g_heff_2ecompile_2eranges_2egatherCond(V v_c_240, V v_go_241, V v_env_242, V v_st_243, V v_x5_244) {
top: ;
  switch (heff_tag_of(v_x5_244)) {
  case TAG_CTrue: {
    heff_drop(v_c_240);
    heff_drop(v_go_241);
    heff_drop(v_env_242);
    return v_st_243;
  }
  case TAG_CFalse: {
    heff_drop(v_c_240);
    heff_drop(v_go_241);
    heff_drop(v_env_242);
    return v_st_243;
  }
  case TAG_CRel: {
    V v_p_245 = heff_field(v_x5_244, 0);
    V v_a_246 = heff_field(v_x5_244, 1);
    V v_b_247 = heff_field(v_x5_244, 2);
    V v_ru_24x5_244_24CRel = heff_take_reuse_n(v_x5_244, 7ULL, 3);
    V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_b_247), NTAG(TAG_Nil)});
    HeffT2 v_t_249 = (g_heff_2ecompile_2eranges_2egatherMany_24cpr(v_go_241, heff_dup(v_env_242), v_st_243, heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_a_246), v_t_248})));
    {
      V v_field_2410 = v_t_249.f[0];
      V v_field_2411 = v_t_249.f[1];
      V v_rs_2412 = v_field_2410;
      heff_drop(v_rs_2412);
      V v_st_2413 = v_field_2411;
      V v_lit_2414 = v_p_245;
      V v_lit_2415 = v_a_246;
      V v_lit_2416 = v_b_247;
      V v_c_2417 = v_c_240;
      V v_env_2418 = v_env_242;
      V v_st_2419 = v_st_2413;
      V v_t_2432;
      if (!(heff_dup(heff_rfield(v_c_2417, 2)) == NTAG(TAG_True))) {
        heff_drop_cell(v_ru_24x5_244_24CRel, 3);
        heff_drop(v_lit_2414);
        heff_drop(v_lit_2415);
        heff_drop(v_lit_2416);
        heff_drop_rec(v_c_2417, 3);
        heff_drop(v_env_2418);
        v_t_2432 = v_st_2419;
      } else {
        V v_t_2420;
        switch (heff_tag_of(v_lit_2414)) {
        case TAG_WordEq: {
          v_t_2420 = NTAG(TAG_IntEq);
          break;
        }
        case TAG_WordLt: {
          v_t_2420 = NTAG(TAG_IntLt);
          break;
        }
        case TAG_WordLe: {
          v_t_2420 = NTAG(TAG_IntLe);
          break;
        }
        default: {
          v_t_2420 = heff_dup(v_lit_2414);
          break;
        }
        }
        V v_t_2421 = ({ V a_0 = v_t_2420; V r_ = (g_heff_2ecompile_2eranges_2eisIntRel(a_0)); heff_drop(v_t_2420); r_; });
        V v_t_2422;
        if ((heff_dup(v_t_2421) == NTAG(TAG_True))) {
          heff_drop(v_t_2421);
          v_t_2422 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x5_244_24CRel, TAG_MkTest, 3, (V[]){v_lit_2414, v_lit_2415, v_lit_2416}), NTAG(TAG_Nil)});
        } else {
          heff_drop_cell(v_ru_24x5_244_24CRel, 3);
          heff_drop(v_lit_2414);
          heff_drop(v_lit_2415);
          heff_drop(v_lit_2416);
          heff_drop(v_t_2421);
          v_t_2422 = NTAG(TAG_Nil);
        }
        v_t_2432 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2eranges_2egatherCond_lam0, 2, 2, (V[]){v_c_2417, v_env_2418}); V a_1 = v_st_2419; V a_2 = v_t_2422; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2422); r_; });
      }
      return v_t_2432;
    }
  }
  case TAG_CTest: {
    V v_e_2433 = heff_field(v_x5_244, 0);
    heff_take_n(v_x5_244, 1ULL, 1);
    heff_drop(v_c_240);
    V v_x1_2434 = heff_tr(heff_call(v_go_241, 3, (V[]){v_env_242, v_st_243, v_e_2433}));
    switch (heff_tag_of(v_x1_2434)) {
    case TAG_MkSeen: {
      V v_st_2436 = heff_field(v_x1_2434, 1);
      heff_take_n(v_x1_2434, 2ULL, 2);
      return v_st_2436;
    }
    case TAG_MkSeenVals: {
      V v_st_2438 = heff_field(v_x1_2434, 1);
      heff_take_n(v_x1_2434, 2ULL, 2);
      return v_st_2438;
    }
    default: return heff_nomatch(v_x1_2434);
    }
  }
  case TAG_CNot: {
    V v_k_2439 = heff_field(v_x5_244, 0);
    heff_take_n(v_x5_244, 1ULL, 1);
    V t_0 = v_c_240;
    V t_1 = v_go_241;
    V t_2 = v_env_242;
    V t_3 = v_st_243;
    V t_4 = v_k_2439;
    v_c_240 = t_0;
    v_go_241 = t_1;
    v_env_242 = t_2;
    v_st_243 = t_3;
    v_x5_244 = t_4;
    goto top;
  }
  case TAG_CIf: {
    V v_a_2440 = heff_field(v_x5_244, 0);
    V v_b_2441 = heff_field(v_x5_244, 1);
    V v_k_2442 = heff_field(v_x5_244, 2);
    heff_take_n(v_x5_244, 7ULL, 3);
    V v_t_2443 = (g_heff_2ecompile_2eranges_2econdRefine(heff_dup(v_c_240), heff_dup(v_env_242), v_a_2440, NTAG(TAG_False)));
    V v_t_2444 = (g_heff_2ecompile_2eranges_2econdRefine(heff_dup(v_c_240), heff_dup(v_env_242), v_a_2440, NTAG(TAG_True)));
    V v_t_2445 = (g_heff_2ecompile_2eranges_2egatherCond(heff_dup(v_c_240), heff_dup(v_go_241), v_env_242, v_st_243, v_a_2440));
    V v_t_2446 = (g_heff_2ecompile_2eranges_2egatherCond(heff_dup(v_c_240), heff_dup(v_go_241), v_t_2444, v_t_2445, v_b_2441));
    V t_0 = v_c_240;
    V t_1 = v_go_241;
    V t_2 = v_t_2443;
    V t_3 = v_t_2446;
    V t_4 = v_k_2442;
    v_c_240 = t_0;
    v_go_241 = t_1;
    v_env_242 = t_2;
    v_st_243 = t_3;
    v_x5_244 = t_4;
    goto top;
  }
  default: return heff_nomatch(v_x5_244);
  }
}
V g_heff_2ecompile_2eranges_2egatherCond_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eranges_2egatherCond(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ecompile_2eranges_2egatherCond_lam0(V self, V *args) {
  V v_st_2423 = args[0];
  V v_x4_2424 = args[1];
  V v_c_2417 = heff_env(self)[0];
  V v_env_2418 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_x4_2424)) {
  case TAG_MkTest: {
    V v_a_2426 = heff_field(v_x4_2424, 1);
    V v_b_2427 = heff_field(v_x4_2424, 2);
    heff_take_n(v_x4_2424, 6ULL, 3);
    V v_t_2428 = (g_heff_2ecompile_2eranges_2eoperandRange(heff_dup(v_c_2417), heff_dup(v_env_2418), v_a_2426));
    V v_t_2429 = ({ V a_0 = heff_take_field(v_st_2423, 1); V a_1 = v_t_2428; V r_ = (g_heff_2ecompile_2eranges_2emarkRange(a_0, a_1)); heff_drop(v_t_2428); r_; });
    V v_t_2430 = (g_heff_2ecompile_2eranges_2eoperandRange(v_c_2417, v_env_2418, v_b_2427));
    V v_t_2431 = ({ V a_0 = v_t_2429; V a_1 = v_t_2430; V r_ = (g_heff_2ecompile_2eranges_2emarkRange(a_0, a_1)); heff_drop(v_t_2430); r_; });
    return ({ V rv_1 = v_t_2431; V rr_ = heff_rec_reuse_nf(v_st_2423, 1ULL, 2, shape_calls__marks, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
  }
  default: return heff_nomatch(v_x4_2424);
  }
}
Clo g_heff_2ecompile_2eranges_2ewalkCond_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eranges_2ewalkCond_24dps_entry, 6, 0};

V g_heff_2ecompile_2eranges_2ewalkCond_24dps(V v_c_240, V v_go_241, V v_env_242, V v_x4_243, V v_d_244, V v_i_245) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_CTrue: {
    heff_drop(v_c_240);
    heff_drop(v_go_241);
    heff_drop(v_env_242);
    return heff_setField(v_d_244, v_i_245, v_x4_243);
  }
  case TAG_CFalse: {
    heff_drop(v_c_240);
    heff_drop(v_go_241);
    heff_drop(v_env_242);
    return heff_setField(v_d_244, v_i_245, v_x4_243);
  }
  case TAG_CRel: {
    V v_p_246 = heff_field(v_x4_243, 0);
    V v_a_247 = heff_field(v_x4_243, 1);
    V v_b_248 = heff_field(v_x4_243, 2);
    V v_ru_24x4_243_24CRel = heff_take_reuse_n(v_x4_243, 7ULL, 3);
    heff_drop(v_c_240);
    V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_b_248), NTAG(TAG_Nil)});
    HeffT2 v_t_2410 = (g_heff_2ecompile_2eranges_2ewalkMany_24cpr(v_go_241, v_env_242, heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_a_247), v_t_249})));
    V v_t_2427;
    {
      V v_field_2411 = v_t_2410.f[0];
      V v_field_2412 = v_t_2410.f[1];
      V v_rs_2413 = v_field_2411;
      V v_es_2414 = v_field_2412;
      switch (heff_tag_of(v_es_2414)) {
      case TAG_Nil: {
        heff_drop(v_rs_2413);
        v_t_2427 = heff_tag_n(TAG_EBool, 1, (V[]){heff_tag_at_n(v_ru_24x4_243_24CRel, TAG_CRel, 3, (V[]){v_p_246, v_a_247, v_b_248})});
        break;
      }
      case TAG_Cons: {
        V v_a2_2415 = heff_field(v_es_2414, 0);
        V v_it2_2416 = heff_field(v_es_2414, 1);
        heff_take_n(v_es_2414, 3ULL, 2);
        switch (heff_tag_of(v_it2_2416)) {
        case TAG_Nil: {
          heff_drop(v_rs_2413);
          heff_drop(v_a2_2415);
          v_t_2427 = heff_tag_n(TAG_EBool, 1, (V[]){heff_tag_at_n(v_ru_24x4_243_24CRel, TAG_CRel, 3, (V[]){v_p_246, v_a_247, v_b_248})});
          break;
        }
        case TAG_Cons: {
          V v_b2_2417 = heff_field(v_it2_2416, 0);
          V v_it22_2418 = heff_field(v_it2_2416, 1);
          heff_take_n(v_it2_2416, 3ULL, 2);
          switch (heff_tag_of(v_it22_2418)) {
          case TAG_Nil: {
            heff_drop(v_a_247);
            heff_drop(v_b_248);
            HeffT2 v_t_2419 = ({ V a_0 = v_p_246; V a_1 = v_rs_2413; V b_2 = heff_dup(g_heff_2ecompile_2eranges_2eanyRange_get()); HeffT2 r_ = (g_heff_2ecompile_2eranges_2ewordOf_24cpr(a_0, a_1, b_2)); heff_drop(v_rs_2413); heff_drop(b_2); r_; });
            V v_t_2423;
            {
              V v_field_2421 = v_t_2419.f[1];
              int64_t v_tag_2420 = ((int64_t)v_t_2419.f[0]);
              if ((v_tag_2420 == ((int64_t)0ULL))) {
                heff_drop(v_p_246);
                V v_x_2422 = v_field_2421;
                v_t_2423 = v_x_2422;
              } else {
                heff_drop(v_field_2421);
                v_t_2423 = v_p_246;
              }
            }
            V v_t_2424 = heff_tag_n(TAG_EBool, 1, (V[]){heff_tag_at_n(v_ru_24x4_243_24CRel, TAG_CRel, 3, (V[]){v_t_2423, v_a2_2415, v_b2_2417})});
            v_t_2427 = v_t_2424;
            break;
          }
          case TAG_Cons: {
            heff_take_n(v_it22_2418, 0ULL, 2);
            heff_drop(v_rs_2413);
            heff_drop(v_a2_2415);
            heff_drop(v_b2_2417);
            v_t_2427 = heff_tag_n(TAG_EBool, 1, (V[]){heff_tag_at_n(v_ru_24x4_243_24CRel, TAG_CRel, 3, (V[]){v_p_246, v_a_247, v_b_248})});
            break;
          }
          default: heff_nomatch(v_it22_2418);
          }
          break;
        }
        default: heff_nomatch(v_it2_2416);
        }
        break;
      }
      default: heff_nomatch(v_es_2414);
      }
    }
    V v_t_2428 = (g_heff_2ecompile_2eir_2econdOf(v_t_2427));
    return heff_setField(v_d_244, v_i_245, v_t_2428);
  }
  case TAG_CTest: {
    V v_e_2429 = heff_field(v_x4_243, 0);
    heff_take_n(v_x4_243, 1ULL, 1);
    heff_drop(v_c_240);
    V v_x1_2430 = heff_tr(heff_call(v_go_241, 2, (V[]){v_env_242, v_e_2429}));
    V v_t_2435;
    switch (heff_tag_of(v_x1_2430)) {
    case TAG_MkRes: {
      V v_e_2432 = heff_field(v_x1_2430, 1);
      heff_take_n(v_x1_2430, 2ULL, 2);
      v_t_2435 = v_e_2432;
      break;
    }
    case TAG_MkResVals: {
      V v_e_2434 = heff_field(v_x1_2430, 1);
      heff_take_n(v_x1_2430, 2ULL, 2);
      v_t_2435 = v_e_2434;
      break;
    }
    default: heff_nomatch(v_x1_2430);
    }
    return heff_setField(v_d_244, v_i_245, heff_tag_n(TAG_CTest, 1, (V[]){v_t_2435}));
  }
  case TAG_CNot: {
    V v_k_2436 = heff_field(v_x4_243, 0);
    V v_ru_24x4_243_24CNot = heff_take_reuse_n(v_x4_243, 1ULL, 1);
    V v_cell_2437 = heff_tag_at_n(v_ru_24x4_243_24CNot, TAG_CNot, 1, (V[]){heff_hole()});
    V v_u_2438 = heff_setField(v_d_244, v_i_245, heff_dup(v_cell_2437));
    heff_drop(v_u_2438);
    V t_0 = v_c_240;
    V t_1 = v_go_241;
    V t_2 = v_env_242;
    V t_3 = v_k_2436;
    V t_4 = v_cell_2437;
    V t_5 = MK_INT(0LL);
    v_c_240 = t_0;
    v_go_241 = t_1;
    v_env_242 = t_2;
    v_x4_243 = t_3;
    v_d_244 = t_4;
    v_i_245 = t_5;
    goto top;
  }
  case TAG_CIf: {
    V v_a_2439 = heff_field(v_x4_243, 0);
    V v_b_2440 = heff_field(v_x4_243, 1);
    V v_k_2441 = heff_field(v_x4_243, 2);
    V v_ru_24x4_243_24CIf = heff_take_reuse_n(v_x4_243, 7ULL, 3);
    V v_t_2442 = (g_heff_2ecompile_2eranges_2ewalkCond(heff_dup(v_c_240), heff_dup(v_go_241), heff_dup(v_env_242), heff_dup(v_a_2439)));
    V v_t_2443 = (g_heff_2ecompile_2eranges_2econdRefine(heff_dup(v_c_240), heff_dup(v_env_242), v_a_2439, NTAG(TAG_True)));
    V v_t_2444 = (g_heff_2ecompile_2eranges_2ewalkCond(heff_dup(v_c_240), heff_dup(v_go_241), v_t_2443, v_b_2440));
    V v_cell_2445 = heff_tag_at_n(v_ru_24x4_243_24CIf, TAG_CIf, 3, (V[]){v_t_2442, v_t_2444, heff_hole()});
    V v_u_2446 = heff_setField(v_d_244, v_i_245, heff_dup(v_cell_2445));
    heff_drop(v_u_2446);
    V v_t_2447 = ({ V a_0 = heff_dup(v_c_240); V a_1 = v_env_242; V a_2 = v_a_2439; V a_3 = NTAG(TAG_False); V r_ = (g_heff_2ecompile_2eranges_2econdRefine(a_0, a_1, a_2, a_3)); heff_drop(v_a_2439); r_; });
    V t_0 = v_c_240;
    V t_1 = v_go_241;
    V t_2 = v_t_2447;
    V t_3 = v_k_2441;
    V t_4 = v_cell_2445;
    V t_5 = MK_INT(2LL);
    v_c_240 = t_0;
    v_go_241 = t_1;
    v_env_242 = t_2;
    v_x4_243 = t_3;
    v_d_244 = t_4;
    v_i_245 = t_5;
    goto top;
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2ecompile_2eranges_2ewalkCond_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eranges_2ewalkCond_24dps(a[0], a[1], a[2], a[3], a[4], a[5]);
}
Clo g_heff_2ecompile_2eranges_2escanCond_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eranges_2escanCond_entry, 2, 0};

V g_heff_2ecompile_2eranges_2escanCond(V v_s_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_CTrue: {
    return v_s_240;
  }
  case TAG_CFalse: {
    return v_s_240;
  }
  case TAG_CRel: {
    V v_p_242 = heff_field(v_x2_241, 0);
    V v_a_243 = heff_field(v_x2_241, 1);
    V v_b_244 = heff_field(v_x2_241, 2);
    V v_t_245;
    switch (heff_tag_of(v_p_242)) {
    case TAG_IntAdd: {
      v_t_245 = NTAG(TAG_True);
      break;
    }
    case TAG_IntSub: {
      v_t_245 = NTAG(TAG_True);
      break;
    }
    case TAG_IntMul: {
      v_t_245 = NTAG(TAG_True);
      break;
    }
    case TAG_IntDiv: {
      v_t_245 = NTAG(TAG_True);
      break;
    }
    case TAG_IntMod: {
      v_t_245 = NTAG(TAG_True);
      break;
    }
    case TAG_IntEq: {
      v_t_245 = NTAG(TAG_True);
      break;
    }
    case TAG_IntLt: {
      v_t_245 = NTAG(TAG_True);
      break;
    }
    case TAG_IntLe: {
      v_t_245 = NTAG(TAG_True);
      break;
    }
    case TAG_IntAnd: {
      v_t_245 = NTAG(TAG_True);
      break;
    }
    case TAG_FloatFromInt: {
      v_t_245 = NTAG(TAG_True);
      break;
    }
    default: {
      v_t_245 = NTAG(TAG_False);
      break;
    }
    }
    if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
      heff_drop(v_t_245);
      V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_b_244), NTAG(TAG_Nil)});
      V v_t_247 = (g_heff_2ecompile_2eranges_2enamesW(heff_take_field(v_s_240, 0), heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_a_243), v_t_246})));
      return ({ V rv_0 = v_t_247; V rv_3 = NTAG(TAG_True); V rr_ = heff_rec_reuse_nf(v_s_240, 22ULL, 5, shape_numeric__given__calls__ints__escapes, 828u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 3) = rv_3; rr_; });
    } else {
      heff_drop(v_t_245);
      return v_s_240;
    }
  }
  case TAG_CTest: {
    return v_s_240;
  }
  case TAG_CNot: {
    V v_k_249 = heff_field(v_x2_241, 0);
    V t_0 = v_s_240;
    V t_1 = v_k_249;
    v_s_240 = t_0;
    v_x2_241 = t_1;
    goto top;
  }
  case TAG_CIf: {
    V v_a_2410 = heff_field(v_x2_241, 0);
    V v_b_2411 = heff_field(v_x2_241, 1);
    V v_k_2412 = heff_field(v_x2_241, 2);
    V v_t_2413 = (g_heff_2ecompile_2eranges_2escanCond(v_s_240, v_a_2410));
    V v_t_2414 = (g_heff_2ecompile_2eranges_2escanCond(v_t_2413, v_b_2411));
    V t_0 = v_t_2414;
    V t_1 = v_k_2412;
    v_s_240 = t_0;
    v_x2_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eranges_2escanCond_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2eranges_2escanCond(a[0], a1); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2eranges_2escanW_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eranges_2escanW_entry, 3, 0};

V g_heff_2ecompile_2eranges_2escanW(V v_ar_240, V v_s_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_ar_240);
    return v_s_241;
  }
  case TAG_Cons: {
    V v_x31_243 = heff_field(v_x3_242, 0);
    V v_rest_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    switch (heff_tag_of(v_x31_243)) {
    case TAG_EGlobal: {
      V v_g_245 = heff_field(v_x31_243, 0);
      heff_take_n(v_x31_243, 1ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V v_t_246 = (g_std_2eordmap_2einsert_24s615484302x989744458(heff_take_field(v_s_241, 4), v_g_245, NTAG(TAG_MkUnit)));
      V v_t_247 = ({ V rv_4 = v_t_246; V rr_ = heff_rec_reuse_nf(v_s_241, 15ULL, 5, shape_numeric__given__calls__ints__escapes, 255u, 0u); heff_rfield(rr_, 4) = rv_4; rr_; });
      V t_0 = v_ar_240;
      V t_1 = v_t_247;
      V t_2 = v_rest_244;
      v_ar_240 = t_0;
      v_s_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EPrimCall: {
      V v_p_248 = heff_field(v_x31_243, 0);
      V v_args_249 = heff_field(v_x31_243, 1);
      heff_take_n(v_x31_243, 3ULL, 2);
      V v_t_2410;
      switch (heff_tag_of(v_p_248)) {
      case TAG_IntAdd: {
        v_t_2410 = NTAG(TAG_True);
        break;
      }
      case TAG_IntSub: {
        v_t_2410 = NTAG(TAG_True);
        break;
      }
      case TAG_IntMul: {
        v_t_2410 = NTAG(TAG_True);
        break;
      }
      case TAG_IntDiv: {
        v_t_2410 = NTAG(TAG_True);
        break;
      }
      case TAG_IntMod: {
        v_t_2410 = NTAG(TAG_True);
        break;
      }
      case TAG_IntEq: {
        v_t_2410 = NTAG(TAG_True);
        break;
      }
      case TAG_IntLt: {
        v_t_2410 = NTAG(TAG_True);
        break;
      }
      case TAG_IntLe: {
        v_t_2410 = NTAG(TAG_True);
        break;
      }
      case TAG_IntAnd: {
        v_t_2410 = NTAG(TAG_True);
        break;
      }
      case TAG_FloatFromInt: {
        v_t_2410 = NTAG(TAG_True);
        break;
      }
      default: {
        heff_drop(v_p_248);
        v_t_2410 = NTAG(TAG_False);
        break;
      }
      }
      V v_t_2412;
      if ((heff_dup(v_t_2410) == NTAG(TAG_True))) {
        heff_drop(v_t_2410);
        V v_t_2411 = (g_heff_2ecompile_2eranges_2enamesW(heff_take_field(v_s_241, 0), heff_dup(v_args_249)));
        v_t_2412 = ({ V rv_0 = v_t_2411; V rv_3 = NTAG(TAG_True); V rr_ = heff_rec_reuse_nf(v_s_241, 22ULL, 5, shape_numeric__given__calls__ints__escapes, 828u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 3) = rv_3; rr_; });
      } else {
        heff_drop(v_t_2410);
        v_t_2412 = v_s_241;
      }
      V v_t_2413 = (g_heff_2ecompile_2eir_2eappendI_24tok2(v_ru_24x3_242_24Cons, v_args_249, v_rest_244));
      V t_0 = v_ar_240;
      V t_1 = v_t_2412;
      V t_2 = v_t_2413;
      v_ar_240 = t_0;
      v_s_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_ECall: {
      V v_g_2414 = heff_field(v_x31_243, 0);
      V v_args_2415 = heff_field(v_x31_243, 1);
      V v_ru_24x31_243_24ECall = heff_take_reuse_n(v_x31_243, 3ULL, 2);
      V v_ar_2416 = heff_dup(v_ar_240);
      V v_s_2417 = v_s_241;
      V v_g_2418 = v_g_2414;
      V v_args_2419 = heff_dup(v_args_2415);
      V v_t_2420 = (g_heff_2ecompile_2eranges_2egivenFrom(heff_dup(v_g_2418), MK_INT(0LL), heff_take_field(v_s_2417, 1), heff_dup(v_args_2419)));
      V v_t_2421 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_g_2418), heff_dup(heff_rfield(v_s_2417, 2))});
      V v_n_2422 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_args_2419; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_args_2419); r_; });
      HeffT2 v_t_2423 = ({ V a_0 = v_ar_2416; V a_1 = v_g_2418; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_ar_2416); r_; });
      V v_t_2427;
      {
        V v_field_2425 = v_t_2423.f[1];
        int64_t v_tag_2424 = ((int64_t)v_t_2423.f[0]);
        if ((v_tag_2424 == ((int64_t)0ULL))) {
          V v_m_2426 = v_field_2425;
          if (heff_intEq_c(v_n_2422, v_m_2426)) {
            heff_drop(v_g_2418);
            v_t_2427 = heff_dup(heff_rfield(v_s_2417, 4));
          } else {
            v_t_2427 = (g_std_2eordmap_2einsert_24s615484302x989744458(heff_dup(heff_rfield(v_s_2417, 4)), v_g_2418, NTAG(TAG_MkUnit)));
          }
        } else {
          heff_drop(v_n_2422);
          heff_drop(v_field_2425);
          v_t_2427 = (g_std_2eordmap_2einsert_24s615484302x989744458(heff_dup(heff_rfield(v_s_2417, 4)), v_g_2418, NTAG(TAG_MkUnit)));
        }
      }
      V v_t_2428 = ({ V rv_1 = v_t_2420; V rv_2 = v_t_2421; V rv_4 = v_t_2427; V rr_ = heff_rec_reuse_nf(v_s_2417, 9ULL, 5, shape_numeric__given__calls__ints__escapes, 195u, 0u); heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 4) = rv_4; rr_; });
      V v_t_2429 = (g_heff_2ecompile_2eir_2eappendI_24tok2(v_ru_24x31_243_24ECall, v_args_2415, v_rest_244));
      V t_0 = v_ar_240;
      V t_1 = v_t_2428;
      V t_2 = v_t_2429;
      v_ar_240 = t_0;
      v_s_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EBool: {
      V v_c_2430 = heff_field(v_x31_243, 0);
      heff_take_n(v_x31_243, 1ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V v_t_2431 = (g_heff_2ecompile_2eranges_2escanCond(v_s_241, v_c_2430));
      V v_t_2432 = ({ V a_0 = v_c_2430; V a_1 = v_rest_244; V r_ = (g_heff_2ecompile_2eir_2econdOnto(a_0, a_1)); heff_drop(v_c_2430); r_; });
      V t_0 = v_ar_240;
      V t_1 = v_t_2431;
      V t_2 = v_t_2432;
      v_ar_240 = t_0;
      v_s_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    default: {
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V v_t_2433 = (g_heff_2ecompile_2eir_2epartsOnto(v_x31_243, v_rest_244));
      V t_0 = v_ar_240;
      V t_1 = v_s_241;
      V t_2 = v_t_2433;
      v_ar_240 = t_0;
      v_s_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2eranges_2escanW_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eranges_2escanW(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2eranges_2enarrowWith_lam0(V self, V *args);
Clo g_heff_2ecompile_2eranges_2enarrowWith_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eranges_2enarrowWith_entry, 4, 0};

V g_heff_2ecompile_2eranges_2enarrowWith(V v_sc_240, V v_nw_241, V v_gathered_242, V v_gs_243) {
top: ;
  V v_t_244 = ({ V rv_1 = heff_dup(v_gathered_242); V rv_2 = NTAG(TAG_Nil); V rr_ = heff_rec_reuse_nf(v_nw_241, 1ULL, 3, shape_params__gathered__changed, 3u, 0u); heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; rr_; });
  return (g_list_2efoldl(heff_clo_n(g_heff_2ecompile_2eranges_2enarrowWith_lam0, 2, 2, (V[]){v_sc_240, v_gathered_242}), v_t_244, v_gs_243));
}
V g_heff_2ecompile_2eranges_2enarrowWith_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2ecompile_2eranges_2enarrowWith(a[0], a[1], a[2], a3); heff_drop(a3); return r;
}
V g_heff_2ecompile_2eranges_2enarrowWith_lam0(V self, V *args) {
  V v_acc_245 = args[0];
  V v_g_246 = args[1];
  V v_sc_240 = heff_env(self)[0];
  V v_gathered_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  HeffT2 v_t_247 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(heff_rfield(v_acc_245, 0), v_g_246));
  {
    V v_field_249 = v_t_247.f[1];
    int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
    if ((v_tag_248 == ((int64_t)0ULL))) {
      V v_old_2410 = v_field_249;
      V v_t_2411 = (g_list_2eall_24s853093203x77424416(v_old_2410));
      if ((heff_dup(v_t_2411) == NTAG(TAG_True))) {
        heff_drop(v_g_246);
        heff_drop(v_sc_240);
        heff_drop(v_gathered_242);
        heff_drop(v_old_2410);
        heff_drop(v_t_2411);
        return v_acc_245;
      } else {
        heff_drop(v_t_2411);
        V v_t_2412 = (g_heff_2ecompile_2eranges_2ejoinedFor(heff_dup(v_sc_240), v_gathered_242, heff_dup(v_old_2410), v_g_246));
        V v_t_2413 = ({ V a_0 = v_old_2410; V a_1 = v_t_2412; V r_ = (g_heff_2ecompile_2eranges_2erangesEq(a_0, a_1)); heff_drop(v_t_2412); r_; });
        if ((heff_dup(v_t_2413) == NTAG(TAG_True))) {
          heff_drop(v_g_246);
          heff_drop(v_sc_240);
          heff_drop(v_gathered_242);
          heff_drop(v_old_2410);
          heff_drop(v_t_2413);
          return v_acc_245;
        } else {
          heff_drop(v_t_2413);
          V v_t_2414 = ({ V a_0 = v_sc_240; V a_1 = v_gathered_242; V a_2 = v_old_2410; V a_3 = v_g_246; V r_ = (g_heff_2ecompile_2eranges_2ejoinedFor(a_0, a_1, a_2, a_3)); heff_drop(v_gathered_242); r_; });
          V v_t_2415 = (g_std_2eordmap_2einsert_24s615484302x989744458(heff_take_field(v_acc_245, 0), heff_dup(v_g_246), v_t_2414));
          V v_t_2416 = heff_tag_n(TAG_Cons, 2, (V[]){v_g_246, heff_take_field(v_acc_245, 2)});
          return ({ V rv_0 = v_t_2415; V rv_2 = v_t_2416; V rr_ = heff_rec_reuse_nf(v_acc_245, 2ULL, 3, shape_params__gathered__changed, 12u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 2) = rv_2; rr_; });
        }
      }
    } else {
      heff_drop(v_g_246);
      heff_drop(v_sc_240);
      heff_drop(v_gathered_242);
      heff_drop(v_field_249);
      return v_acc_245;
    }
  }
}
V g_heff_2ecompile_2eranges_2enarrowing_lam0(V self, V *args);
V g_heff_2ecompile_2eranges_2enarrowing_lam1(V self, V *args);
V g_heff_2ecompile_2eranges_2enarrowing_lam2(V self, V *args);
V g_heff_2ecompile_2eranges_2enarrowing_lam3(V self, V *args);
Clo g_heff_2ecompile_2eranges_2enarrowing_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eranges_2enarrowing_entry, 4, 0};

V g_heff_2ecompile_2eranges_2enarrowing(V v_consts_240, V v_sc_241, V v_box_24n_242, V v_nw_243) {
  int64_t v_n_242 = heff_unbox_word(v_box_24n_242);
top: ;
  if ((v_n_242 <= ((int64_t)0ULL))) {
    heff_drop(v_consts_240);
    heff_drop_rec(v_sc_241, 4);
    return heff_get_n(v_nw_243, 0, 3);
  } else {
    V v_x1_249 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ecompile_2eranges_2enarrowing_lam0, 1, 1, (V[]){heff_dup(v_sc_241)}), heff_dup(heff_rfield(v_nw_243, 2))));
    switch (heff_tag_of(v_x1_249)) {
    case TAG_Nil: {
      heff_drop(v_consts_240);
      heff_drop_rec(v_sc_241, 4);
      return heff_get_n(v_nw_243, 0, 3);
    }
    case TAG_Cons: {
      V v_ru_24x1_249_24Cons = heff_take_reuse_n(v_x1_249, 0ULL, 2);
      V v_consts_2412 = heff_dup(v_consts_240);
      V v_sc_2413 = heff_dup(v_sc_241);
      V v_nw_2414 = heff_dup(v_nw_243);
      V v_keys_2420 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ecompile_2eranges_2enarrowing_lam1, 1, 1, (V[]){heff_dup(v_sc_241)}), heff_get_n(v_nw_243, 2, 3)));
      V v_g_2421 = heff_dup(heff_rfield(v_nw_2414, 1));
      V v_t_2430 = (g_list_2efoldl(heff_clo_n(g_heff_2ecompile_2eranges_2enarrowing_lam2, 2, 3, (V[]){heff_dup(v_sc_2413), heff_dup(v_nw_2414), v_consts_2412}), v_g_2421, v_keys_2420));
      V v_m_2438 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2eranges_2enarrowing_lam3, 2, 1, (V[]){heff_dup(v_sc_2413)}); V a_1 = heff_dup(g_std_2eordmap_2eempty_get()); V a_2 = v_keys_2420; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_keys_2420); r_; });
      V v_t_2439 = ({ V a_0 = v_m_2438; V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2eordmap_2etoList_2etoListOnto_240(a_0, a_1)); heff_drop(v_m_2438); r_; });
      V v_t_2440 = (g_list_2emap_24s1937570095x2110149801_24tok2(v_ru_24x1_249_24Cons, v_t_2439));
      V v_t_2441 = ({ V a_0 = v_sc_2413; V a_1 = v_nw_2414; V a_2 = v_t_2430; V a_3 = v_t_2440; V r_ = (g_heff_2ecompile_2eranges_2enarrowWith(a_0, a_1, a_2, a_3)); heff_drop(v_t_2440); r_; });
      V t_0 = v_consts_240;
      V t_1 = v_sc_241;
      int64_t t_2 = (v_n_242 - ((int64_t)1ULL));
      V t_3 = v_t_2441;
      v_consts_240 = t_0;
      v_sc_241 = t_1;
      v_n_242 = t_2;
      v_nw_243 = t_3;
      goto top;
    }
    default: return heff_nomatch(v_x1_249);
    }
  }
}
V g_heff_2ecompile_2eranges_2enarrowing_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eranges_2enarrowing(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2eranges_2enarrowing_lam0(V self, V *args) {
  V v_k_244 = args[0];
  V v_sc_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_245 = ({ V b_0 = heff_get_n(v_sc_241, 1, 4); V a_1 = v_k_244; HeffT2 r_ = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(b_0, a_1)); heff_drop(b_0); heff_drop(v_k_244); r_; });
  {
    V v_field_247 = v_t_245.f[1];
    int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
    V v_ret_24bool = heff_bool(((v_tag_246 == ((int64_t)0ULL)) && ({ V v_x_248 = heff_dup(v_field_247); int c_ = 1; heff_drop(v_x_248); c_; })));
    heff_drop(v_field_247);
    return v_ret_24bool;
  }
}
V g_heff_2ecompile_2eranges_2enarrowing_lam1(V self, V *args) {
  V v_k_2415 = args[0];
  V v_sc_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2416 = ({ V b_0 = heff_get_n(v_sc_241, 1, 4); V a_1 = v_k_2415; HeffT2 r_ = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(b_0, a_1)); heff_drop(b_0); heff_drop(v_k_2415); r_; });
  {
    V v_field_2418 = v_t_2416.f[1];
    int64_t v_tag_2417 = ((int64_t)v_t_2416.f[0]);
    V v_ret_24bool = heff_bool(((v_tag_2417 == ((int64_t)0ULL)) && ({ V v_x_2419 = heff_dup(v_field_2418); int c_ = 1; heff_drop(v_x_2419); c_; })));
    heff_drop(v_field_2418);
    return v_ret_24bool;
  }
}
V g_heff_2ecompile_2eranges_2enarrowing_lam2(V self, V *args) {
  V v_m_2422 = args[0];
  V v_k_2423 = args[1];
  V v_sc_2413 = heff_env(self)[0];
  V v_nw_2414 = heff_env(self)[1];
  V v_consts_2412 = heff_env(self)[2];
  heff_clo_take(self, 3);
  HeffT2 v_t_2424 = ({ V b_0 = heff_get_n(v_sc_2413, 0, 4); V a_1 = v_k_2423; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
  {
    V v_field_2426 = v_t_2424.f[1];
    int64_t v_tag_2425 = ((int64_t)v_t_2424.f[0]);
    if ((v_tag_2425 == ((int64_t)0ULL))) {
      V v_d_2427 = v_field_2426;
      V v_t_2428 = heff_rec_n(3, shape_params__consts__marking, (V[]){heff_get_n(v_nw_2414, 0, 3), v_consts_2412, NTAG(TAG_False)});
      V v_t_2429 = (g_heff_2ecompile_2eranges_2egatherDef(v_t_2428, v_d_2427));
      return (g_std_2eordmap_2einsert_24s615484302x989744458(v_m_2422, v_k_2423, heff_get_n(v_t_2429, 0, 2)));
    } else {
      heff_drop(v_k_2423);
      heff_drop_rec(v_nw_2414, 3);
      heff_drop(v_consts_2412);
      heff_drop(v_field_2426);
      return v_m_2422;
    }
  }
}
V g_heff_2ecompile_2eranges_2enarrowing_lam3(V self, V *args) {
  V v_m_2431 = args[0];
  V v_k_2432 = args[1];
  V v_sc_2413 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2433 = ({ V b_0 = heff_get_n(v_sc_2413, 1, 4); V a_1 = v_k_2432; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(b_0, a_1)); heff_drop(b_0); heff_drop(v_k_2432); r_; });
  V v_t_2437;
  {
    V v_field_2435 = v_t_2433.f[1];
    int64_t v_tag_2434 = ((int64_t)v_t_2433.f[0]);
    if ((v_tag_2434 == ((int64_t)0ULL))) {
      V v_x_2436 = v_field_2435;
      v_t_2437 = v_x_2436;
    } else {
      heff_drop(v_field_2435);
      v_t_2437 = NTAG(TAG_Nil);
    }
  }
  return ({ V a_0 = v_m_2431; V a_1 = v_t_2437; V r_ = (g_list_2efoldl_24s1614667250x430274379(a_0, a_1)); heff_drop(v_t_2437); r_; });
}