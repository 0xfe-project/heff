// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_SError 24172
#define TAG_Throw 56084
#define LBL_bind 9519364
#define LBL_code 9554612
#define LBL_malg 9839318
#define LBL_msg 317947
#define LBL_note 9882809
#define LBL_severity 75955546
#define LBL_span 10032145
static uint32_t shape_code__severity__msg__span__note[] = {LBL_code, LBL_severity, LBL_msg, LBL_span, LBL_note};
V g_heff_2eelab_2erules_2enamedGo_2enoArgNamed_240(V, V, V, V);
V g_heff_2eelab_2erules_2enamedGo_2enoArgNamed_240_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2enamedGo_2enoArgNamed_240_clo;
HEFF_STRA(g_heff_2eelab_2erules_2enamedGo_2enoArgNamed_240_str0, 2, (96, 40));
HEFF_STRA(g_heff_2eelab_2erules_2enamedGo_2enoArgNamed_240_str1, 53, (32, 58, 61, 32, 46, 46, 46, 41, 96, 32, 110, 97, 109, 101, 115, 32, 97, 110, 32, 97, 114, 103, 117, 109, 101, 110, 116, 44, 32, 98, 117, 116, 32, 116, 104, 101, 114, 101, 32, 105, 115, 32, 110, 111, 110, 101, 32, 110, 97, 109, 101, 100, 32));
HEFF_STRA(g_heff_2eelab_2erules_2enamedGo_2enoArgNamed_240_str2, 5, (32, 104, 101, 114, 101));
Clo g_heff_2eelab_2erules_2enamedGo_2enoArgNamed_240_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2enamedGo_2enoArgNamed_240_entry, 4, 0};

V g_heff_2eelab_2erules_2enamedGo_2enoArgNamed_240(V v_sp_240, V v_x_241, V v_hd_242, V v_k2_243) {
top: ;
  V v_t_244 = heff_strAppend(((V)&g_heff_2eelab_2erules_2enamedGo_2enoArgNamed_240_str0), heff_strAppend(heff_dup(v_x_241), heff_strAppend(((V)&g_heff_2eelab_2erules_2enamedGo_2enoArgNamed_240_str1), heff_strAppend(v_x_241, ((V)&g_heff_2eelab_2erules_2enamedGo_2enoArgNamed_240_str2)))));
  V v_t_245 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(329LL), NTAG(TAG_SError), v_t_244, v_sp_240, NTAG(TAG_Nothing)});
  V v_t_246 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_245})});
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tr(heff_apply(heff_take_field(v_hd_242, 2), 1, (V[]){v_t_247}));
  return heff_tail(heff_get_n(v_hd_242, 1, 3), 2, (V[]){v_t_248, v_k2_243});
}
V g_heff_2eelab_2erules_2enamedGo_2enoArgNamed_240_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2enamedGo_2enoArgNamed_240(a[0], a[1], a[2], a[3]);
}