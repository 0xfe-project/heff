// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_SError 24172
#define TAG_Throw 56084
#define LBL_bind 9519364
#define LBL_code 9554612
#define LBL_malg 9839318
#define LBL_msg 317947
#define LBL_note 9882809
#define LBL_severity 75955546
#define LBL_span 10032145
#define LBL_stx 323761
static uint32_t shape_code__severity__msg__span__note[] = {LBL_code, LBL_severity, LBL_msg, LBL_span, LBL_note};
V g_heff_2eelab_2erules_2enamedGo_2enoArgNamed_240(V, V, V, V, V);
V g_heff_2eelab_2erules_2enamedGo_2enoArgNamed_240_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2enamedGo_2enoArgNamed_240_clo;
V g_heff_2eelab_2erules_2enoneNamed(V, V, V);
V g_heff_2eelab_2erules_2enoneNamed_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2enoneNamed_clo;
HEFF_LIT(g_heff_2eelab_2erules_2enamedGo_2enoArgNamed_240_str0, 1, "`");
HEFF_LIT(g_heff_2eelab_2erules_2enamedGo_2enoArgNamed_240_str1, 18, "` is given already");
Clo g_heff_2eelab_2erules_2enamedGo_2enoArgNamed_240_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2enamedGo_2enoArgNamed_240_entry, 5, 0};

V g_heff_2eelab_2erules_2enamedGo_2enoArgNamed_240(V v_sp_240, V v_x_241, V v_m_242, V v_z_243, V v_z_244) {
top: ;
  V v_bind_245 = heff_take_field(v_z_243, 1);
  V v_malg_246 = heff_get_n(v_z_243, 2, 3);
  V v_t_247 = heff_strAppend(heff_strAppend(((V)&g_heff_2eelab_2erules_2enamedGo_2enoArgNamed_240_str0), heff_dup(v_x_241)), ((V)&g_heff_2eelab_2erules_2enamedGo_2enoArgNamed_240_str1));
  V v_msg_248 = ({ V a_0 = v_x_241; V a_1 = v_t_247; V b_2 = heff_get_n(v_m_242, 0, 2); V r_ = (g_heff_2eelab_2erules_2enoneNamed(a_0, a_1, b_2)); heff_drop(b_2); r_; });
  V v_t_249 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(329LL), NTAG(TAG_SError), v_msg_248, v_sp_240, NTAG(TAG_Nothing)});
  V v_t_2410 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tr(heff_call(v_malg_246, 1, (V[]){v_t_2411}));
  return heff_tail(v_bind_245, 2, (V[]){v_t_2412, v_z_244});
}
V g_heff_2eelab_2erules_2enamedGo_2enoArgNamed_240_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2enamedGo_2enoArgNamed_240(a[0], a[1], a[2], a[3], a[4]);
}