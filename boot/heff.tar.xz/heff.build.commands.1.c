// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Complete 48856
#define TAG_End 17255
#define TAG_Exit 20279
#define TAG_FailBecause 16014
#define TAG_FailDiffer 33429
#define TAG_JArray 50516
#define TAG_JBool 39030
#define TAG_JFloat 30719
#define TAG_JInt 58696
#define TAG_JNull 9039
#define TAG_JObject 38239
#define TAG_JString 41091
#define TAG_Left 13886
#define TAG_MkPath 49630
#define TAG_Platform 55558
#define TAG_Posix 44191
#define TAG_Right 62770
#define TAG_Start 63542
#define TAG_Windows 49101
#define TAG_Write 36323
#define TAG_WriteErr 37283
#define LBL_apps 9496377
#define LBL_backend 2032133329
#define LBL_bad 306815
#define LBL_bin 307073
#define LBL_build 295453320
#define LBL_c 317
#define LBL_dir 308999
#define LBL_done 9584713
#define LBL_effect 641056956
#define LBL_end 310101
#define LBL_errors 652506774
#define LBL_globals 352931696
#define LBL_hash 9690581
#define LBL_key 315609
#define LBL_module 878357911
#define LBL_name 9869138
#define LBL_own 320000
#define LBL_pages 307784670
#define LBL_path 9928940
#define LBL_paths 307797256
#define LBL_prefix 967031229
#define LBL_replace 1326354680
#define LBL_require 1327554473
#define LBL_ret 322331
#define LBL_root 10001833
#define LBL_said 10017968
#define LBL_seen 10021698
#define LBL_src 323678
#define LBL_style 311138763
#define LBL_top 324559
#define LBL_zig 330130
static uint32_t shape_apps__bad[] = {LBL_apps, LBL_bad};
static uint32_t shape_name__build[] = {LBL_name, LBL_build};
static uint32_t shape_name__key__effect[] = {LBL_name, LBL_key, LBL_effect};
static uint32_t shape_prefix__end[] = {LBL_prefix, LBL_end};
static uint32_t shape_seen__errors[] = {LBL_seen, LBL_errors};
V g_co_2eop_24s615738393x1686646143(V, V, V);
V g_co_2eop_24s615738393x1686646143_entry(V self, V *a);
extern Clo g_co_2eop_24s615738393x1686646143_clo;
V g_exception_2eattempted_24s85350750x49672201_get(void);
V g_heff_2ebuild_2ebackcache_2ebackDir_get(void);
V g_heff_2ebuild_2ecommands_2eappFile(V, V, V, V);
V g_heff_2ebuild_2ecommands_2eappFile_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eappFile_clo;
V g_heff_2ebuild_2ecommands_2eappShips_24s816274383x1331904422(V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eappShips_24s816274383x1331904422_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eappShips_24s816274383x1331904422_clo;
V g_heff_2ebuild_2ecommands_2ebackDirOf(V);
V g_heff_2ebuild_2ecommands_2ebackDirOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ebackDirOf_clo;
V g_heff_2ebuild_2ecommands_2echeckModule_24s689954649x499235092(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2echeckModule_24s689954649x499235092_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2echeckModule_24s689954649x499235092_clo;
V g_heff_2ebuild_2ecommands_2ecompileFound_24s1945822963x1352587118(V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecompileFound_24s1945822963x1352587118_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecompileFound_24s1945822963x1352587118_clo;
V g_heff_2ebuild_2ecommands_2ecompileFoundC_24s2017760430x1267524453(V, V, V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecompileFoundC_24s2017760430x1267524453_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecompileFoundC_24s2017760430x1267524453_clo;
V g_heff_2ebuild_2ecommands_2eelemStrM(V, V);
V g_heff_2ebuild_2ecommands_2eelemStrM_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eelemStrM_clo;
V g_heff_2ebuild_2ecommands_2eevalDiags_24s1053812068x1843767835(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eevalDiags_24s1053812068x1843767835_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eevalDiags_24s1053812068x1843767835_clo;
V g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382(V, V, V, V);
V g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382_clo;
V g_heff_2ebuild_2ecommands_2efetchedPkg_24s1462621892x1253896370(V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2efetchedPkg_24s1462621892x1253896370_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2efetchedPkg_24s1462621892x1253896370_clo;
V g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937(V, V);
V g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937_clo;
V g_heff_2ebuild_2ecommands_2ejsKept_24s1060797234x1576735494(V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ejsKept_24s1060797234x1576735494_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ejsKept_24s1060797234x1576735494_clo;
V g_heff_2ebuild_2ecommands_2ejsonFailure(V);
V g_heff_2ebuild_2ecommands_2ejsonFailure_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ejsonFailure_clo;
V g_heff_2ebuild_2ecommands_2ekeptParts_24s1926203457x1297589184(V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ekeptParts_24s1926203457x1297589184_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ekeptParts_24s1926203457x1297589184_clo;
V g_heff_2ebuild_2ecommands_2eload_24s1410275656x228048283(V);
V g_heff_2ebuild_2ecommands_2eload_24s1410275656x228048283_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eload_24s1410275656x228048283_clo;
V g_heff_2ebuild_2ecommands_2eownRoot(V, V);
V g_heff_2ebuild_2ecommands_2eownRoot_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eownRoot_clo;
V g_heff_2ebuild_2ecommands_2epartsDir(V, V, V);
V g_heff_2ebuild_2ecommands_2epartsDir_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2epartsDir_clo;
V g_heff_2ebuild_2ecommands_2eplaceAll_24s147065284x1786496036(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eplaceAll_24s147065284x1786496036_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eplaceAll_24s147065284x1786496036_clo;
V g_heff_2ebuild_2ecommands_2eplaceBefore(V, V);
V g_heff_2ebuild_2ecommands_2eplaceBefore_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eplaceBefore_clo;
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1018017004x1417809443(V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1018017004x1417809443_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eplaceMade_24s1018017004x1417809443_clo;
V g_heff_2ebuild_2ecommands_2eprintErrs_24s115117455x797094904(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eprintErrs_24s115117455x797094904_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprintErrs_24s115117455x797094904_clo;
V g_heff_2ebuild_2ecommands_2eprintEvals_24s906160764x145037181(V, V, V);
V g_heff_2ebuild_2ecommands_2eprintEvals_24s906160764x145037181_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprintEvals_24s906160764x145037181_clo;
V g_heff_2ebuild_2ecommands_2eprovidesLeaf(V, V);
V g_heff_2ebuild_2ecommands_2eprovidesLeaf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprovidesLeaf_clo;
V g_heff_2ebuild_2ecommands_2eprovidesLeafC(V, V);
V g_heff_2ebuild_2ecommands_2eprovidesLeafC_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprovidesLeafC_clo;
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s415097226x198460927(V, V);
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s415097226x198460927_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eputFileDiags_24s415097226x198460927_clo;
V g_heff_2ebuild_2ecommands_2etestArgs(V, V, V, V);
V g_heff_2ebuild_2ecommands_2etestArgs_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2etestArgs_clo;
V g_heff_2ebuild_2ecommands_2etestFiles_24s1079562655x2127217752(V);
V g_heff_2ebuild_2ecommands_2etestFiles_24s1079562655x2127217752_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2etestFiles_24s1079562655x2127217752_clo;
V g_heff_2ebuild_2ecommands_2etestOptions_24s1937373887x2047139729(V, V, V, V);
V g_heff_2ebuild_2ecommands_2etestOptions_24s1937373887x2047139729_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2etestOptions_24s1937373887x2047139729_clo;
V g_heff_2ebuild_2ecommands_2etestText(V);
V g_heff_2ebuild_2ecommands_2etestText_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2etestText_clo;
V g_heff_2ebuild_2ecommands_2etestedAgain_24s1026021682x2082722655(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2etestedAgain_24s1026021682x2082722655_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2etestedAgain_24s1026021682x2082722655_clo;
V g_heff_2ebuild_2ecommands_2etestedAgain_24s1918345756x1218238789(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2etestedAgain_24s1918345756x1218238789_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2etestedAgain_24s1918345756x1218238789_clo;
V g_heff_2ebuild_2ecommands_2etestsWatched_24s554924703x912466171(V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2etestsWatched_24s554924703x912466171_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2etestsWatched_24s554924703x912466171_clo;
V g_heff_2ebuild_2ecommands_2ewriteOutC_24s1877451407x355012956(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ewriteOutC_24s1877451407x355012956_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ewriteOutC_24s1877451407x355012956_clo;
V g_heff_2ebuild_2edriver_2ecandLeaves(V);
V g_heff_2ebuild_2edriver_2ecandLeaves_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ecandLeaves_clo;
V g_heff_2ebuild_2edriver_2ecatMaybesD(V);
V g_heff_2ebuild_2edriver_2ecatMaybesD_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ecatMaybesD_clo;
HeffT2 g_heff_2ebuild_2edriver_2eeffectOfKey_24cpr(V, V);
V g_heff_2ebuild_2edriver_2eevaluate(V);
V g_heff_2ebuild_2edriver_2eevaluate_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eevaluate_clo;
HeffT2 g_heff_2ebuild_2edriver_2efindRunnable_24cpr(V, V, V);
HeffT2 g_heff_2ebuild_2edriver_2elastChecked_24cpr(V);
V g_heff_2ebuild_2edriver_2enubStrD(V);
V g_heff_2ebuild_2edriver_2enubStrD_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2enubStrD_clo;
V g_heff_2ebuild_2eload_2ecachedDir(V, V, V);
V g_heff_2ebuild_2eload_2ecachedDir_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2ecachedDir_clo;
V g_heff_2ebuild_2eload_2einside(V, V, V);
V g_heff_2ebuild_2eload_2einside_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2einside_clo;
V g_heff_2ebuild_2eload_2emoduleOf(V, V);
V g_heff_2ebuild_2eload_2emoduleOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2emoduleOf_clo;
V g_heff_2ebuild_2eload_2epathsFor_24s379653470x968203076(V, V);
V g_heff_2ebuild_2eload_2epathsFor_24s379653470x968203076_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2epathsFor_24s379653470x968203076_clo;
V g_heff_2ebuild_2eload_2ereadPkgAt_24s1971503388x1740917138(V, V, V);
V g_heff_2ebuild_2eload_2ereadPkgAt_24s1971503388x1740917138_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2ereadPkgAt_24s1971503388x1740917138_clo;
HeffT2 g_heff_2ebuild_2eproject_2epseudoParts_24cpr(V);
V g_heff_2ebuild_2esession_2ecachedAcc_24s1827793511x304312721(V);
V g_heff_2ebuild_2esession_2ecachedAcc_24s1827793511x304312721_entry(V self, V *a);
extern Clo g_heff_2ebuild_2esession_2ecachedAcc_24s1827793511x304312721_clo;
V g_heff_2ebuild_2ewatch_2eproject_get(void);
V g_heff_2ebuild_2ewatch_2estamps_24s1980481423x537134380(V, V, V);
V g_heff_2ebuild_2ewatch_2estamps_24s1980481423x537134380_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ewatch_2estamps_24s1980481423x537134380_clo;
V g_heff_2ebuild_2ewatch_2ewatchOver_24s1555981406x1212401230(V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ewatch_2ewatchOver_24s1555981406x1212401230_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ewatch_2ewatchOver_24s1555981406x1212401230_clo;
V g_heff_2ecompile_2eemitc_2eoutputOf(V, V, V, V);
V g_heff_2ecompile_2eemitc_2eoutputOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eoutputOf_clo;
V g_heff_2ecompile_2eemitc_2erunEnd(V, V);
V g_heff_2ecompile_2eemitc_2erunEnd_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2erunEnd_clo;
V g_heff_2ecompile_2eemitc_2ethreadsLine_get(void);
V g_heff_2ecompile_2elower_2elowerProgramC(V, V);
V g_heff_2ecompile_2elower_2elowerProgramC_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elower_2elowerProgramC_clo;
V g_heff_2eutil_2efiles_2eremove_24s889287061x300693304(V);
V g_heff_2eutil_2efiles_2eremove_24s889287061x300693304_entry(V self, V *a);
extern Clo g_heff_2eutil_2efiles_2eremove_24s889287061x300693304_clo;
HeffT2 g_json_2eat_24cpr(V, V);
V g_list_2eany_24s1740858080x874135214(V);
V g_list_2eany_24s1740858080x874135214_entry(V self, V *a);
extern Clo g_list_2eany_24s1740858080x874135214_clo;
V g_list_2eany_24s762674996x1009180162(V);
V g_list_2eany_24s762674996x1009180162_entry(V self, V *a);
extern Clo g_list_2eany_24s762674996x1009180162_clo;
V g_list_2edrop(V, V);
V g_list_2edrop_entry(V self, V *a);
extern Clo g_list_2edrop_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s977936796x564903144(V, V, V, V);
V g_list_2efoldl_24s977936796x564903144_entry(V self, V *a);
extern Clo g_list_2efoldl_24s977936796x564903144_clo;
V g_list_2ekeepIf(V, V);
V g_list_2ekeepIf_entry(V self, V *a);
extern Clo g_list_2ekeepIf_clo;
V g_list_2ekeepIf_24s1511525408x973271992(V, V);
V g_list_2ekeepIf_24s1511525408x973271992_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1511525408x973271992_clo;
V g_list_2ekeepIf_24s1800580503x895008059(V);
V g_list_2ekeepIf_24s1800580503x895008059_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1800580503x895008059_clo;
V g_list_2ekeepIf_24s188390362x2017344139(V, V, V);
V g_list_2ekeepIf_24s188390362x2017344139_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s188390362x2017344139_clo;
V g_list_2ekeepIf_24s684755021x1118425975(V, V);
V g_list_2ekeepIf_24s684755021x1118425975_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s684755021x1118425975_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1146729723x1441207893(V, V, V);
V g_list_2emap_24s1146729723x1441207893_entry(V self, V *a);
extern Clo g_list_2emap_24s1146729723x1441207893_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24f427551988x255400191(V, V);
V g_prelude_2e_2b_2b_24f427551988x255400191_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f427551988x255400191_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2esplitFrom(V, V, V, V, V);
V g_prelude_2esplitFrom_entry(V self, V *a);
extern Clo g_prelude_2esplitFrom_clo;
V g_std_2efilesystem_2ecopy_24s1339645142x382698313(V, V);
V g_std_2efilesystem_2ecopy_24s1339645142x382698313_entry(V self, V *a);
extern Clo g_std_2efilesystem_2ecopy_24s1339645142x382698313_clo;
V g_std_2efilesystem_2ereplace_24s887604673x2104466403(V, V);
V g_std_2efilesystem_2ereplace_24s887604673x2104466403_entry(V self, V *a);
extern Clo g_std_2efilesystem_2ereplace_24s887604673x2104466403_clo;
V g_std_2epath_2ejoin(V, V);
V g_std_2epath_2ejoin_entry(V self, V *a);
extern Clo g_std_2epath_2ejoin_clo;
V g_std_2epath_2enative_get(void);
V g_std_2epath_2eparse(V, V);
V g_std_2epath_2eparse_entry(V self, V *a);
extern Clo g_std_2epath_2eparse_clo;
HeffT3 g_std_2epath_2eparse_24cpr(V, V);
V g_std_2epath_2erender(V, V);
V g_std_2epath_2erender_entry(V self, V *a);
extern Clo g_std_2epath_2erender_clo;
HEFF_LIT(g_heff_2ebuild_2ecommands_2eownRoot_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eownRoot_str1, 3, "out");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eownRoot_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eownRoot_str3, 5, ".heff");
Clo g_heff_2ebuild_2ecommands_2eownRoot_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eownRoot_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2eownRoot(V v_st_240, V v_self_241) {
top: ;
  HeffT3 v_t_242 = (g_std_2epath_2eparse_24cpr(v_st_240, heff_dup(v_self_241)));
  V v_t_2412;
  {
    V v_field_243 = v_t_242.f[0];
    V v_field_244 = v_t_242.f[1];
    V v_field_245 = v_t_242.f[2];
    V v_d_246 = v_field_243;
    V v_a_247 = v_field_244;
    V v_xs_248 = v_field_245;
    V v_t_249 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_248));
    V v_xs_2410 = ({ V a_0 = MK_INT(1LL); V a_1 = v_t_249; V r_ = (g_list_2edrop(a_0, a_1)); heff_drop(v_t_249); r_; });
    V v_t_2411 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2410));
    v_t_2412 = heff_tag_n(TAG_MkPath, 3, (V[]){v_d_246, v_a_247, v_t_2411});
  }
  V v_s_2413 = ({ V a_0 = v_st_240; V a_1 = v_t_2412; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2412); r_; });
  HeffT3 v_t_2414 = (g_std_2epath_2eparse_24cpr(v_st_240, v_s_2413));
  V v_t_2424;
  {
    V v_field_2415 = v_t_2414.f[0];
    V v_field_2416 = v_t_2414.f[1];
    V v_field_2417 = v_t_2414.f[2];
    V v_x11_2418 = v_field_2415;
    heff_drop(v_x11_2418);
    V v_x12_2419 = v_field_2416;
    heff_drop(v_x12_2419);
    V v_xs_2420 = v_field_2417;
    V v_x1_2421 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2420));
    switch (heff_tag_of(v_x1_2421)) {
    case TAG_Nil: {
      v_t_2424 = ((V)&g_heff_2ebuild_2ecommands_2eownRoot_str0);
      break;
    }
    case TAG_Cons: {
      V v_x_2422 = heff_field(v_x1_2421, 0);
      heff_take_n(v_x1_2421, 1ULL, 2);
      v_t_2424 = v_x_2422;
      break;
    }
    default: heff_nomatch(v_x1_2421);
    }
  }
  V v_t_2461;
  if (heff_strEq_c(v_t_2424, ((V)&g_heff_2ebuild_2ecommands_2eownRoot_str1))) {
    HeffT3 v_t_2426 = (g_std_2epath_2eparse_24cpr(v_st_240, heff_dup(v_self_241)));
    V v_t_2436;
    {
      V v_field_2427 = v_t_2426.f[0];
      V v_field_2428 = v_t_2426.f[1];
      V v_field_2429 = v_t_2426.f[2];
      V v_d_2430 = v_field_2427;
      V v_a_2431 = v_field_2428;
      V v_xs_2432 = v_field_2429;
      V v_t_2433 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2432));
      V v_xs_2434 = ({ V a_0 = MK_INT(1LL); V a_1 = v_t_2433; V r_ = (g_list_2edrop(a_0, a_1)); heff_drop(v_t_2433); r_; });
      V v_t_2435 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2434));
      v_t_2436 = heff_tag_n(TAG_MkPath, 3, (V[]){v_d_2430, v_a_2431, v_t_2435});
    }
    V v_s_2437 = ({ V a_0 = v_st_240; V a_1 = v_t_2436; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2436); r_; });
    HeffT3 v_t_2438 = (g_std_2epath_2eparse_24cpr(v_st_240, v_s_2437));
    V v_t_2448;
    {
      V v_field_2439 = v_t_2438.f[0];
      V v_field_2440 = v_t_2438.f[1];
      V v_field_2441 = v_t_2438.f[2];
      V v_d_2442 = v_field_2439;
      V v_a_2443 = v_field_2440;
      V v_xs_2444 = v_field_2441;
      V v_t_2445 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2444));
      V v_xs_2446 = ({ V a_0 = MK_INT(1LL); V a_1 = v_t_2445; V r_ = (g_list_2edrop(a_0, a_1)); heff_drop(v_t_2445); r_; });
      V v_t_2447 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2446));
      v_t_2448 = heff_tag_n(TAG_MkPath, 3, (V[]){v_d_2442, v_a_2443, v_t_2447});
    }
    V v_s_2449 = ({ V a_0 = v_st_240; V a_1 = v_t_2448; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2448); r_; });
    HeffT3 v_t_2450 = (g_std_2epath_2eparse_24cpr(v_st_240, v_s_2449));
    V v_t_2460;
    {
      V v_field_2451 = v_t_2450.f[0];
      V v_field_2452 = v_t_2450.f[1];
      V v_field_2453 = v_t_2450.f[2];
      V v_x11_2454 = v_field_2451;
      heff_drop(v_x11_2454);
      V v_x12_2455 = v_field_2452;
      heff_drop(v_x12_2455);
      V v_xs_2456 = v_field_2453;
      V v_x1_2457 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2456));
      switch (heff_tag_of(v_x1_2457)) {
      case TAG_Nil: {
        v_t_2460 = ((V)&g_heff_2ebuild_2ecommands_2eownRoot_str2);
        break;
      }
      case TAG_Cons: {
        V v_x_2458 = heff_field(v_x1_2457, 0);
        heff_take_n(v_x1_2457, 1ULL, 2);
        v_t_2460 = v_x_2458;
        break;
      }
      default: heff_nomatch(v_x1_2457);
      }
    }
    v_t_2461 = heff_strEq(v_t_2460, ((V)&g_heff_2ebuild_2ecommands_2eownRoot_str3));
  } else {
    v_t_2461 = NTAG(TAG_False);
  }
  if ((heff_dup(v_t_2461) == NTAG(TAG_True))) {
    heff_drop(v_t_2461);
    HeffT3 v_t_2462 = (g_std_2epath_2eparse_24cpr(v_st_240, v_self_241));
    V v_t_2472;
    {
      V v_field_2463 = v_t_2462.f[0];
      V v_field_2464 = v_t_2462.f[1];
      V v_field_2465 = v_t_2462.f[2];
      V v_d_2466 = v_field_2463;
      V v_a_2467 = v_field_2464;
      V v_xs_2468 = v_field_2465;
      V v_t_2469 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2468));
      V v_xs_2470 = ({ V a_0 = MK_INT(1LL); V a_1 = v_t_2469; V r_ = (g_list_2edrop(a_0, a_1)); heff_drop(v_t_2469); r_; });
      V v_t_2471 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2470));
      v_t_2472 = heff_tag_n(TAG_MkPath, 3, (V[]){v_d_2466, v_a_2467, v_t_2471});
    }
    V v_s_2473 = ({ V a_0 = v_st_240; V a_1 = v_t_2472; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2472); r_; });
    HeffT3 v_t_2474 = (g_std_2epath_2eparse_24cpr(v_st_240, v_s_2473));
    V v_t_2484;
    {
      V v_field_2475 = v_t_2474.f[0];
      V v_field_2476 = v_t_2474.f[1];
      V v_field_2477 = v_t_2474.f[2];
      V v_d_2478 = v_field_2475;
      V v_a_2479 = v_field_2476;
      V v_xs_2480 = v_field_2477;
      V v_t_2481 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2480));
      V v_xs_2482 = ({ V a_0 = MK_INT(1LL); V a_1 = v_t_2481; V r_ = (g_list_2edrop(a_0, a_1)); heff_drop(v_t_2481); r_; });
      V v_t_2483 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2482));
      v_t_2484 = heff_tag_n(TAG_MkPath, 3, (V[]){v_d_2478, v_a_2479, v_t_2483});
    }
    V v_s_2485 = ({ V a_0 = v_st_240; V a_1 = v_t_2484; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2484); r_; });
    HeffT3 v_t_2486 = (g_std_2epath_2eparse_24cpr(v_st_240, v_s_2485));
    V v_t_2496;
    {
      V v_field_2487 = v_t_2486.f[0];
      V v_field_2488 = v_t_2486.f[1];
      V v_field_2489 = v_t_2486.f[2];
      V v_d_2490 = v_field_2487;
      V v_a_2491 = v_field_2488;
      V v_xs_2492 = v_field_2489;
      V v_t_2493 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2492));
      V v_xs_2494 = ({ V a_0 = MK_INT(1LL); V a_1 = v_t_2493; V r_ = (g_list_2edrop(a_0, a_1)); heff_drop(v_t_2493); r_; });
      V v_t_2495 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2494));
      v_t_2496 = heff_tag_n(TAG_MkPath, 3, (V[]){v_d_2490, v_a_2491, v_t_2495});
    }
    return ({ V a_0 = v_st_240; V a_1 = v_t_2496; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2496); r_; });
  } else {
    heff_drop(v_t_2461);
    HeffT3 v_t_2497 = (g_std_2epath_2eparse_24cpr(v_st_240, v_self_241));
    V v_t_24107;
    {
      V v_field_2498 = v_t_2497.f[0];
      V v_field_2499 = v_t_2497.f[1];
      V v_field_24100 = v_t_2497.f[2];
      V v_d_24101 = v_field_2498;
      V v_a_24102 = v_field_2499;
      V v_xs_24103 = v_field_24100;
      V v_t_24104 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_24103));
      V v_xs_24105 = ({ V a_0 = MK_INT(1LL); V a_1 = v_t_24104; V r_ = (g_list_2edrop(a_0, a_1)); heff_drop(v_t_24104); r_; });
      V v_t_24106 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_24105));
      v_t_24107 = heff_tag_n(TAG_MkPath, 3, (V[]){v_d_24101, v_a_24102, v_t_24106});
    }
    V v_s_24108 = ({ V a_0 = v_st_240; V a_1 = v_t_24107; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_24107); r_; });
    HeffT3 v_t_24109 = (g_std_2epath_2eparse_24cpr(v_st_240, v_s_24108));
    V v_t_24119;
    {
      V v_field_24110 = v_t_24109.f[0];
      V v_field_24111 = v_t_24109.f[1];
      V v_field_24112 = v_t_24109.f[2];
      V v_d_24113 = v_field_24110;
      V v_a_24114 = v_field_24111;
      V v_xs_24115 = v_field_24112;
      V v_t_24116 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_24115));
      V v_xs_24117 = ({ V a_0 = MK_INT(1LL); V a_1 = v_t_24116; V r_ = (g_list_2edrop(a_0, a_1)); heff_drop(v_t_24116); r_; });
      V v_t_24118 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_24117));
      v_t_24119 = heff_tag_n(TAG_MkPath, 3, (V[]){v_d_24113, v_a_24114, v_t_24118});
    }
    return ({ V a_0 = v_st_240; V a_1 = v_t_24119; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_24119); r_; });
  }
}
V g_heff_2ebuild_2ecommands_2eownRoot_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2eownRoot(a0, a[1]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebackDirOf_str0, 5, ".heff");
Clo g_heff_2ebuild_2ecommands_2ebackDirOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebackDirOf_entry, 1, 0};

V g_heff_2ebuild_2ecommands_2ebackDirOf(V v_ps_240) {
top: ;
  V v_st_241 = heff_dup(heff_rfield(v_ps_240, 5));
  V v_t_242 = (g_std_2epath_2eparse(v_st_241, heff_take_field(v_ps_240, 0)));
  V v_t_243 = (g_std_2epath_2eparse(v_st_241, ((V)&g_heff_2ebuild_2ecommands_2ebackDirOf_str0)));
  V v_t_244 = (g_std_2epath_2ejoin(v_t_242, v_t_243));
  V v_d_245 = ({ V a_0 = v_st_241; V a_1 = v_t_244; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_241); heff_drop(v_t_244); r_; });
  V v_st_246 = heff_get_n(v_ps_240, 5, 6);
  V v_t_247 = (g_std_2epath_2eparse(v_st_246, v_d_245));
  V v_t_248 = (g_std_2epath_2eparse(v_st_246, heff_dup(g_heff_2ebuild_2ebackcache_2ebackDir_get())));
  V v_t_249 = (g_std_2epath_2ejoin(v_t_247, v_t_248));
  return ({ V a_0 = v_st_246; V a_1 = v_t_249; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_246); heff_drop(v_t_249); r_; });
}
V g_heff_2ebuild_2ecommands_2ebackDirOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ebackDirOf(a[0]);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eappFile_str0, 3, "app");
Clo g_heff_2ebuild_2ecommands_2eappFile_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eappFile_entry, 4, 0};

V g_heff_2ebuild_2ecommands_2eappFile(V v_st_240, V v_t_241, V v_x_242, V v_f_243) {
top: ;
  V v_t_244 = (g_std_2epath_2eparse(v_st_240, ((V)&g_heff_2ebuild_2ecommands_2eappFile_str0)));
  V v_t_245 = (g_std_2epath_2eparse(v_st_240, v_x_242));
  V v_t_246 = (g_std_2epath_2ejoin(v_t_244, v_t_245));
  V v_a_247 = ({ V a_0 = v_st_240; V a_1 = v_t_246; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_246); r_; });
  V v_t_248 = (g_std_2epath_2eparse(v_st_240, v_a_247));
  V v_t_249 = (g_std_2epath_2eparse(v_st_240, v_f_243));
  V v_t_2410 = (g_std_2epath_2ejoin(v_t_248, v_t_249));
  V v_p_2411 = ({ V a_0 = v_st_240; V a_1 = v_t_2410; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2410); r_; });
  V v_t_2412 = (g_std_2epath_2eparse(v_st_240, heff_get_n(v_t_241, 0, 6)));
  V v_t_2413 = (g_std_2epath_2eparse(v_st_240, v_p_2411));
  V v_t_2414 = (g_std_2epath_2ejoin(v_t_2412, v_t_2413));
  return ({ V a_0 = v_st_240; V a_1 = v_t_2414; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2414); r_; });
}
V g_heff_2ebuild_2ecommands_2eappFile_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2eappFile(a0, a[1], a[2], a[3]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ejsonFailure_str0, 7, "because");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ejsonFailure_str1, 6, "differ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ejsonFailure_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ejsonFailure_str3, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ejsonFailure_str4, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ejsonFailure_str5, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ejsonFailure_str6, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ejsonFailure_str7, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ejsonFailure_str8, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ejsonFailure_str9, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ejsonFailure_str10, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ejsonFailure_str11, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ejsonFailure_str12, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ejsonFailure_str13, 0, "");
Clo g_heff_2ebuild_2ecommands_2ejsonFailure_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ejsonFailure_entry, 1, 0};

V g_heff_2ebuild_2ecommands_2ejsonFailure(V v_j_240) {
top: ;
  V v_t_241 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ejsonFailure_str0), NTAG(TAG_Nil)});
  HeffT2 v_t_242 = (g_json_2eat_24cpr(v_t_241, heff_dup(v_j_240)));
  {
    V v_field_244 = v_t_242.f[1];
    int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
    V v_t_2413;
    if ((v_tag_243 == ((int64_t)0ULL))) {
      V v_it1_246 = v_field_244;
      switch (heff_tag_of(v_it1_246)) {
      case TAG_JNull: {
        v_t_2413 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_JBool: {
        heff_take_n(v_it1_246, 0ULL, 1);
        v_t_2413 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_JInt: {
        heff_take_n(v_it1_246, 0ULL, 1);
        v_t_2413 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_JFloat: {
        heff_take_na(v_it1_246, 0ULL, 1);
        v_t_2413 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_JString: {
        V v_s_2410 = heff_field(v_it1_246, 0);
        V v_ru_24it1_246_24JString = heff_take_reuse_n(v_it1_246, 1ULL, 1);
        v_t_2413 = heff_tag_at_n(v_ru_24it1_246_24JString, TAG_Just, 1, (V[]){v_s_2410});
        break;
      }
      case TAG_JArray: {
        heff_take_n(v_it1_246, 0ULL, 1);
        v_t_2413 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_JObject: {
        heff_take_n(v_it1_246, 0ULL, 1);
        v_t_2413 = NTAG(TAG_Nothing);
        break;
      }
      default: heff_nomatch(v_it1_246);
      }
    } else {
      heff_drop(v_field_244);
      v_t_2413 = NTAG(TAG_Nothing);
    }
    switch (heff_tag_of(v_t_2413)) {
    case TAG_Nothing: {
      V v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ejsonFailure_str1), NTAG(TAG_Nil)});
      HeffT2 v_t_2415 = (g_json_2eat_24cpr(v_t_2414, v_j_240));
      {
        V v_field_2417 = v_t_2415.f[1];
        int64_t v_tag_2416 = ((int64_t)v_t_2415.f[0]);
        if ((v_tag_2416 == ((int64_t)0ULL))) {
          V v_it1_2419 = v_field_2417;
          switch (heff_tag_of(v_it1_2419)) {
          case TAG_JNull: {
            return NTAG(TAG_Nothing);
          }
          case TAG_JBool: {
            heff_take_n(v_it1_2419, 0ULL, 1);
            return NTAG(TAG_Nothing);
          }
          case TAG_JInt: {
            heff_take_n(v_it1_2419, 0ULL, 1);
            return NTAG(TAG_Nothing);
          }
          case TAG_JFloat: {
            heff_take_na(v_it1_2419, 0ULL, 1);
            return NTAG(TAG_Nothing);
          }
          case TAG_JString: {
            heff_take_n(v_it1_2419, 0ULL, 1);
            return NTAG(TAG_Nothing);
          }
          case TAG_JArray: {
            V v_xs_2424 = heff_field(v_it1_2419, 0);
            V v_ru_24it1_2419_24JArray = heff_take_reuse_n(v_it1_2419, 1ULL, 1);
            switch (heff_tag_of(v_xs_2424)) {
            case TAG_Nil: {
              heff_drop_cell(v_ru_24it1_2419_24JArray, 1);
              return NTAG(TAG_Nothing);
            }
            case TAG_Cons: {
              V v_expected_2425 = heff_field(v_xs_2424, 0);
              V v_it12_2426 = heff_field(v_xs_2424, 1);
              heff_take_n(v_xs_2424, 3ULL, 2);
              switch (heff_tag_of(v_it12_2426)) {
              case TAG_Nil: {
                heff_drop_cell(v_ru_24it1_2419_24JArray, 1);
                heff_drop(v_expected_2425);
                return NTAG(TAG_Nothing);
              }
              case TAG_Cons: {
                V v_got_2427 = heff_field(v_it12_2426, 0);
                heff_take_n(v_it12_2426, 1ULL, 2);
                V v_t_2435;
                switch (heff_tag_of(v_expected_2425)) {
                case TAG_JNull: {
                  v_t_2435 = ((V)&g_heff_2ebuild_2ecommands_2ejsonFailure_str2);
                  break;
                }
                case TAG_JBool: {
                  heff_take_n(v_expected_2425, 0ULL, 1);
                  v_t_2435 = ((V)&g_heff_2ebuild_2ecommands_2ejsonFailure_str3);
                  break;
                }
                case TAG_JInt: {
                  heff_take_n(v_expected_2425, 0ULL, 1);
                  v_t_2435 = ((V)&g_heff_2ebuild_2ecommands_2ejsonFailure_str4);
                  break;
                }
                case TAG_JFloat: {
                  heff_take_na(v_expected_2425, 0ULL, 1);
                  v_t_2435 = ((V)&g_heff_2ebuild_2ecommands_2ejsonFailure_str5);
                  break;
                }
                case TAG_JString: {
                  V v_t_2432 = heff_field(v_expected_2425, 0);
                  heff_take_n(v_expected_2425, 1ULL, 1);
                  v_t_2435 = v_t_2432;
                  break;
                }
                case TAG_JArray: {
                  heff_take_n(v_expected_2425, 0ULL, 1);
                  v_t_2435 = ((V)&g_heff_2ebuild_2ecommands_2ejsonFailure_str6);
                  break;
                }
                case TAG_JObject: {
                  heff_take_n(v_expected_2425, 0ULL, 1);
                  v_t_2435 = ((V)&g_heff_2ebuild_2ecommands_2ejsonFailure_str7);
                  break;
                }
                default: heff_nomatch(v_expected_2425);
                }
                V v_t_2442;
                switch (heff_tag_of(v_got_2427)) {
                case TAG_JNull: {
                  v_t_2442 = ((V)&g_heff_2ebuild_2ecommands_2ejsonFailure_str8);
                  break;
                }
                case TAG_JBool: {
                  heff_take_n(v_got_2427, 0ULL, 1);
                  v_t_2442 = ((V)&g_heff_2ebuild_2ecommands_2ejsonFailure_str9);
                  break;
                }
                case TAG_JInt: {
                  heff_take_n(v_got_2427, 0ULL, 1);
                  v_t_2442 = ((V)&g_heff_2ebuild_2ecommands_2ejsonFailure_str10);
                  break;
                }
                case TAG_JFloat: {
                  heff_take_na(v_got_2427, 0ULL, 1);
                  v_t_2442 = ((V)&g_heff_2ebuild_2ecommands_2ejsonFailure_str11);
                  break;
                }
                case TAG_JString: {
                  V v_t_2439 = heff_field(v_got_2427, 0);
                  heff_take_n(v_got_2427, 1ULL, 1);
                  v_t_2442 = v_t_2439;
                  break;
                }
                case TAG_JArray: {
                  heff_take_n(v_got_2427, 0ULL, 1);
                  v_t_2442 = ((V)&g_heff_2ebuild_2ecommands_2ejsonFailure_str12);
                  break;
                }
                case TAG_JObject: {
                  heff_take_n(v_got_2427, 0ULL, 1);
                  v_t_2442 = ((V)&g_heff_2ebuild_2ecommands_2ejsonFailure_str13);
                  break;
                }
                default: heff_nomatch(v_got_2427);
                }
                return heff_tag_at_n(v_ru_24it1_2419_24JArray, TAG_Just, 1, (V[]){heff_tag_n(TAG_FailDiffer, 2, (V[]){v_t_2435, v_t_2442})});
              }
              default: return heff_nomatch(v_it12_2426);
              }
            }
            default: return heff_nomatch(v_xs_2424);
            }
          }
          case TAG_JObject: {
            heff_take_n(v_it1_2419, 0ULL, 1);
            return NTAG(TAG_Nothing);
          }
          default: return heff_nomatch(v_it1_2419);
          }
        } else {
          heff_drop(v_field_2417);
          return NTAG(TAG_Nothing);
        }
      }
    }
    case TAG_Just: {
      V v_why_2444 = heff_field(v_t_2413, 0);
      V v_ru_24t_2413_24Just = heff_take_reuse_n(v_t_2413, 1ULL, 1);
      heff_drop(v_j_240);
      return heff_tag_at_n(v_ru_24t_2413_24Just, TAG_Just, 1, (V[]){heff_tag_n(TAG_FailBecause, 1, (V[]){v_why_2444})});
    }
    default: return heff_nomatch(v_t_2413);
    }
  }
}
V g_heff_2ebuild_2ecommands_2ejsonFailure_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ejsonFailure(a[0]);
}
Clo g_heff_2ebuild_2ecommands_2eplaceBefore_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eplaceBefore_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2eplaceBefore(V v_x1_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_a_242 = heff_field(v_x1_240, 0);
    V v_argv_243 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      return NTAG(TAG_False);
    }
    case TAG_Cons: {
      V v_b_244 = heff_field(v_x2_241, 0);
      V v_bs_245 = heff_field(v_x2_241, 1);
      if (heff_intEq_c_lent(v_a_242, v_b_244, 0)) {
        V t_0 = v_argv_243;
        V t_1 = v_bs_245;
        v_x1_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      } else {
        return heff_intLt_lent(v_a_242, v_b_244, 0);
      }
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2ecommands_2eplaceBefore_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ebuild_2ecommands_2eplaceBefore(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestArgs_str0, 6, "--seed");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestArgs_str1, 5, "--run");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestArgs_str2, 6, "--jobs");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestArgs_str3, 4, "test");
Clo g_heff_2ebuild_2ecommands_2etestArgs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2etestArgs_entry, 4, 0};

V g_heff_2ebuild_2ecommands_2etestArgs(V v_seed_240, V v_pattern_241, V v_jobs_242, V v_given_243) {
top: ;
  V v_t_246;
  switch (heff_tag_of(v_seed_240)) {
  case TAG_Nothing: {
    v_t_246 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_v_244 = heff_field(v_seed_240, 0);
    V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_v_244), NTAG(TAG_Nil)});
    v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2etestArgs_str0), v_t_245});
    break;
  }
  default: heff_nomatch(v_seed_240);
  }
  V v_t_249;
  switch (heff_tag_of(v_pattern_241)) {
  case TAG_Nothing: {
    v_t_249 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_v_247 = heff_field(v_pattern_241, 0);
    V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_v_247), NTAG(TAG_Nil)});
    v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2etestArgs_str1), v_t_248});
    break;
  }
  default: heff_nomatch(v_pattern_241);
  }
  V v_t_2412;
  switch (heff_tag_of(v_jobs_242)) {
  case TAG_Nothing: {
    v_t_2412 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_v_2410 = heff_field(v_jobs_242, 0);
    V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_v_2410), NTAG(TAG_Nil)});
    v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2etestArgs_str2), v_t_2411});
    break;
  }
  default: heff_nomatch(v_jobs_242);
  }
  V v_t_2413 = (g_prelude_2e_2b_2b(v_t_2412, v_given_243));
  V v_t_2414 = (g_prelude_2e_2b_2b(v_t_249, v_t_2413));
  V v_t_2415 = (g_prelude_2e_2b_2b(v_t_246, v_t_2414));
  return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2etestArgs_str3), v_t_2415});
}
V g_heff_2ebuild_2ecommands_2etestArgs_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V r = g_heff_2ebuild_2ecommands_2etestArgs(a0, a1, a2, a[3]); heff_drop(a0); heff_drop(a1); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestText_str0, 7, "import ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestText_str1, 9, ".greeting");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestText_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestText_str3, 8, "greets =");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestText_str4, 64, "  unit \"greeting\" (assertEqual (greeting \"test\") \"Hello, test!\")");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestText_str5, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestText_str6, 13, "greets : Test");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestText_str7, 12, "import check");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestText_str8, 20, "module test.greeting");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestText_str9, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestText_str10, 9, "-- tests.");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestText_str11, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestText_str12, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestText_str13, 68, "-- `heff test` runs the tests of every file of test/ (and src/): the");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestText_str14, 71, "-- definitions of type `Test` (lib/check.hf), after the watches and doc");
Clo g_heff_2ebuild_2ecommands_2etestText_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2etestText_entry, 1, 0};

V g_heff_2ebuild_2ecommands_2etestText(V v_name_240) {
top: ;
  V v_t_241 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2etestText_str0), heff_strAppend(v_name_240, ((V)&g_heff_2ebuild_2ecommands_2etestText_str1)));
  V v_t_242 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2etestText_str2), NTAG(TAG_Nil)});
  V v_t_243 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2etestText_str3), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2etestText_str4), v_t_242})});
  V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2etestText_str5), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2etestText_str6), v_t_243})});
  V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2etestText_str7), heff_tag_n(TAG_Cons, 2, (V[]){v_t_241, v_t_244})});
  V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2etestText_str8), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2etestText_str9), v_t_245})});
  V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2etestText_str10), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2etestText_str11), v_t_246})});
  return ({ V a_0 = ((V)&g_heff_2ebuild_2ecommands_2etestText_str12); V a_1 = ((V)&g_heff_2ebuild_2ecommands_2etestText_str13); V b_2 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2etestText_str14), v_t_247}); V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, b_2)); heff_drop(b_2); r_; });
}
V g_heff_2ebuild_2ecommands_2etestText_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2etestText(a[0]);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileFoundC_24s2017760430x1267524453_str0, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileFoundC_24s2017760430x1267524453_str1, 6, "heff: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileFoundC_24s2017760430x1267524453_str2, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileFoundC_24s2017760430x1267524453_str3, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileFoundC_24s2017760430x1267524453_str4, 6, "heff: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileFoundC_24s2017760430x1267524453_str5, 1, "/");
V g_heff_2ebuild_2ecommands_2ecompileFoundC_24s2017760430x1267524453_lam0(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileFoundC_24s2017760430x1267524453_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileFoundC_24s2017760430x1267524453_lam2(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ecompileFoundC_24s2017760430x1267524453_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecompileFoundC_24s2017760430x1267524453_entry, 11, 0};

V g_heff_2ebuild_2ecommands_2ecompileFoundC_24s2017760430x1267524453(V v_bi_240, V v_file_241, V v_name_242, V v_outPath_243, V v_rt_244, V v_failed_245, V v_done_246, V v_c_247, V v_available_248, V v_z_249, V v_z_2410) {
top: ;
  V v_t_2411 = (g_list_2ekeepIf_24s1800580503x895008059(heff_dup(heff_rfield(v_c_247, 7))));
  V v_t_2419 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileFoundC_24s2017760430x1267524453_lam0, 1, 1, (V[]){heff_dup(v_c_247)}), v_t_2411));
  V v_t_2420 = (g_heff_2ebuild_2edriver_2ecatMaybesD(v_t_2419));
  V v_t_2421 = ({ V a_0 = v_t_2420; V r_ = (g_heff_2ebuild_2edriver_2ecandLeaves(a_0)); heff_drop(v_t_2420); r_; });
  V v_t_2422 = (g_heff_2ebuild_2edriver_2enubStrD(v_t_2421));
  V v_t_2424 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileFoundC_24s2017760430x1267524453_lam1, 1, 1, (V[]){heff_dup(v_available_248)}), v_t_2422));
  HeffT2 v_t_2425 = ({ V a_0 = v_t_2424; V a_1 = heff_dup(v_c_247); V a_2 = v_name_242; HeffT2 r_ = (g_heff_2ebuild_2edriver_2efindRunnable_24cpr(a_0, a_1, a_2)); heff_drop(v_t_2424); r_; });
  {
    V v_field_2427 = v_t_2425.f[1];
    int64_t v_tag_2426 = ((int64_t)v_t_2425.f[0]);
    if ((v_tag_2426 == ((int64_t)0ULL))) {
      heff_drop(v_bi_240);
      heff_drop(v_outPath_243);
      heff_drop_rec(v_rt_244, 2);
      heff_drop(v_done_246);
      heff_drop_rec(v_c_247, 14);
      heff_drop(v_available_248);
      V v_why_2429 = v_field_2427;
      V v_t_2430 = heff_strAppend(heff_dup(v_file_241), heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ecompileFoundC_24s2017760430x1267524453_str0), heff_dup(v_why_2429)));
      V v_t_2431 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ecompileFoundC_24s2017760430x1267524453_str1), v_t_2430), ((V)&g_heff_2ebuild_2ecommands_2ecompileFoundC_24s2017760430x1267524453_str2));
      V v_t_2432 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2431, NTAG(TAG_MkUnit)});
      V v_t_2433 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2432})});
      V v_t_2434 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2433})});
      V v_t_2435 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2434})});
      V v_t_2436 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2435})});
      V v_t_2437 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2436})});
      V v_t_2438 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2437})});
      return (g_co_2eop_24s615738393x1686646143(heff_tag_n(TAG_InR, 1, (V[]){v_t_2438}), heff_dup(v_z_249), heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileFoundC_24s2017760430x1267524453_lam2, 1, 5, (V[]){v_file_241, v_why_2429, v_failed_245, v_z_249, v_z_2410})));
    } else {
      heff_drop(v_file_241);
      heff_drop(v_failed_245);
      V v_r_2441 = v_field_2427;
      int64_t v_t_2442 = (heff_unbox_word(heff_strLength_lent(v_outPath_243, 0)) - ((int64_t)1ULL));
      V v_t_2443 = heff_strSlice(heff_dup(v_outPath_243), heff_box_word(v_t_2442), heff_strLength_lent(v_outPath_243, 0));
      if (heff_strEq_c(v_t_2443, ((V)&g_heff_2ebuild_2ecommands_2ecompileFoundC_24s2017760430x1267524453_str5))) {
        int64_t v_t_2445 = (heff_unbox_word(heff_strLength_lent(v_outPath_243, 0)) - ((int64_t)1ULL));
        return (g_heff_2ebuild_2ecommands_2ekeptParts_24s1926203457x1297589184(v_bi_240, heff_strSlice(v_outPath_243, MK_INT(0LL), heff_box_word(v_t_2445)), v_rt_244, v_done_246, v_c_247, v_available_248, v_r_2441, v_z_249, v_z_2410));
      } else {
        heff_drop(v_bi_240);
        V v_t_2446 = (g_list_2eany_24s762674996x1009180162(v_available_248));
        V v_t_2447;
        if ((heff_dup(v_t_2446) == NTAG(TAG_True))) {
          heff_drop(v_t_2446);
          v_t_2447 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(g_heff_2ecompile_2eemitc_2ethreadsLine_get()), NTAG(TAG_Nil)});
        } else {
          heff_drop(v_t_2446);
          v_t_2447 = NTAG(TAG_Nil);
        }
        V v_t_2448 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eemitc_2erunEnd_clo), 1, (V[]){heff_take_field(v_r_2441, 1)}));
        V v_t_2449 = heff_get_n(heff_get_n(v_c_247, 5, 14), 0, 9);
        V v_t_2450 = (g_heff_2ecompile_2elower_2elowerProgramC(v_t_2449, heff_get_n(v_r_2441, 0, 2)));
        V v_t_2451 = (g_heff_2ecompile_2eemitc_2eoutputOf(heff_take_field(v_rt_244, 0), v_available_248, heff_rec_n(2, shape_prefix__end, (V[]){v_t_2447, v_t_2448}), v_t_2450));
        return (g_heff_2ebuild_2ecommands_2ewriteOutC_24s1877451407x355012956(v_outPath_243, heff_get_n(v_rt_244, 1, 2), v_done_246, v_t_2451, v_z_249, v_z_2410));
      }
    }
  }
}
V g_heff_2ebuild_2ecommands_2ecompileFoundC_24s2017760430x1267524453_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ebuild_2ecommands_2ecompileFoundC_24s2017760430x1267524453(a[0], a[1], a2, a[3], a[4], a[5], a[6], a[7], a[8], a[9], a[10]); heff_drop(a2); return r;
}
V g_heff_2ebuild_2ecommands_2ecompileFoundC_24s2017760430x1267524453_lam0(V self, V *args) {
  V v_o_2412 = args[0];
  V v_c_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2413 = (g_heff_2ebuild_2edriver_2eeffectOfKey_24cpr(v_c_247, heff_rfield(v_o_2412, 1)));
  {
    V v_field_2415 = v_t_2413.f[1];
    int64_t v_tag_2414 = ((int64_t)v_t_2413.f[0]);
    if ((v_tag_2414 == ((int64_t)0ULL))) {
      V v_eff_2417 = v_field_2415;
      V v_t_2418 = heff_rec_n(3, shape_name__key__effect, (V[]){heff_take_field(v_o_2412, 0), heff_get_n(v_o_2412, 1, 2), v_eff_2417});
      return heff_tag_n(TAG_Just, 1, (V[]){v_t_2418});
    } else {
      heff_drop_rec(v_o_2412, 2);
      heff_drop(v_field_2415);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_heff_2ebuild_2ecommands_2ecompileFoundC_24s2017760430x1267524453_lam1(V self, V *args) {
  V v_k_2423 = args[0];
  V v_available_248 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_available_248; V a_1 = v_k_2423; V r_ = (g_heff_2ebuild_2ecommands_2eprovidesLeafC(a_0, a_1)); heff_drop(v_available_248); r_; });
}
V g_heff_2ebuild_2ecommands_2ecompileFoundC_24s2017760430x1267524453_lam2(V self, V *args) {
  V v_x_2439 = args[0];
  V v_file_241 = heff_env(self)[0];
  V v_why_2429 = heff_env(self)[1];
  V v_failed_245 = heff_env(self)[2];
  V v_z_249 = heff_env(self)[3];
  V v_z_2410 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2439);
  V v_t_2440 = heff_strAppend(v_file_241, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ecompileFoundC_24s2017760430x1267524453_str3), v_why_2429));
  V f_ = v_failed_245;
  heff_room[0] = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ecompileFoundC_24s2017760430x1267524453_str4), v_t_2440);
  heff_room[1] = v_z_249;
  heff_room[2] = v_z_2410;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestsWatched_24s554924703x912466171_str0, 46, "heff test: --watch is not given with --update\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestsWatched_24s554924703x912466171_str1, 5, "win32");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestsWatched_24s554924703x912466171_str2, 4, "test");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestsWatched_24s554924703x912466171_str3, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestsWatched_24s554924703x912466171_str4, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestsWatched_24s554924703x912466171_str5, 4, "test");
V g_heff_2ebuild_2ecommands_2etestsWatched_24s554924703x912466171_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestsWatched_24s554924703x912466171_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2etestsWatched_24s554924703x912466171_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2etestsWatched_24s554924703x912466171_lam0, 2, 0};
V g_heff_2ebuild_2ecommands_2etestsWatched_24s554924703x912466171_lam5(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2etestsWatched_24s554924703x912466171_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2etestsWatched_24s554924703x912466171_lam5, 1, 0};
V g_heff_2ebuild_2ecommands_2etestsWatched_24s554924703x912466171_lam8(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestsWatched_24s554924703x912466171_lam7(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestsWatched_24s554924703x912466171_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestsWatched_24s554924703x912466171_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestsWatched_24s554924703x912466171_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestsWatched_24s554924703x912466171_lam2(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2etestsWatched_24s554924703x912466171_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2etestsWatched_24s554924703x912466171_entry, 7, 0};

V g_heff_2ebuild_2ecommands_2etestsWatched_24s554924703x912466171(V v_clock_240, V v_ex_241, V v_seed_242, V v_pattern_243, V v_jobs_244, V v_x4_245, V v_given_246) {
top: ;
  if ((heff_dup(v_x4_245) == NTAG(TAG_True))) {
    heff_drop(v_clock_240);
    heff_drop(v_ex_241);
    heff_drop(v_given_246);
    return ((V)&g_heff_2ebuild_2ecommands_2etestsWatched_24s554924703x912466171_lam0_clo);
  } else {
    V v_c_2424 = (g_heff_2ebuild_2ecommands_2etestOptions_24s1937373887x2047139729(v_seed_242, v_pattern_243, v_jobs_244, NTAG(TAG_False)));
    return heff_clo_n(g_heff_2ebuild_2ecommands_2etestsWatched_24s554924703x912466171_lam2, 2, 7, (V[]){v_c_2424, v_given_246, heff_dup(v_seed_242), heff_dup(v_pattern_243), heff_dup(v_jobs_244), v_ex_241, v_clock_240});
  }
}
V g_heff_2ebuild_2ecommands_2etestsWatched_24s554924703x912466171_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V a3 = a[3]; V a4 = a[4]; V a5 = a[5]; V r = g_heff_2ebuild_2ecommands_2etestsWatched_24s554924703x912466171(a[0], a[1], a2, a3, a4, a5, a[6]); heff_drop(a2); heff_drop(a3); heff_drop(a4); heff_drop(a5); return r;
}
V g_heff_2ebuild_2ecommands_2etestsWatched_24s554924703x912466171_lam1(V self, V *args) {
  V v_x_2416 = args[0];
  V v_hd_247 = heff_env(self)[0];
  V v_k_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2416);
  V v_t_2417 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(2LL), NTAG(TAG_MkUnit)});
  V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
  V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
  V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
  V v_t_2423 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2422})});
  return (g_co_2eop_24s615738393x1686646143(heff_tag_n(TAG_InR, 1, (V[]){v_t_2423}), v_hd_247, v_k_248));
}
V g_heff_2ebuild_2ecommands_2etestsWatched_24s554924703x912466171_lam0(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_t_249 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2etestsWatched_24s554924703x912466171_str0), NTAG(TAG_MkUnit)});
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
  V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
  V v_t_2415 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2414})});
  return (g_co_2eop_24s615738393x1686646143(heff_tag_n(TAG_InR, 1, (V[]){v_t_2415}), heff_dup(v_hd_247), heff_clo_n(g_heff_2ebuild_2ecommands_2etestsWatched_24s554924703x912466171_lam1, 1, 2, (V[]){v_hd_247, v_k_248})));
}
V g_heff_2ebuild_2ecommands_2etestsWatched_24s554924703x912466171_lam5(V self, V *args) {
  V v_s_2430 = args[0];
  return v_s_2430;
}
V g_heff_2ebuild_2ecommands_2etestsWatched_24s554924703x912466171_lam8(V self, V *args) {
  V v_x_2450 = args[0];
  V v_given_246 = heff_env(self)[0];
  V v_seed_242 = heff_env(self)[1];
  V v_pattern_243 = heff_env(self)[2];
  V v_jobs_244 = heff_env(self)[3];
  V v_ex_241 = heff_env(self)[4];
  V v_clock_240 = heff_env(self)[5];
  V v_st_2440 = heff_env(self)[6];
  V v_x_2448 = heff_env(self)[7];
  V v_hd_2425 = heff_env(self)[8];
  V v_k_2426 = heff_env(self)[9];
  heff_clo_take(self, 10);
  V v_t_2453;
  switch (heff_tag_of(v_given_246)) {
  case TAG_Nil: {
    v_t_2453 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2etestsWatched_24s554924703x912466171_str5), heff_dup(g_heff_2ebuild_2ewatch_2eproject_get())});
    break;
  }
  case TAG_Cons: {
    v_t_2453 = (g_prelude_2e_2b_2b(heff_dup(v_given_246), heff_dup(g_heff_2ebuild_2ewatch_2eproject_get())));
    break;
  }
  default: heff_nomatch(v_given_246);
  }
  V v_t_2454 = ({ V a_0 = v_seed_242; V a_1 = v_pattern_243; V a_2 = v_jobs_244; V a_3 = v_given_246; V r_ = (g_heff_2ebuild_2ecommands_2etestArgs(a_0, a_1, a_2, a_3)); heff_drop(v_seed_242); heff_drop(v_pattern_243); heff_drop(v_jobs_244); r_; });
  V v_t_2455 = heff_tr(heff_call(((V)&g_heff_2ebuild_2ecommands_2etestedAgain_24s1918345756x1218238789_clo), 2, (V[]){v_ex_241, v_t_2454}));
  return ({ V a_0 = v_clock_240; V a_1 = v_st_2440; V a_2 = v_t_2453; V a_3 = v_t_2455; V a_4 = v_x_2448; V a_5 = v_x_2450; V a_6 = v_hd_2425; V a_7 = v_k_2426; V r_ = (g_heff_2ebuild_2ewatch_2ewatchOver_24s1555981406x1212401230(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_st_2440); heff_drop(v_x_2448); heff_drop(v_k_2426); r_; });
}
V g_heff_2ebuild_2ecommands_2etestsWatched_24s554924703x912466171_lam7(V self, V *args) {
  V v_x_2445 = args[0];
  V v_seed_242 = heff_env(self)[0];
  V v_pattern_243 = heff_env(self)[1];
  V v_jobs_244 = heff_env(self)[2];
  V v_given_246 = heff_env(self)[3];
  V v_ex_241 = heff_env(self)[4];
  V v_hd_2425 = heff_env(self)[5];
  V v_clock_240 = heff_env(self)[6];
  V v_st_2440 = heff_env(self)[7];
  V v_k_2426 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_x_2448;
  switch (heff_tag_of(v_x_2445)) {
  case TAG_Nil: {
    v_x_2448 = ((V)&g_heff_2ebuild_2ecommands_2etestsWatched_24s554924703x912466171_str3);
    break;
  }
  case TAG_Cons: {
    V v_x_2446 = heff_field(v_x_2445, 0);
    V v_xs_2447 = heff_field(v_x_2445, 1);
    heff_take_n(v_x_2445, 3ULL, 2);
    v_x_2448 = ({ V a_0 = ((V)&g_heff_2ebuild_2ecommands_2etestsWatched_24s554924703x912466171_str4); V a_1 = v_x_2446; V a_2 = v_xs_2447; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2447); r_; });
    break;
  }
  default: heff_nomatch(v_x_2445);
  }
  V v_t_2449 = (g_heff_2ebuild_2ecommands_2etestArgs(v_seed_242, v_pattern_243, v_jobs_244, heff_dup(v_given_246)));
  return (g_heff_2ebuild_2ecommands_2etestedAgain_24s1026021682x2082722655(heff_dup(v_ex_241), v_t_2449, MK_INT(0LL), heff_dup(v_hd_2425), heff_clo_n(g_heff_2ebuild_2ecommands_2etestsWatched_24s554924703x912466171_lam8, 1, 10, (V[]){v_given_246, v_seed_242, v_pattern_243, v_jobs_244, v_ex_241, v_clock_240, v_st_2440, v_x_2448, v_hd_2425, v_k_2426})));
}
V g_heff_2ebuild_2ecommands_2etestsWatched_24s554924703x912466171_lam6(V self, V *args) {
  V v_x_2438 = args[0];
  V v_given_246 = heff_env(self)[0];
  V v_hd_2425 = heff_env(self)[1];
  V v_seed_242 = heff_env(self)[2];
  V v_pattern_243 = heff_env(self)[3];
  V v_jobs_244 = heff_env(self)[4];
  V v_ex_241 = heff_env(self)[5];
  V v_clock_240 = heff_env(self)[6];
  V v_k_2426 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_st_2440;
  if (heff_strEq_c(v_x_2438, ((V)&g_heff_2ebuild_2ecommands_2etestsWatched_24s554924703x912466171_str1))) {
    v_st_2440 = NTAG(TAG_Windows);
  } else {
    v_st_2440 = NTAG(TAG_Posix);
  }
  V v_paths_2443;
  switch (heff_tag_of(v_given_246)) {
  case TAG_Nil: {
    v_paths_2443 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2etestsWatched_24s554924703x912466171_str2), heff_dup(g_heff_2ebuild_2ewatch_2eproject_get())});
    break;
  }
  case TAG_Cons: {
    v_paths_2443 = (g_prelude_2e_2b_2b(heff_dup(v_given_246), heff_dup(g_heff_2ebuild_2ewatch_2eproject_get())));
    break;
  }
  default: heff_nomatch(v_given_246);
  }
  V v_c_2444 = (g_heff_2ebuild_2ewatch_2estamps_24s1980481423x537134380(v_st_2440, NTAG(TAG_Nil), v_paths_2443));
  V f_ = v_c_2444;
  heff_room[0] = heff_dup(v_hd_2425);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2etestsWatched_24s554924703x912466171_lam7, 1, 9, (V[]){v_seed_242, v_pattern_243, v_jobs_244, v_given_246, v_ex_241, v_hd_2425, v_clock_240, v_st_2440, v_k_2426});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2etestsWatched_24s554924703x912466171_lam4(V self, V *args) {
  V v_x_2429 = args[0];
  V v_hd_2425 = heff_env(self)[0];
  V v_given_246 = heff_env(self)[1];
  V v_seed_242 = heff_env(self)[2];
  V v_pattern_243 = heff_env(self)[3];
  V v_jobs_244 = heff_env(self)[4];
  V v_ex_241 = heff_env(self)[5];
  V v_clock_240 = heff_env(self)[6];
  V v_k_2426 = heff_env(self)[7];
  heff_clo_take(self, 8);
  heff_drop(v_x_2429);
  V v_t_2431 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2etestsWatched_24s554924703x912466171_lam5_clo)})});
  V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
  V v_t_2433 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2432})});
  V v_t_2434 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2433})});
  V v_t_2435 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2434})});
  V v_t_2436 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2435})});
  V v_t_2437 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2436})});
  return (g_co_2eop_24s615738393x1686646143(v_t_2437, heff_dup(v_hd_2425), heff_clo_n(g_heff_2ebuild_2ecommands_2etestsWatched_24s554924703x912466171_lam6, 1, 8, (V[]){v_given_246, v_hd_2425, v_seed_242, v_pattern_243, v_jobs_244, v_ex_241, v_clock_240, v_k_2426})));
}
V g_heff_2ebuild_2ecommands_2etestsWatched_24s554924703x912466171_lam3(V self, V *args) {
  V v_x_2427 = args[0];
  V v_given_246 = heff_env(self)[0];
  V v_hd_2425 = heff_env(self)[1];
  V v_seed_242 = heff_env(self)[2];
  V v_pattern_243 = heff_env(self)[3];
  V v_jobs_244 = heff_env(self)[4];
  V v_ex_241 = heff_env(self)[5];
  V v_clock_240 = heff_env(self)[6];
  V v_k_2426 = heff_env(self)[7];
  heff_clo_take(self, 8);
  heff_drop(v_x_2427);
  V v_c_2428 = (g_heff_2ebuild_2ecommands_2etestFiles_24s1079562655x2127217752(heff_dup(v_given_246)));
  V f_ = v_c_2428;
  heff_room[0] = heff_dup(v_hd_2425);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2etestsWatched_24s554924703x912466171_lam4, 1, 8, (V[]){v_hd_2425, v_given_246, v_seed_242, v_pattern_243, v_jobs_244, v_ex_241, v_clock_240, v_k_2426});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2etestsWatched_24s554924703x912466171_lam2(V self, V *args) {
  V v_hd_2425 = args[0];
  V v_k_2426 = args[1];
  V v_c_2424 = heff_env(self)[0];
  V v_given_246 = heff_env(self)[1];
  V v_seed_242 = heff_env(self)[2];
  V v_pattern_243 = heff_env(self)[3];
  V v_jobs_244 = heff_env(self)[4];
  V v_ex_241 = heff_env(self)[5];
  V v_clock_240 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V f_ = v_c_2424;
  args[0] = heff_dup(v_hd_2425);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2etestsWatched_24s554924703x912466171_lam3, 1, 8, (V[]){v_given_246, v_hd_2425, v_seed_242, v_pattern_243, v_jobs_244, v_ex_241, v_clock_240, v_k_2426});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileFound_24s1945822963x1352587118_str0, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileFound_24s1945822963x1352587118_str1, 6, "heff: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileFound_24s1945822963x1352587118_str2, 1, "\012");
V g_heff_2ebuild_2ecommands_2ecompileFound_24s1945822963x1352587118_lam0(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileFound_24s1945822963x1352587118_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileFound_24s1945822963x1352587118_lam2(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ecompileFound_24s1945822963x1352587118_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecompileFound_24s1945822963x1352587118_entry, 9, 0};

V g_heff_2ebuild_2ecommands_2ecompileFound_24s1945822963x1352587118(V v_bi_240, V v_file_241, V v_name_242, V v_outPath_243, V v_done_244, V v_c_245, V v_available_246, V v_z_247, V v_z_248) {
top: ;
  V v_t_249 = (g_list_2ekeepIf_24s1800580503x895008059(heff_dup(heff_rfield(v_c_245, 7))));
  V v_t_2417 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileFound_24s1945822963x1352587118_lam0, 1, 1, (V[]){heff_dup(v_c_245)}), v_t_249));
  V v_t_2418 = (g_heff_2ebuild_2edriver_2ecatMaybesD(v_t_2417));
  V v_t_2419 = ({ V a_0 = v_t_2418; V r_ = (g_heff_2ebuild_2edriver_2ecandLeaves(a_0)); heff_drop(v_t_2418); r_; });
  V v_t_2420 = (g_heff_2ebuild_2edriver_2enubStrD(v_t_2419));
  V v_t_2422 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileFound_24s1945822963x1352587118_lam1, 1, 1, (V[]){heff_dup(v_available_246)}), v_t_2420));
  HeffT2 v_t_2423 = ({ V a_0 = v_t_2422; V a_1 = heff_dup(v_c_245); V a_2 = v_name_242; HeffT2 r_ = (g_heff_2ebuild_2edriver_2efindRunnable_24cpr(a_0, a_1, a_2)); heff_drop(v_t_2422); r_; });
  {
    V v_field_2425 = v_t_2423.f[1];
    int64_t v_tag_2424 = ((int64_t)v_t_2423.f[0]);
    if ((v_tag_2424 == ((int64_t)0ULL))) {
      heff_drop(v_bi_240);
      heff_drop(v_outPath_243);
      heff_drop(v_done_244);
      heff_drop_rec(v_c_245, 14);
      heff_drop(v_available_246);
      V v_why_2427 = v_field_2425;
      V v_t_2428 = heff_strAppend(v_file_241, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ecompileFound_24s1945822963x1352587118_str0), v_why_2427));
      V v_t_2429 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ecompileFound_24s1945822963x1352587118_str1), v_t_2428), ((V)&g_heff_2ebuild_2ecommands_2ecompileFound_24s1945822963x1352587118_str2));
      V v_t_2430 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2429, NTAG(TAG_MkUnit)});
      V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
      V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
      V v_t_2433 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2432})});
      V v_t_2434 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2433})});
      V v_t_2435 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2434})});
      V v_t_2436 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2435})});
      return (g_co_2eop_24s615738393x1686646143(heff_tag_n(TAG_InR, 1, (V[]){v_t_2436}), heff_dup(v_z_247), heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileFound_24s1945822963x1352587118_lam2, 1, 2, (V[]){v_z_247, v_z_248})));
    } else {
      heff_drop(v_file_241);
      V v_r_2445 = v_field_2425;
      return (g_heff_2ebuild_2ecommands_2ejsKept_24s1060797234x1576735494(v_bi_240, v_outPath_243, v_done_244, v_c_245, v_available_246, v_r_2445, v_z_247, v_z_248));
    }
  }
}
V g_heff_2ebuild_2ecommands_2ecompileFound_24s1945822963x1352587118_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ebuild_2ecommands_2ecompileFound_24s1945822963x1352587118(a[0], a[1], a2, a[3], a[4], a[5], a[6], a[7], a[8]); heff_drop(a2); return r;
}
V g_heff_2ebuild_2ecommands_2ecompileFound_24s1945822963x1352587118_lam0(V self, V *args) {
  V v_o_2410 = args[0];
  V v_c_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2411 = (g_heff_2ebuild_2edriver_2eeffectOfKey_24cpr(v_c_245, heff_rfield(v_o_2410, 1)));
  {
    V v_field_2413 = v_t_2411.f[1];
    int64_t v_tag_2412 = ((int64_t)v_t_2411.f[0]);
    if ((v_tag_2412 == ((int64_t)0ULL))) {
      V v_eff_2415 = v_field_2413;
      V v_t_2416 = heff_rec_n(3, shape_name__key__effect, (V[]){heff_take_field(v_o_2410, 0), heff_get_n(v_o_2410, 1, 2), v_eff_2415});
      return heff_tag_n(TAG_Just, 1, (V[]){v_t_2416});
    } else {
      heff_drop_rec(v_o_2410, 2);
      heff_drop(v_field_2413);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_heff_2ebuild_2ecommands_2ecompileFound_24s1945822963x1352587118_lam1(V self, V *args) {
  V v_k_2421 = args[0];
  V v_available_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_available_246; V a_1 = v_k_2421; V r_ = (g_heff_2ebuild_2ecommands_2eprovidesLeaf(a_0, a_1)); heff_drop(v_available_246); r_; });
}
V g_heff_2ebuild_2ecommands_2ecompileFound_24s1945822963x1352587118_lam2(V self, V *args) {
  V v_x_2437 = args[0];
  V v_z_247 = heff_env(self)[0];
  V v_z_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2437);
  V v_t_2438 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2439 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2438})});
  V v_t_2440 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2439})});
  V v_t_2441 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2440})});
  V v_t_2442 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2441})});
  V v_t_2443 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2442})});
  V v_t_2444 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2443})});
  return (g_co_2eop_24s615738393x1686646143(heff_tag_n(TAG_InR, 1, (V[]){v_t_2444}), v_z_247, v_z_248));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetchedPkg_24s1462621892x1253896370_str0, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetchedPkg_24s1462621892x1253896370_str1, 1, " ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetchedPkg_24s1462621892x1253896370_str2, 10, " requires ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetchedPkg_24s1462621892x1253896370_str3, 1, "-");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetchedPkg_24s1462621892x1253896370_str4, 1, "-");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetchedPkg_24s1462621892x1253896370_str5, 23, ": its commit is another");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetchedPkg_24s1462621892x1253896370_str6, 24, ": its tag has been moved");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetchedPkg_24s1462621892x1253896370_str7, 20, ", and heff.sum says ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetchedPkg_24s1462621892x1253896370_str8, 4, " is ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetchedPkg_24s1462621892x1253896370_str9, 1, " ");
V g_heff_2ebuild_2ecommands_2efetchedPkg_24s1462621892x1253896370_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2efetchedPkg_24s1462621892x1253896370_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2efetchedPkg_24s1462621892x1253896370_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2efetchedPkg_24s1462621892x1253896370_entry, 7, 0};

V g_heff_2ebuild_2ecommands_2efetchedPkg_24s1462621892x1253896370(V v_prog_240, V v_ps_241, V v_root_242, V v_sums_243, V v_by_244, V v_path_245, V v_v_246) {
top: ;
  V v_t_247 = (g_list_2ekeepIf_24s684755021x1118425975(v_path_245, heff_take_field(v_root_242, 2)));
  V v_t_2413;
  switch (heff_tag_of(v_t_247)) {
  case TAG_Nil: {
    heff_drop_rec(v_root_242, 4);
    v_t_2413 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Cons: {
    V v_r_248 = heff_field(v_t_247, 0);
    heff_take_n(v_t_247, 1ULL, 2);
    V v_t_2410 = (g_list_2ekeepIf_24s1511525408x973271992(v_r_248, heff_get_n(v_root_242, 3, 4)));
    switch (heff_tag_of(v_t_2410)) {
    case TAG_Nil: {
      v_t_2413 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Cons: {
      V v_p_2411 = heff_field(v_t_2410, 0);
      heff_take_n(v_t_2410, 1ULL, 2);
      v_t_2413 = heff_tag_n(TAG_Just, 1, (V[]){heff_get_n(v_p_2411, 1, 2)});
      break;
    }
    default: heff_nomatch(v_t_2410);
    }
    break;
  }
  default: heff_nomatch(v_t_247);
  }
  switch (heff_tag_of(v_t_2413)) {
  case TAG_Nothing: {
    V v_c_2414 = (g_heff_2ebuild_2ecommands_2efetched_24s1119541509x2002282382(v_prog_240, heff_dup(v_ps_241), heff_dup(v_path_245), heff_dup(v_v_246)));
    return heff_clo_n(g_heff_2ebuild_2ecommands_2efetchedPkg_24s1462621892x1253896370_lam0, 2, 6, (V[]){v_c_2414, v_v_246, v_path_245, v_by_244, v_sums_243, v_ps_241});
  }
  case TAG_Just: {
    V v_d_2443 = heff_field(v_t_2413, 0);
    heff_take_n(v_t_2413, 1ULL, 1);
    heff_drop(v_prog_240);
    heff_drop(v_sums_243);
    heff_drop(v_by_244);
    heff_drop(v_v_246);
    V v_st_2444 = heff_dup(heff_rfield(v_ps_241, 5));
    V v_t_2445 = (g_std_2epath_2eparse(v_st_2444, heff_dup(heff_rfield(v_ps_241, 0))));
    V v_t_2446 = (g_std_2epath_2eparse(v_st_2444, v_d_2443));
    V v_t_2447 = (g_std_2epath_2ejoin(v_t_2445, v_t_2446));
    V v_t_2448 = ({ V a_0 = v_st_2444; V a_1 = v_t_2447; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2444); heff_drop(v_t_2447); r_; });
    return (g_heff_2ebuild_2eload_2ereadPkgAt_24s1971503388x1740917138(v_ps_241, v_t_2448, v_path_245));
  }
  default: return heff_nomatch(v_t_2413);
  }
}
V g_heff_2ebuild_2ecommands_2efetchedPkg_24s1462621892x1253896370_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2efetchedPkg_24s1462621892x1253896370(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
V g_heff_2ebuild_2ecommands_2efetchedPkg_24s1462621892x1253896370_lam1(V self, V *args) {
  V v_x_2417 = args[0];
  V v_v_246 = heff_env(self)[0];
  V v_path_245 = heff_env(self)[1];
  V v_by_244 = heff_env(self)[2];
  V v_k_2416 = heff_env(self)[3];
  V v_sums_243 = heff_env(self)[4];
  V v_ps_241 = heff_env(self)[5];
  V v_hd_2415 = heff_env(self)[6];
  heff_clo_take(self, 7);
  switch (heff_tag_of(v_x_2417)) {
  case TAG_Left: {
    V v_why_2418 = heff_field(v_x_2417, 0);
    heff_take_n(v_x_2417, 1ULL, 1);
    heff_drop(v_sums_243);
    heff_drop_rec(v_ps_241, 6);
    heff_drop(v_hd_2415);
    V v_t_2419 = heff_strAppend(v_v_246, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efetchedPkg_24s1462621892x1253896370_str0), v_why_2418));
    V v_t_2420 = heff_strAppend(v_path_245, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efetchedPkg_24s1462621892x1253896370_str1), v_t_2419));
    V v_t_2421 = heff_strAppend(v_by_244, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efetchedPkg_24s1462621892x1253896370_str2), v_t_2420));
    V f_ = v_k_2416;
    args[0] = heff_tag_n(TAG_Left, 1, (V[]){v_t_2421});
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Right: {
    V v_h_2422 = heff_field(v_x_2417, 0);
    V v_ru_24x_2417_24Right = heff_take_reuse_n(v_x_2417, 1ULL, 1);
    heff_drop(v_by_244);
    V v_t_2423 = (g_list_2ekeepIf_24s188390362x2017344139(v_path_245, v_v_246, v_sums_243));
    switch (heff_tag_of(v_t_2423)) {
    case TAG_Nil: {
      heff_drop(v_h_2422);
      heff_drop_cell(v_ru_24x_2417_24Right, 1);
      V v_t_2424 = (g_heff_2ebuild_2eload_2ecachedDir(heff_dup(v_ps_241), heff_dup(v_path_245), v_v_246));
      V v_t_2425 = (g_heff_2ebuild_2eload_2ereadPkgAt_24s1971503388x1740917138(v_ps_241, v_t_2424, v_path_245));
      V f_ = v_t_2425;
      heff_room[0] = v_hd_2415;
      heff_room[1] = v_k_2416;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
    case TAG_Cons: {
      V v_s_2426 = heff_field(v_t_2423, 0);
      heff_take_n(v_t_2423, 1ULL, 2);
      V v_want_2428 = heff_get_n(v_s_2426, 2, 3);
      if (heff_strEq_c_lent(v_h_2422, v_want_2428, 0)) {
        heff_drop(v_h_2422);
        heff_drop_cell(v_ru_24x_2417_24Right, 1);
        heff_drop(v_want_2428);
        V v_t_2430 = (g_heff_2ebuild_2eload_2ecachedDir(heff_dup(v_ps_241), heff_dup(v_path_245), v_v_246));
        V v_t_2431 = (g_heff_2ebuild_2eload_2ereadPkgAt_24s1971503388x1740917138(v_ps_241, v_t_2430, v_path_245));
        V f_ = v_t_2431;
        heff_room[0] = v_hd_2415;
        heff_room[1] = v_k_2416;
        if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
      } else {
        heff_drop_rec(v_ps_241, 6);
        heff_drop(v_hd_2415);
        V v_t_2432 = ({ V b_0 = ((V)&g_heff_2ebuild_2ecommands_2efetchedPkg_24s1462621892x1253896370_str3); V a_1 = v_v_246; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2ecommands_2efetchedPkg_24s1462621892x1253896370_str4), v_v_246, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
        HeffT2 v_t_2433 = (g_heff_2ebuild_2eproject_2epseudoParts_24cpr(v_t_2432));
        V v_t_2438;
        {
          V v_field_2435 = v_t_2433.f[1];
          int64_t v_tag_2434 = ((int64_t)v_t_2433.f[0]);
          if ((v_tag_2434 == ((int64_t)0ULL))) {
            V v_x_2437 = v_field_2435;
            heff_drop(v_x_2437);
            v_t_2438 = ((V)&g_heff_2ebuild_2ecommands_2efetchedPkg_24s1462621892x1253896370_str5);
          } else {
            heff_drop(v_field_2435);
            v_t_2438 = ((V)&g_heff_2ebuild_2ecommands_2efetchedPkg_24s1462621892x1253896370_str6);
          }
        }
        V v_t_2439 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efetchedPkg_24s1462621892x1253896370_str7), heff_strAppend(v_want_2428, v_t_2438));
        V v_t_2440 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efetchedPkg_24s1462621892x1253896370_str8), heff_strAppend(v_h_2422, v_t_2439));
        V v_t_2441 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efetchedPkg_24s1462621892x1253896370_str9), heff_strAppend(v_v_246, v_t_2440));
        V v_x_2442 = heff_tag_at_n(v_ru_24x_2417_24Right, TAG_Left, 1, (V[]){heff_strAppend(v_path_245, v_t_2441)});
        V f_ = v_k_2416;
        args[0] = v_x_2442;
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      }
    }
    default: return heff_nomatch(v_t_2423);
    }
  }
  default: return heff_nomatch(v_x_2417);
  }
}
V g_heff_2ebuild_2ecommands_2efetchedPkg_24s1462621892x1253896370_lam0(V self, V *args) {
  V v_hd_2415 = args[0];
  V v_k_2416 = args[1];
  V v_c_2414 = heff_env(self)[0];
  V v_v_246 = heff_env(self)[1];
  V v_path_245 = heff_env(self)[2];
  V v_by_244 = heff_env(self)[3];
  V v_sums_243 = heff_env(self)[4];
  V v_ps_241 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V f_ = v_c_2414;
  args[0] = heff_dup(v_hd_2415);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2efetchedPkg_24s1462621892x1253896370_lam1, 1, 7, (V[]){v_v_246, v_path_245, v_by_244, v_k_2416, v_sums_243, v_ps_241, v_hd_2415});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2echeckModule_24s689954649x499235092_str0, 4, "heff");
V g_heff_2ebuild_2ecommands_2echeckModule_24s689954649x499235092_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2echeckModule_24s689954649x499235092_lam4(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2echeckModule_24s689954649x499235092_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2echeckModule_24s689954649x499235092_lam4, 1, 0};
V g_heff_2ebuild_2ecommands_2echeckModule_24s689954649x499235092_lam9(V self, V *args);
V g_heff_2ebuild_2ecommands_2echeckModule_24s689954649x499235092_lam11(V self, V *args);
V g_heff_2ebuild_2ecommands_2echeckModule_24s689954649x499235092_lam10(V self, V *args);
V g_heff_2ebuild_2ecommands_2echeckModule_24s689954649x499235092_lam8(V self, V *args);
V g_heff_2ebuild_2ecommands_2echeckModule_24s689954649x499235092_lam7(V self, V *args);
V g_heff_2ebuild_2ecommands_2echeckModule_24s689954649x499235092_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2echeckModule_24s689954649x499235092_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2echeckModule_24s689954649x499235092_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2echeckModule_24s689954649x499235092_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2echeckModule_24s689954649x499235092_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2echeckModule_24s689954649x499235092_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2echeckModule_24s689954649x499235092_entry, 5, 0};

V g_heff_2ebuild_2ecommands_2echeckModule_24s689954649x499235092(V v_rep_240, V v_prog_241, V v_chk_242, V v_acc_243, V v_f_244) {
top: ;
  V v_c_245 = ((V)&g_heff_2ebuild_2ecommands_2ehostNow_24s542763382x933426937_clo);
  return heff_clo_n(g_heff_2ebuild_2ecommands_2echeckModule_24s689954649x499235092_lam0, 2, 6, (V[]){v_c_245, v_f_244, v_acc_243, v_chk_242, v_prog_241, v_rep_240});
}
V g_heff_2ebuild_2ecommands_2echeckModule_24s689954649x499235092_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2echeckModule_24s689954649x499235092(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ebuild_2ecommands_2echeckModule_24s689954649x499235092_lam3(V self, V *args) {
  V v_x_2415 = args[0];
  V v_k_247 = heff_env(self)[0];
  V v_acc_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2415);
  V f_ = v_k_247;
  args[0] = v_acc_243;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2echeckModule_24s689954649x499235092_lam4(V self, V *args) {
  V v_t_2417 = args[0];
  return v_t_2417;
}
V g_heff_2ebuild_2ecommands_2echeckModule_24s689954649x499235092_lam9(V self, V *args) {
  V v_c_2425 = args[0];
  V v_x_2421 = heff_env(self)[0];
  V v_acc_243 = heff_env(self)[1];
  V v_x_2410 = heff_env(self)[2];
  V v_f_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2426 = heff_get_n(heff_dup(heff_rfield(v_x_2421, 2)), 1, 6);
  V v_t_2427 = (g_heff_2ebuild_2eload_2einside(heff_get_n(v_x_2421, 2, 5), v_t_2426, heff_take_field(v_c_2425, 1)));
  V v_ret_24bool = heff_bool(((heff_dup(v_t_2427) == NTAG(TAG_True)) ? ({ V v_x1_2428 = (g_heff_2ebuild_2ecommands_2eelemStrM(heff_rfield(v_c_2425, 0), heff_rfield(v_acc_243, 0))); int c_ = !(heff_dup(v_x1_2428) == NTAG(TAG_True)); heff_drop(v_x1_2428); c_; }) : ({ V v_t_2429 = (g_heff_2ebuild_2eload_2emoduleOf(heff_dup(v_x_2410), heff_dup(v_f_244))); int c_ = (heff_strEq_c(heff_dup(heff_rfield(v_c_2425, 0)), heff_dup(v_t_2429)) && ({ V v_x1_2431 = (g_heff_2ebuild_2ecommands_2eelemStrM(heff_rfield(v_c_2425, 0), heff_rfield(v_acc_243, 0))); int c_ = !(heff_dup(v_x1_2431) == NTAG(TAG_True)); heff_drop(v_x1_2431); c_; })); heff_drop(v_t_2429); c_; })));
  heff_drop_rec(v_c_2425, 14);
  heff_drop_rec(v_acc_243, 2);
  heff_drop(v_x_2410);
  heff_drop(v_f_244);
  heff_drop(v_t_2427);
  return v_ret_24bool;
}
V g_heff_2ebuild_2ecommands_2echeckModule_24s689954649x499235092_lam11(V self, V *args) {
  V v_x_2437 = args[0];
  V v_acc_243 = heff_env(self)[0];
  V v_x_2432 = heff_env(self)[1];
  V v_x_2422 = heff_env(self)[2];
  V v_k_247 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2437);
  V v_t_2438 = (g_prelude_2e_2b_2b_24f427551988x255400191(heff_take_field(v_acc_243, 0), heff_dup(v_x_2432)));
  V v_t_2439 = heff_intAdd(heff_get_n(v_acc_243, 1, 2), v_x_2422);
  V v_t_2440 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = MK_INT(0LL); V a_3 = v_x_2432; V r_ = (g_list_2efoldl_24s977936796x564903144(a_0, a_1, a_2, a_3)); heff_drop(v_x_2432); r_; });
  V v_x_2441 = heff_rec_n(2, shape_seen__errors, (V[]){v_t_2438, heff_intAdd(v_t_2439, v_t_2440)});
  V f_ = v_k_247;
  args[0] = v_x_2441;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2echeckModule_24s689954649x499235092_lam10(V self, V *args) {
  V v_x_2434 = args[0];
  V v_x_2419 = heff_env(self)[0];
  V v_prog_241 = heff_env(self)[1];
  V v_hd_246 = heff_env(self)[2];
  V v_acc_243 = heff_env(self)[3];
  V v_x_2432 = heff_env(self)[4];
  V v_x_2422 = heff_env(self)[5];
  V v_k_247 = heff_env(self)[6];
  heff_clo_take(self, 7);
  heff_drop(v_x_2434);
  V v_t_2435 = heff_tag_n(TAG_End, 2, (V[]){v_x_2419, NTAG(TAG_MkUnit)});
  V v_t_2436 = heff_tr(heff_call(v_prog_241, 1, (V[]){v_t_2435}));
  return (g_co_2eop_24s615738393x1686646143(v_t_2436, v_hd_246, heff_clo_n(g_heff_2ebuild_2ecommands_2echeckModule_24s689954649x499235092_lam11, 1, 4, (V[]){v_acc_243, v_x_2432, v_x_2422, v_k_247})));
}
V g_heff_2ebuild_2ecommands_2echeckModule_24s689954649x499235092_lam8(V self, V *args) {
  V v_x_2424 = args[0];
  V v_x_2421 = heff_env(self)[0];
  V v_acc_243 = heff_env(self)[1];
  V v_x_2410 = heff_env(self)[2];
  V v_f_244 = heff_env(self)[3];
  V v_rep_240 = heff_env(self)[4];
  V v_hd_246 = heff_env(self)[5];
  V v_x_2419 = heff_env(self)[6];
  V v_prog_241 = heff_env(self)[7];
  V v_x_2422 = heff_env(self)[8];
  V v_k_247 = heff_env(self)[9];
  heff_clo_take(self, 10);
  V v_x_2432 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ebuild_2ecommands_2echeckModule_24s689954649x499235092_lam9, 1, 4, (V[]){v_x_2421, heff_dup(v_acc_243), v_x_2410, v_f_244}), heff_get_n(v_x_2424, 0, 2)));
  V v_c_2433 = (g_heff_2ebuild_2ecommands_2eputFileDiags_24s415097226x198460927(v_rep_240, heff_dup(v_x_2432)));
  V f_ = v_c_2433;
  heff_room[0] = heff_dup(v_hd_246);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2echeckModule_24s689954649x499235092_lam10, 1, 7, (V[]){v_x_2419, v_prog_241, v_hd_246, v_acc_243, v_x_2432, v_x_2422, v_k_247});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2echeckModule_24s689954649x499235092_lam7(V self, V *args) {
  V v_x_2422 = args[0];
  V v_x_2421 = heff_env(self)[0];
  V v_hd_246 = heff_env(self)[1];
  V v_acc_243 = heff_env(self)[2];
  V v_x_2410 = heff_env(self)[3];
  V v_f_244 = heff_env(self)[4];
  V v_rep_240 = heff_env(self)[5];
  V v_x_2419 = heff_env(self)[6];
  V v_prog_241 = heff_env(self)[7];
  V v_k_247 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_c_2423 = (g_heff_2ebuild_2esession_2ecachedAcc_24s1827793511x304312721(heff_dup(v_x_2421)));
  V f_ = v_c_2423;
  heff_room[0] = heff_dup(v_hd_246);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2echeckModule_24s689954649x499235092_lam8, 1, 10, (V[]){v_x_2421, v_acc_243, v_x_2410, v_f_244, v_rep_240, v_hd_246, v_x_2419, v_prog_241, v_x_2422, v_k_247});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2echeckModule_24s689954649x499235092_lam6(V self, V *args) {
  V v_x_2421 = args[0];
  V v_hd_246 = heff_env(self)[0];
  V v_acc_243 = heff_env(self)[1];
  V v_x_2410 = heff_env(self)[2];
  V v_f_244 = heff_env(self)[3];
  V v_rep_240 = heff_env(self)[4];
  V v_x_2419 = heff_env(self)[5];
  V v_prog_241 = heff_env(self)[6];
  V v_k_247 = heff_env(self)[7];
  heff_clo_take(self, 8);
  return (g_heff_2ebuild_2ecommands_2eprintErrs_24s115117455x797094904(((V)&g_heff_2ebuild_2ecommands_2echeckModule_24s689954649x499235092_str0), heff_dup(heff_rfield(v_x_2421, 1)), MK_INT(0LL), heff_dup(v_hd_246), heff_clo_n(g_heff_2ebuild_2ecommands_2echeckModule_24s689954649x499235092_lam7, 1, 9, (V[]){v_x_2421, v_hd_246, v_acc_243, v_x_2410, v_f_244, v_rep_240, v_x_2419, v_prog_241, v_k_247})));
}
V g_heff_2ebuild_2ecommands_2echeckModule_24s689954649x499235092_lam5(V self, V *args) {
  V v_x_2419 = args[0];
  V v_f_244 = heff_env(self)[0];
  V v_hd_246 = heff_env(self)[1];
  V v_acc_243 = heff_env(self)[2];
  V v_x_2410 = heff_env(self)[3];
  V v_rep_240 = heff_env(self)[4];
  V v_prog_241 = heff_env(self)[5];
  V v_k_247 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_c_2420 = (g_heff_2ebuild_2ecommands_2eload_24s1410275656x228048283(heff_dup(v_f_244)));
  V f_ = v_c_2420;
  heff_room[0] = heff_dup(v_hd_246);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2echeckModule_24s689954649x499235092_lam6, 1, 8, (V[]){v_hd_246, v_acc_243, v_x_2410, v_f_244, v_rep_240, v_x_2419, v_prog_241, v_k_247});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2echeckModule_24s689954649x499235092_lam2(V self, V *args) {
  V v_x_2410 = args[0];
  V v_f_244 = heff_env(self)[0];
  V v_acc_243 = heff_env(self)[1];
  V v_chk_242 = heff_env(self)[2];
  V v_prog_241 = heff_env(self)[3];
  V v_hd_246 = heff_env(self)[4];
  V v_k_247 = heff_env(self)[5];
  V v_rep_240 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2411 = (g_heff_2ebuild_2eload_2emoduleOf(heff_dup(v_x_2410), heff_dup(v_f_244)));
  V v_t_2412 = ({ V a_0 = v_t_2411; V a_1 = heff_rfield(v_acc_243, 0); V r_ = (g_heff_2ebuild_2ecommands_2eelemStrM(a_0, a_1)); heff_drop(v_t_2411); r_; });
  if ((heff_dup(v_t_2412) == NTAG(TAG_True))) {
    heff_drop(v_x_2410);
    heff_drop(v_f_244);
    heff_drop(v_rep_240);
    heff_drop(v_t_2412);
    V v_t_2413 = heff_tag_n(TAG_Complete, 2, (V[]){v_chk_242, NTAG(TAG_MkUnit)});
    V v_t_2414 = heff_tr(heff_call(v_prog_241, 1, (V[]){v_t_2413}));
    return (g_co_2eop_24s615738393x1686646143(v_t_2414, v_hd_246, heff_clo_n(g_heff_2ebuild_2ecommands_2echeckModule_24s689954649x499235092_lam3, 1, 2, (V[]){v_k_247, v_acc_243})));
  } else {
    heff_drop(v_t_2412);
    V v_name_2416 = (g_heff_2ebuild_2eload_2emoduleOf(heff_dup(v_x_2410), heff_dup(v_f_244)));
    V v_t_2418 = heff_tr(heff_call(heff_dup(v_prog_241), 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){v_chk_242, v_name_2416, MK_INT(0LL), ((V)&g_heff_2ebuild_2ecommands_2echeckModule_24s689954649x499235092_lam4_clo)})}));
    return (g_co_2eop_24s615738393x1686646143(v_t_2418, heff_dup(v_hd_246), heff_clo_n(g_heff_2ebuild_2ecommands_2echeckModule_24s689954649x499235092_lam5, 1, 7, (V[]){v_f_244, v_hd_246, v_acc_243, v_x_2410, v_rep_240, v_prog_241, v_k_247})));
  }
}
V g_heff_2ebuild_2ecommands_2echeckModule_24s689954649x499235092_lam1(V self, V *args) {
  V v_x_248 = args[0];
  V v_f_244 = heff_env(self)[0];
  V v_hd_246 = heff_env(self)[1];
  V v_acc_243 = heff_env(self)[2];
  V v_chk_242 = heff_env(self)[3];
  V v_prog_241 = heff_env(self)[4];
  V v_k_247 = heff_env(self)[5];
  V v_rep_240 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_c_249 = (g_heff_2ebuild_2eload_2epathsFor_24s379653470x968203076(v_x_248, heff_dup(v_f_244)));
  V f_ = v_c_249;
  heff_room[0] = heff_dup(v_hd_246);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2echeckModule_24s689954649x499235092_lam2, 1, 7, (V[]){v_f_244, v_acc_243, v_chk_242, v_prog_241, v_hd_246, v_k_247, v_rep_240});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2echeckModule_24s689954649x499235092_lam0(V self, V *args) {
  V v_hd_246 = args[0];
  V v_k_247 = args[1];
  V v_c_245 = heff_env(self)[0];
  V v_f_244 = heff_env(self)[1];
  V v_acc_243 = heff_env(self)[2];
  V v_chk_242 = heff_env(self)[3];
  V v_prog_241 = heff_env(self)[4];
  V v_rep_240 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V f_ = v_c_245;
  args[0] = heff_dup(v_hd_246);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2echeckModule_24s689954649x499235092_lam1, 1, 7, (V[]){v_f_244, v_hd_246, v_acc_243, v_chk_242, v_prog_241, v_k_247, v_rep_240});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eappShips_24s816274383x1331904422_str0, 8, "build.hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eappShips_24s816274383x1331904422_str1, 1, "`");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eappShips_24s816274383x1331904422_str2, 1, "`");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eappShips_24s816274383x1331904422_str3, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eappShips_24s816274383x1331904422_str4, 2, ", ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eappShips_24s816274383x1331904422_str5, 11, ": it ships ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eappShips_24s816274383x1331904422_str6, 33, ", which the project does not have");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eappShips_24s816274383x1331904422_str7, 1, "\012");
V g_heff_2ebuild_2ecommands_2eappShips_24s816274383x1331904422_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eappShips_24s816274383x1331904422_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eappShips_24s816274383x1331904422_entry, 8, 0};

V g_heff_2ebuild_2ecommands_2eappShips_24s816274383x1331904422(V v_st_240, V v_t_241, V v_acc_242, V v_x_243, V v_a_244, V v_missing_245, V v_z_246, V v_z_247) {
top: ;
  switch (heff_tag_of(v_missing_245)) {
  case TAG_Nil: {
    heff_drop(v_t_241);
    heff_drop(v_z_246);
    V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){heff_rec_n(2, shape_name__build, (V[]){v_x_243, v_a_244}), heff_take_field(v_acc_242, 0)});
    V v_t_249 = ({ V rv_0 = v_t_248; V rr_ = heff_rec_reuse_nf(v_acc_242, 2ULL, 2, shape_apps__bad, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
    return heff_tail(v_z_247, 1, (V[]){v_t_249});
  }
  case TAG_Cons: {
    heff_drop(v_a_244);
    V v_t_2412 = (g_heff_2ebuild_2ecommands_2eappFile(v_st_240, v_t_241, v_x_243, ((V)&g_heff_2ebuild_2ecommands_2eappShips_24s816274383x1331904422_str0)));
    V v_x2_2413 = (g_list_2emap_24s1146729723x1441207893(((V)&g_heff_2ebuild_2ecommands_2eappShips_24s816274383x1331904422_str1), ((V)&g_heff_2ebuild_2ecommands_2eappShips_24s816274383x1331904422_str2), v_missing_245));
    V v_t_2416;
    switch (heff_tag_of(v_x2_2413)) {
    case TAG_Nil: {
      v_t_2416 = ((V)&g_heff_2ebuild_2ecommands_2eappShips_24s816274383x1331904422_str3);
      break;
    }
    case TAG_Cons: {
      V v_x_2414 = heff_field(v_x2_2413, 0);
      V v_xs_2415 = heff_field(v_x2_2413, 1);
      heff_take_n(v_x2_2413, 3ULL, 2);
      v_t_2416 = ({ V a_0 = ((V)&g_heff_2ebuild_2ecommands_2eappShips_24s816274383x1331904422_str4); V a_1 = v_x_2414; V a_2 = v_xs_2415; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2415); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2413);
    }
    V v_t_2417 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eappShips_24s816274383x1331904422_str5), heff_strAppend(v_t_2416, ((V)&g_heff_2ebuild_2ecommands_2eappShips_24s816274383x1331904422_str6)));
    V v_str_2418 = heff_strAppend(v_t_2412, v_t_2417);
    V v_t_2419 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_str_2418, ((V)&g_heff_2ebuild_2ecommands_2eappShips_24s816274383x1331904422_str7)), NTAG(TAG_MkUnit)});
    V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
    V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
    V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
    V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
    V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
    V v_t_2425 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2424})});
    return (g_co_2eop_24s615738393x1686646143(heff_tag_n(TAG_InR, 1, (V[]){v_t_2425}), v_z_246, heff_clo_n(g_heff_2ebuild_2ecommands_2eappShips_24s816274383x1331904422_lam0, 1, 2, (V[]){v_acc_242, v_z_247})));
  }
  default: return heff_nomatch(v_missing_245);
  }
}
V g_heff_2ebuild_2ecommands_2eappShips_24s816274383x1331904422_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2eappShips_24s816274383x1331904422(a0, a[1], a[2], a[3], a[4], a[5], a[6], a[7]); heff_drop(a0); return r;
}
V g_heff_2ebuild_2ecommands_2eappShips_24s816274383x1331904422_lam0(V self, V *args) {
  V v_x_2426 = args[0];
  V v_acc_242 = heff_env(self)[0];
  V v_z_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2426);
  V v_t_2427 = heff_intAdd(heff_take_field(v_acc_242, 1), MK_INT(1LL));
  V v_t_2428 = ({ V rv_1 = v_t_2427; V rr_ = heff_rec_reuse_nf(v_acc_242, 1ULL, 2, shape_apps__bad, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
  V f_ = v_z_247;
  args[0] = v_t_2428;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eplaceMade_24s1018017004x1417809443_str0, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eplaceMade_24s1018017004x1417809443_str1, 4, ".new");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eplaceMade_24s1018017004x1417809443_str2, 1, " ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eplaceMade_24s1018017004x1417809443_str3, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eplaceMade_24s1018017004x1417809443_str4, 13, " in place of ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eplaceMade_24s1018017004x1417809443_str5, 11, "cannot put ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eplaceMade_24s1018017004x1417809443_str6, 6, "heff: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eplaceMade_24s1018017004x1417809443_str7, 1, "\012");
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1018017004x1417809443_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1018017004x1417809443_lam0(V self, V *args);
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1018017004x1417809443_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eplaceMade_24s1018017004x1417809443_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eplaceMade_24s1018017004x1417809443_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1018017004x1417809443_lam7(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eplaceMade_24s1018017004x1417809443_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eplaceMade_24s1018017004x1417809443_lam7, 2, 0};
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1018017004x1417809443_lam9(V self, V *args);
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1018017004x1417809443_lam8(V self, V *args);
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1018017004x1417809443_lam12(V self, V *args);
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1018017004x1417809443_lam11(V self, V *args);
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1018017004x1417809443_lam14(V self, V *args);
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1018017004x1417809443_lam13(V self, V *args);
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1018017004x1417809443_lam10(V self, V *args);
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1018017004x1417809443_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1018017004x1417809443_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1018017004x1417809443_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1018017004x1417809443_lam3(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eplaceMade_24s1018017004x1417809443_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eplaceMade_24s1018017004x1417809443_entry, 7, 0};

V g_heff_2ebuild_2ecommands_2eplaceMade_24s1018017004x1417809443(V v_prog_240, V v_st_241, V v_t_242, V v_pl_243, V v_next_244, V v_x_245, V v_x6_246) {
top: ;
  switch (heff_tag_of(v_x6_246)) {
  case TAG_Nothing: {
    heff_drop_rec(v_t_242, 6);
    heff_drop(v_x_245);
    V v_t_247 = heff_tag_n(TAG_Complete, 2, (V[]){v_pl_243, NTAG(TAG_MkUnit)});
    V v_t_248 = heff_tr(heff_call(v_prog_240, 1, (V[]){v_t_247}));
    return heff_clo_n(g_heff_2ebuild_2ecommands_2eplaceMade_24s1018017004x1417809443_lam0, 2, 2, (V[]){v_t_248, v_next_244});
  }
  case TAG_Just: {
    V v_n_2412 = heff_field(v_x6_246, 0);
    heff_take_n(v_x6_246, 1ULL, 1);
    V v_t_2414 = heff_tr(heff_call(heff_dup(v_prog_240), 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){v_pl_243, heff_dup(v_n_2412), MK_INT(0LL), ((V)&g_heff_2ebuild_2ecommands_2eplaceMade_24s1018017004x1417809443_lam2_clo)})}));
    return heff_clo_n(g_heff_2ebuild_2ecommands_2eplaceMade_24s1018017004x1417809443_lam3, 2, 7, (V[]){v_t_2414, heff_dup(v_st_241), v_t_242, v_n_2412, v_x_245, v_prog_240, v_next_244});
  }
  default: return heff_nomatch(v_x6_246);
  }
}
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1018017004x1417809443_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2ecommands_2eplaceMade_24s1018017004x1417809443(a[0], a1, a[2], a[3], a[4], a[5], a[6]); heff_drop(a1); return r;
}
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1018017004x1417809443_lam1(V self, V *args) {
  V v_x_2411 = args[0];
  V v_next_244 = heff_env(self)[0];
  V v_hd_249 = heff_env(self)[1];
  V v_k_2410 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2411);
  V f_ = v_next_244;
  heff_room[0] = v_hd_249;
  heff_room[1] = v_k_2410;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1018017004x1417809443_lam0(V self, V *args) {
  V v_hd_249 = args[0];
  V v_k_2410 = args[1];
  V v_t_248 = heff_env(self)[0];
  V v_next_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_co_2eop_24s615738393x1686646143(v_t_248, heff_dup(v_hd_249), heff_clo_n(g_heff_2ebuild_2ecommands_2eplaceMade_24s1018017004x1417809443_lam1, 1, 3, (V[]){v_next_244, v_hd_249, v_k_2410})));
}
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1018017004x1417809443_lam2(V self, V *args) {
  V v_t_2413 = args[0];
  return v_t_2413;
}
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1018017004x1417809443_lam7(V self, V *args) {
  V v_hd_2437 = args[0];
  V v_k_2438 = args[1];
  heff_drop(v_hd_2437);
  V f_ = v_k_2438;
  args[0] = NTAG(TAG_False);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1018017004x1417809443_lam9(V self, V *args) {
  V v_x_2450 = args[0];
  V v_k_2449 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2453;
  switch (heff_tag_of(v_x_2450)) {
  case TAG_Left: {
    heff_take_n(v_x_2450, 0ULL, 1);
    v_t_2453 = NTAG(TAG_False);
    break;
  }
  case TAG_Right: {
    heff_take_n(v_x_2450, 0ULL, 1);
    v_t_2453 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_x_2450);
  }
  V f_ = v_k_2449;
  args[0] = v_t_2453;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1018017004x1417809443_lam8(V self, V *args) {
  V v_hd_2448 = args[0];
  V v_k_2449 = args[1];
  V v_c_2447 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2447;
  args[0] = v_hd_2448;
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2eplaceMade_24s1018017004x1417809443_lam9, 1, 1, (V[]){v_k_2449});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1018017004x1417809443_lam12(V self, V *args) {
  V v_x_2471 = args[0];
  V v_next_244 = heff_env(self)[0];
  V v_hd_2415 = heff_env(self)[1];
  V v_k_2416 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2471);
  V f_ = v_next_244;
  heff_room[0] = v_hd_2415;
  heff_room[1] = v_k_2416;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1018017004x1417809443_lam11(V self, V *args) {
  V v_x_2470 = args[0];
  V v_t_2461 = heff_env(self)[0];
  V v_hd_2415 = heff_env(self)[1];
  V v_next_244 = heff_env(self)[2];
  V v_k_2416 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2470);
  return (g_co_2eop_24s615738393x1686646143(v_t_2461, heff_dup(v_hd_2415), heff_clo_n(g_heff_2ebuild_2ecommands_2eplaceMade_24s1018017004x1417809443_lam12, 1, 3, (V[]){v_next_244, v_hd_2415, v_k_2416})));
}
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1018017004x1417809443_lam14(V self, V *args) {
  V v_x_2494 = args[0];
  V v_hd_2415 = heff_env(self)[0];
  V v_k_2416 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2494);
  V v_t_2495 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2496 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2495})});
  V v_t_2497 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2496})});
  V v_t_2498 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2497})});
  V v_t_2499 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2498})});
  V v_t_24100 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2499})});
  V v_t_24101 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24100})});
  return (g_co_2eop_24s615738393x1686646143(heff_tag_n(TAG_InR, 1, (V[]){v_t_24101}), v_hd_2415, v_k_2416));
}
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1018017004x1417809443_lam13(V self, V *args) {
  V v_x_2474 = args[0];
  V v_st_241 = heff_env(self)[0];
  V v_t_242 = heff_env(self)[1];
  V v_x_245 = heff_env(self)[2];
  V v_n_2412 = heff_env(self)[3];
  V v_hd_2415 = heff_env(self)[4];
  V v_k_2416 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_2474);
  V v_a_2475 = (g_heff_2ebuild_2ecommands_2epartsDir(v_st_241, heff_dup(v_t_242), v_x_245));
  V v_t_2476 = (g_std_2epath_2eparse(v_st_241, v_a_2475));
  V v_t_2477 = (g_std_2epath_2eparse(v_st_241, heff_dup(v_n_2412)));
  V v_t_2478 = (g_std_2epath_2ejoin(v_t_2476, v_t_2477));
  V v_t_2479 = ({ V a_0 = v_st_241; V a_1 = v_t_2478; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2478); r_; });
  V v_t_2480 = (g_std_2epath_2eparse(v_st_241, heff_get_n(v_t_242, 1, 6)));
  V v_t_2481 = (g_std_2epath_2eparse(v_st_241, v_n_2412));
  V v_t_2482 = (g_std_2epath_2ejoin(v_t_2480, v_t_2481));
  V v_t_2483 = ({ V a_0 = v_st_241; V a_1 = v_t_2482; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_241); heff_drop(v_t_2482); r_; });
  V v_t_2484 = heff_strAppend(v_t_2479, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eplaceMade_24s1018017004x1417809443_str4), v_t_2483));
  V v_why_2485 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eplaceMade_24s1018017004x1417809443_str5), v_t_2484);
  V v_t_2486 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eplaceMade_24s1018017004x1417809443_str6), v_why_2485), ((V)&g_heff_2ebuild_2ecommands_2eplaceMade_24s1018017004x1417809443_str7));
  V v_t_2487 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2486, NTAG(TAG_MkUnit)});
  V v_t_2488 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2487})});
  V v_t_2489 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2488})});
  V v_t_2490 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2489})});
  V v_t_2491 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2490})});
  V v_t_2492 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2491})});
  V v_t_2493 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2492})});
  return (g_co_2eop_24s615738393x1686646143(heff_tag_n(TAG_InR, 1, (V[]){v_t_2493}), heff_dup(v_hd_2415), heff_clo_n(g_heff_2ebuild_2ecommands_2eplaceMade_24s1018017004x1417809443_lam14, 1, 2, (V[]){v_hd_2415, v_k_2416})));
}
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1018017004x1417809443_lam10(V self, V *args) {
  V v_x_2455 = args[0];
  V v_st_241 = heff_env(self)[0];
  V v_t_242 = heff_env(self)[1];
  V v_n_2412 = heff_env(self)[2];
  V v_x_2417 = heff_env(self)[3];
  V v_prog_240 = heff_env(self)[4];
  V v_hd_2415 = heff_env(self)[5];
  V v_next_244 = heff_env(self)[6];
  V v_k_2416 = heff_env(self)[7];
  V v_x_2422 = heff_env(self)[8];
  V v_x_245 = heff_env(self)[9];
  heff_clo_take(self, 10);
  if ((heff_dup(v_x_2455) == NTAG(TAG_True))) {
    heff_drop(v_x_2455);
    heff_drop(v_x_2422);
    heff_drop(v_x_245);
    V v_t_2456 = (g_std_2epath_2eparse(v_st_241, heff_take_field(v_t_242, 1)));
    V v_t_2457 = (g_std_2epath_2eparse(v_st_241, v_n_2412));
    V v_t_2458 = (g_std_2epath_2ejoin(v_t_2456, v_t_2457));
    V v_path_2459 = ({ V a_0 = v_st_241; V a_1 = v_t_2458; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_241); heff_drop(v_t_2458); r_; });
    V v_t_2460 = heff_tag_n(TAG_End, 2, (V[]){v_x_2417, NTAG(TAG_MkUnit)});
    V v_t_2461 = heff_tr(heff_call(v_prog_240, 1, (V[]){v_t_2460}));
    V v_t_2462 = heff_strAppend(heff_get_n(v_t_242, 2, 6), heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eplaceMade_24s1018017004x1417809443_str2), v_path_2459));
    V v_t_2463 = heff_tag_n(TAG_Write, 2, (V[]){heff_strAppend(v_t_2462, ((V)&g_heff_2ebuild_2ecommands_2eplaceMade_24s1018017004x1417809443_str3)), NTAG(TAG_MkUnit)});
    V v_t_2464 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2463})});
    V v_t_2465 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2464})});
    V v_t_2466 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2465})});
    V v_t_2467 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2466})});
    V v_t_2468 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2467})});
    V v_t_2469 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2468})});
    return (g_co_2eop_24s615738393x1686646143(heff_tag_n(TAG_InR, 1, (V[]){v_t_2469}), heff_dup(v_hd_2415), heff_clo_n(g_heff_2ebuild_2ecommands_2eplaceMade_24s1018017004x1417809443_lam11, 1, 4, (V[]){v_t_2461, v_hd_2415, v_next_244, v_k_2416})));
  } else {
    heff_drop(v_x_2455);
    heff_drop(v_x_2417);
    heff_drop(v_prog_240);
    heff_drop(v_next_244);
    V v_t_2472 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_x_2422; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
    V v_c_2473 = ({ V a_0 = v_t_2472; V r_ = (g_heff_2eutil_2efiles_2eremove_24s889287061x300693304(a_0)); heff_drop(v_t_2472); r_; });
    V f_ = v_c_2473;
    heff_room[0] = heff_dup(v_hd_2415);
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2eplaceMade_24s1018017004x1417809443_lam13, 1, 6, (V[]){v_st_241, v_t_242, v_x_245, v_n_2412, v_hd_2415, v_k_2416});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1018017004x1417809443_lam6(V self, V *args) {
  V v_x_2435 = args[0];
  V v_x_2422 = heff_env(self)[0];
  V v_st_241 = heff_env(self)[1];
  V v_t_242 = heff_env(self)[2];
  V v_n_2412 = heff_env(self)[3];
  V v_hd_2415 = heff_env(self)[4];
  V v_x_2417 = heff_env(self)[5];
  V v_prog_240 = heff_env(self)[6];
  V v_next_244 = heff_env(self)[7];
  V v_k_2416 = heff_env(self)[8];
  V v_x_245 = heff_env(self)[9];
  heff_clo_take(self, 10);
  V v_c_2454;
  switch (heff_tag_of(v_x_2435)) {
  case TAG_Left: {
    heff_take_n(v_x_2435, 0ULL, 1);
    v_c_2454 = ((V)&g_heff_2ebuild_2ecommands_2eplaceMade_24s1018017004x1417809443_lam7_clo);
    break;
  }
  case TAG_Right: {
    heff_take_n(v_x_2435, 0ULL, 1);
    V v_path_2440 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = heff_dup(v_x_2422); V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
    V v_t_2441 = (g_std_2epath_2eparse(v_st_241, heff_dup(heff_rfield(v_t_242, 1))));
    V v_t_2442 = (g_std_2epath_2eparse(v_st_241, heff_dup(v_n_2412)));
    V v_t_2443 = (g_std_2epath_2ejoin(v_t_2441, v_t_2442));
    V v_s_2444 = ({ V a_0 = v_st_241; V a_1 = v_t_2443; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2443); r_; });
    V v_to_2445 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_s_2444; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
    V v_c_2446 = ({ V a_0 = v_path_2440; V a_1 = v_to_2445; V r_ = (g_std_2efilesystem_2ereplace_24s887604673x2104466403(a_0, a_1)); heff_drop(v_path_2440); heff_drop(v_to_2445); r_; });
    V v_c_2447 = heff_tr(heff_call(v_c_2446, 2, (V[]){heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), heff_dup(heff_rfield(g_exception_2eattempted_24s85350750x49672201_get(), 0))}));
    v_c_2454 = heff_clo_n(g_heff_2ebuild_2ecommands_2eplaceMade_24s1018017004x1417809443_lam8, 2, 1, (V[]){v_c_2447});
    break;
  }
  default: heff_nomatch(v_x_2435);
  }
  V f_ = v_c_2454;
  heff_room[0] = heff_dup(v_hd_2415);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2eplaceMade_24s1018017004x1417809443_lam10, 1, 10, (V[]){v_st_241, v_t_242, v_n_2412, v_x_2417, v_prog_240, v_hd_2415, v_next_244, v_k_2416, v_x_2422, v_x_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1018017004x1417809443_lam5(V self, V *args) {
  V v_x_2425 = args[0];
  V v_st_241 = heff_env(self)[0];
  V v_t_242 = heff_env(self)[1];
  V v_x_245 = heff_env(self)[2];
  V v_n_2412 = heff_env(self)[3];
  V v_x_2422 = heff_env(self)[4];
  V v_hd_2415 = heff_env(self)[5];
  V v_x_2417 = heff_env(self)[6];
  V v_prog_240 = heff_env(self)[7];
  V v_next_244 = heff_env(self)[8];
  V v_k_2416 = heff_env(self)[9];
  heff_clo_take(self, 10);
  heff_drop(v_x_2425);
  V v_a_2426 = (g_heff_2ebuild_2ecommands_2epartsDir(v_st_241, heff_dup(v_t_242), heff_dup(v_x_245)));
  V v_t_2427 = (g_std_2epath_2eparse(v_st_241, v_a_2426));
  V v_t_2428 = (g_std_2epath_2eparse(v_st_241, heff_dup(v_n_2412)));
  V v_t_2429 = (g_std_2epath_2ejoin(v_t_2427, v_t_2428));
  V v_s_2430 = ({ V a_0 = v_st_241; V a_1 = v_t_2429; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2429); r_; });
  V v_path_2431 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_s_2430; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
  V v_to_2432 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = heff_dup(v_x_2422); V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
  V v_c_2433 = ({ V a_0 = v_path_2431; V a_1 = v_to_2432; V r_ = (g_std_2efilesystem_2ecopy_24s1339645142x382698313(a_0, a_1)); heff_drop(v_path_2431); heff_drop(v_to_2432); r_; });
  V v_c_2434 = heff_tr(heff_call(v_c_2433, 2, (V[]){heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), heff_dup(heff_rfield(g_exception_2eattempted_24s85350750x49672201_get(), 0))}));
  V f_ = v_c_2434;
  heff_room[0] = heff_dup(v_hd_2415);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2eplaceMade_24s1018017004x1417809443_lam6, 1, 10, (V[]){v_x_2422, v_st_241, v_t_242, v_n_2412, v_hd_2415, v_x_2417, v_prog_240, v_next_244, v_k_2416, v_x_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1018017004x1417809443_lam4(V self, V *args) {
  V v_x_2417 = args[0];
  V v_st_241 = heff_env(self)[0];
  V v_t_242 = heff_env(self)[1];
  V v_n_2412 = heff_env(self)[2];
  V v_hd_2415 = heff_env(self)[3];
  V v_x_245 = heff_env(self)[4];
  V v_prog_240 = heff_env(self)[5];
  V v_next_244 = heff_env(self)[6];
  V v_k_2416 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2418 = (g_std_2epath_2eparse(v_st_241, heff_dup(heff_rfield(v_t_242, 1))));
  V v_t_2419 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eplaceMade_24s1018017004x1417809443_str0), heff_strAppend(heff_dup(v_n_2412), ((V)&g_heff_2ebuild_2ecommands_2eplaceMade_24s1018017004x1417809443_str1)));
  V v_t_2420 = (g_std_2epath_2eparse(v_st_241, v_t_2419));
  V v_t_2421 = (g_std_2epath_2ejoin(v_t_2418, v_t_2420));
  V v_x_2422 = ({ V a_0 = v_st_241; V a_1 = v_t_2421; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2421); r_; });
  V v_t_2423 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = heff_dup(v_x_2422); V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
  V v_c_2424 = ({ V a_0 = v_t_2423; V r_ = (g_heff_2eutil_2efiles_2eremove_24s889287061x300693304(a_0)); heff_drop(v_t_2423); r_; });
  V f_ = v_c_2424;
  heff_room[0] = heff_dup(v_hd_2415);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2eplaceMade_24s1018017004x1417809443_lam5, 1, 10, (V[]){v_st_241, v_t_242, v_x_245, v_n_2412, v_x_2422, v_hd_2415, v_x_2417, v_prog_240, v_next_244, v_k_2416});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1018017004x1417809443_lam3(V self, V *args) {
  V v_hd_2415 = args[0];
  V v_k_2416 = args[1];
  V v_t_2414 = heff_env(self)[0];
  V v_st_241 = heff_env(self)[1];
  V v_t_242 = heff_env(self)[2];
  V v_n_2412 = heff_env(self)[3];
  V v_x_245 = heff_env(self)[4];
  V v_prog_240 = heff_env(self)[5];
  V v_next_244 = heff_env(self)[6];
  heff_clo_take(self, 7);
  return (g_co_2eop_24s615738393x1686646143(v_t_2414, heff_dup(v_hd_2415), heff_clo_n(g_heff_2ebuild_2ecommands_2eplaceMade_24s1018017004x1417809443_lam4, 1, 8, (V[]){v_st_241, v_t_242, v_n_2412, v_hd_2415, v_x_245, v_prog_240, v_next_244, v_k_2416})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eplaceAll_24s147065284x1786496036_str0, 1, "c");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eplaceAll_24s147065284x1786496036_str1, 3, ".js");
Clo g_heff_2ebuild_2ecommands_2eplaceAll_24s147065284x1786496036_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eplaceAll_24s147065284x1786496036_entry, 6, 0};

V g_heff_2ebuild_2ecommands_2eplaceAll_24s147065284x1786496036(V v_prog_240, V v_st_241, V v_t_242, V v_pl_243, V v_next_244, V v_x5_245) {
top: ;
  switch (heff_tag_of(v_x5_245)) {
  case TAG_Nil: {
    heff_drop(v_prog_240);
    heff_drop_rec(v_t_242, 6);
    heff_drop(v_pl_243);
    return v_next_244;
  }
  case TAG_Cons: {
    V v_a_246 = heff_field(v_x5_245, 0);
    V v_rest_247 = heff_field(v_x5_245, 1);
    V v_t_248 = (g_heff_2ebuild_2ecommands_2eplaceAll_24s147065284x1786496036(heff_dup(v_prog_240), v_st_241, heff_dup(v_t_242), heff_dup(v_pl_243), v_next_244, v_rest_247));
    V v_t_249 = heff_get_n(heff_dup(heff_rfield(v_a_246, 1)), 0, 3);
    V v_t_2413;
    if (heff_strEq_c(v_t_249, ((V)&g_heff_2ebuild_2ecommands_2eplaceAll_24s147065284x1786496036_str0))) {
      v_t_2413 = heff_tag_n(TAG_Just, 1, (V[]){heff_dup(heff_rfield(v_a_246, 0))});
    } else {
      V v_t_2411 = heff_dup(heff_rfield(v_t_242, 3));
      if ((heff_dup(v_t_2411) == NTAG(TAG_True))) {
        heff_drop(v_t_2411);
        V v_t_2412 = heff_strAppend(heff_dup(heff_rfield(v_a_246, 0)), ((V)&g_heff_2ebuild_2ecommands_2eplaceAll_24s147065284x1786496036_str1));
        v_t_2413 = heff_tag_n(TAG_Just, 1, (V[]){v_t_2412});
      } else {
        heff_drop(v_t_2411);
        v_t_2413 = NTAG(TAG_Nothing);
      }
    }
    return (g_heff_2ebuild_2ecommands_2eplaceMade_24s1018017004x1417809443(v_prog_240, v_st_241, v_t_242, v_pl_243, v_t_248, heff_dup(heff_rfield(v_a_246, 0)), v_t_2413));
  }
  default: return heff_nomatch(v_x5_245);
  }
}
V g_heff_2ebuild_2ecommands_2eplaceAll_24s147065284x1786496036_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a5 = a[5]; V r = g_heff_2ebuild_2ecommands_2eplaceAll_24s147065284x1786496036(a[0], a1, a[2], a[3], a[4], a5); heff_drop(a1); heff_drop(a5); return r;
}
V g_heff_2ebuild_2ecommands_2eevalDiags_24s1053812068x1843767835_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2eevalDiags_24s1053812068x1843767835_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eevalDiags_24s1053812068x1843767835_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eevalDiags_24s1053812068x1843767835_entry, 5, 0};

V g_heff_2ebuild_2ecommands_2eevalDiags_24s1053812068x1843767835(V v_rep_240, V v_badL_241, V v_cs_242, V v_z_243, V v_z_244) {
top: ;
  V v_c_245 = (g_heff_2ebuild_2ecommands_2eputFileDiags_24s415097226x198460927(v_rep_240, heff_dup(v_cs_242)));
  return heff_tail(v_c_245, 2, (V[]){heff_dup(v_z_243), heff_clo_n(g_heff_2ebuild_2ecommands_2eevalDiags_24s1053812068x1843767835_lam0, 1, 4, (V[]){v_cs_242, v_z_243, heff_dup(v_badL_241), v_z_244})});
}
V g_heff_2ebuild_2ecommands_2eevalDiags_24s1053812068x1843767835_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2ecommands_2eevalDiags_24s1053812068x1843767835(a[0], a1, a[2], a[3], a[4]); heff_drop(a1); return r;
}
V g_heff_2ebuild_2ecommands_2eevalDiags_24s1053812068x1843767835_lam1(V self, V *args) {
  V v_x_2413 = args[0];
  V v_badL_241 = heff_env(self)[0];
  V v_z_243 = heff_env(self)[1];
  V v_z_244 = heff_env(self)[2];
  V v_cs_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  if ((heff_dup(v_badL_241) == NTAG(TAG_True))) {
    heff_drop(v_x_2413);
    heff_drop(v_badL_241);
    heff_drop(v_cs_242);
    V v_t_2414 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
    V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2414})});
    V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
    V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
    V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
    V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
    V v_t_2420 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2419})});
    return (g_co_2eop_24s615738393x1686646143(heff_tag_n(TAG_InR, 1, (V[]){v_t_2420}), v_z_243, v_z_244));
  } else {
    heff_drop(v_badL_241);
    V v_t_2421 = ({ V a_0 = v_cs_242; V r_ = (g_list_2eany_24s1740858080x874135214(a_0)); heff_drop(v_cs_242); r_; });
    if ((heff_dup(v_t_2421) == NTAG(TAG_True))) {
      heff_drop(v_x_2413);
      heff_drop(v_t_2421);
      V v_t_2422 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
      V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2422})});
      V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
      V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
      V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
      V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
      V v_t_2428 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2427})});
      return (g_co_2eop_24s615738393x1686646143(heff_tag_n(TAG_InR, 1, (V[]){v_t_2428}), v_z_243, v_z_244));
    } else {
      heff_drop(v_t_2421);
      if ((heff_dup(v_x_2413) == NTAG(TAG_True))) {
        heff_drop(v_x_2413);
        V v_t_2429 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
        V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2429})});
        V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
        V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
        V v_t_2433 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2432})});
        V v_t_2434 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2433})});
        V v_t_2435 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2434})});
        return (g_co_2eop_24s615738393x1686646143(heff_tag_n(TAG_InR, 1, (V[]){v_t_2435}), v_z_243, v_z_244));
      } else {
        heff_drop(v_x_2413);
        heff_drop(v_z_243);
        V f_ = v_z_244;
        args[0] = NTAG(TAG_MkUnit);
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      }
    }
  }
}
V g_heff_2ebuild_2ecommands_2eevalDiags_24s1053812068x1843767835_lam0(V self, V *args) {
  V v_x_246 = args[0];
  V v_cs_242 = heff_env(self)[0];
  V v_z_243 = heff_env(self)[1];
  V v_badL_241 = heff_env(self)[2];
  V v_z_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_246);
  HeffT2 v_t_247 = (g_heff_2ebuild_2edriver_2elastChecked_24cpr(heff_dup(v_cs_242)));
  {
    V v_field_249 = v_t_247.f[1];
    int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
    if ((v_tag_248 == ((int64_t)0ULL))) {
      V v_c_2411 = v_field_249;
      V v_t_2412 = (g_heff_2ebuild_2edriver_2eevaluate(v_c_2411));
      return (g_heff_2ebuild_2ecommands_2eprintEvals_24s906160764x145037181(v_t_2412, heff_dup(v_z_243), heff_clo_n(g_heff_2ebuild_2ecommands_2eevalDiags_24s1053812068x1843767835_lam1, 1, 4, (V[]){v_badL_241, v_z_243, v_z_244, v_cs_242})));
    } else {
      heff_drop(v_cs_242);
      heff_drop(v_badL_241);
      heff_drop(v_field_249);
      V v_t_2436 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
      V v_t_2437 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2436})});
      V v_t_2438 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2437})});
      V v_t_2439 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2438})});
      V v_t_2440 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2439})});
      V v_t_2441 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2440})});
      V v_t_2442 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2441})});
      return (g_co_2eop_24s615738393x1686646143(heff_tag_n(TAG_InR, 1, (V[]){v_t_2442}), v_z_243, v_z_244));
    }
  }
}