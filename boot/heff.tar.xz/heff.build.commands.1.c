// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Exit 20279
#define TAG_FailBecause 16014
#define TAG_FailDiffer 33429
#define TAG_GetEnv 43934
#define TAG_JArray 50516
#define TAG_JBool 39030
#define TAG_JFloat 30719
#define TAG_JInt 58696
#define TAG_JNull 9039
#define TAG_JObject 38239
#define TAG_JString 41091
#define TAG_MakeDirectory 16793
#define TAG_Pend 2230
#define TAG_Platform 55558
#define TAG_Posix 44191
#define TAG_ProgramPath 46819
#define TAG_ReadFile 6783
#define TAG_Remove 9747
#define TAG_Settled 45257
#define TAG_Windows 49101
#define TAG_WorkingDir 28879
#define TAG_WriteErr 37283
#define TAG_WriteFile 62589
#define LBL_absolute 325777132
#define LBL_cwd 308458
#define LBL_dir 308999
#define LBL_done 9584713
#define LBL_drive 297211300
#define LBL_errors 652506774
#define LBL_file 9638467
#define LBL_heff 9694020
#define LBL_job 314935
#define LBL_lib 316671
#define LBL_limit 304334805
#define LBL_mod 317820
#define LBL_next 9873338
#define LBL_outcome 1272833429
#define LBL_outcomes 803130769
#define LBL_owner 307523277
#define LBL_packages 1496006433
#define LBL_path 9928940
#define LBL_place 308106529
#define LBL_reports 1326460931
#define LBL_root 10001833
#define LBL_segments 1801007612
#define LBL_style 311138763
#define LBL_top 324559
#define LBL_wrong 314763719
static uint32_t shape_drive__absolute__segments[] = {LBL_drive, LBL_absolute, LBL_segments};
static uint32_t shape_lib__mod__cwd__style__heff[] = {LBL_lib, LBL_mod, LBL_cwd, LBL_style, LBL_heff};
static uint32_t shape_owner__place__outcome__next[] = {LBL_owner, LBL_place, LBL_outcome, LBL_next};
V g_co_2eop_24s903439140x919002362(V, V, V);
V g_co_2eop_24s903439140x919002362_entry(V self, V *a);
extern Clo g_co_2eop_24s903439140x919002362_clo;
V g_co_2eop_24s94900133x232571340(V, V, V);
V g_co_2eop_24s94900133x232571340_entry(V self, V *a);
extern Clo g_co_2eop_24s94900133x232571340_clo;
V g_heff_2ebuild_2ebackcache_2ebackDir_get(void);
V g_heff_2ebuild_2ecommands_2eaddRes(V, V);
V g_heff_2ebuild_2ecommands_2eaddRes_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eaddRes_clo;
V g_heff_2ebuild_2ecommands_2eendedJob_24s549099390x170744795(V, V, V);
V g_heff_2ebuild_2ecommands_2eendedJob_24s549099390x170744795_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eendedJob_24s549099390x170744795_clo;
V g_heff_2ebuild_2ecommands_2eheffErrors(V, V);
V g_heff_2ebuild_2ecommands_2eheffErrors_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eheffErrors_clo;
V g_heff_2ebuild_2ecommands_2eheffHome_24s373667348x1409440695(V, V);
V g_heff_2ebuild_2ecommands_2eheffHome_24s373667348x1409440695_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eheffHome_24s373667348x1409440695_clo;
V g_heff_2ebuild_2ecommands_2ehostNow_24s2061420951x254348482(V, V);
V g_heff_2ebuild_2ecommands_2ehostNow_24s2061420951x254348482_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ehostNow_24s2061420951x254348482_clo;
V g_heff_2ebuild_2ecommands_2ejsonFailure(V);
V g_heff_2ebuild_2ecommands_2ejsonFailure_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ejsonFailure_clo;
V g_heff_2ebuild_2ecommands_2elibDir_24s603036008x1646449713(V, V);
V g_heff_2ebuild_2ecommands_2elibDir_24s603036008x1646449713_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2elibDir_24s603036008x1646449713_clo;
V g_heff_2ebuild_2ecommands_2eload_24s1185299161x1866120155(V);
V g_heff_2ebuild_2ecommands_2eload_24s1185299161x1866120155_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eload_24s1185299161x1866120155_clo;
V g_heff_2ebuild_2ecommands_2emodDir_24s2027020589x399818523(V, V);
V g_heff_2ebuild_2ecommands_2emodDir_24s2027020589x399818523_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2emodDir_24s2027020589x399818523_clo;
V g_heff_2ebuild_2ecommands_2eownPackage_24s1781231717x895000447(V, V);
V g_heff_2ebuild_2ecommands_2eownPackage_24s1781231717x895000447_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eownPackage_24s1781231717x895000447_clo;
V g_heff_2ebuild_2ecommands_2eownRoot(V, V);
V g_heff_2ebuild_2ecommands_2eownRoot_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eownRoot_clo;
V g_heff_2ebuild_2ecommands_2eplaceBefore(V, V);
V g_heff_2ebuild_2ecommands_2eplaceBefore_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eplaceBefore_clo;
V g_heff_2ebuild_2ecommands_2eprintErrs_24s1245252666x1045981980(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eprintErrs_24s1245252666x1045981980_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprintErrs_24s1245252666x1045981980_clo;
V g_heff_2ebuild_2ecommands_2eprintLines_24s1721756835x860488624(V, V, V);
V g_heff_2ebuild_2ecommands_2eprintLines_24s1721756835x860488624_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprintLines_24s1721756835x860488624_clo;
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s1001351446x35627320(V, V, V);
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s1001351446x35627320_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eputFileDiags_24s1001351446x35627320_clo;
V g_heff_2ebuild_2ecommands_2eranOutcome(V, V, V, V);
V g_heff_2ebuild_2ecommands_2eranOutcome_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eranOutcome_clo;
V g_heff_2ebuild_2ecommands_2eranSubtests(V);
V g_heff_2ebuild_2ecommands_2eranSubtests_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eranSubtests_clo;
V g_heff_2ebuild_2ecommands_2eremoveStale_24s480615832x477662859(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eremoveStale_24s480615832x477662859_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eremoveStale_24s480615832x477662859_clo;
V g_heff_2ebuild_2ecommands_2eselfKept_24s759285935x83839238(V, V, V);
V g_heff_2ebuild_2ecommands_2eselfKept_24s759285935x83839238_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eselfKept_24s759285935x83839238_clo;
V g_heff_2ebuild_2ecommands_2esourceSaid(V);
V g_heff_2ebuild_2ecommands_2esourceSaid_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2esourceSaid_clo;
V g_heff_2ebuild_2ecommands_2esubtestJobs(V, V, V, V);
V g_heff_2ebuild_2ecommands_2esubtestJobs_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2esubtestJobs_clo;
V g_heff_2ebuild_2ecommands_2etestAll_24s1867599223x751417343(V, V, V, V);
V g_heff_2ebuild_2ecommands_2etestAll_24s1867599223x751417343_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2etestAll_24s1867599223x751417343_clo;
V g_heff_2ebuild_2ecommands_2etestArgs(V, V, V, V);
V g_heff_2ebuild_2ecommands_2etestArgs_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2etestArgs_clo;
V g_heff_2ebuild_2ecommands_2etestOneF_24s617553487x14119047(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2etestOneF_24s617553487x14119047_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2etestOneF_24s617553487x14119047_clo;
V g_heff_2ebuild_2ecommands_2etestReport_24s1197250805x667886372(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2etestReport_24s1197250805x667886372_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2etestReport_24s1197250805x667886372_clo;
V g_heff_2ebuild_2ecommands_2etypeAtCmd_24s399193099x86398068(V, V);
V g_heff_2ebuild_2ecommands_2etypeAtCmd_24s399193099x86398068_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2etypeAtCmd_24s399193099x86398068_clo;
V g_heff_2ebuild_2ecommands_2ewithGoldens_24s1156604030x1965065690(V, V, V);
V g_heff_2ebuild_2ecommands_2ewithGoldens_24s1156604030x1965065690_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ewithGoldens_24s1156604030x1965065690_clo;
V g_heff_2ebuild_2ecommands_2ewriteAll_24s455230731x322530487(V, V, V, V);
V g_heff_2ebuild_2ecommands_2ewriteAll_24s455230731x322530487_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ewriteAll_24s455230731x322530487_clo;
V g_heff_2ebuild_2ecommands_2ewriteOut_24s1526932426x1979368335(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ewriteOut_24s1526932426x1979368335_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ewriteOut_24s1526932426x1979368335_clo;
V g_heff_2ebuild_2ecommands_2ewriteOutC_24s1118707885x1042375480(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ewriteOutC_24s1118707885x1042375480_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ewriteOutC_24s1118707885x1042375480_clo;
V g_heff_2ebuild_2ecommands_2ewriteWhole_24s1689266202x111863540(V, V, V, V);
V g_heff_2ebuild_2ecommands_2ewriteWhole_24s1689266202x111863540_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ewriteWhole_24s1689266202x111863540_clo;
HeffT2 g_heff_2ebuild_2edriver_2elastChecked_24cpr(V);
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1238309362x1813598648(V, V);
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1238309362x1813598648_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eloadProgramWith_24s1238309362x1813598648_clo;
HeffT2 g_heff_2ebuild_2eproject_2epackageLit_24cpr(V);
HeffT2 g_heff_2ebuild_2eproject_2epackageOf_24cpr(V);
HeffT2 g_heff_2ebuild_2equery_2etypeAt_24cpr(V, V);
V g_heff_2ebuild_2esession_2ecachedAcc_24s52573320x1968432593(V);
V g_heff_2ebuild_2esession_2ecachedAcc_24s52573320x1968432593_entry(V self, V *a);
extern Clo g_heff_2ebuild_2esession_2ecachedAcc_24s52573320x1968432593_clo;
HeffT2 g_heff_2esyntax_2eformat_2eformat_24cpr(V);
HeffT2 g_json_2eat_24cpr(V, V);
V g_list_2eany_24s1230506745x754542351(V, V);
V g_list_2eany_24s1230506745x754542351_entry(V self, V *a);
extern Clo g_list_2eany_24s1230506745x754542351_clo;
V g_list_2edrop(V, V);
V g_list_2edrop_entry(V self, V *a);
extern Clo g_list_2edrop_clo;
HeffT2 g_list_2efind_24s1124674959x1716421677_24cpr(V, V);
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s571074576x1179600767(V, V);
V g_list_2efoldl_24s571074576x1179600767_entry(V self, V *a);
extern Clo g_list_2efoldl_24s571074576x1179600767_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
HeffT2 g_prelude_2eparseInt_24cpr(V);
V g_std_2epath_2ejoin(V, V, V);
V g_std_2epath_2ejoin_entry(V self, V *a);
extern Clo g_std_2epath_2ejoin_clo;
V g_std_2epath_2eparse(V, V);
V g_std_2epath_2eparse_entry(V self, V *a);
extern Clo g_std_2epath_2eparse_clo;
HeffT3 g_std_2epath_2eparse_24cpr(V, V);
V g_std_2epath_2erender(V, V);
V g_std_2epath_2erender_entry(V self, V *a);
extern Clo g_std_2epath_2erender_clo;
HEFF_LIT(g_heff_2ebuild_2ecommands_2eownRoot_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eownRoot_str1, 3, "out");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eownRoot_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eownRoot_str3, 5, ".heff");
Clo g_heff_2ebuild_2ecommands_2eownRoot_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eownRoot_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2eownRoot(V v_st_240, V v_self_241) {
top: ;
  HeffT3 v_t_242 = (g_std_2epath_2eparse_24cpr(v_st_240, heff_dup(v_self_241)));
  V v_t_249;
  {
    V v_field_243 = v_t_242.f[0];
    V v_field_244 = v_t_242.f[1];
    V v_field_245 = v_t_242.f[2];
    V v_t_246 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_field_245));
    V v_xs_247 = ({ V a_0 = MK_INT(1LL); V a_1 = v_t_246; V r_ = (g_list_2edrop(a_0, a_1)); heff_drop(v_t_246); r_; });
    V v_t_248 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_247));
    v_t_249 = heff_rec_n(3, shape_drive__absolute__segments, (V[]){v_field_243, v_field_244, v_t_248});
  }
  V v_s_2410 = (g_std_2epath_2erender(v_st_240, v_t_249));
  V v_t_2411 = (g_std_2epath_2eparse(v_st_240, v_s_2410));
  V v_xs_2412 = heff_get_n(v_t_2411, 2, 3);
  V v_x1_2413 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2412));
  V v_t_2416;
  switch (heff_tag_of(v_x1_2413)) {
  case TAG_Nil: {
    v_t_2416 = ((V)&g_heff_2ebuild_2ecommands_2eownRoot_str0);
    break;
  }
  case TAG_Cons: {
    V v_x_2414 = heff_field(v_x1_2413, 0);
    heff_take_n(v_x1_2413, 1ULL, 2);
    v_t_2416 = v_x_2414;
    break;
  }
  default: heff_nomatch(v_x1_2413);
  }
  V v_t_2442;
  if (heff_strEq_c(v_t_2416, ((V)&g_heff_2ebuild_2ecommands_2eownRoot_str1))) {
    HeffT3 v_t_2418 = (g_std_2epath_2eparse_24cpr(v_st_240, heff_dup(v_self_241)));
    V v_t_2425;
    {
      V v_field_2419 = v_t_2418.f[0];
      V v_field_2420 = v_t_2418.f[1];
      V v_field_2421 = v_t_2418.f[2];
      V v_t_2422 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_field_2421));
      V v_xs_2423 = ({ V a_0 = MK_INT(1LL); V a_1 = v_t_2422; V r_ = (g_list_2edrop(a_0, a_1)); heff_drop(v_t_2422); r_; });
      V v_t_2424 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2423));
      v_t_2425 = heff_rec_n(3, shape_drive__absolute__segments, (V[]){v_field_2419, v_field_2420, v_t_2424});
    }
    V v_s_2426 = (g_std_2epath_2erender(v_st_240, v_t_2425));
    HeffT3 v_t_2427 = (g_std_2epath_2eparse_24cpr(v_st_240, v_s_2426));
    V v_t_2434;
    {
      V v_field_2428 = v_t_2427.f[0];
      V v_field_2429 = v_t_2427.f[1];
      V v_field_2430 = v_t_2427.f[2];
      V v_t_2431 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_field_2430));
      V v_xs_2432 = ({ V a_0 = MK_INT(1LL); V a_1 = v_t_2431; V r_ = (g_list_2edrop(a_0, a_1)); heff_drop(v_t_2431); r_; });
      V v_t_2433 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2432));
      v_t_2434 = heff_rec_n(3, shape_drive__absolute__segments, (V[]){v_field_2428, v_field_2429, v_t_2433});
    }
    V v_s_2435 = (g_std_2epath_2erender(v_st_240, v_t_2434));
    V v_t_2436 = (g_std_2epath_2eparse(v_st_240, v_s_2435));
    V v_xs_2437 = heff_get_n(v_t_2436, 2, 3);
    V v_x1_2438 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2437));
    V v_t_2441;
    switch (heff_tag_of(v_x1_2438)) {
    case TAG_Nil: {
      v_t_2441 = ((V)&g_heff_2ebuild_2ecommands_2eownRoot_str2);
      break;
    }
    case TAG_Cons: {
      V v_x_2439 = heff_field(v_x1_2438, 0);
      heff_take_n(v_x1_2438, 1ULL, 2);
      v_t_2441 = v_x_2439;
      break;
    }
    default: heff_nomatch(v_x1_2438);
    }
    v_t_2442 = heff_strEq(v_t_2441, ((V)&g_heff_2ebuild_2ecommands_2eownRoot_str3));
  } else {
    v_t_2442 = NTAG(TAG_False);
  }
  if ((heff_dup(v_t_2442) == NTAG(TAG_True))) {
    heff_drop(v_t_2442);
    HeffT3 v_t_2443 = (g_std_2epath_2eparse_24cpr(v_st_240, v_self_241));
    V v_t_2450;
    {
      V v_field_2444 = v_t_2443.f[0];
      V v_field_2445 = v_t_2443.f[1];
      V v_field_2446 = v_t_2443.f[2];
      V v_t_2447 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_field_2446));
      V v_xs_2448 = ({ V a_0 = MK_INT(1LL); V a_1 = v_t_2447; V r_ = (g_list_2edrop(a_0, a_1)); heff_drop(v_t_2447); r_; });
      V v_t_2449 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2448));
      v_t_2450 = heff_rec_n(3, shape_drive__absolute__segments, (V[]){v_field_2444, v_field_2445, v_t_2449});
    }
    V v_s_2451 = (g_std_2epath_2erender(v_st_240, v_t_2450));
    HeffT3 v_t_2452 = (g_std_2epath_2eparse_24cpr(v_st_240, v_s_2451));
    V v_t_2459;
    {
      V v_field_2453 = v_t_2452.f[0];
      V v_field_2454 = v_t_2452.f[1];
      V v_field_2455 = v_t_2452.f[2];
      V v_t_2456 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_field_2455));
      V v_xs_2457 = ({ V a_0 = MK_INT(1LL); V a_1 = v_t_2456; V r_ = (g_list_2edrop(a_0, a_1)); heff_drop(v_t_2456); r_; });
      V v_t_2458 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2457));
      v_t_2459 = heff_rec_n(3, shape_drive__absolute__segments, (V[]){v_field_2453, v_field_2454, v_t_2458});
    }
    V v_s_2460 = (g_std_2epath_2erender(v_st_240, v_t_2459));
    HeffT3 v_t_2461 = (g_std_2epath_2eparse_24cpr(v_st_240, v_s_2460));
    V v_t_2468;
    {
      V v_field_2462 = v_t_2461.f[0];
      V v_field_2463 = v_t_2461.f[1];
      V v_field_2464 = v_t_2461.f[2];
      V v_t_2465 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_field_2464));
      V v_xs_2466 = ({ V a_0 = MK_INT(1LL); V a_1 = v_t_2465; V r_ = (g_list_2edrop(a_0, a_1)); heff_drop(v_t_2465); r_; });
      V v_t_2467 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2466));
      v_t_2468 = heff_rec_n(3, shape_drive__absolute__segments, (V[]){v_field_2462, v_field_2463, v_t_2467});
    }
    HEFF_LAST return g_std_2epath_2erender(v_st_240, v_t_2468);
  } else {
    heff_drop(v_t_2442);
    HeffT3 v_t_2469 = (g_std_2epath_2eparse_24cpr(v_st_240, v_self_241));
    V v_t_2476;
    {
      V v_field_2470 = v_t_2469.f[0];
      V v_field_2471 = v_t_2469.f[1];
      V v_field_2472 = v_t_2469.f[2];
      V v_t_2473 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_field_2472));
      V v_xs_2474 = ({ V a_0 = MK_INT(1LL); V a_1 = v_t_2473; V r_ = (g_list_2edrop(a_0, a_1)); heff_drop(v_t_2473); r_; });
      V v_t_2475 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2474));
      v_t_2476 = heff_rec_n(3, shape_drive__absolute__segments, (V[]){v_field_2470, v_field_2471, v_t_2475});
    }
    V v_s_2477 = (g_std_2epath_2erender(v_st_240, v_t_2476));
    HeffT3 v_t_2478 = (g_std_2epath_2eparse_24cpr(v_st_240, v_s_2477));
    V v_t_2485;
    {
      V v_field_2479 = v_t_2478.f[0];
      V v_field_2480 = v_t_2478.f[1];
      V v_field_2481 = v_t_2478.f[2];
      V v_t_2482 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_field_2481));
      V v_xs_2483 = ({ V a_0 = MK_INT(1LL); V a_1 = v_t_2482; V r_ = (g_list_2edrop(a_0, a_1)); heff_drop(v_t_2482); r_; });
      V v_t_2484 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2483));
      v_t_2485 = heff_rec_n(3, shape_drive__absolute__segments, (V[]){v_field_2479, v_field_2480, v_t_2484});
    }
    HEFF_LAST return g_std_2epath_2erender(v_st_240, v_t_2485);
  }
}
V g_heff_2ebuild_2ecommands_2eownRoot_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2eownRoot(a0, a[1]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ejsonFailure_str0, 7, "because");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ejsonFailure_str1, 6, "differ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ejsonFailure_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ejsonFailure_str3, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ejsonFailure_str4, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ejsonFailure_str5, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ejsonFailure_str6, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ejsonFailure_str7, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ejsonFailure_str8, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ejsonFailure_str9, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ejsonFailure_str10, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ejsonFailure_str11, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ejsonFailure_str12, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ejsonFailure_str13, 0, "");
Clo g_heff_2ebuild_2ecommands_2ejsonFailure_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ejsonFailure_entry, 1, 0};

V g_heff_2ebuild_2ecommands_2ejsonFailure(V v_j_240) {
top: ;
  V v_t_241 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ejsonFailure_str0), NTAG(TAG_Nil)});
  HeffT2 v_t_242 = (g_json_2eat_24cpr(v_t_241, heff_dup(v_j_240)));
  {
    V v_field_244 = v_t_242.f[1];
    int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
    V v_t_2413;
    if ((v_tag_243 == ((int64_t)0ULL))) {
      V v_it1_246 = v_field_244;
      switch (heff_tag_of(v_it1_246)) {
      case TAG_JNull: {
        v_t_2413 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_JBool: {
        heff_take_n(v_it1_246, 0ULL, 1);
        v_t_2413 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_JInt: {
        heff_take_n(v_it1_246, 0ULL, 1);
        v_t_2413 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_JFloat: {
        heff_take_na(v_it1_246, 0ULL, 1);
        v_t_2413 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_JString: {
        V v_s_2410 = heff_field(v_it1_246, 0);
        V v_ru_24it1_246_24JString = heff_take_reuse_n(v_it1_246, 1ULL, 1);
        v_t_2413 = heff_tag_at_n(v_ru_24it1_246_24JString, TAG_Just, 1, (V[]){v_s_2410});
        break;
      }
      case TAG_JArray: {
        heff_take_n(v_it1_246, 0ULL, 1);
        v_t_2413 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_JObject: {
        heff_take_n(v_it1_246, 0ULL, 1);
        v_t_2413 = NTAG(TAG_Nothing);
        break;
      }
      default: heff_nomatch(v_it1_246);
      }
    } else {
      heff_drop(v_field_244);
      v_t_2413 = NTAG(TAG_Nothing);
    }
    switch (heff_tag_of(v_t_2413)) {
    case TAG_Nothing: {
      V v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ejsonFailure_str1), NTAG(TAG_Nil)});
      HeffT2 v_t_2415 = (g_json_2eat_24cpr(v_t_2414, v_j_240));
      {
        V v_field_2417 = v_t_2415.f[1];
        int64_t v_tag_2416 = ((int64_t)v_t_2415.f[0]);
        if ((v_tag_2416 == ((int64_t)0ULL))) {
          V v_it1_2419 = v_field_2417;
          switch (heff_tag_of(v_it1_2419)) {
          case TAG_JNull: {
            return NTAG(TAG_Nothing);
          }
          case TAG_JBool: {
            heff_take_n(v_it1_2419, 0ULL, 1);
            return NTAG(TAG_Nothing);
          }
          case TAG_JInt: {
            heff_take_n(v_it1_2419, 0ULL, 1);
            return NTAG(TAG_Nothing);
          }
          case TAG_JFloat: {
            heff_take_na(v_it1_2419, 0ULL, 1);
            return NTAG(TAG_Nothing);
          }
          case TAG_JString: {
            heff_take_n(v_it1_2419, 0ULL, 1);
            return NTAG(TAG_Nothing);
          }
          case TAG_JArray: {
            V v_xs_2424 = heff_field(v_it1_2419, 0);
            V v_ru_24it1_2419_24JArray = heff_take_reuse_n(v_it1_2419, 1ULL, 1);
            switch (heff_tag_of(v_xs_2424)) {
            case TAG_Nil: {
              heff_drop_cell(v_ru_24it1_2419_24JArray, 1);
              return NTAG(TAG_Nothing);
            }
            case TAG_Cons: {
              V v_expected_2425 = heff_field(v_xs_2424, 0);
              V v_it12_2426 = heff_field(v_xs_2424, 1);
              heff_take_n(v_xs_2424, 3ULL, 2);
              switch (heff_tag_of(v_it12_2426)) {
              case TAG_Nil: {
                heff_drop_cell(v_ru_24it1_2419_24JArray, 1);
                heff_drop(v_expected_2425);
                return NTAG(TAG_Nothing);
              }
              case TAG_Cons: {
                V v_got_2427 = heff_field(v_it12_2426, 0);
                heff_take_n(v_it12_2426, 1ULL, 2);
                V v_t_2435;
                switch (heff_tag_of(v_expected_2425)) {
                case TAG_JNull: {
                  v_t_2435 = ((V)&g_heff_2ebuild_2ecommands_2ejsonFailure_str2);
                  break;
                }
                case TAG_JBool: {
                  heff_take_n(v_expected_2425, 0ULL, 1);
                  v_t_2435 = ((V)&g_heff_2ebuild_2ecommands_2ejsonFailure_str3);
                  break;
                }
                case TAG_JInt: {
                  heff_take_n(v_expected_2425, 0ULL, 1);
                  v_t_2435 = ((V)&g_heff_2ebuild_2ecommands_2ejsonFailure_str4);
                  break;
                }
                case TAG_JFloat: {
                  heff_take_na(v_expected_2425, 0ULL, 1);
                  v_t_2435 = ((V)&g_heff_2ebuild_2ecommands_2ejsonFailure_str5);
                  break;
                }
                case TAG_JString: {
                  V v_t_2432 = heff_field(v_expected_2425, 0);
                  heff_take_n(v_expected_2425, 1ULL, 1);
                  v_t_2435 = v_t_2432;
                  break;
                }
                case TAG_JArray: {
                  heff_take_n(v_expected_2425, 0ULL, 1);
                  v_t_2435 = ((V)&g_heff_2ebuild_2ecommands_2ejsonFailure_str6);
                  break;
                }
                case TAG_JObject: {
                  heff_take_n(v_expected_2425, 0ULL, 1);
                  v_t_2435 = ((V)&g_heff_2ebuild_2ecommands_2ejsonFailure_str7);
                  break;
                }
                default: heff_nomatch(v_expected_2425);
                }
                V v_t_2442;
                switch (heff_tag_of(v_got_2427)) {
                case TAG_JNull: {
                  v_t_2442 = ((V)&g_heff_2ebuild_2ecommands_2ejsonFailure_str8);
                  break;
                }
                case TAG_JBool: {
                  heff_take_n(v_got_2427, 0ULL, 1);
                  v_t_2442 = ((V)&g_heff_2ebuild_2ecommands_2ejsonFailure_str9);
                  break;
                }
                case TAG_JInt: {
                  heff_take_n(v_got_2427, 0ULL, 1);
                  v_t_2442 = ((V)&g_heff_2ebuild_2ecommands_2ejsonFailure_str10);
                  break;
                }
                case TAG_JFloat: {
                  heff_take_na(v_got_2427, 0ULL, 1);
                  v_t_2442 = ((V)&g_heff_2ebuild_2ecommands_2ejsonFailure_str11);
                  break;
                }
                case TAG_JString: {
                  V v_t_2439 = heff_field(v_got_2427, 0);
                  heff_take_n(v_got_2427, 1ULL, 1);
                  v_t_2442 = v_t_2439;
                  break;
                }
                case TAG_JArray: {
                  heff_take_n(v_got_2427, 0ULL, 1);
                  v_t_2442 = ((V)&g_heff_2ebuild_2ecommands_2ejsonFailure_str12);
                  break;
                }
                case TAG_JObject: {
                  heff_take_n(v_got_2427, 0ULL, 1);
                  v_t_2442 = ((V)&g_heff_2ebuild_2ecommands_2ejsonFailure_str13);
                  break;
                }
                default: heff_nomatch(v_got_2427);
                }
                return heff_tag_at_n(v_ru_24it1_2419_24JArray, TAG_Just, 1, (V[]){heff_tag_n(TAG_FailDiffer, 2, (V[]){v_t_2435, v_t_2442})});
              }
              default: return heff_nomatch(v_it12_2426);
              }
            }
            default: return heff_nomatch(v_xs_2424);
            }
          }
          case TAG_JObject: {
            heff_take_n(v_it1_2419, 0ULL, 1);
            return NTAG(TAG_Nothing);
          }
          default: return heff_nomatch(v_it1_2419);
          }
        } else {
          heff_drop(v_field_2417);
          return NTAG(TAG_Nothing);
        }
      }
    }
    case TAG_Just: {
      V v_why_2444 = heff_field(v_t_2413, 0);
      V v_ru_24t_2413_24Just = heff_take_reuse_n(v_t_2413, 1ULL, 1);
      heff_drop(v_j_240);
      return heff_tag_at_n(v_ru_24t_2413_24Just, TAG_Just, 1, (V[]){heff_tag_n(TAG_FailBecause, 1, (V[]){v_why_2444})});
    }
    default: return heff_nomatch(v_t_2413);
    }
  }
}
V g_heff_2ebuild_2ecommands_2ejsonFailure_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ejsonFailure(a[0]);
}
Clo g_heff_2ebuild_2ecommands_2eplaceBefore_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eplaceBefore_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2eplaceBefore(V v_x1_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_a_242 = heff_field(v_x1_240, 0);
    V v_as_243 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      return NTAG(TAG_False);
    }
    case TAG_Cons: {
      V v_b_244 = heff_field(v_x2_241, 0);
      V v_bs_245 = heff_field(v_x2_241, 1);
      if (heff_intEq_c_lent(v_a_242, v_b_244, 0)) {
        V t_0 = v_as_243;
        V t_1 = v_bs_245;
        v_x1_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      } else {
        return heff_intLt_lent(v_a_242, v_b_244, 0);
      }
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2ecommands_2eplaceBefore_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ebuild_2ecommands_2eplaceBefore(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestArgs_str0, 6, "--seed");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestArgs_str1, 5, "--run");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestArgs_str2, 6, "--jobs");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestArgs_str3, 4, "test");
Clo g_heff_2ebuild_2ecommands_2etestArgs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2etestArgs_entry, 4, 0};

V g_heff_2ebuild_2ecommands_2etestArgs(V v_seed_240, V v_pattern_241, V v_jobs_242, V v_given_243) {
top: ;
  V v_t_246;
  switch (heff_tag_of(v_seed_240)) {
  case TAG_Nothing: {
    v_t_246 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_v_244 = heff_field(v_seed_240, 0);
    V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_v_244), NTAG(TAG_Nil)});
    v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2etestArgs_str0), v_t_245});
    break;
  }
  default: heff_nomatch(v_seed_240);
  }
  V v_t_249;
  switch (heff_tag_of(v_pattern_241)) {
  case TAG_Nothing: {
    v_t_249 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_v_247 = heff_field(v_pattern_241, 0);
    V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_v_247), NTAG(TAG_Nil)});
    v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2etestArgs_str1), v_t_248});
    break;
  }
  default: heff_nomatch(v_pattern_241);
  }
  V v_t_2412;
  switch (heff_tag_of(v_jobs_242)) {
  case TAG_Nothing: {
    v_t_2412 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_v_2410 = heff_field(v_jobs_242, 0);
    V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_v_2410), NTAG(TAG_Nil)});
    v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2etestArgs_str2), v_t_2411});
    break;
  }
  default: heff_nomatch(v_jobs_242);
  }
  V v_t_2413 = (g_prelude_2e_2b_2b(v_t_2412, v_given_243));
  V v_t_2414 = (g_prelude_2e_2b_2b(v_t_249, v_t_2413));
  V v_t_2415 = (g_prelude_2e_2b_2b(v_t_246, v_t_2414));
  return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2etestArgs_str3), v_t_2415});
}
V g_heff_2ebuild_2ecommands_2etestArgs_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V r = g_heff_2ebuild_2ecommands_2etestArgs(a0, a1, a2, a[3]); heff_drop(a0); heff_drop(a1); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2emodDir_24s2027020589x399818523_str0, 13, "HEFF_MODCACHE");
HEFF_LIT(g_heff_2ebuild_2ecommands_2emodDir_24s2027020589x399818523_str1, 4, "HOME");
HEFF_LIT(g_heff_2ebuild_2ecommands_2emodDir_24s2027020589x399818523_str2, 11, "USERPROFILE");
HEFF_LIT(g_heff_2ebuild_2ecommands_2emodDir_24s2027020589x399818523_str3, 5, "win32");
HEFF_LIT(g_heff_2ebuild_2ecommands_2emodDir_24s2027020589x399818523_str4, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2emodDir_24s2027020589x399818523_str5, 6, ".cache");
HEFF_LIT(g_heff_2ebuild_2ecommands_2emodDir_24s2027020589x399818523_str6, 4, "heff");
HEFF_LIT(g_heff_2ebuild_2ecommands_2emodDir_24s2027020589x399818523_str7, 3, "mod");
V g_heff_2ebuild_2ecommands_2emodDir_24s2027020589x399818523_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2emodDir_24s2027020589x399818523_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2emodDir_24s2027020589x399818523_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2emodDir_24s2027020589x399818523_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2emodDir_24s2027020589x399818523_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2emodDir_24s2027020589x399818523_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2emodDir_24s2027020589x399818523_lam4(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2emodDir_24s2027020589x399818523_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2emodDir_24s2027020589x399818523_lam4, 1, 0};
V g_heff_2ebuild_2ecommands_2emodDir_24s2027020589x399818523_lam6(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2emodDir_24s2027020589x399818523_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2emodDir_24s2027020589x399818523_lam6, 1, 0};
V g_heff_2ebuild_2ecommands_2emodDir_24s2027020589x399818523_lam7(V self, V *args);
V g_heff_2ebuild_2ecommands_2emodDir_24s2027020589x399818523_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2emodDir_24s2027020589x399818523_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2emodDir_24s2027020589x399818523_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2emodDir_24s2027020589x399818523_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2emodDir_24s2027020589x399818523_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2emodDir_24s2027020589x399818523(V v_hd_240, V v_k_241) {
top: ;
  V v_t_243 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_GetEnv, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2emodDir_24s2027020589x399818523_str0), ((V)&g_heff_2ebuild_2ecommands_2emodDir_24s2027020589x399818523_lam0_clo)})});
  V v_t_244 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_243})});
  V v_t_245 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_244})});
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_245})});
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  return (g_co_2eop_24s94900133x232571340(v_t_248, heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2ecommands_2emodDir_24s2027020589x399818523_lam1, 1, 2, (V[]){v_hd_240, v_k_241})));
}
V g_heff_2ebuild_2ecommands_2emodDir_24s2027020589x399818523_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2emodDir_24s2027020589x399818523(a[0], a[1]);
}
V g_heff_2ebuild_2ecommands_2emodDir_24s2027020589x399818523_lam0(V self, V *args) {
  V v_v_242 = args[0];
  return v_v_242;
}
V g_heff_2ebuild_2ecommands_2emodDir_24s2027020589x399818523_lam2(V self, V *args) {
  V v_v_2410 = args[0];
  return v_v_2410;
}
V g_heff_2ebuild_2ecommands_2emodDir_24s2027020589x399818523_lam4(V self, V *args) {
  V v_v_2418 = args[0];
  return v_v_2418;
}
V g_heff_2ebuild_2ecommands_2emodDir_24s2027020589x399818523_lam6(V self, V *args) {
  V v_s_2426 = args[0];
  return v_s_2426;
}
V g_heff_2ebuild_2ecommands_2emodDir_24s2027020589x399818523_lam7(V self, V *args) {
  V v_x_2433 = args[0];
  V v_x_249 = heff_env(self)[0];
  V v_x_2417 = heff_env(self)[1];
  V v_x_2425 = heff_env(self)[2];
  V v_k_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_st_2435;
  if (heff_strEq_c(v_x_2433, ((V)&g_heff_2ebuild_2ecommands_2emodDir_24s2027020589x399818523_str3))) {
    v_st_2435 = NTAG(TAG_Windows);
  } else {
    v_st_2435 = NTAG(TAG_Posix);
  }
  V v_x_2442;
  switch (heff_tag_of(v_x_249)) {
  case TAG_Nothing: {
    V v_t_2438;
    switch (heff_tag_of(v_x_2417)) {
    case TAG_Nothing: {
      switch (heff_tag_of(v_x_2425)) {
      case TAG_Nothing: {
        v_t_2438 = ((V)&g_heff_2ebuild_2ecommands_2emodDir_24s2027020589x399818523_str4);
        break;
      }
      case TAG_Just: {
        V v_x_2436 = heff_field(v_x_2425, 0);
        heff_take_n(v_x_2425, 1ULL, 1);
        v_t_2438 = v_x_2436;
        break;
      }
      default: heff_nomatch(v_x_2425);
      }
      break;
    }
    case TAG_Just: {
      V v_x_2437 = heff_field(v_x_2417, 0);
      heff_take_n(v_x_2417, 1ULL, 1);
      heff_drop(v_x_2425);
      v_t_2438 = v_x_2437;
      break;
    }
    default: heff_nomatch(v_x_2417);
    }
    V v_t_2439 = (g_std_2epath_2ejoin(v_st_2435, v_t_2438, ((V)&g_heff_2ebuild_2ecommands_2emodDir_24s2027020589x399818523_str5)));
    V v_t_2440 = (g_std_2epath_2ejoin(v_st_2435, ((V)&g_heff_2ebuild_2ecommands_2emodDir_24s2027020589x399818523_str6), ((V)&g_heff_2ebuild_2ecommands_2emodDir_24s2027020589x399818523_str7)));
    v_x_2442 = ({ V a_0 = v_st_2435; V a_1 = v_t_2439; V a_2 = v_t_2440; V r_ = (g_std_2epath_2ejoin(a_0, a_1, a_2)); heff_drop(v_st_2435); r_; });
    break;
  }
  case TAG_Just: {
    V v_d_2441 = heff_field(v_x_249, 0);
    heff_take_n(v_x_249, 1ULL, 1);
    heff_drop(v_x_2417);
    heff_drop(v_x_2425);
    heff_drop(v_st_2435);
    v_x_2442 = v_d_2441;
    break;
  }
  default: heff_nomatch(v_x_249);
  }
  V f_ = v_k_241;
  args[0] = v_x_2442;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2emodDir_24s2027020589x399818523_lam5(V self, V *args) {
  V v_x_2425 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_x_249 = heff_env(self)[1];
  V v_x_2417 = heff_env(self)[2];
  V v_k_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2427 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2emodDir_24s2027020589x399818523_lam6_clo)})});
  V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
  V v_t_2429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
  V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
  V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
  V v_t_2432 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
  return (g_co_2eop_24s94900133x232571340(v_t_2432, v_hd_240, heff_clo_n(g_heff_2ebuild_2ecommands_2emodDir_24s2027020589x399818523_lam7, 1, 4, (V[]){v_x_249, v_x_2417, v_x_2425, v_k_241})));
}
V g_heff_2ebuild_2ecommands_2emodDir_24s2027020589x399818523_lam3(V self, V *args) {
  V v_x_2417 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_x_249 = heff_env(self)[1];
  V v_k_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2419 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_GetEnv, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2emodDir_24s2027020589x399818523_str2), ((V)&g_heff_2ebuild_2ecommands_2emodDir_24s2027020589x399818523_lam4_clo)})});
  V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
  V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
  V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
  V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
  V v_t_2424 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
  return (g_co_2eop_24s94900133x232571340(v_t_2424, heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2ecommands_2emodDir_24s2027020589x399818523_lam5, 1, 4, (V[]){v_hd_240, v_x_249, v_x_2417, v_k_241})));
}
V g_heff_2ebuild_2ecommands_2emodDir_24s2027020589x399818523_lam1(V self, V *args) {
  V v_x_249 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2411 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_GetEnv, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2emodDir_24s2027020589x399818523_str1), ((V)&g_heff_2ebuild_2ecommands_2emodDir_24s2027020589x399818523_lam2_clo)})});
  V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
  V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
  V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
  V v_t_2416 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  return (g_co_2eop_24s94900133x232571340(v_t_2416, heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2ecommands_2emodDir_24s2027020589x399818523_lam3, 1, 3, (V[]){v_hd_240, v_x_249, v_k_241})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eheffHome_24s373667348x1409440695_str0, 9, "HEFF_HOME");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eheffHome_24s373667348x1409440695_str1, 4, "HOME");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eheffHome_24s373667348x1409440695_str2, 11, "USERPROFILE");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eheffHome_24s373667348x1409440695_str3, 5, "win32");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eheffHome_24s373667348x1409440695_str4, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eheffHome_24s373667348x1409440695_str5, 5, ".heff");
V g_heff_2ebuild_2ecommands_2eheffHome_24s373667348x1409440695_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eheffHome_24s373667348x1409440695_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eheffHome_24s373667348x1409440695_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2eheffHome_24s373667348x1409440695_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eheffHome_24s373667348x1409440695_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eheffHome_24s373667348x1409440695_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2eheffHome_24s373667348x1409440695_lam4(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eheffHome_24s373667348x1409440695_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eheffHome_24s373667348x1409440695_lam4, 1, 0};
V g_heff_2ebuild_2ecommands_2eheffHome_24s373667348x1409440695_lam6(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eheffHome_24s373667348x1409440695_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eheffHome_24s373667348x1409440695_lam6, 1, 0};
V g_heff_2ebuild_2ecommands_2eheffHome_24s373667348x1409440695_lam7(V self, V *args);
V g_heff_2ebuild_2ecommands_2eheffHome_24s373667348x1409440695_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2eheffHome_24s373667348x1409440695_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2eheffHome_24s373667348x1409440695_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eheffHome_24s373667348x1409440695_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eheffHome_24s373667348x1409440695_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2eheffHome_24s373667348x1409440695(V v_hd_240, V v_k_241) {
top: ;
  V v_t_243 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_GetEnv, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eheffHome_24s373667348x1409440695_str0), ((V)&g_heff_2ebuild_2ecommands_2eheffHome_24s373667348x1409440695_lam0_clo)})});
  V v_t_244 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_243})});
  V v_t_245 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_244})});
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_245})});
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  return (g_co_2eop_24s94900133x232571340(v_t_248, heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2ecommands_2eheffHome_24s373667348x1409440695_lam1, 1, 2, (V[]){v_hd_240, v_k_241})));
}
V g_heff_2ebuild_2ecommands_2eheffHome_24s373667348x1409440695_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eheffHome_24s373667348x1409440695(a[0], a[1]);
}
V g_heff_2ebuild_2ecommands_2eheffHome_24s373667348x1409440695_lam0(V self, V *args) {
  V v_v_242 = args[0];
  return v_v_242;
}
V g_heff_2ebuild_2ecommands_2eheffHome_24s373667348x1409440695_lam2(V self, V *args) {
  V v_v_2410 = args[0];
  return v_v_2410;
}
V g_heff_2ebuild_2ecommands_2eheffHome_24s373667348x1409440695_lam4(V self, V *args) {
  V v_v_2418 = args[0];
  return v_v_2418;
}
V g_heff_2ebuild_2ecommands_2eheffHome_24s373667348x1409440695_lam6(V self, V *args) {
  V v_s_2426 = args[0];
  return v_s_2426;
}
V g_heff_2ebuild_2ecommands_2eheffHome_24s373667348x1409440695_lam7(V self, V *args) {
  V v_x_2433 = args[0];
  V v_x_249 = heff_env(self)[0];
  V v_x_2417 = heff_env(self)[1];
  V v_x_2425 = heff_env(self)[2];
  V v_k_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x_2440;
  switch (heff_tag_of(v_x_249)) {
  case TAG_Nothing: {
    V v_t_2435;
    if (heff_strEq_c(v_x_2433, ((V)&g_heff_2ebuild_2ecommands_2eheffHome_24s373667348x1409440695_str3))) {
      v_t_2435 = NTAG(TAG_Windows);
    } else {
      v_t_2435 = NTAG(TAG_Posix);
    }
    V v_t_2438;
    switch (heff_tag_of(v_x_2417)) {
    case TAG_Nothing: {
      switch (heff_tag_of(v_x_2425)) {
      case TAG_Nothing: {
        v_t_2438 = ((V)&g_heff_2ebuild_2ecommands_2eheffHome_24s373667348x1409440695_str4);
        break;
      }
      case TAG_Just: {
        V v_x_2436 = heff_field(v_x_2425, 0);
        heff_take_n(v_x_2425, 1ULL, 1);
        v_t_2438 = v_x_2436;
        break;
      }
      default: heff_nomatch(v_x_2425);
      }
      break;
    }
    case TAG_Just: {
      V v_x_2437 = heff_field(v_x_2417, 0);
      heff_take_n(v_x_2417, 1ULL, 1);
      heff_drop(v_x_2425);
      v_t_2438 = v_x_2437;
      break;
    }
    default: heff_nomatch(v_x_2417);
    }
    v_x_2440 = ({ V a_0 = v_t_2435; V a_1 = v_t_2438; V a_2 = ((V)&g_heff_2ebuild_2ecommands_2eheffHome_24s373667348x1409440695_str5); V r_ = (g_std_2epath_2ejoin(a_0, a_1, a_2)); heff_drop(v_t_2435); r_; });
    break;
  }
  case TAG_Just: {
    V v_d_2439 = heff_field(v_x_249, 0);
    heff_take_n(v_x_249, 1ULL, 1);
    heff_drop(v_x_2433);
    heff_drop(v_x_2417);
    heff_drop(v_x_2425);
    v_x_2440 = v_d_2439;
    break;
  }
  default: heff_nomatch(v_x_249);
  }
  V f_ = v_k_241;
  args[0] = v_x_2440;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eheffHome_24s373667348x1409440695_lam5(V self, V *args) {
  V v_x_2425 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_x_249 = heff_env(self)[1];
  V v_x_2417 = heff_env(self)[2];
  V v_k_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2427 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2eheffHome_24s373667348x1409440695_lam6_clo)})});
  V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
  V v_t_2429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
  V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
  V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
  V v_t_2432 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
  return (g_co_2eop_24s94900133x232571340(v_t_2432, v_hd_240, heff_clo_n(g_heff_2ebuild_2ecommands_2eheffHome_24s373667348x1409440695_lam7, 1, 4, (V[]){v_x_249, v_x_2417, v_x_2425, v_k_241})));
}
V g_heff_2ebuild_2ecommands_2eheffHome_24s373667348x1409440695_lam3(V self, V *args) {
  V v_x_2417 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_x_249 = heff_env(self)[1];
  V v_k_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2419 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_GetEnv, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eheffHome_24s373667348x1409440695_str2), ((V)&g_heff_2ebuild_2ecommands_2eheffHome_24s373667348x1409440695_lam4_clo)})});
  V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
  V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
  V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
  V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
  V v_t_2424 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
  return (g_co_2eop_24s94900133x232571340(v_t_2424, heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2ecommands_2eheffHome_24s373667348x1409440695_lam5, 1, 4, (V[]){v_hd_240, v_x_249, v_x_2417, v_k_241})));
}
V g_heff_2ebuild_2ecommands_2eheffHome_24s373667348x1409440695_lam1(V self, V *args) {
  V v_x_249 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2411 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_GetEnv, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eheffHome_24s373667348x1409440695_str1), ((V)&g_heff_2ebuild_2ecommands_2eheffHome_24s373667348x1409440695_lam2_clo)})});
  V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
  V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
  V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
  V v_t_2416 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  return (g_co_2eop_24s94900133x232571340(v_t_2416, heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2ecommands_2eheffHome_24s373667348x1409440695_lam3, 1, 3, (V[]){v_hd_240, v_x_249, v_k_241})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ehostNow_24s2061420951x254348482_str0, 5, "win32");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ehostNow_24s2061420951x254348482_str1, 6, "source");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ehostNow_24s2061420951x254348482_str2, 6, "source");
V g_heff_2ebuild_2ecommands_2ehostNow_24s2061420951x254348482_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ehostNow_24s2061420951x254348482_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ehostNow_24s2061420951x254348482_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2ehostNow_24s2061420951x254348482_lam4(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ehostNow_24s2061420951x254348482_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ehostNow_24s2061420951x254348482_lam4, 1, 0};
V g_heff_2ebuild_2ecommands_2ehostNow_24s2061420951x254348482_lam6(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ehostNow_24s2061420951x254348482_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ehostNow_24s2061420951x254348482_lam6, 1, 0};
V g_heff_2ebuild_2ecommands_2ehostNow_24s2061420951x254348482_lam9(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ehostNow_24s2061420951x254348482_lam9_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ehostNow_24s2061420951x254348482_lam9, 1, 0};
V g_heff_2ebuild_2ecommands_2ehostNow_24s2061420951x254348482_lam11(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ehostNow_24s2061420951x254348482_lam11_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ehostNow_24s2061420951x254348482_lam11, 1, 0};
V g_heff_2ebuild_2ecommands_2ehostNow_24s2061420951x254348482_lam12(V self, V *args);
V g_heff_2ebuild_2ecommands_2ehostNow_24s2061420951x254348482_lam10(V self, V *args);
V g_heff_2ebuild_2ecommands_2ehostNow_24s2061420951x254348482_lam8(V self, V *args);
V g_heff_2ebuild_2ecommands_2ehostNow_24s2061420951x254348482_lam7(V self, V *args);
V g_heff_2ebuild_2ecommands_2ehostNow_24s2061420951x254348482_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2ehostNow_24s2061420951x254348482_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ehostNow_24s2061420951x254348482_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2ehostNow_24s2061420951x254348482_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ehostNow_24s2061420951x254348482_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ehostNow_24s2061420951x254348482_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2ehostNow_24s2061420951x254348482(V v_hd_240, V v_k_241) {
top: ;
  HEFF_LAST return g_heff_2ebuild_2ecommands_2elibDir_24s603036008x1646449713(heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2ecommands_2ehostNow_24s2061420951x254348482_lam0, 1, 2, (V[]){v_hd_240, v_k_241}));
}
V g_heff_2ebuild_2ecommands_2ehostNow_24s2061420951x254348482_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ehostNow_24s2061420951x254348482(a[0], a[1]);
}
V g_heff_2ebuild_2ecommands_2ehostNow_24s2061420951x254348482_lam2(V self, V *args) {
  V v_s_244 = args[0];
  return v_s_244;
}
V g_heff_2ebuild_2ecommands_2ehostNow_24s2061420951x254348482_lam4(V self, V *args) {
  V v_s_2412 = args[0];
  return v_s_2412;
}
V g_heff_2ebuild_2ecommands_2ehostNow_24s2061420951x254348482_lam6(V self, V *args) {
  V v_s_2422 = args[0];
  return v_s_2422;
}
V g_heff_2ebuild_2ecommands_2ehostNow_24s2061420951x254348482_lam9(V self, V *args) {
  V v_t_2433 = args[0];
  return v_t_2433;
}
V g_heff_2ebuild_2ecommands_2ehostNow_24s2061420951x254348482_lam11(V self, V *args) {
  V v_t_2441 = args[0];
  return v_t_2441;
}
V g_heff_2ebuild_2ecommands_2ehostNow_24s2061420951x254348482_lam12(V self, V *args) {
  V v_x_2447 = args[0];
  V v_st_2421 = heff_env(self)[0];
  V v_x_2429 = heff_env(self)[1];
  V v_x_2439 = heff_env(self)[2];
  V v_x_242 = heff_env(self)[3];
  V v_x_243 = heff_env(self)[4];
  V v_x_2411 = heff_env(self)[5];
  V v_k_241 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2448 = (g_heff_2ebuild_2ecommands_2eownRoot(v_st_2421, v_x_2429));
  V v_t_2449 = ({ V a_0 = v_x_2439; V r_ = (g_heff_2ebuild_2ecommands_2esourceSaid(a_0)); heff_drop(v_x_2439); r_; });
  V v_t_2450 = ({ V a_0 = v_x_2447; V r_ = (g_heff_2ebuild_2ecommands_2esourceSaid(a_0)); heff_drop(v_x_2447); r_; });
  V v_t_2451 = (g_prelude_2e_2b_2b(v_t_2449, v_t_2450));
  V v_x_2452 = heff_rec_n(5, shape_lib__mod__cwd__style__heff, (V[]){v_x_242, v_x_243, v_x_2411, v_st_2421, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2448, v_t_2451})});
  V f_ = v_k_241;
  args[0] = v_x_2452;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ehostNow_24s2061420951x254348482_lam10(V self, V *args) {
  V v_x_2439 = args[0];
  V v_st_2421 = heff_env(self)[0];
  V v_x_2430 = heff_env(self)[1];
  V v_hd_240 = heff_env(self)[2];
  V v_x_2429 = heff_env(self)[3];
  V v_x_242 = heff_env(self)[4];
  V v_x_243 = heff_env(self)[5];
  V v_x_2411 = heff_env(self)[6];
  V v_k_241 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_path_2440 = (g_std_2epath_2ejoin(v_st_2421, v_x_2430, ((V)&g_heff_2ebuild_2ecommands_2ehostNow_24s2061420951x254348482_str2)));
  V v_t_2442 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){v_path_2440, ((V)&g_heff_2ebuild_2ecommands_2ehostNow_24s2061420951x254348482_lam11_clo)})});
  V v_t_2443 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2442})});
  V v_t_2444 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2443})});
  V v_t_2445 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2444})});
  V v_t_2446 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2445})});
  return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2446}), v_hd_240, heff_clo_n(g_heff_2ebuild_2ecommands_2ehostNow_24s2061420951x254348482_lam12, 1, 7, (V[]){v_st_2421, v_x_2429, v_x_2439, v_x_242, v_x_243, v_x_2411, v_k_241})));
}
V g_heff_2ebuild_2ecommands_2ehostNow_24s2061420951x254348482_lam8(V self, V *args) {
  V v_x_2430 = args[0];
  V v_st_2421 = heff_env(self)[0];
  V v_x_2429 = heff_env(self)[1];
  V v_hd_240 = heff_env(self)[2];
  V v_x_242 = heff_env(self)[3];
  V v_x_243 = heff_env(self)[4];
  V v_x_2411 = heff_env(self)[5];
  V v_k_241 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_home_2431 = (g_heff_2ebuild_2ecommands_2eownRoot(v_st_2421, heff_dup(v_x_2429)));
  V v_path_2432 = (g_std_2epath_2ejoin(v_st_2421, v_home_2431, ((V)&g_heff_2ebuild_2ecommands_2ehostNow_24s2061420951x254348482_str1)));
  V v_t_2434 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){v_path_2432, ((V)&g_heff_2ebuild_2ecommands_2ehostNow_24s2061420951x254348482_lam9_clo)})});
  V v_t_2435 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2434})});
  V v_t_2436 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2435})});
  V v_t_2437 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2436})});
  V v_t_2438 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2437})});
  return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2438}), heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2ecommands_2ehostNow_24s2061420951x254348482_lam10, 1, 8, (V[]){v_st_2421, v_x_2430, v_hd_240, v_x_2429, v_x_242, v_x_243, v_x_2411, v_k_241})));
}
V g_heff_2ebuild_2ecommands_2ehostNow_24s2061420951x254348482_lam7(V self, V *args) {
  V v_x_2429 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_st_2421 = heff_env(self)[1];
  V v_x_242 = heff_env(self)[2];
  V v_x_243 = heff_env(self)[3];
  V v_x_2411 = heff_env(self)[4];
  V v_k_241 = heff_env(self)[5];
  heff_clo_take(self, 6);
  return (g_heff_2ebuild_2ecommands_2eheffHome_24s373667348x1409440695(heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2ecommands_2ehostNow_24s2061420951x254348482_lam8, 1, 7, (V[]){v_st_2421, v_x_2429, v_hd_240, v_x_242, v_x_243, v_x_2411, v_k_241})));
}
V g_heff_2ebuild_2ecommands_2ehostNow_24s2061420951x254348482_lam5(V self, V *args) {
  V v_x_2419 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_x_242 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  V v_x_2411 = heff_env(self)[3];
  V v_k_241 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_st_2421;
  if (heff_strEq_c(v_x_2419, ((V)&g_heff_2ebuild_2ecommands_2ehostNow_24s2061420951x254348482_str0))) {
    v_st_2421 = NTAG(TAG_Windows);
  } else {
    v_st_2421 = NTAG(TAG_Posix);
  }
  V v_t_2423 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ProgramPath, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2ehostNow_24s2061420951x254348482_lam6_clo)})});
  V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
  V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
  V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
  V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
  V v_t_2428 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
  return (g_co_2eop_24s94900133x232571340(v_t_2428, heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2ecommands_2ehostNow_24s2061420951x254348482_lam7, 1, 6, (V[]){v_hd_240, v_st_2421, v_x_242, v_x_243, v_x_2411, v_k_241})));
}
V g_heff_2ebuild_2ecommands_2ehostNow_24s2061420951x254348482_lam3(V self, V *args) {
  V v_x_2411 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_x_242 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  V v_k_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2413 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2ehostNow_24s2061420951x254348482_lam4_clo)})});
  V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
  V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
  return (g_co_2eop_24s94900133x232571340(v_t_2418, heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2ecommands_2ehostNow_24s2061420951x254348482_lam5, 1, 5, (V[]){v_hd_240, v_x_242, v_x_243, v_x_2411, v_k_241})));
}
V g_heff_2ebuild_2ecommands_2ehostNow_24s2061420951x254348482_lam1(V self, V *args) {
  V v_x_243 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_x_242 = heff_env(self)[1];
  V v_k_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_245 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_WorkingDir, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2ehostNow_24s2061420951x254348482_lam2_clo)})});
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_245})});
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  return (g_co_2eop_24s94900133x232571340(v_t_2410, heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2ecommands_2ehostNow_24s2061420951x254348482_lam3, 1, 4, (V[]){v_hd_240, v_x_242, v_x_243, v_k_241})));
}
V g_heff_2ebuild_2ecommands_2ehostNow_24s2061420951x254348482_lam0(V self, V *args) {
  V v_x_242 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2ebuild_2ecommands_2emodDir_24s2027020589x399818523(heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2ecommands_2ehostNow_24s2061420951x254348482_lam1, 1, 3, (V[]){v_hd_240, v_x_242, v_k_241})));
}
V g_heff_2ebuild_2ecommands_2eload_24s1185299161x1866120155_lam4(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eload_24s1185299161x1866120155_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eload_24s1185299161x1866120155_lam4, 1, 0};
V g_heff_2ebuild_2ecommands_2eload_24s1185299161x1866120155_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2eload_24s1185299161x1866120155_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2eload_24s1185299161x1866120155_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2eload_24s1185299161x1866120155_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2eload_24s1185299161x1866120155_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eload_24s1185299161x1866120155_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eload_24s1185299161x1866120155_entry, 1, 0};

V g_heff_2ebuild_2ecommands_2eload_24s1185299161x1866120155(V v_file_240) {
top: ;
  V v_c_241 = ((V)&g_heff_2ebuild_2ecommands_2ehostNow_24s2061420951x254348482_clo);
  return heff_clo_n(g_heff_2ebuild_2ecommands_2eload_24s1185299161x1866120155_lam0, 2, 2, (V[]){v_c_241, v_file_240});
}
V g_heff_2ebuild_2ecommands_2eload_24s1185299161x1866120155_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eload_24s1185299161x1866120155(a[0]);
}
V g_heff_2ebuild_2ecommands_2eload_24s1185299161x1866120155_lam4(V self, V *args) {
  V v_t_248 = args[0];
  return v_t_248;
}
V g_heff_2ebuild_2ecommands_2eload_24s1185299161x1866120155_lam5(V self, V *args) {
  V v_x_2414 = args[0];
  V v_x_246 = heff_env(self)[0];
  V v_k_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2428;
  switch (heff_tag_of(v_x_2414)) {
  case TAG_Nothing: {
    v_x_2428 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Just: {
    V v_src_2415 = heff_field(v_x_2414, 0);
    V v_ru_24x_2414_24Just = heff_take_reuse_n(v_x_2414, 1ULL, 1);
    HeffT2 v_t_2416 = ({ V a_0 = v_src_2415; HeffT2 r_ = (g_heff_2ebuild_2eproject_2epackageLit_24cpr(a_0)); heff_drop(v_src_2415); r_; });
    {
      V v_field_2418 = v_t_2416.f[1];
      int64_t v_tag_2417 = ((int64_t)v_t_2416.f[0]);
      if ((v_tag_2417 == ((int64_t)0ULL))) {
        heff_drop_cell(v_ru_24x_2414_24Just, 1);
        V v_p_2420 = v_field_2418;
        heff_drop(v_p_2420);
        v_x_2428 = NTAG(TAG_Nothing);
      } else {
        V v_x_2421 = v_field_2418;
        HeffT2 v_t_2422 = (g_heff_2ebuild_2eproject_2epackageOf_24cpr(v_x_2421));
        {
          V v_field_2424 = v_t_2422.f[1];
          int64_t v_tag_2423 = ((int64_t)v_t_2422.f[0]);
          if ((v_tag_2423 == ((int64_t)0ULL))) {
            heff_drop_cell(v_ru_24x_2414_24Just, 1);
            V v_x_2426 = v_field_2424;
            heff_drop(v_x_2426);
            v_x_2428 = NTAG(TAG_Nothing);
          } else {
            V v_p_2427 = v_field_2424;
            v_x_2428 = heff_tag_at_n(v_ru_24x_2414_24Just, TAG_Just, 1, (V[]){heff_get_n(v_p_2427, 1, 4)});
          }
        }
      }
    }
    break;
  }
  default: heff_nomatch(v_x_2414);
  }
  V v_t_2429 = ({ V a_0 = v_x_2428; V a_1 = heff_dup(heff_rfield(v_x_246, 4)); V r_ = (g_heff_2ebuild_2ecommands_2eheffErrors(a_0, a_1)); heff_drop(v_x_2428); r_; });
  V v_x_2430 = (g_list_2efoldl_24s571074576x1179600767(v_x_246, v_t_2429));
  V f_ = v_k_243;
  args[0] = v_x_2430;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eload_24s1185299161x1866120155_lam3(V self, V *args) {
  V v_x_247 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_x_246 = heff_env(self)[1];
  V v_k_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_249 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){v_x_247, ((V)&g_heff_2ebuild_2ecommands_2eload_24s1185299161x1866120155_lam4_clo)})});
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
  return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2413}), v_hd_242, heff_clo_n(g_heff_2ebuild_2ecommands_2eload_24s1185299161x1866120155_lam5, 1, 2, (V[]){v_x_246, v_k_243})));
}
V g_heff_2ebuild_2ecommands_2eload_24s1185299161x1866120155_lam2(V self, V *args) {
  V v_x_246 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_k_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2ebuild_2ecommands_2eownPackage_24s1781231717x895000447(heff_dup(v_hd_242), heff_clo_n(g_heff_2ebuild_2ecommands_2eload_24s1185299161x1866120155_lam3, 1, 3, (V[]){v_hd_242, v_x_246, v_k_243})));
}
V g_heff_2ebuild_2ecommands_2eload_24s1185299161x1866120155_lam1(V self, V *args) {
  V v_x_244 = args[0];
  V v_file_240 = heff_env(self)[0];
  V v_hd_242 = heff_env(self)[1];
  V v_k_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_c_245 = (g_heff_2ebuild_2eload_2eloadProgramWith_24s1238309362x1813598648(v_x_244, v_file_240));
  V f_ = v_c_245;
  heff_room[0] = heff_dup(v_hd_242);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2eload_24s1185299161x1866120155_lam2, 1, 2, (V[]){v_hd_242, v_k_243});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2eload_24s1185299161x1866120155_lam0(V self, V *args) {
  V v_hd_242 = args[0];
  V v_k_243 = args[1];
  V v_c_241 = heff_env(self)[0];
  V v_file_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_241;
  args[0] = heff_dup(v_hd_242);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2eload_24s1185299161x1866120155_lam1, 1, 3, (V[]){v_file_240, v_hd_242, v_k_243});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eselfKept_24s759285935x83839238_str0, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eselfKept_24s759285935x83839238_str1, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eselfKept_24s759285935x83839238_str2, 8, "compiler");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eselfKept_24s759285935x83839238_str3, 1, "\012");
V g_heff_2ebuild_2ecommands_2eselfKept_24s759285935x83839238_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eselfKept_24s759285935x83839238_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eselfKept_24s759285935x83839238_lam1, 1, 0};
V g_heff_2ebuild_2ecommands_2eselfKept_24s759285935x83839238_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2eselfKept_24s759285935x83839238_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2eselfKept_24s759285935x83839238_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eselfKept_24s759285935x83839238_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eselfKept_24s759285935x83839238_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2eselfKept_24s759285935x83839238(V v_ps_240, V v_b_241, V v_id_242) {
top: ;
  V v_d_243 = (g_std_2epath_2ejoin(heff_rfield(v_ps_240, 5), heff_dup(heff_rfield(v_ps_240, 0)), ((V)&g_heff_2ebuild_2ecommands_2eselfKept_24s759285935x83839238_str0)));
  V v_path_244 = (g_std_2epath_2ejoin(heff_rfield(v_ps_240, 5), v_d_243, heff_dup(g_heff_2ebuild_2ebackcache_2ebackDir_get())));
  return heff_clo_n(g_heff_2ebuild_2ecommands_2eselfKept_24s759285935x83839238_lam0, 2, 4, (V[]){v_path_244, v_ps_240, v_id_242, v_b_241});
}
V g_heff_2ebuild_2ecommands_2eselfKept_24s759285935x83839238_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eselfKept_24s759285935x83839238(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2ecommands_2eselfKept_24s759285935x83839238_lam1(V self, V *args) {
  V v_ok_247 = args[0];
  return v_ok_247;
}
V g_heff_2ebuild_2ecommands_2eselfKept_24s759285935x83839238_lam3(V self, V *args) {
  V v_x_2418 = args[0];
  V v_k_246 = heff_env(self)[0];
  V v_id_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2418);
  V f_ = v_k_246;
  args[0] = v_id_242;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eselfKept_24s759285935x83839238_lam2(V self, V *args) {
  V v_x_2413 = args[0];
  V v_ps_240 = heff_env(self)[0];
  V v_id_242 = heff_env(self)[1];
  V v_b_241 = heff_env(self)[2];
  V v_hd_245 = heff_env(self)[3];
  V v_k_246 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2413);
  V v_d_2414 = (g_std_2epath_2ejoin(heff_rfield(v_ps_240, 5), heff_take_field(v_ps_240, 0), ((V)&g_heff_2ebuild_2ecommands_2eselfKept_24s759285935x83839238_str1)));
  V v_d_2415 = (g_std_2epath_2ejoin(heff_rfield(v_ps_240, 5), v_d_2414, heff_dup(g_heff_2ebuild_2ebackcache_2ebackDir_get())));
  V v_t_2416 = ({ V b_0 = heff_get_n(v_ps_240, 5, 6); V a_1 = v_d_2415; V a_2 = ((V)&g_heff_2ebuild_2ecommands_2eselfKept_24s759285935x83839238_str2); V r_ = (g_std_2epath_2ejoin(b_0, a_1, a_2)); heff_drop(b_0); r_; });
  V v_t_2417 = heff_strAppend(heff_dup(v_id_242), heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eselfKept_24s759285935x83839238_str3), v_b_241));
  return (g_heff_2ebuild_2ecommands_2ewriteWhole_24s1689266202x111863540(v_t_2416, v_t_2417, v_hd_245, heff_clo_n(g_heff_2ebuild_2ecommands_2eselfKept_24s759285935x83839238_lam3, 1, 2, (V[]){v_k_246, v_id_242})));
}
V g_heff_2ebuild_2ecommands_2eselfKept_24s759285935x83839238_lam0(V self, V *args) {
  V v_hd_245 = args[0];
  V v_k_246 = args[1];
  V v_path_244 = heff_env(self)[0];
  V v_ps_240 = heff_env(self)[1];
  V v_id_242 = heff_env(self)[2];
  V v_b_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_248 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_MakeDirectory, 2, (V[]){v_path_244, ((V)&g_heff_2ebuild_2ecommands_2eselfKept_24s759285935x83839238_lam1_clo)})});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
  return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2412}), heff_dup(v_hd_245), heff_clo_n(g_heff_2ebuild_2ecommands_2eselfKept_24s759285935x83839238_lam2, 1, 5, (V[]){v_ps_240, v_id_242, v_b_241, v_hd_245, v_k_246})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eremoveStale_24s480615832x477662859_str0, 5, "win32");
V g_heff_2ebuild_2ecommands_2eremoveStale_24s480615832x477662859_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eremoveStale_24s480615832x477662859_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eremoveStale_24s480615832x477662859_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2eremoveStale_24s480615832x477662859_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eremoveStale_24s480615832x477662859_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eremoveStale_24s480615832x477662859_lam2, 2, 0};
V g_heff_2ebuild_2ecommands_2eremoveStale_24s480615832x477662859_lam3(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eremoveStale_24s480615832x477662859_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eremoveStale_24s480615832x477662859_lam3, 1, 0};
V g_heff_2ebuild_2ecommands_2eremoveStale_24s480615832x477662859_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2eremoveStale_24s480615832x477662859_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eremoveStale_24s480615832x477662859_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eremoveStale_24s480615832x477662859_entry, 5, 0};

V g_heff_2ebuild_2ecommands_2eremoveStale_24s480615832x477662859(V v_dir_240, V v_parts_241, V v_x3_242, V v_p_243, V v_p_244) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_dir_240);
    heff_drop(v_p_243);
    return heff_tail(v_p_244, 1, (V[]){NTAG(TAG_MkUnit)});
  }
  case TAG_Cons: {
    V v_n_245 = heff_field(v_x3_242, 0);
    V v_rest_246 = heff_field(v_x3_242, 1);
    heff_take_n(v_x3_242, 3ULL, 2);
    V v_t_248 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2eremoveStale_24s480615832x477662859_lam0_clo)})});
    V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
    V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
    V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
    V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
    V v_t_2413 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
    return (g_co_2eop_24s94900133x232571340(v_t_2413, heff_dup(v_p_243), heff_clo_n(g_heff_2ebuild_2ecommands_2eremoveStale_24s480615832x477662859_lam1, 1, 6, (V[]){v_n_245, heff_dup(v_parts_241), v_dir_240, v_p_243, v_rest_246, v_p_244})));
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2ecommands_2eremoveStale_24s480615832x477662859_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2ecommands_2eremoveStale_24s480615832x477662859(a[0], a1, a[2], a[3], a[4]); heff_drop(a1); return r;
}
V g_heff_2ebuild_2ecommands_2eremoveStale_24s480615832x477662859_lam0(V self, V *args) {
  V v_s_247 = args[0];
  return v_s_247;
}
V g_heff_2ebuild_2ecommands_2eremoveStale_24s480615832x477662859_lam2(V self, V *args) {
  V v_hd_2416 = args[0];
  V v_k_2417 = args[1];
  heff_drop(v_hd_2416);
  V f_ = v_k_2417;
  args[0] = NTAG(TAG_True);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eremoveStale_24s480615832x477662859_lam3(V self, V *args) {
  V v_ok_2421 = args[0];
  return v_ok_2421;
}
V g_heff_2ebuild_2ecommands_2eremoveStale_24s480615832x477662859_lam4(V self, V *args) {
  V v_x_2428 = args[0];
  V v_dir_240 = heff_env(self)[0];
  V v_parts_241 = heff_env(self)[1];
  V v_rest_246 = heff_env(self)[2];
  V v_p_243 = heff_env(self)[3];
  V v_p_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2428);
  return ({ V a_0 = v_dir_240; V a_1 = v_parts_241; V a_2 = v_rest_246; V a_3 = v_p_243; V a_4 = v_p_244; V r_ = (g_heff_2ebuild_2ecommands_2eremoveStale_24s480615832x477662859(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_parts_241); r_; });
}
V g_heff_2ebuild_2ecommands_2eremoveStale_24s480615832x477662859_lam1(V self, V *args) {
  V v_x_2414 = args[0];
  V v_n_245 = heff_env(self)[0];
  V v_parts_241 = heff_env(self)[1];
  V v_dir_240 = heff_env(self)[2];
  V v_p_243 = heff_env(self)[3];
  V v_rest_246 = heff_env(self)[4];
  V v_p_244 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2415 = (g_list_2eany_24s1230506745x754542351(v_n_245, v_parts_241));
  V v_c_2427;
  if ((heff_dup(v_t_2415) == NTAG(TAG_True))) {
    heff_drop(v_x_2414);
    heff_drop(v_n_245);
    heff_drop(v_t_2415);
    v_c_2427 = ((V)&g_heff_2ebuild_2ecommands_2eremoveStale_24s480615832x477662859_lam2_clo);
  } else {
    heff_drop(v_t_2415);
    V v_t_2419;
    if (heff_strEq_c(v_x_2414, ((V)&g_heff_2ebuild_2ecommands_2eremoveStale_24s480615832x477662859_str0))) {
      v_t_2419 = NTAG(TAG_Windows);
    } else {
      v_t_2419 = NTAG(TAG_Posix);
    }
    V v_path_2420 = ({ V a_0 = v_t_2419; V a_1 = heff_dup(v_dir_240); V a_2 = v_n_245; V r_ = (g_std_2epath_2ejoin(a_0, a_1, a_2)); heff_drop(v_t_2419); r_; });
    V v_t_2422 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Remove, 2, (V[]){v_path_2420, ((V)&g_heff_2ebuild_2ecommands_2eremoveStale_24s480615832x477662859_lam3_clo)})});
    V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
    V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
    V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
    V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
    v_c_2427 = heff_tr(heff_call(((V)&g_co_2eop_24s903439140x919002362_clo), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2426})}));
  }
  V f_ = v_c_2427;
  heff_room[0] = heff_dup(v_p_243);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2eremoveStale_24s480615832x477662859_lam4, 1, 5, (V[]){v_dir_240, v_parts_241, v_rest_246, v_p_243, v_p_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ewriteOutC_24s1118707885x1042375480_str0, 2, ".c");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ewriteOutC_24s1118707885x1042375480_str1, 4, ".zig");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ewriteOutC_24s1118707885x1042375480_str2, 2, ".c");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ewriteOutC_24s1118707885x1042375480_str3, 13, "cannot write ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ewriteOutC_24s1118707885x1042375480_str4, 4, ".zig");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ewriteOutC_24s1118707885x1042375480_str5, 1, "\012");
V g_heff_2ebuild_2ecommands_2ewriteOutC_24s1118707885x1042375480_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ewriteOutC_24s1118707885x1042375480_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewriteOutC_24s1118707885x1042375480_lam1, 1, 0};
V g_heff_2ebuild_2ecommands_2ewriteOutC_24s1118707885x1042375480_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ewriteOutC_24s1118707885x1042375480_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ewriteOutC_24s1118707885x1042375480_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ewriteOutC_24s1118707885x1042375480_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewriteOutC_24s1118707885x1042375480_entry, 6, 0};

V g_heff_2ebuild_2ecommands_2ewriteOutC_24s1118707885x1042375480(V v_outPath_240, V v_zig_241, V v_done_242, V v_o_243, V v_p_244, V v_p_245) {
top: ;
  return (g_heff_2ebuild_2ecommands_2ewriteOut_24s1526932426x1979368335(heff_dup(v_outPath_240), heff_clo_n(g_heff_2ebuild_2ecommands_2ewriteOutC_24s1118707885x1042375480_lam0, 2, 3, (V[]){v_outPath_240, v_zig_241, v_done_242}), v_o_243, v_p_244, v_p_245));
}
V g_heff_2ebuild_2ecommands_2ewriteOutC_24s1118707885x1042375480_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ewriteOutC_24s1118707885x1042375480(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2ebuild_2ecommands_2ewriteOutC_24s1118707885x1042375480_lam1(V self, V *args) {
  V v_ok_2413 = args[0];
  return v_ok_2413;
}
V g_heff_2ebuild_2ecommands_2ewriteOutC_24s1118707885x1042375480_lam3(V self, V *args) {
  V v_x_2433 = args[0];
  V v_hd_246 = heff_env(self)[0];
  V v_k_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2433);
  V v_t_2434 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2435 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2434})});
  V v_t_2436 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2435})});
  V v_t_2437 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2436})});
  V v_t_2438 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2437})});
  V v_t_2439 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2438})});
  return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2439}), v_hd_246, v_k_247));
}
V g_heff_2ebuild_2ecommands_2ewriteOutC_24s1118707885x1042375480_lam2(V self, V *args) {
  V v_x_2420 = args[0];
  V v_done_242 = heff_env(self)[0];
  V v_hd_246 = heff_env(self)[1];
  V v_k_247 = heff_env(self)[2];
  V v_outPath_240 = heff_env(self)[3];
  heff_clo_take(self, 4);
  if ((heff_dup(v_x_2420) == NTAG(TAG_True))) {
    heff_drop(v_x_2420);
    heff_drop(v_outPath_240);
    V f_ = v_done_242;
    heff_room[0] = v_hd_246;
    heff_room[1] = v_k_247;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    heff_drop(v_x_2420);
    heff_drop(v_done_242);
    int64_t v_t_2421 = (heff_unbox_word(heff_strLength_lent(v_outPath_240, 0)) - ((int64_t)2ULL));
    V v_t_2422 = heff_strSlice(heff_dup(v_outPath_240), heff_box_word(v_t_2421), heff_strLength_lent(v_outPath_240, 0));
    V v_t_2425;
    if (heff_strEq_c(v_t_2422, ((V)&g_heff_2ebuild_2ecommands_2ewriteOutC_24s1118707885x1042375480_str2))) {
      int64_t v_t_2424 = (heff_unbox_word(heff_strLength_lent(v_outPath_240, 0)) - ((int64_t)2ULL));
      v_t_2425 = heff_strSlice(v_outPath_240, MK_INT(0LL), heff_box_word(v_t_2424));
    } else {
      v_t_2425 = v_outPath_240;
    }
    V v_t_2426 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ewriteOutC_24s1118707885x1042375480_str3), heff_strAppend(v_t_2425, ((V)&g_heff_2ebuild_2ecommands_2ewriteOutC_24s1118707885x1042375480_str4)));
    V v_t_2427 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_t_2426, ((V)&g_heff_2ebuild_2ecommands_2ewriteOutC_24s1118707885x1042375480_str5)), NTAG(TAG_MkUnit)});
    V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
    V v_t_2429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
    V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
    V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
    V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
    return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2432}), heff_dup(v_hd_246), heff_clo_n(g_heff_2ebuild_2ecommands_2ewriteOutC_24s1118707885x1042375480_lam3, 1, 2, (V[]){v_hd_246, v_k_247})));
  }
}
V g_heff_2ebuild_2ecommands_2ewriteOutC_24s1118707885x1042375480_lam0(V self, V *args) {
  V v_hd_246 = args[0];
  V v_k_247 = args[1];
  V v_outPath_240 = heff_env(self)[0];
  V v_zig_241 = heff_env(self)[1];
  V v_done_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  int64_t v_t_248 = (heff_unbox_word(heff_strLength_lent(v_outPath_240, 0)) - ((int64_t)2ULL));
  V v_t_249 = heff_strSlice(heff_dup(v_outPath_240), heff_box_word(v_t_248), heff_strLength_lent(v_outPath_240, 0));
  V v_t_2412;
  if (heff_strEq_c(v_t_249, ((V)&g_heff_2ebuild_2ecommands_2ewriteOutC_24s1118707885x1042375480_str0))) {
    int64_t v_t_2411 = (heff_unbox_word(heff_strLength_lent(v_outPath_240, 0)) - ((int64_t)2ULL));
    v_t_2412 = heff_strSlice_lent(v_outPath_240, MK_INT(0LL), heff_box_word(v_t_2411), 6);
  } else {
    v_t_2412 = heff_dup(v_outPath_240);
  }
  V v_t_2414 = heff_tag_n(TAG_WriteFile, 3, (V[]){heff_strAppend(v_t_2412, ((V)&g_heff_2ebuild_2ecommands_2ewriteOutC_24s1118707885x1042375480_str1)), v_zig_241, ((V)&g_heff_2ebuild_2ecommands_2ewriteOutC_24s1118707885x1042375480_lam1_clo)});
  V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2414})});
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
  return (g_co_2eop_24s94900133x232571340(v_t_2419, heff_dup(v_hd_246), heff_clo_n(g_heff_2ebuild_2ecommands_2ewriteOutC_24s1118707885x1042375480_lam2, 1, 4, (V[]){v_done_242, v_hd_246, v_k_247, v_outPath_240})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eendedJob_24s549099390x170744795_str0, 8, ".outcome");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eendedJob_24s549099390x170744795_str1, 8, ".outcome");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eendedJob_24s549099390x170744795_str2, 3, " / ");
V g_heff_2ebuild_2ecommands_2eendedJob_24s549099390x170744795_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eendedJob_24s549099390x170744795_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eendedJob_24s549099390x170744795_lam0, 2, 0};
V g_heff_2ebuild_2ecommands_2eendedJob_24s549099390x170744795_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eendedJob_24s549099390x170744795_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eendedJob_24s549099390x170744795_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2eendedJob_24s549099390x170744795_lam4(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eendedJob_24s549099390x170744795_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eendedJob_24s549099390x170744795_lam4, 1, 0};
V g_heff_2ebuild_2ecommands_2eendedJob_24s549099390x170744795_lam6(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eendedJob_24s549099390x170744795_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eendedJob_24s549099390x170744795_lam6, 1, 0};
V g_heff_2ebuild_2ecommands_2eendedJob_24s549099390x170744795_lam7(V self, V *args);
V g_heff_2ebuild_2ecommands_2eendedJob_24s549099390x170744795_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2eendedJob_24s549099390x170744795_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2eendedJob_24s549099390x170744795_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2eendedJob_24s549099390x170744795_lam8(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eendedJob_24s549099390x170744795_lam8_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eendedJob_24s549099390x170744795_lam8, 2, 0};
Clo g_heff_2ebuild_2ecommands_2eendedJob_24s549099390x170744795_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eendedJob_24s549099390x170744795_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2eendedJob_24s549099390x170744795(V v_sel_240, V v_rs_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nothing: {
    heff_drop(v_rs_241);
    return ((V)&g_heff_2ebuild_2ecommands_2eendedJob_24s549099390x170744795_lam0_clo);
  }
  case TAG_Just: {
    V v_x31_245 = heff_field(v_x3_242, 0);
    heff_take_n(v_x3_242, 1ULL, 1);
    switch (heff_tag_of(v_x31_245)) {
    case TAG_MkPair: {
      V v_proc_246 = heff_field(v_x31_245, 0);
      V v_ran_247 = heff_field(v_x31_245, 1);
      heff_take_n(v_x31_245, 3ULL, 2);
      HeffT2 v_t_248 = ({ V a_0 = v_proc_246; V a_1 = v_rs_241; HeffT2 r_ = (g_list_2efind_24s1124674959x1716421677_24cpr(a_0, a_1)); heff_drop(v_proc_246); r_; });
      {
        V v_field_2410 = v_t_248.f[1];
        int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
        if ((v_tag_249 == ((int64_t)0ULL))) {
          V v_r_2412 = v_field_2410;
          return heff_clo_n(g_heff_2ebuild_2ecommands_2eendedJob_24s549099390x170744795_lam1, 2, 3, (V[]){v_r_2412, v_ran_247, heff_dup(v_sel_240)});
        } else {
          heff_drop(v_ran_247);
          heff_drop(v_field_2410);
          return ((V)&g_heff_2ebuild_2ecommands_2eendedJob_24s549099390x170744795_lam8_clo);
        }
      }
    }
    default: return heff_nomatch(v_x31_245);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2ecommands_2eendedJob_24s549099390x170744795_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2eendedJob_24s549099390x170744795(a0, a[1], a[2]); heff_drop(a0); return r;
}
V g_heff_2ebuild_2ecommands_2eendedJob_24s549099390x170744795_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  heff_drop(v_hd_243);
  V f_ = v_k_244;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eendedJob_24s549099390x170744795_lam2(V self, V *args) {
  V v_ok_2415 = args[0];
  return v_ok_2415;
}
V g_heff_2ebuild_2ecommands_2eendedJob_24s549099390x170744795_lam4(V self, V *args) {
  V v_t_2424 = args[0];
  return v_t_2424;
}
V g_heff_2ebuild_2ecommands_2eendedJob_24s549099390x170744795_lam6(V self, V *args) {
  V v_ok_2432 = args[0];
  return v_ok_2432;
}
V g_heff_2ebuild_2ecommands_2eendedJob_24s549099390x170744795_lam7(V self, V *args) {
  V v_x_2438 = args[0];
  V v_r_2412 = heff_env(self)[0];
  V v_ran_247 = heff_env(self)[1];
  V v_x_2430 = heff_env(self)[2];
  V v_sel_240 = heff_env(self)[3];
  V v_k_2414 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2438);
  V v_t_2439 = heff_get_n(heff_dup(heff_rfield(v_r_2412, 0)), 0, 6);
  V v_t_2440 = heff_get_n(heff_dup(heff_rfield(v_r_2412, 0)), 2, 6);
  V v_j_2441 = heff_dup(heff_rfield(v_r_2412, 0));
  V v_t_2442 = ({ V a_0 = ((V)&g_heff_2ebuild_2ecommands_2eendedJob_24s549099390x170744795_str2); V a_1 = heff_take_field(v_j_2441, 3); V b_2 = heff_get_n(v_j_2441, 4, 6); V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, b_2)); heff_drop(b_2); r_; });
  V v_t_2443 = heff_get_n(heff_dup(heff_rfield(v_r_2412, 0)), 5, 6);
  V v_t_2444 = (g_heff_2ebuild_2ecommands_2eranOutcome(v_t_2442, v_t_2443, v_ran_247, heff_dup(v_x_2430)));
  V v_t_2445 = ({ V a_0 = v_x_2430; V r_ = (g_heff_2ebuild_2ecommands_2eranSubtests(a_0)); heff_drop(v_x_2430); r_; });
  V v_t_2446 = ({ V a_0 = v_sel_240; V a_1 = heff_get_n(v_r_2412, 0, 3); V a_2 = MK_INT(0LL); V a_3 = v_t_2445; V r_ = (g_heff_2ebuild_2ecommands_2esubtestJobs(a_0, a_1, a_2, a_3)); heff_drop(v_sel_240); r_; });
  V v_x_2447 = heff_tag_n(TAG_Cons, 2, (V[]){heff_rec_n(4, shape_owner__place__outcome__next, (V[]){v_t_2439, v_t_2440, v_t_2444, v_t_2446}), NTAG(TAG_Nil)});
  V f_ = v_k_2414;
  args[0] = v_x_2447;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eendedJob_24s549099390x170744795_lam5(V self, V *args) {
  V v_x_2430 = args[0];
  V v_r_2412 = heff_env(self)[0];
  V v_hd_2413 = heff_env(self)[1];
  V v_ran_247 = heff_env(self)[2];
  V v_sel_240 = heff_env(self)[3];
  V v_k_2414 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2431 = heff_strAppend(heff_dup(heff_rfield(v_r_2412, 2)), ((V)&g_heff_2ebuild_2ecommands_2eendedJob_24s549099390x170744795_str1));
  V v_t_2433 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Remove, 2, (V[]){v_t_2431, ((V)&g_heff_2ebuild_2ecommands_2eendedJob_24s549099390x170744795_lam6_clo)})});
  V v_t_2434 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2433})});
  V v_t_2435 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2434})});
  V v_t_2436 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2435})});
  V v_t_2437 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2436})});
  return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2437}), v_hd_2413, heff_clo_n(g_heff_2ebuild_2ecommands_2eendedJob_24s549099390x170744795_lam7, 1, 5, (V[]){v_r_2412, v_ran_247, v_x_2430, v_sel_240, v_k_2414})));
}
V g_heff_2ebuild_2ecommands_2eendedJob_24s549099390x170744795_lam3(V self, V *args) {
  V v_x_2422 = args[0];
  V v_r_2412 = heff_env(self)[0];
  V v_hd_2413 = heff_env(self)[1];
  V v_ran_247 = heff_env(self)[2];
  V v_sel_240 = heff_env(self)[3];
  V v_k_2414 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2422);
  V v_t_2423 = heff_strAppend(heff_dup(heff_rfield(v_r_2412, 2)), ((V)&g_heff_2ebuild_2ecommands_2eendedJob_24s549099390x170744795_str0));
  V v_t_2425 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){v_t_2423, ((V)&g_heff_2ebuild_2ecommands_2eendedJob_24s549099390x170744795_lam4_clo)})});
  V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
  V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
  V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
  V v_t_2429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
  return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2429}), heff_dup(v_hd_2413), heff_clo_n(g_heff_2ebuild_2ecommands_2eendedJob_24s549099390x170744795_lam5, 1, 5, (V[]){v_r_2412, v_hd_2413, v_ran_247, v_sel_240, v_k_2414})));
}
V g_heff_2ebuild_2ecommands_2eendedJob_24s549099390x170744795_lam1(V self, V *args) {
  V v_hd_2413 = args[0];
  V v_k_2414 = args[1];
  V v_r_2412 = heff_env(self)[0];
  V v_ran_247 = heff_env(self)[1];
  V v_sel_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2416 = heff_tag_n(TAG_Remove, 2, (V[]){heff_dup(heff_rfield(v_r_2412, 2)), ((V)&g_heff_2ebuild_2ecommands_2eendedJob_24s549099390x170744795_lam2_clo)});
  V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
  V v_t_2421 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
  return (g_co_2eop_24s94900133x232571340(v_t_2421, heff_dup(v_hd_2413), heff_clo_n(g_heff_2ebuild_2ecommands_2eendedJob_24s549099390x170744795_lam3, 1, 5, (V[]){v_r_2412, v_hd_2413, v_ran_247, v_sel_240, v_k_2414})));
}
V g_heff_2ebuild_2ecommands_2eendedJob_24s549099390x170744795_lam8(V self, V *args) {
  V v_hd_2448 = args[0];
  V v_k_2449 = args[1];
  heff_drop(v_hd_2448);
  V f_ = v_k_2449;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2etypeAtCmd_24s399193099x86398068_str0, 4, "heff");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etypeAtCmd_24s399193099x86398068_str1, 13, "nothing there");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etypeAtCmd_24s399193099x86398068_str2, 13, "nothing there");
V g_heff_2ebuild_2ecommands_2etypeAtCmd_24s399193099x86398068_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2etypeAtCmd_24s399193099x86398068_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2etypeAtCmd_24s399193099x86398068_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2etypeAtCmd_24s399193099x86398068_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2etypeAtCmd_24s399193099x86398068_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2etypeAtCmd_24s399193099x86398068_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2etypeAtCmd_24s399193099x86398068_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2etypeAtCmd_24s399193099x86398068_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2etypeAtCmd_24s399193099x86398068(V v_file_240, V v_offs_241) {
top: ;
  V v_c_242 = (g_heff_2ebuild_2ecommands_2eload_24s1185299161x1866120155(v_file_240));
  return heff_clo_n(g_heff_2ebuild_2ecommands_2etypeAtCmd_24s399193099x86398068_lam0, 2, 2, (V[]){v_c_242, v_offs_241});
}
V g_heff_2ebuild_2ecommands_2etypeAtCmd_24s399193099x86398068_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2etypeAtCmd_24s399193099x86398068(a[0], a[1]);
}
V g_heff_2ebuild_2ecommands_2etypeAtCmd_24s399193099x86398068_lam5(V self, V *args) {
  V v_off_2416 = args[0];
  V v_c_2415 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2417 = ({ V a_0 = v_off_2416; HeffT2 r_ = (g_prelude_2eparseInt_24cpr(a_0)); heff_drop(v_off_2416); r_; });
  {
    V v_field_2419 = v_t_2417.f[1];
    int64_t v_tag_2418 = ((int64_t)v_t_2417.f[0]);
    if ((v_tag_2418 == ((int64_t)0ULL))) {
      V v_o_2421 = v_field_2419;
      HeffT2 v_t_2422 = (g_heff_2ebuild_2equery_2etypeAt_24cpr(v_c_2415, v_o_2421));
      {
        V v_field_2424 = v_t_2422.f[1];
        int64_t v_tag_2423 = ((int64_t)v_t_2422.f[0]);
        if ((v_tag_2423 == ((int64_t)0ULL))) {
          V v_x_2426 = v_field_2424;
          return v_x_2426;
        } else {
          heff_drop(v_field_2424);
          return ((V)&g_heff_2ebuild_2ecommands_2etypeAtCmd_24s399193099x86398068_str1);
        }
      }
    } else {
      heff_drop(v_c_2415);
      heff_drop(v_field_2419);
      return ((V)&g_heff_2ebuild_2ecommands_2etypeAtCmd_24s399193099x86398068_str2);
    }
  }
}
V g_heff_2ebuild_2ecommands_2etypeAtCmd_24s399193099x86398068_lam4(V self, V *args) {
  V v_x_2410 = args[0];
  V v_cs_249 = heff_env(self)[0];
  V v_offs_241 = heff_env(self)[1];
  V v_hd_243 = heff_env(self)[2];
  V v_k_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2410);
  HeffT2 v_t_2411 = (g_heff_2ebuild_2edriver_2elastChecked_24cpr(v_cs_249));
  {
    V v_field_2413 = v_t_2411.f[1];
    int64_t v_tag_2412 = ((int64_t)v_t_2411.f[0]);
    if ((v_tag_2412 == ((int64_t)0ULL))) {
      V v_c_2415 = v_field_2413;
      V v_t_2427 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2ecommands_2etypeAtCmd_24s399193099x86398068_lam5, 1, 1, (V[]){v_c_2415}), v_offs_241));
      return (g_heff_2ebuild_2ecommands_2eprintLines_24s1721756835x860488624(v_t_2427, v_hd_243, v_k_244));
    } else {
      heff_drop(v_offs_241);
      heff_drop(v_field_2413);
      V v_t_2428 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
      V v_t_2429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2428})});
      V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
      V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
      V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
      V v_t_2433 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2432})});
      return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2433}), v_hd_243, v_k_244));
    }
  }
}
V g_heff_2ebuild_2ecommands_2etypeAtCmd_24s399193099x86398068_lam3(V self, V *args) {
  V v_x_248 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_offs_241 = heff_env(self)[1];
  V v_k_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_cs_249 = heff_get_n(v_x_248, 0, 2);
  return (g_heff_2ebuild_2ecommands_2eputFileDiags_24s1001351446x35627320(heff_dup(v_cs_249), heff_dup(v_hd_243), heff_clo_n(g_heff_2ebuild_2ecommands_2etypeAtCmd_24s399193099x86398068_lam4, 1, 4, (V[]){v_cs_249, v_offs_241, v_hd_243, v_k_244})));
}
V g_heff_2ebuild_2ecommands_2etypeAtCmd_24s399193099x86398068_lam2(V self, V *args) {
  V v_x_246 = args[0];
  V v_x_245 = heff_env(self)[0];
  V v_hd_243 = heff_env(self)[1];
  V v_offs_241 = heff_env(self)[2];
  V v_k_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_246);
  V v_c_247 = (g_heff_2ebuild_2esession_2ecachedAcc_24s52573320x1968432593(v_x_245));
  V f_ = v_c_247;
  heff_room[0] = heff_dup(v_hd_243);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2etypeAtCmd_24s399193099x86398068_lam3, 1, 3, (V[]){v_hd_243, v_offs_241, v_k_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2etypeAtCmd_24s399193099x86398068_lam1(V self, V *args) {
  V v_x_245 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_offs_241 = heff_env(self)[1];
  V v_k_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2ebuild_2ecommands_2eprintErrs_24s1245252666x1045981980(((V)&g_heff_2ebuild_2ecommands_2etypeAtCmd_24s399193099x86398068_str0), heff_dup(heff_rfield(v_x_245, 1)), MK_INT(0LL), heff_dup(v_hd_243), heff_clo_n(g_heff_2ebuild_2ecommands_2etypeAtCmd_24s399193099x86398068_lam2, 1, 4, (V[]){v_x_245, v_hd_243, v_offs_241, v_k_244})));
}
V g_heff_2ebuild_2ecommands_2etypeAtCmd_24s399193099x86398068_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  V v_c_242 = heff_env(self)[0];
  V v_offs_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_242;
  args[0] = heff_dup(v_hd_243);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2etypeAtCmd_24s399193099x86398068_lam1, 1, 3, (V[]){v_hd_243, v_offs_241, v_k_244});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ewriteAll_24s455230731x322530487_str0, 5, "win32");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ewriteAll_24s455230731x322530487_str1, 3, ".hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ewriteAll_24s455230731x322530487_str2, 19, "heff: cannot write ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ewriteAll_24s455230731x322530487_str3, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ewriteAll_24s455230731x322530487_str4, 19, "heff: cannot write ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ewriteAll_24s455230731x322530487_str5, 1, "\012");
V g_heff_2ebuild_2ecommands_2ewriteAll_24s455230731x322530487_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ewriteAll_24s455230731x322530487_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewriteAll_24s455230731x322530487_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2ewriteAll_24s455230731x322530487_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ewriteAll_24s455230731x322530487_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewriteAll_24s455230731x322530487_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2ewriteAll_24s455230731x322530487_lam4(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ewriteAll_24s455230731x322530487_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewriteAll_24s455230731x322530487_lam4, 1, 0};
V g_heff_2ebuild_2ecommands_2ewriteAll_24s455230731x322530487_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2ewriteAll_24s455230731x322530487_lam7(V self, V *args);
V g_heff_2ebuild_2ecommands_2ewriteAll_24s455230731x322530487_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2ewriteAll_24s455230731x322530487_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ewriteAll_24s455230731x322530487_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ewriteAll_24s455230731x322530487_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewriteAll_24s455230731x322530487_entry, 4, 0};

V g_heff_2ebuild_2ecommands_2ewriteAll_24s455230731x322530487(V v_dir_240, V v_x2_241, V v_p_242, V v_p_243) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_dir_240);
    heff_drop(v_p_242);
    return heff_tail(v_p_243, 1, (V[]){NTAG(TAG_True)});
  }
  case TAG_Cons: {
    V v_x21_244 = heff_field(v_x2_241, 0);
    V v_rest_245 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_244)) {
    case TAG_MkPair: {
      V v_f_246 = heff_field(v_x21_244, 0);
      V v_text_247 = heff_field(v_x21_244, 1);
      heff_take_n(v_x21_244, 3ULL, 2);
      V v_t_249 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2ewriteAll_24s455230731x322530487_lam0_clo)})});
      V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
      V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
      V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
      V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
      V v_t_2414 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
      return (g_co_2eop_24s94900133x232571340(v_t_2414, heff_dup(v_p_242), heff_clo_n(g_heff_2ebuild_2ecommands_2ewriteAll_24s455230731x322530487_lam1, 1, 6, (V[]){v_dir_240, v_f_246, v_p_242, v_text_247, v_rest_245, v_p_243})));
    }
    default: return heff_nomatch(v_x21_244);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2ecommands_2ewriteAll_24s455230731x322530487_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ewriteAll_24s455230731x322530487(a[0], a[1], a[2], a[3]);
}
V g_heff_2ebuild_2ecommands_2ewriteAll_24s455230731x322530487_lam0(V self, V *args) {
  V v_s_248 = args[0];
  return v_s_248;
}
V g_heff_2ebuild_2ecommands_2ewriteAll_24s455230731x322530487_lam2(V self, V *args) {
  V v_ok_2428 = args[0];
  return v_ok_2428;
}
V g_heff_2ebuild_2ecommands_2ewriteAll_24s455230731x322530487_lam4(V self, V *args) {
  V v_ok_2446 = args[0];
  return v_ok_2446;
}
V g_heff_2ebuild_2ecommands_2ewriteAll_24s455230731x322530487_lam6(V self, V *args) {
  V v_x_2461 = args[0];
  V v_p_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2461);
  V f_ = v_p_243;
  args[0] = NTAG(TAG_False);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ewriteAll_24s455230731x322530487_lam7(V self, V *args) {
  V v_x_2470 = args[0];
  V v_p_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2470);
  V f_ = v_p_243;
  args[0] = NTAG(TAG_False);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ewriteAll_24s455230731x322530487_lam5(V self, V *args) {
  V v_x_2452 = args[0];
  V v_x_2434 = heff_env(self)[0];
  V v_dir_240 = heff_env(self)[1];
  V v_rest_245 = heff_env(self)[2];
  V v_p_242 = heff_env(self)[3];
  V v_p_243 = heff_env(self)[4];
  V v_st_2417 = heff_env(self)[5];
  V v_f_246 = heff_env(self)[6];
  heff_clo_take(self, 7);
  if ((heff_dup(v_x_2434) == NTAG(TAG_True))) {
    heff_drop(v_x_2434);
    if ((heff_dup(v_x_2452) == NTAG(TAG_True))) {
      heff_drop(v_x_2452);
      heff_drop(v_st_2417);
      heff_drop(v_f_246);
      return (g_heff_2ebuild_2ecommands_2ewriteAll_24s455230731x322530487(v_dir_240, v_rest_245, v_p_242, v_p_243));
    } else {
      heff_drop(v_x_2452);
      heff_drop(v_rest_245);
      V v_t_2453 = ({ V a_0 = v_st_2417; V a_1 = v_dir_240; V a_2 = v_f_246; V r_ = (g_std_2epath_2ejoin(a_0, a_1, a_2)); heff_drop(v_st_2417); r_; });
      V v_str_2454 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ewriteAll_24s455230731x322530487_str2), v_t_2453);
      V v_t_2455 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_str_2454, ((V)&g_heff_2ebuild_2ecommands_2ewriteAll_24s455230731x322530487_str3)), NTAG(TAG_MkUnit)});
      V v_t_2456 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2455})});
      V v_t_2457 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2456})});
      V v_t_2458 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2457})});
      V v_t_2459 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2458})});
      V v_t_2460 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2459})});
      return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2460}), v_p_242, heff_clo_n(g_heff_2ebuild_2ecommands_2ewriteAll_24s455230731x322530487_lam6, 1, 1, (V[]){v_p_243})));
    }
  } else {
    heff_drop(v_x_2452);
    heff_drop(v_x_2434);
    heff_drop(v_rest_245);
    V v_t_2462 = ({ V a_0 = v_st_2417; V a_1 = v_dir_240; V a_2 = v_f_246; V r_ = (g_std_2epath_2ejoin(a_0, a_1, a_2)); heff_drop(v_st_2417); r_; });
    V v_str_2463 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ewriteAll_24s455230731x322530487_str4), v_t_2462);
    V v_t_2464 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_str_2463, ((V)&g_heff_2ebuild_2ecommands_2ewriteAll_24s455230731x322530487_str5)), NTAG(TAG_MkUnit)});
    V v_t_2465 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2464})});
    V v_t_2466 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2465})});
    V v_t_2467 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2466})});
    V v_t_2468 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2467})});
    V v_t_2469 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2468})});
    return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2469}), v_p_242, heff_clo_n(g_heff_2ebuild_2ecommands_2ewriteAll_24s455230731x322530487_lam7, 1, 1, (V[]){v_p_243})));
  }
}
V g_heff_2ebuild_2ecommands_2ewriteAll_24s455230731x322530487_lam3(V self, V *args) {
  V v_x_2434 = args[0];
  V v_st_2417 = heff_env(self)[0];
  V v_dir_240 = heff_env(self)[1];
  V v_f_246 = heff_env(self)[2];
  V v_text_247 = heff_env(self)[3];
  V v_p_242 = heff_env(self)[4];
  V v_rest_245 = heff_env(self)[5];
  V v_p_243 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_path_2435 = (g_std_2epath_2ejoin(v_st_2417, heff_dup(v_dir_240), heff_dup(v_f_246)));
  int64_t v_t_2436 = (heff_unbox_word(heff_strLength_lent(v_f_246, 0)) - ((int64_t)3ULL));
  V v_t_2437 = heff_strSlice(heff_dup(v_f_246), heff_box_word(v_t_2436), heff_strLength_lent(v_f_246, 0));
  V v_str_2445;
  if (heff_strEq_c(v_t_2437, ((V)&g_heff_2ebuild_2ecommands_2ewriteAll_24s455230731x322530487_str1))) {
    HeffT2 v_t_2439 = (g_heff_2esyntax_2eformat_2eformat_24cpr(heff_dup(v_text_247)));
    {
      V v_field_2441 = v_t_2439.f[1];
      int64_t v_tag_2440 = ((int64_t)v_t_2439.f[0]);
      if ((v_tag_2440 == ((int64_t)0ULL))) {
        V v_x_2443 = v_field_2441;
        heff_drop(v_x_2443);
        v_str_2445 = v_text_247;
      } else {
        heff_drop(v_text_247);
        V v_out_2444 = v_field_2441;
        v_str_2445 = v_out_2444;
      }
    }
  } else {
    v_str_2445 = v_text_247;
  }
  V v_t_2447 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_WriteFile, 3, (V[]){v_path_2435, v_str_2445, ((V)&g_heff_2ebuild_2ecommands_2ewriteAll_24s455230731x322530487_lam4_clo)})});
  V v_t_2448 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2447})});
  V v_t_2449 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2448})});
  V v_t_2450 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2449})});
  V v_t_2451 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2450})});
  return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2451}), heff_dup(v_p_242), heff_clo_n(g_heff_2ebuild_2ecommands_2ewriteAll_24s455230731x322530487_lam5, 1, 7, (V[]){v_x_2434, v_dir_240, v_rest_245, v_p_242, v_p_243, v_st_2417, v_f_246})));
}
V g_heff_2ebuild_2ecommands_2ewriteAll_24s455230731x322530487_lam1(V self, V *args) {
  V v_x_2415 = args[0];
  V v_dir_240 = heff_env(self)[0];
  V v_f_246 = heff_env(self)[1];
  V v_p_242 = heff_env(self)[2];
  V v_text_247 = heff_env(self)[3];
  V v_rest_245 = heff_env(self)[4];
  V v_p_243 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_st_2417;
  if (heff_strEq_c(v_x_2415, ((V)&g_heff_2ebuild_2ecommands_2ewriteAll_24s455230731x322530487_str0))) {
    v_st_2417 = NTAG(TAG_Windows);
  } else {
    v_st_2417 = NTAG(TAG_Posix);
  }
  V v_s_2418 = (g_std_2epath_2ejoin(v_st_2417, heff_dup(v_dir_240), heff_dup(v_f_246)));
  HeffT3 v_t_2419 = (g_std_2epath_2eparse_24cpr(v_st_2417, v_s_2418));
  V v_t_2426;
  {
    V v_field_2420 = v_t_2419.f[0];
    V v_field_2421 = v_t_2419.f[1];
    V v_field_2422 = v_t_2419.f[2];
    V v_t_2423 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_field_2422));
    V v_xs_2424 = ({ V a_0 = MK_INT(1LL); V a_1 = v_t_2423; V r_ = (g_list_2edrop(a_0, a_1)); heff_drop(v_t_2423); r_; });
    V v_t_2425 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2424));
    v_t_2426 = heff_rec_n(3, shape_drive__absolute__segments, (V[]){v_field_2420, v_field_2421, v_t_2425});
  }
  V v_path_2427 = (g_std_2epath_2erender(v_st_2417, v_t_2426));
  V v_t_2429 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_MakeDirectory, 2, (V[]){v_path_2427, ((V)&g_heff_2ebuild_2ecommands_2ewriteAll_24s455230731x322530487_lam2_clo)})});
  V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
  V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
  V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
  V v_t_2433 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2432})});
  return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2433}), heff_dup(v_p_242), heff_clo_n(g_heff_2ebuild_2ecommands_2ewriteAll_24s455230731x322530487_lam3, 1, 7, (V[]){v_st_2417, v_dir_240, v_f_246, v_text_247, v_p_242, v_rest_245, v_p_243})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestAll_24s1867599223x751417343_str0, 0, "");
V g_heff_2ebuild_2ecommands_2etestAll_24s1867599223x751417343_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestAll_24s1867599223x751417343_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestAll_24s1867599223x751417343_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestAll_24s1867599223x751417343_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestAll_24s1867599223x751417343_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2etestAll_24s1867599223x751417343_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2etestAll_24s1867599223x751417343_entry, 4, 0};

V g_heff_2ebuild_2ecommands_2etestAll_24s1867599223x751417343(V v_x1_240, V v_acc_241, V v_p_242, V v_p_243) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_p_242);
    return heff_tail(v_p_243, 1, (V[]){v_acc_241});
  }
  case TAG_Cons: {
    V v_f_244 = heff_field(v_x1_240, 0);
    V v_rest_245 = heff_field(v_x1_240, 1);
    return (g_heff_2ebuild_2ecommands_2etestOneF_24s617553487x14119047(MK_INT(2026LL), ((V)&g_heff_2ebuild_2ecommands_2etestAll_24s1867599223x751417343_str0), MK_INT(1LL), heff_dup(v_f_244), heff_dup(v_p_242), heff_clo_n(g_heff_2ebuild_2ecommands_2etestAll_24s1867599223x751417343_lam0, 1, 4, (V[]){v_p_242, v_acc_241, heff_dup(v_rest_245), v_p_243})));
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2ecommands_2etestAll_24s1867599223x751417343_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2etestAll_24s1867599223x751417343(a0, a[1], a[2], a[3]); heff_drop(a0); return r;
}
V g_heff_2ebuild_2ecommands_2etestAll_24s1867599223x751417343_lam1(V self, V *args) {
  V v_hd_248 = args[0];
  V v_k_249 = args[1];
  V v_r_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_248);
  V f_ = v_k_249;
  args[0] = v_r_247;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2etestAll_24s1867599223x751417343_lam3(V self, V *args) {
  V v_x_2414 = args[0];
  V v_p_2410 = heff_env(self)[0];
  V v_hd_2412 = heff_env(self)[1];
  V v_k_2413 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2ebuild_2ecommands_2etestReport_24s1197250805x667886372(heff_dup(heff_rfield(v_p_2410, 0)), heff_dup(heff_rfield(v_p_2410, 1)), heff_get_n(v_p_2410, 2, 7), v_x_2414, v_hd_2412, v_k_2413));
}
V g_heff_2ebuild_2ecommands_2etestAll_24s1867599223x751417343_lam2(V self, V *args) {
  V v_hd_2412 = args[0];
  V v_k_2413 = args[1];
  V v_c_2411 = heff_env(self)[0];
  V v_p_2410 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2411;
  args[0] = heff_dup(v_hd_2412);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2etestAll_24s1867599223x751417343_lam3, 1, 3, (V[]){v_p_2410, v_hd_2412, v_k_2413});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2ecommands_2etestAll_24s1867599223x751417343_lam4(V self, V *args) {
  V v_x_2416 = args[0];
  V v_acc_241 = heff_env(self)[0];
  V v_rest_245 = heff_env(self)[1];
  V v_p_242 = heff_env(self)[2];
  V v_p_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2417 = (g_heff_2ebuild_2ecommands_2eaddRes(v_acc_241, v_x_2416));
  return ({ V a_0 = v_rest_245; V a_1 = v_t_2417; V a_2 = v_p_242; V a_3 = v_p_243; V r_ = (g_heff_2ebuild_2ecommands_2etestAll_24s1867599223x751417343(a_0, a_1, a_2, a_3)); heff_drop(v_rest_245); r_; });
}
V g_heff_2ebuild_2ecommands_2etestAll_24s1867599223x751417343_lam0(V self, V *args) {
  V v_x_246 = args[0];
  V v_p_242 = heff_env(self)[0];
  V v_acc_241 = heff_env(self)[1];
  V v_rest_245 = heff_env(self)[2];
  V v_p_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_c_2415;
  switch (heff_tag_of(v_x_246)) {
  case TAG_Settled: {
    V v_r_247 = heff_field(v_x_246, 0);
    heff_take_n(v_x_246, 1ULL, 1);
    v_c_2415 = heff_clo_n(g_heff_2ebuild_2ecommands_2etestAll_24s1867599223x751417343_lam1, 2, 1, (V[]){v_r_247});
    break;
  }
  case TAG_Pend: {
    V v_p_2410 = heff_field(v_x_246, 0);
    heff_take_n(v_x_246, 1ULL, 1);
    V v_c_2411 = ({ V b_0 = NTAG(TAG_False); V a_1 = heff_dup(heff_rfield(v_p_2410, 0)); V a_2 = heff_dup(heff_rfield(v_p_2410, 3)); V r_ = (g_heff_2ebuild_2ecommands_2ewithGoldens_24s1156604030x1965065690(b_0, a_1, a_2)); heff_drop(b_0); r_; });
    v_c_2415 = heff_clo_n(g_heff_2ebuild_2ecommands_2etestAll_24s1867599223x751417343_lam2, 2, 2, (V[]){v_c_2411, v_p_2410});
    break;
  }
  default: heff_nomatch(v_x_246);
  }
  V f_ = v_c_2415;
  heff_room[0] = heff_dup(v_p_242);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2etestAll_24s1867599223x751417343_lam4, 1, 4, (V[]){v_acc_241, v_rest_245, v_p_242, v_p_243});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}