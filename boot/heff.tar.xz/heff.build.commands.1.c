// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Copy 17796
#define TAG_End 17255
#define TAG_Exited 20560
#define TAG_GetEnv 43934
#define TAG_Left 13886
#define TAG_MakeDirectory 16793
#define TAG_MkPath 49630
#define TAG_NotRun 12703
#define TAG_Platform 55558
#define TAG_ReadDirectory 46629
#define TAG_Remove 9747
#define TAG_Replace 14236
#define TAG_Right 62770
#define TAG_RunUnder 28888
#define TAG_Signalled 34337
#define TAG_Start 63542
#define TAG_Throw 56084
#define TAG_TimedOut 6056
#define TAG_Write 36323
#define TAG_WriteErr 37283
#define TAG_WriteFile 62589
#define LBL_apps 9496377
#define LBL_bad 306815
#define LBL_bin 307073
#define LBL_bind 9519364
#define LBL_build 295453320
#define LBL_c 317
#define LBL_done 9584713
#define LBL_effect 641056956
#define LBL_ended 298010324
#define LBL_err 310239
#define LBL_errors 652506774
#define LBL_globals 352931696
#define LBL_key 315609
#define LBL_malg 9839318
#define LBL_name 9869138
#define LBL_opt 319789
#define LBL_out 319944
#define LBL_pages 307784670
#define LBL_root 10001833
#define LBL_said 10017968
#define LBL_shipTo 1043811586
#define LBL_source 1050636102
#define LBL_style 311138763
#define LBL_top 324559
#define LBL_ty 10476
#define LBL_zig 330130
static uint32_t shape_apps__bad[] = {LBL_apps, LBL_bad};
static uint32_t shape_ended__out__err[] = {LBL_ended, LBL_out, LBL_err};
static uint32_t shape_name__build[] = {LBL_name, LBL_build};
static uint32_t shape_root__bin__said__pages__shipTo__opt[] = {LBL_root, LBL_bin, LBL_said, LBL_pages, LBL_shipTo, LBL_opt};
V g_co_2eop_24s1191249873x1860951653(V, V, V, V, V);
V g_co_2eop_24s1191249873x1860951653_entry(V self, V *a);
extern Clo g_co_2eop_24s1191249873x1860951653_clo;
V g_co_2eop_24s1398690846x1918384825(V, V, V);
V g_co_2eop_24s1398690846x1918384825_entry(V self, V *a);
extern Clo g_co_2eop_24s1398690846x1918384825_clo;
V g_co_2eop_24s1531911654x724325922(V, V, V);
V g_co_2eop_24s1531911654x724325922_entry(V self, V *a);
extern Clo g_co_2eop_24s1531911654x724325922_clo;
V g_co_2eop_24s1734868233x1940051977(V, V, V);
V g_co_2eop_24s1734868233x1940051977_entry(V self, V *a);
extern Clo g_co_2eop_24s1734868233x1940051977_clo;
V g_co_2eop_24s1998166633x1971890408(V);
V g_co_2eop_24s1998166633x1971890408_entry(V self, V *a);
extern Clo g_co_2eop_24s1998166633x1971890408_clo;
V g_co_2eop_24s40508559x1835373952(V, V, V);
V g_co_2eop_24s40508559x1835373952_entry(V self, V *a);
extern Clo g_co_2eop_24s40508559x1835373952_clo;
V g_co_2eop_24s40508559x1835373952_24tok1(V, V, V, V);
V g_co_2eop_24s40508559x1835373952_24tok1_entry(V self, V *a);
extern Clo g_co_2eop_24s40508559x1835373952_24tok1_clo;
V g_co_2eop_24s40508559x1835373952_24tok2(V, V, V, V);
V g_co_2eop_24s40508559x1835373952_24tok2_entry(V self, V *a);
extern Clo g_co_2eop_24s40508559x1835373952_24tok2_clo;
V g_co_2eop_24s847889387x1388281137(V, V, V);
V g_co_2eop_24s847889387x1388281137_entry(V self, V *a);
extern Clo g_co_2eop_24s847889387x1388281137_clo;
V g_co_2eop_24s907744994x1234676051(V, V);
V g_co_2eop_24s907744994x1234676051_entry(V self, V *a);
extern Clo g_co_2eop_24s907744994x1234676051_clo;
V g_co_2eop_24s91617614x2132230022(V, V, V, V);
V g_co_2eop_24s91617614x2132230022_entry(V self, V *a);
extern Clo g_co_2eop_24s91617614x2132230022_clo;
V g_exception_2eattempted_24s85350750x49672201_get(void);
V g_heff_2ebuild_2ebackcache_2ebackDir_get(void);
V g_heff_2ebuild_2ecommands_2eappFile(V, V, V, V);
V g_heff_2ebuild_2ecommands_2eappFile_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eappFile_clo;
V g_heff_2ebuild_2ecommands_2eappShips_24s816274383x1331904422(V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eappShips_24s816274383x1331904422_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eappShips_24s816274383x1331904422_clo;
V g_heff_2ebuild_2ecommands_2ebackDirOf(V);
V g_heff_2ebuild_2ecommands_2ebackDirOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ebackDirOf_clo;
V g_heff_2ebuild_2ecommands_2ebuildTarget(V, V);
V g_heff_2ebuild_2ecommands_2ebuildTarget_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ebuildTarget_clo;
V g_heff_2ebuild_2ecommands_2ecompileFound_24s1945822963x1352587118(V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecompileFound_24s1945822963x1352587118_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecompileFound_24s1945822963x1352587118_clo;
V g_heff_2ebuild_2ecommands_2ecompileFoundC_24s2017760430x1267524453(V, V, V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecompileFoundC_24s2017760430x1267524453_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecompileFoundC_24s2017760430x1267524453_clo;
V g_heff_2ebuild_2ecommands_2ecompileJsOut_24s462361791x320109327_24tok1(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecompileJsOut_24s462361791x320109327_24tok1_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecompileJsOut_24s462361791x320109327_24tok1_clo;
V g_heff_2ebuild_2ecommands_2eemitErrs_24s394189364x2134712221(V, V, V);
V g_heff_2ebuild_2ecommands_2eemitErrs_24s394189364x2134712221_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eemitErrs_24s394189364x2134712221_clo;
V g_heff_2ebuild_2ecommands_2eemitErrs_24s394189364x2134712221_24tok1(V, V, V, V);
V g_heff_2ebuild_2ecommands_2eemitErrs_24s394189364x2134712221_24tok1_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eemitErrs_24s394189364x2134712221_24tok1_clo;
V g_heff_2ebuild_2ecommands_2eemitErrs_24s394189364x2134712221_24tok2(V, V, V, V);
V g_heff_2ebuild_2ecommands_2eemitErrs_24s394189364x2134712221_24tok2_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eemitErrs_24s394189364x2134712221_24tok2_clo;
V g_heff_2ebuild_2ecommands_2eimportsOn(V);
V g_heff_2ebuild_2ecommands_2eimportsOn_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eimportsOn_clo;
V g_heff_2ebuild_2ecommands_2eimportsOn_24acc(V, V);
V g_heff_2ebuild_2ecommands_2eimportsOn_24acc_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eimportsOn_24acc_clo;
V g_heff_2ebuild_2ecommands_2ejsKept_24s1060797234x1576735494(V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ejsKept_24s1060797234x1576735494_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ejsKept_24s1060797234x1576735494_clo;
V g_heff_2ebuild_2ecommands_2ekeptParts_24s1926203457x1297589184(V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ekeptParts_24s1926203457x1297589184_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ekeptParts_24s1926203457x1297589184_clo;
V g_heff_2ebuild_2ecommands_2eload_24s1410275656x228048283(V);
V g_heff_2ebuild_2ecommands_2eload_24s1410275656x228048283_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eload_24s1410275656x228048283_clo;
V g_heff_2ebuild_2ecommands_2eonPathHint_24s1577168380x1162105305(V, V, V, V);
V g_heff_2ebuild_2ecommands_2eonPathHint_24s1577168380x1162105305_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eonPathHint_24s1577168380x1162105305_clo;
V g_heff_2ebuild_2ecommands_2eownRoot(V, V);
V g_heff_2ebuild_2ecommands_2eownRoot_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eownRoot_clo;
V g_heff_2ebuild_2ecommands_2epartsDir(V, V, V);
V g_heff_2ebuild_2ecommands_2epartsDir_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2epartsDir_clo;
V g_heff_2ebuild_2ecommands_2eplaceMade_24s146667787x1338613119(V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eplaceMade_24s146667787x1338613119_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eplaceMade_24s146667787x1338613119_clo;
V g_heff_2ebuild_2ecommands_2eprintErrs_24s115117455x797094904(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eprintErrs_24s115117455x797094904_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprintErrs_24s115117455x797094904_clo;
V g_heff_2ebuild_2ecommands_2eprintLines_24s994673524x1208908117(V, V, V);
V g_heff_2ebuild_2ecommands_2eprintLines_24s994673524x1208908117_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprintLines_24s994673524x1208908117_clo;
V g_heff_2ebuild_2ecommands_2eprovidesLeaf(V, V);
V g_heff_2ebuild_2ecommands_2eprovidesLeaf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprovidesLeaf_clo;
V g_heff_2ebuild_2ecommands_2eprovidesLeafC(V, V);
V g_heff_2ebuild_2ecommands_2eprovidesLeafC_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprovidesLeafC_clo;
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s1312606805x1381188003(V, V, V);
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s1312606805x1381188003_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eputFileDiags_24s1312606805x1381188003_clo;
V g_heff_2ebuild_2ecommands_2erunDir(V, V);
V g_heff_2ebuild_2ecommands_2erunDir_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2erunDir_clo;
V g_heff_2ebuild_2ecommands_2eselfKept_24s1039208617x848590819_24tok1(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eselfKept_24s1039208617x848590819_24tok1_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eselfKept_24s1039208617x848590819_24tok1_clo;
V g_heff_2ebuild_2ecommands_2etypeAtCmd_24s1179958766x743113785(V, V);
V g_heff_2ebuild_2ecommands_2etypeAtCmd_24s1179958766x743113785_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2etypeAtCmd_24s1179958766x743113785_clo;
V g_heff_2ebuild_2ecommands_2ewriteOutC_24s1877451407x355012956(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ewriteOutC_24s1877451407x355012956_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ewriteOutC_24s1877451407x355012956_clo;
V g_heff_2ebuild_2ecommands_2ewriteWhole_24s886536390x2068229138(V, V);
V g_heff_2ebuild_2ecommands_2ewriteWhole_24s886536390x2068229138_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ewriteWhole_24s886536390x2068229138_clo;
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s791070600x204593616(V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s791070600x204593616_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s791070600x204593616_clo;
V g_heff_2ebuild_2ecommands_2ezigObjects_24s1218369498x1750867255(V, V, V, V);
V g_heff_2ebuild_2ecommands_2ezigObjects_24s1218369498x1750867255_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ezigObjects_24s1218369498x1750867255_clo;
V g_heff_2ebuild_2edriver_2ecandLeaves(V);
V g_heff_2ebuild_2edriver_2ecandLeaves_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ecandLeaves_clo;
V g_heff_2ebuild_2edriver_2ecandidatesOf(V);
V g_heff_2ebuild_2edriver_2ecandidatesOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ecandidatesOf_clo;
HeffT2 g_heff_2ebuild_2edriver_2efindRunnable_24cpr(V, V, V);
HeffT2 g_heff_2ebuild_2edriver_2elastChecked_24cpr(V);
V g_heff_2ebuild_2edriver_2enubStrD(V);
V g_heff_2ebuild_2edriver_2enubStrD_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2enubStrD_clo;
HeffT2 g_heff_2ebuild_2equery_2einfoAt_24cpr(V, V);
V g_heff_2ebuild_2esession_2ecachedAcc_24s1827793511x304312721(V);
V g_heff_2ebuild_2esession_2ecachedAcc_24s1827793511x304312721_entry(V self, V *a);
extern Clo g_heff_2ebuild_2esession_2ecachedAcc_24s1827793511x304312721_clo;
V g_heff_2ecompile_2eemitc_2ecompileProgramC(V, V, V, V, V);
V g_heff_2ecompile_2eemitc_2ecompileProgramC_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2ecompileProgramC_clo;
V g_heff_2esyntax_2esurfaceprint_2enamed(V);
V g_heff_2esyntax_2esurfaceprint_2enamed_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2enamed_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2edrop(V, V);
V g_list_2edrop_entry(V self, V *a);
extern Clo g_list_2edrop_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2efoldl_24s680990791x1764841948(V, V, V, V, V, V, V);
V g_list_2efoldl_24s680990791x1764841948_entry(V self, V *a);
extern Clo g_list_2efoldl_24s680990791x1764841948_clo;
V g_list_2ekeepIf(V, V);
V g_list_2ekeepIf_entry(V self, V *a);
extern Clo g_list_2ekeepIf_clo;
V g_list_2ekeepIf_24s1063601026x1972672043(V, V);
V g_list_2ekeepIf_24s1063601026x1972672043_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1063601026x1972672043_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1325317589x1506218481(V, V, V);
V g_list_2emap_24s1325317589x1506218481_entry(V self, V *a);
extern Clo g_list_2emap_24s1325317589x1506218481_clo;
V g_list_2emap_24s219049803x1458391381(V);
V g_list_2emap_24s219049803x1458391381_entry(V self, V *a);
extern Clo g_list_2emap_24s219049803x1458391381_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
HeffT2 g_prelude_2eparseInt_24cpr(V);
V g_prelude_2esplitFrom(V, V, V, V, V);
V g_prelude_2esplitFrom_entry(V self, V *a);
extern Clo g_prelude_2esplitFrom_clo;
V g_std_2epath_2ejoin(V, V);
V g_std_2epath_2ejoin_entry(V self, V *a);
extern Clo g_std_2epath_2ejoin_clo;
V g_std_2epath_2enative_get(void);
V g_std_2epath_2eparse(V, V);
V g_std_2epath_2eparse_entry(V self, V *a);
extern Clo g_std_2epath_2eparse_clo;
HeffT3 g_std_2epath_2eparse_24cpr(V, V);
V g_std_2epath_2erender(V, V);
V g_std_2epath_2erender_entry(V self, V *a);
extern Clo g_std_2epath_2erender_clo;
HEFF_LIT(g_heff_2ebuild_2ecommands_2eownRoot_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eownRoot_str1, 3, "out");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eownRoot_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eownRoot_str3, 5, ".heff");
Clo g_heff_2ebuild_2ecommands_2eownRoot_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eownRoot_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2eownRoot(V v_st_240, V v_self_241) {
top: ;
  HeffT3 v_t_242 = (g_std_2epath_2eparse_24cpr(heff_dup(v_st_240), heff_dup(v_self_241)));
  V v_t_2412;
  {
    V v_field_243 = v_t_242.f[0];
    V v_field_244 = v_t_242.f[1];
    V v_field_245 = v_t_242.f[2];
    V v_d_246 = v_field_243;
    V v_a_247 = v_field_244;
    V v_xs_248 = v_field_245;
    V v_t_249 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_248));
    V v_xs_2410 = ({ V a_0 = MK_INT(1LL); V a_1 = v_t_249; V r_ = (g_list_2edrop(a_0, a_1)); heff_drop(v_t_249); r_; });
    V v_t_2411 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2410));
    v_t_2412 = heff_tag_n(TAG_MkPath, 3, (V[]){v_d_246, v_a_247, v_t_2411});
  }
  V v_s_2413 = ({ V a_0 = v_st_240; V a_1 = v_t_2412; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2412); r_; });
  HeffT3 v_t_2414 = (g_std_2epath_2eparse_24cpr(heff_dup(v_st_240), v_s_2413));
  V v_t_2424;
  {
    V v_field_2415 = v_t_2414.f[0];
    V v_field_2416 = v_t_2414.f[1];
    V v_field_2417 = v_t_2414.f[2];
    V v_x11_2418 = v_field_2415;
    heff_drop(v_x11_2418);
    V v_x12_2419 = v_field_2416;
    heff_drop(v_x12_2419);
    V v_xs_2420 = v_field_2417;
    V v_x1_2421 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2420));
    switch (heff_tag_of(v_x1_2421)) {
    case TAG_Nil: {
      v_t_2424 = ((V)&g_heff_2ebuild_2ecommands_2eownRoot_str0);
      break;
    }
    case TAG_Cons: {
      V v_x_2422 = heff_field(v_x1_2421, 0);
      heff_take_n(v_x1_2421, 1ULL, 2);
      v_t_2424 = v_x_2422;
      break;
    }
    default: heff_nomatch(v_x1_2421);
    }
  }
  V v_t_24118;
  if (heff_strEq_c(v_t_2424, ((V)&g_heff_2ebuild_2ecommands_2eownRoot_str1))) {
    HeffT3 v_t_2425 = (g_std_2epath_2eparse_24cpr(heff_dup(v_st_240), heff_dup(v_self_241)));
    V v_t_2435;
    {
      V v_field_2426 = v_t_2425.f[0];
      V v_field_2427 = v_t_2425.f[1];
      V v_field_2428 = v_t_2425.f[2];
      V v_d_2429 = v_field_2426;
      V v_a_2430 = v_field_2427;
      V v_xs_2431 = v_field_2428;
      V v_t_2432 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2431));
      V v_xs_2433 = ({ V a_0 = MK_INT(1LL); V a_1 = v_t_2432; V r_ = (g_list_2edrop(a_0, a_1)); heff_drop(v_t_2432); r_; });
      V v_t_2434 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2433));
      v_t_2435 = heff_tag_n(TAG_MkPath, 3, (V[]){v_d_2429, v_a_2430, v_t_2434});
    }
    V v_s_2436 = ({ V a_0 = v_st_240; V a_1 = v_t_2435; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2435); r_; });
    HeffT3 v_t_2437 = (g_std_2epath_2eparse_24cpr(heff_dup(v_st_240), v_s_2436));
    V v_t_2447;
    {
      V v_field_2438 = v_t_2437.f[0];
      V v_field_2439 = v_t_2437.f[1];
      V v_field_2440 = v_t_2437.f[2];
      V v_d_2441 = v_field_2438;
      V v_a_2442 = v_field_2439;
      V v_xs_2443 = v_field_2440;
      V v_t_2444 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2443));
      V v_xs_2445 = ({ V a_0 = MK_INT(1LL); V a_1 = v_t_2444; V r_ = (g_list_2edrop(a_0, a_1)); heff_drop(v_t_2444); r_; });
      V v_t_2446 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2445));
      v_t_2447 = heff_tag_n(TAG_MkPath, 3, (V[]){v_d_2441, v_a_2442, v_t_2446});
    }
    V v_s_2448 = ({ V a_0 = v_st_240; V a_1 = v_t_2447; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2447); r_; });
    HeffT3 v_t_2449 = (g_std_2epath_2eparse_24cpr(heff_dup(v_st_240), v_s_2448));
    V v_t_24121;
    {
      V v_field_2450 = v_t_2449.f[0];
      V v_field_2451 = v_t_2449.f[1];
      V v_field_2452 = v_t_2449.f[2];
      V v_x11_2453 = v_field_2450;
      heff_drop(v_x11_2453);
      V v_x12_2454 = v_field_2451;
      heff_drop(v_x12_2454);
      V v_xs_2455 = v_field_2452;
      V v_x1_2456 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2455));
      switch (heff_tag_of(v_x1_2456)) {
      case TAG_Nil: {
        v_t_24121 = ((V)&g_heff_2ebuild_2ecommands_2eownRoot_str2);
        break;
      }
      case TAG_Cons: {
        V v_x_2457 = heff_field(v_x1_2456, 0);
        heff_take_n(v_x1_2456, 1ULL, 2);
        v_t_24121 = v_x_2457;
        break;
      }
      default: heff_nomatch(v_x1_2456);
      }
    }
    v_t_24118 = heff_strEq(v_t_24121, ((V)&g_heff_2ebuild_2ecommands_2eownRoot_str3));
  } else {
    v_t_24118 = NTAG(TAG_False);
  }
  switch (heff_tag_of(v_t_24118)) {
  case TAG_True: {
    HeffT3 v_t_2459 = (g_std_2epath_2eparse_24cpr(heff_dup(v_st_240), v_self_241));
    V v_t_2469;
    {
      V v_field_2460 = v_t_2459.f[0];
      V v_field_2461 = v_t_2459.f[1];
      V v_field_2462 = v_t_2459.f[2];
      V v_d_2463 = v_field_2460;
      V v_a_2464 = v_field_2461;
      V v_xs_2465 = v_field_2462;
      V v_t_2466 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2465));
      V v_xs_2467 = ({ V a_0 = MK_INT(1LL); V a_1 = v_t_2466; V r_ = (g_list_2edrop(a_0, a_1)); heff_drop(v_t_2466); r_; });
      V v_t_2468 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2467));
      v_t_2469 = heff_tag_n(TAG_MkPath, 3, (V[]){v_d_2463, v_a_2464, v_t_2468});
    }
    V v_s_2470 = ({ V a_0 = v_st_240; V a_1 = v_t_2469; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2469); r_; });
    HeffT3 v_t_2471 = (g_std_2epath_2eparse_24cpr(heff_dup(v_st_240), v_s_2470));
    V v_t_2481;
    {
      V v_field_2472 = v_t_2471.f[0];
      V v_field_2473 = v_t_2471.f[1];
      V v_field_2474 = v_t_2471.f[2];
      V v_d_2475 = v_field_2472;
      V v_a_2476 = v_field_2473;
      V v_xs_2477 = v_field_2474;
      V v_t_2478 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2477));
      V v_xs_2479 = ({ V a_0 = MK_INT(1LL); V a_1 = v_t_2478; V r_ = (g_list_2edrop(a_0, a_1)); heff_drop(v_t_2478); r_; });
      V v_t_2480 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2479));
      v_t_2481 = heff_tag_n(TAG_MkPath, 3, (V[]){v_d_2475, v_a_2476, v_t_2480});
    }
    V v_s_2482 = ({ V a_0 = v_st_240; V a_1 = v_t_2481; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2481); r_; });
    HeffT3 v_t_2483 = (g_std_2epath_2eparse_24cpr(heff_dup(v_st_240), v_s_2482));
    V v_t_2493;
    {
      V v_field_2484 = v_t_2483.f[0];
      V v_field_2485 = v_t_2483.f[1];
      V v_field_2486 = v_t_2483.f[2];
      V v_d_2487 = v_field_2484;
      V v_a_2488 = v_field_2485;
      V v_xs_2489 = v_field_2486;
      V v_t_2490 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2489));
      V v_xs_2491 = ({ V a_0 = MK_INT(1LL); V a_1 = v_t_2490; V r_ = (g_list_2edrop(a_0, a_1)); heff_drop(v_t_2490); r_; });
      V v_t_2492 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2491));
      v_t_2493 = heff_tag_n(TAG_MkPath, 3, (V[]){v_d_2487, v_a_2488, v_t_2492});
    }
    return ({ V a_0 = v_st_240; V a_1 = v_t_2493; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_240); heff_drop(v_t_2493); r_; });
  }
  case TAG_False: {
    HeffT3 v_t_2494 = (g_std_2epath_2eparse_24cpr(heff_dup(v_st_240), v_self_241));
    V v_t_24104;
    {
      V v_field_2495 = v_t_2494.f[0];
      V v_field_2496 = v_t_2494.f[1];
      V v_field_2497 = v_t_2494.f[2];
      V v_d_2498 = v_field_2495;
      V v_a_2499 = v_field_2496;
      V v_xs_24100 = v_field_2497;
      V v_t_24101 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_24100));
      V v_xs_24102 = ({ V a_0 = MK_INT(1LL); V a_1 = v_t_24101; V r_ = (g_list_2edrop(a_0, a_1)); heff_drop(v_t_24101); r_; });
      V v_t_24103 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_24102));
      v_t_24104 = heff_tag_n(TAG_MkPath, 3, (V[]){v_d_2498, v_a_2499, v_t_24103});
    }
    V v_s_24105 = ({ V a_0 = v_st_240; V a_1 = v_t_24104; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_24104); r_; });
    HeffT3 v_t_24106 = (g_std_2epath_2eparse_24cpr(heff_dup(v_st_240), v_s_24105));
    V v_t_24116;
    {
      V v_field_24107 = v_t_24106.f[0];
      V v_field_24108 = v_t_24106.f[1];
      V v_field_24109 = v_t_24106.f[2];
      V v_d_24110 = v_field_24107;
      V v_a_24111 = v_field_24108;
      V v_xs_24112 = v_field_24109;
      V v_t_24113 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_24112));
      V v_xs_24114 = ({ V a_0 = MK_INT(1LL); V a_1 = v_t_24113; V r_ = (g_list_2edrop(a_0, a_1)); heff_drop(v_t_24113); r_; });
      V v_t_24115 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_24114));
      v_t_24116 = heff_tag_n(TAG_MkPath, 3, (V[]){v_d_24110, v_a_24111, v_t_24115});
    }
    return ({ V a_0 = v_st_240; V a_1 = v_t_24116; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_240); heff_drop(v_t_24116); r_; });
  }
  default: return heff_nomatch(v_t_24118);
  }
}
V g_heff_2ebuild_2ecommands_2eownRoot_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eownRoot(a[0], a[1]);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eimportsOn_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eimportsOn_str1, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eimportsOn_str2, 10, "imports it");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eimportsOn_str3, 9, "imports `");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eimportsOn_str4, 9, "`, which ");
Clo g_heff_2ebuild_2ecommands_2eimportsOn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eimportsOn_entry, 1, 0};

V g_heff_2ebuild_2ecommands_2eimportsOn(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return ((V)&g_heff_2ebuild_2ecommands_2eimportsOn_str0);
  }
  case TAG_Cons: {
    V v_x12_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 2ULL, 2);
    switch (heff_tag_of(v_x12_242)) {
    case TAG_Nil: {
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      return ((V)&g_heff_2ebuild_2ecommands_2eimportsOn_str1);
    }
    case TAG_Cons: {
      V v_b_243 = heff_field(v_x12_242, 0);
      V v_x122_244 = heff_field(v_x12_242, 1);
      heff_take_n(v_x12_242, 3ULL, 2);
      switch (heff_tag_of(v_x122_244)) {
      case TAG_Nil: {
        heff_drop_cell(v_ru_24x1_240_24Cons, 2);
        heff_drop(v_b_243);
        return ((V)&g_heff_2ebuild_2ecommands_2eimportsOn_str2);
      }
      case TAG_Cons: {
        V v_s_247 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eimportsOn_str3), heff_dup(v_b_243)), ((V)&g_heff_2ebuild_2ecommands_2eimportsOn_str4));
        return (g_heff_2ebuild_2ecommands_2eimportsOn_24acc(heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_b_243, v_x122_244}), v_s_247));
      }
      default: return heff_nomatch(v_x122_244);
      }
    }
    default: return heff_nomatch(v_x12_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2ecommands_2eimportsOn_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eimportsOn(a[0]);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebackDirOf_str0, 5, ".heff");
Clo g_heff_2ebuild_2ecommands_2ebackDirOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebackDirOf_entry, 1, 0};

V g_heff_2ebuild_2ecommands_2ebackDirOf(V v_ps_240) {
top: ;
  V v_style_241 = heff_take_field(v_ps_240, 5);
  V v_root_242 = heff_get_n(v_ps_240, 0, 6);
  V v_st_243 = heff_dup(v_style_241);
  V v_t_244 = (g_std_2epath_2eparse(heff_dup(v_st_243), v_root_242));
  V v_t_245 = (g_std_2epath_2eparse(heff_dup(v_st_243), ((V)&g_heff_2ebuild_2ecommands_2ebackDirOf_str0)));
  V v_t_246 = (g_std_2epath_2ejoin(v_t_244, v_t_245));
  V v_d_247 = ({ V a_0 = v_st_243; V a_1 = v_t_246; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_243); heff_drop(v_t_246); r_; });
  V v_st_248 = v_style_241;
  V v_t_249 = (g_std_2epath_2eparse(heff_dup(v_st_248), v_d_247));
  V v_t_2410 = (g_std_2epath_2eparse(heff_dup(v_st_248), heff_dup(g_heff_2ebuild_2ebackcache_2ebackDir_get())));
  V v_t_2411 = (g_std_2epath_2ejoin(v_t_249, v_t_2410));
  return ({ V a_0 = v_st_248; V a_1 = v_t_2411; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_248); heff_drop(v_t_2411); r_; });
}
V g_heff_2ebuild_2ecommands_2ebackDirOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ebackDirOf(a[0]);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildTarget_str0, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildTarget_str1, 3, "bin");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildTarget_str2, 5, "wrote");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildTarget_str3, 3, "-O1");
Clo g_heff_2ebuild_2ecommands_2ebuildTarget_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildTarget_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2ebuildTarget(V v_st_240, V v_root_241) {
top: ;
  V v_t_242 = (g_std_2epath_2eparse(heff_dup(v_st_240), ((V)&g_heff_2ebuild_2ecommands_2ebuildTarget_str0)));
  V v_t_243 = (g_std_2epath_2eparse(heff_dup(v_st_240), ((V)&g_heff_2ebuild_2ecommands_2ebuildTarget_str1)));
  V v_t_244 = (g_std_2epath_2ejoin(v_t_242, v_t_243));
  V v_b_245 = ({ V a_0 = v_st_240; V a_1 = v_t_244; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_244); r_; });
  V v_t_246 = (g_std_2epath_2eparse(heff_dup(v_st_240), heff_dup(v_root_241)));
  V v_t_247 = (g_std_2epath_2eparse(heff_dup(v_st_240), v_b_245));
  V v_t_248 = (g_std_2epath_2ejoin(v_t_246, v_t_247));
  V v_t_249 = ({ V a_0 = v_st_240; V a_1 = v_t_248; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_240); heff_drop(v_t_248); r_; });
  return heff_rec_n(6, shape_root__bin__said__pages__shipTo__opt, (V[]){v_root_241, v_t_249, ((V)&g_heff_2ebuild_2ecommands_2ebuildTarget_str2), NTAG(TAG_True), NTAG(TAG_Nothing), ((V)&g_heff_2ebuild_2ecommands_2ebuildTarget_str3)});
}
V g_heff_2ebuild_2ecommands_2ebuildTarget_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ebuildTarget(a[0], a[1]);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eappFile_str0, 3, "app");
Clo g_heff_2ebuild_2ecommands_2eappFile_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eappFile_entry, 4, 0};

V g_heff_2ebuild_2ecommands_2eappFile(V v_st_240, V v_t_241, V v_x_242, V v_f_243) {
top: ;
  V v_t_244 = (g_std_2epath_2eparse(heff_dup(v_st_240), ((V)&g_heff_2ebuild_2ecommands_2eappFile_str0)));
  V v_t_245 = (g_std_2epath_2eparse(heff_dup(v_st_240), v_x_242));
  V v_t_246 = (g_std_2epath_2ejoin(v_t_244, v_t_245));
  V v_a_247 = ({ V a_0 = v_st_240; V a_1 = v_t_246; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_246); r_; });
  V v_t_248 = (g_std_2epath_2eparse(heff_dup(v_st_240), v_a_247));
  V v_t_249 = (g_std_2epath_2eparse(heff_dup(v_st_240), v_f_243));
  V v_t_2410 = (g_std_2epath_2ejoin(v_t_248, v_t_249));
  V v_p_2411 = ({ V a_0 = v_st_240; V a_1 = v_t_2410; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2410); r_; });
  V v_t_2412 = (g_std_2epath_2eparse(heff_dup(v_st_240), heff_get_n(v_t_241, 0, 6)));
  V v_t_2413 = (g_std_2epath_2eparse(heff_dup(v_st_240), v_p_2411));
  V v_t_2414 = (g_std_2epath_2ejoin(v_t_2412, v_t_2413));
  return ({ V a_0 = v_st_240; V a_1 = v_t_2414; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_240); heff_drop(v_t_2414); r_; });
}
V g_heff_2ebuild_2ecommands_2eappFile_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eappFile(a[0], a[1], a[2], a[3]);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2erunDir_str0, 9, ".heff/run");
HEFF_LIT(g_heff_2ebuild_2ecommands_2erunDir_str1, 2, "..");
HEFF_LIT(g_heff_2ebuild_2ecommands_2erunDir_str2, 2, "..");
HEFF_LIT(g_heff_2ebuild_2ecommands_2erunDir_str3, 2, "..");
HEFF_LIT(g_heff_2ebuild_2ecommands_2erunDir_str4, 2, "..");
HEFF_LIT(g_heff_2ebuild_2ecommands_2erunDir_str5, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2erunDir_str6, 1, "_");
Clo g_heff_2ebuild_2ecommands_2erunDir_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2erunDir_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2erunDir(V v_paths_240, V v_file_241) {
top: ;
  V v_style_242 = heff_take_field(v_paths_240, 5);
  V v_root_243 = heff_get_n(v_paths_240, 0, 6);
  V v_st_244 = heff_dup(v_style_242);
  V v_t_245 = (g_std_2epath_2eparse(heff_dup(v_st_244), v_root_243));
  V v_t_246 = (g_std_2epath_2eparse(heff_dup(v_st_244), ((V)&g_heff_2ebuild_2ecommands_2erunDir_str0)));
  V v_t_247 = (g_std_2epath_2ejoin(v_t_245, v_t_246));
  V v_d_248 = ({ V a_0 = v_st_244; V a_1 = v_t_247; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_244); heff_drop(v_t_247); r_; });
  HeffT3 v_t_249 = (g_std_2epath_2eparse_24cpr(heff_dup(v_style_242), v_file_241));
  {
    V v_field_2410 = v_t_249.f[0];
    V v_field_2411 = v_t_249.f[1];
    V v_field_2412 = v_t_249.f[2];
    V v_d_2413 = v_field_2410;
    heff_drop(v_d_2413);
    V v_a_2414 = v_field_2411;
    V v_xs_2415 = v_field_2412;
    V v_xs_2416 = ({ V b_0 = ((V)&g_heff_2ebuild_2ecommands_2erunDir_str1); V a_1 = v_a_2414; V a_2 = ((V)&g_heff_2ebuild_2ecommands_2erunDir_str2); V b_3 = ((V)&g_heff_2ebuild_2ecommands_2erunDir_str3); V a_4 = ((V)&g_heff_2ebuild_2ecommands_2erunDir_str4); V a_5 = NTAG(TAG_Nil); V a_6 = v_xs_2415; V r_ = (g_list_2efoldl_24s680990791x1764841948(b_0, a_1, a_2, b_3, a_4, a_5, a_6)); heff_drop(b_0); heff_drop(v_a_2414); heff_drop(b_3); r_; });
    V v_t_2417 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2416));
    V v_x2_2418 = v_t_2417;
    V v_p_2421;
    switch (heff_tag_of(v_x2_2418)) {
    case TAG_Nil: {
      v_p_2421 = ((V)&g_heff_2ebuild_2ecommands_2erunDir_str5);
      break;
    }
    case TAG_Cons: {
      V v_x_2419 = heff_field(v_x2_2418, 0);
      V v_xs_2420 = heff_field(v_x2_2418, 1);
      heff_take_n(v_x2_2418, 3ULL, 2);
      v_p_2421 = ({ V a_0 = ((V)&g_heff_2ebuild_2ecommands_2erunDir_str6); V a_1 = v_x_2419; V a_2 = v_xs_2420; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2420); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2418);
    }
    V v_st_2422 = v_style_242;
    V v_t_2423 = (g_std_2epath_2eparse(heff_dup(v_st_2422), v_d_248));
    V v_t_2424 = (g_std_2epath_2eparse(heff_dup(v_st_2422), v_p_2421));
    V v_t_2425 = (g_std_2epath_2ejoin(v_t_2423, v_t_2424));
    return ({ V a_0 = v_st_2422; V a_1 = v_t_2425; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2422); heff_drop(v_t_2425); r_; });
  }
}
V g_heff_2ebuild_2ecommands_2erunDir_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2erunDir(a[0], a[1]);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ewriteWhole_24s886536390x2068229138_str0, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ewriteWhole_24s886536390x2068229138_str1, 4, ".tmp");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ewriteWhole_24s886536390x2068229138_str2, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ewriteWhole_24s886536390x2068229138_str3, 4, ".tmp");
V g_heff_2ebuild_2ecommands_2ewriteWhole_24s886536390x2068229138_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ewriteWhole_24s886536390x2068229138_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewriteWhole_24s886536390x2068229138_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2ewriteWhole_24s886536390x2068229138_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ewriteWhole_24s886536390x2068229138_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ewriteWhole_24s886536390x2068229138_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewriteWhole_24s886536390x2068229138_lam1, 1, 0};
V g_heff_2ebuild_2ecommands_2ewriteWhole_24s886536390x2068229138_lam5(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ewriteWhole_24s886536390x2068229138_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewriteWhole_24s886536390x2068229138_lam5, 1, 0};
V g_heff_2ebuild_2ecommands_2ewriteWhole_24s886536390x2068229138_lam7(V self, V *args);
V g_heff_2ebuild_2ecommands_2ewriteWhole_24s886536390x2068229138_lam6(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ewriteWhole_24s886536390x2068229138_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewriteWhole_24s886536390x2068229138_lam6, 1, 0};
V g_heff_2ebuild_2ecommands_2ewriteWhole_24s886536390x2068229138_lam8(V self, V *args);
V g_heff_2ebuild_2ecommands_2ewriteWhole_24s886536390x2068229138_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2ewriteWhole_24s886536390x2068229138_lam3(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ewriteWhole_24s886536390x2068229138_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewriteWhole_24s886536390x2068229138_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2ewriteWhole_24s886536390x2068229138(V v_path_240, V v_text_241) {
top: ;
  V v_t_242 = heff_intShow(heff_strLength_lent(v_text_241, 0));
  V v_t_243 = heff_strAppend(heff_strAppend(heff_dup(v_path_240), ((V)&g_heff_2ebuild_2ecommands_2ewriteWhole_24s886536390x2068229138_str0)), v_t_242);
  V v_path_244 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), heff_strAppend(v_t_243, ((V)&g_heff_2ebuild_2ecommands_2ewriteWhole_24s886536390x2068229138_str1))));
  V v_t_245 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_244; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_244); r_; });
  V v_a_247 = heff_tag_n(TAG_WriteFile, 3, (V[]){v_t_245, heff_dup(v_text_241), ((V)&g_heff_2ebuild_2ecommands_2ewriteWhole_24s886536390x2068229138_lam0_clo)});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_247})});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2412})});
  V v_c_2420 = heff_tr(g_co_2eop_24s1398690846x1918384825(heff_tag_n(TAG_InR, 1, (V[]){v_t_2413}), heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), ((V)&g_heff_2ebuild_2ecommands_2ewriteWhole_24s886536390x2068229138_lam1_clo)));
  return heff_clo_n(g_heff_2ebuild_2ecommands_2ewriteWhole_24s886536390x2068229138_lam3, 2, 3, (V[]){v_c_2420, v_text_241, v_path_240});
}
V g_heff_2ebuild_2ecommands_2ewriteWhole_24s886536390x2068229138_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ewriteWhole_24s886536390x2068229138(a[0], a[1]);
}
V g_heff_2ebuild_2ecommands_2ewriteWhole_24s886536390x2068229138_lam0(V self, V *args) {
  V v_r_246 = args[0];
  return v_r_246;
}
V g_heff_2ebuild_2ecommands_2ewriteWhole_24s886536390x2068229138_lam2(V self, V *args) {
  V v_hd_2418 = args[0];
  V v_k_2419 = args[1];
  V v_x_2417 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2418);
  V f_ = v_k_2419;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2417});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ewriteWhole_24s886536390x2068229138_lam1(V self, V *args) {
  V v_x_2414 = args[0];
  switch (heff_tag_of(v_x_2414)) {
  case TAG_Left: {
    V v_err_2415 = heff_field(v_x_2414, 0);
    V v_ru_24x_2414_24Left = heff_take_reuse_n(v_x_2414, 1ULL, 1);
    V v_t_2416 = heff_tag_at_n(v_ru_24x_2414_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_err_2415})});
    return (g_co_2eop_24s1998166633x1971890408(v_t_2416));
  }
  case TAG_Right: {
    V v_x_2417 = heff_field(v_x_2414, 0);
    heff_take_n(v_x_2414, 1ULL, 1);
    return heff_clo_n(g_heff_2ebuild_2ecommands_2ewriteWhole_24s886536390x2068229138_lam2, 2, 1, (V[]){v_x_2417});
  }
  default: return heff_nomatch(v_x_2414);
  }
}
V g_heff_2ebuild_2ecommands_2ewriteWhole_24s886536390x2068229138_lam5(V self, V *args) {
  V v_r_2432 = args[0];
  return v_r_2432;
}
V g_heff_2ebuild_2ecommands_2ewriteWhole_24s886536390x2068229138_lam7(V self, V *args) {
  V v_hd_2444 = args[0];
  V v_k_2445 = args[1];
  V v_x_2443 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2444);
  V f_ = v_k_2445;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2443});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ewriteWhole_24s886536390x2068229138_lam6(V self, V *args) {
  V v_x_2440 = args[0];
  switch (heff_tag_of(v_x_2440)) {
  case TAG_Left: {
    V v_err_2441 = heff_field(v_x_2440, 0);
    V v_ru_24x_2440_24Left = heff_take_reuse_n(v_x_2440, 1ULL, 1);
    V v_t_2442 = heff_tag_at_n(v_ru_24x_2440_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_err_2441})});
    return (g_co_2eop_24s1998166633x1971890408(v_t_2442));
  }
  case TAG_Right: {
    V v_x_2443 = heff_field(v_x_2440, 0);
    heff_take_n(v_x_2440, 1ULL, 1);
    return heff_clo_n(g_heff_2ebuild_2ecommands_2ewriteWhole_24s886536390x2068229138_lam7, 2, 1, (V[]){v_x_2443});
  }
  default: return heff_nomatch(v_x_2440);
  }
}
V g_heff_2ebuild_2ecommands_2ewriteWhole_24s886536390x2068229138_lam8(V self, V *args) {
  V v_x_2447 = args[0];
  V v_k_2422 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2450;
  switch (heff_tag_of(v_x_2447)) {
  case TAG_Left: {
    heff_take_n(v_x_2447, 0ULL, 1);
    v_t_2450 = NTAG(TAG_False);
    break;
  }
  case TAG_Right: {
    heff_take_n(v_x_2447, 0ULL, 1);
    v_t_2450 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_x_2447);
  }
  V f_ = v_k_2422;
  args[0] = v_t_2450;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ewriteWhole_24s886536390x2068229138_lam4(V self, V *args) {
  V v_x_2423 = args[0];
  V v_k_2422 = heff_env(self)[0];
  V v_text_241 = heff_env(self)[1];
  V v_path_240 = heff_env(self)[2];
  V v_hd_2421 = heff_env(self)[3];
  heff_clo_take(self, 4);
  switch (heff_tag_of(v_x_2423)) {
  case TAG_Left: {
    heff_take_n(v_x_2423, 0ULL, 1);
    heff_drop(v_text_241);
    heff_drop(v_path_240);
    heff_drop(v_hd_2421);
    V f_ = v_k_2422;
    args[0] = NTAG(TAG_False);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Right: {
    V v_ru_24x_2423_24Right = heff_take_reuse_n(v_x_2423, 0ULL, 1);
    V v_t_2426 = heff_intShow(heff_strLength(v_text_241));
    V v_t_2427 = heff_strAppend(heff_strAppend(heff_dup(v_path_240), ((V)&g_heff_2ebuild_2ecommands_2ewriteWhole_24s886536390x2068229138_str2)), v_t_2426);
    V v_path_2428 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), heff_strAppend(v_t_2427, ((V)&g_heff_2ebuild_2ecommands_2ewriteWhole_24s886536390x2068229138_str3))));
    V v_to_2429 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_path_240));
    V v_t_2430 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2428; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_2428); r_; });
    V v_t_2431 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_to_2429; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_to_2429); r_; });
    V v_a_2433 = heff_tag_n(TAG_Replace, 3, (V[]){v_t_2430, v_t_2431, ((V)&g_heff_2ebuild_2ecommands_2ewriteWhole_24s886536390x2068229138_lam5_clo)});
    V v_t_2434 = heff_tag_at_n(v_ru_24x_2423_24Right, TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2433})});
    V v_t_2435 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2434})});
    V v_t_2436 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2435})});
    V v_t_2437 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2436})});
    V v_t_2438 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2437})});
    V v_t_2439 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2438})});
    V v_c_2446 = heff_tr(g_co_2eop_24s1398690846x1918384825(heff_tag_n(TAG_InR, 1, (V[]){v_t_2439}), heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), ((V)&g_heff_2ebuild_2ecommands_2ewriteWhole_24s886536390x2068229138_lam6_clo)));
    V f_ = v_c_2446;
    heff_room[0] = v_hd_2421;
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ewriteWhole_24s886536390x2068229138_lam8, 1, 1, (V[]){v_k_2422});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_x_2423);
  }
}
V g_heff_2ebuild_2ecommands_2ewriteWhole_24s886536390x2068229138_lam3(V self, V *args) {
  V v_hd_2421 = args[0];
  V v_k_2422 = args[1];
  V v_c_2420 = heff_env(self)[0];
  V v_text_241 = heff_env(self)[1];
  V v_path_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_2420;
  args[0] = heff_dup(v_hd_2421);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ewriteWhole_24s886536390x2068229138_lam4, 1, 4, (V[]){v_k_2422, v_text_241, v_path_240, v_hd_2421});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprintLines_24s994673524x1208908117_str0, 1, "\012");
Clo g_heff_2ebuild_2ecommands_2eprintLines_24s994673524x1208908117_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eprintLines_24s994673524x1208908117_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2eprintLines_24s994673524x1208908117(V v_x1_240, V v_p_241, V v_p_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_p_241);
    return heff_tail(v_p_242, 1, (V[]){NTAG(TAG_MkUnit)});
  }
  case TAG_Cons: {
    V v_l_243 = heff_field(v_x1_240, 0);
    V v_rest_244 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_245 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Write, 2, (V[]){heff_strAppend(v_l_243, ((V)&g_heff_2ebuild_2ecommands_2eprintLines_24s994673524x1208908117_str0)), NTAG(TAG_MkUnit)});
    V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_245})});
    V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
    V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
    V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
    V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
    V v_t_2411 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2410})});
    return (g_co_2eop_24s1191249873x1860951653(v_rest_244, heff_dup(v_p_241), v_p_242, heff_tag_n(TAG_InR, 1, (V[]){v_t_2411}), v_p_241));
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2ecommands_2eprintLines_24s994673524x1208908117_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eprintLines_24s994673524x1208908117(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileFoundC_24s2017760430x1267524453_str0, 6, "heff: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileFoundC_24s2017760430x1267524453_str1, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileFoundC_24s2017760430x1267524453_str2, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileFoundC_24s2017760430x1267524453_str3, 6, "heff: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileFoundC_24s2017760430x1267524453_str4, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileFoundC_24s2017760430x1267524453_str5, 1, "/");
V g_heff_2ebuild_2ecommands_2ecompileFoundC_24s2017760430x1267524453_lam0(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileFoundC_24s2017760430x1267524453_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ecompileFoundC_24s2017760430x1267524453_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecompileFoundC_24s2017760430x1267524453_entry, 11, 0};

V g_heff_2ebuild_2ecommands_2ecompileFoundC_24s2017760430x1267524453(V v_bi_240, V v_file_241, V v_name_242, V v_outPath_243, V v_rt_244, V v_failed_245, V v_done_246, V v_c_247, V v_available_248, V v_z_249, V v_z_2410) {
top: ;
  V v_t_2411 = (g_heff_2ebuild_2edriver_2ecandidatesOf(heff_dup(v_c_247)));
  V v_t_2412 = ({ V a_0 = v_t_2411; V r_ = (g_heff_2ebuild_2edriver_2ecandLeaves(a_0)); heff_drop(v_t_2411); r_; });
  V v_t_2413 = (g_heff_2ebuild_2edriver_2enubStrD(v_t_2412));
  V v_t_2415 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileFoundC_24s2017760430x1267524453_lam0, 1, 1, (V[]){heff_dup(v_available_248)}), v_t_2413));
  HeffT2 v_t_2416 = (g_heff_2ebuild_2edriver_2efindRunnable_24cpr(v_t_2415, heff_dup(v_c_247), v_name_242));
  {
    V v_field_2418 = v_t_2416.f[1];
    int64_t v_tag_2417 = ((int64_t)v_t_2416.f[0]);
    if ((v_tag_2417 == ((int64_t)0ULL))) {
      heff_drop(v_bi_240);
      heff_drop(v_outPath_243);
      heff_drop_rec(v_rt_244, 2);
      heff_drop(v_done_246);
      heff_drop_rec(v_c_247, 14);
      heff_drop(v_available_248);
      V v_why_2419 = v_field_2418;
      V v_t_2420 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ecompileFoundC_24s2017760430x1267524453_str0), heff_dup(v_file_241)), ((V)&g_heff_2ebuild_2ecommands_2ecompileFoundC_24s2017760430x1267524453_str1));
      V v_t_2421 = heff_strAppend(heff_strAppend(v_t_2420, heff_dup(v_why_2419)), ((V)&g_heff_2ebuild_2ecommands_2ecompileFoundC_24s2017760430x1267524453_str2));
      V v_t_2422 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2421, NTAG(TAG_MkUnit)});
      V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
      V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
      V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
      V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
      V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
      V v_t_2428 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2427})});
      V v_t_2429 = heff_tr(heff_call(heff_dup(heff_rfield(v_z_249, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2428})}));
      return heff_tail(heff_dup(heff_rfield(v_z_249, 1)), 2, (V[]){v_t_2429, heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileFoundC_24s2017760430x1267524453_lam1, 1, 5, (V[]){v_file_241, v_failed_245, v_why_2419, v_z_249, v_z_2410})});
    } else {
      heff_drop(v_file_241);
      heff_drop(v_failed_245);
      V v_r_2432 = v_field_2418;
      int64_t v_t_2433 = (heff_unbox_word(heff_strLength_lent(v_outPath_243, 0)) - ((int64_t)1ULL));
      V v_t_2434 = heff_strSlice(heff_dup(v_outPath_243), heff_box_word(v_t_2433), heff_strLength_lent(v_outPath_243, 0));
      if (heff_strEq_c(v_t_2434, ((V)&g_heff_2ebuild_2ecommands_2ecompileFoundC_24s2017760430x1267524453_str5))) {
        int64_t v_t_2435 = (heff_unbox_word(heff_strLength_lent(v_outPath_243, 0)) - ((int64_t)1ULL));
        return (g_heff_2ebuild_2ecommands_2ekeptParts_24s1926203457x1297589184(v_bi_240, heff_strSlice(v_outPath_243, MK_INT(0LL), heff_box_word(v_t_2435)), v_rt_244, v_done_246, v_c_247, v_available_248, v_r_2432, v_z_249, v_z_2410));
      } else {
        heff_drop(v_bi_240);
        V v_t_2436 = heff_get_n(heff_get_n(v_c_247, 5, 14), 0, 10);
        V v_t_2437 = (g_heff_2ecompile_2eemitc_2ecompileProgramC(heff_take_field(v_rt_244, 0), v_available_248, v_t_2436, heff_take_field(v_r_2432, 0), heff_get_n(v_r_2432, 1, 2)));
        return (g_heff_2ebuild_2ecommands_2ewriteOutC_24s1877451407x355012956(v_outPath_243, heff_get_n(v_rt_244, 1, 2), v_done_246, v_t_2437, v_z_249, v_z_2410));
      }
    }
  }
}
V g_heff_2ebuild_2ecommands_2ecompileFoundC_24s2017760430x1267524453_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ebuild_2ecommands_2ecompileFoundC_24s2017760430x1267524453(a[0], a[1], a2, a[3], a[4], a[5], a[6], a[7], a[8], a[9], a[10]); heff_drop(a2); return r;
}
V g_heff_2ebuild_2ecommands_2ecompileFoundC_24s2017760430x1267524453_lam0(V self, V *args) {
  V v_k_2414 = args[0];
  V v_available_248 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_available_248; V a_1 = v_k_2414; V r_ = (g_heff_2ebuild_2ecommands_2eprovidesLeafC(a_0, a_1)); heff_drop(v_available_248); r_; });
}
V g_heff_2ebuild_2ecommands_2ecompileFoundC_24s2017760430x1267524453_lam1(V self, V *args) {
  V v_x_2430 = args[0];
  V v_file_241 = heff_env(self)[0];
  V v_failed_245 = heff_env(self)[1];
  V v_why_2419 = heff_env(self)[2];
  V v_z_249 = heff_env(self)[3];
  V v_z_2410 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2430);
  V v_t_2431 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ecompileFoundC_24s2017760430x1267524453_str3), v_file_241), ((V)&g_heff_2ebuild_2ecommands_2ecompileFoundC_24s2017760430x1267524453_str4));
  V f_ = v_failed_245;
  heff_room[0] = heff_strAppend(v_t_2431, v_why_2419);
  heff_room[1] = v_z_249;
  heff_room[2] = v_z_2410;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s791070600x204593616_str0, 2, ".c");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s791070600x204593616_str1, 4, ".zig");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s791070600x204593616_str2, 6, "zig cc");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s791070600x204593616_str3, 3, "-O0");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s791070600x204593616_str4, 5, "Debug");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s791070600x204593616_str5, 3, "-O1");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s791070600x204593616_str6, 11, "ReleaseSafe");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s791070600x204593616_str7, 3, "-Os");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s791070600x204593616_str8, 12, "ReleaseSmall");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s791070600x204593616_str9, 3, "-O2");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s791070600x204593616_str10, 3, "-O3");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s791070600x204593616_str11, 11, "ReleaseFast");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s791070600x204593616_str12, 5, "Debug");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s791070600x204593616_str13, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s791070600x204593616_str14, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s791070600x204593616_str15, 3, "-lm");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s791070600x204593616_str16, 2, "-o");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s791070600x204593616_str17, 2, "-w");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s791070600x204593616_str18, 2, "cc");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s791070600x204593616_str19, 3, "zig");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s791070600x204593616_str20, 27, ": `zig cc` could not build ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s791070600x204593616_str21, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s791070600x204593616_str22, 27, ": `zig cc` could not build ");
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s791070600x204593616_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s791070600x204593616_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s791070600x204593616_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s791070600x204593616_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s791070600x204593616_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s791070600x204593616_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s791070600x204593616_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s791070600x204593616_lam7(V self, V *args);
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s791070600x204593616_lam8(V self, V *args);
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s791070600x204593616_lam9(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s791070600x204593616_lam9_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s791070600x204593616_lam9, 1, 0};
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s791070600x204593616_lam12(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s791070600x204593616_lam12_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s791070600x204593616_lam12, 2, 0};
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s791070600x204593616_lam13(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s791070600x204593616_lam13_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s791070600x204593616_lam13, 1, 0};
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s791070600x204593616_lam17(V self, V *args);
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s791070600x204593616_lam16(V self, V *args);
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s791070600x204593616_lam15(V self, V *args);
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s791070600x204593616_lam14(V self, V *args);
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s791070600x204593616_lam11(V self, V *args);
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s791070600x204593616_lam10(V self, V *args);
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s791070600x204593616_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s791070600x204593616_lam5(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s791070600x204593616_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s791070600x204593616_entry, 8, 0};

V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s791070600x204593616(V v_lit_240, V v_failed_241, V v_who_242, V v_st_243, V v_p_244, V v_dir_245, V v_out_246, V v_next_247) {
top: ;
  V v_path_248 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), heff_dup(v_dir_245)));
  V v_t_249 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_248; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); r_; });
  V v_a_2411 = heff_tag_n(TAG_ReadDirectory, 2, (V[]){v_t_249, ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s791070600x204593616_lam0_clo)});
  V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2411})});
  V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
  V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
  V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
  V v_t_2416 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2416})});
  V v_c_2435 = (g_co_2eop_24s907744994x1234676051(heff_tag_n(TAG_InR, 1, (V[]){v_t_2417}), heff_clo_n(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s791070600x204593616_lam1, 3, 1, (V[]){v_path_248})));
  return heff_clo_n(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s791070600x204593616_lam5, 2, 9, (V[]){v_c_2435, v_st_243, v_dir_245, v_p_244, v_lit_240, v_out_246, v_next_247, v_who_242, v_failed_241});
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s791070600x204593616_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s791070600x204593616(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s791070600x204593616_lam0(V self, V *args) {
  V v_r_2410 = args[0];
  return v_r_2410;
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s791070600x204593616_lam3(V self, V *args) {
  V v_n_2426 = args[0];
  V v_path_248 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2427 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_n_2426));
  return (g_std_2epath_2ejoin(v_path_248, v_t_2427));
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s791070600x204593616_lam2(V self, V *args) {
  V v_x_2423 = args[0];
  V v_z_2424 = args[1];
  V v_z_2425 = args[2];
  V v_path_248 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_z_2424);
  V v_x_2428 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s791070600x204593616_lam3, 1, 1, (V[]){v_path_248}), v_x_2423));
  V v_x_2429 = (g_list_2emap_24s219049803x1458391381(v_x_2428));
  V f_ = v_z_2425;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2429});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s791070600x204593616_lam4(V self, V *args) {
  V v_n_2431 = args[0];
  V v_path_248 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2432 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_n_2431));
  return (g_std_2epath_2ejoin(v_path_248, v_t_2432));
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s791070600x204593616_lam1(V self, V *args) {
  V v_x_2418 = args[0];
  V v_z_2419 = args[1];
  V v_z_2420 = args[2];
  V v_path_248 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x_2418)) {
  case TAG_Left: {
    V v_err_2421 = heff_field(v_x_2418, 0);
    V v_ru_24x_2418_24Left = heff_take_reuse_n(v_x_2418, 1ULL, 1);
    V v_t_2422 = heff_tag_at_n(v_ru_24x_2418_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_err_2421})});
    return (g_co_2eop_24s91617614x2132230022(v_t_2422, heff_clo_n(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s791070600x204593616_lam2, 3, 1, (V[]){v_path_248}), v_z_2419, v_z_2420));
  }
  case TAG_Right: {
    V v_x_2430 = heff_field(v_x_2418, 0);
    heff_take_n(v_x_2418, 1ULL, 1);
    heff_drop(v_z_2419);
    V v_x_2433 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s791070600x204593616_lam4, 1, 1, (V[]){v_path_248}), v_x_2430));
    V v_x_2434 = (g_list_2emap_24s219049803x1458391381(v_x_2433));
    V f_ = v_z_2420;
    args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2434});
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_2418);
  }
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s791070600x204593616_lam7(V self, V *args) {
  V v_n_2445 = args[0];
  V v_st_243 = heff_env(self)[0];
  V v_dir_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2446 = (g_std_2epath_2eparse(heff_dup(v_st_243), v_dir_245));
  V v_t_2447 = (g_std_2epath_2eparse(heff_dup(v_st_243), v_n_2445));
  V v_t_2448 = (g_std_2epath_2ejoin(v_t_2446, v_t_2447));
  return ({ V a_0 = v_st_243; V a_1 = v_t_2448; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_243); heff_drop(v_t_2448); r_; });
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s791070600x204593616_lam8(V self, V *args) {
  V v_n_2453 = args[0];
  V v_st_243 = heff_env(self)[0];
  V v_dir_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2454 = (g_std_2epath_2eparse(heff_dup(v_st_243), v_dir_245));
  V v_t_2455 = (g_std_2epath_2eparse(heff_dup(v_st_243), v_n_2453));
  V v_t_2456 = (g_std_2epath_2ejoin(v_t_2454, v_t_2455));
  return ({ V a_0 = v_st_243; V a_1 = v_t_2456; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_243); heff_drop(v_t_2456); r_; });
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s791070600x204593616_lam9(V self, V *args) {
  V v_t_2461 = args[0];
  return v_t_2461;
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s791070600x204593616_lam12(V self, V *args) {
  V v_hd_2469 = args[0];
  V v_k_2470 = args[1];
  heff_drop(v_hd_2469);
  V v_t_2471 = heff_rec_n(3, shape_ended__out__err, (V[]){NTAG(TAG_NotRun), ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s791070600x204593616_str13), ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s791070600x204593616_str14)});
  V f_ = v_k_2470;
  args[0] = v_t_2471;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s791070600x204593616_lam13(V self, V *args) {
  V v_r_2479 = args[0];
  return v_r_2479;
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s791070600x204593616_lam17(V self, V *args) {
  V v_x_24111 = args[0];
  V v_who_242 = heff_env(self)[0];
  V v_out_246 = heff_env(self)[1];
  V v_failed_241 = heff_env(self)[2];
  V v_hd_2436 = heff_env(self)[3];
  V v_k_2437 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_24111);
  V v_t_24112 = heff_strAppend(heff_strAppend(v_who_242, ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s791070600x204593616_str22)), v_out_246);
  V f_ = v_failed_241;
  heff_room[0] = v_t_24112;
  heff_room[1] = v_hd_2436;
  heff_room[2] = v_k_2437;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s791070600x204593616_lam16(V self, V *args) {
  V v_x_24101 = args[0];
  V v_who_242 = heff_env(self)[0];
  V v_out_246 = heff_env(self)[1];
  V v_hd_2436 = heff_env(self)[2];
  V v_failed_241 = heff_env(self)[3];
  V v_k_2437 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_24101);
  V v_t_24102 = heff_strAppend(heff_strAppend(heff_dup(v_who_242), ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s791070600x204593616_str20)), heff_dup(v_out_246));
  V v_t_24103 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_t_24102, ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s791070600x204593616_str21)), NTAG(TAG_MkUnit)});
  V v_t_24104 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24103})});
  V v_t_24105 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24104})});
  V v_t_24106 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24105})});
  V v_t_24107 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24106})});
  V v_t_24108 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24107})});
  V v_t_24109 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24108})});
  V v_t_24110 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_2436, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24109})}));
  V f_ = heff_dup(heff_rfield(v_hd_2436, 1));
  heff_room[0] = v_t_24110;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s791070600x204593616_lam17, 1, 5, (V[]){v_who_242, v_out_246, v_failed_241, v_hd_2436, v_k_2437});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s791070600x204593616_lam15(V self, V *args) {
  V v_x_2489 = args[0];
  V v_ended_2484 = heff_env(self)[0];
  V v_next_247 = heff_env(self)[1];
  V v_hd_2436 = heff_env(self)[2];
  V v_k_2437 = heff_env(self)[3];
  V v_err_2485 = heff_env(self)[4];
  V v_who_242 = heff_env(self)[5];
  V v_out_246 = heff_env(self)[6];
  V v_failed_241 = heff_env(self)[7];
  heff_clo_take(self, 8);
  heff_drop(v_x_2489);
  V v_t_2492;
  switch (heff_tag_of(v_ended_2484)) {
  case TAG_Exited: {
    V v_n_2490 = heff_field(v_ended_2484, 0);
    heff_take_n(v_ended_2484, 1ULL, 1);
    v_t_2492 = heff_bool(heff_intEq_c_lent(v_n_2490, MK_INT(0LL), 2));
    heff_drop(v_n_2490);
    break;
  }
  case TAG_Signalled: {
    heff_take_n(v_ended_2484, 0ULL, 1);
    v_t_2492 = NTAG(TAG_False);
    break;
  }
  case TAG_TimedOut: {
    v_t_2492 = NTAG(TAG_False);
    break;
  }
  case TAG_NotRun: {
    v_t_2492 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_ended_2484);
  }
  if ((heff_dup(v_t_2492) == NTAG(TAG_True))) {
    heff_drop(v_err_2485);
    heff_drop(v_who_242);
    heff_drop(v_out_246);
    heff_drop(v_failed_241);
    heff_drop(v_t_2492);
    V f_ = v_next_247;
    heff_room[0] = v_hd_2436;
    heff_room[1] = v_k_2437;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    heff_drop(v_next_247);
    heff_drop(v_t_2492);
    V v_t_2493 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_err_2485, NTAG(TAG_MkUnit)});
    V v_t_2494 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2493})});
    V v_t_2495 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2494})});
    V v_t_2496 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2495})});
    V v_t_2497 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2496})});
    V v_t_2498 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2497})});
    V v_t_2499 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2498})});
    V v_t_24100 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_2436, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2499})}));
    V f_ = heff_dup(heff_rfield(v_hd_2436, 1));
    heff_room[0] = v_t_24100;
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s791070600x204593616_lam16, 1, 5, (V[]){v_who_242, v_out_246, v_hd_2436, v_failed_241, v_k_2437});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s791070600x204593616_lam14(V self, V *args) {
  V v_x_2483 = args[0];
  V v_x_2465 = heff_env(self)[0];
  V v_hd_2436 = heff_env(self)[1];
  V v_next_247 = heff_env(self)[2];
  V v_k_2437 = heff_env(self)[3];
  V v_who_242 = heff_env(self)[4];
  V v_out_246 = heff_env(self)[5];
  V v_failed_241 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_ended_2484 = heff_take_field(v_x_2483, 0);
  V v_err_2485 = heff_get_n(v_x_2483, 2, 3);
  V v_t_2486 = heff_tag_n(TAG_End, 2, (V[]){v_x_2465, NTAG(TAG_MkUnit)});
  V v_t_2487 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2486})});
  V v_t_2488 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_2436, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2487})}));
  V f_ = heff_dup(heff_rfield(v_hd_2436, 1));
  heff_room[0] = v_t_2488;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s791070600x204593616_lam15, 1, 8, (V[]){v_ended_2484, v_next_247, v_hd_2436, v_k_2437, v_err_2485, v_who_242, v_out_246, v_failed_241});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s791070600x204593616_lam11(V self, V *args) {
  V v_x_2468 = args[0];
  V v_out_246 = heff_env(self)[0];
  V v_x_2449 = heff_env(self)[1];
  V v_lit_240 = heff_env(self)[2];
  V v_x_2465 = heff_env(self)[3];
  V v_hd_2436 = heff_env(self)[4];
  V v_next_247 = heff_env(self)[5];
  V v_k_2437 = heff_env(self)[6];
  V v_who_242 = heff_env(self)[7];
  V v_failed_241 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_c_2482;
  switch (heff_tag_of(v_x_2468)) {
  case TAG_Nothing: {
    heff_drop(v_x_2449);
    heff_drop(v_lit_240);
    v_c_2482 = ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s791070600x204593616_lam12_clo);
    break;
  }
  case TAG_Just: {
    V v_os_2472 = heff_field(v_x_2468, 0);
    V v_ru_24x_2468_24Just = heff_take_reuse_n(v_x_2468, 1ULL, 1);
    V v_t_2473 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s791070600x204593616_str15), NTAG(TAG_Nil)});
    V v_t_2474 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s791070600x204593616_str16), heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_out_246), v_t_2473})});
    V v_t_2475 = (g_prelude_2e_2b_2b(v_os_2472, v_t_2474));
    V v_t_2476 = (g_prelude_2e_2b_2b(v_x_2449, v_t_2475));
    V v_ys_2477 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s791070600x204593616_str17), v_t_2476});
    V v_argv_2478 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s791070600x204593616_str18), heff_tag_n(TAG_Cons, 2, (V[]){v_lit_240, v_ys_2477})});
    V v_t_2480 = heff_tag_at_n(v_ru_24x_2468_24Just, TAG_InL, 1, (V[]){heff_tag_n(TAG_RunUnder, 4, (V[]){heff_dup(v_x_2465), ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s791070600x204593616_str19), v_argv_2478, ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s791070600x204593616_lam13_clo)})});
    V v_t_2481 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2480})});
    v_c_2482 = heff_tr(heff_call(((V)&g_co_2eop_24s847889387x1388281137_clo), 1, (V[]){v_t_2481}));
    break;
  }
  default: heff_nomatch(v_x_2468);
  }
  V f_ = v_c_2482;
  heff_room[0] = heff_dup(v_hd_2436);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s791070600x204593616_lam14, 1, 7, (V[]){v_x_2465, v_hd_2436, v_next_247, v_k_2437, v_who_242, v_out_246, v_failed_241});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s791070600x204593616_lam10(V self, V *args) {
  V v_x_2465 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_x_2457 = heff_env(self)[1];
  V v_hd_2436 = heff_env(self)[2];
  V v_out_246 = heff_env(self)[3];
  V v_x_2449 = heff_env(self)[4];
  V v_next_247 = heff_env(self)[5];
  V v_k_2437 = heff_env(self)[6];
  V v_who_242 = heff_env(self)[7];
  V v_failed_241 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_t_2466;
  if (heff_strEq_c_lent(v_lit_240, ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s791070600x204593616_str3), 2)) {
    v_t_2466 = ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s791070600x204593616_str4);
  } else {
    if (heff_strEq_c_lent(v_lit_240, ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s791070600x204593616_str5), 2)) {
      v_t_2466 = ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s791070600x204593616_str6);
    } else {
      if (heff_strEq_c_lent(v_lit_240, ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s791070600x204593616_str7), 2)) {
        v_t_2466 = ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s791070600x204593616_str8);
      } else {
        if ((heff_strEq_c_lent(v_lit_240, ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s791070600x204593616_str9), 2) || heff_strEq_c_lent(v_lit_240, ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s791070600x204593616_str10), 2))) {
          v_t_2466 = ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s791070600x204593616_str11);
        } else {
          v_t_2466 = ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s791070600x204593616_str12);
        }
      }
    }
  }
  V v_c_2467 = (g_heff_2ebuild_2ecommands_2ezigObjects_24s1218369498x1750867255(heff_dup(v_x_2465), v_t_2466, v_x_2457, NTAG(TAG_Nil)));
  V f_ = v_c_2467;
  heff_room[0] = heff_dup(v_hd_2436);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s791070600x204593616_lam11, 1, 9, (V[]){v_out_246, v_x_2449, v_lit_240, v_x_2465, v_hd_2436, v_next_247, v_k_2437, v_who_242, v_failed_241});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s791070600x204593616_lam6(V self, V *args) {
  V v_x_2438 = args[0];
  V v_st_243 = heff_env(self)[0];
  V v_dir_245 = heff_env(self)[1];
  V v_p_244 = heff_env(self)[2];
  V v_hd_2436 = heff_env(self)[3];
  V v_lit_240 = heff_env(self)[4];
  V v_out_246 = heff_env(self)[5];
  V v_next_247 = heff_env(self)[6];
  V v_k_2437 = heff_env(self)[7];
  V v_who_242 = heff_env(self)[8];
  V v_failed_241 = heff_env(self)[9];
  heff_clo_take(self, 10);
  V v_x_2441;
  switch (heff_tag_of(v_x_2438)) {
  case TAG_Left: {
    heff_take_n(v_x_2438, 0ULL, 1);
    v_x_2441 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Right: {
    V v_y_2440 = heff_field(v_x_2438, 0);
    V v_ru_24x_2438_24Right = heff_take_reuse_n(v_x_2438, 1ULL, 1);
    v_x_2441 = heff_tag_at_n(v_ru_24x_2438_24Right, TAG_Just, 1, (V[]){v_y_2440});
    break;
  }
  default: heff_nomatch(v_x_2438);
  }
  V v_t_2443;
  switch (heff_tag_of(v_x_2441)) {
  case TAG_Nothing: {
    v_t_2443 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_x_2442 = heff_dup(heff_field(v_x_2441, 0));
    v_t_2443 = v_x_2442;
    break;
  }
  default: heff_nomatch(v_x_2441);
  }
  V v_t_2444 = ({ V b_0 = ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s791070600x204593616_str0); V a_1 = v_t_2443; V r_ = (g_list_2ekeepIf_24s1063601026x1972672043(b_0, a_1)); heff_drop(b_0); r_; });
  V v_x_2449 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s791070600x204593616_lam7, 1, 2, (V[]){heff_dup(v_st_243), heff_dup(v_dir_245)}), v_t_2444));
  V v_t_2451;
  switch (heff_tag_of(v_x_2441)) {
  case TAG_Nothing: {
    v_t_2451 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_x_2450 = heff_field(v_x_2441, 0);
    heff_take_n(v_x_2441, 1ULL, 1);
    v_t_2451 = v_x_2450;
    break;
  }
  default: heff_nomatch(v_x_2441);
  }
  V v_t_2452 = ({ V b_0 = ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s791070600x204593616_str1); V a_1 = v_t_2451; V r_ = (g_list_2ekeepIf_24s1063601026x1972672043(b_0, a_1)); heff_drop(b_0); r_; });
  V v_x_2457 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s791070600x204593616_lam8, 1, 2, (V[]){v_st_243, v_dir_245}), v_t_2452));
  V v_t_2458 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_x_2449));
  V v_t_2459 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_x_2457));
  V v_total_2460 = heff_intAdd(heff_intAdd(v_t_2458, v_t_2459), MK_INT(1LL));
  V v_t_2462 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){v_p_244, ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s791070600x204593616_str2), v_total_2460, ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s791070600x204593616_lam9_clo)})});
  V v_t_2463 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2462})});
  V v_t_2464 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_2436, 2)), 1, (V[]){v_t_2463}));
  V f_ = heff_dup(heff_rfield(v_hd_2436, 1));
  heff_room[0] = v_t_2464;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s791070600x204593616_lam10, 1, 9, (V[]){v_lit_240, v_x_2457, v_hd_2436, v_out_246, v_x_2449, v_next_247, v_k_2437, v_who_242, v_failed_241});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s791070600x204593616_lam5(V self, V *args) {
  V v_hd_2436 = args[0];
  V v_k_2437 = args[1];
  V v_c_2435 = heff_env(self)[0];
  V v_st_243 = heff_env(self)[1];
  V v_dir_245 = heff_env(self)[2];
  V v_p_244 = heff_env(self)[3];
  V v_lit_240 = heff_env(self)[4];
  V v_out_246 = heff_env(self)[5];
  V v_next_247 = heff_env(self)[6];
  V v_who_242 = heff_env(self)[7];
  V v_failed_241 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V f_ = v_c_2435;
  args[0] = heff_dup(v_hd_2436);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s791070600x204593616_lam6, 1, 10, (V[]){v_st_243, v_dir_245, v_p_244, v_hd_2436, v_lit_240, v_out_246, v_next_247, v_k_2437, v_who_242, v_failed_241});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileFound_24s1945822963x1352587118_str0, 6, "heff: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileFound_24s1945822963x1352587118_str1, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileFound_24s1945822963x1352587118_str2, 1, "\012");
V g_heff_2ebuild_2ecommands_2ecompileFound_24s1945822963x1352587118_lam0(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileFound_24s1945822963x1352587118_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ecompileFound_24s1945822963x1352587118_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecompileFound_24s1945822963x1352587118_entry, 9, 0};

V g_heff_2ebuild_2ecommands_2ecompileFound_24s1945822963x1352587118(V v_bi_240, V v_file_241, V v_name_242, V v_outPath_243, V v_done_244, V v_c_245, V v_available_246, V v_z_247, V v_z_248) {
top: ;
  V v_t_249 = (g_heff_2ebuild_2edriver_2ecandidatesOf(heff_dup(v_c_245)));
  V v_t_2410 = ({ V a_0 = v_t_249; V r_ = (g_heff_2ebuild_2edriver_2ecandLeaves(a_0)); heff_drop(v_t_249); r_; });
  V v_t_2411 = (g_heff_2ebuild_2edriver_2enubStrD(v_t_2410));
  V v_t_2413 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileFound_24s1945822963x1352587118_lam0, 1, 1, (V[]){heff_dup(v_available_246)}), v_t_2411));
  HeffT2 v_t_2414 = (g_heff_2ebuild_2edriver_2efindRunnable_24cpr(v_t_2413, heff_dup(v_c_245), v_name_242));
  {
    V v_field_2416 = v_t_2414.f[1];
    int64_t v_tag_2415 = ((int64_t)v_t_2414.f[0]);
    if ((v_tag_2415 == ((int64_t)0ULL))) {
      heff_drop(v_bi_240);
      heff_drop(v_outPath_243);
      heff_drop(v_done_244);
      heff_drop(v_c_245);
      heff_drop(v_available_246);
      V v_why_2417 = v_field_2416;
      V v_t_2418 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ecompileFound_24s1945822963x1352587118_str0), v_file_241), ((V)&g_heff_2ebuild_2ecommands_2ecompileFound_24s1945822963x1352587118_str1));
      V v_t_2419 = heff_strAppend(heff_strAppend(v_t_2418, v_why_2417), ((V)&g_heff_2ebuild_2ecommands_2ecompileFound_24s1945822963x1352587118_str2));
      V v_t_2420 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2419, NTAG(TAG_MkUnit)});
      V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
      V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
      V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
      V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
      V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
      V v_t_2426 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2425})});
      V v_t_2427 = heff_tr(heff_call(heff_dup(heff_rfield(v_z_247, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2426})}));
      return heff_tail(heff_dup(heff_rfield(v_z_247, 1)), 2, (V[]){v_t_2427, heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileFound_24s1945822963x1352587118_lam1, 1, 2, (V[]){v_z_247, v_z_248})});
    } else {
      heff_drop(v_file_241);
      V v_r_2429 = v_field_2416;
      return (g_heff_2ebuild_2ecommands_2ejsKept_24s1060797234x1576735494(v_bi_240, v_outPath_243, v_done_244, v_c_245, v_available_246, v_r_2429, v_z_247, v_z_248));
    }
  }
}
V g_heff_2ebuild_2ecommands_2ecompileFound_24s1945822963x1352587118_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ebuild_2ecommands_2ecompileFound_24s1945822963x1352587118(a[0], a[1], a2, a[3], a[4], a[5], a[6], a[7], a[8]); heff_drop(a2); return r;
}
V g_heff_2ebuild_2ecommands_2ecompileFound_24s1945822963x1352587118_lam0(V self, V *args) {
  V v_k_2412 = args[0];
  V v_available_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_available_246; V a_1 = v_k_2412; V r_ = (g_heff_2ebuild_2ecommands_2eprovidesLeaf(a_0, a_1)); heff_drop(v_available_246); r_; });
}
V g_heff_2ebuild_2ecommands_2ecompileFound_24s1945822963x1352587118_lam1(V self, V *args) {
  V v_x_2428 = args[0];
  V v_z_247 = heff_env(self)[0];
  V v_z_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2428);
  return (g_co_2eop_24s40508559x1835373952(MK_INT(1LL), v_z_247, v_z_248));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2etypeAtCmd_24s1179958766x743113785_str0, 4, "heff");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etypeAtCmd_24s1179958766x743113785_str1, 3, " : ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etypeAtCmd_24s1179958766x743113785_str2, 10, "   (local)");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etypeAtCmd_24s1179958766x743113785_str3, 11, "   (global)");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etypeAtCmd_24s1179958766x743113785_str4, 13, "nothing there");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etypeAtCmd_24s1179958766x743113785_str5, 13, "nothing there");
V g_heff_2ebuild_2ecommands_2etypeAtCmd_24s1179958766x743113785_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2etypeAtCmd_24s1179958766x743113785_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2etypeAtCmd_24s1179958766x743113785_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2etypeAtCmd_24s1179958766x743113785_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2etypeAtCmd_24s1179958766x743113785_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2etypeAtCmd_24s1179958766x743113785_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2etypeAtCmd_24s1179958766x743113785_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2etypeAtCmd_24s1179958766x743113785_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2etypeAtCmd_24s1179958766x743113785(V v_file_240, V v_offs_241) {
top: ;
  V v_c_242 = (g_heff_2ebuild_2ecommands_2eload_24s1410275656x228048283(v_file_240));
  return heff_clo_n(g_heff_2ebuild_2ecommands_2etypeAtCmd_24s1179958766x743113785_lam0, 2, 2, (V[]){v_c_242, v_offs_241});
}
V g_heff_2ebuild_2ecommands_2etypeAtCmd_24s1179958766x743113785_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2etypeAtCmd_24s1179958766x743113785(a[0], a[1]);
}
V g_heff_2ebuild_2ecommands_2etypeAtCmd_24s1179958766x743113785_lam5(V self, V *args) {
  V v_off_2415 = args[0];
  V v_c_2414 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2416 = ({ V a_0 = v_off_2415; HeffT2 r_ = (g_prelude_2eparseInt_24cpr(a_0)); heff_drop(v_off_2415); r_; });
  {
    V v_field_2418 = v_t_2416.f[1];
    int64_t v_tag_2417 = ((int64_t)v_t_2416.f[0]);
    if ((v_tag_2417 == ((int64_t)0ULL))) {
      V v_o_2419 = v_field_2418;
      HeffT2 v_t_2420 = (g_heff_2ebuild_2equery_2einfoAt_24cpr(v_c_2414, v_o_2419));
      {
        V v_field_2422 = v_t_2420.f[1];
        int64_t v_tag_2421 = ((int64_t)v_t_2420.f[0]);
        if ((v_tag_2421 == ((int64_t)0ULL))) {
          V v_i_2423 = v_field_2422;
          V v_name_2424 = heff_take_field(v_i_2423, 1);
          V v_ty_2425 = heff_take_field(v_i_2423, 4);
          V v_key_2426 = heff_get_n(v_i_2423, 2, 5);
          V v_t_2427 = (g_heff_2esyntax_2esurfaceprint_2enamed(v_name_2424));
          V v_t_2428 = heff_tr(heff_call(v_ty_2425, 1, (V[]){NTAG(TAG_MkUnit)}));
          V v_t_2429 = heff_strAppend(heff_strAppend(v_t_2427, ((V)&g_heff_2ebuild_2ecommands_2etypeAtCmd_24s1179958766x743113785_str1)), v_t_2428);
          V v_t_2431;
          switch (heff_tag_of(v_key_2426)) {
          case TAG_Nothing: {
            v_t_2431 = ((V)&g_heff_2ebuild_2ecommands_2etypeAtCmd_24s1179958766x743113785_str2);
            break;
          }
          case TAG_Just: {
            heff_take_n(v_key_2426, 0ULL, 1);
            v_t_2431 = ((V)&g_heff_2ebuild_2ecommands_2etypeAtCmd_24s1179958766x743113785_str3);
            break;
          }
          default: heff_nomatch(v_key_2426);
          }
          V v_t_2432 = heff_strAppend(v_t_2429, v_t_2431);
          return v_t_2432;
        } else {
          heff_drop(v_field_2422);
          return ((V)&g_heff_2ebuild_2ecommands_2etypeAtCmd_24s1179958766x743113785_str4);
        }
      }
    } else {
      heff_drop(v_c_2414);
      heff_drop(v_field_2418);
      return ((V)&g_heff_2ebuild_2ecommands_2etypeAtCmd_24s1179958766x743113785_str5);
    }
  }
}
V g_heff_2ebuild_2ecommands_2etypeAtCmd_24s1179958766x743113785_lam4(V self, V *args) {
  V v_x_2410 = args[0];
  V v_cs_249 = heff_env(self)[0];
  V v_offs_241 = heff_env(self)[1];
  V v_hd_243 = heff_env(self)[2];
  V v_k_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2410);
  HeffT2 v_t_2411 = ({ V a_0 = v_cs_249; HeffT2 r_ = (g_heff_2ebuild_2edriver_2elastChecked_24cpr(a_0)); heff_drop(v_cs_249); r_; });
  {
    V v_field_2413 = v_t_2411.f[1];
    int64_t v_tag_2412 = ((int64_t)v_t_2411.f[0]);
    if ((v_tag_2412 == ((int64_t)0ULL))) {
      V v_c_2414 = v_field_2413;
      V v_t_2433 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2ecommands_2etypeAtCmd_24s1179958766x743113785_lam5, 1, 1, (V[]){v_c_2414}), v_offs_241));
      return (g_heff_2ebuild_2ecommands_2eprintLines_24s994673524x1208908117(v_t_2433, v_hd_243, v_k_244));
    } else {
      heff_drop(v_offs_241);
      heff_drop(v_field_2413);
      return (g_co_2eop_24s40508559x1835373952(MK_INT(1LL), v_hd_243, v_k_244));
    }
  }
}
V g_heff_2ebuild_2ecommands_2etypeAtCmd_24s1179958766x743113785_lam3(V self, V *args) {
  V v_x_248 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_offs_241 = heff_env(self)[1];
  V v_k_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_cs_249 = heff_get_n(v_x_248, 0, 2);
  return ({ V a_0 = v_cs_249; V a_1 = heff_dup(v_hd_243); V a_2 = heff_clo_n(g_heff_2ebuild_2ecommands_2etypeAtCmd_24s1179958766x743113785_lam4, 1, 4, (V[]){heff_dup(v_cs_249), v_offs_241, v_hd_243, v_k_244}); V r_ = (g_heff_2ebuild_2ecommands_2eputFileDiags_24s1312606805x1381188003(a_0, a_1, a_2)); heff_drop(v_cs_249); r_; });
}
V g_heff_2ebuild_2ecommands_2etypeAtCmd_24s1179958766x743113785_lam2(V self, V *args) {
  V v_x_246 = args[0];
  V v_x_245 = heff_env(self)[0];
  V v_hd_243 = heff_env(self)[1];
  V v_offs_241 = heff_env(self)[2];
  V v_k_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_246);
  V v_c_247 = (g_heff_2ebuild_2esession_2ecachedAcc_24s1827793511x304312721(v_x_245));
  V f_ = v_c_247;
  heff_room[0] = heff_dup(v_hd_243);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2etypeAtCmd_24s1179958766x743113785_lam3, 1, 3, (V[]){v_hd_243, v_offs_241, v_k_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2etypeAtCmd_24s1179958766x743113785_lam1(V self, V *args) {
  V v_x_245 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_offs_241 = heff_env(self)[1];
  V v_k_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2ebuild_2ecommands_2eprintErrs_24s115117455x797094904(((V)&g_heff_2ebuild_2ecommands_2etypeAtCmd_24s1179958766x743113785_str0), heff_dup(heff_rfield(v_x_245, 1)), MK_INT(0LL), heff_dup(v_hd_243), heff_clo_n(g_heff_2ebuild_2ecommands_2etypeAtCmd_24s1179958766x743113785_lam2, 1, 4, (V[]){v_x_245, v_hd_243, v_offs_241, v_k_244})));
}
V g_heff_2ebuild_2ecommands_2etypeAtCmd_24s1179958766x743113785_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  V v_c_242 = heff_env(self)[0];
  V v_offs_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_242;
  args[0] = heff_dup(v_hd_243);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2etypeAtCmd_24s1179958766x743113785_lam1, 1, 3, (V[]){v_hd_243, v_offs_241, v_k_244});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eappShips_24s816274383x1331904422_str0, 8, "build.hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eappShips_24s816274383x1331904422_str1, 1, "`");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eappShips_24s816274383x1331904422_str2, 1, "`");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eappShips_24s816274383x1331904422_str3, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eappShips_24s816274383x1331904422_str4, 2, ", ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eappShips_24s816274383x1331904422_str5, 11, ": it ships ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eappShips_24s816274383x1331904422_str6, 33, ", which the project does not have");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eappShips_24s816274383x1331904422_str7, 1, "\012");
V g_heff_2ebuild_2ecommands_2eappShips_24s816274383x1331904422_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eappShips_24s816274383x1331904422_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eappShips_24s816274383x1331904422_entry, 8, 0};

V g_heff_2ebuild_2ecommands_2eappShips_24s816274383x1331904422(V v_st_240, V v_t_241, V v_acc_242, V v_x_243, V v_a_244, V v_missing_245, V v_z_246, V v_z_247) {
top: ;
  V v_bind_248 = heff_take_field(v_z_246, 1);
  V v_malg_249 = heff_get_n(v_z_246, 2, 3);
  switch (heff_tag_of(v_missing_245)) {
  case TAG_Nil: {
    heff_drop(v_st_240);
    heff_drop(v_t_241);
    heff_drop(v_bind_248);
    heff_drop(v_malg_249);
    V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){heff_rec_n(2, shape_name__build, (V[]){v_x_243, v_a_244}), heff_take_field(v_acc_242, 0)});
    V v_t_2411 = ({ V rv_0 = v_t_2410; V rr_ = heff_rec_reuse_nf(v_acc_242, 2ULL, 2, shape_apps__bad, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
    return heff_tail(v_z_247, 1, (V[]){v_t_2411});
  }
  case TAG_Cons: {
    heff_drop(v_a_244);
    V v_t_2414 = (g_heff_2ebuild_2ecommands_2eappFile(v_st_240, v_t_241, v_x_243, ((V)&g_heff_2ebuild_2ecommands_2eappShips_24s816274383x1331904422_str0)));
    V v_x2_2415 = (g_list_2emap_24s1325317589x1506218481(((V)&g_heff_2ebuild_2ecommands_2eappShips_24s816274383x1331904422_str1), ((V)&g_heff_2ebuild_2ecommands_2eappShips_24s816274383x1331904422_str2), v_missing_245));
    V v_t_2418;
    switch (heff_tag_of(v_x2_2415)) {
    case TAG_Nil: {
      v_t_2418 = ((V)&g_heff_2ebuild_2ecommands_2eappShips_24s816274383x1331904422_str3);
      break;
    }
    case TAG_Cons: {
      V v_x_2416 = heff_field(v_x2_2415, 0);
      V v_xs_2417 = heff_field(v_x2_2415, 1);
      heff_take_n(v_x2_2415, 3ULL, 2);
      v_t_2418 = ({ V a_0 = ((V)&g_heff_2ebuild_2ecommands_2eappShips_24s816274383x1331904422_str4); V a_1 = v_x_2416; V a_2 = v_xs_2417; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2417); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2415);
    }
    V v_t_2419 = heff_strAppend(heff_strAppend(v_t_2414, ((V)&g_heff_2ebuild_2ecommands_2eappShips_24s816274383x1331904422_str5)), v_t_2418);
    V v_str_2420 = heff_strAppend(v_t_2419, ((V)&g_heff_2ebuild_2ecommands_2eappShips_24s816274383x1331904422_str6));
    V v_t_2421 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_str_2420, ((V)&g_heff_2ebuild_2ecommands_2eappShips_24s816274383x1331904422_str7)), NTAG(TAG_MkUnit)});
    V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
    V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
    V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
    V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
    V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
    V v_t_2427 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2426})});
    V v_t_2428 = heff_tr(heff_call(v_malg_249, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2427})}));
    return heff_tail(v_bind_248, 2, (V[]){v_t_2428, heff_clo_n(g_heff_2ebuild_2ecommands_2eappShips_24s816274383x1331904422_lam0, 1, 2, (V[]){v_acc_242, v_z_247})});
  }
  default: return heff_nomatch(v_missing_245);
  }
}
V g_heff_2ebuild_2ecommands_2eappShips_24s816274383x1331904422_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eappShips_24s816274383x1331904422(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
}
V g_heff_2ebuild_2ecommands_2eappShips_24s816274383x1331904422_lam0(V self, V *args) {
  V v_x_2429 = args[0];
  V v_acc_242 = heff_env(self)[0];
  V v_z_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2429);
  V v_t_2430 = heff_intAdd(heff_take_field(v_acc_242, 1), MK_INT(1LL));
  V v_t_2431 = ({ V rv_1 = v_t_2430; V rr_ = heff_rec_reuse_nf(v_acc_242, 1ULL, 2, shape_apps__bad, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
  V f_ = v_z_247;
  args[0] = v_t_2431;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eplaceMade_24s146667787x1338613119_str0, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eplaceMade_24s146667787x1338613119_str1, 4, ".new");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eplaceMade_24s146667787x1338613119_str2, 1, " ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eplaceMade_24s146667787x1338613119_str3, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eplaceMade_24s146667787x1338613119_str4, 11, "cannot put ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eplaceMade_24s146667787x1338613119_str5, 13, " in place of ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eplaceMade_24s146667787x1338613119_str6, 6, "heff: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eplaceMade_24s146667787x1338613119_str7, 1, "\012");
V g_heff_2ebuild_2ecommands_2eplaceMade_24s146667787x1338613119_lam0(V self, V *args);
V g_heff_2ebuild_2ecommands_2eplaceMade_24s146667787x1338613119_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eplaceMade_24s146667787x1338613119_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eplaceMade_24s146667787x1338613119_lam1, 1, 0};
V g_heff_2ebuild_2ecommands_2eplaceMade_24s146667787x1338613119_lam3(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eplaceMade_24s146667787x1338613119_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eplaceMade_24s146667787x1338613119_lam3, 1, 0};
V g_heff_2ebuild_2ecommands_2eplaceMade_24s146667787x1338613119_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2eplaceMade_24s146667787x1338613119_lam4(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eplaceMade_24s146667787x1338613119_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eplaceMade_24s146667787x1338613119_lam4, 1, 0};
V g_heff_2ebuild_2ecommands_2eplaceMade_24s146667787x1338613119_lam7(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eplaceMade_24s146667787x1338613119_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eplaceMade_24s146667787x1338613119_lam7, 1, 0};
V g_heff_2ebuild_2ecommands_2eplaceMade_24s146667787x1338613119_lam9(V self, V *args);
V g_heff_2ebuild_2ecommands_2eplaceMade_24s146667787x1338613119_lam8(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eplaceMade_24s146667787x1338613119_lam8_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eplaceMade_24s146667787x1338613119_lam8, 1, 0};
V g_heff_2ebuild_2ecommands_2eplaceMade_24s146667787x1338613119_lam11(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eplaceMade_24s146667787x1338613119_lam11_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eplaceMade_24s146667787x1338613119_lam11, 2, 0};
V g_heff_2ebuild_2ecommands_2eplaceMade_24s146667787x1338613119_lam12(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eplaceMade_24s146667787x1338613119_lam12_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eplaceMade_24s146667787x1338613119_lam12, 1, 0};
V g_heff_2ebuild_2ecommands_2eplaceMade_24s146667787x1338613119_lam14(V self, V *args);
V g_heff_2ebuild_2ecommands_2eplaceMade_24s146667787x1338613119_lam13(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eplaceMade_24s146667787x1338613119_lam13_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eplaceMade_24s146667787x1338613119_lam13, 1, 0};
V g_heff_2ebuild_2ecommands_2eplaceMade_24s146667787x1338613119_lam16(V self, V *args);
V g_heff_2ebuild_2ecommands_2eplaceMade_24s146667787x1338613119_lam15(V self, V *args);
V g_heff_2ebuild_2ecommands_2eplaceMade_24s146667787x1338613119_lam19(V self, V *args);
V g_heff_2ebuild_2ecommands_2eplaceMade_24s146667787x1338613119_lam18(V self, V *args);
V g_heff_2ebuild_2ecommands_2eplaceMade_24s146667787x1338613119_lam20(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eplaceMade_24s146667787x1338613119_lam20_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eplaceMade_24s146667787x1338613119_lam20, 1, 0};
V g_heff_2ebuild_2ecommands_2eplaceMade_24s146667787x1338613119_lam22(V self, V *args);
V g_heff_2ebuild_2ecommands_2eplaceMade_24s146667787x1338613119_lam21(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eplaceMade_24s146667787x1338613119_lam21_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eplaceMade_24s146667787x1338613119_lam21, 1, 0};
V g_heff_2ebuild_2ecommands_2eplaceMade_24s146667787x1338613119_lam24(V self, V *args);
V g_heff_2ebuild_2ecommands_2eplaceMade_24s146667787x1338613119_lam23(V self, V *args);
V g_heff_2ebuild_2ecommands_2eplaceMade_24s146667787x1338613119_lam17(V self, V *args);
V g_heff_2ebuild_2ecommands_2eplaceMade_24s146667787x1338613119_lam10(V self, V *args);
V g_heff_2ebuild_2ecommands_2eplaceMade_24s146667787x1338613119_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2eplaceMade_24s146667787x1338613119_lam2(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eplaceMade_24s146667787x1338613119_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eplaceMade_24s146667787x1338613119_entry, 8, 0};

V g_heff_2ebuild_2ecommands_2eplaceMade_24s146667787x1338613119(V v_st_240, V v_t_241, V v_pl_242, V v_next_243, V v_x_244, V v_x6_245, V v_p_246, V v_p_247) {
top: ;
  switch (heff_tag_of(v_x6_245)) {
  case TAG_Nothing: {
    heff_drop(v_st_240);
    heff_drop_rec(v_t_241, 6);
    heff_drop(v_x_244);
    return (g_co_2eop_24s1734868233x1940051977(v_pl_242, heff_dup(v_p_246), heff_clo_n(g_heff_2ebuild_2ecommands_2eplaceMade_24s146667787x1338613119_lam0, 1, 3, (V[]){v_next_243, v_p_246, v_p_247})));
  }
  case TAG_Just: {
    V v_n_249 = heff_field(v_x6_245, 0);
    V v_ru_24x6_245_24Just = heff_take_reuse_n(v_x6_245, 1ULL, 1);
    V v_t_2411 = heff_tag_at_n(v_ru_24x6_245_24Just, TAG_InL, 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){v_pl_242, heff_dup(v_n_249), MK_INT(0LL), ((V)&g_heff_2ebuild_2ecommands_2eplaceMade_24s146667787x1338613119_lam1_clo)})});
    V v_t_2412 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2411})});
    V v_t_2413 = heff_tr(heff_call(heff_dup(heff_rfield(v_p_246, 2)), 1, (V[]){v_t_2412}));
    return heff_tail(heff_dup(heff_rfield(v_p_246, 1)), 2, (V[]){v_t_2413, heff_clo_n(g_heff_2ebuild_2ecommands_2eplaceMade_24s146667787x1338613119_lam2, 1, 7, (V[]){v_st_240, v_t_241, v_n_249, v_p_246, v_x_244, v_next_243, v_p_247})});
  }
  default: return heff_nomatch(v_x6_245);
  }
}
V g_heff_2ebuild_2ecommands_2eplaceMade_24s146667787x1338613119_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eplaceMade_24s146667787x1338613119(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
}
V g_heff_2ebuild_2ecommands_2eplaceMade_24s146667787x1338613119_lam0(V self, V *args) {
  V v_x_248 = args[0];
  V v_next_243 = heff_env(self)[0];
  V v_p_246 = heff_env(self)[1];
  V v_p_247 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_248);
  V f_ = v_next_243;
  heff_room[0] = v_p_246;
  heff_room[1] = v_p_247;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2eplaceMade_24s146667787x1338613119_lam1(V self, V *args) {
  V v_t_2410 = args[0];
  return v_t_2410;
}
V g_heff_2ebuild_2ecommands_2eplaceMade_24s146667787x1338613119_lam3(V self, V *args) {
  V v_r_2422 = args[0];
  return v_r_2422;
}
V g_heff_2ebuild_2ecommands_2eplaceMade_24s146667787x1338613119_lam5(V self, V *args) {
  V v_hd_2434 = args[0];
  V v_k_2435 = args[1];
  V v_x_2433 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2434);
  V f_ = v_k_2435;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2433});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eplaceMade_24s146667787x1338613119_lam4(V self, V *args) {
  V v_x_2430 = args[0];
  switch (heff_tag_of(v_x_2430)) {
  case TAG_Left: {
    V v_err_2431 = heff_field(v_x_2430, 0);
    V v_ru_24x_2430_24Left = heff_take_reuse_n(v_x_2430, 1ULL, 1);
    V v_t_2432 = heff_tag_at_n(v_ru_24x_2430_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_err_2431})});
    return (g_co_2eop_24s1998166633x1971890408(v_t_2432));
  }
  case TAG_Right: {
    V v_x_2433 = heff_field(v_x_2430, 0);
    heff_take_n(v_x_2430, 1ULL, 1);
    return heff_clo_n(g_heff_2ebuild_2ecommands_2eplaceMade_24s146667787x1338613119_lam5, 2, 1, (V[]){v_x_2433});
  }
  default: return heff_nomatch(v_x_2430);
  }
}
V g_heff_2ebuild_2ecommands_2eplaceMade_24s146667787x1338613119_lam7(V self, V *args) {
  V v_r_2447 = args[0];
  return v_r_2447;
}
V g_heff_2ebuild_2ecommands_2eplaceMade_24s146667787x1338613119_lam9(V self, V *args) {
  V v_hd_2459 = args[0];
  V v_k_2460 = args[1];
  V v_x_2458 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2459);
  V f_ = v_k_2460;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2458});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eplaceMade_24s146667787x1338613119_lam8(V self, V *args) {
  V v_x_2455 = args[0];
  switch (heff_tag_of(v_x_2455)) {
  case TAG_Left: {
    V v_err_2456 = heff_field(v_x_2455, 0);
    V v_ru_24x_2455_24Left = heff_take_reuse_n(v_x_2455, 1ULL, 1);
    V v_t_2457 = heff_tag_at_n(v_ru_24x_2455_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_err_2456})});
    return (g_co_2eop_24s1998166633x1971890408(v_t_2457));
  }
  case TAG_Right: {
    V v_x_2458 = heff_field(v_x_2455, 0);
    heff_take_n(v_x_2455, 1ULL, 1);
    return heff_clo_n(g_heff_2ebuild_2ecommands_2eplaceMade_24s146667787x1338613119_lam9, 2, 1, (V[]){v_x_2458});
  }
  default: return heff_nomatch(v_x_2455);
  }
}
V g_heff_2ebuild_2ecommands_2eplaceMade_24s146667787x1338613119_lam11(V self, V *args) {
  V v_hd_2464 = args[0];
  V v_k_2465 = args[1];
  heff_drop(v_hd_2464);
  V f_ = v_k_2465;
  args[0] = NTAG(TAG_False);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eplaceMade_24s146667787x1338613119_lam12(V self, V *args) {
  V v_r_2475 = args[0];
  return v_r_2475;
}
V g_heff_2ebuild_2ecommands_2eplaceMade_24s146667787x1338613119_lam14(V self, V *args) {
  V v_hd_2487 = args[0];
  V v_k_2488 = args[1];
  V v_x_2486 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2487);
  V f_ = v_k_2488;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2486});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eplaceMade_24s146667787x1338613119_lam13(V self, V *args) {
  V v_x_2483 = args[0];
  switch (heff_tag_of(v_x_2483)) {
  case TAG_Left: {
    V v_err_2484 = heff_field(v_x_2483, 0);
    V v_ru_24x_2483_24Left = heff_take_reuse_n(v_x_2483, 1ULL, 1);
    V v_t_2485 = heff_tag_at_n(v_ru_24x_2483_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_err_2484})});
    return (g_co_2eop_24s1998166633x1971890408(v_t_2485));
  }
  case TAG_Right: {
    V v_x_2486 = heff_field(v_x_2483, 0);
    heff_take_n(v_x_2483, 1ULL, 1);
    return heff_clo_n(g_heff_2ebuild_2ecommands_2eplaceMade_24s146667787x1338613119_lam14, 2, 1, (V[]){v_x_2486});
  }
  default: return heff_nomatch(v_x_2483);
  }
}
V g_heff_2ebuild_2ecommands_2eplaceMade_24s146667787x1338613119_lam16(V self, V *args) {
  V v_x_2492 = args[0];
  V v_k_2491 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2495;
  switch (heff_tag_of(v_x_2492)) {
  case TAG_Left: {
    heff_take_n(v_x_2492, 0ULL, 1);
    v_t_2495 = NTAG(TAG_False);
    break;
  }
  case TAG_Right: {
    heff_take_n(v_x_2492, 0ULL, 1);
    v_t_2495 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_x_2492);
  }
  V f_ = v_k_2491;
  args[0] = v_t_2495;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eplaceMade_24s146667787x1338613119_lam15(V self, V *args) {
  V v_hd_2490 = args[0];
  V v_k_2491 = args[1];
  V v_c_2489 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_c_2489;
  args[0] = v_hd_2490;
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2eplaceMade_24s146667787x1338613119_lam16, 1, 1, (V[]){v_k_2491});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2ecommands_2eplaceMade_24s146667787x1338613119_lam19(V self, V *args) {
  V v_x_24113 = args[0];
  V v_next_243 = heff_env(self)[0];
  V v_p_246 = heff_env(self)[1];
  V v_p_247 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_24113);
  V f_ = v_next_243;
  heff_room[0] = v_p_246;
  heff_room[1] = v_p_247;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2eplaceMade_24s146667787x1338613119_lam18(V self, V *args) {
  V v_x_24112 = args[0];
  V v_x_2414 = heff_env(self)[0];
  V v_p_246 = heff_env(self)[1];
  V v_next_243 = heff_env(self)[2];
  V v_p_247 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_24112);
  return (g_co_2eop_24s1531911654x724325922(v_x_2414, heff_dup(v_p_246), heff_clo_n(g_heff_2ebuild_2ecommands_2eplaceMade_24s146667787x1338613119_lam19, 1, 3, (V[]){v_next_243, v_p_246, v_p_247})));
}
V g_heff_2ebuild_2ecommands_2eplaceMade_24s146667787x1338613119_lam20(V self, V *args) {
  V v_r_24116 = args[0];
  return v_r_24116;
}
V g_heff_2ebuild_2ecommands_2eplaceMade_24s146667787x1338613119_lam22(V self, V *args) {
  V v_hd_24128 = args[0];
  V v_k_24129 = args[1];
  V v_x_24127 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_24128);
  V f_ = v_k_24129;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_24127});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eplaceMade_24s146667787x1338613119_lam21(V self, V *args) {
  V v_x_24124 = args[0];
  switch (heff_tag_of(v_x_24124)) {
  case TAG_Left: {
    V v_err_24125 = heff_field(v_x_24124, 0);
    V v_ru_24x_24124_24Left = heff_take_reuse_n(v_x_24124, 1ULL, 1);
    V v_t_24126 = heff_tag_at_n(v_ru_24x_24124_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_err_24125})});
    return (g_co_2eop_24s1998166633x1971890408(v_t_24126));
  }
  case TAG_Right: {
    V v_x_24127 = heff_field(v_x_24124, 0);
    heff_take_n(v_x_24124, 1ULL, 1);
    return heff_clo_n(g_heff_2ebuild_2ecommands_2eplaceMade_24s146667787x1338613119_lam22, 2, 1, (V[]){v_x_24127});
  }
  default: return heff_nomatch(v_x_24124);
  }
}
V g_heff_2ebuild_2ecommands_2eplaceMade_24s146667787x1338613119_lam24(V self, V *args) {
  V v_x_24152 = args[0];
  V v_p_246 = heff_env(self)[0];
  V v_p_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_24152);
  return (g_co_2eop_24s40508559x1835373952(MK_INT(1LL), v_p_246, v_p_247));
}
V g_heff_2ebuild_2ecommands_2eplaceMade_24s146667787x1338613119_lam23(V self, V *args) {
  V v_x_24131 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_t_241 = heff_env(self)[1];
  V v_x_244 = heff_env(self)[2];
  V v_n_249 = heff_env(self)[3];
  V v_p_246 = heff_env(self)[4];
  V v_p_247 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_24131);
  V v_a_24132 = (g_heff_2ebuild_2ecommands_2epartsDir(heff_dup(v_st_240), heff_dup(v_t_241), v_x_244));
  V v_t_24133 = (g_std_2epath_2eparse(heff_dup(v_st_240), v_a_24132));
  V v_t_24134 = (g_std_2epath_2eparse(heff_dup(v_st_240), heff_dup(v_n_249)));
  V v_t_24135 = (g_std_2epath_2ejoin(v_t_24133, v_t_24134));
  V v_t_24136 = ({ V a_0 = v_st_240; V a_1 = v_t_24135; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_24135); r_; });
  V v_t_24137 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eplaceMade_24s146667787x1338613119_str4), v_t_24136), ((V)&g_heff_2ebuild_2ecommands_2eplaceMade_24s146667787x1338613119_str5));
  V v_t_24138 = (g_std_2epath_2eparse(heff_dup(v_st_240), heff_get_n(v_t_241, 1, 6)));
  V v_t_24139 = (g_std_2epath_2eparse(heff_dup(v_st_240), v_n_249));
  V v_t_24140 = (g_std_2epath_2ejoin(v_t_24138, v_t_24139));
  V v_t_24141 = ({ V a_0 = v_st_240; V a_1 = v_t_24140; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_240); heff_drop(v_t_24140); r_; });
  V v_why_24142 = heff_strAppend(v_t_24137, v_t_24141);
  V v_t_24143 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eplaceMade_24s146667787x1338613119_str6), v_why_24142), ((V)&g_heff_2ebuild_2ecommands_2eplaceMade_24s146667787x1338613119_str7));
  V v_t_24144 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_24143, NTAG(TAG_MkUnit)});
  V v_t_24145 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24144})});
  V v_t_24146 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24145})});
  V v_t_24147 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24146})});
  V v_t_24148 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24147})});
  V v_t_24149 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24148})});
  V v_t_24150 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24149})});
  V v_t_24151 = heff_tr(heff_call(heff_dup(heff_rfield(v_p_246, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24150})}));
  V f_ = heff_dup(heff_rfield(v_p_246, 1));
  heff_room[0] = v_t_24151;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2eplaceMade_24s146667787x1338613119_lam24, 1, 2, (V[]){v_p_246, v_p_247});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2eplaceMade_24s146667787x1338613119_lam17(V self, V *args) {
  V v_x_2497 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_t_241 = heff_env(self)[1];
  V v_n_249 = heff_env(self)[2];
  V v_p_246 = heff_env(self)[3];
  V v_x_2414 = heff_env(self)[4];
  V v_next_243 = heff_env(self)[5];
  V v_p_247 = heff_env(self)[6];
  V v_x_2419 = heff_env(self)[7];
  V v_x_244 = heff_env(self)[8];
  heff_clo_take(self, 9);
  if ((heff_dup(v_x_2497) == NTAG(TAG_True))) {
    heff_drop(v_x_2497);
    heff_drop(v_x_2419);
    heff_drop(v_x_244);
    V v_t_2498 = (g_std_2epath_2eparse(heff_dup(v_st_240), heff_take_field(v_t_241, 1)));
    V v_t_2499 = (g_std_2epath_2eparse(heff_dup(v_st_240), v_n_249));
    V v_t_24100 = (g_std_2epath_2ejoin(v_t_2498, v_t_2499));
    V v_path_24101 = ({ V a_0 = v_st_240; V a_1 = v_t_24100; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_240); heff_drop(v_t_24100); r_; });
    V v_t_24102 = heff_strAppend(heff_get_n(v_t_241, 2, 6), ((V)&g_heff_2ebuild_2ecommands_2eplaceMade_24s146667787x1338613119_str2));
    V v_t_24103 = heff_strAppend(heff_strAppend(v_t_24102, v_path_24101), ((V)&g_heff_2ebuild_2ecommands_2eplaceMade_24s146667787x1338613119_str3));
    V v_t_24104 = heff_tag_n(TAG_Write, 2, (V[]){v_t_24103, NTAG(TAG_MkUnit)});
    V v_t_24105 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24104})});
    V v_t_24106 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24105})});
    V v_t_24107 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24106})});
    V v_t_24108 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24107})});
    V v_t_24109 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24108})});
    V v_t_24110 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24109})});
    V v_t_24111 = heff_tr(heff_call(heff_dup(heff_rfield(v_p_246, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24110})}));
    V f_ = heff_dup(heff_rfield(v_p_246, 1));
    heff_room[0] = v_t_24111;
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2eplaceMade_24s146667787x1338613119_lam18, 1, 4, (V[]){v_x_2414, v_p_246, v_next_243, v_p_247});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    heff_drop(v_x_2497);
    heff_drop(v_x_2414);
    heff_drop(v_next_243);
    V v_path_24114 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_x_2419));
    V v_t_24115 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_24114; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_24114); r_; });
    V v_a_24117 = heff_tag_n(TAG_Remove, 2, (V[]){v_t_24115, ((V)&g_heff_2ebuild_2ecommands_2eplaceMade_24s146667787x1338613119_lam20_clo)});
    V v_t_24118 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_24117})});
    V v_t_24119 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24118})});
    V v_t_24120 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24119})});
    V v_t_24121 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24120})});
    V v_t_24122 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24121})});
    V v_t_24123 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24122})});
    V v_c_24130 = heff_tr(g_co_2eop_24s1398690846x1918384825(heff_tag_n(TAG_InR, 1, (V[]){v_t_24123}), heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), ((V)&g_heff_2ebuild_2ecommands_2eplaceMade_24s146667787x1338613119_lam21_clo)));
    V f_ = v_c_24130;
    heff_room[0] = heff_dup(v_p_246);
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2eplaceMade_24s146667787x1338613119_lam23, 1, 6, (V[]){v_st_240, v_t_241, v_x_244, v_n_249, v_p_246, v_p_247});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2ebuild_2ecommands_2eplaceMade_24s146667787x1338613119_lam10(V self, V *args) {
  V v_x_2462 = args[0];
  V v_x_2419 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_t_241 = heff_env(self)[2];
  V v_n_249 = heff_env(self)[3];
  V v_p_246 = heff_env(self)[4];
  V v_x_2414 = heff_env(self)[5];
  V v_next_243 = heff_env(self)[6];
  V v_p_247 = heff_env(self)[7];
  V v_x_244 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_c_2496;
  switch (heff_tag_of(v_x_2462)) {
  case TAG_Left: {
    heff_take_n(v_x_2462, 0ULL, 1);
    v_c_2496 = ((V)&g_heff_2ebuild_2ecommands_2eplaceMade_24s146667787x1338613119_lam11_clo);
    break;
  }
  case TAG_Right: {
    V v_ru_24x_2462_24Right = heff_take_reuse_n(v_x_2462, 0ULL, 1);
    V v_path_2467 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), heff_dup(v_x_2419)));
    V v_t_2468 = (g_std_2epath_2eparse(heff_dup(v_st_240), heff_dup(heff_rfield(v_t_241, 1))));
    V v_t_2469 = (g_std_2epath_2eparse(heff_dup(v_st_240), heff_dup(v_n_249)));
    V v_t_2470 = (g_std_2epath_2ejoin(v_t_2468, v_t_2469));
    V v_s_2471 = ({ V a_0 = v_st_240; V a_1 = v_t_2470; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2470); r_; });
    V v_to_2472 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_s_2471));
    V v_t_2473 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2467; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_2467); r_; });
    V v_t_2474 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_to_2472; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_to_2472); r_; });
    V v_a_2476 = heff_tag_n(TAG_Replace, 3, (V[]){v_t_2473, v_t_2474, ((V)&g_heff_2ebuild_2ecommands_2eplaceMade_24s146667787x1338613119_lam12_clo)});
    V v_t_2477 = heff_tag_at_n(v_ru_24x_2462_24Right, TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2476})});
    V v_t_2478 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2477})});
    V v_t_2479 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2478})});
    V v_t_2480 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2479})});
    V v_t_2481 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2480})});
    V v_t_2482 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2481})});
    V v_c_2489 = heff_tr(g_co_2eop_24s1398690846x1918384825(heff_tag_n(TAG_InR, 1, (V[]){v_t_2482}), heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), ((V)&g_heff_2ebuild_2ecommands_2eplaceMade_24s146667787x1338613119_lam13_clo)));
    v_c_2496 = heff_clo_n(g_heff_2ebuild_2ecommands_2eplaceMade_24s146667787x1338613119_lam15, 2, 1, (V[]){v_c_2489});
    break;
  }
  default: heff_nomatch(v_x_2462);
  }
  V f_ = v_c_2496;
  heff_room[0] = heff_dup(v_p_246);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2eplaceMade_24s146667787x1338613119_lam17, 1, 9, (V[]){v_st_240, v_t_241, v_n_249, v_p_246, v_x_2414, v_next_243, v_p_247, v_x_2419, v_x_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2eplaceMade_24s146667787x1338613119_lam6(V self, V *args) {
  V v_x_2437 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_t_241 = heff_env(self)[1];
  V v_x_244 = heff_env(self)[2];
  V v_n_249 = heff_env(self)[3];
  V v_x_2419 = heff_env(self)[4];
  V v_p_246 = heff_env(self)[5];
  V v_x_2414 = heff_env(self)[6];
  V v_next_243 = heff_env(self)[7];
  V v_p_247 = heff_env(self)[8];
  heff_clo_take(self, 9);
  heff_drop(v_x_2437);
  V v_a_2438 = (g_heff_2ebuild_2ecommands_2epartsDir(heff_dup(v_st_240), heff_dup(v_t_241), heff_dup(v_x_244)));
  V v_t_2439 = (g_std_2epath_2eparse(heff_dup(v_st_240), v_a_2438));
  V v_t_2440 = (g_std_2epath_2eparse(heff_dup(v_st_240), heff_dup(v_n_249)));
  V v_t_2441 = (g_std_2epath_2ejoin(v_t_2439, v_t_2440));
  V v_s_2442 = ({ V a_0 = v_st_240; V a_1 = v_t_2441; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2441); r_; });
  V v_path_2443 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_s_2442));
  V v_to_2444 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), heff_dup(v_x_2419)));
  V v_t_2445 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2443; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_2443); r_; });
  V v_t_2446 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_to_2444; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_to_2444); r_; });
  V v_a_2448 = heff_tag_n(TAG_Copy, 3, (V[]){v_t_2445, v_t_2446, ((V)&g_heff_2ebuild_2ecommands_2eplaceMade_24s146667787x1338613119_lam7_clo)});
  V v_t_2449 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2448})});
  V v_t_2450 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2449})});
  V v_t_2451 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2450})});
  V v_t_2452 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2451})});
  V v_t_2453 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2452})});
  V v_t_2454 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2453})});
  V v_c_2461 = heff_tr(g_co_2eop_24s1398690846x1918384825(heff_tag_n(TAG_InR, 1, (V[]){v_t_2454}), heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), ((V)&g_heff_2ebuild_2ecommands_2eplaceMade_24s146667787x1338613119_lam8_clo)));
  V f_ = v_c_2461;
  heff_room[0] = heff_dup(v_p_246);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2eplaceMade_24s146667787x1338613119_lam10, 1, 9, (V[]){v_x_2419, v_st_240, v_t_241, v_n_249, v_p_246, v_x_2414, v_next_243, v_p_247, v_x_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2eplaceMade_24s146667787x1338613119_lam2(V self, V *args) {
  V v_x_2414 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_t_241 = heff_env(self)[1];
  V v_n_249 = heff_env(self)[2];
  V v_p_246 = heff_env(self)[3];
  V v_x_244 = heff_env(self)[4];
  V v_next_243 = heff_env(self)[5];
  V v_p_247 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2415 = (g_std_2epath_2eparse(heff_dup(v_st_240), heff_dup(heff_rfield(v_t_241, 1))));
  V v_t_2416 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eplaceMade_24s146667787x1338613119_str0), heff_dup(v_n_249)), ((V)&g_heff_2ebuild_2ecommands_2eplaceMade_24s146667787x1338613119_str1));
  V v_t_2417 = (g_std_2epath_2eparse(heff_dup(v_st_240), v_t_2416));
  V v_t_2418 = (g_std_2epath_2ejoin(v_t_2415, v_t_2417));
  V v_x_2419 = ({ V a_0 = v_st_240; V a_1 = v_t_2418; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2418); r_; });
  V v_path_2420 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), heff_dup(v_x_2419)));
  V v_t_2421 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2420; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_2420); r_; });
  V v_a_2423 = heff_tag_n(TAG_Remove, 2, (V[]){v_t_2421, ((V)&g_heff_2ebuild_2ecommands_2eplaceMade_24s146667787x1338613119_lam3_clo)});
  V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2423})});
  V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
  V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
  V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
  V v_t_2428 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
  V v_t_2429 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2428})});
  V v_c_2436 = heff_tr(g_co_2eop_24s1398690846x1918384825(heff_tag_n(TAG_InR, 1, (V[]){v_t_2429}), heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), ((V)&g_heff_2ebuild_2ecommands_2eplaceMade_24s146667787x1338613119_lam4_clo)));
  V f_ = v_c_2436;
  heff_room[0] = heff_dup(v_p_246);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2eplaceMade_24s146667787x1338613119_lam6, 1, 9, (V[]){v_st_240, v_t_241, v_x_244, v_n_249, v_x_2419, v_p_246, v_x_2414, v_next_243, v_p_247});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eonPathHint_24s1577168380x1162105305_str0, 4, "PATH");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eonPathHint_24s1577168380x1162105305_str1, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eonPathHint_24s1577168380x1162105305_str2, 5, "win32");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eonPathHint_24s1577168380x1162105305_str3, 1, ";");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eonPathHint_24s1577168380x1162105305_str4, 1, ":");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eonPathHint_24s1577168380x1162105305_str5, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eonPathHint_24s1577168380x1162105305_str6, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eonPathHint_24s1577168380x1162105305_str7, 14, "heff install: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eonPathHint_24s1577168380x1162105305_str8, 60, " is not on the PATH: add it there to run them by their names");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eonPathHint_24s1577168380x1162105305_str9, 1, "\012");
V g_heff_2ebuild_2ecommands_2eonPathHint_24s1577168380x1162105305_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eonPathHint_24s1577168380x1162105305_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eonPathHint_24s1577168380x1162105305_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2eonPathHint_24s1577168380x1162105305_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eonPathHint_24s1577168380x1162105305_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eonPathHint_24s1577168380x1162105305_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2eonPathHint_24s1577168380x1162105305_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2eonPathHint_24s1577168380x1162105305_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2eonPathHint_24s1577168380x1162105305_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eonPathHint_24s1577168380x1162105305_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eonPathHint_24s1577168380x1162105305_entry, 4, 0};

V g_heff_2ebuild_2ecommands_2eonPathHint_24s1577168380x1162105305(V v_st_240, V v_bin_241, V v_hd_242, V v_k_243) {
top: ;
  V v_bind_244 = heff_take_field(v_hd_242, 1);
  V v_malg_245 = heff_get_n(v_hd_242, 2, 3);
  V v_t_247 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2eonPathHint_24s1577168380x1162105305_lam0_clo)})});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2412})});
  V v_t_2414 = heff_tr(heff_call(heff_dup(v_malg_245), 1, (V[]){v_t_2413}));
  return heff_tail(heff_dup(v_bind_244), 2, (V[]){v_t_2414, heff_clo_n(g_heff_2ebuild_2ecommands_2eonPathHint_24s1577168380x1162105305_lam1, 1, 5, (V[]){v_malg_245, v_bind_244, v_st_240, v_bin_241, v_k_243})});
}
V g_heff_2ebuild_2ecommands_2eonPathHint_24s1577168380x1162105305_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eonPathHint_24s1577168380x1162105305(a[0], a[1], a[2], a[3]);
}
V g_heff_2ebuild_2ecommands_2eonPathHint_24s1577168380x1162105305_lam0(V self, V *args) {
  V v_s_246 = args[0];
  return v_s_246;
}
V g_heff_2ebuild_2ecommands_2eonPathHint_24s1577168380x1162105305_lam2(V self, V *args) {
  V v_v_2416 = args[0];
  return v_v_2416;
}
V g_heff_2ebuild_2ecommands_2eonPathHint_24s1577168380x1162105305_lam4(V self, V *args) {
  V v_d_2430 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_bin_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2431 = (g_std_2epath_2eparse(heff_dup(v_st_240), v_d_2430));
  V v_t_2432 = (g_std_2epath_2eparse(heff_dup(v_st_240), ((V)&g_heff_2ebuild_2ecommands_2eonPathHint_24s1577168380x1162105305_str5)));
  V v_t_2433 = (g_std_2epath_2ejoin(v_t_2431, v_t_2432));
  V v_t_2434 = ({ V a_0 = v_st_240; V a_1 = v_t_2433; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2433); r_; });
  V v_t_2435 = (g_std_2epath_2eparse(heff_dup(v_st_240), v_bin_241));
  V v_t_2436 = (g_std_2epath_2eparse(heff_dup(v_st_240), ((V)&g_heff_2ebuild_2ecommands_2eonPathHint_24s1577168380x1162105305_str6)));
  V v_t_2437 = (g_std_2epath_2ejoin(v_t_2435, v_t_2436));
  V v_t_2438 = ({ V a_0 = v_st_240; V a_1 = v_t_2437; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_240); heff_drop(v_t_2437); r_; });
  V v_ret_24bool = heff_bool(heff_strEq_c_lent(v_t_2434, v_t_2438, 0));
  heff_drop(v_t_2434);
  heff_drop(v_t_2438);
  return v_ret_24bool;
}
V g_heff_2ebuild_2ecommands_2eonPathHint_24s1577168380x1162105305_lam3(V self, V *args) {
  V v_x_2425 = args[0];
  V v_x_2415 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_bin_241 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  V v_malg_245 = heff_env(self)[4];
  V v_bind_244 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_path_2427;
  switch (heff_tag_of(v_x_2425)) {
  case TAG_Nothing: {
    v_path_2427 = ((V)&g_heff_2ebuild_2ecommands_2eonPathHint_24s1577168380x1162105305_str1);
    break;
  }
  case TAG_Just: {
    V v_x_2426 = heff_field(v_x_2425, 0);
    heff_take_n(v_x_2425, 1ULL, 1);
    v_path_2427 = v_x_2426;
    break;
  }
  default: heff_nomatch(v_x_2425);
  }
  V v_sep_2428;
  if (heff_strEq_c(v_x_2415, ((V)&g_heff_2ebuild_2ecommands_2eonPathHint_24s1577168380x1162105305_str2))) {
    v_sep_2428 = ((V)&g_heff_2ebuild_2ecommands_2eonPathHint_24s1577168380x1162105305_str3);
  } else {
    v_sep_2428 = ((V)&g_heff_2ebuild_2ecommands_2eonPathHint_24s1577168380x1162105305_str4);
  }
  V v_t_2429;
  if ((heff_unbox_word(heff_strLength_lent(v_sep_2428, 0)) == ((int64_t)0ULL))) {
    heff_drop(v_sep_2428);
    v_t_2429 = heff_tag_n(TAG_Cons, 2, (V[]){v_path_2427, NTAG(TAG_Nil)});
  } else {
    v_t_2429 = ({ V a_0 = v_sep_2428; V a_1 = v_path_2427; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(v_sep_2428, v_path_2427, MK_INT(0LL), 4); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_sep_2428); heff_drop(v_path_2427); r_; });
  }
  V v_t_2439 = ({ V a_0 = heff_clo_n(g_heff_2ebuild_2ecommands_2eonPathHint_24s1577168380x1162105305_lam4, 1, 2, (V[]){v_st_240, heff_dup(v_bin_241)}); V a_1 = v_t_2429; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_t_2429); r_; });
  if ((heff_dup(v_t_2439) == NTAG(TAG_True))) {
    heff_drop(v_bin_241);
    heff_drop(v_malg_245);
    heff_drop(v_bind_244);
    heff_drop(v_t_2439);
    V f_ = v_k_243;
    args[0] = NTAG(TAG_MkUnit);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  } else {
    heff_drop(v_t_2439);
    V v_t_2440 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eonPathHint_24s1577168380x1162105305_str7), v_bin_241), ((V)&g_heff_2ebuild_2ecommands_2eonPathHint_24s1577168380x1162105305_str8));
    V v_t_2441 = heff_tag_n(TAG_Write, 2, (V[]){heff_strAppend(v_t_2440, ((V)&g_heff_2ebuild_2ecommands_2eonPathHint_24s1577168380x1162105305_str9)), NTAG(TAG_MkUnit)});
    V v_t_2442 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2441})});
    V v_t_2443 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2442})});
    V v_t_2444 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2443})});
    V v_t_2445 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2444})});
    V v_t_2446 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2445})});
    V v_t_2447 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2446})});
    V v_t_2448 = heff_tr(heff_call(v_malg_245, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2447})}));
    V f_ = v_bind_244;
    heff_room[0] = v_t_2448;
    heff_room[1] = v_k_243;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2ebuild_2ecommands_2eonPathHint_24s1577168380x1162105305_lam1(V self, V *args) {
  V v_x_2415 = args[0];
  V v_malg_245 = heff_env(self)[0];
  V v_bind_244 = heff_env(self)[1];
  V v_st_240 = heff_env(self)[2];
  V v_bin_241 = heff_env(self)[3];
  V v_k_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2417 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_GetEnv, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eonPathHint_24s1577168380x1162105305_str0), ((V)&g_heff_2ebuild_2ecommands_2eonPathHint_24s1577168380x1162105305_lam2_clo)})});
  V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
  V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
  V v_t_2422 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
  V v_t_2423 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2422})});
  V v_t_2424 = heff_tr(heff_call(heff_dup(v_malg_245), 1, (V[]){v_t_2423}));
  V f_ = heff_dup(v_bind_244);
  heff_room[0] = v_t_2424;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2eonPathHint_24s1577168380x1162105305_lam3, 1, 6, (V[]){v_x_2415, v_st_240, v_bin_241, v_k_243, v_malg_245, v_bind_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ecompileJsOut_24s462361791x320109327_24tok1_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ecompileJsOut_24s462361791x320109327_24tok1_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecompileJsOut_24s462361791x320109327_24tok1_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2ecompileJsOut_24s462361791x320109327_24tok1_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileJsOut_24s462361791x320109327_24tok1_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ecompileJsOut_24s462361791x320109327_24tok1_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecompileJsOut_24s462361791x320109327_24tok1_lam1, 1, 0};
V g_heff_2ebuild_2ecommands_2ecompileJsOut_24s462361791x320109327_24tok1_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileJsOut_24s462361791x320109327_24tok1_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileJsOut_24s462361791x320109327_24tok1_lam3(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ecompileJsOut_24s462361791x320109327_24tok1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecompileJsOut_24s462361791x320109327_24tok1_entry, 6, 0};

V g_heff_2ebuild_2ecommands_2ecompileJsOut_24s462361791x320109327_24tok1(V v_tok_240, V v_outPath_241, V v_bad_242, V v_o_243, V v_z_244, V v_z_245) {
top: ;
  V v_source_246 = heff_take_field(v_o_243, 0);
  V v_errors_247 = heff_get_n(v_o_243, 1, 2);
  V v_path_248 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_outPath_241));
  V v_t_249 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_248; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_248); r_; });
  V v_a_2411 = heff_tag_n(TAG_WriteFile, 3, (V[]){v_t_249, v_source_246, ((V)&g_heff_2ebuild_2ecommands_2ecompileJsOut_24s462361791x320109327_24tok1_lam0_clo)});
  V v_t_2412 = heff_tag_at_n(v_tok_240, TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2411})});
  V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
  V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
  V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
  V v_t_2416 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2416})});
  V v_c_2424 = heff_tr(g_co_2eop_24s1398690846x1918384825(heff_tag_n(TAG_InR, 1, (V[]){v_t_2417}), heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), ((V)&g_heff_2ebuild_2ecommands_2ecompileJsOut_24s462361791x320109327_24tok1_lam1_clo)));
  return heff_tail(v_c_2424, 2, (V[]){heff_dup(v_z_244), heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileJsOut_24s462361791x320109327_24tok1_lam3, 1, 4, (V[]){v_errors_247, v_z_244, v_z_245, heff_dup(v_bad_242)})});
}
V g_heff_2ebuild_2ecommands_2ecompileJsOut_24s462361791x320109327_24tok1_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ebuild_2ecommands_2ecompileJsOut_24s462361791x320109327_24tok1(a[0], a[1], a2, a[3], a[4], a[5]); heff_drop(a2); return r;
}
V g_heff_2ebuild_2ecommands_2ecompileJsOut_24s462361791x320109327_24tok1_lam0(V self, V *args) {
  V v_r_2410 = args[0];
  return v_r_2410;
}
V g_heff_2ebuild_2ecommands_2ecompileJsOut_24s462361791x320109327_24tok1_lam2(V self, V *args) {
  V v_hd_2422 = args[0];
  V v_k_2423 = args[1];
  V v_x_2421 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2422);
  V f_ = v_k_2423;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2421});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ecompileJsOut_24s462361791x320109327_24tok1_lam1(V self, V *args) {
  V v_x_2418 = args[0];
  switch (heff_tag_of(v_x_2418)) {
  case TAG_Left: {
    V v_err_2419 = heff_field(v_x_2418, 0);
    V v_ru_24x_2418_24Left = heff_take_reuse_n(v_x_2418, 1ULL, 1);
    V v_t_2420 = heff_tag_at_n(v_ru_24x_2418_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_err_2419})});
    return (g_co_2eop_24s1998166633x1971890408(v_t_2420));
  }
  case TAG_Right: {
    V v_x_2421 = heff_field(v_x_2418, 0);
    heff_take_n(v_x_2418, 1ULL, 1);
    return heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileJsOut_24s462361791x320109327_24tok1_lam2, 2, 1, (V[]){v_x_2421});
  }
  default: return heff_nomatch(v_x_2418);
  }
}
V g_heff_2ebuild_2ecommands_2ecompileJsOut_24s462361791x320109327_24tok1_lam4(V self, V *args) {
  V v_x_2427 = args[0];
  V v_z_244 = heff_env(self)[0];
  V v_z_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2427);
  return (g_co_2eop_24s40508559x1835373952(MK_INT(1LL), v_z_244, v_z_245));
}
V g_heff_2ebuild_2ecommands_2ecompileJsOut_24s462361791x320109327_24tok1_lam5(V self, V *args) {
  V v_x_2429 = args[0];
  V v_bad_242 = heff_env(self)[0];
  V v_errors_247 = heff_env(self)[1];
  V v_z_245 = heff_env(self)[2];
  V v_z_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2429);
  if (!(heff_dup(v_bad_242) == NTAG(TAG_True))) {
    heff_drop(v_bad_242);
    switch (heff_tag_of(v_errors_247)) {
    case TAG_Nil: {
      heff_drop(v_z_244);
      V f_ = v_z_245;
      args[0] = NTAG(TAG_MkUnit);
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    case TAG_Cons: {
      V v_ru_24errors_247_24Cons = heff_take_reuse_n(v_errors_247, 0ULL, 2);
      return (g_co_2eop_24s40508559x1835373952_24tok2(v_ru_24errors_247_24Cons, MK_INT(1LL), v_z_244, v_z_245));
    }
    default: return heff_nomatch(v_errors_247);
    }
  } else {
    heff_drop(v_bad_242);
    heff_drop(v_errors_247);
    return (g_co_2eop_24s40508559x1835373952(MK_INT(1LL), v_z_244, v_z_245));
  }
}
V g_heff_2ebuild_2ecommands_2ecompileJsOut_24s462361791x320109327_24tok1_lam3(V self, V *args) {
  V v_x_2425 = args[0];
  V v_errors_247 = heff_env(self)[0];
  V v_z_244 = heff_env(self)[1];
  V v_z_245 = heff_env(self)[2];
  V v_bad_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  switch (heff_tag_of(v_x_2425)) {
  case TAG_Left: {
    V v_ru_24x_2425_24Left = heff_take_reuse_n(v_x_2425, 0ULL, 1);
    heff_drop(v_bad_242);
    return (g_heff_2ebuild_2ecommands_2eemitErrs_24s394189364x2134712221_24tok1(v_ru_24x_2425_24Left, v_errors_247, heff_dup(v_z_244), heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileJsOut_24s462361791x320109327_24tok1_lam4, 1, 2, (V[]){v_z_244, v_z_245})));
  }
  case TAG_Right: {
    V v_ru_24x_2425_24Right = heff_take_reuse_n(v_x_2425, 0ULL, 1);
    return (g_heff_2ebuild_2ecommands_2eemitErrs_24s394189364x2134712221_24tok1(v_ru_24x_2425_24Right, heff_dup(v_errors_247), heff_dup(v_z_244), heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileJsOut_24s462361791x320109327_24tok1_lam5, 1, 4, (V[]){v_bad_242, v_errors_247, v_z_245, v_z_244})));
  }
  default: return heff_nomatch(v_x_2425);
  }
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eselfKept_24s1039208617x848590819_24tok1_str0, 8, "compiler");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eselfKept_24s1039208617x848590819_24tok1_str1, 1, "\012");
V g_heff_2ebuild_2ecommands_2eselfKept_24s1039208617x848590819_24tok1_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eselfKept_24s1039208617x848590819_24tok1_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eselfKept_24s1039208617x848590819_24tok1_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2eselfKept_24s1039208617x848590819_24tok1_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2eselfKept_24s1039208617x848590819_24tok1_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eselfKept_24s1039208617x848590819_24tok1_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eselfKept_24s1039208617x848590819_24tok1_lam1, 1, 0};
V g_heff_2ebuild_2ecommands_2eselfKept_24s1039208617x848590819_24tok1_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2eselfKept_24s1039208617x848590819_24tok1_lam3(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eselfKept_24s1039208617x848590819_24tok1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eselfKept_24s1039208617x848590819_24tok1_entry, 6, 0};

V g_heff_2ebuild_2ecommands_2eselfKept_24s1039208617x848590819_24tok1(V v_tok_240, V v_ps_241, V v_b_242, V v_id_243, V v_z_244, V v_z_245) {
top: ;
  V v_s_246 = (g_heff_2ebuild_2ecommands_2ebackDirOf(heff_dup(v_ps_241)));
  V v_path_247 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_s_246));
  V v_t_248 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_247; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_247); r_; });
  V v_a_2410 = heff_tag_n(TAG_MakeDirectory, 2, (V[]){v_t_248, ((V)&g_heff_2ebuild_2ecommands_2eselfKept_24s1039208617x848590819_24tok1_lam0_clo)});
  V v_t_2411 = heff_tag_at_n(v_tok_240, TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2410})});
  V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
  V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
  V v_t_2415 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
  V v_t_2416 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2415})});
  V v_c_2423 = heff_tr(g_co_2eop_24s1398690846x1918384825(heff_tag_n(TAG_InR, 1, (V[]){v_t_2416}), heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), ((V)&g_heff_2ebuild_2ecommands_2eselfKept_24s1039208617x848590819_24tok1_lam1_clo)));
  return heff_tail(v_c_2423, 2, (V[]){heff_dup(v_z_244), heff_clo_n(g_heff_2ebuild_2ecommands_2eselfKept_24s1039208617x848590819_24tok1_lam3, 1, 5, (V[]){v_ps_241, v_id_243, v_b_242, v_z_244, v_z_245})});
}
V g_heff_2ebuild_2ecommands_2eselfKept_24s1039208617x848590819_24tok1_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eselfKept_24s1039208617x848590819_24tok1(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2ebuild_2ecommands_2eselfKept_24s1039208617x848590819_24tok1_lam0(V self, V *args) {
  V v_r_249 = args[0];
  return v_r_249;
}
V g_heff_2ebuild_2ecommands_2eselfKept_24s1039208617x848590819_24tok1_lam2(V self, V *args) {
  V v_hd_2421 = args[0];
  V v_k_2422 = args[1];
  V v_x_2420 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2421);
  V f_ = v_k_2422;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2420});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eselfKept_24s1039208617x848590819_24tok1_lam1(V self, V *args) {
  V v_x_2417 = args[0];
  switch (heff_tag_of(v_x_2417)) {
  case TAG_Left: {
    V v_err_2418 = heff_field(v_x_2417, 0);
    V v_ru_24x_2417_24Left = heff_take_reuse_n(v_x_2417, 1ULL, 1);
    V v_t_2419 = heff_tag_at_n(v_ru_24x_2417_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_err_2418})});
    return (g_co_2eop_24s1998166633x1971890408(v_t_2419));
  }
  case TAG_Right: {
    V v_x_2420 = heff_field(v_x_2417, 0);
    heff_take_n(v_x_2417, 1ULL, 1);
    return heff_clo_n(g_heff_2ebuild_2ecommands_2eselfKept_24s1039208617x848590819_24tok1_lam2, 2, 1, (V[]){v_x_2420});
  }
  default: return heff_nomatch(v_x_2417);
  }
}
V g_heff_2ebuild_2ecommands_2eselfKept_24s1039208617x848590819_24tok1_lam4(V self, V *args) {
  V v_x_2433 = args[0];
  V v_z_245 = heff_env(self)[0];
  V v_id_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2433);
  V f_ = v_z_245;
  args[0] = v_id_243;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eselfKept_24s1039208617x848590819_24tok1_lam3(V self, V *args) {
  V v_x_2424 = args[0];
  V v_ps_241 = heff_env(self)[0];
  V v_id_243 = heff_env(self)[1];
  V v_b_242 = heff_env(self)[2];
  V v_z_244 = heff_env(self)[3];
  V v_z_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2424);
  V v_d_2425 = (g_heff_2ebuild_2ecommands_2ebackDirOf(heff_dup(v_ps_241)));
  V v_st_2426 = heff_get_n(v_ps_241, 5, 6);
  V v_t_2427 = (g_std_2epath_2eparse(heff_dup(v_st_2426), v_d_2425));
  V v_t_2428 = (g_std_2epath_2eparse(heff_dup(v_st_2426), ((V)&g_heff_2ebuild_2ecommands_2eselfKept_24s1039208617x848590819_24tok1_str0)));
  V v_t_2429 = (g_std_2epath_2ejoin(v_t_2427, v_t_2428));
  V v_t_2430 = ({ V a_0 = v_st_2426; V a_1 = v_t_2429; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2426); heff_drop(v_t_2429); r_; });
  V v_t_2431 = heff_strAppend(heff_strAppend(heff_dup(v_id_243), ((V)&g_heff_2ebuild_2ecommands_2eselfKept_24s1039208617x848590819_24tok1_str1)), v_b_242);
  V v_c_2432 = (g_heff_2ebuild_2ecommands_2ewriteWhole_24s886536390x2068229138(v_t_2430, v_t_2431));
  V f_ = v_c_2432;
  heff_room[0] = v_z_244;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2eselfKept_24s1039208617x848590819_24tok1_lam4, 1, 2, (V[]){v_z_245, v_id_243});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}