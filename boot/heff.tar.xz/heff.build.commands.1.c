// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_End 17255
#define TAG_Exit 20279
#define TAG_GetEnv 43934
#define TAG_Left 13886
#define TAG_MkPath 49630
#define TAG_Platform 55558
#define TAG_Posix 44191
#define TAG_ProgramPath 46819
#define TAG_Right 62770
#define TAG_Start 63542
#define TAG_Windows 49101
#define TAG_WorkingDir 28879
#define TAG_Write 36323
#define TAG_WriteErr 37283
#define LBL_apps 9496377
#define LBL_at 9882
#define LBL_backend 2032133329
#define LBL_bad 306815
#define LBL_bin 307073
#define LBL_c 317
#define LBL_cmt 308164
#define LBL_copies 592412158
#define LBL_done 9584713
#define LBL_emits 297985818
#define LBL_err 310239
#define LBL_errors 652506774
#define LBL_first 298798794
#define LBL_globals 352931696
#define LBL_groups 709681407
#define LBL_i 323
#define LBL_jss 315076
#define LBL_key 315609
#define LBL_library 398066429
#define LBL_line 9817275
#define LBL_lineStart 1964790630
#define LBL_mods 9852536
#define LBL_module 878357911
#define LBL_modules 1459291593
#define LBL_msg 317947
#define LBL_name 9869138
#define LBL_olds 9909235
#define LBL_opt 319789
#define LBL_outPath 1272254166
#define LBL_pages 307784670
#define LBL_parts 307795706
#define LBL_paths 307797256
#define LBL_root 10001833
#define LBL_said 10017968
#define LBL_shipTo 1043811586
#define LBL_ships 310766033
#define LBL_source 1050636102
#define LBL_start 311115900
#define LBL_style 311138763
#define LBL_tok 324554
#define LBL_top 324559
#define LBL_ty 10476
#define LBL_zig 330130
static uint32_t shape_apps__bad[] = {LBL_apps, LBL_bad};
static uint32_t shape_at__msg[] = {LBL_at, LBL_msg};
static uint32_t shape_c__zig[] = {LBL_c, LBL_zig};
static uint32_t shape_groups__copies__emits__jss[] = {LBL_groups, LBL_copies, LBL_emits, LBL_jss};
static uint32_t shape_i__line__lineStart__first__tok__err__cmt[] = {LBL_i, LBL_line, LBL_lineStart, LBL_first, LBL_tok, LBL_err, LBL_cmt};
static uint32_t shape_mods__olds[] = {LBL_mods, LBL_olds};
static uint32_t shape_root__bin__said__pages__shipTo__opt[] = {LBL_root, LBL_bin, LBL_said, LBL_pages, LBL_shipTo, LBL_opt};
V g_co_2eop_24s310169282x2049378029(V, V, V, V);
V g_co_2eop_24s310169282x2049378029_entry(V self, V *a);
extern Clo g_co_2eop_24s310169282x2049378029_clo;
V g_exception_2eattempted(V);
V g_exception_2eattempted_entry(V self, V *a);
extern Clo g_exception_2eattempted_clo;
V g_heff_2ebuild_2ebackcache_2ebackDir_get(void);
V g_heff_2ebuild_2ebackcache_2ebackTexts(V, V, V);
V g_heff_2ebuild_2ebackcache_2ebackTexts_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebackcache_2ebackTexts_clo;
V g_heff_2ebuild_2ecommands_2eappFile(V, V, V, V);
V g_heff_2ebuild_2ecommands_2eappFile_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eappFile_clo;
V g_heff_2ebuild_2ecommands_2eappRead_24s1547571770x1565867076(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eappRead_24s1547571770x1565867076_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eappRead_24s1547571770x1565867076_clo;
V g_heff_2ebuild_2ecommands_2eappShips_24s332790385x308708530(V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eappShips_24s332790385x308708530_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eappShips_24s332790385x308708530_clo;
V g_heff_2ebuild_2ecommands_2ebackDirOf(V);
V g_heff_2ebuild_2ecommands_2ebackDirOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ebackDirOf_clo;
V g_heff_2ebuild_2ecommands_2ebacksOf(V, V);
V g_heff_2ebuild_2ecommands_2ebacksOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ebacksOf_clo;
V g_heff_2ebuild_2ecommands_2ebuildTarget(V, V);
V g_heff_2ebuild_2ecommands_2ebuildTarget_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ebuildTarget_clo;
V g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1870015767x1734489010(V, V, V, V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1870015767x1734489010_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1870015767x1734489010_clo;
V g_heff_2ebuild_2ecommands_2ecompileJsOut_24s2121337324x1959907762(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecompileJsOut_24s2121337324x1959907762_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecompileJsOut_24s2121337324x1959907762_clo;
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s661001863x1156540388(V, V, V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s661001863x1156540388_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecompileLastC_24s661001863x1156540388_clo;
V g_heff_2ebuild_2ecommands_2ecwdNow_24s668555420x1041141502(V, V, V);
V g_heff_2ebuild_2ecommands_2ecwdNow_24s668555420x1041141502_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecwdNow_24s668555420x1041141502_clo;
V g_heff_2ebuild_2ecommands_2eemitErrs_24s1206086771x983818389(V, V, V, V);
V g_heff_2ebuild_2ecommands_2eemitErrs_24s1206086771x983818389_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eemitErrs_24s1206086771x983818389_clo;
V g_heff_2ebuild_2ecommands_2eimportsOn(V);
V g_heff_2ebuild_2ecommands_2eimportsOn_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eimportsOn_clo;
V g_heff_2ebuild_2ecommands_2eimportsOn_24acc(V, V);
V g_heff_2ebuild_2ecommands_2eimportsOn_24acc_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eimportsOn_24acc_clo;
V g_heff_2ebuild_2ecommands_2ekeptParts_24s901611701x2116226688(V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ekeptParts_24s901611701x2116226688_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ekeptParts_24s901611701x2116226688_clo;
V g_heff_2ebuild_2ecommands_2ekeptWith_24s2006126946x578363648(V, V, V, V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ekeptWith_24s2006126946x578363648_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ekeptWith_24s2006126946x578363648_clo;
V g_heff_2ebuild_2ecommands_2ekeptWritten_24s35934590x313560989(V, V, V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ekeptWritten_24s35934590x313560989_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ekeptWritten_24s35934590x313560989_clo;
V g_heff_2ebuild_2ecommands_2eload_24s2043842606x1315457906(V, V, V, V);
V g_heff_2ebuild_2ecommands_2eload_24s2043842606x1315457906_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eload_24s2043842606x1315457906_clo;
V g_heff_2ebuild_2ecommands_2emissingOutDir_24s401416675x2114298136(V, V, V, V);
V g_heff_2ebuild_2ecommands_2emissingOutDir_24s401416675x2114298136_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2emissingOutDir_24s401416675x2114298136_clo;
V g_heff_2ebuild_2ecommands_2enotInProject_24s1239925928x1402397320(V, V, V, V);
V g_heff_2ebuild_2ecommands_2enotInProject_24s1239925928x1402397320_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2enotInProject_24s1239925928x1402397320_clo;
V g_heff_2ebuild_2ecommands_2enubStrGo(V, V);
V g_heff_2ebuild_2ecommands_2enubStrGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2enubStrGo_clo;
V g_heff_2ebuild_2ecommands_2eonPathHint_24s1119738011x382523600(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eonPathHint_24s1119738011x382523600_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eonPathHint_24s1119738011x382523600_clo;
V g_heff_2ebuild_2ecommands_2eownRoot(V, V);
V g_heff_2ebuild_2ecommands_2eownRoot_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eownRoot_clo;
V g_heff_2ebuild_2ecommands_2eprintErrs_24s1758719709x679644559(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eprintErrs_24s1758719709x679644559_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprintErrs_24s1758719709x679644559_clo;
V g_heff_2ebuild_2ecommands_2eprintLines_24s438298383x569258715(V, V, V, V);
V g_heff_2ebuild_2ecommands_2eprintLines_24s438298383x569258715_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprintLines_24s438298383x569258715_clo;
V g_heff_2ebuild_2ecommands_2eprovidesLeafC(V, V);
V g_heff_2ebuild_2ecommands_2eprovidesLeafC_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprovidesLeafC_clo;
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s1666732804x1501633074(V, V, V, V);
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s1666732804x1501633074_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eputFileDiags_24s1666732804x1501633074_clo;
V g_heff_2ebuild_2ecommands_2ereadBacks_24s960701544x1414957442(V, V, V);
V g_heff_2ebuild_2ecommands_2ereadBacks_24s960701544x1414957442_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ereadBacks_24s960701544x1414957442_clo;
V g_heff_2ebuild_2ecommands_2ereadProvidersC_24s1323278373x1718996742(V, V, V);
V g_heff_2ebuild_2ecommands_2ereadProvidersC_24s1323278373x1718996742_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ereadProvidersC_24s1323278373x1718996742_clo;
V g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s628326673x1969472940(V, V, V, V);
V g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s628326673x1969472940_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s628326673x1969472940_clo;
V g_heff_2ebuild_2ecommands_2erunDir(V, V);
V g_heff_2ebuild_2ecommands_2erunDir_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2erunDir_clo;
V g_heff_2ebuild_2ecommands_2eselfHash_24s1263115327x65083815(V, V, V, V);
V g_heff_2ebuild_2ecommands_2eselfHash_24s1263115327x65083815_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eselfHash_24s1263115327x65083815_clo;
V g_heff_2ebuild_2ecommands_2eselfPath_24s1217305498x1892484309(V, V, V);
V g_heff_2ebuild_2ecommands_2eselfPath_24s1217305498x1892484309_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eselfPath_24s1217305498x1892484309_clo;
V g_heff_2ebuild_2ecommands_2eshipAll_24s1743475427x165111673(V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eshipAll_24s1743475427x165111673_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eshipAll_24s1743475427x165111673_clo;
V g_heff_2ebuild_2ecommands_2eshipIn_24s811788384x1289483489(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eshipIn_24s811788384x1289483489_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eshipIn_24s811788384x1289483489_clo;
V g_heff_2ebuild_2ecommands_2esystemOnly_24s1898595125x1760051853(V, V, V);
V g_heff_2ebuild_2ecommands_2esystemOnly_24s1898595125x1760051853_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2esystemOnly_24s1898595125x1760051853_clo;
V g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s1022594378x1370601054(V, V, V);
V g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s1022594378x1370601054_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s1022594378x1370601054_clo;
V g_heff_2ebuild_2ecommands_2etypeAtCmd_24s661188703x1448631645(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2etypeAtCmd_24s661188703x1448631645_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2etypeAtCmd_24s661188703x1448631645_clo;
V g_heff_2ebuild_2ecommands_2ewriteBacks_24s896479057x1627394630(V, V, V, V);
V g_heff_2ebuild_2ecommands_2ewriteBacks_24s896479057x1627394630_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ewriteBacks_24s896479057x1627394630_clo;
V g_heff_2ebuild_2ecommands_2ewriteOut_24s639639504x191707652(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ewriteOut_24s639639504x191707652_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ewriteOut_24s639639504x191707652_clo;
V g_heff_2ebuild_2ecommands_2ewriteOutC_24s196946078x469800039(V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ewriteOutC_24s196946078x469800039_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ewriteOutC_24s196946078x469800039_clo;
V g_heff_2ebuild_2ecommands_2ewriteParts_24s610674570x1742983909(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ewriteParts_24s610674570x1742983909_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ewriteParts_24s610674570x1742983909_clo;
V g_heff_2ebuild_2ecommands_2ewriteWhole_24s1510611923x1957311911(V, V, V);
V g_heff_2ebuild_2ecommands_2ewriteWhole_24s1510611923x1957311911_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ewriteWhole_24s1510611923x1957311911_clo;
V g_heff_2ebuild_2edriver_2ecandLeaves(V);
V g_heff_2ebuild_2edriver_2ecandLeaves_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ecandLeaves_clo;
V g_heff_2ebuild_2edriver_2ecandidatesOf(V);
V g_heff_2ebuild_2edriver_2ecandidatesOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ecandidatesOf_clo;
HeffT2 g_heff_2ebuild_2edriver_2elastChecked_24cpr(V);
V g_heff_2ebuild_2edriver_2enubStrD(V);
V g_heff_2ebuild_2edriver_2enubStrD_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2enubStrD_clo;
V g_heff_2ebuild_2eload_2eproblemMsg(V, V, V);
V g_heff_2ebuild_2eload_2eproblemMsg_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eproblemMsg_clo;
V g_heff_2ebuild_2eproject_2ebuildOf(V);
V g_heff_2ebuild_2eproject_2ebuildOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2ebuildOf_clo;
HeffT2 g_heff_2ebuild_2eproject_2edeclsGo_24cpr(V, V, V, V, V);
HeffT2 g_heff_2ebuild_2equery_2einfoAt_24cpr(V, V);
V g_heff_2ebuild_2esession_2ecachedAcc_24s1465745022x907203497(V, V);
V g_heff_2ebuild_2esession_2ecachedAcc_24s1465745022x907203497_entry(V self, V *a);
extern Clo g_heff_2ebuild_2esession_2ecachedAcc_24s1465745022x907203497_clo;
HeffT2 g_heff_2ecompile_2eglue_2eeithers_24cpr(V);
V g_heff_2ecompile_2eglue_2ejusts(V);
V g_heff_2ecompile_2eglue_2ejusts_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eglue_2ejusts_clo;
HeffT3 g_heff_2esyntax_2efmt_2elex_2elexGo_24cpr(V, V, V, V, V);
V g_heff_2esyntax_2esurfaceprint_2enamed(V);
V g_heff_2esyntax_2esurfaceprint_2enamed_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2enamed_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2edrop(V, V);
V g_list_2edrop_entry(V self, V *a);
extern Clo g_list_2edrop_clo;
V g_list_2efoldl_24f1425140065x1254143828(V, V, V, V);
V g_list_2efoldl_24f1425140065x1254143828_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1425140065x1254143828_clo;
V g_list_2efoldl_24s1325969685x576913065(V, V);
V g_list_2efoldl_24s1325969685x576913065_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1325969685x576913065_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1614667250x430274379(V, V);
V g_list_2efoldl_24s1614667250x430274379_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1614667250x430274379_clo;
V g_list_2efoldl_24s680990791x1764841948(V, V, V, V, V, V, V);
V g_list_2efoldl_24s680990791x1764841948_entry(V self, V *a);
extern Clo g_list_2efoldl_24s680990791x1764841948_clo;
V g_list_2efoldl_24s744304057x1932700078(V, V);
V g_list_2efoldl_24s744304057x1932700078_entry(V self, V *a);
extern Clo g_list_2efoldl_24s744304057x1932700078_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1435185561x202019164(V);
V g_list_2emap_24s1435185561x202019164_entry(V self, V *a);
extern Clo g_list_2emap_24s1435185561x202019164_clo;
V g_list_2emap_24s164225955x66209884(V, V, V);
V g_list_2emap_24s164225955x66209884_entry(V self, V *a);
extern Clo g_list_2emap_24s164225955x66209884_clo;
V g_list_2emap_24s219049803x1458391381(V);
V g_list_2emap_24s219049803x1458391381_entry(V self, V *a);
extern Clo g_list_2emap_24s219049803x1458391381_clo;
V g_list_2emap_24s89148281x951607804(V, V, V, V, V, V, V);
V g_list_2emap_24s89148281x951607804_entry(V self, V *a);
extern Clo g_list_2emap_24s89148281x951607804_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
HeffT2 g_prelude_2eparseInt_24cpr(V);
V g_prelude_2esplit_2esplitFrom_240(V, V, V, V, V);
V g_prelude_2esplit_2esplitFrom_240_entry(V self, V *a);
extern Clo g_prelude_2esplit_2esplitFrom_240_clo;
V g_std_2efilesystem_2emakeDirectory_24s718897684x895598918(V, V);
V g_std_2efilesystem_2emakeDirectory_24s718897684x895598918_entry(V self, V *a);
extern Clo g_std_2efilesystem_2emakeDirectory_24s718897684x895598918_clo;
V g_std_2efilesystem_2ereadDirectory_24s1485822734x1304823189(V, V);
V g_std_2efilesystem_2ereadDirectory_24s1485822734x1304823189_entry(V self, V *a);
extern Clo g_std_2efilesystem_2ereadDirectory_24s1485822734x1304823189_clo;
V g_std_2efilesystem_2ereplace_24s1810255102x220553654(V, V, V);
V g_std_2efilesystem_2ereplace_24s1810255102x220553654_entry(V self, V *a);
extern Clo g_std_2efilesystem_2ereplace_24s1810255102x220553654_clo;
V g_std_2efilesystem_2ewriteFile_24s1279893433x291681682(V, V, V);
V g_std_2efilesystem_2ewriteFile_24s1279893433x291681682_entry(V self, V *a);
extern Clo g_std_2efilesystem_2ewriteFile_24s1279893433x291681682_clo;
V g_std_2eordmap_2eempty_get(void);
V g_std_2eordmap_2einsert_24s615484302x989744458(V, V, V);
V g_std_2eordmap_2einsert_24s615484302x989744458_entry(V self, V *a);
extern Clo g_std_2eordmap_2einsert_24s615484302x989744458_clo;
V g_std_2epath_2ejoin(V, V);
V g_std_2epath_2ejoin_entry(V self, V *a);
extern Clo g_std_2epath_2ejoin_clo;
V g_std_2epath_2enative_get(void);
V g_std_2epath_2eparse(V, V);
V g_std_2epath_2eparse_entry(V self, V *a);
extern Clo g_std_2epath_2eparse_clo;
HeffT3 g_std_2epath_2eparse_24cpr(V, V);
V g_std_2epath_2erender(V, V);
V g_std_2epath_2erender_entry(V self, V *a);
extern Clo g_std_2epath_2erender_clo;
V g_std_2eprogress_2eroot_get(void);
HEFF_LIT(g_heff_2ebuild_2ecommands_2eownRoot_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eownRoot_str1, 3, "out");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eownRoot_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eownRoot_str3, 5, ".heff");
Clo g_heff_2ebuild_2ecommands_2eownRoot_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eownRoot_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2eownRoot(V v_st_240, V v_self_241) {
top: ;
  HeffT3 v_t_242 = (g_std_2epath_2eparse_24cpr(heff_dup(v_st_240), heff_dup(v_self_241)));
  V v_t_2412;
  {
    V v_field_243 = v_t_242.f[0];
    V v_field_244 = v_t_242.f[1];
    V v_field_245 = v_t_242.f[2];
    V v_d_246 = v_field_243;
    V v_a_247 = v_field_244;
    V v_xs_248 = v_field_245;
    V v_t_249 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_248));
    V v_xs_2410 = ({ V a_0 = MK_INT(1LL); V a_1 = v_t_249; V r_ = (g_list_2edrop(a_0, a_1)); heff_drop(v_t_249); r_; });
    V v_t_2411 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2410));
    v_t_2412 = heff_tag_n(TAG_MkPath, 3, (V[]){v_d_246, v_a_247, v_t_2411});
  }
  V v_s_2413 = ({ V a_0 = v_st_240; V a_1 = v_t_2412; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2412); r_; });
  HeffT3 v_t_2414 = (g_std_2epath_2eparse_24cpr(heff_dup(v_st_240), v_s_2413));
  V v_t_2424;
  {
    V v_field_2415 = v_t_2414.f[0];
    V v_field_2416 = v_t_2414.f[1];
    V v_field_2417 = v_t_2414.f[2];
    V v_x11_2418 = v_field_2415;
    heff_drop(v_x11_2418);
    V v_x12_2419 = v_field_2416;
    heff_drop(v_x12_2419);
    V v_xs_2420 = v_field_2417;
    V v_x1_2421 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2420));
    switch (heff_tag_of(v_x1_2421)) {
    case TAG_Nil: {
      v_t_2424 = ((V)&g_heff_2ebuild_2ecommands_2eownRoot_str0);
      break;
    }
    case TAG_Cons: {
      V v_x_2422 = heff_field(v_x1_2421, 0);
      heff_take_n(v_x1_2421, 1ULL, 2);
      v_t_2424 = v_x_2422;
      break;
    }
    default: heff_nomatch(v_x1_2421);
    }
  }
  V v_t_24118;
  if (heff_strEq_c(v_t_2424, ((V)&g_heff_2ebuild_2ecommands_2eownRoot_str1))) {
    HeffT3 v_t_2425 = (g_std_2epath_2eparse_24cpr(heff_dup(v_st_240), heff_dup(v_self_241)));
    V v_t_2435;
    {
      V v_field_2426 = v_t_2425.f[0];
      V v_field_2427 = v_t_2425.f[1];
      V v_field_2428 = v_t_2425.f[2];
      V v_d_2429 = v_field_2426;
      V v_a_2430 = v_field_2427;
      V v_xs_2431 = v_field_2428;
      V v_t_2432 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2431));
      V v_xs_2433 = ({ V a_0 = MK_INT(1LL); V a_1 = v_t_2432; V r_ = (g_list_2edrop(a_0, a_1)); heff_drop(v_t_2432); r_; });
      V v_t_2434 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2433));
      v_t_2435 = heff_tag_n(TAG_MkPath, 3, (V[]){v_d_2429, v_a_2430, v_t_2434});
    }
    V v_s_2436 = ({ V a_0 = v_st_240; V a_1 = v_t_2435; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2435); r_; });
    HeffT3 v_t_2437 = (g_std_2epath_2eparse_24cpr(heff_dup(v_st_240), v_s_2436));
    V v_t_2447;
    {
      V v_field_2438 = v_t_2437.f[0];
      V v_field_2439 = v_t_2437.f[1];
      V v_field_2440 = v_t_2437.f[2];
      V v_d_2441 = v_field_2438;
      V v_a_2442 = v_field_2439;
      V v_xs_2443 = v_field_2440;
      V v_t_2444 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2443));
      V v_xs_2445 = ({ V a_0 = MK_INT(1LL); V a_1 = v_t_2444; V r_ = (g_list_2edrop(a_0, a_1)); heff_drop(v_t_2444); r_; });
      V v_t_2446 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2445));
      v_t_2447 = heff_tag_n(TAG_MkPath, 3, (V[]){v_d_2441, v_a_2442, v_t_2446});
    }
    V v_s_2448 = ({ V a_0 = v_st_240; V a_1 = v_t_2447; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2447); r_; });
    HeffT3 v_t_2449 = (g_std_2epath_2eparse_24cpr(heff_dup(v_st_240), v_s_2448));
    V v_t_24121;
    {
      V v_field_2450 = v_t_2449.f[0];
      V v_field_2451 = v_t_2449.f[1];
      V v_field_2452 = v_t_2449.f[2];
      V v_x11_2453 = v_field_2450;
      heff_drop(v_x11_2453);
      V v_x12_2454 = v_field_2451;
      heff_drop(v_x12_2454);
      V v_xs_2455 = v_field_2452;
      V v_x1_2456 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2455));
      switch (heff_tag_of(v_x1_2456)) {
      case TAG_Nil: {
        v_t_24121 = ((V)&g_heff_2ebuild_2ecommands_2eownRoot_str2);
        break;
      }
      case TAG_Cons: {
        V v_x_2457 = heff_field(v_x1_2456, 0);
        heff_take_n(v_x1_2456, 1ULL, 2);
        v_t_24121 = v_x_2457;
        break;
      }
      default: heff_nomatch(v_x1_2456);
      }
    }
    v_t_24118 = heff_strEq(v_t_24121, ((V)&g_heff_2ebuild_2ecommands_2eownRoot_str3));
  } else {
    v_t_24118 = NTAG(TAG_False);
  }
  switch (heff_tag_of(v_t_24118)) {
  case TAG_True: {
    HeffT3 v_t_2459 = (g_std_2epath_2eparse_24cpr(heff_dup(v_st_240), v_self_241));
    V v_t_2469;
    {
      V v_field_2460 = v_t_2459.f[0];
      V v_field_2461 = v_t_2459.f[1];
      V v_field_2462 = v_t_2459.f[2];
      V v_d_2463 = v_field_2460;
      V v_a_2464 = v_field_2461;
      V v_xs_2465 = v_field_2462;
      V v_t_2466 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2465));
      V v_xs_2467 = ({ V a_0 = MK_INT(1LL); V a_1 = v_t_2466; V r_ = (g_list_2edrop(a_0, a_1)); heff_drop(v_t_2466); r_; });
      V v_t_2468 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2467));
      v_t_2469 = heff_tag_n(TAG_MkPath, 3, (V[]){v_d_2463, v_a_2464, v_t_2468});
    }
    V v_s_2470 = ({ V a_0 = v_st_240; V a_1 = v_t_2469; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2469); r_; });
    HeffT3 v_t_2471 = (g_std_2epath_2eparse_24cpr(heff_dup(v_st_240), v_s_2470));
    V v_t_2481;
    {
      V v_field_2472 = v_t_2471.f[0];
      V v_field_2473 = v_t_2471.f[1];
      V v_field_2474 = v_t_2471.f[2];
      V v_d_2475 = v_field_2472;
      V v_a_2476 = v_field_2473;
      V v_xs_2477 = v_field_2474;
      V v_t_2478 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2477));
      V v_xs_2479 = ({ V a_0 = MK_INT(1LL); V a_1 = v_t_2478; V r_ = (g_list_2edrop(a_0, a_1)); heff_drop(v_t_2478); r_; });
      V v_t_2480 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2479));
      v_t_2481 = heff_tag_n(TAG_MkPath, 3, (V[]){v_d_2475, v_a_2476, v_t_2480});
    }
    V v_s_2482 = ({ V a_0 = v_st_240; V a_1 = v_t_2481; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2481); r_; });
    HeffT3 v_t_2483 = (g_std_2epath_2eparse_24cpr(heff_dup(v_st_240), v_s_2482));
    V v_t_2493;
    {
      V v_field_2484 = v_t_2483.f[0];
      V v_field_2485 = v_t_2483.f[1];
      V v_field_2486 = v_t_2483.f[2];
      V v_d_2487 = v_field_2484;
      V v_a_2488 = v_field_2485;
      V v_xs_2489 = v_field_2486;
      V v_t_2490 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2489));
      V v_xs_2491 = ({ V a_0 = MK_INT(1LL); V a_1 = v_t_2490; V r_ = (g_list_2edrop(a_0, a_1)); heff_drop(v_t_2490); r_; });
      V v_t_2492 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2491));
      v_t_2493 = heff_tag_n(TAG_MkPath, 3, (V[]){v_d_2487, v_a_2488, v_t_2492});
    }
    return ({ V a_0 = v_st_240; V a_1 = v_t_2493; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_240); heff_drop(v_t_2493); r_; });
  }
  case TAG_False: {
    HeffT3 v_t_2494 = (g_std_2epath_2eparse_24cpr(heff_dup(v_st_240), v_self_241));
    V v_t_24104;
    {
      V v_field_2495 = v_t_2494.f[0];
      V v_field_2496 = v_t_2494.f[1];
      V v_field_2497 = v_t_2494.f[2];
      V v_d_2498 = v_field_2495;
      V v_a_2499 = v_field_2496;
      V v_xs_24100 = v_field_2497;
      V v_t_24101 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_24100));
      V v_xs_24102 = ({ V a_0 = MK_INT(1LL); V a_1 = v_t_24101; V r_ = (g_list_2edrop(a_0, a_1)); heff_drop(v_t_24101); r_; });
      V v_t_24103 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_24102));
      v_t_24104 = heff_tag_n(TAG_MkPath, 3, (V[]){v_d_2498, v_a_2499, v_t_24103});
    }
    V v_s_24105 = ({ V a_0 = v_st_240; V a_1 = v_t_24104; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_24104); r_; });
    HeffT3 v_t_24106 = (g_std_2epath_2eparse_24cpr(heff_dup(v_st_240), v_s_24105));
    V v_t_24116;
    {
      V v_field_24107 = v_t_24106.f[0];
      V v_field_24108 = v_t_24106.f[1];
      V v_field_24109 = v_t_24106.f[2];
      V v_d_24110 = v_field_24107;
      V v_a_24111 = v_field_24108;
      V v_xs_24112 = v_field_24109;
      V v_t_24113 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_24112));
      V v_xs_24114 = ({ V a_0 = MK_INT(1LL); V a_1 = v_t_24113; V r_ = (g_list_2edrop(a_0, a_1)); heff_drop(v_t_24113); r_; });
      V v_t_24115 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_24114));
      v_t_24116 = heff_tag_n(TAG_MkPath, 3, (V[]){v_d_24110, v_a_24111, v_t_24115});
    }
    return ({ V a_0 = v_st_240; V a_1 = v_t_24116; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_240); heff_drop(v_t_24116); r_; });
  }
  default: return heff_nomatch(v_t_24118);
  }
}
V g_heff_2ebuild_2ecommands_2eownRoot_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eownRoot(a[0], a[1]);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eimportsOn_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eimportsOn_str1, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eimportsOn_str2, 10, "imports it");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eimportsOn_str3, 9, "imports `");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eimportsOn_str4, 9, "`, which ");
Clo g_heff_2ebuild_2ecommands_2eimportsOn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eimportsOn_entry, 1, 0};

V g_heff_2ebuild_2ecommands_2eimportsOn(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return ((V)&g_heff_2ebuild_2ecommands_2eimportsOn_str0);
  }
  case TAG_Cons: {
    V v_x12_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 2ULL, 2);
    switch (heff_tag_of(v_x12_242)) {
    case TAG_Nil: {
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      return ((V)&g_heff_2ebuild_2ecommands_2eimportsOn_str1);
    }
    case TAG_Cons: {
      V v_b_243 = heff_field(v_x12_242, 0);
      V v_x122_244 = heff_field(v_x12_242, 1);
      heff_take_n(v_x12_242, 3ULL, 2);
      switch (heff_tag_of(v_x122_244)) {
      case TAG_Nil: {
        heff_drop_cell(v_ru_24x1_240_24Cons, 2);
        heff_drop(v_b_243);
        return ((V)&g_heff_2ebuild_2ecommands_2eimportsOn_str2);
      }
      case TAG_Cons: {
        V v_s_247 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eimportsOn_str3), heff_dup(v_b_243)), ((V)&g_heff_2ebuild_2ecommands_2eimportsOn_str4));
        return (g_heff_2ebuild_2ecommands_2eimportsOn_24acc(heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_b_243, v_x122_244}), v_s_247));
      }
      default: return heff_nomatch(v_x122_244);
      }
    }
    default: return heff_nomatch(v_x12_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2ecommands_2eimportsOn_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eimportsOn(a[0]);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebackDirOf_str0, 5, ".heff");
Clo g_heff_2ebuild_2ecommands_2ebackDirOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebackDirOf_entry, 1, 0};

V g_heff_2ebuild_2ecommands_2ebackDirOf(V v_ps_240) {
top: ;
  V v_style_241 = heff_take_field(v_ps_240, 5);
  V v_root_242 = heff_get_n(v_ps_240, 0, 6);
  V v_st_243 = heff_dup(v_style_241);
  V v_t_244 = (g_std_2epath_2eparse(heff_dup(v_st_243), v_root_242));
  V v_t_245 = (g_std_2epath_2eparse(heff_dup(v_st_243), ((V)&g_heff_2ebuild_2ecommands_2ebackDirOf_str0)));
  V v_t_246 = (g_std_2epath_2ejoin(v_t_244, v_t_245));
  V v_d_247 = ({ V a_0 = v_st_243; V a_1 = v_t_246; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_243); heff_drop(v_t_246); r_; });
  V v_st_248 = v_style_241;
  V v_t_249 = (g_std_2epath_2eparse(heff_dup(v_st_248), v_d_247));
  V v_t_2410 = (g_std_2epath_2eparse(heff_dup(v_st_248), heff_dup(g_heff_2ebuild_2ebackcache_2ebackDir_get())));
  V v_t_2411 = (g_std_2epath_2ejoin(v_t_249, v_t_2410));
  return ({ V a_0 = v_st_248; V a_1 = v_t_2411; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_248); heff_drop(v_t_2411); r_; });
}
V g_heff_2ebuild_2ecommands_2ebackDirOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ebackDirOf(a[0]);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildTarget_str0, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildTarget_str1, 3, "bin");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildTarget_str2, 5, "wrote");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildTarget_str3, 3, "-O1");
Clo g_heff_2ebuild_2ecommands_2ebuildTarget_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildTarget_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2ebuildTarget(V v_st_240, V v_root_241) {
top: ;
  V v_t_242 = (g_std_2epath_2eparse(heff_dup(v_st_240), ((V)&g_heff_2ebuild_2ecommands_2ebuildTarget_str0)));
  V v_t_243 = (g_std_2epath_2eparse(heff_dup(v_st_240), ((V)&g_heff_2ebuild_2ecommands_2ebuildTarget_str1)));
  V v_t_244 = (g_std_2epath_2ejoin(v_t_242, v_t_243));
  V v_b_245 = ({ V a_0 = v_st_240; V a_1 = v_t_244; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_244); r_; });
  V v_t_246 = (g_std_2epath_2eparse(heff_dup(v_st_240), heff_dup(v_root_241)));
  V v_t_247 = (g_std_2epath_2eparse(heff_dup(v_st_240), v_b_245));
  V v_t_248 = (g_std_2epath_2ejoin(v_t_246, v_t_247));
  V v_t_249 = ({ V a_0 = v_st_240; V a_1 = v_t_248; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_240); heff_drop(v_t_248); r_; });
  return heff_rec_n(6, shape_root__bin__said__pages__shipTo__opt, (V[]){v_root_241, v_t_249, ((V)&g_heff_2ebuild_2ecommands_2ebuildTarget_str2), NTAG(TAG_True), NTAG(TAG_Nothing), ((V)&g_heff_2ebuild_2ecommands_2ebuildTarget_str3)});
}
V g_heff_2ebuild_2ecommands_2ebuildTarget_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ebuildTarget(a[0], a[1]);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eappFile_str0, 3, "app");
Clo g_heff_2ebuild_2ecommands_2eappFile_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eappFile_entry, 4, 0};

V g_heff_2ebuild_2ecommands_2eappFile(V v_st_240, V v_t_241, V v_x_242, V v_f_243) {
top: ;
  V v_t_244 = (g_std_2epath_2eparse(heff_dup(v_st_240), ((V)&g_heff_2ebuild_2ecommands_2eappFile_str0)));
  V v_t_245 = (g_std_2epath_2eparse(heff_dup(v_st_240), v_x_242));
  V v_t_246 = (g_std_2epath_2ejoin(v_t_244, v_t_245));
  V v_a_247 = ({ V a_0 = v_st_240; V a_1 = v_t_246; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_246); r_; });
  V v_t_248 = (g_std_2epath_2eparse(heff_dup(v_st_240), v_a_247));
  V v_t_249 = (g_std_2epath_2eparse(heff_dup(v_st_240), v_f_243));
  V v_t_2410 = (g_std_2epath_2ejoin(v_t_248, v_t_249));
  V v_p_2411 = ({ V a_0 = v_st_240; V a_1 = v_t_2410; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2410); r_; });
  V v_t_2412 = (g_std_2epath_2eparse(heff_dup(v_st_240), heff_get_n(v_t_241, 0, 6)));
  V v_t_2413 = (g_std_2epath_2eparse(heff_dup(v_st_240), v_p_2411));
  V v_t_2414 = (g_std_2epath_2ejoin(v_t_2412, v_t_2413));
  return ({ V a_0 = v_st_240; V a_1 = v_t_2414; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_240); heff_drop(v_t_2414); r_; });
}
V g_heff_2ebuild_2ecommands_2eappFile_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eappFile(a[0], a[1], a[2], a[3]);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2erunDir_str0, 9, ".heff/run");
HEFF_LIT(g_heff_2ebuild_2ecommands_2erunDir_str1, 2, "..");
HEFF_LIT(g_heff_2ebuild_2ecommands_2erunDir_str2, 2, "..");
HEFF_LIT(g_heff_2ebuild_2ecommands_2erunDir_str3, 2, "..");
HEFF_LIT(g_heff_2ebuild_2ecommands_2erunDir_str4, 2, "..");
HEFF_LIT(g_heff_2ebuild_2ecommands_2erunDir_str5, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2erunDir_str6, 1, "_");
Clo g_heff_2ebuild_2ecommands_2erunDir_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2erunDir_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2erunDir(V v_paths_240, V v_file_241) {
top: ;
  V v_style_242 = heff_take_field(v_paths_240, 5);
  V v_root_243 = heff_get_n(v_paths_240, 0, 6);
  V v_st_244 = heff_dup(v_style_242);
  V v_t_245 = (g_std_2epath_2eparse(heff_dup(v_st_244), v_root_243));
  V v_t_246 = (g_std_2epath_2eparse(heff_dup(v_st_244), ((V)&g_heff_2ebuild_2ecommands_2erunDir_str0)));
  V v_t_247 = (g_std_2epath_2ejoin(v_t_245, v_t_246));
  V v_d_248 = ({ V a_0 = v_st_244; V a_1 = v_t_247; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_244); heff_drop(v_t_247); r_; });
  HeffT3 v_t_249 = (g_std_2epath_2eparse_24cpr(heff_dup(v_style_242), v_file_241));
  {
    V v_field_2410 = v_t_249.f[0];
    V v_field_2411 = v_t_249.f[1];
    V v_field_2412 = v_t_249.f[2];
    V v_d_2413 = v_field_2410;
    heff_drop(v_d_2413);
    V v_a_2414 = v_field_2411;
    V v_xs_2415 = v_field_2412;
    V v_xs_2416 = ({ V b_0 = ((V)&g_heff_2ebuild_2ecommands_2erunDir_str1); V a_1 = v_a_2414; V a_2 = ((V)&g_heff_2ebuild_2ecommands_2erunDir_str2); V b_3 = ((V)&g_heff_2ebuild_2ecommands_2erunDir_str3); V a_4 = ((V)&g_heff_2ebuild_2ecommands_2erunDir_str4); V a_5 = NTAG(TAG_Nil); V a_6 = v_xs_2415; V r_ = (g_list_2efoldl_24s680990791x1764841948(b_0, a_1, a_2, b_3, a_4, a_5, a_6)); heff_drop(b_0); heff_drop(v_a_2414); heff_drop(b_3); r_; });
    V v_t_2417 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2416));
    V v_x2_2418 = v_t_2417;
    V v_p_2421;
    switch (heff_tag_of(v_x2_2418)) {
    case TAG_Nil: {
      v_p_2421 = ((V)&g_heff_2ebuild_2ecommands_2erunDir_str5);
      break;
    }
    case TAG_Cons: {
      V v_x_2419 = heff_field(v_x2_2418, 0);
      V v_xs_2420 = heff_field(v_x2_2418, 1);
      heff_take_n(v_x2_2418, 3ULL, 2);
      v_p_2421 = ({ V a_0 = ((V)&g_heff_2ebuild_2ecommands_2erunDir_str6); V a_1 = v_x_2419; V a_2 = v_xs_2420; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2420); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2418);
    }
    V v_st_2422 = v_style_242;
    V v_t_2423 = (g_std_2epath_2eparse(heff_dup(v_st_2422), v_d_248));
    V v_t_2424 = (g_std_2epath_2eparse(heff_dup(v_st_2422), v_p_2421));
    V v_t_2425 = (g_std_2epath_2ejoin(v_t_2423, v_t_2424));
    return ({ V a_0 = v_st_2422; V a_1 = v_t_2425; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2422); heff_drop(v_t_2425); r_; });
  }
}
V g_heff_2ebuild_2ecommands_2erunDir_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2erunDir(a[0], a[1]);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eselfPath_24s1217305498x1892484309_str0, 5, "win32");
V g_heff_2ebuild_2ecommands_2eselfPath_24s1217305498x1892484309_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eselfPath_24s1217305498x1892484309_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eselfPath_24s1217305498x1892484309_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2eselfPath_24s1217305498x1892484309_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eselfPath_24s1217305498x1892484309_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eselfPath_24s1217305498x1892484309_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2eselfPath_24s1217305498x1892484309_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2eselfPath_24s1217305498x1892484309_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eselfPath_24s1217305498x1892484309_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eselfPath_24s1217305498x1892484309_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2eselfPath_24s1217305498x1892484309(V v_e_240, V v_hd_241, V v_k_242) {
top: ;
  V v_t_244 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2eselfPath_24s1217305498x1892484309_lam0_clo)})});
  V v_t_245 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_244})});
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_245})});
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_249})});
  return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), v_t_2410, heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2ecommands_2eselfPath_24s1217305498x1892484309_lam1, 1, 3, (V[]){v_e_240, v_hd_241, v_k_242})));
}
V g_heff_2ebuild_2ecommands_2eselfPath_24s1217305498x1892484309_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eselfPath_24s1217305498x1892484309(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2ecommands_2eselfPath_24s1217305498x1892484309_lam0(V self, V *args) {
  V v_s_243 = args[0];
  return v_s_243;
}
V g_heff_2ebuild_2ecommands_2eselfPath_24s1217305498x1892484309_lam2(V self, V *args) {
  V v_s_2412 = args[0];
  return v_s_2412;
}
V g_heff_2ebuild_2ecommands_2eselfPath_24s1217305498x1892484309_lam3(V self, V *args) {
  V v_x_2420 = args[0];
  V v_x_2411 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2421 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_x_2420));
  V v_t_2422;
  if (heff_strEq_c(v_x_2411, ((V)&g_heff_2ebuild_2ecommands_2eselfPath_24s1217305498x1892484309_str0))) {
    v_t_2422 = NTAG(TAG_Windows);
  } else {
    v_t_2422 = NTAG(TAG_Posix);
  }
  V v_x_2423 = ({ V a_0 = v_t_2422; V a_1 = v_x_2421; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2422); heff_drop(v_x_2421); r_; });
  V f_ = v_k_242;
  args[0] = v_x_2423;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eselfPath_24s1217305498x1892484309_lam1(V self, V *args) {
  V v_x_2411 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2413 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ProgramPath, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2eselfPath_24s1217305498x1892484309_lam2_clo)})});
  V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
  V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2418})});
  return (g_co_2eop_24s310169282x2049378029(v_e_240, v_t_2419, v_hd_241, heff_clo_n(g_heff_2ebuild_2ecommands_2eselfPath_24s1217305498x1892484309_lam3, 1, 2, (V[]){v_x_2411, v_k_242})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecwdNow_24s668555420x1041141502_str0, 5, "win32");
V g_heff_2ebuild_2ecommands_2ecwdNow_24s668555420x1041141502_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ecwdNow_24s668555420x1041141502_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecwdNow_24s668555420x1041141502_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2ecwdNow_24s668555420x1041141502_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ecwdNow_24s668555420x1041141502_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecwdNow_24s668555420x1041141502_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2ecwdNow_24s668555420x1041141502_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecwdNow_24s668555420x1041141502_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ecwdNow_24s668555420x1041141502_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecwdNow_24s668555420x1041141502_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2ecwdNow_24s668555420x1041141502(V v_e_240, V v_hd_241, V v_k_242) {
top: ;
  V v_t_244 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2ecwdNow_24s668555420x1041141502_lam0_clo)})});
  V v_t_245 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_244})});
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_245})});
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_249})});
  return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), v_t_2410, heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2ecommands_2ecwdNow_24s668555420x1041141502_lam1, 1, 3, (V[]){v_e_240, v_hd_241, v_k_242})));
}
V g_heff_2ebuild_2ecommands_2ecwdNow_24s668555420x1041141502_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ecwdNow_24s668555420x1041141502(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2ecommands_2ecwdNow_24s668555420x1041141502_lam0(V self, V *args) {
  V v_s_243 = args[0];
  return v_s_243;
}
V g_heff_2ebuild_2ecommands_2ecwdNow_24s668555420x1041141502_lam2(V self, V *args) {
  V v_s_2412 = args[0];
  return v_s_2412;
}
V g_heff_2ebuild_2ecommands_2ecwdNow_24s668555420x1041141502_lam3(V self, V *args) {
  V v_x_2420 = args[0];
  V v_x_2411 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2421 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_x_2420));
  V v_t_2422;
  if (heff_strEq_c(v_x_2411, ((V)&g_heff_2ebuild_2ecommands_2ecwdNow_24s668555420x1041141502_str0))) {
    v_t_2422 = NTAG(TAG_Windows);
  } else {
    v_t_2422 = NTAG(TAG_Posix);
  }
  V v_x_2423 = ({ V a_0 = v_t_2422; V a_1 = v_x_2421; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2422); heff_drop(v_x_2421); r_; });
  V f_ = v_k_242;
  args[0] = v_x_2423;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ecwdNow_24s668555420x1041141502_lam1(V self, V *args) {
  V v_x_2411 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2413 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_WorkingDir, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2ecwdNow_24s668555420x1041141502_lam2_clo)})});
  V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
  V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2418})});
  return (g_co_2eop_24s310169282x2049378029(v_e_240, v_t_2419, v_hd_241, heff_clo_n(g_heff_2ebuild_2ecommands_2ecwdNow_24s668555420x1041141502_lam3, 1, 2, (V[]){v_x_2411, v_k_242})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ewriteWhole_24s1510611923x1957311911_str0, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ewriteWhole_24s1510611923x1957311911_str1, 4, ".tmp");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ewriteWhole_24s1510611923x1957311911_str2, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ewriteWhole_24s1510611923x1957311911_str3, 4, ".tmp");
V g_heff_2ebuild_2ecommands_2ewriteWhole_24s1510611923x1957311911_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ewriteWhole_24s1510611923x1957311911_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewriteWhole_24s1510611923x1957311911_lam0, 3, 0};
V g_heff_2ebuild_2ecommands_2ewriteWhole_24s1510611923x1957311911_lam3(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ewriteWhole_24s1510611923x1957311911_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewriteWhole_24s1510611923x1957311911_lam3, 3, 0};
V g_heff_2ebuild_2ecommands_2ewriteWhole_24s1510611923x1957311911_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2ewriteWhole_24s1510611923x1957311911_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ewriteWhole_24s1510611923x1957311911_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ewriteWhole_24s1510611923x1957311911_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewriteWhole_24s1510611923x1957311911_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2ewriteWhole_24s1510611923x1957311911(V v_e_240, V v_path_241, V v_text_242) {
top: ;
  V v_t_243 = heff_intShow(heff_strLength_lent(v_text_242, 0));
  V v_t_244 = heff_strAppend(heff_strAppend(heff_dup(v_path_241), ((V)&g_heff_2ebuild_2ecommands_2ewriteWhole_24s1510611923x1957311911_str0)), v_t_243);
  V v_path_245 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), heff_strAppend(v_t_244, ((V)&g_heff_2ebuild_2ecommands_2ewriteWhole_24s1510611923x1957311911_str1))));
  V v_c_246 = ({ V a_0 = heff_dup(v_e_240); V a_1 = v_path_245; V a_2 = heff_dup(v_text_242); V r_ = (g_std_2efilesystem_2ewriteFile_24s1279893433x291681682(a_0, a_1, a_2)); heff_drop(v_path_245); r_; });
  V v_t_247 = (g_exception_2eattempted(heff_dup(v_e_240)));
  V v_c_2411 = heff_tr(heff_call(v_c_246, 2, (V[]){v_t_247, ((V)&g_heff_2ebuild_2ecommands_2ewriteWhole_24s1510611923x1957311911_lam0_clo)}));
  return heff_clo_n(g_heff_2ebuild_2ecommands_2ewriteWhole_24s1510611923x1957311911_lam1, 2, 4, (V[]){v_c_2411, v_text_242, v_path_241, v_e_240});
}
V g_heff_2ebuild_2ecommands_2ewriteWhole_24s1510611923x1957311911_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ewriteWhole_24s1510611923x1957311911(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2ecommands_2ewriteWhole_24s1510611923x1957311911_lam0(V self, V *args) {
  V v_x_248 = args[0];
  V v_hd_249 = args[1];
  V v_k_2410 = args[2];
  heff_drop(v_hd_249);
  V f_ = v_k_2410;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_248});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ewriteWhole_24s1510611923x1957311911_lam3(V self, V *args) {
  V v_x_2423 = args[0];
  V v_hd_2424 = args[1];
  V v_k_2425 = args[2];
  heff_drop(v_hd_2424);
  V f_ = v_k_2425;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2423});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ewriteWhole_24s1510611923x1957311911_lam4(V self, V *args) {
  V v_x_2427 = args[0];
  V v_k_2413 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2430;
  switch (heff_tag_of(v_x_2427)) {
  case TAG_Left: {
    heff_take_n(v_x_2427, 0ULL, 1);
    v_t_2430 = NTAG(TAG_False);
    break;
  }
  case TAG_Right: {
    heff_take_n(v_x_2427, 0ULL, 1);
    v_t_2430 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_x_2427);
  }
  V f_ = v_k_2413;
  args[0] = v_t_2430;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ewriteWhole_24s1510611923x1957311911_lam2(V self, V *args) {
  V v_x_2414 = args[0];
  V v_k_2413 = heff_env(self)[0];
  V v_text_242 = heff_env(self)[1];
  V v_path_241 = heff_env(self)[2];
  V v_e_240 = heff_env(self)[3];
  V v_hd_2412 = heff_env(self)[4];
  heff_clo_take(self, 5);
  switch (heff_tag_of(v_x_2414)) {
  case TAG_Left: {
    heff_take_n(v_x_2414, 0ULL, 1);
    heff_drop(v_text_242);
    heff_drop(v_path_241);
    heff_drop(v_e_240);
    heff_drop(v_hd_2412);
    V f_ = v_k_2413;
    args[0] = NTAG(TAG_False);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Right: {
    heff_take_n(v_x_2414, 0ULL, 1);
    V v_t_2417 = heff_intShow(heff_strLength(v_text_242));
    V v_t_2418 = heff_strAppend(heff_strAppend(heff_dup(v_path_241), ((V)&g_heff_2ebuild_2ecommands_2ewriteWhole_24s1510611923x1957311911_str2)), v_t_2417);
    V v_path_2419 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), heff_strAppend(v_t_2418, ((V)&g_heff_2ebuild_2ecommands_2ewriteWhole_24s1510611923x1957311911_str3))));
    V v_to_2420 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_path_241));
    V v_c_2421 = ({ V a_0 = heff_dup(v_e_240); V a_1 = v_path_2419; V a_2 = v_to_2420; V r_ = (g_std_2efilesystem_2ereplace_24s1810255102x220553654(a_0, a_1, a_2)); heff_drop(v_path_2419); heff_drop(v_to_2420); r_; });
    V v_t_2422 = (g_exception_2eattempted(v_e_240));
    V v_c_2426 = heff_tr(heff_call(v_c_2421, 2, (V[]){v_t_2422, ((V)&g_heff_2ebuild_2ecommands_2ewriteWhole_24s1510611923x1957311911_lam3_clo)}));
    V f_ = v_c_2426;
    heff_room[0] = v_hd_2412;
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ewriteWhole_24s1510611923x1957311911_lam4, 1, 1, (V[]){v_k_2413});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_x_2414);
  }
}
V g_heff_2ebuild_2ecommands_2ewriteWhole_24s1510611923x1957311911_lam1(V self, V *args) {
  V v_hd_2412 = args[0];
  V v_k_2413 = args[1];
  V v_c_2411 = heff_env(self)[0];
  V v_text_242 = heff_env(self)[1];
  V v_path_241 = heff_env(self)[2];
  V v_e_240 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_2411;
  args[0] = heff_dup(v_hd_2412);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ewriteWhole_24s1510611923x1957311911_lam2, 1, 5, (V[]){v_k_2413, v_text_242, v_path_241, v_e_240, v_hd_2412});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ekeptWritten_24s35934590x313560989_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ekeptWritten_24s35934590x313560989_str1, 1, "_");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ekeptWritten_24s35934590x313560989_str2, 8, "heff.zig");
V g_heff_2ebuild_2ecommands_2ekeptWritten_24s35934590x313560989_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ekeptWritten_24s35934590x313560989_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ekeptWritten_24s35934590x313560989_lam0, 3, 0};
V g_heff_2ebuild_2ecommands_2ekeptWritten_24s35934590x313560989_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ekeptWritten_24s35934590x313560989_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ekeptWritten_24s35934590x313560989_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ekeptWritten_24s35934590x313560989_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ekeptWritten_24s35934590x313560989_entry, 11, 0};

V g_heff_2ebuild_2ecommands_2ekeptWritten_24s35934590x313560989(V v_e_240, V v_bi_241, V v_dir_242, V v_zig_243, V v_id_244, V v_texts_245, V v_backs_246, V v_done_247, V v_out_248, V v_z_249, V v_z_2410) {
top: ;
  V v_groups_2411 = heff_take_field(v_out_248, 2);
  V v_copies_2412 = heff_take_field(v_out_248, 3);
  V v_emits_2413 = heff_take_field(v_out_248, 4);
  V v_parts_2414 = heff_take_field(v_out_248, 0);
  V v_errors_2415 = heff_get_n(v_out_248, 1, 5);
  V v_paths_2416 = heff_take_field(v_bi_241, 0);
  V v_modules_2417 = heff_get_n(v_bi_241, 2, 3);
  V v_t_2436;
  if (heff_strEq_c_lent(v_id_244, ((V)&g_heff_2ebuild_2ecommands_2ekeptWritten_24s35934590x313560989_str0), 2)) {
    heff_drop(v_id_244);
    heff_drop(v_backs_246);
    heff_drop(v_groups_2411);
    heff_drop(v_copies_2412);
    heff_drop(v_emits_2413);
    heff_drop(v_paths_2416);
    heff_drop(v_modules_2417);
    v_t_2436 = v_done_247;
  } else {
    V v_s_2418 = (g_heff_2ebuild_2ecommands_2ebackDirOf(heff_dup(v_paths_2416)));
    V v_path_2419 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_s_2418));
    V v_c_2420 = ({ V a_0 = heff_dup(v_e_240); V a_1 = v_path_2419; V r_ = (g_std_2efilesystem_2emakeDirectory_24s718897684x895598918(a_0, a_1)); heff_drop(v_path_2419); r_; });
    V v_t_2421 = (g_exception_2eattempted(heff_dup(v_e_240)));
    V v_c_2425 = heff_tr(heff_call(v_c_2420, 2, (V[]){v_t_2421, ((V)&g_heff_2ebuild_2ecommands_2ekeptWritten_24s35934590x313560989_lam0_clo)}));
    v_t_2436 = heff_clo_n(g_heff_2ebuild_2ecommands_2ekeptWritten_24s35934590x313560989_lam1, 2, 11, (V[]){v_c_2425, heff_dup(v_texts_245), v_modules_2417, v_groups_2411, v_copies_2412, v_emits_2413, v_id_244, v_backs_246, heff_dup(v_e_240), v_paths_2416, v_done_247});
  }
  V v_t_2437 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ekeptWritten_24s35934590x313560989_str2), v_zig_243}), v_parts_2414});
  return (g_heff_2ebuild_2ecommands_2ewriteParts_24s610674570x1742983909(v_e_240, v_dir_242, v_t_2436, heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2437, v_errors_2415}), v_z_249, v_z_2410));
}
V g_heff_2ebuild_2ecommands_2ekeptWritten_24s35934590x313560989_entry(V self, V *a) {
  (void)self;
  V a5 = a[5]; V r = g_heff_2ebuild_2ecommands_2ekeptWritten_24s35934590x313560989(a[0], a[1], a[2], a[3], a[4], a5, a[6], a[7], a[8], a[9], a[10]); heff_drop(a5); return r;
}
V g_heff_2ebuild_2ecommands_2ekeptWritten_24s35934590x313560989_lam0(V self, V *args) {
  V v_x_2422 = args[0];
  V v_hd_2423 = args[1];
  V v_k_2424 = args[2];
  heff_drop(v_hd_2423);
  V f_ = v_k_2424;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2422});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ekeptWritten_24s35934590x313560989_lam3(V self, V *args) {
  V v_x_2435 = args[0];
  V v_done_247 = heff_env(self)[0];
  V v_hd_2426 = heff_env(self)[1];
  V v_k_2427 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2435);
  V f_ = v_done_247;
  heff_room[0] = v_hd_2426;
  heff_room[1] = v_k_2427;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ekeptWritten_24s35934590x313560989_lam2(V self, V *args) {
  V v_x_2428 = args[0];
  V v_texts_245 = heff_env(self)[0];
  V v_modules_2417 = heff_env(self)[1];
  V v_groups_2411 = heff_env(self)[2];
  V v_copies_2412 = heff_env(self)[3];
  V v_emits_2413 = heff_env(self)[4];
  V v_id_244 = heff_env(self)[5];
  V v_backs_246 = heff_env(self)[6];
  V v_e_240 = heff_env(self)[7];
  V v_paths_2416 = heff_env(self)[8];
  V v_hd_2426 = heff_env(self)[9];
  V v_done_247 = heff_env(self)[10];
  V v_k_2427 = heff_env(self)[11];
  heff_clo_take(self, 12);
  heff_drop(v_x_2428);
  V v_t_2429 = ({ V a_0 = heff_dup(g_std_2eordmap_2eempty_get()); V a_1 = v_texts_245; V r_ = (g_list_2efoldl_24s744304057x1932700078(a_0, a_1)); heff_drop(v_texts_245); r_; });
  V v_t_2430 = (g_std_2eordmap_2einsert_24s615484302x989744458(heff_dup(g_std_2eordmap_2eempty_get()), ((V)&g_heff_2ebuild_2ecommands_2ekeptWritten_24s35934590x313560989_str1), NTAG(TAG_MkUnit)));
  V v_t_2431 = ({ V a_0 = v_t_2430; V a_1 = v_modules_2417; V r_ = (g_list_2efoldl_24s1614667250x430274379(a_0, a_1)); heff_drop(v_modules_2417); r_; });
  V v_t_2432 = heff_rec_n(4, shape_groups__copies__emits__jss, (V[]){v_groups_2411, v_copies_2412, v_emits_2413, NTAG(TAG_Nil)});
  V v_t_2433 = (g_heff_2ebuild_2ebackcache_2ebackTexts(v_id_244, heff_rec_n(2, shape_mods__olds, (V[]){v_t_2431, v_backs_246}), v_t_2432));
  V v_c_2434 = ({ V a_0 = v_e_240; V a_1 = v_paths_2416; V a_2 = v_t_2429; V a_3 = v_t_2433; V r_ = (g_heff_2ebuild_2ecommands_2ewriteBacks_24s896479057x1627394630(a_0, a_1, a_2, a_3)); heff_drop(v_t_2429); heff_drop(v_t_2433); r_; });
  V f_ = v_c_2434;
  heff_room[0] = heff_dup(v_hd_2426);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ekeptWritten_24s35934590x313560989_lam3, 1, 3, (V[]){v_done_247, v_hd_2426, v_k_2427});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ekeptWritten_24s35934590x313560989_lam1(V self, V *args) {
  V v_hd_2426 = args[0];
  V v_k_2427 = args[1];
  V v_c_2425 = heff_env(self)[0];
  V v_texts_245 = heff_env(self)[1];
  V v_modules_2417 = heff_env(self)[2];
  V v_groups_2411 = heff_env(self)[3];
  V v_copies_2412 = heff_env(self)[4];
  V v_emits_2413 = heff_env(self)[5];
  V v_id_244 = heff_env(self)[6];
  V v_backs_246 = heff_env(self)[7];
  V v_e_240 = heff_env(self)[8];
  V v_paths_2416 = heff_env(self)[9];
  V v_done_247 = heff_env(self)[10];
  heff_clo_take(self, 11);
  V f_ = v_c_2425;
  args[0] = heff_dup(v_hd_2426);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ekeptWritten_24s35934590x313560989_lam2, 1, 12, (V[]){v_texts_245, v_modules_2417, v_groups_2411, v_copies_2412, v_emits_2413, v_id_244, v_backs_246, v_e_240, v_paths_2416, v_hd_2426, v_done_247, v_k_2427});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ewriteOutC_24s196946078x469800039_str0, 2, ".c");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ewriteOutC_24s196946078x469800039_str1, 4, ".zig");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ewriteOutC_24s196946078x469800039_str2, 2, ".c");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ewriteOutC_24s196946078x469800039_str3, 13, "cannot write ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ewriteOutC_24s196946078x469800039_str4, 4, ".zig");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ewriteOutC_24s196946078x469800039_str5, 1, "\012");
V g_heff_2ebuild_2ecommands_2ewriteOutC_24s196946078x469800039_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ewriteOutC_24s196946078x469800039_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewriteOutC_24s196946078x469800039_lam0, 3, 0};
V g_heff_2ebuild_2ecommands_2ewriteOutC_24s196946078x469800039_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ewriteOutC_24s196946078x469800039_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ewriteOutC_24s196946078x469800039_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ewriteOutC_24s196946078x469800039_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewriteOutC_24s196946078x469800039_entry, 7, 0};

V g_heff_2ebuild_2ecommands_2ewriteOutC_24s196946078x469800039(V v_e_240, V v_outPath_241, V v_zig_242, V v_done_243, V v_o_244, V v_z_245, V v_z_246) {
top: ;
  int64_t v_t_247 = (heff_unbox_word(heff_strLength_lent(v_outPath_241, 0)) - ((int64_t)2ULL));
  V v_t_248 = heff_strSlice(heff_dup(v_outPath_241), heff_box_word(v_t_247), heff_strLength_lent(v_outPath_241, 0));
  V v_t_2410;
  if (heff_strEq_c(v_t_248, ((V)&g_heff_2ebuild_2ecommands_2ewriteOutC_24s196946078x469800039_str0))) {
    int64_t v_t_249 = (heff_unbox_word(heff_strLength_lent(v_outPath_241, 0)) - ((int64_t)2ULL));
    v_t_2410 = heff_strSlice_lent(v_outPath_241, MK_INT(0LL), heff_box_word(v_t_249), 6);
  } else {
    v_t_2410 = heff_dup(v_outPath_241);
  }
  V v_path_2411 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), heff_strAppend(v_t_2410, ((V)&g_heff_2ebuild_2ecommands_2ewriteOutC_24s196946078x469800039_str1))));
  V v_c_2412 = ({ V a_0 = heff_dup(v_e_240); V a_1 = v_path_2411; V a_2 = v_zig_242; V r_ = (g_std_2efilesystem_2ewriteFile_24s1279893433x291681682(a_0, a_1, a_2)); heff_drop(v_path_2411); r_; });
  V v_t_2413 = (g_exception_2eattempted(heff_dup(v_e_240)));
  V v_c_2417 = heff_tr(heff_call(v_c_2412, 2, (V[]){v_t_2413, ((V)&g_heff_2ebuild_2ecommands_2ewriteOutC_24s196946078x469800039_lam0_clo)}));
  return (g_heff_2ebuild_2ecommands_2ewriteOut_24s639639504x191707652(heff_dup(v_e_240), heff_dup(v_outPath_241), heff_clo_n(g_heff_2ebuild_2ecommands_2ewriteOutC_24s196946078x469800039_lam1, 2, 4, (V[]){v_c_2417, v_outPath_241, v_e_240, v_done_243}), v_o_244, v_z_245, v_z_246));
}
V g_heff_2ebuild_2ecommands_2ewriteOutC_24s196946078x469800039_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ewriteOutC_24s196946078x469800039(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
V g_heff_2ebuild_2ecommands_2ewriteOutC_24s196946078x469800039_lam0(V self, V *args) {
  V v_x_2414 = args[0];
  V v_hd_2415 = args[1];
  V v_k_2416 = args[2];
  heff_drop(v_hd_2415);
  V f_ = v_k_2416;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2414});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ewriteOutC_24s196946078x469800039_lam3(V self, V *args) {
  V v_x_2434 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_hd_2418 = heff_env(self)[1];
  V v_k_2419 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2434);
  V v_t_2435 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2436 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2435})});
  V v_t_2437 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2436})});
  V v_t_2438 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2437})});
  V v_t_2439 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2438})});
  V v_t_2440 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2439})});
  V v_t_2441 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2440})});
  return (g_co_2eop_24s310169282x2049378029(v_e_240, heff_tag_n(TAG_InR, 1, (V[]){v_t_2441}), v_hd_2418, v_k_2419));
}
V g_heff_2ebuild_2ecommands_2ewriteOutC_24s196946078x469800039_lam2(V self, V *args) {
  V v_x_2420 = args[0];
  V v_outPath_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_hd_2418 = heff_env(self)[2];
  V v_k_2419 = heff_env(self)[3];
  V v_done_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  switch (heff_tag_of(v_x_2420)) {
  case TAG_Left: {
    V v_ru_24x_2420_24Left = heff_take_reuse_n(v_x_2420, 0ULL, 1);
    heff_drop(v_done_243);
    int64_t v_t_2422 = (heff_unbox_word(heff_strLength_lent(v_outPath_241, 0)) - ((int64_t)2ULL));
    V v_t_2423 = heff_strSlice(heff_dup(v_outPath_241), heff_box_word(v_t_2422), heff_strLength_lent(v_outPath_241, 0));
    V v_t_2425;
    if (heff_strEq_c(v_t_2423, ((V)&g_heff_2ebuild_2ecommands_2ewriteOutC_24s196946078x469800039_str2))) {
      int64_t v_t_2424 = (heff_unbox_word(heff_strLength_lent(v_outPath_241, 0)) - ((int64_t)2ULL));
      v_t_2425 = heff_strSlice(v_outPath_241, MK_INT(0LL), heff_box_word(v_t_2424));
    } else {
      v_t_2425 = v_outPath_241;
    }
    V v_t_2426 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ewriteOutC_24s196946078x469800039_str3), heff_strAppend(v_t_2425, ((V)&g_heff_2ebuild_2ecommands_2ewriteOutC_24s196946078x469800039_str4)));
    V v_t_2427 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_t_2426, ((V)&g_heff_2ebuild_2ecommands_2ewriteOutC_24s196946078x469800039_str5)), NTAG(TAG_MkUnit)});
    V v_t_2428 = heff_tag_at_n(v_ru_24x_2420_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
    V v_t_2429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
    V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
    V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
    V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
    V v_t_2433 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2432})});
    return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), heff_tag_n(TAG_InR, 1, (V[]){v_t_2433}), heff_dup(v_hd_2418), heff_clo_n(g_heff_2ebuild_2ecommands_2ewriteOutC_24s196946078x469800039_lam3, 1, 3, (V[]){v_e_240, v_hd_2418, v_k_2419})));
  }
  case TAG_Right: {
    heff_take_n(v_x_2420, 0ULL, 1);
    heff_drop(v_outPath_241);
    heff_drop(v_e_240);
    V f_ = v_done_243;
    heff_room[0] = v_hd_2418;
    heff_room[1] = v_k_2419;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_x_2420);
  }
}
V g_heff_2ebuild_2ecommands_2ewriteOutC_24s196946078x469800039_lam1(V self, V *args) {
  V v_hd_2418 = args[0];
  V v_k_2419 = args[1];
  V v_c_2417 = heff_env(self)[0];
  V v_outPath_241 = heff_env(self)[1];
  V v_e_240 = heff_env(self)[2];
  V v_done_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_2417;
  args[0] = heff_dup(v_hd_2418);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ewriteOutC_24s196946078x469800039_lam2, 1, 5, (V[]){v_outPath_241, v_e_240, v_hd_2418, v_k_2419, v_done_243});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s661001863x1156540388_str0, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s661001863x1156540388_str1, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s661001863x1156540388_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s661001863x1156540388_str3, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s661001863x1156540388_str4, 9, "runtime.c");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s661001863x1156540388_str5, 11, "runtime.zig");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s661001863x1156540388_str6, 6, "heff: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s661001863x1156540388_str7, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s661001863x1156540388_str8, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s661001863x1156540388_str9, 6, "heff: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s661001863x1156540388_str10, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s661001863x1156540388_str11, 15, "no files given\012");
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s661001863x1156540388_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s661001863x1156540388_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s661001863x1156540388_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s661001863x1156540388_lam0(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s661001863x1156540388_lam4(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ecompileLastC_24s661001863x1156540388_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecompileLastC_24s661001863x1156540388_entry, 11, 0};

V g_heff_2ebuild_2ecommands_2ecompileLastC_24s661001863x1156540388(V v_lit_240, V v_e_241, V v_bi_242, V v_sources_243, V v_file_244, V v_outPath_245, V v_failed_246, V v_done_247, V v_cs_248, V v_z_249, V v_z_2410) {
top: ;
  HeffT2 v_t_2411 = (g_heff_2ebuild_2edriver_2elastChecked_24cpr(v_cs_248));
  {
    V v_field_2413 = v_t_2411.f[1];
    int64_t v_tag_2412 = ((int64_t)v_t_2411.f[0]);
    if ((v_tag_2412 == ((int64_t)0ULL))) {
      V v_c_2414 = v_field_2413;
      V v_t_2415 = (g_heff_2ebuild_2edriver_2ecandidatesOf(heff_dup(v_c_2414)));
      V v_t_2416 = ({ V a_0 = v_t_2415; V r_ = (g_heff_2ebuild_2edriver_2ecandLeaves(a_0)); heff_drop(v_t_2415); r_; });
      V v_t_2417 = (g_heff_2ebuild_2edriver_2enubStrD(v_t_2416));
      V v_xs_2418 = ({ V b_0 = ((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s661001863x1156540388_str0); V a_1 = MK_INT(0LL); V b_2 = ((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s661001863x1156540388_str1); V b_3 = MK_INT(0LL); V a_4 = ((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s661001863x1156540388_str2); V a_5 = ((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s661001863x1156540388_str3); V a_6 = v_t_2417; V r_ = (g_list_2emap_24s89148281x951607804(b_0, a_1, b_2, b_3, a_4, a_5, a_6)); heff_drop(b_0); heff_drop(b_2); heff_drop(b_3); r_; });
      V v_t_2419 = (g_heff_2ebuild_2ecommands_2enubStrGo(NTAG(TAG_Nil), v_xs_2418));
      V v_c_2420 = (g_heff_2ebuild_2ecommands_2ereadProvidersC_24s1323278373x1718996742(heff_dup(v_e_241), v_sources_243, v_t_2419));
      return heff_tail(v_c_2420, 2, (V[]){heff_dup(v_z_249), heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileLastC_24s661001863x1156540388_lam0, 1, 10, (V[]){v_e_241, v_z_249, v_c_2414, v_file_244, v_failed_246, v_z_2410, v_lit_240, v_bi_242, v_outPath_245, v_done_247})});
    } else {
      heff_drop(v_lit_240);
      heff_drop(v_bi_242);
      heff_drop(v_sources_243);
      heff_drop(v_file_244);
      heff_drop(v_outPath_245);
      heff_drop(v_failed_246);
      heff_drop(v_done_247);
      heff_drop(v_field_2413);
      V v_t_2449 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s661001863x1156540388_str11), NTAG(TAG_MkUnit)});
      V v_t_2450 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2449})});
      V v_t_2451 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2450})});
      V v_t_2452 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2451})});
      V v_t_2453 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2452})});
      V v_t_2454 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2453})});
      V v_t_2455 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2454})});
      return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_241), heff_tag_n(TAG_InR, 1, (V[]){v_t_2455}), heff_dup(v_z_249), heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileLastC_24s661001863x1156540388_lam4, 1, 3, (V[]){v_e_241, v_z_249, v_z_2410})));
    }
  }
}
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s661001863x1156540388_entry(V self, V *a) {
  (void)self;
  V a8 = a[8]; V r = g_heff_2ebuild_2ecommands_2ecompileLastC_24s661001863x1156540388(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a8, a[9], a[10]); heff_drop(a8); return r;
}
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s661001863x1156540388_lam3(V self, V *args) {
  V v_x_2443 = args[0];
  V v_file_244 = heff_env(self)[0];
  V v_failed_246 = heff_env(self)[1];
  V v_why_2433 = heff_env(self)[2];
  V v_z_249 = heff_env(self)[3];
  V v_z_2410 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2443);
  V v_t_2444 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s661001863x1156540388_str9), v_file_244), ((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s661001863x1156540388_str10));
  V f_ = v_failed_246;
  heff_room[0] = heff_strAppend(v_t_2444, v_why_2433);
  heff_room[1] = v_z_249;
  heff_room[2] = v_z_2410;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s661001863x1156540388_lam2(V self, V *args) {
  V v_x_2423 = args[0];
  V v_c_2414 = heff_env(self)[0];
  V v_x_2421 = heff_env(self)[1];
  V v_file_244 = heff_env(self)[2];
  V v_e_241 = heff_env(self)[3];
  V v_z_249 = heff_env(self)[4];
  V v_failed_246 = heff_env(self)[5];
  V v_z_2410 = heff_env(self)[6];
  V v_lit_240 = heff_env(self)[7];
  V v_bi_242 = heff_env(self)[8];
  V v_outPath_245 = heff_env(self)[9];
  V v_x_2422 = heff_env(self)[10];
  V v_done_247 = heff_env(self)[11];
  heff_clo_take(self, 12);
  V v_t_2424 = (g_heff_2ebuild_2edriver_2ecandidatesOf(heff_dup(v_c_2414)));
  V v_t_2425 = ({ V a_0 = v_t_2424; V r_ = (g_heff_2ebuild_2edriver_2ecandLeaves(a_0)); heff_drop(v_t_2424); r_; });
  V v_leaves_2426 = (g_heff_2ebuild_2edriver_2enubStrD(v_t_2425));
  V v_t_2427 = heff_get_n(heff_dup(heff_rfield(v_c_2414, 5)), 0, 10);
  V v_t_2428 = heff_tr(heff_call(((V)&g_heff_2ebuild_2ecommands_2eprovidesLeafC_clo), 1, (V[]){heff_dup(v_x_2421)}));
  V v_t_2429 = (g_list_2emap_24s164225955x66209884(v_t_2427, v_t_2428, v_leaves_2426));
  HeffT2 v_t_2430 = (g_heff_2ecompile_2eglue_2eeithers_24cpr(v_t_2429));
  {
    V v_field_2432 = v_t_2430.f[1];
    int64_t v_tag_2431 = ((int64_t)v_t_2430.f[0]);
    if ((v_tag_2431 == ((int64_t)0ULL))) {
      heff_drop(v_x_2423);
      heff_drop_rec(v_c_2414, 14);
      heff_drop(v_x_2421);
      heff_drop(v_lit_240);
      heff_drop(v_bi_242);
      heff_drop(v_outPath_245);
      heff_drop(v_x_2422);
      heff_drop(v_done_247);
      V v_why_2433 = v_field_2432;
      V v_t_2434 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s661001863x1156540388_str6), heff_dup(v_file_244)), ((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s661001863x1156540388_str7));
      V v_t_2435 = heff_strAppend(heff_strAppend(v_t_2434, heff_dup(v_why_2433)), ((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s661001863x1156540388_str8));
      V v_t_2436 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2435, NTAG(TAG_MkUnit)});
      V v_t_2437 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2436})});
      V v_t_2438 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2437})});
      V v_t_2439 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2438})});
      V v_t_2440 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2439})});
      V v_t_2441 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2440})});
      V v_t_2442 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2441})});
      return (g_co_2eop_24s310169282x2049378029(v_e_241, heff_tag_n(TAG_InR, 1, (V[]){v_t_2442}), heff_dup(v_z_249), heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileLastC_24s661001863x1156540388_lam3, 1, 5, (V[]){v_file_244, v_failed_246, v_why_2433, v_z_249, v_z_2410})));
    } else {
      V v_ms_2445 = v_field_2432;
      V v_glues_2446 = (g_heff_2ecompile_2eglue_2ejusts(v_ms_2445));
      V v_t_2447 = (g_list_2emap_24s1435185561x202019164(v_glues_2446));
      V v_t_2448 = (g_prelude_2e_2b_2b(v_x_2421, v_t_2447));
      return (g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1870015767x1734489010(v_lit_240, v_e_241, v_bi_242, v_file_244, v_outPath_245, heff_rec_n(2, shape_c__zig, (V[]){v_x_2422, v_x_2423}), v_failed_246, v_done_247, v_c_2414, v_t_2448, v_z_249, v_z_2410));
    }
  }
}
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s661001863x1156540388_lam1(V self, V *args) {
  V v_x_2422 = args[0];
  V v_e_241 = heff_env(self)[0];
  V v_z_249 = heff_env(self)[1];
  V v_c_2414 = heff_env(self)[2];
  V v_x_2421 = heff_env(self)[3];
  V v_file_244 = heff_env(self)[4];
  V v_failed_246 = heff_env(self)[5];
  V v_z_2410 = heff_env(self)[6];
  V v_lit_240 = heff_env(self)[7];
  V v_bi_242 = heff_env(self)[8];
  V v_outPath_245 = heff_env(self)[9];
  V v_done_247 = heff_env(self)[10];
  heff_clo_take(self, 11);
  return (g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s628326673x1969472940(heff_dup(v_e_241), ((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s661001863x1156540388_str5), heff_dup(v_z_249), heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileLastC_24s661001863x1156540388_lam2, 1, 12, (V[]){v_c_2414, v_x_2421, v_file_244, v_e_241, v_z_249, v_failed_246, v_z_2410, v_lit_240, v_bi_242, v_outPath_245, v_x_2422, v_done_247})));
}
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s661001863x1156540388_lam0(V self, V *args) {
  V v_x_2421 = args[0];
  V v_e_241 = heff_env(self)[0];
  V v_z_249 = heff_env(self)[1];
  V v_c_2414 = heff_env(self)[2];
  V v_file_244 = heff_env(self)[3];
  V v_failed_246 = heff_env(self)[4];
  V v_z_2410 = heff_env(self)[5];
  V v_lit_240 = heff_env(self)[6];
  V v_bi_242 = heff_env(self)[7];
  V v_outPath_245 = heff_env(self)[8];
  V v_done_247 = heff_env(self)[9];
  heff_clo_take(self, 10);
  return (g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s628326673x1969472940(heff_dup(v_e_241), ((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s661001863x1156540388_str4), heff_dup(v_z_249), heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileLastC_24s661001863x1156540388_lam1, 1, 11, (V[]){v_e_241, v_z_249, v_c_2414, v_x_2421, v_file_244, v_failed_246, v_z_2410, v_lit_240, v_bi_242, v_outPath_245, v_done_247})));
}
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s661001863x1156540388_lam4(V self, V *args) {
  V v_x_2456 = args[0];
  V v_e_241 = heff_env(self)[0];
  V v_z_249 = heff_env(self)[1];
  V v_z_2410 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2456);
  V v_t_2457 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2458 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2457})});
  V v_t_2459 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2458})});
  V v_t_2460 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2459})});
  V v_t_2461 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2460})});
  V v_t_2462 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2461})});
  V v_t_2463 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2462})});
  return (g_co_2eop_24s310169282x2049378029(v_e_241, heff_tag_n(TAG_InR, 1, (V[]){v_t_2463}), v_z_249, v_z_2410));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileJsOut_24s2121337324x1959907762_str0, 13, "cannot write ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileJsOut_24s2121337324x1959907762_str1, 1, "\012");
V g_heff_2ebuild_2ecommands_2ecompileJsOut_24s2121337324x1959907762_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ecompileJsOut_24s2121337324x1959907762_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecompileJsOut_24s2121337324x1959907762_lam0, 3, 0};
V g_heff_2ebuild_2ecommands_2ecompileJsOut_24s2121337324x1959907762_lam3(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ecompileJsOut_24s2121337324x1959907762_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecompileJsOut_24s2121337324x1959907762_lam3, 2, 0};
V g_heff_2ebuild_2ecommands_2ecompileJsOut_24s2121337324x1959907762_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileJsOut_24s2121337324x1959907762_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileJsOut_24s2121337324x1959907762_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ecompileJsOut_24s2121337324x1959907762_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecompileJsOut_24s2121337324x1959907762_entry, 6, 0};

V g_heff_2ebuild_2ecommands_2ecompileJsOut_24s2121337324x1959907762(V v_e_240, V v_outPath_241, V v_bad_242, V v_o_243, V v_z_244, V v_z_245) {
top: ;
  V v_source_246 = heff_take_field(v_o_243, 0);
  V v_errors_247 = heff_get_n(v_o_243, 1, 2);
  V v_path_248 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), heff_dup(v_outPath_241)));
  V v_c_249 = ({ V a_0 = heff_dup(v_e_240); V a_1 = v_path_248; V a_2 = v_source_246; V r_ = (g_std_2efilesystem_2ewriteFile_24s1279893433x291681682(a_0, a_1, a_2)); heff_drop(v_path_248); r_; });
  V v_t_2410 = (g_exception_2eattempted(heff_dup(v_e_240)));
  V v_c_2414 = heff_tr(heff_call(v_c_249, 2, (V[]){v_t_2410, ((V)&g_heff_2ebuild_2ecommands_2ecompileJsOut_24s2121337324x1959907762_lam0_clo)}));
  return heff_tail(v_c_2414, 2, (V[]){heff_dup(v_z_244), heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileJsOut_24s2121337324x1959907762_lam1, 1, 6, (V[]){v_e_240, v_errors_247, v_z_244, v_outPath_241, heff_dup(v_bad_242), v_z_245})});
}
V g_heff_2ebuild_2ecommands_2ecompileJsOut_24s2121337324x1959907762_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ebuild_2ecommands_2ecompileJsOut_24s2121337324x1959907762(a[0], a[1], a2, a[3], a[4], a[5]); heff_drop(a2); return r;
}
V g_heff_2ebuild_2ecommands_2ecompileJsOut_24s2121337324x1959907762_lam0(V self, V *args) {
  V v_x_2411 = args[0];
  V v_hd_2412 = args[1];
  V v_k_2413 = args[2];
  heff_drop(v_hd_2412);
  V f_ = v_k_2413;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2411});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ecompileJsOut_24s2121337324x1959907762_lam3(V self, V *args) {
  V v_hd_2420 = args[0];
  V v_k_2421 = args[1];
  heff_drop(v_hd_2420);
  V f_ = v_k_2421;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ecompileJsOut_24s2121337324x1959907762_lam4(V self, V *args) {
  V v_x_2431 = args[0];
  V v_x_2418 = heff_env(self)[0];
  V v_bad_242 = heff_env(self)[1];
  V v_errors_247 = heff_env(self)[2];
  V v_z_245 = heff_env(self)[3];
  V v_e_240 = heff_env(self)[4];
  V v_z_244 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_2431);
  if ((heff_dup(v_x_2418) == NTAG(TAG_True))) {
    heff_drop(v_x_2418);
    if (!(heff_dup(v_bad_242) == NTAG(TAG_True))) {
      heff_drop(v_bad_242);
      switch (heff_tag_of(v_errors_247)) {
      case TAG_Nil: {
        heff_drop(v_e_240);
        heff_drop(v_z_244);
        V f_ = v_z_245;
        args[0] = NTAG(TAG_MkUnit);
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      }
      case TAG_Cons: {
        V v_ru_24errors_247_24Cons = heff_take_reuse_n(v_errors_247, 0ULL, 2);
        V v_t_2434 = heff_tag_at_n(v_ru_24errors_247_24Cons, TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
        V v_t_2435 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2434})});
        V v_t_2436 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2435})});
        V v_t_2437 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2436})});
        V v_t_2438 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2437})});
        V v_t_2439 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2438})});
        V v_t_2440 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2439})});
        return (g_co_2eop_24s310169282x2049378029(v_e_240, heff_tag_n(TAG_InR, 1, (V[]){v_t_2440}), v_z_244, v_z_245));
      }
      default: return heff_nomatch(v_errors_247);
      }
    } else {
      heff_drop(v_bad_242);
      heff_drop(v_errors_247);
      V v_t_2441 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
      V v_t_2442 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2441})});
      V v_t_2443 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2442})});
      V v_t_2444 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2443})});
      V v_t_2445 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2444})});
      V v_t_2446 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2445})});
      V v_t_2447 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2446})});
      return (g_co_2eop_24s310169282x2049378029(v_e_240, heff_tag_n(TAG_InR, 1, (V[]){v_t_2447}), v_z_244, v_z_245));
    }
  } else {
    heff_drop(v_x_2418);
    heff_drop(v_bad_242);
    heff_drop(v_errors_247);
    V v_t_2448 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
    V v_t_2449 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2448})});
    V v_t_2450 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2449})});
    V v_t_2451 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2450})});
    V v_t_2452 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2451})});
    V v_t_2453 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2452})});
    V v_t_2454 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2453})});
    return (g_co_2eop_24s310169282x2049378029(v_e_240, heff_tag_n(TAG_InR, 1, (V[]){v_t_2454}), v_z_244, v_z_245));
  }
}
V g_heff_2ebuild_2ecommands_2ecompileJsOut_24s2121337324x1959907762_lam2(V self, V *args) {
  V v_x_2419 = args[0];
  V v_x_2418 = heff_env(self)[0];
  V v_outPath_241 = heff_env(self)[1];
  V v_e_240 = heff_env(self)[2];
  V v_z_244 = heff_env(self)[3];
  V v_bad_242 = heff_env(self)[4];
  V v_errors_247 = heff_env(self)[5];
  V v_z_245 = heff_env(self)[6];
  heff_clo_take(self, 7);
  heff_drop(v_x_2419);
  V v_t_2430;
  if ((heff_dup(v_x_2418) == NTAG(TAG_True))) {
    heff_drop(v_outPath_241);
    v_t_2430 = ((V)&g_heff_2ebuild_2ecommands_2ecompileJsOut_24s2121337324x1959907762_lam3_clo);
  } else {
    V v_t_2422 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ecompileJsOut_24s2121337324x1959907762_str0), v_outPath_241), ((V)&g_heff_2ebuild_2ecommands_2ecompileJsOut_24s2121337324x1959907762_str1));
    V v_t_2423 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2422, NTAG(TAG_MkUnit)});
    V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
    V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
    V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
    V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
    V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
    V v_t_2429 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2428})});
    v_t_2430 = heff_tr(heff_call(((V)&g_co_2eop_24s310169282x2049378029_clo), 2, (V[]){heff_dup(v_e_240), heff_tag_n(TAG_InR, 1, (V[]){v_t_2429})}));
  }
  V f_ = v_t_2430;
  heff_room[0] = heff_dup(v_z_244);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileJsOut_24s2121337324x1959907762_lam4, 1, 6, (V[]){v_x_2418, v_bad_242, v_errors_247, v_z_245, v_e_240, v_z_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ecompileJsOut_24s2121337324x1959907762_lam1(V self, V *args) {
  V v_x_2415 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_errors_247 = heff_env(self)[1];
  V v_z_244 = heff_env(self)[2];
  V v_outPath_241 = heff_env(self)[3];
  V v_bad_242 = heff_env(self)[4];
  V v_z_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_x_2418;
  switch (heff_tag_of(v_x_2415)) {
  case TAG_Left: {
    heff_take_n(v_x_2415, 0ULL, 1);
    v_x_2418 = NTAG(TAG_False);
    break;
  }
  case TAG_Right: {
    heff_take_n(v_x_2415, 0ULL, 1);
    v_x_2418 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_x_2415);
  }
  return (g_heff_2ebuild_2ecommands_2eemitErrs_24s1206086771x983818389(heff_dup(v_e_240), heff_dup(v_errors_247), heff_dup(v_z_244), heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileJsOut_24s2121337324x1959907762_lam2, 1, 7, (V[]){v_x_2418, v_outPath_241, v_e_240, v_z_244, v_bad_242, v_errors_247, v_z_245})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2emissingOutDir_24s401416675x2114298136_str0, 1, "c");
HEFF_LIT(g_heff_2ebuild_2ecommands_2emissingOutDir_24s401416675x2114298136_str1, 1, "/");
HEFF_LIT(g_heff_2ebuild_2ecommands_2emissingOutDir_24s401416675x2114298136_str2, 5, "win32");
HEFF_LIT(g_heff_2ebuild_2ecommands_2emissingOutDir_24s401416675x2114298136_str3, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2emissingOutDir_24s401416675x2114298136_str4, 1, ".");
V g_heff_2ebuild_2ecommands_2emissingOutDir_24s401416675x2114298136_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2emissingOutDir_24s401416675x2114298136_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2emissingOutDir_24s401416675x2114298136_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2emissingOutDir_24s401416675x2114298136_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2emissingOutDir_24s401416675x2114298136_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2emissingOutDir_24s401416675x2114298136_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2emissingOutDir_24s401416675x2114298136_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2emissingOutDir_24s401416675x2114298136_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2emissingOutDir_24s401416675x2114298136_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2emissingOutDir_24s401416675x2114298136_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2emissingOutDir_24s401416675x2114298136_entry, 4, 0};

V g_heff_2ebuild_2ecommands_2emissingOutDir_24s401416675x2114298136(V v_e_240, V v_o_241, V v_p_242, V v_p_243) {
top: ;
  V v_backend_244 = heff_take_field(v_o_241, 3);
  V v_outPath_245 = heff_get_n(v_o_241, 1, 4);
  V v_t_249;
  if (heff_strEq_c(v_backend_244, ((V)&g_heff_2ebuild_2ecommands_2emissingOutDir_24s401416675x2114298136_str0))) {
    V v_s_246 = heff_dup(v_outPath_245);
    int64_t v_t_247 = (heff_unbox_word(heff_strLength_lent(v_s_246, 0)) - ((int64_t)1ULL));
    V v_t_248 = heff_strSlice(heff_dup(v_s_246), heff_box_word(v_t_247), heff_strLength(v_s_246));
    v_t_249 = heff_bool(heff_strEq_c_lent(v_t_248, ((V)&g_heff_2ebuild_2ecommands_2emissingOutDir_24s401416675x2114298136_str1), 2));
    heff_drop(v_t_248);
  } else {
    v_t_249 = NTAG(TAG_False);
  }
  if ((heff_dup(v_t_249) == NTAG(TAG_True))) {
    heff_drop(v_e_240);
    heff_drop(v_p_242);
    heff_drop(v_outPath_245);
    heff_drop(v_t_249);
    return heff_tail(v_p_243, 1, (V[]){NTAG(TAG_Nothing)});
  } else {
    heff_drop(v_t_249);
    V v_t_2411 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2emissingOutDir_24s401416675x2114298136_lam0_clo)})});
    V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
    V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
    V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
    V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
    V v_t_2416 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
    V v_t_2417 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2416})});
    HEFF_LAST return g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), v_t_2417, heff_dup(v_p_242), heff_clo_n(g_heff_2ebuild_2ecommands_2emissingOutDir_24s401416675x2114298136_lam1, 1, 4, (V[]){v_outPath_245, v_e_240, v_p_242, v_p_243}));
  }
}
V g_heff_2ebuild_2ecommands_2emissingOutDir_24s401416675x2114298136_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2emissingOutDir_24s401416675x2114298136(a[0], a[1], a[2], a[3]);
}
V g_heff_2ebuild_2ecommands_2emissingOutDir_24s401416675x2114298136_lam0(V self, V *args) {
  V v_s_2410 = args[0];
  return v_s_2410;
}
V g_heff_2ebuild_2ecommands_2emissingOutDir_24s401416675x2114298136_lam3(V self, V *args) {
  V v_hd_2437 = args[0];
  V v_k_2438 = args[1];
  V v_x_2436 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2437);
  V f_ = v_k_2438;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2436});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2emissingOutDir_24s401416675x2114298136_lam2(V self, V *args) {
  V v_x_2435 = args[0];
  V v_x_2436 = (g_list_2emap_24s219049803x1458391381(v_x_2435));
  return heff_clo_n(g_heff_2ebuild_2ecommands_2emissingOutDir_24s401416675x2114298136_lam3, 2, 1, (V[]){v_x_2436});
}
V g_heff_2ebuild_2ecommands_2emissingOutDir_24s401416675x2114298136_lam4(V self, V *args) {
  V v_x_2440 = args[0];
  V v_p_243 = heff_env(self)[0];
  V v_x_2431 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_x_2440)) {
  case TAG_Left: {
    heff_take_n(v_x_2440, 0ULL, 1);
    V f_ = v_p_243;
    args[0] = heff_tag_n(TAG_Just, 1, (V[]){v_x_2431});
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Right: {
    heff_take_n(v_x_2440, 0ULL, 1);
    heff_drop(v_x_2431);
    V f_ = v_p_243;
    args[0] = NTAG(TAG_Nothing);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_2440);
  }
}
V g_heff_2ebuild_2ecommands_2emissingOutDir_24s401416675x2114298136_lam1(V self, V *args) {
  V v_x_2418 = args[0];
  V v_outPath_245 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_p_242 = heff_env(self)[2];
  V v_p_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_st_2419;
  if (heff_strEq_c(v_x_2418, ((V)&g_heff_2ebuild_2ecommands_2emissingOutDir_24s401416675x2114298136_str2))) {
    v_st_2419 = NTAG(TAG_Windows);
  } else {
    v_st_2419 = NTAG(TAG_Posix);
  }
  HeffT3 v_t_2420 = (g_std_2epath_2eparse_24cpr(heff_dup(v_st_2419), v_outPath_245));
  V v_t_2430;
  {
    V v_field_2421 = v_t_2420.f[0];
    V v_field_2422 = v_t_2420.f[1];
    V v_field_2423 = v_t_2420.f[2];
    V v_d_2424 = v_field_2421;
    V v_a_2425 = v_field_2422;
    V v_xs_2426 = v_field_2423;
    V v_t_2427 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2426));
    V v_xs_2428 = ({ V a_0 = MK_INT(1LL); V a_1 = v_t_2427; V r_ = (g_list_2edrop(a_0, a_1)); heff_drop(v_t_2427); r_; });
    V v_t_2429 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2428));
    v_t_2430 = heff_tag_n(TAG_MkPath, 3, (V[]){v_d_2424, v_a_2425, v_t_2429});
  }
  V v_x_2431 = ({ V a_0 = v_st_2419; V a_1 = v_t_2430; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2419); heff_drop(v_t_2430); r_; });
  V v_path_2432;
  if (heff_strEq_c_lent(v_x_2431, ((V)&g_heff_2ebuild_2ecommands_2emissingOutDir_24s401416675x2114298136_str3), 2)) {
    v_path_2432 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), ((V)&g_heff_2ebuild_2ecommands_2emissingOutDir_24s401416675x2114298136_str4)));
  } else {
    v_path_2432 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), heff_dup(v_x_2431)));
  }
  V v_c_2433 = (g_std_2efilesystem_2ereadDirectory_24s1485822734x1304823189(heff_dup(v_e_240), v_path_2432));
  V v_t_2434 = (g_exception_2eattempted(v_e_240));
  V v_c_2439 = heff_tr(heff_call(v_c_2433, 2, (V[]){v_t_2434, ((V)&g_heff_2ebuild_2ecommands_2emissingOutDir_24s401416675x2114298136_lam2_clo)}));
  V f_ = v_c_2439;
  heff_room[0] = v_p_242;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2emissingOutDir_24s401416675x2114298136_lam4, 1, 2, (V[]){v_p_243, v_x_2431});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s1022594378x1370601054_str0, 4, "std.");
V g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s1022594378x1370601054_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s1022594378x1370601054_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s1022594378x1370601054_lam0, 2, 0};
V g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s1022594378x1370601054_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s1022594378x1370601054_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s1022594378x1370601054_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s1022594378x1370601054_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s1022594378x1370601054_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s1022594378x1370601054(V v_e_240, V v_host_241, V v_x2_242) {
top: ;
  switch (heff_tag_of(v_x2_242)) {
  case TAG_Nil: {
    heff_drop(v_e_240);
    return ((V)&g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s1022594378x1370601054_lam0_clo);
  }
  case TAG_Cons: {
    V v_s_245 = heff_field(v_x2_242, 0);
    V v_rest_246 = heff_field(v_x2_242, 1);
    heff_take_n(v_x2_242, 3ULL, 2);
    V v_c_247 = (g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s1022594378x1370601054(heff_dup(v_e_240), v_host_241, v_rest_246));
    return heff_clo_n(g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s1022594378x1370601054_lam1, 2, 4, (V[]){v_c_247, v_s_245, v_e_240, heff_dup(v_host_241)});
  }
  default: return heff_nomatch(v_x2_242);
  }
}
V g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s1022594378x1370601054_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s1022594378x1370601054(a[0], a1, a[2]); heff_drop(a1); return r;
}
V g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s1022594378x1370601054_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  heff_drop(v_hd_243);
  V f_ = v_k_244;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s1022594378x1370601054_lam3(V self, V *args) {
  V v_x_2412 = args[0];
  V v_s_245 = heff_env(self)[0];
  V v_x_2410 = heff_env(self)[1];
  V v_k_249 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2413;
  if ((heff_dup(v_x_2412) == NTAG(TAG_True))) {
    heff_drop(v_x_2412);
    v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){heff_get_n(v_s_245, 0, 8), v_x_2410});
  } else {
    heff_drop(v_x_2412);
    heff_drop_rec(v_s_245, 8);
    v_t_2413 = v_x_2410;
  }
  V f_ = v_k_249;
  args[0] = v_t_2413;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s1022594378x1370601054_lam2(V self, V *args) {
  V v_x_2410 = args[0];
  V v_s_245 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_host_241 = heff_env(self)[2];
  V v_hd_248 = heff_env(self)[3];
  V v_k_249 = heff_env(self)[4];
  heff_clo_take(self, 5);
  if (((heff_dup(heff_rfield(v_s_245, 7)) == NTAG(TAG_True)) && heff_strEq_c(heff_strSlice(heff_dup(heff_rfield(v_s_245, 0)), MK_INT(0LL), MK_INT(4LL)), ((V)&g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s1022594378x1370601054_str0)))) {
    V v_c_2411 = ({ V a_0 = v_e_240; V a_1 = v_host_241; V a_2 = heff_dup(v_s_245); V r_ = (g_heff_2ebuild_2ecommands_2esystemOnly_24s1898595125x1760051853(a_0, a_1, a_2)); heff_drop(v_host_241); r_; });
    V f_ = v_c_2411;
    heff_room[0] = v_hd_248;
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s1022594378x1370601054_lam3, 1, 3, (V[]){v_s_245, v_x_2410, v_k_249});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    heff_drop_rec(v_s_245, 8);
    heff_drop(v_e_240);
    heff_drop(v_host_241);
    heff_drop(v_hd_248);
    V f_ = v_k_249;
    args[0] = v_x_2410;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}
V g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s1022594378x1370601054_lam1(V self, V *args) {
  V v_hd_248 = args[0];
  V v_k_249 = args[1];
  V v_c_247 = heff_env(self)[0];
  V v_s_245 = heff_env(self)[1];
  V v_e_240 = heff_env(self)[2];
  V v_host_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_247;
  args[0] = heff_dup(v_hd_248);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2esystemOnlyOf_24s1022594378x1370601054_lam2, 1, 5, (V[]){v_s_245, v_e_240, v_host_241, v_hd_248, v_k_249});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2etypeAtCmd_24s661188703x1448631645_str0, 4, "heff");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etypeAtCmd_24s661188703x1448631645_str1, 3, " : ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etypeAtCmd_24s661188703x1448631645_str2, 10, "   (local)");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etypeAtCmd_24s661188703x1448631645_str3, 11, "   (global)");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etypeAtCmd_24s661188703x1448631645_str4, 13, "nothing there");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etypeAtCmd_24s661188703x1448631645_str5, 13, "nothing there");
V g_heff_2ebuild_2ecommands_2etypeAtCmd_24s661188703x1448631645_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2etypeAtCmd_24s661188703x1448631645_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2etypeAtCmd_24s661188703x1448631645_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2etypeAtCmd_24s661188703x1448631645_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2etypeAtCmd_24s661188703x1448631645_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2etypeAtCmd_24s661188703x1448631645_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2etypeAtCmd_24s661188703x1448631645_entry, 5, 0};

V g_heff_2ebuild_2ecommands_2etypeAtCmd_24s661188703x1448631645(V v_e_240, V v_file_241, V v_offs_242, V v_hd_243, V v_k_244) {
top: ;
  return (g_heff_2ebuild_2ecommands_2eload_24s2043842606x1315457906(heff_dup(v_e_240), v_file_241, heff_dup(v_hd_243), heff_clo_n(g_heff_2ebuild_2ecommands_2etypeAtCmd_24s661188703x1448631645_lam0, 1, 4, (V[]){v_e_240, v_hd_243, v_offs_242, v_k_244})));
}
V g_heff_2ebuild_2ecommands_2etypeAtCmd_24s661188703x1448631645_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2etypeAtCmd_24s661188703x1448631645(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ebuild_2ecommands_2etypeAtCmd_24s661188703x1448631645_lam4(V self, V *args) {
  V v_off_2415 = args[0];
  V v_c_2414 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2416 = ({ V a_0 = v_off_2415; HeffT2 r_ = (g_prelude_2eparseInt_24cpr(a_0)); heff_drop(v_off_2415); r_; });
  {
    V v_field_2418 = v_t_2416.f[1];
    int64_t v_tag_2417 = ((int64_t)v_t_2416.f[0]);
    if ((v_tag_2417 == ((int64_t)0ULL))) {
      V v_o_2419 = v_field_2418;
      HeffT2 v_t_2420 = (g_heff_2ebuild_2equery_2einfoAt_24cpr(v_c_2414, v_o_2419));
      {
        V v_field_2422 = v_t_2420.f[1];
        int64_t v_tag_2421 = ((int64_t)v_t_2420.f[0]);
        if ((v_tag_2421 == ((int64_t)0ULL))) {
          V v_i_2423 = v_field_2422;
          V v_name_2424 = heff_take_field(v_i_2423, 1);
          V v_ty_2425 = heff_take_field(v_i_2423, 4);
          V v_key_2426 = heff_get_n(v_i_2423, 2, 5);
          V v_t_2427 = (g_heff_2esyntax_2esurfaceprint_2enamed(v_name_2424));
          V v_t_2428 = heff_tr(heff_call(v_ty_2425, 1, (V[]){NTAG(TAG_MkUnit)}));
          V v_t_2429 = heff_strAppend(heff_strAppend(v_t_2427, ((V)&g_heff_2ebuild_2ecommands_2etypeAtCmd_24s661188703x1448631645_str1)), v_t_2428);
          V v_t_2431;
          switch (heff_tag_of(v_key_2426)) {
          case TAG_Nothing: {
            v_t_2431 = ((V)&g_heff_2ebuild_2ecommands_2etypeAtCmd_24s661188703x1448631645_str2);
            break;
          }
          case TAG_Just: {
            heff_take_n(v_key_2426, 0ULL, 1);
            v_t_2431 = ((V)&g_heff_2ebuild_2ecommands_2etypeAtCmd_24s661188703x1448631645_str3);
            break;
          }
          default: heff_nomatch(v_key_2426);
          }
          V v_t_2432 = heff_strAppend(v_t_2429, v_t_2431);
          return v_t_2432;
        } else {
          heff_drop(v_field_2422);
          return ((V)&g_heff_2ebuild_2ecommands_2etypeAtCmd_24s661188703x1448631645_str4);
        }
      }
    } else {
      heff_drop(v_c_2414);
      heff_drop(v_field_2418);
      return ((V)&g_heff_2ebuild_2ecommands_2etypeAtCmd_24s661188703x1448631645_str5);
    }
  }
}
V g_heff_2ebuild_2ecommands_2etypeAtCmd_24s661188703x1448631645_lam3(V self, V *args) {
  V v_x_2410 = args[0];
  V v_cs_249 = heff_env(self)[0];
  V v_offs_242 = heff_env(self)[1];
  V v_e_240 = heff_env(self)[2];
  V v_hd_243 = heff_env(self)[3];
  V v_k_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2410);
  HeffT2 v_t_2411 = ({ V a_0 = v_cs_249; HeffT2 r_ = (g_heff_2ebuild_2edriver_2elastChecked_24cpr(a_0)); heff_drop(v_cs_249); r_; });
  {
    V v_field_2413 = v_t_2411.f[1];
    int64_t v_tag_2412 = ((int64_t)v_t_2411.f[0]);
    if ((v_tag_2412 == ((int64_t)0ULL))) {
      V v_c_2414 = v_field_2413;
      V v_t_2433 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2ecommands_2etypeAtCmd_24s661188703x1448631645_lam4, 1, 1, (V[]){v_c_2414}), v_offs_242));
      return (g_heff_2ebuild_2ecommands_2eprintLines_24s438298383x569258715(v_e_240, v_t_2433, v_hd_243, v_k_244));
    } else {
      heff_drop(v_offs_242);
      heff_drop(v_field_2413);
      V v_t_2434 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
      V v_t_2435 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2434})});
      V v_t_2436 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2435})});
      V v_t_2437 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2436})});
      V v_t_2438 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2437})});
      V v_t_2439 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2438})});
      V v_t_2440 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2439})});
      return (g_co_2eop_24s310169282x2049378029(v_e_240, heff_tag_n(TAG_InR, 1, (V[]){v_t_2440}), v_hd_243, v_k_244));
    }
  }
}
V g_heff_2ebuild_2ecommands_2etypeAtCmd_24s661188703x1448631645_lam2(V self, V *args) {
  V v_x_248 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_hd_243 = heff_env(self)[1];
  V v_offs_242 = heff_env(self)[2];
  V v_k_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_cs_249 = heff_get_n(v_x_248, 0, 2);
  return (g_heff_2ebuild_2ecommands_2eputFileDiags_24s1666732804x1501633074(heff_dup(v_e_240), heff_dup(v_cs_249), heff_dup(v_hd_243), heff_clo_n(g_heff_2ebuild_2ecommands_2etypeAtCmd_24s661188703x1448631645_lam3, 1, 5, (V[]){v_cs_249, v_offs_242, v_e_240, v_hd_243, v_k_244})));
}
V g_heff_2ebuild_2ecommands_2etypeAtCmd_24s661188703x1448631645_lam1(V self, V *args) {
  V v_x_246 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_x_245 = heff_env(self)[1];
  V v_hd_243 = heff_env(self)[2];
  V v_offs_242 = heff_env(self)[3];
  V v_k_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_246);
  V v_c_247 = (g_heff_2ebuild_2esession_2ecachedAcc_24s1465745022x907203497(heff_dup(v_e_240), v_x_245));
  V f_ = v_c_247;
  heff_room[0] = heff_dup(v_hd_243);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2etypeAtCmd_24s661188703x1448631645_lam2, 1, 4, (V[]){v_e_240, v_hd_243, v_offs_242, v_k_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2etypeAtCmd_24s661188703x1448631645_lam0(V self, V *args) {
  V v_x_245 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_hd_243 = heff_env(self)[1];
  V v_offs_242 = heff_env(self)[2];
  V v_k_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2ebuild_2ecommands_2eprintErrs_24s1758719709x679644559(heff_dup(v_e_240), ((V)&g_heff_2ebuild_2ecommands_2etypeAtCmd_24s661188703x1448631645_str0), heff_dup(heff_rfield(v_x_245, 1)), MK_INT(0LL), heff_dup(v_hd_243), heff_clo_n(g_heff_2ebuild_2ecommands_2etypeAtCmd_24s661188703x1448631645_lam1, 1, 5, (V[]){v_e_240, v_x_245, v_hd_243, v_offs_242, v_k_244})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eappRead_24s1547571770x1565867076_str0, 8, "build.hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eappRead_24s1547571770x1565867076_str1, 5, "build");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eappRead_24s1547571770x1565867076_str2, 8, "build.hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eappRead_24s1547571770x1565867076_str3, 1, "\012");
V g_heff_2ebuild_2ecommands_2eappRead_24s1547571770x1565867076_lam0(V self, V *args);
V g_heff_2ebuild_2ecommands_2eappRead_24s1547571770x1565867076_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2eappRead_24s1547571770x1565867076_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2eappRead_24s1547571770x1565867076_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2eappRead_24s1547571770x1565867076_lam3(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eappRead_24s1547571770x1565867076_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eappRead_24s1547571770x1565867076_entry, 6, 0};

V g_heff_2ebuild_2ecommands_2eappRead_24s1547571770x1565867076(V v_e_240, V v_st_241, V v_t_242, V v_acc_243, V v_x_244, V v_x5_245) {
top: ;
  switch (heff_tag_of(v_x5_245)) {
  case TAG_Nothing: {
    heff_drop(v_e_240);
    heff_drop(v_st_241);
    heff_drop(v_t_242);
    heff_drop(v_x_244);
    return heff_clo_n(g_heff_2ebuild_2ecommands_2eappRead_24s1547571770x1565867076_lam0, 2, 1, (V[]){v_acc_243});
  }
  case TAG_Just: {
    V v_text_248 = heff_field(v_x5_245, 0);
    V v_ru_24x5_245_24Just = heff_take_reuse_n(v_x5_245, 1ULL, 1);
    V v_src_249 = heff_dup(v_text_248);
    V v_t_2410 = heff_rec_n(7, shape_i__line__lineStart__first__tok__err__cmt, (V[]){MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_True), NTAG(TAG_Nothing), NTAG(TAG_Nothing), NTAG(TAG_Nothing)});
    HeffT3 v_t_2411 = (g_heff_2esyntax_2efmt_2elex_2elexGo_24cpr(heff_dup(v_src_249), v_t_2410, NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil)));
    V v_t_2430;
    {
      V v_field_2413 = v_t_2411.f[1];
      heff_drop(v_t_2411.f[0]);
      heff_drop(v_t_2411.f[2]);
      switch (heff_tag_of(v_field_2413)) {
      case TAG_Nil: {
        V v_t_2415 = heff_rec_n(7, shape_i__line__lineStart__first__tok__err__cmt, (V[]){MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_True), NTAG(TAG_Nothing), NTAG(TAG_Nothing), NTAG(TAG_Nothing)});
        HeffT3 v_t_2416 = (g_heff_2esyntax_2efmt_2elex_2elexGo_24cpr(v_src_249, v_t_2415, NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil)));
        V v_t_2420;
        {
          V v_field_2417 = v_t_2416.f[0];
          heff_drop(v_t_2416.f[1]);
          heff_drop(v_t_2416.f[2]);
          v_t_2420 = v_field_2417;
        }
        HeffT2 v_t_2421 = ({ V a_0 = ((V)&g_heff_2ebuild_2ecommands_2eappRead_24s1547571770x1565867076_str0); V a_1 = ((V)&g_heff_2ebuild_2ecommands_2eappRead_24s1547571770x1565867076_str1); V b_2 = heff_arrayFromList(v_t_2420); V a_3 = MK_INT(0LL); V a_4 = NTAG(TAG_Nothing); HeffT2 r_ = (g_heff_2ebuild_2eproject_2edeclsGo_24cpr(a_0, a_1, b_2, a_3, a_4)); heff_drop(b_2); r_; });
        {
          V v_field_2423 = v_t_2421.f[1];
          int64_t v_tag_2422 = ((int64_t)v_t_2421.f[0]);
          if ((v_tag_2422 == ((int64_t)0ULL))) {
            V v_p_2424 = v_field_2423;
            v_t_2430 = heff_tag_at_n(v_ru_24x5_245_24Just, TAG_Left, 1, (V[]){v_p_2424});
          } else {
            heff_drop_cell(v_ru_24x5_245_24Just, 1);
            V v_x_2425 = v_field_2423;
            v_t_2430 = ({ V a_0 = v_x_2425; V r_ = (g_heff_2ebuild_2eproject_2ebuildOf(a_0)); heff_drop(v_x_2425); r_; });
          }
        }
        break;
      }
      case TAG_Cons: {
        V v_e_2426 = heff_field(v_field_2413, 0);
        heff_take_n(v_field_2413, 1ULL, 2);
        heff_drop(v_src_249);
        V v_start_2428 = heff_take_field(v_e_2426, 0);
        V v_msg_2429 = heff_get_n(v_e_2426, 2, 3);
        v_t_2430 = heff_tag_at_n(v_ru_24x5_245_24Just, TAG_Left, 1, (V[]){heff_rec_n(2, shape_at__msg, (V[]){v_start_2428, v_msg_2429})});
        break;
      }
      default: heff_nomatch(v_field_2413);
      }
    }
    switch (heff_tag_of(v_t_2430)) {
    case TAG_Left: {
      V v_p_2431 = heff_field(v_t_2430, 0);
      heff_take_n(v_t_2430, 1ULL, 1);
      V v_t_2432 = (g_heff_2ebuild_2ecommands_2eappFile(v_st_241, v_t_242, v_x_244, ((V)&g_heff_2ebuild_2ecommands_2eappRead_24s1547571770x1565867076_str2)));
      V v_str_2433 = ({ V a_0 = v_t_2432; V a_1 = v_text_248; V a_2 = v_p_2431; V r_ = (g_heff_2ebuild_2eload_2eproblemMsg(a_0, a_1, a_2)); heff_drop(v_text_248); r_; });
      return heff_clo_n(g_heff_2ebuild_2ecommands_2eappRead_24s1547571770x1565867076_lam1, 2, 3, (V[]){v_str_2433, v_e_240, v_acc_243});
    }
    case TAG_Right: {
      V v_a_2446 = heff_field(v_t_2430, 0);
      heff_take_n(v_t_2430, 1ULL, 1);
      heff_drop(v_text_248);
      V v_c_2447 = (g_heff_2ebuild_2ecommands_2enotInProject_24s1239925928x1402397320(heff_dup(v_e_240), heff_dup(v_st_241), heff_dup(v_t_242), heff_dup(heff_rfield(v_a_2446, 2))));
      return heff_clo_n(g_heff_2ebuild_2ecommands_2eappRead_24s1547571770x1565867076_lam3, 2, 7, (V[]){v_c_2447, v_e_240, v_st_241, v_t_242, v_acc_243, v_x_244, v_a_2446});
    }
    default: return heff_nomatch(v_t_2430);
    }
  }
  default: return heff_nomatch(v_x5_245);
  }
}
V g_heff_2ebuild_2ecommands_2eappRead_24s1547571770x1565867076_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eappRead_24s1547571770x1565867076(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2ebuild_2ecommands_2eappRead_24s1547571770x1565867076_lam0(V self, V *args) {
  V v_hd_246 = args[0];
  V v_k_247 = args[1];
  V v_acc_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_246);
  V f_ = v_k_247;
  args[0] = v_acc_243;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eappRead_24s1547571770x1565867076_lam2(V self, V *args) {
  V v_x_2443 = args[0];
  V v_acc_243 = heff_env(self)[0];
  V v_k_2435 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2443);
  V v_t_2444 = heff_intAdd(heff_take_field(v_acc_243, 1), MK_INT(1LL));
  V v_t_2445 = ({ V rv_1 = v_t_2444; V rr_ = heff_rec_reuse_nf(v_acc_243, 1ULL, 2, shape_apps__bad, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
  V f_ = v_k_2435;
  args[0] = v_t_2445;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eappRead_24s1547571770x1565867076_lam1(V self, V *args) {
  V v_hd_2434 = args[0];
  V v_k_2435 = args[1];
  V v_str_2433 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_acc_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2436 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_str_2433, ((V)&g_heff_2ebuild_2ecommands_2eappRead_24s1547571770x1565867076_str3)), NTAG(TAG_MkUnit)});
  V v_t_2437 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2436})});
  V v_t_2438 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2437})});
  V v_t_2439 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2438})});
  V v_t_2440 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2439})});
  V v_t_2441 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2440})});
  V v_t_2442 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2441})});
  return (g_co_2eop_24s310169282x2049378029(v_e_240, heff_tag_n(TAG_InR, 1, (V[]){v_t_2442}), v_hd_2434, heff_clo_n(g_heff_2ebuild_2ecommands_2eappRead_24s1547571770x1565867076_lam2, 1, 2, (V[]){v_acc_243, v_k_2435})));
}
V g_heff_2ebuild_2ecommands_2eappRead_24s1547571770x1565867076_lam4(V self, V *args) {
  V v_x_2450 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_st_241 = heff_env(self)[1];
  V v_t_242 = heff_env(self)[2];
  V v_acc_243 = heff_env(self)[3];
  V v_x_244 = heff_env(self)[4];
  V v_a_2446 = heff_env(self)[5];
  V v_hd_2448 = heff_env(self)[6];
  V v_k_2449 = heff_env(self)[7];
  heff_clo_take(self, 8);
  return (g_heff_2ebuild_2ecommands_2eappShips_24s332790385x308708530(v_e_240, v_st_241, v_t_242, v_acc_243, v_x_244, v_a_2446, v_x_2450, v_hd_2448, v_k_2449));
}
V g_heff_2ebuild_2ecommands_2eappRead_24s1547571770x1565867076_lam3(V self, V *args) {
  V v_hd_2448 = args[0];
  V v_k_2449 = args[1];
  V v_c_2447 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_st_241 = heff_env(self)[2];
  V v_t_242 = heff_env(self)[3];
  V v_acc_243 = heff_env(self)[4];
  V v_x_244 = heff_env(self)[5];
  V v_a_2446 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V f_ = v_c_2447;
  args[0] = heff_dup(v_hd_2448);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2eappRead_24s1547571770x1565867076_lam4, 1, 8, (V[]){v_e_240, v_st_241, v_t_242, v_acc_243, v_x_244, v_a_2446, v_hd_2448, v_k_2449});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eshipIn_24s811788384x1289483489_str0, 14, "installing in ");
V g_heff_2ebuild_2ecommands_2eshipIn_24s811788384x1289483489_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eshipIn_24s811788384x1289483489_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eshipIn_24s811788384x1289483489_lam1, 1, 0};
V g_heff_2ebuild_2ecommands_2eshipIn_24s811788384x1289483489_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2eshipIn_24s811788384x1289483489_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2eshipIn_24s811788384x1289483489_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2eshipIn_24s811788384x1289483489_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eshipIn_24s811788384x1289483489_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eshipIn_24s811788384x1289483489_entry, 6, 0};

V g_heff_2ebuild_2ecommands_2eshipIn_24s811788384x1289483489(V v_e_240, V v_st_241, V v_t_242, V v_done_243, V v_progs_244, V v_x5_245) {
top: ;
  switch (heff_tag_of(v_x5_245)) {
  case TAG_Nothing: {
    heff_drop(v_e_240);
    heff_drop(v_st_241);
    heff_drop(v_t_242);
    heff_drop(v_progs_244);
    return v_done_243;
  }
  case TAG_Just: {
    V v_home_246 = heff_field(v_x5_245, 0);
    heff_take_n(v_x5_245, 1ULL, 1);
    V v_t_247 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_progs_244)));
    V v_xs_248 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_247; V r_ = (g_list_2efoldl_24s1325969685x576913065(a_0, a_1)); heff_drop(v_t_247); r_; });
    V v_total_249 = (g_list_2efoldl_24f1425140065x1254143828(MK_INT(1LL), MK_INT(0LL), NTAG(TAG_Nil), v_xs_248));
    V v_t_2410 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eshipIn_24s811788384x1289483489_str0), heff_dup(v_home_246));
    return heff_clo_n(g_heff_2ebuild_2ecommands_2eshipIn_24s811788384x1289483489_lam0, 2, 8, (V[]){v_t_2410, v_total_249, v_e_240, v_progs_244, v_st_241, v_t_242, v_home_246, v_done_243});
  }
  default: return heff_nomatch(v_x5_245);
  }
}
V g_heff_2ebuild_2ecommands_2eshipIn_24s811788384x1289483489_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eshipIn_24s811788384x1289483489(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2ebuild_2ecommands_2eshipIn_24s811788384x1289483489_lam1(V self, V *args) {
  V v_t_2413 = args[0];
  return v_t_2413;
}
V g_heff_2ebuild_2ecommands_2eshipIn_24s811788384x1289483489_lam4(V self, V *args) {
  V v_x_2424 = args[0];
  V v_done_243 = heff_env(self)[0];
  V v_hd_2420 = heff_env(self)[1];
  V v_k_2421 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2424);
  V f_ = v_done_243;
  heff_room[0] = v_hd_2420;
  heff_room[1] = v_k_2421;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2eshipIn_24s811788384x1289483489_lam3(V self, V *args) {
  V v_hd_2420 = args[0];
  V v_k_2421 = args[1];
  V v_x_2416 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_done_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2422 = heff_tag_n(TAG_End, 2, (V[]){v_x_2416, NTAG(TAG_MkUnit)});
  V v_t_2423 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
  return (g_co_2eop_24s310169282x2049378029(v_e_240, heff_tag_n(TAG_InR, 1, (V[]){v_t_2423}), heff_dup(v_hd_2420), heff_clo_n(g_heff_2ebuild_2ecommands_2eshipIn_24s811788384x1289483489_lam4, 1, 3, (V[]){v_done_243, v_hd_2420, v_k_2421})));
}
V g_heff_2ebuild_2ecommands_2eshipIn_24s811788384x1289483489_lam2(V self, V *args) {
  V v_x_2416 = args[0];
  V v_progs_244 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_st_241 = heff_env(self)[2];
  V v_t_242 = heff_env(self)[3];
  V v_home_246 = heff_env(self)[4];
  V v_done_243 = heff_env(self)[5];
  V v_hd_2411 = heff_env(self)[6];
  V v_k_2412 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2417 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_progs_244));
  V v_xs_2418 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2417; V r_ = (g_list_2efoldl_24s1325969685x576913065(a_0, a_1)); heff_drop(v_t_2417); r_; });
  V v_t_2419 = (g_heff_2ebuild_2ecommands_2enubStrGo(NTAG(TAG_Nil), v_xs_2418));
  V v_t_2425 = ({ V a_0 = heff_dup(v_e_240); V a_1 = v_st_241; V a_2 = v_t_242; V a_3 = v_home_246; V a_4 = heff_dup(v_x_2416); V a_5 = heff_clo_n(g_heff_2ebuild_2ecommands_2eshipIn_24s811788384x1289483489_lam3, 2, 3, (V[]){v_x_2416, v_e_240, v_done_243}); V a_6 = v_t_2419; V r_ = heff_tr(g_heff_2ebuild_2ecommands_2eshipAll_24s1743475427x165111673(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_t_2419); r_; });
  V f_ = v_t_2425;
  heff_room[0] = v_hd_2411;
  heff_room[1] = v_k_2412;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2eshipIn_24s811788384x1289483489_lam0(V self, V *args) {
  V v_hd_2411 = args[0];
  V v_k_2412 = args[1];
  V v_t_2410 = heff_env(self)[0];
  V v_total_249 = heff_env(self)[1];
  V v_e_240 = heff_env(self)[2];
  V v_progs_244 = heff_env(self)[3];
  V v_st_241 = heff_env(self)[4];
  V v_t_242 = heff_env(self)[5];
  V v_home_246 = heff_env(self)[6];
  V v_done_243 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){heff_dup(g_std_2eprogress_2eroot_get()), v_t_2410, v_total_249, ((V)&g_heff_2ebuild_2ecommands_2eshipIn_24s811788384x1289483489_lam1_clo)})});
  V v_t_2415 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2414})});
  return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), v_t_2415, heff_dup(v_hd_2411), heff_clo_n(g_heff_2ebuild_2ecommands_2eshipIn_24s811788384x1289483489_lam2, 1, 8, (V[]){v_progs_244, v_e_240, v_st_241, v_t_242, v_home_246, v_done_243, v_hd_2411, v_k_2412})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eonPathHint_24s1119738011x382523600_str0, 4, "PATH");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eonPathHint_24s1119738011x382523600_str1, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eonPathHint_24s1119738011x382523600_str2, 5, "win32");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eonPathHint_24s1119738011x382523600_str3, 1, ";");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eonPathHint_24s1119738011x382523600_str4, 1, ":");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eonPathHint_24s1119738011x382523600_str5, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eonPathHint_24s1119738011x382523600_str6, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eonPathHint_24s1119738011x382523600_str7, 14, "heff install: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eonPathHint_24s1119738011x382523600_str8, 60, " is not on the PATH: add it there to run them by their names");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eonPathHint_24s1119738011x382523600_str9, 1, "\012");
V g_heff_2ebuild_2ecommands_2eonPathHint_24s1119738011x382523600_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eonPathHint_24s1119738011x382523600_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eonPathHint_24s1119738011x382523600_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2eonPathHint_24s1119738011x382523600_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eonPathHint_24s1119738011x382523600_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eonPathHint_24s1119738011x382523600_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2eonPathHint_24s1119738011x382523600_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2eonPathHint_24s1119738011x382523600_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2eonPathHint_24s1119738011x382523600_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eonPathHint_24s1119738011x382523600_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eonPathHint_24s1119738011x382523600_entry, 5, 0};

V g_heff_2ebuild_2ecommands_2eonPathHint_24s1119738011x382523600(V v_e_240, V v_st_241, V v_bin_242, V v_hd_243, V v_k_244) {
top: ;
  V v_t_246 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2eonPathHint_24s1119738011x382523600_lam0_clo)})});
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2411})});
  return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), v_t_2412, heff_dup(v_hd_243), heff_clo_n(g_heff_2ebuild_2ecommands_2eonPathHint_24s1119738011x382523600_lam1, 1, 5, (V[]){v_e_240, v_hd_243, v_st_241, v_bin_242, v_k_244})));
}
V g_heff_2ebuild_2ecommands_2eonPathHint_24s1119738011x382523600_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eonPathHint_24s1119738011x382523600(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ebuild_2ecommands_2eonPathHint_24s1119738011x382523600_lam0(V self, V *args) {
  V v_s_245 = args[0];
  return v_s_245;
}
V g_heff_2ebuild_2ecommands_2eonPathHint_24s1119738011x382523600_lam2(V self, V *args) {
  V v_v_2414 = args[0];
  return v_v_2414;
}
V g_heff_2ebuild_2ecommands_2eonPathHint_24s1119738011x382523600_lam4(V self, V *args) {
  V v_d_2427 = args[0];
  V v_st_241 = heff_env(self)[0];
  V v_bin_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2428 = (g_std_2epath_2eparse(heff_dup(v_st_241), v_d_2427));
  V v_t_2429 = (g_std_2epath_2eparse(heff_dup(v_st_241), ((V)&g_heff_2ebuild_2ecommands_2eonPathHint_24s1119738011x382523600_str5)));
  V v_t_2430 = (g_std_2epath_2ejoin(v_t_2428, v_t_2429));
  V v_t_2431 = ({ V a_0 = v_st_241; V a_1 = v_t_2430; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2430); r_; });
  V v_t_2432 = (g_std_2epath_2eparse(heff_dup(v_st_241), v_bin_242));
  V v_t_2433 = (g_std_2epath_2eparse(heff_dup(v_st_241), ((V)&g_heff_2ebuild_2ecommands_2eonPathHint_24s1119738011x382523600_str6)));
  V v_t_2434 = (g_std_2epath_2ejoin(v_t_2432, v_t_2433));
  V v_t_2435 = ({ V a_0 = v_st_241; V a_1 = v_t_2434; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_241); heff_drop(v_t_2434); r_; });
  V v_ret_24bool = heff_bool(heff_strEq_c_lent(v_t_2431, v_t_2435, 0));
  heff_drop(v_t_2431);
  heff_drop(v_t_2435);
  return v_ret_24bool;
}
V g_heff_2ebuild_2ecommands_2eonPathHint_24s1119738011x382523600_lam3(V self, V *args) {
  V v_x_2422 = args[0];
  V v_x_2413 = heff_env(self)[0];
  V v_st_241 = heff_env(self)[1];
  V v_bin_242 = heff_env(self)[2];
  V v_k_244 = heff_env(self)[3];
  V v_e_240 = heff_env(self)[4];
  V v_hd_243 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_path_2424;
  switch (heff_tag_of(v_x_2422)) {
  case TAG_Nothing: {
    v_path_2424 = ((V)&g_heff_2ebuild_2ecommands_2eonPathHint_24s1119738011x382523600_str1);
    break;
  }
  case TAG_Just: {
    V v_x_2423 = heff_field(v_x_2422, 0);
    heff_take_n(v_x_2422, 1ULL, 1);
    v_path_2424 = v_x_2423;
    break;
  }
  default: heff_nomatch(v_x_2422);
  }
  V v_sep_2425;
  if (heff_strEq_c(v_x_2413, ((V)&g_heff_2ebuild_2ecommands_2eonPathHint_24s1119738011x382523600_str2))) {
    v_sep_2425 = ((V)&g_heff_2ebuild_2ecommands_2eonPathHint_24s1119738011x382523600_str3);
  } else {
    v_sep_2425 = ((V)&g_heff_2ebuild_2ecommands_2eonPathHint_24s1119738011x382523600_str4);
  }
  V v_t_2426;
  if ((heff_unbox_word(heff_strLength_lent(v_sep_2425, 0)) == ((int64_t)0ULL))) {
    heff_drop(v_sep_2425);
    v_t_2426 = heff_tag_n(TAG_Cons, 2, (V[]){v_path_2424, NTAG(TAG_Nil)});
  } else {
    v_t_2426 = ({ V a_0 = v_path_2424; V a_1 = v_sep_2425; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(v_sep_2425, v_path_2424, MK_INT(0LL), 4); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplit_2esplitFrom_240(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_path_2424); heff_drop(v_sep_2425); r_; });
  }
  V v_t_2436 = ({ V a_0 = heff_clo_n(g_heff_2ebuild_2ecommands_2eonPathHint_24s1119738011x382523600_lam4, 1, 2, (V[]){v_st_241, heff_dup(v_bin_242)}); V a_1 = v_t_2426; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_t_2426); r_; });
  if ((heff_dup(v_t_2436) == NTAG(TAG_True))) {
    heff_drop(v_bin_242);
    heff_drop(v_e_240);
    heff_drop(v_hd_243);
    heff_drop(v_t_2436);
    V f_ = v_k_244;
    args[0] = NTAG(TAG_MkUnit);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  } else {
    heff_drop(v_t_2436);
    V v_t_2437 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eonPathHint_24s1119738011x382523600_str7), v_bin_242), ((V)&g_heff_2ebuild_2ecommands_2eonPathHint_24s1119738011x382523600_str8));
    V v_t_2438 = heff_tag_n(TAG_Write, 2, (V[]){heff_strAppend(v_t_2437, ((V)&g_heff_2ebuild_2ecommands_2eonPathHint_24s1119738011x382523600_str9)), NTAG(TAG_MkUnit)});
    V v_t_2439 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2438})});
    V v_t_2440 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2439})});
    V v_t_2441 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2440})});
    V v_t_2442 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2441})});
    V v_t_2443 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2442})});
    V v_t_2444 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2443})});
    return (g_co_2eop_24s310169282x2049378029(v_e_240, heff_tag_n(TAG_InR, 1, (V[]){v_t_2444}), v_hd_243, v_k_244));
  }
}
V g_heff_2ebuild_2ecommands_2eonPathHint_24s1119738011x382523600_lam1(V self, V *args) {
  V v_x_2413 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_hd_243 = heff_env(self)[1];
  V v_st_241 = heff_env(self)[2];
  V v_bin_242 = heff_env(self)[3];
  V v_k_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2415 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_GetEnv, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eonPathHint_24s1119738011x382523600_str0), ((V)&g_heff_2ebuild_2ecommands_2eonPathHint_24s1119738011x382523600_lam2_clo)})});
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
  V v_t_2421 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2420})});
  return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), v_t_2421, heff_dup(v_hd_243), heff_clo_n(g_heff_2ebuild_2ecommands_2eonPathHint_24s1119738011x382523600_lam3, 1, 6, (V[]){v_x_2413, v_st_241, v_bin_242, v_k_244, v_e_240, v_hd_243})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ekeptParts_24s901611701x2116226688_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ekeptParts_24s901611701x2116226688_str1, 1, "_");
V g_heff_2ebuild_2ecommands_2ekeptParts_24s901611701x2116226688_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ekeptParts_24s901611701x2116226688_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ekeptParts_24s901611701x2116226688_lam1, 2, 0};
V g_heff_2ebuild_2ecommands_2ekeptParts_24s901611701x2116226688_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ekeptParts_24s901611701x2116226688_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ekeptParts_24s901611701x2116226688_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ekeptParts_24s901611701x2116226688_entry, 9, 0};

V g_heff_2ebuild_2ecommands_2ekeptParts_24s901611701x2116226688(V v_e_240, V v_bi_241, V v_dir_242, V v_rt_243, V v_c_244, V v_available_245, V v_r_246, V v_hd_247, V v_k_248) {
top: ;
  return (g_heff_2ebuild_2ecommands_2eselfHash_24s1263115327x65083815(heff_dup(v_e_240), heff_dup(heff_rfield(v_bi_241, 0)), heff_dup(v_hd_247), heff_clo_n(g_heff_2ebuild_2ecommands_2ekeptParts_24s901611701x2116226688_lam0, 1, 9, (V[]){v_bi_241, v_e_240, v_hd_247, v_dir_242, v_rt_243, v_c_244, v_available_245, v_r_246, v_k_248})));
}
V g_heff_2ebuild_2ecommands_2ekeptParts_24s901611701x2116226688_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ekeptParts_24s901611701x2116226688(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8]);
}
V g_heff_2ebuild_2ecommands_2ekeptParts_24s901611701x2116226688_lam1(V self, V *args) {
  V v_hd_2410 = args[0];
  V v_k_2411 = args[1];
  heff_drop(v_hd_2410);
  V f_ = v_k_2411;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ekeptParts_24s901611701x2116226688_lam2(V self, V *args) {
  V v_x_2414 = args[0];
  V v_x_249 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_bi_241 = heff_env(self)[2];
  V v_dir_242 = heff_env(self)[3];
  V v_rt_243 = heff_env(self)[4];
  V v_c_244 = heff_env(self)[5];
  V v_available_245 = heff_env(self)[6];
  V v_r_246 = heff_env(self)[7];
  V v_hd_247 = heff_env(self)[8];
  V v_k_248 = heff_env(self)[9];
  heff_clo_take(self, 10);
  V v_t_2415 = (g_heff_2ebuild_2ecommands_2ebacksOf(v_x_249, v_x_2414));
  return ({ V a_0 = v_e_240; V a_1 = v_bi_241; V a_2 = v_dir_242; V a_3 = v_rt_243; V a_4 = v_c_244; V a_5 = v_available_245; V a_6 = v_r_246; V a_7 = v_x_249; V a_8 = v_x_2414; V a_9 = v_t_2415; V a_10 = v_hd_247; V a_11 = v_k_248; V r_ = (g_heff_2ebuild_2ecommands_2ekeptWith_24s2006126946x578363648(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9, a_10, a_11)); heff_drop(v_x_2414); r_; });
}
V g_heff_2ebuild_2ecommands_2ekeptParts_24s901611701x2116226688_lam0(V self, V *args) {
  V v_x_249 = args[0];
  V v_bi_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_hd_247 = heff_env(self)[2];
  V v_dir_242 = heff_env(self)[3];
  V v_rt_243 = heff_env(self)[4];
  V v_c_244 = heff_env(self)[5];
  V v_available_245 = heff_env(self)[6];
  V v_r_246 = heff_env(self)[7];
  V v_k_248 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_c_2413;
  if (heff_strEq_c_lent(v_x_249, ((V)&g_heff_2ebuild_2ecommands_2ekeptParts_24s901611701x2116226688_str0), 2)) {
    v_c_2413 = ((V)&g_heff_2ebuild_2ecommands_2ekeptParts_24s901611701x2116226688_lam1_clo);
  } else {
    V v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ekeptParts_24s901611701x2116226688_str1), heff_dup(heff_rfield(v_bi_241, 2))});
    v_c_2413 = (g_heff_2ebuild_2ecommands_2ereadBacks_24s960701544x1414957442(heff_dup(v_e_240), heff_dup(heff_rfield(v_bi_241, 0)), v_t_2412));
  }
  V f_ = v_c_2413;
  heff_room[0] = heff_dup(v_hd_247);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ekeptParts_24s901611701x2116226688_lam2, 1, 10, (V[]){v_x_249, v_e_240, v_bi_241, v_dir_242, v_rt_243, v_c_244, v_available_245, v_r_246, v_hd_247, v_k_248});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}