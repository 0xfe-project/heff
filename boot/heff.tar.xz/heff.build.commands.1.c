// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Complete 48856
#define TAG_End 17255
#define TAG_Exit 20279
#define TAG_Left 13886
#define TAG_MkDir 57961
#define TAG_Platform 55558
#define TAG_Posix 44191
#define TAG_ProgramPath 46819
#define TAG_ReadFile 6783
#define TAG_ReadOnly 17623
#define TAG_Remove 9747
#define TAG_Right 62770
#define TAG_Run 29975
#define TAG_Start 63542
#define TAG_Windows 49101
#define TAG_Write 36323
#define TAG_WriteErr 37283
#define TAG_WriteFile 62589
#define LBL_absolute 325777132
#define LBL_apps 9496377
#define LBL_bad 306815
#define LBL_bin 307073
#define LBL_copies 592412158
#define LBL_discarded 1490202606
#define LBL_drive 297211300
#define LBL_emits 297985818
#define LBL_err 310239
#define LBL_errors 652506774
#define LBL_failed 665164648
#define LBL_failure 1292767177
#define LBL_groups 709681407
#define LBL_jss 315076
#define LBL_labels 836724522
#define LBL_mods 9852536
#define LBL_module 878357911
#define LBL_modules 1459291593
#define LBL_notes 306367195
#define LBL_ok 10307
#define LBL_olds 9909235
#define LBL_opt 319789
#define LBL_out 319944
#define LBL_pages 307784670
#define LBL_parts 307795706
#define LBL_path 9928940
#define LBL_paths 307797256
#define LBL_root 10001833
#define LBL_runs 10007567
#define LBL_said 10017968
#define LBL_segments 1801007612
#define LBL_shipTo 1043811586
#define LBL_ships 310766033
#define LBL_status 1054660381
#define LBL_style 311138763
#define LBL_tests 311609915
#define LBL_testsFailed 1062135101
#define LBL_total 311908190
#define LBL_unchecked 1931098040
static uint32_t shape_apps__bad[] = {LBL_apps, LBL_bad};
static uint32_t shape_drive__absolute__segments[] = {LBL_drive, LBL_absolute, LBL_segments};
static uint32_t shape_groups__copies__emits__jss[] = {LBL_groups, LBL_copies, LBL_emits, LBL_jss};
static uint32_t shape_mods__olds[] = {LBL_mods, LBL_olds};
static uint32_t shape_root__bin__said__pages__shipTo__opt[] = {LBL_root, LBL_bin, LBL_said, LBL_pages, LBL_shipTo, LBL_opt};
V g_co_2eop_24s1084803226x1249263831(V, V, V);
V g_co_2eop_24s1084803226x1249263831_entry(V self, V *a);
extern Clo g_co_2eop_24s1084803226x1249263831_clo;
V g_co_2eop_24s954557541x749476273(V, V, V);
V g_co_2eop_24s954557541x749476273_entry(V self, V *a);
extern Clo g_co_2eop_24s954557541x749476273_clo;
V g_heff_2ebuild_2ebackcache_2ebackDir_get(void);
V g_heff_2ebuild_2ebackcache_2ebackTexts(V, V, V);
V g_heff_2ebuild_2ebackcache_2ebackTexts_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebackcache_2ebackTexts_clo;
V g_heff_2ebuild_2ecommands_2eaddRes(V, V);
V g_heff_2ebuild_2ecommands_2eaddRes_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eaddRes_clo;
V g_heff_2ebuild_2ecommands_2eappFile(V, V, V, V);
V g_heff_2ebuild_2ecommands_2eappFile_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eappFile_clo;
V g_heff_2ebuild_2ecommands_2eappRead_24s565652333x1470992278(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eappRead_24s565652333x1470992278_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eappRead_24s565652333x1470992278_clo;
V g_heff_2ebuild_2ecommands_2eappShips_24s494931198x1067141729(V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eappShips_24s494931198x1067141729_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eappShips_24s494931198x1067141729_clo;
V g_heff_2ebuild_2ecommands_2eappsIn_24s1533067604x1981180975(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eappsIn_24s1533067604x1981180975_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eappsIn_24s1533067604x1981180975_clo;
V g_heff_2ebuild_2ecommands_2ebackDirOf(V);
V g_heff_2ebuild_2ecommands_2ebackDirOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ebackDirOf_clo;
V g_heff_2ebuild_2ecommands_2ebuildTarget(V, V);
V g_heff_2ebuild_2ecommands_2ebuildTarget_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ebuildTarget_clo;
V g_heff_2ebuild_2ecommands_2efailLines(V, V);
V g_heff_2ebuild_2ecommands_2efailLines_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2efailLines_clo;
V g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957(V, V, V);
V g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_clo;
V g_heff_2ebuild_2ecommands_2efilesSaid(V);
V g_heff_2ebuild_2ecommands_2efilesSaid_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2efilesSaid_clo;
V g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_get(void);
V g_heff_2ebuild_2ecommands_2egetCmd_24s1824733856x1503967101(V, V, V);
V g_heff_2ebuild_2ecommands_2egetCmd_24s1824733856x1503967101_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2egetCmd_24s1824733856x1503967101_clo;
V g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246_clo;
V g_heff_2ebuild_2ecommands_2eheffVersions(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eheffVersions_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eheffVersions_clo;
V g_heff_2ebuild_2ecommands_2ehostNow_24s1524073894x1314263325(V, V);
V g_heff_2ebuild_2ecommands_2ehostNow_24s1524073894x1314263325_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ehostNow_24s1524073894x1314263325_clo;
V g_heff_2ebuild_2ecommands_2ekeptWritten_24s1884000495x2131386180(V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ekeptWritten_24s1884000495x2131386180_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ekeptWritten_24s1884000495x2131386180_clo;
V g_heff_2ebuild_2ecommands_2enewestTag_24s53038353x309194843(V, V, V);
V g_heff_2ebuild_2ecommands_2enewestTag_24s53038353x309194843_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2enewestTag_24s53038353x309194843_clo;
V g_heff_2ebuild_2ecommands_2enotInProject_24s327269570x1050569655(V, V, V);
V g_heff_2ebuild_2ecommands_2enotInProject_24s327269570x1050569655_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2enotInProject_24s327269570x1050569655_clo;
V g_heff_2ebuild_2ecommands_2eoutcomeLine(V);
V g_heff_2ebuild_2ecommands_2eoutcomeLine_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eoutcomeLine_clo;
V g_heff_2ebuild_2ecommands_2eownPackage_24s759818713x2101508697(V, V);
V g_heff_2ebuild_2ecommands_2eownPackage_24s759818713x2101508697_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eownPackage_24s759818713x2101508697_clo;
V g_heff_2ebuild_2ecommands_2eownRoot(V, V);
V g_heff_2ebuild_2ecommands_2eownRoot_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eownRoot_clo;
V g_heff_2ebuild_2ecommands_2epathOfModule(V, V);
V g_heff_2ebuild_2ecommands_2epathOfModule_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2epathOfModule_clo;
V g_heff_2ebuild_2ecommands_2eprintLines_24s1020531090x2086937737(V, V, V);
V g_heff_2ebuild_2ecommands_2eprintLines_24s1020531090x2086937737_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprintLines_24s1020531090x2086937737_clo;
V g_heff_2ebuild_2ecommands_2eprintOutcomes_24s684981677x530430275(V, V);
V g_heff_2ebuild_2ecommands_2eprintOutcomes_24s684981677x530430275_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprintOutcomes_24s684981677x530430275_clo;
V g_heff_2ebuild_2ecommands_2epublishTag_24s229598417x236103835(V, V, V, V);
V g_heff_2ebuild_2ecommands_2epublishTag_24s229598417x236103835_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2epublishTag_24s229598417x236103835_clo;
V g_heff_2ebuild_2ecommands_2epublishTested_24s2067279794x684806743(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2epublishTested_24s2067279794x684806743_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2epublishTested_24s2067279794x684806743_clo;
V g_heff_2ebuild_2ecommands_2erunDir(V);
V g_heff_2ebuild_2ecommands_2erunDir_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2erunDir_clo;
V g_heff_2ebuild_2ecommands_2estatistic(V);
V g_heff_2ebuild_2ecommands_2estatistic_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2estatistic_clo;
V g_heff_2ebuild_2ecommands_2etestCmd_24s1861054559x1051560230(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2etestCmd_24s1861054559x1051560230_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2etestCmd_24s1861054559x1051560230_clo;
V g_heff_2ebuild_2ecommands_2etestOneF_24s1353895353x878524806(V, V, V, V);
V g_heff_2ebuild_2ecommands_2etestOneF_24s1353895353x878524806_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2etestOneF_24s1353895353x878524806_clo;
V g_heff_2ebuild_2ecommands_2ewriteBacks_24s1642553849x1460541962(V, V, V);
V g_heff_2ebuild_2ecommands_2ewriteBacks_24s1642553849x1460541962_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ewriteBacks_24s1642553849x1460541962_clo;
V g_heff_2ebuild_2ecommands_2ewriteParts_24s2007547047x1883297068(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ewriteParts_24s2007547047x1883297068_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ewriteParts_24s2007547047x1883297068_clo;
V g_heff_2ebuild_2eload_2ecachedDir(V, V, V);
V g_heff_2ebuild_2eload_2ecachedDir_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2ecachedDir_clo;
V g_heff_2ebuild_2eload_2epathsFor_24s1509642847x2084081176(V, V);
V g_heff_2ebuild_2eload_2epathsFor_24s1509642847x2084081176_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2epathsFor_24s1509642847x2084081176_clo;
V g_heff_2ebuild_2eload_2eproblemMsg(V, V, V);
V g_heff_2ebuild_2eload_2eproblemMsg_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eproblemMsg_clo;
V g_heff_2ebuild_2eload_2eunder(V, V, V);
V g_heff_2ebuild_2eload_2eunder_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eunder_clo;
V g_heff_2ebuild_2eproject_2ecompatible(V, V);
V g_heff_2ebuild_2eproject_2ecompatible_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2ecompatible_clo;
V g_heff_2ebuild_2eproject_2eheffModule_get(void);
V g_heff_2ebuild_2eproject_2epackageLit(V);
V g_heff_2ebuild_2eproject_2epackageLit_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2epackageLit_clo;
V g_heff_2ebuild_2eproject_2epackageOf(V);
V g_heff_2ebuild_2eproject_2epackageOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2epackageOf_clo;
V g_heff_2ebuild_2eproject_2ereadBuild(V);
V g_heff_2ebuild_2eproject_2ereadBuild_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2ereadBuild_clo;
V g_heff_2ebuild_2eproject_2erepoOf(V);
V g_heff_2ebuild_2eproject_2erepoOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2erepoOf_clo;
V g_heff_2ebuild_2eproject_2erequireMsg_get(void);
V g_heff_2ebuild_2eproject_2eversion(V);
V g_heff_2ebuild_2eproject_2eversion_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2eversion_clo;
V g_list_2edrop(V, V);
V g_list_2edrop_entry(V self, V *a);
extern Clo g_list_2edrop_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s2040448920x1981923787(V, V);
V g_list_2efoldl_24s2040448920x1981923787_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2040448920x1981923787_clo;
V g_list_2efoldl_24s657006386x1833506039(V, V);
V g_list_2efoldl_24s657006386x1833506039_entry(V self, V *a);
extern Clo g_list_2efoldl_24s657006386x1833506039_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1367796012x2117543847(V, V);
V g_list_2emap_24s1367796012x2117543847_entry(V self, V *a);
extern Clo g_list_2emap_24s1367796012x2117543847_clo;
V g_map_2eempty_get(void);
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2eskipSpaces(V, V, V);
V g_prelude_2eskipSpaces_entry(V self, V *a);
extern Clo g_prelude_2eskipSpaces_clo;
V g_prelude_2esplitFrom(V, V, V, V);
V g_prelude_2esplitFrom_entry(V self, V *a);
extern Clo g_prelude_2esplitFrom_clo;
V g_std_2epath_2ecollapse(V, V);
V g_std_2epath_2ecollapse_entry(V self, V *a);
extern Clo g_std_2epath_2ecollapse_clo;
V g_std_2epath_2ejoin_2eonto_240(V, V);
V g_std_2epath_2ejoin_2eonto_240_entry(V self, V *a);
extern Clo g_std_2epath_2ejoin_2eonto_240_clo;
V g_std_2epath_2eparse(V, V);
V g_std_2epath_2eparse_entry(V self, V *a);
extern Clo g_std_2epath_2eparse_clo;
V g_std_2epath_2erender(V, V);
V g_std_2epath_2erender_entry(V self, V *a);
extern Clo g_std_2epath_2erender_clo;
V g_std_2eprogress_2eroot_get(void);
HEFF_LIT(g_heff_2ebuild_2ecommands_2eownRoot_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eownRoot_str1, 3, "out");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eownRoot_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eownRoot_str3, 5, ".heff");
Clo g_heff_2ebuild_2ecommands_2eownRoot_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eownRoot_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2eownRoot(V v_st_240, V v_self_241) {
top: ;
  V v_p_242 = (g_std_2epath_2eparse(v_st_240, heff_dup(v_self_241)));
  V v_t_243 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_p_242, 2)));
  V v_xs_244 = (g_list_2edrop(MK_INT(1LL), v_t_243));
  V v_t_245 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_244));
  V v_t_246 = ({ V rv_2 = v_t_245; V rr_ = heff_rec_reuse_nf(v_p_242, 3ULL, 3, shape_drive__absolute__segments, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
  V v_s_247 = (g_std_2epath_2erender(v_st_240, v_t_246));
  V v_t_248 = (g_std_2epath_2eparse(v_st_240, v_s_247));
  V v_xs_249 = heff_get_n(v_t_248, 2, 3);
  V v_x1_2410 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_249));
  V v_x2_2413;
  switch (heff_tag_of(v_x1_2410)) {
  case TAG_Nil: {
    v_x2_2413 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Cons: {
    V v_x_2411 = heff_field(v_x1_2410, 0);
    heff_take_n(v_x1_2410, 1ULL, 2);
    v_x2_2413 = heff_tag_n(TAG_Just, 1, (V[]){v_x_2411});
    break;
  }
  default: heff_nomatch(v_x1_2410);
  }
  V v_t_2415;
  switch (heff_tag_of(v_x2_2413)) {
  case TAG_Nothing: {
    v_t_2415 = ((V)&g_heff_2ebuild_2ecommands_2eownRoot_str0);
    break;
  }
  case TAG_Just: {
    V v_x_2414 = heff_field(v_x2_2413, 0);
    heff_take_n(v_x2_2413, 1ULL, 1);
    v_t_2415 = v_x_2414;
    break;
  }
  default: heff_nomatch(v_x2_2413);
  }
  V v_t_2437;
  if (heff_strEq_c(v_t_2415, ((V)&g_heff_2ebuild_2ecommands_2eownRoot_str1))) {
    V v_p_2417 = (g_std_2epath_2eparse(v_st_240, heff_dup(v_self_241)));
    V v_t_2418 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_p_2417, 2)));
    V v_xs_2419 = (g_list_2edrop(MK_INT(1LL), v_t_2418));
    V v_t_2420 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2419));
    V v_t_2421 = ({ V rv_2 = v_t_2420; V rr_ = heff_rec_reuse_nf(v_p_2417, 3ULL, 3, shape_drive__absolute__segments, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    V v_s_2422 = (g_std_2epath_2erender(v_st_240, v_t_2421));
    V v_p_2423 = (g_std_2epath_2eparse(v_st_240, v_s_2422));
    V v_t_2424 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_p_2423, 2)));
    V v_xs_2425 = (g_list_2edrop(MK_INT(1LL), v_t_2424));
    V v_t_2426 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2425));
    V v_t_2427 = ({ V rv_2 = v_t_2426; V rr_ = heff_rec_reuse_nf(v_p_2423, 3ULL, 3, shape_drive__absolute__segments, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    V v_s_2428 = (g_std_2epath_2erender(v_st_240, v_t_2427));
    V v_t_2429 = (g_std_2epath_2eparse(v_st_240, v_s_2428));
    V v_xs_2430 = heff_get_n(v_t_2429, 2, 3);
    V v_x1_2431 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2430));
    V v_x2_2434;
    switch (heff_tag_of(v_x1_2431)) {
    case TAG_Nil: {
      v_x2_2434 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Cons: {
      V v_x_2432 = heff_field(v_x1_2431, 0);
      heff_take_n(v_x1_2431, 1ULL, 2);
      v_x2_2434 = heff_tag_n(TAG_Just, 1, (V[]){v_x_2432});
      break;
    }
    default: heff_nomatch(v_x1_2431);
    }
    V v_t_2436;
    switch (heff_tag_of(v_x2_2434)) {
    case TAG_Nothing: {
      v_t_2436 = ((V)&g_heff_2ebuild_2ecommands_2eownRoot_str2);
      break;
    }
    case TAG_Just: {
      V v_x_2435 = heff_field(v_x2_2434, 0);
      heff_take_n(v_x2_2434, 1ULL, 1);
      v_t_2436 = v_x_2435;
      break;
    }
    default: heff_nomatch(v_x2_2434);
    }
    v_t_2437 = heff_strEq(v_t_2436, ((V)&g_heff_2ebuild_2ecommands_2eownRoot_str3));
  } else {
    v_t_2437 = NTAG(TAG_False);
  }
  if ((heff_dup(v_t_2437) == NTAG(TAG_True))) {
    heff_drop(v_t_2437);
    V v_p_2438 = (g_std_2epath_2eparse(v_st_240, v_self_241));
    V v_t_2439 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_p_2438, 2)));
    V v_xs_2440 = (g_list_2edrop(MK_INT(1LL), v_t_2439));
    V v_t_2441 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2440));
    V v_t_2442 = ({ V rv_2 = v_t_2441; V rr_ = heff_rec_reuse_nf(v_p_2438, 3ULL, 3, shape_drive__absolute__segments, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    V v_s_2443 = (g_std_2epath_2erender(v_st_240, v_t_2442));
    V v_p_2444 = (g_std_2epath_2eparse(v_st_240, v_s_2443));
    V v_t_2445 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_p_2444, 2)));
    V v_xs_2446 = (g_list_2edrop(MK_INT(1LL), v_t_2445));
    V v_t_2447 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2446));
    V v_t_2448 = ({ V rv_2 = v_t_2447; V rr_ = heff_rec_reuse_nf(v_p_2444, 3ULL, 3, shape_drive__absolute__segments, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    V v_s_2449 = (g_std_2epath_2erender(v_st_240, v_t_2448));
    V v_p_2450 = (g_std_2epath_2eparse(v_st_240, v_s_2449));
    V v_t_2451 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_p_2450, 2)));
    V v_xs_2452 = (g_list_2edrop(MK_INT(1LL), v_t_2451));
    V v_t_2453 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2452));
    V v_t_2454 = ({ V rv_2 = v_t_2453; V rr_ = heff_rec_reuse_nf(v_p_2450, 3ULL, 3, shape_drive__absolute__segments, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    HEFF_LAST return g_std_2epath_2erender(v_st_240, v_t_2454);
  } else {
    heff_drop(v_t_2437);
    V v_p_2455 = (g_std_2epath_2eparse(v_st_240, v_self_241));
    V v_t_2456 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_p_2455, 2)));
    V v_xs_2457 = (g_list_2edrop(MK_INT(1LL), v_t_2456));
    V v_t_2458 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2457));
    V v_t_2459 = ({ V rv_2 = v_t_2458; V rr_ = heff_rec_reuse_nf(v_p_2455, 3ULL, 3, shape_drive__absolute__segments, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    V v_s_2460 = (g_std_2epath_2erender(v_st_240, v_t_2459));
    V v_p_2461 = (g_std_2epath_2eparse(v_st_240, v_s_2460));
    V v_t_2462 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_p_2461, 2)));
    V v_xs_2463 = (g_list_2edrop(MK_INT(1LL), v_t_2462));
    V v_t_2464 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2463));
    V v_t_2465 = ({ V rv_2 = v_t_2464; V rr_ = heff_rec_reuse_nf(v_p_2461, 3ULL, 3, shape_drive__absolute__segments, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    HEFF_LAST return g_std_2epath_2erender(v_st_240, v_t_2465);
  }
}
V g_heff_2ebuild_2ecommands_2eownRoot_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2eownRoot(a0, a[1]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eheffVersions_str0, 2, "0.");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eheffVersions_str1, 15, " (the same 0.x)");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eheffVersions_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eheffVersions_str3, 19, ", and this heff is ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eheffVersions_str4, 13, " is for heff ");
Clo g_heff_2ebuild_2ecommands_2eheffVersions_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eheffVersions_entry, 5, 0};

V g_heff_2ebuild_2ecommands_2eheffVersions(V v_who_240, V v_wanted_241, V v_running_242, V v_x4_243, V v_x5_244) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nothing: {
    heff_drop(v_who_240);
    heff_drop(v_wanted_241);
    heff_drop(v_running_242);
    heff_drop(v_x5_244);
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_w_245 = heff_field(v_x4_243, 0);
    V v_ru_24x4_243_24Just = heff_take_reuse_n(v_x4_243, 1ULL, 1);
    switch (heff_tag_of(v_x5_244)) {
    case TAG_Nothing: {
      heff_drop(v_who_240);
      heff_drop(v_wanted_241);
      heff_drop(v_running_242);
      heff_drop(v_w_245);
      heff_drop_cell(v_ru_24x4_243_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_Just: {
      V v_r_246 = heff_field(v_x5_244, 0);
      heff_take_n(v_x5_244, 1ULL, 1);
      V v_t_247 = ({ V a_0 = v_w_245; V a_1 = v_r_246; V r_ = (g_heff_2ebuild_2eproject_2ecompatible(a_0, a_1)); heff_drop(v_w_245); heff_drop(v_r_246); r_; });
      if ((heff_dup(v_t_247) == NTAG(TAG_True))) {
        heff_drop(v_who_240);
        heff_drop(v_wanted_241);
        heff_drop(v_running_242);
        heff_drop_cell(v_ru_24x4_243_24Just, 1);
        heff_drop(v_t_247);
        return NTAG(TAG_Nothing);
      } else {
        heff_drop(v_t_247);
        V v_t_249;
        if (heff_strEq_c(heff_strSlice(heff_dup(v_wanted_241), MK_INT(0LL), MK_INT(2LL)), ((V)&g_heff_2ebuild_2ecommands_2eheffVersions_str0))) {
          v_t_249 = ((V)&g_heff_2ebuild_2ecommands_2eheffVersions_str1);
        } else {
          v_t_249 = ((V)&g_heff_2ebuild_2ecommands_2eheffVersions_str2);
        }
        V v_t_2410 = heff_strAppend(v_t_249, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eheffVersions_str3), v_running_242));
        V v_t_2411 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eheffVersions_str4), heff_strAppend(v_wanted_241, v_t_2410));
        return heff_tag_at_n(v_ru_24x4_243_24Just, TAG_Just, 1, (V[]){heff_strAppend(v_who_240, v_t_2411)});
      }
    }
    default: return heff_nomatch(v_x5_244);
    }
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2ebuild_2ecommands_2eheffVersions_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eheffVersions(a[0], a[1], a[2], a[3], a[4]);
}
Clo g_heff_2ebuild_2ecommands_2epathOfModule_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2epathOfModule_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2epathOfModule(V v_x1_240, V v_m_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_m_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_s_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    if (heff_strEq_c(heff_dup(heff_rfield(v_s_242, 0)), heff_dup(v_m_241))) {
      heff_drop(v_m_241);
      return heff_tag_n(TAG_Just, 1, (V[]){heff_dup(heff_rfield(v_s_242, 1))});
    } else {
      V t_0 = v_rest_243;
      V t_1 = v_m_241;
      v_x1_240 = t_0;
      v_m_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2ecommands_2epathOfModule_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2epathOfModule(a0, a[1]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebackDirOf_str0, 5, ".heff");
Clo g_heff_2ebuild_2ecommands_2ebackDirOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebackDirOf_entry, 1, 0};

V g_heff_2ebuild_2ecommands_2ebackDirOf(V v_ps_240) {
top: ;
  V v_st_241 = heff_dup(heff_rfield(v_ps_240, 5));
  V v_t_242 = (g_std_2epath_2eparse(v_st_241, heff_dup(heff_rfield(v_ps_240, 0))));
  V v_t_243 = (g_std_2epath_2eparse(v_st_241, ((V)&g_heff_2ebuild_2ecommands_2ebackDirOf_str0)));
  V v_p_244 = (g_std_2epath_2ejoin_2eonto_240(v_t_242, v_t_243));
  V v_t_245 = (g_std_2epath_2ecollapse(heff_dup(heff_rfield(v_p_244, 1)), heff_rfield(v_p_244, 2)));
  V v_t_246 = ({ V rv_2 = v_t_245; V rr_ = heff_rec_reuse_nf(v_p_244, 3ULL, 3, shape_drive__absolute__segments, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
  V v_t_247 = ({ V a_0 = v_st_241; V a_1 = v_t_246; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_241); r_; });
  return (g_heff_2ebuild_2eload_2eunder(v_ps_240, v_t_247, heff_dup(g_heff_2ebuild_2ebackcache_2ebackDir_get())));
}
V g_heff_2ebuild_2ecommands_2ebackDirOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ebackDirOf(a[0]);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2erunDir_str0, 9, ".heff/run");
Clo g_heff_2ebuild_2ecommands_2erunDir_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2erunDir_entry, 1, 0};

V g_heff_2ebuild_2ecommands_2erunDir(V v_paths_240) {
top: ;
  V v_st_241 = heff_take_field(v_paths_240, 5);
  V v_t_242 = (g_std_2epath_2eparse(v_st_241, heff_get_n(v_paths_240, 0, 6)));
  V v_t_243 = (g_std_2epath_2eparse(v_st_241, ((V)&g_heff_2ebuild_2ecommands_2erunDir_str0)));
  V v_p_244 = (g_std_2epath_2ejoin_2eonto_240(v_t_242, v_t_243));
  V v_t_245 = (g_std_2epath_2ecollapse(heff_dup(heff_rfield(v_p_244, 1)), heff_rfield(v_p_244, 2)));
  V v_t_246 = ({ V rv_2 = v_t_245; V rr_ = heff_rec_reuse_nf(v_p_244, 3ULL, 3, shape_drive__absolute__segments, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
  return ({ V a_0 = v_st_241; V a_1 = v_t_246; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_241); r_; });
}
V g_heff_2ebuild_2ecommands_2erunDir_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2erunDir(a[0]);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildTarget_str0, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildTarget_str1, 3, "bin");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildTarget_str2, 5, "wrote");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildTarget_str3, 3, "-O1");
Clo g_heff_2ebuild_2ecommands_2ebuildTarget_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildTarget_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2ebuildTarget(V v_st_240, V v_root_241) {
top: ;
  V v_t_242 = (g_std_2epath_2eparse(v_st_240, ((V)&g_heff_2ebuild_2ecommands_2ebuildTarget_str0)));
  V v_t_243 = (g_std_2epath_2eparse(v_st_240, ((V)&g_heff_2ebuild_2ecommands_2ebuildTarget_str1)));
  V v_p_244 = (g_std_2epath_2ejoin_2eonto_240(v_t_242, v_t_243));
  V v_t_245 = (g_std_2epath_2ecollapse(heff_dup(heff_rfield(v_p_244, 1)), heff_rfield(v_p_244, 2)));
  V v_t_246 = ({ V rv_2 = v_t_245; V rr_ = heff_rec_reuse_nf(v_p_244, 3ULL, 3, shape_drive__absolute__segments, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
  V v_b_247 = (g_std_2epath_2erender(v_st_240, v_t_246));
  V v_t_248 = (g_std_2epath_2eparse(v_st_240, heff_dup(v_root_241)));
  V v_t_249 = (g_std_2epath_2eparse(v_st_240, v_b_247));
  V v_p_2410 = (g_std_2epath_2ejoin_2eonto_240(v_t_248, v_t_249));
  V v_t_2411 = (g_std_2epath_2ecollapse(heff_dup(heff_rfield(v_p_2410, 1)), heff_rfield(v_p_2410, 2)));
  V v_t_2412 = ({ V rv_2 = v_t_2411; V rr_ = heff_rec_reuse_nf(v_p_2410, 3ULL, 3, shape_drive__absolute__segments, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
  V v_t_2413 = (g_std_2epath_2erender(v_st_240, v_t_2412));
  return heff_rec_n(6, shape_root__bin__said__pages__shipTo__opt, (V[]){v_root_241, v_t_2413, ((V)&g_heff_2ebuild_2ecommands_2ebuildTarget_str2), NTAG(TAG_True), NTAG(TAG_Nothing), ((V)&g_heff_2ebuild_2ecommands_2ebuildTarget_str3)});
}
V g_heff_2ebuild_2ecommands_2ebuildTarget_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2ebuildTarget(a0, a[1]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eappFile_str0, 3, "app");
Clo g_heff_2ebuild_2ecommands_2eappFile_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eappFile_entry, 4, 0};

V g_heff_2ebuild_2ecommands_2eappFile(V v_st_240, V v_t_241, V v_x_242, V v_f_243) {
top: ;
  V v_t_244 = (g_std_2epath_2eparse(v_st_240, ((V)&g_heff_2ebuild_2ecommands_2eappFile_str0)));
  V v_t_245 = (g_std_2epath_2eparse(v_st_240, v_x_242));
  V v_p_246 = (g_std_2epath_2ejoin_2eonto_240(v_t_244, v_t_245));
  V v_t_247 = (g_std_2epath_2ecollapse(heff_dup(heff_rfield(v_p_246, 1)), heff_rfield(v_p_246, 2)));
  V v_t_248 = ({ V rv_2 = v_t_247; V rr_ = heff_rec_reuse_nf(v_p_246, 3ULL, 3, shape_drive__absolute__segments, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
  V v_a_249 = (g_std_2epath_2erender(v_st_240, v_t_248));
  V v_t_2410 = (g_std_2epath_2eparse(v_st_240, v_a_249));
  V v_t_2411 = (g_std_2epath_2eparse(v_st_240, v_f_243));
  V v_p_2412 = (g_std_2epath_2ejoin_2eonto_240(v_t_2410, v_t_2411));
  V v_t_2413 = (g_std_2epath_2ecollapse(heff_dup(heff_rfield(v_p_2412, 1)), heff_rfield(v_p_2412, 2)));
  V v_t_2414 = ({ V rv_2 = v_t_2413; V rr_ = heff_rec_reuse_nf(v_p_2412, 3ULL, 3, shape_drive__absolute__segments, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
  V v_p_2415 = (g_std_2epath_2erender(v_st_240, v_t_2414));
  V v_t_2416 = (g_std_2epath_2eparse(v_st_240, heff_get_n(v_t_241, 0, 6)));
  V v_t_2417 = (g_std_2epath_2eparse(v_st_240, v_p_2415));
  V v_p_2418 = (g_std_2epath_2ejoin_2eonto_240(v_t_2416, v_t_2417));
  V v_t_2419 = (g_std_2epath_2ecollapse(heff_dup(heff_rfield(v_p_2418, 1)), heff_rfield(v_p_2418, 2)));
  V v_t_2420 = ({ V rv_2 = v_t_2419; V rr_ = heff_rec_reuse_nf(v_p_2418, 3ULL, 3, shape_drive__absolute__segments, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
  return (g_std_2epath_2erender(v_st_240, v_t_2420));
}
V g_heff_2ebuild_2ecommands_2eappFile_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2eappFile(a0, a[1], a[2], a[3]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2estatistic_str0, 2, ", ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2estatistic_str1, 12, " given up on");
HEFF_LIT(g_heff_2ebuild_2ecommands_2estatistic_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2estatistic_str3, 1, "%");
HEFF_LIT(g_heff_2ebuild_2ecommands_2estatistic_str4, 1, " ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2estatistic_str5, 2, ", ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2estatistic_str6, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2estatistic_str7, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2estatistic_str8, 5, " runs");
V g_heff_2ebuild_2ecommands_2estatistic_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2estatistic_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2estatistic_entry, 1, 0};

V g_heff_2ebuild_2ecommands_2estatistic(V v_o_240) {
top: ;
  V v_t_241 = heff_intShow(heff_dup(heff_rfield(v_o_240, 3)));
  V v_t_244;
  if (heff_intLt_c(MK_INT(0LL), heff_dup(heff_rfield(v_o_240, 4)))) {
    V v_t_243 = heff_intShow(heff_dup(heff_rfield(v_o_240, 4)));
    v_t_244 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2estatistic_str0), heff_strAppend(v_t_243, ((V)&g_heff_2ebuild_2ecommands_2estatistic_str1)));
  } else {
    v_t_244 = ((V)&g_heff_2ebuild_2ecommands_2estatistic_str2);
  }
  V v_x2_2417 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2ecommands_2estatistic_lam0, 1, 1, (V[]){heff_dup(v_o_240)}), heff_get_n(v_o_240, 6, 10)));
  V v_t_2420;
  switch (heff_tag_of(v_x2_2417)) {
  case TAG_Nil: {
    v_t_2420 = ((V)&g_heff_2ebuild_2ecommands_2estatistic_str6);
    break;
  }
  case TAG_Cons: {
    V v_x_2418 = heff_field(v_x2_2417, 0);
    V v_xs_2419 = heff_field(v_x2_2417, 1);
    heff_take_n(v_x2_2417, 3ULL, 2);
    v_t_2420 = ({ V a_0 = ((V)&g_heff_2ebuild_2ecommands_2estatistic_str7); V a_1 = v_x_2418; V a_2 = v_xs_2419; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2419); r_; });
    break;
  }
  default: heff_nomatch(v_x2_2417);
  }
  V v_t_2421 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2estatistic_str8), heff_strAppend(v_t_244, v_t_2420));
  return heff_strAppend(v_t_241, v_t_2421);
}
V g_heff_2ebuild_2ecommands_2estatistic_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2estatistic(a[0]);
}
V g_heff_2ebuild_2ecommands_2estatistic_lam0(V self, V *args) {
  V v_p_245 = args[0];
  V v_o_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_n_248;
  switch (heff_tag_of(v_p_245)) {
  case TAG_MkPair: {
    V v_y_247 = heff_dup(heff_field(v_p_245, 1));
    v_n_248 = v_y_247;
    break;
  }
  default: heff_nomatch(v_p_245);
  }
  V v_total_249 = heff_get_n(v_o_240, 3, 10);
  V v_t_2411;
  if (heff_intEq_c(heff_dup(v_total_249), MK_INT(0LL))) {
    heff_drop(v_n_248);
    heff_drop(v_total_249);
    v_t_2411 = MK_INT(0LL);
  } else {
    v_t_2411 = heff_intDiv(heff_intMul(v_n_248, MK_INT(100LL)), v_total_249);
  }
  V v_t_2412 = heff_strAppend(heff_intShow(v_t_2411), ((V)&g_heff_2ebuild_2ecommands_2estatistic_str3));
  V v_t_2415;
  switch (heff_tag_of(v_p_245)) {
  case TAG_MkPair: {
    V v_x_2413 = heff_field(v_p_245, 0);
    heff_take_n(v_p_245, 1ULL, 2);
    v_t_2415 = v_x_2413;
    break;
  }
  default: heff_nomatch(v_p_245);
  }
  V v_t_2416 = heff_strAppend(v_t_2412, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2estatistic_str4), v_t_2415));
  return heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2estatistic_str5), v_t_2416);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eownPackage_24s759818713x2101508697_str0, 5, "win32");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eownPackage_24s759818713x2101508697_str1, 10, "package.hf");
V g_heff_2ebuild_2ecommands_2eownPackage_24s759818713x2101508697_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eownPackage_24s759818713x2101508697_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eownPackage_24s759818713x2101508697_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2eownPackage_24s759818713x2101508697_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eownPackage_24s759818713x2101508697_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eownPackage_24s759818713x2101508697_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2eownPackage_24s759818713x2101508697_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2eownPackage_24s759818713x2101508697_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eownPackage_24s759818713x2101508697_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eownPackage_24s759818713x2101508697_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2eownPackage_24s759818713x2101508697(V v_hd_240, V v_k_241) {
top: ;
  V v_t_243 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2eownPackage_24s759818713x2101508697_lam0_clo)})});
  V v_t_244 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_243})});
  V v_t_245 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_244})});
  return (g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InR, 1, (V[]){v_t_245}), heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2ecommands_2eownPackage_24s759818713x2101508697_lam1, 1, 2, (V[]){v_hd_240, v_k_241})));
}
V g_heff_2ebuild_2ecommands_2eownPackage_24s759818713x2101508697_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eownPackage_24s759818713x2101508697(a[0], a[1]);
}
V g_heff_2ebuild_2ecommands_2eownPackage_24s759818713x2101508697_lam0(V self, V *args) {
  V v_s_242 = args[0];
  return v_s_242;
}
V g_heff_2ebuild_2ecommands_2eownPackage_24s759818713x2101508697_lam2(V self, V *args) {
  V v_s_249 = args[0];
  return v_s_249;
}
V g_heff_2ebuild_2ecommands_2eownPackage_24s759818713x2101508697_lam3(V self, V *args) {
  V v_x_2413 = args[0];
  V v_x_248 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_a_2414 = (g_heff_2ebuild_2ecommands_2eownRoot(v_x_248, v_x_2413));
  V v_t_2415 = (g_std_2epath_2eparse(v_x_248, v_a_2414));
  V v_t_2416 = (g_std_2epath_2eparse(v_x_248, ((V)&g_heff_2ebuild_2ecommands_2eownPackage_24s759818713x2101508697_str1)));
  V v_p_2417 = (g_std_2epath_2ejoin_2eonto_240(v_t_2415, v_t_2416));
  V v_t_2418 = (g_std_2epath_2ecollapse(heff_dup(heff_rfield(v_p_2417, 1)), heff_rfield(v_p_2417, 2)));
  V v_t_2419 = ({ V rv_2 = v_t_2418; V rr_ = heff_rec_reuse_nf(v_p_2417, 3ULL, 3, shape_drive__absolute__segments, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
  V v_x_2420 = ({ V a_0 = v_x_248; V a_1 = v_t_2419; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_x_248); r_; });
  V f_ = v_k_241;
  args[0] = v_x_2420;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eownPackage_24s759818713x2101508697_lam1(V self, V *args) {
  V v_x_246 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_248;
  if (heff_strEq_c(v_x_246, ((V)&g_heff_2ebuild_2ecommands_2eownPackage_24s759818713x2101508697_str0))) {
    v_x_248 = NTAG(TAG_Windows);
  } else {
    v_x_248 = NTAG(TAG_Posix);
  }
  V v_t_2410 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ProgramPath, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2eownPackage_24s759818713x2101508697_lam2_clo)})});
  V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
  return (g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InR, 1, (V[]){v_t_2412}), v_hd_240, heff_clo_n(g_heff_2ebuild_2ecommands_2eownPackage_24s759818713x2101508697_lam3, 1, 2, (V[]){v_x_248, v_k_241})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprintOutcomes_24s684981677x530430275_str0, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprintOutcomes_24s684981677x530430275_str1, 8, "        ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprintOutcomes_24s684981677x530430275_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprintOutcomes_24s684981677x530430275_str3, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprintOutcomes_24s684981677x530430275_str4, 1, "\012");
V g_heff_2ebuild_2ecommands_2eprintOutcomes_24s684981677x530430275_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eprintOutcomes_24s684981677x530430275_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eprintOutcomes_24s684981677x530430275_lam0, 2, 0};
V g_heff_2ebuild_2ecommands_2eprintOutcomes_24s684981677x530430275_lam3(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eprintOutcomes_24s684981677x530430275_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eprintOutcomes_24s684981677x530430275_lam3, 2, 0};
V g_heff_2ebuild_2ecommands_2eprintOutcomes_24s684981677x530430275_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2eprintOutcomes_24s684981677x530430275_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2eprintOutcomes_24s684981677x530430275_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eprintOutcomes_24s684981677x530430275_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eprintOutcomes_24s684981677x530430275_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2eprintOutcomes_24s684981677x530430275(V v_color_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return ((V)&g_heff_2ebuild_2ecommands_2eprintOutcomes_24s684981677x530430275_lam0_clo);
  }
  case TAG_Cons: {
    V v_o_244 = heff_field(v_x2_241, 0);
    V v_rest_245 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_str_246 = (g_heff_2ebuild_2ecommands_2eoutcomeLine(heff_dup(v_o_244)));
    return heff_clo_n(g_heff_2ebuild_2ecommands_2eprintOutcomes_24s684981677x530430275_lam1, 2, 4, (V[]){v_str_246, v_o_244, heff_dup(v_color_240), v_rest_245});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2ecommands_2eprintOutcomes_24s684981677x530430275_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2eprintOutcomes_24s684981677x530430275(a0, a[1]); heff_drop(a0); return r;
}
V g_heff_2ebuild_2ecommands_2eprintOutcomes_24s684981677x530430275_lam0(V self, V *args) {
  V v_hd_242 = args[0];
  V v_k_243 = args[1];
  heff_drop(v_hd_242);
  V f_ = v_k_243;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eprintOutcomes_24s684981677x530430275_lam3(V self, V *args) {
  V v_hd_2415 = args[0];
  V v_k_2416 = args[1];
  heff_drop(v_hd_2415);
  V f_ = v_k_2416;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eprintOutcomes_24s684981677x530430275_lam4(V self, V *args) {
  V v_x_2430 = args[0];
  V v_color_240 = heff_env(self)[0];
  V v_rest_245 = heff_env(self)[1];
  V v_hd_247 = heff_env(self)[2];
  V v_k_248 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2430);
  V v_t_2431 = ({ V a_0 = v_color_240; V a_1 = v_rest_245; V r_ = (g_heff_2ebuild_2ecommands_2eprintOutcomes_24s684981677x530430275(a_0, a_1)); heff_drop(v_color_240); r_; });
  V f_ = v_t_2431;
  heff_room[0] = v_hd_247;
  heff_room[1] = v_k_248;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2eprintOutcomes_24s684981677x530430275_lam2(V self, V *args) {
  V v_x_2413 = args[0];
  V v_o_244 = heff_env(self)[0];
  V v_color_240 = heff_env(self)[1];
  V v_hd_247 = heff_env(self)[2];
  V v_rest_245 = heff_env(self)[3];
  V v_k_248 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2413);
  V v_t_2414 = heff_take_field(v_o_244, 1);
  V v_c_2429;
  if ((heff_dup(v_t_2414) == NTAG(TAG_True))) {
    heff_drop_rec(v_o_244, 10);
    heff_drop(v_t_2414);
    v_c_2429 = ((V)&g_heff_2ebuild_2ecommands_2eprintOutcomes_24s684981677x530430275_lam3_clo);
  } else {
    heff_drop(v_t_2414);
    V v_t_2417 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2ebuild_2ecommands_2eprintOutcomes_24s684981677x530430275_str1), heff_take_field(v_o_244, 7)));
    V v_t_2418 = heff_get_n(v_o_244, 8, 10);
    V v_t_2420;
    switch (heff_tag_of(v_t_2418)) {
    case TAG_Nothing: {
      v_t_2420 = NTAG(TAG_Nil);
      break;
    }
    case TAG_Just: {
      V v_f_2419 = heff_field(v_t_2418, 0);
      heff_take_n(v_t_2418, 1ULL, 1);
      v_t_2420 = (g_heff_2ebuild_2ecommands_2efailLines(v_color_240, v_f_2419));
      break;
    }
    default: heff_nomatch(v_t_2418);
    }
    V v_x2_2421 = (g_prelude_2e_2b_2b(v_t_2417, v_t_2420));
    V v_str_2424;
    switch (heff_tag_of(v_x2_2421)) {
    case TAG_Nil: {
      v_str_2424 = ((V)&g_heff_2ebuild_2ecommands_2eprintOutcomes_24s684981677x530430275_str2);
      break;
    }
    case TAG_Cons: {
      V v_x_2422 = heff_field(v_x2_2421, 0);
      V v_xs_2423 = heff_field(v_x2_2421, 1);
      heff_take_n(v_x2_2421, 3ULL, 2);
      v_str_2424 = ({ V a_0 = ((V)&g_heff_2ebuild_2ecommands_2eprintOutcomes_24s684981677x530430275_str3); V a_1 = v_x_2422; V a_2 = v_xs_2423; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2423); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2421);
    }
    V v_t_2425 = heff_tag_n(TAG_Write, 2, (V[]){heff_strAppend(v_str_2424, ((V)&g_heff_2ebuild_2ecommands_2eprintOutcomes_24s684981677x530430275_str4)), NTAG(TAG_MkUnit)});
    V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
    V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
    V v_t_2428 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
    v_c_2429 = heff_tr(heff_call(((V)&g_co_2eop_24s1084803226x1249263831_clo), 1, (V[]){v_t_2428}));
  }
  V f_ = v_c_2429;
  heff_room[0] = heff_dup(v_hd_247);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2eprintOutcomes_24s684981677x530430275_lam4, 1, 4, (V[]){v_color_240, v_rest_245, v_hd_247, v_k_248});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2eprintOutcomes_24s684981677x530430275_lam1(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_str_246 = heff_env(self)[0];
  V v_o_244 = heff_env(self)[1];
  V v_color_240 = heff_env(self)[2];
  V v_rest_245 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_249 = heff_tag_n(TAG_Write, 2, (V[]){heff_strAppend(v_str_246, ((V)&g_heff_2ebuild_2ecommands_2eprintOutcomes_24s684981677x530430275_str0)), NTAG(TAG_MkUnit)});
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
  return (g_co_2eop_24s954557541x749476273(v_t_2412, heff_dup(v_hd_247), heff_clo_n(g_heff_2ebuild_2ecommands_2eprintOutcomes_24s684981677x530430275_lam2, 1, 5, (V[]){v_o_244, v_color_240, v_hd_247, v_rest_245, v_k_248})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestCmd_24s1861054559x1051560230_str0, 40, "files that do not check as they should:\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestCmd_24s1861054559x1051560230_str1, 2, "  ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestCmd_24s1861054559x1051560230_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestCmd_24s1861054559x1051560230_str3, 11, " tests hold");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestCmd_24s1861054559x1051560230_str4, 1, "/");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestCmd_24s1861054559x1051560230_str5, 2, ", ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestCmd_24s1861054559x1051560230_str6, 18, " expectations hold");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestCmd_24s1861054559x1051560230_str7, 1, "/");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestCmd_24s1861054559x1051560230_str8, 1, "\012");
V g_heff_2ebuild_2ecommands_2etestCmd_24s1861054559x1051560230_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2etestCmd_24s1861054559x1051560230_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2etestCmd_24s1861054559x1051560230_lam1, 2, 0};
V g_heff_2ebuild_2ecommands_2etestCmd_24s1861054559x1051560230_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestCmd_24s1861054559x1051560230_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestCmd_24s1861054559x1051560230_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestCmd_24s1861054559x1051560230_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestCmd_24s1861054559x1051560230_lam0(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestCmd_24s1861054559x1051560230_lam6(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2etestCmd_24s1861054559x1051560230_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2etestCmd_24s1861054559x1051560230_lam6, 1, 0};
V g_heff_2ebuild_2ecommands_2etestCmd_24s1861054559x1051560230_lam9(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestCmd_24s1861054559x1051560230_lam8(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestCmd_24s1861054559x1051560230_lam7(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2etestCmd_24s1861054559x1051560230_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2etestCmd_24s1861054559x1051560230_entry, 6, 0};

V g_heff_2ebuild_2ecommands_2etestCmd_24s1861054559x1051560230(V v_tk_240, V v_seed_241, V v_x3_242, V v_acc_243, V v_p_244, V v_p_245) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_seed_241);
    V v_t_246 = heff_tag_n(TAG_End, 2, (V[]){v_tk_240, NTAG(TAG_MkUnit)});
    return (g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InL, 1, (V[]){v_t_246}), heff_dup(v_p_244), heff_clo_n(g_heff_2ebuild_2ecommands_2etestCmd_24s1861054559x1051560230_lam0, 1, 3, (V[]){v_acc_243, v_p_244, v_p_245})));
  }
  case TAG_Cons: {
    V v_f_2458 = heff_field(v_x3_242, 0);
    V v_rest_2459 = heff_field(v_x3_242, 1);
    heff_take_n(v_x3_242, 3ULL, 2);
    V v_t_2461 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){heff_dup(v_tk_240), heff_dup(v_f_2458), MK_INT(0LL), ((V)&g_heff_2ebuild_2ecommands_2etestCmd_24s1861054559x1051560230_lam6_clo)})});
    return (g_co_2eop_24s954557541x749476273(v_t_2461, heff_dup(v_p_244), heff_clo_n(g_heff_2ebuild_2ecommands_2etestCmd_24s1861054559x1051560230_lam7, 1, 7, (V[]){v_seed_241, v_f_2458, v_p_244, v_acc_243, v_tk_240, v_rest_2459, v_p_245})));
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2ecommands_2etestCmd_24s1861054559x1051560230_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2etestCmd_24s1861054559x1051560230(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2ebuild_2ecommands_2etestCmd_24s1861054559x1051560230_lam1(V self, V *args) {
  V v_hd_249 = args[0];
  V v_k_2410 = args[1];
  heff_drop(v_hd_249);
  V f_ = v_k_2410;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2etestCmd_24s1861054559x1051560230_lam3(V self, V *args) {
  V v_x_2419 = args[0];
  V v_ws_248 = heff_env(self)[0];
  V v_hd_2413 = heff_env(self)[1];
  V v_k_2414 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2419);
  V v_t_2420 = (g_list_2emap_24s1367796012x2117543847(((V)&g_heff_2ebuild_2ecommands_2etestCmd_24s1861054559x1051560230_str1), v_ws_248));
  return (g_heff_2ebuild_2ecommands_2eprintLines_24s1020531090x2086937737(v_t_2420, v_hd_2413, v_k_2414));
}
V g_heff_2ebuild_2ecommands_2etestCmd_24s1861054559x1051560230_lam2(V self, V *args) {
  V v_hd_2413 = args[0];
  V v_k_2414 = args[1];
  V v_ws_248 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2415 = heff_tag_n(TAG_Write, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2etestCmd_24s1861054559x1051560230_str0), NTAG(TAG_MkUnit)});
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
  return (g_co_2eop_24s954557541x749476273(v_t_2418, heff_dup(v_hd_2413), heff_clo_n(g_heff_2ebuild_2ecommands_2etestCmd_24s1861054559x1051560230_lam3, 1, 3, (V[]){v_ws_248, v_hd_2413, v_k_2414})));
}
V g_heff_2ebuild_2ecommands_2etestCmd_24s1861054559x1051560230_lam5(V self, V *args) {
  V v_x_2439 = args[0];
  V v_acc_243 = heff_env(self)[0];
  V v_p_244 = heff_env(self)[1];
  V v_p_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2439);
  if (heff_intLt_c(MK_INT(0LL), heff_dup(heff_rfield(v_acc_243, 3)))) {
    heff_drop_rec(v_acc_243, 7);
    V v_t_2441 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
    V v_t_2442 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2441})});
    V v_t_2443 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2442})});
    V v_t_2444 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2443})});
    return (g_co_2eop_24s954557541x749476273(v_t_2444, v_p_244, v_p_245));
  } else {
    if (heff_intLt_c(MK_INT(0LL), heff_dup(heff_rfield(v_acc_243, 6)))) {
      heff_drop_rec(v_acc_243, 7);
      V v_t_2446 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
      V v_t_2447 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2446})});
      V v_t_2448 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2447})});
      V v_t_2449 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2448})});
      return (g_co_2eop_24s954557541x749476273(v_t_2449, v_p_244, v_p_245));
    } else {
      V v_t_2450 = heff_get_n(v_acc_243, 4, 7);
      V v_x1_2453;
      switch (heff_tag_of(v_t_2450)) {
      case TAG_Nil: {
        v_x1_2453 = NTAG(TAG_True);
        break;
      }
      case TAG_Cons: {
        heff_take_n(v_t_2450, 0ULL, 2);
        v_x1_2453 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_t_2450);
      }
      if ((heff_dup(v_x1_2453) == NTAG(TAG_True))) {
        heff_drop(v_p_244);
        heff_drop(v_x1_2453);
        V f_ = v_p_245;
        args[0] = NTAG(TAG_MkUnit);
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      } else {
        heff_drop(v_x1_2453);
        V v_t_2454 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
        V v_t_2455 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2454})});
        V v_t_2456 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2455})});
        V v_t_2457 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2456})});
        return (g_co_2eop_24s954557541x749476273(v_t_2457, v_p_244, v_p_245));
      }
    }
  }
}
V g_heff_2ebuild_2ecommands_2etestCmd_24s1861054559x1051560230_lam4(V self, V *args) {
  V v_x_2422 = args[0];
  V v_acc_243 = heff_env(self)[0];
  V v_p_244 = heff_env(self)[1];
  V v_p_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2422);
  V v_t_2423 = heff_intSub(heff_dup(heff_rfield(v_acc_243, 2)), heff_dup(heff_rfield(v_acc_243, 3)));
  V v_t_2424 = heff_intShow(heff_dup(heff_rfield(v_acc_243, 2)));
  V v_tests_2425 = heff_dup(heff_rfield(v_acc_243, 5));
  V v_t_2430;
  if (heff_intEq_c(heff_dup(v_tests_2425), MK_INT(0LL))) {
    heff_drop(v_tests_2425);
    v_t_2430 = ((V)&g_heff_2ebuild_2ecommands_2etestCmd_24s1861054559x1051560230_str2);
  } else {
    V v_t_2427 = heff_intSub(heff_dup(v_tests_2425), heff_dup(heff_rfield(v_acc_243, 6)));
    V v_t_2428 = heff_strAppend(heff_intShow(v_tests_2425), ((V)&g_heff_2ebuild_2ecommands_2etestCmd_24s1861054559x1051560230_str3));
    V v_t_2429 = heff_strAppend(heff_intShow(v_t_2427), heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2etestCmd_24s1861054559x1051560230_str4), v_t_2428));
    v_t_2430 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2etestCmd_24s1861054559x1051560230_str5), v_t_2429);
  }
  V v_t_2431 = (g_heff_2ebuild_2ecommands_2efilesSaid(heff_dup(v_acc_243)));
  V v_t_2432 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2etestCmd_24s1861054559x1051560230_str6), heff_strAppend(v_t_2430, v_t_2431));
  V v_t_2433 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2etestCmd_24s1861054559x1051560230_str7), heff_strAppend(v_t_2424, v_t_2432));
  V v_str_2434 = heff_strAppend(heff_intShow(v_t_2423), v_t_2433);
  V v_t_2435 = heff_tag_n(TAG_Write, 2, (V[]){heff_strAppend(v_str_2434, ((V)&g_heff_2ebuild_2ecommands_2etestCmd_24s1861054559x1051560230_str8)), NTAG(TAG_MkUnit)});
  V v_t_2436 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2435})});
  V v_t_2437 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2436})});
  V v_t_2438 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2437})});
  return (g_co_2eop_24s954557541x749476273(v_t_2438, heff_dup(v_p_244), heff_clo_n(g_heff_2ebuild_2ecommands_2etestCmd_24s1861054559x1051560230_lam5, 1, 3, (V[]){v_acc_243, v_p_244, v_p_245})));
}
V g_heff_2ebuild_2ecommands_2etestCmd_24s1861054559x1051560230_lam0(V self, V *args) {
  V v_x_247 = args[0];
  V v_acc_243 = heff_env(self)[0];
  V v_p_244 = heff_env(self)[1];
  V v_p_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_247);
  V v_ws_248 = heff_dup(heff_rfield(v_acc_243, 4));
  V v_c_2421;
  switch (heff_tag_of(v_ws_248)) {
  case TAG_Nil: {
    v_c_2421 = ((V)&g_heff_2ebuild_2ecommands_2etestCmd_24s1861054559x1051560230_lam1_clo);
    break;
  }
  case TAG_Cons: {
    v_c_2421 = heff_clo_n(g_heff_2ebuild_2ecommands_2etestCmd_24s1861054559x1051560230_lam2, 2, 1, (V[]){v_ws_248});
    break;
  }
  default: heff_nomatch(v_ws_248);
  }
  V f_ = v_c_2421;
  heff_room[0] = heff_dup(v_p_244);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2etestCmd_24s1861054559x1051560230_lam4, 1, 3, (V[]){v_acc_243, v_p_244, v_p_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2etestCmd_24s1861054559x1051560230_lam6(V self, V *args) {
  V v_t_2460 = args[0];
  return v_t_2460;
}
V g_heff_2ebuild_2ecommands_2etestCmd_24s1861054559x1051560230_lam9(V self, V *args) {
  V v_x_2465 = args[0];
  V v_acc_243 = heff_env(self)[0];
  V v_x_2463 = heff_env(self)[1];
  V v_tk_240 = heff_env(self)[2];
  V v_seed_241 = heff_env(self)[3];
  V v_rest_2459 = heff_env(self)[4];
  V v_p_244 = heff_env(self)[5];
  V v_p_245 = heff_env(self)[6];
  heff_clo_take(self, 7);
  heff_drop(v_x_2465);
  V v_t_2466 = (g_heff_2ebuild_2ecommands_2eaddRes(v_acc_243, v_x_2463));
  return (g_heff_2ebuild_2ecommands_2etestCmd_24s1861054559x1051560230(v_tk_240, v_seed_241, v_rest_2459, v_t_2466, v_p_244, v_p_245));
}
V g_heff_2ebuild_2ecommands_2etestCmd_24s1861054559x1051560230_lam8(V self, V *args) {
  V v_x_2463 = args[0];
  V v_x_2462 = heff_env(self)[0];
  V v_p_244 = heff_env(self)[1];
  V v_acc_243 = heff_env(self)[2];
  V v_tk_240 = heff_env(self)[3];
  V v_seed_241 = heff_env(self)[4];
  V v_rest_2459 = heff_env(self)[5];
  V v_p_245 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2464 = heff_tag_n(TAG_End, 2, (V[]){v_x_2462, NTAG(TAG_MkUnit)});
  return (g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InL, 1, (V[]){v_t_2464}), heff_dup(v_p_244), heff_clo_n(g_heff_2ebuild_2ecommands_2etestCmd_24s1861054559x1051560230_lam9, 1, 7, (V[]){v_acc_243, v_x_2463, v_tk_240, v_seed_241, v_rest_2459, v_p_244, v_p_245})));
}
V g_heff_2ebuild_2ecommands_2etestCmd_24s1861054559x1051560230_lam7(V self, V *args) {
  V v_x_2462 = args[0];
  V v_seed_241 = heff_env(self)[0];
  V v_f_2458 = heff_env(self)[1];
  V v_p_244 = heff_env(self)[2];
  V v_acc_243 = heff_env(self)[3];
  V v_tk_240 = heff_env(self)[4];
  V v_rest_2459 = heff_env(self)[5];
  V v_p_245 = heff_env(self)[6];
  heff_clo_take(self, 7);
  return (g_heff_2ebuild_2ecommands_2etestOneF_24s1353895353x878524806(heff_dup(v_seed_241), v_f_2458, heff_dup(v_p_244), heff_clo_n(g_heff_2ebuild_2ecommands_2etestCmd_24s1861054559x1051560230_lam8, 1, 7, (V[]){v_x_2462, v_p_244, v_acc_243, v_tk_240, v_seed_241, v_rest_2459, v_p_245})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ekeptWritten_24s1884000495x2131386180_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ekeptWritten_24s1884000495x2131386180_str1, 1, "_");
V g_heff_2ebuild_2ecommands_2ekeptWritten_24s1884000495x2131386180_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ekeptWritten_24s1884000495x2131386180_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ekeptWritten_24s1884000495x2131386180_lam1, 1, 0};
V g_heff_2ebuild_2ecommands_2ekeptWritten_24s1884000495x2131386180_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ekeptWritten_24s1884000495x2131386180_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ekeptWritten_24s1884000495x2131386180_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ekeptWritten_24s1884000495x2131386180_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ekeptWritten_24s1884000495x2131386180_entry, 9, 0};

V g_heff_2ebuild_2ecommands_2ekeptWritten_24s1884000495x2131386180(V v_bi_240, V v_dir_241, V v_id_242, V v_texts_243, V v_backs_244, V v_done_245, V v_out_246, V v_z_247, V v_z_248) {
top: ;
  V v_t_2425;
  if (heff_strEq_c(heff_dup(v_id_242), ((V)&g_heff_2ebuild_2ecommands_2ekeptWritten_24s1884000495x2131386180_str0))) {
    heff_drop_rec(v_bi_240, 3);
    heff_drop(v_id_242);
    heff_drop(v_backs_244);
    v_t_2425 = v_done_245;
  } else {
    V v_path_2410 = (g_heff_2ebuild_2ecommands_2ebackDirOf(heff_dup(heff_rfield(v_bi_240, 0))));
    v_t_2425 = heff_clo_n(g_heff_2ebuild_2ecommands_2ekeptWritten_24s1884000495x2131386180_lam0, 2, 7, (V[]){v_path_2410, heff_dup(v_texts_243), v_bi_240, heff_dup(v_out_246), v_id_242, v_backs_244, v_done_245});
  }
  V v_t_2426 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_take_field(v_out_246, 0), heff_get_n(v_out_246, 1, 5)});
  return (g_heff_2ebuild_2ecommands_2ewriteParts_24s2007547047x1883297068(v_dir_241, v_t_2425, v_t_2426, v_z_247, v_z_248));
}
V g_heff_2ebuild_2ecommands_2ekeptWritten_24s1884000495x2131386180_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2ebuild_2ecommands_2ekeptWritten_24s1884000495x2131386180(a[0], a[1], a[2], a3, a[4], a[5], a[6], a[7], a[8]); heff_drop(a3); return r;
}
V g_heff_2ebuild_2ecommands_2ekeptWritten_24s1884000495x2131386180_lam1(V self, V *args) {
  V v_ok_2413 = args[0];
  return v_ok_2413;
}
V g_heff_2ebuild_2ecommands_2ekeptWritten_24s1884000495x2131386180_lam3(V self, V *args) {
  V v_x_2424 = args[0];
  V v_done_245 = heff_env(self)[0];
  V v_hd_2411 = heff_env(self)[1];
  V v_k_2412 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2424);
  V f_ = v_done_245;
  heff_room[0] = v_hd_2411;
  heff_room[1] = v_k_2412;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ekeptWritten_24s1884000495x2131386180_lam2(V self, V *args) {
  V v_x_2417 = args[0];
  V v_texts_243 = heff_env(self)[0];
  V v_bi_240 = heff_env(self)[1];
  V v_out_246 = heff_env(self)[2];
  V v_id_242 = heff_env(self)[3];
  V v_backs_244 = heff_env(self)[4];
  V v_hd_2411 = heff_env(self)[5];
  V v_done_245 = heff_env(self)[6];
  V v_k_2412 = heff_env(self)[7];
  heff_clo_take(self, 8);
  heff_drop(v_x_2417);
  V v_t_2418 = ({ V a_0 = heff_dup(g_map_2eempty_get()); V a_1 = v_texts_243; V r_ = (g_list_2efoldl_24s2040448920x1981923787(a_0, a_1)); heff_drop(v_texts_243); r_; });
  V v_t_2419 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ekeptWritten_24s1884000495x2131386180_str1), heff_take_field(v_bi_240, 2)});
  V v_t_2420 = ({ V a_0 = heff_dup(g_map_2eempty_get()); V a_1 = v_t_2419; V r_ = (g_list_2efoldl_24s657006386x1833506039(a_0, a_1)); heff_drop_tag(v_t_2419, 2); r_; });
  V v_t_2421 = heff_rec_n(4, shape_groups__copies__emits__jss, (V[]){heff_take_field(v_out_246, 2), heff_take_field(v_out_246, 3), heff_get_n(v_out_246, 4, 5), NTAG(TAG_Nil)});
  V v_t_2422 = (g_heff_2ebuild_2ebackcache_2ebackTexts(v_id_242, heff_rec_n(2, shape_mods__olds, (V[]){v_t_2420, v_backs_244}), v_t_2421));
  V v_c_2423 = ({ V a_0 = heff_get_n(v_bi_240, 0, 3); V a_1 = v_t_2418; V a_2 = v_t_2422; V r_ = (g_heff_2ebuild_2ecommands_2ewriteBacks_24s1642553849x1460541962(a_0, a_1, a_2)); heff_drop(v_t_2418); heff_drop(v_t_2422); r_; });
  V f_ = v_c_2423;
  heff_room[0] = heff_dup(v_hd_2411);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ekeptWritten_24s1884000495x2131386180_lam3, 1, 3, (V[]){v_done_245, v_hd_2411, v_k_2412});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ekeptWritten_24s1884000495x2131386180_lam0(V self, V *args) {
  V v_hd_2411 = args[0];
  V v_k_2412 = args[1];
  V v_path_2410 = heff_env(self)[0];
  V v_texts_243 = heff_env(self)[1];
  V v_bi_240 = heff_env(self)[2];
  V v_out_246 = heff_env(self)[3];
  V v_id_242 = heff_env(self)[4];
  V v_backs_244 = heff_env(self)[5];
  V v_done_245 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2414 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_MkDir, 2, (V[]){v_path_2410, ((V)&g_heff_2ebuild_2ecommands_2ekeptWritten_24s1884000495x2131386180_lam1_clo)})});
  V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
  V v_t_2416 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  return (g_co_2eop_24s954557541x749476273(v_t_2416, heff_dup(v_hd_2411), heff_clo_n(g_heff_2ebuild_2ecommands_2ekeptWritten_24s1884000495x2131386180_lam2, 1, 8, (V[]){v_texts_243, v_bi_240, v_out_246, v_id_242, v_backs_244, v_hd_2411, v_done_245, v_k_2412})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_str0, 5, ".hash");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_str1, 1, " ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_str2, 9, "fetching ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_str3, 8, "https://");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_str4, 1, "v");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_str5, 1, "1");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_str6, 8, "--branch");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_str7, 7, "--quiet");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_str8, 7, "--depth");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_str9, 25, "advice.detachedHead=false");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_str10, 5, "clone");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_str11, 2, "-c");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_str12, 3, "git");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_str13, 8, "https://");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_str14, 3, "): ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_str15, 4, " of ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_str16, 7, " (tag v");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_str17, 1, " ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_str18, 13, "cannot fetch ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_str19, 11, "HEAD^{tree}");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_str20, 9, "rev-parse");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_str21, 3, "git");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_str22, 2, "-C");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_str23, 4, ".git");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_str24, 5, "tree:");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_str25, 5, ".hash");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_str26, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_str27, 1, " ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_str28, 18, "heff get: fetched ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_str29, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_str30, 4, " in ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_str31, 1, " ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_str32, 12, "cannot keep ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_str33, 4, " in ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_str34, 1, " ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_str35, 12, "cannot keep ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_str36, 4, " in ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_str37, 1, " ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_str38, 12, "cannot keep ");
V g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_lam1, 1, 0};
V g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_lam3(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_lam3, 1, 0};
V g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_lam5(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_lam5, 1, 0};
V g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_lam7(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_lam7, 1, 0};
V g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_lam9(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_lam9_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_lam9, 1, 0};
V g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_lam12(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_lam12_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_lam12, 1, 0};
V g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_lam13(V self, V *args);
V g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_lam14(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_lam14_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_lam14, 1, 0};
V g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_lam16(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_lam16_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_lam16, 1, 0};
V g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_lam18(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_lam18_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_lam18, 1, 0};
V g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_lam20(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_lam20_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_lam20, 1, 0};
V g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_lam22(V self, V *args);
V g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_lam21(V self, V *args);
V g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_lam19(V self, V *args);
V g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_lam17(V self, V *args);
V g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_lam15(V self, V *args);
V g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_lam11(V self, V *args);
V g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_lam10(V self, V *args);
V g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_lam8(V self, V *args);
V g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957(V v_ps_240, V v_path_241, V v_v_242) {
top: ;
  V v_x_243 = (g_heff_2ebuild_2eload_2ecachedDir(heff_dup(v_ps_240), heff_dup(v_path_241), heff_dup(v_v_242)));
  return heff_clo_n(g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_lam0, 2, 4, (V[]){v_x_243, v_ps_240, v_path_241, v_v_242});
}
V g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_lam1(V self, V *args) {
  V v_t_246 = args[0];
  return v_t_246;
}
V g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_lam3(V self, V *args) {
  V v_ok_2411 = args[0];
  return v_ok_2411;
}
V g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_lam5(V self, V *args) {
  V v_ok_2423 = args[0];
  return v_ok_2423;
}
V g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_lam7(V self, V *args) {
  V v_t_2429 = args[0];
  return v_t_2429;
}
V g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_lam9(V self, V *args) {
  V v_r_2440 = args[0];
  return v_r_2440;
}
V g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_lam12(V self, V *args) {
  V v_ok_2449 = args[0];
  return v_ok_2449;
}
V g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_lam13(V self, V *args) {
  V v_x_2453 = args[0];
  V v_path_241 = heff_env(self)[0];
  V v_x_2444 = heff_env(self)[1];
  V v_v_242 = heff_env(self)[2];
  V v_k_245 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2453);
  V v_t_2454 = (g_heff_2ebuild_2eproject_2erepoOf(heff_dup(v_path_241)));
  V v_s_2455 = heff_get_n(v_x_2444, 2, 3);
  V v_t_2456 = (g_prelude_2eskipSpaces(heff_dup(v_s_2455), MK_INT(0LL), MK_INT(1LL)));
  V v_t_2457 = heff_intSub(heff_strLength(heff_dup(v_s_2455)), MK_INT(1LL));
  V v_t_2458 = (g_prelude_2eskipSpaces(heff_dup(v_s_2455), v_t_2457, MK_INT(-1LL)));
  V v_t_2459 = heff_strSlice(v_s_2455, v_t_2456, heff_intAdd(v_t_2458, MK_INT(1LL)));
  V v_t_2460 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_str13), v_t_2454), heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_str14), v_t_2459));
  V v_t_2461 = heff_strAppend(heff_dup(v_v_242), heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_str15), v_t_2460));
  V v_t_2462 = heff_strAppend(v_v_242, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_str16), v_t_2461));
  V v_t_2463 = heff_strAppend(v_path_241, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_str17), v_t_2462));
  V v_x_2464 = heff_tag_n(TAG_Left, 1, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_str18), v_t_2463)});
  V f_ = v_k_245;
  args[0] = v_x_2464;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_lam14(V self, V *args) {
  V v_r_2467 = args[0];
  return v_r_2467;
}
V g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_lam16(V self, V *args) {
  V v_ok_2480 = args[0];
  return v_ok_2480;
}
V g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_lam18(V self, V *args) {
  V v_ok_2485 = args[0];
  return v_ok_2485;
}
V g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_lam20(V self, V *args) {
  V v_ok_2496 = args[0];
  return v_ok_2496;
}
V g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_lam22(V self, V *args) {
  V v_x_24108 = args[0];
  V v_k_245 = heff_env(self)[0];
  V v_x_2495 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_24108);
  V f_ = v_k_245;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2495});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_lam21(V self, V *args) {
  V v_x_24100 = args[0];
  V v_x_2472 = heff_env(self)[0];
  V v_x_2489 = heff_env(self)[1];
  V v_path_241 = heff_env(self)[2];
  V v_v_242 = heff_env(self)[3];
  V v_hd_244 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  V v_x_2495 = heff_env(self)[6];
  V v_x_243 = heff_env(self)[7];
  heff_clo_take(self, 8);
  if (heff_intEq_c(heff_get_n(v_x_2472, 0, 3), MK_INT(0LL))) {
    if ((heff_dup(v_x_2489) == NTAG(TAG_True))) {
      heff_drop(v_x_2489);
      if ((heff_dup(v_x_24100) == NTAG(TAG_True))) {
        heff_drop(v_x_24100);
        heff_drop(v_x_243);
        V v_t_24102 = heff_strAppend(v_path_241, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_str27), v_v_242));
        V v_t_24103 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_str28), v_t_24102), ((V)&g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_str29));
        V v_t_24104 = heff_tag_n(TAG_Write, 2, (V[]){v_t_24103, NTAG(TAG_MkUnit)});
        V v_t_24105 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24104})});
        V v_t_24106 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24105})});
        V v_t_24107 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24106})});
        return (g_co_2eop_24s954557541x749476273(v_t_24107, v_hd_244, heff_clo_n(g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_lam22, 1, 2, (V[]){v_k_245, v_x_2495})));
      } else {
        heff_drop(v_x_24100);
        heff_drop(v_hd_244);
        heff_drop(v_x_2495);
        V v_t_24109 = heff_strAppend(v_v_242, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_str30), v_x_243));
        V v_t_24110 = heff_strAppend(v_path_241, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_str31), v_t_24109));
        V v_t_24111 = heff_tag_n(TAG_Left, 1, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_str32), v_t_24110)});
        V f_ = v_k_245;
        args[0] = v_t_24111;
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      }
    } else {
      heff_drop(v_x_24100);
      heff_drop(v_x_2489);
      heff_drop(v_hd_244);
      heff_drop(v_x_2495);
      V v_t_24112 = heff_strAppend(v_v_242, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_str33), v_x_243));
      V v_t_24113 = heff_strAppend(v_path_241, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_str34), v_t_24112));
      V v_t_24114 = heff_tag_n(TAG_Left, 1, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_str35), v_t_24113)});
      V f_ = v_k_245;
      args[0] = v_t_24114;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
  } else {
    heff_drop(v_x_24100);
    heff_drop(v_x_2489);
    heff_drop(v_hd_244);
    heff_drop(v_x_2495);
    V v_t_24115 = heff_strAppend(v_v_242, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_str36), v_x_243));
    V v_t_24116 = heff_strAppend(v_path_241, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_str37), v_t_24115));
    V v_t_24117 = heff_tag_n(TAG_Left, 1, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_str38), v_t_24116)});
    V f_ = v_k_245;
    args[0] = v_t_24117;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}
V g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_lam19(V self, V *args) {
  V v_x_2489 = args[0];
  V v_x_2472 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  V v_hd_244 = heff_env(self)[2];
  V v_path_241 = heff_env(self)[3];
  V v_v_242 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_s_2490 = heff_dup(heff_rfield(v_x_2472, 1));
  V v_t_2491 = (g_prelude_2eskipSpaces(heff_dup(v_s_2490), MK_INT(0LL), MK_INT(1LL)));
  V v_t_2492 = heff_intSub(heff_strLength(heff_dup(v_s_2490)), MK_INT(1LL));
  V v_t_2493 = (g_prelude_2eskipSpaces(heff_dup(v_s_2490), v_t_2492, MK_INT(-1LL)));
  V v_t_2494 = heff_strSlice(v_s_2490, v_t_2491, heff_intAdd(v_t_2493, MK_INT(1LL)));
  V v_x_2495 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_str24), v_t_2494);
  V v_t_2497 = heff_tag_n(TAG_WriteFile, 3, (V[]){heff_strAppend(heff_dup(v_x_243), ((V)&g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_str25)), heff_strAppend(heff_dup(v_x_2495), ((V)&g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_str26)), ((V)&g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_lam20_clo)});
  V v_t_2498 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2497})});
  V v_t_2499 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2498})});
  return (g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InR, 1, (V[]){v_t_2499}), heff_dup(v_hd_244), heff_clo_n(g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_lam21, 1, 8, (V[]){v_x_2472, v_x_2489, v_path_241, v_v_242, v_hd_244, v_k_245, v_x_2495, v_x_243})));
}
V g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_lam17(V self, V *args) {
  V v_x_2484 = args[0];
  V v_x_243 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_x_2472 = heff_env(self)[2];
  V v_path_241 = heff_env(self)[3];
  V v_v_242 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_2484);
  V v_t_2486 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadOnly, 2, (V[]){heff_dup(v_x_243), ((V)&g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_lam18_clo)})});
  V v_t_2487 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2486})});
  V v_t_2488 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2487})});
  return (g_co_2eop_24s954557541x749476273(v_t_2488, heff_dup(v_hd_244), heff_clo_n(g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_lam19, 1, 6, (V[]){v_x_2472, v_x_243, v_hd_244, v_path_241, v_v_242, v_k_245})));
}
V g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_lam15(V self, V *args) {
  V v_x_2472 = args[0];
  V v_ps_240 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  V v_hd_244 = heff_env(self)[2];
  V v_path_241 = heff_env(self)[3];
  V v_v_242 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_st_2473 = heff_get_n(v_ps_240, 5, 6);
  V v_t_2474 = (g_std_2epath_2eparse(v_st_2473, heff_dup(v_x_243)));
  V v_t_2475 = (g_std_2epath_2eparse(v_st_2473, ((V)&g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_str23)));
  V v_p_2476 = (g_std_2epath_2ejoin_2eonto_240(v_t_2474, v_t_2475));
  V v_t_2477 = (g_std_2epath_2ecollapse(heff_dup(heff_rfield(v_p_2476, 1)), heff_rfield(v_p_2476, 2)));
  V v_t_2478 = ({ V rv_2 = v_t_2477; V rr_ = heff_rec_reuse_nf(v_p_2476, 3ULL, 3, shape_drive__absolute__segments, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
  V v_path_2479 = ({ V a_0 = v_st_2473; V a_1 = v_t_2478; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2473); r_; });
  V v_t_2481 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Remove, 2, (V[]){v_path_2479, ((V)&g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_lam16_clo)})});
  V v_t_2482 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2481})});
  V v_t_2483 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2482})});
  return (g_co_2eop_24s954557541x749476273(v_t_2483, heff_dup(v_hd_244), heff_clo_n(g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_lam17, 1, 6, (V[]){v_x_243, v_hd_244, v_x_2472, v_path_241, v_v_242, v_k_245})));
}
V g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_lam11(V self, V *args) {
  V v_x_2446 = args[0];
  V v_x_2444 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  V v_hd_244 = heff_env(self)[2];
  V v_path_241 = heff_env(self)[3];
  V v_v_242 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  V v_ps_240 = heff_env(self)[6];
  heff_clo_take(self, 7);
  heff_drop(v_x_2446);
  V v_t_2448 = heff_bool(!heff_intEq_c(heff_dup(heff_rfield(v_x_2444, 0)), MK_INT(0LL)));
  if ((heff_dup(v_t_2448) == NTAG(TAG_True))) {
    heff_drop_rec(v_ps_240, 6);
    heff_drop(v_t_2448);
    V v_t_2450 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Remove, 2, (V[]){v_x_243, ((V)&g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_lam12_clo)})});
    V v_t_2451 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2450})});
    V v_t_2452 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2451})});
    return (g_co_2eop_24s954557541x749476273(v_t_2452, v_hd_244, heff_clo_n(g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_lam13, 1, 4, (V[]){v_path_241, v_x_2444, v_v_242, v_k_245})));
  } else {
    heff_drop_rec(v_x_2444, 3);
    heff_drop(v_t_2448);
    V v_t_2465 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_str19), NTAG(TAG_Nil)});
    V v_t_2466 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_x_243), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_str20), v_t_2465})});
    V v_t_2468 = heff_tag_n(TAG_Run, 3, (V[]){((V)&g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_str21), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_str22), v_t_2466}), ((V)&g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_lam14_clo)});
    V v_t_2469 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2468})});
    V v_t_2470 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2469})});
    V v_t_2471 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2470})});
    return (g_co_2eop_24s954557541x749476273(v_t_2471, heff_dup(v_hd_244), heff_clo_n(g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_lam15, 1, 6, (V[]){v_ps_240, v_x_243, v_hd_244, v_path_241, v_v_242, v_k_245})));
  }
}
V g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_lam10(V self, V *args) {
  V v_x_2444 = args[0];
  V v_x_2431 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  V v_path_241 = heff_env(self)[3];
  V v_v_242 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  V v_ps_240 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2445 = heff_tag_n(TAG_End, 2, (V[]){v_x_2431, NTAG(TAG_MkUnit)});
  return (g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InL, 1, (V[]){v_t_2445}), heff_dup(v_hd_244), heff_clo_n(g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_lam11, 1, 7, (V[]){v_x_2444, v_x_243, v_hd_244, v_path_241, v_v_242, v_k_245, v_ps_240})));
}
V g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_lam8(V self, V *args) {
  V v_x_2431 = args[0];
  V v_path_241 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  V v_v_242 = heff_env(self)[2];
  V v_hd_244 = heff_env(self)[3];
  V v_k_245 = heff_env(self)[4];
  V v_ps_240 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2432 = (g_heff_2ebuild_2eproject_2erepoOf(heff_dup(v_path_241)));
  V v_t_2433 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_x_243), NTAG(TAG_Nil)});
  V v_t_2434 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_str3), v_t_2432), v_t_2433});
  V v_t_2435 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_str4), heff_dup(v_v_242)), v_t_2434});
  V v_t_2436 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_str5), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_str6), v_t_2435})});
  V v_t_2437 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_str7), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_str8), v_t_2436})});
  V v_t_2438 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_str9), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_str10), v_t_2437})});
  V v_as_2439 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_str11), v_t_2438});
  V v_t_2441 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Run, 3, (V[]){((V)&g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_str12), v_as_2439, ((V)&g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_lam9_clo)})});
  V v_t_2442 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2441})});
  V v_t_2443 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2442})});
  return (g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InR, 1, (V[]){v_t_2443}), heff_dup(v_hd_244), heff_clo_n(g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_lam10, 1, 7, (V[]){v_x_2431, v_hd_244, v_x_243, v_path_241, v_v_242, v_k_245, v_ps_240})));
}
V g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_lam6(V self, V *args) {
  V v_x_2427 = args[0];
  V v_path_241 = heff_env(self)[0];
  V v_v_242 = heff_env(self)[1];
  V v_hd_244 = heff_env(self)[2];
  V v_x_243 = heff_env(self)[3];
  V v_k_245 = heff_env(self)[4];
  V v_ps_240 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_2427);
  V v_t_2428 = heff_strAppend(heff_dup(v_path_241), heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_str1), heff_dup(v_v_242)));
  V v_t_2430 = heff_tag_n(TAG_Start, 4, (V[]){heff_dup(g_std_2eprogress_2eroot_get()), heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_str2), v_t_2428), MK_INT(0LL), ((V)&g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_lam7_clo)});
  return (g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InL, 1, (V[]){v_t_2430}), heff_dup(v_hd_244), heff_clo_n(g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_lam8, 1, 6, (V[]){v_path_241, v_x_243, v_v_242, v_hd_244, v_k_245, v_ps_240})));
}
V g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_lam4(V self, V *args) {
  V v_x_2415 = args[0];
  V v_ps_240 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  V v_hd_244 = heff_env(self)[2];
  V v_path_241 = heff_env(self)[3];
  V v_v_242 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_2415);
  V v_st_2416 = heff_dup(heff_rfield(v_ps_240, 5));
  V v_p_2417 = (g_std_2epath_2eparse(v_st_2416, heff_dup(v_x_243)));
  V v_t_2418 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_p_2417, 2)));
  V v_xs_2419 = (g_list_2edrop(MK_INT(1LL), v_t_2418));
  V v_t_2420 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2419));
  V v_t_2421 = ({ V rv_2 = v_t_2420; V rr_ = heff_rec_reuse_nf(v_p_2417, 3ULL, 3, shape_drive__absolute__segments, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
  V v_path_2422 = ({ V a_0 = v_st_2416; V a_1 = v_t_2421; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2416); r_; });
  V v_t_2424 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_MkDir, 2, (V[]){v_path_2422, ((V)&g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_lam5_clo)})});
  V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
  V v_t_2426 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
  return (g_co_2eop_24s954557541x749476273(v_t_2426, heff_dup(v_hd_244), heff_clo_n(g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_lam6, 1, 6, (V[]){v_path_241, v_v_242, v_hd_244, v_x_243, v_k_245, v_ps_240})));
}
V g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_lam2(V self, V *args) {
  V v_x_2410 = args[0];
  V v_x_243 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_ps_240 = heff_env(self)[2];
  V v_path_241 = heff_env(self)[3];
  V v_v_242 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  switch (heff_tag_of(v_x_2410)) {
  case TAG_Nothing: {
    V v_t_2412 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Remove, 2, (V[]){heff_dup(v_x_243), ((V)&g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_lam3_clo)})});
    V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
    V v_t_2414 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
    return (g_co_2eop_24s954557541x749476273(v_t_2414, heff_dup(v_hd_244), heff_clo_n(g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_lam4, 1, 6, (V[]){v_ps_240, v_x_243, v_hd_244, v_path_241, v_v_242, v_k_245})));
  }
  case TAG_Just: {
    V v_h_24118 = heff_field(v_x_2410, 0);
    V v_ru_24x_2410_24Just = heff_take_reuse_n(v_x_2410, 1ULL, 1);
    heff_drop(v_x_243);
    heff_drop(v_hd_244);
    heff_drop_rec(v_ps_240, 6);
    heff_drop(v_path_241);
    heff_drop(v_v_242);
    V v_t_24119 = (g_prelude_2eskipSpaces(heff_dup(v_h_24118), MK_INT(0LL), MK_INT(1LL)));
    V v_t_24120 = heff_intSub(heff_strLength(heff_dup(v_h_24118)), MK_INT(1LL));
    V v_t_24121 = (g_prelude_2eskipSpaces(heff_dup(v_h_24118), v_t_24120, MK_INT(-1LL)));
    V v_t_24122 = heff_strSlice(v_h_24118, v_t_24119, heff_intAdd(v_t_24121, MK_INT(1LL)));
    V v_x_24123 = heff_tag_at_n(v_ru_24x_2410_24Just, TAG_Right, 1, (V[]){v_t_24122});
    V f_ = v_k_245;
    args[0] = v_x_24123;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_2410);
  }
}
V g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_lam0(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k_245 = args[1];
  V v_x_243 = heff_env(self)[0];
  V v_ps_240 = heff_env(self)[1];
  V v_path_241 = heff_env(self)[2];
  V v_v_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_247 = heff_tag_n(TAG_ReadFile, 2, (V[]){heff_strAppend(heff_dup(v_x_243), ((V)&g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_str0)), ((V)&g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_lam1_clo)});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  return (g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InR, 1, (V[]){v_t_249}), heff_dup(v_hd_244), heff_clo_n(g_heff_2ebuild_2ecommands_2efetched_24s1278278858x1776836957_lam2, 1, 6, (V[]){v_x_243, v_hd_244, v_ps_240, v_path_241, v_v_242, v_k_245})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetCmd_24s1824733856x1503967101_str0, 10, "package.hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetCmd_24s1824733856x1503967101_str1, 56, "heff get: no package.hf here: get at the project's root\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetCmd_24s1824733856x1503967101_str2, 35, "heff get: package.hf does not read\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetCmd_24s1824733856x1503967101_str3, 1, "@");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetCmd_24s1824733856x1503967101_str4, 10, "heff get: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetCmd_24s1824733856x1503967101_str5, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetCmd_24s1824733856x1503967101_str6, 10, "package.hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetCmd_24s1824733856x1503967101_str7, 1, "@");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetCmd_24s1824733856x1503967101_str8, 1, "@");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetCmd_24s1824733856x1503967101_str9, 10, "heff get: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetCmd_24s1824733856x1503967101_str10, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetCmd_24s1824733856x1503967101_str11, 1, "`");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetCmd_24s1824733856x1503967101_str12, 22, "` is no version: a.b.c");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetCmd_24s1824733856x1503967101_str13, 10, "heff get: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetCmd_24s1824733856x1503967101_str14, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetCmd_24s1824733856x1503967101_str15, 1, "@");
V g_heff_2ebuild_2ecommands_2egetCmd_24s1824733856x1503967101_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2egetCmd_24s1824733856x1503967101_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2egetCmd_24s1824733856x1503967101_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2egetCmd_24s1824733856x1503967101_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetCmd_24s1824733856x1503967101_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetCmd_24s1824733856x1503967101_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetCmd_24s1824733856x1503967101_lam7(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetCmd_24s1824733856x1503967101_lam9(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetCmd_24s1824733856x1503967101_lam10(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetCmd_24s1824733856x1503967101_lam11(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetCmd_24s1824733856x1503967101_lam8(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetCmd_24s1824733856x1503967101_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetCmd_24s1824733856x1503967101_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetCmd_24s1824733856x1503967101_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2egetCmd_24s1824733856x1503967101_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2egetCmd_24s1824733856x1503967101_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2egetCmd_24s1824733856x1503967101(V v_spec_240, V v_hd_241, V v_k_242) {
top: ;
  V v_t_244 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2egetCmd_24s1824733856x1503967101_str0), ((V)&g_heff_2ebuild_2ecommands_2egetCmd_24s1824733856x1503967101_lam0_clo)})});
  V v_t_245 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_244})});
  V v_t_246 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_245})});
  HEFF_LAST return g_co_2eop_24s954557541x749476273(v_t_246, heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2ecommands_2egetCmd_24s1824733856x1503967101_lam1, 1, 3, (V[]){v_hd_241, v_k_242, v_spec_240}));
}
V g_heff_2ebuild_2ecommands_2egetCmd_24s1824733856x1503967101_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2egetCmd_24s1824733856x1503967101(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2ecommands_2egetCmd_24s1824733856x1503967101_lam0(V self, V *args) {
  V v_t_243 = args[0];
  return v_t_243;
}
V g_heff_2ebuild_2ecommands_2egetCmd_24s1824733856x1503967101_lam2(V self, V *args) {
  V v_x_2412 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2412);
  V v_t_2413 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2413})});
  V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
  V v_t_2416 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  return (g_co_2eop_24s954557541x749476273(v_t_2416, v_hd_241, v_k_242));
}
V g_heff_2ebuild_2ecommands_2egetCmd_24s1824733856x1503967101_lam3(V self, V *args) {
  V v_x_2427 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2427);
  V v_t_2428 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2428})});
  V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
  V v_t_2431 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
  return (g_co_2eop_24s954557541x749476273(v_t_2431, v_hd_241, v_k_242));
}
V g_heff_2ebuild_2ecommands_2egetCmd_24s1824733856x1503967101_lam4(V self, V *args) {
  V v_x_2451 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2451);
  V v_t_2452 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2453 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2452})});
  V v_t_2454 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2453})});
  V v_t_2455 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2454})});
  return (g_co_2eop_24s954557541x749476273(v_t_2455, v_hd_241, v_k_242));
}
V g_heff_2ebuild_2ecommands_2egetCmd_24s1824733856x1503967101_lam7(V self, V *args) {
  V v_hd_2483 = args[0];
  V v_k_2484 = args[1];
  V v_v_2482 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2483);
  V f_ = v_k_2484;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_v_2482});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2egetCmd_24s1824733856x1503967101_lam9(V self, V *args) {
  V v_x_2493 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2493);
  V v_t_2494 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2495 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2494})});
  V v_t_2496 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2495})});
  V v_t_2497 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2496})});
  return (g_co_2eop_24s954557541x749476273(v_t_2497, v_hd_241, v_k_242));
}
V g_heff_2ebuild_2ecommands_2egetCmd_24s1824733856x1503967101_lam10(V self, V *args) {
  V v_x_24106 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_24106);
  V v_t_24107 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_24108 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24107})});
  V v_t_24109 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24108})});
  V v_t_24110 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24109})});
  return (g_co_2eop_24s954557541x749476273(v_t_24110, v_hd_241, v_k_242));
}
V g_heff_2ebuild_2ecommands_2egetCmd_24s1824733856x1503967101_lam11(V self, V *args) {
  V v_x_24124 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  if ((heff_dup(v_x_24124) == NTAG(TAG_True))) {
    heff_drop(v_x_24124);
    V f_ = heff_dup(g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_get());
    heff_room[0] = v_hd_241;
    heff_room[1] = v_k_242;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    heff_drop(v_x_24124);
    heff_drop(v_hd_241);
    V f_ = v_k_242;
    args[0] = NTAG(TAG_MkUnit);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}
V g_heff_2ebuild_2ecommands_2egetCmd_24s1824733856x1503967101_lam8(V self, V *args) {
  V v_x_2486 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  V v_s_2433 = heff_env(self)[2];
  V v_x_2459 = heff_env(self)[3];
  V v_t_2417 = heff_env(self)[4];
  V v_pk_2432 = heff_env(self)[5];
  heff_clo_take(self, 6);
  switch (heff_tag_of(v_x_2486)) {
  case TAG_Left: {
    V v_why_2487 = heff_field(v_x_2486, 0);
    V v_ru_24x_2486_24Left = heff_take_reuse_n(v_x_2486, 1ULL, 1);
    heff_drop(v_s_2433);
    heff_drop(v_x_2459);
    heff_drop(v_t_2417);
    heff_drop(v_pk_2432);
    V v_t_2488 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2egetCmd_24s1824733856x1503967101_str9), v_why_2487), ((V)&g_heff_2ebuild_2ecommands_2egetCmd_24s1824733856x1503967101_str10));
    V v_t_2489 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2488, NTAG(TAG_MkUnit)});
    V v_t_2490 = heff_tag_at_n(v_ru_24x_2486_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2489})});
    V v_t_2491 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2490})});
    V v_t_2492 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2491})});
    return (g_co_2eop_24s954557541x749476273(v_t_2492, heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2ecommands_2egetCmd_24s1824733856x1503967101_lam9, 1, 2, (V[]){v_hd_241, v_k_242})));
  }
  case TAG_Right: {
    V v_ver_2498 = heff_field(v_x_2486, 0);
    V v_ru_24x_2486_24Right = heff_take_reuse_n(v_x_2486, 1ULL, 1);
    V v_t_2499 = (g_heff_2ebuild_2eproject_2eversion(heff_dup(v_ver_2498)));
    switch (heff_tag_of(v_t_2499)) {
    case TAG_Nothing: {
      heff_drop(v_s_2433);
      heff_drop(v_x_2459);
      heff_drop(v_t_2417);
      heff_drop(v_pk_2432);
      V v_t_24100 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2egetCmd_24s1824733856x1503967101_str11), heff_strAppend(v_ver_2498, ((V)&g_heff_2ebuild_2ecommands_2egetCmd_24s1824733856x1503967101_str12)));
      V v_t_24101 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2egetCmd_24s1824733856x1503967101_str13), v_t_24100), ((V)&g_heff_2ebuild_2ecommands_2egetCmd_24s1824733856x1503967101_str14));
      V v_t_24102 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_24101, NTAG(TAG_MkUnit)});
      V v_t_24103 = heff_tag_at_n(v_ru_24x_2486_24Right, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24102})});
      V v_t_24104 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24103})});
      V v_t_24105 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24104})});
      return (g_co_2eop_24s954557541x749476273(v_t_24105, heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2ecommands_2egetCmd_24s1824733856x1503967101_lam10, 1, 2, (V[]){v_hd_241, v_k_242})));
    }
    case TAG_Just: {
      heff_take_n(v_t_2499, 0ULL, 1);
      V v_it_24112 = (g_prelude_2esplitFrom(((V)&g_heff_2ebuild_2ecommands_2egetCmd_24s1824733856x1503967101_str15), heff_dup(v_s_2433), MK_INT(0LL), NTAG(TAG_Nil)));
      V v_x1_24119;
      switch (heff_tag_of(v_it_24112)) {
      case TAG_Nil: {
        heff_drop_cell(v_ru_24x_2486_24Right, 1);
        v_x1_24119 = heff_tag_n(TAG_MkPair, 2, (V[]){v_s_2433, NTAG(TAG_Nothing)});
        break;
      }
      case TAG_Cons: {
        V v_path_24113 = heff_field(v_it_24112, 0);
        V v_it2_24114 = heff_field(v_it_24112, 1);
        V v_ru_24it_24112_24Cons = heff_take_reuse_n(v_it_24112, 3ULL, 2);
        switch (heff_tag_of(v_it2_24114)) {
        case TAG_Nil: {
          heff_drop_cell(v_ru_24x_2486_24Right, 1);
          heff_drop(v_path_24113);
          v_x1_24119 = heff_tag_at_n(v_ru_24it_24112_24Cons, TAG_MkPair, 2, (V[]){v_s_2433, NTAG(TAG_Nothing)});
          break;
        }
        case TAG_Cons: {
          V v_v_24115 = heff_field(v_it2_24114, 0);
          V v_it22_24116 = heff_field(v_it2_24114, 1);
          heff_take_n(v_it2_24114, 3ULL, 2);
          switch (heff_tag_of(v_it22_24116)) {
          case TAG_Nil: {
            heff_drop(v_s_2433);
            v_x1_24119 = heff_tag_at_n(v_ru_24it_24112_24Cons, TAG_MkPair, 2, (V[]){v_path_24113, heff_tag_at_n(v_ru_24x_2486_24Right, TAG_Just, 1, (V[]){v_v_24115})});
            break;
          }
          case TAG_Cons: {
            heff_take_n(v_it22_24116, 0ULL, 2);
            heff_drop_cell(v_ru_24x_2486_24Right, 1);
            heff_drop(v_path_24113);
            heff_drop(v_v_24115);
            v_x1_24119 = heff_tag_at_n(v_ru_24it_24112_24Cons, TAG_MkPair, 2, (V[]){v_s_2433, NTAG(TAG_Nothing)});
            break;
          }
          default: heff_nomatch(v_it22_24116);
          }
          break;
        }
        default: heff_nomatch(v_it2_24114);
        }
        break;
      }
      default: heff_nomatch(v_it_24112);
      }
      V v_t_24122;
      switch (heff_tag_of(v_x1_24119)) {
      case TAG_MkPair: {
        V v_x_24120 = heff_field(v_x1_24119, 0);
        heff_take_n(v_x1_24119, 1ULL, 2);
        v_t_24122 = v_x_24120;
        break;
      }
      default: heff_nomatch(v_x1_24119);
      }
      V v_c_24123 = (g_heff_2ebuild_2ecommands_2egetRequire_24s699978635x1427431246(v_x_2459, v_t_2417, v_pk_2432, v_t_24122, v_ver_2498));
      V f_ = v_c_24123;
      heff_room[0] = heff_dup(v_hd_241);
      heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2egetCmd_24s1824733856x1503967101_lam11, 1, 2, (V[]){v_hd_241, v_k_242});
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
    default: return heff_nomatch(v_t_2499);
    }
  }
  default: return heff_nomatch(v_x_2486);
  }
}
V g_heff_2ebuild_2ecommands_2egetCmd_24s1824733856x1503967101_lam6(V self, V *args) {
  V v_x_2459 = args[0];
  V v_s_2433 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  V v_t_2417 = heff_env(self)[3];
  V v_pk_2432 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_it_2460 = (g_prelude_2esplitFrom(((V)&g_heff_2ebuild_2ecommands_2egetCmd_24s1824733856x1503967101_str7), heff_dup(v_s_2433), MK_INT(0LL), NTAG(TAG_Nil)));
  V v_x1_2467;
  switch (heff_tag_of(v_it_2460)) {
  case TAG_Nil: {
    v_x1_2467 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_dup(v_s_2433), NTAG(TAG_Nothing)});
    break;
  }
  case TAG_Cons: {
    V v_path_2461 = heff_field(v_it_2460, 0);
    V v_it2_2462 = heff_field(v_it_2460, 1);
    V v_ru_24it_2460_24Cons = heff_take_reuse_n(v_it_2460, 3ULL, 2);
    switch (heff_tag_of(v_it2_2462)) {
    case TAG_Nil: {
      heff_drop(v_path_2461);
      v_x1_2467 = heff_tag_at_n(v_ru_24it_2460_24Cons, TAG_MkPair, 2, (V[]){heff_dup(v_s_2433), NTAG(TAG_Nothing)});
      break;
    }
    case TAG_Cons: {
      V v_v_2463 = heff_field(v_it2_2462, 0);
      V v_it22_2464 = heff_field(v_it2_2462, 1);
      heff_take_n(v_it2_2462, 3ULL, 2);
      switch (heff_tag_of(v_it22_2464)) {
      case TAG_Nil: {
        v_x1_2467 = heff_tag_at_n(v_ru_24it_2460_24Cons, TAG_MkPair, 2, (V[]){v_path_2461, heff_tag_n(TAG_Just, 1, (V[]){v_v_2463})});
        break;
      }
      case TAG_Cons: {
        heff_take_n(v_it22_2464, 0ULL, 2);
        heff_drop(v_path_2461);
        heff_drop(v_v_2463);
        v_x1_2467 = heff_tag_at_n(v_ru_24it_2460_24Cons, TAG_MkPair, 2, (V[]){heff_dup(v_s_2433), NTAG(TAG_Nothing)});
        break;
      }
      default: heff_nomatch(v_it22_2464);
      }
      break;
    }
    default: heff_nomatch(v_it2_2462);
    }
    break;
  }
  default: heff_nomatch(v_it_2460);
  }
  V v_t_2470;
  switch (heff_tag_of(v_x1_2467)) {
  case TAG_MkPair: {
    V v_y_2469 = heff_field(v_x1_2467, 1);
    heff_take_n(v_x1_2467, 2ULL, 2);
    v_t_2470 = v_y_2469;
    break;
  }
  default: heff_nomatch(v_x1_2467);
  }
  V v_c_2485;
  switch (heff_tag_of(v_t_2470)) {
  case TAG_Nothing: {
    V v_it_2471 = (g_prelude_2esplitFrom(((V)&g_heff_2ebuild_2ecommands_2egetCmd_24s1824733856x1503967101_str8), heff_dup(v_s_2433), MK_INT(0LL), NTAG(TAG_Nil)));
    V v_x1_2478;
    switch (heff_tag_of(v_it_2471)) {
    case TAG_Nil: {
      v_x1_2478 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_dup(v_s_2433), NTAG(TAG_Nothing)});
      break;
    }
    case TAG_Cons: {
      V v_path_2472 = heff_field(v_it_2471, 0);
      V v_it2_2473 = heff_field(v_it_2471, 1);
      V v_ru_24it_2471_24Cons = heff_take_reuse_n(v_it_2471, 3ULL, 2);
      switch (heff_tag_of(v_it2_2473)) {
      case TAG_Nil: {
        heff_drop(v_path_2472);
        v_x1_2478 = heff_tag_at_n(v_ru_24it_2471_24Cons, TAG_MkPair, 2, (V[]){heff_dup(v_s_2433), NTAG(TAG_Nothing)});
        break;
      }
      case TAG_Cons: {
        V v_v_2474 = heff_field(v_it2_2473, 0);
        V v_it22_2475 = heff_field(v_it2_2473, 1);
        heff_take_n(v_it2_2473, 3ULL, 2);
        switch (heff_tag_of(v_it22_2475)) {
        case TAG_Nil: {
          v_x1_2478 = heff_tag_at_n(v_ru_24it_2471_24Cons, TAG_MkPair, 2, (V[]){v_path_2472, heff_tag_n(TAG_Just, 1, (V[]){v_v_2474})});
          break;
        }
        case TAG_Cons: {
          heff_take_n(v_it22_2475, 0ULL, 2);
          heff_drop(v_path_2472);
          heff_drop(v_v_2474);
          v_x1_2478 = heff_tag_at_n(v_ru_24it_2471_24Cons, TAG_MkPair, 2, (V[]){heff_dup(v_s_2433), NTAG(TAG_Nothing)});
          break;
        }
        default: heff_nomatch(v_it22_2475);
        }
        break;
      }
      default: heff_nomatch(v_it2_2473);
      }
      break;
    }
    default: heff_nomatch(v_it_2471);
    }
    V v_t_2481;
    switch (heff_tag_of(v_x1_2478)) {
    case TAG_MkPair: {
      V v_x_2479 = heff_field(v_x1_2478, 0);
      heff_take_n(v_x1_2478, 1ULL, 2);
      v_t_2481 = v_x_2479;
      break;
    }
    default: heff_nomatch(v_x1_2478);
    }
    v_c_2485 = heff_tr(heff_call(((V)&g_heff_2ebuild_2ecommands_2enewestTag_24s53038353x309194843_clo), 1, (V[]){v_t_2481}));
    break;
  }
  case TAG_Just: {
    V v_v_2482 = heff_field(v_t_2470, 0);
    heff_take_n(v_t_2470, 1ULL, 1);
    v_c_2485 = heff_clo_n(g_heff_2ebuild_2ecommands_2egetCmd_24s1824733856x1503967101_lam7, 2, 1, (V[]){v_v_2482});
    break;
  }
  default: heff_nomatch(v_t_2470);
  }
  V f_ = v_c_2485;
  heff_room[0] = heff_dup(v_hd_241);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2egetCmd_24s1824733856x1503967101_lam8, 1, 6, (V[]){v_hd_241, v_k_242, v_s_2433, v_x_2459, v_t_2417, v_pk_2432});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2egetCmd_24s1824733856x1503967101_lam5(V self, V *args) {
  V v_x_2457 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_s_2433 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  V v_t_2417 = heff_env(self)[3];
  V v_pk_2432 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_c_2458 = (g_heff_2ebuild_2eload_2epathsFor_24s1509642847x2084081176(v_x_2457, ((V)&g_heff_2ebuild_2ecommands_2egetCmd_24s1824733856x1503967101_str6)));
  V f_ = v_c_2458;
  heff_room[0] = heff_dup(v_hd_241);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2egetCmd_24s1824733856x1503967101_lam6, 1, 5, (V[]){v_s_2433, v_hd_241, v_k_242, v_t_2417, v_pk_2432});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2egetCmd_24s1824733856x1503967101_lam1(V self, V *args) {
  V v_x_247 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  V v_spec_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_x_247)) {
  case TAG_Nothing: {
    heff_drop(v_spec_240);
    V v_t_248 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2egetCmd_24s1824733856x1503967101_str1), NTAG(TAG_MkUnit)});
    V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
    V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
    V v_t_2411 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
    return (g_co_2eop_24s954557541x749476273(v_t_2411, heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2ecommands_2egetCmd_24s1824733856x1503967101_lam2, 1, 2, (V[]){v_hd_241, v_k_242})));
  }
  case TAG_Just: {
    V v_t_2417 = heff_field(v_x_247, 0);
    V v_ru_24x_247_24Just = heff_take_reuse_n(v_x_247, 1ULL, 1);
    V v_x1_2418 = (g_heff_2ebuild_2eproject_2epackageLit(heff_dup(v_t_2417)));
    V v_t_2421;
    switch (heff_tag_of(v_x1_2418)) {
    case TAG_Left: {
      V v_p_2419 = heff_field(v_x1_2418, 0);
      heff_take_n(v_x1_2418, 1ULL, 1);
      v_t_2421 = heff_tag_at_n(v_ru_24x_247_24Just, TAG_Left, 1, (V[]){v_p_2419});
      break;
    }
    case TAG_Right: {
      V v_x_2420 = heff_field(v_x1_2418, 0);
      heff_take_n(v_x1_2418, 1ULL, 1);
      heff_drop_cell(v_ru_24x_247_24Just, 1);
      v_t_2421 = ({ V a_0 = v_x_2420; V r_ = (g_heff_2ebuild_2eproject_2epackageOf(a_0)); heff_drop(v_x_2420); r_; });
      break;
    }
    default: heff_nomatch(v_x1_2418);
    }
    switch (heff_tag_of(v_t_2421)) {
    case TAG_Left: {
      V v_ru_24t_2421_24Left = heff_take_reuse_n(v_t_2421, 0ULL, 1);
      heff_drop(v_spec_240);
      heff_drop(v_t_2417);
      V v_t_2423 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2egetCmd_24s1824733856x1503967101_str2), NTAG(TAG_MkUnit)});
      V v_t_2424 = heff_tag_at_n(v_ru_24t_2421_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
      V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
      V v_t_2426 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
      return (g_co_2eop_24s954557541x749476273(v_t_2426, heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2ecommands_2egetCmd_24s1824733856x1503967101_lam3, 1, 2, (V[]){v_hd_241, v_k_242})));
    }
    case TAG_Right: {
      V v_pk_2432 = heff_field(v_t_2421, 0);
      V v_ru_24t_2421_24Right = heff_take_reuse_n(v_t_2421, 1ULL, 1);
      switch (heff_tag_of(v_spec_240)) {
      case TAG_Nothing: {
        heff_drop(v_t_2417);
        heff_drop(v_pk_2432);
        heff_drop_cell(v_ru_24t_2421_24Right, 1);
        V f_ = heff_dup(g_heff_2ebuild_2ecommands_2egetAll_24s1876559814x2020229972_get());
        heff_room[0] = v_hd_241;
        heff_room[1] = v_k_242;
        if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
      }
      case TAG_Just: {
        V v_s_2433 = heff_field(v_spec_240, 0);
        V v_ru_24spec_240_24Just = heff_take_reuse_n(v_spec_240, 1ULL, 1);
        V v_it_2434 = (g_prelude_2esplitFrom(((V)&g_heff_2ebuild_2ecommands_2egetCmd_24s1824733856x1503967101_str3), heff_dup(v_s_2433), MK_INT(0LL), NTAG(TAG_Nil)));
        V v_x1_2441;
        switch (heff_tag_of(v_it_2434)) {
        case TAG_Nil: {
          heff_drop_cell(v_ru_24t_2421_24Right, 1);
          v_x1_2441 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_dup(v_s_2433), NTAG(TAG_Nothing)});
          break;
        }
        case TAG_Cons: {
          V v_path_2435 = heff_field(v_it_2434, 0);
          V v_it2_2436 = heff_field(v_it_2434, 1);
          V v_ru_24it_2434_24Cons = heff_take_reuse_n(v_it_2434, 3ULL, 2);
          switch (heff_tag_of(v_it2_2436)) {
          case TAG_Nil: {
            heff_drop_cell(v_ru_24t_2421_24Right, 1);
            heff_drop(v_path_2435);
            v_x1_2441 = heff_tag_at_n(v_ru_24it_2434_24Cons, TAG_MkPair, 2, (V[]){heff_dup(v_s_2433), NTAG(TAG_Nothing)});
            break;
          }
          case TAG_Cons: {
            V v_v_2437 = heff_field(v_it2_2436, 0);
            V v_it22_2438 = heff_field(v_it2_2436, 1);
            heff_take_n(v_it2_2436, 3ULL, 2);
            switch (heff_tag_of(v_it22_2438)) {
            case TAG_Nil: {
              v_x1_2441 = heff_tag_at_n(v_ru_24it_2434_24Cons, TAG_MkPair, 2, (V[]){v_path_2435, heff_tag_at_n(v_ru_24t_2421_24Right, TAG_Just, 1, (V[]){v_v_2437})});
              break;
            }
            case TAG_Cons: {
              heff_take_n(v_it22_2438, 0ULL, 2);
              heff_drop_cell(v_ru_24t_2421_24Right, 1);
              heff_drop(v_path_2435);
              heff_drop(v_v_2437);
              v_x1_2441 = heff_tag_at_n(v_ru_24it_2434_24Cons, TAG_MkPair, 2, (V[]){heff_dup(v_s_2433), NTAG(TAG_Nothing)});
              break;
            }
            default: heff_nomatch(v_it22_2438);
            }
            break;
          }
          default: heff_nomatch(v_it2_2436);
          }
          break;
        }
        default: heff_nomatch(v_it_2434);
        }
        V v_t_2444;
        switch (heff_tag_of(v_x1_2441)) {
        case TAG_MkPair: {
          V v_x_2442 = heff_field(v_x1_2441, 0);
          heff_take_n(v_x1_2441, 1ULL, 2);
          v_t_2444 = v_x_2442;
          break;
        }
        default: heff_nomatch(v_x1_2441);
        }
        if (heff_strEq_c(v_t_2444, heff_dup(g_heff_2ebuild_2eproject_2eheffModule_get()))) {
          heff_drop(v_t_2417);
          heff_drop(v_pk_2432);
          heff_drop(v_s_2433);
          V v_t_2446 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2egetCmd_24s1824733856x1503967101_str4), heff_dup(g_heff_2ebuild_2eproject_2erequireMsg_get())), ((V)&g_heff_2ebuild_2ecommands_2egetCmd_24s1824733856x1503967101_str5));
          V v_t_2447 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2446, NTAG(TAG_MkUnit)});
          V v_t_2448 = heff_tag_at_n(v_ru_24spec_240_24Just, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2447})});
          V v_t_2449 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2448})});
          V v_t_2450 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2449})});
          return (g_co_2eop_24s954557541x749476273(v_t_2450, heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2ecommands_2egetCmd_24s1824733856x1503967101_lam4, 1, 2, (V[]){v_hd_241, v_k_242})));
        } else {
          heff_drop_cell(v_ru_24spec_240_24Just, 1);
          V v_c_2456 = ((V)&g_heff_2ebuild_2ecommands_2ehostNow_24s1524073894x1314263325_clo);
          V f_ = v_c_2456;
          heff_room[0] = heff_dup(v_hd_241);
          heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2egetCmd_24s1824733856x1503967101_lam5, 1, 5, (V[]){v_hd_241, v_s_2433, v_k_242, v_t_2417, v_pk_2432});
          if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
          return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
        }
      }
      default: return heff_nomatch(v_spec_240);
      }
    }
    default: return heff_nomatch(v_t_2421);
    }
  }
  default: return heff_nomatch(v_x_247);
  }
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eappRead_24s565652333x1470992278_str0, 8, "build.hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eappRead_24s565652333x1470992278_str1, 1, "\012");
V g_heff_2ebuild_2ecommands_2eappRead_24s565652333x1470992278_lam0(V self, V *args);
V g_heff_2ebuild_2ecommands_2eappRead_24s565652333x1470992278_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2eappRead_24s565652333x1470992278_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2eappRead_24s565652333x1470992278_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2eappRead_24s565652333x1470992278_lam3(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eappRead_24s565652333x1470992278_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eappRead_24s565652333x1470992278_entry, 5, 0};

V g_heff_2ebuild_2ecommands_2eappRead_24s565652333x1470992278(V v_st_240, V v_t_241, V v_acc_242, V v_x_243, V v_x5_244) {
top: ;
  switch (heff_tag_of(v_x5_244)) {
  case TAG_Nothing: {
    heff_drop(v_t_241);
    heff_drop(v_x_243);
    return heff_clo_n(g_heff_2ebuild_2ecommands_2eappRead_24s565652333x1470992278_lam0, 2, 1, (V[]){v_acc_242});
  }
  case TAG_Just: {
    V v_text_247 = heff_field(v_x5_244, 0);
    heff_take_n(v_x5_244, 1ULL, 1);
    V v_t_248 = (g_heff_2ebuild_2eproject_2ereadBuild(heff_dup(v_text_247)));
    switch (heff_tag_of(v_t_248)) {
    case TAG_Left: {
      V v_p_249 = heff_field(v_t_248, 0);
      heff_take_n(v_t_248, 1ULL, 1);
      V v_t_2410 = (g_heff_2ebuild_2ecommands_2eappFile(v_st_240, v_t_241, v_x_243, ((V)&g_heff_2ebuild_2ecommands_2eappRead_24s565652333x1470992278_str0)));
      V v_str_2411 = (g_heff_2ebuild_2eload_2eproblemMsg(v_t_2410, v_text_247, v_p_249));
      return heff_clo_n(g_heff_2ebuild_2ecommands_2eappRead_24s565652333x1470992278_lam1, 2, 2, (V[]){v_str_2411, v_acc_242});
    }
    case TAG_Right: {
      V v_a_2421 = heff_field(v_t_248, 0);
      heff_take_n(v_t_248, 1ULL, 1);
      heff_drop(v_text_247);
      V v_c_2422 = (g_heff_2ebuild_2ecommands_2enotInProject_24s327269570x1050569655(v_st_240, heff_dup(v_t_241), heff_dup(heff_rfield(v_a_2421, 2))));
      return heff_clo_n(g_heff_2ebuild_2ecommands_2eappRead_24s565652333x1470992278_lam3, 2, 6, (V[]){v_c_2422, heff_dup(v_st_240), v_t_241, v_acc_242, v_x_243, v_a_2421});
    }
    default: return heff_nomatch(v_t_248);
    }
  }
  default: return heff_nomatch(v_x5_244);
  }
}
V g_heff_2ebuild_2ecommands_2eappRead_24s565652333x1470992278_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2eappRead_24s565652333x1470992278(a0, a[1], a[2], a[3], a[4]); heff_drop(a0); return r;
}
V g_heff_2ebuild_2ecommands_2eappRead_24s565652333x1470992278_lam0(V self, V *args) {
  V v_hd_245 = args[0];
  V v_k_246 = args[1];
  V v_acc_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_245);
  V f_ = v_k_246;
  args[0] = v_acc_242;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eappRead_24s565652333x1470992278_lam2(V self, V *args) {
  V v_x_2418 = args[0];
  V v_acc_242 = heff_env(self)[0];
  V v_k_2413 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2418);
  V v_t_2419 = heff_intAdd(heff_take_field(v_acc_242, 1), MK_INT(1LL));
  V v_t_2420 = ({ V rv_1 = v_t_2419; V rr_ = heff_rec_reuse_nf(v_acc_242, 1ULL, 2, shape_apps__bad, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
  V f_ = v_k_2413;
  args[0] = v_t_2420;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eappRead_24s565652333x1470992278_lam1(V self, V *args) {
  V v_hd_2412 = args[0];
  V v_k_2413 = args[1];
  V v_str_2411 = heff_env(self)[0];
  V v_acc_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2414 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_str_2411, ((V)&g_heff_2ebuild_2ecommands_2eappRead_24s565652333x1470992278_str1)), NTAG(TAG_MkUnit)});
  V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  return (g_co_2eop_24s954557541x749476273(v_t_2417, v_hd_2412, heff_clo_n(g_heff_2ebuild_2ecommands_2eappRead_24s565652333x1470992278_lam2, 1, 2, (V[]){v_acc_242, v_k_2413})));
}
V g_heff_2ebuild_2ecommands_2eappRead_24s565652333x1470992278_lam4(V self, V *args) {
  V v_x_2425 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_t_241 = heff_env(self)[1];
  V v_acc_242 = heff_env(self)[2];
  V v_x_243 = heff_env(self)[3];
  V v_a_2421 = heff_env(self)[4];
  V v_hd_2423 = heff_env(self)[5];
  V v_k_2424 = heff_env(self)[6];
  heff_clo_take(self, 7);
  return ({ V a_0 = v_st_240; V a_1 = v_t_241; V a_2 = v_acc_242; V a_3 = v_x_243; V a_4 = v_a_2421; V a_5 = v_x_2425; V a_6 = v_hd_2423; V a_7 = v_k_2424; V r_ = (g_heff_2ebuild_2ecommands_2eappShips_24s494931198x1067141729(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_st_240); r_; });
}
V g_heff_2ebuild_2ecommands_2eappRead_24s565652333x1470992278_lam3(V self, V *args) {
  V v_hd_2423 = args[0];
  V v_k_2424 = args[1];
  V v_c_2422 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_t_241 = heff_env(self)[2];
  V v_acc_242 = heff_env(self)[3];
  V v_x_243 = heff_env(self)[4];
  V v_a_2421 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V f_ = v_c_2422;
  args[0] = heff_dup(v_hd_2423);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2eappRead_24s565652333x1470992278_lam4, 1, 7, (V[]){v_st_240, v_t_241, v_acc_242, v_x_243, v_a_2421, v_hd_2423, v_k_2424});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eappsIn_24s1533067604x1981180975_str0, 8, "build.hf");
V g_heff_2ebuild_2ecommands_2eappsIn_24s1533067604x1981180975_lam0(V self, V *args);
V g_heff_2ebuild_2ecommands_2eappsIn_24s1533067604x1981180975_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eappsIn_24s1533067604x1981180975_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eappsIn_24s1533067604x1981180975_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2eappsIn_24s1533067604x1981180975_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2eappsIn_24s1533067604x1981180975_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2eappsIn_24s1533067604x1981180975_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2eappsIn_24s1533067604x1981180975_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eappsIn_24s1533067604x1981180975_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eappsIn_24s1533067604x1981180975_entry, 5, 0};

V g_heff_2ebuild_2ecommands_2eappsIn_24s1533067604x1981180975(V v_st_240, V v_t_241, V v_rd_242, V v_acc_243, V v_x5_244) {
top: ;
  switch (heff_tag_of(v_x5_244)) {
  case TAG_Nil: {
    heff_drop(v_t_241);
    heff_drop(v_rd_242);
    V v_t_245 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_take_field(v_acc_243, 0)));
    V v_x_246 = ({ V rv_0 = v_t_245; V rr_ = heff_rec_reuse_nf(v_acc_243, 2ULL, 2, shape_apps__bad, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
    return heff_clo_n(g_heff_2ebuild_2ecommands_2eappsIn_24s1533067604x1981180975_lam0, 2, 1, (V[]){v_x_246});
  }
  case TAG_Cons: {
    V v_x_249 = heff_field(v_x5_244, 0);
    V v_rest_2410 = heff_field(v_x5_244, 1);
    heff_take_n(v_x5_244, 3ULL, 2);
    V v_path_2411 = (g_heff_2ebuild_2ecommands_2eappFile(v_st_240, heff_dup(v_t_241), heff_dup(v_x_249), ((V)&g_heff_2ebuild_2ecommands_2eappsIn_24s1533067604x1981180975_str0)));
    return heff_clo_n(g_heff_2ebuild_2ecommands_2eappsIn_24s1533067604x1981180975_lam1, 2, 7, (V[]){v_path_2411, heff_dup(v_st_240), v_t_241, v_acc_243, v_x_249, v_rd_242, v_rest_2410});
  }
  default: return heff_nomatch(v_x5_244);
  }
}
V g_heff_2ebuild_2ecommands_2eappsIn_24s1533067604x1981180975_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2eappsIn_24s1533067604x1981180975(a0, a[1], a[2], a[3], a[4]); heff_drop(a0); return r;
}
V g_heff_2ebuild_2ecommands_2eappsIn_24s1533067604x1981180975_lam0(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_x_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_247);
  V f_ = v_k_248;
  args[0] = v_x_246;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eappsIn_24s1533067604x1981180975_lam2(V self, V *args) {
  V v_t_2414 = args[0];
  return v_t_2414;
}
V g_heff_2ebuild_2ecommands_2eappsIn_24s1533067604x1981180975_lam5(V self, V *args) {
  V v_x_2422 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_t_241 = heff_env(self)[1];
  V v_rd_242 = heff_env(self)[2];
  V v_x_2420 = heff_env(self)[3];
  V v_rest_2410 = heff_env(self)[4];
  V v_hd_2412 = heff_env(self)[5];
  V v_k_2413 = heff_env(self)[6];
  heff_clo_take(self, 7);
  heff_drop(v_x_2422);
  V v_t_2423 = ({ V a_0 = v_st_240; V a_1 = v_t_241; V a_2 = v_rd_242; V a_3 = v_x_2420; V a_4 = v_rest_2410; V r_ = (g_heff_2ebuild_2ecommands_2eappsIn_24s1533067604x1981180975(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_st_240); r_; });
  V f_ = v_t_2423;
  heff_room[0] = v_hd_2412;
  heff_room[1] = v_k_2413;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2eappsIn_24s1533067604x1981180975_lam4(V self, V *args) {
  V v_x_2420 = args[0];
  V v_rd_242 = heff_env(self)[0];
  V v_hd_2412 = heff_env(self)[1];
  V v_st_240 = heff_env(self)[2];
  V v_t_241 = heff_env(self)[3];
  V v_rest_2410 = heff_env(self)[4];
  V v_k_2413 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2421 = heff_tag_n(TAG_Complete, 2, (V[]){heff_dup(v_rd_242), NTAG(TAG_MkUnit)});
  return (g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InL, 1, (V[]){v_t_2421}), heff_dup(v_hd_2412), heff_clo_n(g_heff_2ebuild_2ecommands_2eappsIn_24s1533067604x1981180975_lam5, 1, 7, (V[]){v_st_240, v_t_241, v_rd_242, v_x_2420, v_rest_2410, v_hd_2412, v_k_2413})));
}
V g_heff_2ebuild_2ecommands_2eappsIn_24s1533067604x1981180975_lam3(V self, V *args) {
  V v_x_2418 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_t_241 = heff_env(self)[1];
  V v_acc_243 = heff_env(self)[2];
  V v_x_249 = heff_env(self)[3];
  V v_hd_2412 = heff_env(self)[4];
  V v_rd_242 = heff_env(self)[5];
  V v_rest_2410 = heff_env(self)[6];
  V v_k_2413 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_c_2419 = (g_heff_2ebuild_2ecommands_2eappRead_24s565652333x1470992278(v_st_240, heff_dup(v_t_241), v_acc_243, v_x_249, v_x_2418));
  V f_ = v_c_2419;
  heff_room[0] = heff_dup(v_hd_2412);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2eappsIn_24s1533067604x1981180975_lam4, 1, 6, (V[]){v_rd_242, v_hd_2412, v_st_240, v_t_241, v_rest_2410, v_k_2413});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2eappsIn_24s1533067604x1981180975_lam1(V self, V *args) {
  V v_hd_2412 = args[0];
  V v_k_2413 = args[1];
  V v_path_2411 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_t_241 = heff_env(self)[2];
  V v_acc_243 = heff_env(self)[3];
  V v_x_249 = heff_env(self)[4];
  V v_rd_242 = heff_env(self)[5];
  V v_rest_2410 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2415 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){v_path_2411, ((V)&g_heff_2ebuild_2ecommands_2eappsIn_24s1533067604x1981180975_lam2_clo)})});
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  return (g_co_2eop_24s954557541x749476273(v_t_2417, heff_dup(v_hd_2412), heff_clo_n(g_heff_2ebuild_2ecommands_2eappsIn_24s1533067604x1981180975_lam3, 1, 8, (V[]){v_st_240, v_t_241, v_acc_243, v_x_249, v_hd_2412, v_rd_242, v_rest_2410, v_k_2413})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishTested_24s2067279794x684806743_str0, 4, " of ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishTested_24s2067279794x684806743_str1, 37, " tests fail, or a file does not check");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishTested_24s2067279794x684806743_str2, 27, " expectations do not hold, ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishTested_24s2067279794x684806743_str3, 4, " of ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishTested_24s2067279794x684806743_str4, 14, "heff publish: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishTested_24s2067279794x684806743_str5, 1, "\012");
V g_heff_2ebuild_2ecommands_2epublishTested_24s2067279794x684806743_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2epublishTested_24s2067279794x684806743_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2epublishTested_24s2067279794x684806743_entry, 5, 0};

V g_heff_2ebuild_2ecommands_2epublishTested_24s2067279794x684806743(V v_v_240, V v_pk_241, V v_r_242, V v_z_243, V v_z_244) {
top: ;
  V v_t_2411;
  if (heff_intLt_c(MK_INT(0LL), heff_dup(heff_rfield(v_r_242, 3)))) {
    v_t_2411 = NTAG(TAG_True);
  } else {
    if (heff_intLt_c(MK_INT(0LL), heff_dup(heff_rfield(v_r_242, 6)))) {
      v_t_2411 = NTAG(TAG_True);
    } else {
      V v_t_247 = heff_dup(heff_rfield(v_r_242, 4));
      V v_x1_2410;
      switch (heff_tag_of(v_t_247)) {
      case TAG_Nil: {
        v_x1_2410 = NTAG(TAG_True);
        break;
      }
      case TAG_Cons: {
        heff_take_n(v_t_247, 0ULL, 2);
        v_x1_2410 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_t_247);
      }
      v_t_2411 = heff_bool(!(heff_dup(v_x1_2410) == NTAG(TAG_True)));
      heff_drop(v_x1_2410);
    }
  }
  if ((heff_dup(v_t_2411) == NTAG(TAG_True))) {
    heff_drop(v_v_240);
    heff_drop(v_pk_241);
    heff_drop(v_t_2411);
    V v_t_2412 = heff_intShow(heff_take_field(v_r_242, 3));
    V v_t_2413 = heff_intShow(heff_take_field(v_r_242, 2));
    V v_t_2414 = heff_intShow(heff_take_field(v_r_242, 6));
    V v_t_2415 = heff_intShow(heff_get_n(v_r_242, 5, 7));
    V v_t_2416 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2epublishTested_24s2067279794x684806743_str0), heff_strAppend(v_t_2415, ((V)&g_heff_2ebuild_2ecommands_2epublishTested_24s2067279794x684806743_str1)));
    V v_t_2417 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2epublishTested_24s2067279794x684806743_str2), heff_strAppend(v_t_2414, v_t_2416));
    V v_t_2418 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2epublishTested_24s2067279794x684806743_str3), heff_strAppend(v_t_2413, v_t_2417));
    V v_t_2419 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2epublishTested_24s2067279794x684806743_str4), heff_strAppend(v_t_2412, v_t_2418));
    V v_t_2420 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_t_2419, ((V)&g_heff_2ebuild_2ecommands_2epublishTested_24s2067279794x684806743_str5)), NTAG(TAG_MkUnit)});
    V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
    V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
    V v_t_2423 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
    return (g_co_2eop_24s954557541x749476273(v_t_2423, heff_dup(v_z_243), heff_clo_n(g_heff_2ebuild_2ecommands_2epublishTested_24s2067279794x684806743_lam0, 1, 2, (V[]){v_z_243, v_z_244})));
  } else {
    heff_drop_rec(v_r_242, 7);
    heff_drop(v_t_2411);
    return (g_heff_2ebuild_2ecommands_2epublishTag_24s229598417x236103835(v_v_240, v_pk_241, v_z_243, v_z_244));
  }
}
V g_heff_2ebuild_2ecommands_2epublishTested_24s2067279794x684806743_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2epublishTested_24s2067279794x684806743(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ebuild_2ecommands_2epublishTested_24s2067279794x684806743_lam0(V self, V *args) {
  V v_x_2424 = args[0];
  V v_z_243 = heff_env(self)[0];
  V v_z_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2424);
  V v_t_2425 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2425})});
  V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
  V v_t_2428 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
  return (g_co_2eop_24s954557541x749476273(v_t_2428, v_z_243, v_z_244));
}