// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_FailBecause 16014
#define TAG_FailDiffer 33429
#define TAG_Finish 61316
#define TAG_Holds 53574
#define TAG_JArray 50516
#define TAG_JBool 39030
#define TAG_JFloat 30719
#define TAG_JInt 58696
#define TAG_JNull 9039
#define TAG_JObject 38239
#define TAG_JString 41091
#define TAG_MakeDirectory 16793
#define TAG_MkGroup 19195
#define TAG_MkPath 49630
#define TAG_Platform 55558
#define TAG_Posix 44191
#define TAG_Start 63542
#define TAG_Windows 49101
#define TAG_Write 36323
#define TAG_WriteErr 37283
#define TAG_WriteFile 62589
#define TAG_Wrong 41905
#define TAG_Wrote 42089
#define LBL_c 317
#define LBL_discarded 1490202606
#define LBL_effect 641056956
#define LBL_end 310101
#define LBL_failure 1292767177
#define LBL_globals 352931696
#define LBL_goldens 436112074
#define LBL_key 315609
#define LBL_labels 836724522
#define LBL_name 9869138
#define LBL_next 9873338
#define LBL_notes 306367195
#define LBL_ok 10307
#define LBL_own 320000
#define LBL_prefix 967031229
#define LBL_property 1899481104
#define LBL_root 10001833
#define LBL_runs 10007567
#define LBL_seed 10021688
#define LBL_shrinks 154032591
#define LBL_skipped 231818613
#define LBL_style 311138763
#define LBL_top 324559
#define LBL_zig 330130
static uint32_t shape_name__key__effect[] = {LBL_name, LBL_key, LBL_effect};
static uint32_t shape_name__ok__skipped__property__runs__discarded__shrinks__labels__notes__failure__seed__goldens[] = {LBL_name, LBL_ok, LBL_skipped, LBL_property, LBL_runs, LBL_discarded, LBL_shrinks, LBL_labels, LBL_notes, LBL_failure, LBL_seed, LBL_goldens};
static uint32_t shape_prefix__end[] = {LBL_prefix, LBL_end};
V g_co_2eop_24s1676588087x1342415945(V, V, V, V, V, V, V, V);
V g_co_2eop_24s1676588087x1342415945_entry(V self, V *a);
extern Clo g_co_2eop_24s1676588087x1342415945_clo;
V g_co_2eop_24s22628809x1035315751(V, V, V);
V g_co_2eop_24s22628809x1035315751_entry(V self, V *a);
extern Clo g_co_2eop_24s22628809x1035315751_clo;
V g_co_2eop_24s495635622x733177935(V, V, V);
V g_co_2eop_24s495635622x733177935_entry(V self, V *a);
extern Clo g_co_2eop_24s495635622x733177935_clo;
V g_heff_2ebuild_2ebackcache_2ebackDir_get(void);
V g_heff_2ebuild_2ecommands_2eappFile(V, V, V, V);
V g_heff_2ebuild_2ecommands_2eappFile_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eappFile_clo;
V g_heff_2ebuild_2ecommands_2ebackDirOf(V);
V g_heff_2ebuild_2ecommands_2ebackDirOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ebackDirOf_clo;
V g_heff_2ebuild_2ecommands_2ecompileFoundC_24s878705973x548968787(V, V, V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecompileFoundC_24s878705973x548968787_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecompileFoundC_24s878705973x548968787_clo;
V g_heff_2ebuild_2ecommands_2egoldenSaid_24s472216893x1015725474(V, V, V);
V g_heff_2ebuild_2ecommands_2egoldenSaid_24s472216893x1015725474_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2egoldenSaid_24s472216893x1015725474_clo;
V g_heff_2ebuild_2ecommands_2egoldensGo_24s1718087514x1126158310(V, V, V, V);
V g_heff_2ebuild_2ecommands_2egoldensGo_24s1718087514x1126158310_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2egoldensGo_24s1718087514x1126158310_clo;
V g_heff_2ebuild_2ecommands_2ejsonFailure(V);
V g_heff_2ebuild_2ecommands_2ejsonFailure_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ejsonFailure_clo;
V g_heff_2ebuild_2ecommands_2ekeptParts_24s131303381x2005966716(V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ekeptParts_24s131303381x2005966716_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ekeptParts_24s131303381x2005966716_clo;
V g_heff_2ebuild_2ecommands_2eownRoot(V, V);
V g_heff_2ebuild_2ecommands_2eownRoot_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eownRoot_clo;
V g_heff_2ebuild_2ecommands_2eplaceBefore(V, V);
V g_heff_2ebuild_2ecommands_2eplaceBefore_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eplaceBefore_clo;
V g_heff_2ebuild_2ecommands_2eprovidesLeafC(V, V);
V g_heff_2ebuild_2ecommands_2eprovidesLeafC_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprovidesLeafC_clo;
V g_heff_2ebuild_2ecommands_2erunJob_24s58783120x925504139(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2erunJob_24s58783120x925504139_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2erunJob_24s58783120x925504139_clo;
V g_heff_2ebuild_2ecommands_2erunJobs_24s171025554x779625707(V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2erunJobs_24s171025554x779625707_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2erunJobs_24s171025554x779625707_clo;
V g_heff_2ebuild_2ecommands_2etestArgs(V, V, V, V);
V g_heff_2ebuild_2ecommands_2etestArgs_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2etestArgs_clo;
V g_heff_2ebuild_2ecommands_2etestText(V);
V g_heff_2ebuild_2ecommands_2etestText_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2etestText_clo;
V g_heff_2ebuild_2ecommands_2ewriteAll_24s2120021028x1422408481(V, V, V, V);
V g_heff_2ebuild_2ecommands_2ewriteAll_24s2120021028x1422408481_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ewriteAll_24s2120021028x1422408481_clo;
V g_heff_2ebuild_2ecommands_2ewriteOutC_24s1713743400x1441638619(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ewriteOutC_24s1713743400x1441638619_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ewriteOutC_24s1713743400x1441638619_clo;
V g_heff_2ebuild_2edriver_2ecandLeaves(V);
V g_heff_2ebuild_2edriver_2ecandLeaves_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ecandLeaves_clo;
V g_heff_2ebuild_2edriver_2ecatMaybesD(V);
V g_heff_2ebuild_2edriver_2ecatMaybesD_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ecatMaybesD_clo;
HeffT2 g_heff_2ebuild_2edriver_2eeffectOfKey_24cpr(V, V);
HeffT2 g_heff_2ebuild_2edriver_2efindRunnable_24cpr(V, V, V);
V g_heff_2ebuild_2edriver_2enubStrD(V);
V g_heff_2ebuild_2edriver_2enubStrD_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2enubStrD_clo;
V g_heff_2ecompile_2eemitc_2eoutputOf(V, V, V, V);
V g_heff_2ecompile_2eemitc_2eoutputOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2eoutputOf_clo;
V g_heff_2ecompile_2eemitc_2erunEnd(V, V);
V g_heff_2ecompile_2eemitc_2erunEnd_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2erunEnd_clo;
V g_heff_2ecompile_2eemitc_2ethreadsLine_get(void);
V g_heff_2ecompile_2elower_2elowerProgramC(V, V);
V g_heff_2ecompile_2elower_2elowerProgramC_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elower_2elowerProgramC_clo;
HeffT2 g_heff_2esyntax_2eformat_2eformat_24cpr(V);
HeffT2 g_json_2eat_24cpr(V, V);
V g_list_2eany_24s762674996x1009180162(V);
V g_list_2eany_24s762674996x1009180162_entry(V self, V *a);
extern Clo g_list_2eany_24s762674996x1009180162_clo;
V g_list_2edrop(V, V);
V g_list_2edrop_entry(V self, V *a);
extern Clo g_list_2edrop_clo;
V g_list_2efoldl_24s1300477078x2058851060(V, V);
V g_list_2efoldl_24s1300477078x2058851060_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1300477078x2058851060_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2ekeepIf(V, V);
V g_list_2ekeepIf_entry(V self, V *a);
extern Clo g_list_2ekeepIf_clo;
V g_list_2ekeepIf_24s1800580503x895008059(V);
V g_list_2ekeepIf_24s1800580503x895008059_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1800580503x895008059_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_std_2epath_2ejoin(V, V);
V g_std_2epath_2ejoin_entry(V self, V *a);
extern Clo g_std_2epath_2ejoin_clo;
V g_std_2epath_2enative_get(void);
V g_std_2epath_2eparse(V, V);
V g_std_2epath_2eparse_entry(V self, V *a);
extern Clo g_std_2epath_2eparse_clo;
HeffT3 g_std_2epath_2eparse_24cpr(V, V);
V g_std_2epath_2erender(V, V);
V g_std_2epath_2erender_entry(V self, V *a);
extern Clo g_std_2epath_2erender_clo;
HEFF_LIT(g_heff_2ebuild_2ecommands_2eownRoot_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eownRoot_str1, 3, "out");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eownRoot_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eownRoot_str3, 5, ".heff");
Clo g_heff_2ebuild_2ecommands_2eownRoot_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eownRoot_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2eownRoot(V v_st_240, V v_self_241) {
top: ;
  HeffT3 v_t_242 = (g_std_2epath_2eparse_24cpr(v_st_240, heff_dup(v_self_241)));
  V v_t_2412;
  {
    V v_field_243 = v_t_242.f[0];
    V v_field_244 = v_t_242.f[1];
    V v_field_245 = v_t_242.f[2];
    V v_d_246 = v_field_243;
    V v_a_247 = v_field_244;
    V v_xs_248 = v_field_245;
    V v_t_249 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_248));
    V v_xs_2410 = ({ V a_0 = MK_INT(1LL); V a_1 = v_t_249; V r_ = (g_list_2edrop(a_0, a_1)); heff_drop(v_t_249); r_; });
    V v_t_2411 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2410));
    v_t_2412 = heff_tag_n(TAG_MkPath, 3, (V[]){v_d_246, v_a_247, v_t_2411});
  }
  V v_s_2413 = ({ V a_0 = v_st_240; V a_1 = v_t_2412; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2412); r_; });
  HeffT3 v_t_2414 = (g_std_2epath_2eparse_24cpr(v_st_240, v_s_2413));
  V v_t_2424;
  {
    V v_field_2415 = v_t_2414.f[0];
    V v_field_2416 = v_t_2414.f[1];
    V v_field_2417 = v_t_2414.f[2];
    V v_x11_2418 = v_field_2415;
    heff_drop(v_x11_2418);
    V v_x12_2419 = v_field_2416;
    heff_drop(v_x12_2419);
    V v_xs_2420 = v_field_2417;
    V v_x1_2421 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2420));
    switch (heff_tag_of(v_x1_2421)) {
    case TAG_Nil: {
      v_t_2424 = ((V)&g_heff_2ebuild_2ecommands_2eownRoot_str0);
      break;
    }
    case TAG_Cons: {
      V v_x_2422 = heff_field(v_x1_2421, 0);
      heff_take_n(v_x1_2421, 1ULL, 2);
      v_t_2424 = v_x_2422;
      break;
    }
    default: heff_nomatch(v_x1_2421);
    }
  }
  V v_t_2461;
  if (heff_strEq_c(v_t_2424, ((V)&g_heff_2ebuild_2ecommands_2eownRoot_str1))) {
    HeffT3 v_t_2426 = (g_std_2epath_2eparse_24cpr(v_st_240, heff_dup(v_self_241)));
    V v_t_2436;
    {
      V v_field_2427 = v_t_2426.f[0];
      V v_field_2428 = v_t_2426.f[1];
      V v_field_2429 = v_t_2426.f[2];
      V v_d_2430 = v_field_2427;
      V v_a_2431 = v_field_2428;
      V v_xs_2432 = v_field_2429;
      V v_t_2433 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2432));
      V v_xs_2434 = ({ V a_0 = MK_INT(1LL); V a_1 = v_t_2433; V r_ = (g_list_2edrop(a_0, a_1)); heff_drop(v_t_2433); r_; });
      V v_t_2435 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2434));
      v_t_2436 = heff_tag_n(TAG_MkPath, 3, (V[]){v_d_2430, v_a_2431, v_t_2435});
    }
    V v_s_2437 = ({ V a_0 = v_st_240; V a_1 = v_t_2436; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2436); r_; });
    HeffT3 v_t_2438 = (g_std_2epath_2eparse_24cpr(v_st_240, v_s_2437));
    V v_t_2448;
    {
      V v_field_2439 = v_t_2438.f[0];
      V v_field_2440 = v_t_2438.f[1];
      V v_field_2441 = v_t_2438.f[2];
      V v_d_2442 = v_field_2439;
      V v_a_2443 = v_field_2440;
      V v_xs_2444 = v_field_2441;
      V v_t_2445 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2444));
      V v_xs_2446 = ({ V a_0 = MK_INT(1LL); V a_1 = v_t_2445; V r_ = (g_list_2edrop(a_0, a_1)); heff_drop(v_t_2445); r_; });
      V v_t_2447 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2446));
      v_t_2448 = heff_tag_n(TAG_MkPath, 3, (V[]){v_d_2442, v_a_2443, v_t_2447});
    }
    V v_s_2449 = ({ V a_0 = v_st_240; V a_1 = v_t_2448; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2448); r_; });
    HeffT3 v_t_2450 = (g_std_2epath_2eparse_24cpr(v_st_240, v_s_2449));
    V v_t_2460;
    {
      V v_field_2451 = v_t_2450.f[0];
      V v_field_2452 = v_t_2450.f[1];
      V v_field_2453 = v_t_2450.f[2];
      V v_x11_2454 = v_field_2451;
      heff_drop(v_x11_2454);
      V v_x12_2455 = v_field_2452;
      heff_drop(v_x12_2455);
      V v_xs_2456 = v_field_2453;
      V v_x1_2457 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2456));
      switch (heff_tag_of(v_x1_2457)) {
      case TAG_Nil: {
        v_t_2460 = ((V)&g_heff_2ebuild_2ecommands_2eownRoot_str2);
        break;
      }
      case TAG_Cons: {
        V v_x_2458 = heff_field(v_x1_2457, 0);
        heff_take_n(v_x1_2457, 1ULL, 2);
        v_t_2460 = v_x_2458;
        break;
      }
      default: heff_nomatch(v_x1_2457);
      }
    }
    v_t_2461 = heff_strEq(v_t_2460, ((V)&g_heff_2ebuild_2ecommands_2eownRoot_str3));
  } else {
    v_t_2461 = NTAG(TAG_False);
  }
  if ((heff_dup(v_t_2461) == NTAG(TAG_True))) {
    heff_drop(v_t_2461);
    HeffT3 v_t_2462 = (g_std_2epath_2eparse_24cpr(v_st_240, v_self_241));
    V v_t_2472;
    {
      V v_field_2463 = v_t_2462.f[0];
      V v_field_2464 = v_t_2462.f[1];
      V v_field_2465 = v_t_2462.f[2];
      V v_d_2466 = v_field_2463;
      V v_a_2467 = v_field_2464;
      V v_xs_2468 = v_field_2465;
      V v_t_2469 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2468));
      V v_xs_2470 = ({ V a_0 = MK_INT(1LL); V a_1 = v_t_2469; V r_ = (g_list_2edrop(a_0, a_1)); heff_drop(v_t_2469); r_; });
      V v_t_2471 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2470));
      v_t_2472 = heff_tag_n(TAG_MkPath, 3, (V[]){v_d_2466, v_a_2467, v_t_2471});
    }
    V v_s_2473 = ({ V a_0 = v_st_240; V a_1 = v_t_2472; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2472); r_; });
    HeffT3 v_t_2474 = (g_std_2epath_2eparse_24cpr(v_st_240, v_s_2473));
    V v_t_2484;
    {
      V v_field_2475 = v_t_2474.f[0];
      V v_field_2476 = v_t_2474.f[1];
      V v_field_2477 = v_t_2474.f[2];
      V v_d_2478 = v_field_2475;
      V v_a_2479 = v_field_2476;
      V v_xs_2480 = v_field_2477;
      V v_t_2481 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2480));
      V v_xs_2482 = ({ V a_0 = MK_INT(1LL); V a_1 = v_t_2481; V r_ = (g_list_2edrop(a_0, a_1)); heff_drop(v_t_2481); r_; });
      V v_t_2483 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2482));
      v_t_2484 = heff_tag_n(TAG_MkPath, 3, (V[]){v_d_2478, v_a_2479, v_t_2483});
    }
    V v_s_2485 = ({ V a_0 = v_st_240; V a_1 = v_t_2484; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2484); r_; });
    HeffT3 v_t_2486 = (g_std_2epath_2eparse_24cpr(v_st_240, v_s_2485));
    V v_t_2496;
    {
      V v_field_2487 = v_t_2486.f[0];
      V v_field_2488 = v_t_2486.f[1];
      V v_field_2489 = v_t_2486.f[2];
      V v_d_2490 = v_field_2487;
      V v_a_2491 = v_field_2488;
      V v_xs_2492 = v_field_2489;
      V v_t_2493 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2492));
      V v_xs_2494 = ({ V a_0 = MK_INT(1LL); V a_1 = v_t_2493; V r_ = (g_list_2edrop(a_0, a_1)); heff_drop(v_t_2493); r_; });
      V v_t_2495 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2494));
      v_t_2496 = heff_tag_n(TAG_MkPath, 3, (V[]){v_d_2490, v_a_2491, v_t_2495});
    }
    return ({ V a_0 = v_st_240; V a_1 = v_t_2496; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2496); r_; });
  } else {
    heff_drop(v_t_2461);
    HeffT3 v_t_2497 = (g_std_2epath_2eparse_24cpr(v_st_240, v_self_241));
    V v_t_24107;
    {
      V v_field_2498 = v_t_2497.f[0];
      V v_field_2499 = v_t_2497.f[1];
      V v_field_24100 = v_t_2497.f[2];
      V v_d_24101 = v_field_2498;
      V v_a_24102 = v_field_2499;
      V v_xs_24103 = v_field_24100;
      V v_t_24104 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_24103));
      V v_xs_24105 = ({ V a_0 = MK_INT(1LL); V a_1 = v_t_24104; V r_ = (g_list_2edrop(a_0, a_1)); heff_drop(v_t_24104); r_; });
      V v_t_24106 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_24105));
      v_t_24107 = heff_tag_n(TAG_MkPath, 3, (V[]){v_d_24101, v_a_24102, v_t_24106});
    }
    V v_s_24108 = ({ V a_0 = v_st_240; V a_1 = v_t_24107; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_24107); r_; });
    HeffT3 v_t_24109 = (g_std_2epath_2eparse_24cpr(v_st_240, v_s_24108));
    V v_t_24119;
    {
      V v_field_24110 = v_t_24109.f[0];
      V v_field_24111 = v_t_24109.f[1];
      V v_field_24112 = v_t_24109.f[2];
      V v_d_24113 = v_field_24110;
      V v_a_24114 = v_field_24111;
      V v_xs_24115 = v_field_24112;
      V v_t_24116 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_24115));
      V v_xs_24117 = ({ V a_0 = MK_INT(1LL); V a_1 = v_t_24116; V r_ = (g_list_2edrop(a_0, a_1)); heff_drop(v_t_24116); r_; });
      V v_t_24118 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_24117));
      v_t_24119 = heff_tag_n(TAG_MkPath, 3, (V[]){v_d_24113, v_a_24114, v_t_24118});
    }
    return ({ V a_0 = v_st_240; V a_1 = v_t_24119; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_24119); r_; });
  }
}
V g_heff_2ebuild_2ecommands_2eownRoot_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2eownRoot(a0, a[1]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebackDirOf_str0, 5, ".heff");
Clo g_heff_2ebuild_2ecommands_2ebackDirOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebackDirOf_entry, 1, 0};

V g_heff_2ebuild_2ecommands_2ebackDirOf(V v_ps_240) {
top: ;
  V v_st_241 = heff_dup(heff_rfield(v_ps_240, 5));
  V v_t_242 = (g_std_2epath_2eparse(v_st_241, heff_take_field(v_ps_240, 0)));
  V v_t_243 = (g_std_2epath_2eparse(v_st_241, ((V)&g_heff_2ebuild_2ecommands_2ebackDirOf_str0)));
  V v_t_244 = (g_std_2epath_2ejoin(v_t_242, v_t_243));
  V v_d_245 = ({ V a_0 = v_st_241; V a_1 = v_t_244; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_241); heff_drop(v_t_244); r_; });
  V v_st_246 = heff_get_n(v_ps_240, 5, 6);
  V v_t_247 = (g_std_2epath_2eparse(v_st_246, v_d_245));
  V v_t_248 = (g_std_2epath_2eparse(v_st_246, heff_dup(g_heff_2ebuild_2ebackcache_2ebackDir_get())));
  V v_t_249 = (g_std_2epath_2ejoin(v_t_247, v_t_248));
  return ({ V a_0 = v_st_246; V a_1 = v_t_249; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_246); heff_drop(v_t_249); r_; });
}
V g_heff_2ebuild_2ecommands_2ebackDirOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ebackDirOf(a[0]);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eappFile_str0, 3, "app");
Clo g_heff_2ebuild_2ecommands_2eappFile_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eappFile_entry, 4, 0};

V g_heff_2ebuild_2ecommands_2eappFile(V v_st_240, V v_t_241, V v_x_242, V v_f_243) {
top: ;
  V v_t_244 = (g_std_2epath_2eparse(v_st_240, ((V)&g_heff_2ebuild_2ecommands_2eappFile_str0)));
  V v_t_245 = (g_std_2epath_2eparse(v_st_240, v_x_242));
  V v_t_246 = (g_std_2epath_2ejoin(v_t_244, v_t_245));
  V v_a_247 = ({ V a_0 = v_st_240; V a_1 = v_t_246; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_246); r_; });
  V v_t_248 = (g_std_2epath_2eparse(v_st_240, v_a_247));
  V v_t_249 = (g_std_2epath_2eparse(v_st_240, v_f_243));
  V v_t_2410 = (g_std_2epath_2ejoin(v_t_248, v_t_249));
  V v_p_2411 = ({ V a_0 = v_st_240; V a_1 = v_t_2410; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2410); r_; });
  V v_t_2412 = (g_std_2epath_2eparse(v_st_240, heff_get_n(v_t_241, 0, 6)));
  V v_t_2413 = (g_std_2epath_2eparse(v_st_240, v_p_2411));
  V v_t_2414 = (g_std_2epath_2ejoin(v_t_2412, v_t_2413));
  return ({ V a_0 = v_st_240; V a_1 = v_t_2414; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2414); r_; });
}
V g_heff_2ebuild_2ecommands_2eappFile_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2eappFile(a0, a[1], a[2], a[3]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ejsonFailure_str0, 7, "because");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ejsonFailure_str1, 6, "differ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ejsonFailure_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ejsonFailure_str3, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ejsonFailure_str4, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ejsonFailure_str5, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ejsonFailure_str6, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ejsonFailure_str7, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ejsonFailure_str8, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ejsonFailure_str9, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ejsonFailure_str10, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ejsonFailure_str11, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ejsonFailure_str12, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ejsonFailure_str13, 0, "");
Clo g_heff_2ebuild_2ecommands_2ejsonFailure_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ejsonFailure_entry, 1, 0};

V g_heff_2ebuild_2ecommands_2ejsonFailure(V v_j_240) {
top: ;
  V v_t_241 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ejsonFailure_str0), NTAG(TAG_Nil)});
  HeffT2 v_t_242 = (g_json_2eat_24cpr(v_t_241, heff_dup(v_j_240)));
  {
    V v_field_244 = v_t_242.f[1];
    int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
    V v_t_2413;
    if ((v_tag_243 == ((int64_t)0ULL))) {
      V v_it1_246 = v_field_244;
      switch (heff_tag_of(v_it1_246)) {
      case TAG_JNull: {
        v_t_2413 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_JBool: {
        heff_take_n(v_it1_246, 0ULL, 1);
        v_t_2413 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_JInt: {
        heff_take_n(v_it1_246, 0ULL, 1);
        v_t_2413 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_JFloat: {
        heff_take_na(v_it1_246, 0ULL, 1);
        v_t_2413 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_JString: {
        V v_s_2410 = heff_field(v_it1_246, 0);
        V v_ru_24it1_246_24JString = heff_take_reuse_n(v_it1_246, 1ULL, 1);
        v_t_2413 = heff_tag_at_n(v_ru_24it1_246_24JString, TAG_Just, 1, (V[]){v_s_2410});
        break;
      }
      case TAG_JArray: {
        heff_take_n(v_it1_246, 0ULL, 1);
        v_t_2413 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_JObject: {
        heff_take_n(v_it1_246, 0ULL, 1);
        v_t_2413 = NTAG(TAG_Nothing);
        break;
      }
      default: heff_nomatch(v_it1_246);
      }
    } else {
      heff_drop(v_field_244);
      v_t_2413 = NTAG(TAG_Nothing);
    }
    switch (heff_tag_of(v_t_2413)) {
    case TAG_Nothing: {
      V v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ejsonFailure_str1), NTAG(TAG_Nil)});
      HeffT2 v_t_2415 = (g_json_2eat_24cpr(v_t_2414, v_j_240));
      {
        V v_field_2417 = v_t_2415.f[1];
        int64_t v_tag_2416 = ((int64_t)v_t_2415.f[0]);
        if ((v_tag_2416 == ((int64_t)0ULL))) {
          V v_it1_2419 = v_field_2417;
          switch (heff_tag_of(v_it1_2419)) {
          case TAG_JNull: {
            return NTAG(TAG_Nothing);
          }
          case TAG_JBool: {
            heff_take_n(v_it1_2419, 0ULL, 1);
            return NTAG(TAG_Nothing);
          }
          case TAG_JInt: {
            heff_take_n(v_it1_2419, 0ULL, 1);
            return NTAG(TAG_Nothing);
          }
          case TAG_JFloat: {
            heff_take_na(v_it1_2419, 0ULL, 1);
            return NTAG(TAG_Nothing);
          }
          case TAG_JString: {
            heff_take_n(v_it1_2419, 0ULL, 1);
            return NTAG(TAG_Nothing);
          }
          case TAG_JArray: {
            V v_xs_2424 = heff_field(v_it1_2419, 0);
            V v_ru_24it1_2419_24JArray = heff_take_reuse_n(v_it1_2419, 1ULL, 1);
            switch (heff_tag_of(v_xs_2424)) {
            case TAG_Nil: {
              heff_drop_cell(v_ru_24it1_2419_24JArray, 1);
              return NTAG(TAG_Nothing);
            }
            case TAG_Cons: {
              V v_expected_2425 = heff_field(v_xs_2424, 0);
              V v_it12_2426 = heff_field(v_xs_2424, 1);
              heff_take_n(v_xs_2424, 3ULL, 2);
              switch (heff_tag_of(v_it12_2426)) {
              case TAG_Nil: {
                heff_drop_cell(v_ru_24it1_2419_24JArray, 1);
                heff_drop(v_expected_2425);
                return NTAG(TAG_Nothing);
              }
              case TAG_Cons: {
                V v_got_2427 = heff_field(v_it12_2426, 0);
                heff_take_n(v_it12_2426, 1ULL, 2);
                V v_t_2435;
                switch (heff_tag_of(v_expected_2425)) {
                case TAG_JNull: {
                  v_t_2435 = ((V)&g_heff_2ebuild_2ecommands_2ejsonFailure_str2);
                  break;
                }
                case TAG_JBool: {
                  heff_take_n(v_expected_2425, 0ULL, 1);
                  v_t_2435 = ((V)&g_heff_2ebuild_2ecommands_2ejsonFailure_str3);
                  break;
                }
                case TAG_JInt: {
                  heff_take_n(v_expected_2425, 0ULL, 1);
                  v_t_2435 = ((V)&g_heff_2ebuild_2ecommands_2ejsonFailure_str4);
                  break;
                }
                case TAG_JFloat: {
                  heff_take_na(v_expected_2425, 0ULL, 1);
                  v_t_2435 = ((V)&g_heff_2ebuild_2ecommands_2ejsonFailure_str5);
                  break;
                }
                case TAG_JString: {
                  V v_t_2432 = heff_field(v_expected_2425, 0);
                  heff_take_n(v_expected_2425, 1ULL, 1);
                  v_t_2435 = v_t_2432;
                  break;
                }
                case TAG_JArray: {
                  heff_take_n(v_expected_2425, 0ULL, 1);
                  v_t_2435 = ((V)&g_heff_2ebuild_2ecommands_2ejsonFailure_str6);
                  break;
                }
                case TAG_JObject: {
                  heff_take_n(v_expected_2425, 0ULL, 1);
                  v_t_2435 = ((V)&g_heff_2ebuild_2ecommands_2ejsonFailure_str7);
                  break;
                }
                default: heff_nomatch(v_expected_2425);
                }
                V v_t_2442;
                switch (heff_tag_of(v_got_2427)) {
                case TAG_JNull: {
                  v_t_2442 = ((V)&g_heff_2ebuild_2ecommands_2ejsonFailure_str8);
                  break;
                }
                case TAG_JBool: {
                  heff_take_n(v_got_2427, 0ULL, 1);
                  v_t_2442 = ((V)&g_heff_2ebuild_2ecommands_2ejsonFailure_str9);
                  break;
                }
                case TAG_JInt: {
                  heff_take_n(v_got_2427, 0ULL, 1);
                  v_t_2442 = ((V)&g_heff_2ebuild_2ecommands_2ejsonFailure_str10);
                  break;
                }
                case TAG_JFloat: {
                  heff_take_na(v_got_2427, 0ULL, 1);
                  v_t_2442 = ((V)&g_heff_2ebuild_2ecommands_2ejsonFailure_str11);
                  break;
                }
                case TAG_JString: {
                  V v_t_2439 = heff_field(v_got_2427, 0);
                  heff_take_n(v_got_2427, 1ULL, 1);
                  v_t_2442 = v_t_2439;
                  break;
                }
                case TAG_JArray: {
                  heff_take_n(v_got_2427, 0ULL, 1);
                  v_t_2442 = ((V)&g_heff_2ebuild_2ecommands_2ejsonFailure_str12);
                  break;
                }
                case TAG_JObject: {
                  heff_take_n(v_got_2427, 0ULL, 1);
                  v_t_2442 = ((V)&g_heff_2ebuild_2ecommands_2ejsonFailure_str13);
                  break;
                }
                default: heff_nomatch(v_got_2427);
                }
                return heff_tag_at_n(v_ru_24it1_2419_24JArray, TAG_Just, 1, (V[]){heff_tag_n(TAG_FailDiffer, 2, (V[]){v_t_2435, v_t_2442})});
              }
              default: return heff_nomatch(v_it12_2426);
              }
            }
            default: return heff_nomatch(v_xs_2424);
            }
          }
          case TAG_JObject: {
            heff_take_n(v_it1_2419, 0ULL, 1);
            return NTAG(TAG_Nothing);
          }
          default: return heff_nomatch(v_it1_2419);
          }
        } else {
          heff_drop(v_field_2417);
          return NTAG(TAG_Nothing);
        }
      }
    }
    case TAG_Just: {
      V v_why_2444 = heff_field(v_t_2413, 0);
      V v_ru_24t_2413_24Just = heff_take_reuse_n(v_t_2413, 1ULL, 1);
      heff_drop(v_j_240);
      return heff_tag_at_n(v_ru_24t_2413_24Just, TAG_Just, 1, (V[]){heff_tag_n(TAG_FailBecause, 1, (V[]){v_why_2444})});
    }
    default: return heff_nomatch(v_t_2413);
    }
  }
}
V g_heff_2ebuild_2ecommands_2ejsonFailure_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ejsonFailure(a[0]);
}
Clo g_heff_2ebuild_2ecommands_2eplaceBefore_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eplaceBefore_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2eplaceBefore(V v_x1_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_a_242 = heff_field(v_x1_240, 0);
    V v_argv_243 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      return NTAG(TAG_False);
    }
    case TAG_Cons: {
      V v_b_244 = heff_field(v_x2_241, 0);
      V v_bs_245 = heff_field(v_x2_241, 1);
      if (heff_intEq_c_lent(v_a_242, v_b_244, 0)) {
        V t_0 = v_argv_243;
        V t_1 = v_bs_245;
        v_x1_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      } else {
        return heff_intLt_lent(v_a_242, v_b_244, 0);
      }
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2ecommands_2eplaceBefore_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ebuild_2ecommands_2eplaceBefore(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestArgs_str0, 6, "--seed");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestArgs_str1, 5, "--run");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestArgs_str2, 6, "--jobs");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestArgs_str3, 4, "test");
Clo g_heff_2ebuild_2ecommands_2etestArgs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2etestArgs_entry, 4, 0};

V g_heff_2ebuild_2ecommands_2etestArgs(V v_seed_240, V v_pattern_241, V v_jobs_242, V v_given_243) {
top: ;
  V v_t_246;
  switch (heff_tag_of(v_seed_240)) {
  case TAG_Nothing: {
    v_t_246 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_v_244 = heff_field(v_seed_240, 0);
    V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_v_244), NTAG(TAG_Nil)});
    v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2etestArgs_str0), v_t_245});
    break;
  }
  default: heff_nomatch(v_seed_240);
  }
  V v_t_249;
  switch (heff_tag_of(v_pattern_241)) {
  case TAG_Nothing: {
    v_t_249 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_v_247 = heff_field(v_pattern_241, 0);
    V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_v_247), NTAG(TAG_Nil)});
    v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2etestArgs_str1), v_t_248});
    break;
  }
  default: heff_nomatch(v_pattern_241);
  }
  V v_t_2412;
  switch (heff_tag_of(v_jobs_242)) {
  case TAG_Nothing: {
    v_t_2412 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_v_2410 = heff_field(v_jobs_242, 0);
    V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_v_2410), NTAG(TAG_Nil)});
    v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2etestArgs_str2), v_t_2411});
    break;
  }
  default: heff_nomatch(v_jobs_242);
  }
  V v_t_2413 = (g_prelude_2e_2b_2b(v_t_2412, v_given_243));
  V v_t_2414 = (g_prelude_2e_2b_2b(v_t_249, v_t_2413));
  V v_t_2415 = (g_prelude_2e_2b_2b(v_t_246, v_t_2414));
  return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2etestArgs_str3), v_t_2415});
}
V g_heff_2ebuild_2ecommands_2etestArgs_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V r = g_heff_2ebuild_2ecommands_2etestArgs(a0, a1, a2, a[3]); heff_drop(a0); heff_drop(a1); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestText_str0, 7, "import ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestText_str1, 9, ".greeting");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestText_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestText_str3, 8, "greets =");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestText_str4, 64, "  unit \"greeting\" (assertEqual (greeting \"test\") \"Hello, test!\")");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestText_str5, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestText_str6, 13, "greets : Test");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestText_str7, 12, "import check");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestText_str8, 20, "module test.greeting");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestText_str9, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestText_str10, 9, "-- tests.");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestText_str11, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestText_str12, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestText_str13, 68, "-- `heff test` runs the tests of every file of test/ (and src/): the");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestText_str14, 71, "-- definitions of type `Test` (lib/check.hf), after the watches and doc");
Clo g_heff_2ebuild_2ecommands_2etestText_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2etestText_entry, 1, 0};

V g_heff_2ebuild_2ecommands_2etestText(V v_name_240) {
top: ;
  V v_t_241 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2etestText_str0), heff_strAppend(v_name_240, ((V)&g_heff_2ebuild_2ecommands_2etestText_str1)));
  V v_t_242 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2etestText_str2), NTAG(TAG_Nil)});
  V v_t_243 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2etestText_str3), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2etestText_str4), v_t_242})});
  V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2etestText_str5), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2etestText_str6), v_t_243})});
  V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2etestText_str7), heff_tag_n(TAG_Cons, 2, (V[]){v_t_241, v_t_244})});
  V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2etestText_str8), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2etestText_str9), v_t_245})});
  V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2etestText_str10), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2etestText_str11), v_t_246})});
  return ({ V a_0 = ((V)&g_heff_2ebuild_2ecommands_2etestText_str12); V a_1 = ((V)&g_heff_2ebuild_2ecommands_2etestText_str13); V b_2 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2etestText_str14), v_t_247}); V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, b_2)); heff_drop(b_2); r_; });
}
V g_heff_2ebuild_2ecommands_2etestText_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2etestText(a[0]);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileFoundC_24s878705973x548968787_str0, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileFoundC_24s878705973x548968787_str1, 6, "heff: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileFoundC_24s878705973x548968787_str2, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileFoundC_24s878705973x548968787_str3, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileFoundC_24s878705973x548968787_str4, 6, "heff: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileFoundC_24s878705973x548968787_str5, 1, "/");
V g_heff_2ebuild_2ecommands_2ecompileFoundC_24s878705973x548968787_lam0(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileFoundC_24s878705973x548968787_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileFoundC_24s878705973x548968787_lam2(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ecompileFoundC_24s878705973x548968787_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecompileFoundC_24s878705973x548968787_entry, 11, 0};

V g_heff_2ebuild_2ecommands_2ecompileFoundC_24s878705973x548968787(V v_bi_240, V v_file_241, V v_name_242, V v_outPath_243, V v_rt_244, V v_failed_245, V v_done_246, V v_c_247, V v_available_248, V v_z_249, V v_z_2410) {
top: ;
  V v_t_2411 = (g_list_2ekeepIf_24s1800580503x895008059(heff_dup(heff_rfield(v_c_247, 7))));
  V v_t_2419 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileFoundC_24s878705973x548968787_lam0, 1, 1, (V[]){heff_dup(v_c_247)}), v_t_2411));
  V v_t_2420 = (g_heff_2ebuild_2edriver_2ecatMaybesD(v_t_2419));
  V v_t_2421 = ({ V a_0 = v_t_2420; V r_ = (g_heff_2ebuild_2edriver_2ecandLeaves(a_0)); heff_drop(v_t_2420); r_; });
  V v_t_2422 = (g_heff_2ebuild_2edriver_2enubStrD(v_t_2421));
  V v_t_2424 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileFoundC_24s878705973x548968787_lam1, 1, 1, (V[]){heff_dup(v_available_248)}), v_t_2422));
  HeffT2 v_t_2425 = ({ V a_0 = v_t_2424; V a_1 = heff_dup(v_c_247); V a_2 = v_name_242; HeffT2 r_ = (g_heff_2ebuild_2edriver_2efindRunnable_24cpr(a_0, a_1, a_2)); heff_drop(v_t_2424); r_; });
  {
    V v_field_2427 = v_t_2425.f[1];
    int64_t v_tag_2426 = ((int64_t)v_t_2425.f[0]);
    if ((v_tag_2426 == ((int64_t)0ULL))) {
      heff_drop(v_bi_240);
      heff_drop(v_outPath_243);
      heff_drop_rec(v_rt_244, 2);
      heff_drop(v_done_246);
      heff_drop_rec(v_c_247, 14);
      heff_drop(v_available_248);
      V v_why_2429 = v_field_2427;
      V v_t_2430 = heff_strAppend(heff_dup(v_file_241), heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ecompileFoundC_24s878705973x548968787_str0), heff_dup(v_why_2429)));
      V v_t_2431 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ecompileFoundC_24s878705973x548968787_str1), v_t_2430), ((V)&g_heff_2ebuild_2ecommands_2ecompileFoundC_24s878705973x548968787_str2));
      V v_t_2432 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2431, NTAG(TAG_MkUnit)});
      V v_t_2433 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2432})});
      V v_t_2434 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2433})});
      V v_t_2435 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2434})});
      V v_t_2436 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2435})});
      V v_t_2437 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2436})});
      V v_t_2438 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2437})});
      return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2438}), heff_dup(v_z_249), heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileFoundC_24s878705973x548968787_lam2, 1, 5, (V[]){v_file_241, v_why_2429, v_failed_245, v_z_249, v_z_2410})));
    } else {
      heff_drop(v_file_241);
      heff_drop(v_failed_245);
      V v_r_2441 = v_field_2427;
      int64_t v_t_2442 = (heff_unbox_word(heff_strLength_lent(v_outPath_243, 0)) - ((int64_t)1ULL));
      V v_t_2443 = heff_strSlice(heff_dup(v_outPath_243), heff_box_word(v_t_2442), heff_strLength_lent(v_outPath_243, 0));
      if (heff_strEq_c(v_t_2443, ((V)&g_heff_2ebuild_2ecommands_2ecompileFoundC_24s878705973x548968787_str5))) {
        int64_t v_t_2445 = (heff_unbox_word(heff_strLength_lent(v_outPath_243, 0)) - ((int64_t)1ULL));
        return (g_heff_2ebuild_2ecommands_2ekeptParts_24s131303381x2005966716(v_bi_240, heff_strSlice(v_outPath_243, MK_INT(0LL), heff_box_word(v_t_2445)), v_rt_244, v_done_246, v_c_247, v_available_248, v_r_2441, v_z_249, v_z_2410));
      } else {
        heff_drop(v_bi_240);
        V v_t_2446 = (g_list_2eany_24s762674996x1009180162(v_available_248));
        V v_t_2447;
        if ((heff_dup(v_t_2446) == NTAG(TAG_True))) {
          heff_drop(v_t_2446);
          v_t_2447 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(g_heff_2ecompile_2eemitc_2ethreadsLine_get()), NTAG(TAG_Nil)});
        } else {
          heff_drop(v_t_2446);
          v_t_2447 = NTAG(TAG_Nil);
        }
        V v_t_2448 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eemitc_2erunEnd_clo), 1, (V[]){heff_take_field(v_r_2441, 1)}));
        V v_t_2449 = heff_get_n(heff_get_n(v_c_247, 5, 14), 0, 9);
        V v_t_2450 = (g_heff_2ecompile_2elower_2elowerProgramC(v_t_2449, heff_get_n(v_r_2441, 0, 2)));
        V v_t_2451 = (g_heff_2ecompile_2eemitc_2eoutputOf(heff_take_field(v_rt_244, 0), v_available_248, heff_rec_n(2, shape_prefix__end, (V[]){v_t_2447, v_t_2448}), v_t_2450));
        return (g_heff_2ebuild_2ecommands_2ewriteOutC_24s1713743400x1441638619(v_outPath_243, heff_get_n(v_rt_244, 1, 2), v_done_246, v_t_2451, v_z_249, v_z_2410));
      }
    }
  }
}
V g_heff_2ebuild_2ecommands_2ecompileFoundC_24s878705973x548968787_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ebuild_2ecommands_2ecompileFoundC_24s878705973x548968787(a[0], a[1], a2, a[3], a[4], a[5], a[6], a[7], a[8], a[9], a[10]); heff_drop(a2); return r;
}
V g_heff_2ebuild_2ecommands_2ecompileFoundC_24s878705973x548968787_lam0(V self, V *args) {
  V v_o_2412 = args[0];
  V v_c_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2413 = (g_heff_2ebuild_2edriver_2eeffectOfKey_24cpr(v_c_247, heff_rfield(v_o_2412, 1)));
  {
    V v_field_2415 = v_t_2413.f[1];
    int64_t v_tag_2414 = ((int64_t)v_t_2413.f[0]);
    if ((v_tag_2414 == ((int64_t)0ULL))) {
      V v_eff_2417 = v_field_2415;
      V v_t_2418 = heff_rec_n(3, shape_name__key__effect, (V[]){heff_take_field(v_o_2412, 0), heff_get_n(v_o_2412, 1, 2), v_eff_2417});
      return heff_tag_n(TAG_Just, 1, (V[]){v_t_2418});
    } else {
      heff_drop_rec(v_o_2412, 2);
      heff_drop(v_field_2415);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_heff_2ebuild_2ecommands_2ecompileFoundC_24s878705973x548968787_lam1(V self, V *args) {
  V v_k_2423 = args[0];
  V v_available_248 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_available_248; V a_1 = v_k_2423; V r_ = (g_heff_2ebuild_2ecommands_2eprovidesLeafC(a_0, a_1)); heff_drop(v_available_248); r_; });
}
V g_heff_2ebuild_2ecommands_2ecompileFoundC_24s878705973x548968787_lam2(V self, V *args) {
  V v_x_2439 = args[0];
  V v_file_241 = heff_env(self)[0];
  V v_why_2429 = heff_env(self)[1];
  V v_failed_245 = heff_env(self)[2];
  V v_z_249 = heff_env(self)[3];
  V v_z_2410 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2439);
  V v_t_2440 = heff_strAppend(v_file_241, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ecompileFoundC_24s878705973x548968787_str3), v_why_2429));
  V f_ = v_failed_245;
  heff_room[0] = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ecompileFoundC_24s878705973x548968787_str4), v_t_2440);
  heff_room[1] = v_z_249;
  heff_room[2] = v_z_2410;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
V g_heff_2ebuild_2ecommands_2erunJobs_24s171025554x779625707_lam0(V self, V *args);
V g_heff_2ebuild_2ecommands_2erunJobs_24s171025554x779625707_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2erunJobs_24s171025554x779625707_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2erunJobs_24s171025554x779625707_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2erunJobs_24s171025554x779625707_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2erunJobs_24s171025554x779625707_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2erunJobs_24s171025554x779625707_lam1, 1, 0};
V g_heff_2ebuild_2ecommands_2erunJobs_24s171025554x779625707_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2erunJobs_24s171025554x779625707_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2erunJobs_24s171025554x779625707_lam6(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2erunJobs_24s171025554x779625707_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2erunJobs_24s171025554x779625707_lam6, 1, 0};
V g_heff_2ebuild_2ecommands_2erunJobs_24s171025554x779625707_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2erunJobs_24s171025554x779625707_lam8(V self, V *args);
V g_heff_2ebuild_2ecommands_2erunJobs_24s171025554x779625707_lam7(V self, V *args);
V g_heff_2ebuild_2ecommands_2erunJobs_24s171025554x779625707_lam10(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2erunJobs_24s171025554x779625707_lam10_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2erunJobs_24s171025554x779625707_lam10, 1, 0};
V g_heff_2ebuild_2ecommands_2erunJobs_24s171025554x779625707_lam9(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2erunJobs_24s171025554x779625707_lam9_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2erunJobs_24s171025554x779625707_lam9, 1, 0};
V g_heff_2ebuild_2ecommands_2erunJobs_24s171025554x779625707_lam12(V self, V *args);
V g_heff_2ebuild_2ecommands_2erunJobs_24s171025554x779625707_lam11(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2erunJobs_24s171025554x779625707_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2erunJobs_24s171025554x779625707_entry, 8, 0};

V g_heff_2ebuild_2ecommands_2erunJobs_24s171025554x779625707(V v_ex_240, V v_rx_241, V v_sel_242, V v_jobs_243, V v_g_244, V v_x4_245, V v_pending_246, V v_done_247) {
top: ;
  switch (heff_tag_of(v_x4_245)) {
  case TAG_Nil: {
    if (heff_intEq_c_lent(v_pending_246, MK_INT(0LL), 2)) {
      heff_drop(v_ex_240);
      heff_drop(v_rx_241);
      heff_drop(v_sel_242);
      heff_drop(v_jobs_243);
      heff_drop(v_pending_246);
      return heff_clo_n(g_heff_2ebuild_2ecommands_2erunJobs_24s171025554x779625707_lam0, 2, 1, (V[]){v_done_247});
    } else {
      V v_c_2416;
      switch (heff_tag_of(v_g_244)) {
      case TAG_MkGroup: {
        V v_i_2411 = heff_field(v_g_244, 0);
        V v_t_2414 = heff_tag_n(TAG_Finish, 3, (V[]){heff_dup(v_i_2411), NTAG(TAG_True), ((V)&g_heff_2ebuild_2ecommands_2erunJobs_24s171025554x779625707_lam1_clo)});
        V v_t_2415 = heff_tr(heff_call(heff_dup(v_rx_241), 1, (V[]){v_t_2414}));
        v_c_2416 = heff_tr(heff_call(((V)&g_co_2eop_24s22628809x1035315751_clo), 1, (V[]){v_t_2415}));
        break;
      }
      default: heff_nomatch(v_g_244);
      }
      return heff_clo_n(g_heff_2ebuild_2ecommands_2erunJobs_24s171025554x779625707_lam3, 2, 8, (V[]){v_c_2416, v_done_247, v_ex_240, v_rx_241, v_sel_242, v_jobs_243, heff_dup(v_g_244), v_pending_246});
    }
  }
  case TAG_Cons: {
    V v_j_2425 = heff_field(v_x4_245, 0);
    V v_rest_2426 = heff_field(v_x4_245, 1);
    heff_take_n(v_x4_245, 3ULL, 2);
    if (heff_intLt_c_lent(v_pending_246, v_jobs_243, 0)) {
      V v_c_2433;
      switch (heff_tag_of(v_g_244)) {
      case TAG_MkGroup: {
        V v_i_2428 = heff_field(v_g_244, 0);
        V v_t_2432 = heff_tr(heff_call(heff_dup(v_rx_241), 1, (V[]){heff_tag_n(TAG_Start, 2, (V[]){heff_dup(v_i_2428), heff_clo_n(g_heff_2ebuild_2ecommands_2erunJobs_24s171025554x779625707_lam5, 1, 3, (V[]){heff_dup(v_ex_240), heff_dup(v_sel_242), v_j_2425})})}));
        v_c_2433 = heff_tr(heff_call(((V)&g_co_2eop_24s22628809x1035315751_clo), 1, (V[]){v_t_2432}));
        break;
      }
      default: heff_nomatch(v_g_244);
      }
      return heff_clo_n(g_heff_2ebuild_2ecommands_2erunJobs_24s171025554x779625707_lam7, 2, 9, (V[]){v_c_2433, v_ex_240, v_rx_241, v_sel_242, v_jobs_243, heff_dup(v_g_244), v_rest_2426, v_pending_246, v_done_247});
    } else {
      V v_c_2446;
      switch (heff_tag_of(v_g_244)) {
      case TAG_MkGroup: {
        V v_i_2441 = heff_field(v_g_244, 0);
        V v_t_2444 = heff_tag_n(TAG_Finish, 3, (V[]){heff_dup(v_i_2441), NTAG(TAG_True), ((V)&g_heff_2ebuild_2ecommands_2erunJobs_24s171025554x779625707_lam9_clo)});
        V v_t_2445 = heff_tr(heff_call(heff_dup(v_rx_241), 1, (V[]){v_t_2444}));
        v_c_2446 = heff_tr(heff_call(((V)&g_co_2eop_24s22628809x1035315751_clo), 1, (V[]){v_t_2445}));
        break;
      }
      default: heff_nomatch(v_g_244);
      }
      return heff_clo_n(g_heff_2ebuild_2ecommands_2erunJobs_24s171025554x779625707_lam11, 2, 10, (V[]){v_c_2446, v_j_2425, v_rest_2426, v_done_247, v_ex_240, v_rx_241, v_sel_242, v_jobs_243, heff_dup(v_g_244), v_pending_246});
    }
  }
  default: return heff_nomatch(v_x4_245);
  }
}
V g_heff_2ebuild_2ecommands_2erunJobs_24s171025554x779625707_entry(V self, V *a) {
  (void)self;
  V a4 = a[4]; V r = g_heff_2ebuild_2ecommands_2erunJobs_24s171025554x779625707(a[0], a[1], a[2], a[3], a4, a[5], a[6], a[7]); heff_drop(a4); return r;
}
V g_heff_2ebuild_2ecommands_2erunJobs_24s171025554x779625707_lam0(V self, V *args) {
  V v_hd_249 = args[0];
  V v_k_2410 = args[1];
  V v_done_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_249);
  V f_ = v_k_2410;
  args[0] = v_done_247;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2erunJobs_24s171025554x779625707_lam2(V self, V *args) {
  V v_l_2413 = args[0];
  return v_l_2413;
}
V g_heff_2ebuild_2ecommands_2erunJobs_24s171025554x779625707_lam1(V self, V *args) {
  V v_use_2412 = args[0];
  V f_ = v_use_2412;
  args[0] = ((V)&g_heff_2ebuild_2ecommands_2erunJobs_24s171025554x779625707_lam2_clo);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2erunJobs_24s171025554x779625707_lam4(V self, V *args) {
  V v_x_2419 = args[0];
  V v_done_247 = heff_env(self)[0];
  V v_ex_240 = heff_env(self)[1];
  V v_rx_241 = heff_env(self)[2];
  V v_sel_242 = heff_env(self)[3];
  V v_jobs_243 = heff_env(self)[4];
  V v_g_244 = heff_env(self)[5];
  V v_pending_246 = heff_env(self)[6];
  V v_hd_2417 = heff_env(self)[7];
  V v_k_2418 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_t_2420 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_x_2419)));
  V v_t_2421 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2420; V r_ = (g_list_2efoldl_24s1300477078x2058851060(a_0, a_1)); heff_drop(v_t_2420); r_; });
  V v_t_2422 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_x_2419));
  V v_t_2423 = (g_prelude_2e_2b_2b(v_x_2419, v_done_247));
  V v_t_2424 = ({ V a_0 = v_ex_240; V a_1 = v_rx_241; V a_2 = v_sel_242; V a_3 = v_jobs_243; V a_4 = v_g_244; V a_5 = v_t_2421; V a_6 = heff_intSub(v_pending_246, v_t_2422); V a_7 = v_t_2423; V r_ = (g_heff_2ebuild_2ecommands_2erunJobs_24s171025554x779625707(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_g_244); r_; });
  V f_ = v_t_2424;
  heff_room[0] = v_hd_2417;
  heff_room[1] = v_k_2418;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2erunJobs_24s171025554x779625707_lam3(V self, V *args) {
  V v_hd_2417 = args[0];
  V v_k_2418 = args[1];
  V v_c_2416 = heff_env(self)[0];
  V v_done_247 = heff_env(self)[1];
  V v_ex_240 = heff_env(self)[2];
  V v_rx_241 = heff_env(self)[3];
  V v_sel_242 = heff_env(self)[4];
  V v_jobs_243 = heff_env(self)[5];
  V v_g_244 = heff_env(self)[6];
  V v_pending_246 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V f_ = v_c_2416;
  args[0] = heff_dup(v_hd_2417);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2erunJobs_24s171025554x779625707_lam4, 1, 9, (V[]){v_done_247, v_ex_240, v_rx_241, v_sel_242, v_jobs_243, v_g_244, v_pending_246, v_hd_2417, v_k_2418});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2ecommands_2erunJobs_24s171025554x779625707_lam6(V self, V *args) {
  V v_r_2431 = args[0];
  return v_r_2431;
}
V g_heff_2ebuild_2ecommands_2erunJobs_24s171025554x779625707_lam5(V self, V *args) {
  V v_use_2429 = args[0];
  V v_ex_240 = heff_env(self)[0];
  V v_sel_242 = heff_env(self)[1];
  V v_j_2425 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2430 = heff_tr(heff_call(((V)&g_heff_2ebuild_2ecommands_2erunJob_24s58783120x925504139_clo), 3, (V[]){v_ex_240, v_sel_242, v_j_2425}));
  V f_ = v_use_2429;
  heff_room[0] = v_t_2430;
  heff_room[1] = ((V)&g_heff_2ebuild_2ecommands_2erunJobs_24s171025554x779625707_lam6_clo);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2erunJobs_24s171025554x779625707_lam8(V self, V *args) {
  V v_x_2436 = args[0];
  V v_ex_240 = heff_env(self)[0];
  V v_rx_241 = heff_env(self)[1];
  V v_sel_242 = heff_env(self)[2];
  V v_jobs_243 = heff_env(self)[3];
  V v_g_244 = heff_env(self)[4];
  V v_rest_2426 = heff_env(self)[5];
  V v_pending_246 = heff_env(self)[6];
  V v_done_247 = heff_env(self)[7];
  V v_hd_2434 = heff_env(self)[8];
  V v_k_2435 = heff_env(self)[9];
  heff_clo_take(self, 10);
  switch (heff_tag_of(v_x_2436)) {
  case TAG_Nothing: {
    V v_t_2437 = ({ V a_0 = v_ex_240; V a_1 = v_rx_241; V a_2 = v_sel_242; V a_3 = v_jobs_243; V a_4 = v_g_244; V a_5 = v_rest_2426; V a_6 = heff_intAdd(v_pending_246, MK_INT(1LL)); V a_7 = v_done_247; V r_ = (g_heff_2ebuild_2ecommands_2erunJobs_24s171025554x779625707(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_g_244); r_; });
    V f_ = v_t_2437;
    heff_room[0] = v_hd_2434;
    heff_room[1] = v_k_2435;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_Just: {
    V v_f_2438 = heff_field(v_x_2436, 0);
    heff_take_n(v_x_2436, 1ULL, 1);
    V v_t_2439 = (g_prelude_2e_2b_2b(v_rest_2426, heff_dup(heff_rfield(v_f_2438, 3))));
    V v_t_2440 = ({ V a_0 = v_ex_240; V a_1 = v_rx_241; V a_2 = v_sel_242; V a_3 = v_jobs_243; V a_4 = v_g_244; V a_5 = v_t_2439; V a_6 = v_pending_246; V a_7 = heff_tag_n(TAG_Cons, 2, (V[]){v_f_2438, v_done_247}); V r_ = (g_heff_2ebuild_2ecommands_2erunJobs_24s171025554x779625707(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_g_244); r_; });
    V f_ = v_t_2440;
    heff_room[0] = v_hd_2434;
    heff_room[1] = v_k_2435;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_x_2436);
  }
}
V g_heff_2ebuild_2ecommands_2erunJobs_24s171025554x779625707_lam7(V self, V *args) {
  V v_hd_2434 = args[0];
  V v_k_2435 = args[1];
  V v_c_2433 = heff_env(self)[0];
  V v_ex_240 = heff_env(self)[1];
  V v_rx_241 = heff_env(self)[2];
  V v_sel_242 = heff_env(self)[3];
  V v_jobs_243 = heff_env(self)[4];
  V v_g_244 = heff_env(self)[5];
  V v_rest_2426 = heff_env(self)[6];
  V v_pending_246 = heff_env(self)[7];
  V v_done_247 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V f_ = v_c_2433;
  args[0] = heff_dup(v_hd_2434);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2erunJobs_24s171025554x779625707_lam8, 1, 10, (V[]){v_ex_240, v_rx_241, v_sel_242, v_jobs_243, v_g_244, v_rest_2426, v_pending_246, v_done_247, v_hd_2434, v_k_2435});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2ecommands_2erunJobs_24s171025554x779625707_lam10(V self, V *args) {
  V v_l_2443 = args[0];
  return v_l_2443;
}
V g_heff_2ebuild_2ecommands_2erunJobs_24s171025554x779625707_lam9(V self, V *args) {
  V v_use_2442 = args[0];
  V f_ = v_use_2442;
  args[0] = ((V)&g_heff_2ebuild_2ecommands_2erunJobs_24s171025554x779625707_lam10_clo);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2erunJobs_24s171025554x779625707_lam12(V self, V *args) {
  V v_x_2449 = args[0];
  V v_j_2425 = heff_env(self)[0];
  V v_rest_2426 = heff_env(self)[1];
  V v_done_247 = heff_env(self)[2];
  V v_ex_240 = heff_env(self)[3];
  V v_rx_241 = heff_env(self)[4];
  V v_sel_242 = heff_env(self)[5];
  V v_jobs_243 = heff_env(self)[6];
  V v_g_244 = heff_env(self)[7];
  V v_pending_246 = heff_env(self)[8];
  V v_hd_2447 = heff_env(self)[9];
  V v_k_2448 = heff_env(self)[10];
  heff_clo_take(self, 11);
  V v_t_2450 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_x_2449)));
  V v_t_2451 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2450; V r_ = (g_list_2efoldl_24s1300477078x2058851060(a_0, a_1)); heff_drop(v_t_2450); r_; });
  V v_t_2452 = (g_prelude_2e_2b_2b(heff_tag_n(TAG_Cons, 2, (V[]){v_j_2425, v_rest_2426}), v_t_2451));
  V v_t_2453 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_x_2449));
  V v_t_2454 = (g_prelude_2e_2b_2b(v_x_2449, v_done_247));
  V v_t_2455 = ({ V a_0 = v_ex_240; V a_1 = v_rx_241; V a_2 = v_sel_242; V a_3 = v_jobs_243; V a_4 = v_g_244; V a_5 = v_t_2452; V a_6 = heff_intSub(v_pending_246, v_t_2453); V a_7 = v_t_2454; V r_ = (g_heff_2ebuild_2ecommands_2erunJobs_24s171025554x779625707(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_g_244); r_; });
  V f_ = v_t_2455;
  heff_room[0] = v_hd_2447;
  heff_room[1] = v_k_2448;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2erunJobs_24s171025554x779625707_lam11(V self, V *args) {
  V v_hd_2447 = args[0];
  V v_k_2448 = args[1];
  V v_c_2446 = heff_env(self)[0];
  V v_j_2425 = heff_env(self)[1];
  V v_rest_2426 = heff_env(self)[2];
  V v_done_247 = heff_env(self)[3];
  V v_ex_240 = heff_env(self)[4];
  V v_rx_241 = heff_env(self)[5];
  V v_sel_242 = heff_env(self)[6];
  V v_jobs_243 = heff_env(self)[7];
  V v_g_244 = heff_env(self)[8];
  V v_pending_246 = heff_env(self)[9];
  heff_clo_take(self, 10);
  V f_ = v_c_2446;
  args[0] = heff_dup(v_hd_2447);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2erunJobs_24s171025554x779625707_lam12, 1, 11, (V[]){v_j_2425, v_rest_2426, v_done_247, v_ex_240, v_rx_241, v_sel_242, v_jobs_243, v_g_244, v_pending_246, v_hd_2447, v_k_2448});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2egoldensGo_24s1718087514x1126158310_str0, 6, "wrote ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egoldensGo_24s1718087514x1126158310_str1, 1, "\012");
V g_heff_2ebuild_2ecommands_2egoldensGo_24s1718087514x1126158310_lam0(V self, V *args);
V g_heff_2ebuild_2ecommands_2egoldensGo_24s1718087514x1126158310_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2egoldensGo_24s1718087514x1126158310_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2egoldensGo_24s1718087514x1126158310_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2egoldensGo_24s1718087514x1126158310_entry, 4, 0};

V g_heff_2ebuild_2ecommands_2egoldensGo_24s1718087514x1126158310(V v_update_240, V v_f_241, V v_o_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nil: {
    heff_drop(v_f_241);
    return heff_clo_n(g_heff_2ebuild_2ecommands_2egoldensGo_24s1718087514x1126158310_lam0, 2, 1, (V[]){v_o_242});
  }
  case TAG_Cons: {
    V v_g_246 = heff_field(v_x4_243, 0);
    V v_rest_247 = heff_field(v_x4_243, 1);
    heff_take_n(v_x4_243, 3ULL, 2);
    V v_c_248 = (g_heff_2ebuild_2ecommands_2egoldenSaid_24s472216893x1015725474(v_update_240, heff_dup(v_f_241), v_g_246));
    return heff_clo_n(g_heff_2ebuild_2ecommands_2egoldensGo_24s1718087514x1126158310_lam1, 2, 5, (V[]){v_c_248, heff_dup(v_update_240), v_f_241, v_o_242, v_rest_247});
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2ebuild_2ecommands_2egoldensGo_24s1718087514x1126158310_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2egoldensGo_24s1718087514x1126158310(a0, a[1], a[2], a[3]); heff_drop(a0); return r;
}
V g_heff_2ebuild_2ecommands_2egoldensGo_24s1718087514x1126158310_lam0(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k_245 = args[1];
  V v_o_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_244);
  V f_ = v_k_245;
  args[0] = v_o_242;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2egoldensGo_24s1718087514x1126158310_lam2(V self, V *args) {
  V v_x_2411 = args[0];
  V v_update_240 = heff_env(self)[0];
  V v_f_241 = heff_env(self)[1];
  V v_o_242 = heff_env(self)[2];
  V v_rest_247 = heff_env(self)[3];
  V v_hd_249 = heff_env(self)[4];
  V v_k_2410 = heff_env(self)[5];
  heff_clo_take(self, 6);
  switch (heff_tag_of(v_x_2411)) {
  case TAG_Holds: {
    V v_t_2412 = ({ V a_0 = v_update_240; V a_1 = v_f_241; V a_2 = v_o_242; V a_3 = v_rest_247; V r_ = (g_heff_2ebuild_2ecommands_2egoldensGo_24s1718087514x1126158310(a_0, a_1, a_2, a_3)); heff_drop(v_update_240); r_; });
    V f_ = v_t_2412;
    heff_room[0] = v_hd_249;
    heff_room[1] = v_k_2410;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_Wrote: {
    V v_path_2413 = heff_field(v_x_2411, 0);
    V v_ru_24x_2411_24Wrote = heff_take_reuse_n(v_x_2411, 1ULL, 1);
    V v_t_2414 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2egoldensGo_24s1718087514x1126158310_str0), v_path_2413), ((V)&g_heff_2ebuild_2ecommands_2egoldensGo_24s1718087514x1126158310_str1));
    V v_t_2415 = heff_tag_n(TAG_Write, 2, (V[]){v_t_2414, NTAG(TAG_MkUnit)});
    V v_t_2416 = heff_tag_at_n(v_ru_24x_2411_24Wrote, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
    V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
    V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
    V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
    V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
    V v_t_2421 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2420})});
    return ({ V a_0 = v_update_240; V a_1 = v_f_241; V a_2 = v_o_242; V a_3 = v_rest_247; V a_4 = heff_dup(v_hd_249); V a_5 = v_k_2410; V a_6 = heff_tag_n(TAG_InR, 1, (V[]){v_t_2421}); V a_7 = v_hd_249; V r_ = (g_co_2eop_24s1676588087x1342415945(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7)); heff_drop(v_update_240); r_; });
  }
  case TAG_Wrong: {
    V v_note_2422 = heff_field(v_x_2411, 0);
    V v_why_2423 = heff_field(v_x_2411, 1);
    V v_ru_24x_2411_24Wrong = heff_take_reuse_n(v_x_2411, 3ULL, 2);
    heff_drop(v_update_240);
    heff_drop(v_f_241);
    heff_drop(v_rest_247);
    heff_drop(v_hd_249);
    V v_t_2424 = heff_tag_at_n(v_ru_24x_2411_24Wrong, TAG_Cons, 2, (V[]){v_note_2422, NTAG(TAG_Nil)});
    V v_t_2425 = (g_prelude_2e_2b_2b(heff_take_field(v_o_242, 8), v_t_2424));
    V v_x_2426 = ({ V rv_1 = NTAG(TAG_False); V rv_2 = NTAG(TAG_Nothing); V rv_8 = v_t_2425; V rv_9 = heff_tag_n(TAG_Just, 1, (V[]){v_why_2423}); V rr_ = heff_rec_reuse_nf(v_o_242, 3321ULL, 12, shape_name__ok__skipped__property__runs__discarded__shrinks__labels__notes__failure__seed__goldens, 15794115u, 0u); heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 8) = rv_8; heff_rfield(rr_, 9) = rv_9; rr_; });
    V f_ = v_k_2410;
    args[0] = v_x_2426;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_2411);
  }
}
V g_heff_2ebuild_2ecommands_2egoldensGo_24s1718087514x1126158310_lam1(V self, V *args) {
  V v_hd_249 = args[0];
  V v_k_2410 = args[1];
  V v_c_248 = heff_env(self)[0];
  V v_update_240 = heff_env(self)[1];
  V v_f_241 = heff_env(self)[2];
  V v_o_242 = heff_env(self)[3];
  V v_rest_247 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_248;
  args[0] = heff_dup(v_hd_249);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2egoldensGo_24s1718087514x1126158310_lam2, 1, 6, (V[]){v_update_240, v_f_241, v_o_242, v_rest_247, v_hd_249, v_k_2410});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ewriteAll_24s2120021028x1422408481_str0, 5, "win32");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ewriteAll_24s2120021028x1422408481_str1, 3, ".hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ewriteAll_24s2120021028x1422408481_str2, 19, "heff: cannot write ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ewriteAll_24s2120021028x1422408481_str3, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ewriteAll_24s2120021028x1422408481_str4, 19, "heff: cannot write ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ewriteAll_24s2120021028x1422408481_str5, 1, "\012");
V g_heff_2ebuild_2ecommands_2ewriteAll_24s2120021028x1422408481_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ewriteAll_24s2120021028x1422408481_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewriteAll_24s2120021028x1422408481_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2ewriteAll_24s2120021028x1422408481_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ewriteAll_24s2120021028x1422408481_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewriteAll_24s2120021028x1422408481_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2ewriteAll_24s2120021028x1422408481_lam4(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ewriteAll_24s2120021028x1422408481_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewriteAll_24s2120021028x1422408481_lam4, 1, 0};
V g_heff_2ebuild_2ecommands_2ewriteAll_24s2120021028x1422408481_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2ewriteAll_24s2120021028x1422408481_lam7(V self, V *args);
V g_heff_2ebuild_2ecommands_2ewriteAll_24s2120021028x1422408481_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2ewriteAll_24s2120021028x1422408481_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ewriteAll_24s2120021028x1422408481_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ewriteAll_24s2120021028x1422408481_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewriteAll_24s2120021028x1422408481_entry, 4, 0};

V g_heff_2ebuild_2ecommands_2ewriteAll_24s2120021028x1422408481(V v_dir_240, V v_x2_241, V v_p_242, V v_p_243) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_dir_240);
    heff_drop(v_p_242);
    return heff_tail(v_p_243, 1, (V[]){NTAG(TAG_True)});
  }
  case TAG_Cons: {
    V v_x21_244 = heff_field(v_x2_241, 0);
    V v_rest_245 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_244)) {
    case TAG_MkPair: {
      V v_f_246 = heff_field(v_x21_244, 0);
      V v_text_247 = heff_field(v_x21_244, 1);
      heff_take_n(v_x21_244, 3ULL, 2);
      V v_t_249 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2ewriteAll_24s2120021028x1422408481_lam0_clo)})});
      V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
      V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
      V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
      V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
      V v_t_2414 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
      V v_t_2415 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2414})});
      return (g_co_2eop_24s495635622x733177935(v_t_2415, heff_dup(v_p_242), heff_clo_n(g_heff_2ebuild_2ecommands_2ewriteAll_24s2120021028x1422408481_lam1, 1, 6, (V[]){v_dir_240, v_f_246, v_p_242, v_text_247, v_rest_245, v_p_243})));
    }
    default: return heff_nomatch(v_x21_244);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2ecommands_2ewriteAll_24s2120021028x1422408481_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ewriteAll_24s2120021028x1422408481(a[0], a[1], a[2], a[3]);
}
V g_heff_2ebuild_2ecommands_2ewriteAll_24s2120021028x1422408481_lam0(V self, V *args) {
  V v_s_248 = args[0];
  return v_s_248;
}
V g_heff_2ebuild_2ecommands_2ewriteAll_24s2120021028x1422408481_lam2(V self, V *args) {
  V v_ok_2437 = args[0];
  return v_ok_2437;
}
V g_heff_2ebuild_2ecommands_2ewriteAll_24s2120021028x1422408481_lam4(V self, V *args) {
  V v_ok_2462 = args[0];
  return v_ok_2462;
}
V g_heff_2ebuild_2ecommands_2ewriteAll_24s2120021028x1422408481_lam6(V self, V *args) {
  V v_x_2483 = args[0];
  V v_p_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2483);
  V f_ = v_p_243;
  args[0] = NTAG(TAG_False);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ewriteAll_24s2120021028x1422408481_lam7(V self, V *args) {
  V v_x_2496 = args[0];
  V v_p_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2496);
  V f_ = v_p_243;
  args[0] = NTAG(TAG_False);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ewriteAll_24s2120021028x1422408481_lam5(V self, V *args) {
  V v_x_2470 = args[0];
  V v_x_2445 = heff_env(self)[0];
  V v_dir_240 = heff_env(self)[1];
  V v_rest_245 = heff_env(self)[2];
  V v_p_242 = heff_env(self)[3];
  V v_p_243 = heff_env(self)[4];
  V v_st_2418 = heff_env(self)[5];
  V v_f_246 = heff_env(self)[6];
  heff_clo_take(self, 7);
  if ((heff_dup(v_x_2445) == NTAG(TAG_True))) {
    heff_drop(v_x_2445);
    if ((heff_dup(v_x_2470) == NTAG(TAG_True))) {
      heff_drop(v_x_2470);
      heff_drop(v_st_2418);
      heff_drop(v_f_246);
      return (g_heff_2ebuild_2ecommands_2ewriteAll_24s2120021028x1422408481(v_dir_240, v_rest_245, v_p_242, v_p_243));
    } else {
      heff_drop(v_x_2470);
      heff_drop(v_rest_245);
      V v_t_2471 = (g_std_2epath_2eparse(v_st_2418, v_dir_240));
      V v_t_2472 = (g_std_2epath_2eparse(v_st_2418, v_f_246));
      V v_t_2473 = (g_std_2epath_2ejoin(v_t_2471, v_t_2472));
      V v_t_2474 = ({ V a_0 = v_st_2418; V a_1 = v_t_2473; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2418); heff_drop(v_t_2473); r_; });
      V v_str_2475 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ewriteAll_24s2120021028x1422408481_str2), v_t_2474);
      V v_t_2476 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_str_2475, ((V)&g_heff_2ebuild_2ecommands_2ewriteAll_24s2120021028x1422408481_str3)), NTAG(TAG_MkUnit)});
      V v_t_2477 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2476})});
      V v_t_2478 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2477})});
      V v_t_2479 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2478})});
      V v_t_2480 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2479})});
      V v_t_2481 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2480})});
      V v_t_2482 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2481})});
      return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2482}), v_p_242, heff_clo_n(g_heff_2ebuild_2ecommands_2ewriteAll_24s2120021028x1422408481_lam6, 1, 1, (V[]){v_p_243})));
    }
  } else {
    heff_drop(v_x_2470);
    heff_drop(v_x_2445);
    heff_drop(v_rest_245);
    V v_t_2484 = (g_std_2epath_2eparse(v_st_2418, v_dir_240));
    V v_t_2485 = (g_std_2epath_2eparse(v_st_2418, v_f_246));
    V v_t_2486 = (g_std_2epath_2ejoin(v_t_2484, v_t_2485));
    V v_t_2487 = ({ V a_0 = v_st_2418; V a_1 = v_t_2486; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2418); heff_drop(v_t_2486); r_; });
    V v_str_2488 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ewriteAll_24s2120021028x1422408481_str4), v_t_2487);
    V v_t_2489 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_str_2488, ((V)&g_heff_2ebuild_2ecommands_2ewriteAll_24s2120021028x1422408481_str5)), NTAG(TAG_MkUnit)});
    V v_t_2490 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2489})});
    V v_t_2491 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2490})});
    V v_t_2492 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2491})});
    V v_t_2493 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2492})});
    V v_t_2494 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2493})});
    V v_t_2495 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2494})});
    return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2495}), v_p_242, heff_clo_n(g_heff_2ebuild_2ecommands_2ewriteAll_24s2120021028x1422408481_lam7, 1, 1, (V[]){v_p_243})));
  }
}
V g_heff_2ebuild_2ecommands_2ewriteAll_24s2120021028x1422408481_lam3(V self, V *args) {
  V v_x_2445 = args[0];
  V v_st_2418 = heff_env(self)[0];
  V v_dir_240 = heff_env(self)[1];
  V v_f_246 = heff_env(self)[2];
  V v_text_247 = heff_env(self)[3];
  V v_p_242 = heff_env(self)[4];
  V v_rest_245 = heff_env(self)[5];
  V v_p_243 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2446 = (g_std_2epath_2eparse(v_st_2418, heff_dup(v_dir_240)));
  V v_t_2447 = (g_std_2epath_2eparse(v_st_2418, heff_dup(v_f_246)));
  V v_t_2448 = (g_std_2epath_2ejoin(v_t_2446, v_t_2447));
  V v_s_2449 = ({ V a_0 = v_st_2418; V a_1 = v_t_2448; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2448); r_; });
  V v_path_2450 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_s_2449; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
  int64_t v_t_2451 = (heff_unbox_word(heff_strLength_lent(v_f_246, 0)) - ((int64_t)3ULL));
  V v_t_2452 = heff_strSlice(heff_dup(v_f_246), heff_box_word(v_t_2451), heff_strLength_lent(v_f_246, 0));
  V v_str_2460;
  if (heff_strEq_c(v_t_2452, ((V)&g_heff_2ebuild_2ecommands_2ewriteAll_24s2120021028x1422408481_str1))) {
    HeffT2 v_t_2454 = (g_heff_2esyntax_2eformat_2eformat_24cpr(heff_dup(v_text_247)));
    {
      V v_field_2456 = v_t_2454.f[1];
      int64_t v_tag_2455 = ((int64_t)v_t_2454.f[0]);
      if ((v_tag_2455 == ((int64_t)0ULL))) {
        V v_x_2458 = v_field_2456;
        heff_drop(v_x_2458);
        v_str_2460 = v_text_247;
      } else {
        heff_drop(v_text_247);
        V v_out_2459 = v_field_2456;
        v_str_2460 = v_out_2459;
      }
    }
  } else {
    v_str_2460 = v_text_247;
  }
  V v_t_2461 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2450; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_2450); r_; });
  V v_a_2463 = heff_tag_n(TAG_WriteFile, 3, (V[]){v_t_2461, v_str_2460, ((V)&g_heff_2ebuild_2ecommands_2ewriteAll_24s2120021028x1422408481_lam4_clo)});
  V v_t_2464 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2463})});
  V v_t_2465 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2464})});
  V v_t_2466 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2465})});
  V v_t_2467 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2466})});
  V v_t_2468 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2467})});
  V v_t_2469 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2468})});
  return (g_co_2eop_24s495635622x733177935(v_t_2469, heff_dup(v_p_242), heff_clo_n(g_heff_2ebuild_2ecommands_2ewriteAll_24s2120021028x1422408481_lam5, 1, 7, (V[]){v_x_2445, v_dir_240, v_rest_245, v_p_242, v_p_243, v_st_2418, v_f_246})));
}
V g_heff_2ebuild_2ecommands_2ewriteAll_24s2120021028x1422408481_lam1(V self, V *args) {
  V v_x_2416 = args[0];
  V v_dir_240 = heff_env(self)[0];
  V v_f_246 = heff_env(self)[1];
  V v_p_242 = heff_env(self)[2];
  V v_text_247 = heff_env(self)[3];
  V v_rest_245 = heff_env(self)[4];
  V v_p_243 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_st_2418;
  if (heff_strEq_c(v_x_2416, ((V)&g_heff_2ebuild_2ecommands_2ewriteAll_24s2120021028x1422408481_str0))) {
    v_st_2418 = NTAG(TAG_Windows);
  } else {
    v_st_2418 = NTAG(TAG_Posix);
  }
  V v_t_2419 = (g_std_2epath_2eparse(v_st_2418, heff_dup(v_dir_240)));
  V v_t_2420 = (g_std_2epath_2eparse(v_st_2418, heff_dup(v_f_246)));
  V v_t_2421 = (g_std_2epath_2ejoin(v_t_2419, v_t_2420));
  V v_s_2422 = ({ V a_0 = v_st_2418; V a_1 = v_t_2421; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2421); r_; });
  HeffT3 v_t_2423 = (g_std_2epath_2eparse_24cpr(v_st_2418, v_s_2422));
  V v_t_2433;
  {
    V v_field_2424 = v_t_2423.f[0];
    V v_field_2425 = v_t_2423.f[1];
    V v_field_2426 = v_t_2423.f[2];
    V v_d_2427 = v_field_2424;
    V v_a_2428 = v_field_2425;
    V v_xs_2429 = v_field_2426;
    V v_t_2430 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2429));
    V v_xs_2431 = ({ V a_0 = MK_INT(1LL); V a_1 = v_t_2430; V r_ = (g_list_2edrop(a_0, a_1)); heff_drop(v_t_2430); r_; });
    V v_t_2432 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2431));
    v_t_2433 = heff_tag_n(TAG_MkPath, 3, (V[]){v_d_2427, v_a_2428, v_t_2432});
  }
  V v_s_2434 = ({ V a_0 = v_st_2418; V a_1 = v_t_2433; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2433); r_; });
  V v_path_2435 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_s_2434; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
  V v_t_2436 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2435; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_2435); r_; });
  V v_a_2438 = heff_tag_n(TAG_MakeDirectory, 2, (V[]){v_t_2436, ((V)&g_heff_2ebuild_2ecommands_2ewriteAll_24s2120021028x1422408481_lam2_clo)});
  V v_t_2439 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2438})});
  V v_t_2440 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2439})});
  V v_t_2441 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2440})});
  V v_t_2442 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2441})});
  V v_t_2443 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2442})});
  V v_t_2444 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2443})});
  return (g_co_2eop_24s495635622x733177935(v_t_2444, heff_dup(v_p_242), heff_clo_n(g_heff_2ebuild_2ecommands_2ewriteAll_24s2120021028x1422408481_lam3, 1, 7, (V[]){v_st_2418, v_dir_240, v_f_246, v_text_247, v_p_242, v_rest_245, v_p_243})));
}