// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_At 8900
#define TAG_DeclDefine 5286
#define TAG_DeclEquations 25755
#define TAG_DeclPrimitive 46335
#define TAG_DeclTest 38719
#define TAG_DeclTheory 39552
#define TAG_DeclWatch 51419
#define TAG_EAnn 33099
#define TAG_EApp 33163
#define TAG_EAssign 4102
#define TAG_EBinary 42634
#define TAG_EBreak 7195
#define TAG_EContinue 48638
#define TAG_EDo 15964
#define TAG_EFloat 59274
#define TAG_EFor 37939
#define TAG_EIfLet 62066
#define TAG_EIfThen 2245
#define TAG_EImplicitVar 16588
#define TAG_EInt 40793
#define TAG_EInvalid 31081
#define TAG_ELam 43266
#define TAG_ELetIn 22786
#define TAG_ELocal 42997
#define TAG_EMatch 41631
#define TAG_ENamed 41119
#define TAG_ENest 28629
#define TAG_EPi 16330
#define TAG_EProject 35489
#define TAG_EReturn 59059
#define TAG_ERune 31947
#define TAG_ESig 50235
#define TAG_ESpec 56652
#define TAG_EString 8932
#define TAG_EStruct 20136
#define TAG_ESum 50613
#define TAG_ETag 50948
#define TAG_ETry 51493
#define TAG_EUpdate 6986
#define TAG_EVar 52881
#define TAG_EWhile 39339
#define TAG_EWith 38507
#define TAG_EWord 44207
#define TAG_LamAnn 40466
#define TAG_LamImplicit 28191
#define TAG_LamName 56383
#define TAG_MkAlt 55173
#define TAG_MkCatchArm 36970
#define TAG_MkTry 8097
#define TAG_PiAnon 44344
#define TAG_PiImplicit 53923
#define TAG_PiInstance 8677
#define TAG_PiNamed 16606
#define TAG_SDebug 8687
#define TAG_SError 24172
#define TAG_SWarning 44190
#define LBL_aliases 1464806715
#define LBL_binder 558177493
#define LBL_broken 566525696
#define LBL_c 317
#define LBL_children 257181584
#define LBL_code 9554612
#define LBL_col 308218
#define LBL_decls 296817955
#define LBL_defines 1776893014
#define LBL_detail 611917692
#define LBL_diags 296935042
#define LBL_end 310101
#define LBL_entries 787768015
#define LBL_expecting 1746726246
#define LBL_fields 672433636
#define LBL_from 9647217
#define LBL_globals 352931696
#define LBL_infos 301706655
#define LBL_key 315609
#define LBL_kind 9787483
#define LBL_label 304085774
#define LBL_line 9817275
#define LBL_local 304503685
#define LBL_locals 849679763
#define LBL_member 869372357
#define LBL_module 878357911
#define LBL_msg 317947
#define LBL_name 9869138
#define LBL_order 307364712
#define LBL_out 319944
#define LBL_own 320000
#define LBL_path 9928940
#define LBL_selection 2055983820
#define LBL_severity 75955546
#define LBL_source 1050636102
#define LBL_span 10032145
#define LBL_spans 310996611
#define LBL_start 311115900
#define LBL_target 1066236092
#define LBL_text 10052084
#define LBL_to 10466
#define LBL_top 324559
#define LBL_trace 311979359
#define LBL_ty 10476
#define LBL_type_5f 312202367
#define LBL_uses 10094739
#define LBL_watches 1357821955
static uint32_t shape_c__name__span[] = {LBL_c, LBL_name, LBL_span};
static uint32_t shape_key__member__local[] = {LBL_key, LBL_member, LBL_local};
static uint32_t shape_label__detail[] = {LBL_label, LBL_detail};
static uint32_t shape_name__kind__span__selection__children[] = {LBL_name, LBL_kind, LBL_span, LBL_selection, LBL_children};
static uint32_t shape_out__code__expecting[] = {LBL_out, LBL_code, LBL_expecting};
static uint32_t shape_path__source__span[] = {LBL_path, LBL_source, LBL_span};
static uint32_t shape_path__source__span__defines[] = {LBL_path, LBL_source, LBL_span, LBL_defines};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
static uint32_t shape_target__name[] = {LBL_target, LBL_name};
static uint32_t shape_text__span[] = {LBL_text, LBL_span};
V g_heff_2ebuild_2edriver_2eexpectAfter(V, V, V);
V g_heff_2ebuild_2edriver_2eexpectAfter_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eexpectAfter_clo;
V g_heff_2ebuild_2edriver_2enubStrD(V);
V g_heff_2ebuild_2edriver_2enubStrD_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2enubStrD_clo;
V g_heff_2ebuild_2edriver_2eshowTySx(V, V);
V g_heff_2ebuild_2edriver_2eshowTySx_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eshowTySx_clo;
V g_heff_2ebuild_2equery_2eallChars_24s1328103304x613783392(V, V);
V g_heff_2ebuild_2equery_2eallChars_24s1328103304x613783392_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2eallChars_24s1328103304x613783392_clo;
V g_heff_2ebuild_2equery_2eallChars_24s542516060x1937552692(V, V, V);
V g_heff_2ebuild_2equery_2eallChars_24s542516060x1937552692_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2eallChars_24s542516060x1937552692_clo;
V g_heff_2ebuild_2equery_2eatLine(V, V);
V g_heff_2ebuild_2equery_2eatLine_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2eatLine_clo;
V g_heff_2ebuild_2equery_2ebrokenSymbol(V, V);
V g_heff_2ebuild_2equery_2ebrokenSymbol_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2ebrokenSymbol_clo;
V g_heff_2ebuild_2equery_2ecatMaybesQ(V);
V g_heff_2ebuild_2equery_2ecatMaybesQ_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2ecatMaybesQ_clo;
V g_heff_2ebuild_2equery_2ecatMaybesQ_24dps(V, V);
V g_heff_2ebuild_2equery_2ecatMaybesQ_24dps_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2ecatMaybesQ_24dps_clo;
V g_heff_2ebuild_2equery_2ecommentAbove(V, V, V);
V g_heff_2ebuild_2equery_2ecommentAbove_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2ecommentAbove_clo;
V g_heff_2ebuild_2equery_2ecompletionDetail(V, V);
V g_heff_2ebuild_2equery_2ecompletionDetail_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2ecompletionDetail_clo;
V g_heff_2ebuild_2equery_2ecompletionOf(V, V, V, V);
V g_heff_2ebuild_2equery_2ecompletionOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2ecompletionOf_clo;
V g_heff_2ebuild_2equery_2ecompletionsAt(V, V);
V g_heff_2ebuild_2equery_2ecompletionsAt_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2ecompletionsAt_clo;
V g_heff_2ebuild_2equery_2edeclSites(V, V);
V g_heff_2ebuild_2equery_2edeclSites_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2edeclSites_clo;
V g_heff_2ebuild_2equery_2edefinesGo(V, V, V, V);
V g_heff_2ebuild_2equery_2edefinesGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2edefinesGo_clo;
HeffT2 g_heff_2ebuild_2equery_2edefinitionAt_24cpr(V, V);
V g_heff_2ebuild_2equery_2edefinitionIn(V, V, V);
V g_heff_2ebuild_2equery_2edefinitionIn_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2edefinitionIn_clo;
V g_heff_2ebuild_2equery_2edocAt(V, V);
V g_heff_2ebuild_2equery_2edocAt_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2edocAt_clo;
V g_heff_2ebuild_2equery_2edocMarkdownIn(V, V);
V g_heff_2ebuild_2equery_2edocMarkdownIn_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2edocMarkdownIn_clo;
V g_heff_2ebuild_2equery_2edocMdStep(V, V, V);
V g_heff_2ebuild_2equery_2edocMdStep_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2edocMdStep_clo;
V g_heff_2ebuild_2equery_2eeqTarget(V, V);
V g_heff_2ebuild_2equery_2eeqTarget_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2eeqTarget_clo;
V g_heff_2ebuild_2equery_2eexpectedFits(V, V, V, V);
V g_heff_2ebuild_2equery_2eexpectedFits_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2eexpectedFits_clo;
V g_heff_2ebuild_2equery_2eexpectedIn(V, V, V);
V g_heff_2ebuild_2equery_2eexpectedIn_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2eexpectedIn_clo;
V g_heff_2ebuild_2equery_2eexplain(V);
V g_heff_2ebuild_2equery_2eexplain_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2eexplain_clo;
HeffT2 g_heff_2ebuild_2equery_2efieldFound_24cpr(V, V, V, V);
V g_heff_2ebuild_2equery_2efixityWords(V, V);
V g_heff_2ebuild_2equery_2efixityWords_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2efixityWords_clo;
V g_heff_2ebuild_2equery_2einFileFound(V, V, V, V, V);
V g_heff_2ebuild_2equery_2einFileFound_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2einFileFound_clo;
V g_heff_2ebuild_2equery_2einFileSites(V, V, V, V);
V g_heff_2ebuild_2equery_2einFileSites_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2einFileSites_clo;
V g_heff_2ebuild_2equery_2einStringGo(V, V, V, V);
V g_heff_2ebuild_2equery_2einStringGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2einStringGo_clo;
V g_heff_2ebuild_2equery_2eisLabelAt(V, V, V);
V g_heff_2ebuild_2equery_2eisLabelAt_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2eisLabelAt_clo;
V g_heff_2ebuild_2equery_2eisNameChar(V);
V g_heff_2ebuild_2equery_2eisNameChar_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2eisNameChar_clo;
V g_heff_2ebuild_2equery_2eisTypedChar(V);
V g_heff_2ebuild_2equery_2eisTypedChar_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2eisTypedChar_clo;
HeffT2 g_heff_2ebuild_2equery_2elastDot_24cpr(V, V);
V g_heff_2ebuild_2equery_2elineStartOf(V, V);
V g_heff_2ebuild_2equery_2elineStartOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2elineStartOf_clo;
V g_heff_2ebuild_2equery_2elocalDeclF_24s1801777056x609367408(V);
V g_heff_2ebuild_2equery_2elocalDeclF_24s1801777056x609367408_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2elocalDeclF_24s1801777056x609367408_clo;
V g_heff_2ebuild_2equery_2elocalFound(V, V, V);
V g_heff_2ebuild_2equery_2elocalFound_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2elocalFound_clo;
V g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(V);
V g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211_clo;
V g_heff_2ebuild_2equery_2emoreIn(V, V, V);
V g_heff_2ebuild_2equery_2emoreIn_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2emoreIn_clo;
V g_heff_2ebuild_2equery_2enameClass(V);
V g_heff_2ebuild_2equery_2enameClass_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2enameClass_clo;
V g_heff_2ebuild_2equery_2enameInGo(V, V, V, V);
V g_heff_2ebuild_2equery_2enameInGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2enameInGo_clo;
V g_heff_2ebuild_2equery_2enubByStart(V);
V g_heff_2ebuild_2equery_2enubByStart_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2enubByStart_clo;
V g_heff_2ebuild_2equery_2enubByStart_24dps(V, V);
V g_heff_2ebuild_2equery_2enubByStart_24dps_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2enubByStart_24dps_clo;
V g_heff_2ebuild_2equery_2eoccurrences(V, V, V);
V g_heff_2ebuild_2equery_2eoccurrences_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2eoccurrences_clo;
HeffT2 g_heff_2ebuild_2equery_2eownNameOf_24cpr(V, V);
V g_heff_2ebuild_2equery_2epunctuation(V);
V g_heff_2ebuild_2equery_2epunctuation_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2epunctuation_clo;
HeffT2 g_heff_2ebuild_2equery_2erenameRefused_24cpr(V, V, V);
HeffT2 g_heff_2ebuild_2equery_2esiteFound_24cpr(V, V, V);
V g_heff_2ebuild_2equery_2espacesBefore(V, V);
V g_heff_2ebuild_2equery_2espacesBefore_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2espacesBefore_clo;
V g_heff_2ebuild_2equery_2espacesFrom(V, V);
V g_heff_2ebuild_2equery_2espacesFrom_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2espacesFrom_clo;
V g_heff_2ebuild_2equery_2estartsStatement(V, V, V);
V g_heff_2ebuild_2equery_2estartsStatement_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2estartsStatement_clo;
V g_heff_2ebuild_2equery_2esumTags(V);
V g_heff_2ebuild_2equery_2esumTags_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2esumTags_clo;
V g_heff_2ebuild_2equery_2esymbolWith(V, V, V, V);
V g_heff_2ebuild_2equery_2esymbolWith_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2esymbolWith_clo;
V g_heff_2ebuild_2equery_2esymbols(V);
V g_heff_2ebuild_2equery_2esymbols_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2esymbols_clo;
V g_heff_2ebuild_2equery_2esymbolsGo(V, V, V, V);
V g_heff_2ebuild_2equery_2esymbolsGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2esymbolsGo_clo;
V g_heff_2ebuild_2equery_2esymbolsGo_24dps(V, V, V, V, V);
V g_heff_2ebuild_2equery_2esymbolsGo_24dps_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2esymbolsGo_24dps_clo;
V g_heff_2ebuild_2equery_2etargetIn(V, V, V, V);
V g_heff_2ebuild_2equery_2etargetIn_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2etargetIn_clo;
HeffT2 g_heff_2ebuild_2equery_2etypeAt_24cpr(V, V);
V g_heff_2ebuild_2equery_2etypedFrom(V, V);
V g_heff_2ebuild_2equery_2etypedFrom_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2etypedFrom_clo;
V g_heff_2ebuild_2equery_2euseOf(V, V, V);
V g_heff_2ebuild_2equery_2euseOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2euseOf_clo;
V g_heff_2ebuild_2equery_2ewordAt(V, V, V);
V g_heff_2ebuild_2equery_2ewordAt_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2ewordAt_clo;
V g_heff_2ebuild_2equery_2ewordsIn(V, V, V, V, V, V);
V g_heff_2ebuild_2equery_2ewordsIn_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2ewordsIn_clo;
V g_heff_2ebuild_2equery_2ewordsOf(V, V, V, V);
V g_heff_2ebuild_2equery_2ewordsOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2ewordsOf_clo;
HeffT2 g_heff_2eelab_2eglobals_2elookupKey_24cpr(V, V);
V g_heff_2eelab_2elocals_2elocalsOf(V);
V g_heff_2eelab_2elocals_2elocalsOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2elocals_2elocalsOf_clo;
HeffT2 g_heff_2eelab_2elocals_2elocalsOf_24cpr(V);
V g_heff_2eelab_2elocals_2enone_get(void);
V g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(V, V);
V g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276_entry(V self, V *a);
extern Clo g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276_clo;
V g_heff_2elsp_2erender_2elineColAt(V, V, V, V, V);
V g_heff_2elsp_2erender_2elineColAt_entry(V self, V *a);
extern Clo g_heff_2elsp_2erender_2elineColAt_clo;
V g_heff_2esyntax_2esurfaceprint_2enamed(V);
V g_heff_2esyntax_2esurfaceprint_2enamed_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2enamed_clo;
V g_list_2eany_24s1711939327x1502975912(V, V);
V g_list_2eany_24s1711939327x1502975912_entry(V self, V *a);
extern Clo g_list_2eany_24s1711939327x1502975912_clo;
V g_list_2eany_24s406396256x713021373(V, V);
V g_list_2eany_24s406396256x713021373_entry(V self, V *a);
extern Clo g_list_2eany_24s406396256x713021373_clo;
V g_list_2eany_24s430343851x1474283355(V, V);
V g_list_2eany_24s430343851x1474283355_entry(V self, V *a);
extern Clo g_list_2eany_24s430343851x1474283355_clo;
V g_list_2efilter(V, V);
V g_list_2efilter_entry(V self, V *a);
extern Clo g_list_2efilter_clo;
V g_list_2efilter_24s1109331425x852844386(V, V, V);
V g_list_2efilter_24s1109331425x852844386_entry(V self, V *a);
extern Clo g_list_2efilter_24s1109331425x852844386_clo;
V g_list_2efilter_24s1716878720x675187502(V, V);
V g_list_2efilter_24s1716878720x675187502_entry(V self, V *a);
extern Clo g_list_2efilter_24s1716878720x675187502_clo;
V g_list_2efilter_24s1771067298x678756798(V, V);
V g_list_2efilter_24s1771067298x678756798_entry(V self, V *a);
extern Clo g_list_2efilter_24s1771067298x678756798_clo;
V g_list_2efilter_24s343483820x881052984(V, V);
V g_list_2efilter_24s343483820x881052984_entry(V self, V *a);
extern Clo g_list_2efilter_24s343483820x881052984_clo;
HeffT2 g_list_2efind_24cpr(V, V);
HeffT2 g_list_2efind_24s1085725546x1737150855_24cpr(V, V);
HeffT2 g_list_2efind_24s1184231137x30317987_24cpr(V, V);
HeffT2 g_list_2efind_24s1702704581x1717241719_24cpr(V);
HeffT2 g_list_2efind_24s361650052x1432786508_24cpr(V, V);
HeffT2 g_list_2efind_24s582687515x818787580_24cpr(V, V);
HeffT2 g_list_2efind_24s728994925x1501467390_24cpr(V, V);
HeffT2 g_list_2efind_24s924148649x7864569_24cpr(V, V);
HeffT2 g_list_2efind_24s988189774x1593035904_24cpr(V, V);
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24f297647854x479783049(V, V);
V g_list_2efoldl_24f297647854x479783049_entry(V self, V *a);
extern Clo g_list_2efoldl_24f297647854x479783049_clo;
V g_list_2efoldl_24f765463553x1160475073(V, V, V, V, V, V, V);
V g_list_2efoldl_24f765463553x1160475073_entry(V self, V *a);
extern Clo g_list_2efoldl_24f765463553x1160475073_clo;
V g_list_2efoldl_24s1026998256x1634433314(V, V);
V g_list_2efoldl_24s1026998256x1634433314_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1026998256x1634433314_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1516272141x1201056882(V, V, V);
V g_list_2efoldl_24s1516272141x1201056882_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1516272141x1201056882_clo;
V g_list_2efoldl_24s1545552222x115732981(V, V);
V g_list_2efoldl_24s1545552222x115732981_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1545552222x115732981_clo;
V g_list_2efoldl_24s1777318809x1106245647(V, V);
V g_list_2efoldl_24s1777318809x1106245647_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1777318809x1106245647_clo;
V g_list_2efoldl_24s189033563x26633104(V, V);
V g_list_2efoldl_24s189033563x26633104_entry(V self, V *a);
extern Clo g_list_2efoldl_24s189033563x26633104_clo;
V g_list_2efoldl_24s1975553568x1034350329(V, V);
V g_list_2efoldl_24s1975553568x1034350329_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1975553568x1034350329_clo;
V g_list_2efoldl_24s2134067310x2049132013(V, V);
V g_list_2efoldl_24s2134067310x2049132013_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2134067310x2049132013_clo;
V g_list_2efoldl_24s302194196x751324068(V, V);
V g_list_2efoldl_24s302194196x751324068_entry(V self, V *a);
extern Clo g_list_2efoldl_24s302194196x751324068_clo;
V g_list_2efoldl_24s44351024x1408738471(V, V);
V g_list_2efoldl_24s44351024x1408738471_entry(V self, V *a);
extern Clo g_list_2efoldl_24s44351024x1408738471_clo;
V g_list_2efoldl_24s491084544x100802329(V, V);
V g_list_2efoldl_24s491084544x100802329_entry(V self, V *a);
extern Clo g_list_2efoldl_24s491084544x100802329_clo;
V g_list_2efoldl_24s496727651x1448898893(V, V);
V g_list_2efoldl_24s496727651x1448898893_entry(V self, V *a);
extern Clo g_list_2efoldl_24s496727651x1448898893_clo;
V g_list_2efoldl_24s54159557x1528472185(V, V);
V g_list_2efoldl_24s54159557x1528472185_entry(V self, V *a);
extern Clo g_list_2efoldl_24s54159557x1528472185_clo;
V g_list_2efoldl_24s673493459x989016999(V, V, V);
V g_list_2efoldl_24s673493459x989016999_entry(V self, V *a);
extern Clo g_list_2efoldl_24s673493459x989016999_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24f1959721488x1340654904(V, V, V, V, V, V, V);
V g_list_2emap_24f1959721488x1340654904_entry(V self, V *a);
extern Clo g_list_2emap_24f1959721488x1340654904_clo;
V g_list_2emap_24f2063070488x1806431062(V, V);
V g_list_2emap_24f2063070488x1806431062_entry(V self, V *a);
extern Clo g_list_2emap_24f2063070488x1806431062_clo;
V g_list_2emap_24f990982947x2126256822(V, V);
V g_list_2emap_24f990982947x2126256822_entry(V self, V *a);
extern Clo g_list_2emap_24f990982947x2126256822_clo;
V g_list_2emap_24s1266088736x105832553(V, V);
V g_list_2emap_24s1266088736x105832553_entry(V self, V *a);
extern Clo g_list_2emap_24s1266088736x105832553_clo;
V g_list_2emap_24s1415906091x1371825187(V);
V g_list_2emap_24s1415906091x1371825187_entry(V self, V *a);
extern Clo g_list_2emap_24s1415906091x1371825187_clo;
V g_list_2emap_24s149108714x637478466(V, V, V);
V g_list_2emap_24s149108714x637478466_entry(V self, V *a);
extern Clo g_list_2emap_24s149108714x637478466_clo;
V g_list_2emap_24s1675313341x192238134(V);
V g_list_2emap_24s1675313341x192238134_entry(V self, V *a);
extern Clo g_list_2emap_24s1675313341x192238134_clo;
V g_list_2emap_24s1721231741x1085491812(V);
V g_list_2emap_24s1721231741x1085491812_entry(V self, V *a);
extern Clo g_list_2emap_24s1721231741x1085491812_clo;
V g_list_2emap_24s173442543x1801751270(V);
V g_list_2emap_24s173442543x1801751270_entry(V self, V *a);
extern Clo g_list_2emap_24s173442543x1801751270_clo;
V g_list_2emap_24s1817753698x509594538(V, V, V);
V g_list_2emap_24s1817753698x509594538_entry(V self, V *a);
extern Clo g_list_2emap_24s1817753698x509594538_clo;
V g_list_2emap_24s1819241345x1511673126(V);
V g_list_2emap_24s1819241345x1511673126_entry(V self, V *a);
extern Clo g_list_2emap_24s1819241345x1511673126_clo;
V g_list_2emap_24s2000102784x314586828(V);
V g_list_2emap_24s2000102784x314586828_entry(V self, V *a);
extern Clo g_list_2emap_24s2000102784x314586828_clo;
V g_list_2emap_24s388004800x1261967008(V);
V g_list_2emap_24s388004800x1261967008_entry(V self, V *a);
extern Clo g_list_2emap_24s388004800x1261967008_clo;
V g_list_2emap_24s467798769x1763085075(V);
V g_list_2emap_24s467798769x1763085075_entry(V self, V *a);
extern Clo g_list_2emap_24s467798769x1763085075_clo;
V g_list_2esortBy_24s1223185427x423554351(V);
V g_list_2esortBy_24s1223185427x423554351_entry(V self, V *a);
extern Clo g_list_2esortBy_24s1223185427x423554351_clo;
V g_list_2esortBy_24s1230002843x105774350(V);
V g_list_2esortBy_24s1230002843x105774350_entry(V self, V *a);
extern Clo g_list_2esortBy_24s1230002843x105774350_clo;
V g_list_2esortBy_24s1681607803x465385494(V);
V g_list_2esortBy_24s1681607803x465385494_entry(V self, V *a);
extern Clo g_list_2esortBy_24s1681607803x465385494_clo;
V g_list_2esortBy_24s1768199906x1695529242(V);
V g_list_2esortBy_24s1768199906x1695529242_entry(V self, V *a);
extern Clo g_list_2esortBy_24s1768199906x1695529242_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2eskipSpaces(V, V, V);
V g_prelude_2eskipSpaces_entry(V self, V *a);
extern Clo g_prelude_2eskipSpaces_clo;
HeffT2 g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(V, V);
V g_std_2emap_2etoListOnto(V, V);
V g_std_2emap_2etoListOnto_entry(V self, V *a);
extern Clo g_std_2emap_2etoListOnto_clo;
Clo g_heff_2ebuild_2equery_2ecatMaybesQ_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2ecatMaybesQ_entry, 1, 0};

V g_heff_2ebuild_2equery_2ecatMaybesQ(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Just: {
      V v_x_243 = heff_field(v_x11_241, 0);
      heff_take_n(v_x11_241, 1ULL, 1);
      V v_cell_244 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
      V v_u_245 = (g_heff_2ebuild_2equery_2ecatMaybesQ_24dps(v_rest_242, heff_dup(v_cell_244)));
      heff_drop(v_u_245);
      return v_cell_244;
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2equery_2ecatMaybesQ_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2equery_2ecatMaybesQ(a[0]);
}
Clo g_heff_2ebuild_2equery_2ecatMaybesQ_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2ecatMaybesQ_24dps_entry, 2, 0};

V g_heff_2ebuild_2equery_2ecatMaybesQ_24dps(V v_x1_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x11_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_243;
      V t_1 = v_d_241;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_Just: {
      V v_x_244 = heff_field(v_x11_242, 0);
      heff_take_n(v_x11_242, 1ULL, 1);
      V v_cell_245 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_244, heff_hole()});
      V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
      heff_drop(v_u_246);
      V t_0 = v_rest_243;
      V t_1 = v_cell_245;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_x11_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2equery_2ecatMaybesQ_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2equery_2ecatMaybesQ_24dps(a[0], a[1]);
}
Clo g_heff_2ebuild_2equery_2eisNameChar_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2eisNameChar_entry, 1, 0};

V g_heff_2ebuild_2equery_2eisNameChar(V v_box_24c_240) {
  int64_t v_c_240 = heff_unbox_word(v_box_24c_240);
top: ;
  V v_ret_24bool = heff_bool(((v_c_240 == ((int64_t)95ULL)) || ((v_c_240 == ((int64_t)39ULL)) || ((v_c_240 == ((int64_t)47ULL)) || ((((int64_t)97ULL) <= v_c_240) ? ((v_c_240 <= ((int64_t)122ULL)) || ((((int64_t)65ULL) <= v_c_240) ? ((v_c_240 <= ((int64_t)90ULL)) || ((((int64_t)48ULL) <= v_c_240) && (v_c_240 <= ((int64_t)57ULL)))) : (heff_intLe_c(MK_INT(48LL), heff_box_word(v_c_240)) && heff_intLe_c(heff_box_word(v_c_240), MK_INT(57LL))))) : ((((int64_t)65ULL) <= v_c_240) ? ((v_c_240 <= ((int64_t)90ULL)) || ((((int64_t)48ULL) <= v_c_240) && (v_c_240 <= ((int64_t)57ULL)))) : ((((int64_t)48ULL) <= v_c_240) && (v_c_240 <= ((int64_t)57ULL)))))))));
  return v_ret_24bool;
}
V g_heff_2ebuild_2equery_2eisNameChar_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2equery_2eisNameChar(a[0]);
}
Clo g_heff_2ebuild_2equery_2ewordAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2ewordAt_entry, 3, 0};

V g_heff_2ebuild_2equery_2ewordAt(V v_src_240, V v_p_241, V v_x_242) {
top: ;
  V v_ret_24bool = heff_bool((heff_intEq_c_lent(v_p_241, MK_INT(0LL), 2) ? ({ int64_t v_t_244 = (heff_peek_word(v_p_241) + heff_unbox_word(heff_strLength_lent(v_x_242, 0))); int c_ = ({ V v_x1_245 = (g_heff_2ebuild_2equery_2eisNameChar(heff_strByteAt_lent(v_src_240, heff_box_word(v_t_244), 2))); int c_ = !(heff_dup(v_x1_245) == NTAG(TAG_True)); heff_drop(v_x1_245); c_; }); c_; }) : ({ V v_t_246 = heff_strByteAt(heff_dup(v_src_240), heff_intSub(heff_dup(v_p_241), MK_INT(1LL))); int c_ = ({ V v_x1_247 = (g_heff_2ebuild_2equery_2eisNameChar(heff_dup(v_t_246))); int c_ = ((heff_dup(v_x1_247) == NTAG(TAG_True)) ? 0 : ({ V v_t_248 = heff_intAdd(heff_dup(v_p_241), heff_strLength_lent(v_x_242, 0)); int c_ = ({ V v_x1_249 = (g_heff_2ebuild_2equery_2eisNameChar(heff_strByteAt_lent(v_src_240, v_t_248, 0))); int c_ = !(heff_dup(v_x1_249) == NTAG(TAG_True)); heff_drop(v_x1_249); c_; }); heff_drop(v_t_248); c_; })); heff_drop(v_x1_247); c_; }); heff_drop(v_t_246); c_; })));
  heff_drop(v_p_241);
  return v_ret_24bool;
}
V g_heff_2ebuild_2equery_2ewordAt_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a2 = a[2]; V r = g_heff_2ebuild_2equery_2ewordAt(a0, a[1], a2); heff_drop(a0); heff_drop(a2); return r;
}
Clo g_heff_2ebuild_2equery_2enameInGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2enameInGo_entry, 4, 0};

V g_heff_2ebuild_2equery_2enameInGo(V v_src_240, V v_x_241, V v_sp_242, V v_from_243) {
top: ;
  V v_j_244 = heff_strFind_lent(v_x_241, v_src_240, v_from_243, 4);
  if (heff_intLt_c_lent(v_j_244, MK_INT(0LL), 2)) {
    heff_drop(v_j_244);
    return v_sp_242;
  } else {
    V v_t_246 = heff_intAdd(heff_dup(v_j_244), heff_strLength_lent(v_x_241, 0));
    if (heff_intLe_c(v_t_246, heff_dup(heff_rfield(v_sp_242, 1)))) {
      V v_t_248 = (g_heff_2ebuild_2equery_2ewordAt(v_src_240, heff_dup(v_j_244), v_x_241));
      if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
        heff_drop_rec(v_sp_242, 2);
        heff_drop(v_t_248);
        V v_t_249 = heff_intAdd(heff_dup(v_j_244), heff_strLength_lent(v_x_241, 0));
        return heff_rec_n(2, shape_start__end, (V[]){v_j_244, v_t_249});
      } else {
        heff_drop(v_t_248);
        V t_0 = v_src_240;
        V t_1 = v_x_241;
        V t_2 = v_sp_242;
        V t_3 = heff_intAdd(v_j_244, MK_INT(1LL));
        v_src_240 = t_0;
        v_x_241 = t_1;
        v_sp_242 = t_2;
        v_from_243 = t_3;
        goto top;
      }
    } else {
      heff_drop(v_j_244);
      return v_sp_242;
    }
  }
}
V g_heff_2ebuild_2equery_2enameInGo_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ebuild_2equery_2enameInGo(a0, a1, a[2], a[3]); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_heff_2ebuild_2equery_2enubByStart_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2enubByStart_entry, 1, 0};

V g_heff_2ebuild_2equery_2enubByStart(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x1_240, 0);
    V v_xs_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_cell_243 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_x_241), heff_hole()});
    V v_t_244 = (g_list_2efilter_24s1771067298x678756798(v_x_241, v_xs_242));
    V v_u_245 = (g_heff_2ebuild_2equery_2enubByStart_24dps(v_t_244, heff_dup(v_cell_243)));
    heff_drop(v_u_245);
    return v_cell_243;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2equery_2enubByStart_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2equery_2enubByStart(a[0]);
}
Clo g_heff_2ebuild_2equery_2enubByStart_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2enubByStart_24dps_entry, 2, 0};

V g_heff_2ebuild_2equery_2enubByStart_24dps(V v_x1_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_x_242), heff_hole()});
    V v_u_245 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_244));
    heff_drop(v_u_245);
    V v_t_246 = (g_list_2efilter_24s1771067298x678756798(v_x_242, v_xs_243));
    V t_0 = v_t_246;
    V t_1 = v_cell_244;
    v_x1_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2equery_2enubByStart_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2equery_2enubByStart_24dps(a[0], a[1]);
}
HEFF_LIT(g_heff_2ebuild_2equery_2eatLine_str0, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2equery_2eatLine_str1, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2equery_2eatLine_str2, 1, ":");
Clo g_heff_2ebuild_2equery_2eatLine_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2eatLine_entry, 2, 0};

V g_heff_2ebuild_2equery_2eatLine(V v_src_240, V v_sp_241) {
top: ;
  V v_j_242 = heff_strFind_lent(((V)&g_heff_2ebuild_2equery_2eatLine_str0), v_src_240, MK_INT(0LL), 5);
  V v_t_244;
  if (heff_intLt_c_lent(v_j_242, MK_INT(0LL), 2)) {
    heff_drop(v_j_242);
    v_t_244 = NTAG(TAG_Nothing);
  } else {
    v_t_244 = heff_tag_n(TAG_Just, 1, (V[]){v_j_242});
  }
  V v_t_245 = (g_heff_2elsp_2erender_2elineColAt(v_src_240, heff_dup(heff_rfield(v_sp_241, 0)), MK_INT(0LL), MK_INT(0LL), v_t_244));
  V v_t_246 = heff_intAdd(heff_get_n(v_t_245, 0, 3), MK_INT(1LL));
  V v_j_247 = heff_strFind_lent(((V)&g_heff_2ebuild_2equery_2eatLine_str1), v_src_240, MK_INT(0LL), 5);
  V v_t_249;
  if (heff_intLt_c_lent(v_j_247, MK_INT(0LL), 2)) {
    heff_drop(v_j_247);
    v_t_249 = NTAG(TAG_Nothing);
  } else {
    v_t_249 = heff_tag_n(TAG_Just, 1, (V[]){v_j_247});
  }
  V v_t_2410 = (g_heff_2elsp_2erender_2elineColAt(v_src_240, heff_get_n(v_sp_241, 0, 2), MK_INT(0LL), MK_INT(0LL), v_t_249));
  V v_t_2411 = heff_intAdd(heff_get_n(v_t_2410, 2, 3), MK_INT(1LL));
  V v_t_2412 = heff_strAppend(((V)&g_heff_2ebuild_2equery_2eatLine_str2), heff_intShow(v_t_2411));
  return heff_strAppend(heff_intShow(v_t_246), v_t_2412);
}
V g_heff_2ebuild_2equery_2eatLine_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2equery_2eatLine(a0, a[1]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ebuild_2equery_2eexplain_str0, 2, "  ");
HEFF_LIT(g_heff_2ebuild_2equery_2eexplain_str1, 2, "  ");
HEFF_LIT(g_heff_2ebuild_2equery_2eexplain_str2, 5, "error");
HEFF_LIT(g_heff_2ebuild_2equery_2eexplain_str3, 7, "warning");
HEFF_LIT(g_heff_2ebuild_2equery_2eexplain_str4, 5, "debug");
HEFF_LIT(g_heff_2ebuild_2equery_2eexplain_str5, 2, "  ");
HEFF_LIT(g_heff_2ebuild_2equery_2eexplain_str6, 2, "  ");
V g_heff_2ebuild_2equery_2eexplain_lam0(V self, V *args);
V g_heff_2ebuild_2equery_2eexplain_lam1(V self, V *args);
Clo g_heff_2ebuild_2equery_2eexplain_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2eexplain_entry, 1, 0};

V g_heff_2ebuild_2equery_2eexplain(V v_c_240) {
top: ;
  V v_t_241 = heff_get_n(heff_dup(heff_rfield(v_c_240, 5)), 8, 9);
  V v_t_246 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2equery_2eexplain_lam0, 1, 1, (V[]){heff_dup(v_c_240)}), v_t_241));
  V v_t_2413 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2equery_2eexplain_lam1, 1, 1, (V[]){heff_dup(v_c_240)}), heff_get_n(v_c_240, 6, 14)));
  return (g_prelude_2e_2b_2b(v_t_246, v_t_2413));
}
V g_heff_2ebuild_2equery_2eexplain_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2equery_2eexplain(a[0]);
}
V g_heff_2ebuild_2equery_2eexplain_lam0(V self, V *args) {
  V v_ev_242 = args[0];
  V v_c_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_243 = ({ V b_0 = heff_get_n(v_c_240, 3, 14); V a_1 = heff_take_field(v_ev_242, 0); V r_ = (g_heff_2ebuild_2equery_2eatLine(b_0, a_1)); heff_drop(b_0); r_; });
  V v_t_244 = heff_tr(heff_call(heff_take_field(v_ev_242, 2), 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_t_245 = heff_strAppend(heff_get_n(v_ev_242, 1, 3), heff_strAppend(((V)&g_heff_2ebuild_2equery_2eexplain_str0), v_t_244));
  return heff_strAppend(v_t_243, heff_strAppend(((V)&g_heff_2ebuild_2equery_2eexplain_str1), v_t_245));
}
V g_heff_2ebuild_2equery_2eexplain_lam1(V self, V *args) {
  V v_d_247 = args[0];
  V v_c_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_248 = ({ V b_0 = heff_get_n(v_c_240, 3, 14); V a_1 = heff_take_field(v_d_247, 3); V r_ = (g_heff_2ebuild_2equery_2eatLine(b_0, a_1)); heff_drop(b_0); r_; });
  V v_t_249 = heff_take_field(v_d_247, 1);
  V v_t_2410;
  switch (heff_tag_of(v_t_249)) {
  case TAG_SError: {
    v_t_2410 = ((V)&g_heff_2ebuild_2equery_2eexplain_str2);
    break;
  }
  case TAG_SWarning: {
    v_t_2410 = ((V)&g_heff_2ebuild_2equery_2eexplain_str3);
    break;
  }
  case TAG_SDebug: {
    v_t_2410 = ((V)&g_heff_2ebuild_2equery_2eexplain_str4);
    break;
  }
  default: heff_nomatch(v_t_249);
  }
  V v_t_2411 = heff_strAppend(((V)&g_heff_2ebuild_2equery_2eexplain_str5), heff_get_n(v_d_247, 2, 5));
  V v_t_2412 = heff_strAppend(((V)&g_heff_2ebuild_2equery_2eexplain_str6), heff_strAppend(v_t_2410, v_t_2411));
  return heff_strAppend(v_t_248, v_t_2412);
}
HEFF_LIT(g_heff_2ebuild_2equery_2etypeAt_24cpr_str0, 10, "   (local)");
HEFF_LIT(g_heff_2ebuild_2equery_2etypeAt_24cpr_str1, 11, "   (global)");
HEFF_LIT(g_heff_2ebuild_2equery_2etypeAt_24cpr_str2, 3, " : ");

HeffT2 g_heff_2ebuild_2equery_2etypeAt_24cpr(V v_c_240, V v_off_241) {
top: ;
  V v_t_242 = heff_get_n(heff_get_n(v_c_240, 5, 14), 7, 9);
  V v_t_243 = (g_list_2efilter_24s1109331425x852844386(MK_INT(1LL), v_off_241, v_t_242));
  V v_x1_244 = (g_list_2esortBy_24s1681607803x465385494(v_t_243));
  switch (heff_tag_of(v_x1_244)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x1_244, 0);
    heff_take_n(v_x1_244, 1ULL, 2);
    V v_t_247 = (g_heff_2esyntax_2esurfaceprint_2enamed(heff_take_field(v_x_245, 1)));
    V v_t_248 = heff_tr(heff_call(heff_take_field(v_x_245, 4), 1, (V[]){NTAG(TAG_MkUnit)}));
    V v_t_249 = heff_get_n(v_x_245, 2, 5);
    V v_t_2411;
    switch (heff_tag_of(v_t_249)) {
    case TAG_Nothing: {
      v_t_2411 = ((V)&g_heff_2ebuild_2equery_2etypeAt_24cpr_str0);
      break;
    }
    case TAG_Just: {
      heff_take_n(v_t_249, 0ULL, 1);
      v_t_2411 = ((V)&g_heff_2ebuild_2equery_2etypeAt_24cpr_str1);
      break;
    }
    default: heff_nomatch(v_t_249);
    }
    V v_t_2412 = heff_strAppend(((V)&g_heff_2ebuild_2equery_2etypeAt_24cpr_str2), heff_strAppend(v_t_248, v_t_2411));
    V v_f_2413 = heff_strAppend(v_t_247, v_t_2412);
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2413}});
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_244)}});
  }
}
Clo g_heff_2ebuild_2equery_2eisTypedChar_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2eisTypedChar_entry, 1, 0};

V g_heff_2ebuild_2equery_2eisTypedChar(V v_box_24c_240) {
  int64_t v_c_240 = heff_unbox_word(v_box_24c_240);
top: ;
  V v_ret_24bool = heff_bool(((v_c_240 == ((int64_t)95ULL)) || ((v_c_240 == ((int64_t)39ULL)) || ((v_c_240 == ((int64_t)46ULL)) || ((((int64_t)97ULL) <= v_c_240) ? ((v_c_240 <= ((int64_t)122ULL)) || ((((int64_t)65ULL) <= v_c_240) ? ((v_c_240 <= ((int64_t)90ULL)) || ((((int64_t)48ULL) <= v_c_240) && (v_c_240 <= ((int64_t)57ULL)))) : (heff_intLe_c(MK_INT(48LL), heff_box_word(v_c_240)) && heff_intLe_c(heff_box_word(v_c_240), MK_INT(57LL))))) : ((((int64_t)65ULL) <= v_c_240) ? ((v_c_240 <= ((int64_t)90ULL)) || ((((int64_t)48ULL) <= v_c_240) && (v_c_240 <= ((int64_t)57ULL)))) : ((((int64_t)48ULL) <= v_c_240) && (v_c_240 <= ((int64_t)57ULL)))))))));
  return v_ret_24bool;
}
V g_heff_2ebuild_2equery_2eisTypedChar_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2equery_2eisTypedChar(a[0]);
}
Clo g_heff_2ebuild_2equery_2etypedFrom_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2etypedFrom_entry, 2, 0};

V g_heff_2ebuild_2equery_2etypedFrom(V v_src_240, V v_i_241) {
top: ;
  if (heff_intLt_c_lent(MK_INT(0LL), v_i_241, 1)) {
    V v_t_243 = heff_strByteAt(heff_dup(v_src_240), heff_intSub(heff_dup(v_i_241), MK_INT(1LL)));
    V v_t_244 = (g_heff_2ebuild_2equery_2eisTypedChar(v_t_243));
    if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
      heff_drop(v_t_244);
      V t_0 = v_src_240;
      V t_1 = heff_intSub(v_i_241, MK_INT(1LL));
      v_src_240 = t_0;
      v_i_241 = t_1;
      goto top;
    } else {
      heff_drop(v_t_244);
      return v_i_241;
    }
  } else {
    return v_i_241;
  }
}
V g_heff_2ebuild_2equery_2etypedFrom_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2equery_2etypedFrom(a0, a[1]); heff_drop(a0); return r;
}

HeffT2 g_heff_2ebuild_2equery_2elastDot_24cpr(V v_s_240, V v_box_24i_241) {
  int64_t v_i_241 = heff_unbox_word(v_box_24i_241);
top: ;
  if ((v_i_241 < ((int64_t)0ULL))) {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  } else {
    if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, heff_box_word(v_i_241), 2)) == ((int64_t)46ULL))) {
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_box_word(v_i_241)}});
    } else {
      V t_0 = v_s_240;
      int64_t t_1 = (v_i_241 - ((int64_t)1ULL));
      v_s_240 = t_0;
      v_i_241 = t_1;
      goto top;
    }
  }
}
HEFF_LIT(g_heff_2ebuild_2equery_2ecompletionDetail_str0, 1, ".");
HEFF_LIT(g_heff_2ebuild_2equery_2ecompletionDetail_str1, 0, "");
HEFF_LIT(g_heff_2ebuild_2equery_2ecompletionDetail_str2, 0, "");
Clo g_heff_2ebuild_2equery_2ecompletionDetail_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2ecompletionDetail_entry, 2, 0};

V g_heff_2ebuild_2equery_2ecompletionDetail(V v_c_240, V v_x_241) {
top: ;
  V v_t_242 = heff_get_n(heff_dup(heff_rfield(v_c_240, 5)), 0, 9);
  HeffT2 v_t_243 = (g_heff_2eelab_2eglobals_2elookupKey_24cpr(v_t_242, heff_dup(v_x_241)));
  {
    V v_field_245 = v_t_243.f[1];
    int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
    if ((v_tag_244 == ((int64_t)0ULL))) {
      heff_drop(v_x_241);
      V v_it1_247 = v_field_245;
      switch (heff_tag_of(v_it1_247)) {
      case TAG_MkPair: {
        V v_e_249 = heff_field(v_it1_247, 1);
        heff_take_n(v_it1_247, 2ULL, 2);
        V v_t_2410 = heff_get_n(heff_get_n(v_c_240, 5, 14), 0, 9);
        V v_t_2411 = (g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(MK_INT(0LL), heff_get_n(v_e_249, 3, 4)));
        HEFF_LAST return g_heff_2ebuild_2edriver_2eshowTySx(v_t_2410, v_t_2411);
      }
      default: return heff_nomatch(v_it1_247);
      }
    } else {
      heff_drop(v_field_245);
      V v_g_2412 = heff_get_n(heff_dup(heff_rfield(v_c_240, 5)), 0, 9);
      V v_k_2413 = heff_strAppend(heff_take_field(v_c_240, 0), heff_strAppend(((V)&g_heff_2ebuild_2equery_2ecompletionDetail_str0), v_x_241));
      HeffT2 v_t_2414 = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(heff_rfield(v_g_2412, 1), v_k_2413));
      {
        V v_field_2416 = v_t_2414.f[1];
        int64_t v_tag_2415 = ((int64_t)v_t_2414.f[0]);
        if ((v_tag_2415 == ((int64_t)0ULL))) {
          heff_drop_rec(v_g_2412, 8);
          heff_drop(v_k_2413);
          V v_e_2418 = v_field_2416;
          V v_t_2419 = heff_get_n(heff_get_n(v_c_240, 5, 14), 0, 9);
          V v_t_2420 = (g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(MK_INT(0LL), heff_get_n(v_e_2418, 3, 4)));
          HEFF_LAST return g_heff_2ebuild_2edriver_2eshowTySx(v_t_2419, v_t_2420);
        } else {
          heff_drop(v_field_2416);
          HeffT2 v_t_2421 = ({ V a_0 = heff_rfield(v_g_2412, 2); V a_1 = v_k_2413; HeffT2 r_ = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(a_0, a_1)); heff_drop(v_k_2413); r_; });
          {
            V v_field_2423 = v_t_2421.f[1];
            int64_t v_tag_2422 = ((int64_t)v_t_2421.f[0]);
            if ((v_tag_2422 == ((int64_t)0ULL))) {
              V v_k2_2425 = v_field_2423;
              HeffT2 v_t_2426 = ({ V b_0 = heff_get_n(v_g_2412, 1, 8); V a_1 = v_k2_2425; HeffT2 r_ = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(b_0, a_1)); heff_drop(b_0); heff_drop(v_k2_2425); r_; });
              {
                V v_field_2428 = v_t_2426.f[1];
                int64_t v_tag_2427 = ((int64_t)v_t_2426.f[0]);
                if ((v_tag_2427 == ((int64_t)0ULL))) {
                  V v_e_2430 = v_field_2428;
                  V v_t_2431 = heff_get_n(heff_get_n(v_c_240, 5, 14), 0, 9);
                  V v_t_2432 = (g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(MK_INT(0LL), heff_get_n(v_e_2430, 3, 4)));
                  HEFF_LAST return g_heff_2ebuild_2edriver_2eshowTySx(v_t_2431, v_t_2432);
                } else {
                  heff_drop_rec(v_c_240, 14);
                  heff_drop(v_field_2428);
                  return ((V)&g_heff_2ebuild_2equery_2ecompletionDetail_str1);
                }
              }
            } else {
              heff_drop_rec(v_c_240, 14);
              heff_drop_rec(v_g_2412, 8);
              heff_drop(v_field_2423);
              return ((V)&g_heff_2ebuild_2equery_2ecompletionDetail_str2);
            }
          }
        }
      }
    }
  }
}
V g_heff_2ebuild_2equery_2ecompletionDetail_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2equery_2ecompletionDetail(a[0], a[1]);
}
HEFF_LIT(g_heff_2ebuild_2equery_2ecompletionOf_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2equery_2ecompletionOf_str1, 1, ".");
Clo g_heff_2ebuild_2equery_2ecompletionOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2ecompletionOf_entry, 4, 0};

V g_heff_2ebuild_2equery_2ecompletionOf(V v_c_240, V v_typed_241, V v_qualifier_242, V v_x_243) {
top: ;
  V v_t_244 = heff_strSlice(heff_dup(v_x_243), MK_INT(0LL), heff_strLength_lent(v_typed_241, 0));
  if (heff_strEq_c_lent(v_t_244, v_typed_241, 1)) {
    if (heff_strEq_c_lent(v_qualifier_242, ((V)&g_heff_2ebuild_2equery_2ecompletionOf_str0), 2)) {
      if (heff_intLe_c(MK_INT(0LL), heff_strFind_lent(((V)&g_heff_2ebuild_2equery_2ecompletionOf_str1), v_x_243, MK_INT(0LL), 5))) {
        heff_drop(v_c_240);
        heff_drop(v_x_243);
        return NTAG(TAG_Nothing);
      } else {
        V v_t_248 = heff_strSlice(heff_dup(v_x_243), MK_INT(0LL), heff_strLength_lent(v_qualifier_242, 0));
        V v_t_2410;
        if (heff_strEq_c_lent(v_t_248, v_qualifier_242, 1)) {
          v_t_2410 = heff_strSlice(heff_dup(v_x_243), heff_strLength_lent(v_qualifier_242, 0), heff_strLength_lent(v_x_243, 0));
        } else {
          v_t_2410 = heff_dup(v_x_243);
        }
        V v_t_2411 = (g_heff_2ebuild_2equery_2ecompletionDetail(v_c_240, v_x_243));
        return heff_tag_n(TAG_Just, 1, (V[]){heff_rec_n(2, shape_label__detail, (V[]){v_t_2410, v_t_2411})});
      }
    } else {
      V v_t_2412 = heff_strSlice(heff_dup(v_x_243), MK_INT(0LL), heff_strLength_lent(v_qualifier_242, 0));
      V v_t_2414;
      if (heff_strEq_c_lent(v_t_2412, v_qualifier_242, 1)) {
        v_t_2414 = heff_strSlice(heff_dup(v_x_243), heff_strLength_lent(v_qualifier_242, 0), heff_strLength_lent(v_x_243, 0));
      } else {
        v_t_2414 = heff_dup(v_x_243);
      }
      V v_t_2415 = (g_heff_2ebuild_2equery_2ecompletionDetail(v_c_240, v_x_243));
      return heff_tag_n(TAG_Just, 1, (V[]){heff_rec_n(2, shape_label__detail, (V[]){v_t_2414, v_t_2415})});
    }
  } else {
    heff_drop(v_c_240);
    heff_drop(v_x_243);
    return NTAG(TAG_Nothing);
  }
}
V g_heff_2ebuild_2equery_2ecompletionOf_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a2 = a[2]; V r = g_heff_2ebuild_2equery_2ecompletionOf(a[0], a1, a2, a[3]); heff_drop(a1); heff_drop(a2); return r;
}
Clo g_heff_2ebuild_2equery_2estartsStatement_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2estartsStatement_entry, 3, 0};

V g_heff_2ebuild_2equery_2estartsStatement(V v_src_240, V v_i_241, V v_n_242) {
top: ;
  if (heff_intLt_c_lent(MK_INT(0LL), v_i_241, 1)) {
    V v_t_244 = heff_strByteAt(heff_dup(v_src_240), heff_intSub(heff_dup(v_i_241), MK_INT(1LL)));
    if ((heff_unbox_word(v_t_244) == ((int64_t)32ULL))) {
      V t_0 = v_src_240;
      V t_1 = heff_intSub(v_i_241, MK_INT(1LL));
      V t_2 = heff_intAdd(v_n_242, MK_INT(1LL));
      v_src_240 = t_0;
      v_i_241 = t_1;
      v_n_242 = t_2;
      goto top;
    } else {
      if (heff_intLt_c(MK_INT(0LL), v_n_242)) {
        if (heff_intEq_c_lent(v_i_241, MK_INT(0LL), 2)) {
          heff_drop(v_i_241);
          return NTAG(TAG_True);
        } else {
          V v_t_248 = heff_strByteAt(heff_dup(v_src_240), heff_intSub(v_i_241, MK_INT(1LL)));
          return heff_bool((heff_unbox_word(v_t_248) == ((int64_t)10ULL)));
        }
      } else {
        heff_drop(v_i_241);
        return NTAG(TAG_False);
      }
    }
  } else {
    if (heff_intLt_c(MK_INT(0LL), v_n_242)) {
      if (heff_intEq_c_lent(v_i_241, MK_INT(0LL), 2)) {
        heff_drop(v_i_241);
        return NTAG(TAG_True);
      } else {
        V v_t_2411 = heff_strByteAt(heff_dup(v_src_240), heff_intSub(v_i_241, MK_INT(1LL)));
        return heff_bool((heff_unbox_word(v_t_2411) == ((int64_t)10ULL)));
      }
    } else {
      heff_drop(v_i_241);
      return NTAG(TAG_False);
    }
  }
}
V g_heff_2ebuild_2equery_2estartsStatement_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2equery_2estartsStatement(a0, a[1], a[2]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ebuild_2equery_2ecompletionsAt_str0, 7, "abandon");
HEFF_LIT(g_heff_2ebuild_2equery_2ecompletionsAt_str1, 7, "abandon");
HEFF_LIT(g_heff_2ebuild_2equery_2ecompletionsAt_str2, 50, "a hole: checks at any small type, abandons the run");
HEFF_LIT(g_heff_2ebuild_2equery_2ecompletionsAt_str3, 4, "with");
HEFF_LIT(g_heff_2ebuild_2equery_2ecompletionsAt_str4, 4, "with");
HEFF_LIT(g_heff_2ebuild_2equery_2ecompletionsAt_str5, 58, "a statement: `with e as x do`, the block the `with`'s body");
HEFF_LIT(g_heff_2ebuild_2equery_2ecompletionsAt_str6, 0, "");
V g_heff_2ebuild_2equery_2ecompletionsAt_lam0(V self, V *args);
V g_heff_2ebuild_2equery_2ecompletionsAt_lam1(V self, V *args);
Clo g_heff_2ebuild_2equery_2ecompletionsAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2ecompletionsAt_entry, 2, 0};

V g_heff_2ebuild_2equery_2ecompletionsAt(V v_c_240, V v_offset_241) {
top: ;
  V v_t_242 = (g_heff_2ebuild_2equery_2etypedFrom(heff_rfield(v_c_240, 3), heff_dup(v_offset_241)));
  V v_typed_243 = heff_strSlice(heff_dup(heff_rfield(v_c_240, 3)), v_t_242, heff_dup(v_offset_241));
  V v_t_244 = heff_strSlice(((V)&g_heff_2ebuild_2equery_2ecompletionsAt_str0), MK_INT(0LL), heff_strLength_lent(v_typed_243, 0));
  V v_t_246;
  if (heff_strEq_c(v_t_244, v_typed_243)) {
    v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){heff_rec_n(2, shape_label__detail, (V[]){((V)&g_heff_2ebuild_2equery_2ecompletionsAt_str1), ((V)&g_heff_2ebuild_2equery_2ecompletionsAt_str2)}), NTAG(TAG_Nil)});
  } else {
    v_t_246 = NTAG(TAG_Nil);
  }
  V v_from_247 = (g_heff_2ebuild_2equery_2etypedFrom(heff_rfield(v_c_240, 3), heff_dup(v_offset_241)));
  V v_t_248 = (g_heff_2ebuild_2equery_2etypedFrom(heff_rfield(v_c_240, 3), heff_dup(v_offset_241)));
  V v_typed_249 = heff_strSlice(heff_dup(heff_rfield(v_c_240, 3)), v_t_248, heff_dup(v_offset_241));
  V v_t_2410 = (g_heff_2ebuild_2equery_2estartsStatement(heff_rfield(v_c_240, 3), v_from_247, MK_INT(0LL)));
  V v_t_2413;
  if ((heff_dup(v_t_2410) == NTAG(TAG_True))) {
    heff_drop(v_t_2410);
    V v_t_2411 = heff_strSlice(((V)&g_heff_2ebuild_2equery_2ecompletionsAt_str3), MK_INT(0LL), heff_strLength_lent(v_typed_249, 0));
    if (heff_strEq_c(v_t_2411, v_typed_249)) {
      v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){heff_rec_n(2, shape_label__detail, (V[]){((V)&g_heff_2ebuild_2equery_2ecompletionsAt_str4), ((V)&g_heff_2ebuild_2equery_2ecompletionsAt_str5)}), NTAG(TAG_Nil)});
    } else {
      v_t_2413 = NTAG(TAG_Nil);
    }
  } else {
    heff_drop(v_typed_249);
    heff_drop(v_t_2410);
    v_t_2413 = NTAG(TAG_Nil);
  }
  V v_t_2414 = (g_prelude_2e_2b_2b(v_t_246, v_t_2413));
  V v_t_2415 = (g_list_2emap_24s467798769x1763085075(heff_dup(heff_rfield(v_c_240, 7))));
  V v_t_2416 = heff_get_n(heff_dup(heff_rfield(v_c_240, 5)), 0, 9);
  V v_t_2417 = ({ V b_0 = heff_get_n(v_t_2416, 2, 8); V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2emap_2etoListOnto(b_0, a_1)); heff_drop(b_0); r_; });
  V v_t_2418 = (g_list_2emap_24s1415906091x1371825187(v_t_2417));
  V v_g_2419 = heff_get_n(heff_dup(heff_rfield(v_c_240, 5)), 0, 9);
  V v_t_2427 = ({ V a_0 = heff_clo_n(g_heff_2ebuild_2equery_2ecompletionsAt_lam0, 2, 1, (V[]){heff_dup(v_g_2419)}); V a_1 = NTAG(TAG_Nil); V b_2 = heff_get_n(v_g_2419, 0, 8); V r_ = (g_list_2efoldl(a_0, a_1, b_2)); heff_drop(b_2); r_; });
  V v_t_2428 = (g_list_2emap_24s1721231741x1085491812(v_t_2427));
  V v_t_2429 = (g_heff_2ebuild_2equery_2ecatMaybesQ(v_t_2428));
  V v_t_2430 = (g_prelude_2e_2b_2b(v_t_2418, v_t_2429));
  V v_t_2431 = (g_prelude_2e_2b_2b(v_t_2415, v_t_2430));
  V v_t_2432 = (g_heff_2ebuild_2edriver_2enubStrD(v_t_2431));
  V v_t_2445 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2equery_2ecompletionsAt_lam1, 1, 2, (V[]){v_c_240, v_offset_241}), v_t_2432));
  V v_t_2446 = (g_heff_2ebuild_2equery_2ecatMaybesQ(v_t_2445));
  V v_t_2447 = (g_prelude_2e_2b_2b(v_t_2414, v_t_2446));
  return (g_list_2esortBy_24s1223185427x423554351(v_t_2447));
}
V g_heff_2ebuild_2equery_2ecompletionsAt_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2equery_2ecompletionsAt(a[0], a[1]);
}
V g_heff_2ebuild_2equery_2ecompletionsAt_lam0(V self, V *args) {
  V v_acc_2420 = args[0];
  V v_k_2421 = args[1];
  V v_g_2419 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2422 = ({ V b_0 = heff_get_n(v_g_2419, 1, 8); V a_1 = v_k_2421; HeffT2 r_ = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
  {
    V v_field_2424 = v_t_2422.f[1];
    int64_t v_tag_2423 = ((int64_t)v_t_2422.f[0]);
    if ((v_tag_2423 == ((int64_t)0ULL))) {
      V v_e_2426 = v_field_2424;
      return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_k_2421, v_e_2426}), v_acc_2420});
    } else {
      heff_drop(v_k_2421);
      heff_drop(v_field_2424);
      return v_acc_2420;
    }
  }
}
V g_heff_2ebuild_2equery_2ecompletionsAt_lam1(V self, V *args) {
  V v_x_2433 = args[0];
  V v_c_240 = heff_env(self)[0];
  V v_offset_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2434 = (g_heff_2ebuild_2equery_2etypedFrom(heff_rfield(v_c_240, 3), heff_dup(v_offset_241)));
  V v_t_2435 = heff_strSlice(heff_dup(heff_rfield(v_c_240, 3)), v_t_2434, heff_dup(v_offset_241));
  V v_t_2436 = (g_heff_2ebuild_2equery_2etypedFrom(heff_rfield(v_c_240, 3), heff_dup(v_offset_241)));
  V v_typed_2437 = heff_strSlice(heff_dup(heff_rfield(v_c_240, 3)), v_t_2436, v_offset_241);
  int64_t v_t_2438 = (heff_unbox_word(heff_strLength_lent(v_typed_2437, 0)) - ((int64_t)1ULL));
  HeffT2 v_t_2439 = (g_heff_2ebuild_2equery_2elastDot_24cpr(v_typed_2437, heff_box_word(v_t_2438)));
  V v_t_2444;
  {
    V v_field_2441 = v_t_2439.f[1];
    int64_t v_tag_2440 = ((int64_t)v_t_2439.f[0]);
    if ((v_tag_2440 == ((int64_t)0ULL))) {
      V v_i_2443 = v_field_2441;
      v_t_2444 = heff_strSlice(v_typed_2437, MK_INT(0LL), heff_intAdd(v_i_2443, MK_INT(1LL)));
    } else {
      heff_drop(v_typed_2437);
      heff_drop(v_field_2441);
      v_t_2444 = ((V)&g_heff_2ebuild_2equery_2ecompletionsAt_str6);
    }
  }
  return ({ V a_0 = v_c_240; V a_1 = v_t_2435; V a_2 = v_t_2444; V a_3 = v_x_2433; V r_ = (g_heff_2ebuild_2equery_2ecompletionOf(a_0, a_1, a_2, a_3)); heff_drop(v_t_2435); heff_drop(v_t_2444); r_; });
}
Clo g_heff_2ebuild_2equery_2eeqTarget_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2eeqTarget_entry, 2, 0};

V g_heff_2ebuild_2equery_2eeqTarget(V v_a_240, V v_b_241) {
top: ;
  if (heff_strEq_c(heff_dup(heff_rfield(v_a_240, 0)), heff_dup(heff_rfield(v_b_241, 0)))) {
    V v_x2_243 = heff_take_field(v_b_241, 1);
    V v_t_244 = heff_take_field(v_a_240, 1);
    switch (heff_tag_of(v_t_244)) {
    case TAG_Nothing: {
      switch (heff_tag_of(v_x2_243)) {
      case TAG_Nothing: {
        V v_x2_245 = heff_get_n(v_b_241, 2, 3);
        V v_t_246 = heff_get_n(v_a_240, 2, 3);
        switch (heff_tag_of(v_t_246)) {
        case TAG_Nothing: {
          switch (heff_tag_of(v_x2_245)) {
          case TAG_Nothing: {
            return NTAG(TAG_True);
          }
          case TAG_Just: {
            heff_take_n(v_x2_245, 0ULL, 1);
            return NTAG(TAG_False);
          }
          default: return heff_nomatch(v_x2_245);
          }
        }
        case TAG_Just: {
          V v_a_248 = heff_field(v_t_246, 0);
          heff_take_n(v_t_246, 1ULL, 1);
          switch (heff_tag_of(v_x2_245)) {
          case TAG_Nothing: {
            heff_drop_rec(v_a_248, 2);
            return NTAG(TAG_False);
          }
          case TAG_Just: {
            V v_b_249 = heff_field(v_x2_245, 0);
            heff_take_n(v_x2_245, 1ULL, 1);
            V v_ret_24bool = heff_bool((heff_intEq_c(heff_dup(heff_rfield(v_a_248, 0)), heff_dup(heff_rfield(v_b_249, 0))) && heff_intEq_c(heff_dup(heff_rfield(v_a_248, 1)), heff_dup(heff_rfield(v_b_249, 1)))));
            heff_drop_rec(v_a_248, 2);
            heff_drop_rec(v_b_249, 2);
            return v_ret_24bool;
          }
          default: return heff_nomatch(v_x2_245);
          }
        }
        default: return heff_nomatch(v_t_246);
        }
      }
      case TAG_Just: {
        heff_take_n(v_x2_243, 0ULL, 1);
        heff_drop_rec(v_a_240, 3);
        heff_drop_rec(v_b_241, 3);
        return NTAG(TAG_False);
      }
      default: return heff_nomatch(v_x2_243);
      }
    }
    case TAG_Just: {
      V v_a_2412 = heff_field(v_t_244, 0);
      heff_take_n(v_t_244, 1ULL, 1);
      switch (heff_tag_of(v_x2_243)) {
      case TAG_Nothing: {
        heff_drop_rec(v_a_240, 3);
        heff_drop_rec(v_b_241, 3);
        heff_drop(v_a_2412);
        return NTAG(TAG_False);
      }
      case TAG_Just: {
        V v_b_2413 = heff_field(v_x2_243, 0);
        heff_take_n(v_x2_243, 1ULL, 1);
        if (heff_strEq_c(v_a_2412, v_b_2413)) {
          V v_x2_2415 = heff_get_n(v_b_241, 2, 3);
          V v_t_2416 = heff_get_n(v_a_240, 2, 3);
          switch (heff_tag_of(v_t_2416)) {
          case TAG_Nothing: {
            switch (heff_tag_of(v_x2_2415)) {
            case TAG_Nothing: {
              return NTAG(TAG_True);
            }
            case TAG_Just: {
              heff_take_n(v_x2_2415, 0ULL, 1);
              return NTAG(TAG_False);
            }
            default: return heff_nomatch(v_x2_2415);
            }
          }
          case TAG_Just: {
            V v_a_2418 = heff_field(v_t_2416, 0);
            heff_take_n(v_t_2416, 1ULL, 1);
            switch (heff_tag_of(v_x2_2415)) {
            case TAG_Nothing: {
              heff_drop_rec(v_a_2418, 2);
              return NTAG(TAG_False);
            }
            case TAG_Just: {
              V v_b_2419 = heff_field(v_x2_2415, 0);
              heff_take_n(v_x2_2415, 1ULL, 1);
              V v_ret_24bool = heff_bool((heff_intEq_c(heff_dup(heff_rfield(v_a_2418, 0)), heff_dup(heff_rfield(v_b_2419, 0))) && heff_intEq_c(heff_dup(heff_rfield(v_a_2418, 1)), heff_dup(heff_rfield(v_b_2419, 1)))));
              heff_drop_rec(v_a_2418, 2);
              heff_drop_rec(v_b_2419, 2);
              return v_ret_24bool;
            }
            default: return heff_nomatch(v_x2_2415);
            }
          }
          default: return heff_nomatch(v_t_2416);
          }
        } else {
          heff_drop_rec(v_a_240, 3);
          heff_drop_rec(v_b_241, 3);
          return NTAG(TAG_False);
        }
      }
      default: return heff_nomatch(v_x2_243);
      }
    }
    default: return heff_nomatch(v_t_244);
    }
  } else {
    heff_drop_rec(v_a_240, 3);
    heff_drop_rec(v_b_241, 3);
    return NTAG(TAG_False);
  }
}
V g_heff_2ebuild_2equery_2eeqTarget_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2equery_2eeqTarget(a[0], a[1]);
}
Clo g_heff_2ebuild_2equery_2esumTags_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2esumTags_entry, 1, 0};

V g_heff_2ebuild_2equery_2esumTags(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_At: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_EVar: {
      return NTAG(TAG_Nil);
    }
    case TAG_EImplicitVar: {
      return NTAG(TAG_Nil);
    }
    case TAG_ETag: {
      return NTAG(TAG_Nil);
    }
    case TAG_EInt: {
      return NTAG(TAG_Nil);
    }
    case TAG_EFloat: {
      return NTAG(TAG_Nil);
    }
    case TAG_EString: {
      return NTAG(TAG_Nil);
    }
    case TAG_EBinary: {
      return NTAG(TAG_Nil);
    }
    case TAG_ERune: {
      return NTAG(TAG_Nil);
    }
    case TAG_EWord: {
      return NTAG(TAG_Nil);
    }
    case TAG_EApp: {
      return NTAG(TAG_Nil);
    }
    case TAG_EProject: {
      return NTAG(TAG_Nil);
    }
    case TAG_ENamed: {
      return NTAG(TAG_Nil);
    }
    case TAG_EPi: {
      return NTAG(TAG_Nil);
    }
    case TAG_ELam: {
      return NTAG(TAG_Nil);
    }
    case TAG_EAnn: {
      return NTAG(TAG_Nil);
    }
    case TAG_ESpec: {
      return NTAG(TAG_Nil);
    }
    case TAG_ESig: {
      return NTAG(TAG_Nil);
    }
    case TAG_ESum: {
      V v_alts_2428 = heff_field(v_x11_241, 0);
      V v_t_2429 = (g_list_2emap_24s173442543x1801751270(heff_dup(v_alts_2428)));
      HEFF_LAST return g_heff_2ebuild_2equery_2ecatMaybesQ(v_t_2429);
    }
    case TAG_EStruct: {
      return NTAG(TAG_Nil);
    }
    case TAG_EUpdate: {
      return NTAG(TAG_Nil);
    }
    case TAG_EMatch: {
      return NTAG(TAG_Nil);
    }
    case TAG_ELetIn: {
      return NTAG(TAG_Nil);
    }
    case TAG_EDo: {
      return NTAG(TAG_Nil);
    }
    case TAG_ELocal: {
      return NTAG(TAG_Nil);
    }
    case TAG_EInvalid: {
      return NTAG(TAG_Nil);
    }
    case TAG_EAssign: {
      return NTAG(TAG_Nil);
    }
    case TAG_EWhile: {
      return NTAG(TAG_Nil);
    }
    case TAG_EFor: {
      return NTAG(TAG_Nil);
    }
    case TAG_EIfThen: {
      return NTAG(TAG_Nil);
    }
    case TAG_EBreak: {
      return NTAG(TAG_Nil);
    }
    case TAG_EContinue: {
      return NTAG(TAG_Nil);
    }
    case TAG_EReturn: {
      return NTAG(TAG_Nil);
    }
    case TAG_ENest: {
      return NTAG(TAG_Nil);
    }
    case TAG_EIfLet: {
      return NTAG(TAG_Nil);
    }
    case TAG_ETry: {
      return NTAG(TAG_Nil);
    }
    case TAG_EWith: {
      return NTAG(TAG_Nil);
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2equery_2esumTags_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2equery_2esumTags(a0); heff_drop(a0); return r;
}
Clo g_heff_2ebuild_2equery_2edeclSites_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2edeclSites_entry, 2, 0};

V g_heff_2ebuild_2equery_2edeclSites(V v_c_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_At: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24At = heff_take_reuse_n(v_x2_241, 1ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_DeclEquations: {
      V v_f_244 = heff_field(v_x21_242, 0);
      V v_fsp_245 = heff_field(v_x21_242, 1);
      V v_eqs_248 = heff_field(v_x21_242, 4);
      heff_take_n(v_x21_242, 19ULL, 5);
      V v_t_249 = (g_list_2emap_24s1675313341x192238134(v_eqs_248));
      V v_sps_2410 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_fsp_245, v_t_249});
      HeffT2 v_t_2411 = (g_list_2efind_24s1184231137x30317987_24cpr(v_f_244, heff_get_n(v_c_240, 7, 14)));
      {
        V v_field_2413 = v_t_2411.f[1];
        int64_t v_tag_2412 = ((int64_t)v_t_2411.f[0]);
        if ((v_tag_2412 == ((int64_t)0ULL))) {
          V v_o_2415 = v_field_2413;
          return (g_list_2emap_24s1817753698x509594538(heff_get_n(v_o_2415, 1, 2), v_f_244, v_sps_2410));
        } else {
          heff_drop(v_f_244);
          heff_drop_tag(v_sps_2410, 2);
          heff_drop(v_field_2413);
          return NTAG(TAG_Nil);
        }
      }
    }
    case TAG_DeclDefine: {
      V v_x_2416 = heff_field(v_x21_242, 0);
      V v_xsp_2417 = heff_field(v_x21_242, 1);
      V v_body_2420 = heff_field(v_x21_242, 4);
      heff_take_n(v_x21_242, 19ULL, 5);
      HeffT2 v_t_2421 = (g_list_2efind_24s1184231137x30317987_24cpr(v_x_2416, heff_dup(heff_rfield(v_c_240, 7))));
      V v_t_2427;
      {
        V v_field_2423 = v_t_2421.f[1];
        int64_t v_tag_2422 = ((int64_t)v_t_2421.f[0]);
        if ((v_tag_2422 == ((int64_t)0ULL))) {
          V v_o_2425 = v_field_2423;
          V v_t_2426 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_xsp_2417, NTAG(TAG_Nil)});
          v_t_2427 = (g_list_2emap_24s1817753698x509594538(heff_get_n(v_o_2425, 1, 2), heff_dup(v_x_2416), v_t_2426));
        } else {
          heff_drop_cell(v_ru_24x2_241_24At, 2);
          heff_drop(v_xsp_2417);
          heff_drop(v_field_2423);
          v_t_2427 = NTAG(TAG_Nil);
        }
      }
      V v_ms_2428 = ({ V a_0 = v_body_2420; V r_ = (g_heff_2ebuild_2equery_2esumTags(a_0)); heff_drop(v_body_2420); r_; });
      HeffT2 v_t_2429 = ({ V a_0 = v_x_2416; V a_1 = heff_get_n(v_c_240, 7, 14); HeffT2 r_ = (g_list_2efind_24s1184231137x30317987_24cpr(a_0, a_1)); heff_drop(v_x_2416); r_; });
      V v_t_2434;
      {
        V v_field_2431 = v_t_2429.f[1];
        int64_t v_tag_2430 = ((int64_t)v_t_2429.f[0]);
        if ((v_tag_2430 == ((int64_t)0ULL))) {
          V v_o_2433 = v_field_2431;
          v_t_2434 = (g_list_2emap_24s1266088736x105832553(heff_get_n(v_o_2433, 1, 2), v_ms_2428));
        } else {
          heff_drop(v_ms_2428);
          heff_drop(v_field_2431);
          v_t_2434 = NTAG(TAG_Nil);
        }
      }
      HEFF_LAST return g_prelude_2e_2b_2b(v_t_2427, v_t_2434);
    }
    case TAG_DeclTheory: {
      V v_x_2435 = heff_field(v_x21_242, 0);
      V v_xsp_2436 = heff_field(v_x21_242, 1);
      V v_x214_2438 = heff_field(v_x21_242, 3);
      heff_take_n(v_x21_242, 11ULL, 4);
      switch (heff_tag_of(v_x214_2438)) {
      case TAG_At: {
        V v_x2141_2439 = heff_field(v_x214_2438, 0);
        heff_take_n(v_x214_2438, 1ULL, 2);
        switch (heff_tag_of(v_x2141_2439)) {
        case TAG_EVar: {
          heff_take_n(v_x2141_2439, 0ULL, 1);
          heff_drop_rec(v_c_240, 14);
          heff_drop_cell(v_ru_24x2_241_24At, 2);
          heff_drop(v_x_2435);
          heff_drop(v_xsp_2436);
          return NTAG(TAG_Nil);
        }
        case TAG_EImplicitVar: {
          heff_take_n(v_x2141_2439, 0ULL, 1);
          heff_drop_rec(v_c_240, 14);
          heff_drop_cell(v_ru_24x2_241_24At, 2);
          heff_drop(v_x_2435);
          heff_drop(v_xsp_2436);
          return NTAG(TAG_Nil);
        }
        case TAG_ETag: {
          heff_take_n(v_x2141_2439, 0ULL, 1);
          heff_drop_rec(v_c_240, 14);
          heff_drop_cell(v_ru_24x2_241_24At, 2);
          heff_drop(v_x_2435);
          heff_drop(v_xsp_2436);
          return NTAG(TAG_Nil);
        }
        case TAG_EInt: {
          heff_take_n(v_x2141_2439, 0ULL, 1);
          heff_drop_rec(v_c_240, 14);
          heff_drop_cell(v_ru_24x2_241_24At, 2);
          heff_drop(v_x_2435);
          heff_drop(v_xsp_2436);
          return NTAG(TAG_Nil);
        }
        case TAG_EFloat: {
          heff_take_na(v_x2141_2439, 0ULL, 1);
          heff_drop_rec(v_c_240, 14);
          heff_drop_cell(v_ru_24x2_241_24At, 2);
          heff_drop(v_x_2435);
          heff_drop(v_xsp_2436);
          return NTAG(TAG_Nil);
        }
        case TAG_EString: {
          heff_take_n(v_x2141_2439, 0ULL, 1);
          heff_drop_rec(v_c_240, 14);
          heff_drop_cell(v_ru_24x2_241_24At, 2);
          heff_drop(v_x_2435);
          heff_drop(v_xsp_2436);
          return NTAG(TAG_Nil);
        }
        case TAG_EBinary: {
          heff_take_n(v_x2141_2439, 0ULL, 1);
          heff_drop_rec(v_c_240, 14);
          heff_drop_cell(v_ru_24x2_241_24At, 2);
          heff_drop(v_x_2435);
          heff_drop(v_xsp_2436);
          return NTAG(TAG_Nil);
        }
        case TAG_ERune: {
          heff_take_n(v_x2141_2439, 0ULL, 1);
          heff_drop_rec(v_c_240, 14);
          heff_drop_cell(v_ru_24x2_241_24At, 2);
          heff_drop(v_x_2435);
          heff_drop(v_xsp_2436);
          return NTAG(TAG_Nil);
        }
        case TAG_EWord: {
          heff_take_n(v_x2141_2439, 0ULL, 1);
          heff_drop_rec(v_c_240, 14);
          heff_drop_cell(v_ru_24x2_241_24At, 2);
          heff_drop(v_x_2435);
          heff_drop(v_xsp_2436);
          return NTAG(TAG_Nil);
        }
        case TAG_EApp: {
          heff_take_n(v_x2141_2439, 0ULL, 2);
          heff_drop_rec(v_c_240, 14);
          heff_drop_cell(v_ru_24x2_241_24At, 2);
          heff_drop(v_x_2435);
          heff_drop(v_xsp_2436);
          return NTAG(TAG_Nil);
        }
        case TAG_EProject: {
          heff_take_n(v_x2141_2439, 0ULL, 1);
          heff_drop_rec(v_c_240, 14);
          heff_drop_cell(v_ru_24x2_241_24At, 2);
          heff_drop(v_x_2435);
          heff_drop(v_xsp_2436);
          return NTAG(TAG_Nil);
        }
        case TAG_ENamed: {
          heff_take_n(v_x2141_2439, 0ULL, 2);
          heff_drop_rec(v_c_240, 14);
          heff_drop_cell(v_ru_24x2_241_24At, 2);
          heff_drop(v_x_2435);
          heff_drop(v_xsp_2436);
          return NTAG(TAG_Nil);
        }
        case TAG_EPi: {
          heff_take_n(v_x2141_2439, 0ULL, 2);
          heff_drop_rec(v_c_240, 14);
          heff_drop_cell(v_ru_24x2_241_24At, 2);
          heff_drop(v_x_2435);
          heff_drop(v_xsp_2436);
          return NTAG(TAG_Nil);
        }
        case TAG_ELam: {
          heff_take_n(v_x2141_2439, 0ULL, 2);
          heff_drop_rec(v_c_240, 14);
          heff_drop_cell(v_ru_24x2_241_24At, 2);
          heff_drop(v_x_2435);
          heff_drop(v_xsp_2436);
          return NTAG(TAG_Nil);
        }
        case TAG_EAnn: {
          heff_take_n(v_x2141_2439, 0ULL, 2);
          heff_drop_rec(v_c_240, 14);
          heff_drop_cell(v_ru_24x2_241_24At, 2);
          heff_drop(v_x_2435);
          heff_drop(v_xsp_2436);
          return NTAG(TAG_Nil);
        }
        case TAG_ESpec: {
          heff_take_n(v_x2141_2439, 0ULL, 4);
          heff_drop_rec(v_c_240, 14);
          heff_drop_cell(v_ru_24x2_241_24At, 2);
          heff_drop(v_x_2435);
          heff_drop(v_xsp_2436);
          return NTAG(TAG_Nil);
        }
        case TAG_ESig: {
          V v_fs_2465 = heff_field(v_x2141_2439, 0);
          heff_take_n(v_x2141_2439, 1ULL, 1);
          HeffT2 v_t_2466 = (g_list_2efind_24s1184231137x30317987_24cpr(v_x_2435, heff_dup(heff_rfield(v_c_240, 7))));
          V v_t_2472;
          {
            V v_field_2468 = v_t_2466.f[1];
            int64_t v_tag_2467 = ((int64_t)v_t_2466.f[0]);
            if ((v_tag_2467 == ((int64_t)0ULL))) {
              V v_o_2470 = v_field_2468;
              V v_t_2471 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_xsp_2436, NTAG(TAG_Nil)});
              v_t_2472 = (g_list_2emap_24s1817753698x509594538(heff_get_n(v_o_2470, 1, 2), heff_dup(v_x_2435), v_t_2471));
            } else {
              heff_drop_cell(v_ru_24x2_241_24At, 2);
              heff_drop(v_xsp_2436);
              heff_drop(v_field_2468);
              v_t_2472 = NTAG(TAG_Nil);
            }
          }
          V v_t_2473 = (g_list_2emap_24s2000102784x314586828(v_fs_2465));
          V v_ms_2474 = (g_heff_2ebuild_2equery_2ecatMaybesQ(v_t_2473));
          HeffT2 v_t_2475 = ({ V a_0 = v_x_2435; V a_1 = heff_get_n(v_c_240, 7, 14); HeffT2 r_ = (g_list_2efind_24s1184231137x30317987_24cpr(a_0, a_1)); heff_drop(v_x_2435); r_; });
          V v_t_2480;
          {
            V v_field_2477 = v_t_2475.f[1];
            int64_t v_tag_2476 = ((int64_t)v_t_2475.f[0]);
            if ((v_tag_2476 == ((int64_t)0ULL))) {
              V v_o_2479 = v_field_2477;
              v_t_2480 = (g_list_2emap_24s1266088736x105832553(heff_get_n(v_o_2479, 1, 2), v_ms_2474));
            } else {
              heff_drop(v_ms_2474);
              heff_drop(v_field_2477);
              v_t_2480 = NTAG(TAG_Nil);
            }
          }
          HEFF_LAST return g_prelude_2e_2b_2b(v_t_2472, v_t_2480);
        }
        case TAG_ESum: {
          heff_take_n(v_x2141_2439, 0ULL, 1);
          heff_drop_rec(v_c_240, 14);
          heff_drop_cell(v_ru_24x2_241_24At, 2);
          heff_drop(v_x_2435);
          heff_drop(v_xsp_2436);
          return NTAG(TAG_Nil);
        }
        case TAG_EStruct: {
          heff_take_n(v_x2141_2439, 0ULL, 1);
          heff_drop_rec(v_c_240, 14);
          heff_drop_cell(v_ru_24x2_241_24At, 2);
          heff_drop(v_x_2435);
          heff_drop(v_xsp_2436);
          return NTAG(TAG_Nil);
        }
        case TAG_EUpdate: {
          heff_take_n(v_x2141_2439, 0ULL, 2);
          heff_drop_rec(v_c_240, 14);
          heff_drop_cell(v_ru_24x2_241_24At, 2);
          heff_drop(v_x_2435);
          heff_drop(v_xsp_2436);
          return NTAG(TAG_Nil);
        }
        case TAG_EMatch: {
          heff_take_n(v_x2141_2439, 0ULL, 2);
          heff_drop_rec(v_c_240, 14);
          heff_drop_cell(v_ru_24x2_241_24At, 2);
          heff_drop(v_x_2435);
          heff_drop(v_xsp_2436);
          return NTAG(TAG_Nil);
        }
        case TAG_ELetIn: {
          heff_take_n(v_x2141_2439, 0ULL, 2);
          heff_drop_rec(v_c_240, 14);
          heff_drop_cell(v_ru_24x2_241_24At, 2);
          heff_drop(v_x_2435);
          heff_drop(v_xsp_2436);
          return NTAG(TAG_Nil);
        }
        case TAG_EDo: {
          heff_take_n(v_x2141_2439, 0ULL, 1);
          heff_drop_rec(v_c_240, 14);
          heff_drop_cell(v_ru_24x2_241_24At, 2);
          heff_drop(v_x_2435);
          heff_drop(v_xsp_2436);
          return NTAG(TAG_Nil);
        }
        case TAG_ELocal: {
          heff_take_n(v_x2141_2439, 0ULL, 2);
          heff_drop_rec(v_c_240, 14);
          heff_drop_cell(v_ru_24x2_241_24At, 2);
          heff_drop(v_x_2435);
          heff_drop(v_xsp_2436);
          return NTAG(TAG_Nil);
        }
        case TAG_EInvalid: {
          heff_take_n(v_x2141_2439, 0ULL, 1);
          heff_drop_rec(v_c_240, 14);
          heff_drop_cell(v_ru_24x2_241_24At, 2);
          heff_drop(v_x_2435);
          heff_drop(v_xsp_2436);
          return NTAG(TAG_Nil);
        }
        case TAG_EAssign: {
          heff_take_n(v_x2141_2439, 0ULL, 3);
          heff_drop_rec(v_c_240, 14);
          heff_drop_cell(v_ru_24x2_241_24At, 2);
          heff_drop(v_x_2435);
          heff_drop(v_xsp_2436);
          return NTAG(TAG_Nil);
        }
        case TAG_EWhile: {
          heff_take_n(v_x2141_2439, 0ULL, 2);
          heff_drop_rec(v_c_240, 14);
          heff_drop_cell(v_ru_24x2_241_24At, 2);
          heff_drop(v_x_2435);
          heff_drop(v_xsp_2436);
          return NTAG(TAG_Nil);
        }
        case TAG_EFor: {
          heff_take_n(v_x2141_2439, 0ULL, 3);
          heff_drop_rec(v_c_240, 14);
          heff_drop_cell(v_ru_24x2_241_24At, 2);
          heff_drop(v_x_2435);
          heff_drop(v_xsp_2436);
          return NTAG(TAG_Nil);
        }
        case TAG_EIfThen: {
          heff_take_n(v_x2141_2439, 0ULL, 2);
          heff_drop_rec(v_c_240, 14);
          heff_drop_cell(v_ru_24x2_241_24At, 2);
          heff_drop(v_x_2435);
          heff_drop(v_xsp_2436);
          return NTAG(TAG_Nil);
        }
        case TAG_EBreak: {
          heff_drop_rec(v_c_240, 14);
          heff_drop_cell(v_ru_24x2_241_24At, 2);
          heff_drop(v_x_2435);
          heff_drop(v_xsp_2436);
          return NTAG(TAG_Nil);
        }
        case TAG_EContinue: {
          heff_drop_rec(v_c_240, 14);
          heff_drop_cell(v_ru_24x2_241_24At, 2);
          heff_drop(v_x_2435);
          heff_drop(v_xsp_2436);
          return NTAG(TAG_Nil);
        }
        case TAG_EReturn: {
          heff_take_n(v_x2141_2439, 0ULL, 1);
          heff_drop_rec(v_c_240, 14);
          heff_drop_cell(v_ru_24x2_241_24At, 2);
          heff_drop(v_x_2435);
          heff_drop(v_xsp_2436);
          return NTAG(TAG_Nil);
        }
        case TAG_ENest: {
          heff_take_n(v_x2141_2439, 0ULL, 1);
          heff_drop_rec(v_c_240, 14);
          heff_drop_cell(v_ru_24x2_241_24At, 2);
          heff_drop(v_x_2435);
          heff_drop(v_xsp_2436);
          return NTAG(TAG_Nil);
        }
        case TAG_EIfLet: {
          heff_take_n(v_x2141_2439, 0ULL, 4);
          heff_drop_rec(v_c_240, 14);
          heff_drop_cell(v_ru_24x2_241_24At, 2);
          heff_drop(v_x_2435);
          heff_drop(v_xsp_2436);
          return NTAG(TAG_Nil);
        }
        case TAG_ETry: {
          heff_take_n(v_x2141_2439, 0ULL, 1);
          heff_drop_rec(v_c_240, 14);
          heff_drop_cell(v_ru_24x2_241_24At, 2);
          heff_drop(v_x_2435);
          heff_drop(v_xsp_2436);
          return NTAG(TAG_Nil);
        }
        case TAG_EWith: {
          heff_take_n(v_x2141_2439, 0ULL, 4);
          heff_drop_rec(v_c_240, 14);
          heff_drop_cell(v_ru_24x2_241_24At, 2);
          heff_drop(v_x_2435);
          heff_drop(v_xsp_2436);
          return NTAG(TAG_Nil);
        }
        default: return heff_nomatch(v_x2141_2439);
        }
      }
      default: return heff_nomatch(v_x214_2438);
      }
    }
    case TAG_DeclPrimitive: {
      V v_x_24114 = heff_field(v_x21_242, 0);
      V v_sp_24115 = heff_field(v_x21_242, 1);
      heff_take_n(v_x21_242, 3ULL, 3);
      HeffT2 v_t_24117 = (g_list_2efind_24s1184231137x30317987_24cpr(v_x_24114, heff_get_n(v_c_240, 7, 14)));
      {
        V v_field_24119 = v_t_24117.f[1];
        int64_t v_tag_24118 = ((int64_t)v_t_24117.f[0]);
        if ((v_tag_24118 == ((int64_t)0ULL))) {
          V v_o_24121 = v_field_24119;
          V v_t_24122 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_sp_24115, NTAG(TAG_Nil)});
          return (g_list_2emap_24s1817753698x509594538(heff_get_n(v_o_24121, 1, 2), v_x_24114, v_t_24122));
        } else {
          heff_drop_cell(v_ru_24x2_241_24At, 2);
          heff_drop(v_x_24114);
          heff_drop(v_sp_24115);
          heff_drop(v_field_24119);
          return NTAG(TAG_Nil);
        }
      }
    }
    case TAG_DeclTest: {
      heff_take_n(v_x21_242, 0ULL, 2);
      heff_drop_rec(v_c_240, 14);
      heff_drop_cell(v_ru_24x2_241_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_DeclWatch: {
      heff_take_n(v_x21_242, 0ULL, 1);
      heff_drop_rec(v_c_240, 14);
      heff_drop_cell(v_ru_24x2_241_24At, 2);
      return NTAG(TAG_Nil);
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2equery_2edeclSites_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2equery_2edeclSites(a[0], a[1]);
}
Clo g_heff_2ebuild_2equery_2edefinesGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2edefinesGo_entry, 4, 0};

V g_heff_2ebuild_2equery_2edefinesGo(V v_k_240, V v_c_241, V v_x3_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_c_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_o_244 = heff_field(v_x3_242, 0);
    V v_os_245 = heff_field(v_x3_242, 1);
    switch (heff_tag_of(v_x4_243)) {
    case TAG_Nil: {
      heff_drop(v_c_241);
      return NTAG(TAG_Nothing);
    }
    case TAG_Cons: {
      V v_x41_246 = heff_field(v_x4_243, 0);
      V v_sps_247 = heff_field(v_x4_243, 1);
      switch (heff_tag_of(v_x41_246)) {
      case TAG_MkPair: {
        V v_sp_249 = heff_field(v_x41_246, 1);
        if (heff_strEq_c(heff_dup(heff_rfield(v_o_244, 1)), heff_dup(v_k_240))) {
          V v_t_2411 = heff_rec_n(3, shape_c__name__span, (V[]){v_c_241, heff_dup(heff_rfield(v_o_244, 0)), heff_dup(v_sp_249)});
          return heff_tag_n(TAG_Just, 1, (V[]){v_t_2411});
        } else {
          V t_0 = v_k_240;
          V t_1 = v_c_241;
          V t_2 = v_os_245;
          V t_3 = v_sps_247;
          v_k_240 = t_0;
          v_c_241 = t_1;
          v_x3_242 = t_2;
          v_x4_243 = t_3;
          goto top;
        }
      }
      default: return heff_nomatch(v_x41_246);
      }
    }
    default: return heff_nomatch(v_x4_243);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2equery_2edefinesGo_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a2 = a[2]; V a3 = a[3]; V r = g_heff_2ebuild_2equery_2edefinesGo(a0, a[1], a2, a3); heff_drop(a0); heff_drop(a2); heff_drop(a3); return r;
}
V g_heff_2ebuild_2equery_2edefinitionIn_lam0(V self, V *args);
V g_heff_2ebuild_2equery_2edefinitionIn_lam1(V self, V *args);
Clo g_heff_2ebuild_2equery_2edefinitionIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2edefinitionIn_entry, 3, 0};

V g_heff_2ebuild_2equery_2edefinitionIn(V v_i_240, V v_k_241, V v_d_242) {
top: ;
  V v_t_243 = heff_get_n(heff_dup(heff_rfield(v_d_242, 0)), 1, 14);
  V v_t_244 = heff_get_n(heff_dup(heff_rfield(v_d_242, 0)), 3, 14);
  V v_c_245 = heff_dup(heff_rfield(v_d_242, 0));
  V v_t_246 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(heff_rfield(v_c_245, 4))));
  V v_t_2410 = ({ V a_0 = heff_clo_n(g_heff_2ebuild_2equery_2edefinitionIn_lam0, 2, 1, (V[]){v_c_245}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_246; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_246); r_; });
  HeffT2 v_t_2415 = (g_list_2efind_24cpr(heff_clo_n(g_heff_2ebuild_2equery_2edefinitionIn_lam1, 1, 2, (V[]){heff_dup(v_i_240), v_k_241}), v_t_2410));
  V v_t_2422;
  {
    V v_field_2417 = v_t_2415.f[1];
    int64_t v_tag_2416 = ((int64_t)v_t_2415.f[0]);
    if ((v_tag_2416 == ((int64_t)0ULL))) {
      heff_drop_rec(v_i_240, 5);
      heff_drop_rec(v_d_242, 3);
      V v_s_2419 = v_field_2417;
      v_t_2422 = heff_get_n(v_s_2419, 2, 3);
    } else {
      heff_drop(v_field_2417);
      V v_sp_2420 = heff_take_field(v_d_242, 2);
      V v_t_2421 = heff_get_n(heff_get_n(v_d_242, 0, 3), 3, 14);
      v_t_2422 = ({ V a_0 = v_t_2421; V b_1 = heff_get_n(v_i_240, 1, 5); V a_2 = heff_dup(v_sp_2420); V a_3 = heff_get_n(v_sp_2420, 0, 2); V r_ = (g_heff_2ebuild_2equery_2enameInGo(a_0, b_1, a_2, a_3)); heff_drop(v_t_2421); heff_drop(b_1); r_; });
    }
  }
  return heff_rec_n(3, shape_path__source__span, (V[]){v_t_243, v_t_244, v_t_2422});
}
V g_heff_2ebuild_2equery_2edefinitionIn_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2equery_2edefinitionIn(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2equery_2edefinitionIn_lam0(V self, V *args) {
  V v_acc_247 = args[0];
  V v_x_248 = args[1];
  V v_c_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_249 = (g_heff_2ebuild_2equery_2edeclSites(v_c_245, v_x_248));
  return (g_prelude_2e_2b_2b(v_t_249, v_acc_247));
}
V g_heff_2ebuild_2equery_2edefinitionIn_lam1(V self, V *args) {
  V v_s_2411 = args[0];
  V v_i_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2412 = heff_take_field(v_i_240, 3);
  V v_t_2414;
  if ((heff_dup(v_t_2412) == NTAG(TAG_True))) {
    heff_drop(v_t_2412);
    V v_t_2413 = heff_tag_n(TAG_Just, 1, (V[]){heff_get_n(v_i_240, 1, 5)});
    v_t_2414 = heff_rec_n(3, shape_key__member__local, (V[]){v_k_241, v_t_2413, NTAG(TAG_Nothing)});
  } else {
    heff_drop_rec(v_i_240, 5);
    heff_drop(v_t_2412);
    v_t_2414 = heff_rec_n(3, shape_key__member__local, (V[]){v_k_241, NTAG(TAG_Nothing), NTAG(TAG_Nothing)});
  }
  return (g_heff_2ebuild_2equery_2eeqTarget(heff_get_n(v_s_2411, 0, 3), v_t_2414));
}
V g_heff_2ebuild_2equery_2edefinitionAt_24cpr_lam0(V self, V *args);

HeffT2 g_heff_2ebuild_2equery_2edefinitionAt_24cpr(V v_program_240, V v_off_241) {
top: ;
  V v_x1_242 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_program_240)));
  switch (heff_tag_of(v_x1_242)) {
  case TAG_Nil: {
    heff_drop(v_program_240);
    heff_drop(v_off_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x1_242, 0);
    heff_take_n(v_x1_242, 1ULL, 2);
    V v_t_245 = heff_get_n(heff_get_n(v_x_243, 5, 14), 7, 9);
    V v_t_246 = (g_list_2efilter_24s1109331425x852844386(MK_INT(1LL), v_off_241, v_t_245));
    V v_x1_247 = (g_list_2esortBy_24s1681607803x465385494(v_t_246));
    switch (heff_tag_of(v_x1_247)) {
    case TAG_Nil: {
      heff_drop(v_program_240);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_Cons: {
      V v_x_248 = heff_field(v_x1_247, 0);
      heff_take_n(v_x1_247, 1ULL, 2);
      V v_t_2410 = heff_dup(heff_rfield(v_x_248, 2));
      switch (heff_tag_of(v_t_2410)) {
      case TAG_Nothing: {
        heff_drop(v_program_240);
        heff_drop_rec(v_x_248, 5);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
      case TAG_Just: {
        V v_k_2411 = heff_field(v_t_2410, 0);
        heff_take_n(v_t_2410, 1ULL, 1);
        V v_t_2412 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_program_240));
        V v_t_2415 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2equery_2edefinitionAt_24cpr_lam0, 1, 1, (V[]){heff_dup(v_k_2411)}), v_t_2412));
        V v_x1_2416 = (g_heff_2ebuild_2equery_2ecatMaybesQ(v_t_2415));
        switch (heff_tag_of(v_x1_2416)) {
        case TAG_Nil: {
          heff_drop_rec(v_x_248, 5);
          heff_drop(v_k_2411);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
        case TAG_Cons: {
          V v_x_2417 = heff_field(v_x1_2416, 0);
          heff_take_n(v_x1_2416, 1ULL, 2);
          V v_f_2419 = (g_heff_2ebuild_2equery_2edefinitionIn(v_x_248, v_k_2411, v_x_2417));
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2419}});
        }
        default: return ((HeffT2){{heff_nomatch(v_x1_2416)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_t_2410)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x1_247)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_242)}});
  }
}
V g_heff_2ebuild_2equery_2edefinitionAt_24cpr_lam0(V self, V *args) {
  V v_c2_2413 = args[0];
  V v_k_2411 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2414 = heff_get_n(heff_dup(heff_rfield(v_c2_2413, 5)), 6, 9);
  return ({ V a_0 = v_k_2411; V a_1 = heff_dup(v_c2_2413); V b_2 = heff_get_n(v_c2_2413, 7, 14); V a_3 = v_t_2414; V r_ = (g_heff_2ebuild_2equery_2edefinesGo(a_0, a_1, b_2, a_3)); heff_drop(v_k_2411); heff_drop(b_2); heff_drop(v_t_2414); r_; });
}

HeffT2 g_heff_2ebuild_2equery_2eownNameOf_24cpr(V v_x1_240, V v_k_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_c_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 3ULL, 2);
    HeffT2 v_t_244 = (g_list_2efind_24s988189774x1593035904_24cpr(v_k_241, heff_get_n(v_c_242, 7, 14)));
    {
      V v_field_246 = v_t_244.f[1];
      int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
      if ((v_tag_245 == ((int64_t)0ULL))) {
        heff_drop(v_rest_243);
        V v_o_248 = v_field_246;
        V v_f_249 = heff_get_n(v_o_248, 0, 2);
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_249}});
      } else {
        heff_drop(v_field_246);
        V t_0 = v_rest_243;
        V t_1 = v_k_241;
        v_x1_240 = t_0;
        v_k_241 = t_1;
        goto top;
      }
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
V g_heff_2ebuild_2equery_2esiteFound_24cpr_lam0(V self, V *args);

HeffT2 g_heff_2ebuild_2equery_2esiteFound_24cpr(V v_program_240, V v_c_241, V v_off_242) {
top: ;
  V v_t_243 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(heff_rfield(v_c_241, 4))));
  V v_t_247 = ({ V a_0 = heff_clo_n(g_heff_2ebuild_2equery_2esiteFound_24cpr_lam0, 2, 1, (V[]){v_c_241}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_243; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_243); r_; });
  HeffT2 v_t_248 = (g_list_2efind_24s361650052x1432786508_24cpr(v_off_242, v_t_247));
  {
    V v_field_2410 = v_t_248.f[1];
    int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
    if ((v_tag_249 == ((int64_t)0ULL))) {
      V v_s_2412 = v_field_2410;
      V v_t_2413 = heff_get_n(v_s_2412, 0, 3);
      V v_t_2414 = heff_dup(heff_rfield(v_t_2413, 1));
      switch (heff_tag_of(v_t_2414)) {
      case TAG_Nothing: {
        HeffT2 v_t_2415 = (g_heff_2ebuild_2equery_2eownNameOf_24cpr(v_program_240, heff_rfield(v_t_2413, 0)));
        {
          V v_field_2417 = v_t_2415.f[1];
          int64_t v_tag_2416 = ((int64_t)v_t_2415.f[0]);
          if ((v_tag_2416 == ((int64_t)0ULL))) {
            V v_x_2419 = v_field_2417;
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_rec_n(2, shape_target__name, (V[]){v_t_2413, v_x_2419})}});
          } else {
            heff_drop_rec(v_t_2413, 3);
            heff_drop(v_field_2417);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
        }
      }
      case TAG_Just: {
        V v_m_2420 = heff_field(v_t_2414, 0);
        heff_take_n(v_t_2414, 1ULL, 1);
        heff_drop(v_program_240);
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_rec_n(2, shape_target__name, (V[]){v_t_2413, v_m_2420})}});
      }
      default: return ((HeffT2){{heff_nomatch(v_t_2414)}});
      }
    } else {
      heff_drop(v_program_240);
      heff_drop(v_field_2410);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
  }
}
V g_heff_2ebuild_2equery_2esiteFound_24cpr_lam0(V self, V *args) {
  V v_acc_244 = args[0];
  V v_x_245 = args[1];
  V v_c_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_246 = (g_heff_2ebuild_2equery_2edeclSites(v_c_241, v_x_245));
  return (g_prelude_2e_2b_2b(v_t_246, v_acc_244));
}
V g_heff_2ebuild_2equery_2efieldFound_24cpr_lam0(V self, V *args);

HeffT2 g_heff_2ebuild_2equery_2efieldFound_24cpr(V v_program_240, V v_c_241, V v_ls_242, V v_off_243) {
top: ;
  HeffT2 v_t_244 = (g_list_2efind_24s1085725546x1737150855_24cpr(v_off_243, heff_get_n(v_ls_242, 1, 2)));
  {
    V v_field_246 = v_t_244.f[1];
    int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
    if ((v_tag_245 == ((int64_t)0ULL))) {
      V v_f_248 = v_field_246;
      V v_t_249 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(heff_rfield(v_c_241, 4))));
      V v_t_2413 = ({ V a_0 = heff_clo_n(g_heff_2ebuild_2equery_2efieldFound_24cpr_lam0, 2, 1, (V[]){v_c_241}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_249; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_249); r_; });
      HeffT2 v_t_2414 = (g_list_2efind_24s582687515x818787580_24cpr(v_f_248, v_t_2413));
      {
        V v_field_2416 = v_t_2414.f[1];
        int64_t v_tag_2415 = ((int64_t)v_t_2414.f[0]);
        if ((v_tag_2415 == ((int64_t)0ULL))) {
          V v_s_2418 = v_field_2416;
          V v_t_2419 = heff_get_n(v_s_2418, 0, 3);
          V v_t_2420 = heff_dup(heff_rfield(v_t_2419, 1));
          switch (heff_tag_of(v_t_2420)) {
          case TAG_Nothing: {
            HeffT2 v_t_2421 = (g_heff_2ebuild_2equery_2eownNameOf_24cpr(v_program_240, heff_rfield(v_t_2419, 0)));
            {
              V v_field_2423 = v_t_2421.f[1];
              int64_t v_tag_2422 = ((int64_t)v_t_2421.f[0]);
              if ((v_tag_2422 == ((int64_t)0ULL))) {
                V v_x_2425 = v_field_2423;
                return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_rec_n(2, shape_target__name, (V[]){v_t_2419, v_x_2425})}});
              } else {
                heff_drop_rec(v_t_2419, 3);
                heff_drop(v_field_2423);
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
              }
            }
          }
          case TAG_Just: {
            V v_m_2426 = heff_field(v_t_2420, 0);
            heff_take_n(v_t_2420, 1ULL, 1);
            heff_drop(v_program_240);
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_rec_n(2, shape_target__name, (V[]){v_t_2419, v_m_2426})}});
          }
          default: return ((HeffT2){{heff_nomatch(v_t_2420)}});
          }
        } else {
          heff_drop(v_program_240);
          heff_drop(v_field_2416);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
      }
    } else {
      heff_drop(v_program_240);
      heff_drop_rec(v_c_241, 14);
      heff_drop(v_field_246);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
  }
}
V g_heff_2ebuild_2equery_2efieldFound_24cpr_lam0(V self, V *args) {
  V v_acc_2410 = args[0];
  V v_x_2411 = args[1];
  V v_c_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2412 = (g_heff_2ebuild_2equery_2edeclSites(v_c_241, v_x_2411));
  return (g_prelude_2e_2b_2b(v_t_2412, v_acc_2410));
}
V g_heff_2ebuild_2equery_2elocalFound_lam0(V self, V *args);
Clo g_heff_2ebuild_2equery_2elocalFound_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2elocalFound_entry, 3, 0};

V g_heff_2ebuild_2equery_2elocalFound(V v_c_240, V v_ls_241, V v_off_242) {
top: ;
  HeffT2 v_t_247 = (g_list_2efind_24cpr(heff_clo_n(g_heff_2ebuild_2equery_2elocalFound_lam0, 1, 1, (V[]){v_off_242}), heff_get_n(v_ls_241, 0, 2)));
  {
    V v_field_249 = v_t_247.f[1];
    int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
    if ((v_tag_248 == ((int64_t)0ULL))) {
      V v_l_2411 = v_field_249;
      V v_t_2412 = heff_tag_n(TAG_Just, 1, (V[]){heff_take_field(v_l_2411, 1)});
      V v_t_2413 = heff_rec_n(3, shape_key__member__local, (V[]){heff_get_n(v_c_240, 1, 14), NTAG(TAG_Nothing), v_t_2412});
      V v_t_2414 = heff_rec_n(2, shape_target__name, (V[]){v_t_2413, heff_get_n(v_l_2411, 0, 3)});
      return heff_tag_n(TAG_Just, 1, (V[]){v_t_2414});
    } else {
      heff_drop_rec(v_c_240, 14);
      heff_drop(v_field_249);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_heff_2ebuild_2equery_2elocalFound_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2equery_2elocalFound(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2equery_2elocalFound_lam0(V self, V *args) {
  V v_l_243 = args[0];
  V v_off_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_sp_244 = heff_take_field(v_l_243, 1);
  if (heff_intLe_c(heff_dup(heff_rfield(v_sp_244, 0)), heff_dup(v_off_242))) {
    if (heff_intLe_c(heff_dup(v_off_242), heff_get_n(v_sp_244, 1, 2))) {
      heff_drop_rec(v_l_243, 3);
      heff_drop(v_off_242);
      return NTAG(TAG_True);
    } else {
      return ({ V a_0 = v_off_242; V b_1 = heff_get_n(v_l_243, 2, 3); V r_ = (g_list_2eany_24s430343851x1474283355(a_0, b_1)); heff_drop(b_1); r_; });
    }
  } else {
    heff_drop_rec(v_sp_244, 2);
    return ({ V a_0 = v_off_242; V b_1 = heff_get_n(v_l_243, 2, 3); V r_ = (g_list_2eany_24s430343851x1474283355(a_0, b_1)); heff_drop(b_1); r_; });
  }
}
Clo g_heff_2ebuild_2equery_2etargetIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2etargetIn_entry, 4, 0};

V g_heff_2ebuild_2equery_2etargetIn(V v_program_240, V v_c_241, V v_ls_242, V v_off_243) {
top: ;
  V v_t_244 = heff_get_n(heff_dup(heff_rfield(v_c_241, 5)), 7, 9);
  V v_t_245 = (g_list_2efilter_24s1109331425x852844386(MK_INT(1LL), heff_dup(v_off_243), v_t_244));
  V v_x1_246 = (g_list_2esortBy_24s1681607803x465385494(v_t_245));
  switch (heff_tag_of(v_x1_246)) {
  case TAG_Nil: {
    HeffT2 v_t_247 = (g_heff_2ebuild_2equery_2esiteFound_24cpr(heff_dup(v_program_240), heff_dup(v_c_241), heff_dup(v_off_243)));
    {
      V v_field_249 = v_t_247.f[1];
      int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
      HeffT2 v_t_2410 = (g_heff_2ebuild_2equery_2efieldFound_24cpr(v_program_240, heff_dup(v_c_241), heff_dup(v_ls_242), heff_dup(v_off_243)));
      {
        V v_field_2412 = v_t_2410.f[1];
        int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
        V v_x2_2413 = (g_heff_2ebuild_2equery_2elocalFound(v_c_241, v_ls_242, v_off_243));
        if ((v_tag_248 == ((int64_t)0ULL))) {
          heff_drop(v_field_2412);
          heff_drop(v_x2_2413);
          V v_x_2415 = v_field_249;
          return heff_tag_n(TAG_Just, 1, (V[]){v_x_2415});
        } else {
          heff_drop(v_field_249);
          if ((v_tag_2411 == ((int64_t)0ULL))) {
            heff_drop(v_x2_2413);
            V v_x_2417 = v_field_2412;
            return heff_tag_n(TAG_Just, 1, (V[]){v_x_2417});
          } else {
            heff_drop(v_field_2412);
            return v_x2_2413;
          }
        }
      }
    }
  }
  case TAG_Cons: {
    V v_x_2418 = heff_field(v_x1_246, 0);
    heff_take_n(v_x1_246, 1ULL, 2);
    V v_t_2420 = heff_take_field(v_x_2418, 2);
    switch (heff_tag_of(v_t_2420)) {
    case TAG_Nothing: {
      heff_drop_rec(v_x_2418, 5);
      HeffT2 v_t_2421 = (g_heff_2ebuild_2equery_2esiteFound_24cpr(heff_dup(v_program_240), heff_dup(v_c_241), heff_dup(v_off_243)));
      {
        V v_field_2423 = v_t_2421.f[1];
        int64_t v_tag_2422 = ((int64_t)v_t_2421.f[0]);
        HeffT2 v_t_2424 = (g_heff_2ebuild_2equery_2efieldFound_24cpr(v_program_240, heff_dup(v_c_241), heff_dup(v_ls_242), heff_dup(v_off_243)));
        {
          V v_field_2426 = v_t_2424.f[1];
          int64_t v_tag_2425 = ((int64_t)v_t_2424.f[0]);
          V v_x2_2427 = (g_heff_2ebuild_2equery_2elocalFound(v_c_241, v_ls_242, v_off_243));
          if ((v_tag_2422 == ((int64_t)0ULL))) {
            heff_drop(v_field_2426);
            heff_drop(v_x2_2427);
            V v_x_2429 = v_field_2423;
            return heff_tag_n(TAG_Just, 1, (V[]){v_x_2429});
          } else {
            heff_drop(v_field_2423);
            if ((v_tag_2425 == ((int64_t)0ULL))) {
              heff_drop(v_x2_2427);
              V v_x_2431 = v_field_2426;
              return heff_tag_n(TAG_Just, 1, (V[]){v_x_2431});
            } else {
              heff_drop(v_field_2426);
              return v_x2_2427;
            }
          }
        }
      }
    }
    case TAG_Just: {
      V v_k_2432 = heff_field(v_t_2420, 0);
      V v_ru_24t_2420_24Just = heff_take_reuse_n(v_t_2420, 1ULL, 1);
      heff_drop_rec(v_c_241, 14);
      heff_drop(v_ls_242);
      heff_drop(v_off_243);
      V v_t_2433 = heff_take_field(v_x_2418, 3);
      V v_t_2435;
      if ((heff_dup(v_t_2433) == NTAG(TAG_True))) {
        heff_drop(v_t_2433);
        V v_t_2434 = heff_tag_at_n(v_ru_24t_2420_24Just, TAG_Just, 1, (V[]){heff_get_n(v_x_2418, 1, 5)});
        v_t_2435 = heff_rec_n(3, shape_key__member__local, (V[]){v_k_2432, v_t_2434, NTAG(TAG_Nothing)});
      } else {
        heff_drop_rec(v_x_2418, 5);
        heff_drop_cell(v_ru_24t_2420_24Just, 1);
        heff_drop(v_t_2433);
        v_t_2435 = heff_rec_n(3, shape_key__member__local, (V[]){v_k_2432, NTAG(TAG_Nothing), NTAG(TAG_Nothing)});
      }
      V v_t_2436 = heff_dup(heff_rfield(v_t_2435, 1));
      switch (heff_tag_of(v_t_2436)) {
      case TAG_Nothing: {
        HeffT2 v_t_2437 = (g_heff_2ebuild_2equery_2eownNameOf_24cpr(v_program_240, heff_rfield(v_t_2435, 0)));
        {
          V v_field_2439 = v_t_2437.f[1];
          int64_t v_tag_2438 = ((int64_t)v_t_2437.f[0]);
          if ((v_tag_2438 == ((int64_t)0ULL))) {
            V v_x_2441 = v_field_2439;
            return heff_tag_n(TAG_Just, 1, (V[]){heff_rec_n(2, shape_target__name, (V[]){v_t_2435, v_x_2441})});
          } else {
            heff_drop_rec(v_t_2435, 3);
            heff_drop(v_field_2439);
            return NTAG(TAG_Nothing);
          }
        }
      }
      case TAG_Just: {
        V v_m_2442 = heff_field(v_t_2436, 0);
        V v_ru_24t_2436_24Just = heff_take_reuse_n(v_t_2436, 1ULL, 1);
        heff_drop(v_program_240);
        return heff_tag_at_n(v_ru_24t_2436_24Just, TAG_Just, 1, (V[]){heff_rec_n(2, shape_target__name, (V[]){v_t_2435, v_m_2442})});
      }
      default: return heff_nomatch(v_t_2436);
      }
    }
    default: return heff_nomatch(v_t_2420);
    }
  }
  default: return heff_nomatch(v_x1_246);
  }
}
V g_heff_2ebuild_2equery_2etargetIn_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2equery_2etargetIn(a[0], a[1], a[2], a[3]);
}
Clo g_heff_2ebuild_2equery_2euseOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2euseOf_entry, 3, 0};

V g_heff_2ebuild_2equery_2euseOf(V v_t_240, V v_name_241, V v_i_242) {
top: ;
  V v_t_243 = heff_take_field(v_i_242, 2);
  switch (heff_tag_of(v_t_243)) {
  case TAG_Nothing: {
    heff_drop_rec(v_t_240, 3);
    heff_drop_rec(v_i_242, 5);
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_a_244 = heff_field(v_t_243, 0);
    V v_ru_24t_243_24Just = heff_take_reuse_n(v_t_243, 1ULL, 1);
    if (heff_strEq_c(v_a_244, heff_dup(heff_rfield(v_t_240, 0)))) {
      V v_t_246 = heff_take_field(v_i_242, 3);
      if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
        heff_drop(v_t_246);
        V v_t_247 = heff_get_n(v_t_240, 1, 3);
        switch (heff_tag_of(v_t_247)) {
        case TAG_Nothing: {
          heff_drop_rec(v_i_242, 5);
          heff_drop_cell(v_ru_24t_243_24Just, 1);
          return NTAG(TAG_Nothing);
        }
        case TAG_Just: {
          V v_a_248 = heff_field(v_t_247, 0);
          heff_take_n(v_t_247, 1ULL, 1);
          if (heff_strEq_c(v_a_248, heff_dup(heff_rfield(v_i_242, 1)))) {
            V v_x_2410 = heff_get_n(heff_dup(heff_rfield(v_i_242, 0)), 0, 2);
            V v_t_2411 = heff_get_n(heff_dup(heff_rfield(v_i_242, 0)), 1, 2);
            V v_y_2412 = heff_intSub(v_t_2411, heff_strLength_lent(v_name_241, 0));
            V v_t_2414;
            if (heff_intLe_c_lent(v_x_2410, v_y_2412, 0)) {
              heff_drop(v_x_2410);
              v_t_2414 = v_y_2412;
            } else {
              heff_drop(v_y_2412);
              v_t_2414 = v_x_2410;
            }
            V v_t_2415 = heff_get_n(heff_get_n(v_i_242, 0, 5), 1, 2);
            return heff_tag_at_n(v_ru_24t_243_24Just, TAG_Just, 1, (V[]){heff_rec_n(2, shape_start__end, (V[]){v_t_2414, v_t_2415})});
          } else {
            heff_drop_rec(v_i_242, 5);
            heff_drop_cell(v_ru_24t_243_24Just, 1);
            return NTAG(TAG_Nothing);
          }
        }
        default: return heff_nomatch(v_t_247);
        }
      } else {
        heff_drop(v_t_246);
        V v_t_2416 = heff_get_n(v_t_240, 1, 3);
        switch (heff_tag_of(v_t_2416)) {
        case TAG_Nothing: {
          V v_x_2417 = heff_get_n(heff_dup(heff_rfield(v_i_242, 0)), 0, 2);
          V v_t_2418 = heff_get_n(heff_dup(heff_rfield(v_i_242, 0)), 1, 2);
          V v_y_2419 = heff_intSub(v_t_2418, heff_strLength_lent(v_name_241, 0));
          V v_t_2421;
          if (heff_intLe_c_lent(v_x_2417, v_y_2419, 0)) {
            heff_drop(v_x_2417);
            v_t_2421 = v_y_2419;
          } else {
            heff_drop(v_y_2419);
            v_t_2421 = v_x_2417;
          }
          V v_t_2422 = heff_get_n(heff_get_n(v_i_242, 0, 5), 1, 2);
          return heff_tag_at_n(v_ru_24t_243_24Just, TAG_Just, 1, (V[]){heff_rec_n(2, shape_start__end, (V[]){v_t_2421, v_t_2422})});
        }
        case TAG_Just: {
          heff_take_n(v_t_2416, 0ULL, 1);
          heff_drop_rec(v_i_242, 5);
          heff_drop_cell(v_ru_24t_243_24Just, 1);
          return NTAG(TAG_Nothing);
        }
        default: return heff_nomatch(v_t_2416);
        }
      }
    } else {
      heff_drop_rec(v_t_240, 3);
      heff_drop_rec(v_i_242, 5);
      heff_drop_cell(v_ru_24t_243_24Just, 1);
      return NTAG(TAG_Nothing);
    }
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_heff_2ebuild_2equery_2euseOf_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2equery_2euseOf(a[0], a1, a[2]); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ebuild_2equery_2ewordsOf_str0, 1, " ");
HEFF_LIT(g_heff_2ebuild_2equery_2ewordsOf_str1, 1, " ");
HEFF_LIT(g_heff_2ebuild_2equery_2ewordsOf_str2, 1, " ");
Clo g_heff_2ebuild_2equery_2ewordsOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2ewordsOf_entry, 4, 0};

V g_heff_2ebuild_2equery_2ewordsOf(V v_base_240, V v_line_241, V v_i_242, V v_acc_243) {
top: ;
  if (heff_intLe_c(heff_strLength_lent(v_line_241, 0), heff_dup(v_i_242))) {
    heff_drop(v_base_240);
    heff_drop(v_i_242);
    return (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_243));
  } else {
    if ((heff_unbox_word(heff_strByteAt_lent(v_line_241, v_i_242, 0)) == ((int64_t)32ULL))) {
      V t_0 = v_base_240;
      V t_1 = v_line_241;
      V t_2 = heff_box_word((heff_unbox_word(v_i_242) + ((int64_t)1ULL)));
      V t_3 = v_acc_243;
      v_base_240 = t_0;
      v_line_241 = t_1;
      v_i_242 = t_2;
      v_acc_243 = t_3;
      goto top;
    } else {
      V v_j_246 = heff_strFind_lent(((V)&g_heff_2ebuild_2equery_2ewordsOf_str0), v_line_241, v_i_242, 1);
      V v_t_248;
      if (heff_intLt_c_lent(v_j_246, MK_INT(0LL), 2)) {
        heff_drop(v_j_246);
        v_t_248 = heff_strLength_lent(v_line_241, 0);
      } else {
        v_t_248 = v_j_246;
      }
      V v_j_249 = heff_strFind_lent(((V)&g_heff_2ebuild_2equery_2ewordsOf_str1), v_line_241, v_i_242, 1);
      V v_t_2411;
      if (heff_intLt_c_lent(v_j_249, MK_INT(0LL), 2)) {
        heff_drop(v_j_249);
        v_t_2411 = heff_strLength_lent(v_line_241, 0);
      } else {
        v_t_2411 = v_j_249;
      }
      V v_j_2412 = heff_strFind_lent(((V)&g_heff_2ebuild_2equery_2ewordsOf_str2), v_line_241, v_i_242, 1);
      V v_t_2414;
      if (heff_intLt_c_lent(v_j_2412, MK_INT(0LL), 2)) {
        heff_drop(v_j_2412);
        v_t_2414 = heff_strLength_lent(v_line_241, 0);
      } else {
        v_t_2414 = v_j_2412;
      }
      V v_e_2415 = heff_intAdd(heff_dup(v_base_240), v_t_2414);
      V v_t_2416 = heff_rec_n(2, shape_start__end, (V[]){heff_intAdd(heff_dup(v_base_240), heff_dup(v_i_242)), v_e_2415});
      V v_t_2417 = heff_rec_n(2, shape_text__span, (V[]){heff_strSlice_lent(v_line_241, v_i_242, v_t_2411, 6), v_t_2416});
      V t_0 = v_base_240;
      V t_1 = v_line_241;
      V t_2 = v_t_248;
      V t_3 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2417, v_acc_243});
      v_base_240 = t_0;
      v_line_241 = t_1;
      v_i_242 = t_2;
      v_acc_243 = t_3;
      goto top;
    }
  }
}
V g_heff_2ebuild_2equery_2ewordsOf_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2equery_2ewordsOf(a[0], a1, a[2], a[3]); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ebuild_2equery_2efixityWords_str0, 6, "infixl");
HEFF_LIT(g_heff_2ebuild_2equery_2efixityWords_str1, 6, "infixr");
HEFF_LIT(g_heff_2ebuild_2equery_2efixityWords_str2, 5, "infix");
Clo g_heff_2ebuild_2equery_2efixityWords_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2efixityWords_entry, 2, 0};

V g_heff_2ebuild_2equery_2efixityWords(V v_name_240, V v_ws_241) {
top: ;
  switch (heff_tag_of(v_ws_241)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_w_242 = heff_dup(heff_field(v_ws_241, 0));
    if (heff_strEq_c(heff_dup(heff_rfield(v_w_242, 0)), ((V)&g_heff_2ebuild_2equery_2efixityWords_str0))) {
      heff_drop_rec(v_w_242, 2);
      HEFF_LAST return g_list_2emap_24f990982947x2126256822(v_name_240, v_ws_241);
    } else {
      if (heff_strEq_c(heff_dup(heff_rfield(v_w_242, 0)), ((V)&g_heff_2ebuild_2equery_2efixityWords_str1))) {
        heff_drop_rec(v_w_242, 2);
        HEFF_LAST return g_list_2emap_24f990982947x2126256822(v_name_240, v_ws_241);
      } else {
        if (heff_strEq_c(heff_get_n(v_w_242, 0, 2), ((V)&g_heff_2ebuild_2equery_2efixityWords_str2))) {
          HEFF_LAST return g_list_2emap_24f990982947x2126256822(v_name_240, v_ws_241);
        } else {
          heff_drop_tag(v_ws_241, 2);
          return NTAG(TAG_Nil);
        }
      }
    }
  }
  default: return heff_nomatch(v_ws_241);
  }
}
V g_heff_2ebuild_2equery_2efixityWords_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2equery_2efixityWords(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2ebuild_2equery_2ewordsIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2ewordsIn_entry, 6, 0};

V g_heff_2ebuild_2equery_2ewordsIn(V v_fits_240, V v_name_241, V v_src_242, V v_i_243, V v_to_244, V v_acc_245) {
top: ;
  V v_j_246 = heff_strFind_lent(v_name_241, v_src_242, v_i_243, 4);
  if (heff_intLt_c_lent(v_j_246, MK_INT(0LL), 2)) {
    heff_drop(v_fits_240);
    heff_drop(v_to_244);
    heff_drop(v_j_246);
    return (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_245));
  } else {
    V v_t_248 = heff_intAdd(heff_dup(v_j_246), heff_strLength_lent(v_name_241, 0));
    if (heff_intLe_c_lent(v_t_248, v_to_244, 1)) {
      V v_t_2410 = (g_heff_2ebuild_2equery_2ewordAt(v_src_242, heff_dup(v_j_246), v_name_241));
      V v_t_2413;
      if ((heff_dup(v_t_2410) == NTAG(TAG_True))) {
        heff_drop(v_t_2410);
        V v_t_2411 = heff_tr(heff_call(heff_dup(v_fits_240), 1, (V[]){heff_dup(v_j_246)}));
        if ((heff_dup(v_t_2411) == NTAG(TAG_True))) {
          heff_drop(v_t_2411);
          V v_t_2412 = heff_intAdd(heff_dup(v_j_246), heff_strLength_lent(v_name_241, 0));
          v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){heff_rec_n(2, shape_start__end, (V[]){heff_dup(v_j_246), v_t_2412}), v_acc_245});
        } else {
          heff_drop(v_t_2411);
          v_t_2413 = v_acc_245;
        }
      } else {
        heff_drop(v_t_2410);
        v_t_2413 = v_acc_245;
      }
      V t_0 = v_fits_240;
      V t_1 = v_name_241;
      V t_2 = v_src_242;
      V t_3 = heff_intAdd(v_j_246, MK_INT(1LL));
      V t_4 = v_to_244;
      V t_5 = v_t_2413;
      v_fits_240 = t_0;
      v_name_241 = t_1;
      v_src_242 = t_2;
      v_i_243 = t_3;
      v_to_244 = t_4;
      v_acc_245 = t_5;
      goto top;
    } else {
      heff_drop(v_fits_240);
      heff_drop(v_to_244);
      heff_drop(v_j_246);
      return (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_245));
    }
  }
}
V g_heff_2ebuild_2equery_2ewordsIn_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a2 = a[2]; V r = g_heff_2ebuild_2equery_2ewordsIn(a[0], a1, a2, a[3], a[4], a[5]); heff_drop(a1); heff_drop(a2); return r;
}
Clo g_heff_2ebuild_2equery_2elineStartOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2elineStartOf_entry, 2, 0};

V g_heff_2ebuild_2equery_2elineStartOf(V v_src_240, V v_p_241) {
top: ;
  if (heff_intLt_c_lent(MK_INT(0LL), v_p_241, 1)) {
    V v_t_243 = heff_strByteAt(heff_dup(v_src_240), heff_intSub(heff_dup(v_p_241), MK_INT(1LL)));
    if ((heff_unbox_word(v_t_243) == ((int64_t)10ULL))) {
      return v_p_241;
    } else {
      V t_0 = v_src_240;
      V t_1 = heff_intSub(v_p_241, MK_INT(1LL));
      v_src_240 = t_0;
      v_p_241 = t_1;
      goto top;
    }
  } else {
    return v_p_241;
  }
}
V g_heff_2ebuild_2equery_2elineStartOf_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2equery_2elineStartOf(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2ebuild_2equery_2einStringGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2einStringGo_entry, 4, 0};

V g_heff_2ebuild_2equery_2einStringGo(V v_src_240, V v_i_241, V v_p_242, V v_inside_243) {
top: ;
  if (heff_intLe_c_lent(v_p_242, v_i_241, 0)) {
    heff_drop(v_i_241);
    heff_drop(v_p_242);
    return v_inside_243;
  } else {
    if ((heff_dup(v_inside_243) == NTAG(TAG_True))) {
      if ((heff_unbox_word(heff_strByteAt_lent(v_src_240, v_i_241, 0)) == ((int64_t)92ULL))) {
        V t_0 = v_src_240;
        V t_1 = heff_intAdd(v_i_241, MK_INT(2LL));
        V t_2 = v_p_242;
        V t_3 = v_inside_243;
        v_src_240 = t_0;
        v_i_241 = t_1;
        v_p_242 = t_2;
        v_inside_243 = t_3;
        goto top;
      } else {
        if ((heff_unbox_word(heff_strByteAt_lent(v_src_240, v_i_241, 0)) == ((int64_t)34ULL))) {
          V v_t_247 = heff_bool(!(heff_dup(v_inside_243) == NTAG(TAG_True)));
          heff_drop(v_inside_243);
          V t_0 = v_src_240;
          V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
          V t_2 = v_p_242;
          V t_3 = v_t_247;
          v_src_240 = t_0;
          v_i_241 = t_1;
          v_p_242 = t_2;
          v_inside_243 = t_3;
          goto top;
        } else {
          V t_0 = v_src_240;
          V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
          V t_2 = v_p_242;
          V t_3 = v_inside_243;
          v_src_240 = t_0;
          v_i_241 = t_1;
          v_p_242 = t_2;
          v_inside_243 = t_3;
          goto top;
        }
      }
    } else {
      if ((heff_unbox_word(heff_strByteAt_lent(v_src_240, v_i_241, 0)) == ((int64_t)34ULL))) {
        V v_t_249 = heff_bool(!(heff_dup(v_inside_243) == NTAG(TAG_True)));
        heff_drop(v_inside_243);
        V t_0 = v_src_240;
        V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
        V t_2 = v_p_242;
        V t_3 = v_t_249;
        v_src_240 = t_0;
        v_i_241 = t_1;
        v_p_242 = t_2;
        v_inside_243 = t_3;
        goto top;
      } else {
        V t_0 = v_src_240;
        V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
        V t_2 = v_p_242;
        V t_3 = v_inside_243;
        v_src_240 = t_0;
        v_i_241 = t_1;
        v_p_242 = t_2;
        v_inside_243 = t_3;
        goto top;
      }
    }
  }
}
V g_heff_2ebuild_2equery_2einStringGo_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2equery_2einStringGo(a0, a[1], a[2], a[3]); heff_drop(a0); return r;
}
Clo g_heff_2ebuild_2equery_2espacesFrom_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2espacesFrom_entry, 2, 0};

V g_heff_2ebuild_2equery_2espacesFrom(V v_src_240, V v_i_241) {
top: ;
  if ((heff_unbox_word(heff_strByteAt_lent(v_src_240, v_i_241, 0)) == ((int64_t)32ULL))) {
    V t_0 = v_src_240;
    V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
    v_src_240 = t_0;
    v_i_241 = t_1;
    goto top;
  } else {
    return v_i_241;
  }
}
V g_heff_2ebuild_2equery_2espacesFrom_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2equery_2espacesFrom(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2ebuild_2equery_2espacesBefore_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2espacesBefore_entry, 2, 0};

V g_heff_2ebuild_2equery_2espacesBefore(V v_src_240, V v_i_241) {
top: ;
  if (heff_intLt_c_lent(MK_INT(0LL), v_i_241, 1)) {
    V v_t_243 = heff_strByteAt(heff_dup(v_src_240), heff_intSub(heff_dup(v_i_241), MK_INT(1LL)));
    if ((heff_unbox_word(v_t_243) == ((int64_t)32ULL))) {
      V t_0 = v_src_240;
      V t_1 = heff_intSub(v_i_241, MK_INT(1LL));
      v_src_240 = t_0;
      v_i_241 = t_1;
      goto top;
    } else {
      return v_i_241;
    }
  } else {
    return v_i_241;
  }
}
V g_heff_2ebuild_2equery_2espacesBefore_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2equery_2espacesBefore(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2ebuild_2equery_2eisLabelAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2eisLabelAt_entry, 3, 0};

V g_heff_2ebuild_2equery_2eisLabelAt(V v_src_240, V v_p_241, V v_n_242) {
top: ;
  V v_t_243 = (g_heff_2ebuild_2equery_2espacesFrom(v_src_240, heff_intAdd(heff_dup(v_p_241), heff_dup(v_n_242))));
  V v_ret_24bool = heff_bool(((heff_unbox_word(heff_strByteAt_lent(v_src_240, v_t_243, 0)) == ((int64_t)61ULL)) && ({ V v_t_245 = (g_heff_2ebuild_2equery_2espacesFrom(v_src_240, heff_intAdd(heff_dup(v_p_241), heff_dup(v_n_242)))); int c_ = ({ V v_x_246 = heff_strByteAt(heff_dup(v_src_240), heff_intAdd(heff_dup(v_t_245), MK_INT(1LL))); int c_ = ((heff_peek_word(v_x_246) == ((int64_t)61ULL)) ? 0 : ({ V v_x_248 = (g_heff_2ebuild_2equery_2espacesBefore(v_src_240, heff_dup(v_p_241))); int c_ = (heff_intLt_c_lent(MK_INT(0LL), v_x_248, 1) && ({ V v_t_2410 = (g_heff_2ebuild_2equery_2espacesBefore(v_src_240, heff_dup(v_p_241))); int c_ = ({ V v_t_2411 = heff_strByteAt(heff_dup(v_src_240), heff_intSub(heff_dup(v_t_2410), MK_INT(1LL))); int c_ = ((heff_peek_word(v_t_2411) == ((int64_t)123ULL)) || ({ V v_t_2413 = (g_heff_2ebuild_2equery_2espacesBefore(v_src_240, heff_dup(v_p_241))); int c_ = ({ V v_t_2414 = heff_strByteAt(heff_dup(v_src_240), heff_intSub(heff_dup(v_t_2413), MK_INT(1LL))); int c_ = (heff_peek_word(v_t_2414) == ((int64_t)44ULL)); heff_drop(v_t_2414); c_; }); heff_drop(v_t_2413); c_; })); heff_drop(v_t_2411); c_; }); heff_drop(v_t_2410); c_; })); heff_drop(v_x_248); c_; })); heff_drop(v_x_246); c_; }); heff_drop(v_t_245); c_; })));
  heff_drop(v_p_241);
  heff_drop(v_n_242);
  heff_drop(v_t_243);
  return v_ret_24bool;
}
V g_heff_2ebuild_2equery_2eisLabelAt_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2equery_2eisLabelAt(a0, a[1], a[2]); heff_drop(a0); return r;
}
Clo g_heff_2ebuild_2equery_2eexpectedFits_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2eexpectedFits_entry, 4, 0};

V g_heff_2ebuild_2equery_2eexpectedFits(V v_t_240, V v_src_241, V v_n_242, V v_p_243) {
top: ;
  V v_t_244 = (g_heff_2ebuild_2equery_2elineStartOf(v_src_241, heff_dup(v_p_243)));
  V v_x1_245 = (g_heff_2ebuild_2equery_2einStringGo(v_src_241, v_t_244, heff_dup(v_p_243), NTAG(TAG_False)));
  if ((heff_dup(v_x1_245) == NTAG(TAG_True))) {
    heff_drop_rec(v_t_240, 3);
    heff_drop(v_n_242);
    heff_drop(v_p_243);
    heff_drop(v_x1_245);
    return NTAG(TAG_False);
  } else {
    heff_drop(v_x1_245);
    V v_t_246 = heff_get_n(v_t_240, 1, 3);
    switch (heff_tag_of(v_t_246)) {
    case TAG_Nothing: {
      V v_x1_247 = (g_heff_2ebuild_2equery_2eisLabelAt(v_src_241, v_p_243, v_n_242));
      V v_ret_24bool = heff_bool(!(heff_dup(v_x1_247) == NTAG(TAG_True)));
      heff_drop(v_x1_247);
      return v_ret_24bool;
    }
    case TAG_Just: {
      V v_m_248 = heff_field(v_t_246, 0);
      heff_take_n(v_t_246, 1ULL, 1);
      V v_ret_24bool = heff_bool(((((int64_t)65ULL) <= heff_unbox_word(heff_strByteAt_lent(v_m_248, MK_INT(0LL), 2))) ? ((heff_unbox_word(heff_strByteAt_lent(v_m_248, MK_INT(0LL), 2)) <= ((int64_t)90ULL)) ? ({ V v_x1_2411 = (g_heff_2ebuild_2equery_2eisLabelAt(v_src_241, heff_dup(v_p_243), heff_dup(v_n_242))); int c_ = !(heff_dup(v_x1_2411) == NTAG(TAG_True)); heff_drop(v_x1_2411); c_; }) : ({ V v_t_2412 = (g_heff_2ebuild_2equery_2eisLabelAt(v_src_241, heff_dup(v_p_243), heff_dup(v_n_242))); int c_ = ((heff_dup(v_t_2412) == NTAG(TAG_True)) || (heff_intLt_c_lent(MK_INT(0LL), v_p_243, 1) && ({ V v_t_2414 = heff_strByteAt(heff_dup(v_src_241), heff_intSub(heff_dup(v_p_243), MK_INT(1LL))); int c_ = (heff_peek_word(v_t_2414) == ((int64_t)46ULL)); heff_drop(v_t_2414); c_; }))); heff_drop(v_t_2412); c_; })) : ({ V v_t_2415 = (g_heff_2ebuild_2equery_2eisLabelAt(v_src_241, heff_dup(v_p_243), heff_dup(v_n_242))); int c_ = ((heff_dup(v_t_2415) == NTAG(TAG_True)) || (heff_intLt_c_lent(MK_INT(0LL), v_p_243, 1) && ({ V v_t_2417 = heff_strByteAt(heff_dup(v_src_241), heff_intSub(heff_dup(v_p_243), MK_INT(1LL))); int c_ = (heff_peek_word(v_t_2417) == ((int64_t)46ULL)); heff_drop(v_t_2417); c_; }))); heff_drop(v_t_2415); c_; })));
      heff_drop(v_n_242);
      heff_drop(v_p_243);
      heff_drop(v_m_248);
      return v_ret_24bool;
    }
    default: return heff_nomatch(v_t_246);
    }
  }
}
V g_heff_2ebuild_2equery_2eexpectedFits_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2equery_2eexpectedFits(a[0], a1, a[2], a[3]); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ebuild_2equery_2eexpectedIn_str0, 8, "-- | >>>");
HEFF_LIT(g_heff_2ebuild_2equery_2eexpectedIn_str1, 8, "-- | >>>");
V g_heff_2ebuild_2equery_2eexpectedIn_lam1(V self, V *args);
V g_heff_2ebuild_2equery_2eexpectedIn_lam0(V self, V *args);
Clo g_heff_2ebuild_2equery_2eexpectedIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2eexpectedIn_entry, 3, 0};

V g_heff_2ebuild_2equery_2eexpectedIn(V v_t_240, V v_name_241, V v_c_242) {
top: ;
  V v_t_243 = heff_get_n(heff_dup(heff_rfield(v_c_242, 5)), 4, 9);
  V v_t_244 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_t_243));
  return ({ V a_0 = heff_clo_n(g_heff_2ebuild_2equery_2eexpectedIn_lam0, 2, 3, (V[]){v_c_242, v_t_240, heff_dup(v_name_241)}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_244; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_244); r_; });
}
V g_heff_2ebuild_2equery_2eexpectedIn_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2equery_2eexpectedIn(a[0], a1, a[2]); heff_drop(a1); return r;
}
V g_heff_2ebuild_2equery_2eexpectedIn_lam1(V self, V *args) {
  V v_p_2417 = args[0];
  V v_t_240 = heff_env(self)[0];
  V v_c_242 = heff_env(self)[1];
  V v_name_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return ({ V a_0 = v_t_240; V b_1 = heff_get_n(v_c_242, 3, 14); V a_2 = heff_strLength(v_name_241); V a_3 = v_p_2417; V r_ = (g_heff_2ebuild_2equery_2eexpectedFits(a_0, b_1, a_2, a_3)); heff_drop(b_1); r_; });
}
V g_heff_2ebuild_2equery_2eexpectedIn_lam0(V self, V *args) {
  V v_acc_245 = args[0];
  V v_x_246 = args[1];
  V v_c_242 = heff_env(self)[0];
  V v_t_240 = heff_env(self)[1];
  V v_name_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_src_247 = heff_dup(heff_rfield(v_c_242, 3));
  V v_sp_248 = heff_dup(heff_rfield(v_x_246, 0));
  V v_start_249 = heff_take_field(v_sp_248, 0);
  V v_t_2410 = heff_strSlice(heff_dup(v_src_247), heff_dup(v_start_249), heff_intAdd(v_start_249, MK_INT(8LL)));
  V v_t_2411 = ({ V b_0 = heff_strEq(v_t_2410, ((V)&g_heff_2ebuild_2equery_2eexpectedIn_str0)); V a_1 = v_src_247; V b_2 = heff_get_n(v_sp_248, 1, 2); V r_ = (g_heff_2ebuild_2edriver_2eexpectAfter(b_0, a_1, b_2)); heff_drop(b_0); heff_drop(v_src_247); heff_drop(b_2); r_; });
  V v_src_2412 = heff_dup(heff_rfield(v_c_242, 3));
  V v_sp_2413 = heff_get_n(v_x_246, 0, 2);
  V v_start_2414 = heff_take_field(v_sp_2413, 0);
  V v_t_2415 = heff_strSlice(heff_dup(v_src_2412), heff_dup(v_start_2414), heff_intAdd(v_start_2414, MK_INT(8LL)));
  V v_t_2416 = ({ V b_0 = heff_strEq(v_t_2415, ((V)&g_heff_2ebuild_2equery_2eexpectedIn_str1)); V a_1 = v_src_2412; V b_2 = heff_get_n(v_sp_2413, 1, 2); V r_ = (g_heff_2ebuild_2edriver_2eexpectAfter(b_0, a_1, b_2)); heff_drop(b_0); heff_drop(v_src_2412); heff_drop(b_2); r_; });
  V v_t_2418 = ({ V a_0 = heff_clo_n(g_heff_2ebuild_2equery_2eexpectedIn_lam1, 1, 3, (V[]){v_t_240, heff_dup(v_c_242), heff_dup(v_name_241)}); V a_1 = v_name_241; V b_2 = heff_get_n(v_c_242, 3, 14); V a_3 = heff_get_n(v_t_2411, 1, 3); V a_4 = heff_get_n(v_t_2416, 2, 3); V a_5 = NTAG(TAG_Nil); V r_ = (g_heff_2ebuild_2equery_2ewordsIn(a_0, a_1, b_2, a_3, a_4, a_5)); heff_drop(v_name_241); heff_drop(b_2); r_; });
  return (g_prelude_2e_2b_2b(v_t_2418, v_acc_245));
}
HEFF_LIT(g_heff_2ebuild_2equery_2emoreIn_str0, 1, "\012");
V g_heff_2ebuild_2equery_2emoreIn_lam0(V self, V *args);
Clo g_heff_2ebuild_2equery_2emoreIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2emoreIn_entry, 3, 0};

V g_heff_2ebuild_2equery_2emoreIn(V v_t_240, V v_name_241, V v_c_242) {
top: ;
  V v_x1_243 = (g_heff_2ebuild_2equery_2eisNameChar(heff_strByteAt_lent(v_name_241, MK_INT(0LL), 2)));
  V v_t_2417;
  if ((heff_dup(v_x1_243) == NTAG(TAG_True))) {
    heff_drop(v_x1_243);
    v_t_2417 = NTAG(TAG_Nil);
  } else {
    heff_drop(v_x1_243);
    V v_t_244 = heff_dup(heff_rfield(v_t_240, 1));
    switch (heff_tag_of(v_t_244)) {
    case TAG_Nothing: {
      V v_src_245 = heff_dup(heff_rfield(v_c_242, 3));
      int64_t v_t_246 = (heff_unbox_word(heff_strLength_lent(v_src_245, 0)) - ((int64_t)1ULL));
      V v_t_247 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = MK_INT(0LL); V a_2 = v_src_245; V a_3 = MK_INT(1LL); V a_4 = MK_INT(10LL); V a_5 = MK_INT(0LL); V a_6 = heff_box_word(v_t_246); V r_ = (g_list_2efoldl_24f765463553x1160475073(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_src_245); r_; });
      v_t_2417 = ({ V a_0 = heff_clo_n(g_heff_2ebuild_2equery_2emoreIn_lam0, 2, 2, (V[]){heff_dup(v_c_242), heff_dup(v_name_241)}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_247; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_247); r_; });
      break;
    }
    case TAG_Just: {
      heff_take_n(v_t_244, 0ULL, 1);
      v_t_2417 = NTAG(TAG_Nil);
      break;
    }
    default: heff_nomatch(v_t_244);
    }
  }
  V v_x1_2418 = (g_heff_2ebuild_2equery_2eisNameChar(heff_strByteAt_lent(v_name_241, MK_INT(0LL), 2)));
  V v_t_2419;
  if ((heff_dup(v_x1_2418) == NTAG(TAG_True))) {
    heff_drop(v_x1_2418);
    v_t_2419 = (g_heff_2ebuild_2equery_2eexpectedIn(v_t_240, v_name_241, v_c_242));
  } else {
    heff_drop_rec(v_t_240, 3);
    heff_drop_rec(v_c_242, 14);
    heff_drop(v_x1_2418);
    v_t_2419 = NTAG(TAG_Nil);
  }
  return (g_prelude_2e_2b_2b(v_t_2417, v_t_2419));
}
V g_heff_2ebuild_2equery_2emoreIn_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2equery_2emoreIn(a[0], a1, a[2]); heff_drop(a1); return r;
}
V g_heff_2ebuild_2equery_2emoreIn_lam0(V self, V *args) {
  V v_acc_248 = args[0];
  V v_x_249 = args[1];
  V v_c_242 = heff_env(self)[0];
  V v_name_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_src_2410 = heff_get_n(v_c_242, 3, 14);
  V v_j_2411 = heff_strFind_lent(((V)&g_heff_2ebuild_2equery_2emoreIn_str0), v_src_2410, v_x_249, 1);
  V v_t_2413;
  if (heff_intLt_c_lent(v_j_2411, MK_INT(0LL), 2)) {
    heff_drop(v_j_2411);
    v_t_2413 = heff_strLength_lent(v_src_2410, 0);
  } else {
    v_t_2413 = v_j_2411;
  }
  V v_t_2414 = ({ V a_0 = heff_dup(v_x_249); V b_1 = heff_strSlice(v_src_2410, v_x_249, v_t_2413); V a_2 = MK_INT(0LL); V a_3 = NTAG(TAG_Nil); V r_ = (g_heff_2ebuild_2equery_2ewordsOf(a_0, b_1, a_2, a_3)); heff_drop(b_1); r_; });
  V v_t_2415 = ({ V a_0 = v_name_241; V a_1 = v_t_2414; V r_ = (g_heff_2ebuild_2equery_2efixityWords(a_0, a_1)); heff_drop(v_name_241); r_; });
  return (g_prelude_2e_2b_2b(v_t_2415, v_acc_248));
}
V g_heff_2ebuild_2equery_2einFileFound_lam0(V self, V *args);
Clo g_heff_2ebuild_2equery_2einFileFound_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2einFileFound_entry, 5, 0};

V g_heff_2ebuild_2equery_2einFileFound(V v_t_240, V v_name_241, V v_c_242, V v_ss_243, V v_found_244) {
top: ;
  V v_defs_245 = (g_list_2emap_24s388004800x1261967008(v_ss_243));
  V v_t_248;
  switch (heff_tag_of(v_found_244)) {
  case TAG_Nil: {
    heff_drop(v_t_240);
    v_t_248 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Cons: {
    v_t_248 = (g_heff_2ebuild_2equery_2emoreIn(v_t_240, v_name_241, heff_dup(v_c_242)));
    break;
  }
  default: heff_nomatch(v_found_244);
  }
  V v_spans_249 = (g_prelude_2e_2b_2b(v_found_244, v_t_248));
  V v_t_2410 = (g_list_2esortBy_24s1768199906x1695529242(v_spans_249));
  V v_t_2411 = (g_heff_2ebuild_2equery_2enubByStart(v_t_2410));
  return (g_list_2emap(heff_clo_n(g_heff_2ebuild_2equery_2einFileFound_lam0, 1, 2, (V[]){v_defs_245, v_c_242}), v_t_2411));
}
V g_heff_2ebuild_2equery_2einFileFound_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2equery_2einFileFound(a[0], a1, a[2], a[3], a[4]); heff_drop(a1); return r;
}
V g_heff_2ebuild_2equery_2einFileFound_lam0(V self, V *args) {
  V v_sp_2412 = args[0];
  V v_defs_245 = heff_env(self)[0];
  V v_c_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_defines_2413 = ({ V a_0 = heff_dup(v_sp_2412); V a_1 = v_defs_245; V r_ = (g_list_2eany_24s1711939327x1502975912(a_0, a_1)); heff_drop(v_defs_245); r_; });
  return heff_rec_n(4, shape_path__source__span__defines, (V[]){heff_dup(heff_rfield(v_c_242, 1)), heff_get_n(v_c_242, 3, 14), v_sp_2412, v_defines_2413});
}
V g_heff_2ebuild_2equery_2einFileSites_lam0(V self, V *args);
V g_heff_2ebuild_2equery_2einFileSites_lam1(V self, V *args);
Clo g_heff_2ebuild_2equery_2einFileSites_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2einFileSites_entry, 4, 0};

V g_heff_2ebuild_2equery_2einFileSites(V v_t_240, V v_name_241, V v_c_242, V v_ss_243) {
top: ;
  V v_t_244 = heff_get_n(heff_dup(heff_rfield(v_c_242, 5)), 7, 9);
  V v_t_246 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2equery_2einFileSites_lam0, 1, 2, (V[]){heff_dup(v_t_240), heff_dup(v_name_241)}), v_t_244));
  V v_t_247 = (g_heff_2ebuild_2equery_2ecatMaybesQ(v_t_246));
  V v_t_248 = (g_list_2emap_24s388004800x1261967008(heff_dup(v_ss_243)));
  V v_t_249 = (g_list_2efoldl_24s44351024x1408738471(heff_dup(g_heff_2eelab_2elocals_2enone_get()), heff_rfield(v_c_242, 4)));
  HeffT2 v_t_2410 = (g_heff_2eelab_2elocals_2elocalsOf_24cpr(v_t_249));
  V v_t_2414;
  {
    V v_field_2412 = v_t_2410.f[1];
    heff_drop(v_t_2410.f[0]);
    v_t_2414 = (g_list_2emap_24f2063070488x1806431062(heff_clo_n(g_heff_2ebuild_2equery_2einFileSites_lam1, 1, 1, (V[]){heff_dup(v_ss_243)}), v_field_2412));
  }
  V v_t_2415 = (g_prelude_2e_2b_2b(v_t_248, v_t_2414));
  V v_t_2416 = (g_prelude_2e_2b_2b(v_t_247, v_t_2415));
  return (g_heff_2ebuild_2equery_2einFileFound(v_t_240, v_name_241, v_c_242, v_ss_243, v_t_2416));
}
V g_heff_2ebuild_2equery_2einFileSites_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2equery_2einFileSites(a[0], a1, a[2], a[3]); heff_drop(a1); return r;
}
V g_heff_2ebuild_2equery_2einFileSites_lam0(V self, V *args) {
  V v_i_245 = args[0];
  V v_t_240 = heff_env(self)[0];
  V v_name_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return ({ V a_0 = v_t_240; V a_1 = v_name_241; V a_2 = v_i_245; V r_ = (g_heff_2ebuild_2equery_2euseOf(a_0, a_1, a_2)); heff_drop(v_name_241); r_; });
}
V g_heff_2ebuild_2equery_2einFileSites_lam1(V self, V *args) {
  V v_f_2413 = args[0];
  V v_ss_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_f_2413; V a_1 = v_ss_243; V r_ = (g_list_2eany_24s406396256x713021373(a_0, a_1)); heff_drop(v_ss_243); r_; });
}
V g_heff_2ebuild_2equery_2eoccurrences_lam1(V self, V *args);
V g_heff_2ebuild_2equery_2eoccurrences_lam2(V self, V *args);
V g_heff_2ebuild_2equery_2eoccurrences_lam0(V self, V *args);
Clo g_heff_2ebuild_2equery_2eoccurrences_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2eoccurrences_entry, 3, 0};

V g_heff_2ebuild_2equery_2eoccurrences(V v_program_240, V v_t_241, V v_name_242) {
top: ;
  V v_t_243 = heff_dup(heff_rfield(v_t_241, 2));
  switch (heff_tag_of(v_t_243)) {
  case TAG_Nothing: {
    V v_t_244 = (g_list_2efoldl_24f297647854x479783049(NTAG(TAG_Nil), v_program_240));
    return ({ V a_0 = heff_clo_n(g_heff_2ebuild_2equery_2eoccurrences_lam0, 2, 2, (V[]){v_t_241, heff_dup(v_name_242)}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_244; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_244); r_; });
  }
  case TAG_Just: {
    V v_b_2415 = heff_field(v_t_243, 0);
    heff_take_n(v_t_243, 1ULL, 1);
    HeffT2 v_t_2416 = (g_list_2efind_24s728994925x1501467390_24cpr(v_t_241, v_program_240));
    {
      V v_field_2418 = v_t_2416.f[1];
      int64_t v_tag_2417 = ((int64_t)v_t_2416.f[0]);
      if ((v_tag_2417 == ((int64_t)0ULL))) {
        V v_c_2420 = v_field_2418;
        V v_t_2421 = (g_list_2efoldl_24s44351024x1408738471(heff_dup(g_heff_2eelab_2elocals_2enone_get()), heff_rfield(v_c_2420, 4)));
        V v_t_2422 = (g_heff_2eelab_2elocals_2elocalsOf(v_t_2421));
        HeffT2 v_t_2423 = (g_list_2efind_24s924148649x7864569_24cpr(heff_dup(v_b_2415), heff_get_n(v_t_2422, 0, 2)));
        {
          V v_field_2425 = v_t_2423.f[1];
          int64_t v_tag_2424 = ((int64_t)v_t_2423.f[0]);
          if ((v_tag_2424 == ((int64_t)0ULL))) {
            V v_l_2427 = v_field_2425;
            V v_t_2428 = heff_tag_n(TAG_Cons, 2, (V[]){heff_take_field(v_l_2427, 1), heff_get_n(v_l_2427, 2, 3)});
            V v_t_2429 = (g_list_2esortBy_24s1768199906x1695529242(v_t_2428));
            HEFF_LAST return g_list_2emap_24s149108714x637478466(v_c_2420, v_b_2415, v_t_2429);
          } else {
            heff_drop(v_b_2415);
            heff_drop_rec(v_c_2420, 14);
            heff_drop(v_field_2425);
            return NTAG(TAG_Nil);
          }
        }
      } else {
        heff_drop(v_b_2415);
        heff_drop(v_field_2418);
        return NTAG(TAG_Nil);
      }
    }
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_heff_2ebuild_2equery_2eoccurrences_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ebuild_2equery_2eoccurrences(a[0], a[1], a2); heff_drop(a2); return r;
}
V g_heff_2ebuild_2equery_2eoccurrences_lam1(V self, V *args) {
  V v_acc_248 = args[0];
  V v_x_249 = args[1];
  V v_x_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2410 = (g_heff_2ebuild_2equery_2edeclSites(v_x_246, v_x_249));
  return (g_prelude_2e_2b_2b(v_t_2410, v_acc_248));
}
V g_heff_2ebuild_2equery_2eoccurrences_lam2(V self, V *args) {
  V v_s_2412 = args[0];
  V v_t_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2ebuild_2equery_2eeqTarget(heff_get_n(v_s_2412, 0, 3), v_t_241));
}
V g_heff_2ebuild_2equery_2eoccurrences_lam0(V self, V *args) {
  V v_acc_245 = args[0];
  V v_x_246 = args[1];
  V v_t_241 = heff_env(self)[0];
  V v_name_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_247 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(heff_rfield(v_x_246, 4))));
  V v_t_2411 = ({ V a_0 = heff_clo_n(g_heff_2ebuild_2equery_2eoccurrences_lam1, 2, 1, (V[]){heff_dup(v_x_246)}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_247; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_247); r_; });
  V v_t_2413 = (g_list_2efilter(heff_clo_n(g_heff_2ebuild_2equery_2eoccurrences_lam2, 1, 1, (V[]){heff_dup(v_t_241)}), v_t_2411));
  V v_t_2414 = ({ V a_0 = v_t_241; V a_1 = v_name_242; V a_2 = v_x_246; V a_3 = v_t_2413; V r_ = (g_heff_2ebuild_2equery_2einFileSites(a_0, a_1, a_2, a_3)); heff_drop(v_name_242); r_; });
  return (g_prelude_2e_2b_2b(v_t_2414, v_acc_245));
}
Clo g_heff_2ebuild_2equery_2epunctuation_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2epunctuation_entry, 1, 0};

V g_heff_2ebuild_2equery_2epunctuation(V v_box_24d_240) {
  int64_t v_d_240 = heff_unbox_word(v_box_24d_240);
top: ;
  V v_ret_24bool = heff_bool(((v_d_240 == ((int64_t)32ULL)) || ((v_d_240 == ((int64_t)10ULL)) || ((v_d_240 == ((int64_t)40ULL)) || ((v_d_240 == ((int64_t)41ULL)) || ((v_d_240 == ((int64_t)91ULL)) || ((v_d_240 == ((int64_t)93ULL)) || ((v_d_240 == ((int64_t)123ULL)) || ((v_d_240 == ((int64_t)125ULL)) || ((v_d_240 == ((int64_t)44ULL)) || ((v_d_240 == ((int64_t)34ULL)) || (v_d_240 == ((int64_t)96ULL)))))))))))));
  return v_ret_24bool;
}
V g_heff_2ebuild_2equery_2epunctuation_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2equery_2epunctuation(a[0]);
}
Clo g_heff_2ebuild_2equery_2eallChars_24s1328103304x613783392_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2eallChars_24s1328103304x613783392_entry, 2, 0};

V g_heff_2ebuild_2equery_2eallChars_24s1328103304x613783392(V v_s_240, V v_box_24i_241) {
  int64_t v_i_241 = heff_unbox_word(v_box_24i_241);
top: ;
  if ((heff_unbox_word(heff_strLength_lent(v_s_240, 0)) <= v_i_241)) {
    return NTAG(TAG_True);
  } else {
    V v_d_243 = heff_strByteAt_lent(v_s_240, heff_box_word(v_i_241), 2);
    if ((heff_peek_word(v_d_243) == ((int64_t)47ULL))) {
      heff_drop(v_d_243);
      return NTAG(TAG_False);
    } else {
      V v_t_245 = (g_heff_2ebuild_2equery_2eisNameChar(v_d_243));
      if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
        heff_drop(v_t_245);
        V t_0 = v_s_240;
        int64_t t_1 = (v_i_241 + ((int64_t)1ULL));
        v_s_240 = t_0;
        v_i_241 = t_1;
        goto top;
      } else {
        heff_drop(v_t_245);
        return NTAG(TAG_False);
      }
    }
  }
}
V g_heff_2ebuild_2equery_2eallChars_24s1328103304x613783392_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2equery_2eallChars_24s1328103304x613783392(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2ebuild_2equery_2eallChars_24s542516060x1937552692_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2eallChars_24s542516060x1937552692_entry, 3, 0};

V g_heff_2ebuild_2equery_2eallChars_24s542516060x1937552692(V v_box_24lit_240, V v_s_241, V v_box_24i_242) {
  int64_t v_lit_240 = heff_unbox_word(v_box_24lit_240);
  int64_t v_i_242 = heff_unbox_word(v_box_24i_242);
top: ;
  if ((heff_unbox_word(heff_strLength_lent(v_s_241, 0)) <= v_i_242)) {
    return NTAG(TAG_True);
  } else {
    V v_a_244 = heff_strByteAt_lent(v_s_241, heff_box_word(v_i_242), 2);
    if ((heff_peek_word(v_a_244) == v_lit_240)) {
      V v_a_246 = (g_heff_2ebuild_2equery_2epunctuation(v_a_244));
      if ((heff_dup(v_a_246) == NTAG(TAG_True))) {
        heff_drop(v_a_246);
        return NTAG(TAG_False);
      } else {
        heff_drop(v_a_246);
        int64_t t_0 = v_lit_240;
        V t_1 = v_s_241;
        int64_t t_2 = (v_i_242 + ((int64_t)1ULL));
        v_lit_240 = t_0;
        v_s_241 = t_1;
        v_i_242 = t_2;
        goto top;
      }
    } else {
      V v_a_247 = (g_heff_2ebuild_2equery_2eisNameChar(heff_dup(v_a_244)));
      if ((heff_dup(v_a_247) == NTAG(TAG_True))) {
        heff_drop(v_a_244);
        heff_drop(v_a_247);
        return NTAG(TAG_False);
      } else {
        heff_drop(v_a_247);
        V v_a_248 = (g_heff_2ebuild_2equery_2epunctuation(v_a_244));
        if ((heff_dup(v_a_248) == NTAG(TAG_True))) {
          heff_drop(v_a_248);
          return NTAG(TAG_False);
        } else {
          heff_drop(v_a_248);
          int64_t t_0 = v_lit_240;
          V t_1 = v_s_241;
          int64_t t_2 = (v_i_242 + ((int64_t)1ULL));
          v_lit_240 = t_0;
          v_s_241 = t_1;
          v_i_242 = t_2;
          goto top;
        }
      }
    }
  }
}
V g_heff_2ebuild_2equery_2eallChars_24s542516060x1937552692_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2equery_2eallChars_24s542516060x1937552692(a[0], a1, a[2]); heff_drop(a1); return r;
}
Clo g_heff_2ebuild_2equery_2enameClass_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2enameClass_entry, 1, 0};

V g_heff_2ebuild_2equery_2enameClass(V v_x_240) {
top: ;
  if ((heff_unbox_word(heff_strLength_lent(v_x_240, 0)) == ((int64_t)0ULL))) {
    return MK_INT(0LL);
  } else {
    V v_t_243 = heff_bool(((((int64_t)65ULL) <= heff_unbox_word(heff_strByteAt_lent(v_x_240, MK_INT(0LL), 2))) && (heff_unbox_word(heff_strByteAt_lent(v_x_240, MK_INT(0LL), 2)) <= ((int64_t)90ULL))));
    if ((heff_dup(v_t_243) == NTAG(TAG_True))) {
      heff_drop(v_t_243);
      V v_t_244 = (g_heff_2ebuild_2equery_2eallChars_24s1328103304x613783392(v_x_240, MK_INT(0LL)));
      if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
        heff_drop(v_t_244);
        return MK_INT(1LL);
      } else {
        heff_drop(v_t_244);
        return MK_INT(0LL);
      }
    } else {
      heff_drop(v_t_243);
      if ((heff_unbox_word(heff_strByteAt_lent(v_x_240, MK_INT(0LL), 2)) == ((int64_t)95ULL))) {
        V v_t_246 = (g_heff_2ebuild_2equery_2eallChars_24s1328103304x613783392(v_x_240, MK_INT(0LL)));
        if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
          heff_drop(v_t_246);
          return MK_INT(2LL);
        } else {
          heff_drop(v_t_246);
          return MK_INT(0LL);
        }
      } else {
        if ((((int64_t)97ULL) <= heff_unbox_word(heff_strByteAt_lent(v_x_240, MK_INT(0LL), 2)))) {
          if ((heff_unbox_word(heff_strByteAt_lent(v_x_240, MK_INT(0LL), 2)) <= ((int64_t)122ULL))) {
            V v_t_249 = (g_heff_2ebuild_2equery_2eallChars_24s1328103304x613783392(v_x_240, MK_INT(0LL)));
            if ((heff_dup(v_t_249) == NTAG(TAG_True))) {
              heff_drop(v_t_249);
              return MK_INT(2LL);
            } else {
              heff_drop(v_t_249);
              return MK_INT(0LL);
            }
          } else {
            V v_t_2410 = (g_heff_2ebuild_2equery_2eallChars_24s542516060x1937552692(MK_INT(47LL), v_x_240, MK_INT(0LL)));
            if ((heff_dup(v_t_2410) == NTAG(TAG_True))) {
              heff_drop(v_t_2410);
              return MK_INT(3LL);
            } else {
              heff_drop(v_t_2410);
              return MK_INT(0LL);
            }
          }
        } else {
          V v_t_2411 = (g_heff_2ebuild_2equery_2eallChars_24s542516060x1937552692(MK_INT(47LL), v_x_240, MK_INT(0LL)));
          if ((heff_dup(v_t_2411) == NTAG(TAG_True))) {
            heff_drop(v_t_2411);
            return MK_INT(3LL);
          } else {
            heff_drop(v_t_2411);
            return MK_INT(0LL);
          }
        }
      }
    }
  }
}
V g_heff_2ebuild_2equery_2enameClass_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2equery_2enameClass(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ebuild_2equery_2erenameRefused_24cpr_str0, 1, ".");
HEFF_LIT(g_heff_2ebuild_2equery_2erenameRefused_24cpr_str1, 1, "`");
HEFF_LIT(g_heff_2ebuild_2equery_2erenameRefused_24cpr_str2, 43, "` is a primitive: its name is the runtime's");
HEFF_LIT(g_heff_2ebuild_2equery_2erenameRefused_24cpr_str3, 29, "` is not a name of the kind `");
HEFF_LIT(g_heff_2ebuild_2equery_2erenameRefused_24cpr_str4, 4, "` is");
HEFF_LIT(g_heff_2ebuild_2equery_2erenameRefused_24cpr_str5, 1, "`");

HeffT2 g_heff_2ebuild_2equery_2erenameRefused_24cpr(V v_t_240, V v_old_241, V v_new_242) {
top: ;
  V v_t_243 = heff_take_field(v_t_240, 1);
  V v_t_249;
  switch (heff_tag_of(v_t_243)) {
  case TAG_Nothing: {
    V v_t_244 = heff_take_field(v_t_240, 2);
    switch (heff_tag_of(v_t_244)) {
    case TAG_Nothing: {
      V v_t_245 = heff_strFind(((V)&g_heff_2ebuild_2equery_2erenameRefused_24cpr_str0), heff_get_n(v_t_240, 0, 3), MK_INT(0LL));
      v_t_249 = heff_bool(!heff_intLe_c_lent(MK_INT(0LL), v_t_245, 1));
      heff_drop(v_t_245);
      break;
    }
    case TAG_Just: {
      heff_take_n(v_t_244, 0ULL, 1);
      heff_drop_rec(v_t_240, 3);
      v_t_249 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_t_244);
    }
    break;
  }
  case TAG_Just: {
    heff_take_n(v_t_243, 0ULL, 1);
    heff_drop_rec(v_t_240, 3);
    v_t_249 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_t_243);
  }
  if ((heff_dup(v_t_249) == NTAG(TAG_True))) {
    heff_drop(v_new_242);
    heff_drop(v_t_249);
    V v_f_2410 = heff_strAppend(((V)&g_heff_2ebuild_2equery_2erenameRefused_24cpr_str1), heff_strAppend(v_old_241, ((V)&g_heff_2ebuild_2equery_2erenameRefused_24cpr_str2)));
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2410}});
  } else {
    heff_drop(v_t_249);
    V v_x_2411 = (g_heff_2ebuild_2equery_2enameClass(v_old_241));
    V v_y_2412 = (g_heff_2ebuild_2equery_2enameClass(v_new_242));
    if (heff_intEq_c(v_x_2411, v_y_2412)) {
      heff_drop(v_old_241);
      heff_drop(v_new_242);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    } else {
      V v_t_2414 = heff_strAppend(((V)&g_heff_2ebuild_2equery_2erenameRefused_24cpr_str3), heff_strAppend(v_old_241, ((V)&g_heff_2ebuild_2equery_2erenameRefused_24cpr_str4)));
      V v_f_2415 = heff_strAppend(((V)&g_heff_2ebuild_2equery_2erenameRefused_24cpr_str5), heff_strAppend(v_new_242, v_t_2414));
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2415}});
    }
  }
}
HEFF_LIT(g_heff_2ebuild_2equery_2ecommentAbove_str0, 2, "--");
Clo g_heff_2ebuild_2equery_2ecommentAbove_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2ecommentAbove_entry, 3, 0};

V g_heff_2ebuild_2equery_2ecommentAbove(V v_src_240, V v_start_241, V v_acc_242) {
top: ;
  if (heff_intLe_c_lent(v_start_241, MK_INT(0LL), 2)) {
    heff_drop(v_start_241);
    return v_acc_242;
  } else {
    V v_t_244 = (g_heff_2ebuild_2equery_2elineStartOf(v_src_240, heff_intSub(heff_dup(v_start_241), MK_INT(1LL))));
    V v_s_245 = heff_strSlice(heff_dup(v_src_240), v_t_244, heff_intSub(heff_dup(v_start_241), MK_INT(1LL)));
    V v_t_246 = (g_prelude_2eskipSpaces(v_s_245, MK_INT(0LL), MK_INT(1LL)));
    int64_t v_t_247 = (heff_unbox_word(heff_strLength_lent(v_s_245, 0)) - ((int64_t)1ULL));
    V v_t_248 = (g_prelude_2eskipSpaces(v_s_245, heff_box_word(v_t_247), MK_INT(-1LL)));
    V v_s_249 = heff_strSlice(v_s_245, v_t_246, heff_intAdd(v_t_248, MK_INT(1LL)));
    if (heff_strEq_c(heff_strSlice(v_s_249, MK_INT(0LL), MK_INT(2LL)), ((V)&g_heff_2ebuild_2equery_2ecommentAbove_str0))) {
      V v_t_2411 = (g_heff_2ebuild_2equery_2elineStartOf(v_src_240, heff_intSub(heff_dup(v_start_241), MK_INT(1LL))));
      V v_t_2412 = (g_heff_2ebuild_2equery_2elineStartOf(v_src_240, heff_intSub(heff_dup(v_start_241), MK_INT(1LL))));
      V v_s_2413 = heff_strSlice(heff_dup(v_src_240), v_t_2412, heff_intSub(v_start_241, MK_INT(1LL)));
      V v_t_2414 = (g_prelude_2eskipSpaces(v_s_2413, MK_INT(0LL), MK_INT(1LL)));
      int64_t v_t_2415 = (heff_unbox_word(heff_strLength_lent(v_s_2413, 0)) - ((int64_t)1ULL));
      V v_t_2416 = (g_prelude_2eskipSpaces(v_s_2413, heff_box_word(v_t_2415), MK_INT(-1LL)));
      V v_t_2417 = heff_strSlice(v_s_2413, v_t_2414, heff_intAdd(v_t_2416, MK_INT(1LL)));
      V t_0 = v_src_240;
      V t_1 = v_t_2411;
      V t_2 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2417, v_acc_242});
      v_src_240 = t_0;
      v_start_241 = t_1;
      v_acc_242 = t_2;
      goto top;
    } else {
      heff_drop(v_start_241);
      return v_acc_242;
    }
  }
}
V g_heff_2ebuild_2equery_2ecommentAbove_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2equery_2ecommentAbove(a0, a[1], a[2]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ebuild_2equery_2edocMdStep_str0, 3, ">>>");
HEFF_LIT(g_heff_2ebuild_2equery_2edocMdStep_str1, 3, "```");
HEFF_LIT(g_heff_2ebuild_2equery_2edocMdStep_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2equery_2edocMdStep_str3, 3, "```");
HEFF_LIT(g_heff_2ebuild_2equery_2edocMdStep_str4, 3, "```");
HEFF_LIT(g_heff_2ebuild_2equery_2edocMdStep_str5, 3, "```");
Clo g_heff_2ebuild_2equery_2edocMdStep_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2edocMdStep_entry, 3, 0};

V g_heff_2ebuild_2equery_2edocMdStep(V v_lang_240, V v_m_241, V v_l_242) {
top: ;
  if (heff_strEq_c(heff_strSlice_lent(v_l_242, MK_INT(0LL), MK_INT(3LL), 6), ((V)&g_heff_2ebuild_2equery_2edocMdStep_str0))) {
    V v_t_244 = heff_take_field(v_m_241, 1);
    V v_t_245;
    if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
      heff_drop(v_lang_240);
      heff_drop(v_t_244);
      v_t_245 = heff_get_n(v_m_241, 0, 3);
    } else {
      heff_drop(v_t_244);
      v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2equery_2edocMdStep_str1), v_lang_240), heff_get_n(v_m_241, 0, 3)});
    }
    return heff_rec_n(3, shape_out__code__expecting, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_l_242, v_t_245}), NTAG(TAG_True), NTAG(TAG_True)});
  } else {
    heff_drop(v_lang_240);
    V v_t_246 = heff_dup(heff_rfield(v_m_241, 1));
    if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
      heff_drop(v_t_246);
      V v_t_247 = heff_take_field(v_m_241, 2);
      if ((heff_dup(v_t_247) == NTAG(TAG_True))) {
        heff_drop(v_t_247);
        V v_t_248 = (g_prelude_2eskipSpaces(v_l_242, MK_INT(0LL), MK_INT(1LL)));
        int64_t v_t_249 = (heff_unbox_word(heff_strLength_lent(v_l_242, 0)) - ((int64_t)1ULL));
        V v_t_2410 = (g_prelude_2eskipSpaces(v_l_242, heff_box_word(v_t_249), MK_INT(-1LL)));
        V v_t_2411 = heff_strSlice(heff_dup(v_l_242), v_t_248, heff_intAdd(v_t_2410, MK_INT(1LL)));
        if (heff_strEq_c(v_t_2411, ((V)&g_heff_2ebuild_2equery_2edocMdStep_str2))) {
          V v_t_2413 = heff_take_field(v_m_241, 1);
          V v_t_2414;
          if ((heff_dup(v_t_2413) == NTAG(TAG_True))) {
            heff_drop(v_t_2413);
            v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2equery_2edocMdStep_str3), heff_get_n(v_m_241, 0, 3)});
          } else {
            heff_drop(v_t_2413);
            v_t_2414 = heff_get_n(v_m_241, 0, 3);
          }
          return heff_rec_n(3, shape_out__code__expecting, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_l_242, v_t_2414}), NTAG(TAG_False), NTAG(TAG_False)});
        } else {
          V v_t_2415 = heff_tag_n(TAG_Cons, 2, (V[]){v_l_242, heff_get_n(v_m_241, 0, 3)});
          return heff_rec_n(3, shape_out__code__expecting, (V[]){v_t_2415, NTAG(TAG_True), NTAG(TAG_True)});
        }
      } else {
        heff_drop(v_t_247);
        V v_t_2416 = heff_take_field(v_m_241, 1);
        V v_t_2417;
        if ((heff_dup(v_t_2416) == NTAG(TAG_True))) {
          heff_drop(v_t_2416);
          v_t_2417 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2equery_2edocMdStep_str4), heff_get_n(v_m_241, 0, 3)});
        } else {
          heff_drop(v_t_2416);
          v_t_2417 = heff_get_n(v_m_241, 0, 3);
        }
        return heff_rec_n(3, shape_out__code__expecting, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_l_242, v_t_2417}), NTAG(TAG_False), NTAG(TAG_False)});
      }
    } else {
      heff_drop(v_t_246);
      V v_t_2418 = heff_take_field(v_m_241, 1);
      V v_t_2419;
      if ((heff_dup(v_t_2418) == NTAG(TAG_True))) {
        heff_drop(v_t_2418);
        v_t_2419 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2equery_2edocMdStep_str5), heff_get_n(v_m_241, 0, 3)});
      } else {
        heff_drop(v_t_2418);
        v_t_2419 = heff_get_n(v_m_241, 0, 3);
      }
      return heff_rec_n(3, shape_out__code__expecting, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_l_242, v_t_2419}), NTAG(TAG_False), NTAG(TAG_False)});
    }
  }
}
V g_heff_2ebuild_2equery_2edocMdStep_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2equery_2edocMdStep(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ebuild_2equery_2edocMarkdownIn_str0, 3, "```");
HEFF_LIT(g_heff_2ebuild_2equery_2edocMarkdownIn_str1, 0, "");
HEFF_LIT(g_heff_2ebuild_2equery_2edocMarkdownIn_str2, 1, "\012");
Clo g_heff_2ebuild_2equery_2edocMarkdownIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2edocMarkdownIn_entry, 2, 0};

V g_heff_2ebuild_2equery_2edocMarkdownIn(V v_lang_240, V v_ls_241) {
top: ;
  V v_t_242 = heff_rec_n(3, shape_out__code__expecting, (V[]){NTAG(TAG_Nil), NTAG(TAG_False), NTAG(TAG_False)});
  V v_m_243 = (g_list_2efoldl_24s673493459x989016999(v_lang_240, v_t_242, v_ls_241));
  V v_t_244 = heff_take_field(v_m_243, 1);
  V v_t_245;
  if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
    heff_drop(v_t_244);
    v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2equery_2edocMarkdownIn_str0), heff_get_n(v_m_243, 0, 3)});
  } else {
    heff_drop(v_t_244);
    v_t_245 = heff_get_n(v_m_243, 0, 3);
  }
  V v_x2_246 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_t_245));
  switch (heff_tag_of(v_x2_246)) {
  case TAG_Nil: {
    return ((V)&g_heff_2ebuild_2equery_2edocMarkdownIn_str1);
  }
  case TAG_Cons: {
    V v_x_247 = heff_field(v_x2_246, 0);
    V v_xs_248 = heff_field(v_x2_246, 1);
    heff_take_n(v_x2_246, 3ULL, 2);
    return ({ V a_0 = ((V)&g_heff_2ebuild_2equery_2edocMarkdownIn_str2); V a_1 = v_x_247; V a_2 = v_xs_248; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_248); r_; });
  }
  default: return heff_nomatch(v_x2_246);
  }
}
V g_heff_2ebuild_2equery_2edocMarkdownIn_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2equery_2edocMarkdownIn(a[0], a1); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ebuild_2equery_2edocAt_str0, 4, "heff");
HEFF_LIT(g_heff_2ebuild_2equery_2edocAt_str1, 0, "");
Clo g_heff_2ebuild_2equery_2edocAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2edocAt_entry, 2, 0};

V g_heff_2ebuild_2equery_2edocAt(V v_program_240, V v_off_241) {
top: ;
  HeffT2 v_t_242 = (g_heff_2ebuild_2equery_2edefinitionAt_24cpr(v_program_240, v_off_241));
  {
    V v_field_244 = v_t_242.f[1];
    int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
    if ((v_tag_243 == ((int64_t)0ULL))) {
      V v_d_246 = v_field_244;
      V v_t_247 = heff_get_n(heff_dup(heff_rfield(v_d_246, 2)), 0, 2);
      V v_start_248 = (g_heff_2ebuild_2equery_2elineStartOf(heff_rfield(v_d_246, 1), v_t_247));
      V v_t_249 = ({ V b_0 = heff_get_n(v_d_246, 1, 3); V a_1 = v_start_248; V a_2 = NTAG(TAG_Nil); V r_ = (g_heff_2ebuild_2equery_2ecommentAbove(b_0, a_1, a_2)); heff_drop(b_0); r_; });
      V v_t_2410 = (g_list_2emap_24s1819241345x1511673126(v_t_249));
      V v_ls_2411 = (g_heff_2ebuild_2equery_2ecatMaybesQ(v_t_2410));
      return ({ V a_0 = ((V)&g_heff_2ebuild_2equery_2edocAt_str0); V a_1 = v_ls_2411; V r_ = (g_heff_2ebuild_2equery_2edocMarkdownIn(a_0, a_1)); heff_drop(v_ls_2411); r_; });
    } else {
      heff_drop(v_field_244);
      return ((V)&g_heff_2ebuild_2equery_2edocAt_str1);
    }
  }
}
V g_heff_2ebuild_2equery_2edocAt_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2equery_2edocAt(a[0], a[1]);
}
HEFF_LIT(g_heff_2ebuild_2equery_2ebrokenSymbol_str0, 5, "data ");
HEFF_LIT(g_heff_2ebuild_2equery_2ebrokenSymbol_str1, 7, "theory ");
Clo g_heff_2ebuild_2equery_2ebrokenSymbol_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2ebrokenSymbol_entry, 2, 0};

V g_heff_2ebuild_2equery_2ebrokenSymbol(V v_c_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_MkPair: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_sp_243 = heff_field(v_x2_241, 1);
    V v_text_244 = heff_strSlice(heff_dup(heff_rfield(v_c_240, 3)), heff_dup(heff_rfield(v_sp_243, 0)), heff_dup(heff_rfield(v_sp_243, 1)));
    V v_t_248;
    if (heff_strEq_c(heff_strSlice_lent(v_text_244, MK_INT(0LL), MK_INT(5LL), 6), ((V)&g_heff_2ebuild_2equery_2ebrokenSymbol_str0))) {
      heff_drop(v_text_244);
      v_t_248 = MK_INT(10LL);
    } else {
      if (heff_strEq_c(heff_strSlice(v_text_244, MK_INT(0LL), MK_INT(7LL)), ((V)&g_heff_2ebuild_2equery_2ebrokenSymbol_str1))) {
        v_t_248 = MK_INT(11LL);
      } else {
        V v_x1_247 = (g_heff_2ebuild_2equery_2eisNameChar(heff_strByteAt_lent(v_x_242, MK_INT(0LL), 2)));
        if ((heff_dup(v_x1_247) == NTAG(TAG_True))) {
          heff_drop(v_x1_247);
          v_t_248 = MK_INT(12LL);
        } else {
          heff_drop(v_x1_247);
          v_t_248 = MK_INT(25LL);
        }
      }
    }
    V v_t_249 = ({ V b_0 = heff_get_n(v_c_240, 3, 14); V a_1 = v_x_242; V a_2 = heff_dup(v_sp_243); V a_3 = heff_dup(heff_rfield(v_sp_243, 0)); V r_ = (g_heff_2ebuild_2equery_2enameInGo(b_0, a_1, a_2, a_3)); heff_drop(b_0); r_; });
    return heff_rec_n(5, shape_name__kind__span__selection__children, (V[]){heff_dup(v_x_242), v_t_248, heff_dup(v_sp_243), v_t_249, NTAG(TAG_Nil)});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2equery_2ebrokenSymbol_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2equery_2ebrokenSymbol(a[0], a1); heff_drop(a1); return r;
}
Clo g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211_entry, 1, 0};

V g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_At: {
    V v_x21_241 = heff_field(v_x2_240, 0);
    switch (heff_tag_of(v_x21_241)) {
    case TAG_EVar: {
      return NTAG(TAG_Nil);
    }
    case TAG_EImplicitVar: {
      return NTAG(TAG_Nil);
    }
    case TAG_ETag: {
      return NTAG(TAG_Nil);
    }
    case TAG_EInt: {
      return NTAG(TAG_Nil);
    }
    case TAG_EFloat: {
      return NTAG(TAG_Nil);
    }
    case TAG_EString: {
      return NTAG(TAG_Nil);
    }
    case TAG_EBinary: {
      return NTAG(TAG_Nil);
    }
    case TAG_ERune: {
      return NTAG(TAG_Nil);
    }
    case TAG_EWord: {
      return NTAG(TAG_Nil);
    }
    case TAG_EApp: {
      V v_h_2412 = heff_field(v_x21_241, 0);
      V v_args_2413 = heff_field(v_x21_241, 1);
      V v_t_2414 = (g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(v_h_2412));
      V v_t_2415 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_args_2413)));
      V v_t_2416 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2415; V r_ = (g_list_2efoldl_24s2134067310x2049132013(a_0, a_1)); heff_drop(v_t_2415); r_; });
      return (g_prelude_2e_2b_2b(v_t_2414, v_t_2416));
    }
    case TAG_EProject: {
      return NTAG(TAG_Nil);
    }
    case TAG_ENamed: {
      V v_e_2419 = heff_field(v_x21_241, 1);
      V t_0 = v_e_2419;
      v_x2_240 = t_0;
      goto top;
    }
    case TAG_EPi: {
      V v_b_2420 = heff_field(v_x21_241, 0);
      V v_cod_2421 = heff_field(v_x21_241, 1);
      V v_t_2438;
      switch (heff_tag_of(v_b_2420)) {
      case TAG_PiNamed: {
        V v_t_2424 = heff_field(v_b_2420, 2);
        v_t_2438 = (g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(v_t_2424));
        break;
      }
      case TAG_PiImplicit: {
        V v_t_2428 = heff_field(v_b_2420, 3);
        V v_d_2429 = heff_field(v_b_2420, 4);
        V v_t_2430 = (g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(v_t_2428));
        V v_t_2432;
        switch (heff_tag_of(v_d_2429)) {
        case TAG_Nothing: {
          v_t_2432 = NTAG(TAG_Nil);
          break;
        }
        case TAG_Just: {
          V v_x_2431 = heff_field(v_d_2429, 0);
          v_t_2432 = (g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(v_x_2431));
          break;
        }
        default: heff_nomatch(v_d_2429);
        }
        v_t_2438 = (g_prelude_2e_2b_2b(v_t_2430, v_t_2432));
        break;
      }
      case TAG_PiInstance: {
        V v_t_2436 = heff_field(v_b_2420, 3);
        v_t_2438 = (g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(v_t_2436));
        break;
      }
      case TAG_PiAnon: {
        V v_t_2437 = heff_field(v_b_2420, 0);
        v_t_2438 = (g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(v_t_2437));
        break;
      }
      default: heff_nomatch(v_b_2420);
      }
      V v_t_2439 = (g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(v_cod_2421));
      return (g_prelude_2e_2b_2b(v_t_2438, v_t_2439));
    }
    case TAG_ELam: {
      V v_b_2440 = heff_field(v_x21_241, 0);
      V v_body_2441 = heff_field(v_x21_241, 1);
      V v_t_2449;
      switch (heff_tag_of(v_b_2440)) {
      case TAG_LamName: {
        v_t_2449 = NTAG(TAG_Nil);
        break;
      }
      case TAG_LamImplicit: {
        v_t_2449 = NTAG(TAG_Nil);
        break;
      }
      case TAG_LamAnn: {
        V v_t_2448 = heff_field(v_b_2440, 2);
        v_t_2449 = (g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(v_t_2448));
        break;
      }
      default: heff_nomatch(v_b_2440);
      }
      V v_t_2450 = (g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(v_body_2441));
      return (g_prelude_2e_2b_2b(v_t_2449, v_t_2450));
    }
    case TAG_EAnn: {
      V v_e_2451 = heff_field(v_x21_241, 0);
      V v_t_2452 = heff_field(v_x21_241, 1);
      V v_t_2453 = (g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(v_e_2451));
      V v_t_2454 = (g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(v_t_2452));
      return (g_prelude_2e_2b_2b(v_t_2453, v_t_2454));
    }
    case TAG_ESpec: {
      V v_acc_2455 = heff_field(v_x21_241, 0);
      V v_v_2458 = heff_field(v_x21_241, 3);
      V v_t_2459 = (g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(v_acc_2455));
      V v_t_2460 = (g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(v_v_2458));
      return (g_prelude_2e_2b_2b(v_t_2459, v_t_2460));
    }
    case TAG_ESig: {
      V v_fs_2461 = heff_field(v_x21_241, 0);
      V v_t_2462 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_fs_2461)));
      return ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2462; V r_ = (g_list_2efoldl_24s1777318809x1106245647(a_0, a_1)); heff_drop(v_t_2462); r_; });
    }
    case TAG_ESum: {
      V v_vs_2463 = heff_field(v_x21_241, 0);
      V v_t_2464 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_vs_2463)));
      return ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2464; V r_ = (g_list_2efoldl_24s491084544x100802329(a_0, a_1)); heff_drop(v_t_2464); r_; });
    }
    case TAG_EStruct: {
      V v_fs_2465 = heff_field(v_x21_241, 0);
      V v_t_2466 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_fs_2465)));
      return ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2466; V r_ = (g_list_2efoldl_24s189033563x26633104(a_0, a_1)); heff_drop(v_t_2466); r_; });
    }
    case TAG_EUpdate: {
      V v_a_2467 = heff_field(v_x21_241, 0);
      V v_fs_2468 = heff_field(v_x21_241, 1);
      V v_t_2469 = (g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(v_a_2467));
      V v_t_2470 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_fs_2468)));
      V v_t_2471 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2470; V r_ = (g_list_2efoldl_24s1026998256x1634433314(a_0, a_1)); heff_drop(v_t_2470); r_; });
      return (g_prelude_2e_2b_2b(v_t_2469, v_t_2471));
    }
    case TAG_EMatch: {
      V v_s_2472 = heff_field(v_x21_241, 0);
      V v_alts_2473 = heff_field(v_x21_241, 1);
      V v_t_2474 = (g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(v_s_2472));
      V v_t_2475 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_alts_2473)));
      V v_t_2476 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2475; V r_ = (g_list_2efoldl_24s302194196x751324068(a_0, a_1)); heff_drop(v_t_2475); r_; });
      return (g_prelude_2e_2b_2b(v_t_2474, v_t_2476));
    }
    case TAG_ELetIn: {
      V v_rhs_2477 = heff_field(v_x21_241, 0);
      V v_x212_2478 = heff_field(v_x21_241, 1);
      switch (heff_tag_of(v_x212_2478)) {
      case TAG_At: {
        V v_x2121_2479 = heff_field(v_x212_2478, 0);
        switch (heff_tag_of(v_x2121_2479)) {
        case TAG_MkAlt: {
          V v_e_2482 = heff_field(v_x2121_2479, 1);
          V v_t_2483 = (g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(v_rhs_2477));
          V v_t_2484 = (g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(v_e_2482));
          return (g_prelude_2e_2b_2b(v_t_2483, v_t_2484));
        }
        default: return heff_nomatch(v_x2121_2479);
        }
      }
      default: return heff_nomatch(v_x212_2478);
      }
    }
    case TAG_EDo: {
      V v_stmts_2485 = heff_field(v_x21_241, 0);
      V v_t_2486 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_stmts_2485)));
      return ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2486; V r_ = (g_list_2efoldl_24s1545552222x115732981(a_0, a_1)); heff_drop(v_t_2486); r_; });
    }
    case TAG_ELocal: {
      V v_b_2487 = heff_field(v_x21_241, 0);
      V v_defs_2488 = heff_field(v_x21_241, 1);
      V v_t_2489 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_defs_2488)));
      V v_t_2490 = (g_list_2efoldl_24s1516272141x1201056882(MK_INT(12LL), NTAG(TAG_Nil), v_t_2489));
      V v_t_2491 = (g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(v_b_2487));
      V v_t_2492 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_defs_2488)));
      V v_t_2493 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2492; V r_ = (g_list_2efoldl_24s54159557x1528472185(a_0, a_1)); heff_drop(v_t_2492); r_; });
      V v_t_2494 = (g_prelude_2e_2b_2b(v_t_2491, v_t_2493));
      return (g_prelude_2e_2b_2b(v_t_2490, v_t_2494));
    }
    case TAG_EInvalid: {
      return NTAG(TAG_Nil);
    }
    case TAG_EAssign: {
      V v_e_2498 = heff_field(v_x21_241, 2);
      V t_0 = v_e_2498;
      v_x2_240 = t_0;
      goto top;
    }
    case TAG_EWhile: {
      V v_c_2499 = heff_field(v_x21_241, 0);
      V v_body_24100 = heff_field(v_x21_241, 1);
      V v_t_24101 = (g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(v_c_2499));
      V v_t_24102 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_body_24100)));
      V v_t_24103 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_24102; V r_ = (g_list_2efoldl_24s1545552222x115732981(a_0, a_1)); heff_drop(v_t_24102); r_; });
      return (g_prelude_2e_2b_2b(v_t_24101, v_t_24103));
    }
    case TAG_EFor: {
      V v_c_24105 = heff_field(v_x21_241, 1);
      V v_body_24106 = heff_field(v_x21_241, 2);
      V v_t_24107 = (g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(v_c_24105));
      V v_t_24108 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_body_24106)));
      V v_t_24109 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_24108; V r_ = (g_list_2efoldl_24s1545552222x115732981(a_0, a_1)); heff_drop(v_t_24108); r_; });
      return (g_prelude_2e_2b_2b(v_t_24107, v_t_24109));
    }
    case TAG_EIfThen: {
      V v_c_24110 = heff_field(v_x21_241, 0);
      V v_a_24111 = heff_field(v_x21_241, 1);
      V v_t_24112 = (g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(v_c_24110));
      V v_t_24113 = (g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(v_a_24111));
      return (g_prelude_2e_2b_2b(v_t_24112, v_t_24113));
    }
    case TAG_EBreak: {
      return NTAG(TAG_Nil);
    }
    case TAG_EContinue: {
      return NTAG(TAG_Nil);
    }
    case TAG_EReturn: {
      V v_e_24114 = heff_field(v_x21_241, 0);
      V t_0 = v_e_24114;
      v_x2_240 = t_0;
      goto top;
    }
    case TAG_ENest: {
      V v_e_24115 = heff_field(v_x21_241, 0);
      V t_0 = v_e_24115;
      v_x2_240 = t_0;
      goto top;
    }
    case TAG_EIfLet: {
      V v_s_24117 = heff_field(v_x21_241, 1);
      V v_a_24118 = heff_field(v_x21_241, 2);
      V v_b_24119 = heff_field(v_x21_241, 3);
      V v_t_24120 = (g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(v_s_24117));
      V v_t_24121 = (g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(v_a_24118));
      V v_t_24123;
      switch (heff_tag_of(v_b_24119)) {
      case TAG_Nothing: {
        v_t_24123 = NTAG(TAG_Nil);
        break;
      }
      case TAG_Just: {
        V v_x_24122 = heff_field(v_b_24119, 0);
        v_t_24123 = (g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(v_x_24122));
        break;
      }
      default: heff_nomatch(v_b_24119);
      }
      V v_t_24124 = (g_prelude_2e_2b_2b(v_t_24121, v_t_24123));
      return (g_prelude_2e_2b_2b(v_t_24120, v_t_24124));
    }
    case TAG_ETry: {
      V v_x211_24125 = heff_field(v_x21_241, 0);
      switch (heff_tag_of(v_x211_24125)) {
      case TAG_MkTry: {
        V v_body_24127 = heff_field(v_x211_24125, 1);
        V v_c_24128 = heff_field(v_x211_24125, 2);
        V v_t_24129 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_body_24127)));
        V v_t_24130 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_24129; V r_ = (g_list_2efoldl_24s1545552222x115732981(a_0, a_1)); heff_drop(v_t_24129); r_; });
        V v_t_24143;
        switch (heff_tag_of(v_c_24128)) {
        case TAG_MkCatchArm: {
          V v_b_24131 = heff_field(v_c_24128, 0);
          V v_ss_24132 = heff_field(v_c_24128, 1);
          V v_t_24140;
          switch (heff_tag_of(v_b_24131)) {
          case TAG_LamName: {
            v_t_24140 = NTAG(TAG_Nil);
            break;
          }
          case TAG_LamImplicit: {
            v_t_24140 = NTAG(TAG_Nil);
            break;
          }
          case TAG_LamAnn: {
            V v_t_24139 = heff_field(v_b_24131, 2);
            v_t_24140 = (g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(v_t_24139));
            break;
          }
          default: heff_nomatch(v_b_24131);
          }
          V v_t_24141 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_ss_24132)));
          V v_t_24142 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_24141; V r_ = (g_list_2efoldl_24s1545552222x115732981(a_0, a_1)); heff_drop(v_t_24141); r_; });
          v_t_24143 = (g_prelude_2e_2b_2b(v_t_24140, v_t_24142));
          break;
        }
        default: heff_nomatch(v_c_24128);
        }
        return (g_prelude_2e_2b_2b(v_t_24130, v_t_24143));
      }
      default: return heff_nomatch(v_x211_24125);
      }
    }
    case TAG_EWith: {
      V v_w_24144 = heff_field(v_x21_241, 0);
      V v_body_24147 = heff_field(v_x21_241, 3);
      V v_t_24148 = (g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(v_w_24144));
      V v_t_24149 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_body_24147)));
      V v_t_24150 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_24149; V r_ = (g_list_2efoldl_24s1545552222x115732981(a_0, a_1)); heff_drop(v_t_24149); r_; });
      return (g_prelude_2e_2b_2b(v_t_24148, v_t_24150));
    }
    default: return heff_nomatch(v_x21_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(a0); heff_drop(a0); return r;
}
Clo g_heff_2ebuild_2equery_2elocalDeclF_24s1801777056x609367408_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2elocalDeclF_24s1801777056x609367408_entry, 1, 0};

V g_heff_2ebuild_2equery_2elocalDeclF_24s1801777056x609367408(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_At: {
    V v_x21_241 = heff_field(v_x2_240, 0);
    switch (heff_tag_of(v_x21_241)) {
    case TAG_DeclEquations: {
      V v_ty_246 = heff_field(v_x21_241, 3);
      V v_eqs_247 = heff_field(v_x21_241, 4);
      V v_t_248 = (g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(v_ty_246));
      V v_t_249 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_eqs_247)));
      V v_t_2410 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_249; V r_ = (g_list_2efoldl_24s496727651x1448898893(a_0, a_1)); heff_drop(v_t_249); r_; });
      return (g_prelude_2e_2b_2b(v_t_248, v_t_2410));
    }
    case TAG_DeclDefine: {
      V v_ps_2413 = heff_field(v_x21_241, 2);
      V v_u_2414 = heff_field(v_x21_241, 3);
      V v_body_2415 = heff_field(v_x21_241, 4);
      V v_t_2416 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_ps_2413)));
      V v_t_2417 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2416; V r_ = (g_list_2efoldl_24s1975553568x1034350329(a_0, a_1)); heff_drop(v_t_2416); r_; });
      V v_t_2418 = (g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(v_u_2414));
      V v_t_2419 = (g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(v_body_2415));
      V v_t_2420 = (g_prelude_2e_2b_2b(v_t_2418, v_t_2419));
      return (g_prelude_2e_2b_2b(v_t_2417, v_t_2420));
    }
    case TAG_DeclTheory: {
      V v_ps_2423 = heff_field(v_x21_241, 2);
      V v_body_2424 = heff_field(v_x21_241, 3);
      V v_t_2425 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_ps_2423)));
      V v_t_2426 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2425; V r_ = (g_list_2efoldl_24s1975553568x1034350329(a_0, a_1)); heff_drop(v_t_2425); r_; });
      V v_t_2427 = (g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(v_body_2424));
      return (g_prelude_2e_2b_2b(v_t_2426, v_t_2427));
    }
    case TAG_DeclPrimitive: {
      V v_t_2430 = heff_field(v_x21_241, 2);
      HEFF_LAST return g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(v_t_2430);
    }
    case TAG_DeclTest: {
      return NTAG(TAG_Nil);
    }
    case TAG_DeclWatch: {
      V v_e_2433 = heff_field(v_x21_241, 0);
      HEFF_LAST return g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(v_e_2433);
    }
    default: return heff_nomatch(v_x21_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2ebuild_2equery_2elocalDeclF_24s1801777056x609367408_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2equery_2elocalDeclF_24s1801777056x609367408(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ebuild_2equery_2esymbolWith_str0, 5, "data ");
HEFF_LIT(g_heff_2ebuild_2equery_2esymbolWith_str1, 7, "theory ");
HEFF_LIT(g_heff_2ebuild_2equery_2esymbolWith_str2, 5, "data ");
Clo g_heff_2ebuild_2equery_2esymbolWith_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2esymbolWith_entry, 4, 0};

V g_heff_2ebuild_2equery_2esymbolWith(V v_c_240, V v_o_241, V v_sp_242, V v_own_243) {
top: ;
  V v_text_244 = heff_strSlice(heff_dup(heff_rfield(v_c_240, 3)), heff_dup(heff_rfield(v_sp_242, 0)), heff_dup(heff_rfield(v_sp_242, 1)));
  V v_t_249;
  if (heff_strEq_c(heff_strSlice_lent(v_text_244, MK_INT(0LL), MK_INT(5LL), 6), ((V)&g_heff_2ebuild_2equery_2esymbolWith_str0))) {
    heff_drop(v_text_244);
    v_t_249 = MK_INT(10LL);
  } else {
    if (heff_strEq_c(heff_strSlice(v_text_244, MK_INT(0LL), MK_INT(7LL)), ((V)&g_heff_2ebuild_2equery_2esymbolWith_str1))) {
      v_t_249 = MK_INT(11LL);
    } else {
      V v_t_247 = heff_strByteAt(heff_dup(heff_rfield(v_o_241, 0)), MK_INT(0LL));
      V v_x1_248 = (g_heff_2ebuild_2equery_2eisNameChar(v_t_247));
      if ((heff_dup(v_x1_248) == NTAG(TAG_True))) {
        heff_drop(v_x1_248);
        v_t_249 = MK_INT(12LL);
      } else {
        heff_drop(v_x1_248);
        v_t_249 = MK_INT(25LL);
      }
    }
  }
  HeffT2 v_t_2410 = (g_list_2efind_24s1702704581x1717241719_24cpr(heff_dup(v_own_243)));
  V v_t_2415;
  {
    V v_field_2412 = v_t_2410.f[1];
    int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
    if ((v_tag_2411 == ((int64_t)0ULL))) {
      V v_s_2414 = v_field_2412;
      v_t_2415 = heff_get_n(v_s_2414, 2, 3);
    } else {
      heff_drop(v_field_2412);
      v_t_2415 = (g_heff_2ebuild_2equery_2enameInGo(heff_rfield(v_c_240, 3), heff_rfield(v_o_241, 0), heff_dup(v_sp_242), heff_dup(heff_rfield(v_sp_242, 0))));
    }
  }
  V v_t_2416 = ({ V a_0 = heff_dup(v_c_240); V a_1 = heff_dup(v_sp_242); V a_2 = MK_INT(5LL); V b_3 = ((V)&g_heff_2ebuild_2equery_2esymbolWith_str2); V a_4 = MK_INT(22LL); V a_5 = MK_INT(8LL); V a_6 = v_own_243; V r_ = (g_list_2emap_24f1959721488x1340654904(a_0, a_1, a_2, b_3, a_4, a_5, a_6)); heff_drop(b_3); r_; });
  V v_t_2417 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_get_n(v_c_240, 4, 14)));
  V v_t_2418 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2417; V r_ = (g_list_2efoldl_24s54159557x1528472185(a_0, a_1)); heff_drop(v_t_2417); r_; });
  V v_t_2419 = (g_list_2efilter_24s343483820x881052984(heff_dup(v_sp_242), v_t_2418));
  V v_t_2420 = (g_prelude_2e_2b_2b(v_t_2416, v_t_2419));
  return heff_rec_n(5, shape_name__kind__span__selection__children, (V[]){heff_get_n(v_o_241, 0, 2), v_t_249, v_sp_242, v_t_2415, v_t_2420});
}
V g_heff_2ebuild_2equery_2esymbolWith_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2equery_2esymbolWith(a[0], a[1], a[2], a[3]);
}
Clo g_heff_2ebuild_2equery_2esymbolsGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2esymbolsGo_entry, 4, 0};

V g_heff_2ebuild_2equery_2esymbolsGo(V v_c_240, V v_ss_241, V v_x3_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_c_240);
    heff_drop(v_ss_241);
    heff_drop(v_x4_243);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_o_244 = heff_field(v_x3_242, 0);
    V v_os_245 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    switch (heff_tag_of(v_x4_243)) {
    case TAG_Nil: {
      heff_drop(v_c_240);
      heff_drop(v_ss_241);
      heff_drop(v_o_244);
      heff_drop(v_os_245);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_x41_246 = heff_field(v_x4_243, 0);
      V v_sps_247 = heff_field(v_x4_243, 1);
      heff_take_n(v_x4_243, 3ULL, 2);
      switch (heff_tag_of(v_x41_246)) {
      case TAG_MkPair: {
        V v_sp_249 = heff_field(v_x41_246, 1);
        heff_take_n(v_x41_246, 2ULL, 2);
        V v_t_2410 = (g_list_2efilter_24s1716878720x675187502(heff_dup(v_sp_249), heff_dup(v_ss_241)));
        V v_t_2411 = (g_heff_2ebuild_2equery_2esymbolWith(heff_dup(v_c_240), v_o_244, v_sp_249, v_t_2410));
        V v_cell_2412 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_t_2411, heff_hole()});
        V v_u_2413 = (g_heff_2ebuild_2equery_2esymbolsGo_24dps(v_c_240, v_ss_241, v_os_245, v_sps_247, heff_dup(v_cell_2412)));
        heff_drop(v_u_2413);
        return v_cell_2412;
      }
      default: return heff_nomatch(v_x41_246);
      }
    }
    default: return heff_nomatch(v_x4_243);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2equery_2esymbolsGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2equery_2esymbolsGo(a[0], a[1], a[2], a[3]);
}
Clo g_heff_2ebuild_2equery_2esymbolsGo_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2esymbolsGo_24dps_entry, 5, 0};

V g_heff_2ebuild_2equery_2esymbolsGo_24dps(V v_c_240, V v_ss_241, V v_x3_242, V v_x4_243, V v_d_244) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_c_240);
    heff_drop(v_ss_241);
    heff_drop(v_x4_243);
    return heff_setField(v_d_244, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_o_245 = heff_field(v_x3_242, 0);
    V v_os_246 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    switch (heff_tag_of(v_x4_243)) {
    case TAG_Nil: {
      heff_drop(v_c_240);
      heff_drop(v_ss_241);
      heff_drop(v_o_245);
      heff_drop(v_os_246);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      return heff_setField(v_d_244, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_Cons: {
      V v_x41_247 = heff_field(v_x4_243, 0);
      V v_sps_248 = heff_field(v_x4_243, 1);
      heff_take_n(v_x4_243, 3ULL, 2);
      switch (heff_tag_of(v_x41_247)) {
      case TAG_MkPair: {
        V v_sp_2410 = heff_field(v_x41_247, 1);
        heff_take_n(v_x41_247, 2ULL, 2);
        V v_t_2411 = (g_list_2efilter_24s1716878720x675187502(heff_dup(v_sp_2410), heff_dup(v_ss_241)));
        V v_t_2412 = (g_heff_2ebuild_2equery_2esymbolWith(heff_dup(v_c_240), v_o_245, v_sp_2410, v_t_2411));
        V v_cell_2413 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_t_2412, heff_hole()});
        V v_u_2414 = heff_setField(v_d_244, MK_INT(1LL), heff_dup(v_cell_2413));
        heff_drop(v_u_2414);
        V t_0 = v_c_240;
        V t_1 = v_ss_241;
        V t_2 = v_os_246;
        V t_3 = v_sps_248;
        V t_4 = v_cell_2413;
        v_c_240 = t_0;
        v_ss_241 = t_1;
        v_x3_242 = t_2;
        v_x4_243 = t_3;
        v_d_244 = t_4;
        goto top;
      }
      default: return heff_nomatch(v_x41_247);
      }
    }
    default: return heff_nomatch(v_x4_243);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2equery_2esymbolsGo_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2equery_2esymbolsGo_24dps(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ebuild_2equery_2esymbols_lam0(V self, V *args);
V g_heff_2ebuild_2equery_2esymbols_lam1(V self, V *args);
Clo g_heff_2ebuild_2equery_2esymbols_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2esymbols_entry, 1, 0};

V g_heff_2ebuild_2equery_2esymbols(V v_c_240) {
top: ;
  V v_t_241 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(heff_rfield(v_c_240, 4))));
  V v_t_245 = ({ V a_0 = heff_clo_n(g_heff_2ebuild_2equery_2esymbols_lam0, 2, 1, (V[]){heff_dup(v_c_240)}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_241; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_241); r_; });
  V v_t_246 = heff_get_n(heff_dup(heff_rfield(v_c_240, 5)), 6, 9);
  V v_t_247 = (g_heff_2ebuild_2equery_2esymbolsGo(heff_dup(v_c_240), v_t_245, heff_dup(heff_rfield(v_c_240, 7)), v_t_246));
  V v_t_248 = heff_get_n(heff_dup(heff_rfield(v_c_240, 5)), 3, 9);
  V v_t_2410 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2equery_2esymbols_lam1, 1, 1, (V[]){v_c_240}), v_t_248));
  V v_t_2411 = (g_prelude_2e_2b_2b(v_t_247, v_t_2410));
  HEFF_LAST return g_list_2esortBy_24s1230002843x105774350(v_t_2411);
}
V g_heff_2ebuild_2equery_2esymbols_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2equery_2esymbols(a[0]);
}
V g_heff_2ebuild_2equery_2esymbols_lam0(V self, V *args) {
  V v_acc_242 = args[0];
  V v_x_243 = args[1];
  V v_c_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_244 = (g_heff_2ebuild_2equery_2edeclSites(v_c_240, v_x_243));
  return (g_prelude_2e_2b_2b(v_t_244, v_acc_242));
}
V g_heff_2ebuild_2equery_2esymbols_lam1(V self, V *args) {
  V v_p_249 = args[0];
  V v_c_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_c_240; V a_1 = v_p_249; V r_ = (g_heff_2ebuild_2equery_2ebrokenSymbol(a_0, a_1)); heff_drop(v_p_249); r_; });
}