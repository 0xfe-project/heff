// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_At 8900
#define TAG_DeclDefine 5286
#define TAG_DeclEquations 25755
#define TAG_DeclPrimitive 46335
#define TAG_DeclTest 38719
#define TAG_DeclTheory 39552
#define TAG_DeclWatch 51419
#define TAG_EAnn 33099
#define TAG_EApp 33163
#define TAG_EBinary 42634
#define TAG_EDo 15964
#define TAG_EFloat 59274
#define TAG_EImplicitVar 16588
#define TAG_EInt 40793
#define TAG_EInvalid 31081
#define TAG_ELam 43266
#define TAG_ELetIn 22786
#define TAG_ELocal 42997
#define TAG_EMatch 41631
#define TAG_ENamed 41119
#define TAG_EPi 16330
#define TAG_EProject 35489
#define TAG_ERune 31947
#define TAG_ESig 50235
#define TAG_ESpec 56652
#define TAG_EString 8932
#define TAG_EStruct 20136
#define TAG_ESum 50613
#define TAG_ETag 50948
#define TAG_EUpdate 6986
#define TAG_EVar 52881
#define TAG_EWord 44207
#define TAG_LamAnn 40466
#define TAG_LamImplicit 28191
#define TAG_LamName 56383
#define TAG_MkAlt 55173
#define TAG_PiAnon 44344
#define TAG_PiImplicit 53923
#define TAG_PiInstance 8677
#define TAG_PiNamed 16606
#define TAG_SDebug 8687
#define TAG_SError 24172
#define TAG_SWarning 44190
#define LBL_aliases 1464806715
#define LBL_binder 558177493
#define LBL_broken 566525696
#define LBL_c 317
#define LBL_children 257181584
#define LBL_code 9554612
#define LBL_col 308218
#define LBL_decls 296817955
#define LBL_defines 1776893014
#define LBL_detail 611917692
#define LBL_diags 296935042
#define LBL_end 310101
#define LBL_entries 787768015
#define LBL_expecting 1746726246
#define LBL_fields 672433636
#define LBL_from 9647217
#define LBL_globals 352931696
#define LBL_infos 301706655
#define LBL_key 315609
#define LBL_kind 9787483
#define LBL_label 304085774
#define LBL_line 9817275
#define LBL_local 304503685
#define LBL_locals 849679763
#define LBL_member 869372357
#define LBL_module 878357911
#define LBL_msg 317947
#define LBL_name 9869138
#define LBL_order 307364712
#define LBL_out 319944
#define LBL_own 320000
#define LBL_path 9928940
#define LBL_selection 2055983820
#define LBL_severity 75955546
#define LBL_source 1050636102
#define LBL_span 10032145
#define LBL_spans 310996611
#define LBL_start 311115900
#define LBL_target 1066236092
#define LBL_text 10052084
#define LBL_to 10466
#define LBL_top 324559
#define LBL_trace 311979359
#define LBL_ty 10476
#define LBL_type_5f 312202367
#define LBL_uses 10094739
#define LBL_watches 1357821955
static uint32_t shape_c__name__span[] = {LBL_c, LBL_name, LBL_span};
static uint32_t shape_key__member__local[] = {LBL_key, LBL_member, LBL_local};
static uint32_t shape_label__detail[] = {LBL_label, LBL_detail};
static uint32_t shape_name__kind__span__selection__children[] = {LBL_name, LBL_kind, LBL_span, LBL_selection, LBL_children};
static uint32_t shape_out__code__expecting[] = {LBL_out, LBL_code, LBL_expecting};
static uint32_t shape_path__source__span[] = {LBL_path, LBL_source, LBL_span};
static uint32_t shape_path__source__span__defines[] = {LBL_path, LBL_source, LBL_span, LBL_defines};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
static uint32_t shape_target__name[] = {LBL_target, LBL_name};
static uint32_t shape_text__span[] = {LBL_text, LBL_span};
V g_heff_2ebuild_2edriver_2eexpectAfter(V, V, V);
V g_heff_2ebuild_2edriver_2eexpectAfter_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eexpectAfter_clo;
V g_heff_2ebuild_2edriver_2enubStrD(V);
V g_heff_2ebuild_2edriver_2enubStrD_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2enubStrD_clo;
V g_heff_2ebuild_2edriver_2eshowTySx(V, V);
V g_heff_2ebuild_2edriver_2eshowTySx_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eshowTySx_clo;
V g_heff_2ebuild_2equery_2eallChars_24s1240979977x1750746677(V, V, V);
V g_heff_2ebuild_2equery_2eallChars_24s1240979977x1750746677_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2eallChars_24s1240979977x1750746677_clo;
V g_heff_2ebuild_2equery_2eallChars_24s1328103304x613783392(V, V);
V g_heff_2ebuild_2equery_2eallChars_24s1328103304x613783392_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2eallChars_24s1328103304x613783392_clo;
V g_heff_2ebuild_2equery_2eatLine(V, V);
V g_heff_2ebuild_2equery_2eatLine_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2eatLine_clo;
V g_heff_2ebuild_2equery_2ebrokenSymbol(V, V);
V g_heff_2ebuild_2equery_2ebrokenSymbol_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2ebrokenSymbol_clo;
V g_heff_2ebuild_2equery_2ecatMaybesQ(V);
V g_heff_2ebuild_2equery_2ecatMaybesQ_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2ecatMaybesQ_clo;
V g_heff_2ebuild_2equery_2ecatMaybesQ_24dps(V, V);
V g_heff_2ebuild_2equery_2ecatMaybesQ_24dps_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2ecatMaybesQ_24dps_clo;
V g_heff_2ebuild_2equery_2ecommentAbove(V, V, V);
V g_heff_2ebuild_2equery_2ecommentAbove_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2ecommentAbove_clo;
V g_heff_2ebuild_2equery_2ecompletionDetail(V, V);
V g_heff_2ebuild_2equery_2ecompletionDetail_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2ecompletionDetail_clo;
V g_heff_2ebuild_2equery_2ecompletionOf(V, V, V, V);
V g_heff_2ebuild_2equery_2ecompletionOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2ecompletionOf_clo;
V g_heff_2ebuild_2equery_2ecompletionsAt(V, V);
V g_heff_2ebuild_2equery_2ecompletionsAt_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2ecompletionsAt_clo;
V g_heff_2ebuild_2equery_2edeclSites(V, V);
V g_heff_2ebuild_2equery_2edeclSites_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2edeclSites_clo;
V g_heff_2ebuild_2equery_2edefinesGo(V, V, V, V);
V g_heff_2ebuild_2equery_2edefinesGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2edefinesGo_clo;
V g_heff_2ebuild_2equery_2edefinitionAt(V, V);
V g_heff_2ebuild_2equery_2edefinitionAt_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2edefinitionAt_clo;
V g_heff_2ebuild_2equery_2edefinitionIn(V, V, V);
V g_heff_2ebuild_2equery_2edefinitionIn_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2edefinitionIn_clo;
V g_heff_2ebuild_2equery_2edocMarkdown(V);
V g_heff_2ebuild_2equery_2edocMarkdown_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2edocMarkdown_clo;
V g_heff_2ebuild_2equery_2edocMdStep(V, V);
V g_heff_2ebuild_2equery_2edocMdStep_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2edocMdStep_clo;
V g_heff_2ebuild_2equery_2eeqTarget(V, V);
V g_heff_2ebuild_2equery_2eeqTarget_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2eeqTarget_clo;
V g_heff_2ebuild_2equery_2eexpectedFits(V, V, V, V);
V g_heff_2ebuild_2equery_2eexpectedFits_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2eexpectedFits_clo;
V g_heff_2ebuild_2equery_2eexpectedIn(V, V, V);
V g_heff_2ebuild_2equery_2eexpectedIn_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2eexpectedIn_clo;
V g_heff_2ebuild_2equery_2eexplain(V);
V g_heff_2ebuild_2equery_2eexplain_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2eexplain_clo;
V g_heff_2ebuild_2equery_2efieldFound(V, V, V, V);
V g_heff_2ebuild_2equery_2efieldFound_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2efieldFound_clo;
V g_heff_2ebuild_2equery_2efixityWords(V, V);
V g_heff_2ebuild_2equery_2efixityWords_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2efixityWords_clo;
V g_heff_2ebuild_2equery_2einFileFound(V, V, V, V, V);
V g_heff_2ebuild_2equery_2einFileFound_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2einFileFound_clo;
V g_heff_2ebuild_2equery_2einFileSites(V, V, V, V);
V g_heff_2ebuild_2equery_2einFileSites_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2einFileSites_clo;
V g_heff_2ebuild_2equery_2einStringGo(V, V, V, V);
V g_heff_2ebuild_2equery_2einStringGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2einStringGo_clo;
V g_heff_2ebuild_2equery_2eisLabelAt(V, V, V);
V g_heff_2ebuild_2equery_2eisLabelAt_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2eisLabelAt_clo;
V g_heff_2ebuild_2equery_2eisNameChar(V);
V g_heff_2ebuild_2equery_2eisNameChar_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2eisNameChar_clo;
V g_heff_2ebuild_2equery_2eisTypedChar(V);
V g_heff_2ebuild_2equery_2eisTypedChar_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2eisTypedChar_clo;
V g_heff_2ebuild_2equery_2elastDot(V, V);
V g_heff_2ebuild_2equery_2elastDot_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2elastDot_clo;
V g_heff_2ebuild_2equery_2elineStartOf(V, V);
V g_heff_2ebuild_2equery_2elineStartOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2elineStartOf_clo;
V g_heff_2ebuild_2equery_2elocalDeclF_24s1801777056x609367408(V);
V g_heff_2ebuild_2equery_2elocalDeclF_24s1801777056x609367408_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2elocalDeclF_24s1801777056x609367408_clo;
V g_heff_2ebuild_2equery_2elocalFound(V, V, V);
V g_heff_2ebuild_2equery_2elocalFound_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2elocalFound_clo;
V g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(V);
V g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211_clo;
V g_heff_2ebuild_2equery_2emoreIn(V, V, V);
V g_heff_2ebuild_2equery_2emoreIn_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2emoreIn_clo;
V g_heff_2ebuild_2equery_2enameClass(V);
V g_heff_2ebuild_2equery_2enameClass_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2enameClass_clo;
V g_heff_2ebuild_2equery_2enameInGo(V, V, V, V);
V g_heff_2ebuild_2equery_2enameInGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2enameInGo_clo;
V g_heff_2ebuild_2equery_2enubByStart(V);
V g_heff_2ebuild_2equery_2enubByStart_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2enubByStart_clo;
V g_heff_2ebuild_2equery_2enubByStart_24dps(V, V);
V g_heff_2ebuild_2equery_2enubByStart_24dps_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2enubByStart_24dps_clo;
V g_heff_2ebuild_2equery_2eoccurrences(V, V, V);
V g_heff_2ebuild_2equery_2eoccurrences_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2eoccurrences_clo;
V g_heff_2ebuild_2equery_2eownNameOf(V, V);
V g_heff_2ebuild_2equery_2eownNameOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2eownNameOf_clo;
V g_heff_2ebuild_2equery_2epunctuation(V);
V g_heff_2ebuild_2equery_2epunctuation_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2epunctuation_clo;
V g_heff_2ebuild_2equery_2erenameRefused(V, V, V);
V g_heff_2ebuild_2equery_2erenameRefused_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2erenameRefused_clo;
V g_heff_2ebuild_2equery_2esiteFound(V, V, V);
V g_heff_2ebuild_2equery_2esiteFound_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2esiteFound_clo;
V g_heff_2ebuild_2equery_2espacesBefore(V, V);
V g_heff_2ebuild_2equery_2espacesBefore_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2espacesBefore_clo;
V g_heff_2ebuild_2equery_2espacesFrom(V, V);
V g_heff_2ebuild_2equery_2espacesFrom_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2espacesFrom_clo;
V g_heff_2ebuild_2equery_2esumTags(V);
V g_heff_2ebuild_2equery_2esumTags_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2esumTags_clo;
V g_heff_2ebuild_2equery_2esymbolWith(V, V, V, V);
V g_heff_2ebuild_2equery_2esymbolWith_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2esymbolWith_clo;
V g_heff_2ebuild_2equery_2esymbols(V);
V g_heff_2ebuild_2equery_2esymbols_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2esymbols_clo;
V g_heff_2ebuild_2equery_2esymbolsGo(V, V, V, V);
V g_heff_2ebuild_2equery_2esymbolsGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2esymbolsGo_clo;
V g_heff_2ebuild_2equery_2esymbolsGo_24dps(V, V, V, V, V);
V g_heff_2ebuild_2equery_2esymbolsGo_24dps_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2esymbolsGo_24dps_clo;
V g_heff_2ebuild_2equery_2etargetIn(V, V, V, V);
V g_heff_2ebuild_2equery_2etargetIn_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2etargetIn_clo;
V g_heff_2ebuild_2equery_2etypeAt(V, V);
V g_heff_2ebuild_2equery_2etypeAt_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2etypeAt_clo;
V g_heff_2ebuild_2equery_2etypedFrom(V, V);
V g_heff_2ebuild_2equery_2etypedFrom_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2etypedFrom_clo;
V g_heff_2ebuild_2equery_2euseOf(V, V, V);
V g_heff_2ebuild_2equery_2euseOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2euseOf_clo;
V g_heff_2ebuild_2equery_2ewordAt(V, V, V);
V g_heff_2ebuild_2equery_2ewordAt_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2ewordAt_clo;
V g_heff_2ebuild_2equery_2ewordsIn(V, V, V, V, V, V);
V g_heff_2ebuild_2equery_2ewordsIn_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2ewordsIn_clo;
V g_heff_2ebuild_2equery_2ewordsOf(V, V, V, V);
V g_heff_2ebuild_2equery_2ewordsOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2equery_2ewordsOf_clo;
V g_heff_2eelab_2elocals_2elocalsOf(V);
V g_heff_2eelab_2elocals_2elocalsOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2elocals_2elocalsOf_clo;
V g_heff_2eelab_2elocals_2enone_get(void);
V g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(V, V);
V g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276_entry(V self, V *a);
extern Clo g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276_clo;
V g_heff_2elsp_2erender_2elineColAt(V, V, V, V, V);
V g_heff_2elsp_2erender_2elineColAt_entry(V self, V *a);
extern Clo g_heff_2elsp_2erender_2elineColAt_clo;
V g_heff_2esyntax_2esurfaceprint_2enamed(V);
V g_heff_2esyntax_2esurfaceprint_2enamed_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2enamed_clo;
V g_list_2eany_24s1711939327x1502975912(V, V);
V g_list_2eany_24s1711939327x1502975912_entry(V self, V *a);
extern Clo g_list_2eany_24s1711939327x1502975912_clo;
V g_list_2eany_24s406396256x713021373(V, V);
V g_list_2eany_24s406396256x713021373_entry(V self, V *a);
extern Clo g_list_2eany_24s406396256x713021373_clo;
V g_list_2eany_24s430343851x1474283355(V, V);
V g_list_2eany_24s430343851x1474283355_entry(V self, V *a);
extern Clo g_list_2eany_24s430343851x1474283355_clo;
V g_list_2efilter(V, V);
V g_list_2efilter_entry(V self, V *a);
extern Clo g_list_2efilter_clo;
V g_list_2efilter_24s1109331425x852844386(V, V, V);
V g_list_2efilter_24s1109331425x852844386_entry(V self, V *a);
extern Clo g_list_2efilter_24s1109331425x852844386_clo;
V g_list_2efilter_24s1716878720x675187502(V, V);
V g_list_2efilter_24s1716878720x675187502_entry(V self, V *a);
extern Clo g_list_2efilter_24s1716878720x675187502_clo;
V g_list_2efilter_24s1771067298x678756798(V, V);
V g_list_2efilter_24s1771067298x678756798_entry(V self, V *a);
extern Clo g_list_2efilter_24s1771067298x678756798_clo;
V g_list_2efilter_24s343483820x881052984(V, V);
V g_list_2efilter_24s343483820x881052984_entry(V self, V *a);
extern Clo g_list_2efilter_24s343483820x881052984_clo;
V g_list_2efind(V, V);
V g_list_2efind_entry(V self, V *a);
extern Clo g_list_2efind_clo;
V g_list_2efind_24s1085725546x1737150855(V, V);
V g_list_2efind_24s1085725546x1737150855_entry(V self, V *a);
extern Clo g_list_2efind_24s1085725546x1737150855_clo;
V g_list_2efind_24s1184231137x30317987(V, V);
V g_list_2efind_24s1184231137x30317987_entry(V self, V *a);
extern Clo g_list_2efind_24s1184231137x30317987_clo;
V g_list_2efind_24s1702704581x1717241719(V);
V g_list_2efind_24s1702704581x1717241719_entry(V self, V *a);
extern Clo g_list_2efind_24s1702704581x1717241719_clo;
V g_list_2efind_24s358915833x209356919(V, V);
V g_list_2efind_24s358915833x209356919_entry(V self, V *a);
extern Clo g_list_2efind_24s358915833x209356919_clo;
V g_list_2efind_24s361650052x1432786508(V, V);
V g_list_2efind_24s361650052x1432786508_entry(V self, V *a);
extern Clo g_list_2efind_24s361650052x1432786508_clo;
V g_list_2efind_24s582687515x818787580(V, V);
V g_list_2efind_24s582687515x818787580_entry(V self, V *a);
extern Clo g_list_2efind_24s582687515x818787580_clo;
V g_list_2efind_24s924148649x7864569(V, V);
V g_list_2efind_24s924148649x7864569_entry(V self, V *a);
extern Clo g_list_2efind_24s924148649x7864569_clo;
V g_list_2efind_24s988189774x1593035904(V, V);
V g_list_2efind_24s988189774x1593035904_entry(V self, V *a);
extern Clo g_list_2efind_24s988189774x1593035904_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24f297647854x479783049(V, V);
V g_list_2efoldl_24f297647854x479783049_entry(V self, V *a);
extern Clo g_list_2efoldl_24f297647854x479783049_clo;
V g_list_2efoldl_24f765463553x1160475073(V, V, V, V, V, V, V);
V g_list_2efoldl_24f765463553x1160475073_entry(V self, V *a);
extern Clo g_list_2efoldl_24f765463553x1160475073_clo;
V g_list_2efoldl_24s1026998256x1634433314(V, V);
V g_list_2efoldl_24s1026998256x1634433314_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1026998256x1634433314_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1472875662x470242985(V, V);
V g_list_2efoldl_24s1472875662x470242985_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1472875662x470242985_clo;
V g_list_2efoldl_24s1516272141x1201056882(V, V, V);
V g_list_2efoldl_24s1516272141x1201056882_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1516272141x1201056882_clo;
V g_list_2efoldl_24s1620243413x998711352(V, V);
V g_list_2efoldl_24s1620243413x998711352_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1620243413x998711352_clo;
V g_list_2efoldl_24s1777318809x1106245647(V, V);
V g_list_2efoldl_24s1777318809x1106245647_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1777318809x1106245647_clo;
V g_list_2efoldl_24s189033563x26633104(V, V);
V g_list_2efoldl_24s189033563x26633104_entry(V self, V *a);
extern Clo g_list_2efoldl_24s189033563x26633104_clo;
V g_list_2efoldl_24s1975553568x1034350329(V, V);
V g_list_2efoldl_24s1975553568x1034350329_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1975553568x1034350329_clo;
V g_list_2efoldl_24s2134067310x2049132013(V, V);
V g_list_2efoldl_24s2134067310x2049132013_entry(V self, V *a);
extern Clo g_list_2efoldl_24s2134067310x2049132013_clo;
V g_list_2efoldl_24s302194196x751324068(V, V);
V g_list_2efoldl_24s302194196x751324068_entry(V self, V *a);
extern Clo g_list_2efoldl_24s302194196x751324068_clo;
V g_list_2efoldl_24s44351024x1408738471(V, V);
V g_list_2efoldl_24s44351024x1408738471_entry(V self, V *a);
extern Clo g_list_2efoldl_24s44351024x1408738471_clo;
V g_list_2efoldl_24s491084544x100802329(V, V);
V g_list_2efoldl_24s491084544x100802329_entry(V self, V *a);
extern Clo g_list_2efoldl_24s491084544x100802329_clo;
V g_list_2efoldl_24s496727651x1448898893(V, V);
V g_list_2efoldl_24s496727651x1448898893_entry(V self, V *a);
extern Clo g_list_2efoldl_24s496727651x1448898893_clo;
V g_list_2efoldl_24s54159557x1528472185(V, V);
V g_list_2efoldl_24s54159557x1528472185_entry(V self, V *a);
extern Clo g_list_2efoldl_24s54159557x1528472185_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24f1451184245x2111935062(V, V, V, V, V, V, V);
V g_list_2emap_24f1451184245x2111935062_entry(V self, V *a);
extern Clo g_list_2emap_24f1451184245x2111935062_clo;
V g_list_2emap_24f2063070488x1806431062(V, V);
V g_list_2emap_24f2063070488x1806431062_entry(V self, V *a);
extern Clo g_list_2emap_24f2063070488x1806431062_clo;
V g_list_2emap_24f990982947x2126256822(V, V);
V g_list_2emap_24f990982947x2126256822_entry(V self, V *a);
extern Clo g_list_2emap_24f990982947x2126256822_clo;
V g_list_2emap_24s1004924153x684987219(V, V, V);
V g_list_2emap_24s1004924153x684987219_entry(V self, V *a);
extern Clo g_list_2emap_24s1004924153x684987219_clo;
V g_list_2emap_24s1266088736x105832553(V, V);
V g_list_2emap_24s1266088736x105832553_entry(V self, V *a);
extern Clo g_list_2emap_24s1266088736x105832553_clo;
V g_list_2emap_24s1415906091x1371825187(V);
V g_list_2emap_24s1415906091x1371825187_entry(V self, V *a);
extern Clo g_list_2emap_24s1415906091x1371825187_clo;
V g_list_2emap_24s1675313341x192238134(V);
V g_list_2emap_24s1675313341x192238134_entry(V self, V *a);
extern Clo g_list_2emap_24s1675313341x192238134_clo;
V g_list_2emap_24s1721231741x1085491812(V);
V g_list_2emap_24s1721231741x1085491812_entry(V self, V *a);
extern Clo g_list_2emap_24s1721231741x1085491812_clo;
V g_list_2emap_24s173442543x1801751270(V);
V g_list_2emap_24s173442543x1801751270_entry(V self, V *a);
extern Clo g_list_2emap_24s173442543x1801751270_clo;
V g_list_2emap_24s1817753698x509594538(V, V, V);
V g_list_2emap_24s1817753698x509594538_entry(V self, V *a);
extern Clo g_list_2emap_24s1817753698x509594538_clo;
V g_list_2emap_24s2000102784x314586828(V);
V g_list_2emap_24s2000102784x314586828_entry(V self, V *a);
extern Clo g_list_2emap_24s2000102784x314586828_clo;
V g_list_2emap_24s388004800x1261967008(V);
V g_list_2emap_24s388004800x1261967008_entry(V self, V *a);
extern Clo g_list_2emap_24s388004800x1261967008_clo;
V g_list_2emap_24s467798769x1763085075(V);
V g_list_2emap_24s467798769x1763085075_entry(V self, V *a);
extern Clo g_list_2emap_24s467798769x1763085075_clo;
V g_list_2esortBy_24s1223185427x423554351(V);
V g_list_2esortBy_24s1223185427x423554351_entry(V self, V *a);
extern Clo g_list_2esortBy_24s1223185427x423554351_clo;
V g_list_2esortBy_24s1230002843x105774350(V);
V g_list_2esortBy_24s1230002843x105774350_entry(V self, V *a);
extern Clo g_list_2esortBy_24s1230002843x105774350_clo;
V g_list_2esortBy_24s1681607803x465385494(V);
V g_list_2esortBy_24s1681607803x465385494_entry(V self, V *a);
extern Clo g_list_2esortBy_24s1681607803x465385494_clo;
V g_list_2esortBy_24s1768199906x1695529242(V);
V g_list_2esortBy_24s1768199906x1695529242_entry(V self, V *a);
extern Clo g_list_2esortBy_24s1768199906x1695529242_clo;
V g_map_2elookup_24s1546226666x2146984184(V, V);
V g_map_2elookup_24s1546226666x2146984184_entry(V self, V *a);
extern Clo g_map_2elookup_24s1546226666x2146984184_clo;
V g_map_2etoListOnto(V, V);
V g_map_2etoListOnto_entry(V self, V *a);
extern Clo g_map_2etoListOnto_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2eskipSpaces(V, V, V);
V g_prelude_2eskipSpaces_entry(V self, V *a);
extern Clo g_prelude_2eskipSpaces_clo;
V g_prelude_2estrFind(V, V, V);
V g_prelude_2estrFind_entry(V self, V *a);
extern Clo g_prelude_2estrFind_clo;
Clo g_heff_2ebuild_2equery_2ecatMaybesQ_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2ecatMaybesQ_entry, 1, 0};

V g_heff_2ebuild_2equery_2ecatMaybesQ(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Just: {
      V v_x_243 = heff_field(v_x11_241, 0);
      heff_take_n(v_x11_241, 1ULL, 1);
      V v_cell_244 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
      V v_u_245 = (g_heff_2ebuild_2equery_2ecatMaybesQ_24dps(v_rest_242, heff_dup(v_cell_244)));
      heff_drop(v_u_245);
      return v_cell_244;
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2equery_2ecatMaybesQ_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2equery_2ecatMaybesQ(a[0]);
}
Clo g_heff_2ebuild_2equery_2ecatMaybesQ_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2ecatMaybesQ_24dps_entry, 2, 0};

V g_heff_2ebuild_2equery_2ecatMaybesQ_24dps(V v_x1_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x11_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_243;
      V t_1 = v_d_241;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_Just: {
      V v_x_244 = heff_field(v_x11_242, 0);
      heff_take_n(v_x11_242, 1ULL, 1);
      V v_cell_245 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_244, heff_hole()});
      V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
      heff_drop(v_u_246);
      V t_0 = v_rest_243;
      V t_1 = v_cell_245;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_x11_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2equery_2ecatMaybesQ_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2equery_2ecatMaybesQ_24dps(a[0], a[1]);
}
Clo g_heff_2ebuild_2equery_2eisNameChar_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2eisNameChar_entry, 1, 0};

V g_heff_2ebuild_2equery_2eisNameChar(V v_c_240) {
top: ;
  V v_ret_24bool = heff_bool((heff_intEq_c(heff_dup(v_c_240), MK_INT(95LL)) || (heff_intEq_c(heff_dup(v_c_240), MK_INT(39LL)) || (heff_intEq_c(heff_dup(v_c_240), MK_INT(47LL)) || (heff_intLe_c(MK_INT(97LL), heff_dup(v_c_240)) ? (heff_intLe_c(heff_dup(v_c_240), MK_INT(122LL)) || (heff_intLe_c(MK_INT(65LL), heff_dup(v_c_240)) ? (heff_intLe_c(heff_dup(v_c_240), MK_INT(90LL)) || (heff_intLe_c(MK_INT(48LL), heff_dup(v_c_240)) && heff_intLe_c(heff_dup(v_c_240), MK_INT(57LL)))) : (heff_intLe_c(MK_INT(48LL), heff_dup(v_c_240)) && heff_intLe_c(heff_dup(v_c_240), MK_INT(57LL))))) : (heff_intLe_c(MK_INT(65LL), heff_dup(v_c_240)) ? (heff_intLe_c(heff_dup(v_c_240), MK_INT(90LL)) || (heff_intLe_c(MK_INT(48LL), heff_dup(v_c_240)) && heff_intLe_c(heff_dup(v_c_240), MK_INT(57LL)))) : (heff_intLe_c(MK_INT(48LL), heff_dup(v_c_240)) && heff_intLe_c(heff_dup(v_c_240), MK_INT(57LL)))))))));
  heff_drop(v_c_240);
  return v_ret_24bool;
}
V g_heff_2ebuild_2equery_2eisNameChar_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2equery_2eisNameChar(a[0]);
}
Clo g_heff_2ebuild_2equery_2ewordAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2ewordAt_entry, 3, 0};

V g_heff_2ebuild_2equery_2ewordAt(V v_src_240, V v_p_241, V v_x_242) {
top: ;
  V v_ret_24bool = heff_bool((heff_intEq_c(heff_dup(v_p_241), MK_INT(0LL)) ? ({ V v_t_244 = heff_intAdd(heff_dup(v_p_241), heff_strLength_lent(v_x_242, 0)); int c_ = ({ V v_x1_245 = (g_heff_2ebuild_2equery_2eisNameChar(heff_strByteAt_lent(v_src_240, v_t_244, 0))); int c_ = !(heff_dup(v_x1_245) == NTAG(TAG_True)); heff_drop(v_x1_245); c_; }); heff_drop(v_t_244); c_; }) : ({ V v_t_246 = heff_strByteAt(heff_dup(v_src_240), heff_intSub(heff_dup(v_p_241), MK_INT(1LL))); int c_ = ({ V v_x1_247 = (g_heff_2ebuild_2equery_2eisNameChar(heff_dup(v_t_246))); int c_ = ((heff_dup(v_x1_247) == NTAG(TAG_True)) ? 0 : ({ V v_t_248 = heff_intAdd(heff_dup(v_p_241), heff_strLength_lent(v_x_242, 0)); int c_ = ({ V v_x1_249 = (g_heff_2ebuild_2equery_2eisNameChar(heff_strByteAt_lent(v_src_240, v_t_248, 0))); int c_ = !(heff_dup(v_x1_249) == NTAG(TAG_True)); heff_drop(v_x1_249); c_; }); heff_drop(v_t_248); c_; })); heff_drop(v_x1_247); c_; }); heff_drop(v_t_246); c_; })));
  heff_drop(v_src_240);
  heff_drop(v_p_241);
  heff_drop(v_x_242);
  return v_ret_24bool;
}
V g_heff_2ebuild_2equery_2ewordAt_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2equery_2ewordAt(a[0], a[1], a[2]);
}
Clo g_heff_2ebuild_2equery_2enameInGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2enameInGo_entry, 4, 0};

V g_heff_2ebuild_2equery_2enameInGo(V v_src_240, V v_x_241, V v_sp_242, V v_from_243) {
top: ;
  V v_j_244 = (g_prelude_2estrFind(heff_dup(v_x_241), heff_dup(v_src_240), v_from_243));
  if (heff_intLt_c(heff_dup(v_j_244), MK_INT(0LL))) {
    heff_drop(v_src_240);
    heff_drop(v_x_241);
    heff_drop(v_j_244);
    return v_sp_242;
  } else {
    V v_t_246 = heff_intAdd(heff_dup(v_j_244), heff_strLength_lent(v_x_241, 0));
    if (heff_intLe_c(v_t_246, heff_dup(heff_rfield(v_sp_242, 1)))) {
      V v_t_248 = (g_heff_2ebuild_2equery_2ewordAt(heff_dup(v_src_240), heff_dup(v_j_244), heff_dup(v_x_241)));
      if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
        heff_drop(v_src_240);
        heff_drop_rec(v_sp_242, 2);
        heff_drop(v_t_248);
        V v_t_249 = heff_intAdd(heff_dup(v_j_244), heff_strLength(v_x_241));
        return heff_rec_n(2, shape_start__end, (V[]){v_j_244, v_t_249});
      } else {
        heff_drop(v_t_248);
        V t_0 = v_src_240;
        V t_1 = v_x_241;
        V t_2 = v_sp_242;
        V t_3 = heff_intAdd(v_j_244, MK_INT(1LL));
        v_src_240 = t_0;
        v_x_241 = t_1;
        v_sp_242 = t_2;
        v_from_243 = t_3;
        goto top;
      }
    } else {
      heff_drop(v_src_240);
      heff_drop(v_x_241);
      heff_drop(v_j_244);
      return v_sp_242;
    }
  }
}
V g_heff_2ebuild_2equery_2enameInGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2equery_2enameInGo(a[0], a[1], a[2], a[3]);
}
Clo g_heff_2ebuild_2equery_2enubByStart_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2enubByStart_entry, 1, 0};

V g_heff_2ebuild_2equery_2enubByStart(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x1_240, 0);
    V v_xs_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_cell_243 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_x_241), heff_hole()});
    V v_t_244 = (g_list_2efilter_24s1771067298x678756798(v_x_241, v_xs_242));
    V v_u_245 = (g_heff_2ebuild_2equery_2enubByStart_24dps(v_t_244, heff_dup(v_cell_243)));
    heff_drop(v_u_245);
    return v_cell_243;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2equery_2enubByStart_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2equery_2enubByStart(a[0]);
}
Clo g_heff_2ebuild_2equery_2enubByStart_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2enubByStart_24dps_entry, 2, 0};

V g_heff_2ebuild_2equery_2enubByStart_24dps(V v_x1_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_x_242), heff_hole()});
    V v_u_245 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_244));
    heff_drop(v_u_245);
    V v_t_246 = (g_list_2efilter_24s1771067298x678756798(v_x_242, v_xs_243));
    V t_0 = v_t_246;
    V t_1 = v_cell_244;
    v_x1_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2equery_2enubByStart_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2equery_2enubByStart_24dps(a[0], a[1]);
}
HEFF_LIT(g_heff_2ebuild_2equery_2eatLine_str0, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2equery_2eatLine_str1, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2equery_2eatLine_str2, 1, ":");
Clo g_heff_2ebuild_2equery_2eatLine_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2eatLine_entry, 2, 0};

V g_heff_2ebuild_2equery_2eatLine(V v_src_240, V v_sp_241) {
top: ;
  V v_j_242 = (g_prelude_2estrFind(((V)&g_heff_2ebuild_2equery_2eatLine_str0), heff_dup(v_src_240), MK_INT(0LL)));
  V v_t_244;
  if (heff_intLt_c(heff_dup(v_j_242), MK_INT(0LL))) {
    heff_drop(v_j_242);
    v_t_244 = NTAG(TAG_Nothing);
  } else {
    v_t_244 = heff_tag_n(TAG_Just, 1, (V[]){v_j_242});
  }
  V v_t_245 = (g_heff_2elsp_2erender_2elineColAt(heff_dup(v_src_240), heff_dup(heff_rfield(v_sp_241, 0)), MK_INT(0LL), MK_INT(0LL), v_t_244));
  V v_t_246 = heff_intAdd(heff_get_n(v_t_245, 0, 3), MK_INT(1LL));
  V v_j_247 = (g_prelude_2estrFind(((V)&g_heff_2ebuild_2equery_2eatLine_str1), heff_dup(v_src_240), MK_INT(0LL)));
  V v_t_249;
  if (heff_intLt_c(heff_dup(v_j_247), MK_INT(0LL))) {
    heff_drop(v_j_247);
    v_t_249 = NTAG(TAG_Nothing);
  } else {
    v_t_249 = heff_tag_n(TAG_Just, 1, (V[]){v_j_247});
  }
  V v_t_2410 = (g_heff_2elsp_2erender_2elineColAt(v_src_240, heff_get_n(v_sp_241, 0, 2), MK_INT(0LL), MK_INT(0LL), v_t_249));
  V v_t_2411 = heff_intAdd(heff_get_n(v_t_2410, 2, 3), MK_INT(1LL));
  V v_t_2412 = heff_strAppend(((V)&g_heff_2ebuild_2equery_2eatLine_str2), heff_intShow(v_t_2411));
  return heff_strAppend(heff_intShow(v_t_246), v_t_2412);
}
V g_heff_2ebuild_2equery_2eatLine_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2equery_2eatLine(a[0], a[1]);
}
HEFF_LIT(g_heff_2ebuild_2equery_2eexplain_str0, 2, "  ");
HEFF_LIT(g_heff_2ebuild_2equery_2eexplain_str1, 2, "  ");
HEFF_LIT(g_heff_2ebuild_2equery_2eexplain_str2, 5, "error");
HEFF_LIT(g_heff_2ebuild_2equery_2eexplain_str3, 7, "warning");
HEFF_LIT(g_heff_2ebuild_2equery_2eexplain_str4, 5, "debug");
HEFF_LIT(g_heff_2ebuild_2equery_2eexplain_str5, 2, "  ");
HEFF_LIT(g_heff_2ebuild_2equery_2eexplain_str6, 2, "  ");
V g_heff_2ebuild_2equery_2eexplain_lam0(V self, V *args);
V g_heff_2ebuild_2equery_2eexplain_lam1(V self, V *args);
Clo g_heff_2ebuild_2equery_2eexplain_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2eexplain_entry, 1, 0};

V g_heff_2ebuild_2equery_2eexplain(V v_c_240) {
top: ;
  V v_t_241 = heff_get_n(heff_dup(heff_rfield(v_c_240, 5)), 8, 9);
  V v_t_246 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2equery_2eexplain_lam0, 1, 1, (V[]){heff_dup(v_c_240)}), v_t_241));
  V v_t_2413 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2equery_2eexplain_lam1, 1, 1, (V[]){heff_dup(v_c_240)}), heff_get_n(v_c_240, 6, 13)));
  return (g_prelude_2e_2b_2b(v_t_246, v_t_2413));
}
V g_heff_2ebuild_2equery_2eexplain_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2equery_2eexplain(a[0]);
}
V g_heff_2ebuild_2equery_2eexplain_lam0(V self, V *args) {
  V v_ev_242 = args[0];
  V v_c_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_243 = (g_heff_2ebuild_2equery_2eatLine(heff_get_n(v_c_240, 3, 13), heff_take_field(v_ev_242, 0)));
  V v_t_244 = heff_tr(heff_call(heff_take_field(v_ev_242, 2), 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_t_245 = heff_strAppend(heff_get_n(v_ev_242, 1, 3), heff_strAppend(((V)&g_heff_2ebuild_2equery_2eexplain_str0), v_t_244));
  return heff_strAppend(v_t_243, heff_strAppend(((V)&g_heff_2ebuild_2equery_2eexplain_str1), v_t_245));
}
V g_heff_2ebuild_2equery_2eexplain_lam1(V self, V *args) {
  V v_d_247 = args[0];
  V v_c_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_248 = (g_heff_2ebuild_2equery_2eatLine(heff_get_n(v_c_240, 3, 13), heff_take_field(v_d_247, 3)));
  V v_t_249 = heff_take_field(v_d_247, 1);
  V v_t_2410;
  switch (heff_tag_of(v_t_249)) {
  case TAG_SError: {
    v_t_2410 = ((V)&g_heff_2ebuild_2equery_2eexplain_str2);
    break;
  }
  case TAG_SWarning: {
    v_t_2410 = ((V)&g_heff_2ebuild_2equery_2eexplain_str3);
    break;
  }
  case TAG_SDebug: {
    v_t_2410 = ((V)&g_heff_2ebuild_2equery_2eexplain_str4);
    break;
  }
  default: heff_nomatch(v_t_249);
  }
  V v_t_2411 = heff_strAppend(((V)&g_heff_2ebuild_2equery_2eexplain_str5), heff_get_n(v_d_247, 2, 5));
  V v_t_2412 = heff_strAppend(((V)&g_heff_2ebuild_2equery_2eexplain_str6), heff_strAppend(v_t_2410, v_t_2411));
  return heff_strAppend(v_t_248, v_t_2412);
}
HEFF_LIT(g_heff_2ebuild_2equery_2etypeAt_str0, 10, "   (local)");
HEFF_LIT(g_heff_2ebuild_2equery_2etypeAt_str1, 11, "   (global)");
HEFF_LIT(g_heff_2ebuild_2equery_2etypeAt_str2, 3, " : ");
Clo g_heff_2ebuild_2equery_2etypeAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2etypeAt_entry, 2, 0};

V g_heff_2ebuild_2equery_2etypeAt(V v_c_240, V v_off_241) {
top: ;
  V v_t_242 = heff_get_n(heff_get_n(v_c_240, 5, 13), 7, 9);
  V v_t_243 = (g_list_2efilter_24s1109331425x852844386(MK_INT(1LL), v_off_241, v_t_242));
  V v_x1_244 = (g_list_2esortBy_24s1681607803x465385494(v_t_243));
  switch (heff_tag_of(v_x1_244)) {
  case TAG_Nil: {
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x1_244, 0);
    heff_take_n(v_x1_244, 1ULL, 2);
    V v_t_247 = (g_heff_2esyntax_2esurfaceprint_2enamed(heff_take_field(v_x_245, 1)));
    V v_t_248 = heff_tr(heff_call(heff_take_field(v_x_245, 4), 1, (V[]){NTAG(TAG_MkUnit)}));
    V v_t_249 = heff_get_n(v_x_245, 2, 5);
    V v_t_2411;
    switch (heff_tag_of(v_t_249)) {
    case TAG_Nothing: {
      v_t_2411 = ((V)&g_heff_2ebuild_2equery_2etypeAt_str0);
      break;
    }
    case TAG_Just: {
      heff_take_n(v_t_249, 0ULL, 1);
      v_t_2411 = ((V)&g_heff_2ebuild_2equery_2etypeAt_str1);
      break;
    }
    default: heff_nomatch(v_t_249);
    }
    V v_t_2412 = heff_strAppend(((V)&g_heff_2ebuild_2equery_2etypeAt_str2), heff_strAppend(v_t_248, v_t_2411));
    return heff_tag_n(TAG_Just, 1, (V[]){heff_strAppend(v_t_247, v_t_2412)});
  }
  default: return heff_nomatch(v_x1_244);
  }
}
V g_heff_2ebuild_2equery_2etypeAt_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2equery_2etypeAt(a[0], a[1]);
}
Clo g_heff_2ebuild_2equery_2eisTypedChar_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2eisTypedChar_entry, 1, 0};

V g_heff_2ebuild_2equery_2eisTypedChar(V v_c_240) {
top: ;
  V v_ret_24bool = heff_bool((heff_intEq_c(heff_dup(v_c_240), MK_INT(95LL)) || (heff_intEq_c(heff_dup(v_c_240), MK_INT(39LL)) || (heff_intEq_c(heff_dup(v_c_240), MK_INT(46LL)) || (heff_intLe_c(MK_INT(97LL), heff_dup(v_c_240)) ? (heff_intLe_c(heff_dup(v_c_240), MK_INT(122LL)) || (heff_intLe_c(MK_INT(65LL), heff_dup(v_c_240)) ? (heff_intLe_c(heff_dup(v_c_240), MK_INT(90LL)) || (heff_intLe_c(MK_INT(48LL), heff_dup(v_c_240)) && heff_intLe_c(heff_dup(v_c_240), MK_INT(57LL)))) : (heff_intLe_c(MK_INT(48LL), heff_dup(v_c_240)) && heff_intLe_c(heff_dup(v_c_240), MK_INT(57LL))))) : (heff_intLe_c(MK_INT(65LL), heff_dup(v_c_240)) ? (heff_intLe_c(heff_dup(v_c_240), MK_INT(90LL)) || (heff_intLe_c(MK_INT(48LL), heff_dup(v_c_240)) && heff_intLe_c(heff_dup(v_c_240), MK_INT(57LL)))) : (heff_intLe_c(MK_INT(48LL), heff_dup(v_c_240)) && heff_intLe_c(heff_dup(v_c_240), MK_INT(57LL)))))))));
  heff_drop(v_c_240);
  return v_ret_24bool;
}
V g_heff_2ebuild_2equery_2eisTypedChar_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2equery_2eisTypedChar(a[0]);
}
Clo g_heff_2ebuild_2equery_2etypedFrom_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2etypedFrom_entry, 2, 0};

V g_heff_2ebuild_2equery_2etypedFrom(V v_src_240, V v_i_241) {
top: ;
  if (heff_intLt_c(MK_INT(0LL), heff_dup(v_i_241))) {
    V v_t_243 = heff_strByteAt(heff_dup(v_src_240), heff_intSub(heff_dup(v_i_241), MK_INT(1LL)));
    V v_t_244 = (g_heff_2ebuild_2equery_2eisTypedChar(v_t_243));
    if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
      heff_drop(v_t_244);
      V t_0 = v_src_240;
      V t_1 = heff_intSub(v_i_241, MK_INT(1LL));
      v_src_240 = t_0;
      v_i_241 = t_1;
      goto top;
    } else {
      heff_drop(v_src_240);
      heff_drop(v_t_244);
      return v_i_241;
    }
  } else {
    heff_drop(v_src_240);
    return v_i_241;
  }
}
V g_heff_2ebuild_2equery_2etypedFrom_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2equery_2etypedFrom(a[0], a[1]);
}
Clo g_heff_2ebuild_2equery_2elastDot_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2elastDot_entry, 2, 0};

V g_heff_2ebuild_2equery_2elastDot(V v_s_240, V v_i_241) {
top: ;
  if (heff_intLt_c(heff_dup(v_i_241), MK_INT(0LL))) {
    heff_drop(v_s_240);
    heff_drop(v_i_241);
    return NTAG(TAG_Nothing);
  } else {
    if (heff_intEq_c(heff_strByteAt_lent(v_s_240, v_i_241, 0), MK_INT(46LL))) {
      heff_drop(v_s_240);
      return heff_tag_n(TAG_Just, 1, (V[]){v_i_241});
    } else {
      V t_0 = v_s_240;
      V t_1 = heff_intSub(v_i_241, MK_INT(1LL));
      v_s_240 = t_0;
      v_i_241 = t_1;
      goto top;
    }
  }
}
V g_heff_2ebuild_2equery_2elastDot_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2equery_2elastDot(a[0], a[1]);
}
HEFF_LIT(g_heff_2ebuild_2equery_2ecompletionDetail_str0, 1, ".");
HEFF_LIT(g_heff_2ebuild_2equery_2ecompletionDetail_str1, 0, "");
HEFF_LIT(g_heff_2ebuild_2equery_2ecompletionDetail_str2, 0, "");
Clo g_heff_2ebuild_2equery_2ecompletionDetail_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2ecompletionDetail_entry, 2, 0};

V g_heff_2ebuild_2equery_2ecompletionDetail(V v_c_240, V v_x_241) {
top: ;
  V v_g_242 = heff_get_n(heff_dup(heff_rfield(v_c_240, 5)), 0, 9);
  V v_t_243 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(v_x_241), heff_rfield(v_g_242, 2)));
  V v_t_249;
  switch (heff_tag_of(v_t_243)) {
  case TAG_Nothing: {
    V v_t_244 = ({ V a_0 = heff_dup(v_x_241); V b_1 = heff_get_n(v_g_242, 1, 7); V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, b_1)); heff_drop(b_1); r_; });
    switch (heff_tag_of(v_t_244)) {
    case TAG_Nothing: {
      v_t_249 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Just: {
      V v_e_245 = heff_field(v_t_244, 0);
      V v_ru_24t_244_24Just = heff_take_reuse_n(v_t_244, 1ULL, 1);
      v_t_249 = heff_tag_at_n(v_ru_24t_244_24Just, TAG_Just, 1, (V[]){v_e_245});
      break;
    }
    default: heff_nomatch(v_t_244);
    }
    break;
  }
  case TAG_Just: {
    V v_k_246 = heff_field(v_t_243, 0);
    V v_ru_24t_243_24Just = heff_take_reuse_n(v_t_243, 1ULL, 1);
    V v_t_247 = ({ V a_0 = v_k_246; V b_1 = heff_get_n(v_g_242, 1, 7); V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, b_1)); heff_drop(b_1); r_; });
    switch (heff_tag_of(v_t_247)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24t_243_24Just, 1);
      v_t_249 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Just: {
      V v_e_248 = heff_field(v_t_247, 0);
      heff_take_n(v_t_247, 1ULL, 1);
      v_t_249 = heff_tag_at_n(v_ru_24t_243_24Just, TAG_Just, 1, (V[]){v_e_248});
      break;
    }
    default: heff_nomatch(v_t_247);
    }
    break;
  }
  default: heff_nomatch(v_t_243);
  }
  switch (heff_tag_of(v_t_249)) {
  case TAG_Nothing: {
    V v_g_2410 = heff_get_n(heff_dup(heff_rfield(v_c_240, 5)), 0, 9);
    V v_k_2411 = heff_strAppend(heff_take_field(v_c_240, 0), heff_strAppend(((V)&g_heff_2ebuild_2equery_2ecompletionDetail_str0), v_x_241));
    V v_t_2412 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(v_k_2411), heff_rfield(v_g_2410, 1)));
    switch (heff_tag_of(v_t_2412)) {
    case TAG_Nothing: {
      V v_t_2413 = (g_map_2elookup_24s1546226666x2146984184(v_k_2411, heff_rfield(v_g_2410, 2)));
      switch (heff_tag_of(v_t_2413)) {
      case TAG_Nothing: {
        heff_drop_rec(v_c_240, 13);
        heff_drop_rec(v_g_2410, 7);
        return ((V)&g_heff_2ebuild_2equery_2ecompletionDetail_str1);
      }
      case TAG_Just: {
        V v_k2_2414 = heff_field(v_t_2413, 0);
        heff_take_n(v_t_2413, 1ULL, 1);
        V v_t_2415 = ({ V a_0 = v_k2_2414; V b_1 = heff_get_n(v_g_2410, 1, 7); V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, b_1)); heff_drop(b_1); r_; });
        switch (heff_tag_of(v_t_2415)) {
        case TAG_Nothing: {
          heff_drop_rec(v_c_240, 13);
          return ((V)&g_heff_2ebuild_2equery_2ecompletionDetail_str2);
        }
        case TAG_Just: {
          V v_e_2416 = heff_field(v_t_2415, 0);
          heff_take_n(v_t_2415, 1ULL, 1);
          V v_t_2417 = heff_get_n(heff_get_n(v_c_240, 5, 13), 0, 9);
          V v_t_2418 = (g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(MK_INT(0LL), heff_get_n(v_e_2416, 3, 4)));
          HEFF_LAST return g_heff_2ebuild_2edriver_2eshowTySx(v_t_2417, v_t_2418);
        }
        default: return heff_nomatch(v_t_2415);
        }
      }
      default: return heff_nomatch(v_t_2413);
      }
    }
    case TAG_Just: {
      V v_e_2419 = heff_field(v_t_2412, 0);
      heff_take_n(v_t_2412, 1ULL, 1);
      heff_drop_rec(v_g_2410, 7);
      heff_drop(v_k_2411);
      V v_t_2420 = heff_get_n(heff_get_n(v_c_240, 5, 13), 0, 9);
      V v_t_2421 = (g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(MK_INT(0LL), heff_get_n(v_e_2419, 3, 4)));
      HEFF_LAST return g_heff_2ebuild_2edriver_2eshowTySx(v_t_2420, v_t_2421);
    }
    default: return heff_nomatch(v_t_2412);
    }
  }
  case TAG_Just: {
    V v_e_2422 = heff_field(v_t_249, 0);
    heff_take_n(v_t_249, 1ULL, 1);
    heff_drop(v_x_241);
    V v_t_2423 = heff_get_n(heff_get_n(v_c_240, 5, 13), 0, 9);
    V v_t_2424 = (g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(MK_INT(0LL), heff_get_n(v_e_2422, 3, 4)));
    HEFF_LAST return g_heff_2ebuild_2edriver_2eshowTySx(v_t_2423, v_t_2424);
  }
  default: return heff_nomatch(v_t_249);
  }
}
V g_heff_2ebuild_2equery_2ecompletionDetail_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2equery_2ecompletionDetail(a[0], a[1]);
}
HEFF_LIT(g_heff_2ebuild_2equery_2ecompletionOf_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2equery_2ecompletionOf_str1, 1, ".");
Clo g_heff_2ebuild_2equery_2ecompletionOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2ecompletionOf_entry, 4, 0};

V g_heff_2ebuild_2equery_2ecompletionOf(V v_c_240, V v_typed_241, V v_qualifier_242, V v_x_243) {
top: ;
  V v_t_244 = heff_strSlice(heff_dup(v_x_243), MK_INT(0LL), heff_strLength_lent(v_typed_241, 0));
  if (heff_strEq_c(v_t_244, v_typed_241)) {
    if (heff_strEq_c_lent(v_qualifier_242, ((V)&g_heff_2ebuild_2equery_2ecompletionOf_str0), 2)) {
      V v_x_247 = (g_prelude_2estrFind(((V)&g_heff_2ebuild_2equery_2ecompletionOf_str1), heff_dup(v_x_243), MK_INT(0LL)));
      if (heff_intLe_c(MK_INT(0LL), v_x_247)) {
        heff_drop(v_c_240);
        heff_drop(v_qualifier_242);
        heff_drop(v_x_243);
        return NTAG(TAG_Nothing);
      } else {
        V v_t_249 = heff_strSlice(heff_dup(v_x_243), MK_INT(0LL), heff_strLength_lent(v_qualifier_242, 0));
        V v_t_2411;
        if (heff_strEq_c_lent(v_t_249, v_qualifier_242, 1)) {
          v_t_2411 = heff_strSlice(heff_dup(v_x_243), heff_strLength(v_qualifier_242), heff_strLength_lent(v_x_243, 0));
        } else {
          heff_drop(v_qualifier_242);
          v_t_2411 = heff_dup(v_x_243);
        }
        V v_t_2412 = (g_heff_2ebuild_2equery_2ecompletionDetail(v_c_240, v_x_243));
        return heff_tag_n(TAG_Just, 1, (V[]){heff_rec_n(2, shape_label__detail, (V[]){v_t_2411, v_t_2412})});
      }
    } else {
      V v_t_2413 = heff_strSlice(heff_dup(v_x_243), MK_INT(0LL), heff_strLength_lent(v_qualifier_242, 0));
      V v_t_2415;
      if (heff_strEq_c_lent(v_t_2413, v_qualifier_242, 1)) {
        v_t_2415 = heff_strSlice(heff_dup(v_x_243), heff_strLength(v_qualifier_242), heff_strLength_lent(v_x_243, 0));
      } else {
        heff_drop(v_qualifier_242);
        v_t_2415 = heff_dup(v_x_243);
      }
      V v_t_2416 = (g_heff_2ebuild_2equery_2ecompletionDetail(v_c_240, v_x_243));
      return heff_tag_n(TAG_Just, 1, (V[]){heff_rec_n(2, shape_label__detail, (V[]){v_t_2415, v_t_2416})});
    }
  } else {
    heff_drop(v_c_240);
    heff_drop(v_qualifier_242);
    heff_drop(v_x_243);
    return NTAG(TAG_Nothing);
  }
}
V g_heff_2ebuild_2equery_2ecompletionOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2equery_2ecompletionOf(a[0], a[1], a[2], a[3]);
}
HEFF_LIT(g_heff_2ebuild_2equery_2ecompletionsAt_str0, 0, "");
V g_heff_2ebuild_2equery_2ecompletionsAt_lam0(V self, V *args);
V g_heff_2ebuild_2equery_2ecompletionsAt_lam1(V self, V *args);
Clo g_heff_2ebuild_2equery_2ecompletionsAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2ecompletionsAt_entry, 2, 0};

V g_heff_2ebuild_2equery_2ecompletionsAt(V v_c_240, V v_offset_241) {
top: ;
  V v_t_242 = (g_list_2emap_24s467798769x1763085075(heff_dup(heff_rfield(v_c_240, 7))));
  V v_t_243 = heff_get_n(heff_dup(heff_rfield(v_c_240, 5)), 0, 9);
  V v_t_244 = ({ V b_0 = heff_get_n(v_t_243, 2, 7); V a_1 = NTAG(TAG_Nil); V r_ = (g_map_2etoListOnto(b_0, a_1)); heff_drop(b_0); r_; });
  V v_t_245 = (g_list_2emap_24s1415906091x1371825187(v_t_244));
  V v_g_246 = heff_get_n(heff_dup(heff_rfield(v_c_240, 5)), 0, 9);
  V v_t_2411 = ({ V a_0 = heff_clo_n(g_heff_2ebuild_2equery_2ecompletionsAt_lam0, 2, 1, (V[]){heff_dup(v_g_246)}); V a_1 = NTAG(TAG_Nil); V b_2 = heff_get_n(v_g_246, 0, 7); V r_ = (g_list_2efoldl(a_0, a_1, b_2)); heff_drop(b_2); r_; });
  V v_t_2412 = (g_list_2emap_24s1721231741x1085491812(v_t_2411));
  V v_t_2413 = (g_heff_2ebuild_2equery_2ecatMaybesQ(v_t_2412));
  V v_t_2414 = (g_prelude_2e_2b_2b(v_t_245, v_t_2413));
  V v_t_2415 = (g_prelude_2e_2b_2b(v_t_242, v_t_2414));
  V v_t_2416 = (g_heff_2ebuild_2edriver_2enubStrD(v_t_2415));
  V v_t_2426 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2equery_2ecompletionsAt_lam1, 1, 2, (V[]){v_c_240, v_offset_241}), v_t_2416));
  V v_t_2427 = (g_heff_2ebuild_2equery_2ecatMaybesQ(v_t_2426));
  return (g_list_2esortBy_24s1223185427x423554351(v_t_2427));
}
V g_heff_2ebuild_2equery_2ecompletionsAt_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2equery_2ecompletionsAt(a[0], a[1]);
}
V g_heff_2ebuild_2equery_2ecompletionsAt_lam0(V self, V *args) {
  V v_acc_247 = args[0];
  V v_k_248 = args[1];
  V v_g_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_249 = ({ V a_0 = heff_dup(v_k_248); V b_1 = heff_get_n(v_g_246, 1, 7); V r_ = (g_map_2elookup_24s1546226666x2146984184(a_0, b_1)); heff_drop(b_1); r_; });
  switch (heff_tag_of(v_t_249)) {
  case TAG_Nothing: {
    heff_drop(v_k_248);
    return v_acc_247;
  }
  case TAG_Just: {
    V v_e_2410 = heff_field(v_t_249, 0);
    heff_take_n(v_t_249, 1ULL, 1);
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_k_248, v_e_2410}), v_acc_247});
  }
  default: return heff_nomatch(v_t_249);
  }
}
V g_heff_2ebuild_2equery_2ecompletionsAt_lam1(V self, V *args) {
  V v_x_2417 = args[0];
  V v_c_240 = heff_env(self)[0];
  V v_offset_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2418 = (g_heff_2ebuild_2equery_2etypedFrom(heff_dup(heff_rfield(v_c_240, 3)), heff_dup(v_offset_241)));
  V v_t_2419 = heff_strSlice(heff_dup(heff_rfield(v_c_240, 3)), v_t_2418, heff_dup(v_offset_241));
  V v_t_2420 = (g_heff_2ebuild_2equery_2etypedFrom(heff_dup(heff_rfield(v_c_240, 3)), heff_dup(v_offset_241)));
  V v_typed_2421 = heff_strSlice(heff_dup(heff_rfield(v_c_240, 3)), v_t_2420, v_offset_241);
  V v_t_2422 = heff_intSub(heff_strLength_lent(v_typed_2421, 0), MK_INT(1LL));
  V v_t_2423 = (g_heff_2ebuild_2equery_2elastDot(heff_dup(v_typed_2421), v_t_2422));
  V v_t_2425;
  switch (heff_tag_of(v_t_2423)) {
  case TAG_Nothing: {
    heff_drop(v_typed_2421);
    v_t_2425 = ((V)&g_heff_2ebuild_2equery_2ecompletionsAt_str0);
    break;
  }
  case TAG_Just: {
    V v_i_2424 = heff_field(v_t_2423, 0);
    heff_take_n(v_t_2423, 1ULL, 1);
    v_t_2425 = heff_strSlice(v_typed_2421, MK_INT(0LL), heff_intAdd(v_i_2424, MK_INT(1LL)));
    break;
  }
  default: heff_nomatch(v_t_2423);
  }
  return (g_heff_2ebuild_2equery_2ecompletionOf(v_c_240, v_t_2419, v_t_2425, v_x_2417));
}
Clo g_heff_2ebuild_2equery_2eeqTarget_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2eeqTarget_entry, 2, 0};

V g_heff_2ebuild_2equery_2eeqTarget(V v_a_240, V v_b_241) {
top: ;
  if (heff_strEq_c(heff_dup(heff_rfield(v_a_240, 0)), heff_dup(heff_rfield(v_b_241, 0)))) {
    V v_x2_243 = heff_take_field(v_b_241, 1);
    V v_t_244 = heff_take_field(v_a_240, 1);
    V v_t_248;
    switch (heff_tag_of(v_t_244)) {
    case TAG_Nothing: {
      switch (heff_tag_of(v_x2_243)) {
      case TAG_Nothing: {
        v_t_248 = NTAG(TAG_True);
        break;
      }
      case TAG_Just: {
        heff_take_n(v_x2_243, 0ULL, 1);
        v_t_248 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_x2_243);
      }
      break;
    }
    case TAG_Just: {
      V v_a_246 = heff_field(v_t_244, 0);
      heff_take_n(v_t_244, 1ULL, 1);
      switch (heff_tag_of(v_x2_243)) {
      case TAG_Nothing: {
        heff_drop(v_a_246);
        v_t_248 = NTAG(TAG_False);
        break;
      }
      case TAG_Just: {
        V v_b_247 = heff_field(v_x2_243, 0);
        heff_take_n(v_x2_243, 1ULL, 1);
        v_t_248 = heff_strEq(v_a_246, v_b_247);
        break;
      }
      default: heff_nomatch(v_x2_243);
      }
      break;
    }
    default: heff_nomatch(v_t_244);
    }
    if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
      heff_drop(v_t_248);
      V v_x2_249 = heff_get_n(v_b_241, 2, 3);
      V v_t_2410 = heff_get_n(v_a_240, 2, 3);
      switch (heff_tag_of(v_t_2410)) {
      case TAG_Nothing: {
        switch (heff_tag_of(v_x2_249)) {
        case TAG_Nothing: {
          return NTAG(TAG_True);
        }
        case TAG_Just: {
          heff_take_n(v_x2_249, 0ULL, 1);
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_x2_249);
        }
      }
      case TAG_Just: {
        V v_a_2412 = heff_field(v_t_2410, 0);
        heff_take_n(v_t_2410, 1ULL, 1);
        switch (heff_tag_of(v_x2_249)) {
        case TAG_Nothing: {
          heff_drop_rec(v_a_2412, 2);
          return NTAG(TAG_False);
        }
        case TAG_Just: {
          V v_b_2413 = heff_field(v_x2_249, 0);
          heff_take_n(v_x2_249, 1ULL, 1);
          V v_ret_24bool = heff_bool((heff_intEq_c(heff_dup(heff_rfield(v_a_2412, 0)), heff_dup(heff_rfield(v_b_2413, 0))) && heff_intEq_c(heff_dup(heff_rfield(v_a_2412, 1)), heff_dup(heff_rfield(v_b_2413, 1)))));
          heff_drop_rec(v_a_2412, 2);
          heff_drop_rec(v_b_2413, 2);
          return v_ret_24bool;
        }
        default: return heff_nomatch(v_x2_249);
        }
      }
      default: return heff_nomatch(v_t_2410);
      }
    } else {
      heff_drop_rec(v_a_240, 3);
      heff_drop_rec(v_b_241, 3);
      heff_drop(v_t_248);
      return NTAG(TAG_False);
    }
  } else {
    heff_drop_rec(v_a_240, 3);
    heff_drop_rec(v_b_241, 3);
    return NTAG(TAG_False);
  }
}
V g_heff_2ebuild_2equery_2eeqTarget_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2equery_2eeqTarget(a[0], a[1]);
}
Clo g_heff_2ebuild_2equery_2esumTags_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2esumTags_entry, 1, 0};

V g_heff_2ebuild_2equery_2esumTags(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_At: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_EVar: {
      return NTAG(TAG_Nil);
    }
    case TAG_EImplicitVar: {
      return NTAG(TAG_Nil);
    }
    case TAG_ETag: {
      return NTAG(TAG_Nil);
    }
    case TAG_EInt: {
      return NTAG(TAG_Nil);
    }
    case TAG_EFloat: {
      return NTAG(TAG_Nil);
    }
    case TAG_EString: {
      return NTAG(TAG_Nil);
    }
    case TAG_EBinary: {
      return NTAG(TAG_Nil);
    }
    case TAG_ERune: {
      return NTAG(TAG_Nil);
    }
    case TAG_EWord: {
      return NTAG(TAG_Nil);
    }
    case TAG_EApp: {
      return NTAG(TAG_Nil);
    }
    case TAG_EProject: {
      return NTAG(TAG_Nil);
    }
    case TAG_ENamed: {
      return NTAG(TAG_Nil);
    }
    case TAG_EPi: {
      return NTAG(TAG_Nil);
    }
    case TAG_ELam: {
      return NTAG(TAG_Nil);
    }
    case TAG_EAnn: {
      return NTAG(TAG_Nil);
    }
    case TAG_ESpec: {
      return NTAG(TAG_Nil);
    }
    case TAG_ESig: {
      return NTAG(TAG_Nil);
    }
    case TAG_ESum: {
      V v_alts_2428 = heff_field(v_x11_241, 0);
      V v_t_2429 = (g_list_2emap_24s173442543x1801751270(heff_dup(v_alts_2428)));
      HEFF_LAST return g_heff_2ebuild_2equery_2ecatMaybesQ(v_t_2429);
    }
    case TAG_EStruct: {
      return NTAG(TAG_Nil);
    }
    case TAG_EUpdate: {
      return NTAG(TAG_Nil);
    }
    case TAG_EMatch: {
      return NTAG(TAG_Nil);
    }
    case TAG_ELetIn: {
      return NTAG(TAG_Nil);
    }
    case TAG_EDo: {
      return NTAG(TAG_Nil);
    }
    case TAG_ELocal: {
      return NTAG(TAG_Nil);
    }
    case TAG_EInvalid: {
      return NTAG(TAG_Nil);
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2equery_2esumTags_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2equery_2esumTags(a0); heff_drop(a0); return r;
}
Clo g_heff_2ebuild_2equery_2edeclSites_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2edeclSites_entry, 2, 0};

V g_heff_2ebuild_2equery_2edeclSites(V v_c_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_At: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24At = heff_take_reuse_n(v_x2_241, 1ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_DeclEquations: {
      V v_f_244 = heff_field(v_x21_242, 0);
      V v_fsp_245 = heff_field(v_x21_242, 1);
      V v_eqs_248 = heff_field(v_x21_242, 4);
      heff_take_n(v_x21_242, 19ULL, 5);
      V v_t_249 = (g_list_2emap_24s1675313341x192238134(v_eqs_248));
      V v_sps_2410 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_fsp_245, v_t_249});
      V v_t_2411 = ({ V a_0 = heff_dup(v_f_244); V b_1 = heff_get_n(v_c_240, 7, 13); V r_ = (g_list_2efind_24s1184231137x30317987(a_0, b_1)); heff_drop(b_1); r_; });
      switch (heff_tag_of(v_t_2411)) {
      case TAG_Nothing: {
        heff_drop(v_f_244);
        heff_drop_tag(v_sps_2410, 2);
        return NTAG(TAG_Nil);
      }
      case TAG_Just: {
        V v_o_2412 = heff_field(v_t_2411, 0);
        heff_take_n(v_t_2411, 1ULL, 1);
        return (g_list_2emap_24s1817753698x509594538(heff_get_n(v_o_2412, 1, 2), v_f_244, v_sps_2410));
      }
      default: return heff_nomatch(v_t_2411);
      }
    }
    case TAG_DeclDefine: {
      V v_x_2413 = heff_field(v_x21_242, 0);
      V v_xsp_2414 = heff_field(v_x21_242, 1);
      V v_body_2417 = heff_field(v_x21_242, 4);
      heff_take_n(v_x21_242, 19ULL, 5);
      V v_t_2418 = (g_list_2efind_24s1184231137x30317987(heff_dup(v_x_2413), heff_rfield(v_c_240, 7)));
      V v_t_2421;
      switch (heff_tag_of(v_t_2418)) {
      case TAG_Nothing: {
        heff_drop_cell(v_ru_24x2_241_24At, 2);
        heff_drop(v_xsp_2414);
        v_t_2421 = NTAG(TAG_Nil);
        break;
      }
      case TAG_Just: {
        V v_o_2419 = heff_field(v_t_2418, 0);
        heff_take_n(v_t_2418, 1ULL, 1);
        V v_t_2420 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_xsp_2414, NTAG(TAG_Nil)});
        v_t_2421 = (g_list_2emap_24s1817753698x509594538(heff_get_n(v_o_2419, 1, 2), heff_dup(v_x_2413), v_t_2420));
        break;
      }
      default: heff_nomatch(v_t_2418);
      }
      V v_ms_2422 = ({ V a_0 = v_body_2417; V r_ = (g_heff_2ebuild_2equery_2esumTags(a_0)); heff_drop(v_body_2417); r_; });
      V v_t_2423 = ({ V a_0 = v_x_2413; V b_1 = heff_get_n(v_c_240, 7, 13); V r_ = (g_list_2efind_24s1184231137x30317987(a_0, b_1)); heff_drop(b_1); r_; });
      V v_t_2425;
      switch (heff_tag_of(v_t_2423)) {
      case TAG_Nothing: {
        heff_drop(v_ms_2422);
        v_t_2425 = NTAG(TAG_Nil);
        break;
      }
      case TAG_Just: {
        V v_o_2424 = heff_field(v_t_2423, 0);
        heff_take_n(v_t_2423, 1ULL, 1);
        v_t_2425 = (g_list_2emap_24s1266088736x105832553(heff_get_n(v_o_2424, 1, 2), v_ms_2422));
        break;
      }
      default: heff_nomatch(v_t_2423);
      }
      HEFF_LAST return g_prelude_2e_2b_2b(v_t_2421, v_t_2425);
    }
    case TAG_DeclTheory: {
      V v_x_2426 = heff_field(v_x21_242, 0);
      V v_xsp_2427 = heff_field(v_x21_242, 1);
      V v_x214_2429 = heff_field(v_x21_242, 3);
      heff_take_n(v_x21_242, 11ULL, 4);
      switch (heff_tag_of(v_x214_2429)) {
      case TAG_At: {
        V v_x2141_2430 = heff_field(v_x214_2429, 0);
        heff_take_n(v_x214_2429, 1ULL, 2);
        switch (heff_tag_of(v_x2141_2430)) {
        case TAG_EVar: {
          heff_take_n(v_x2141_2430, 0ULL, 1);
          heff_drop_rec(v_c_240, 13);
          heff_drop_cell(v_ru_24x2_241_24At, 2);
          heff_drop(v_x_2426);
          heff_drop(v_xsp_2427);
          return NTAG(TAG_Nil);
        }
        case TAG_EImplicitVar: {
          heff_take_n(v_x2141_2430, 0ULL, 1);
          heff_drop_rec(v_c_240, 13);
          heff_drop_cell(v_ru_24x2_241_24At, 2);
          heff_drop(v_x_2426);
          heff_drop(v_xsp_2427);
          return NTAG(TAG_Nil);
        }
        case TAG_ETag: {
          heff_take_n(v_x2141_2430, 0ULL, 1);
          heff_drop_rec(v_c_240, 13);
          heff_drop_cell(v_ru_24x2_241_24At, 2);
          heff_drop(v_x_2426);
          heff_drop(v_xsp_2427);
          return NTAG(TAG_Nil);
        }
        case TAG_EInt: {
          heff_take_n(v_x2141_2430, 0ULL, 1);
          heff_drop_rec(v_c_240, 13);
          heff_drop_cell(v_ru_24x2_241_24At, 2);
          heff_drop(v_x_2426);
          heff_drop(v_xsp_2427);
          return NTAG(TAG_Nil);
        }
        case TAG_EFloat: {
          heff_take_na(v_x2141_2430, 0ULL, 1);
          heff_drop_rec(v_c_240, 13);
          heff_drop_cell(v_ru_24x2_241_24At, 2);
          heff_drop(v_x_2426);
          heff_drop(v_xsp_2427);
          return NTAG(TAG_Nil);
        }
        case TAG_EString: {
          heff_take_n(v_x2141_2430, 0ULL, 1);
          heff_drop_rec(v_c_240, 13);
          heff_drop_cell(v_ru_24x2_241_24At, 2);
          heff_drop(v_x_2426);
          heff_drop(v_xsp_2427);
          return NTAG(TAG_Nil);
        }
        case TAG_EBinary: {
          heff_take_n(v_x2141_2430, 0ULL, 1);
          heff_drop_rec(v_c_240, 13);
          heff_drop_cell(v_ru_24x2_241_24At, 2);
          heff_drop(v_x_2426);
          heff_drop(v_xsp_2427);
          return NTAG(TAG_Nil);
        }
        case TAG_ERune: {
          heff_take_n(v_x2141_2430, 0ULL, 1);
          heff_drop_rec(v_c_240, 13);
          heff_drop_cell(v_ru_24x2_241_24At, 2);
          heff_drop(v_x_2426);
          heff_drop(v_xsp_2427);
          return NTAG(TAG_Nil);
        }
        case TAG_EWord: {
          heff_take_n(v_x2141_2430, 0ULL, 1);
          heff_drop_rec(v_c_240, 13);
          heff_drop_cell(v_ru_24x2_241_24At, 2);
          heff_drop(v_x_2426);
          heff_drop(v_xsp_2427);
          return NTAG(TAG_Nil);
        }
        case TAG_EApp: {
          heff_take_n(v_x2141_2430, 0ULL, 2);
          heff_drop_rec(v_c_240, 13);
          heff_drop_cell(v_ru_24x2_241_24At, 2);
          heff_drop(v_x_2426);
          heff_drop(v_xsp_2427);
          return NTAG(TAG_Nil);
        }
        case TAG_EProject: {
          heff_take_n(v_x2141_2430, 0ULL, 1);
          heff_drop_rec(v_c_240, 13);
          heff_drop_cell(v_ru_24x2_241_24At, 2);
          heff_drop(v_x_2426);
          heff_drop(v_xsp_2427);
          return NTAG(TAG_Nil);
        }
        case TAG_ENamed: {
          heff_take_n(v_x2141_2430, 0ULL, 2);
          heff_drop_rec(v_c_240, 13);
          heff_drop_cell(v_ru_24x2_241_24At, 2);
          heff_drop(v_x_2426);
          heff_drop(v_xsp_2427);
          return NTAG(TAG_Nil);
        }
        case TAG_EPi: {
          heff_take_n(v_x2141_2430, 0ULL, 2);
          heff_drop_rec(v_c_240, 13);
          heff_drop_cell(v_ru_24x2_241_24At, 2);
          heff_drop(v_x_2426);
          heff_drop(v_xsp_2427);
          return NTAG(TAG_Nil);
        }
        case TAG_ELam: {
          heff_take_n(v_x2141_2430, 0ULL, 2);
          heff_drop_rec(v_c_240, 13);
          heff_drop_cell(v_ru_24x2_241_24At, 2);
          heff_drop(v_x_2426);
          heff_drop(v_xsp_2427);
          return NTAG(TAG_Nil);
        }
        case TAG_EAnn: {
          heff_take_n(v_x2141_2430, 0ULL, 2);
          heff_drop_rec(v_c_240, 13);
          heff_drop_cell(v_ru_24x2_241_24At, 2);
          heff_drop(v_x_2426);
          heff_drop(v_xsp_2427);
          return NTAG(TAG_Nil);
        }
        case TAG_ESpec: {
          heff_take_n(v_x2141_2430, 0ULL, 4);
          heff_drop_rec(v_c_240, 13);
          heff_drop_cell(v_ru_24x2_241_24At, 2);
          heff_drop(v_x_2426);
          heff_drop(v_xsp_2427);
          return NTAG(TAG_Nil);
        }
        case TAG_ESig: {
          V v_fs_2456 = heff_field(v_x2141_2430, 0);
          heff_take_n(v_x2141_2430, 1ULL, 1);
          V v_t_2457 = (g_list_2efind_24s1184231137x30317987(heff_dup(v_x_2426), heff_rfield(v_c_240, 7)));
          V v_t_2460;
          switch (heff_tag_of(v_t_2457)) {
          case TAG_Nothing: {
            heff_drop_cell(v_ru_24x2_241_24At, 2);
            heff_drop(v_xsp_2427);
            v_t_2460 = NTAG(TAG_Nil);
            break;
          }
          case TAG_Just: {
            V v_o_2458 = heff_field(v_t_2457, 0);
            heff_take_n(v_t_2457, 1ULL, 1);
            V v_t_2459 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_xsp_2427, NTAG(TAG_Nil)});
            v_t_2460 = (g_list_2emap_24s1817753698x509594538(heff_get_n(v_o_2458, 1, 2), heff_dup(v_x_2426), v_t_2459));
            break;
          }
          default: heff_nomatch(v_t_2457);
          }
          V v_t_2461 = (g_list_2emap_24s2000102784x314586828(v_fs_2456));
          V v_ms_2462 = (g_heff_2ebuild_2equery_2ecatMaybesQ(v_t_2461));
          V v_t_2463 = ({ V a_0 = v_x_2426; V b_1 = heff_get_n(v_c_240, 7, 13); V r_ = (g_list_2efind_24s1184231137x30317987(a_0, b_1)); heff_drop(b_1); r_; });
          V v_t_2465;
          switch (heff_tag_of(v_t_2463)) {
          case TAG_Nothing: {
            heff_drop(v_ms_2462);
            v_t_2465 = NTAG(TAG_Nil);
            break;
          }
          case TAG_Just: {
            V v_o_2464 = heff_field(v_t_2463, 0);
            heff_take_n(v_t_2463, 1ULL, 1);
            v_t_2465 = (g_list_2emap_24s1266088736x105832553(heff_get_n(v_o_2464, 1, 2), v_ms_2462));
            break;
          }
          default: heff_nomatch(v_t_2463);
          }
          HEFF_LAST return g_prelude_2e_2b_2b(v_t_2460, v_t_2465);
        }
        case TAG_ESum: {
          heff_take_n(v_x2141_2430, 0ULL, 1);
          heff_drop_rec(v_c_240, 13);
          heff_drop_cell(v_ru_24x2_241_24At, 2);
          heff_drop(v_x_2426);
          heff_drop(v_xsp_2427);
          return NTAG(TAG_Nil);
        }
        case TAG_EStruct: {
          heff_take_n(v_x2141_2430, 0ULL, 1);
          heff_drop_rec(v_c_240, 13);
          heff_drop_cell(v_ru_24x2_241_24At, 2);
          heff_drop(v_x_2426);
          heff_drop(v_xsp_2427);
          return NTAG(TAG_Nil);
        }
        case TAG_EUpdate: {
          heff_take_n(v_x2141_2430, 0ULL, 2);
          heff_drop_rec(v_c_240, 13);
          heff_drop_cell(v_ru_24x2_241_24At, 2);
          heff_drop(v_x_2426);
          heff_drop(v_xsp_2427);
          return NTAG(TAG_Nil);
        }
        case TAG_EMatch: {
          heff_take_n(v_x2141_2430, 0ULL, 2);
          heff_drop_rec(v_c_240, 13);
          heff_drop_cell(v_ru_24x2_241_24At, 2);
          heff_drop(v_x_2426);
          heff_drop(v_xsp_2427);
          return NTAG(TAG_Nil);
        }
        case TAG_ELetIn: {
          heff_take_n(v_x2141_2430, 0ULL, 2);
          heff_drop_rec(v_c_240, 13);
          heff_drop_cell(v_ru_24x2_241_24At, 2);
          heff_drop(v_x_2426);
          heff_drop(v_xsp_2427);
          return NTAG(TAG_Nil);
        }
        case TAG_EDo: {
          heff_take_n(v_x2141_2430, 0ULL, 1);
          heff_drop_rec(v_c_240, 13);
          heff_drop_cell(v_ru_24x2_241_24At, 2);
          heff_drop(v_x_2426);
          heff_drop(v_xsp_2427);
          return NTAG(TAG_Nil);
        }
        case TAG_ELocal: {
          heff_take_n(v_x2141_2430, 0ULL, 2);
          heff_drop_rec(v_c_240, 13);
          heff_drop_cell(v_ru_24x2_241_24At, 2);
          heff_drop(v_x_2426);
          heff_drop(v_xsp_2427);
          return NTAG(TAG_Nil);
        }
        case TAG_EInvalid: {
          heff_take_n(v_x2141_2430, 0ULL, 1);
          heff_drop_rec(v_c_240, 13);
          heff_drop_cell(v_ru_24x2_241_24At, 2);
          heff_drop(v_x_2426);
          heff_drop(v_xsp_2427);
          return NTAG(TAG_Nil);
        }
        default: return heff_nomatch(v_x2141_2430);
        }
      }
      default: return heff_nomatch(v_x214_2429);
      }
    }
    case TAG_DeclPrimitive: {
      V v_x_2478 = heff_field(v_x21_242, 0);
      V v_sp_2479 = heff_field(v_x21_242, 1);
      heff_take_n(v_x21_242, 3ULL, 3);
      V v_t_2481 = ({ V a_0 = heff_dup(v_x_2478); V b_1 = heff_get_n(v_c_240, 7, 13); V r_ = (g_list_2efind_24s1184231137x30317987(a_0, b_1)); heff_drop(b_1); r_; });
      switch (heff_tag_of(v_t_2481)) {
      case TAG_Nothing: {
        heff_drop_cell(v_ru_24x2_241_24At, 2);
        heff_drop(v_x_2478);
        heff_drop(v_sp_2479);
        return NTAG(TAG_Nil);
      }
      case TAG_Just: {
        V v_o_2482 = heff_field(v_t_2481, 0);
        heff_take_n(v_t_2481, 1ULL, 1);
        V v_t_2483 = heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_sp_2479, NTAG(TAG_Nil)});
        return (g_list_2emap_24s1817753698x509594538(heff_get_n(v_o_2482, 1, 2), v_x_2478, v_t_2483));
      }
      default: return heff_nomatch(v_t_2481);
      }
    }
    case TAG_DeclTest: {
      heff_take_n(v_x21_242, 0ULL, 2);
      heff_drop_rec(v_c_240, 13);
      heff_drop_cell(v_ru_24x2_241_24At, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_DeclWatch: {
      heff_take_n(v_x21_242, 0ULL, 1);
      heff_drop_rec(v_c_240, 13);
      heff_drop_cell(v_ru_24x2_241_24At, 2);
      return NTAG(TAG_Nil);
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2equery_2edeclSites_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2equery_2edeclSites(a[0], a[1]);
}
Clo g_heff_2ebuild_2equery_2edefinesGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2edefinesGo_entry, 4, 0};

V g_heff_2ebuild_2equery_2edefinesGo(V v_k_240, V v_c_241, V v_x3_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_k_240);
    heff_drop(v_c_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_o_244 = heff_field(v_x3_242, 0);
    V v_os_245 = heff_field(v_x3_242, 1);
    switch (heff_tag_of(v_x4_243)) {
    case TAG_Nil: {
      heff_drop(v_k_240);
      heff_drop(v_c_241);
      return NTAG(TAG_Nothing);
    }
    case TAG_Cons: {
      V v_x41_246 = heff_field(v_x4_243, 0);
      V v_sps_247 = heff_field(v_x4_243, 1);
      switch (heff_tag_of(v_x41_246)) {
      case TAG_MkPair: {
        V v_sp_249 = heff_field(v_x41_246, 1);
        if (heff_strEq_c(heff_dup(heff_rfield(v_o_244, 1)), heff_dup(v_k_240))) {
          heff_drop(v_k_240);
          V v_t_2411 = heff_rec_n(3, shape_c__name__span, (V[]){v_c_241, heff_dup(heff_rfield(v_o_244, 0)), heff_dup(v_sp_249)});
          return heff_tag_n(TAG_Just, 1, (V[]){v_t_2411});
        } else {
          V t_0 = v_k_240;
          V t_1 = v_c_241;
          V t_2 = v_os_245;
          V t_3 = v_sps_247;
          v_k_240 = t_0;
          v_c_241 = t_1;
          v_x3_242 = t_2;
          v_x4_243 = t_3;
          goto top;
        }
      }
      default: return heff_nomatch(v_x41_246);
      }
    }
    default: return heff_nomatch(v_x4_243);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2equery_2edefinesGo_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V a3 = a[3]; V r = g_heff_2ebuild_2equery_2edefinesGo(a[0], a[1], a2, a3); heff_drop(a2); heff_drop(a3); return r;
}
V g_heff_2ebuild_2equery_2edefinitionIn_lam0(V self, V *args);
V g_heff_2ebuild_2equery_2edefinitionIn_lam1(V self, V *args);
Clo g_heff_2ebuild_2equery_2edefinitionIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2edefinitionIn_entry, 3, 0};

V g_heff_2ebuild_2equery_2edefinitionIn(V v_i_240, V v_k_241, V v_d_242) {
top: ;
  V v_t_243 = heff_get_n(heff_dup(heff_rfield(v_d_242, 0)), 1, 13);
  V v_t_244 = heff_get_n(heff_dup(heff_rfield(v_d_242, 0)), 3, 13);
  V v_c_245 = heff_dup(heff_rfield(v_d_242, 0));
  V v_t_246 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(heff_rfield(v_c_245, 4))));
  V v_t_2410 = ({ V a_0 = heff_clo_n(g_heff_2ebuild_2equery_2edefinitionIn_lam0, 2, 1, (V[]){v_c_245}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_246; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_246); r_; });
  V v_t_2415 = ({ V a_0 = heff_clo_n(g_heff_2ebuild_2equery_2edefinitionIn_lam1, 1, 2, (V[]){heff_dup(v_i_240), v_k_241}); V a_1 = v_t_2410; V r_ = (g_list_2efind(a_0, a_1)); heff_drop(v_t_2410); r_; });
  V v_t_2419;
  switch (heff_tag_of(v_t_2415)) {
  case TAG_Nothing: {
    V v_sp_2416 = heff_take_field(v_d_242, 2);
    V v_t_2417 = heff_get_n(heff_get_n(v_d_242, 0, 3), 3, 13);
    v_t_2419 = (g_heff_2ebuild_2equery_2enameInGo(v_t_2417, heff_get_n(v_i_240, 1, 5), heff_dup(v_sp_2416), heff_get_n(v_sp_2416, 0, 2)));
    break;
  }
  case TAG_Just: {
    V v_s_2418 = heff_field(v_t_2415, 0);
    heff_take_n(v_t_2415, 1ULL, 1);
    heff_drop_rec(v_i_240, 5);
    heff_drop_rec(v_d_242, 3);
    v_t_2419 = heff_get_n(v_s_2418, 2, 3);
    break;
  }
  default: heff_nomatch(v_t_2415);
  }
  return heff_rec_n(3, shape_path__source__span, (V[]){v_t_243, v_t_244, v_t_2419});
}
V g_heff_2ebuild_2equery_2edefinitionIn_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2equery_2edefinitionIn(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2equery_2edefinitionIn_lam0(V self, V *args) {
  V v_acc_247 = args[0];
  V v_x_248 = args[1];
  V v_c_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_249 = (g_heff_2ebuild_2equery_2edeclSites(v_c_245, v_x_248));
  return (g_prelude_2e_2b_2b(v_t_249, v_acc_247));
}
V g_heff_2ebuild_2equery_2edefinitionIn_lam1(V self, V *args) {
  V v_s_2411 = args[0];
  V v_i_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2412 = heff_take_field(v_i_240, 3);
  V v_t_2414;
  if ((heff_dup(v_t_2412) == NTAG(TAG_True))) {
    heff_drop(v_t_2412);
    V v_t_2413 = heff_tag_n(TAG_Just, 1, (V[]){heff_get_n(v_i_240, 1, 5)});
    v_t_2414 = heff_rec_n(3, shape_key__member__local, (V[]){v_k_241, v_t_2413, NTAG(TAG_Nothing)});
  } else {
    heff_drop_rec(v_i_240, 5);
    heff_drop(v_t_2412);
    v_t_2414 = heff_rec_n(3, shape_key__member__local, (V[]){v_k_241, NTAG(TAG_Nothing), NTAG(TAG_Nothing)});
  }
  return (g_heff_2ebuild_2equery_2eeqTarget(heff_get_n(v_s_2411, 0, 3), v_t_2414));
}
V g_heff_2ebuild_2equery_2edefinitionAt_lam0(V self, V *args);
Clo g_heff_2ebuild_2equery_2edefinitionAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2edefinitionAt_entry, 2, 0};

V g_heff_2ebuild_2equery_2edefinitionAt(V v_program_240, V v_off_241) {
top: ;
  V v_x1_242 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_program_240)));
  V v_t_245;
  switch (heff_tag_of(v_x1_242)) {
  case TAG_Nil: {
    v_t_245 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x1_242, 0);
    heff_take_n(v_x1_242, 1ULL, 2);
    v_t_245 = heff_tag_n(TAG_Just, 1, (V[]){v_x_243});
    break;
  }
  default: heff_nomatch(v_x1_242);
  }
  switch (heff_tag_of(v_t_245)) {
  case TAG_Nothing: {
    heff_drop(v_program_240);
    heff_drop(v_off_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_c_246 = heff_field(v_t_245, 0);
    V v_ru_24t_245_24Just = heff_take_reuse_n(v_t_245, 1ULL, 1);
    V v_t_247 = heff_get_n(heff_get_n(v_c_246, 5, 13), 7, 9);
    V v_t_248 = (g_list_2efilter_24s1109331425x852844386(MK_INT(1LL), v_off_241, v_t_247));
    V v_x1_249 = (g_list_2esortBy_24s1681607803x465385494(v_t_248));
    switch (heff_tag_of(v_x1_249)) {
    case TAG_Nil: {
      heff_drop(v_program_240);
      heff_drop_cell(v_ru_24t_245_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_Cons: {
      V v_x_2410 = heff_field(v_x1_249, 0);
      heff_take_n(v_x1_249, 1ULL, 2);
      V v_t_2412 = heff_dup(heff_rfield(v_x_2410, 2));
      switch (heff_tag_of(v_t_2412)) {
      case TAG_Nothing: {
        heff_drop(v_program_240);
        heff_drop_cell(v_ru_24t_245_24Just, 1);
        heff_drop_rec(v_x_2410, 5);
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_k_2413 = heff_field(v_t_2412, 0);
        heff_take_n(v_t_2412, 1ULL, 1);
        V v_t_2414 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_program_240));
        V v_t_2417 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2equery_2edefinitionAt_lam0, 1, 1, (V[]){heff_dup(v_k_2413)}), v_t_2414));
        V v_x1_2418 = (g_heff_2ebuild_2equery_2ecatMaybesQ(v_t_2417));
        switch (heff_tag_of(v_x1_2418)) {
        case TAG_Nil: {
          heff_drop_cell(v_ru_24t_245_24Just, 1);
          heff_drop_rec(v_x_2410, 5);
          heff_drop(v_k_2413);
          return NTAG(TAG_Nothing);
        }
        case TAG_Cons: {
          V v_x_2419 = heff_field(v_x1_2418, 0);
          heff_take_n(v_x1_2418, 1ULL, 2);
          V v_t_2421 = (g_heff_2ebuild_2equery_2edefinitionIn(v_x_2410, v_k_2413, v_x_2419));
          return heff_tag_at_n(v_ru_24t_245_24Just, TAG_Just, 1, (V[]){v_t_2421});
        }
        default: return heff_nomatch(v_x1_2418);
        }
      }
      default: return heff_nomatch(v_t_2412);
      }
    }
    default: return heff_nomatch(v_x1_249);
    }
  }
  default: return heff_nomatch(v_t_245);
  }
}
V g_heff_2ebuild_2equery_2edefinitionAt_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2equery_2edefinitionAt(a[0], a[1]);
}
V g_heff_2ebuild_2equery_2edefinitionAt_lam0(V self, V *args) {
  V v_c2_2415 = args[0];
  V v_k_2413 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2416 = heff_get_n(heff_dup(heff_rfield(v_c2_2415, 5)), 6, 9);
  return ({ V a_0 = v_k_2413; V a_1 = heff_dup(v_c2_2415); V b_2 = heff_get_n(v_c2_2415, 7, 13); V a_3 = v_t_2416; V r_ = (g_heff_2ebuild_2equery_2edefinesGo(a_0, a_1, b_2, a_3)); heff_drop(b_2); heff_drop(v_t_2416); r_; });
}
Clo g_heff_2ebuild_2equery_2eownNameOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2eownNameOf_entry, 2, 0};

V g_heff_2ebuild_2equery_2eownNameOf(V v_x1_240, V v_k_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_k_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_c_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    V v_t_244 = (g_list_2efind_24s988189774x1593035904(heff_dup(v_k_241), heff_rfield(v_c_242, 7)));
    switch (heff_tag_of(v_t_244)) {
    case TAG_Nothing: {
      V t_0 = v_rest_243;
      V t_1 = v_k_241;
      v_x1_240 = t_0;
      v_k_241 = t_1;
      goto top;
    }
    case TAG_Just: {
      V v_o_245 = heff_field(v_t_244, 0);
      V v_ru_24t_244_24Just = heff_take_reuse_n(v_t_244, 1ULL, 1);
      heff_drop(v_k_241);
      return heff_tag_at_n(v_ru_24t_244_24Just, TAG_Just, 1, (V[]){heff_get_n(v_o_245, 0, 2)});
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2equery_2eownNameOf_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2equery_2eownNameOf(a0, a[1]); heff_drop(a0); return r;
}
V g_heff_2ebuild_2equery_2esiteFound_lam0(V self, V *args);
Clo g_heff_2ebuild_2equery_2esiteFound_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2esiteFound_entry, 3, 0};

V g_heff_2ebuild_2equery_2esiteFound(V v_program_240, V v_c_241, V v_off_242) {
top: ;
  V v_t_243 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(heff_rfield(v_c_241, 4))));
  V v_t_247 = ({ V a_0 = heff_clo_n(g_heff_2ebuild_2equery_2esiteFound_lam0, 2, 1, (V[]){v_c_241}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_243; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_243); r_; });
  V v_t_248 = ({ V a_0 = v_off_242; V a_1 = v_t_247; V r_ = (g_list_2efind_24s361650052x1432786508(a_0, a_1)); heff_drop(v_t_247); r_; });
  switch (heff_tag_of(v_t_248)) {
  case TAG_Nothing: {
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_s_249 = heff_field(v_t_248, 0);
    V v_ru_24t_248_24Just = heff_take_reuse_n(v_t_248, 1ULL, 1);
    V v_t_2410 = heff_get_n(v_s_249, 0, 3);
    V v_t_2411 = heff_dup(heff_rfield(v_t_2410, 1));
    switch (heff_tag_of(v_t_2411)) {
    case TAG_Nothing: {
      V v_t_2412 = (g_heff_2ebuild_2equery_2eownNameOf(v_program_240, heff_dup(heff_rfield(v_t_2410, 0))));
      switch (heff_tag_of(v_t_2412)) {
      case TAG_Nothing: {
        heff_drop_cell(v_ru_24t_248_24Just, 1);
        heff_drop_rec(v_t_2410, 3);
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_x_2413 = heff_field(v_t_2412, 0);
        heff_take_n(v_t_2412, 1ULL, 1);
        return heff_tag_at_n(v_ru_24t_248_24Just, TAG_Just, 1, (V[]){heff_rec_n(2, shape_target__name, (V[]){v_t_2410, v_x_2413})});
      }
      default: return heff_nomatch(v_t_2412);
      }
    }
    case TAG_Just: {
      V v_m_2414 = heff_field(v_t_2411, 0);
      heff_take_n(v_t_2411, 1ULL, 1);
      return heff_tag_at_n(v_ru_24t_248_24Just, TAG_Just, 1, (V[]){heff_rec_n(2, shape_target__name, (V[]){v_t_2410, v_m_2414})});
    }
    default: return heff_nomatch(v_t_2411);
    }
  }
  default: return heff_nomatch(v_t_248);
  }
}
V g_heff_2ebuild_2equery_2esiteFound_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2equery_2esiteFound(a0, a[1], a[2]); heff_drop(a0); return r;
}
V g_heff_2ebuild_2equery_2esiteFound_lam0(V self, V *args) {
  V v_acc_244 = args[0];
  V v_x_245 = args[1];
  V v_c_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_246 = (g_heff_2ebuild_2equery_2edeclSites(v_c_241, v_x_245));
  return (g_prelude_2e_2b_2b(v_t_246, v_acc_244));
}
V g_heff_2ebuild_2equery_2efieldFound_lam0(V self, V *args);
Clo g_heff_2ebuild_2equery_2efieldFound_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2efieldFound_entry, 4, 0};

V g_heff_2ebuild_2equery_2efieldFound(V v_program_240, V v_c_241, V v_ls_242, V v_off_243) {
top: ;
  V v_t_244 = ({ V a_0 = v_off_243; V b_1 = heff_get_n(v_ls_242, 1, 2); V r_ = (g_list_2efind_24s1085725546x1737150855(a_0, b_1)); heff_drop(b_1); r_; });
  switch (heff_tag_of(v_t_244)) {
  case TAG_Nothing: {
    heff_drop_rec(v_c_241, 13);
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_f_245 = heff_field(v_t_244, 0);
    V v_ru_24t_244_24Just = heff_take_reuse_n(v_t_244, 1ULL, 1);
    V v_t_246 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(heff_rfield(v_c_241, 4))));
    V v_t_2410 = ({ V a_0 = heff_clo_n(g_heff_2ebuild_2equery_2efieldFound_lam0, 2, 1, (V[]){v_c_241}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_246; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_246); r_; });
    V v_t_2411 = ({ V a_0 = v_f_245; V a_1 = v_t_2410; V r_ = (g_list_2efind_24s582687515x818787580(a_0, a_1)); heff_drop(v_t_2410); r_; });
    switch (heff_tag_of(v_t_2411)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24t_244_24Just, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_Just: {
      V v_s_2412 = heff_field(v_t_2411, 0);
      heff_take_n(v_t_2411, 1ULL, 1);
      V v_t_2413 = heff_get_n(v_s_2412, 0, 3);
      V v_t_2414 = heff_dup(heff_rfield(v_t_2413, 1));
      switch (heff_tag_of(v_t_2414)) {
      case TAG_Nothing: {
        V v_t_2415 = (g_heff_2ebuild_2equery_2eownNameOf(v_program_240, heff_dup(heff_rfield(v_t_2413, 0))));
        switch (heff_tag_of(v_t_2415)) {
        case TAG_Nothing: {
          heff_drop_cell(v_ru_24t_244_24Just, 1);
          heff_drop_rec(v_t_2413, 3);
          return NTAG(TAG_Nothing);
        }
        case TAG_Just: {
          V v_x_2416 = heff_field(v_t_2415, 0);
          heff_take_n(v_t_2415, 1ULL, 1);
          return heff_tag_at_n(v_ru_24t_244_24Just, TAG_Just, 1, (V[]){heff_rec_n(2, shape_target__name, (V[]){v_t_2413, v_x_2416})});
        }
        default: return heff_nomatch(v_t_2415);
        }
      }
      case TAG_Just: {
        V v_m_2417 = heff_field(v_t_2414, 0);
        heff_take_n(v_t_2414, 1ULL, 1);
        return heff_tag_at_n(v_ru_24t_244_24Just, TAG_Just, 1, (V[]){heff_rec_n(2, shape_target__name, (V[]){v_t_2413, v_m_2417})});
      }
      default: return heff_nomatch(v_t_2414);
      }
    }
    default: return heff_nomatch(v_t_2411);
    }
  }
  default: return heff_nomatch(v_t_244);
  }
}
V g_heff_2ebuild_2equery_2efieldFound_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2equery_2efieldFound(a0, a[1], a[2], a[3]); heff_drop(a0); return r;
}
V g_heff_2ebuild_2equery_2efieldFound_lam0(V self, V *args) {
  V v_acc_247 = args[0];
  V v_x_248 = args[1];
  V v_c_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_249 = (g_heff_2ebuild_2equery_2edeclSites(v_c_241, v_x_248));
  return (g_prelude_2e_2b_2b(v_t_249, v_acc_247));
}
V g_heff_2ebuild_2equery_2elocalFound_lam0(V self, V *args);
Clo g_heff_2ebuild_2equery_2elocalFound_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2elocalFound_entry, 3, 0};

V g_heff_2ebuild_2equery_2elocalFound(V v_c_240, V v_ls_241, V v_off_242) {
top: ;
  V v_t_247 = ({ V a_0 = heff_clo_n(g_heff_2ebuild_2equery_2elocalFound_lam0, 1, 1, (V[]){v_off_242}); V b_1 = heff_get_n(v_ls_241, 0, 2); V r_ = (g_list_2efind(a_0, b_1)); heff_drop(b_1); r_; });
  switch (heff_tag_of(v_t_247)) {
  case TAG_Nothing: {
    heff_drop_rec(v_c_240, 13);
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_l_248 = heff_field(v_t_247, 0);
    V v_ru_24t_247_24Just = heff_take_reuse_n(v_t_247, 1ULL, 1);
    V v_t_249 = heff_tag_at_n(v_ru_24t_247_24Just, TAG_Just, 1, (V[]){heff_dup(heff_rfield(v_l_248, 1))});
    V v_t_2410 = heff_rec_n(3, shape_key__member__local, (V[]){heff_get_n(v_c_240, 1, 13), NTAG(TAG_Nothing), v_t_249});
    V v_t_2411 = heff_rec_n(2, shape_target__name, (V[]){v_t_2410, heff_get_n(v_l_248, 0, 3)});
    return heff_tag_n(TAG_Just, 1, (V[]){v_t_2411});
  }
  default: return heff_nomatch(v_t_247);
  }
}
V g_heff_2ebuild_2equery_2elocalFound_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2equery_2elocalFound(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2equery_2elocalFound_lam0(V self, V *args) {
  V v_l_243 = args[0];
  V v_off_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_sp_244 = heff_take_field(v_l_243, 1);
  if (heff_intLe_c(heff_dup(heff_rfield(v_sp_244, 0)), heff_dup(v_off_242))) {
    if (heff_intLe_c(heff_dup(v_off_242), heff_get_n(v_sp_244, 1, 2))) {
      heff_drop_rec(v_l_243, 3);
      heff_drop(v_off_242);
      return NTAG(TAG_True);
    } else {
      return ({ V a_0 = v_off_242; V b_1 = heff_get_n(v_l_243, 2, 3); V r_ = (g_list_2eany_24s430343851x1474283355(a_0, b_1)); heff_drop(b_1); r_; });
    }
  } else {
    heff_drop_rec(v_sp_244, 2);
    return ({ V a_0 = v_off_242; V b_1 = heff_get_n(v_l_243, 2, 3); V r_ = (g_list_2eany_24s430343851x1474283355(a_0, b_1)); heff_drop(b_1); r_; });
  }
}
Clo g_heff_2ebuild_2equery_2etargetIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2etargetIn_entry, 4, 0};

V g_heff_2ebuild_2equery_2etargetIn(V v_program_240, V v_c_241, V v_ls_242, V v_off_243) {
top: ;
  V v_t_244 = heff_get_n(heff_dup(heff_rfield(v_c_241, 5)), 7, 9);
  V v_t_245 = (g_list_2efilter_24s1109331425x852844386(MK_INT(1LL), heff_dup(v_off_243), v_t_244));
  V v_x1_246 = (g_list_2esortBy_24s1681607803x465385494(v_t_245));
  V v_t_249;
  switch (heff_tag_of(v_x1_246)) {
  case TAG_Nil: {
    v_t_249 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Cons: {
    V v_x_247 = heff_field(v_x1_246, 0);
    heff_take_n(v_x1_246, 1ULL, 2);
    v_t_249 = heff_tag_n(TAG_Just, 1, (V[]){v_x_247});
    break;
  }
  default: heff_nomatch(v_x1_246);
  }
  switch (heff_tag_of(v_t_249)) {
  case TAG_Nothing: {
    V v_x1_2410 = (g_heff_2ebuild_2equery_2esiteFound(v_program_240, heff_dup(v_c_241), heff_dup(v_off_243)));
    V v_x1_2411 = (g_heff_2ebuild_2equery_2efieldFound(v_program_240, heff_dup(v_c_241), heff_dup(v_ls_242), heff_dup(v_off_243)));
    V v_x2_2412 = (g_heff_2ebuild_2equery_2elocalFound(v_c_241, v_ls_242, v_off_243));
    switch (heff_tag_of(v_x1_2410)) {
    case TAG_Nothing: {
      switch (heff_tag_of(v_x1_2411)) {
      case TAG_Nothing: {
        return v_x2_2412;
      }
      case TAG_Just: {
        V v_x_2413 = heff_field(v_x1_2411, 0);
        V v_ru_24x1_2411_24Just = heff_take_reuse_n(v_x1_2411, 1ULL, 1);
        heff_drop(v_x2_2412);
        return heff_tag_at_n(v_ru_24x1_2411_24Just, TAG_Just, 1, (V[]){v_x_2413});
      }
      default: return heff_nomatch(v_x1_2411);
      }
    }
    case TAG_Just: {
      V v_x_2414 = heff_field(v_x1_2410, 0);
      V v_ru_24x1_2410_24Just = heff_take_reuse_n(v_x1_2410, 1ULL, 1);
      heff_drop(v_x1_2411);
      heff_drop(v_x2_2412);
      return heff_tag_at_n(v_ru_24x1_2410_24Just, TAG_Just, 1, (V[]){v_x_2414});
    }
    default: return heff_nomatch(v_x1_2410);
    }
  }
  case TAG_Just: {
    V v_i_2415 = heff_field(v_t_249, 0);
    V v_ru_24t_249_24Just = heff_take_reuse_n(v_t_249, 1ULL, 1);
    V v_t_2416 = heff_take_field(v_i_2415, 2);
    switch (heff_tag_of(v_t_2416)) {
    case TAG_Nothing: {
      heff_drop_rec(v_i_2415, 5);
      V v_x1_2417 = (g_heff_2ebuild_2equery_2esiteFound(v_program_240, heff_dup(v_c_241), heff_dup(v_off_243)));
      V v_x1_2418 = (g_heff_2ebuild_2equery_2efieldFound(v_program_240, heff_dup(v_c_241), heff_dup(v_ls_242), heff_dup(v_off_243)));
      V v_x2_2419 = (g_heff_2ebuild_2equery_2elocalFound(v_c_241, v_ls_242, v_off_243));
      switch (heff_tag_of(v_x1_2417)) {
      case TAG_Nothing: {
        switch (heff_tag_of(v_x1_2418)) {
        case TAG_Nothing: {
          heff_drop_cell(v_ru_24t_249_24Just, 1);
          return v_x2_2419;
        }
        case TAG_Just: {
          V v_x_2420 = heff_field(v_x1_2418, 0);
          heff_take_n(v_x1_2418, 1ULL, 1);
          heff_drop(v_x2_2419);
          return heff_tag_at_n(v_ru_24t_249_24Just, TAG_Just, 1, (V[]){v_x_2420});
        }
        default: return heff_nomatch(v_x1_2418);
        }
      }
      case TAG_Just: {
        V v_x_2421 = heff_field(v_x1_2417, 0);
        heff_take_n(v_x1_2417, 1ULL, 1);
        heff_drop(v_x1_2418);
        heff_drop(v_x2_2419);
        return heff_tag_at_n(v_ru_24t_249_24Just, TAG_Just, 1, (V[]){v_x_2421});
      }
      default: return heff_nomatch(v_x1_2417);
      }
    }
    case TAG_Just: {
      V v_k_2422 = heff_field(v_t_2416, 0);
      V v_ru_24t_2416_24Just = heff_take_reuse_n(v_t_2416, 1ULL, 1);
      heff_drop_rec(v_c_241, 13);
      heff_drop(v_ls_242);
      heff_drop(v_off_243);
      V v_t_2423 = heff_take_field(v_i_2415, 3);
      V v_t_2425;
      if ((heff_dup(v_t_2423) == NTAG(TAG_True))) {
        heff_drop(v_t_2423);
        V v_t_2424 = heff_tag_at_n(v_ru_24t_249_24Just, TAG_Just, 1, (V[]){heff_get_n(v_i_2415, 1, 5)});
        v_t_2425 = heff_rec_n(3, shape_key__member__local, (V[]){v_k_2422, v_t_2424, NTAG(TAG_Nothing)});
      } else {
        heff_drop_rec(v_i_2415, 5);
        heff_drop_cell(v_ru_24t_249_24Just, 1);
        heff_drop(v_t_2423);
        v_t_2425 = heff_rec_n(3, shape_key__member__local, (V[]){v_k_2422, NTAG(TAG_Nothing), NTAG(TAG_Nothing)});
      }
      V v_t_2426 = heff_dup(heff_rfield(v_t_2425, 1));
      switch (heff_tag_of(v_t_2426)) {
      case TAG_Nothing: {
        V v_t_2427 = (g_heff_2ebuild_2equery_2eownNameOf(v_program_240, heff_dup(heff_rfield(v_t_2425, 0))));
        switch (heff_tag_of(v_t_2427)) {
        case TAG_Nothing: {
          heff_drop_cell(v_ru_24t_2416_24Just, 1);
          heff_drop_rec(v_t_2425, 3);
          return NTAG(TAG_Nothing);
        }
        case TAG_Just: {
          V v_x_2428 = heff_field(v_t_2427, 0);
          heff_take_n(v_t_2427, 1ULL, 1);
          return heff_tag_at_n(v_ru_24t_2416_24Just, TAG_Just, 1, (V[]){heff_rec_n(2, shape_target__name, (V[]){v_t_2425, v_x_2428})});
        }
        default: return heff_nomatch(v_t_2427);
        }
      }
      case TAG_Just: {
        V v_m_2429 = heff_field(v_t_2426, 0);
        heff_take_n(v_t_2426, 1ULL, 1);
        return heff_tag_at_n(v_ru_24t_2416_24Just, TAG_Just, 1, (V[]){heff_rec_n(2, shape_target__name, (V[]){v_t_2425, v_m_2429})});
      }
      default: return heff_nomatch(v_t_2426);
      }
    }
    default: return heff_nomatch(v_t_2416);
    }
  }
  default: return heff_nomatch(v_t_249);
  }
}
V g_heff_2ebuild_2equery_2etargetIn_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2equery_2etargetIn(a0, a[1], a[2], a[3]); heff_drop(a0); return r;
}
Clo g_heff_2ebuild_2equery_2euseOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2euseOf_entry, 3, 0};

V g_heff_2ebuild_2equery_2euseOf(V v_t_240, V v_name_241, V v_i_242) {
top: ;
  V v_x2_243 = heff_tag_n(TAG_Just, 1, (V[]){heff_take_field(v_t_240, 0)});
  V v_t_244 = heff_take_field(v_i_242, 2);
  V v_t_248;
  switch (heff_tag_of(v_t_244)) {
  case TAG_Nothing: {
    switch (heff_tag_of(v_x2_243)) {
    case TAG_Nothing: {
      v_t_248 = NTAG(TAG_True);
      break;
    }
    case TAG_Just: {
      heff_take_n(v_x2_243, 0ULL, 1);
      v_t_248 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x2_243);
    }
    break;
  }
  case TAG_Just: {
    V v_a_246 = heff_field(v_t_244, 0);
    heff_take_n(v_t_244, 1ULL, 1);
    switch (heff_tag_of(v_x2_243)) {
    case TAG_Nothing: {
      heff_drop(v_a_246);
      v_t_248 = NTAG(TAG_False);
      break;
    }
    case TAG_Just: {
      V v_b_247 = heff_field(v_x2_243, 0);
      heff_take_n(v_x2_243, 1ULL, 1);
      v_t_248 = heff_strEq(v_a_246, v_b_247);
      break;
    }
    default: heff_nomatch(v_x2_243);
    }
    break;
  }
  default: heff_nomatch(v_t_244);
  }
  if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
    heff_drop(v_t_248);
    V v_t_249 = heff_take_field(v_i_242, 3);
    V v_t_2417;
    if ((heff_dup(v_t_249) == NTAG(TAG_True))) {
      heff_drop(v_t_249);
      V v_x2_2410 = heff_tag_n(TAG_Just, 1, (V[]){heff_dup(heff_rfield(v_i_242, 1))});
      V v_t_2411 = heff_get_n(v_t_240, 1, 3);
      switch (heff_tag_of(v_t_2411)) {
      case TAG_Nothing: {
        switch (heff_tag_of(v_x2_2410)) {
        case TAG_Nothing: {
          v_t_2417 = NTAG(TAG_True);
          break;
        }
        case TAG_Just: {
          heff_take_n(v_x2_2410, 0ULL, 1);
          v_t_2417 = NTAG(TAG_False);
          break;
        }
        default: heff_nomatch(v_x2_2410);
        }
        break;
      }
      case TAG_Just: {
        V v_a_2413 = heff_field(v_t_2411, 0);
        heff_take_n(v_t_2411, 1ULL, 1);
        switch (heff_tag_of(v_x2_2410)) {
        case TAG_Nothing: {
          heff_drop(v_a_2413);
          v_t_2417 = NTAG(TAG_False);
          break;
        }
        case TAG_Just: {
          V v_b_2414 = heff_field(v_x2_2410, 0);
          heff_take_n(v_x2_2410, 1ULL, 1);
          v_t_2417 = heff_strEq(v_a_2413, v_b_2414);
          break;
        }
        default: heff_nomatch(v_x2_2410);
        }
        break;
      }
      default: heff_nomatch(v_t_2411);
      }
    } else {
      heff_drop(v_t_249);
      V v_t_2415 = heff_get_n(v_t_240, 1, 3);
      switch (heff_tag_of(v_t_2415)) {
      case TAG_Nothing: {
        v_t_2417 = NTAG(TAG_True);
        break;
      }
      case TAG_Just: {
        heff_take_n(v_t_2415, 0ULL, 1);
        v_t_2417 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_t_2415);
      }
    }
    if ((heff_dup(v_t_2417) == NTAG(TAG_True))) {
      heff_drop(v_t_2417);
      V v_x_2418 = heff_get_n(heff_dup(heff_rfield(v_i_242, 0)), 0, 2);
      V v_t_2419 = heff_get_n(heff_dup(heff_rfield(v_i_242, 0)), 1, 2);
      V v_y_2420 = heff_intSub(v_t_2419, heff_strLength(v_name_241));
      V v_t_2422;
      if (heff_intLe_c(heff_dup(v_x_2418), heff_dup(v_y_2420))) {
        heff_drop(v_x_2418);
        v_t_2422 = v_y_2420;
      } else {
        heff_drop(v_y_2420);
        v_t_2422 = v_x_2418;
      }
      V v_t_2423 = heff_get_n(heff_get_n(v_i_242, 0, 5), 1, 2);
      return heff_tag_n(TAG_Just, 1, (V[]){heff_rec_n(2, shape_start__end, (V[]){v_t_2422, v_t_2423})});
    } else {
      heff_drop(v_name_241);
      heff_drop_rec(v_i_242, 5);
      heff_drop(v_t_2417);
      return NTAG(TAG_Nothing);
    }
  } else {
    heff_drop_rec(v_t_240, 3);
    heff_drop(v_name_241);
    heff_drop_rec(v_i_242, 5);
    heff_drop(v_t_248);
    return NTAG(TAG_Nothing);
  }
}
V g_heff_2ebuild_2equery_2euseOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2equery_2euseOf(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ebuild_2equery_2ewordsOf_str0, 1, " ");
HEFF_LIT(g_heff_2ebuild_2equery_2ewordsOf_str1, 1, " ");
HEFF_LIT(g_heff_2ebuild_2equery_2ewordsOf_str2, 1, " ");
Clo g_heff_2ebuild_2equery_2ewordsOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2ewordsOf_entry, 4, 0};

V g_heff_2ebuild_2equery_2ewordsOf(V v_base_240, V v_line_241, V v_i_242, V v_acc_243) {
top: ;
  if (heff_intLe_c(heff_strLength_lent(v_line_241, 0), heff_dup(v_i_242))) {
    heff_drop(v_base_240);
    heff_drop(v_line_241);
    heff_drop(v_i_242);
    return (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_243));
  } else {
    if (heff_intEq_c(heff_strByteAt_lent(v_line_241, v_i_242, 0), MK_INT(32LL))) {
      V t_0 = v_base_240;
      V t_1 = v_line_241;
      V t_2 = heff_intAdd(v_i_242, MK_INT(1LL));
      V t_3 = v_acc_243;
      v_base_240 = t_0;
      v_line_241 = t_1;
      v_i_242 = t_2;
      v_acc_243 = t_3;
      goto top;
    } else {
      V v_j_246 = (g_prelude_2estrFind(((V)&g_heff_2ebuild_2equery_2ewordsOf_str0), heff_dup(v_line_241), heff_dup(v_i_242)));
      V v_t_248;
      if (heff_intLt_c(heff_dup(v_j_246), MK_INT(0LL))) {
        heff_drop(v_j_246);
        v_t_248 = heff_strLength_lent(v_line_241, 0);
      } else {
        v_t_248 = v_j_246;
      }
      V v_j_249 = (g_prelude_2estrFind(((V)&g_heff_2ebuild_2equery_2ewordsOf_str1), heff_dup(v_line_241), heff_dup(v_i_242)));
      V v_t_2411;
      if (heff_intLt_c(heff_dup(v_j_249), MK_INT(0LL))) {
        heff_drop(v_j_249);
        v_t_2411 = heff_strLength_lent(v_line_241, 0);
      } else {
        v_t_2411 = v_j_249;
      }
      V v_j_2412 = (g_prelude_2estrFind(((V)&g_heff_2ebuild_2equery_2ewordsOf_str2), heff_dup(v_line_241), heff_dup(v_i_242)));
      V v_t_2414;
      if (heff_intLt_c(heff_dup(v_j_2412), MK_INT(0LL))) {
        heff_drop(v_j_2412);
        v_t_2414 = heff_strLength_lent(v_line_241, 0);
      } else {
        v_t_2414 = v_j_2412;
      }
      V v_e_2415 = heff_intAdd(heff_dup(v_base_240), v_t_2414);
      V v_t_2416 = heff_rec_n(2, shape_start__end, (V[]){heff_intAdd(heff_dup(v_base_240), heff_dup(v_i_242)), v_e_2415});
      V v_t_2417 = heff_rec_n(2, shape_text__span, (V[]){heff_strSlice_lent(v_line_241, v_i_242, v_t_2411, 6), v_t_2416});
      V t_0 = v_base_240;
      V t_1 = v_line_241;
      V t_2 = v_t_248;
      V t_3 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2417, v_acc_243});
      v_base_240 = t_0;
      v_line_241 = t_1;
      v_i_242 = t_2;
      v_acc_243 = t_3;
      goto top;
    }
  }
}
V g_heff_2ebuild_2equery_2ewordsOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2equery_2ewordsOf(a[0], a[1], a[2], a[3]);
}
HEFF_LIT(g_heff_2ebuild_2equery_2efixityWords_str0, 6, "infixl");
HEFF_LIT(g_heff_2ebuild_2equery_2efixityWords_str1, 6, "infixr");
HEFF_LIT(g_heff_2ebuild_2equery_2efixityWords_str2, 5, "infix");
Clo g_heff_2ebuild_2equery_2efixityWords_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2efixityWords_entry, 2, 0};

V g_heff_2ebuild_2equery_2efixityWords(V v_name_240, V v_ws_241) {
top: ;
  switch (heff_tag_of(v_ws_241)) {
  case TAG_Nil: {
    heff_drop(v_name_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_w_242 = heff_dup(heff_field(v_ws_241, 0));
    if (heff_strEq_c(heff_dup(heff_rfield(v_w_242, 0)), ((V)&g_heff_2ebuild_2equery_2efixityWords_str0))) {
      heff_drop_rec(v_w_242, 2);
      HEFF_LAST return g_list_2emap_24f990982947x2126256822(v_name_240, v_ws_241);
    } else {
      if (heff_strEq_c(heff_dup(heff_rfield(v_w_242, 0)), ((V)&g_heff_2ebuild_2equery_2efixityWords_str1))) {
        heff_drop_rec(v_w_242, 2);
        HEFF_LAST return g_list_2emap_24f990982947x2126256822(v_name_240, v_ws_241);
      } else {
        if (heff_strEq_c(heff_get_n(v_w_242, 0, 2), ((V)&g_heff_2ebuild_2equery_2efixityWords_str2))) {
          HEFF_LAST return g_list_2emap_24f990982947x2126256822(v_name_240, v_ws_241);
        } else {
          heff_drop(v_name_240);
          heff_drop_tag(v_ws_241, 2);
          return NTAG(TAG_Nil);
        }
      }
    }
  }
  default: return heff_nomatch(v_ws_241);
  }
}
V g_heff_2ebuild_2equery_2efixityWords_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2equery_2efixityWords(a[0], a[1]);
}
Clo g_heff_2ebuild_2equery_2ewordsIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2ewordsIn_entry, 6, 0};

V g_heff_2ebuild_2equery_2ewordsIn(V v_fits_240, V v_name_241, V v_src_242, V v_i_243, V v_to_244, V v_acc_245) {
top: ;
  V v_j_246 = (g_prelude_2estrFind(heff_dup(v_name_241), heff_dup(v_src_242), v_i_243));
  V v_t_248;
  if (heff_intLt_c(heff_dup(v_j_246), MK_INT(0LL))) {
    heff_drop(v_j_246);
    v_t_248 = NTAG(TAG_Nothing);
  } else {
    v_t_248 = heff_tag_n(TAG_Just, 1, (V[]){v_j_246});
  }
  switch (heff_tag_of(v_t_248)) {
  case TAG_Nothing: {
    heff_drop(v_fits_240);
    heff_drop(v_name_241);
    heff_drop(v_src_242);
    heff_drop(v_to_244);
    return (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_245));
  }
  case TAG_Just: {
    V v_p_249 = heff_field(v_t_248, 0);
    heff_take_n(v_t_248, 1ULL, 1);
    V v_t_2410 = heff_intAdd(heff_dup(v_p_249), heff_strLength_lent(v_name_241, 0));
    if (heff_intLe_c(v_t_2410, heff_dup(v_to_244))) {
      V v_t_2412 = (g_heff_2ebuild_2equery_2ewordAt(heff_dup(v_src_242), heff_dup(v_p_249), heff_dup(v_name_241)));
      V v_t_2415;
      if ((heff_dup(v_t_2412) == NTAG(TAG_True))) {
        heff_drop(v_t_2412);
        V v_t_2413 = heff_tr(heff_call(heff_dup(v_fits_240), 1, (V[]){heff_dup(v_p_249)}));
        if ((heff_dup(v_t_2413) == NTAG(TAG_True))) {
          heff_drop(v_t_2413);
          V v_t_2414 = heff_intAdd(heff_dup(v_p_249), heff_strLength_lent(v_name_241, 0));
          v_t_2415 = heff_tag_n(TAG_Cons, 2, (V[]){heff_rec_n(2, shape_start__end, (V[]){heff_dup(v_p_249), v_t_2414}), v_acc_245});
        } else {
          heff_drop(v_t_2413);
          v_t_2415 = v_acc_245;
        }
      } else {
        heff_drop(v_t_2412);
        v_t_2415 = v_acc_245;
      }
      V t_0 = v_fits_240;
      V t_1 = v_name_241;
      V t_2 = v_src_242;
      V t_3 = heff_intAdd(v_p_249, MK_INT(1LL));
      V t_4 = v_to_244;
      V t_5 = v_t_2415;
      v_fits_240 = t_0;
      v_name_241 = t_1;
      v_src_242 = t_2;
      v_i_243 = t_3;
      v_to_244 = t_4;
      v_acc_245 = t_5;
      goto top;
    } else {
      heff_drop(v_fits_240);
      heff_drop(v_name_241);
      heff_drop(v_src_242);
      heff_drop(v_to_244);
      heff_drop(v_p_249);
      return (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_245));
    }
  }
  default: return heff_nomatch(v_t_248);
  }
}
V g_heff_2ebuild_2equery_2ewordsIn_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2equery_2ewordsIn(a[0], a[1], a[2], a[3], a[4], a[5]);
}
Clo g_heff_2ebuild_2equery_2elineStartOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2elineStartOf_entry, 2, 0};

V g_heff_2ebuild_2equery_2elineStartOf(V v_src_240, V v_p_241) {
top: ;
  if (heff_intLt_c(MK_INT(0LL), heff_dup(v_p_241))) {
    V v_t_243 = heff_strByteAt(heff_dup(v_src_240), heff_intSub(heff_dup(v_p_241), MK_INT(1LL)));
    if (heff_intEq_c(v_t_243, MK_INT(10LL))) {
      heff_drop(v_src_240);
      return v_p_241;
    } else {
      V t_0 = v_src_240;
      V t_1 = heff_intSub(v_p_241, MK_INT(1LL));
      v_src_240 = t_0;
      v_p_241 = t_1;
      goto top;
    }
  } else {
    heff_drop(v_src_240);
    return v_p_241;
  }
}
V g_heff_2ebuild_2equery_2elineStartOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2equery_2elineStartOf(a[0], a[1]);
}
Clo g_heff_2ebuild_2equery_2einStringGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2einStringGo_entry, 4, 0};

V g_heff_2ebuild_2equery_2einStringGo(V v_src_240, V v_i_241, V v_p_242, V v_inside_243) {
top: ;
  if (heff_intLe_c(heff_dup(v_p_242), heff_dup(v_i_241))) {
    heff_drop(v_src_240);
    heff_drop(v_i_241);
    heff_drop(v_p_242);
    return v_inside_243;
  } else {
    if ((heff_dup(v_inside_243) == NTAG(TAG_True))) {
      if (heff_intEq_c(heff_strByteAt_lent(v_src_240, v_i_241, 0), MK_INT(92LL))) {
        V t_0 = v_src_240;
        V t_1 = heff_intAdd(v_i_241, MK_INT(2LL));
        V t_2 = v_p_242;
        V t_3 = v_inside_243;
        v_src_240 = t_0;
        v_i_241 = t_1;
        v_p_242 = t_2;
        v_inside_243 = t_3;
        goto top;
      } else {
        if (heff_intEq_c(heff_strByteAt_lent(v_src_240, v_i_241, 0), MK_INT(34LL))) {
          V v_t_247 = heff_bool(!(heff_dup(v_inside_243) == NTAG(TAG_True)));
          heff_drop(v_inside_243);
          V t_0 = v_src_240;
          V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
          V t_2 = v_p_242;
          V t_3 = v_t_247;
          v_src_240 = t_0;
          v_i_241 = t_1;
          v_p_242 = t_2;
          v_inside_243 = t_3;
          goto top;
        } else {
          V t_0 = v_src_240;
          V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
          V t_2 = v_p_242;
          V t_3 = v_inside_243;
          v_src_240 = t_0;
          v_i_241 = t_1;
          v_p_242 = t_2;
          v_inside_243 = t_3;
          goto top;
        }
      }
    } else {
      if (heff_intEq_c(heff_strByteAt_lent(v_src_240, v_i_241, 0), MK_INT(34LL))) {
        V v_t_249 = heff_bool(!(heff_dup(v_inside_243) == NTAG(TAG_True)));
        heff_drop(v_inside_243);
        V t_0 = v_src_240;
        V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
        V t_2 = v_p_242;
        V t_3 = v_t_249;
        v_src_240 = t_0;
        v_i_241 = t_1;
        v_p_242 = t_2;
        v_inside_243 = t_3;
        goto top;
      } else {
        V t_0 = v_src_240;
        V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
        V t_2 = v_p_242;
        V t_3 = v_inside_243;
        v_src_240 = t_0;
        v_i_241 = t_1;
        v_p_242 = t_2;
        v_inside_243 = t_3;
        goto top;
      }
    }
  }
}
V g_heff_2ebuild_2equery_2einStringGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2equery_2einStringGo(a[0], a[1], a[2], a[3]);
}
Clo g_heff_2ebuild_2equery_2espacesFrom_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2espacesFrom_entry, 2, 0};

V g_heff_2ebuild_2equery_2espacesFrom(V v_src_240, V v_i_241) {
top: ;
  if (heff_intEq_c(heff_strByteAt_lent(v_src_240, v_i_241, 0), MK_INT(32LL))) {
    V t_0 = v_src_240;
    V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
    v_src_240 = t_0;
    v_i_241 = t_1;
    goto top;
  } else {
    heff_drop(v_src_240);
    return v_i_241;
  }
}
V g_heff_2ebuild_2equery_2espacesFrom_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2equery_2espacesFrom(a[0], a[1]);
}
Clo g_heff_2ebuild_2equery_2espacesBefore_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2espacesBefore_entry, 2, 0};

V g_heff_2ebuild_2equery_2espacesBefore(V v_src_240, V v_i_241) {
top: ;
  if (heff_intLt_c(MK_INT(0LL), heff_dup(v_i_241))) {
    V v_t_243 = heff_strByteAt(heff_dup(v_src_240), heff_intSub(heff_dup(v_i_241), MK_INT(1LL)));
    if (heff_intEq_c(v_t_243, MK_INT(32LL))) {
      V t_0 = v_src_240;
      V t_1 = heff_intSub(v_i_241, MK_INT(1LL));
      v_src_240 = t_0;
      v_i_241 = t_1;
      goto top;
    } else {
      heff_drop(v_src_240);
      return v_i_241;
    }
  } else {
    heff_drop(v_src_240);
    return v_i_241;
  }
}
V g_heff_2ebuild_2equery_2espacesBefore_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2equery_2espacesBefore(a[0], a[1]);
}
Clo g_heff_2ebuild_2equery_2eisLabelAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2eisLabelAt_entry, 3, 0};

V g_heff_2ebuild_2equery_2eisLabelAt(V v_src_240, V v_p_241, V v_n_242) {
top: ;
  V v_t_243 = (g_heff_2ebuild_2equery_2espacesFrom(heff_dup(v_src_240), heff_intAdd(heff_dup(v_p_241), heff_dup(v_n_242))));
  V v_ret_24bool = heff_bool((heff_intEq_c(heff_strByteAt_lent(v_src_240, v_t_243, 0), MK_INT(61LL)) && ({ V v_t_245 = (g_heff_2ebuild_2equery_2espacesFrom(heff_dup(v_src_240), heff_intAdd(heff_dup(v_p_241), heff_dup(v_n_242)))); int c_ = ({ V v_x_246 = heff_strByteAt(heff_dup(v_src_240), heff_intAdd(heff_dup(v_t_245), MK_INT(1LL))); int c_ = (heff_intEq_c(heff_dup(v_x_246), MK_INT(61LL)) ? 0 : ({ V v_x_248 = (g_heff_2ebuild_2equery_2espacesBefore(heff_dup(v_src_240), heff_dup(v_p_241))); int c_ = (heff_intLt_c(MK_INT(0LL), heff_dup(v_x_248)) && ({ V v_t_2410 = (g_heff_2ebuild_2equery_2espacesBefore(heff_dup(v_src_240), heff_dup(v_p_241))); int c_ = ({ V v_t_2411 = heff_strByteAt(heff_dup(v_src_240), heff_intSub(heff_dup(v_t_2410), MK_INT(1LL))); int c_ = (heff_intEq_c(heff_dup(v_t_2411), MK_INT(123LL)) || ({ V v_t_2413 = (g_heff_2ebuild_2equery_2espacesBefore(heff_dup(v_src_240), heff_dup(v_p_241))); int c_ = ({ V v_t_2414 = heff_strByteAt(heff_dup(v_src_240), heff_intSub(heff_dup(v_t_2413), MK_INT(1LL))); int c_ = heff_intEq_c(heff_dup(v_t_2414), MK_INT(44LL)); heff_drop(v_t_2414); c_; }); heff_drop(v_t_2413); c_; })); heff_drop(v_t_2411); c_; }); heff_drop(v_t_2410); c_; })); heff_drop(v_x_248); c_; })); heff_drop(v_x_246); c_; }); heff_drop(v_t_245); c_; })));
  heff_drop(v_src_240);
  heff_drop(v_p_241);
  heff_drop(v_n_242);
  heff_drop(v_t_243);
  return v_ret_24bool;
}
V g_heff_2ebuild_2equery_2eisLabelAt_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2equery_2eisLabelAt(a[0], a[1], a[2]);
}
Clo g_heff_2ebuild_2equery_2eexpectedFits_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2eexpectedFits_entry, 4, 0};

V g_heff_2ebuild_2equery_2eexpectedFits(V v_t_240, V v_src_241, V v_n_242, V v_p_243) {
top: ;
  V v_t_244 = (g_heff_2ebuild_2equery_2elineStartOf(heff_dup(v_src_241), heff_dup(v_p_243)));
  V v_x1_245 = (g_heff_2ebuild_2equery_2einStringGo(heff_dup(v_src_241), v_t_244, heff_dup(v_p_243), NTAG(TAG_False)));
  V v_t_246 = heff_bool(!(heff_dup(v_x1_245) == NTAG(TAG_True)));
  heff_drop(v_x1_245);
  if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
    heff_drop(v_t_246);
    V v_t_247 = heff_get_n(v_t_240, 1, 3);
    switch (heff_tag_of(v_t_247)) {
    case TAG_Nothing: {
      V v_x1_248 = (g_heff_2ebuild_2equery_2eisLabelAt(v_src_241, v_p_243, v_n_242));
      V v_ret_24bool = heff_bool(!(heff_dup(v_x1_248) == NTAG(TAG_True)));
      heff_drop(v_x1_248);
      return v_ret_24bool;
    }
    case TAG_Just: {
      V v_m_249 = heff_field(v_t_247, 0);
      heff_take_n(v_t_247, 1ULL, 1);
      V v_ret_24bool = heff_bool((heff_intLe_c(MK_INT(65LL), heff_strByteAt_lent(v_m_249, MK_INT(0LL), 2)) ? (heff_intLe_c(heff_strByteAt_lent(v_m_249, MK_INT(0LL), 2), MK_INT(90LL)) ? ({ V v_x1_2412 = (g_heff_2ebuild_2equery_2eisLabelAt(heff_dup(v_src_241), heff_dup(v_p_243), heff_dup(v_n_242))); int c_ = !(heff_dup(v_x1_2412) == NTAG(TAG_True)); heff_drop(v_x1_2412); c_; }) : ({ V v_t_2413 = (g_heff_2ebuild_2equery_2eisLabelAt(heff_dup(v_src_241), heff_dup(v_p_243), heff_dup(v_n_242))); int c_ = ((heff_dup(v_t_2413) == NTAG(TAG_True)) || (heff_intLt_c(MK_INT(0LL), heff_dup(v_p_243)) && ({ V v_t_2415 = heff_strByteAt(heff_dup(v_src_241), heff_intSub(heff_dup(v_p_243), MK_INT(1LL))); int c_ = heff_intEq_c(heff_dup(v_t_2415), MK_INT(46LL)); heff_drop(v_t_2415); c_; }))); heff_drop(v_t_2413); c_; })) : ({ V v_t_2416 = (g_heff_2ebuild_2equery_2eisLabelAt(heff_dup(v_src_241), heff_dup(v_p_243), heff_dup(v_n_242))); int c_ = ((heff_dup(v_t_2416) == NTAG(TAG_True)) || (heff_intLt_c(MK_INT(0LL), heff_dup(v_p_243)) && ({ V v_t_2418 = heff_strByteAt(heff_dup(v_src_241), heff_intSub(heff_dup(v_p_243), MK_INT(1LL))); int c_ = heff_intEq_c(heff_dup(v_t_2418), MK_INT(46LL)); heff_drop(v_t_2418); c_; }))); heff_drop(v_t_2416); c_; })));
      heff_drop(v_src_241);
      heff_drop(v_n_242);
      heff_drop(v_p_243);
      heff_drop(v_m_249);
      return v_ret_24bool;
    }
    default: return heff_nomatch(v_t_247);
    }
  } else {
    heff_drop_rec(v_t_240, 3);
    heff_drop(v_src_241);
    heff_drop(v_n_242);
    heff_drop(v_p_243);
    heff_drop(v_t_246);
    return NTAG(TAG_False);
  }
}
V g_heff_2ebuild_2equery_2eexpectedFits_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2equery_2eexpectedFits(a[0], a[1], a[2], a[3]);
}
HEFF_LIT(g_heff_2ebuild_2equery_2eexpectedIn_str0, 8, "-- | >>>");
HEFF_LIT(g_heff_2ebuild_2equery_2eexpectedIn_str1, 8, "-- | >>>");
V g_heff_2ebuild_2equery_2eexpectedIn_lam1(V self, V *args);
V g_heff_2ebuild_2equery_2eexpectedIn_lam0(V self, V *args);
Clo g_heff_2ebuild_2equery_2eexpectedIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2eexpectedIn_entry, 3, 0};

V g_heff_2ebuild_2equery_2eexpectedIn(V v_t_240, V v_name_241, V v_c_242) {
top: ;
  V v_t_243 = heff_get_n(heff_dup(heff_rfield(v_c_242, 5)), 4, 9);
  V v_t_244 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_t_243));
  return ({ V a_0 = heff_clo_n(g_heff_2ebuild_2equery_2eexpectedIn_lam0, 2, 3, (V[]){v_c_242, v_t_240, v_name_241}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_244; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_244); r_; });
}
V g_heff_2ebuild_2equery_2eexpectedIn_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2equery_2eexpectedIn(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2equery_2eexpectedIn_lam1(V self, V *args) {
  V v_p_2417 = args[0];
  V v_t_240 = heff_env(self)[0];
  V v_c_242 = heff_env(self)[1];
  V v_name_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2ebuild_2equery_2eexpectedFits(v_t_240, heff_get_n(v_c_242, 3, 13), heff_strLength(v_name_241), v_p_2417));
}
V g_heff_2ebuild_2equery_2eexpectedIn_lam0(V self, V *args) {
  V v_acc_245 = args[0];
  V v_x_246 = args[1];
  V v_c_242 = heff_env(self)[0];
  V v_t_240 = heff_env(self)[1];
  V v_name_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_src_247 = heff_dup(heff_rfield(v_c_242, 3));
  V v_sp_248 = heff_dup(heff_rfield(v_x_246, 0));
  V v_start_249 = heff_take_field(v_sp_248, 0);
  V v_t_2410 = heff_strSlice(heff_dup(v_src_247), heff_dup(v_start_249), heff_intAdd(v_start_249, MK_INT(8LL)));
  V v_t_2411 = ({ V b_0 = heff_strEq(v_t_2410, ((V)&g_heff_2ebuild_2equery_2eexpectedIn_str0)); V a_1 = v_src_247; V a_2 = heff_get_n(v_sp_248, 1, 2); V r_ = (g_heff_2ebuild_2edriver_2eexpectAfter(b_0, a_1, a_2)); heff_drop(b_0); r_; });
  V v_src_2412 = heff_dup(heff_rfield(v_c_242, 3));
  V v_sp_2413 = heff_get_n(v_x_246, 0, 2);
  V v_start_2414 = heff_take_field(v_sp_2413, 0);
  V v_t_2415 = heff_strSlice(heff_dup(v_src_2412), heff_dup(v_start_2414), heff_intAdd(v_start_2414, MK_INT(8LL)));
  V v_t_2416 = ({ V b_0 = heff_strEq(v_t_2415, ((V)&g_heff_2ebuild_2equery_2eexpectedIn_str1)); V a_1 = v_src_2412; V a_2 = heff_get_n(v_sp_2413, 1, 2); V r_ = (g_heff_2ebuild_2edriver_2eexpectAfter(b_0, a_1, a_2)); heff_drop(b_0); r_; });
  V v_t_2418 = (g_heff_2ebuild_2equery_2ewordsIn(heff_clo_n(g_heff_2ebuild_2equery_2eexpectedIn_lam1, 1, 3, (V[]){v_t_240, heff_dup(v_c_242), heff_dup(v_name_241)}), v_name_241, heff_get_n(v_c_242, 3, 13), heff_get_n(v_t_2411, 1, 3), heff_get_n(v_t_2416, 2, 3), NTAG(TAG_Nil)));
  return (g_prelude_2e_2b_2b(v_t_2418, v_acc_245));
}
HEFF_LIT(g_heff_2ebuild_2equery_2emoreIn_str0, 1, "\012");
V g_heff_2ebuild_2equery_2emoreIn_lam0(V self, V *args);
Clo g_heff_2ebuild_2equery_2emoreIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2emoreIn_entry, 3, 0};

V g_heff_2ebuild_2equery_2emoreIn(V v_t_240, V v_name_241, V v_c_242) {
top: ;
  V v_x1_243 = (g_heff_2ebuild_2equery_2eisNameChar(heff_strByteAt_lent(v_name_241, MK_INT(0LL), 2)));
  V v_t_246;
  if ((heff_dup(v_x1_243) == NTAG(TAG_True))) {
    heff_drop(v_x1_243);
    v_t_246 = NTAG(TAG_False);
  } else {
    heff_drop(v_x1_243);
    V v_t_244 = heff_dup(heff_rfield(v_t_240, 1));
    switch (heff_tag_of(v_t_244)) {
    case TAG_Nothing: {
      v_t_246 = NTAG(TAG_True);
      break;
    }
    case TAG_Just: {
      heff_take_n(v_t_244, 0ULL, 1);
      v_t_246 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_t_244);
    }
  }
  V v_t_2418;
  if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
    heff_drop(v_t_246);
    V v_src_247 = heff_dup(heff_rfield(v_c_242, 3));
    V v_t_248 = heff_intSub(heff_strLength_lent(v_src_247, 0), MK_INT(1LL));
    V v_t_249 = (g_list_2efoldl_24f765463553x1160475073(NTAG(TAG_Nil), MK_INT(0LL), v_src_247, MK_INT(1LL), MK_INT(10LL), MK_INT(0LL), v_t_248));
    v_t_2418 = ({ V a_0 = heff_clo_n(g_heff_2ebuild_2equery_2emoreIn_lam0, 2, 2, (V[]){heff_dup(v_c_242), heff_dup(v_name_241)}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_249; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_249); r_; });
  } else {
    heff_drop(v_t_246);
    v_t_2418 = NTAG(TAG_Nil);
  }
  V v_x1_2419 = (g_heff_2ebuild_2equery_2eisNameChar(heff_strByteAt_lent(v_name_241, MK_INT(0LL), 2)));
  V v_t_2420;
  if ((heff_dup(v_x1_2419) == NTAG(TAG_True))) {
    heff_drop(v_x1_2419);
    v_t_2420 = (g_heff_2ebuild_2equery_2eexpectedIn(v_t_240, v_name_241, v_c_242));
  } else {
    heff_drop_rec(v_t_240, 3);
    heff_drop(v_name_241);
    heff_drop_rec(v_c_242, 13);
    heff_drop(v_x1_2419);
    v_t_2420 = NTAG(TAG_Nil);
  }
  return (g_prelude_2e_2b_2b(v_t_2418, v_t_2420));
}
V g_heff_2ebuild_2equery_2emoreIn_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2equery_2emoreIn(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2equery_2emoreIn_lam0(V self, V *args) {
  V v_acc_2410 = args[0];
  V v_x_2411 = args[1];
  V v_c_242 = heff_env(self)[0];
  V v_name_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_src_2412 = heff_get_n(v_c_242, 3, 13);
  V v_j_2413 = (g_prelude_2estrFind(((V)&g_heff_2ebuild_2equery_2emoreIn_str0), heff_dup(v_src_2412), heff_dup(v_x_2411)));
  V v_t_2415;
  if (heff_intLt_c(heff_dup(v_j_2413), MK_INT(0LL))) {
    heff_drop(v_j_2413);
    v_t_2415 = heff_strLength_lent(v_src_2412, 0);
  } else {
    v_t_2415 = v_j_2413;
  }
  V v_t_2416 = (g_heff_2ebuild_2equery_2ewordsOf(heff_dup(v_x_2411), heff_strSlice(v_src_2412, v_x_2411, v_t_2415), MK_INT(0LL), NTAG(TAG_Nil)));
  V v_t_2417 = (g_heff_2ebuild_2equery_2efixityWords(v_name_241, v_t_2416));
  return (g_prelude_2e_2b_2b(v_t_2417, v_acc_2410));
}
V g_heff_2ebuild_2equery_2einFileFound_lam0(V self, V *args);
Clo g_heff_2ebuild_2equery_2einFileFound_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2einFileFound_entry, 5, 0};

V g_heff_2ebuild_2equery_2einFileFound(V v_t_240, V v_name_241, V v_c_242, V v_ss_243, V v_found_244) {
top: ;
  V v_defs_245 = (g_list_2emap_24s388004800x1261967008(v_ss_243));
  V v_t_248;
  switch (heff_tag_of(v_found_244)) {
  case TAG_Nil: {
    heff_drop(v_t_240);
    heff_drop(v_name_241);
    v_t_248 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Cons: {
    v_t_248 = (g_heff_2ebuild_2equery_2emoreIn(v_t_240, v_name_241, heff_dup(v_c_242)));
    break;
  }
  default: heff_nomatch(v_found_244);
  }
  V v_spans_249 = (g_prelude_2e_2b_2b(v_found_244, v_t_248));
  V v_t_2410 = (g_list_2esortBy_24s1768199906x1695529242(v_spans_249));
  V v_t_2411 = (g_heff_2ebuild_2equery_2enubByStart(v_t_2410));
  return (g_list_2emap(heff_clo_n(g_heff_2ebuild_2equery_2einFileFound_lam0, 1, 2, (V[]){v_defs_245, v_c_242}), v_t_2411));
}
V g_heff_2ebuild_2equery_2einFileFound_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2equery_2einFileFound(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ebuild_2equery_2einFileFound_lam0(V self, V *args) {
  V v_sp_2412 = args[0];
  V v_defs_245 = heff_env(self)[0];
  V v_c_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_defines_2413 = ({ V a_0 = heff_dup(v_sp_2412); V a_1 = v_defs_245; V r_ = (g_list_2eany_24s1711939327x1502975912(a_0, a_1)); heff_drop(v_defs_245); r_; });
  return heff_rec_n(4, shape_path__source__span__defines, (V[]){heff_dup(heff_rfield(v_c_242, 1)), heff_get_n(v_c_242, 3, 13), v_sp_2412, v_defines_2413});
}
V g_heff_2ebuild_2equery_2einFileSites_lam0(V self, V *args);
V g_heff_2ebuild_2equery_2einFileSites_lam1(V self, V *args);
Clo g_heff_2ebuild_2equery_2einFileSites_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2einFileSites_entry, 4, 0};

V g_heff_2ebuild_2equery_2einFileSites(V v_t_240, V v_name_241, V v_c_242, V v_ss_243) {
top: ;
  V v_t_244 = heff_get_n(heff_dup(heff_rfield(v_c_242, 5)), 7, 9);
  V v_t_246 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2equery_2einFileSites_lam0, 1, 2, (V[]){heff_dup(v_t_240), heff_dup(v_name_241)}), v_t_244));
  V v_t_247 = (g_heff_2ebuild_2equery_2ecatMaybesQ(v_t_246));
  V v_t_248 = (g_list_2emap_24s388004800x1261967008(heff_dup(v_ss_243)));
  V v_t_249 = (g_list_2efoldl_24s44351024x1408738471(heff_dup(g_heff_2eelab_2elocals_2enone_get()), heff_rfield(v_c_242, 4)));
  V v_ls_2410 = (g_heff_2eelab_2elocals_2elocalsOf(v_t_249));
  V v_t_2412 = (g_list_2emap_24f2063070488x1806431062(heff_clo_n(g_heff_2ebuild_2equery_2einFileSites_lam1, 1, 1, (V[]){heff_dup(v_ss_243)}), heff_get_n(v_ls_2410, 1, 2)));
  V v_t_2413 = (g_prelude_2e_2b_2b(v_t_248, v_t_2412));
  V v_t_2414 = (g_prelude_2e_2b_2b(v_t_247, v_t_2413));
  return (g_heff_2ebuild_2equery_2einFileFound(v_t_240, v_name_241, v_c_242, v_ss_243, v_t_2414));
}
V g_heff_2ebuild_2equery_2einFileSites_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2equery_2einFileSites(a[0], a[1], a[2], a[3]);
}
V g_heff_2ebuild_2equery_2einFileSites_lam0(V self, V *args) {
  V v_i_245 = args[0];
  V v_t_240 = heff_env(self)[0];
  V v_name_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2ebuild_2equery_2euseOf(v_t_240, v_name_241, v_i_245));
}
V g_heff_2ebuild_2equery_2einFileSites_lam1(V self, V *args) {
  V v_f_2411 = args[0];
  V v_ss_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_f_2411; V a_1 = v_ss_243; V r_ = (g_list_2eany_24s406396256x713021373(a_0, a_1)); heff_drop(v_ss_243); r_; });
}
V g_heff_2ebuild_2equery_2eoccurrences_lam1(V self, V *args);
V g_heff_2ebuild_2equery_2eoccurrences_lam2(V self, V *args);
V g_heff_2ebuild_2equery_2eoccurrences_lam0(V self, V *args);
Clo g_heff_2ebuild_2equery_2eoccurrences_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2eoccurrences_entry, 3, 0};

V g_heff_2ebuild_2equery_2eoccurrences(V v_program_240, V v_t_241, V v_name_242) {
top: ;
  V v_t_243 = heff_dup(heff_rfield(v_t_241, 2));
  switch (heff_tag_of(v_t_243)) {
  case TAG_Nothing: {
    V v_t_244 = (g_list_2efoldl_24f297647854x479783049(NTAG(TAG_Nil), v_program_240));
    return ({ V a_0 = heff_clo_n(g_heff_2ebuild_2equery_2eoccurrences_lam0, 2, 2, (V[]){v_t_241, v_name_242}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_244; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_244); r_; });
  }
  case TAG_Just: {
    V v_b_2415 = heff_field(v_t_243, 0);
    heff_take_n(v_t_243, 1ULL, 1);
    heff_drop(v_name_242);
    V v_t_2416 = ({ V a_0 = v_t_241; V a_1 = v_program_240; V r_ = (g_list_2efind_24s358915833x209356919(a_0, a_1)); heff_drop(v_program_240); r_; });
    switch (heff_tag_of(v_t_2416)) {
    case TAG_Nothing: {
      heff_drop(v_b_2415);
      return NTAG(TAG_Nil);
    }
    case TAG_Just: {
      V v_c_2417 = heff_field(v_t_2416, 0);
      heff_take_n(v_t_2416, 1ULL, 1);
      V v_t_2418 = (g_list_2efoldl_24s44351024x1408738471(heff_dup(g_heff_2eelab_2elocals_2enone_get()), heff_rfield(v_c_2417, 4)));
      V v_t_2419 = (g_heff_2eelab_2elocals_2elocalsOf(v_t_2418));
      V v_t_2420 = ({ V a_0 = heff_dup(v_b_2415); V b_1 = heff_get_n(v_t_2419, 0, 2); V r_ = (g_list_2efind_24s924148649x7864569(a_0, b_1)); heff_drop(b_1); r_; });
      switch (heff_tag_of(v_t_2420)) {
      case TAG_Nothing: {
        heff_drop(v_b_2415);
        heff_drop_rec(v_c_2417, 13);
        return NTAG(TAG_Nil);
      }
      case TAG_Just: {
        V v_l_2421 = heff_field(v_t_2420, 0);
        heff_take_n(v_t_2420, 1ULL, 1);
        V v_t_2422 = heff_tag_n(TAG_Cons, 2, (V[]){heff_take_field(v_l_2421, 1), heff_get_n(v_l_2421, 2, 3)});
        V v_t_2423 = (g_list_2esortBy_24s1768199906x1695529242(v_t_2422));
        HEFF_LAST return g_list_2emap_24s1004924153x684987219(v_c_2417, v_b_2415, v_t_2423);
      }
      default: return heff_nomatch(v_t_2420);
      }
    }
    default: return heff_nomatch(v_t_2416);
    }
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_heff_2ebuild_2equery_2eoccurrences_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2equery_2eoccurrences(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2equery_2eoccurrences_lam1(V self, V *args) {
  V v_acc_248 = args[0];
  V v_x_249 = args[1];
  V v_x_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2410 = (g_heff_2ebuild_2equery_2edeclSites(v_x_246, v_x_249));
  return (g_prelude_2e_2b_2b(v_t_2410, v_acc_248));
}
V g_heff_2ebuild_2equery_2eoccurrences_lam2(V self, V *args) {
  V v_s_2412 = args[0];
  V v_t_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2ebuild_2equery_2eeqTarget(heff_get_n(v_s_2412, 0, 3), v_t_241));
}
V g_heff_2ebuild_2equery_2eoccurrences_lam0(V self, V *args) {
  V v_acc_245 = args[0];
  V v_x_246 = args[1];
  V v_t_241 = heff_env(self)[0];
  V v_name_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_247 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(heff_rfield(v_x_246, 4))));
  V v_t_2411 = ({ V a_0 = heff_clo_n(g_heff_2ebuild_2equery_2eoccurrences_lam1, 2, 1, (V[]){heff_dup(v_x_246)}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_247; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_247); r_; });
  V v_t_2413 = (g_list_2efilter(heff_clo_n(g_heff_2ebuild_2equery_2eoccurrences_lam2, 1, 1, (V[]){heff_dup(v_t_241)}), v_t_2411));
  V v_t_2414 = (g_heff_2ebuild_2equery_2einFileSites(v_t_241, v_name_242, v_x_246, v_t_2413));
  return (g_prelude_2e_2b_2b(v_t_2414, v_acc_245));
}
Clo g_heff_2ebuild_2equery_2epunctuation_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2epunctuation_entry, 1, 0};

V g_heff_2ebuild_2equery_2epunctuation(V v_d_240) {
top: ;
  V v_ret_24bool = heff_bool((heff_intEq_c(heff_dup(v_d_240), MK_INT(32LL)) || (heff_intEq_c(heff_dup(v_d_240), MK_INT(10LL)) || (heff_intEq_c(heff_dup(v_d_240), MK_INT(40LL)) || (heff_intEq_c(heff_dup(v_d_240), MK_INT(41LL)) || (heff_intEq_c(heff_dup(v_d_240), MK_INT(91LL)) || (heff_intEq_c(heff_dup(v_d_240), MK_INT(93LL)) || (heff_intEq_c(heff_dup(v_d_240), MK_INT(123LL)) || (heff_intEq_c(heff_dup(v_d_240), MK_INT(125LL)) || (heff_intEq_c(heff_dup(v_d_240), MK_INT(44LL)) || (heff_intEq_c(heff_dup(v_d_240), MK_INT(34LL)) || heff_intEq_c(heff_dup(v_d_240), MK_INT(96LL)))))))))))));
  heff_drop(v_d_240);
  return v_ret_24bool;
}
V g_heff_2ebuild_2equery_2epunctuation_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2equery_2epunctuation(a[0]);
}
Clo g_heff_2ebuild_2equery_2eallChars_24s1328103304x613783392_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2eallChars_24s1328103304x613783392_entry, 2, 0};

V g_heff_2ebuild_2equery_2eallChars_24s1328103304x613783392(V v_s_240, V v_i_241) {
top: ;
  if (heff_intLe_c(heff_strLength_lent(v_s_240, 0), heff_dup(v_i_241))) {
    heff_drop(v_s_240);
    heff_drop(v_i_241);
    return NTAG(TAG_True);
  } else {
    V v_d_243 = heff_strByteAt_lent(v_s_240, v_i_241, 0);
    if (heff_intEq_c(heff_dup(v_d_243), MK_INT(47LL))) {
      heff_drop(v_s_240);
      heff_drop(v_i_241);
      heff_drop(v_d_243);
      return NTAG(TAG_False);
    } else {
      V v_t_245 = (g_heff_2ebuild_2equery_2eisNameChar(v_d_243));
      if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
        heff_drop(v_t_245);
        V t_0 = v_s_240;
        V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
        v_s_240 = t_0;
        v_i_241 = t_1;
        goto top;
      } else {
        heff_drop(v_s_240);
        heff_drop(v_i_241);
        heff_drop(v_t_245);
        return NTAG(TAG_False);
      }
    }
  }
}
V g_heff_2ebuild_2equery_2eallChars_24s1328103304x613783392_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2equery_2eallChars_24s1328103304x613783392(a[0], a[1]);
}
Clo g_heff_2ebuild_2equery_2eallChars_24s1240979977x1750746677_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2eallChars_24s1240979977x1750746677_entry, 3, 0};

V g_heff_2ebuild_2equery_2eallChars_24s1240979977x1750746677(V v_lit_240, V v_s_241, V v_i_242) {
top: ;
  if (heff_intLe_c(heff_strLength_lent(v_s_241, 0), heff_dup(v_i_242))) {
    heff_drop(v_lit_240);
    heff_drop(v_s_241);
    heff_drop(v_i_242);
    return NTAG(TAG_True);
  } else {
    V v_a_244 = heff_strByteAt_lent(v_s_241, v_i_242, 0);
    V v_a_246;
    if (heff_intEq_c(heff_dup(v_a_244), heff_dup(v_lit_240))) {
      v_a_246 = NTAG(TAG_False);
    } else {
      v_a_246 = (g_heff_2ebuild_2equery_2eisNameChar(heff_dup(v_a_244)));
    }
    if ((heff_dup(v_a_246) == NTAG(TAG_True))) {
      heff_drop(v_lit_240);
      heff_drop(v_s_241);
      heff_drop(v_i_242);
      heff_drop(v_a_244);
      heff_drop(v_a_246);
      return NTAG(TAG_False);
    } else {
      heff_drop(v_a_246);
      V v_a_247 = (g_heff_2ebuild_2equery_2epunctuation(v_a_244));
      if ((heff_dup(v_a_247) == NTAG(TAG_True))) {
        heff_drop(v_lit_240);
        heff_drop(v_s_241);
        heff_drop(v_i_242);
        heff_drop(v_a_247);
        return NTAG(TAG_False);
      } else {
        heff_drop(v_a_247);
        V t_0 = v_lit_240;
        V t_1 = v_s_241;
        V t_2 = heff_intAdd(v_i_242, MK_INT(1LL));
        v_lit_240 = t_0;
        v_s_241 = t_1;
        v_i_242 = t_2;
        goto top;
      }
    }
  }
}
V g_heff_2ebuild_2equery_2eallChars_24s1240979977x1750746677_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2equery_2eallChars_24s1240979977x1750746677(a[0], a[1], a[2]);
}
Clo g_heff_2ebuild_2equery_2enameClass_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2enameClass_entry, 1, 0};

V g_heff_2ebuild_2equery_2enameClass(V v_x_240) {
top: ;
  if (heff_intEq_c(heff_strLength_lent(v_x_240, 0), MK_INT(0LL))) {
    heff_drop(v_x_240);
    return MK_INT(0LL);
  } else {
    V v_t_243 = heff_bool((heff_intLe_c(MK_INT(65LL), heff_strByteAt_lent(v_x_240, MK_INT(0LL), 2)) && heff_intLe_c(heff_strByteAt_lent(v_x_240, MK_INT(0LL), 2), MK_INT(90LL))));
    if ((heff_dup(v_t_243) == NTAG(TAG_True))) {
      heff_drop(v_t_243);
      V v_t_244 = (g_heff_2ebuild_2equery_2eallChars_24s1328103304x613783392(v_x_240, MK_INT(0LL)));
      if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
        heff_drop(v_t_244);
        return MK_INT(1LL);
      } else {
        heff_drop(v_t_244);
        return MK_INT(0LL);
      }
    } else {
      heff_drop(v_t_243);
      if (heff_intEq_c(heff_strByteAt_lent(v_x_240, MK_INT(0LL), 2), MK_INT(95LL))) {
        V v_t_246 = (g_heff_2ebuild_2equery_2eallChars_24s1328103304x613783392(v_x_240, MK_INT(0LL)));
        if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
          heff_drop(v_t_246);
          return MK_INT(2LL);
        } else {
          heff_drop(v_t_246);
          return MK_INT(0LL);
        }
      } else {
        if (heff_intLe_c(MK_INT(97LL), heff_strByteAt_lent(v_x_240, MK_INT(0LL), 2))) {
          if (heff_intLe_c(heff_strByteAt_lent(v_x_240, MK_INT(0LL), 2), MK_INT(122LL))) {
            V v_t_249 = (g_heff_2ebuild_2equery_2eallChars_24s1328103304x613783392(v_x_240, MK_INT(0LL)));
            if ((heff_dup(v_t_249) == NTAG(TAG_True))) {
              heff_drop(v_t_249);
              return MK_INT(2LL);
            } else {
              heff_drop(v_t_249);
              return MK_INT(0LL);
            }
          } else {
            V v_t_2410 = (g_heff_2ebuild_2equery_2eallChars_24s1240979977x1750746677(MK_INT(47LL), v_x_240, MK_INT(0LL)));
            if ((heff_dup(v_t_2410) == NTAG(TAG_True))) {
              heff_drop(v_t_2410);
              return MK_INT(3LL);
            } else {
              heff_drop(v_t_2410);
              return MK_INT(0LL);
            }
          }
        } else {
          V v_t_2411 = (g_heff_2ebuild_2equery_2eallChars_24s1240979977x1750746677(MK_INT(47LL), v_x_240, MK_INT(0LL)));
          if ((heff_dup(v_t_2411) == NTAG(TAG_True))) {
            heff_drop(v_t_2411);
            return MK_INT(3LL);
          } else {
            heff_drop(v_t_2411);
            return MK_INT(0LL);
          }
        }
      }
    }
  }
}
V g_heff_2ebuild_2equery_2enameClass_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2equery_2enameClass(a[0]);
}
HEFF_LIT(g_heff_2ebuild_2equery_2erenameRefused_str0, 1, ".");
HEFF_LIT(g_heff_2ebuild_2equery_2erenameRefused_str1, 29, "` is not a name of the kind `");
HEFF_LIT(g_heff_2ebuild_2equery_2erenameRefused_str2, 4, "` is");
HEFF_LIT(g_heff_2ebuild_2equery_2erenameRefused_str3, 1, "`");
HEFF_LIT(g_heff_2ebuild_2equery_2erenameRefused_str4, 1, "`");
HEFF_LIT(g_heff_2ebuild_2equery_2erenameRefused_str5, 43, "` is a primitive: its name is the runtime's");
HEFF_LIT(g_heff_2ebuild_2equery_2erenameRefused_str6, 29, "` is not a name of the kind `");
HEFF_LIT(g_heff_2ebuild_2equery_2erenameRefused_str7, 4, "` is");
HEFF_LIT(g_heff_2ebuild_2equery_2erenameRefused_str8, 1, "`");
HEFF_LIT(g_heff_2ebuild_2equery_2erenameRefused_str9, 29, "` is not a name of the kind `");
HEFF_LIT(g_heff_2ebuild_2equery_2erenameRefused_str10, 4, "` is");
HEFF_LIT(g_heff_2ebuild_2equery_2erenameRefused_str11, 1, "`");
Clo g_heff_2ebuild_2equery_2erenameRefused_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2erenameRefused_entry, 3, 0};

V g_heff_2ebuild_2equery_2erenameRefused(V v_t_240, V v_old_241, V v_new_242) {
top: ;
  V v_t_243 = heff_take_field(v_t_240, 1);
  switch (heff_tag_of(v_t_243)) {
  case TAG_Nothing: {
    V v_t_244 = heff_take_field(v_t_240, 2);
    switch (heff_tag_of(v_t_244)) {
    case TAG_Nothing: {
      V v_x_245 = (g_prelude_2estrFind(((V)&g_heff_2ebuild_2equery_2erenameRefused_str0), heff_get_n(v_t_240, 0, 3), MK_INT(0LL)));
      if (heff_intLe_c(MK_INT(0LL), v_x_245)) {
        V v_x_247 = (g_heff_2ebuild_2equery_2enameClass(heff_dup(v_old_241)));
        V v_y_248 = (g_heff_2ebuild_2equery_2enameClass(heff_dup(v_new_242)));
        if (heff_intEq_c(v_x_247, v_y_248)) {
          heff_drop(v_old_241);
          heff_drop(v_new_242);
          return NTAG(TAG_Nothing);
        } else {
          V v_t_2410 = heff_strAppend(((V)&g_heff_2ebuild_2equery_2erenameRefused_str1), heff_strAppend(v_old_241, ((V)&g_heff_2ebuild_2equery_2erenameRefused_str2)));
          V v_t_2411 = heff_strAppend(((V)&g_heff_2ebuild_2equery_2erenameRefused_str3), heff_strAppend(v_new_242, v_t_2410));
          return heff_tag_n(TAG_Just, 1, (V[]){v_t_2411});
        }
      } else {
        heff_drop(v_new_242);
        V v_t_2412 = heff_strAppend(((V)&g_heff_2ebuild_2equery_2erenameRefused_str4), heff_strAppend(v_old_241, ((V)&g_heff_2ebuild_2equery_2erenameRefused_str5)));
        return heff_tag_n(TAG_Just, 1, (V[]){v_t_2412});
      }
    }
    case TAG_Just: {
      V v_ru_24t_244_24Just = heff_take_reuse_n(v_t_244, 0ULL, 1);
      heff_drop_rec(v_t_240, 3);
      V v_x_2414 = (g_heff_2ebuild_2equery_2enameClass(heff_dup(v_old_241)));
      V v_y_2415 = (g_heff_2ebuild_2equery_2enameClass(heff_dup(v_new_242)));
      if (heff_intEq_c(v_x_2414, v_y_2415)) {
        heff_drop(v_old_241);
        heff_drop(v_new_242);
        heff_drop_cell(v_ru_24t_244_24Just, 1);
        return NTAG(TAG_Nothing);
      } else {
        V v_t_2417 = heff_strAppend(((V)&g_heff_2ebuild_2equery_2erenameRefused_str6), heff_strAppend(v_old_241, ((V)&g_heff_2ebuild_2equery_2erenameRefused_str7)));
        V v_t_2418 = heff_strAppend(((V)&g_heff_2ebuild_2equery_2erenameRefused_str8), heff_strAppend(v_new_242, v_t_2417));
        return heff_tag_at_n(v_ru_24t_244_24Just, TAG_Just, 1, (V[]){v_t_2418});
      }
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  case TAG_Just: {
    V v_ru_24t_243_24Just = heff_take_reuse_n(v_t_243, 0ULL, 1);
    heff_drop_rec(v_t_240, 3);
    V v_x_2420 = (g_heff_2ebuild_2equery_2enameClass(heff_dup(v_old_241)));
    V v_y_2421 = (g_heff_2ebuild_2equery_2enameClass(heff_dup(v_new_242)));
    if (heff_intEq_c(v_x_2420, v_y_2421)) {
      heff_drop(v_old_241);
      heff_drop(v_new_242);
      heff_drop_cell(v_ru_24t_243_24Just, 1);
      return NTAG(TAG_Nothing);
    } else {
      V v_t_2423 = heff_strAppend(((V)&g_heff_2ebuild_2equery_2erenameRefused_str9), heff_strAppend(v_old_241, ((V)&g_heff_2ebuild_2equery_2erenameRefused_str10)));
      V v_t_2424 = heff_strAppend(((V)&g_heff_2ebuild_2equery_2erenameRefused_str11), heff_strAppend(v_new_242, v_t_2423));
      return heff_tag_at_n(v_ru_24t_243_24Just, TAG_Just, 1, (V[]){v_t_2424});
    }
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_heff_2ebuild_2equery_2erenameRefused_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2equery_2erenameRefused(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ebuild_2equery_2ecommentAbove_str0, 2, "--");
Clo g_heff_2ebuild_2equery_2ecommentAbove_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2ecommentAbove_entry, 3, 0};

V g_heff_2ebuild_2equery_2ecommentAbove(V v_src_240, V v_start_241, V v_acc_242) {
top: ;
  if (heff_intLe_c(heff_dup(v_start_241), MK_INT(0LL))) {
    heff_drop(v_src_240);
    heff_drop(v_start_241);
    return v_acc_242;
  } else {
    V v_t_244 = (g_heff_2ebuild_2equery_2elineStartOf(heff_dup(v_src_240), heff_intSub(heff_dup(v_start_241), MK_INT(1LL))));
    V v_s_245 = heff_strSlice(heff_dup(v_src_240), v_t_244, heff_intSub(heff_dup(v_start_241), MK_INT(1LL)));
    V v_t_246 = (g_prelude_2eskipSpaces(heff_dup(v_s_245), MK_INT(0LL), MK_INT(1LL)));
    V v_t_247 = heff_intSub(heff_strLength_lent(v_s_245, 0), MK_INT(1LL));
    V v_t_248 = (g_prelude_2eskipSpaces(heff_dup(v_s_245), v_t_247, MK_INT(-1LL)));
    V v_s_249 = heff_strSlice(v_s_245, v_t_246, heff_intAdd(v_t_248, MK_INT(1LL)));
    if (heff_strEq_c(heff_strSlice(v_s_249, MK_INT(0LL), MK_INT(2LL)), ((V)&g_heff_2ebuild_2equery_2ecommentAbove_str0))) {
      V v_t_2411 = (g_heff_2ebuild_2equery_2elineStartOf(heff_dup(v_src_240), heff_intSub(heff_dup(v_start_241), MK_INT(1LL))));
      V v_t_2412 = (g_heff_2ebuild_2equery_2elineStartOf(heff_dup(v_src_240), heff_intSub(heff_dup(v_start_241), MK_INT(1LL))));
      V v_s_2413 = heff_strSlice(heff_dup(v_src_240), v_t_2412, heff_intSub(v_start_241, MK_INT(1LL)));
      V v_t_2414 = (g_prelude_2eskipSpaces(heff_dup(v_s_2413), MK_INT(0LL), MK_INT(1LL)));
      V v_t_2415 = heff_intSub(heff_strLength_lent(v_s_2413, 0), MK_INT(1LL));
      V v_t_2416 = (g_prelude_2eskipSpaces(heff_dup(v_s_2413), v_t_2415, MK_INT(-1LL)));
      V v_t_2417 = heff_strSlice(v_s_2413, v_t_2414, heff_intAdd(v_t_2416, MK_INT(1LL)));
      V t_0 = v_src_240;
      V t_1 = v_t_2411;
      V t_2 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2417, v_acc_242});
      v_src_240 = t_0;
      v_start_241 = t_1;
      v_acc_242 = t_2;
      goto top;
    } else {
      heff_drop(v_src_240);
      heff_drop(v_start_241);
      return v_acc_242;
    }
  }
}
V g_heff_2ebuild_2equery_2ecommentAbove_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2equery_2ecommentAbove(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ebuild_2equery_2edocMdStep_str0, 3, ">>>");
HEFF_LIT(g_heff_2ebuild_2equery_2edocMdStep_str1, 7, "```heff");
HEFF_LIT(g_heff_2ebuild_2equery_2edocMdStep_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2equery_2edocMdStep_str3, 3, "```");
HEFF_LIT(g_heff_2ebuild_2equery_2edocMdStep_str4, 3, "```");
HEFF_LIT(g_heff_2ebuild_2equery_2edocMdStep_str5, 3, "```");
Clo g_heff_2ebuild_2equery_2edocMdStep_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2edocMdStep_entry, 2, 0};

V g_heff_2ebuild_2equery_2edocMdStep(V v_m_240, V v_l_241) {
top: ;
  if (heff_strEq_c(heff_strSlice_lent(v_l_241, MK_INT(0LL), MK_INT(3LL), 6), ((V)&g_heff_2ebuild_2equery_2edocMdStep_str0))) {
    V v_t_243 = heff_take_field(v_m_240, 1);
    V v_t_244;
    if ((heff_dup(v_t_243) == NTAG(TAG_True))) {
      heff_drop(v_t_243);
      v_t_244 = heff_get_n(v_m_240, 0, 3);
    } else {
      heff_drop(v_t_243);
      v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2equery_2edocMdStep_str1), heff_get_n(v_m_240, 0, 3)});
    }
    return heff_rec_n(3, shape_out__code__expecting, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_l_241, v_t_244}), NTAG(TAG_True), NTAG(TAG_True)});
  } else {
    V v_t_245 = heff_dup(heff_rfield(v_m_240, 1));
    if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
      heff_drop(v_t_245);
      V v_t_246 = heff_take_field(v_m_240, 2);
      if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
        heff_drop(v_t_246);
        V v_t_247 = (g_prelude_2eskipSpaces(heff_dup(v_l_241), MK_INT(0LL), MK_INT(1LL)));
        V v_t_248 = heff_intSub(heff_strLength_lent(v_l_241, 0), MK_INT(1LL));
        V v_t_249 = (g_prelude_2eskipSpaces(heff_dup(v_l_241), v_t_248, MK_INT(-1LL)));
        V v_t_2410 = heff_strSlice(heff_dup(v_l_241), v_t_247, heff_intAdd(v_t_249, MK_INT(1LL)));
        if (heff_strEq_c(v_t_2410, ((V)&g_heff_2ebuild_2equery_2edocMdStep_str2))) {
          V v_t_2412 = heff_take_field(v_m_240, 1);
          V v_t_2413;
          if ((heff_dup(v_t_2412) == NTAG(TAG_True))) {
            heff_drop(v_t_2412);
            v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2equery_2edocMdStep_str3), heff_get_n(v_m_240, 0, 3)});
          } else {
            heff_drop(v_t_2412);
            v_t_2413 = heff_get_n(v_m_240, 0, 3);
          }
          return heff_rec_n(3, shape_out__code__expecting, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_l_241, v_t_2413}), NTAG(TAG_False), NTAG(TAG_False)});
        } else {
          V v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){v_l_241, heff_get_n(v_m_240, 0, 3)});
          return heff_rec_n(3, shape_out__code__expecting, (V[]){v_t_2414, NTAG(TAG_True), NTAG(TAG_True)});
        }
      } else {
        heff_drop(v_t_246);
        V v_t_2415 = heff_take_field(v_m_240, 1);
        V v_t_2416;
        if ((heff_dup(v_t_2415) == NTAG(TAG_True))) {
          heff_drop(v_t_2415);
          v_t_2416 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2equery_2edocMdStep_str4), heff_get_n(v_m_240, 0, 3)});
        } else {
          heff_drop(v_t_2415);
          v_t_2416 = heff_get_n(v_m_240, 0, 3);
        }
        return heff_rec_n(3, shape_out__code__expecting, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_l_241, v_t_2416}), NTAG(TAG_False), NTAG(TAG_False)});
      }
    } else {
      heff_drop(v_t_245);
      V v_t_2417 = heff_take_field(v_m_240, 1);
      V v_t_2418;
      if ((heff_dup(v_t_2417) == NTAG(TAG_True))) {
        heff_drop(v_t_2417);
        v_t_2418 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2equery_2edocMdStep_str5), heff_get_n(v_m_240, 0, 3)});
      } else {
        heff_drop(v_t_2417);
        v_t_2418 = heff_get_n(v_m_240, 0, 3);
      }
      return heff_rec_n(3, shape_out__code__expecting, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_l_241, v_t_2418}), NTAG(TAG_False), NTAG(TAG_False)});
    }
  }
}
V g_heff_2ebuild_2equery_2edocMdStep_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2equery_2edocMdStep(a[0], a[1]);
}
HEFF_LIT(g_heff_2ebuild_2equery_2edocMarkdown_str0, 3, "```");
HEFF_LIT(g_heff_2ebuild_2equery_2edocMarkdown_str1, 0, "");
HEFF_LIT(g_heff_2ebuild_2equery_2edocMarkdown_str2, 1, "\012");
Clo g_heff_2ebuild_2equery_2edocMarkdown_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2edocMarkdown_entry, 1, 0};

V g_heff_2ebuild_2equery_2edocMarkdown(V v_ls_240) {
top: ;
  V v_t_241 = heff_rec_n(3, shape_out__code__expecting, (V[]){NTAG(TAG_Nil), NTAG(TAG_False), NTAG(TAG_False)});
  V v_m_242 = (g_list_2efoldl_24s1472875662x470242985(v_t_241, v_ls_240));
  V v_t_243 = heff_take_field(v_m_242, 1);
  V v_t_244;
  if ((heff_dup(v_t_243) == NTAG(TAG_True))) {
    heff_drop(v_t_243);
    v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2equery_2edocMarkdown_str0), heff_get_n(v_m_242, 0, 3)});
  } else {
    heff_drop(v_t_243);
    v_t_244 = heff_get_n(v_m_242, 0, 3);
  }
  V v_x2_245 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_t_244));
  switch (heff_tag_of(v_x2_245)) {
  case TAG_Nil: {
    return ((V)&g_heff_2ebuild_2equery_2edocMarkdown_str1);
  }
  case TAG_Cons: {
    V v_x_246 = heff_field(v_x2_245, 0);
    V v_xs_247 = heff_field(v_x2_245, 1);
    heff_take_n(v_x2_245, 3ULL, 2);
    return ({ V a_0 = ((V)&g_heff_2ebuild_2equery_2edocMarkdown_str2); V a_1 = v_x_246; V a_2 = v_xs_247; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_247); r_; });
  }
  default: return heff_nomatch(v_x2_245);
  }
}
V g_heff_2ebuild_2equery_2edocMarkdown_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2equery_2edocMarkdown(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ebuild_2equery_2ebrokenSymbol_str0, 5, "data ");
HEFF_LIT(g_heff_2ebuild_2equery_2ebrokenSymbol_str1, 7, "theory ");
Clo g_heff_2ebuild_2equery_2ebrokenSymbol_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2ebrokenSymbol_entry, 2, 0};

V g_heff_2ebuild_2equery_2ebrokenSymbol(V v_c_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_MkPair: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_sp_243 = heff_field(v_x2_241, 1);
    V v_text_244 = heff_strSlice(heff_dup(heff_rfield(v_c_240, 3)), heff_dup(heff_rfield(v_sp_243, 0)), heff_dup(heff_rfield(v_sp_243, 1)));
    V v_t_248;
    if (heff_strEq_c(heff_strSlice_lent(v_text_244, MK_INT(0LL), MK_INT(5LL), 6), ((V)&g_heff_2ebuild_2equery_2ebrokenSymbol_str0))) {
      heff_drop(v_text_244);
      v_t_248 = MK_INT(10LL);
    } else {
      if (heff_strEq_c(heff_strSlice(v_text_244, MK_INT(0LL), MK_INT(7LL)), ((V)&g_heff_2ebuild_2equery_2ebrokenSymbol_str1))) {
        v_t_248 = MK_INT(11LL);
      } else {
        V v_x1_247 = (g_heff_2ebuild_2equery_2eisNameChar(heff_strByteAt_lent(v_x_242, MK_INT(0LL), 2)));
        if ((heff_dup(v_x1_247) == NTAG(TAG_True))) {
          heff_drop(v_x1_247);
          v_t_248 = MK_INT(12LL);
        } else {
          heff_drop(v_x1_247);
          v_t_248 = MK_INT(25LL);
        }
      }
    }
    V v_t_249 = (g_heff_2ebuild_2equery_2enameInGo(heff_get_n(v_c_240, 3, 13), heff_dup(v_x_242), heff_dup(v_sp_243), heff_dup(heff_rfield(v_sp_243, 0))));
    return heff_rec_n(5, shape_name__kind__span__selection__children, (V[]){heff_dup(v_x_242), v_t_248, heff_dup(v_sp_243), v_t_249, NTAG(TAG_Nil)});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2equery_2ebrokenSymbol_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2equery_2ebrokenSymbol(a[0], a1); heff_drop(a1); return r;
}
Clo g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211_entry, 1, 0};

V g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_At: {
    V v_x21_241 = heff_field(v_x2_240, 0);
    switch (heff_tag_of(v_x21_241)) {
    case TAG_EVar: {
      return NTAG(TAG_Nil);
    }
    case TAG_EImplicitVar: {
      return NTAG(TAG_Nil);
    }
    case TAG_ETag: {
      return NTAG(TAG_Nil);
    }
    case TAG_EInt: {
      return NTAG(TAG_Nil);
    }
    case TAG_EFloat: {
      return NTAG(TAG_Nil);
    }
    case TAG_EString: {
      return NTAG(TAG_Nil);
    }
    case TAG_EBinary: {
      return NTAG(TAG_Nil);
    }
    case TAG_ERune: {
      return NTAG(TAG_Nil);
    }
    case TAG_EWord: {
      return NTAG(TAG_Nil);
    }
    case TAG_EApp: {
      V v_h_2412 = heff_field(v_x21_241, 0);
      V v_args_2413 = heff_field(v_x21_241, 1);
      V v_t_2414 = (g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(v_h_2412));
      V v_t_2415 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_args_2413)));
      V v_t_2416 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2415; V r_ = (g_list_2efoldl_24s2134067310x2049132013(a_0, a_1)); heff_drop(v_t_2415); r_; });
      return (g_prelude_2e_2b_2b(v_t_2414, v_t_2416));
    }
    case TAG_EProject: {
      return NTAG(TAG_Nil);
    }
    case TAG_ENamed: {
      V v_e_2419 = heff_field(v_x21_241, 1);
      V t_0 = v_e_2419;
      v_x2_240 = t_0;
      goto top;
    }
    case TAG_EPi: {
      V v_b_2420 = heff_field(v_x21_241, 0);
      V v_cod_2421 = heff_field(v_x21_241, 1);
      V v_t_2438;
      switch (heff_tag_of(v_b_2420)) {
      case TAG_PiNamed: {
        V v_t_2424 = heff_field(v_b_2420, 2);
        v_t_2438 = (g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(v_t_2424));
        break;
      }
      case TAG_PiImplicit: {
        V v_t_2428 = heff_field(v_b_2420, 3);
        V v_d_2429 = heff_field(v_b_2420, 4);
        V v_t_2430 = (g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(v_t_2428));
        V v_t_2432;
        switch (heff_tag_of(v_d_2429)) {
        case TAG_Nothing: {
          v_t_2432 = NTAG(TAG_Nil);
          break;
        }
        case TAG_Just: {
          V v_x_2431 = heff_field(v_d_2429, 0);
          v_t_2432 = (g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(v_x_2431));
          break;
        }
        default: heff_nomatch(v_d_2429);
        }
        v_t_2438 = (g_prelude_2e_2b_2b(v_t_2430, v_t_2432));
        break;
      }
      case TAG_PiInstance: {
        V v_t_2436 = heff_field(v_b_2420, 3);
        v_t_2438 = (g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(v_t_2436));
        break;
      }
      case TAG_PiAnon: {
        V v_t_2437 = heff_field(v_b_2420, 0);
        v_t_2438 = (g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(v_t_2437));
        break;
      }
      default: heff_nomatch(v_b_2420);
      }
      V v_t_2439 = (g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(v_cod_2421));
      return (g_prelude_2e_2b_2b(v_t_2438, v_t_2439));
    }
    case TAG_ELam: {
      V v_b_2440 = heff_field(v_x21_241, 0);
      V v_body_2441 = heff_field(v_x21_241, 1);
      V v_t_2449;
      switch (heff_tag_of(v_b_2440)) {
      case TAG_LamName: {
        v_t_2449 = NTAG(TAG_Nil);
        break;
      }
      case TAG_LamImplicit: {
        v_t_2449 = NTAG(TAG_Nil);
        break;
      }
      case TAG_LamAnn: {
        V v_t_2448 = heff_field(v_b_2440, 2);
        v_t_2449 = (g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(v_t_2448));
        break;
      }
      default: heff_nomatch(v_b_2440);
      }
      V v_t_2450 = (g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(v_body_2441));
      return (g_prelude_2e_2b_2b(v_t_2449, v_t_2450));
    }
    case TAG_EAnn: {
      V v_e_2451 = heff_field(v_x21_241, 0);
      V v_t_2452 = heff_field(v_x21_241, 1);
      V v_t_2453 = (g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(v_e_2451));
      V v_t_2454 = (g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(v_t_2452));
      return (g_prelude_2e_2b_2b(v_t_2453, v_t_2454));
    }
    case TAG_ESpec: {
      V v_acc_2455 = heff_field(v_x21_241, 0);
      V v_v_2458 = heff_field(v_x21_241, 3);
      V v_t_2459 = (g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(v_acc_2455));
      V v_t_2460 = (g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(v_v_2458));
      return (g_prelude_2e_2b_2b(v_t_2459, v_t_2460));
    }
    case TAG_ESig: {
      V v_fs_2461 = heff_field(v_x21_241, 0);
      V v_t_2462 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_fs_2461)));
      return ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2462; V r_ = (g_list_2efoldl_24s1777318809x1106245647(a_0, a_1)); heff_drop(v_t_2462); r_; });
    }
    case TAG_ESum: {
      V v_vs_2463 = heff_field(v_x21_241, 0);
      V v_t_2464 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_vs_2463)));
      return ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2464; V r_ = (g_list_2efoldl_24s491084544x100802329(a_0, a_1)); heff_drop(v_t_2464); r_; });
    }
    case TAG_EStruct: {
      V v_fs_2465 = heff_field(v_x21_241, 0);
      V v_t_2466 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_fs_2465)));
      return ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2466; V r_ = (g_list_2efoldl_24s189033563x26633104(a_0, a_1)); heff_drop(v_t_2466); r_; });
    }
    case TAG_EUpdate: {
      V v_a_2467 = heff_field(v_x21_241, 0);
      V v_fs_2468 = heff_field(v_x21_241, 1);
      V v_t_2469 = (g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(v_a_2467));
      V v_t_2470 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_fs_2468)));
      V v_t_2471 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2470; V r_ = (g_list_2efoldl_24s1026998256x1634433314(a_0, a_1)); heff_drop(v_t_2470); r_; });
      return (g_prelude_2e_2b_2b(v_t_2469, v_t_2471));
    }
    case TAG_EMatch: {
      V v_s_2472 = heff_field(v_x21_241, 0);
      V v_alts_2473 = heff_field(v_x21_241, 1);
      V v_t_2474 = (g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(v_s_2472));
      V v_t_2475 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_alts_2473)));
      V v_t_2476 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2475; V r_ = (g_list_2efoldl_24s302194196x751324068(a_0, a_1)); heff_drop(v_t_2475); r_; });
      return (g_prelude_2e_2b_2b(v_t_2474, v_t_2476));
    }
    case TAG_ELetIn: {
      V v_rhs_2477 = heff_field(v_x21_241, 0);
      V v_x212_2478 = heff_field(v_x21_241, 1);
      switch (heff_tag_of(v_x212_2478)) {
      case TAG_At: {
        V v_x2121_2479 = heff_field(v_x212_2478, 0);
        switch (heff_tag_of(v_x2121_2479)) {
        case TAG_MkAlt: {
          V v_e_2482 = heff_field(v_x2121_2479, 1);
          V v_t_2483 = (g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(v_rhs_2477));
          V v_t_2484 = (g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(v_e_2482));
          return (g_prelude_2e_2b_2b(v_t_2483, v_t_2484));
        }
        default: return heff_nomatch(v_x2121_2479);
        }
      }
      default: return heff_nomatch(v_x212_2478);
      }
    }
    case TAG_EDo: {
      V v_stmts_2485 = heff_field(v_x21_241, 0);
      V v_t_2486 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_stmts_2485)));
      return ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2486; V r_ = (g_list_2efoldl_24s1620243413x998711352(a_0, a_1)); heff_drop(v_t_2486); r_; });
    }
    case TAG_ELocal: {
      V v_b_2487 = heff_field(v_x21_241, 0);
      V v_defs_2488 = heff_field(v_x21_241, 1);
      V v_t_2489 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_defs_2488)));
      V v_t_2490 = (g_list_2efoldl_24s1516272141x1201056882(MK_INT(12LL), NTAG(TAG_Nil), v_t_2489));
      V v_t_2491 = (g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(v_b_2487));
      V v_t_2492 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_defs_2488)));
      V v_t_2493 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2492; V r_ = (g_list_2efoldl_24s54159557x1528472185(a_0, a_1)); heff_drop(v_t_2492); r_; });
      V v_t_2494 = (g_prelude_2e_2b_2b(v_t_2491, v_t_2493));
      return (g_prelude_2e_2b_2b(v_t_2490, v_t_2494));
    }
    case TAG_EInvalid: {
      return NTAG(TAG_Nil);
    }
    default: return heff_nomatch(v_x21_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(a0); heff_drop(a0); return r;
}
Clo g_heff_2ebuild_2equery_2elocalDeclF_24s1801777056x609367408_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2elocalDeclF_24s1801777056x609367408_entry, 1, 0};

V g_heff_2ebuild_2equery_2elocalDeclF_24s1801777056x609367408(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_At: {
    V v_x21_241 = heff_field(v_x2_240, 0);
    switch (heff_tag_of(v_x21_241)) {
    case TAG_DeclEquations: {
      V v_ty_246 = heff_field(v_x21_241, 3);
      V v_eqs_247 = heff_field(v_x21_241, 4);
      V v_t_248 = (g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(v_ty_246));
      V v_t_249 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_eqs_247)));
      V v_t_2410 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_249; V r_ = (g_list_2efoldl_24s496727651x1448898893(a_0, a_1)); heff_drop(v_t_249); r_; });
      return (g_prelude_2e_2b_2b(v_t_248, v_t_2410));
    }
    case TAG_DeclDefine: {
      V v_ps_2413 = heff_field(v_x21_241, 2);
      V v_u_2414 = heff_field(v_x21_241, 3);
      V v_body_2415 = heff_field(v_x21_241, 4);
      V v_t_2416 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_ps_2413)));
      V v_t_2417 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2416; V r_ = (g_list_2efoldl_24s1975553568x1034350329(a_0, a_1)); heff_drop(v_t_2416); r_; });
      V v_t_2418 = (g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(v_u_2414));
      V v_t_2419 = (g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(v_body_2415));
      V v_t_2420 = (g_prelude_2e_2b_2b(v_t_2418, v_t_2419));
      return (g_prelude_2e_2b_2b(v_t_2417, v_t_2420));
    }
    case TAG_DeclTheory: {
      V v_ps_2423 = heff_field(v_x21_241, 2);
      V v_body_2424 = heff_field(v_x21_241, 3);
      V v_t_2425 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_ps_2423)));
      V v_t_2426 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2425; V r_ = (g_list_2efoldl_24s1975553568x1034350329(a_0, a_1)); heff_drop(v_t_2425); r_; });
      V v_t_2427 = (g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(v_body_2424));
      return (g_prelude_2e_2b_2b(v_t_2426, v_t_2427));
    }
    case TAG_DeclPrimitive: {
      V v_t_2430 = heff_field(v_x21_241, 2);
      HEFF_LAST return g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(v_t_2430);
    }
    case TAG_DeclTest: {
      return NTAG(TAG_Nil);
    }
    case TAG_DeclWatch: {
      V v_e_2433 = heff_field(v_x21_241, 0);
      HEFF_LAST return g_heff_2ebuild_2equery_2elocalTermF_24s1893869207x922528211(v_e_2433);
    }
    default: return heff_nomatch(v_x21_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2ebuild_2equery_2elocalDeclF_24s1801777056x609367408_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2equery_2elocalDeclF_24s1801777056x609367408(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ebuild_2equery_2esymbolWith_str0, 5, "data ");
HEFF_LIT(g_heff_2ebuild_2equery_2esymbolWith_str1, 7, "theory ");
HEFF_LIT(g_heff_2ebuild_2equery_2esymbolWith_str2, 5, "data ");
Clo g_heff_2ebuild_2equery_2esymbolWith_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2esymbolWith_entry, 4, 0};

V g_heff_2ebuild_2equery_2esymbolWith(V v_c_240, V v_o_241, V v_sp_242, V v_own_243) {
top: ;
  V v_text_244 = heff_strSlice(heff_dup(heff_rfield(v_c_240, 3)), heff_dup(heff_rfield(v_sp_242, 0)), heff_dup(heff_rfield(v_sp_242, 1)));
  V v_t_249;
  if (heff_strEq_c(heff_strSlice_lent(v_text_244, MK_INT(0LL), MK_INT(5LL), 6), ((V)&g_heff_2ebuild_2equery_2esymbolWith_str0))) {
    heff_drop(v_text_244);
    v_t_249 = MK_INT(10LL);
  } else {
    if (heff_strEq_c(heff_strSlice(v_text_244, MK_INT(0LL), MK_INT(7LL)), ((V)&g_heff_2ebuild_2equery_2esymbolWith_str1))) {
      v_t_249 = MK_INT(11LL);
    } else {
      V v_t_247 = heff_strByteAt(heff_dup(heff_rfield(v_o_241, 0)), MK_INT(0LL));
      V v_x1_248 = (g_heff_2ebuild_2equery_2eisNameChar(v_t_247));
      if ((heff_dup(v_x1_248) == NTAG(TAG_True))) {
        heff_drop(v_x1_248);
        v_t_249 = MK_INT(12LL);
      } else {
        heff_drop(v_x1_248);
        v_t_249 = MK_INT(25LL);
      }
    }
  }
  V v_t_2410 = (g_list_2efind_24s1702704581x1717241719(v_own_243));
  V v_t_2412;
  switch (heff_tag_of(v_t_2410)) {
  case TAG_Nothing: {
    v_t_2412 = (g_heff_2ebuild_2equery_2enameInGo(heff_dup(heff_rfield(v_c_240, 3)), heff_dup(heff_rfield(v_o_241, 0)), heff_dup(v_sp_242), heff_dup(heff_rfield(v_sp_242, 0))));
    break;
  }
  case TAG_Just: {
    V v_s_2411 = heff_field(v_t_2410, 0);
    heff_take_n(v_t_2410, 1ULL, 1);
    v_t_2412 = heff_get_n(v_s_2411, 2, 3);
    break;
  }
  default: heff_nomatch(v_t_2410);
  }
  V v_t_2413 = (g_list_2emap_24f1451184245x2111935062(heff_dup(v_c_240), heff_dup(v_sp_242), MK_INT(5LL), ((V)&g_heff_2ebuild_2equery_2esymbolWith_str2), MK_INT(22LL), MK_INT(8LL), v_own_243));
  V v_t_2414 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_get_n(v_c_240, 4, 13)));
  V v_t_2415 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2414; V r_ = (g_list_2efoldl_24s54159557x1528472185(a_0, a_1)); heff_drop(v_t_2414); r_; });
  V v_t_2416 = (g_list_2efilter_24s343483820x881052984(heff_dup(v_sp_242), v_t_2415));
  V v_t_2417 = (g_prelude_2e_2b_2b(v_t_2413, v_t_2416));
  return heff_rec_n(5, shape_name__kind__span__selection__children, (V[]){heff_get_n(v_o_241, 0, 2), v_t_249, v_sp_242, v_t_2412, v_t_2417});
}
V g_heff_2ebuild_2equery_2esymbolWith_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2equery_2esymbolWith(a[0], a[1], a[2], a[3]);
}
Clo g_heff_2ebuild_2equery_2esymbolsGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2esymbolsGo_entry, 4, 0};

V g_heff_2ebuild_2equery_2esymbolsGo(V v_c_240, V v_ss_241, V v_x3_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_c_240);
    heff_drop(v_ss_241);
    heff_drop(v_x4_243);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_o_244 = heff_field(v_x3_242, 0);
    V v_os_245 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    switch (heff_tag_of(v_x4_243)) {
    case TAG_Nil: {
      heff_drop(v_c_240);
      heff_drop(v_ss_241);
      heff_drop(v_o_244);
      heff_drop(v_os_245);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_x41_246 = heff_field(v_x4_243, 0);
      V v_sps_247 = heff_field(v_x4_243, 1);
      heff_take_n(v_x4_243, 3ULL, 2);
      switch (heff_tag_of(v_x41_246)) {
      case TAG_MkPair: {
        V v_sp_249 = heff_field(v_x41_246, 1);
        heff_take_n(v_x41_246, 2ULL, 2);
        V v_t_2410 = (g_list_2efilter_24s1716878720x675187502(heff_dup(v_sp_249), heff_dup(v_ss_241)));
        V v_t_2411 = (g_heff_2ebuild_2equery_2esymbolWith(heff_dup(v_c_240), v_o_244, v_sp_249, v_t_2410));
        V v_cell_2412 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_t_2411, heff_hole()});
        V v_u_2413 = (g_heff_2ebuild_2equery_2esymbolsGo_24dps(v_c_240, v_ss_241, v_os_245, v_sps_247, heff_dup(v_cell_2412)));
        heff_drop(v_u_2413);
        return v_cell_2412;
      }
      default: return heff_nomatch(v_x41_246);
      }
    }
    default: return heff_nomatch(v_x4_243);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2equery_2esymbolsGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2equery_2esymbolsGo(a[0], a[1], a[2], a[3]);
}
Clo g_heff_2ebuild_2equery_2esymbolsGo_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2esymbolsGo_24dps_entry, 5, 0};

V g_heff_2ebuild_2equery_2esymbolsGo_24dps(V v_c_240, V v_ss_241, V v_x3_242, V v_x4_243, V v_d_244) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_c_240);
    heff_drop(v_ss_241);
    heff_drop(v_x4_243);
    return heff_setField(v_d_244, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_o_245 = heff_field(v_x3_242, 0);
    V v_os_246 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    switch (heff_tag_of(v_x4_243)) {
    case TAG_Nil: {
      heff_drop(v_c_240);
      heff_drop(v_ss_241);
      heff_drop(v_o_245);
      heff_drop(v_os_246);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      return heff_setField(v_d_244, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_Cons: {
      V v_x41_247 = heff_field(v_x4_243, 0);
      V v_sps_248 = heff_field(v_x4_243, 1);
      heff_take_n(v_x4_243, 3ULL, 2);
      switch (heff_tag_of(v_x41_247)) {
      case TAG_MkPair: {
        V v_sp_2410 = heff_field(v_x41_247, 1);
        heff_take_n(v_x41_247, 2ULL, 2);
        V v_t_2411 = (g_list_2efilter_24s1716878720x675187502(heff_dup(v_sp_2410), heff_dup(v_ss_241)));
        V v_t_2412 = (g_heff_2ebuild_2equery_2esymbolWith(heff_dup(v_c_240), v_o_245, v_sp_2410, v_t_2411));
        V v_cell_2413 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_t_2412, heff_hole()});
        V v_u_2414 = heff_setField(v_d_244, MK_INT(1LL), heff_dup(v_cell_2413));
        heff_drop(v_u_2414);
        V t_0 = v_c_240;
        V t_1 = v_ss_241;
        V t_2 = v_os_246;
        V t_3 = v_sps_248;
        V t_4 = v_cell_2413;
        v_c_240 = t_0;
        v_ss_241 = t_1;
        v_x3_242 = t_2;
        v_x4_243 = t_3;
        v_d_244 = t_4;
        goto top;
      }
      default: return heff_nomatch(v_x41_247);
      }
    }
    default: return heff_nomatch(v_x4_243);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2equery_2esymbolsGo_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2equery_2esymbolsGo_24dps(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ebuild_2equery_2esymbols_lam0(V self, V *args);
V g_heff_2ebuild_2equery_2esymbols_lam1(V self, V *args);
Clo g_heff_2ebuild_2equery_2esymbols_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2equery_2esymbols_entry, 1, 0};

V g_heff_2ebuild_2equery_2esymbols(V v_c_240) {
top: ;
  V v_t_241 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(heff_rfield(v_c_240, 4))));
  V v_t_245 = ({ V a_0 = heff_clo_n(g_heff_2ebuild_2equery_2esymbols_lam0, 2, 1, (V[]){heff_dup(v_c_240)}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_241; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_241); r_; });
  V v_t_246 = heff_get_n(heff_dup(heff_rfield(v_c_240, 5)), 6, 9);
  V v_t_247 = (g_heff_2ebuild_2equery_2esymbolsGo(heff_dup(v_c_240), v_t_245, heff_dup(heff_rfield(v_c_240, 7)), v_t_246));
  V v_t_248 = heff_get_n(heff_dup(heff_rfield(v_c_240, 5)), 3, 9);
  V v_t_2410 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2equery_2esymbols_lam1, 1, 1, (V[]){v_c_240}), v_t_248));
  V v_t_2411 = (g_prelude_2e_2b_2b(v_t_247, v_t_2410));
  HEFF_LAST return g_list_2esortBy_24s1230002843x105774350(v_t_2411);
}
V g_heff_2ebuild_2equery_2esymbols_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2equery_2esymbols(a[0]);
}
V g_heff_2ebuild_2equery_2esymbols_lam0(V self, V *args) {
  V v_acc_242 = args[0];
  V v_x_243 = args[1];
  V v_c_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_244 = (g_heff_2ebuild_2equery_2edeclSites(v_c_240, v_x_243));
  return (g_prelude_2e_2b_2b(v_t_244, v_acc_242));
}
V g_heff_2ebuild_2equery_2esymbols_lam1(V self, V *args) {
  V v_p_249 = args[0];
  V v_c_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_c_240; V a_1 = v_p_249; V r_ = (g_heff_2ebuild_2equery_2ebrokenSymbol(a_0, a_1)); heff_drop(v_p_249); r_; });
}