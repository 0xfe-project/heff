// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define LBL_body 9524841
#define LBL_code 9554612
#define LBL_copies 592412158
#define LBL_def 308863
#define LBL_depth 296830685
#define LBL_done 9584713
#define LBL_emits 297985818
#define LBL_groups 709681407
#define LBL_jss 315076
#define LBL_key 315609
#define LBL_lams 9809570
#define LBL_lines 304335641
#define LBL_lprotos 613175609
#define LBL_made 9839068
#define LBL_mods 9852536
#define LBL_name 9869138
#define LBL_olds 9909235
#define LBL_owner 307523277
#define LBL_params 951713969
#define LBL_prims 308293287
#define LBL_protos 967342774
#define LBL_recipe 1012227257
#define LBL_refs 9991943
#define LBL_safe 10017876
#define LBL_sgSafe 1042218796
#define LBL_sgTotal 97882005
#define LBL_shapes 1043573789
#define LBL_strs 10036521
#define LBL_touched 1244526179
#define LBL_units 312791945
#define LBL_ver 326173
static uint32_t shape_body__touched[] = {LBL_body, LBL_touched};
static uint32_t shape_def__refs[] = {LBL_def, LBL_refs};
static uint32_t shape_groups__copies__emits__jss[] = {LBL_groups, LBL_copies, LBL_emits, LBL_jss};
static uint32_t shape_key__name__body__safe__touched__sgSafe__sgTotal[] = {LBL_key, LBL_name, LBL_body, LBL_safe, LBL_touched, LBL_sgSafe, LBL_sgTotal};
static uint32_t shape_owner__ver__units[] = {LBL_owner, LBL_ver, LBL_units};
static uint32_t shape_ver__lines__params__refs__prims[] = {LBL_ver, LBL_lines, LBL_params, LBL_refs, LBL_prims};
static uint32_t shape_ver__protos__code__strs__lprotos__lams__shapes__prims[] = {LBL_ver, LBL_protos, LBL_code, LBL_strs, LBL_lprotos, LBL_lams, LBL_shapes, LBL_prims};
static uint32_t shape_ver__recipe__depth__safe__made[] = {LBL_ver, LBL_recipe, LBL_depth, LBL_safe, LBL_made};
V g_heff_2ebuild_2ebackcache_2eaddCopy(V, V, V);
V g_heff_2ebuild_2ebackcache_2eaddCopy_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebackcache_2eaddCopy_clo;
V g_heff_2ebuild_2ebackcache_2eaddEmit(V, V, V);
V g_heff_2ebuild_2ebackcache_2eaddEmit_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebackcache_2eaddEmit_clo;
V g_heff_2ebuild_2ebackcache_2eaddGroup(V, V, V);
V g_heff_2ebuild_2ebackcache_2eaddGroup_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebackcache_2eaddGroup_clo;
V g_heff_2ebuild_2ebackcache_2eaddJs(V, V, V);
V g_heff_2ebuild_2ebackcache_2eaddJs_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebackcache_2eaddJs_clo;
V g_heff_2ebuild_2ebackcache_2eallJustB(V);
V g_heff_2ebuild_2ebackcache_2eallJustB_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebackcache_2eallJustB_clo;
HeffT2 g_heff_2ebuild_2ebackcache_2eallJustB_24cpr(V);
HeffT2 g_heff_2ebuild_2ebackcache_2ebackD_24cpr(V, V, V);
V g_heff_2ebuild_2ebackcache_2ebackDir_get(void);
V g_heff_2ebuild_2ebackcache_2ebackText(V, V);
V g_heff_2ebuild_2ebackcache_2ebackText_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebackcache_2ebackText_clo;
V g_heff_2ebuild_2ebackcache_2ebackTexts(V, V, V);
V g_heff_2ebuild_2ebackcache_2ebackTexts_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebackcache_2ebackTexts_clo;
V g_heff_2ebuild_2ebackcache_2ecopyD(V, V);
V g_heff_2ebuild_2ebackcache_2ecopyD_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebackcache_2ecopyD_clo;
V g_heff_2ebuild_2ebackcache_2ecopyText(V);
V g_heff_2ebuild_2ebackcache_2ecopyText_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebackcache_2ecopyText_clo;
HeffT2 g_heff_2ebuild_2ebackcache_2eemitD_24cpr(V, V);
V g_heff_2ebuild_2ebackcache_2eemitText(V, V);
V g_heff_2ebuild_2ebackcache_2eemitText_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebackcache_2eemitText_clo;
V g_heff_2ebuild_2ebackcache_2eentriesAt(V, V, V);
V g_heff_2ebuild_2ebackcache_2eentriesAt_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebackcache_2eentriesAt_clo;
HeffT2 g_heff_2ebuild_2ebackcache_2egroupD_24cpr(V, V);
V g_heff_2ebuild_2ebackcache_2egroupIn(V, V, V, V, V);
V g_heff_2ebuild_2ebackcache_2egroupIn_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebackcache_2egroupIn_clo;
V g_heff_2ebuild_2ebackcache_2egroupText(V, V, V);
V g_heff_2ebuild_2ebackcache_2egroupText_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebackcache_2egroupText_clo;
HeffT2 g_heff_2ebuild_2ebackcache_2ejsD_24cpr(V, V);
V g_heff_2ebuild_2ebackcache_2ejsText(V, V);
V g_heff_2ebuild_2ebackcache_2ejsText_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebackcache_2ejsText_clo;
V g_heff_2ebuild_2ebackcache_2elastDotGo(V, V, V);
V g_heff_2ebuild_2ebackcache_2elastDotGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebackcache_2elastDotGo_clo;
HeffT2 g_heff_2ebuild_2ebackcache_2emadeOf_24cpr(V, V, V);
V g_heff_2ebuild_2ebackcache_2emadeT(V);
V g_heff_2ebuild_2ebackcache_2emadeT_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebackcache_2emadeT_clo;
V g_heff_2ebuild_2ebackcache_2emoduleIn(V, V);
V g_heff_2ebuild_2ebackcache_2emoduleIn_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebackcache_2emoduleIn_clo;
V g_heff_2ebuild_2ebackcache_2enoBack_get(void);
V g_heff_2ebuild_2ebackcache_2epairsGo(V, V);
V g_heff_2ebuild_2ebackcache_2epairsGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebackcache_2epairsGo_clo;
V g_heff_2ebuild_2ebackcache_2eunitD(V, V);
V g_heff_2ebuild_2ebackcache_2eunitD_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebackcache_2eunitD_clo;
V g_heff_2ebuild_2ebackcache_2eunitText(V);
V g_heff_2ebuild_2ebackcache_2eunitText_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebackcache_2eunitText_clo;
V g_heff_2ebuild_2ebackcache_2eversion_get(void);
HeffT2 g_heff_2ebuild_2ebackcache_2ewithRaw_24s1280263334x1684915868_24cpr(V, V);
HeffT2 g_heff_2ebuild_2ebackcache_2ewithRaw_24s1304941386x8760443_24cpr(V, V);
HeffT2 g_heff_2ebuild_2ebackcache_2ewithRaw_24s1413851850x1114201945_24cpr(V, V);
HeffT2 g_heff_2ebuild_2ebackcache_2ewithRaw_24s1993828292x1749017443_24cpr(V, V);
HeffT2 g_heff_2ebuild_2ebackcache_2ewithRaw_24s497340727x548230450_24cpr(V, V);
V g_heff_2ebuild_2edecoder_2ebind_24s823677936x1444069277(V, V, V);
V g_heff_2ebuild_2edecoder_2ebind_24s823677936x1444069277_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edecoder_2ebind_24s823677936x1444069277_clo;
HeffT2 g_heff_2ebuild_2edecoder_2efail_24cpr(V, V);
HeffT2 g_heff_2ebuild_2edecoder_2eint_24cpr(V, V);
HeffT2 g_heff_2ebuild_2edecoder_2estr_24cpr(V, V);
HeffT2 g_heff_2ebuild_2edecoder_2etimes_24s1391953550x1663492198_24cpr(V, V, V);
HeffT2 g_heff_2ebuild_2edecoder_2etimes_24s1603230686x1883420273_24cpr(V, V, V);
HeffT2 g_heff_2ebuild_2edecoder_2etimes_24s1952093399x207461701_24cpr(V, V, V);
HeffT2 g_heff_2ebuild_2edecoder_2etimes_24s1954476619x1073210498_24cpr(V, V, V);
HeffT2 g_heff_2ebuild_2edecoder_2etimes_24s2049614891x1595878686_24cpr(V, V, V);
HeffT2 g_heff_2ebuild_2edecoder_2etimes_24s481066606x2100141841_24cpr(V, V, V);
HeffT2 g_heff_2ebuild_2edecoder_2etimes_24s98296704x1684150820_24cpr(V, V, V);
HeffT2 g_heff_2ebuild_2edecoder_2ewhole_24cpr(V, V, V);
HeffT2 g_heff_2ebuild_2edecoder_2eword_24cpr(V, V);
V g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091(V, V);
V g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_clo;
V g_heff_2ecompile_2eirtext_2etakeExpr_get(void);
HeffT2 g_list_2efind_24s1156299507x501436576_24cpr(V, V);
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24s1056451377x727850182(V, V);
V g_list_2efoldl_24s1056451377x727850182_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1056451377x727850182_clo;
V g_list_2efoldl_24s1103469845x1474178821(V, V, V);
V g_list_2efoldl_24s1103469845x1474178821_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1103469845x1474178821_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1494296198x1800016121(V, V, V);
V g_list_2efoldl_24s1494296198x1800016121_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1494296198x1800016121_clo;
V g_list_2efoldl_24s250221336x1707528432(V, V);
V g_list_2efoldl_24s250221336x1707528432_entry(V self, V *a);
extern Clo g_list_2efoldl_24s250221336x1707528432_clo;
V g_list_2efoldl_24s425699049x1164890302(V, V, V);
V g_list_2efoldl_24s425699049x1164890302_entry(V self, V *a);
extern Clo g_list_2efoldl_24s425699049x1164890302_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2efoldl_24s788343806x1528994845(V, V, V);
V g_list_2efoldl_24s788343806x1528994845_entry(V self, V *a);
extern Clo g_list_2efoldl_24s788343806x1528994845_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1173914895x100384474(V);
V g_list_2emap_24s1173914895x100384474_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_clo;
V g_list_2emap_24s1173914895x100384474_24tok2(V, V);
V g_list_2emap_24s1173914895x100384474_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_24tok2_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24f1085359736x1262841716(V, V);
V g_prelude_2e_2b_2b_24f1085359736x1262841716_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f1085359736x1262841716_clo;
V g_prelude_2e_2b_2b_24f1815933030x829523367(V, V);
V g_prelude_2e_2b_2b_24f1815933030x829523367_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f1815933030x829523367_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_std_2emap_2eempty_get(void);
V g_std_2emap_2einsert_24s93785294x875597928(V, V, V);
V g_std_2emap_2einsert_24s93785294x875597928_entry(V self, V *a);
extern Clo g_std_2emap_2einsert_24s93785294x875597928_clo;
HeffT2 g_std_2emap_2elookup_24s1781110452x2115140655_24cpr(V, V);
HeffT2 g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(V, V);
V g_std_2emap_2esize(V);
V g_std_2emap_2esize_entry(V self, V *a);
extern Clo g_std_2emap_2esize_clo;
V g_std_2emap_2etoListOnto(V, V);
V g_std_2emap_2etoListOnto_entry(V self, V *a);
extern Clo g_std_2emap_2etoListOnto_clo;
HEFF_LIT(g_heff_2ebuild_2ebackcache_2eversion_str0, 14, "heff-backend/8");

static V g_heff_2ebuild_2ebackcache_2eversion_val;
static HEFF_ONCE g_heff_2ebuild_2ebackcache_2eversion_st;
static V g_heff_2ebuild_2ebackcache_2eversion_init(void) {
  return ((V)&g_heff_2ebuild_2ebackcache_2eversion_str0);
}
V g_heff_2ebuild_2ebackcache_2eversion_get(void) {
  if (HEFF_DONE(g_heff_2ebuild_2ebackcache_2eversion_st)) return g_heff_2ebuild_2ebackcache_2eversion_val;
  return heff_global(&g_heff_2ebuild_2ebackcache_2eversion_val, &g_heff_2ebuild_2ebackcache_2eversion_st, g_heff_2ebuild_2ebackcache_2eversion_init);
}
HEFF_LIT(g_heff_2ebuild_2ebackcache_2ebackDir_str0, 2, "b1");

static V g_heff_2ebuild_2ebackcache_2ebackDir_val;
static HEFF_ONCE g_heff_2ebuild_2ebackcache_2ebackDir_st;
static V g_heff_2ebuild_2ebackcache_2ebackDir_init(void) {
  return ((V)&g_heff_2ebuild_2ebackcache_2ebackDir_str0);
}
V g_heff_2ebuild_2ebackcache_2ebackDir_get(void) {
  if (HEFF_DONE(g_heff_2ebuild_2ebackcache_2ebackDir_st)) return g_heff_2ebuild_2ebackcache_2ebackDir_val;
  return heff_global(&g_heff_2ebuild_2ebackcache_2ebackDir_val, &g_heff_2ebuild_2ebackcache_2ebackDir_st, g_heff_2ebuild_2ebackcache_2ebackDir_init);
}
HEFF_LIT(g_heff_2ebuild_2ebackcache_2epairsGo_str0, 1, ":");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2epairsGo_str1, 1, ":");
Clo g_heff_2ebuild_2ebackcache_2epairsGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebackcache_2epairsGo_entry, 2, 0};

V g_heff_2ebuild_2ebackcache_2epairsGo(V v_x1_240, V v_rest_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return v_rest_241;
  }
  case TAG_Cons: {
    V v_p_242 = heff_field(v_x1_240, 0);
    V v_ps_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_rest_244 = (g_heff_2ebuild_2ebackcache_2epairsGo(v_ps_243, v_rest_241));
    switch (heff_tag_of(v_p_242)) {
    case TAG_MkPair: {
      V v_a_245 = heff_field(v_p_242, 0);
      V v_b_246 = heff_field(v_p_242, 1);
      heff_take_n(v_p_242, 3ULL, 2);
      V v_t_247 = heff_intShow(heff_strLength_lent(v_a_245, 0));
      V v_t_248 = heff_strAppend(v_t_247, heff_strAppend(((V)&g_heff_2ebuild_2ebackcache_2epairsGo_str0), v_a_245));
      V v_t_249 = heff_intShow(heff_strLength_lent(v_b_246, 0));
      V v_t_2410 = heff_strAppend(v_t_249, heff_strAppend(((V)&g_heff_2ebuild_2ebackcache_2epairsGo_str1), v_b_246));
      return heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_t_248, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2410, v_rest_244})});
    }
    default: return heff_nomatch(v_p_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2ebackcache_2epairsGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ebackcache_2epairsGo(a[0], a[1]);
}
HEFF_LIT(g_heff_2ebuild_2ebackcache_2eunitText_str0, 1, "t");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2eunitText_str1, 1, "f");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2eunitText_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2eunitText_str3, 1, " ");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2eunitText_str4, 1, ":");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2eunitText_str5, 1, "t");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2eunitText_str6, 1, "f");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2eunitText_str7, 1, ":");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2eunitText_str8, 1, ":");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2eunitText_str9, 1, " ");
Clo g_heff_2ebuild_2ebackcache_2eunitText_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebackcache_2eunitText_entry, 1, 0};

V g_heff_2ebuild_2ebackcache_2eunitText(V v_u_240) {
top: ;
  V v_done_241 = heff_take_field(v_u_240, 0);
  V v_name_242 = heff_take_field(v_u_240, 1);
  V v_refs_243 = heff_take_field(v_u_240, 2);
  V v_sgSafe_244 = heff_take_field(v_u_240, 3);
  V v_sgTotal_245 = heff_get_n(v_u_240, 4, 5);
  V v_s_246 = heff_take_field(v_done_241, 0);
  V v_s_247 = v_name_242;
  V v_xs_248 = v_refs_243;
  V v_t_249;
  if ((heff_dup(v_sgSafe_244) == NTAG(TAG_True))) {
    heff_drop(v_sgSafe_244);
    v_t_249 = ((V)&g_heff_2ebuild_2ebackcache_2eunitText_str0);
  } else {
    heff_drop(v_sgSafe_244);
    v_t_249 = ((V)&g_heff_2ebuild_2ebackcache_2eunitText_str1);
  }
  V v_x2_2410 = (g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091(heff_take_field(v_done_241, 1), NTAG(TAG_Nil)));
  V v_s_2413;
  switch (heff_tag_of(v_x2_2410)) {
  case TAG_Nil: {
    v_s_2413 = ((V)&g_heff_2ebuild_2ebackcache_2eunitText_str2);
    break;
  }
  case TAG_Cons: {
    V v_x_2411 = heff_field(v_x2_2410, 0);
    V v_xs_2412 = heff_field(v_x2_2410, 1);
    heff_take_n(v_x2_2410, 3ULL, 2);
    v_s_2413 = ({ V a_0 = ((V)&g_heff_2ebuild_2ebackcache_2eunitText_str3); V a_1 = v_x_2411; V a_2 = v_xs_2412; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2412); r_; });
    break;
  }
  default: heff_nomatch(v_x2_2410);
  }
  V v_t_2414 = heff_intShow(heff_strLength_lent(v_s_2413, 0));
  V v_t_2415 = heff_strAppend(v_t_2414, heff_strAppend(((V)&g_heff_2ebuild_2ebackcache_2eunitText_str4), v_s_2413));
  V v_t_2416 = heff_take_field(v_done_241, 2);
  V v_t_2417;
  if ((heff_dup(v_t_2416) == NTAG(TAG_True))) {
    heff_drop(v_t_2416);
    v_t_2417 = ((V)&g_heff_2ebuild_2ebackcache_2eunitText_str5);
  } else {
    heff_drop(v_t_2416);
    v_t_2417 = ((V)&g_heff_2ebuild_2ebackcache_2eunitText_str6);
  }
  V v_ps_2418 = heff_get_n(v_done_241, 3, 4);
  V v_t_2419 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_ps_2418));
  V v_t_2420 = (g_heff_2ebuild_2ebackcache_2epairsGo(v_ps_2418, NTAG(TAG_Nil)));
  V v_t_2421 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_t_2419), v_t_2420});
  V v_t_2422 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2415, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2417, v_t_2421})});
  V v_t_2423 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_sgTotal_245), v_t_2422});
  V v_rest_2424 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_249, v_t_2423});
  V v_t_2425 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_248));
  V v_t_2426 = heff_intShow(v_t_2425);
  V v_t_2427 = (g_prelude_2e_2b_2b_24f1815933030x829523367(v_rest_2424, v_xs_248));
  V v_t_2428 = heff_intShow(heff_strLength_lent(v_s_246, 0));
  V v_t_2429 = heff_strAppend(v_t_2428, heff_strAppend(((V)&g_heff_2ebuild_2ebackcache_2eunitText_str7), v_s_246));
  V v_t_2430 = heff_intShow(heff_strLength_lent(v_s_247, 0));
  V v_t_2431 = heff_strAppend(v_t_2430, heff_strAppend(((V)&g_heff_2ebuild_2ebackcache_2eunitText_str8), v_s_247));
  V v_t_2432 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2431, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2426, v_t_2427})});
  return ({ V a_0 = ((V)&g_heff_2ebuild_2ebackcache_2eunitText_str9); V a_1 = v_t_2429; V a_2 = v_t_2432; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop_tag(v_t_2432, 2); r_; });
}
V g_heff_2ebuild_2ebackcache_2eunitText_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ebackcache_2eunitText(a[0]);
}
HEFF_LIT(g_heff_2ebuild_2ebackcache_2emadeT_str0, 1, "n");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2emadeT_str1, 0, "");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2emadeT_str2, 1, " ");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2emadeT_str3, 1, ":");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2emadeT_str4, 1, "j");
Clo g_heff_2ebuild_2ebackcache_2emadeT_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebackcache_2emadeT_entry, 1, 0};

V g_heff_2ebuild_2ebackcache_2emadeT(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nothing: {
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ebackcache_2emadeT_str0), NTAG(TAG_Nil)});
  }
  case TAG_Just: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_MkPair: {
      V v_b_242 = heff_field(v_x11_241, 0);
      V v_t_243 = heff_field(v_x11_241, 1);
      V v_x2_244 = (g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091(heff_dup(v_b_242), NTAG(TAG_Nil)));
      V v_s_247;
      switch (heff_tag_of(v_x2_244)) {
      case TAG_Nil: {
        v_s_247 = ((V)&g_heff_2ebuild_2ebackcache_2emadeT_str1);
        break;
      }
      case TAG_Cons: {
        V v_x_245 = heff_field(v_x2_244, 0);
        V v_xs_246 = heff_field(v_x2_244, 1);
        heff_take_n(v_x2_244, 3ULL, 2);
        v_s_247 = ({ V a_0 = ((V)&g_heff_2ebuild_2ebackcache_2emadeT_str2); V a_1 = v_x_245; V a_2 = v_xs_246; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_246); r_; });
        break;
      }
      default: heff_nomatch(v_x2_244);
      }
      V v_t_248 = heff_intShow(heff_strLength_lent(v_s_247, 0));
      V v_t_249 = heff_strAppend(v_t_248, heff_strAppend(((V)&g_heff_2ebuild_2ebackcache_2emadeT_str3), v_s_247));
      V v_t_2410 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_t_243));
      V v_t_2411 = (g_heff_2ebuild_2ebackcache_2epairsGo(heff_dup(v_t_243), NTAG(TAG_Nil)));
      V v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_t_2410), v_t_2411});
      return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ebackcache_2emadeT_str4), heff_tag_n(TAG_Cons, 2, (V[]){v_t_249, v_t_2412})});
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2ebackcache_2emadeT_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ebackcache_2emadeT(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ebuild_2ebackcache_2ecopyText_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2ecopyText_str1, 1, " ");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2ecopyText_str2, 1, ":");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2ecopyText_str3, 1, ":");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2ecopyText_str4, 1, ":");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2ecopyText_str5, 1, "t");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2ecopyText_str6, 1, "f");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2ecopyText_str7, 1, " ");
Clo g_heff_2ebuild_2ebackcache_2ecopyText_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebackcache_2ecopyText_entry, 1, 0};

V g_heff_2ebuild_2ebackcache_2ecopyText(V v_c_240) {
top: ;
  V v_name_241 = heff_take_field(v_c_240, 0);
  V v_ver_242 = heff_take_field(v_c_240, 1);
  V v_recipe_243 = heff_take_field(v_c_240, 2);
  V v_made_244 = heff_take_field(v_c_240, 5);
  V v_depth_245 = heff_take_field(v_c_240, 3);
  V v_safe_246 = heff_get_n(v_c_240, 4, 6);
  V v_s_247 = v_name_241;
  V v_s_248 = v_ver_242;
  V v_x2_249 = (g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091(v_recipe_243, NTAG(TAG_Nil)));
  V v_s_2412;
  switch (heff_tag_of(v_x2_249)) {
  case TAG_Nil: {
    v_s_2412 = ((V)&g_heff_2ebuild_2ebackcache_2ecopyText_str0);
    break;
  }
  case TAG_Cons: {
    V v_x_2410 = heff_field(v_x2_249, 0);
    V v_xs_2411 = heff_field(v_x2_249, 1);
    heff_take_n(v_x2_249, 3ULL, 2);
    v_s_2412 = ({ V a_0 = ((V)&g_heff_2ebuild_2ebackcache_2ecopyText_str1); V a_1 = v_x_2410; V a_2 = v_xs_2411; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2411); r_; });
    break;
  }
  default: heff_nomatch(v_x2_249);
  }
  V v_t_2413 = ({ V a_0 = v_made_244; V r_ = (g_heff_2ebuild_2ebackcache_2emadeT(a_0)); heff_drop(v_made_244); r_; });
  V v_t_2414 = heff_intShow(heff_strLength_lent(v_s_247, 0));
  V v_t_2415 = heff_strAppend(v_t_2414, heff_strAppend(((V)&g_heff_2ebuild_2ebackcache_2ecopyText_str2), v_s_247));
  V v_t_2416 = heff_intShow(heff_strLength_lent(v_s_248, 0));
  V v_t_2417 = heff_strAppend(v_t_2416, heff_strAppend(((V)&g_heff_2ebuild_2ebackcache_2ecopyText_str3), v_s_248));
  V v_t_2418 = heff_intShow(heff_strLength_lent(v_s_2412, 0));
  V v_t_2419 = heff_strAppend(v_t_2418, heff_strAppend(((V)&g_heff_2ebuild_2ebackcache_2ecopyText_str4), v_s_2412));
  V v_t_2420;
  if ((heff_dup(v_safe_246) == NTAG(TAG_True))) {
    heff_drop(v_safe_246);
    v_t_2420 = ((V)&g_heff_2ebuild_2ebackcache_2ecopyText_str5);
  } else {
    heff_drop(v_safe_246);
    v_t_2420 = ((V)&g_heff_2ebuild_2ebackcache_2ecopyText_str6);
  }
  V v_t_2421 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_depth_245), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2420, v_t_2413})});
  V v_t_2422 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2417, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2419, v_t_2421})});
  return ({ V a_0 = ((V)&g_heff_2ebuild_2ebackcache_2ecopyText_str7); V a_1 = v_t_2415; V a_2 = v_t_2422; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop_tag(v_t_2422, 2); r_; });
}
V g_heff_2ebuild_2ebackcache_2ecopyText_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ebackcache_2ecopyText(a[0]);
}
HEFF_LIT(g_heff_2ebuild_2ebackcache_2eemitText_str0, 1, ":");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2eemitText_str1, 1, ":");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2eemitText_str2, 1, " ");
Clo g_heff_2ebuild_2ebackcache_2eemitText_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebackcache_2eemitText_entry, 2, 0};

V g_heff_2ebuild_2ebackcache_2eemitText(V v_key_240, V v_k_241) {
top: ;
  V v_ver_242 = heff_take_field(v_k_241, 0);
  V v_protos_243 = heff_take_field(v_k_241, 1);
  V v_code_244 = heff_take_field(v_k_241, 2);
  V v_strs_245 = heff_take_field(v_k_241, 3);
  V v_lprotos_246 = heff_take_field(v_k_241, 4);
  V v_lams_247 = heff_take_field(v_k_241, 5);
  V v_shapes_248 = heff_take_field(v_k_241, 6);
  V v_prims_249 = heff_get_n(v_k_241, 7, 8);
  V v_s_2410 = v_ver_242;
  V v_xs_2411 = v_protos_243;
  V v_xs_2412 = v_code_244;
  V v_xs_2413 = v_strs_245;
  V v_xs_2414 = v_lprotos_246;
  V v_xs_2415 = v_lams_247;
  V v_xs_2416 = v_shapes_248;
  V v_xs_2417 = v_prims_249;
  V v_t_2418 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_2417));
  V v_t_2419 = (g_prelude_2e_2b_2b_24f1815933030x829523367(NTAG(TAG_Nil), v_xs_2417));
  V v_rest_2420 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_t_2418), v_t_2419});
  V v_t_2421 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_2416));
  V v_t_2422 = (g_prelude_2e_2b_2b_24f1815933030x829523367(v_rest_2420, v_xs_2416));
  V v_rest_2423 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_t_2421), v_t_2422});
  V v_t_2424 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_2415));
  V v_t_2425 = (g_prelude_2e_2b_2b_24f1815933030x829523367(v_rest_2423, v_xs_2415));
  V v_rest_2426 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_t_2424), v_t_2425});
  V v_t_2427 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_2414));
  V v_t_2428 = (g_prelude_2e_2b_2b_24f1815933030x829523367(v_rest_2426, v_xs_2414));
  V v_rest_2429 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_t_2427), v_t_2428});
  V v_t_2430 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_2413));
  V v_t_2431 = (g_prelude_2e_2b_2b_24f1815933030x829523367(v_rest_2429, v_xs_2413));
  V v_rest_2432 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_t_2430), v_t_2431});
  V v_t_2433 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_2412));
  V v_t_2434 = (g_prelude_2e_2b_2b_24f1815933030x829523367(v_rest_2432, v_xs_2412));
  V v_rest_2435 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_t_2433), v_t_2434});
  V v_t_2436 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_2411));
  V v_t_2437 = heff_intShow(v_t_2436);
  V v_t_2438 = (g_prelude_2e_2b_2b_24f1815933030x829523367(v_rest_2435, v_xs_2411));
  V v_t_2439 = heff_intShow(heff_strLength_lent(v_key_240, 0));
  V v_t_2440 = heff_strAppend(v_t_2439, heff_strAppend(((V)&g_heff_2ebuild_2ebackcache_2eemitText_str0), v_key_240));
  V v_t_2441 = heff_intShow(heff_strLength_lent(v_s_2410, 0));
  V v_t_2442 = heff_strAppend(v_t_2441, heff_strAppend(((V)&g_heff_2ebuild_2ebackcache_2eemitText_str1), v_s_2410));
  V v_t_2443 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2442, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2437, v_t_2438})});
  return ({ V a_0 = ((V)&g_heff_2ebuild_2ebackcache_2eemitText_str2); V a_1 = v_t_2440; V a_2 = v_t_2443; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop_tag(v_t_2443, 2); r_; });
}
V g_heff_2ebuild_2ebackcache_2eemitText_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ebackcache_2eemitText(a[0], a[1]);
}
HEFF_LIT(g_heff_2ebuild_2ebackcache_2ejsText_str0, 1, ":");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2ejsText_str1, 1, ":");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2ejsText_str2, 1, " ");
Clo g_heff_2ebuild_2ebackcache_2ejsText_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebackcache_2ejsText_entry, 2, 0};

V g_heff_2ebuild_2ebackcache_2ejsText(V v_key_240, V v_k_241) {
top: ;
  V v_ver_242 = heff_take_field(v_k_241, 0);
  V v_lines_243 = heff_take_field(v_k_241, 1);
  V v_params_244 = heff_take_field(v_k_241, 2);
  V v_refs_245 = heff_take_field(v_k_241, 3);
  V v_prims_246 = heff_get_n(v_k_241, 4, 5);
  V v_s_247 = v_ver_242;
  V v_xs_248 = v_lines_243;
  V v_xs_249 = v_params_244;
  V v_xs_2410 = v_refs_245;
  V v_xs_2411 = v_prims_246;
  V v_t_2412 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_2411));
  V v_t_2413 = (g_prelude_2e_2b_2b_24f1815933030x829523367(NTAG(TAG_Nil), v_xs_2411));
  V v_rest_2414 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_t_2412), v_t_2413});
  V v_t_2415 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_2410));
  V v_t_2416 = (g_prelude_2e_2b_2b_24f1815933030x829523367(v_rest_2414, v_xs_2410));
  V v_rest_2417 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_t_2415), v_t_2416});
  V v_t_2418 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_249));
  V v_t_2419 = (g_prelude_2e_2b_2b_24f1815933030x829523367(v_rest_2417, v_xs_249));
  V v_rest_2420 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_t_2418), v_t_2419});
  V v_t_2421 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_248));
  V v_t_2422 = heff_intShow(v_t_2421);
  V v_t_2423 = (g_prelude_2e_2b_2b_24f1815933030x829523367(v_rest_2420, v_xs_248));
  V v_t_2424 = heff_intShow(heff_strLength_lent(v_key_240, 0));
  V v_t_2425 = heff_strAppend(v_t_2424, heff_strAppend(((V)&g_heff_2ebuild_2ebackcache_2ejsText_str0), v_key_240));
  V v_t_2426 = heff_intShow(heff_strLength_lent(v_s_247, 0));
  V v_t_2427 = heff_strAppend(v_t_2426, heff_strAppend(((V)&g_heff_2ebuild_2ebackcache_2ejsText_str1), v_s_247));
  V v_t_2428 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2427, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2422, v_t_2423})});
  return ({ V a_0 = ((V)&g_heff_2ebuild_2ebackcache_2ejsText_str2); V a_1 = v_t_2425; V a_2 = v_t_2428; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop_tag(v_t_2428, 2); r_; });
}
V g_heff_2ebuild_2ebackcache_2ejsText_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ebackcache_2ejsText(a[0], a[1]);
}
V g_heff_2ebuild_2ebackcache_2eunitD_lam2(V self, V *args);
V g_heff_2ebuild_2ebackcache_2eunitD_lam1(V self, V *args);
V g_heff_2ebuild_2ebackcache_2eunitD_lam0(V self, V *args);
Clo g_heff_2ebuild_2ebackcache_2eunitD_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebackcache_2eunitD_entry, 2, 0};

V g_heff_2ebuild_2ebackcache_2eunitD(V v_s_240, V v_i_241) {
top: ;
  HeffT2 v_t_242 = (g_heff_2ebuild_2edecoder_2estr_24cpr(v_s_240, v_i_241));
  {
    V v_field_244 = v_t_242.f[1];
    int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
    if ((v_tag_243 == ((int64_t)0ULL))) {
      V v_x31_245 = v_field_244;
      switch (heff_tag_of(v_x31_245)) {
      case TAG_MkPair: {
        V v_x_246 = heff_field(v_x31_245, 0);
        V v_j_247 = heff_field(v_x31_245, 1);
        heff_take_n(v_x31_245, 3ULL, 2);
        HeffT2 v_t_248 = (g_heff_2ebuild_2edecoder_2estr_24cpr(v_s_240, v_j_247));
        {
          V v_field_2410 = v_t_248.f[1];
          int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
          if ((v_tag_249 == ((int64_t)0ULL))) {
            V v_x31_2411 = v_field_2410;
            switch (heff_tag_of(v_x31_2411)) {
            case TAG_MkPair: {
              V v_x_2412 = heff_field(v_x31_2411, 0);
              V v_j_2413 = heff_field(v_x31_2411, 1);
              heff_take_n(v_x31_2411, 3ULL, 2);
              HeffT2 v_t_2414 = (g_heff_2ebuild_2edecoder_2eint_24cpr(v_s_240, v_j_2413));
              {
                V v_field_2416 = v_t_2414.f[1];
                int64_t v_tag_2415 = ((int64_t)v_t_2414.f[0]);
                if ((v_tag_2415 == ((int64_t)0ULL))) {
                  V v_x31_2417 = v_field_2416;
                  switch (heff_tag_of(v_x31_2417)) {
                  case TAG_MkPair: {
                    V v_x_2418 = heff_field(v_x31_2417, 0);
                    V v_j_2419 = heff_field(v_x31_2417, 1);
                    heff_take_n(v_x31_2417, 3ULL, 2);
                    HeffT2 v_t_2420 = (g_heff_2ebuild_2edecoder_2etimes_24s1603230686x1883420273_24cpr(v_x_2418, v_s_240, v_j_2419));
                    {
                      V v_field_2422 = v_t_2420.f[1];
                      int64_t v_tag_2421 = ((int64_t)v_t_2420.f[0]);
                      if ((v_tag_2421 == ((int64_t)0ULL))) {
                        V v_x31_2423 = v_field_2422;
                        switch (heff_tag_of(v_x31_2423)) {
                        case TAG_MkPair: {
                          V v_x_2424 = heff_field(v_x31_2423, 0);
                          V v_j_2425 = heff_field(v_x31_2423, 1);
                          heff_take_n(v_x31_2423, 3ULL, 2);
                          return (g_heff_2ebuild_2edecoder_2ebind_24s823677936x1444069277(heff_clo_n(g_heff_2ebuild_2ebackcache_2eunitD_lam0, 3, 3, (V[]){v_x_246, v_x_2412, v_x_2424}), v_s_240, v_j_2425));
                        }
                        default: return heff_nomatch(v_x31_2423);
                        }
                      } else {
                        heff_drop(v_s_240);
                        heff_drop(v_x_246);
                        heff_drop(v_x_2412);
                        heff_drop(v_field_2422);
                        return NTAG(TAG_Nothing);
                      }
                    }
                  }
                  default: return heff_nomatch(v_x31_2417);
                  }
                } else {
                  heff_drop(v_s_240);
                  heff_drop(v_x_246);
                  heff_drop(v_x_2412);
                  heff_drop(v_field_2416);
                  return NTAG(TAG_Nothing);
                }
              }
            }
            default: return heff_nomatch(v_x31_2411);
            }
          } else {
            heff_drop(v_s_240);
            heff_drop(v_x_246);
            heff_drop(v_field_2410);
            return NTAG(TAG_Nothing);
          }
        }
      }
      default: return heff_nomatch(v_x31_245);
      }
    } else {
      heff_drop(v_s_240);
      heff_drop(v_field_244);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_heff_2ebuild_2ebackcache_2eunitD_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ebackcache_2eunitD(a[0], a[1]);
}
V g_heff_2ebuild_2ebackcache_2eunitD_lam2(V self, V *args) {
  V v_u_2456 = args[0];
  V v_x_2439 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2456);
  HeffT2 v_t_2457 = (g_heff_2ebuild_2edecoder_2ewhole_24cpr(heff_dup(g_heff_2ecompile_2eirtext_2etakeExpr_get()), v_x_2439, MK_INT(0LL)));
  {
    V v_field_2459 = v_t_2457.f[1];
    int64_t v_tag_2458 = ((int64_t)v_t_2457.f[0]);
    if ((v_tag_2458 == ((int64_t)0ULL))) {
      V v_x11_2460 = v_field_2459;
      switch (heff_tag_of(v_x11_2460)) {
      case TAG_MkPair: {
        V v_x_2461 = heff_field(v_x11_2460, 0);
        heff_take_n(v_x11_2460, 1ULL, 2);
        return heff_tag_n(TAG_Just, 1, (V[]){v_x_2461});
      }
      default: return heff_nomatch(v_x11_2460);
      }
    } else {
      heff_drop(v_field_2459);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_heff_2ebuild_2ebackcache_2eunitD_lam1(V self, V *args) {
  V v_safe_2441 = args[0];
  V v_s_2442 = args[1];
  V v_i_2443 = args[2];
  V v_x_246 = heff_env(self)[0];
  V v_x_2412 = heff_env(self)[1];
  V v_x_2439 = heff_env(self)[2];
  V v_sgSafe_2426 = heff_env(self)[3];
  V v_x_2433 = heff_env(self)[4];
  V v_x_2424 = heff_env(self)[5];
  heff_clo_take(self, 6);
  HeffT2 v_t_2444 = (g_heff_2ebuild_2edecoder_2eint_24cpr(v_s_2442, v_i_2443));
  {
    V v_field_2446 = v_t_2444.f[1];
    int64_t v_tag_2445 = ((int64_t)v_t_2444.f[0]);
    if ((v_tag_2445 == ((int64_t)0ULL))) {
      V v_x31_2447 = v_field_2446;
      switch (heff_tag_of(v_x31_2447)) {
      case TAG_MkPair: {
        V v_x_2448 = heff_field(v_x31_2447, 0);
        V v_j_2449 = heff_field(v_x31_2447, 1);
        V v_ru_24x31_2447_24MkPair = heff_take_reuse_n(v_x31_2447, 3ULL, 2);
        HeffT2 v_t_2450 = ({ V a_0 = v_x_2448; V a_1 = v_s_2442; V a_2 = v_j_2449; HeffT2 r_ = (g_heff_2ebuild_2edecoder_2etimes_24s98296704x1684150820_24cpr(a_0, a_1, a_2)); heff_drop(v_s_2442); r_; });
        {
          V v_field_2452 = v_t_2450.f[1];
          int64_t v_tag_2451 = ((int64_t)v_t_2450.f[0]);
          if ((v_tag_2451 == ((int64_t)0ULL))) {
            V v_x31_2453 = v_field_2452;
            switch (heff_tag_of(v_x31_2453)) {
            case TAG_MkPair: {
              V v_x_2454 = heff_field(v_x31_2453, 0);
              V v_j_2455 = heff_field(v_x31_2453, 1);
              heff_take_n(v_x31_2453, 3ULL, 2);
              V v_t_2463 = heff_rec_n(2, shape_def__refs, (V[]){heff_rec_n(7, shape_key__name__body__safe__touched__sgSafe__sgTotal, (V[]){v_x_246, v_x_2412, heff_clo_n(g_heff_2ebuild_2ebackcache_2eunitD_lam2, 1, 1, (V[]){v_x_2439}), v_safe_2441, v_x_2454, v_sgSafe_2426, v_x_2433}), v_x_2424});
              return heff_tag_n(TAG_Just, 1, (V[]){heff_tag_at_n(v_ru_24x31_2447_24MkPair, TAG_MkPair, 2, (V[]){v_t_2463, v_j_2455})});
            }
            default: return heff_nomatch(v_x31_2453);
            }
          } else {
            heff_drop(v_safe_2441);
            heff_drop(v_x_246);
            heff_drop(v_x_2412);
            heff_drop(v_x_2439);
            heff_drop(v_sgSafe_2426);
            heff_drop(v_x_2433);
            heff_drop(v_x_2424);
            heff_drop_cell(v_ru_24x31_2447_24MkPair, 2);
            heff_drop(v_field_2452);
            return NTAG(TAG_Nothing);
          }
        }
      }
      default: return heff_nomatch(v_x31_2447);
      }
    } else {
      heff_drop(v_safe_2441);
      heff_drop(v_s_2442);
      heff_drop(v_x_246);
      heff_drop(v_x_2412);
      heff_drop(v_x_2439);
      heff_drop(v_sgSafe_2426);
      heff_drop(v_x_2433);
      heff_drop(v_x_2424);
      heff_drop(v_field_2446);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_heff_2ebuild_2ebackcache_2eunitD_lam0(V self, V *args) {
  V v_sgSafe_2426 = args[0];
  V v_s_2427 = args[1];
  V v_i_2428 = args[2];
  V v_x_246 = heff_env(self)[0];
  V v_x_2412 = heff_env(self)[1];
  V v_x_2424 = heff_env(self)[2];
  heff_clo_take(self, 3);
  HeffT2 v_t_2429 = (g_heff_2ebuild_2edecoder_2eint_24cpr(v_s_2427, v_i_2428));
  {
    V v_field_2431 = v_t_2429.f[1];
    int64_t v_tag_2430 = ((int64_t)v_t_2429.f[0]);
    if ((v_tag_2430 == ((int64_t)0ULL))) {
      V v_x31_2432 = v_field_2431;
      switch (heff_tag_of(v_x31_2432)) {
      case TAG_MkPair: {
        V v_x_2433 = heff_field(v_x31_2432, 0);
        V v_j_2434 = heff_field(v_x31_2432, 1);
        heff_take_n(v_x31_2432, 3ULL, 2);
        HeffT2 v_t_2435 = (g_heff_2ebuild_2edecoder_2estr_24cpr(v_s_2427, v_j_2434));
        {
          V v_field_2437 = v_t_2435.f[1];
          int64_t v_tag_2436 = ((int64_t)v_t_2435.f[0]);
          if ((v_tag_2436 == ((int64_t)0ULL))) {
            V v_x31_2438 = v_field_2437;
            switch (heff_tag_of(v_x31_2438)) {
            case TAG_MkPair: {
              V v_x_2439 = heff_field(v_x31_2438, 0);
              V v_j_2440 = heff_field(v_x31_2438, 1);
              heff_take_n(v_x31_2438, 3ULL, 2);
              return (g_heff_2ebuild_2edecoder_2ebind_24s823677936x1444069277(heff_clo_n(g_heff_2ebuild_2ebackcache_2eunitD_lam1, 3, 6, (V[]){v_x_246, v_x_2412, v_x_2439, v_sgSafe_2426, v_x_2433, v_x_2424}), v_s_2427, v_j_2440));
            }
            default: return heff_nomatch(v_x31_2438);
            }
          } else {
            heff_drop(v_sgSafe_2426);
            heff_drop(v_s_2427);
            heff_drop(v_x_246);
            heff_drop(v_x_2412);
            heff_drop(v_x_2424);
            heff_drop(v_x_2433);
            heff_drop(v_field_2437);
            return NTAG(TAG_Nothing);
          }
        }
      }
      default: return heff_nomatch(v_x31_2432);
      }
    } else {
      heff_drop(v_sgSafe_2426);
      heff_drop(v_s_2427);
      heff_drop(v_x_246);
      heff_drop(v_x_2412);
      heff_drop(v_x_2424);
      heff_drop(v_field_2431);
      return NTAG(TAG_Nothing);
    }
  }
}

HeffT2 g_heff_2ebuild_2ebackcache_2ewithRaw_24s1993828292x1749017443_24cpr(V v_s_240, V v_i_241) {
top: ;
  V v_x3_242 = heff_tr(g_heff_2ebuild_2ebackcache_2eunitD(heff_dup(v_s_240), heff_dup(v_i_241)));
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nothing: {
    heff_drop(v_s_240);
    heff_drop(v_i_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Just: {
    V v_x31_243 = heff_field(v_x3_242, 0);
    heff_take_n(v_x3_242, 1ULL, 1);
    switch (heff_tag_of(v_x31_243)) {
    case TAG_MkPair: {
      V v_x_244 = heff_field(v_x31_243, 0);
      V v_j_245 = heff_field(v_x31_243, 1);
      V v_ru_24x31_243_24MkPair = heff_take_reuse_n(v_x31_243, 3ULL, 2);
      V v_t_246;
      if ((heff_intLt_c_lent(v_i_241, v_j_245, 0) && (heff_unbox_word(heff_strByteAt(heff_dup(v_s_240), heff_intSub(heff_dup(v_j_245), MK_INT(1LL)))) == ((int64_t)32ULL)))) {
        v_t_246 = heff_intSub(heff_dup(v_j_245), MK_INT(1LL));
      } else {
        v_t_246 = heff_dup(v_j_245);
      }
      V v_t_247 = heff_tag_at_n(v_ru_24x31_243_24MkPair, TAG_MkPair, 2, (V[]){v_x_244, heff_strSlice(v_s_240, v_i_241, v_t_246)});
      V v_f_248 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_247, v_j_245});
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_248}});
    }
    default: return ((HeffT2){{heff_nomatch(v_x31_243)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x3_242)}});
  }
}

HeffT2 g_heff_2ebuild_2ebackcache_2egroupD_24cpr(V v_s_240, V v_i_241) {
top: ;
  HeffT2 v_t_242 = (g_heff_2ebuild_2edecoder_2estr_24cpr(v_s_240, v_i_241));
  {
    V v_field_244 = v_t_242.f[1];
    int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
    if ((v_tag_243 == ((int64_t)0ULL))) {
      V v_x31_245 = v_field_244;
      switch (heff_tag_of(v_x31_245)) {
      case TAG_MkPair: {
        V v_x_246 = heff_field(v_x31_245, 0);
        V v_j_247 = heff_field(v_x31_245, 1);
        V v_ru_24x31_245_24MkPair = heff_take_reuse_n(v_x31_245, 3ULL, 2);
        HeffT2 v_t_248 = (g_heff_2ebuild_2edecoder_2estr_24cpr(v_s_240, v_j_247));
        {
          V v_field_2410 = v_t_248.f[1];
          int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
          if ((v_tag_249 == ((int64_t)0ULL))) {
            V v_x31_2411 = v_field_2410;
            switch (heff_tag_of(v_x31_2411)) {
            case TAG_MkPair: {
              V v_x_2412 = heff_field(v_x31_2411, 0);
              V v_j_2413 = heff_field(v_x31_2411, 1);
              heff_take_n(v_x31_2411, 3ULL, 2);
              HeffT2 v_t_2414 = (g_heff_2ebuild_2edecoder_2eint_24cpr(v_s_240, v_j_2413));
              {
                V v_field_2416 = v_t_2414.f[1];
                int64_t v_tag_2415 = ((int64_t)v_t_2414.f[0]);
                if ((v_tag_2415 == ((int64_t)0ULL))) {
                  V v_x31_2417 = v_field_2416;
                  switch (heff_tag_of(v_x31_2417)) {
                  case TAG_MkPair: {
                    V v_x_2418 = heff_field(v_x31_2417, 0);
                    V v_j_2419 = heff_field(v_x31_2417, 1);
                    heff_take_n(v_x31_2417, 3ULL, 2);
                    HeffT2 v_t_2420 = (g_heff_2ebuild_2edecoder_2etimes_24s1952093399x207461701_24cpr(v_x_2418, v_s_240, v_j_2419));
                    {
                      V v_field_2422 = v_t_2420.f[1];
                      int64_t v_tag_2421 = ((int64_t)v_t_2420.f[0]);
                      if ((v_tag_2421 == ((int64_t)0ULL))) {
                        V v_x31_2423 = v_field_2422;
                        switch (heff_tag_of(v_x31_2423)) {
                        case TAG_MkPair: {
                          V v_x_2424 = heff_field(v_x31_2423, 0);
                          V v_j_2425 = heff_field(v_x31_2423, 1);
                          heff_take_n(v_x31_2423, 3ULL, 2);
                          V v_t_2426 = heff_tag_at_n(v_ru_24x31_245_24MkPair, TAG_MkPair, 2, (V[]){heff_rec_n(3, shape_owner__ver__units, (V[]){v_x_246, v_x_2412, v_x_2424}), v_j_2425});
                          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2426}});
                        }
                        default: return ((HeffT2){{heff_nomatch(v_x31_2423)}});
                        }
                      } else {
                        heff_drop(v_x_246);
                        heff_drop_cell(v_ru_24x31_245_24MkPair, 2);
                        heff_drop(v_x_2412);
                        heff_drop(v_field_2422);
                        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                      }
                    }
                  }
                  default: return ((HeffT2){{heff_nomatch(v_x31_2417)}});
                  }
                } else {
                  heff_drop(v_s_240);
                  heff_drop(v_x_246);
                  heff_drop_cell(v_ru_24x31_245_24MkPair, 2);
                  heff_drop(v_x_2412);
                  heff_drop(v_field_2416);
                  return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                }
              }
            }
            default: return ((HeffT2){{heff_nomatch(v_x31_2411)}});
            }
          } else {
            heff_drop(v_s_240);
            heff_drop(v_x_246);
            heff_drop_cell(v_ru_24x31_245_24MkPair, 2);
            heff_drop(v_field_2410);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x31_245)}});
      }
    } else {
      heff_drop(v_s_240);
      heff_drop(v_field_244);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
  }
}
HEFF_LIT(g_heff_2ebuild_2ebackcache_2emadeOf_24cpr_str0, 1, "j");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2emadeOf_24cpr_str1, 1, "n");
V g_heff_2ebuild_2ebackcache_2emadeOf_24cpr_lam0(V self, V *args);

HeffT2 g_heff_2ebuild_2ebackcache_2emadeOf_24cpr(V v_x1_240, V v_z_241, V v_z_242) {
top: ;
  if (heff_strEq_c_lent(v_x1_240, ((V)&g_heff_2ebuild_2ebackcache_2emadeOf_24cpr_str0), 2)) {
    HeffT2 v_t_243 = (g_heff_2ebuild_2edecoder_2estr_24cpr(v_z_241, v_z_242));
    {
      V v_field_245 = v_t_243.f[1];
      int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
      if ((v_tag_244 == ((int64_t)0ULL))) {
        V v_x31_246 = v_field_245;
        switch (heff_tag_of(v_x31_246)) {
        case TAG_MkPair: {
          V v_x_247 = heff_field(v_x31_246, 0);
          V v_j_248 = heff_field(v_x31_246, 1);
          V v_ru_24x31_246_24MkPair = heff_take_reuse_n(v_x31_246, 3ULL, 2);
          HeffT2 v_t_249 = (g_heff_2ebuild_2edecoder_2eint_24cpr(v_z_241, v_j_248));
          {
            V v_field_2411 = v_t_249.f[1];
            int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
            if ((v_tag_2410 == ((int64_t)0ULL))) {
              V v_x31_2412 = v_field_2411;
              switch (heff_tag_of(v_x31_2412)) {
              case TAG_MkPair: {
                V v_x_2413 = heff_field(v_x31_2412, 0);
                V v_j_2414 = heff_field(v_x31_2412, 1);
                heff_take_n(v_x31_2412, 3ULL, 2);
                HeffT2 v_t_2415 = (g_heff_2ebuild_2edecoder_2etimes_24s98296704x1684150820_24cpr(v_x_2413, v_z_241, v_j_2414));
                {
                  V v_field_2417 = v_t_2415.f[1];
                  int64_t v_tag_2416 = ((int64_t)v_t_2415.f[0]);
                  if ((v_tag_2416 == ((int64_t)0ULL))) {
                    V v_x31_2418 = v_field_2417;
                    switch (heff_tag_of(v_x31_2418)) {
                    case TAG_MkPair: {
                      V v_x_2419 = heff_field(v_x31_2418, 0);
                      V v_j_2420 = heff_field(v_x31_2418, 1);
                      heff_take_n(v_x31_2418, 3ULL, 2);
                      V v_t_2428 = heff_tag_n(TAG_Just, 1, (V[]){heff_rec_n(2, shape_body__touched, (V[]){heff_clo_n(g_heff_2ebuild_2ebackcache_2emadeOf_24cpr_lam0, 1, 1, (V[]){v_x_247}), v_x_2419})});
                      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24x31_246_24MkPair, TAG_MkPair, 2, (V[]){v_t_2428, v_j_2420})}});
                    }
                    default: return ((HeffT2){{heff_nomatch(v_x31_2418)}});
                    }
                  } else {
                    heff_drop(v_x_247);
                    heff_drop_cell(v_ru_24x31_246_24MkPair, 2);
                    heff_drop(v_field_2417);
                    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                  }
                }
              }
              default: return ((HeffT2){{heff_nomatch(v_x31_2412)}});
              }
            } else {
              heff_drop(v_x_247);
              heff_drop_cell(v_ru_24x31_246_24MkPair, 2);
              heff_drop(v_field_2411);
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
            }
          }
        }
        default: return ((HeffT2){{heff_nomatch(v_x31_246)}});
        }
      } else {
        heff_drop(v_field_245);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
  } else {
    if (heff_strEq_c_lent(v_x1_240, ((V)&g_heff_2ebuild_2ebackcache_2emadeOf_24cpr_str1), 2)) {
      V v_t_2429 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_z_242});
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2429}});
    } else {
      return ({ V a_0 = v_z_241; V a_1 = v_z_242; HeffT2 r_ = (g_heff_2ebuild_2edecoder_2efail_24cpr(a_0, a_1)); heff_drop(v_z_242); r_; });
    }
  }
}
V g_heff_2ebuild_2ebackcache_2emadeOf_24cpr_lam0(V self, V *args) {
  V v_u_2421 = args[0];
  V v_x_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2421);
  HeffT2 v_t_2422 = (g_heff_2ebuild_2edecoder_2ewhole_24cpr(heff_dup(g_heff_2ecompile_2eirtext_2etakeExpr_get()), v_x_247, MK_INT(0LL)));
  {
    V v_field_2424 = v_t_2422.f[1];
    int64_t v_tag_2423 = ((int64_t)v_t_2422.f[0]);
    if ((v_tag_2423 == ((int64_t)0ULL))) {
      V v_x11_2425 = v_field_2424;
      switch (heff_tag_of(v_x11_2425)) {
      case TAG_MkPair: {
        V v_x_2426 = heff_field(v_x11_2425, 0);
        heff_take_n(v_x11_2425, 1ULL, 2);
        return heff_tag_n(TAG_Just, 1, (V[]){v_x_2426});
      }
      default: return heff_nomatch(v_x11_2425);
      }
    } else {
      heff_drop(v_field_2424);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_heff_2ebuild_2ebackcache_2ecopyD_lam1(V self, V *args);
V g_heff_2ebuild_2ebackcache_2ecopyD_lam0(V self, V *args);
Clo g_heff_2ebuild_2ebackcache_2ecopyD_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebackcache_2ecopyD_entry, 2, 0};

V g_heff_2ebuild_2ebackcache_2ecopyD(V v_s_240, V v_i_241) {
top: ;
  HeffT2 v_t_242 = (g_heff_2ebuild_2edecoder_2estr_24cpr(v_s_240, v_i_241));
  {
    V v_field_244 = v_t_242.f[1];
    int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
    if ((v_tag_243 == ((int64_t)0ULL))) {
      V v_x31_245 = v_field_244;
      switch (heff_tag_of(v_x31_245)) {
      case TAG_MkPair: {
        V v_x_246 = heff_field(v_x31_245, 0);
        V v_j_247 = heff_field(v_x31_245, 1);
        heff_take_n(v_x31_245, 3ULL, 2);
        HeffT2 v_t_248 = (g_heff_2ebuild_2edecoder_2estr_24cpr(v_s_240, v_j_247));
        {
          V v_field_2410 = v_t_248.f[1];
          int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
          if ((v_tag_249 == ((int64_t)0ULL))) {
            V v_x31_2411 = v_field_2410;
            switch (heff_tag_of(v_x31_2411)) {
            case TAG_MkPair: {
              V v_x_2412 = heff_field(v_x31_2411, 0);
              V v_j_2413 = heff_field(v_x31_2411, 1);
              heff_take_n(v_x31_2411, 3ULL, 2);
              HeffT2 v_t_2414 = (g_heff_2ebuild_2edecoder_2estr_24cpr(v_s_240, v_j_2413));
              {
                V v_field_2416 = v_t_2414.f[1];
                int64_t v_tag_2415 = ((int64_t)v_t_2414.f[0]);
                if ((v_tag_2415 == ((int64_t)0ULL))) {
                  V v_x31_2417 = v_field_2416;
                  switch (heff_tag_of(v_x31_2417)) {
                  case TAG_MkPair: {
                    V v_x_2418 = heff_field(v_x31_2417, 0);
                    V v_j_2419 = heff_field(v_x31_2417, 1);
                    heff_take_n(v_x31_2417, 3ULL, 2);
                    HeffT2 v_t_2420 = (g_heff_2ebuild_2edecoder_2eint_24cpr(v_s_240, v_j_2419));
                    {
                      V v_field_2422 = v_t_2420.f[1];
                      int64_t v_tag_2421 = ((int64_t)v_t_2420.f[0]);
                      if ((v_tag_2421 == ((int64_t)0ULL))) {
                        V v_x31_2423 = v_field_2422;
                        switch (heff_tag_of(v_x31_2423)) {
                        case TAG_MkPair: {
                          V v_x_2424 = heff_field(v_x31_2423, 0);
                          V v_j_2425 = heff_field(v_x31_2423, 1);
                          heff_take_n(v_x31_2423, 3ULL, 2);
                          return (g_heff_2ebuild_2edecoder_2ebind_24s823677936x1444069277(heff_clo_n(g_heff_2ebuild_2ebackcache_2ecopyD_lam0, 3, 4, (V[]){v_x_246, v_x_2412, v_x_2418, v_x_2424}), v_s_240, v_j_2425));
                        }
                        default: return heff_nomatch(v_x31_2423);
                        }
                      } else {
                        heff_drop(v_s_240);
                        heff_drop(v_x_246);
                        heff_drop(v_x_2412);
                        heff_drop(v_x_2418);
                        heff_drop(v_field_2422);
                        return NTAG(TAG_Nothing);
                      }
                    }
                  }
                  default: return heff_nomatch(v_x31_2417);
                  }
                } else {
                  heff_drop(v_s_240);
                  heff_drop(v_x_246);
                  heff_drop(v_x_2412);
                  heff_drop(v_field_2416);
                  return NTAG(TAG_Nothing);
                }
              }
            }
            default: return heff_nomatch(v_x31_2411);
            }
          } else {
            heff_drop(v_s_240);
            heff_drop(v_x_246);
            heff_drop(v_field_2410);
            return NTAG(TAG_Nothing);
          }
        }
      }
      default: return heff_nomatch(v_x31_245);
      }
    } else {
      heff_drop(v_s_240);
      heff_drop(v_field_244);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_heff_2ebuild_2ebackcache_2ecopyD_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ebackcache_2ecopyD(a[0], a[1]);
}
V g_heff_2ebuild_2ebackcache_2ecopyD_lam1(V self, V *args) {
  V v_u_2441 = args[0];
  V v_x_2418 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2441);
  HeffT2 v_t_2442 = (g_heff_2ebuild_2edecoder_2ewhole_24cpr(heff_dup(g_heff_2ecompile_2eirtext_2etakeExpr_get()), v_x_2418, MK_INT(0LL)));
  {
    V v_field_2444 = v_t_2442.f[1];
    int64_t v_tag_2443 = ((int64_t)v_t_2442.f[0]);
    if ((v_tag_2443 == ((int64_t)0ULL))) {
      V v_x11_2445 = v_field_2444;
      switch (heff_tag_of(v_x11_2445)) {
      case TAG_MkPair: {
        V v_x_2446 = heff_field(v_x11_2445, 0);
        heff_take_n(v_x11_2445, 1ULL, 2);
        return heff_tag_n(TAG_Just, 1, (V[]){v_x_2446});
      }
      default: return heff_nomatch(v_x11_2445);
      }
    } else {
      heff_drop(v_field_2444);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_heff_2ebuild_2ebackcache_2ecopyD_lam0(V self, V *args) {
  V v_safe_2426 = args[0];
  V v_s_2427 = args[1];
  V v_i_2428 = args[2];
  V v_x_246 = heff_env(self)[0];
  V v_x_2412 = heff_env(self)[1];
  V v_x_2418 = heff_env(self)[2];
  V v_x_2424 = heff_env(self)[3];
  heff_clo_take(self, 4);
  HeffT2 v_t_2429 = (g_heff_2ebuild_2edecoder_2eword_24cpr(v_s_2427, v_i_2428));
  {
    V v_field_2431 = v_t_2429.f[1];
    int64_t v_tag_2430 = ((int64_t)v_t_2429.f[0]);
    if ((v_tag_2430 == ((int64_t)0ULL))) {
      V v_x31_2432 = v_field_2431;
      switch (heff_tag_of(v_x31_2432)) {
      case TAG_MkPair: {
        V v_x_2433 = heff_field(v_x31_2432, 0);
        V v_j_2434 = heff_field(v_x31_2432, 1);
        V v_ru_24x31_2432_24MkPair = heff_take_reuse_n(v_x31_2432, 3ULL, 2);
        HeffT2 v_t_2435 = ({ V a_0 = v_x_2433; V a_1 = v_s_2427; V a_2 = v_j_2434; HeffT2 r_ = (g_heff_2ebuild_2ebackcache_2emadeOf_24cpr(a_0, a_1, a_2)); heff_drop(v_x_2433); heff_drop(v_s_2427); r_; });
        {
          V v_field_2437 = v_t_2435.f[1];
          int64_t v_tag_2436 = ((int64_t)v_t_2435.f[0]);
          if ((v_tag_2436 == ((int64_t)0ULL))) {
            V v_x31_2438 = v_field_2437;
            switch (heff_tag_of(v_x31_2438)) {
            case TAG_MkPair: {
              V v_x_2439 = heff_field(v_x31_2438, 0);
              V v_j_2440 = heff_field(v_x31_2438, 1);
              V v_ru_24x31_2438_24MkPair = heff_take_reuse_n(v_x31_2438, 3ULL, 2);
              V v_t_2448 = heff_tag_at_n(v_ru_24x31_2432_24MkPair, TAG_MkPair, 2, (V[]){v_x_246, heff_rec_n(5, shape_ver__recipe__depth__safe__made, (V[]){v_x_2412, heff_clo_n(g_heff_2ebuild_2ebackcache_2ecopyD_lam1, 1, 1, (V[]){v_x_2418}), v_x_2424, v_safe_2426, v_x_2439})});
              return heff_tag_n(TAG_Just, 1, (V[]){heff_tag_at_n(v_ru_24x31_2438_24MkPair, TAG_MkPair, 2, (V[]){v_t_2448, v_j_2440})});
            }
            default: return heff_nomatch(v_x31_2438);
            }
          } else {
            heff_drop(v_safe_2426);
            heff_drop(v_x_246);
            heff_drop(v_x_2412);
            heff_drop(v_x_2418);
            heff_drop(v_x_2424);
            heff_drop_cell(v_ru_24x31_2432_24MkPair, 2);
            heff_drop(v_field_2437);
            return NTAG(TAG_Nothing);
          }
        }
      }
      default: return heff_nomatch(v_x31_2432);
      }
    } else {
      heff_drop(v_safe_2426);
      heff_drop(v_s_2427);
      heff_drop(v_x_246);
      heff_drop(v_x_2412);
      heff_drop(v_x_2418);
      heff_drop(v_x_2424);
      heff_drop(v_field_2431);
      return NTAG(TAG_Nothing);
    }
  }
}

HeffT2 g_heff_2ebuild_2ebackcache_2eemitD_24cpr(V v_s_240, V v_i_241) {
top: ;
  HeffT2 v_t_242 = (g_heff_2ebuild_2edecoder_2estr_24cpr(v_s_240, v_i_241));
  {
    V v_field_244 = v_t_242.f[1];
    int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
    if ((v_tag_243 == ((int64_t)0ULL))) {
      V v_x31_245 = v_field_244;
      switch (heff_tag_of(v_x31_245)) {
      case TAG_MkPair: {
        V v_x_246 = heff_field(v_x31_245, 0);
        V v_j_247 = heff_field(v_x31_245, 1);
        V v_ru_24x31_245_24MkPair = heff_take_reuse_n(v_x31_245, 3ULL, 2);
        HeffT2 v_t_248 = (g_heff_2ebuild_2edecoder_2estr_24cpr(v_s_240, v_j_247));
        {
          V v_field_2410 = v_t_248.f[1];
          int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
          if ((v_tag_249 == ((int64_t)0ULL))) {
            V v_x31_2411 = v_field_2410;
            switch (heff_tag_of(v_x31_2411)) {
            case TAG_MkPair: {
              V v_x_2412 = heff_field(v_x31_2411, 0);
              V v_j_2413 = heff_field(v_x31_2411, 1);
              V v_ru_24x31_2411_24MkPair = heff_take_reuse_n(v_x31_2411, 3ULL, 2);
              HeffT2 v_t_2414 = (g_heff_2ebuild_2edecoder_2eint_24cpr(v_s_240, v_j_2413));
              {
                V v_field_2416 = v_t_2414.f[1];
                int64_t v_tag_2415 = ((int64_t)v_t_2414.f[0]);
                if ((v_tag_2415 == ((int64_t)0ULL))) {
                  V v_x31_2417 = v_field_2416;
                  switch (heff_tag_of(v_x31_2417)) {
                  case TAG_MkPair: {
                    V v_x_2418 = heff_field(v_x31_2417, 0);
                    V v_j_2419 = heff_field(v_x31_2417, 1);
                    heff_take_n(v_x31_2417, 3ULL, 2);
                    HeffT2 v_t_2420 = (g_heff_2ebuild_2edecoder_2etimes_24s1603230686x1883420273_24cpr(v_x_2418, v_s_240, v_j_2419));
                    {
                      V v_field_2422 = v_t_2420.f[1];
                      int64_t v_tag_2421 = ((int64_t)v_t_2420.f[0]);
                      if ((v_tag_2421 == ((int64_t)0ULL))) {
                        V v_x31_2423 = v_field_2422;
                        switch (heff_tag_of(v_x31_2423)) {
                        case TAG_MkPair: {
                          V v_x_2424 = heff_field(v_x31_2423, 0);
                          V v_j_2425 = heff_field(v_x31_2423, 1);
                          heff_take_n(v_x31_2423, 3ULL, 2);
                          HeffT2 v_t_2426 = (g_heff_2ebuild_2edecoder_2eint_24cpr(v_s_240, v_j_2425));
                          {
                            V v_field_2428 = v_t_2426.f[1];
                            int64_t v_tag_2427 = ((int64_t)v_t_2426.f[0]);
                            if ((v_tag_2427 == ((int64_t)0ULL))) {
                              V v_x31_2429 = v_field_2428;
                              switch (heff_tag_of(v_x31_2429)) {
                              case TAG_MkPair: {
                                V v_x_2430 = heff_field(v_x31_2429, 0);
                                V v_j_2431 = heff_field(v_x31_2429, 1);
                                heff_take_n(v_x31_2429, 3ULL, 2);
                                HeffT2 v_t_2432 = (g_heff_2ebuild_2edecoder_2etimes_24s1603230686x1883420273_24cpr(v_x_2430, v_s_240, v_j_2431));
                                {
                                  V v_field_2434 = v_t_2432.f[1];
                                  int64_t v_tag_2433 = ((int64_t)v_t_2432.f[0]);
                                  if ((v_tag_2433 == ((int64_t)0ULL))) {
                                    V v_x31_2435 = v_field_2434;
                                    switch (heff_tag_of(v_x31_2435)) {
                                    case TAG_MkPair: {
                                      V v_x_2436 = heff_field(v_x31_2435, 0);
                                      V v_j_2437 = heff_field(v_x31_2435, 1);
                                      heff_take_n(v_x31_2435, 3ULL, 2);
                                      HeffT2 v_t_2438 = (g_heff_2ebuild_2edecoder_2eint_24cpr(v_s_240, v_j_2437));
                                      {
                                        V v_field_2440 = v_t_2438.f[1];
                                        int64_t v_tag_2439 = ((int64_t)v_t_2438.f[0]);
                                        if ((v_tag_2439 == ((int64_t)0ULL))) {
                                          V v_x31_2441 = v_field_2440;
                                          switch (heff_tag_of(v_x31_2441)) {
                                          case TAG_MkPair: {
                                            V v_x_2442 = heff_field(v_x31_2441, 0);
                                            V v_j_2443 = heff_field(v_x31_2441, 1);
                                            heff_take_n(v_x31_2441, 3ULL, 2);
                                            HeffT2 v_t_2444 = (g_heff_2ebuild_2edecoder_2etimes_24s1603230686x1883420273_24cpr(v_x_2442, v_s_240, v_j_2443));
                                            {
                                              V v_field_2446 = v_t_2444.f[1];
                                              int64_t v_tag_2445 = ((int64_t)v_t_2444.f[0]);
                                              if ((v_tag_2445 == ((int64_t)0ULL))) {
                                                V v_x31_2447 = v_field_2446;
                                                switch (heff_tag_of(v_x31_2447)) {
                                                case TAG_MkPair: {
                                                  V v_x_2448 = heff_field(v_x31_2447, 0);
                                                  V v_j_2449 = heff_field(v_x31_2447, 1);
                                                  heff_take_n(v_x31_2447, 3ULL, 2);
                                                  HeffT2 v_t_2450 = (g_heff_2ebuild_2edecoder_2eint_24cpr(v_s_240, v_j_2449));
                                                  {
                                                    V v_field_2452 = v_t_2450.f[1];
                                                    int64_t v_tag_2451 = ((int64_t)v_t_2450.f[0]);
                                                    if ((v_tag_2451 == ((int64_t)0ULL))) {
                                                      V v_x31_2453 = v_field_2452;
                                                      switch (heff_tag_of(v_x31_2453)) {
                                                      case TAG_MkPair: {
                                                        V v_x_2454 = heff_field(v_x31_2453, 0);
                                                        V v_j_2455 = heff_field(v_x31_2453, 1);
                                                        heff_take_n(v_x31_2453, 3ULL, 2);
                                                        HeffT2 v_t_2456 = (g_heff_2ebuild_2edecoder_2etimes_24s1603230686x1883420273_24cpr(v_x_2454, v_s_240, v_j_2455));
                                                        {
                                                          V v_field_2458 = v_t_2456.f[1];
                                                          int64_t v_tag_2457 = ((int64_t)v_t_2456.f[0]);
                                                          if ((v_tag_2457 == ((int64_t)0ULL))) {
                                                            V v_x31_2459 = v_field_2458;
                                                            switch (heff_tag_of(v_x31_2459)) {
                                                            case TAG_MkPair: {
                                                              V v_x_2460 = heff_field(v_x31_2459, 0);
                                                              V v_j_2461 = heff_field(v_x31_2459, 1);
                                                              heff_take_n(v_x31_2459, 3ULL, 2);
                                                              HeffT2 v_t_2462 = (g_heff_2ebuild_2edecoder_2eint_24cpr(v_s_240, v_j_2461));
                                                              {
                                                                V v_field_2464 = v_t_2462.f[1];
                                                                int64_t v_tag_2463 = ((int64_t)v_t_2462.f[0]);
                                                                if ((v_tag_2463 == ((int64_t)0ULL))) {
                                                                  V v_x31_2465 = v_field_2464;
                                                                  switch (heff_tag_of(v_x31_2465)) {
                                                                  case TAG_MkPair: {
                                                                    V v_x_2466 = heff_field(v_x31_2465, 0);
                                                                    V v_j_2467 = heff_field(v_x31_2465, 1);
                                                                    heff_take_n(v_x31_2465, 3ULL, 2);
                                                                    HeffT2 v_t_2468 = (g_heff_2ebuild_2edecoder_2etimes_24s1603230686x1883420273_24cpr(v_x_2466, v_s_240, v_j_2467));
                                                                    {
                                                                      V v_field_2470 = v_t_2468.f[1];
                                                                      int64_t v_tag_2469 = ((int64_t)v_t_2468.f[0]);
                                                                      if ((v_tag_2469 == ((int64_t)0ULL))) {
                                                                        V v_x31_2471 = v_field_2470;
                                                                        switch (heff_tag_of(v_x31_2471)) {
                                                                        case TAG_MkPair: {
                                                                          V v_x_2472 = heff_field(v_x31_2471, 0);
                                                                          V v_j_2473 = heff_field(v_x31_2471, 1);
                                                                          heff_take_n(v_x31_2471, 3ULL, 2);
                                                                          HeffT2 v_t_2474 = (g_heff_2ebuild_2edecoder_2eint_24cpr(v_s_240, v_j_2473));
                                                                          {
                                                                            V v_field_2476 = v_t_2474.f[1];
                                                                            int64_t v_tag_2475 = ((int64_t)v_t_2474.f[0]);
                                                                            if ((v_tag_2475 == ((int64_t)0ULL))) {
                                                                              V v_x31_2477 = v_field_2476;
                                                                              switch (heff_tag_of(v_x31_2477)) {
                                                                              case TAG_MkPair: {
                                                                                V v_x_2478 = heff_field(v_x31_2477, 0);
                                                                                V v_j_2479 = heff_field(v_x31_2477, 1);
                                                                                heff_take_n(v_x31_2477, 3ULL, 2);
                                                                                HeffT2 v_t_2480 = (g_heff_2ebuild_2edecoder_2etimes_24s1603230686x1883420273_24cpr(v_x_2478, v_s_240, v_j_2479));
                                                                                {
                                                                                  V v_field_2482 = v_t_2480.f[1];
                                                                                  int64_t v_tag_2481 = ((int64_t)v_t_2480.f[0]);
                                                                                  if ((v_tag_2481 == ((int64_t)0ULL))) {
                                                                                    V v_x31_2483 = v_field_2482;
                                                                                    switch (heff_tag_of(v_x31_2483)) {
                                                                                    case TAG_MkPair: {
                                                                                      V v_x_2484 = heff_field(v_x31_2483, 0);
                                                                                      V v_j_2485 = heff_field(v_x31_2483, 1);
                                                                                      heff_take_n(v_x31_2483, 3ULL, 2);
                                                                                      HeffT2 v_t_2486 = (g_heff_2ebuild_2edecoder_2eint_24cpr(v_s_240, v_j_2485));
                                                                                      {
                                                                                        V v_field_2488 = v_t_2486.f[1];
                                                                                        int64_t v_tag_2487 = ((int64_t)v_t_2486.f[0]);
                                                                                        if ((v_tag_2487 == ((int64_t)0ULL))) {
                                                                                          V v_x31_2489 = v_field_2488;
                                                                                          switch (heff_tag_of(v_x31_2489)) {
                                                                                          case TAG_MkPair: {
                                                                                            V v_x_2490 = heff_field(v_x31_2489, 0);
                                                                                            V v_j_2491 = heff_field(v_x31_2489, 1);
                                                                                            heff_take_n(v_x31_2489, 3ULL, 2);
                                                                                            HeffT2 v_t_2492 = (g_heff_2ebuild_2edecoder_2etimes_24s1603230686x1883420273_24cpr(v_x_2490, v_s_240, v_j_2491));
                                                                                            {
                                                                                              V v_field_2494 = v_t_2492.f[1];
                                                                                              int64_t v_tag_2493 = ((int64_t)v_t_2492.f[0]);
                                                                                              if ((v_tag_2493 == ((int64_t)0ULL))) {
                                                                                                V v_x31_2495 = v_field_2494;
                                                                                                switch (heff_tag_of(v_x31_2495)) {
                                                                                                case TAG_MkPair: {
                                                                                                  V v_x_2496 = heff_field(v_x31_2495, 0);
                                                                                                  V v_j_2497 = heff_field(v_x31_2495, 1);
                                                                                                  heff_take_n(v_x31_2495, 3ULL, 2);
                                                                                                  V v_t_2498 = heff_tag_at_n(v_ru_24x31_245_24MkPair, TAG_MkPair, 2, (V[]){v_x_246, heff_rec_n(8, shape_ver__protos__code__strs__lprotos__lams__shapes__prims, (V[]){v_x_2412, v_x_2424, v_x_2436, v_x_2448, v_x_2460, v_x_2472, v_x_2484, v_x_2496})});
                                                                                                  return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24x31_2411_24MkPair, TAG_MkPair, 2, (V[]){v_t_2498, v_j_2497})}});
                                                                                                }
                                                                                                default: return ((HeffT2){{heff_nomatch(v_x31_2495)}});
                                                                                                }
                                                                                              } else {
                                                                                                heff_drop(v_x_246);
                                                                                                heff_drop_cell(v_ru_24x31_245_24MkPair, 2);
                                                                                                heff_drop(v_x_2412);
                                                                                                heff_drop_cell(v_ru_24x31_2411_24MkPair, 2);
                                                                                                heff_drop(v_x_2424);
                                                                                                heff_drop(v_x_2436);
                                                                                                heff_drop(v_x_2448);
                                                                                                heff_drop(v_x_2460);
                                                                                                heff_drop(v_x_2472);
                                                                                                heff_drop(v_x_2484);
                                                                                                heff_drop(v_field_2494);
                                                                                                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                                                                              }
                                                                                            }
                                                                                          }
                                                                                          default: return ((HeffT2){{heff_nomatch(v_x31_2489)}});
                                                                                          }
                                                                                        } else {
                                                                                          heff_drop(v_x_246);
                                                                                          heff_drop_cell(v_ru_24x31_245_24MkPair, 2);
                                                                                          heff_drop(v_x_2412);
                                                                                          heff_drop_cell(v_ru_24x31_2411_24MkPair, 2);
                                                                                          heff_drop(v_x_2424);
                                                                                          heff_drop(v_x_2436);
                                                                                          heff_drop(v_x_2448);
                                                                                          heff_drop(v_x_2460);
                                                                                          heff_drop(v_x_2472);
                                                                                          heff_drop(v_x_2484);
                                                                                          heff_drop(v_field_2488);
                                                                                          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                                                                        }
                                                                                      }
                                                                                    }
                                                                                    default: return ((HeffT2){{heff_nomatch(v_x31_2483)}});
                                                                                    }
                                                                                  } else {
                                                                                    heff_drop(v_x_246);
                                                                                    heff_drop_cell(v_ru_24x31_245_24MkPair, 2);
                                                                                    heff_drop(v_x_2412);
                                                                                    heff_drop_cell(v_ru_24x31_2411_24MkPair, 2);
                                                                                    heff_drop(v_x_2424);
                                                                                    heff_drop(v_x_2436);
                                                                                    heff_drop(v_x_2448);
                                                                                    heff_drop(v_x_2460);
                                                                                    heff_drop(v_x_2472);
                                                                                    heff_drop(v_field_2482);
                                                                                    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                                                                  }
                                                                                }
                                                                              }
                                                                              default: return ((HeffT2){{heff_nomatch(v_x31_2477)}});
                                                                              }
                                                                            } else {
                                                                              heff_drop(v_x_246);
                                                                              heff_drop_cell(v_ru_24x31_245_24MkPair, 2);
                                                                              heff_drop(v_x_2412);
                                                                              heff_drop_cell(v_ru_24x31_2411_24MkPair, 2);
                                                                              heff_drop(v_x_2424);
                                                                              heff_drop(v_x_2436);
                                                                              heff_drop(v_x_2448);
                                                                              heff_drop(v_x_2460);
                                                                              heff_drop(v_x_2472);
                                                                              heff_drop(v_field_2476);
                                                                              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                                                            }
                                                                          }
                                                                        }
                                                                        default: return ((HeffT2){{heff_nomatch(v_x31_2471)}});
                                                                        }
                                                                      } else {
                                                                        heff_drop(v_x_246);
                                                                        heff_drop_cell(v_ru_24x31_245_24MkPair, 2);
                                                                        heff_drop(v_x_2412);
                                                                        heff_drop_cell(v_ru_24x31_2411_24MkPair, 2);
                                                                        heff_drop(v_x_2424);
                                                                        heff_drop(v_x_2436);
                                                                        heff_drop(v_x_2448);
                                                                        heff_drop(v_x_2460);
                                                                        heff_drop(v_field_2470);
                                                                        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                                                      }
                                                                    }
                                                                  }
                                                                  default: return ((HeffT2){{heff_nomatch(v_x31_2465)}});
                                                                  }
                                                                } else {
                                                                  heff_drop(v_x_246);
                                                                  heff_drop_cell(v_ru_24x31_245_24MkPair, 2);
                                                                  heff_drop(v_x_2412);
                                                                  heff_drop_cell(v_ru_24x31_2411_24MkPair, 2);
                                                                  heff_drop(v_x_2424);
                                                                  heff_drop(v_x_2436);
                                                                  heff_drop(v_x_2448);
                                                                  heff_drop(v_x_2460);
                                                                  heff_drop(v_field_2464);
                                                                  return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                                                }
                                                              }
                                                            }
                                                            default: return ((HeffT2){{heff_nomatch(v_x31_2459)}});
                                                            }
                                                          } else {
                                                            heff_drop(v_x_246);
                                                            heff_drop_cell(v_ru_24x31_245_24MkPair, 2);
                                                            heff_drop(v_x_2412);
                                                            heff_drop_cell(v_ru_24x31_2411_24MkPair, 2);
                                                            heff_drop(v_x_2424);
                                                            heff_drop(v_x_2436);
                                                            heff_drop(v_x_2448);
                                                            heff_drop(v_field_2458);
                                                            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                                          }
                                                        }
                                                      }
                                                      default: return ((HeffT2){{heff_nomatch(v_x31_2453)}});
                                                      }
                                                    } else {
                                                      heff_drop(v_x_246);
                                                      heff_drop_cell(v_ru_24x31_245_24MkPair, 2);
                                                      heff_drop(v_x_2412);
                                                      heff_drop_cell(v_ru_24x31_2411_24MkPair, 2);
                                                      heff_drop(v_x_2424);
                                                      heff_drop(v_x_2436);
                                                      heff_drop(v_x_2448);
                                                      heff_drop(v_field_2452);
                                                      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                                    }
                                                  }
                                                }
                                                default: return ((HeffT2){{heff_nomatch(v_x31_2447)}});
                                                }
                                              } else {
                                                heff_drop(v_x_246);
                                                heff_drop_cell(v_ru_24x31_245_24MkPair, 2);
                                                heff_drop(v_x_2412);
                                                heff_drop_cell(v_ru_24x31_2411_24MkPair, 2);
                                                heff_drop(v_x_2424);
                                                heff_drop(v_x_2436);
                                                heff_drop(v_field_2446);
                                                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                              }
                                            }
                                          }
                                          default: return ((HeffT2){{heff_nomatch(v_x31_2441)}});
                                          }
                                        } else {
                                          heff_drop(v_x_246);
                                          heff_drop_cell(v_ru_24x31_245_24MkPair, 2);
                                          heff_drop(v_x_2412);
                                          heff_drop_cell(v_ru_24x31_2411_24MkPair, 2);
                                          heff_drop(v_x_2424);
                                          heff_drop(v_x_2436);
                                          heff_drop(v_field_2440);
                                          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                        }
                                      }
                                    }
                                    default: return ((HeffT2){{heff_nomatch(v_x31_2435)}});
                                    }
                                  } else {
                                    heff_drop(v_x_246);
                                    heff_drop_cell(v_ru_24x31_245_24MkPair, 2);
                                    heff_drop(v_x_2412);
                                    heff_drop_cell(v_ru_24x31_2411_24MkPair, 2);
                                    heff_drop(v_x_2424);
                                    heff_drop(v_field_2434);
                                    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                  }
                                }
                              }
                              default: return ((HeffT2){{heff_nomatch(v_x31_2429)}});
                              }
                            } else {
                              heff_drop(v_x_246);
                              heff_drop_cell(v_ru_24x31_245_24MkPair, 2);
                              heff_drop(v_x_2412);
                              heff_drop_cell(v_ru_24x31_2411_24MkPair, 2);
                              heff_drop(v_x_2424);
                              heff_drop(v_field_2428);
                              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                            }
                          }
                        }
                        default: return ((HeffT2){{heff_nomatch(v_x31_2423)}});
                        }
                      } else {
                        heff_drop(v_x_246);
                        heff_drop_cell(v_ru_24x31_245_24MkPair, 2);
                        heff_drop(v_x_2412);
                        heff_drop_cell(v_ru_24x31_2411_24MkPair, 2);
                        heff_drop(v_field_2422);
                        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                      }
                    }
                  }
                  default: return ((HeffT2){{heff_nomatch(v_x31_2417)}});
                  }
                } else {
                  heff_drop(v_x_246);
                  heff_drop_cell(v_ru_24x31_245_24MkPair, 2);
                  heff_drop(v_x_2412);
                  heff_drop_cell(v_ru_24x31_2411_24MkPair, 2);
                  heff_drop(v_field_2416);
                  return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                }
              }
            }
            default: return ((HeffT2){{heff_nomatch(v_x31_2411)}});
            }
          } else {
            heff_drop(v_x_246);
            heff_drop_cell(v_ru_24x31_245_24MkPair, 2);
            heff_drop(v_field_2410);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x31_245)}});
      }
    } else {
      heff_drop(v_field_244);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
  }
}

HeffT2 g_heff_2ebuild_2ebackcache_2ejsD_24cpr(V v_s_240, V v_i_241) {
top: ;
  HeffT2 v_t_242 = (g_heff_2ebuild_2edecoder_2estr_24cpr(v_s_240, v_i_241));
  {
    V v_field_244 = v_t_242.f[1];
    int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
    if ((v_tag_243 == ((int64_t)0ULL))) {
      V v_x31_245 = v_field_244;
      switch (heff_tag_of(v_x31_245)) {
      case TAG_MkPair: {
        V v_x_246 = heff_field(v_x31_245, 0);
        V v_j_247 = heff_field(v_x31_245, 1);
        V v_ru_24x31_245_24MkPair = heff_take_reuse_n(v_x31_245, 3ULL, 2);
        HeffT2 v_t_248 = (g_heff_2ebuild_2edecoder_2estr_24cpr(v_s_240, v_j_247));
        {
          V v_field_2410 = v_t_248.f[1];
          int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
          if ((v_tag_249 == ((int64_t)0ULL))) {
            V v_x31_2411 = v_field_2410;
            switch (heff_tag_of(v_x31_2411)) {
            case TAG_MkPair: {
              V v_x_2412 = heff_field(v_x31_2411, 0);
              V v_j_2413 = heff_field(v_x31_2411, 1);
              V v_ru_24x31_2411_24MkPair = heff_take_reuse_n(v_x31_2411, 3ULL, 2);
              HeffT2 v_t_2414 = (g_heff_2ebuild_2edecoder_2eint_24cpr(v_s_240, v_j_2413));
              {
                V v_field_2416 = v_t_2414.f[1];
                int64_t v_tag_2415 = ((int64_t)v_t_2414.f[0]);
                if ((v_tag_2415 == ((int64_t)0ULL))) {
                  V v_x31_2417 = v_field_2416;
                  switch (heff_tag_of(v_x31_2417)) {
                  case TAG_MkPair: {
                    V v_x_2418 = heff_field(v_x31_2417, 0);
                    V v_j_2419 = heff_field(v_x31_2417, 1);
                    heff_take_n(v_x31_2417, 3ULL, 2);
                    HeffT2 v_t_2420 = (g_heff_2ebuild_2edecoder_2etimes_24s1603230686x1883420273_24cpr(v_x_2418, v_s_240, v_j_2419));
                    {
                      V v_field_2422 = v_t_2420.f[1];
                      int64_t v_tag_2421 = ((int64_t)v_t_2420.f[0]);
                      if ((v_tag_2421 == ((int64_t)0ULL))) {
                        V v_x31_2423 = v_field_2422;
                        switch (heff_tag_of(v_x31_2423)) {
                        case TAG_MkPair: {
                          V v_x_2424 = heff_field(v_x31_2423, 0);
                          V v_j_2425 = heff_field(v_x31_2423, 1);
                          heff_take_n(v_x31_2423, 3ULL, 2);
                          HeffT2 v_t_2426 = (g_heff_2ebuild_2edecoder_2eint_24cpr(v_s_240, v_j_2425));
                          {
                            V v_field_2428 = v_t_2426.f[1];
                            int64_t v_tag_2427 = ((int64_t)v_t_2426.f[0]);
                            if ((v_tag_2427 == ((int64_t)0ULL))) {
                              V v_x31_2429 = v_field_2428;
                              switch (heff_tag_of(v_x31_2429)) {
                              case TAG_MkPair: {
                                V v_x_2430 = heff_field(v_x31_2429, 0);
                                V v_j_2431 = heff_field(v_x31_2429, 1);
                                heff_take_n(v_x31_2429, 3ULL, 2);
                                HeffT2 v_t_2432 = (g_heff_2ebuild_2edecoder_2etimes_24s1603230686x1883420273_24cpr(v_x_2430, v_s_240, v_j_2431));
                                {
                                  V v_field_2434 = v_t_2432.f[1];
                                  int64_t v_tag_2433 = ((int64_t)v_t_2432.f[0]);
                                  if ((v_tag_2433 == ((int64_t)0ULL))) {
                                    V v_x31_2435 = v_field_2434;
                                    switch (heff_tag_of(v_x31_2435)) {
                                    case TAG_MkPair: {
                                      V v_x_2436 = heff_field(v_x31_2435, 0);
                                      V v_j_2437 = heff_field(v_x31_2435, 1);
                                      heff_take_n(v_x31_2435, 3ULL, 2);
                                      HeffT2 v_t_2438 = (g_heff_2ebuild_2edecoder_2eint_24cpr(v_s_240, v_j_2437));
                                      {
                                        V v_field_2440 = v_t_2438.f[1];
                                        int64_t v_tag_2439 = ((int64_t)v_t_2438.f[0]);
                                        if ((v_tag_2439 == ((int64_t)0ULL))) {
                                          V v_x31_2441 = v_field_2440;
                                          switch (heff_tag_of(v_x31_2441)) {
                                          case TAG_MkPair: {
                                            V v_x_2442 = heff_field(v_x31_2441, 0);
                                            V v_j_2443 = heff_field(v_x31_2441, 1);
                                            heff_take_n(v_x31_2441, 3ULL, 2);
                                            HeffT2 v_t_2444 = (g_heff_2ebuild_2edecoder_2etimes_24s1603230686x1883420273_24cpr(v_x_2442, v_s_240, v_j_2443));
                                            {
                                              V v_field_2446 = v_t_2444.f[1];
                                              int64_t v_tag_2445 = ((int64_t)v_t_2444.f[0]);
                                              if ((v_tag_2445 == ((int64_t)0ULL))) {
                                                V v_x31_2447 = v_field_2446;
                                                switch (heff_tag_of(v_x31_2447)) {
                                                case TAG_MkPair: {
                                                  V v_x_2448 = heff_field(v_x31_2447, 0);
                                                  V v_j_2449 = heff_field(v_x31_2447, 1);
                                                  heff_take_n(v_x31_2447, 3ULL, 2);
                                                  HeffT2 v_t_2450 = (g_heff_2ebuild_2edecoder_2eint_24cpr(v_s_240, v_j_2449));
                                                  {
                                                    V v_field_2452 = v_t_2450.f[1];
                                                    int64_t v_tag_2451 = ((int64_t)v_t_2450.f[0]);
                                                    if ((v_tag_2451 == ((int64_t)0ULL))) {
                                                      V v_x31_2453 = v_field_2452;
                                                      switch (heff_tag_of(v_x31_2453)) {
                                                      case TAG_MkPair: {
                                                        V v_x_2454 = heff_field(v_x31_2453, 0);
                                                        V v_j_2455 = heff_field(v_x31_2453, 1);
                                                        heff_take_n(v_x31_2453, 3ULL, 2);
                                                        HeffT2 v_t_2456 = (g_heff_2ebuild_2edecoder_2etimes_24s1603230686x1883420273_24cpr(v_x_2454, v_s_240, v_j_2455));
                                                        {
                                                          V v_field_2458 = v_t_2456.f[1];
                                                          int64_t v_tag_2457 = ((int64_t)v_t_2456.f[0]);
                                                          if ((v_tag_2457 == ((int64_t)0ULL))) {
                                                            V v_x31_2459 = v_field_2458;
                                                            switch (heff_tag_of(v_x31_2459)) {
                                                            case TAG_MkPair: {
                                                              V v_x_2460 = heff_field(v_x31_2459, 0);
                                                              V v_j_2461 = heff_field(v_x31_2459, 1);
                                                              heff_take_n(v_x31_2459, 3ULL, 2);
                                                              V v_t_2462 = heff_tag_at_n(v_ru_24x31_245_24MkPair, TAG_MkPair, 2, (V[]){v_x_246, heff_rec_n(5, shape_ver__lines__params__refs__prims, (V[]){v_x_2412, v_x_2424, v_x_2436, v_x_2448, v_x_2460})});
                                                              return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24x31_2411_24MkPair, TAG_MkPair, 2, (V[]){v_t_2462, v_j_2461})}});
                                                            }
                                                            default: return ((HeffT2){{heff_nomatch(v_x31_2459)}});
                                                            }
                                                          } else {
                                                            heff_drop(v_x_246);
                                                            heff_drop_cell(v_ru_24x31_245_24MkPair, 2);
                                                            heff_drop(v_x_2412);
                                                            heff_drop_cell(v_ru_24x31_2411_24MkPair, 2);
                                                            heff_drop(v_x_2424);
                                                            heff_drop(v_x_2436);
                                                            heff_drop(v_x_2448);
                                                            heff_drop(v_field_2458);
                                                            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                                          }
                                                        }
                                                      }
                                                      default: return ((HeffT2){{heff_nomatch(v_x31_2453)}});
                                                      }
                                                    } else {
                                                      heff_drop(v_x_246);
                                                      heff_drop_cell(v_ru_24x31_245_24MkPair, 2);
                                                      heff_drop(v_x_2412);
                                                      heff_drop_cell(v_ru_24x31_2411_24MkPair, 2);
                                                      heff_drop(v_x_2424);
                                                      heff_drop(v_x_2436);
                                                      heff_drop(v_x_2448);
                                                      heff_drop(v_field_2452);
                                                      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                                    }
                                                  }
                                                }
                                                default: return ((HeffT2){{heff_nomatch(v_x31_2447)}});
                                                }
                                              } else {
                                                heff_drop(v_x_246);
                                                heff_drop_cell(v_ru_24x31_245_24MkPair, 2);
                                                heff_drop(v_x_2412);
                                                heff_drop_cell(v_ru_24x31_2411_24MkPair, 2);
                                                heff_drop(v_x_2424);
                                                heff_drop(v_x_2436);
                                                heff_drop(v_field_2446);
                                                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                              }
                                            }
                                          }
                                          default: return ((HeffT2){{heff_nomatch(v_x31_2441)}});
                                          }
                                        } else {
                                          heff_drop(v_x_246);
                                          heff_drop_cell(v_ru_24x31_245_24MkPair, 2);
                                          heff_drop(v_x_2412);
                                          heff_drop_cell(v_ru_24x31_2411_24MkPair, 2);
                                          heff_drop(v_x_2424);
                                          heff_drop(v_x_2436);
                                          heff_drop(v_field_2440);
                                          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                        }
                                      }
                                    }
                                    default: return ((HeffT2){{heff_nomatch(v_x31_2435)}});
                                    }
                                  } else {
                                    heff_drop(v_x_246);
                                    heff_drop_cell(v_ru_24x31_245_24MkPair, 2);
                                    heff_drop(v_x_2412);
                                    heff_drop_cell(v_ru_24x31_2411_24MkPair, 2);
                                    heff_drop(v_x_2424);
                                    heff_drop(v_field_2434);
                                    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                  }
                                }
                              }
                              default: return ((HeffT2){{heff_nomatch(v_x31_2429)}});
                              }
                            } else {
                              heff_drop(v_x_246);
                              heff_drop_cell(v_ru_24x31_245_24MkPair, 2);
                              heff_drop(v_x_2412);
                              heff_drop_cell(v_ru_24x31_2411_24MkPair, 2);
                              heff_drop(v_x_2424);
                              heff_drop(v_field_2428);
                              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                            }
                          }
                        }
                        default: return ((HeffT2){{heff_nomatch(v_x31_2423)}});
                        }
                      } else {
                        heff_drop(v_x_246);
                        heff_drop_cell(v_ru_24x31_245_24MkPair, 2);
                        heff_drop(v_x_2412);
                        heff_drop_cell(v_ru_24x31_2411_24MkPair, 2);
                        heff_drop(v_field_2422);
                        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                      }
                    }
                  }
                  default: return ((HeffT2){{heff_nomatch(v_x31_2417)}});
                  }
                } else {
                  heff_drop(v_x_246);
                  heff_drop_cell(v_ru_24x31_245_24MkPair, 2);
                  heff_drop(v_x_2412);
                  heff_drop_cell(v_ru_24x31_2411_24MkPair, 2);
                  heff_drop(v_field_2416);
                  return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                }
              }
            }
            default: return ((HeffT2){{heff_nomatch(v_x31_2411)}});
            }
          } else {
            heff_drop(v_x_246);
            heff_drop_cell(v_ru_24x31_245_24MkPair, 2);
            heff_drop(v_field_2410);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x31_245)}});
      }
    } else {
      heff_drop(v_field_244);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
  }
}

static V g_heff_2ebuild_2ebackcache_2enoBack_val;
static HEFF_ONCE g_heff_2ebuild_2ebackcache_2enoBack_st;
static V g_heff_2ebuild_2ebackcache_2enoBack_init(void) {
  return heff_rec_n(4, shape_groups__copies__emits__jss, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil)});
}
V g_heff_2ebuild_2ebackcache_2enoBack_get(void) {
  if (HEFF_DONE(g_heff_2ebuild_2ebackcache_2enoBack_st)) return g_heff_2ebuild_2ebackcache_2enoBack_val;
  return heff_global(&g_heff_2ebuild_2ebackcache_2enoBack_val, &g_heff_2ebuild_2ebackcache_2enoBack_st, g_heff_2ebuild_2ebackcache_2enoBack_init);
}

HeffT2 g_heff_2ebuild_2ebackcache_2ewithRaw_24s1280263334x1684915868_24cpr(V v_s_240, V v_i_241) {
top: ;
  HeffT2 v_t_242 = (g_heff_2ebuild_2ebackcache_2egroupD_24cpr(heff_dup(v_s_240), heff_dup(v_i_241)));
  {
    V v_field_244 = v_t_242.f[1];
    int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
    if ((v_tag_243 == ((int64_t)0ULL))) {
      V v_x31_245 = v_field_244;
      switch (heff_tag_of(v_x31_245)) {
      case TAG_MkPair: {
        V v_x_246 = heff_field(v_x31_245, 0);
        V v_j_247 = heff_field(v_x31_245, 1);
        V v_ru_24x31_245_24MkPair = heff_take_reuse_n(v_x31_245, 3ULL, 2);
        V v_t_248;
        if ((heff_intLt_c_lent(v_i_241, v_j_247, 0) && (heff_unbox_word(heff_strByteAt(heff_dup(v_s_240), heff_intSub(heff_dup(v_j_247), MK_INT(1LL)))) == ((int64_t)32ULL)))) {
          v_t_248 = heff_intSub(heff_dup(v_j_247), MK_INT(1LL));
        } else {
          v_t_248 = heff_dup(v_j_247);
        }
        V v_t_249 = heff_tag_at_n(v_ru_24x31_245_24MkPair, TAG_MkPair, 2, (V[]){v_x_246, heff_strSlice(v_s_240, v_i_241, v_t_248)});
        V v_f_2410 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_249, v_j_247});
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2410}});
      }
      default: return ((HeffT2){{heff_nomatch(v_x31_245)}});
      }
    } else {
      heff_drop(v_s_240);
      heff_drop(v_i_241);
      heff_drop(v_field_244);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
  }
}

HeffT2 g_heff_2ebuild_2ebackcache_2ewithRaw_24s497340727x548230450_24cpr(V v_s_240, V v_i_241) {
top: ;
  V v_x3_242 = heff_tr(g_heff_2ebuild_2ebackcache_2ecopyD(heff_dup(v_s_240), heff_dup(v_i_241)));
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nothing: {
    heff_drop(v_s_240);
    heff_drop(v_i_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Just: {
    V v_x31_243 = heff_field(v_x3_242, 0);
    heff_take_n(v_x3_242, 1ULL, 1);
    switch (heff_tag_of(v_x31_243)) {
    case TAG_MkPair: {
      V v_x_244 = heff_field(v_x31_243, 0);
      V v_j_245 = heff_field(v_x31_243, 1);
      V v_ru_24x31_243_24MkPair = heff_take_reuse_n(v_x31_243, 3ULL, 2);
      V v_t_246;
      if ((heff_intLt_c_lent(v_i_241, v_j_245, 0) && (heff_unbox_word(heff_strByteAt(heff_dup(v_s_240), heff_intSub(heff_dup(v_j_245), MK_INT(1LL)))) == ((int64_t)32ULL)))) {
        v_t_246 = heff_intSub(heff_dup(v_j_245), MK_INT(1LL));
      } else {
        v_t_246 = heff_dup(v_j_245);
      }
      V v_t_247 = heff_tag_at_n(v_ru_24x31_243_24MkPair, TAG_MkPair, 2, (V[]){v_x_244, heff_strSlice(v_s_240, v_i_241, v_t_246)});
      V v_f_248 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_247, v_j_245});
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_248}});
    }
    default: return ((HeffT2){{heff_nomatch(v_x31_243)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x3_242)}});
  }
}

HeffT2 g_heff_2ebuild_2ebackcache_2ewithRaw_24s1413851850x1114201945_24cpr(V v_s_240, V v_i_241) {
top: ;
  HeffT2 v_t_242 = (g_heff_2ebuild_2ebackcache_2eemitD_24cpr(v_s_240, heff_dup(v_i_241)));
  {
    V v_field_244 = v_t_242.f[1];
    int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
    if ((v_tag_243 == ((int64_t)0ULL))) {
      V v_x31_245 = v_field_244;
      switch (heff_tag_of(v_x31_245)) {
      case TAG_MkPair: {
        V v_x_246 = heff_field(v_x31_245, 0);
        V v_j_247 = heff_field(v_x31_245, 1);
        V v_ru_24x31_245_24MkPair = heff_take_reuse_n(v_x31_245, 3ULL, 2);
        V v_t_248;
        if ((heff_intLt_c_lent(v_i_241, v_j_247, 0) && (heff_unbox_word(heff_strByteAt(heff_dup(v_s_240), heff_intSub(heff_dup(v_j_247), MK_INT(1LL)))) == ((int64_t)32ULL)))) {
          v_t_248 = heff_intSub(heff_dup(v_j_247), MK_INT(1LL));
        } else {
          v_t_248 = heff_dup(v_j_247);
        }
        V v_t_249 = heff_tag_at_n(v_ru_24x31_245_24MkPair, TAG_MkPair, 2, (V[]){v_x_246, heff_strSlice_lent(v_s_240, v_i_241, v_t_248, 6)});
        V v_f_2410 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_249, v_j_247});
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2410}});
      }
      default: return ((HeffT2){{heff_nomatch(v_x31_245)}});
      }
    } else {
      heff_drop(v_i_241);
      heff_drop(v_field_244);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
  }
}

HeffT2 g_heff_2ebuild_2ebackcache_2ewithRaw_24s1304941386x8760443_24cpr(V v_s_240, V v_i_241) {
top: ;
  HeffT2 v_t_242 = (g_heff_2ebuild_2ebackcache_2ejsD_24cpr(v_s_240, heff_dup(v_i_241)));
  {
    V v_field_244 = v_t_242.f[1];
    int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
    if ((v_tag_243 == ((int64_t)0ULL))) {
      V v_x31_245 = v_field_244;
      switch (heff_tag_of(v_x31_245)) {
      case TAG_MkPair: {
        V v_x_246 = heff_field(v_x31_245, 0);
        V v_j_247 = heff_field(v_x31_245, 1);
        V v_ru_24x31_245_24MkPair = heff_take_reuse_n(v_x31_245, 3ULL, 2);
        V v_t_248;
        if ((heff_intLt_c_lent(v_i_241, v_j_247, 0) && (heff_unbox_word(heff_strByteAt(heff_dup(v_s_240), heff_intSub(heff_dup(v_j_247), MK_INT(1LL)))) == ((int64_t)32ULL)))) {
          v_t_248 = heff_intSub(heff_dup(v_j_247), MK_INT(1LL));
        } else {
          v_t_248 = heff_dup(v_j_247);
        }
        V v_t_249 = heff_tag_at_n(v_ru_24x31_245_24MkPair, TAG_MkPair, 2, (V[]){v_x_246, heff_strSlice_lent(v_s_240, v_i_241, v_t_248, 6)});
        V v_f_2410 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_249, v_j_247});
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2410}});
      }
      default: return ((HeffT2){{heff_nomatch(v_x31_245)}});
      }
    } else {
      heff_drop(v_i_241);
      heff_drop(v_field_244);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
  }
}
HEFF_LIT(g_heff_2ebuild_2ebackcache_2ebackD_24cpr_str0, 3, "end");

HeffT2 g_heff_2ebuild_2ebackcache_2ebackD_24cpr(V v_id_240, V v_s_241, V v_i_242) {
top: ;
  HeffT2 v_t_243 = (g_heff_2ebuild_2edecoder_2estr_24cpr(v_s_241, v_i_242));
  {
    V v_field_245 = v_t_243.f[1];
    int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
    if ((v_tag_244 == ((int64_t)0ULL))) {
      V v_x31_246 = v_field_245;
      switch (heff_tag_of(v_x31_246)) {
      case TAG_MkPair: {
        V v_x_247 = heff_field(v_x31_246, 0);
        V v_j_248 = heff_field(v_x31_246, 1);
        V v_ru_24x31_246_24MkPair = heff_take_reuse_n(v_x31_246, 3ULL, 2);
        if (heff_strEq_c(v_x_247, heff_dup(g_heff_2ebuild_2ebackcache_2eversion_get()))) {
          V v_x_249 = NTAG(TAG_MkUnit);
          V v_j_2410 = v_j_248;
          HeffT2 v_t_2411 = (g_heff_2ebuild_2edecoder_2estr_24cpr(v_s_241, v_j_2410));
          {
            V v_field_2413 = v_t_2411.f[1];
            int64_t v_tag_2412 = ((int64_t)v_t_2411.f[0]);
            if ((v_tag_2412 == ((int64_t)0ULL))) {
              V v_x31_2414 = v_field_2413;
              switch (heff_tag_of(v_x31_2414)) {
              case TAG_MkPair: {
                V v_x_2415 = heff_field(v_x31_2414, 0);
                V v_j_2416 = heff_field(v_x31_2414, 1);
                heff_take_n(v_x31_2414, 3ULL, 2);
                if (heff_strEq_c_lent(v_x_2415, v_id_240, 1)) {
                  HeffT2 v_t_2417 = (g_heff_2ebuild_2edecoder_2eint_24cpr(v_s_241, v_j_2416));
                  {
                    V v_field_2419 = v_t_2417.f[1];
                    int64_t v_tag_2418 = ((int64_t)v_t_2417.f[0]);
                    if ((v_tag_2418 == ((int64_t)0ULL))) {
                      V v_x31_2420 = v_field_2419;
                      switch (heff_tag_of(v_x31_2420)) {
                      case TAG_MkPair: {
                        V v_x_2421 = heff_field(v_x31_2420, 0);
                        V v_j_2422 = heff_field(v_x31_2420, 1);
                        heff_take_n(v_x31_2420, 3ULL, 2);
                        HeffT2 v_t_2423 = (g_heff_2ebuild_2edecoder_2etimes_24s2049614891x1595878686_24cpr(v_x_2421, heff_dup(v_s_241), v_j_2422));
                        {
                          V v_field_2425 = v_t_2423.f[1];
                          int64_t v_tag_2424 = ((int64_t)v_t_2423.f[0]);
                          if ((v_tag_2424 == ((int64_t)0ULL))) {
                            V v_x31_2426 = v_field_2425;
                            switch (heff_tag_of(v_x31_2426)) {
                            case TAG_MkPair: {
                              V v_x_2427 = heff_field(v_x31_2426, 0);
                              V v_j_2428 = heff_field(v_x31_2426, 1);
                              heff_take_n(v_x31_2426, 3ULL, 2);
                              HeffT2 v_t_2429 = (g_heff_2ebuild_2edecoder_2eint_24cpr(v_s_241, v_j_2428));
                              {
                                V v_field_2431 = v_t_2429.f[1];
                                int64_t v_tag_2430 = ((int64_t)v_t_2429.f[0]);
                                if ((v_tag_2430 == ((int64_t)0ULL))) {
                                  V v_x31_2432 = v_field_2431;
                                  switch (heff_tag_of(v_x31_2432)) {
                                  case TAG_MkPair: {
                                    V v_x_2433 = heff_field(v_x31_2432, 0);
                                    V v_j_2434 = heff_field(v_x31_2432, 1);
                                    heff_take_n(v_x31_2432, 3ULL, 2);
                                    HeffT2 v_t_2435 = (g_heff_2ebuild_2edecoder_2etimes_24s481066606x2100141841_24cpr(v_x_2433, heff_dup(v_s_241), v_j_2434));
                                    {
                                      V v_field_2437 = v_t_2435.f[1];
                                      int64_t v_tag_2436 = ((int64_t)v_t_2435.f[0]);
                                      if ((v_tag_2436 == ((int64_t)0ULL))) {
                                        V v_x31_2438 = v_field_2437;
                                        switch (heff_tag_of(v_x31_2438)) {
                                        case TAG_MkPair: {
                                          V v_x_2439 = heff_field(v_x31_2438, 0);
                                          V v_j_2440 = heff_field(v_x31_2438, 1);
                                          heff_take_n(v_x31_2438, 3ULL, 2);
                                          HeffT2 v_t_2441 = (g_heff_2ebuild_2edecoder_2eint_24cpr(v_s_241, v_j_2440));
                                          {
                                            V v_field_2443 = v_t_2441.f[1];
                                            int64_t v_tag_2442 = ((int64_t)v_t_2441.f[0]);
                                            if ((v_tag_2442 == ((int64_t)0ULL))) {
                                              V v_x31_2444 = v_field_2443;
                                              switch (heff_tag_of(v_x31_2444)) {
                                              case TAG_MkPair: {
                                                V v_x_2445 = heff_field(v_x31_2444, 0);
                                                V v_j_2446 = heff_field(v_x31_2444, 1);
                                                heff_take_n(v_x31_2444, 3ULL, 2);
                                                HeffT2 v_t_2447 = (g_heff_2ebuild_2edecoder_2etimes_24s1954476619x1073210498_24cpr(v_x_2445, v_s_241, v_j_2446));
                                                {
                                                  V v_field_2449 = v_t_2447.f[1];
                                                  int64_t v_tag_2448 = ((int64_t)v_t_2447.f[0]);
                                                  if ((v_tag_2448 == ((int64_t)0ULL))) {
                                                    V v_x31_2450 = v_field_2449;
                                                    switch (heff_tag_of(v_x31_2450)) {
                                                    case TAG_MkPair: {
                                                      V v_x_2451 = heff_field(v_x31_2450, 0);
                                                      V v_j_2452 = heff_field(v_x31_2450, 1);
                                                      heff_take_n(v_x31_2450, 3ULL, 2);
                                                      HeffT2 v_t_2453 = (g_heff_2ebuild_2edecoder_2eint_24cpr(v_s_241, v_j_2452));
                                                      {
                                                        V v_field_2455 = v_t_2453.f[1];
                                                        int64_t v_tag_2454 = ((int64_t)v_t_2453.f[0]);
                                                        if ((v_tag_2454 == ((int64_t)0ULL))) {
                                                          V v_x31_2456 = v_field_2455;
                                                          switch (heff_tag_of(v_x31_2456)) {
                                                          case TAG_MkPair: {
                                                            V v_x_2457 = heff_field(v_x31_2456, 0);
                                                            V v_j_2458 = heff_field(v_x31_2456, 1);
                                                            heff_take_n(v_x31_2456, 3ULL, 2);
                                                            HeffT2 v_t_2459 = (g_heff_2ebuild_2edecoder_2etimes_24s1391953550x1663492198_24cpr(v_x_2457, v_s_241, v_j_2458));
                                                            {
                                                              V v_field_2461 = v_t_2459.f[1];
                                                              int64_t v_tag_2460 = ((int64_t)v_t_2459.f[0]);
                                                              if ((v_tag_2460 == ((int64_t)0ULL))) {
                                                                V v_x31_2462 = v_field_2461;
                                                                switch (heff_tag_of(v_x31_2462)) {
                                                                case TAG_MkPair: {
                                                                  V v_x_2463 = heff_field(v_x31_2462, 0);
                                                                  V v_j_2464 = heff_field(v_x31_2462, 1);
                                                                  heff_take_n(v_x31_2462, 3ULL, 2);
                                                                  HeffT2 v_t_2465 = ({ V a_0 = v_s_241; V a_1 = v_j_2464; HeffT2 r_ = (g_heff_2ebuild_2edecoder_2estr_24cpr(a_0, a_1)); heff_drop(v_s_241); r_; });
                                                                  {
                                                                    V v_field_2467 = v_t_2465.f[1];
                                                                    int64_t v_tag_2466 = ((int64_t)v_t_2465.f[0]);
                                                                    if ((v_tag_2466 == ((int64_t)0ULL))) {
                                                                      V v_x31_2468 = v_field_2467;
                                                                      switch (heff_tag_of(v_x31_2468)) {
                                                                      case TAG_MkPair: {
                                                                        V v_x_2469 = heff_field(v_x31_2468, 0);
                                                                        V v_j_2470 = heff_field(v_x31_2468, 1);
                                                                        heff_take_n(v_x31_2468, 3ULL, 2);
                                                                        if (heff_strEq_c(v_x_2469, ((V)&g_heff_2ebuild_2ebackcache_2ebackD_24cpr_str0))) {
                                                                          V v_t_2471 = heff_tag_at_n(v_ru_24x31_246_24MkPair, TAG_MkPair, 2, (V[]){heff_rec_n(4, shape_groups__copies__emits__jss, (V[]){v_x_2427, v_x_2439, v_x_2451, v_x_2463}), v_j_2470});
                                                                          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2471}});
                                                                        } else {
                                                                          heff_drop_cell(v_ru_24x31_246_24MkPair, 2);
                                                                          heff_drop(v_x_2427);
                                                                          heff_drop(v_x_2439);
                                                                          heff_drop(v_x_2451);
                                                                          heff_drop(v_x_2463);
                                                                          heff_drop(v_j_2470);
                                                                          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                                                        }
                                                                      }
                                                                      default: return ((HeffT2){{heff_nomatch(v_x31_2468)}});
                                                                      }
                                                                    } else {
                                                                      heff_drop_cell(v_ru_24x31_246_24MkPair, 2);
                                                                      heff_drop(v_x_2427);
                                                                      heff_drop(v_x_2439);
                                                                      heff_drop(v_x_2451);
                                                                      heff_drop(v_x_2463);
                                                                      heff_drop(v_field_2467);
                                                                      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                                                    }
                                                                  }
                                                                }
                                                                default: return ((HeffT2){{heff_nomatch(v_x31_2462)}});
                                                                }
                                                              } else {
                                                                heff_drop(v_s_241);
                                                                heff_drop_cell(v_ru_24x31_246_24MkPair, 2);
                                                                heff_drop(v_x_2427);
                                                                heff_drop(v_x_2439);
                                                                heff_drop(v_x_2451);
                                                                heff_drop(v_field_2461);
                                                                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                                              }
                                                            }
                                                          }
                                                          default: return ((HeffT2){{heff_nomatch(v_x31_2456)}});
                                                          }
                                                        } else {
                                                          heff_drop(v_s_241);
                                                          heff_drop_cell(v_ru_24x31_246_24MkPair, 2);
                                                          heff_drop(v_x_2427);
                                                          heff_drop(v_x_2439);
                                                          heff_drop(v_x_2451);
                                                          heff_drop(v_field_2455);
                                                          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                                        }
                                                      }
                                                    }
                                                    default: return ((HeffT2){{heff_nomatch(v_x31_2450)}});
                                                    }
                                                  } else {
                                                    heff_drop(v_s_241);
                                                    heff_drop_cell(v_ru_24x31_246_24MkPair, 2);
                                                    heff_drop(v_x_2427);
                                                    heff_drop(v_x_2439);
                                                    heff_drop(v_field_2449);
                                                    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                                  }
                                                }
                                              }
                                              default: return ((HeffT2){{heff_nomatch(v_x31_2444)}});
                                              }
                                            } else {
                                              heff_drop(v_s_241);
                                              heff_drop_cell(v_ru_24x31_246_24MkPair, 2);
                                              heff_drop(v_x_2427);
                                              heff_drop(v_x_2439);
                                              heff_drop(v_field_2443);
                                              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                            }
                                          }
                                        }
                                        default: return ((HeffT2){{heff_nomatch(v_x31_2438)}});
                                        }
                                      } else {
                                        heff_drop(v_s_241);
                                        heff_drop_cell(v_ru_24x31_246_24MkPair, 2);
                                        heff_drop(v_x_2427);
                                        heff_drop(v_field_2437);
                                        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                      }
                                    }
                                  }
                                  default: return ((HeffT2){{heff_nomatch(v_x31_2432)}});
                                  }
                                } else {
                                  heff_drop(v_s_241);
                                  heff_drop_cell(v_ru_24x31_246_24MkPair, 2);
                                  heff_drop(v_x_2427);
                                  heff_drop(v_field_2431);
                                  return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                }
                              }
                            }
                            default: return ((HeffT2){{heff_nomatch(v_x31_2426)}});
                            }
                          } else {
                            heff_drop(v_s_241);
                            heff_drop_cell(v_ru_24x31_246_24MkPair, 2);
                            heff_drop(v_field_2425);
                            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                          }
                        }
                      }
                      default: return ((HeffT2){{heff_nomatch(v_x31_2420)}});
                      }
                    } else {
                      heff_drop(v_s_241);
                      heff_drop_cell(v_ru_24x31_246_24MkPair, 2);
                      heff_drop(v_field_2419);
                      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                    }
                  }
                } else {
                  heff_drop(v_s_241);
                  heff_drop_cell(v_ru_24x31_246_24MkPair, 2);
                  heff_drop(v_j_2416);
                  return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                }
              }
              default: return ((HeffT2){{heff_nomatch(v_x31_2414)}});
              }
            } else {
              heff_drop(v_s_241);
              heff_drop_cell(v_ru_24x31_246_24MkPair, 2);
              heff_drop(v_field_2413);
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
            }
          }
        } else {
          heff_drop(v_s_241);
          heff_drop(v_j_248);
          heff_drop_cell(v_ru_24x31_246_24MkPair, 2);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x31_246)}});
      }
    } else {
      heff_drop(v_s_241);
      heff_drop(v_field_245);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
  }
}
Clo g_heff_2ebuild_2ebackcache_2elastDotGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebackcache_2elastDotGo_entry, 3, 0};

V g_heff_2ebuild_2ebackcache_2elastDotGo(V v_k_240, V v_i_241, V v_at_242) {
top: ;
  if ((heff_unbox_word(heff_strLength_lent(v_k_240, 0)) <= heff_peek_word(v_i_241))) {
    heff_drop(v_i_241);
    return v_at_242;
  } else {
    V v_t_243;
    if ((heff_unbox_word(heff_strByteAt_lent(v_k_240, v_i_241, 0)) == ((int64_t)46ULL))) {
      heff_drop(v_at_242);
      v_t_243 = heff_dup(v_i_241);
    } else {
      v_t_243 = v_at_242;
    }
    V t_0 = v_k_240;
    V t_1 = heff_box_word((heff_unbox_word(v_i_241) + ((int64_t)1ULL)));
    V t_2 = v_t_243;
    v_k_240 = t_0;
    v_i_241 = t_1;
    v_at_242 = t_2;
    goto top;
  }
}
V g_heff_2ebuild_2ebackcache_2elastDotGo_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ebackcache_2elastDotGo(a0, a[1], a[2]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ebuild_2ebackcache_2emoduleIn_str0, 1, "_");
Clo g_heff_2ebuild_2ebackcache_2emoduleIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebackcache_2emoduleIn_entry, 2, 0};

V g_heff_2ebuild_2ebackcache_2emoduleIn(V v_mods_240, V v_k_241) {
top: ;
  HeffT2 v_t_242 = (g_std_2emap_2elookup_24s1781110452x2115140655_24cpr(v_mods_240, v_k_241));
  {
    V v_field_244 = v_t_242.f[1];
    int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
    if ((v_tag_243 == ((int64_t)0ULL))) {
      V v_x_245 = v_field_244;
      heff_drop(v_x_245);
      return v_k_241;
    } else {
      heff_drop(v_field_244);
      V v_t_246 = (g_heff_2ebuild_2ebackcache_2elastDotGo(v_k_241, MK_INT(0LL), MK_INT(-1LL)));
      if (heff_intLe_c(v_t_246, MK_INT(0LL))) {
        heff_drop(v_k_241);
        return ((V)&g_heff_2ebuild_2ebackcache_2emoduleIn_str0);
      } else {
        V v_t_247 = (g_heff_2ebuild_2ebackcache_2elastDotGo(v_k_241, MK_INT(0LL), MK_INT(-1LL)));
        V t_0 = v_mods_240;
        V t_1 = heff_strSlice(v_k_241, MK_INT(0LL), v_t_247);
        v_mods_240 = t_0;
        v_k_241 = t_1;
        goto top;
      }
    }
  }
}
V g_heff_2ebuild_2ebackcache_2emoduleIn_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ebackcache_2emoduleIn(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2ebuild_2ebackcache_2eentriesAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebackcache_2eentriesAt_entry, 3, 0};

V g_heff_2ebuild_2ebackcache_2eentriesAt(V v_olds_240, V v_m_241, V v_k_242) {
top: ;
  HeffT2 v_t_243 = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(v_m_241, v_k_242));
  {
    V v_field_245 = v_t_243.f[1];
    int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
    if ((v_tag_244 == ((int64_t)0ULL))) {
      V v_es_246 = v_field_245;
      return v_es_246;
    } else {
      heff_drop(v_field_245);
      HeffT2 v_t_247 = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(v_olds_240, v_k_242));
      {
        V v_field_249 = v_t_247.f[1];
        int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
        V v_b_2411;
        if ((v_tag_248 == ((int64_t)0ULL))) {
          V v_x_2410 = v_field_249;
          v_b_2411 = v_x_2410;
        } else {
          heff_drop(v_field_249);
          v_b_2411 = heff_dup(g_heff_2ebuild_2ebackcache_2enoBack_get());
        }
        V v_groups_2412 = heff_take_field(v_b_2411, 0);
        V v_copies_2413 = heff_take_field(v_b_2411, 1);
        V v_emits_2414 = heff_take_field(v_b_2411, 2);
        V v_jss_2415 = heff_get_n(v_b_2411, 3, 4);
        V v_t_2416 = ({ V a_0 = heff_dup(g_std_2emap_2eempty_get()); V a_1 = v_groups_2412; V r_ = (g_list_2efoldl_24s250221336x1707528432(a_0, a_1)); heff_drop(v_groups_2412); r_; });
        V v_t_2417 = ({ V a_0 = heff_dup(g_std_2emap_2eempty_get()); V a_1 = v_copies_2413; V r_ = (g_list_2efoldl_24s1056451377x727850182(a_0, a_1)); heff_drop(v_copies_2413); r_; });
        V v_t_2418 = ({ V a_0 = heff_dup(g_std_2emap_2eempty_get()); V a_1 = v_emits_2414; V r_ = (g_list_2efoldl_24s1056451377x727850182(a_0, a_1)); heff_drop(v_emits_2414); r_; });
        V v_t_2419 = ({ V a_0 = heff_dup(g_std_2emap_2eempty_get()); V a_1 = v_jss_2415; V r_ = (g_list_2efoldl_24s1056451377x727850182(a_0, a_1)); heff_drop(v_jss_2415); r_; });
        return heff_rec_n(4, shape_groups__copies__emits__jss, (V[]){v_t_2416, v_t_2417, v_t_2418, v_t_2419});
      }
    }
  }
}
V g_heff_2ebuild_2ebackcache_2eentriesAt_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V r = g_heff_2ebuild_2ebackcache_2eentriesAt(a0, a1, a2); heff_drop(a0); heff_drop(a1); heff_drop(a2); return r;
}

HeffT2 g_heff_2ebuild_2ebackcache_2eallJustB_24cpr(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), NTAG(TAG_Nil)}});
  }
  case TAG_Cons: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_Nothing: {
      heff_drop(v_rest_242);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_Just: {
      V v_x_243 = heff_field(v_x11_241, 0);
      heff_take_n(v_x11_241, 1ULL, 1);
      HeffT2 v_t_244 = (g_heff_2ebuild_2ebackcache_2eallJustB_24cpr(v_rest_242));
      {
        V v_field_246 = v_t_244.f[1];
        int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
        if ((v_tag_245 == ((int64_t)0ULL))) {
          V v_xs_247 = v_field_246;
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_243, v_xs_247})}});
        } else {
          heff_drop_cell(v_ru_24x1_240_24Cons, 2);
          heff_drop(v_x_243);
          heff_drop(v_field_246);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x11_241)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
Clo g_heff_2ebuild_2ebackcache_2eallJustB_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebackcache_2eallJustB_entry, 1, 0};

V g_heff_2ebuild_2ebackcache_2eallJustB(V v_x1_240) {
top: ;
  HeffT2 v_t_241 = (g_heff_2ebuild_2ebackcache_2eallJustB_24cpr(v_x1_240));
  {
    V v_field_243 = v_t_241.f[1];
    int64_t v_tag_242 = ((int64_t)v_t_241.f[0]);
    if ((v_tag_242 == ((int64_t)0ULL))) {
      return heff_tag_n(TAG_Just, 1, (V[]){v_field_243});
    } else {
      heff_drop(v_field_243);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_heff_2ebuild_2ebackcache_2eallJustB_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ebackcache_2eallJustB(a[0]);
}
HEFF_LIT(g_heff_2ebuild_2ebackcache_2egroupText_str0, 1, ":");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2egroupText_str1, 1, ":");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2egroupText_str2, 1, " ");
Clo g_heff_2ebuild_2ebackcache_2egroupText_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebackcache_2egroupText_entry, 3, 0};

V g_heff_2ebuild_2ebackcache_2egroupText(V v_owner_240, V v_ver_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nothing: {
    heff_drop(v_owner_240);
    heff_drop(v_ver_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_us_243 = heff_field(v_x3_242, 0);
    V v_ru_24x3_242_24Just = heff_take_reuse_n(v_x3_242, 1ULL, 1);
    V v_t_244 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_us_243));
    V v_t_245 = heff_intShow(v_t_244);
    V v_t_246 = heff_intShow(heff_strLength_lent(v_owner_240, 0));
    V v_t_247 = heff_strAppend(v_t_246, heff_strAppend(((V)&g_heff_2ebuild_2ebackcache_2egroupText_str0), v_owner_240));
    V v_t_248 = heff_intShow(heff_strLength_lent(v_ver_241, 0));
    V v_t_249 = heff_strAppend(v_t_248, heff_strAppend(((V)&g_heff_2ebuild_2ebackcache_2egroupText_str1), v_ver_241));
    V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_249, heff_tag_n(TAG_Cons, 2, (V[]){v_t_245, v_us_243})});
    V v_t_2411 = ({ V a_0 = ((V)&g_heff_2ebuild_2ebackcache_2egroupText_str2); V a_1 = v_t_247; V a_2 = v_t_2410; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop_tag(v_t_2410, 2); r_; });
    return heff_tag_at_n(v_ru_24x3_242_24Just, TAG_Just, 1, (V[]){v_t_2411});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2ebackcache_2egroupText_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ebackcache_2egroupText(a[0], a[1], a[2]);
}
Clo g_heff_2ebuild_2ebackcache_2egroupIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebackcache_2egroupIn_entry, 5, 0};

V g_heff_2ebuild_2ebackcache_2egroupIn(V v_fs_240, V v_m_241, V v_md_242, V v_g_243, V v_x5_244) {
top: ;
  switch (heff_tag_of(v_x5_244)) {
  case TAG_Nothing: {
    heff_drop_rec(v_fs_240, 2);
    heff_drop(v_md_242);
    heff_drop_rec(v_g_243, 3);
    return v_m_241;
  }
  case TAG_Just: {
    V v_t_245 = heff_field(v_x5_244, 0);
    V v_es_246 = ({ V b_0 = heff_get_n(v_fs_240, 1, 2); V a_1 = v_m_241; V a_2 = v_md_242; V r_ = (g_heff_2ebuild_2ebackcache_2eentriesAt(b_0, a_1, a_2)); heff_drop(b_0); r_; });
    V v_groups_247 = heff_take_field(v_es_246, 0);
    V v_copies_248 = heff_take_field(v_es_246, 1);
    V v_emits_249 = heff_take_field(v_es_246, 2);
    V v_jss_2410 = heff_get_n(v_es_246, 3, 4);
    V v_t_2411 = (g_std_2emap_2einsert_24s93785294x875597928(v_groups_247, heff_get_n(v_g_243, 0, 3), heff_dup(v_t_245)));
    return (g_std_2emap_2einsert_24s93785294x875597928(v_m_241, v_md_242, heff_rec_n(4, shape_groups__copies__emits__jss, (V[]){v_t_2411, v_copies_248, v_emits_249, v_jss_2410})));
  }
  default: return heff_nomatch(v_x5_244);
  }
}
V g_heff_2ebuild_2ebackcache_2egroupIn_entry(V self, V *a) {
  (void)self;
  V a4 = a[4]; V r = g_heff_2ebuild_2ebackcache_2egroupIn(a[0], a[1], a[2], a[3], a4); heff_drop(a4); return r;
}
V g_heff_2ebuild_2ebackcache_2eaddGroup_lam0(V self, V *args);
V g_heff_2ebuild_2ebackcache_2eaddGroup_lam1(V self, V *args);
Clo g_heff_2ebuild_2ebackcache_2eaddGroup_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebackcache_2eaddGroup_entry, 3, 0};

V g_heff_2ebuild_2ebackcache_2eaddGroup(V v_fs_240, V v_m_241, V v_g_242) {
top: ;
  V v_t_243 = (g_heff_2ebuild_2ebackcache_2emoduleIn(heff_rfield(v_fs_240, 0), heff_dup(heff_rfield(v_g_242, 0))));
  V v_m_244 = (g_heff_2ebuild_2ebackcache_2emoduleIn(heff_rfield(v_fs_240, 0), heff_dup(heff_rfield(v_g_242, 0))));
  HeffT2 v_t_245 = ({ V a_0 = heff_rfield(v_fs_240, 1); V a_1 = v_m_244; HeffT2 r_ = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(a_0, a_1)); heff_drop(v_m_244); r_; });
  V v_t_2433;
  {
    V v_field_247 = v_t_245.f[1];
    int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
    V v_t_249;
    if ((v_tag_246 == ((int64_t)0ULL))) {
      V v_x_248 = v_field_247;
      v_t_249 = v_x_248;
    } else {
      heff_drop(v_field_247);
      v_t_249 = heff_dup(g_heff_2ebuild_2ebackcache_2enoBack_get());
    }
    V v_t_2410 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_get_n(v_t_249, 0, 4)));
    V v_old_2420 = ({ V a_0 = heff_clo_n(g_heff_2ebuild_2ebackcache_2eaddGroup_lam0, 2, 1, (V[]){heff_dup(v_g_242)}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_2410; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2410); r_; });
    v_t_2433 = heff_clo_n(g_heff_2ebuild_2ebackcache_2eaddGroup_lam1, 1, 1, (V[]){v_old_2420});
  }
  V v_t_2434 = (g_list_2emap(v_t_2433, heff_dup(heff_rfield(v_g_242, 2))));
  V v_t_2435 = (g_heff_2ebuild_2ebackcache_2eallJustB(v_t_2434));
  V v_t_2436 = (g_heff_2ebuild_2ebackcache_2egroupText(heff_dup(heff_rfield(v_g_242, 0)), heff_dup(heff_rfield(v_g_242, 1)), v_t_2435));
  return ({ V a_0 = v_fs_240; V a_1 = v_m_241; V a_2 = v_t_243; V a_3 = v_g_242; V a_4 = v_t_2436; V r_ = (g_heff_2ebuild_2ebackcache_2egroupIn(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_t_2436); r_; });
}
V g_heff_2ebuild_2ebackcache_2eaddGroup_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ebackcache_2eaddGroup(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2ebackcache_2eaddGroup_lam0(V self, V *args) {
  V v_acc_2411 = args[0];
  V v_x_2412 = args[1];
  V v_g_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2415;
  switch (heff_tag_of(v_x_2412)) {
  case TAG_MkPair: {
    V v_x_2413 = heff_dup(heff_field(v_x_2412, 0));
    v_t_2415 = v_x_2413;
    break;
  }
  default: heff_nomatch(v_x_2412);
  }
  V v_t_2419;
  if (heff_strEq_c(heff_get_n(v_t_2415, 0, 3), heff_get_n(v_g_242, 0, 3))) {
    V v_t_2418;
    switch (heff_tag_of(v_x_2412)) {
    case TAG_MkPair: {
      V v_x_2416 = heff_field(v_x_2412, 0);
      heff_take_n(v_x_2412, 1ULL, 2);
      v_t_2418 = v_x_2416;
      break;
    }
    default: heff_nomatch(v_x_2412);
    }
    v_t_2419 = heff_get_n(v_t_2418, 2, 3);
  } else {
    heff_drop(v_x_2412);
    v_t_2419 = NTAG(TAG_Nil);
  }
  return (g_prelude_2e_2b_2b(v_t_2419, v_acc_2411));
}
V g_heff_2ebuild_2ebackcache_2eaddGroup_lam1(V self, V *args) {
  V v_x2_2421 = args[0];
  V v_old_2420 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x2_2421)) {
  case TAG_MkPair: {
    V v_k_2422 = heff_field(v_x2_2421, 0);
    V v_x22_2423 = heff_field(v_x2_2421, 1);
    heff_take_n(v_x2_2421, 3ULL, 2);
    switch (heff_tag_of(v_x22_2423)) {
    case TAG_Nothing: {
      HeffT2 v_t_2424 = ({ V a_0 = v_k_2422; V a_1 = v_old_2420; HeffT2 r_ = (g_list_2efind_24s1156299507x501436576_24cpr(a_0, a_1)); heff_drop(v_k_2422); r_; });
      {
        V v_field_2426 = v_t_2424.f[1];
        int64_t v_tag_2425 = ((int64_t)v_t_2424.f[0]);
        if ((v_tag_2425 == ((int64_t)0ULL))) {
          V v_p_2427 = v_field_2426;
          V v_t_2430;
          switch (heff_tag_of(v_p_2427)) {
          case TAG_MkPair: {
            V v_y_2429 = heff_field(v_p_2427, 1);
            heff_take_n(v_p_2427, 2ULL, 2);
            v_t_2430 = v_y_2429;
            break;
          }
          default: heff_nomatch(v_p_2427);
          }
          return heff_tag_n(TAG_Just, 1, (V[]){v_t_2430});
        } else {
          heff_drop(v_field_2426);
          return NTAG(TAG_Nothing);
        }
      }
    }
    case TAG_Just: {
      V v_u_2431 = heff_field(v_x22_2423, 0);
      V v_ru_24x22_2423_24Just = heff_take_reuse_n(v_x22_2423, 1ULL, 1);
      heff_drop(v_old_2420);
      heff_drop(v_k_2422);
      V v_t_2432 = (g_heff_2ebuild_2ebackcache_2eunitText(v_u_2431));
      return heff_tag_at_n(v_ru_24x22_2423_24Just, TAG_Just, 1, (V[]){v_t_2432});
    }
    default: return heff_nomatch(v_x22_2423);
    }
  }
  default: return heff_nomatch(v_x2_2421);
  }
}
HEFF_LIT(g_heff_2ebuild_2ebackcache_2eaddCopy_str0, 2, "$s");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2eaddCopy_str1, 2, "$s");
Clo g_heff_2ebuild_2ebackcache_2eaddCopy_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebackcache_2eaddCopy_entry, 3, 0};

V g_heff_2ebuild_2ebackcache_2eaddCopy(V v_fs_240, V v_m_241, V v_c_242) {
top: ;
  V v_mods_243 = heff_take_field(v_fs_240, 0);
  V v_olds_244 = heff_get_n(v_fs_240, 1, 2);
  V v_g_245 = heff_dup(heff_rfield(v_c_242, 0));
  V v_j_246 = heff_strFind_lent(((V)&g_heff_2ebuild_2ebackcache_2eaddCopy_str0), v_g_245, MK_INT(0LL), 5);
  V v_t_247;
  if (heff_intLt_c_lent(v_j_246, MK_INT(0LL), 2)) {
    heff_drop(v_j_246);
    v_t_247 = v_g_245;
  } else {
    v_t_247 = heff_strSlice(v_g_245, MK_INT(0LL), v_j_246);
  }
  V v_t_248 = (g_heff_2ebuild_2ebackcache_2emoduleIn(v_mods_243, v_t_247));
  V v_t_249 = (g_heff_2ebuild_2ebackcache_2ecopyText(heff_dup(v_c_242)));
  V v_g_2410 = heff_dup(heff_rfield(v_c_242, 0));
  V v_j_2411 = heff_strFind_lent(((V)&g_heff_2ebuild_2ebackcache_2eaddCopy_str1), v_g_2410, MK_INT(0LL), 5);
  V v_t_2412;
  if (heff_intLt_c_lent(v_j_2411, MK_INT(0LL), 2)) {
    heff_drop(v_j_2411);
    v_t_2412 = v_g_2410;
  } else {
    v_t_2412 = heff_strSlice(v_g_2410, MK_INT(0LL), v_j_2411);
  }
  V v_t_2413 = ({ V a_0 = v_mods_243; V a_1 = v_t_2412; V r_ = (g_heff_2ebuild_2ebackcache_2emoduleIn(a_0, a_1)); heff_drop(v_mods_243); r_; });
  V v_es_2414 = ({ V a_0 = v_olds_244; V a_1 = v_m_241; V a_2 = v_t_2413; V r_ = (g_heff_2ebuild_2ebackcache_2eentriesAt(a_0, a_1, a_2)); heff_drop(v_olds_244); heff_drop(v_t_2413); r_; });
  V v_groups_2415 = heff_take_field(v_es_2414, 0);
  V v_copies_2416 = heff_take_field(v_es_2414, 1);
  V v_emits_2417 = heff_take_field(v_es_2414, 2);
  V v_jss_2418 = heff_get_n(v_es_2414, 3, 4);
  V v_t_2419 = (g_std_2emap_2einsert_24s93785294x875597928(v_copies_2416, heff_get_n(v_c_242, 0, 6), v_t_249));
  HEFF_LAST return g_std_2emap_2einsert_24s93785294x875597928(v_m_241, v_t_248, heff_rec_n(4, shape_groups__copies__emits__jss, (V[]){v_groups_2415, v_t_2419, v_emits_2417, v_jss_2418}));
}
V g_heff_2ebuild_2ebackcache_2eaddCopy_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ebackcache_2eaddCopy(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ebuild_2ebackcache_2eaddEmit_str0, 2, "$s");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2eaddEmit_str1, 2, "$s");
Clo g_heff_2ebuild_2ebackcache_2eaddEmit_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebackcache_2eaddEmit_entry, 3, 0};

V g_heff_2ebuild_2ebackcache_2eaddEmit(V v_fs_240, V v_m_241, V v_x3_242) {
top: ;
  V v_mods_243 = heff_take_field(v_fs_240, 0);
  V v_olds_244 = heff_get_n(v_fs_240, 1, 2);
  switch (heff_tag_of(v_x3_242)) {
  case TAG_MkPair: {
    V v_k_245 = heff_field(v_x3_242, 0);
    V v_e_246 = heff_field(v_x3_242, 1);
    V v_j_247 = heff_strFind_lent(((V)&g_heff_2ebuild_2ebackcache_2eaddEmit_str0), v_k_245, MK_INT(0LL), 5);
    V v_t_248;
    if (heff_intLt_c_lent(v_j_247, MK_INT(0LL), 2)) {
      heff_drop(v_j_247);
      v_t_248 = heff_dup(v_k_245);
    } else {
      v_t_248 = heff_strSlice_lent(v_k_245, MK_INT(0LL), v_j_247, 6);
    }
    V v_t_249 = (g_heff_2ebuild_2ebackcache_2emoduleIn(v_mods_243, v_t_248));
    V v_t_2410 = (g_heff_2ebuild_2ebackcache_2eemitText(heff_dup(v_k_245), heff_dup(v_e_246)));
    V v_j_2411 = heff_strFind_lent(((V)&g_heff_2ebuild_2ebackcache_2eaddEmit_str1), v_k_245, MK_INT(0LL), 5);
    V v_t_2412;
    if (heff_intLt_c_lent(v_j_2411, MK_INT(0LL), 2)) {
      heff_drop(v_j_2411);
      v_t_2412 = heff_dup(v_k_245);
    } else {
      v_t_2412 = heff_strSlice_lent(v_k_245, MK_INT(0LL), v_j_2411, 6);
    }
    V v_t_2413 = ({ V a_0 = v_mods_243; V a_1 = v_t_2412; V r_ = (g_heff_2ebuild_2ebackcache_2emoduleIn(a_0, a_1)); heff_drop(v_mods_243); r_; });
    V v_es_2414 = ({ V a_0 = v_olds_244; V a_1 = v_m_241; V a_2 = v_t_2413; V r_ = (g_heff_2ebuild_2ebackcache_2eentriesAt(a_0, a_1, a_2)); heff_drop(v_olds_244); heff_drop(v_t_2413); r_; });
    V v_groups_2415 = heff_take_field(v_es_2414, 0);
    V v_copies_2416 = heff_take_field(v_es_2414, 1);
    V v_emits_2417 = heff_take_field(v_es_2414, 2);
    V v_jss_2418 = heff_get_n(v_es_2414, 3, 4);
    V v_t_2419 = (g_std_2emap_2einsert_24s93785294x875597928(v_emits_2417, heff_dup(v_k_245), v_t_2410));
    HEFF_LAST return g_std_2emap_2einsert_24s93785294x875597928(v_m_241, v_t_249, heff_rec_n(4, shape_groups__copies__emits__jss, (V[]){v_groups_2415, v_copies_2416, v_t_2419, v_jss_2418}));
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2ebackcache_2eaddEmit_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ebuild_2ebackcache_2eaddEmit(a[0], a[1], a2); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2ebuild_2ebackcache_2eaddJs_str0, 2, "$s");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2eaddJs_str1, 2, "$s");
Clo g_heff_2ebuild_2ebackcache_2eaddJs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebackcache_2eaddJs_entry, 3, 0};

V g_heff_2ebuild_2ebackcache_2eaddJs(V v_fs_240, V v_m_241, V v_x3_242) {
top: ;
  V v_mods_243 = heff_take_field(v_fs_240, 0);
  V v_olds_244 = heff_get_n(v_fs_240, 1, 2);
  switch (heff_tag_of(v_x3_242)) {
  case TAG_MkPair: {
    V v_k_245 = heff_field(v_x3_242, 0);
    V v_e_246 = heff_field(v_x3_242, 1);
    V v_j_247 = heff_strFind_lent(((V)&g_heff_2ebuild_2ebackcache_2eaddJs_str0), v_k_245, MK_INT(0LL), 5);
    V v_t_248;
    if (heff_intLt_c_lent(v_j_247, MK_INT(0LL), 2)) {
      heff_drop(v_j_247);
      v_t_248 = heff_dup(v_k_245);
    } else {
      v_t_248 = heff_strSlice_lent(v_k_245, MK_INT(0LL), v_j_247, 6);
    }
    V v_t_249 = (g_heff_2ebuild_2ebackcache_2emoduleIn(v_mods_243, v_t_248));
    V v_t_2410 = (g_heff_2ebuild_2ebackcache_2ejsText(heff_dup(v_k_245), heff_dup(v_e_246)));
    V v_j_2411 = heff_strFind_lent(((V)&g_heff_2ebuild_2ebackcache_2eaddJs_str1), v_k_245, MK_INT(0LL), 5);
    V v_t_2412;
    if (heff_intLt_c_lent(v_j_2411, MK_INT(0LL), 2)) {
      heff_drop(v_j_2411);
      v_t_2412 = heff_dup(v_k_245);
    } else {
      v_t_2412 = heff_strSlice_lent(v_k_245, MK_INT(0LL), v_j_2411, 6);
    }
    V v_t_2413 = ({ V a_0 = v_mods_243; V a_1 = v_t_2412; V r_ = (g_heff_2ebuild_2ebackcache_2emoduleIn(a_0, a_1)); heff_drop(v_mods_243); r_; });
    V v_es_2414 = ({ V a_0 = v_olds_244; V a_1 = v_m_241; V a_2 = v_t_2413; V r_ = (g_heff_2ebuild_2ebackcache_2eentriesAt(a_0, a_1, a_2)); heff_drop(v_olds_244); heff_drop(v_t_2413); r_; });
    V v_groups_2415 = heff_take_field(v_es_2414, 0);
    V v_copies_2416 = heff_take_field(v_es_2414, 1);
    V v_emits_2417 = heff_take_field(v_es_2414, 2);
    V v_jss_2418 = heff_get_n(v_es_2414, 3, 4);
    V v_t_2419 = (g_std_2emap_2einsert_24s93785294x875597928(v_jss_2418, heff_dup(v_k_245), v_t_2410));
    HEFF_LAST return g_std_2emap_2einsert_24s93785294x875597928(v_m_241, v_t_249, heff_rec_n(4, shape_groups__copies__emits__jss, (V[]){v_groups_2415, v_copies_2416, v_emits_2417, v_t_2419}));
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2ebackcache_2eaddJs_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ebuild_2ebackcache_2eaddJs(a[0], a[1], a2); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2ebuild_2ebackcache_2ebackText_str0, 1, ":");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2ebackText_str1, 1, ":");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2ebackText_str2, 5, "3:end");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2ebackText_str3, 0, "");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2ebackText_str4, 1, " ");
Clo g_heff_2ebuild_2ebackcache_2ebackText_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebackcache_2ebackText_entry, 2, 0};

V g_heff_2ebuild_2ebackcache_2ebackText(V v_id_240, V v_es_241) {
top: ;
  V v_groups_242 = heff_take_field(v_es_241, 0);
  V v_copies_243 = heff_take_field(v_es_241, 1);
  V v_emits_244 = heff_take_field(v_es_241, 2);
  V v_jss_245 = heff_get_n(v_es_241, 3, 4);
  V v_t_246 = heff_intShow(heff_strLength(heff_dup(g_heff_2ebuild_2ebackcache_2eversion_get())));
  V v_t_247 = heff_strAppend(v_t_246, heff_strAppend(((V)&g_heff_2ebuild_2ebackcache_2ebackText_str0), heff_dup(g_heff_2ebuild_2ebackcache_2eversion_get())));
  V v_t_248 = heff_intShow(heff_strLength_lent(v_id_240, 0));
  V v_t_249 = heff_strAppend(v_t_248, heff_strAppend(((V)&g_heff_2ebuild_2ebackcache_2ebackText_str1), v_id_240));
  V v_t_2410 = (g_std_2emap_2esize(v_groups_242));
  V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_t_2410), NTAG(TAG_Nil)});
  V v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_247, heff_tag_n(TAG_Cons, 2, (V[]){v_t_249, v_t_2411})});
  V v_t_2413 = ({ V a_0 = v_groups_242; V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2emap_2etoListOnto(a_0, a_1)); heff_drop(v_groups_242); r_; });
  V v_t_2414 = (g_list_2emap_24s1173914895x100384474(v_t_2413));
  V v_t_2415 = (g_std_2emap_2esize(v_copies_243));
  V v_t_2416 = ({ V a_0 = v_copies_243; V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2emap_2etoListOnto(a_0, a_1)); heff_drop(v_copies_243); r_; });
  V v_t_2417 = (g_list_2emap_24s1173914895x100384474(v_t_2416));
  V v_t_2418 = (g_std_2emap_2esize(v_emits_244));
  V v_t_2419 = ({ V a_0 = v_emits_244; V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2emap_2etoListOnto(a_0, a_1)); heff_drop(v_emits_244); r_; });
  V v_t_2420 = (g_list_2emap_24s1173914895x100384474(v_t_2419));
  V v_t_2421 = (g_std_2emap_2esize(v_jss_245));
  V v_t_2422 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ebackcache_2ebackText_str2), NTAG(TAG_Nil)});
  V v_t_2423 = ({ V a_0 = v_jss_245; V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2emap_2etoListOnto(a_0, a_1)); heff_drop(v_jss_245); r_; });
  V v_t_2424 = (g_prelude_2e_2b_2b_24f1085359736x1262841716(v_t_2422, v_t_2423));
  V v_t_2425 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_t_2421), v_t_2424});
  V v_t_2426 = (g_prelude_2e_2b_2b(v_t_2420, v_t_2425));
  V v_t_2427 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_t_2418), v_t_2426});
  V v_t_2428 = (g_prelude_2e_2b_2b(v_t_2417, v_t_2427));
  V v_t_2429 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_t_2415), v_t_2428});
  V v_t_2430 = (g_prelude_2e_2b_2b(v_t_2414, v_t_2429));
  V v_x2_2431 = (g_prelude_2e_2b_2b(v_t_2412, v_t_2430));
  switch (heff_tag_of(v_x2_2431)) {
  case TAG_Nil: {
    return ((V)&g_heff_2ebuild_2ebackcache_2ebackText_str3);
  }
  case TAG_Cons: {
    V v_x_2432 = heff_field(v_x2_2431, 0);
    V v_xs_2433 = heff_field(v_x2_2431, 1);
    heff_take_n(v_x2_2431, 3ULL, 2);
    return ({ V a_0 = ((V)&g_heff_2ebuild_2ebackcache_2ebackText_str4); V a_1 = v_x_2432; V a_2 = v_xs_2433; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2433); r_; });
  }
  default: return heff_nomatch(v_x2_2431);
  }
}
V g_heff_2ebuild_2ebackcache_2ebackText_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ebackcache_2ebackText(a[0], a[1]);
}
V g_heff_2ebuild_2ebackcache_2ebackTexts_lam0(V self, V *args);
Clo g_heff_2ebuild_2ebackcache_2ebackTexts_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebackcache_2ebackTexts_entry, 3, 0};

V g_heff_2ebuild_2ebackcache_2ebackTexts(V v_id_240, V v_fs_241, V v_gv_242) {
top: ;
  V v_groups_243 = heff_take_field(v_gv_242, 0);
  V v_copies_244 = heff_take_field(v_gv_242, 1);
  V v_emits_245 = heff_take_field(v_gv_242, 2);
  V v_jss_246 = heff_get_n(v_gv_242, 3, 4);
  V v_t_247 = ({ V a_0 = heff_dup(v_fs_241); V a_1 = heff_dup(g_std_2emap_2eempty_get()); V a_2 = v_groups_243; V r_ = (g_list_2efoldl_24s1494296198x1800016121(a_0, a_1, a_2)); heff_drop(v_groups_243); r_; });
  V v_t_248 = ({ V a_0 = heff_dup(v_fs_241); V a_1 = v_t_247; V a_2 = v_copies_244; V r_ = (g_list_2efoldl_24s1103469845x1474178821(a_0, a_1, a_2)); heff_drop(v_copies_244); r_; });
  V v_t_249 = ({ V a_0 = heff_dup(v_fs_241); V a_1 = v_t_248; V a_2 = v_emits_245; V r_ = (g_list_2efoldl_24s788343806x1528994845(a_0, a_1, a_2)); heff_drop(v_emits_245); r_; });
  V v_m_2410 = ({ V a_0 = v_fs_241; V a_1 = v_t_249; V a_2 = v_jss_246; V r_ = (g_list_2efoldl_24s425699049x1164890302(a_0, a_1, a_2)); heff_drop(v_jss_246); r_; });
  V v_t_2411 = ({ V a_0 = v_m_2410; V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2emap_2etoListOnto(a_0, a_1)); heff_drop(v_m_2410); r_; });
  return (g_list_2emap(heff_clo_n(g_heff_2ebuild_2ebackcache_2ebackTexts_lam0, 1, 1, (V[]){v_id_240}), v_t_2411));
}
V g_heff_2ebuild_2ebackcache_2ebackTexts_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ebackcache_2ebackTexts(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2ebackcache_2ebackTexts_lam0(V self, V *args) {
  V v_p_2412 = args[0];
  V v_id_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2415;
  switch (heff_tag_of(v_p_2412)) {
  case TAG_MkPair: {
    V v_x_2413 = heff_dup(heff_field(v_p_2412, 0));
    v_t_2415 = v_x_2413;
    break;
  }
  default: heff_nomatch(v_p_2412);
  }
  V v_t_2418;
  switch (heff_tag_of(v_p_2412)) {
  case TAG_MkPair: {
    V v_y_2417 = heff_field(v_p_2412, 1);
    heff_take_n(v_p_2412, 2ULL, 2);
    v_t_2418 = v_y_2417;
    break;
  }
  default: heff_nomatch(v_p_2412);
  }
  V v_t_2419 = (g_heff_2ebuild_2ebackcache_2ebackText(v_id_240, v_t_2418));
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2415, v_t_2419});
}