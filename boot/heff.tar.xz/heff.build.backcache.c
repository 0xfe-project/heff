// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define LBL_body 9524841
#define LBL_code 9554612
#define LBL_copies 592412158
#define LBL_def 308863
#define LBL_depth 296830685
#define LBL_done 9584713
#define LBL_emits 297985818
#define LBL_groups 709681407
#define LBL_jss 315076
#define LBL_key 315609
#define LBL_lams 9809570
#define LBL_lines 304335641
#define LBL_lprotos 613175609
#define LBL_made 9839068
#define LBL_mods 9852536
#define LBL_name 9869138
#define LBL_olds 9909235
#define LBL_owner 307523277
#define LBL_params 951713969
#define LBL_prims 308293287
#define LBL_protos 967342774
#define LBL_recipe 1012227257
#define LBL_refs 9991943
#define LBL_safe 10017876
#define LBL_sgSafe 1042218796
#define LBL_sgTotal 97882005
#define LBL_shapes 1043573789
#define LBL_strs 10036521
#define LBL_touched 1244526179
#define LBL_units 312791945
#define LBL_ver 326173
static uint32_t shape_body__touched[] = {LBL_body, LBL_touched};
static uint32_t shape_def__refs[] = {LBL_def, LBL_refs};
static uint32_t shape_groups__copies__emits__jss[] = {LBL_groups, LBL_copies, LBL_emits, LBL_jss};
static uint32_t shape_key__name__body__safe__touched__sgSafe__sgTotal[] = {LBL_key, LBL_name, LBL_body, LBL_safe, LBL_touched, LBL_sgSafe, LBL_sgTotal};
static uint32_t shape_owner__ver__units[] = {LBL_owner, LBL_ver, LBL_units};
static uint32_t shape_ver__lines__params__refs__prims[] = {LBL_ver, LBL_lines, LBL_params, LBL_refs, LBL_prims};
static uint32_t shape_ver__protos__code__strs__lprotos__lams__shapes__prims[] = {LBL_ver, LBL_protos, LBL_code, LBL_strs, LBL_lprotos, LBL_lams, LBL_shapes, LBL_prims};
static uint32_t shape_ver__recipe__depth__safe__made[] = {LBL_ver, LBL_recipe, LBL_depth, LBL_safe, LBL_made};
V g_heff_2ebuild_2ebackcache_2eaddCopy(V, V, V);
V g_heff_2ebuild_2ebackcache_2eaddCopy_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebackcache_2eaddCopy_clo;
V g_heff_2ebuild_2ebackcache_2eaddEmit(V, V, V);
V g_heff_2ebuild_2ebackcache_2eaddEmit_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebackcache_2eaddEmit_clo;
V g_heff_2ebuild_2ebackcache_2eaddGroup(V, V, V);
V g_heff_2ebuild_2ebackcache_2eaddGroup_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebackcache_2eaddGroup_clo;
V g_heff_2ebuild_2ebackcache_2eaddJs(V, V, V);
V g_heff_2ebuild_2ebackcache_2eaddJs_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebackcache_2eaddJs_clo;
V g_heff_2ebuild_2ebackcache_2eallJustB(V);
V g_heff_2ebuild_2ebackcache_2eallJustB_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebackcache_2eallJustB_clo;
V g_heff_2ebuild_2ebackcache_2ebackD(V, V, V);
V g_heff_2ebuild_2ebackcache_2ebackD_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebackcache_2ebackD_clo;
V g_heff_2ebuild_2ebackcache_2ebackDir_get(void);
V g_heff_2ebuild_2ebackcache_2ebackText(V, V);
V g_heff_2ebuild_2ebackcache_2ebackText_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebackcache_2ebackText_clo;
V g_heff_2ebuild_2ebackcache_2ebackTexts(V, V, V);
V g_heff_2ebuild_2ebackcache_2ebackTexts_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebackcache_2ebackTexts_clo;
V g_heff_2ebuild_2ebackcache_2ecopyD(V, V);
V g_heff_2ebuild_2ebackcache_2ecopyD_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebackcache_2ecopyD_clo;
V g_heff_2ebuild_2ebackcache_2ecopyText(V);
V g_heff_2ebuild_2ebackcache_2ecopyText_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebackcache_2ecopyText_clo;
V g_heff_2ebuild_2ebackcache_2eemitD(V, V);
V g_heff_2ebuild_2ebackcache_2eemitD_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebackcache_2eemitD_clo;
V g_heff_2ebuild_2ebackcache_2eemitText(V, V);
V g_heff_2ebuild_2ebackcache_2eemitText_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebackcache_2eemitText_clo;
V g_heff_2ebuild_2ebackcache_2eentriesAt(V, V, V);
V g_heff_2ebuild_2ebackcache_2eentriesAt_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebackcache_2eentriesAt_clo;
V g_heff_2ebuild_2ebackcache_2egroupD(V, V);
V g_heff_2ebuild_2ebackcache_2egroupD_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebackcache_2egroupD_clo;
V g_heff_2ebuild_2ebackcache_2egroupIn(V, V, V, V, V);
V g_heff_2ebuild_2ebackcache_2egroupIn_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebackcache_2egroupIn_clo;
V g_heff_2ebuild_2ebackcache_2egroupText(V, V, V);
V g_heff_2ebuild_2ebackcache_2egroupText_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebackcache_2egroupText_clo;
V g_heff_2ebuild_2ebackcache_2ejsD(V, V);
V g_heff_2ebuild_2ebackcache_2ejsD_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebackcache_2ejsD_clo;
V g_heff_2ebuild_2ebackcache_2ejsText(V, V);
V g_heff_2ebuild_2ebackcache_2ejsText_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebackcache_2ejsText_clo;
V g_heff_2ebuild_2ebackcache_2elastDotGo(V, V, V);
V g_heff_2ebuild_2ebackcache_2elastDotGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebackcache_2elastDotGo_clo;
V g_heff_2ebuild_2ebackcache_2emadeOf(V, V, V);
V g_heff_2ebuild_2ebackcache_2emadeOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebackcache_2emadeOf_clo;
V g_heff_2ebuild_2ebackcache_2emadeT(V);
V g_heff_2ebuild_2ebackcache_2emadeT_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebackcache_2emadeT_clo;
V g_heff_2ebuild_2ebackcache_2emoduleIn(V, V);
V g_heff_2ebuild_2ebackcache_2emoduleIn_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebackcache_2emoduleIn_clo;
V g_heff_2ebuild_2ebackcache_2enoBack_get(void);
V g_heff_2ebuild_2ebackcache_2epairsGo(V, V);
V g_heff_2ebuild_2ebackcache_2epairsGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebackcache_2epairsGo_clo;
V g_heff_2ebuild_2ebackcache_2erawGot(V, V, V);
V g_heff_2ebuild_2ebackcache_2erawGot_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebackcache_2erawGot_clo;
V g_heff_2ebuild_2ebackcache_2eunitD(V, V);
V g_heff_2ebuild_2ebackcache_2eunitD_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebackcache_2eunitD_clo;
V g_heff_2ebuild_2ebackcache_2eunitText(V);
V g_heff_2ebuild_2ebackcache_2eunitText_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebackcache_2eunitText_clo;
V g_heff_2ebuild_2ebackcache_2eversion_get(void);
V g_heff_2ebuild_2edecoder_2ebind_24s823677936x1444069277(V, V, V);
V g_heff_2ebuild_2edecoder_2ebind_24s823677936x1444069277_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edecoder_2ebind_24s823677936x1444069277_clo;
V g_heff_2ebuild_2edecoder_2efail(V, V);
V g_heff_2ebuild_2edecoder_2efail_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edecoder_2efail_clo;
V g_heff_2ebuild_2edecoder_2eint(V, V);
V g_heff_2ebuild_2edecoder_2eint_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edecoder_2eint_clo;
V g_heff_2ebuild_2edecoder_2estr(V, V);
V g_heff_2ebuild_2edecoder_2estr_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edecoder_2estr_clo;
V g_heff_2ebuild_2edecoder_2etimes_24s1444395529x927023430(V, V, V);
V g_heff_2ebuild_2edecoder_2etimes_24s1444395529x927023430_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edecoder_2etimes_24s1444395529x927023430_clo;
V g_heff_2ebuild_2edecoder_2etimes_24s1603230686x1883420273(V, V, V);
V g_heff_2ebuild_2edecoder_2etimes_24s1603230686x1883420273_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edecoder_2etimes_24s1603230686x1883420273_clo;
V g_heff_2ebuild_2edecoder_2etimes_24s1861622792x1526156306(V, V, V);
V g_heff_2ebuild_2edecoder_2etimes_24s1861622792x1526156306_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edecoder_2etimes_24s1861622792x1526156306_clo;
V g_heff_2ebuild_2edecoder_2etimes_24s364931774x210987922(V, V, V);
V g_heff_2ebuild_2edecoder_2etimes_24s364931774x210987922_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edecoder_2etimes_24s364931774x210987922_clo;
V g_heff_2ebuild_2edecoder_2etimes_24s372484702x1286645721(V, V, V);
V g_heff_2ebuild_2edecoder_2etimes_24s372484702x1286645721_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edecoder_2etimes_24s372484702x1286645721_clo;
V g_heff_2ebuild_2edecoder_2etimes_24s700921301x1216293995(V, V, V);
V g_heff_2ebuild_2edecoder_2etimes_24s700921301x1216293995_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edecoder_2etimes_24s700921301x1216293995_clo;
V g_heff_2ebuild_2edecoder_2etimes_24s98296704x1684150820(V, V, V);
V g_heff_2ebuild_2edecoder_2etimes_24s98296704x1684150820_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edecoder_2etimes_24s98296704x1684150820_clo;
V g_heff_2ebuild_2edecoder_2ewhole(V, V, V);
V g_heff_2ebuild_2edecoder_2ewhole_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edecoder_2ewhole_clo;
V g_heff_2ebuild_2edecoder_2eword(V, V);
V g_heff_2ebuild_2edecoder_2eword_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edecoder_2eword_clo;
V g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091(V, V);
V g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_clo;
V g_heff_2ecompile_2eirtext_2etakeExpr_get(void);
V g_list_2efind_24s1990539953x112149757(V, V);
V g_list_2efind_24s1990539953x112149757_entry(V self, V *a);
extern Clo g_list_2efind_24s1990539953x112149757_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s306513717x1560435942(V, V);
V g_list_2efoldl_24s306513717x1560435942_entry(V self, V *a);
extern Clo g_list_2efoldl_24s306513717x1560435942_clo;
V g_list_2efoldl_24s544151770x491236151(V, V);
V g_list_2efoldl_24s544151770x491236151_entry(V self, V *a);
extern Clo g_list_2efoldl_24s544151770x491236151_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1173914895x100384474(V);
V g_list_2emap_24s1173914895x100384474_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_clo;
V g_map_2eempty_get(void);
V g_map_2einsert_24s1341440536x470972936(V, V, V);
V g_map_2einsert_24s1341440536x470972936_entry(V self, V *a);
extern Clo g_map_2einsert_24s1341440536x470972936_clo;
V g_map_2elookup_24s1546226666x2146984184(V, V);
V g_map_2elookup_24s1546226666x2146984184_entry(V self, V *a);
extern Clo g_map_2elookup_24s1546226666x2146984184_clo;
V g_map_2elookup_24s659669741x1036301430(V, V);
V g_map_2elookup_24s659669741x1036301430_entry(V self, V *a);
extern Clo g_map_2elookup_24s659669741x1036301430_clo;
V g_map_2esize(V);
V g_map_2esize_entry(V self, V *a);
extern Clo g_map_2esize_clo;
V g_map_2etoListOnto(V, V);
V g_map_2etoListOnto_entry(V self, V *a);
extern Clo g_map_2etoListOnto_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24f1085359736x1262841716(V, V);
V g_prelude_2e_2b_2b_24f1085359736x1262841716_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f1085359736x1262841716_clo;
V g_prelude_2e_2b_2b_24f1815933030x829523367(V, V);
V g_prelude_2e_2b_2b_24f1815933030x829523367_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f1815933030x829523367_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2estrFind(V, V, V);
V g_prelude_2estrFind_entry(V self, V *a);
extern Clo g_prelude_2estrFind_clo;
HEFF_LIT(g_heff_2ebuild_2ebackcache_2eversion_str0, 14, "heff-backend/4");

static V g_heff_2ebuild_2ebackcache_2eversion_val;
static HEFF_ONCE g_heff_2ebuild_2ebackcache_2eversion_st;
static V g_heff_2ebuild_2ebackcache_2eversion_init(void) {
  return ((V)&g_heff_2ebuild_2ebackcache_2eversion_str0);
}
V g_heff_2ebuild_2ebackcache_2eversion_get(void) {
  if (HEFF_DONE(g_heff_2ebuild_2ebackcache_2eversion_st)) return g_heff_2ebuild_2ebackcache_2eversion_val;
  return heff_global(&g_heff_2ebuild_2ebackcache_2eversion_val, &g_heff_2ebuild_2ebackcache_2eversion_st, g_heff_2ebuild_2ebackcache_2eversion_init);
}
HEFF_LIT(g_heff_2ebuild_2ebackcache_2ebackDir_str0, 2, "b1");

static V g_heff_2ebuild_2ebackcache_2ebackDir_val;
static HEFF_ONCE g_heff_2ebuild_2ebackcache_2ebackDir_st;
static V g_heff_2ebuild_2ebackcache_2ebackDir_init(void) {
  return ((V)&g_heff_2ebuild_2ebackcache_2ebackDir_str0);
}
V g_heff_2ebuild_2ebackcache_2ebackDir_get(void) {
  if (HEFF_DONE(g_heff_2ebuild_2ebackcache_2ebackDir_st)) return g_heff_2ebuild_2ebackcache_2ebackDir_val;
  return heff_global(&g_heff_2ebuild_2ebackcache_2ebackDir_val, &g_heff_2ebuild_2ebackcache_2ebackDir_st, g_heff_2ebuild_2ebackcache_2ebackDir_init);
}
HEFF_LIT(g_heff_2ebuild_2ebackcache_2epairsGo_str0, 1, ":");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2epairsGo_str1, 1, ":");
Clo g_heff_2ebuild_2ebackcache_2epairsGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebackcache_2epairsGo_entry, 2, 0};

V g_heff_2ebuild_2ebackcache_2epairsGo(V v_x1_240, V v_rest_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return v_rest_241;
  }
  case TAG_Cons: {
    V v_p_242 = heff_field(v_x1_240, 0);
    V v_ps_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_rest_244 = (g_heff_2ebuild_2ebackcache_2epairsGo(v_ps_243, v_rest_241));
    switch (heff_tag_of(v_p_242)) {
    case TAG_MkPair: {
      V v_a_245 = heff_field(v_p_242, 0);
      V v_b_246 = heff_field(v_p_242, 1);
      heff_take_n(v_p_242, 3ULL, 2);
      V v_t_247 = heff_intShow(heff_strLength_lent(v_a_245, 0));
      V v_t_248 = heff_strAppend(v_t_247, heff_strAppend(((V)&g_heff_2ebuild_2ebackcache_2epairsGo_str0), v_a_245));
      V v_t_249 = heff_intShow(heff_strLength_lent(v_b_246, 0));
      V v_t_2410 = heff_strAppend(v_t_249, heff_strAppend(((V)&g_heff_2ebuild_2ebackcache_2epairsGo_str1), v_b_246));
      return heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_t_248, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2410, v_rest_244})});
    }
    default: return heff_nomatch(v_p_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2ebackcache_2epairsGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ebackcache_2epairsGo(a[0], a[1]);
}
HEFF_LIT(g_heff_2ebuild_2ebackcache_2eunitText_str0, 1, ":");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2eunitText_str1, 1, ":");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2eunitText_str2, 1, "t");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2eunitText_str3, 1, "f");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2eunitText_str4, 0, "");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2eunitText_str5, 1, " ");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2eunitText_str6, 1, ":");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2eunitText_str7, 1, "t");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2eunitText_str8, 1, "f");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2eunitText_str9, 0, "");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2eunitText_str10, 1, " ");
Clo g_heff_2ebuild_2ebackcache_2eunitText_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebackcache_2eunitText_entry, 1, 0};

V g_heff_2ebuild_2ebackcache_2eunitText(V v_u_240) {
top: ;
  V v_s_241 = heff_get_n(heff_dup(heff_rfield(v_u_240, 0)), 0, 4);
  V v_t_242 = heff_intShow(heff_strLength_lent(v_s_241, 0));
  V v_t_243 = heff_strAppend(v_t_242, heff_strAppend(((V)&g_heff_2ebuild_2ebackcache_2eunitText_str0), v_s_241));
  V v_s_244 = heff_take_field(v_u_240, 1);
  V v_t_245 = heff_intShow(heff_strLength_lent(v_s_244, 0));
  V v_t_246 = heff_strAppend(v_t_245, heff_strAppend(((V)&g_heff_2ebuild_2ebackcache_2eunitText_str1), v_s_244));
  V v_xs_247 = heff_take_field(v_u_240, 2);
  V v_t_248 = heff_take_field(v_u_240, 3);
  V v_t_249;
  if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
    heff_drop(v_t_248);
    v_t_249 = ((V)&g_heff_2ebuild_2ebackcache_2eunitText_str2);
  } else {
    heff_drop(v_t_248);
    v_t_249 = ((V)&g_heff_2ebuild_2ebackcache_2eunitText_str3);
  }
  V v_t_2410 = heff_intShow(heff_take_field(v_u_240, 4));
  V v_t_2411 = heff_get_n(heff_dup(heff_rfield(v_u_240, 0)), 1, 4);
  V v_x2_2412 = (g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091(v_t_2411, NTAG(TAG_Nil)));
  V v_s_2415;
  switch (heff_tag_of(v_x2_2412)) {
  case TAG_Nil: {
    v_s_2415 = ((V)&g_heff_2ebuild_2ebackcache_2eunitText_str4);
    break;
  }
  case TAG_Cons: {
    V v_x_2413 = heff_field(v_x2_2412, 0);
    V v_xs_2414 = heff_field(v_x2_2412, 1);
    heff_take_n(v_x2_2412, 3ULL, 2);
    v_s_2415 = ({ V a_0 = ((V)&g_heff_2ebuild_2ebackcache_2eunitText_str5); V a_1 = v_x_2413; V a_2 = v_xs_2414; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2414); r_; });
    break;
  }
  default: heff_nomatch(v_x2_2412);
  }
  V v_t_2416 = heff_intShow(heff_strLength_lent(v_s_2415, 0));
  V v_t_2417 = heff_strAppend(v_t_2416, heff_strAppend(((V)&g_heff_2ebuild_2ebackcache_2eunitText_str6), v_s_2415));
  V v_t_2418 = heff_get_n(heff_dup(heff_rfield(v_u_240, 0)), 2, 4);
  V v_t_2419;
  if ((heff_dup(v_t_2418) == NTAG(TAG_True))) {
    heff_drop(v_t_2418);
    v_t_2419 = ((V)&g_heff_2ebuild_2ebackcache_2eunitText_str7);
  } else {
    heff_drop(v_t_2418);
    v_t_2419 = ((V)&g_heff_2ebuild_2ebackcache_2eunitText_str8);
  }
  V v_ps_2420 = heff_get_n(heff_get_n(v_u_240, 0, 5), 3, 4);
  V v_t_2421 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_ps_2420));
  V v_t_2422 = (g_heff_2ebuild_2ebackcache_2epairsGo(v_ps_2420, NTAG(TAG_Nil)));
  V v_t_2423 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_t_2421), v_t_2422});
  V v_t_2424 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2417, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2419, v_t_2423})});
  V v_rest_2425 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_249, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2410, v_t_2424})});
  V v_t_2426 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_247));
  V v_t_2427 = (g_prelude_2e_2b_2b_24f1815933030x829523367(v_rest_2425, v_xs_247));
  V v_t_2428 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_t_2426), v_t_2427});
  V v_x2_2429 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_243, heff_tag_n(TAG_Cons, 2, (V[]){v_t_246, v_t_2428})});
  switch (heff_tag_of(v_x2_2429)) {
  case TAG_Nil: {
    return ((V)&g_heff_2ebuild_2ebackcache_2eunitText_str9);
  }
  case TAG_Cons: {
    V v_x_2430 = heff_field(v_x2_2429, 0);
    V v_xs_2431 = heff_field(v_x2_2429, 1);
    heff_take_n(v_x2_2429, 3ULL, 2);
    return ({ V a_0 = ((V)&g_heff_2ebuild_2ebackcache_2eunitText_str10); V a_1 = v_x_2430; V a_2 = v_xs_2431; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2431); r_; });
  }
  default: return heff_nomatch(v_x2_2429);
  }
}
V g_heff_2ebuild_2ebackcache_2eunitText_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ebackcache_2eunitText(a[0]);
}
HEFF_LIT(g_heff_2ebuild_2ebackcache_2emadeT_str0, 1, "n");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2emadeT_str1, 0, "");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2emadeT_str2, 1, " ");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2emadeT_str3, 1, ":");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2emadeT_str4, 1, "j");
Clo g_heff_2ebuild_2ebackcache_2emadeT_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebackcache_2emadeT_entry, 1, 0};

V g_heff_2ebuild_2ebackcache_2emadeT(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nothing: {
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ebackcache_2emadeT_str0), NTAG(TAG_Nil)});
  }
  case TAG_Just: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_MkPair: {
      V v_b_242 = heff_field(v_x11_241, 0);
      V v_t_243 = heff_field(v_x11_241, 1);
      V v_x2_244 = (g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091(heff_dup(v_b_242), NTAG(TAG_Nil)));
      V v_s_247;
      switch (heff_tag_of(v_x2_244)) {
      case TAG_Nil: {
        v_s_247 = ((V)&g_heff_2ebuild_2ebackcache_2emadeT_str1);
        break;
      }
      case TAG_Cons: {
        V v_x_245 = heff_field(v_x2_244, 0);
        V v_xs_246 = heff_field(v_x2_244, 1);
        heff_take_n(v_x2_244, 3ULL, 2);
        v_s_247 = ({ V a_0 = ((V)&g_heff_2ebuild_2ebackcache_2emadeT_str2); V a_1 = v_x_245; V a_2 = v_xs_246; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_246); r_; });
        break;
      }
      default: heff_nomatch(v_x2_244);
      }
      V v_t_248 = heff_intShow(heff_strLength_lent(v_s_247, 0));
      V v_t_249 = heff_strAppend(v_t_248, heff_strAppend(((V)&g_heff_2ebuild_2ebackcache_2emadeT_str3), v_s_247));
      V v_t_2410 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_t_243));
      V v_t_2411 = (g_heff_2ebuild_2ebackcache_2epairsGo(heff_dup(v_t_243), NTAG(TAG_Nil)));
      V v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_t_2410), v_t_2411});
      return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ebackcache_2emadeT_str4), heff_tag_n(TAG_Cons, 2, (V[]){v_t_249, v_t_2412})});
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2ebackcache_2emadeT_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ebackcache_2emadeT(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ebuild_2ebackcache_2ecopyText_str0, 1, ":");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2ecopyText_str1, 1, ":");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2ecopyText_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2ecopyText_str3, 1, " ");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2ecopyText_str4, 1, ":");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2ecopyText_str5, 1, "t");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2ecopyText_str6, 1, "f");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2ecopyText_str7, 0, "");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2ecopyText_str8, 1, " ");
Clo g_heff_2ebuild_2ebackcache_2ecopyText_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebackcache_2ecopyText_entry, 1, 0};

V g_heff_2ebuild_2ebackcache_2ecopyText(V v_c_240) {
top: ;
  V v_s_241 = heff_take_field(v_c_240, 0);
  V v_t_242 = heff_intShow(heff_strLength_lent(v_s_241, 0));
  V v_t_243 = heff_strAppend(v_t_242, heff_strAppend(((V)&g_heff_2ebuild_2ebackcache_2ecopyText_str0), v_s_241));
  V v_s_244 = heff_take_field(v_c_240, 1);
  V v_t_245 = heff_intShow(heff_strLength_lent(v_s_244, 0));
  V v_t_246 = heff_strAppend(v_t_245, heff_strAppend(((V)&g_heff_2ebuild_2ebackcache_2ecopyText_str1), v_s_244));
  V v_x2_247 = (g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091(heff_take_field(v_c_240, 2), NTAG(TAG_Nil)));
  V v_s_2410;
  switch (heff_tag_of(v_x2_247)) {
  case TAG_Nil: {
    v_s_2410 = ((V)&g_heff_2ebuild_2ebackcache_2ecopyText_str2);
    break;
  }
  case TAG_Cons: {
    V v_x_248 = heff_field(v_x2_247, 0);
    V v_xs_249 = heff_field(v_x2_247, 1);
    heff_take_n(v_x2_247, 3ULL, 2);
    v_s_2410 = ({ V a_0 = ((V)&g_heff_2ebuild_2ebackcache_2ecopyText_str3); V a_1 = v_x_248; V a_2 = v_xs_249; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_249); r_; });
    break;
  }
  default: heff_nomatch(v_x2_247);
  }
  V v_t_2411 = heff_intShow(heff_strLength_lent(v_s_2410, 0));
  V v_t_2412 = heff_strAppend(v_t_2411, heff_strAppend(((V)&g_heff_2ebuild_2ebackcache_2ecopyText_str4), v_s_2410));
  V v_t_2413 = heff_intShow(heff_take_field(v_c_240, 3));
  V v_t_2414 = heff_take_field(v_c_240, 4);
  V v_t_2415;
  if ((heff_dup(v_t_2414) == NTAG(TAG_True))) {
    heff_drop(v_t_2414);
    v_t_2415 = ((V)&g_heff_2ebuild_2ebackcache_2ecopyText_str5);
  } else {
    heff_drop(v_t_2414);
    v_t_2415 = ((V)&g_heff_2ebuild_2ebackcache_2ecopyText_str6);
  }
  V v_t_2416 = ({ V b_0 = heff_get_n(v_c_240, 5, 6); V r_ = (g_heff_2ebuild_2ebackcache_2emadeT(b_0)); heff_drop(b_0); r_; });
  V v_t_2417 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2413, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2415, v_t_2416})});
  V v_t_2418 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_246, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2412, v_t_2417})});
  V v_x2_2419 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_243, v_t_2418});
  switch (heff_tag_of(v_x2_2419)) {
  case TAG_Nil: {
    return ((V)&g_heff_2ebuild_2ebackcache_2ecopyText_str7);
  }
  case TAG_Cons: {
    V v_x_2420 = heff_field(v_x2_2419, 0);
    V v_xs_2421 = heff_field(v_x2_2419, 1);
    heff_take_n(v_x2_2419, 3ULL, 2);
    return ({ V a_0 = ((V)&g_heff_2ebuild_2ebackcache_2ecopyText_str8); V a_1 = v_x_2420; V a_2 = v_xs_2421; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2421); r_; });
  }
  default: return heff_nomatch(v_x2_2419);
  }
}
V g_heff_2ebuild_2ebackcache_2ecopyText_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ebackcache_2ecopyText(a[0]);
}
HEFF_LIT(g_heff_2ebuild_2ebackcache_2eemitText_str0, 1, ":");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2eemitText_str1, 1, ":");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2eemitText_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2eemitText_str3, 1, " ");
Clo g_heff_2ebuild_2ebackcache_2eemitText_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebackcache_2eemitText_entry, 2, 0};

V g_heff_2ebuild_2ebackcache_2eemitText(V v_key_240, V v_k_241) {
top: ;
  V v_t_242 = heff_intShow(heff_strLength_lent(v_key_240, 0));
  V v_t_243 = heff_strAppend(v_t_242, heff_strAppend(((V)&g_heff_2ebuild_2ebackcache_2eemitText_str0), v_key_240));
  V v_s_244 = heff_take_field(v_k_241, 0);
  V v_t_245 = heff_intShow(heff_strLength_lent(v_s_244, 0));
  V v_t_246 = heff_strAppend(v_t_245, heff_strAppend(((V)&g_heff_2ebuild_2ebackcache_2eemitText_str1), v_s_244));
  V v_xs_247 = heff_take_field(v_k_241, 1);
  V v_xs_248 = heff_take_field(v_k_241, 2);
  V v_xs_249 = heff_take_field(v_k_241, 3);
  V v_xs_2410 = heff_take_field(v_k_241, 4);
  V v_xs_2411 = heff_take_field(v_k_241, 5);
  V v_xs_2412 = heff_take_field(v_k_241, 6);
  V v_xs_2413 = heff_get_n(v_k_241, 7, 8);
  V v_t_2414 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_2413));
  V v_t_2415 = (g_prelude_2e_2b_2b_24f1815933030x829523367(NTAG(TAG_Nil), v_xs_2413));
  V v_rest_2416 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_t_2414), v_t_2415});
  V v_t_2417 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_2412));
  V v_t_2418 = (g_prelude_2e_2b_2b_24f1815933030x829523367(v_rest_2416, v_xs_2412));
  V v_rest_2419 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_t_2417), v_t_2418});
  V v_t_2420 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_2411));
  V v_t_2421 = (g_prelude_2e_2b_2b_24f1815933030x829523367(v_rest_2419, v_xs_2411));
  V v_rest_2422 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_t_2420), v_t_2421});
  V v_t_2423 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_2410));
  V v_t_2424 = (g_prelude_2e_2b_2b_24f1815933030x829523367(v_rest_2422, v_xs_2410));
  V v_rest_2425 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_t_2423), v_t_2424});
  V v_t_2426 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_249));
  V v_t_2427 = (g_prelude_2e_2b_2b_24f1815933030x829523367(v_rest_2425, v_xs_249));
  V v_rest_2428 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_t_2426), v_t_2427});
  V v_t_2429 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_248));
  V v_t_2430 = (g_prelude_2e_2b_2b_24f1815933030x829523367(v_rest_2428, v_xs_248));
  V v_rest_2431 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_t_2429), v_t_2430});
  V v_t_2432 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_247));
  V v_t_2433 = (g_prelude_2e_2b_2b_24f1815933030x829523367(v_rest_2431, v_xs_247));
  V v_t_2434 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_t_2432), v_t_2433});
  V v_x2_2435 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_243, heff_tag_n(TAG_Cons, 2, (V[]){v_t_246, v_t_2434})});
  switch (heff_tag_of(v_x2_2435)) {
  case TAG_Nil: {
    return ((V)&g_heff_2ebuild_2ebackcache_2eemitText_str2);
  }
  case TAG_Cons: {
    V v_x_2436 = heff_field(v_x2_2435, 0);
    V v_xs_2437 = heff_field(v_x2_2435, 1);
    heff_take_n(v_x2_2435, 3ULL, 2);
    return ({ V a_0 = ((V)&g_heff_2ebuild_2ebackcache_2eemitText_str3); V a_1 = v_x_2436; V a_2 = v_xs_2437; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2437); r_; });
  }
  default: return heff_nomatch(v_x2_2435);
  }
}
V g_heff_2ebuild_2ebackcache_2eemitText_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ebackcache_2eemitText(a[0], a[1]);
}
HEFF_LIT(g_heff_2ebuild_2ebackcache_2ejsText_str0, 1, ":");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2ejsText_str1, 1, ":");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2ejsText_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2ejsText_str3, 1, " ");
Clo g_heff_2ebuild_2ebackcache_2ejsText_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebackcache_2ejsText_entry, 2, 0};

V g_heff_2ebuild_2ebackcache_2ejsText(V v_key_240, V v_k_241) {
top: ;
  V v_t_242 = heff_intShow(heff_strLength_lent(v_key_240, 0));
  V v_t_243 = heff_strAppend(v_t_242, heff_strAppend(((V)&g_heff_2ebuild_2ebackcache_2ejsText_str0), v_key_240));
  V v_s_244 = heff_take_field(v_k_241, 0);
  V v_t_245 = heff_intShow(heff_strLength_lent(v_s_244, 0));
  V v_t_246 = heff_strAppend(v_t_245, heff_strAppend(((V)&g_heff_2ebuild_2ebackcache_2ejsText_str1), v_s_244));
  V v_xs_247 = heff_take_field(v_k_241, 1);
  V v_xs_248 = heff_take_field(v_k_241, 2);
  V v_xs_249 = heff_take_field(v_k_241, 3);
  V v_xs_2410 = heff_get_n(v_k_241, 4, 5);
  V v_t_2411 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_2410));
  V v_t_2412 = (g_prelude_2e_2b_2b_24f1815933030x829523367(NTAG(TAG_Nil), v_xs_2410));
  V v_rest_2413 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_t_2411), v_t_2412});
  V v_t_2414 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_249));
  V v_t_2415 = (g_prelude_2e_2b_2b_24f1815933030x829523367(v_rest_2413, v_xs_249));
  V v_rest_2416 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_t_2414), v_t_2415});
  V v_t_2417 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_248));
  V v_t_2418 = (g_prelude_2e_2b_2b_24f1815933030x829523367(v_rest_2416, v_xs_248));
  V v_rest_2419 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_t_2417), v_t_2418});
  V v_t_2420 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_247));
  V v_t_2421 = (g_prelude_2e_2b_2b_24f1815933030x829523367(v_rest_2419, v_xs_247));
  V v_t_2422 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_t_2420), v_t_2421});
  V v_x2_2423 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_243, heff_tag_n(TAG_Cons, 2, (V[]){v_t_246, v_t_2422})});
  switch (heff_tag_of(v_x2_2423)) {
  case TAG_Nil: {
    return ((V)&g_heff_2ebuild_2ebackcache_2ejsText_str2);
  }
  case TAG_Cons: {
    V v_x_2424 = heff_field(v_x2_2423, 0);
    V v_xs_2425 = heff_field(v_x2_2423, 1);
    heff_take_n(v_x2_2423, 3ULL, 2);
    return ({ V a_0 = ((V)&g_heff_2ebuild_2ebackcache_2ejsText_str3); V a_1 = v_x_2424; V a_2 = v_xs_2425; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2425); r_; });
  }
  default: return heff_nomatch(v_x2_2423);
  }
}
V g_heff_2ebuild_2ebackcache_2ejsText_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ebackcache_2ejsText(a[0], a[1]);
}
Clo g_heff_2ebuild_2ebackcache_2erawGot_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebackcache_2erawGot_entry, 3, 0};

V g_heff_2ebuild_2ebackcache_2erawGot(V v_s_240, V v_i_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nothing: {
    heff_drop(v_s_240);
    heff_drop(v_i_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_x31_243 = heff_field(v_x3_242, 0);
    V v_ru_24x3_242_24Just = heff_take_reuse_n(v_x3_242, 1ULL, 1);
    switch (heff_tag_of(v_x31_243)) {
    case TAG_MkPair: {
      V v_x_244 = heff_field(v_x31_243, 0);
      V v_j_245 = heff_field(v_x31_243, 1);
      V v_ru_24x31_243_24MkPair = heff_take_reuse_n(v_x31_243, 3ULL, 2);
      V v_t_249;
      if (heff_intLt_c(heff_dup(v_i_241), heff_dup(v_j_245))) {
        V v_t_247 = heff_strByteAt(heff_dup(v_s_240), heff_intSub(heff_dup(v_j_245), MK_INT(1LL)));
        if (heff_intEq_c(v_t_247, MK_INT(32LL))) {
          v_t_249 = heff_intSub(heff_dup(v_j_245), MK_INT(1LL));
        } else {
          v_t_249 = heff_dup(v_j_245);
        }
      } else {
        v_t_249 = heff_dup(v_j_245);
      }
      V v_t_2410 = heff_tag_at_n(v_ru_24x31_243_24MkPair, TAG_MkPair, 2, (V[]){v_x_244, heff_strSlice(v_s_240, v_i_241, v_t_249)});
      return heff_tag_at_n(v_ru_24x3_242_24Just, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2410, v_j_245})});
    }
    default: return heff_nomatch(v_x31_243);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2ebackcache_2erawGot_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ebackcache_2erawGot(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2ebackcache_2eunitD_lam2(V self, V *args);
V g_heff_2ebuild_2ebackcache_2eunitD_lam1(V self, V *args);
V g_heff_2ebuild_2ebackcache_2eunitD_lam0(V self, V *args);
Clo g_heff_2ebuild_2ebackcache_2eunitD_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebackcache_2eunitD_entry, 2, 0};

V g_heff_2ebuild_2ebackcache_2eunitD(V v_s_240, V v_i_241) {
top: ;
  V v_x3_242 = (g_heff_2ebuild_2edecoder_2estr(heff_dup(v_s_240), v_i_241));
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nothing: {
    heff_drop(v_s_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_x31_243 = heff_field(v_x3_242, 0);
    heff_take_n(v_x3_242, 1ULL, 1);
    switch (heff_tag_of(v_x31_243)) {
    case TAG_MkPair: {
      V v_x_244 = heff_field(v_x31_243, 0);
      V v_j_245 = heff_field(v_x31_243, 1);
      heff_take_n(v_x31_243, 3ULL, 2);
      V v_x3_246 = (g_heff_2ebuild_2edecoder_2estr(heff_dup(v_s_240), v_j_245));
      switch (heff_tag_of(v_x3_246)) {
      case TAG_Nothing: {
        heff_drop(v_s_240);
        heff_drop(v_x_244);
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_x31_247 = heff_field(v_x3_246, 0);
        heff_take_n(v_x3_246, 1ULL, 1);
        switch (heff_tag_of(v_x31_247)) {
        case TAG_MkPair: {
          V v_x_248 = heff_field(v_x31_247, 0);
          V v_j_249 = heff_field(v_x31_247, 1);
          heff_take_n(v_x31_247, 3ULL, 2);
          V v_x3_2410 = (g_heff_2ebuild_2edecoder_2eint(heff_dup(v_s_240), v_j_249));
          V v_x3_2414;
          switch (heff_tag_of(v_x3_2410)) {
          case TAG_Nothing: {
            v_x3_2414 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_Just: {
            V v_x31_2411 = heff_field(v_x3_2410, 0);
            heff_take_n(v_x3_2410, 1ULL, 1);
            switch (heff_tag_of(v_x31_2411)) {
            case TAG_MkPair: {
              V v_x_2412 = heff_field(v_x31_2411, 0);
              V v_j_2413 = heff_field(v_x31_2411, 1);
              heff_take_n(v_x31_2411, 3ULL, 2);
              v_x3_2414 = (g_heff_2ebuild_2edecoder_2etimes_24s1603230686x1883420273(v_x_2412, heff_dup(v_s_240), v_j_2413));
              break;
            }
            default: heff_nomatch(v_x31_2411);
            }
            break;
          }
          default: heff_nomatch(v_x3_2410);
          }
          switch (heff_tag_of(v_x3_2414)) {
          case TAG_Nothing: {
            heff_drop(v_s_240);
            heff_drop(v_x_244);
            heff_drop(v_x_248);
            return NTAG(TAG_Nothing);
          }
          case TAG_Just: {
            V v_x31_2415 = heff_field(v_x3_2414, 0);
            heff_take_n(v_x3_2414, 1ULL, 1);
            switch (heff_tag_of(v_x31_2415)) {
            case TAG_MkPair: {
              V v_x_2416 = heff_field(v_x31_2415, 0);
              V v_j_2417 = heff_field(v_x31_2415, 1);
              heff_take_n(v_x31_2415, 3ULL, 2);
              return (g_heff_2ebuild_2edecoder_2ebind_24s823677936x1444069277(heff_clo_n(g_heff_2ebuild_2ebackcache_2eunitD_lam0, 3, 3, (V[]){v_x_244, v_x_248, v_x_2416}), v_s_240, v_j_2417));
            }
            default: return heff_nomatch(v_x31_2415);
            }
          }
          default: return heff_nomatch(v_x3_2414);
          }
        }
        default: return heff_nomatch(v_x31_247);
        }
      }
      default: return heff_nomatch(v_x3_246);
      }
    }
    default: return heff_nomatch(v_x31_243);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2ebackcache_2eunitD_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ebackcache_2eunitD(a[0], a[1]);
}
V g_heff_2ebuild_2ebackcache_2eunitD_lam2(V self, V *args) {
  V v_u_2440 = args[0];
  V v_x_2427 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2440);
  V v_x1_2441 = (g_heff_2ebuild_2edecoder_2ewhole(heff_dup(g_heff_2ecompile_2eirtext_2etakeExpr_get()), v_x_2427, MK_INT(0LL)));
  switch (heff_tag_of(v_x1_2441)) {
  case TAG_Nothing: {
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_x11_2442 = heff_field(v_x1_2441, 0);
    V v_ru_24x1_2441_24Just = heff_take_reuse_n(v_x1_2441, 1ULL, 1);
    switch (heff_tag_of(v_x11_2442)) {
    case TAG_MkPair: {
      V v_x_2443 = heff_field(v_x11_2442, 0);
      heff_take_n(v_x11_2442, 1ULL, 2);
      return heff_tag_at_n(v_ru_24x1_2441_24Just, TAG_Just, 1, (V[]){v_x_2443});
    }
    default: return heff_nomatch(v_x11_2442);
    }
  }
  default: return heff_nomatch(v_x1_2441);
  }
}
V g_heff_2ebuild_2ebackcache_2eunitD_lam1(V self, V *args) {
  V v_safe_2429 = args[0];
  V v_s_2430 = args[1];
  V v_i_2431 = args[2];
  V v_x_244 = heff_env(self)[0];
  V v_x_248 = heff_env(self)[1];
  V v_x_2427 = heff_env(self)[2];
  V v_sgSafe_2418 = heff_env(self)[3];
  V v_x_2423 = heff_env(self)[4];
  V v_x_2416 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_x3_2432 = (g_heff_2ebuild_2edecoder_2eint(heff_dup(v_s_2430), v_i_2431));
  V v_x3_2436;
  switch (heff_tag_of(v_x3_2432)) {
  case TAG_Nothing: {
    heff_drop(v_s_2430);
    v_x3_2436 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Just: {
    V v_x31_2433 = heff_field(v_x3_2432, 0);
    heff_take_n(v_x3_2432, 1ULL, 1);
    switch (heff_tag_of(v_x31_2433)) {
    case TAG_MkPair: {
      V v_x_2434 = heff_field(v_x31_2433, 0);
      V v_j_2435 = heff_field(v_x31_2433, 1);
      heff_take_n(v_x31_2433, 3ULL, 2);
      v_x3_2436 = (g_heff_2ebuild_2edecoder_2etimes_24s98296704x1684150820(v_x_2434, v_s_2430, v_j_2435));
      break;
    }
    default: heff_nomatch(v_x31_2433);
    }
    break;
  }
  default: heff_nomatch(v_x3_2432);
  }
  switch (heff_tag_of(v_x3_2436)) {
  case TAG_Nothing: {
    heff_drop(v_safe_2429);
    heff_drop(v_x_244);
    heff_drop(v_x_248);
    heff_drop(v_x_2427);
    heff_drop(v_sgSafe_2418);
    heff_drop(v_x_2423);
    heff_drop(v_x_2416);
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_x31_2437 = heff_field(v_x3_2436, 0);
    V v_ru_24x3_2436_24Just = heff_take_reuse_n(v_x3_2436, 1ULL, 1);
    switch (heff_tag_of(v_x31_2437)) {
    case TAG_MkPair: {
      V v_x_2438 = heff_field(v_x31_2437, 0);
      V v_j_2439 = heff_field(v_x31_2437, 1);
      heff_take_n(v_x31_2437, 3ULL, 2);
      V v_t_2445 = heff_rec_n(2, shape_def__refs, (V[]){heff_rec_n(7, shape_key__name__body__safe__touched__sgSafe__sgTotal, (V[]){v_x_244, v_x_248, heff_clo_n(g_heff_2ebuild_2ebackcache_2eunitD_lam2, 1, 1, (V[]){v_x_2427}), v_safe_2429, v_x_2438, v_sgSafe_2418, v_x_2423}), v_x_2416});
      return heff_tag_at_n(v_ru_24x3_2436_24Just, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2445, v_j_2439})});
    }
    default: return heff_nomatch(v_x31_2437);
    }
  }
  default: return heff_nomatch(v_x3_2436);
  }
}
V g_heff_2ebuild_2ebackcache_2eunitD_lam0(V self, V *args) {
  V v_sgSafe_2418 = args[0];
  V v_s_2419 = args[1];
  V v_i_2420 = args[2];
  V v_x_244 = heff_env(self)[0];
  V v_x_248 = heff_env(self)[1];
  V v_x_2416 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x3_2421 = (g_heff_2ebuild_2edecoder_2eint(heff_dup(v_s_2419), v_i_2420));
  switch (heff_tag_of(v_x3_2421)) {
  case TAG_Nothing: {
    heff_drop(v_sgSafe_2418);
    heff_drop(v_s_2419);
    heff_drop(v_x_244);
    heff_drop(v_x_248);
    heff_drop(v_x_2416);
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_x31_2422 = heff_field(v_x3_2421, 0);
    heff_take_n(v_x3_2421, 1ULL, 1);
    switch (heff_tag_of(v_x31_2422)) {
    case TAG_MkPair: {
      V v_x_2423 = heff_field(v_x31_2422, 0);
      V v_j_2424 = heff_field(v_x31_2422, 1);
      heff_take_n(v_x31_2422, 3ULL, 2);
      V v_x3_2425 = (g_heff_2ebuild_2edecoder_2estr(heff_dup(v_s_2419), v_j_2424));
      switch (heff_tag_of(v_x3_2425)) {
      case TAG_Nothing: {
        heff_drop(v_sgSafe_2418);
        heff_drop(v_s_2419);
        heff_drop(v_x_244);
        heff_drop(v_x_248);
        heff_drop(v_x_2416);
        heff_drop(v_x_2423);
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_x31_2426 = heff_field(v_x3_2425, 0);
        heff_take_n(v_x3_2425, 1ULL, 1);
        switch (heff_tag_of(v_x31_2426)) {
        case TAG_MkPair: {
          V v_x_2427 = heff_field(v_x31_2426, 0);
          V v_j_2428 = heff_field(v_x31_2426, 1);
          heff_take_n(v_x31_2426, 3ULL, 2);
          return (g_heff_2ebuild_2edecoder_2ebind_24s823677936x1444069277(heff_clo_n(g_heff_2ebuild_2ebackcache_2eunitD_lam1, 3, 6, (V[]){v_x_244, v_x_248, v_x_2427, v_sgSafe_2418, v_x_2423, v_x_2416}), v_s_2419, v_j_2428));
        }
        default: return heff_nomatch(v_x31_2426);
        }
      }
      default: return heff_nomatch(v_x3_2425);
      }
    }
    default: return heff_nomatch(v_x31_2422);
    }
  }
  default: return heff_nomatch(v_x3_2421);
  }
}
Clo g_heff_2ebuild_2ebackcache_2egroupD_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebackcache_2egroupD_entry, 2, 0};

V g_heff_2ebuild_2ebackcache_2egroupD(V v_s_240, V v_i_241) {
top: ;
  V v_x3_242 = (g_heff_2ebuild_2edecoder_2estr(heff_dup(v_s_240), v_i_241));
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nothing: {
    heff_drop(v_s_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_x31_243 = heff_field(v_x3_242, 0);
    V v_ru_24x3_242_24Just = heff_take_reuse_n(v_x3_242, 1ULL, 1);
    switch (heff_tag_of(v_x31_243)) {
    case TAG_MkPair: {
      V v_x_244 = heff_field(v_x31_243, 0);
      V v_j_245 = heff_field(v_x31_243, 1);
      V v_ru_24x31_243_24MkPair = heff_take_reuse_n(v_x31_243, 3ULL, 2);
      V v_x3_246 = (g_heff_2ebuild_2edecoder_2estr(heff_dup(v_s_240), v_j_245));
      switch (heff_tag_of(v_x3_246)) {
      case TAG_Nothing: {
        heff_drop(v_s_240);
        heff_drop_cell(v_ru_24x3_242_24Just, 1);
        heff_drop(v_x_244);
        heff_drop_cell(v_ru_24x31_243_24MkPair, 2);
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_x31_247 = heff_field(v_x3_246, 0);
        heff_take_n(v_x3_246, 1ULL, 1);
        switch (heff_tag_of(v_x31_247)) {
        case TAG_MkPair: {
          V v_x_248 = heff_field(v_x31_247, 0);
          V v_j_249 = heff_field(v_x31_247, 1);
          heff_take_n(v_x31_247, 3ULL, 2);
          V v_x3_2410 = (g_heff_2ebuild_2edecoder_2eint(heff_dup(v_s_240), v_j_249));
          V v_x3_2414;
          switch (heff_tag_of(v_x3_2410)) {
          case TAG_Nothing: {
            heff_drop(v_s_240);
            v_x3_2414 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_Just: {
            V v_x31_2411 = heff_field(v_x3_2410, 0);
            heff_take_n(v_x3_2410, 1ULL, 1);
            switch (heff_tag_of(v_x31_2411)) {
            case TAG_MkPair: {
              V v_x_2412 = heff_field(v_x31_2411, 0);
              V v_j_2413 = heff_field(v_x31_2411, 1);
              heff_take_n(v_x31_2411, 3ULL, 2);
              v_x3_2414 = (g_heff_2ebuild_2edecoder_2etimes_24s1444395529x927023430(v_x_2412, v_s_240, v_j_2413));
              break;
            }
            default: heff_nomatch(v_x31_2411);
            }
            break;
          }
          default: heff_nomatch(v_x3_2410);
          }
          switch (heff_tag_of(v_x3_2414)) {
          case TAG_Nothing: {
            heff_drop_cell(v_ru_24x3_242_24Just, 1);
            heff_drop(v_x_244);
            heff_drop_cell(v_ru_24x31_243_24MkPair, 2);
            heff_drop(v_x_248);
            return NTAG(TAG_Nothing);
          }
          case TAG_Just: {
            V v_x31_2415 = heff_field(v_x3_2414, 0);
            heff_take_n(v_x3_2414, 1ULL, 1);
            switch (heff_tag_of(v_x31_2415)) {
            case TAG_MkPair: {
              V v_x_2416 = heff_field(v_x31_2415, 0);
              V v_j_2417 = heff_field(v_x31_2415, 1);
              heff_take_n(v_x31_2415, 3ULL, 2);
              V v_t_2418 = heff_tag_at_n(v_ru_24x31_243_24MkPair, TAG_MkPair, 2, (V[]){heff_rec_n(3, shape_owner__ver__units, (V[]){v_x_244, v_x_248, v_x_2416}), v_j_2417});
              return heff_tag_at_n(v_ru_24x3_242_24Just, TAG_Just, 1, (V[]){v_t_2418});
            }
            default: return heff_nomatch(v_x31_2415);
            }
          }
          default: return heff_nomatch(v_x3_2414);
          }
        }
        default: return heff_nomatch(v_x31_247);
        }
      }
      default: return heff_nomatch(v_x3_246);
      }
    }
    default: return heff_nomatch(v_x31_243);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2ebackcache_2egroupD_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ebackcache_2egroupD(a[0], a[1]);
}
HEFF_LIT(g_heff_2ebuild_2ebackcache_2emadeOf_str0, 1, "j");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2emadeOf_str1, 1, "n");
V g_heff_2ebuild_2ebackcache_2emadeOf_lam0(V self, V *args);
Clo g_heff_2ebuild_2ebackcache_2emadeOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebackcache_2emadeOf_entry, 3, 0};

V g_heff_2ebuild_2ebackcache_2emadeOf(V v_x1_240, V v_z_241, V v_z_242) {
top: ;
  if (heff_strEq_c_lent(v_x1_240, ((V)&g_heff_2ebuild_2ebackcache_2emadeOf_str0), 2)) {
    heff_drop(v_x1_240);
    V v_x3_244 = (g_heff_2ebuild_2edecoder_2estr(heff_dup(v_z_241), v_z_242));
    switch (heff_tag_of(v_x3_244)) {
    case TAG_Nothing: {
      heff_drop(v_z_241);
      return NTAG(TAG_Nothing);
    }
    case TAG_Just: {
      V v_x31_245 = heff_field(v_x3_244, 0);
      V v_ru_24x3_244_24Just = heff_take_reuse_n(v_x3_244, 1ULL, 1);
      switch (heff_tag_of(v_x31_245)) {
      case TAG_MkPair: {
        V v_x_246 = heff_field(v_x31_245, 0);
        V v_j_247 = heff_field(v_x31_245, 1);
        V v_ru_24x31_245_24MkPair = heff_take_reuse_n(v_x31_245, 3ULL, 2);
        V v_x3_248 = (g_heff_2ebuild_2edecoder_2eint(heff_dup(v_z_241), v_j_247));
        V v_x3_2412;
        switch (heff_tag_of(v_x3_248)) {
        case TAG_Nothing: {
          heff_drop(v_z_241);
          v_x3_2412 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_Just: {
          V v_x31_249 = heff_field(v_x3_248, 0);
          heff_take_n(v_x3_248, 1ULL, 1);
          switch (heff_tag_of(v_x31_249)) {
          case TAG_MkPair: {
            V v_x_2410 = heff_field(v_x31_249, 0);
            V v_j_2411 = heff_field(v_x31_249, 1);
            heff_take_n(v_x31_249, 3ULL, 2);
            v_x3_2412 = (g_heff_2ebuild_2edecoder_2etimes_24s98296704x1684150820(v_x_2410, v_z_241, v_j_2411));
            break;
          }
          default: heff_nomatch(v_x31_249);
          }
          break;
        }
        default: heff_nomatch(v_x3_248);
        }
        switch (heff_tag_of(v_x3_2412)) {
        case TAG_Nothing: {
          heff_drop_cell(v_ru_24x3_244_24Just, 1);
          heff_drop(v_x_246);
          heff_drop_cell(v_ru_24x31_245_24MkPair, 2);
          return NTAG(TAG_Nothing);
        }
        case TAG_Just: {
          V v_x31_2413 = heff_field(v_x3_2412, 0);
          V v_ru_24x3_2412_24Just = heff_take_reuse_n(v_x3_2412, 1ULL, 1);
          switch (heff_tag_of(v_x31_2413)) {
          case TAG_MkPair: {
            V v_x_2414 = heff_field(v_x31_2413, 0);
            V v_j_2415 = heff_field(v_x31_2413, 1);
            heff_take_n(v_x31_2413, 3ULL, 2);
            V v_t_2421 = heff_tag_at_n(v_ru_24x3_244_24Just, TAG_Just, 1, (V[]){heff_rec_n(2, shape_body__touched, (V[]){heff_clo_n(g_heff_2ebuild_2ebackcache_2emadeOf_lam0, 1, 1, (V[]){v_x_246}), v_x_2414})});
            return heff_tag_at_n(v_ru_24x3_2412_24Just, TAG_Just, 1, (V[]){heff_tag_at_n(v_ru_24x31_245_24MkPair, TAG_MkPair, 2, (V[]){v_t_2421, v_j_2415})});
          }
          default: return heff_nomatch(v_x31_2413);
          }
        }
        default: return heff_nomatch(v_x3_2412);
        }
      }
      default: return heff_nomatch(v_x31_245);
      }
    }
    default: return heff_nomatch(v_x3_244);
    }
  } else {
    if (heff_strEq_c(v_x1_240, ((V)&g_heff_2ebuild_2ebackcache_2emadeOf_str1))) {
      heff_drop(v_z_241);
      V v_t_2423 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_z_242});
      return heff_tag_n(TAG_Just, 1, (V[]){v_t_2423});
    } else {
      return ({ V a_0 = v_z_241; V a_1 = v_z_242; V r_ = (g_heff_2ebuild_2edecoder_2efail(a_0, a_1)); heff_drop(v_z_241); heff_drop(v_z_242); r_; });
    }
  }
}
V g_heff_2ebuild_2ebackcache_2emadeOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ebackcache_2emadeOf(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2ebackcache_2emadeOf_lam0(V self, V *args) {
  V v_u_2416 = args[0];
  V v_x_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2416);
  V v_x1_2417 = (g_heff_2ebuild_2edecoder_2ewhole(heff_dup(g_heff_2ecompile_2eirtext_2etakeExpr_get()), v_x_246, MK_INT(0LL)));
  switch (heff_tag_of(v_x1_2417)) {
  case TAG_Nothing: {
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_x11_2418 = heff_field(v_x1_2417, 0);
    V v_ru_24x1_2417_24Just = heff_take_reuse_n(v_x1_2417, 1ULL, 1);
    switch (heff_tag_of(v_x11_2418)) {
    case TAG_MkPair: {
      V v_x_2419 = heff_field(v_x11_2418, 0);
      heff_take_n(v_x11_2418, 1ULL, 2);
      return heff_tag_at_n(v_ru_24x1_2417_24Just, TAG_Just, 1, (V[]){v_x_2419});
    }
    default: return heff_nomatch(v_x11_2418);
    }
  }
  default: return heff_nomatch(v_x1_2417);
  }
}
V g_heff_2ebuild_2ebackcache_2ecopyD_lam1(V self, V *args);
V g_heff_2ebuild_2ebackcache_2ecopyD_lam0(V self, V *args);
Clo g_heff_2ebuild_2ebackcache_2ecopyD_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebackcache_2ecopyD_entry, 2, 0};

V g_heff_2ebuild_2ebackcache_2ecopyD(V v_s_240, V v_i_241) {
top: ;
  V v_x3_242 = (g_heff_2ebuild_2edecoder_2estr(heff_dup(v_s_240), v_i_241));
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nothing: {
    heff_drop(v_s_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_x31_243 = heff_field(v_x3_242, 0);
    heff_take_n(v_x3_242, 1ULL, 1);
    switch (heff_tag_of(v_x31_243)) {
    case TAG_MkPair: {
      V v_x_244 = heff_field(v_x31_243, 0);
      V v_j_245 = heff_field(v_x31_243, 1);
      heff_take_n(v_x31_243, 3ULL, 2);
      V v_x3_246 = (g_heff_2ebuild_2edecoder_2estr(heff_dup(v_s_240), v_j_245));
      switch (heff_tag_of(v_x3_246)) {
      case TAG_Nothing: {
        heff_drop(v_s_240);
        heff_drop(v_x_244);
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_x31_247 = heff_field(v_x3_246, 0);
        heff_take_n(v_x3_246, 1ULL, 1);
        switch (heff_tag_of(v_x31_247)) {
        case TAG_MkPair: {
          V v_x_248 = heff_field(v_x31_247, 0);
          V v_j_249 = heff_field(v_x31_247, 1);
          heff_take_n(v_x31_247, 3ULL, 2);
          V v_x3_2410 = (g_heff_2ebuild_2edecoder_2estr(heff_dup(v_s_240), v_j_249));
          switch (heff_tag_of(v_x3_2410)) {
          case TAG_Nothing: {
            heff_drop(v_s_240);
            heff_drop(v_x_244);
            heff_drop(v_x_248);
            return NTAG(TAG_Nothing);
          }
          case TAG_Just: {
            V v_x31_2411 = heff_field(v_x3_2410, 0);
            heff_take_n(v_x3_2410, 1ULL, 1);
            switch (heff_tag_of(v_x31_2411)) {
            case TAG_MkPair: {
              V v_x_2412 = heff_field(v_x31_2411, 0);
              V v_j_2413 = heff_field(v_x31_2411, 1);
              heff_take_n(v_x31_2411, 3ULL, 2);
              V v_x3_2414 = (g_heff_2ebuild_2edecoder_2eint(heff_dup(v_s_240), v_j_2413));
              switch (heff_tag_of(v_x3_2414)) {
              case TAG_Nothing: {
                heff_drop(v_s_240);
                heff_drop(v_x_244);
                heff_drop(v_x_248);
                heff_drop(v_x_2412);
                return NTAG(TAG_Nothing);
              }
              case TAG_Just: {
                V v_x31_2415 = heff_field(v_x3_2414, 0);
                heff_take_n(v_x3_2414, 1ULL, 1);
                switch (heff_tag_of(v_x31_2415)) {
                case TAG_MkPair: {
                  V v_x_2416 = heff_field(v_x31_2415, 0);
                  V v_j_2417 = heff_field(v_x31_2415, 1);
                  heff_take_n(v_x31_2415, 3ULL, 2);
                  return (g_heff_2ebuild_2edecoder_2ebind_24s823677936x1444069277(heff_clo_n(g_heff_2ebuild_2ebackcache_2ecopyD_lam0, 3, 4, (V[]){v_x_244, v_x_248, v_x_2412, v_x_2416}), v_s_240, v_j_2417));
                }
                default: return heff_nomatch(v_x31_2415);
                }
              }
              default: return heff_nomatch(v_x3_2414);
              }
            }
            default: return heff_nomatch(v_x31_2411);
            }
          }
          default: return heff_nomatch(v_x3_2410);
          }
        }
        default: return heff_nomatch(v_x31_247);
        }
      }
      default: return heff_nomatch(v_x3_246);
      }
    }
    default: return heff_nomatch(v_x31_243);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2ebackcache_2ecopyD_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ebackcache_2ecopyD(a[0], a[1]);
}
V g_heff_2ebuild_2ebackcache_2ecopyD_lam1(V self, V *args) {
  V v_u_2429 = args[0];
  V v_x_2412 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2429);
  V v_x1_2430 = (g_heff_2ebuild_2edecoder_2ewhole(heff_dup(g_heff_2ecompile_2eirtext_2etakeExpr_get()), v_x_2412, MK_INT(0LL)));
  switch (heff_tag_of(v_x1_2430)) {
  case TAG_Nothing: {
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_x11_2431 = heff_field(v_x1_2430, 0);
    V v_ru_24x1_2430_24Just = heff_take_reuse_n(v_x1_2430, 1ULL, 1);
    switch (heff_tag_of(v_x11_2431)) {
    case TAG_MkPair: {
      V v_x_2432 = heff_field(v_x11_2431, 0);
      heff_take_n(v_x11_2431, 1ULL, 2);
      return heff_tag_at_n(v_ru_24x1_2430_24Just, TAG_Just, 1, (V[]){v_x_2432});
    }
    default: return heff_nomatch(v_x11_2431);
    }
  }
  default: return heff_nomatch(v_x1_2430);
  }
}
V g_heff_2ebuild_2ebackcache_2ecopyD_lam0(V self, V *args) {
  V v_safe_2418 = args[0];
  V v_s_2419 = args[1];
  V v_i_2420 = args[2];
  V v_x_244 = heff_env(self)[0];
  V v_x_248 = heff_env(self)[1];
  V v_x_2412 = heff_env(self)[2];
  V v_x_2416 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x3_2421 = (g_heff_2ebuild_2edecoder_2eword(heff_dup(v_s_2419), v_i_2420));
  V v_x3_2425;
  switch (heff_tag_of(v_x3_2421)) {
  case TAG_Nothing: {
    heff_drop(v_s_2419);
    v_x3_2425 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Just: {
    V v_x31_2422 = heff_field(v_x3_2421, 0);
    heff_take_n(v_x3_2421, 1ULL, 1);
    switch (heff_tag_of(v_x31_2422)) {
    case TAG_MkPair: {
      V v_x_2423 = heff_field(v_x31_2422, 0);
      V v_j_2424 = heff_field(v_x31_2422, 1);
      heff_take_n(v_x31_2422, 3ULL, 2);
      v_x3_2425 = (g_heff_2ebuild_2ebackcache_2emadeOf(v_x_2423, v_s_2419, v_j_2424));
      break;
    }
    default: heff_nomatch(v_x31_2422);
    }
    break;
  }
  default: heff_nomatch(v_x3_2421);
  }
  switch (heff_tag_of(v_x3_2425)) {
  case TAG_Nothing: {
    heff_drop(v_safe_2418);
    heff_drop(v_x_244);
    heff_drop(v_x_248);
    heff_drop(v_x_2412);
    heff_drop(v_x_2416);
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_x31_2426 = heff_field(v_x3_2425, 0);
    V v_ru_24x3_2425_24Just = heff_take_reuse_n(v_x3_2425, 1ULL, 1);
    switch (heff_tag_of(v_x31_2426)) {
    case TAG_MkPair: {
      V v_x_2427 = heff_field(v_x31_2426, 0);
      V v_j_2428 = heff_field(v_x31_2426, 1);
      V v_ru_24x31_2426_24MkPair = heff_take_reuse_n(v_x31_2426, 3ULL, 2);
      V v_t_2434 = heff_tag_at_n(v_ru_24x31_2426_24MkPair, TAG_MkPair, 2, (V[]){v_x_244, heff_rec_n(5, shape_ver__recipe__depth__safe__made, (V[]){v_x_248, heff_clo_n(g_heff_2ebuild_2ebackcache_2ecopyD_lam1, 1, 1, (V[]){v_x_2412}), v_x_2416, v_safe_2418, v_x_2427})});
      return heff_tag_at_n(v_ru_24x3_2425_24Just, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2434, v_j_2428})});
    }
    default: return heff_nomatch(v_x31_2426);
    }
  }
  default: return heff_nomatch(v_x3_2425);
  }
}
Clo g_heff_2ebuild_2ebackcache_2eemitD_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebackcache_2eemitD_entry, 2, 0};

V g_heff_2ebuild_2ebackcache_2eemitD(V v_s_240, V v_i_241) {
top: ;
  V v_x3_242 = (g_heff_2ebuild_2edecoder_2estr(heff_dup(v_s_240), v_i_241));
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nothing: {
    heff_drop(v_s_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_x31_243 = heff_field(v_x3_242, 0);
    V v_ru_24x3_242_24Just = heff_take_reuse_n(v_x3_242, 1ULL, 1);
    switch (heff_tag_of(v_x31_243)) {
    case TAG_MkPair: {
      V v_x_244 = heff_field(v_x31_243, 0);
      V v_j_245 = heff_field(v_x31_243, 1);
      V v_ru_24x31_243_24MkPair = heff_take_reuse_n(v_x31_243, 3ULL, 2);
      V v_x3_246 = (g_heff_2ebuild_2edecoder_2estr(heff_dup(v_s_240), v_j_245));
      switch (heff_tag_of(v_x3_246)) {
      case TAG_Nothing: {
        heff_drop(v_s_240);
        heff_drop_cell(v_ru_24x3_242_24Just, 1);
        heff_drop(v_x_244);
        heff_drop_cell(v_ru_24x31_243_24MkPair, 2);
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_x31_247 = heff_field(v_x3_246, 0);
        heff_take_n(v_x3_246, 1ULL, 1);
        switch (heff_tag_of(v_x31_247)) {
        case TAG_MkPair: {
          V v_x_248 = heff_field(v_x31_247, 0);
          V v_j_249 = heff_field(v_x31_247, 1);
          heff_take_n(v_x31_247, 3ULL, 2);
          V v_x3_2410 = (g_heff_2ebuild_2edecoder_2eint(heff_dup(v_s_240), v_j_249));
          V v_x3_2414;
          switch (heff_tag_of(v_x3_2410)) {
          case TAG_Nothing: {
            v_x3_2414 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_Just: {
            V v_x31_2411 = heff_field(v_x3_2410, 0);
            heff_take_n(v_x3_2410, 1ULL, 1);
            switch (heff_tag_of(v_x31_2411)) {
            case TAG_MkPair: {
              V v_x_2412 = heff_field(v_x31_2411, 0);
              V v_j_2413 = heff_field(v_x31_2411, 1);
              heff_take_n(v_x31_2411, 3ULL, 2);
              v_x3_2414 = (g_heff_2ebuild_2edecoder_2etimes_24s1603230686x1883420273(v_x_2412, heff_dup(v_s_240), v_j_2413));
              break;
            }
            default: heff_nomatch(v_x31_2411);
            }
            break;
          }
          default: heff_nomatch(v_x3_2410);
          }
          switch (heff_tag_of(v_x3_2414)) {
          case TAG_Nothing: {
            heff_drop(v_s_240);
            heff_drop_cell(v_ru_24x3_242_24Just, 1);
            heff_drop(v_x_244);
            heff_drop_cell(v_ru_24x31_243_24MkPair, 2);
            heff_drop(v_x_248);
            return NTAG(TAG_Nothing);
          }
          case TAG_Just: {
            V v_x31_2415 = heff_field(v_x3_2414, 0);
            heff_take_n(v_x3_2414, 1ULL, 1);
            switch (heff_tag_of(v_x31_2415)) {
            case TAG_MkPair: {
              V v_x_2416 = heff_field(v_x31_2415, 0);
              V v_j_2417 = heff_field(v_x31_2415, 1);
              heff_take_n(v_x31_2415, 3ULL, 2);
              V v_x3_2418 = (g_heff_2ebuild_2edecoder_2eint(heff_dup(v_s_240), v_j_2417));
              V v_x3_2422;
              switch (heff_tag_of(v_x3_2418)) {
              case TAG_Nothing: {
                v_x3_2422 = NTAG(TAG_Nothing);
                break;
              }
              case TAG_Just: {
                V v_x31_2419 = heff_field(v_x3_2418, 0);
                heff_take_n(v_x3_2418, 1ULL, 1);
                switch (heff_tag_of(v_x31_2419)) {
                case TAG_MkPair: {
                  V v_x_2420 = heff_field(v_x31_2419, 0);
                  V v_j_2421 = heff_field(v_x31_2419, 1);
                  heff_take_n(v_x31_2419, 3ULL, 2);
                  v_x3_2422 = (g_heff_2ebuild_2edecoder_2etimes_24s1603230686x1883420273(v_x_2420, heff_dup(v_s_240), v_j_2421));
                  break;
                }
                default: heff_nomatch(v_x31_2419);
                }
                break;
              }
              default: heff_nomatch(v_x3_2418);
              }
              switch (heff_tag_of(v_x3_2422)) {
              case TAG_Nothing: {
                heff_drop(v_s_240);
                heff_drop_cell(v_ru_24x3_242_24Just, 1);
                heff_drop(v_x_244);
                heff_drop_cell(v_ru_24x31_243_24MkPair, 2);
                heff_drop(v_x_248);
                heff_drop(v_x_2416);
                return NTAG(TAG_Nothing);
              }
              case TAG_Just: {
                V v_x31_2423 = heff_field(v_x3_2422, 0);
                heff_take_n(v_x3_2422, 1ULL, 1);
                switch (heff_tag_of(v_x31_2423)) {
                case TAG_MkPair: {
                  V v_x_2424 = heff_field(v_x31_2423, 0);
                  V v_j_2425 = heff_field(v_x31_2423, 1);
                  heff_take_n(v_x31_2423, 3ULL, 2);
                  V v_x3_2426 = (g_heff_2ebuild_2edecoder_2eint(heff_dup(v_s_240), v_j_2425));
                  V v_x3_2430;
                  switch (heff_tag_of(v_x3_2426)) {
                  case TAG_Nothing: {
                    v_x3_2430 = NTAG(TAG_Nothing);
                    break;
                  }
                  case TAG_Just: {
                    V v_x31_2427 = heff_field(v_x3_2426, 0);
                    heff_take_n(v_x3_2426, 1ULL, 1);
                    switch (heff_tag_of(v_x31_2427)) {
                    case TAG_MkPair: {
                      V v_x_2428 = heff_field(v_x31_2427, 0);
                      V v_j_2429 = heff_field(v_x31_2427, 1);
                      heff_take_n(v_x31_2427, 3ULL, 2);
                      v_x3_2430 = (g_heff_2ebuild_2edecoder_2etimes_24s1603230686x1883420273(v_x_2428, heff_dup(v_s_240), v_j_2429));
                      break;
                    }
                    default: heff_nomatch(v_x31_2427);
                    }
                    break;
                  }
                  default: heff_nomatch(v_x3_2426);
                  }
                  switch (heff_tag_of(v_x3_2430)) {
                  case TAG_Nothing: {
                    heff_drop(v_s_240);
                    heff_drop_cell(v_ru_24x3_242_24Just, 1);
                    heff_drop(v_x_244);
                    heff_drop_cell(v_ru_24x31_243_24MkPair, 2);
                    heff_drop(v_x_248);
                    heff_drop(v_x_2416);
                    heff_drop(v_x_2424);
                    return NTAG(TAG_Nothing);
                  }
                  case TAG_Just: {
                    V v_x31_2431 = heff_field(v_x3_2430, 0);
                    heff_take_n(v_x3_2430, 1ULL, 1);
                    switch (heff_tag_of(v_x31_2431)) {
                    case TAG_MkPair: {
                      V v_x_2432 = heff_field(v_x31_2431, 0);
                      V v_j_2433 = heff_field(v_x31_2431, 1);
                      heff_take_n(v_x31_2431, 3ULL, 2);
                      V v_x3_2434 = (g_heff_2ebuild_2edecoder_2eint(heff_dup(v_s_240), v_j_2433));
                      V v_x3_2438;
                      switch (heff_tag_of(v_x3_2434)) {
                      case TAG_Nothing: {
                        v_x3_2438 = NTAG(TAG_Nothing);
                        break;
                      }
                      case TAG_Just: {
                        V v_x31_2435 = heff_field(v_x3_2434, 0);
                        heff_take_n(v_x3_2434, 1ULL, 1);
                        switch (heff_tag_of(v_x31_2435)) {
                        case TAG_MkPair: {
                          V v_x_2436 = heff_field(v_x31_2435, 0);
                          V v_j_2437 = heff_field(v_x31_2435, 1);
                          heff_take_n(v_x31_2435, 3ULL, 2);
                          v_x3_2438 = (g_heff_2ebuild_2edecoder_2etimes_24s1603230686x1883420273(v_x_2436, heff_dup(v_s_240), v_j_2437));
                          break;
                        }
                        default: heff_nomatch(v_x31_2435);
                        }
                        break;
                      }
                      default: heff_nomatch(v_x3_2434);
                      }
                      switch (heff_tag_of(v_x3_2438)) {
                      case TAG_Nothing: {
                        heff_drop(v_s_240);
                        heff_drop_cell(v_ru_24x3_242_24Just, 1);
                        heff_drop(v_x_244);
                        heff_drop_cell(v_ru_24x31_243_24MkPair, 2);
                        heff_drop(v_x_248);
                        heff_drop(v_x_2416);
                        heff_drop(v_x_2424);
                        heff_drop(v_x_2432);
                        return NTAG(TAG_Nothing);
                      }
                      case TAG_Just: {
                        V v_x31_2439 = heff_field(v_x3_2438, 0);
                        heff_take_n(v_x3_2438, 1ULL, 1);
                        switch (heff_tag_of(v_x31_2439)) {
                        case TAG_MkPair: {
                          V v_x_2440 = heff_field(v_x31_2439, 0);
                          V v_j_2441 = heff_field(v_x31_2439, 1);
                          heff_take_n(v_x31_2439, 3ULL, 2);
                          V v_x3_2442 = (g_heff_2ebuild_2edecoder_2eint(heff_dup(v_s_240), v_j_2441));
                          V v_x3_2446;
                          switch (heff_tag_of(v_x3_2442)) {
                          case TAG_Nothing: {
                            v_x3_2446 = NTAG(TAG_Nothing);
                            break;
                          }
                          case TAG_Just: {
                            V v_x31_2443 = heff_field(v_x3_2442, 0);
                            heff_take_n(v_x3_2442, 1ULL, 1);
                            switch (heff_tag_of(v_x31_2443)) {
                            case TAG_MkPair: {
                              V v_x_2444 = heff_field(v_x31_2443, 0);
                              V v_j_2445 = heff_field(v_x31_2443, 1);
                              heff_take_n(v_x31_2443, 3ULL, 2);
                              v_x3_2446 = (g_heff_2ebuild_2edecoder_2etimes_24s1603230686x1883420273(v_x_2444, heff_dup(v_s_240), v_j_2445));
                              break;
                            }
                            default: heff_nomatch(v_x31_2443);
                            }
                            break;
                          }
                          default: heff_nomatch(v_x3_2442);
                          }
                          switch (heff_tag_of(v_x3_2446)) {
                          case TAG_Nothing: {
                            heff_drop(v_s_240);
                            heff_drop_cell(v_ru_24x3_242_24Just, 1);
                            heff_drop(v_x_244);
                            heff_drop_cell(v_ru_24x31_243_24MkPair, 2);
                            heff_drop(v_x_248);
                            heff_drop(v_x_2416);
                            heff_drop(v_x_2424);
                            heff_drop(v_x_2432);
                            heff_drop(v_x_2440);
                            return NTAG(TAG_Nothing);
                          }
                          case TAG_Just: {
                            V v_x31_2447 = heff_field(v_x3_2446, 0);
                            heff_take_n(v_x3_2446, 1ULL, 1);
                            switch (heff_tag_of(v_x31_2447)) {
                            case TAG_MkPair: {
                              V v_x_2448 = heff_field(v_x31_2447, 0);
                              V v_j_2449 = heff_field(v_x31_2447, 1);
                              heff_take_n(v_x31_2447, 3ULL, 2);
                              V v_x3_2450 = (g_heff_2ebuild_2edecoder_2eint(heff_dup(v_s_240), v_j_2449));
                              V v_x3_2454;
                              switch (heff_tag_of(v_x3_2450)) {
                              case TAG_Nothing: {
                                v_x3_2454 = NTAG(TAG_Nothing);
                                break;
                              }
                              case TAG_Just: {
                                V v_x31_2451 = heff_field(v_x3_2450, 0);
                                heff_take_n(v_x3_2450, 1ULL, 1);
                                switch (heff_tag_of(v_x31_2451)) {
                                case TAG_MkPair: {
                                  V v_x_2452 = heff_field(v_x31_2451, 0);
                                  V v_j_2453 = heff_field(v_x31_2451, 1);
                                  heff_take_n(v_x31_2451, 3ULL, 2);
                                  v_x3_2454 = (g_heff_2ebuild_2edecoder_2etimes_24s1603230686x1883420273(v_x_2452, heff_dup(v_s_240), v_j_2453));
                                  break;
                                }
                                default: heff_nomatch(v_x31_2451);
                                }
                                break;
                              }
                              default: heff_nomatch(v_x3_2450);
                              }
                              switch (heff_tag_of(v_x3_2454)) {
                              case TAG_Nothing: {
                                heff_drop(v_s_240);
                                heff_drop_cell(v_ru_24x3_242_24Just, 1);
                                heff_drop(v_x_244);
                                heff_drop_cell(v_ru_24x31_243_24MkPair, 2);
                                heff_drop(v_x_248);
                                heff_drop(v_x_2416);
                                heff_drop(v_x_2424);
                                heff_drop(v_x_2432);
                                heff_drop(v_x_2440);
                                heff_drop(v_x_2448);
                                return NTAG(TAG_Nothing);
                              }
                              case TAG_Just: {
                                V v_x31_2455 = heff_field(v_x3_2454, 0);
                                heff_take_n(v_x3_2454, 1ULL, 1);
                                switch (heff_tag_of(v_x31_2455)) {
                                case TAG_MkPair: {
                                  V v_x_2456 = heff_field(v_x31_2455, 0);
                                  V v_j_2457 = heff_field(v_x31_2455, 1);
                                  heff_take_n(v_x31_2455, 3ULL, 2);
                                  V v_x3_2458 = (g_heff_2ebuild_2edecoder_2eint(heff_dup(v_s_240), v_j_2457));
                                  V v_x3_2462;
                                  switch (heff_tag_of(v_x3_2458)) {
                                  case TAG_Nothing: {
                                    heff_drop(v_s_240);
                                    v_x3_2462 = NTAG(TAG_Nothing);
                                    break;
                                  }
                                  case TAG_Just: {
                                    V v_x31_2459 = heff_field(v_x3_2458, 0);
                                    heff_take_n(v_x3_2458, 1ULL, 1);
                                    switch (heff_tag_of(v_x31_2459)) {
                                    case TAG_MkPair: {
                                      V v_x_2460 = heff_field(v_x31_2459, 0);
                                      V v_j_2461 = heff_field(v_x31_2459, 1);
                                      heff_take_n(v_x31_2459, 3ULL, 2);
                                      v_x3_2462 = (g_heff_2ebuild_2edecoder_2etimes_24s1603230686x1883420273(v_x_2460, v_s_240, v_j_2461));
                                      break;
                                    }
                                    default: heff_nomatch(v_x31_2459);
                                    }
                                    break;
                                  }
                                  default: heff_nomatch(v_x3_2458);
                                  }
                                  switch (heff_tag_of(v_x3_2462)) {
                                  case TAG_Nothing: {
                                    heff_drop_cell(v_ru_24x3_242_24Just, 1);
                                    heff_drop(v_x_244);
                                    heff_drop_cell(v_ru_24x31_243_24MkPair, 2);
                                    heff_drop(v_x_248);
                                    heff_drop(v_x_2416);
                                    heff_drop(v_x_2424);
                                    heff_drop(v_x_2432);
                                    heff_drop(v_x_2440);
                                    heff_drop(v_x_2448);
                                    heff_drop(v_x_2456);
                                    return NTAG(TAG_Nothing);
                                  }
                                  case TAG_Just: {
                                    V v_x31_2463 = heff_field(v_x3_2462, 0);
                                    heff_take_n(v_x3_2462, 1ULL, 1);
                                    switch (heff_tag_of(v_x31_2463)) {
                                    case TAG_MkPair: {
                                      V v_x_2464 = heff_field(v_x31_2463, 0);
                                      V v_j_2465 = heff_field(v_x31_2463, 1);
                                      heff_take_n(v_x31_2463, 3ULL, 2);
                                      V v_t_2466 = heff_tag_at_n(v_ru_24x31_243_24MkPair, TAG_MkPair, 2, (V[]){v_x_244, heff_rec_n(8, shape_ver__protos__code__strs__lprotos__lams__shapes__prims, (V[]){v_x_248, v_x_2416, v_x_2424, v_x_2432, v_x_2440, v_x_2448, v_x_2456, v_x_2464})});
                                      return heff_tag_at_n(v_ru_24x3_242_24Just, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2466, v_j_2465})});
                                    }
                                    default: return heff_nomatch(v_x31_2463);
                                    }
                                  }
                                  default: return heff_nomatch(v_x3_2462);
                                  }
                                }
                                default: return heff_nomatch(v_x31_2455);
                                }
                              }
                              default: return heff_nomatch(v_x3_2454);
                              }
                            }
                            default: return heff_nomatch(v_x31_2447);
                            }
                          }
                          default: return heff_nomatch(v_x3_2446);
                          }
                        }
                        default: return heff_nomatch(v_x31_2439);
                        }
                      }
                      default: return heff_nomatch(v_x3_2438);
                      }
                    }
                    default: return heff_nomatch(v_x31_2431);
                    }
                  }
                  default: return heff_nomatch(v_x3_2430);
                  }
                }
                default: return heff_nomatch(v_x31_2423);
                }
              }
              default: return heff_nomatch(v_x3_2422);
              }
            }
            default: return heff_nomatch(v_x31_2415);
            }
          }
          default: return heff_nomatch(v_x3_2414);
          }
        }
        default: return heff_nomatch(v_x31_247);
        }
      }
      default: return heff_nomatch(v_x3_246);
      }
    }
    default: return heff_nomatch(v_x31_243);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2ebackcache_2eemitD_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ebackcache_2eemitD(a[0], a[1]);
}
Clo g_heff_2ebuild_2ebackcache_2ejsD_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebackcache_2ejsD_entry, 2, 0};

V g_heff_2ebuild_2ebackcache_2ejsD(V v_s_240, V v_i_241) {
top: ;
  V v_x3_242 = (g_heff_2ebuild_2edecoder_2estr(heff_dup(v_s_240), v_i_241));
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nothing: {
    heff_drop(v_s_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_x31_243 = heff_field(v_x3_242, 0);
    V v_ru_24x3_242_24Just = heff_take_reuse_n(v_x3_242, 1ULL, 1);
    switch (heff_tag_of(v_x31_243)) {
    case TAG_MkPair: {
      V v_x_244 = heff_field(v_x31_243, 0);
      V v_j_245 = heff_field(v_x31_243, 1);
      V v_ru_24x31_243_24MkPair = heff_take_reuse_n(v_x31_243, 3ULL, 2);
      V v_x3_246 = (g_heff_2ebuild_2edecoder_2estr(heff_dup(v_s_240), v_j_245));
      switch (heff_tag_of(v_x3_246)) {
      case TAG_Nothing: {
        heff_drop(v_s_240);
        heff_drop_cell(v_ru_24x3_242_24Just, 1);
        heff_drop(v_x_244);
        heff_drop_cell(v_ru_24x31_243_24MkPair, 2);
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_x31_247 = heff_field(v_x3_246, 0);
        heff_take_n(v_x3_246, 1ULL, 1);
        switch (heff_tag_of(v_x31_247)) {
        case TAG_MkPair: {
          V v_x_248 = heff_field(v_x31_247, 0);
          V v_j_249 = heff_field(v_x31_247, 1);
          heff_take_n(v_x31_247, 3ULL, 2);
          V v_x3_2410 = (g_heff_2ebuild_2edecoder_2eint(heff_dup(v_s_240), v_j_249));
          V v_x3_2414;
          switch (heff_tag_of(v_x3_2410)) {
          case TAG_Nothing: {
            v_x3_2414 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_Just: {
            V v_x31_2411 = heff_field(v_x3_2410, 0);
            heff_take_n(v_x3_2410, 1ULL, 1);
            switch (heff_tag_of(v_x31_2411)) {
            case TAG_MkPair: {
              V v_x_2412 = heff_field(v_x31_2411, 0);
              V v_j_2413 = heff_field(v_x31_2411, 1);
              heff_take_n(v_x31_2411, 3ULL, 2);
              v_x3_2414 = (g_heff_2ebuild_2edecoder_2etimes_24s1603230686x1883420273(v_x_2412, heff_dup(v_s_240), v_j_2413));
              break;
            }
            default: heff_nomatch(v_x31_2411);
            }
            break;
          }
          default: heff_nomatch(v_x3_2410);
          }
          switch (heff_tag_of(v_x3_2414)) {
          case TAG_Nothing: {
            heff_drop(v_s_240);
            heff_drop_cell(v_ru_24x3_242_24Just, 1);
            heff_drop(v_x_244);
            heff_drop_cell(v_ru_24x31_243_24MkPair, 2);
            heff_drop(v_x_248);
            return NTAG(TAG_Nothing);
          }
          case TAG_Just: {
            V v_x31_2415 = heff_field(v_x3_2414, 0);
            heff_take_n(v_x3_2414, 1ULL, 1);
            switch (heff_tag_of(v_x31_2415)) {
            case TAG_MkPair: {
              V v_x_2416 = heff_field(v_x31_2415, 0);
              V v_j_2417 = heff_field(v_x31_2415, 1);
              heff_take_n(v_x31_2415, 3ULL, 2);
              V v_x3_2418 = (g_heff_2ebuild_2edecoder_2eint(heff_dup(v_s_240), v_j_2417));
              V v_x3_2422;
              switch (heff_tag_of(v_x3_2418)) {
              case TAG_Nothing: {
                v_x3_2422 = NTAG(TAG_Nothing);
                break;
              }
              case TAG_Just: {
                V v_x31_2419 = heff_field(v_x3_2418, 0);
                heff_take_n(v_x3_2418, 1ULL, 1);
                switch (heff_tag_of(v_x31_2419)) {
                case TAG_MkPair: {
                  V v_x_2420 = heff_field(v_x31_2419, 0);
                  V v_j_2421 = heff_field(v_x31_2419, 1);
                  heff_take_n(v_x31_2419, 3ULL, 2);
                  v_x3_2422 = (g_heff_2ebuild_2edecoder_2etimes_24s1603230686x1883420273(v_x_2420, heff_dup(v_s_240), v_j_2421));
                  break;
                }
                default: heff_nomatch(v_x31_2419);
                }
                break;
              }
              default: heff_nomatch(v_x3_2418);
              }
              switch (heff_tag_of(v_x3_2422)) {
              case TAG_Nothing: {
                heff_drop(v_s_240);
                heff_drop_cell(v_ru_24x3_242_24Just, 1);
                heff_drop(v_x_244);
                heff_drop_cell(v_ru_24x31_243_24MkPair, 2);
                heff_drop(v_x_248);
                heff_drop(v_x_2416);
                return NTAG(TAG_Nothing);
              }
              case TAG_Just: {
                V v_x31_2423 = heff_field(v_x3_2422, 0);
                heff_take_n(v_x3_2422, 1ULL, 1);
                switch (heff_tag_of(v_x31_2423)) {
                case TAG_MkPair: {
                  V v_x_2424 = heff_field(v_x31_2423, 0);
                  V v_j_2425 = heff_field(v_x31_2423, 1);
                  heff_take_n(v_x31_2423, 3ULL, 2);
                  V v_x3_2426 = (g_heff_2ebuild_2edecoder_2eint(heff_dup(v_s_240), v_j_2425));
                  V v_x3_2430;
                  switch (heff_tag_of(v_x3_2426)) {
                  case TAG_Nothing: {
                    v_x3_2430 = NTAG(TAG_Nothing);
                    break;
                  }
                  case TAG_Just: {
                    V v_x31_2427 = heff_field(v_x3_2426, 0);
                    heff_take_n(v_x3_2426, 1ULL, 1);
                    switch (heff_tag_of(v_x31_2427)) {
                    case TAG_MkPair: {
                      V v_x_2428 = heff_field(v_x31_2427, 0);
                      V v_j_2429 = heff_field(v_x31_2427, 1);
                      heff_take_n(v_x31_2427, 3ULL, 2);
                      v_x3_2430 = (g_heff_2ebuild_2edecoder_2etimes_24s1603230686x1883420273(v_x_2428, heff_dup(v_s_240), v_j_2429));
                      break;
                    }
                    default: heff_nomatch(v_x31_2427);
                    }
                    break;
                  }
                  default: heff_nomatch(v_x3_2426);
                  }
                  switch (heff_tag_of(v_x3_2430)) {
                  case TAG_Nothing: {
                    heff_drop(v_s_240);
                    heff_drop_cell(v_ru_24x3_242_24Just, 1);
                    heff_drop(v_x_244);
                    heff_drop_cell(v_ru_24x31_243_24MkPair, 2);
                    heff_drop(v_x_248);
                    heff_drop(v_x_2416);
                    heff_drop(v_x_2424);
                    return NTAG(TAG_Nothing);
                  }
                  case TAG_Just: {
                    V v_x31_2431 = heff_field(v_x3_2430, 0);
                    heff_take_n(v_x3_2430, 1ULL, 1);
                    switch (heff_tag_of(v_x31_2431)) {
                    case TAG_MkPair: {
                      V v_x_2432 = heff_field(v_x31_2431, 0);
                      V v_j_2433 = heff_field(v_x31_2431, 1);
                      heff_take_n(v_x31_2431, 3ULL, 2);
                      V v_x3_2434 = (g_heff_2ebuild_2edecoder_2eint(heff_dup(v_s_240), v_j_2433));
                      V v_x3_2438;
                      switch (heff_tag_of(v_x3_2434)) {
                      case TAG_Nothing: {
                        heff_drop(v_s_240);
                        v_x3_2438 = NTAG(TAG_Nothing);
                        break;
                      }
                      case TAG_Just: {
                        V v_x31_2435 = heff_field(v_x3_2434, 0);
                        heff_take_n(v_x3_2434, 1ULL, 1);
                        switch (heff_tag_of(v_x31_2435)) {
                        case TAG_MkPair: {
                          V v_x_2436 = heff_field(v_x31_2435, 0);
                          V v_j_2437 = heff_field(v_x31_2435, 1);
                          heff_take_n(v_x31_2435, 3ULL, 2);
                          v_x3_2438 = (g_heff_2ebuild_2edecoder_2etimes_24s1603230686x1883420273(v_x_2436, v_s_240, v_j_2437));
                          break;
                        }
                        default: heff_nomatch(v_x31_2435);
                        }
                        break;
                      }
                      default: heff_nomatch(v_x3_2434);
                      }
                      switch (heff_tag_of(v_x3_2438)) {
                      case TAG_Nothing: {
                        heff_drop_cell(v_ru_24x3_242_24Just, 1);
                        heff_drop(v_x_244);
                        heff_drop_cell(v_ru_24x31_243_24MkPair, 2);
                        heff_drop(v_x_248);
                        heff_drop(v_x_2416);
                        heff_drop(v_x_2424);
                        heff_drop(v_x_2432);
                        return NTAG(TAG_Nothing);
                      }
                      case TAG_Just: {
                        V v_x31_2439 = heff_field(v_x3_2438, 0);
                        heff_take_n(v_x3_2438, 1ULL, 1);
                        switch (heff_tag_of(v_x31_2439)) {
                        case TAG_MkPair: {
                          V v_x_2440 = heff_field(v_x31_2439, 0);
                          V v_j_2441 = heff_field(v_x31_2439, 1);
                          heff_take_n(v_x31_2439, 3ULL, 2);
                          V v_t_2442 = heff_tag_at_n(v_ru_24x31_243_24MkPair, TAG_MkPair, 2, (V[]){v_x_244, heff_rec_n(5, shape_ver__lines__params__refs__prims, (V[]){v_x_248, v_x_2416, v_x_2424, v_x_2432, v_x_2440})});
                          return heff_tag_at_n(v_ru_24x3_242_24Just, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2442, v_j_2441})});
                        }
                        default: return heff_nomatch(v_x31_2439);
                        }
                      }
                      default: return heff_nomatch(v_x3_2438);
                      }
                    }
                    default: return heff_nomatch(v_x31_2431);
                    }
                  }
                  default: return heff_nomatch(v_x3_2430);
                  }
                }
                default: return heff_nomatch(v_x31_2423);
                }
              }
              default: return heff_nomatch(v_x3_2422);
              }
            }
            default: return heff_nomatch(v_x31_2415);
            }
          }
          default: return heff_nomatch(v_x3_2414);
          }
        }
        default: return heff_nomatch(v_x31_247);
        }
      }
      default: return heff_nomatch(v_x3_246);
      }
    }
    default: return heff_nomatch(v_x31_243);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2ebackcache_2ejsD_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ebackcache_2ejsD(a[0], a[1]);
}

static V g_heff_2ebuild_2ebackcache_2enoBack_val;
static HEFF_ONCE g_heff_2ebuild_2ebackcache_2enoBack_st;
static V g_heff_2ebuild_2ebackcache_2enoBack_init(void) {
  return heff_rec_n(4, shape_groups__copies__emits__jss, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil)});
}
V g_heff_2ebuild_2ebackcache_2enoBack_get(void) {
  if (HEFF_DONE(g_heff_2ebuild_2ebackcache_2enoBack_st)) return g_heff_2ebuild_2ebackcache_2enoBack_val;
  return heff_global(&g_heff_2ebuild_2ebackcache_2enoBack_val, &g_heff_2ebuild_2ebackcache_2enoBack_st, g_heff_2ebuild_2ebackcache_2enoBack_init);
}
HEFF_LIT(g_heff_2ebuild_2ebackcache_2ebackD_str0, 3, "end");
Clo g_heff_2ebuild_2ebackcache_2ebackD_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebackcache_2ebackD_entry, 3, 0};

V g_heff_2ebuild_2ebackcache_2ebackD(V v_id_240, V v_s_241, V v_i_242) {
top: ;
  V v_x3_243 = (g_heff_2ebuild_2edecoder_2estr(heff_dup(v_s_241), v_i_242));
  V v_t_249;
  switch (heff_tag_of(v_x3_243)) {
  case TAG_Nothing: {
    v_t_249 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Just: {
    V v_x31_244 = heff_field(v_x3_243, 0);
    V v_ru_24x3_243_24Just = heff_take_reuse_n(v_x3_243, 1ULL, 1);
    switch (heff_tag_of(v_x31_244)) {
    case TAG_MkPair: {
      V v_x_245 = heff_field(v_x31_244, 0);
      V v_j_246 = heff_field(v_x31_244, 1);
      V v_ru_24x31_244_24MkPair = heff_take_reuse_n(v_x31_244, 3ULL, 2);
      if (heff_strEq_c(v_x_245, heff_dup(g_heff_2ebuild_2ebackcache_2eversion_get()))) {
        V v_t_248 = heff_tag_at_n(v_ru_24x31_244_24MkPair, TAG_MkPair, 2, (V[]){NTAG(TAG_MkUnit), v_j_246});
        v_t_249 = heff_tag_at_n(v_ru_24x3_243_24Just, TAG_Just, 1, (V[]){v_t_248});
      } else {
        heff_drop_cell(v_ru_24x3_243_24Just, 1);
        heff_drop(v_j_246);
        heff_drop_cell(v_ru_24x31_244_24MkPair, 2);
        v_t_249 = NTAG(TAG_Nothing);
      }
      break;
    }
    default: heff_nomatch(v_x31_244);
    }
    break;
  }
  default: heff_nomatch(v_x3_243);
  }
  switch (heff_tag_of(v_t_249)) {
  case TAG_Nothing: {
    heff_drop(v_id_240);
    heff_drop(v_s_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_x31_2410 = heff_field(v_t_249, 0);
    V v_ru_24t_249_24Just = heff_take_reuse_n(v_t_249, 1ULL, 1);
    switch (heff_tag_of(v_x31_2410)) {
    case TAG_MkPair: {
      V v_j_2412 = heff_field(v_x31_2410, 1);
      V v_ru_24x31_2410_24MkPair = heff_take_reuse_n(v_x31_2410, 2ULL, 2);
      V v_x3_2413 = (g_heff_2ebuild_2edecoder_2estr(heff_dup(v_s_241), v_j_2412));
      V v_t_2419;
      switch (heff_tag_of(v_x3_2413)) {
      case TAG_Nothing: {
        heff_drop(v_id_240);
        heff_drop_cell(v_ru_24t_249_24Just, 1);
        heff_drop_cell(v_ru_24x31_2410_24MkPair, 2);
        v_t_2419 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Just: {
        V v_x31_2414 = heff_field(v_x3_2413, 0);
        heff_take_n(v_x3_2413, 1ULL, 1);
        switch (heff_tag_of(v_x31_2414)) {
        case TAG_MkPair: {
          V v_x_2415 = heff_field(v_x31_2414, 0);
          V v_j_2416 = heff_field(v_x31_2414, 1);
          heff_take_n(v_x31_2414, 3ULL, 2);
          if (heff_strEq_c(v_x_2415, v_id_240)) {
            V v_t_2418 = heff_tag_at_n(v_ru_24x31_2410_24MkPair, TAG_MkPair, 2, (V[]){NTAG(TAG_MkUnit), v_j_2416});
            v_t_2419 = heff_tag_at_n(v_ru_24t_249_24Just, TAG_Just, 1, (V[]){v_t_2418});
          } else {
            heff_drop_cell(v_ru_24t_249_24Just, 1);
            heff_drop_cell(v_ru_24x31_2410_24MkPair, 2);
            heff_drop(v_j_2416);
            v_t_2419 = NTAG(TAG_Nothing);
          }
          break;
        }
        default: heff_nomatch(v_x31_2414);
        }
        break;
      }
      default: heff_nomatch(v_x3_2413);
      }
      switch (heff_tag_of(v_t_2419)) {
      case TAG_Nothing: {
        heff_drop(v_s_241);
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_x31_2420 = heff_field(v_t_2419, 0);
        V v_ru_24t_2419_24Just = heff_take_reuse_n(v_t_2419, 1ULL, 1);
        switch (heff_tag_of(v_x31_2420)) {
        case TAG_MkPair: {
          V v_j_2422 = heff_field(v_x31_2420, 1);
          V v_ru_24x31_2420_24MkPair = heff_take_reuse_n(v_x31_2420, 2ULL, 2);
          V v_x3_2423 = (g_heff_2ebuild_2edecoder_2eint(heff_dup(v_s_241), v_j_2422));
          V v_x3_2427;
          switch (heff_tag_of(v_x3_2423)) {
          case TAG_Nothing: {
            v_x3_2427 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_Just: {
            V v_x31_2424 = heff_field(v_x3_2423, 0);
            heff_take_n(v_x3_2423, 1ULL, 1);
            switch (heff_tag_of(v_x31_2424)) {
            case TAG_MkPair: {
              V v_x_2425 = heff_field(v_x31_2424, 0);
              V v_j_2426 = heff_field(v_x31_2424, 1);
              heff_take_n(v_x31_2424, 3ULL, 2);
              v_x3_2427 = (g_heff_2ebuild_2edecoder_2etimes_24s364931774x210987922(v_x_2425, heff_dup(v_s_241), v_j_2426));
              break;
            }
            default: heff_nomatch(v_x31_2424);
            }
            break;
          }
          default: heff_nomatch(v_x3_2423);
          }
          switch (heff_tag_of(v_x3_2427)) {
          case TAG_Nothing: {
            heff_drop(v_s_241);
            heff_drop_cell(v_ru_24t_2419_24Just, 1);
            heff_drop_cell(v_ru_24x31_2420_24MkPair, 2);
            return NTAG(TAG_Nothing);
          }
          case TAG_Just: {
            V v_x31_2428 = heff_field(v_x3_2427, 0);
            heff_take_n(v_x3_2427, 1ULL, 1);
            switch (heff_tag_of(v_x31_2428)) {
            case TAG_MkPair: {
              V v_x_2429 = heff_field(v_x31_2428, 0);
              V v_j_2430 = heff_field(v_x31_2428, 1);
              heff_take_n(v_x31_2428, 3ULL, 2);
              V v_x3_2431 = (g_heff_2ebuild_2edecoder_2eint(heff_dup(v_s_241), v_j_2430));
              V v_x3_2435;
              switch (heff_tag_of(v_x3_2431)) {
              case TAG_Nothing: {
                v_x3_2435 = NTAG(TAG_Nothing);
                break;
              }
              case TAG_Just: {
                V v_x31_2432 = heff_field(v_x3_2431, 0);
                heff_take_n(v_x3_2431, 1ULL, 1);
                switch (heff_tag_of(v_x31_2432)) {
                case TAG_MkPair: {
                  V v_x_2433 = heff_field(v_x31_2432, 0);
                  V v_j_2434 = heff_field(v_x31_2432, 1);
                  heff_take_n(v_x31_2432, 3ULL, 2);
                  v_x3_2435 = (g_heff_2ebuild_2edecoder_2etimes_24s1861622792x1526156306(v_x_2433, heff_dup(v_s_241), v_j_2434));
                  break;
                }
                default: heff_nomatch(v_x31_2432);
                }
                break;
              }
              default: heff_nomatch(v_x3_2431);
              }
              switch (heff_tag_of(v_x3_2435)) {
              case TAG_Nothing: {
                heff_drop(v_s_241);
                heff_drop_cell(v_ru_24t_2419_24Just, 1);
                heff_drop_cell(v_ru_24x31_2420_24MkPair, 2);
                heff_drop(v_x_2429);
                return NTAG(TAG_Nothing);
              }
              case TAG_Just: {
                V v_x31_2436 = heff_field(v_x3_2435, 0);
                heff_take_n(v_x3_2435, 1ULL, 1);
                switch (heff_tag_of(v_x31_2436)) {
                case TAG_MkPair: {
                  V v_x_2437 = heff_field(v_x31_2436, 0);
                  V v_j_2438 = heff_field(v_x31_2436, 1);
                  heff_take_n(v_x31_2436, 3ULL, 2);
                  V v_x3_2439 = (g_heff_2ebuild_2edecoder_2eint(heff_dup(v_s_241), v_j_2438));
                  V v_x3_2443;
                  switch (heff_tag_of(v_x3_2439)) {
                  case TAG_Nothing: {
                    v_x3_2443 = NTAG(TAG_Nothing);
                    break;
                  }
                  case TAG_Just: {
                    V v_x31_2440 = heff_field(v_x3_2439, 0);
                    heff_take_n(v_x3_2439, 1ULL, 1);
                    switch (heff_tag_of(v_x31_2440)) {
                    case TAG_MkPair: {
                      V v_x_2441 = heff_field(v_x31_2440, 0);
                      V v_j_2442 = heff_field(v_x31_2440, 1);
                      heff_take_n(v_x31_2440, 3ULL, 2);
                      v_x3_2443 = (g_heff_2ebuild_2edecoder_2etimes_24s372484702x1286645721(v_x_2441, heff_dup(v_s_241), v_j_2442));
                      break;
                    }
                    default: heff_nomatch(v_x31_2440);
                    }
                    break;
                  }
                  default: heff_nomatch(v_x3_2439);
                  }
                  switch (heff_tag_of(v_x3_2443)) {
                  case TAG_Nothing: {
                    heff_drop(v_s_241);
                    heff_drop_cell(v_ru_24t_2419_24Just, 1);
                    heff_drop_cell(v_ru_24x31_2420_24MkPair, 2);
                    heff_drop(v_x_2429);
                    heff_drop(v_x_2437);
                    return NTAG(TAG_Nothing);
                  }
                  case TAG_Just: {
                    V v_x31_2444 = heff_field(v_x3_2443, 0);
                    heff_take_n(v_x3_2443, 1ULL, 1);
                    switch (heff_tag_of(v_x31_2444)) {
                    case TAG_MkPair: {
                      V v_x_2445 = heff_field(v_x31_2444, 0);
                      V v_j_2446 = heff_field(v_x31_2444, 1);
                      heff_take_n(v_x31_2444, 3ULL, 2);
                      V v_x3_2447 = (g_heff_2ebuild_2edecoder_2eint(heff_dup(v_s_241), v_j_2446));
                      V v_x3_2451;
                      switch (heff_tag_of(v_x3_2447)) {
                      case TAG_Nothing: {
                        v_x3_2451 = NTAG(TAG_Nothing);
                        break;
                      }
                      case TAG_Just: {
                        V v_x31_2448 = heff_field(v_x3_2447, 0);
                        heff_take_n(v_x3_2447, 1ULL, 1);
                        switch (heff_tag_of(v_x31_2448)) {
                        case TAG_MkPair: {
                          V v_x_2449 = heff_field(v_x31_2448, 0);
                          V v_j_2450 = heff_field(v_x31_2448, 1);
                          heff_take_n(v_x31_2448, 3ULL, 2);
                          v_x3_2451 = (g_heff_2ebuild_2edecoder_2etimes_24s700921301x1216293995(v_x_2449, heff_dup(v_s_241), v_j_2450));
                          break;
                        }
                        default: heff_nomatch(v_x31_2448);
                        }
                        break;
                      }
                      default: heff_nomatch(v_x3_2447);
                      }
                      switch (heff_tag_of(v_x3_2451)) {
                      case TAG_Nothing: {
                        heff_drop(v_s_241);
                        heff_drop_cell(v_ru_24t_2419_24Just, 1);
                        heff_drop_cell(v_ru_24x31_2420_24MkPair, 2);
                        heff_drop(v_x_2429);
                        heff_drop(v_x_2437);
                        heff_drop(v_x_2445);
                        return NTAG(TAG_Nothing);
                      }
                      case TAG_Just: {
                        V v_x31_2452 = heff_field(v_x3_2451, 0);
                        heff_take_n(v_x3_2451, 1ULL, 1);
                        switch (heff_tag_of(v_x31_2452)) {
                        case TAG_MkPair: {
                          V v_x_2453 = heff_field(v_x31_2452, 0);
                          V v_j_2454 = heff_field(v_x31_2452, 1);
                          heff_take_n(v_x31_2452, 3ULL, 2);
                          V v_x3_2455 = (g_heff_2ebuild_2edecoder_2estr(v_s_241, v_j_2454));
                          switch (heff_tag_of(v_x3_2455)) {
                          case TAG_Nothing: {
                            heff_drop_cell(v_ru_24t_2419_24Just, 1);
                            heff_drop_cell(v_ru_24x31_2420_24MkPair, 2);
                            heff_drop(v_x_2429);
                            heff_drop(v_x_2437);
                            heff_drop(v_x_2445);
                            heff_drop(v_x_2453);
                            return NTAG(TAG_Nothing);
                          }
                          case TAG_Just: {
                            V v_x31_2456 = heff_field(v_x3_2455, 0);
                            heff_take_n(v_x3_2455, 1ULL, 1);
                            switch (heff_tag_of(v_x31_2456)) {
                            case TAG_MkPair: {
                              V v_x_2457 = heff_field(v_x31_2456, 0);
                              V v_j_2458 = heff_field(v_x31_2456, 1);
                              heff_take_n(v_x31_2456, 3ULL, 2);
                              if (heff_strEq_c(v_x_2457, ((V)&g_heff_2ebuild_2ebackcache_2ebackD_str0))) {
                                V v_t_2460 = heff_tag_at_n(v_ru_24x31_2420_24MkPair, TAG_MkPair, 2, (V[]){heff_rec_n(4, shape_groups__copies__emits__jss, (V[]){v_x_2429, v_x_2437, v_x_2445, v_x_2453}), v_j_2458});
                                return heff_tag_at_n(v_ru_24t_2419_24Just, TAG_Just, 1, (V[]){v_t_2460});
                              } else {
                                heff_drop_cell(v_ru_24t_2419_24Just, 1);
                                heff_drop_cell(v_ru_24x31_2420_24MkPair, 2);
                                heff_drop(v_x_2429);
                                heff_drop(v_x_2437);
                                heff_drop(v_x_2445);
                                heff_drop(v_x_2453);
                                heff_drop(v_j_2458);
                                return NTAG(TAG_Nothing);
                              }
                            }
                            default: return heff_nomatch(v_x31_2456);
                            }
                          }
                          default: return heff_nomatch(v_x3_2455);
                          }
                        }
                        default: return heff_nomatch(v_x31_2452);
                        }
                      }
                      default: return heff_nomatch(v_x3_2451);
                      }
                    }
                    default: return heff_nomatch(v_x31_2444);
                    }
                  }
                  default: return heff_nomatch(v_x3_2443);
                  }
                }
                default: return heff_nomatch(v_x31_2436);
                }
              }
              default: return heff_nomatch(v_x3_2435);
              }
            }
            default: return heff_nomatch(v_x31_2428);
            }
          }
          default: return heff_nomatch(v_x3_2427);
          }
        }
        default: return heff_nomatch(v_x31_2420);
        }
      }
      default: return heff_nomatch(v_t_2419);
      }
    }
    default: return heff_nomatch(v_x31_2410);
    }
  }
  default: return heff_nomatch(v_t_249);
  }
}
V g_heff_2ebuild_2ebackcache_2ebackD_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ebackcache_2ebackD(a[0], a[1], a[2]);
}
Clo g_heff_2ebuild_2ebackcache_2elastDotGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebackcache_2elastDotGo_entry, 3, 0};

V g_heff_2ebuild_2ebackcache_2elastDotGo(V v_k_240, V v_i_241, V v_at_242) {
top: ;
  if (heff_intLe_c(heff_strLength_lent(v_k_240, 0), heff_dup(v_i_241))) {
    heff_drop(v_k_240);
    heff_drop(v_i_241);
    return v_at_242;
  } else {
    V v_t_245;
    if (heff_intEq_c(heff_strByteAt_lent(v_k_240, v_i_241, 0), MK_INT(46LL))) {
      heff_drop(v_at_242);
      v_t_245 = heff_dup(v_i_241);
    } else {
      v_t_245 = v_at_242;
    }
    V t_0 = v_k_240;
    V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
    V t_2 = v_t_245;
    v_k_240 = t_0;
    v_i_241 = t_1;
    v_at_242 = t_2;
    goto top;
  }
}
V g_heff_2ebuild_2ebackcache_2elastDotGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ebackcache_2elastDotGo(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ebuild_2ebackcache_2emoduleIn_str0, 1, "_");
Clo g_heff_2ebuild_2ebackcache_2emoduleIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebackcache_2emoduleIn_entry, 2, 0};

V g_heff_2ebuild_2ebackcache_2emoduleIn(V v_mods_240, V v_k_241) {
top: ;
  V v_x3_242 = (g_map_2elookup_24s659669741x1036301430(heff_dup(v_k_241), v_mods_240));
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nothing: {
    V v_t_243 = (g_heff_2ebuild_2ebackcache_2elastDotGo(heff_dup(v_k_241), MK_INT(0LL), MK_INT(-1LL)));
    if (heff_intLe_c(v_t_243, MK_INT(0LL))) {
      heff_drop(v_k_241);
      return ((V)&g_heff_2ebuild_2ebackcache_2emoduleIn_str0);
    } else {
      V v_t_245 = (g_heff_2ebuild_2ebackcache_2elastDotGo(heff_dup(v_k_241), MK_INT(0LL), MK_INT(-1LL)));
      V t_0 = v_mods_240;
      V t_1 = heff_strSlice(v_k_241, MK_INT(0LL), v_t_245);
      v_mods_240 = t_0;
      v_k_241 = t_1;
      goto top;
    }
  }
  case TAG_Just: {
    heff_take_n(v_x3_242, 0ULL, 1);
    return v_k_241;
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2ebackcache_2emoduleIn_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ebackcache_2emoduleIn(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2ebuild_2ebackcache_2eentriesAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebackcache_2eentriesAt_entry, 3, 0};

V g_heff_2ebuild_2ebackcache_2eentriesAt(V v_olds_240, V v_m_241, V v_k_242) {
top: ;
  V v_t_243 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(v_k_242), v_m_241));
  switch (heff_tag_of(v_t_243)) {
  case TAG_Nothing: {
    V v_x2_244 = (g_map_2elookup_24s1546226666x2146984184(v_k_242, v_olds_240));
    V v_b_246;
    switch (heff_tag_of(v_x2_244)) {
    case TAG_Nothing: {
      v_b_246 = heff_dup(g_heff_2ebuild_2ebackcache_2enoBack_get());
      break;
    }
    case TAG_Just: {
      V v_x_245 = heff_field(v_x2_244, 0);
      heff_take_n(v_x2_244, 1ULL, 1);
      v_b_246 = v_x_245;
      break;
    }
    default: heff_nomatch(v_x2_244);
    }
    V v_t_247 = (g_list_2efoldl_24s306513717x1560435942(heff_dup(g_map_2eempty_get()), heff_rfield(v_b_246, 0)));
    V v_t_248 = (g_list_2efoldl_24s544151770x491236151(heff_dup(g_map_2eempty_get()), heff_rfield(v_b_246, 1)));
    V v_t_249 = (g_list_2efoldl_24s544151770x491236151(heff_dup(g_map_2eempty_get()), heff_rfield(v_b_246, 2)));
    V v_t_2410 = ({ V a_0 = heff_dup(g_map_2eempty_get()); V b_1 = heff_get_n(v_b_246, 3, 4); V r_ = (g_list_2efoldl_24s544151770x491236151(a_0, b_1)); heff_drop(b_1); r_; });
    return heff_rec_n(4, shape_groups__copies__emits__jss, (V[]){v_t_247, v_t_248, v_t_249, v_t_2410});
  }
  case TAG_Just: {
    V v_es_2411 = heff_field(v_t_243, 0);
    heff_take_n(v_t_243, 1ULL, 1);
    heff_drop(v_k_242);
    return v_es_2411;
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_heff_2ebuild_2ebackcache_2eentriesAt_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ebuild_2ebackcache_2eentriesAt(a0, a1, a[2]); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_heff_2ebuild_2ebackcache_2eallJustB_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebackcache_2eallJustB_entry, 1, 0};

V g_heff_2ebuild_2ebackcache_2eallJustB(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_tag_n(TAG_Just, 1, (V[]){NTAG(TAG_Nil)});
  }
  case TAG_Cons: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_Nothing: {
      heff_drop(v_rest_242);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_Just: {
      V v_x_243 = heff_field(v_x11_241, 0);
      V v_ru_24x11_241_24Just = heff_take_reuse_n(v_x11_241, 1ULL, 1);
      V v_x2_244 = (g_heff_2ebuild_2ebackcache_2eallJustB(v_rest_242));
      switch (heff_tag_of(v_x2_244)) {
      case TAG_Nothing: {
        heff_drop_cell(v_ru_24x1_240_24Cons, 2);
        heff_drop(v_x_243);
        heff_drop_cell(v_ru_24x11_241_24Just, 1);
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_xs_245 = heff_field(v_x2_244, 0);
        heff_take_n(v_x2_244, 1ULL, 1);
        return heff_tag_at_n(v_ru_24x11_241_24Just, TAG_Just, 1, (V[]){heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_243, v_xs_245})});
      }
      default: return heff_nomatch(v_x2_244);
      }
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2ebackcache_2eallJustB_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ebackcache_2eallJustB(a[0]);
}
HEFF_LIT(g_heff_2ebuild_2ebackcache_2egroupText_str0, 1, ":");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2egroupText_str1, 1, ":");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2egroupText_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2egroupText_str3, 1, " ");
Clo g_heff_2ebuild_2ebackcache_2egroupText_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebackcache_2egroupText_entry, 3, 0};

V g_heff_2ebuild_2ebackcache_2egroupText(V v_owner_240, V v_ver_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nothing: {
    heff_drop(v_owner_240);
    heff_drop(v_ver_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_us_243 = heff_field(v_x3_242, 0);
    V v_ru_24x3_242_24Just = heff_take_reuse_n(v_x3_242, 1ULL, 1);
    V v_t_244 = heff_intShow(heff_strLength_lent(v_owner_240, 0));
    V v_t_245 = heff_strAppend(v_t_244, heff_strAppend(((V)&g_heff_2ebuild_2ebackcache_2egroupText_str0), v_owner_240));
    V v_t_246 = heff_intShow(heff_strLength_lent(v_ver_241, 0));
    V v_t_247 = heff_strAppend(v_t_246, heff_strAppend(((V)&g_heff_2ebuild_2ebackcache_2egroupText_str1), v_ver_241));
    V v_t_248 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_us_243));
    V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_t_248), v_us_243});
    V v_x2_2410 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_245, heff_tag_n(TAG_Cons, 2, (V[]){v_t_247, v_t_249})});
    V v_t_2413;
    switch (heff_tag_of(v_x2_2410)) {
    case TAG_Nil: {
      v_t_2413 = ((V)&g_heff_2ebuild_2ebackcache_2egroupText_str2);
      break;
    }
    case TAG_Cons: {
      V v_x_2411 = heff_field(v_x2_2410, 0);
      V v_xs_2412 = heff_field(v_x2_2410, 1);
      heff_take_n(v_x2_2410, 3ULL, 2);
      v_t_2413 = ({ V a_0 = ((V)&g_heff_2ebuild_2ebackcache_2egroupText_str3); V a_1 = v_x_2411; V a_2 = v_xs_2412; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2412); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2410);
    }
    return heff_tag_at_n(v_ru_24x3_242_24Just, TAG_Just, 1, (V[]){v_t_2413});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2ebackcache_2egroupText_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ebackcache_2egroupText(a[0], a[1], a[2]);
}
Clo g_heff_2ebuild_2ebackcache_2egroupIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebackcache_2egroupIn_entry, 5, 0};

V g_heff_2ebuild_2ebackcache_2egroupIn(V v_fs_240, V v_m_241, V v_md_242, V v_g_243, V v_x5_244) {
top: ;
  switch (heff_tag_of(v_x5_244)) {
  case TAG_Nothing: {
    heff_drop_rec(v_fs_240, 2);
    heff_drop(v_md_242);
    heff_drop_rec(v_g_243, 3);
    return v_m_241;
  }
  case TAG_Just: {
    V v_t_245 = heff_field(v_x5_244, 0);
    V v_es_246 = ({ V b_0 = heff_get_n(v_fs_240, 1, 2); V a_1 = v_m_241; V a_2 = heff_dup(v_md_242); V r_ = (g_heff_2ebuild_2ebackcache_2eentriesAt(b_0, a_1, a_2)); heff_drop(b_0); r_; });
    V v_t_247 = (g_map_2einsert_24s1341440536x470972936(heff_get_n(v_g_243, 0, 3), heff_dup(v_t_245), heff_take_field(v_es_246, 0)));
    V v_t_248 = ({ V rv_0 = v_t_247; V rr_ = heff_rec_reuse_nf(v_es_246, 14ULL, 4, shape_groups__copies__emits__jss, 252u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
    return (g_map_2einsert_24s1341440536x470972936(v_md_242, v_t_248, v_m_241));
  }
  default: return heff_nomatch(v_x5_244);
  }
}
V g_heff_2ebuild_2ebackcache_2egroupIn_entry(V self, V *a) {
  (void)self;
  V a4 = a[4]; V r = g_heff_2ebuild_2ebackcache_2egroupIn(a[0], a[1], a[2], a[3], a4); heff_drop(a4); return r;
}
V g_heff_2ebuild_2ebackcache_2eaddGroup_lam0(V self, V *args);
V g_heff_2ebuild_2ebackcache_2eaddGroup_lam1(V self, V *args);
Clo g_heff_2ebuild_2ebackcache_2eaddGroup_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebackcache_2eaddGroup_entry, 3, 0};

V g_heff_2ebuild_2ebackcache_2eaddGroup(V v_fs_240, V v_m_241, V v_g_242) {
top: ;
  V v_t_243 = (g_heff_2ebuild_2ebackcache_2emoduleIn(heff_rfield(v_fs_240, 0), heff_dup(heff_rfield(v_g_242, 0))));
  V v_m_244 = (g_heff_2ebuild_2ebackcache_2emoduleIn(heff_rfield(v_fs_240, 0), heff_dup(heff_rfield(v_g_242, 0))));
  V v_x2_245 = (g_map_2elookup_24s1546226666x2146984184(v_m_244, heff_rfield(v_fs_240, 1)));
  V v_t_247;
  switch (heff_tag_of(v_x2_245)) {
  case TAG_Nothing: {
    v_t_247 = heff_dup(g_heff_2ebuild_2ebackcache_2enoBack_get());
    break;
  }
  case TAG_Just: {
    V v_x_246 = heff_field(v_x2_245, 0);
    heff_take_n(v_x2_245, 1ULL, 1);
    v_t_247 = v_x_246;
    break;
  }
  default: heff_nomatch(v_x2_245);
  }
  V v_t_248 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_get_n(v_t_247, 0, 4)));
  V v_old_2419 = ({ V a_0 = heff_clo_n(g_heff_2ebuild_2ebackcache_2eaddGroup_lam0, 2, 1, (V[]){heff_dup(v_g_242)}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_248; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_248); r_; });
  V v_t_2430 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2ebackcache_2eaddGroup_lam1, 1, 1, (V[]){v_old_2419}), heff_dup(heff_rfield(v_g_242, 2))));
  V v_t_2431 = (g_heff_2ebuild_2ebackcache_2eallJustB(v_t_2430));
  V v_t_2432 = (g_heff_2ebuild_2ebackcache_2egroupText(heff_dup(heff_rfield(v_g_242, 0)), heff_dup(heff_rfield(v_g_242, 1)), v_t_2431));
  return ({ V a_0 = v_fs_240; V a_1 = v_m_241; V a_2 = v_t_243; V a_3 = v_g_242; V a_4 = v_t_2432; V r_ = (g_heff_2ebuild_2ebackcache_2egroupIn(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_t_2432); r_; });
}
V g_heff_2ebuild_2ebackcache_2eaddGroup_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ebackcache_2eaddGroup(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2ebackcache_2eaddGroup_lam0(V self, V *args) {
  V v_acc_249 = args[0];
  V v_x_2410 = args[1];
  V v_g_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2413;
  switch (heff_tag_of(v_x_2410)) {
  case TAG_MkPair: {
    V v_x_2411 = heff_dup(heff_field(v_x_2410, 0));
    v_t_2413 = v_x_2411;
    break;
  }
  default: heff_nomatch(v_x_2410);
  }
  V v_t_2418;
  if (heff_strEq_c(heff_get_n(v_t_2413, 0, 3), heff_get_n(v_g_242, 0, 3))) {
    V v_t_2417;
    switch (heff_tag_of(v_x_2410)) {
    case TAG_MkPair: {
      V v_x_2415 = heff_field(v_x_2410, 0);
      heff_take_n(v_x_2410, 1ULL, 2);
      v_t_2417 = v_x_2415;
      break;
    }
    default: heff_nomatch(v_x_2410);
    }
    v_t_2418 = heff_get_n(v_t_2417, 2, 3);
  } else {
    heff_drop(v_x_2410);
    v_t_2418 = NTAG(TAG_Nil);
  }
  return (g_prelude_2e_2b_2b(v_t_2418, v_acc_249));
}
V g_heff_2ebuild_2ebackcache_2eaddGroup_lam1(V self, V *args) {
  V v_x2_2420 = args[0];
  V v_old_2419 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x2_2420)) {
  case TAG_MkPair: {
    V v_k_2421 = heff_field(v_x2_2420, 0);
    V v_x22_2422 = heff_field(v_x2_2420, 1);
    heff_take_n(v_x2_2420, 3ULL, 2);
    switch (heff_tag_of(v_x22_2422)) {
    case TAG_Nothing: {
      V v_t_2423 = ({ V a_0 = v_k_2421; V a_1 = v_old_2419; V r_ = (g_list_2efind_24s1990539953x112149757(a_0, a_1)); heff_drop(v_old_2419); r_; });
      switch (heff_tag_of(v_t_2423)) {
      case TAG_Nothing: {
        return NTAG(TAG_Nothing);
      }
      case TAG_Just: {
        V v_p_2424 = heff_field(v_t_2423, 0);
        V v_ru_24t_2423_24Just = heff_take_reuse_n(v_t_2423, 1ULL, 1);
        V v_t_2427;
        switch (heff_tag_of(v_p_2424)) {
        case TAG_MkPair: {
          V v_y_2426 = heff_field(v_p_2424, 1);
          heff_take_n(v_p_2424, 2ULL, 2);
          v_t_2427 = v_y_2426;
          break;
        }
        default: heff_nomatch(v_p_2424);
        }
        return heff_tag_at_n(v_ru_24t_2423_24Just, TAG_Just, 1, (V[]){v_t_2427});
      }
      default: return heff_nomatch(v_t_2423);
      }
    }
    case TAG_Just: {
      V v_u_2428 = heff_field(v_x22_2422, 0);
      V v_ru_24x22_2422_24Just = heff_take_reuse_n(v_x22_2422, 1ULL, 1);
      heff_drop(v_old_2419);
      heff_drop(v_k_2421);
      V v_t_2429 = (g_heff_2ebuild_2ebackcache_2eunitText(v_u_2428));
      return heff_tag_at_n(v_ru_24x22_2422_24Just, TAG_Just, 1, (V[]){v_t_2429});
    }
    default: return heff_nomatch(v_x22_2422);
    }
  }
  default: return heff_nomatch(v_x2_2420);
  }
}
HEFF_LIT(g_heff_2ebuild_2ebackcache_2eaddCopy_str0, 2, "$s");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2eaddCopy_str1, 2, "$s");
Clo g_heff_2ebuild_2ebackcache_2eaddCopy_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebackcache_2eaddCopy_entry, 3, 0};

V g_heff_2ebuild_2ebackcache_2eaddCopy(V v_fs_240, V v_m_241, V v_c_242) {
top: ;
  V v_g_243 = heff_dup(heff_rfield(v_c_242, 0));
  V v_j_244 = (g_prelude_2estrFind(((V)&g_heff_2ebuild_2ebackcache_2eaddCopy_str0), heff_dup(v_g_243), MK_INT(0LL)));
  V v_t_246;
  if (heff_intLt_c(heff_dup(v_j_244), MK_INT(0LL))) {
    heff_drop(v_j_244);
    v_t_246 = v_g_243;
  } else {
    v_t_246 = heff_strSlice(v_g_243, MK_INT(0LL), v_j_244);
  }
  V v_t_247 = (g_heff_2ebuild_2ebackcache_2emoduleIn(heff_rfield(v_fs_240, 0), v_t_246));
  V v_t_248 = (g_heff_2ebuild_2ebackcache_2ecopyText(heff_dup(v_c_242)));
  V v_g_249 = heff_dup(heff_rfield(v_c_242, 0));
  V v_j_2410 = (g_prelude_2estrFind(((V)&g_heff_2ebuild_2ebackcache_2eaddCopy_str1), heff_dup(v_g_249), MK_INT(0LL)));
  V v_t_2412;
  if (heff_intLt_c(heff_dup(v_j_2410), MK_INT(0LL))) {
    heff_drop(v_j_2410);
    v_t_2412 = v_g_249;
  } else {
    v_t_2412 = heff_strSlice(v_g_249, MK_INT(0LL), v_j_2410);
  }
  V v_t_2413 = (g_heff_2ebuild_2ebackcache_2emoduleIn(heff_rfield(v_fs_240, 0), v_t_2412));
  V v_es_2414 = ({ V b_0 = heff_get_n(v_fs_240, 1, 2); V a_1 = v_m_241; V a_2 = v_t_2413; V r_ = (g_heff_2ebuild_2ebackcache_2eentriesAt(b_0, a_1, a_2)); heff_drop(b_0); r_; });
  V v_t_2415 = (g_map_2einsert_24s1341440536x470972936(heff_get_n(v_c_242, 0, 6), v_t_248, heff_take_field(v_es_2414, 1)));
  V v_t_2416 = ({ V rv_1 = v_t_2415; V rr_ = heff_rec_reuse_nf(v_es_2414, 13ULL, 4, shape_groups__copies__emits__jss, 243u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
  HEFF_LAST return g_map_2einsert_24s1341440536x470972936(v_t_247, v_t_2416, v_m_241);
}
V g_heff_2ebuild_2ebackcache_2eaddCopy_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ebackcache_2eaddCopy(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ebuild_2ebackcache_2eaddEmit_str0, 2, "$s");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2eaddEmit_str1, 2, "$s");
Clo g_heff_2ebuild_2ebackcache_2eaddEmit_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebackcache_2eaddEmit_entry, 3, 0};

V g_heff_2ebuild_2ebackcache_2eaddEmit(V v_fs_240, V v_m_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_MkPair: {
    V v_k_243 = heff_field(v_x3_242, 0);
    V v_e_244 = heff_field(v_x3_242, 1);
    V v_j_245 = (g_prelude_2estrFind(((V)&g_heff_2ebuild_2ebackcache_2eaddEmit_str0), heff_dup(v_k_243), MK_INT(0LL)));
    V v_t_247;
    if (heff_intLt_c(heff_dup(v_j_245), MK_INT(0LL))) {
      heff_drop(v_j_245);
      v_t_247 = heff_dup(v_k_243);
    } else {
      v_t_247 = heff_strSlice_lent(v_k_243, MK_INT(0LL), v_j_245, 6);
    }
    V v_t_248 = (g_heff_2ebuild_2ebackcache_2emoduleIn(heff_rfield(v_fs_240, 0), v_t_247));
    V v_t_249 = (g_heff_2ebuild_2ebackcache_2eemitText(heff_dup(v_k_243), heff_dup(v_e_244)));
    V v_j_2410 = (g_prelude_2estrFind(((V)&g_heff_2ebuild_2ebackcache_2eaddEmit_str1), heff_dup(v_k_243), MK_INT(0LL)));
    V v_t_2412;
    if (heff_intLt_c(heff_dup(v_j_2410), MK_INT(0LL))) {
      heff_drop(v_j_2410);
      v_t_2412 = heff_dup(v_k_243);
    } else {
      v_t_2412 = heff_strSlice_lent(v_k_243, MK_INT(0LL), v_j_2410, 6);
    }
    V v_t_2413 = (g_heff_2ebuild_2ebackcache_2emoduleIn(heff_rfield(v_fs_240, 0), v_t_2412));
    V v_es_2414 = ({ V b_0 = heff_get_n(v_fs_240, 1, 2); V a_1 = v_m_241; V a_2 = v_t_2413; V r_ = (g_heff_2ebuild_2ebackcache_2eentriesAt(b_0, a_1, a_2)); heff_drop(b_0); r_; });
    V v_t_2415 = (g_map_2einsert_24s1341440536x470972936(heff_dup(v_k_243), v_t_249, heff_take_field(v_es_2414, 2)));
    V v_t_2416 = ({ V rv_2 = v_t_2415; V rr_ = heff_rec_reuse_nf(v_es_2414, 11ULL, 4, shape_groups__copies__emits__jss, 207u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    HEFF_LAST return g_map_2einsert_24s1341440536x470972936(v_t_248, v_t_2416, v_m_241);
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2ebackcache_2eaddEmit_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ebuild_2ebackcache_2eaddEmit(a[0], a[1], a2); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2ebuild_2ebackcache_2eaddJs_str0, 2, "$s");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2eaddJs_str1, 2, "$s");
Clo g_heff_2ebuild_2ebackcache_2eaddJs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebackcache_2eaddJs_entry, 3, 0};

V g_heff_2ebuild_2ebackcache_2eaddJs(V v_fs_240, V v_m_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_MkPair: {
    V v_k_243 = heff_field(v_x3_242, 0);
    V v_e_244 = heff_field(v_x3_242, 1);
    V v_j_245 = (g_prelude_2estrFind(((V)&g_heff_2ebuild_2ebackcache_2eaddJs_str0), heff_dup(v_k_243), MK_INT(0LL)));
    V v_t_247;
    if (heff_intLt_c(heff_dup(v_j_245), MK_INT(0LL))) {
      heff_drop(v_j_245);
      v_t_247 = heff_dup(v_k_243);
    } else {
      v_t_247 = heff_strSlice_lent(v_k_243, MK_INT(0LL), v_j_245, 6);
    }
    V v_t_248 = (g_heff_2ebuild_2ebackcache_2emoduleIn(heff_rfield(v_fs_240, 0), v_t_247));
    V v_t_249 = (g_heff_2ebuild_2ebackcache_2ejsText(heff_dup(v_k_243), heff_dup(v_e_244)));
    V v_j_2410 = (g_prelude_2estrFind(((V)&g_heff_2ebuild_2ebackcache_2eaddJs_str1), heff_dup(v_k_243), MK_INT(0LL)));
    V v_t_2412;
    if (heff_intLt_c(heff_dup(v_j_2410), MK_INT(0LL))) {
      heff_drop(v_j_2410);
      v_t_2412 = heff_dup(v_k_243);
    } else {
      v_t_2412 = heff_strSlice_lent(v_k_243, MK_INT(0LL), v_j_2410, 6);
    }
    V v_t_2413 = (g_heff_2ebuild_2ebackcache_2emoduleIn(heff_rfield(v_fs_240, 0), v_t_2412));
    V v_es_2414 = ({ V b_0 = heff_get_n(v_fs_240, 1, 2); V a_1 = v_m_241; V a_2 = v_t_2413; V r_ = (g_heff_2ebuild_2ebackcache_2eentriesAt(b_0, a_1, a_2)); heff_drop(b_0); r_; });
    V v_t_2415 = (g_map_2einsert_24s1341440536x470972936(heff_dup(v_k_243), v_t_249, heff_take_field(v_es_2414, 3)));
    V v_t_2416 = ({ V rv_3 = v_t_2415; V rr_ = heff_rec_reuse_nf(v_es_2414, 7ULL, 4, shape_groups__copies__emits__jss, 63u, 0u); heff_rfield(rr_, 3) = rv_3; rr_; });
    HEFF_LAST return g_map_2einsert_24s1341440536x470972936(v_t_248, v_t_2416, v_m_241);
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2ebackcache_2eaddJs_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ebuild_2ebackcache_2eaddJs(a[0], a[1], a2); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2ebuild_2ebackcache_2ebackText_str0, 1, ":");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2ebackText_str1, 1, ":");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2ebackText_str2, 5, "3:end");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2ebackText_str3, 0, "");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2ebackText_str4, 1, " ");
Clo g_heff_2ebuild_2ebackcache_2ebackText_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebackcache_2ebackText_entry, 2, 0};

V g_heff_2ebuild_2ebackcache_2ebackText(V v_id_240, V v_es_241) {
top: ;
  V v_t_242 = heff_intShow(heff_strLength(heff_dup(g_heff_2ebuild_2ebackcache_2eversion_get())));
  V v_t_243 = heff_strAppend(v_t_242, heff_strAppend(((V)&g_heff_2ebuild_2ebackcache_2ebackText_str0), heff_dup(g_heff_2ebuild_2ebackcache_2eversion_get())));
  V v_t_244 = heff_intShow(heff_strLength_lent(v_id_240, 0));
  V v_t_245 = heff_strAppend(v_t_244, heff_strAppend(((V)&g_heff_2ebuild_2ebackcache_2ebackText_str1), v_id_240));
  V v_t_246 = (g_map_2esize(heff_rfield(v_es_241, 0)));
  V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_t_246), NTAG(TAG_Nil)});
  V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_243, heff_tag_n(TAG_Cons, 2, (V[]){v_t_245, v_t_247})});
  V v_t_249 = (g_map_2etoListOnto(heff_rfield(v_es_241, 0), NTAG(TAG_Nil)));
  V v_t_2410 = (g_list_2emap_24s1173914895x100384474(v_t_249));
  V v_t_2411 = (g_map_2esize(heff_rfield(v_es_241, 1)));
  V v_t_2412 = (g_map_2etoListOnto(heff_rfield(v_es_241, 1), NTAG(TAG_Nil)));
  V v_t_2413 = (g_list_2emap_24s1173914895x100384474(v_t_2412));
  V v_t_2414 = (g_map_2esize(heff_rfield(v_es_241, 2)));
  V v_t_2415 = (g_map_2etoListOnto(heff_rfield(v_es_241, 2), NTAG(TAG_Nil)));
  V v_t_2416 = (g_list_2emap_24s1173914895x100384474(v_t_2415));
  V v_t_2417 = (g_map_2esize(heff_rfield(v_es_241, 3)));
  V v_t_2418 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ebackcache_2ebackText_str2), NTAG(TAG_Nil)});
  V v_t_2419 = ({ V b_0 = heff_get_n(v_es_241, 3, 4); V a_1 = NTAG(TAG_Nil); V r_ = (g_map_2etoListOnto(b_0, a_1)); heff_drop(b_0); r_; });
  V v_t_2420 = (g_prelude_2e_2b_2b_24f1085359736x1262841716(v_t_2418, v_t_2419));
  V v_t_2421 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_t_2417), v_t_2420});
  V v_t_2422 = (g_prelude_2e_2b_2b(v_t_2416, v_t_2421));
  V v_t_2423 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_t_2414), v_t_2422});
  V v_t_2424 = (g_prelude_2e_2b_2b(v_t_2413, v_t_2423));
  V v_t_2425 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_t_2411), v_t_2424});
  V v_t_2426 = (g_prelude_2e_2b_2b(v_t_2410, v_t_2425));
  V v_x2_2427 = (g_prelude_2e_2b_2b(v_t_248, v_t_2426));
  switch (heff_tag_of(v_x2_2427)) {
  case TAG_Nil: {
    return ((V)&g_heff_2ebuild_2ebackcache_2ebackText_str3);
  }
  case TAG_Cons: {
    V v_x_2428 = heff_field(v_x2_2427, 0);
    V v_xs_2429 = heff_field(v_x2_2427, 1);
    heff_take_n(v_x2_2427, 3ULL, 2);
    return ({ V a_0 = ((V)&g_heff_2ebuild_2ebackcache_2ebackText_str4); V a_1 = v_x_2428; V a_2 = v_xs_2429; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2429); r_; });
  }
  default: return heff_nomatch(v_x2_2427);
  }
}
V g_heff_2ebuild_2ebackcache_2ebackText_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ebackcache_2ebackText(a[0], a[1]);
}
V g_heff_2ebuild_2ebackcache_2ebackTexts_lam0(V self, V *args);
Clo g_heff_2ebuild_2ebackcache_2ebackTexts_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebackcache_2ebackTexts_entry, 3, 0};

V g_heff_2ebuild_2ebackcache_2ebackTexts(V v_id_240, V v_fs_241, V v_gv_242) {
top: ;
  V v_t_243 = heff_tr(heff_call(((V)&g_heff_2ebuild_2ebackcache_2eaddJs_clo), 1, (V[]){heff_dup(v_fs_241)}));
  V v_t_244 = heff_tr(heff_call(((V)&g_heff_2ebuild_2ebackcache_2eaddEmit_clo), 1, (V[]){heff_dup(v_fs_241)}));
  V v_t_245 = heff_tr(heff_call(((V)&g_heff_2ebuild_2ebackcache_2eaddCopy_clo), 1, (V[]){heff_dup(v_fs_241)}));
  V v_t_246 = heff_tr(heff_call(((V)&g_heff_2ebuild_2ebackcache_2eaddGroup_clo), 1, (V[]){v_fs_241}));
  V v_t_247 = (g_list_2efoldl(v_t_246, heff_dup(g_map_2eempty_get()), heff_rfield(v_gv_242, 0)));
  V v_t_248 = (g_list_2efoldl(v_t_245, v_t_247, heff_rfield(v_gv_242, 1)));
  V v_t_249 = (g_list_2efoldl(v_t_244, v_t_248, heff_rfield(v_gv_242, 2)));
  V v_m_2410 = ({ V a_0 = v_t_243; V a_1 = v_t_249; V b_2 = heff_get_n(v_gv_242, 3, 4); V r_ = (g_list_2efoldl(a_0, a_1, b_2)); heff_drop(b_2); r_; });
  V v_t_2411 = ({ V a_0 = v_m_2410; V a_1 = NTAG(TAG_Nil); V r_ = (g_map_2etoListOnto(a_0, a_1)); heff_drop(v_m_2410); r_; });
  return (g_list_2emap(heff_clo_n(g_heff_2ebuild_2ebackcache_2ebackTexts_lam0, 1, 1, (V[]){v_id_240}), v_t_2411));
}
V g_heff_2ebuild_2ebackcache_2ebackTexts_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ebackcache_2ebackTexts(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2ebackcache_2ebackTexts_lam0(V self, V *args) {
  V v_p_2412 = args[0];
  V v_id_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2415;
  switch (heff_tag_of(v_p_2412)) {
  case TAG_MkPair: {
    V v_x_2413 = heff_dup(heff_field(v_p_2412, 0));
    v_t_2415 = v_x_2413;
    break;
  }
  default: heff_nomatch(v_p_2412);
  }
  V v_t_2418;
  switch (heff_tag_of(v_p_2412)) {
  case TAG_MkPair: {
    V v_y_2417 = heff_field(v_p_2412, 1);
    heff_take_n(v_p_2412, 2ULL, 2);
    v_t_2418 = v_y_2417;
    break;
  }
  default: heff_nomatch(v_p_2412);
  }
  V v_t_2419 = (g_heff_2ebuild_2ebackcache_2ebackText(v_id_240, v_t_2418));
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2415, v_t_2419});
}