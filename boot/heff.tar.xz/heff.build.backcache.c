// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define LBL_body 9524841
#define LBL_code 9554612
#define LBL_copies 592412158
#define LBL_def 308863
#define LBL_depth 296830685
#define LBL_done 9584713
#define LBL_emits 297985818
#define LBL_groups 709681407
#define LBL_jss 315076
#define LBL_key 315609
#define LBL_lams 9809570
#define LBL_lines 304335641
#define LBL_lprotos 613175609
#define LBL_made 9839068
#define LBL_mods 9852536
#define LBL_name 9869138
#define LBL_olds 9909235
#define LBL_owner 307523277
#define LBL_params 951713969
#define LBL_prims 308293287
#define LBL_protos 967342774
#define LBL_recipe 1012227257
#define LBL_refs 9991943
#define LBL_safe 10017876
#define LBL_sgSafe 1042218796
#define LBL_sgTotal 97882005
#define LBL_shapes 1043573789
#define LBL_strs 10036521
#define LBL_touched 1244526179
#define LBL_units 312791945
#define LBL_ver 326173
static uint32_t shape_body__touched[] = {LBL_body, LBL_touched};
static uint32_t shape_def__refs[] = {LBL_def, LBL_refs};
static uint32_t shape_groups__copies__emits__jss[] = {LBL_groups, LBL_copies, LBL_emits, LBL_jss};
static uint32_t shape_key__name__body__safe__touched__sgSafe__sgTotal[] = {LBL_key, LBL_name, LBL_body, LBL_safe, LBL_touched, LBL_sgSafe, LBL_sgTotal};
static uint32_t shape_owner__ver__units[] = {LBL_owner, LBL_ver, LBL_units};
static uint32_t shape_ver__lines__params__refs__prims[] = {LBL_ver, LBL_lines, LBL_params, LBL_refs, LBL_prims};
static uint32_t shape_ver__protos__code__strs__lprotos__lams__shapes__prims[] = {LBL_ver, LBL_protos, LBL_code, LBL_strs, LBL_lprotos, LBL_lams, LBL_shapes, LBL_prims};
static uint32_t shape_ver__recipe__depth__safe__made[] = {LBL_ver, LBL_recipe, LBL_depth, LBL_safe, LBL_made};
V g_heff_2ebuild_2ebackcache_2eaddCopy(V, V, V);
V g_heff_2ebuild_2ebackcache_2eaddCopy_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebackcache_2eaddCopy_clo;
V g_heff_2ebuild_2ebackcache_2eaddEmit(V, V, V);
V g_heff_2ebuild_2ebackcache_2eaddEmit_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebackcache_2eaddEmit_clo;
V g_heff_2ebuild_2ebackcache_2eaddGroup(V, V, V);
V g_heff_2ebuild_2ebackcache_2eaddGroup_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebackcache_2eaddGroup_clo;
V g_heff_2ebuild_2ebackcache_2eaddJs(V, V, V);
V g_heff_2ebuild_2ebackcache_2eaddJs_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebackcache_2eaddJs_clo;
V g_heff_2ebuild_2ebackcache_2eallJustB(V);
V g_heff_2ebuild_2ebackcache_2eallJustB_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebackcache_2eallJustB_clo;
HeffT2 g_heff_2ebuild_2ebackcache_2eallJustB_24cpr(V);
HeffT2 g_heff_2ebuild_2ebackcache_2ebackD_24cpr(V, V, V);
V g_heff_2ebuild_2ebackcache_2ebackDir_get(void);
V g_heff_2ebuild_2ebackcache_2ebackText(V, V);
V g_heff_2ebuild_2ebackcache_2ebackText_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebackcache_2ebackText_clo;
V g_heff_2ebuild_2ebackcache_2ebackTexts(V, V, V);
V g_heff_2ebuild_2ebackcache_2ebackTexts_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebackcache_2ebackTexts_clo;
V g_heff_2ebuild_2ebackcache_2ecopyD(V, V);
V g_heff_2ebuild_2ebackcache_2ecopyD_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebackcache_2ecopyD_clo;
V g_heff_2ebuild_2ebackcache_2ecopyText(V);
V g_heff_2ebuild_2ebackcache_2ecopyText_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebackcache_2ecopyText_clo;
V g_heff_2ebuild_2ebackcache_2eemitD(V, V);
V g_heff_2ebuild_2ebackcache_2eemitD_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebackcache_2eemitD_clo;
V g_heff_2ebuild_2ebackcache_2eemitText(V, V);
V g_heff_2ebuild_2ebackcache_2eemitText_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebackcache_2eemitText_clo;
V g_heff_2ebuild_2ebackcache_2eentriesAt(V, V, V);
V g_heff_2ebuild_2ebackcache_2eentriesAt_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebackcache_2eentriesAt_clo;
V g_heff_2ebuild_2ebackcache_2egroupD(V, V);
V g_heff_2ebuild_2ebackcache_2egroupD_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebackcache_2egroupD_clo;
V g_heff_2ebuild_2ebackcache_2egroupIn(V, V, V, V, V);
V g_heff_2ebuild_2ebackcache_2egroupIn_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebackcache_2egroupIn_clo;
V g_heff_2ebuild_2ebackcache_2egroupText(V, V, V);
V g_heff_2ebuild_2ebackcache_2egroupText_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebackcache_2egroupText_clo;
V g_heff_2ebuild_2ebackcache_2ejsD(V, V);
V g_heff_2ebuild_2ebackcache_2ejsD_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebackcache_2ejsD_clo;
V g_heff_2ebuild_2ebackcache_2ejsText(V, V);
V g_heff_2ebuild_2ebackcache_2ejsText_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebackcache_2ejsText_clo;
V g_heff_2ebuild_2ebackcache_2elastDotGo(V, V, V);
V g_heff_2ebuild_2ebackcache_2elastDotGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebackcache_2elastDotGo_clo;
HeffT2 g_heff_2ebuild_2ebackcache_2emadeOf_24cpr(V, V, V);
V g_heff_2ebuild_2ebackcache_2emadeT(V);
V g_heff_2ebuild_2ebackcache_2emadeT_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebackcache_2emadeT_clo;
V g_heff_2ebuild_2ebackcache_2emoduleIn(V, V);
V g_heff_2ebuild_2ebackcache_2emoduleIn_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebackcache_2emoduleIn_clo;
V g_heff_2ebuild_2ebackcache_2enoBack_get(void);
V g_heff_2ebuild_2ebackcache_2epairsGo(V, V);
V g_heff_2ebuild_2ebackcache_2epairsGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebackcache_2epairsGo_clo;
HeffT2 g_heff_2ebuild_2ebackcache_2erawGot_24cpr(V, V, V);
V g_heff_2ebuild_2ebackcache_2eunitD(V, V);
V g_heff_2ebuild_2ebackcache_2eunitD_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebackcache_2eunitD_clo;
V g_heff_2ebuild_2ebackcache_2eunitText(V);
V g_heff_2ebuild_2ebackcache_2eunitText_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebackcache_2eunitText_clo;
V g_heff_2ebuild_2ebackcache_2eversion_get(void);
V g_heff_2ebuild_2edecoder_2ebind_24s823677936x1444069277(V, V, V);
V g_heff_2ebuild_2edecoder_2ebind_24s823677936x1444069277_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edecoder_2ebind_24s823677936x1444069277_clo;
HeffT2 g_heff_2ebuild_2edecoder_2efail_24cpr(V, V);
HeffT2 g_heff_2ebuild_2edecoder_2eint_24cpr(V, V);
HeffT2 g_heff_2ebuild_2edecoder_2estr_24cpr(V, V);
HeffT2 g_heff_2ebuild_2edecoder_2etimes_24s1444395529x927023430_24cpr(V, V, V);
HeffT2 g_heff_2ebuild_2edecoder_2etimes_24s1603230686x1883420273_24cpr(V, V, V);
HeffT2 g_heff_2ebuild_2edecoder_2etimes_24s1861622792x1526156306_24cpr(V, V, V);
HeffT2 g_heff_2ebuild_2edecoder_2etimes_24s364931774x210987922_24cpr(V, V, V);
HeffT2 g_heff_2ebuild_2edecoder_2etimes_24s372484702x1286645721_24cpr(V, V, V);
HeffT2 g_heff_2ebuild_2edecoder_2etimes_24s700921301x1216293995_24cpr(V, V, V);
HeffT2 g_heff_2ebuild_2edecoder_2etimes_24s98296704x1684150820_24cpr(V, V, V);
HeffT2 g_heff_2ebuild_2edecoder_2ewhole_24cpr(V, V, V);
HeffT2 g_heff_2ebuild_2edecoder_2eword_24cpr(V, V);
V g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091(V, V);
V g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_clo;
V g_heff_2ecompile_2eirtext_2etakeExpr_get(void);
HeffT2 g_list_2efind_24s1990539953x112149757_24cpr(V, V);
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24s1103469845x1474178821(V, V, V);
V g_list_2efoldl_24s1103469845x1474178821_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1103469845x1474178821_clo;
V g_list_2efoldl_24s1111588856x1684976655(V, V);
V g_list_2efoldl_24s1111588856x1684976655_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1111588856x1684976655_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1494296198x1800016121(V, V, V);
V g_list_2efoldl_24s1494296198x1800016121_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1494296198x1800016121_clo;
V g_list_2efoldl_24s425699049x1164890302(V, V, V);
V g_list_2efoldl_24s425699049x1164890302_entry(V self, V *a);
extern Clo g_list_2efoldl_24s425699049x1164890302_clo;
V g_list_2efoldl_24s497871705x469972998(V, V);
V g_list_2efoldl_24s497871705x469972998_entry(V self, V *a);
extern Clo g_list_2efoldl_24s497871705x469972998_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2efoldl_24s788343806x1528994845(V, V, V);
V g_list_2efoldl_24s788343806x1528994845_entry(V self, V *a);
extern Clo g_list_2efoldl_24s788343806x1528994845_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1173914895x100384474(V);
V g_list_2emap_24s1173914895x100384474_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24f1085359736x1262841716(V, V);
V g_prelude_2e_2b_2b_24f1085359736x1262841716_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f1085359736x1262841716_clo;
V g_prelude_2e_2b_2b_24f1815933030x829523367(V, V);
V g_prelude_2e_2b_2b_24f1815933030x829523367_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f1815933030x829523367_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_std_2emap_2eempty_get(void);
V g_std_2emap_2einsert_24s1305793909x1049798133(V, V, V);
V g_std_2emap_2einsert_24s1305793909x1049798133_entry(V self, V *a);
extern Clo g_std_2emap_2einsert_24s1305793909x1049798133_clo;
HeffT2 g_std_2emap_2elookup_24s1654411661x99037275_24cpr(V, V);
HeffT2 g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(V, V);
V g_std_2emap_2esize(V);
V g_std_2emap_2esize_entry(V self, V *a);
extern Clo g_std_2emap_2esize_clo;
V g_std_2emap_2etoListOnto(V, V);
V g_std_2emap_2etoListOnto_entry(V self, V *a);
extern Clo g_std_2emap_2etoListOnto_clo;
HEFF_LIT(g_heff_2ebuild_2ebackcache_2eversion_str0, 14, "heff-backend/5");

static V g_heff_2ebuild_2ebackcache_2eversion_val;
static HEFF_ONCE g_heff_2ebuild_2ebackcache_2eversion_st;
static V g_heff_2ebuild_2ebackcache_2eversion_init(void) {
  return ((V)&g_heff_2ebuild_2ebackcache_2eversion_str0);
}
V g_heff_2ebuild_2ebackcache_2eversion_get(void) {
  if (HEFF_DONE(g_heff_2ebuild_2ebackcache_2eversion_st)) return g_heff_2ebuild_2ebackcache_2eversion_val;
  return heff_global(&g_heff_2ebuild_2ebackcache_2eversion_val, &g_heff_2ebuild_2ebackcache_2eversion_st, g_heff_2ebuild_2ebackcache_2eversion_init);
}
HEFF_LIT(g_heff_2ebuild_2ebackcache_2ebackDir_str0, 2, "b1");

static V g_heff_2ebuild_2ebackcache_2ebackDir_val;
static HEFF_ONCE g_heff_2ebuild_2ebackcache_2ebackDir_st;
static V g_heff_2ebuild_2ebackcache_2ebackDir_init(void) {
  return ((V)&g_heff_2ebuild_2ebackcache_2ebackDir_str0);
}
V g_heff_2ebuild_2ebackcache_2ebackDir_get(void) {
  if (HEFF_DONE(g_heff_2ebuild_2ebackcache_2ebackDir_st)) return g_heff_2ebuild_2ebackcache_2ebackDir_val;
  return heff_global(&g_heff_2ebuild_2ebackcache_2ebackDir_val, &g_heff_2ebuild_2ebackcache_2ebackDir_st, g_heff_2ebuild_2ebackcache_2ebackDir_init);
}
HEFF_LIT(g_heff_2ebuild_2ebackcache_2epairsGo_str0, 1, ":");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2epairsGo_str1, 1, ":");
Clo g_heff_2ebuild_2ebackcache_2epairsGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebackcache_2epairsGo_entry, 2, 0};

V g_heff_2ebuild_2ebackcache_2epairsGo(V v_x1_240, V v_rest_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return v_rest_241;
  }
  case TAG_Cons: {
    V v_p_242 = heff_field(v_x1_240, 0);
    V v_ps_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_rest_244 = (g_heff_2ebuild_2ebackcache_2epairsGo(v_ps_243, v_rest_241));
    switch (heff_tag_of(v_p_242)) {
    case TAG_MkPair: {
      V v_a_245 = heff_field(v_p_242, 0);
      V v_b_246 = heff_field(v_p_242, 1);
      heff_take_n(v_p_242, 3ULL, 2);
      V v_t_247 = heff_intShow(heff_strLength_lent(v_a_245, 0));
      V v_t_248 = heff_strAppend(v_t_247, heff_strAppend(((V)&g_heff_2ebuild_2ebackcache_2epairsGo_str0), v_a_245));
      V v_t_249 = heff_intShow(heff_strLength_lent(v_b_246, 0));
      V v_t_2410 = heff_strAppend(v_t_249, heff_strAppend(((V)&g_heff_2ebuild_2ebackcache_2epairsGo_str1), v_b_246));
      return heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_t_248, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2410, v_rest_244})});
    }
    default: return heff_nomatch(v_p_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2ebackcache_2epairsGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ebackcache_2epairsGo(a[0], a[1]);
}
HEFF_LIT(g_heff_2ebuild_2ebackcache_2eunitText_str0, 1, "t");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2eunitText_str1, 1, "f");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2eunitText_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2eunitText_str3, 1, " ");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2eunitText_str4, 1, ":");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2eunitText_str5, 1, "t");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2eunitText_str6, 1, "f");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2eunitText_str7, 1, ":");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2eunitText_str8, 1, ":");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2eunitText_str9, 1, " ");
Clo g_heff_2ebuild_2ebackcache_2eunitText_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebackcache_2eunitText_entry, 1, 0};

V g_heff_2ebuild_2ebackcache_2eunitText(V v_u_240) {
top: ;
  V v_s_241 = heff_get_n(heff_dup(heff_rfield(v_u_240, 0)), 0, 4);
  V v_s_242 = heff_take_field(v_u_240, 1);
  V v_xs_243 = heff_take_field(v_u_240, 2);
  V v_t_244 = heff_take_field(v_u_240, 3);
  V v_t_245;
  if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
    heff_drop(v_t_244);
    v_t_245 = ((V)&g_heff_2ebuild_2ebackcache_2eunitText_str0);
  } else {
    heff_drop(v_t_244);
    v_t_245 = ((V)&g_heff_2ebuild_2ebackcache_2eunitText_str1);
  }
  V v_t_246 = heff_intShow(heff_take_field(v_u_240, 4));
  V v_t_247 = heff_get_n(heff_dup(heff_rfield(v_u_240, 0)), 1, 4);
  V v_x2_248 = (g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091(v_t_247, NTAG(TAG_Nil)));
  V v_s_2411;
  switch (heff_tag_of(v_x2_248)) {
  case TAG_Nil: {
    v_s_2411 = ((V)&g_heff_2ebuild_2ebackcache_2eunitText_str2);
    break;
  }
  case TAG_Cons: {
    V v_x_249 = heff_field(v_x2_248, 0);
    V v_xs_2410 = heff_field(v_x2_248, 1);
    heff_take_n(v_x2_248, 3ULL, 2);
    v_s_2411 = ({ V a_0 = ((V)&g_heff_2ebuild_2ebackcache_2eunitText_str3); V a_1 = v_x_249; V a_2 = v_xs_2410; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2410); r_; });
    break;
  }
  default: heff_nomatch(v_x2_248);
  }
  V v_t_2412 = heff_intShow(heff_strLength_lent(v_s_2411, 0));
  V v_t_2413 = heff_strAppend(v_t_2412, heff_strAppend(((V)&g_heff_2ebuild_2ebackcache_2eunitText_str4), v_s_2411));
  V v_t_2414 = heff_get_n(heff_dup(heff_rfield(v_u_240, 0)), 2, 4);
  V v_t_2415;
  if ((heff_dup(v_t_2414) == NTAG(TAG_True))) {
    heff_drop(v_t_2414);
    v_t_2415 = ((V)&g_heff_2ebuild_2ebackcache_2eunitText_str5);
  } else {
    heff_drop(v_t_2414);
    v_t_2415 = ((V)&g_heff_2ebuild_2ebackcache_2eunitText_str6);
  }
  V v_ps_2416 = heff_get_n(heff_get_n(v_u_240, 0, 5), 3, 4);
  V v_t_2417 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_ps_2416));
  V v_t_2418 = (g_heff_2ebuild_2ebackcache_2epairsGo(v_ps_2416, NTAG(TAG_Nil)));
  V v_t_2419 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_t_2417), v_t_2418});
  V v_t_2420 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2413, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2415, v_t_2419})});
  V v_rest_2421 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_245, heff_tag_n(TAG_Cons, 2, (V[]){v_t_246, v_t_2420})});
  V v_t_2422 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_243));
  V v_t_2423 = heff_intShow(v_t_2422);
  V v_t_2424 = (g_prelude_2e_2b_2b_24f1815933030x829523367(v_rest_2421, v_xs_243));
  V v_t_2425 = heff_intShow(heff_strLength_lent(v_s_241, 0));
  V v_t_2426 = heff_strAppend(v_t_2425, heff_strAppend(((V)&g_heff_2ebuild_2ebackcache_2eunitText_str7), v_s_241));
  V v_t_2427 = heff_intShow(heff_strLength_lent(v_s_242, 0));
  V v_t_2428 = heff_strAppend(v_t_2427, heff_strAppend(((V)&g_heff_2ebuild_2ebackcache_2eunitText_str8), v_s_242));
  V v_t_2429 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2428, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2423, v_t_2424})});
  return ({ V a_0 = ((V)&g_heff_2ebuild_2ebackcache_2eunitText_str9); V a_1 = v_t_2426; V a_2 = v_t_2429; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop_tag(v_t_2429, 2); r_; });
}
V g_heff_2ebuild_2ebackcache_2eunitText_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ebackcache_2eunitText(a[0]);
}
HEFF_LIT(g_heff_2ebuild_2ebackcache_2emadeT_str0, 1, "n");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2emadeT_str1, 0, "");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2emadeT_str2, 1, " ");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2emadeT_str3, 1, ":");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2emadeT_str4, 1, "j");
Clo g_heff_2ebuild_2ebackcache_2emadeT_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebackcache_2emadeT_entry, 1, 0};

V g_heff_2ebuild_2ebackcache_2emadeT(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nothing: {
    return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ebackcache_2emadeT_str0), NTAG(TAG_Nil)});
  }
  case TAG_Just: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_MkPair: {
      V v_b_242 = heff_field(v_x11_241, 0);
      V v_t_243 = heff_field(v_x11_241, 1);
      V v_x2_244 = (g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091(heff_dup(v_b_242), NTAG(TAG_Nil)));
      V v_s_247;
      switch (heff_tag_of(v_x2_244)) {
      case TAG_Nil: {
        v_s_247 = ((V)&g_heff_2ebuild_2ebackcache_2emadeT_str1);
        break;
      }
      case TAG_Cons: {
        V v_x_245 = heff_field(v_x2_244, 0);
        V v_xs_246 = heff_field(v_x2_244, 1);
        heff_take_n(v_x2_244, 3ULL, 2);
        v_s_247 = ({ V a_0 = ((V)&g_heff_2ebuild_2ebackcache_2emadeT_str2); V a_1 = v_x_245; V a_2 = v_xs_246; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_246); r_; });
        break;
      }
      default: heff_nomatch(v_x2_244);
      }
      V v_t_248 = heff_intShow(heff_strLength_lent(v_s_247, 0));
      V v_t_249 = heff_strAppend(v_t_248, heff_strAppend(((V)&g_heff_2ebuild_2ebackcache_2emadeT_str3), v_s_247));
      V v_t_2410 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_t_243));
      V v_t_2411 = (g_heff_2ebuild_2ebackcache_2epairsGo(heff_dup(v_t_243), NTAG(TAG_Nil)));
      V v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_t_2410), v_t_2411});
      return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ebackcache_2emadeT_str4), heff_tag_n(TAG_Cons, 2, (V[]){v_t_249, v_t_2412})});
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2ebackcache_2emadeT_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ebackcache_2emadeT(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ebuild_2ebackcache_2ecopyText_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2ecopyText_str1, 1, " ");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2ecopyText_str2, 1, ":");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2ecopyText_str3, 1, ":");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2ecopyText_str4, 1, ":");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2ecopyText_str5, 1, "t");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2ecopyText_str6, 1, "f");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2ecopyText_str7, 1, " ");
Clo g_heff_2ebuild_2ebackcache_2ecopyText_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebackcache_2ecopyText_entry, 1, 0};

V g_heff_2ebuild_2ebackcache_2ecopyText(V v_c_240) {
top: ;
  V v_s_241 = heff_take_field(v_c_240, 0);
  V v_s_242 = heff_take_field(v_c_240, 1);
  V v_x2_243 = (g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091(heff_take_field(v_c_240, 2), NTAG(TAG_Nil)));
  V v_s_246;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    v_s_246 = ((V)&g_heff_2ebuild_2ebackcache_2ecopyText_str0);
    break;
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_xs_245 = heff_field(v_x2_243, 1);
    heff_take_n(v_x2_243, 3ULL, 2);
    v_s_246 = ({ V a_0 = ((V)&g_heff_2ebuild_2ebackcache_2ecopyText_str1); V a_1 = v_x_244; V a_2 = v_xs_245; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_245); r_; });
    break;
  }
  default: heff_nomatch(v_x2_243);
  }
  V v_t_247 = (g_heff_2ebuild_2ebackcache_2emadeT(heff_rfield(v_c_240, 5)));
  V v_t_248 = heff_intShow(heff_strLength_lent(v_s_241, 0));
  V v_t_249 = heff_strAppend(v_t_248, heff_strAppend(((V)&g_heff_2ebuild_2ebackcache_2ecopyText_str2), v_s_241));
  V v_t_2410 = heff_intShow(heff_strLength_lent(v_s_242, 0));
  V v_t_2411 = heff_strAppend(v_t_2410, heff_strAppend(((V)&g_heff_2ebuild_2ebackcache_2ecopyText_str3), v_s_242));
  V v_t_2412 = heff_intShow(heff_strLength_lent(v_s_246, 0));
  V v_t_2413 = heff_strAppend(v_t_2412, heff_strAppend(((V)&g_heff_2ebuild_2ebackcache_2ecopyText_str4), v_s_246));
  V v_t_2414 = heff_intShow(heff_take_field(v_c_240, 3));
  V v_t_2415 = heff_get_n(v_c_240, 4, 6);
  V v_t_2416;
  if ((heff_dup(v_t_2415) == NTAG(TAG_True))) {
    heff_drop(v_t_2415);
    v_t_2416 = ((V)&g_heff_2ebuild_2ebackcache_2ecopyText_str5);
  } else {
    heff_drop(v_t_2415);
    v_t_2416 = ((V)&g_heff_2ebuild_2ebackcache_2ecopyText_str6);
  }
  V v_t_2417 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2414, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2416, v_t_247})});
  V v_t_2418 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2411, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2413, v_t_2417})});
  return ({ V a_0 = ((V)&g_heff_2ebuild_2ebackcache_2ecopyText_str7); V a_1 = v_t_249; V a_2 = v_t_2418; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop_tag(v_t_2418, 2); r_; });
}
V g_heff_2ebuild_2ebackcache_2ecopyText_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ebackcache_2ecopyText(a[0]);
}
HEFF_LIT(g_heff_2ebuild_2ebackcache_2eemitText_str0, 1, ":");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2eemitText_str1, 1, ":");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2eemitText_str2, 1, " ");
Clo g_heff_2ebuild_2ebackcache_2eemitText_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebackcache_2eemitText_entry, 2, 0};

V g_heff_2ebuild_2ebackcache_2eemitText(V v_key_240, V v_k_241) {
top: ;
  V v_s_242 = heff_take_field(v_k_241, 0);
  V v_xs_243 = heff_take_field(v_k_241, 1);
  V v_xs_244 = heff_take_field(v_k_241, 2);
  V v_xs_245 = heff_take_field(v_k_241, 3);
  V v_xs_246 = heff_take_field(v_k_241, 4);
  V v_xs_247 = heff_take_field(v_k_241, 5);
  V v_xs_248 = heff_take_field(v_k_241, 6);
  V v_xs_249 = heff_get_n(v_k_241, 7, 8);
  V v_t_2410 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_249));
  V v_t_2411 = (g_prelude_2e_2b_2b_24f1815933030x829523367(NTAG(TAG_Nil), v_xs_249));
  V v_rest_2412 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_t_2410), v_t_2411});
  V v_t_2413 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_248));
  V v_t_2414 = (g_prelude_2e_2b_2b_24f1815933030x829523367(v_rest_2412, v_xs_248));
  V v_rest_2415 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_t_2413), v_t_2414});
  V v_t_2416 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_247));
  V v_t_2417 = (g_prelude_2e_2b_2b_24f1815933030x829523367(v_rest_2415, v_xs_247));
  V v_rest_2418 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_t_2416), v_t_2417});
  V v_t_2419 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_246));
  V v_t_2420 = (g_prelude_2e_2b_2b_24f1815933030x829523367(v_rest_2418, v_xs_246));
  V v_rest_2421 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_t_2419), v_t_2420});
  V v_t_2422 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_245));
  V v_t_2423 = (g_prelude_2e_2b_2b_24f1815933030x829523367(v_rest_2421, v_xs_245));
  V v_rest_2424 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_t_2422), v_t_2423});
  V v_t_2425 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_244));
  V v_t_2426 = (g_prelude_2e_2b_2b_24f1815933030x829523367(v_rest_2424, v_xs_244));
  V v_rest_2427 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_t_2425), v_t_2426});
  V v_t_2428 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_243));
  V v_t_2429 = heff_intShow(v_t_2428);
  V v_t_2430 = (g_prelude_2e_2b_2b_24f1815933030x829523367(v_rest_2427, v_xs_243));
  V v_t_2431 = heff_intShow(heff_strLength_lent(v_key_240, 0));
  V v_t_2432 = heff_strAppend(v_t_2431, heff_strAppend(((V)&g_heff_2ebuild_2ebackcache_2eemitText_str0), v_key_240));
  V v_t_2433 = heff_intShow(heff_strLength_lent(v_s_242, 0));
  V v_t_2434 = heff_strAppend(v_t_2433, heff_strAppend(((V)&g_heff_2ebuild_2ebackcache_2eemitText_str1), v_s_242));
  V v_t_2435 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2434, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2429, v_t_2430})});
  return ({ V a_0 = ((V)&g_heff_2ebuild_2ebackcache_2eemitText_str2); V a_1 = v_t_2432; V a_2 = v_t_2435; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop_tag(v_t_2435, 2); r_; });
}
V g_heff_2ebuild_2ebackcache_2eemitText_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ebackcache_2eemitText(a[0], a[1]);
}
HEFF_LIT(g_heff_2ebuild_2ebackcache_2ejsText_str0, 1, ":");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2ejsText_str1, 1, ":");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2ejsText_str2, 1, " ");
Clo g_heff_2ebuild_2ebackcache_2ejsText_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebackcache_2ejsText_entry, 2, 0};

V g_heff_2ebuild_2ebackcache_2ejsText(V v_key_240, V v_k_241) {
top: ;
  V v_s_242 = heff_take_field(v_k_241, 0);
  V v_xs_243 = heff_take_field(v_k_241, 1);
  V v_xs_244 = heff_take_field(v_k_241, 2);
  V v_xs_245 = heff_take_field(v_k_241, 3);
  V v_xs_246 = heff_get_n(v_k_241, 4, 5);
  V v_t_247 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_246));
  V v_t_248 = (g_prelude_2e_2b_2b_24f1815933030x829523367(NTAG(TAG_Nil), v_xs_246));
  V v_rest_249 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_t_247), v_t_248});
  V v_t_2410 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_245));
  V v_t_2411 = (g_prelude_2e_2b_2b_24f1815933030x829523367(v_rest_249, v_xs_245));
  V v_rest_2412 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_t_2410), v_t_2411});
  V v_t_2413 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_244));
  V v_t_2414 = (g_prelude_2e_2b_2b_24f1815933030x829523367(v_rest_2412, v_xs_244));
  V v_rest_2415 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_t_2413), v_t_2414});
  V v_t_2416 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_243));
  V v_t_2417 = heff_intShow(v_t_2416);
  V v_t_2418 = (g_prelude_2e_2b_2b_24f1815933030x829523367(v_rest_2415, v_xs_243));
  V v_t_2419 = heff_intShow(heff_strLength_lent(v_key_240, 0));
  V v_t_2420 = heff_strAppend(v_t_2419, heff_strAppend(((V)&g_heff_2ebuild_2ebackcache_2ejsText_str0), v_key_240));
  V v_t_2421 = heff_intShow(heff_strLength_lent(v_s_242, 0));
  V v_t_2422 = heff_strAppend(v_t_2421, heff_strAppend(((V)&g_heff_2ebuild_2ebackcache_2ejsText_str1), v_s_242));
  V v_t_2423 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2422, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2417, v_t_2418})});
  return ({ V a_0 = ((V)&g_heff_2ebuild_2ebackcache_2ejsText_str2); V a_1 = v_t_2420; V a_2 = v_t_2423; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop_tag(v_t_2423, 2); r_; });
}
V g_heff_2ebuild_2ebackcache_2ejsText_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ebackcache_2ejsText(a[0], a[1]);
}

HeffT2 g_heff_2ebuild_2ebackcache_2erawGot_24cpr(V v_s_240, V v_i_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nothing: {
    heff_drop(v_i_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Just: {
    V v_x31_243 = heff_field(v_x3_242, 0);
    switch (heff_tag_of(v_x31_243)) {
    case TAG_MkPair: {
      V v_x_244 = heff_field(v_x31_243, 0);
      V v_j_245 = heff_field(v_x31_243, 1);
      V v_t_249;
      if (heff_intLt_c_lent(v_i_241, v_j_245, 0)) {
        V v_t_247 = heff_strByteAt(heff_dup(v_s_240), heff_intSub(heff_dup(v_j_245), MK_INT(1LL)));
        if ((heff_unbox_word(v_t_247) == ((int64_t)32ULL))) {
          v_t_249 = heff_intSub(heff_dup(v_j_245), MK_INT(1LL));
        } else {
          v_t_249 = heff_dup(v_j_245);
        }
      } else {
        v_t_249 = heff_dup(v_j_245);
      }
      V v_t_2410 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_dup(v_x_244), heff_strSlice_lent(v_s_240, v_i_241, v_t_249, 6)});
      V v_f_2411 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2410, heff_dup(v_j_245)});
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2411}});
    }
    default: return ((HeffT2){{heff_nomatch(v_x31_243)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x3_242)}});
  }
}
V g_heff_2ebuild_2ebackcache_2eunitD_lam2(V self, V *args);
V g_heff_2ebuild_2ebackcache_2eunitD_lam1(V self, V *args);
V g_heff_2ebuild_2ebackcache_2eunitD_lam0(V self, V *args);
Clo g_heff_2ebuild_2ebackcache_2eunitD_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebackcache_2eunitD_entry, 2, 0};

V g_heff_2ebuild_2ebackcache_2eunitD(V v_s_240, V v_i_241) {
top: ;
  HeffT2 v_t_242 = (g_heff_2ebuild_2edecoder_2estr_24cpr(v_s_240, v_i_241));
  {
    V v_field_244 = v_t_242.f[1];
    int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
    if ((v_tag_243 == ((int64_t)0ULL))) {
      V v_x31_246 = v_field_244;
      switch (heff_tag_of(v_x31_246)) {
      case TAG_MkPair: {
        V v_x_247 = heff_field(v_x31_246, 0);
        V v_j_248 = heff_field(v_x31_246, 1);
        heff_take_n(v_x31_246, 3ULL, 2);
        HeffT2 v_t_249 = (g_heff_2ebuild_2edecoder_2estr_24cpr(v_s_240, v_j_248));
        {
          V v_field_2411 = v_t_249.f[1];
          int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
          if ((v_tag_2410 == ((int64_t)0ULL))) {
            V v_x31_2413 = v_field_2411;
            switch (heff_tag_of(v_x31_2413)) {
            case TAG_MkPair: {
              V v_x_2414 = heff_field(v_x31_2413, 0);
              V v_j_2415 = heff_field(v_x31_2413, 1);
              heff_take_n(v_x31_2413, 3ULL, 2);
              HeffT2 v_t_2416 = (g_heff_2ebuild_2edecoder_2eint_24cpr(v_s_240, v_j_2415));
              {
                V v_field_2418 = v_t_2416.f[1];
                int64_t v_tag_2417 = ((int64_t)v_t_2416.f[0]);
                if ((v_tag_2417 == ((int64_t)0ULL))) {
                  V v_x31_2420 = v_field_2418;
                  switch (heff_tag_of(v_x31_2420)) {
                  case TAG_MkPair: {
                    V v_x_2421 = heff_field(v_x31_2420, 0);
                    V v_j_2422 = heff_field(v_x31_2420, 1);
                    heff_take_n(v_x31_2420, 3ULL, 2);
                    HeffT2 v_t_2423 = (g_heff_2ebuild_2edecoder_2etimes_24s1603230686x1883420273_24cpr(v_x_2421, v_s_240, v_j_2422));
                    {
                      V v_field_2425 = v_t_2423.f[1];
                      int64_t v_tag_2424 = ((int64_t)v_t_2423.f[0]);
                      if ((v_tag_2424 == ((int64_t)0ULL))) {
                        V v_x31_2427 = v_field_2425;
                        switch (heff_tag_of(v_x31_2427)) {
                        case TAG_MkPair: {
                          V v_x_2428 = heff_field(v_x31_2427, 0);
                          V v_j_2429 = heff_field(v_x31_2427, 1);
                          heff_take_n(v_x31_2427, 3ULL, 2);
                          return (g_heff_2ebuild_2edecoder_2ebind_24s823677936x1444069277(heff_clo_n(g_heff_2ebuild_2ebackcache_2eunitD_lam0, 3, 3, (V[]){v_x_247, v_x_2414, v_x_2428}), v_s_240, v_j_2429));
                        }
                        default: return heff_nomatch(v_x31_2427);
                        }
                      } else {
                        heff_drop(v_s_240);
                        heff_drop(v_x_247);
                        heff_drop(v_x_2414);
                        heff_drop(v_field_2425);
                        return NTAG(TAG_Nothing);
                      }
                    }
                  }
                  default: return heff_nomatch(v_x31_2420);
                  }
                } else {
                  heff_drop(v_s_240);
                  heff_drop(v_x_247);
                  heff_drop(v_x_2414);
                  heff_drop(v_field_2418);
                  return NTAG(TAG_Nothing);
                }
              }
            }
            default: return heff_nomatch(v_x31_2413);
            }
          } else {
            heff_drop(v_s_240);
            heff_drop(v_x_247);
            heff_drop(v_field_2411);
            return NTAG(TAG_Nothing);
          }
        }
      }
      default: return heff_nomatch(v_x31_246);
      }
    } else {
      heff_drop(v_s_240);
      heff_drop(v_field_244);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_heff_2ebuild_2ebackcache_2eunitD_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ebackcache_2eunitD(a[0], a[1]);
}
V g_heff_2ebuild_2ebackcache_2eunitD_lam2(V self, V *args) {
  V v_u_2464 = args[0];
  V v_x_2445 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2464);
  HeffT2 v_t_2465 = (g_heff_2ebuild_2edecoder_2ewhole_24cpr(heff_dup(g_heff_2ecompile_2eirtext_2etakeExpr_get()), v_x_2445, MK_INT(0LL)));
  {
    V v_field_2467 = v_t_2465.f[1];
    int64_t v_tag_2466 = ((int64_t)v_t_2465.f[0]);
    if ((v_tag_2466 == ((int64_t)0ULL))) {
      V v_x11_2469 = v_field_2467;
      switch (heff_tag_of(v_x11_2469)) {
      case TAG_MkPair: {
        V v_x_2470 = heff_field(v_x11_2469, 0);
        heff_take_n(v_x11_2469, 1ULL, 2);
        return heff_tag_n(TAG_Just, 1, (V[]){v_x_2470});
      }
      default: return heff_nomatch(v_x11_2469);
      }
    } else {
      heff_drop(v_field_2467);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_heff_2ebuild_2ebackcache_2eunitD_lam1(V self, V *args) {
  V v_safe_2447 = args[0];
  V v_s_2448 = args[1];
  V v_i_2449 = args[2];
  V v_x_247 = heff_env(self)[0];
  V v_x_2414 = heff_env(self)[1];
  V v_x_2445 = heff_env(self)[2];
  V v_sgSafe_2430 = heff_env(self)[3];
  V v_x_2438 = heff_env(self)[4];
  V v_x_2428 = heff_env(self)[5];
  heff_clo_take(self, 6);
  HeffT2 v_t_2450 = (g_heff_2ebuild_2edecoder_2eint_24cpr(v_s_2448, v_i_2449));
  {
    V v_field_2452 = v_t_2450.f[1];
    int64_t v_tag_2451 = ((int64_t)v_t_2450.f[0]);
    if ((v_tag_2451 == ((int64_t)0ULL))) {
      V v_x31_2454 = v_field_2452;
      switch (heff_tag_of(v_x31_2454)) {
      case TAG_MkPair: {
        V v_x_2455 = heff_field(v_x31_2454, 0);
        V v_j_2456 = heff_field(v_x31_2454, 1);
        V v_ru_24x31_2454_24MkPair = heff_take_reuse_n(v_x31_2454, 3ULL, 2);
        HeffT2 v_t_2457 = ({ V a_0 = v_x_2455; V a_1 = v_s_2448; V a_2 = v_j_2456; HeffT2 r_ = (g_heff_2ebuild_2edecoder_2etimes_24s98296704x1684150820_24cpr(a_0, a_1, a_2)); heff_drop(v_s_2448); r_; });
        {
          V v_field_2459 = v_t_2457.f[1];
          int64_t v_tag_2458 = ((int64_t)v_t_2457.f[0]);
          if ((v_tag_2458 == ((int64_t)0ULL))) {
            V v_x31_2461 = v_field_2459;
            switch (heff_tag_of(v_x31_2461)) {
            case TAG_MkPair: {
              V v_x_2462 = heff_field(v_x31_2461, 0);
              V v_j_2463 = heff_field(v_x31_2461, 1);
              heff_take_n(v_x31_2461, 3ULL, 2);
              V v_t_2472 = heff_rec_n(2, shape_def__refs, (V[]){heff_rec_n(7, shape_key__name__body__safe__touched__sgSafe__sgTotal, (V[]){v_x_247, v_x_2414, heff_clo_n(g_heff_2ebuild_2ebackcache_2eunitD_lam2, 1, 1, (V[]){v_x_2445}), v_safe_2447, v_x_2462, v_sgSafe_2430, v_x_2438}), v_x_2428});
              return heff_tag_n(TAG_Just, 1, (V[]){heff_tag_at_n(v_ru_24x31_2454_24MkPair, TAG_MkPair, 2, (V[]){v_t_2472, v_j_2463})});
            }
            default: return heff_nomatch(v_x31_2461);
            }
          } else {
            heff_drop(v_safe_2447);
            heff_drop(v_x_247);
            heff_drop(v_x_2414);
            heff_drop(v_x_2445);
            heff_drop(v_sgSafe_2430);
            heff_drop(v_x_2438);
            heff_drop(v_x_2428);
            heff_drop_cell(v_ru_24x31_2454_24MkPair, 2);
            heff_drop(v_field_2459);
            return NTAG(TAG_Nothing);
          }
        }
      }
      default: return heff_nomatch(v_x31_2454);
      }
    } else {
      heff_drop(v_safe_2447);
      heff_drop(v_s_2448);
      heff_drop(v_x_247);
      heff_drop(v_x_2414);
      heff_drop(v_x_2445);
      heff_drop(v_sgSafe_2430);
      heff_drop(v_x_2438);
      heff_drop(v_x_2428);
      heff_drop(v_field_2452);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_heff_2ebuild_2ebackcache_2eunitD_lam0(V self, V *args) {
  V v_sgSafe_2430 = args[0];
  V v_s_2431 = args[1];
  V v_i_2432 = args[2];
  V v_x_247 = heff_env(self)[0];
  V v_x_2414 = heff_env(self)[1];
  V v_x_2428 = heff_env(self)[2];
  heff_clo_take(self, 3);
  HeffT2 v_t_2433 = (g_heff_2ebuild_2edecoder_2eint_24cpr(v_s_2431, v_i_2432));
  {
    V v_field_2435 = v_t_2433.f[1];
    int64_t v_tag_2434 = ((int64_t)v_t_2433.f[0]);
    if ((v_tag_2434 == ((int64_t)0ULL))) {
      V v_x31_2437 = v_field_2435;
      switch (heff_tag_of(v_x31_2437)) {
      case TAG_MkPair: {
        V v_x_2438 = heff_field(v_x31_2437, 0);
        V v_j_2439 = heff_field(v_x31_2437, 1);
        heff_take_n(v_x31_2437, 3ULL, 2);
        HeffT2 v_t_2440 = (g_heff_2ebuild_2edecoder_2estr_24cpr(v_s_2431, v_j_2439));
        {
          V v_field_2442 = v_t_2440.f[1];
          int64_t v_tag_2441 = ((int64_t)v_t_2440.f[0]);
          if ((v_tag_2441 == ((int64_t)0ULL))) {
            V v_x31_2444 = v_field_2442;
            switch (heff_tag_of(v_x31_2444)) {
            case TAG_MkPair: {
              V v_x_2445 = heff_field(v_x31_2444, 0);
              V v_j_2446 = heff_field(v_x31_2444, 1);
              heff_take_n(v_x31_2444, 3ULL, 2);
              return (g_heff_2ebuild_2edecoder_2ebind_24s823677936x1444069277(heff_clo_n(g_heff_2ebuild_2ebackcache_2eunitD_lam1, 3, 6, (V[]){v_x_247, v_x_2414, v_x_2445, v_sgSafe_2430, v_x_2438, v_x_2428}), v_s_2431, v_j_2446));
            }
            default: return heff_nomatch(v_x31_2444);
            }
          } else {
            heff_drop(v_sgSafe_2430);
            heff_drop(v_s_2431);
            heff_drop(v_x_247);
            heff_drop(v_x_2414);
            heff_drop(v_x_2428);
            heff_drop(v_x_2438);
            heff_drop(v_field_2442);
            return NTAG(TAG_Nothing);
          }
        }
      }
      default: return heff_nomatch(v_x31_2437);
      }
    } else {
      heff_drop(v_sgSafe_2430);
      heff_drop(v_s_2431);
      heff_drop(v_x_247);
      heff_drop(v_x_2414);
      heff_drop(v_x_2428);
      heff_drop(v_field_2435);
      return NTAG(TAG_Nothing);
    }
  }
}
Clo g_heff_2ebuild_2ebackcache_2egroupD_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebackcache_2egroupD_entry, 2, 0};

V g_heff_2ebuild_2ebackcache_2egroupD(V v_s_240, V v_i_241) {
top: ;
  HeffT2 v_t_242 = (g_heff_2ebuild_2edecoder_2estr_24cpr(v_s_240, v_i_241));
  {
    V v_field_244 = v_t_242.f[1];
    int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
    if ((v_tag_243 == ((int64_t)0ULL))) {
      V v_x31_246 = v_field_244;
      switch (heff_tag_of(v_x31_246)) {
      case TAG_MkPair: {
        V v_x_247 = heff_field(v_x31_246, 0);
        V v_j_248 = heff_field(v_x31_246, 1);
        V v_ru_24x31_246_24MkPair = heff_take_reuse_n(v_x31_246, 3ULL, 2);
        HeffT2 v_t_249 = (g_heff_2ebuild_2edecoder_2estr_24cpr(v_s_240, v_j_248));
        {
          V v_field_2411 = v_t_249.f[1];
          int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
          if ((v_tag_2410 == ((int64_t)0ULL))) {
            V v_x31_2413 = v_field_2411;
            switch (heff_tag_of(v_x31_2413)) {
            case TAG_MkPair: {
              V v_x_2414 = heff_field(v_x31_2413, 0);
              V v_j_2415 = heff_field(v_x31_2413, 1);
              heff_take_n(v_x31_2413, 3ULL, 2);
              HeffT2 v_t_2416 = (g_heff_2ebuild_2edecoder_2eint_24cpr(v_s_240, v_j_2415));
              {
                V v_field_2418 = v_t_2416.f[1];
                int64_t v_tag_2417 = ((int64_t)v_t_2416.f[0]);
                if ((v_tag_2417 == ((int64_t)0ULL))) {
                  V v_x31_2420 = v_field_2418;
                  switch (heff_tag_of(v_x31_2420)) {
                  case TAG_MkPair: {
                    V v_x_2421 = heff_field(v_x31_2420, 0);
                    V v_j_2422 = heff_field(v_x31_2420, 1);
                    heff_take_n(v_x31_2420, 3ULL, 2);
                    HeffT2 v_t_2423 = (g_heff_2ebuild_2edecoder_2etimes_24s1444395529x927023430_24cpr(v_x_2421, v_s_240, v_j_2422));
                    {
                      V v_field_2425 = v_t_2423.f[1];
                      int64_t v_tag_2424 = ((int64_t)v_t_2423.f[0]);
                      if ((v_tag_2424 == ((int64_t)0ULL))) {
                        V v_x31_2427 = v_field_2425;
                        switch (heff_tag_of(v_x31_2427)) {
                        case TAG_MkPair: {
                          V v_x_2428 = heff_field(v_x31_2427, 0);
                          V v_j_2429 = heff_field(v_x31_2427, 1);
                          heff_take_n(v_x31_2427, 3ULL, 2);
                          V v_t_2430 = heff_tag_at_n(v_ru_24x31_246_24MkPair, TAG_MkPair, 2, (V[]){heff_rec_n(3, shape_owner__ver__units, (V[]){v_x_247, v_x_2414, v_x_2428}), v_j_2429});
                          return heff_tag_n(TAG_Just, 1, (V[]){v_t_2430});
                        }
                        default: return heff_nomatch(v_x31_2427);
                        }
                      } else {
                        heff_drop(v_x_247);
                        heff_drop_cell(v_ru_24x31_246_24MkPair, 2);
                        heff_drop(v_x_2414);
                        heff_drop(v_field_2425);
                        return NTAG(TAG_Nothing);
                      }
                    }
                  }
                  default: return heff_nomatch(v_x31_2420);
                  }
                } else {
                  heff_drop(v_s_240);
                  heff_drop(v_x_247);
                  heff_drop_cell(v_ru_24x31_246_24MkPair, 2);
                  heff_drop(v_x_2414);
                  heff_drop(v_field_2418);
                  return NTAG(TAG_Nothing);
                }
              }
            }
            default: return heff_nomatch(v_x31_2413);
            }
          } else {
            heff_drop(v_s_240);
            heff_drop(v_x_247);
            heff_drop_cell(v_ru_24x31_246_24MkPair, 2);
            heff_drop(v_field_2411);
            return NTAG(TAG_Nothing);
          }
        }
      }
      default: return heff_nomatch(v_x31_246);
      }
    } else {
      heff_drop(v_s_240);
      heff_drop(v_field_244);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_heff_2ebuild_2ebackcache_2egroupD_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ebackcache_2egroupD(a[0], a[1]);
}
HEFF_LIT(g_heff_2ebuild_2ebackcache_2emadeOf_24cpr_str0, 1, "j");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2emadeOf_24cpr_str1, 1, "n");
V g_heff_2ebuild_2ebackcache_2emadeOf_24cpr_lam0(V self, V *args);

HeffT2 g_heff_2ebuild_2ebackcache_2emadeOf_24cpr(V v_x1_240, V v_z_241, V v_z_242) {
top: ;
  if (heff_strEq_c_lent(v_x1_240, ((V)&g_heff_2ebuild_2ebackcache_2emadeOf_24cpr_str0), 2)) {
    HeffT2 v_t_244 = (g_heff_2ebuild_2edecoder_2estr_24cpr(v_z_241, v_z_242));
    {
      V v_field_246 = v_t_244.f[1];
      int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
      if ((v_tag_245 == ((int64_t)0ULL))) {
        V v_x31_248 = v_field_246;
        switch (heff_tag_of(v_x31_248)) {
        case TAG_MkPair: {
          V v_x_249 = heff_field(v_x31_248, 0);
          V v_j_2410 = heff_field(v_x31_248, 1);
          V v_ru_24x31_248_24MkPair = heff_take_reuse_n(v_x31_248, 3ULL, 2);
          HeffT2 v_t_2411 = (g_heff_2ebuild_2edecoder_2eint_24cpr(v_z_241, v_j_2410));
          {
            V v_field_2413 = v_t_2411.f[1];
            int64_t v_tag_2412 = ((int64_t)v_t_2411.f[0]);
            if ((v_tag_2412 == ((int64_t)0ULL))) {
              V v_x31_2415 = v_field_2413;
              switch (heff_tag_of(v_x31_2415)) {
              case TAG_MkPair: {
                V v_x_2416 = heff_field(v_x31_2415, 0);
                V v_j_2417 = heff_field(v_x31_2415, 1);
                heff_take_n(v_x31_2415, 3ULL, 2);
                HeffT2 v_t_2418 = (g_heff_2ebuild_2edecoder_2etimes_24s98296704x1684150820_24cpr(v_x_2416, v_z_241, v_j_2417));
                {
                  V v_field_2420 = v_t_2418.f[1];
                  int64_t v_tag_2419 = ((int64_t)v_t_2418.f[0]);
                  if ((v_tag_2419 == ((int64_t)0ULL))) {
                    V v_x31_2422 = v_field_2420;
                    switch (heff_tag_of(v_x31_2422)) {
                    case TAG_MkPair: {
                      V v_x_2423 = heff_field(v_x31_2422, 0);
                      V v_j_2424 = heff_field(v_x31_2422, 1);
                      heff_take_n(v_x31_2422, 3ULL, 2);
                      V v_t_2433 = heff_tag_n(TAG_Just, 1, (V[]){heff_rec_n(2, shape_body__touched, (V[]){heff_clo_n(g_heff_2ebuild_2ebackcache_2emadeOf_24cpr_lam0, 1, 1, (V[]){v_x_249}), v_x_2423})});
                      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24x31_248_24MkPair, TAG_MkPair, 2, (V[]){v_t_2433, v_j_2424})}});
                    }
                    default: return ((HeffT2){{heff_nomatch(v_x31_2422)}});
                    }
                  } else {
                    heff_drop(v_x_249);
                    heff_drop_cell(v_ru_24x31_248_24MkPair, 2);
                    heff_drop(v_field_2420);
                    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                  }
                }
              }
              default: return ((HeffT2){{heff_nomatch(v_x31_2415)}});
              }
            } else {
              heff_drop(v_x_249);
              heff_drop_cell(v_ru_24x31_248_24MkPair, 2);
              heff_drop(v_field_2413);
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
            }
          }
        }
        default: return ((HeffT2){{heff_nomatch(v_x31_248)}});
        }
      } else {
        heff_drop(v_field_246);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    }
  } else {
    if (heff_strEq_c_lent(v_x1_240, ((V)&g_heff_2ebuild_2ebackcache_2emadeOf_24cpr_str1), 2)) {
      V v_t_2435 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nothing), v_z_242});
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2435}});
    } else {
      return ({ V a_0 = v_z_241; V a_1 = v_z_242; HeffT2 r_ = (g_heff_2ebuild_2edecoder_2efail_24cpr(a_0, a_1)); heff_drop(v_z_242); r_; });
    }
  }
}
V g_heff_2ebuild_2ebackcache_2emadeOf_24cpr_lam0(V self, V *args) {
  V v_u_2425 = args[0];
  V v_x_249 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2425);
  HeffT2 v_t_2426 = (g_heff_2ebuild_2edecoder_2ewhole_24cpr(heff_dup(g_heff_2ecompile_2eirtext_2etakeExpr_get()), v_x_249, MK_INT(0LL)));
  {
    V v_field_2428 = v_t_2426.f[1];
    int64_t v_tag_2427 = ((int64_t)v_t_2426.f[0]);
    if ((v_tag_2427 == ((int64_t)0ULL))) {
      V v_x11_2430 = v_field_2428;
      switch (heff_tag_of(v_x11_2430)) {
      case TAG_MkPair: {
        V v_x_2431 = heff_field(v_x11_2430, 0);
        heff_take_n(v_x11_2430, 1ULL, 2);
        return heff_tag_n(TAG_Just, 1, (V[]){v_x_2431});
      }
      default: return heff_nomatch(v_x11_2430);
      }
    } else {
      heff_drop(v_field_2428);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_heff_2ebuild_2ebackcache_2ecopyD_lam1(V self, V *args);
V g_heff_2ebuild_2ebackcache_2ecopyD_lam0(V self, V *args);
Clo g_heff_2ebuild_2ebackcache_2ecopyD_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebackcache_2ecopyD_entry, 2, 0};

V g_heff_2ebuild_2ebackcache_2ecopyD(V v_s_240, V v_i_241) {
top: ;
  HeffT2 v_t_242 = (g_heff_2ebuild_2edecoder_2estr_24cpr(v_s_240, v_i_241));
  {
    V v_field_244 = v_t_242.f[1];
    int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
    if ((v_tag_243 == ((int64_t)0ULL))) {
      V v_x31_246 = v_field_244;
      switch (heff_tag_of(v_x31_246)) {
      case TAG_MkPair: {
        V v_x_247 = heff_field(v_x31_246, 0);
        V v_j_248 = heff_field(v_x31_246, 1);
        heff_take_n(v_x31_246, 3ULL, 2);
        HeffT2 v_t_249 = (g_heff_2ebuild_2edecoder_2estr_24cpr(v_s_240, v_j_248));
        {
          V v_field_2411 = v_t_249.f[1];
          int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
          if ((v_tag_2410 == ((int64_t)0ULL))) {
            V v_x31_2413 = v_field_2411;
            switch (heff_tag_of(v_x31_2413)) {
            case TAG_MkPair: {
              V v_x_2414 = heff_field(v_x31_2413, 0);
              V v_j_2415 = heff_field(v_x31_2413, 1);
              heff_take_n(v_x31_2413, 3ULL, 2);
              HeffT2 v_t_2416 = (g_heff_2ebuild_2edecoder_2estr_24cpr(v_s_240, v_j_2415));
              {
                V v_field_2418 = v_t_2416.f[1];
                int64_t v_tag_2417 = ((int64_t)v_t_2416.f[0]);
                if ((v_tag_2417 == ((int64_t)0ULL))) {
                  V v_x31_2420 = v_field_2418;
                  switch (heff_tag_of(v_x31_2420)) {
                  case TAG_MkPair: {
                    V v_x_2421 = heff_field(v_x31_2420, 0);
                    V v_j_2422 = heff_field(v_x31_2420, 1);
                    heff_take_n(v_x31_2420, 3ULL, 2);
                    HeffT2 v_t_2423 = (g_heff_2ebuild_2edecoder_2eint_24cpr(v_s_240, v_j_2422));
                    {
                      V v_field_2425 = v_t_2423.f[1];
                      int64_t v_tag_2424 = ((int64_t)v_t_2423.f[0]);
                      if ((v_tag_2424 == ((int64_t)0ULL))) {
                        V v_x31_2427 = v_field_2425;
                        switch (heff_tag_of(v_x31_2427)) {
                        case TAG_MkPair: {
                          V v_x_2428 = heff_field(v_x31_2427, 0);
                          V v_j_2429 = heff_field(v_x31_2427, 1);
                          heff_take_n(v_x31_2427, 3ULL, 2);
                          return (g_heff_2ebuild_2edecoder_2ebind_24s823677936x1444069277(heff_clo_n(g_heff_2ebuild_2ebackcache_2ecopyD_lam0, 3, 4, (V[]){v_x_247, v_x_2414, v_x_2421, v_x_2428}), v_s_240, v_j_2429));
                        }
                        default: return heff_nomatch(v_x31_2427);
                        }
                      } else {
                        heff_drop(v_s_240);
                        heff_drop(v_x_247);
                        heff_drop(v_x_2414);
                        heff_drop(v_x_2421);
                        heff_drop(v_field_2425);
                        return NTAG(TAG_Nothing);
                      }
                    }
                  }
                  default: return heff_nomatch(v_x31_2420);
                  }
                } else {
                  heff_drop(v_s_240);
                  heff_drop(v_x_247);
                  heff_drop(v_x_2414);
                  heff_drop(v_field_2418);
                  return NTAG(TAG_Nothing);
                }
              }
            }
            default: return heff_nomatch(v_x31_2413);
            }
          } else {
            heff_drop(v_s_240);
            heff_drop(v_x_247);
            heff_drop(v_field_2411);
            return NTAG(TAG_Nothing);
          }
        }
      }
      default: return heff_nomatch(v_x31_246);
      }
    } else {
      heff_drop(v_s_240);
      heff_drop(v_field_244);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_heff_2ebuild_2ebackcache_2ecopyD_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ebackcache_2ecopyD(a[0], a[1]);
}
V g_heff_2ebuild_2ebackcache_2ecopyD_lam1(V self, V *args) {
  V v_u_2447 = args[0];
  V v_x_2421 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2447);
  HeffT2 v_t_2448 = (g_heff_2ebuild_2edecoder_2ewhole_24cpr(heff_dup(g_heff_2ecompile_2eirtext_2etakeExpr_get()), v_x_2421, MK_INT(0LL)));
  {
    V v_field_2450 = v_t_2448.f[1];
    int64_t v_tag_2449 = ((int64_t)v_t_2448.f[0]);
    if ((v_tag_2449 == ((int64_t)0ULL))) {
      V v_x11_2452 = v_field_2450;
      switch (heff_tag_of(v_x11_2452)) {
      case TAG_MkPair: {
        V v_x_2453 = heff_field(v_x11_2452, 0);
        heff_take_n(v_x11_2452, 1ULL, 2);
        return heff_tag_n(TAG_Just, 1, (V[]){v_x_2453});
      }
      default: return heff_nomatch(v_x11_2452);
      }
    } else {
      heff_drop(v_field_2450);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_heff_2ebuild_2ebackcache_2ecopyD_lam0(V self, V *args) {
  V v_safe_2430 = args[0];
  V v_s_2431 = args[1];
  V v_i_2432 = args[2];
  V v_x_247 = heff_env(self)[0];
  V v_x_2414 = heff_env(self)[1];
  V v_x_2421 = heff_env(self)[2];
  V v_x_2428 = heff_env(self)[3];
  heff_clo_take(self, 4);
  HeffT2 v_t_2433 = (g_heff_2ebuild_2edecoder_2eword_24cpr(v_s_2431, v_i_2432));
  {
    V v_field_2435 = v_t_2433.f[1];
    int64_t v_tag_2434 = ((int64_t)v_t_2433.f[0]);
    if ((v_tag_2434 == ((int64_t)0ULL))) {
      V v_x31_2437 = v_field_2435;
      switch (heff_tag_of(v_x31_2437)) {
      case TAG_MkPair: {
        V v_x_2438 = heff_field(v_x31_2437, 0);
        V v_j_2439 = heff_field(v_x31_2437, 1);
        V v_ru_24x31_2437_24MkPair = heff_take_reuse_n(v_x31_2437, 3ULL, 2);
        HeffT2 v_t_2440 = ({ V a_0 = v_x_2438; V a_1 = v_s_2431; V a_2 = v_j_2439; HeffT2 r_ = (g_heff_2ebuild_2ebackcache_2emadeOf_24cpr(a_0, a_1, a_2)); heff_drop(v_x_2438); heff_drop(v_s_2431); r_; });
        {
          V v_field_2442 = v_t_2440.f[1];
          int64_t v_tag_2441 = ((int64_t)v_t_2440.f[0]);
          if ((v_tag_2441 == ((int64_t)0ULL))) {
            V v_x31_2444 = v_field_2442;
            switch (heff_tag_of(v_x31_2444)) {
            case TAG_MkPair: {
              V v_x_2445 = heff_field(v_x31_2444, 0);
              V v_j_2446 = heff_field(v_x31_2444, 1);
              V v_ru_24x31_2444_24MkPair = heff_take_reuse_n(v_x31_2444, 3ULL, 2);
              V v_t_2455 = heff_tag_at_n(v_ru_24x31_2437_24MkPair, TAG_MkPair, 2, (V[]){v_x_247, heff_rec_n(5, shape_ver__recipe__depth__safe__made, (V[]){v_x_2414, heff_clo_n(g_heff_2ebuild_2ebackcache_2ecopyD_lam1, 1, 1, (V[]){v_x_2421}), v_x_2428, v_safe_2430, v_x_2445})});
              return heff_tag_n(TAG_Just, 1, (V[]){heff_tag_at_n(v_ru_24x31_2444_24MkPair, TAG_MkPair, 2, (V[]){v_t_2455, v_j_2446})});
            }
            default: return heff_nomatch(v_x31_2444);
            }
          } else {
            heff_drop(v_safe_2430);
            heff_drop(v_x_247);
            heff_drop(v_x_2414);
            heff_drop(v_x_2421);
            heff_drop(v_x_2428);
            heff_drop_cell(v_ru_24x31_2437_24MkPair, 2);
            heff_drop(v_field_2442);
            return NTAG(TAG_Nothing);
          }
        }
      }
      default: return heff_nomatch(v_x31_2437);
      }
    } else {
      heff_drop(v_safe_2430);
      heff_drop(v_s_2431);
      heff_drop(v_x_247);
      heff_drop(v_x_2414);
      heff_drop(v_x_2421);
      heff_drop(v_x_2428);
      heff_drop(v_field_2435);
      return NTAG(TAG_Nothing);
    }
  }
}
Clo g_heff_2ebuild_2ebackcache_2eemitD_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebackcache_2eemitD_entry, 2, 0};

V g_heff_2ebuild_2ebackcache_2eemitD(V v_s_240, V v_i_241) {
top: ;
  HeffT2 v_t_242 = (g_heff_2ebuild_2edecoder_2estr_24cpr(v_s_240, v_i_241));
  {
    V v_field_244 = v_t_242.f[1];
    int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
    if ((v_tag_243 == ((int64_t)0ULL))) {
      V v_x31_246 = v_field_244;
      switch (heff_tag_of(v_x31_246)) {
      case TAG_MkPair: {
        V v_x_247 = heff_field(v_x31_246, 0);
        V v_j_248 = heff_field(v_x31_246, 1);
        V v_ru_24x31_246_24MkPair = heff_take_reuse_n(v_x31_246, 3ULL, 2);
        HeffT2 v_t_249 = (g_heff_2ebuild_2edecoder_2estr_24cpr(v_s_240, v_j_248));
        {
          V v_field_2411 = v_t_249.f[1];
          int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
          if ((v_tag_2410 == ((int64_t)0ULL))) {
            V v_x31_2413 = v_field_2411;
            switch (heff_tag_of(v_x31_2413)) {
            case TAG_MkPair: {
              V v_x_2414 = heff_field(v_x31_2413, 0);
              V v_j_2415 = heff_field(v_x31_2413, 1);
              V v_ru_24x31_2413_24MkPair = heff_take_reuse_n(v_x31_2413, 3ULL, 2);
              HeffT2 v_t_2416 = (g_heff_2ebuild_2edecoder_2eint_24cpr(v_s_240, v_j_2415));
              {
                V v_field_2418 = v_t_2416.f[1];
                int64_t v_tag_2417 = ((int64_t)v_t_2416.f[0]);
                if ((v_tag_2417 == ((int64_t)0ULL))) {
                  V v_x31_2420 = v_field_2418;
                  switch (heff_tag_of(v_x31_2420)) {
                  case TAG_MkPair: {
                    V v_x_2421 = heff_field(v_x31_2420, 0);
                    V v_j_2422 = heff_field(v_x31_2420, 1);
                    heff_take_n(v_x31_2420, 3ULL, 2);
                    HeffT2 v_t_2423 = (g_heff_2ebuild_2edecoder_2etimes_24s1603230686x1883420273_24cpr(v_x_2421, v_s_240, v_j_2422));
                    {
                      V v_field_2425 = v_t_2423.f[1];
                      int64_t v_tag_2424 = ((int64_t)v_t_2423.f[0]);
                      if ((v_tag_2424 == ((int64_t)0ULL))) {
                        V v_x31_2427 = v_field_2425;
                        switch (heff_tag_of(v_x31_2427)) {
                        case TAG_MkPair: {
                          V v_x_2428 = heff_field(v_x31_2427, 0);
                          V v_j_2429 = heff_field(v_x31_2427, 1);
                          heff_take_n(v_x31_2427, 3ULL, 2);
                          HeffT2 v_t_2430 = (g_heff_2ebuild_2edecoder_2eint_24cpr(v_s_240, v_j_2429));
                          {
                            V v_field_2432 = v_t_2430.f[1];
                            int64_t v_tag_2431 = ((int64_t)v_t_2430.f[0]);
                            if ((v_tag_2431 == ((int64_t)0ULL))) {
                              V v_x31_2434 = v_field_2432;
                              switch (heff_tag_of(v_x31_2434)) {
                              case TAG_MkPair: {
                                V v_x_2435 = heff_field(v_x31_2434, 0);
                                V v_j_2436 = heff_field(v_x31_2434, 1);
                                heff_take_n(v_x31_2434, 3ULL, 2);
                                HeffT2 v_t_2437 = (g_heff_2ebuild_2edecoder_2etimes_24s1603230686x1883420273_24cpr(v_x_2435, v_s_240, v_j_2436));
                                {
                                  V v_field_2439 = v_t_2437.f[1];
                                  int64_t v_tag_2438 = ((int64_t)v_t_2437.f[0]);
                                  if ((v_tag_2438 == ((int64_t)0ULL))) {
                                    V v_x31_2441 = v_field_2439;
                                    switch (heff_tag_of(v_x31_2441)) {
                                    case TAG_MkPair: {
                                      V v_x_2442 = heff_field(v_x31_2441, 0);
                                      V v_j_2443 = heff_field(v_x31_2441, 1);
                                      heff_take_n(v_x31_2441, 3ULL, 2);
                                      HeffT2 v_t_2444 = (g_heff_2ebuild_2edecoder_2eint_24cpr(v_s_240, v_j_2443));
                                      {
                                        V v_field_2446 = v_t_2444.f[1];
                                        int64_t v_tag_2445 = ((int64_t)v_t_2444.f[0]);
                                        if ((v_tag_2445 == ((int64_t)0ULL))) {
                                          V v_x31_2448 = v_field_2446;
                                          switch (heff_tag_of(v_x31_2448)) {
                                          case TAG_MkPair: {
                                            V v_x_2449 = heff_field(v_x31_2448, 0);
                                            V v_j_2450 = heff_field(v_x31_2448, 1);
                                            heff_take_n(v_x31_2448, 3ULL, 2);
                                            HeffT2 v_t_2451 = (g_heff_2ebuild_2edecoder_2etimes_24s1603230686x1883420273_24cpr(v_x_2449, v_s_240, v_j_2450));
                                            {
                                              V v_field_2453 = v_t_2451.f[1];
                                              int64_t v_tag_2452 = ((int64_t)v_t_2451.f[0]);
                                              if ((v_tag_2452 == ((int64_t)0ULL))) {
                                                V v_x31_2455 = v_field_2453;
                                                switch (heff_tag_of(v_x31_2455)) {
                                                case TAG_MkPair: {
                                                  V v_x_2456 = heff_field(v_x31_2455, 0);
                                                  V v_j_2457 = heff_field(v_x31_2455, 1);
                                                  heff_take_n(v_x31_2455, 3ULL, 2);
                                                  HeffT2 v_t_2458 = (g_heff_2ebuild_2edecoder_2eint_24cpr(v_s_240, v_j_2457));
                                                  {
                                                    V v_field_2460 = v_t_2458.f[1];
                                                    int64_t v_tag_2459 = ((int64_t)v_t_2458.f[0]);
                                                    if ((v_tag_2459 == ((int64_t)0ULL))) {
                                                      V v_x31_2462 = v_field_2460;
                                                      switch (heff_tag_of(v_x31_2462)) {
                                                      case TAG_MkPair: {
                                                        V v_x_2463 = heff_field(v_x31_2462, 0);
                                                        V v_j_2464 = heff_field(v_x31_2462, 1);
                                                        heff_take_n(v_x31_2462, 3ULL, 2);
                                                        HeffT2 v_t_2465 = (g_heff_2ebuild_2edecoder_2etimes_24s1603230686x1883420273_24cpr(v_x_2463, v_s_240, v_j_2464));
                                                        {
                                                          V v_field_2467 = v_t_2465.f[1];
                                                          int64_t v_tag_2466 = ((int64_t)v_t_2465.f[0]);
                                                          if ((v_tag_2466 == ((int64_t)0ULL))) {
                                                            V v_x31_2469 = v_field_2467;
                                                            switch (heff_tag_of(v_x31_2469)) {
                                                            case TAG_MkPair: {
                                                              V v_x_2470 = heff_field(v_x31_2469, 0);
                                                              V v_j_2471 = heff_field(v_x31_2469, 1);
                                                              heff_take_n(v_x31_2469, 3ULL, 2);
                                                              HeffT2 v_t_2472 = (g_heff_2ebuild_2edecoder_2eint_24cpr(v_s_240, v_j_2471));
                                                              {
                                                                V v_field_2474 = v_t_2472.f[1];
                                                                int64_t v_tag_2473 = ((int64_t)v_t_2472.f[0]);
                                                                if ((v_tag_2473 == ((int64_t)0ULL))) {
                                                                  V v_x31_2476 = v_field_2474;
                                                                  switch (heff_tag_of(v_x31_2476)) {
                                                                  case TAG_MkPair: {
                                                                    V v_x_2477 = heff_field(v_x31_2476, 0);
                                                                    V v_j_2478 = heff_field(v_x31_2476, 1);
                                                                    heff_take_n(v_x31_2476, 3ULL, 2);
                                                                    HeffT2 v_t_2479 = (g_heff_2ebuild_2edecoder_2etimes_24s1603230686x1883420273_24cpr(v_x_2477, v_s_240, v_j_2478));
                                                                    {
                                                                      V v_field_2481 = v_t_2479.f[1];
                                                                      int64_t v_tag_2480 = ((int64_t)v_t_2479.f[0]);
                                                                      if ((v_tag_2480 == ((int64_t)0ULL))) {
                                                                        V v_x31_2483 = v_field_2481;
                                                                        switch (heff_tag_of(v_x31_2483)) {
                                                                        case TAG_MkPair: {
                                                                          V v_x_2484 = heff_field(v_x31_2483, 0);
                                                                          V v_j_2485 = heff_field(v_x31_2483, 1);
                                                                          heff_take_n(v_x31_2483, 3ULL, 2);
                                                                          HeffT2 v_t_2486 = (g_heff_2ebuild_2edecoder_2eint_24cpr(v_s_240, v_j_2485));
                                                                          {
                                                                            V v_field_2488 = v_t_2486.f[1];
                                                                            int64_t v_tag_2487 = ((int64_t)v_t_2486.f[0]);
                                                                            if ((v_tag_2487 == ((int64_t)0ULL))) {
                                                                              V v_x31_2490 = v_field_2488;
                                                                              switch (heff_tag_of(v_x31_2490)) {
                                                                              case TAG_MkPair: {
                                                                                V v_x_2491 = heff_field(v_x31_2490, 0);
                                                                                V v_j_2492 = heff_field(v_x31_2490, 1);
                                                                                heff_take_n(v_x31_2490, 3ULL, 2);
                                                                                HeffT2 v_t_2493 = (g_heff_2ebuild_2edecoder_2etimes_24s1603230686x1883420273_24cpr(v_x_2491, v_s_240, v_j_2492));
                                                                                {
                                                                                  V v_field_2495 = v_t_2493.f[1];
                                                                                  int64_t v_tag_2494 = ((int64_t)v_t_2493.f[0]);
                                                                                  if ((v_tag_2494 == ((int64_t)0ULL))) {
                                                                                    V v_x31_2497 = v_field_2495;
                                                                                    switch (heff_tag_of(v_x31_2497)) {
                                                                                    case TAG_MkPair: {
                                                                                      V v_x_2498 = heff_field(v_x31_2497, 0);
                                                                                      V v_j_2499 = heff_field(v_x31_2497, 1);
                                                                                      heff_take_n(v_x31_2497, 3ULL, 2);
                                                                                      HeffT2 v_t_24100 = (g_heff_2ebuild_2edecoder_2eint_24cpr(v_s_240, v_j_2499));
                                                                                      {
                                                                                        V v_field_24102 = v_t_24100.f[1];
                                                                                        int64_t v_tag_24101 = ((int64_t)v_t_24100.f[0]);
                                                                                        if ((v_tag_24101 == ((int64_t)0ULL))) {
                                                                                          V v_x31_24104 = v_field_24102;
                                                                                          switch (heff_tag_of(v_x31_24104)) {
                                                                                          case TAG_MkPair: {
                                                                                            V v_x_24105 = heff_field(v_x31_24104, 0);
                                                                                            V v_j_24106 = heff_field(v_x31_24104, 1);
                                                                                            heff_take_n(v_x31_24104, 3ULL, 2);
                                                                                            HeffT2 v_t_24107 = (g_heff_2ebuild_2edecoder_2etimes_24s1603230686x1883420273_24cpr(v_x_24105, v_s_240, v_j_24106));
                                                                                            {
                                                                                              V v_field_24109 = v_t_24107.f[1];
                                                                                              int64_t v_tag_24108 = ((int64_t)v_t_24107.f[0]);
                                                                                              if ((v_tag_24108 == ((int64_t)0ULL))) {
                                                                                                V v_x31_24111 = v_field_24109;
                                                                                                switch (heff_tag_of(v_x31_24111)) {
                                                                                                case TAG_MkPair: {
                                                                                                  V v_x_24112 = heff_field(v_x31_24111, 0);
                                                                                                  V v_j_24113 = heff_field(v_x31_24111, 1);
                                                                                                  heff_take_n(v_x31_24111, 3ULL, 2);
                                                                                                  V v_t_24114 = heff_tag_at_n(v_ru_24x31_246_24MkPair, TAG_MkPair, 2, (V[]){v_x_247, heff_rec_n(8, shape_ver__protos__code__strs__lprotos__lams__shapes__prims, (V[]){v_x_2414, v_x_2428, v_x_2442, v_x_2456, v_x_2470, v_x_2484, v_x_2498, v_x_24112})});
                                                                                                  return heff_tag_n(TAG_Just, 1, (V[]){heff_tag_at_n(v_ru_24x31_2413_24MkPair, TAG_MkPair, 2, (V[]){v_t_24114, v_j_24113})});
                                                                                                }
                                                                                                default: return heff_nomatch(v_x31_24111);
                                                                                                }
                                                                                              } else {
                                                                                                heff_drop(v_x_247);
                                                                                                heff_drop_cell(v_ru_24x31_246_24MkPair, 2);
                                                                                                heff_drop(v_x_2414);
                                                                                                heff_drop_cell(v_ru_24x31_2413_24MkPair, 2);
                                                                                                heff_drop(v_x_2428);
                                                                                                heff_drop(v_x_2442);
                                                                                                heff_drop(v_x_2456);
                                                                                                heff_drop(v_x_2470);
                                                                                                heff_drop(v_x_2484);
                                                                                                heff_drop(v_x_2498);
                                                                                                heff_drop(v_field_24109);
                                                                                                return NTAG(TAG_Nothing);
                                                                                              }
                                                                                            }
                                                                                          }
                                                                                          default: return heff_nomatch(v_x31_24104);
                                                                                          }
                                                                                        } else {
                                                                                          heff_drop(v_x_247);
                                                                                          heff_drop_cell(v_ru_24x31_246_24MkPair, 2);
                                                                                          heff_drop(v_x_2414);
                                                                                          heff_drop_cell(v_ru_24x31_2413_24MkPair, 2);
                                                                                          heff_drop(v_x_2428);
                                                                                          heff_drop(v_x_2442);
                                                                                          heff_drop(v_x_2456);
                                                                                          heff_drop(v_x_2470);
                                                                                          heff_drop(v_x_2484);
                                                                                          heff_drop(v_x_2498);
                                                                                          heff_drop(v_field_24102);
                                                                                          return NTAG(TAG_Nothing);
                                                                                        }
                                                                                      }
                                                                                    }
                                                                                    default: return heff_nomatch(v_x31_2497);
                                                                                    }
                                                                                  } else {
                                                                                    heff_drop(v_x_247);
                                                                                    heff_drop_cell(v_ru_24x31_246_24MkPair, 2);
                                                                                    heff_drop(v_x_2414);
                                                                                    heff_drop_cell(v_ru_24x31_2413_24MkPair, 2);
                                                                                    heff_drop(v_x_2428);
                                                                                    heff_drop(v_x_2442);
                                                                                    heff_drop(v_x_2456);
                                                                                    heff_drop(v_x_2470);
                                                                                    heff_drop(v_x_2484);
                                                                                    heff_drop(v_field_2495);
                                                                                    return NTAG(TAG_Nothing);
                                                                                  }
                                                                                }
                                                                              }
                                                                              default: return heff_nomatch(v_x31_2490);
                                                                              }
                                                                            } else {
                                                                              heff_drop(v_x_247);
                                                                              heff_drop_cell(v_ru_24x31_246_24MkPair, 2);
                                                                              heff_drop(v_x_2414);
                                                                              heff_drop_cell(v_ru_24x31_2413_24MkPair, 2);
                                                                              heff_drop(v_x_2428);
                                                                              heff_drop(v_x_2442);
                                                                              heff_drop(v_x_2456);
                                                                              heff_drop(v_x_2470);
                                                                              heff_drop(v_x_2484);
                                                                              heff_drop(v_field_2488);
                                                                              return NTAG(TAG_Nothing);
                                                                            }
                                                                          }
                                                                        }
                                                                        default: return heff_nomatch(v_x31_2483);
                                                                        }
                                                                      } else {
                                                                        heff_drop(v_x_247);
                                                                        heff_drop_cell(v_ru_24x31_246_24MkPair, 2);
                                                                        heff_drop(v_x_2414);
                                                                        heff_drop_cell(v_ru_24x31_2413_24MkPair, 2);
                                                                        heff_drop(v_x_2428);
                                                                        heff_drop(v_x_2442);
                                                                        heff_drop(v_x_2456);
                                                                        heff_drop(v_x_2470);
                                                                        heff_drop(v_field_2481);
                                                                        return NTAG(TAG_Nothing);
                                                                      }
                                                                    }
                                                                  }
                                                                  default: return heff_nomatch(v_x31_2476);
                                                                  }
                                                                } else {
                                                                  heff_drop(v_x_247);
                                                                  heff_drop_cell(v_ru_24x31_246_24MkPair, 2);
                                                                  heff_drop(v_x_2414);
                                                                  heff_drop_cell(v_ru_24x31_2413_24MkPair, 2);
                                                                  heff_drop(v_x_2428);
                                                                  heff_drop(v_x_2442);
                                                                  heff_drop(v_x_2456);
                                                                  heff_drop(v_x_2470);
                                                                  heff_drop(v_field_2474);
                                                                  return NTAG(TAG_Nothing);
                                                                }
                                                              }
                                                            }
                                                            default: return heff_nomatch(v_x31_2469);
                                                            }
                                                          } else {
                                                            heff_drop(v_x_247);
                                                            heff_drop_cell(v_ru_24x31_246_24MkPair, 2);
                                                            heff_drop(v_x_2414);
                                                            heff_drop_cell(v_ru_24x31_2413_24MkPair, 2);
                                                            heff_drop(v_x_2428);
                                                            heff_drop(v_x_2442);
                                                            heff_drop(v_x_2456);
                                                            heff_drop(v_field_2467);
                                                            return NTAG(TAG_Nothing);
                                                          }
                                                        }
                                                      }
                                                      default: return heff_nomatch(v_x31_2462);
                                                      }
                                                    } else {
                                                      heff_drop(v_x_247);
                                                      heff_drop_cell(v_ru_24x31_246_24MkPair, 2);
                                                      heff_drop(v_x_2414);
                                                      heff_drop_cell(v_ru_24x31_2413_24MkPair, 2);
                                                      heff_drop(v_x_2428);
                                                      heff_drop(v_x_2442);
                                                      heff_drop(v_x_2456);
                                                      heff_drop(v_field_2460);
                                                      return NTAG(TAG_Nothing);
                                                    }
                                                  }
                                                }
                                                default: return heff_nomatch(v_x31_2455);
                                                }
                                              } else {
                                                heff_drop(v_x_247);
                                                heff_drop_cell(v_ru_24x31_246_24MkPair, 2);
                                                heff_drop(v_x_2414);
                                                heff_drop_cell(v_ru_24x31_2413_24MkPair, 2);
                                                heff_drop(v_x_2428);
                                                heff_drop(v_x_2442);
                                                heff_drop(v_field_2453);
                                                return NTAG(TAG_Nothing);
                                              }
                                            }
                                          }
                                          default: return heff_nomatch(v_x31_2448);
                                          }
                                        } else {
                                          heff_drop(v_x_247);
                                          heff_drop_cell(v_ru_24x31_246_24MkPair, 2);
                                          heff_drop(v_x_2414);
                                          heff_drop_cell(v_ru_24x31_2413_24MkPair, 2);
                                          heff_drop(v_x_2428);
                                          heff_drop(v_x_2442);
                                          heff_drop(v_field_2446);
                                          return NTAG(TAG_Nothing);
                                        }
                                      }
                                    }
                                    default: return heff_nomatch(v_x31_2441);
                                    }
                                  } else {
                                    heff_drop(v_x_247);
                                    heff_drop_cell(v_ru_24x31_246_24MkPair, 2);
                                    heff_drop(v_x_2414);
                                    heff_drop_cell(v_ru_24x31_2413_24MkPair, 2);
                                    heff_drop(v_x_2428);
                                    heff_drop(v_field_2439);
                                    return NTAG(TAG_Nothing);
                                  }
                                }
                              }
                              default: return heff_nomatch(v_x31_2434);
                              }
                            } else {
                              heff_drop(v_x_247);
                              heff_drop_cell(v_ru_24x31_246_24MkPair, 2);
                              heff_drop(v_x_2414);
                              heff_drop_cell(v_ru_24x31_2413_24MkPair, 2);
                              heff_drop(v_x_2428);
                              heff_drop(v_field_2432);
                              return NTAG(TAG_Nothing);
                            }
                          }
                        }
                        default: return heff_nomatch(v_x31_2427);
                        }
                      } else {
                        heff_drop(v_x_247);
                        heff_drop_cell(v_ru_24x31_246_24MkPair, 2);
                        heff_drop(v_x_2414);
                        heff_drop_cell(v_ru_24x31_2413_24MkPair, 2);
                        heff_drop(v_field_2425);
                        return NTAG(TAG_Nothing);
                      }
                    }
                  }
                  default: return heff_nomatch(v_x31_2420);
                  }
                } else {
                  heff_drop(v_x_247);
                  heff_drop_cell(v_ru_24x31_246_24MkPair, 2);
                  heff_drop(v_x_2414);
                  heff_drop_cell(v_ru_24x31_2413_24MkPair, 2);
                  heff_drop(v_field_2418);
                  return NTAG(TAG_Nothing);
                }
              }
            }
            default: return heff_nomatch(v_x31_2413);
            }
          } else {
            heff_drop(v_x_247);
            heff_drop_cell(v_ru_24x31_246_24MkPair, 2);
            heff_drop(v_field_2411);
            return NTAG(TAG_Nothing);
          }
        }
      }
      default: return heff_nomatch(v_x31_246);
      }
    } else {
      heff_drop(v_field_244);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_heff_2ebuild_2ebackcache_2eemitD_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ebackcache_2eemitD(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2ebuild_2ebackcache_2ejsD_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebackcache_2ejsD_entry, 2, 0};

V g_heff_2ebuild_2ebackcache_2ejsD(V v_s_240, V v_i_241) {
top: ;
  HeffT2 v_t_242 = (g_heff_2ebuild_2edecoder_2estr_24cpr(v_s_240, v_i_241));
  {
    V v_field_244 = v_t_242.f[1];
    int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
    if ((v_tag_243 == ((int64_t)0ULL))) {
      V v_x31_246 = v_field_244;
      switch (heff_tag_of(v_x31_246)) {
      case TAG_MkPair: {
        V v_x_247 = heff_field(v_x31_246, 0);
        V v_j_248 = heff_field(v_x31_246, 1);
        V v_ru_24x31_246_24MkPair = heff_take_reuse_n(v_x31_246, 3ULL, 2);
        HeffT2 v_t_249 = (g_heff_2ebuild_2edecoder_2estr_24cpr(v_s_240, v_j_248));
        {
          V v_field_2411 = v_t_249.f[1];
          int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
          if ((v_tag_2410 == ((int64_t)0ULL))) {
            V v_x31_2413 = v_field_2411;
            switch (heff_tag_of(v_x31_2413)) {
            case TAG_MkPair: {
              V v_x_2414 = heff_field(v_x31_2413, 0);
              V v_j_2415 = heff_field(v_x31_2413, 1);
              V v_ru_24x31_2413_24MkPair = heff_take_reuse_n(v_x31_2413, 3ULL, 2);
              HeffT2 v_t_2416 = (g_heff_2ebuild_2edecoder_2eint_24cpr(v_s_240, v_j_2415));
              {
                V v_field_2418 = v_t_2416.f[1];
                int64_t v_tag_2417 = ((int64_t)v_t_2416.f[0]);
                if ((v_tag_2417 == ((int64_t)0ULL))) {
                  V v_x31_2420 = v_field_2418;
                  switch (heff_tag_of(v_x31_2420)) {
                  case TAG_MkPair: {
                    V v_x_2421 = heff_field(v_x31_2420, 0);
                    V v_j_2422 = heff_field(v_x31_2420, 1);
                    heff_take_n(v_x31_2420, 3ULL, 2);
                    HeffT2 v_t_2423 = (g_heff_2ebuild_2edecoder_2etimes_24s1603230686x1883420273_24cpr(v_x_2421, v_s_240, v_j_2422));
                    {
                      V v_field_2425 = v_t_2423.f[1];
                      int64_t v_tag_2424 = ((int64_t)v_t_2423.f[0]);
                      if ((v_tag_2424 == ((int64_t)0ULL))) {
                        V v_x31_2427 = v_field_2425;
                        switch (heff_tag_of(v_x31_2427)) {
                        case TAG_MkPair: {
                          V v_x_2428 = heff_field(v_x31_2427, 0);
                          V v_j_2429 = heff_field(v_x31_2427, 1);
                          heff_take_n(v_x31_2427, 3ULL, 2);
                          HeffT2 v_t_2430 = (g_heff_2ebuild_2edecoder_2eint_24cpr(v_s_240, v_j_2429));
                          {
                            V v_field_2432 = v_t_2430.f[1];
                            int64_t v_tag_2431 = ((int64_t)v_t_2430.f[0]);
                            if ((v_tag_2431 == ((int64_t)0ULL))) {
                              V v_x31_2434 = v_field_2432;
                              switch (heff_tag_of(v_x31_2434)) {
                              case TAG_MkPair: {
                                V v_x_2435 = heff_field(v_x31_2434, 0);
                                V v_j_2436 = heff_field(v_x31_2434, 1);
                                heff_take_n(v_x31_2434, 3ULL, 2);
                                HeffT2 v_t_2437 = (g_heff_2ebuild_2edecoder_2etimes_24s1603230686x1883420273_24cpr(v_x_2435, v_s_240, v_j_2436));
                                {
                                  V v_field_2439 = v_t_2437.f[1];
                                  int64_t v_tag_2438 = ((int64_t)v_t_2437.f[0]);
                                  if ((v_tag_2438 == ((int64_t)0ULL))) {
                                    V v_x31_2441 = v_field_2439;
                                    switch (heff_tag_of(v_x31_2441)) {
                                    case TAG_MkPair: {
                                      V v_x_2442 = heff_field(v_x31_2441, 0);
                                      V v_j_2443 = heff_field(v_x31_2441, 1);
                                      heff_take_n(v_x31_2441, 3ULL, 2);
                                      HeffT2 v_t_2444 = (g_heff_2ebuild_2edecoder_2eint_24cpr(v_s_240, v_j_2443));
                                      {
                                        V v_field_2446 = v_t_2444.f[1];
                                        int64_t v_tag_2445 = ((int64_t)v_t_2444.f[0]);
                                        if ((v_tag_2445 == ((int64_t)0ULL))) {
                                          V v_x31_2448 = v_field_2446;
                                          switch (heff_tag_of(v_x31_2448)) {
                                          case TAG_MkPair: {
                                            V v_x_2449 = heff_field(v_x31_2448, 0);
                                            V v_j_2450 = heff_field(v_x31_2448, 1);
                                            heff_take_n(v_x31_2448, 3ULL, 2);
                                            HeffT2 v_t_2451 = (g_heff_2ebuild_2edecoder_2etimes_24s1603230686x1883420273_24cpr(v_x_2449, v_s_240, v_j_2450));
                                            {
                                              V v_field_2453 = v_t_2451.f[1];
                                              int64_t v_tag_2452 = ((int64_t)v_t_2451.f[0]);
                                              if ((v_tag_2452 == ((int64_t)0ULL))) {
                                                V v_x31_2455 = v_field_2453;
                                                switch (heff_tag_of(v_x31_2455)) {
                                                case TAG_MkPair: {
                                                  V v_x_2456 = heff_field(v_x31_2455, 0);
                                                  V v_j_2457 = heff_field(v_x31_2455, 1);
                                                  heff_take_n(v_x31_2455, 3ULL, 2);
                                                  HeffT2 v_t_2458 = (g_heff_2ebuild_2edecoder_2eint_24cpr(v_s_240, v_j_2457));
                                                  {
                                                    V v_field_2460 = v_t_2458.f[1];
                                                    int64_t v_tag_2459 = ((int64_t)v_t_2458.f[0]);
                                                    if ((v_tag_2459 == ((int64_t)0ULL))) {
                                                      V v_x31_2462 = v_field_2460;
                                                      switch (heff_tag_of(v_x31_2462)) {
                                                      case TAG_MkPair: {
                                                        V v_x_2463 = heff_field(v_x31_2462, 0);
                                                        V v_j_2464 = heff_field(v_x31_2462, 1);
                                                        heff_take_n(v_x31_2462, 3ULL, 2);
                                                        HeffT2 v_t_2465 = (g_heff_2ebuild_2edecoder_2etimes_24s1603230686x1883420273_24cpr(v_x_2463, v_s_240, v_j_2464));
                                                        {
                                                          V v_field_2467 = v_t_2465.f[1];
                                                          int64_t v_tag_2466 = ((int64_t)v_t_2465.f[0]);
                                                          if ((v_tag_2466 == ((int64_t)0ULL))) {
                                                            V v_x31_2469 = v_field_2467;
                                                            switch (heff_tag_of(v_x31_2469)) {
                                                            case TAG_MkPair: {
                                                              V v_x_2470 = heff_field(v_x31_2469, 0);
                                                              V v_j_2471 = heff_field(v_x31_2469, 1);
                                                              heff_take_n(v_x31_2469, 3ULL, 2);
                                                              V v_t_2472 = heff_tag_at_n(v_ru_24x31_246_24MkPair, TAG_MkPair, 2, (V[]){v_x_247, heff_rec_n(5, shape_ver__lines__params__refs__prims, (V[]){v_x_2414, v_x_2428, v_x_2442, v_x_2456, v_x_2470})});
                                                              return heff_tag_n(TAG_Just, 1, (V[]){heff_tag_at_n(v_ru_24x31_2413_24MkPair, TAG_MkPair, 2, (V[]){v_t_2472, v_j_2471})});
                                                            }
                                                            default: return heff_nomatch(v_x31_2469);
                                                            }
                                                          } else {
                                                            heff_drop(v_x_247);
                                                            heff_drop_cell(v_ru_24x31_246_24MkPair, 2);
                                                            heff_drop(v_x_2414);
                                                            heff_drop_cell(v_ru_24x31_2413_24MkPair, 2);
                                                            heff_drop(v_x_2428);
                                                            heff_drop(v_x_2442);
                                                            heff_drop(v_x_2456);
                                                            heff_drop(v_field_2467);
                                                            return NTAG(TAG_Nothing);
                                                          }
                                                        }
                                                      }
                                                      default: return heff_nomatch(v_x31_2462);
                                                      }
                                                    } else {
                                                      heff_drop(v_x_247);
                                                      heff_drop_cell(v_ru_24x31_246_24MkPair, 2);
                                                      heff_drop(v_x_2414);
                                                      heff_drop_cell(v_ru_24x31_2413_24MkPair, 2);
                                                      heff_drop(v_x_2428);
                                                      heff_drop(v_x_2442);
                                                      heff_drop(v_x_2456);
                                                      heff_drop(v_field_2460);
                                                      return NTAG(TAG_Nothing);
                                                    }
                                                  }
                                                }
                                                default: return heff_nomatch(v_x31_2455);
                                                }
                                              } else {
                                                heff_drop(v_x_247);
                                                heff_drop_cell(v_ru_24x31_246_24MkPair, 2);
                                                heff_drop(v_x_2414);
                                                heff_drop_cell(v_ru_24x31_2413_24MkPair, 2);
                                                heff_drop(v_x_2428);
                                                heff_drop(v_x_2442);
                                                heff_drop(v_field_2453);
                                                return NTAG(TAG_Nothing);
                                              }
                                            }
                                          }
                                          default: return heff_nomatch(v_x31_2448);
                                          }
                                        } else {
                                          heff_drop(v_x_247);
                                          heff_drop_cell(v_ru_24x31_246_24MkPair, 2);
                                          heff_drop(v_x_2414);
                                          heff_drop_cell(v_ru_24x31_2413_24MkPair, 2);
                                          heff_drop(v_x_2428);
                                          heff_drop(v_x_2442);
                                          heff_drop(v_field_2446);
                                          return NTAG(TAG_Nothing);
                                        }
                                      }
                                    }
                                    default: return heff_nomatch(v_x31_2441);
                                    }
                                  } else {
                                    heff_drop(v_x_247);
                                    heff_drop_cell(v_ru_24x31_246_24MkPair, 2);
                                    heff_drop(v_x_2414);
                                    heff_drop_cell(v_ru_24x31_2413_24MkPair, 2);
                                    heff_drop(v_x_2428);
                                    heff_drop(v_field_2439);
                                    return NTAG(TAG_Nothing);
                                  }
                                }
                              }
                              default: return heff_nomatch(v_x31_2434);
                              }
                            } else {
                              heff_drop(v_x_247);
                              heff_drop_cell(v_ru_24x31_246_24MkPair, 2);
                              heff_drop(v_x_2414);
                              heff_drop_cell(v_ru_24x31_2413_24MkPair, 2);
                              heff_drop(v_x_2428);
                              heff_drop(v_field_2432);
                              return NTAG(TAG_Nothing);
                            }
                          }
                        }
                        default: return heff_nomatch(v_x31_2427);
                        }
                      } else {
                        heff_drop(v_x_247);
                        heff_drop_cell(v_ru_24x31_246_24MkPair, 2);
                        heff_drop(v_x_2414);
                        heff_drop_cell(v_ru_24x31_2413_24MkPair, 2);
                        heff_drop(v_field_2425);
                        return NTAG(TAG_Nothing);
                      }
                    }
                  }
                  default: return heff_nomatch(v_x31_2420);
                  }
                } else {
                  heff_drop(v_x_247);
                  heff_drop_cell(v_ru_24x31_246_24MkPair, 2);
                  heff_drop(v_x_2414);
                  heff_drop_cell(v_ru_24x31_2413_24MkPair, 2);
                  heff_drop(v_field_2418);
                  return NTAG(TAG_Nothing);
                }
              }
            }
            default: return heff_nomatch(v_x31_2413);
            }
          } else {
            heff_drop(v_x_247);
            heff_drop_cell(v_ru_24x31_246_24MkPair, 2);
            heff_drop(v_field_2411);
            return NTAG(TAG_Nothing);
          }
        }
      }
      default: return heff_nomatch(v_x31_246);
      }
    } else {
      heff_drop(v_field_244);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_heff_2ebuild_2ebackcache_2ejsD_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ebackcache_2ejsD(a0, a[1]); heff_drop(a0); return r;
}

static V g_heff_2ebuild_2ebackcache_2enoBack_val;
static HEFF_ONCE g_heff_2ebuild_2ebackcache_2enoBack_st;
static V g_heff_2ebuild_2ebackcache_2enoBack_init(void) {
  return heff_rec_n(4, shape_groups__copies__emits__jss, (V[]){NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil)});
}
V g_heff_2ebuild_2ebackcache_2enoBack_get(void) {
  if (HEFF_DONE(g_heff_2ebuild_2ebackcache_2enoBack_st)) return g_heff_2ebuild_2ebackcache_2enoBack_val;
  return heff_global(&g_heff_2ebuild_2ebackcache_2enoBack_val, &g_heff_2ebuild_2ebackcache_2enoBack_st, g_heff_2ebuild_2ebackcache_2enoBack_init);
}
HEFF_LIT(g_heff_2ebuild_2ebackcache_2ebackD_24cpr_str0, 3, "end");

HeffT2 g_heff_2ebuild_2ebackcache_2ebackD_24cpr(V v_id_240, V v_s_241, V v_i_242) {
top: ;
  HeffT2 v_t_243 = (g_heff_2ebuild_2edecoder_2estr_24cpr(v_s_241, v_i_242));
  {
    V v_field_245 = v_t_243.f[1];
    int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
    if ((v_tag_244 == ((int64_t)0ULL))) {
      V v_x31_247 = v_field_245;
      switch (heff_tag_of(v_x31_247)) {
      case TAG_MkPair: {
        V v_x_248 = heff_field(v_x31_247, 0);
        V v_j_249 = heff_field(v_x31_247, 1);
        V v_ru_24x31_247_24MkPair = heff_take_reuse_n(v_x31_247, 3ULL, 2);
        if (heff_strEq_c(v_x_248, heff_dup(g_heff_2ebuild_2ebackcache_2eversion_get()))) {
          HeffT2 v_t_2411 = (g_heff_2ebuild_2edecoder_2estr_24cpr(v_s_241, v_j_249));
          {
            V v_field_2413 = v_t_2411.f[1];
            int64_t v_tag_2412 = ((int64_t)v_t_2411.f[0]);
            if ((v_tag_2412 == ((int64_t)0ULL))) {
              V v_x31_2415 = v_field_2413;
              switch (heff_tag_of(v_x31_2415)) {
              case TAG_MkPair: {
                V v_x_2416 = heff_field(v_x31_2415, 0);
                V v_j_2417 = heff_field(v_x31_2415, 1);
                heff_take_n(v_x31_2415, 3ULL, 2);
                if (heff_strEq_c_lent(v_x_2416, v_id_240, 1)) {
                  HeffT2 v_t_2419 = (g_heff_2ebuild_2edecoder_2eint_24cpr(v_s_241, v_j_2417));
                  {
                    V v_field_2421 = v_t_2419.f[1];
                    int64_t v_tag_2420 = ((int64_t)v_t_2419.f[0]);
                    if ((v_tag_2420 == ((int64_t)0ULL))) {
                      V v_x31_2423 = v_field_2421;
                      switch (heff_tag_of(v_x31_2423)) {
                      case TAG_MkPair: {
                        V v_x_2424 = heff_field(v_x31_2423, 0);
                        V v_j_2425 = heff_field(v_x31_2423, 1);
                        heff_take_n(v_x31_2423, 3ULL, 2);
                        HeffT2 v_t_2426 = (g_heff_2ebuild_2edecoder_2etimes_24s364931774x210987922_24cpr(v_x_2424, heff_dup(v_s_241), v_j_2425));
                        {
                          V v_field_2428 = v_t_2426.f[1];
                          int64_t v_tag_2427 = ((int64_t)v_t_2426.f[0]);
                          if ((v_tag_2427 == ((int64_t)0ULL))) {
                            V v_x31_2430 = v_field_2428;
                            switch (heff_tag_of(v_x31_2430)) {
                            case TAG_MkPair: {
                              V v_x_2431 = heff_field(v_x31_2430, 0);
                              V v_j_2432 = heff_field(v_x31_2430, 1);
                              heff_take_n(v_x31_2430, 3ULL, 2);
                              HeffT2 v_t_2433 = (g_heff_2ebuild_2edecoder_2eint_24cpr(v_s_241, v_j_2432));
                              {
                                V v_field_2435 = v_t_2433.f[1];
                                int64_t v_tag_2434 = ((int64_t)v_t_2433.f[0]);
                                if ((v_tag_2434 == ((int64_t)0ULL))) {
                                  V v_x31_2437 = v_field_2435;
                                  switch (heff_tag_of(v_x31_2437)) {
                                  case TAG_MkPair: {
                                    V v_x_2438 = heff_field(v_x31_2437, 0);
                                    V v_j_2439 = heff_field(v_x31_2437, 1);
                                    heff_take_n(v_x31_2437, 3ULL, 2);
                                    HeffT2 v_t_2440 = (g_heff_2ebuild_2edecoder_2etimes_24s1861622792x1526156306_24cpr(v_x_2438, heff_dup(v_s_241), v_j_2439));
                                    {
                                      V v_field_2442 = v_t_2440.f[1];
                                      int64_t v_tag_2441 = ((int64_t)v_t_2440.f[0]);
                                      if ((v_tag_2441 == ((int64_t)0ULL))) {
                                        V v_x31_2444 = v_field_2442;
                                        switch (heff_tag_of(v_x31_2444)) {
                                        case TAG_MkPair: {
                                          V v_x_2445 = heff_field(v_x31_2444, 0);
                                          V v_j_2446 = heff_field(v_x31_2444, 1);
                                          heff_take_n(v_x31_2444, 3ULL, 2);
                                          HeffT2 v_t_2447 = (g_heff_2ebuild_2edecoder_2eint_24cpr(v_s_241, v_j_2446));
                                          {
                                            V v_field_2449 = v_t_2447.f[1];
                                            int64_t v_tag_2448 = ((int64_t)v_t_2447.f[0]);
                                            if ((v_tag_2448 == ((int64_t)0ULL))) {
                                              V v_x31_2451 = v_field_2449;
                                              switch (heff_tag_of(v_x31_2451)) {
                                              case TAG_MkPair: {
                                                V v_x_2452 = heff_field(v_x31_2451, 0);
                                                V v_j_2453 = heff_field(v_x31_2451, 1);
                                                heff_take_n(v_x31_2451, 3ULL, 2);
                                                HeffT2 v_t_2454 = (g_heff_2ebuild_2edecoder_2etimes_24s372484702x1286645721_24cpr(v_x_2452, v_s_241, v_j_2453));
                                                {
                                                  V v_field_2456 = v_t_2454.f[1];
                                                  int64_t v_tag_2455 = ((int64_t)v_t_2454.f[0]);
                                                  if ((v_tag_2455 == ((int64_t)0ULL))) {
                                                    V v_x31_2458 = v_field_2456;
                                                    switch (heff_tag_of(v_x31_2458)) {
                                                    case TAG_MkPair: {
                                                      V v_x_2459 = heff_field(v_x31_2458, 0);
                                                      V v_j_2460 = heff_field(v_x31_2458, 1);
                                                      heff_take_n(v_x31_2458, 3ULL, 2);
                                                      HeffT2 v_t_2461 = (g_heff_2ebuild_2edecoder_2eint_24cpr(v_s_241, v_j_2460));
                                                      {
                                                        V v_field_2463 = v_t_2461.f[1];
                                                        int64_t v_tag_2462 = ((int64_t)v_t_2461.f[0]);
                                                        if ((v_tag_2462 == ((int64_t)0ULL))) {
                                                          V v_x31_2465 = v_field_2463;
                                                          switch (heff_tag_of(v_x31_2465)) {
                                                          case TAG_MkPair: {
                                                            V v_x_2466 = heff_field(v_x31_2465, 0);
                                                            V v_j_2467 = heff_field(v_x31_2465, 1);
                                                            heff_take_n(v_x31_2465, 3ULL, 2);
                                                            HeffT2 v_t_2468 = (g_heff_2ebuild_2edecoder_2etimes_24s700921301x1216293995_24cpr(v_x_2466, v_s_241, v_j_2467));
                                                            {
                                                              V v_field_2470 = v_t_2468.f[1];
                                                              int64_t v_tag_2469 = ((int64_t)v_t_2468.f[0]);
                                                              if ((v_tag_2469 == ((int64_t)0ULL))) {
                                                                V v_x31_2472 = v_field_2470;
                                                                switch (heff_tag_of(v_x31_2472)) {
                                                                case TAG_MkPair: {
                                                                  V v_x_2473 = heff_field(v_x31_2472, 0);
                                                                  V v_j_2474 = heff_field(v_x31_2472, 1);
                                                                  heff_take_n(v_x31_2472, 3ULL, 2);
                                                                  HeffT2 v_t_2475 = ({ V a_0 = v_s_241; V a_1 = v_j_2474; HeffT2 r_ = (g_heff_2ebuild_2edecoder_2estr_24cpr(a_0, a_1)); heff_drop(v_s_241); r_; });
                                                                  {
                                                                    V v_field_2477 = v_t_2475.f[1];
                                                                    int64_t v_tag_2476 = ((int64_t)v_t_2475.f[0]);
                                                                    if ((v_tag_2476 == ((int64_t)0ULL))) {
                                                                      V v_x31_2479 = v_field_2477;
                                                                      switch (heff_tag_of(v_x31_2479)) {
                                                                      case TAG_MkPair: {
                                                                        V v_x_2480 = heff_field(v_x31_2479, 0);
                                                                        V v_j_2481 = heff_field(v_x31_2479, 1);
                                                                        heff_take_n(v_x31_2479, 3ULL, 2);
                                                                        if (heff_strEq_c(v_x_2480, ((V)&g_heff_2ebuild_2ebackcache_2ebackD_24cpr_str0))) {
                                                                          V v_t_2483 = heff_tag_at_n(v_ru_24x31_247_24MkPair, TAG_MkPair, 2, (V[]){heff_rec_n(4, shape_groups__copies__emits__jss, (V[]){v_x_2431, v_x_2445, v_x_2459, v_x_2473}), v_j_2481});
                                                                          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2483}});
                                                                        } else {
                                                                          heff_drop_cell(v_ru_24x31_247_24MkPair, 2);
                                                                          heff_drop(v_x_2431);
                                                                          heff_drop(v_x_2445);
                                                                          heff_drop(v_x_2459);
                                                                          heff_drop(v_x_2473);
                                                                          heff_drop(v_j_2481);
                                                                          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                                                        }
                                                                      }
                                                                      default: return ((HeffT2){{heff_nomatch(v_x31_2479)}});
                                                                      }
                                                                    } else {
                                                                      heff_drop_cell(v_ru_24x31_247_24MkPair, 2);
                                                                      heff_drop(v_x_2431);
                                                                      heff_drop(v_x_2445);
                                                                      heff_drop(v_x_2459);
                                                                      heff_drop(v_x_2473);
                                                                      heff_drop(v_field_2477);
                                                                      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                                                    }
                                                                  }
                                                                }
                                                                default: return ((HeffT2){{heff_nomatch(v_x31_2472)}});
                                                                }
                                                              } else {
                                                                heff_drop(v_s_241);
                                                                heff_drop_cell(v_ru_24x31_247_24MkPair, 2);
                                                                heff_drop(v_x_2431);
                                                                heff_drop(v_x_2445);
                                                                heff_drop(v_x_2459);
                                                                heff_drop(v_field_2470);
                                                                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                                              }
                                                            }
                                                          }
                                                          default: return ((HeffT2){{heff_nomatch(v_x31_2465)}});
                                                          }
                                                        } else {
                                                          heff_drop(v_s_241);
                                                          heff_drop_cell(v_ru_24x31_247_24MkPair, 2);
                                                          heff_drop(v_x_2431);
                                                          heff_drop(v_x_2445);
                                                          heff_drop(v_x_2459);
                                                          heff_drop(v_field_2463);
                                                          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                                        }
                                                      }
                                                    }
                                                    default: return ((HeffT2){{heff_nomatch(v_x31_2458)}});
                                                    }
                                                  } else {
                                                    heff_drop(v_s_241);
                                                    heff_drop_cell(v_ru_24x31_247_24MkPair, 2);
                                                    heff_drop(v_x_2431);
                                                    heff_drop(v_x_2445);
                                                    heff_drop(v_field_2456);
                                                    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                                  }
                                                }
                                              }
                                              default: return ((HeffT2){{heff_nomatch(v_x31_2451)}});
                                              }
                                            } else {
                                              heff_drop(v_s_241);
                                              heff_drop_cell(v_ru_24x31_247_24MkPair, 2);
                                              heff_drop(v_x_2431);
                                              heff_drop(v_x_2445);
                                              heff_drop(v_field_2449);
                                              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                            }
                                          }
                                        }
                                        default: return ((HeffT2){{heff_nomatch(v_x31_2444)}});
                                        }
                                      } else {
                                        heff_drop(v_s_241);
                                        heff_drop_cell(v_ru_24x31_247_24MkPair, 2);
                                        heff_drop(v_x_2431);
                                        heff_drop(v_field_2442);
                                        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                      }
                                    }
                                  }
                                  default: return ((HeffT2){{heff_nomatch(v_x31_2437)}});
                                  }
                                } else {
                                  heff_drop(v_s_241);
                                  heff_drop_cell(v_ru_24x31_247_24MkPair, 2);
                                  heff_drop(v_x_2431);
                                  heff_drop(v_field_2435);
                                  return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                                }
                              }
                            }
                            default: return ((HeffT2){{heff_nomatch(v_x31_2430)}});
                            }
                          } else {
                            heff_drop(v_s_241);
                            heff_drop_cell(v_ru_24x31_247_24MkPair, 2);
                            heff_drop(v_field_2428);
                            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                          }
                        }
                      }
                      default: return ((HeffT2){{heff_nomatch(v_x31_2423)}});
                      }
                    } else {
                      heff_drop(v_s_241);
                      heff_drop_cell(v_ru_24x31_247_24MkPair, 2);
                      heff_drop(v_field_2421);
                      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                    }
                  }
                } else {
                  heff_drop(v_s_241);
                  heff_drop_cell(v_ru_24x31_247_24MkPair, 2);
                  heff_drop(v_j_2417);
                  return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
                }
              }
              default: return ((HeffT2){{heff_nomatch(v_x31_2415)}});
              }
            } else {
              heff_drop(v_s_241);
              heff_drop_cell(v_ru_24x31_247_24MkPair, 2);
              heff_drop(v_field_2413);
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
            }
          }
        } else {
          heff_drop(v_s_241);
          heff_drop(v_j_249);
          heff_drop_cell(v_ru_24x31_247_24MkPair, 2);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x31_247)}});
      }
    } else {
      heff_drop(v_s_241);
      heff_drop(v_field_245);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
  }
}
Clo g_heff_2ebuild_2ebackcache_2elastDotGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebackcache_2elastDotGo_entry, 3, 0};

V g_heff_2ebuild_2ebackcache_2elastDotGo(V v_k_240, V v_i_241, V v_at_242) {
top: ;
  if ((heff_unbox_word(heff_strLength_lent(v_k_240, 0)) <= heff_peek_word(v_i_241))) {
    heff_drop(v_i_241);
    return v_at_242;
  } else {
    V v_t_245;
    if ((heff_unbox_word(heff_strByteAt_lent(v_k_240, v_i_241, 0)) == ((int64_t)46ULL))) {
      heff_drop(v_at_242);
      v_t_245 = heff_dup(v_i_241);
    } else {
      v_t_245 = v_at_242;
    }
    V t_0 = v_k_240;
    V t_1 = heff_box_word((heff_unbox_word(v_i_241) + ((int64_t)1ULL)));
    V t_2 = v_t_245;
    v_k_240 = t_0;
    v_i_241 = t_1;
    v_at_242 = t_2;
    goto top;
  }
}
V g_heff_2ebuild_2ebackcache_2elastDotGo_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ebackcache_2elastDotGo(a0, a[1], a[2]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ebuild_2ebackcache_2emoduleIn_str0, 1, "_");
Clo g_heff_2ebuild_2ebackcache_2emoduleIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebackcache_2emoduleIn_entry, 2, 0};

V g_heff_2ebuild_2ebackcache_2emoduleIn(V v_mods_240, V v_k_241) {
top: ;
  HeffT2 v_t_242 = (g_std_2emap_2elookup_24s1654411661x99037275_24cpr(v_mods_240, v_k_241));
  {
    V v_field_244 = v_t_242.f[1];
    int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
    if ((v_tag_243 == ((int64_t)0ULL))) {
      V v_x_246 = v_field_244;
      heff_drop(v_x_246);
      return v_k_241;
    } else {
      heff_drop(v_field_244);
      V v_t_247 = (g_heff_2ebuild_2ebackcache_2elastDotGo(v_k_241, MK_INT(0LL), MK_INT(-1LL)));
      if (heff_intLe_c(v_t_247, MK_INT(0LL))) {
        heff_drop(v_k_241);
        return ((V)&g_heff_2ebuild_2ebackcache_2emoduleIn_str0);
      } else {
        V v_t_249 = (g_heff_2ebuild_2ebackcache_2elastDotGo(v_k_241, MK_INT(0LL), MK_INT(-1LL)));
        V t_0 = v_mods_240;
        V t_1 = heff_strSlice(v_k_241, MK_INT(0LL), v_t_249);
        v_mods_240 = t_0;
        v_k_241 = t_1;
        goto top;
      }
    }
  }
}
V g_heff_2ebuild_2ebackcache_2emoduleIn_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ebackcache_2emoduleIn(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2ebuild_2ebackcache_2eentriesAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebackcache_2eentriesAt_entry, 3, 0};

V g_heff_2ebuild_2ebackcache_2eentriesAt(V v_olds_240, V v_m_241, V v_k_242) {
top: ;
  HeffT2 v_t_243 = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(v_m_241, v_k_242));
  {
    V v_field_245 = v_t_243.f[1];
    int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
    if ((v_tag_244 == ((int64_t)0ULL))) {
      V v_es_247 = v_field_245;
      return v_es_247;
    } else {
      heff_drop(v_field_245);
      HeffT2 v_t_248 = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(v_olds_240, v_k_242));
      {
        V v_field_2410 = v_t_248.f[1];
        int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
        V v_b_2413;
        if ((v_tag_249 == ((int64_t)0ULL))) {
          V v_x_2412 = v_field_2410;
          v_b_2413 = v_x_2412;
        } else {
          heff_drop(v_field_2410);
          v_b_2413 = heff_dup(g_heff_2ebuild_2ebackcache_2enoBack_get());
        }
        V v_t_2414 = (g_list_2efoldl_24s497871705x469972998(heff_dup(g_std_2emap_2eempty_get()), heff_rfield(v_b_2413, 0)));
        V v_t_2415 = (g_list_2efoldl_24s1111588856x1684976655(heff_dup(g_std_2emap_2eempty_get()), heff_rfield(v_b_2413, 1)));
        V v_t_2416 = (g_list_2efoldl_24s1111588856x1684976655(heff_dup(g_std_2emap_2eempty_get()), heff_rfield(v_b_2413, 2)));
        V v_t_2417 = ({ V a_0 = heff_dup(g_std_2emap_2eempty_get()); V b_1 = heff_get_n(v_b_2413, 3, 4); V r_ = (g_list_2efoldl_24s1111588856x1684976655(a_0, b_1)); heff_drop(b_1); r_; });
        return heff_rec_n(4, shape_groups__copies__emits__jss, (V[]){v_t_2414, v_t_2415, v_t_2416, v_t_2417});
      }
    }
  }
}
V g_heff_2ebuild_2ebackcache_2eentriesAt_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V r = g_heff_2ebuild_2ebackcache_2eentriesAt(a0, a1, a2); heff_drop(a0); heff_drop(a1); heff_drop(a2); return r;
}

HeffT2 g_heff_2ebuild_2ebackcache_2eallJustB_24cpr(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), NTAG(TAG_Nil)}});
  }
  case TAG_Cons: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_Nothing: {
      heff_drop(v_rest_242);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_Just: {
      V v_x_243 = heff_field(v_x11_241, 0);
      heff_take_n(v_x11_241, 1ULL, 1);
      HeffT2 v_t_244 = (g_heff_2ebuild_2ebackcache_2eallJustB_24cpr(v_rest_242));
      {
        V v_field_246 = v_t_244.f[1];
        int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
        if ((v_tag_245 == ((int64_t)0ULL))) {
          V v_xs_248 = v_field_246;
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_243, v_xs_248})}});
        } else {
          heff_drop_cell(v_ru_24x1_240_24Cons, 2);
          heff_drop(v_x_243);
          heff_drop(v_field_246);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x11_241)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
Clo g_heff_2ebuild_2ebackcache_2eallJustB_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebackcache_2eallJustB_entry, 1, 0};

V g_heff_2ebuild_2ebackcache_2eallJustB(V v_x1_240) {
top: ;
  HeffT2 v_t_241 = (g_heff_2ebuild_2ebackcache_2eallJustB_24cpr(v_x1_240));
  {
    V v_field_243 = v_t_241.f[1];
    int64_t v_tag_242 = ((int64_t)v_t_241.f[0]);
    if ((v_tag_242 == ((int64_t)0ULL))) {
      return heff_tag_n(TAG_Just, 1, (V[]){v_field_243});
    } else {
      heff_drop(v_field_243);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_heff_2ebuild_2ebackcache_2eallJustB_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ebackcache_2eallJustB(a[0]);
}
HEFF_LIT(g_heff_2ebuild_2ebackcache_2egroupText_str0, 1, ":");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2egroupText_str1, 1, ":");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2egroupText_str2, 1, " ");
Clo g_heff_2ebuild_2ebackcache_2egroupText_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebackcache_2egroupText_entry, 3, 0};

V g_heff_2ebuild_2ebackcache_2egroupText(V v_owner_240, V v_ver_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nothing: {
    heff_drop(v_owner_240);
    heff_drop(v_ver_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_us_243 = heff_field(v_x3_242, 0);
    V v_ru_24x3_242_24Just = heff_take_reuse_n(v_x3_242, 1ULL, 1);
    V v_t_244 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_us_243));
    V v_t_245 = heff_intShow(v_t_244);
    V v_t_246 = heff_intShow(heff_strLength_lent(v_owner_240, 0));
    V v_t_247 = heff_strAppend(v_t_246, heff_strAppend(((V)&g_heff_2ebuild_2ebackcache_2egroupText_str0), v_owner_240));
    V v_t_248 = heff_intShow(heff_strLength_lent(v_ver_241, 0));
    V v_t_249 = heff_strAppend(v_t_248, heff_strAppend(((V)&g_heff_2ebuild_2ebackcache_2egroupText_str1), v_ver_241));
    V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_249, heff_tag_n(TAG_Cons, 2, (V[]){v_t_245, v_us_243})});
    V v_t_2411 = ({ V a_0 = ((V)&g_heff_2ebuild_2ebackcache_2egroupText_str2); V a_1 = v_t_247; V a_2 = v_t_2410; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop_tag(v_t_2410, 2); r_; });
    return heff_tag_at_n(v_ru_24x3_242_24Just, TAG_Just, 1, (V[]){v_t_2411});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2ebackcache_2egroupText_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ebackcache_2egroupText(a[0], a[1], a[2]);
}
Clo g_heff_2ebuild_2ebackcache_2egroupIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebackcache_2egroupIn_entry, 5, 0};

V g_heff_2ebuild_2ebackcache_2egroupIn(V v_fs_240, V v_m_241, V v_md_242, V v_g_243, V v_x5_244) {
top: ;
  switch (heff_tag_of(v_x5_244)) {
  case TAG_Nothing: {
    heff_drop_rec(v_fs_240, 2);
    heff_drop(v_md_242);
    heff_drop_rec(v_g_243, 3);
    return v_m_241;
  }
  case TAG_Just: {
    V v_t_245 = heff_field(v_x5_244, 0);
    V v_es_246 = ({ V b_0 = heff_get_n(v_fs_240, 1, 2); V a_1 = v_m_241; V a_2 = v_md_242; V r_ = (g_heff_2ebuild_2ebackcache_2eentriesAt(b_0, a_1, a_2)); heff_drop(b_0); r_; });
    V v_t_247 = (g_std_2emap_2einsert_24s1305793909x1049798133(heff_take_field(v_es_246, 0), heff_get_n(v_g_243, 0, 3), heff_dup(v_t_245)));
    V v_t_248 = ({ V rv_0 = v_t_247; V rr_ = heff_rec_reuse_nf(v_es_246, 14ULL, 4, shape_groups__copies__emits__jss, 252u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
    return (g_std_2emap_2einsert_24s1305793909x1049798133(v_m_241, v_md_242, v_t_248));
  }
  default: return heff_nomatch(v_x5_244);
  }
}
V g_heff_2ebuild_2ebackcache_2egroupIn_entry(V self, V *a) {
  (void)self;
  V a4 = a[4]; V r = g_heff_2ebuild_2ebackcache_2egroupIn(a[0], a[1], a[2], a[3], a4); heff_drop(a4); return r;
}
V g_heff_2ebuild_2ebackcache_2eaddGroup_lam0(V self, V *args);
V g_heff_2ebuild_2ebackcache_2eaddGroup_lam1(V self, V *args);
Clo g_heff_2ebuild_2ebackcache_2eaddGroup_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebackcache_2eaddGroup_entry, 3, 0};

V g_heff_2ebuild_2ebackcache_2eaddGroup(V v_fs_240, V v_m_241, V v_g_242) {
top: ;
  V v_t_243 = (g_heff_2ebuild_2ebackcache_2emoduleIn(heff_rfield(v_fs_240, 0), heff_dup(heff_rfield(v_g_242, 0))));
  V v_m_244 = (g_heff_2ebuild_2ebackcache_2emoduleIn(heff_rfield(v_fs_240, 0), heff_dup(heff_rfield(v_g_242, 0))));
  HeffT2 v_t_245 = ({ V a_0 = heff_rfield(v_fs_240, 1); V a_1 = v_m_244; HeffT2 r_ = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(a_0, a_1)); heff_drop(v_m_244); r_; });
  V v_t_2436;
  {
    V v_field_247 = v_t_245.f[1];
    int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
    V v_t_2410;
    if ((v_tag_246 == ((int64_t)0ULL))) {
      V v_x_249 = v_field_247;
      v_t_2410 = v_x_249;
    } else {
      heff_drop(v_field_247);
      v_t_2410 = heff_dup(g_heff_2ebuild_2ebackcache_2enoBack_get());
    }
    V v_t_2411 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_get_n(v_t_2410, 0, 4)));
    V v_old_2422 = ({ V a_0 = heff_clo_n(g_heff_2ebuild_2ebackcache_2eaddGroup_lam0, 2, 1, (V[]){heff_dup(v_g_242)}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_2411; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2411); r_; });
    v_t_2436 = heff_clo_n(g_heff_2ebuild_2ebackcache_2eaddGroup_lam1, 1, 1, (V[]){v_old_2422});
  }
  V v_t_2437 = (g_list_2emap(v_t_2436, heff_dup(heff_rfield(v_g_242, 2))));
  V v_t_2438 = (g_heff_2ebuild_2ebackcache_2eallJustB(v_t_2437));
  V v_t_2439 = (g_heff_2ebuild_2ebackcache_2egroupText(heff_dup(heff_rfield(v_g_242, 0)), heff_dup(heff_rfield(v_g_242, 1)), v_t_2438));
  return ({ V a_0 = v_fs_240; V a_1 = v_m_241; V a_2 = v_t_243; V a_3 = v_g_242; V a_4 = v_t_2439; V r_ = (g_heff_2ebuild_2ebackcache_2egroupIn(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_t_2439); r_; });
}
V g_heff_2ebuild_2ebackcache_2eaddGroup_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ebackcache_2eaddGroup(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2ebackcache_2eaddGroup_lam0(V self, V *args) {
  V v_acc_2412 = args[0];
  V v_x_2413 = args[1];
  V v_g_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2416;
  switch (heff_tag_of(v_x_2413)) {
  case TAG_MkPair: {
    V v_x_2414 = heff_dup(heff_field(v_x_2413, 0));
    v_t_2416 = v_x_2414;
    break;
  }
  default: heff_nomatch(v_x_2413);
  }
  V v_t_2421;
  if (heff_strEq_c(heff_get_n(v_t_2416, 0, 3), heff_get_n(v_g_242, 0, 3))) {
    V v_t_2420;
    switch (heff_tag_of(v_x_2413)) {
    case TAG_MkPair: {
      V v_x_2418 = heff_field(v_x_2413, 0);
      heff_take_n(v_x_2413, 1ULL, 2);
      v_t_2420 = v_x_2418;
      break;
    }
    default: heff_nomatch(v_x_2413);
    }
    v_t_2421 = heff_get_n(v_t_2420, 2, 3);
  } else {
    heff_drop(v_x_2413);
    v_t_2421 = NTAG(TAG_Nil);
  }
  return (g_prelude_2e_2b_2b(v_t_2421, v_acc_2412));
}
V g_heff_2ebuild_2ebackcache_2eaddGroup_lam1(V self, V *args) {
  V v_x2_2423 = args[0];
  V v_old_2422 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x2_2423)) {
  case TAG_MkPair: {
    V v_k_2424 = heff_field(v_x2_2423, 0);
    V v_x22_2425 = heff_field(v_x2_2423, 1);
    heff_take_n(v_x2_2423, 3ULL, 2);
    switch (heff_tag_of(v_x22_2425)) {
    case TAG_Nothing: {
      HeffT2 v_t_2426 = ({ V a_0 = v_k_2424; V a_1 = v_old_2422; HeffT2 r_ = (g_list_2efind_24s1990539953x112149757_24cpr(a_0, a_1)); heff_drop(v_k_2424); r_; });
      {
        V v_field_2428 = v_t_2426.f[1];
        int64_t v_tag_2427 = ((int64_t)v_t_2426.f[0]);
        if ((v_tag_2427 == ((int64_t)0ULL))) {
          V v_p_2430 = v_field_2428;
          V v_t_2433;
          switch (heff_tag_of(v_p_2430)) {
          case TAG_MkPair: {
            V v_y_2432 = heff_field(v_p_2430, 1);
            heff_take_n(v_p_2430, 2ULL, 2);
            v_t_2433 = v_y_2432;
            break;
          }
          default: heff_nomatch(v_p_2430);
          }
          return heff_tag_n(TAG_Just, 1, (V[]){v_t_2433});
        } else {
          heff_drop(v_field_2428);
          return NTAG(TAG_Nothing);
        }
      }
    }
    case TAG_Just: {
      V v_u_2434 = heff_field(v_x22_2425, 0);
      V v_ru_24x22_2425_24Just = heff_take_reuse_n(v_x22_2425, 1ULL, 1);
      heff_drop(v_old_2422);
      heff_drop(v_k_2424);
      V v_t_2435 = (g_heff_2ebuild_2ebackcache_2eunitText(v_u_2434));
      return heff_tag_at_n(v_ru_24x22_2425_24Just, TAG_Just, 1, (V[]){v_t_2435});
    }
    default: return heff_nomatch(v_x22_2425);
    }
  }
  default: return heff_nomatch(v_x2_2423);
  }
}
HEFF_LIT(g_heff_2ebuild_2ebackcache_2eaddCopy_str0, 2, "$s");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2eaddCopy_str1, 2, "$s");
Clo g_heff_2ebuild_2ebackcache_2eaddCopy_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebackcache_2eaddCopy_entry, 3, 0};

V g_heff_2ebuild_2ebackcache_2eaddCopy(V v_fs_240, V v_m_241, V v_c_242) {
top: ;
  V v_g_243 = heff_dup(heff_rfield(v_c_242, 0));
  V v_j_244 = heff_strFind_lent(((V)&g_heff_2ebuild_2ebackcache_2eaddCopy_str0), v_g_243, MK_INT(0LL), 5);
  V v_t_246;
  if (heff_intLt_c_lent(v_j_244, MK_INT(0LL), 2)) {
    heff_drop(v_j_244);
    v_t_246 = v_g_243;
  } else {
    v_t_246 = heff_strSlice(v_g_243, MK_INT(0LL), v_j_244);
  }
  V v_t_247 = (g_heff_2ebuild_2ebackcache_2emoduleIn(heff_rfield(v_fs_240, 0), v_t_246));
  V v_t_248 = (g_heff_2ebuild_2ebackcache_2ecopyText(heff_dup(v_c_242)));
  V v_g_249 = heff_dup(heff_rfield(v_c_242, 0));
  V v_j_2410 = heff_strFind_lent(((V)&g_heff_2ebuild_2ebackcache_2eaddCopy_str1), v_g_249, MK_INT(0LL), 5);
  V v_t_2412;
  if (heff_intLt_c_lent(v_j_2410, MK_INT(0LL), 2)) {
    heff_drop(v_j_2410);
    v_t_2412 = v_g_249;
  } else {
    v_t_2412 = heff_strSlice(v_g_249, MK_INT(0LL), v_j_2410);
  }
  V v_t_2413 = (g_heff_2ebuild_2ebackcache_2emoduleIn(heff_rfield(v_fs_240, 0), v_t_2412));
  V v_es_2414 = ({ V b_0 = heff_get_n(v_fs_240, 1, 2); V a_1 = v_m_241; V a_2 = v_t_2413; V r_ = (g_heff_2ebuild_2ebackcache_2eentriesAt(b_0, a_1, a_2)); heff_drop(b_0); heff_drop(v_t_2413); r_; });
  V v_t_2415 = (g_std_2emap_2einsert_24s1305793909x1049798133(heff_take_field(v_es_2414, 1), heff_get_n(v_c_242, 0, 6), v_t_248));
  V v_t_2416 = ({ V rv_1 = v_t_2415; V rr_ = heff_rec_reuse_nf(v_es_2414, 13ULL, 4, shape_groups__copies__emits__jss, 243u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
  HEFF_LAST return g_std_2emap_2einsert_24s1305793909x1049798133(v_m_241, v_t_247, v_t_2416);
}
V g_heff_2ebuild_2ebackcache_2eaddCopy_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ebackcache_2eaddCopy(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ebuild_2ebackcache_2eaddEmit_str0, 2, "$s");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2eaddEmit_str1, 2, "$s");
Clo g_heff_2ebuild_2ebackcache_2eaddEmit_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebackcache_2eaddEmit_entry, 3, 0};

V g_heff_2ebuild_2ebackcache_2eaddEmit(V v_fs_240, V v_m_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_MkPair: {
    V v_k_243 = heff_field(v_x3_242, 0);
    V v_e_244 = heff_field(v_x3_242, 1);
    V v_j_245 = heff_strFind_lent(((V)&g_heff_2ebuild_2ebackcache_2eaddEmit_str0), v_k_243, MK_INT(0LL), 5);
    V v_t_247;
    if (heff_intLt_c_lent(v_j_245, MK_INT(0LL), 2)) {
      heff_drop(v_j_245);
      v_t_247 = heff_dup(v_k_243);
    } else {
      v_t_247 = heff_strSlice_lent(v_k_243, MK_INT(0LL), v_j_245, 6);
    }
    V v_t_248 = (g_heff_2ebuild_2ebackcache_2emoduleIn(heff_rfield(v_fs_240, 0), v_t_247));
    V v_t_249 = (g_heff_2ebuild_2ebackcache_2eemitText(heff_dup(v_k_243), heff_dup(v_e_244)));
    V v_j_2410 = heff_strFind_lent(((V)&g_heff_2ebuild_2ebackcache_2eaddEmit_str1), v_k_243, MK_INT(0LL), 5);
    V v_t_2412;
    if (heff_intLt_c_lent(v_j_2410, MK_INT(0LL), 2)) {
      heff_drop(v_j_2410);
      v_t_2412 = heff_dup(v_k_243);
    } else {
      v_t_2412 = heff_strSlice_lent(v_k_243, MK_INT(0LL), v_j_2410, 6);
    }
    V v_t_2413 = (g_heff_2ebuild_2ebackcache_2emoduleIn(heff_rfield(v_fs_240, 0), v_t_2412));
    V v_es_2414 = ({ V b_0 = heff_get_n(v_fs_240, 1, 2); V a_1 = v_m_241; V a_2 = v_t_2413; V r_ = (g_heff_2ebuild_2ebackcache_2eentriesAt(b_0, a_1, a_2)); heff_drop(b_0); heff_drop(v_t_2413); r_; });
    V v_t_2415 = (g_std_2emap_2einsert_24s1305793909x1049798133(heff_take_field(v_es_2414, 2), heff_dup(v_k_243), v_t_249));
    V v_t_2416 = ({ V rv_2 = v_t_2415; V rr_ = heff_rec_reuse_nf(v_es_2414, 11ULL, 4, shape_groups__copies__emits__jss, 207u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    HEFF_LAST return g_std_2emap_2einsert_24s1305793909x1049798133(v_m_241, v_t_248, v_t_2416);
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2ebackcache_2eaddEmit_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ebuild_2ebackcache_2eaddEmit(a[0], a[1], a2); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2ebuild_2ebackcache_2eaddJs_str0, 2, "$s");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2eaddJs_str1, 2, "$s");
Clo g_heff_2ebuild_2ebackcache_2eaddJs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebackcache_2eaddJs_entry, 3, 0};

V g_heff_2ebuild_2ebackcache_2eaddJs(V v_fs_240, V v_m_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_MkPair: {
    V v_k_243 = heff_field(v_x3_242, 0);
    V v_e_244 = heff_field(v_x3_242, 1);
    V v_j_245 = heff_strFind_lent(((V)&g_heff_2ebuild_2ebackcache_2eaddJs_str0), v_k_243, MK_INT(0LL), 5);
    V v_t_247;
    if (heff_intLt_c_lent(v_j_245, MK_INT(0LL), 2)) {
      heff_drop(v_j_245);
      v_t_247 = heff_dup(v_k_243);
    } else {
      v_t_247 = heff_strSlice_lent(v_k_243, MK_INT(0LL), v_j_245, 6);
    }
    V v_t_248 = (g_heff_2ebuild_2ebackcache_2emoduleIn(heff_rfield(v_fs_240, 0), v_t_247));
    V v_t_249 = (g_heff_2ebuild_2ebackcache_2ejsText(heff_dup(v_k_243), heff_dup(v_e_244)));
    V v_j_2410 = heff_strFind_lent(((V)&g_heff_2ebuild_2ebackcache_2eaddJs_str1), v_k_243, MK_INT(0LL), 5);
    V v_t_2412;
    if (heff_intLt_c_lent(v_j_2410, MK_INT(0LL), 2)) {
      heff_drop(v_j_2410);
      v_t_2412 = heff_dup(v_k_243);
    } else {
      v_t_2412 = heff_strSlice_lent(v_k_243, MK_INT(0LL), v_j_2410, 6);
    }
    V v_t_2413 = (g_heff_2ebuild_2ebackcache_2emoduleIn(heff_rfield(v_fs_240, 0), v_t_2412));
    V v_es_2414 = ({ V b_0 = heff_get_n(v_fs_240, 1, 2); V a_1 = v_m_241; V a_2 = v_t_2413; V r_ = (g_heff_2ebuild_2ebackcache_2eentriesAt(b_0, a_1, a_2)); heff_drop(b_0); heff_drop(v_t_2413); r_; });
    V v_t_2415 = (g_std_2emap_2einsert_24s1305793909x1049798133(heff_take_field(v_es_2414, 3), heff_dup(v_k_243), v_t_249));
    V v_t_2416 = ({ V rv_3 = v_t_2415; V rr_ = heff_rec_reuse_nf(v_es_2414, 7ULL, 4, shape_groups__copies__emits__jss, 63u, 0u); heff_rfield(rr_, 3) = rv_3; rr_; });
    HEFF_LAST return g_std_2emap_2einsert_24s1305793909x1049798133(v_m_241, v_t_248, v_t_2416);
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2ebackcache_2eaddJs_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ebuild_2ebackcache_2eaddJs(a[0], a[1], a2); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2ebuild_2ebackcache_2ebackText_str0, 1, ":");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2ebackText_str1, 1, ":");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2ebackText_str2, 5, "3:end");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2ebackText_str3, 0, "");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2ebackText_str4, 1, " ");
Clo g_heff_2ebuild_2ebackcache_2ebackText_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebackcache_2ebackText_entry, 2, 0};

V g_heff_2ebuild_2ebackcache_2ebackText(V v_id_240, V v_es_241) {
top: ;
  V v_t_242 = heff_intShow(heff_strLength(heff_dup(g_heff_2ebuild_2ebackcache_2eversion_get())));
  V v_t_243 = heff_strAppend(v_t_242, heff_strAppend(((V)&g_heff_2ebuild_2ebackcache_2ebackText_str0), heff_dup(g_heff_2ebuild_2ebackcache_2eversion_get())));
  V v_t_244 = heff_intShow(heff_strLength_lent(v_id_240, 0));
  V v_t_245 = heff_strAppend(v_t_244, heff_strAppend(((V)&g_heff_2ebuild_2ebackcache_2ebackText_str1), v_id_240));
  V v_t_246 = (g_std_2emap_2esize(heff_rfield(v_es_241, 0)));
  V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_t_246), NTAG(TAG_Nil)});
  V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_243, heff_tag_n(TAG_Cons, 2, (V[]){v_t_245, v_t_247})});
  V v_t_249 = (g_std_2emap_2etoListOnto(heff_rfield(v_es_241, 0), NTAG(TAG_Nil)));
  V v_t_2410 = (g_list_2emap_24s1173914895x100384474(v_t_249));
  V v_t_2411 = (g_std_2emap_2esize(heff_rfield(v_es_241, 1)));
  V v_t_2412 = (g_std_2emap_2etoListOnto(heff_rfield(v_es_241, 1), NTAG(TAG_Nil)));
  V v_t_2413 = (g_list_2emap_24s1173914895x100384474(v_t_2412));
  V v_t_2414 = (g_std_2emap_2esize(heff_rfield(v_es_241, 2)));
  V v_t_2415 = (g_std_2emap_2etoListOnto(heff_rfield(v_es_241, 2), NTAG(TAG_Nil)));
  V v_t_2416 = (g_list_2emap_24s1173914895x100384474(v_t_2415));
  V v_t_2417 = (g_std_2emap_2esize(heff_rfield(v_es_241, 3)));
  V v_t_2418 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ebackcache_2ebackText_str2), NTAG(TAG_Nil)});
  V v_t_2419 = ({ V b_0 = heff_get_n(v_es_241, 3, 4); V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2emap_2etoListOnto(b_0, a_1)); heff_drop(b_0); r_; });
  V v_t_2420 = (g_prelude_2e_2b_2b_24f1085359736x1262841716(v_t_2418, v_t_2419));
  V v_t_2421 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_t_2417), v_t_2420});
  V v_t_2422 = (g_prelude_2e_2b_2b(v_t_2416, v_t_2421));
  V v_t_2423 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_t_2414), v_t_2422});
  V v_t_2424 = (g_prelude_2e_2b_2b(v_t_2413, v_t_2423));
  V v_t_2425 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_t_2411), v_t_2424});
  V v_t_2426 = (g_prelude_2e_2b_2b(v_t_2410, v_t_2425));
  V v_x2_2427 = (g_prelude_2e_2b_2b(v_t_248, v_t_2426));
  switch (heff_tag_of(v_x2_2427)) {
  case TAG_Nil: {
    return ((V)&g_heff_2ebuild_2ebackcache_2ebackText_str3);
  }
  case TAG_Cons: {
    V v_x_2428 = heff_field(v_x2_2427, 0);
    V v_xs_2429 = heff_field(v_x2_2427, 1);
    heff_take_n(v_x2_2427, 3ULL, 2);
    return ({ V a_0 = ((V)&g_heff_2ebuild_2ebackcache_2ebackText_str4); V a_1 = v_x_2428; V a_2 = v_xs_2429; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2429); r_; });
  }
  default: return heff_nomatch(v_x2_2427);
  }
}
V g_heff_2ebuild_2ebackcache_2ebackText_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ebackcache_2ebackText(a[0], a[1]);
}
V g_heff_2ebuild_2ebackcache_2ebackTexts_lam0(V self, V *args);
Clo g_heff_2ebuild_2ebackcache_2ebackTexts_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebackcache_2ebackTexts_entry, 3, 0};

V g_heff_2ebuild_2ebackcache_2ebackTexts(V v_id_240, V v_fs_241, V v_gv_242) {
top: ;
  V v_t_243 = (g_list_2efoldl_24s1494296198x1800016121(heff_dup(v_fs_241), heff_dup(g_std_2emap_2eempty_get()), heff_rfield(v_gv_242, 0)));
  V v_t_244 = (g_list_2efoldl_24s1103469845x1474178821(heff_dup(v_fs_241), v_t_243, heff_rfield(v_gv_242, 1)));
  V v_t_245 = (g_list_2efoldl_24s788343806x1528994845(heff_dup(v_fs_241), v_t_244, heff_rfield(v_gv_242, 2)));
  V v_m_246 = ({ V a_0 = v_fs_241; V a_1 = v_t_245; V b_2 = heff_get_n(v_gv_242, 3, 4); V r_ = (g_list_2efoldl_24s425699049x1164890302(a_0, a_1, b_2)); heff_drop(b_2); r_; });
  V v_t_247 = ({ V a_0 = v_m_246; V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2emap_2etoListOnto(a_0, a_1)); heff_drop(v_m_246); r_; });
  return (g_list_2emap(heff_clo_n(g_heff_2ebuild_2ebackcache_2ebackTexts_lam0, 1, 1, (V[]){v_id_240}), v_t_247));
}
V g_heff_2ebuild_2ebackcache_2ebackTexts_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ebackcache_2ebackTexts(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2ebackcache_2ebackTexts_lam0(V self, V *args) {
  V v_p_248 = args[0];
  V v_id_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2411;
  switch (heff_tag_of(v_p_248)) {
  case TAG_MkPair: {
    V v_x_249 = heff_dup(heff_field(v_p_248, 0));
    v_t_2411 = v_x_249;
    break;
  }
  default: heff_nomatch(v_p_248);
  }
  V v_t_2414;
  switch (heff_tag_of(v_p_248)) {
  case TAG_MkPair: {
    V v_y_2413 = heff_field(v_p_248, 1);
    heff_take_n(v_p_248, 2ULL, 2);
    v_t_2414 = v_y_2413;
    break;
  }
  default: heff_nomatch(v_p_248);
  }
  V v_t_2415 = (g_heff_2ebuild_2ebackcache_2ebackText(v_id_240, v_t_2414));
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2411, v_t_2415});
}