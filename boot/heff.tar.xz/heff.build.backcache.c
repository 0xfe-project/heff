// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define LBL_asks 9499105
#define LBL_body 9524841
#define LBL_code 9554612
#define LBL_copies 592412158
#define LBL_def 308863
#define LBL_depth 296830685
#define LBL_done 9584713
#define LBL_emits 297985818
#define LBL_groups 709681407
#define LBL_jss 315076
#define LBL_key 315609
#define LBL_lams 9809570
#define LBL_lines 304335641
#define LBL_lprotos 613175609
#define LBL_made 9839068
#define LBL_mods 9852536
#define LBL_name 9869138
#define LBL_olds 9909235
#define LBL_owner 307523277
#define LBL_params 951713969
#define LBL_prims 308293287
#define LBL_protos 967342774
#define LBL_recipe 1012227257
#define LBL_refs 9991943
#define LBL_safe 10017876
#define LBL_sgSafe 1042218796
#define LBL_sgTotal 97882005
#define LBL_shapes 1043573789
#define LBL_strs 10036521
#define LBL_touched 1244526179
#define LBL_units 312791945
#define LBL_ver 326173
static uint32_t shape_body__touched[] = {LBL_body, LBL_touched};
static uint32_t shape_def__refs[] = {LBL_def, LBL_refs};
static uint32_t shape_groups__copies__emits__jss[] = {LBL_groups, LBL_copies, LBL_emits, LBL_jss};
static uint32_t shape_key__name__body__safe__touched__sgSafe__sgTotal[] = {LBL_key, LBL_name, LBL_body, LBL_safe, LBL_touched, LBL_sgSafe, LBL_sgTotal};
static uint32_t shape_ver__lines__params__refs__prims[] = {LBL_ver, LBL_lines, LBL_params, LBL_refs, LBL_prims};
static uint32_t shape_ver__protos__code__strs__lprotos__lams__shapes__prims[] = {LBL_ver, LBL_protos, LBL_code, LBL_strs, LBL_lprotos, LBL_lams, LBL_shapes, LBL_prims};
static uint32_t shape_ver__recipe__asks__depth__safe__made[] = {LBL_ver, LBL_recipe, LBL_asks, LBL_depth, LBL_safe, LBL_made};
V g_heff_2ebuild_2ebackcache_2eaddGroup(V, V, V);
V g_heff_2ebuild_2ebackcache_2eaddGroup_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebackcache_2eaddGroup_clo;
HeffT2 g_heff_2ebuild_2ebackcache_2eallJustB_24cpr(V);
HeffT3 g_heff_2ebuild_2ebackcache_2ebackD_24cpr(V, V, V);
V g_heff_2ebuild_2ebackcache_2ebackDir_get(void);
V g_heff_2ebuild_2ebackcache_2ebackText(V, V);
V g_heff_2ebuild_2ebackcache_2ebackText_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebackcache_2ebackText_clo;
V g_heff_2ebuild_2ebackcache_2ebackTexts(V, V, V);
V g_heff_2ebuild_2ebackcache_2ebackTexts_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebackcache_2ebackTexts_clo;
V g_heff_2ebuild_2ebackcache_2ecopyD(V, V);
V g_heff_2ebuild_2ebackcache_2ecopyD_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebackcache_2ecopyD_clo;
V g_heff_2ebuild_2ebackcache_2ecopyText(V);
V g_heff_2ebuild_2ebackcache_2ecopyText_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebackcache_2ecopyText_clo;
HeffT4 g_heff_2ebuild_2ebackcache_2eemitD_24cpr(V, V);
V g_heff_2ebuild_2ebackcache_2eemitText(V, V);
V g_heff_2ebuild_2ebackcache_2eemitText_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebackcache_2eemitText_clo;
V g_heff_2ebuild_2ebackcache_2eentriesAt(V, V, V);
V g_heff_2ebuild_2ebackcache_2eentriesAt_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebackcache_2eentriesAt_clo;
HeffT4 g_heff_2ebuild_2ebackcache_2ejsD_24cpr(V, V);
V g_heff_2ebuild_2ebackcache_2ejsText(V, V);
V g_heff_2ebuild_2ebackcache_2ejsText_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebackcache_2ejsText_clo;
V g_heff_2ebuild_2ebackcache_2elastDotGo(V, V, V);
V g_heff_2ebuild_2ebackcache_2elastDotGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebackcache_2elastDotGo_clo;
HeffT3 g_heff_2ebuild_2ebackcache_2emadeOf_24cpr(V, V, V);
V g_heff_2ebuild_2ebackcache_2emoduleIn(V, V);
V g_heff_2ebuild_2ebackcache_2emoduleIn_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebackcache_2emoduleIn_clo;
V g_heff_2ebuild_2ebackcache_2enoBack_get(void);
V g_heff_2ebuild_2ebackcache_2epairsGo(V, V);
V g_heff_2ebuild_2ebackcache_2epairsGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebackcache_2epairsGo_clo;
V g_heff_2ebuild_2ebackcache_2eunitD(V, V);
V g_heff_2ebuild_2ebackcache_2eunitD_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebackcache_2eunitD_clo;
V g_heff_2ebuild_2ebackcache_2eunitText(V);
V g_heff_2ebuild_2ebackcache_2eunitText_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebackcache_2eunitText_clo;
V g_heff_2ebuild_2ebackcache_2eversion_get(void);
V g_heff_2ebuild_2edecoder_2ebind_24s823677936x1444069277(V, V, V);
V g_heff_2ebuild_2edecoder_2ebind_24s823677936x1444069277_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edecoder_2ebind_24s823677936x1444069277_clo;
HeffT3 g_heff_2ebuild_2edecoder_2efail_24cpr(V, V);
HeffT3 g_heff_2ebuild_2edecoder_2eint_24cpr(V, V);
HeffT3 g_heff_2ebuild_2edecoder_2estr_24cpr(V, V);
HeffT3 g_heff_2ebuild_2edecoder_2etimes_24s1391953550x1663492198_24cpr(V, V, V);
HeffT3 g_heff_2ebuild_2edecoder_2etimes_24s1603230686x1883420273_24cpr(V, V, V);
HeffT3 g_heff_2ebuild_2edecoder_2etimes_24s1954476619x1073210498_24cpr(V, V, V);
HeffT3 g_heff_2ebuild_2edecoder_2etimes_24s2049614891x1595878686_24cpr(V, V, V);
HeffT3 g_heff_2ebuild_2edecoder_2etimes_24s481066606x2100141841_24cpr(V, V, V);
HeffT3 g_heff_2ebuild_2edecoder_2etimes_24s98296704x1684150820_24cpr(V, V, V);
HeffT3 g_heff_2ebuild_2edecoder_2ewhole_24cpr(V, V, V);
HeffT3 g_heff_2ebuild_2edecoder_2eword_24cpr(V, V);
V g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091(V, V);
V g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091_clo;
V g_heff_2ecompile_2eirtext_2etakeExpr_get(void);
HeffT2 g_list_2efind_24s1156299507x501436576_24cpr(V, V);
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24s1103469845x1474178821(V, V, V);
V g_list_2efoldl_24s1103469845x1474178821_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1103469845x1474178821_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1494296198x1800016121(V, V, V);
V g_list_2efoldl_24s1494296198x1800016121_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1494296198x1800016121_clo;
V g_list_2efoldl_24s1533929316x1834489357(V, V);
V g_list_2efoldl_24s1533929316x1834489357_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1533929316x1834489357_clo;
V g_list_2efoldl_24s224553292x101133675(V, V);
V g_list_2efoldl_24s224553292x101133675_entry(V self, V *a);
extern Clo g_list_2efoldl_24s224553292x101133675_clo;
V g_list_2efoldl_24s425699049x1164890302(V, V, V);
V g_list_2efoldl_24s425699049x1164890302_entry(V self, V *a);
extern Clo g_list_2efoldl_24s425699049x1164890302_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2efoldl_24s788343806x1528994845(V, V, V);
V g_list_2efoldl_24s788343806x1528994845_entry(V self, V *a);
extern Clo g_list_2efoldl_24s788343806x1528994845_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1173914895x100384474(V);
V g_list_2emap_24s1173914895x100384474_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_clo;
V g_list_2emap_24s1173914895x100384474_24tok2(V, V);
V g_list_2emap_24s1173914895x100384474_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_24tok2_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24f1085359736x1262841716(V, V);
V g_prelude_2e_2b_2b_24f1085359736x1262841716_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f1085359736x1262841716_clo;
V g_prelude_2e_2b_2b_24f1815933030x829523367(V, V);
V g_prelude_2e_2b_2b_24f1815933030x829523367_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f1815933030x829523367_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_std_2eordmap_2eempty_get(void);
V g_std_2eordmap_2einsert_24s615484302x989744458(V, V, V);
V g_std_2eordmap_2einsert_24s615484302x989744458_entry(V self, V *a);
extern Clo g_std_2eordmap_2einsert_24s615484302x989744458_clo;
HeffT2 g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(V, V);
HeffT2 g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(V, V);
V g_std_2eordmap_2esize(V);
V g_std_2eordmap_2esize_entry(V self, V *a);
extern Clo g_std_2eordmap_2esize_clo;
V g_std_2eordmap_2etoList_2etoListOnto_240(V, V);
V g_std_2eordmap_2etoList_2etoListOnto_240_entry(V self, V *a);
extern Clo g_std_2eordmap_2etoList_2etoListOnto_240_clo;
HEFF_LIT(g_heff_2ebuild_2ebackcache_2eversion_str0, 15, "heff-backend/14");

static V g_heff_2ebuild_2ebackcache_2eversion_val;
static HEFF_ONCE g_heff_2ebuild_2ebackcache_2eversion_st;
static V g_heff_2ebuild_2ebackcache_2eversion_init(void) {
  return ((V)&g_heff_2ebuild_2ebackcache_2eversion_str0);
}
V g_heff_2ebuild_2ebackcache_2eversion_get(void) {
  if (HEFF_DONE(g_heff_2ebuild_2ebackcache_2eversion_st)) return g_heff_2ebuild_2ebackcache_2eversion_val;
  return heff_global(&g_heff_2ebuild_2ebackcache_2eversion_val, &g_heff_2ebuild_2ebackcache_2eversion_st, g_heff_2ebuild_2ebackcache_2eversion_init);
}
HEFF_LIT(g_heff_2ebuild_2ebackcache_2ebackDir_str0, 2, "b1");

static V g_heff_2ebuild_2ebackcache_2ebackDir_val;
static HEFF_ONCE g_heff_2ebuild_2ebackcache_2ebackDir_st;
static V g_heff_2ebuild_2ebackcache_2ebackDir_init(void) {
  return ((V)&g_heff_2ebuild_2ebackcache_2ebackDir_str0);
}
V g_heff_2ebuild_2ebackcache_2ebackDir_get(void) {
  if (HEFF_DONE(g_heff_2ebuild_2ebackcache_2ebackDir_st)) return g_heff_2ebuild_2ebackcache_2ebackDir_val;
  return heff_global(&g_heff_2ebuild_2ebackcache_2ebackDir_val, &g_heff_2ebuild_2ebackcache_2ebackDir_st, g_heff_2ebuild_2ebackcache_2ebackDir_init);
}
HEFF_LIT(g_heff_2ebuild_2ebackcache_2epairsGo_str0, 1, ":");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2epairsGo_str1, 1, ":");
Clo g_heff_2ebuild_2ebackcache_2epairsGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebackcache_2epairsGo_entry, 2, 0};

V g_heff_2ebuild_2ebackcache_2epairsGo(V v_x1_240, V v_rest_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return v_rest_241;
  }
  case TAG_Cons: {
    V v_p_242 = heff_field(v_x1_240, 0);
    V v_ps_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_rest_244 = (g_heff_2ebuild_2ebackcache_2epairsGo(v_ps_243, v_rest_241));
    switch (heff_tag_of(v_p_242)) {
    case TAG_MkPair: {
      V v_a_245 = heff_field(v_p_242, 0);
      V v_b_246 = heff_field(v_p_242, 1);
      V v_ru_24p_242_24MkPair = heff_take_reuse_n(v_p_242, 3ULL, 2);
      V v_t_247 = heff_intShow(heff_strLength_lent(v_a_245, 0));
      V v_t_248 = heff_strAppend(heff_strAppend(v_t_247, ((V)&g_heff_2ebuild_2ebackcache_2epairsGo_str0)), v_a_245);
      V v_t_249 = heff_intShow(heff_strLength_lent(v_b_246, 0));
      V v_t_2410 = heff_strAppend(heff_strAppend(v_t_249, ((V)&g_heff_2ebuild_2ebackcache_2epairsGo_str1)), v_b_246);
      return heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_t_248, heff_tag_at_n(v_ru_24p_242_24MkPair, TAG_Cons, 2, (V[]){v_t_2410, v_rest_244})});
    }
    default: return heff_nomatch(v_p_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2ebackcache_2epairsGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ebackcache_2epairsGo(a[0], a[1]);
}
HEFF_LIT(g_heff_2ebuild_2ebackcache_2eunitText_str0, 1, "t");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2eunitText_str1, 1, "f");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2eunitText_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2eunitText_str3, 1, " ");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2eunitText_str4, 1, "t");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2eunitText_str5, 1, "f");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2eunitText_str6, 1, ":");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2eunitText_str7, 1, ":");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2eunitText_str8, 1, ":");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2eunitText_str9, 1, " ");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2eunitText_str10, 1, " ");
Clo g_heff_2ebuild_2ebackcache_2eunitText_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebackcache_2eunitText_entry, 1, 0};

V g_heff_2ebuild_2ebackcache_2eunitText(V v_u_240) {
top: ;
  V v_done_241 = heff_take_field(v_u_240, 0);
  V v_name_242 = heff_take_field(v_u_240, 1);
  V v_refs_243 = heff_take_field(v_u_240, 2);
  V v_sgSafe_244 = heff_take_field(v_u_240, 3);
  V v_sgTotal_245 = heff_get_n(v_u_240, 4, 5);
  V v_s_246 = heff_take_field(v_done_241, 0);
  V v_s_247 = v_name_242;
  V v_xs_248 = v_refs_243;
  V v_t_249 = v_sgSafe_244;
  V v_t_2410;
  if ((heff_dup(v_t_249) == NTAG(TAG_True))) {
    heff_drop(v_t_249);
    v_t_2410 = ((V)&g_heff_2ebuild_2ebackcache_2eunitText_str0);
  } else {
    heff_drop(v_t_249);
    v_t_2410 = ((V)&g_heff_2ebuild_2ebackcache_2eunitText_str1);
  }
  V v_x2_2411 = (g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091(heff_take_field(v_done_241, 1), NTAG(TAG_Nil)));
  V v_s_2414;
  switch (heff_tag_of(v_x2_2411)) {
  case TAG_Nil: {
    v_s_2414 = ((V)&g_heff_2ebuild_2ebackcache_2eunitText_str2);
    break;
  }
  case TAG_Cons: {
    V v_x_2412 = heff_field(v_x2_2411, 0);
    V v_xs_2413 = heff_field(v_x2_2411, 1);
    heff_take_n(v_x2_2411, 3ULL, 2);
    v_s_2414 = ({ V a_0 = ((V)&g_heff_2ebuild_2ebackcache_2eunitText_str3); V a_1 = v_x_2412; V a_2 = v_xs_2413; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2413); r_; });
    break;
  }
  default: heff_nomatch(v_x2_2411);
  }
  V v_t_2415 = heff_take_field(v_done_241, 2);
  V v_t_2416;
  if ((heff_dup(v_t_2415) == NTAG(TAG_True))) {
    heff_drop(v_t_2415);
    v_t_2416 = ((V)&g_heff_2ebuild_2ebackcache_2eunitText_str4);
  } else {
    heff_drop(v_t_2415);
    v_t_2416 = ((V)&g_heff_2ebuild_2ebackcache_2eunitText_str5);
  }
  V v_ps_2417 = heff_get_n(v_done_241, 3, 4);
  V v_t_2418 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_ps_2417));
  V v_t_2419 = (g_heff_2ebuild_2ebackcache_2epairsGo(v_ps_2417, NTAG(TAG_Nil)));
  V v_t_2420 = heff_intShow(heff_strLength_lent(v_s_2414, 0));
  V v_t_2421 = heff_strAppend(heff_strAppend(v_t_2420, ((V)&g_heff_2ebuild_2ebackcache_2eunitText_str6)), v_s_2414);
  V v_t_2422 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_t_2418), v_t_2419});
  V v_t_2423 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2421, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2416, v_t_2422})});
  V v_t_2424 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_sgTotal_245), v_t_2423});
  V v_rest_2425 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2410, v_t_2424});
  V v_t_2426 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_248));
  V v_t_2427 = heff_intShow(v_t_2426);
  V v_t_2428 = (g_prelude_2e_2b_2b_24f1815933030x829523367(v_rest_2425, v_xs_248));
  V v_t_2429 = heff_intShow(heff_strLength_lent(v_s_247, 0));
  V v_t_2430 = heff_strAppend(heff_strAppend(v_t_2429, ((V)&g_heff_2ebuild_2ebackcache_2eunitText_str7)), v_s_247);
  V v_t_2431 = heff_intShow(heff_strLength_lent(v_s_246, 0));
  V v_t_2432 = heff_strAppend(heff_strAppend(v_t_2431, ((V)&g_heff_2ebuild_2ebackcache_2eunitText_str8)), v_s_246);
  V v_t_2433 = heff_strAppend(heff_strAppend(v_t_2432, ((V)&g_heff_2ebuild_2ebackcache_2eunitText_str9)), v_t_2430);
  return ({ V a_0 = ((V)&g_heff_2ebuild_2ebackcache_2eunitText_str10); V a_1 = v_t_2433; V b_2 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2427, v_t_2428}); V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, b_2)); heff_drop(b_2); r_; });
}
V g_heff_2ebuild_2ebackcache_2eunitText_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ebackcache_2eunitText(a[0]);
}
HEFF_LIT(g_heff_2ebuild_2ebackcache_2ecopyText_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2ecopyText_str1, 1, " ");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2ecopyText_str2, 1, "t");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2ecopyText_str3, 1, "f");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2ecopyText_str4, 1, "n");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2ecopyText_str5, 0, "");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2ecopyText_str6, 1, " ");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2ecopyText_str7, 1, ":");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2ecopyText_str8, 1, "j");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2ecopyText_str9, 1, ":");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2ecopyText_str10, 1, ":");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2ecopyText_str11, 1, ":");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2ecopyText_str12, 1, " ");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2ecopyText_str13, 1, " ");
Clo g_heff_2ebuild_2ebackcache_2ecopyText_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebackcache_2ecopyText_entry, 1, 0};

V g_heff_2ebuild_2ebackcache_2ecopyText(V v_c_240) {
top: ;
  V v_name_241 = heff_take_field(v_c_240, 0);
  V v_ver_242 = heff_take_field(v_c_240, 1);
  V v_recipe_243 = heff_take_field(v_c_240, 2);
  V v_asks_244 = heff_take_field(v_c_240, 3);
  V v_safe_245 = heff_take_field(v_c_240, 5);
  V v_made_246 = heff_take_field(v_c_240, 6);
  V v_depth_247 = heff_get_n(v_c_240, 4, 7);
  V v_s_248 = v_name_241;
  V v_s_249 = v_ver_242;
  V v_x2_2410 = (g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091(v_recipe_243, NTAG(TAG_Nil)));
  V v_s_2413;
  switch (heff_tag_of(v_x2_2410)) {
  case TAG_Nil: {
    v_s_2413 = ((V)&g_heff_2ebuild_2ebackcache_2ecopyText_str0);
    break;
  }
  case TAG_Cons: {
    V v_x_2411 = heff_field(v_x2_2410, 0);
    V v_xs_2412 = heff_field(v_x2_2410, 1);
    heff_take_n(v_x2_2410, 3ULL, 2);
    v_s_2413 = ({ V a_0 = ((V)&g_heff_2ebuild_2ebackcache_2ecopyText_str1); V a_1 = v_x_2411; V a_2 = v_xs_2412; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2412); r_; });
    break;
  }
  default: heff_nomatch(v_x2_2410);
  }
  V v_ps_2414 = v_asks_244;
  V v_t_2415 = v_safe_245;
  V v_t_2416;
  if ((heff_dup(v_t_2415) == NTAG(TAG_True))) {
    heff_drop(v_t_2415);
    v_t_2416 = ((V)&g_heff_2ebuild_2ebackcache_2ecopyText_str2);
  } else {
    heff_drop(v_t_2415);
    v_t_2416 = ((V)&g_heff_2ebuild_2ebackcache_2ecopyText_str3);
  }
  V v_x1_2417 = v_made_246;
  V v_t_2430;
  switch (heff_tag_of(v_x1_2417)) {
  case TAG_Nothing: {
    v_t_2430 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ebackcache_2ecopyText_str4), NTAG(TAG_Nil)});
    break;
  }
  case TAG_Just: {
    V v_x11_2418 = heff_field(v_x1_2417, 0);
    heff_take_n(v_x1_2417, 1ULL, 1);
    switch (heff_tag_of(v_x11_2418)) {
    case TAG_MkPair: {
      V v_b_2419 = heff_field(v_x11_2418, 0);
      V v_t_2420 = heff_field(v_x11_2418, 1);
      V v_ru_24x11_2418_24MkPair = heff_take_reuse_n(v_x11_2418, 3ULL, 2);
      V v_x2_2421 = (g_heff_2ecompile_2eirtext_2eencodeF_24s2103188991x300942091(v_b_2419, NTAG(TAG_Nil)));
      V v_s_2424;
      switch (heff_tag_of(v_x2_2421)) {
      case TAG_Nil: {
        v_s_2424 = ((V)&g_heff_2ebuild_2ebackcache_2ecopyText_str5);
        break;
      }
      case TAG_Cons: {
        V v_x_2422 = heff_field(v_x2_2421, 0);
        V v_xs_2423 = heff_field(v_x2_2421, 1);
        heff_take_n(v_x2_2421, 3ULL, 2);
        v_s_2424 = ({ V a_0 = ((V)&g_heff_2ebuild_2ebackcache_2ecopyText_str6); V a_1 = v_x_2422; V a_2 = v_xs_2423; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2423); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2421);
      }
      V v_t_2425 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_t_2420));
      V v_t_2426 = (g_heff_2ebuild_2ebackcache_2epairsGo(v_t_2420, NTAG(TAG_Nil)));
      V v_t_2427 = heff_intShow(heff_strLength_lent(v_s_2424, 0));
      V v_t_2428 = heff_strAppend(heff_strAppend(v_t_2427, ((V)&g_heff_2ebuild_2ebackcache_2ecopyText_str7)), v_s_2424);
      V v_t_2429 = heff_tag_at_n(v_ru_24x11_2418_24MkPair, TAG_Cons, 2, (V[]){heff_intShow(v_t_2425), v_t_2426});
      v_t_2430 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ebackcache_2ecopyText_str8), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2428, v_t_2429})});
      break;
    }
    default: heff_nomatch(v_x11_2418);
    }
    break;
  }
  default: heff_nomatch(v_x1_2417);
  }
  V v_rest_2431 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_depth_247), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2416, v_t_2430})});
  V v_t_2432 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_ps_2414));
  V v_t_2433 = heff_intShow(v_t_2432);
  V v_t_2434 = (g_heff_2ebuild_2ebackcache_2epairsGo(v_ps_2414, v_rest_2431));
  V v_t_2435 = heff_intShow(heff_strLength_lent(v_s_249, 0));
  V v_t_2436 = heff_strAppend(heff_strAppend(v_t_2435, ((V)&g_heff_2ebuild_2ebackcache_2ecopyText_str9)), v_s_249);
  V v_t_2437 = heff_intShow(heff_strLength_lent(v_s_2413, 0));
  V v_t_2438 = heff_strAppend(heff_strAppend(v_t_2437, ((V)&g_heff_2ebuild_2ebackcache_2ecopyText_str10)), v_s_2413);
  V v_t_2439 = heff_intShow(heff_strLength_lent(v_s_248, 0));
  V v_t_2440 = heff_strAppend(heff_strAppend(v_t_2439, ((V)&g_heff_2ebuild_2ebackcache_2ecopyText_str11)), v_s_248);
  V v_t_2441 = heff_strAppend(heff_strAppend(v_t_2440, ((V)&g_heff_2ebuild_2ebackcache_2ecopyText_str12)), v_t_2436);
  V v_t_2442 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2438, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2433, v_t_2434})});
  return ({ V a_0 = ((V)&g_heff_2ebuild_2ebackcache_2ecopyText_str13); V a_1 = v_t_2441; V a_2 = v_t_2442; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop_tag(v_t_2442, 2); r_; });
}
V g_heff_2ebuild_2ebackcache_2ecopyText_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ebackcache_2ecopyText(a[0]);
}
HEFF_LIT(g_heff_2ebuild_2ebackcache_2eemitText_str0, 1, ":");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2eemitText_str1, 1, ":");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2eemitText_str2, 1, " ");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2eemitText_str3, 1, " ");
Clo g_heff_2ebuild_2ebackcache_2eemitText_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebackcache_2eemitText_entry, 2, 0};

V g_heff_2ebuild_2ebackcache_2eemitText(V v_key_240, V v_k_241) {
top: ;
  V v_ver_242 = heff_take_field(v_k_241, 0);
  V v_protos_243 = heff_take_field(v_k_241, 1);
  V v_code_244 = heff_take_field(v_k_241, 2);
  V v_strs_245 = heff_take_field(v_k_241, 3);
  V v_lprotos_246 = heff_take_field(v_k_241, 4);
  V v_lams_247 = heff_take_field(v_k_241, 5);
  V v_shapes_248 = heff_take_field(v_k_241, 6);
  V v_prims_249 = heff_get_n(v_k_241, 7, 8);
  V v_s_2410 = v_ver_242;
  V v_xs_2411 = v_protos_243;
  V v_xs_2412 = v_code_244;
  V v_xs_2413 = v_strs_245;
  V v_xs_2414 = v_lprotos_246;
  V v_xs_2415 = v_lams_247;
  V v_xs_2416 = v_shapes_248;
  V v_xs_2417 = v_prims_249;
  V v_t_2418 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_2417));
  V v_t_2419 = (g_prelude_2e_2b_2b_24f1815933030x829523367(NTAG(TAG_Nil), v_xs_2417));
  V v_rest_2420 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_t_2418), v_t_2419});
  V v_t_2421 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_2416));
  V v_t_2422 = (g_prelude_2e_2b_2b_24f1815933030x829523367(v_rest_2420, v_xs_2416));
  V v_rest_2423 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_t_2421), v_t_2422});
  V v_t_2424 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_2415));
  V v_t_2425 = (g_prelude_2e_2b_2b_24f1815933030x829523367(v_rest_2423, v_xs_2415));
  V v_rest_2426 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_t_2424), v_t_2425});
  V v_t_2427 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_2414));
  V v_t_2428 = (g_prelude_2e_2b_2b_24f1815933030x829523367(v_rest_2426, v_xs_2414));
  V v_rest_2429 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_t_2427), v_t_2428});
  V v_t_2430 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_2413));
  V v_t_2431 = (g_prelude_2e_2b_2b_24f1815933030x829523367(v_rest_2429, v_xs_2413));
  V v_rest_2432 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_t_2430), v_t_2431});
  V v_t_2433 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_2412));
  V v_t_2434 = (g_prelude_2e_2b_2b_24f1815933030x829523367(v_rest_2432, v_xs_2412));
  V v_rest_2435 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_t_2433), v_t_2434});
  V v_t_2436 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_2411));
  V v_t_2437 = heff_intShow(v_t_2436);
  V v_t_2438 = (g_prelude_2e_2b_2b_24f1815933030x829523367(v_rest_2435, v_xs_2411));
  V v_t_2439 = heff_intShow(heff_strLength_lent(v_s_2410, 0));
  V v_t_2440 = heff_strAppend(heff_strAppend(v_t_2439, ((V)&g_heff_2ebuild_2ebackcache_2eemitText_str0)), v_s_2410);
  V v_t_2441 = heff_intShow(heff_strLength_lent(v_key_240, 0));
  V v_t_2442 = heff_strAppend(heff_strAppend(v_t_2441, ((V)&g_heff_2ebuild_2ebackcache_2eemitText_str1)), v_key_240);
  V v_t_2443 = heff_strAppend(heff_strAppend(v_t_2442, ((V)&g_heff_2ebuild_2ebackcache_2eemitText_str2)), v_t_2440);
  return ({ V a_0 = ((V)&g_heff_2ebuild_2ebackcache_2eemitText_str3); V a_1 = v_t_2443; V b_2 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2437, v_t_2438}); V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, b_2)); heff_drop(b_2); r_; });
}
V g_heff_2ebuild_2ebackcache_2eemitText_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ebackcache_2eemitText(a[0], a[1]);
}
HEFF_LIT(g_heff_2ebuild_2ebackcache_2ejsText_str0, 1, ":");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2ejsText_str1, 1, ":");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2ejsText_str2, 1, " ");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2ejsText_str3, 1, " ");
Clo g_heff_2ebuild_2ebackcache_2ejsText_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebackcache_2ejsText_entry, 2, 0};

V g_heff_2ebuild_2ebackcache_2ejsText(V v_key_240, V v_k_241) {
top: ;
  V v_ver_242 = heff_take_field(v_k_241, 0);
  V v_lines_243 = heff_take_field(v_k_241, 1);
  V v_params_244 = heff_take_field(v_k_241, 2);
  V v_refs_245 = heff_take_field(v_k_241, 3);
  V v_prims_246 = heff_get_n(v_k_241, 4, 5);
  V v_s_247 = v_ver_242;
  V v_xs_248 = v_lines_243;
  V v_xs_249 = v_params_244;
  V v_xs_2410 = v_refs_245;
  V v_xs_2411 = v_prims_246;
  V v_t_2412 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_2411));
  V v_t_2413 = (g_prelude_2e_2b_2b_24f1815933030x829523367(NTAG(TAG_Nil), v_xs_2411));
  V v_rest_2414 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_t_2412), v_t_2413});
  V v_t_2415 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_2410));
  V v_t_2416 = (g_prelude_2e_2b_2b_24f1815933030x829523367(v_rest_2414, v_xs_2410));
  V v_rest_2417 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_t_2415), v_t_2416});
  V v_t_2418 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_249));
  V v_t_2419 = (g_prelude_2e_2b_2b_24f1815933030x829523367(v_rest_2417, v_xs_249));
  V v_rest_2420 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_t_2418), v_t_2419});
  V v_t_2421 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_248));
  V v_t_2422 = heff_intShow(v_t_2421);
  V v_t_2423 = (g_prelude_2e_2b_2b_24f1815933030x829523367(v_rest_2420, v_xs_248));
  V v_t_2424 = heff_intShow(heff_strLength_lent(v_s_247, 0));
  V v_t_2425 = heff_strAppend(heff_strAppend(v_t_2424, ((V)&g_heff_2ebuild_2ebackcache_2ejsText_str0)), v_s_247);
  V v_t_2426 = heff_intShow(heff_strLength_lent(v_key_240, 0));
  V v_t_2427 = heff_strAppend(heff_strAppend(v_t_2426, ((V)&g_heff_2ebuild_2ebackcache_2ejsText_str1)), v_key_240);
  V v_t_2428 = heff_strAppend(heff_strAppend(v_t_2427, ((V)&g_heff_2ebuild_2ebackcache_2ejsText_str2)), v_t_2425);
  return ({ V a_0 = ((V)&g_heff_2ebuild_2ebackcache_2ejsText_str3); V a_1 = v_t_2428; V b_2 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2422, v_t_2423}); V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, b_2)); heff_drop(b_2); r_; });
}
V g_heff_2ebuild_2ebackcache_2ejsText_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ebackcache_2ejsText(a[0], a[1]);
}
V g_heff_2ebuild_2ebackcache_2eunitD_lam2(V self, V *args);
V g_heff_2ebuild_2ebackcache_2eunitD_lam1(V self, V *args);
V g_heff_2ebuild_2ebackcache_2eunitD_lam0(V self, V *args);
Clo g_heff_2ebuild_2ebackcache_2eunitD_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebackcache_2eunitD_entry, 2, 0};

V g_heff_2ebuild_2ebackcache_2eunitD(V v_s_240, V v_i_241) {
top: ;
  HeffT3 v_t_242 = (g_heff_2ebuild_2edecoder_2estr_24cpr(heff_dup(v_s_240), v_i_241));
  {
    V v_field_244 = v_t_242.f[1];
    V v_field_245 = v_t_242.f[2];
    int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
    if ((v_tag_243 == ((int64_t)0ULL))) {
      V v_x_246 = v_field_244;
      V v_j_247 = v_field_245;
      HeffT3 v_t_248 = (g_heff_2ebuild_2edecoder_2estr_24cpr(heff_dup(v_s_240), v_j_247));
      {
        V v_field_2410 = v_t_248.f[1];
        V v_field_2411 = v_t_248.f[2];
        int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
        if ((v_tag_249 == ((int64_t)0ULL))) {
          V v_x_2412 = v_field_2410;
          V v_j_2413 = v_field_2411;
          HeffT3 v_t_2414 = (g_heff_2ebuild_2edecoder_2eint_24cpr(v_s_240, v_j_2413));
          {
            V v_field_2416 = v_t_2414.f[1];
            V v_field_2417 = v_t_2414.f[2];
            int64_t v_tag_2415 = ((int64_t)v_t_2414.f[0]);
            if ((v_tag_2415 == ((int64_t)0ULL))) {
              V v_x_2418 = v_field_2416;
              V v_j_2419 = v_field_2417;
              HeffT3 v_t_2420 = (g_heff_2ebuild_2edecoder_2etimes_24s1603230686x1883420273_24cpr(v_x_2418, heff_dup(v_s_240), v_j_2419));
              {
                V v_field_2422 = v_t_2420.f[1];
                V v_field_2423 = v_t_2420.f[2];
                int64_t v_tag_2421 = ((int64_t)v_t_2420.f[0]);
                if ((v_tag_2421 == ((int64_t)0ULL))) {
                  V v_x_2424 = v_field_2422;
                  V v_j_2425 = v_field_2423;
                  return (g_heff_2ebuild_2edecoder_2ebind_24s823677936x1444069277(heff_clo_n(g_heff_2ebuild_2ebackcache_2eunitD_lam0, 3, 3, (V[]){v_x_246, v_x_2412, v_x_2424}), v_s_240, v_j_2425));
                } else {
                  heff_drop(v_s_240);
                  heff_drop(v_x_246);
                  heff_drop(v_x_2412);
                  heff_drop(v_field_2422);
                  heff_drop(v_field_2423);
                  return NTAG(TAG_Nothing);
                }
              }
            } else {
              heff_drop(v_s_240);
              heff_drop(v_x_246);
              heff_drop(v_x_2412);
              heff_drop(v_field_2416);
              heff_drop(v_field_2417);
              return NTAG(TAG_Nothing);
            }
          }
        } else {
          heff_drop(v_s_240);
          heff_drop(v_x_246);
          heff_drop(v_field_2410);
          heff_drop(v_field_2411);
          return NTAG(TAG_Nothing);
        }
      }
    } else {
      heff_drop(v_s_240);
      heff_drop(v_field_244);
      heff_drop(v_field_245);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_heff_2ebuild_2ebackcache_2eunitD_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ebackcache_2eunitD(a[0], a[1]);
}
V g_heff_2ebuild_2ebackcache_2eunitD_lam2(V self, V *args) {
  V v_u_2456 = args[0];
  V v_x_2439 = heff_env(self)[0];
  heff_drop(v_u_2456);
  heff_clo_take(self, 1);
  HeffT3 v_t_2457 = (g_heff_2ebuild_2edecoder_2ewhole_24cpr(heff_dup(g_heff_2ecompile_2eirtext_2etakeExpr_get()), v_x_2439, MK_INT(0LL)));
  {
    V v_field_2459 = v_t_2457.f[1];
    V v_field_2460 = v_t_2457.f[2];
    int64_t v_tag_2458 = ((int64_t)v_t_2457.f[0]);
    if ((v_tag_2458 == ((int64_t)0ULL))) {
      V v_x_2461 = v_field_2459;
      V v_x112_2462 = v_field_2460;
      heff_drop(v_x112_2462);
      return heff_tag_n(TAG_Just, 1, (V[]){v_x_2461});
    } else {
      heff_drop(v_field_2459);
      heff_drop(v_field_2460);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_heff_2ebuild_2ebackcache_2eunitD_lam1(V self, V *args) {
  V v_safe_2441 = args[0];
  V v_s_2442 = args[1];
  V v_i_2443 = args[2];
  V v_x_246 = heff_env(self)[0];
  V v_x_2412 = heff_env(self)[1];
  V v_x_2439 = heff_env(self)[2];
  V v_sgSafe_2426 = heff_env(self)[3];
  V v_x_2433 = heff_env(self)[4];
  V v_x_2424 = heff_env(self)[5];
  HeffT3 v_t_2444 = (g_heff_2ebuild_2edecoder_2eint_24cpr(v_s_2442, v_i_2443));
  {
    V v_field_2446 = v_t_2444.f[1];
    V v_field_2447 = v_t_2444.f[2];
    int64_t v_tag_2445 = ((int64_t)v_t_2444.f[0]);
    if ((v_tag_2445 == ((int64_t)0ULL))) {
      V v_x_2448 = v_field_2446;
      V v_j_2449 = v_field_2447;
      HeffT3 v_t_2450 = (g_heff_2ebuild_2edecoder_2etimes_24s98296704x1684150820_24cpr(v_x_2448, v_s_2442, v_j_2449));
      {
        V v_field_2452 = v_t_2450.f[1];
        V v_field_2453 = v_t_2450.f[2];
        int64_t v_tag_2451 = ((int64_t)v_t_2450.f[0]);
        if ((v_tag_2451 == ((int64_t)0ULL))) {
          V v_x_2454 = v_field_2452;
          V v_j_2455 = v_field_2453;
          heff_clo_take(self, 6);
          V v_t_2463 = heff_rec_n(2, shape_def__refs, (V[]){heff_rec_n(7, shape_key__name__body__safe__touched__sgSafe__sgTotal, (V[]){v_x_246, v_x_2412, heff_clo_n(g_heff_2ebuild_2ebackcache_2eunitD_lam2, 1, 1, (V[]){v_x_2439}), v_safe_2441, v_x_2454, v_sgSafe_2426, v_x_2433}), v_x_2424});
          return heff_tag_n(TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2463, v_j_2455})});
        } else {
          heff_drop(v_safe_2441);
          heff_drop(self);
          heff_drop(v_field_2452);
          heff_drop(v_field_2453);
          return NTAG(TAG_Nothing);
        }
      }
    } else {
      heff_drop(v_safe_2441);
      heff_drop(v_s_2442);
      heff_drop(self);
      heff_drop(v_field_2446);
      heff_drop(v_field_2447);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_heff_2ebuild_2ebackcache_2eunitD_lam0(V self, V *args) {
  V v_sgSafe_2426 = args[0];
  V v_s_2427 = args[1];
  V v_i_2428 = args[2];
  V v_x_246 = heff_env(self)[0];
  V v_x_2412 = heff_env(self)[1];
  V v_x_2424 = heff_env(self)[2];
  HeffT3 v_t_2429 = (g_heff_2ebuild_2edecoder_2eint_24cpr(v_s_2427, v_i_2428));
  {
    V v_field_2431 = v_t_2429.f[1];
    V v_field_2432 = v_t_2429.f[2];
    int64_t v_tag_2430 = ((int64_t)v_t_2429.f[0]);
    if ((v_tag_2430 == ((int64_t)0ULL))) {
      V v_x_2433 = v_field_2431;
      V v_j_2434 = v_field_2432;
      HeffT3 v_t_2435 = (g_heff_2ebuild_2edecoder_2estr_24cpr(heff_dup(v_s_2427), v_j_2434));
      {
        V v_field_2437 = v_t_2435.f[1];
        V v_field_2438 = v_t_2435.f[2];
        int64_t v_tag_2436 = ((int64_t)v_t_2435.f[0]);
        if ((v_tag_2436 == ((int64_t)0ULL))) {
          V v_x_2439 = v_field_2437;
          V v_j_2440 = v_field_2438;
          heff_clo_take(self, 3);
          return (g_heff_2ebuild_2edecoder_2ebind_24s823677936x1444069277(heff_clo_n(g_heff_2ebuild_2ebackcache_2eunitD_lam1, 3, 6, (V[]){v_x_246, v_x_2412, v_x_2439, v_sgSafe_2426, v_x_2433, v_x_2424}), v_s_2427, v_j_2440));
        } else {
          heff_drop(v_sgSafe_2426);
          heff_drop(v_s_2427);
          heff_drop(self);
          heff_drop(v_x_2433);
          heff_drop(v_field_2437);
          heff_drop(v_field_2438);
          return NTAG(TAG_Nothing);
        }
      }
    } else {
      heff_drop(v_sgSafe_2426);
      heff_drop(v_s_2427);
      heff_drop(self);
      heff_drop(v_field_2431);
      heff_drop(v_field_2432);
      return NTAG(TAG_Nothing);
    }
  }
}
HEFF_LIT(g_heff_2ebuild_2ebackcache_2emadeOf_24cpr_str0, 1, "j");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2emadeOf_24cpr_str1, 1, "n");
V g_heff_2ebuild_2ebackcache_2emadeOf_24cpr_lam0(V self, V *args);

HeffT3 g_heff_2ebuild_2ebackcache_2emadeOf_24cpr(V v_x1_240, V v_z_241, V v_z_242) {
top: ;
  if (heff_strEq_c_lent(v_x1_240, ((V)&g_heff_2ebuild_2ebackcache_2emadeOf_24cpr_str0), 2)) {
    HeffT3 v_t_243 = (g_heff_2ebuild_2edecoder_2estr_24cpr(heff_dup(v_z_241), v_z_242));
    {
      V v_field_245 = v_t_243.f[1];
      V v_field_246 = v_t_243.f[2];
      int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
      if ((v_tag_244 == ((int64_t)0ULL))) {
        V v_x_247 = v_field_245;
        V v_j_248 = v_field_246;
        HeffT3 v_t_249 = (g_heff_2ebuild_2edecoder_2eint_24cpr(v_z_241, v_j_248));
        {
          V v_field_2411 = v_t_249.f[1];
          V v_field_2412 = v_t_249.f[2];
          int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
          if ((v_tag_2410 == ((int64_t)0ULL))) {
            V v_x_2413 = v_field_2411;
            V v_j_2414 = v_field_2412;
            HeffT3 v_t_2415 = (g_heff_2ebuild_2edecoder_2etimes_24s98296704x1684150820_24cpr(v_x_2413, v_z_241, v_j_2414));
            {
              V v_field_2417 = v_t_2415.f[1];
              V v_field_2418 = v_t_2415.f[2];
              int64_t v_tag_2416 = ((int64_t)v_t_2415.f[0]);
              if ((v_tag_2416 == ((int64_t)0ULL))) {
                V v_x_2419 = v_field_2417;
                V v_j_2420 = v_field_2418;
                V v_t_2428 = heff_tag_n(TAG_Just, 1, (V[]){heff_rec_n(2, shape_body__touched, (V[]){heff_clo_n(g_heff_2ebuild_2ebackcache_2emadeOf_24cpr_lam0, 1, 1, (V[]){v_x_247}), v_x_2419})});
                return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), v_t_2428, v_j_2420}});
              } else {
                heff_drop(v_x_247);
                heff_drop(v_field_2417);
                heff_drop(v_field_2418);
                return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
              }
            }
          } else {
            heff_drop(v_z_241);
            heff_drop(v_x_247);
            heff_drop(v_field_2411);
            heff_drop(v_field_2412);
            return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
          }
        }
      } else {
        heff_drop(v_z_241);
        heff_drop(v_field_245);
        heff_drop(v_field_246);
        return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
      }
    }
  } else {
    if (heff_strEq_c_lent(v_x1_240, ((V)&g_heff_2ebuild_2ebackcache_2emadeOf_24cpr_str1), 2)) {
      heff_drop(v_z_241);
      return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), NTAG(TAG_Nothing), v_z_242}});
    } else {
      return ({ V a_0 = v_z_241; V a_1 = v_z_242; HeffT3 r_ = (g_heff_2ebuild_2edecoder_2efail_24cpr(a_0, a_1)); heff_drop(v_z_241); heff_drop(v_z_242); r_; });
    }
  }
}
V g_heff_2ebuild_2ebackcache_2emadeOf_24cpr_lam0(V self, V *args) {
  V v_u_2421 = args[0];
  V v_x_247 = heff_env(self)[0];
  heff_drop(v_u_2421);
  heff_clo_take(self, 1);
  HeffT3 v_t_2422 = (g_heff_2ebuild_2edecoder_2ewhole_24cpr(heff_dup(g_heff_2ecompile_2eirtext_2etakeExpr_get()), v_x_247, MK_INT(0LL)));
  {
    V v_field_2424 = v_t_2422.f[1];
    V v_field_2425 = v_t_2422.f[2];
    int64_t v_tag_2423 = ((int64_t)v_t_2422.f[0]);
    if ((v_tag_2423 == ((int64_t)0ULL))) {
      V v_x_2426 = v_field_2424;
      V v_x112_2427 = v_field_2425;
      heff_drop(v_x112_2427);
      return heff_tag_n(TAG_Just, 1, (V[]){v_x_2426});
    } else {
      heff_drop(v_field_2424);
      heff_drop(v_field_2425);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_heff_2ebuild_2ebackcache_2ecopyD_lam1(V self, V *args);
V g_heff_2ebuild_2ebackcache_2ecopyD_lam0(V self, V *args);
Clo g_heff_2ebuild_2ebackcache_2ecopyD_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebackcache_2ecopyD_entry, 2, 0};

V g_heff_2ebuild_2ebackcache_2ecopyD(V v_s_240, V v_i_241) {
top: ;
  HeffT3 v_t_242 = (g_heff_2ebuild_2edecoder_2estr_24cpr(heff_dup(v_s_240), v_i_241));
  {
    V v_field_244 = v_t_242.f[1];
    V v_field_245 = v_t_242.f[2];
    int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
    if ((v_tag_243 == ((int64_t)0ULL))) {
      V v_x_246 = v_field_244;
      V v_j_247 = v_field_245;
      HeffT3 v_t_248 = (g_heff_2ebuild_2edecoder_2estr_24cpr(heff_dup(v_s_240), v_j_247));
      {
        V v_field_2410 = v_t_248.f[1];
        V v_field_2411 = v_t_248.f[2];
        int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
        if ((v_tag_249 == ((int64_t)0ULL))) {
          V v_x_2412 = v_field_2410;
          V v_j_2413 = v_field_2411;
          HeffT3 v_t_2414 = (g_heff_2ebuild_2edecoder_2estr_24cpr(heff_dup(v_s_240), v_j_2413));
          {
            V v_field_2416 = v_t_2414.f[1];
            V v_field_2417 = v_t_2414.f[2];
            int64_t v_tag_2415 = ((int64_t)v_t_2414.f[0]);
            if ((v_tag_2415 == ((int64_t)0ULL))) {
              V v_x_2418 = v_field_2416;
              V v_j_2419 = v_field_2417;
              HeffT3 v_t_2420 = (g_heff_2ebuild_2edecoder_2eint_24cpr(v_s_240, v_j_2419));
              {
                V v_field_2422 = v_t_2420.f[1];
                V v_field_2423 = v_t_2420.f[2];
                int64_t v_tag_2421 = ((int64_t)v_t_2420.f[0]);
                if ((v_tag_2421 == ((int64_t)0ULL))) {
                  V v_x_2424 = v_field_2422;
                  V v_j_2425 = v_field_2423;
                  HeffT3 v_t_2426 = (g_heff_2ebuild_2edecoder_2etimes_24s98296704x1684150820_24cpr(v_x_2424, heff_dup(v_s_240), v_j_2425));
                  {
                    V v_field_2428 = v_t_2426.f[1];
                    V v_field_2429 = v_t_2426.f[2];
                    int64_t v_tag_2427 = ((int64_t)v_t_2426.f[0]);
                    if ((v_tag_2427 == ((int64_t)0ULL))) {
                      V v_x_2430 = v_field_2428;
                      V v_j_2431 = v_field_2429;
                      HeffT3 v_t_2432 = (g_heff_2ebuild_2edecoder_2eint_24cpr(v_s_240, v_j_2431));
                      {
                        V v_field_2434 = v_t_2432.f[1];
                        V v_field_2435 = v_t_2432.f[2];
                        int64_t v_tag_2433 = ((int64_t)v_t_2432.f[0]);
                        if ((v_tag_2433 == ((int64_t)0ULL))) {
                          V v_x_2436 = v_field_2434;
                          V v_j_2437 = v_field_2435;
                          return (g_heff_2ebuild_2edecoder_2ebind_24s823677936x1444069277(heff_clo_n(g_heff_2ebuild_2ebackcache_2ecopyD_lam0, 3, 5, (V[]){v_x_246, v_x_2412, v_x_2418, v_x_2430, v_x_2436}), v_s_240, v_j_2437));
                        } else {
                          heff_drop(v_s_240);
                          heff_drop(v_x_246);
                          heff_drop(v_x_2412);
                          heff_drop(v_x_2418);
                          heff_drop(v_x_2430);
                          heff_drop(v_field_2434);
                          heff_drop(v_field_2435);
                          return NTAG(TAG_Nothing);
                        }
                      }
                    } else {
                      heff_drop(v_s_240);
                      heff_drop(v_x_246);
                      heff_drop(v_x_2412);
                      heff_drop(v_x_2418);
                      heff_drop(v_field_2428);
                      heff_drop(v_field_2429);
                      return NTAG(TAG_Nothing);
                    }
                  }
                } else {
                  heff_drop(v_s_240);
                  heff_drop(v_x_246);
                  heff_drop(v_x_2412);
                  heff_drop(v_x_2418);
                  heff_drop(v_field_2422);
                  heff_drop(v_field_2423);
                  return NTAG(TAG_Nothing);
                }
              }
            } else {
              heff_drop(v_s_240);
              heff_drop(v_x_246);
              heff_drop(v_x_2412);
              heff_drop(v_field_2416);
              heff_drop(v_field_2417);
              return NTAG(TAG_Nothing);
            }
          }
        } else {
          heff_drop(v_s_240);
          heff_drop(v_x_246);
          heff_drop(v_field_2410);
          heff_drop(v_field_2411);
          return NTAG(TAG_Nothing);
        }
      }
    } else {
      heff_drop(v_s_240);
      heff_drop(v_field_244);
      heff_drop(v_field_245);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_heff_2ebuild_2ebackcache_2ecopyD_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ebackcache_2ecopyD(a[0], a[1]);
}
V g_heff_2ebuild_2ebackcache_2ecopyD_lam1(V self, V *args) {
  V v_u_2453 = args[0];
  V v_x_2418 = heff_env(self)[0];
  heff_drop(v_u_2453);
  heff_clo_take(self, 1);
  HeffT3 v_t_2454 = (g_heff_2ebuild_2edecoder_2ewhole_24cpr(heff_dup(g_heff_2ecompile_2eirtext_2etakeExpr_get()), v_x_2418, MK_INT(0LL)));
  {
    V v_field_2456 = v_t_2454.f[1];
    V v_field_2457 = v_t_2454.f[2];
    int64_t v_tag_2455 = ((int64_t)v_t_2454.f[0]);
    if ((v_tag_2455 == ((int64_t)0ULL))) {
      V v_x_2458 = v_field_2456;
      V v_x112_2459 = v_field_2457;
      heff_drop(v_x112_2459);
      return heff_tag_n(TAG_Just, 1, (V[]){v_x_2458});
    } else {
      heff_drop(v_field_2456);
      heff_drop(v_field_2457);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_heff_2ebuild_2ebackcache_2ecopyD_lam0(V self, V *args) {
  V v_safe_2438 = args[0];
  V v_s_2439 = args[1];
  V v_i_2440 = args[2];
  V v_x_246 = heff_env(self)[0];
  V v_x_2412 = heff_env(self)[1];
  V v_x_2418 = heff_env(self)[2];
  V v_x_2430 = heff_env(self)[3];
  V v_x_2436 = heff_env(self)[4];
  HeffT3 v_t_2441 = (g_heff_2ebuild_2edecoder_2eword_24cpr(v_s_2439, v_i_2440));
  {
    V v_field_2443 = v_t_2441.f[1];
    V v_field_2444 = v_t_2441.f[2];
    int64_t v_tag_2442 = ((int64_t)v_t_2441.f[0]);
    if ((v_tag_2442 == ((int64_t)0ULL))) {
      V v_x_2445 = v_field_2443;
      V v_j_2446 = v_field_2444;
      HeffT3 v_t_2447 = ({ V a_0 = v_x_2445; V a_1 = v_s_2439; V a_2 = v_j_2446; HeffT3 r_ = (g_heff_2ebuild_2ebackcache_2emadeOf_24cpr(a_0, a_1, a_2)); heff_drop(v_x_2445); r_; });
      {
        V v_field_2449 = v_t_2447.f[1];
        V v_field_2450 = v_t_2447.f[2];
        int64_t v_tag_2448 = ((int64_t)v_t_2447.f[0]);
        if ((v_tag_2448 == ((int64_t)0ULL))) {
          V v_x_2451 = v_field_2449;
          V v_j_2452 = v_field_2450;
          heff_clo_take(self, 5);
          V v_t_2460 = heff_tag_n(TAG_MkPair, 2, (V[]){v_x_246, heff_rec_n(6, shape_ver__recipe__asks__depth__safe__made, (V[]){v_x_2412, heff_clo_n(g_heff_2ebuild_2ebackcache_2ecopyD_lam1, 1, 1, (V[]){v_x_2418}), v_x_2430, v_x_2436, v_safe_2438, v_x_2451})});
          return heff_tag_n(TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2460, v_j_2452})});
        } else {
          heff_drop(v_safe_2438);
          heff_drop(self);
          heff_drop(v_field_2449);
          heff_drop(v_field_2450);
          return NTAG(TAG_Nothing);
        }
      }
    } else {
      heff_drop(v_safe_2438);
      heff_drop(v_s_2439);
      heff_drop(self);
      heff_drop(v_field_2443);
      heff_drop(v_field_2444);
      return NTAG(TAG_Nothing);
    }
  }
}

HeffT4 g_heff_2ebuild_2ebackcache_2eemitD_24cpr(V v_s_240, V v_i_241) {
top: ;
  HeffT3 v_t_242 = (g_heff_2ebuild_2edecoder_2estr_24cpr(heff_dup(v_s_240), v_i_241));
  {
    V v_field_244 = v_t_242.f[1];
    V v_field_245 = v_t_242.f[2];
    int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
    if ((v_tag_243 == ((int64_t)0ULL))) {
      V v_x_246 = v_field_244;
      V v_j_247 = v_field_245;
      HeffT3 v_t_248 = (g_heff_2ebuild_2edecoder_2estr_24cpr(heff_dup(v_s_240), v_j_247));
      {
        V v_field_2410 = v_t_248.f[1];
        V v_field_2411 = v_t_248.f[2];
        int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
        if ((v_tag_249 == ((int64_t)0ULL))) {
          V v_x_2412 = v_field_2410;
          V v_j_2413 = v_field_2411;
          HeffT3 v_t_2414 = (g_heff_2ebuild_2edecoder_2eint_24cpr(v_s_240, v_j_2413));
          {
            V v_field_2416 = v_t_2414.f[1];
            V v_field_2417 = v_t_2414.f[2];
            int64_t v_tag_2415 = ((int64_t)v_t_2414.f[0]);
            if ((v_tag_2415 == ((int64_t)0ULL))) {
              V v_x_2418 = v_field_2416;
              V v_j_2419 = v_field_2417;
              HeffT3 v_t_2420 = (g_heff_2ebuild_2edecoder_2etimes_24s1603230686x1883420273_24cpr(v_x_2418, heff_dup(v_s_240), v_j_2419));
              {
                V v_field_2422 = v_t_2420.f[1];
                V v_field_2423 = v_t_2420.f[2];
                int64_t v_tag_2421 = ((int64_t)v_t_2420.f[0]);
                if ((v_tag_2421 == ((int64_t)0ULL))) {
                  V v_x_2424 = v_field_2422;
                  V v_j_2425 = v_field_2423;
                  HeffT3 v_t_2426 = (g_heff_2ebuild_2edecoder_2eint_24cpr(v_s_240, v_j_2425));
                  {
                    V v_field_2428 = v_t_2426.f[1];
                    V v_field_2429 = v_t_2426.f[2];
                    int64_t v_tag_2427 = ((int64_t)v_t_2426.f[0]);
                    if ((v_tag_2427 == ((int64_t)0ULL))) {
                      V v_x_2430 = v_field_2428;
                      V v_j_2431 = v_field_2429;
                      HeffT3 v_t_2432 = (g_heff_2ebuild_2edecoder_2etimes_24s1603230686x1883420273_24cpr(v_x_2430, heff_dup(v_s_240), v_j_2431));
                      {
                        V v_field_2434 = v_t_2432.f[1];
                        V v_field_2435 = v_t_2432.f[2];
                        int64_t v_tag_2433 = ((int64_t)v_t_2432.f[0]);
                        if ((v_tag_2433 == ((int64_t)0ULL))) {
                          V v_x_2436 = v_field_2434;
                          V v_j_2437 = v_field_2435;
                          HeffT3 v_t_2438 = (g_heff_2ebuild_2edecoder_2eint_24cpr(v_s_240, v_j_2437));
                          {
                            V v_field_2440 = v_t_2438.f[1];
                            V v_field_2441 = v_t_2438.f[2];
                            int64_t v_tag_2439 = ((int64_t)v_t_2438.f[0]);
                            if ((v_tag_2439 == ((int64_t)0ULL))) {
                              V v_x_2442 = v_field_2440;
                              V v_j_2443 = v_field_2441;
                              HeffT3 v_t_2444 = (g_heff_2ebuild_2edecoder_2etimes_24s1603230686x1883420273_24cpr(v_x_2442, heff_dup(v_s_240), v_j_2443));
                              {
                                V v_field_2446 = v_t_2444.f[1];
                                V v_field_2447 = v_t_2444.f[2];
                                int64_t v_tag_2445 = ((int64_t)v_t_2444.f[0]);
                                if ((v_tag_2445 == ((int64_t)0ULL))) {
                                  V v_x_2448 = v_field_2446;
                                  V v_j_2449 = v_field_2447;
                                  HeffT3 v_t_2450 = (g_heff_2ebuild_2edecoder_2eint_24cpr(v_s_240, v_j_2449));
                                  {
                                    V v_field_2452 = v_t_2450.f[1];
                                    V v_field_2453 = v_t_2450.f[2];
                                    int64_t v_tag_2451 = ((int64_t)v_t_2450.f[0]);
                                    if ((v_tag_2451 == ((int64_t)0ULL))) {
                                      V v_x_2454 = v_field_2452;
                                      V v_j_2455 = v_field_2453;
                                      HeffT3 v_t_2456 = (g_heff_2ebuild_2edecoder_2etimes_24s1603230686x1883420273_24cpr(v_x_2454, heff_dup(v_s_240), v_j_2455));
                                      {
                                        V v_field_2458 = v_t_2456.f[1];
                                        V v_field_2459 = v_t_2456.f[2];
                                        int64_t v_tag_2457 = ((int64_t)v_t_2456.f[0]);
                                        if ((v_tag_2457 == ((int64_t)0ULL))) {
                                          V v_x_2460 = v_field_2458;
                                          V v_j_2461 = v_field_2459;
                                          HeffT3 v_t_2462 = (g_heff_2ebuild_2edecoder_2eint_24cpr(v_s_240, v_j_2461));
                                          {
                                            V v_field_2464 = v_t_2462.f[1];
                                            V v_field_2465 = v_t_2462.f[2];
                                            int64_t v_tag_2463 = ((int64_t)v_t_2462.f[0]);
                                            if ((v_tag_2463 == ((int64_t)0ULL))) {
                                              V v_x_2466 = v_field_2464;
                                              V v_j_2467 = v_field_2465;
                                              HeffT3 v_t_2468 = (g_heff_2ebuild_2edecoder_2etimes_24s1603230686x1883420273_24cpr(v_x_2466, heff_dup(v_s_240), v_j_2467));
                                              {
                                                V v_field_2470 = v_t_2468.f[1];
                                                V v_field_2471 = v_t_2468.f[2];
                                                int64_t v_tag_2469 = ((int64_t)v_t_2468.f[0]);
                                                if ((v_tag_2469 == ((int64_t)0ULL))) {
                                                  V v_x_2472 = v_field_2470;
                                                  V v_j_2473 = v_field_2471;
                                                  HeffT3 v_t_2474 = (g_heff_2ebuild_2edecoder_2eint_24cpr(v_s_240, v_j_2473));
                                                  {
                                                    V v_field_2476 = v_t_2474.f[1];
                                                    V v_field_2477 = v_t_2474.f[2];
                                                    int64_t v_tag_2475 = ((int64_t)v_t_2474.f[0]);
                                                    if ((v_tag_2475 == ((int64_t)0ULL))) {
                                                      V v_x_2478 = v_field_2476;
                                                      V v_j_2479 = v_field_2477;
                                                      HeffT3 v_t_2480 = (g_heff_2ebuild_2edecoder_2etimes_24s1603230686x1883420273_24cpr(v_x_2478, heff_dup(v_s_240), v_j_2479));
                                                      {
                                                        V v_field_2482 = v_t_2480.f[1];
                                                        V v_field_2483 = v_t_2480.f[2];
                                                        int64_t v_tag_2481 = ((int64_t)v_t_2480.f[0]);
                                                        if ((v_tag_2481 == ((int64_t)0ULL))) {
                                                          V v_x_2484 = v_field_2482;
                                                          V v_j_2485 = v_field_2483;
                                                          HeffT3 v_t_2486 = (g_heff_2ebuild_2edecoder_2eint_24cpr(v_s_240, v_j_2485));
                                                          {
                                                            V v_field_2488 = v_t_2486.f[1];
                                                            V v_field_2489 = v_t_2486.f[2];
                                                            int64_t v_tag_2487 = ((int64_t)v_t_2486.f[0]);
                                                            if ((v_tag_2487 == ((int64_t)0ULL))) {
                                                              V v_x_2490 = v_field_2488;
                                                              V v_j_2491 = v_field_2489;
                                                              HeffT3 v_t_2492 = (g_heff_2ebuild_2edecoder_2etimes_24s1603230686x1883420273_24cpr(v_x_2490, v_s_240, v_j_2491));
                                                              {
                                                                V v_field_2494 = v_t_2492.f[1];
                                                                V v_field_2495 = v_t_2492.f[2];
                                                                int64_t v_tag_2493 = ((int64_t)v_t_2492.f[0]);
                                                                if ((v_tag_2493 == ((int64_t)0ULL))) {
                                                                  V v_x_2496 = v_field_2494;
                                                                  V v_j_2497 = v_field_2495;
                                                                  return ((HeffT4){{heff_word_i64(((int64_t)0ULL)), v_x_246, heff_rec_n(8, shape_ver__protos__code__strs__lprotos__lams__shapes__prims, (V[]){v_x_2412, v_x_2424, v_x_2436, v_x_2448, v_x_2460, v_x_2472, v_x_2484, v_x_2496}), v_j_2497}});
                                                                } else {
                                                                  heff_drop(v_x_246);
                                                                  heff_drop(v_x_2412);
                                                                  heff_drop(v_x_2424);
                                                                  heff_drop(v_x_2436);
                                                                  heff_drop(v_x_2448);
                                                                  heff_drop(v_x_2460);
                                                                  heff_drop(v_x_2472);
                                                                  heff_drop(v_x_2484);
                                                                  heff_drop(v_field_2494);
                                                                  heff_drop(v_field_2495);
                                                                  return ((HeffT4){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL)}});
                                                                }
                                                              }
                                                            } else {
                                                              heff_drop(v_s_240);
                                                              heff_drop(v_x_246);
                                                              heff_drop(v_x_2412);
                                                              heff_drop(v_x_2424);
                                                              heff_drop(v_x_2436);
                                                              heff_drop(v_x_2448);
                                                              heff_drop(v_x_2460);
                                                              heff_drop(v_x_2472);
                                                              heff_drop(v_x_2484);
                                                              heff_drop(v_field_2488);
                                                              heff_drop(v_field_2489);
                                                              return ((HeffT4){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL)}});
                                                            }
                                                          }
                                                        } else {
                                                          heff_drop(v_s_240);
                                                          heff_drop(v_x_246);
                                                          heff_drop(v_x_2412);
                                                          heff_drop(v_x_2424);
                                                          heff_drop(v_x_2436);
                                                          heff_drop(v_x_2448);
                                                          heff_drop(v_x_2460);
                                                          heff_drop(v_x_2472);
                                                          heff_drop(v_field_2482);
                                                          heff_drop(v_field_2483);
                                                          return ((HeffT4){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL)}});
                                                        }
                                                      }
                                                    } else {
                                                      heff_drop(v_s_240);
                                                      heff_drop(v_x_246);
                                                      heff_drop(v_x_2412);
                                                      heff_drop(v_x_2424);
                                                      heff_drop(v_x_2436);
                                                      heff_drop(v_x_2448);
                                                      heff_drop(v_x_2460);
                                                      heff_drop(v_x_2472);
                                                      heff_drop(v_field_2476);
                                                      heff_drop(v_field_2477);
                                                      return ((HeffT4){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL)}});
                                                    }
                                                  }
                                                } else {
                                                  heff_drop(v_s_240);
                                                  heff_drop(v_x_246);
                                                  heff_drop(v_x_2412);
                                                  heff_drop(v_x_2424);
                                                  heff_drop(v_x_2436);
                                                  heff_drop(v_x_2448);
                                                  heff_drop(v_x_2460);
                                                  heff_drop(v_field_2470);
                                                  heff_drop(v_field_2471);
                                                  return ((HeffT4){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL)}});
                                                }
                                              }
                                            } else {
                                              heff_drop(v_s_240);
                                              heff_drop(v_x_246);
                                              heff_drop(v_x_2412);
                                              heff_drop(v_x_2424);
                                              heff_drop(v_x_2436);
                                              heff_drop(v_x_2448);
                                              heff_drop(v_x_2460);
                                              heff_drop(v_field_2464);
                                              heff_drop(v_field_2465);
                                              return ((HeffT4){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL)}});
                                            }
                                          }
                                        } else {
                                          heff_drop(v_s_240);
                                          heff_drop(v_x_246);
                                          heff_drop(v_x_2412);
                                          heff_drop(v_x_2424);
                                          heff_drop(v_x_2436);
                                          heff_drop(v_x_2448);
                                          heff_drop(v_field_2458);
                                          heff_drop(v_field_2459);
                                          return ((HeffT4){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL)}});
                                        }
                                      }
                                    } else {
                                      heff_drop(v_s_240);
                                      heff_drop(v_x_246);
                                      heff_drop(v_x_2412);
                                      heff_drop(v_x_2424);
                                      heff_drop(v_x_2436);
                                      heff_drop(v_x_2448);
                                      heff_drop(v_field_2452);
                                      heff_drop(v_field_2453);
                                      return ((HeffT4){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL)}});
                                    }
                                  }
                                } else {
                                  heff_drop(v_s_240);
                                  heff_drop(v_x_246);
                                  heff_drop(v_x_2412);
                                  heff_drop(v_x_2424);
                                  heff_drop(v_x_2436);
                                  heff_drop(v_field_2446);
                                  heff_drop(v_field_2447);
                                  return ((HeffT4){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL)}});
                                }
                              }
                            } else {
                              heff_drop(v_s_240);
                              heff_drop(v_x_246);
                              heff_drop(v_x_2412);
                              heff_drop(v_x_2424);
                              heff_drop(v_x_2436);
                              heff_drop(v_field_2440);
                              heff_drop(v_field_2441);
                              return ((HeffT4){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL)}});
                            }
                          }
                        } else {
                          heff_drop(v_s_240);
                          heff_drop(v_x_246);
                          heff_drop(v_x_2412);
                          heff_drop(v_x_2424);
                          heff_drop(v_field_2434);
                          heff_drop(v_field_2435);
                          return ((HeffT4){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL)}});
                        }
                      }
                    } else {
                      heff_drop(v_s_240);
                      heff_drop(v_x_246);
                      heff_drop(v_x_2412);
                      heff_drop(v_x_2424);
                      heff_drop(v_field_2428);
                      heff_drop(v_field_2429);
                      return ((HeffT4){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL)}});
                    }
                  }
                } else {
                  heff_drop(v_s_240);
                  heff_drop(v_x_246);
                  heff_drop(v_x_2412);
                  heff_drop(v_field_2422);
                  heff_drop(v_field_2423);
                  return ((HeffT4){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL)}});
                }
              }
            } else {
              heff_drop(v_s_240);
              heff_drop(v_x_246);
              heff_drop(v_x_2412);
              heff_drop(v_field_2416);
              heff_drop(v_field_2417);
              return ((HeffT4){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL)}});
            }
          }
        } else {
          heff_drop(v_s_240);
          heff_drop(v_x_246);
          heff_drop(v_field_2410);
          heff_drop(v_field_2411);
          return ((HeffT4){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL)}});
        }
      }
    } else {
      heff_drop(v_s_240);
      heff_drop(v_field_244);
      heff_drop(v_field_245);
      return ((HeffT4){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL)}});
    }
  }
}

HeffT4 g_heff_2ebuild_2ebackcache_2ejsD_24cpr(V v_s_240, V v_i_241) {
top: ;
  HeffT3 v_t_242 = (g_heff_2ebuild_2edecoder_2estr_24cpr(heff_dup(v_s_240), v_i_241));
  {
    V v_field_244 = v_t_242.f[1];
    V v_field_245 = v_t_242.f[2];
    int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
    if ((v_tag_243 == ((int64_t)0ULL))) {
      V v_x_246 = v_field_244;
      V v_j_247 = v_field_245;
      HeffT3 v_t_248 = (g_heff_2ebuild_2edecoder_2estr_24cpr(heff_dup(v_s_240), v_j_247));
      {
        V v_field_2410 = v_t_248.f[1];
        V v_field_2411 = v_t_248.f[2];
        int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
        if ((v_tag_249 == ((int64_t)0ULL))) {
          V v_x_2412 = v_field_2410;
          V v_j_2413 = v_field_2411;
          HeffT3 v_t_2414 = (g_heff_2ebuild_2edecoder_2eint_24cpr(v_s_240, v_j_2413));
          {
            V v_field_2416 = v_t_2414.f[1];
            V v_field_2417 = v_t_2414.f[2];
            int64_t v_tag_2415 = ((int64_t)v_t_2414.f[0]);
            if ((v_tag_2415 == ((int64_t)0ULL))) {
              V v_x_2418 = v_field_2416;
              V v_j_2419 = v_field_2417;
              HeffT3 v_t_2420 = (g_heff_2ebuild_2edecoder_2etimes_24s1603230686x1883420273_24cpr(v_x_2418, heff_dup(v_s_240), v_j_2419));
              {
                V v_field_2422 = v_t_2420.f[1];
                V v_field_2423 = v_t_2420.f[2];
                int64_t v_tag_2421 = ((int64_t)v_t_2420.f[0]);
                if ((v_tag_2421 == ((int64_t)0ULL))) {
                  V v_x_2424 = v_field_2422;
                  V v_j_2425 = v_field_2423;
                  HeffT3 v_t_2426 = (g_heff_2ebuild_2edecoder_2eint_24cpr(v_s_240, v_j_2425));
                  {
                    V v_field_2428 = v_t_2426.f[1];
                    V v_field_2429 = v_t_2426.f[2];
                    int64_t v_tag_2427 = ((int64_t)v_t_2426.f[0]);
                    if ((v_tag_2427 == ((int64_t)0ULL))) {
                      V v_x_2430 = v_field_2428;
                      V v_j_2431 = v_field_2429;
                      HeffT3 v_t_2432 = (g_heff_2ebuild_2edecoder_2etimes_24s1603230686x1883420273_24cpr(v_x_2430, heff_dup(v_s_240), v_j_2431));
                      {
                        V v_field_2434 = v_t_2432.f[1];
                        V v_field_2435 = v_t_2432.f[2];
                        int64_t v_tag_2433 = ((int64_t)v_t_2432.f[0]);
                        if ((v_tag_2433 == ((int64_t)0ULL))) {
                          V v_x_2436 = v_field_2434;
                          V v_j_2437 = v_field_2435;
                          HeffT3 v_t_2438 = (g_heff_2ebuild_2edecoder_2eint_24cpr(v_s_240, v_j_2437));
                          {
                            V v_field_2440 = v_t_2438.f[1];
                            V v_field_2441 = v_t_2438.f[2];
                            int64_t v_tag_2439 = ((int64_t)v_t_2438.f[0]);
                            if ((v_tag_2439 == ((int64_t)0ULL))) {
                              V v_x_2442 = v_field_2440;
                              V v_j_2443 = v_field_2441;
                              HeffT3 v_t_2444 = (g_heff_2ebuild_2edecoder_2etimes_24s1603230686x1883420273_24cpr(v_x_2442, heff_dup(v_s_240), v_j_2443));
                              {
                                V v_field_2446 = v_t_2444.f[1];
                                V v_field_2447 = v_t_2444.f[2];
                                int64_t v_tag_2445 = ((int64_t)v_t_2444.f[0]);
                                if ((v_tag_2445 == ((int64_t)0ULL))) {
                                  V v_x_2448 = v_field_2446;
                                  V v_j_2449 = v_field_2447;
                                  HeffT3 v_t_2450 = (g_heff_2ebuild_2edecoder_2eint_24cpr(v_s_240, v_j_2449));
                                  {
                                    V v_field_2452 = v_t_2450.f[1];
                                    V v_field_2453 = v_t_2450.f[2];
                                    int64_t v_tag_2451 = ((int64_t)v_t_2450.f[0]);
                                    if ((v_tag_2451 == ((int64_t)0ULL))) {
                                      V v_x_2454 = v_field_2452;
                                      V v_j_2455 = v_field_2453;
                                      HeffT3 v_t_2456 = (g_heff_2ebuild_2edecoder_2etimes_24s1603230686x1883420273_24cpr(v_x_2454, v_s_240, v_j_2455));
                                      {
                                        V v_field_2458 = v_t_2456.f[1];
                                        V v_field_2459 = v_t_2456.f[2];
                                        int64_t v_tag_2457 = ((int64_t)v_t_2456.f[0]);
                                        if ((v_tag_2457 == ((int64_t)0ULL))) {
                                          V v_x_2460 = v_field_2458;
                                          V v_j_2461 = v_field_2459;
                                          return ((HeffT4){{heff_word_i64(((int64_t)0ULL)), v_x_246, heff_rec_n(5, shape_ver__lines__params__refs__prims, (V[]){v_x_2412, v_x_2424, v_x_2436, v_x_2448, v_x_2460}), v_j_2461}});
                                        } else {
                                          heff_drop(v_x_246);
                                          heff_drop(v_x_2412);
                                          heff_drop(v_x_2424);
                                          heff_drop(v_x_2436);
                                          heff_drop(v_x_2448);
                                          heff_drop(v_field_2458);
                                          heff_drop(v_field_2459);
                                          return ((HeffT4){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL)}});
                                        }
                                      }
                                    } else {
                                      heff_drop(v_s_240);
                                      heff_drop(v_x_246);
                                      heff_drop(v_x_2412);
                                      heff_drop(v_x_2424);
                                      heff_drop(v_x_2436);
                                      heff_drop(v_x_2448);
                                      heff_drop(v_field_2452);
                                      heff_drop(v_field_2453);
                                      return ((HeffT4){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL)}});
                                    }
                                  }
                                } else {
                                  heff_drop(v_s_240);
                                  heff_drop(v_x_246);
                                  heff_drop(v_x_2412);
                                  heff_drop(v_x_2424);
                                  heff_drop(v_x_2436);
                                  heff_drop(v_field_2446);
                                  heff_drop(v_field_2447);
                                  return ((HeffT4){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL)}});
                                }
                              }
                            } else {
                              heff_drop(v_s_240);
                              heff_drop(v_x_246);
                              heff_drop(v_x_2412);
                              heff_drop(v_x_2424);
                              heff_drop(v_x_2436);
                              heff_drop(v_field_2440);
                              heff_drop(v_field_2441);
                              return ((HeffT4){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL)}});
                            }
                          }
                        } else {
                          heff_drop(v_s_240);
                          heff_drop(v_x_246);
                          heff_drop(v_x_2412);
                          heff_drop(v_x_2424);
                          heff_drop(v_field_2434);
                          heff_drop(v_field_2435);
                          return ((HeffT4){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL)}});
                        }
                      }
                    } else {
                      heff_drop(v_s_240);
                      heff_drop(v_x_246);
                      heff_drop(v_x_2412);
                      heff_drop(v_x_2424);
                      heff_drop(v_field_2428);
                      heff_drop(v_field_2429);
                      return ((HeffT4){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL)}});
                    }
                  }
                } else {
                  heff_drop(v_s_240);
                  heff_drop(v_x_246);
                  heff_drop(v_x_2412);
                  heff_drop(v_field_2422);
                  heff_drop(v_field_2423);
                  return ((HeffT4){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL)}});
                }
              }
            } else {
              heff_drop(v_s_240);
              heff_drop(v_x_246);
              heff_drop(v_x_2412);
              heff_drop(v_field_2416);
              heff_drop(v_field_2417);
              return ((HeffT4){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL)}});
            }
          }
        } else {
          heff_drop(v_s_240);
          heff_drop(v_x_246);
          heff_drop(v_field_2410);
          heff_drop(v_field_2411);
          return ((HeffT4){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL)}});
        }
      }
    } else {
      heff_drop(v_s_240);
      heff_drop(v_field_244);
      heff_drop(v_field_245);
      return ((HeffT4){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL), MK_INT(0LL)}});
    }
  }
}
HEFF_REC_LIT(g_heff_2ebuild_2ebackcache_2enoBack_lit0, 4, shape_groups__copies__emits__jss, NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil), NTAG(TAG_Nil));

static V g_heff_2ebuild_2ebackcache_2enoBack_val;
static HEFF_ONCE g_heff_2ebuild_2ebackcache_2enoBack_st;
static V g_heff_2ebuild_2ebackcache_2enoBack_init(void) {
  return ((V)&g_heff_2ebuild_2ebackcache_2enoBack_lit0);
}
V g_heff_2ebuild_2ebackcache_2enoBack_get(void) {
  if (HEFF_DONE(g_heff_2ebuild_2ebackcache_2enoBack_st)) return g_heff_2ebuild_2ebackcache_2enoBack_val;
  return heff_global(&g_heff_2ebuild_2ebackcache_2enoBack_val, &g_heff_2ebuild_2ebackcache_2enoBack_st, g_heff_2ebuild_2ebackcache_2enoBack_init);
}
HEFF_LIT(g_heff_2ebuild_2ebackcache_2ebackD_24cpr_str0, 3, "end");

HeffT3 g_heff_2ebuild_2ebackcache_2ebackD_24cpr(V v_id_240, V v_s_241, V v_i_242) {
top: ;
  HeffT3 v_t_243 = (g_heff_2ebuild_2edecoder_2estr_24cpr(heff_dup(v_s_241), v_i_242));
  {
    V v_field_245 = v_t_243.f[1];
    V v_field_246 = v_t_243.f[2];
    int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
    if ((v_tag_244 == ((int64_t)0ULL))) {
      V v_x_247 = v_field_245;
      V v_j_248 = v_field_246;
      if (heff_strEq_c(v_x_247, heff_dup(g_heff_2ebuild_2ebackcache_2eversion_get()))) {
        V v_x_249 = NTAG(TAG_MkUnit);
        V v_j_2410 = v_j_248;
        HeffT3 v_t_2411 = (g_heff_2ebuild_2edecoder_2estr_24cpr(heff_dup(v_s_241), v_j_2410));
        {
          V v_field_2413 = v_t_2411.f[1];
          V v_field_2414 = v_t_2411.f[2];
          int64_t v_tag_2412 = ((int64_t)v_t_2411.f[0]);
          if ((v_tag_2412 == ((int64_t)0ULL))) {
            V v_x_2415 = v_field_2413;
            V v_j_2416 = v_field_2414;
            if (heff_strEq_c_lent(v_x_2415, v_id_240, 1)) {
              HeffT3 v_t_2417 = (g_heff_2ebuild_2edecoder_2eint_24cpr(v_s_241, v_j_2416));
              {
                V v_field_2419 = v_t_2417.f[1];
                V v_field_2420 = v_t_2417.f[2];
                int64_t v_tag_2418 = ((int64_t)v_t_2417.f[0]);
                if ((v_tag_2418 == ((int64_t)0ULL))) {
                  V v_x_2421 = v_field_2419;
                  V v_j_2422 = v_field_2420;
                  HeffT3 v_t_2423 = (g_heff_2ebuild_2edecoder_2etimes_24s2049614891x1595878686_24cpr(v_x_2421, heff_dup(v_s_241), v_j_2422));
                  {
                    V v_field_2425 = v_t_2423.f[1];
                    V v_field_2426 = v_t_2423.f[2];
                    int64_t v_tag_2424 = ((int64_t)v_t_2423.f[0]);
                    if ((v_tag_2424 == ((int64_t)0ULL))) {
                      V v_x_2427 = v_field_2425;
                      V v_j_2428 = v_field_2426;
                      HeffT3 v_t_2429 = (g_heff_2ebuild_2edecoder_2eint_24cpr(v_s_241, v_j_2428));
                      {
                        V v_field_2431 = v_t_2429.f[1];
                        V v_field_2432 = v_t_2429.f[2];
                        int64_t v_tag_2430 = ((int64_t)v_t_2429.f[0]);
                        if ((v_tag_2430 == ((int64_t)0ULL))) {
                          V v_x_2433 = v_field_2431;
                          V v_j_2434 = v_field_2432;
                          HeffT3 v_t_2435 = (g_heff_2ebuild_2edecoder_2etimes_24s481066606x2100141841_24cpr(v_x_2433, heff_dup(v_s_241), v_j_2434));
                          {
                            V v_field_2437 = v_t_2435.f[1];
                            V v_field_2438 = v_t_2435.f[2];
                            int64_t v_tag_2436 = ((int64_t)v_t_2435.f[0]);
                            if ((v_tag_2436 == ((int64_t)0ULL))) {
                              V v_x_2439 = v_field_2437;
                              V v_j_2440 = v_field_2438;
                              HeffT3 v_t_2441 = (g_heff_2ebuild_2edecoder_2eint_24cpr(v_s_241, v_j_2440));
                              {
                                V v_field_2443 = v_t_2441.f[1];
                                V v_field_2444 = v_t_2441.f[2];
                                int64_t v_tag_2442 = ((int64_t)v_t_2441.f[0]);
                                if ((v_tag_2442 == ((int64_t)0ULL))) {
                                  V v_x_2445 = v_field_2443;
                                  V v_j_2446 = v_field_2444;
                                  HeffT3 v_t_2447 = (g_heff_2ebuild_2edecoder_2etimes_24s1954476619x1073210498_24cpr(v_x_2445, heff_dup(v_s_241), v_j_2446));
                                  {
                                    V v_field_2449 = v_t_2447.f[1];
                                    V v_field_2450 = v_t_2447.f[2];
                                    int64_t v_tag_2448 = ((int64_t)v_t_2447.f[0]);
                                    if ((v_tag_2448 == ((int64_t)0ULL))) {
                                      V v_x_2451 = v_field_2449;
                                      V v_j_2452 = v_field_2450;
                                      HeffT3 v_t_2453 = (g_heff_2ebuild_2edecoder_2eint_24cpr(v_s_241, v_j_2452));
                                      {
                                        V v_field_2455 = v_t_2453.f[1];
                                        V v_field_2456 = v_t_2453.f[2];
                                        int64_t v_tag_2454 = ((int64_t)v_t_2453.f[0]);
                                        if ((v_tag_2454 == ((int64_t)0ULL))) {
                                          V v_x_2457 = v_field_2455;
                                          V v_j_2458 = v_field_2456;
                                          HeffT3 v_t_2459 = (g_heff_2ebuild_2edecoder_2etimes_24s1391953550x1663492198_24cpr(v_x_2457, heff_dup(v_s_241), v_j_2458));
                                          {
                                            V v_field_2461 = v_t_2459.f[1];
                                            V v_field_2462 = v_t_2459.f[2];
                                            int64_t v_tag_2460 = ((int64_t)v_t_2459.f[0]);
                                            if ((v_tag_2460 == ((int64_t)0ULL))) {
                                              V v_x_2463 = v_field_2461;
                                              V v_j_2464 = v_field_2462;
                                              HeffT3 v_t_2465 = (g_heff_2ebuild_2edecoder_2estr_24cpr(v_s_241, v_j_2464));
                                              {
                                                V v_field_2467 = v_t_2465.f[1];
                                                V v_field_2468 = v_t_2465.f[2];
                                                int64_t v_tag_2466 = ((int64_t)v_t_2465.f[0]);
                                                if ((v_tag_2466 == ((int64_t)0ULL))) {
                                                  V v_x_2469 = v_field_2467;
                                                  V v_j_2470 = v_field_2468;
                                                  if (heff_strEq_c(v_x_2469, ((V)&g_heff_2ebuild_2ebackcache_2ebackD_24cpr_str0))) {
                                                    return ((HeffT3){{heff_word_i64(((int64_t)0ULL)), heff_rec_n(4, shape_groups__copies__emits__jss, (V[]){v_x_2427, v_x_2439, v_x_2451, v_x_2463}), v_j_2470}});
                                                  } else {
                                                    heff_drop(v_x_2427);
                                                    heff_drop(v_x_2439);
                                                    heff_drop(v_x_2451);
                                                    heff_drop(v_x_2463);
                                                    heff_drop(v_j_2470);
                                                    return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                                                  }
                                                } else {
                                                  heff_drop(v_x_2427);
                                                  heff_drop(v_x_2439);
                                                  heff_drop(v_x_2451);
                                                  heff_drop(v_x_2463);
                                                  heff_drop(v_field_2467);
                                                  heff_drop(v_field_2468);
                                                  return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                                                }
                                              }
                                            } else {
                                              heff_drop(v_s_241);
                                              heff_drop(v_x_2427);
                                              heff_drop(v_x_2439);
                                              heff_drop(v_x_2451);
                                              heff_drop(v_field_2461);
                                              heff_drop(v_field_2462);
                                              return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                                            }
                                          }
                                        } else {
                                          heff_drop(v_s_241);
                                          heff_drop(v_x_2427);
                                          heff_drop(v_x_2439);
                                          heff_drop(v_x_2451);
                                          heff_drop(v_field_2455);
                                          heff_drop(v_field_2456);
                                          return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                                        }
                                      }
                                    } else {
                                      heff_drop(v_s_241);
                                      heff_drop(v_x_2427);
                                      heff_drop(v_x_2439);
                                      heff_drop(v_field_2449);
                                      heff_drop(v_field_2450);
                                      return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                                    }
                                  }
                                } else {
                                  heff_drop(v_s_241);
                                  heff_drop(v_x_2427);
                                  heff_drop(v_x_2439);
                                  heff_drop(v_field_2443);
                                  heff_drop(v_field_2444);
                                  return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                                }
                              }
                            } else {
                              heff_drop(v_s_241);
                              heff_drop(v_x_2427);
                              heff_drop(v_field_2437);
                              heff_drop(v_field_2438);
                              return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                            }
                          }
                        } else {
                          heff_drop(v_s_241);
                          heff_drop(v_x_2427);
                          heff_drop(v_field_2431);
                          heff_drop(v_field_2432);
                          return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                        }
                      }
                    } else {
                      heff_drop(v_s_241);
                      heff_drop(v_field_2425);
                      heff_drop(v_field_2426);
                      return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                    }
                  }
                } else {
                  heff_drop(v_s_241);
                  heff_drop(v_field_2419);
                  heff_drop(v_field_2420);
                  return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
                }
              }
            } else {
              heff_drop(v_s_241);
              heff_drop(v_j_2416);
              return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
            }
          } else {
            heff_drop(v_s_241);
            heff_drop(v_field_2413);
            heff_drop(v_field_2414);
            return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
          }
        }
      } else {
        heff_drop(v_s_241);
        heff_drop(v_j_248);
        return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
      }
    } else {
      heff_drop(v_s_241);
      heff_drop(v_field_245);
      heff_drop(v_field_246);
      return ((HeffT3){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL), MK_INT(0LL)}});
    }
  }
}
Clo g_heff_2ebuild_2ebackcache_2elastDotGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebackcache_2elastDotGo_entry, 3, 0};

V g_heff_2ebuild_2ebackcache_2elastDotGo(V v_k_240, V v_i_241, V v_at_242) {
top: ;
  if ((heff_unbox_word(heff_strLength_lent(v_k_240, 0)) <= heff_peek_word(v_i_241))) {
    heff_drop(v_i_241);
    return v_at_242;
  } else {
    V v_t_243;
    if ((heff_unbox_word(heff_strByteAt_lent(v_k_240, v_i_241, 0)) == ((int64_t)46ULL))) {
      heff_drop(v_at_242);
      v_t_243 = heff_dup(v_i_241);
    } else {
      v_t_243 = v_at_242;
    }
    V t_0 = v_k_240;
    V t_1 = heff_box_word((heff_unbox_word(v_i_241) + ((int64_t)1ULL)));
    V t_2 = v_t_243;
    v_k_240 = t_0;
    v_i_241 = t_1;
    v_at_242 = t_2;
    goto top;
  }
}
V g_heff_2ebuild_2ebackcache_2elastDotGo_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ebackcache_2elastDotGo(a0, a[1], a[2]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ebuild_2ebackcache_2emoduleIn_str0, 1, "_");
Clo g_heff_2ebuild_2ebackcache_2emoduleIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebackcache_2emoduleIn_entry, 2, 0};

V g_heff_2ebuild_2ebackcache_2emoduleIn(V v_mods_240, V v_k_241) {
top: ;
  HeffT2 v_t_242 = (g_std_2eordmap_2elookup_24s2065330800x1141937666_24cpr(v_mods_240, v_k_241));
  {
    V v_field_244 = v_t_242.f[1];
    int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
    if ((v_tag_243 == ((int64_t)0ULL))) {
      V v_x_245 = v_field_244;
      heff_drop(v_x_245);
      return v_k_241;
    } else {
      heff_drop(v_field_244);
      V v_t_246 = (g_heff_2ebuild_2ebackcache_2elastDotGo(v_k_241, MK_INT(0LL), MK_INT(-1LL)));
      if (heff_intLe_c(v_t_246, MK_INT(0LL))) {
        heff_drop(v_k_241);
        return ((V)&g_heff_2ebuild_2ebackcache_2emoduleIn_str0);
      } else {
        V v_t_247 = (g_heff_2ebuild_2ebackcache_2elastDotGo(v_k_241, MK_INT(0LL), MK_INT(-1LL)));
        V t_0 = v_mods_240;
        V t_1 = heff_strSlice(v_k_241, MK_INT(0LL), v_t_247);
        v_mods_240 = t_0;
        v_k_241 = t_1;
        goto top;
      }
    }
  }
}
V g_heff_2ebuild_2ebackcache_2emoduleIn_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ebackcache_2emoduleIn(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2ebuild_2ebackcache_2eentriesAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebackcache_2eentriesAt_entry, 3, 0};

V g_heff_2ebuild_2ebackcache_2eentriesAt(V v_olds_240, V v_m_241, V v_k_242) {
top: ;
  HeffT2 v_t_243 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(v_m_241, v_k_242));
  {
    V v_field_245 = v_t_243.f[1];
    int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
    if ((v_tag_244 == ((int64_t)0ULL))) {
      V v_es_246 = v_field_245;
      return v_es_246;
    } else {
      heff_drop(v_field_245);
      HeffT2 v_t_247 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(v_olds_240, v_k_242));
      {
        V v_field_249 = v_t_247.f[1];
        int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
        V v_b_2411;
        if ((v_tag_248 == ((int64_t)0ULL))) {
          V v_x_2410 = v_field_249;
          v_b_2411 = v_x_2410;
        } else {
          heff_drop(v_field_249);
          v_b_2411 = heff_dup(g_heff_2ebuild_2ebackcache_2enoBack_get());
        }
        V v_groups_2412 = heff_take_field(v_b_2411, 0);
        V v_copies_2413 = heff_take_field(v_b_2411, 1);
        V v_emits_2414 = heff_take_field(v_b_2411, 2);
        V v_jss_2415 = heff_take_field(v_b_2411, 3);
        V v_t_2416 = ({ V a_0 = heff_dup(g_std_2eordmap_2eempty_get()); V a_1 = v_groups_2412; V r_ = (g_list_2efoldl_24s224553292x101133675(a_0, a_1)); heff_drop(v_groups_2412); r_; });
        V v_t_2417 = ({ V a_0 = heff_dup(g_std_2eordmap_2eempty_get()); V a_1 = v_copies_2413; V r_ = (g_list_2efoldl_24s1533929316x1834489357(a_0, a_1)); heff_drop(v_copies_2413); r_; });
        V v_t_2418 = ({ V a_0 = heff_dup(g_std_2eordmap_2eempty_get()); V a_1 = v_emits_2414; V r_ = (g_list_2efoldl_24s1533929316x1834489357(a_0, a_1)); heff_drop(v_emits_2414); r_; });
        V v_t_2419 = ({ V a_0 = heff_dup(g_std_2eordmap_2eempty_get()); V a_1 = v_jss_2415; V r_ = (g_list_2efoldl_24s1533929316x1834489357(a_0, a_1)); heff_drop(v_jss_2415); r_; });
        return ({ V rv_0 = v_t_2416; V rv_1 = v_t_2417; V rv_2 = v_t_2418; V rv_3 = v_t_2419; V rr_ = heff_rec_reuse_nf(v_b_2411, 0ULL, 4, shape_groups__copies__emits__jss, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; rr_; });
      }
    }
  }
}
V g_heff_2ebuild_2ebackcache_2eentriesAt_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V r = g_heff_2ebuild_2ebackcache_2eentriesAt(a0, a1, a2); heff_drop(a0); heff_drop(a1); heff_drop(a2); return r;
}

HeffT2 g_heff_2ebuild_2ebackcache_2eallJustB_24cpr(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), NTAG(TAG_Nil)}});
  }
  case TAG_Cons: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_Nothing: {
      heff_drop(v_rest_242);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_Just: {
      V v_x_243 = heff_field(v_x11_241, 0);
      heff_take_n(v_x11_241, 1ULL, 1);
      HeffT2 v_t_244 = (g_heff_2ebuild_2ebackcache_2eallJustB_24cpr(v_rest_242));
      {
        V v_field_246 = v_t_244.f[1];
        int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
        if ((v_tag_245 == ((int64_t)0ULL))) {
          V v_xs_247 = v_field_246;
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_243, v_xs_247})}});
        } else {
          heff_drop_cell(v_ru_24x1_240_24Cons, 2);
          heff_drop(v_x_243);
          heff_drop(v_field_246);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x11_241)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
HEFF_LIT(g_heff_2ebuild_2ebackcache_2eaddGroup_str0, 1, ":");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2eaddGroup_str1, 1, ":");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2eaddGroup_str2, 1, " ");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2eaddGroup_str3, 1, " ");
V g_heff_2ebuild_2ebackcache_2eaddGroup_lam0(V self, V *args);
V g_heff_2ebuild_2ebackcache_2eaddGroup_lam1(V self, V *args);
Clo g_heff_2ebuild_2ebackcache_2eaddGroup_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebackcache_2eaddGroup_entry, 3, 0};

V g_heff_2ebuild_2ebackcache_2eaddGroup(V v_fs_240, V v_m_241, V v_g_242) {
top: ;
  V v_fs_243 = heff_dup(v_fs_240);
  V v_m_244 = v_m_241;
  V v_md_245 = (g_heff_2ebuild_2ebackcache_2emoduleIn(heff_rfield(v_fs_240, 0), heff_dup(heff_rfield(v_g_242, 0))));
  V v_g_246 = heff_dup(v_g_242);
  V v_owner_247 = heff_dup(heff_rfield(v_g_242, 0));
  V v_ver_248 = heff_dup(heff_rfield(v_g_242, 1));
  V v_olds_249 = heff_take_field(v_fs_240, 1);
  V v_m_2410 = ({ V b_0 = heff_get_n(v_fs_240, 0, 2); V a_1 = heff_dup(heff_rfield(v_g_242, 0)); V r_ = (g_heff_2ebuild_2ebackcache_2emoduleIn(b_0, a_1)); heff_drop(b_0); r_; });
  HeffT2 v_t_2411 = ({ V a_0 = v_olds_249; V a_1 = v_m_2410; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_olds_249); heff_drop(v_m_2410); r_; });
  {
    V v_field_2413 = v_t_2411.f[1];
    int64_t v_tag_2412 = ((int64_t)v_t_2411.f[0]);
    V v_t_2415;
    if ((v_tag_2412 == ((int64_t)0ULL))) {
      V v_x_2414 = v_field_2413;
      v_t_2415 = v_x_2414;
    } else {
      heff_drop(v_field_2413);
      v_t_2415 = heff_dup(g_heff_2ebuild_2ebackcache_2enoBack_get());
    }
    V v_t_2416 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_get_n(v_t_2415, 0, 4)));
    V v_old_2426 = ({ V a_0 = heff_clo_n(g_heff_2ebuild_2ebackcache_2eaddGroup_lam0, 2, 1, (V[]){heff_dup(v_g_242)}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_2416; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2416); r_; });
    V v_t_2439 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2ebackcache_2eaddGroup_lam1, 1, 1, (V[]){v_old_2426}), heff_get_n(v_g_242, 2, 3)));
    HeffT2 v_t_2440 = (g_heff_2ebuild_2ebackcache_2eallJustB_24cpr(v_t_2439));
    {
      V v_field_2442 = v_t_2440.f[1];
      int64_t v_tag_2441 = ((int64_t)v_t_2440.f[0]);
      V v_x5_2452;
      if ((v_tag_2441 == ((int64_t)0ULL))) {
        V v_us_2443 = v_field_2442;
        V v_t_2444 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_us_2443));
        V v_t_2445 = heff_intShow(v_t_2444);
        V v_t_2446 = heff_intShow(heff_strLength_lent(v_ver_248, 0));
        V v_t_2447 = heff_strAppend(heff_strAppend(v_t_2446, ((V)&g_heff_2ebuild_2ebackcache_2eaddGroup_str0)), v_ver_248);
        V v_t_2448 = heff_intShow(heff_strLength_lent(v_owner_247, 0));
        V v_t_2449 = heff_strAppend(heff_strAppend(v_t_2448, ((V)&g_heff_2ebuild_2ebackcache_2eaddGroup_str1)), v_owner_247);
        V v_t_2450 = heff_strAppend(heff_strAppend(v_t_2449, ((V)&g_heff_2ebuild_2ebackcache_2eaddGroup_str2)), v_t_2447);
        V v_t_2451 = ({ V a_0 = ((V)&g_heff_2ebuild_2ebackcache_2eaddGroup_str3); V a_1 = v_t_2450; V b_2 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2445, v_us_2443}); V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, b_2)); heff_drop(b_2); r_; });
        v_x5_2452 = heff_tag_n(TAG_Just, 1, (V[]){v_t_2451});
      } else {
        heff_drop(v_owner_247);
        heff_drop(v_ver_248);
        heff_drop(v_field_2442);
        v_x5_2452 = NTAG(TAG_Nothing);
      }
      switch (heff_tag_of(v_x5_2452)) {
      case TAG_Nothing: {
        heff_drop_rec(v_fs_243, 2);
        heff_drop(v_md_245);
        heff_drop_rec(v_g_246, 3);
        return v_m_244;
      }
      case TAG_Just: {
        V v_t_2453 = heff_field(v_x5_2452, 0);
        heff_take_n(v_x5_2452, 1ULL, 1);
        V v_es_2454 = ({ V b_0 = heff_get_n(v_fs_243, 1, 2); V a_1 = v_m_244; V a_2 = v_md_245; V r_ = (g_heff_2ebuild_2ebackcache_2eentriesAt(b_0, a_1, a_2)); heff_drop(b_0); r_; });
        V v_t_2455 = (g_std_2eordmap_2einsert_24s615484302x989744458(heff_take_field(v_es_2454, 0), heff_get_n(v_g_246, 0, 3), v_t_2453));
        V v_t_2456 = ({ V rv_0 = v_t_2455; V rr_ = heff_rec_reuse_nf(v_es_2454, 14ULL, 4, shape_groups__copies__emits__jss, 252u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
        HEFF_LAST return g_std_2eordmap_2einsert_24s615484302x989744458(v_m_244, v_md_245, v_t_2456);
      }
      default: return heff_nomatch(v_x5_2452);
      }
    }
  }
}
V g_heff_2ebuild_2ebackcache_2eaddGroup_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ebackcache_2eaddGroup(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2ebackcache_2eaddGroup_lam0(V self, V *args) {
  V v_acc_2417 = args[0];
  V v_x_2418 = args[1];
  V v_g_242 = heff_env(self)[0];
  V v_t_2421;
  switch (heff_tag_of(v_x_2418)) {
  case TAG_MkPair: {
    V v_x_2419 = heff_dup(heff_field(v_x_2418, 0));
    v_t_2421 = v_x_2419;
    break;
  }
  default: heff_nomatch(v_x_2418);
  }
  V v_t_2425;
  heff_clo_take(self, 1);
  if (heff_strEq_c(heff_get_n(v_t_2421, 0, 3), heff_get_n(v_g_242, 0, 3))) {
    V v_t_2424;
    switch (heff_tag_of(v_x_2418)) {
    case TAG_MkPair: {
      V v_x_2422 = heff_field(v_x_2418, 0);
      heff_take_n(v_x_2418, 1ULL, 2);
      v_t_2424 = v_x_2422;
      break;
    }
    default: heff_nomatch(v_x_2418);
    }
    v_t_2425 = heff_get_n(v_t_2424, 2, 3);
  } else {
    heff_drop(v_x_2418);
    v_t_2425 = NTAG(TAG_Nil);
  }
  return (g_prelude_2e_2b_2b(v_t_2425, v_acc_2417));
}
V g_heff_2ebuild_2ebackcache_2eaddGroup_lam1(V self, V *args) {
  V v_x2_2427 = args[0];
  V v_old_2426 = heff_env(self)[0];
  switch (heff_tag_of(v_x2_2427)) {
  case TAG_MkPair: {
    V v_k_2428 = heff_field(v_x2_2427, 0);
    V v_x22_2429 = heff_field(v_x2_2427, 1);
    heff_take_n(v_x2_2427, 3ULL, 2);
    switch (heff_tag_of(v_x22_2429)) {
    case TAG_Nothing: {
      heff_clo_take(self, 1);
      HeffT2 v_t_2430 = ({ V a_0 = v_k_2428; V a_1 = v_old_2426; HeffT2 r_ = (g_list_2efind_24s1156299507x501436576_24cpr(a_0, a_1)); heff_drop(v_k_2428); heff_drop(v_old_2426); r_; });
      {
        V v_field_2432 = v_t_2430.f[1];
        int64_t v_tag_2431 = ((int64_t)v_t_2430.f[0]);
        if ((v_tag_2431 == ((int64_t)0ULL))) {
          V v_p_2433 = v_field_2432;
          V v_t_2436;
          switch (heff_tag_of(v_p_2433)) {
          case TAG_MkPair: {
            V v_y_2435 = heff_field(v_p_2433, 1);
            heff_take_n(v_p_2433, 2ULL, 2);
            v_t_2436 = v_y_2435;
            break;
          }
          default: heff_nomatch(v_p_2433);
          }
          return heff_tag_n(TAG_Just, 1, (V[]){v_t_2436});
        } else {
          heff_drop(v_field_2432);
          return NTAG(TAG_Nothing);
        }
      }
    }
    case TAG_Just: {
      V v_u_2437 = heff_field(v_x22_2429, 0);
      V v_ru_24x22_2429_24Just = heff_take_reuse_n(v_x22_2429, 1ULL, 1);
      heff_drop(self);
      heff_drop(v_k_2428);
      V v_t_2438 = (g_heff_2ebuild_2ebackcache_2eunitText(v_u_2437));
      return heff_tag_at_n(v_ru_24x22_2429_24Just, TAG_Just, 1, (V[]){v_t_2438});
    }
    default: return heff_nomatch(v_x22_2429);
    }
  }
  default: return heff_nomatch(v_x2_2427);
  }
}
HEFF_LIT(g_heff_2ebuild_2ebackcache_2ebackText_str0, 5, "3:end");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2ebackText_str1, 1, ":");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2ebackText_str2, 1, ":");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2ebackText_str3, 1, " ");
HEFF_LIT(g_heff_2ebuild_2ebackcache_2ebackText_str4, 1, " ");
Clo g_heff_2ebuild_2ebackcache_2ebackText_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebackcache_2ebackText_entry, 2, 0};

V g_heff_2ebuild_2ebackcache_2ebackText(V v_id_240, V v_es_241) {
top: ;
  V v_groups_242 = heff_take_field(v_es_241, 0);
  V v_copies_243 = heff_take_field(v_es_241, 1);
  V v_emits_244 = heff_take_field(v_es_241, 2);
  V v_jss_245 = heff_get_n(v_es_241, 3, 4);
  V v_t_246 = (g_std_2eordmap_2esize(v_groups_242));
  V v_t_247 = heff_intShow(v_t_246);
  V v_t_248 = ({ V a_0 = v_groups_242; V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2eordmap_2etoList_2etoListOnto_240(a_0, a_1)); heff_drop(v_groups_242); r_; });
  V v_t_249 = (g_list_2emap_24s1173914895x100384474(v_t_248));
  V v_t_2410 = (g_std_2eordmap_2esize(v_copies_243));
  V v_t_2411 = ({ V a_0 = v_copies_243; V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2eordmap_2etoList_2etoListOnto_240(a_0, a_1)); heff_drop(v_copies_243); r_; });
  V v_t_2412 = (g_list_2emap_24s1173914895x100384474(v_t_2411));
  V v_t_2413 = (g_std_2eordmap_2esize(v_emits_244));
  V v_t_2414 = ({ V a_0 = v_emits_244; V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2eordmap_2etoList_2etoListOnto_240(a_0, a_1)); heff_drop(v_emits_244); r_; });
  V v_t_2415 = (g_list_2emap_24s1173914895x100384474(v_t_2414));
  V v_t_2416 = (g_std_2eordmap_2esize(v_jss_245));
  V v_t_2417 = ({ V a_0 = v_jss_245; V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2eordmap_2etoList_2etoListOnto_240(a_0, a_1)); heff_drop(v_jss_245); r_; });
  V v_t_2418 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ebackcache_2ebackText_str0), NTAG(TAG_Nil)});
  V v_t_2419 = (g_prelude_2e_2b_2b_24f1085359736x1262841716(v_t_2418, v_t_2417));
  V v_t_2420 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_t_2416), v_t_2419});
  V v_t_2421 = (g_prelude_2e_2b_2b(v_t_2415, v_t_2420));
  V v_t_2422 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_t_2413), v_t_2421});
  V v_t_2423 = (g_prelude_2e_2b_2b(v_t_2412, v_t_2422));
  V v_t_2424 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_t_2410), v_t_2423});
  V v_ys_2425 = (g_prelude_2e_2b_2b(v_t_249, v_t_2424));
  V v_t_2426 = heff_intShow(heff_strLength_lent(v_id_240, 0));
  V v_t_2427 = heff_strAppend(heff_strAppend(v_t_2426, ((V)&g_heff_2ebuild_2ebackcache_2ebackText_str1)), v_id_240);
  V v_t_2428 = heff_intShow(heff_strLength(heff_dup(g_heff_2ebuild_2ebackcache_2eversion_get())));
  V v_t_2429 = heff_strAppend(heff_strAppend(v_t_2428, ((V)&g_heff_2ebuild_2ebackcache_2ebackText_str2)), heff_dup(g_heff_2ebuild_2ebackcache_2eversion_get()));
  V v_t_2430 = heff_strAppend(heff_strAppend(v_t_2429, ((V)&g_heff_2ebuild_2ebackcache_2ebackText_str3)), v_t_2427);
  return ({ V a_0 = ((V)&g_heff_2ebuild_2ebackcache_2ebackText_str4); V a_1 = v_t_2430; V b_2 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_247, v_ys_2425}); V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, b_2)); heff_drop(b_2); r_; });
}
V g_heff_2ebuild_2ebackcache_2ebackText_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ebackcache_2ebackText(a[0], a[1]);
}
V g_heff_2ebuild_2ebackcache_2ebackTexts_lam0(V self, V *args);
Clo g_heff_2ebuild_2ebackcache_2ebackTexts_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebackcache_2ebackTexts_entry, 3, 0};

V g_heff_2ebuild_2ebackcache_2ebackTexts(V v_id_240, V v_fs_241, V v_gv_242) {
top: ;
  V v_groups_243 = heff_take_field(v_gv_242, 0);
  V v_copies_244 = heff_take_field(v_gv_242, 1);
  V v_emits_245 = heff_take_field(v_gv_242, 2);
  V v_jss_246 = heff_get_n(v_gv_242, 3, 4);
  V v_t_247 = ({ V a_0 = heff_dup(v_fs_241); V a_1 = heff_dup(g_std_2eordmap_2eempty_get()); V a_2 = v_groups_243; V r_ = (g_list_2efoldl_24s1494296198x1800016121(a_0, a_1, a_2)); heff_drop(v_groups_243); r_; });
  V v_t_248 = ({ V a_0 = heff_dup(v_fs_241); V a_1 = v_t_247; V a_2 = v_copies_244; V r_ = (g_list_2efoldl_24s1103469845x1474178821(a_0, a_1, a_2)); heff_drop(v_copies_244); r_; });
  V v_t_249 = ({ V a_0 = heff_dup(v_fs_241); V a_1 = v_t_248; V a_2 = v_emits_245; V r_ = (g_list_2efoldl_24s788343806x1528994845(a_0, a_1, a_2)); heff_drop(v_emits_245); r_; });
  V v_m_2410 = ({ V a_0 = v_fs_241; V a_1 = v_t_249; V a_2 = v_jss_246; V r_ = (g_list_2efoldl_24s425699049x1164890302(a_0, a_1, a_2)); heff_drop(v_jss_246); r_; });
  V v_t_2411 = ({ V a_0 = v_m_2410; V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2eordmap_2etoList_2etoListOnto_240(a_0, a_1)); heff_drop(v_m_2410); r_; });
  return (g_list_2emap(heff_clo_n(g_heff_2ebuild_2ebackcache_2ebackTexts_lam0, 1, 1, (V[]){v_id_240}), v_t_2411));
}
V g_heff_2ebuild_2ebackcache_2ebackTexts_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ebackcache_2ebackTexts(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2ebackcache_2ebackTexts_lam0(V self, V *args) {
  V v_p_2412 = args[0];
  V v_id_240 = heff_env(self)[0];
  V v_t_2415;
  switch (heff_tag_of(v_p_2412)) {
  case TAG_MkPair: {
    V v_x_2413 = heff_dup(heff_field(v_p_2412, 0));
    v_t_2415 = v_x_2413;
    break;
  }
  default: heff_nomatch(v_p_2412);
  }
  V v_t_2418;
  switch (heff_tag_of(v_p_2412)) {
  case TAG_MkPair: {
    V v_y_2417 = heff_field(v_p_2412, 1);
    heff_take_n(v_p_2412, 2ULL, 2);
    v_t_2418 = v_y_2417;
    break;
  }
  default: heff_nomatch(v_p_2412);
  }
  heff_clo_take(self, 1);
  V v_t_2419 = (g_heff_2ebuild_2ebackcache_2ebackText(v_id_240, v_t_2418));
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2415, v_t_2419});
}