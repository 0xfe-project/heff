// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_CFalse 2759
#define TAG_CIf 14188
#define TAG_CNot 51573
#define TAG_CRel 55099
#define TAG_CTest 64009
#define TAG_CTrue 11023
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBool 8245
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_ESet 50124
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EValues 34965
#define TAG_EVar 52881
#define TAG_Enter_24heff_2ecompile_2eir_2efoldParts_24s1678201098x2107332371 26687
#define TAG_Enter_24heff_2ecompile_2eworlds_2eworldsIn 19030
#define TAG_FloatEq 13032
#define TAG_FloatLe 13237
#define TAG_FloatLt 13252
#define TAG_IntEq 36665
#define TAG_IntLe 36870
#define TAG_IntLt 36885
#define TAG_MkArm 55352
#define TAG_OfFixed 17267
#define TAG_OpAdd 19601
#define TAG_OpAnd 19910
#define TAG_OpDiv 22656
#define TAG_OpEq 47278
#define TAG_OpFloor 41205
#define TAG_OpFromFloat 35229
#define TAG_OpFromInt 12062
#define TAG_OpLe 47483
#define TAG_OpLt 47498
#define TAG_OpMul 31667
#define TAG_OpOr 47589
#define TAG_OpRem 35977
#define TAG_OpShl 37030
#define TAG_OpShow 33901
#define TAG_OpShr 37036
#define TAG_OpSqrt 42640
#define TAG_OpSub 37423
#define TAG_OpToFloat 56600
#define TAG_OpToInt 49177
#define TAG_OpXor 42058
#define TAG_RuneEq 61407
#define TAG_RuneLe 61612
#define TAG_RuneLt 61627
#define TAG_StrEq 12955
#define TAG_StrLt 13175
#define TAG_WordEq 48587
#define TAG_WordLe 48792
#define TAG_WordLt 48807
V g_heff_2ecompile_2eir_2eallArms_24s1990391376x1174486746(V);
V g_heff_2ecompile_2eir_2eallArms_24s1990391376x1174486746_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eallArms_24s1990391376x1174486746_clo;
V g_heff_2ecompile_2eir_2econdMap(V, V);
V g_heff_2ecompile_2eir_2econdMap_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2econdMap_clo;
V g_heff_2ecompile_2eir_2econdMap_24dps(V, V, V, V);
V g_heff_2ecompile_2eir_2econdMap_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2econdMap_24dps_clo;
V g_heff_2ecompile_2eir_2econdOnto(V, V);
V g_heff_2ecompile_2eir_2econdOnto_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2econdOnto_clo;
V g_heff_2ecompile_2eir_2econdTraverse_24s1837299276x21224549(V);
V g_heff_2ecompile_2eir_2econdTraverse_24s1837299276x21224549_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2econdTraverse_24s1837299276x21224549_clo;
V g_heff_2ecompile_2eir_2econdTraverse_24s1863996995x1569673226(V, V);
V g_heff_2ecompile_2eir_2econdTraverse_24s1863996995x1569673226_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2econdTraverse_24s1863996995x1569673226_clo;
V g_heff_2ecompile_2eir_2efoldArms_24s1362069606x2094249349(V, V);
V g_heff_2ecompile_2eir_2efoldArms_24s1362069606x2094249349_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2efoldArms_24s1362069606x2094249349_clo;
V g_heff_2ecompile_2eir_2efoldFields_24s1664558841x62844947(V, V);
V g_heff_2ecompile_2eir_2efoldFields_24s1664558841x62844947_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2efoldFields_24s1664558841x62844947_clo;
V g_heff_2ecompile_2eir_2efoldList_24s665204368x62248699(V, V);
V g_heff_2ecompile_2eir_2efoldList_24s665204368x62248699_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2efoldList_24s665204368x62248699_clo;
V g_heff_2ecompile_2eir_2efoldParts_24s1678201098x2107332371_24cycle(V, V, V, V, V);
V g_heff_2ecompile_2eir_2efoldParts_24s1678201098x2107332371_24cycle_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2efoldParts_24s1678201098x2107332371_24cycle_clo;
V g_heff_2ecompile_2eir_2ehasDefault(V);
V g_heff_2ecompile_2eir_2ehasDefault_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2ehasDefault_clo;
V g_heff_2ecompile_2eir_2eisRel(V);
V g_heff_2ecompile_2eir_2eisRel_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eisRel_clo;
HeffT2 g_heff_2ecompile_2eir_2etraversePartsM_24s522885877x67011946_24cpr(V, V, V);
V g_heff_2ecompile_2eir_2ewaysM_24s1047738232x1749794841(V, V, V);
V g_heff_2ecompile_2eir_2ewaysM_24s1047738232x1749794841_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2ewaysM_24s1047738232x1749794841_clo;
V g_heff_2ecompile_2eir_2ewaysM_24s720639170x844131841(V, V, V);
V g_heff_2ecompile_2eir_2ewaysM_24s720639170x844131841_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2ewaysM_24s720639170x844131841_clo;
V g_heff_2ecompile_2eir_2ewaysMap_24s566160109x359740854(V, V);
V g_heff_2ecompile_2eir_2ewaysMap_24s566160109x359740854_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2ewaysMap_24s566160109x359740854_clo;
V g_heff_2ecompile_2eir_2ewaysMap_24s566160109x359740854_24dps(V, V, V);
V g_heff_2ecompile_2eir_2ewaysMap_24s566160109x359740854_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2ewaysMap_24s566160109x359740854_24dps_clo;
V g_heff_2ecompile_2emonadic_2enormWith_24s1213536996x2095892884(V);
V g_heff_2ecompile_2emonadic_2enormWith_24s1213536996x2095892884_entry(V self, V *a);
extern Clo g_heff_2ecompile_2emonadic_2enormWith_24s1213536996x2095892884_clo;
V g_heff_2ecompile_2esimplify_2estripLams(V, V);
V g_heff_2ecompile_2esimplify_2estripLams_entry(V self, V *a);
extern Clo g_heff_2ecompile_2esimplify_2estripLams_clo;
V g_heff_2ecompile_2etrmc_2estartAcc(V, V, V);
V g_heff_2ecompile_2etrmc_2estartAcc_entry(V self, V *a);
extern Clo g_heff_2ecompile_2etrmc_2estartAcc_clo;
V g_heff_2ecompile_2etrmc_2estartCell(V, V, V);
V g_heff_2ecompile_2etrmc_2estartCell_entry(V self, V *a);
extern Clo g_heff_2ecompile_2etrmc_2estartCell_clo;
V g_heff_2ecompile_2eworlds_2eofGlobals(V);
V g_heff_2ecompile_2eworlds_2eofGlobals_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eworlds_2eofGlobals_clo;
HeffT3 g_heff_2ecompile_2eworlds_2esidesOf_24cpr(V);
V g_heff_2ecompile_2eworlds_2eworldsIn(V, V);
V g_heff_2ecompile_2eworlds_2eworldsIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eworlds_2eworldsIn_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_prelude_2etraverse_24s1587080482x1917521257(V, V);
V g_prelude_2etraverse_24s1587080482x1917521257_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s1587080482x1917521257_clo;
V g_prelude_2etraverse_24s988656740x982054589(V, V);
V g_prelude_2etraverse_24s988656740x982054589_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s988656740x982054589_clo;
Clo g_heff_2ecompile_2eir_2econdMap_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2econdMap_24dps_entry, 4, 0};

V g_heff_2ecompile_2eir_2econdMap_24dps(V v_f_240, V v_x2_241, V v_d_242, V v_i_243) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_CTrue: {
    heff_drop(v_f_240);
    return heff_setField(heff_dup(v_d_242), v_i_243, NTAG(TAG_CTrue));
  }
  case TAG_CFalse: {
    heff_drop(v_f_240);
    return heff_setField(heff_dup(v_d_242), v_i_243, NTAG(TAG_CFalse));
  }
  case TAG_CRel: {
    V v_p_244 = heff_field(v_x2_241, 0);
    V v_x_245 = heff_field(v_x2_241, 1);
    V v_y_246 = heff_field(v_x2_241, 2);
    heff_take_n(v_x2_241, 7ULL, 3);
    V v_t_247 = heff_tr(heff_call(heff_dup(v_f_240), 1, (V[]){v_x_245}));
    V v_t_248 = heff_tr(heff_call(v_f_240, 1, (V[]){v_y_246}));
    return heff_setField(heff_dup(v_d_242), v_i_243, heff_tag_n(TAG_CRel, 3, (V[]){v_p_244, v_t_247, v_t_248}));
  }
  case TAG_CTest: {
    V v_x_249 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    V v_t_2410 = heff_tr(heff_call(v_f_240, 1, (V[]){v_x_249}));
    return heff_setField(heff_dup(v_d_242), v_i_243, heff_tag_n(TAG_CTest, 1, (V[]){v_t_2410}));
  }
  case TAG_CNot: {
    V v_c_2411 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24CNot = heff_take_reuse_n(v_x2_241, 1ULL, 1);
    V v_cell_2412 = heff_tag_at_n(v_ru_24x2_241_24CNot, TAG_CNot, 1, (V[]){heff_hole()});
    V v_u_2413 = heff_setFieldPeek(v_d_242, v_i_243, v_cell_2412);
    V t_0 = v_f_240;
    V t_1 = v_c_2411;
    V t_2 = v_u_2413;
    V t_3 = MK_INT(0LL);
    v_f_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    v_i_243 = t_3;
    goto top;
  }
  case TAG_CIf: {
    V v_a_2414 = heff_field(v_x2_241, 0);
    V v_b_2415 = heff_field(v_x2_241, 1);
    V v_c_2416 = heff_field(v_x2_241, 2);
    V v_ru_24x2_241_24CIf = heff_take_reuse_n(v_x2_241, 7ULL, 3);
    V v_t_2417 = (g_heff_2ecompile_2eir_2econdMap(heff_dup(v_f_240), v_a_2414));
    V v_t_2418 = (g_heff_2ecompile_2eir_2econdMap(heff_dup(v_f_240), v_b_2415));
    V v_cell_2419 = heff_tag_at_n(v_ru_24x2_241_24CIf, TAG_CIf, 3, (V[]){v_t_2417, v_t_2418, heff_hole()});
    V v_u_2420 = heff_setFieldPeek(v_d_242, v_i_243, v_cell_2419);
    V t_0 = v_f_240;
    V t_1 = v_c_2416;
    V t_2 = v_u_2420;
    V t_3 = MK_INT(2LL);
    v_f_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    v_i_243 = t_3;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eir_2econdMap_24dps_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2eir_2econdMap_24dps(a[0], a[1], a2, a[3]); heff_drop(a2); return r;
}
Clo g_heff_2ecompile_2eir_2eallArms_24s1990391376x1174486746_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2eallArms_24s1990391376x1174486746_entry, 1, 0};

V g_heff_2ecompile_2eir_2eallArms_24s1990391376x1174486746(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_x21_241 = heff_field(v_x2_240, 0);
    V v_arms_242 = heff_field(v_x2_240, 1);
    switch (heff_tag_of(v_x21_241)) {
    case TAG_MkArm: {
      V v_b_245 = heff_field(v_x21_241, 2);
      V v_a_246 = (g_heff_2ecompile_2eir_2ehasDefault(heff_dup(v_b_245)));
      if (!(heff_dup(v_a_246) == NTAG(TAG_True))) {
        heff_drop(v_a_246);
        V t_0 = v_arms_242;
        v_x2_240 = t_0;
        goto top;
      } else {
        heff_drop(v_a_246);
        return NTAG(TAG_False);
      }
    }
    default: return heff_nomatch(v_x21_241);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2ecompile_2eir_2eallArms_24s1990391376x1174486746_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eir_2eallArms_24s1990391376x1174486746(a0); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2eir_2eisRel_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2eisRel_entry, 1, 0};

V g_heff_2ecompile_2eir_2eisRel(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_IntEq: {
    return NTAG(TAG_True);
  }
  case TAG_IntLt: {
    return NTAG(TAG_True);
  }
  case TAG_IntLe: {
    return NTAG(TAG_True);
  }
  case TAG_FloatEq: {
    return NTAG(TAG_True);
  }
  case TAG_FloatLt: {
    return NTAG(TAG_True);
  }
  case TAG_FloatLe: {
    return NTAG(TAG_True);
  }
  case TAG_StrEq: {
    return NTAG(TAG_True);
  }
  case TAG_StrLt: {
    return NTAG(TAG_True);
  }
  case TAG_RuneEq: {
    return NTAG(TAG_True);
  }
  case TAG_RuneLt: {
    return NTAG(TAG_True);
  }
  case TAG_RuneLe: {
    return NTAG(TAG_True);
  }
  case TAG_OfFixed: {
    V v_op_242 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_op_242)) {
    case TAG_OpAdd: {
      return NTAG(TAG_False);
    }
    case TAG_OpSub: {
      return NTAG(TAG_False);
    }
    case TAG_OpMul: {
      return NTAG(TAG_False);
    }
    case TAG_OpDiv: {
      return NTAG(TAG_False);
    }
    case TAG_OpRem: {
      return NTAG(TAG_False);
    }
    case TAG_OpEq: {
      return NTAG(TAG_True);
    }
    case TAG_OpLt: {
      return NTAG(TAG_True);
    }
    case TAG_OpLe: {
      return NTAG(TAG_True);
    }
    case TAG_OpAnd: {
      return NTAG(TAG_False);
    }
    case TAG_OpOr: {
      return NTAG(TAG_False);
    }
    case TAG_OpXor: {
      return NTAG(TAG_False);
    }
    case TAG_OpShl: {
      return NTAG(TAG_False);
    }
    case TAG_OpShr: {
      return NTAG(TAG_False);
    }
    case TAG_OpShow: {
      return NTAG(TAG_False);
    }
    case TAG_OpFromInt: {
      return NTAG(TAG_False);
    }
    case TAG_OpToInt: {
      return NTAG(TAG_False);
    }
    case TAG_OpSqrt: {
      return NTAG(TAG_False);
    }
    case TAG_OpFromFloat: {
      return NTAG(TAG_False);
    }
    case TAG_OpToFloat: {
      return NTAG(TAG_False);
    }
    case TAG_OpFloor: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_op_242);
    }
  }
  case TAG_WordEq: {
    return NTAG(TAG_True);
  }
  case TAG_WordLt: {
    return NTAG(TAG_True);
  }
  case TAG_WordLe: {
    return NTAG(TAG_True);
  }
  default: {
    return NTAG(TAG_False);
  }
  }
}
V g_heff_2ecompile_2eir_2eisRel_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eir_2eisRel(a0); heff_drop(a0); return r;
}
V g_heff_2ecompile_2eir_2ewaysMap_24s566160109x359740854_24dps_lam0(V self, V *args);
Clo g_heff_2ecompile_2eir_2ewaysMap_24s566160109x359740854_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2ewaysMap_24s566160109x359740854_24dps_entry, 3, 0};

V g_heff_2ecompile_2eir_2ewaysMap_24s566160109x359740854_24dps(V v_lit_240, V v_e_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_EVar: {
    V v_t_244 = (g_heff_2ecompile_2esimplify_2estripLams(v_lit_240, v_e_241));
    return heff_setField(heff_dup(v_d_242), MK_INT(2LL), v_t_244);
  }
  case TAG_EGlobal: {
    V v_t_246 = (g_heff_2ecompile_2esimplify_2estripLams(v_lit_240, v_e_241));
    return heff_setField(heff_dup(v_d_242), MK_INT(2LL), v_t_246);
  }
  case TAG_ELam: {
    V v_t_249 = (g_heff_2ecompile_2esimplify_2estripLams(v_lit_240, v_e_241));
    return heff_setField(heff_dup(v_d_242), MK_INT(2LL), v_t_249);
  }
  case TAG_EApp: {
    V v_t_2412 = (g_heff_2ecompile_2esimplify_2estripLams(v_lit_240, v_e_241));
    return heff_setField(heff_dup(v_d_242), MK_INT(2LL), v_t_2412);
  }
  case TAG_ELet: {
    V v_x_2413 = heff_field(v_e_241, 0);
    V v_a_2414 = heff_field(v_e_241, 1);
    V v_b_2415 = heff_field(v_e_241, 2);
    V v_ru_24e_241_24ELet = heff_take_reuse_n(v_e_241, 7ULL, 3);
    V v_cell_2416 = heff_tag_re_n(v_ru_24e_241_24ELet, TAG_ELet, 3, 3ULL, (V[]){v_x_2413, v_a_2414, heff_hole()});
    V v_u_2417 = heff_setFieldPeek(v_d_242, MK_INT(2LL), v_cell_2416);
    V t_0 = v_lit_240;
    V t_1 = v_b_2415;
    V t_2 = v_u_2417;
    v_lit_240 = t_0;
    v_e_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  case TAG_ERecord: {
    V v_t_2420 = (g_heff_2ecompile_2esimplify_2estripLams(v_lit_240, v_e_241));
    return heff_setField(heff_dup(v_d_242), MK_INT(2LL), v_t_2420);
  }
  case TAG_EProj: {
    V v_t_2425 = (g_heff_2ecompile_2esimplify_2estripLams(v_lit_240, v_e_241));
    return heff_setField(heff_dup(v_d_242), MK_INT(2LL), v_t_2425);
  }
  case TAG_ETag: {
    V v_t_2429 = (g_heff_2ecompile_2esimplify_2estripLams(v_lit_240, v_e_241));
    return heff_setField(heff_dup(v_d_242), MK_INT(2LL), v_t_2429);
  }
  case TAG_EMatch: {
    V v_s_2430 = heff_field(v_e_241, 0);
    V v_arms_2431 = heff_field(v_e_241, 1);
    V v_ru_24e_241_24EMatch = heff_take_reuse_n(v_e_241, 3ULL, 2);
    V v_t_2437 = (g_list_2emap_24tok2(v_ru_24e_241_24EMatch, heff_clo_n(g_heff_2ecompile_2eir_2ewaysMap_24s566160109x359740854_24dps_lam0, 1, 1, (V[]){v_lit_240}), v_arms_2431));
    return heff_setField(heff_dup(v_d_242), MK_INT(2LL), heff_tag_n(TAG_EMatch, 2, (V[]){v_s_2430, v_t_2437}));
  }
  case TAG_EPrim: {
    V v_t_2439 = (g_heff_2ecompile_2esimplify_2estripLams(v_lit_240, v_e_241));
    return heff_setField(heff_dup(v_d_242), MK_INT(2LL), v_t_2439);
  }
  case TAG_EPrimCall: {
    V v_t_2442 = (g_heff_2ecompile_2esimplify_2estripLams(v_lit_240, v_e_241));
    return heff_setField(heff_dup(v_d_242), MK_INT(2LL), v_t_2442);
  }
  case TAG_ECall: {
    V v_t_2445 = (g_heff_2ecompile_2esimplify_2estripLams(v_lit_240, v_e_241));
    return heff_setField(heff_dup(v_d_242), MK_INT(2LL), v_t_2445);
  }
  case TAG_EInt: {
    V v_t_2447 = (g_heff_2ecompile_2esimplify_2estripLams(v_lit_240, v_e_241));
    return heff_setField(heff_dup(v_d_242), MK_INT(2LL), v_t_2447);
  }
  case TAG_EFloat: {
    V v_t_2449 = (g_heff_2ecompile_2esimplify_2estripLams(v_lit_240, v_e_241));
    return heff_setField(heff_dup(v_d_242), MK_INT(2LL), v_t_2449);
  }
  case TAG_EStr: {
    V v_t_2451 = (g_heff_2ecompile_2esimplify_2estripLams(v_lit_240, v_e_241));
    return heff_setField(heff_dup(v_d_242), MK_INT(2LL), v_t_2451);
  }
  case TAG_EBytes: {
    V v_t_2453 = (g_heff_2ecompile_2esimplify_2estripLams(v_lit_240, v_e_241));
    return heff_setField(heff_dup(v_d_242), MK_INT(2LL), v_t_2453);
  }
  case TAG_EFixed: {
    V v_t_2456 = (g_heff_2ecompile_2esimplify_2estripLams(v_lit_240, v_e_241));
    return heff_setField(heff_dup(v_d_242), MK_INT(2LL), v_t_2456);
  }
  case TAG_EFloat32: {
    V v_t_2458 = (g_heff_2ecompile_2esimplify_2estripLams(v_lit_240, v_e_241));
    return heff_setField(heff_dup(v_d_242), MK_INT(2LL), v_t_2458);
  }
  case TAG_EAbandon: {
    V v_t_2459 = (g_heff_2ecompile_2esimplify_2estripLams(v_lit_240, v_e_241));
    return heff_setField(heff_dup(v_d_242), MK_INT(2LL), v_t_2459);
  }
  case TAG_EBool: {
    V v_t_2461 = (g_heff_2ecompile_2esimplify_2estripLams(v_lit_240, v_e_241));
    return heff_setField(heff_dup(v_d_242), MK_INT(2LL), v_t_2461);
  }
  case TAG_ESet: {
    V v_xs_2462 = heff_field(v_e_241, 0);
    V v_a_2463 = heff_field(v_e_241, 1);
    V v_b_2464 = heff_field(v_e_241, 2);
    V v_ru_24e_241_24ESet = heff_take_reuse_n(v_e_241, 7ULL, 3);
    V v_cell_2465 = heff_tag_re_n(v_ru_24e_241_24ESet, TAG_ESet, 3, 3ULL, (V[]){v_xs_2462, v_a_2463, heff_hole()});
    V v_u_2466 = heff_setFieldPeek(v_d_242, MK_INT(2LL), v_cell_2465);
    V t_0 = v_lit_240;
    V t_1 = v_b_2464;
    V t_2 = v_u_2466;
    v_lit_240 = t_0;
    v_e_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  case TAG_EValues: {
    V v_t_2468 = (g_heff_2ecompile_2esimplify_2estripLams(v_lit_240, v_e_241));
    return heff_setField(heff_dup(v_d_242), MK_INT(2LL), v_t_2468);
  }
  case TAG_EFix: {
    V v_t_2471 = (g_heff_2ecompile_2esimplify_2estripLams(v_lit_240, v_e_241));
    return heff_setField(heff_dup(v_d_242), MK_INT(2LL), v_t_2471);
  }
  default: return heff_nomatch(v_e_241);
  }
}
V g_heff_2ecompile_2eir_2ewaysMap_24s566160109x359740854_24dps_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ecompile_2eir_2ewaysMap_24s566160109x359740854_24dps(a[0], a[1], a2); heff_drop(a2); return r;
}
V g_heff_2ecompile_2eir_2ewaysMap_24s566160109x359740854_24dps_lam0(V self, V *args) {
  V v_x2_2432 = args[0];
  V v_lit_240 = heff_env(self)[0];
  switch (heff_tag_of(v_x2_2432)) {
  case TAG_MkArm: {
    V v_t_2433 = heff_field(v_x2_2432, 0);
    V v_vs_2434 = heff_field(v_x2_2432, 1);
    V v_b_2435 = heff_field(v_x2_2432, 2);
    V v_ru_24x2_2432_24MkArm = heff_take_reuse_n(v_x2_2432, 7ULL, 3);
    heff_clo_take(self, 1);
    V v_t_2436 = (g_heff_2ecompile_2eir_2ewaysMap_24s566160109x359740854(v_lit_240, v_b_2435));
    return heff_tag_re_n(v_ru_24x2_2432_24MkArm, TAG_MkArm, 3, 3ULL, (V[]){v_t_2433, v_vs_2434, v_t_2436});
  }
  default: return heff_nomatch(v_x2_2432);
  }
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s522885877x67011946_24cpr_lam1(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s522885877x67011946_24cpr_lam0(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s522885877x67011946_24cpr_lam3(V self, V *args);
V g_heff_2ecompile_2eir_2etraversePartsM_24s522885877x67011946_24cpr_lam2(V self, V *args);

HeffT2 g_heff_2ecompile_2eir_2etraversePartsM_24s522885877x67011946_24cpr(V v_f_240, V v_x2_241, V v_z_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_EVar: {
    heff_drop(v_f_240);
    return ((HeffT2){{v_x2_241, v_z_242}});
  }
  case TAG_EGlobal: {
    heff_drop(v_f_240);
    return ((HeffT2){{v_x2_241, v_z_242}});
  }
  case TAG_ELam: {
    V v_xs_245 = heff_field(v_x2_241, 0);
    V v_b_246 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24ELam = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_m_247 = heff_tr(heff_call(v_f_240, 2, (V[]){heff_dup(v_xs_245), v_b_246}));
    V v_x2_248 = heff_tr(heff_call(v_m_247, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x2_248)) {
    case TAG_MkPair: {
      V v_x_249 = heff_field(v_x2_248, 0);
      V v_acc_2410 = heff_field(v_x2_248, 1);
      heff_take_n(v_x2_248, 3ULL, 2);
      return ((HeffT2){{heff_tag_re_n(v_ru_24x2_241_24ELam, TAG_ELam, 2, 1ULL, (V[]){v_xs_245, v_x_249}), v_acc_2410}});
    }
    default: return ((HeffT2){{heff_nomatch(v_x2_248)}});
    }
  }
  case TAG_EApp: {
    V v_g_2411 = heff_field(v_x2_241, 0);
    V v_args_2412 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24EApp = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_m_2413 = heff_tr(heff_call(heff_dup(v_f_240), 2, (V[]){NTAG(TAG_Nil), v_g_2411}));
    V v_x2_2414 = heff_tr(heff_call(v_m_2413, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x2_2414)) {
    case TAG_MkPair: {
      V v_x_2415 = heff_field(v_x2_2414, 0);
      V v_acc_2416 = heff_field(v_x2_2414, 1);
      heff_take_n(v_x2_2414, 3ULL, 2);
      V v_t_2417 = heff_tr(heff_call(v_f_240, 1, (V[]){NTAG(TAG_Nil)}));
      V v_t_2418 = (g_prelude_2etraverse_24s988656740x982054589(v_t_2417, v_args_2412));
      V v_x2_2419 = heff_tr(heff_call(v_t_2418, 1, (V[]){v_acc_2416}));
      switch (heff_tag_of(v_x2_2419)) {
      case TAG_MkPair: {
        V v_x_2420 = heff_field(v_x2_2419, 0);
        V v_acc_2421 = heff_field(v_x2_2419, 1);
        heff_take_n(v_x2_2419, 3ULL, 2);
        return ((HeffT2){{heff_tag_at_n(v_ru_24x2_241_24EApp, TAG_EApp, 2, (V[]){v_x_2415, v_x_2420}), v_acc_2421}});
      }
      default: return ((HeffT2){{heff_nomatch(v_x2_2419)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x2_2414)}});
    }
  }
  case TAG_ELet: {
    V v_x_2422 = heff_field(v_x2_241, 0);
    V v_a_2423 = heff_field(v_x2_241, 1);
    V v_b_2424 = heff_field(v_x2_241, 2);
    V v_ru_24x2_241_24ELet = heff_take_reuse_n(v_x2_241, 7ULL, 3);
    V v_m_2425 = heff_tr(heff_call(heff_dup(v_f_240), 2, (V[]){NTAG(TAG_Nil), v_a_2423}));
    V v_x2_2426 = heff_tr(heff_call(v_m_2425, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x2_2426)) {
    case TAG_MkPair: {
      V v_x_2427 = heff_field(v_x2_2426, 0);
      V v_acc_2428 = heff_field(v_x2_2426, 1);
      V v_ru_24x2_2426_24MkPair = heff_take_reuse_n(v_x2_2426, 3ULL, 2);
      V v_t_2429 = heff_tag_at_n(v_ru_24x2_2426_24MkPair, TAG_Cons, 2, (V[]){heff_dup(v_x_2422), NTAG(TAG_Nil)});
      V v_m_2430 = heff_tr(heff_call(v_f_240, 2, (V[]){v_t_2429, v_b_2424}));
      V v_x2_2431 = heff_tr(heff_call(v_m_2430, 1, (V[]){v_acc_2428}));
      switch (heff_tag_of(v_x2_2431)) {
      case TAG_MkPair: {
        V v_x_2432 = heff_field(v_x2_2431, 0);
        V v_acc_2433 = heff_field(v_x2_2431, 1);
        heff_take_n(v_x2_2431, 3ULL, 2);
        return ((HeffT2){{heff_tag_re_n(v_ru_24x2_241_24ELet, TAG_ELet, 3, 1ULL, (V[]){v_x_2422, v_x_2427, v_x_2432}), v_acc_2433}});
      }
      default: return ((HeffT2){{heff_nomatch(v_x2_2431)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x2_2426)}});
    }
  }
  case TAG_ERecord: {
    V v_fs_2434 = heff_field(v_x2_241, 0);
    V v_ts_2435 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24ERecord = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_m_2444 = (g_prelude_2etraverse_24s988656740x982054589(heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s522885877x67011946_24cpr_lam0, 1, 1, (V[]){v_f_240}), v_fs_2434));
    V v_x2_2445 = heff_tr(heff_call(v_m_2444, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x2_2445)) {
    case TAG_MkPair: {
      V v_x_2446 = heff_field(v_x2_2445, 0);
      V v_acc_2447 = heff_field(v_x2_2445, 1);
      heff_take_n(v_x2_2445, 3ULL, 2);
      return ((HeffT2){{heff_tag_re_n(v_ru_24x2_241_24ERecord, TAG_ERecord, 2, 2ULL, (V[]){v_x_2446, v_ts_2435}), v_acc_2447}});
    }
    default: return ((HeffT2){{heff_nomatch(v_x2_2445)}});
    }
  }
  case TAG_EProj: {
    V v_e_2448 = heff_field(v_x2_241, 0);
    V v_l_2449 = heff_field(v_x2_241, 1);
    V v_sh_2450 = heff_field(v_x2_241, 2);
    V v_t_2451 = heff_field(v_x2_241, 3);
    V v_ru_24x2_241_24EProj = heff_take_reuse_n(v_x2_241, 15ULL, 4);
    V v_m_2452 = heff_tr(heff_call(v_f_240, 2, (V[]){NTAG(TAG_Nil), v_e_2448}));
    V v_x2_2453 = heff_tr(heff_call(v_m_2452, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x2_2453)) {
    case TAG_MkPair: {
      V v_x_2454 = heff_field(v_x2_2453, 0);
      V v_acc_2455 = heff_field(v_x2_2453, 1);
      heff_take_n(v_x2_2453, 3ULL, 2);
      return ((HeffT2){{heff_tag_re_n(v_ru_24x2_241_24EProj, TAG_EProj, 4, 14ULL, (V[]){v_x_2454, v_l_2449, v_sh_2450, v_t_2451}), v_acc_2455}});
    }
    default: return ((HeffT2){{heff_nomatch(v_x2_2453)}});
    }
  }
  case TAG_ETag: {
    V v_t_2456 = heff_field(v_x2_241, 0);
    V v_args_2457 = heff_field(v_x2_241, 1);
    V v_ts_2458 = heff_field(v_x2_241, 2);
    V v_ru_24x2_241_24ETag = heff_take_reuse_n(v_x2_241, 7ULL, 3);
    V v_t_2459 = heff_tr(heff_call(v_f_240, 1, (V[]){NTAG(TAG_Nil)}));
    V v_m_2460 = (g_prelude_2etraverse_24s988656740x982054589(v_t_2459, v_args_2457));
    V v_x2_2461 = heff_tr(heff_call(v_m_2460, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x2_2461)) {
    case TAG_MkPair: {
      V v_x_2462 = heff_field(v_x2_2461, 0);
      V v_acc_2463 = heff_field(v_x2_2461, 1);
      heff_take_n(v_x2_2461, 3ULL, 2);
      return ((HeffT2){{heff_tag_re_n(v_ru_24x2_241_24ETag, TAG_ETag, 3, 5ULL, (V[]){v_t_2456, v_x_2462, v_ts_2458}), v_acc_2463}});
    }
    default: return ((HeffT2){{heff_nomatch(v_x2_2461)}});
    }
  }
  case TAG_EMatch: {
    V v_s_2464 = heff_field(v_x2_241, 0);
    V v_arms_2465 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24EMatch = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_m_2466 = heff_tr(heff_call(heff_dup(v_f_240), 2, (V[]){NTAG(TAG_Nil), v_s_2464}));
    V v_x2_2467 = heff_tr(heff_call(v_m_2466, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x2_2467)) {
    case TAG_MkPair: {
      V v_x_2468 = heff_field(v_x2_2467, 0);
      V v_acc_2469 = heff_field(v_x2_2467, 1);
      heff_take_n(v_x2_2467, 3ULL, 2);
      V v_t_2479 = (g_prelude_2etraverse_24s988656740x982054589(heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s522885877x67011946_24cpr_lam2, 1, 1, (V[]){v_f_240}), v_arms_2465));
      V v_x2_2480 = heff_tr(heff_call(v_t_2479, 1, (V[]){v_acc_2469}));
      switch (heff_tag_of(v_x2_2480)) {
      case TAG_MkPair: {
        V v_x_2481 = heff_field(v_x2_2480, 0);
        V v_acc_2482 = heff_field(v_x2_2480, 1);
        heff_take_n(v_x2_2480, 3ULL, 2);
        return ((HeffT2){{heff_tag_at_n(v_ru_24x2_241_24EMatch, TAG_EMatch, 2, (V[]){v_x_2468, v_x_2481}), v_acc_2482}});
      }
      default: return ((HeffT2){{heff_nomatch(v_x2_2480)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x2_2467)}});
    }
  }
  case TAG_EPrim: {
    heff_drop(v_f_240);
    return ((HeffT2){{v_x2_241, v_z_242}});
  }
  case TAG_EPrimCall: {
    V v_p_2484 = heff_field(v_x2_241, 0);
    V v_args_2485 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24EPrimCall = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_2486 = heff_tr(heff_call(v_f_240, 1, (V[]){NTAG(TAG_Nil)}));
    V v_m_2487 = (g_prelude_2etraverse_24s988656740x982054589(v_t_2486, v_args_2485));
    V v_x2_2488 = heff_tr(heff_call(v_m_2487, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x2_2488)) {
    case TAG_MkPair: {
      V v_x_2489 = heff_field(v_x2_2488, 0);
      V v_acc_2490 = heff_field(v_x2_2488, 1);
      heff_take_n(v_x2_2488, 3ULL, 2);
      return ((HeffT2){{heff_tag_re_n(v_ru_24x2_241_24EPrimCall, TAG_EPrimCall, 2, 1ULL, (V[]){v_p_2484, v_x_2489}), v_acc_2490}});
    }
    default: return ((HeffT2){{heff_nomatch(v_x2_2488)}});
    }
  }
  case TAG_ECall: {
    V v_g_2491 = heff_field(v_x2_241, 0);
    V v_args_2492 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24ECall = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_2493 = heff_tr(heff_call(v_f_240, 1, (V[]){NTAG(TAG_Nil)}));
    V v_m_2494 = (g_prelude_2etraverse_24s988656740x982054589(v_t_2493, v_args_2492));
    V v_x2_2495 = heff_tr(heff_call(v_m_2494, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x2_2495)) {
    case TAG_MkPair: {
      V v_x_2496 = heff_field(v_x2_2495, 0);
      V v_acc_2497 = heff_field(v_x2_2495, 1);
      heff_take_n(v_x2_2495, 3ULL, 2);
      return ((HeffT2){{heff_tag_re_n(v_ru_24x2_241_24ECall, TAG_ECall, 2, 1ULL, (V[]){v_g_2491, v_x_2496}), v_acc_2497}});
    }
    default: return ((HeffT2){{heff_nomatch(v_x2_2495)}});
    }
  }
  case TAG_EInt: {
    heff_drop(v_f_240);
    return ((HeffT2){{v_x2_241, v_z_242}});
  }
  case TAG_EFloat: {
    heff_drop(v_f_240);
    return ((HeffT2){{v_x2_241, v_z_242}});
  }
  case TAG_EStr: {
    heff_drop(v_f_240);
    return ((HeffT2){{v_x2_241, v_z_242}});
  }
  case TAG_EBytes: {
    heff_drop(v_f_240);
    return ((HeffT2){{v_x2_241, v_z_242}});
  }
  case TAG_EFixed: {
    heff_drop(v_f_240);
    return ((HeffT2){{v_x2_241, v_z_242}});
  }
  case TAG_EFloat32: {
    heff_drop(v_f_240);
    return ((HeffT2){{v_x2_241, v_z_242}});
  }
  case TAG_EAbandon: {
    heff_drop(v_f_240);
    return ((HeffT2){{v_x2_241, v_z_242}});
  }
  case TAG_EBool: {
    V v_c_24105 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24EBool = heff_take_reuse_n(v_x2_241, 1ULL, 1);
    V v_t_24106 = heff_tr(heff_call(v_f_240, 1, (V[]){NTAG(TAG_Nil)}));
    V v_m_24107 = (g_heff_2ecompile_2eir_2econdTraverse_24s1863996995x1569673226(v_t_24106, v_c_24105));
    V v_x2_24108 = heff_tr(heff_call(v_m_24107, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x2_24108)) {
    case TAG_MkPair: {
      V v_x_24109 = heff_field(v_x2_24108, 0);
      V v_acc_24110 = heff_field(v_x2_24108, 1);
      heff_take_n(v_x2_24108, 3ULL, 2);
      return ((HeffT2){{heff_tag_at_n(v_ru_24x2_241_24EBool, TAG_EBool, 1, (V[]){v_x_24109}), v_acc_24110}});
    }
    default: return ((HeffT2){{heff_nomatch(v_x2_24108)}});
    }
  }
  case TAG_ESet: {
    V v_xs_24111 = heff_field(v_x2_241, 0);
    V v_a_24112 = heff_field(v_x2_241, 1);
    V v_b_24113 = heff_field(v_x2_241, 2);
    V v_ru_24x2_241_24ESet = heff_take_reuse_n(v_x2_241, 7ULL, 3);
    V v_m_24114 = heff_tr(heff_call(heff_dup(v_f_240), 2, (V[]){NTAG(TAG_Nil), v_a_24112}));
    V v_x2_24115 = heff_tr(heff_call(v_m_24114, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x2_24115)) {
    case TAG_MkPair: {
      V v_x_24116 = heff_field(v_x2_24115, 0);
      V v_acc_24117 = heff_field(v_x2_24115, 1);
      heff_take_n(v_x2_24115, 3ULL, 2);
      V v_m_24118 = heff_tr(heff_call(v_f_240, 2, (V[]){heff_dup(v_xs_24111), v_b_24113}));
      V v_x2_24119 = heff_tr(heff_call(v_m_24118, 1, (V[]){v_acc_24117}));
      switch (heff_tag_of(v_x2_24119)) {
      case TAG_MkPair: {
        V v_x_24120 = heff_field(v_x2_24119, 0);
        V v_acc_24121 = heff_field(v_x2_24119, 1);
        heff_take_n(v_x2_24119, 3ULL, 2);
        return ((HeffT2){{heff_tag_re_n(v_ru_24x2_241_24ESet, TAG_ESet, 3, 1ULL, (V[]){v_xs_24111, v_x_24116, v_x_24120}), v_acc_24121}});
      }
      default: return ((HeffT2){{heff_nomatch(v_x2_24119)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x2_24115)}});
    }
  }
  case TAG_EValues: {
    V v_es_24122 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24EValues = heff_take_reuse_n(v_x2_241, 1ULL, 1);
    V v_t_24123 = heff_tr(heff_call(v_f_240, 1, (V[]){NTAG(TAG_Nil)}));
    V v_m_24124 = (g_prelude_2etraverse_24s988656740x982054589(v_t_24123, v_es_24122));
    V v_x2_24125 = heff_tr(heff_call(v_m_24124, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x2_24125)) {
    case TAG_MkPair: {
      V v_x_24126 = heff_field(v_x2_24125, 0);
      V v_acc_24127 = heff_field(v_x2_24125, 1);
      heff_take_n(v_x2_24125, 3ULL, 2);
      return ((HeffT2){{heff_tag_at_n(v_ru_24x2_241_24EValues, TAG_EValues, 1, (V[]){v_x_24126}), v_acc_24127}});
    }
    default: return ((HeffT2){{heff_nomatch(v_x2_24125)}});
    }
  }
  case TAG_EFix: {
    V v_x_24128 = heff_field(v_x2_241, 0);
    V v_b_24129 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24EFix = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_24130 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_x_24128), NTAG(TAG_Nil)});
    V v_m_24131 = heff_tr(heff_call(v_f_240, 2, (V[]){v_t_24130, v_b_24129}));
    V v_x2_24132 = heff_tr(heff_call(v_m_24131, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x2_24132)) {
    case TAG_MkPair: {
      V v_x_24133 = heff_field(v_x2_24132, 0);
      V v_acc_24134 = heff_field(v_x2_24132, 1);
      heff_take_n(v_x2_24132, 3ULL, 2);
      return ((HeffT2){{heff_tag_re_n(v_ru_24x2_241_24EFix, TAG_EFix, 2, 1ULL, (V[]){v_x_24128, v_x_24133}), v_acc_24134}});
    }
    default: return ((HeffT2){{heff_nomatch(v_x2_24132)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s522885877x67011946_24cpr_lam1(V self, V *args) {
  V v_acc_2440 = args[0];
  V v_m_2439 = heff_env(self)[0];
  V v_l_2437 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2441 = heff_tr(heff_call(v_m_2439, 1, (V[]){v_acc_2440}));
  switch (heff_tag_of(v_x2_2441)) {
  case TAG_MkPair: {
    V v_x_2442 = heff_field(v_x2_2441, 0);
    V v_acc_2443 = heff_field(v_x2_2441, 1);
    V v_ru_24x2_2441_24MkPair = heff_take_reuse_n(v_x2_2441, 3ULL, 2);
    return heff_tag_re_n(v_ru_24x2_2441_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_l_2437, v_x_2442}), v_acc_2443});
  }
  default: return heff_nomatch(v_x2_2441);
  }
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s522885877x67011946_24cpr_lam0(V self, V *args) {
  V v_x2_2436 = args[0];
  V v_f_240 = heff_env(self)[0];
  switch (heff_tag_of(v_x2_2436)) {
  case TAG_MkPair: {
    V v_l_2437 = heff_field(v_x2_2436, 0);
    V v_e_2438 = heff_field(v_x2_2436, 1);
    heff_take_n(v_x2_2436, 3ULL, 2);
    heff_clo_take(self, 1);
    V v_m_2439 = heff_tr(heff_call(v_f_240, 2, (V[]){NTAG(TAG_Nil), v_e_2438}));
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s522885877x67011946_24cpr_lam1, 1, 2, (V[]){v_m_2439, v_l_2437});
  }
  default: return heff_nomatch(v_x2_2436);
  }
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s522885877x67011946_24cpr_lam3(V self, V *args) {
  V v_acc_2475 = args[0];
  V v_m_2474 = heff_env(self)[0];
  V v_t_2471 = heff_env(self)[1];
  V v_vs_2472 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2476 = heff_tr(heff_call(v_m_2474, 1, (V[]){v_acc_2475}));
  switch (heff_tag_of(v_x2_2476)) {
  case TAG_MkPair: {
    V v_x_2477 = heff_field(v_x2_2476, 0);
    V v_acc_2478 = heff_field(v_x2_2476, 1);
    V v_ru_24x2_2476_24MkPair = heff_take_reuse_n(v_x2_2476, 3ULL, 2);
    return heff_tag_re_n(v_ru_24x2_2476_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_n(TAG_MkArm, 3, (V[]){v_t_2471, v_vs_2472, v_x_2477}), v_acc_2478});
  }
  default: return heff_nomatch(v_x2_2476);
  }
}
V g_heff_2ecompile_2eir_2etraversePartsM_24s522885877x67011946_24cpr_lam2(V self, V *args) {
  V v_x2_2470 = args[0];
  V v_f_240 = heff_env(self)[0];
  switch (heff_tag_of(v_x2_2470)) {
  case TAG_MkArm: {
    V v_t_2471 = heff_field(v_x2_2470, 0);
    V v_vs_2472 = heff_field(v_x2_2470, 1);
    V v_b_2473 = heff_field(v_x2_2470, 2);
    heff_take_n(v_x2_2470, 7ULL, 3);
    heff_clo_take(self, 1);
    V v_m_2474 = heff_tr(heff_call(v_f_240, 2, (V[]){heff_dup(v_vs_2472), v_b_2473}));
    return heff_clo_n(g_heff_2ecompile_2eir_2etraversePartsM_24s522885877x67011946_24cpr_lam3, 1, 3, (V[]){v_m_2474, v_t_2471, v_vs_2472});
  }
  default: return heff_nomatch(v_x2_2470);
  }
}
V g_heff_2ecompile_2eir_2econdTraverse_24s1837299276x21224549_lam0(V self, V *args); static Clo g_heff_2ecompile_2eir_2econdTraverse_24s1837299276x21224549_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2econdTraverse_24s1837299276x21224549_lam0, 1, 0};
V g_heff_2ecompile_2eir_2econdTraverse_24s1837299276x21224549_lam1(V self, V *args); static Clo g_heff_2ecompile_2eir_2econdTraverse_24s1837299276x21224549_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2econdTraverse_24s1837299276x21224549_lam1, 1, 0};
V g_heff_2ecompile_2eir_2econdTraverse_24s1837299276x21224549_lam2(V self, V *args);
V g_heff_2ecompile_2eir_2econdTraverse_24s1837299276x21224549_lam3(V self, V *args);
V g_heff_2ecompile_2eir_2econdTraverse_24s1837299276x21224549_lam4(V self, V *args);
V g_heff_2ecompile_2eir_2econdTraverse_24s1837299276x21224549_lam5(V self, V *args);
Clo g_heff_2ecompile_2eir_2econdTraverse_24s1837299276x21224549_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2econdTraverse_24s1837299276x21224549_entry, 1, 0};

V g_heff_2ecompile_2eir_2econdTraverse_24s1837299276x21224549(V v_x2_27_240) {
top: ;
  switch (heff_tag_of(v_x2_27_240)) {
  case TAG_CTrue: {
    return ((V)&g_heff_2ecompile_2eir_2econdTraverse_24s1837299276x21224549_lam0_clo);
  }
  case TAG_CFalse: {
    return ((V)&g_heff_2ecompile_2eir_2econdTraverse_24s1837299276x21224549_lam1_clo);
  }
  case TAG_CRel: {
    V v_p_243 = heff_field(v_x2_27_240, 0);
    V v_x_244 = heff_field(v_x2_27_240, 1);
    V v_y_245 = heff_field(v_x2_27_240, 2);
    heff_take_n(v_x2_27_240, 7ULL, 3);
    V v_m_246 = heff_tr(g_heff_2ecompile_2emonadic_2enormWith_24s1213536996x2095892884(v_x_244));
    return heff_clo_n(g_heff_2ecompile_2eir_2econdTraverse_24s1837299276x21224549_lam2, 1, 3, (V[]){v_m_246, v_y_245, v_p_243});
  }
  case TAG_CTest: {
    V v_x_2415 = heff_field(v_x2_27_240, 0);
    heff_take_n(v_x2_27_240, 1ULL, 1);
    V v_m_2416 = heff_tr(g_heff_2ecompile_2emonadic_2enormWith_24s1213536996x2095892884(v_x_2415));
    return heff_clo_n(g_heff_2ecompile_2eir_2econdTraverse_24s1837299276x21224549_lam3, 1, 1, (V[]){v_m_2416});
  }
  case TAG_CNot: {
    V v_c_2421 = heff_field(v_x2_27_240, 0);
    heff_take_n(v_x2_27_240, 1ULL, 1);
    V v_m_2422 = (g_heff_2ecompile_2eir_2econdTraverse_24s1837299276x21224549(v_c_2421));
    return heff_clo_n(g_heff_2ecompile_2eir_2econdTraverse_24s1837299276x21224549_lam4, 1, 1, (V[]){v_m_2422});
  }
  case TAG_CIf: {
    V v_a_2427 = heff_field(v_x2_27_240, 0);
    V v_b_2428 = heff_field(v_x2_27_240, 1);
    V v_c_2429 = heff_field(v_x2_27_240, 2);
    heff_take_n(v_x2_27_240, 7ULL, 3);
    V v_m_2430 = (g_heff_2ecompile_2eir_2econdTraverse_24s1837299276x21224549(v_a_2427));
    return heff_clo_n(g_heff_2ecompile_2eir_2econdTraverse_24s1837299276x21224549_lam5, 1, 3, (V[]){v_m_2430, v_b_2428, v_c_2429});
  }
  default: return heff_nomatch(v_x2_27_240);
  }
}
V g_heff_2ecompile_2eir_2econdTraverse_24s1837299276x21224549_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eir_2econdTraverse_24s1837299276x21224549(a[0]);
}
V g_heff_2ecompile_2eir_2econdTraverse_24s1837299276x21224549_lam0(V self, V *args) {
  V v_n_241 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_CTrue), v_n_241});
}
V g_heff_2ecompile_2eir_2econdTraverse_24s1837299276x21224549_lam1(V self, V *args) {
  V v_n_242 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_CFalse), v_n_242});
}
V g_heff_2ecompile_2eir_2econdTraverse_24s1837299276x21224549_lam2(V self, V *args) {
  V v_n_247 = args[0];
  V v_m_246 = heff_env(self)[0];
  V v_y_245 = heff_env(self)[1];
  V v_p_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_248 = heff_tr(heff_call(v_m_246, 1, (V[]){v_n_247}));
  switch (heff_tag_of(v_x2_248)) {
  case TAG_MkPair: {
    V v_x_249 = heff_field(v_x2_248, 0);
    V v_n_2410 = heff_field(v_x2_248, 1);
    V v_ru_24x2_248_24MkPair = heff_take_reuse_n(v_x2_248, 3ULL, 2);
    V v_t_2411 = heff_tr(g_heff_2ecompile_2emonadic_2enormWith_24s1213536996x2095892884(v_y_245));
    V v_x2_2412 = heff_tr(heff_call(v_t_2411, 1, (V[]){v_n_2410}));
    switch (heff_tag_of(v_x2_2412)) {
    case TAG_MkPair: {
      V v_x_2413 = heff_field(v_x2_2412, 0);
      V v_n_2414 = heff_field(v_x2_2412, 1);
      heff_take_n(v_x2_2412, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_248_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_CRel, 3, (V[]){v_p_243, v_x_249, v_x_2413}), v_n_2414});
    }
    default: return heff_nomatch(v_x2_2412);
    }
  }
  default: return heff_nomatch(v_x2_248);
  }
}
V g_heff_2ecompile_2eir_2econdTraverse_24s1837299276x21224549_lam3(V self, V *args) {
  V v_n_2417 = args[0];
  V v_m_2416 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_2418 = heff_tr(heff_call(v_m_2416, 1, (V[]){v_n_2417}));
  switch (heff_tag_of(v_x2_2418)) {
  case TAG_MkPair: {
    V v_x_2419 = heff_field(v_x2_2418, 0);
    V v_n_2420 = heff_field(v_x2_2418, 1);
    V v_ru_24x2_2418_24MkPair = heff_take_reuse_n(v_x2_2418, 3ULL, 2);
    return heff_tag_re_n(v_ru_24x2_2418_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_n(TAG_CTest, 1, (V[]){v_x_2419}), v_n_2420});
  }
  default: return heff_nomatch(v_x2_2418);
  }
}
V g_heff_2ecompile_2eir_2econdTraverse_24s1837299276x21224549_lam4(V self, V *args) {
  V v_n_2423 = args[0];
  V v_m_2422 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_2424 = heff_tr(heff_call(v_m_2422, 1, (V[]){v_n_2423}));
  switch (heff_tag_of(v_x2_2424)) {
  case TAG_MkPair: {
    V v_x_2425 = heff_field(v_x2_2424, 0);
    V v_n_2426 = heff_field(v_x2_2424, 1);
    V v_ru_24x2_2424_24MkPair = heff_take_reuse_n(v_x2_2424, 3ULL, 2);
    return heff_tag_re_n(v_ru_24x2_2424_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_n(TAG_CNot, 1, (V[]){v_x_2425}), v_n_2426});
  }
  default: return heff_nomatch(v_x2_2424);
  }
}
V g_heff_2ecompile_2eir_2econdTraverse_24s1837299276x21224549_lam5(V self, V *args) {
  V v_n_2431 = args[0];
  V v_m_2430 = heff_env(self)[0];
  V v_b_2428 = heff_env(self)[1];
  V v_c_2429 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2432 = heff_tr(heff_call(v_m_2430, 1, (V[]){v_n_2431}));
  switch (heff_tag_of(v_x2_2432)) {
  case TAG_MkPair: {
    V v_x_2433 = heff_field(v_x2_2432, 0);
    V v_n_2434 = heff_field(v_x2_2432, 1);
    V v_ru_24x2_2432_24MkPair = heff_take_reuse_n(v_x2_2432, 3ULL, 2);
    V v_t_2435 = (g_heff_2ecompile_2eir_2econdTraverse_24s1837299276x21224549(v_b_2428));
    V v_x2_2436 = heff_tr(heff_call(v_t_2435, 1, (V[]){v_n_2434}));
    switch (heff_tag_of(v_x2_2436)) {
    case TAG_MkPair: {
      V v_x_2437 = heff_field(v_x2_2436, 0);
      V v_n_2438 = heff_field(v_x2_2436, 1);
      heff_take_n(v_x2_2436, 3ULL, 2);
      V v_t_2439 = (g_heff_2ecompile_2eir_2econdTraverse_24s1837299276x21224549(v_c_2429));
      V v_x2_2440 = heff_tr(heff_call(v_t_2439, 1, (V[]){v_n_2438}));
      switch (heff_tag_of(v_x2_2440)) {
      case TAG_MkPair: {
        V v_x_2441 = heff_field(v_x2_2440, 0);
        V v_n_2442 = heff_field(v_x2_2440, 1);
        heff_take_n(v_x2_2440, 3ULL, 2);
        return heff_tag_at_n(v_ru_24x2_2432_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_CIf, 3, (V[]){v_x_2433, v_x_2437, v_x_2441}), v_n_2442});
      }
      default: return heff_nomatch(v_x2_2440);
      }
    }
    default: return heff_nomatch(v_x2_2436);
    }
  }
  default: return heff_nomatch(v_x2_2432);
  }
}
V g_heff_2ecompile_2eir_2ewaysM_24s1047738232x1749794841_lam0(V self, V *args);
V g_heff_2ecompile_2eir_2ewaysM_24s1047738232x1749794841_lam2(V self, V *args);
V g_heff_2ecompile_2eir_2ewaysM_24s1047738232x1749794841_lam1(V self, V *args);
V g_heff_2ecompile_2eir_2ewaysM_24s1047738232x1749794841_lam3(V self, V *args);
V g_heff_2ecompile_2eir_2ewaysM_24s1047738232x1749794841_lam4(V self, V *args);
Clo g_heff_2ecompile_2eir_2ewaysM_24s1047738232x1749794841_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2ewaysM_24s1047738232x1749794841_entry, 3, 0};

V g_heff_2ecompile_2eir_2ewaysM_24s1047738232x1749794841(V v_lit_240, V v_lit_241, V v_e_242) {
top: ;
  switch (heff_tag_of(v_e_242)) {
  case TAG_EVar: {
    HEFF_LAST return g_heff_2ecompile_2etrmc_2estartCell(v_lit_240, v_lit_241, v_e_242);
  }
  case TAG_EGlobal: {
    HEFF_LAST return g_heff_2ecompile_2etrmc_2estartCell(v_lit_240, v_lit_241, v_e_242);
  }
  case TAG_ELam: {
    HEFF_LAST return g_heff_2ecompile_2etrmc_2estartCell(v_lit_240, v_lit_241, v_e_242);
  }
  case TAG_EApp: {
    HEFF_LAST return g_heff_2ecompile_2etrmc_2estartCell(v_lit_240, v_lit_241, v_e_242);
  }
  case TAG_ELet: {
    V v_x_249 = heff_field(v_e_242, 0);
    V v_a_2410 = heff_field(v_e_242, 1);
    V v_b_2411 = heff_field(v_e_242, 2);
    heff_take_n(v_e_242, 7ULL, 3);
    V v_m_2412 = (g_heff_2ecompile_2eir_2ewaysM_24s1047738232x1749794841(v_lit_240, v_lit_241, v_b_2411));
    return heff_clo_n(g_heff_2ecompile_2eir_2ewaysM_24s1047738232x1749794841_lam0, 1, 3, (V[]){v_m_2412, v_x_249, v_a_2410});
  }
  case TAG_ERecord: {
    HEFF_LAST return g_heff_2ecompile_2etrmc_2estartCell(v_lit_240, v_lit_241, v_e_242);
  }
  case TAG_EProj: {
    HEFF_LAST return g_heff_2ecompile_2etrmc_2estartCell(v_lit_240, v_lit_241, v_e_242);
  }
  case TAG_ETag: {
    HEFF_LAST return g_heff_2ecompile_2etrmc_2estartCell(v_lit_240, v_lit_241, v_e_242);
  }
  case TAG_EMatch: {
    V v_s_2426 = heff_field(v_e_242, 0);
    V v_arms_2427 = heff_field(v_e_242, 1);
    heff_take_n(v_e_242, 3ULL, 2);
    V v_m_2437 = (g_prelude_2etraverse_24s1587080482x1917521257(heff_clo_n(g_heff_2ecompile_2eir_2ewaysM_24s1047738232x1749794841_lam1, 1, 2, (V[]){v_lit_240, v_lit_241}), v_arms_2427));
    return heff_clo_n(g_heff_2ecompile_2eir_2ewaysM_24s1047738232x1749794841_lam3, 1, 2, (V[]){v_m_2437, v_s_2426});
  }
  case TAG_EPrim: {
    HEFF_LAST return g_heff_2ecompile_2etrmc_2estartCell(v_lit_240, v_lit_241, v_e_242);
  }
  case TAG_EPrimCall: {
    HEFF_LAST return g_heff_2ecompile_2etrmc_2estartCell(v_lit_240, v_lit_241, v_e_242);
  }
  case TAG_ECall: {
    HEFF_LAST return g_heff_2ecompile_2etrmc_2estartCell(v_lit_240, v_lit_241, v_e_242);
  }
  case TAG_EInt: {
    HEFF_LAST return g_heff_2ecompile_2etrmc_2estartCell(v_lit_240, v_lit_241, v_e_242);
  }
  case TAG_EFloat: {
    HEFF_LAST return g_heff_2ecompile_2etrmc_2estartCell(v_lit_240, v_lit_241, v_e_242);
  }
  case TAG_EStr: {
    HEFF_LAST return g_heff_2ecompile_2etrmc_2estartCell(v_lit_240, v_lit_241, v_e_242);
  }
  case TAG_EBytes: {
    HEFF_LAST return g_heff_2ecompile_2etrmc_2estartCell(v_lit_240, v_lit_241, v_e_242);
  }
  case TAG_EFixed: {
    HEFF_LAST return g_heff_2ecompile_2etrmc_2estartCell(v_lit_240, v_lit_241, v_e_242);
  }
  case TAG_EFloat32: {
    HEFF_LAST return g_heff_2ecompile_2etrmc_2estartCell(v_lit_240, v_lit_241, v_e_242);
  }
  case TAG_EAbandon: {
    HEFF_LAST return g_heff_2ecompile_2etrmc_2estartCell(v_lit_240, v_lit_241, v_e_242);
  }
  case TAG_EBool: {
    HEFF_LAST return g_heff_2ecompile_2etrmc_2estartCell(v_lit_240, v_lit_241, v_e_242);
  }
  case TAG_ESet: {
    V v_xs_2455 = heff_field(v_e_242, 0);
    V v_a_2456 = heff_field(v_e_242, 1);
    V v_b_2457 = heff_field(v_e_242, 2);
    heff_take_n(v_e_242, 7ULL, 3);
    V v_m_2458 = (g_heff_2ecompile_2eir_2ewaysM_24s1047738232x1749794841(v_lit_240, v_lit_241, v_b_2457));
    return heff_clo_n(g_heff_2ecompile_2eir_2ewaysM_24s1047738232x1749794841_lam4, 1, 3, (V[]){v_m_2458, v_xs_2455, v_a_2456});
  }
  case TAG_EValues: {
    HEFF_LAST return g_heff_2ecompile_2etrmc_2estartCell(v_lit_240, v_lit_241, v_e_242);
  }
  case TAG_EFix: {
    HEFF_LAST return g_heff_2ecompile_2etrmc_2estartCell(v_lit_240, v_lit_241, v_e_242);
  }
  default: return heff_nomatch(v_e_242);
  }
}
V g_heff_2ecompile_2eir_2ewaysM_24s1047738232x1749794841_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eir_2ewaysM_24s1047738232x1749794841(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2eir_2ewaysM_24s1047738232x1749794841_lam0(V self, V *args) {
  V v_n_2413 = args[0];
  V v_m_2412 = heff_env(self)[0];
  V v_x_249 = heff_env(self)[1];
  V v_a_2410 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2414 = heff_tr(heff_call(v_m_2412, 1, (V[]){v_n_2413}));
  switch (heff_tag_of(v_x2_2414)) {
  case TAG_MkPair: {
    V v_x_2415 = heff_field(v_x2_2414, 0);
    V v_n_2416 = heff_field(v_x2_2414, 1);
    V v_ru_24x2_2414_24MkPair = heff_take_reuse_n(v_x2_2414, 3ULL, 2);
    return heff_tag_re_n(v_ru_24x2_2414_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_249, v_a_2410, v_x_2415}), v_n_2416});
  }
  default: return heff_nomatch(v_x2_2414);
  }
}
V g_heff_2ecompile_2eir_2ewaysM_24s1047738232x1749794841_lam2(V self, V *args) {
  V v_n_2433 = args[0];
  V v_m_2432 = heff_env(self)[0];
  V v_t_2429 = heff_env(self)[1];
  V v_vs_2430 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2434 = heff_tr(heff_call(v_m_2432, 1, (V[]){v_n_2433}));
  switch (heff_tag_of(v_x2_2434)) {
  case TAG_MkPair: {
    V v_x_2435 = heff_field(v_x2_2434, 0);
    V v_n_2436 = heff_field(v_x2_2434, 1);
    V v_ru_24x2_2434_24MkPair = heff_take_reuse_n(v_x2_2434, 3ULL, 2);
    return heff_tag_re_n(v_ru_24x2_2434_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_n(TAG_MkArm, 3, (V[]){v_t_2429, v_vs_2430, v_x_2435}), v_n_2436});
  }
  default: return heff_nomatch(v_x2_2434);
  }
}
V g_heff_2ecompile_2eir_2ewaysM_24s1047738232x1749794841_lam1(V self, V *args) {
  V v_x2_2428 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  switch (heff_tag_of(v_x2_2428)) {
  case TAG_MkArm: {
    V v_t_2429 = heff_field(v_x2_2428, 0);
    V v_vs_2430 = heff_field(v_x2_2428, 1);
    V v_b_2431 = heff_field(v_x2_2428, 2);
    heff_take_n(v_x2_2428, 7ULL, 3);
    heff_clo_take(self, 2);
    V v_m_2432 = (g_heff_2ecompile_2eir_2ewaysM_24s1047738232x1749794841(v_lit_240, v_lit_241, v_b_2431));
    return heff_clo_n(g_heff_2ecompile_2eir_2ewaysM_24s1047738232x1749794841_lam2, 1, 3, (V[]){v_m_2432, v_t_2429, v_vs_2430});
  }
  default: return heff_nomatch(v_x2_2428);
  }
}
V g_heff_2ecompile_2eir_2ewaysM_24s1047738232x1749794841_lam3(V self, V *args) {
  V v_n_2438 = args[0];
  V v_m_2437 = heff_env(self)[0];
  V v_s_2426 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2439 = heff_tr(heff_call(v_m_2437, 1, (V[]){v_n_2438}));
  switch (heff_tag_of(v_x2_2439)) {
  case TAG_MkPair: {
    V v_x_2440 = heff_field(v_x2_2439, 0);
    V v_n_2441 = heff_field(v_x2_2439, 1);
    V v_ru_24x2_2439_24MkPair = heff_take_reuse_n(v_x2_2439, 3ULL, 2);
    return heff_tag_re_n(v_ru_24x2_2439_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_2426, v_x_2440}), v_n_2441});
  }
  default: return heff_nomatch(v_x2_2439);
  }
}
V g_heff_2ecompile_2eir_2ewaysM_24s1047738232x1749794841_lam4(V self, V *args) {
  V v_n_2459 = args[0];
  V v_m_2458 = heff_env(self)[0];
  V v_xs_2455 = heff_env(self)[1];
  V v_a_2456 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2460 = heff_tr(heff_call(v_m_2458, 1, (V[]){v_n_2459}));
  switch (heff_tag_of(v_x2_2460)) {
  case TAG_MkPair: {
    V v_x_2461 = heff_field(v_x2_2460, 0);
    V v_n_2462 = heff_field(v_x2_2460, 1);
    V v_ru_24x2_2460_24MkPair = heff_take_reuse_n(v_x2_2460, 3ULL, 2);
    return heff_tag_re_n(v_ru_24x2_2460_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_n(TAG_ESet, 3, (V[]){v_xs_2455, v_a_2456, v_x_2461}), v_n_2462});
  }
  default: return heff_nomatch(v_x2_2460);
  }
}
V g_heff_2ecompile_2eir_2ewaysM_24s720639170x844131841_lam0(V self, V *args);
V g_heff_2ecompile_2eir_2ewaysM_24s720639170x844131841_lam2(V self, V *args);
V g_heff_2ecompile_2eir_2ewaysM_24s720639170x844131841_lam1(V self, V *args);
V g_heff_2ecompile_2eir_2ewaysM_24s720639170x844131841_lam3(V self, V *args);
V g_heff_2ecompile_2eir_2ewaysM_24s720639170x844131841_lam4(V self, V *args);
Clo g_heff_2ecompile_2eir_2ewaysM_24s720639170x844131841_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2ewaysM_24s720639170x844131841_entry, 3, 0};

V g_heff_2ecompile_2eir_2ewaysM_24s720639170x844131841(V v_lit_240, V v_lit_241, V v_e_242) {
top: ;
  switch (heff_tag_of(v_e_242)) {
  case TAG_EVar: {
    HEFF_LAST return g_heff_2ecompile_2etrmc_2estartAcc(v_lit_240, v_lit_241, v_e_242);
  }
  case TAG_EGlobal: {
    HEFF_LAST return g_heff_2ecompile_2etrmc_2estartAcc(v_lit_240, v_lit_241, v_e_242);
  }
  case TAG_ELam: {
    HEFF_LAST return g_heff_2ecompile_2etrmc_2estartAcc(v_lit_240, v_lit_241, v_e_242);
  }
  case TAG_EApp: {
    HEFF_LAST return g_heff_2ecompile_2etrmc_2estartAcc(v_lit_240, v_lit_241, v_e_242);
  }
  case TAG_ELet: {
    V v_x_249 = heff_field(v_e_242, 0);
    V v_a_2410 = heff_field(v_e_242, 1);
    V v_b_2411 = heff_field(v_e_242, 2);
    heff_take_n(v_e_242, 7ULL, 3);
    V v_m_2412 = (g_heff_2ecompile_2eir_2ewaysM_24s720639170x844131841(v_lit_240, v_lit_241, v_b_2411));
    return heff_clo_n(g_heff_2ecompile_2eir_2ewaysM_24s720639170x844131841_lam0, 1, 3, (V[]){v_m_2412, v_x_249, v_a_2410});
  }
  case TAG_ERecord: {
    HEFF_LAST return g_heff_2ecompile_2etrmc_2estartAcc(v_lit_240, v_lit_241, v_e_242);
  }
  case TAG_EProj: {
    HEFF_LAST return g_heff_2ecompile_2etrmc_2estartAcc(v_lit_240, v_lit_241, v_e_242);
  }
  case TAG_ETag: {
    HEFF_LAST return g_heff_2ecompile_2etrmc_2estartAcc(v_lit_240, v_lit_241, v_e_242);
  }
  case TAG_EMatch: {
    V v_s_2426 = heff_field(v_e_242, 0);
    V v_arms_2427 = heff_field(v_e_242, 1);
    heff_take_n(v_e_242, 3ULL, 2);
    V v_m_2437 = (g_prelude_2etraverse_24s1587080482x1917521257(heff_clo_n(g_heff_2ecompile_2eir_2ewaysM_24s720639170x844131841_lam1, 1, 2, (V[]){v_lit_240, v_lit_241}), v_arms_2427));
    return heff_clo_n(g_heff_2ecompile_2eir_2ewaysM_24s720639170x844131841_lam3, 1, 2, (V[]){v_m_2437, v_s_2426});
  }
  case TAG_EPrim: {
    HEFF_LAST return g_heff_2ecompile_2etrmc_2estartAcc(v_lit_240, v_lit_241, v_e_242);
  }
  case TAG_EPrimCall: {
    HEFF_LAST return g_heff_2ecompile_2etrmc_2estartAcc(v_lit_240, v_lit_241, v_e_242);
  }
  case TAG_ECall: {
    HEFF_LAST return g_heff_2ecompile_2etrmc_2estartAcc(v_lit_240, v_lit_241, v_e_242);
  }
  case TAG_EInt: {
    HEFF_LAST return g_heff_2ecompile_2etrmc_2estartAcc(v_lit_240, v_lit_241, v_e_242);
  }
  case TAG_EFloat: {
    HEFF_LAST return g_heff_2ecompile_2etrmc_2estartAcc(v_lit_240, v_lit_241, v_e_242);
  }
  case TAG_EStr: {
    HEFF_LAST return g_heff_2ecompile_2etrmc_2estartAcc(v_lit_240, v_lit_241, v_e_242);
  }
  case TAG_EBytes: {
    HEFF_LAST return g_heff_2ecompile_2etrmc_2estartAcc(v_lit_240, v_lit_241, v_e_242);
  }
  case TAG_EFixed: {
    HEFF_LAST return g_heff_2ecompile_2etrmc_2estartAcc(v_lit_240, v_lit_241, v_e_242);
  }
  case TAG_EFloat32: {
    HEFF_LAST return g_heff_2ecompile_2etrmc_2estartAcc(v_lit_240, v_lit_241, v_e_242);
  }
  case TAG_EAbandon: {
    HEFF_LAST return g_heff_2ecompile_2etrmc_2estartAcc(v_lit_240, v_lit_241, v_e_242);
  }
  case TAG_EBool: {
    HEFF_LAST return g_heff_2ecompile_2etrmc_2estartAcc(v_lit_240, v_lit_241, v_e_242);
  }
  case TAG_ESet: {
    V v_xs_2455 = heff_field(v_e_242, 0);
    V v_a_2456 = heff_field(v_e_242, 1);
    V v_b_2457 = heff_field(v_e_242, 2);
    heff_take_n(v_e_242, 7ULL, 3);
    V v_m_2458 = (g_heff_2ecompile_2eir_2ewaysM_24s720639170x844131841(v_lit_240, v_lit_241, v_b_2457));
    return heff_clo_n(g_heff_2ecompile_2eir_2ewaysM_24s720639170x844131841_lam4, 1, 3, (V[]){v_m_2458, v_xs_2455, v_a_2456});
  }
  case TAG_EValues: {
    HEFF_LAST return g_heff_2ecompile_2etrmc_2estartAcc(v_lit_240, v_lit_241, v_e_242);
  }
  case TAG_EFix: {
    HEFF_LAST return g_heff_2ecompile_2etrmc_2estartAcc(v_lit_240, v_lit_241, v_e_242);
  }
  default: return heff_nomatch(v_e_242);
  }
}
V g_heff_2ecompile_2eir_2ewaysM_24s720639170x844131841_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eir_2ewaysM_24s720639170x844131841(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2eir_2ewaysM_24s720639170x844131841_lam0(V self, V *args) {
  V v_n_2413 = args[0];
  V v_m_2412 = heff_env(self)[0];
  V v_x_249 = heff_env(self)[1];
  V v_a_2410 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2414 = heff_tr(heff_call(v_m_2412, 1, (V[]){v_n_2413}));
  switch (heff_tag_of(v_x2_2414)) {
  case TAG_MkPair: {
    V v_x_2415 = heff_field(v_x2_2414, 0);
    V v_n_2416 = heff_field(v_x2_2414, 1);
    V v_ru_24x2_2414_24MkPair = heff_take_reuse_n(v_x2_2414, 3ULL, 2);
    return heff_tag_re_n(v_ru_24x2_2414_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_249, v_a_2410, v_x_2415}), v_n_2416});
  }
  default: return heff_nomatch(v_x2_2414);
  }
}
V g_heff_2ecompile_2eir_2ewaysM_24s720639170x844131841_lam2(V self, V *args) {
  V v_n_2433 = args[0];
  V v_m_2432 = heff_env(self)[0];
  V v_t_2429 = heff_env(self)[1];
  V v_vs_2430 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2434 = heff_tr(heff_call(v_m_2432, 1, (V[]){v_n_2433}));
  switch (heff_tag_of(v_x2_2434)) {
  case TAG_MkPair: {
    V v_x_2435 = heff_field(v_x2_2434, 0);
    V v_n_2436 = heff_field(v_x2_2434, 1);
    V v_ru_24x2_2434_24MkPair = heff_take_reuse_n(v_x2_2434, 3ULL, 2);
    return heff_tag_re_n(v_ru_24x2_2434_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_n(TAG_MkArm, 3, (V[]){v_t_2429, v_vs_2430, v_x_2435}), v_n_2436});
  }
  default: return heff_nomatch(v_x2_2434);
  }
}
V g_heff_2ecompile_2eir_2ewaysM_24s720639170x844131841_lam1(V self, V *args) {
  V v_x2_2428 = args[0];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  switch (heff_tag_of(v_x2_2428)) {
  case TAG_MkArm: {
    V v_t_2429 = heff_field(v_x2_2428, 0);
    V v_vs_2430 = heff_field(v_x2_2428, 1);
    V v_b_2431 = heff_field(v_x2_2428, 2);
    heff_take_n(v_x2_2428, 7ULL, 3);
    heff_clo_take(self, 2);
    V v_m_2432 = (g_heff_2ecompile_2eir_2ewaysM_24s720639170x844131841(v_lit_240, v_lit_241, v_b_2431));
    return heff_clo_n(g_heff_2ecompile_2eir_2ewaysM_24s720639170x844131841_lam2, 1, 3, (V[]){v_m_2432, v_t_2429, v_vs_2430});
  }
  default: return heff_nomatch(v_x2_2428);
  }
}
V g_heff_2ecompile_2eir_2ewaysM_24s720639170x844131841_lam3(V self, V *args) {
  V v_n_2438 = args[0];
  V v_m_2437 = heff_env(self)[0];
  V v_s_2426 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2439 = heff_tr(heff_call(v_m_2437, 1, (V[]){v_n_2438}));
  switch (heff_tag_of(v_x2_2439)) {
  case TAG_MkPair: {
    V v_x_2440 = heff_field(v_x2_2439, 0);
    V v_n_2441 = heff_field(v_x2_2439, 1);
    V v_ru_24x2_2439_24MkPair = heff_take_reuse_n(v_x2_2439, 3ULL, 2);
    return heff_tag_re_n(v_ru_24x2_2439_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_s_2426, v_x_2440}), v_n_2441});
  }
  default: return heff_nomatch(v_x2_2439);
  }
}
V g_heff_2ecompile_2eir_2ewaysM_24s720639170x844131841_lam4(V self, V *args) {
  V v_n_2459 = args[0];
  V v_m_2458 = heff_env(self)[0];
  V v_xs_2455 = heff_env(self)[1];
  V v_a_2456 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2460 = heff_tr(heff_call(v_m_2458, 1, (V[]){v_n_2459}));
  switch (heff_tag_of(v_x2_2460)) {
  case TAG_MkPair: {
    V v_x_2461 = heff_field(v_x2_2460, 0);
    V v_n_2462 = heff_field(v_x2_2460, 1);
    V v_ru_24x2_2460_24MkPair = heff_take_reuse_n(v_x2_2460, 3ULL, 2);
    return heff_tag_re_n(v_ru_24x2_2460_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_n(TAG_ESet, 3, (V[]){v_xs_2455, v_a_2456, v_x_2461}), v_n_2462});
  }
  default: return heff_nomatch(v_x2_2460);
  }
}
HEFF_LIT(g_heff_2ecompile_2eir_2efoldParts_24s1678201098x2107332371_24cycle_str0, 0, "");
HEFF_LIT(g_heff_2ecompile_2eir_2efoldParts_24s1678201098x2107332371_24cycle_str1, 0, "");
HEFF_LIT(g_heff_2ecompile_2eir_2efoldParts_24s1678201098x2107332371_24cycle_str2, 0, "");
HEFF_LIT(g_heff_2ecompile_2eir_2efoldParts_24s1678201098x2107332371_24cycle_str3, 0, "");
HEFF_LIT(g_heff_2ecompile_2eir_2efoldParts_24s1678201098x2107332371_24cycle_str4, 0, "");
HEFF_LIT(g_heff_2ecompile_2eir_2efoldParts_24s1678201098x2107332371_24cycle_str5, 0, "");
HEFF_LIT(g_heff_2ecompile_2eir_2efoldParts_24s1678201098x2107332371_24cycle_str6, 0, "");
HEFF_LIT(g_heff_2ecompile_2eir_2efoldParts_24s1678201098x2107332371_24cycle_str7, 0, "");
HEFF_LIT(g_heff_2ecompile_2eir_2efoldParts_24s1678201098x2107332371_24cycle_str8, 0, "");
HEFF_LIT(g_heff_2ecompile_2eir_2efoldParts_24s1678201098x2107332371_24cycle_str9, 0, "");
HEFF_LIT(g_heff_2ecompile_2eir_2efoldParts_24s1678201098x2107332371_24cycle_str10, 0, "");
HEFF_LIT(g_heff_2ecompile_2eir_2efoldParts_24s1678201098x2107332371_24cycle_str11, 0, "");
HEFF_LIT(g_heff_2ecompile_2eir_2efoldParts_24s1678201098x2107332371_24cycle_str12, 0, "");
HEFF_LIT(g_heff_2ecompile_2eir_2efoldParts_24s1678201098x2107332371_24cycle_str13, 0, "");
HEFF_LIT(g_heff_2ecompile_2eir_2efoldParts_24s1678201098x2107332371_24cycle_str14, 0, "");
HEFF_LIT(g_heff_2ecompile_2eir_2efoldParts_24s1678201098x2107332371_24cycle_str15, 0, "");
Clo g_heff_2ecompile_2eir_2efoldParts_24s1678201098x2107332371_24cycle_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2efoldParts_24s1678201098x2107332371_24cycle_entry, 5, 0};

V g_heff_2ecompile_2eir_2efoldParts_24s1678201098x2107332371_24cycle(V v_tag_240, V v_x2_241, V v_acc_242, V v_e_243, V v_acc_244) {
top: ;
  switch (heff_tag_of(v_tag_240)) {
  case TAG_Enter_24heff_2ecompile_2eir_2efoldParts_24s1678201098x2107332371: {
    top_TAG_Enter_24heff_2ecompile_2eir_2efoldParts_24s1678201098x2107332371: ;
    heff_drop(v_e_243);
    heff_drop(v_acc_244);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_EVar: {
      heff_take_n(v_x2_241, 0ULL, 1);
      return v_acc_242;
    }
    case TAG_EGlobal: {
      heff_take_n(v_x2_241, 0ULL, 1);
      return v_acc_242;
    }
    case TAG_ELam: {
      V v_b_248 = heff_field(v_x2_241, 1);
      heff_take_n(v_x2_241, 2ULL, 2);
      V t_0 = NTAG(TAG_Enter_24heff_2ecompile_2eworlds_2eworldsIn);
      V t_1 = ((V)&g_heff_2ecompile_2eir_2efoldParts_24s1678201098x2107332371_24cycle_str0);
      V t_2 = ((V)&g_heff_2ecompile_2eir_2efoldParts_24s1678201098x2107332371_24cycle_str1);
      V t_3 = v_b_248;
      V t_4 = v_acc_242;
      v_tag_240 = t_0;
      v_x2_241 = t_1;
      v_acc_242 = t_2;
      v_e_243 = t_3;
      v_acc_244 = t_4;
      goto top_TAG_Enter_24heff_2ecompile_2eworlds_2eworldsIn;
    }
    case TAG_EApp: {
      V v_g_249 = heff_field(v_x2_241, 0);
      V v_args_2410 = heff_field(v_x2_241, 1);
      heff_take_n(v_x2_241, 3ULL, 2);
      V v_t_2411 = (g_heff_2ecompile_2eworlds_2eworldsIn(v_g_249, v_acc_242));
      return ({ V a_0 = v_args_2410; V a_1 = v_t_2411; V r_ = (g_heff_2ecompile_2eir_2efoldList_24s665204368x62248699(a_0, a_1)); heff_drop(v_args_2410); r_; });
    }
    case TAG_ELet: {
      V v_a_2413 = heff_field(v_x2_241, 1);
      V v_b_2414 = heff_field(v_x2_241, 2);
      heff_take_n(v_x2_241, 6ULL, 3);
      V v_a_2415 = (g_heff_2ecompile_2eworlds_2eworldsIn(v_a_2413, v_acc_242));
      V t_0 = NTAG(TAG_Enter_24heff_2ecompile_2eworlds_2eworldsIn);
      V t_1 = ((V)&g_heff_2ecompile_2eir_2efoldParts_24s1678201098x2107332371_24cycle_str2);
      V t_2 = ((V)&g_heff_2ecompile_2eir_2efoldParts_24s1678201098x2107332371_24cycle_str3);
      V t_3 = v_b_2414;
      V t_4 = v_a_2415;
      v_tag_240 = t_0;
      v_x2_241 = t_1;
      v_acc_242 = t_2;
      v_e_243 = t_3;
      v_acc_244 = t_4;
      goto top_TAG_Enter_24heff_2ecompile_2eworlds_2eworldsIn;
    }
    case TAG_ERecord: {
      V v_fs_2416 = heff_field(v_x2_241, 0);
      heff_take_n(v_x2_241, 1ULL, 2);
      return ({ V a_0 = v_fs_2416; V a_1 = v_acc_242; V r_ = (g_heff_2ecompile_2eir_2efoldFields_24s1664558841x62844947(a_0, a_1)); heff_drop(v_fs_2416); r_; });
    }
    case TAG_EProj: {
      V v_e_2418 = heff_field(v_x2_241, 0);
      heff_take_n(v_x2_241, 1ULL, 4);
      V t_0 = NTAG(TAG_Enter_24heff_2ecompile_2eworlds_2eworldsIn);
      V t_1 = ((V)&g_heff_2ecompile_2eir_2efoldParts_24s1678201098x2107332371_24cycle_str4);
      V t_2 = ((V)&g_heff_2ecompile_2eir_2efoldParts_24s1678201098x2107332371_24cycle_str5);
      V t_3 = v_e_2418;
      V t_4 = v_acc_242;
      v_tag_240 = t_0;
      v_x2_241 = t_1;
      v_acc_242 = t_2;
      v_e_243 = t_3;
      v_acc_244 = t_4;
      goto top_TAG_Enter_24heff_2ecompile_2eworlds_2eworldsIn;
    }
    case TAG_ETag: {
      V v_args_2423 = heff_field(v_x2_241, 1);
      heff_take_n(v_x2_241, 2ULL, 3);
      return ({ V a_0 = v_args_2423; V a_1 = v_acc_242; V r_ = (g_heff_2ecompile_2eir_2efoldList_24s665204368x62248699(a_0, a_1)); heff_drop(v_args_2423); r_; });
    }
    case TAG_EMatch: {
      V v_s_2425 = heff_field(v_x2_241, 0);
      V v_arms_2426 = heff_field(v_x2_241, 1);
      heff_take_n(v_x2_241, 3ULL, 2);
      V v_t_2427 = (g_heff_2ecompile_2eworlds_2eworldsIn(v_s_2425, v_acc_242));
      return ({ V a_0 = v_arms_2426; V a_1 = v_t_2427; V r_ = (g_heff_2ecompile_2eir_2efoldArms_24s1362069606x2094249349(a_0, a_1)); heff_drop(v_arms_2426); r_; });
    }
    case TAG_EPrim: {
      heff_take_n(v_x2_241, 0ULL, 1);
      return v_acc_242;
    }
    case TAG_EPrimCall: {
      V v_args_2430 = heff_field(v_x2_241, 1);
      heff_take_n(v_x2_241, 2ULL, 2);
      return ({ V a_0 = v_args_2430; V a_1 = v_acc_242; V r_ = (g_heff_2ecompile_2eir_2efoldList_24s665204368x62248699(a_0, a_1)); heff_drop(v_args_2430); r_; });
    }
    case TAG_ECall: {
      V v_args_2432 = heff_field(v_x2_241, 1);
      heff_take_n(v_x2_241, 2ULL, 2);
      return ({ V a_0 = v_args_2432; V a_1 = v_acc_242; V r_ = (g_heff_2ecompile_2eir_2efoldList_24s665204368x62248699(a_0, a_1)); heff_drop(v_args_2432); r_; });
    }
    case TAG_EInt: {
      heff_take_n(v_x2_241, 0ULL, 1);
      return v_acc_242;
    }
    case TAG_EFloat: {
      heff_take_nf(v_x2_241, 0ULL, 1);
      return v_acc_242;
    }
    case TAG_EStr: {
      heff_take_n(v_x2_241, 0ULL, 1);
      return v_acc_242;
    }
    case TAG_EBytes: {
      heff_take_n(v_x2_241, 0ULL, 1);
      return v_acc_242;
    }
    case TAG_EFixed: {
      heff_take_n(v_x2_241, 0ULL, 2);
      return v_acc_242;
    }
    case TAG_EFloat32: {
      heff_take_na(v_x2_241, 0ULL, 1);
      return v_acc_242;
    }
    case TAG_EAbandon: {
      return v_acc_242;
    }
    case TAG_EBool: {
      V v_c_2440 = heff_field(v_x2_241, 0);
      heff_take_n(v_x2_241, 1ULL, 1);
      V v_t_2441 = ({ V a_0 = v_c_2440; V a_1 = NTAG(TAG_Nil); V r_ = (g_heff_2ecompile_2eir_2econdOnto(a_0, a_1)); heff_drop(v_c_2440); r_; });
      return ({ V a_0 = v_t_2441; V a_1 = v_acc_242; V r_ = (g_heff_2ecompile_2eir_2efoldList_24s665204368x62248699(a_0, a_1)); heff_drop(v_t_2441); r_; });
    }
    case TAG_ESet: {
      V v_a_2443 = heff_field(v_x2_241, 1);
      V v_b_2444 = heff_field(v_x2_241, 2);
      heff_take_n(v_x2_241, 6ULL, 3);
      V v_a_2445 = (g_heff_2ecompile_2eworlds_2eworldsIn(v_a_2443, v_acc_242));
      V t_0 = NTAG(TAG_Enter_24heff_2ecompile_2eworlds_2eworldsIn);
      V t_1 = ((V)&g_heff_2ecompile_2eir_2efoldParts_24s1678201098x2107332371_24cycle_str6);
      V t_2 = ((V)&g_heff_2ecompile_2eir_2efoldParts_24s1678201098x2107332371_24cycle_str7);
      V t_3 = v_b_2444;
      V t_4 = v_a_2445;
      v_tag_240 = t_0;
      v_x2_241 = t_1;
      v_acc_242 = t_2;
      v_e_243 = t_3;
      v_acc_244 = t_4;
      goto top_TAG_Enter_24heff_2ecompile_2eworlds_2eworldsIn;
    }
    case TAG_EValues: {
      V v_es_2446 = heff_field(v_x2_241, 0);
      heff_take_n(v_x2_241, 1ULL, 1);
      return ({ V a_0 = v_es_2446; V a_1 = v_acc_242; V r_ = (g_heff_2ecompile_2eir_2efoldList_24s665204368x62248699(a_0, a_1)); heff_drop(v_es_2446); r_; });
    }
    case TAG_EFix: {
      V v_b_2448 = heff_field(v_x2_241, 1);
      heff_take_n(v_x2_241, 2ULL, 2);
      V t_0 = NTAG(TAG_Enter_24heff_2ecompile_2eworlds_2eworldsIn);
      V t_1 = ((V)&g_heff_2ecompile_2eir_2efoldParts_24s1678201098x2107332371_24cycle_str8);
      V t_2 = ((V)&g_heff_2ecompile_2eir_2efoldParts_24s1678201098x2107332371_24cycle_str9);
      V t_3 = v_b_2448;
      V t_4 = v_acc_242;
      v_tag_240 = t_0;
      v_x2_241 = t_1;
      v_acc_242 = t_2;
      v_e_243 = t_3;
      v_acc_244 = t_4;
      goto top_TAG_Enter_24heff_2ecompile_2eworlds_2eworldsIn;
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  case TAG_Enter_24heff_2ecompile_2eworlds_2eworldsIn: {
    top_TAG_Enter_24heff_2ecompile_2eworlds_2eworldsIn: ;
    heff_drop(v_x2_241);
    heff_drop(v_acc_242);
    HeffT3 v_t_2449 = (g_heff_2ecompile_2eworlds_2esidesOf_24cpr(v_e_243));
    {
      V v_field_2451 = v_t_2449.f[1];
      V v_field_2452 = v_t_2449.f[2];
      int64_t v_tag_2450 = ((int64_t)v_t_2449.f[0]);
      if ((v_tag_2450 == ((int64_t)0ULL))) {
        V v_a_2453 = v_field_2451;
        V v_b_2454 = v_field_2452;
        V v_t_2455 = (g_heff_2ecompile_2eworlds_2eofGlobals(v_a_2453));
        if ((heff_dup(v_t_2455) == NTAG(TAG_True))) {
          heff_drop(v_t_2455);
          V v_t_2456 = (g_heff_2ecompile_2eworlds_2eofGlobals(v_b_2454));
          if ((heff_dup(v_t_2456) == NTAG(TAG_True))) {
            heff_drop(v_t_2456);
            return heff_tag_n(TAG_Cons, 2, (V[]){v_e_243, v_acc_244});
          } else {
            heff_drop(v_t_2456);
            V t_0 = NTAG(TAG_Enter_24heff_2ecompile_2eir_2efoldParts_24s1678201098x2107332371);
            V t_1 = v_e_243;
            V t_2 = v_acc_244;
            V t_3 = ((V)&g_heff_2ecompile_2eir_2efoldParts_24s1678201098x2107332371_24cycle_str10);
            V t_4 = ((V)&g_heff_2ecompile_2eir_2efoldParts_24s1678201098x2107332371_24cycle_str11);
            v_tag_240 = t_0;
            v_x2_241 = t_1;
            v_acc_242 = t_2;
            v_e_243 = t_3;
            v_acc_244 = t_4;
            goto top_TAG_Enter_24heff_2ecompile_2eir_2efoldParts_24s1678201098x2107332371;
          }
        } else {
          heff_drop(v_b_2454);
          heff_drop(v_t_2455);
          V t_0 = NTAG(TAG_Enter_24heff_2ecompile_2eir_2efoldParts_24s1678201098x2107332371);
          V t_1 = v_e_243;
          V t_2 = v_acc_244;
          V t_3 = ((V)&g_heff_2ecompile_2eir_2efoldParts_24s1678201098x2107332371_24cycle_str12);
          V t_4 = ((V)&g_heff_2ecompile_2eir_2efoldParts_24s1678201098x2107332371_24cycle_str13);
          v_tag_240 = t_0;
          v_x2_241 = t_1;
          v_acc_242 = t_2;
          v_e_243 = t_3;
          v_acc_244 = t_4;
          goto top_TAG_Enter_24heff_2ecompile_2eir_2efoldParts_24s1678201098x2107332371;
        }
      } else {
        heff_drop(v_field_2451);
        heff_drop(v_field_2452);
        V t_0 = NTAG(TAG_Enter_24heff_2ecompile_2eir_2efoldParts_24s1678201098x2107332371);
        V t_1 = v_e_243;
        V t_2 = v_acc_244;
        V t_3 = ((V)&g_heff_2ecompile_2eir_2efoldParts_24s1678201098x2107332371_24cycle_str14);
        V t_4 = ((V)&g_heff_2ecompile_2eir_2efoldParts_24s1678201098x2107332371_24cycle_str15);
        v_tag_240 = t_0;
        v_x2_241 = t_1;
        v_acc_242 = t_2;
        v_e_243 = t_3;
        v_acc_244 = t_4;
        goto top_TAG_Enter_24heff_2ecompile_2eir_2efoldParts_24s1678201098x2107332371;
      }
    }
  }
  default: return heff_nomatch(v_tag_240);
  }
}
V g_heff_2ecompile_2eir_2efoldParts_24s1678201098x2107332371_24cycle_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eir_2efoldParts_24s1678201098x2107332371_24cycle(a[0], a[1], a[2], a[3], a[4]);
}