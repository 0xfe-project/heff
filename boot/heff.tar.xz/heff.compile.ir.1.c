// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_CFalse 2759
#define TAG_CIf 14188
#define TAG_CNot 51573
#define TAG_CRel 55099
#define TAG_CTest 64009
#define TAG_CTrue 11023
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBool 8245
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_ESet 50124
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EValues 34965
#define TAG_EVar 52881
#define TAG_MkArm 55352
#define TAG_OpAdd 19601
#define TAG_OpAnd 19910
#define TAG_OpDiv 22656
#define TAG_OpEq 47278
#define TAG_OpFloor 41205
#define TAG_OpFromFloat 35229
#define TAG_OpFromInt 12062
#define TAG_OpLe 47483
#define TAG_OpLt 47498
#define TAG_OpMul 31667
#define TAG_OpOr 47589
#define TAG_OpRem 35977
#define TAG_OpShl 37030
#define TAG_OpShow 33901
#define TAG_OpShr 37036
#define TAG_OpSqrt 42640
#define TAG_OpSub 37423
#define TAG_OpToFloat 56600
#define TAG_OpToInt 49177
#define TAG_OpXor 42058
#define LBL_m 327
#define LBL_n 328
#define LBL_op 10312
#define LBL_xs 10594
static uint32_t shape_m__n__xs[] = {LBL_m, LBL_n, LBL_xs};
V g_heff_2ecompile_2eir_2eallI(V);
V g_heff_2ecompile_2eir_2eallI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eallI_clo;
V g_heff_2ecompile_2eir_2eappendI(V, V);
V g_heff_2ecompile_2eir_2eappendI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eappendI_clo;
V g_heff_2ecompile_2eir_2eappendI_24dps(V, V, V);
V g_heff_2ecompile_2eir_2eappendI_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eappendI_24dps_clo;
V g_heff_2ecompile_2eir_2eappendI_24tok2(V, V, V);
V g_heff_2ecompile_2eir_2eappendI_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eappendI_24tok2_clo;
V g_heff_2ecompile_2eir_2ebaseGo(V, V);
V g_heff_2ecompile_2eir_2ebaseGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2ebaseGo_clo;
V g_heff_2ecompile_2eir_2econcatMapI_24s307035317x1495364673(V);
V g_heff_2ecompile_2eir_2econcatMapI_24s307035317x1495364673_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2econcatMapI_24s307035317x1495364673_clo;
V g_heff_2ecompile_2eir_2econcatMapI_24s439116468x354877539(V);
V g_heff_2ecompile_2eir_2econcatMapI_24s439116468x354877539_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2econcatMapI_24s439116468x354877539_clo;
V g_heff_2ecompile_2eir_2econdExpr(V);
V g_heff_2ecompile_2eir_2econdExpr_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2econdExpr_clo;
HeffT2 g_heff_2ecompile_2eir_2econdFillGo_24cpr(V, V);
V g_heff_2ecompile_2eir_2econdMap(V, V);
V g_heff_2ecompile_2eir_2econdMap_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2econdMap_clo;
V g_heff_2ecompile_2eir_2econdMap_24dps(V, V, V, V);
V g_heff_2ecompile_2eir_2econdMap_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2econdMap_24dps_clo;
V g_heff_2ecompile_2eir_2econdOnto(V, V);
V g_heff_2ecompile_2eir_2econdOnto_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2econdOnto_clo;
V g_heff_2ecompile_2eir_2econdTraverse_24s1144524526x881445050(V, V);
V g_heff_2ecompile_2eir_2econdTraverse_24s1144524526x881445050_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2econdTraverse_24s1144524526x881445050_clo;
V g_heff_2ecompile_2eir_2econdTraverse_24s2104458127x1504356407(V, V);
V g_heff_2ecompile_2eir_2econdTraverse_24s2104458127x1504356407_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2econdTraverse_24s2104458127x1504356407_clo;
V g_heff_2ecompile_2eir_2econdTraverse_24s378097287x400807650(V, V);
V g_heff_2ecompile_2eir_2econdTraverse_24s378097287x400807650_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2econdTraverse_24s378097287x400807650_clo;
V g_heff_2ecompile_2eir_2econdTraverse_24s792224752x124814130(V, V);
V g_heff_2ecompile_2eir_2econdTraverse_24s792224752x124814130_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2econdTraverse_24s792224752x124814130_clo;
V g_heff_2ecompile_2eir_2ecountW(V, V, V);
V g_heff_2ecompile_2eir_2ecountW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2ecountW_clo;
V g_heff_2ecompile_2eir_2efreshBindOne(V, V);
V g_heff_2ecompile_2eir_2efreshBindOne_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2efreshBindOne_clo;
HeffT2 g_heff_2ecompile_2eir_2efreshCond_24s1412762879x1533354313_24cpr(V, V, V);
HeffT2 g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850_24cpr(V, V, V);
V g_heff_2ecompile_2eir_2eglobalsGo(V);
V g_heff_2ecompile_2eir_2eglobalsGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eglobalsGo_clo;
V g_heff_2ecompile_2eir_2eisRel(V);
V g_heff_2ecompile_2eir_2eisRel_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eisRel_clo;
V g_heff_2ecompile_2eir_2eisValue(V);
V g_heff_2ecompile_2eir_2eisValue_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eisValue_clo;
V g_heff_2ecompile_2eir_2enubI(V);
V g_heff_2ecompile_2eir_2enubI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2enubI_clo;
V g_heff_2ecompile_2eir_2enubI_24dps(V, V);
V g_heff_2ecompile_2eir_2enubI_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2enubI_24dps_clo;
V g_heff_2ecompile_2eir_2epartsOnto(V, V);
V g_heff_2ecompile_2eir_2epartsOnto_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2epartsOnto_clo;
V g_heff_2ecompile_2eir_2epushArms(V, V);
V g_heff_2ecompile_2eir_2epushArms_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2epushArms_clo;
V g_heff_2ecompile_2eir_2epushFields(V, V);
V g_heff_2ecompile_2eir_2epushFields_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2epushFields_clo;
V g_heff_2ecompile_2eir_2epushFields_24dps(V, V, V);
V g_heff_2ecompile_2eir_2epushFields_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2epushFields_24dps_clo;
V g_heff_2ecompile_2eir_2epushFields_24tok2(V, V, V);
V g_heff_2ecompile_2eir_2epushFields_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2epushFields_24tok2_clo;
V g_heff_2ecompile_2eir_2erelPrims_get(void);
V g_heff_2ecompile_2eir_2esizeB(V, V, V);
V g_heff_2ecompile_2eir_2esizeB_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2esizeB_clo;
HeffT2 g_heff_2eelab_2efixed_2efixedPrimOf_24cpr(V);
V g_list_2eany_24s2077819594x1842428557(V, V);
V g_list_2eany_24s2077819594x1842428557_entry(V self, V *a);
extern Clo g_list_2eany_24s2077819594x1842428557_clo;
V g_list_2ekeepIf_24s930188071x496633547(V, V);
V g_list_2ekeepIf_24s930188071x496633547_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s930188071x496633547_clo;
V g_list_2emap_24s1044393341x1523302351(V);
V g_list_2emap_24s1044393341x1523302351_entry(V self, V *a);
extern Clo g_list_2emap_24s1044393341x1523302351_clo;
V g_list_2emap_24s584454411x1006678865(V);
V g_list_2emap_24s584454411x1006678865_entry(V self, V *a);
extern Clo g_list_2emap_24s584454411x1006678865_clo;
V g_std_2emap_2einsert_24s93785294x875597928(V, V, V);
V g_std_2emap_2einsert_24s93785294x875597928_entry(V self, V *a);
extern Clo g_std_2emap_2einsert_24s93785294x875597928_clo;
Clo g_heff_2ecompile_2eir_2econdMap_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2econdMap_24dps_entry, 4, 0};

V g_heff_2ecompile_2eir_2econdMap_24dps(V v_f_240, V v_x2_241, V v_d_242, V v_i_243) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_CTrue: {
    heff_drop(v_f_240);
    return heff_setField(v_d_242, v_i_243, NTAG(TAG_CTrue));
  }
  case TAG_CFalse: {
    heff_drop(v_f_240);
    return heff_setField(v_d_242, v_i_243, NTAG(TAG_CFalse));
  }
  case TAG_CRel: {
    V v_p_244 = heff_field(v_x2_241, 0);
    V v_x_245 = heff_field(v_x2_241, 1);
    V v_y_246 = heff_field(v_x2_241, 2);
    heff_take_n(v_x2_241, 7ULL, 3);
    V v_t_247 = heff_tr(heff_call(heff_dup(v_f_240), 1, (V[]){v_x_245}));
    V v_t_248 = heff_tr(heff_call(v_f_240, 1, (V[]){v_y_246}));
    return heff_setField(v_d_242, v_i_243, heff_tag_n(TAG_CRel, 3, (V[]){v_p_244, v_t_247, v_t_248}));
  }
  case TAG_CTest: {
    V v_x_249 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    V v_t_2410 = heff_tr(heff_call(v_f_240, 1, (V[]){v_x_249}));
    return heff_setField(v_d_242, v_i_243, heff_tag_n(TAG_CTest, 1, (V[]){v_t_2410}));
  }
  case TAG_CNot: {
    V v_c_2411 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24CNot = heff_take_reuse_n(v_x2_241, 1ULL, 1);
    V v_cell_2412 = heff_tag_at_n(v_ru_24x2_241_24CNot, TAG_CNot, 1, (V[]){heff_hole()});
    V v_u_2413 = heff_setField(v_d_242, v_i_243, heff_dup(v_cell_2412));
    heff_drop(v_u_2413);
    V t_0 = v_f_240;
    V t_1 = v_c_2411;
    V t_2 = v_cell_2412;
    V t_3 = MK_INT(0LL);
    v_f_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    v_i_243 = t_3;
    goto top;
  }
  case TAG_CIf: {
    V v_a_2414 = heff_field(v_x2_241, 0);
    V v_b_2415 = heff_field(v_x2_241, 1);
    V v_c_2416 = heff_field(v_x2_241, 2);
    V v_ru_24x2_241_24CIf = heff_take_reuse_n(v_x2_241, 7ULL, 3);
    V v_t_2417 = (g_heff_2ecompile_2eir_2econdMap(heff_dup(v_f_240), v_a_2414));
    V v_t_2418 = (g_heff_2ecompile_2eir_2econdMap(heff_dup(v_f_240), v_b_2415));
    V v_cell_2419 = heff_tag_at_n(v_ru_24x2_241_24CIf, TAG_CIf, 3, (V[]){v_t_2417, v_t_2418, heff_hole()});
    V v_u_2420 = heff_setField(v_d_242, v_i_243, heff_dup(v_cell_2419));
    heff_drop(v_u_2420);
    V t_0 = v_f_240;
    V t_1 = v_c_2416;
    V t_2 = v_cell_2419;
    V t_3 = MK_INT(2LL);
    v_f_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    v_i_243 = t_3;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eir_2econdMap_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eir_2econdMap_24dps(a[0], a[1], a[2], a[3]);
}

HeffT2 g_heff_2ecompile_2eir_2econdFillGo_24cpr(V v_x1_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_CTrue: {
    V v_t_242 = heff_tag_n(TAG_Just, 1, (V[]){NTAG(TAG_CTrue)});
    return ((HeffT2){{v_t_242, v_x2_241}});
  }
  case TAG_CFalse: {
    V v_t_243 = heff_tag_n(TAG_Just, 1, (V[]){NTAG(TAG_CFalse)});
    return ((HeffT2){{v_t_243, v_x2_241}});
  }
  case TAG_CRel: {
    V v_p_244 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24CRel = heff_take_reuse_n(v_x1_240, 1ULL, 3);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      heff_drop(v_p_244);
      heff_drop_cell(v_ru_24x1_240_24CRel, 3);
      return ((HeffT2){{NTAG(TAG_Nothing), v_x2_241}});
    }
    case TAG_Cons: {
      V v_x22_248 = heff_dup(heff_field(v_x2_241, 1));
      switch (heff_tag_of(v_x22_248)) {
      case TAG_Nil: {
        heff_drop(v_p_244);
        heff_drop_cell(v_ru_24x1_240_24CRel, 3);
        return ((HeffT2){{NTAG(TAG_Nothing), v_x2_241}});
      }
      case TAG_Cons: {
        V v_y_249 = heff_field(v_x22_248, 0);
        V v_es_2410 = heff_field(v_x22_248, 1);
        heff_take_n(v_x22_248, 3ULL, 2);
        switch (heff_tag_of(v_x2_241)) {
        case TAG_Cons: {
          V v_x_2411 = heff_field(v_x2_241, 0);
          heff_take_n(v_x2_241, 1ULL, 2);
          V v_t_2413 = heff_tag_n(TAG_Just, 1, (V[]){heff_tag_at_n(v_ru_24x1_240_24CRel, TAG_CRel, 3, (V[]){v_p_244, v_x_2411, v_y_249})});
          return ((HeffT2){{v_t_2413, v_es_2410}});
        }
        default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x22_248)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
    }
  }
  case TAG_CTest: {
    V v_ru_24x1_240_24CTest = heff_take_reuse_n(v_x1_240, 0ULL, 1);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      heff_drop_cell(v_ru_24x1_240_24CTest, 1);
      return ((HeffT2){{NTAG(TAG_Nothing), v_x2_241}});
    }
    case TAG_Cons: {
      V v_x_2415 = heff_field(v_x2_241, 0);
      V v_es_2416 = heff_field(v_x2_241, 1);
      heff_take_n(v_x2_241, 3ULL, 2);
      V v_t_2417 = heff_tag_n(TAG_Just, 1, (V[]){heff_tag_at_n(v_ru_24x1_240_24CTest, TAG_CTest, 1, (V[]){v_x_2415})});
      return ((HeffT2){{v_t_2417, v_es_2416}});
    }
    default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
    }
  }
  case TAG_CNot: {
    V v_c_2418 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24CNot = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    HeffT2 v_t_2419 = (g_heff_2ecompile_2eir_2econdFillGo_24cpr(v_c_2418, v_x2_241));
    {
      V v_field_2420 = v_t_2419.f[0];
      V v_field_2421 = v_t_2419.f[1];
      V v_x11_2422 = v_field_2420;
      V v_es_2423 = v_field_2421;
      switch (heff_tag_of(v_x11_2422)) {
      case TAG_Nothing: {
        heff_drop_cell(v_ru_24x1_240_24CNot, 1);
        return ((HeffT2){{NTAG(TAG_Nothing), v_es_2423}});
      }
      case TAG_Just: {
        V v_c_2424 = heff_field(v_x11_2422, 0);
        V v_ru_24x11_2422_24Just = heff_take_reuse_n(v_x11_2422, 1ULL, 1);
        V v_t_2425 = heff_tag_at_n(v_ru_24x11_2422_24Just, TAG_Just, 1, (V[]){heff_tag_at_n(v_ru_24x1_240_24CNot, TAG_CNot, 1, (V[]){v_c_2424})});
        return ((HeffT2){{v_t_2425, v_es_2423}});
      }
      default: return ((HeffT2){{heff_nomatch(v_x11_2422)}});
      }
    }
  }
  case TAG_CIf: {
    V v_a_2426 = heff_field(v_x1_240, 0);
    V v_b_2427 = heff_field(v_x1_240, 1);
    V v_c_2428 = heff_field(v_x1_240, 2);
    V v_ru_24x1_240_24CIf = heff_take_reuse_n(v_x1_240, 7ULL, 3);
    HeffT2 v_t_2429 = (g_heff_2ecompile_2eir_2econdFillGo_24cpr(v_a_2426, v_x2_241));
    {
      V v_field_2430 = v_t_2429.f[0];
      V v_field_2431 = v_t_2429.f[1];
      V v_x11_2432 = v_field_2430;
      V v_es_2433 = v_field_2431;
      switch (heff_tag_of(v_x11_2432)) {
      case TAG_Nothing: {
        heff_drop(v_b_2427);
        heff_drop(v_c_2428);
        heff_drop_cell(v_ru_24x1_240_24CIf, 3);
        return ((HeffT2){{NTAG(TAG_Nothing), v_es_2433}});
      }
      case TAG_Just: {
        V v_c_2434 = heff_field(v_x11_2432, 0);
        V v_ru_24x11_2432_24Just = heff_take_reuse_n(v_x11_2432, 1ULL, 1);
        HeffT2 v_t_2435 = (g_heff_2ecompile_2eir_2econdFillGo_24cpr(v_b_2427, v_es_2433));
        {
          V v_field_2436 = v_t_2435.f[0];
          V v_field_2437 = v_t_2435.f[1];
          V v_x11_2438 = v_field_2436;
          V v_es_2439 = v_field_2437;
          switch (heff_tag_of(v_x11_2438)) {
          case TAG_Nothing: {
            heff_drop(v_c_2428);
            heff_drop_cell(v_ru_24x1_240_24CIf, 3);
            heff_drop(v_c_2434);
            heff_drop_cell(v_ru_24x11_2432_24Just, 1);
            return ((HeffT2){{NTAG(TAG_Nothing), v_es_2439}});
          }
          case TAG_Just: {
            V v_c_2440 = heff_field(v_x11_2438, 0);
            heff_take_n(v_x11_2438, 1ULL, 1);
            HeffT2 v_t_2441 = (g_heff_2ecompile_2eir_2econdFillGo_24cpr(v_c_2428, v_es_2439));
            {
              V v_field_2442 = v_t_2441.f[0];
              V v_field_2443 = v_t_2441.f[1];
              V v_x11_2444 = v_field_2442;
              V v_es_2445 = v_field_2443;
              switch (heff_tag_of(v_x11_2444)) {
              case TAG_Nothing: {
                heff_drop_cell(v_ru_24x1_240_24CIf, 3);
                heff_drop(v_c_2434);
                heff_drop_cell(v_ru_24x11_2432_24Just, 1);
                heff_drop(v_c_2440);
                return ((HeffT2){{NTAG(TAG_Nothing), v_es_2445}});
              }
              case TAG_Just: {
                V v_c_2446 = heff_field(v_x11_2444, 0);
                heff_take_n(v_x11_2444, 1ULL, 1);
                V v_t_2447 = heff_tag_at_n(v_ru_24x11_2432_24Just, TAG_Just, 1, (V[]){heff_tag_at_n(v_ru_24x1_240_24CIf, TAG_CIf, 3, (V[]){v_c_2434, v_c_2440, v_c_2446})});
                return ((HeffT2){{v_t_2447, v_es_2445}});
              }
              default: return ((HeffT2){{heff_nomatch(v_x11_2444)}});
              }
            }
          }
          default: return ((HeffT2){{heff_nomatch(v_x11_2438)}});
          }
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x11_2432)}});
      }
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
Clo g_heff_2ecompile_2eir_2eappendI_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2eappendI_entry, 2, 0};

V g_heff_2ecompile_2eir_2eappendI(V v_x1_240, V v_ys_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return v_ys_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
    V v_u_245 = (g_heff_2ecompile_2eir_2eappendI_24dps(v_xs_243, v_ys_241, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eir_2eappendI_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eir_2eappendI(a[0], a[1]);
}
Clo g_heff_2ecompile_2eir_2enubI_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2enubI_entry, 1, 0};

V g_heff_2ecompile_2eir_2enubI(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x1_240, 0);
    V v_xs_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_cell_243 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_x_241), heff_hole()});
    V v_t_244 = ({ V a_0 = v_x_241; V a_1 = v_xs_242; V r_ = (g_list_2ekeepIf_24s930188071x496633547(a_0, a_1)); heff_drop(v_x_241); r_; });
    V v_u_245 = (g_heff_2ecompile_2eir_2enubI_24dps(v_t_244, heff_dup(v_cell_243)));
    heff_drop(v_u_245);
    return v_cell_243;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eir_2enubI_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eir_2enubI(a[0]);
}
HEFF_LIT(g_heff_2ecompile_2eir_2efreshBindOne_str0, 1, "$");
Clo g_heff_2ecompile_2eir_2efreshBindOne_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2efreshBindOne_entry, 2, 0};

V g_heff_2ecompile_2eir_2efreshBindOne(V v_acc_240, V v_x_241) {
top: ;
  V v_n_242 = heff_take_field(v_acc_240, 1);
  V v_m_243 = heff_take_field(v_acc_240, 0);
  V v_xs_244 = heff_get_n(v_acc_240, 2, 3);
  V v_base_245 = (g_heff_2ecompile_2eir_2ebaseGo(heff_dup(v_x_241), MK_INT(0LL)));
  V v_n_246 = v_n_242;
  V v_t_247 = heff_strAppend(((V)&g_heff_2ecompile_2eir_2efreshBindOne_str0), heff_intShow(heff_dup(v_n_246)));
  V v_x_27_248 = heff_strAppend(v_base_245, v_t_247);
  V v_t_249 = (g_std_2emap_2einsert_24s93785294x875597928(v_m_243, v_x_241, heff_dup(v_x_27_248)));
  return heff_rec_n(3, shape_m__n__xs, (V[]){v_t_249, heff_intAdd(v_n_246, MK_INT(1LL)), heff_tag_n(TAG_Cons, 2, (V[]){v_x_27_248, v_xs_244})});
}
V g_heff_2ecompile_2eir_2efreshBindOne_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eir_2efreshBindOne(a[0], a[1]);
}

HeffT2 g_heff_2ecompile_2eir_2efreshCond_24s1412762879x1533354313_24cpr(V v_m_240, V v_n_241, V v_x4_242) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_CTrue: {
    heff_drop(v_m_240);
    return ((HeffT2){{NTAG(TAG_CTrue), v_n_241}});
  }
  case TAG_CFalse: {
    heff_drop(v_m_240);
    return ((HeffT2){{NTAG(TAG_CFalse), v_n_241}});
  }
  case TAG_CRel: {
    V v_p_243 = heff_field(v_x4_242, 0);
    V v_x_244 = heff_field(v_x4_242, 1);
    V v_y_245 = heff_field(v_x4_242, 2);
    V v_ru_24x4_242_24CRel = heff_take_reuse_n(v_x4_242, 7ULL, 3);
    HeffT2 v_t_246 = (g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850_24cpr(heff_dup(v_m_240), v_n_241, v_x_244));
    {
      V v_field_247 = v_t_246.f[0];
      V v_field_248 = v_t_246.f[1];
      V v_x_27_249 = v_field_247;
      V v_n1_2410 = v_field_248;
      HeffT2 v_t_2411 = (g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850_24cpr(v_m_240, v_n1_2410, v_y_245));
      {
        V v_field_2412 = v_t_2411.f[0];
        V v_field_2413 = v_t_2411.f[1];
        V v_y_27_2414 = v_field_2412;
        V v_n2_2415 = v_field_2413;
        return ((HeffT2){{heff_tag_at_n(v_ru_24x4_242_24CRel, TAG_CRel, 3, (V[]){v_p_243, v_x_27_249, v_y_27_2414}), v_n2_2415}});
      }
    }
  }
  case TAG_CTest: {
    V v_x_2416 = heff_field(v_x4_242, 0);
    V v_ru_24x4_242_24CTest = heff_take_reuse_n(v_x4_242, 1ULL, 1);
    HeffT2 v_t_2417 = (g_heff_2ecompile_2eir_2efreshGo_24s1598002449x1298635850_24cpr(v_m_240, v_n_241, v_x_2416));
    {
      V v_field_2418 = v_t_2417.f[0];
      V v_field_2419 = v_t_2417.f[1];
      V v_x_27_2420 = v_field_2418;
      V v_n1_2421 = v_field_2419;
      return ((HeffT2){{heff_tag_at_n(v_ru_24x4_242_24CTest, TAG_CTest, 1, (V[]){v_x_27_2420}), v_n1_2421}});
    }
  }
  case TAG_CNot: {
    V v_c_2422 = heff_field(v_x4_242, 0);
    V v_ru_24x4_242_24CNot = heff_take_reuse_n(v_x4_242, 1ULL, 1);
    HeffT2 v_t_2423 = (g_heff_2ecompile_2eir_2efreshCond_24s1412762879x1533354313_24cpr(v_m_240, v_n_241, v_c_2422));
    {
      V v_field_2424 = v_t_2423.f[0];
      V v_field_2425 = v_t_2423.f[1];
      V v_c_2426 = v_field_2424;
      V v_n_2427 = v_field_2425;
      return ((HeffT2){{heff_tag_at_n(v_ru_24x4_242_24CNot, TAG_CNot, 1, (V[]){v_c_2426}), v_n_2427}});
    }
  }
  case TAG_CIf: {
    V v_a_2428 = heff_field(v_x4_242, 0);
    V v_b_2429 = heff_field(v_x4_242, 1);
    V v_c_2430 = heff_field(v_x4_242, 2);
    V v_ru_24x4_242_24CIf = heff_take_reuse_n(v_x4_242, 7ULL, 3);
    HeffT2 v_t_2431 = (g_heff_2ecompile_2eir_2efreshCond_24s1412762879x1533354313_24cpr(heff_dup(v_m_240), v_n_241, v_a_2428));
    {
      V v_field_2432 = v_t_2431.f[0];
      V v_field_2433 = v_t_2431.f[1];
      V v_c_2434 = v_field_2432;
      V v_n_2435 = v_field_2433;
      HeffT2 v_t_2436 = (g_heff_2ecompile_2eir_2efreshCond_24s1412762879x1533354313_24cpr(heff_dup(v_m_240), v_n_2435, v_b_2429));
      {
        V v_field_2437 = v_t_2436.f[0];
        V v_field_2438 = v_t_2436.f[1];
        V v_c_2439 = v_field_2437;
        V v_n_2440 = v_field_2438;
        HeffT2 v_t_2441 = (g_heff_2ecompile_2eir_2efreshCond_24s1412762879x1533354313_24cpr(v_m_240, v_n_2440, v_c_2430));
        {
          V v_field_2442 = v_t_2441.f[0];
          V v_field_2443 = v_t_2441.f[1];
          V v_c_2444 = v_field_2442;
          V v_n_2445 = v_field_2443;
          return ((HeffT2){{heff_tag_at_n(v_ru_24x4_242_24CIf, TAG_CIf, 3, (V[]){v_c_2434, v_c_2439, v_c_2444}), v_n_2445}});
        }
      }
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x4_242)}});
  }
}
Clo g_heff_2ecompile_2eir_2epushFields_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2epushFields_entry, 2, 0};

V g_heff_2ecompile_2eir_2epushFields(V v_x1_240, V v_rest_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return v_rest_241;
  }
  case TAG_Cons: {
    V v_p_242 = heff_field(v_x1_240, 0);
    V v_fs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_246;
    switch (heff_tag_of(v_p_242)) {
    case TAG_MkPair: {
      V v_e2_245 = heff_field(v_p_242, 1);
      heff_take_n(v_p_242, 2ULL, 2);
      v_t_246 = v_e2_245;
      break;
    }
    default: heff_nomatch(v_p_242);
    }
    V v_cell_247 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_t_246, heff_hole()});
    V v_u_248 = (g_heff_2ecompile_2eir_2epushFields_24dps(v_fs_243, v_rest_241, heff_dup(v_cell_247)));
    heff_drop(v_u_248);
    return v_cell_247;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eir_2epushFields_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eir_2epushFields(a[0], a[1]);
}
Clo g_heff_2ecompile_2eir_2ecountW_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2ecountW_entry, 3, 0};

V g_heff_2ecompile_2eir_2ecountW(V v_x_240, V v_n_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    return v_n_241;
  }
  case TAG_Cons: {
    V v_x31_243 = heff_field(v_x3_242, 0);
    V v_rest_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    switch (heff_tag_of(v_x31_243)) {
    case TAG_EVar: {
      V v_y_245 = heff_field(v_x31_243, 0);
      heff_take_n(v_x31_243, 1ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V v_t_246;
      if (heff_strEq_c_lent(v_y_245, v_x_240, 1)) {
        v_t_246 = heff_intAdd(v_n_241, MK_INT(1LL));
      } else {
        v_t_246 = v_n_241;
      }
      V t_0 = v_x_240;
      V t_1 = v_t_246;
      V t_2 = v_rest_244;
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EGlobal: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = v_rest_244;
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_ELam: {
      V v_b_249 = heff_field(v_x31_243, 1);
      heff_take_n(v_x31_243, 2ULL, 2);
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_b_249, v_rest_244});
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EApp: {
      V v_f_2410 = heff_field(v_x31_243, 0);
      V v_args_2411 = heff_field(v_x31_243, 1);
      V v_ru_24x31_243_24EApp = heff_take_reuse_n(v_x31_243, 3ULL, 2);
      V v_t_2412 = (g_heff_2ecompile_2eir_2eappendI_24tok2(v_ru_24x31_243_24EApp, v_args_2411, v_rest_244));
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_f_2410, v_t_2412});
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_ELet: {
      V v_a_2414 = heff_field(v_x31_243, 1);
      V v_b_2415 = heff_field(v_x31_243, 2);
      heff_take_n(v_x31_243, 6ULL, 3);
      V v_t_2416 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_a_2414, heff_tag_n(TAG_Cons, 2, (V[]){v_b_2415, v_rest_244})});
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = v_t_2416;
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_ERecord: {
      V v_fs_2417 = heff_field(v_x31_243, 0);
      heff_take_n(v_x31_243, 1ULL, 2);
      V v_t_2419 = (g_heff_2ecompile_2eir_2epushFields_24tok2(v_ru_24x3_242_24Cons, v_fs_2417, v_rest_244));
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = v_t_2419;
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EProj: {
      V v_e_2420 = heff_field(v_x31_243, 0);
      heff_take_n(v_x31_243, 1ULL, 4);
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_e_2420, v_rest_244});
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_ETag: {
      V v_args_2425 = heff_field(v_x31_243, 1);
      heff_take_n(v_x31_243, 2ULL, 3);
      V v_t_2427 = (g_heff_2ecompile_2eir_2eappendI_24tok2(v_ru_24x3_242_24Cons, v_args_2425, v_rest_244));
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = v_t_2427;
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EMatch: {
      V v_s_2428 = heff_field(v_x31_243, 0);
      V v_arms_2429 = heff_field(v_x31_243, 1);
      heff_take_n(v_x31_243, 3ULL, 2);
      V v_t_2430 = (g_heff_2ecompile_2eir_2epushArms(v_arms_2429, v_rest_244));
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_s_2428, v_t_2430});
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EPrim: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = v_rest_244;
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EPrimCall: {
      V v_args_2433 = heff_field(v_x31_243, 1);
      heff_take_n(v_x31_243, 2ULL, 2);
      V v_t_2434 = (g_heff_2ecompile_2eir_2eappendI_24tok2(v_ru_24x3_242_24Cons, v_args_2433, v_rest_244));
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = v_t_2434;
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_ECall: {
      V v_args_2436 = heff_field(v_x31_243, 1);
      heff_take_n(v_x31_243, 2ULL, 2);
      V v_t_2437 = (g_heff_2ecompile_2eir_2eappendI_24tok2(v_ru_24x3_242_24Cons, v_args_2436, v_rest_244));
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = v_t_2437;
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EInt: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = v_rest_244;
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EFloat: {
      heff_take_na(v_x31_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = v_rest_244;
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EStr: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = v_rest_244;
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EBytes: {
      heff_take_n(v_x31_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = v_rest_244;
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EFixed: {
      heff_take_n(v_x31_243, 0ULL, 2);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = v_rest_244;
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EFloat32: {
      heff_take_na(v_x31_243, 0ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = v_rest_244;
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EAbandon: {
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = v_rest_244;
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EBool: {
      V v_c_2445 = heff_field(v_x31_243, 0);
      heff_take_n(v_x31_243, 1ULL, 1);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V v_t_2446 = ({ V a_0 = v_c_2445; V a_1 = v_rest_244; V r_ = (g_heff_2ecompile_2eir_2econdOnto(a_0, a_1)); heff_drop(v_c_2445); r_; });
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = v_t_2446;
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_ESet: {
      V v_a_2448 = heff_field(v_x31_243, 1);
      V v_b_2449 = heff_field(v_x31_243, 2);
      heff_take_n(v_x31_243, 6ULL, 3);
      V v_t_2450 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_a_2448, heff_tag_n(TAG_Cons, 2, (V[]){v_b_2449, v_rest_244})});
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = v_t_2450;
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EValues: {
      V v_es_2451 = heff_field(v_x31_243, 0);
      heff_take_n(v_x31_243, 1ULL, 1);
      V v_t_2452 = (g_heff_2ecompile_2eir_2eappendI_24tok2(v_ru_24x3_242_24Cons, v_es_2451, v_rest_244));
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = v_t_2452;
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    case TAG_EFix: {
      heff_take_n(v_x31_243, 0ULL, 2);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      V t_0 = v_x_240;
      V t_1 = v_n_241;
      V t_2 = v_rest_244;
      v_x_240 = t_0;
      v_n_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_x31_243);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2eir_2ecountW_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eir_2ecountW(a0, a[1], a[2]); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2eir_2epartsOnto_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2epartsOnto_entry, 2, 0};

V g_heff_2ecompile_2eir_2epartsOnto(V v_x1_240, V v_rest_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_EVar: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return v_rest_241;
  }
  case TAG_EGlobal: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return v_rest_241;
  }
  case TAG_ELam: {
    V v_b_245 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24ELam = heff_take_reuse_n(v_x1_240, 2ULL, 2);
    return heff_tag_at_n(v_ru_24x1_240_24ELam, TAG_Cons, 2, (V[]){v_b_245, v_rest_241});
  }
  case TAG_EApp: {
    V v_f_246 = heff_field(v_x1_240, 0);
    V v_args_247 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24EApp = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_248 = (g_heff_2ecompile_2eir_2eappendI(v_args_247, v_rest_241));
    return heff_tag_at_n(v_ru_24x1_240_24EApp, TAG_Cons, 2, (V[]){v_f_246, v_t_248});
  }
  case TAG_ELet: {
    V v_a_2410 = heff_field(v_x1_240, 1);
    V v_b_2411 = heff_field(v_x1_240, 2);
    heff_take_n(v_x1_240, 6ULL, 3);
    return heff_tag_n(TAG_Cons, 2, (V[]){v_a_2410, heff_tag_n(TAG_Cons, 2, (V[]){v_b_2411, v_rest_241})});
  }
  case TAG_ERecord: {
    V v_fs_2412 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24ERecord = heff_take_reuse_n(v_x1_240, 1ULL, 2);
    return (g_heff_2ecompile_2eir_2epushFields_24tok2(v_ru_24x1_240_24ERecord, v_fs_2412, v_rest_241));
  }
  case TAG_EProj: {
    V v_e_2414 = heff_field(v_x1_240, 0);
    heff_take_n(v_x1_240, 1ULL, 4);
    return heff_tag_n(TAG_Cons, 2, (V[]){v_e_2414, v_rest_241});
  }
  case TAG_ETag: {
    V v_args_2419 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 2ULL, 3);
    HEFF_LAST return g_heff_2ecompile_2eir_2eappendI(v_args_2419, v_rest_241);
  }
  case TAG_EMatch: {
    V v_s_2421 = heff_field(v_x1_240, 0);
    V v_arms_2422 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24EMatch = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_2423 = (g_heff_2ecompile_2eir_2epushArms(v_arms_2422, v_rest_241));
    return heff_tag_at_n(v_ru_24x1_240_24EMatch, TAG_Cons, 2, (V[]){v_s_2421, v_t_2423});
  }
  case TAG_EPrim: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return v_rest_241;
  }
  case TAG_EPrimCall: {
    V v_args_2426 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24EPrimCall = heff_take_reuse_n(v_x1_240, 2ULL, 2);
    return (g_heff_2ecompile_2eir_2eappendI_24tok2(v_ru_24x1_240_24EPrimCall, v_args_2426, v_rest_241));
  }
  case TAG_ECall: {
    V v_args_2428 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24ECall = heff_take_reuse_n(v_x1_240, 2ULL, 2);
    return (g_heff_2ecompile_2eir_2eappendI_24tok2(v_ru_24x1_240_24ECall, v_args_2428, v_rest_241));
  }
  case TAG_EInt: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return v_rest_241;
  }
  case TAG_EFloat: {
    heff_take_na(v_x1_240, 0ULL, 1);
    return v_rest_241;
  }
  case TAG_EStr: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return v_rest_241;
  }
  case TAG_EBytes: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return v_rest_241;
  }
  case TAG_EFixed: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return v_rest_241;
  }
  case TAG_EFloat32: {
    heff_take_na(v_x1_240, 0ULL, 1);
    return v_rest_241;
  }
  case TAG_EAbandon: {
    return v_rest_241;
  }
  case TAG_EBool: {
    V v_c_2436 = heff_field(v_x1_240, 0);
    heff_take_n(v_x1_240, 1ULL, 1);
    return ({ V a_0 = v_c_2436; V a_1 = v_rest_241; V r_ = (g_heff_2ecompile_2eir_2econdOnto(a_0, a_1)); heff_drop(v_c_2436); r_; });
  }
  case TAG_ESet: {
    V v_a_2438 = heff_field(v_x1_240, 1);
    V v_b_2439 = heff_field(v_x1_240, 2);
    heff_take_n(v_x1_240, 6ULL, 3);
    return heff_tag_n(TAG_Cons, 2, (V[]){v_a_2438, heff_tag_n(TAG_Cons, 2, (V[]){v_b_2439, v_rest_241})});
  }
  case TAG_EValues: {
    V v_es_2440 = heff_field(v_x1_240, 0);
    heff_take_n(v_x1_240, 1ULL, 1);
    HEFF_LAST return g_heff_2ecompile_2eir_2eappendI(v_es_2440, v_rest_241);
  }
  case TAG_EFix: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return v_rest_241;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eir_2epartsOnto_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eir_2epartsOnto(a[0], a[1]);
}
Clo g_heff_2ecompile_2eir_2esizeB_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2esizeB_entry, 3, 0};

V g_heff_2ecompile_2eir_2esizeB(V v_lim_240, V v_n_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_lim_240);
    return v_n_241;
  }
  case TAG_Cons: {
    V v_e_243 = heff_field(v_x3_242, 0);
    V v_rest_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    if (heff_intLt_c_lent(v_lim_240, v_n_241, 0)) {
      heff_drop(v_lim_240);
      heff_drop(v_e_243);
      heff_drop(v_rest_244);
      heff_drop_cell(v_ru_24x3_242_24Cons, 2);
      return v_n_241;
    } else {
      switch (heff_tag_of(v_e_243)) {
      case TAG_EVar: {
        heff_take_n(v_e_243, 0ULL, 1);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        V t_0 = v_lim_240;
        V t_1 = heff_intAdd(v_n_241, MK_INT(1LL));
        V t_2 = v_rest_244;
        v_lim_240 = t_0;
        v_n_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_EGlobal: {
        heff_take_n(v_e_243, 0ULL, 1);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        V t_0 = v_lim_240;
        V t_1 = heff_intAdd(v_n_241, MK_INT(1LL));
        V t_2 = v_rest_244;
        v_lim_240 = t_0;
        v_n_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_ELam: {
        V v_b_248 = heff_field(v_e_243, 1);
        heff_take_n(v_e_243, 2ULL, 2);
        V t_0 = v_lim_240;
        V t_1 = heff_intAdd(v_n_241, MK_INT(1LL));
        V t_2 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_b_248, v_rest_244});
        v_lim_240 = t_0;
        v_n_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_EApp: {
        V v_f_249 = heff_field(v_e_243, 0);
        V v_args_2410 = heff_field(v_e_243, 1);
        V v_ru_24e_243_24EApp = heff_take_reuse_n(v_e_243, 3ULL, 2);
        V v_t_2411 = (g_heff_2ecompile_2eir_2eappendI_24tok2(v_ru_24e_243_24EApp, v_args_2410, v_rest_244));
        V t_0 = v_lim_240;
        V t_1 = heff_intAdd(v_n_241, MK_INT(1LL));
        V t_2 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_f_249, v_t_2411});
        v_lim_240 = t_0;
        v_n_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_ELet: {
        V v_a_2413 = heff_field(v_e_243, 1);
        V v_b_2414 = heff_field(v_e_243, 2);
        heff_take_n(v_e_243, 6ULL, 3);
        V v_t_2415 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_a_2413, heff_tag_n(TAG_Cons, 2, (V[]){v_b_2414, v_rest_244})});
        V t_0 = v_lim_240;
        V t_1 = heff_intAdd(v_n_241, MK_INT(1LL));
        V t_2 = v_t_2415;
        v_lim_240 = t_0;
        v_n_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_ERecord: {
        V v_fs_2416 = heff_field(v_e_243, 0);
        heff_take_n(v_e_243, 1ULL, 2);
        V v_t_2418 = (g_heff_2ecompile_2eir_2epushFields_24tok2(v_ru_24x3_242_24Cons, v_fs_2416, v_rest_244));
        V t_0 = v_lim_240;
        V t_1 = heff_intAdd(v_n_241, MK_INT(1LL));
        V t_2 = v_t_2418;
        v_lim_240 = t_0;
        v_n_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_EProj: {
        V v_e2_2419 = heff_field(v_e_243, 0);
        heff_take_n(v_e_243, 1ULL, 4);
        V t_0 = v_lim_240;
        V t_1 = heff_intAdd(v_n_241, MK_INT(1LL));
        V t_2 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_e2_2419, v_rest_244});
        v_lim_240 = t_0;
        v_n_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_ETag: {
        V v_args_2424 = heff_field(v_e_243, 1);
        heff_take_n(v_e_243, 2ULL, 3);
        V v_t_2426 = (g_heff_2ecompile_2eir_2eappendI_24tok2(v_ru_24x3_242_24Cons, v_args_2424, v_rest_244));
        V t_0 = v_lim_240;
        V t_1 = heff_intAdd(v_n_241, MK_INT(1LL));
        V t_2 = v_t_2426;
        v_lim_240 = t_0;
        v_n_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_EMatch: {
        V v_sc_2427 = heff_field(v_e_243, 0);
        V v_arms_2428 = heff_field(v_e_243, 1);
        heff_take_n(v_e_243, 3ULL, 2);
        V v_t_2429 = (g_heff_2ecompile_2eir_2epushArms(v_arms_2428, v_rest_244));
        V t_0 = v_lim_240;
        V t_1 = heff_intAdd(v_n_241, MK_INT(1LL));
        V t_2 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_sc_2427, v_t_2429});
        v_lim_240 = t_0;
        v_n_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_EPrim: {
        heff_take_n(v_e_243, 0ULL, 1);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        V t_0 = v_lim_240;
        V t_1 = heff_intAdd(v_n_241, MK_INT(1LL));
        V t_2 = v_rest_244;
        v_lim_240 = t_0;
        v_n_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_EPrimCall: {
        V v_args_2432 = heff_field(v_e_243, 1);
        heff_take_n(v_e_243, 2ULL, 2);
        V v_t_2433 = (g_heff_2ecompile_2eir_2eappendI_24tok2(v_ru_24x3_242_24Cons, v_args_2432, v_rest_244));
        V t_0 = v_lim_240;
        V t_1 = heff_intAdd(v_n_241, MK_INT(1LL));
        V t_2 = v_t_2433;
        v_lim_240 = t_0;
        v_n_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_ECall: {
        V v_args_2435 = heff_field(v_e_243, 1);
        heff_take_n(v_e_243, 2ULL, 2);
        V v_t_2436 = (g_heff_2ecompile_2eir_2eappendI_24tok2(v_ru_24x3_242_24Cons, v_args_2435, v_rest_244));
        V t_0 = v_lim_240;
        V t_1 = heff_intAdd(v_n_241, MK_INT(1LL));
        V t_2 = v_t_2436;
        v_lim_240 = t_0;
        v_n_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_EInt: {
        heff_take_n(v_e_243, 0ULL, 1);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        V t_0 = v_lim_240;
        V t_1 = heff_intAdd(v_n_241, MK_INT(1LL));
        V t_2 = v_rest_244;
        v_lim_240 = t_0;
        v_n_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_EFloat: {
        heff_take_na(v_e_243, 0ULL, 1);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        V t_0 = v_lim_240;
        V t_1 = heff_intAdd(v_n_241, MK_INT(1LL));
        V t_2 = v_rest_244;
        v_lim_240 = t_0;
        v_n_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_EStr: {
        heff_take_n(v_e_243, 0ULL, 1);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        V t_0 = v_lim_240;
        V t_1 = heff_intAdd(v_n_241, MK_INT(1LL));
        V t_2 = v_rest_244;
        v_lim_240 = t_0;
        v_n_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_EBytes: {
        heff_take_n(v_e_243, 0ULL, 1);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        V t_0 = v_lim_240;
        V t_1 = heff_intAdd(v_n_241, MK_INT(1LL));
        V t_2 = v_rest_244;
        v_lim_240 = t_0;
        v_n_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_EFixed: {
        heff_take_n(v_e_243, 0ULL, 2);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        V t_0 = v_lim_240;
        V t_1 = heff_intAdd(v_n_241, MK_INT(1LL));
        V t_2 = v_rest_244;
        v_lim_240 = t_0;
        v_n_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_EFloat32: {
        heff_take_na(v_e_243, 0ULL, 1);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        V t_0 = v_lim_240;
        V t_1 = heff_intAdd(v_n_241, MK_INT(1LL));
        V t_2 = v_rest_244;
        v_lim_240 = t_0;
        v_n_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_EAbandon: {
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        V t_0 = v_lim_240;
        V t_1 = heff_intAdd(v_n_241, MK_INT(1LL));
        V t_2 = v_rest_244;
        v_lim_240 = t_0;
        v_n_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_EBool: {
        V v_c_2444 = heff_field(v_e_243, 0);
        heff_take_n(v_e_243, 1ULL, 1);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        V v_t_2445 = ({ V a_0 = v_c_2444; V a_1 = v_rest_244; V r_ = (g_heff_2ecompile_2eir_2econdOnto(a_0, a_1)); heff_drop(v_c_2444); r_; });
        V t_0 = v_lim_240;
        V t_1 = heff_intAdd(v_n_241, MK_INT(1LL));
        V t_2 = v_t_2445;
        v_lim_240 = t_0;
        v_n_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_ESet: {
        V v_a_2447 = heff_field(v_e_243, 1);
        V v_b_2448 = heff_field(v_e_243, 2);
        heff_take_n(v_e_243, 6ULL, 3);
        V v_t_2449 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_a_2447, heff_tag_n(TAG_Cons, 2, (V[]){v_b_2448, v_rest_244})});
        V t_0 = v_lim_240;
        V t_1 = heff_intAdd(v_n_241, MK_INT(1LL));
        V t_2 = v_t_2449;
        v_lim_240 = t_0;
        v_n_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_EValues: {
        V v_es_2450 = heff_field(v_e_243, 0);
        heff_take_n(v_e_243, 1ULL, 1);
        V v_t_2451 = (g_heff_2ecompile_2eir_2eappendI_24tok2(v_ru_24x3_242_24Cons, v_es_2450, v_rest_244));
        V t_0 = v_lim_240;
        V t_1 = heff_intAdd(v_n_241, MK_INT(1LL));
        V t_2 = v_t_2451;
        v_lim_240 = t_0;
        v_n_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_EFix: {
        heff_take_n(v_e_243, 0ULL, 2);
        heff_drop_cell(v_ru_24x3_242_24Cons, 2);
        V t_0 = v_lim_240;
        V t_1 = heff_intAdd(v_n_241, MK_INT(1LL));
        V t_2 = v_rest_244;
        v_lim_240 = t_0;
        v_n_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      default: return heff_nomatch(v_e_243);
      }
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2eir_2esizeB_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eir_2esizeB(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2eir_2econcatMapI_24s307035317x1495364673_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2econcatMapI_24s307035317x1495364673_entry, 1, 0};

V g_heff_2ecompile_2eir_2econcatMapI_24s307035317x1495364673(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_245;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkPair: {
      V v_a_244 = heff_field(v_x_241, 1);
      v_t_245 = (g_heff_2ecompile_2eir_2eglobalsGo(heff_dup(v_a_244)));
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_t_246 = (g_heff_2ecompile_2eir_2econcatMapI_24s307035317x1495364673(v_xs_242));
    return (g_heff_2ecompile_2eir_2eappendI(v_t_245, v_t_246));
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2ecompile_2eir_2econcatMapI_24s307035317x1495364673_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eir_2econcatMapI_24s307035317x1495364673(a0); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2eir_2econcatMapI_24s439116468x354877539_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2econcatMapI_24s439116468x354877539_entry, 1, 0};

V g_heff_2ecompile_2eir_2econcatMapI_24s439116468x354877539(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_246;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkArm: {
      V v_a_245 = heff_field(v_x_241, 2);
      v_t_246 = heff_dup(v_a_245);
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_t_247 = (g_heff_2ecompile_2eir_2eglobalsGo(v_t_246));
    V v_t_248 = (g_heff_2ecompile_2eir_2econcatMapI_24s439116468x354877539(v_xs_242));
    return (g_heff_2ecompile_2eir_2eappendI(v_t_247, v_t_248));
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2ecompile_2eir_2econcatMapI_24s439116468x354877539_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eir_2econcatMapI_24s439116468x354877539(a0); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2eir_2eallI_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2eallI_entry, 1, 0};

V g_heff_2ecompile_2eir_2eallI(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_b_241 = heff_field(v_x1_240, 0);
    V v_bs_242 = heff_field(v_x1_240, 1);
    if ((heff_dup(v_b_241) == NTAG(TAG_True))) {
      V t_0 = v_bs_242;
      v_x1_240 = t_0;
      goto top;
    } else {
      return NTAG(TAG_False);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eir_2eallI_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eir_2eallI(a0); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2eir_2eisValue_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2eisValue_entry, 1, 0};

V g_heff_2ecompile_2eir_2eisValue(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_EVar: {
    return NTAG(TAG_True);
  }
  case TAG_EGlobal: {
    return NTAG(TAG_True);
  }
  case TAG_ELam: {
    return NTAG(TAG_True);
  }
  case TAG_EApp: {
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    return NTAG(TAG_False);
  }
  case TAG_ERecord: {
    V v_fs_2410 = heff_field(v_x1_240, 0);
    V v_t_2412 = (g_list_2emap_24s1044393341x1523302351(heff_dup(v_fs_2410)));
    return ({ V a_0 = v_t_2412; V r_ = (g_heff_2ecompile_2eir_2eallI(a_0)); heff_drop(v_t_2412); r_; });
  }
  case TAG_EProj: {
    return NTAG(TAG_False);
  }
  case TAG_ETag: {
    V v_args_2418 = heff_field(v_x1_240, 1);
    V v_t_2420 = (g_list_2emap_24s584454411x1006678865(heff_dup(v_args_2418)));
    return ({ V a_0 = v_t_2420; V r_ = (g_heff_2ecompile_2eir_2eallI(a_0)); heff_drop(v_t_2420); r_; });
  }
  case TAG_EMatch: {
    return NTAG(TAG_False);
  }
  case TAG_EPrim: {
    return NTAG(TAG_True);
  }
  case TAG_EPrimCall: {
    return NTAG(TAG_False);
  }
  case TAG_ECall: {
    return NTAG(TAG_False);
  }
  case TAG_EInt: {
    return NTAG(TAG_True);
  }
  case TAG_EFloat: {
    return NTAG(TAG_True);
  }
  case TAG_EStr: {
    return NTAG(TAG_True);
  }
  case TAG_EBytes: {
    return NTAG(TAG_True);
  }
  case TAG_EFixed: {
    return NTAG(TAG_True);
  }
  case TAG_EFloat32: {
    return NTAG(TAG_True);
  }
  case TAG_EAbandon: {
    return NTAG(TAG_False);
  }
  case TAG_EBool: {
    V v_c_2435 = heff_field(v_x1_240, 0);
    V v_t_2436 = (g_heff_2ecompile_2eir_2econdOnto(v_c_2435, NTAG(TAG_Nil)));
    V v_t_2437 = (g_list_2emap_24s584454411x1006678865(v_t_2436));
    return ({ V a_0 = v_t_2437; V r_ = (g_heff_2ecompile_2eir_2eallI(a_0)); heff_drop(v_t_2437); r_; });
  }
  case TAG_ESet: {
    return NTAG(TAG_False);
  }
  case TAG_EValues: {
    return NTAG(TAG_False);
  }
  case TAG_EFix: {
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eir_2eisValue_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eir_2eisValue(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ecompile_2eir_2erelPrims_str0, 6, "wordLe");
HEFF_LIT(g_heff_2ecompile_2eir_2erelPrims_str1, 6, "wordEq");
HEFF_LIT(g_heff_2ecompile_2eir_2erelPrims_str2, 6, "wordLt");
HEFF_LIT(g_heff_2ecompile_2eir_2erelPrims_str3, 6, "runeLt");
HEFF_LIT(g_heff_2ecompile_2eir_2erelPrims_str4, 6, "runeLe");
HEFF_LIT(g_heff_2ecompile_2eir_2erelPrims_str5, 5, "strLt");
HEFF_LIT(g_heff_2ecompile_2eir_2erelPrims_str6, 6, "runeEq");
HEFF_LIT(g_heff_2ecompile_2eir_2erelPrims_str7, 7, "floatLe");
HEFF_LIT(g_heff_2ecompile_2eir_2erelPrims_str8, 5, "strEq");
HEFF_LIT(g_heff_2ecompile_2eir_2erelPrims_str9, 7, "floatEq");
HEFF_LIT(g_heff_2ecompile_2eir_2erelPrims_str10, 7, "floatLt");
HEFF_LIT(g_heff_2ecompile_2eir_2erelPrims_str11, 5, "intLt");
HEFF_LIT(g_heff_2ecompile_2eir_2erelPrims_str12, 5, "intLe");
HEFF_LIT(g_heff_2ecompile_2eir_2erelPrims_str13, 5, "intEq");

static V g_heff_2ecompile_2eir_2erelPrims_val;
static HEFF_ONCE g_heff_2ecompile_2eir_2erelPrims_st;
static V g_heff_2ecompile_2eir_2erelPrims_init(void) {
  V v_t_240 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eir_2erelPrims_str0), NTAG(TAG_Nil)});
  V v_t_241 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eir_2erelPrims_str1), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eir_2erelPrims_str2), v_t_240})});
  V v_t_242 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eir_2erelPrims_str3), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eir_2erelPrims_str4), v_t_241})});
  V v_t_243 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eir_2erelPrims_str5), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eir_2erelPrims_str6), v_t_242})});
  V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eir_2erelPrims_str7), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eir_2erelPrims_str8), v_t_243})});
  V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eir_2erelPrims_str9), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eir_2erelPrims_str10), v_t_244})});
  V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eir_2erelPrims_str11), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eir_2erelPrims_str12), v_t_245})});
  return heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ecompile_2eir_2erelPrims_str13), v_t_246});
}
V g_heff_2ecompile_2eir_2erelPrims_get(void) {
  if (HEFF_DONE(g_heff_2ecompile_2eir_2erelPrims_st)) return g_heff_2ecompile_2eir_2erelPrims_val;
  return heff_global(&g_heff_2ecompile_2eir_2erelPrims_val, &g_heff_2ecompile_2eir_2erelPrims_st, g_heff_2ecompile_2eir_2erelPrims_init);
}
Clo g_heff_2ecompile_2eir_2eisRel_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2eisRel_entry, 1, 0};

V g_heff_2ecompile_2eir_2eisRel(V v_p_240) {
top: ;
  V v_t_241 = ({ V a_0 = v_p_240; V b_1 = heff_dup(g_heff_2ecompile_2eir_2erelPrims_get()); V r_ = (g_list_2eany_24s2077819594x1842428557(a_0, b_1)); heff_drop(b_1); r_; });
  if ((heff_dup(v_t_241) == NTAG(TAG_True))) {
    heff_drop(v_t_241);
    return NTAG(TAG_True);
  } else {
    heff_drop(v_t_241);
    HeffT2 v_t_242 = (g_heff_2eelab_2efixed_2efixedPrimOf_24cpr(v_p_240));
    {
      V v_field_244 = v_t_242.f[1];
      int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
      if ((v_tag_243 == ((int64_t)0ULL))) {
        V v_x_245 = v_field_244;
        V v_t_246 = heff_get_n(v_x_245, 1, 2);
        switch (heff_tag_of(v_t_246)) {
        case TAG_OpAdd: {
          return NTAG(TAG_False);
        }
        case TAG_OpSub: {
          return NTAG(TAG_False);
        }
        case TAG_OpMul: {
          return NTAG(TAG_False);
        }
        case TAG_OpDiv: {
          return NTAG(TAG_False);
        }
        case TAG_OpRem: {
          return NTAG(TAG_False);
        }
        case TAG_OpEq: {
          return NTAG(TAG_True);
        }
        case TAG_OpLt: {
          return NTAG(TAG_True);
        }
        case TAG_OpLe: {
          return NTAG(TAG_True);
        }
        case TAG_OpAnd: {
          return NTAG(TAG_False);
        }
        case TAG_OpOr: {
          return NTAG(TAG_False);
        }
        case TAG_OpXor: {
          return NTAG(TAG_False);
        }
        case TAG_OpShl: {
          return NTAG(TAG_False);
        }
        case TAG_OpShr: {
          return NTAG(TAG_False);
        }
        case TAG_OpShow: {
          return NTAG(TAG_False);
        }
        case TAG_OpFromInt: {
          return NTAG(TAG_False);
        }
        case TAG_OpToInt: {
          return NTAG(TAG_False);
        }
        case TAG_OpSqrt: {
          return NTAG(TAG_False);
        }
        case TAG_OpFromFloat: {
          return NTAG(TAG_False);
        }
        case TAG_OpToFloat: {
          return NTAG(TAG_False);
        }
        case TAG_OpFloor: {
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_t_246);
        }
      } else {
        heff_drop(v_field_244);
        return NTAG(TAG_False);
      }
    }
  }
}
V g_heff_2ecompile_2eir_2eisRel_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eir_2eisRel(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ecompile_2eir_2econdExpr_str0, 4, "True");
HEFF_LIT(g_heff_2ecompile_2eir_2econdExpr_str1, 5, "False");
HEFF_LIT(g_heff_2ecompile_2eir_2econdExpr_str2, 5, "False");
HEFF_LIT(g_heff_2ecompile_2eir_2econdExpr_str3, 4, "True");
HEFF_LIT(g_heff_2ecompile_2eir_2econdExpr_str4, 4, "True");
HEFF_LIT(g_heff_2ecompile_2eir_2econdExpr_str5, 5, "False");
HEFF_LIT(g_heff_2ecompile_2eir_2econdExpr_str6, 4, "True");
HEFF_LIT(g_heff_2ecompile_2eir_2econdExpr_str7, 5, "False");
Clo g_heff_2ecompile_2eir_2econdExpr_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2econdExpr_entry, 1, 0};

V g_heff_2ecompile_2eir_2econdExpr(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_CTrue: {
    return heff_tag_n(TAG_ETag, 3, (V[]){((V)&g_heff_2ecompile_2eir_2econdExpr_str0), NTAG(TAG_Nil), NTAG(TAG_Nil)});
  }
  case TAG_CFalse: {
    return heff_tag_n(TAG_ETag, 3, (V[]){((V)&g_heff_2ecompile_2eir_2econdExpr_str1), NTAG(TAG_Nil), NTAG(TAG_Nil)});
  }
  case TAG_CRel: {
    V v_p_241 = heff_field(v_x1_240, 0);
    V v_a_242 = heff_field(v_x1_240, 1);
    V v_b_243 = heff_field(v_x1_240, 2);
    heff_take_n(v_x1_240, 7ULL, 3);
    V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){v_b_243, NTAG(TAG_Nil)});
    return heff_tag_n(TAG_EPrimCall, 2, (V[]){v_p_241, heff_tag_n(TAG_Cons, 2, (V[]){v_a_242, v_t_244})});
  }
  case TAG_CTest: {
    V v_e_245 = heff_field(v_x1_240, 0);
    heff_take_n(v_x1_240, 1ULL, 1);
    return v_e_245;
  }
  case TAG_CNot: {
    V v_c_246 = heff_field(v_x1_240, 0);
    heff_take_n(v_x1_240, 1ULL, 1);
    V v_t_247 = (g_heff_2ecompile_2eir_2econdExpr(v_c_246));
    V v_t_248 = heff_tag_n(TAG_ETag, 3, (V[]){((V)&g_heff_2ecompile_2eir_2econdExpr_str2), NTAG(TAG_Nil), NTAG(TAG_Nil)});
    V v_t_249 = heff_tag_n(TAG_MkArm, 3, (V[]){((V)&g_heff_2ecompile_2eir_2econdExpr_str3), NTAG(TAG_Nil), v_t_248});
    V v_t_2410 = heff_tag_n(TAG_ETag, 3, (V[]){((V)&g_heff_2ecompile_2eir_2econdExpr_str4), NTAG(TAG_Nil), NTAG(TAG_Nil)});
    V v_t_2411 = heff_tag_n(TAG_MkArm, 3, (V[]){((V)&g_heff_2ecompile_2eir_2econdExpr_str5), NTAG(TAG_Nil), v_t_2410});
    V v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2411, NTAG(TAG_Nil)});
    return heff_tag_n(TAG_EMatch, 2, (V[]){v_t_247, heff_tag_n(TAG_Cons, 2, (V[]){v_t_249, v_t_2412})});
  }
  case TAG_CIf: {
    V v_a_2413 = heff_field(v_x1_240, 0);
    V v_b_2414 = heff_field(v_x1_240, 1);
    V v_c_2415 = heff_field(v_x1_240, 2);
    V v_ru_24x1_240_24CIf = heff_take_reuse_n(v_x1_240, 7ULL, 3);
    V v_t_2416 = (g_heff_2ecompile_2eir_2econdExpr(v_a_2413));
    V v_t_2417 = (g_heff_2ecompile_2eir_2econdExpr(v_b_2414));
    V v_f_2418 = (g_heff_2ecompile_2eir_2econdExpr(v_c_2415));
    V v_t_2419 = heff_tag_at_n(v_ru_24x1_240_24CIf, TAG_MkArm, 3, (V[]){((V)&g_heff_2ecompile_2eir_2econdExpr_str6), NTAG(TAG_Nil), v_t_2417});
    V v_t_2420 = heff_tag_n(TAG_MkArm, 3, (V[]){((V)&g_heff_2ecompile_2eir_2econdExpr_str7), NTAG(TAG_Nil), v_f_2418});
    V v_t_2421 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2420, NTAG(TAG_Nil)});
    return heff_tag_n(TAG_EMatch, 2, (V[]){v_t_2416, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2419, v_t_2421})});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eir_2econdExpr_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eir_2econdExpr(a[0]);
}
V g_heff_2ecompile_2eir_2econdTraverse_24s792224752x124814130_lam0(V self, V *args); static Clo g_heff_2ecompile_2eir_2econdTraverse_24s792224752x124814130_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2econdTraverse_24s792224752x124814130_lam0, 1, 0};
V g_heff_2ecompile_2eir_2econdTraverse_24s792224752x124814130_lam1(V self, V *args); static Clo g_heff_2ecompile_2eir_2econdTraverse_24s792224752x124814130_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2econdTraverse_24s792224752x124814130_lam1, 1, 0};
V g_heff_2ecompile_2eir_2econdTraverse_24s792224752x124814130_lam2(V self, V *args);
V g_heff_2ecompile_2eir_2econdTraverse_24s792224752x124814130_lam3(V self, V *args);
V g_heff_2ecompile_2eir_2econdTraverse_24s792224752x124814130_lam4(V self, V *args);
V g_heff_2ecompile_2eir_2econdTraverse_24s792224752x124814130_lam5(V self, V *args);
Clo g_heff_2ecompile_2eir_2econdTraverse_24s792224752x124814130_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2econdTraverse_24s792224752x124814130_entry, 2, 0};

V g_heff_2ecompile_2eir_2econdTraverse_24s792224752x124814130(V v_f_240, V v_x2_27_241) {
top: ;
  switch (heff_tag_of(v_x2_27_241)) {
  case TAG_CTrue: {
    heff_drop(v_f_240);
    return ((V)&g_heff_2ecompile_2eir_2econdTraverse_24s792224752x124814130_lam0_clo);
  }
  case TAG_CFalse: {
    heff_drop(v_f_240);
    return ((V)&g_heff_2ecompile_2eir_2econdTraverse_24s792224752x124814130_lam1_clo);
  }
  case TAG_CRel: {
    V v_p_244 = heff_field(v_x2_27_241, 0);
    V v_x_245 = heff_field(v_x2_27_241, 1);
    V v_y_246 = heff_field(v_x2_27_241, 2);
    heff_take_n(v_x2_27_241, 7ULL, 3);
    V v_m_247 = heff_tr(heff_call(heff_dup(v_f_240), 1, (V[]){v_x_245}));
    return heff_clo_n(g_heff_2ecompile_2eir_2econdTraverse_24s792224752x124814130_lam2, 1, 4, (V[]){v_m_247, v_f_240, v_y_246, v_p_244});
  }
  case TAG_CTest: {
    V v_x_2416 = heff_field(v_x2_27_241, 0);
    heff_take_n(v_x2_27_241, 1ULL, 1);
    V v_m_2417 = heff_tr(heff_call(v_f_240, 1, (V[]){v_x_2416}));
    return heff_clo_n(g_heff_2ecompile_2eir_2econdTraverse_24s792224752x124814130_lam3, 1, 1, (V[]){v_m_2417});
  }
  case TAG_CNot: {
    V v_c_2422 = heff_field(v_x2_27_241, 0);
    heff_take_n(v_x2_27_241, 1ULL, 1);
    V v_m_2423 = (g_heff_2ecompile_2eir_2econdTraverse_24s792224752x124814130(v_f_240, v_c_2422));
    return heff_clo_n(g_heff_2ecompile_2eir_2econdTraverse_24s792224752x124814130_lam4, 1, 1, (V[]){v_m_2423});
  }
  case TAG_CIf: {
    V v_a_2428 = heff_field(v_x2_27_241, 0);
    V v_b_2429 = heff_field(v_x2_27_241, 1);
    V v_c_2430 = heff_field(v_x2_27_241, 2);
    heff_take_n(v_x2_27_241, 7ULL, 3);
    V v_m_2431 = (g_heff_2ecompile_2eir_2econdTraverse_24s792224752x124814130(heff_dup(v_f_240), v_a_2428));
    return heff_clo_n(g_heff_2ecompile_2eir_2econdTraverse_24s792224752x124814130_lam5, 1, 4, (V[]){v_m_2431, v_f_240, v_b_2429, v_c_2430});
  }
  default: return heff_nomatch(v_x2_27_241);
  }
}
V g_heff_2ecompile_2eir_2econdTraverse_24s792224752x124814130_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eir_2econdTraverse_24s792224752x124814130(a[0], a[1]);
}
V g_heff_2ecompile_2eir_2econdTraverse_24s792224752x124814130_lam0(V self, V *args) {
  V v_s_242 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_CTrue), v_s_242});
}
V g_heff_2ecompile_2eir_2econdTraverse_24s792224752x124814130_lam1(V self, V *args) {
  V v_s_243 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_CFalse), v_s_243});
}
V g_heff_2ecompile_2eir_2econdTraverse_24s792224752x124814130_lam2(V self, V *args) {
  V v_s_248 = args[0];
  V v_m_247 = heff_env(self)[0];
  V v_f_240 = heff_env(self)[1];
  V v_y_246 = heff_env(self)[2];
  V v_p_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_249 = heff_tr(heff_call(v_m_247, 1, (V[]){v_s_248}));
  switch (heff_tag_of(v_x2_249)) {
  case TAG_MkPair: {
    V v_x_2410 = heff_field(v_x2_249, 0);
    V v_s_2411 = heff_field(v_x2_249, 1);
    V v_ru_24x2_249_24MkPair = heff_take_reuse_n(v_x2_249, 3ULL, 2);
    V v_m_2412 = heff_tr(heff_call(v_f_240, 1, (V[]){v_y_246}));
    V v_x2_2413 = heff_tr(heff_call(v_m_2412, 1, (V[]){v_s_2411}));
    switch (heff_tag_of(v_x2_2413)) {
    case TAG_MkPair: {
      V v_x_2414 = heff_field(v_x2_2413, 0);
      V v_s_2415 = heff_field(v_x2_2413, 1);
      heff_take_n(v_x2_2413, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_249_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_CRel, 3, (V[]){v_p_244, v_x_2410, v_x_2414}), v_s_2415});
    }
    default: return heff_nomatch(v_x2_2413);
    }
  }
  default: return heff_nomatch(v_x2_249);
  }
}
V g_heff_2ecompile_2eir_2econdTraverse_24s792224752x124814130_lam3(V self, V *args) {
  V v_s_2418 = args[0];
  V v_m_2417 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_2419 = heff_tr(heff_call(v_m_2417, 1, (V[]){v_s_2418}));
  switch (heff_tag_of(v_x2_2419)) {
  case TAG_MkPair: {
    V v_x_2420 = heff_field(v_x2_2419, 0);
    V v_s_2421 = heff_field(v_x2_2419, 1);
    V v_ru_24x2_2419_24MkPair = heff_take_reuse_n(v_x2_2419, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2419_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_CTest, 1, (V[]){v_x_2420}), v_s_2421});
  }
  default: return heff_nomatch(v_x2_2419);
  }
}
V g_heff_2ecompile_2eir_2econdTraverse_24s792224752x124814130_lam4(V self, V *args) {
  V v_s_2424 = args[0];
  V v_m_2423 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_2425 = heff_tr(heff_call(v_m_2423, 1, (V[]){v_s_2424}));
  switch (heff_tag_of(v_x2_2425)) {
  case TAG_MkPair: {
    V v_x_2426 = heff_field(v_x2_2425, 0);
    V v_s_2427 = heff_field(v_x2_2425, 1);
    V v_ru_24x2_2425_24MkPair = heff_take_reuse_n(v_x2_2425, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2425_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_CNot, 1, (V[]){v_x_2426}), v_s_2427});
  }
  default: return heff_nomatch(v_x2_2425);
  }
}
V g_heff_2ecompile_2eir_2econdTraverse_24s792224752x124814130_lam5(V self, V *args) {
  V v_s_2432 = args[0];
  V v_m_2431 = heff_env(self)[0];
  V v_f_240 = heff_env(self)[1];
  V v_b_2429 = heff_env(self)[2];
  V v_c_2430 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2433 = heff_tr(heff_call(v_m_2431, 1, (V[]){v_s_2432}));
  switch (heff_tag_of(v_x2_2433)) {
  case TAG_MkPair: {
    V v_x_2434 = heff_field(v_x2_2433, 0);
    V v_s_2435 = heff_field(v_x2_2433, 1);
    V v_ru_24x2_2433_24MkPair = heff_take_reuse_n(v_x2_2433, 3ULL, 2);
    V v_m_2436 = (g_heff_2ecompile_2eir_2econdTraverse_24s792224752x124814130(heff_dup(v_f_240), v_b_2429));
    V v_x2_2437 = heff_tr(heff_call(v_m_2436, 1, (V[]){v_s_2435}));
    switch (heff_tag_of(v_x2_2437)) {
    case TAG_MkPair: {
      V v_x_2438 = heff_field(v_x2_2437, 0);
      V v_s_2439 = heff_field(v_x2_2437, 1);
      heff_take_n(v_x2_2437, 3ULL, 2);
      V v_m_2440 = (g_heff_2ecompile_2eir_2econdTraverse_24s792224752x124814130(v_f_240, v_c_2430));
      V v_x2_2441 = heff_tr(heff_call(v_m_2440, 1, (V[]){v_s_2439}));
      switch (heff_tag_of(v_x2_2441)) {
      case TAG_MkPair: {
        V v_x_2442 = heff_field(v_x2_2441, 0);
        V v_s_2443 = heff_field(v_x2_2441, 1);
        heff_take_n(v_x2_2441, 3ULL, 2);
        return heff_tag_at_n(v_ru_24x2_2433_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_CIf, 3, (V[]){v_x_2434, v_x_2438, v_x_2442}), v_s_2443});
      }
      default: return heff_nomatch(v_x2_2441);
      }
    }
    default: return heff_nomatch(v_x2_2437);
    }
  }
  default: return heff_nomatch(v_x2_2433);
  }
}
V g_heff_2ecompile_2eir_2econdTraverse_24s2104458127x1504356407_lam0(V self, V *args); static Clo g_heff_2ecompile_2eir_2econdTraverse_24s2104458127x1504356407_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2econdTraverse_24s2104458127x1504356407_lam0, 1, 0};
V g_heff_2ecompile_2eir_2econdTraverse_24s2104458127x1504356407_lam1(V self, V *args); static Clo g_heff_2ecompile_2eir_2econdTraverse_24s2104458127x1504356407_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2econdTraverse_24s2104458127x1504356407_lam1, 1, 0};
V g_heff_2ecompile_2eir_2econdTraverse_24s2104458127x1504356407_lam2(V self, V *args);
V g_heff_2ecompile_2eir_2econdTraverse_24s2104458127x1504356407_lam3(V self, V *args);
V g_heff_2ecompile_2eir_2econdTraverse_24s2104458127x1504356407_lam4(V self, V *args);
V g_heff_2ecompile_2eir_2econdTraverse_24s2104458127x1504356407_lam5(V self, V *args);
Clo g_heff_2ecompile_2eir_2econdTraverse_24s2104458127x1504356407_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2econdTraverse_24s2104458127x1504356407_entry, 2, 0};

V g_heff_2ecompile_2eir_2econdTraverse_24s2104458127x1504356407(V v_f_240, V v_x2_27_241) {
top: ;
  switch (heff_tag_of(v_x2_27_241)) {
  case TAG_CTrue: {
    heff_drop(v_f_240);
    return ((V)&g_heff_2ecompile_2eir_2econdTraverse_24s2104458127x1504356407_lam0_clo);
  }
  case TAG_CFalse: {
    heff_drop(v_f_240);
    return ((V)&g_heff_2ecompile_2eir_2econdTraverse_24s2104458127x1504356407_lam1_clo);
  }
  case TAG_CRel: {
    V v_p_244 = heff_field(v_x2_27_241, 0);
    V v_x_245 = heff_field(v_x2_27_241, 1);
    V v_y_246 = heff_field(v_x2_27_241, 2);
    heff_take_n(v_x2_27_241, 7ULL, 3);
    V v_m_247 = heff_tr(heff_call(heff_dup(v_f_240), 1, (V[]){v_x_245}));
    return heff_clo_n(g_heff_2ecompile_2eir_2econdTraverse_24s2104458127x1504356407_lam2, 1, 4, (V[]){v_m_247, v_f_240, v_y_246, v_p_244});
  }
  case TAG_CTest: {
    V v_x_2416 = heff_field(v_x2_27_241, 0);
    heff_take_n(v_x2_27_241, 1ULL, 1);
    V v_m_2417 = heff_tr(heff_call(v_f_240, 1, (V[]){v_x_2416}));
    return heff_clo_n(g_heff_2ecompile_2eir_2econdTraverse_24s2104458127x1504356407_lam3, 1, 1, (V[]){v_m_2417});
  }
  case TAG_CNot: {
    V v_c_2422 = heff_field(v_x2_27_241, 0);
    heff_take_n(v_x2_27_241, 1ULL, 1);
    V v_m_2423 = (g_heff_2ecompile_2eir_2econdTraverse_24s2104458127x1504356407(v_f_240, v_c_2422));
    return heff_clo_n(g_heff_2ecompile_2eir_2econdTraverse_24s2104458127x1504356407_lam4, 1, 1, (V[]){v_m_2423});
  }
  case TAG_CIf: {
    V v_a_2428 = heff_field(v_x2_27_241, 0);
    V v_b_2429 = heff_field(v_x2_27_241, 1);
    V v_c_2430 = heff_field(v_x2_27_241, 2);
    heff_take_n(v_x2_27_241, 7ULL, 3);
    V v_m_2431 = (g_heff_2ecompile_2eir_2econdTraverse_24s2104458127x1504356407(heff_dup(v_f_240), v_a_2428));
    return heff_clo_n(g_heff_2ecompile_2eir_2econdTraverse_24s2104458127x1504356407_lam5, 1, 4, (V[]){v_m_2431, v_f_240, v_b_2429, v_c_2430});
  }
  default: return heff_nomatch(v_x2_27_241);
  }
}
V g_heff_2ecompile_2eir_2econdTraverse_24s2104458127x1504356407_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eir_2econdTraverse_24s2104458127x1504356407(a[0], a[1]);
}
V g_heff_2ecompile_2eir_2econdTraverse_24s2104458127x1504356407_lam0(V self, V *args) {
  V v_n_242 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_CTrue), v_n_242});
}
V g_heff_2ecompile_2eir_2econdTraverse_24s2104458127x1504356407_lam1(V self, V *args) {
  V v_n_243 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_CFalse), v_n_243});
}
V g_heff_2ecompile_2eir_2econdTraverse_24s2104458127x1504356407_lam2(V self, V *args) {
  V v_n_248 = args[0];
  V v_m_247 = heff_env(self)[0];
  V v_f_240 = heff_env(self)[1];
  V v_y_246 = heff_env(self)[2];
  V v_p_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_249 = heff_tr(heff_call(v_m_247, 1, (V[]){v_n_248}));
  switch (heff_tag_of(v_x2_249)) {
  case TAG_MkPair: {
    V v_x_2410 = heff_field(v_x2_249, 0);
    V v_n_2411 = heff_field(v_x2_249, 1);
    V v_ru_24x2_249_24MkPair = heff_take_reuse_n(v_x2_249, 3ULL, 2);
    V v_m_2412 = heff_tr(heff_call(v_f_240, 1, (V[]){v_y_246}));
    V v_x2_2413 = heff_tr(heff_call(v_m_2412, 1, (V[]){v_n_2411}));
    switch (heff_tag_of(v_x2_2413)) {
    case TAG_MkPair: {
      V v_x_2414 = heff_field(v_x2_2413, 0);
      V v_n_2415 = heff_field(v_x2_2413, 1);
      heff_take_n(v_x2_2413, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_249_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_CRel, 3, (V[]){v_p_244, v_x_2410, v_x_2414}), v_n_2415});
    }
    default: return heff_nomatch(v_x2_2413);
    }
  }
  default: return heff_nomatch(v_x2_249);
  }
}
V g_heff_2ecompile_2eir_2econdTraverse_24s2104458127x1504356407_lam3(V self, V *args) {
  V v_n_2418 = args[0];
  V v_m_2417 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_2419 = heff_tr(heff_call(v_m_2417, 1, (V[]){v_n_2418}));
  switch (heff_tag_of(v_x2_2419)) {
  case TAG_MkPair: {
    V v_x_2420 = heff_field(v_x2_2419, 0);
    V v_n_2421 = heff_field(v_x2_2419, 1);
    V v_ru_24x2_2419_24MkPair = heff_take_reuse_n(v_x2_2419, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2419_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_CTest, 1, (V[]){v_x_2420}), v_n_2421});
  }
  default: return heff_nomatch(v_x2_2419);
  }
}
V g_heff_2ecompile_2eir_2econdTraverse_24s2104458127x1504356407_lam4(V self, V *args) {
  V v_n_2424 = args[0];
  V v_m_2423 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_2425 = heff_tr(heff_call(v_m_2423, 1, (V[]){v_n_2424}));
  switch (heff_tag_of(v_x2_2425)) {
  case TAG_MkPair: {
    V v_x_2426 = heff_field(v_x2_2425, 0);
    V v_n_2427 = heff_field(v_x2_2425, 1);
    V v_ru_24x2_2425_24MkPair = heff_take_reuse_n(v_x2_2425, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2425_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_CNot, 1, (V[]){v_x_2426}), v_n_2427});
  }
  default: return heff_nomatch(v_x2_2425);
  }
}
V g_heff_2ecompile_2eir_2econdTraverse_24s2104458127x1504356407_lam5(V self, V *args) {
  V v_n_2432 = args[0];
  V v_m_2431 = heff_env(self)[0];
  V v_f_240 = heff_env(self)[1];
  V v_b_2429 = heff_env(self)[2];
  V v_c_2430 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2433 = heff_tr(heff_call(v_m_2431, 1, (V[]){v_n_2432}));
  switch (heff_tag_of(v_x2_2433)) {
  case TAG_MkPair: {
    V v_x_2434 = heff_field(v_x2_2433, 0);
    V v_n_2435 = heff_field(v_x2_2433, 1);
    V v_ru_24x2_2433_24MkPair = heff_take_reuse_n(v_x2_2433, 3ULL, 2);
    V v_m_2436 = (g_heff_2ecompile_2eir_2econdTraverse_24s2104458127x1504356407(heff_dup(v_f_240), v_b_2429));
    V v_x2_2437 = heff_tr(heff_call(v_m_2436, 1, (V[]){v_n_2435}));
    switch (heff_tag_of(v_x2_2437)) {
    case TAG_MkPair: {
      V v_x_2438 = heff_field(v_x2_2437, 0);
      V v_n_2439 = heff_field(v_x2_2437, 1);
      heff_take_n(v_x2_2437, 3ULL, 2);
      V v_m_2440 = (g_heff_2ecompile_2eir_2econdTraverse_24s2104458127x1504356407(v_f_240, v_c_2430));
      V v_x2_2441 = heff_tr(heff_call(v_m_2440, 1, (V[]){v_n_2439}));
      switch (heff_tag_of(v_x2_2441)) {
      case TAG_MkPair: {
        V v_x_2442 = heff_field(v_x2_2441, 0);
        V v_n_2443 = heff_field(v_x2_2441, 1);
        heff_take_n(v_x2_2441, 3ULL, 2);
        return heff_tag_at_n(v_ru_24x2_2433_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_CIf, 3, (V[]){v_x_2434, v_x_2438, v_x_2442}), v_n_2443});
      }
      default: return heff_nomatch(v_x2_2441);
      }
    }
    default: return heff_nomatch(v_x2_2437);
    }
  }
  default: return heff_nomatch(v_x2_2433);
  }
}
V g_heff_2ecompile_2eir_2econdTraverse_24s1144524526x881445050_lam0(V self, V *args); static Clo g_heff_2ecompile_2eir_2econdTraverse_24s1144524526x881445050_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2econdTraverse_24s1144524526x881445050_lam0, 1, 0};
V g_heff_2ecompile_2eir_2econdTraverse_24s1144524526x881445050_lam1(V self, V *args); static Clo g_heff_2ecompile_2eir_2econdTraverse_24s1144524526x881445050_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2econdTraverse_24s1144524526x881445050_lam1, 1, 0};
V g_heff_2ecompile_2eir_2econdTraverse_24s1144524526x881445050_lam2(V self, V *args);
V g_heff_2ecompile_2eir_2econdTraverse_24s1144524526x881445050_lam3(V self, V *args);
V g_heff_2ecompile_2eir_2econdTraverse_24s1144524526x881445050_lam4(V self, V *args);
V g_heff_2ecompile_2eir_2econdTraverse_24s1144524526x881445050_lam5(V self, V *args);
Clo g_heff_2ecompile_2eir_2econdTraverse_24s1144524526x881445050_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2econdTraverse_24s1144524526x881445050_entry, 2, 0};

V g_heff_2ecompile_2eir_2econdTraverse_24s1144524526x881445050(V v_f_240, V v_x2_27_241) {
top: ;
  switch (heff_tag_of(v_x2_27_241)) {
  case TAG_CTrue: {
    heff_drop(v_f_240);
    return ((V)&g_heff_2ecompile_2eir_2econdTraverse_24s1144524526x881445050_lam0_clo);
  }
  case TAG_CFalse: {
    heff_drop(v_f_240);
    return ((V)&g_heff_2ecompile_2eir_2econdTraverse_24s1144524526x881445050_lam1_clo);
  }
  case TAG_CRel: {
    V v_p_244 = heff_field(v_x2_27_241, 0);
    V v_x_245 = heff_field(v_x2_27_241, 1);
    V v_y_246 = heff_field(v_x2_27_241, 2);
    heff_take_n(v_x2_27_241, 7ULL, 3);
    V v_m_247 = heff_tr(heff_call(heff_dup(v_f_240), 1, (V[]){v_x_245}));
    return heff_clo_n(g_heff_2ecompile_2eir_2econdTraverse_24s1144524526x881445050_lam2, 1, 4, (V[]){v_m_247, v_f_240, v_y_246, v_p_244});
  }
  case TAG_CTest: {
    V v_x_2416 = heff_field(v_x2_27_241, 0);
    heff_take_n(v_x2_27_241, 1ULL, 1);
    V v_m_2417 = heff_tr(heff_call(v_f_240, 1, (V[]){v_x_2416}));
    return heff_clo_n(g_heff_2ecompile_2eir_2econdTraverse_24s1144524526x881445050_lam3, 1, 1, (V[]){v_m_2417});
  }
  case TAG_CNot: {
    V v_c_2422 = heff_field(v_x2_27_241, 0);
    heff_take_n(v_x2_27_241, 1ULL, 1);
    V v_m_2423 = (g_heff_2ecompile_2eir_2econdTraverse_24s1144524526x881445050(v_f_240, v_c_2422));
    return heff_clo_n(g_heff_2ecompile_2eir_2econdTraverse_24s1144524526x881445050_lam4, 1, 1, (V[]){v_m_2423});
  }
  case TAG_CIf: {
    V v_a_2428 = heff_field(v_x2_27_241, 0);
    V v_b_2429 = heff_field(v_x2_27_241, 1);
    V v_c_2430 = heff_field(v_x2_27_241, 2);
    heff_take_n(v_x2_27_241, 7ULL, 3);
    V v_m_2431 = (g_heff_2ecompile_2eir_2econdTraverse_24s1144524526x881445050(heff_dup(v_f_240), v_a_2428));
    return heff_clo_n(g_heff_2ecompile_2eir_2econdTraverse_24s1144524526x881445050_lam5, 1, 4, (V[]){v_m_2431, v_f_240, v_b_2429, v_c_2430});
  }
  default: return heff_nomatch(v_x2_27_241);
  }
}
V g_heff_2ecompile_2eir_2econdTraverse_24s1144524526x881445050_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eir_2econdTraverse_24s1144524526x881445050(a[0], a[1]);
}
V g_heff_2ecompile_2eir_2econdTraverse_24s1144524526x881445050_lam0(V self, V *args) {
  V v_n_242 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_CTrue), v_n_242});
}
V g_heff_2ecompile_2eir_2econdTraverse_24s1144524526x881445050_lam1(V self, V *args) {
  V v_n_243 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_CFalse), v_n_243});
}
V g_heff_2ecompile_2eir_2econdTraverse_24s1144524526x881445050_lam2(V self, V *args) {
  V v_n_248 = args[0];
  V v_m_247 = heff_env(self)[0];
  V v_f_240 = heff_env(self)[1];
  V v_y_246 = heff_env(self)[2];
  V v_p_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_249 = heff_tr(heff_call(v_m_247, 1, (V[]){v_n_248}));
  switch (heff_tag_of(v_x2_249)) {
  case TAG_MkPair: {
    V v_x_2410 = heff_field(v_x2_249, 0);
    V v_n_2411 = heff_field(v_x2_249, 1);
    V v_ru_24x2_249_24MkPair = heff_take_reuse_n(v_x2_249, 3ULL, 2);
    V v_m_2412 = heff_tr(heff_call(v_f_240, 1, (V[]){v_y_246}));
    V v_x2_2413 = heff_tr(heff_call(v_m_2412, 1, (V[]){v_n_2411}));
    switch (heff_tag_of(v_x2_2413)) {
    case TAG_MkPair: {
      V v_x_2414 = heff_field(v_x2_2413, 0);
      V v_n_2415 = heff_field(v_x2_2413, 1);
      heff_take_n(v_x2_2413, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_249_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_CRel, 3, (V[]){v_p_244, v_x_2410, v_x_2414}), v_n_2415});
    }
    default: return heff_nomatch(v_x2_2413);
    }
  }
  default: return heff_nomatch(v_x2_249);
  }
}
V g_heff_2ecompile_2eir_2econdTraverse_24s1144524526x881445050_lam3(V self, V *args) {
  V v_n_2418 = args[0];
  V v_m_2417 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_2419 = heff_tr(heff_call(v_m_2417, 1, (V[]){v_n_2418}));
  switch (heff_tag_of(v_x2_2419)) {
  case TAG_MkPair: {
    V v_x_2420 = heff_field(v_x2_2419, 0);
    V v_n_2421 = heff_field(v_x2_2419, 1);
    V v_ru_24x2_2419_24MkPair = heff_take_reuse_n(v_x2_2419, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2419_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_CTest, 1, (V[]){v_x_2420}), v_n_2421});
  }
  default: return heff_nomatch(v_x2_2419);
  }
}
V g_heff_2ecompile_2eir_2econdTraverse_24s1144524526x881445050_lam4(V self, V *args) {
  V v_n_2424 = args[0];
  V v_m_2423 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_2425 = heff_tr(heff_call(v_m_2423, 1, (V[]){v_n_2424}));
  switch (heff_tag_of(v_x2_2425)) {
  case TAG_MkPair: {
    V v_x_2426 = heff_field(v_x2_2425, 0);
    V v_n_2427 = heff_field(v_x2_2425, 1);
    V v_ru_24x2_2425_24MkPair = heff_take_reuse_n(v_x2_2425, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2425_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_CNot, 1, (V[]){v_x_2426}), v_n_2427});
  }
  default: return heff_nomatch(v_x2_2425);
  }
}
V g_heff_2ecompile_2eir_2econdTraverse_24s1144524526x881445050_lam5(V self, V *args) {
  V v_n_2432 = args[0];
  V v_m_2431 = heff_env(self)[0];
  V v_f_240 = heff_env(self)[1];
  V v_b_2429 = heff_env(self)[2];
  V v_c_2430 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2433 = heff_tr(heff_call(v_m_2431, 1, (V[]){v_n_2432}));
  switch (heff_tag_of(v_x2_2433)) {
  case TAG_MkPair: {
    V v_x_2434 = heff_field(v_x2_2433, 0);
    V v_n_2435 = heff_field(v_x2_2433, 1);
    V v_ru_24x2_2433_24MkPair = heff_take_reuse_n(v_x2_2433, 3ULL, 2);
    V v_m_2436 = (g_heff_2ecompile_2eir_2econdTraverse_24s1144524526x881445050(heff_dup(v_f_240), v_b_2429));
    V v_x2_2437 = heff_tr(heff_call(v_m_2436, 1, (V[]){v_n_2435}));
    switch (heff_tag_of(v_x2_2437)) {
    case TAG_MkPair: {
      V v_x_2438 = heff_field(v_x2_2437, 0);
      V v_n_2439 = heff_field(v_x2_2437, 1);
      heff_take_n(v_x2_2437, 3ULL, 2);
      V v_m_2440 = (g_heff_2ecompile_2eir_2econdTraverse_24s1144524526x881445050(v_f_240, v_c_2430));
      V v_x2_2441 = heff_tr(heff_call(v_m_2440, 1, (V[]){v_n_2439}));
      switch (heff_tag_of(v_x2_2441)) {
      case TAG_MkPair: {
        V v_x_2442 = heff_field(v_x2_2441, 0);
        V v_n_2443 = heff_field(v_x2_2441, 1);
        heff_take_n(v_x2_2441, 3ULL, 2);
        return heff_tag_at_n(v_ru_24x2_2433_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_CIf, 3, (V[]){v_x_2434, v_x_2438, v_x_2442}), v_n_2443});
      }
      default: return heff_nomatch(v_x2_2441);
      }
    }
    default: return heff_nomatch(v_x2_2437);
    }
  }
  default: return heff_nomatch(v_x2_2433);
  }
}
V g_heff_2ecompile_2eir_2econdTraverse_24s378097287x400807650_lam0(V self, V *args); static Clo g_heff_2ecompile_2eir_2econdTraverse_24s378097287x400807650_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2econdTraverse_24s378097287x400807650_lam0, 1, 0};
V g_heff_2ecompile_2eir_2econdTraverse_24s378097287x400807650_lam1(V self, V *args); static Clo g_heff_2ecompile_2eir_2econdTraverse_24s378097287x400807650_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2econdTraverse_24s378097287x400807650_lam1, 1, 0};
V g_heff_2ecompile_2eir_2econdTraverse_24s378097287x400807650_lam2(V self, V *args);
V g_heff_2ecompile_2eir_2econdTraverse_24s378097287x400807650_lam3(V self, V *args);
V g_heff_2ecompile_2eir_2econdTraverse_24s378097287x400807650_lam4(V self, V *args);
V g_heff_2ecompile_2eir_2econdTraverse_24s378097287x400807650_lam5(V self, V *args);
Clo g_heff_2ecompile_2eir_2econdTraverse_24s378097287x400807650_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eir_2econdTraverse_24s378097287x400807650_entry, 2, 0};

V g_heff_2ecompile_2eir_2econdTraverse_24s378097287x400807650(V v_f_240, V v_x2_27_241) {
top: ;
  switch (heff_tag_of(v_x2_27_241)) {
  case TAG_CTrue: {
    heff_drop(v_f_240);
    return ((V)&g_heff_2ecompile_2eir_2econdTraverse_24s378097287x400807650_lam0_clo);
  }
  case TAG_CFalse: {
    heff_drop(v_f_240);
    return ((V)&g_heff_2ecompile_2eir_2econdTraverse_24s378097287x400807650_lam1_clo);
  }
  case TAG_CRel: {
    V v_p_244 = heff_field(v_x2_27_241, 0);
    V v_x_245 = heff_field(v_x2_27_241, 1);
    V v_y_246 = heff_field(v_x2_27_241, 2);
    heff_take_n(v_x2_27_241, 7ULL, 3);
    V v_m_247 = heff_tr(heff_call(heff_dup(v_f_240), 1, (V[]){v_x_245}));
    return heff_clo_n(g_heff_2ecompile_2eir_2econdTraverse_24s378097287x400807650_lam2, 1, 4, (V[]){v_m_247, v_f_240, v_y_246, v_p_244});
  }
  case TAG_CTest: {
    V v_x_2416 = heff_field(v_x2_27_241, 0);
    heff_take_n(v_x2_27_241, 1ULL, 1);
    V v_m_2417 = heff_tr(heff_call(v_f_240, 1, (V[]){v_x_2416}));
    return heff_clo_n(g_heff_2ecompile_2eir_2econdTraverse_24s378097287x400807650_lam3, 1, 1, (V[]){v_m_2417});
  }
  case TAG_CNot: {
    V v_c_2422 = heff_field(v_x2_27_241, 0);
    heff_take_n(v_x2_27_241, 1ULL, 1);
    V v_m_2423 = (g_heff_2ecompile_2eir_2econdTraverse_24s378097287x400807650(v_f_240, v_c_2422));
    return heff_clo_n(g_heff_2ecompile_2eir_2econdTraverse_24s378097287x400807650_lam4, 1, 1, (V[]){v_m_2423});
  }
  case TAG_CIf: {
    V v_a_2428 = heff_field(v_x2_27_241, 0);
    V v_b_2429 = heff_field(v_x2_27_241, 1);
    V v_c_2430 = heff_field(v_x2_27_241, 2);
    heff_take_n(v_x2_27_241, 7ULL, 3);
    V v_m_2431 = (g_heff_2ecompile_2eir_2econdTraverse_24s378097287x400807650(heff_dup(v_f_240), v_a_2428));
    return heff_clo_n(g_heff_2ecompile_2eir_2econdTraverse_24s378097287x400807650_lam5, 1, 4, (V[]){v_m_2431, v_f_240, v_b_2429, v_c_2430});
  }
  default: return heff_nomatch(v_x2_27_241);
  }
}
V g_heff_2ecompile_2eir_2econdTraverse_24s378097287x400807650_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eir_2econdTraverse_24s378097287x400807650(a[0], a[1]);
}
V g_heff_2ecompile_2eir_2econdTraverse_24s378097287x400807650_lam0(V self, V *args) {
  V v_n_242 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_CTrue), v_n_242});
}
V g_heff_2ecompile_2eir_2econdTraverse_24s378097287x400807650_lam1(V self, V *args) {
  V v_n_243 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_CFalse), v_n_243});
}
V g_heff_2ecompile_2eir_2econdTraverse_24s378097287x400807650_lam2(V self, V *args) {
  V v_n_248 = args[0];
  V v_m_247 = heff_env(self)[0];
  V v_f_240 = heff_env(self)[1];
  V v_y_246 = heff_env(self)[2];
  V v_p_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_249 = heff_tr(heff_call(v_m_247, 1, (V[]){v_n_248}));
  switch (heff_tag_of(v_x2_249)) {
  case TAG_MkPair: {
    V v_x_2410 = heff_field(v_x2_249, 0);
    V v_n_2411 = heff_field(v_x2_249, 1);
    V v_ru_24x2_249_24MkPair = heff_take_reuse_n(v_x2_249, 3ULL, 2);
    V v_m_2412 = heff_tr(heff_call(v_f_240, 1, (V[]){v_y_246}));
    V v_x2_2413 = heff_tr(heff_call(v_m_2412, 1, (V[]){v_n_2411}));
    switch (heff_tag_of(v_x2_2413)) {
    case TAG_MkPair: {
      V v_x_2414 = heff_field(v_x2_2413, 0);
      V v_n_2415 = heff_field(v_x2_2413, 1);
      heff_take_n(v_x2_2413, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_249_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_CRel, 3, (V[]){v_p_244, v_x_2410, v_x_2414}), v_n_2415});
    }
    default: return heff_nomatch(v_x2_2413);
    }
  }
  default: return heff_nomatch(v_x2_249);
  }
}
V g_heff_2ecompile_2eir_2econdTraverse_24s378097287x400807650_lam3(V self, V *args) {
  V v_n_2418 = args[0];
  V v_m_2417 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_2419 = heff_tr(heff_call(v_m_2417, 1, (V[]){v_n_2418}));
  switch (heff_tag_of(v_x2_2419)) {
  case TAG_MkPair: {
    V v_x_2420 = heff_field(v_x2_2419, 0);
    V v_n_2421 = heff_field(v_x2_2419, 1);
    V v_ru_24x2_2419_24MkPair = heff_take_reuse_n(v_x2_2419, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2419_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_CTest, 1, (V[]){v_x_2420}), v_n_2421});
  }
  default: return heff_nomatch(v_x2_2419);
  }
}
V g_heff_2ecompile_2eir_2econdTraverse_24s378097287x400807650_lam4(V self, V *args) {
  V v_n_2424 = args[0];
  V v_m_2423 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_2425 = heff_tr(heff_call(v_m_2423, 1, (V[]){v_n_2424}));
  switch (heff_tag_of(v_x2_2425)) {
  case TAG_MkPair: {
    V v_x_2426 = heff_field(v_x2_2425, 0);
    V v_n_2427 = heff_field(v_x2_2425, 1);
    V v_ru_24x2_2425_24MkPair = heff_take_reuse_n(v_x2_2425, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2425_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_CNot, 1, (V[]){v_x_2426}), v_n_2427});
  }
  default: return heff_nomatch(v_x2_2425);
  }
}
V g_heff_2ecompile_2eir_2econdTraverse_24s378097287x400807650_lam5(V self, V *args) {
  V v_n_2432 = args[0];
  V v_m_2431 = heff_env(self)[0];
  V v_f_240 = heff_env(self)[1];
  V v_b_2429 = heff_env(self)[2];
  V v_c_2430 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2433 = heff_tr(heff_call(v_m_2431, 1, (V[]){v_n_2432}));
  switch (heff_tag_of(v_x2_2433)) {
  case TAG_MkPair: {
    V v_x_2434 = heff_field(v_x2_2433, 0);
    V v_n_2435 = heff_field(v_x2_2433, 1);
    V v_ru_24x2_2433_24MkPair = heff_take_reuse_n(v_x2_2433, 3ULL, 2);
    V v_m_2436 = (g_heff_2ecompile_2eir_2econdTraverse_24s378097287x400807650(heff_dup(v_f_240), v_b_2429));
    V v_x2_2437 = heff_tr(heff_call(v_m_2436, 1, (V[]){v_n_2435}));
    switch (heff_tag_of(v_x2_2437)) {
    case TAG_MkPair: {
      V v_x_2438 = heff_field(v_x2_2437, 0);
      V v_n_2439 = heff_field(v_x2_2437, 1);
      heff_take_n(v_x2_2437, 3ULL, 2);
      V v_m_2440 = (g_heff_2ecompile_2eir_2econdTraverse_24s378097287x400807650(v_f_240, v_c_2430));
      V v_x2_2441 = heff_tr(heff_call(v_m_2440, 1, (V[]){v_n_2439}));
      switch (heff_tag_of(v_x2_2441)) {
      case TAG_MkPair: {
        V v_x_2442 = heff_field(v_x2_2441, 0);
        V v_n_2443 = heff_field(v_x2_2441, 1);
        heff_take_n(v_x2_2441, 3ULL, 2);
        return heff_tag_at_n(v_ru_24x2_2433_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_CIf, 3, (V[]){v_x_2434, v_x_2438, v_x_2442}), v_n_2443});
      }
      default: return heff_nomatch(v_x2_2441);
      }
    }
    default: return heff_nomatch(v_x2_2437);
    }
  }
  default: return heff_nomatch(v_x2_2433);
  }
}