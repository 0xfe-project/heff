// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Ann 13421
#define TAG_App 13485
#define TAG_At 8900
#define TAG_Atom 28502
#define TAG_BAnn 9252
#define TAG_BImp 16911
#define TAG_BVar 29034
#define TAG_Braces 8205
#define TAG_Case 4415
#define TAG_Do 8988
#define TAG_EAlt 33043
#define TAG_EAnn 33099
#define TAG_ECon 35052
#define TAG_EDo 15964
#define TAG_EFDefault 38038
#define TAG_EFSet 34673
#define TAG_EField 26142
#define TAG_EInvalid 31081
#define TAG_ELet 43397
#define TAG_ELetIn 22786
#define TAG_EMatch 41631
#define TAG_ENeg 45306
#define TAG_EParen 58248
#define TAG_ESBind 62182
#define TAG_ESum 50613
#define TAG_ETag 50948
#define TAG_EUSet 22856
#define TAG_EUpdate 6986
#define TAG_EVar 52881
#define TAG_If 9134
#define TAG_InstB 37114
#define TAG_Lam 23588
#define TAG_Left 13886
#define TAG_MkAlt 55173
#define TAG_MkFields 41650
#define TAG_Named 2049
#define TAG_Op 9330
#define TAG_OpRhs 36076
#define TAG_Ops 26942
#define TAG_Right 62770
#define TAG_SError 24172
#define TAG_Sum 30935
#define TAG_Tup 31899
#define TAG_Update 40810
#define LBL_code 9554612
#define LBL_e 319
#define LBL_end 310101
#define LBL_kind 9787483
#define LBL_msg 317947
#define LBL_note 9882809
#define LBL_op 10312
#define LBL_ops 319788
#define LBL_out 319944
#define LBL_severity 75955546
#define LBL_span 10032145
#define LBL_start 311115900
#define LBL_text 10052084
static uint32_t shape_code__severity__msg__span__note[] = {LBL_code, LBL_severity, LBL_msg, LBL_span, LBL_note};
static uint32_t shape_op__e[] = {LBL_op, LBL_e};
static uint32_t shape_ops__out[] = {LBL_ops, LBL_out};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
V g_heff_2esyntax_2ecst_2efirstE(V);
V g_heff_2esyntax_2ecst_2efirstE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2efirstE_clo;
V g_heff_2esyntax_2ecst_2elastE(V);
V g_heff_2esyntax_2ecst_2elastE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2elastE_clo;
V g_heff_2esyntax_2epresyntax_2eapp(V, V);
V g_heff_2esyntax_2epresyntax_2eapp_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eapp_clo;
V g_heff_2esyntax_2esurface_2ealtL(V, V);
V g_heff_2esyntax_2esurface_2ealtL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ealtL_clo;
V g_heff_2esyntax_2esurface_2eapplyOp(V, V, V);
V g_heff_2esyntax_2esurface_2eapplyOp_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eapplyOp_clo;
V g_heff_2esyntax_2esurface_2eargL(V, V);
V g_heff_2esyntax_2esurface_2eargL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eargL_clo;
V g_heff_2esyntax_2esurface_2eatomTok(V);
V g_heff_2esyntax_2esurface_2eatomTok_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eatomTok_clo;
V g_heff_2esyntax_2esurface_2eblock(V, V, V);
V g_heff_2esyntax_2esurface_2eblock_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eblock_clo;
V g_heff_2esyntax_2esurface_2ebracesL(V, V, V, V, V);
V g_heff_2esyntax_2esurface_2ebracesL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ebracesL_clo;
V g_heff_2esyntax_2esurface_2ecommentLinesFrom(V, V, V);
V g_heff_2esyntax_2esurface_2ecommentLinesFrom_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ecommentLinesFrom_clo;
V g_heff_2esyntax_2esurface_2econAtom(V, V, V);
V g_heff_2esyntax_2esurface_2econAtom_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2econAtom_clo;
V g_heff_2esyntax_2esurface_2econL(V, V, V);
V g_heff_2esyntax_2esurface_2econL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2econL_clo;
V g_heff_2esyntax_2esurface_2edeclarationL(V, V);
V g_heff_2esyntax_2esurface_2edeclarationL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2edeclarationL_clo;
V g_heff_2esyntax_2esurface_2edefaultL(V, V);
V g_heff_2esyntax_2esurface_2edefaultL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2edefaultL_clo;
V g_heff_2esyntax_2esurface_2eexprL(V, V, V);
V g_heff_2esyntax_2esurface_2eexprL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eexprL_clo;
V g_heff_2esyntax_2esurface_2efieldsOf(V, V);
V g_heff_2esyntax_2esurface_2efieldsOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2efieldsOf_clo;
V g_heff_2esyntax_2esurface_2efirstS(V, V, V, V);
V g_heff_2esyntax_2esurface_2efirstS_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2efirstS_clo;
V g_heff_2esyntax_2esurface_2efoldr(V, V, V);
V g_heff_2esyntax_2esurface_2efoldr_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2efoldr_clo;
V g_heff_2esyntax_2esurface_2eifE(V, V, V, V);
V g_heff_2esyntax_2esurface_2eifE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eifE_clo;
V g_heff_2esyntax_2esurface_2ekwAtom(V, V, V);
V g_heff_2esyntax_2esurface_2ekwAtom_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ekwAtom_clo;
V g_heff_2esyntax_2esurface_2elambdaL(V, V, V, V);
V g_heff_2esyntax_2esurface_2elambdaL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2elambdaL_clo;
V g_heff_2esyntax_2esurface_2eletBodyL(V, V, V, V, V, V);
V g_heff_2esyntax_2esurface_2eletBodyL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eletBodyL_clo;
V g_heff_2esyntax_2esurface_2eletL(V, V, V);
V g_heff_2esyntax_2esurface_2eletL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eletL_clo;
V g_heff_2esyntax_2esurface_2eopL(V, V, V, V, V);
V g_heff_2esyntax_2esurface_2eopL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eopL_clo;
V g_heff_2esyntax_2esurface_2eopRhsOf(V);
V g_heff_2esyntax_2esurface_2eopRhsOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eopRhsOf_clo;
V g_heff_2esyntax_2esurface_2eparenL(V, V, V, V, V);
V g_heff_2esyntax_2esurface_2eparenL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eparenL_clo;
V g_heff_2esyntax_2esurface_2epushS_24s1868233564x1858628873(V, V, V, V);
V g_heff_2esyntax_2esurface_2epushS_24s1868233564x1858628873_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2epushS_24s1868233564x1858628873_clo;
V g_heff_2esyntax_2esurface_2eresolve_24s1832151779x1448561609(V, V, V);
V g_heff_2esyntax_2esurface_2eresolve_24s1832151779x1448561609_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eresolve_24s1832151779x1448561609_clo;
V g_heff_2esyntax_2esurface_2estmtL(V, V);
V g_heff_2esyntax_2esurface_2estmtL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2estmtL_clo;
V g_heff_2esyntax_2esurface_2etraverseS(V, V);
V g_heff_2esyntax_2esurface_2etraverseS_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2etraverseS_clo;
V g_heff_2esyntax_2esurface_2eupdateSettingL(V, V);
V g_heff_2esyntax_2esurface_2eupdateSettingL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eupdateSettingL_clo;
V g_heff_2esyntax_2esurface_2evariantL(V, V);
V g_heff_2esyntax_2esurface_2evariantL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2evariantL_clo;
V g_heff_2esyntax_2esurface_2ewithScope(V, V, V);
V g_heff_2esyntax_2esurface_2ewithScope_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ewithScope_clo;
V g_list_2emap_24s513201124x806973253(V);
V g_list_2emap_24s513201124x806973253_entry(V self, V *a);
extern Clo g_list_2emap_24s513201124x806973253_clo;
V g_prelude_2eindexFrom(V, V, V);
V g_prelude_2eindexFrom_entry(V self, V *a);
extern Clo g_prelude_2eindexFrom_clo;
V g_prelude_2eskipSpaces(V, V, V);
V g_prelude_2eskipSpaces_entry(V self, V *a);
extern Clo g_prelude_2eskipSpaces_clo;
HEFF_LIT(g_heff_2esyntax_2esurface_2ecommentLinesFrom_str0, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecommentLinesFrom_str1, 2, "--");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecommentLinesFrom_str2, 1, "\012");
Clo g_heff_2esyntax_2esurface_2ecommentLinesFrom_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2ecommentLinesFrom_entry, 3, 0};

V g_heff_2esyntax_2esurface_2ecommentLinesFrom(V v_src_240, V v_i_241, V v_to_242) {
top: ;
  if (heff_intLe_c(heff_dup(v_to_242), heff_dup(v_i_241))) {
    heff_drop(v_src_240);
    heff_drop(v_i_241);
    heff_drop(v_to_242);
    return NTAG(TAG_True);
  } else {
    V v_x2_244 = (g_prelude_2eindexFrom(((V)&g_heff_2esyntax_2esurface_2ecommentLinesFrom_str0), heff_dup(v_src_240), heff_dup(v_i_241)));
    V v_t_246;
    switch (heff_tag_of(v_x2_244)) {
    case TAG_Nothing: {
      v_t_246 = heff_strLength(heff_dup(v_src_240));
      break;
    }
    case TAG_Just: {
      V v_x_245 = heff_field(v_x2_244, 0);
      heff_take_n(v_x2_244, 1ULL, 1);
      v_t_246 = v_x_245;
      break;
    }
    default: heff_nomatch(v_x2_244);
    }
    V v_s_247 = heff_strSlice(heff_dup(v_src_240), heff_dup(v_i_241), v_t_246);
    V v_t_248 = (g_prelude_2eskipSpaces(heff_dup(v_s_247), MK_INT(0LL), MK_INT(1LL)));
    V v_t_249 = heff_intSub(heff_strLength(heff_dup(v_s_247)), MK_INT(1LL));
    V v_t_2410 = (g_prelude_2eskipSpaces(heff_dup(v_s_247), v_t_249, MK_INT(-1LL)));
    V v_s_2411 = heff_strSlice(v_s_247, v_t_248, heff_intAdd(v_t_2410, MK_INT(1LL)));
    if (heff_strEq_c(heff_strSlice(v_s_2411, MK_INT(0LL), MK_INT(2LL)), ((V)&g_heff_2esyntax_2esurface_2ecommentLinesFrom_str1))) {
      V v_x2_2413 = (g_prelude_2eindexFrom(((V)&g_heff_2esyntax_2esurface_2ecommentLinesFrom_str2), heff_dup(v_src_240), v_i_241));
      V v_t_2415;
      switch (heff_tag_of(v_x2_2413)) {
      case TAG_Nothing: {
        v_t_2415 = heff_strLength(heff_dup(v_src_240));
        break;
      }
      case TAG_Just: {
        V v_x_2414 = heff_field(v_x2_2413, 0);
        heff_take_n(v_x2_2413, 1ULL, 1);
        v_t_2415 = v_x_2414;
        break;
      }
      default: heff_nomatch(v_x2_2413);
      }
      V t_0 = v_src_240;
      V t_1 = heff_intAdd(v_t_2415, MK_INT(1LL));
      V t_2 = v_to_242;
      v_src_240 = t_0;
      v_i_241 = t_1;
      v_to_242 = t_2;
      goto top;
    } else {
      heff_drop(v_src_240);
      heff_drop(v_i_241);
      heff_drop(v_to_242);
      return NTAG(TAG_False);
    }
  }
}
V g_heff_2esyntax_2esurface_2ecommentLinesFrom_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2ecommentLinesFrom(a[0], a[1], a[2]);
}
V g_heff_2esyntax_2esurface_2eletBodyL_lam0(V self, V *args);
Clo g_heff_2esyntax_2esurface_2eletBodyL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eletBodyL_entry, 6, 0};

V g_heff_2esyntax_2esurface_2eletBodyL(V v_r_240, V v_kw_241, V v_x3_242, V v_names_243, V v_body_244, V v_z_245) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_MkPair: {
    V v_p_246 = heff_field(v_x3_242, 0);
    V v_rhs_247 = heff_field(v_x3_242, 1);
    heff_take_n(v_x3_242, 3ULL, 2);
    V v_m_248 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_body_244)}));
    return (g_heff_2esyntax_2esurface_2ewithScope(v_names_243, heff_clo_n(g_heff_2esyntax_2esurface_2eletBodyL_lam0, 1, 5, (V[]){v_m_248, v_p_246, v_body_244, v_kw_241, v_rhs_247}), v_z_245));
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2esyntax_2esurface_2eletBodyL_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2eletBodyL(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2esyntax_2esurface_2eletBodyL_lam0(V self, V *args) {
  V v_st_249 = args[0];
  V v_m_248 = heff_env(self)[0];
  V v_p_246 = heff_env(self)[1];
  V v_body_244 = heff_env(self)[2];
  V v_kw_241 = heff_env(self)[3];
  V v_rhs_247 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_x1_2410 = heff_tr(heff_call(v_m_248, 1, (V[]){v_st_249}));
  switch (heff_tag_of(v_x1_2410)) {
  case TAG_MkPair: {
    V v_x11_2411 = heff_field(v_x1_2410, 0);
    V v_st_2412 = heff_field(v_x1_2410, 1);
    V v_ru_24x1_2410_24MkPair = heff_take_reuse_n(v_x1_2410, 3ULL, 2);
    switch (heff_tag_of(v_x11_2411)) {
    case TAG_Left: {
      V v_e_2413 = heff_field(v_x11_2411, 0);
      heff_take_n(v_x11_2411, 1ULL, 1);
      heff_drop(v_p_246);
      heff_drop(v_body_244);
      heff_drop_rec(v_kw_241, 9);
      heff_drop(v_rhs_247);
      return heff_tag_at_n(v_ru_24x1_2410_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2413}), v_st_2412});
    }
    case TAG_Right: {
      V v_x_2414 = heff_field(v_x11_2411, 0);
      V v_ru_24x11_2411_24Right = heff_take_reuse_n(v_x11_2411, 1ULL, 1);
      V v_a_2417;
      switch (heff_tag_of(v_p_246)) {
      case TAG_At: {
        V v_s_2416 = heff_dup(heff_field(v_p_246, 1));
        v_a_2417 = v_s_2416;
        break;
      }
      default: heff_nomatch(v_p_246);
      }
      V v_b_2420;
      switch (heff_tag_of(v_x_2414)) {
      case TAG_At: {
        V v_s_2419 = heff_dup(heff_field(v_x_2414, 1));
        v_b_2420 = v_s_2419;
        break;
      }
      default: heff_nomatch(v_x_2414);
      }
      V v_t_2421 = ({ V rv_1 = heff_get_n(v_b_2420, 1, 2); V rr_ = heff_rec_reuse_nf(v_a_2417, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
      V v_t_2422 = heff_tag_at_n(v_ru_24x1_2410_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_246, v_x_2414}), v_t_2421});
      V v_t_2423 = (g_heff_2esyntax_2ecst_2elastE(v_body_244));
      V v_e_2424 = heff_get_n(v_t_2423, 4, 9);
      V v_t_2425 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_241, 3, 9), v_e_2424});
      V v_x_2426 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ELetIn, 2, (V[]){v_rhs_247, v_t_2422}), v_t_2425});
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_2411_24Right, TAG_Right, 1, (V[]){v_x_2426}), v_st_2412});
    }
    default: return heff_nomatch(v_x11_2411);
    }
  }
  default: return heff_nomatch(v_x1_2410);
  }
}
V g_heff_2esyntax_2esurface_2epushS_24s1868233564x1858628873_lam0(V self, V *args);
V g_heff_2esyntax_2esurface_2epushS_24s1868233564x1858628873_lam1(V self, V *args);
Clo g_heff_2esyntax_2esurface_2epushS_24s1868233564x1858628873_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2epushS_24s1868233564x1858628873_entry, 4, 0};

V g_heff_2esyntax_2esurface_2epushS_24s1868233564x1858628873(V v_fix_240, V v_lenient_241, V v_st_242, V v_r_243) {
top: ;
  V v_t_244 = heff_dup(heff_rfield(v_st_242, 0));
  switch (heff_tag_of(v_t_244)) {
  case TAG_Nil: {
    heff_drop(v_fix_240);
    return heff_clo_n(g_heff_2esyntax_2esurface_2epushS_24s1868233564x1858628873_lam0, 1, 2, (V[]){v_r_243, v_st_242});
  }
  case TAG_Cons: {
    V v_before_249 = heff_field(v_t_244, 0);
    heff_take_n(v_t_244, 1ULL, 2);
    V v_m_2411 = (g_heff_2esyntax_2esurface_2efirstS(heff_dup(v_fix_240), v_lenient_241, v_before_249, heff_dup(heff_rfield(v_r_243, 0))));
    return heff_clo_n(g_heff_2esyntax_2esurface_2epushS_24s1868233564x1858628873_lam1, 1, 5, (V[]){v_m_2411, v_st_242, v_fix_240, heff_dup(v_lenient_241), v_r_243});
  }
  default: return heff_nomatch(v_t_244);
  }
}
V g_heff_2esyntax_2esurface_2epushS_24s1868233564x1858628873_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2esyntax_2esurface_2epushS_24s1868233564x1858628873(a[0], a1, a[2], a[3]); heff_drop(a1); return r;
}
V g_heff_2esyntax_2esurface_2epushS_24s1868233564x1858628873_lam0(V self, V *args) {
  V v_st_245 = args[0];
  V v_r_243 = heff_env(self)[0];
  V v_st_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){heff_take_field(v_r_243, 0), heff_take_field(v_st_242, 0)});
  V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){heff_get_n(v_r_243, 1, 2), heff_get_n(v_st_242, 1, 2)});
  V v_t_248 = heff_tag_n(TAG_Right, 1, (V[]){heff_rec_n(2, shape_ops__out, (V[]){v_t_246, v_t_247})});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_248, v_st_245});
}
V g_heff_2esyntax_2esurface_2epushS_24s1868233564x1858628873_lam1(V self, V *args) {
  V v_st_2412 = args[0];
  V v_m_2411 = heff_env(self)[0];
  V v_st_242 = heff_env(self)[1];
  V v_fix_240 = heff_env(self)[2];
  V v_lenient_241 = heff_env(self)[3];
  V v_r_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_x1_2413 = heff_tr(heff_call(v_m_2411, 1, (V[]){v_st_2412}));
  switch (heff_tag_of(v_x1_2413)) {
  case TAG_MkPair: {
    V v_x11_2414 = heff_field(v_x1_2413, 0);
    V v_st_2415 = heff_field(v_x1_2413, 1);
    V v_ru_24x1_2413_24MkPair = heff_take_reuse_n(v_x1_2413, 3ULL, 2);
    switch (heff_tag_of(v_x11_2414)) {
    case TAG_Left: {
      V v_e_2416 = heff_field(v_x11_2414, 0);
      heff_take_n(v_x11_2414, 1ULL, 1);
      heff_drop_rec(v_st_242, 2);
      heff_drop(v_fix_240);
      heff_drop(v_lenient_241);
      heff_drop_rec(v_r_243, 2);
      return heff_tag_at_n(v_ru_24x1_2413_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2416}), v_st_2415});
    }
    case TAG_Right: {
      V v_x_2417 = heff_field(v_x11_2414, 0);
      V v_ru_24x11_2414_24Right = heff_take_reuse_n(v_x11_2414, 1ULL, 1);
      if ((heff_dup(v_x_2417) == NTAG(TAG_True))) {
        heff_drop_cell(v_ru_24x1_2413_24MkPair, 2);
        heff_drop(v_x_2417);
        heff_drop_cell(v_ru_24x11_2414_24Right, 1);
        V v_t_2418 = heff_dup(heff_rfield(v_st_242, 0));
        V v_t_2427;
        switch (heff_tag_of(v_t_2418)) {
        case TAG_Nil: {
          v_t_2427 = v_st_242;
          break;
        }
        case TAG_Cons: {
          V v_o_2419 = heff_field(v_t_2418, 0);
          V v_os_2420 = heff_field(v_t_2418, 1);
          heff_take_n(v_t_2418, 3ULL, 2);
          V v_t_2421 = heff_dup(heff_rfield(v_st_242, 1));
          switch (heff_tag_of(v_t_2421)) {
          case TAG_Nil: {
            heff_drop(v_o_2419);
            heff_drop(v_os_2420);
            v_t_2427 = v_st_242;
            break;
          }
          case TAG_Cons: {
            V v_r_2422 = heff_field(v_t_2421, 0);
            V v_it2_2423 = heff_field(v_t_2421, 1);
            heff_take_n(v_t_2421, 3ULL, 2);
            switch (heff_tag_of(v_it2_2423)) {
            case TAG_Nil: {
              heff_drop(v_o_2419);
              heff_drop(v_os_2420);
              heff_drop(v_r_2422);
              v_t_2427 = v_st_242;
              break;
            }
            case TAG_Cons: {
              V v_l_2424 = heff_field(v_it2_2423, 0);
              V v_rest_2425 = heff_field(v_it2_2423, 1);
              heff_take_n(v_it2_2423, 3ULL, 2);
              heff_drop_rec(v_st_242, 2);
              V v_t_2426 = (g_heff_2esyntax_2esurface_2eapplyOp(v_o_2419, v_l_2424, v_r_2422));
              v_t_2427 = heff_rec_n(2, shape_ops__out, (V[]){v_os_2420, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2426, v_rest_2425})});
              break;
            }
            default: heff_nomatch(v_it2_2423);
            }
            break;
          }
          default: heff_nomatch(v_t_2421);
          }
          break;
        }
        default: heff_nomatch(v_t_2418);
        }
        V v_t_2428 = ({ V a_0 = v_fix_240; V a_1 = v_lenient_241; V a_2 = v_t_2427; V a_3 = v_r_243; V r_ = (g_heff_2esyntax_2esurface_2epushS_24s1868233564x1858628873(a_0, a_1, a_2, a_3)); heff_drop(v_lenient_241); r_; });
        V f_ = v_t_2428;
        args[0] = v_st_2415;
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      } else {
        heff_drop(v_fix_240);
        heff_drop(v_lenient_241);
        heff_drop(v_x_2417);
        V v_t_2429 = heff_tag_at_n(v_ru_24x1_2413_24MkPair, TAG_Cons, 2, (V[]){heff_dup(heff_rfield(v_r_243, 0)), heff_dup(heff_rfield(v_st_242, 0))});
        V v_t_2430 = heff_tag_n(TAG_Cons, 2, (V[]){heff_get_n(v_r_243, 1, 2), heff_get_n(v_st_242, 1, 2)});
        V v_t_2431 = heff_tag_at_n(v_ru_24x11_2414_24Right, TAG_Right, 1, (V[]){heff_rec_n(2, shape_ops__out, (V[]){v_t_2429, v_t_2430})});
        return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2431, v_st_2415});
      }
    }
    default: return heff_nomatch(v_x11_2414);
    }
  }
  default: return heff_nomatch(v_x1_2413);
  }
}
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str0, 3, "con");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str1, 7, " := e)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str2, 51, " := ...)` names an argument, after a function: `f (");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str3, 2, "`(");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str4, 1, "[");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str5, 3, "Nil");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str6, 4, "Cons");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str7, 70, "heff has no tuples: a record holds values together, `{ x = a, y = b }`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str8, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str9, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str10, 61, "an instance argument is bound before `->`: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str11, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str12, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str13, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str14, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str15, 3, "con");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str16, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str17, 3, "neg");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str18, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str19, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str20, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str21, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str22, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str23, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str24, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str25, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str26, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str27, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str28, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str29, 12, "unexpected `");
V g_heff_2esyntax_2esurface_2eexprL_lam0(V self, V *args);
V g_heff_2esyntax_2esurface_2eexprL_lam1(V self, V *args);
V g_heff_2esyntax_2esurface_2eexprL_lam2(V self, V *args);
V g_heff_2esyntax_2esurface_2eexprL_lam3(V self, V *args);
V g_heff_2esyntax_2esurface_2eexprL_lam5(V self, V *args);
V g_heff_2esyntax_2esurface_2eexprL_lam4(V self, V *args);
V g_heff_2esyntax_2esurface_2eexprL_lam6(V self, V *args);
V g_heff_2esyntax_2esurface_2eexprL_lam7(V self, V *args);
Clo g_heff_2esyntax_2esurface_2eexprL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eexprL_entry, 3, 0};

V g_heff_2esyntax_2esurface_2eexprL(V v_r_240, V v_e0_241, V v_z_242) {
top: ;
  switch (heff_tag_of(v_e0_241)) {
  case TAG_Atom: {
    V v_t_243 = heff_field(v_e0_241, 0);
    V v_ru_24e0_241_24Atom = heff_take_reuse_n(v_e0_241, 1ULL, 1);
    heff_drop_rec(v_r_240, 3);
    if (heff_strEq_c(heff_dup(heff_rfield(v_t_243, 0)), ((V)&g_heff_2esyntax_2esurface_2eexprL_str0))) {
      heff_drop_cell(v_ru_24e0_241_24Atom, 1);
      HEFF_LAST return g_heff_2esyntax_2esurface_2econAtom(v_t_243, NTAG(TAG_Nil), v_z_242);
    } else {
      V v_x_245 = (g_heff_2esyntax_2esurface_2eatomTok(v_t_243));
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24e0_241_24Atom, TAG_Right, 1, (V[]){v_x_245}), v_z_242});
    }
  }
  case TAG_EParen: {
    V v_o_246 = heff_field(v_e0_241, 0);
    V v_e_247 = heff_field(v_e0_241, 1);
    V v_c_248 = heff_field(v_e0_241, 2);
    heff_take_n(v_e0_241, 7ULL, 3);
    return ({ V a_0 = v_r_240; V a_1 = v_o_246; V a_2 = v_e_247; V a_3 = v_c_248; V a_4 = v_z_242; V r_ = (g_heff_2esyntax_2esurface_2eparenL(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_o_246); r_; });
  }
  case TAG_Named: {
    V v_o_249 = heff_field(v_e0_241, 0);
    V v_x_2410 = heff_field(v_e0_241, 1);
    V v_e_2412 = heff_field(v_e0_241, 3);
    V v_c_2413 = heff_field(v_e0_241, 4);
    heff_take_n(v_e0_241, 27ULL, 5);
    V v_m_2414 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_2412}));
    V v_x1_2415 = heff_tr(heff_call(v_m_2414, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x1_2415)) {
    case TAG_MkPair: {
      V v_x11_2416 = heff_field(v_x1_2415, 0);
      V v_st_2417 = heff_field(v_x1_2415, 1);
      V v_ru_24x1_2415_24MkPair = heff_take_reuse_n(v_x1_2415, 3ULL, 2);
      switch (heff_tag_of(v_x11_2416)) {
      case TAG_Left: {
        V v_e_2418 = heff_field(v_x11_2416, 0);
        heff_take_n(v_x11_2416, 1ULL, 1);
        heff_drop_rec(v_o_249, 9);
        heff_drop_rec(v_x_2410, 9);
        heff_drop_rec(v_c_2413, 9);
        return heff_tag_at_n(v_ru_24x1_2415_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2418}), v_st_2417});
      }
      case TAG_Right: {
        V v_ru_24x11_2416_24Right = heff_take_reuse_n(v_x11_2416, 0ULL, 1);
        V v_t_2420 = heff_strAppend(heff_dup(heff_rfield(v_x_2410, 1)), ((V)&g_heff_2esyntax_2esurface_2eexprL_str1));
        V v_t_2421 = heff_strAppend(heff_get_n(v_x_2410, 1, 9), heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eexprL_str2), v_t_2420));
        V v_t_2422 = heff_tag_at_n(v_ru_24x11_2416_24Right, TAG_EInvalid, 1, (V[]){heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eexprL_str3), v_t_2421)});
        V v_t_2423 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_o_249, 3, 9), heff_get_n(v_c_2413, 4, 9)});
        V v_t_2424 = heff_tag_n(TAG_Right, 1, (V[]){heff_tag_at_n(v_ru_24x1_2415_24MkPair, TAG_At, 2, (V[]){v_t_2422, v_t_2423})});
        return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2424, v_st_2417});
      }
      default: return heff_nomatch(v_x11_2416);
      }
    }
    default: return heff_nomatch(v_x1_2415);
    }
  }
  case TAG_Tup: {
    V v_o_2425 = heff_field(v_e0_241, 0);
    V v_es_2426 = heff_field(v_e0_241, 1);
    V v_c_2428 = heff_field(v_e0_241, 3);
    heff_take_n(v_e0_241, 11ULL, 4);
    if (heff_strEq_c(heff_dup(heff_rfield(v_o_2425, 1)), ((V)&g_heff_2esyntax_2esurface_2eexprL_str4))) {
      V v_m_2430 = (g_heff_2esyntax_2esurface_2etraverseS(heff_get_n(v_r_240, 0, 3), v_es_2426));
      V v_x1_2431 = heff_tr(heff_call(v_m_2430, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_2431)) {
      case TAG_MkPair: {
        V v_x11_2432 = heff_field(v_x1_2431, 0);
        V v_st_2433 = heff_field(v_x1_2431, 1);
        V v_ru_24x1_2431_24MkPair = heff_take_reuse_n(v_x1_2431, 3ULL, 2);
        switch (heff_tag_of(v_x11_2432)) {
        case TAG_Left: {
          V v_e_2434 = heff_field(v_x11_2432, 0);
          heff_take_n(v_x11_2432, 1ULL, 1);
          heff_drop_rec(v_o_2425, 9);
          heff_drop_rec(v_c_2428, 9);
          return heff_tag_at_n(v_ru_24x1_2431_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2434}), v_st_2433});
        }
        case TAG_Right: {
          V v_x_2435 = heff_field(v_x11_2432, 0);
          V v_ru_24x11_2432_24Right = heff_take_reuse_n(v_x11_2432, 1ULL, 1);
          V v_sp_2436 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_o_2425, 3, 9), heff_get_n(v_c_2428, 4, 9)});
          V v_t_2437 = heff_tag_at_n(v_ru_24x1_2431_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_ETag, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2eexprL_str5)}), heff_dup(v_sp_2436)});
          V v_x_2442 = ({ V a_0 = heff_clo_n(g_heff_2esyntax_2esurface_2eexprL_lam0, 2, 1, (V[]){v_sp_2436}); V a_1 = v_t_2437; V a_2 = v_x_2435; V r_ = heff_tr(g_heff_2esyntax_2esurface_2efoldr(a_0, a_1, a_2)); heff_drop(v_x_2435); r_; });
          return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_2432_24Right, TAG_Right, 1, (V[]){v_x_2442}), v_st_2433});
        }
        default: return heff_nomatch(v_x11_2432);
        }
      }
      default: return heff_nomatch(v_x1_2431);
      }
    } else {
      V v_m_2443 = (g_heff_2esyntax_2esurface_2etraverseS(heff_get_n(v_r_240, 0, 3), v_es_2426));
      V v_x1_2444 = heff_tr(heff_call(v_m_2443, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_2444)) {
      case TAG_MkPair: {
        V v_x11_2445 = heff_field(v_x1_2444, 0);
        V v_st_2446 = heff_field(v_x1_2444, 1);
        V v_ru_24x1_2444_24MkPair = heff_take_reuse_n(v_x1_2444, 3ULL, 2);
        switch (heff_tag_of(v_x11_2445)) {
        case TAG_Left: {
          V v_e_2447 = heff_field(v_x11_2445, 0);
          heff_take_n(v_x11_2445, 1ULL, 1);
          heff_drop_rec(v_o_2425, 9);
          heff_drop_rec(v_c_2428, 9);
          return heff_tag_at_n(v_ru_24x1_2444_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2447}), v_st_2446});
        }
        case TAG_Right: {
          V v_ru_24x11_2445_24Right = heff_take_reuse_n(v_x11_2445, 0ULL, 1);
          V v_t_2449 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_o_2425, 3, 9), heff_get_n(v_c_2428, 4, 9)});
          V v_t_2450 = heff_tag_at_n(v_ru_24x1_2444_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2eexprL_str7)}), v_t_2449});
          return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_2445_24Right, TAG_Right, 1, (V[]){v_t_2450}), v_st_2446});
        }
        default: return heff_nomatch(v_x11_2445);
        }
      }
      default: return heff_nomatch(v_x1_2444);
      }
    }
  }
  case TAG_Braces: {
    V v_o_2451 = heff_field(v_e0_241, 0);
    V v_fs_2452 = heff_field(v_e0_241, 1);
    V v_c_2454 = heff_field(v_e0_241, 3);
    heff_take_n(v_e0_241, 11ULL, 4);
    return (g_heff_2esyntax_2esurface_2ebracesL(v_r_240, v_o_2451, v_fs_2452, v_c_2454, v_z_242));
  }
  case TAG_Update: {
    V v_o_2455 = heff_field(v_e0_241, 0);
    V v_rec_2456 = heff_field(v_e0_241, 1);
    V v_fs_2458 = heff_field(v_e0_241, 3);
    V v_c_2460 = heff_field(v_e0_241, 5);
    heff_take_n(v_e0_241, 43ULL, 6);
    V v_m_2461 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_rec_2456}));
    V v_x1_2462 = heff_tr(heff_call(v_m_2461, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x1_2462)) {
    case TAG_MkPair: {
      V v_x11_2463 = heff_field(v_x1_2462, 0);
      V v_st_2464 = heff_field(v_x1_2462, 1);
      V v_ru_24x1_2462_24MkPair = heff_take_reuse_n(v_x1_2462, 3ULL, 2);
      switch (heff_tag_of(v_x11_2463)) {
      case TAG_Left: {
        V v_e_2465 = heff_field(v_x11_2463, 0);
        heff_take_n(v_x11_2463, 1ULL, 1);
        heff_drop_rec(v_r_240, 3);
        heff_drop_rec(v_o_2455, 9);
        heff_drop(v_fs_2458);
        heff_drop_rec(v_c_2460, 9);
        return heff_tag_at_n(v_ru_24x1_2462_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2465}), v_st_2464});
      }
      case TAG_Right: {
        V v_x_2466 = heff_field(v_x11_2463, 0);
        V v_ru_24x11_2463_24Right = heff_take_reuse_n(v_x11_2463, 1ULL, 1);
        V v_m_2468 = (g_heff_2esyntax_2esurface_2etraverseS(heff_clo_n(g_heff_2esyntax_2esurface_2eexprL_lam1, 1, 1, (V[]){v_r_240}), v_fs_2458));
        V v_x1_2469 = heff_tr(heff_call(v_m_2468, 1, (V[]){v_st_2464}));
        switch (heff_tag_of(v_x1_2469)) {
        case TAG_MkPair: {
          V v_x11_2470 = heff_field(v_x1_2469, 0);
          V v_st_2471 = heff_field(v_x1_2469, 1);
          V v_ru_24x1_2469_24MkPair = heff_take_reuse_n(v_x1_2469, 3ULL, 2);
          switch (heff_tag_of(v_x11_2470)) {
          case TAG_Left: {
            V v_e_2472 = heff_field(v_x11_2470, 0);
            heff_take_n(v_x11_2470, 1ULL, 1);
            heff_drop_rec(v_o_2455, 9);
            heff_drop_rec(v_c_2460, 9);
            heff_drop(v_x_2466);
            heff_drop_cell(v_ru_24x11_2463_24Right, 1);
            heff_drop_cell(v_ru_24x1_2469_24MkPair, 2);
            return heff_tag_at_n(v_ru_24x1_2462_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2472}), v_st_2471});
          }
          case TAG_Right: {
            V v_x_2473 = heff_field(v_x11_2470, 0);
            heff_take_n(v_x11_2470, 1ULL, 1);
            V v_t_2474 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_o_2455, 3, 9), heff_get_n(v_c_2460, 4, 9)});
            V v_t_2475 = heff_tag_at_n(v_ru_24x1_2462_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_EUpdate, 2, (V[]){v_x_2466, v_x_2473}), v_t_2474});
            return heff_tag_at_n(v_ru_24x1_2469_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_2463_24Right, TAG_Right, 1, (V[]){v_t_2475}), v_st_2471});
          }
          default: return heff_nomatch(v_x11_2470);
          }
        }
        default: return heff_nomatch(v_x1_2469);
        }
      }
      default: return heff_nomatch(v_x11_2463);
      }
    }
    default: return heff_nomatch(v_x1_2462);
    }
  }
  case TAG_EUSet: {
    heff_drop_rec(v_r_240, 3);
    V v_t_2479 = (g_heff_2esyntax_2ecst_2efirstE(v_e0_241));
    V v_t_2480 = ({ V a_0 = v_e0_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e0_241, 3); r_; });
    V v_t_2481 = heff_strAppend(heff_get_n(v_t_2480, 1, 9), ((V)&g_heff_2esyntax_2esurface_2eexprL_str8));
    V v_msg_2482 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eexprL_str9), v_t_2481);
    V v_t_2483 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_2479, 3), heff_get_n(v_t_2479, 4, 9)});
    V v_t_2484 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_2482, v_t_2483, NTAG(TAG_Nothing)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2484}), v_z_242});
  }
  case TAG_InstB: {
    V v_o_2485 = heff_field(v_e0_241, 0);
    V v_d_2487 = heff_field(v_e0_241, 2);
    V v_c_2489 = heff_field(v_e0_241, 4);
    heff_take_n(v_e0_241, 21ULL, 5);
    V v_m_2490 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_d_2487));
    V v_x1_2491 = heff_tr(heff_call(v_m_2490, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x1_2491)) {
    case TAG_MkPair: {
      V v_x11_2492 = heff_field(v_x1_2491, 0);
      V v_st_2493 = heff_field(v_x1_2491, 1);
      V v_ru_24x1_2491_24MkPair = heff_take_reuse_n(v_x1_2491, 3ULL, 2);
      switch (heff_tag_of(v_x11_2492)) {
      case TAG_Left: {
        V v_e_2494 = heff_field(v_x11_2492, 0);
        heff_take_n(v_x11_2492, 1ULL, 1);
        heff_drop_rec(v_o_2485, 9);
        heff_drop_rec(v_c_2489, 9);
        return heff_tag_at_n(v_ru_24x1_2491_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2494}), v_st_2493});
      }
      case TAG_Right: {
        V v_ru_24x11_2492_24Right = heff_take_reuse_n(v_x11_2492, 0ULL, 1);
        V v_t_2496 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_o_2485, 3, 9), heff_get_n(v_c_2489, 4, 9)});
        V v_t_2497 = heff_tag_at_n(v_ru_24x1_2491_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2eexprL_str10)}), v_t_2496});
        return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_2492_24Right, TAG_Right, 1, (V[]){v_t_2497}), v_st_2493});
      }
      default: return heff_nomatch(v_x11_2492);
      }
    }
    default: return heff_nomatch(v_x1_2491);
    }
  }
  case TAG_EFSet: {
    heff_drop_rec(v_r_240, 3);
    V v_t_24101 = (g_heff_2esyntax_2ecst_2efirstE(v_e0_241));
    V v_t_24102 = ({ V a_0 = v_e0_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e0_241, 3); r_; });
    V v_t_24103 = heff_strAppend(heff_get_n(v_t_24102, 1, 9), ((V)&g_heff_2esyntax_2esurface_2eexprL_str11));
    V v_msg_24104 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eexprL_str12), v_t_24103);
    V v_t_24105 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24101, 3), heff_get_n(v_t_24101, 4, 9)});
    V v_t_24106 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24104, v_t_24105, NTAG(TAG_Nothing)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24106}), v_z_242});
  }
  case TAG_EFDefault: {
    heff_drop_rec(v_r_240, 3);
    V v_t_24110 = (g_heff_2esyntax_2ecst_2efirstE(v_e0_241));
    V v_t_24111 = ({ V a_0 = v_e0_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e0_241, 3); r_; });
    V v_t_24112 = heff_strAppend(heff_get_n(v_t_24111, 1, 9), ((V)&g_heff_2esyntax_2esurface_2eexprL_str13));
    V v_msg_24113 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eexprL_str14), v_t_24112);
    V v_t_24114 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24110, 3), heff_get_n(v_t_24110, 4, 9)});
    V v_t_24115 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24113, v_t_24114, NTAG(TAG_Nothing)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24115}), v_z_242});
  }
  case TAG_Sum: {
    V v_kw_24116 = heff_field(v_e0_241, 0);
    V v_alts_24118 = heff_field(v_e0_241, 2);
    V v_c_24120 = heff_field(v_e0_241, 4);
    heff_take_n(v_e0_241, 21ULL, 5);
    V v_m_24122 = (g_heff_2esyntax_2esurface_2etraverseS(heff_clo_n(g_heff_2esyntax_2esurface_2eexprL_lam2, 1, 1, (V[]){v_r_240}), v_alts_24118));
    V v_x1_24123 = heff_tr(heff_call(v_m_24122, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x1_24123)) {
    case TAG_MkPair: {
      V v_x11_24124 = heff_field(v_x1_24123, 0);
      V v_st_24125 = heff_field(v_x1_24123, 1);
      V v_ru_24x1_24123_24MkPair = heff_take_reuse_n(v_x1_24123, 3ULL, 2);
      switch (heff_tag_of(v_x11_24124)) {
      case TAG_Left: {
        V v_e_24126 = heff_field(v_x11_24124, 0);
        heff_take_n(v_x11_24124, 1ULL, 1);
        heff_drop_rec(v_kw_24116, 9);
        heff_drop_rec(v_c_24120, 9);
        return heff_tag_at_n(v_ru_24x1_24123_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24126}), v_st_24125});
      }
      case TAG_Right: {
        V v_x_24127 = heff_field(v_x11_24124, 0);
        V v_ru_24x11_24124_24Right = heff_take_reuse_n(v_x11_24124, 1ULL, 1);
        V v_t_24128 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_24116, 3, 9), heff_get_n(v_c_24120, 4, 9)});
        V v_t_24129 = heff_tag_at_n(v_ru_24x1_24123_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_ESum, 1, (V[]){v_x_24127}), v_t_24128});
        return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_24124_24Right, TAG_Right, 1, (V[]){v_t_24129}), v_st_24125});
      }
      default: return heff_nomatch(v_x11_24124);
      }
    }
    default: return heff_nomatch(v_x1_24123);
    }
  }
  case TAG_ECon: {
    V v_c_24130 = heff_field(v_e0_241, 0);
    V v_args_24131 = heff_field(v_e0_241, 1);
    heff_take_n(v_e0_241, 3ULL, 2);
    V v_t_24132 = (g_heff_2esyntax_2esurface_2econL(v_r_240, v_c_24130, v_args_24131));
    return heff_tail(v_t_24132, 1, (V[]){v_z_242});
  }
  case TAG_EField: {
    V v_e_24133 = heff_field(v_e0_241, 0);
    V v_f_24134 = heff_field(v_e0_241, 1);
    V v_ru_24e0_241_24EField = heff_take_reuse_n(v_e0_241, 3ULL, 2);
    V v_it_24135 = (g_heff_2esyntax_2esurface_2efieldsOf(heff_tag_at_n(v_ru_24e0_241_24EField, TAG_EField, 2, (V[]){v_e_24133, v_f_24134}), NTAG(TAG_Nil)));
    switch (heff_tag_of(v_it_24135)) {
    case TAG_MkFields: {
      V v_it1_24136 = heff_field(v_it_24135, 0);
      V v_fs_24137 = heff_field(v_it_24135, 1);
      V v_ru_24it_24135_24MkFields = heff_take_reuse_n(v_it_24135, 3ULL, 2);
      switch (heff_tag_of(v_it1_24136)) {
      case TAG_Atom: {
        V v_t_24138 = heff_field(v_it1_24136, 0);
        heff_take_n(v_it1_24136, 1ULL, 1);
        heff_drop_rec(v_r_240, 3);
        if (heff_strEq_c(heff_dup(heff_rfield(v_t_24138, 0)), ((V)&g_heff_2esyntax_2esurface_2eexprL_str15))) {
          heff_drop_cell(v_ru_24it_24135_24MkFields, 2);
          HEFF_LAST return g_heff_2esyntax_2esurface_2econAtom(v_t_24138, v_fs_24137, v_z_242);
        } else {
          if (heff_strEq_c(heff_dup(heff_rfield(v_t_24138, 0)), ((V)&g_heff_2esyntax_2esurface_2eexprL_str16))) {
            heff_drop_cell(v_ru_24it_24135_24MkFields, 2);
            HEFF_LAST return g_heff_2esyntax_2esurface_2ekwAtom(v_t_24138, v_fs_24137, v_z_242);
          } else {
            V v_e_24141 = (g_heff_2esyntax_2esurface_2eatomTok(v_t_24138));
            V v_t_24142 = (g_list_2emap_24s513201124x806973253(v_fs_24137));
            V v_x_24143 = (g_heff_2esyntax_2epresyntax_2eapp(v_e_24141, v_t_24142));
            return heff_tag_at_n(v_ru_24it_24135_24MkFields, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24143}), v_z_242});
          }
        }
      }
      case TAG_EParen: {
        V v_m_24147 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24136}));
        V v_x1_24148 = heff_tr(heff_call(v_m_24147, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24148)) {
        case TAG_MkPair: {
          V v_x11_24149 = heff_field(v_x1_24148, 0);
          V v_st_24150 = heff_field(v_x1_24148, 1);
          heff_take_n(v_x1_24148, 3ULL, 2);
          switch (heff_tag_of(v_x11_24149)) {
          case TAG_Left: {
            V v_e_24151 = heff_field(v_x11_24149, 0);
            heff_take_n(v_x11_24149, 1ULL, 1);
            heff_drop(v_fs_24137);
            return heff_tag_at_n(v_ru_24it_24135_24MkFields, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24151}), v_st_24150});
          }
          case TAG_Right: {
            V v_x_24152 = heff_field(v_x11_24149, 0);
            heff_take_n(v_x11_24149, 1ULL, 1);
            V v_t_24153 = (g_list_2emap_24s513201124x806973253(v_fs_24137));
            V v_x_24154 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24152, v_t_24153));
            return heff_tag_at_n(v_ru_24it_24135_24MkFields, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24154}), v_st_24150});
          }
          default: return heff_nomatch(v_x11_24149);
          }
        }
        default: return heff_nomatch(v_x1_24148);
        }
      }
      case TAG_Named: {
        V v_m_24160 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24136}));
        V v_x1_24161 = heff_tr(heff_call(v_m_24160, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24161)) {
        case TAG_MkPair: {
          V v_x11_24162 = heff_field(v_x1_24161, 0);
          V v_st_24163 = heff_field(v_x1_24161, 1);
          heff_take_n(v_x1_24161, 3ULL, 2);
          switch (heff_tag_of(v_x11_24162)) {
          case TAG_Left: {
            V v_e_24164 = heff_field(v_x11_24162, 0);
            heff_take_n(v_x11_24162, 1ULL, 1);
            heff_drop(v_fs_24137);
            return heff_tag_at_n(v_ru_24it_24135_24MkFields, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24164}), v_st_24163});
          }
          case TAG_Right: {
            V v_x_24165 = heff_field(v_x11_24162, 0);
            heff_take_n(v_x11_24162, 1ULL, 1);
            V v_t_24166 = (g_list_2emap_24s513201124x806973253(v_fs_24137));
            V v_x_24167 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24165, v_t_24166));
            return heff_tag_at_n(v_ru_24it_24135_24MkFields, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24167}), v_st_24163});
          }
          default: return heff_nomatch(v_x11_24162);
          }
        }
        default: return heff_nomatch(v_x1_24161);
        }
      }
      case TAG_Tup: {
        V v_m_24172 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24136}));
        V v_x1_24173 = heff_tr(heff_call(v_m_24172, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24173)) {
        case TAG_MkPair: {
          V v_x11_24174 = heff_field(v_x1_24173, 0);
          V v_st_24175 = heff_field(v_x1_24173, 1);
          heff_take_n(v_x1_24173, 3ULL, 2);
          switch (heff_tag_of(v_x11_24174)) {
          case TAG_Left: {
            V v_e_24176 = heff_field(v_x11_24174, 0);
            heff_take_n(v_x11_24174, 1ULL, 1);
            heff_drop(v_fs_24137);
            return heff_tag_at_n(v_ru_24it_24135_24MkFields, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24176}), v_st_24175});
          }
          case TAG_Right: {
            V v_x_24177 = heff_field(v_x11_24174, 0);
            heff_take_n(v_x11_24174, 1ULL, 1);
            V v_t_24178 = (g_list_2emap_24s513201124x806973253(v_fs_24137));
            V v_x_24179 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24177, v_t_24178));
            return heff_tag_at_n(v_ru_24it_24135_24MkFields, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24179}), v_st_24175});
          }
          default: return heff_nomatch(v_x11_24174);
          }
        }
        default: return heff_nomatch(v_x1_24173);
        }
      }
      case TAG_Braces: {
        V v_m_24184 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24136}));
        V v_x1_24185 = heff_tr(heff_call(v_m_24184, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24185)) {
        case TAG_MkPair: {
          V v_x11_24186 = heff_field(v_x1_24185, 0);
          V v_st_24187 = heff_field(v_x1_24185, 1);
          heff_take_n(v_x1_24185, 3ULL, 2);
          switch (heff_tag_of(v_x11_24186)) {
          case TAG_Left: {
            V v_e_24188 = heff_field(v_x11_24186, 0);
            heff_take_n(v_x11_24186, 1ULL, 1);
            heff_drop(v_fs_24137);
            return heff_tag_at_n(v_ru_24it_24135_24MkFields, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24188}), v_st_24187});
          }
          case TAG_Right: {
            V v_x_24189 = heff_field(v_x11_24186, 0);
            heff_take_n(v_x11_24186, 1ULL, 1);
            V v_t_24190 = (g_list_2emap_24s513201124x806973253(v_fs_24137));
            V v_x_24191 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24189, v_t_24190));
            return heff_tag_at_n(v_ru_24it_24135_24MkFields, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24191}), v_st_24187});
          }
          default: return heff_nomatch(v_x11_24186);
          }
        }
        default: return heff_nomatch(v_x1_24185);
        }
      }
      case TAG_Update: {
        V v_m_24198 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24136}));
        V v_x1_24199 = heff_tr(heff_call(v_m_24198, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24199)) {
        case TAG_MkPair: {
          V v_x11_24200 = heff_field(v_x1_24199, 0);
          V v_st_24201 = heff_field(v_x1_24199, 1);
          heff_take_n(v_x1_24199, 3ULL, 2);
          switch (heff_tag_of(v_x11_24200)) {
          case TAG_Left: {
            V v_e_24202 = heff_field(v_x11_24200, 0);
            heff_take_n(v_x11_24200, 1ULL, 1);
            heff_drop(v_fs_24137);
            return heff_tag_at_n(v_ru_24it_24135_24MkFields, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24202}), v_st_24201});
          }
          case TAG_Right: {
            V v_x_24203 = heff_field(v_x11_24200, 0);
            heff_take_n(v_x11_24200, 1ULL, 1);
            V v_t_24204 = (g_list_2emap_24s513201124x806973253(v_fs_24137));
            V v_x_24205 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24203, v_t_24204));
            return heff_tag_at_n(v_ru_24it_24135_24MkFields, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24205}), v_st_24201});
          }
          default: return heff_nomatch(v_x11_24200);
          }
        }
        default: return heff_nomatch(v_x1_24199);
        }
      }
      case TAG_EUSet: {
        V v_m_24209 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24136}));
        V v_x1_24210 = heff_tr(heff_call(v_m_24209, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24210)) {
        case TAG_MkPair: {
          V v_x11_24211 = heff_field(v_x1_24210, 0);
          V v_st_24212 = heff_field(v_x1_24210, 1);
          heff_take_n(v_x1_24210, 3ULL, 2);
          switch (heff_tag_of(v_x11_24211)) {
          case TAG_Left: {
            V v_e_24213 = heff_field(v_x11_24211, 0);
            heff_take_n(v_x11_24211, 1ULL, 1);
            heff_drop(v_fs_24137);
            return heff_tag_at_n(v_ru_24it_24135_24MkFields, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24213}), v_st_24212});
          }
          case TAG_Right: {
            V v_x_24214 = heff_field(v_x11_24211, 0);
            heff_take_n(v_x11_24211, 1ULL, 1);
            V v_t_24215 = (g_list_2emap_24s513201124x806973253(v_fs_24137));
            V v_x_24216 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24214, v_t_24215));
            return heff_tag_at_n(v_ru_24it_24135_24MkFields, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24216}), v_st_24212});
          }
          default: return heff_nomatch(v_x11_24211);
          }
        }
        default: return heff_nomatch(v_x1_24210);
        }
      }
      case TAG_InstB: {
        V v_m_24222 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24136}));
        V v_x1_24223 = heff_tr(heff_call(v_m_24222, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24223)) {
        case TAG_MkPair: {
          V v_x11_24224 = heff_field(v_x1_24223, 0);
          V v_st_24225 = heff_field(v_x1_24223, 1);
          heff_take_n(v_x1_24223, 3ULL, 2);
          switch (heff_tag_of(v_x11_24224)) {
          case TAG_Left: {
            V v_e_24226 = heff_field(v_x11_24224, 0);
            heff_take_n(v_x11_24224, 1ULL, 1);
            heff_drop(v_fs_24137);
            return heff_tag_at_n(v_ru_24it_24135_24MkFields, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24226}), v_st_24225});
          }
          case TAG_Right: {
            V v_x_24227 = heff_field(v_x11_24224, 0);
            heff_take_n(v_x11_24224, 1ULL, 1);
            V v_t_24228 = (g_list_2emap_24s513201124x806973253(v_fs_24137));
            V v_x_24229 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24227, v_t_24228));
            return heff_tag_at_n(v_ru_24it_24135_24MkFields, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24229}), v_st_24225});
          }
          default: return heff_nomatch(v_x11_24224);
          }
        }
        default: return heff_nomatch(v_x1_24223);
        }
      }
      case TAG_EFSet: {
        V v_m_24233 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24136}));
        V v_x1_24234 = heff_tr(heff_call(v_m_24233, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24234)) {
        case TAG_MkPair: {
          V v_x11_24235 = heff_field(v_x1_24234, 0);
          V v_st_24236 = heff_field(v_x1_24234, 1);
          heff_take_n(v_x1_24234, 3ULL, 2);
          switch (heff_tag_of(v_x11_24235)) {
          case TAG_Left: {
            V v_e_24237 = heff_field(v_x11_24235, 0);
            heff_take_n(v_x11_24235, 1ULL, 1);
            heff_drop(v_fs_24137);
            return heff_tag_at_n(v_ru_24it_24135_24MkFields, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24237}), v_st_24236});
          }
          case TAG_Right: {
            V v_x_24238 = heff_field(v_x11_24235, 0);
            heff_take_n(v_x11_24235, 1ULL, 1);
            V v_t_24239 = (g_list_2emap_24s513201124x806973253(v_fs_24137));
            V v_x_24240 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24238, v_t_24239));
            return heff_tag_at_n(v_ru_24it_24135_24MkFields, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24240}), v_st_24236});
          }
          default: return heff_nomatch(v_x11_24235);
          }
        }
        default: return heff_nomatch(v_x1_24234);
        }
      }
      case TAG_EFDefault: {
        V v_m_24244 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24136}));
        V v_x1_24245 = heff_tr(heff_call(v_m_24244, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24245)) {
        case TAG_MkPair: {
          V v_x11_24246 = heff_field(v_x1_24245, 0);
          V v_st_24247 = heff_field(v_x1_24245, 1);
          heff_take_n(v_x1_24245, 3ULL, 2);
          switch (heff_tag_of(v_x11_24246)) {
          case TAG_Left: {
            V v_e_24248 = heff_field(v_x11_24246, 0);
            heff_take_n(v_x11_24246, 1ULL, 1);
            heff_drop(v_fs_24137);
            return heff_tag_at_n(v_ru_24it_24135_24MkFields, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24248}), v_st_24247});
          }
          case TAG_Right: {
            V v_x_24249 = heff_field(v_x11_24246, 0);
            heff_take_n(v_x11_24246, 1ULL, 1);
            V v_t_24250 = (g_list_2emap_24s513201124x806973253(v_fs_24137));
            V v_x_24251 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24249, v_t_24250));
            return heff_tag_at_n(v_ru_24it_24135_24MkFields, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24251}), v_st_24247});
          }
          default: return heff_nomatch(v_x11_24246);
          }
        }
        default: return heff_nomatch(v_x1_24245);
        }
      }
      case TAG_Sum: {
        V v_m_24257 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24136}));
        V v_x1_24258 = heff_tr(heff_call(v_m_24257, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24258)) {
        case TAG_MkPair: {
          V v_x11_24259 = heff_field(v_x1_24258, 0);
          V v_st_24260 = heff_field(v_x1_24258, 1);
          heff_take_n(v_x1_24258, 3ULL, 2);
          switch (heff_tag_of(v_x11_24259)) {
          case TAG_Left: {
            V v_e_24261 = heff_field(v_x11_24259, 0);
            heff_take_n(v_x11_24259, 1ULL, 1);
            heff_drop(v_fs_24137);
            return heff_tag_at_n(v_ru_24it_24135_24MkFields, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24261}), v_st_24260});
          }
          case TAG_Right: {
            V v_x_24262 = heff_field(v_x11_24259, 0);
            heff_take_n(v_x11_24259, 1ULL, 1);
            V v_t_24263 = (g_list_2emap_24s513201124x806973253(v_fs_24137));
            V v_x_24264 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24262, v_t_24263));
            return heff_tag_at_n(v_ru_24it_24135_24MkFields, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24264}), v_st_24260});
          }
          default: return heff_nomatch(v_x11_24259);
          }
        }
        default: return heff_nomatch(v_x1_24258);
        }
      }
      case TAG_ECon: {
        V v_m_24267 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24136}));
        V v_x1_24268 = heff_tr(heff_call(v_m_24267, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24268)) {
        case TAG_MkPair: {
          V v_x11_24269 = heff_field(v_x1_24268, 0);
          V v_st_24270 = heff_field(v_x1_24268, 1);
          heff_take_n(v_x1_24268, 3ULL, 2);
          switch (heff_tag_of(v_x11_24269)) {
          case TAG_Left: {
            V v_e_24271 = heff_field(v_x11_24269, 0);
            heff_take_n(v_x11_24269, 1ULL, 1);
            heff_drop(v_fs_24137);
            return heff_tag_at_n(v_ru_24it_24135_24MkFields, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24271}), v_st_24270});
          }
          case TAG_Right: {
            V v_x_24272 = heff_field(v_x11_24269, 0);
            heff_take_n(v_x11_24269, 1ULL, 1);
            V v_t_24273 = (g_list_2emap_24s513201124x806973253(v_fs_24137));
            V v_x_24274 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24272, v_t_24273));
            return heff_tag_at_n(v_ru_24it_24135_24MkFields, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24274}), v_st_24270});
          }
          default: return heff_nomatch(v_x11_24269);
          }
        }
        default: return heff_nomatch(v_x1_24268);
        }
      }
      case TAG_EField: {
        V v_m_24277 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24136}));
        V v_x1_24278 = heff_tr(heff_call(v_m_24277, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24278)) {
        case TAG_MkPair: {
          V v_x11_24279 = heff_field(v_x1_24278, 0);
          V v_st_24280 = heff_field(v_x1_24278, 1);
          heff_take_n(v_x1_24278, 3ULL, 2);
          switch (heff_tag_of(v_x11_24279)) {
          case TAG_Left: {
            V v_e_24281 = heff_field(v_x11_24279, 0);
            heff_take_n(v_x11_24279, 1ULL, 1);
            heff_drop(v_fs_24137);
            return heff_tag_at_n(v_ru_24it_24135_24MkFields, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24281}), v_st_24280});
          }
          case TAG_Right: {
            V v_x_24282 = heff_field(v_x11_24279, 0);
            heff_take_n(v_x11_24279, 1ULL, 1);
            V v_t_24283 = (g_list_2emap_24s513201124x806973253(v_fs_24137));
            V v_x_24284 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24282, v_t_24283));
            return heff_tag_at_n(v_ru_24it_24135_24MkFields, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24284}), v_st_24280});
          }
          default: return heff_nomatch(v_x11_24279);
          }
        }
        default: return heff_nomatch(v_x1_24278);
        }
      }
      case TAG_ENeg: {
        V v_m_24287 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24136}));
        V v_x1_24288 = heff_tr(heff_call(v_m_24287, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24288)) {
        case TAG_MkPair: {
          V v_x11_24289 = heff_field(v_x1_24288, 0);
          V v_st_24290 = heff_field(v_x1_24288, 1);
          heff_take_n(v_x1_24288, 3ULL, 2);
          switch (heff_tag_of(v_x11_24289)) {
          case TAG_Left: {
            V v_e_24291 = heff_field(v_x11_24289, 0);
            heff_take_n(v_x11_24289, 1ULL, 1);
            heff_drop(v_fs_24137);
            return heff_tag_at_n(v_ru_24it_24135_24MkFields, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24291}), v_st_24290});
          }
          case TAG_Right: {
            V v_x_24292 = heff_field(v_x11_24289, 0);
            heff_take_n(v_x11_24289, 1ULL, 1);
            V v_t_24293 = (g_list_2emap_24s513201124x806973253(v_fs_24137));
            V v_x_24294 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24292, v_t_24293));
            return heff_tag_at_n(v_ru_24it_24135_24MkFields, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24294}), v_st_24290});
          }
          default: return heff_nomatch(v_x11_24289);
          }
        }
        default: return heff_nomatch(v_x1_24288);
        }
      }
      case TAG_App: {
        V v_m_24297 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24136}));
        V v_x1_24298 = heff_tr(heff_call(v_m_24297, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24298)) {
        case TAG_MkPair: {
          V v_x11_24299 = heff_field(v_x1_24298, 0);
          V v_st_24300 = heff_field(v_x1_24298, 1);
          heff_take_n(v_x1_24298, 3ULL, 2);
          switch (heff_tag_of(v_x11_24299)) {
          case TAG_Left: {
            V v_e_24301 = heff_field(v_x11_24299, 0);
            heff_take_n(v_x11_24299, 1ULL, 1);
            heff_drop(v_fs_24137);
            return heff_tag_at_n(v_ru_24it_24135_24MkFields, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24301}), v_st_24300});
          }
          case TAG_Right: {
            V v_x_24302 = heff_field(v_x11_24299, 0);
            heff_take_n(v_x11_24299, 1ULL, 1);
            V v_t_24303 = (g_list_2emap_24s513201124x806973253(v_fs_24137));
            V v_x_24304 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24302, v_t_24303));
            return heff_tag_at_n(v_ru_24it_24135_24MkFields, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24304}), v_st_24300});
          }
          default: return heff_nomatch(v_x11_24299);
          }
        }
        default: return heff_nomatch(v_x1_24298);
        }
      }
      case TAG_Op: {
        V v_m_24308 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24136}));
        V v_x1_24309 = heff_tr(heff_call(v_m_24308, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24309)) {
        case TAG_MkPair: {
          V v_x11_24310 = heff_field(v_x1_24309, 0);
          V v_st_24311 = heff_field(v_x1_24309, 1);
          heff_take_n(v_x1_24309, 3ULL, 2);
          switch (heff_tag_of(v_x11_24310)) {
          case TAG_Left: {
            V v_e_24312 = heff_field(v_x11_24310, 0);
            heff_take_n(v_x11_24310, 1ULL, 1);
            heff_drop(v_fs_24137);
            return heff_tag_at_n(v_ru_24it_24135_24MkFields, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24312}), v_st_24311});
          }
          case TAG_Right: {
            V v_x_24313 = heff_field(v_x11_24310, 0);
            heff_take_n(v_x11_24310, 1ULL, 1);
            V v_t_24314 = (g_list_2emap_24s513201124x806973253(v_fs_24137));
            V v_x_24315 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24313, v_t_24314));
            return heff_tag_at_n(v_ru_24it_24135_24MkFields, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24315}), v_st_24311});
          }
          default: return heff_nomatch(v_x11_24310);
          }
        }
        default: return heff_nomatch(v_x1_24309);
        }
      }
      case TAG_Ops: {
        V v_m_24318 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24136}));
        V v_x1_24319 = heff_tr(heff_call(v_m_24318, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24319)) {
        case TAG_MkPair: {
          V v_x11_24320 = heff_field(v_x1_24319, 0);
          V v_st_24321 = heff_field(v_x1_24319, 1);
          heff_take_n(v_x1_24319, 3ULL, 2);
          switch (heff_tag_of(v_x11_24320)) {
          case TAG_Left: {
            V v_e_24322 = heff_field(v_x11_24320, 0);
            heff_take_n(v_x11_24320, 1ULL, 1);
            heff_drop(v_fs_24137);
            return heff_tag_at_n(v_ru_24it_24135_24MkFields, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24322}), v_st_24321});
          }
          case TAG_Right: {
            V v_x_24323 = heff_field(v_x11_24320, 0);
            heff_take_n(v_x11_24320, 1ULL, 1);
            V v_t_24324 = (g_list_2emap_24s513201124x806973253(v_fs_24137));
            V v_x_24325 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24323, v_t_24324));
            return heff_tag_at_n(v_ru_24it_24135_24MkFields, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24325}), v_st_24321});
          }
          default: return heff_nomatch(v_x11_24320);
          }
        }
        default: return heff_nomatch(v_x1_24319);
        }
      }
      case TAG_OpRhs: {
        V v_m_24328 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24136}));
        V v_x1_24329 = heff_tr(heff_call(v_m_24328, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24329)) {
        case TAG_MkPair: {
          V v_x11_24330 = heff_field(v_x1_24329, 0);
          V v_st_24331 = heff_field(v_x1_24329, 1);
          heff_take_n(v_x1_24329, 3ULL, 2);
          switch (heff_tag_of(v_x11_24330)) {
          case TAG_Left: {
            V v_e_24332 = heff_field(v_x11_24330, 0);
            heff_take_n(v_x11_24330, 1ULL, 1);
            heff_drop(v_fs_24137);
            return heff_tag_at_n(v_ru_24it_24135_24MkFields, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24332}), v_st_24331});
          }
          case TAG_Right: {
            V v_x_24333 = heff_field(v_x11_24330, 0);
            heff_take_n(v_x11_24330, 1ULL, 1);
            V v_t_24334 = (g_list_2emap_24s513201124x806973253(v_fs_24137));
            V v_x_24335 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24333, v_t_24334));
            return heff_tag_at_n(v_ru_24it_24135_24MkFields, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24335}), v_st_24331});
          }
          default: return heff_nomatch(v_x11_24330);
          }
        }
        default: return heff_nomatch(v_x1_24329);
        }
      }
      case TAG_Ann: {
        V v_m_24339 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24136}));
        V v_x1_24340 = heff_tr(heff_call(v_m_24339, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24340)) {
        case TAG_MkPair: {
          V v_x11_24341 = heff_field(v_x1_24340, 0);
          V v_st_24342 = heff_field(v_x1_24340, 1);
          heff_take_n(v_x1_24340, 3ULL, 2);
          switch (heff_tag_of(v_x11_24341)) {
          case TAG_Left: {
            V v_e_24343 = heff_field(v_x11_24341, 0);
            heff_take_n(v_x11_24341, 1ULL, 1);
            heff_drop(v_fs_24137);
            return heff_tag_at_n(v_ru_24it_24135_24MkFields, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24343}), v_st_24342});
          }
          case TAG_Right: {
            V v_x_24344 = heff_field(v_x11_24341, 0);
            heff_take_n(v_x11_24341, 1ULL, 1);
            V v_t_24345 = (g_list_2emap_24s513201124x806973253(v_fs_24137));
            V v_x_24346 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24344, v_t_24345));
            return heff_tag_at_n(v_ru_24it_24135_24MkFields, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24346}), v_st_24342});
          }
          default: return heff_nomatch(v_x11_24341);
          }
        }
        default: return heff_nomatch(v_x1_24340);
        }
      }
      case TAG_BVar: {
        V v_m_24348 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24136}));
        V v_x1_24349 = heff_tr(heff_call(v_m_24348, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24349)) {
        case TAG_MkPair: {
          V v_x11_24350 = heff_field(v_x1_24349, 0);
          V v_st_24351 = heff_field(v_x1_24349, 1);
          heff_take_n(v_x1_24349, 3ULL, 2);
          switch (heff_tag_of(v_x11_24350)) {
          case TAG_Left: {
            V v_e_24352 = heff_field(v_x11_24350, 0);
            heff_take_n(v_x11_24350, 1ULL, 1);
            heff_drop(v_fs_24137);
            return heff_tag_at_n(v_ru_24it_24135_24MkFields, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24352}), v_st_24351});
          }
          case TAG_Right: {
            V v_x_24353 = heff_field(v_x11_24350, 0);
            heff_take_n(v_x11_24350, 1ULL, 1);
            V v_t_24354 = (g_list_2emap_24s513201124x806973253(v_fs_24137));
            V v_x_24355 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24353, v_t_24354));
            return heff_tag_at_n(v_ru_24it_24135_24MkFields, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24355}), v_st_24351});
          }
          default: return heff_nomatch(v_x11_24350);
          }
        }
        default: return heff_nomatch(v_x1_24349);
        }
      }
      case TAG_BImp: {
        V v_m_24359 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24136}));
        V v_x1_24360 = heff_tr(heff_call(v_m_24359, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24360)) {
        case TAG_MkPair: {
          V v_x11_24361 = heff_field(v_x1_24360, 0);
          V v_st_24362 = heff_field(v_x1_24360, 1);
          heff_take_n(v_x1_24360, 3ULL, 2);
          switch (heff_tag_of(v_x11_24361)) {
          case TAG_Left: {
            V v_e_24363 = heff_field(v_x11_24361, 0);
            heff_take_n(v_x11_24361, 1ULL, 1);
            heff_drop(v_fs_24137);
            return heff_tag_at_n(v_ru_24it_24135_24MkFields, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24363}), v_st_24362});
          }
          case TAG_Right: {
            V v_x_24364 = heff_field(v_x11_24361, 0);
            heff_take_n(v_x11_24361, 1ULL, 1);
            V v_t_24365 = (g_list_2emap_24s513201124x806973253(v_fs_24137));
            V v_x_24366 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24364, v_t_24365));
            return heff_tag_at_n(v_ru_24it_24135_24MkFields, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24366}), v_st_24362});
          }
          default: return heff_nomatch(v_x11_24361);
          }
        }
        default: return heff_nomatch(v_x1_24360);
        }
      }
      case TAG_BAnn: {
        V v_m_24372 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24136}));
        V v_x1_24373 = heff_tr(heff_call(v_m_24372, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24373)) {
        case TAG_MkPair: {
          V v_x11_24374 = heff_field(v_x1_24373, 0);
          V v_st_24375 = heff_field(v_x1_24373, 1);
          heff_take_n(v_x1_24373, 3ULL, 2);
          switch (heff_tag_of(v_x11_24374)) {
          case TAG_Left: {
            V v_e_24376 = heff_field(v_x11_24374, 0);
            heff_take_n(v_x11_24374, 1ULL, 1);
            heff_drop(v_fs_24137);
            return heff_tag_at_n(v_ru_24it_24135_24MkFields, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24376}), v_st_24375});
          }
          case TAG_Right: {
            V v_x_24377 = heff_field(v_x11_24374, 0);
            heff_take_n(v_x11_24374, 1ULL, 1);
            V v_t_24378 = (g_list_2emap_24s513201124x806973253(v_fs_24137));
            V v_x_24379 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24377, v_t_24378));
            return heff_tag_at_n(v_ru_24it_24135_24MkFields, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24379}), v_st_24375});
          }
          default: return heff_nomatch(v_x11_24374);
          }
        }
        default: return heff_nomatch(v_x1_24373);
        }
      }
      case TAG_Lam: {
        V v_m_24384 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24136}));
        V v_x1_24385 = heff_tr(heff_call(v_m_24384, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24385)) {
        case TAG_MkPair: {
          V v_x11_24386 = heff_field(v_x1_24385, 0);
          V v_st_24387 = heff_field(v_x1_24385, 1);
          heff_take_n(v_x1_24385, 3ULL, 2);
          switch (heff_tag_of(v_x11_24386)) {
          case TAG_Left: {
            V v_e_24388 = heff_field(v_x11_24386, 0);
            heff_take_n(v_x11_24386, 1ULL, 1);
            heff_drop(v_fs_24137);
            return heff_tag_at_n(v_ru_24it_24135_24MkFields, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24388}), v_st_24387});
          }
          case TAG_Right: {
            V v_x_24389 = heff_field(v_x11_24386, 0);
            heff_take_n(v_x11_24386, 1ULL, 1);
            V v_t_24390 = (g_list_2emap_24s513201124x806973253(v_fs_24137));
            V v_x_24391 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24389, v_t_24390));
            return heff_tag_at_n(v_ru_24it_24135_24MkFields, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24391}), v_st_24387});
          }
          default: return heff_nomatch(v_x11_24386);
          }
        }
        default: return heff_nomatch(v_x1_24385);
        }
      }
      case TAG_Case: {
        V v_m_24396 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24136}));
        V v_x1_24397 = heff_tr(heff_call(v_m_24396, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24397)) {
        case TAG_MkPair: {
          V v_x11_24398 = heff_field(v_x1_24397, 0);
          V v_st_24399 = heff_field(v_x1_24397, 1);
          heff_take_n(v_x1_24397, 3ULL, 2);
          switch (heff_tag_of(v_x11_24398)) {
          case TAG_Left: {
            V v_e_24400 = heff_field(v_x11_24398, 0);
            heff_take_n(v_x11_24398, 1ULL, 1);
            heff_drop(v_fs_24137);
            return heff_tag_at_n(v_ru_24it_24135_24MkFields, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24400}), v_st_24399});
          }
          case TAG_Right: {
            V v_x_24401 = heff_field(v_x11_24398, 0);
            heff_take_n(v_x11_24398, 1ULL, 1);
            V v_t_24402 = (g_list_2emap_24s513201124x806973253(v_fs_24137));
            V v_x_24403 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24401, v_t_24402));
            return heff_tag_at_n(v_ru_24it_24135_24MkFields, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24403}), v_st_24399});
          }
          default: return heff_nomatch(v_x11_24398);
          }
        }
        default: return heff_nomatch(v_x1_24397);
        }
      }
      case TAG_EAlt: {
        V v_m_24407 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24136}));
        V v_x1_24408 = heff_tr(heff_call(v_m_24407, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24408)) {
        case TAG_MkPair: {
          V v_x11_24409 = heff_field(v_x1_24408, 0);
          V v_st_24410 = heff_field(v_x1_24408, 1);
          heff_take_n(v_x1_24408, 3ULL, 2);
          switch (heff_tag_of(v_x11_24409)) {
          case TAG_Left: {
            V v_e_24411 = heff_field(v_x11_24409, 0);
            heff_take_n(v_x11_24409, 1ULL, 1);
            heff_drop(v_fs_24137);
            return heff_tag_at_n(v_ru_24it_24135_24MkFields, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24411}), v_st_24410});
          }
          case TAG_Right: {
            V v_x_24412 = heff_field(v_x11_24409, 0);
            heff_take_n(v_x11_24409, 1ULL, 1);
            V v_t_24413 = (g_list_2emap_24s513201124x806973253(v_fs_24137));
            V v_x_24414 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24412, v_t_24413));
            return heff_tag_at_n(v_ru_24it_24135_24MkFields, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24414}), v_st_24410});
          }
          default: return heff_nomatch(v_x11_24409);
          }
        }
        default: return heff_nomatch(v_x1_24408);
        }
      }
      case TAG_If: {
        V v_m_24421 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24136}));
        V v_x1_24422 = heff_tr(heff_call(v_m_24421, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24422)) {
        case TAG_MkPair: {
          V v_x11_24423 = heff_field(v_x1_24422, 0);
          V v_st_24424 = heff_field(v_x1_24422, 1);
          heff_take_n(v_x1_24422, 3ULL, 2);
          switch (heff_tag_of(v_x11_24423)) {
          case TAG_Left: {
            V v_e_24425 = heff_field(v_x11_24423, 0);
            heff_take_n(v_x11_24423, 1ULL, 1);
            heff_drop(v_fs_24137);
            return heff_tag_at_n(v_ru_24it_24135_24MkFields, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24425}), v_st_24424});
          }
          case TAG_Right: {
            V v_x_24426 = heff_field(v_x11_24423, 0);
            heff_take_n(v_x11_24423, 1ULL, 1);
            V v_t_24427 = (g_list_2emap_24s513201124x806973253(v_fs_24137));
            V v_x_24428 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24426, v_t_24427));
            return heff_tag_at_n(v_ru_24it_24135_24MkFields, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24428}), v_st_24424});
          }
          default: return heff_nomatch(v_x11_24423);
          }
        }
        default: return heff_nomatch(v_x1_24422);
        }
      }
      case TAG_Do: {
        V v_m_24431 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24136}));
        V v_x1_24432 = heff_tr(heff_call(v_m_24431, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24432)) {
        case TAG_MkPair: {
          V v_x11_24433 = heff_field(v_x1_24432, 0);
          V v_st_24434 = heff_field(v_x1_24432, 1);
          heff_take_n(v_x1_24432, 3ULL, 2);
          switch (heff_tag_of(v_x11_24433)) {
          case TAG_Left: {
            V v_e_24435 = heff_field(v_x11_24433, 0);
            heff_take_n(v_x11_24433, 1ULL, 1);
            heff_drop(v_fs_24137);
            return heff_tag_at_n(v_ru_24it_24135_24MkFields, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24435}), v_st_24434});
          }
          case TAG_Right: {
            V v_x_24436 = heff_field(v_x11_24433, 0);
            heff_take_n(v_x11_24433, 1ULL, 1);
            V v_t_24437 = (g_list_2emap_24s513201124x806973253(v_fs_24137));
            V v_x_24438 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24436, v_t_24437));
            return heff_tag_at_n(v_ru_24it_24135_24MkFields, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24438}), v_st_24434});
          }
          default: return heff_nomatch(v_x11_24433);
          }
        }
        default: return heff_nomatch(v_x1_24432);
        }
      }
      case TAG_ESBind: {
        V v_m_24442 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24136}));
        V v_x1_24443 = heff_tr(heff_call(v_m_24442, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24443)) {
        case TAG_MkPair: {
          V v_x11_24444 = heff_field(v_x1_24443, 0);
          V v_st_24445 = heff_field(v_x1_24443, 1);
          heff_take_n(v_x1_24443, 3ULL, 2);
          switch (heff_tag_of(v_x11_24444)) {
          case TAG_Left: {
            V v_e_24446 = heff_field(v_x11_24444, 0);
            heff_take_n(v_x11_24444, 1ULL, 1);
            heff_drop(v_fs_24137);
            return heff_tag_at_n(v_ru_24it_24135_24MkFields, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24446}), v_st_24445});
          }
          case TAG_Right: {
            V v_x_24447 = heff_field(v_x11_24444, 0);
            heff_take_n(v_x11_24444, 1ULL, 1);
            V v_t_24448 = (g_list_2emap_24s513201124x806973253(v_fs_24137));
            V v_x_24449 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24447, v_t_24448));
            return heff_tag_at_n(v_ru_24it_24135_24MkFields, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24449}), v_st_24445});
          }
          default: return heff_nomatch(v_x11_24444);
          }
        }
        default: return heff_nomatch(v_x1_24443);
        }
      }
      case TAG_ELet: {
        V v_m_24456 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24136}));
        V v_x1_24457 = heff_tr(heff_call(v_m_24456, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24457)) {
        case TAG_MkPair: {
          V v_x11_24458 = heff_field(v_x1_24457, 0);
          V v_st_24459 = heff_field(v_x1_24457, 1);
          heff_take_n(v_x1_24457, 3ULL, 2);
          switch (heff_tag_of(v_x11_24458)) {
          case TAG_Left: {
            V v_e_24460 = heff_field(v_x11_24458, 0);
            heff_take_n(v_x11_24458, 1ULL, 1);
            heff_drop(v_fs_24137);
            return heff_tag_at_n(v_ru_24it_24135_24MkFields, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24460}), v_st_24459});
          }
          case TAG_Right: {
            V v_x_24461 = heff_field(v_x11_24458, 0);
            heff_take_n(v_x11_24458, 1ULL, 1);
            V v_t_24462 = (g_list_2emap_24s513201124x806973253(v_fs_24137));
            V v_x_24463 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24461, v_t_24462));
            return heff_tag_at_n(v_ru_24it_24135_24MkFields, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24463}), v_st_24459});
          }
          default: return heff_nomatch(v_x11_24458);
          }
        }
        default: return heff_nomatch(v_x1_24457);
        }
      }
      default: return heff_nomatch(v_it1_24136);
      }
    }
    default: return heff_nomatch(v_it_24135);
    }
  }
  case TAG_ENeg: {
    V v_m_24464 = heff_field(v_e0_241, 0);
    V v_e_24465 = heff_field(v_e0_241, 1);
    V v_ru_24e0_241_24ENeg = heff_take_reuse_n(v_e0_241, 3ULL, 2);
    V v_m_24466 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_24465}));
    V v_x1_24467 = heff_tr(heff_call(v_m_24466, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x1_24467)) {
    case TAG_MkPair: {
      V v_x11_24468 = heff_field(v_x1_24467, 0);
      V v_st_24469 = heff_field(v_x1_24467, 1);
      V v_ru_24x1_24467_24MkPair = heff_take_reuse_n(v_x1_24467, 3ULL, 2);
      switch (heff_tag_of(v_x11_24468)) {
      case TAG_Left: {
        V v_e_24470 = heff_field(v_x11_24468, 0);
        heff_take_n(v_x11_24468, 1ULL, 1);
        heff_drop_rec(v_m_24464, 9);
        heff_drop_cell(v_ru_24x1_24467_24MkPair, 2);
        return heff_tag_at_n(v_ru_24e0_241_24ENeg, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24470}), v_st_24469});
      }
      case TAG_Right: {
        V v_x_24471 = heff_field(v_x11_24468, 0);
        V v_ru_24x11_24468_24Right = heff_take_reuse_n(v_x11_24468, 1ULL, 1);
        V v_t_24472 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_m_24464, 3), heff_get_n(v_m_24464, 4, 9)});
        V v_t_24473 = heff_tag_at_n(v_ru_24e0_241_24ENeg, TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2eexprL_str17)}), v_t_24472});
        V v_t_24474 = heff_tag_at_n(v_ru_24x1_24467_24MkPair, TAG_Cons, 2, (V[]){v_x_24471, NTAG(TAG_Nil)});
        V v_x_24475 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_24473, v_t_24474));
        return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_24468_24Right, TAG_Right, 1, (V[]){v_x_24475}), v_st_24469});
      }
      default: return heff_nomatch(v_x11_24468);
      }
    }
    default: return heff_nomatch(v_x1_24467);
    }
  }
  case TAG_App: {
    V v_h_24476 = heff_field(v_e0_241, 0);
    V v_args_24477 = heff_field(v_e0_241, 1);
    V v_ru_24e0_241_24App = heff_take_reuse_n(v_e0_241, 3ULL, 2);
    V v_m_24478 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_h_24476}));
    V v_x1_24479 = heff_tr(heff_call(v_m_24478, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x1_24479)) {
    case TAG_MkPair: {
      V v_x11_24480 = heff_field(v_x1_24479, 0);
      V v_st_24481 = heff_field(v_x1_24479, 1);
      heff_take_n(v_x1_24479, 3ULL, 2);
      switch (heff_tag_of(v_x11_24480)) {
      case TAG_Left: {
        V v_e_24482 = heff_field(v_x11_24480, 0);
        heff_take_n(v_x11_24480, 1ULL, 1);
        heff_drop_rec(v_r_240, 3);
        heff_drop(v_args_24477);
        return heff_tag_at_n(v_ru_24e0_241_24App, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24482}), v_st_24481});
      }
      case TAG_Right: {
        V v_x_24483 = heff_field(v_x11_24480, 0);
        heff_take_n(v_x11_24480, 1ULL, 1);
        V v_m_24485 = (g_heff_2esyntax_2esurface_2etraverseS(heff_clo_n(g_heff_2esyntax_2esurface_2eexprL_lam3, 1, 1, (V[]){v_r_240}), v_args_24477));
        V v_x1_24486 = heff_tr(heff_call(v_m_24485, 1, (V[]){v_st_24481}));
        switch (heff_tag_of(v_x1_24486)) {
        case TAG_MkPair: {
          V v_x11_24487 = heff_field(v_x1_24486, 0);
          V v_st_24488 = heff_field(v_x1_24486, 1);
          heff_take_n(v_x1_24486, 3ULL, 2);
          switch (heff_tag_of(v_x11_24487)) {
          case TAG_Left: {
            V v_e_24489 = heff_field(v_x11_24487, 0);
            heff_take_n(v_x11_24487, 1ULL, 1);
            heff_drop(v_x_24483);
            return heff_tag_at_n(v_ru_24e0_241_24App, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24489}), v_st_24488});
          }
          case TAG_Right: {
            V v_x_24490 = heff_field(v_x11_24487, 0);
            heff_take_n(v_x11_24487, 1ULL, 1);
            V v_x_24491 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24483, v_x_24490));
            return heff_tag_at_n(v_ru_24e0_241_24App, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24491}), v_st_24488});
          }
          default: return heff_nomatch(v_x11_24487);
          }
        }
        default: return heff_nomatch(v_x1_24486);
        }
      }
      default: return heff_nomatch(v_x11_24480);
      }
    }
    default: return heff_nomatch(v_x1_24479);
    }
  }
  case TAG_Op: {
    V v_a_24492 = heff_field(v_e0_241, 0);
    V v_op_24493 = heff_field(v_e0_241, 1);
    V v_b_24494 = heff_field(v_e0_241, 2);
    heff_take_n(v_e0_241, 7ULL, 3);
    return (g_heff_2esyntax_2esurface_2eopL(v_r_240, v_a_24492, v_op_24493, v_b_24494, v_z_242));
  }
  case TAG_Ops: {
    V v_a_24495 = heff_field(v_e0_241, 0);
    V v_rest_24496 = heff_field(v_e0_241, 1);
    V v_ru_24e0_241_24Ops = heff_take_reuse_n(v_e0_241, 3ULL, 2);
    V v_m_24497 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_24495}));
    V v_x1_24498 = heff_tr(heff_call(v_m_24497, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x1_24498)) {
    case TAG_MkPair: {
      V v_x11_24499 = heff_field(v_x1_24498, 0);
      V v_st_24500 = heff_field(v_x1_24498, 1);
      heff_take_n(v_x1_24498, 3ULL, 2);
      switch (heff_tag_of(v_x11_24499)) {
      case TAG_Left: {
        V v_e_24501 = heff_field(v_x11_24499, 0);
        heff_take_n(v_x11_24499, 1ULL, 1);
        heff_drop_rec(v_r_240, 3);
        heff_drop(v_rest_24496);
        return heff_tag_at_n(v_ru_24e0_241_24Ops, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24501}), v_st_24500});
      }
      case TAG_Right: {
        V v_x_24502 = heff_field(v_x11_24499, 0);
        heff_take_n(v_x11_24499, 1ULL, 1);
        V v_m_24515 = (g_heff_2esyntax_2esurface_2etraverseS(heff_clo_n(g_heff_2esyntax_2esurface_2eexprL_lam4, 1, 1, (V[]){v_r_240}), v_rest_24496));
        V v_x1_24516 = heff_tr(heff_call(v_m_24515, 1, (V[]){v_st_24500}));
        switch (heff_tag_of(v_x1_24516)) {
        case TAG_MkPair: {
          V v_x11_24517 = heff_field(v_x1_24516, 0);
          V v_st_24518 = heff_field(v_x1_24516, 1);
          heff_take_n(v_x1_24516, 3ULL, 2);
          switch (heff_tag_of(v_x11_24517)) {
          case TAG_Left: {
            V v_e_24519 = heff_field(v_x11_24517, 0);
            heff_take_n(v_x11_24517, 1ULL, 1);
            heff_drop(v_x_24502);
            return heff_tag_at_n(v_ru_24e0_241_24Ops, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24519}), v_st_24518});
          }
          case TAG_Right: {
            V v_x_24520 = heff_field(v_x11_24517, 0);
            heff_take_n(v_x11_24517, 1ULL, 1);
            heff_drop_cell(v_ru_24e0_241_24Ops, 2);
            HEFF_LAST return g_heff_2esyntax_2esurface_2eresolve_24s1832151779x1448561609(v_x_24502, v_x_24520, v_st_24518);
          }
          default: return heff_nomatch(v_x11_24517);
          }
        }
        default: return heff_nomatch(v_x1_24516);
        }
      }
      default: return heff_nomatch(v_x11_24499);
      }
    }
    default: return heff_nomatch(v_x1_24498);
    }
  }
  case TAG_OpRhs: {
    heff_drop_rec(v_r_240, 3);
    V v_t_24523 = (g_heff_2esyntax_2ecst_2efirstE(v_e0_241));
    V v_t_24524 = ({ V a_0 = v_e0_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e0_241, 2); r_; });
    V v_t_24525 = heff_strAppend(heff_get_n(v_t_24524, 1, 9), ((V)&g_heff_2esyntax_2esurface_2eexprL_str18));
    V v_msg_24526 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eexprL_str19), v_t_24525);
    V v_t_24527 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24523, 3), heff_get_n(v_t_24523, 4, 9)});
    V v_t_24528 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24526, v_t_24527, NTAG(TAG_Nothing)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24528}), v_z_242});
  }
  case TAG_Ann: {
    V v_e_24529 = heff_field(v_e0_241, 0);
    V v_ty_24531 = heff_field(v_e0_241, 2);
    heff_take_n(v_e0_241, 5ULL, 3);
    V v_m_24532 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e_24529}));
    V v_x1_24533 = heff_tr(heff_call(v_m_24532, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x1_24533)) {
    case TAG_MkPair: {
      V v_x11_24534 = heff_field(v_x1_24533, 0);
      V v_st_24535 = heff_field(v_x1_24533, 1);
      V v_ru_24x1_24533_24MkPair = heff_take_reuse_n(v_x1_24533, 3ULL, 2);
      switch (heff_tag_of(v_x11_24534)) {
      case TAG_Left: {
        V v_e_24536 = heff_field(v_x11_24534, 0);
        heff_take_n(v_x11_24534, 1ULL, 1);
        heff_drop_rec(v_r_240, 3);
        heff_drop(v_ty_24531);
        return heff_tag_at_n(v_ru_24x1_24533_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24536}), v_st_24535});
      }
      case TAG_Right: {
        V v_x_24537 = heff_field(v_x11_24534, 0);
        V v_ru_24x11_24534_24Right = heff_take_reuse_n(v_x11_24534, 1ULL, 1);
        V v_m_24538 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_ty_24531}));
        V v_x1_24539 = heff_tr(heff_call(v_m_24538, 1, (V[]){v_st_24535}));
        switch (heff_tag_of(v_x1_24539)) {
        case TAG_MkPair: {
          V v_x11_24540 = heff_field(v_x1_24539, 0);
          V v_st_24541 = heff_field(v_x1_24539, 1);
          V v_ru_24x1_24539_24MkPair = heff_take_reuse_n(v_x1_24539, 3ULL, 2);
          switch (heff_tag_of(v_x11_24540)) {
          case TAG_Left: {
            V v_e_24542 = heff_field(v_x11_24540, 0);
            heff_take_n(v_x11_24540, 1ULL, 1);
            heff_drop(v_x_24537);
            heff_drop_cell(v_ru_24x11_24534_24Right, 1);
            heff_drop_cell(v_ru_24x1_24539_24MkPair, 2);
            return heff_tag_at_n(v_ru_24x1_24533_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24542}), v_st_24541});
          }
          case TAG_Right: {
            V v_x_24543 = heff_field(v_x11_24540, 0);
            heff_take_n(v_x11_24540, 1ULL, 1);
            V v_a_24546;
            switch (heff_tag_of(v_x_24537)) {
            case TAG_At: {
              V v_s_24545 = heff_dup(heff_field(v_x_24537, 1));
              v_a_24546 = v_s_24545;
              break;
            }
            default: heff_nomatch(v_x_24537);
            }
            V v_b_24549;
            switch (heff_tag_of(v_x_24543)) {
            case TAG_At: {
              V v_s_24548 = heff_dup(heff_field(v_x_24543, 1));
              v_b_24549 = v_s_24548;
              break;
            }
            default: heff_nomatch(v_x_24543);
            }
            V v_t_24550 = ({ V rv_1 = heff_get_n(v_b_24549, 1, 2); V rr_ = heff_rec_reuse_nf(v_a_24546, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
            V v_x_24551 = heff_tag_at_n(v_ru_24x1_24533_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_EAnn, 2, (V[]){v_x_24537, v_x_24543}), v_t_24550});
            return heff_tag_at_n(v_ru_24x1_24539_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_24534_24Right, TAG_Right, 1, (V[]){v_x_24551}), v_st_24541});
          }
          default: return heff_nomatch(v_x11_24540);
          }
        }
        default: return heff_nomatch(v_x1_24539);
        }
      }
      default: return heff_nomatch(v_x11_24534);
      }
    }
    default: return heff_nomatch(v_x1_24533);
    }
  }
  case TAG_BVar: {
    heff_drop_rec(v_r_240, 3);
    V v_t_24553 = (g_heff_2esyntax_2ecst_2efirstE(v_e0_241));
    V v_t_24554 = ({ V a_0 = v_e0_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e0_241, 1); r_; });
    V v_t_24555 = heff_strAppend(heff_get_n(v_t_24554, 1, 9), ((V)&g_heff_2esyntax_2esurface_2eexprL_str20));
    V v_msg_24556 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eexprL_str21), v_t_24555);
    V v_t_24557 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24553, 3), heff_get_n(v_t_24553, 4, 9)});
    V v_t_24558 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24556, v_t_24557, NTAG(TAG_Nothing)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24558}), v_z_242});
  }
  case TAG_BImp: {
    heff_drop_rec(v_r_240, 3);
    V v_t_24562 = (g_heff_2esyntax_2ecst_2efirstE(v_e0_241));
    V v_t_24563 = ({ V a_0 = v_e0_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e0_241, 3); r_; });
    V v_t_24564 = heff_strAppend(heff_get_n(v_t_24563, 1, 9), ((V)&g_heff_2esyntax_2esurface_2eexprL_str22));
    V v_msg_24565 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eexprL_str23), v_t_24564);
    V v_t_24566 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24562, 3), heff_get_n(v_t_24562, 4, 9)});
    V v_t_24567 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24565, v_t_24566, NTAG(TAG_Nothing)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24567}), v_z_242});
  }
  case TAG_BAnn: {
    heff_drop_rec(v_r_240, 3);
    V v_t_24573 = (g_heff_2esyntax_2ecst_2efirstE(v_e0_241));
    V v_t_24574 = ({ V a_0 = v_e0_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e0_241, 5); r_; });
    V v_t_24575 = heff_strAppend(heff_get_n(v_t_24574, 1, 9), ((V)&g_heff_2esyntax_2esurface_2eexprL_str24));
    V v_msg_24576 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eexprL_str25), v_t_24575);
    V v_t_24577 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24573, 3), heff_get_n(v_t_24573, 4, 9)});
    V v_t_24578 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24576, v_t_24577, NTAG(TAG_Nothing)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24578}), v_z_242});
  }
  case TAG_Lam: {
    V v_binders_24580 = heff_field(v_e0_241, 1);
    V v_body_24582 = heff_field(v_e0_241, 3);
    heff_take_n(v_e0_241, 10ULL, 4);
    return (g_heff_2esyntax_2esurface_2elambdaL(v_r_240, v_binders_24580, v_body_24582, v_z_242));
  }
  case TAG_Case: {
    V v_kw_24583 = heff_dup(heff_field(v_e0_241, 0));
    V v_scrut_24584 = heff_dup(heff_field(v_e0_241, 1));
    V v_alts_24586 = heff_dup(heff_field(v_e0_241, 3));
    V v_m_24587 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_scrut_24584}));
    V v_x1_24588 = heff_tr(heff_call(v_m_24587, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x1_24588)) {
    case TAG_MkPair: {
      V v_x11_24589 = heff_field(v_x1_24588, 0);
      V v_st_24590 = heff_field(v_x1_24588, 1);
      V v_ru_24x1_24588_24MkPair = heff_take_reuse_n(v_x1_24588, 3ULL, 2);
      switch (heff_tag_of(v_x11_24589)) {
      case TAG_Left: {
        V v_e_24591 = heff_field(v_x11_24589, 0);
        heff_take_n(v_x11_24589, 1ULL, 1);
        heff_drop_rec(v_r_240, 3);
        heff_drop_tag(v_e0_241, 4);
        heff_drop_rec(v_kw_24583, 9);
        heff_drop(v_alts_24586);
        return heff_tag_at_n(v_ru_24x1_24588_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24591}), v_st_24590});
      }
      case TAG_Right: {
        V v_x_24592 = heff_field(v_x11_24589, 0);
        V v_ru_24x11_24589_24Right = heff_take_reuse_n(v_x11_24589, 1ULL, 1);
        V v_x1_24594 = (g_heff_2esyntax_2esurface_2eblock(heff_clo_n(g_heff_2esyntax_2esurface_2eexprL_lam6, 1, 1, (V[]){v_r_240}), v_alts_24586, v_st_24590));
        switch (heff_tag_of(v_x1_24594)) {
        case TAG_MkPair: {
          V v_x11_24595 = heff_field(v_x1_24594, 0);
          V v_st_24596 = heff_field(v_x1_24594, 1);
          V v_ru_24x1_24594_24MkPair = heff_take_reuse_n(v_x1_24594, 3ULL, 2);
          switch (heff_tag_of(v_x11_24595)) {
          case TAG_Left: {
            V v_e_24597 = heff_field(v_x11_24595, 0);
            heff_take_n(v_x11_24595, 1ULL, 1);
            heff_drop_tag(v_e0_241, 4);
            heff_drop_rec(v_kw_24583, 9);
            heff_drop(v_x_24592);
            heff_drop_cell(v_ru_24x11_24589_24Right, 1);
            heff_drop_cell(v_ru_24x1_24594_24MkPair, 2);
            return heff_tag_at_n(v_ru_24x1_24588_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24597}), v_st_24596});
          }
          case TAG_Right: {
            V v_x_24598 = heff_field(v_x11_24595, 0);
            heff_take_n(v_x11_24595, 1ULL, 1);
            V v_t_24599 = (g_heff_2esyntax_2ecst_2elastE(v_e0_241));
            V v_e_24600 = heff_get_n(v_t_24599, 4, 9);
            V v_t_24601 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_24583, 3, 9), v_e_24600});
            V v_x_24602 = heff_tag_at_n(v_ru_24x1_24588_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_x_24592, v_x_24598}), v_t_24601});
            return heff_tag_at_n(v_ru_24x1_24594_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_24589_24Right, TAG_Right, 1, (V[]){v_x_24602}), v_st_24596});
          }
          default: return heff_nomatch(v_x11_24595);
          }
        }
        default: return heff_nomatch(v_x1_24594);
        }
      }
      default: return heff_nomatch(v_x11_24589);
      }
    }
    default: return heff_nomatch(v_x1_24588);
    }
  }
  case TAG_EAlt: {
    heff_drop_rec(v_r_240, 3);
    V v_t_24606 = (g_heff_2esyntax_2ecst_2efirstE(v_e0_241));
    V v_t_24607 = ({ V a_0 = v_e0_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e0_241, 3); r_; });
    V v_t_24608 = heff_strAppend(heff_get_n(v_t_24607, 1, 9), ((V)&g_heff_2esyntax_2esurface_2eexprL_str26));
    V v_msg_24609 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eexprL_str27), v_t_24608);
    V v_t_24610 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24606, 3), heff_get_n(v_t_24606, 4, 9)});
    V v_t_24611 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24609, v_t_24610, NTAG(TAG_Nothing)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24611}), v_z_242});
  }
  case TAG_If: {
    V v_kw_24612 = heff_field(v_e0_241, 0);
    V v_c_24613 = heff_field(v_e0_241, 1);
    V v_a_24615 = heff_field(v_e0_241, 3);
    V v_b_24617 = heff_field(v_e0_241, 5);
    heff_take_n(v_e0_241, 43ULL, 6);
    V v_m_24618 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_c_24613}));
    V v_x1_24619 = heff_tr(heff_call(v_m_24618, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x1_24619)) {
    case TAG_MkPair: {
      V v_x11_24620 = heff_field(v_x1_24619, 0);
      V v_st_24621 = heff_field(v_x1_24619, 1);
      V v_ru_24x1_24619_24MkPair = heff_take_reuse_n(v_x1_24619, 3ULL, 2);
      switch (heff_tag_of(v_x11_24620)) {
      case TAG_Left: {
        V v_e_24622 = heff_field(v_x11_24620, 0);
        heff_take_n(v_x11_24620, 1ULL, 1);
        heff_drop_rec(v_r_240, 3);
        heff_drop_rec(v_kw_24612, 9);
        heff_drop(v_a_24615);
        heff_drop(v_b_24617);
        return heff_tag_at_n(v_ru_24x1_24619_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24622}), v_st_24621});
      }
      case TAG_Right: {
        V v_x_24623 = heff_field(v_x11_24620, 0);
        heff_take_n(v_x11_24620, 1ULL, 1);
        V v_m_24624 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_24615}));
        V v_x1_24625 = heff_tr(heff_call(v_m_24624, 1, (V[]){v_st_24621}));
        switch (heff_tag_of(v_x1_24625)) {
        case TAG_MkPair: {
          V v_x11_24626 = heff_field(v_x1_24625, 0);
          V v_st_24627 = heff_field(v_x1_24625, 1);
          heff_take_n(v_x1_24625, 3ULL, 2);
          switch (heff_tag_of(v_x11_24626)) {
          case TAG_Left: {
            V v_e_24628 = heff_field(v_x11_24626, 0);
            heff_take_n(v_x11_24626, 1ULL, 1);
            heff_drop_rec(v_r_240, 3);
            heff_drop_rec(v_kw_24612, 9);
            heff_drop(v_b_24617);
            heff_drop(v_x_24623);
            return heff_tag_at_n(v_ru_24x1_24619_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24628}), v_st_24627});
          }
          case TAG_Right: {
            V v_x_24629 = heff_field(v_x11_24626, 0);
            heff_take_n(v_x11_24626, 1ULL, 1);
            V v_m_24630 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_b_24617)}));
            V v_x1_24631 = heff_tr(heff_call(v_m_24630, 1, (V[]){v_st_24627}));
            switch (heff_tag_of(v_x1_24631)) {
            case TAG_MkPair: {
              V v_x11_24632 = heff_field(v_x1_24631, 0);
              V v_st_24633 = heff_field(v_x1_24631, 1);
              heff_take_n(v_x1_24631, 3ULL, 2);
              switch (heff_tag_of(v_x11_24632)) {
              case TAG_Left: {
                V v_e_24634 = heff_field(v_x11_24632, 0);
                heff_take_n(v_x11_24632, 1ULL, 1);
                heff_drop_rec(v_kw_24612, 9);
                heff_drop(v_b_24617);
                heff_drop(v_x_24623);
                heff_drop(v_x_24629);
                return heff_tag_at_n(v_ru_24x1_24619_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24634}), v_st_24633});
              }
              case TAG_Right: {
                V v_x_24635 = heff_field(v_x11_24632, 0);
                heff_take_n(v_x11_24632, 1ULL, 1);
                V v_t_24636 = (g_heff_2esyntax_2ecst_2elastE(v_b_24617));
                V v_e_24637 = heff_get_n(v_t_24636, 4, 9);
                V v_t_24638 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_24612, 3, 9), v_e_24637});
                V v_x_24639 = (g_heff_2esyntax_2esurface_2eifE(v_t_24638, v_x_24623, v_x_24629, v_x_24635));
                return heff_tag_at_n(v_ru_24x1_24619_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24639}), v_st_24633});
              }
              default: return heff_nomatch(v_x11_24632);
              }
            }
            default: return heff_nomatch(v_x1_24631);
            }
          }
          default: return heff_nomatch(v_x11_24626);
          }
        }
        default: return heff_nomatch(v_x1_24625);
        }
      }
      default: return heff_nomatch(v_x11_24620);
      }
    }
    default: return heff_nomatch(v_x1_24619);
    }
  }
  case TAG_Do: {
    V v_kw_24640 = heff_dup(heff_field(v_e0_241, 0));
    V v_stmts_24641 = heff_dup(heff_field(v_e0_241, 1));
    V v_x1_24643 = (g_heff_2esyntax_2esurface_2eblock(heff_clo_n(g_heff_2esyntax_2esurface_2eexprL_lam7, 1, 1, (V[]){v_r_240}), v_stmts_24641, v_z_242));
    switch (heff_tag_of(v_x1_24643)) {
    case TAG_MkPair: {
      V v_x11_24644 = heff_field(v_x1_24643, 0);
      V v_st_24645 = heff_field(v_x1_24643, 1);
      V v_ru_24x1_24643_24MkPair = heff_take_reuse_n(v_x1_24643, 3ULL, 2);
      switch (heff_tag_of(v_x11_24644)) {
      case TAG_Left: {
        V v_e_24646 = heff_field(v_x11_24644, 0);
        heff_take_n(v_x11_24644, 1ULL, 1);
        heff_drop_tag(v_e0_241, 2);
        heff_drop_rec(v_kw_24640, 9);
        return heff_tag_at_n(v_ru_24x1_24643_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24646}), v_st_24645});
      }
      case TAG_Right: {
        V v_x_24647 = heff_field(v_x11_24644, 0);
        V v_ru_24x11_24644_24Right = heff_take_reuse_n(v_x11_24644, 1ULL, 1);
        V v_t_24648 = (g_heff_2esyntax_2ecst_2elastE(v_e0_241));
        V v_e_24649 = heff_get_n(v_t_24648, 4, 9);
        V v_t_24650 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_24640, 3, 9), v_e_24649});
        V v_x_24651 = heff_tag_at_n(v_ru_24x1_24643_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_EDo, 1, (V[]){v_x_24647}), v_t_24650});
        return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_24644_24Right, TAG_Right, 1, (V[]){v_x_24651}), v_st_24645});
      }
      default: return heff_nomatch(v_x11_24644);
      }
    }
    default: return heff_nomatch(v_x1_24643);
    }
  }
  case TAG_ESBind: {
    heff_drop_rec(v_r_240, 3);
    V v_t_24655 = (g_heff_2esyntax_2ecst_2efirstE(v_e0_241));
    V v_t_24656 = ({ V a_0 = v_e0_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e0_241, 3); r_; });
    V v_t_24657 = heff_strAppend(heff_get_n(v_t_24656, 1, 9), ((V)&g_heff_2esyntax_2esurface_2eexprL_str28));
    V v_msg_24658 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eexprL_str29), v_t_24657);
    V v_t_24659 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24655, 3), heff_get_n(v_t_24655, 4, 9)});
    V v_t_24660 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24658, v_t_24659, NTAG(TAG_Nothing)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24660}), v_z_242});
  }
  case TAG_ELet: {
    HEFF_LAST return g_heff_2esyntax_2esurface_2eletL(v_r_240, v_e0_241, v_z_242);
  }
  default: return heff_nomatch(v_e0_241);
  }
}
V g_heff_2esyntax_2esurface_2eexprL_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2eexprL(a[0], a[1], a[2]);
}
V g_heff_2esyntax_2esurface_2eexprL_lam0(V self, V *args) {
  V v_x_2438 = args[0];
  V v_rest_2439 = args[1];
  V v_sp_2436 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2440 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ETag, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2eexprL_str6)}), v_sp_2436});
  V v_t_2441 = heff_tag_n(TAG_Cons, 2, (V[]){v_rest_2439, NTAG(TAG_Nil)});
  return (g_heff_2esyntax_2epresyntax_2eapp(v_t_2440, heff_tag_n(TAG_Cons, 2, (V[]){v_x_2438, v_t_2441})));
}
V g_heff_2esyntax_2esurface_2eexprL_lam1(V self, V *args) {
  V v_m_2467 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2esyntax_2esurface_2eupdateSettingL(v_r_240, v_m_2467));
}
V g_heff_2esyntax_2esurface_2eexprL_lam2(V self, V *args) {
  V v_a_24121 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2esyntax_2esurface_2evariantL(v_r_240, v_a_24121));
}
V g_heff_2esyntax_2esurface_2eexprL_lam3(V self, V *args) {
  V v_m_24484 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2esyntax_2esurface_2eargL(v_r_240, v_m_24484));
}
V g_heff_2esyntax_2esurface_2eexprL_lam5(V self, V *args) {
  V v_st_24508 = args[0];
  V v_m_24507 = heff_env(self)[0];
  V v_op_24505 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24509 = heff_tr(heff_call(v_m_24507, 1, (V[]){v_st_24508}));
  switch (heff_tag_of(v_x1_24509)) {
  case TAG_MkPair: {
    V v_x11_24510 = heff_field(v_x1_24509, 0);
    V v_st_24511 = heff_field(v_x1_24509, 1);
    V v_ru_24x1_24509_24MkPair = heff_take_reuse_n(v_x1_24509, 3ULL, 2);
    switch (heff_tag_of(v_x11_24510)) {
    case TAG_Left: {
      V v_e_24512 = heff_field(v_x11_24510, 0);
      heff_take_n(v_x11_24510, 1ULL, 1);
      heff_drop(v_op_24505);
      return heff_tag_at_n(v_ru_24x1_24509_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24512}), v_st_24511});
    }
    case TAG_Right: {
      V v_x_24513 = heff_field(v_x11_24510, 0);
      V v_ru_24x11_24510_24Right = heff_take_reuse_n(v_x11_24510, 1ULL, 1);
      V v_t_24514 = heff_tag_at_n(v_ru_24x11_24510_24Right, TAG_Right, 1, (V[]){heff_rec_n(2, shape_op__e, (V[]){v_op_24505, v_x_24513})});
      return heff_tag_at_n(v_ru_24x1_24509_24MkPair, TAG_MkPair, 2, (V[]){v_t_24514, v_st_24511});
    }
    default: return heff_nomatch(v_x11_24510);
    }
  }
  default: return heff_nomatch(v_x1_24509);
  }
}
V g_heff_2esyntax_2esurface_2eexprL_lam4(V self, V *args) {
  V v_m_24503 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24504 = (g_heff_2esyntax_2esurface_2eopRhsOf(v_m_24503));
  switch (heff_tag_of(v_t_24504)) {
  case TAG_MkPair: {
    V v_op_24505 = heff_field(v_t_24504, 0);
    V v_e_24506 = heff_field(v_t_24504, 1);
    heff_take_n(v_t_24504, 3ULL, 2);
    V v_m_24507 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_24506}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2eexprL_lam5, 1, 2, (V[]){v_m_24507, v_op_24505});
  }
  default: return heff_nomatch(v_t_24504);
  }
}
V g_heff_2esyntax_2esurface_2eexprL_lam6(V self, V *args) {
  V v_a_24593 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2esyntax_2esurface_2ealtL(v_r_240, v_a_24593));
}
V g_heff_2esyntax_2esurface_2eexprL_lam7(V self, V *args) {
  V v_m_24642 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2esyntax_2esurface_2estmtL(v_r_240, v_m_24642));
}
V g_heff_2esyntax_2esurface_2edefaultL_lam0(V self, V *args); static Clo g_heff_2esyntax_2esurface_2edefaultL_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2edefaultL_lam0, 1, 0};
V g_heff_2esyntax_2esurface_2edefaultL_lam1(V self, V *args);
Clo g_heff_2esyntax_2esurface_2edefaultL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2edefaultL_entry, 2, 0};

V g_heff_2esyntax_2esurface_2edefaultL(V v_r_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nothing: {
    heff_drop_rec(v_r_240, 3);
    return ((V)&g_heff_2esyntax_2esurface_2edefaultL_lam0_clo);
  }
  case TAG_Just: {
    V v_x21_244 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    switch (heff_tag_of(v_x21_244)) {
    case TAG_MkPair: {
      V v_d_246 = heff_field(v_x21_244, 1);
      heff_take_n(v_x21_244, 2ULL, 2);
      V v_m_247 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_d_246}));
      return heff_clo_n(g_heff_2esyntax_2esurface_2edefaultL_lam1, 1, 1, (V[]){v_m_247});
    }
    default: return heff_nomatch(v_x21_244);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2esurface_2edefaultL_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2edefaultL(a[0], a[1]);
}
V g_heff_2esyntax_2esurface_2edefaultL_lam0(V self, V *args) {
  V v_st_242 = args[0];
  V v_t_243 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_243, v_st_242});
}
V g_heff_2esyntax_2esurface_2edefaultL_lam1(V self, V *args) {
  V v_st_248 = args[0];
  V v_m_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_249 = heff_tr(heff_call(v_m_247, 1, (V[]){v_st_248}));
  switch (heff_tag_of(v_x1_249)) {
  case TAG_MkPair: {
    V v_x11_2410 = heff_field(v_x1_249, 0);
    V v_st_2411 = heff_field(v_x1_249, 1);
    V v_ru_24x1_249_24MkPair = heff_take_reuse_n(v_x1_249, 3ULL, 2);
    switch (heff_tag_of(v_x11_2410)) {
    case TAG_Left: {
      V v_e_2412 = heff_field(v_x11_2410, 0);
      heff_take_n(v_x11_2410, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_249_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2412}), v_st_2411});
    }
    case TAG_Right: {
      V v_x_2413 = heff_field(v_x11_2410, 0);
      V v_ru_24x11_2410_24Right = heff_take_reuse_n(v_x11_2410, 1ULL, 1);
      V v_t_2414 = heff_tag_at_n(v_ru_24x11_2410_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Just, 1, (V[]){v_x_2413})});
      return heff_tag_at_n(v_ru_24x1_249_24MkPair, TAG_MkPair, 2, (V[]){v_t_2414, v_st_2411});
    }
    default: return heff_nomatch(v_x11_2410);
    }
  }
  default: return heff_nomatch(v_x1_249);
  }
}