// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Ann 13421
#define TAG_App 13485
#define TAG_At 8900
#define TAG_Atom 28502
#define TAG_BAnn 9252
#define TAG_BImp 16911
#define TAG_BVar 29034
#define TAG_Braces 8205
#define TAG_Case 4415
#define TAG_Do 8988
#define TAG_EAlt 33043
#define TAG_EAnn 33099
#define TAG_EAssign 4102
#define TAG_EBinary 42634
#define TAG_EBreak 7195
#define TAG_ECatch 45587
#define TAG_ECon 35052
#define TAG_EContinue 48638
#define TAG_EDo 15964
#define TAG_EFDefault 38038
#define TAG_EFSet 34673
#define TAG_EField 26142
#define TAG_EFor 37939
#define TAG_EIfThen 2245
#define TAG_EInvalid 31081
#define TAG_EJump 55703
#define TAG_ELet 43397
#define TAG_ELetCond 24397
#define TAG_ELetIn 22786
#define TAG_ELetMut 54984
#define TAG_EMatch 41631
#define TAG_ENeg 45306
#define TAG_ENest 28629
#define TAG_EParen 58248
#define TAG_EReturn 59059
#define TAG_ESBind 62182
#define TAG_ESum 50613
#define TAG_ETag 50948
#define TAG_ETry 51493
#define TAG_EUSet 22856
#define TAG_EUpdate 6986
#define TAG_EVar 52881
#define TAG_EWhile 39339
#define TAG_FloatValue 23118
#define TAG_If 9134
#define TAG_IfThen 36069
#define TAG_InstB 37114
#define TAG_IntValue 62477
#define TAG_Lam 23588
#define TAG_Left 13886
#define TAG_MkAlt 55173
#define TAG_MkSegment 38079
#define TAG_MkTry 8097
#define TAG_Named 2049
#define TAG_Op 9330
#define TAG_OpRhs 36076
#define TAG_Ops 26942
#define TAG_OtherValue 43098
#define TAG_Right 62770
#define TAG_RuneValue 49425
#define TAG_SError 24172
#define TAG_Seg 30433
#define TAG_SegmentBinary 41188
#define TAG_SegmentBits 43687
#define TAG_SegmentFloat 21180
#define TAG_SegmentInteger 22664
#define TAG_SegmentUtf 5205
#define TAG_SizeDefault 11444
#define TAG_StrValue 22621
#define TAG_Sum 30935
#define TAG_Tup 31899
#define TAG_Update 40810
#define LBL_code 9554612
#define LBL_e 319
#define LBL_end 310101
#define LBL_kind 9787483
#define LBL_little 844663329
#define LBL_msg 317947
#define LBL_note 9882809
#define LBL_op 10312
#define LBL_ops 319788
#define LBL_out 319944
#define LBL_pat 320285
#define LBL_severity 75955546
#define LBL_signed 1044674119
#define LBL_size 10026184
#define LBL_span 10032145
#define LBL_start 311115900
#define LBL_text 10052084
#define LBL_ty 10476
#define LBL_unit 10090059
static uint32_t shape_code__severity__msg__span__note[] = {LBL_code, LBL_severity, LBL_msg, LBL_span, LBL_note};
static uint32_t shape_op__e[] = {LBL_op, LBL_e};
static uint32_t shape_ops__out[] = {LBL_ops, LBL_out};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
static uint32_t shape_ty__size__unit__little__signed[] = {LBL_ty, LBL_size, LBL_unit, LBL_little, LBL_signed};
V g_heff_2esyntax_2ecst_2efirstE(V);
V g_heff_2esyntax_2ecst_2efirstE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2efirstE_clo;
V g_heff_2esyntax_2ecst_2elastE(V);
V g_heff_2esyntax_2ecst_2elastE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2elastE_clo;
V g_heff_2esyntax_2epresyntax_2eapp(V, V);
V g_heff_2esyntax_2epresyntax_2eapp_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eapp_clo;
V g_heff_2esyntax_2esurface_2ealtL(V, V);
V g_heff_2esyntax_2esurface_2ealtL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ealtL_clo;
V g_heff_2esyntax_2esurface_2eapplyOp(V, V, V);
V g_heff_2esyntax_2esurface_2eapplyOp_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eapplyOp_clo;
V g_heff_2esyntax_2esurface_2eargL(V, V);
V g_heff_2esyntax_2esurface_2eargL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eargL_clo;
V g_heff_2esyntax_2esurface_2eatomTok(V);
V g_heff_2esyntax_2esurface_2eatomTok_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eatomTok_clo;
V g_heff_2esyntax_2esurface_2eblock(V, V, V);
V g_heff_2esyntax_2esurface_2eblock_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eblock_clo;
HeffT2 g_heff_2esyntax_2esurface_2eblock_24cpr(V, V, V);
V g_heff_2esyntax_2esurface_2eboundBy(V, V);
V g_heff_2esyntax_2esurface_2eboundBy_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eboundBy_clo;
V g_heff_2esyntax_2esurface_2ebracesL(V, V, V, V, V);
V g_heff_2esyntax_2esurface_2ebracesL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ebracesL_clo;
V g_heff_2esyntax_2esurface_2ecatchL(V, V);
V g_heff_2esyntax_2esurface_2ecatchL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ecatchL_clo;
V g_heff_2esyntax_2esurface_2ecommentLinesFrom(V, V, V);
V g_heff_2esyntax_2esurface_2ecommentLinesFrom_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ecommentLinesFrom_clo;
V g_heff_2esyntax_2esurface_2econAtom(V, V, V);
V g_heff_2esyntax_2esurface_2econAtom_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2econAtom_clo;
V g_heff_2esyntax_2esurface_2econL(V, V, V);
V g_heff_2esyntax_2esurface_2econL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2econL_clo;
V g_heff_2esyntax_2esurface_2edeclarationL(V, V);
V g_heff_2esyntax_2esurface_2edeclarationL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2edeclarationL_clo;
V g_heff_2esyntax_2esurface_2edefaultL(V, V);
V g_heff_2esyntax_2esurface_2edefaultL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2edefaultL_clo;
V g_heff_2esyntax_2esurface_2eexprL(V, V, V);
V g_heff_2esyntax_2esurface_2eexprL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eexprL_clo;
HeffT2 g_heff_2esyntax_2esurface_2efieldsOf_24cpr(V, V);
V g_heff_2esyntax_2esurface_2efirstS(V, V, V, V);
V g_heff_2esyntax_2esurface_2efirstS_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2efirstS_clo;
V g_heff_2esyntax_2esurface_2efoldr(V, V, V);
V g_heff_2esyntax_2esurface_2efoldr_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2efoldr_clo;
V g_heff_2esyntax_2esurface_2eifE(V, V, V, V);
V g_heff_2esyntax_2esurface_2eifE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eifE_clo;
V g_heff_2esyntax_2esurface_2eifLetL(V, V, V, V, V, V, V);
V g_heff_2esyntax_2esurface_2eifLetL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eifLetL_clo;
V g_heff_2esyntax_2esurface_2eintOfText(V);
V g_heff_2esyntax_2esurface_2eintOfText_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eintOfText_clo;
V g_heff_2esyntax_2esurface_2ekwAtom(V, V, V);
V g_heff_2esyntax_2esurface_2ekwAtom_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ekwAtom_clo;
V g_heff_2esyntax_2esurface_2elambdaL(V, V, V, V);
V g_heff_2esyntax_2esurface_2elambdaL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2elambdaL_clo;
HeffT2 g_heff_2esyntax_2esurface_2eletBodyL_24cpr(V, V, V, V, V, V);
V g_heff_2esyntax_2esurface_2eletL(V, V, V);
V g_heff_2esyntax_2esurface_2eletL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eletL_clo;
V g_heff_2esyntax_2esurface_2eopL(V, V, V, V, V);
V g_heff_2esyntax_2esurface_2eopL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eopL_clo;
HeffT2 g_heff_2esyntax_2esurface_2eopRhsOf_24cpr(V);
V g_heff_2esyntax_2esurface_2eparenL(V, V, V, V, V);
V g_heff_2esyntax_2esurface_2eparenL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eparenL_clo;
V g_heff_2esyntax_2esurface_2epushS_24s1868233564x1858628873(V, V, V, V);
V g_heff_2esyntax_2esurface_2epushS_24s1868233564x1858628873_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2epushS_24s1868233564x1858628873_clo;
V g_heff_2esyntax_2esurface_2eresolve_24s1832151779x1448561609(V, V, V);
V g_heff_2esyntax_2esurface_2eresolve_24s1832151779x1448561609_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eresolve_24s1832151779x1448561609_clo;
V g_heff_2esyntax_2esurface_2erightsOf(V);
V g_heff_2esyntax_2esurface_2erightsOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2erightsOf_clo;
V g_heff_2esyntax_2esurface_2erightsOf_24dps(V, V);
V g_heff_2esyntax_2esurface_2erightsOf_24dps_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2erightsOf_24dps_clo;
V g_heff_2esyntax_2esurface_2esegmentL(V, V);
V g_heff_2esyntax_2esurface_2esegmentL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2esegmentL_clo;
V g_heff_2esyntax_2esurface_2esegmentOf_24s1547151193x813882637(V, V, V, V, V);
V g_heff_2esyntax_2esurface_2esegmentOf_24s1547151193x813882637_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2esegmentOf_24s1547151193x813882637_clo;
V g_heff_2esyntax_2esurface_2especWord(V, V, V);
V g_heff_2esyntax_2esurface_2especWord_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2especWord_clo;
V g_heff_2esyntax_2esurface_2estmtL(V, V);
V g_heff_2esyntax_2esurface_2estmtL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2estmtL_clo;
V g_heff_2esyntax_2esurface_2etryTypeL(V, V);
V g_heff_2esyntax_2esurface_2etryTypeL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2etryTypeL_clo;
V g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993(V, V, V, V, V);
V g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_clo;
V g_heff_2esyntax_2esurface_2eunitOf(V, V, V);
V g_heff_2esyntax_2esurface_2eunitOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eunitOf_clo;
V g_heff_2esyntax_2esurface_2eupdateSettingL(V, V);
V g_heff_2esyntax_2esurface_2eupdateSettingL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eupdateSettingL_clo;
HeffT2 g_heff_2esyntax_2esurface_2evalueKind_24cpr(V, V, V, V);
V g_heff_2esyntax_2esurface_2evarAtom(V, V, V);
V g_heff_2esyntax_2esurface_2evarAtom_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2evarAtom_clo;
V g_heff_2esyntax_2esurface_2evariantL(V, V);
V g_heff_2esyntax_2esurface_2evariantL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2evariantL_clo;
HeffT2 g_heff_2esyntax_2esurface_2ewithScope_24cpr(V, V, V);
V g_list_2emap_24s513201124x806973253(V);
V g_list_2emap_24s513201124x806973253_entry(V self, V *a);
extern Clo g_list_2emap_24s513201124x806973253_clo;
V g_prelude_2eskipSpaces(V, V, V);
V g_prelude_2eskipSpaces_entry(V self, V *a);
extern Clo g_prelude_2eskipSpaces_clo;
V g_prelude_2etraverse_24s499544530x2060473942(V, V);
V g_prelude_2etraverse_24s499544530x2060473942_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s499544530x2060473942_clo;
HEFF_LIT(g_heff_2esyntax_2esurface_2ecommentLinesFrom_str0, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecommentLinesFrom_str1, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecommentLinesFrom_str2, 2, "--");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecommentLinesFrom_str3, 1, "\012");
Clo g_heff_2esyntax_2esurface_2ecommentLinesFrom_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2ecommentLinesFrom_entry, 3, 0};

V g_heff_2esyntax_2esurface_2ecommentLinesFrom(V v_src_240, V v_i_241, V v_to_242) {
top: ;
  V v_j_243 = heff_strFind_lent(((V)&g_heff_2esyntax_2esurface_2ecommentLinesFrom_str0), v_src_240, v_i_241, 1);
  V v_t_245;
  if (heff_intLt_c_lent(v_j_243, MK_INT(0LL), 2)) {
    heff_drop(v_j_243);
    v_t_245 = heff_strLength_lent(v_src_240, 0);
  } else {
    v_t_245 = v_j_243;
  }
  if (heff_intLe_c_lent(v_to_242, v_t_245, 2)) {
    heff_drop(v_i_241);
    heff_drop(v_to_242);
    return NTAG(TAG_True);
  } else {
    V v_j_247 = heff_strFind_lent(((V)&g_heff_2esyntax_2esurface_2ecommentLinesFrom_str1), v_src_240, v_i_241, 1);
    V v_t_249;
    if (heff_intLt_c_lent(v_j_247, MK_INT(0LL), 2)) {
      heff_drop(v_j_247);
      v_t_249 = heff_strLength_lent(v_src_240, 0);
    } else {
      v_t_249 = v_j_247;
    }
    V v_s_2410 = heff_strSlice_lent(v_src_240, v_i_241, v_t_249, 4);
    V v_t_2411 = (g_prelude_2eskipSpaces(v_s_2410, MK_INT(0LL), MK_INT(1LL)));
    int64_t v_t_2412 = (heff_unbox_word(heff_strLength_lent(v_s_2410, 0)) - ((int64_t)1ULL));
    V v_t_2413 = (g_prelude_2eskipSpaces(v_s_2410, heff_box_word(v_t_2412), MK_INT(-1LL)));
    V v_s_2414 = heff_strSlice(v_s_2410, v_t_2411, heff_intAdd(v_t_2413, MK_INT(1LL)));
    if (heff_strEq_c(heff_strSlice(v_s_2414, MK_INT(0LL), MK_INT(2LL)), ((V)&g_heff_2esyntax_2esurface_2ecommentLinesFrom_str2))) {
      V v_j_2416 = heff_strFind_lent(((V)&g_heff_2esyntax_2esurface_2ecommentLinesFrom_str3), v_src_240, v_i_241, 5);
      V v_t_2418;
      if (heff_intLt_c_lent(v_j_2416, MK_INT(0LL), 2)) {
        heff_drop(v_j_2416);
        v_t_2418 = heff_strLength_lent(v_src_240, 0);
      } else {
        v_t_2418 = v_j_2416;
      }
      V t_0 = v_src_240;
      V t_1 = heff_intAdd(v_t_2418, MK_INT(1LL));
      V t_2 = v_to_242;
      v_src_240 = t_0;
      v_i_241 = t_1;
      v_to_242 = t_2;
      goto top;
    } else {
      heff_drop(v_i_241);
      heff_drop(v_to_242);
      return NTAG(TAG_False);
    }
  }
}
V g_heff_2esyntax_2esurface_2ecommentLinesFrom_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2esurface_2ecommentLinesFrom(a0, a[1], a[2]); heff_drop(a0); return r;
}
V g_heff_2esyntax_2esurface_2eletBodyL_24cpr_lam0(V self, V *args);

HeffT2 g_heff_2esyntax_2esurface_2eletBodyL_24cpr(V v_r_240, V v_kw_241, V v_x3_242, V v_names_243, V v_body_244, V v_z_245) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_MkPair: {
    V v_p_246 = heff_field(v_x3_242, 0);
    V v_rhs_247 = heff_field(v_x3_242, 1);
    heff_take_n(v_x3_242, 3ULL, 2);
    V v_m_248 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_body_244)}));
    return (g_heff_2esyntax_2esurface_2ewithScope_24cpr(v_names_243, heff_clo_n(g_heff_2esyntax_2esurface_2eletBodyL_24cpr_lam0, 1, 5, (V[]){v_m_248, v_p_246, v_body_244, v_kw_241, v_rhs_247}), v_z_245));
  }
  default: return ((HeffT2){{heff_nomatch(v_x3_242)}});
  }
}
V g_heff_2esyntax_2esurface_2eletBodyL_24cpr_lam0(V self, V *args) {
  V v_st_249 = args[0];
  V v_m_248 = heff_env(self)[0];
  V v_p_246 = heff_env(self)[1];
  V v_body_244 = heff_env(self)[2];
  V v_kw_241 = heff_env(self)[3];
  V v_rhs_247 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_x1_2410 = heff_tr(heff_call(v_m_248, 1, (V[]){v_st_249}));
  switch (heff_tag_of(v_x1_2410)) {
  case TAG_MkPair: {
    V v_x11_2411 = heff_field(v_x1_2410, 0);
    V v_st_2412 = heff_field(v_x1_2410, 1);
    V v_ru_24x1_2410_24MkPair = heff_take_reuse_n(v_x1_2410, 3ULL, 2);
    switch (heff_tag_of(v_x11_2411)) {
    case TAG_Left: {
      V v_e_2413 = heff_field(v_x11_2411, 0);
      heff_take_n(v_x11_2411, 1ULL, 1);
      heff_drop(v_p_246);
      heff_drop(v_body_244);
      heff_drop_rec(v_kw_241, 9);
      heff_drop(v_rhs_247);
      return heff_tag_at_n(v_ru_24x1_2410_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2413}), v_st_2412});
    }
    case TAG_Right: {
      V v_x_2414 = heff_field(v_x11_2411, 0);
      heff_take_n(v_x11_2411, 1ULL, 1);
      V v_t_2417;
      switch (heff_tag_of(v_p_246)) {
      case TAG_At: {
        V v_s_2416 = heff_dup(heff_field(v_p_246, 1));
        v_t_2417 = v_s_2416;
        break;
      }
      default: heff_nomatch(v_p_246);
      }
      V v_t_2420;
      switch (heff_tag_of(v_x_2414)) {
      case TAG_At: {
        V v_s_2419 = heff_dup(heff_field(v_x_2414, 1));
        v_t_2420 = v_s_2419;
        break;
      }
      default: heff_nomatch(v_x_2414);
      }
      V v_t_2421 = ({ V rv_1 = heff_get_n(v_t_2420, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_2417, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
      V v_t_2422 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_246, v_x_2414}), v_t_2421});
      V v_t_2423 = (g_heff_2esyntax_2ecst_2elastE(v_body_244));
      V v_e_2424 = heff_get_n(v_t_2423, 4, 9);
      V v_t_2425 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_241, 3, 9), v_e_2424});
      V v_x_2426 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ELetIn, 2, (V[]){v_rhs_247, v_t_2422}), v_t_2425});
      return heff_tag_at_n(v_ru_24x1_2410_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2426}), v_st_2412});
    }
    default: return heff_nomatch(v_x11_2411);
    }
  }
  default: return heff_nomatch(v_x1_2410);
  }
}
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str0, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str1, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str2, 3, "err");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str3, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str4, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str5, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str6, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str7, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str8, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str9, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str10, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str11, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str12, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str13, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str14, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str15, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str16, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str17, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str18, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str19, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str20, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str21, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str22, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str23, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str24, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str25, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str26, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str27, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str28, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str29, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str30, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str31, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str32, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str33, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str34, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str35, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str36, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str37, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str38, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str39, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str40, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str41, 61, "a `try` names the type of the throws it hears as `(err := T)`");
V g_heff_2esyntax_2esurface_2etryTypeL_lam0(V self, V *args); static Clo g_heff_2esyntax_2esurface_2etryTypeL_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2etryTypeL_lam0, 1, 0};
V g_heff_2esyntax_2esurface_2etryTypeL_lam1(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam2(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam3(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam4(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam5(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam6(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam7(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam8(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam9(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam10(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam11(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam12(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam13(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam14(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam15(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam16(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam17(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam18(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam19(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam20(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam21(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam22(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam23(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam24(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam25(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam26(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam27(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam28(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam29(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam30(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam31(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam32(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam33(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam34(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam35(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam36(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam37(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam38(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam39(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam40(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam41(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam42(V self, V *args);
Clo g_heff_2esyntax_2esurface_2etryTypeL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2etryTypeL_entry, 2, 0};

V g_heff_2esyntax_2esurface_2etryTypeL(V v_r_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nothing: {
    heff_drop_rec(v_r_240, 3);
    return ((V)&g_heff_2esyntax_2esurface_2etryTypeL_lam0_clo);
  }
  case TAG_Just: {
    V v_x21_244 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24Just = heff_take_reuse_n(v_x2_241, 1ULL, 1);
    switch (heff_tag_of(v_x21_244)) {
    case TAG_Atom: {
      heff_drop_rec(v_r_240, 3);
      V v_t_246 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 1); r_; });
      V v_t_247 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_246, 3), heff_get_n(v_t_246, 4, 9)});
      V v_t_248 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str0)}), v_t_247});
      V v_x_249 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_248});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam1, 1, 1, (V[]){v_x_249});
    }
    case TAG_EParen: {
      heff_drop_rec(v_r_240, 3);
      V v_t_2414 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 3); r_; });
      V v_t_2415 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_2414, 3), heff_get_n(v_t_2414, 4, 9)});
      V v_t_2416 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str1)}), v_t_2415});
      V v_x_2417 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_2416});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam2, 1, 1, (V[]){v_x_2417});
    }
    case TAG_Named: {
      V v_x_2420 = heff_field(v_x21_244, 1);
      V v_e_2422 = heff_field(v_x21_244, 3);
      heff_take_n(v_x21_244, 10ULL, 5);
      heff_drop_cell(v_ru_24x2_241_24Just, 1);
      if (heff_strEq_c(heff_dup(heff_rfield(v_x_2420, 1)), ((V)&g_heff_2esyntax_2esurface_2etryTypeL_str2))) {
        heff_drop_rec(v_x_2420, 9);
        V v_m_2425 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_2422}));
        return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam3, 1, 1, (V[]){v_m_2425});
      } else {
        heff_drop_rec(v_r_240, 3);
        heff_drop(v_e_2422);
        return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam4, 1, 1, (V[]){v_x_2420});
      }
    }
    case TAG_Tup: {
      heff_drop_rec(v_r_240, 3);
      V v_t_2441 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 4); r_; });
      V v_t_2442 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_2441, 3), heff_get_n(v_t_2441, 4, 9)});
      V v_t_2443 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str4)}), v_t_2442});
      V v_x_2444 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_2443});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam5, 1, 1, (V[]){v_x_2444});
    }
    case TAG_Seg: {
      heff_drop_rec(v_r_240, 3);
      V v_t_2449 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 3); r_; });
      V v_t_2450 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_2449, 3), heff_get_n(v_t_2449, 4, 9)});
      V v_t_2451 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str5)}), v_t_2450});
      V v_x_2452 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_2451});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam6, 1, 1, (V[]){v_x_2452});
    }
    case TAG_Braces: {
      heff_drop_rec(v_r_240, 3);
      V v_t_2458 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 4); r_; });
      V v_t_2459 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_2458, 3), heff_get_n(v_t_2458, 4, 9)});
      V v_t_2460 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str6)}), v_t_2459});
      V v_x_2461 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_2460});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam7, 1, 1, (V[]){v_x_2461});
    }
    case TAG_Update: {
      heff_drop_rec(v_r_240, 3);
      V v_t_2469 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 6); r_; });
      V v_t_2470 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_2469, 3), heff_get_n(v_t_2469, 4, 9)});
      V v_t_2471 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str7)}), v_t_2470});
      V v_x_2472 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_2471});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam8, 1, 1, (V[]){v_x_2472});
    }
    case TAG_EUSet: {
      heff_drop_rec(v_r_240, 3);
      V v_t_2477 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 3); r_; });
      V v_t_2478 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_2477, 3), heff_get_n(v_t_2477, 4, 9)});
      V v_t_2479 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str8)}), v_t_2478});
      V v_x_2480 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_2479});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam9, 1, 1, (V[]){v_x_2480});
    }
    case TAG_InstB: {
      heff_drop_rec(v_r_240, 3);
      V v_t_2487 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 5); r_; });
      V v_t_2488 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_2487, 3), heff_get_n(v_t_2487, 4, 9)});
      V v_t_2489 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str9)}), v_t_2488});
      V v_x_2490 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_2489});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam10, 1, 1, (V[]){v_x_2490});
    }
    case TAG_EFSet: {
      heff_drop_rec(v_r_240, 3);
      V v_t_2495 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 3); r_; });
      V v_t_2496 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_2495, 3), heff_get_n(v_t_2495, 4, 9)});
      V v_t_2497 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str10)}), v_t_2496});
      V v_x_2498 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_2497});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam11, 1, 1, (V[]){v_x_2498});
    }
    case TAG_EFDefault: {
      heff_drop_rec(v_r_240, 3);
      V v_t_24103 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 3); r_; });
      V v_t_24104 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24103, 3), heff_get_n(v_t_24103, 4, 9)});
      V v_t_24105 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str11)}), v_t_24104});
      V v_x_24106 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_24105});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam12, 1, 1, (V[]){v_x_24106});
    }
    case TAG_Sum: {
      heff_drop_rec(v_r_240, 3);
      V v_t_24113 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 5); r_; });
      V v_t_24114 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24113, 3), heff_get_n(v_t_24113, 4, 9)});
      V v_t_24115 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str12)}), v_t_24114});
      V v_x_24116 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_24115});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam13, 1, 1, (V[]){v_x_24116});
    }
    case TAG_ECon: {
      heff_drop_rec(v_r_240, 3);
      V v_t_24120 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 2); r_; });
      V v_t_24121 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24120, 3), heff_get_n(v_t_24120, 4, 9)});
      V v_t_24122 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str13)}), v_t_24121});
      V v_x_24123 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_24122});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam14, 1, 1, (V[]){v_x_24123});
    }
    case TAG_EField: {
      heff_drop_rec(v_r_240, 3);
      V v_t_24127 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 2); r_; });
      V v_t_24128 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24127, 3), heff_get_n(v_t_24127, 4, 9)});
      V v_t_24129 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str14)}), v_t_24128});
      V v_x_24130 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_24129});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam15, 1, 1, (V[]){v_x_24130});
    }
    case TAG_ENeg: {
      heff_drop_rec(v_r_240, 3);
      V v_t_24134 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 2); r_; });
      V v_t_24135 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24134, 3), heff_get_n(v_t_24134, 4, 9)});
      V v_t_24136 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str15)}), v_t_24135});
      V v_x_24137 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_24136});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam16, 1, 1, (V[]){v_x_24137});
    }
    case TAG_App: {
      heff_drop_rec(v_r_240, 3);
      V v_t_24141 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 2); r_; });
      V v_t_24142 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24141, 3), heff_get_n(v_t_24141, 4, 9)});
      V v_t_24143 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str16)}), v_t_24142});
      V v_x_24144 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_24143});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam17, 1, 1, (V[]){v_x_24144});
    }
    case TAG_Op: {
      heff_drop_rec(v_r_240, 3);
      V v_t_24149 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 3); r_; });
      V v_t_24150 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24149, 3), heff_get_n(v_t_24149, 4, 9)});
      V v_t_24151 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str17)}), v_t_24150});
      V v_x_24152 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_24151});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam18, 1, 1, (V[]){v_x_24152});
    }
    case TAG_Ops: {
      heff_drop_rec(v_r_240, 3);
      V v_t_24156 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 2); r_; });
      V v_t_24157 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24156, 3), heff_get_n(v_t_24156, 4, 9)});
      V v_t_24158 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str18)}), v_t_24157});
      V v_x_24159 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_24158});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam19, 1, 1, (V[]){v_x_24159});
    }
    case TAG_OpRhs: {
      heff_drop_rec(v_r_240, 3);
      V v_t_24163 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 2); r_; });
      V v_t_24164 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24163, 3), heff_get_n(v_t_24163, 4, 9)});
      V v_t_24165 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str19)}), v_t_24164});
      V v_x_24166 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_24165});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam20, 1, 1, (V[]){v_x_24166});
    }
    case TAG_Ann: {
      heff_drop_rec(v_r_240, 3);
      V v_t_24171 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 3); r_; });
      V v_t_24172 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24171, 3), heff_get_n(v_t_24171, 4, 9)});
      V v_t_24173 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str20)}), v_t_24172});
      V v_x_24174 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_24173});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam21, 1, 1, (V[]){v_x_24174});
    }
    case TAG_BVar: {
      heff_drop_rec(v_r_240, 3);
      V v_t_24177 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 1); r_; });
      V v_t_24178 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24177, 3), heff_get_n(v_t_24177, 4, 9)});
      V v_t_24179 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str21)}), v_t_24178});
      V v_x_24180 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_24179});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam22, 1, 1, (V[]){v_x_24180});
    }
    case TAG_BImp: {
      heff_drop_rec(v_r_240, 3);
      V v_t_24185 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 3); r_; });
      V v_t_24186 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24185, 3), heff_get_n(v_t_24185, 4, 9)});
      V v_t_24187 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str22)}), v_t_24186});
      V v_x_24188 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_24187});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam23, 1, 1, (V[]){v_x_24188});
    }
    case TAG_BAnn: {
      heff_drop_rec(v_r_240, 3);
      V v_t_24195 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 5); r_; });
      V v_t_24196 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24195, 3), heff_get_n(v_t_24195, 4, 9)});
      V v_t_24197 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str23)}), v_t_24196});
      V v_x_24198 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_24197});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam24, 1, 1, (V[]){v_x_24198});
    }
    case TAG_Lam: {
      heff_drop_rec(v_r_240, 3);
      V v_t_24204 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 4); r_; });
      V v_t_24205 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24204, 3), heff_get_n(v_t_24204, 4, 9)});
      V v_t_24206 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str24)}), v_t_24205});
      V v_x_24207 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_24206});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam25, 1, 1, (V[]){v_x_24207});
    }
    case TAG_Case: {
      heff_drop_rec(v_r_240, 3);
      V v_t_24213 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 4); r_; });
      V v_t_24214 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24213, 3), heff_get_n(v_t_24213, 4, 9)});
      V v_t_24215 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str25)}), v_t_24214});
      V v_x_24216 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_24215});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam26, 1, 1, (V[]){v_x_24216});
    }
    case TAG_EAlt: {
      heff_drop_rec(v_r_240, 3);
      V v_t_24221 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 3); r_; });
      V v_t_24222 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24221, 3), heff_get_n(v_t_24221, 4, 9)});
      V v_t_24223 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str26)}), v_t_24222});
      V v_x_24224 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_24223});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam27, 1, 1, (V[]){v_x_24224});
    }
    case TAG_If: {
      heff_drop_rec(v_r_240, 3);
      V v_t_24232 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 6); r_; });
      V v_t_24233 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24232, 3), heff_get_n(v_t_24232, 4, 9)});
      V v_t_24234 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str27)}), v_t_24233});
      V v_x_24235 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_24234});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam28, 1, 1, (V[]){v_x_24235});
    }
    case TAG_Do: {
      heff_drop_rec(v_r_240, 3);
      V v_t_24239 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 2); r_; });
      V v_t_24240 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24239, 3), heff_get_n(v_t_24239, 4, 9)});
      V v_t_24241 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str28)}), v_t_24240});
      V v_x_24242 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_24241});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam29, 1, 1, (V[]){v_x_24242});
    }
    case TAG_ESBind: {
      heff_drop_rec(v_r_240, 3);
      V v_t_24247 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 3); r_; });
      V v_t_24248 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24247, 3), heff_get_n(v_t_24247, 4, 9)});
      V v_t_24249 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str29)}), v_t_24248});
      V v_x_24250 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_24249});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam30, 1, 1, (V[]){v_x_24250});
    }
    case TAG_ELet: {
      heff_drop_rec(v_r_240, 3);
      V v_t_24258 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 6); r_; });
      V v_t_24259 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24258, 3), heff_get_n(v_t_24258, 4, 9)});
      V v_t_24260 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str30)}), v_t_24259});
      V v_x_24261 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_24260});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam31, 1, 1, (V[]){v_x_24261});
    }
    case TAG_ELetMut: {
      heff_drop_rec(v_r_240, 3);
      V v_t_24269 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 6); r_; });
      V v_t_24270 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24269, 3), heff_get_n(v_t_24269, 4, 9)});
      V v_t_24271 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str31)}), v_t_24270});
      V v_x_24272 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_24271});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam32, 1, 1, (V[]){v_x_24272});
    }
    case TAG_EAssign: {
      heff_drop_rec(v_r_240, 3);
      V v_t_24277 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 3); r_; });
      V v_t_24278 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24277, 3), heff_get_n(v_t_24277, 4, 9)});
      V v_t_24279 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str32)}), v_t_24278});
      V v_x_24280 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_24279});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam33, 1, 1, (V[]){v_x_24280});
    }
    case TAG_EWhile: {
      heff_drop_rec(v_r_240, 3);
      V v_t_24286 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 4); r_; });
      V v_t_24287 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24286, 3), heff_get_n(v_t_24286, 4, 9)});
      V v_t_24288 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str33)}), v_t_24287});
      V v_x_24289 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_24288});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam34, 1, 1, (V[]){v_x_24289});
    }
    case TAG_EFor: {
      heff_drop_rec(v_r_240, 3);
      V v_t_24297 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 6); r_; });
      V v_t_24298 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24297, 3), heff_get_n(v_t_24297, 4, 9)});
      V v_t_24299 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str34)}), v_t_24298});
      V v_x_24300 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_24299});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam35, 1, 1, (V[]){v_x_24300});
    }
    case TAG_EJump: {
      heff_drop_rec(v_r_240, 3);
      V v_t_24303 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 1); r_; });
      V v_t_24304 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24303, 3), heff_get_n(v_t_24303, 4, 9)});
      V v_t_24305 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str35)}), v_t_24304});
      V v_x_24306 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_24305});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam36, 1, 1, (V[]){v_x_24306});
    }
    case TAG_EReturn: {
      heff_drop_rec(v_r_240, 3);
      V v_t_24310 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 2); r_; });
      V v_t_24311 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24310, 3), heff_get_n(v_t_24310, 4, 9)});
      V v_t_24312 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str36)}), v_t_24311});
      V v_x_24313 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_24312});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam37, 1, 1, (V[]){v_x_24313});
    }
    case TAG_ENest: {
      heff_drop_rec(v_r_240, 3);
      V v_t_24319 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 4); r_; });
      V v_t_24320 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24319, 3), heff_get_n(v_t_24319, 4, 9)});
      V v_t_24321 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str37)}), v_t_24320});
      V v_x_24322 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_24321});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam38, 1, 1, (V[]){v_x_24322});
    }
    case TAG_IfThen: {
      heff_drop_rec(v_r_240, 3);
      V v_t_24328 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 4); r_; });
      V v_t_24329 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24328, 3), heff_get_n(v_t_24328, 4, 9)});
      V v_t_24330 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str38)}), v_t_24329});
      V v_x_24331 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_24330});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam39, 1, 1, (V[]){v_x_24331});
    }
    case TAG_ELetCond: {
      heff_drop_rec(v_r_240, 3);
      V v_t_24337 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 4); r_; });
      V v_t_24338 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24337, 3), heff_get_n(v_t_24337, 4, 9)});
      V v_t_24339 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str39)}), v_t_24338});
      V v_x_24340 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_24339});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam40, 1, 1, (V[]){v_x_24340});
    }
    case TAG_ETry: {
      heff_drop_rec(v_r_240, 3);
      V v_t_24346 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 4); r_; });
      V v_t_24347 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24346, 3), heff_get_n(v_t_24346, 4, 9)});
      V v_t_24348 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str40)}), v_t_24347});
      V v_x_24349 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_24348});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam41, 1, 1, (V[]){v_x_24349});
    }
    case TAG_ECatch: {
      heff_drop_rec(v_r_240, 3);
      V v_t_24355 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 4); r_; });
      V v_t_24356 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24355, 3), heff_get_n(v_t_24355, 4, 9)});
      V v_t_24357 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str41)}), v_t_24356});
      V v_x_24358 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_24357});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam42, 1, 1, (V[]){v_x_24358});
    }
    default: return heff_nomatch(v_x21_244);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2esurface_2etryTypeL_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2etryTypeL(a[0], a[1]);
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam0(V self, V *args) {
  V v_st_242 = args[0];
  V v_t_243 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_243, v_st_242});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam1(V self, V *args) {
  V v_st_2410 = args[0];
  V v_x_249 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_249}), v_st_2410});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam2(V self, V *args) {
  V v_st_2418 = args[0];
  V v_x_2417 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2417}), v_st_2418});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam3(V self, V *args) {
  V v_st_2426 = args[0];
  V v_m_2425 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2427 = heff_tr(heff_call(v_m_2425, 1, (V[]){v_st_2426}));
  switch (heff_tag_of(v_x1_2427)) {
  case TAG_MkPair: {
    V v_x11_2428 = heff_field(v_x1_2427, 0);
    V v_st_2429 = heff_field(v_x1_2427, 1);
    V v_ru_24x1_2427_24MkPair = heff_take_reuse_n(v_x1_2427, 3ULL, 2);
    switch (heff_tag_of(v_x11_2428)) {
    case TAG_Left: {
      V v_e_2430 = heff_field(v_x11_2428, 0);
      heff_take_n(v_x11_2428, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_2427_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2430}), v_st_2429});
    }
    case TAG_Right: {
      V v_x_2431 = heff_field(v_x11_2428, 0);
      V v_ru_24x11_2428_24Right = heff_take_reuse_n(v_x11_2428, 1ULL, 1);
      V v_t_2432 = heff_tag_at_n(v_ru_24x11_2428_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Just, 1, (V[]){v_x_2431})});
      return heff_tag_at_n(v_ru_24x1_2427_24MkPair, TAG_MkPair, 2, (V[]){v_t_2432, v_st_2429});
    }
    default: return heff_nomatch(v_x11_2428);
    }
  }
  default: return heff_nomatch(v_x1_2427);
  }
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam4(V self, V *args) {
  V v_st_2433 = args[0];
  V v_x_2420 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2434 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_x_2420, 3), heff_get_n(v_x_2420, 4, 9)});
  V v_t_2435 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str3)}), v_t_2434});
  V v_t_2436 = heff_tag_n(TAG_Right, 1, (V[]){heff_tag_n(TAG_Just, 1, (V[]){v_t_2435})});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2436, v_st_2433});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam5(V self, V *args) {
  V v_st_2445 = args[0];
  V v_x_2444 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2444}), v_st_2445});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam6(V self, V *args) {
  V v_st_2453 = args[0];
  V v_x_2452 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2452}), v_st_2453});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam7(V self, V *args) {
  V v_st_2462 = args[0];
  V v_x_2461 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2461}), v_st_2462});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam8(V self, V *args) {
  V v_st_2473 = args[0];
  V v_x_2472 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2472}), v_st_2473});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam9(V self, V *args) {
  V v_st_2481 = args[0];
  V v_x_2480 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2480}), v_st_2481});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam10(V self, V *args) {
  V v_st_2491 = args[0];
  V v_x_2490 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2490}), v_st_2491});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam11(V self, V *args) {
  V v_st_2499 = args[0];
  V v_x_2498 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2498}), v_st_2499});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam12(V self, V *args) {
  V v_st_24107 = args[0];
  V v_x_24106 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24106}), v_st_24107});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam13(V self, V *args) {
  V v_st_24117 = args[0];
  V v_x_24116 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24116}), v_st_24117});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam14(V self, V *args) {
  V v_st_24124 = args[0];
  V v_x_24123 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24123}), v_st_24124});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam15(V self, V *args) {
  V v_st_24131 = args[0];
  V v_x_24130 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24130}), v_st_24131});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam16(V self, V *args) {
  V v_st_24138 = args[0];
  V v_x_24137 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24137}), v_st_24138});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam17(V self, V *args) {
  V v_st_24145 = args[0];
  V v_x_24144 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24144}), v_st_24145});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam18(V self, V *args) {
  V v_st_24153 = args[0];
  V v_x_24152 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24152}), v_st_24153});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam19(V self, V *args) {
  V v_st_24160 = args[0];
  V v_x_24159 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24159}), v_st_24160});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam20(V self, V *args) {
  V v_st_24167 = args[0];
  V v_x_24166 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24166}), v_st_24167});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam21(V self, V *args) {
  V v_st_24175 = args[0];
  V v_x_24174 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24174}), v_st_24175});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam22(V self, V *args) {
  V v_st_24181 = args[0];
  V v_x_24180 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24180}), v_st_24181});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam23(V self, V *args) {
  V v_st_24189 = args[0];
  V v_x_24188 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24188}), v_st_24189});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam24(V self, V *args) {
  V v_st_24199 = args[0];
  V v_x_24198 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24198}), v_st_24199});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam25(V self, V *args) {
  V v_st_24208 = args[0];
  V v_x_24207 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24207}), v_st_24208});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam26(V self, V *args) {
  V v_st_24217 = args[0];
  V v_x_24216 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24216}), v_st_24217});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam27(V self, V *args) {
  V v_st_24225 = args[0];
  V v_x_24224 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24224}), v_st_24225});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam28(V self, V *args) {
  V v_st_24236 = args[0];
  V v_x_24235 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24235}), v_st_24236});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam29(V self, V *args) {
  V v_st_24243 = args[0];
  V v_x_24242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24242}), v_st_24243});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam30(V self, V *args) {
  V v_st_24251 = args[0];
  V v_x_24250 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24250}), v_st_24251});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam31(V self, V *args) {
  V v_st_24262 = args[0];
  V v_x_24261 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24261}), v_st_24262});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam32(V self, V *args) {
  V v_st_24273 = args[0];
  V v_x_24272 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24272}), v_st_24273});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam33(V self, V *args) {
  V v_st_24281 = args[0];
  V v_x_24280 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24280}), v_st_24281});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam34(V self, V *args) {
  V v_st_24290 = args[0];
  V v_x_24289 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24289}), v_st_24290});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam35(V self, V *args) {
  V v_st_24301 = args[0];
  V v_x_24300 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24300}), v_st_24301});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam36(V self, V *args) {
  V v_st_24307 = args[0];
  V v_x_24306 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24306}), v_st_24307});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam37(V self, V *args) {
  V v_st_24314 = args[0];
  V v_x_24313 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24313}), v_st_24314});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam38(V self, V *args) {
  V v_st_24323 = args[0];
  V v_x_24322 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24322}), v_st_24323});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam39(V self, V *args) {
  V v_st_24332 = args[0];
  V v_x_24331 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24331}), v_st_24332});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam40(V self, V *args) {
  V v_st_24341 = args[0];
  V v_x_24340 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24340}), v_st_24341});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam41(V self, V *args) {
  V v_st_24350 = args[0];
  V v_x_24349 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24349}), v_st_24350});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam42(V self, V *args) {
  V v_st_24359 = args[0];
  V v_x_24358 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24358}), v_st_24359});
}
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str0, 7, "integer");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str1, 28, "a segment says its type once");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str2, 6, "binary");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str3, 28, "a segment says its type once");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str4, 5, "bytes");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str5, 28, "a segment says its type once");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str6, 4, "bits");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str7, 28, "a segment says its type once");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str8, 9, "bitstring");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str9, 28, "a segment says its type once");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str10, 5, "float");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str11, 28, "a segment says its type once");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str12, 4, "utf8");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str13, 28, "a segment says its type once");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str14, 5, "utf16");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str15, 28, "a segment says its type once");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str16, 5, "utf32");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str17, 28, "a segment says its type once");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str18, 3, "big");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str19, 34, "a segment says its endianness once");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str20, 6, "little");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str21, 34, "a segment says its endianness once");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str22, 6, "signed");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str23, 28, "a segment says its sign once");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str24, 8, "unsigned");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str25, 28, "a segment says its sign once");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str26, 227, "a segment's spec is its type (`integer`, `binary`, `bits`, `float`, `utf8`, `utf16`, `utf32`), size (`16`, `size(n)`), unit (`unit(8)`), endianness (`big`, `little`) and sign (`signed`, `unsigned`), between `-`s: `x::16-little`");
Clo g_heff_2esyntax_2esurface_2especWord_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2especWord_entry, 3, 0};

V g_heff_2esyntax_2esurface_2especWord(V v_t_240, V v_s_241, V v_p_242) {
top: ;
  if (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 1)), ((V)&g_heff_2esyntax_2esurface_2especWord_str0))) {
    V v_t_244 = heff_take_field(v_s_241, 0);
    switch (heff_tag_of(v_t_244)) {
    case TAG_Nothing: {
      heff_drop_rec(v_t_240, 9);
      V v_t_245 = heff_tag_n(TAG_Just, 1, (V[]){NTAG(TAG_SegmentInteger)});
      V v_t_246 = ({ V rv_0 = v_t_245; V rr_ = heff_rec_reuse_nf(v_s_241, 30ULL, 5, shape_ty__size__unit__little__signed, 1020u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_246}), v_p_242});
    }
    case TAG_Just: {
      V v_ru_24t_244_24Just = heff_take_reuse_n(v_t_244, 0ULL, 1);
      heff_drop_rec(v_s_241, 5);
      V v_t_248 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_240, 3), heff_get_n(v_t_240, 4, 9)});
      V v_t_249 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2especWord_str1), v_t_248, NTAG(TAG_Nothing)});
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24t_244_24Just, TAG_Left, 1, (V[]){v_t_249}), v_p_242});
    }
    default: return heff_nomatch(v_t_244);
    }
  } else {
    if (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 1)), ((V)&g_heff_2esyntax_2esurface_2especWord_str2))) {
      V v_t_2411 = heff_take_field(v_s_241, 0);
      switch (heff_tag_of(v_t_2411)) {
      case TAG_Nothing: {
        heff_drop_rec(v_t_240, 9);
        V v_t_2412 = heff_tag_n(TAG_Just, 1, (V[]){NTAG(TAG_SegmentBinary)});
        V v_t_2413 = ({ V rv_0 = v_t_2412; V rr_ = heff_rec_reuse_nf(v_s_241, 30ULL, 5, shape_ty__size__unit__little__signed, 1020u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
        return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2413}), v_p_242});
      }
      case TAG_Just: {
        V v_ru_24t_2411_24Just = heff_take_reuse_n(v_t_2411, 0ULL, 1);
        heff_drop_rec(v_s_241, 5);
        V v_t_2415 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_240, 3), heff_get_n(v_t_240, 4, 9)});
        V v_t_2416 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2especWord_str3), v_t_2415, NTAG(TAG_Nothing)});
        return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24t_2411_24Just, TAG_Left, 1, (V[]){v_t_2416}), v_p_242});
      }
      default: return heff_nomatch(v_t_2411);
      }
    } else {
      if (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 1)), ((V)&g_heff_2esyntax_2esurface_2especWord_str4))) {
        V v_t_2418 = heff_take_field(v_s_241, 0);
        switch (heff_tag_of(v_t_2418)) {
        case TAG_Nothing: {
          heff_drop_rec(v_t_240, 9);
          V v_t_2419 = heff_tag_n(TAG_Just, 1, (V[]){NTAG(TAG_SegmentBinary)});
          V v_t_2420 = ({ V rv_0 = v_t_2419; V rr_ = heff_rec_reuse_nf(v_s_241, 30ULL, 5, shape_ty__size__unit__little__signed, 1020u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
          return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2420}), v_p_242});
        }
        case TAG_Just: {
          V v_ru_24t_2418_24Just = heff_take_reuse_n(v_t_2418, 0ULL, 1);
          heff_drop_rec(v_s_241, 5);
          V v_t_2422 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_240, 3), heff_get_n(v_t_240, 4, 9)});
          V v_t_2423 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2especWord_str5), v_t_2422, NTAG(TAG_Nothing)});
          return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24t_2418_24Just, TAG_Left, 1, (V[]){v_t_2423}), v_p_242});
        }
        default: return heff_nomatch(v_t_2418);
        }
      } else {
        if (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 1)), ((V)&g_heff_2esyntax_2esurface_2especWord_str6))) {
          V v_t_2425 = heff_take_field(v_s_241, 0);
          switch (heff_tag_of(v_t_2425)) {
          case TAG_Nothing: {
            heff_drop_rec(v_t_240, 9);
            V v_t_2426 = heff_tag_n(TAG_Just, 1, (V[]){NTAG(TAG_SegmentBits)});
            V v_t_2427 = ({ V rv_0 = v_t_2426; V rr_ = heff_rec_reuse_nf(v_s_241, 30ULL, 5, shape_ty__size__unit__little__signed, 1020u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
            return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2427}), v_p_242});
          }
          case TAG_Just: {
            V v_ru_24t_2425_24Just = heff_take_reuse_n(v_t_2425, 0ULL, 1);
            heff_drop_rec(v_s_241, 5);
            V v_t_2429 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_240, 3), heff_get_n(v_t_240, 4, 9)});
            V v_t_2430 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2especWord_str7), v_t_2429, NTAG(TAG_Nothing)});
            return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24t_2425_24Just, TAG_Left, 1, (V[]){v_t_2430}), v_p_242});
          }
          default: return heff_nomatch(v_t_2425);
          }
        } else {
          if (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 1)), ((V)&g_heff_2esyntax_2esurface_2especWord_str8))) {
            V v_t_2432 = heff_take_field(v_s_241, 0);
            switch (heff_tag_of(v_t_2432)) {
            case TAG_Nothing: {
              heff_drop_rec(v_t_240, 9);
              V v_t_2433 = heff_tag_n(TAG_Just, 1, (V[]){NTAG(TAG_SegmentBits)});
              V v_t_2434 = ({ V rv_0 = v_t_2433; V rr_ = heff_rec_reuse_nf(v_s_241, 30ULL, 5, shape_ty__size__unit__little__signed, 1020u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
              return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2434}), v_p_242});
            }
            case TAG_Just: {
              V v_ru_24t_2432_24Just = heff_take_reuse_n(v_t_2432, 0ULL, 1);
              heff_drop_rec(v_s_241, 5);
              V v_t_2436 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_240, 3), heff_get_n(v_t_240, 4, 9)});
              V v_t_2437 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2especWord_str9), v_t_2436, NTAG(TAG_Nothing)});
              return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24t_2432_24Just, TAG_Left, 1, (V[]){v_t_2437}), v_p_242});
            }
            default: return heff_nomatch(v_t_2432);
            }
          } else {
            if (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 1)), ((V)&g_heff_2esyntax_2esurface_2especWord_str10))) {
              V v_t_2439 = heff_take_field(v_s_241, 0);
              switch (heff_tag_of(v_t_2439)) {
              case TAG_Nothing: {
                heff_drop_rec(v_t_240, 9);
                V v_t_2440 = heff_tag_n(TAG_Just, 1, (V[]){NTAG(TAG_SegmentFloat)});
                V v_t_2441 = ({ V rv_0 = v_t_2440; V rr_ = heff_rec_reuse_nf(v_s_241, 30ULL, 5, shape_ty__size__unit__little__signed, 1020u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
                return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2441}), v_p_242});
              }
              case TAG_Just: {
                V v_ru_24t_2439_24Just = heff_take_reuse_n(v_t_2439, 0ULL, 1);
                heff_drop_rec(v_s_241, 5);
                V v_t_2443 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_240, 3), heff_get_n(v_t_240, 4, 9)});
                V v_t_2444 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2especWord_str11), v_t_2443, NTAG(TAG_Nothing)});
                return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24t_2439_24Just, TAG_Left, 1, (V[]){v_t_2444}), v_p_242});
              }
              default: return heff_nomatch(v_t_2439);
              }
            } else {
              if (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 1)), ((V)&g_heff_2esyntax_2esurface_2especWord_str12))) {
                V v_t_2446 = heff_take_field(v_s_241, 0);
                switch (heff_tag_of(v_t_2446)) {
                case TAG_Nothing: {
                  heff_drop_rec(v_t_240, 9);
                  V v_t_2447 = heff_tag_n(TAG_Just, 1, (V[]){heff_tag_n(TAG_SegmentUtf, 1, (V[]){MK_INT(8LL)})});
                  V v_t_2448 = ({ V rv_0 = v_t_2447; V rr_ = heff_rec_reuse_nf(v_s_241, 30ULL, 5, shape_ty__size__unit__little__signed, 1020u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
                  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2448}), v_p_242});
                }
                case TAG_Just: {
                  V v_ru_24t_2446_24Just = heff_take_reuse_n(v_t_2446, 0ULL, 1);
                  heff_drop_rec(v_s_241, 5);
                  V v_t_2450 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_240, 3), heff_get_n(v_t_240, 4, 9)});
                  V v_t_2451 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2especWord_str13), v_t_2450, NTAG(TAG_Nothing)});
                  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24t_2446_24Just, TAG_Left, 1, (V[]){v_t_2451}), v_p_242});
                }
                default: return heff_nomatch(v_t_2446);
                }
              } else {
                if (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 1)), ((V)&g_heff_2esyntax_2esurface_2especWord_str14))) {
                  V v_t_2453 = heff_take_field(v_s_241, 0);
                  switch (heff_tag_of(v_t_2453)) {
                  case TAG_Nothing: {
                    heff_drop_rec(v_t_240, 9);
                    V v_t_2454 = heff_tag_n(TAG_Just, 1, (V[]){heff_tag_n(TAG_SegmentUtf, 1, (V[]){MK_INT(16LL)})});
                    V v_t_2455 = ({ V rv_0 = v_t_2454; V rr_ = heff_rec_reuse_nf(v_s_241, 30ULL, 5, shape_ty__size__unit__little__signed, 1020u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
                    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2455}), v_p_242});
                  }
                  case TAG_Just: {
                    V v_ru_24t_2453_24Just = heff_take_reuse_n(v_t_2453, 0ULL, 1);
                    heff_drop_rec(v_s_241, 5);
                    V v_t_2457 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_240, 3), heff_get_n(v_t_240, 4, 9)});
                    V v_t_2458 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2especWord_str15), v_t_2457, NTAG(TAG_Nothing)});
                    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24t_2453_24Just, TAG_Left, 1, (V[]){v_t_2458}), v_p_242});
                  }
                  default: return heff_nomatch(v_t_2453);
                  }
                } else {
                  if (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 1)), ((V)&g_heff_2esyntax_2esurface_2especWord_str16))) {
                    V v_t_2460 = heff_take_field(v_s_241, 0);
                    switch (heff_tag_of(v_t_2460)) {
                    case TAG_Nothing: {
                      heff_drop_rec(v_t_240, 9);
                      V v_t_2461 = heff_tag_n(TAG_Just, 1, (V[]){heff_tag_n(TAG_SegmentUtf, 1, (V[]){MK_INT(32LL)})});
                      V v_t_2462 = ({ V rv_0 = v_t_2461; V rr_ = heff_rec_reuse_nf(v_s_241, 30ULL, 5, shape_ty__size__unit__little__signed, 1020u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
                      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2462}), v_p_242});
                    }
                    case TAG_Just: {
                      V v_ru_24t_2460_24Just = heff_take_reuse_n(v_t_2460, 0ULL, 1);
                      heff_drop_rec(v_s_241, 5);
                      V v_t_2464 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_240, 3), heff_get_n(v_t_240, 4, 9)});
                      V v_t_2465 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2especWord_str17), v_t_2464, NTAG(TAG_Nothing)});
                      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24t_2460_24Just, TAG_Left, 1, (V[]){v_t_2465}), v_p_242});
                    }
                    default: return heff_nomatch(v_t_2460);
                    }
                  } else {
                    if (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 1)), ((V)&g_heff_2esyntax_2esurface_2especWord_str18))) {
                      V v_t_2467 = heff_take_field(v_s_241, 3);
                      switch (heff_tag_of(v_t_2467)) {
                      case TAG_Nothing: {
                        heff_drop_rec(v_t_240, 9);
                        V v_t_2468 = heff_tag_n(TAG_Just, 1, (V[]){NTAG(TAG_False)});
                        V v_t_2469 = ({ V rv_3 = v_t_2468; V rr_ = heff_rec_reuse_nf(v_s_241, 23ULL, 5, shape_ty__size__unit__little__signed, 831u, 0u); heff_rfield(rr_, 3) = rv_3; rr_; });
                        return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2469}), v_p_242});
                      }
                      case TAG_Just: {
                        V v_ru_24t_2467_24Just = heff_take_reuse_n(v_t_2467, 0ULL, 1);
                        heff_drop_rec(v_s_241, 5);
                        V v_t_2471 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_240, 3), heff_get_n(v_t_240, 4, 9)});
                        V v_t_2472 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2especWord_str19), v_t_2471, NTAG(TAG_Nothing)});
                        return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24t_2467_24Just, TAG_Left, 1, (V[]){v_t_2472}), v_p_242});
                      }
                      default: return heff_nomatch(v_t_2467);
                      }
                    } else {
                      if (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 1)), ((V)&g_heff_2esyntax_2esurface_2especWord_str20))) {
                        V v_t_2474 = heff_take_field(v_s_241, 3);
                        switch (heff_tag_of(v_t_2474)) {
                        case TAG_Nothing: {
                          heff_drop_rec(v_t_240, 9);
                          V v_t_2475 = heff_tag_n(TAG_Just, 1, (V[]){NTAG(TAG_True)});
                          V v_t_2476 = ({ V rv_3 = v_t_2475; V rr_ = heff_rec_reuse_nf(v_s_241, 23ULL, 5, shape_ty__size__unit__little__signed, 831u, 0u); heff_rfield(rr_, 3) = rv_3; rr_; });
                          return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2476}), v_p_242});
                        }
                        case TAG_Just: {
                          V v_ru_24t_2474_24Just = heff_take_reuse_n(v_t_2474, 0ULL, 1);
                          heff_drop_rec(v_s_241, 5);
                          V v_t_2478 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_240, 3), heff_get_n(v_t_240, 4, 9)});
                          V v_t_2479 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2especWord_str21), v_t_2478, NTAG(TAG_Nothing)});
                          return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24t_2474_24Just, TAG_Left, 1, (V[]){v_t_2479}), v_p_242});
                        }
                        default: return heff_nomatch(v_t_2474);
                        }
                      } else {
                        if (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 1)), ((V)&g_heff_2esyntax_2esurface_2especWord_str22))) {
                          V v_t_2481 = heff_take_field(v_s_241, 4);
                          switch (heff_tag_of(v_t_2481)) {
                          case TAG_Nothing: {
                            heff_drop_rec(v_t_240, 9);
                            V v_t_2482 = heff_tag_n(TAG_Just, 1, (V[]){NTAG(TAG_True)});
                            V v_t_2483 = ({ V rv_4 = v_t_2482; V rr_ = heff_rec_reuse_nf(v_s_241, 15ULL, 5, shape_ty__size__unit__little__signed, 255u, 0u); heff_rfield(rr_, 4) = rv_4; rr_; });
                            return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2483}), v_p_242});
                          }
                          case TAG_Just: {
                            V v_ru_24t_2481_24Just = heff_take_reuse_n(v_t_2481, 0ULL, 1);
                            heff_drop_rec(v_s_241, 5);
                            V v_t_2485 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_240, 3), heff_get_n(v_t_240, 4, 9)});
                            V v_t_2486 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2especWord_str23), v_t_2485, NTAG(TAG_Nothing)});
                            return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24t_2481_24Just, TAG_Left, 1, (V[]){v_t_2486}), v_p_242});
                          }
                          default: return heff_nomatch(v_t_2481);
                          }
                        } else {
                          if (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 1)), ((V)&g_heff_2esyntax_2esurface_2especWord_str24))) {
                            V v_t_2488 = heff_take_field(v_s_241, 4);
                            switch (heff_tag_of(v_t_2488)) {
                            case TAG_Nothing: {
                              heff_drop_rec(v_t_240, 9);
                              V v_t_2489 = heff_tag_n(TAG_Just, 1, (V[]){NTAG(TAG_False)});
                              V v_t_2490 = ({ V rv_4 = v_t_2489; V rr_ = heff_rec_reuse_nf(v_s_241, 15ULL, 5, shape_ty__size__unit__little__signed, 255u, 0u); heff_rfield(rr_, 4) = rv_4; rr_; });
                              return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2490}), v_p_242});
                            }
                            case TAG_Just: {
                              V v_ru_24t_2488_24Just = heff_take_reuse_n(v_t_2488, 0ULL, 1);
                              heff_drop_rec(v_s_241, 5);
                              V v_t_2492 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_240, 3), heff_get_n(v_t_240, 4, 9)});
                              V v_t_2493 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2especWord_str25), v_t_2492, NTAG(TAG_Nothing)});
                              return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24t_2488_24Just, TAG_Left, 1, (V[]){v_t_2493}), v_p_242});
                            }
                            default: return heff_nomatch(v_t_2488);
                            }
                          } else {
                            heff_drop_rec(v_s_241, 5);
                            V v_t_2494 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_240, 3), heff_get_n(v_t_240, 4, 9)});
                            V v_t_2495 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2especWord_str26), v_t_2494, NTAG(TAG_Nothing)});
                            return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2495}), v_p_242});
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}
V g_heff_2esyntax_2esurface_2especWord_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2especWord(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2esyntax_2esurface_2eunitOf_str0, 3, "int");
HEFF_LIT(g_heff_2esyntax_2esurface_2eunitOf_str1, 28, "a segment says its unit once");
HEFF_LIT(g_heff_2esyntax_2esurface_2eunitOf_str2, 47, "a unit is a number of bits, 1 to 256: `unit(8)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eunitOf_str3, 47, "a unit is a number of bits, 1 to 256: `unit(8)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eunitOf_str4, 47, "a unit is a number of bits, 1 to 256: `unit(8)`");
V g_heff_2esyntax_2esurface_2eunitOf_lam0(V self, V *args);
V g_heff_2esyntax_2esurface_2eunitOf_lam1(V self, V *args);
V g_heff_2esyntax_2esurface_2eunitOf_lam2(V self, V *args);
V g_heff_2esyntax_2esurface_2eunitOf_lam3(V self, V *args);
Clo g_heff_2esyntax_2esurface_2eunitOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eunitOf_entry, 3, 0};

V g_heff_2esyntax_2esurface_2eunitOf(V v_sp_240, V v_n_241, V v_s_242) {
top: ;
  if (heff_strEq_c(heff_dup(heff_rfield(v_n_241, 0)), ((V)&g_heff_2esyntax_2esurface_2eunitOf_str0))) {
    V v_t_244 = (g_heff_2esyntax_2esurface_2eintOfText(heff_rfield(v_n_241, 1)));
    if (heff_intLe_c(MK_INT(1LL), v_t_244)) {
      V v_t_246 = (g_heff_2esyntax_2esurface_2eintOfText(heff_rfield(v_n_241, 1)));
      if (heff_intLe_c(v_t_246, MK_INT(256LL))) {
        V v_n_248 = ({ V b_0 = heff_get_n(v_n_241, 1, 9); V r_ = (g_heff_2esyntax_2esurface_2eintOfText(b_0)); heff_drop(b_0); r_; });
        return heff_clo_n(g_heff_2esyntax_2esurface_2eunitOf_lam0, 1, 3, (V[]){v_s_242, v_n_248, v_sp_240});
      } else {
        heff_drop_rec(v_n_241, 9);
        heff_drop_rec(v_s_242, 5);
        return heff_clo_n(g_heff_2esyntax_2esurface_2eunitOf_lam1, 1, 1, (V[]){v_sp_240});
      }
    } else {
      heff_drop_rec(v_n_241, 9);
      heff_drop_rec(v_s_242, 5);
      return heff_clo_n(g_heff_2esyntax_2esurface_2eunitOf_lam2, 1, 1, (V[]){v_sp_240});
    }
  } else {
    heff_drop_rec(v_n_241, 9);
    heff_drop_rec(v_s_242, 5);
    return heff_clo_n(g_heff_2esyntax_2esurface_2eunitOf_lam3, 1, 1, (V[]){v_sp_240});
  }
}
V g_heff_2esyntax_2esurface_2eunitOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2eunitOf(a[0], a[1], a[2]);
}
V g_heff_2esyntax_2esurface_2eunitOf_lam0(V self, V *args) {
  V v_p_249 = args[0];
  V v_s_242 = heff_env(self)[0];
  V v_n_248 = heff_env(self)[1];
  V v_sp_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2410 = heff_take_field(v_s_242, 2);
  switch (heff_tag_of(v_t_2410)) {
  case TAG_Nothing: {
    heff_drop(v_sp_240);
    V v_t_2411 = ({ V rv_2 = heff_tag_n(TAG_Just, 1, (V[]){v_n_248}); V rr_ = heff_rec_reuse_nf(v_s_242, 27ULL, 5, shape_ty__size__unit__little__signed, 975u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2411}), v_p_249});
  }
  case TAG_Just: {
    V v_ru_24t_2410_24Just = heff_take_reuse_n(v_t_2410, 0ULL, 1);
    heff_drop_rec(v_s_242, 5);
    heff_drop(v_n_248);
    V v_t_2413 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2eunitOf_str1), v_sp_240, NTAG(TAG_Nothing)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24t_2410_24Just, TAG_Left, 1, (V[]){v_t_2413}), v_p_249});
  }
  default: return heff_nomatch(v_t_2410);
  }
}
V g_heff_2esyntax_2esurface_2eunitOf_lam1(V self, V *args) {
  V v_st_2414 = args[0];
  V v_sp_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2415 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2eunitOf_str2), v_sp_240, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2415}), v_st_2414});
}
V g_heff_2esyntax_2esurface_2eunitOf_lam2(V self, V *args) {
  V v_st_2416 = args[0];
  V v_sp_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2417 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2eunitOf_str3), v_sp_240, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2417}), v_st_2416});
}
V g_heff_2esyntax_2esurface_2eunitOf_lam3(V self, V *args) {
  V v_st_2418 = args[0];
  V v_sp_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2419 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2eunitOf_str4), v_sp_240, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2419}), v_st_2418});
}
Clo g_heff_2esyntax_2esurface_2esegmentOf_24s1547151193x813882637_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2esegmentOf_24s1547151193x813882637_entry, 5, 0};

V g_heff_2esyntax_2esurface_2esegmentOf_24s1547151193x813882637(V v_inPat_240, V v_sp_241, V v_e_242, V v_v_243, V v_st_244) {
top: ;
  V v_t_246;
  switch (heff_tag_of(v_v_243)) {
  case TAG_StrValue: {
    v_t_246 = NTAG(TAG_SegmentBinary);
    break;
  }
  case TAG_IntValue: {
    v_t_246 = NTAG(TAG_SegmentInteger);
    break;
  }
  case TAG_FloatValue: {
    v_t_246 = NTAG(TAG_SegmentFloat);
    break;
  }
  case TAG_RuneValue: {
    v_t_246 = heff_tag_n(TAG_SegmentUtf, 1, (V[]){MK_INT(8LL)});
    break;
  }
  case TAG_OtherValue: {
    v_t_246 = NTAG(TAG_SegmentInteger);
    break;
  }
  default: heff_nomatch(v_v_243);
  }
  HeffT2 v_t_247 = (g_heff_2esyntax_2esurface_2evalueKind_24cpr(heff_dup(v_sp_241), heff_dup(v_v_243), v_t_246, v_st_244));
  {
    V v_field_248 = v_t_247.f[0];
    V v_field_249 = v_t_247.f[1];
    V v_x11_2410 = v_field_248;
    V v_st_2411 = v_field_249;
    switch (heff_tag_of(v_x11_2410)) {
    case TAG_Left: {
      V v_e_2412 = heff_field(v_x11_2410, 0);
      V v_ru_24x11_2410_24Left = heff_take_reuse_n(v_x11_2410, 1ULL, 1);
      heff_drop(v_sp_241);
      heff_drop(v_e_242);
      heff_drop(v_v_243);
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_2410_24Left, TAG_Left, 1, (V[]){v_e_2412}), v_st_2411});
    }
    case TAG_Right: {
      V v_ru_24x11_2410_24Right = heff_take_reuse_n(v_x11_2410, 0ULL, 1);
      V v_t_2415;
      switch (heff_tag_of(v_v_243)) {
      case TAG_StrValue: {
        v_t_2415 = NTAG(TAG_SegmentBinary);
        break;
      }
      case TAG_IntValue: {
        v_t_2415 = NTAG(TAG_SegmentInteger);
        break;
      }
      case TAG_FloatValue: {
        v_t_2415 = NTAG(TAG_SegmentFloat);
        break;
      }
      case TAG_RuneValue: {
        v_t_2415 = heff_tag_n(TAG_SegmentUtf, 1, (V[]){MK_INT(8LL)});
        break;
      }
      case TAG_OtherValue: {
        v_t_2415 = NTAG(TAG_SegmentInteger);
        break;
      }
      default: heff_nomatch(v_v_243);
      }
      V v_m_2416 = (g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993(v_inPat_240, heff_dup(v_sp_241), heff_dup(v_v_243), v_t_2415, NTAG(TAG_SizeDefault)));
      V v_x1_2417 = heff_tr(heff_call(v_m_2416, 1, (V[]){v_st_2411}));
      switch (heff_tag_of(v_x1_2417)) {
      case TAG_MkPair: {
        V v_x11_2418 = heff_field(v_x1_2417, 0);
        V v_st_2419 = heff_field(v_x1_2417, 1);
        V v_ru_24x1_2417_24MkPair = heff_take_reuse_n(v_x1_2417, 3ULL, 2);
        switch (heff_tag_of(v_x11_2418)) {
        case TAG_Left: {
          V v_e_2420 = heff_field(v_x11_2418, 0);
          heff_take_n(v_x11_2418, 1ULL, 1);
          heff_drop(v_sp_241);
          heff_drop(v_e_242);
          heff_drop(v_v_243);
          heff_drop_cell(v_ru_24x11_2410_24Right, 1);
          return heff_tag_at_n(v_ru_24x1_2417_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2420}), v_st_2419});
        }
        case TAG_Right: {
          V v_ru_24x11_2418_24Right = heff_take_reuse_n(v_x11_2418, 0ULL, 1);
          V v_t_2423;
          switch (heff_tag_of(v_v_243)) {
          case TAG_StrValue: {
            heff_drop_cell(v_ru_24x11_2418_24Right, 1);
            v_t_2423 = NTAG(TAG_SegmentBinary);
            break;
          }
          case TAG_IntValue: {
            heff_take_n(v_v_243, 0ULL, 1);
            heff_drop_cell(v_ru_24x11_2418_24Right, 1);
            v_t_2423 = NTAG(TAG_SegmentInteger);
            break;
          }
          case TAG_FloatValue: {
            heff_drop_cell(v_ru_24x11_2418_24Right, 1);
            v_t_2423 = NTAG(TAG_SegmentFloat);
            break;
          }
          case TAG_RuneValue: {
            v_t_2423 = heff_tag_at_n(v_ru_24x11_2418_24Right, TAG_SegmentUtf, 1, (V[]){MK_INT(8LL)});
            break;
          }
          case TAG_OtherValue: {
            heff_drop_cell(v_ru_24x11_2418_24Right, 1);
            v_t_2423 = NTAG(TAG_SegmentInteger);
            break;
          }
          default: heff_nomatch(v_v_243);
          }
          V v_t_2424 = heff_tag_n(TAG_MkSegment, 5, (V[]){v_e_242, v_t_2423, NTAG(TAG_SizeDefault), NTAG(TAG_False), NTAG(TAG_False)});
          V v_t_2425 = heff_tag_at_n(v_ru_24x11_2410_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2424, v_sp_241})});
          return heff_tag_at_n(v_ru_24x1_2417_24MkPair, TAG_MkPair, 2, (V[]){v_t_2425, v_st_2419});
        }
        default: return heff_nomatch(v_x11_2418);
        }
      }
      default: return heff_nomatch(v_x1_2417);
      }
    }
    default: return heff_nomatch(v_x11_2410);
    }
  }
}
V g_heff_2esyntax_2esurface_2esegmentOf_24s1547151193x813882637_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2esurface_2esegmentOf_24s1547151193x813882637(a0, a[1], a[2], a[3], a[4]); heff_drop(a0); return r;
}
V g_heff_2esyntax_2esurface_2epushS_24s1868233564x1858628873_lam0(V self, V *args);
V g_heff_2esyntax_2esurface_2epushS_24s1868233564x1858628873_lam1(V self, V *args);
Clo g_heff_2esyntax_2esurface_2epushS_24s1868233564x1858628873_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2epushS_24s1868233564x1858628873_entry, 4, 0};

V g_heff_2esyntax_2esurface_2epushS_24s1868233564x1858628873(V v_fix_240, V v_lenient_241, V v_st_242, V v_r_243) {
top: ;
  V v_t_244 = heff_dup(heff_rfield(v_st_242, 0));
  switch (heff_tag_of(v_t_244)) {
  case TAG_Nil: {
    heff_drop(v_fix_240);
    return heff_clo_n(g_heff_2esyntax_2esurface_2epushS_24s1868233564x1858628873_lam0, 1, 2, (V[]){v_r_243, v_st_242});
  }
  case TAG_Cons: {
    V v_before_249 = heff_field(v_t_244, 0);
    heff_take_n(v_t_244, 1ULL, 2);
    V v_m_2411 = (g_heff_2esyntax_2esurface_2efirstS(heff_dup(v_fix_240), v_lenient_241, v_before_249, heff_dup(heff_rfield(v_r_243, 0))));
    return heff_clo_n(g_heff_2esyntax_2esurface_2epushS_24s1868233564x1858628873_lam1, 1, 5, (V[]){v_m_2411, v_st_242, v_fix_240, heff_dup(v_lenient_241), v_r_243});
  }
  default: return heff_nomatch(v_t_244);
  }
}
V g_heff_2esyntax_2esurface_2epushS_24s1868233564x1858628873_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2esyntax_2esurface_2epushS_24s1868233564x1858628873(a[0], a1, a[2], a[3]); heff_drop(a1); return r;
}
V g_heff_2esyntax_2esurface_2epushS_24s1868233564x1858628873_lam0(V self, V *args) {
  V v_st_245 = args[0];
  V v_r_243 = heff_env(self)[0];
  V v_st_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){heff_take_field(v_r_243, 0), heff_take_field(v_st_242, 0)});
  V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){heff_get_n(v_r_243, 1, 2), heff_get_n(v_st_242, 1, 2)});
  V v_t_248 = heff_tag_n(TAG_Right, 1, (V[]){heff_rec_n(2, shape_ops__out, (V[]){v_t_246, v_t_247})});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_248, v_st_245});
}
V g_heff_2esyntax_2esurface_2epushS_24s1868233564x1858628873_lam1(V self, V *args) {
  V v_st_2412 = args[0];
  V v_m_2411 = heff_env(self)[0];
  V v_st_242 = heff_env(self)[1];
  V v_fix_240 = heff_env(self)[2];
  V v_lenient_241 = heff_env(self)[3];
  V v_r_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_x1_2413 = heff_tr(heff_call(v_m_2411, 1, (V[]){v_st_2412}));
  switch (heff_tag_of(v_x1_2413)) {
  case TAG_MkPair: {
    V v_x11_2414 = heff_field(v_x1_2413, 0);
    V v_st_2415 = heff_field(v_x1_2413, 1);
    V v_ru_24x1_2413_24MkPair = heff_take_reuse_n(v_x1_2413, 3ULL, 2);
    switch (heff_tag_of(v_x11_2414)) {
    case TAG_Left: {
      V v_e_2416 = heff_field(v_x11_2414, 0);
      heff_take_n(v_x11_2414, 1ULL, 1);
      heff_drop_rec(v_st_242, 2);
      heff_drop(v_fix_240);
      heff_drop(v_lenient_241);
      heff_drop_rec(v_r_243, 2);
      return heff_tag_at_n(v_ru_24x1_2413_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2416}), v_st_2415});
    }
    case TAG_Right: {
      V v_x_2417 = heff_field(v_x11_2414, 0);
      V v_ru_24x11_2414_24Right = heff_take_reuse_n(v_x11_2414, 1ULL, 1);
      if ((heff_dup(v_x_2417) == NTAG(TAG_True))) {
        heff_drop_cell(v_ru_24x1_2413_24MkPair, 2);
        heff_drop(v_x_2417);
        heff_drop_cell(v_ru_24x11_2414_24Right, 1);
        V v_t_2418 = heff_dup(heff_rfield(v_st_242, 0));
        V v_t_2427;
        switch (heff_tag_of(v_t_2418)) {
        case TAG_Nil: {
          v_t_2427 = v_st_242;
          break;
        }
        case TAG_Cons: {
          V v_o_2419 = heff_field(v_t_2418, 0);
          V v_os_2420 = heff_field(v_t_2418, 1);
          heff_take_n(v_t_2418, 3ULL, 2);
          V v_t_2421 = heff_dup(heff_rfield(v_st_242, 1));
          switch (heff_tag_of(v_t_2421)) {
          case TAG_Nil: {
            heff_drop(v_o_2419);
            heff_drop(v_os_2420);
            v_t_2427 = v_st_242;
            break;
          }
          case TAG_Cons: {
            V v_r_2422 = heff_field(v_t_2421, 0);
            V v_it2_2423 = heff_field(v_t_2421, 1);
            heff_take_n(v_t_2421, 3ULL, 2);
            switch (heff_tag_of(v_it2_2423)) {
            case TAG_Nil: {
              heff_drop(v_o_2419);
              heff_drop(v_os_2420);
              heff_drop(v_r_2422);
              v_t_2427 = v_st_242;
              break;
            }
            case TAG_Cons: {
              V v_l_2424 = heff_field(v_it2_2423, 0);
              V v_rest_2425 = heff_field(v_it2_2423, 1);
              heff_take_n(v_it2_2423, 3ULL, 2);
              heff_drop_rec(v_st_242, 2);
              V v_t_2426 = (g_heff_2esyntax_2esurface_2eapplyOp(v_o_2419, v_l_2424, v_r_2422));
              v_t_2427 = heff_rec_n(2, shape_ops__out, (V[]){v_os_2420, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2426, v_rest_2425})});
              break;
            }
            default: heff_nomatch(v_it2_2423);
            }
            break;
          }
          default: heff_nomatch(v_t_2421);
          }
          break;
        }
        default: heff_nomatch(v_t_2418);
        }
        V v_t_2428 = ({ V a_0 = v_fix_240; V a_1 = v_lenient_241; V a_2 = v_t_2427; V a_3 = v_r_243; V r_ = (g_heff_2esyntax_2esurface_2epushS_24s1868233564x1858628873(a_0, a_1, a_2, a_3)); heff_drop(v_lenient_241); r_; });
        V f_ = v_t_2428;
        args[0] = v_st_2415;
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      } else {
        heff_drop(v_fix_240);
        heff_drop(v_lenient_241);
        heff_drop(v_x_2417);
        V v_t_2429 = heff_tag_n(TAG_Cons, 2, (V[]){heff_take_field(v_r_243, 0), heff_take_field(v_st_242, 0)});
        V v_t_2430 = heff_tag_n(TAG_Cons, 2, (V[]){heff_get_n(v_r_243, 1, 2), heff_get_n(v_st_242, 1, 2)});
        V v_t_2431 = heff_tag_at_n(v_ru_24x11_2414_24Right, TAG_Right, 1, (V[]){heff_rec_n(2, shape_ops__out, (V[]){v_t_2429, v_t_2430})});
        return heff_tag_at_n(v_ru_24x1_2413_24MkPair, TAG_MkPair, 2, (V[]){v_t_2431, v_st_2415});
      }
    }
    default: return heff_nomatch(v_x11_2414);
    }
  }
  default: return heff_nomatch(v_x1_2413);
  }
}
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str0, 3, "con");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str1, 3, "var");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str2, 7, " := e)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str3, 51, " := ...)` names an argument, after a function: `f (");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str4, 2, "`(");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str5, 2, "b[");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str6, 1, "[");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str7, 3, "Nil");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str8, 4, "Cons");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str9, 70, "heff has no tuples: a record holds values together, `{ x = a, y = b }`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str10, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str11, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str12, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str13, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str14, 61, "an instance argument is bound before `->`: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str15, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str16, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str17, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str18, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str19, 3, "con");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str20, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str21, 3, "var");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str22, 3, "neg");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str23, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str24, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str25, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str26, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str27, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str28, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str29, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str30, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str31, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str32, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str33, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str34, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str35, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str36, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str37, 5, "break");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str38, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str39, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str40, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str41, 12, "unexpected `");
V g_heff_2esyntax_2esurface_2eexprL_lam0(V self, V *args);
V g_heff_2esyntax_2esurface_2eexprL_lam1(V self, V *args);
V g_heff_2esyntax_2esurface_2eexprL_lam2(V self, V *args);
V g_heff_2esyntax_2esurface_2eexprL_lam3(V self, V *args);
V g_heff_2esyntax_2esurface_2eexprL_lam4(V self, V *args);
V g_heff_2esyntax_2esurface_2eexprL_lam6(V self, V *args);
V g_heff_2esyntax_2esurface_2eexprL_lam5(V self, V *args);
V g_heff_2esyntax_2esurface_2eexprL_lam7(V self, V *args);
V g_heff_2esyntax_2esurface_2eexprL_lam8(V self, V *args);
V g_heff_2esyntax_2esurface_2eexprL_lam9(V self, V *args);
V g_heff_2esyntax_2esurface_2eexprL_lam10(V self, V *args);
V g_heff_2esyntax_2esurface_2eexprL_lam11(V self, V *args);
Clo g_heff_2esyntax_2esurface_2eexprL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eexprL_entry, 3, 0};

V g_heff_2esyntax_2esurface_2eexprL(V v_r_240, V v_e0_241, V v_z_242) {
top: ;
  switch (heff_tag_of(v_e0_241)) {
  case TAG_Atom: {
    V v_t_243 = heff_field(v_e0_241, 0);
    V v_ru_24e0_241_24Atom = heff_take_reuse_n(v_e0_241, 1ULL, 1);
    heff_drop_rec(v_r_240, 3);
    if (heff_strEq_c(heff_dup(heff_rfield(v_t_243, 0)), ((V)&g_heff_2esyntax_2esurface_2eexprL_str0))) {
      heff_drop_cell(v_ru_24e0_241_24Atom, 1);
      HEFF_LAST return g_heff_2esyntax_2esurface_2econAtom(v_t_243, NTAG(TAG_Nil), v_z_242);
    } else {
      if (heff_strEq_c(heff_dup(heff_rfield(v_t_243, 0)), ((V)&g_heff_2esyntax_2esurface_2eexprL_str1))) {
        heff_drop_cell(v_ru_24e0_241_24Atom, 1);
        HEFF_LAST return g_heff_2esyntax_2esurface_2evarAtom(v_t_243, NTAG(TAG_Nil), v_z_242);
      } else {
        V v_x_246 = (g_heff_2esyntax_2esurface_2eatomTok(v_t_243));
        return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24e0_241_24Atom, TAG_Right, 1, (V[]){v_x_246}), v_z_242});
      }
    }
  }
  case TAG_EParen: {
    V v_o_247 = heff_field(v_e0_241, 0);
    V v_e_248 = heff_field(v_e0_241, 1);
    V v_c_249 = heff_field(v_e0_241, 2);
    heff_take_n(v_e0_241, 7ULL, 3);
    return ({ V a_0 = v_r_240; V a_1 = v_o_247; V a_2 = v_e_248; V a_3 = v_c_249; V a_4 = v_z_242; V r_ = (g_heff_2esyntax_2esurface_2eparenL(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_o_247); r_; });
  }
  case TAG_Named: {
    V v_o_2410 = heff_field(v_e0_241, 0);
    V v_x_2411 = heff_field(v_e0_241, 1);
    V v_e_2413 = heff_field(v_e0_241, 3);
    V v_c_2414 = heff_field(v_e0_241, 4);
    heff_take_n(v_e0_241, 27ULL, 5);
    V v_m_2415 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_2413}));
    V v_x1_2416 = heff_tr(heff_call(v_m_2415, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x1_2416)) {
    case TAG_MkPair: {
      V v_x11_2417 = heff_field(v_x1_2416, 0);
      V v_st_2418 = heff_field(v_x1_2416, 1);
      V v_ru_24x1_2416_24MkPair = heff_take_reuse_n(v_x1_2416, 3ULL, 2);
      switch (heff_tag_of(v_x11_2417)) {
      case TAG_Left: {
        V v_e_2419 = heff_field(v_x11_2417, 0);
        heff_take_n(v_x11_2417, 1ULL, 1);
        heff_drop_rec(v_o_2410, 9);
        heff_drop_rec(v_x_2411, 9);
        heff_drop_rec(v_c_2414, 9);
        return heff_tag_at_n(v_ru_24x1_2416_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2419}), v_st_2418});
      }
      case TAG_Right: {
        V v_ru_24x11_2417_24Right = heff_take_reuse_n(v_x11_2417, 0ULL, 1);
        V v_t_2421 = heff_strAppend(heff_dup(heff_rfield(v_x_2411, 1)), ((V)&g_heff_2esyntax_2esurface_2eexprL_str2));
        V v_t_2422 = heff_strAppend(heff_get_n(v_x_2411, 1, 9), heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eexprL_str3), v_t_2421));
        V v_t_2423 = heff_tag_n(TAG_EInvalid, 1, (V[]){heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eexprL_str4), v_t_2422)});
        V v_t_2424 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_o_2410, 3, 9), heff_get_n(v_c_2414, 4, 9)});
        V v_t_2425 = heff_tag_at_n(v_ru_24x11_2417_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2423, v_t_2424})});
        return heff_tag_at_n(v_ru_24x1_2416_24MkPair, TAG_MkPair, 2, (V[]){v_t_2425, v_st_2418});
      }
      default: return heff_nomatch(v_x11_2417);
      }
    }
    default: return heff_nomatch(v_x1_2416);
    }
  }
  case TAG_Tup: {
    V v_o_2426 = heff_field(v_e0_241, 0);
    V v_es_2427 = heff_field(v_e0_241, 1);
    V v_c_2429 = heff_field(v_e0_241, 3);
    heff_take_n(v_e0_241, 11ULL, 4);
    if (heff_strEq_c(heff_dup(heff_rfield(v_o_2426, 1)), ((V)&g_heff_2esyntax_2esurface_2eexprL_str5))) {
      V v_m_2432 = (g_prelude_2etraverse_24s499544530x2060473942(heff_clo_n(g_heff_2esyntax_2esurface_2eexprL_lam0, 1, 1, (V[]){v_r_240}), v_es_2427));
      V v_x1_2433 = heff_tr(heff_call(v_m_2432, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_2433)) {
      case TAG_MkPair: {
        V v_x11_2434 = heff_field(v_x1_2433, 0);
        V v_st_2435 = heff_field(v_x1_2433, 1);
        V v_ru_24x1_2433_24MkPair = heff_take_reuse_n(v_x1_2433, 3ULL, 2);
        switch (heff_tag_of(v_x11_2434)) {
        case TAG_Left: {
          V v_e_2436 = heff_field(v_x11_2434, 0);
          heff_take_n(v_x11_2434, 1ULL, 1);
          heff_drop_rec(v_o_2426, 9);
          heff_drop_rec(v_c_2429, 9);
          return heff_tag_at_n(v_ru_24x1_2433_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2436}), v_st_2435});
        }
        case TAG_Right: {
          V v_x_2437 = heff_field(v_x11_2434, 0);
          V v_ru_24x11_2434_24Right = heff_take_reuse_n(v_x11_2434, 1ULL, 1);
          V v_t_2438 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_o_2426, 3, 9), heff_get_n(v_c_2429, 4, 9)});
          V v_t_2439 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_2434_24Right, TAG_EBinary, 1, (V[]){v_x_2437}), v_t_2438});
          return heff_tag_at_n(v_ru_24x1_2433_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2439}), v_st_2435});
        }
        default: return heff_nomatch(v_x11_2434);
        }
      }
      default: return heff_nomatch(v_x1_2433);
      }
    } else {
      if (heff_strEq_c(heff_dup(heff_rfield(v_o_2426, 1)), ((V)&g_heff_2esyntax_2esurface_2eexprL_str6))) {
        V v_m_2441 = (g_prelude_2etraverse_24s499544530x2060473942(heff_get_n(v_r_240, 0, 3), v_es_2427));
        V v_x1_2442 = heff_tr(heff_call(v_m_2441, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_2442)) {
        case TAG_MkPair: {
          V v_x11_2443 = heff_field(v_x1_2442, 0);
          V v_st_2444 = heff_field(v_x1_2442, 1);
          V v_ru_24x1_2442_24MkPair = heff_take_reuse_n(v_x1_2442, 3ULL, 2);
          switch (heff_tag_of(v_x11_2443)) {
          case TAG_Left: {
            V v_e_2445 = heff_field(v_x11_2443, 0);
            heff_take_n(v_x11_2443, 1ULL, 1);
            heff_drop_rec(v_o_2426, 9);
            heff_drop_rec(v_c_2429, 9);
            return heff_tag_at_n(v_ru_24x1_2442_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2445}), v_st_2444});
          }
          case TAG_Right: {
            V v_x_2446 = heff_field(v_x11_2443, 0);
            V v_ru_24x11_2443_24Right = heff_take_reuse_n(v_x11_2443, 1ULL, 1);
            V v_sp_2447 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_o_2426, 3, 9), heff_get_n(v_c_2429, 4, 9)});
            V v_t_2448 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_2443_24Right, TAG_ETag, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2eexprL_str7)}), heff_dup(v_sp_2447)});
            V v_x_2453 = ({ V a_0 = heff_clo_n(g_heff_2esyntax_2esurface_2eexprL_lam1, 2, 1, (V[]){v_sp_2447}); V a_1 = v_t_2448; V a_2 = v_x_2446; V r_ = heff_tr(g_heff_2esyntax_2esurface_2efoldr(a_0, a_1, a_2)); heff_drop(v_x_2446); r_; });
            return heff_tag_at_n(v_ru_24x1_2442_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2453}), v_st_2444});
          }
          default: return heff_nomatch(v_x11_2443);
          }
        }
        default: return heff_nomatch(v_x1_2442);
        }
      } else {
        V v_m_2454 = (g_prelude_2etraverse_24s499544530x2060473942(heff_get_n(v_r_240, 0, 3), v_es_2427));
        V v_x1_2455 = heff_tr(heff_call(v_m_2454, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_2455)) {
        case TAG_MkPair: {
          V v_x11_2456 = heff_field(v_x1_2455, 0);
          V v_st_2457 = heff_field(v_x1_2455, 1);
          V v_ru_24x1_2455_24MkPair = heff_take_reuse_n(v_x1_2455, 3ULL, 2);
          switch (heff_tag_of(v_x11_2456)) {
          case TAG_Left: {
            V v_e_2458 = heff_field(v_x11_2456, 0);
            heff_take_n(v_x11_2456, 1ULL, 1);
            heff_drop_rec(v_o_2426, 9);
            heff_drop_rec(v_c_2429, 9);
            return heff_tag_at_n(v_ru_24x1_2455_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2458}), v_st_2457});
          }
          case TAG_Right: {
            V v_ru_24x11_2456_24Right = heff_take_reuse_n(v_x11_2456, 0ULL, 1);
            V v_t_2460 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_o_2426, 3, 9), heff_get_n(v_c_2429, 4, 9)});
            V v_t_2461 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_2456_24Right, TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2eexprL_str9)}), v_t_2460});
            return heff_tag_at_n(v_ru_24x1_2455_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2461}), v_st_2457});
          }
          default: return heff_nomatch(v_x11_2456);
          }
        }
        default: return heff_nomatch(v_x1_2455);
        }
      }
    }
  }
  case TAG_Seg: {
    heff_drop_rec(v_r_240, 3);
    V v_t_2465 = (g_heff_2esyntax_2ecst_2efirstE(v_e0_241));
    V v_t_2466 = ({ V a_0 = v_e0_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e0_241, 3); r_; });
    V v_t_2467 = heff_strAppend(heff_get_n(v_t_2466, 1, 9), ((V)&g_heff_2esyntax_2esurface_2eexprL_str10));
    V v_msg_2468 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eexprL_str11), v_t_2467);
    V v_t_2469 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_2465, 3), heff_get_n(v_t_2465, 4, 9)});
    V v_t_2470 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_2468, v_t_2469, NTAG(TAG_Nothing)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2470}), v_z_242});
  }
  case TAG_Braces: {
    V v_o_2471 = heff_field(v_e0_241, 0);
    V v_fs_2472 = heff_field(v_e0_241, 1);
    V v_c_2474 = heff_field(v_e0_241, 3);
    heff_take_n(v_e0_241, 11ULL, 4);
    return (g_heff_2esyntax_2esurface_2ebracesL(v_r_240, v_o_2471, v_fs_2472, v_c_2474, v_z_242));
  }
  case TAG_Update: {
    V v_o_2475 = heff_field(v_e0_241, 0);
    V v_rec_2476 = heff_field(v_e0_241, 1);
    V v_fs_2478 = heff_field(v_e0_241, 3);
    V v_c_2480 = heff_field(v_e0_241, 5);
    heff_take_n(v_e0_241, 43ULL, 6);
    V v_m_2481 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_rec_2476}));
    V v_x1_2482 = heff_tr(heff_call(v_m_2481, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x1_2482)) {
    case TAG_MkPair: {
      V v_x11_2483 = heff_field(v_x1_2482, 0);
      V v_st_2484 = heff_field(v_x1_2482, 1);
      V v_ru_24x1_2482_24MkPair = heff_take_reuse_n(v_x1_2482, 3ULL, 2);
      switch (heff_tag_of(v_x11_2483)) {
      case TAG_Left: {
        V v_e_2485 = heff_field(v_x11_2483, 0);
        heff_take_n(v_x11_2483, 1ULL, 1);
        heff_drop_rec(v_r_240, 3);
        heff_drop_rec(v_o_2475, 9);
        heff_drop(v_fs_2478);
        heff_drop_rec(v_c_2480, 9);
        return heff_tag_at_n(v_ru_24x1_2482_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2485}), v_st_2484});
      }
      case TAG_Right: {
        V v_x_2486 = heff_field(v_x11_2483, 0);
        heff_take_n(v_x11_2483, 1ULL, 1);
        V v_m_2488 = (g_prelude_2etraverse_24s499544530x2060473942(heff_clo_n(g_heff_2esyntax_2esurface_2eexprL_lam2, 1, 1, (V[]){v_r_240}), v_fs_2478));
        V v_x1_2489 = heff_tr(heff_call(v_m_2488, 1, (V[]){v_st_2484}));
        switch (heff_tag_of(v_x1_2489)) {
        case TAG_MkPair: {
          V v_x11_2490 = heff_field(v_x1_2489, 0);
          V v_st_2491 = heff_field(v_x1_2489, 1);
          V v_ru_24x1_2489_24MkPair = heff_take_reuse_n(v_x1_2489, 3ULL, 2);
          switch (heff_tag_of(v_x11_2490)) {
          case TAG_Left: {
            V v_e_2492 = heff_field(v_x11_2490, 0);
            heff_take_n(v_x11_2490, 1ULL, 1);
            heff_drop_rec(v_o_2475, 9);
            heff_drop_rec(v_c_2480, 9);
            heff_drop(v_x_2486);
            heff_drop_cell(v_ru_24x1_2489_24MkPair, 2);
            return heff_tag_at_n(v_ru_24x1_2482_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2492}), v_st_2491});
          }
          case TAG_Right: {
            V v_x_2493 = heff_field(v_x11_2490, 0);
            heff_take_n(v_x11_2490, 1ULL, 1);
            V v_t_2494 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_o_2475, 3, 9), heff_get_n(v_c_2480, 4, 9)});
            V v_t_2495 = heff_tag_at_n(v_ru_24x1_2489_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_EUpdate, 2, (V[]){v_x_2486, v_x_2493}), v_t_2494});
            return heff_tag_at_n(v_ru_24x1_2482_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2495}), v_st_2491});
          }
          default: return heff_nomatch(v_x11_2490);
          }
        }
        default: return heff_nomatch(v_x1_2489);
        }
      }
      default: return heff_nomatch(v_x11_2483);
      }
    }
    default: return heff_nomatch(v_x1_2482);
    }
  }
  case TAG_EUSet: {
    heff_drop_rec(v_r_240, 3);
    V v_t_2499 = (g_heff_2esyntax_2ecst_2efirstE(v_e0_241));
    V v_t_24100 = ({ V a_0 = v_e0_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e0_241, 3); r_; });
    V v_t_24101 = heff_strAppend(heff_get_n(v_t_24100, 1, 9), ((V)&g_heff_2esyntax_2esurface_2eexprL_str12));
    V v_msg_24102 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eexprL_str13), v_t_24101);
    V v_t_24103 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_2499, 3), heff_get_n(v_t_2499, 4, 9)});
    V v_t_24104 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24102, v_t_24103, NTAG(TAG_Nothing)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24104}), v_z_242});
  }
  case TAG_InstB: {
    V v_o_24105 = heff_field(v_e0_241, 0);
    V v_d_24107 = heff_field(v_e0_241, 2);
    V v_c_24109 = heff_field(v_e0_241, 4);
    heff_take_n(v_e0_241, 21ULL, 5);
    V v_m_24110 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_d_24107));
    V v_x1_24111 = heff_tr(heff_call(v_m_24110, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x1_24111)) {
    case TAG_MkPair: {
      V v_x11_24112 = heff_field(v_x1_24111, 0);
      V v_st_24113 = heff_field(v_x1_24111, 1);
      V v_ru_24x1_24111_24MkPair = heff_take_reuse_n(v_x1_24111, 3ULL, 2);
      switch (heff_tag_of(v_x11_24112)) {
      case TAG_Left: {
        V v_e_24114 = heff_field(v_x11_24112, 0);
        heff_take_n(v_x11_24112, 1ULL, 1);
        heff_drop_rec(v_o_24105, 9);
        heff_drop_rec(v_c_24109, 9);
        return heff_tag_at_n(v_ru_24x1_24111_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24114}), v_st_24113});
      }
      case TAG_Right: {
        V v_ru_24x11_24112_24Right = heff_take_reuse_n(v_x11_24112, 0ULL, 1);
        V v_t_24116 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_o_24105, 3, 9), heff_get_n(v_c_24109, 4, 9)});
        V v_t_24117 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24112_24Right, TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2eexprL_str14)}), v_t_24116});
        return heff_tag_at_n(v_ru_24x1_24111_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24117}), v_st_24113});
      }
      default: return heff_nomatch(v_x11_24112);
      }
    }
    default: return heff_nomatch(v_x1_24111);
    }
  }
  case TAG_EFSet: {
    heff_drop_rec(v_r_240, 3);
    V v_t_24121 = (g_heff_2esyntax_2ecst_2efirstE(v_e0_241));
    V v_t_24122 = ({ V a_0 = v_e0_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e0_241, 3); r_; });
    V v_t_24123 = heff_strAppend(heff_get_n(v_t_24122, 1, 9), ((V)&g_heff_2esyntax_2esurface_2eexprL_str15));
    V v_msg_24124 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eexprL_str16), v_t_24123);
    V v_t_24125 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24121, 3), heff_get_n(v_t_24121, 4, 9)});
    V v_t_24126 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24124, v_t_24125, NTAG(TAG_Nothing)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24126}), v_z_242});
  }
  case TAG_EFDefault: {
    heff_drop_rec(v_r_240, 3);
    V v_t_24130 = (g_heff_2esyntax_2ecst_2efirstE(v_e0_241));
    V v_t_24131 = ({ V a_0 = v_e0_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e0_241, 3); r_; });
    V v_t_24132 = heff_strAppend(heff_get_n(v_t_24131, 1, 9), ((V)&g_heff_2esyntax_2esurface_2eexprL_str17));
    V v_msg_24133 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eexprL_str18), v_t_24132);
    V v_t_24134 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24130, 3), heff_get_n(v_t_24130, 4, 9)});
    V v_t_24135 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24133, v_t_24134, NTAG(TAG_Nothing)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24135}), v_z_242});
  }
  case TAG_Sum: {
    V v_kw_24136 = heff_field(v_e0_241, 0);
    V v_alts_24138 = heff_field(v_e0_241, 2);
    V v_c_24140 = heff_field(v_e0_241, 4);
    heff_take_n(v_e0_241, 21ULL, 5);
    V v_m_24142 = (g_prelude_2etraverse_24s499544530x2060473942(heff_clo_n(g_heff_2esyntax_2esurface_2eexprL_lam3, 1, 1, (V[]){v_r_240}), v_alts_24138));
    V v_x1_24143 = heff_tr(heff_call(v_m_24142, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x1_24143)) {
    case TAG_MkPair: {
      V v_x11_24144 = heff_field(v_x1_24143, 0);
      V v_st_24145 = heff_field(v_x1_24143, 1);
      V v_ru_24x1_24143_24MkPair = heff_take_reuse_n(v_x1_24143, 3ULL, 2);
      switch (heff_tag_of(v_x11_24144)) {
      case TAG_Left: {
        V v_e_24146 = heff_field(v_x11_24144, 0);
        heff_take_n(v_x11_24144, 1ULL, 1);
        heff_drop_rec(v_kw_24136, 9);
        heff_drop_rec(v_c_24140, 9);
        return heff_tag_at_n(v_ru_24x1_24143_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24146}), v_st_24145});
      }
      case TAG_Right: {
        V v_x_24147 = heff_field(v_x11_24144, 0);
        V v_ru_24x11_24144_24Right = heff_take_reuse_n(v_x11_24144, 1ULL, 1);
        V v_t_24148 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_24136, 3, 9), heff_get_n(v_c_24140, 4, 9)});
        V v_t_24149 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24144_24Right, TAG_ESum, 1, (V[]){v_x_24147}), v_t_24148});
        return heff_tag_at_n(v_ru_24x1_24143_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24149}), v_st_24145});
      }
      default: return heff_nomatch(v_x11_24144);
      }
    }
    default: return heff_nomatch(v_x1_24143);
    }
  }
  case TAG_ECon: {
    V v_c_24150 = heff_field(v_e0_241, 0);
    V v_args_24151 = heff_field(v_e0_241, 1);
    heff_take_n(v_e0_241, 3ULL, 2);
    V v_t_24152 = (g_heff_2esyntax_2esurface_2econL(v_r_240, v_c_24150, v_args_24151));
    return heff_tail(v_t_24152, 1, (V[]){v_z_242});
  }
  case TAG_EField: {
    V v_e_24153 = heff_field(v_e0_241, 0);
    V v_f_24154 = heff_field(v_e0_241, 1);
    V v_ru_24e0_241_24EField = heff_take_reuse_n(v_e0_241, 3ULL, 2);
    HeffT2 v_t_24155 = (g_heff_2esyntax_2esurface_2efieldsOf_24cpr(heff_tag_at_n(v_ru_24e0_241_24EField, TAG_EField, 2, (V[]){v_e_24153, v_f_24154}), NTAG(TAG_Nil)));
    {
      V v_field_24156 = v_t_24155.f[0];
      V v_field_24157 = v_t_24155.f[1];
      V v_it1_24158 = v_field_24156;
      V v_fs_24159 = v_field_24157;
      switch (heff_tag_of(v_it1_24158)) {
      case TAG_Atom: {
        V v_t_24160 = heff_field(v_it1_24158, 0);
        V v_ru_24it1_24158_24Atom = heff_take_reuse_n(v_it1_24158, 1ULL, 1);
        heff_drop_rec(v_r_240, 3);
        if (heff_strEq_c(heff_dup(heff_rfield(v_t_24160, 0)), ((V)&g_heff_2esyntax_2esurface_2eexprL_str19))) {
          heff_drop_cell(v_ru_24it1_24158_24Atom, 1);
          HEFF_LAST return g_heff_2esyntax_2esurface_2econAtom(v_t_24160, v_fs_24159, v_z_242);
        } else {
          if (heff_strEq_c(heff_dup(heff_rfield(v_t_24160, 0)), ((V)&g_heff_2esyntax_2esurface_2eexprL_str20))) {
            heff_drop_cell(v_ru_24it1_24158_24Atom, 1);
            HEFF_LAST return g_heff_2esyntax_2esurface_2ekwAtom(v_t_24160, v_fs_24159, v_z_242);
          } else {
            if (heff_strEq_c(heff_dup(heff_rfield(v_t_24160, 0)), ((V)&g_heff_2esyntax_2esurface_2eexprL_str21))) {
              heff_drop_cell(v_ru_24it1_24158_24Atom, 1);
              HEFF_LAST return g_heff_2esyntax_2esurface_2evarAtom(v_t_24160, v_fs_24159, v_z_242);
            } else {
              V v_e_24164 = (g_heff_2esyntax_2esurface_2eatomTok(v_t_24160));
              V v_t_24165 = (g_list_2emap_24s513201124x806973253(v_fs_24159));
              V v_x_24166 = (g_heff_2esyntax_2epresyntax_2eapp(v_e_24164, v_t_24165));
              return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24it1_24158_24Atom, TAG_Right, 1, (V[]){v_x_24166}), v_z_242});
            }
          }
        }
      }
      case TAG_EParen: {
        V v_m_24170 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24158}));
        V v_x1_24171 = heff_tr(heff_call(v_m_24170, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24171)) {
        case TAG_MkPair: {
          V v_x11_24172 = heff_field(v_x1_24171, 0);
          V v_st_24173 = heff_field(v_x1_24171, 1);
          V v_ru_24x1_24171_24MkPair = heff_take_reuse_n(v_x1_24171, 3ULL, 2);
          switch (heff_tag_of(v_x11_24172)) {
          case TAG_Left: {
            V v_e_24174 = heff_field(v_x11_24172, 0);
            heff_take_n(v_x11_24172, 1ULL, 1);
            heff_drop(v_fs_24159);
            return heff_tag_at_n(v_ru_24x1_24171_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24174}), v_st_24173});
          }
          case TAG_Right: {
            V v_x_24175 = heff_field(v_x11_24172, 0);
            heff_take_n(v_x11_24172, 1ULL, 1);
            V v_t_24176 = (g_list_2emap_24s513201124x806973253(v_fs_24159));
            V v_x_24177 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24175, v_t_24176));
            return heff_tag_at_n(v_ru_24x1_24171_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24177}), v_st_24173});
          }
          default: return heff_nomatch(v_x11_24172);
          }
        }
        default: return heff_nomatch(v_x1_24171);
        }
      }
      case TAG_Named: {
        V v_m_24183 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24158}));
        V v_x1_24184 = heff_tr(heff_call(v_m_24183, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24184)) {
        case TAG_MkPair: {
          V v_x11_24185 = heff_field(v_x1_24184, 0);
          V v_st_24186 = heff_field(v_x1_24184, 1);
          V v_ru_24x1_24184_24MkPair = heff_take_reuse_n(v_x1_24184, 3ULL, 2);
          switch (heff_tag_of(v_x11_24185)) {
          case TAG_Left: {
            V v_e_24187 = heff_field(v_x11_24185, 0);
            heff_take_n(v_x11_24185, 1ULL, 1);
            heff_drop(v_fs_24159);
            return heff_tag_at_n(v_ru_24x1_24184_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24187}), v_st_24186});
          }
          case TAG_Right: {
            V v_x_24188 = heff_field(v_x11_24185, 0);
            heff_take_n(v_x11_24185, 1ULL, 1);
            V v_t_24189 = (g_list_2emap_24s513201124x806973253(v_fs_24159));
            V v_x_24190 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24188, v_t_24189));
            return heff_tag_at_n(v_ru_24x1_24184_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24190}), v_st_24186});
          }
          default: return heff_nomatch(v_x11_24185);
          }
        }
        default: return heff_nomatch(v_x1_24184);
        }
      }
      case TAG_Tup: {
        V v_m_24195 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24158}));
        V v_x1_24196 = heff_tr(heff_call(v_m_24195, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24196)) {
        case TAG_MkPair: {
          V v_x11_24197 = heff_field(v_x1_24196, 0);
          V v_st_24198 = heff_field(v_x1_24196, 1);
          V v_ru_24x1_24196_24MkPair = heff_take_reuse_n(v_x1_24196, 3ULL, 2);
          switch (heff_tag_of(v_x11_24197)) {
          case TAG_Left: {
            V v_e_24199 = heff_field(v_x11_24197, 0);
            heff_take_n(v_x11_24197, 1ULL, 1);
            heff_drop(v_fs_24159);
            return heff_tag_at_n(v_ru_24x1_24196_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24199}), v_st_24198});
          }
          case TAG_Right: {
            V v_x_24200 = heff_field(v_x11_24197, 0);
            heff_take_n(v_x11_24197, 1ULL, 1);
            V v_t_24201 = (g_list_2emap_24s513201124x806973253(v_fs_24159));
            V v_x_24202 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24200, v_t_24201));
            return heff_tag_at_n(v_ru_24x1_24196_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24202}), v_st_24198});
          }
          default: return heff_nomatch(v_x11_24197);
          }
        }
        default: return heff_nomatch(v_x1_24196);
        }
      }
      case TAG_Seg: {
        V v_m_24206 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24158}));
        V v_x1_24207 = heff_tr(heff_call(v_m_24206, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24207)) {
        case TAG_MkPair: {
          V v_x11_24208 = heff_field(v_x1_24207, 0);
          V v_st_24209 = heff_field(v_x1_24207, 1);
          V v_ru_24x1_24207_24MkPair = heff_take_reuse_n(v_x1_24207, 3ULL, 2);
          switch (heff_tag_of(v_x11_24208)) {
          case TAG_Left: {
            V v_e_24210 = heff_field(v_x11_24208, 0);
            heff_take_n(v_x11_24208, 1ULL, 1);
            heff_drop(v_fs_24159);
            return heff_tag_at_n(v_ru_24x1_24207_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24210}), v_st_24209});
          }
          case TAG_Right: {
            V v_x_24211 = heff_field(v_x11_24208, 0);
            heff_take_n(v_x11_24208, 1ULL, 1);
            V v_t_24212 = (g_list_2emap_24s513201124x806973253(v_fs_24159));
            V v_x_24213 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24211, v_t_24212));
            return heff_tag_at_n(v_ru_24x1_24207_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24213}), v_st_24209});
          }
          default: return heff_nomatch(v_x11_24208);
          }
        }
        default: return heff_nomatch(v_x1_24207);
        }
      }
      case TAG_Braces: {
        V v_m_24218 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24158}));
        V v_x1_24219 = heff_tr(heff_call(v_m_24218, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24219)) {
        case TAG_MkPair: {
          V v_x11_24220 = heff_field(v_x1_24219, 0);
          V v_st_24221 = heff_field(v_x1_24219, 1);
          V v_ru_24x1_24219_24MkPair = heff_take_reuse_n(v_x1_24219, 3ULL, 2);
          switch (heff_tag_of(v_x11_24220)) {
          case TAG_Left: {
            V v_e_24222 = heff_field(v_x11_24220, 0);
            heff_take_n(v_x11_24220, 1ULL, 1);
            heff_drop(v_fs_24159);
            return heff_tag_at_n(v_ru_24x1_24219_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24222}), v_st_24221});
          }
          case TAG_Right: {
            V v_x_24223 = heff_field(v_x11_24220, 0);
            heff_take_n(v_x11_24220, 1ULL, 1);
            V v_t_24224 = (g_list_2emap_24s513201124x806973253(v_fs_24159));
            V v_x_24225 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24223, v_t_24224));
            return heff_tag_at_n(v_ru_24x1_24219_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24225}), v_st_24221});
          }
          default: return heff_nomatch(v_x11_24220);
          }
        }
        default: return heff_nomatch(v_x1_24219);
        }
      }
      case TAG_Update: {
        V v_m_24232 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24158}));
        V v_x1_24233 = heff_tr(heff_call(v_m_24232, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24233)) {
        case TAG_MkPair: {
          V v_x11_24234 = heff_field(v_x1_24233, 0);
          V v_st_24235 = heff_field(v_x1_24233, 1);
          V v_ru_24x1_24233_24MkPair = heff_take_reuse_n(v_x1_24233, 3ULL, 2);
          switch (heff_tag_of(v_x11_24234)) {
          case TAG_Left: {
            V v_e_24236 = heff_field(v_x11_24234, 0);
            heff_take_n(v_x11_24234, 1ULL, 1);
            heff_drop(v_fs_24159);
            return heff_tag_at_n(v_ru_24x1_24233_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24236}), v_st_24235});
          }
          case TAG_Right: {
            V v_x_24237 = heff_field(v_x11_24234, 0);
            heff_take_n(v_x11_24234, 1ULL, 1);
            V v_t_24238 = (g_list_2emap_24s513201124x806973253(v_fs_24159));
            V v_x_24239 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24237, v_t_24238));
            return heff_tag_at_n(v_ru_24x1_24233_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24239}), v_st_24235});
          }
          default: return heff_nomatch(v_x11_24234);
          }
        }
        default: return heff_nomatch(v_x1_24233);
        }
      }
      case TAG_EUSet: {
        V v_m_24243 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24158}));
        V v_x1_24244 = heff_tr(heff_call(v_m_24243, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24244)) {
        case TAG_MkPair: {
          V v_x11_24245 = heff_field(v_x1_24244, 0);
          V v_st_24246 = heff_field(v_x1_24244, 1);
          V v_ru_24x1_24244_24MkPair = heff_take_reuse_n(v_x1_24244, 3ULL, 2);
          switch (heff_tag_of(v_x11_24245)) {
          case TAG_Left: {
            V v_e_24247 = heff_field(v_x11_24245, 0);
            heff_take_n(v_x11_24245, 1ULL, 1);
            heff_drop(v_fs_24159);
            return heff_tag_at_n(v_ru_24x1_24244_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24247}), v_st_24246});
          }
          case TAG_Right: {
            V v_x_24248 = heff_field(v_x11_24245, 0);
            heff_take_n(v_x11_24245, 1ULL, 1);
            V v_t_24249 = (g_list_2emap_24s513201124x806973253(v_fs_24159));
            V v_x_24250 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24248, v_t_24249));
            return heff_tag_at_n(v_ru_24x1_24244_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24250}), v_st_24246});
          }
          default: return heff_nomatch(v_x11_24245);
          }
        }
        default: return heff_nomatch(v_x1_24244);
        }
      }
      case TAG_InstB: {
        V v_m_24256 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24158}));
        V v_x1_24257 = heff_tr(heff_call(v_m_24256, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24257)) {
        case TAG_MkPair: {
          V v_x11_24258 = heff_field(v_x1_24257, 0);
          V v_st_24259 = heff_field(v_x1_24257, 1);
          V v_ru_24x1_24257_24MkPair = heff_take_reuse_n(v_x1_24257, 3ULL, 2);
          switch (heff_tag_of(v_x11_24258)) {
          case TAG_Left: {
            V v_e_24260 = heff_field(v_x11_24258, 0);
            heff_take_n(v_x11_24258, 1ULL, 1);
            heff_drop(v_fs_24159);
            return heff_tag_at_n(v_ru_24x1_24257_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24260}), v_st_24259});
          }
          case TAG_Right: {
            V v_x_24261 = heff_field(v_x11_24258, 0);
            heff_take_n(v_x11_24258, 1ULL, 1);
            V v_t_24262 = (g_list_2emap_24s513201124x806973253(v_fs_24159));
            V v_x_24263 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24261, v_t_24262));
            return heff_tag_at_n(v_ru_24x1_24257_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24263}), v_st_24259});
          }
          default: return heff_nomatch(v_x11_24258);
          }
        }
        default: return heff_nomatch(v_x1_24257);
        }
      }
      case TAG_EFSet: {
        V v_m_24267 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24158}));
        V v_x1_24268 = heff_tr(heff_call(v_m_24267, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24268)) {
        case TAG_MkPair: {
          V v_x11_24269 = heff_field(v_x1_24268, 0);
          V v_st_24270 = heff_field(v_x1_24268, 1);
          V v_ru_24x1_24268_24MkPair = heff_take_reuse_n(v_x1_24268, 3ULL, 2);
          switch (heff_tag_of(v_x11_24269)) {
          case TAG_Left: {
            V v_e_24271 = heff_field(v_x11_24269, 0);
            heff_take_n(v_x11_24269, 1ULL, 1);
            heff_drop(v_fs_24159);
            return heff_tag_at_n(v_ru_24x1_24268_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24271}), v_st_24270});
          }
          case TAG_Right: {
            V v_x_24272 = heff_field(v_x11_24269, 0);
            heff_take_n(v_x11_24269, 1ULL, 1);
            V v_t_24273 = (g_list_2emap_24s513201124x806973253(v_fs_24159));
            V v_x_24274 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24272, v_t_24273));
            return heff_tag_at_n(v_ru_24x1_24268_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24274}), v_st_24270});
          }
          default: return heff_nomatch(v_x11_24269);
          }
        }
        default: return heff_nomatch(v_x1_24268);
        }
      }
      case TAG_EFDefault: {
        V v_m_24278 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24158}));
        V v_x1_24279 = heff_tr(heff_call(v_m_24278, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24279)) {
        case TAG_MkPair: {
          V v_x11_24280 = heff_field(v_x1_24279, 0);
          V v_st_24281 = heff_field(v_x1_24279, 1);
          V v_ru_24x1_24279_24MkPair = heff_take_reuse_n(v_x1_24279, 3ULL, 2);
          switch (heff_tag_of(v_x11_24280)) {
          case TAG_Left: {
            V v_e_24282 = heff_field(v_x11_24280, 0);
            heff_take_n(v_x11_24280, 1ULL, 1);
            heff_drop(v_fs_24159);
            return heff_tag_at_n(v_ru_24x1_24279_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24282}), v_st_24281});
          }
          case TAG_Right: {
            V v_x_24283 = heff_field(v_x11_24280, 0);
            heff_take_n(v_x11_24280, 1ULL, 1);
            V v_t_24284 = (g_list_2emap_24s513201124x806973253(v_fs_24159));
            V v_x_24285 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24283, v_t_24284));
            return heff_tag_at_n(v_ru_24x1_24279_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24285}), v_st_24281});
          }
          default: return heff_nomatch(v_x11_24280);
          }
        }
        default: return heff_nomatch(v_x1_24279);
        }
      }
      case TAG_Sum: {
        V v_m_24291 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24158}));
        V v_x1_24292 = heff_tr(heff_call(v_m_24291, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24292)) {
        case TAG_MkPair: {
          V v_x11_24293 = heff_field(v_x1_24292, 0);
          V v_st_24294 = heff_field(v_x1_24292, 1);
          V v_ru_24x1_24292_24MkPair = heff_take_reuse_n(v_x1_24292, 3ULL, 2);
          switch (heff_tag_of(v_x11_24293)) {
          case TAG_Left: {
            V v_e_24295 = heff_field(v_x11_24293, 0);
            heff_take_n(v_x11_24293, 1ULL, 1);
            heff_drop(v_fs_24159);
            return heff_tag_at_n(v_ru_24x1_24292_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24295}), v_st_24294});
          }
          case TAG_Right: {
            V v_x_24296 = heff_field(v_x11_24293, 0);
            heff_take_n(v_x11_24293, 1ULL, 1);
            V v_t_24297 = (g_list_2emap_24s513201124x806973253(v_fs_24159));
            V v_x_24298 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24296, v_t_24297));
            return heff_tag_at_n(v_ru_24x1_24292_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24298}), v_st_24294});
          }
          default: return heff_nomatch(v_x11_24293);
          }
        }
        default: return heff_nomatch(v_x1_24292);
        }
      }
      case TAG_ECon: {
        V v_m_24301 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24158}));
        V v_x1_24302 = heff_tr(heff_call(v_m_24301, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24302)) {
        case TAG_MkPair: {
          V v_x11_24303 = heff_field(v_x1_24302, 0);
          V v_st_24304 = heff_field(v_x1_24302, 1);
          V v_ru_24x1_24302_24MkPair = heff_take_reuse_n(v_x1_24302, 3ULL, 2);
          switch (heff_tag_of(v_x11_24303)) {
          case TAG_Left: {
            V v_e_24305 = heff_field(v_x11_24303, 0);
            heff_take_n(v_x11_24303, 1ULL, 1);
            heff_drop(v_fs_24159);
            return heff_tag_at_n(v_ru_24x1_24302_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24305}), v_st_24304});
          }
          case TAG_Right: {
            V v_x_24306 = heff_field(v_x11_24303, 0);
            heff_take_n(v_x11_24303, 1ULL, 1);
            V v_t_24307 = (g_list_2emap_24s513201124x806973253(v_fs_24159));
            V v_x_24308 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24306, v_t_24307));
            return heff_tag_at_n(v_ru_24x1_24302_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24308}), v_st_24304});
          }
          default: return heff_nomatch(v_x11_24303);
          }
        }
        default: return heff_nomatch(v_x1_24302);
        }
      }
      case TAG_EField: {
        V v_m_24311 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24158}));
        V v_x1_24312 = heff_tr(heff_call(v_m_24311, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24312)) {
        case TAG_MkPair: {
          V v_x11_24313 = heff_field(v_x1_24312, 0);
          V v_st_24314 = heff_field(v_x1_24312, 1);
          V v_ru_24x1_24312_24MkPair = heff_take_reuse_n(v_x1_24312, 3ULL, 2);
          switch (heff_tag_of(v_x11_24313)) {
          case TAG_Left: {
            V v_e_24315 = heff_field(v_x11_24313, 0);
            heff_take_n(v_x11_24313, 1ULL, 1);
            heff_drop(v_fs_24159);
            return heff_tag_at_n(v_ru_24x1_24312_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24315}), v_st_24314});
          }
          case TAG_Right: {
            V v_x_24316 = heff_field(v_x11_24313, 0);
            heff_take_n(v_x11_24313, 1ULL, 1);
            V v_t_24317 = (g_list_2emap_24s513201124x806973253(v_fs_24159));
            V v_x_24318 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24316, v_t_24317));
            return heff_tag_at_n(v_ru_24x1_24312_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24318}), v_st_24314});
          }
          default: return heff_nomatch(v_x11_24313);
          }
        }
        default: return heff_nomatch(v_x1_24312);
        }
      }
      case TAG_ENeg: {
        V v_m_24321 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24158}));
        V v_x1_24322 = heff_tr(heff_call(v_m_24321, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24322)) {
        case TAG_MkPair: {
          V v_x11_24323 = heff_field(v_x1_24322, 0);
          V v_st_24324 = heff_field(v_x1_24322, 1);
          V v_ru_24x1_24322_24MkPair = heff_take_reuse_n(v_x1_24322, 3ULL, 2);
          switch (heff_tag_of(v_x11_24323)) {
          case TAG_Left: {
            V v_e_24325 = heff_field(v_x11_24323, 0);
            heff_take_n(v_x11_24323, 1ULL, 1);
            heff_drop(v_fs_24159);
            return heff_tag_at_n(v_ru_24x1_24322_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24325}), v_st_24324});
          }
          case TAG_Right: {
            V v_x_24326 = heff_field(v_x11_24323, 0);
            heff_take_n(v_x11_24323, 1ULL, 1);
            V v_t_24327 = (g_list_2emap_24s513201124x806973253(v_fs_24159));
            V v_x_24328 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24326, v_t_24327));
            return heff_tag_at_n(v_ru_24x1_24322_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24328}), v_st_24324});
          }
          default: return heff_nomatch(v_x11_24323);
          }
        }
        default: return heff_nomatch(v_x1_24322);
        }
      }
      case TAG_App: {
        V v_m_24331 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24158}));
        V v_x1_24332 = heff_tr(heff_call(v_m_24331, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24332)) {
        case TAG_MkPair: {
          V v_x11_24333 = heff_field(v_x1_24332, 0);
          V v_st_24334 = heff_field(v_x1_24332, 1);
          V v_ru_24x1_24332_24MkPair = heff_take_reuse_n(v_x1_24332, 3ULL, 2);
          switch (heff_tag_of(v_x11_24333)) {
          case TAG_Left: {
            V v_e_24335 = heff_field(v_x11_24333, 0);
            heff_take_n(v_x11_24333, 1ULL, 1);
            heff_drop(v_fs_24159);
            return heff_tag_at_n(v_ru_24x1_24332_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24335}), v_st_24334});
          }
          case TAG_Right: {
            V v_x_24336 = heff_field(v_x11_24333, 0);
            heff_take_n(v_x11_24333, 1ULL, 1);
            V v_t_24337 = (g_list_2emap_24s513201124x806973253(v_fs_24159));
            V v_x_24338 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24336, v_t_24337));
            return heff_tag_at_n(v_ru_24x1_24332_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24338}), v_st_24334});
          }
          default: return heff_nomatch(v_x11_24333);
          }
        }
        default: return heff_nomatch(v_x1_24332);
        }
      }
      case TAG_Op: {
        V v_m_24342 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24158}));
        V v_x1_24343 = heff_tr(heff_call(v_m_24342, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24343)) {
        case TAG_MkPair: {
          V v_x11_24344 = heff_field(v_x1_24343, 0);
          V v_st_24345 = heff_field(v_x1_24343, 1);
          V v_ru_24x1_24343_24MkPair = heff_take_reuse_n(v_x1_24343, 3ULL, 2);
          switch (heff_tag_of(v_x11_24344)) {
          case TAG_Left: {
            V v_e_24346 = heff_field(v_x11_24344, 0);
            heff_take_n(v_x11_24344, 1ULL, 1);
            heff_drop(v_fs_24159);
            return heff_tag_at_n(v_ru_24x1_24343_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24346}), v_st_24345});
          }
          case TAG_Right: {
            V v_x_24347 = heff_field(v_x11_24344, 0);
            heff_take_n(v_x11_24344, 1ULL, 1);
            V v_t_24348 = (g_list_2emap_24s513201124x806973253(v_fs_24159));
            V v_x_24349 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24347, v_t_24348));
            return heff_tag_at_n(v_ru_24x1_24343_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24349}), v_st_24345});
          }
          default: return heff_nomatch(v_x11_24344);
          }
        }
        default: return heff_nomatch(v_x1_24343);
        }
      }
      case TAG_Ops: {
        V v_m_24352 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24158}));
        V v_x1_24353 = heff_tr(heff_call(v_m_24352, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24353)) {
        case TAG_MkPair: {
          V v_x11_24354 = heff_field(v_x1_24353, 0);
          V v_st_24355 = heff_field(v_x1_24353, 1);
          V v_ru_24x1_24353_24MkPair = heff_take_reuse_n(v_x1_24353, 3ULL, 2);
          switch (heff_tag_of(v_x11_24354)) {
          case TAG_Left: {
            V v_e_24356 = heff_field(v_x11_24354, 0);
            heff_take_n(v_x11_24354, 1ULL, 1);
            heff_drop(v_fs_24159);
            return heff_tag_at_n(v_ru_24x1_24353_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24356}), v_st_24355});
          }
          case TAG_Right: {
            V v_x_24357 = heff_field(v_x11_24354, 0);
            heff_take_n(v_x11_24354, 1ULL, 1);
            V v_t_24358 = (g_list_2emap_24s513201124x806973253(v_fs_24159));
            V v_x_24359 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24357, v_t_24358));
            return heff_tag_at_n(v_ru_24x1_24353_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24359}), v_st_24355});
          }
          default: return heff_nomatch(v_x11_24354);
          }
        }
        default: return heff_nomatch(v_x1_24353);
        }
      }
      case TAG_OpRhs: {
        V v_m_24362 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24158}));
        V v_x1_24363 = heff_tr(heff_call(v_m_24362, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24363)) {
        case TAG_MkPair: {
          V v_x11_24364 = heff_field(v_x1_24363, 0);
          V v_st_24365 = heff_field(v_x1_24363, 1);
          V v_ru_24x1_24363_24MkPair = heff_take_reuse_n(v_x1_24363, 3ULL, 2);
          switch (heff_tag_of(v_x11_24364)) {
          case TAG_Left: {
            V v_e_24366 = heff_field(v_x11_24364, 0);
            heff_take_n(v_x11_24364, 1ULL, 1);
            heff_drop(v_fs_24159);
            return heff_tag_at_n(v_ru_24x1_24363_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24366}), v_st_24365});
          }
          case TAG_Right: {
            V v_x_24367 = heff_field(v_x11_24364, 0);
            heff_take_n(v_x11_24364, 1ULL, 1);
            V v_t_24368 = (g_list_2emap_24s513201124x806973253(v_fs_24159));
            V v_x_24369 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24367, v_t_24368));
            return heff_tag_at_n(v_ru_24x1_24363_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24369}), v_st_24365});
          }
          default: return heff_nomatch(v_x11_24364);
          }
        }
        default: return heff_nomatch(v_x1_24363);
        }
      }
      case TAG_Ann: {
        V v_m_24373 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24158}));
        V v_x1_24374 = heff_tr(heff_call(v_m_24373, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24374)) {
        case TAG_MkPair: {
          V v_x11_24375 = heff_field(v_x1_24374, 0);
          V v_st_24376 = heff_field(v_x1_24374, 1);
          V v_ru_24x1_24374_24MkPair = heff_take_reuse_n(v_x1_24374, 3ULL, 2);
          switch (heff_tag_of(v_x11_24375)) {
          case TAG_Left: {
            V v_e_24377 = heff_field(v_x11_24375, 0);
            heff_take_n(v_x11_24375, 1ULL, 1);
            heff_drop(v_fs_24159);
            return heff_tag_at_n(v_ru_24x1_24374_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24377}), v_st_24376});
          }
          case TAG_Right: {
            V v_x_24378 = heff_field(v_x11_24375, 0);
            heff_take_n(v_x11_24375, 1ULL, 1);
            V v_t_24379 = (g_list_2emap_24s513201124x806973253(v_fs_24159));
            V v_x_24380 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24378, v_t_24379));
            return heff_tag_at_n(v_ru_24x1_24374_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24380}), v_st_24376});
          }
          default: return heff_nomatch(v_x11_24375);
          }
        }
        default: return heff_nomatch(v_x1_24374);
        }
      }
      case TAG_BVar: {
        V v_m_24382 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24158}));
        V v_x1_24383 = heff_tr(heff_call(v_m_24382, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24383)) {
        case TAG_MkPair: {
          V v_x11_24384 = heff_field(v_x1_24383, 0);
          V v_st_24385 = heff_field(v_x1_24383, 1);
          V v_ru_24x1_24383_24MkPair = heff_take_reuse_n(v_x1_24383, 3ULL, 2);
          switch (heff_tag_of(v_x11_24384)) {
          case TAG_Left: {
            V v_e_24386 = heff_field(v_x11_24384, 0);
            heff_take_n(v_x11_24384, 1ULL, 1);
            heff_drop(v_fs_24159);
            return heff_tag_at_n(v_ru_24x1_24383_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24386}), v_st_24385});
          }
          case TAG_Right: {
            V v_x_24387 = heff_field(v_x11_24384, 0);
            heff_take_n(v_x11_24384, 1ULL, 1);
            V v_t_24388 = (g_list_2emap_24s513201124x806973253(v_fs_24159));
            V v_x_24389 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24387, v_t_24388));
            return heff_tag_at_n(v_ru_24x1_24383_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24389}), v_st_24385});
          }
          default: return heff_nomatch(v_x11_24384);
          }
        }
        default: return heff_nomatch(v_x1_24383);
        }
      }
      case TAG_BImp: {
        V v_m_24393 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24158}));
        V v_x1_24394 = heff_tr(heff_call(v_m_24393, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24394)) {
        case TAG_MkPair: {
          V v_x11_24395 = heff_field(v_x1_24394, 0);
          V v_st_24396 = heff_field(v_x1_24394, 1);
          V v_ru_24x1_24394_24MkPair = heff_take_reuse_n(v_x1_24394, 3ULL, 2);
          switch (heff_tag_of(v_x11_24395)) {
          case TAG_Left: {
            V v_e_24397 = heff_field(v_x11_24395, 0);
            heff_take_n(v_x11_24395, 1ULL, 1);
            heff_drop(v_fs_24159);
            return heff_tag_at_n(v_ru_24x1_24394_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24397}), v_st_24396});
          }
          case TAG_Right: {
            V v_x_24398 = heff_field(v_x11_24395, 0);
            heff_take_n(v_x11_24395, 1ULL, 1);
            V v_t_24399 = (g_list_2emap_24s513201124x806973253(v_fs_24159));
            V v_x_24400 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24398, v_t_24399));
            return heff_tag_at_n(v_ru_24x1_24394_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24400}), v_st_24396});
          }
          default: return heff_nomatch(v_x11_24395);
          }
        }
        default: return heff_nomatch(v_x1_24394);
        }
      }
      case TAG_BAnn: {
        V v_m_24406 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24158}));
        V v_x1_24407 = heff_tr(heff_call(v_m_24406, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24407)) {
        case TAG_MkPair: {
          V v_x11_24408 = heff_field(v_x1_24407, 0);
          V v_st_24409 = heff_field(v_x1_24407, 1);
          V v_ru_24x1_24407_24MkPair = heff_take_reuse_n(v_x1_24407, 3ULL, 2);
          switch (heff_tag_of(v_x11_24408)) {
          case TAG_Left: {
            V v_e_24410 = heff_field(v_x11_24408, 0);
            heff_take_n(v_x11_24408, 1ULL, 1);
            heff_drop(v_fs_24159);
            return heff_tag_at_n(v_ru_24x1_24407_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24410}), v_st_24409});
          }
          case TAG_Right: {
            V v_x_24411 = heff_field(v_x11_24408, 0);
            heff_take_n(v_x11_24408, 1ULL, 1);
            V v_t_24412 = (g_list_2emap_24s513201124x806973253(v_fs_24159));
            V v_x_24413 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24411, v_t_24412));
            return heff_tag_at_n(v_ru_24x1_24407_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24413}), v_st_24409});
          }
          default: return heff_nomatch(v_x11_24408);
          }
        }
        default: return heff_nomatch(v_x1_24407);
        }
      }
      case TAG_Lam: {
        V v_m_24418 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24158}));
        V v_x1_24419 = heff_tr(heff_call(v_m_24418, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24419)) {
        case TAG_MkPair: {
          V v_x11_24420 = heff_field(v_x1_24419, 0);
          V v_st_24421 = heff_field(v_x1_24419, 1);
          V v_ru_24x1_24419_24MkPair = heff_take_reuse_n(v_x1_24419, 3ULL, 2);
          switch (heff_tag_of(v_x11_24420)) {
          case TAG_Left: {
            V v_e_24422 = heff_field(v_x11_24420, 0);
            heff_take_n(v_x11_24420, 1ULL, 1);
            heff_drop(v_fs_24159);
            return heff_tag_at_n(v_ru_24x1_24419_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24422}), v_st_24421});
          }
          case TAG_Right: {
            V v_x_24423 = heff_field(v_x11_24420, 0);
            heff_take_n(v_x11_24420, 1ULL, 1);
            V v_t_24424 = (g_list_2emap_24s513201124x806973253(v_fs_24159));
            V v_x_24425 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24423, v_t_24424));
            return heff_tag_at_n(v_ru_24x1_24419_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24425}), v_st_24421});
          }
          default: return heff_nomatch(v_x11_24420);
          }
        }
        default: return heff_nomatch(v_x1_24419);
        }
      }
      case TAG_Case: {
        V v_m_24430 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24158}));
        V v_x1_24431 = heff_tr(heff_call(v_m_24430, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24431)) {
        case TAG_MkPair: {
          V v_x11_24432 = heff_field(v_x1_24431, 0);
          V v_st_24433 = heff_field(v_x1_24431, 1);
          V v_ru_24x1_24431_24MkPair = heff_take_reuse_n(v_x1_24431, 3ULL, 2);
          switch (heff_tag_of(v_x11_24432)) {
          case TAG_Left: {
            V v_e_24434 = heff_field(v_x11_24432, 0);
            heff_take_n(v_x11_24432, 1ULL, 1);
            heff_drop(v_fs_24159);
            return heff_tag_at_n(v_ru_24x1_24431_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24434}), v_st_24433});
          }
          case TAG_Right: {
            V v_x_24435 = heff_field(v_x11_24432, 0);
            heff_take_n(v_x11_24432, 1ULL, 1);
            V v_t_24436 = (g_list_2emap_24s513201124x806973253(v_fs_24159));
            V v_x_24437 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24435, v_t_24436));
            return heff_tag_at_n(v_ru_24x1_24431_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24437}), v_st_24433});
          }
          default: return heff_nomatch(v_x11_24432);
          }
        }
        default: return heff_nomatch(v_x1_24431);
        }
      }
      case TAG_EAlt: {
        V v_m_24441 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24158}));
        V v_x1_24442 = heff_tr(heff_call(v_m_24441, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24442)) {
        case TAG_MkPair: {
          V v_x11_24443 = heff_field(v_x1_24442, 0);
          V v_st_24444 = heff_field(v_x1_24442, 1);
          V v_ru_24x1_24442_24MkPair = heff_take_reuse_n(v_x1_24442, 3ULL, 2);
          switch (heff_tag_of(v_x11_24443)) {
          case TAG_Left: {
            V v_e_24445 = heff_field(v_x11_24443, 0);
            heff_take_n(v_x11_24443, 1ULL, 1);
            heff_drop(v_fs_24159);
            return heff_tag_at_n(v_ru_24x1_24442_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24445}), v_st_24444});
          }
          case TAG_Right: {
            V v_x_24446 = heff_field(v_x11_24443, 0);
            heff_take_n(v_x11_24443, 1ULL, 1);
            V v_t_24447 = (g_list_2emap_24s513201124x806973253(v_fs_24159));
            V v_x_24448 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24446, v_t_24447));
            return heff_tag_at_n(v_ru_24x1_24442_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24448}), v_st_24444});
          }
          default: return heff_nomatch(v_x11_24443);
          }
        }
        default: return heff_nomatch(v_x1_24442);
        }
      }
      case TAG_If: {
        V v_m_24455 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24158}));
        V v_x1_24456 = heff_tr(heff_call(v_m_24455, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24456)) {
        case TAG_MkPair: {
          V v_x11_24457 = heff_field(v_x1_24456, 0);
          V v_st_24458 = heff_field(v_x1_24456, 1);
          V v_ru_24x1_24456_24MkPair = heff_take_reuse_n(v_x1_24456, 3ULL, 2);
          switch (heff_tag_of(v_x11_24457)) {
          case TAG_Left: {
            V v_e_24459 = heff_field(v_x11_24457, 0);
            heff_take_n(v_x11_24457, 1ULL, 1);
            heff_drop(v_fs_24159);
            return heff_tag_at_n(v_ru_24x1_24456_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24459}), v_st_24458});
          }
          case TAG_Right: {
            V v_x_24460 = heff_field(v_x11_24457, 0);
            heff_take_n(v_x11_24457, 1ULL, 1);
            V v_t_24461 = (g_list_2emap_24s513201124x806973253(v_fs_24159));
            V v_x_24462 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24460, v_t_24461));
            return heff_tag_at_n(v_ru_24x1_24456_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24462}), v_st_24458});
          }
          default: return heff_nomatch(v_x11_24457);
          }
        }
        default: return heff_nomatch(v_x1_24456);
        }
      }
      case TAG_Do: {
        V v_m_24465 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24158}));
        V v_x1_24466 = heff_tr(heff_call(v_m_24465, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24466)) {
        case TAG_MkPair: {
          V v_x11_24467 = heff_field(v_x1_24466, 0);
          V v_st_24468 = heff_field(v_x1_24466, 1);
          V v_ru_24x1_24466_24MkPair = heff_take_reuse_n(v_x1_24466, 3ULL, 2);
          switch (heff_tag_of(v_x11_24467)) {
          case TAG_Left: {
            V v_e_24469 = heff_field(v_x11_24467, 0);
            heff_take_n(v_x11_24467, 1ULL, 1);
            heff_drop(v_fs_24159);
            return heff_tag_at_n(v_ru_24x1_24466_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24469}), v_st_24468});
          }
          case TAG_Right: {
            V v_x_24470 = heff_field(v_x11_24467, 0);
            heff_take_n(v_x11_24467, 1ULL, 1);
            V v_t_24471 = (g_list_2emap_24s513201124x806973253(v_fs_24159));
            V v_x_24472 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24470, v_t_24471));
            return heff_tag_at_n(v_ru_24x1_24466_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24472}), v_st_24468});
          }
          default: return heff_nomatch(v_x11_24467);
          }
        }
        default: return heff_nomatch(v_x1_24466);
        }
      }
      case TAG_ESBind: {
        V v_m_24476 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24158}));
        V v_x1_24477 = heff_tr(heff_call(v_m_24476, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24477)) {
        case TAG_MkPair: {
          V v_x11_24478 = heff_field(v_x1_24477, 0);
          V v_st_24479 = heff_field(v_x1_24477, 1);
          V v_ru_24x1_24477_24MkPair = heff_take_reuse_n(v_x1_24477, 3ULL, 2);
          switch (heff_tag_of(v_x11_24478)) {
          case TAG_Left: {
            V v_e_24480 = heff_field(v_x11_24478, 0);
            heff_take_n(v_x11_24478, 1ULL, 1);
            heff_drop(v_fs_24159);
            return heff_tag_at_n(v_ru_24x1_24477_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24480}), v_st_24479});
          }
          case TAG_Right: {
            V v_x_24481 = heff_field(v_x11_24478, 0);
            heff_take_n(v_x11_24478, 1ULL, 1);
            V v_t_24482 = (g_list_2emap_24s513201124x806973253(v_fs_24159));
            V v_x_24483 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24481, v_t_24482));
            return heff_tag_at_n(v_ru_24x1_24477_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24483}), v_st_24479});
          }
          default: return heff_nomatch(v_x11_24478);
          }
        }
        default: return heff_nomatch(v_x1_24477);
        }
      }
      case TAG_ELet: {
        V v_m_24490 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24158}));
        V v_x1_24491 = heff_tr(heff_call(v_m_24490, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24491)) {
        case TAG_MkPair: {
          V v_x11_24492 = heff_field(v_x1_24491, 0);
          V v_st_24493 = heff_field(v_x1_24491, 1);
          V v_ru_24x1_24491_24MkPair = heff_take_reuse_n(v_x1_24491, 3ULL, 2);
          switch (heff_tag_of(v_x11_24492)) {
          case TAG_Left: {
            V v_e_24494 = heff_field(v_x11_24492, 0);
            heff_take_n(v_x11_24492, 1ULL, 1);
            heff_drop(v_fs_24159);
            return heff_tag_at_n(v_ru_24x1_24491_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24494}), v_st_24493});
          }
          case TAG_Right: {
            V v_x_24495 = heff_field(v_x11_24492, 0);
            heff_take_n(v_x11_24492, 1ULL, 1);
            V v_t_24496 = (g_list_2emap_24s513201124x806973253(v_fs_24159));
            V v_x_24497 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24495, v_t_24496));
            return heff_tag_at_n(v_ru_24x1_24491_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24497}), v_st_24493});
          }
          default: return heff_nomatch(v_x11_24492);
          }
        }
        default: return heff_nomatch(v_x1_24491);
        }
      }
      case TAG_ELetMut: {
        V v_m_24504 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24158}));
        V v_x1_24505 = heff_tr(heff_call(v_m_24504, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24505)) {
        case TAG_MkPair: {
          V v_x11_24506 = heff_field(v_x1_24505, 0);
          V v_st_24507 = heff_field(v_x1_24505, 1);
          V v_ru_24x1_24505_24MkPair = heff_take_reuse_n(v_x1_24505, 3ULL, 2);
          switch (heff_tag_of(v_x11_24506)) {
          case TAG_Left: {
            V v_e_24508 = heff_field(v_x11_24506, 0);
            heff_take_n(v_x11_24506, 1ULL, 1);
            heff_drop(v_fs_24159);
            return heff_tag_at_n(v_ru_24x1_24505_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24508}), v_st_24507});
          }
          case TAG_Right: {
            V v_x_24509 = heff_field(v_x11_24506, 0);
            heff_take_n(v_x11_24506, 1ULL, 1);
            V v_t_24510 = (g_list_2emap_24s513201124x806973253(v_fs_24159));
            V v_x_24511 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24509, v_t_24510));
            return heff_tag_at_n(v_ru_24x1_24505_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24511}), v_st_24507});
          }
          default: return heff_nomatch(v_x11_24506);
          }
        }
        default: return heff_nomatch(v_x1_24505);
        }
      }
      case TAG_EAssign: {
        V v_m_24515 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24158}));
        V v_x1_24516 = heff_tr(heff_call(v_m_24515, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24516)) {
        case TAG_MkPair: {
          V v_x11_24517 = heff_field(v_x1_24516, 0);
          V v_st_24518 = heff_field(v_x1_24516, 1);
          V v_ru_24x1_24516_24MkPair = heff_take_reuse_n(v_x1_24516, 3ULL, 2);
          switch (heff_tag_of(v_x11_24517)) {
          case TAG_Left: {
            V v_e_24519 = heff_field(v_x11_24517, 0);
            heff_take_n(v_x11_24517, 1ULL, 1);
            heff_drop(v_fs_24159);
            return heff_tag_at_n(v_ru_24x1_24516_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24519}), v_st_24518});
          }
          case TAG_Right: {
            V v_x_24520 = heff_field(v_x11_24517, 0);
            heff_take_n(v_x11_24517, 1ULL, 1);
            V v_t_24521 = (g_list_2emap_24s513201124x806973253(v_fs_24159));
            V v_x_24522 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24520, v_t_24521));
            return heff_tag_at_n(v_ru_24x1_24516_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24522}), v_st_24518});
          }
          default: return heff_nomatch(v_x11_24517);
          }
        }
        default: return heff_nomatch(v_x1_24516);
        }
      }
      case TAG_EWhile: {
        V v_m_24527 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24158}));
        V v_x1_24528 = heff_tr(heff_call(v_m_24527, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24528)) {
        case TAG_MkPair: {
          V v_x11_24529 = heff_field(v_x1_24528, 0);
          V v_st_24530 = heff_field(v_x1_24528, 1);
          V v_ru_24x1_24528_24MkPair = heff_take_reuse_n(v_x1_24528, 3ULL, 2);
          switch (heff_tag_of(v_x11_24529)) {
          case TAG_Left: {
            V v_e_24531 = heff_field(v_x11_24529, 0);
            heff_take_n(v_x11_24529, 1ULL, 1);
            heff_drop(v_fs_24159);
            return heff_tag_at_n(v_ru_24x1_24528_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24531}), v_st_24530});
          }
          case TAG_Right: {
            V v_x_24532 = heff_field(v_x11_24529, 0);
            heff_take_n(v_x11_24529, 1ULL, 1);
            V v_t_24533 = (g_list_2emap_24s513201124x806973253(v_fs_24159));
            V v_x_24534 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24532, v_t_24533));
            return heff_tag_at_n(v_ru_24x1_24528_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24534}), v_st_24530});
          }
          default: return heff_nomatch(v_x11_24529);
          }
        }
        default: return heff_nomatch(v_x1_24528);
        }
      }
      case TAG_EFor: {
        V v_m_24541 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24158}));
        V v_x1_24542 = heff_tr(heff_call(v_m_24541, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24542)) {
        case TAG_MkPair: {
          V v_x11_24543 = heff_field(v_x1_24542, 0);
          V v_st_24544 = heff_field(v_x1_24542, 1);
          V v_ru_24x1_24542_24MkPair = heff_take_reuse_n(v_x1_24542, 3ULL, 2);
          switch (heff_tag_of(v_x11_24543)) {
          case TAG_Left: {
            V v_e_24545 = heff_field(v_x11_24543, 0);
            heff_take_n(v_x11_24543, 1ULL, 1);
            heff_drop(v_fs_24159);
            return heff_tag_at_n(v_ru_24x1_24542_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24545}), v_st_24544});
          }
          case TAG_Right: {
            V v_x_24546 = heff_field(v_x11_24543, 0);
            heff_take_n(v_x11_24543, 1ULL, 1);
            V v_t_24547 = (g_list_2emap_24s513201124x806973253(v_fs_24159));
            V v_x_24548 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24546, v_t_24547));
            return heff_tag_at_n(v_ru_24x1_24542_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24548}), v_st_24544});
          }
          default: return heff_nomatch(v_x11_24543);
          }
        }
        default: return heff_nomatch(v_x1_24542);
        }
      }
      case TAG_EJump: {
        V v_m_24550 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24158}));
        V v_x1_24551 = heff_tr(heff_call(v_m_24550, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24551)) {
        case TAG_MkPair: {
          V v_x11_24552 = heff_field(v_x1_24551, 0);
          V v_st_24553 = heff_field(v_x1_24551, 1);
          V v_ru_24x1_24551_24MkPair = heff_take_reuse_n(v_x1_24551, 3ULL, 2);
          switch (heff_tag_of(v_x11_24552)) {
          case TAG_Left: {
            V v_e_24554 = heff_field(v_x11_24552, 0);
            heff_take_n(v_x11_24552, 1ULL, 1);
            heff_drop(v_fs_24159);
            return heff_tag_at_n(v_ru_24x1_24551_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24554}), v_st_24553});
          }
          case TAG_Right: {
            V v_x_24555 = heff_field(v_x11_24552, 0);
            heff_take_n(v_x11_24552, 1ULL, 1);
            V v_t_24556 = (g_list_2emap_24s513201124x806973253(v_fs_24159));
            V v_x_24557 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24555, v_t_24556));
            return heff_tag_at_n(v_ru_24x1_24551_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24557}), v_st_24553});
          }
          default: return heff_nomatch(v_x11_24552);
          }
        }
        default: return heff_nomatch(v_x1_24551);
        }
      }
      case TAG_EReturn: {
        V v_m_24560 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24158}));
        V v_x1_24561 = heff_tr(heff_call(v_m_24560, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24561)) {
        case TAG_MkPair: {
          V v_x11_24562 = heff_field(v_x1_24561, 0);
          V v_st_24563 = heff_field(v_x1_24561, 1);
          V v_ru_24x1_24561_24MkPair = heff_take_reuse_n(v_x1_24561, 3ULL, 2);
          switch (heff_tag_of(v_x11_24562)) {
          case TAG_Left: {
            V v_e_24564 = heff_field(v_x11_24562, 0);
            heff_take_n(v_x11_24562, 1ULL, 1);
            heff_drop(v_fs_24159);
            return heff_tag_at_n(v_ru_24x1_24561_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24564}), v_st_24563});
          }
          case TAG_Right: {
            V v_x_24565 = heff_field(v_x11_24562, 0);
            heff_take_n(v_x11_24562, 1ULL, 1);
            V v_t_24566 = (g_list_2emap_24s513201124x806973253(v_fs_24159));
            V v_x_24567 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24565, v_t_24566));
            return heff_tag_at_n(v_ru_24x1_24561_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24567}), v_st_24563});
          }
          default: return heff_nomatch(v_x11_24562);
          }
        }
        default: return heff_nomatch(v_x1_24561);
        }
      }
      case TAG_ENest: {
        V v_m_24572 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24158}));
        V v_x1_24573 = heff_tr(heff_call(v_m_24572, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24573)) {
        case TAG_MkPair: {
          V v_x11_24574 = heff_field(v_x1_24573, 0);
          V v_st_24575 = heff_field(v_x1_24573, 1);
          V v_ru_24x1_24573_24MkPair = heff_take_reuse_n(v_x1_24573, 3ULL, 2);
          switch (heff_tag_of(v_x11_24574)) {
          case TAG_Left: {
            V v_e_24576 = heff_field(v_x11_24574, 0);
            heff_take_n(v_x11_24574, 1ULL, 1);
            heff_drop(v_fs_24159);
            return heff_tag_at_n(v_ru_24x1_24573_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24576}), v_st_24575});
          }
          case TAG_Right: {
            V v_x_24577 = heff_field(v_x11_24574, 0);
            heff_take_n(v_x11_24574, 1ULL, 1);
            V v_t_24578 = (g_list_2emap_24s513201124x806973253(v_fs_24159));
            V v_x_24579 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24577, v_t_24578));
            return heff_tag_at_n(v_ru_24x1_24573_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24579}), v_st_24575});
          }
          default: return heff_nomatch(v_x11_24574);
          }
        }
        default: return heff_nomatch(v_x1_24573);
        }
      }
      case TAG_IfThen: {
        V v_m_24584 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24158}));
        V v_x1_24585 = heff_tr(heff_call(v_m_24584, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24585)) {
        case TAG_MkPair: {
          V v_x11_24586 = heff_field(v_x1_24585, 0);
          V v_st_24587 = heff_field(v_x1_24585, 1);
          V v_ru_24x1_24585_24MkPair = heff_take_reuse_n(v_x1_24585, 3ULL, 2);
          switch (heff_tag_of(v_x11_24586)) {
          case TAG_Left: {
            V v_e_24588 = heff_field(v_x11_24586, 0);
            heff_take_n(v_x11_24586, 1ULL, 1);
            heff_drop(v_fs_24159);
            return heff_tag_at_n(v_ru_24x1_24585_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24588}), v_st_24587});
          }
          case TAG_Right: {
            V v_x_24589 = heff_field(v_x11_24586, 0);
            heff_take_n(v_x11_24586, 1ULL, 1);
            V v_t_24590 = (g_list_2emap_24s513201124x806973253(v_fs_24159));
            V v_x_24591 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24589, v_t_24590));
            return heff_tag_at_n(v_ru_24x1_24585_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24591}), v_st_24587});
          }
          default: return heff_nomatch(v_x11_24586);
          }
        }
        default: return heff_nomatch(v_x1_24585);
        }
      }
      case TAG_ELetCond: {
        V v_m_24596 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24158}));
        V v_x1_24597 = heff_tr(heff_call(v_m_24596, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24597)) {
        case TAG_MkPair: {
          V v_x11_24598 = heff_field(v_x1_24597, 0);
          V v_st_24599 = heff_field(v_x1_24597, 1);
          V v_ru_24x1_24597_24MkPair = heff_take_reuse_n(v_x1_24597, 3ULL, 2);
          switch (heff_tag_of(v_x11_24598)) {
          case TAG_Left: {
            V v_e_24600 = heff_field(v_x11_24598, 0);
            heff_take_n(v_x11_24598, 1ULL, 1);
            heff_drop(v_fs_24159);
            return heff_tag_at_n(v_ru_24x1_24597_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24600}), v_st_24599});
          }
          case TAG_Right: {
            V v_x_24601 = heff_field(v_x11_24598, 0);
            heff_take_n(v_x11_24598, 1ULL, 1);
            V v_t_24602 = (g_list_2emap_24s513201124x806973253(v_fs_24159));
            V v_x_24603 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24601, v_t_24602));
            return heff_tag_at_n(v_ru_24x1_24597_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24603}), v_st_24599});
          }
          default: return heff_nomatch(v_x11_24598);
          }
        }
        default: return heff_nomatch(v_x1_24597);
        }
      }
      case TAG_ETry: {
        V v_m_24608 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24158}));
        V v_x1_24609 = heff_tr(heff_call(v_m_24608, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24609)) {
        case TAG_MkPair: {
          V v_x11_24610 = heff_field(v_x1_24609, 0);
          V v_st_24611 = heff_field(v_x1_24609, 1);
          V v_ru_24x1_24609_24MkPair = heff_take_reuse_n(v_x1_24609, 3ULL, 2);
          switch (heff_tag_of(v_x11_24610)) {
          case TAG_Left: {
            V v_e_24612 = heff_field(v_x11_24610, 0);
            heff_take_n(v_x11_24610, 1ULL, 1);
            heff_drop(v_fs_24159);
            return heff_tag_at_n(v_ru_24x1_24609_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24612}), v_st_24611});
          }
          case TAG_Right: {
            V v_x_24613 = heff_field(v_x11_24610, 0);
            heff_take_n(v_x11_24610, 1ULL, 1);
            V v_t_24614 = (g_list_2emap_24s513201124x806973253(v_fs_24159));
            V v_x_24615 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24613, v_t_24614));
            return heff_tag_at_n(v_ru_24x1_24609_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24615}), v_st_24611});
          }
          default: return heff_nomatch(v_x11_24610);
          }
        }
        default: return heff_nomatch(v_x1_24609);
        }
      }
      case TAG_ECatch: {
        V v_m_24620 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24158}));
        V v_x1_24621 = heff_tr(heff_call(v_m_24620, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24621)) {
        case TAG_MkPair: {
          V v_x11_24622 = heff_field(v_x1_24621, 0);
          V v_st_24623 = heff_field(v_x1_24621, 1);
          V v_ru_24x1_24621_24MkPair = heff_take_reuse_n(v_x1_24621, 3ULL, 2);
          switch (heff_tag_of(v_x11_24622)) {
          case TAG_Left: {
            V v_e_24624 = heff_field(v_x11_24622, 0);
            heff_take_n(v_x11_24622, 1ULL, 1);
            heff_drop(v_fs_24159);
            return heff_tag_at_n(v_ru_24x1_24621_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24624}), v_st_24623});
          }
          case TAG_Right: {
            V v_x_24625 = heff_field(v_x11_24622, 0);
            heff_take_n(v_x11_24622, 1ULL, 1);
            V v_t_24626 = (g_list_2emap_24s513201124x806973253(v_fs_24159));
            V v_x_24627 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24625, v_t_24626));
            return heff_tag_at_n(v_ru_24x1_24621_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24627}), v_st_24623});
          }
          default: return heff_nomatch(v_x11_24622);
          }
        }
        default: return heff_nomatch(v_x1_24621);
        }
      }
      default: return heff_nomatch(v_it1_24158);
      }
    }
  }
  case TAG_ENeg: {
    V v_m_24628 = heff_field(v_e0_241, 0);
    V v_e_24629 = heff_field(v_e0_241, 1);
    V v_ru_24e0_241_24ENeg = heff_take_reuse_n(v_e0_241, 3ULL, 2);
    V v_m_24630 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_24629}));
    V v_x1_24631 = heff_tr(heff_call(v_m_24630, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x1_24631)) {
    case TAG_MkPair: {
      V v_x11_24632 = heff_field(v_x1_24631, 0);
      V v_st_24633 = heff_field(v_x1_24631, 1);
      V v_ru_24x1_24631_24MkPair = heff_take_reuse_n(v_x1_24631, 3ULL, 2);
      switch (heff_tag_of(v_x11_24632)) {
      case TAG_Left: {
        V v_e_24634 = heff_field(v_x11_24632, 0);
        heff_take_n(v_x11_24632, 1ULL, 1);
        heff_drop_rec(v_m_24628, 9);
        heff_drop_cell(v_ru_24x1_24631_24MkPair, 2);
        return heff_tag_at_n(v_ru_24e0_241_24ENeg, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24634}), v_st_24633});
      }
      case TAG_Right: {
        V v_x_24635 = heff_field(v_x11_24632, 0);
        heff_take_n(v_x11_24632, 1ULL, 1);
        V v_t_24636 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_m_24628, 3), heff_get_n(v_m_24628, 4, 9)});
        V v_t_24637 = heff_tag_at_n(v_ru_24e0_241_24ENeg, TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2eexprL_str22)}), v_t_24636});
        V v_t_24638 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_24635, NTAG(TAG_Nil)});
        V v_x_24639 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_24637, v_t_24638));
        return heff_tag_at_n(v_ru_24x1_24631_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24639}), v_st_24633});
      }
      default: return heff_nomatch(v_x11_24632);
      }
    }
    default: return heff_nomatch(v_x1_24631);
    }
  }
  case TAG_App: {
    V v_h_24640 = heff_field(v_e0_241, 0);
    V v_args_24641 = heff_field(v_e0_241, 1);
    V v_ru_24e0_241_24App = heff_take_reuse_n(v_e0_241, 3ULL, 2);
    V v_m_24642 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_h_24640}));
    V v_x1_24643 = heff_tr(heff_call(v_m_24642, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x1_24643)) {
    case TAG_MkPair: {
      V v_x11_24644 = heff_field(v_x1_24643, 0);
      V v_st_24645 = heff_field(v_x1_24643, 1);
      heff_take_n(v_x1_24643, 3ULL, 2);
      switch (heff_tag_of(v_x11_24644)) {
      case TAG_Left: {
        V v_e_24646 = heff_field(v_x11_24644, 0);
        heff_take_n(v_x11_24644, 1ULL, 1);
        heff_drop_rec(v_r_240, 3);
        heff_drop(v_args_24641);
        return heff_tag_at_n(v_ru_24e0_241_24App, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24646}), v_st_24645});
      }
      case TAG_Right: {
        V v_x_24647 = heff_field(v_x11_24644, 0);
        heff_take_n(v_x11_24644, 1ULL, 1);
        V v_m_24649 = (g_prelude_2etraverse_24s499544530x2060473942(heff_clo_n(g_heff_2esyntax_2esurface_2eexprL_lam4, 1, 1, (V[]){v_r_240}), v_args_24641));
        V v_x1_24650 = heff_tr(heff_call(v_m_24649, 1, (V[]){v_st_24645}));
        switch (heff_tag_of(v_x1_24650)) {
        case TAG_MkPair: {
          V v_x11_24651 = heff_field(v_x1_24650, 0);
          V v_st_24652 = heff_field(v_x1_24650, 1);
          heff_take_n(v_x1_24650, 3ULL, 2);
          switch (heff_tag_of(v_x11_24651)) {
          case TAG_Left: {
            V v_e_24653 = heff_field(v_x11_24651, 0);
            heff_take_n(v_x11_24651, 1ULL, 1);
            heff_drop(v_x_24647);
            return heff_tag_at_n(v_ru_24e0_241_24App, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24653}), v_st_24652});
          }
          case TAG_Right: {
            V v_x_24654 = heff_field(v_x11_24651, 0);
            heff_take_n(v_x11_24651, 1ULL, 1);
            V v_x_24655 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24647, v_x_24654));
            return heff_tag_at_n(v_ru_24e0_241_24App, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24655}), v_st_24652});
          }
          default: return heff_nomatch(v_x11_24651);
          }
        }
        default: return heff_nomatch(v_x1_24650);
        }
      }
      default: return heff_nomatch(v_x11_24644);
      }
    }
    default: return heff_nomatch(v_x1_24643);
    }
  }
  case TAG_Op: {
    V v_a_24656 = heff_field(v_e0_241, 0);
    V v_op_24657 = heff_field(v_e0_241, 1);
    V v_b_24658 = heff_field(v_e0_241, 2);
    heff_take_n(v_e0_241, 7ULL, 3);
    return (g_heff_2esyntax_2esurface_2eopL(v_r_240, v_a_24656, v_op_24657, v_b_24658, v_z_242));
  }
  case TAG_Ops: {
    V v_a_24659 = heff_field(v_e0_241, 0);
    V v_rest_24660 = heff_field(v_e0_241, 1);
    V v_ru_24e0_241_24Ops = heff_take_reuse_n(v_e0_241, 3ULL, 2);
    V v_m_24661 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_24659}));
    V v_x1_24662 = heff_tr(heff_call(v_m_24661, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x1_24662)) {
    case TAG_MkPair: {
      V v_x11_24663 = heff_field(v_x1_24662, 0);
      V v_st_24664 = heff_field(v_x1_24662, 1);
      heff_take_n(v_x1_24662, 3ULL, 2);
      switch (heff_tag_of(v_x11_24663)) {
      case TAG_Left: {
        V v_e_24665 = heff_field(v_x11_24663, 0);
        heff_take_n(v_x11_24663, 1ULL, 1);
        heff_drop_rec(v_r_240, 3);
        heff_drop(v_rest_24660);
        return heff_tag_at_n(v_ru_24e0_241_24Ops, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24665}), v_st_24664});
      }
      case TAG_Right: {
        V v_x_24666 = heff_field(v_x11_24663, 0);
        heff_take_n(v_x11_24663, 1ULL, 1);
        V v_m_24681 = (g_prelude_2etraverse_24s499544530x2060473942(heff_clo_n(g_heff_2esyntax_2esurface_2eexprL_lam5, 1, 1, (V[]){v_r_240}), v_rest_24660));
        V v_x1_24682 = heff_tr(heff_call(v_m_24681, 1, (V[]){v_st_24664}));
        switch (heff_tag_of(v_x1_24682)) {
        case TAG_MkPair: {
          V v_x11_24683 = heff_field(v_x1_24682, 0);
          V v_st_24684 = heff_field(v_x1_24682, 1);
          heff_take_n(v_x1_24682, 3ULL, 2);
          switch (heff_tag_of(v_x11_24683)) {
          case TAG_Left: {
            V v_e_24685 = heff_field(v_x11_24683, 0);
            heff_take_n(v_x11_24683, 1ULL, 1);
            heff_drop(v_x_24666);
            return heff_tag_at_n(v_ru_24e0_241_24Ops, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24685}), v_st_24684});
          }
          case TAG_Right: {
            V v_x_24686 = heff_field(v_x11_24683, 0);
            heff_take_n(v_x11_24683, 1ULL, 1);
            heff_drop_cell(v_ru_24e0_241_24Ops, 2);
            HEFF_LAST return g_heff_2esyntax_2esurface_2eresolve_24s1832151779x1448561609(v_x_24666, v_x_24686, v_st_24684);
          }
          default: return heff_nomatch(v_x11_24683);
          }
        }
        default: return heff_nomatch(v_x1_24682);
        }
      }
      default: return heff_nomatch(v_x11_24663);
      }
    }
    default: return heff_nomatch(v_x1_24662);
    }
  }
  case TAG_OpRhs: {
    heff_drop_rec(v_r_240, 3);
    V v_t_24689 = (g_heff_2esyntax_2ecst_2efirstE(v_e0_241));
    V v_t_24690 = ({ V a_0 = v_e0_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e0_241, 2); r_; });
    V v_t_24691 = heff_strAppend(heff_get_n(v_t_24690, 1, 9), ((V)&g_heff_2esyntax_2esurface_2eexprL_str23));
    V v_msg_24692 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eexprL_str24), v_t_24691);
    V v_t_24693 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24689, 3), heff_get_n(v_t_24689, 4, 9)});
    V v_t_24694 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24692, v_t_24693, NTAG(TAG_Nothing)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24694}), v_z_242});
  }
  case TAG_Ann: {
    V v_e_24695 = heff_field(v_e0_241, 0);
    V v_ty_24697 = heff_field(v_e0_241, 2);
    heff_take_n(v_e0_241, 5ULL, 3);
    V v_m_24698 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e_24695}));
    V v_x1_24699 = heff_tr(heff_call(v_m_24698, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x1_24699)) {
    case TAG_MkPair: {
      V v_x11_24700 = heff_field(v_x1_24699, 0);
      V v_st_24701 = heff_field(v_x1_24699, 1);
      V v_ru_24x1_24699_24MkPair = heff_take_reuse_n(v_x1_24699, 3ULL, 2);
      switch (heff_tag_of(v_x11_24700)) {
      case TAG_Left: {
        V v_e_24702 = heff_field(v_x11_24700, 0);
        heff_take_n(v_x11_24700, 1ULL, 1);
        heff_drop_rec(v_r_240, 3);
        heff_drop(v_ty_24697);
        return heff_tag_at_n(v_ru_24x1_24699_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24702}), v_st_24701});
      }
      case TAG_Right: {
        V v_x_24703 = heff_field(v_x11_24700, 0);
        heff_take_n(v_x11_24700, 1ULL, 1);
        V v_m_24704 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_ty_24697}));
        V v_x1_24705 = heff_tr(heff_call(v_m_24704, 1, (V[]){v_st_24701}));
        switch (heff_tag_of(v_x1_24705)) {
        case TAG_MkPair: {
          V v_x11_24706 = heff_field(v_x1_24705, 0);
          V v_st_24707 = heff_field(v_x1_24705, 1);
          V v_ru_24x1_24705_24MkPair = heff_take_reuse_n(v_x1_24705, 3ULL, 2);
          switch (heff_tag_of(v_x11_24706)) {
          case TAG_Left: {
            V v_e_24708 = heff_field(v_x11_24706, 0);
            heff_take_n(v_x11_24706, 1ULL, 1);
            heff_drop(v_x_24703);
            heff_drop_cell(v_ru_24x1_24705_24MkPair, 2);
            return heff_tag_at_n(v_ru_24x1_24699_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24708}), v_st_24707});
          }
          case TAG_Right: {
            V v_x_24709 = heff_field(v_x11_24706, 0);
            heff_take_n(v_x11_24706, 1ULL, 1);
            V v_t_24712;
            switch (heff_tag_of(v_x_24703)) {
            case TAG_At: {
              V v_s_24711 = heff_dup(heff_field(v_x_24703, 1));
              v_t_24712 = v_s_24711;
              break;
            }
            default: heff_nomatch(v_x_24703);
            }
            V v_t_24715;
            switch (heff_tag_of(v_x_24709)) {
            case TAG_At: {
              V v_s_24714 = heff_dup(heff_field(v_x_24709, 1));
              v_t_24715 = v_s_24714;
              break;
            }
            default: heff_nomatch(v_x_24709);
            }
            V v_t_24716 = ({ V rv_1 = heff_get_n(v_t_24715, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24712, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
            V v_t_24717 = heff_tag_at_n(v_ru_24x1_24705_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_EAnn, 2, (V[]){v_x_24703, v_x_24709}), v_t_24716});
            return heff_tag_at_n(v_ru_24x1_24699_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24717}), v_st_24707});
          }
          default: return heff_nomatch(v_x11_24706);
          }
        }
        default: return heff_nomatch(v_x1_24705);
        }
      }
      default: return heff_nomatch(v_x11_24700);
      }
    }
    default: return heff_nomatch(v_x1_24699);
    }
  }
  case TAG_BVar: {
    heff_drop_rec(v_r_240, 3);
    V v_t_24719 = (g_heff_2esyntax_2ecst_2efirstE(v_e0_241));
    V v_t_24720 = ({ V a_0 = v_e0_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e0_241, 1); r_; });
    V v_t_24721 = heff_strAppend(heff_get_n(v_t_24720, 1, 9), ((V)&g_heff_2esyntax_2esurface_2eexprL_str25));
    V v_msg_24722 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eexprL_str26), v_t_24721);
    V v_t_24723 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24719, 3), heff_get_n(v_t_24719, 4, 9)});
    V v_t_24724 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24722, v_t_24723, NTAG(TAG_Nothing)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24724}), v_z_242});
  }
  case TAG_BImp: {
    heff_drop_rec(v_r_240, 3);
    V v_t_24728 = (g_heff_2esyntax_2ecst_2efirstE(v_e0_241));
    V v_t_24729 = ({ V a_0 = v_e0_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e0_241, 3); r_; });
    V v_t_24730 = heff_strAppend(heff_get_n(v_t_24729, 1, 9), ((V)&g_heff_2esyntax_2esurface_2eexprL_str27));
    V v_msg_24731 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eexprL_str28), v_t_24730);
    V v_t_24732 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24728, 3), heff_get_n(v_t_24728, 4, 9)});
    V v_t_24733 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24731, v_t_24732, NTAG(TAG_Nothing)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24733}), v_z_242});
  }
  case TAG_BAnn: {
    heff_drop_rec(v_r_240, 3);
    V v_t_24739 = (g_heff_2esyntax_2ecst_2efirstE(v_e0_241));
    V v_t_24740 = ({ V a_0 = v_e0_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e0_241, 5); r_; });
    V v_t_24741 = heff_strAppend(heff_get_n(v_t_24740, 1, 9), ((V)&g_heff_2esyntax_2esurface_2eexprL_str29));
    V v_msg_24742 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eexprL_str30), v_t_24741);
    V v_t_24743 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24739, 3), heff_get_n(v_t_24739, 4, 9)});
    V v_t_24744 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24742, v_t_24743, NTAG(TAG_Nothing)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24744}), v_z_242});
  }
  case TAG_Lam: {
    V v_binders_24746 = heff_field(v_e0_241, 1);
    V v_body_24748 = heff_field(v_e0_241, 3);
    heff_take_n(v_e0_241, 10ULL, 4);
    return (g_heff_2esyntax_2esurface_2elambdaL(v_r_240, v_binders_24746, v_body_24748, v_z_242));
  }
  case TAG_Case: {
    V v_kw_24749 = heff_dup(heff_field(v_e0_241, 0));
    V v_scrut_24750 = heff_dup(heff_field(v_e0_241, 1));
    V v_alts_24752 = heff_dup(heff_field(v_e0_241, 3));
    V v_m_24753 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_scrut_24750}));
    V v_x1_24754 = heff_tr(heff_call(v_m_24753, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x1_24754)) {
    case TAG_MkPair: {
      V v_x11_24755 = heff_field(v_x1_24754, 0);
      V v_st_24756 = heff_field(v_x1_24754, 1);
      V v_ru_24x1_24754_24MkPair = heff_take_reuse_n(v_x1_24754, 3ULL, 2);
      switch (heff_tag_of(v_x11_24755)) {
      case TAG_Left: {
        V v_e_24757 = heff_field(v_x11_24755, 0);
        heff_take_n(v_x11_24755, 1ULL, 1);
        heff_drop_rec(v_r_240, 3);
        heff_drop_tag(v_e0_241, 4);
        heff_drop_rec(v_kw_24749, 9);
        heff_drop(v_alts_24752);
        return heff_tag_at_n(v_ru_24x1_24754_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24757}), v_st_24756});
      }
      case TAG_Right: {
        V v_x_24758 = heff_field(v_x11_24755, 0);
        heff_take_n(v_x11_24755, 1ULL, 1);
        HeffT2 v_t_24760 = (g_heff_2esyntax_2esurface_2eblock_24cpr(heff_clo_n(g_heff_2esyntax_2esurface_2eexprL_lam7, 1, 1, (V[]){v_r_240}), v_alts_24752, v_st_24756));
        {
          V v_field_24761 = v_t_24760.f[0];
          V v_field_24762 = v_t_24760.f[1];
          V v_x11_24763 = v_field_24761;
          V v_st_24764 = v_field_24762;
          switch (heff_tag_of(v_x11_24763)) {
          case TAG_Left: {
            V v_e_24765 = heff_field(v_x11_24763, 0);
            heff_take_n(v_x11_24763, 1ULL, 1);
            heff_drop_tag(v_e0_241, 4);
            heff_drop_rec(v_kw_24749, 9);
            heff_drop(v_x_24758);
            return heff_tag_at_n(v_ru_24x1_24754_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24765}), v_st_24764});
          }
          case TAG_Right: {
            V v_x_24766 = heff_field(v_x11_24763, 0);
            heff_take_n(v_x11_24763, 1ULL, 1);
            V v_t_24767 = (g_heff_2esyntax_2ecst_2elastE(v_e0_241));
            V v_e_24768 = heff_get_n(v_t_24767, 4, 9);
            V v_t_24769 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_24749, 3, 9), v_e_24768});
            V v_x_24770 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_x_24758, v_x_24766}), v_t_24769});
            return heff_tag_at_n(v_ru_24x1_24754_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24770}), v_st_24764});
          }
          default: return heff_nomatch(v_x11_24763);
          }
        }
      }
      default: return heff_nomatch(v_x11_24755);
      }
    }
    default: return heff_nomatch(v_x1_24754);
    }
  }
  case TAG_EAlt: {
    heff_drop_rec(v_r_240, 3);
    V v_t_24774 = (g_heff_2esyntax_2ecst_2efirstE(v_e0_241));
    V v_t_24775 = ({ V a_0 = v_e0_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e0_241, 3); r_; });
    V v_t_24776 = heff_strAppend(heff_get_n(v_t_24775, 1, 9), ((V)&g_heff_2esyntax_2esurface_2eexprL_str31));
    V v_msg_24777 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eexprL_str32), v_t_24776);
    V v_t_24778 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24774, 3), heff_get_n(v_t_24774, 4, 9)});
    V v_t_24779 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24777, v_t_24778, NTAG(TAG_Nothing)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24779}), v_z_242});
  }
  case TAG_If: {
    V v_kw_24780 = heff_field(v_e0_241, 0);
    V v_e02_24781 = heff_field(v_e0_241, 1);
    V v_a_24783 = heff_field(v_e0_241, 3);
    V v_b_24785 = heff_field(v_e0_241, 5);
    heff_take_n(v_e0_241, 43ULL, 6);
    switch (heff_tag_of(v_e02_24781)) {
    case TAG_Atom: {
      V v_m_24787 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_24781}));
      V v_x1_24788 = heff_tr(heff_call(v_m_24787, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_24788)) {
      case TAG_MkPair: {
        V v_x11_24789 = heff_field(v_x1_24788, 0);
        V v_st_24790 = heff_field(v_x1_24788, 1);
        V v_ru_24x1_24788_24MkPair = heff_take_reuse_n(v_x1_24788, 3ULL, 2);
        switch (heff_tag_of(v_x11_24789)) {
        case TAG_Left: {
          V v_e_24791 = heff_field(v_x11_24789, 0);
          heff_take_n(v_x11_24789, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_24780, 9);
          heff_drop(v_a_24783);
          heff_drop(v_b_24785);
          return heff_tag_at_n(v_ru_24x1_24788_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24791}), v_st_24790});
        }
        case TAG_Right: {
          V v_x_24792 = heff_field(v_x11_24789, 0);
          heff_take_n(v_x11_24789, 1ULL, 1);
          V v_m_24793 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_24783}));
          V v_x1_24794 = heff_tr(heff_call(v_m_24793, 1, (V[]){v_st_24790}));
          switch (heff_tag_of(v_x1_24794)) {
          case TAG_MkPair: {
            V v_x11_24795 = heff_field(v_x1_24794, 0);
            V v_st_24796 = heff_field(v_x1_24794, 1);
            heff_take_n(v_x1_24794, 3ULL, 2);
            switch (heff_tag_of(v_x11_24795)) {
            case TAG_Left: {
              V v_e_24797 = heff_field(v_x11_24795, 0);
              heff_take_n(v_x11_24795, 1ULL, 1);
              heff_drop_rec(v_r_240, 3);
              heff_drop_rec(v_kw_24780, 9);
              heff_drop(v_b_24785);
              heff_drop(v_x_24792);
              return heff_tag_at_n(v_ru_24x1_24788_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24797}), v_st_24796});
            }
            case TAG_Right: {
              V v_x_24798 = heff_field(v_x11_24795, 0);
              heff_take_n(v_x11_24795, 1ULL, 1);
              V v_m_24799 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_b_24785)}));
              V v_x1_24800 = heff_tr(heff_call(v_m_24799, 1, (V[]){v_st_24796}));
              switch (heff_tag_of(v_x1_24800)) {
              case TAG_MkPair: {
                V v_x11_24801 = heff_field(v_x1_24800, 0);
                V v_st_24802 = heff_field(v_x1_24800, 1);
                heff_take_n(v_x1_24800, 3ULL, 2);
                switch (heff_tag_of(v_x11_24801)) {
                case TAG_Left: {
                  V v_e_24803 = heff_field(v_x11_24801, 0);
                  heff_take_n(v_x11_24801, 1ULL, 1);
                  heff_drop_rec(v_kw_24780, 9);
                  heff_drop(v_b_24785);
                  heff_drop(v_x_24792);
                  heff_drop(v_x_24798);
                  return heff_tag_at_n(v_ru_24x1_24788_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24803}), v_st_24802});
                }
                case TAG_Right: {
                  V v_x_24804 = heff_field(v_x11_24801, 0);
                  heff_take_n(v_x11_24801, 1ULL, 1);
                  V v_t_24805 = (g_heff_2esyntax_2ecst_2elastE(v_b_24785));
                  V v_e_24806 = heff_get_n(v_t_24805, 4, 9);
                  V v_t_24807 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_24780, 3, 9), v_e_24806});
                  V v_x_24808 = (g_heff_2esyntax_2esurface_2eifE(v_t_24807, v_x_24792, v_x_24798, v_x_24804));
                  return heff_tag_at_n(v_ru_24x1_24788_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24808}), v_st_24802});
                }
                default: return heff_nomatch(v_x11_24801);
                }
              }
              default: return heff_nomatch(v_x1_24800);
              }
            }
            default: return heff_nomatch(v_x11_24795);
            }
          }
          default: return heff_nomatch(v_x1_24794);
          }
        }
        default: return heff_nomatch(v_x11_24789);
        }
      }
      default: return heff_nomatch(v_x1_24788);
      }
    }
    case TAG_EParen: {
      V v_m_24812 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_24781}));
      V v_x1_24813 = heff_tr(heff_call(v_m_24812, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_24813)) {
      case TAG_MkPair: {
        V v_x11_24814 = heff_field(v_x1_24813, 0);
        V v_st_24815 = heff_field(v_x1_24813, 1);
        V v_ru_24x1_24813_24MkPair = heff_take_reuse_n(v_x1_24813, 3ULL, 2);
        switch (heff_tag_of(v_x11_24814)) {
        case TAG_Left: {
          V v_e_24816 = heff_field(v_x11_24814, 0);
          heff_take_n(v_x11_24814, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_24780, 9);
          heff_drop(v_a_24783);
          heff_drop(v_b_24785);
          return heff_tag_at_n(v_ru_24x1_24813_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24816}), v_st_24815});
        }
        case TAG_Right: {
          V v_x_24817 = heff_field(v_x11_24814, 0);
          heff_take_n(v_x11_24814, 1ULL, 1);
          V v_m_24818 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_24783}));
          V v_x1_24819 = heff_tr(heff_call(v_m_24818, 1, (V[]){v_st_24815}));
          switch (heff_tag_of(v_x1_24819)) {
          case TAG_MkPair: {
            V v_x11_24820 = heff_field(v_x1_24819, 0);
            V v_st_24821 = heff_field(v_x1_24819, 1);
            heff_take_n(v_x1_24819, 3ULL, 2);
            switch (heff_tag_of(v_x11_24820)) {
            case TAG_Left: {
              V v_e_24822 = heff_field(v_x11_24820, 0);
              heff_take_n(v_x11_24820, 1ULL, 1);
              heff_drop_rec(v_r_240, 3);
              heff_drop_rec(v_kw_24780, 9);
              heff_drop(v_b_24785);
              heff_drop(v_x_24817);
              return heff_tag_at_n(v_ru_24x1_24813_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24822}), v_st_24821});
            }
            case TAG_Right: {
              V v_x_24823 = heff_field(v_x11_24820, 0);
              heff_take_n(v_x11_24820, 1ULL, 1);
              V v_m_24824 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_b_24785)}));
              V v_x1_24825 = heff_tr(heff_call(v_m_24824, 1, (V[]){v_st_24821}));
              switch (heff_tag_of(v_x1_24825)) {
              case TAG_MkPair: {
                V v_x11_24826 = heff_field(v_x1_24825, 0);
                V v_st_24827 = heff_field(v_x1_24825, 1);
                heff_take_n(v_x1_24825, 3ULL, 2);
                switch (heff_tag_of(v_x11_24826)) {
                case TAG_Left: {
                  V v_e_24828 = heff_field(v_x11_24826, 0);
                  heff_take_n(v_x11_24826, 1ULL, 1);
                  heff_drop_rec(v_kw_24780, 9);
                  heff_drop(v_b_24785);
                  heff_drop(v_x_24817);
                  heff_drop(v_x_24823);
                  return heff_tag_at_n(v_ru_24x1_24813_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24828}), v_st_24827});
                }
                case TAG_Right: {
                  V v_x_24829 = heff_field(v_x11_24826, 0);
                  heff_take_n(v_x11_24826, 1ULL, 1);
                  V v_t_24830 = (g_heff_2esyntax_2ecst_2elastE(v_b_24785));
                  V v_e_24831 = heff_get_n(v_t_24830, 4, 9);
                  V v_t_24832 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_24780, 3, 9), v_e_24831});
                  V v_x_24833 = (g_heff_2esyntax_2esurface_2eifE(v_t_24832, v_x_24817, v_x_24823, v_x_24829));
                  return heff_tag_at_n(v_ru_24x1_24813_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24833}), v_st_24827});
                }
                default: return heff_nomatch(v_x11_24826);
                }
              }
              default: return heff_nomatch(v_x1_24825);
              }
            }
            default: return heff_nomatch(v_x11_24820);
            }
          }
          default: return heff_nomatch(v_x1_24819);
          }
        }
        default: return heff_nomatch(v_x11_24814);
        }
      }
      default: return heff_nomatch(v_x1_24813);
      }
    }
    case TAG_Named: {
      V v_m_24839 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_24781}));
      V v_x1_24840 = heff_tr(heff_call(v_m_24839, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_24840)) {
      case TAG_MkPair: {
        V v_x11_24841 = heff_field(v_x1_24840, 0);
        V v_st_24842 = heff_field(v_x1_24840, 1);
        V v_ru_24x1_24840_24MkPair = heff_take_reuse_n(v_x1_24840, 3ULL, 2);
        switch (heff_tag_of(v_x11_24841)) {
        case TAG_Left: {
          V v_e_24843 = heff_field(v_x11_24841, 0);
          heff_take_n(v_x11_24841, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_24780, 9);
          heff_drop(v_a_24783);
          heff_drop(v_b_24785);
          return heff_tag_at_n(v_ru_24x1_24840_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24843}), v_st_24842});
        }
        case TAG_Right: {
          V v_x_24844 = heff_field(v_x11_24841, 0);
          heff_take_n(v_x11_24841, 1ULL, 1);
          V v_m_24845 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_24783}));
          V v_x1_24846 = heff_tr(heff_call(v_m_24845, 1, (V[]){v_st_24842}));
          switch (heff_tag_of(v_x1_24846)) {
          case TAG_MkPair: {
            V v_x11_24847 = heff_field(v_x1_24846, 0);
            V v_st_24848 = heff_field(v_x1_24846, 1);
            heff_take_n(v_x1_24846, 3ULL, 2);
            switch (heff_tag_of(v_x11_24847)) {
            case TAG_Left: {
              V v_e_24849 = heff_field(v_x11_24847, 0);
              heff_take_n(v_x11_24847, 1ULL, 1);
              heff_drop_rec(v_r_240, 3);
              heff_drop_rec(v_kw_24780, 9);
              heff_drop(v_b_24785);
              heff_drop(v_x_24844);
              return heff_tag_at_n(v_ru_24x1_24840_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24849}), v_st_24848});
            }
            case TAG_Right: {
              V v_x_24850 = heff_field(v_x11_24847, 0);
              heff_take_n(v_x11_24847, 1ULL, 1);
              V v_m_24851 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_b_24785)}));
              V v_x1_24852 = heff_tr(heff_call(v_m_24851, 1, (V[]){v_st_24848}));
              switch (heff_tag_of(v_x1_24852)) {
              case TAG_MkPair: {
                V v_x11_24853 = heff_field(v_x1_24852, 0);
                V v_st_24854 = heff_field(v_x1_24852, 1);
                heff_take_n(v_x1_24852, 3ULL, 2);
                switch (heff_tag_of(v_x11_24853)) {
                case TAG_Left: {
                  V v_e_24855 = heff_field(v_x11_24853, 0);
                  heff_take_n(v_x11_24853, 1ULL, 1);
                  heff_drop_rec(v_kw_24780, 9);
                  heff_drop(v_b_24785);
                  heff_drop(v_x_24844);
                  heff_drop(v_x_24850);
                  return heff_tag_at_n(v_ru_24x1_24840_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24855}), v_st_24854});
                }
                case TAG_Right: {
                  V v_x_24856 = heff_field(v_x11_24853, 0);
                  heff_take_n(v_x11_24853, 1ULL, 1);
                  V v_t_24857 = (g_heff_2esyntax_2ecst_2elastE(v_b_24785));
                  V v_e_24858 = heff_get_n(v_t_24857, 4, 9);
                  V v_t_24859 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_24780, 3, 9), v_e_24858});
                  V v_x_24860 = (g_heff_2esyntax_2esurface_2eifE(v_t_24859, v_x_24844, v_x_24850, v_x_24856));
                  return heff_tag_at_n(v_ru_24x1_24840_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24860}), v_st_24854});
                }
                default: return heff_nomatch(v_x11_24853);
                }
              }
              default: return heff_nomatch(v_x1_24852);
              }
            }
            default: return heff_nomatch(v_x11_24847);
            }
          }
          default: return heff_nomatch(v_x1_24846);
          }
        }
        default: return heff_nomatch(v_x11_24841);
        }
      }
      default: return heff_nomatch(v_x1_24840);
      }
    }
    case TAG_Tup: {
      V v_m_24865 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_24781}));
      V v_x1_24866 = heff_tr(heff_call(v_m_24865, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_24866)) {
      case TAG_MkPair: {
        V v_x11_24867 = heff_field(v_x1_24866, 0);
        V v_st_24868 = heff_field(v_x1_24866, 1);
        V v_ru_24x1_24866_24MkPair = heff_take_reuse_n(v_x1_24866, 3ULL, 2);
        switch (heff_tag_of(v_x11_24867)) {
        case TAG_Left: {
          V v_e_24869 = heff_field(v_x11_24867, 0);
          heff_take_n(v_x11_24867, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_24780, 9);
          heff_drop(v_a_24783);
          heff_drop(v_b_24785);
          return heff_tag_at_n(v_ru_24x1_24866_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24869}), v_st_24868});
        }
        case TAG_Right: {
          V v_x_24870 = heff_field(v_x11_24867, 0);
          heff_take_n(v_x11_24867, 1ULL, 1);
          V v_m_24871 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_24783}));
          V v_x1_24872 = heff_tr(heff_call(v_m_24871, 1, (V[]){v_st_24868}));
          switch (heff_tag_of(v_x1_24872)) {
          case TAG_MkPair: {
            V v_x11_24873 = heff_field(v_x1_24872, 0);
            V v_st_24874 = heff_field(v_x1_24872, 1);
            heff_take_n(v_x1_24872, 3ULL, 2);
            switch (heff_tag_of(v_x11_24873)) {
            case TAG_Left: {
              V v_e_24875 = heff_field(v_x11_24873, 0);
              heff_take_n(v_x11_24873, 1ULL, 1);
              heff_drop_rec(v_r_240, 3);
              heff_drop_rec(v_kw_24780, 9);
              heff_drop(v_b_24785);
              heff_drop(v_x_24870);
              return heff_tag_at_n(v_ru_24x1_24866_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24875}), v_st_24874});
            }
            case TAG_Right: {
              V v_x_24876 = heff_field(v_x11_24873, 0);
              heff_take_n(v_x11_24873, 1ULL, 1);
              V v_m_24877 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_b_24785)}));
              V v_x1_24878 = heff_tr(heff_call(v_m_24877, 1, (V[]){v_st_24874}));
              switch (heff_tag_of(v_x1_24878)) {
              case TAG_MkPair: {
                V v_x11_24879 = heff_field(v_x1_24878, 0);
                V v_st_24880 = heff_field(v_x1_24878, 1);
                heff_take_n(v_x1_24878, 3ULL, 2);
                switch (heff_tag_of(v_x11_24879)) {
                case TAG_Left: {
                  V v_e_24881 = heff_field(v_x11_24879, 0);
                  heff_take_n(v_x11_24879, 1ULL, 1);
                  heff_drop_rec(v_kw_24780, 9);
                  heff_drop(v_b_24785);
                  heff_drop(v_x_24870);
                  heff_drop(v_x_24876);
                  return heff_tag_at_n(v_ru_24x1_24866_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24881}), v_st_24880});
                }
                case TAG_Right: {
                  V v_x_24882 = heff_field(v_x11_24879, 0);
                  heff_take_n(v_x11_24879, 1ULL, 1);
                  V v_t_24883 = (g_heff_2esyntax_2ecst_2elastE(v_b_24785));
                  V v_e_24884 = heff_get_n(v_t_24883, 4, 9);
                  V v_t_24885 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_24780, 3, 9), v_e_24884});
                  V v_x_24886 = (g_heff_2esyntax_2esurface_2eifE(v_t_24885, v_x_24870, v_x_24876, v_x_24882));
                  return heff_tag_at_n(v_ru_24x1_24866_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24886}), v_st_24880});
                }
                default: return heff_nomatch(v_x11_24879);
                }
              }
              default: return heff_nomatch(v_x1_24878);
              }
            }
            default: return heff_nomatch(v_x11_24873);
            }
          }
          default: return heff_nomatch(v_x1_24872);
          }
        }
        default: return heff_nomatch(v_x11_24867);
        }
      }
      default: return heff_nomatch(v_x1_24866);
      }
    }
    case TAG_Seg: {
      V v_m_24890 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_24781}));
      V v_x1_24891 = heff_tr(heff_call(v_m_24890, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_24891)) {
      case TAG_MkPair: {
        V v_x11_24892 = heff_field(v_x1_24891, 0);
        V v_st_24893 = heff_field(v_x1_24891, 1);
        V v_ru_24x1_24891_24MkPair = heff_take_reuse_n(v_x1_24891, 3ULL, 2);
        switch (heff_tag_of(v_x11_24892)) {
        case TAG_Left: {
          V v_e_24894 = heff_field(v_x11_24892, 0);
          heff_take_n(v_x11_24892, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_24780, 9);
          heff_drop(v_a_24783);
          heff_drop(v_b_24785);
          return heff_tag_at_n(v_ru_24x1_24891_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24894}), v_st_24893});
        }
        case TAG_Right: {
          V v_x_24895 = heff_field(v_x11_24892, 0);
          heff_take_n(v_x11_24892, 1ULL, 1);
          V v_m_24896 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_24783}));
          V v_x1_24897 = heff_tr(heff_call(v_m_24896, 1, (V[]){v_st_24893}));
          switch (heff_tag_of(v_x1_24897)) {
          case TAG_MkPair: {
            V v_x11_24898 = heff_field(v_x1_24897, 0);
            V v_st_24899 = heff_field(v_x1_24897, 1);
            heff_take_n(v_x1_24897, 3ULL, 2);
            switch (heff_tag_of(v_x11_24898)) {
            case TAG_Left: {
              V v_e_24900 = heff_field(v_x11_24898, 0);
              heff_take_n(v_x11_24898, 1ULL, 1);
              heff_drop_rec(v_r_240, 3);
              heff_drop_rec(v_kw_24780, 9);
              heff_drop(v_b_24785);
              heff_drop(v_x_24895);
              return heff_tag_at_n(v_ru_24x1_24891_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24900}), v_st_24899});
            }
            case TAG_Right: {
              V v_x_24901 = heff_field(v_x11_24898, 0);
              heff_take_n(v_x11_24898, 1ULL, 1);
              V v_m_24902 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_b_24785)}));
              V v_x1_24903 = heff_tr(heff_call(v_m_24902, 1, (V[]){v_st_24899}));
              switch (heff_tag_of(v_x1_24903)) {
              case TAG_MkPair: {
                V v_x11_24904 = heff_field(v_x1_24903, 0);
                V v_st_24905 = heff_field(v_x1_24903, 1);
                heff_take_n(v_x1_24903, 3ULL, 2);
                switch (heff_tag_of(v_x11_24904)) {
                case TAG_Left: {
                  V v_e_24906 = heff_field(v_x11_24904, 0);
                  heff_take_n(v_x11_24904, 1ULL, 1);
                  heff_drop_rec(v_kw_24780, 9);
                  heff_drop(v_b_24785);
                  heff_drop(v_x_24895);
                  heff_drop(v_x_24901);
                  return heff_tag_at_n(v_ru_24x1_24891_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24906}), v_st_24905});
                }
                case TAG_Right: {
                  V v_x_24907 = heff_field(v_x11_24904, 0);
                  heff_take_n(v_x11_24904, 1ULL, 1);
                  V v_t_24908 = (g_heff_2esyntax_2ecst_2elastE(v_b_24785));
                  V v_e_24909 = heff_get_n(v_t_24908, 4, 9);
                  V v_t_24910 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_24780, 3, 9), v_e_24909});
                  V v_x_24911 = (g_heff_2esyntax_2esurface_2eifE(v_t_24910, v_x_24895, v_x_24901, v_x_24907));
                  return heff_tag_at_n(v_ru_24x1_24891_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24911}), v_st_24905});
                }
                default: return heff_nomatch(v_x11_24904);
                }
              }
              default: return heff_nomatch(v_x1_24903);
              }
            }
            default: return heff_nomatch(v_x11_24898);
            }
          }
          default: return heff_nomatch(v_x1_24897);
          }
        }
        default: return heff_nomatch(v_x11_24892);
        }
      }
      default: return heff_nomatch(v_x1_24891);
      }
    }
    case TAG_Braces: {
      V v_m_24916 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_24781}));
      V v_x1_24917 = heff_tr(heff_call(v_m_24916, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_24917)) {
      case TAG_MkPair: {
        V v_x11_24918 = heff_field(v_x1_24917, 0);
        V v_st_24919 = heff_field(v_x1_24917, 1);
        V v_ru_24x1_24917_24MkPair = heff_take_reuse_n(v_x1_24917, 3ULL, 2);
        switch (heff_tag_of(v_x11_24918)) {
        case TAG_Left: {
          V v_e_24920 = heff_field(v_x11_24918, 0);
          heff_take_n(v_x11_24918, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_24780, 9);
          heff_drop(v_a_24783);
          heff_drop(v_b_24785);
          return heff_tag_at_n(v_ru_24x1_24917_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24920}), v_st_24919});
        }
        case TAG_Right: {
          V v_x_24921 = heff_field(v_x11_24918, 0);
          heff_take_n(v_x11_24918, 1ULL, 1);
          V v_m_24922 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_24783}));
          V v_x1_24923 = heff_tr(heff_call(v_m_24922, 1, (V[]){v_st_24919}));
          switch (heff_tag_of(v_x1_24923)) {
          case TAG_MkPair: {
            V v_x11_24924 = heff_field(v_x1_24923, 0);
            V v_st_24925 = heff_field(v_x1_24923, 1);
            heff_take_n(v_x1_24923, 3ULL, 2);
            switch (heff_tag_of(v_x11_24924)) {
            case TAG_Left: {
              V v_e_24926 = heff_field(v_x11_24924, 0);
              heff_take_n(v_x11_24924, 1ULL, 1);
              heff_drop_rec(v_r_240, 3);
              heff_drop_rec(v_kw_24780, 9);
              heff_drop(v_b_24785);
              heff_drop(v_x_24921);
              return heff_tag_at_n(v_ru_24x1_24917_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24926}), v_st_24925});
            }
            case TAG_Right: {
              V v_x_24927 = heff_field(v_x11_24924, 0);
              heff_take_n(v_x11_24924, 1ULL, 1);
              V v_m_24928 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_b_24785)}));
              V v_x1_24929 = heff_tr(heff_call(v_m_24928, 1, (V[]){v_st_24925}));
              switch (heff_tag_of(v_x1_24929)) {
              case TAG_MkPair: {
                V v_x11_24930 = heff_field(v_x1_24929, 0);
                V v_st_24931 = heff_field(v_x1_24929, 1);
                heff_take_n(v_x1_24929, 3ULL, 2);
                switch (heff_tag_of(v_x11_24930)) {
                case TAG_Left: {
                  V v_e_24932 = heff_field(v_x11_24930, 0);
                  heff_take_n(v_x11_24930, 1ULL, 1);
                  heff_drop_rec(v_kw_24780, 9);
                  heff_drop(v_b_24785);
                  heff_drop(v_x_24921);
                  heff_drop(v_x_24927);
                  return heff_tag_at_n(v_ru_24x1_24917_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24932}), v_st_24931});
                }
                case TAG_Right: {
                  V v_x_24933 = heff_field(v_x11_24930, 0);
                  heff_take_n(v_x11_24930, 1ULL, 1);
                  V v_t_24934 = (g_heff_2esyntax_2ecst_2elastE(v_b_24785));
                  V v_e_24935 = heff_get_n(v_t_24934, 4, 9);
                  V v_t_24936 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_24780, 3, 9), v_e_24935});
                  V v_x_24937 = (g_heff_2esyntax_2esurface_2eifE(v_t_24936, v_x_24921, v_x_24927, v_x_24933));
                  return heff_tag_at_n(v_ru_24x1_24917_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24937}), v_st_24931});
                }
                default: return heff_nomatch(v_x11_24930);
                }
              }
              default: return heff_nomatch(v_x1_24929);
              }
            }
            default: return heff_nomatch(v_x11_24924);
            }
          }
          default: return heff_nomatch(v_x1_24923);
          }
        }
        default: return heff_nomatch(v_x11_24918);
        }
      }
      default: return heff_nomatch(v_x1_24917);
      }
    }
    case TAG_Update: {
      V v_m_24944 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_24781}));
      V v_x1_24945 = heff_tr(heff_call(v_m_24944, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_24945)) {
      case TAG_MkPair: {
        V v_x11_24946 = heff_field(v_x1_24945, 0);
        V v_st_24947 = heff_field(v_x1_24945, 1);
        V v_ru_24x1_24945_24MkPair = heff_take_reuse_n(v_x1_24945, 3ULL, 2);
        switch (heff_tag_of(v_x11_24946)) {
        case TAG_Left: {
          V v_e_24948 = heff_field(v_x11_24946, 0);
          heff_take_n(v_x11_24946, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_24780, 9);
          heff_drop(v_a_24783);
          heff_drop(v_b_24785);
          return heff_tag_at_n(v_ru_24x1_24945_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24948}), v_st_24947});
        }
        case TAG_Right: {
          V v_x_24949 = heff_field(v_x11_24946, 0);
          heff_take_n(v_x11_24946, 1ULL, 1);
          V v_m_24950 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_24783}));
          V v_x1_24951 = heff_tr(heff_call(v_m_24950, 1, (V[]){v_st_24947}));
          switch (heff_tag_of(v_x1_24951)) {
          case TAG_MkPair: {
            V v_x11_24952 = heff_field(v_x1_24951, 0);
            V v_st_24953 = heff_field(v_x1_24951, 1);
            heff_take_n(v_x1_24951, 3ULL, 2);
            switch (heff_tag_of(v_x11_24952)) {
            case TAG_Left: {
              V v_e_24954 = heff_field(v_x11_24952, 0);
              heff_take_n(v_x11_24952, 1ULL, 1);
              heff_drop_rec(v_r_240, 3);
              heff_drop_rec(v_kw_24780, 9);
              heff_drop(v_b_24785);
              heff_drop(v_x_24949);
              return heff_tag_at_n(v_ru_24x1_24945_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24954}), v_st_24953});
            }
            case TAG_Right: {
              V v_x_24955 = heff_field(v_x11_24952, 0);
              heff_take_n(v_x11_24952, 1ULL, 1);
              V v_m_24956 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_b_24785)}));
              V v_x1_24957 = heff_tr(heff_call(v_m_24956, 1, (V[]){v_st_24953}));
              switch (heff_tag_of(v_x1_24957)) {
              case TAG_MkPair: {
                V v_x11_24958 = heff_field(v_x1_24957, 0);
                V v_st_24959 = heff_field(v_x1_24957, 1);
                heff_take_n(v_x1_24957, 3ULL, 2);
                switch (heff_tag_of(v_x11_24958)) {
                case TAG_Left: {
                  V v_e_24960 = heff_field(v_x11_24958, 0);
                  heff_take_n(v_x11_24958, 1ULL, 1);
                  heff_drop_rec(v_kw_24780, 9);
                  heff_drop(v_b_24785);
                  heff_drop(v_x_24949);
                  heff_drop(v_x_24955);
                  return heff_tag_at_n(v_ru_24x1_24945_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24960}), v_st_24959});
                }
                case TAG_Right: {
                  V v_x_24961 = heff_field(v_x11_24958, 0);
                  heff_take_n(v_x11_24958, 1ULL, 1);
                  V v_t_24962 = (g_heff_2esyntax_2ecst_2elastE(v_b_24785));
                  V v_e_24963 = heff_get_n(v_t_24962, 4, 9);
                  V v_t_24964 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_24780, 3, 9), v_e_24963});
                  V v_x_24965 = (g_heff_2esyntax_2esurface_2eifE(v_t_24964, v_x_24949, v_x_24955, v_x_24961));
                  return heff_tag_at_n(v_ru_24x1_24945_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24965}), v_st_24959});
                }
                default: return heff_nomatch(v_x11_24958);
                }
              }
              default: return heff_nomatch(v_x1_24957);
              }
            }
            default: return heff_nomatch(v_x11_24952);
            }
          }
          default: return heff_nomatch(v_x1_24951);
          }
        }
        default: return heff_nomatch(v_x11_24946);
        }
      }
      default: return heff_nomatch(v_x1_24945);
      }
    }
    case TAG_EUSet: {
      V v_m_24969 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_24781}));
      V v_x1_24970 = heff_tr(heff_call(v_m_24969, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_24970)) {
      case TAG_MkPair: {
        V v_x11_24971 = heff_field(v_x1_24970, 0);
        V v_st_24972 = heff_field(v_x1_24970, 1);
        V v_ru_24x1_24970_24MkPair = heff_take_reuse_n(v_x1_24970, 3ULL, 2);
        switch (heff_tag_of(v_x11_24971)) {
        case TAG_Left: {
          V v_e_24973 = heff_field(v_x11_24971, 0);
          heff_take_n(v_x11_24971, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_24780, 9);
          heff_drop(v_a_24783);
          heff_drop(v_b_24785);
          return heff_tag_at_n(v_ru_24x1_24970_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24973}), v_st_24972});
        }
        case TAG_Right: {
          V v_x_24974 = heff_field(v_x11_24971, 0);
          heff_take_n(v_x11_24971, 1ULL, 1);
          V v_m_24975 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_24783}));
          V v_x1_24976 = heff_tr(heff_call(v_m_24975, 1, (V[]){v_st_24972}));
          switch (heff_tag_of(v_x1_24976)) {
          case TAG_MkPair: {
            V v_x11_24977 = heff_field(v_x1_24976, 0);
            V v_st_24978 = heff_field(v_x1_24976, 1);
            heff_take_n(v_x1_24976, 3ULL, 2);
            switch (heff_tag_of(v_x11_24977)) {
            case TAG_Left: {
              V v_e_24979 = heff_field(v_x11_24977, 0);
              heff_take_n(v_x11_24977, 1ULL, 1);
              heff_drop_rec(v_r_240, 3);
              heff_drop_rec(v_kw_24780, 9);
              heff_drop(v_b_24785);
              heff_drop(v_x_24974);
              return heff_tag_at_n(v_ru_24x1_24970_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24979}), v_st_24978});
            }
            case TAG_Right: {
              V v_x_24980 = heff_field(v_x11_24977, 0);
              heff_take_n(v_x11_24977, 1ULL, 1);
              V v_m_24981 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_b_24785)}));
              V v_x1_24982 = heff_tr(heff_call(v_m_24981, 1, (V[]){v_st_24978}));
              switch (heff_tag_of(v_x1_24982)) {
              case TAG_MkPair: {
                V v_x11_24983 = heff_field(v_x1_24982, 0);
                V v_st_24984 = heff_field(v_x1_24982, 1);
                heff_take_n(v_x1_24982, 3ULL, 2);
                switch (heff_tag_of(v_x11_24983)) {
                case TAG_Left: {
                  V v_e_24985 = heff_field(v_x11_24983, 0);
                  heff_take_n(v_x11_24983, 1ULL, 1);
                  heff_drop_rec(v_kw_24780, 9);
                  heff_drop(v_b_24785);
                  heff_drop(v_x_24974);
                  heff_drop(v_x_24980);
                  return heff_tag_at_n(v_ru_24x1_24970_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24985}), v_st_24984});
                }
                case TAG_Right: {
                  V v_x_24986 = heff_field(v_x11_24983, 0);
                  heff_take_n(v_x11_24983, 1ULL, 1);
                  V v_t_24987 = (g_heff_2esyntax_2ecst_2elastE(v_b_24785));
                  V v_e_24988 = heff_get_n(v_t_24987, 4, 9);
                  V v_t_24989 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_24780, 3, 9), v_e_24988});
                  V v_x_24990 = (g_heff_2esyntax_2esurface_2eifE(v_t_24989, v_x_24974, v_x_24980, v_x_24986));
                  return heff_tag_at_n(v_ru_24x1_24970_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24990}), v_st_24984});
                }
                default: return heff_nomatch(v_x11_24983);
                }
              }
              default: return heff_nomatch(v_x1_24982);
              }
            }
            default: return heff_nomatch(v_x11_24977);
            }
          }
          default: return heff_nomatch(v_x1_24976);
          }
        }
        default: return heff_nomatch(v_x11_24971);
        }
      }
      default: return heff_nomatch(v_x1_24970);
      }
    }
    case TAG_InstB: {
      V v_m_24996 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_24781}));
      V v_x1_24997 = heff_tr(heff_call(v_m_24996, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_24997)) {
      case TAG_MkPair: {
        V v_x11_24998 = heff_field(v_x1_24997, 0);
        V v_st_24999 = heff_field(v_x1_24997, 1);
        V v_ru_24x1_24997_24MkPair = heff_take_reuse_n(v_x1_24997, 3ULL, 2);
        switch (heff_tag_of(v_x11_24998)) {
        case TAG_Left: {
          V v_e_241000 = heff_field(v_x11_24998, 0);
          heff_take_n(v_x11_24998, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_24780, 9);
          heff_drop(v_a_24783);
          heff_drop(v_b_24785);
          return heff_tag_at_n(v_ru_24x1_24997_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241000}), v_st_24999});
        }
        case TAG_Right: {
          V v_x_241001 = heff_field(v_x11_24998, 0);
          heff_take_n(v_x11_24998, 1ULL, 1);
          V v_m_241002 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_24783}));
          V v_x1_241003 = heff_tr(heff_call(v_m_241002, 1, (V[]){v_st_24999}));
          switch (heff_tag_of(v_x1_241003)) {
          case TAG_MkPair: {
            V v_x11_241004 = heff_field(v_x1_241003, 0);
            V v_st_241005 = heff_field(v_x1_241003, 1);
            heff_take_n(v_x1_241003, 3ULL, 2);
            switch (heff_tag_of(v_x11_241004)) {
            case TAG_Left: {
              V v_e_241006 = heff_field(v_x11_241004, 0);
              heff_take_n(v_x11_241004, 1ULL, 1);
              heff_drop_rec(v_r_240, 3);
              heff_drop_rec(v_kw_24780, 9);
              heff_drop(v_b_24785);
              heff_drop(v_x_241001);
              return heff_tag_at_n(v_ru_24x1_24997_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241006}), v_st_241005});
            }
            case TAG_Right: {
              V v_x_241007 = heff_field(v_x11_241004, 0);
              heff_take_n(v_x11_241004, 1ULL, 1);
              V v_m_241008 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_b_24785)}));
              V v_x1_241009 = heff_tr(heff_call(v_m_241008, 1, (V[]){v_st_241005}));
              switch (heff_tag_of(v_x1_241009)) {
              case TAG_MkPair: {
                V v_x11_241010 = heff_field(v_x1_241009, 0);
                V v_st_241011 = heff_field(v_x1_241009, 1);
                heff_take_n(v_x1_241009, 3ULL, 2);
                switch (heff_tag_of(v_x11_241010)) {
                case TAG_Left: {
                  V v_e_241012 = heff_field(v_x11_241010, 0);
                  heff_take_n(v_x11_241010, 1ULL, 1);
                  heff_drop_rec(v_kw_24780, 9);
                  heff_drop(v_b_24785);
                  heff_drop(v_x_241001);
                  heff_drop(v_x_241007);
                  return heff_tag_at_n(v_ru_24x1_24997_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241012}), v_st_241011});
                }
                case TAG_Right: {
                  V v_x_241013 = heff_field(v_x11_241010, 0);
                  heff_take_n(v_x11_241010, 1ULL, 1);
                  V v_t_241014 = (g_heff_2esyntax_2ecst_2elastE(v_b_24785));
                  V v_e_241015 = heff_get_n(v_t_241014, 4, 9);
                  V v_t_241016 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_24780, 3, 9), v_e_241015});
                  V v_x_241017 = (g_heff_2esyntax_2esurface_2eifE(v_t_241016, v_x_241001, v_x_241007, v_x_241013));
                  return heff_tag_at_n(v_ru_24x1_24997_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_241017}), v_st_241011});
                }
                default: return heff_nomatch(v_x11_241010);
                }
              }
              default: return heff_nomatch(v_x1_241009);
              }
            }
            default: return heff_nomatch(v_x11_241004);
            }
          }
          default: return heff_nomatch(v_x1_241003);
          }
        }
        default: return heff_nomatch(v_x11_24998);
        }
      }
      default: return heff_nomatch(v_x1_24997);
      }
    }
    case TAG_EFSet: {
      V v_m_241021 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_24781}));
      V v_x1_241022 = heff_tr(heff_call(v_m_241021, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_241022)) {
      case TAG_MkPair: {
        V v_x11_241023 = heff_field(v_x1_241022, 0);
        V v_st_241024 = heff_field(v_x1_241022, 1);
        V v_ru_24x1_241022_24MkPair = heff_take_reuse_n(v_x1_241022, 3ULL, 2);
        switch (heff_tag_of(v_x11_241023)) {
        case TAG_Left: {
          V v_e_241025 = heff_field(v_x11_241023, 0);
          heff_take_n(v_x11_241023, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_24780, 9);
          heff_drop(v_a_24783);
          heff_drop(v_b_24785);
          return heff_tag_at_n(v_ru_24x1_241022_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241025}), v_st_241024});
        }
        case TAG_Right: {
          V v_x_241026 = heff_field(v_x11_241023, 0);
          heff_take_n(v_x11_241023, 1ULL, 1);
          V v_m_241027 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_24783}));
          V v_x1_241028 = heff_tr(heff_call(v_m_241027, 1, (V[]){v_st_241024}));
          switch (heff_tag_of(v_x1_241028)) {
          case TAG_MkPair: {
            V v_x11_241029 = heff_field(v_x1_241028, 0);
            V v_st_241030 = heff_field(v_x1_241028, 1);
            heff_take_n(v_x1_241028, 3ULL, 2);
            switch (heff_tag_of(v_x11_241029)) {
            case TAG_Left: {
              V v_e_241031 = heff_field(v_x11_241029, 0);
              heff_take_n(v_x11_241029, 1ULL, 1);
              heff_drop_rec(v_r_240, 3);
              heff_drop_rec(v_kw_24780, 9);
              heff_drop(v_b_24785);
              heff_drop(v_x_241026);
              return heff_tag_at_n(v_ru_24x1_241022_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241031}), v_st_241030});
            }
            case TAG_Right: {
              V v_x_241032 = heff_field(v_x11_241029, 0);
              heff_take_n(v_x11_241029, 1ULL, 1);
              V v_m_241033 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_b_24785)}));
              V v_x1_241034 = heff_tr(heff_call(v_m_241033, 1, (V[]){v_st_241030}));
              switch (heff_tag_of(v_x1_241034)) {
              case TAG_MkPair: {
                V v_x11_241035 = heff_field(v_x1_241034, 0);
                V v_st_241036 = heff_field(v_x1_241034, 1);
                heff_take_n(v_x1_241034, 3ULL, 2);
                switch (heff_tag_of(v_x11_241035)) {
                case TAG_Left: {
                  V v_e_241037 = heff_field(v_x11_241035, 0);
                  heff_take_n(v_x11_241035, 1ULL, 1);
                  heff_drop_rec(v_kw_24780, 9);
                  heff_drop(v_b_24785);
                  heff_drop(v_x_241026);
                  heff_drop(v_x_241032);
                  return heff_tag_at_n(v_ru_24x1_241022_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241037}), v_st_241036});
                }
                case TAG_Right: {
                  V v_x_241038 = heff_field(v_x11_241035, 0);
                  heff_take_n(v_x11_241035, 1ULL, 1);
                  V v_t_241039 = (g_heff_2esyntax_2ecst_2elastE(v_b_24785));
                  V v_e_241040 = heff_get_n(v_t_241039, 4, 9);
                  V v_t_241041 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_24780, 3, 9), v_e_241040});
                  V v_x_241042 = (g_heff_2esyntax_2esurface_2eifE(v_t_241041, v_x_241026, v_x_241032, v_x_241038));
                  return heff_tag_at_n(v_ru_24x1_241022_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_241042}), v_st_241036});
                }
                default: return heff_nomatch(v_x11_241035);
                }
              }
              default: return heff_nomatch(v_x1_241034);
              }
            }
            default: return heff_nomatch(v_x11_241029);
            }
          }
          default: return heff_nomatch(v_x1_241028);
          }
        }
        default: return heff_nomatch(v_x11_241023);
        }
      }
      default: return heff_nomatch(v_x1_241022);
      }
    }
    case TAG_EFDefault: {
      V v_m_241046 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_24781}));
      V v_x1_241047 = heff_tr(heff_call(v_m_241046, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_241047)) {
      case TAG_MkPair: {
        V v_x11_241048 = heff_field(v_x1_241047, 0);
        V v_st_241049 = heff_field(v_x1_241047, 1);
        V v_ru_24x1_241047_24MkPair = heff_take_reuse_n(v_x1_241047, 3ULL, 2);
        switch (heff_tag_of(v_x11_241048)) {
        case TAG_Left: {
          V v_e_241050 = heff_field(v_x11_241048, 0);
          heff_take_n(v_x11_241048, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_24780, 9);
          heff_drop(v_a_24783);
          heff_drop(v_b_24785);
          return heff_tag_at_n(v_ru_24x1_241047_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241050}), v_st_241049});
        }
        case TAG_Right: {
          V v_x_241051 = heff_field(v_x11_241048, 0);
          heff_take_n(v_x11_241048, 1ULL, 1);
          V v_m_241052 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_24783}));
          V v_x1_241053 = heff_tr(heff_call(v_m_241052, 1, (V[]){v_st_241049}));
          switch (heff_tag_of(v_x1_241053)) {
          case TAG_MkPair: {
            V v_x11_241054 = heff_field(v_x1_241053, 0);
            V v_st_241055 = heff_field(v_x1_241053, 1);
            heff_take_n(v_x1_241053, 3ULL, 2);
            switch (heff_tag_of(v_x11_241054)) {
            case TAG_Left: {
              V v_e_241056 = heff_field(v_x11_241054, 0);
              heff_take_n(v_x11_241054, 1ULL, 1);
              heff_drop_rec(v_r_240, 3);
              heff_drop_rec(v_kw_24780, 9);
              heff_drop(v_b_24785);
              heff_drop(v_x_241051);
              return heff_tag_at_n(v_ru_24x1_241047_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241056}), v_st_241055});
            }
            case TAG_Right: {
              V v_x_241057 = heff_field(v_x11_241054, 0);
              heff_take_n(v_x11_241054, 1ULL, 1);
              V v_m_241058 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_b_24785)}));
              V v_x1_241059 = heff_tr(heff_call(v_m_241058, 1, (V[]){v_st_241055}));
              switch (heff_tag_of(v_x1_241059)) {
              case TAG_MkPair: {
                V v_x11_241060 = heff_field(v_x1_241059, 0);
                V v_st_241061 = heff_field(v_x1_241059, 1);
                heff_take_n(v_x1_241059, 3ULL, 2);
                switch (heff_tag_of(v_x11_241060)) {
                case TAG_Left: {
                  V v_e_241062 = heff_field(v_x11_241060, 0);
                  heff_take_n(v_x11_241060, 1ULL, 1);
                  heff_drop_rec(v_kw_24780, 9);
                  heff_drop(v_b_24785);
                  heff_drop(v_x_241051);
                  heff_drop(v_x_241057);
                  return heff_tag_at_n(v_ru_24x1_241047_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241062}), v_st_241061});
                }
                case TAG_Right: {
                  V v_x_241063 = heff_field(v_x11_241060, 0);
                  heff_take_n(v_x11_241060, 1ULL, 1);
                  V v_t_241064 = (g_heff_2esyntax_2ecst_2elastE(v_b_24785));
                  V v_e_241065 = heff_get_n(v_t_241064, 4, 9);
                  V v_t_241066 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_24780, 3, 9), v_e_241065});
                  V v_x_241067 = (g_heff_2esyntax_2esurface_2eifE(v_t_241066, v_x_241051, v_x_241057, v_x_241063));
                  return heff_tag_at_n(v_ru_24x1_241047_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_241067}), v_st_241061});
                }
                default: return heff_nomatch(v_x11_241060);
                }
              }
              default: return heff_nomatch(v_x1_241059);
              }
            }
            default: return heff_nomatch(v_x11_241054);
            }
          }
          default: return heff_nomatch(v_x1_241053);
          }
        }
        default: return heff_nomatch(v_x11_241048);
        }
      }
      default: return heff_nomatch(v_x1_241047);
      }
    }
    case TAG_Sum: {
      V v_m_241073 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_24781}));
      V v_x1_241074 = heff_tr(heff_call(v_m_241073, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_241074)) {
      case TAG_MkPair: {
        V v_x11_241075 = heff_field(v_x1_241074, 0);
        V v_st_241076 = heff_field(v_x1_241074, 1);
        V v_ru_24x1_241074_24MkPair = heff_take_reuse_n(v_x1_241074, 3ULL, 2);
        switch (heff_tag_of(v_x11_241075)) {
        case TAG_Left: {
          V v_e_241077 = heff_field(v_x11_241075, 0);
          heff_take_n(v_x11_241075, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_24780, 9);
          heff_drop(v_a_24783);
          heff_drop(v_b_24785);
          return heff_tag_at_n(v_ru_24x1_241074_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241077}), v_st_241076});
        }
        case TAG_Right: {
          V v_x_241078 = heff_field(v_x11_241075, 0);
          heff_take_n(v_x11_241075, 1ULL, 1);
          V v_m_241079 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_24783}));
          V v_x1_241080 = heff_tr(heff_call(v_m_241079, 1, (V[]){v_st_241076}));
          switch (heff_tag_of(v_x1_241080)) {
          case TAG_MkPair: {
            V v_x11_241081 = heff_field(v_x1_241080, 0);
            V v_st_241082 = heff_field(v_x1_241080, 1);
            heff_take_n(v_x1_241080, 3ULL, 2);
            switch (heff_tag_of(v_x11_241081)) {
            case TAG_Left: {
              V v_e_241083 = heff_field(v_x11_241081, 0);
              heff_take_n(v_x11_241081, 1ULL, 1);
              heff_drop_rec(v_r_240, 3);
              heff_drop_rec(v_kw_24780, 9);
              heff_drop(v_b_24785);
              heff_drop(v_x_241078);
              return heff_tag_at_n(v_ru_24x1_241074_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241083}), v_st_241082});
            }
            case TAG_Right: {
              V v_x_241084 = heff_field(v_x11_241081, 0);
              heff_take_n(v_x11_241081, 1ULL, 1);
              V v_m_241085 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_b_24785)}));
              V v_x1_241086 = heff_tr(heff_call(v_m_241085, 1, (V[]){v_st_241082}));
              switch (heff_tag_of(v_x1_241086)) {
              case TAG_MkPair: {
                V v_x11_241087 = heff_field(v_x1_241086, 0);
                V v_st_241088 = heff_field(v_x1_241086, 1);
                heff_take_n(v_x1_241086, 3ULL, 2);
                switch (heff_tag_of(v_x11_241087)) {
                case TAG_Left: {
                  V v_e_241089 = heff_field(v_x11_241087, 0);
                  heff_take_n(v_x11_241087, 1ULL, 1);
                  heff_drop_rec(v_kw_24780, 9);
                  heff_drop(v_b_24785);
                  heff_drop(v_x_241078);
                  heff_drop(v_x_241084);
                  return heff_tag_at_n(v_ru_24x1_241074_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241089}), v_st_241088});
                }
                case TAG_Right: {
                  V v_x_241090 = heff_field(v_x11_241087, 0);
                  heff_take_n(v_x11_241087, 1ULL, 1);
                  V v_t_241091 = (g_heff_2esyntax_2ecst_2elastE(v_b_24785));
                  V v_e_241092 = heff_get_n(v_t_241091, 4, 9);
                  V v_t_241093 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_24780, 3, 9), v_e_241092});
                  V v_x_241094 = (g_heff_2esyntax_2esurface_2eifE(v_t_241093, v_x_241078, v_x_241084, v_x_241090));
                  return heff_tag_at_n(v_ru_24x1_241074_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_241094}), v_st_241088});
                }
                default: return heff_nomatch(v_x11_241087);
                }
              }
              default: return heff_nomatch(v_x1_241086);
              }
            }
            default: return heff_nomatch(v_x11_241081);
            }
          }
          default: return heff_nomatch(v_x1_241080);
          }
        }
        default: return heff_nomatch(v_x11_241075);
        }
      }
      default: return heff_nomatch(v_x1_241074);
      }
    }
    case TAG_ECon: {
      V v_m_241097 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_24781}));
      V v_x1_241098 = heff_tr(heff_call(v_m_241097, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_241098)) {
      case TAG_MkPair: {
        V v_x11_241099 = heff_field(v_x1_241098, 0);
        V v_st_241100 = heff_field(v_x1_241098, 1);
        V v_ru_24x1_241098_24MkPair = heff_take_reuse_n(v_x1_241098, 3ULL, 2);
        switch (heff_tag_of(v_x11_241099)) {
        case TAG_Left: {
          V v_e_241101 = heff_field(v_x11_241099, 0);
          heff_take_n(v_x11_241099, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_24780, 9);
          heff_drop(v_a_24783);
          heff_drop(v_b_24785);
          return heff_tag_at_n(v_ru_24x1_241098_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241101}), v_st_241100});
        }
        case TAG_Right: {
          V v_x_241102 = heff_field(v_x11_241099, 0);
          heff_take_n(v_x11_241099, 1ULL, 1);
          V v_m_241103 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_24783}));
          V v_x1_241104 = heff_tr(heff_call(v_m_241103, 1, (V[]){v_st_241100}));
          switch (heff_tag_of(v_x1_241104)) {
          case TAG_MkPair: {
            V v_x11_241105 = heff_field(v_x1_241104, 0);
            V v_st_241106 = heff_field(v_x1_241104, 1);
            heff_take_n(v_x1_241104, 3ULL, 2);
            switch (heff_tag_of(v_x11_241105)) {
            case TAG_Left: {
              V v_e_241107 = heff_field(v_x11_241105, 0);
              heff_take_n(v_x11_241105, 1ULL, 1);
              heff_drop_rec(v_r_240, 3);
              heff_drop_rec(v_kw_24780, 9);
              heff_drop(v_b_24785);
              heff_drop(v_x_241102);
              return heff_tag_at_n(v_ru_24x1_241098_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241107}), v_st_241106});
            }
            case TAG_Right: {
              V v_x_241108 = heff_field(v_x11_241105, 0);
              heff_take_n(v_x11_241105, 1ULL, 1);
              V v_m_241109 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_b_24785)}));
              V v_x1_241110 = heff_tr(heff_call(v_m_241109, 1, (V[]){v_st_241106}));
              switch (heff_tag_of(v_x1_241110)) {
              case TAG_MkPair: {
                V v_x11_241111 = heff_field(v_x1_241110, 0);
                V v_st_241112 = heff_field(v_x1_241110, 1);
                heff_take_n(v_x1_241110, 3ULL, 2);
                switch (heff_tag_of(v_x11_241111)) {
                case TAG_Left: {
                  V v_e_241113 = heff_field(v_x11_241111, 0);
                  heff_take_n(v_x11_241111, 1ULL, 1);
                  heff_drop_rec(v_kw_24780, 9);
                  heff_drop(v_b_24785);
                  heff_drop(v_x_241102);
                  heff_drop(v_x_241108);
                  return heff_tag_at_n(v_ru_24x1_241098_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241113}), v_st_241112});
                }
                case TAG_Right: {
                  V v_x_241114 = heff_field(v_x11_241111, 0);
                  heff_take_n(v_x11_241111, 1ULL, 1);
                  V v_t_241115 = (g_heff_2esyntax_2ecst_2elastE(v_b_24785));
                  V v_e_241116 = heff_get_n(v_t_241115, 4, 9);
                  V v_t_241117 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_24780, 3, 9), v_e_241116});
                  V v_x_241118 = (g_heff_2esyntax_2esurface_2eifE(v_t_241117, v_x_241102, v_x_241108, v_x_241114));
                  return heff_tag_at_n(v_ru_24x1_241098_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_241118}), v_st_241112});
                }
                default: return heff_nomatch(v_x11_241111);
                }
              }
              default: return heff_nomatch(v_x1_241110);
              }
            }
            default: return heff_nomatch(v_x11_241105);
            }
          }
          default: return heff_nomatch(v_x1_241104);
          }
        }
        default: return heff_nomatch(v_x11_241099);
        }
      }
      default: return heff_nomatch(v_x1_241098);
      }
    }
    case TAG_EField: {
      V v_m_241121 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_24781}));
      V v_x1_241122 = heff_tr(heff_call(v_m_241121, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_241122)) {
      case TAG_MkPair: {
        V v_x11_241123 = heff_field(v_x1_241122, 0);
        V v_st_241124 = heff_field(v_x1_241122, 1);
        V v_ru_24x1_241122_24MkPair = heff_take_reuse_n(v_x1_241122, 3ULL, 2);
        switch (heff_tag_of(v_x11_241123)) {
        case TAG_Left: {
          V v_e_241125 = heff_field(v_x11_241123, 0);
          heff_take_n(v_x11_241123, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_24780, 9);
          heff_drop(v_a_24783);
          heff_drop(v_b_24785);
          return heff_tag_at_n(v_ru_24x1_241122_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241125}), v_st_241124});
        }
        case TAG_Right: {
          V v_x_241126 = heff_field(v_x11_241123, 0);
          heff_take_n(v_x11_241123, 1ULL, 1);
          V v_m_241127 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_24783}));
          V v_x1_241128 = heff_tr(heff_call(v_m_241127, 1, (V[]){v_st_241124}));
          switch (heff_tag_of(v_x1_241128)) {
          case TAG_MkPair: {
            V v_x11_241129 = heff_field(v_x1_241128, 0);
            V v_st_241130 = heff_field(v_x1_241128, 1);
            heff_take_n(v_x1_241128, 3ULL, 2);
            switch (heff_tag_of(v_x11_241129)) {
            case TAG_Left: {
              V v_e_241131 = heff_field(v_x11_241129, 0);
              heff_take_n(v_x11_241129, 1ULL, 1);
              heff_drop_rec(v_r_240, 3);
              heff_drop_rec(v_kw_24780, 9);
              heff_drop(v_b_24785);
              heff_drop(v_x_241126);
              return heff_tag_at_n(v_ru_24x1_241122_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241131}), v_st_241130});
            }
            case TAG_Right: {
              V v_x_241132 = heff_field(v_x11_241129, 0);
              heff_take_n(v_x11_241129, 1ULL, 1);
              V v_m_241133 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_b_24785)}));
              V v_x1_241134 = heff_tr(heff_call(v_m_241133, 1, (V[]){v_st_241130}));
              switch (heff_tag_of(v_x1_241134)) {
              case TAG_MkPair: {
                V v_x11_241135 = heff_field(v_x1_241134, 0);
                V v_st_241136 = heff_field(v_x1_241134, 1);
                heff_take_n(v_x1_241134, 3ULL, 2);
                switch (heff_tag_of(v_x11_241135)) {
                case TAG_Left: {
                  V v_e_241137 = heff_field(v_x11_241135, 0);
                  heff_take_n(v_x11_241135, 1ULL, 1);
                  heff_drop_rec(v_kw_24780, 9);
                  heff_drop(v_b_24785);
                  heff_drop(v_x_241126);
                  heff_drop(v_x_241132);
                  return heff_tag_at_n(v_ru_24x1_241122_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241137}), v_st_241136});
                }
                case TAG_Right: {
                  V v_x_241138 = heff_field(v_x11_241135, 0);
                  heff_take_n(v_x11_241135, 1ULL, 1);
                  V v_t_241139 = (g_heff_2esyntax_2ecst_2elastE(v_b_24785));
                  V v_e_241140 = heff_get_n(v_t_241139, 4, 9);
                  V v_t_241141 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_24780, 3, 9), v_e_241140});
                  V v_x_241142 = (g_heff_2esyntax_2esurface_2eifE(v_t_241141, v_x_241126, v_x_241132, v_x_241138));
                  return heff_tag_at_n(v_ru_24x1_241122_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_241142}), v_st_241136});
                }
                default: return heff_nomatch(v_x11_241135);
                }
              }
              default: return heff_nomatch(v_x1_241134);
              }
            }
            default: return heff_nomatch(v_x11_241129);
            }
          }
          default: return heff_nomatch(v_x1_241128);
          }
        }
        default: return heff_nomatch(v_x11_241123);
        }
      }
      default: return heff_nomatch(v_x1_241122);
      }
    }
    case TAG_ENeg: {
      V v_m_241145 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_24781}));
      V v_x1_241146 = heff_tr(heff_call(v_m_241145, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_241146)) {
      case TAG_MkPair: {
        V v_x11_241147 = heff_field(v_x1_241146, 0);
        V v_st_241148 = heff_field(v_x1_241146, 1);
        V v_ru_24x1_241146_24MkPair = heff_take_reuse_n(v_x1_241146, 3ULL, 2);
        switch (heff_tag_of(v_x11_241147)) {
        case TAG_Left: {
          V v_e_241149 = heff_field(v_x11_241147, 0);
          heff_take_n(v_x11_241147, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_24780, 9);
          heff_drop(v_a_24783);
          heff_drop(v_b_24785);
          return heff_tag_at_n(v_ru_24x1_241146_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241149}), v_st_241148});
        }
        case TAG_Right: {
          V v_x_241150 = heff_field(v_x11_241147, 0);
          heff_take_n(v_x11_241147, 1ULL, 1);
          V v_m_241151 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_24783}));
          V v_x1_241152 = heff_tr(heff_call(v_m_241151, 1, (V[]){v_st_241148}));
          switch (heff_tag_of(v_x1_241152)) {
          case TAG_MkPair: {
            V v_x11_241153 = heff_field(v_x1_241152, 0);
            V v_st_241154 = heff_field(v_x1_241152, 1);
            heff_take_n(v_x1_241152, 3ULL, 2);
            switch (heff_tag_of(v_x11_241153)) {
            case TAG_Left: {
              V v_e_241155 = heff_field(v_x11_241153, 0);
              heff_take_n(v_x11_241153, 1ULL, 1);
              heff_drop_rec(v_r_240, 3);
              heff_drop_rec(v_kw_24780, 9);
              heff_drop(v_b_24785);
              heff_drop(v_x_241150);
              return heff_tag_at_n(v_ru_24x1_241146_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241155}), v_st_241154});
            }
            case TAG_Right: {
              V v_x_241156 = heff_field(v_x11_241153, 0);
              heff_take_n(v_x11_241153, 1ULL, 1);
              V v_m_241157 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_b_24785)}));
              V v_x1_241158 = heff_tr(heff_call(v_m_241157, 1, (V[]){v_st_241154}));
              switch (heff_tag_of(v_x1_241158)) {
              case TAG_MkPair: {
                V v_x11_241159 = heff_field(v_x1_241158, 0);
                V v_st_241160 = heff_field(v_x1_241158, 1);
                heff_take_n(v_x1_241158, 3ULL, 2);
                switch (heff_tag_of(v_x11_241159)) {
                case TAG_Left: {
                  V v_e_241161 = heff_field(v_x11_241159, 0);
                  heff_take_n(v_x11_241159, 1ULL, 1);
                  heff_drop_rec(v_kw_24780, 9);
                  heff_drop(v_b_24785);
                  heff_drop(v_x_241150);
                  heff_drop(v_x_241156);
                  return heff_tag_at_n(v_ru_24x1_241146_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241161}), v_st_241160});
                }
                case TAG_Right: {
                  V v_x_241162 = heff_field(v_x11_241159, 0);
                  heff_take_n(v_x11_241159, 1ULL, 1);
                  V v_t_241163 = (g_heff_2esyntax_2ecst_2elastE(v_b_24785));
                  V v_e_241164 = heff_get_n(v_t_241163, 4, 9);
                  V v_t_241165 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_24780, 3, 9), v_e_241164});
                  V v_x_241166 = (g_heff_2esyntax_2esurface_2eifE(v_t_241165, v_x_241150, v_x_241156, v_x_241162));
                  return heff_tag_at_n(v_ru_24x1_241146_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_241166}), v_st_241160});
                }
                default: return heff_nomatch(v_x11_241159);
                }
              }
              default: return heff_nomatch(v_x1_241158);
              }
            }
            default: return heff_nomatch(v_x11_241153);
            }
          }
          default: return heff_nomatch(v_x1_241152);
          }
        }
        default: return heff_nomatch(v_x11_241147);
        }
      }
      default: return heff_nomatch(v_x1_241146);
      }
    }
    case TAG_App: {
      V v_m_241169 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_24781}));
      V v_x1_241170 = heff_tr(heff_call(v_m_241169, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_241170)) {
      case TAG_MkPair: {
        V v_x11_241171 = heff_field(v_x1_241170, 0);
        V v_st_241172 = heff_field(v_x1_241170, 1);
        V v_ru_24x1_241170_24MkPair = heff_take_reuse_n(v_x1_241170, 3ULL, 2);
        switch (heff_tag_of(v_x11_241171)) {
        case TAG_Left: {
          V v_e_241173 = heff_field(v_x11_241171, 0);
          heff_take_n(v_x11_241171, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_24780, 9);
          heff_drop(v_a_24783);
          heff_drop(v_b_24785);
          return heff_tag_at_n(v_ru_24x1_241170_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241173}), v_st_241172});
        }
        case TAG_Right: {
          V v_x_241174 = heff_field(v_x11_241171, 0);
          heff_take_n(v_x11_241171, 1ULL, 1);
          V v_m_241175 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_24783}));
          V v_x1_241176 = heff_tr(heff_call(v_m_241175, 1, (V[]){v_st_241172}));
          switch (heff_tag_of(v_x1_241176)) {
          case TAG_MkPair: {
            V v_x11_241177 = heff_field(v_x1_241176, 0);
            V v_st_241178 = heff_field(v_x1_241176, 1);
            heff_take_n(v_x1_241176, 3ULL, 2);
            switch (heff_tag_of(v_x11_241177)) {
            case TAG_Left: {
              V v_e_241179 = heff_field(v_x11_241177, 0);
              heff_take_n(v_x11_241177, 1ULL, 1);
              heff_drop_rec(v_r_240, 3);
              heff_drop_rec(v_kw_24780, 9);
              heff_drop(v_b_24785);
              heff_drop(v_x_241174);
              return heff_tag_at_n(v_ru_24x1_241170_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241179}), v_st_241178});
            }
            case TAG_Right: {
              V v_x_241180 = heff_field(v_x11_241177, 0);
              heff_take_n(v_x11_241177, 1ULL, 1);
              V v_m_241181 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_b_24785)}));
              V v_x1_241182 = heff_tr(heff_call(v_m_241181, 1, (V[]){v_st_241178}));
              switch (heff_tag_of(v_x1_241182)) {
              case TAG_MkPair: {
                V v_x11_241183 = heff_field(v_x1_241182, 0);
                V v_st_241184 = heff_field(v_x1_241182, 1);
                heff_take_n(v_x1_241182, 3ULL, 2);
                switch (heff_tag_of(v_x11_241183)) {
                case TAG_Left: {
                  V v_e_241185 = heff_field(v_x11_241183, 0);
                  heff_take_n(v_x11_241183, 1ULL, 1);
                  heff_drop_rec(v_kw_24780, 9);
                  heff_drop(v_b_24785);
                  heff_drop(v_x_241174);
                  heff_drop(v_x_241180);
                  return heff_tag_at_n(v_ru_24x1_241170_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241185}), v_st_241184});
                }
                case TAG_Right: {
                  V v_x_241186 = heff_field(v_x11_241183, 0);
                  heff_take_n(v_x11_241183, 1ULL, 1);
                  V v_t_241187 = (g_heff_2esyntax_2ecst_2elastE(v_b_24785));
                  V v_e_241188 = heff_get_n(v_t_241187, 4, 9);
                  V v_t_241189 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_24780, 3, 9), v_e_241188});
                  V v_x_241190 = (g_heff_2esyntax_2esurface_2eifE(v_t_241189, v_x_241174, v_x_241180, v_x_241186));
                  return heff_tag_at_n(v_ru_24x1_241170_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_241190}), v_st_241184});
                }
                default: return heff_nomatch(v_x11_241183);
                }
              }
              default: return heff_nomatch(v_x1_241182);
              }
            }
            default: return heff_nomatch(v_x11_241177);
            }
          }
          default: return heff_nomatch(v_x1_241176);
          }
        }
        default: return heff_nomatch(v_x11_241171);
        }
      }
      default: return heff_nomatch(v_x1_241170);
      }
    }
    case TAG_Op: {
      V v_m_241194 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_24781}));
      V v_x1_241195 = heff_tr(heff_call(v_m_241194, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_241195)) {
      case TAG_MkPair: {
        V v_x11_241196 = heff_field(v_x1_241195, 0);
        V v_st_241197 = heff_field(v_x1_241195, 1);
        V v_ru_24x1_241195_24MkPair = heff_take_reuse_n(v_x1_241195, 3ULL, 2);
        switch (heff_tag_of(v_x11_241196)) {
        case TAG_Left: {
          V v_e_241198 = heff_field(v_x11_241196, 0);
          heff_take_n(v_x11_241196, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_24780, 9);
          heff_drop(v_a_24783);
          heff_drop(v_b_24785);
          return heff_tag_at_n(v_ru_24x1_241195_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241198}), v_st_241197});
        }
        case TAG_Right: {
          V v_x_241199 = heff_field(v_x11_241196, 0);
          heff_take_n(v_x11_241196, 1ULL, 1);
          V v_m_241200 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_24783}));
          V v_x1_241201 = heff_tr(heff_call(v_m_241200, 1, (V[]){v_st_241197}));
          switch (heff_tag_of(v_x1_241201)) {
          case TAG_MkPair: {
            V v_x11_241202 = heff_field(v_x1_241201, 0);
            V v_st_241203 = heff_field(v_x1_241201, 1);
            heff_take_n(v_x1_241201, 3ULL, 2);
            switch (heff_tag_of(v_x11_241202)) {
            case TAG_Left: {
              V v_e_241204 = heff_field(v_x11_241202, 0);
              heff_take_n(v_x11_241202, 1ULL, 1);
              heff_drop_rec(v_r_240, 3);
              heff_drop_rec(v_kw_24780, 9);
              heff_drop(v_b_24785);
              heff_drop(v_x_241199);
              return heff_tag_at_n(v_ru_24x1_241195_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241204}), v_st_241203});
            }
            case TAG_Right: {
              V v_x_241205 = heff_field(v_x11_241202, 0);
              heff_take_n(v_x11_241202, 1ULL, 1);
              V v_m_241206 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_b_24785)}));
              V v_x1_241207 = heff_tr(heff_call(v_m_241206, 1, (V[]){v_st_241203}));
              switch (heff_tag_of(v_x1_241207)) {
              case TAG_MkPair: {
                V v_x11_241208 = heff_field(v_x1_241207, 0);
                V v_st_241209 = heff_field(v_x1_241207, 1);
                heff_take_n(v_x1_241207, 3ULL, 2);
                switch (heff_tag_of(v_x11_241208)) {
                case TAG_Left: {
                  V v_e_241210 = heff_field(v_x11_241208, 0);
                  heff_take_n(v_x11_241208, 1ULL, 1);
                  heff_drop_rec(v_kw_24780, 9);
                  heff_drop(v_b_24785);
                  heff_drop(v_x_241199);
                  heff_drop(v_x_241205);
                  return heff_tag_at_n(v_ru_24x1_241195_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241210}), v_st_241209});
                }
                case TAG_Right: {
                  V v_x_241211 = heff_field(v_x11_241208, 0);
                  heff_take_n(v_x11_241208, 1ULL, 1);
                  V v_t_241212 = (g_heff_2esyntax_2ecst_2elastE(v_b_24785));
                  V v_e_241213 = heff_get_n(v_t_241212, 4, 9);
                  V v_t_241214 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_24780, 3, 9), v_e_241213});
                  V v_x_241215 = (g_heff_2esyntax_2esurface_2eifE(v_t_241214, v_x_241199, v_x_241205, v_x_241211));
                  return heff_tag_at_n(v_ru_24x1_241195_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_241215}), v_st_241209});
                }
                default: return heff_nomatch(v_x11_241208);
                }
              }
              default: return heff_nomatch(v_x1_241207);
              }
            }
            default: return heff_nomatch(v_x11_241202);
            }
          }
          default: return heff_nomatch(v_x1_241201);
          }
        }
        default: return heff_nomatch(v_x11_241196);
        }
      }
      default: return heff_nomatch(v_x1_241195);
      }
    }
    case TAG_Ops: {
      V v_m_241218 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_24781}));
      V v_x1_241219 = heff_tr(heff_call(v_m_241218, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_241219)) {
      case TAG_MkPair: {
        V v_x11_241220 = heff_field(v_x1_241219, 0);
        V v_st_241221 = heff_field(v_x1_241219, 1);
        V v_ru_24x1_241219_24MkPair = heff_take_reuse_n(v_x1_241219, 3ULL, 2);
        switch (heff_tag_of(v_x11_241220)) {
        case TAG_Left: {
          V v_e_241222 = heff_field(v_x11_241220, 0);
          heff_take_n(v_x11_241220, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_24780, 9);
          heff_drop(v_a_24783);
          heff_drop(v_b_24785);
          return heff_tag_at_n(v_ru_24x1_241219_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241222}), v_st_241221});
        }
        case TAG_Right: {
          V v_x_241223 = heff_field(v_x11_241220, 0);
          heff_take_n(v_x11_241220, 1ULL, 1);
          V v_m_241224 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_24783}));
          V v_x1_241225 = heff_tr(heff_call(v_m_241224, 1, (V[]){v_st_241221}));
          switch (heff_tag_of(v_x1_241225)) {
          case TAG_MkPair: {
            V v_x11_241226 = heff_field(v_x1_241225, 0);
            V v_st_241227 = heff_field(v_x1_241225, 1);
            heff_take_n(v_x1_241225, 3ULL, 2);
            switch (heff_tag_of(v_x11_241226)) {
            case TAG_Left: {
              V v_e_241228 = heff_field(v_x11_241226, 0);
              heff_take_n(v_x11_241226, 1ULL, 1);
              heff_drop_rec(v_r_240, 3);
              heff_drop_rec(v_kw_24780, 9);
              heff_drop(v_b_24785);
              heff_drop(v_x_241223);
              return heff_tag_at_n(v_ru_24x1_241219_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241228}), v_st_241227});
            }
            case TAG_Right: {
              V v_x_241229 = heff_field(v_x11_241226, 0);
              heff_take_n(v_x11_241226, 1ULL, 1);
              V v_m_241230 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_b_24785)}));
              V v_x1_241231 = heff_tr(heff_call(v_m_241230, 1, (V[]){v_st_241227}));
              switch (heff_tag_of(v_x1_241231)) {
              case TAG_MkPair: {
                V v_x11_241232 = heff_field(v_x1_241231, 0);
                V v_st_241233 = heff_field(v_x1_241231, 1);
                heff_take_n(v_x1_241231, 3ULL, 2);
                switch (heff_tag_of(v_x11_241232)) {
                case TAG_Left: {
                  V v_e_241234 = heff_field(v_x11_241232, 0);
                  heff_take_n(v_x11_241232, 1ULL, 1);
                  heff_drop_rec(v_kw_24780, 9);
                  heff_drop(v_b_24785);
                  heff_drop(v_x_241223);
                  heff_drop(v_x_241229);
                  return heff_tag_at_n(v_ru_24x1_241219_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241234}), v_st_241233});
                }
                case TAG_Right: {
                  V v_x_241235 = heff_field(v_x11_241232, 0);
                  heff_take_n(v_x11_241232, 1ULL, 1);
                  V v_t_241236 = (g_heff_2esyntax_2ecst_2elastE(v_b_24785));
                  V v_e_241237 = heff_get_n(v_t_241236, 4, 9);
                  V v_t_241238 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_24780, 3, 9), v_e_241237});
                  V v_x_241239 = (g_heff_2esyntax_2esurface_2eifE(v_t_241238, v_x_241223, v_x_241229, v_x_241235));
                  return heff_tag_at_n(v_ru_24x1_241219_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_241239}), v_st_241233});
                }
                default: return heff_nomatch(v_x11_241232);
                }
              }
              default: return heff_nomatch(v_x1_241231);
              }
            }
            default: return heff_nomatch(v_x11_241226);
            }
          }
          default: return heff_nomatch(v_x1_241225);
          }
        }
        default: return heff_nomatch(v_x11_241220);
        }
      }
      default: return heff_nomatch(v_x1_241219);
      }
    }
    case TAG_OpRhs: {
      V v_m_241242 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_24781}));
      V v_x1_241243 = heff_tr(heff_call(v_m_241242, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_241243)) {
      case TAG_MkPair: {
        V v_x11_241244 = heff_field(v_x1_241243, 0);
        V v_st_241245 = heff_field(v_x1_241243, 1);
        V v_ru_24x1_241243_24MkPair = heff_take_reuse_n(v_x1_241243, 3ULL, 2);
        switch (heff_tag_of(v_x11_241244)) {
        case TAG_Left: {
          V v_e_241246 = heff_field(v_x11_241244, 0);
          heff_take_n(v_x11_241244, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_24780, 9);
          heff_drop(v_a_24783);
          heff_drop(v_b_24785);
          return heff_tag_at_n(v_ru_24x1_241243_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241246}), v_st_241245});
        }
        case TAG_Right: {
          V v_x_241247 = heff_field(v_x11_241244, 0);
          heff_take_n(v_x11_241244, 1ULL, 1);
          V v_m_241248 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_24783}));
          V v_x1_241249 = heff_tr(heff_call(v_m_241248, 1, (V[]){v_st_241245}));
          switch (heff_tag_of(v_x1_241249)) {
          case TAG_MkPair: {
            V v_x11_241250 = heff_field(v_x1_241249, 0);
            V v_st_241251 = heff_field(v_x1_241249, 1);
            heff_take_n(v_x1_241249, 3ULL, 2);
            switch (heff_tag_of(v_x11_241250)) {
            case TAG_Left: {
              V v_e_241252 = heff_field(v_x11_241250, 0);
              heff_take_n(v_x11_241250, 1ULL, 1);
              heff_drop_rec(v_r_240, 3);
              heff_drop_rec(v_kw_24780, 9);
              heff_drop(v_b_24785);
              heff_drop(v_x_241247);
              return heff_tag_at_n(v_ru_24x1_241243_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241252}), v_st_241251});
            }
            case TAG_Right: {
              V v_x_241253 = heff_field(v_x11_241250, 0);
              heff_take_n(v_x11_241250, 1ULL, 1);
              V v_m_241254 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_b_24785)}));
              V v_x1_241255 = heff_tr(heff_call(v_m_241254, 1, (V[]){v_st_241251}));
              switch (heff_tag_of(v_x1_241255)) {
              case TAG_MkPair: {
                V v_x11_241256 = heff_field(v_x1_241255, 0);
                V v_st_241257 = heff_field(v_x1_241255, 1);
                heff_take_n(v_x1_241255, 3ULL, 2);
                switch (heff_tag_of(v_x11_241256)) {
                case TAG_Left: {
                  V v_e_241258 = heff_field(v_x11_241256, 0);
                  heff_take_n(v_x11_241256, 1ULL, 1);
                  heff_drop_rec(v_kw_24780, 9);
                  heff_drop(v_b_24785);
                  heff_drop(v_x_241247);
                  heff_drop(v_x_241253);
                  return heff_tag_at_n(v_ru_24x1_241243_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241258}), v_st_241257});
                }
                case TAG_Right: {
                  V v_x_241259 = heff_field(v_x11_241256, 0);
                  heff_take_n(v_x11_241256, 1ULL, 1);
                  V v_t_241260 = (g_heff_2esyntax_2ecst_2elastE(v_b_24785));
                  V v_e_241261 = heff_get_n(v_t_241260, 4, 9);
                  V v_t_241262 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_24780, 3, 9), v_e_241261});
                  V v_x_241263 = (g_heff_2esyntax_2esurface_2eifE(v_t_241262, v_x_241247, v_x_241253, v_x_241259));
                  return heff_tag_at_n(v_ru_24x1_241243_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_241263}), v_st_241257});
                }
                default: return heff_nomatch(v_x11_241256);
                }
              }
              default: return heff_nomatch(v_x1_241255);
              }
            }
            default: return heff_nomatch(v_x11_241250);
            }
          }
          default: return heff_nomatch(v_x1_241249);
          }
        }
        default: return heff_nomatch(v_x11_241244);
        }
      }
      default: return heff_nomatch(v_x1_241243);
      }
    }
    case TAG_Ann: {
      V v_m_241267 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_24781}));
      V v_x1_241268 = heff_tr(heff_call(v_m_241267, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_241268)) {
      case TAG_MkPair: {
        V v_x11_241269 = heff_field(v_x1_241268, 0);
        V v_st_241270 = heff_field(v_x1_241268, 1);
        V v_ru_24x1_241268_24MkPair = heff_take_reuse_n(v_x1_241268, 3ULL, 2);
        switch (heff_tag_of(v_x11_241269)) {
        case TAG_Left: {
          V v_e_241271 = heff_field(v_x11_241269, 0);
          heff_take_n(v_x11_241269, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_24780, 9);
          heff_drop(v_a_24783);
          heff_drop(v_b_24785);
          return heff_tag_at_n(v_ru_24x1_241268_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241271}), v_st_241270});
        }
        case TAG_Right: {
          V v_x_241272 = heff_field(v_x11_241269, 0);
          heff_take_n(v_x11_241269, 1ULL, 1);
          V v_m_241273 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_24783}));
          V v_x1_241274 = heff_tr(heff_call(v_m_241273, 1, (V[]){v_st_241270}));
          switch (heff_tag_of(v_x1_241274)) {
          case TAG_MkPair: {
            V v_x11_241275 = heff_field(v_x1_241274, 0);
            V v_st_241276 = heff_field(v_x1_241274, 1);
            heff_take_n(v_x1_241274, 3ULL, 2);
            switch (heff_tag_of(v_x11_241275)) {
            case TAG_Left: {
              V v_e_241277 = heff_field(v_x11_241275, 0);
              heff_take_n(v_x11_241275, 1ULL, 1);
              heff_drop_rec(v_r_240, 3);
              heff_drop_rec(v_kw_24780, 9);
              heff_drop(v_b_24785);
              heff_drop(v_x_241272);
              return heff_tag_at_n(v_ru_24x1_241268_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241277}), v_st_241276});
            }
            case TAG_Right: {
              V v_x_241278 = heff_field(v_x11_241275, 0);
              heff_take_n(v_x11_241275, 1ULL, 1);
              V v_m_241279 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_b_24785)}));
              V v_x1_241280 = heff_tr(heff_call(v_m_241279, 1, (V[]){v_st_241276}));
              switch (heff_tag_of(v_x1_241280)) {
              case TAG_MkPair: {
                V v_x11_241281 = heff_field(v_x1_241280, 0);
                V v_st_241282 = heff_field(v_x1_241280, 1);
                heff_take_n(v_x1_241280, 3ULL, 2);
                switch (heff_tag_of(v_x11_241281)) {
                case TAG_Left: {
                  V v_e_241283 = heff_field(v_x11_241281, 0);
                  heff_take_n(v_x11_241281, 1ULL, 1);
                  heff_drop_rec(v_kw_24780, 9);
                  heff_drop(v_b_24785);
                  heff_drop(v_x_241272);
                  heff_drop(v_x_241278);
                  return heff_tag_at_n(v_ru_24x1_241268_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241283}), v_st_241282});
                }
                case TAG_Right: {
                  V v_x_241284 = heff_field(v_x11_241281, 0);
                  heff_take_n(v_x11_241281, 1ULL, 1);
                  V v_t_241285 = (g_heff_2esyntax_2ecst_2elastE(v_b_24785));
                  V v_e_241286 = heff_get_n(v_t_241285, 4, 9);
                  V v_t_241287 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_24780, 3, 9), v_e_241286});
                  V v_x_241288 = (g_heff_2esyntax_2esurface_2eifE(v_t_241287, v_x_241272, v_x_241278, v_x_241284));
                  return heff_tag_at_n(v_ru_24x1_241268_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_241288}), v_st_241282});
                }
                default: return heff_nomatch(v_x11_241281);
                }
              }
              default: return heff_nomatch(v_x1_241280);
              }
            }
            default: return heff_nomatch(v_x11_241275);
            }
          }
          default: return heff_nomatch(v_x1_241274);
          }
        }
        default: return heff_nomatch(v_x11_241269);
        }
      }
      default: return heff_nomatch(v_x1_241268);
      }
    }
    case TAG_BVar: {
      V v_m_241290 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_24781}));
      V v_x1_241291 = heff_tr(heff_call(v_m_241290, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_241291)) {
      case TAG_MkPair: {
        V v_x11_241292 = heff_field(v_x1_241291, 0);
        V v_st_241293 = heff_field(v_x1_241291, 1);
        V v_ru_24x1_241291_24MkPair = heff_take_reuse_n(v_x1_241291, 3ULL, 2);
        switch (heff_tag_of(v_x11_241292)) {
        case TAG_Left: {
          V v_e_241294 = heff_field(v_x11_241292, 0);
          heff_take_n(v_x11_241292, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_24780, 9);
          heff_drop(v_a_24783);
          heff_drop(v_b_24785);
          return heff_tag_at_n(v_ru_24x1_241291_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241294}), v_st_241293});
        }
        case TAG_Right: {
          V v_x_241295 = heff_field(v_x11_241292, 0);
          heff_take_n(v_x11_241292, 1ULL, 1);
          V v_m_241296 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_24783}));
          V v_x1_241297 = heff_tr(heff_call(v_m_241296, 1, (V[]){v_st_241293}));
          switch (heff_tag_of(v_x1_241297)) {
          case TAG_MkPair: {
            V v_x11_241298 = heff_field(v_x1_241297, 0);
            V v_st_241299 = heff_field(v_x1_241297, 1);
            heff_take_n(v_x1_241297, 3ULL, 2);
            switch (heff_tag_of(v_x11_241298)) {
            case TAG_Left: {
              V v_e_241300 = heff_field(v_x11_241298, 0);
              heff_take_n(v_x11_241298, 1ULL, 1);
              heff_drop_rec(v_r_240, 3);
              heff_drop_rec(v_kw_24780, 9);
              heff_drop(v_b_24785);
              heff_drop(v_x_241295);
              return heff_tag_at_n(v_ru_24x1_241291_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241300}), v_st_241299});
            }
            case TAG_Right: {
              V v_x_241301 = heff_field(v_x11_241298, 0);
              heff_take_n(v_x11_241298, 1ULL, 1);
              V v_m_241302 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_b_24785)}));
              V v_x1_241303 = heff_tr(heff_call(v_m_241302, 1, (V[]){v_st_241299}));
              switch (heff_tag_of(v_x1_241303)) {
              case TAG_MkPair: {
                V v_x11_241304 = heff_field(v_x1_241303, 0);
                V v_st_241305 = heff_field(v_x1_241303, 1);
                heff_take_n(v_x1_241303, 3ULL, 2);
                switch (heff_tag_of(v_x11_241304)) {
                case TAG_Left: {
                  V v_e_241306 = heff_field(v_x11_241304, 0);
                  heff_take_n(v_x11_241304, 1ULL, 1);
                  heff_drop_rec(v_kw_24780, 9);
                  heff_drop(v_b_24785);
                  heff_drop(v_x_241295);
                  heff_drop(v_x_241301);
                  return heff_tag_at_n(v_ru_24x1_241291_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241306}), v_st_241305});
                }
                case TAG_Right: {
                  V v_x_241307 = heff_field(v_x11_241304, 0);
                  heff_take_n(v_x11_241304, 1ULL, 1);
                  V v_t_241308 = (g_heff_2esyntax_2ecst_2elastE(v_b_24785));
                  V v_e_241309 = heff_get_n(v_t_241308, 4, 9);
                  V v_t_241310 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_24780, 3, 9), v_e_241309});
                  V v_x_241311 = (g_heff_2esyntax_2esurface_2eifE(v_t_241310, v_x_241295, v_x_241301, v_x_241307));
                  return heff_tag_at_n(v_ru_24x1_241291_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_241311}), v_st_241305});
                }
                default: return heff_nomatch(v_x11_241304);
                }
              }
              default: return heff_nomatch(v_x1_241303);
              }
            }
            default: return heff_nomatch(v_x11_241298);
            }
          }
          default: return heff_nomatch(v_x1_241297);
          }
        }
        default: return heff_nomatch(v_x11_241292);
        }
      }
      default: return heff_nomatch(v_x1_241291);
      }
    }
    case TAG_BImp: {
      V v_m_241315 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_24781}));
      V v_x1_241316 = heff_tr(heff_call(v_m_241315, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_241316)) {
      case TAG_MkPair: {
        V v_x11_241317 = heff_field(v_x1_241316, 0);
        V v_st_241318 = heff_field(v_x1_241316, 1);
        V v_ru_24x1_241316_24MkPair = heff_take_reuse_n(v_x1_241316, 3ULL, 2);
        switch (heff_tag_of(v_x11_241317)) {
        case TAG_Left: {
          V v_e_241319 = heff_field(v_x11_241317, 0);
          heff_take_n(v_x11_241317, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_24780, 9);
          heff_drop(v_a_24783);
          heff_drop(v_b_24785);
          return heff_tag_at_n(v_ru_24x1_241316_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241319}), v_st_241318});
        }
        case TAG_Right: {
          V v_x_241320 = heff_field(v_x11_241317, 0);
          heff_take_n(v_x11_241317, 1ULL, 1);
          V v_m_241321 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_24783}));
          V v_x1_241322 = heff_tr(heff_call(v_m_241321, 1, (V[]){v_st_241318}));
          switch (heff_tag_of(v_x1_241322)) {
          case TAG_MkPair: {
            V v_x11_241323 = heff_field(v_x1_241322, 0);
            V v_st_241324 = heff_field(v_x1_241322, 1);
            heff_take_n(v_x1_241322, 3ULL, 2);
            switch (heff_tag_of(v_x11_241323)) {
            case TAG_Left: {
              V v_e_241325 = heff_field(v_x11_241323, 0);
              heff_take_n(v_x11_241323, 1ULL, 1);
              heff_drop_rec(v_r_240, 3);
              heff_drop_rec(v_kw_24780, 9);
              heff_drop(v_b_24785);
              heff_drop(v_x_241320);
              return heff_tag_at_n(v_ru_24x1_241316_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241325}), v_st_241324});
            }
            case TAG_Right: {
              V v_x_241326 = heff_field(v_x11_241323, 0);
              heff_take_n(v_x11_241323, 1ULL, 1);
              V v_m_241327 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_b_24785)}));
              V v_x1_241328 = heff_tr(heff_call(v_m_241327, 1, (V[]){v_st_241324}));
              switch (heff_tag_of(v_x1_241328)) {
              case TAG_MkPair: {
                V v_x11_241329 = heff_field(v_x1_241328, 0);
                V v_st_241330 = heff_field(v_x1_241328, 1);
                heff_take_n(v_x1_241328, 3ULL, 2);
                switch (heff_tag_of(v_x11_241329)) {
                case TAG_Left: {
                  V v_e_241331 = heff_field(v_x11_241329, 0);
                  heff_take_n(v_x11_241329, 1ULL, 1);
                  heff_drop_rec(v_kw_24780, 9);
                  heff_drop(v_b_24785);
                  heff_drop(v_x_241320);
                  heff_drop(v_x_241326);
                  return heff_tag_at_n(v_ru_24x1_241316_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241331}), v_st_241330});
                }
                case TAG_Right: {
                  V v_x_241332 = heff_field(v_x11_241329, 0);
                  heff_take_n(v_x11_241329, 1ULL, 1);
                  V v_t_241333 = (g_heff_2esyntax_2ecst_2elastE(v_b_24785));
                  V v_e_241334 = heff_get_n(v_t_241333, 4, 9);
                  V v_t_241335 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_24780, 3, 9), v_e_241334});
                  V v_x_241336 = (g_heff_2esyntax_2esurface_2eifE(v_t_241335, v_x_241320, v_x_241326, v_x_241332));
                  return heff_tag_at_n(v_ru_24x1_241316_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_241336}), v_st_241330});
                }
                default: return heff_nomatch(v_x11_241329);
                }
              }
              default: return heff_nomatch(v_x1_241328);
              }
            }
            default: return heff_nomatch(v_x11_241323);
            }
          }
          default: return heff_nomatch(v_x1_241322);
          }
        }
        default: return heff_nomatch(v_x11_241317);
        }
      }
      default: return heff_nomatch(v_x1_241316);
      }
    }
    case TAG_BAnn: {
      V v_m_241342 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_24781}));
      V v_x1_241343 = heff_tr(heff_call(v_m_241342, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_241343)) {
      case TAG_MkPair: {
        V v_x11_241344 = heff_field(v_x1_241343, 0);
        V v_st_241345 = heff_field(v_x1_241343, 1);
        V v_ru_24x1_241343_24MkPair = heff_take_reuse_n(v_x1_241343, 3ULL, 2);
        switch (heff_tag_of(v_x11_241344)) {
        case TAG_Left: {
          V v_e_241346 = heff_field(v_x11_241344, 0);
          heff_take_n(v_x11_241344, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_24780, 9);
          heff_drop(v_a_24783);
          heff_drop(v_b_24785);
          return heff_tag_at_n(v_ru_24x1_241343_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241346}), v_st_241345});
        }
        case TAG_Right: {
          V v_x_241347 = heff_field(v_x11_241344, 0);
          heff_take_n(v_x11_241344, 1ULL, 1);
          V v_m_241348 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_24783}));
          V v_x1_241349 = heff_tr(heff_call(v_m_241348, 1, (V[]){v_st_241345}));
          switch (heff_tag_of(v_x1_241349)) {
          case TAG_MkPair: {
            V v_x11_241350 = heff_field(v_x1_241349, 0);
            V v_st_241351 = heff_field(v_x1_241349, 1);
            heff_take_n(v_x1_241349, 3ULL, 2);
            switch (heff_tag_of(v_x11_241350)) {
            case TAG_Left: {
              V v_e_241352 = heff_field(v_x11_241350, 0);
              heff_take_n(v_x11_241350, 1ULL, 1);
              heff_drop_rec(v_r_240, 3);
              heff_drop_rec(v_kw_24780, 9);
              heff_drop(v_b_24785);
              heff_drop(v_x_241347);
              return heff_tag_at_n(v_ru_24x1_241343_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241352}), v_st_241351});
            }
            case TAG_Right: {
              V v_x_241353 = heff_field(v_x11_241350, 0);
              heff_take_n(v_x11_241350, 1ULL, 1);
              V v_m_241354 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_b_24785)}));
              V v_x1_241355 = heff_tr(heff_call(v_m_241354, 1, (V[]){v_st_241351}));
              switch (heff_tag_of(v_x1_241355)) {
              case TAG_MkPair: {
                V v_x11_241356 = heff_field(v_x1_241355, 0);
                V v_st_241357 = heff_field(v_x1_241355, 1);
                heff_take_n(v_x1_241355, 3ULL, 2);
                switch (heff_tag_of(v_x11_241356)) {
                case TAG_Left: {
                  V v_e_241358 = heff_field(v_x11_241356, 0);
                  heff_take_n(v_x11_241356, 1ULL, 1);
                  heff_drop_rec(v_kw_24780, 9);
                  heff_drop(v_b_24785);
                  heff_drop(v_x_241347);
                  heff_drop(v_x_241353);
                  return heff_tag_at_n(v_ru_24x1_241343_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241358}), v_st_241357});
                }
                case TAG_Right: {
                  V v_x_241359 = heff_field(v_x11_241356, 0);
                  heff_take_n(v_x11_241356, 1ULL, 1);
                  V v_t_241360 = (g_heff_2esyntax_2ecst_2elastE(v_b_24785));
                  V v_e_241361 = heff_get_n(v_t_241360, 4, 9);
                  V v_t_241362 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_24780, 3, 9), v_e_241361});
                  V v_x_241363 = (g_heff_2esyntax_2esurface_2eifE(v_t_241362, v_x_241347, v_x_241353, v_x_241359));
                  return heff_tag_at_n(v_ru_24x1_241343_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_241363}), v_st_241357});
                }
                default: return heff_nomatch(v_x11_241356);
                }
              }
              default: return heff_nomatch(v_x1_241355);
              }
            }
            default: return heff_nomatch(v_x11_241350);
            }
          }
          default: return heff_nomatch(v_x1_241349);
          }
        }
        default: return heff_nomatch(v_x11_241344);
        }
      }
      default: return heff_nomatch(v_x1_241343);
      }
    }
    case TAG_Lam: {
      V v_m_241368 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_24781}));
      V v_x1_241369 = heff_tr(heff_call(v_m_241368, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_241369)) {
      case TAG_MkPair: {
        V v_x11_241370 = heff_field(v_x1_241369, 0);
        V v_st_241371 = heff_field(v_x1_241369, 1);
        V v_ru_24x1_241369_24MkPair = heff_take_reuse_n(v_x1_241369, 3ULL, 2);
        switch (heff_tag_of(v_x11_241370)) {
        case TAG_Left: {
          V v_e_241372 = heff_field(v_x11_241370, 0);
          heff_take_n(v_x11_241370, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_24780, 9);
          heff_drop(v_a_24783);
          heff_drop(v_b_24785);
          return heff_tag_at_n(v_ru_24x1_241369_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241372}), v_st_241371});
        }
        case TAG_Right: {
          V v_x_241373 = heff_field(v_x11_241370, 0);
          heff_take_n(v_x11_241370, 1ULL, 1);
          V v_m_241374 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_24783}));
          V v_x1_241375 = heff_tr(heff_call(v_m_241374, 1, (V[]){v_st_241371}));
          switch (heff_tag_of(v_x1_241375)) {
          case TAG_MkPair: {
            V v_x11_241376 = heff_field(v_x1_241375, 0);
            V v_st_241377 = heff_field(v_x1_241375, 1);
            heff_take_n(v_x1_241375, 3ULL, 2);
            switch (heff_tag_of(v_x11_241376)) {
            case TAG_Left: {
              V v_e_241378 = heff_field(v_x11_241376, 0);
              heff_take_n(v_x11_241376, 1ULL, 1);
              heff_drop_rec(v_r_240, 3);
              heff_drop_rec(v_kw_24780, 9);
              heff_drop(v_b_24785);
              heff_drop(v_x_241373);
              return heff_tag_at_n(v_ru_24x1_241369_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241378}), v_st_241377});
            }
            case TAG_Right: {
              V v_x_241379 = heff_field(v_x11_241376, 0);
              heff_take_n(v_x11_241376, 1ULL, 1);
              V v_m_241380 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_b_24785)}));
              V v_x1_241381 = heff_tr(heff_call(v_m_241380, 1, (V[]){v_st_241377}));
              switch (heff_tag_of(v_x1_241381)) {
              case TAG_MkPair: {
                V v_x11_241382 = heff_field(v_x1_241381, 0);
                V v_st_241383 = heff_field(v_x1_241381, 1);
                heff_take_n(v_x1_241381, 3ULL, 2);
                switch (heff_tag_of(v_x11_241382)) {
                case TAG_Left: {
                  V v_e_241384 = heff_field(v_x11_241382, 0);
                  heff_take_n(v_x11_241382, 1ULL, 1);
                  heff_drop_rec(v_kw_24780, 9);
                  heff_drop(v_b_24785);
                  heff_drop(v_x_241373);
                  heff_drop(v_x_241379);
                  return heff_tag_at_n(v_ru_24x1_241369_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241384}), v_st_241383});
                }
                case TAG_Right: {
                  V v_x_241385 = heff_field(v_x11_241382, 0);
                  heff_take_n(v_x11_241382, 1ULL, 1);
                  V v_t_241386 = (g_heff_2esyntax_2ecst_2elastE(v_b_24785));
                  V v_e_241387 = heff_get_n(v_t_241386, 4, 9);
                  V v_t_241388 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_24780, 3, 9), v_e_241387});
                  V v_x_241389 = (g_heff_2esyntax_2esurface_2eifE(v_t_241388, v_x_241373, v_x_241379, v_x_241385));
                  return heff_tag_at_n(v_ru_24x1_241369_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_241389}), v_st_241383});
                }
                default: return heff_nomatch(v_x11_241382);
                }
              }
              default: return heff_nomatch(v_x1_241381);
              }
            }
            default: return heff_nomatch(v_x11_241376);
            }
          }
          default: return heff_nomatch(v_x1_241375);
          }
        }
        default: return heff_nomatch(v_x11_241370);
        }
      }
      default: return heff_nomatch(v_x1_241369);
      }
    }
    case TAG_Case: {
      V v_m_241394 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_24781}));
      V v_x1_241395 = heff_tr(heff_call(v_m_241394, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_241395)) {
      case TAG_MkPair: {
        V v_x11_241396 = heff_field(v_x1_241395, 0);
        V v_st_241397 = heff_field(v_x1_241395, 1);
        V v_ru_24x1_241395_24MkPair = heff_take_reuse_n(v_x1_241395, 3ULL, 2);
        switch (heff_tag_of(v_x11_241396)) {
        case TAG_Left: {
          V v_e_241398 = heff_field(v_x11_241396, 0);
          heff_take_n(v_x11_241396, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_24780, 9);
          heff_drop(v_a_24783);
          heff_drop(v_b_24785);
          return heff_tag_at_n(v_ru_24x1_241395_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241398}), v_st_241397});
        }
        case TAG_Right: {
          V v_x_241399 = heff_field(v_x11_241396, 0);
          heff_take_n(v_x11_241396, 1ULL, 1);
          V v_m_241400 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_24783}));
          V v_x1_241401 = heff_tr(heff_call(v_m_241400, 1, (V[]){v_st_241397}));
          switch (heff_tag_of(v_x1_241401)) {
          case TAG_MkPair: {
            V v_x11_241402 = heff_field(v_x1_241401, 0);
            V v_st_241403 = heff_field(v_x1_241401, 1);
            heff_take_n(v_x1_241401, 3ULL, 2);
            switch (heff_tag_of(v_x11_241402)) {
            case TAG_Left: {
              V v_e_241404 = heff_field(v_x11_241402, 0);
              heff_take_n(v_x11_241402, 1ULL, 1);
              heff_drop_rec(v_r_240, 3);
              heff_drop_rec(v_kw_24780, 9);
              heff_drop(v_b_24785);
              heff_drop(v_x_241399);
              return heff_tag_at_n(v_ru_24x1_241395_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241404}), v_st_241403});
            }
            case TAG_Right: {
              V v_x_241405 = heff_field(v_x11_241402, 0);
              heff_take_n(v_x11_241402, 1ULL, 1);
              V v_m_241406 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_b_24785)}));
              V v_x1_241407 = heff_tr(heff_call(v_m_241406, 1, (V[]){v_st_241403}));
              switch (heff_tag_of(v_x1_241407)) {
              case TAG_MkPair: {
                V v_x11_241408 = heff_field(v_x1_241407, 0);
                V v_st_241409 = heff_field(v_x1_241407, 1);
                heff_take_n(v_x1_241407, 3ULL, 2);
                switch (heff_tag_of(v_x11_241408)) {
                case TAG_Left: {
                  V v_e_241410 = heff_field(v_x11_241408, 0);
                  heff_take_n(v_x11_241408, 1ULL, 1);
                  heff_drop_rec(v_kw_24780, 9);
                  heff_drop(v_b_24785);
                  heff_drop(v_x_241399);
                  heff_drop(v_x_241405);
                  return heff_tag_at_n(v_ru_24x1_241395_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241410}), v_st_241409});
                }
                case TAG_Right: {
                  V v_x_241411 = heff_field(v_x11_241408, 0);
                  heff_take_n(v_x11_241408, 1ULL, 1);
                  V v_t_241412 = (g_heff_2esyntax_2ecst_2elastE(v_b_24785));
                  V v_e_241413 = heff_get_n(v_t_241412, 4, 9);
                  V v_t_241414 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_24780, 3, 9), v_e_241413});
                  V v_x_241415 = (g_heff_2esyntax_2esurface_2eifE(v_t_241414, v_x_241399, v_x_241405, v_x_241411));
                  return heff_tag_at_n(v_ru_24x1_241395_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_241415}), v_st_241409});
                }
                default: return heff_nomatch(v_x11_241408);
                }
              }
              default: return heff_nomatch(v_x1_241407);
              }
            }
            default: return heff_nomatch(v_x11_241402);
            }
          }
          default: return heff_nomatch(v_x1_241401);
          }
        }
        default: return heff_nomatch(v_x11_241396);
        }
      }
      default: return heff_nomatch(v_x1_241395);
      }
    }
    case TAG_EAlt: {
      V v_m_241419 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_24781}));
      V v_x1_241420 = heff_tr(heff_call(v_m_241419, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_241420)) {
      case TAG_MkPair: {
        V v_x11_241421 = heff_field(v_x1_241420, 0);
        V v_st_241422 = heff_field(v_x1_241420, 1);
        V v_ru_24x1_241420_24MkPair = heff_take_reuse_n(v_x1_241420, 3ULL, 2);
        switch (heff_tag_of(v_x11_241421)) {
        case TAG_Left: {
          V v_e_241423 = heff_field(v_x11_241421, 0);
          heff_take_n(v_x11_241421, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_24780, 9);
          heff_drop(v_a_24783);
          heff_drop(v_b_24785);
          return heff_tag_at_n(v_ru_24x1_241420_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241423}), v_st_241422});
        }
        case TAG_Right: {
          V v_x_241424 = heff_field(v_x11_241421, 0);
          heff_take_n(v_x11_241421, 1ULL, 1);
          V v_m_241425 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_24783}));
          V v_x1_241426 = heff_tr(heff_call(v_m_241425, 1, (V[]){v_st_241422}));
          switch (heff_tag_of(v_x1_241426)) {
          case TAG_MkPair: {
            V v_x11_241427 = heff_field(v_x1_241426, 0);
            V v_st_241428 = heff_field(v_x1_241426, 1);
            heff_take_n(v_x1_241426, 3ULL, 2);
            switch (heff_tag_of(v_x11_241427)) {
            case TAG_Left: {
              V v_e_241429 = heff_field(v_x11_241427, 0);
              heff_take_n(v_x11_241427, 1ULL, 1);
              heff_drop_rec(v_r_240, 3);
              heff_drop_rec(v_kw_24780, 9);
              heff_drop(v_b_24785);
              heff_drop(v_x_241424);
              return heff_tag_at_n(v_ru_24x1_241420_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241429}), v_st_241428});
            }
            case TAG_Right: {
              V v_x_241430 = heff_field(v_x11_241427, 0);
              heff_take_n(v_x11_241427, 1ULL, 1);
              V v_m_241431 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_b_24785)}));
              V v_x1_241432 = heff_tr(heff_call(v_m_241431, 1, (V[]){v_st_241428}));
              switch (heff_tag_of(v_x1_241432)) {
              case TAG_MkPair: {
                V v_x11_241433 = heff_field(v_x1_241432, 0);
                V v_st_241434 = heff_field(v_x1_241432, 1);
                heff_take_n(v_x1_241432, 3ULL, 2);
                switch (heff_tag_of(v_x11_241433)) {
                case TAG_Left: {
                  V v_e_241435 = heff_field(v_x11_241433, 0);
                  heff_take_n(v_x11_241433, 1ULL, 1);
                  heff_drop_rec(v_kw_24780, 9);
                  heff_drop(v_b_24785);
                  heff_drop(v_x_241424);
                  heff_drop(v_x_241430);
                  return heff_tag_at_n(v_ru_24x1_241420_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241435}), v_st_241434});
                }
                case TAG_Right: {
                  V v_x_241436 = heff_field(v_x11_241433, 0);
                  heff_take_n(v_x11_241433, 1ULL, 1);
                  V v_t_241437 = (g_heff_2esyntax_2ecst_2elastE(v_b_24785));
                  V v_e_241438 = heff_get_n(v_t_241437, 4, 9);
                  V v_t_241439 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_24780, 3, 9), v_e_241438});
                  V v_x_241440 = (g_heff_2esyntax_2esurface_2eifE(v_t_241439, v_x_241424, v_x_241430, v_x_241436));
                  return heff_tag_at_n(v_ru_24x1_241420_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_241440}), v_st_241434});
                }
                default: return heff_nomatch(v_x11_241433);
                }
              }
              default: return heff_nomatch(v_x1_241432);
              }
            }
            default: return heff_nomatch(v_x11_241427);
            }
          }
          default: return heff_nomatch(v_x1_241426);
          }
        }
        default: return heff_nomatch(v_x11_241421);
        }
      }
      default: return heff_nomatch(v_x1_241420);
      }
    }
    case TAG_If: {
      V v_m_241447 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_24781}));
      V v_x1_241448 = heff_tr(heff_call(v_m_241447, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_241448)) {
      case TAG_MkPair: {
        V v_x11_241449 = heff_field(v_x1_241448, 0);
        V v_st_241450 = heff_field(v_x1_241448, 1);
        V v_ru_24x1_241448_24MkPair = heff_take_reuse_n(v_x1_241448, 3ULL, 2);
        switch (heff_tag_of(v_x11_241449)) {
        case TAG_Left: {
          V v_e_241451 = heff_field(v_x11_241449, 0);
          heff_take_n(v_x11_241449, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_24780, 9);
          heff_drop(v_a_24783);
          heff_drop(v_b_24785);
          return heff_tag_at_n(v_ru_24x1_241448_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241451}), v_st_241450});
        }
        case TAG_Right: {
          V v_x_241452 = heff_field(v_x11_241449, 0);
          heff_take_n(v_x11_241449, 1ULL, 1);
          V v_m_241453 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_24783}));
          V v_x1_241454 = heff_tr(heff_call(v_m_241453, 1, (V[]){v_st_241450}));
          switch (heff_tag_of(v_x1_241454)) {
          case TAG_MkPair: {
            V v_x11_241455 = heff_field(v_x1_241454, 0);
            V v_st_241456 = heff_field(v_x1_241454, 1);
            heff_take_n(v_x1_241454, 3ULL, 2);
            switch (heff_tag_of(v_x11_241455)) {
            case TAG_Left: {
              V v_e_241457 = heff_field(v_x11_241455, 0);
              heff_take_n(v_x11_241455, 1ULL, 1);
              heff_drop_rec(v_r_240, 3);
              heff_drop_rec(v_kw_24780, 9);
              heff_drop(v_b_24785);
              heff_drop(v_x_241452);
              return heff_tag_at_n(v_ru_24x1_241448_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241457}), v_st_241456});
            }
            case TAG_Right: {
              V v_x_241458 = heff_field(v_x11_241455, 0);
              heff_take_n(v_x11_241455, 1ULL, 1);
              V v_m_241459 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_b_24785)}));
              V v_x1_241460 = heff_tr(heff_call(v_m_241459, 1, (V[]){v_st_241456}));
              switch (heff_tag_of(v_x1_241460)) {
              case TAG_MkPair: {
                V v_x11_241461 = heff_field(v_x1_241460, 0);
                V v_st_241462 = heff_field(v_x1_241460, 1);
                heff_take_n(v_x1_241460, 3ULL, 2);
                switch (heff_tag_of(v_x11_241461)) {
                case TAG_Left: {
                  V v_e_241463 = heff_field(v_x11_241461, 0);
                  heff_take_n(v_x11_241461, 1ULL, 1);
                  heff_drop_rec(v_kw_24780, 9);
                  heff_drop(v_b_24785);
                  heff_drop(v_x_241452);
                  heff_drop(v_x_241458);
                  return heff_tag_at_n(v_ru_24x1_241448_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241463}), v_st_241462});
                }
                case TAG_Right: {
                  V v_x_241464 = heff_field(v_x11_241461, 0);
                  heff_take_n(v_x11_241461, 1ULL, 1);
                  V v_t_241465 = (g_heff_2esyntax_2ecst_2elastE(v_b_24785));
                  V v_e_241466 = heff_get_n(v_t_241465, 4, 9);
                  V v_t_241467 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_24780, 3, 9), v_e_241466});
                  V v_x_241468 = (g_heff_2esyntax_2esurface_2eifE(v_t_241467, v_x_241452, v_x_241458, v_x_241464));
                  return heff_tag_at_n(v_ru_24x1_241448_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_241468}), v_st_241462});
                }
                default: return heff_nomatch(v_x11_241461);
                }
              }
              default: return heff_nomatch(v_x1_241460);
              }
            }
            default: return heff_nomatch(v_x11_241455);
            }
          }
          default: return heff_nomatch(v_x1_241454);
          }
        }
        default: return heff_nomatch(v_x11_241449);
        }
      }
      default: return heff_nomatch(v_x1_241448);
      }
    }
    case TAG_Do: {
      V v_m_241471 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_24781}));
      V v_x1_241472 = heff_tr(heff_call(v_m_241471, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_241472)) {
      case TAG_MkPair: {
        V v_x11_241473 = heff_field(v_x1_241472, 0);
        V v_st_241474 = heff_field(v_x1_241472, 1);
        V v_ru_24x1_241472_24MkPair = heff_take_reuse_n(v_x1_241472, 3ULL, 2);
        switch (heff_tag_of(v_x11_241473)) {
        case TAG_Left: {
          V v_e_241475 = heff_field(v_x11_241473, 0);
          heff_take_n(v_x11_241473, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_24780, 9);
          heff_drop(v_a_24783);
          heff_drop(v_b_24785);
          return heff_tag_at_n(v_ru_24x1_241472_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241475}), v_st_241474});
        }
        case TAG_Right: {
          V v_x_241476 = heff_field(v_x11_241473, 0);
          heff_take_n(v_x11_241473, 1ULL, 1);
          V v_m_241477 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_24783}));
          V v_x1_241478 = heff_tr(heff_call(v_m_241477, 1, (V[]){v_st_241474}));
          switch (heff_tag_of(v_x1_241478)) {
          case TAG_MkPair: {
            V v_x11_241479 = heff_field(v_x1_241478, 0);
            V v_st_241480 = heff_field(v_x1_241478, 1);
            heff_take_n(v_x1_241478, 3ULL, 2);
            switch (heff_tag_of(v_x11_241479)) {
            case TAG_Left: {
              V v_e_241481 = heff_field(v_x11_241479, 0);
              heff_take_n(v_x11_241479, 1ULL, 1);
              heff_drop_rec(v_r_240, 3);
              heff_drop_rec(v_kw_24780, 9);
              heff_drop(v_b_24785);
              heff_drop(v_x_241476);
              return heff_tag_at_n(v_ru_24x1_241472_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241481}), v_st_241480});
            }
            case TAG_Right: {
              V v_x_241482 = heff_field(v_x11_241479, 0);
              heff_take_n(v_x11_241479, 1ULL, 1);
              V v_m_241483 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_b_24785)}));
              V v_x1_241484 = heff_tr(heff_call(v_m_241483, 1, (V[]){v_st_241480}));
              switch (heff_tag_of(v_x1_241484)) {
              case TAG_MkPair: {
                V v_x11_241485 = heff_field(v_x1_241484, 0);
                V v_st_241486 = heff_field(v_x1_241484, 1);
                heff_take_n(v_x1_241484, 3ULL, 2);
                switch (heff_tag_of(v_x11_241485)) {
                case TAG_Left: {
                  V v_e_241487 = heff_field(v_x11_241485, 0);
                  heff_take_n(v_x11_241485, 1ULL, 1);
                  heff_drop_rec(v_kw_24780, 9);
                  heff_drop(v_b_24785);
                  heff_drop(v_x_241476);
                  heff_drop(v_x_241482);
                  return heff_tag_at_n(v_ru_24x1_241472_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241487}), v_st_241486});
                }
                case TAG_Right: {
                  V v_x_241488 = heff_field(v_x11_241485, 0);
                  heff_take_n(v_x11_241485, 1ULL, 1);
                  V v_t_241489 = (g_heff_2esyntax_2ecst_2elastE(v_b_24785));
                  V v_e_241490 = heff_get_n(v_t_241489, 4, 9);
                  V v_t_241491 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_24780, 3, 9), v_e_241490});
                  V v_x_241492 = (g_heff_2esyntax_2esurface_2eifE(v_t_241491, v_x_241476, v_x_241482, v_x_241488));
                  return heff_tag_at_n(v_ru_24x1_241472_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_241492}), v_st_241486});
                }
                default: return heff_nomatch(v_x11_241485);
                }
              }
              default: return heff_nomatch(v_x1_241484);
              }
            }
            default: return heff_nomatch(v_x11_241479);
            }
          }
          default: return heff_nomatch(v_x1_241478);
          }
        }
        default: return heff_nomatch(v_x11_241473);
        }
      }
      default: return heff_nomatch(v_x1_241472);
      }
    }
    case TAG_ESBind: {
      V v_m_241496 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_24781}));
      V v_x1_241497 = heff_tr(heff_call(v_m_241496, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_241497)) {
      case TAG_MkPair: {
        V v_x11_241498 = heff_field(v_x1_241497, 0);
        V v_st_241499 = heff_field(v_x1_241497, 1);
        V v_ru_24x1_241497_24MkPair = heff_take_reuse_n(v_x1_241497, 3ULL, 2);
        switch (heff_tag_of(v_x11_241498)) {
        case TAG_Left: {
          V v_e_241500 = heff_field(v_x11_241498, 0);
          heff_take_n(v_x11_241498, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_24780, 9);
          heff_drop(v_a_24783);
          heff_drop(v_b_24785);
          return heff_tag_at_n(v_ru_24x1_241497_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241500}), v_st_241499});
        }
        case TAG_Right: {
          V v_x_241501 = heff_field(v_x11_241498, 0);
          heff_take_n(v_x11_241498, 1ULL, 1);
          V v_m_241502 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_24783}));
          V v_x1_241503 = heff_tr(heff_call(v_m_241502, 1, (V[]){v_st_241499}));
          switch (heff_tag_of(v_x1_241503)) {
          case TAG_MkPair: {
            V v_x11_241504 = heff_field(v_x1_241503, 0);
            V v_st_241505 = heff_field(v_x1_241503, 1);
            heff_take_n(v_x1_241503, 3ULL, 2);
            switch (heff_tag_of(v_x11_241504)) {
            case TAG_Left: {
              V v_e_241506 = heff_field(v_x11_241504, 0);
              heff_take_n(v_x11_241504, 1ULL, 1);
              heff_drop_rec(v_r_240, 3);
              heff_drop_rec(v_kw_24780, 9);
              heff_drop(v_b_24785);
              heff_drop(v_x_241501);
              return heff_tag_at_n(v_ru_24x1_241497_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241506}), v_st_241505});
            }
            case TAG_Right: {
              V v_x_241507 = heff_field(v_x11_241504, 0);
              heff_take_n(v_x11_241504, 1ULL, 1);
              V v_m_241508 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_b_24785)}));
              V v_x1_241509 = heff_tr(heff_call(v_m_241508, 1, (V[]){v_st_241505}));
              switch (heff_tag_of(v_x1_241509)) {
              case TAG_MkPair: {
                V v_x11_241510 = heff_field(v_x1_241509, 0);
                V v_st_241511 = heff_field(v_x1_241509, 1);
                heff_take_n(v_x1_241509, 3ULL, 2);
                switch (heff_tag_of(v_x11_241510)) {
                case TAG_Left: {
                  V v_e_241512 = heff_field(v_x11_241510, 0);
                  heff_take_n(v_x11_241510, 1ULL, 1);
                  heff_drop_rec(v_kw_24780, 9);
                  heff_drop(v_b_24785);
                  heff_drop(v_x_241501);
                  heff_drop(v_x_241507);
                  return heff_tag_at_n(v_ru_24x1_241497_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241512}), v_st_241511});
                }
                case TAG_Right: {
                  V v_x_241513 = heff_field(v_x11_241510, 0);
                  heff_take_n(v_x11_241510, 1ULL, 1);
                  V v_t_241514 = (g_heff_2esyntax_2ecst_2elastE(v_b_24785));
                  V v_e_241515 = heff_get_n(v_t_241514, 4, 9);
                  V v_t_241516 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_24780, 3, 9), v_e_241515});
                  V v_x_241517 = (g_heff_2esyntax_2esurface_2eifE(v_t_241516, v_x_241501, v_x_241507, v_x_241513));
                  return heff_tag_at_n(v_ru_24x1_241497_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_241517}), v_st_241511});
                }
                default: return heff_nomatch(v_x11_241510);
                }
              }
              default: return heff_nomatch(v_x1_241509);
              }
            }
            default: return heff_nomatch(v_x11_241504);
            }
          }
          default: return heff_nomatch(v_x1_241503);
          }
        }
        default: return heff_nomatch(v_x11_241498);
        }
      }
      default: return heff_nomatch(v_x1_241497);
      }
    }
    case TAG_ELet: {
      V v_m_241524 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_24781}));
      V v_x1_241525 = heff_tr(heff_call(v_m_241524, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_241525)) {
      case TAG_MkPair: {
        V v_x11_241526 = heff_field(v_x1_241525, 0);
        V v_st_241527 = heff_field(v_x1_241525, 1);
        V v_ru_24x1_241525_24MkPair = heff_take_reuse_n(v_x1_241525, 3ULL, 2);
        switch (heff_tag_of(v_x11_241526)) {
        case TAG_Left: {
          V v_e_241528 = heff_field(v_x11_241526, 0);
          heff_take_n(v_x11_241526, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_24780, 9);
          heff_drop(v_a_24783);
          heff_drop(v_b_24785);
          return heff_tag_at_n(v_ru_24x1_241525_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241528}), v_st_241527});
        }
        case TAG_Right: {
          V v_x_241529 = heff_field(v_x11_241526, 0);
          heff_take_n(v_x11_241526, 1ULL, 1);
          V v_m_241530 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_24783}));
          V v_x1_241531 = heff_tr(heff_call(v_m_241530, 1, (V[]){v_st_241527}));
          switch (heff_tag_of(v_x1_241531)) {
          case TAG_MkPair: {
            V v_x11_241532 = heff_field(v_x1_241531, 0);
            V v_st_241533 = heff_field(v_x1_241531, 1);
            heff_take_n(v_x1_241531, 3ULL, 2);
            switch (heff_tag_of(v_x11_241532)) {
            case TAG_Left: {
              V v_e_241534 = heff_field(v_x11_241532, 0);
              heff_take_n(v_x11_241532, 1ULL, 1);
              heff_drop_rec(v_r_240, 3);
              heff_drop_rec(v_kw_24780, 9);
              heff_drop(v_b_24785);
              heff_drop(v_x_241529);
              return heff_tag_at_n(v_ru_24x1_241525_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241534}), v_st_241533});
            }
            case TAG_Right: {
              V v_x_241535 = heff_field(v_x11_241532, 0);
              heff_take_n(v_x11_241532, 1ULL, 1);
              V v_m_241536 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_b_24785)}));
              V v_x1_241537 = heff_tr(heff_call(v_m_241536, 1, (V[]){v_st_241533}));
              switch (heff_tag_of(v_x1_241537)) {
              case TAG_MkPair: {
                V v_x11_241538 = heff_field(v_x1_241537, 0);
                V v_st_241539 = heff_field(v_x1_241537, 1);
                heff_take_n(v_x1_241537, 3ULL, 2);
                switch (heff_tag_of(v_x11_241538)) {
                case TAG_Left: {
                  V v_e_241540 = heff_field(v_x11_241538, 0);
                  heff_take_n(v_x11_241538, 1ULL, 1);
                  heff_drop_rec(v_kw_24780, 9);
                  heff_drop(v_b_24785);
                  heff_drop(v_x_241529);
                  heff_drop(v_x_241535);
                  return heff_tag_at_n(v_ru_24x1_241525_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241540}), v_st_241539});
                }
                case TAG_Right: {
                  V v_x_241541 = heff_field(v_x11_241538, 0);
                  heff_take_n(v_x11_241538, 1ULL, 1);
                  V v_t_241542 = (g_heff_2esyntax_2ecst_2elastE(v_b_24785));
                  V v_e_241543 = heff_get_n(v_t_241542, 4, 9);
                  V v_t_241544 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_24780, 3, 9), v_e_241543});
                  V v_x_241545 = (g_heff_2esyntax_2esurface_2eifE(v_t_241544, v_x_241529, v_x_241535, v_x_241541));
                  return heff_tag_at_n(v_ru_24x1_241525_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_241545}), v_st_241539});
                }
                default: return heff_nomatch(v_x11_241538);
                }
              }
              default: return heff_nomatch(v_x1_241537);
              }
            }
            default: return heff_nomatch(v_x11_241532);
            }
          }
          default: return heff_nomatch(v_x1_241531);
          }
        }
        default: return heff_nomatch(v_x11_241526);
        }
      }
      default: return heff_nomatch(v_x1_241525);
      }
    }
    case TAG_ELetMut: {
      V v_m_241552 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_24781}));
      V v_x1_241553 = heff_tr(heff_call(v_m_241552, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_241553)) {
      case TAG_MkPair: {
        V v_x11_241554 = heff_field(v_x1_241553, 0);
        V v_st_241555 = heff_field(v_x1_241553, 1);
        V v_ru_24x1_241553_24MkPair = heff_take_reuse_n(v_x1_241553, 3ULL, 2);
        switch (heff_tag_of(v_x11_241554)) {
        case TAG_Left: {
          V v_e_241556 = heff_field(v_x11_241554, 0);
          heff_take_n(v_x11_241554, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_24780, 9);
          heff_drop(v_a_24783);
          heff_drop(v_b_24785);
          return heff_tag_at_n(v_ru_24x1_241553_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241556}), v_st_241555});
        }
        case TAG_Right: {
          V v_x_241557 = heff_field(v_x11_241554, 0);
          heff_take_n(v_x11_241554, 1ULL, 1);
          V v_m_241558 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_24783}));
          V v_x1_241559 = heff_tr(heff_call(v_m_241558, 1, (V[]){v_st_241555}));
          switch (heff_tag_of(v_x1_241559)) {
          case TAG_MkPair: {
            V v_x11_241560 = heff_field(v_x1_241559, 0);
            V v_st_241561 = heff_field(v_x1_241559, 1);
            heff_take_n(v_x1_241559, 3ULL, 2);
            switch (heff_tag_of(v_x11_241560)) {
            case TAG_Left: {
              V v_e_241562 = heff_field(v_x11_241560, 0);
              heff_take_n(v_x11_241560, 1ULL, 1);
              heff_drop_rec(v_r_240, 3);
              heff_drop_rec(v_kw_24780, 9);
              heff_drop(v_b_24785);
              heff_drop(v_x_241557);
              return heff_tag_at_n(v_ru_24x1_241553_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241562}), v_st_241561});
            }
            case TAG_Right: {
              V v_x_241563 = heff_field(v_x11_241560, 0);
              heff_take_n(v_x11_241560, 1ULL, 1);
              V v_m_241564 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_b_24785)}));
              V v_x1_241565 = heff_tr(heff_call(v_m_241564, 1, (V[]){v_st_241561}));
              switch (heff_tag_of(v_x1_241565)) {
              case TAG_MkPair: {
                V v_x11_241566 = heff_field(v_x1_241565, 0);
                V v_st_241567 = heff_field(v_x1_241565, 1);
                heff_take_n(v_x1_241565, 3ULL, 2);
                switch (heff_tag_of(v_x11_241566)) {
                case TAG_Left: {
                  V v_e_241568 = heff_field(v_x11_241566, 0);
                  heff_take_n(v_x11_241566, 1ULL, 1);
                  heff_drop_rec(v_kw_24780, 9);
                  heff_drop(v_b_24785);
                  heff_drop(v_x_241557);
                  heff_drop(v_x_241563);
                  return heff_tag_at_n(v_ru_24x1_241553_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241568}), v_st_241567});
                }
                case TAG_Right: {
                  V v_x_241569 = heff_field(v_x11_241566, 0);
                  heff_take_n(v_x11_241566, 1ULL, 1);
                  V v_t_241570 = (g_heff_2esyntax_2ecst_2elastE(v_b_24785));
                  V v_e_241571 = heff_get_n(v_t_241570, 4, 9);
                  V v_t_241572 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_24780, 3, 9), v_e_241571});
                  V v_x_241573 = (g_heff_2esyntax_2esurface_2eifE(v_t_241572, v_x_241557, v_x_241563, v_x_241569));
                  return heff_tag_at_n(v_ru_24x1_241553_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_241573}), v_st_241567});
                }
                default: return heff_nomatch(v_x11_241566);
                }
              }
              default: return heff_nomatch(v_x1_241565);
              }
            }
            default: return heff_nomatch(v_x11_241560);
            }
          }
          default: return heff_nomatch(v_x1_241559);
          }
        }
        default: return heff_nomatch(v_x11_241554);
        }
      }
      default: return heff_nomatch(v_x1_241553);
      }
    }
    case TAG_EAssign: {
      V v_m_241577 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_24781}));
      V v_x1_241578 = heff_tr(heff_call(v_m_241577, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_241578)) {
      case TAG_MkPair: {
        V v_x11_241579 = heff_field(v_x1_241578, 0);
        V v_st_241580 = heff_field(v_x1_241578, 1);
        V v_ru_24x1_241578_24MkPair = heff_take_reuse_n(v_x1_241578, 3ULL, 2);
        switch (heff_tag_of(v_x11_241579)) {
        case TAG_Left: {
          V v_e_241581 = heff_field(v_x11_241579, 0);
          heff_take_n(v_x11_241579, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_24780, 9);
          heff_drop(v_a_24783);
          heff_drop(v_b_24785);
          return heff_tag_at_n(v_ru_24x1_241578_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241581}), v_st_241580});
        }
        case TAG_Right: {
          V v_x_241582 = heff_field(v_x11_241579, 0);
          heff_take_n(v_x11_241579, 1ULL, 1);
          V v_m_241583 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_24783}));
          V v_x1_241584 = heff_tr(heff_call(v_m_241583, 1, (V[]){v_st_241580}));
          switch (heff_tag_of(v_x1_241584)) {
          case TAG_MkPair: {
            V v_x11_241585 = heff_field(v_x1_241584, 0);
            V v_st_241586 = heff_field(v_x1_241584, 1);
            heff_take_n(v_x1_241584, 3ULL, 2);
            switch (heff_tag_of(v_x11_241585)) {
            case TAG_Left: {
              V v_e_241587 = heff_field(v_x11_241585, 0);
              heff_take_n(v_x11_241585, 1ULL, 1);
              heff_drop_rec(v_r_240, 3);
              heff_drop_rec(v_kw_24780, 9);
              heff_drop(v_b_24785);
              heff_drop(v_x_241582);
              return heff_tag_at_n(v_ru_24x1_241578_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241587}), v_st_241586});
            }
            case TAG_Right: {
              V v_x_241588 = heff_field(v_x11_241585, 0);
              heff_take_n(v_x11_241585, 1ULL, 1);
              V v_m_241589 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_b_24785)}));
              V v_x1_241590 = heff_tr(heff_call(v_m_241589, 1, (V[]){v_st_241586}));
              switch (heff_tag_of(v_x1_241590)) {
              case TAG_MkPair: {
                V v_x11_241591 = heff_field(v_x1_241590, 0);
                V v_st_241592 = heff_field(v_x1_241590, 1);
                heff_take_n(v_x1_241590, 3ULL, 2);
                switch (heff_tag_of(v_x11_241591)) {
                case TAG_Left: {
                  V v_e_241593 = heff_field(v_x11_241591, 0);
                  heff_take_n(v_x11_241591, 1ULL, 1);
                  heff_drop_rec(v_kw_24780, 9);
                  heff_drop(v_b_24785);
                  heff_drop(v_x_241582);
                  heff_drop(v_x_241588);
                  return heff_tag_at_n(v_ru_24x1_241578_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241593}), v_st_241592});
                }
                case TAG_Right: {
                  V v_x_241594 = heff_field(v_x11_241591, 0);
                  heff_take_n(v_x11_241591, 1ULL, 1);
                  V v_t_241595 = (g_heff_2esyntax_2ecst_2elastE(v_b_24785));
                  V v_e_241596 = heff_get_n(v_t_241595, 4, 9);
                  V v_t_241597 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_24780, 3, 9), v_e_241596});
                  V v_x_241598 = (g_heff_2esyntax_2esurface_2eifE(v_t_241597, v_x_241582, v_x_241588, v_x_241594));
                  return heff_tag_at_n(v_ru_24x1_241578_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_241598}), v_st_241592});
                }
                default: return heff_nomatch(v_x11_241591);
                }
              }
              default: return heff_nomatch(v_x1_241590);
              }
            }
            default: return heff_nomatch(v_x11_241585);
            }
          }
          default: return heff_nomatch(v_x1_241584);
          }
        }
        default: return heff_nomatch(v_x11_241579);
        }
      }
      default: return heff_nomatch(v_x1_241578);
      }
    }
    case TAG_EWhile: {
      V v_m_241603 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_24781}));
      V v_x1_241604 = heff_tr(heff_call(v_m_241603, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_241604)) {
      case TAG_MkPair: {
        V v_x11_241605 = heff_field(v_x1_241604, 0);
        V v_st_241606 = heff_field(v_x1_241604, 1);
        V v_ru_24x1_241604_24MkPair = heff_take_reuse_n(v_x1_241604, 3ULL, 2);
        switch (heff_tag_of(v_x11_241605)) {
        case TAG_Left: {
          V v_e_241607 = heff_field(v_x11_241605, 0);
          heff_take_n(v_x11_241605, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_24780, 9);
          heff_drop(v_a_24783);
          heff_drop(v_b_24785);
          return heff_tag_at_n(v_ru_24x1_241604_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241607}), v_st_241606});
        }
        case TAG_Right: {
          V v_x_241608 = heff_field(v_x11_241605, 0);
          heff_take_n(v_x11_241605, 1ULL, 1);
          V v_m_241609 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_24783}));
          V v_x1_241610 = heff_tr(heff_call(v_m_241609, 1, (V[]){v_st_241606}));
          switch (heff_tag_of(v_x1_241610)) {
          case TAG_MkPair: {
            V v_x11_241611 = heff_field(v_x1_241610, 0);
            V v_st_241612 = heff_field(v_x1_241610, 1);
            heff_take_n(v_x1_241610, 3ULL, 2);
            switch (heff_tag_of(v_x11_241611)) {
            case TAG_Left: {
              V v_e_241613 = heff_field(v_x11_241611, 0);
              heff_take_n(v_x11_241611, 1ULL, 1);
              heff_drop_rec(v_r_240, 3);
              heff_drop_rec(v_kw_24780, 9);
              heff_drop(v_b_24785);
              heff_drop(v_x_241608);
              return heff_tag_at_n(v_ru_24x1_241604_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241613}), v_st_241612});
            }
            case TAG_Right: {
              V v_x_241614 = heff_field(v_x11_241611, 0);
              heff_take_n(v_x11_241611, 1ULL, 1);
              V v_m_241615 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_b_24785)}));
              V v_x1_241616 = heff_tr(heff_call(v_m_241615, 1, (V[]){v_st_241612}));
              switch (heff_tag_of(v_x1_241616)) {
              case TAG_MkPair: {
                V v_x11_241617 = heff_field(v_x1_241616, 0);
                V v_st_241618 = heff_field(v_x1_241616, 1);
                heff_take_n(v_x1_241616, 3ULL, 2);
                switch (heff_tag_of(v_x11_241617)) {
                case TAG_Left: {
                  V v_e_241619 = heff_field(v_x11_241617, 0);
                  heff_take_n(v_x11_241617, 1ULL, 1);
                  heff_drop_rec(v_kw_24780, 9);
                  heff_drop(v_b_24785);
                  heff_drop(v_x_241608);
                  heff_drop(v_x_241614);
                  return heff_tag_at_n(v_ru_24x1_241604_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241619}), v_st_241618});
                }
                case TAG_Right: {
                  V v_x_241620 = heff_field(v_x11_241617, 0);
                  heff_take_n(v_x11_241617, 1ULL, 1);
                  V v_t_241621 = (g_heff_2esyntax_2ecst_2elastE(v_b_24785));
                  V v_e_241622 = heff_get_n(v_t_241621, 4, 9);
                  V v_t_241623 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_24780, 3, 9), v_e_241622});
                  V v_x_241624 = (g_heff_2esyntax_2esurface_2eifE(v_t_241623, v_x_241608, v_x_241614, v_x_241620));
                  return heff_tag_at_n(v_ru_24x1_241604_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_241624}), v_st_241618});
                }
                default: return heff_nomatch(v_x11_241617);
                }
              }
              default: return heff_nomatch(v_x1_241616);
              }
            }
            default: return heff_nomatch(v_x11_241611);
            }
          }
          default: return heff_nomatch(v_x1_241610);
          }
        }
        default: return heff_nomatch(v_x11_241605);
        }
      }
      default: return heff_nomatch(v_x1_241604);
      }
    }
    case TAG_EFor: {
      V v_m_241631 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_24781}));
      V v_x1_241632 = heff_tr(heff_call(v_m_241631, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_241632)) {
      case TAG_MkPair: {
        V v_x11_241633 = heff_field(v_x1_241632, 0);
        V v_st_241634 = heff_field(v_x1_241632, 1);
        V v_ru_24x1_241632_24MkPair = heff_take_reuse_n(v_x1_241632, 3ULL, 2);
        switch (heff_tag_of(v_x11_241633)) {
        case TAG_Left: {
          V v_e_241635 = heff_field(v_x11_241633, 0);
          heff_take_n(v_x11_241633, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_24780, 9);
          heff_drop(v_a_24783);
          heff_drop(v_b_24785);
          return heff_tag_at_n(v_ru_24x1_241632_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241635}), v_st_241634});
        }
        case TAG_Right: {
          V v_x_241636 = heff_field(v_x11_241633, 0);
          heff_take_n(v_x11_241633, 1ULL, 1);
          V v_m_241637 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_24783}));
          V v_x1_241638 = heff_tr(heff_call(v_m_241637, 1, (V[]){v_st_241634}));
          switch (heff_tag_of(v_x1_241638)) {
          case TAG_MkPair: {
            V v_x11_241639 = heff_field(v_x1_241638, 0);
            V v_st_241640 = heff_field(v_x1_241638, 1);
            heff_take_n(v_x1_241638, 3ULL, 2);
            switch (heff_tag_of(v_x11_241639)) {
            case TAG_Left: {
              V v_e_241641 = heff_field(v_x11_241639, 0);
              heff_take_n(v_x11_241639, 1ULL, 1);
              heff_drop_rec(v_r_240, 3);
              heff_drop_rec(v_kw_24780, 9);
              heff_drop(v_b_24785);
              heff_drop(v_x_241636);
              return heff_tag_at_n(v_ru_24x1_241632_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241641}), v_st_241640});
            }
            case TAG_Right: {
              V v_x_241642 = heff_field(v_x11_241639, 0);
              heff_take_n(v_x11_241639, 1ULL, 1);
              V v_m_241643 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_b_24785)}));
              V v_x1_241644 = heff_tr(heff_call(v_m_241643, 1, (V[]){v_st_241640}));
              switch (heff_tag_of(v_x1_241644)) {
              case TAG_MkPair: {
                V v_x11_241645 = heff_field(v_x1_241644, 0);
                V v_st_241646 = heff_field(v_x1_241644, 1);
                heff_take_n(v_x1_241644, 3ULL, 2);
                switch (heff_tag_of(v_x11_241645)) {
                case TAG_Left: {
                  V v_e_241647 = heff_field(v_x11_241645, 0);
                  heff_take_n(v_x11_241645, 1ULL, 1);
                  heff_drop_rec(v_kw_24780, 9);
                  heff_drop(v_b_24785);
                  heff_drop(v_x_241636);
                  heff_drop(v_x_241642);
                  return heff_tag_at_n(v_ru_24x1_241632_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241647}), v_st_241646});
                }
                case TAG_Right: {
                  V v_x_241648 = heff_field(v_x11_241645, 0);
                  heff_take_n(v_x11_241645, 1ULL, 1);
                  V v_t_241649 = (g_heff_2esyntax_2ecst_2elastE(v_b_24785));
                  V v_e_241650 = heff_get_n(v_t_241649, 4, 9);
                  V v_t_241651 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_24780, 3, 9), v_e_241650});
                  V v_x_241652 = (g_heff_2esyntax_2esurface_2eifE(v_t_241651, v_x_241636, v_x_241642, v_x_241648));
                  return heff_tag_at_n(v_ru_24x1_241632_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_241652}), v_st_241646});
                }
                default: return heff_nomatch(v_x11_241645);
                }
              }
              default: return heff_nomatch(v_x1_241644);
              }
            }
            default: return heff_nomatch(v_x11_241639);
            }
          }
          default: return heff_nomatch(v_x1_241638);
          }
        }
        default: return heff_nomatch(v_x11_241633);
        }
      }
      default: return heff_nomatch(v_x1_241632);
      }
    }
    case TAG_EJump: {
      V v_m_241654 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_24781}));
      V v_x1_241655 = heff_tr(heff_call(v_m_241654, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_241655)) {
      case TAG_MkPair: {
        V v_x11_241656 = heff_field(v_x1_241655, 0);
        V v_st_241657 = heff_field(v_x1_241655, 1);
        V v_ru_24x1_241655_24MkPair = heff_take_reuse_n(v_x1_241655, 3ULL, 2);
        switch (heff_tag_of(v_x11_241656)) {
        case TAG_Left: {
          V v_e_241658 = heff_field(v_x11_241656, 0);
          heff_take_n(v_x11_241656, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_24780, 9);
          heff_drop(v_a_24783);
          heff_drop(v_b_24785);
          return heff_tag_at_n(v_ru_24x1_241655_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241658}), v_st_241657});
        }
        case TAG_Right: {
          V v_x_241659 = heff_field(v_x11_241656, 0);
          heff_take_n(v_x11_241656, 1ULL, 1);
          V v_m_241660 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_24783}));
          V v_x1_241661 = heff_tr(heff_call(v_m_241660, 1, (V[]){v_st_241657}));
          switch (heff_tag_of(v_x1_241661)) {
          case TAG_MkPair: {
            V v_x11_241662 = heff_field(v_x1_241661, 0);
            V v_st_241663 = heff_field(v_x1_241661, 1);
            heff_take_n(v_x1_241661, 3ULL, 2);
            switch (heff_tag_of(v_x11_241662)) {
            case TAG_Left: {
              V v_e_241664 = heff_field(v_x11_241662, 0);
              heff_take_n(v_x11_241662, 1ULL, 1);
              heff_drop_rec(v_r_240, 3);
              heff_drop_rec(v_kw_24780, 9);
              heff_drop(v_b_24785);
              heff_drop(v_x_241659);
              return heff_tag_at_n(v_ru_24x1_241655_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241664}), v_st_241663});
            }
            case TAG_Right: {
              V v_x_241665 = heff_field(v_x11_241662, 0);
              heff_take_n(v_x11_241662, 1ULL, 1);
              V v_m_241666 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_b_24785)}));
              V v_x1_241667 = heff_tr(heff_call(v_m_241666, 1, (V[]){v_st_241663}));
              switch (heff_tag_of(v_x1_241667)) {
              case TAG_MkPair: {
                V v_x11_241668 = heff_field(v_x1_241667, 0);
                V v_st_241669 = heff_field(v_x1_241667, 1);
                heff_take_n(v_x1_241667, 3ULL, 2);
                switch (heff_tag_of(v_x11_241668)) {
                case TAG_Left: {
                  V v_e_241670 = heff_field(v_x11_241668, 0);
                  heff_take_n(v_x11_241668, 1ULL, 1);
                  heff_drop_rec(v_kw_24780, 9);
                  heff_drop(v_b_24785);
                  heff_drop(v_x_241659);
                  heff_drop(v_x_241665);
                  return heff_tag_at_n(v_ru_24x1_241655_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241670}), v_st_241669});
                }
                case TAG_Right: {
                  V v_x_241671 = heff_field(v_x11_241668, 0);
                  heff_take_n(v_x11_241668, 1ULL, 1);
                  V v_t_241672 = (g_heff_2esyntax_2ecst_2elastE(v_b_24785));
                  V v_e_241673 = heff_get_n(v_t_241672, 4, 9);
                  V v_t_241674 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_24780, 3, 9), v_e_241673});
                  V v_x_241675 = (g_heff_2esyntax_2esurface_2eifE(v_t_241674, v_x_241659, v_x_241665, v_x_241671));
                  return heff_tag_at_n(v_ru_24x1_241655_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_241675}), v_st_241669});
                }
                default: return heff_nomatch(v_x11_241668);
                }
              }
              default: return heff_nomatch(v_x1_241667);
              }
            }
            default: return heff_nomatch(v_x11_241662);
            }
          }
          default: return heff_nomatch(v_x1_241661);
          }
        }
        default: return heff_nomatch(v_x11_241656);
        }
      }
      default: return heff_nomatch(v_x1_241655);
      }
    }
    case TAG_EReturn: {
      V v_m_241678 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_24781}));
      V v_x1_241679 = heff_tr(heff_call(v_m_241678, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_241679)) {
      case TAG_MkPair: {
        V v_x11_241680 = heff_field(v_x1_241679, 0);
        V v_st_241681 = heff_field(v_x1_241679, 1);
        V v_ru_24x1_241679_24MkPair = heff_take_reuse_n(v_x1_241679, 3ULL, 2);
        switch (heff_tag_of(v_x11_241680)) {
        case TAG_Left: {
          V v_e_241682 = heff_field(v_x11_241680, 0);
          heff_take_n(v_x11_241680, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_24780, 9);
          heff_drop(v_a_24783);
          heff_drop(v_b_24785);
          return heff_tag_at_n(v_ru_24x1_241679_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241682}), v_st_241681});
        }
        case TAG_Right: {
          V v_x_241683 = heff_field(v_x11_241680, 0);
          heff_take_n(v_x11_241680, 1ULL, 1);
          V v_m_241684 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_24783}));
          V v_x1_241685 = heff_tr(heff_call(v_m_241684, 1, (V[]){v_st_241681}));
          switch (heff_tag_of(v_x1_241685)) {
          case TAG_MkPair: {
            V v_x11_241686 = heff_field(v_x1_241685, 0);
            V v_st_241687 = heff_field(v_x1_241685, 1);
            heff_take_n(v_x1_241685, 3ULL, 2);
            switch (heff_tag_of(v_x11_241686)) {
            case TAG_Left: {
              V v_e_241688 = heff_field(v_x11_241686, 0);
              heff_take_n(v_x11_241686, 1ULL, 1);
              heff_drop_rec(v_r_240, 3);
              heff_drop_rec(v_kw_24780, 9);
              heff_drop(v_b_24785);
              heff_drop(v_x_241683);
              return heff_tag_at_n(v_ru_24x1_241679_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241688}), v_st_241687});
            }
            case TAG_Right: {
              V v_x_241689 = heff_field(v_x11_241686, 0);
              heff_take_n(v_x11_241686, 1ULL, 1);
              V v_m_241690 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_b_24785)}));
              V v_x1_241691 = heff_tr(heff_call(v_m_241690, 1, (V[]){v_st_241687}));
              switch (heff_tag_of(v_x1_241691)) {
              case TAG_MkPair: {
                V v_x11_241692 = heff_field(v_x1_241691, 0);
                V v_st_241693 = heff_field(v_x1_241691, 1);
                heff_take_n(v_x1_241691, 3ULL, 2);
                switch (heff_tag_of(v_x11_241692)) {
                case TAG_Left: {
                  V v_e_241694 = heff_field(v_x11_241692, 0);
                  heff_take_n(v_x11_241692, 1ULL, 1);
                  heff_drop_rec(v_kw_24780, 9);
                  heff_drop(v_b_24785);
                  heff_drop(v_x_241683);
                  heff_drop(v_x_241689);
                  return heff_tag_at_n(v_ru_24x1_241679_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241694}), v_st_241693});
                }
                case TAG_Right: {
                  V v_x_241695 = heff_field(v_x11_241692, 0);
                  heff_take_n(v_x11_241692, 1ULL, 1);
                  V v_t_241696 = (g_heff_2esyntax_2ecst_2elastE(v_b_24785));
                  V v_e_241697 = heff_get_n(v_t_241696, 4, 9);
                  V v_t_241698 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_24780, 3, 9), v_e_241697});
                  V v_x_241699 = (g_heff_2esyntax_2esurface_2eifE(v_t_241698, v_x_241683, v_x_241689, v_x_241695));
                  return heff_tag_at_n(v_ru_24x1_241679_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_241699}), v_st_241693});
                }
                default: return heff_nomatch(v_x11_241692);
                }
              }
              default: return heff_nomatch(v_x1_241691);
              }
            }
            default: return heff_nomatch(v_x11_241686);
            }
          }
          default: return heff_nomatch(v_x1_241685);
          }
        }
        default: return heff_nomatch(v_x11_241680);
        }
      }
      default: return heff_nomatch(v_x1_241679);
      }
    }
    case TAG_ENest: {
      V v_m_241704 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_24781}));
      V v_x1_241705 = heff_tr(heff_call(v_m_241704, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_241705)) {
      case TAG_MkPair: {
        V v_x11_241706 = heff_field(v_x1_241705, 0);
        V v_st_241707 = heff_field(v_x1_241705, 1);
        V v_ru_24x1_241705_24MkPair = heff_take_reuse_n(v_x1_241705, 3ULL, 2);
        switch (heff_tag_of(v_x11_241706)) {
        case TAG_Left: {
          V v_e_241708 = heff_field(v_x11_241706, 0);
          heff_take_n(v_x11_241706, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_24780, 9);
          heff_drop(v_a_24783);
          heff_drop(v_b_24785);
          return heff_tag_at_n(v_ru_24x1_241705_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241708}), v_st_241707});
        }
        case TAG_Right: {
          V v_x_241709 = heff_field(v_x11_241706, 0);
          heff_take_n(v_x11_241706, 1ULL, 1);
          V v_m_241710 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_24783}));
          V v_x1_241711 = heff_tr(heff_call(v_m_241710, 1, (V[]){v_st_241707}));
          switch (heff_tag_of(v_x1_241711)) {
          case TAG_MkPair: {
            V v_x11_241712 = heff_field(v_x1_241711, 0);
            V v_st_241713 = heff_field(v_x1_241711, 1);
            heff_take_n(v_x1_241711, 3ULL, 2);
            switch (heff_tag_of(v_x11_241712)) {
            case TAG_Left: {
              V v_e_241714 = heff_field(v_x11_241712, 0);
              heff_take_n(v_x11_241712, 1ULL, 1);
              heff_drop_rec(v_r_240, 3);
              heff_drop_rec(v_kw_24780, 9);
              heff_drop(v_b_24785);
              heff_drop(v_x_241709);
              return heff_tag_at_n(v_ru_24x1_241705_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241714}), v_st_241713});
            }
            case TAG_Right: {
              V v_x_241715 = heff_field(v_x11_241712, 0);
              heff_take_n(v_x11_241712, 1ULL, 1);
              V v_m_241716 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_b_24785)}));
              V v_x1_241717 = heff_tr(heff_call(v_m_241716, 1, (V[]){v_st_241713}));
              switch (heff_tag_of(v_x1_241717)) {
              case TAG_MkPair: {
                V v_x11_241718 = heff_field(v_x1_241717, 0);
                V v_st_241719 = heff_field(v_x1_241717, 1);
                heff_take_n(v_x1_241717, 3ULL, 2);
                switch (heff_tag_of(v_x11_241718)) {
                case TAG_Left: {
                  V v_e_241720 = heff_field(v_x11_241718, 0);
                  heff_take_n(v_x11_241718, 1ULL, 1);
                  heff_drop_rec(v_kw_24780, 9);
                  heff_drop(v_b_24785);
                  heff_drop(v_x_241709);
                  heff_drop(v_x_241715);
                  return heff_tag_at_n(v_ru_24x1_241705_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241720}), v_st_241719});
                }
                case TAG_Right: {
                  V v_x_241721 = heff_field(v_x11_241718, 0);
                  heff_take_n(v_x11_241718, 1ULL, 1);
                  V v_t_241722 = (g_heff_2esyntax_2ecst_2elastE(v_b_24785));
                  V v_e_241723 = heff_get_n(v_t_241722, 4, 9);
                  V v_t_241724 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_24780, 3, 9), v_e_241723});
                  V v_x_241725 = (g_heff_2esyntax_2esurface_2eifE(v_t_241724, v_x_241709, v_x_241715, v_x_241721));
                  return heff_tag_at_n(v_ru_24x1_241705_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_241725}), v_st_241719});
                }
                default: return heff_nomatch(v_x11_241718);
                }
              }
              default: return heff_nomatch(v_x1_241717);
              }
            }
            default: return heff_nomatch(v_x11_241712);
            }
          }
          default: return heff_nomatch(v_x1_241711);
          }
        }
        default: return heff_nomatch(v_x11_241706);
        }
      }
      default: return heff_nomatch(v_x1_241705);
      }
    }
    case TAG_IfThen: {
      V v_m_241730 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_24781}));
      V v_x1_241731 = heff_tr(heff_call(v_m_241730, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_241731)) {
      case TAG_MkPair: {
        V v_x11_241732 = heff_field(v_x1_241731, 0);
        V v_st_241733 = heff_field(v_x1_241731, 1);
        V v_ru_24x1_241731_24MkPair = heff_take_reuse_n(v_x1_241731, 3ULL, 2);
        switch (heff_tag_of(v_x11_241732)) {
        case TAG_Left: {
          V v_e_241734 = heff_field(v_x11_241732, 0);
          heff_take_n(v_x11_241732, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_24780, 9);
          heff_drop(v_a_24783);
          heff_drop(v_b_24785);
          return heff_tag_at_n(v_ru_24x1_241731_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241734}), v_st_241733});
        }
        case TAG_Right: {
          V v_x_241735 = heff_field(v_x11_241732, 0);
          heff_take_n(v_x11_241732, 1ULL, 1);
          V v_m_241736 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_24783}));
          V v_x1_241737 = heff_tr(heff_call(v_m_241736, 1, (V[]){v_st_241733}));
          switch (heff_tag_of(v_x1_241737)) {
          case TAG_MkPair: {
            V v_x11_241738 = heff_field(v_x1_241737, 0);
            V v_st_241739 = heff_field(v_x1_241737, 1);
            heff_take_n(v_x1_241737, 3ULL, 2);
            switch (heff_tag_of(v_x11_241738)) {
            case TAG_Left: {
              V v_e_241740 = heff_field(v_x11_241738, 0);
              heff_take_n(v_x11_241738, 1ULL, 1);
              heff_drop_rec(v_r_240, 3);
              heff_drop_rec(v_kw_24780, 9);
              heff_drop(v_b_24785);
              heff_drop(v_x_241735);
              return heff_tag_at_n(v_ru_24x1_241731_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241740}), v_st_241739});
            }
            case TAG_Right: {
              V v_x_241741 = heff_field(v_x11_241738, 0);
              heff_take_n(v_x11_241738, 1ULL, 1);
              V v_m_241742 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_b_24785)}));
              V v_x1_241743 = heff_tr(heff_call(v_m_241742, 1, (V[]){v_st_241739}));
              switch (heff_tag_of(v_x1_241743)) {
              case TAG_MkPair: {
                V v_x11_241744 = heff_field(v_x1_241743, 0);
                V v_st_241745 = heff_field(v_x1_241743, 1);
                heff_take_n(v_x1_241743, 3ULL, 2);
                switch (heff_tag_of(v_x11_241744)) {
                case TAG_Left: {
                  V v_e_241746 = heff_field(v_x11_241744, 0);
                  heff_take_n(v_x11_241744, 1ULL, 1);
                  heff_drop_rec(v_kw_24780, 9);
                  heff_drop(v_b_24785);
                  heff_drop(v_x_241735);
                  heff_drop(v_x_241741);
                  return heff_tag_at_n(v_ru_24x1_241731_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241746}), v_st_241745});
                }
                case TAG_Right: {
                  V v_x_241747 = heff_field(v_x11_241744, 0);
                  heff_take_n(v_x11_241744, 1ULL, 1);
                  V v_t_241748 = (g_heff_2esyntax_2ecst_2elastE(v_b_24785));
                  V v_e_241749 = heff_get_n(v_t_241748, 4, 9);
                  V v_t_241750 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_24780, 3, 9), v_e_241749});
                  V v_x_241751 = (g_heff_2esyntax_2esurface_2eifE(v_t_241750, v_x_241735, v_x_241741, v_x_241747));
                  return heff_tag_at_n(v_ru_24x1_241731_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_241751}), v_st_241745});
                }
                default: return heff_nomatch(v_x11_241744);
                }
              }
              default: return heff_nomatch(v_x1_241743);
              }
            }
            default: return heff_nomatch(v_x11_241738);
            }
          }
          default: return heff_nomatch(v_x1_241737);
          }
        }
        default: return heff_nomatch(v_x11_241732);
        }
      }
      default: return heff_nomatch(v_x1_241731);
      }
    }
    case TAG_ELetCond: {
      V v_p_241753 = heff_field(v_e02_24781, 1);
      V v_e_241755 = heff_field(v_e02_24781, 3);
      heff_take_n(v_e02_24781, 10ULL, 4);
      V v_t_241756 = (g_heff_2esyntax_2ecst_2elastE(heff_dup(v_b_24785)));
      V v_e_241757 = heff_get_n(v_t_241756, 4, 9);
      V v_t_241758 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_24780, 3, 9), v_e_241757});
      return (g_heff_2esyntax_2esurface_2eifLetL(v_r_240, v_t_241758, v_p_241753, v_e_241755, v_a_24783, heff_tag_n(TAG_Just, 1, (V[]){v_b_24785}), v_z_242));
    }
    case TAG_ETry: {
      V v_m_241763 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_24781}));
      V v_x1_241764 = heff_tr(heff_call(v_m_241763, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_241764)) {
      case TAG_MkPair: {
        V v_x11_241765 = heff_field(v_x1_241764, 0);
        V v_st_241766 = heff_field(v_x1_241764, 1);
        V v_ru_24x1_241764_24MkPair = heff_take_reuse_n(v_x1_241764, 3ULL, 2);
        switch (heff_tag_of(v_x11_241765)) {
        case TAG_Left: {
          V v_e_241767 = heff_field(v_x11_241765, 0);
          heff_take_n(v_x11_241765, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_24780, 9);
          heff_drop(v_a_24783);
          heff_drop(v_b_24785);
          return heff_tag_at_n(v_ru_24x1_241764_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241767}), v_st_241766});
        }
        case TAG_Right: {
          V v_x_241768 = heff_field(v_x11_241765, 0);
          heff_take_n(v_x11_241765, 1ULL, 1);
          V v_m_241769 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_24783}));
          V v_x1_241770 = heff_tr(heff_call(v_m_241769, 1, (V[]){v_st_241766}));
          switch (heff_tag_of(v_x1_241770)) {
          case TAG_MkPair: {
            V v_x11_241771 = heff_field(v_x1_241770, 0);
            V v_st_241772 = heff_field(v_x1_241770, 1);
            heff_take_n(v_x1_241770, 3ULL, 2);
            switch (heff_tag_of(v_x11_241771)) {
            case TAG_Left: {
              V v_e_241773 = heff_field(v_x11_241771, 0);
              heff_take_n(v_x11_241771, 1ULL, 1);
              heff_drop_rec(v_r_240, 3);
              heff_drop_rec(v_kw_24780, 9);
              heff_drop(v_b_24785);
              heff_drop(v_x_241768);
              return heff_tag_at_n(v_ru_24x1_241764_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241773}), v_st_241772});
            }
            case TAG_Right: {
              V v_x_241774 = heff_field(v_x11_241771, 0);
              heff_take_n(v_x11_241771, 1ULL, 1);
              V v_m_241775 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_b_24785)}));
              V v_x1_241776 = heff_tr(heff_call(v_m_241775, 1, (V[]){v_st_241772}));
              switch (heff_tag_of(v_x1_241776)) {
              case TAG_MkPair: {
                V v_x11_241777 = heff_field(v_x1_241776, 0);
                V v_st_241778 = heff_field(v_x1_241776, 1);
                heff_take_n(v_x1_241776, 3ULL, 2);
                switch (heff_tag_of(v_x11_241777)) {
                case TAG_Left: {
                  V v_e_241779 = heff_field(v_x11_241777, 0);
                  heff_take_n(v_x11_241777, 1ULL, 1);
                  heff_drop_rec(v_kw_24780, 9);
                  heff_drop(v_b_24785);
                  heff_drop(v_x_241768);
                  heff_drop(v_x_241774);
                  return heff_tag_at_n(v_ru_24x1_241764_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241779}), v_st_241778});
                }
                case TAG_Right: {
                  V v_x_241780 = heff_field(v_x11_241777, 0);
                  heff_take_n(v_x11_241777, 1ULL, 1);
                  V v_t_241781 = (g_heff_2esyntax_2ecst_2elastE(v_b_24785));
                  V v_e_241782 = heff_get_n(v_t_241781, 4, 9);
                  V v_t_241783 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_24780, 3, 9), v_e_241782});
                  V v_x_241784 = (g_heff_2esyntax_2esurface_2eifE(v_t_241783, v_x_241768, v_x_241774, v_x_241780));
                  return heff_tag_at_n(v_ru_24x1_241764_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_241784}), v_st_241778});
                }
                default: return heff_nomatch(v_x11_241777);
                }
              }
              default: return heff_nomatch(v_x1_241776);
              }
            }
            default: return heff_nomatch(v_x11_241771);
            }
          }
          default: return heff_nomatch(v_x1_241770);
          }
        }
        default: return heff_nomatch(v_x11_241765);
        }
      }
      default: return heff_nomatch(v_x1_241764);
      }
    }
    case TAG_ECatch: {
      V v_m_241789 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_24781}));
      V v_x1_241790 = heff_tr(heff_call(v_m_241789, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_241790)) {
      case TAG_MkPair: {
        V v_x11_241791 = heff_field(v_x1_241790, 0);
        V v_st_241792 = heff_field(v_x1_241790, 1);
        V v_ru_24x1_241790_24MkPair = heff_take_reuse_n(v_x1_241790, 3ULL, 2);
        switch (heff_tag_of(v_x11_241791)) {
        case TAG_Left: {
          V v_e_241793 = heff_field(v_x11_241791, 0);
          heff_take_n(v_x11_241791, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_24780, 9);
          heff_drop(v_a_24783);
          heff_drop(v_b_24785);
          return heff_tag_at_n(v_ru_24x1_241790_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241793}), v_st_241792});
        }
        case TAG_Right: {
          V v_x_241794 = heff_field(v_x11_241791, 0);
          heff_take_n(v_x11_241791, 1ULL, 1);
          V v_m_241795 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_24783}));
          V v_x1_241796 = heff_tr(heff_call(v_m_241795, 1, (V[]){v_st_241792}));
          switch (heff_tag_of(v_x1_241796)) {
          case TAG_MkPair: {
            V v_x11_241797 = heff_field(v_x1_241796, 0);
            V v_st_241798 = heff_field(v_x1_241796, 1);
            heff_take_n(v_x1_241796, 3ULL, 2);
            switch (heff_tag_of(v_x11_241797)) {
            case TAG_Left: {
              V v_e_241799 = heff_field(v_x11_241797, 0);
              heff_take_n(v_x11_241797, 1ULL, 1);
              heff_drop_rec(v_r_240, 3);
              heff_drop_rec(v_kw_24780, 9);
              heff_drop(v_b_24785);
              heff_drop(v_x_241794);
              return heff_tag_at_n(v_ru_24x1_241790_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241799}), v_st_241798});
            }
            case TAG_Right: {
              V v_x_241800 = heff_field(v_x11_241797, 0);
              heff_take_n(v_x11_241797, 1ULL, 1);
              V v_m_241801 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_b_24785)}));
              V v_x1_241802 = heff_tr(heff_call(v_m_241801, 1, (V[]){v_st_241798}));
              switch (heff_tag_of(v_x1_241802)) {
              case TAG_MkPair: {
                V v_x11_241803 = heff_field(v_x1_241802, 0);
                V v_st_241804 = heff_field(v_x1_241802, 1);
                heff_take_n(v_x1_241802, 3ULL, 2);
                switch (heff_tag_of(v_x11_241803)) {
                case TAG_Left: {
                  V v_e_241805 = heff_field(v_x11_241803, 0);
                  heff_take_n(v_x11_241803, 1ULL, 1);
                  heff_drop_rec(v_kw_24780, 9);
                  heff_drop(v_b_24785);
                  heff_drop(v_x_241794);
                  heff_drop(v_x_241800);
                  return heff_tag_at_n(v_ru_24x1_241790_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241805}), v_st_241804});
                }
                case TAG_Right: {
                  V v_x_241806 = heff_field(v_x11_241803, 0);
                  heff_take_n(v_x11_241803, 1ULL, 1);
                  V v_t_241807 = (g_heff_2esyntax_2ecst_2elastE(v_b_24785));
                  V v_e_241808 = heff_get_n(v_t_241807, 4, 9);
                  V v_t_241809 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_24780, 3, 9), v_e_241808});
                  V v_x_241810 = (g_heff_2esyntax_2esurface_2eifE(v_t_241809, v_x_241794, v_x_241800, v_x_241806));
                  return heff_tag_at_n(v_ru_24x1_241790_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_241810}), v_st_241804});
                }
                default: return heff_nomatch(v_x11_241803);
                }
              }
              default: return heff_nomatch(v_x1_241802);
              }
            }
            default: return heff_nomatch(v_x11_241797);
            }
          }
          default: return heff_nomatch(v_x1_241796);
          }
        }
        default: return heff_nomatch(v_x11_241791);
        }
      }
      default: return heff_nomatch(v_x1_241790);
      }
    }
    default: return heff_nomatch(v_e02_24781);
    }
  }
  case TAG_Do: {
    V v_kw_241811 = heff_dup(heff_field(v_e0_241, 0));
    V v_stmts_241812 = heff_dup(heff_field(v_e0_241, 1));
    HeffT2 v_t_241814 = (g_heff_2esyntax_2esurface_2eblock_24cpr(heff_clo_n(g_heff_2esyntax_2esurface_2eexprL_lam8, 1, 1, (V[]){v_r_240}), v_stmts_241812, v_z_242));
    {
      V v_field_241815 = v_t_241814.f[0];
      V v_field_241816 = v_t_241814.f[1];
      V v_x11_241817 = v_field_241815;
      V v_st_241818 = v_field_241816;
      switch (heff_tag_of(v_x11_241817)) {
      case TAG_Left: {
        V v_e_241819 = heff_field(v_x11_241817, 0);
        V v_ru_24x11_241817_24Left = heff_take_reuse_n(v_x11_241817, 1ULL, 1);
        heff_drop_tag(v_e0_241, 2);
        heff_drop_rec(v_kw_241811, 9);
        return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_241817_24Left, TAG_Left, 1, (V[]){v_e_241819}), v_st_241818});
      }
      case TAG_Right: {
        V v_x_241820 = heff_field(v_x11_241817, 0);
        V v_ru_24x11_241817_24Right = heff_take_reuse_n(v_x11_241817, 1ULL, 1);
        V v_t_241821 = (g_heff_2esyntax_2ecst_2elastE(v_e0_241));
        V v_e_241822 = heff_get_n(v_t_241821, 4, 9);
        V v_t_241823 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_241811, 3, 9), v_e_241822});
        V v_x_241824 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EDo, 1, (V[]){v_x_241820}), v_t_241823});
        return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_241817_24Right, TAG_Right, 1, (V[]){v_x_241824}), v_st_241818});
      }
      default: return heff_nomatch(v_x11_241817);
      }
    }
  }
  case TAG_ESBind: {
    heff_drop_rec(v_r_240, 3);
    V v_t_241828 = (g_heff_2esyntax_2ecst_2efirstE(v_e0_241));
    V v_t_241829 = ({ V a_0 = v_e0_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e0_241, 3); r_; });
    V v_t_241830 = heff_strAppend(heff_get_n(v_t_241829, 1, 9), ((V)&g_heff_2esyntax_2esurface_2eexprL_str33));
    V v_msg_241831 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eexprL_str34), v_t_241830);
    V v_t_241832 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_241828, 3), heff_get_n(v_t_241828, 4, 9)});
    V v_t_241833 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_241831, v_t_241832, NTAG(TAG_Nothing)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_241833}), v_z_242});
  }
  case TAG_ELet: {
    HEFF_LAST return g_heff_2esyntax_2esurface_2eletL(v_r_240, v_e0_241, v_z_242);
  }
  case TAG_ELetMut: {
    heff_drop_rec(v_r_240, 3);
    V v_t_241846 = (g_heff_2esyntax_2ecst_2efirstE(v_e0_241));
    V v_t_241847 = ({ V a_0 = v_e0_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e0_241, 6); r_; });
    V v_t_241848 = heff_strAppend(heff_get_n(v_t_241847, 1, 9), ((V)&g_heff_2esyntax_2esurface_2eexprL_str35));
    V v_msg_241849 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eexprL_str36), v_t_241848);
    V v_t_241850 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_241846, 3), heff_get_n(v_t_241846, 4, 9)});
    V v_t_241851 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_241849, v_t_241850, NTAG(TAG_Nothing)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_241851}), v_z_242});
  }
  case TAG_EAssign: {
    V v_x_241852 = heff_field(v_e0_241, 0);
    V v_e_241854 = heff_field(v_e0_241, 2);
    V v_ru_24e0_241_24EAssign = heff_take_reuse_n(v_e0_241, 5ULL, 3);
    V v_m_241855 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_e_241854)}));
    V v_x1_241856 = heff_tr(heff_call(v_m_241855, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x1_241856)) {
    case TAG_MkPair: {
      V v_x11_241857 = heff_field(v_x1_241856, 0);
      V v_st_241858 = heff_field(v_x1_241856, 1);
      V v_ru_24x1_241856_24MkPair = heff_take_reuse_n(v_x1_241856, 3ULL, 2);
      switch (heff_tag_of(v_x11_241857)) {
      case TAG_Left: {
        V v_e_241859 = heff_field(v_x11_241857, 0);
        heff_take_n(v_x11_241857, 1ULL, 1);
        heff_drop_rec(v_x_241852, 9);
        heff_drop(v_e_241854);
        heff_drop_cell(v_ru_24e0_241_24EAssign, 3);
        return heff_tag_at_n(v_ru_24x1_241856_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241859}), v_st_241858});
      }
      case TAG_Right: {
        V v_x_241860 = heff_field(v_x11_241857, 0);
        heff_take_n(v_x11_241857, 1ULL, 1);
        V v_t_241861 = heff_rec_n(2, shape_start__end, (V[]){heff_dup(heff_rfield(v_x_241852, 3)), heff_take_field(v_x_241852, 4)});
        V v_t_241862 = heff_tag_at_n(v_ru_24e0_241_24EAssign, TAG_EAssign, 3, (V[]){heff_dup(heff_rfield(v_x_241852, 1)), v_t_241861, v_x_241860});
        V v_t_241863 = (g_heff_2esyntax_2ecst_2elastE(v_e_241854));
        V v_e_241864 = heff_get_n(v_t_241863, 4, 9);
        V v_t_241865 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_x_241852, 3, 9), v_e_241864});
        V v_x_241866 = heff_tag_n(TAG_At, 2, (V[]){v_t_241862, v_t_241865});
        return heff_tag_at_n(v_ru_24x1_241856_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_241866}), v_st_241858});
      }
      default: return heff_nomatch(v_x11_241857);
      }
    }
    default: return heff_nomatch(v_x1_241856);
    }
  }
  case TAG_EWhile: {
    V v_kw_241867 = heff_dup(heff_field(v_e0_241, 0));
    V v_c_241868 = heff_dup(heff_field(v_e0_241, 1));
    V v_body_241870 = heff_dup(heff_field(v_e0_241, 3));
    V v_m_241871 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_c_241868}));
    V v_x1_241872 = heff_tr(heff_call(v_m_241871, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x1_241872)) {
    case TAG_MkPair: {
      V v_x11_241873 = heff_field(v_x1_241872, 0);
      V v_st_241874 = heff_field(v_x1_241872, 1);
      V v_ru_24x1_241872_24MkPair = heff_take_reuse_n(v_x1_241872, 3ULL, 2);
      switch (heff_tag_of(v_x11_241873)) {
      case TAG_Left: {
        V v_e_241875 = heff_field(v_x11_241873, 0);
        heff_take_n(v_x11_241873, 1ULL, 1);
        heff_drop_rec(v_r_240, 3);
        heff_drop_tag(v_e0_241, 4);
        heff_drop_rec(v_kw_241867, 9);
        heff_drop(v_body_241870);
        return heff_tag_at_n(v_ru_24x1_241872_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241875}), v_st_241874});
      }
      case TAG_Right: {
        V v_x_241876 = heff_field(v_x11_241873, 0);
        heff_take_n(v_x11_241873, 1ULL, 1);
        HeffT2 v_t_241878 = (g_heff_2esyntax_2esurface_2eblock_24cpr(heff_clo_n(g_heff_2esyntax_2esurface_2eexprL_lam9, 1, 1, (V[]){v_r_240}), v_body_241870, v_st_241874));
        {
          V v_field_241879 = v_t_241878.f[0];
          V v_field_241880 = v_t_241878.f[1];
          V v_x11_241881 = v_field_241879;
          V v_st_241882 = v_field_241880;
          switch (heff_tag_of(v_x11_241881)) {
          case TAG_Left: {
            V v_e_241883 = heff_field(v_x11_241881, 0);
            heff_take_n(v_x11_241881, 1ULL, 1);
            heff_drop_tag(v_e0_241, 4);
            heff_drop_rec(v_kw_241867, 9);
            heff_drop(v_x_241876);
            return heff_tag_at_n(v_ru_24x1_241872_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241883}), v_st_241882});
          }
          case TAG_Right: {
            V v_x_241884 = heff_field(v_x11_241881, 0);
            heff_take_n(v_x11_241881, 1ULL, 1);
            V v_t_241885 = (g_heff_2esyntax_2ecst_2elastE(v_e0_241));
            V v_e_241886 = heff_get_n(v_t_241885, 4, 9);
            V v_t_241887 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_241867, 3, 9), v_e_241886});
            V v_x_241888 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EWhile, 2, (V[]){v_x_241876, v_x_241884}), v_t_241887});
            return heff_tag_at_n(v_ru_24x1_241872_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_241888}), v_st_241882});
          }
          default: return heff_nomatch(v_x11_241881);
          }
        }
      }
      default: return heff_nomatch(v_x11_241873);
      }
    }
    default: return heff_nomatch(v_x1_241872);
    }
  }
  case TAG_EFor: {
    V v_kw_241889 = heff_dup(heff_field(v_e0_241, 0));
    V v_p_241890 = heff_dup(heff_field(v_e0_241, 1));
    V v_c_241892 = heff_dup(heff_field(v_e0_241, 3));
    V v_body_241894 = heff_dup(heff_field(v_e0_241, 5));
    V v_m_241895 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_c_241892}));
    V v_x1_241896 = heff_tr(heff_call(v_m_241895, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x1_241896)) {
    case TAG_MkPair: {
      V v_x11_241897 = heff_field(v_x1_241896, 0);
      V v_st_241898 = heff_field(v_x1_241896, 1);
      V v_ru_24x1_241896_24MkPair = heff_take_reuse_n(v_x1_241896, 3ULL, 2);
      switch (heff_tag_of(v_x11_241897)) {
      case TAG_Left: {
        V v_e_241899 = heff_field(v_x11_241897, 0);
        heff_take_n(v_x11_241897, 1ULL, 1);
        heff_drop_rec(v_r_240, 3);
        heff_drop_tag(v_e0_241, 6);
        heff_drop_rec(v_kw_241889, 9);
        heff_drop(v_p_241890);
        heff_drop(v_body_241894);
        return heff_tag_at_n(v_ru_24x1_241896_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241899}), v_st_241898});
      }
      case TAG_Right: {
        V v_x_241900 = heff_field(v_x11_241897, 0);
        heff_take_n(v_x11_241897, 1ULL, 1);
        V v_m_241901 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 1)), 1, (V[]){heff_dup(v_p_241890)}));
        V v_x1_241902 = heff_tr(heff_call(v_m_241901, 1, (V[]){v_st_241898}));
        switch (heff_tag_of(v_x1_241902)) {
        case TAG_MkPair: {
          V v_x11_241903 = heff_field(v_x1_241902, 0);
          V v_st_241904 = heff_field(v_x1_241902, 1);
          V v_ru_24x1_241902_24MkPair = heff_take_reuse_n(v_x1_241902, 3ULL, 2);
          switch (heff_tag_of(v_x11_241903)) {
          case TAG_Left: {
            V v_e_241905 = heff_field(v_x11_241903, 0);
            heff_take_n(v_x11_241903, 1ULL, 1);
            heff_drop_rec(v_r_240, 3);
            heff_drop_tag(v_e0_241, 6);
            heff_drop_rec(v_kw_241889, 9);
            heff_drop(v_p_241890);
            heff_drop(v_body_241894);
            heff_drop(v_x_241900);
            heff_drop_cell(v_ru_24x1_241902_24MkPair, 2);
            return heff_tag_at_n(v_ru_24x1_241896_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241905}), v_st_241904});
          }
          case TAG_Right: {
            V v_x_241906 = heff_field(v_x11_241903, 0);
            heff_take_n(v_x11_241903, 1ULL, 1);
            V v_t_241907 = ({ V b_0 = NTAG(TAG_Nil); V a_1 = v_p_241890; V r_ = (g_heff_2esyntax_2esurface_2eboundBy(b_0, a_1)); heff_drop(b_0); heff_drop(v_p_241890); r_; });
            V v_t_241909 = heff_tr(heff_call(((V)&g_heff_2esyntax_2esurface_2eblock_clo), 2, (V[]){heff_clo_n(g_heff_2esyntax_2esurface_2eexprL_lam10, 1, 1, (V[]){v_r_240}), v_body_241894}));
            HeffT2 v_t_241910 = (g_heff_2esyntax_2esurface_2ewithScope_24cpr(v_t_241907, v_t_241909, v_st_241904));
            {
              V v_field_241911 = v_t_241910.f[0];
              V v_field_241912 = v_t_241910.f[1];
              V v_x11_241913 = v_field_241911;
              V v_st_241914 = v_field_241912;
              switch (heff_tag_of(v_x11_241913)) {
              case TAG_Left: {
                V v_e_241915 = heff_field(v_x11_241913, 0);
                heff_take_n(v_x11_241913, 1ULL, 1);
                heff_drop_tag(v_e0_241, 6);
                heff_drop_rec(v_kw_241889, 9);
                heff_drop(v_x_241900);
                heff_drop_cell(v_ru_24x1_241902_24MkPair, 2);
                heff_drop(v_x_241906);
                return heff_tag_at_n(v_ru_24x1_241896_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241915}), v_st_241914});
              }
              case TAG_Right: {
                V v_x_241916 = heff_field(v_x11_241913, 0);
                heff_take_n(v_x11_241913, 1ULL, 1);
                V v_t_241917 = (g_heff_2esyntax_2ecst_2elastE(v_e0_241));
                V v_e_241918 = heff_get_n(v_t_241917, 4, 9);
                V v_t_241919 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_241889, 3, 9), v_e_241918});
                V v_x_241920 = heff_tag_at_n(v_ru_24x1_241902_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_EFor, 3, (V[]){v_x_241906, v_x_241900, v_x_241916}), v_t_241919});
                return heff_tag_at_n(v_ru_24x1_241896_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_241920}), v_st_241914});
              }
              default: return heff_nomatch(v_x11_241913);
              }
            }
          }
          default: return heff_nomatch(v_x11_241903);
          }
        }
        default: return heff_nomatch(v_x1_241902);
        }
      }
      default: return heff_nomatch(v_x11_241897);
      }
    }
    default: return heff_nomatch(v_x1_241896);
    }
  }
  case TAG_EJump: {
    V v_kw_241921 = heff_field(v_e0_241, 0);
    V v_ru_24e0_241_24EJump = heff_take_reuse_n(v_e0_241, 1ULL, 1);
    heff_drop_rec(v_r_240, 3);
    V v_t_241923;
    if (heff_strEq_c(heff_dup(heff_rfield(v_kw_241921, 1)), ((V)&g_heff_2esyntax_2esurface_2eexprL_str37))) {
      v_t_241923 = NTAG(TAG_EBreak);
    } else {
      v_t_241923 = NTAG(TAG_EContinue);
    }
    V v_t_241924 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_kw_241921, 3), heff_get_n(v_kw_241921, 4, 9)});
    V v_t_241925 = heff_tag_at_n(v_ru_24e0_241_24EJump, TAG_Right, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_241923, v_t_241924})});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_241925, v_z_242});
  }
  case TAG_EReturn: {
    V v_kw_241926 = heff_field(v_e0_241, 0);
    V v_e_241927 = heff_field(v_e0_241, 1);
    V v_ru_24e0_241_24EReturn = heff_take_reuse_n(v_e0_241, 3ULL, 2);
    V v_m_241928 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_e_241927)}));
    V v_x1_241929 = heff_tr(heff_call(v_m_241928, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x1_241929)) {
    case TAG_MkPair: {
      V v_x11_241930 = heff_field(v_x1_241929, 0);
      V v_st_241931 = heff_field(v_x1_241929, 1);
      V v_ru_24x1_241929_24MkPair = heff_take_reuse_n(v_x1_241929, 3ULL, 2);
      switch (heff_tag_of(v_x11_241930)) {
      case TAG_Left: {
        V v_e_241932 = heff_field(v_x11_241930, 0);
        heff_take_n(v_x11_241930, 1ULL, 1);
        heff_drop_rec(v_kw_241926, 9);
        heff_drop(v_e_241927);
        heff_drop_cell(v_ru_24x1_241929_24MkPair, 2);
        return heff_tag_at_n(v_ru_24e0_241_24EReturn, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241932}), v_st_241931});
      }
      case TAG_Right: {
        V v_x_241933 = heff_field(v_x11_241930, 0);
        heff_take_n(v_x11_241930, 1ULL, 1);
        V v_t_241934 = (g_heff_2esyntax_2ecst_2elastE(v_e_241927));
        V v_e_241935 = heff_get_n(v_t_241934, 4, 9);
        V v_t_241936 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_241926, 3, 9), v_e_241935});
        V v_x_241937 = heff_tag_at_n(v_ru_24e0_241_24EReturn, TAG_At, 2, (V[]){heff_tag_n(TAG_EReturn, 1, (V[]){v_x_241933}), v_t_241936});
        return heff_tag_at_n(v_ru_24x1_241929_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_241937}), v_st_241931});
      }
      default: return heff_nomatch(v_x11_241930);
      }
    }
    default: return heff_nomatch(v_x1_241929);
    }
  }
  case TAG_ENest: {
    V v_o_241938 = heff_field(v_e0_241, 0);
    V v_e_241940 = heff_field(v_e0_241, 2);
    V v_c_241941 = heff_field(v_e0_241, 3);
    heff_take_n(v_e0_241, 13ULL, 4);
    V v_m_241942 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_241940}));
    V v_x1_241943 = heff_tr(heff_call(v_m_241942, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x1_241943)) {
    case TAG_MkPair: {
      V v_x11_241944 = heff_field(v_x1_241943, 0);
      V v_st_241945 = heff_field(v_x1_241943, 1);
      V v_ru_24x1_241943_24MkPair = heff_take_reuse_n(v_x1_241943, 3ULL, 2);
      switch (heff_tag_of(v_x11_241944)) {
      case TAG_Left: {
        V v_e_241946 = heff_field(v_x11_241944, 0);
        heff_take_n(v_x11_241944, 1ULL, 1);
        heff_drop_rec(v_o_241938, 9);
        heff_drop_rec(v_c_241941, 9);
        return heff_tag_at_n(v_ru_24x1_241943_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241946}), v_st_241945});
      }
      case TAG_Right: {
        V v_x_241947 = heff_field(v_x11_241944, 0);
        V v_ru_24x11_241944_24Right = heff_take_reuse_n(v_x11_241944, 1ULL, 1);
        V v_t_241948 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_o_241938, 3, 9), heff_get_n(v_c_241941, 4, 9)});
        V v_t_241949 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_241944_24Right, TAG_ENest, 1, (V[]){v_x_241947}), v_t_241948});
        return heff_tag_at_n(v_ru_24x1_241943_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_241949}), v_st_241945});
      }
      default: return heff_nomatch(v_x11_241944);
      }
    }
    default: return heff_nomatch(v_x1_241943);
    }
  }
  case TAG_IfThen: {
    V v_kw_241950 = heff_field(v_e0_241, 0);
    V v_e02_241951 = heff_field(v_e0_241, 1);
    V v_a_241953 = heff_field(v_e0_241, 3);
    heff_take_n(v_e0_241, 11ULL, 4);
    switch (heff_tag_of(v_e02_241951)) {
    case TAG_Atom: {
      V v_m_241955 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_241951}));
      V v_x1_241956 = heff_tr(heff_call(v_m_241955, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_241956)) {
      case TAG_MkPair: {
        V v_x11_241957 = heff_field(v_x1_241956, 0);
        V v_st_241958 = heff_field(v_x1_241956, 1);
        V v_ru_24x1_241956_24MkPair = heff_take_reuse_n(v_x1_241956, 3ULL, 2);
        switch (heff_tag_of(v_x11_241957)) {
        case TAG_Left: {
          V v_e_241959 = heff_field(v_x11_241957, 0);
          heff_take_n(v_x11_241957, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_241950, 9);
          heff_drop(v_a_241953);
          return heff_tag_at_n(v_ru_24x1_241956_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241959}), v_st_241958});
        }
        case TAG_Right: {
          V v_x_241960 = heff_field(v_x11_241957, 0);
          heff_take_n(v_x11_241957, 1ULL, 1);
          V v_m_241961 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_a_241953)}));
          V v_x1_241962 = heff_tr(heff_call(v_m_241961, 1, (V[]){v_st_241958}));
          switch (heff_tag_of(v_x1_241962)) {
          case TAG_MkPair: {
            V v_x11_241963 = heff_field(v_x1_241962, 0);
            V v_st_241964 = heff_field(v_x1_241962, 1);
            V v_ru_24x1_241962_24MkPair = heff_take_reuse_n(v_x1_241962, 3ULL, 2);
            switch (heff_tag_of(v_x11_241963)) {
            case TAG_Left: {
              V v_e_241965 = heff_field(v_x11_241963, 0);
              heff_take_n(v_x11_241963, 1ULL, 1);
              heff_drop_rec(v_kw_241950, 9);
              heff_drop(v_a_241953);
              heff_drop(v_x_241960);
              heff_drop_cell(v_ru_24x1_241962_24MkPair, 2);
              return heff_tag_at_n(v_ru_24x1_241956_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241965}), v_st_241964});
            }
            case TAG_Right: {
              V v_x_241966 = heff_field(v_x11_241963, 0);
              heff_take_n(v_x11_241963, 1ULL, 1);
              V v_t_241967 = (g_heff_2esyntax_2ecst_2elastE(v_a_241953));
              V v_e_241968 = heff_get_n(v_t_241967, 4, 9);
              V v_t_241969 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_241950, 3, 9), v_e_241968});
              V v_x_241970 = heff_tag_at_n(v_ru_24x1_241962_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_EIfThen, 2, (V[]){v_x_241960, v_x_241966}), v_t_241969});
              return heff_tag_at_n(v_ru_24x1_241956_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_241970}), v_st_241964});
            }
            default: return heff_nomatch(v_x11_241963);
            }
          }
          default: return heff_nomatch(v_x1_241962);
          }
        }
        default: return heff_nomatch(v_x11_241957);
        }
      }
      default: return heff_nomatch(v_x1_241956);
      }
    }
    case TAG_EParen: {
      V v_m_241974 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_241951}));
      V v_x1_241975 = heff_tr(heff_call(v_m_241974, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_241975)) {
      case TAG_MkPair: {
        V v_x11_241976 = heff_field(v_x1_241975, 0);
        V v_st_241977 = heff_field(v_x1_241975, 1);
        V v_ru_24x1_241975_24MkPair = heff_take_reuse_n(v_x1_241975, 3ULL, 2);
        switch (heff_tag_of(v_x11_241976)) {
        case TAG_Left: {
          V v_e_241978 = heff_field(v_x11_241976, 0);
          heff_take_n(v_x11_241976, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_241950, 9);
          heff_drop(v_a_241953);
          return heff_tag_at_n(v_ru_24x1_241975_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241978}), v_st_241977});
        }
        case TAG_Right: {
          V v_x_241979 = heff_field(v_x11_241976, 0);
          heff_take_n(v_x11_241976, 1ULL, 1);
          V v_m_241980 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_a_241953)}));
          V v_x1_241981 = heff_tr(heff_call(v_m_241980, 1, (V[]){v_st_241977}));
          switch (heff_tag_of(v_x1_241981)) {
          case TAG_MkPair: {
            V v_x11_241982 = heff_field(v_x1_241981, 0);
            V v_st_241983 = heff_field(v_x1_241981, 1);
            V v_ru_24x1_241981_24MkPair = heff_take_reuse_n(v_x1_241981, 3ULL, 2);
            switch (heff_tag_of(v_x11_241982)) {
            case TAG_Left: {
              V v_e_241984 = heff_field(v_x11_241982, 0);
              heff_take_n(v_x11_241982, 1ULL, 1);
              heff_drop_rec(v_kw_241950, 9);
              heff_drop(v_a_241953);
              heff_drop(v_x_241979);
              heff_drop_cell(v_ru_24x1_241981_24MkPair, 2);
              return heff_tag_at_n(v_ru_24x1_241975_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241984}), v_st_241983});
            }
            case TAG_Right: {
              V v_x_241985 = heff_field(v_x11_241982, 0);
              heff_take_n(v_x11_241982, 1ULL, 1);
              V v_t_241986 = (g_heff_2esyntax_2ecst_2elastE(v_a_241953));
              V v_e_241987 = heff_get_n(v_t_241986, 4, 9);
              V v_t_241988 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_241950, 3, 9), v_e_241987});
              V v_x_241989 = heff_tag_at_n(v_ru_24x1_241981_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_EIfThen, 2, (V[]){v_x_241979, v_x_241985}), v_t_241988});
              return heff_tag_at_n(v_ru_24x1_241975_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_241989}), v_st_241983});
            }
            default: return heff_nomatch(v_x11_241982);
            }
          }
          default: return heff_nomatch(v_x1_241981);
          }
        }
        default: return heff_nomatch(v_x11_241976);
        }
      }
      default: return heff_nomatch(v_x1_241975);
      }
    }
    case TAG_Named: {
      V v_m_241995 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_241951}));
      V v_x1_241996 = heff_tr(heff_call(v_m_241995, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_241996)) {
      case TAG_MkPair: {
        V v_x11_241997 = heff_field(v_x1_241996, 0);
        V v_st_241998 = heff_field(v_x1_241996, 1);
        V v_ru_24x1_241996_24MkPair = heff_take_reuse_n(v_x1_241996, 3ULL, 2);
        switch (heff_tag_of(v_x11_241997)) {
        case TAG_Left: {
          V v_e_241999 = heff_field(v_x11_241997, 0);
          heff_take_n(v_x11_241997, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_241950, 9);
          heff_drop(v_a_241953);
          return heff_tag_at_n(v_ru_24x1_241996_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241999}), v_st_241998});
        }
        case TAG_Right: {
          V v_x_242000 = heff_field(v_x11_241997, 0);
          heff_take_n(v_x11_241997, 1ULL, 1);
          V v_m_242001 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_a_241953)}));
          V v_x1_242002 = heff_tr(heff_call(v_m_242001, 1, (V[]){v_st_241998}));
          switch (heff_tag_of(v_x1_242002)) {
          case TAG_MkPair: {
            V v_x11_242003 = heff_field(v_x1_242002, 0);
            V v_st_242004 = heff_field(v_x1_242002, 1);
            V v_ru_24x1_242002_24MkPair = heff_take_reuse_n(v_x1_242002, 3ULL, 2);
            switch (heff_tag_of(v_x11_242003)) {
            case TAG_Left: {
              V v_e_242005 = heff_field(v_x11_242003, 0);
              heff_take_n(v_x11_242003, 1ULL, 1);
              heff_drop_rec(v_kw_241950, 9);
              heff_drop(v_a_241953);
              heff_drop(v_x_242000);
              heff_drop_cell(v_ru_24x1_242002_24MkPair, 2);
              return heff_tag_at_n(v_ru_24x1_241996_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242005}), v_st_242004});
            }
            case TAG_Right: {
              V v_x_242006 = heff_field(v_x11_242003, 0);
              heff_take_n(v_x11_242003, 1ULL, 1);
              V v_t_242007 = (g_heff_2esyntax_2ecst_2elastE(v_a_241953));
              V v_e_242008 = heff_get_n(v_t_242007, 4, 9);
              V v_t_242009 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_241950, 3, 9), v_e_242008});
              V v_x_242010 = heff_tag_at_n(v_ru_24x1_242002_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_EIfThen, 2, (V[]){v_x_242000, v_x_242006}), v_t_242009});
              return heff_tag_at_n(v_ru_24x1_241996_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_242010}), v_st_242004});
            }
            default: return heff_nomatch(v_x11_242003);
            }
          }
          default: return heff_nomatch(v_x1_242002);
          }
        }
        default: return heff_nomatch(v_x11_241997);
        }
      }
      default: return heff_nomatch(v_x1_241996);
      }
    }
    case TAG_Tup: {
      V v_m_242015 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_241951}));
      V v_x1_242016 = heff_tr(heff_call(v_m_242015, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_242016)) {
      case TAG_MkPair: {
        V v_x11_242017 = heff_field(v_x1_242016, 0);
        V v_st_242018 = heff_field(v_x1_242016, 1);
        V v_ru_24x1_242016_24MkPair = heff_take_reuse_n(v_x1_242016, 3ULL, 2);
        switch (heff_tag_of(v_x11_242017)) {
        case TAG_Left: {
          V v_e_242019 = heff_field(v_x11_242017, 0);
          heff_take_n(v_x11_242017, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_241950, 9);
          heff_drop(v_a_241953);
          return heff_tag_at_n(v_ru_24x1_242016_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242019}), v_st_242018});
        }
        case TAG_Right: {
          V v_x_242020 = heff_field(v_x11_242017, 0);
          heff_take_n(v_x11_242017, 1ULL, 1);
          V v_m_242021 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_a_241953)}));
          V v_x1_242022 = heff_tr(heff_call(v_m_242021, 1, (V[]){v_st_242018}));
          switch (heff_tag_of(v_x1_242022)) {
          case TAG_MkPair: {
            V v_x11_242023 = heff_field(v_x1_242022, 0);
            V v_st_242024 = heff_field(v_x1_242022, 1);
            V v_ru_24x1_242022_24MkPair = heff_take_reuse_n(v_x1_242022, 3ULL, 2);
            switch (heff_tag_of(v_x11_242023)) {
            case TAG_Left: {
              V v_e_242025 = heff_field(v_x11_242023, 0);
              heff_take_n(v_x11_242023, 1ULL, 1);
              heff_drop_rec(v_kw_241950, 9);
              heff_drop(v_a_241953);
              heff_drop(v_x_242020);
              heff_drop_cell(v_ru_24x1_242022_24MkPair, 2);
              return heff_tag_at_n(v_ru_24x1_242016_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242025}), v_st_242024});
            }
            case TAG_Right: {
              V v_x_242026 = heff_field(v_x11_242023, 0);
              heff_take_n(v_x11_242023, 1ULL, 1);
              V v_t_242027 = (g_heff_2esyntax_2ecst_2elastE(v_a_241953));
              V v_e_242028 = heff_get_n(v_t_242027, 4, 9);
              V v_t_242029 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_241950, 3, 9), v_e_242028});
              V v_x_242030 = heff_tag_at_n(v_ru_24x1_242022_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_EIfThen, 2, (V[]){v_x_242020, v_x_242026}), v_t_242029});
              return heff_tag_at_n(v_ru_24x1_242016_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_242030}), v_st_242024});
            }
            default: return heff_nomatch(v_x11_242023);
            }
          }
          default: return heff_nomatch(v_x1_242022);
          }
        }
        default: return heff_nomatch(v_x11_242017);
        }
      }
      default: return heff_nomatch(v_x1_242016);
      }
    }
    case TAG_Seg: {
      V v_m_242034 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_241951}));
      V v_x1_242035 = heff_tr(heff_call(v_m_242034, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_242035)) {
      case TAG_MkPair: {
        V v_x11_242036 = heff_field(v_x1_242035, 0);
        V v_st_242037 = heff_field(v_x1_242035, 1);
        V v_ru_24x1_242035_24MkPair = heff_take_reuse_n(v_x1_242035, 3ULL, 2);
        switch (heff_tag_of(v_x11_242036)) {
        case TAG_Left: {
          V v_e_242038 = heff_field(v_x11_242036, 0);
          heff_take_n(v_x11_242036, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_241950, 9);
          heff_drop(v_a_241953);
          return heff_tag_at_n(v_ru_24x1_242035_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242038}), v_st_242037});
        }
        case TAG_Right: {
          V v_x_242039 = heff_field(v_x11_242036, 0);
          heff_take_n(v_x11_242036, 1ULL, 1);
          V v_m_242040 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_a_241953)}));
          V v_x1_242041 = heff_tr(heff_call(v_m_242040, 1, (V[]){v_st_242037}));
          switch (heff_tag_of(v_x1_242041)) {
          case TAG_MkPair: {
            V v_x11_242042 = heff_field(v_x1_242041, 0);
            V v_st_242043 = heff_field(v_x1_242041, 1);
            V v_ru_24x1_242041_24MkPair = heff_take_reuse_n(v_x1_242041, 3ULL, 2);
            switch (heff_tag_of(v_x11_242042)) {
            case TAG_Left: {
              V v_e_242044 = heff_field(v_x11_242042, 0);
              heff_take_n(v_x11_242042, 1ULL, 1);
              heff_drop_rec(v_kw_241950, 9);
              heff_drop(v_a_241953);
              heff_drop(v_x_242039);
              heff_drop_cell(v_ru_24x1_242041_24MkPair, 2);
              return heff_tag_at_n(v_ru_24x1_242035_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242044}), v_st_242043});
            }
            case TAG_Right: {
              V v_x_242045 = heff_field(v_x11_242042, 0);
              heff_take_n(v_x11_242042, 1ULL, 1);
              V v_t_242046 = (g_heff_2esyntax_2ecst_2elastE(v_a_241953));
              V v_e_242047 = heff_get_n(v_t_242046, 4, 9);
              V v_t_242048 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_241950, 3, 9), v_e_242047});
              V v_x_242049 = heff_tag_at_n(v_ru_24x1_242041_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_EIfThen, 2, (V[]){v_x_242039, v_x_242045}), v_t_242048});
              return heff_tag_at_n(v_ru_24x1_242035_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_242049}), v_st_242043});
            }
            default: return heff_nomatch(v_x11_242042);
            }
          }
          default: return heff_nomatch(v_x1_242041);
          }
        }
        default: return heff_nomatch(v_x11_242036);
        }
      }
      default: return heff_nomatch(v_x1_242035);
      }
    }
    case TAG_Braces: {
      V v_m_242054 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_241951}));
      V v_x1_242055 = heff_tr(heff_call(v_m_242054, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_242055)) {
      case TAG_MkPair: {
        V v_x11_242056 = heff_field(v_x1_242055, 0);
        V v_st_242057 = heff_field(v_x1_242055, 1);
        V v_ru_24x1_242055_24MkPair = heff_take_reuse_n(v_x1_242055, 3ULL, 2);
        switch (heff_tag_of(v_x11_242056)) {
        case TAG_Left: {
          V v_e_242058 = heff_field(v_x11_242056, 0);
          heff_take_n(v_x11_242056, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_241950, 9);
          heff_drop(v_a_241953);
          return heff_tag_at_n(v_ru_24x1_242055_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242058}), v_st_242057});
        }
        case TAG_Right: {
          V v_x_242059 = heff_field(v_x11_242056, 0);
          heff_take_n(v_x11_242056, 1ULL, 1);
          V v_m_242060 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_a_241953)}));
          V v_x1_242061 = heff_tr(heff_call(v_m_242060, 1, (V[]){v_st_242057}));
          switch (heff_tag_of(v_x1_242061)) {
          case TAG_MkPair: {
            V v_x11_242062 = heff_field(v_x1_242061, 0);
            V v_st_242063 = heff_field(v_x1_242061, 1);
            V v_ru_24x1_242061_24MkPair = heff_take_reuse_n(v_x1_242061, 3ULL, 2);
            switch (heff_tag_of(v_x11_242062)) {
            case TAG_Left: {
              V v_e_242064 = heff_field(v_x11_242062, 0);
              heff_take_n(v_x11_242062, 1ULL, 1);
              heff_drop_rec(v_kw_241950, 9);
              heff_drop(v_a_241953);
              heff_drop(v_x_242059);
              heff_drop_cell(v_ru_24x1_242061_24MkPair, 2);
              return heff_tag_at_n(v_ru_24x1_242055_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242064}), v_st_242063});
            }
            case TAG_Right: {
              V v_x_242065 = heff_field(v_x11_242062, 0);
              heff_take_n(v_x11_242062, 1ULL, 1);
              V v_t_242066 = (g_heff_2esyntax_2ecst_2elastE(v_a_241953));
              V v_e_242067 = heff_get_n(v_t_242066, 4, 9);
              V v_t_242068 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_241950, 3, 9), v_e_242067});
              V v_x_242069 = heff_tag_at_n(v_ru_24x1_242061_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_EIfThen, 2, (V[]){v_x_242059, v_x_242065}), v_t_242068});
              return heff_tag_at_n(v_ru_24x1_242055_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_242069}), v_st_242063});
            }
            default: return heff_nomatch(v_x11_242062);
            }
          }
          default: return heff_nomatch(v_x1_242061);
          }
        }
        default: return heff_nomatch(v_x11_242056);
        }
      }
      default: return heff_nomatch(v_x1_242055);
      }
    }
    case TAG_Update: {
      V v_m_242076 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_241951}));
      V v_x1_242077 = heff_tr(heff_call(v_m_242076, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_242077)) {
      case TAG_MkPair: {
        V v_x11_242078 = heff_field(v_x1_242077, 0);
        V v_st_242079 = heff_field(v_x1_242077, 1);
        V v_ru_24x1_242077_24MkPair = heff_take_reuse_n(v_x1_242077, 3ULL, 2);
        switch (heff_tag_of(v_x11_242078)) {
        case TAG_Left: {
          V v_e_242080 = heff_field(v_x11_242078, 0);
          heff_take_n(v_x11_242078, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_241950, 9);
          heff_drop(v_a_241953);
          return heff_tag_at_n(v_ru_24x1_242077_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242080}), v_st_242079});
        }
        case TAG_Right: {
          V v_x_242081 = heff_field(v_x11_242078, 0);
          heff_take_n(v_x11_242078, 1ULL, 1);
          V v_m_242082 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_a_241953)}));
          V v_x1_242083 = heff_tr(heff_call(v_m_242082, 1, (V[]){v_st_242079}));
          switch (heff_tag_of(v_x1_242083)) {
          case TAG_MkPair: {
            V v_x11_242084 = heff_field(v_x1_242083, 0);
            V v_st_242085 = heff_field(v_x1_242083, 1);
            V v_ru_24x1_242083_24MkPair = heff_take_reuse_n(v_x1_242083, 3ULL, 2);
            switch (heff_tag_of(v_x11_242084)) {
            case TAG_Left: {
              V v_e_242086 = heff_field(v_x11_242084, 0);
              heff_take_n(v_x11_242084, 1ULL, 1);
              heff_drop_rec(v_kw_241950, 9);
              heff_drop(v_a_241953);
              heff_drop(v_x_242081);
              heff_drop_cell(v_ru_24x1_242083_24MkPair, 2);
              return heff_tag_at_n(v_ru_24x1_242077_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242086}), v_st_242085});
            }
            case TAG_Right: {
              V v_x_242087 = heff_field(v_x11_242084, 0);
              heff_take_n(v_x11_242084, 1ULL, 1);
              V v_t_242088 = (g_heff_2esyntax_2ecst_2elastE(v_a_241953));
              V v_e_242089 = heff_get_n(v_t_242088, 4, 9);
              V v_t_242090 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_241950, 3, 9), v_e_242089});
              V v_x_242091 = heff_tag_at_n(v_ru_24x1_242083_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_EIfThen, 2, (V[]){v_x_242081, v_x_242087}), v_t_242090});
              return heff_tag_at_n(v_ru_24x1_242077_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_242091}), v_st_242085});
            }
            default: return heff_nomatch(v_x11_242084);
            }
          }
          default: return heff_nomatch(v_x1_242083);
          }
        }
        default: return heff_nomatch(v_x11_242078);
        }
      }
      default: return heff_nomatch(v_x1_242077);
      }
    }
    case TAG_EUSet: {
      V v_m_242095 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_241951}));
      V v_x1_242096 = heff_tr(heff_call(v_m_242095, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_242096)) {
      case TAG_MkPair: {
        V v_x11_242097 = heff_field(v_x1_242096, 0);
        V v_st_242098 = heff_field(v_x1_242096, 1);
        V v_ru_24x1_242096_24MkPair = heff_take_reuse_n(v_x1_242096, 3ULL, 2);
        switch (heff_tag_of(v_x11_242097)) {
        case TAG_Left: {
          V v_e_242099 = heff_field(v_x11_242097, 0);
          heff_take_n(v_x11_242097, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_241950, 9);
          heff_drop(v_a_241953);
          return heff_tag_at_n(v_ru_24x1_242096_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242099}), v_st_242098});
        }
        case TAG_Right: {
          V v_x_242100 = heff_field(v_x11_242097, 0);
          heff_take_n(v_x11_242097, 1ULL, 1);
          V v_m_242101 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_a_241953)}));
          V v_x1_242102 = heff_tr(heff_call(v_m_242101, 1, (V[]){v_st_242098}));
          switch (heff_tag_of(v_x1_242102)) {
          case TAG_MkPair: {
            V v_x11_242103 = heff_field(v_x1_242102, 0);
            V v_st_242104 = heff_field(v_x1_242102, 1);
            V v_ru_24x1_242102_24MkPair = heff_take_reuse_n(v_x1_242102, 3ULL, 2);
            switch (heff_tag_of(v_x11_242103)) {
            case TAG_Left: {
              V v_e_242105 = heff_field(v_x11_242103, 0);
              heff_take_n(v_x11_242103, 1ULL, 1);
              heff_drop_rec(v_kw_241950, 9);
              heff_drop(v_a_241953);
              heff_drop(v_x_242100);
              heff_drop_cell(v_ru_24x1_242102_24MkPair, 2);
              return heff_tag_at_n(v_ru_24x1_242096_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242105}), v_st_242104});
            }
            case TAG_Right: {
              V v_x_242106 = heff_field(v_x11_242103, 0);
              heff_take_n(v_x11_242103, 1ULL, 1);
              V v_t_242107 = (g_heff_2esyntax_2ecst_2elastE(v_a_241953));
              V v_e_242108 = heff_get_n(v_t_242107, 4, 9);
              V v_t_242109 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_241950, 3, 9), v_e_242108});
              V v_x_242110 = heff_tag_at_n(v_ru_24x1_242102_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_EIfThen, 2, (V[]){v_x_242100, v_x_242106}), v_t_242109});
              return heff_tag_at_n(v_ru_24x1_242096_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_242110}), v_st_242104});
            }
            default: return heff_nomatch(v_x11_242103);
            }
          }
          default: return heff_nomatch(v_x1_242102);
          }
        }
        default: return heff_nomatch(v_x11_242097);
        }
      }
      default: return heff_nomatch(v_x1_242096);
      }
    }
    case TAG_InstB: {
      V v_m_242116 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_241951}));
      V v_x1_242117 = heff_tr(heff_call(v_m_242116, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_242117)) {
      case TAG_MkPair: {
        V v_x11_242118 = heff_field(v_x1_242117, 0);
        V v_st_242119 = heff_field(v_x1_242117, 1);
        V v_ru_24x1_242117_24MkPair = heff_take_reuse_n(v_x1_242117, 3ULL, 2);
        switch (heff_tag_of(v_x11_242118)) {
        case TAG_Left: {
          V v_e_242120 = heff_field(v_x11_242118, 0);
          heff_take_n(v_x11_242118, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_241950, 9);
          heff_drop(v_a_241953);
          return heff_tag_at_n(v_ru_24x1_242117_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242120}), v_st_242119});
        }
        case TAG_Right: {
          V v_x_242121 = heff_field(v_x11_242118, 0);
          heff_take_n(v_x11_242118, 1ULL, 1);
          V v_m_242122 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_a_241953)}));
          V v_x1_242123 = heff_tr(heff_call(v_m_242122, 1, (V[]){v_st_242119}));
          switch (heff_tag_of(v_x1_242123)) {
          case TAG_MkPair: {
            V v_x11_242124 = heff_field(v_x1_242123, 0);
            V v_st_242125 = heff_field(v_x1_242123, 1);
            V v_ru_24x1_242123_24MkPair = heff_take_reuse_n(v_x1_242123, 3ULL, 2);
            switch (heff_tag_of(v_x11_242124)) {
            case TAG_Left: {
              V v_e_242126 = heff_field(v_x11_242124, 0);
              heff_take_n(v_x11_242124, 1ULL, 1);
              heff_drop_rec(v_kw_241950, 9);
              heff_drop(v_a_241953);
              heff_drop(v_x_242121);
              heff_drop_cell(v_ru_24x1_242123_24MkPair, 2);
              return heff_tag_at_n(v_ru_24x1_242117_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242126}), v_st_242125});
            }
            case TAG_Right: {
              V v_x_242127 = heff_field(v_x11_242124, 0);
              heff_take_n(v_x11_242124, 1ULL, 1);
              V v_t_242128 = (g_heff_2esyntax_2ecst_2elastE(v_a_241953));
              V v_e_242129 = heff_get_n(v_t_242128, 4, 9);
              V v_t_242130 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_241950, 3, 9), v_e_242129});
              V v_x_242131 = heff_tag_at_n(v_ru_24x1_242123_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_EIfThen, 2, (V[]){v_x_242121, v_x_242127}), v_t_242130});
              return heff_tag_at_n(v_ru_24x1_242117_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_242131}), v_st_242125});
            }
            default: return heff_nomatch(v_x11_242124);
            }
          }
          default: return heff_nomatch(v_x1_242123);
          }
        }
        default: return heff_nomatch(v_x11_242118);
        }
      }
      default: return heff_nomatch(v_x1_242117);
      }
    }
    case TAG_EFSet: {
      V v_m_242135 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_241951}));
      V v_x1_242136 = heff_tr(heff_call(v_m_242135, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_242136)) {
      case TAG_MkPair: {
        V v_x11_242137 = heff_field(v_x1_242136, 0);
        V v_st_242138 = heff_field(v_x1_242136, 1);
        V v_ru_24x1_242136_24MkPair = heff_take_reuse_n(v_x1_242136, 3ULL, 2);
        switch (heff_tag_of(v_x11_242137)) {
        case TAG_Left: {
          V v_e_242139 = heff_field(v_x11_242137, 0);
          heff_take_n(v_x11_242137, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_241950, 9);
          heff_drop(v_a_241953);
          return heff_tag_at_n(v_ru_24x1_242136_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242139}), v_st_242138});
        }
        case TAG_Right: {
          V v_x_242140 = heff_field(v_x11_242137, 0);
          heff_take_n(v_x11_242137, 1ULL, 1);
          V v_m_242141 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_a_241953)}));
          V v_x1_242142 = heff_tr(heff_call(v_m_242141, 1, (V[]){v_st_242138}));
          switch (heff_tag_of(v_x1_242142)) {
          case TAG_MkPair: {
            V v_x11_242143 = heff_field(v_x1_242142, 0);
            V v_st_242144 = heff_field(v_x1_242142, 1);
            V v_ru_24x1_242142_24MkPair = heff_take_reuse_n(v_x1_242142, 3ULL, 2);
            switch (heff_tag_of(v_x11_242143)) {
            case TAG_Left: {
              V v_e_242145 = heff_field(v_x11_242143, 0);
              heff_take_n(v_x11_242143, 1ULL, 1);
              heff_drop_rec(v_kw_241950, 9);
              heff_drop(v_a_241953);
              heff_drop(v_x_242140);
              heff_drop_cell(v_ru_24x1_242142_24MkPair, 2);
              return heff_tag_at_n(v_ru_24x1_242136_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242145}), v_st_242144});
            }
            case TAG_Right: {
              V v_x_242146 = heff_field(v_x11_242143, 0);
              heff_take_n(v_x11_242143, 1ULL, 1);
              V v_t_242147 = (g_heff_2esyntax_2ecst_2elastE(v_a_241953));
              V v_e_242148 = heff_get_n(v_t_242147, 4, 9);
              V v_t_242149 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_241950, 3, 9), v_e_242148});
              V v_x_242150 = heff_tag_at_n(v_ru_24x1_242142_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_EIfThen, 2, (V[]){v_x_242140, v_x_242146}), v_t_242149});
              return heff_tag_at_n(v_ru_24x1_242136_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_242150}), v_st_242144});
            }
            default: return heff_nomatch(v_x11_242143);
            }
          }
          default: return heff_nomatch(v_x1_242142);
          }
        }
        default: return heff_nomatch(v_x11_242137);
        }
      }
      default: return heff_nomatch(v_x1_242136);
      }
    }
    case TAG_EFDefault: {
      V v_m_242154 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_241951}));
      V v_x1_242155 = heff_tr(heff_call(v_m_242154, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_242155)) {
      case TAG_MkPair: {
        V v_x11_242156 = heff_field(v_x1_242155, 0);
        V v_st_242157 = heff_field(v_x1_242155, 1);
        V v_ru_24x1_242155_24MkPair = heff_take_reuse_n(v_x1_242155, 3ULL, 2);
        switch (heff_tag_of(v_x11_242156)) {
        case TAG_Left: {
          V v_e_242158 = heff_field(v_x11_242156, 0);
          heff_take_n(v_x11_242156, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_241950, 9);
          heff_drop(v_a_241953);
          return heff_tag_at_n(v_ru_24x1_242155_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242158}), v_st_242157});
        }
        case TAG_Right: {
          V v_x_242159 = heff_field(v_x11_242156, 0);
          heff_take_n(v_x11_242156, 1ULL, 1);
          V v_m_242160 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_a_241953)}));
          V v_x1_242161 = heff_tr(heff_call(v_m_242160, 1, (V[]){v_st_242157}));
          switch (heff_tag_of(v_x1_242161)) {
          case TAG_MkPair: {
            V v_x11_242162 = heff_field(v_x1_242161, 0);
            V v_st_242163 = heff_field(v_x1_242161, 1);
            V v_ru_24x1_242161_24MkPair = heff_take_reuse_n(v_x1_242161, 3ULL, 2);
            switch (heff_tag_of(v_x11_242162)) {
            case TAG_Left: {
              V v_e_242164 = heff_field(v_x11_242162, 0);
              heff_take_n(v_x11_242162, 1ULL, 1);
              heff_drop_rec(v_kw_241950, 9);
              heff_drop(v_a_241953);
              heff_drop(v_x_242159);
              heff_drop_cell(v_ru_24x1_242161_24MkPair, 2);
              return heff_tag_at_n(v_ru_24x1_242155_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242164}), v_st_242163});
            }
            case TAG_Right: {
              V v_x_242165 = heff_field(v_x11_242162, 0);
              heff_take_n(v_x11_242162, 1ULL, 1);
              V v_t_242166 = (g_heff_2esyntax_2ecst_2elastE(v_a_241953));
              V v_e_242167 = heff_get_n(v_t_242166, 4, 9);
              V v_t_242168 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_241950, 3, 9), v_e_242167});
              V v_x_242169 = heff_tag_at_n(v_ru_24x1_242161_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_EIfThen, 2, (V[]){v_x_242159, v_x_242165}), v_t_242168});
              return heff_tag_at_n(v_ru_24x1_242155_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_242169}), v_st_242163});
            }
            default: return heff_nomatch(v_x11_242162);
            }
          }
          default: return heff_nomatch(v_x1_242161);
          }
        }
        default: return heff_nomatch(v_x11_242156);
        }
      }
      default: return heff_nomatch(v_x1_242155);
      }
    }
    case TAG_Sum: {
      V v_m_242175 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_241951}));
      V v_x1_242176 = heff_tr(heff_call(v_m_242175, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_242176)) {
      case TAG_MkPair: {
        V v_x11_242177 = heff_field(v_x1_242176, 0);
        V v_st_242178 = heff_field(v_x1_242176, 1);
        V v_ru_24x1_242176_24MkPair = heff_take_reuse_n(v_x1_242176, 3ULL, 2);
        switch (heff_tag_of(v_x11_242177)) {
        case TAG_Left: {
          V v_e_242179 = heff_field(v_x11_242177, 0);
          heff_take_n(v_x11_242177, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_241950, 9);
          heff_drop(v_a_241953);
          return heff_tag_at_n(v_ru_24x1_242176_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242179}), v_st_242178});
        }
        case TAG_Right: {
          V v_x_242180 = heff_field(v_x11_242177, 0);
          heff_take_n(v_x11_242177, 1ULL, 1);
          V v_m_242181 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_a_241953)}));
          V v_x1_242182 = heff_tr(heff_call(v_m_242181, 1, (V[]){v_st_242178}));
          switch (heff_tag_of(v_x1_242182)) {
          case TAG_MkPair: {
            V v_x11_242183 = heff_field(v_x1_242182, 0);
            V v_st_242184 = heff_field(v_x1_242182, 1);
            V v_ru_24x1_242182_24MkPair = heff_take_reuse_n(v_x1_242182, 3ULL, 2);
            switch (heff_tag_of(v_x11_242183)) {
            case TAG_Left: {
              V v_e_242185 = heff_field(v_x11_242183, 0);
              heff_take_n(v_x11_242183, 1ULL, 1);
              heff_drop_rec(v_kw_241950, 9);
              heff_drop(v_a_241953);
              heff_drop(v_x_242180);
              heff_drop_cell(v_ru_24x1_242182_24MkPair, 2);
              return heff_tag_at_n(v_ru_24x1_242176_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242185}), v_st_242184});
            }
            case TAG_Right: {
              V v_x_242186 = heff_field(v_x11_242183, 0);
              heff_take_n(v_x11_242183, 1ULL, 1);
              V v_t_242187 = (g_heff_2esyntax_2ecst_2elastE(v_a_241953));
              V v_e_242188 = heff_get_n(v_t_242187, 4, 9);
              V v_t_242189 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_241950, 3, 9), v_e_242188});
              V v_x_242190 = heff_tag_at_n(v_ru_24x1_242182_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_EIfThen, 2, (V[]){v_x_242180, v_x_242186}), v_t_242189});
              return heff_tag_at_n(v_ru_24x1_242176_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_242190}), v_st_242184});
            }
            default: return heff_nomatch(v_x11_242183);
            }
          }
          default: return heff_nomatch(v_x1_242182);
          }
        }
        default: return heff_nomatch(v_x11_242177);
        }
      }
      default: return heff_nomatch(v_x1_242176);
      }
    }
    case TAG_ECon: {
      V v_m_242193 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_241951}));
      V v_x1_242194 = heff_tr(heff_call(v_m_242193, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_242194)) {
      case TAG_MkPair: {
        V v_x11_242195 = heff_field(v_x1_242194, 0);
        V v_st_242196 = heff_field(v_x1_242194, 1);
        V v_ru_24x1_242194_24MkPair = heff_take_reuse_n(v_x1_242194, 3ULL, 2);
        switch (heff_tag_of(v_x11_242195)) {
        case TAG_Left: {
          V v_e_242197 = heff_field(v_x11_242195, 0);
          heff_take_n(v_x11_242195, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_241950, 9);
          heff_drop(v_a_241953);
          return heff_tag_at_n(v_ru_24x1_242194_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242197}), v_st_242196});
        }
        case TAG_Right: {
          V v_x_242198 = heff_field(v_x11_242195, 0);
          heff_take_n(v_x11_242195, 1ULL, 1);
          V v_m_242199 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_a_241953)}));
          V v_x1_242200 = heff_tr(heff_call(v_m_242199, 1, (V[]){v_st_242196}));
          switch (heff_tag_of(v_x1_242200)) {
          case TAG_MkPair: {
            V v_x11_242201 = heff_field(v_x1_242200, 0);
            V v_st_242202 = heff_field(v_x1_242200, 1);
            V v_ru_24x1_242200_24MkPair = heff_take_reuse_n(v_x1_242200, 3ULL, 2);
            switch (heff_tag_of(v_x11_242201)) {
            case TAG_Left: {
              V v_e_242203 = heff_field(v_x11_242201, 0);
              heff_take_n(v_x11_242201, 1ULL, 1);
              heff_drop_rec(v_kw_241950, 9);
              heff_drop(v_a_241953);
              heff_drop(v_x_242198);
              heff_drop_cell(v_ru_24x1_242200_24MkPair, 2);
              return heff_tag_at_n(v_ru_24x1_242194_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242203}), v_st_242202});
            }
            case TAG_Right: {
              V v_x_242204 = heff_field(v_x11_242201, 0);
              heff_take_n(v_x11_242201, 1ULL, 1);
              V v_t_242205 = (g_heff_2esyntax_2ecst_2elastE(v_a_241953));
              V v_e_242206 = heff_get_n(v_t_242205, 4, 9);
              V v_t_242207 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_241950, 3, 9), v_e_242206});
              V v_x_242208 = heff_tag_at_n(v_ru_24x1_242200_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_EIfThen, 2, (V[]){v_x_242198, v_x_242204}), v_t_242207});
              return heff_tag_at_n(v_ru_24x1_242194_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_242208}), v_st_242202});
            }
            default: return heff_nomatch(v_x11_242201);
            }
          }
          default: return heff_nomatch(v_x1_242200);
          }
        }
        default: return heff_nomatch(v_x11_242195);
        }
      }
      default: return heff_nomatch(v_x1_242194);
      }
    }
    case TAG_EField: {
      V v_m_242211 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_241951}));
      V v_x1_242212 = heff_tr(heff_call(v_m_242211, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_242212)) {
      case TAG_MkPair: {
        V v_x11_242213 = heff_field(v_x1_242212, 0);
        V v_st_242214 = heff_field(v_x1_242212, 1);
        V v_ru_24x1_242212_24MkPair = heff_take_reuse_n(v_x1_242212, 3ULL, 2);
        switch (heff_tag_of(v_x11_242213)) {
        case TAG_Left: {
          V v_e_242215 = heff_field(v_x11_242213, 0);
          heff_take_n(v_x11_242213, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_241950, 9);
          heff_drop(v_a_241953);
          return heff_tag_at_n(v_ru_24x1_242212_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242215}), v_st_242214});
        }
        case TAG_Right: {
          V v_x_242216 = heff_field(v_x11_242213, 0);
          heff_take_n(v_x11_242213, 1ULL, 1);
          V v_m_242217 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_a_241953)}));
          V v_x1_242218 = heff_tr(heff_call(v_m_242217, 1, (V[]){v_st_242214}));
          switch (heff_tag_of(v_x1_242218)) {
          case TAG_MkPair: {
            V v_x11_242219 = heff_field(v_x1_242218, 0);
            V v_st_242220 = heff_field(v_x1_242218, 1);
            V v_ru_24x1_242218_24MkPair = heff_take_reuse_n(v_x1_242218, 3ULL, 2);
            switch (heff_tag_of(v_x11_242219)) {
            case TAG_Left: {
              V v_e_242221 = heff_field(v_x11_242219, 0);
              heff_take_n(v_x11_242219, 1ULL, 1);
              heff_drop_rec(v_kw_241950, 9);
              heff_drop(v_a_241953);
              heff_drop(v_x_242216);
              heff_drop_cell(v_ru_24x1_242218_24MkPair, 2);
              return heff_tag_at_n(v_ru_24x1_242212_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242221}), v_st_242220});
            }
            case TAG_Right: {
              V v_x_242222 = heff_field(v_x11_242219, 0);
              heff_take_n(v_x11_242219, 1ULL, 1);
              V v_t_242223 = (g_heff_2esyntax_2ecst_2elastE(v_a_241953));
              V v_e_242224 = heff_get_n(v_t_242223, 4, 9);
              V v_t_242225 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_241950, 3, 9), v_e_242224});
              V v_x_242226 = heff_tag_at_n(v_ru_24x1_242218_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_EIfThen, 2, (V[]){v_x_242216, v_x_242222}), v_t_242225});
              return heff_tag_at_n(v_ru_24x1_242212_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_242226}), v_st_242220});
            }
            default: return heff_nomatch(v_x11_242219);
            }
          }
          default: return heff_nomatch(v_x1_242218);
          }
        }
        default: return heff_nomatch(v_x11_242213);
        }
      }
      default: return heff_nomatch(v_x1_242212);
      }
    }
    case TAG_ENeg: {
      V v_m_242229 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_241951}));
      V v_x1_242230 = heff_tr(heff_call(v_m_242229, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_242230)) {
      case TAG_MkPair: {
        V v_x11_242231 = heff_field(v_x1_242230, 0);
        V v_st_242232 = heff_field(v_x1_242230, 1);
        V v_ru_24x1_242230_24MkPair = heff_take_reuse_n(v_x1_242230, 3ULL, 2);
        switch (heff_tag_of(v_x11_242231)) {
        case TAG_Left: {
          V v_e_242233 = heff_field(v_x11_242231, 0);
          heff_take_n(v_x11_242231, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_241950, 9);
          heff_drop(v_a_241953);
          return heff_tag_at_n(v_ru_24x1_242230_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242233}), v_st_242232});
        }
        case TAG_Right: {
          V v_x_242234 = heff_field(v_x11_242231, 0);
          heff_take_n(v_x11_242231, 1ULL, 1);
          V v_m_242235 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_a_241953)}));
          V v_x1_242236 = heff_tr(heff_call(v_m_242235, 1, (V[]){v_st_242232}));
          switch (heff_tag_of(v_x1_242236)) {
          case TAG_MkPair: {
            V v_x11_242237 = heff_field(v_x1_242236, 0);
            V v_st_242238 = heff_field(v_x1_242236, 1);
            V v_ru_24x1_242236_24MkPair = heff_take_reuse_n(v_x1_242236, 3ULL, 2);
            switch (heff_tag_of(v_x11_242237)) {
            case TAG_Left: {
              V v_e_242239 = heff_field(v_x11_242237, 0);
              heff_take_n(v_x11_242237, 1ULL, 1);
              heff_drop_rec(v_kw_241950, 9);
              heff_drop(v_a_241953);
              heff_drop(v_x_242234);
              heff_drop_cell(v_ru_24x1_242236_24MkPair, 2);
              return heff_tag_at_n(v_ru_24x1_242230_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242239}), v_st_242238});
            }
            case TAG_Right: {
              V v_x_242240 = heff_field(v_x11_242237, 0);
              heff_take_n(v_x11_242237, 1ULL, 1);
              V v_t_242241 = (g_heff_2esyntax_2ecst_2elastE(v_a_241953));
              V v_e_242242 = heff_get_n(v_t_242241, 4, 9);
              V v_t_242243 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_241950, 3, 9), v_e_242242});
              V v_x_242244 = heff_tag_at_n(v_ru_24x1_242236_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_EIfThen, 2, (V[]){v_x_242234, v_x_242240}), v_t_242243});
              return heff_tag_at_n(v_ru_24x1_242230_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_242244}), v_st_242238});
            }
            default: return heff_nomatch(v_x11_242237);
            }
          }
          default: return heff_nomatch(v_x1_242236);
          }
        }
        default: return heff_nomatch(v_x11_242231);
        }
      }
      default: return heff_nomatch(v_x1_242230);
      }
    }
    case TAG_App: {
      V v_m_242247 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_241951}));
      V v_x1_242248 = heff_tr(heff_call(v_m_242247, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_242248)) {
      case TAG_MkPair: {
        V v_x11_242249 = heff_field(v_x1_242248, 0);
        V v_st_242250 = heff_field(v_x1_242248, 1);
        V v_ru_24x1_242248_24MkPair = heff_take_reuse_n(v_x1_242248, 3ULL, 2);
        switch (heff_tag_of(v_x11_242249)) {
        case TAG_Left: {
          V v_e_242251 = heff_field(v_x11_242249, 0);
          heff_take_n(v_x11_242249, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_241950, 9);
          heff_drop(v_a_241953);
          return heff_tag_at_n(v_ru_24x1_242248_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242251}), v_st_242250});
        }
        case TAG_Right: {
          V v_x_242252 = heff_field(v_x11_242249, 0);
          heff_take_n(v_x11_242249, 1ULL, 1);
          V v_m_242253 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_a_241953)}));
          V v_x1_242254 = heff_tr(heff_call(v_m_242253, 1, (V[]){v_st_242250}));
          switch (heff_tag_of(v_x1_242254)) {
          case TAG_MkPair: {
            V v_x11_242255 = heff_field(v_x1_242254, 0);
            V v_st_242256 = heff_field(v_x1_242254, 1);
            V v_ru_24x1_242254_24MkPair = heff_take_reuse_n(v_x1_242254, 3ULL, 2);
            switch (heff_tag_of(v_x11_242255)) {
            case TAG_Left: {
              V v_e_242257 = heff_field(v_x11_242255, 0);
              heff_take_n(v_x11_242255, 1ULL, 1);
              heff_drop_rec(v_kw_241950, 9);
              heff_drop(v_a_241953);
              heff_drop(v_x_242252);
              heff_drop_cell(v_ru_24x1_242254_24MkPair, 2);
              return heff_tag_at_n(v_ru_24x1_242248_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242257}), v_st_242256});
            }
            case TAG_Right: {
              V v_x_242258 = heff_field(v_x11_242255, 0);
              heff_take_n(v_x11_242255, 1ULL, 1);
              V v_t_242259 = (g_heff_2esyntax_2ecst_2elastE(v_a_241953));
              V v_e_242260 = heff_get_n(v_t_242259, 4, 9);
              V v_t_242261 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_241950, 3, 9), v_e_242260});
              V v_x_242262 = heff_tag_at_n(v_ru_24x1_242254_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_EIfThen, 2, (V[]){v_x_242252, v_x_242258}), v_t_242261});
              return heff_tag_at_n(v_ru_24x1_242248_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_242262}), v_st_242256});
            }
            default: return heff_nomatch(v_x11_242255);
            }
          }
          default: return heff_nomatch(v_x1_242254);
          }
        }
        default: return heff_nomatch(v_x11_242249);
        }
      }
      default: return heff_nomatch(v_x1_242248);
      }
    }
    case TAG_Op: {
      V v_m_242266 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_241951}));
      V v_x1_242267 = heff_tr(heff_call(v_m_242266, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_242267)) {
      case TAG_MkPair: {
        V v_x11_242268 = heff_field(v_x1_242267, 0);
        V v_st_242269 = heff_field(v_x1_242267, 1);
        V v_ru_24x1_242267_24MkPair = heff_take_reuse_n(v_x1_242267, 3ULL, 2);
        switch (heff_tag_of(v_x11_242268)) {
        case TAG_Left: {
          V v_e_242270 = heff_field(v_x11_242268, 0);
          heff_take_n(v_x11_242268, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_241950, 9);
          heff_drop(v_a_241953);
          return heff_tag_at_n(v_ru_24x1_242267_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242270}), v_st_242269});
        }
        case TAG_Right: {
          V v_x_242271 = heff_field(v_x11_242268, 0);
          heff_take_n(v_x11_242268, 1ULL, 1);
          V v_m_242272 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_a_241953)}));
          V v_x1_242273 = heff_tr(heff_call(v_m_242272, 1, (V[]){v_st_242269}));
          switch (heff_tag_of(v_x1_242273)) {
          case TAG_MkPair: {
            V v_x11_242274 = heff_field(v_x1_242273, 0);
            V v_st_242275 = heff_field(v_x1_242273, 1);
            V v_ru_24x1_242273_24MkPair = heff_take_reuse_n(v_x1_242273, 3ULL, 2);
            switch (heff_tag_of(v_x11_242274)) {
            case TAG_Left: {
              V v_e_242276 = heff_field(v_x11_242274, 0);
              heff_take_n(v_x11_242274, 1ULL, 1);
              heff_drop_rec(v_kw_241950, 9);
              heff_drop(v_a_241953);
              heff_drop(v_x_242271);
              heff_drop_cell(v_ru_24x1_242273_24MkPair, 2);
              return heff_tag_at_n(v_ru_24x1_242267_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242276}), v_st_242275});
            }
            case TAG_Right: {
              V v_x_242277 = heff_field(v_x11_242274, 0);
              heff_take_n(v_x11_242274, 1ULL, 1);
              V v_t_242278 = (g_heff_2esyntax_2ecst_2elastE(v_a_241953));
              V v_e_242279 = heff_get_n(v_t_242278, 4, 9);
              V v_t_242280 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_241950, 3, 9), v_e_242279});
              V v_x_242281 = heff_tag_at_n(v_ru_24x1_242273_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_EIfThen, 2, (V[]){v_x_242271, v_x_242277}), v_t_242280});
              return heff_tag_at_n(v_ru_24x1_242267_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_242281}), v_st_242275});
            }
            default: return heff_nomatch(v_x11_242274);
            }
          }
          default: return heff_nomatch(v_x1_242273);
          }
        }
        default: return heff_nomatch(v_x11_242268);
        }
      }
      default: return heff_nomatch(v_x1_242267);
      }
    }
    case TAG_Ops: {
      V v_m_242284 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_241951}));
      V v_x1_242285 = heff_tr(heff_call(v_m_242284, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_242285)) {
      case TAG_MkPair: {
        V v_x11_242286 = heff_field(v_x1_242285, 0);
        V v_st_242287 = heff_field(v_x1_242285, 1);
        V v_ru_24x1_242285_24MkPair = heff_take_reuse_n(v_x1_242285, 3ULL, 2);
        switch (heff_tag_of(v_x11_242286)) {
        case TAG_Left: {
          V v_e_242288 = heff_field(v_x11_242286, 0);
          heff_take_n(v_x11_242286, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_241950, 9);
          heff_drop(v_a_241953);
          return heff_tag_at_n(v_ru_24x1_242285_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242288}), v_st_242287});
        }
        case TAG_Right: {
          V v_x_242289 = heff_field(v_x11_242286, 0);
          heff_take_n(v_x11_242286, 1ULL, 1);
          V v_m_242290 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_a_241953)}));
          V v_x1_242291 = heff_tr(heff_call(v_m_242290, 1, (V[]){v_st_242287}));
          switch (heff_tag_of(v_x1_242291)) {
          case TAG_MkPair: {
            V v_x11_242292 = heff_field(v_x1_242291, 0);
            V v_st_242293 = heff_field(v_x1_242291, 1);
            V v_ru_24x1_242291_24MkPair = heff_take_reuse_n(v_x1_242291, 3ULL, 2);
            switch (heff_tag_of(v_x11_242292)) {
            case TAG_Left: {
              V v_e_242294 = heff_field(v_x11_242292, 0);
              heff_take_n(v_x11_242292, 1ULL, 1);
              heff_drop_rec(v_kw_241950, 9);
              heff_drop(v_a_241953);
              heff_drop(v_x_242289);
              heff_drop_cell(v_ru_24x1_242291_24MkPair, 2);
              return heff_tag_at_n(v_ru_24x1_242285_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242294}), v_st_242293});
            }
            case TAG_Right: {
              V v_x_242295 = heff_field(v_x11_242292, 0);
              heff_take_n(v_x11_242292, 1ULL, 1);
              V v_t_242296 = (g_heff_2esyntax_2ecst_2elastE(v_a_241953));
              V v_e_242297 = heff_get_n(v_t_242296, 4, 9);
              V v_t_242298 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_241950, 3, 9), v_e_242297});
              V v_x_242299 = heff_tag_at_n(v_ru_24x1_242291_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_EIfThen, 2, (V[]){v_x_242289, v_x_242295}), v_t_242298});
              return heff_tag_at_n(v_ru_24x1_242285_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_242299}), v_st_242293});
            }
            default: return heff_nomatch(v_x11_242292);
            }
          }
          default: return heff_nomatch(v_x1_242291);
          }
        }
        default: return heff_nomatch(v_x11_242286);
        }
      }
      default: return heff_nomatch(v_x1_242285);
      }
    }
    case TAG_OpRhs: {
      V v_m_242302 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_241951}));
      V v_x1_242303 = heff_tr(heff_call(v_m_242302, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_242303)) {
      case TAG_MkPair: {
        V v_x11_242304 = heff_field(v_x1_242303, 0);
        V v_st_242305 = heff_field(v_x1_242303, 1);
        V v_ru_24x1_242303_24MkPair = heff_take_reuse_n(v_x1_242303, 3ULL, 2);
        switch (heff_tag_of(v_x11_242304)) {
        case TAG_Left: {
          V v_e_242306 = heff_field(v_x11_242304, 0);
          heff_take_n(v_x11_242304, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_241950, 9);
          heff_drop(v_a_241953);
          return heff_tag_at_n(v_ru_24x1_242303_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242306}), v_st_242305});
        }
        case TAG_Right: {
          V v_x_242307 = heff_field(v_x11_242304, 0);
          heff_take_n(v_x11_242304, 1ULL, 1);
          V v_m_242308 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_a_241953)}));
          V v_x1_242309 = heff_tr(heff_call(v_m_242308, 1, (V[]){v_st_242305}));
          switch (heff_tag_of(v_x1_242309)) {
          case TAG_MkPair: {
            V v_x11_242310 = heff_field(v_x1_242309, 0);
            V v_st_242311 = heff_field(v_x1_242309, 1);
            V v_ru_24x1_242309_24MkPair = heff_take_reuse_n(v_x1_242309, 3ULL, 2);
            switch (heff_tag_of(v_x11_242310)) {
            case TAG_Left: {
              V v_e_242312 = heff_field(v_x11_242310, 0);
              heff_take_n(v_x11_242310, 1ULL, 1);
              heff_drop_rec(v_kw_241950, 9);
              heff_drop(v_a_241953);
              heff_drop(v_x_242307);
              heff_drop_cell(v_ru_24x1_242309_24MkPair, 2);
              return heff_tag_at_n(v_ru_24x1_242303_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242312}), v_st_242311});
            }
            case TAG_Right: {
              V v_x_242313 = heff_field(v_x11_242310, 0);
              heff_take_n(v_x11_242310, 1ULL, 1);
              V v_t_242314 = (g_heff_2esyntax_2ecst_2elastE(v_a_241953));
              V v_e_242315 = heff_get_n(v_t_242314, 4, 9);
              V v_t_242316 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_241950, 3, 9), v_e_242315});
              V v_x_242317 = heff_tag_at_n(v_ru_24x1_242309_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_EIfThen, 2, (V[]){v_x_242307, v_x_242313}), v_t_242316});
              return heff_tag_at_n(v_ru_24x1_242303_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_242317}), v_st_242311});
            }
            default: return heff_nomatch(v_x11_242310);
            }
          }
          default: return heff_nomatch(v_x1_242309);
          }
        }
        default: return heff_nomatch(v_x11_242304);
        }
      }
      default: return heff_nomatch(v_x1_242303);
      }
    }
    case TAG_Ann: {
      V v_m_242321 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_241951}));
      V v_x1_242322 = heff_tr(heff_call(v_m_242321, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_242322)) {
      case TAG_MkPair: {
        V v_x11_242323 = heff_field(v_x1_242322, 0);
        V v_st_242324 = heff_field(v_x1_242322, 1);
        V v_ru_24x1_242322_24MkPair = heff_take_reuse_n(v_x1_242322, 3ULL, 2);
        switch (heff_tag_of(v_x11_242323)) {
        case TAG_Left: {
          V v_e_242325 = heff_field(v_x11_242323, 0);
          heff_take_n(v_x11_242323, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_241950, 9);
          heff_drop(v_a_241953);
          return heff_tag_at_n(v_ru_24x1_242322_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242325}), v_st_242324});
        }
        case TAG_Right: {
          V v_x_242326 = heff_field(v_x11_242323, 0);
          heff_take_n(v_x11_242323, 1ULL, 1);
          V v_m_242327 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_a_241953)}));
          V v_x1_242328 = heff_tr(heff_call(v_m_242327, 1, (V[]){v_st_242324}));
          switch (heff_tag_of(v_x1_242328)) {
          case TAG_MkPair: {
            V v_x11_242329 = heff_field(v_x1_242328, 0);
            V v_st_242330 = heff_field(v_x1_242328, 1);
            V v_ru_24x1_242328_24MkPair = heff_take_reuse_n(v_x1_242328, 3ULL, 2);
            switch (heff_tag_of(v_x11_242329)) {
            case TAG_Left: {
              V v_e_242331 = heff_field(v_x11_242329, 0);
              heff_take_n(v_x11_242329, 1ULL, 1);
              heff_drop_rec(v_kw_241950, 9);
              heff_drop(v_a_241953);
              heff_drop(v_x_242326);
              heff_drop_cell(v_ru_24x1_242328_24MkPair, 2);
              return heff_tag_at_n(v_ru_24x1_242322_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242331}), v_st_242330});
            }
            case TAG_Right: {
              V v_x_242332 = heff_field(v_x11_242329, 0);
              heff_take_n(v_x11_242329, 1ULL, 1);
              V v_t_242333 = (g_heff_2esyntax_2ecst_2elastE(v_a_241953));
              V v_e_242334 = heff_get_n(v_t_242333, 4, 9);
              V v_t_242335 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_241950, 3, 9), v_e_242334});
              V v_x_242336 = heff_tag_at_n(v_ru_24x1_242328_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_EIfThen, 2, (V[]){v_x_242326, v_x_242332}), v_t_242335});
              return heff_tag_at_n(v_ru_24x1_242322_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_242336}), v_st_242330});
            }
            default: return heff_nomatch(v_x11_242329);
            }
          }
          default: return heff_nomatch(v_x1_242328);
          }
        }
        default: return heff_nomatch(v_x11_242323);
        }
      }
      default: return heff_nomatch(v_x1_242322);
      }
    }
    case TAG_BVar: {
      V v_m_242338 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_241951}));
      V v_x1_242339 = heff_tr(heff_call(v_m_242338, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_242339)) {
      case TAG_MkPair: {
        V v_x11_242340 = heff_field(v_x1_242339, 0);
        V v_st_242341 = heff_field(v_x1_242339, 1);
        V v_ru_24x1_242339_24MkPair = heff_take_reuse_n(v_x1_242339, 3ULL, 2);
        switch (heff_tag_of(v_x11_242340)) {
        case TAG_Left: {
          V v_e_242342 = heff_field(v_x11_242340, 0);
          heff_take_n(v_x11_242340, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_241950, 9);
          heff_drop(v_a_241953);
          return heff_tag_at_n(v_ru_24x1_242339_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242342}), v_st_242341});
        }
        case TAG_Right: {
          V v_x_242343 = heff_field(v_x11_242340, 0);
          heff_take_n(v_x11_242340, 1ULL, 1);
          V v_m_242344 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_a_241953)}));
          V v_x1_242345 = heff_tr(heff_call(v_m_242344, 1, (V[]){v_st_242341}));
          switch (heff_tag_of(v_x1_242345)) {
          case TAG_MkPair: {
            V v_x11_242346 = heff_field(v_x1_242345, 0);
            V v_st_242347 = heff_field(v_x1_242345, 1);
            V v_ru_24x1_242345_24MkPair = heff_take_reuse_n(v_x1_242345, 3ULL, 2);
            switch (heff_tag_of(v_x11_242346)) {
            case TAG_Left: {
              V v_e_242348 = heff_field(v_x11_242346, 0);
              heff_take_n(v_x11_242346, 1ULL, 1);
              heff_drop_rec(v_kw_241950, 9);
              heff_drop(v_a_241953);
              heff_drop(v_x_242343);
              heff_drop_cell(v_ru_24x1_242345_24MkPair, 2);
              return heff_tag_at_n(v_ru_24x1_242339_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242348}), v_st_242347});
            }
            case TAG_Right: {
              V v_x_242349 = heff_field(v_x11_242346, 0);
              heff_take_n(v_x11_242346, 1ULL, 1);
              V v_t_242350 = (g_heff_2esyntax_2ecst_2elastE(v_a_241953));
              V v_e_242351 = heff_get_n(v_t_242350, 4, 9);
              V v_t_242352 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_241950, 3, 9), v_e_242351});
              V v_x_242353 = heff_tag_at_n(v_ru_24x1_242345_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_EIfThen, 2, (V[]){v_x_242343, v_x_242349}), v_t_242352});
              return heff_tag_at_n(v_ru_24x1_242339_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_242353}), v_st_242347});
            }
            default: return heff_nomatch(v_x11_242346);
            }
          }
          default: return heff_nomatch(v_x1_242345);
          }
        }
        default: return heff_nomatch(v_x11_242340);
        }
      }
      default: return heff_nomatch(v_x1_242339);
      }
    }
    case TAG_BImp: {
      V v_m_242357 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_241951}));
      V v_x1_242358 = heff_tr(heff_call(v_m_242357, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_242358)) {
      case TAG_MkPair: {
        V v_x11_242359 = heff_field(v_x1_242358, 0);
        V v_st_242360 = heff_field(v_x1_242358, 1);
        V v_ru_24x1_242358_24MkPair = heff_take_reuse_n(v_x1_242358, 3ULL, 2);
        switch (heff_tag_of(v_x11_242359)) {
        case TAG_Left: {
          V v_e_242361 = heff_field(v_x11_242359, 0);
          heff_take_n(v_x11_242359, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_241950, 9);
          heff_drop(v_a_241953);
          return heff_tag_at_n(v_ru_24x1_242358_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242361}), v_st_242360});
        }
        case TAG_Right: {
          V v_x_242362 = heff_field(v_x11_242359, 0);
          heff_take_n(v_x11_242359, 1ULL, 1);
          V v_m_242363 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_a_241953)}));
          V v_x1_242364 = heff_tr(heff_call(v_m_242363, 1, (V[]){v_st_242360}));
          switch (heff_tag_of(v_x1_242364)) {
          case TAG_MkPair: {
            V v_x11_242365 = heff_field(v_x1_242364, 0);
            V v_st_242366 = heff_field(v_x1_242364, 1);
            V v_ru_24x1_242364_24MkPair = heff_take_reuse_n(v_x1_242364, 3ULL, 2);
            switch (heff_tag_of(v_x11_242365)) {
            case TAG_Left: {
              V v_e_242367 = heff_field(v_x11_242365, 0);
              heff_take_n(v_x11_242365, 1ULL, 1);
              heff_drop_rec(v_kw_241950, 9);
              heff_drop(v_a_241953);
              heff_drop(v_x_242362);
              heff_drop_cell(v_ru_24x1_242364_24MkPair, 2);
              return heff_tag_at_n(v_ru_24x1_242358_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242367}), v_st_242366});
            }
            case TAG_Right: {
              V v_x_242368 = heff_field(v_x11_242365, 0);
              heff_take_n(v_x11_242365, 1ULL, 1);
              V v_t_242369 = (g_heff_2esyntax_2ecst_2elastE(v_a_241953));
              V v_e_242370 = heff_get_n(v_t_242369, 4, 9);
              V v_t_242371 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_241950, 3, 9), v_e_242370});
              V v_x_242372 = heff_tag_at_n(v_ru_24x1_242364_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_EIfThen, 2, (V[]){v_x_242362, v_x_242368}), v_t_242371});
              return heff_tag_at_n(v_ru_24x1_242358_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_242372}), v_st_242366});
            }
            default: return heff_nomatch(v_x11_242365);
            }
          }
          default: return heff_nomatch(v_x1_242364);
          }
        }
        default: return heff_nomatch(v_x11_242359);
        }
      }
      default: return heff_nomatch(v_x1_242358);
      }
    }
    case TAG_BAnn: {
      V v_m_242378 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_241951}));
      V v_x1_242379 = heff_tr(heff_call(v_m_242378, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_242379)) {
      case TAG_MkPair: {
        V v_x11_242380 = heff_field(v_x1_242379, 0);
        V v_st_242381 = heff_field(v_x1_242379, 1);
        V v_ru_24x1_242379_24MkPair = heff_take_reuse_n(v_x1_242379, 3ULL, 2);
        switch (heff_tag_of(v_x11_242380)) {
        case TAG_Left: {
          V v_e_242382 = heff_field(v_x11_242380, 0);
          heff_take_n(v_x11_242380, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_241950, 9);
          heff_drop(v_a_241953);
          return heff_tag_at_n(v_ru_24x1_242379_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242382}), v_st_242381});
        }
        case TAG_Right: {
          V v_x_242383 = heff_field(v_x11_242380, 0);
          heff_take_n(v_x11_242380, 1ULL, 1);
          V v_m_242384 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_a_241953)}));
          V v_x1_242385 = heff_tr(heff_call(v_m_242384, 1, (V[]){v_st_242381}));
          switch (heff_tag_of(v_x1_242385)) {
          case TAG_MkPair: {
            V v_x11_242386 = heff_field(v_x1_242385, 0);
            V v_st_242387 = heff_field(v_x1_242385, 1);
            V v_ru_24x1_242385_24MkPair = heff_take_reuse_n(v_x1_242385, 3ULL, 2);
            switch (heff_tag_of(v_x11_242386)) {
            case TAG_Left: {
              V v_e_242388 = heff_field(v_x11_242386, 0);
              heff_take_n(v_x11_242386, 1ULL, 1);
              heff_drop_rec(v_kw_241950, 9);
              heff_drop(v_a_241953);
              heff_drop(v_x_242383);
              heff_drop_cell(v_ru_24x1_242385_24MkPair, 2);
              return heff_tag_at_n(v_ru_24x1_242379_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242388}), v_st_242387});
            }
            case TAG_Right: {
              V v_x_242389 = heff_field(v_x11_242386, 0);
              heff_take_n(v_x11_242386, 1ULL, 1);
              V v_t_242390 = (g_heff_2esyntax_2ecst_2elastE(v_a_241953));
              V v_e_242391 = heff_get_n(v_t_242390, 4, 9);
              V v_t_242392 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_241950, 3, 9), v_e_242391});
              V v_x_242393 = heff_tag_at_n(v_ru_24x1_242385_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_EIfThen, 2, (V[]){v_x_242383, v_x_242389}), v_t_242392});
              return heff_tag_at_n(v_ru_24x1_242379_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_242393}), v_st_242387});
            }
            default: return heff_nomatch(v_x11_242386);
            }
          }
          default: return heff_nomatch(v_x1_242385);
          }
        }
        default: return heff_nomatch(v_x11_242380);
        }
      }
      default: return heff_nomatch(v_x1_242379);
      }
    }
    case TAG_Lam: {
      V v_m_242398 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_241951}));
      V v_x1_242399 = heff_tr(heff_call(v_m_242398, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_242399)) {
      case TAG_MkPair: {
        V v_x11_242400 = heff_field(v_x1_242399, 0);
        V v_st_242401 = heff_field(v_x1_242399, 1);
        V v_ru_24x1_242399_24MkPair = heff_take_reuse_n(v_x1_242399, 3ULL, 2);
        switch (heff_tag_of(v_x11_242400)) {
        case TAG_Left: {
          V v_e_242402 = heff_field(v_x11_242400, 0);
          heff_take_n(v_x11_242400, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_241950, 9);
          heff_drop(v_a_241953);
          return heff_tag_at_n(v_ru_24x1_242399_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242402}), v_st_242401});
        }
        case TAG_Right: {
          V v_x_242403 = heff_field(v_x11_242400, 0);
          heff_take_n(v_x11_242400, 1ULL, 1);
          V v_m_242404 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_a_241953)}));
          V v_x1_242405 = heff_tr(heff_call(v_m_242404, 1, (V[]){v_st_242401}));
          switch (heff_tag_of(v_x1_242405)) {
          case TAG_MkPair: {
            V v_x11_242406 = heff_field(v_x1_242405, 0);
            V v_st_242407 = heff_field(v_x1_242405, 1);
            V v_ru_24x1_242405_24MkPair = heff_take_reuse_n(v_x1_242405, 3ULL, 2);
            switch (heff_tag_of(v_x11_242406)) {
            case TAG_Left: {
              V v_e_242408 = heff_field(v_x11_242406, 0);
              heff_take_n(v_x11_242406, 1ULL, 1);
              heff_drop_rec(v_kw_241950, 9);
              heff_drop(v_a_241953);
              heff_drop(v_x_242403);
              heff_drop_cell(v_ru_24x1_242405_24MkPair, 2);
              return heff_tag_at_n(v_ru_24x1_242399_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242408}), v_st_242407});
            }
            case TAG_Right: {
              V v_x_242409 = heff_field(v_x11_242406, 0);
              heff_take_n(v_x11_242406, 1ULL, 1);
              V v_t_242410 = (g_heff_2esyntax_2ecst_2elastE(v_a_241953));
              V v_e_242411 = heff_get_n(v_t_242410, 4, 9);
              V v_t_242412 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_241950, 3, 9), v_e_242411});
              V v_x_242413 = heff_tag_at_n(v_ru_24x1_242405_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_EIfThen, 2, (V[]){v_x_242403, v_x_242409}), v_t_242412});
              return heff_tag_at_n(v_ru_24x1_242399_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_242413}), v_st_242407});
            }
            default: return heff_nomatch(v_x11_242406);
            }
          }
          default: return heff_nomatch(v_x1_242405);
          }
        }
        default: return heff_nomatch(v_x11_242400);
        }
      }
      default: return heff_nomatch(v_x1_242399);
      }
    }
    case TAG_Case: {
      V v_m_242418 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_241951}));
      V v_x1_242419 = heff_tr(heff_call(v_m_242418, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_242419)) {
      case TAG_MkPair: {
        V v_x11_242420 = heff_field(v_x1_242419, 0);
        V v_st_242421 = heff_field(v_x1_242419, 1);
        V v_ru_24x1_242419_24MkPair = heff_take_reuse_n(v_x1_242419, 3ULL, 2);
        switch (heff_tag_of(v_x11_242420)) {
        case TAG_Left: {
          V v_e_242422 = heff_field(v_x11_242420, 0);
          heff_take_n(v_x11_242420, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_241950, 9);
          heff_drop(v_a_241953);
          return heff_tag_at_n(v_ru_24x1_242419_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242422}), v_st_242421});
        }
        case TAG_Right: {
          V v_x_242423 = heff_field(v_x11_242420, 0);
          heff_take_n(v_x11_242420, 1ULL, 1);
          V v_m_242424 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_a_241953)}));
          V v_x1_242425 = heff_tr(heff_call(v_m_242424, 1, (V[]){v_st_242421}));
          switch (heff_tag_of(v_x1_242425)) {
          case TAG_MkPair: {
            V v_x11_242426 = heff_field(v_x1_242425, 0);
            V v_st_242427 = heff_field(v_x1_242425, 1);
            V v_ru_24x1_242425_24MkPair = heff_take_reuse_n(v_x1_242425, 3ULL, 2);
            switch (heff_tag_of(v_x11_242426)) {
            case TAG_Left: {
              V v_e_242428 = heff_field(v_x11_242426, 0);
              heff_take_n(v_x11_242426, 1ULL, 1);
              heff_drop_rec(v_kw_241950, 9);
              heff_drop(v_a_241953);
              heff_drop(v_x_242423);
              heff_drop_cell(v_ru_24x1_242425_24MkPair, 2);
              return heff_tag_at_n(v_ru_24x1_242419_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242428}), v_st_242427});
            }
            case TAG_Right: {
              V v_x_242429 = heff_field(v_x11_242426, 0);
              heff_take_n(v_x11_242426, 1ULL, 1);
              V v_t_242430 = (g_heff_2esyntax_2ecst_2elastE(v_a_241953));
              V v_e_242431 = heff_get_n(v_t_242430, 4, 9);
              V v_t_242432 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_241950, 3, 9), v_e_242431});
              V v_x_242433 = heff_tag_at_n(v_ru_24x1_242425_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_EIfThen, 2, (V[]){v_x_242423, v_x_242429}), v_t_242432});
              return heff_tag_at_n(v_ru_24x1_242419_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_242433}), v_st_242427});
            }
            default: return heff_nomatch(v_x11_242426);
            }
          }
          default: return heff_nomatch(v_x1_242425);
          }
        }
        default: return heff_nomatch(v_x11_242420);
        }
      }
      default: return heff_nomatch(v_x1_242419);
      }
    }
    case TAG_EAlt: {
      V v_m_242437 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_241951}));
      V v_x1_242438 = heff_tr(heff_call(v_m_242437, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_242438)) {
      case TAG_MkPair: {
        V v_x11_242439 = heff_field(v_x1_242438, 0);
        V v_st_242440 = heff_field(v_x1_242438, 1);
        V v_ru_24x1_242438_24MkPair = heff_take_reuse_n(v_x1_242438, 3ULL, 2);
        switch (heff_tag_of(v_x11_242439)) {
        case TAG_Left: {
          V v_e_242441 = heff_field(v_x11_242439, 0);
          heff_take_n(v_x11_242439, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_241950, 9);
          heff_drop(v_a_241953);
          return heff_tag_at_n(v_ru_24x1_242438_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242441}), v_st_242440});
        }
        case TAG_Right: {
          V v_x_242442 = heff_field(v_x11_242439, 0);
          heff_take_n(v_x11_242439, 1ULL, 1);
          V v_m_242443 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_a_241953)}));
          V v_x1_242444 = heff_tr(heff_call(v_m_242443, 1, (V[]){v_st_242440}));
          switch (heff_tag_of(v_x1_242444)) {
          case TAG_MkPair: {
            V v_x11_242445 = heff_field(v_x1_242444, 0);
            V v_st_242446 = heff_field(v_x1_242444, 1);
            V v_ru_24x1_242444_24MkPair = heff_take_reuse_n(v_x1_242444, 3ULL, 2);
            switch (heff_tag_of(v_x11_242445)) {
            case TAG_Left: {
              V v_e_242447 = heff_field(v_x11_242445, 0);
              heff_take_n(v_x11_242445, 1ULL, 1);
              heff_drop_rec(v_kw_241950, 9);
              heff_drop(v_a_241953);
              heff_drop(v_x_242442);
              heff_drop_cell(v_ru_24x1_242444_24MkPair, 2);
              return heff_tag_at_n(v_ru_24x1_242438_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242447}), v_st_242446});
            }
            case TAG_Right: {
              V v_x_242448 = heff_field(v_x11_242445, 0);
              heff_take_n(v_x11_242445, 1ULL, 1);
              V v_t_242449 = (g_heff_2esyntax_2ecst_2elastE(v_a_241953));
              V v_e_242450 = heff_get_n(v_t_242449, 4, 9);
              V v_t_242451 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_241950, 3, 9), v_e_242450});
              V v_x_242452 = heff_tag_at_n(v_ru_24x1_242444_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_EIfThen, 2, (V[]){v_x_242442, v_x_242448}), v_t_242451});
              return heff_tag_at_n(v_ru_24x1_242438_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_242452}), v_st_242446});
            }
            default: return heff_nomatch(v_x11_242445);
            }
          }
          default: return heff_nomatch(v_x1_242444);
          }
        }
        default: return heff_nomatch(v_x11_242439);
        }
      }
      default: return heff_nomatch(v_x1_242438);
      }
    }
    case TAG_If: {
      V v_m_242459 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_241951}));
      V v_x1_242460 = heff_tr(heff_call(v_m_242459, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_242460)) {
      case TAG_MkPair: {
        V v_x11_242461 = heff_field(v_x1_242460, 0);
        V v_st_242462 = heff_field(v_x1_242460, 1);
        V v_ru_24x1_242460_24MkPair = heff_take_reuse_n(v_x1_242460, 3ULL, 2);
        switch (heff_tag_of(v_x11_242461)) {
        case TAG_Left: {
          V v_e_242463 = heff_field(v_x11_242461, 0);
          heff_take_n(v_x11_242461, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_241950, 9);
          heff_drop(v_a_241953);
          return heff_tag_at_n(v_ru_24x1_242460_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242463}), v_st_242462});
        }
        case TAG_Right: {
          V v_x_242464 = heff_field(v_x11_242461, 0);
          heff_take_n(v_x11_242461, 1ULL, 1);
          V v_m_242465 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_a_241953)}));
          V v_x1_242466 = heff_tr(heff_call(v_m_242465, 1, (V[]){v_st_242462}));
          switch (heff_tag_of(v_x1_242466)) {
          case TAG_MkPair: {
            V v_x11_242467 = heff_field(v_x1_242466, 0);
            V v_st_242468 = heff_field(v_x1_242466, 1);
            V v_ru_24x1_242466_24MkPair = heff_take_reuse_n(v_x1_242466, 3ULL, 2);
            switch (heff_tag_of(v_x11_242467)) {
            case TAG_Left: {
              V v_e_242469 = heff_field(v_x11_242467, 0);
              heff_take_n(v_x11_242467, 1ULL, 1);
              heff_drop_rec(v_kw_241950, 9);
              heff_drop(v_a_241953);
              heff_drop(v_x_242464);
              heff_drop_cell(v_ru_24x1_242466_24MkPair, 2);
              return heff_tag_at_n(v_ru_24x1_242460_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242469}), v_st_242468});
            }
            case TAG_Right: {
              V v_x_242470 = heff_field(v_x11_242467, 0);
              heff_take_n(v_x11_242467, 1ULL, 1);
              V v_t_242471 = (g_heff_2esyntax_2ecst_2elastE(v_a_241953));
              V v_e_242472 = heff_get_n(v_t_242471, 4, 9);
              V v_t_242473 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_241950, 3, 9), v_e_242472});
              V v_x_242474 = heff_tag_at_n(v_ru_24x1_242466_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_EIfThen, 2, (V[]){v_x_242464, v_x_242470}), v_t_242473});
              return heff_tag_at_n(v_ru_24x1_242460_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_242474}), v_st_242468});
            }
            default: return heff_nomatch(v_x11_242467);
            }
          }
          default: return heff_nomatch(v_x1_242466);
          }
        }
        default: return heff_nomatch(v_x11_242461);
        }
      }
      default: return heff_nomatch(v_x1_242460);
      }
    }
    case TAG_Do: {
      V v_m_242477 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_241951}));
      V v_x1_242478 = heff_tr(heff_call(v_m_242477, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_242478)) {
      case TAG_MkPair: {
        V v_x11_242479 = heff_field(v_x1_242478, 0);
        V v_st_242480 = heff_field(v_x1_242478, 1);
        V v_ru_24x1_242478_24MkPair = heff_take_reuse_n(v_x1_242478, 3ULL, 2);
        switch (heff_tag_of(v_x11_242479)) {
        case TAG_Left: {
          V v_e_242481 = heff_field(v_x11_242479, 0);
          heff_take_n(v_x11_242479, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_241950, 9);
          heff_drop(v_a_241953);
          return heff_tag_at_n(v_ru_24x1_242478_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242481}), v_st_242480});
        }
        case TAG_Right: {
          V v_x_242482 = heff_field(v_x11_242479, 0);
          heff_take_n(v_x11_242479, 1ULL, 1);
          V v_m_242483 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_a_241953)}));
          V v_x1_242484 = heff_tr(heff_call(v_m_242483, 1, (V[]){v_st_242480}));
          switch (heff_tag_of(v_x1_242484)) {
          case TAG_MkPair: {
            V v_x11_242485 = heff_field(v_x1_242484, 0);
            V v_st_242486 = heff_field(v_x1_242484, 1);
            V v_ru_24x1_242484_24MkPair = heff_take_reuse_n(v_x1_242484, 3ULL, 2);
            switch (heff_tag_of(v_x11_242485)) {
            case TAG_Left: {
              V v_e_242487 = heff_field(v_x11_242485, 0);
              heff_take_n(v_x11_242485, 1ULL, 1);
              heff_drop_rec(v_kw_241950, 9);
              heff_drop(v_a_241953);
              heff_drop(v_x_242482);
              heff_drop_cell(v_ru_24x1_242484_24MkPair, 2);
              return heff_tag_at_n(v_ru_24x1_242478_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242487}), v_st_242486});
            }
            case TAG_Right: {
              V v_x_242488 = heff_field(v_x11_242485, 0);
              heff_take_n(v_x11_242485, 1ULL, 1);
              V v_t_242489 = (g_heff_2esyntax_2ecst_2elastE(v_a_241953));
              V v_e_242490 = heff_get_n(v_t_242489, 4, 9);
              V v_t_242491 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_241950, 3, 9), v_e_242490});
              V v_x_242492 = heff_tag_at_n(v_ru_24x1_242484_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_EIfThen, 2, (V[]){v_x_242482, v_x_242488}), v_t_242491});
              return heff_tag_at_n(v_ru_24x1_242478_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_242492}), v_st_242486});
            }
            default: return heff_nomatch(v_x11_242485);
            }
          }
          default: return heff_nomatch(v_x1_242484);
          }
        }
        default: return heff_nomatch(v_x11_242479);
        }
      }
      default: return heff_nomatch(v_x1_242478);
      }
    }
    case TAG_ESBind: {
      V v_m_242496 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_241951}));
      V v_x1_242497 = heff_tr(heff_call(v_m_242496, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_242497)) {
      case TAG_MkPair: {
        V v_x11_242498 = heff_field(v_x1_242497, 0);
        V v_st_242499 = heff_field(v_x1_242497, 1);
        V v_ru_24x1_242497_24MkPair = heff_take_reuse_n(v_x1_242497, 3ULL, 2);
        switch (heff_tag_of(v_x11_242498)) {
        case TAG_Left: {
          V v_e_242500 = heff_field(v_x11_242498, 0);
          heff_take_n(v_x11_242498, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_241950, 9);
          heff_drop(v_a_241953);
          return heff_tag_at_n(v_ru_24x1_242497_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242500}), v_st_242499});
        }
        case TAG_Right: {
          V v_x_242501 = heff_field(v_x11_242498, 0);
          heff_take_n(v_x11_242498, 1ULL, 1);
          V v_m_242502 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_a_241953)}));
          V v_x1_242503 = heff_tr(heff_call(v_m_242502, 1, (V[]){v_st_242499}));
          switch (heff_tag_of(v_x1_242503)) {
          case TAG_MkPair: {
            V v_x11_242504 = heff_field(v_x1_242503, 0);
            V v_st_242505 = heff_field(v_x1_242503, 1);
            V v_ru_24x1_242503_24MkPair = heff_take_reuse_n(v_x1_242503, 3ULL, 2);
            switch (heff_tag_of(v_x11_242504)) {
            case TAG_Left: {
              V v_e_242506 = heff_field(v_x11_242504, 0);
              heff_take_n(v_x11_242504, 1ULL, 1);
              heff_drop_rec(v_kw_241950, 9);
              heff_drop(v_a_241953);
              heff_drop(v_x_242501);
              heff_drop_cell(v_ru_24x1_242503_24MkPair, 2);
              return heff_tag_at_n(v_ru_24x1_242497_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242506}), v_st_242505});
            }
            case TAG_Right: {
              V v_x_242507 = heff_field(v_x11_242504, 0);
              heff_take_n(v_x11_242504, 1ULL, 1);
              V v_t_242508 = (g_heff_2esyntax_2ecst_2elastE(v_a_241953));
              V v_e_242509 = heff_get_n(v_t_242508, 4, 9);
              V v_t_242510 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_241950, 3, 9), v_e_242509});
              V v_x_242511 = heff_tag_at_n(v_ru_24x1_242503_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_EIfThen, 2, (V[]){v_x_242501, v_x_242507}), v_t_242510});
              return heff_tag_at_n(v_ru_24x1_242497_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_242511}), v_st_242505});
            }
            default: return heff_nomatch(v_x11_242504);
            }
          }
          default: return heff_nomatch(v_x1_242503);
          }
        }
        default: return heff_nomatch(v_x11_242498);
        }
      }
      default: return heff_nomatch(v_x1_242497);
      }
    }
    case TAG_ELet: {
      V v_m_242518 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_241951}));
      V v_x1_242519 = heff_tr(heff_call(v_m_242518, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_242519)) {
      case TAG_MkPair: {
        V v_x11_242520 = heff_field(v_x1_242519, 0);
        V v_st_242521 = heff_field(v_x1_242519, 1);
        V v_ru_24x1_242519_24MkPair = heff_take_reuse_n(v_x1_242519, 3ULL, 2);
        switch (heff_tag_of(v_x11_242520)) {
        case TAG_Left: {
          V v_e_242522 = heff_field(v_x11_242520, 0);
          heff_take_n(v_x11_242520, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_241950, 9);
          heff_drop(v_a_241953);
          return heff_tag_at_n(v_ru_24x1_242519_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242522}), v_st_242521});
        }
        case TAG_Right: {
          V v_x_242523 = heff_field(v_x11_242520, 0);
          heff_take_n(v_x11_242520, 1ULL, 1);
          V v_m_242524 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_a_241953)}));
          V v_x1_242525 = heff_tr(heff_call(v_m_242524, 1, (V[]){v_st_242521}));
          switch (heff_tag_of(v_x1_242525)) {
          case TAG_MkPair: {
            V v_x11_242526 = heff_field(v_x1_242525, 0);
            V v_st_242527 = heff_field(v_x1_242525, 1);
            V v_ru_24x1_242525_24MkPair = heff_take_reuse_n(v_x1_242525, 3ULL, 2);
            switch (heff_tag_of(v_x11_242526)) {
            case TAG_Left: {
              V v_e_242528 = heff_field(v_x11_242526, 0);
              heff_take_n(v_x11_242526, 1ULL, 1);
              heff_drop_rec(v_kw_241950, 9);
              heff_drop(v_a_241953);
              heff_drop(v_x_242523);
              heff_drop_cell(v_ru_24x1_242525_24MkPair, 2);
              return heff_tag_at_n(v_ru_24x1_242519_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242528}), v_st_242527});
            }
            case TAG_Right: {
              V v_x_242529 = heff_field(v_x11_242526, 0);
              heff_take_n(v_x11_242526, 1ULL, 1);
              V v_t_242530 = (g_heff_2esyntax_2ecst_2elastE(v_a_241953));
              V v_e_242531 = heff_get_n(v_t_242530, 4, 9);
              V v_t_242532 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_241950, 3, 9), v_e_242531});
              V v_x_242533 = heff_tag_at_n(v_ru_24x1_242525_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_EIfThen, 2, (V[]){v_x_242523, v_x_242529}), v_t_242532});
              return heff_tag_at_n(v_ru_24x1_242519_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_242533}), v_st_242527});
            }
            default: return heff_nomatch(v_x11_242526);
            }
          }
          default: return heff_nomatch(v_x1_242525);
          }
        }
        default: return heff_nomatch(v_x11_242520);
        }
      }
      default: return heff_nomatch(v_x1_242519);
      }
    }
    case TAG_ELetMut: {
      V v_m_242540 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_241951}));
      V v_x1_242541 = heff_tr(heff_call(v_m_242540, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_242541)) {
      case TAG_MkPair: {
        V v_x11_242542 = heff_field(v_x1_242541, 0);
        V v_st_242543 = heff_field(v_x1_242541, 1);
        V v_ru_24x1_242541_24MkPair = heff_take_reuse_n(v_x1_242541, 3ULL, 2);
        switch (heff_tag_of(v_x11_242542)) {
        case TAG_Left: {
          V v_e_242544 = heff_field(v_x11_242542, 0);
          heff_take_n(v_x11_242542, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_241950, 9);
          heff_drop(v_a_241953);
          return heff_tag_at_n(v_ru_24x1_242541_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242544}), v_st_242543});
        }
        case TAG_Right: {
          V v_x_242545 = heff_field(v_x11_242542, 0);
          heff_take_n(v_x11_242542, 1ULL, 1);
          V v_m_242546 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_a_241953)}));
          V v_x1_242547 = heff_tr(heff_call(v_m_242546, 1, (V[]){v_st_242543}));
          switch (heff_tag_of(v_x1_242547)) {
          case TAG_MkPair: {
            V v_x11_242548 = heff_field(v_x1_242547, 0);
            V v_st_242549 = heff_field(v_x1_242547, 1);
            V v_ru_24x1_242547_24MkPair = heff_take_reuse_n(v_x1_242547, 3ULL, 2);
            switch (heff_tag_of(v_x11_242548)) {
            case TAG_Left: {
              V v_e_242550 = heff_field(v_x11_242548, 0);
              heff_take_n(v_x11_242548, 1ULL, 1);
              heff_drop_rec(v_kw_241950, 9);
              heff_drop(v_a_241953);
              heff_drop(v_x_242545);
              heff_drop_cell(v_ru_24x1_242547_24MkPair, 2);
              return heff_tag_at_n(v_ru_24x1_242541_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242550}), v_st_242549});
            }
            case TAG_Right: {
              V v_x_242551 = heff_field(v_x11_242548, 0);
              heff_take_n(v_x11_242548, 1ULL, 1);
              V v_t_242552 = (g_heff_2esyntax_2ecst_2elastE(v_a_241953));
              V v_e_242553 = heff_get_n(v_t_242552, 4, 9);
              V v_t_242554 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_241950, 3, 9), v_e_242553});
              V v_x_242555 = heff_tag_at_n(v_ru_24x1_242547_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_EIfThen, 2, (V[]){v_x_242545, v_x_242551}), v_t_242554});
              return heff_tag_at_n(v_ru_24x1_242541_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_242555}), v_st_242549});
            }
            default: return heff_nomatch(v_x11_242548);
            }
          }
          default: return heff_nomatch(v_x1_242547);
          }
        }
        default: return heff_nomatch(v_x11_242542);
        }
      }
      default: return heff_nomatch(v_x1_242541);
      }
    }
    case TAG_EAssign: {
      V v_m_242559 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_241951}));
      V v_x1_242560 = heff_tr(heff_call(v_m_242559, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_242560)) {
      case TAG_MkPair: {
        V v_x11_242561 = heff_field(v_x1_242560, 0);
        V v_st_242562 = heff_field(v_x1_242560, 1);
        V v_ru_24x1_242560_24MkPair = heff_take_reuse_n(v_x1_242560, 3ULL, 2);
        switch (heff_tag_of(v_x11_242561)) {
        case TAG_Left: {
          V v_e_242563 = heff_field(v_x11_242561, 0);
          heff_take_n(v_x11_242561, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_241950, 9);
          heff_drop(v_a_241953);
          return heff_tag_at_n(v_ru_24x1_242560_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242563}), v_st_242562});
        }
        case TAG_Right: {
          V v_x_242564 = heff_field(v_x11_242561, 0);
          heff_take_n(v_x11_242561, 1ULL, 1);
          V v_m_242565 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_a_241953)}));
          V v_x1_242566 = heff_tr(heff_call(v_m_242565, 1, (V[]){v_st_242562}));
          switch (heff_tag_of(v_x1_242566)) {
          case TAG_MkPair: {
            V v_x11_242567 = heff_field(v_x1_242566, 0);
            V v_st_242568 = heff_field(v_x1_242566, 1);
            V v_ru_24x1_242566_24MkPair = heff_take_reuse_n(v_x1_242566, 3ULL, 2);
            switch (heff_tag_of(v_x11_242567)) {
            case TAG_Left: {
              V v_e_242569 = heff_field(v_x11_242567, 0);
              heff_take_n(v_x11_242567, 1ULL, 1);
              heff_drop_rec(v_kw_241950, 9);
              heff_drop(v_a_241953);
              heff_drop(v_x_242564);
              heff_drop_cell(v_ru_24x1_242566_24MkPair, 2);
              return heff_tag_at_n(v_ru_24x1_242560_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242569}), v_st_242568});
            }
            case TAG_Right: {
              V v_x_242570 = heff_field(v_x11_242567, 0);
              heff_take_n(v_x11_242567, 1ULL, 1);
              V v_t_242571 = (g_heff_2esyntax_2ecst_2elastE(v_a_241953));
              V v_e_242572 = heff_get_n(v_t_242571, 4, 9);
              V v_t_242573 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_241950, 3, 9), v_e_242572});
              V v_x_242574 = heff_tag_at_n(v_ru_24x1_242566_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_EIfThen, 2, (V[]){v_x_242564, v_x_242570}), v_t_242573});
              return heff_tag_at_n(v_ru_24x1_242560_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_242574}), v_st_242568});
            }
            default: return heff_nomatch(v_x11_242567);
            }
          }
          default: return heff_nomatch(v_x1_242566);
          }
        }
        default: return heff_nomatch(v_x11_242561);
        }
      }
      default: return heff_nomatch(v_x1_242560);
      }
    }
    case TAG_EWhile: {
      V v_m_242579 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_241951}));
      V v_x1_242580 = heff_tr(heff_call(v_m_242579, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_242580)) {
      case TAG_MkPair: {
        V v_x11_242581 = heff_field(v_x1_242580, 0);
        V v_st_242582 = heff_field(v_x1_242580, 1);
        V v_ru_24x1_242580_24MkPair = heff_take_reuse_n(v_x1_242580, 3ULL, 2);
        switch (heff_tag_of(v_x11_242581)) {
        case TAG_Left: {
          V v_e_242583 = heff_field(v_x11_242581, 0);
          heff_take_n(v_x11_242581, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_241950, 9);
          heff_drop(v_a_241953);
          return heff_tag_at_n(v_ru_24x1_242580_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242583}), v_st_242582});
        }
        case TAG_Right: {
          V v_x_242584 = heff_field(v_x11_242581, 0);
          heff_take_n(v_x11_242581, 1ULL, 1);
          V v_m_242585 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_a_241953)}));
          V v_x1_242586 = heff_tr(heff_call(v_m_242585, 1, (V[]){v_st_242582}));
          switch (heff_tag_of(v_x1_242586)) {
          case TAG_MkPair: {
            V v_x11_242587 = heff_field(v_x1_242586, 0);
            V v_st_242588 = heff_field(v_x1_242586, 1);
            V v_ru_24x1_242586_24MkPair = heff_take_reuse_n(v_x1_242586, 3ULL, 2);
            switch (heff_tag_of(v_x11_242587)) {
            case TAG_Left: {
              V v_e_242589 = heff_field(v_x11_242587, 0);
              heff_take_n(v_x11_242587, 1ULL, 1);
              heff_drop_rec(v_kw_241950, 9);
              heff_drop(v_a_241953);
              heff_drop(v_x_242584);
              heff_drop_cell(v_ru_24x1_242586_24MkPair, 2);
              return heff_tag_at_n(v_ru_24x1_242580_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242589}), v_st_242588});
            }
            case TAG_Right: {
              V v_x_242590 = heff_field(v_x11_242587, 0);
              heff_take_n(v_x11_242587, 1ULL, 1);
              V v_t_242591 = (g_heff_2esyntax_2ecst_2elastE(v_a_241953));
              V v_e_242592 = heff_get_n(v_t_242591, 4, 9);
              V v_t_242593 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_241950, 3, 9), v_e_242592});
              V v_x_242594 = heff_tag_at_n(v_ru_24x1_242586_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_EIfThen, 2, (V[]){v_x_242584, v_x_242590}), v_t_242593});
              return heff_tag_at_n(v_ru_24x1_242580_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_242594}), v_st_242588});
            }
            default: return heff_nomatch(v_x11_242587);
            }
          }
          default: return heff_nomatch(v_x1_242586);
          }
        }
        default: return heff_nomatch(v_x11_242581);
        }
      }
      default: return heff_nomatch(v_x1_242580);
      }
    }
    case TAG_EFor: {
      V v_m_242601 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_241951}));
      V v_x1_242602 = heff_tr(heff_call(v_m_242601, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_242602)) {
      case TAG_MkPair: {
        V v_x11_242603 = heff_field(v_x1_242602, 0);
        V v_st_242604 = heff_field(v_x1_242602, 1);
        V v_ru_24x1_242602_24MkPair = heff_take_reuse_n(v_x1_242602, 3ULL, 2);
        switch (heff_tag_of(v_x11_242603)) {
        case TAG_Left: {
          V v_e_242605 = heff_field(v_x11_242603, 0);
          heff_take_n(v_x11_242603, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_241950, 9);
          heff_drop(v_a_241953);
          return heff_tag_at_n(v_ru_24x1_242602_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242605}), v_st_242604});
        }
        case TAG_Right: {
          V v_x_242606 = heff_field(v_x11_242603, 0);
          heff_take_n(v_x11_242603, 1ULL, 1);
          V v_m_242607 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_a_241953)}));
          V v_x1_242608 = heff_tr(heff_call(v_m_242607, 1, (V[]){v_st_242604}));
          switch (heff_tag_of(v_x1_242608)) {
          case TAG_MkPair: {
            V v_x11_242609 = heff_field(v_x1_242608, 0);
            V v_st_242610 = heff_field(v_x1_242608, 1);
            V v_ru_24x1_242608_24MkPair = heff_take_reuse_n(v_x1_242608, 3ULL, 2);
            switch (heff_tag_of(v_x11_242609)) {
            case TAG_Left: {
              V v_e_242611 = heff_field(v_x11_242609, 0);
              heff_take_n(v_x11_242609, 1ULL, 1);
              heff_drop_rec(v_kw_241950, 9);
              heff_drop(v_a_241953);
              heff_drop(v_x_242606);
              heff_drop_cell(v_ru_24x1_242608_24MkPair, 2);
              return heff_tag_at_n(v_ru_24x1_242602_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242611}), v_st_242610});
            }
            case TAG_Right: {
              V v_x_242612 = heff_field(v_x11_242609, 0);
              heff_take_n(v_x11_242609, 1ULL, 1);
              V v_t_242613 = (g_heff_2esyntax_2ecst_2elastE(v_a_241953));
              V v_e_242614 = heff_get_n(v_t_242613, 4, 9);
              V v_t_242615 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_241950, 3, 9), v_e_242614});
              V v_x_242616 = heff_tag_at_n(v_ru_24x1_242608_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_EIfThen, 2, (V[]){v_x_242606, v_x_242612}), v_t_242615});
              return heff_tag_at_n(v_ru_24x1_242602_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_242616}), v_st_242610});
            }
            default: return heff_nomatch(v_x11_242609);
            }
          }
          default: return heff_nomatch(v_x1_242608);
          }
        }
        default: return heff_nomatch(v_x11_242603);
        }
      }
      default: return heff_nomatch(v_x1_242602);
      }
    }
    case TAG_EJump: {
      V v_m_242618 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_241951}));
      V v_x1_242619 = heff_tr(heff_call(v_m_242618, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_242619)) {
      case TAG_MkPair: {
        V v_x11_242620 = heff_field(v_x1_242619, 0);
        V v_st_242621 = heff_field(v_x1_242619, 1);
        V v_ru_24x1_242619_24MkPair = heff_take_reuse_n(v_x1_242619, 3ULL, 2);
        switch (heff_tag_of(v_x11_242620)) {
        case TAG_Left: {
          V v_e_242622 = heff_field(v_x11_242620, 0);
          heff_take_n(v_x11_242620, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_241950, 9);
          heff_drop(v_a_241953);
          return heff_tag_at_n(v_ru_24x1_242619_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242622}), v_st_242621});
        }
        case TAG_Right: {
          V v_x_242623 = heff_field(v_x11_242620, 0);
          heff_take_n(v_x11_242620, 1ULL, 1);
          V v_m_242624 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_a_241953)}));
          V v_x1_242625 = heff_tr(heff_call(v_m_242624, 1, (V[]){v_st_242621}));
          switch (heff_tag_of(v_x1_242625)) {
          case TAG_MkPair: {
            V v_x11_242626 = heff_field(v_x1_242625, 0);
            V v_st_242627 = heff_field(v_x1_242625, 1);
            V v_ru_24x1_242625_24MkPair = heff_take_reuse_n(v_x1_242625, 3ULL, 2);
            switch (heff_tag_of(v_x11_242626)) {
            case TAG_Left: {
              V v_e_242628 = heff_field(v_x11_242626, 0);
              heff_take_n(v_x11_242626, 1ULL, 1);
              heff_drop_rec(v_kw_241950, 9);
              heff_drop(v_a_241953);
              heff_drop(v_x_242623);
              heff_drop_cell(v_ru_24x1_242625_24MkPair, 2);
              return heff_tag_at_n(v_ru_24x1_242619_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242628}), v_st_242627});
            }
            case TAG_Right: {
              V v_x_242629 = heff_field(v_x11_242626, 0);
              heff_take_n(v_x11_242626, 1ULL, 1);
              V v_t_242630 = (g_heff_2esyntax_2ecst_2elastE(v_a_241953));
              V v_e_242631 = heff_get_n(v_t_242630, 4, 9);
              V v_t_242632 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_241950, 3, 9), v_e_242631});
              V v_x_242633 = heff_tag_at_n(v_ru_24x1_242625_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_EIfThen, 2, (V[]){v_x_242623, v_x_242629}), v_t_242632});
              return heff_tag_at_n(v_ru_24x1_242619_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_242633}), v_st_242627});
            }
            default: return heff_nomatch(v_x11_242626);
            }
          }
          default: return heff_nomatch(v_x1_242625);
          }
        }
        default: return heff_nomatch(v_x11_242620);
        }
      }
      default: return heff_nomatch(v_x1_242619);
      }
    }
    case TAG_EReturn: {
      V v_m_242636 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_241951}));
      V v_x1_242637 = heff_tr(heff_call(v_m_242636, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_242637)) {
      case TAG_MkPair: {
        V v_x11_242638 = heff_field(v_x1_242637, 0);
        V v_st_242639 = heff_field(v_x1_242637, 1);
        V v_ru_24x1_242637_24MkPair = heff_take_reuse_n(v_x1_242637, 3ULL, 2);
        switch (heff_tag_of(v_x11_242638)) {
        case TAG_Left: {
          V v_e_242640 = heff_field(v_x11_242638, 0);
          heff_take_n(v_x11_242638, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_241950, 9);
          heff_drop(v_a_241953);
          return heff_tag_at_n(v_ru_24x1_242637_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242640}), v_st_242639});
        }
        case TAG_Right: {
          V v_x_242641 = heff_field(v_x11_242638, 0);
          heff_take_n(v_x11_242638, 1ULL, 1);
          V v_m_242642 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_a_241953)}));
          V v_x1_242643 = heff_tr(heff_call(v_m_242642, 1, (V[]){v_st_242639}));
          switch (heff_tag_of(v_x1_242643)) {
          case TAG_MkPair: {
            V v_x11_242644 = heff_field(v_x1_242643, 0);
            V v_st_242645 = heff_field(v_x1_242643, 1);
            V v_ru_24x1_242643_24MkPair = heff_take_reuse_n(v_x1_242643, 3ULL, 2);
            switch (heff_tag_of(v_x11_242644)) {
            case TAG_Left: {
              V v_e_242646 = heff_field(v_x11_242644, 0);
              heff_take_n(v_x11_242644, 1ULL, 1);
              heff_drop_rec(v_kw_241950, 9);
              heff_drop(v_a_241953);
              heff_drop(v_x_242641);
              heff_drop_cell(v_ru_24x1_242643_24MkPair, 2);
              return heff_tag_at_n(v_ru_24x1_242637_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242646}), v_st_242645});
            }
            case TAG_Right: {
              V v_x_242647 = heff_field(v_x11_242644, 0);
              heff_take_n(v_x11_242644, 1ULL, 1);
              V v_t_242648 = (g_heff_2esyntax_2ecst_2elastE(v_a_241953));
              V v_e_242649 = heff_get_n(v_t_242648, 4, 9);
              V v_t_242650 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_241950, 3, 9), v_e_242649});
              V v_x_242651 = heff_tag_at_n(v_ru_24x1_242643_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_EIfThen, 2, (V[]){v_x_242641, v_x_242647}), v_t_242650});
              return heff_tag_at_n(v_ru_24x1_242637_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_242651}), v_st_242645});
            }
            default: return heff_nomatch(v_x11_242644);
            }
          }
          default: return heff_nomatch(v_x1_242643);
          }
        }
        default: return heff_nomatch(v_x11_242638);
        }
      }
      default: return heff_nomatch(v_x1_242637);
      }
    }
    case TAG_ENest: {
      V v_m_242656 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_241951}));
      V v_x1_242657 = heff_tr(heff_call(v_m_242656, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_242657)) {
      case TAG_MkPair: {
        V v_x11_242658 = heff_field(v_x1_242657, 0);
        V v_st_242659 = heff_field(v_x1_242657, 1);
        V v_ru_24x1_242657_24MkPair = heff_take_reuse_n(v_x1_242657, 3ULL, 2);
        switch (heff_tag_of(v_x11_242658)) {
        case TAG_Left: {
          V v_e_242660 = heff_field(v_x11_242658, 0);
          heff_take_n(v_x11_242658, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_241950, 9);
          heff_drop(v_a_241953);
          return heff_tag_at_n(v_ru_24x1_242657_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242660}), v_st_242659});
        }
        case TAG_Right: {
          V v_x_242661 = heff_field(v_x11_242658, 0);
          heff_take_n(v_x11_242658, 1ULL, 1);
          V v_m_242662 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_a_241953)}));
          V v_x1_242663 = heff_tr(heff_call(v_m_242662, 1, (V[]){v_st_242659}));
          switch (heff_tag_of(v_x1_242663)) {
          case TAG_MkPair: {
            V v_x11_242664 = heff_field(v_x1_242663, 0);
            V v_st_242665 = heff_field(v_x1_242663, 1);
            V v_ru_24x1_242663_24MkPair = heff_take_reuse_n(v_x1_242663, 3ULL, 2);
            switch (heff_tag_of(v_x11_242664)) {
            case TAG_Left: {
              V v_e_242666 = heff_field(v_x11_242664, 0);
              heff_take_n(v_x11_242664, 1ULL, 1);
              heff_drop_rec(v_kw_241950, 9);
              heff_drop(v_a_241953);
              heff_drop(v_x_242661);
              heff_drop_cell(v_ru_24x1_242663_24MkPair, 2);
              return heff_tag_at_n(v_ru_24x1_242657_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242666}), v_st_242665});
            }
            case TAG_Right: {
              V v_x_242667 = heff_field(v_x11_242664, 0);
              heff_take_n(v_x11_242664, 1ULL, 1);
              V v_t_242668 = (g_heff_2esyntax_2ecst_2elastE(v_a_241953));
              V v_e_242669 = heff_get_n(v_t_242668, 4, 9);
              V v_t_242670 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_241950, 3, 9), v_e_242669});
              V v_x_242671 = heff_tag_at_n(v_ru_24x1_242663_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_EIfThen, 2, (V[]){v_x_242661, v_x_242667}), v_t_242670});
              return heff_tag_at_n(v_ru_24x1_242657_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_242671}), v_st_242665});
            }
            default: return heff_nomatch(v_x11_242664);
            }
          }
          default: return heff_nomatch(v_x1_242663);
          }
        }
        default: return heff_nomatch(v_x11_242658);
        }
      }
      default: return heff_nomatch(v_x1_242657);
      }
    }
    case TAG_IfThen: {
      V v_m_242676 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_241951}));
      V v_x1_242677 = heff_tr(heff_call(v_m_242676, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_242677)) {
      case TAG_MkPair: {
        V v_x11_242678 = heff_field(v_x1_242677, 0);
        V v_st_242679 = heff_field(v_x1_242677, 1);
        V v_ru_24x1_242677_24MkPair = heff_take_reuse_n(v_x1_242677, 3ULL, 2);
        switch (heff_tag_of(v_x11_242678)) {
        case TAG_Left: {
          V v_e_242680 = heff_field(v_x11_242678, 0);
          heff_take_n(v_x11_242678, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_241950, 9);
          heff_drop(v_a_241953);
          return heff_tag_at_n(v_ru_24x1_242677_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242680}), v_st_242679});
        }
        case TAG_Right: {
          V v_x_242681 = heff_field(v_x11_242678, 0);
          heff_take_n(v_x11_242678, 1ULL, 1);
          V v_m_242682 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_a_241953)}));
          V v_x1_242683 = heff_tr(heff_call(v_m_242682, 1, (V[]){v_st_242679}));
          switch (heff_tag_of(v_x1_242683)) {
          case TAG_MkPair: {
            V v_x11_242684 = heff_field(v_x1_242683, 0);
            V v_st_242685 = heff_field(v_x1_242683, 1);
            V v_ru_24x1_242683_24MkPair = heff_take_reuse_n(v_x1_242683, 3ULL, 2);
            switch (heff_tag_of(v_x11_242684)) {
            case TAG_Left: {
              V v_e_242686 = heff_field(v_x11_242684, 0);
              heff_take_n(v_x11_242684, 1ULL, 1);
              heff_drop_rec(v_kw_241950, 9);
              heff_drop(v_a_241953);
              heff_drop(v_x_242681);
              heff_drop_cell(v_ru_24x1_242683_24MkPair, 2);
              return heff_tag_at_n(v_ru_24x1_242677_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242686}), v_st_242685});
            }
            case TAG_Right: {
              V v_x_242687 = heff_field(v_x11_242684, 0);
              heff_take_n(v_x11_242684, 1ULL, 1);
              V v_t_242688 = (g_heff_2esyntax_2ecst_2elastE(v_a_241953));
              V v_e_242689 = heff_get_n(v_t_242688, 4, 9);
              V v_t_242690 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_241950, 3, 9), v_e_242689});
              V v_x_242691 = heff_tag_at_n(v_ru_24x1_242683_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_EIfThen, 2, (V[]){v_x_242681, v_x_242687}), v_t_242690});
              return heff_tag_at_n(v_ru_24x1_242677_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_242691}), v_st_242685});
            }
            default: return heff_nomatch(v_x11_242684);
            }
          }
          default: return heff_nomatch(v_x1_242683);
          }
        }
        default: return heff_nomatch(v_x11_242678);
        }
      }
      default: return heff_nomatch(v_x1_242677);
      }
    }
    case TAG_ELetCond: {
      V v_p_242693 = heff_field(v_e02_241951, 1);
      V v_e_242695 = heff_field(v_e02_241951, 3);
      heff_take_n(v_e02_241951, 10ULL, 4);
      V v_t_242696 = (g_heff_2esyntax_2ecst_2elastE(heff_dup(v_a_241953)));
      V v_e_242697 = heff_get_n(v_t_242696, 4, 9);
      V v_t_242698 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_241950, 3, 9), v_e_242697});
      return (g_heff_2esyntax_2esurface_2eifLetL(v_r_240, v_t_242698, v_p_242693, v_e_242695, v_a_241953, NTAG(TAG_Nothing), v_z_242));
    }
    case TAG_ETry: {
      V v_m_242703 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_241951}));
      V v_x1_242704 = heff_tr(heff_call(v_m_242703, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_242704)) {
      case TAG_MkPair: {
        V v_x11_242705 = heff_field(v_x1_242704, 0);
        V v_st_242706 = heff_field(v_x1_242704, 1);
        V v_ru_24x1_242704_24MkPair = heff_take_reuse_n(v_x1_242704, 3ULL, 2);
        switch (heff_tag_of(v_x11_242705)) {
        case TAG_Left: {
          V v_e_242707 = heff_field(v_x11_242705, 0);
          heff_take_n(v_x11_242705, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_241950, 9);
          heff_drop(v_a_241953);
          return heff_tag_at_n(v_ru_24x1_242704_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242707}), v_st_242706});
        }
        case TAG_Right: {
          V v_x_242708 = heff_field(v_x11_242705, 0);
          heff_take_n(v_x11_242705, 1ULL, 1);
          V v_m_242709 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_a_241953)}));
          V v_x1_242710 = heff_tr(heff_call(v_m_242709, 1, (V[]){v_st_242706}));
          switch (heff_tag_of(v_x1_242710)) {
          case TAG_MkPair: {
            V v_x11_242711 = heff_field(v_x1_242710, 0);
            V v_st_242712 = heff_field(v_x1_242710, 1);
            V v_ru_24x1_242710_24MkPair = heff_take_reuse_n(v_x1_242710, 3ULL, 2);
            switch (heff_tag_of(v_x11_242711)) {
            case TAG_Left: {
              V v_e_242713 = heff_field(v_x11_242711, 0);
              heff_take_n(v_x11_242711, 1ULL, 1);
              heff_drop_rec(v_kw_241950, 9);
              heff_drop(v_a_241953);
              heff_drop(v_x_242708);
              heff_drop_cell(v_ru_24x1_242710_24MkPair, 2);
              return heff_tag_at_n(v_ru_24x1_242704_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242713}), v_st_242712});
            }
            case TAG_Right: {
              V v_x_242714 = heff_field(v_x11_242711, 0);
              heff_take_n(v_x11_242711, 1ULL, 1);
              V v_t_242715 = (g_heff_2esyntax_2ecst_2elastE(v_a_241953));
              V v_e_242716 = heff_get_n(v_t_242715, 4, 9);
              V v_t_242717 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_241950, 3, 9), v_e_242716});
              V v_x_242718 = heff_tag_at_n(v_ru_24x1_242710_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_EIfThen, 2, (V[]){v_x_242708, v_x_242714}), v_t_242717});
              return heff_tag_at_n(v_ru_24x1_242704_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_242718}), v_st_242712});
            }
            default: return heff_nomatch(v_x11_242711);
            }
          }
          default: return heff_nomatch(v_x1_242710);
          }
        }
        default: return heff_nomatch(v_x11_242705);
        }
      }
      default: return heff_nomatch(v_x1_242704);
      }
    }
    case TAG_ECatch: {
      V v_m_242723 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_241951}));
      V v_x1_242724 = heff_tr(heff_call(v_m_242723, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_242724)) {
      case TAG_MkPair: {
        V v_x11_242725 = heff_field(v_x1_242724, 0);
        V v_st_242726 = heff_field(v_x1_242724, 1);
        V v_ru_24x1_242724_24MkPair = heff_take_reuse_n(v_x1_242724, 3ULL, 2);
        switch (heff_tag_of(v_x11_242725)) {
        case TAG_Left: {
          V v_e_242727 = heff_field(v_x11_242725, 0);
          heff_take_n(v_x11_242725, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_241950, 9);
          heff_drop(v_a_241953);
          return heff_tag_at_n(v_ru_24x1_242724_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242727}), v_st_242726});
        }
        case TAG_Right: {
          V v_x_242728 = heff_field(v_x11_242725, 0);
          heff_take_n(v_x11_242725, 1ULL, 1);
          V v_m_242729 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_a_241953)}));
          V v_x1_242730 = heff_tr(heff_call(v_m_242729, 1, (V[]){v_st_242726}));
          switch (heff_tag_of(v_x1_242730)) {
          case TAG_MkPair: {
            V v_x11_242731 = heff_field(v_x1_242730, 0);
            V v_st_242732 = heff_field(v_x1_242730, 1);
            V v_ru_24x1_242730_24MkPair = heff_take_reuse_n(v_x1_242730, 3ULL, 2);
            switch (heff_tag_of(v_x11_242731)) {
            case TAG_Left: {
              V v_e_242733 = heff_field(v_x11_242731, 0);
              heff_take_n(v_x11_242731, 1ULL, 1);
              heff_drop_rec(v_kw_241950, 9);
              heff_drop(v_a_241953);
              heff_drop(v_x_242728);
              heff_drop_cell(v_ru_24x1_242730_24MkPair, 2);
              return heff_tag_at_n(v_ru_24x1_242724_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242733}), v_st_242732});
            }
            case TAG_Right: {
              V v_x_242734 = heff_field(v_x11_242731, 0);
              heff_take_n(v_x11_242731, 1ULL, 1);
              V v_t_242735 = (g_heff_2esyntax_2ecst_2elastE(v_a_241953));
              V v_e_242736 = heff_get_n(v_t_242735, 4, 9);
              V v_t_242737 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_241950, 3, 9), v_e_242736});
              V v_x_242738 = heff_tag_at_n(v_ru_24x1_242730_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_EIfThen, 2, (V[]){v_x_242728, v_x_242734}), v_t_242737});
              return heff_tag_at_n(v_ru_24x1_242724_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_242738}), v_st_242732});
            }
            default: return heff_nomatch(v_x11_242731);
            }
          }
          default: return heff_nomatch(v_x1_242730);
          }
        }
        default: return heff_nomatch(v_x11_242725);
        }
      }
      default: return heff_nomatch(v_x1_242724);
      }
    }
    default: return heff_nomatch(v_e02_241951);
    }
  }
  case TAG_ELetCond: {
    heff_drop_rec(v_r_240, 3);
    V v_t_242743 = (g_heff_2esyntax_2ecst_2efirstE(v_e0_241));
    V v_t_242744 = ({ V a_0 = v_e0_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e0_241, 4); r_; });
    V v_t_242745 = heff_strAppend(heff_get_n(v_t_242744, 1, 9), ((V)&g_heff_2esyntax_2esurface_2eexprL_str38));
    V v_msg_242746 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eexprL_str39), v_t_242745);
    V v_t_242747 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_242743, 3), heff_get_n(v_t_242743, 4, 9)});
    V v_t_242748 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_242746, v_t_242747, NTAG(TAG_Nothing)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_242748}), v_z_242});
  }
  case TAG_ETry: {
    V v_kw_242749 = heff_dup(heff_field(v_e0_241, 0));
    V v_ty_242750 = heff_dup(heff_field(v_e0_241, 1));
    V v_body_242751 = heff_dup(heff_field(v_e0_241, 2));
    V v_c_242752 = heff_dup(heff_field(v_e0_241, 3));
    V v_m_242753 = (g_heff_2esyntax_2esurface_2etryTypeL(heff_dup(v_r_240), v_ty_242750));
    V v_x1_242754 = heff_tr(heff_call(v_m_242753, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x1_242754)) {
    case TAG_MkPair: {
      V v_x11_242755 = heff_field(v_x1_242754, 0);
      V v_st_242756 = heff_field(v_x1_242754, 1);
      V v_ru_24x1_242754_24MkPair = heff_take_reuse_n(v_x1_242754, 3ULL, 2);
      switch (heff_tag_of(v_x11_242755)) {
      case TAG_Left: {
        V v_e_242757 = heff_field(v_x11_242755, 0);
        heff_take_n(v_x11_242755, 1ULL, 1);
        heff_drop_rec(v_r_240, 3);
        heff_drop_tag(v_e0_241, 4);
        heff_drop_rec(v_kw_242749, 9);
        heff_drop(v_body_242751);
        heff_drop(v_c_242752);
        return heff_tag_at_n(v_ru_24x1_242754_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242757}), v_st_242756});
      }
      case TAG_Right: {
        V v_x_242758 = heff_field(v_x11_242755, 0);
        V v_ru_24x11_242755_24Right = heff_take_reuse_n(v_x11_242755, 1ULL, 1);
        HeffT2 v_t_242760 = (g_heff_2esyntax_2esurface_2eblock_24cpr(heff_clo_n(g_heff_2esyntax_2esurface_2eexprL_lam11, 1, 1, (V[]){heff_dup(v_r_240)}), v_body_242751, v_st_242756));
        {
          V v_field_242761 = v_t_242760.f[0];
          V v_field_242762 = v_t_242760.f[1];
          V v_x11_242763 = v_field_242761;
          V v_st_242764 = v_field_242762;
          switch (heff_tag_of(v_x11_242763)) {
          case TAG_Left: {
            V v_e_242765 = heff_field(v_x11_242763, 0);
            heff_take_n(v_x11_242763, 1ULL, 1);
            heff_drop_rec(v_r_240, 3);
            heff_drop_tag(v_e0_241, 4);
            heff_drop_rec(v_kw_242749, 9);
            heff_drop(v_c_242752);
            heff_drop(v_x_242758);
            heff_drop_cell(v_ru_24x11_242755_24Right, 1);
            return heff_tag_at_n(v_ru_24x1_242754_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242765}), v_st_242764});
          }
          case TAG_Right: {
            V v_x_242766 = heff_field(v_x11_242763, 0);
            heff_take_n(v_x11_242763, 1ULL, 1);
            V v_m_242767 = (g_heff_2esyntax_2esurface_2ecatchL(v_r_240, v_c_242752));
            V v_x1_242768 = heff_tr(heff_call(v_m_242767, 1, (V[]){v_st_242764}));
            switch (heff_tag_of(v_x1_242768)) {
            case TAG_MkPair: {
              V v_x11_242769 = heff_field(v_x1_242768, 0);
              V v_st_242770 = heff_field(v_x1_242768, 1);
              V v_ru_24x1_242768_24MkPair = heff_take_reuse_n(v_x1_242768, 3ULL, 2);
              switch (heff_tag_of(v_x11_242769)) {
              case TAG_Left: {
                V v_e_242771 = heff_field(v_x11_242769, 0);
                heff_take_n(v_x11_242769, 1ULL, 1);
                heff_drop_tag(v_e0_241, 4);
                heff_drop_rec(v_kw_242749, 9);
                heff_drop(v_x_242758);
                heff_drop_cell(v_ru_24x11_242755_24Right, 1);
                heff_drop(v_x_242766);
                heff_drop_cell(v_ru_24x1_242768_24MkPair, 2);
                return heff_tag_at_n(v_ru_24x1_242754_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242771}), v_st_242770});
              }
              case TAG_Right: {
                V v_x_242772 = heff_field(v_x11_242769, 0);
                heff_take_n(v_x11_242769, 1ULL, 1);
                V v_t_242773 = heff_tag_at_n(v_ru_24x11_242755_24Right, TAG_ETry, 1, (V[]){heff_tag_n(TAG_MkTry, 3, (V[]){v_x_242758, v_x_242766, v_x_242772})});
                V v_t_242774 = (g_heff_2esyntax_2ecst_2elastE(v_e0_241));
                V v_e_242775 = heff_get_n(v_t_242774, 4, 9);
                V v_t_242776 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_242749, 3, 9), v_e_242775});
                V v_x_242777 = heff_tag_at_n(v_ru_24x1_242768_24MkPair, TAG_At, 2, (V[]){v_t_242773, v_t_242776});
                return heff_tag_at_n(v_ru_24x1_242754_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_242777}), v_st_242770});
              }
              default: return heff_nomatch(v_x11_242769);
              }
            }
            default: return heff_nomatch(v_x1_242768);
            }
          }
          default: return heff_nomatch(v_x11_242763);
          }
        }
      }
      default: return heff_nomatch(v_x11_242755);
      }
    }
    default: return heff_nomatch(v_x1_242754);
    }
  }
  case TAG_ECatch: {
    heff_drop_rec(v_r_240, 3);
    V v_t_242782 = (g_heff_2esyntax_2ecst_2efirstE(v_e0_241));
    V v_t_242783 = ({ V a_0 = v_e0_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e0_241, 4); r_; });
    V v_t_242784 = heff_strAppend(heff_get_n(v_t_242783, 1, 9), ((V)&g_heff_2esyntax_2esurface_2eexprL_str40));
    V v_msg_242785 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eexprL_str41), v_t_242784);
    V v_t_242786 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_242782, 3), heff_get_n(v_t_242782, 4, 9)});
    V v_t_242787 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_242785, v_t_242786, NTAG(TAG_Nothing)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_242787}), v_z_242});
  }
  default: return heff_nomatch(v_e0_241);
  }
}
V g_heff_2esyntax_2esurface_2eexprL_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2eexprL(a[0], a[1], a[2]);
}
V g_heff_2esyntax_2esurface_2eexprL_lam0(V self, V *args) {
  V v_m_2431 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2esyntax_2esurface_2esegmentL(v_r_240, v_m_2431));
}
V g_heff_2esyntax_2esurface_2eexprL_lam1(V self, V *args) {
  V v_x_2449 = args[0];
  V v_rest_2450 = args[1];
  V v_sp_2447 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2451 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ETag, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2eexprL_str8)}), v_sp_2447});
  V v_t_2452 = heff_tag_n(TAG_Cons, 2, (V[]){v_rest_2450, NTAG(TAG_Nil)});
  return (g_heff_2esyntax_2epresyntax_2eapp(v_t_2451, heff_tag_n(TAG_Cons, 2, (V[]){v_x_2449, v_t_2452})));
}
V g_heff_2esyntax_2esurface_2eexprL_lam2(V self, V *args) {
  V v_m_2487 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2esyntax_2esurface_2eupdateSettingL(v_r_240, v_m_2487));
}
V g_heff_2esyntax_2esurface_2eexprL_lam3(V self, V *args) {
  V v_a_24141 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2esyntax_2esurface_2evariantL(v_r_240, v_a_24141));
}
V g_heff_2esyntax_2esurface_2eexprL_lam4(V self, V *args) {
  V v_m_24648 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2esyntax_2esurface_2eargL(v_r_240, v_m_24648));
}
V g_heff_2esyntax_2esurface_2eexprL_lam6(V self, V *args) {
  V v_st_24674 = args[0];
  V v_m_24673 = heff_env(self)[0];
  V v_op_24671 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24675 = heff_tr(heff_call(v_m_24673, 1, (V[]){v_st_24674}));
  switch (heff_tag_of(v_x1_24675)) {
  case TAG_MkPair: {
    V v_x11_24676 = heff_field(v_x1_24675, 0);
    V v_st_24677 = heff_field(v_x1_24675, 1);
    V v_ru_24x1_24675_24MkPair = heff_take_reuse_n(v_x1_24675, 3ULL, 2);
    switch (heff_tag_of(v_x11_24676)) {
    case TAG_Left: {
      V v_e_24678 = heff_field(v_x11_24676, 0);
      heff_take_n(v_x11_24676, 1ULL, 1);
      heff_drop(v_op_24671);
      return heff_tag_at_n(v_ru_24x1_24675_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24678}), v_st_24677});
    }
    case TAG_Right: {
      V v_x_24679 = heff_field(v_x11_24676, 0);
      V v_ru_24x11_24676_24Right = heff_take_reuse_n(v_x11_24676, 1ULL, 1);
      V v_t_24680 = heff_tag_at_n(v_ru_24x11_24676_24Right, TAG_Right, 1, (V[]){heff_rec_n(2, shape_op__e, (V[]){v_op_24671, v_x_24679})});
      return heff_tag_at_n(v_ru_24x1_24675_24MkPair, TAG_MkPair, 2, (V[]){v_t_24680, v_st_24677});
    }
    default: return heff_nomatch(v_x11_24676);
    }
  }
  default: return heff_nomatch(v_x1_24675);
  }
}
V g_heff_2esyntax_2esurface_2eexprL_lam5(V self, V *args) {
  V v_m_24667 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_24668 = (g_heff_2esyntax_2esurface_2eopRhsOf_24cpr(v_m_24667));
  {
    V v_field_24669 = v_t_24668.f[0];
    V v_field_24670 = v_t_24668.f[1];
    V v_op_24671 = v_field_24669;
    V v_e_24672 = v_field_24670;
    V v_m_24673 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_24672}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2eexprL_lam6, 1, 2, (V[]){v_m_24673, v_op_24671});
  }
}
V g_heff_2esyntax_2esurface_2eexprL_lam7(V self, V *args) {
  V v_a_24759 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2esyntax_2esurface_2ealtL(v_r_240, v_a_24759));
}
V g_heff_2esyntax_2esurface_2eexprL_lam8(V self, V *args) {
  V v_m_241813 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2esyntax_2esurface_2estmtL(v_r_240, v_m_241813));
}
V g_heff_2esyntax_2esurface_2eexprL_lam9(V self, V *args) {
  V v_m_241877 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2esyntax_2esurface_2estmtL(v_r_240, v_m_241877));
}
V g_heff_2esyntax_2esurface_2eexprL_lam10(V self, V *args) {
  V v_m_241908 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2esyntax_2esurface_2estmtL(v_r_240, v_m_241908));
}
V g_heff_2esyntax_2esurface_2eexprL_lam11(V self, V *args) {
  V v_m_242759 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2esyntax_2esurface_2estmtL(v_r_240, v_m_242759));
}
V g_heff_2esyntax_2esurface_2edefaultL_lam0(V self, V *args); static Clo g_heff_2esyntax_2esurface_2edefaultL_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2edefaultL_lam0, 1, 0};
V g_heff_2esyntax_2esurface_2edefaultL_lam1(V self, V *args);
Clo g_heff_2esyntax_2esurface_2edefaultL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2edefaultL_entry, 2, 0};

V g_heff_2esyntax_2esurface_2edefaultL(V v_r_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nothing: {
    heff_drop_rec(v_r_240, 3);
    return ((V)&g_heff_2esyntax_2esurface_2edefaultL_lam0_clo);
  }
  case TAG_Just: {
    V v_x21_244 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    switch (heff_tag_of(v_x21_244)) {
    case TAG_MkPair: {
      V v_d_246 = heff_field(v_x21_244, 1);
      heff_take_n(v_x21_244, 2ULL, 2);
      V v_m_247 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_d_246}));
      return heff_clo_n(g_heff_2esyntax_2esurface_2edefaultL_lam1, 1, 1, (V[]){v_m_247});
    }
    default: return heff_nomatch(v_x21_244);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2esurface_2edefaultL_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2edefaultL(a[0], a[1]);
}
V g_heff_2esyntax_2esurface_2edefaultL_lam0(V self, V *args) {
  V v_st_242 = args[0];
  V v_t_243 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_243, v_st_242});
}
V g_heff_2esyntax_2esurface_2edefaultL_lam1(V self, V *args) {
  V v_st_248 = args[0];
  V v_m_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_249 = heff_tr(heff_call(v_m_247, 1, (V[]){v_st_248}));
  switch (heff_tag_of(v_x1_249)) {
  case TAG_MkPair: {
    V v_x11_2410 = heff_field(v_x1_249, 0);
    V v_st_2411 = heff_field(v_x1_249, 1);
    V v_ru_24x1_249_24MkPair = heff_take_reuse_n(v_x1_249, 3ULL, 2);
    switch (heff_tag_of(v_x11_2410)) {
    case TAG_Left: {
      V v_e_2412 = heff_field(v_x11_2410, 0);
      heff_take_n(v_x11_2410, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_249_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2412}), v_st_2411});
    }
    case TAG_Right: {
      V v_x_2413 = heff_field(v_x11_2410, 0);
      V v_ru_24x11_2410_24Right = heff_take_reuse_n(v_x11_2410, 1ULL, 1);
      V v_t_2414 = heff_tag_at_n(v_ru_24x11_2410_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Just, 1, (V[]){v_x_2413})});
      return heff_tag_at_n(v_ru_24x1_249_24MkPair, TAG_MkPair, 2, (V[]){v_t_2414, v_st_2411});
    }
    default: return heff_nomatch(v_x11_2410);
    }
  }
  default: return heff_nomatch(v_x1_249);
  }
}
Clo g_heff_2esyntax_2esurface_2erightsOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2erightsOf_entry, 1, 0};

V g_heff_2esyntax_2esurface_2erightsOf(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_Left: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Right: {
      V v_x_244 = heff_field(v_x11_241, 0);
      heff_take_n(v_x11_241, 1ULL, 1);
      V v_cell_245 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_244, heff_hole()});
      V v_u_246 = (g_heff_2esyntax_2esurface_2erightsOf_24dps(v_rest_242, heff_dup(v_cell_245)));
      heff_drop(v_u_246);
      return v_cell_245;
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2esurface_2erightsOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2erightsOf(a[0]);
}