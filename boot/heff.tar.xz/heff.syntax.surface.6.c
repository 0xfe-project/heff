// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Ann 13421
#define TAG_App 13485
#define TAG_At 8900
#define TAG_Atom 28502
#define TAG_BAnn 9252
#define TAG_BImp 16911
#define TAG_BPat 23270
#define TAG_BVar 29034
#define TAG_Braces 8205
#define TAG_Case 4415
#define TAG_DeclDefine 5286
#define TAG_DeclEquations 25755
#define TAG_DeclPrimitive 46335
#define TAG_DeclTest 38719
#define TAG_DeclTheory 39552
#define TAG_DeclWatch 51419
#define TAG_Do 8988
#define TAG_Doc 16324
#define TAG_EAnn 33099
#define TAG_EArrow 13977
#define TAG_EAssign 4102
#define TAG_EBinary 42634
#define TAG_EBreak 7195
#define TAG_ECon 35052
#define TAG_EContinue 48638
#define TAG_EDo 15964
#define TAG_EField 26142
#define TAG_EFor 37939
#define TAG_EInvalid 31081
#define TAG_EJump 55703
#define TAG_ELazy 30951
#define TAG_ELet 43397
#define TAG_ELetIn 22786
#define TAG_EMatch 41631
#define TAG_ENamed 41119
#define TAG_ENeg 45306
#define TAG_ENest 28629
#define TAG_EParen 58248
#define TAG_EProject 35489
#define TAG_EReturn 59059
#define TAG_ESum 50613
#define TAG_ETag 50948
#define TAG_ETilde 53294
#define TAG_ETry 51493
#define TAG_ETuple 21722
#define TAG_EUSet 22856
#define TAG_EUpdate 6986
#define TAG_EVar 52881
#define TAG_EWhile 39339
#define TAG_EWith 38507
#define TAG_EWithBound 48916
#define TAG_EWord 44207
#define TAG_Eqn 17358
#define TAG_ExplicitParam 63083
#define TAG_FloatValue 23118
#define TAG_If 9134
#define TAG_IfThen 36069
#define TAG_InstB 37114
#define TAG_IntValue 62477
#define TAG_Lam 23588
#define TAG_LamAnn 40466
#define TAG_LamImplicit 28191
#define TAG_LamName 56383
#define TAG_Left 13886
#define TAG_MkAlt 55173
#define TAG_MkDAlts 45152
#define TAG_MkEquation 38417
#define TAG_MkTry 8097
#define TAG_Named 2049
#define TAG_Names 2064
#define TAG_Op 9330
#define TAG_OpRhs 36076
#define TAG_Ops 26942
#define TAG_OtherValue 43098
#define TAG_PAtom 50987
#define TAG_Passes 47566
#define TAG_PatVar 49363
#define TAG_Right 62770
#define TAG_RuneValue 49425
#define TAG_SError 24172
#define TAG_SegmentBinary 41188
#define TAG_SegmentBits 43687
#define TAG_SegmentFloat 21180
#define TAG_SegmentInteger 22664
#define TAG_SegmentUtf 5205
#define TAG_SetPath 11095
#define TAG_Sig 30557
#define TAG_SizeDefault 11444
#define TAG_SizeName 63845
#define TAG_SizeNumber 5591
#define TAG_StmtLet 16809
#define TAG_StrValue 22621
#define TAG_Sum 30935
#define TAG_Tup 31899
#define TAG_TypeWord 10401
#define TAG_Update 40810
#define TAG_Whole 6035
#define LBL_arms 9498206
#define LBL_at 9882
#define LBL_binder 558177493
#define LBL_binders 123633223
#define LBL_blank 295177582
#define LBL_code 9554612
#define LBL_col 308218
#define LBL_diags 296935042
#define LBL_e 319
#define LBL_end 310101
#define LBL_first 298798794
#define LBL_fix 310927
#define LBL_groups 709681407
#define LBL_id 10114
#define LBL_items 301884378
#define LBL_ix 10134
#define LBL_kind 9787483
#define LBL_knot 9792335
#define LBL_known 303562589
#define LBL_lenient 294367673
#define LBL_little 844663329
#define LBL_msg 317947
#define LBL_name 9869138
#define LBL_note 9882809
#define LBL_op 10312
#define LBL_ops 319788
#define LBL_out 319944
#define LBL_pat 320285
#define LBL_patVars 1587353522
#define LBL_raw 322210
#define LBL_scope 310622830
#define LBL_severity 75955546
#define LBL_signed 1044674119
#define LBL_size 10026184
#define LBL_span 10032145
#define LBL_start 311115900
#define LBL_text 10052084
#define LBL_toks 10061290
#define LBL_ty 10476
#define LBL_unit 10090059
#define LBL_waiting 1348170899
static uint32_t shape_binder__span__pat[] = {LBL_binder, LBL_span, LBL_pat};
static uint32_t shape_code__severity__msg__span__note[] = {LBL_code, LBL_severity, LBL_msg, LBL_span, LBL_note};
static uint32_t shape_items__waiting__diags[] = {LBL_items, LBL_waiting, LBL_diags};
static uint32_t shape_kind__text__raw__start__end__col__first__ix__blank[] = {LBL_kind, LBL_text, LBL_raw, LBL_start, LBL_end, LBL_col, LBL_first, LBL_ix, LBL_blank};
static uint32_t shape_op__e[] = {LBL_op, LBL_e};
static uint32_t shape_ops__out[] = {LBL_ops, LBL_out};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
static uint32_t shape_toks__scope__known__binders__patVars__fix__lenient__at__knot__arms[] = {LBL_toks, LBL_scope, LBL_known, LBL_binders, LBL_patVars, LBL_fix, LBL_lenient, LBL_at, LBL_knot, LBL_arms};
static uint32_t shape_ty__size__unit__little__signed[] = {LBL_ty, LBL_size, LBL_unit, LBL_little, LBL_signed};
V g_heff_2esyntax_2ecst_2efirstE(V);
V g_heff_2esyntax_2ecst_2efirstE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2efirstE_clo;
V g_heff_2esyntax_2ecst_2elastD(V);
V g_heff_2esyntax_2ecst_2elastD_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2elastD_clo;
V g_heff_2esyntax_2ecst_2elastE(V);
V g_heff_2esyntax_2ecst_2elastE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2elastE_clo;
V g_heff_2esyntax_2efixity_2elosers(V, V);
V g_heff_2esyntax_2efixity_2elosers_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efixity_2elosers_clo;
V g_heff_2esyntax_2efixity_2etighterGo(V, V, V, V);
V g_heff_2esyntax_2efixity_2etighterGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efixity_2etighterGo_clo;
V g_heff_2esyntax_2efmt_2elex_2ekeywords_get(void);
V g_heff_2esyntax_2epresyntax_2eapp(V, V);
V g_heff_2esyntax_2epresyntax_2eapp_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eapp_clo;
V g_heff_2esyntax_2esurface_2ealtL(V, V);
V g_heff_2esyntax_2esurface_2ealtL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ealtL_clo;
V g_heff_2esyntax_2esurface_2eanyS(V, V);
V g_heff_2esyntax_2esurface_2eanyS_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eanyS_clo;
V g_heff_2esyntax_2esurface_2eappendS(V, V);
V g_heff_2esyntax_2esurface_2eappendS_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eappendS_clo;
V g_heff_2esyntax_2esurface_2eappendS_24dps(V, V, V);
V g_heff_2esyntax_2esurface_2eappendS_24dps_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eappendS_24dps_clo;
V g_heff_2esyntax_2esurface_2eappendS_24f1650453221x1165775554(V, V);
V g_heff_2esyntax_2esurface_2eappendS_24f1650453221x1165775554_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eappendS_24f1650453221x1165775554_clo;
V g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830(V, V);
V g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830_clo;
V g_heff_2esyntax_2esurface_2eappendS_24tok2(V, V, V);
V g_heff_2esyntax_2esurface_2eappendS_24tok2_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eappendS_24tok2_clo;
V g_heff_2esyntax_2esurface_2easBinderOn(V, V);
V g_heff_2esyntax_2esurface_2easBinderOn_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2easBinderOn_clo;
V g_heff_2esyntax_2esurface_2easBinderOn_24tok1(V, V, V);
V g_heff_2esyntax_2esurface_2easBinderOn_24tok1_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2easBinderOn_24tok1_clo;
V g_heff_2esyntax_2esurface_2easBinderOn_24tok2(V, V, V);
V g_heff_2esyntax_2esurface_2easBinderOn_24tok2_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2easBinderOn_24tok2_clo;
V g_heff_2esyntax_2esurface_2eatomTok(V);
V g_heff_2esyntax_2esurface_2eatomTok_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eatomTok_clo;
V g_heff_2esyntax_2esurface_2ebind(V, V, V);
V g_heff_2esyntax_2esurface_2ebind_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ebind_clo;
V g_heff_2esyntax_2esurface_2ebind_24s273834694x1861812659(V, V, V, V);
V g_heff_2esyntax_2esurface_2ebind_24s273834694x1861812659_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ebind_24s273834694x1861812659_clo;
V g_heff_2esyntax_2esurface_2ebind_24s273834694x1861812659_24tok2(V, V, V, V, V);
V g_heff_2esyntax_2esurface_2ebind_24s273834694x1861812659_24tok2_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ebind_24s273834694x1861812659_24tok2_clo;
V g_heff_2esyntax_2esurface_2ebind_24tok1(V, V, V, V);
V g_heff_2esyntax_2esurface_2ebind_24tok1_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ebind_24tok1_clo;
V g_heff_2esyntax_2esurface_2ebind_24tok2(V, V, V, V);
V g_heff_2esyntax_2esurface_2ebind_24tok2_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ebind_24tok2_clo;
V g_heff_2esyntax_2esurface_2ebindingL(V, V);
V g_heff_2esyntax_2esurface_2ebindingL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ebindingL_clo;
V g_heff_2esyntax_2esurface_2eboundBy(V, V);
V g_heff_2esyntax_2esurface_2eboundBy_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eboundBy_clo;
V g_heff_2esyntax_2esurface_2ebracesL(V, V, V, V, V);
V g_heff_2esyntax_2esurface_2ebracesL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ebracesL_clo;
V g_heff_2esyntax_2esurface_2ecatchL(V, V);
V g_heff_2esyntax_2esurface_2ecatchL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ecatchL_clo;
V g_heff_2esyntax_2esurface_2echeckFixOf(V, V, V);
V g_heff_2esyntax_2esurface_2echeckFixOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2echeckFixOf_clo;
V g_heff_2esyntax_2esurface_2ecommentLinesFrom(V, V, V);
V g_heff_2esyntax_2esurface_2ecommentLinesFrom_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ecommentLinesFrom_clo;
V g_heff_2esyntax_2esurface_2econAtom(V, V, V);
V g_heff_2esyntax_2esurface_2econAtom_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2econAtom_clo;
V g_heff_2esyntax_2esurface_2econL(V, V, V);
V g_heff_2esyntax_2esurface_2econL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2econL_clo;
V g_heff_2esyntax_2esurface_2econcatMapS_24s1201403852x2138817053(V);
V g_heff_2esyntax_2esurface_2econcatMapS_24s1201403852x2138817053_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2econcatMapS_24s1201403852x2138817053_clo;
V g_heff_2esyntax_2esurface_2econcatMapS_24s1449391958x677358818(V);
V g_heff_2esyntax_2esurface_2econcatMapS_24s1449391958x677358818_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2econcatMapS_24s1449391958x677358818_clo;
V g_heff_2esyntax_2esurface_2ecycleDiag(V, V);
V g_heff_2esyntax_2esurface_2ecycleDiag_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ecycleDiag_clo;
HeffT2 g_heff_2esyntax_2esurface_2edataL_24s2041319846x1615558476_24cpr(V, V, V, V, V, V, V);
HeffT2 g_heff_2esyntax_2esurface_2edeclNameOf_24cpr(V);
V g_heff_2esyntax_2esurface_2edefNext(V, V, V);
V g_heff_2esyntax_2esurface_2edefNext_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2edefNext_clo;
V g_heff_2esyntax_2esurface_2edefinesOf(V, V);
V g_heff_2esyntax_2esurface_2edefinesOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2edefinesOf_clo;
V g_heff_2esyntax_2esurface_2edropN(V, V);
V g_heff_2esyntax_2esurface_2edropN_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2edropN_clo;
V g_heff_2esyntax_2esurface_2eexprL(V, V, V);
V g_heff_2esyntax_2esurface_2eexprL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eexprL_clo;
HeffT2 g_heff_2esyntax_2esurface_2efieldsOf_24cpr(V, V);
V g_heff_2esyntax_2esurface_2efirstDot(V, V);
V g_heff_2esyntax_2esurface_2efirstDot_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2efirstDot_clo;
V g_heff_2esyntax_2esurface_2efoldr(V, V, V);
V g_heff_2esyntax_2esurface_2efoldr_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2efoldr_clo;
V g_heff_2esyntax_2esurface_2efoldr_24s503335349x1048908132(V, V);
V g_heff_2esyntax_2esurface_2efoldr_24s503335349x1048908132_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2efoldr_24s503335349x1048908132_clo;
HeffT2 g_heff_2esyntax_2esurface_2eheadAt_24cpr(V, V);
V g_heff_2esyntax_2esurface_2eifL(V, V, V, V, V, V, V);
V g_heff_2esyntax_2esurface_2eifL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eifL_clo;
V g_heff_2esyntax_2esurface_2eifL_24s1615235115x417367760(V, V, V, V, V, V, V);
V g_heff_2esyntax_2esurface_2eifL_24s1615235115x417367760_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eifL_24s1615235115x417367760_clo;
V g_heff_2esyntax_2esurface_2eifLetL_24s130707926x1920299130(V, V, V, V, V, V, V, V);
V g_heff_2esyntax_2esurface_2eifLetL_24s130707926x1920299130_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eifLetL_24s130707926x1920299130_clo;
V g_heff_2esyntax_2esurface_2ekwAtom(V, V, V);
V g_heff_2esyntax_2esurface_2ekwAtom_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ekwAtom_clo;
V g_heff_2esyntax_2esurface_2ekwAtom_24tok1(V, V, V, V);
V g_heff_2esyntax_2esurface_2ekwAtom_24tok1_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ekwAtom_24tok1_clo;
V g_heff_2esyntax_2esurface_2elamBinderL(V, V);
V g_heff_2esyntax_2esurface_2elamBinderL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2elamBinderL_clo;
HeffT2 g_heff_2esyntax_2esurface_2eletBodyL_24cpr(V, V, V, V, V, V);
V g_heff_2esyntax_2esurface_2eletHeadL(V, V, V, V);
V g_heff_2esyntax_2esurface_2eletHeadL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eletHeadL_clo;
V g_heff_2esyntax_2esurface_2eletL(V, V, V);
V g_heff_2esyntax_2esurface_2eletL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eletL_clo;
V g_heff_2esyntax_2esurface_2elw_get(void);
HeffT2 g_heff_2esyntax_2esurface_2enameAnn_24cpr(V);
V g_heff_2esyntax_2esurface_2enameBinder(V);
V g_heff_2esyntax_2esurface_2enameBinder_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2enameBinder_clo;
V g_heff_2esyntax_2esurface_2enameSet(V);
V g_heff_2esyntax_2esurface_2enameSet_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2enameSet_clo;
V g_heff_2esyntax_2esurface_2eopL(V, V, V, V, V);
V g_heff_2esyntax_2esurface_2eopL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eopL_clo;
V g_heff_2esyntax_2esurface_2eparamOf_24tok1(V, V, V);
V g_heff_2esyntax_2esurface_2eparamOf_24tok1_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eparamOf_24tok1_clo;
V g_heff_2esyntax_2esurface_2eparenL(V, V, V, V, V);
V g_heff_2esyntax_2esurface_2eparenL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eparenL_clo;
V g_heff_2esyntax_2esurface_2epathOf(V, V);
V g_heff_2esyntax_2esurface_2epathOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2epathOf_clo;
V g_heff_2esyntax_2esurface_2eprescanGo(V, V, V, V);
V g_heff_2esyntax_2esurface_2eprescanGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eprescanGo_clo;
HeffT2 g_heff_2esyntax_2esurface_2epushAll_24cpr(V, V, V, V, V, V);
V g_heff_2esyntax_2esurface_2ereduceAll(V, V);
V g_heff_2esyntax_2esurface_2ereduceAll_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ereduceAll_clo;
V g_heff_2esyntax_2esurface_2erightsOf(V);
V g_heff_2esyntax_2esurface_2erightsOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2erightsOf_clo;
V g_heff_2esyntax_2esurface_2erightsOf_24dps(V, V);
V g_heff_2esyntax_2esurface_2erightsOf_24dps_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2erightsOf_24dps_clo;
V g_heff_2esyntax_2esurface_2esegmentL(V, V);
V g_heff_2esyntax_2esurface_2esegmentL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2esegmentL_clo;
V g_heff_2esyntax_2esurface_2esetScope(V, V);
V g_heff_2esyntax_2esurface_2esetScope_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2esetScope_clo;
V g_heff_2esyntax_2esurface_2eshortcut(V, V, V, V);
V g_heff_2esyntax_2esurface_2eshortcut_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eshortcut_clo;
V g_heff_2esyntax_2esurface_2esigNamesFrom(V, V, V);
V g_heff_2esyntax_2esurface_2esigNamesFrom_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2esigNamesFrom_clo;
V g_heff_2esyntax_2esurface_2esizeSaid(V, V, V, V, V);
V g_heff_2esyntax_2esurface_2esizeSaid_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2esizeSaid_clo;
V g_heff_2esyntax_2esurface_2especWord(V, V, V);
V g_heff_2esyntax_2esurface_2especWord_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2especWord_clo;
V g_heff_2esyntax_2esurface_2estmtL(V, V);
V g_heff_2esyntax_2esurface_2estmtL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2estmtL_clo;
V g_heff_2esyntax_2esurface_2etickFields(V, V, V);
V g_heff_2esyntax_2esurface_2etickFields_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2etickFields_clo;
V g_heff_2esyntax_2esurface_2etickPart(V, V, V, V, V);
V g_heff_2esyntax_2esurface_2etickPart_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2etickPart_clo;
V g_heff_2esyntax_2esurface_2etwoToS(V);
V g_heff_2esyntax_2esurface_2etwoToS_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2etwoToS_clo;
HeffT2 g_heff_2esyntax_2esurface_2etypeChecks_24cpr(V, V, V, V, V, V, V);
V g_heff_2esyntax_2esurface_2evarAtom(V, V, V);
V g_heff_2esyntax_2esurface_2evarAtom_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2evarAtom_clo;
V g_heff_2esyntax_2esurface_2evarAtom_24tok1(V, V, V, V);
V g_heff_2esyntax_2esurface_2evarAtom_24tok1_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2evarAtom_24tok1_clo;
V g_heff_2esyntax_2esurface_2evariantL(V, V);
V g_heff_2esyntax_2esurface_2evariantL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2evariantL_clo;
V g_heff_2esyntax_2esurface_2evariantOf(V);
V g_heff_2esyntax_2esurface_2evariantOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2evariantOf_clo;
V g_heff_2esyntax_2esurface_2ewithScope(V, V, V);
V g_heff_2esyntax_2esurface_2ewithScope_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ewithScope_clo;
HeffT2 g_heff_2esyntax_2esurface_2ewithScope_24cpr(V, V, V);
V g_heff_2esyntax_2esurface_2ewithScope_24tok2(V, V, V, V);
V g_heff_2esyntax_2esurface_2ewithScope_24tok2_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ewithScope_24tok2_clo;
V g_list_2eany_24s1006624359x760861690(V, V);
V g_list_2eany_24s1006624359x760861690_entry(V self, V *a);
extern Clo g_list_2eany_24s1006624359x760861690_clo;
V g_list_2eany_24s1137631697x622554211(V, V);
V g_list_2eany_24s1137631697x622554211_entry(V self, V *a);
extern Clo g_list_2eany_24s1137631697x622554211_clo;
V g_list_2eany_24s565534491x447967237(V, V);
V g_list_2eany_24s565534491x447967237_entry(V self, V *a);
extern Clo g_list_2eany_24s565534491x447967237_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1422286737x1936996242(V, V);
V g_list_2efoldl_24s1422286737x1936996242_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1422286737x1936996242_clo;
V g_list_2efoldl_24s1617583276x303680691(V, V);
V g_list_2efoldl_24s1617583276x303680691_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1617583276x303680691_clo;
V g_list_2emap_24f2053285389x511622380(V, V, V, V, V);
V g_list_2emap_24f2053285389x511622380_entry(V self, V *a);
extern Clo g_list_2emap_24f2053285389x511622380_clo;
V g_list_2emap_24s1059370217x1267747283(V);
V g_list_2emap_24s1059370217x1267747283_entry(V self, V *a);
extern Clo g_list_2emap_24s1059370217x1267747283_clo;
V g_list_2emap_24s513201124x806973253(V);
V g_list_2emap_24s513201124x806973253_entry(V self, V *a);
extern Clo g_list_2emap_24s513201124x806973253_clo;
V g_prelude_2eskipSpaces(V, V, V);
V g_prelude_2eskipSpaces_entry(V self, V *a);
extern Clo g_prelude_2eskipSpaces_clo;
HeffT2 g_prelude_2etraverse_24s1726903169x1952011622_24cpr(V, V);
V g_prelude_2etraverse_24s499544530x2060473942(V, V);
V g_prelude_2etraverse_24s499544530x2060473942_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s499544530x2060473942_clo;
V g_prelude_2etraverse_24s518454301x170091462(V);
V g_prelude_2etraverse_24s518454301x170091462_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s518454301x170091462_clo;
V g_std_2eordmap_2eempty_get(void);
V g_std_2eordmap_2einsert_24s615484302x989744458(V, V, V);
V g_std_2eordmap_2einsert_24s615484302x989744458_entry(V self, V *a);
extern Clo g_std_2eordmap_2einsert_24s615484302x989744458_clo;
HeffT2 g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(V, V);
Clo g_heff_2esyntax_2esurface_2ebind_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2ebind_entry, 3, 0};

V g_heff_2esyntax_2esurface_2ebind(V v_m_240, V v_f_241, V v_st_242) {
top: ;
  V v_x1_243 = heff_tr(heff_call(v_m_240, 1, (V[]){v_st_242}));
  switch (heff_tag_of(v_x1_243)) {
  case TAG_MkPair: {
    V v_x11_244 = heff_field(v_x1_243, 0);
    V v_st_245 = heff_field(v_x1_243, 1);
    V v_ru_24x1_243_24MkPair = heff_take_reuse_n(v_x1_243, 3ULL, 2);
    switch (heff_tag_of(v_x11_244)) {
    case TAG_Left: {
      V v_e_246 = heff_field(v_x11_244, 0);
      V v_ru_24x11_244_24Left = heff_take_reuse_n(v_x11_244, 1ULL, 1);
      heff_drop(v_f_241);
      return heff_tag_re_n(v_ru_24x1_243_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x11_244_24Left, TAG_Left, 1, 1ULL, (V[]){v_e_246}), v_st_245});
    }
    case TAG_Right: {
      V v_x_247 = heff_field(v_x11_244, 0);
      heff_take_n(v_x11_244, 1ULL, 1);
      heff_drop_cell(v_ru_24x1_243_24MkPair, 2);
      return heff_tail(v_f_241, 2, (V[]){v_x_247, v_st_245});
    }
    default: return heff_nomatch(v_x11_244);
    }
  }
  default: return heff_nomatch(v_x1_243);
  }
}
V g_heff_2esyntax_2esurface_2ebind_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2ebind(a[0], a[1], a[2]);
}
Clo g_heff_2esyntax_2esurface_2etickPart_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2etickPart_entry, 5, 0};

V g_heff_2esyntax_2esurface_2etickPart(V v_t_240, V v_kind_241, V v_from_242, V v_a_243, V v_b_244) {
top: ;
  V v_t_245 = heff_strSlice(heff_dup(heff_rfield(v_t_240, 1)), heff_dup(v_a_243), heff_dup(v_b_244));
  V v_t_246 = heff_strSlice(heff_take_field(v_t_240, 1), heff_dup(v_from_242), heff_dup(v_b_244));
  V v_t_247 = heff_intAdd(heff_dup(heff_rfield(v_t_240, 3)), MK_INT(1LL));
  V v_t_248 = heff_intAdd(heff_take_field(v_t_240, 3), MK_INT(1LL));
  V v_t_249 = heff_intAdd(heff_take_field(v_t_240, 5), MK_INT(1LL));
  return ({ V rv_0 = v_kind_241; V rv_1 = v_t_245; V rv_2 = v_t_246; V rv_3 = heff_intAdd_lent(v_t_247, v_from_242, 1); V rv_4 = heff_intAdd(v_t_248, v_b_244); V rv_5 = heff_intAdd(v_t_249, v_from_242); V rv_6 = NTAG(TAG_False); V rv_8 = NTAG(TAG_False); V rr_ = heff_rec_reuse_nf(v_t_240, 128ULL, 9, shape_kind__text__raw__start__end__col__first__ix__blank, 49152u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; heff_rfield(rr_, 5) = rv_5; heff_rfield(rr_, 6) = rv_6; heff_rfield(rr_, 8) = rv_8; rr_; });
}
V g_heff_2esyntax_2esurface_2etickPart_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2esyntax_2esurface_2etickPart(a[0], a[1], a[2], a3, a[4]); heff_drop(a3); return r;
}
Clo g_heff_2esyntax_2esurface_2enameSet_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2enameSet_entry, 1, 0};

V g_heff_2esyntax_2esurface_2enameSet(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_dup(g_std_2eordmap_2eempty_get());
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    V v_t_243 = (g_heff_2esyntax_2esurface_2enameSet(v_rest_242));
    return (g_std_2eordmap_2einsert_24s615484302x989744458(v_t_243, v_x_241, NTAG(TAG_MkUnit)));
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2esurface_2enameSet_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2esurface_2enameSet(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2esyntax_2esurface_2edefinesOf_str0, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2edefinesOf_str1, 18, "` is defined twice");
HEFF_LIT(g_heff_2esyntax_2esurface_2edefinesOf_str2, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2edefinesOf_str3, 76, "` is defined twice: its equations are apart, another definition between them");
HEFF_LIT(g_heff_2esyntax_2esurface_2edefinesOf_str4, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2edefinesOf_str5, 76, "` is defined twice: its equations are apart, another definition between them");
HEFF_LIT(g_heff_2esyntax_2esurface_2edefinesOf_str6, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2edefinesOf_str7, 18, "` is defined twice");
HEFF_LIT(g_heff_2esyntax_2esurface_2edefinesOf_str8, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2edefinesOf_str9, 18, "` is defined twice");
HEFF_LIT(g_heff_2esyntax_2esurface_2edefinesOf_str10, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2edefinesOf_str11, 18, "` is defined twice");
Clo g_heff_2esyntax_2esurface_2edefinesOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2edefinesOf_entry, 2, 0};

V g_heff_2esyntax_2esurface_2edefinesOf(V v_open_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Sig: {
    V v_f_243 = heff_field(v_x2_241, 1);
    V v_fsp_244 = heff_field(v_x2_241, 2);
    V v_ru_24x2_241_24Sig = heff_take_reuse_n(v_x2_241, 6ULL, 5);
    heff_drop(v_open_240);
    V v_t_247 = heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2esurface_2edefinesOf_str0), heff_dup(v_f_243)), ((V)&g_heff_2esyntax_2esurface_2edefinesOf_str1));
    return heff_tag_at_n(v_ru_24x2_241_24Sig, TAG_Names, 5, (V[]){heff_dup(v_f_243), v_fsp_244, heff_tag_n(TAG_Just, 1, (V[]){v_f_243}), v_t_247, NTAG(TAG_False)});
  }
  case TAG_Eqn: {
    V v_g_248 = heff_field(v_x2_241, 0);
    V v_e_249 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 3);
    switch (heff_tag_of(v_open_240)) {
    case TAG_Nothing: {
      V v_t_2417;
      switch (heff_tag_of(v_e_249)) {
      case TAG_At: {
        V v_x11_2411 = heff_field(v_e_249, 0);
        heff_take_n(v_e_249, 1ULL, 2);
        switch (heff_tag_of(v_x11_2411)) {
        case TAG_MkEquation: {
          V v_fsp_2414 = heff_field(v_x11_2411, 1);
          heff_take_n(v_x11_2411, 2ULL, 4);
          v_t_2417 = v_fsp_2414;
          break;
        }
        default: heff_nomatch(v_x11_2411);
        }
        break;
      }
      default: heff_nomatch(v_e_249);
      }
      V v_t_2418 = heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2esurface_2edefinesOf_str2), heff_dup(v_g_248)), ((V)&g_heff_2esyntax_2esurface_2edefinesOf_str3));
      return heff_tag_n(TAG_Names, 5, (V[]){heff_dup(v_g_248), v_t_2417, heff_tag_n(TAG_Just, 1, (V[]){v_g_248}), v_t_2418, NTAG(TAG_False)});
    }
    case TAG_Just: {
      V v_f_2419 = heff_field(v_open_240, 0);
      V v_ru_24open_240_24Just = heff_take_reuse_n(v_open_240, 1ULL, 1);
      if (heff_strEq_c_lent(v_f_2419, v_g_248, 1)) {
        heff_drop(v_g_248);
        heff_drop(v_e_249);
        heff_drop_cell(v_ru_24open_240_24Just, 1);
        return NTAG(TAG_Passes);
      } else {
        V v_t_2426;
        switch (heff_tag_of(v_e_249)) {
        case TAG_At: {
          V v_x11_2420 = heff_field(v_e_249, 0);
          heff_take_n(v_e_249, 1ULL, 2);
          switch (heff_tag_of(v_x11_2420)) {
          case TAG_MkEquation: {
            V v_fsp_2423 = heff_field(v_x11_2420, 1);
            heff_take_n(v_x11_2420, 2ULL, 4);
            v_t_2426 = v_fsp_2423;
            break;
          }
          default: heff_nomatch(v_x11_2420);
          }
          break;
        }
        default: heff_nomatch(v_e_249);
        }
        V v_t_2427 = heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2esurface_2edefinesOf_str4), heff_dup(v_g_248)), ((V)&g_heff_2esyntax_2esurface_2edefinesOf_str5));
        return heff_tag_n(TAG_Names, 5, (V[]){heff_dup(v_g_248), v_t_2426, heff_tag_at_n(v_ru_24open_240_24Just, TAG_Just, 1, (V[]){v_g_248}), v_t_2427, NTAG(TAG_False)});
      }
    }
    default: return heff_nomatch(v_open_240);
    }
  }
  case TAG_Whole: {
    V v_d_2428 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    heff_drop(v_open_240);
    V v_x1_2429 = v_d_2428;
    switch (heff_tag_of(v_x1_2429)) {
    case TAG_At: {
      V v_x11_2430 = heff_field(v_x1_2429, 0);
      heff_take_n(v_x1_2429, 1ULL, 2);
      switch (heff_tag_of(v_x11_2430)) {
      case TAG_DeclEquations: {
        heff_take_n(v_x11_2430, 0ULL, 5);
        return NTAG(TAG_Passes);
      }
      case TAG_DeclDefine: {
        V v_x_2437 = heff_field(v_x11_2430, 0);
        V v_xsp_2438 = heff_field(v_x11_2430, 1);
        V v_ru_24x11_2430_24DeclDefine = heff_take_reuse_n(v_x11_2430, 3ULL, 5);
        V v_t_2442 = heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2esurface_2edefinesOf_str6), heff_dup(v_x_2437)), ((V)&g_heff_2esyntax_2esurface_2edefinesOf_str7));
        return heff_tag_at_n(v_ru_24x11_2430_24DeclDefine, TAG_Names, 5, (V[]){v_x_2437, v_xsp_2438, NTAG(TAG_Nothing), v_t_2442, NTAG(TAG_False)});
      }
      case TAG_DeclTheory: {
        V v_x_2443 = heff_field(v_x11_2430, 0);
        V v_xsp_2444 = heff_field(v_x11_2430, 1);
        heff_take_n(v_x11_2430, 3ULL, 4);
        V v_t_2447 = heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2esurface_2edefinesOf_str8), heff_dup(v_x_2443)), ((V)&g_heff_2esyntax_2esurface_2edefinesOf_str9));
        return heff_tag_n(TAG_Names, 5, (V[]){v_x_2443, v_xsp_2444, NTAG(TAG_Nothing), v_t_2447, NTAG(TAG_False)});
      }
      case TAG_DeclPrimitive: {
        V v_x_2448 = heff_field(v_x11_2430, 0);
        V v_xsp_2449 = heff_field(v_x11_2430, 1);
        heff_take_n(v_x11_2430, 3ULL, 3);
        V v_t_2451 = heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2esurface_2edefinesOf_str10), heff_dup(v_x_2448)), ((V)&g_heff_2esyntax_2esurface_2edefinesOf_str11));
        return heff_tag_n(TAG_Names, 5, (V[]){v_x_2448, v_xsp_2449, NTAG(TAG_Nothing), v_t_2451, NTAG(TAG_True)});
      }
      case TAG_DeclTest: {
        heff_take_n(v_x11_2430, 0ULL, 2);
        return NTAG(TAG_Passes);
      }
      case TAG_DeclWatch: {
        heff_take_n(v_x11_2430, 0ULL, 1);
        return NTAG(TAG_Passes);
      }
      default: return heff_nomatch(v_x11_2430);
      }
    }
    default: return heff_nomatch(v_x1_2429);
    }
  }
  case TAG_Doc: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_open_240);
    return NTAG(TAG_Passes);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2esurface_2edefinesOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2edefinesOf(a[0], a[1]);
}
HEFF_LIT(g_heff_2esyntax_2esurface_2ecommentLinesFrom_str0, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecommentLinesFrom_str1, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecommentLinesFrom_str2, 2, "--");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecommentLinesFrom_str3, 1, "\012");
Clo g_heff_2esyntax_2esurface_2ecommentLinesFrom_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2ecommentLinesFrom_entry, 3, 0};

V g_heff_2esyntax_2esurface_2ecommentLinesFrom(V v_src_240, V v_i_241, V v_to_242) {
top: ;
  V v_j_243 = heff_strFind_lent(((V)&g_heff_2esyntax_2esurface_2ecommentLinesFrom_str0), v_src_240, v_i_241, 1);
  V v_t_244;
  if (heff_intLt_c_lent(v_j_243, MK_INT(0LL), 2)) {
    heff_drop(v_j_243);
    v_t_244 = heff_strLength_lent(v_src_240, 0);
  } else {
    v_t_244 = v_j_243;
  }
  if (heff_intLe_c_lent(v_to_242, v_t_244, 2)) {
    heff_drop(v_i_241);
    return NTAG(TAG_True);
  } else {
    V v_d_245 = heff_strLength_lent(v_src_240, 0);
    V v_j_246 = heff_strFind_lent(((V)&g_heff_2esyntax_2esurface_2ecommentLinesFrom_str1), v_src_240, v_i_241, 1);
    V v_t_247;
    if (heff_intLt_c_lent(v_j_246, MK_INT(0LL), 2)) {
      heff_drop(v_j_246);
      v_t_247 = v_d_245;
    } else {
      heff_drop(v_d_245);
      v_t_247 = v_j_246;
    }
    V v_s_248 = heff_strSlice_lent(v_src_240, v_i_241, v_t_247, 4);
    V v_t_249 = (g_prelude_2eskipSpaces(v_s_248, MK_INT(0LL), MK_INT(1LL)));
    int64_t v_t_2410 = (heff_unbox_word(heff_strLength_lent(v_s_248, 0)) - ((int64_t)1ULL));
    V v_t_2411 = (g_prelude_2eskipSpaces(v_s_248, heff_box_word(v_t_2410), MK_INT(-1LL)));
    V v_s_2412 = heff_strSlice(v_s_248, v_t_249, heff_intAdd(v_t_2411, MK_INT(1LL)));
    if (heff_strEq_c(heff_strSlice(v_s_2412, MK_INT(0LL), MK_INT(2LL)), ((V)&g_heff_2esyntax_2esurface_2ecommentLinesFrom_str2))) {
      V v_d_2413 = heff_strLength_lent(v_src_240, 0);
      V v_j_2414 = heff_strFind_lent(((V)&g_heff_2esyntax_2esurface_2ecommentLinesFrom_str3), v_src_240, v_i_241, 5);
      V v_t_2415;
      if (heff_intLt_c_lent(v_j_2414, MK_INT(0LL), 2)) {
        heff_drop(v_j_2414);
        v_t_2415 = v_d_2413;
      } else {
        heff_drop(v_d_2413);
        v_t_2415 = v_j_2414;
      }
      V t_0 = v_src_240;
      V t_1 = heff_intAdd(v_t_2415, MK_INT(1LL));
      V t_2 = v_to_242;
      v_src_240 = t_0;
      v_i_241 = t_1;
      v_to_242 = t_2;
      goto top;
    } else {
      heff_drop(v_i_241);
      return NTAG(TAG_False);
    }
  }
}
V g_heff_2esyntax_2esurface_2ecommentLinesFrom_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a2 = a[2]; V r = g_heff_2esyntax_2esurface_2ecommentLinesFrom(a0, a[1], a2); heff_drop(a0); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2esyntax_2esurface_2edefNext_str0, 1, "\012");
Clo g_heff_2esyntax_2esurface_2edefNext_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2edefNext_entry, 3, 0};

V g_heff_2esyntax_2esurface_2edefNext(V v_src_240, V v_p_241, V v_it_242) {
top: ;
  V v_t_243 = heff_dup(heff_rfield(v_p_241, 1));
  V v_t_2429;
  switch (heff_tag_of(v_t_243)) {
  case TAG_Nil: {
    v_t_2429 = NTAG(TAG_False);
    break;
  }
  case TAG_Cons: {
    V v_d_244 = heff_field(v_t_243, 0);
    heff_take_n(v_t_243, 1ULL, 2);
    V v_d_246 = heff_strLength_lent(v_src_240, 0);
    V v_t_249;
    switch (heff_tag_of(v_d_244)) {
    case TAG_At: {
      V v_s_248 = heff_field(v_d_244, 1);
      heff_take_n(v_d_244, 2ULL, 2);
      v_t_249 = v_s_248;
      break;
    }
    default: heff_nomatch(v_d_244);
    }
    V v_j_2410 = heff_strFind(((V)&g_heff_2esyntax_2esurface_2edefNext_str0), heff_dup(v_src_240), heff_get_n(v_t_249, 1, 2));
    V v_t_2411;
    if (heff_intLt_c_lent(v_j_2410, MK_INT(0LL), 2)) {
      heff_drop(v_j_2410);
      v_t_2411 = v_d_246;
    } else {
      heff_drop(v_d_246);
      v_t_2411 = v_j_2410;
    }
    V v_t_2428;
    switch (heff_tag_of(v_it_242)) {
    case TAG_Sig: {
      V v_sp_2416 = heff_dup(heff_field(v_it_242, 4));
      v_t_2428 = heff_get_n(v_sp_2416, 0, 2);
      break;
    }
    case TAG_Eqn: {
      V v_sp_2419 = heff_dup(heff_field(v_it_242, 2));
      v_t_2428 = heff_get_n(v_sp_2419, 0, 2);
      break;
    }
    case TAG_Whole: {
      V v_d_2420 = heff_dup(heff_field(v_it_242, 0));
      V v_t_2423;
      switch (heff_tag_of(v_d_2420)) {
      case TAG_At: {
        V v_s_2422 = heff_field(v_d_2420, 1);
        heff_take_n(v_d_2420, 2ULL, 2);
        v_t_2423 = v_s_2422;
        break;
      }
      default: heff_nomatch(v_d_2420);
      }
      v_t_2428 = heff_get_n(v_t_2423, 0, 2);
      break;
    }
    case TAG_Doc: {
      V v_d_2424 = heff_dup(heff_field(v_it_242, 0));
      V v_t_2427;
      switch (heff_tag_of(v_d_2424)) {
      case TAG_At: {
        V v_s_2426 = heff_field(v_d_2424, 1);
        heff_take_n(v_d_2424, 2ULL, 2);
        v_t_2427 = v_s_2426;
        break;
      }
      default: heff_nomatch(v_d_2424);
      }
      v_t_2428 = heff_get_n(v_t_2427, 0, 2);
      break;
    }
    default: heff_nomatch(v_it_242);
    }
    v_t_2429 = ({ V a_0 = v_src_240; V a_1 = heff_intAdd(v_t_2411, MK_INT(1LL)); V a_2 = v_t_2428; V r_ = (g_heff_2esyntax_2esurface_2ecommentLinesFrom(a_0, a_1, a_2)); heff_drop(v_t_2428); r_; });
    break;
  }
  default: heff_nomatch(v_t_243);
  }
  if ((heff_dup(v_t_2429) == NTAG(TAG_True))) {
    heff_drop(v_t_2429);
    V v_t_2430 = heff_tag_n(TAG_Cons, 2, (V[]){v_it_242, heff_take_field(v_p_241, 0)});
    V v_items_2431 = (g_heff_2esyntax_2esurface_2eappendS_24f1650453221x1165775554(v_t_2430, heff_take_field(v_p_241, 1)));
    return ({ V rv_0 = v_items_2431; V rv_1 = NTAG(TAG_Nil); V rr_ = heff_rec_reuse_nf(v_p_241, 4ULL, 3, shape_items__waiting__diags, 48u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; rr_; });
  } else {
    heff_drop(v_t_2429);
    V v_items_2432 = (g_heff_2esyntax_2esurface_2eappendS_24f1650453221x1165775554(heff_dup(heff_rfield(v_p_241, 0)), heff_dup(heff_rfield(v_p_241, 1))));
    V v_diags_2433 = (g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830(heff_dup(heff_rfield(v_p_241, 2)), heff_dup(heff_rfield(v_p_241, 1))));
    heff_drop(v_diags_2433);
    V v_items_2434 = heff_tag_n(TAG_Cons, 2, (V[]){v_it_242, v_items_2432});
    V v_items_2435 = (g_heff_2esyntax_2esurface_2eappendS_24f1650453221x1165775554(heff_take_field(v_p_241, 0), heff_dup(heff_rfield(v_p_241, 1))));
    heff_drop(v_items_2435);
    V v_diags_2436 = (g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830(heff_take_field(v_p_241, 2), heff_take_field(v_p_241, 1)));
    return ({ V rv_0 = v_items_2434; V rv_1 = NTAG(TAG_Nil); V rv_2 = v_diags_2436; V rr_ = heff_rec_reuse_nf(v_p_241, 0ULL, 3, shape_items__waiting__diags, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; rr_; });
  }
}
V g_heff_2esyntax_2esurface_2edefNext_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2esurface_2edefNext(a0, a[1], a[2]); heff_drop(a0); return r;
}
V g_heff_2esyntax_2esurface_2evariantL_lam0(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_lam1(V self, V *args);
Clo g_heff_2esyntax_2esurface_2evariantL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2evariantL_entry, 2, 0};

V g_heff_2esyntax_2esurface_2evariantL(V v_r_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_ECon: {
    V v_c_242 = heff_field(v_x2_241, 0);
    V v_args_243 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_m_244 = (g_heff_2esyntax_2esurface_2econL(v_r_240, v_c_242, v_args_243));
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_lam0, 1, 1, (V[]){v_m_244});
  }
  default: {
    V v_m_2412 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_lam1, 1, 1, (V[]){v_m_2412});
  }
  }
}
V g_heff_2esyntax_2esurface_2evariantL_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2evariantL(a[0], a[1]);
}
V g_heff_2esyntax_2esurface_2evariantL_lam0(V self, V *args) {
  V v_st_245 = args[0];
  V v_m_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_246 = heff_tr(heff_call(v_m_244, 1, (V[]){v_st_245}));
  switch (heff_tag_of(v_x1_246)) {
  case TAG_MkPair: {
    V v_x11_247 = heff_field(v_x1_246, 0);
    V v_st_248 = heff_field(v_x1_246, 1);
    V v_ru_24x1_246_24MkPair = heff_take_reuse_n(v_x1_246, 3ULL, 2);
    switch (heff_tag_of(v_x11_247)) {
    case TAG_Left: {
      V v_e_249 = heff_field(v_x11_247, 0);
      V v_ru_24x11_247_24Left = heff_take_reuse_n(v_x11_247, 1ULL, 1);
      return heff_tag_re_n(v_ru_24x1_246_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x11_247_24Left, TAG_Left, 1, 1ULL, (V[]){v_e_249}), v_st_248});
    }
    case TAG_Right: {
      V v_x_2410 = heff_field(v_x11_247, 0);
      V v_ru_24x11_247_24Right = heff_take_reuse_n(v_x11_247, 1ULL, 1);
      V v_x_2411 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_2410));
      return heff_tag_re_n(v_ru_24x1_246_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_at_n(v_ru_24x11_247_24Right, TAG_Right, 1, (V[]){v_x_2411}), v_st_248});
    }
    default: return heff_nomatch(v_x11_247);
    }
  }
  default: return heff_nomatch(v_x1_246);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_lam1(V self, V *args) {
  V v_st_2413 = args[0];
  V v_m_2412 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2414 = heff_tr(heff_call(v_m_2412, 1, (V[]){v_st_2413}));
  switch (heff_tag_of(v_x1_2414)) {
  case TAG_MkPair: {
    V v_x11_2415 = heff_field(v_x1_2414, 0);
    V v_st_2416 = heff_field(v_x1_2414, 1);
    V v_ru_24x1_2414_24MkPair = heff_take_reuse_n(v_x1_2414, 3ULL, 2);
    switch (heff_tag_of(v_x11_2415)) {
    case TAG_Left: {
      V v_e_2417 = heff_field(v_x11_2415, 0);
      V v_ru_24x11_2415_24Left = heff_take_reuse_n(v_x11_2415, 1ULL, 1);
      return heff_tag_re_n(v_ru_24x1_2414_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x11_2415_24Left, TAG_Left, 1, 1ULL, (V[]){v_e_2417}), v_st_2416});
    }
    case TAG_Right: {
      V v_x_2418 = heff_field(v_x11_2415, 0);
      V v_ru_24x11_2415_24Right = heff_take_reuse_n(v_x11_2415, 1ULL, 1);
      V v_x_2419 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_2418));
      return heff_tag_re_n(v_ru_24x1_2414_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_at_n(v_ru_24x11_2415_24Right, TAG_Right, 1, (V[]){v_x_2419}), v_st_2416});
    }
    default: return heff_nomatch(v_x11_2415);
    }
  }
  default: return heff_nomatch(v_x1_2414);
  }
}
HEFF_LIT(g_heff_2esyntax_2esurface_2elamBinderL_str0, 7, "pat#arg");
HEFF_LIT(g_heff_2esyntax_2esurface_2elamBinderL_str1, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2elamBinderL_str2, 1, "`");
V g_heff_2esyntax_2esurface_2elamBinderL_lam0(V self, V *args);
V g_heff_2esyntax_2esurface_2elamBinderL_lam1(V self, V *args);
V g_heff_2esyntax_2esurface_2elamBinderL_lam2(V self, V *args);
V g_heff_2esyntax_2esurface_2elamBinderL_lam3(V self, V *args);
V g_heff_2esyntax_2esurface_2elamBinderL_lam4(V self, V *args);
Clo g_heff_2esyntax_2esurface_2elamBinderL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2elamBinderL_entry, 2, 0};

V g_heff_2esyntax_2esurface_2elamBinderL(V v_r_240, V v_e_241) {
top: ;
  V v_e_242 = heff_take_field(v_r_240, 0);
  V v_pat_243 = heff_get_n(v_r_240, 1, 3);
  switch (heff_tag_of(v_e_241)) {
  case TAG_BVar: {
    V v_x_244 = heff_field(v_e_241, 0);
    heff_take_n(v_e_241, 1ULL, 1);
    heff_drop(v_e_242);
    heff_drop(v_pat_243);
    V v_text_245 = heff_take_field(v_x_244, 1);
    V v_start_246 = heff_take_field(v_x_244, 3);
    V v_end_247 = heff_get_n(v_x_244, 4, 9);
    return heff_clo_n(g_heff_2esyntax_2esurface_2elamBinderL_lam0, 1, 3, (V[]){v_text_245, v_start_246, v_end_247});
  }
  case TAG_BImp: {
    V v_o_2411 = heff_field(v_e_241, 0);
    V v_x_2412 = heff_field(v_e_241, 1);
    V v_c_2413 = heff_field(v_e_241, 2);
    heff_take_n(v_e_241, 7ULL, 3);
    heff_drop(v_e_242);
    heff_drop(v_pat_243);
    V v_text_2414 = heff_take_field(v_x_2412, 1);
    V v_start_2415 = heff_take_field(v_x_2412, 3);
    V v_end_2416 = heff_get_n(v_x_2412, 4, 9);
    return heff_clo_n(g_heff_2esyntax_2esurface_2elamBinderL_lam1, 1, 5, (V[]){v_text_2414, v_start_2415, v_end_2416, v_o_2411, v_c_2413});
  }
  case TAG_BAnn: {
    V v_x_2422 = heff_field(v_e_241, 1);
    V v_ty_2424 = heff_field(v_e_241, 3);
    heff_take_n(v_e_241, 10ULL, 5);
    heff_drop(v_pat_243);
    V v_text_2426 = heff_take_field(v_x_2422, 1);
    V v_start_2427 = heff_take_field(v_x_2422, 3);
    V v_end_2428 = heff_get_n(v_x_2422, 4, 9);
    V v_m_2429 = heff_tr(heff_call(v_e_242, 1, (V[]){v_ty_2424}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2elamBinderL_lam2, 1, 4, (V[]){v_m_2429, v_text_2426, v_start_2427, v_end_2428});
  }
  case TAG_BPat: {
    V v_p_2442 = heff_field(v_e_241, 0);
    heff_take_n(v_e_241, 1ULL, 1);
    heff_drop(v_e_242);
    V v_m_2443 = heff_tr(heff_call(v_pat_243, 1, (V[]){v_p_2442}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2elamBinderL_lam3, 1, 1, (V[]){v_m_2443});
  }
  default: {
    heff_drop(v_e_242);
    heff_drop(v_pat_243);
    V v_t_2457 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_start_2458 = heff_take_field(v_t_2457, 3);
    V v_end_2459 = heff_get_n(v_t_2457, 4, 9);
    V v_t_2460 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop(v_e_241); r_; });
    V v_t_2461 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2elamBinderL_str1), heff_get_n(v_t_2460, 1, 9));
    V v_msg_2462 = heff_strAppend(v_t_2461, ((V)&g_heff_2esyntax_2esurface_2elamBinderL_str2));
    return heff_clo_n(g_heff_2esyntax_2esurface_2elamBinderL_lam4, 1, 3, (V[]){v_msg_2462, v_start_2458, v_end_2459});
  }
  }
}
V g_heff_2esyntax_2esurface_2elamBinderL_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2elamBinderL(a[0], a[1]);
}
V g_heff_2esyntax_2esurface_2elamBinderL_lam0(V self, V *args) {
  V v_st_248 = args[0];
  V v_text_245 = heff_env(self)[0];
  V v_start_246 = heff_env(self)[1];
  V v_end_247 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_249 = heff_tag_n(TAG_LamName, 2, (V[]){v_text_245, heff_rec_n(2, shape_start__end, (V[]){heff_dup(v_start_246), heff_dup(v_end_247)})});
  V v_t_2410 = heff_rec_n(3, shape_binder__span__pat, (V[]){v_t_249, heff_rec_n(2, shape_start__end, (V[]){v_start_246, v_end_247}), NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2410}), v_st_248});
}
V g_heff_2esyntax_2esurface_2elamBinderL_lam1(V self, V *args) {
  V v_st_2417 = args[0];
  V v_text_2414 = heff_env(self)[0];
  V v_start_2415 = heff_env(self)[1];
  V v_end_2416 = heff_env(self)[2];
  V v_o_2411 = heff_env(self)[3];
  V v_c_2413 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2418 = heff_tag_n(TAG_LamImplicit, 2, (V[]){v_text_2414, heff_rec_n(2, shape_start__end, (V[]){v_start_2415, v_end_2416})});
  V v_t_2419 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_o_2411, 3, 9), heff_get_n(v_c_2413, 4, 9)});
  V v_t_2420 = heff_rec_n(3, shape_binder__span__pat, (V[]){v_t_2418, v_t_2419, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2420}), v_st_2417});
}
V g_heff_2esyntax_2esurface_2elamBinderL_lam2(V self, V *args) {
  V v_st_2430 = args[0];
  V v_m_2429 = heff_env(self)[0];
  V v_text_2426 = heff_env(self)[1];
  V v_start_2427 = heff_env(self)[2];
  V v_end_2428 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x1_2431 = heff_tr(heff_call(v_m_2429, 1, (V[]){v_st_2430}));
  switch (heff_tag_of(v_x1_2431)) {
  case TAG_MkPair: {
    V v_x11_2432 = heff_field(v_x1_2431, 0);
    V v_st_2433 = heff_field(v_x1_2431, 1);
    V v_ru_24x1_2431_24MkPair = heff_take_reuse_n(v_x1_2431, 3ULL, 2);
    switch (heff_tag_of(v_x11_2432)) {
    case TAG_Left: {
      V v_e_2434 = heff_field(v_x11_2432, 0);
      V v_ru_24x11_2432_24Left = heff_take_reuse_n(v_x11_2432, 1ULL, 1);
      heff_drop(v_text_2426);
      heff_drop(v_start_2427);
      heff_drop(v_end_2428);
      return heff_tag_re_n(v_ru_24x1_2431_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x11_2432_24Left, TAG_Left, 1, 1ULL, (V[]){v_e_2434}), v_st_2433});
    }
    case TAG_Right: {
      V v_x_2435 = heff_field(v_x11_2432, 0);
      V v_ru_24x11_2432_24Right = heff_take_reuse_n(v_x11_2432, 1ULL, 1);
      V v_t_2438;
      switch (heff_tag_of(v_x_2435)) {
      case TAG_At: {
        V v_s_2437 = heff_dup(heff_field(v_x_2435, 1));
        v_t_2438 = v_s_2437;
        break;
      }
      default: heff_nomatch(v_x_2435);
      }
      V v_t_2439 = heff_tag_n(TAG_LamAnn, 3, (V[]){v_text_2426, heff_rec_n(2, shape_start__end, (V[]){heff_dup(v_start_2427), v_end_2428}), v_x_2435});
      V v_t_2440 = ({ V rv_0 = v_start_2427; V rr_ = heff_rec_reuse_nf(v_t_2438, 2ULL, 2, shape_start__end, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
      V v_t_2441 = heff_rec_n(3, shape_binder__span__pat, (V[]){v_t_2439, v_t_2440, NTAG(TAG_Nothing)});
      return heff_tag_re_n(v_ru_24x1_2431_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_at_n(v_ru_24x11_2432_24Right, TAG_Right, 1, (V[]){v_t_2441}), v_st_2433});
    }
    default: return heff_nomatch(v_x11_2432);
    }
  }
  default: return heff_nomatch(v_x1_2431);
  }
}
V g_heff_2esyntax_2esurface_2elamBinderL_lam3(V self, V *args) {
  V v_st_2444 = args[0];
  V v_m_2443 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2445 = heff_tr(heff_call(v_m_2443, 1, (V[]){v_st_2444}));
  switch (heff_tag_of(v_x1_2445)) {
  case TAG_MkPair: {
    V v_x11_2446 = heff_field(v_x1_2445, 0);
    V v_st_2447 = heff_field(v_x1_2445, 1);
    V v_ru_24x1_2445_24MkPair = heff_take_reuse_n(v_x1_2445, 3ULL, 2);
    switch (heff_tag_of(v_x11_2446)) {
    case TAG_Left: {
      V v_e_2448 = heff_field(v_x11_2446, 0);
      V v_ru_24x11_2446_24Left = heff_take_reuse_n(v_x11_2446, 1ULL, 1);
      return heff_tag_re_n(v_ru_24x1_2445_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x11_2446_24Left, TAG_Left, 1, 1ULL, (V[]){v_e_2448}), v_st_2447});
    }
    case TAG_Right: {
      V v_x_2449 = heff_field(v_x11_2446, 0);
      V v_ru_24x11_2446_24Right = heff_take_reuse_n(v_x11_2446, 1ULL, 1);
      V v_t_2452;
      switch (heff_tag_of(v_x_2449)) {
      case TAG_At: {
        V v_s_2451 = heff_dup(heff_field(v_x_2449, 1));
        v_t_2452 = v_s_2451;
        break;
      }
      default: heff_nomatch(v_x_2449);
      }
      V v_t_2455;
      switch (heff_tag_of(v_x_2449)) {
      case TAG_At: {
        V v_s_2454 = heff_dup(heff_field(v_x_2449, 1));
        v_t_2455 = v_s_2454;
        break;
      }
      default: heff_nomatch(v_x_2449);
      }
      V v_t_2456 = heff_rec_n(3, shape_binder__span__pat, (V[]){heff_tag_n(TAG_LamName, 2, (V[]){((V)&g_heff_2esyntax_2esurface_2elamBinderL_str0), v_t_2452}), v_t_2455, heff_tag_n(TAG_Just, 1, (V[]){v_x_2449})});
      return heff_tag_re_n(v_ru_24x1_2445_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_at_n(v_ru_24x11_2446_24Right, TAG_Right, 1, (V[]){v_t_2456}), v_st_2447});
    }
    default: return heff_nomatch(v_x11_2446);
    }
  }
  default: return heff_nomatch(v_x1_2445);
  }
}
V g_heff_2esyntax_2esurface_2elamBinderL_lam4(V self, V *args) {
  V v_st_2463 = args[0];
  V v_msg_2462 = heff_env(self)[0];
  V v_start_2458 = heff_env(self)[1];
  V v_end_2459 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2464 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_2462, heff_rec_n(2, shape_start__end, (V[]){v_start_2458, v_end_2459}), NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2464}), v_st_2463});
}
V g_heff_2esyntax_2esurface_2eletBodyL_24cpr_lam0(V self, V *args);

HeffT2 g_heff_2esyntax_2esurface_2eletBodyL_24cpr(V v_r_240, V v_kw_241, V v_x3_242, V v_names_243, V v_body_244, V v_z_245) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_MkPair: {
    V v_p_246 = heff_field(v_x3_242, 0);
    V v_rhs_247 = heff_field(v_x3_242, 1);
    heff_take_n(v_x3_242, 3ULL, 2);
    V v_m_248 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_body_244)}));
    return (g_heff_2esyntax_2esurface_2ewithScope_24cpr(v_names_243, heff_clo_n(g_heff_2esyntax_2esurface_2eletBodyL_24cpr_lam0, 1, 5, (V[]){v_m_248, v_p_246, v_body_244, v_kw_241, v_rhs_247}), v_z_245));
  }
  default: return ((HeffT2){{heff_nomatch(v_x3_242)}});
  }
}
V g_heff_2esyntax_2esurface_2eletBodyL_24cpr_lam0(V self, V *args) {
  V v_st_249 = args[0];
  V v_m_248 = heff_env(self)[0];
  V v_p_246 = heff_env(self)[1];
  V v_body_244 = heff_env(self)[2];
  V v_kw_241 = heff_env(self)[3];
  V v_rhs_247 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_x1_2410 = heff_tr(heff_call(v_m_248, 1, (V[]){v_st_249}));
  switch (heff_tag_of(v_x1_2410)) {
  case TAG_MkPair: {
    V v_x11_2411 = heff_field(v_x1_2410, 0);
    V v_st_2412 = heff_field(v_x1_2410, 1);
    V v_ru_24x1_2410_24MkPair = heff_take_reuse_n(v_x1_2410, 3ULL, 2);
    switch (heff_tag_of(v_x11_2411)) {
    case TAG_Left: {
      V v_e_2413 = heff_field(v_x11_2411, 0);
      V v_ru_24x11_2411_24Left = heff_take_reuse_n(v_x11_2411, 1ULL, 1);
      heff_drop(v_p_246);
      heff_drop(v_body_244);
      heff_drop_rec(v_kw_241, 9);
      heff_drop(v_rhs_247);
      return heff_tag_re_n(v_ru_24x1_2410_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x11_2411_24Left, TAG_Left, 1, 1ULL, (V[]){v_e_2413}), v_st_2412});
    }
    case TAG_Right: {
      V v_x_2414 = heff_field(v_x11_2411, 0);
      V v_ru_24x11_2411_24Right = heff_take_reuse_n(v_x11_2411, 1ULL, 1);
      V v_t_2417;
      switch (heff_tag_of(v_p_246)) {
      case TAG_At: {
        V v_s_2416 = heff_dup(heff_field(v_p_246, 1));
        v_t_2417 = v_s_2416;
        break;
      }
      default: heff_nomatch(v_p_246);
      }
      V v_t_2420;
      switch (heff_tag_of(v_x_2414)) {
      case TAG_At: {
        V v_s_2419 = heff_dup(heff_field(v_x_2414, 1));
        v_t_2420 = v_s_2419;
        break;
      }
      default: heff_nomatch(v_x_2414);
      }
      V v_t_2421 = (g_heff_2esyntax_2ecst_2elastE(v_body_244));
      V v_e_2422 = heff_get_n(v_t_2421, 4, 9);
      V v_t_2423 = ({ V rv_1 = heff_take_field(v_t_2420, 1); V rr_ = heff_rec_reuse_nf(v_t_2417, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
      V v_t_2424 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_246, v_x_2414}), v_t_2423});
      V v_t_2425 = ({ V rv_0 = heff_get_n(v_kw_241, 3, 9); V rv_1 = v_e_2422; V rr_ = heff_rec_reuse_nf(v_t_2420, 0ULL, 2, shape_start__end, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; rr_; });
      V v_x_2426 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ELetIn, 2, (V[]){v_rhs_247, v_t_2424}), v_t_2425});
      return heff_tag_re_n(v_ru_24x1_2410_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_at_n(v_ru_24x11_2411_24Right, TAG_Right, 1, (V[]){v_x_2426}), v_st_2412});
    }
    default: return heff_nomatch(v_x11_2411);
    }
  }
  default: return heff_nomatch(v_x1_2410);
  }
}
HEFF_LIT(g_heff_2esyntax_2esurface_2esizeSaid_str0, 28, "a segment says its size once");
HEFF_LIT(g_heff_2esyntax_2esurface_2esizeSaid_str1, 28, "a segment says its size once");
Clo g_heff_2esyntax_2esurface_2esizeSaid_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2esizeSaid_entry, 5, 0};

V g_heff_2esyntax_2esurface_2esizeSaid(V v_sp_240, V v_n_241, V v_x3_242, V v_s_243, V v_p_244) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_SizeDefault: {
    heff_drop(v_sp_240);
    V v_t_245 = ({ V rv_1 = v_n_241; V rr_ = heff_rec_reuse_nf(v_s_243, 29ULL, 5, shape_ty__size__unit__little__signed, 1011u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_245}), v_p_244});
  }
  case TAG_SizeNumber: {
    V v_ru_24x3_242_24SizeNumber = heff_take_reuse_n(v_x3_242, 0ULL, 1);
    heff_drop(v_n_241);
    heff_drop_rec(v_s_243, 5);
    V v_t_247 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2esizeSaid_str0), v_sp_240, NTAG(TAG_Nothing)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x3_242_24SizeNumber, TAG_Left, 1, (V[]){v_t_247}), v_p_244});
  }
  case TAG_SizeName: {
    heff_take_n(v_x3_242, 0ULL, 3);
    heff_drop(v_n_241);
    heff_drop_rec(v_s_243, 5);
    V v_t_2411 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2esizeSaid_str1), v_sp_240, NTAG(TAG_Nothing)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2411}), v_p_244});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2esyntax_2esurface_2esizeSaid_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2esizeSaid(a[0], a[1], a[2], a[3], a[4]);
}
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str0, 7, "integer");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str1, 28, "a segment says its type once");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str2, 6, "binary");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str3, 5, "bytes");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str4, 28, "a segment says its type once");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str5, 4, "bits");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str6, 9, "bitstring");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str7, 28, "a segment says its type once");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str8, 5, "float");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str9, 28, "a segment says its type once");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str10, 4, "utf8");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str11, 28, "a segment says its type once");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str12, 5, "utf16");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str13, 28, "a segment says its type once");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str14, 5, "utf32");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str15, 28, "a segment says its type once");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str16, 3, "big");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str17, 34, "a segment says its endianness once");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str18, 6, "little");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str19, 34, "a segment says its endianness once");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str20, 6, "signed");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str21, 28, "a segment says its sign once");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str22, 8, "unsigned");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str23, 28, "a segment says its sign once");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str24, 227, "a segment's spec is its type (`integer`, `binary`, `bits`, `float`, `utf8`, `utf16`, `utf32`), size (`16`, `size(n)`), unit (`unit(8)`), endianness (`big`, `little`) and sign (`signed`, `unsigned`), between `-`s: `x::16-little`");
Clo g_heff_2esyntax_2esurface_2especWord_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2especWord_entry, 3, 0};

V g_heff_2esyntax_2esurface_2especWord(V v_t_240, V v_s_241, V v_p_242) {
top: ;
  V v_text_243 = heff_take_field(v_t_240, 1);
  V v_start_244 = heff_take_field(v_t_240, 3);
  V v_end_245 = heff_get_n(v_t_240, 4, 9);
  if (heff_strEq_c_lent(v_text_243, ((V)&g_heff_2esyntax_2esurface_2especWord_str0), 2)) {
    heff_drop(v_text_243);
    V v_t_246 = heff_take_field(v_s_241, 0);
    switch (heff_tag_of(v_t_246)) {
    case TAG_Nothing: {
      heff_drop(v_start_244);
      heff_drop(v_end_245);
      V v_t_247 = heff_tag_n(TAG_Just, 1, (V[]){NTAG(TAG_SegmentInteger)});
      V v_t_248 = ({ V rv_0 = v_t_247; V rr_ = heff_rec_reuse_nf(v_s_241, 30ULL, 5, shape_ty__size__unit__little__signed, 1020u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_248}), v_p_242});
    }
    case TAG_Just: {
      V v_ru_24t_246_24Just = heff_take_reuse_n(v_t_246, 0ULL, 1);
      heff_drop_rec(v_s_241, 5);
      V v_t_2410 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2especWord_str1), heff_rec_n(2, shape_start__end, (V[]){v_start_244, v_end_245}), NTAG(TAG_Nothing)});
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24t_246_24Just, TAG_Left, 1, (V[]){v_t_2410}), v_p_242});
    }
    default: return heff_nomatch(v_t_246);
    }
  } else {
    if ((heff_strEq_c_lent(v_text_243, ((V)&g_heff_2esyntax_2esurface_2especWord_str2), 2) || heff_strEq_c_lent(v_text_243, ((V)&g_heff_2esyntax_2esurface_2especWord_str3), 2))) {
      heff_drop(v_text_243);
      V v_t_2411 = heff_take_field(v_s_241, 0);
      switch (heff_tag_of(v_t_2411)) {
      case TAG_Nothing: {
        heff_drop(v_start_244);
        heff_drop(v_end_245);
        V v_t_2412 = heff_tag_n(TAG_Just, 1, (V[]){NTAG(TAG_SegmentBinary)});
        V v_t_2413 = ({ V rv_0 = v_t_2412; V rr_ = heff_rec_reuse_nf(v_s_241, 30ULL, 5, shape_ty__size__unit__little__signed, 1020u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
        return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2413}), v_p_242});
      }
      case TAG_Just: {
        V v_ru_24t_2411_24Just = heff_take_reuse_n(v_t_2411, 0ULL, 1);
        heff_drop_rec(v_s_241, 5);
        V v_t_2415 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2especWord_str4), heff_rec_n(2, shape_start__end, (V[]){v_start_244, v_end_245}), NTAG(TAG_Nothing)});
        return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24t_2411_24Just, TAG_Left, 1, (V[]){v_t_2415}), v_p_242});
      }
      default: return heff_nomatch(v_t_2411);
      }
    } else {
      if ((heff_strEq_c_lent(v_text_243, ((V)&g_heff_2esyntax_2esurface_2especWord_str5), 2) || heff_strEq_c_lent(v_text_243, ((V)&g_heff_2esyntax_2esurface_2especWord_str6), 2))) {
        heff_drop(v_text_243);
        V v_t_2416 = heff_take_field(v_s_241, 0);
        switch (heff_tag_of(v_t_2416)) {
        case TAG_Nothing: {
          heff_drop(v_start_244);
          heff_drop(v_end_245);
          V v_t_2417 = heff_tag_n(TAG_Just, 1, (V[]){NTAG(TAG_SegmentBits)});
          V v_t_2418 = ({ V rv_0 = v_t_2417; V rr_ = heff_rec_reuse_nf(v_s_241, 30ULL, 5, shape_ty__size__unit__little__signed, 1020u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
          return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2418}), v_p_242});
        }
        case TAG_Just: {
          V v_ru_24t_2416_24Just = heff_take_reuse_n(v_t_2416, 0ULL, 1);
          heff_drop_rec(v_s_241, 5);
          V v_t_2420 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2especWord_str7), heff_rec_n(2, shape_start__end, (V[]){v_start_244, v_end_245}), NTAG(TAG_Nothing)});
          return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24t_2416_24Just, TAG_Left, 1, (V[]){v_t_2420}), v_p_242});
        }
        default: return heff_nomatch(v_t_2416);
        }
      } else {
        if (heff_strEq_c_lent(v_text_243, ((V)&g_heff_2esyntax_2esurface_2especWord_str8), 2)) {
          heff_drop(v_text_243);
          V v_t_2421 = heff_take_field(v_s_241, 0);
          switch (heff_tag_of(v_t_2421)) {
          case TAG_Nothing: {
            heff_drop(v_start_244);
            heff_drop(v_end_245);
            V v_t_2422 = heff_tag_n(TAG_Just, 1, (V[]){NTAG(TAG_SegmentFloat)});
            V v_t_2423 = ({ V rv_0 = v_t_2422; V rr_ = heff_rec_reuse_nf(v_s_241, 30ULL, 5, shape_ty__size__unit__little__signed, 1020u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
            return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2423}), v_p_242});
          }
          case TAG_Just: {
            V v_ru_24t_2421_24Just = heff_take_reuse_n(v_t_2421, 0ULL, 1);
            heff_drop_rec(v_s_241, 5);
            V v_t_2425 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2especWord_str9), heff_rec_n(2, shape_start__end, (V[]){v_start_244, v_end_245}), NTAG(TAG_Nothing)});
            return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24t_2421_24Just, TAG_Left, 1, (V[]){v_t_2425}), v_p_242});
          }
          default: return heff_nomatch(v_t_2421);
          }
        } else {
          if (heff_strEq_c_lent(v_text_243, ((V)&g_heff_2esyntax_2esurface_2especWord_str10), 2)) {
            heff_drop(v_text_243);
            V v_t_2426 = heff_take_field(v_s_241, 0);
            switch (heff_tag_of(v_t_2426)) {
            case TAG_Nothing: {
              heff_drop(v_start_244);
              heff_drop(v_end_245);
              V v_t_2427 = heff_tag_n(TAG_Just, 1, (V[]){heff_tag_n(TAG_SegmentUtf, 1, (V[]){MK_INT(8LL)})});
              V v_t_2428 = ({ V rv_0 = v_t_2427; V rr_ = heff_rec_reuse_nf(v_s_241, 30ULL, 5, shape_ty__size__unit__little__signed, 1020u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
              return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2428}), v_p_242});
            }
            case TAG_Just: {
              V v_ru_24t_2426_24Just = heff_take_reuse_n(v_t_2426, 0ULL, 1);
              heff_drop_rec(v_s_241, 5);
              V v_t_2430 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2especWord_str11), heff_rec_n(2, shape_start__end, (V[]){v_start_244, v_end_245}), NTAG(TAG_Nothing)});
              return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24t_2426_24Just, TAG_Left, 1, (V[]){v_t_2430}), v_p_242});
            }
            default: return heff_nomatch(v_t_2426);
            }
          } else {
            if (heff_strEq_c_lent(v_text_243, ((V)&g_heff_2esyntax_2esurface_2especWord_str12), 2)) {
              heff_drop(v_text_243);
              V v_t_2431 = heff_take_field(v_s_241, 0);
              switch (heff_tag_of(v_t_2431)) {
              case TAG_Nothing: {
                heff_drop(v_start_244);
                heff_drop(v_end_245);
                V v_t_2432 = heff_tag_n(TAG_Just, 1, (V[]){heff_tag_n(TAG_SegmentUtf, 1, (V[]){MK_INT(16LL)})});
                V v_t_2433 = ({ V rv_0 = v_t_2432; V rr_ = heff_rec_reuse_nf(v_s_241, 30ULL, 5, shape_ty__size__unit__little__signed, 1020u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
                return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2433}), v_p_242});
              }
              case TAG_Just: {
                V v_ru_24t_2431_24Just = heff_take_reuse_n(v_t_2431, 0ULL, 1);
                heff_drop_rec(v_s_241, 5);
                V v_t_2435 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2especWord_str13), heff_rec_n(2, shape_start__end, (V[]){v_start_244, v_end_245}), NTAG(TAG_Nothing)});
                return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24t_2431_24Just, TAG_Left, 1, (V[]){v_t_2435}), v_p_242});
              }
              default: return heff_nomatch(v_t_2431);
              }
            } else {
              if (heff_strEq_c_lent(v_text_243, ((V)&g_heff_2esyntax_2esurface_2especWord_str14), 2)) {
                heff_drop(v_text_243);
                V v_t_2436 = heff_take_field(v_s_241, 0);
                switch (heff_tag_of(v_t_2436)) {
                case TAG_Nothing: {
                  heff_drop(v_start_244);
                  heff_drop(v_end_245);
                  V v_t_2437 = heff_tag_n(TAG_Just, 1, (V[]){heff_tag_n(TAG_SegmentUtf, 1, (V[]){MK_INT(32LL)})});
                  V v_t_2438 = ({ V rv_0 = v_t_2437; V rr_ = heff_rec_reuse_nf(v_s_241, 30ULL, 5, shape_ty__size__unit__little__signed, 1020u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
                  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2438}), v_p_242});
                }
                case TAG_Just: {
                  V v_ru_24t_2436_24Just = heff_take_reuse_n(v_t_2436, 0ULL, 1);
                  heff_drop_rec(v_s_241, 5);
                  V v_t_2440 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2especWord_str15), heff_rec_n(2, shape_start__end, (V[]){v_start_244, v_end_245}), NTAG(TAG_Nothing)});
                  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24t_2436_24Just, TAG_Left, 1, (V[]){v_t_2440}), v_p_242});
                }
                default: return heff_nomatch(v_t_2436);
                }
              } else {
                if (heff_strEq_c_lent(v_text_243, ((V)&g_heff_2esyntax_2esurface_2especWord_str16), 2)) {
                  heff_drop(v_text_243);
                  V v_t_2441 = heff_take_field(v_s_241, 3);
                  switch (heff_tag_of(v_t_2441)) {
                  case TAG_Nothing: {
                    heff_drop(v_start_244);
                    heff_drop(v_end_245);
                    V v_t_2442 = heff_tag_n(TAG_Just, 1, (V[]){NTAG(TAG_False)});
                    V v_t_2443 = ({ V rv_3 = v_t_2442; V rr_ = heff_rec_reuse_nf(v_s_241, 23ULL, 5, shape_ty__size__unit__little__signed, 831u, 0u); heff_rfield(rr_, 3) = rv_3; rr_; });
                    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2443}), v_p_242});
                  }
                  case TAG_Just: {
                    V v_ru_24t_2441_24Just = heff_take_reuse_n(v_t_2441, 0ULL, 1);
                    heff_drop_rec(v_s_241, 5);
                    V v_t_2445 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2especWord_str17), heff_rec_n(2, shape_start__end, (V[]){v_start_244, v_end_245}), NTAG(TAG_Nothing)});
                    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24t_2441_24Just, TAG_Left, 1, (V[]){v_t_2445}), v_p_242});
                  }
                  default: return heff_nomatch(v_t_2441);
                  }
                } else {
                  if (heff_strEq_c_lent(v_text_243, ((V)&g_heff_2esyntax_2esurface_2especWord_str18), 2)) {
                    heff_drop(v_text_243);
                    V v_t_2446 = heff_take_field(v_s_241, 3);
                    switch (heff_tag_of(v_t_2446)) {
                    case TAG_Nothing: {
                      heff_drop(v_start_244);
                      heff_drop(v_end_245);
                      V v_t_2447 = heff_tag_n(TAG_Just, 1, (V[]){NTAG(TAG_True)});
                      V v_t_2448 = ({ V rv_3 = v_t_2447; V rr_ = heff_rec_reuse_nf(v_s_241, 23ULL, 5, shape_ty__size__unit__little__signed, 831u, 0u); heff_rfield(rr_, 3) = rv_3; rr_; });
                      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2448}), v_p_242});
                    }
                    case TAG_Just: {
                      V v_ru_24t_2446_24Just = heff_take_reuse_n(v_t_2446, 0ULL, 1);
                      heff_drop_rec(v_s_241, 5);
                      V v_t_2450 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2especWord_str19), heff_rec_n(2, shape_start__end, (V[]){v_start_244, v_end_245}), NTAG(TAG_Nothing)});
                      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24t_2446_24Just, TAG_Left, 1, (V[]){v_t_2450}), v_p_242});
                    }
                    default: return heff_nomatch(v_t_2446);
                    }
                  } else {
                    if (heff_strEq_c_lent(v_text_243, ((V)&g_heff_2esyntax_2esurface_2especWord_str20), 2)) {
                      heff_drop(v_text_243);
                      V v_t_2451 = heff_take_field(v_s_241, 4);
                      switch (heff_tag_of(v_t_2451)) {
                      case TAG_Nothing: {
                        heff_drop(v_start_244);
                        heff_drop(v_end_245);
                        V v_t_2452 = heff_tag_n(TAG_Just, 1, (V[]){NTAG(TAG_True)});
                        V v_t_2453 = ({ V rv_4 = v_t_2452; V rr_ = heff_rec_reuse_nf(v_s_241, 15ULL, 5, shape_ty__size__unit__little__signed, 255u, 0u); heff_rfield(rr_, 4) = rv_4; rr_; });
                        return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2453}), v_p_242});
                      }
                      case TAG_Just: {
                        V v_ru_24t_2451_24Just = heff_take_reuse_n(v_t_2451, 0ULL, 1);
                        heff_drop_rec(v_s_241, 5);
                        V v_t_2455 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2especWord_str21), heff_rec_n(2, shape_start__end, (V[]){v_start_244, v_end_245}), NTAG(TAG_Nothing)});
                        return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24t_2451_24Just, TAG_Left, 1, (V[]){v_t_2455}), v_p_242});
                      }
                      default: return heff_nomatch(v_t_2451);
                      }
                    } else {
                      if (heff_strEq_c(v_text_243, ((V)&g_heff_2esyntax_2esurface_2especWord_str22))) {
                        V v_t_2456 = heff_take_field(v_s_241, 4);
                        switch (heff_tag_of(v_t_2456)) {
                        case TAG_Nothing: {
                          heff_drop(v_start_244);
                          heff_drop(v_end_245);
                          V v_t_2457 = heff_tag_n(TAG_Just, 1, (V[]){NTAG(TAG_False)});
                          V v_t_2458 = ({ V rv_4 = v_t_2457; V rr_ = heff_rec_reuse_nf(v_s_241, 15ULL, 5, shape_ty__size__unit__little__signed, 255u, 0u); heff_rfield(rr_, 4) = rv_4; rr_; });
                          return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2458}), v_p_242});
                        }
                        case TAG_Just: {
                          V v_ru_24t_2456_24Just = heff_take_reuse_n(v_t_2456, 0ULL, 1);
                          heff_drop_rec(v_s_241, 5);
                          V v_t_2460 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2especWord_str23), heff_rec_n(2, shape_start__end, (V[]){v_start_244, v_end_245}), NTAG(TAG_Nothing)});
                          return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24t_2456_24Just, TAG_Left, 1, (V[]){v_t_2460}), v_p_242});
                        }
                        default: return heff_nomatch(v_t_2456);
                        }
                      } else {
                        heff_drop_rec(v_s_241, 5);
                        V v_t_2461 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2especWord_str24), heff_rec_n(2, shape_start__end, (V[]){v_start_244, v_end_245}), NTAG(TAG_Nothing)});
                        return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2461}), v_p_242});
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}
V g_heff_2esyntax_2esurface_2especWord_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2especWord(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2esyntax_2esurface_2etypeChecks_24cpr_str0, 45, "an integer's segment is of 1 to 64 bits, not ");
HEFF_LIT(g_heff_2esyntax_2esurface_2etypeChecks_24cpr_str1, 0, "");
HEFF_LIT(g_heff_2esyntax_2esurface_2etypeChecks_24cpr_str2, 10, ", unsigned");
HEFF_LIT(g_heff_2esyntax_2esurface_2etypeChecks_24cpr_str3, 8, ", signed");
HEFF_LIT(g_heff_2esyntax_2esurface_2etypeChecks_24cpr_str4, 10, ", unsigned");
HEFF_LIT(g_heff_2esyntax_2esurface_2etypeChecks_24cpr_str5, 17, " does not fit in ");
HEFF_LIT(g_heff_2esyntax_2esurface_2etypeChecks_24cpr_str6, 5, " bits");
HEFF_LIT(g_heff_2esyntax_2esurface_2etypeChecks_24cpr_str7, 66, "a string's segment is its bytes, all of them, as they are: `\"GET\"`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etypeChecks_24cpr_str8, 66, "a string's segment is its bytes, all of them, as they are: `\"GET\"`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etypeChecks_24cpr_str9, 66, "a string's segment is its bytes, all of them, as they are: `\"GET\"`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etypeChecks_24cpr_str10, 66, "a string's segment is its bytes, all of them, as they are: `\"GET\"`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etypeChecks_24cpr_str11, 82, "bytes are whole bytes: their unit is a multiple of 8, `x::binary-size(2)-unit(16)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etypeChecks_24cpr_str12, 69, "bytes are of no endianness nor sign: `x::binary`, `x::binary-size(4)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etypeChecks_24cpr_str13, 69, "bytes are of no endianness nor sign: `x::binary`, `x::binary-size(4)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etypeChecks_24cpr_str14, 64, "bits are of no endianness nor sign: `x::bits`, `x::bits-size(3)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etypeChecks_24cpr_str15, 64, "bits are of no endianness nor sign: `x::bits`, `x::bits-size(3)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etypeChecks_24cpr_str16, 43, "a float's segment is of 32 or 64 bits, not ");
HEFF_LIT(g_heff_2esyntax_2esurface_2etypeChecks_24cpr_str17, 51, "a float's size is a number, 32 or 64: `x::float-32`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etypeChecks_24cpr_str18, 55, "a float is of no sign: `x::float`, `x::float-32-little`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etypeChecks_24cpr_str19, 36, "UTF-8 is of no endianness: `c::utf8`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etypeChecks_24cpr_str20, 35, "a code point is of no sign: `c::utf");
HEFF_LIT(g_heff_2esyntax_2esurface_2etypeChecks_24cpr_str21, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etypeChecks_24cpr_str22, 6, "a `utf");
HEFF_LIT(g_heff_2esyntax_2esurface_2etypeChecks_24cpr_str23, 64, "` segment is as long as its code point: it says no size, `c::utf");
HEFF_LIT(g_heff_2esyntax_2esurface_2etypeChecks_24cpr_str24, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etypeChecks_24cpr_str25, 35, "a code point is of no sign: `c::utf");
HEFF_LIT(g_heff_2esyntax_2esurface_2etypeChecks_24cpr_str26, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etypeChecks_24cpr_str27, 6, "a `utf");
HEFF_LIT(g_heff_2esyntax_2esurface_2etypeChecks_24cpr_str28, 64, "` segment is as long as its code point: it says no size, `c::utf");
HEFF_LIT(g_heff_2esyntax_2esurface_2etypeChecks_24cpr_str29, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etypeChecks_24cpr_str30, 35, "a code point is of no sign: `c::utf");
HEFF_LIT(g_heff_2esyntax_2esurface_2etypeChecks_24cpr_str31, 1, "`");

HeffT2 g_heff_2esyntax_2esurface_2etypeChecks_24cpr(V v_inPat_240, V v_sp_241, V v_v_242, V v_s_243, V v_x5_244, V v_x6_245, V v_z_246) {
top: ;
  switch (heff_tag_of(v_x5_244)) {
  case TAG_SegmentInteger: {
    V v_inPat_247 = v_inPat_240;
    V v_sp_248 = v_sp_241;
    V v_v_249 = v_v_242;
    V v_s_2410 = v_s_243;
    V v_x5_2415;
    switch (heff_tag_of(v_x6_245)) {
    case TAG_SizeDefault: {
      v_x5_2415 = heff_tag_n(TAG_Just, 1, (V[]){MK_INT(8LL)});
      break;
    }
    case TAG_SizeNumber: {
      V v_n_2411 = heff_field(v_x6_245, 0);
      V v_ru_24x6_245_24SizeNumber = heff_take_reuse_n(v_x6_245, 1ULL, 1);
      v_x5_2415 = heff_tag_at_n(v_ru_24x6_245_24SizeNumber, TAG_Just, 1, (V[]){v_n_2411});
      break;
    }
    case TAG_SizeName: {
      heff_take_n(v_x6_245, 0ULL, 3);
      v_x5_2415 = NTAG(TAG_Nothing);
      break;
    }
    default: heff_nomatch(v_x6_245);
    }
    switch (heff_tag_of(v_x5_2415)) {
    case TAG_Nothing: {
      heff_drop(v_inPat_247);
      heff_drop(v_sp_248);
      heff_drop(v_v_249);
      heff_drop(v_s_2410);
      V v_t_2416 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
      return ((HeffT2){{v_t_2416, v_z_246}});
    }
    case TAG_Just: {
      V v_n_2417 = heff_field(v_x5_2415, 0);
      V v_ru_24x5_2415_24Just = heff_take_reuse_n(v_x5_2415, 1ULL, 1);
      if ((heff_intLt_c_lent(v_n_2417, MK_INT(1LL), 2) || heff_intLt_c_lent(MK_INT(64LL), v_n_2417, 1))) {
        heff_drop(v_inPat_247);
        heff_drop(v_v_249);
        heff_drop(v_s_2410);
        V v_t_2418 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2etypeChecks_24cpr_str0), heff_intShow(v_n_2417));
        V v_t_2419 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_t_2418, v_sp_248, NTAG(TAG_Nothing)});
        V v_f_2420 = heff_tag_at_n(v_ru_24x5_2415_24Just, TAG_Left, 1, (V[]){v_t_2419});
        return ((HeffT2){{v_f_2420, v_z_246}});
      } else {
        V v_inPat_2421 = v_inPat_247;
        V v_sp_2422 = v_sp_248;
        V v_x3_2423 = v_v_249;
        V v_s_2424 = v_s_2410;
        V v_n_2425 = v_n_2417;
        switch (heff_tag_of(v_x3_2423)) {
        case TAG_StrValue: {
          heff_drop(v_inPat_2421);
          heff_drop(v_sp_2422);
          heff_drop_rec(v_s_2424, 5);
          heff_drop(v_n_2425);
          V v_t_2426 = heff_tag_at_n(v_ru_24x5_2415_24Just, TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
          return ((HeffT2){{v_t_2426, v_z_246}});
        }
        case TAG_IntValue: {
          V v_v_2427 = heff_field(v_x3_2423, 0);
          heff_take_n(v_x3_2423, 1ULL, 1);
          V v_x1_2428 = heff_dup(v_inPat_2421);
          V v_t_2429 = heff_dup(heff_rfield(v_s_2424, 4));
          V v_signed_2431;
          switch (heff_tag_of(v_t_2429)) {
          case TAG_Nothing: {
            v_signed_2431 = NTAG(TAG_False);
            break;
          }
          case TAG_Just: {
            V v_b_2430 = heff_field(v_t_2429, 0);
            heff_take_n(v_t_2429, 1ULL, 1);
            v_signed_2431 = v_b_2430;
            break;
          }
          default: heff_nomatch(v_t_2429);
          }
          V v_n_2432 = heff_dup(v_n_2425);
          V v_v_2433 = heff_dup(v_v_2427);
          if (((heff_dup(v_x1_2428) == NTAG(TAG_True)) ? ((heff_dup(v_signed_2431) == NTAG(TAG_True)) ? ({ V v_t_2434 = (g_heff_2esyntax_2esurface_2etwoToS(heff_box_word((heff_peek_word(v_n_2432) - ((int64_t)1ULL))))); int c_ = ({ V v_t_24124 = heff_intSub_lent(MK_INT(0LL), v_t_2434, 1); int c_ = (heff_intLe_c_lent(v_t_24124, v_v_2433, 0) && ({ V v_t_24125 = (g_heff_2esyntax_2esurface_2etwoToS(heff_box_word((heff_peek_word(v_n_2432) - ((int64_t)1ULL))))); int c_ = heff_intLt_c_lent(v_v_2433, v_t_24125, 0); heff_drop(v_t_24125); c_; })); heff_drop(v_t_24124); c_; }); heff_drop(v_t_2434); c_; }) : (heff_intLe_c_lent(MK_INT(0LL), v_v_2433, 1) && ({ V v_t_24126 = (g_heff_2esyntax_2esurface_2etwoToS(heff_dup(v_n_2432))); int c_ = heff_intLt_c_lent(v_v_2433, v_t_24126, 0); heff_drop(v_t_24126); c_; }))) : ({ V v_t_2435 = (g_heff_2esyntax_2esurface_2etwoToS(heff_box_word((heff_peek_word(v_n_2432) - ((int64_t)1ULL))))); int c_ = ({ V v_t_24127 = heff_intSub_lent(MK_INT(0LL), v_t_2435, 1); int c_ = (heff_intLe_c_lent(v_t_24127, v_v_2433, 0) && ({ V v_t_24128 = (g_heff_2esyntax_2esurface_2etwoToS(heff_dup(v_n_2432))); int c_ = heff_intLt_c_lent(v_v_2433, v_t_24128, 0); heff_drop(v_t_24128); c_; })); heff_drop(v_t_24127); c_; }); heff_drop(v_t_2435); c_; }))) {
            heff_drop(v_inPat_2421);
            heff_drop(v_sp_2422);
            heff_drop_rec(v_s_2424, 5);
            heff_drop(v_n_2425);
            heff_drop(v_v_2427);
            heff_drop(v_x1_2428);
            heff_drop(v_signed_2431);
            heff_drop(v_n_2432);
            heff_drop(v_v_2433);
            V v_t_2436 = heff_tag_at_n(v_ru_24x5_2415_24Just, TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
            return ((HeffT2){{v_t_2436, v_z_246}});
          } else {
            heff_drop(v_x1_2428);
            heff_drop(v_signed_2431);
            heff_drop(v_n_2432);
            heff_drop(v_v_2433);
            V v_t_2439;
            if (!(heff_dup(v_inPat_2421) == NTAG(TAG_True))) {
              heff_drop(v_inPat_2421);
              heff_drop_rec(v_s_2424, 5);
              v_t_2439 = ((V)&g_heff_2esyntax_2esurface_2etypeChecks_24cpr_str1);
            } else {
              heff_drop(v_inPat_2421);
              V v_t_2437 = heff_get_n(v_s_2424, 4, 5);
              switch (heff_tag_of(v_t_2437)) {
              case TAG_Nothing: {
                v_t_2439 = ((V)&g_heff_2esyntax_2esurface_2etypeChecks_24cpr_str2);
                break;
              }
              case TAG_Just: {
                V v_b_2438 = heff_field(v_t_2437, 0);
                heff_take_n(v_t_2437, 1ULL, 1);
                if ((heff_dup(v_b_2438) == NTAG(TAG_True))) {
                  heff_drop(v_b_2438);
                  v_t_2439 = ((V)&g_heff_2esyntax_2esurface_2etypeChecks_24cpr_str3);
                } else {
                  heff_drop(v_b_2438);
                  v_t_2439 = ((V)&g_heff_2esyntax_2esurface_2etypeChecks_24cpr_str4);
                }
                break;
              }
              default: heff_nomatch(v_t_2437);
              }
            }
            V v_t_2440 = heff_strAppend(heff_intShow(v_v_2427), ((V)&g_heff_2esyntax_2esurface_2etypeChecks_24cpr_str5));
            V v_t_2441 = heff_strAppend(v_t_2440, heff_intShow(v_n_2425));
            V v_t_2442 = heff_strAppend(heff_strAppend(v_t_2441, ((V)&g_heff_2esyntax_2esurface_2etypeChecks_24cpr_str6)), v_t_2439);
            V v_t_2443 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_t_2442, v_sp_2422, NTAG(TAG_Nothing)});
            V v_f_2444 = heff_tag_at_n(v_ru_24x5_2415_24Just, TAG_Left, 1, (V[]){v_t_2443});
            return ((HeffT2){{v_f_2444, v_z_246}});
          }
        }
        case TAG_FloatValue: {
          heff_drop(v_inPat_2421);
          heff_drop(v_sp_2422);
          heff_drop_rec(v_s_2424, 5);
          heff_drop(v_n_2425);
          V v_t_2445 = heff_tag_at_n(v_ru_24x5_2415_24Just, TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
          return ((HeffT2){{v_t_2445, v_z_246}});
        }
        case TAG_RuneValue: {
          heff_drop(v_inPat_2421);
          heff_drop(v_sp_2422);
          heff_drop_rec(v_s_2424, 5);
          heff_drop(v_n_2425);
          V v_t_2446 = heff_tag_at_n(v_ru_24x5_2415_24Just, TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
          return ((HeffT2){{v_t_2446, v_z_246}});
        }
        case TAG_OtherValue: {
          heff_drop(v_inPat_2421);
          heff_drop(v_sp_2422);
          heff_drop_rec(v_s_2424, 5);
          heff_drop(v_n_2425);
          V v_t_2447 = heff_tag_at_n(v_ru_24x5_2415_24Just, TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
          return ((HeffT2){{v_t_2447, v_z_246}});
        }
        default: return ((HeffT2){{heff_nomatch(v_x3_2423)}});
        }
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x5_2415)}});
    }
  }
  case TAG_SegmentBinary: {
    heff_drop(v_inPat_240);
    heff_drop(v_x6_245);
    switch (heff_tag_of(v_v_242)) {
    case TAG_StrValue: {
      V v_t_2448 = heff_take_field(v_s_243, 1);
      switch (heff_tag_of(v_t_2448)) {
      case TAG_SizeDefault: {
        V v_t_2449 = heff_take_field(v_s_243, 3);
        switch (heff_tag_of(v_t_2449)) {
        case TAG_Nothing: {
          V v_t_2450 = heff_get_n(v_s_243, 4, 5);
          switch (heff_tag_of(v_t_2450)) {
          case TAG_Nothing: {
            heff_drop(v_sp_241);
            V v_t_2451 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
            return ((HeffT2){{v_t_2451, v_z_246}});
          }
          case TAG_Just: {
            V v_ru_24t_2450_24Just = heff_take_reuse_n(v_t_2450, 0ULL, 1);
            V v_t_2453 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2etypeChecks_24cpr_str7), v_sp_241, NTAG(TAG_Nothing)});
            return ((HeffT2){{heff_tag_at_n(v_ru_24t_2450_24Just, TAG_Left, 1, (V[]){v_t_2453}), v_z_246}});
          }
          default: return ((HeffT2){{heff_nomatch(v_t_2450)}});
          }
        }
        case TAG_Just: {
          V v_ru_24t_2449_24Just = heff_take_reuse_n(v_t_2449, 0ULL, 1);
          heff_drop_rec(v_s_243, 5);
          V v_t_2455 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2etypeChecks_24cpr_str8), v_sp_241, NTAG(TAG_Nothing)});
          return ((HeffT2){{heff_tag_at_n(v_ru_24t_2449_24Just, TAG_Left, 1, (V[]){v_t_2455}), v_z_246}});
        }
        default: return ((HeffT2){{heff_nomatch(v_t_2449)}});
        }
      }
      case TAG_SizeNumber: {
        V v_ru_24t_2448_24SizeNumber = heff_take_reuse_n(v_t_2448, 0ULL, 1);
        heff_drop_rec(v_s_243, 5);
        V v_t_2457 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2etypeChecks_24cpr_str9), v_sp_241, NTAG(TAG_Nothing)});
        return ((HeffT2){{heff_tag_at_n(v_ru_24t_2448_24SizeNumber, TAG_Left, 1, (V[]){v_t_2457}), v_z_246}});
      }
      case TAG_SizeName: {
        heff_take_n(v_t_2448, 0ULL, 3);
        heff_drop_rec(v_s_243, 5);
        V v_t_2461 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2etypeChecks_24cpr_str10), v_sp_241, NTAG(TAG_Nothing)});
        return ((HeffT2){{heff_tag_n(TAG_Left, 1, (V[]){v_t_2461}), v_z_246}});
      }
      default: return ((HeffT2){{heff_nomatch(v_t_2448)}});
      }
    }
    default: {
      heff_drop(v_v_242);
      V v_t_2462 = heff_take_field(v_s_243, 2);
      V v_t_2464;
      switch (heff_tag_of(v_t_2462)) {
      case TAG_Nothing: {
        v_t_2464 = MK_INT(8LL);
        break;
      }
      case TAG_Just: {
        V v_u_2463 = heff_field(v_t_2462, 0);
        heff_take_n(v_t_2462, 1ULL, 1);
        v_t_2464 = v_u_2463;
        break;
      }
      default: heff_nomatch(v_t_2462);
      }
      if (!(heff_unbox_word(heff_intMod_lent(v_t_2464, MK_INT(8LL), 2)) == ((int64_t)0ULL))) {
        heff_drop_rec(v_s_243, 5);
        heff_drop(v_t_2464);
        V v_t_2465 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2etypeChecks_24cpr_str11), v_sp_241, NTAG(TAG_Nothing)});
        return ((HeffT2){{heff_tag_n(TAG_Left, 1, (V[]){v_t_2465}), v_z_246}});
      } else {
        heff_drop(v_t_2464);
        V v_t_2466 = heff_take_field(v_s_243, 3);
        switch (heff_tag_of(v_t_2466)) {
        case TAG_Nothing: {
          V v_t_2467 = heff_get_n(v_s_243, 4, 5);
          switch (heff_tag_of(v_t_2467)) {
          case TAG_Nothing: {
            heff_drop(v_sp_241);
            V v_t_2468 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
            return ((HeffT2){{v_t_2468, v_z_246}});
          }
          case TAG_Just: {
            V v_ru_24t_2467_24Just = heff_take_reuse_n(v_t_2467, 0ULL, 1);
            V v_t_2470 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2etypeChecks_24cpr_str12), v_sp_241, NTAG(TAG_Nothing)});
            return ((HeffT2){{heff_tag_at_n(v_ru_24t_2467_24Just, TAG_Left, 1, (V[]){v_t_2470}), v_z_246}});
          }
          default: return ((HeffT2){{heff_nomatch(v_t_2467)}});
          }
        }
        case TAG_Just: {
          V v_ru_24t_2466_24Just = heff_take_reuse_n(v_t_2466, 0ULL, 1);
          heff_drop_rec(v_s_243, 5);
          V v_t_2472 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2etypeChecks_24cpr_str13), v_sp_241, NTAG(TAG_Nothing)});
          return ((HeffT2){{heff_tag_at_n(v_ru_24t_2466_24Just, TAG_Left, 1, (V[]){v_t_2472}), v_z_246}});
        }
        default: return ((HeffT2){{heff_nomatch(v_t_2466)}});
        }
      }
    }
    }
  }
  case TAG_SegmentBits: {
    heff_drop(v_inPat_240);
    heff_drop(v_v_242);
    heff_drop(v_x6_245);
    V v_t_2473 = heff_take_field(v_s_243, 3);
    switch (heff_tag_of(v_t_2473)) {
    case TAG_Nothing: {
      V v_t_2474 = heff_get_n(v_s_243, 4, 5);
      switch (heff_tag_of(v_t_2474)) {
      case TAG_Nothing: {
        heff_drop(v_sp_241);
        V v_t_2475 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
        return ((HeffT2){{v_t_2475, v_z_246}});
      }
      case TAG_Just: {
        V v_ru_24t_2474_24Just = heff_take_reuse_n(v_t_2474, 0ULL, 1);
        V v_t_2477 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2etypeChecks_24cpr_str14), v_sp_241, NTAG(TAG_Nothing)});
        return ((HeffT2){{heff_tag_at_n(v_ru_24t_2474_24Just, TAG_Left, 1, (V[]){v_t_2477}), v_z_246}});
      }
      default: return ((HeffT2){{heff_nomatch(v_t_2474)}});
      }
    }
    case TAG_Just: {
      V v_ru_24t_2473_24Just = heff_take_reuse_n(v_t_2473, 0ULL, 1);
      heff_drop_rec(v_s_243, 5);
      V v_t_2479 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2etypeChecks_24cpr_str15), v_sp_241, NTAG(TAG_Nothing)});
      return ((HeffT2){{heff_tag_at_n(v_ru_24t_2473_24Just, TAG_Left, 1, (V[]){v_t_2479}), v_z_246}});
    }
    default: return ((HeffT2){{heff_nomatch(v_t_2473)}});
    }
  }
  case TAG_SegmentFloat: {
    heff_drop(v_inPat_240);
    heff_drop(v_v_242);
    V v_t_2480 = heff_get_n(v_s_243, 4, 5);
    switch (heff_tag_of(v_t_2480)) {
    case TAG_Nothing: {
      switch (heff_tag_of(v_x6_245)) {
      case TAG_SizeDefault: {
        heff_drop(v_sp_241);
        V v_t_2481 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
        return ((HeffT2){{v_t_2481, v_z_246}});
      }
      case TAG_SizeNumber: {
        V v_x61_2482 = heff_field(v_x6_245, 0);
        V v_ru_24x6_245_24SizeNumber = heff_take_reuse_n(v_x6_245, 1ULL, 1);
        if (heff_intEq_c_lent(v_x61_2482, MK_INT(64LL), 2)) {
          heff_drop(v_sp_241);
          heff_drop(v_x61_2482);
          V v_t_2483 = heff_tag_at_n(v_ru_24x6_245_24SizeNumber, TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
          return ((HeffT2){{v_t_2483, v_z_246}});
        } else {
          if (heff_intEq_c_lent(v_x61_2482, MK_INT(32LL), 2)) {
            heff_drop(v_sp_241);
            heff_drop(v_x61_2482);
            V v_t_2484 = heff_tag_at_n(v_ru_24x6_245_24SizeNumber, TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
            return ((HeffT2){{v_t_2484, v_z_246}});
          } else {
            V v_t_2485 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2etypeChecks_24cpr_str16), heff_intShow(v_x61_2482));
            V v_t_2486 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_t_2485, v_sp_241, NTAG(TAG_Nothing)});
            V v_f_2487 = heff_tag_at_n(v_ru_24x6_245_24SizeNumber, TAG_Left, 1, (V[]){v_t_2486});
            return ((HeffT2){{v_f_2487, v_z_246}});
          }
        }
      }
      case TAG_SizeName: {
        heff_take_n(v_x6_245, 0ULL, 3);
        V v_t_2491 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2etypeChecks_24cpr_str17), v_sp_241, NTAG(TAG_Nothing)});
        return ((HeffT2){{heff_tag_n(TAG_Left, 1, (V[]){v_t_2491}), v_z_246}});
      }
      default: return ((HeffT2){{heff_nomatch(v_x6_245)}});
      }
    }
    case TAG_Just: {
      V v_ru_24t_2480_24Just = heff_take_reuse_n(v_t_2480, 0ULL, 1);
      heff_drop(v_x6_245);
      V v_t_2493 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2etypeChecks_24cpr_str18), v_sp_241, NTAG(TAG_Nothing)});
      return ((HeffT2){{heff_tag_at_n(v_ru_24t_2480_24Just, TAG_Left, 1, (V[]){v_t_2493}), v_z_246}});
    }
    default: return ((HeffT2){{heff_nomatch(v_t_2480)}});
    }
  }
  case TAG_SegmentUtf: {
    V v_w_2494 = heff_field(v_x5_244, 0);
    V v_ru_24x5_244_24SegmentUtf = heff_take_reuse_n(v_x5_244, 1ULL, 1);
    heff_drop(v_inPat_240);
    heff_drop(v_v_242);
    heff_drop(v_x6_245);
    V v_signed_2495 = heff_take_field(v_s_243, 4);
    V v_t_2496 = heff_take_field(v_s_243, 1);
    switch (heff_tag_of(v_t_2496)) {
    case TAG_SizeDefault: {
      V v_t_2497 = heff_take_field(v_s_243, 2);
      switch (heff_tag_of(v_t_2497)) {
      case TAG_Nothing: {
        switch (heff_tag_of(v_signed_2495)) {
        case TAG_Nothing: {
          V v_t_2498 = heff_get_n(v_s_243, 3, 5);
          switch (heff_tag_of(v_t_2498)) {
          case TAG_Nothing: {
            heff_drop(v_sp_241);
            heff_drop(v_w_2494);
            V v_t_2499 = heff_tag_at_n(v_ru_24x5_244_24SegmentUtf, TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
            return ((HeffT2){{v_t_2499, v_z_246}});
          }
          case TAG_Just: {
            heff_take_n(v_t_2498, 0ULL, 1);
            if (heff_intEq_c(v_w_2494, MK_INT(8LL))) {
              V v_t_24101 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2etypeChecks_24cpr_str19), v_sp_241, NTAG(TAG_Nothing)});
              return ((HeffT2){{heff_tag_at_n(v_ru_24x5_244_24SegmentUtf, TAG_Left, 1, (V[]){v_t_24101}), v_z_246}});
            } else {
              heff_drop(v_sp_241);
              V v_t_24102 = heff_tag_at_n(v_ru_24x5_244_24SegmentUtf, TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
              return ((HeffT2){{v_t_24102, v_z_246}});
            }
          }
          default: return ((HeffT2){{heff_nomatch(v_t_2498)}});
          }
        }
        case TAG_Just: {
          heff_take_n(v_signed_2495, 0ULL, 1);
          heff_drop_rec(v_s_243, 5);
          V v_t_24104 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2etypeChecks_24cpr_str20), heff_intShow(v_w_2494));
          V v_t_24105 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), heff_strAppend(v_t_24104, ((V)&g_heff_2esyntax_2esurface_2etypeChecks_24cpr_str21)), v_sp_241, NTAG(TAG_Nothing)});
          V v_f_24106 = heff_tag_at_n(v_ru_24x5_244_24SegmentUtf, TAG_Left, 1, (V[]){v_t_24105});
          return ((HeffT2){{v_f_24106, v_z_246}});
        }
        default: return ((HeffT2){{heff_nomatch(v_signed_2495)}});
        }
      }
      case TAG_Just: {
        heff_take_n(v_t_2497, 0ULL, 1);
        heff_drop_rec(v_s_243, 5);
        switch (heff_tag_of(v_signed_2495)) {
        case TAG_Nothing: {
          V v_t_24108 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2etypeChecks_24cpr_str22), heff_intShow(heff_dup(v_w_2494)));
          V v_t_24109 = heff_strAppend(heff_strAppend(v_t_24108, ((V)&g_heff_2esyntax_2esurface_2etypeChecks_24cpr_str23)), heff_intShow(v_w_2494));
          V v_t_24110 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), heff_strAppend(v_t_24109, ((V)&g_heff_2esyntax_2esurface_2etypeChecks_24cpr_str24)), v_sp_241, NTAG(TAG_Nothing)});
          V v_f_24111 = heff_tag_at_n(v_ru_24x5_244_24SegmentUtf, TAG_Left, 1, (V[]){v_t_24110});
          return ((HeffT2){{v_f_24111, v_z_246}});
        }
        case TAG_Just: {
          heff_take_n(v_signed_2495, 0ULL, 1);
          V v_t_24113 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2etypeChecks_24cpr_str25), heff_intShow(v_w_2494));
          V v_t_24114 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), heff_strAppend(v_t_24113, ((V)&g_heff_2esyntax_2esurface_2etypeChecks_24cpr_str26)), v_sp_241, NTAG(TAG_Nothing)});
          V v_f_24115 = heff_tag_at_n(v_ru_24x5_244_24SegmentUtf, TAG_Left, 1, (V[]){v_t_24114});
          return ((HeffT2){{v_f_24115, v_z_246}});
        }
        default: return ((HeffT2){{heff_nomatch(v_signed_2495)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_t_2497)}});
      }
    }
    default: {
      heff_drop_rec(v_s_243, 5);
      heff_drop(v_t_2496);
      switch (heff_tag_of(v_signed_2495)) {
      case TAG_Nothing: {
        V v_t_24116 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2etypeChecks_24cpr_str27), heff_intShow(heff_dup(v_w_2494)));
        V v_t_24117 = heff_strAppend(heff_strAppend(v_t_24116, ((V)&g_heff_2esyntax_2esurface_2etypeChecks_24cpr_str28)), heff_intShow(v_w_2494));
        V v_t_24118 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), heff_strAppend(v_t_24117, ((V)&g_heff_2esyntax_2esurface_2etypeChecks_24cpr_str29)), v_sp_241, NTAG(TAG_Nothing)});
        V v_f_24119 = heff_tag_at_n(v_ru_24x5_244_24SegmentUtf, TAG_Left, 1, (V[]){v_t_24118});
        return ((HeffT2){{v_f_24119, v_z_246}});
      }
      case TAG_Just: {
        heff_take_n(v_signed_2495, 0ULL, 1);
        V v_t_24121 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2etypeChecks_24cpr_str30), heff_intShow(v_w_2494));
        V v_t_24122 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), heff_strAppend(v_t_24121, ((V)&g_heff_2esyntax_2esurface_2etypeChecks_24cpr_str31)), v_sp_241, NTAG(TAG_Nothing)});
        V v_f_24123 = heff_tag_at_n(v_ru_24x5_244_24SegmentUtf, TAG_Left, 1, (V[]){v_t_24122});
        return ((HeffT2){{v_f_24123, v_z_246}});
      }
      default: return ((HeffT2){{heff_nomatch(v_signed_2495)}});
      }
    }
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x5_244)}});
  }
}
Clo g_heff_2esyntax_2esurface_2evarAtom_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2evarAtom_entry, 3, 0};

V g_heff_2esyntax_2esurface_2evarAtom(V v_t_240, V v_fs_241, V v_st_242) {
top: ;
  V v_t_243 = (g_list_2eany_24s565534491x447967237(v_t_240, heff_rfield(v_st_242, 1)));
  HeffT2 v_t_244 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(heff_rfield(v_st_242, 8), heff_rfield(v_t_240, 1)));
  {
    V v_field_246 = v_t_244.f[1];
    int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
    V v_x_2419;
    if ((v_tag_245 == ((int64_t)0ULL))) {
      V v_k_247 = v_field_246;
      if ((heff_dup(v_t_243) == NTAG(TAG_True))) {
        heff_drop(v_t_243);
        heff_drop(v_k_247);
        V v_e_248 = (g_heff_2esyntax_2esurface_2eatomTok(v_t_240));
        V v_t_249 = (g_list_2emap_24s513201124x806973253(v_fs_241));
        v_x_2419 = (g_heff_2esyntax_2epresyntax_2eapp(v_e_248, v_t_249));
      } else {
        heff_drop(v_t_243);
        V v_t_2410 = heff_intAdd(heff_dup(heff_rfield(v_t_240, 3)), heff_strLength_lent(v_k_247, 0));
        V v_t_2411 = heff_rec_n(2, shape_start__end, (V[]){heff_dup(heff_rfield(v_t_240, 3)), heff_intAdd(v_t_2410, MK_INT(2LL))});
        V v_t_2412 = (g_list_2emap_24s513201124x806973253(v_fs_241));
        V v_t_2413 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_k_247}), v_t_2411});
        V v_t_2414 = heff_tag_n(TAG_EProject, 1, (V[]){heff_take_field(v_t_240, 1)});
        V v_t_2415 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_240, 3), heff_get_n(v_t_240, 4, 9)});
        V v_t_2416 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2414, v_t_2415}), v_t_2412});
        v_x_2419 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_2413, v_t_2416));
      }
    } else {
      heff_drop(v_t_243);
      heff_drop(v_field_246);
      V v_e_2417 = (g_heff_2esyntax_2esurface_2eatomTok(v_t_240));
      V v_t_2418 = (g_list_2emap_24s513201124x806973253(v_fs_241));
      v_x_2419 = (g_heff_2esyntax_2epresyntax_2eapp(v_e_2417, v_t_2418));
    }
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2419}), v_st_242});
  }
}
V g_heff_2esyntax_2esurface_2evarAtom_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2evarAtom(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2esyntax_2esurface_2eifLetL_24s130707926x1920299130_str0, 1, "_");
V g_heff_2esyntax_2esurface_2eifLetL_24s130707926x1920299130_lam0(V self, V *args);
Clo g_heff_2esyntax_2esurface_2eifLetL_24s130707926x1920299130_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eifLetL_24s130707926x1920299130_entry, 8, 0};

V g_heff_2esyntax_2esurface_2eifLetL_24s130707926x1920299130(V v_lit_240, V v_r_241, V v_kw_242, V v_p_243, V v_ann0_244, V v_e_245, V v_a_246, V v_last_247) {
top: ;
  V v_m_248 = (g_heff_2esyntax_2esurface_2eletHeadL(heff_dup(v_r_241), heff_dup(v_p_243), v_ann0_244, v_e_245));
  return heff_clo_n(g_heff_2esyntax_2esurface_2eifLetL_24s130707926x1920299130_lam0, 1, 7, (V[]){v_m_248, v_p_243, v_r_241, v_a_246, v_last_247, v_kw_242, v_lit_240});
}
V g_heff_2esyntax_2esurface_2eifLetL_24s130707926x1920299130_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2eifLetL_24s130707926x1920299130(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
}
V g_heff_2esyntax_2esurface_2eifLetL_24s130707926x1920299130_lam0(V self, V *args) {
  V v_st_249 = args[0];
  V v_m_248 = heff_env(self)[0];
  V v_p_243 = heff_env(self)[1];
  V v_r_241 = heff_env(self)[2];
  V v_a_246 = heff_env(self)[3];
  V v_last_247 = heff_env(self)[4];
  V v_kw_242 = heff_env(self)[5];
  V v_lit_240 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_x1_2410 = heff_tr(heff_call(v_m_248, 1, (V[]){v_st_249}));
  switch (heff_tag_of(v_x1_2410)) {
  case TAG_MkPair: {
    V v_x11_2411 = heff_field(v_x1_2410, 0);
    V v_st_2412 = heff_field(v_x1_2410, 1);
    V v_ru_24x1_2410_24MkPair = heff_take_reuse_n(v_x1_2410, 3ULL, 2);
    switch (heff_tag_of(v_x11_2411)) {
    case TAG_Left: {
      V v_e_2413 = heff_field(v_x11_2411, 0);
      V v_ru_24x11_2411_24Left = heff_take_reuse_n(v_x11_2411, 1ULL, 1);
      heff_drop(v_p_243);
      heff_drop_rec(v_r_241, 3);
      heff_drop(v_a_246);
      heff_drop(v_last_247);
      heff_drop_rec(v_kw_242, 9);
      heff_drop(v_lit_240);
      return heff_tag_re_n(v_ru_24x1_2410_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x11_2411_24Left, TAG_Left, 1, 1ULL, (V[]){v_e_2413}), v_st_2412});
    }
    case TAG_Right: {
      V v_x_2414 = heff_field(v_x11_2411, 0);
      V v_ru_24x11_2411_24Right = heff_take_reuse_n(v_x11_2411, 1ULL, 1);
      V v_t_2415 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_p_243; V r_ = (g_heff_2esyntax_2esurface_2eboundBy(a_0, a_1)); heff_drop(v_p_243); r_; });
      V v_t_2416 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_241, 0)), 1, (V[]){v_a_246}));
      HeffT2 v_t_2417 = (g_heff_2esyntax_2esurface_2ewithScope_24cpr(v_t_2415, v_t_2416, v_st_2412));
      {
        V v_field_2418 = v_t_2417.f[0];
        V v_field_2419 = v_t_2417.f[1];
        V v_x11_2420 = v_field_2418;
        V v_st_2421 = v_field_2419;
        switch (heff_tag_of(v_x11_2420)) {
        case TAG_Left: {
          V v_e_2422 = heff_field(v_x11_2420, 0);
          V v_ru_24x11_2420_24Left = heff_take_reuse_n(v_x11_2420, 1ULL, 1);
          heff_drop_rec(v_r_241, 3);
          heff_drop(v_last_247);
          heff_drop_rec(v_kw_242, 9);
          heff_drop(v_lit_240);
          heff_drop(v_x_2414);
          heff_drop_cell(v_ru_24x11_2411_24Right, 1);
          return heff_tag_at_n(v_ru_24x1_2410_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_re_n(v_ru_24x11_2420_24Left, TAG_Left, 1, 1ULL, (V[]){v_e_2422}), v_st_2421});
        }
        case TAG_Right: {
          V v_x_2423 = heff_field(v_x11_2420, 0);
          V v_ru_24x11_2420_24Right = heff_take_reuse_n(v_x11_2420, 1ULL, 1);
          V v_t_2424 = (g_heff_2esyntax_2ecst_2elastE(v_last_247));
          V v_e_2425 = heff_get_n(v_t_2424, 4, 9);
          V v_sp_2426 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_242, 3, 9), v_e_2425});
          V v_m_2427 = heff_tr(heff_call(heff_get_n(v_r_241, 0, 3), 1, (V[]){v_lit_240}));
          V v_x1_2428 = heff_tr(heff_call(v_m_2427, 1, (V[]){v_st_2421}));
          switch (heff_tag_of(v_x1_2428)) {
          case TAG_MkPair: {
            V v_x11_2429 = heff_field(v_x1_2428, 0);
            V v_st_2430 = heff_field(v_x1_2428, 1);
            V v_ru_24x1_2428_24MkPair = heff_take_reuse_n(v_x1_2428, 3ULL, 2);
            switch (heff_tag_of(v_x11_2429)) {
            case TAG_Left: {
              V v_e_2431 = heff_field(v_x11_2429, 0);
              heff_take_n(v_x11_2429, 1ULL, 1);
              heff_drop(v_x_2414);
              heff_drop_cell(v_ru_24x11_2411_24Right, 1);
              heff_drop(v_x_2423);
              heff_drop_rec(v_sp_2426, 2);
              heff_drop_cell(v_ru_24x1_2428_24MkPair, 2);
              return heff_tag_at_n(v_ru_24x1_2410_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_2420_24Right, TAG_Left, 1, (V[]){v_e_2431}), v_st_2430});
            }
            case TAG_Right: {
              V v_x_2432 = heff_field(v_x11_2429, 0);
              heff_take_n(v_x11_2429, 1ULL, 1);
              V v_t_2435;
              switch (heff_tag_of(v_x_2414)) {
              case TAG_MkPair: {
                V v_y_2434 = heff_dup(heff_field(v_x_2414, 1));
                v_t_2435 = v_y_2434;
                break;
              }
              default: heff_nomatch(v_x_2414);
              }
              V v_p_2438;
              switch (heff_tag_of(v_x_2414)) {
              case TAG_MkPair: {
                V v_x_2436 = heff_field(v_x_2414, 0);
                heff_take_n(v_x_2414, 1ULL, 2);
                v_p_2438 = v_x_2436;
                break;
              }
              default: heff_nomatch(v_x_2414);
              }
              V v_t_2441;
              switch (heff_tag_of(v_p_2438)) {
              case TAG_At: {
                V v_s_2440 = heff_dup(heff_field(v_p_2438, 1));
                v_t_2441 = v_s_2440;
                break;
              }
              default: heff_nomatch(v_p_2438);
              }
              V v_t_2444;
              switch (heff_tag_of(v_x_2423)) {
              case TAG_At: {
                V v_s_2443 = heff_dup(heff_field(v_x_2423, 1));
                v_t_2444 = v_s_2443;
                break;
              }
              default: heff_nomatch(v_x_2423);
              }
              V v_t_2447;
              switch (heff_tag_of(v_x_2432)) {
              case TAG_At: {
                V v_s_2446 = heff_dup(heff_field(v_x_2432, 1));
                v_t_2447 = v_s_2446;
                break;
              }
              default: heff_nomatch(v_x_2432);
              }
              V v_t_2448 = ({ V rv_1 = heff_get_n(v_t_2444, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_2441, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
              V v_t_2449 = heff_tag_at_n(v_ru_24x1_2428_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_2438, v_x_2423}), v_t_2448});
              V v_t_2450 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_2420_24Right, TAG_PatVar, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2eifLetL_24s130707926x1920299130_str0)}), heff_dup(v_sp_2426)});
              V v_t_2451 = ({ V rv_0 = heff_dup(heff_rfield(v_sp_2426, 0)); V rr_ = heff_rec_reuse_nf(v_t_2447, 2ULL, 2, shape_start__end, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
              V v_t_2452 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_t_2450, v_x_2432}), v_t_2451});
              V v_t_2453 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2452, NTAG(TAG_Nil)});
              V v_t_2454 = heff_tag_n(TAG_EMatch, 2, (V[]){v_t_2435, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2449, v_t_2453})});
              V v_t_2455 = heff_tag_at_n(v_ru_24x11_2411_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2454, v_sp_2426})});
              return heff_tag_at_n(v_ru_24x1_2410_24MkPair, TAG_MkPair, 2, (V[]){v_t_2455, v_st_2430});
            }
            default: return heff_nomatch(v_x11_2429);
            }
          }
          default: return heff_nomatch(v_x1_2428);
          }
        }
        default: return heff_nomatch(v_x11_2420);
        }
      }
    }
    default: return heff_nomatch(v_x11_2411);
    }
  }
  default: return heff_nomatch(v_x1_2410);
  }
}
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str0, 3, "con");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str1, 3, "var");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str2, 2, "`(");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str3, 51, " := ...)` names an argument, after a function: `f (");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str4, 7, " := e)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str5, 2, "b[");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str6, 1, "[");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str7, 3, "Nil");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str8, 4, "Cons");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str9, 24, "a field is `name : Type`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str10, 61, "an instance argument is bound before `->`: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str11, 3, "con");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str12, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str13, 3, "var");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str14, 11, "prelude.neg");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str15, 4, "tick");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str16, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str17, 3, "con");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str18, 3, "var");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str19, 2, "&&");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str20, 5, "False");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str21, 2, "||");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str22, 4, "True");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str23, 5, "break");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str24, 3, "err");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str25, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str26, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str27, 8, "with#arg");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str28, 8, "with#arg");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str29, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str30, 1, "`");
V g_heff_2esyntax_2esurface_2eexprL_lam0(V self, V *args);
V g_heff_2esyntax_2esurface_2eexprL_lam1(V self, V *args);
V g_heff_2esyntax_2esurface_2eexprL_lam3(V self, V *args);
V g_heff_2esyntax_2esurface_2eexprL_lam4(V self, V *args);
V g_heff_2esyntax_2esurface_2eexprL_lam2(V self, V *args);
V g_heff_2esyntax_2esurface_2eexprL_lam5(V self, V *args);
V g_heff_2esyntax_2esurface_2eexprL_lam6(V self, V *args);
V g_heff_2esyntax_2esurface_2eexprL_lam7(V self, V *args);
V g_heff_2esyntax_2esurface_2eexprL_lam9(V self, V *args);
V g_heff_2esyntax_2esurface_2eexprL_lam8(V self, V *args);
V g_heff_2esyntax_2esurface_2eexprL_lam11(V self, V *args);
V g_heff_2esyntax_2esurface_2eexprL_lam12(V self, V *args);
V g_heff_2esyntax_2esurface_2eexprL_lam10(V self, V *args);
V g_heff_2esyntax_2esurface_2eexprL_lam14(V self, V *args);
V g_heff_2esyntax_2esurface_2eexprL_lam15(V self, V *args); static Clo g_heff_2esyntax_2esurface_2eexprL_lam15_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eexprL_lam15, 1, 0};
V g_heff_2esyntax_2esurface_2eexprL_lam16(V self, V *args); static Clo g_heff_2esyntax_2esurface_2eexprL_lam16_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eexprL_lam16, 1, 0};
V g_heff_2esyntax_2esurface_2eexprL_lam13(V self, V *args);
V g_heff_2esyntax_2esurface_2eexprL_lam17(V self, V *args);
V g_heff_2esyntax_2esurface_2eexprL_lam18(V self, V *args);
V g_heff_2esyntax_2esurface_2eexprL_lam19(V self, V *args);
V g_heff_2esyntax_2esurface_2eexprL_lam21(V self, V *args);
V g_heff_2esyntax_2esurface_2eexprL_lam20(V self, V *args);
V g_heff_2esyntax_2esurface_2eexprL_lam22(V self, V *args);
V g_heff_2esyntax_2esurface_2eexprL_lam24(V self, V *args);
V g_heff_2esyntax_2esurface_2eexprL_lam23(V self, V *args);
V g_heff_2esyntax_2esurface_2eexprL_lam25(V self, V *args);
V g_heff_2esyntax_2esurface_2eexprL_lam27(V self, V *args);
V g_heff_2esyntax_2esurface_2eexprL_lam26(V self, V *args);
V g_heff_2esyntax_2esurface_2eexprL_lam28(V self, V *args);
V g_heff_2esyntax_2esurface_2eexprL_lam30(V self, V *args);
V g_heff_2esyntax_2esurface_2eexprL_lam29(V self, V *args);
V g_heff_2esyntax_2esurface_2eexprL_lam31(V self, V *args); static Clo g_heff_2esyntax_2esurface_2eexprL_lam31_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eexprL_lam31, 1, 0};
V g_heff_2esyntax_2esurface_2eexprL_lam32(V self, V *args);
V g_heff_2esyntax_2esurface_2eexprL_lam33(V self, V *args);
V g_heff_2esyntax_2esurface_2eexprL_lam34(V self, V *args);
V g_heff_2esyntax_2esurface_2eexprL_lam36(V self, V *args);
V g_heff_2esyntax_2esurface_2eexprL_lam35(V self, V *args);
V g_heff_2esyntax_2esurface_2eexprL_lam37(V self, V *args);
V g_heff_2esyntax_2esurface_2eexprL_lam39(V self, V *args);
V g_heff_2esyntax_2esurface_2eexprL_lam38(V self, V *args);
V g_heff_2esyntax_2esurface_2eexprL_lam41(V self, V *args);
V g_heff_2esyntax_2esurface_2eexprL_lam40(V self, V *args);
V g_heff_2esyntax_2esurface_2eexprL_lam42(V self, V *args);
V g_heff_2esyntax_2esurface_2eexprL_lam43(V self, V *args); static Clo g_heff_2esyntax_2esurface_2eexprL_lam43_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eexprL_lam43, 1, 0};
V g_heff_2esyntax_2esurface_2eexprL_lam44(V self, V *args);
V g_heff_2esyntax_2esurface_2eexprL_lam46(V self, V *args);
V g_heff_2esyntax_2esurface_2eexprL_lam45(V self, V *args);
Clo g_heff_2esyntax_2esurface_2eexprL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eexprL_entry, 3, 0};

V g_heff_2esyntax_2esurface_2eexprL(V v_r_240, V v_e0_241, V v_z_242) {
top: ;
  switch (heff_tag_of(v_e0_241)) {
  case TAG_Atom: {
    V v_t_243 = heff_field(v_e0_241, 0);
    V v_ru_24e0_241_24Atom = heff_take_reuse_n(v_e0_241, 1ULL, 1);
    heff_drop_rec(v_r_240, 3);
    if (heff_strEq_c(heff_dup(heff_rfield(v_t_243, 0)), ((V)&g_heff_2esyntax_2esurface_2eexprL_str0))) {
      heff_drop_cell(v_ru_24e0_241_24Atom, 1);
      HEFF_LAST return g_heff_2esyntax_2esurface_2econAtom(v_t_243, NTAG(TAG_Nil), v_z_242);
    } else {
      if (heff_strEq_c(heff_dup(heff_rfield(v_t_243, 0)), ((V)&g_heff_2esyntax_2esurface_2eexprL_str1))) {
        return (g_heff_2esyntax_2esurface_2evarAtom_24tok1(v_ru_24e0_241_24Atom, v_t_243, NTAG(TAG_Nil), v_z_242));
      } else {
        V v_x_244 = (g_heff_2esyntax_2esurface_2eatomTok(v_t_243));
        return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24e0_241_24Atom, TAG_Right, 1, (V[]){v_x_244}), v_z_242});
      }
    }
  }
  case TAG_EParen: {
    V v_o_245 = heff_field(v_e0_241, 0);
    V v_e_246 = heff_field(v_e0_241, 1);
    V v_c_247 = heff_field(v_e0_241, 2);
    heff_take_n(v_e0_241, 7ULL, 3);
    return ({ V a_0 = v_r_240; V a_1 = v_o_245; V a_2 = v_e_246; V a_3 = v_c_247; V a_4 = v_z_242; V r_ = (g_heff_2esyntax_2esurface_2eparenL(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_o_245); r_; });
  }
  case TAG_Named: {
    V v_o_248 = heff_field(v_e0_241, 0);
    V v_x_249 = heff_field(v_e0_241, 1);
    V v_e_2411 = heff_field(v_e0_241, 3);
    V v_c_2412 = heff_field(v_e0_241, 4);
    heff_take_n(v_e0_241, 27ULL, 5);
    V v_m_2413 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_2411}));
    V v_x1_2414 = heff_tr(heff_call(v_m_2413, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x1_2414)) {
    case TAG_MkPair: {
      V v_x11_2415 = heff_field(v_x1_2414, 0);
      V v_st_2416 = heff_field(v_x1_2414, 1);
      V v_ru_24x1_2414_24MkPair = heff_take_reuse_n(v_x1_2414, 3ULL, 2);
      switch (heff_tag_of(v_x11_2415)) {
      case TAG_Left: {
        V v_e_2417 = heff_field(v_x11_2415, 0);
        V v_ru_24x11_2415_24Left = heff_take_reuse_n(v_x11_2415, 1ULL, 1);
        heff_drop_rec(v_o_248, 9);
        heff_drop_rec(v_x_249, 9);
        heff_drop_rec(v_c_2412, 9);
        return heff_tag_re_n(v_ru_24x1_2414_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x11_2415_24Left, TAG_Left, 1, 1ULL, (V[]){v_e_2417}), v_st_2416});
      }
      case TAG_Right: {
        V v_ru_24x11_2415_24Right = heff_take_reuse_n(v_x11_2415, 0ULL, 1);
        V v_t_2419 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eexprL_str2), heff_dup(heff_rfield(v_x_249, 1)));
        V v_t_2420 = heff_strAppend(heff_strAppend(v_t_2419, ((V)&g_heff_2esyntax_2esurface_2eexprL_str3)), heff_get_n(v_x_249, 1, 9));
        V v_t_2421 = heff_tag_n(TAG_EInvalid, 1, (V[]){heff_strAppend(v_t_2420, ((V)&g_heff_2esyntax_2esurface_2eexprL_str4))});
        V v_t_2422 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_o_248, 3, 9), heff_get_n(v_c_2412, 4, 9)});
        V v_t_2423 = heff_tag_at_n(v_ru_24x11_2415_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2421, v_t_2422})});
        return heff_tag_re_n(v_ru_24x1_2414_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){v_t_2423, v_st_2416});
      }
      default: return heff_nomatch(v_x11_2415);
      }
    }
    default: return heff_nomatch(v_x1_2414);
    }
  }
  case TAG_Tup: {
    V v_o_2424 = heff_field(v_e0_241, 0);
    V v_es_2425 = heff_field(v_e0_241, 1);
    V v_c_2427 = heff_field(v_e0_241, 3);
    heff_take_n(v_e0_241, 11ULL, 4);
    V v_text_2428 = heff_take_field(v_o_2424, 1);
    V v_start_2429 = heff_get_n(v_o_2424, 3, 9);
    if (heff_strEq_c_lent(v_text_2428, ((V)&g_heff_2esyntax_2esurface_2eexprL_str5), 2)) {
      heff_drop(v_text_2428);
      V v_m_2431 = (g_prelude_2etraverse_24s499544530x2060473942(heff_clo_n(g_heff_2esyntax_2esurface_2eexprL_lam0, 1, 1, (V[]){v_r_240}), v_es_2425));
      V v_x1_2432 = heff_tr(heff_call(v_m_2431, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_2432)) {
      case TAG_MkPair: {
        V v_x11_2433 = heff_field(v_x1_2432, 0);
        V v_st_2434 = heff_field(v_x1_2432, 1);
        V v_ru_24x1_2432_24MkPair = heff_take_reuse_n(v_x1_2432, 3ULL, 2);
        switch (heff_tag_of(v_x11_2433)) {
        case TAG_Left: {
          V v_e_2435 = heff_field(v_x11_2433, 0);
          V v_ru_24x11_2433_24Left = heff_take_reuse_n(v_x11_2433, 1ULL, 1);
          heff_drop_rec(v_c_2427, 9);
          heff_drop(v_start_2429);
          return heff_tag_re_n(v_ru_24x1_2432_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x11_2433_24Left, TAG_Left, 1, 1ULL, (V[]){v_e_2435}), v_st_2434});
        }
        case TAG_Right: {
          V v_x_2436 = heff_field(v_x11_2433, 0);
          V v_ru_24x11_2433_24Right = heff_take_reuse_n(v_x11_2433, 1ULL, 1);
          V v_t_2437 = heff_rec_n(2, shape_start__end, (V[]){v_start_2429, heff_get_n(v_c_2427, 4, 9)});
          V v_t_2438 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EBinary, 1, (V[]){v_x_2436}), v_t_2437});
          return heff_tag_re_n(v_ru_24x1_2432_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_at_n(v_ru_24x11_2433_24Right, TAG_Right, 1, (V[]){v_t_2438}), v_st_2434});
        }
        default: return heff_nomatch(v_x11_2433);
        }
      }
      default: return heff_nomatch(v_x1_2432);
      }
    } else {
      if (heff_strEq_c(v_text_2428, ((V)&g_heff_2esyntax_2esurface_2eexprL_str6))) {
        V v_m_2439 = (g_prelude_2etraverse_24s499544530x2060473942(heff_get_n(v_r_240, 0, 3), v_es_2425));
        V v_x1_2440 = heff_tr(heff_call(v_m_2439, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_2440)) {
        case TAG_MkPair: {
          V v_x11_2441 = heff_field(v_x1_2440, 0);
          V v_st_2442 = heff_field(v_x1_2440, 1);
          V v_ru_24x1_2440_24MkPair = heff_take_reuse_n(v_x1_2440, 3ULL, 2);
          switch (heff_tag_of(v_x11_2441)) {
          case TAG_Left: {
            V v_e_2443 = heff_field(v_x11_2441, 0);
            V v_ru_24x11_2441_24Left = heff_take_reuse_n(v_x11_2441, 1ULL, 1);
            heff_drop_rec(v_c_2427, 9);
            heff_drop(v_start_2429);
            return heff_tag_re_n(v_ru_24x1_2440_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x11_2441_24Left, TAG_Left, 1, 1ULL, (V[]){v_e_2443}), v_st_2442});
          }
          case TAG_Right: {
            V v_x_2444 = heff_field(v_x11_2441, 0);
            V v_ru_24x11_2441_24Right = heff_take_reuse_n(v_x11_2441, 1ULL, 1);
            V v_sp_2445 = heff_rec_n(2, shape_start__end, (V[]){v_start_2429, heff_get_n(v_c_2427, 4, 9)});
            V v_t_2446 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ETag, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2eexprL_str7)}), heff_dup(v_sp_2445)});
            V v_x_2451 = ({ V b_0 = heff_clo_n(g_heff_2esyntax_2esurface_2eexprL_lam1, 2, 1, (V[]){v_sp_2445}); V a_1 = v_t_2446; V a_2 = v_x_2444; V r_ = heff_tr(g_heff_2esyntax_2esurface_2efoldr(b_0, a_1, a_2)); heff_drop(b_0); heff_drop_tag(v_t_2446, 2); heff_drop(v_x_2444); r_; });
            return heff_tag_re_n(v_ru_24x1_2440_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_at_n(v_ru_24x11_2441_24Right, TAG_Right, 1, (V[]){v_x_2451}), v_st_2442});
          }
          default: return heff_nomatch(v_x11_2441);
          }
        }
        default: return heff_nomatch(v_x1_2440);
        }
      } else {
        V v_m_2452 = (g_prelude_2etraverse_24s499544530x2060473942(heff_get_n(v_r_240, 0, 3), v_es_2425));
        V v_x1_2453 = heff_tr(heff_call(v_m_2452, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_2453)) {
        case TAG_MkPair: {
          V v_x11_2454 = heff_field(v_x1_2453, 0);
          V v_st_2455 = heff_field(v_x1_2453, 1);
          V v_ru_24x1_2453_24MkPair = heff_take_reuse_n(v_x1_2453, 3ULL, 2);
          switch (heff_tag_of(v_x11_2454)) {
          case TAG_Left: {
            V v_e_2456 = heff_field(v_x11_2454, 0);
            V v_ru_24x11_2454_24Left = heff_take_reuse_n(v_x11_2454, 1ULL, 1);
            heff_drop_rec(v_c_2427, 9);
            heff_drop(v_start_2429);
            return heff_tag_re_n(v_ru_24x1_2453_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x11_2454_24Left, TAG_Left, 1, 1ULL, (V[]){v_e_2456}), v_st_2455});
          }
          case TAG_Right: {
            V v_x_2457 = heff_field(v_x11_2454, 0);
            V v_ru_24x11_2454_24Right = heff_take_reuse_n(v_x11_2454, 1ULL, 1);
            V v_t_2458 = heff_rec_n(2, shape_start__end, (V[]){v_start_2429, heff_get_n(v_c_2427, 4, 9)});
            V v_t_2459 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ETuple, 1, (V[]){v_x_2457}), v_t_2458});
            return heff_tag_re_n(v_ru_24x1_2453_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_at_n(v_ru_24x11_2454_24Right, TAG_Right, 1, (V[]){v_t_2459}), v_st_2455});
          }
          default: return heff_nomatch(v_x11_2454);
          }
        }
        default: return heff_nomatch(v_x1_2453);
        }
      }
    }
  }
  case TAG_Braces: {
    V v_o_2460 = heff_field(v_e0_241, 0);
    V v_fs_2461 = heff_field(v_e0_241, 1);
    V v_c_2463 = heff_field(v_e0_241, 3);
    heff_take_n(v_e0_241, 11ULL, 4);
    return (g_heff_2esyntax_2esurface_2ebracesL(v_r_240, v_o_2460, v_fs_2461, v_c_2463, v_z_242));
  }
  case TAG_Update: {
    V v_o_2464 = heff_field(v_e0_241, 0);
    V v_rec_2465 = heff_field(v_e0_241, 1);
    V v_fs_2467 = heff_field(v_e0_241, 3);
    V v_c_2469 = heff_field(v_e0_241, 5);
    heff_take_n(v_e0_241, 43ULL, 6);
    V v_m_2470 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_rec_2465}));
    V v_x1_2471 = heff_tr(heff_call(v_m_2470, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x1_2471)) {
    case TAG_MkPair: {
      V v_x11_2472 = heff_field(v_x1_2471, 0);
      V v_st_2473 = heff_field(v_x1_2471, 1);
      V v_ru_24x1_2471_24MkPair = heff_take_reuse_n(v_x1_2471, 3ULL, 2);
      switch (heff_tag_of(v_x11_2472)) {
      case TAG_Left: {
        V v_e_2474 = heff_field(v_x11_2472, 0);
        V v_ru_24x11_2472_24Left = heff_take_reuse_n(v_x11_2472, 1ULL, 1);
        heff_drop_rec(v_r_240, 3);
        heff_drop_rec(v_o_2464, 9);
        heff_drop(v_fs_2467);
        heff_drop_rec(v_c_2469, 9);
        return heff_tag_re_n(v_ru_24x1_2471_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x11_2472_24Left, TAG_Left, 1, 1ULL, (V[]){v_e_2474}), v_st_2473});
      }
      case TAG_Right: {
        V v_x_2475 = heff_field(v_x11_2472, 0);
        V v_ru_24x11_2472_24Right = heff_take_reuse_n(v_x11_2472, 1ULL, 1);
        V v_t_24108 = (g_prelude_2etraverse_24s499544530x2060473942(heff_clo_n(g_heff_2esyntax_2esurface_2eexprL_lam2, 1, 1, (V[]){v_r_240}), v_fs_2467));
        V v_x1_24109 = heff_tr(heff_call(v_t_24108, 1, (V[]){v_st_2473}));
        switch (heff_tag_of(v_x1_24109)) {
        case TAG_MkPair: {
          V v_x11_24110 = heff_field(v_x1_24109, 0);
          V v_st_24111 = heff_field(v_x1_24109, 1);
          V v_ru_24x1_24109_24MkPair = heff_take_reuse_n(v_x1_24109, 3ULL, 2);
          switch (heff_tag_of(v_x11_24110)) {
          case TAG_Left: {
            V v_e_24112 = heff_field(v_x11_24110, 0);
            V v_ru_24x11_24110_24Left = heff_take_reuse_n(v_x11_24110, 1ULL, 1);
            heff_drop_rec(v_o_2464, 9);
            heff_drop_rec(v_c_2469, 9);
            heff_drop(v_x_2475);
            heff_drop_cell(v_ru_24x11_2472_24Right, 1);
            heff_drop_cell(v_ru_24x1_24109_24MkPair, 2);
            return heff_tag_at_n(v_ru_24x1_2471_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_re_n(v_ru_24x11_24110_24Left, TAG_Left, 1, 1ULL, (V[]){v_e_24112}), v_st_24111});
          }
          case TAG_Right: {
            V v_x_24113 = heff_field(v_x11_24110, 0);
            heff_take_n(v_x11_24110, 1ULL, 1);
            V v_t_24114 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_o_2464, 3, 9), heff_get_n(v_c_2469, 4, 9)});
            V v_t_24115 = heff_tag_at_n(v_ru_24x1_24109_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_EUpdate, 2, (V[]){v_x_2475, v_x_24113}), v_t_24114});
            return heff_tag_at_n(v_ru_24x1_2471_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_2472_24Right, TAG_Right, 1, (V[]){v_t_24115}), v_st_24111});
          }
          default: return heff_nomatch(v_x11_24110);
          }
        }
        default: return heff_nomatch(v_x1_24109);
        }
      }
      default: return heff_nomatch(v_x11_2472);
      }
    }
    default: return heff_nomatch(v_x1_2471);
    }
  }
  case TAG_InstB: {
    V v_o_24116 = heff_field(v_e0_241, 0);
    V v_d_24118 = heff_field(v_e0_241, 2);
    V v_c_24120 = heff_field(v_e0_241, 4);
    heff_take_n(v_e0_241, 21ULL, 5);
    V v_m_24121 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_d_24118}));
    HEFF_LAST return g_heff_2esyntax_2esurface_2ebind(heff_clo_n(g_heff_2esyntax_2esurface_2eexprL_lam5, 1, 1, (V[]){v_m_24121}), heff_clo_n(g_heff_2esyntax_2esurface_2eexprL_lam6, 2, 2, (V[]){v_o_24116, v_c_24120}), v_z_242);
  }
  case TAG_Sum: {
    V v_kw_24134 = heff_field(v_e0_241, 0);
    V v_alts_24136 = heff_field(v_e0_241, 2);
    V v_c_24138 = heff_field(v_e0_241, 4);
    heff_take_n(v_e0_241, 21ULL, 5);
    V v_m_24140 = (g_prelude_2etraverse_24s499544530x2060473942(heff_clo_n(g_heff_2esyntax_2esurface_2eexprL_lam7, 1, 1, (V[]){v_r_240}), v_alts_24136));
    V v_x1_24141 = heff_tr(heff_call(v_m_24140, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x1_24141)) {
    case TAG_MkPair: {
      V v_x11_24142 = heff_field(v_x1_24141, 0);
      V v_st_24143 = heff_field(v_x1_24141, 1);
      V v_ru_24x1_24141_24MkPair = heff_take_reuse_n(v_x1_24141, 3ULL, 2);
      switch (heff_tag_of(v_x11_24142)) {
      case TAG_Left: {
        V v_e_24144 = heff_field(v_x11_24142, 0);
        V v_ru_24x11_24142_24Left = heff_take_reuse_n(v_x11_24142, 1ULL, 1);
        heff_drop_rec(v_kw_24134, 9);
        heff_drop_rec(v_c_24138, 9);
        return heff_tag_re_n(v_ru_24x1_24141_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x11_24142_24Left, TAG_Left, 1, 1ULL, (V[]){v_e_24144}), v_st_24143});
      }
      case TAG_Right: {
        V v_x_24145 = heff_field(v_x11_24142, 0);
        V v_ru_24x11_24142_24Right = heff_take_reuse_n(v_x11_24142, 1ULL, 1);
        V v_t_24146 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_24134, 3, 9), heff_get_n(v_c_24138, 4, 9)});
        V v_t_24147 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ESum, 1, (V[]){v_x_24145}), v_t_24146});
        return heff_tag_re_n(v_ru_24x1_24141_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_at_n(v_ru_24x11_24142_24Right, TAG_Right, 1, (V[]){v_t_24147}), v_st_24143});
      }
      default: return heff_nomatch(v_x11_24142);
      }
    }
    default: return heff_nomatch(v_x1_24141);
    }
  }
  case TAG_ECon: {
    V v_c_24148 = heff_field(v_e0_241, 0);
    V v_args_24149 = heff_field(v_e0_241, 1);
    heff_take_n(v_e0_241, 3ULL, 2);
    V v_t_24150 = (g_heff_2esyntax_2esurface_2econL(v_r_240, v_c_24148, v_args_24149));
    return heff_tail(v_t_24150, 1, (V[]){v_z_242});
  }
  case TAG_EField: {
    V v_e_24151 = heff_field(v_e0_241, 0);
    V v_f_24152 = heff_field(v_e0_241, 1);
    V v_ru_24e0_241_24EField = heff_take_reuse_n(v_e0_241, 3ULL, 2);
    HeffT2 v_t_24153 = (g_heff_2esyntax_2esurface_2efieldsOf_24cpr(heff_tag_re_n(v_ru_24e0_241_24EField, TAG_EField, 2, 3ULL, (V[]){v_e_24151, v_f_24152}), NTAG(TAG_Nil)));
    {
      V v_field_24154 = v_t_24153.f[0];
      V v_field_24155 = v_t_24153.f[1];
      V v_it1_24156 = v_field_24154;
      V v_fs_24157 = v_field_24155;
      switch (heff_tag_of(v_it1_24156)) {
      case TAG_Atom: {
        V v_t_24158 = heff_field(v_it1_24156, 0);
        V v_ru_24it1_24156_24Atom = heff_take_reuse_n(v_it1_24156, 1ULL, 1);
        heff_drop_rec(v_r_240, 3);
        if (heff_strEq_c(heff_dup(heff_rfield(v_t_24158, 0)), ((V)&g_heff_2esyntax_2esurface_2eexprL_str11))) {
          heff_drop_cell(v_ru_24it1_24156_24Atom, 1);
          HEFF_LAST return g_heff_2esyntax_2esurface_2econAtom(v_t_24158, v_fs_24157, v_z_242);
        } else {
          if (heff_strEq_c(heff_dup(heff_rfield(v_t_24158, 0)), ((V)&g_heff_2esyntax_2esurface_2eexprL_str12))) {
            return (g_heff_2esyntax_2esurface_2ekwAtom_24tok1(v_ru_24it1_24156_24Atom, v_t_24158, v_fs_24157, v_z_242));
          } else {
            if (heff_strEq_c(heff_dup(heff_rfield(v_t_24158, 0)), ((V)&g_heff_2esyntax_2esurface_2eexprL_str13))) {
              return (g_heff_2esyntax_2esurface_2evarAtom_24tok1(v_ru_24it1_24156_24Atom, v_t_24158, v_fs_24157, v_z_242));
            } else {
              V v_e_24159 = (g_heff_2esyntax_2esurface_2eatomTok(v_t_24158));
              V v_t_24160 = (g_list_2emap_24s513201124x806973253(v_fs_24157));
              V v_x_24161 = (g_heff_2esyntax_2epresyntax_2eapp(v_e_24159, v_t_24160));
              return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24it1_24156_24Atom, TAG_Right, 1, (V[]){v_x_24161}), v_z_242});
            }
          }
        }
      }
      default: {
        V v_m_24162 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24156}));
        V v_x1_24163 = heff_tr(heff_call(v_m_24162, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24163)) {
        case TAG_MkPair: {
          V v_x11_24164 = heff_field(v_x1_24163, 0);
          V v_st_24165 = heff_field(v_x1_24163, 1);
          V v_ru_24x1_24163_24MkPair = heff_take_reuse_n(v_x1_24163, 3ULL, 2);
          switch (heff_tag_of(v_x11_24164)) {
          case TAG_Left: {
            V v_e_24166 = heff_field(v_x11_24164, 0);
            V v_ru_24x11_24164_24Left = heff_take_reuse_n(v_x11_24164, 1ULL, 1);
            heff_drop(v_fs_24157);
            return heff_tag_re_n(v_ru_24x1_24163_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x11_24164_24Left, TAG_Left, 1, 1ULL, (V[]){v_e_24166}), v_st_24165});
          }
          case TAG_Right: {
            V v_x_24167 = heff_field(v_x11_24164, 0);
            V v_ru_24x11_24164_24Right = heff_take_reuse_n(v_x11_24164, 1ULL, 1);
            V v_t_24168 = (g_list_2emap_24s513201124x806973253(v_fs_24157));
            V v_x_24169 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24167, v_t_24168));
            return heff_tag_re_n(v_ru_24x1_24163_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_at_n(v_ru_24x11_24164_24Right, TAG_Right, 1, (V[]){v_x_24169}), v_st_24165});
          }
          default: return heff_nomatch(v_x11_24164);
          }
        }
        default: return heff_nomatch(v_x1_24163);
        }
      }
      }
    }
  }
  case TAG_ENeg: {
    V v_m_24170 = heff_field(v_e0_241, 0);
    V v_e_24171 = heff_field(v_e0_241, 1);
    V v_ru_24e0_241_24ENeg = heff_take_reuse_n(v_e0_241, 3ULL, 2);
    V v_start_24172 = heff_take_field(v_m_24170, 3);
    V v_end_24173 = heff_get_n(v_m_24170, 4, 9);
    V v_m_24174 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_24171}));
    V v_x1_24175 = heff_tr(heff_call(v_m_24174, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x1_24175)) {
    case TAG_MkPair: {
      V v_x11_24176 = heff_field(v_x1_24175, 0);
      V v_st_24177 = heff_field(v_x1_24175, 1);
      V v_ru_24x1_24175_24MkPair = heff_take_reuse_n(v_x1_24175, 3ULL, 2);
      switch (heff_tag_of(v_x11_24176)) {
      case TAG_Left: {
        V v_e_24178 = heff_field(v_x11_24176, 0);
        V v_ru_24x11_24176_24Left = heff_take_reuse_n(v_x11_24176, 1ULL, 1);
        heff_drop(v_start_24172);
        heff_drop(v_end_24173);
        heff_drop_cell(v_ru_24x1_24175_24MkPair, 2);
        return heff_tag_at_n(v_ru_24e0_241_24ENeg, TAG_MkPair, 2, (V[]){heff_tag_re_n(v_ru_24x11_24176_24Left, TAG_Left, 1, 1ULL, (V[]){v_e_24178}), v_st_24177});
      }
      case TAG_Right: {
        V v_x_24179 = heff_field(v_x11_24176, 0);
        V v_ru_24x11_24176_24Right = heff_take_reuse_n(v_x11_24176, 1ULL, 1);
        V v_t_24180 = heff_tag_at_n(v_ru_24e0_241_24ENeg, TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2eexprL_str14)}), heff_rec_n(2, shape_start__end, (V[]){v_start_24172, v_end_24173})});
        V v_t_24181 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_24179, NTAG(TAG_Nil)});
        V v_x_24182 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_24180, v_t_24181));
        return heff_tag_re_n(v_ru_24x1_24175_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_at_n(v_ru_24x11_24176_24Right, TAG_Right, 1, (V[]){v_x_24182}), v_st_24177});
      }
      default: return heff_nomatch(v_x11_24176);
      }
    }
    default: return heff_nomatch(v_x1_24175);
    }
  }
  case TAG_ETilde: {
    V v_m_24183 = heff_field(v_e0_241, 0);
    V v_e_24184 = heff_field(v_e0_241, 1);
    V v_ru_24e0_241_24ETilde = heff_take_reuse_n(v_e0_241, 3ULL, 2);
    V v_m_24185 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_e_24184)}));
    V v_x1_24186 = heff_tr(heff_call(v_m_24185, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x1_24186)) {
    case TAG_MkPair: {
      V v_x11_24187 = heff_field(v_x1_24186, 0);
      V v_st_24188 = heff_field(v_x1_24186, 1);
      V v_ru_24x1_24186_24MkPair = heff_take_reuse_n(v_x1_24186, 3ULL, 2);
      switch (heff_tag_of(v_x11_24187)) {
      case TAG_Left: {
        V v_e_24189 = heff_field(v_x11_24187, 0);
        V v_ru_24x11_24187_24Left = heff_take_reuse_n(v_x11_24187, 1ULL, 1);
        heff_drop_rec(v_m_24183, 9);
        heff_drop(v_e_24184);
        heff_drop_cell(v_ru_24x1_24186_24MkPair, 2);
        return heff_tag_at_n(v_ru_24e0_241_24ETilde, TAG_MkPair, 2, (V[]){heff_tag_re_n(v_ru_24x11_24187_24Left, TAG_Left, 1, 1ULL, (V[]){v_e_24189}), v_st_24188});
      }
      case TAG_Right: {
        V v_x_24190 = heff_field(v_x11_24187, 0);
        V v_ru_24x11_24187_24Right = heff_take_reuse_n(v_x11_24187, 1ULL, 1);
        V v_t_24191 = (g_heff_2esyntax_2ecst_2elastE(v_e_24184));
        V v_e_24192 = heff_get_n(v_t_24191, 4, 9);
        V v_t_24193 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_m_24183, 3, 9), v_e_24192});
        V v_x_24194 = heff_tag_at_n(v_ru_24e0_241_24ETilde, TAG_At, 2, (V[]){heff_tag_n(TAG_ELazy, 1, (V[]){v_x_24190}), v_t_24193});
        return heff_tag_re_n(v_ru_24x1_24186_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_at_n(v_ru_24x11_24187_24Right, TAG_Right, 1, (V[]){v_x_24194}), v_st_24188});
      }
      default: return heff_nomatch(v_x11_24187);
      }
    }
    default: return heff_nomatch(v_x1_24186);
    }
  }
  case TAG_App: {
    V v_h_24195 = heff_field(v_e0_241, 0);
    V v_args_24196 = heff_field(v_e0_241, 1);
    V v_ru_24e0_241_24App = heff_take_reuse_n(v_e0_241, 3ULL, 2);
    V v_m_24197 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_h_24195}));
    V v_x1_24198 = heff_tr(heff_call(v_m_24197, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x1_24198)) {
    case TAG_MkPair: {
      V v_x11_24199 = heff_field(v_x1_24198, 0);
      V v_st_24200 = heff_field(v_x1_24198, 1);
      heff_take_n(v_x1_24198, 3ULL, 2);
      switch (heff_tag_of(v_x11_24199)) {
      case TAG_Left: {
        V v_e_24201 = heff_field(v_x11_24199, 0);
        V v_ru_24x11_24199_24Left = heff_take_reuse_n(v_x11_24199, 1ULL, 1);
        heff_drop_rec(v_r_240, 3);
        heff_drop(v_args_24196);
        return heff_tag_at_n(v_ru_24e0_241_24App, TAG_MkPair, 2, (V[]){heff_tag_re_n(v_ru_24x11_24199_24Left, TAG_Left, 1, 1ULL, (V[]){v_e_24201}), v_st_24200});
      }
      case TAG_Right: {
        V v_x_24202 = heff_field(v_x11_24199, 0);
        V v_ru_24x11_24199_24Right = heff_take_reuse_n(v_x11_24199, 1ULL, 1);
        V v_t_24221 = (g_prelude_2etraverse_24s499544530x2060473942(heff_clo_n(g_heff_2esyntax_2esurface_2eexprL_lam8, 1, 1, (V[]){v_r_240}), v_args_24196));
        V v_x1_24222 = heff_tr(heff_call(v_t_24221, 1, (V[]){v_st_24200}));
        switch (heff_tag_of(v_x1_24222)) {
        case TAG_MkPair: {
          V v_x11_24223 = heff_field(v_x1_24222, 0);
          V v_st_24224 = heff_field(v_x1_24222, 1);
          heff_take_n(v_x1_24222, 3ULL, 2);
          switch (heff_tag_of(v_x11_24223)) {
          case TAG_Left: {
            V v_e_24225 = heff_field(v_x11_24223, 0);
            V v_ru_24x11_24223_24Left = heff_take_reuse_n(v_x11_24223, 1ULL, 1);
            heff_drop(v_x_24202);
            heff_drop_cell(v_ru_24x11_24199_24Right, 1);
            return heff_tag_at_n(v_ru_24e0_241_24App, TAG_MkPair, 2, (V[]){heff_tag_re_n(v_ru_24x11_24223_24Left, TAG_Left, 1, 1ULL, (V[]){v_e_24225}), v_st_24224});
          }
          case TAG_Right: {
            V v_x_24226 = heff_field(v_x11_24223, 0);
            heff_take_n(v_x11_24223, 1ULL, 1);
            V v_x_24227 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24202, v_x_24226));
            return heff_tag_at_n(v_ru_24e0_241_24App, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_24199_24Right, TAG_Right, 1, (V[]){v_x_24227}), v_st_24224});
          }
          default: return heff_nomatch(v_x11_24223);
          }
        }
        default: return heff_nomatch(v_x1_24222);
        }
      }
      default: return heff_nomatch(v_x11_24199);
      }
    }
    default: return heff_nomatch(v_x1_24198);
    }
  }
  case TAG_Op: {
    V v_a_24228 = heff_field(v_e0_241, 0);
    V v_op_24229 = heff_field(v_e0_241, 1);
    V v_b_24230 = heff_field(v_e0_241, 2);
    heff_take_n(v_e0_241, 7ULL, 3);
    return (g_heff_2esyntax_2esurface_2eopL(v_r_240, v_a_24228, v_op_24229, v_b_24230, v_z_242));
  }
  case TAG_Ops: {
    V v_a_24231 = heff_field(v_e0_241, 0);
    V v_rest_24232 = heff_field(v_e0_241, 1);
    V v_ru_24e0_241_24Ops = heff_take_reuse_n(v_e0_241, 3ULL, 2);
    V v_m_24233 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_24231}));
    V v_x1_24234 = heff_tr(heff_call(v_m_24233, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x1_24234)) {
    case TAG_MkPair: {
      V v_x11_24235 = heff_field(v_x1_24234, 0);
      V v_st_24236 = heff_field(v_x1_24234, 1);
      V v_ru_24x1_24234_24MkPair = heff_take_reuse_n(v_x1_24234, 3ULL, 2);
      switch (heff_tag_of(v_x11_24235)) {
      case TAG_Left: {
        V v_e_24237 = heff_field(v_x11_24235, 0);
        V v_ru_24x11_24235_24Left = heff_take_reuse_n(v_x11_24235, 1ULL, 1);
        heff_drop_rec(v_r_240, 3);
        heff_drop(v_rest_24232);
        heff_drop_cell(v_ru_24x1_24234_24MkPair, 2);
        return heff_tag_at_n(v_ru_24e0_241_24Ops, TAG_MkPair, 2, (V[]){heff_tag_re_n(v_ru_24x11_24235_24Left, TAG_Left, 1, 1ULL, (V[]){v_e_24237}), v_st_24236});
      }
      case TAG_Right: {
        V v_x_24238 = heff_field(v_x11_24235, 0);
        V v_ru_24x11_24235_24Right = heff_take_reuse_n(v_x11_24235, 1ULL, 1);
        V v_t_24261 = (g_prelude_2etraverse_24s499544530x2060473942(heff_clo_n(g_heff_2esyntax_2esurface_2eexprL_lam10, 1, 1, (V[]){heff_dup(v_r_240)}), heff_dup(v_rest_24232)));
        V v_x1_24262 = heff_tr(heff_call(v_t_24261, 1, (V[]){v_st_24236}));
        switch (heff_tag_of(v_x1_24262)) {
        case TAG_MkPair: {
          V v_x11_24263 = heff_field(v_x1_24262, 0);
          V v_st_24264 = heff_field(v_x1_24262, 1);
          heff_take_n(v_x1_24262, 3ULL, 2);
          switch (heff_tag_of(v_x11_24263)) {
          case TAG_Left: {
            V v_e_24265 = heff_field(v_x11_24263, 0);
            V v_ru_24x11_24263_24Left = heff_take_reuse_n(v_x11_24263, 1ULL, 1);
            heff_drop_rec(v_r_240, 3);
            heff_drop(v_rest_24232);
            heff_drop_cell(v_ru_24x1_24234_24MkPair, 2);
            heff_drop(v_x_24238);
            heff_drop_cell(v_ru_24x11_24235_24Right, 1);
            return heff_tag_at_n(v_ru_24e0_241_24Ops, TAG_MkPair, 2, (V[]){heff_tag_re_n(v_ru_24x11_24263_24Left, TAG_Left, 1, 1ULL, (V[]){v_e_24265}), v_st_24264});
          }
          case TAG_Right: {
            V v_x_24266 = heff_field(v_x11_24263, 0);
            V v_ru_24x11_24263_24Right = heff_take_reuse_n(v_x11_24263, 1ULL, 1);
            V v_t_24295 = (g_prelude_2etraverse_24s499544530x2060473942(heff_clo_n(g_heff_2esyntax_2esurface_2eexprL_lam13, 1, 1, (V[]){v_r_240}), v_rest_24232));
            V v_x1_24296 = heff_tr(heff_call(v_t_24295, 1, (V[]){v_st_24264}));
            switch (heff_tag_of(v_x1_24296)) {
            case TAG_MkPair: {
              V v_x11_24297 = heff_field(v_x1_24296, 0);
              V v_st_24298 = heff_field(v_x1_24296, 1);
              heff_take_n(v_x1_24296, 3ULL, 2);
              switch (heff_tag_of(v_x11_24297)) {
              case TAG_Left: {
                V v_e_24299 = heff_field(v_x11_24297, 0);
                heff_take_n(v_x11_24297, 1ULL, 1);
                heff_drop_cell(v_ru_24x1_24234_24MkPair, 2);
                heff_drop(v_x_24238);
                heff_drop_cell(v_ru_24x11_24235_24Right, 1);
                heff_drop(v_x_24266);
                return heff_tag_at_n(v_ru_24e0_241_24Ops, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_24263_24Right, TAG_Left, 1, (V[]){v_e_24299}), v_st_24298});
              }
              case TAG_Right: {
                V v_x_24300 = heff_field(v_x11_24297, 0);
                heff_take_n(v_x11_24297, 1ULL, 1);
                V v_heads_24301 = ({ V a_0 = v_x_24300; V r_ = (g_heff_2esyntax_2esurface_2econcatMapS_24s1201403852x2138817053(a_0)); heff_drop(v_x_24300); r_; });
                V v_apply_24320 = heff_clo_n(g_heff_2esyntax_2esurface_2eexprL_lam17, 3, 1, (V[]){v_heads_24301});
                V v_e0_24321 = v_x_24238;
                V v_rest_24322 = v_x_24266;
                V v_st_24323 = v_st_24298;
                V v_t_24324 = heff_dup(heff_rfield(v_st_24323, 5));
                V v_t_24325 = heff_dup(heff_rfield(v_st_24323, 6));
                V v_t_24326 = (g_heff_2esyntax_2esurface_2echeckFixOf(v_t_24324, v_t_24325, heff_dup(v_rest_24322)));
                V v_x1_24327 = heff_tr(heff_call(v_t_24326, 1, (V[]){v_st_24323}));
                switch (heff_tag_of(v_x1_24327)) {
                case TAG_MkPair: {
                  V v_x11_24328 = heff_field(v_x1_24327, 0);
                  V v_st_24329 = heff_field(v_x1_24327, 1);
                  heff_take_n(v_x1_24327, 3ULL, 2);
                  switch (heff_tag_of(v_x11_24328)) {
                  case TAG_Left: {
                    V v_e_24330 = heff_field(v_x11_24328, 0);
                    heff_take_n(v_x11_24328, 1ULL, 1);
                    heff_drop_cell(v_ru_24x1_24234_24MkPair, 2);
                    heff_drop_cell(v_ru_24x11_24235_24Right, 1);
                    heff_drop_clo(v_apply_24320, 1);
                    heff_drop(v_e0_24321);
                    heff_drop(v_rest_24322);
                    heff_drop(v_t_24324);
                    heff_drop(v_t_24325);
                    return heff_tag_at_n(v_ru_24e0_241_24Ops, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_24263_24Right, TAG_Left, 1, (V[]){v_e_24330}), v_st_24329});
                  }
                  case TAG_Right: {
                    heff_take_n(v_x11_24328, 0ULL, 1);
                    V v_t_24332 = heff_tag_at_n(v_ru_24e0_241_24Ops, TAG_Cons, 2, (V[]){heff_dup(v_e0_24321), NTAG(TAG_Nil)});
                    V v_t_24333 = heff_rec_n(2, shape_ops__out, (V[]){NTAG(TAG_Nil), v_t_24332});
                    HeffT2 v_t_24334 = ({ V a_0 = v_apply_24320; V a_1 = v_t_24324; V a_2 = v_t_24325; V a_3 = v_t_24333; V a_4 = v_rest_24322; V a_5 = v_st_24329; HeffT2 r_ = (g_heff_2esyntax_2esurface_2epushAll_24cpr(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_t_24324); heff_drop(v_t_24325); heff_drop(v_rest_24322); r_; });
                    {
                      V v_field_24335 = v_t_24334.f[0];
                      V v_field_24336 = v_t_24334.f[1];
                      V v_x11_24337 = v_field_24335;
                      V v_st_24338 = v_field_24336;
                      switch (heff_tag_of(v_x11_24337)) {
                      case TAG_Left: {
                        V v_e_24339 = heff_field(v_x11_24337, 0);
                        heff_take_n(v_x11_24337, 1ULL, 1);
                        heff_drop_cell(v_ru_24x11_24235_24Right, 1);
                        heff_drop_clo(v_apply_24320, 1);
                        heff_drop(v_e0_24321);
                        return heff_tag_at_n(v_ru_24x1_24234_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_24263_24Right, TAG_Left, 1, (V[]){v_e_24339}), v_st_24338});
                      }
                      case TAG_Right: {
                        V v_x_24340 = heff_field(v_x11_24337, 0);
                        heff_take_n(v_x11_24337, 1ULL, 1);
                        heff_drop_cell(v_ru_24x11_24263_24Right, 1);
                        V v_st_24341 = ({ V a_0 = v_apply_24320; V a_1 = v_x_24340; V r_ = (g_heff_2esyntax_2esurface_2ereduceAll(a_0, a_1)); heff_drop_clo(v_apply_24320, 1); r_; });
                        V v_t_24342 = heff_get_n(v_st_24341, 1, 2);
                        V v_t_24345;
                        switch (heff_tag_of(v_t_24342)) {
                        case TAG_Nil: {
                          v_t_24345 = v_e0_24321;
                          break;
                        }
                        case TAG_Cons: {
                          V v_x_24343 = heff_field(v_t_24342, 0);
                          heff_take_n(v_t_24342, 1ULL, 2);
                          heff_drop(v_e0_24321);
                          v_t_24345 = v_x_24343;
                          break;
                        }
                        default: heff_nomatch(v_t_24342);
                        }
                        return heff_tag_at_n(v_ru_24x1_24234_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_24235_24Right, TAG_Right, 1, (V[]){v_t_24345}), v_st_24338});
                      }
                      default: return heff_nomatch(v_x11_24337);
                      }
                    }
                  }
                  default: return heff_nomatch(v_x11_24328);
                  }
                }
                default: return heff_nomatch(v_x1_24327);
                }
              }
              default: return heff_nomatch(v_x11_24297);
              }
            }
            default: return heff_nomatch(v_x1_24296);
            }
          }
          default: return heff_nomatch(v_x11_24263);
          }
        }
        default: return heff_nomatch(v_x1_24262);
        }
      }
      default: return heff_nomatch(v_x11_24235);
      }
    }
    default: return heff_nomatch(v_x1_24234);
    }
  }
  case TAG_Ann: {
    V v_e_24346 = heff_field(v_e0_241, 0);
    V v_ty_24348 = heff_field(v_e0_241, 2);
    heff_take_n(v_e0_241, 5ULL, 3);
    V v_m_24349 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e_24346}));
    V v_x1_24350 = heff_tr(heff_call(v_m_24349, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x1_24350)) {
    case TAG_MkPair: {
      V v_x11_24351 = heff_field(v_x1_24350, 0);
      V v_st_24352 = heff_field(v_x1_24350, 1);
      V v_ru_24x1_24350_24MkPair = heff_take_reuse_n(v_x1_24350, 3ULL, 2);
      switch (heff_tag_of(v_x11_24351)) {
      case TAG_Left: {
        V v_e_24353 = heff_field(v_x11_24351, 0);
        V v_ru_24x11_24351_24Left = heff_take_reuse_n(v_x11_24351, 1ULL, 1);
        heff_drop_rec(v_r_240, 3);
        heff_drop(v_ty_24348);
        return heff_tag_re_n(v_ru_24x1_24350_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x11_24351_24Left, TAG_Left, 1, 1ULL, (V[]){v_e_24353}), v_st_24352});
      }
      case TAG_Right: {
        V v_x_24354 = heff_field(v_x11_24351, 0);
        V v_ru_24x11_24351_24Right = heff_take_reuse_n(v_x11_24351, 1ULL, 1);
        V v_m_24355 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_ty_24348}));
        V v_x1_24356 = heff_tr(heff_call(v_m_24355, 1, (V[]){v_st_24352}));
        switch (heff_tag_of(v_x1_24356)) {
        case TAG_MkPair: {
          V v_x11_24357 = heff_field(v_x1_24356, 0);
          V v_st_24358 = heff_field(v_x1_24356, 1);
          V v_ru_24x1_24356_24MkPair = heff_take_reuse_n(v_x1_24356, 3ULL, 2);
          switch (heff_tag_of(v_x11_24357)) {
          case TAG_Left: {
            V v_e_24359 = heff_field(v_x11_24357, 0);
            V v_ru_24x11_24357_24Left = heff_take_reuse_n(v_x11_24357, 1ULL, 1);
            heff_drop(v_x_24354);
            heff_drop_cell(v_ru_24x11_24351_24Right, 1);
            heff_drop_cell(v_ru_24x1_24356_24MkPair, 2);
            return heff_tag_at_n(v_ru_24x1_24350_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_re_n(v_ru_24x11_24357_24Left, TAG_Left, 1, 1ULL, (V[]){v_e_24359}), v_st_24358});
          }
          case TAG_Right: {
            V v_x_24360 = heff_field(v_x11_24357, 0);
            heff_take_n(v_x11_24357, 1ULL, 1);
            V v_t_24363;
            switch (heff_tag_of(v_x_24354)) {
            case TAG_At: {
              V v_s_24362 = heff_dup(heff_field(v_x_24354, 1));
              v_t_24363 = v_s_24362;
              break;
            }
            default: heff_nomatch(v_x_24354);
            }
            V v_t_24366;
            switch (heff_tag_of(v_x_24360)) {
            case TAG_At: {
              V v_s_24365 = heff_dup(heff_field(v_x_24360, 1));
              v_t_24366 = v_s_24365;
              break;
            }
            default: heff_nomatch(v_x_24360);
            }
            V v_t_24367 = ({ V rv_1 = heff_get_n(v_t_24366, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24363, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
            V v_t_24368 = heff_tag_at_n(v_ru_24x1_24356_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_EAnn, 2, (V[]){v_x_24354, v_x_24360}), v_t_24367});
            return heff_tag_at_n(v_ru_24x1_24350_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_24351_24Right, TAG_Right, 1, (V[]){v_t_24368}), v_st_24358});
          }
          default: return heff_nomatch(v_x11_24357);
          }
        }
        default: return heff_nomatch(v_x1_24356);
        }
      }
      default: return heff_nomatch(v_x11_24351);
      }
    }
    default: return heff_nomatch(v_x1_24350);
    }
  }
  case TAG_Lam: {
    V v_binders_24370 = heff_field(v_e0_241, 1);
    V v_body_24372 = heff_field(v_e0_241, 3);
    heff_take_n(v_e0_241, 10ULL, 4);
    V v_r_24373 = v_r_240;
    V v_binders_24374 = v_binders_24370;
    V v_body_24375 = v_body_24372;
    V v_m_24377 = (g_prelude_2etraverse_24s499544530x2060473942(heff_clo_n(g_heff_2esyntax_2esurface_2eexprL_lam18, 1, 1, (V[]){heff_dup(v_r_24373)}), v_binders_24374));
    V v_x1_24378 = heff_tr(heff_call(v_m_24377, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x1_24378)) {
    case TAG_MkPair: {
      V v_x11_24379 = heff_field(v_x1_24378, 0);
      V v_st_24380 = heff_field(v_x1_24378, 1);
      V v_ru_24x1_24378_24MkPair = heff_take_reuse_n(v_x1_24378, 3ULL, 2);
      switch (heff_tag_of(v_x11_24379)) {
      case TAG_Left: {
        V v_e_24381 = heff_field(v_x11_24379, 0);
        V v_ru_24x11_24379_24Left = heff_take_reuse_n(v_x11_24379, 1ULL, 1);
        heff_drop_rec(v_r_24373, 3);
        heff_drop(v_body_24375);
        return heff_tag_re_n(v_ru_24x1_24378_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x11_24379_24Left, TAG_Left, 1, 1ULL, (V[]){v_e_24381}), v_st_24380});
      }
      case TAG_Right: {
        V v_x_24382 = heff_field(v_x11_24379, 0);
        heff_take_n(v_x11_24379, 1ULL, 1);
        V v_t_24383 = (g_heff_2esyntax_2esurface_2econcatMapS_24s1449391958x677358818(heff_dup(v_x_24382)));
        V v_m_24384 = heff_tr(heff_call(heff_get_n(v_r_24373, 0, 3), 1, (V[]){v_body_24375}));
        return (g_heff_2esyntax_2esurface_2ewithScope_24tok2(v_ru_24x1_24378_24MkPair, v_t_24383, heff_clo_n(g_heff_2esyntax_2esurface_2eexprL_lam19, 1, 2, (V[]){v_m_24384, v_x_24382}), v_st_24380));
      }
      default: return heff_nomatch(v_x11_24379);
      }
    }
    default: return heff_nomatch(v_x1_24378);
    }
  }
  case TAG_Case: {
    V v_kw_24392 = heff_dup(heff_field(v_e0_241, 0));
    V v_scrut_24393 = heff_dup(heff_field(v_e0_241, 1));
    V v_alts_24395 = heff_dup(heff_field(v_e0_241, 3));
    V v_m_24396 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_scrut_24393}));
    V v_x1_24397 = heff_tr(heff_call(v_m_24396, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x1_24397)) {
    case TAG_MkPair: {
      V v_x11_24398 = heff_field(v_x1_24397, 0);
      V v_st_24399 = heff_field(v_x1_24397, 1);
      V v_ru_24x1_24397_24MkPair = heff_take_reuse_n(v_x1_24397, 3ULL, 2);
      switch (heff_tag_of(v_x11_24398)) {
      case TAG_Left: {
        V v_e_24400 = heff_field(v_x11_24398, 0);
        V v_ru_24x11_24398_24Left = heff_take_reuse_n(v_x11_24398, 1ULL, 1);
        heff_drop_rec(v_r_240, 3);
        heff_drop_tag(v_e0_241, 4);
        heff_drop_rec(v_kw_24392, 9);
        heff_drop(v_alts_24395);
        return heff_tag_re_n(v_ru_24x1_24397_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x11_24398_24Left, TAG_Left, 1, 1ULL, (V[]){v_e_24400}), v_st_24399});
      }
      case TAG_Right: {
        V v_x_24401 = heff_field(v_x11_24398, 0);
        heff_take_n(v_x11_24398, 1ULL, 1);
        return (g_heff_2esyntax_2esurface_2ebind_24tok2(v_ru_24x1_24397_24MkPair, heff_clo_n(g_heff_2esyntax_2esurface_2eexprL_lam20, 1, 2, (V[]){v_r_240, v_alts_24395}), heff_clo_n(g_heff_2esyntax_2esurface_2eexprL_lam22, 2, 3, (V[]){v_e0_241, v_kw_24392, v_x_24401}), v_st_24399));
      }
      default: return heff_nomatch(v_x11_24398);
      }
    }
    default: return heff_nomatch(v_x1_24397);
    }
  }
  case TAG_If: {
    V v_kw_24430 = heff_field(v_e0_241, 0);
    V v_c_24431 = heff_field(v_e0_241, 1);
    V v_a_24433 = heff_field(v_e0_241, 3);
    V v_b_24435 = heff_field(v_e0_241, 5);
    heff_take_n(v_e0_241, 43ULL, 6);
    return (g_heff_2esyntax_2esurface_2eifL_24s1615235115x417367760(heff_dup(v_b_24435), v_r_240, v_kw_24430, v_c_24431, v_a_24433, v_b_24435, v_z_242));
  }
  case TAG_Do: {
    V v_kw_24436 = heff_dup(heff_field(v_e0_241, 0));
    V v_stmts_24437 = heff_dup(heff_field(v_e0_241, 1));
    HEFF_LAST return g_heff_2esyntax_2esurface_2ebind(heff_clo_n(g_heff_2esyntax_2esurface_2eexprL_lam23, 1, 2, (V[]){v_r_240, v_stmts_24437}), heff_clo_n(g_heff_2esyntax_2esurface_2eexprL_lam25, 2, 2, (V[]){v_e0_241, v_kw_24436}), v_z_242);
  }
  case TAG_ELet: {
    return ({ V a_0 = v_r_240; V a_1 = v_e0_241; V a_2 = v_z_242; V r_ = (g_heff_2esyntax_2esurface_2eletL(a_0, a_1, a_2)); heff_drop_tag(v_e0_241, 6); r_; });
  }
  case TAG_EAssign: {
    V v_x_24460 = heff_field(v_e0_241, 0);
    V v_e_24462 = heff_field(v_e0_241, 2);
    V v_ru_24e0_241_24EAssign = heff_take_reuse_n(v_e0_241, 5ULL, 3);
    V v_text_24463 = heff_take_field(v_x_24460, 1);
    V v_start_24464 = heff_take_field(v_x_24460, 3);
    V v_end_24465 = heff_get_n(v_x_24460, 4, 9);
    V v_m_24466 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_e_24462)}));
    V v_x1_24467 = heff_tr(heff_call(v_m_24466, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x1_24467)) {
    case TAG_MkPair: {
      V v_x11_24468 = heff_field(v_x1_24467, 0);
      V v_st_24469 = heff_field(v_x1_24467, 1);
      V v_ru_24x1_24467_24MkPair = heff_take_reuse_n(v_x1_24467, 3ULL, 2);
      switch (heff_tag_of(v_x11_24468)) {
      case TAG_Left: {
        V v_e_24470 = heff_field(v_x11_24468, 0);
        V v_ru_24x11_24468_24Left = heff_take_reuse_n(v_x11_24468, 1ULL, 1);
        heff_drop(v_e_24462);
        heff_drop_cell(v_ru_24e0_241_24EAssign, 3);
        heff_drop(v_text_24463);
        heff_drop(v_start_24464);
        heff_drop(v_end_24465);
        return heff_tag_re_n(v_ru_24x1_24467_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x11_24468_24Left, TAG_Left, 1, 1ULL, (V[]){v_e_24470}), v_st_24469});
      }
      case TAG_Right: {
        V v_x_24471 = heff_field(v_x11_24468, 0);
        V v_ru_24x11_24468_24Right = heff_take_reuse_n(v_x11_24468, 1ULL, 1);
        V v_t_24472 = (g_heff_2esyntax_2ecst_2elastE(v_e_24462));
        V v_e_24473 = heff_get_n(v_t_24472, 4, 9);
        V v_t_24474 = heff_tag_at_n(v_ru_24e0_241_24EAssign, TAG_EAssign, 3, (V[]){v_text_24463, heff_rec_n(2, shape_start__end, (V[]){heff_dup(v_start_24464), v_end_24465}), v_x_24471});
        V v_x_24475 = heff_tag_n(TAG_At, 2, (V[]){v_t_24474, heff_rec_n(2, shape_start__end, (V[]){v_start_24464, v_e_24473})});
        return heff_tag_re_n(v_ru_24x1_24467_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_at_n(v_ru_24x11_24468_24Right, TAG_Right, 1, (V[]){v_x_24475}), v_st_24469});
      }
      default: return heff_nomatch(v_x11_24468);
      }
    }
    default: return heff_nomatch(v_x1_24467);
    }
  }
  case TAG_EWhile: {
    V v_kw_24476 = heff_dup(heff_field(v_e0_241, 0));
    V v_c_24477 = heff_dup(heff_field(v_e0_241, 1));
    V v_body_24479 = heff_dup(heff_field(v_e0_241, 3));
    V v_m_24480 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_c_24477}));
    V v_x1_24481 = heff_tr(heff_call(v_m_24480, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x1_24481)) {
    case TAG_MkPair: {
      V v_x11_24482 = heff_field(v_x1_24481, 0);
      V v_st_24483 = heff_field(v_x1_24481, 1);
      V v_ru_24x1_24481_24MkPair = heff_take_reuse_n(v_x1_24481, 3ULL, 2);
      switch (heff_tag_of(v_x11_24482)) {
      case TAG_Left: {
        V v_e_24484 = heff_field(v_x11_24482, 0);
        V v_ru_24x11_24482_24Left = heff_take_reuse_n(v_x11_24482, 1ULL, 1);
        heff_drop_rec(v_r_240, 3);
        heff_drop_tag(v_e0_241, 4);
        heff_drop_rec(v_kw_24476, 9);
        heff_drop(v_body_24479);
        return heff_tag_re_n(v_ru_24x1_24481_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x11_24482_24Left, TAG_Left, 1, 1ULL, (V[]){v_e_24484}), v_st_24483});
      }
      case TAG_Right: {
        V v_x_24485 = heff_field(v_x11_24482, 0);
        heff_take_n(v_x11_24482, 1ULL, 1);
        return (g_heff_2esyntax_2esurface_2ebind_24tok2(v_ru_24x1_24481_24MkPair, heff_clo_n(g_heff_2esyntax_2esurface_2eexprL_lam26, 1, 2, (V[]){v_r_240, v_body_24479}), heff_clo_n(g_heff_2esyntax_2esurface_2eexprL_lam28, 2, 3, (V[]){v_e0_241, v_kw_24476, v_x_24485}), v_st_24483));
      }
      default: return heff_nomatch(v_x11_24482);
      }
    }
    default: return heff_nomatch(v_x1_24481);
    }
  }
  case TAG_EFor: {
    V v_kw_24502 = heff_dup(heff_field(v_e0_241, 0));
    V v_p_24503 = heff_dup(heff_field(v_e0_241, 1));
    V v_c_24505 = heff_dup(heff_field(v_e0_241, 3));
    V v_body_24507 = heff_dup(heff_field(v_e0_241, 5));
    V v_m_24508 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_c_24505}));
    V v_x1_24509 = heff_tr(heff_call(v_m_24508, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x1_24509)) {
    case TAG_MkPair: {
      V v_x11_24510 = heff_field(v_x1_24509, 0);
      V v_st_24511 = heff_field(v_x1_24509, 1);
      V v_ru_24x1_24509_24MkPair = heff_take_reuse_n(v_x1_24509, 3ULL, 2);
      switch (heff_tag_of(v_x11_24510)) {
      case TAG_Left: {
        V v_e_24512 = heff_field(v_x11_24510, 0);
        V v_ru_24x11_24510_24Left = heff_take_reuse_n(v_x11_24510, 1ULL, 1);
        heff_drop_rec(v_r_240, 3);
        heff_drop_tag(v_e0_241, 6);
        heff_drop_rec(v_kw_24502, 9);
        heff_drop(v_p_24503);
        heff_drop(v_body_24507);
        return heff_tag_re_n(v_ru_24x1_24509_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x11_24510_24Left, TAG_Left, 1, 1ULL, (V[]){v_e_24512}), v_st_24511});
      }
      case TAG_Right: {
        V v_x_24513 = heff_field(v_x11_24510, 0);
        V v_ru_24x11_24510_24Right = heff_take_reuse_n(v_x11_24510, 1ULL, 1);
        V v_m_24514 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 1)), 1, (V[]){heff_dup(v_p_24503)}));
        V v_x1_24515 = heff_tr(heff_call(v_m_24514, 1, (V[]){v_st_24511}));
        switch (heff_tag_of(v_x1_24515)) {
        case TAG_MkPair: {
          V v_x11_24516 = heff_field(v_x1_24515, 0);
          V v_st_24517 = heff_field(v_x1_24515, 1);
          V v_ru_24x1_24515_24MkPair = heff_take_reuse_n(v_x1_24515, 3ULL, 2);
          switch (heff_tag_of(v_x11_24516)) {
          case TAG_Left: {
            V v_e_24518 = heff_field(v_x11_24516, 0);
            V v_ru_24x11_24516_24Left = heff_take_reuse_n(v_x11_24516, 1ULL, 1);
            heff_drop_rec(v_r_240, 3);
            heff_drop_tag(v_e0_241, 6);
            heff_drop_rec(v_kw_24502, 9);
            heff_drop(v_p_24503);
            heff_drop(v_body_24507);
            heff_drop(v_x_24513);
            heff_drop_cell(v_ru_24x11_24510_24Right, 1);
            heff_drop_cell(v_ru_24x1_24515_24MkPair, 2);
            return heff_tag_at_n(v_ru_24x1_24509_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_re_n(v_ru_24x11_24516_24Left, TAG_Left, 1, 1ULL, (V[]){v_e_24518}), v_st_24517});
          }
          case TAG_Right: {
            V v_x_24519 = heff_field(v_x11_24516, 0);
            V v_ru_24x11_24516_24Right = heff_take_reuse_n(v_x11_24516, 1ULL, 1);
            V v_t_24520 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_p_24503; V r_ = (g_heff_2esyntax_2esurface_2eboundBy(a_0, a_1)); heff_drop(v_p_24503); r_; });
            HeffT2 v_t_24531 = (g_heff_2esyntax_2esurface_2ewithScope_24cpr(v_t_24520, heff_clo_n(g_heff_2esyntax_2esurface_2eexprL_lam29, 1, 2, (V[]){v_r_240, v_body_24507}), v_st_24517));
            {
              V v_field_24532 = v_t_24531.f[0];
              V v_field_24533 = v_t_24531.f[1];
              V v_x11_24534 = v_field_24532;
              V v_st_24535 = v_field_24533;
              switch (heff_tag_of(v_x11_24534)) {
              case TAG_Left: {
                V v_e_24536 = heff_field(v_x11_24534, 0);
                heff_take_n(v_x11_24534, 1ULL, 1);
                heff_drop_tag(v_e0_241, 6);
                heff_drop_rec(v_kw_24502, 9);
                heff_drop(v_x_24513);
                heff_drop_cell(v_ru_24x11_24510_24Right, 1);
                heff_drop_cell(v_ru_24x1_24515_24MkPair, 2);
                heff_drop(v_x_24519);
                return heff_tag_at_n(v_ru_24x1_24509_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_24516_24Right, TAG_Left, 1, (V[]){v_e_24536}), v_st_24535});
              }
              case TAG_Right: {
                V v_x_24537 = heff_field(v_x11_24534, 0);
                heff_take_n(v_x11_24534, 1ULL, 1);
                heff_drop_cell(v_ru_24x11_24516_24Right, 1);
                V v_t_24538 = (g_heff_2esyntax_2ecst_2elastE(v_e0_241));
                V v_e_24539 = heff_get_n(v_t_24538, 4, 9);
                V v_t_24540 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_24502, 3, 9), v_e_24539});
                V v_x_24541 = heff_tag_at_n(v_ru_24x1_24515_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_EFor, 3, (V[]){v_x_24519, v_x_24513, v_x_24537}), v_t_24540});
                return heff_tag_at_n(v_ru_24x1_24509_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_24510_24Right, TAG_Right, 1, (V[]){v_x_24541}), v_st_24535});
              }
              default: return heff_nomatch(v_x11_24534);
              }
            }
          }
          default: return heff_nomatch(v_x11_24516);
          }
        }
        default: return heff_nomatch(v_x1_24515);
        }
      }
      default: return heff_nomatch(v_x11_24510);
      }
    }
    default: return heff_nomatch(v_x1_24509);
    }
  }
  case TAG_EJump: {
    V v_kw_24542 = heff_field(v_e0_241, 0);
    V v_ru_24e0_241_24EJump = heff_take_reuse_n(v_e0_241, 1ULL, 1);
    heff_drop_rec(v_r_240, 3);
    V v_text_24543 = heff_take_field(v_kw_24542, 1);
    V v_start_24544 = heff_take_field(v_kw_24542, 3);
    V v_end_24545 = heff_get_n(v_kw_24542, 4, 9);
    V v_t_24546;
    if (heff_strEq_c(v_text_24543, ((V)&g_heff_2esyntax_2esurface_2eexprL_str23))) {
      v_t_24546 = NTAG(TAG_EBreak);
    } else {
      v_t_24546 = NTAG(TAG_EContinue);
    }
    V v_t_24547 = heff_tag_n(TAG_At, 2, (V[]){v_t_24546, heff_rec_n(2, shape_start__end, (V[]){v_start_24544, v_end_24545})});
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24e0_241_24EJump, TAG_Right, 1, (V[]){v_t_24547}), v_z_242});
  }
  case TAG_EReturn: {
    V v_kw_24548 = heff_field(v_e0_241, 0);
    V v_e_24549 = heff_field(v_e0_241, 1);
    V v_ru_24e0_241_24EReturn = heff_take_reuse_n(v_e0_241, 3ULL, 2);
    V v_m_24550 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_e_24549)}));
    V v_x1_24551 = heff_tr(heff_call(v_m_24550, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x1_24551)) {
    case TAG_MkPair: {
      V v_x11_24552 = heff_field(v_x1_24551, 0);
      V v_st_24553 = heff_field(v_x1_24551, 1);
      V v_ru_24x1_24551_24MkPair = heff_take_reuse_n(v_x1_24551, 3ULL, 2);
      switch (heff_tag_of(v_x11_24552)) {
      case TAG_Left: {
        V v_e_24554 = heff_field(v_x11_24552, 0);
        V v_ru_24x11_24552_24Left = heff_take_reuse_n(v_x11_24552, 1ULL, 1);
        heff_drop_rec(v_kw_24548, 9);
        heff_drop(v_e_24549);
        heff_drop_cell(v_ru_24x1_24551_24MkPair, 2);
        return heff_tag_at_n(v_ru_24e0_241_24EReturn, TAG_MkPair, 2, (V[]){heff_tag_re_n(v_ru_24x11_24552_24Left, TAG_Left, 1, 1ULL, (V[]){v_e_24554}), v_st_24553});
      }
      case TAG_Right: {
        V v_x_24555 = heff_field(v_x11_24552, 0);
        V v_ru_24x11_24552_24Right = heff_take_reuse_n(v_x11_24552, 1ULL, 1);
        V v_t_24556 = (g_heff_2esyntax_2ecst_2elastE(v_e_24549));
        V v_e_24557 = heff_get_n(v_t_24556, 4, 9);
        V v_t_24558 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_24548, 3, 9), v_e_24557});
        V v_x_24559 = heff_tag_at_n(v_ru_24e0_241_24EReturn, TAG_At, 2, (V[]){heff_tag_n(TAG_EReturn, 1, (V[]){v_x_24555}), v_t_24558});
        return heff_tag_re_n(v_ru_24x1_24551_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_at_n(v_ru_24x11_24552_24Right, TAG_Right, 1, (V[]){v_x_24559}), v_st_24553});
      }
      default: return heff_nomatch(v_x11_24552);
      }
    }
    default: return heff_nomatch(v_x1_24551);
    }
  }
  case TAG_ENest: {
    V v_o_24560 = heff_field(v_e0_241, 0);
    V v_e_24562 = heff_field(v_e0_241, 2);
    V v_c_24563 = heff_field(v_e0_241, 3);
    heff_take_n(v_e0_241, 13ULL, 4);
    V v_m_24564 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_24562}));
    V v_x1_24565 = heff_tr(heff_call(v_m_24564, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x1_24565)) {
    case TAG_MkPair: {
      V v_x11_24566 = heff_field(v_x1_24565, 0);
      V v_st_24567 = heff_field(v_x1_24565, 1);
      V v_ru_24x1_24565_24MkPair = heff_take_reuse_n(v_x1_24565, 3ULL, 2);
      switch (heff_tag_of(v_x11_24566)) {
      case TAG_Left: {
        V v_e_24568 = heff_field(v_x11_24566, 0);
        V v_ru_24x11_24566_24Left = heff_take_reuse_n(v_x11_24566, 1ULL, 1);
        heff_drop_rec(v_o_24560, 9);
        heff_drop_rec(v_c_24563, 9);
        return heff_tag_re_n(v_ru_24x1_24565_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x11_24566_24Left, TAG_Left, 1, 1ULL, (V[]){v_e_24568}), v_st_24567});
      }
      case TAG_Right: {
        V v_x_24569 = heff_field(v_x11_24566, 0);
        V v_ru_24x11_24566_24Right = heff_take_reuse_n(v_x11_24566, 1ULL, 1);
        V v_t_24570 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_o_24560, 3, 9), heff_get_n(v_c_24563, 4, 9)});
        V v_t_24571 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ENest, 1, (V[]){v_x_24569}), v_t_24570});
        return heff_tag_re_n(v_ru_24x1_24565_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_at_n(v_ru_24x11_24566_24Right, TAG_Right, 1, (V[]){v_t_24571}), v_st_24567});
      }
      default: return heff_nomatch(v_x11_24566);
      }
    }
    default: return heff_nomatch(v_x1_24565);
    }
  }
  case TAG_EArrow: {
    V v_arrow_24572 = heff_field(v_e0_241, 0);
    V v_e_24573 = heff_field(v_e0_241, 1);
    V v_ru_24e0_241_24EArrow = heff_take_reuse_n(v_e0_241, 3ULL, 2);
    V v_m_24574 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_e_24573)}));
    V v_x1_24575 = heff_tr(heff_call(v_m_24574, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x1_24575)) {
    case TAG_MkPair: {
      V v_x11_24576 = heff_field(v_x1_24575, 0);
      V v_st_24577 = heff_field(v_x1_24575, 1);
      V v_ru_24x1_24575_24MkPair = heff_take_reuse_n(v_x1_24575, 3ULL, 2);
      switch (heff_tag_of(v_x11_24576)) {
      case TAG_Left: {
        V v_e_24578 = heff_field(v_x11_24576, 0);
        V v_ru_24x11_24576_24Left = heff_take_reuse_n(v_x11_24576, 1ULL, 1);
        heff_drop_rec(v_arrow_24572, 9);
        heff_drop(v_e_24573);
        heff_drop_cell(v_ru_24x1_24575_24MkPair, 2);
        return heff_tag_at_n(v_ru_24e0_241_24EArrow, TAG_MkPair, 2, (V[]){heff_tag_re_n(v_ru_24x11_24576_24Left, TAG_Left, 1, 1ULL, (V[]){v_e_24578}), v_st_24577});
      }
      case TAG_Right: {
        V v_x_24579 = heff_field(v_x11_24576, 0);
        V v_ru_24x11_24576_24Right = heff_take_reuse_n(v_x11_24576, 1ULL, 1);
        V v_t_24580 = (g_heff_2esyntax_2ecst_2elastE(v_e_24573));
        V v_e_24581 = heff_get_n(v_t_24580, 4, 9);
        V v_t_24582 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_arrow_24572, 3, 9), v_e_24581});
        V v_x_24583 = heff_tag_at_n(v_ru_24e0_241_24EArrow, TAG_At, 2, (V[]){heff_tag_n(TAG_ENest, 1, (V[]){v_x_24579}), v_t_24582});
        return heff_tag_re_n(v_ru_24x1_24575_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_at_n(v_ru_24x11_24576_24Right, TAG_Right, 1, (V[]){v_x_24583}), v_st_24577});
      }
      default: return heff_nomatch(v_x11_24576);
      }
    }
    default: return heff_nomatch(v_x1_24575);
    }
  }
  case TAG_IfThen: {
    V v_kw_24584 = heff_field(v_e0_241, 0);
    V v_c_24585 = heff_field(v_e0_241, 1);
    V v_a_24587 = heff_field(v_e0_241, 3);
    heff_take_n(v_e0_241, 11ULL, 4);
    return (g_heff_2esyntax_2esurface_2eifL(v_r_240, v_kw_24584, v_c_24585, heff_dup(v_a_24587), NTAG(TAG_Nothing), v_a_24587, v_z_242));
  }
  case TAG_ETry: {
    V v_kw_24588 = heff_dup(heff_field(v_e0_241, 0));
    V v_ty_24589 = heff_dup(heff_field(v_e0_241, 1));
    V v_body_24590 = heff_dup(heff_field(v_e0_241, 2));
    V v_c_24591 = heff_dup(heff_field(v_e0_241, 3));
    V v_r_24592 = heff_dup(v_r_240);
    V v_x2_24593 = v_ty_24589;
    V v_m_24622;
    switch (heff_tag_of(v_x2_24593)) {
    case TAG_Nothing: {
      heff_drop_rec(v_r_24592, 3);
      v_m_24622 = ((V)&g_heff_2esyntax_2esurface_2eexprL_lam31_clo);
      break;
    }
    case TAG_Just: {
      V v_x21_24596 = heff_field(v_x2_24593, 0);
      V v_ru_24x2_24593_24Just = heff_take_reuse_n(v_x2_24593, 1ULL, 1);
      switch (heff_tag_of(v_x21_24596)) {
      case TAG_Named: {
        V v_x_24598 = heff_field(v_x21_24596, 1);
        V v_e_24600 = heff_field(v_x21_24596, 3);
        heff_take_n(v_x21_24596, 10ULL, 5);
        heff_drop_cell(v_ru_24x2_24593_24Just, 1);
        V v_text_24602 = heff_take_field(v_x_24598, 1);
        V v_start_24603 = heff_take_field(v_x_24598, 3);
        V v_end_24604 = heff_get_n(v_x_24598, 4, 9);
        if (heff_strEq_c(v_text_24602, ((V)&g_heff_2esyntax_2esurface_2eexprL_str24))) {
          heff_drop(v_start_24603);
          heff_drop(v_end_24604);
          V v_m_24605 = heff_tr(heff_call(heff_get_n(v_r_24592, 0, 3), 1, (V[]){v_e_24600}));
          v_m_24622 = heff_clo_n(g_heff_2esyntax_2esurface_2eexprL_lam32, 1, 1, (V[]){v_m_24605});
        } else {
          heff_drop_rec(v_r_24592, 3);
          heff_drop(v_e_24600);
          v_m_24622 = heff_clo_n(g_heff_2esyntax_2esurface_2eexprL_lam33, 1, 2, (V[]){v_start_24603, v_end_24604});
        }
        break;
      }
      default: {
        heff_drop_rec(v_r_24592, 3);
        V v_t_24616 = ({ V a_0 = v_x21_24596; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop(v_x21_24596); r_; });
        V v_start_24617 = heff_take_field(v_t_24616, 3);
        V v_end_24618 = heff_get_n(v_t_24616, 4, 9);
        V v_t_24619 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2eexprL_str26)}), heff_rec_n(2, shape_start__end, (V[]){v_start_24617, v_end_24618})});
        V v_x_24620 = heff_tag_at_n(v_ru_24x2_24593_24Just, TAG_Just, 1, (V[]){v_t_24619});
        v_m_24622 = heff_clo_n(g_heff_2esyntax_2esurface_2eexprL_lam34, 1, 1, (V[]){v_x_24620});
        break;
      }
      }
      break;
    }
    default: heff_nomatch(v_x2_24593);
    }
    V v_x1_24623 = heff_tr(heff_call(v_m_24622, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x1_24623)) {
    case TAG_MkPair: {
      V v_x11_24624 = heff_field(v_x1_24623, 0);
      V v_st_24625 = heff_field(v_x1_24623, 1);
      V v_ru_24x1_24623_24MkPair = heff_take_reuse_n(v_x1_24623, 3ULL, 2);
      switch (heff_tag_of(v_x11_24624)) {
      case TAG_Left: {
        V v_e_24626 = heff_field(v_x11_24624, 0);
        V v_ru_24x11_24624_24Left = heff_take_reuse_n(v_x11_24624, 1ULL, 1);
        heff_drop_rec(v_r_240, 3);
        heff_drop_tag(v_e0_241, 4);
        heff_drop_rec(v_kw_24588, 9);
        heff_drop(v_body_24590);
        heff_drop(v_c_24591);
        return heff_tag_re_n(v_ru_24x1_24623_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x11_24624_24Left, TAG_Left, 1, 1ULL, (V[]){v_e_24626}), v_st_24625});
      }
      case TAG_Right: {
        V v_x_24627 = heff_field(v_x11_24624, 0);
        heff_take_n(v_x11_24624, 1ULL, 1);
        return (g_heff_2esyntax_2esurface_2ebind_24tok2(v_ru_24x1_24623_24MkPair, heff_clo_n(g_heff_2esyntax_2esurface_2eexprL_lam35, 1, 2, (V[]){heff_dup(v_r_240), v_body_24590}), heff_clo_n(g_heff_2esyntax_2esurface_2eexprL_lam37, 2, 5, (V[]){v_r_240, v_c_24591, v_e0_241, v_x_24627, v_kw_24588}), v_st_24625));
      }
      default: return heff_nomatch(v_x11_24624);
      }
    }
    default: return heff_nomatch(v_x1_24623);
    }
  }
  case TAG_EWith: {
    V v_kw_24651 = heff_dup(heff_field(v_e0_241, 0));
    V v_e_24652 = heff_dup(heff_field(v_e0_241, 1));
    V v_e04_24654 = heff_dup(heff_field(v_e0_241, 3));
    V v_body_24656 = heff_dup(heff_field(v_e0_241, 5));
    switch (heff_tag_of(v_e04_24654)) {
    case TAG_PAtom: {
      V v_x_24657 = heff_field(v_e04_24654, 0);
      V v_ru_24e04_24654_24PAtom = heff_take_reuse_n(v_e04_24654, 1ULL, 1);
      V v_text_24658 = heff_take_field(v_x_24657, 1);
      V v_start_24659 = heff_take_field(v_x_24657, 3);
      V v_end_24660 = heff_get_n(v_x_24657, 4, 9);
      V v_m_24661 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e_24652}));
      V v_x1_24662 = heff_tr(heff_call(v_m_24661, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_24662)) {
      case TAG_MkPair: {
        V v_x11_24663 = heff_field(v_x1_24662, 0);
        V v_st_24664 = heff_field(v_x1_24662, 1);
        V v_ru_24x1_24662_24MkPair = heff_take_reuse_n(v_x1_24662, 3ULL, 2);
        switch (heff_tag_of(v_x11_24663)) {
        case TAG_Left: {
          V v_e_24665 = heff_field(v_x11_24663, 0);
          heff_take_n(v_x11_24663, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_tag(v_e0_241, 6);
          heff_drop_rec(v_kw_24651, 9);
          heff_drop(v_body_24656);
          heff_drop(v_text_24658);
          heff_drop(v_start_24659);
          heff_drop(v_end_24660);
          return heff_tag_re_n(v_ru_24x1_24662_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_at_n(v_ru_24e04_24654_24PAtom, TAG_Left, 1, (V[]){v_e_24665}), v_st_24664});
        }
        case TAG_Right: {
          V v_x_24666 = heff_field(v_x11_24663, 0);
          heff_take_n(v_x11_24663, 1ULL, 1);
          V v_t_24667 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_text_24658), NTAG(TAG_Nil)});
          HeffT2 v_t_24678 = (g_heff_2esyntax_2esurface_2ewithScope_24cpr(v_t_24667, heff_clo_n(g_heff_2esyntax_2esurface_2eexprL_lam38, 1, 2, (V[]){v_r_240, v_body_24656}), v_st_24664));
          {
            V v_field_24679 = v_t_24678.f[0];
            V v_field_24680 = v_t_24678.f[1];
            V v_x11_24681 = v_field_24679;
            V v_st_24682 = v_field_24680;
            switch (heff_tag_of(v_x11_24681)) {
            case TAG_Left: {
              V v_e_24683 = heff_field(v_x11_24681, 0);
              heff_take_n(v_x11_24681, 1ULL, 1);
              heff_drop_tag(v_e0_241, 6);
              heff_drop_rec(v_kw_24651, 9);
              heff_drop(v_text_24658);
              heff_drop(v_start_24659);
              heff_drop(v_end_24660);
              heff_drop(v_x_24666);
              return heff_tag_at_n(v_ru_24x1_24662_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24e04_24654_24PAtom, TAG_Left, 1, (V[]){v_e_24683}), v_st_24682});
            }
            case TAG_Right: {
              V v_x_24684 = heff_field(v_x11_24681, 0);
              heff_take_n(v_x11_24681, 1ULL, 1);
              V v_t_24685 = (g_heff_2esyntax_2ecst_2elastE(v_e0_241));
              V v_e_24686 = heff_get_n(v_t_24685, 4, 9);
              V v_t_24687 = heff_tag_n(TAG_EWith, 4, (V[]){v_x_24666, v_text_24658, heff_rec_n(2, shape_start__end, (V[]){v_start_24659, v_end_24660}), v_x_24684});
              V v_t_24688 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_24651, 3, 9), v_e_24686});
              V v_x_24689 = heff_tag_n(TAG_At, 2, (V[]){v_t_24687, v_t_24688});
              return heff_tag_at_n(v_ru_24x1_24662_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24e04_24654_24PAtom, TAG_Right, 1, (V[]){v_x_24689}), v_st_24682});
            }
            default: return heff_nomatch(v_x11_24681);
            }
          }
        }
        default: return heff_nomatch(v_x11_24663);
        }
      }
      default: return heff_nomatch(v_x1_24662);
      }
    }
    default: {
      V v_m_24690 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e_24652}));
      V v_x1_24691 = heff_tr(heff_call(v_m_24690, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_24691)) {
      case TAG_MkPair: {
        V v_x11_24692 = heff_field(v_x1_24691, 0);
        V v_st_24693 = heff_field(v_x1_24691, 1);
        V v_ru_24x1_24691_24MkPair = heff_take_reuse_n(v_x1_24691, 3ULL, 2);
        switch (heff_tag_of(v_x11_24692)) {
        case TAG_Left: {
          V v_e_24694 = heff_field(v_x11_24692, 0);
          V v_ru_24x11_24692_24Left = heff_take_reuse_n(v_x11_24692, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_tag(v_e0_241, 6);
          heff_drop_rec(v_kw_24651, 9);
          heff_drop(v_e04_24654);
          heff_drop(v_body_24656);
          return heff_tag_re_n(v_ru_24x1_24691_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x11_24692_24Left, TAG_Left, 1, 1ULL, (V[]){v_e_24694}), v_st_24693});
        }
        case TAG_Right: {
          V v_x_24695 = heff_field(v_x11_24692, 0);
          V v_ru_24x11_24692_24Right = heff_take_reuse_n(v_x11_24692, 1ULL, 1);
          V v_m_24696 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 1)), 1, (V[]){heff_dup(v_e04_24654)}));
          V v_x1_24697 = heff_tr(heff_call(v_m_24696, 1, (V[]){v_st_24693}));
          switch (heff_tag_of(v_x1_24697)) {
          case TAG_MkPair: {
            V v_x11_24698 = heff_field(v_x1_24697, 0);
            V v_st_24699 = heff_field(v_x1_24697, 1);
            V v_ru_24x1_24697_24MkPair = heff_take_reuse_n(v_x1_24697, 3ULL, 2);
            switch (heff_tag_of(v_x11_24698)) {
            case TAG_Left: {
              V v_e_24700 = heff_field(v_x11_24698, 0);
              V v_ru_24x11_24698_24Left = heff_take_reuse_n(v_x11_24698, 1ULL, 1);
              heff_drop_rec(v_r_240, 3);
              heff_drop_tag(v_e0_241, 6);
              heff_drop_rec(v_kw_24651, 9);
              heff_drop(v_e04_24654);
              heff_drop(v_body_24656);
              heff_drop(v_x_24695);
              heff_drop_cell(v_ru_24x11_24692_24Right, 1);
              heff_drop_cell(v_ru_24x1_24697_24MkPair, 2);
              return heff_tag_at_n(v_ru_24x1_24691_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_re_n(v_ru_24x11_24698_24Left, TAG_Left, 1, 1ULL, (V[]){v_e_24700}), v_st_24699});
            }
            case TAG_Right: {
              V v_x_24701 = heff_field(v_x11_24698, 0);
              V v_ru_24x11_24698_24Right = heff_take_reuse_n(v_x11_24698, 1ULL, 1);
              V v_t_24702 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_e04_24654; V r_ = (g_heff_2esyntax_2esurface_2eboundBy(a_0, a_1)); heff_drop(v_e04_24654); r_; });
              HeffT2 v_t_24713 = (g_heff_2esyntax_2esurface_2ewithScope_24cpr(v_t_24702, heff_clo_n(g_heff_2esyntax_2esurface_2eexprL_lam40, 1, 2, (V[]){v_r_240, v_body_24656}), v_st_24699));
              {
                V v_field_24714 = v_t_24713.f[0];
                V v_field_24715 = v_t_24713.f[1];
                V v_x11_24716 = v_field_24714;
                V v_st_24717 = v_field_24715;
                switch (heff_tag_of(v_x11_24716)) {
                case TAG_Left: {
                  V v_e_24718 = heff_field(v_x11_24716, 0);
                  heff_take_n(v_x11_24716, 1ULL, 1);
                  heff_drop_tag(v_e0_241, 6);
                  heff_drop_rec(v_kw_24651, 9);
                  heff_drop(v_x_24695);
                  heff_drop_cell(v_ru_24x11_24692_24Right, 1);
                  heff_drop_cell(v_ru_24x1_24697_24MkPair, 2);
                  heff_drop(v_x_24701);
                  return heff_tag_at_n(v_ru_24x1_24691_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_24698_24Right, TAG_Left, 1, (V[]){v_e_24718}), v_st_24717});
                }
                case TAG_Right: {
                  V v_x_24719 = heff_field(v_x11_24716, 0);
                  heff_take_n(v_x11_24716, 1ULL, 1);
                  V v_t_24722;
                  switch (heff_tag_of(v_x_24701)) {
                  case TAG_At: {
                    V v_s_24721 = heff_dup(heff_field(v_x_24701, 1));
                    v_t_24722 = v_s_24721;
                    break;
                  }
                  default: heff_nomatch(v_x_24701);
                  }
                  V v_t_24725;
                  switch (heff_tag_of(v_x_24701)) {
                  case TAG_At: {
                    V v_s_24724 = heff_dup(heff_field(v_x_24701, 1));
                    v_t_24725 = v_s_24724;
                    break;
                  }
                  default: heff_nomatch(v_x_24701);
                  }
                  V v_t_24728;
                  switch (heff_tag_of(v_x_24701)) {
                  case TAG_At: {
                    V v_s_24727 = heff_dup(heff_field(v_x_24701, 1));
                    v_t_24728 = v_s_24727;
                    break;
                  }
                  default: heff_nomatch(v_x_24701);
                  }
                  V v_t_24729 = (g_heff_2esyntax_2ecst_2elastE(v_e0_241));
                  V v_e_24730 = heff_get_n(v_t_24729, 4, 9);
                  V v_t_24731 = heff_tag_at_n(v_ru_24x1_24697_24MkPair, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24698_24Right, TAG_EVar, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2eexprL_str27)}), v_t_24725});
                  V v_t_24732 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_StmtLet, 2, (V[]){v_x_24701, v_t_24731}), v_t_24728});
                  V v_t_24733 = heff_tag_n(TAG_EWith, 4, (V[]){v_x_24695, ((V)&g_heff_2esyntax_2esurface_2eexprL_str28), v_t_24722, heff_tag_n(TAG_Cons, 2, (V[]){v_t_24732, v_x_24719})});
                  V v_t_24734 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_24651, 3, 9), v_e_24730});
                  V v_x_24735 = heff_tag_n(TAG_At, 2, (V[]){v_t_24733, v_t_24734});
                  return heff_tag_at_n(v_ru_24x1_24691_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_24692_24Right, TAG_Right, 1, (V[]){v_x_24735}), v_st_24717});
                }
                default: return heff_nomatch(v_x11_24716);
                }
              }
            }
            default: return heff_nomatch(v_x11_24698);
            }
          }
          default: return heff_nomatch(v_x1_24697);
          }
        }
        default: return heff_nomatch(v_x11_24692);
        }
      }
      default: return heff_nomatch(v_x1_24691);
      }
    }
    }
  }
  case TAG_EWithBound: {
    V v_kw_24736 = heff_dup(heff_field(v_e0_241, 0));
    V v_bs_24737 = heff_dup(heff_field(v_e0_241, 1));
    V v_w_24738 = heff_dup(heff_field(v_e0_241, 2));
    V v_body_24740 = heff_dup(heff_field(v_e0_241, 4));
    V v_m_24742 = (g_prelude_2etraverse_24s499544530x2060473942(heff_clo_n(g_heff_2esyntax_2esurface_2eexprL_lam42, 1, 1, (V[]){heff_dup(v_r_240)}), v_bs_24737));
    V v_x1_24743 = heff_tr(heff_call(v_m_24742, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x1_24743)) {
    case TAG_MkPair: {
      V v_x11_24744 = heff_field(v_x1_24743, 0);
      V v_st_24745 = heff_field(v_x1_24743, 1);
      V v_ru_24x1_24743_24MkPair = heff_take_reuse_n(v_x1_24743, 3ULL, 2);
      switch (heff_tag_of(v_x11_24744)) {
      case TAG_Left: {
        V v_e_24746 = heff_field(v_x11_24744, 0);
        V v_ru_24x11_24744_24Left = heff_take_reuse_n(v_x11_24744, 1ULL, 1);
        heff_drop_rec(v_r_240, 3);
        heff_drop_tag(v_e0_241, 5);
        heff_drop_rec(v_kw_24736, 9);
        heff_drop(v_w_24738);
        heff_drop(v_body_24740);
        return heff_tag_re_n(v_ru_24x1_24743_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x11_24744_24Left, TAG_Left, 1, 1ULL, (V[]){v_e_24746}), v_st_24745});
      }
      case TAG_Right: {
        V v_x_24747 = heff_field(v_x11_24744, 0);
        V v_ru_24x11_24744_24Right = heff_take_reuse_n(v_x11_24744, 1ULL, 1);
        V v_t_24748 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_x_24747)));
        V v_names_24749 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_24748; V r_ = (g_list_2efoldl_24s1617583276x303680691(a_0, a_1)); heff_drop(v_t_24748); r_; });
        V v_r_24750 = heff_dup(v_r_240);
        V v_x2_24751 = v_w_24738;
        V v_t_24765;
        switch (heff_tag_of(v_x2_24751)) {
        case TAG_Nothing: {
          heff_drop_rec(v_r_24750, 3);
          v_t_24765 = ((V)&g_heff_2esyntax_2esurface_2eexprL_lam43_clo);
          break;
        }
        case TAG_Just: {
          V v_x21_24754 = heff_field(v_x2_24751, 0);
          heff_take_n(v_x2_24751, 1ULL, 1);
          switch (heff_tag_of(v_x21_24754)) {
          case TAG_MkPair: {
            V v_c_24756 = heff_field(v_x21_24754, 1);
            heff_take_n(v_x21_24754, 2ULL, 2);
            V v_m_24757 = heff_tr(heff_call(heff_get_n(v_r_24750, 0, 3), 1, (V[]){v_c_24756}));
            v_t_24765 = heff_clo_n(g_heff_2esyntax_2esurface_2eexprL_lam44, 1, 1, (V[]){v_m_24757});
            break;
          }
          default: heff_nomatch(v_x21_24754);
          }
          break;
        }
        default: heff_nomatch(v_x2_24751);
        }
        HeffT2 v_t_24766 = (g_heff_2esyntax_2esurface_2ewithScope_24cpr(heff_dup(v_names_24749), v_t_24765, v_st_24745));
        {
          V v_field_24767 = v_t_24766.f[0];
          V v_field_24768 = v_t_24766.f[1];
          V v_x11_24769 = v_field_24767;
          V v_st_24770 = v_field_24768;
          switch (heff_tag_of(v_x11_24769)) {
          case TAG_Left: {
            V v_e_24771 = heff_field(v_x11_24769, 0);
            V v_ru_24x11_24769_24Left = heff_take_reuse_n(v_x11_24769, 1ULL, 1);
            heff_drop_rec(v_r_240, 3);
            heff_drop_tag(v_e0_241, 5);
            heff_drop_rec(v_kw_24736, 9);
            heff_drop(v_body_24740);
            heff_drop(v_x_24747);
            heff_drop_cell(v_ru_24x11_24744_24Right, 1);
            heff_drop(v_names_24749);
            return heff_tag_at_n(v_ru_24x1_24743_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_re_n(v_ru_24x11_24769_24Left, TAG_Left, 1, 1ULL, (V[]){v_e_24771}), v_st_24770});
          }
          case TAG_Right: {
            V v_x_24772 = heff_field(v_x11_24769, 0);
            V v_ru_24x11_24769_24Right = heff_take_reuse_n(v_x11_24769, 1ULL, 1);
            HeffT2 v_t_24783 = (g_heff_2esyntax_2esurface_2ewithScope_24cpr(v_names_24749, heff_clo_n(g_heff_2esyntax_2esurface_2eexprL_lam45, 1, 2, (V[]){v_r_240, v_body_24740}), v_st_24770));
            {
              V v_field_24784 = v_t_24783.f[0];
              V v_field_24785 = v_t_24783.f[1];
              V v_x11_24786 = v_field_24784;
              V v_st_24787 = v_field_24785;
              switch (heff_tag_of(v_x11_24786)) {
              case TAG_Left: {
                V v_e_24788 = heff_field(v_x11_24786, 0);
                heff_take_n(v_x11_24786, 1ULL, 1);
                heff_drop_tag(v_e0_241, 5);
                heff_drop_rec(v_kw_24736, 9);
                heff_drop(v_x_24747);
                heff_drop_cell(v_ru_24x11_24744_24Right, 1);
                heff_drop(v_x_24772);
                return heff_tag_at_n(v_ru_24x1_24743_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_24769_24Right, TAG_Left, 1, (V[]){v_e_24788}), v_st_24787});
              }
              case TAG_Right: {
                V v_x_24789 = heff_field(v_x11_24786, 0);
                heff_take_n(v_x11_24786, 1ULL, 1);
                heff_drop_cell(v_ru_24x11_24769_24Right, 1);
                V v_t_24790 = (g_heff_2esyntax_2ecst_2elastE(v_e0_241));
                V v_e_24791 = heff_get_n(v_t_24790, 4, 9);
                V v_t_24792 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_24736, 3, 9), v_e_24791});
                V v_x_24793 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EWithBound, 3, (V[]){v_x_24747, v_x_24772, v_x_24789}), v_t_24792});
                return heff_tag_at_n(v_ru_24x1_24743_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_24744_24Right, TAG_Right, 1, (V[]){v_x_24793}), v_st_24787});
              }
              default: return heff_nomatch(v_x11_24786);
              }
            }
          }
          default: return heff_nomatch(v_x11_24769);
          }
        }
      }
      default: return heff_nomatch(v_x11_24744);
      }
    }
    default: return heff_nomatch(v_x1_24743);
    }
  }
  default: {
    heff_drop_rec(v_r_240, 3);
    V v_t_24794 = (g_heff_2esyntax_2ecst_2efirstE(v_e0_241));
    V v_start_24795 = heff_take_field(v_t_24794, 3);
    V v_end_24796 = heff_get_n(v_t_24794, 4, 9);
    V v_t_24797 = ({ V a_0 = v_e0_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop(v_e0_241); r_; });
    V v_t_24798 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eexprL_str29), heff_get_n(v_t_24797, 1, 9));
    V v_msg_24799 = heff_strAppend(v_t_24798, ((V)&g_heff_2esyntax_2esurface_2eexprL_str30));
    V v_t_24800 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24799, heff_rec_n(2, shape_start__end, (V[]){v_start_24795, v_end_24796}), NTAG(TAG_Nothing)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24800}), v_z_242});
  }
  }
}
V g_heff_2esyntax_2esurface_2eexprL_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2eexprL(a[0], a[1], a[2]);
}
V g_heff_2esyntax_2esurface_2eexprL_lam0(V self, V *args) {
  V v_m_2430 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2esyntax_2esurface_2esegmentL(v_r_240, v_m_2430));
}
V g_heff_2esyntax_2esurface_2eexprL_lam1(V self, V *args) {
  V v_x_2447 = args[0];
  V v_rest_2448 = args[1];
  V v_sp_2445 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2449 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ETag, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2eexprL_str8)}), v_sp_2445});
  V v_t_2450 = heff_tag_n(TAG_Cons, 2, (V[]){v_rest_2448, NTAG(TAG_Nil)});
  return (g_heff_2esyntax_2epresyntax_2eapp(v_t_2449, heff_tag_n(TAG_Cons, 2, (V[]){v_x_2447, v_t_2450})));
}
V g_heff_2esyntax_2esurface_2eexprL_lam3(V self, V *args) {
  V v_st_2483 = args[0];
  V v_m_2482 = heff_env(self)[0];
  V v_path_2479 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_2484 = heff_tr(heff_call(v_m_2482, 1, (V[]){v_st_2483}));
  switch (heff_tag_of(v_x1_2484)) {
  case TAG_MkPair: {
    V v_x11_2485 = heff_field(v_x1_2484, 0);
    V v_st_2486 = heff_field(v_x1_2484, 1);
    V v_ru_24x1_2484_24MkPair = heff_take_reuse_n(v_x1_2484, 3ULL, 2);
    switch (heff_tag_of(v_x11_2485)) {
    case TAG_Left: {
      V v_e_2487 = heff_field(v_x11_2485, 0);
      V v_ru_24x11_2485_24Left = heff_take_reuse_n(v_x11_2485, 1ULL, 1);
      heff_drop(v_path_2479);
      return heff_tag_re_n(v_ru_24x1_2484_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x11_2485_24Left, TAG_Left, 1, 1ULL, (V[]){v_e_2487}), v_st_2486});
    }
    case TAG_Right: {
      V v_x_2488 = heff_field(v_x11_2485, 0);
      V v_ru_24x11_2485_24Right = heff_take_reuse_n(v_x11_2485, 1ULL, 1);
      V v_t_2489 = (g_heff_2esyntax_2esurface_2epathOf(heff_dup(v_path_2479), NTAG(TAG_Nil)));
      V v_t_2490 = ({ V a_0 = v_path_2479; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop(v_path_2479); r_; });
      V v_t_2493;
      switch (heff_tag_of(v_x_2488)) {
      case TAG_At: {
        V v_s_2492 = heff_dup(heff_field(v_x_2488, 1));
        v_t_2493 = v_s_2492;
        break;
      }
      default: heff_nomatch(v_x_2488);
      }
      V v_t_2494 = ({ V rv_0 = heff_get_n(v_t_2490, 3, 9); V rr_ = heff_rec_reuse_nf(v_t_2493, 2ULL, 2, shape_start__end, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
      V v_x_2495 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_SetPath, 2, (V[]){v_t_2489, v_x_2488}), v_t_2494});
      return heff_tag_re_n(v_ru_24x1_2484_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_at_n(v_ru_24x11_2485_24Right, TAG_Right, 1, (V[]){v_x_2495}), v_st_2486});
    }
    default: return heff_nomatch(v_x11_2485);
    }
  }
  default: return heff_nomatch(v_x1_2484);
  }
}
V g_heff_2esyntax_2esurface_2eexprL_lam4(V self, V *args) {
  V v_st_2497 = args[0];
  V v_m_2496 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2498 = heff_tr(heff_call(v_m_2496, 1, (V[]){v_st_2497}));
  switch (heff_tag_of(v_x1_2498)) {
  case TAG_MkPair: {
    V v_x11_2499 = heff_field(v_x1_2498, 0);
    V v_st_24100 = heff_field(v_x1_2498, 1);
    V v_ru_24x1_2498_24MkPair = heff_take_reuse_n(v_x1_2498, 3ULL, 2);
    switch (heff_tag_of(v_x11_2499)) {
    case TAG_Left: {
      V v_e_24101 = heff_field(v_x11_2499, 0);
      V v_ru_24x11_2499_24Left = heff_take_reuse_n(v_x11_2499, 1ULL, 1);
      return heff_tag_re_n(v_ru_24x1_2498_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x11_2499_24Left, TAG_Left, 1, 1ULL, (V[]){v_e_24101}), v_st_24100});
    }
    case TAG_Right: {
      V v_x_24102 = heff_field(v_x11_2499, 0);
      V v_ru_24x11_2499_24Right = heff_take_reuse_n(v_x11_2499, 1ULL, 1);
      V v_t_24105;
      switch (heff_tag_of(v_x_24102)) {
      case TAG_At: {
        V v_s_24104 = heff_dup(heff_field(v_x_24102, 1));
        v_t_24105 = v_s_24104;
        break;
      }
      default: heff_nomatch(v_x_24102);
      }
      V v_t_24106 = heff_tag_n(TAG_SetPath, 2, (V[]){NTAG(TAG_Nil), v_x_24102});
      V v_t_24107 = heff_tag_at_n(v_ru_24x11_2499_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24106, v_t_24105})});
      return heff_tag_re_n(v_ru_24x1_2498_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){v_t_24107, v_st_24100});
    }
    default: return heff_nomatch(v_x11_2499);
    }
  }
  default: return heff_nomatch(v_x1_2498);
  }
}
V g_heff_2esyntax_2esurface_2eexprL_lam2(V self, V *args) {
  V v_m_2476 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_r_2477 = v_r_240;
  V v_x2_2478 = v_m_2476;
  switch (heff_tag_of(v_x2_2478)) {
  case TAG_EUSet: {
    V v_path_2479 = heff_field(v_x2_2478, 0);
    V v_e_2481 = heff_field(v_x2_2478, 2);
    heff_take_n(v_x2_2478, 5ULL, 3);
    V v_m_2482 = heff_tr(heff_call(heff_get_n(v_r_2477, 0, 3), 1, (V[]){v_e_2481}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2eexprL_lam3, 1, 2, (V[]){v_m_2482, v_path_2479});
  }
  default: {
    V v_m_2496 = heff_tr(heff_call(heff_get_n(v_r_2477, 0, 3), 1, (V[]){v_x2_2478}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2eexprL_lam4, 1, 1, (V[]){v_m_2496});
  }
  }
}
V g_heff_2esyntax_2esurface_2eexprL_lam5(V self, V *args) {
  V v_st_24122 = args[0];
  V v_m_24121 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24123 = heff_tr(heff_call(v_m_24121, 1, (V[]){v_st_24122}));
  switch (heff_tag_of(v_x1_24123)) {
  case TAG_MkPair: {
    V v_x11_24124 = heff_field(v_x1_24123, 0);
    V v_st_24125 = heff_field(v_x1_24123, 1);
    V v_ru_24x1_24123_24MkPair = heff_take_reuse_n(v_x1_24123, 3ULL, 2);
    switch (heff_tag_of(v_x11_24124)) {
    case TAG_Left: {
      V v_e_24126 = heff_field(v_x11_24124, 0);
      V v_ru_24x11_24124_24Left = heff_take_reuse_n(v_x11_24124, 1ULL, 1);
      return heff_tag_re_n(v_ru_24x1_24123_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x11_24124_24Left, TAG_Left, 1, 1ULL, (V[]){v_e_24126}), v_st_24125});
    }
    case TAG_Right: {
      V v_x_24127 = heff_field(v_x11_24124, 0);
      heff_take_n(v_x11_24124, 1ULL, 1);
      V v_t_24128 = (g_heff_2esyntax_2esurface_2enameBinder(v_x_24127));
      V v_t_24129 = heff_tr(heff_call(((V)&g_heff_2esyntax_2esurface_2easBinderOn_clo), 1, (V[]){v_t_24128}));
      return (g_heff_2esyntax_2esurface_2ebind_24s273834694x1861812659_24tok2(v_ru_24x1_24123_24MkPair, MK_INT(150LL), ((V)&g_heff_2esyntax_2esurface_2eexprL_str9), v_t_24129, v_st_24125));
    }
    default: return heff_nomatch(v_x11_24124);
    }
  }
  default: return heff_nomatch(v_x1_24123);
  }
}
V g_heff_2esyntax_2esurface_2eexprL_lam6(V self, V *args) {
  V v_d_27_24130 = args[0];
  V v_st_24131 = args[1];
  V v_o_24116 = heff_env(self)[0];
  V v_c_24120 = heff_env(self)[1];
  heff_drop(v_d_27_24130);
  heff_clo_take(self, 2);
  V v_t_24132 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_o_24116, 3, 9), heff_get_n(v_c_24120, 4, 9)});
  V v_t_24133 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2eexprL_str10)}), v_t_24132});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24133}), v_st_24131});
}
V g_heff_2esyntax_2esurface_2eexprL_lam7(V self, V *args) {
  V v_a_24139 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2esyntax_2esurface_2evariantL(v_r_240, v_a_24139));
}
V g_heff_2esyntax_2esurface_2eexprL_lam9(V self, V *args) {
  V v_st_24212 = args[0];
  V v_m_24211 = heff_env(self)[0];
  V v_x_24207 = heff_env(self)[1];
  V v_o_24206 = heff_env(self)[2];
  V v_c_24210 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x1_24213 = heff_tr(heff_call(v_m_24211, 1, (V[]){v_st_24212}));
  switch (heff_tag_of(v_x1_24213)) {
  case TAG_MkPair: {
    V v_x11_24214 = heff_field(v_x1_24213, 0);
    V v_st_24215 = heff_field(v_x1_24213, 1);
    V v_ru_24x1_24213_24MkPair = heff_take_reuse_n(v_x1_24213, 3ULL, 2);
    switch (heff_tag_of(v_x11_24214)) {
    case TAG_Left: {
      V v_e_24216 = heff_field(v_x11_24214, 0);
      V v_ru_24x11_24214_24Left = heff_take_reuse_n(v_x11_24214, 1ULL, 1);
      heff_drop_rec(v_x_24207, 9);
      heff_drop_rec(v_o_24206, 9);
      heff_drop_rec(v_c_24210, 9);
      return heff_tag_re_n(v_ru_24x1_24213_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x11_24214_24Left, TAG_Left, 1, 1ULL, (V[]){v_e_24216}), v_st_24215});
    }
    case TAG_Right: {
      V v_x_24217 = heff_field(v_x11_24214, 0);
      V v_ru_24x11_24214_24Right = heff_take_reuse_n(v_x11_24214, 1ULL, 1);
      V v_t_24218 = heff_tag_n(TAG_ENamed, 2, (V[]){heff_get_n(v_x_24207, 1, 9), v_x_24217});
      V v_t_24219 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_o_24206, 3, 9), heff_get_n(v_c_24210, 4, 9)});
      V v_t_24220 = heff_tag_at_n(v_ru_24x11_24214_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24218, v_t_24219})});
      return heff_tag_re_n(v_ru_24x1_24213_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){v_t_24220, v_st_24215});
    }
    default: return heff_nomatch(v_x11_24214);
    }
  }
  default: return heff_nomatch(v_x1_24213);
  }
}
V g_heff_2esyntax_2esurface_2eexprL_lam8(V self, V *args) {
  V v_m_24203 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_r_24204 = v_r_240;
  V v_x2_24205 = v_m_24203;
  switch (heff_tag_of(v_x2_24205)) {
  case TAG_Named: {
    V v_o_24206 = heff_field(v_x2_24205, 0);
    V v_x_24207 = heff_field(v_x2_24205, 1);
    V v_e_24209 = heff_field(v_x2_24205, 3);
    V v_c_24210 = heff_field(v_x2_24205, 4);
    heff_take_n(v_x2_24205, 27ULL, 5);
    V v_m_24211 = heff_tr(heff_call(heff_get_n(v_r_24204, 0, 3), 1, (V[]){v_e_24209}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2eexprL_lam9, 1, 4, (V[]){v_m_24211, v_x_24207, v_o_24206, v_c_24210});
  }
  default: {
    V f_ = heff_get_n(v_r_24204, 0, 3);
    args[0] = v_x2_24205;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  }
}
V g_heff_2esyntax_2esurface_2eexprL_lam11(V self, V *args) {
  V v_st_24245 = args[0];
  V v_m_24244 = heff_env(self)[0];
  V v_op_24242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24246 = heff_tr(heff_call(v_m_24244, 1, (V[]){v_st_24245}));
  switch (heff_tag_of(v_x1_24246)) {
  case TAG_MkPair: {
    V v_x11_24247 = heff_field(v_x1_24246, 0);
    V v_st_24248 = heff_field(v_x1_24246, 1);
    V v_ru_24x1_24246_24MkPair = heff_take_reuse_n(v_x1_24246, 3ULL, 2);
    switch (heff_tag_of(v_x11_24247)) {
    case TAG_Left: {
      V v_e_24249 = heff_field(v_x11_24247, 0);
      V v_ru_24x11_24247_24Left = heff_take_reuse_n(v_x11_24247, 1ULL, 1);
      heff_drop(v_op_24242);
      return heff_tag_re_n(v_ru_24x1_24246_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x11_24247_24Left, TAG_Left, 1, 1ULL, (V[]){v_e_24249}), v_st_24248});
    }
    case TAG_Right: {
      V v_x_24250 = heff_field(v_x11_24247, 0);
      V v_ru_24x11_24247_24Right = heff_take_reuse_n(v_x11_24247, 1ULL, 1);
      V v_t_24251 = heff_tag_at_n(v_ru_24x11_24247_24Right, TAG_Right, 1, (V[]){heff_rec_n(2, shape_op__e, (V[]){v_op_24242, v_x_24250})});
      return heff_tag_re_n(v_ru_24x1_24246_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){v_t_24251, v_st_24248});
    }
    default: return heff_nomatch(v_x11_24247);
    }
  }
  default: return heff_nomatch(v_x1_24246);
  }
}
V g_heff_2esyntax_2esurface_2eexprL_lam12(V self, V *args) {
  V v_st_24254 = args[0];
  V v_m_24253 = heff_env(self)[0];
  V v_op_24252 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24255 = heff_tr(heff_call(v_m_24253, 1, (V[]){v_st_24254}));
  switch (heff_tag_of(v_x1_24255)) {
  case TAG_MkPair: {
    V v_x11_24256 = heff_field(v_x1_24255, 0);
    V v_st_24257 = heff_field(v_x1_24255, 1);
    V v_ru_24x1_24255_24MkPair = heff_take_reuse_n(v_x1_24255, 3ULL, 2);
    switch (heff_tag_of(v_x11_24256)) {
    case TAG_Left: {
      V v_e_24258 = heff_field(v_x11_24256, 0);
      V v_ru_24x11_24256_24Left = heff_take_reuse_n(v_x11_24256, 1ULL, 1);
      heff_drop(v_op_24252);
      return heff_tag_re_n(v_ru_24x1_24255_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x11_24256_24Left, TAG_Left, 1, 1ULL, (V[]){v_e_24258}), v_st_24257});
    }
    case TAG_Right: {
      V v_x_24259 = heff_field(v_x11_24256, 0);
      V v_ru_24x11_24256_24Right = heff_take_reuse_n(v_x11_24256, 1ULL, 1);
      V v_t_24260 = heff_tag_at_n(v_ru_24x11_24256_24Right, TAG_Right, 1, (V[]){heff_rec_n(2, shape_op__e, (V[]){v_op_24252, v_x_24259})});
      return heff_tag_re_n(v_ru_24x1_24255_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){v_t_24260, v_st_24257});
    }
    default: return heff_nomatch(v_x11_24256);
    }
  }
  default: return heff_nomatch(v_x1_24255);
  }
}
V g_heff_2esyntax_2esurface_2eexprL_lam10(V self, V *args) {
  V v_m_24239 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_r_24240 = v_r_240;
  V v_m_24241 = v_m_24239;
  switch (heff_tag_of(v_m_24241)) {
  case TAG_OpRhs: {
    V v_op_24242 = heff_field(v_m_24241, 0);
    V v_e_24243 = heff_field(v_m_24241, 1);
    heff_take_n(v_m_24241, 3ULL, 2);
    V v_m_24244 = heff_tr(heff_call(heff_get_n(v_r_24240, 0, 3), 1, (V[]){v_e_24243}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2eexprL_lam11, 1, 2, (V[]){v_m_24244, v_op_24242});
  }
  default: {
    V v_op_24252 = (g_heff_2esyntax_2ecst_2efirstE(v_m_24241));
    V v_m_24253 = heff_tr(heff_call(heff_get_n(v_r_24240, 0, 3), 1, (V[]){v_m_24241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2eexprL_lam12, 1, 2, (V[]){v_m_24253, v_op_24252});
  }
  }
}
V g_heff_2esyntax_2esurface_2eexprL_lam14(V self, V *args) {
  V v_st_24283 = args[0];
  V v_m_24282 = heff_env(self)[0];
  V v_op_24270 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24284 = heff_tr(heff_call(v_m_24282, 1, (V[]){v_st_24283}));
  switch (heff_tag_of(v_x1_24284)) {
  case TAG_MkPair: {
    V v_x11_24285 = heff_field(v_x1_24284, 0);
    V v_st_24286 = heff_field(v_x1_24284, 1);
    V v_ru_24x1_24284_24MkPair = heff_take_reuse_n(v_x1_24284, 3ULL, 2);
    switch (heff_tag_of(v_x11_24285)) {
    case TAG_Left: {
      V v_e_24287 = heff_field(v_x11_24285, 0);
      V v_ru_24x11_24285_24Left = heff_take_reuse_n(v_x11_24285, 1ULL, 1);
      heff_drop_rec(v_op_24270, 9);
      return heff_tag_re_n(v_ru_24x1_24284_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x11_24285_24Left, TAG_Left, 1, 1ULL, (V[]){v_e_24287}), v_st_24286});
    }
    case TAG_Right: {
      V v_x_24288 = heff_field(v_x11_24285, 0);
      V v_ru_24x11_24285_24Right = heff_take_reuse_n(v_x11_24285, 1ULL, 1);
      V v_t_24289 = heff_tag_at_n(v_ru_24x1_24284_24MkPair, TAG_MkPair, 2, (V[]){heff_get_n(v_op_24270, 3, 9), v_x_24288});
      V v_t_24290 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24289, NTAG(TAG_Nil)});
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_24285_24Right, TAG_Right, 1, (V[]){v_t_24290}), v_st_24286});
    }
    default: return heff_nomatch(v_x11_24285);
    }
  }
  default: return heff_nomatch(v_x1_24284);
  }
}
V g_heff_2esyntax_2esurface_2eexprL_lam15(V self, V *args) {
  V v_st_24291 = args[0];
  V v_t_24292 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_Nil)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24292, v_st_24291});
}
V g_heff_2esyntax_2esurface_2eexprL_lam16(V self, V *args) {
  V v_st_24293 = args[0];
  V v_t_24294 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_Nil)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24294, v_st_24293});
}
V g_heff_2esyntax_2esurface_2eexprL_lam13(V self, V *args) {
  V v_m_24267 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_r_24268 = v_r_240;
  V v_x2_24269 = v_m_24267;
  switch (heff_tag_of(v_x2_24269)) {
  case TAG_OpRhs: {
    V v_op_24270 = heff_field(v_x2_24269, 0);
    heff_take_n(v_x2_24269, 1ULL, 2);
    if (heff_strEq_c(heff_dup(heff_rfield(v_op_24270, 0)), ((V)&g_heff_2esyntax_2esurface_2eexprL_str15))) {
      V v_t_24272 = heff_dup(v_op_24270);
      V v_t_24273 = (g_heff_2esyntax_2esurface_2efirstDot(heff_rfield(v_t_24272, 1), MK_INT(0LL)));
      V v_text_24274 = heff_strSlice(heff_dup(heff_rfield(v_t_24272, 1)), MK_INT(0LL), v_t_24273);
      V v_c_24275 = heff_strByteAt(heff_dup(heff_rfield(v_t_24272, 1)), MK_INT(0LL));
      V v_t_24276 = ({ V a_0 = v_text_24274; V b_1 = heff_dup(g_heff_2esyntax_2efmt_2elex_2ekeywords_get()); V r_ = (g_list_2eany_24s1006624359x760861690(a_0, b_1)); heff_drop(v_text_24274); heff_drop(b_1); r_; });
      V v_t_24277;
      if ((heff_dup(v_t_24276) == NTAG(TAG_True))) {
        heff_drop(v_c_24275);
        heff_drop(v_t_24276);
        v_t_24277 = ((V)&g_heff_2esyntax_2esurface_2eexprL_str16);
      } else {
        heff_drop(v_t_24276);
        if (((((int64_t)65ULL) <= heff_peek_word(v_c_24275)) && (heff_peek_word(v_c_24275) <= ((int64_t)90ULL)))) {
          heff_drop(v_c_24275);
          v_t_24277 = ((V)&g_heff_2esyntax_2esurface_2eexprL_str17);
        } else {
          heff_drop(v_c_24275);
          v_t_24277 = ((V)&g_heff_2esyntax_2esurface_2eexprL_str18);
        }
      }
      V v_t_24278 = (g_heff_2esyntax_2esurface_2efirstDot(heff_rfield(v_t_24272, 1), MK_INT(0LL)));
      V v_t_24279 = (g_heff_2esyntax_2esurface_2etickPart(heff_dup(v_t_24272), v_t_24277, MK_INT(0LL), MK_INT(0LL), v_t_24278));
      V v_t_24280 = (g_heff_2esyntax_2esurface_2efirstDot(heff_rfield(v_t_24272, 1), MK_INT(0LL)));
      V v_t_24281 = ({ V a_0 = v_t_24272; V a_1 = heff_tag_n(TAG_Atom, 1, (V[]){v_t_24279}); V a_2 = v_t_24280; V r_ = (g_heff_2esyntax_2esurface_2etickFields(a_0, a_1, a_2)); heff_drop_rec(v_t_24272, 9); r_; });
      V v_m_24282 = heff_tr(heff_call(heff_get_n(v_r_24268, 0, 3), 1, (V[]){v_t_24281}));
      return heff_clo_n(g_heff_2esyntax_2esurface_2eexprL_lam14, 1, 2, (V[]){v_m_24282, v_op_24270});
    } else {
      heff_drop_rec(v_r_24268, 3);
      heff_drop_rec(v_op_24270, 9);
      return ((V)&g_heff_2esyntax_2esurface_2eexprL_lam15_clo);
    }
  }
  default: {
    heff_drop_rec(v_r_24268, 3);
    heff_drop(v_x2_24269);
    return ((V)&g_heff_2esyntax_2esurface_2eexprL_lam16_clo);
  }
  }
}
V g_heff_2esyntax_2esurface_2eexprL_lam17(V self, V *args) {
  V v_op_24302 = args[0];
  V v_l_24303 = args[1];
  V v_r_24304 = args[2];
  V v_heads_24301 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_24305 = ({ V a_0 = v_heads_24301; V a_1 = heff_rfield(v_op_24302, 3); HeffT2 r_ = (g_heff_2esyntax_2esurface_2eheadAt_24cpr(a_0, a_1)); heff_drop(v_heads_24301); r_; });
  {
    V v_field_24307 = v_t_24305.f[1];
    int64_t v_tag_24306 = ((int64_t)v_t_24305.f[0]);
    if ((v_tag_24306 == ((int64_t)0ULL))) {
      heff_drop_rec(v_op_24302, 9);
      V v_h_24308 = v_field_24307;
      V v_t_24309 = heff_tag_n(TAG_Cons, 2, (V[]){v_r_24304, NTAG(TAG_Nil)});
      return (g_heff_2esyntax_2epresyntax_2eapp(v_h_24308, heff_tag_n(TAG_Cons, 2, (V[]){v_l_24303, v_t_24309})));
    } else {
      heff_drop(v_field_24307);
      V v_op_24310 = v_op_24302;
      V v_l_24311 = v_l_24303;
      V v_r_24312 = v_r_24304;
      if (heff_strEq_c(heff_dup(heff_rfield(v_op_24310, 1)), ((V)&g_heff_2esyntax_2esurface_2eexprL_str19))) {
        V v_t_24313 = heff_rec_n(2, shape_start__end, (V[]){heff_dup(heff_rfield(v_op_24310, 3)), heff_dup(heff_rfield(v_op_24310, 4))});
        V v_t_24314 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ETag, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2eexprL_str20)}), v_t_24313});
        return (g_heff_2esyntax_2esurface_2eshortcut(v_op_24310, v_l_24311, v_r_24312, v_t_24314));
      } else {
        if (heff_strEq_c(heff_dup(heff_rfield(v_op_24310, 1)), ((V)&g_heff_2esyntax_2esurface_2eexprL_str21))) {
          V v_t_24315 = heff_rec_n(2, shape_start__end, (V[]){heff_dup(heff_rfield(v_op_24310, 3)), heff_dup(heff_rfield(v_op_24310, 4))});
          V v_t_24316 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ETag, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2eexprL_str22)}), v_t_24315});
          return (g_heff_2esyntax_2esurface_2eshortcut(v_op_24310, v_l_24311, v_t_24316, v_r_24312));
        } else {
          V v_t_24317 = heff_tag_n(TAG_EVar, 1, (V[]){heff_take_field(v_op_24310, 1)});
          V v_t_24318 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_op_24310, 3), heff_get_n(v_op_24310, 4, 9)});
          V v_t_24319 = heff_tag_n(TAG_Cons, 2, (V[]){v_r_24312, NTAG(TAG_Nil)});
          return (g_heff_2esyntax_2epresyntax_2eapp(heff_tag_n(TAG_At, 2, (V[]){v_t_24317, v_t_24318}), heff_tag_n(TAG_Cons, 2, (V[]){v_l_24311, v_t_24319})));
        }
      }
    }
  }
}
V g_heff_2esyntax_2esurface_2eexprL_lam18(V self, V *args) {
  V v_b_24376 = args[0];
  V v_r_24373 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2esyntax_2esurface_2elamBinderL(v_r_24373, v_b_24376));
}
V g_heff_2esyntax_2esurface_2eexprL_lam19(V self, V *args) {
  V v_st_24385 = args[0];
  V v_m_24384 = heff_env(self)[0];
  V v_x_24382 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24386 = heff_tr(heff_call(v_m_24384, 1, (V[]){v_st_24385}));
  switch (heff_tag_of(v_x1_24386)) {
  case TAG_MkPair: {
    V v_x11_24387 = heff_field(v_x1_24386, 0);
    V v_st_24388 = heff_field(v_x1_24386, 1);
    V v_ru_24x1_24386_24MkPair = heff_take_reuse_n(v_x1_24386, 3ULL, 2);
    switch (heff_tag_of(v_x11_24387)) {
    case TAG_Left: {
      V v_e_24389 = heff_field(v_x11_24387, 0);
      V v_ru_24x11_24387_24Left = heff_take_reuse_n(v_x11_24387, 1ULL, 1);
      heff_drop(v_x_24382);
      return heff_tag_re_n(v_ru_24x1_24386_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x11_24387_24Left, TAG_Left, 1, 1ULL, (V[]){v_e_24389}), v_st_24388});
    }
    case TAG_Right: {
      V v_x_24390 = heff_field(v_x11_24387, 0);
      V v_ru_24x11_24387_24Right = heff_take_reuse_n(v_x11_24387, 1ULL, 1);
      V v_x_24391 = ({ V a_0 = v_x_24390; V a_1 = v_x_24382; V r_ = (g_heff_2esyntax_2esurface_2efoldr_24s503335349x1048908132(a_0, a_1)); heff_drop(v_x_24390); r_; });
      return heff_tag_re_n(v_ru_24x1_24386_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_at_n(v_ru_24x11_24387_24Right, TAG_Right, 1, (V[]){v_x_24391}), v_st_24388});
    }
    default: return heff_nomatch(v_x11_24387);
    }
  }
  default: return heff_nomatch(v_x1_24386);
  }
}
V g_heff_2esyntax_2esurface_2eexprL_lam21(V self, V *args) {
  V v_a_24404 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_r_240; V a_1 = v_a_24404; V r_ = (g_heff_2esyntax_2esurface_2ealtL(a_0, a_1)); heff_drop(v_a_24404); r_; });
}
V g_heff_2esyntax_2esurface_2eexprL_lam20(V self, V *args) {
  V v_st_24402 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_alts_24395 = heff_env(self)[1];
  V v_t_24403 = heff_dup(heff_rfield(v_st_24402, 1));
  heff_clo_take(self, 2);
  V v_t_24405 = (g_prelude_2etraverse_24s499544530x2060473942(heff_clo_n(g_heff_2esyntax_2esurface_2eexprL_lam21, 1, 1, (V[]){v_r_240}), v_alts_24395));
  V v_x1_24406 = heff_tr(heff_call(v_t_24405, 1, (V[]){v_st_24402}));
  switch (heff_tag_of(v_x1_24406)) {
  case TAG_MkPair: {
    V v_x11_24407 = heff_field(v_x1_24406, 0);
    V v_st_24408 = heff_field(v_x1_24406, 1);
    V v_ru_24x1_24406_24MkPair = heff_take_reuse_n(v_x1_24406, 3ULL, 2);
    switch (heff_tag_of(v_x11_24407)) {
    case TAG_Left: {
      V v_e_24409 = heff_field(v_x11_24407, 0);
      V v_ru_24x11_24407_24Left = heff_take_reuse_n(v_x11_24407, 1ULL, 1);
      heff_drop(v_t_24403);
      return heff_tag_re_n(v_ru_24x1_24406_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x11_24407_24Left, TAG_Left, 1, 1ULL, (V[]){v_e_24409}), v_st_24408});
    }
    case TAG_Right: {
      V v_x_24410 = heff_field(v_x11_24407, 0);
      V v_ru_24x11_24407_24Right = heff_take_reuse_n(v_x11_24407, 1ULL, 1);
      V v_st_24411 = (g_heff_2esyntax_2esurface_2esetScope(v_t_24403, v_st_24408));
      return heff_tag_at_n(v_ru_24x1_24406_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_re_n(v_ru_24x11_24407_24Right, TAG_Right, 1, 1ULL, (V[]){v_x_24410}), v_st_24411});
    }
    default: return heff_nomatch(v_x11_24407);
    }
  }
  default: return heff_nomatch(v_x1_24406);
  }
}
V g_heff_2esyntax_2esurface_2eexprL_lam22(V self, V *args) {
  V v_alts_27_24412 = args[0];
  V v_z_24413 = args[1];
  V v_e0_241 = heff_env(self)[0];
  V v_kw_24392 = heff_env(self)[1];
  V v_x_24401 = heff_env(self)[2];
  V v_t_24414 = (g_list_2efoldl_24s1422286737x1936996242(NTAG(TAG_Nil), heff_dup(v_alts_27_24412)));
  V v_sps_24415 = v_t_24414;
  V v_s_24416 = v_z_24413;
  V v_known_24417 = heff_take_field(v_s_24416, 2);
  V v_binders_24418 = heff_take_field(v_s_24416, 3);
  V v_patVars_24419 = heff_take_field(v_s_24416, 4);
  V v_fix_24420 = heff_take_field(v_s_24416, 5);
  V v_lenient_24421 = heff_take_field(v_s_24416, 6);
  V v_at_24422 = heff_take_field(v_s_24416, 7);
  V v_knot_24423 = heff_take_field(v_s_24416, 8);
  V v_arms_24424 = (g_heff_2esyntax_2esurface_2eappendS(v_sps_24415, heff_take_field(v_s_24416, 9)));
  V v_st_24425 = ({ V rv_2 = v_known_24417; V rv_3 = v_binders_24418; V rv_4 = v_patVars_24419; V rv_5 = v_fix_24420; V rv_6 = v_lenient_24421; V rv_7 = v_at_24422; V rv_8 = v_knot_24423; V rv_9 = v_arms_24424; V rr_ = heff_rec_reuse_nf(v_s_24416, 3ULL, 10, shape_toks__scope__known__binders__patVars__fix__lenient__at__knot__arms, 15u, 0u); heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; heff_rfield(rr_, 5) = rv_5; heff_rfield(rr_, 6) = rv_6; heff_rfield(rr_, 7) = rv_7; heff_rfield(rr_, 8) = rv_8; heff_rfield(rr_, 9) = rv_9; rr_; });
  heff_clo_take(self, 3);
  V v_t_24426 = (g_heff_2esyntax_2ecst_2elastE(v_e0_241));
  V v_e_24427 = heff_get_n(v_t_24426, 4, 9);
  V v_t_24428 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_24392, 3, 9), v_e_24427});
  V v_x_24429 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_x_24401, v_alts_27_24412}), v_t_24428});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24429}), v_st_24425});
}
V g_heff_2esyntax_2esurface_2eexprL_lam24(V self, V *args) {
  V v_m_24440 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2esyntax_2esurface_2estmtL(v_r_240, v_m_24440));
}
V g_heff_2esyntax_2esurface_2eexprL_lam23(V self, V *args) {
  V v_st_24438 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_stmts_24437 = heff_env(self)[1];
  V v_t_24439 = heff_dup(heff_rfield(v_st_24438, 1));
  heff_clo_take(self, 2);
  V v_t_24441 = (g_prelude_2etraverse_24s499544530x2060473942(heff_clo_n(g_heff_2esyntax_2esurface_2eexprL_lam24, 1, 1, (V[]){v_r_240}), v_stmts_24437));
  V v_x1_24442 = heff_tr(heff_call(v_t_24441, 1, (V[]){v_st_24438}));
  switch (heff_tag_of(v_x1_24442)) {
  case TAG_MkPair: {
    V v_x11_24443 = heff_field(v_x1_24442, 0);
    V v_st_24444 = heff_field(v_x1_24442, 1);
    V v_ru_24x1_24442_24MkPair = heff_take_reuse_n(v_x1_24442, 3ULL, 2);
    switch (heff_tag_of(v_x11_24443)) {
    case TAG_Left: {
      V v_e_24445 = heff_field(v_x11_24443, 0);
      V v_ru_24x11_24443_24Left = heff_take_reuse_n(v_x11_24443, 1ULL, 1);
      heff_drop(v_t_24439);
      return heff_tag_re_n(v_ru_24x1_24442_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x11_24443_24Left, TAG_Left, 1, 1ULL, (V[]){v_e_24445}), v_st_24444});
    }
    case TAG_Right: {
      V v_x_24446 = heff_field(v_x11_24443, 0);
      V v_ru_24x11_24443_24Right = heff_take_reuse_n(v_x11_24443, 1ULL, 1);
      V v_st_24447 = (g_heff_2esyntax_2esurface_2esetScope(v_t_24439, v_st_24444));
      return heff_tag_at_n(v_ru_24x1_24442_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_re_n(v_ru_24x11_24443_24Right, TAG_Right, 1, 1ULL, (V[]){v_x_24446}), v_st_24447});
    }
    default: return heff_nomatch(v_x11_24443);
    }
  }
  default: return heff_nomatch(v_x1_24442);
  }
}
V g_heff_2esyntax_2esurface_2eexprL_lam25(V self, V *args) {
  V v_stmts_27_24448 = args[0];
  V v_z_24449 = args[1];
  V v_e0_241 = heff_env(self)[0];
  V v_kw_24436 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24450 = (g_heff_2esyntax_2ecst_2elastE(v_e0_241));
  V v_e_24451 = heff_get_n(v_t_24450, 4, 9);
  V v_t_24452 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_24436, 3, 9), v_e_24451});
  V v_x_24453 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EDo, 1, (V[]){v_stmts_27_24448}), v_t_24452});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24453}), v_z_24449});
}
V g_heff_2esyntax_2esurface_2eexprL_lam27(V self, V *args) {
  V v_m_24488 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2esyntax_2esurface_2estmtL(v_r_240, v_m_24488));
}
V g_heff_2esyntax_2esurface_2eexprL_lam26(V self, V *args) {
  V v_st_24486 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_body_24479 = heff_env(self)[1];
  V v_t_24487 = heff_dup(heff_rfield(v_st_24486, 1));
  heff_clo_take(self, 2);
  V v_t_24489 = (g_prelude_2etraverse_24s499544530x2060473942(heff_clo_n(g_heff_2esyntax_2esurface_2eexprL_lam27, 1, 1, (V[]){v_r_240}), v_body_24479));
  V v_x1_24490 = heff_tr(heff_call(v_t_24489, 1, (V[]){v_st_24486}));
  switch (heff_tag_of(v_x1_24490)) {
  case TAG_MkPair: {
    V v_x11_24491 = heff_field(v_x1_24490, 0);
    V v_st_24492 = heff_field(v_x1_24490, 1);
    V v_ru_24x1_24490_24MkPair = heff_take_reuse_n(v_x1_24490, 3ULL, 2);
    switch (heff_tag_of(v_x11_24491)) {
    case TAG_Left: {
      V v_e_24493 = heff_field(v_x11_24491, 0);
      V v_ru_24x11_24491_24Left = heff_take_reuse_n(v_x11_24491, 1ULL, 1);
      heff_drop(v_t_24487);
      return heff_tag_re_n(v_ru_24x1_24490_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x11_24491_24Left, TAG_Left, 1, 1ULL, (V[]){v_e_24493}), v_st_24492});
    }
    case TAG_Right: {
      V v_x_24494 = heff_field(v_x11_24491, 0);
      V v_ru_24x11_24491_24Right = heff_take_reuse_n(v_x11_24491, 1ULL, 1);
      V v_st_24495 = (g_heff_2esyntax_2esurface_2esetScope(v_t_24487, v_st_24492));
      return heff_tag_at_n(v_ru_24x1_24490_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_re_n(v_ru_24x11_24491_24Right, TAG_Right, 1, 1ULL, (V[]){v_x_24494}), v_st_24495});
    }
    default: return heff_nomatch(v_x11_24491);
    }
  }
  default: return heff_nomatch(v_x1_24490);
  }
}
V g_heff_2esyntax_2esurface_2eexprL_lam28(V self, V *args) {
  V v_body_27_24496 = args[0];
  V v_z_24497 = args[1];
  V v_e0_241 = heff_env(self)[0];
  V v_kw_24476 = heff_env(self)[1];
  V v_x_24485 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_24498 = (g_heff_2esyntax_2ecst_2elastE(v_e0_241));
  V v_e_24499 = heff_get_n(v_t_24498, 4, 9);
  V v_t_24500 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_24476, 3, 9), v_e_24499});
  V v_x_24501 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EWhile, 2, (V[]){v_x_24485, v_body_27_24496}), v_t_24500});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24501}), v_z_24497});
}
V g_heff_2esyntax_2esurface_2eexprL_lam30(V self, V *args) {
  V v_m_24523 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2esyntax_2esurface_2estmtL(v_r_240, v_m_24523));
}
V g_heff_2esyntax_2esurface_2eexprL_lam29(V self, V *args) {
  V v_st_24521 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_body_24507 = heff_env(self)[1];
  V v_t_24522 = heff_dup(heff_rfield(v_st_24521, 1));
  heff_clo_take(self, 2);
  V v_t_24524 = (g_prelude_2etraverse_24s499544530x2060473942(heff_clo_n(g_heff_2esyntax_2esurface_2eexprL_lam30, 1, 1, (V[]){v_r_240}), v_body_24507));
  V v_x1_24525 = heff_tr(heff_call(v_t_24524, 1, (V[]){v_st_24521}));
  switch (heff_tag_of(v_x1_24525)) {
  case TAG_MkPair: {
    V v_x11_24526 = heff_field(v_x1_24525, 0);
    V v_st_24527 = heff_field(v_x1_24525, 1);
    V v_ru_24x1_24525_24MkPair = heff_take_reuse_n(v_x1_24525, 3ULL, 2);
    switch (heff_tag_of(v_x11_24526)) {
    case TAG_Left: {
      V v_e_24528 = heff_field(v_x11_24526, 0);
      V v_ru_24x11_24526_24Left = heff_take_reuse_n(v_x11_24526, 1ULL, 1);
      heff_drop(v_t_24522);
      return heff_tag_re_n(v_ru_24x1_24525_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x11_24526_24Left, TAG_Left, 1, 1ULL, (V[]){v_e_24528}), v_st_24527});
    }
    case TAG_Right: {
      V v_x_24529 = heff_field(v_x11_24526, 0);
      V v_ru_24x11_24526_24Right = heff_take_reuse_n(v_x11_24526, 1ULL, 1);
      V v_st_24530 = (g_heff_2esyntax_2esurface_2esetScope(v_t_24522, v_st_24527));
      return heff_tag_at_n(v_ru_24x1_24525_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_re_n(v_ru_24x11_24526_24Right, TAG_Right, 1, 1ULL, (V[]){v_x_24529}), v_st_24530});
    }
    default: return heff_nomatch(v_x11_24526);
    }
  }
  default: return heff_nomatch(v_x1_24525);
  }
}
V g_heff_2esyntax_2esurface_2eexprL_lam31(V self, V *args) {
  V v_st_24594 = args[0];
  V v_t_24595 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24595, v_st_24594});
}
V g_heff_2esyntax_2esurface_2eexprL_lam32(V self, V *args) {
  V v_st_24606 = args[0];
  V v_m_24605 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24607 = heff_tr(heff_call(v_m_24605, 1, (V[]){v_st_24606}));
  switch (heff_tag_of(v_x1_24607)) {
  case TAG_MkPair: {
    V v_x11_24608 = heff_field(v_x1_24607, 0);
    V v_st_24609 = heff_field(v_x1_24607, 1);
    V v_ru_24x1_24607_24MkPair = heff_take_reuse_n(v_x1_24607, 3ULL, 2);
    switch (heff_tag_of(v_x11_24608)) {
    case TAG_Left: {
      V v_e_24610 = heff_field(v_x11_24608, 0);
      V v_ru_24x11_24608_24Left = heff_take_reuse_n(v_x11_24608, 1ULL, 1);
      return heff_tag_re_n(v_ru_24x1_24607_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x11_24608_24Left, TAG_Left, 1, 1ULL, (V[]){v_e_24610}), v_st_24609});
    }
    case TAG_Right: {
      V v_x_24611 = heff_field(v_x11_24608, 0);
      V v_ru_24x11_24608_24Right = heff_take_reuse_n(v_x11_24608, 1ULL, 1);
      V v_t_24612 = heff_tag_at_n(v_ru_24x11_24608_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Just, 1, (V[]){v_x_24611})});
      return heff_tag_re_n(v_ru_24x1_24607_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){v_t_24612, v_st_24609});
    }
    default: return heff_nomatch(v_x11_24608);
    }
  }
  default: return heff_nomatch(v_x1_24607);
  }
}
V g_heff_2esyntax_2esurface_2eexprL_lam33(V self, V *args) {
  V v_st_24613 = args[0];
  V v_start_24603 = heff_env(self)[0];
  V v_end_24604 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24614 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2eexprL_str25)}), heff_rec_n(2, shape_start__end, (V[]){v_start_24603, v_end_24604})});
  V v_t_24615 = heff_tag_n(TAG_Right, 1, (V[]){heff_tag_n(TAG_Just, 1, (V[]){v_t_24614})});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24615, v_st_24613});
}
V g_heff_2esyntax_2esurface_2eexprL_lam34(V self, V *args) {
  V v_st_24621 = args[0];
  V v_x_24620 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24620}), v_st_24621});
}
V g_heff_2esyntax_2esurface_2eexprL_lam36(V self, V *args) {
  V v_m_24630 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2esyntax_2esurface_2estmtL(v_r_240, v_m_24630));
}
V g_heff_2esyntax_2esurface_2eexprL_lam35(V self, V *args) {
  V v_st_24628 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_body_24590 = heff_env(self)[1];
  V v_t_24629 = heff_dup(heff_rfield(v_st_24628, 1));
  heff_clo_take(self, 2);
  V v_t_24631 = (g_prelude_2etraverse_24s499544530x2060473942(heff_clo_n(g_heff_2esyntax_2esurface_2eexprL_lam36, 1, 1, (V[]){v_r_240}), v_body_24590));
  V v_x1_24632 = heff_tr(heff_call(v_t_24631, 1, (V[]){v_st_24628}));
  switch (heff_tag_of(v_x1_24632)) {
  case TAG_MkPair: {
    V v_x11_24633 = heff_field(v_x1_24632, 0);
    V v_st_24634 = heff_field(v_x1_24632, 1);
    V v_ru_24x1_24632_24MkPair = heff_take_reuse_n(v_x1_24632, 3ULL, 2);
    switch (heff_tag_of(v_x11_24633)) {
    case TAG_Left: {
      V v_e_24635 = heff_field(v_x11_24633, 0);
      V v_ru_24x11_24633_24Left = heff_take_reuse_n(v_x11_24633, 1ULL, 1);
      heff_drop(v_t_24629);
      return heff_tag_re_n(v_ru_24x1_24632_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x11_24633_24Left, TAG_Left, 1, 1ULL, (V[]){v_e_24635}), v_st_24634});
    }
    case TAG_Right: {
      V v_x_24636 = heff_field(v_x11_24633, 0);
      V v_ru_24x11_24633_24Right = heff_take_reuse_n(v_x11_24633, 1ULL, 1);
      V v_st_24637 = (g_heff_2esyntax_2esurface_2esetScope(v_t_24629, v_st_24634));
      return heff_tag_at_n(v_ru_24x1_24632_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_re_n(v_ru_24x11_24633_24Right, TAG_Right, 1, 1ULL, (V[]){v_x_24636}), v_st_24637});
    }
    default: return heff_nomatch(v_x11_24633);
    }
  }
  default: return heff_nomatch(v_x1_24632);
  }
}
V g_heff_2esyntax_2esurface_2eexprL_lam37(V self, V *args) {
  V v_body_27_24638 = args[0];
  V v_z_24639 = args[1];
  V v_r_240 = heff_env(self)[0];
  V v_c_24591 = heff_env(self)[1];
  V v_e0_241 = heff_env(self)[2];
  V v_x_24627 = heff_env(self)[3];
  V v_kw_24588 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_m_24640 = ({ V a_0 = v_r_240; V a_1 = v_c_24591; V r_ = (g_heff_2esyntax_2esurface_2ecatchL(a_0, a_1)); heff_drop(v_c_24591); r_; });
  V v_x1_24641 = heff_tr(heff_call(v_m_24640, 1, (V[]){v_z_24639}));
  switch (heff_tag_of(v_x1_24641)) {
  case TAG_MkPair: {
    V v_x11_24642 = heff_field(v_x1_24641, 0);
    V v_st_24643 = heff_field(v_x1_24641, 1);
    V v_ru_24x1_24641_24MkPair = heff_take_reuse_n(v_x1_24641, 3ULL, 2);
    switch (heff_tag_of(v_x11_24642)) {
    case TAG_Left: {
      V v_e_24644 = heff_field(v_x11_24642, 0);
      V v_ru_24x11_24642_24Left = heff_take_reuse_n(v_x11_24642, 1ULL, 1);
      heff_drop(v_body_27_24638);
      heff_drop_tag(v_e0_241, 4);
      heff_drop(v_x_24627);
      heff_drop_rec(v_kw_24588, 9);
      return heff_tag_re_n(v_ru_24x1_24641_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x11_24642_24Left, TAG_Left, 1, 1ULL, (V[]){v_e_24644}), v_st_24643});
    }
    case TAG_Right: {
      V v_x_24645 = heff_field(v_x11_24642, 0);
      V v_ru_24x11_24642_24Right = heff_take_reuse_n(v_x11_24642, 1ULL, 1);
      V v_t_24646 = (g_heff_2esyntax_2ecst_2elastE(v_e0_241));
      V v_e_24647 = heff_get_n(v_t_24646, 4, 9);
      V v_t_24648 = heff_tag_n(TAG_ETry, 1, (V[]){heff_tag_n(TAG_MkTry, 3, (V[]){v_x_24627, v_body_27_24638, v_x_24645})});
      V v_t_24649 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_24588, 3, 9), v_e_24647});
      V v_x_24650 = heff_tag_n(TAG_At, 2, (V[]){v_t_24648, v_t_24649});
      return heff_tag_re_n(v_ru_24x1_24641_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_at_n(v_ru_24x11_24642_24Right, TAG_Right, 1, (V[]){v_x_24650}), v_st_24643});
    }
    default: return heff_nomatch(v_x11_24642);
    }
  }
  default: return heff_nomatch(v_x1_24641);
  }
}
V g_heff_2esyntax_2esurface_2eexprL_lam39(V self, V *args) {
  V v_m_24670 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2esyntax_2esurface_2estmtL(v_r_240, v_m_24670));
}
V g_heff_2esyntax_2esurface_2eexprL_lam38(V self, V *args) {
  V v_st_24668 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_body_24656 = heff_env(self)[1];
  V v_t_24669 = heff_dup(heff_rfield(v_st_24668, 1));
  heff_clo_take(self, 2);
  V v_t_24671 = (g_prelude_2etraverse_24s499544530x2060473942(heff_clo_n(g_heff_2esyntax_2esurface_2eexprL_lam39, 1, 1, (V[]){v_r_240}), v_body_24656));
  V v_x1_24672 = heff_tr(heff_call(v_t_24671, 1, (V[]){v_st_24668}));
  switch (heff_tag_of(v_x1_24672)) {
  case TAG_MkPair: {
    V v_x11_24673 = heff_field(v_x1_24672, 0);
    V v_st_24674 = heff_field(v_x1_24672, 1);
    V v_ru_24x1_24672_24MkPair = heff_take_reuse_n(v_x1_24672, 3ULL, 2);
    switch (heff_tag_of(v_x11_24673)) {
    case TAG_Left: {
      V v_e_24675 = heff_field(v_x11_24673, 0);
      V v_ru_24x11_24673_24Left = heff_take_reuse_n(v_x11_24673, 1ULL, 1);
      heff_drop(v_t_24669);
      return heff_tag_re_n(v_ru_24x1_24672_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x11_24673_24Left, TAG_Left, 1, 1ULL, (V[]){v_e_24675}), v_st_24674});
    }
    case TAG_Right: {
      V v_x_24676 = heff_field(v_x11_24673, 0);
      V v_ru_24x11_24673_24Right = heff_take_reuse_n(v_x11_24673, 1ULL, 1);
      V v_st_24677 = (g_heff_2esyntax_2esurface_2esetScope(v_t_24669, v_st_24674));
      return heff_tag_at_n(v_ru_24x1_24672_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_re_n(v_ru_24x11_24673_24Right, TAG_Right, 1, 1ULL, (V[]){v_x_24676}), v_st_24677});
    }
    default: return heff_nomatch(v_x11_24673);
    }
  }
  default: return heff_nomatch(v_x1_24672);
  }
}
V g_heff_2esyntax_2esurface_2eexprL_lam41(V self, V *args) {
  V v_m_24705 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2esyntax_2esurface_2estmtL(v_r_240, v_m_24705));
}
V g_heff_2esyntax_2esurface_2eexprL_lam40(V self, V *args) {
  V v_st_24703 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_body_24656 = heff_env(self)[1];
  V v_t_24704 = heff_dup(heff_rfield(v_st_24703, 1));
  heff_clo_take(self, 2);
  V v_t_24706 = (g_prelude_2etraverse_24s499544530x2060473942(heff_clo_n(g_heff_2esyntax_2esurface_2eexprL_lam41, 1, 1, (V[]){v_r_240}), v_body_24656));
  V v_x1_24707 = heff_tr(heff_call(v_t_24706, 1, (V[]){v_st_24703}));
  switch (heff_tag_of(v_x1_24707)) {
  case TAG_MkPair: {
    V v_x11_24708 = heff_field(v_x1_24707, 0);
    V v_st_24709 = heff_field(v_x1_24707, 1);
    V v_ru_24x1_24707_24MkPair = heff_take_reuse_n(v_x1_24707, 3ULL, 2);
    switch (heff_tag_of(v_x11_24708)) {
    case TAG_Left: {
      V v_e_24710 = heff_field(v_x11_24708, 0);
      V v_ru_24x11_24708_24Left = heff_take_reuse_n(v_x11_24708, 1ULL, 1);
      heff_drop(v_t_24704);
      return heff_tag_re_n(v_ru_24x1_24707_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x11_24708_24Left, TAG_Left, 1, 1ULL, (V[]){v_e_24710}), v_st_24709});
    }
    case TAG_Right: {
      V v_x_24711 = heff_field(v_x11_24708, 0);
      V v_ru_24x11_24708_24Right = heff_take_reuse_n(v_x11_24708, 1ULL, 1);
      V v_st_24712 = (g_heff_2esyntax_2esurface_2esetScope(v_t_24704, v_st_24709));
      return heff_tag_at_n(v_ru_24x1_24707_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_re_n(v_ru_24x11_24708_24Right, TAG_Right, 1, 1ULL, (V[]){v_x_24711}), v_st_24712});
    }
    default: return heff_nomatch(v_x11_24708);
    }
  }
  default: return heff_nomatch(v_x1_24707);
  }
}
V g_heff_2esyntax_2esurface_2eexprL_lam42(V self, V *args) {
  V v_b_24741 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_r_240; V a_1 = v_b_24741; V r_ = (g_heff_2esyntax_2esurface_2ebindingL(a_0, a_1)); heff_drop(v_b_24741); r_; });
}
V g_heff_2esyntax_2esurface_2eexprL_lam43(V self, V *args) {
  V v_st_24752 = args[0];
  V v_t_24753 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24753, v_st_24752});
}
V g_heff_2esyntax_2esurface_2eexprL_lam44(V self, V *args) {
  V v_st_24758 = args[0];
  V v_m_24757 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24759 = heff_tr(heff_call(v_m_24757, 1, (V[]){v_st_24758}));
  switch (heff_tag_of(v_x1_24759)) {
  case TAG_MkPair: {
    V v_x11_24760 = heff_field(v_x1_24759, 0);
    V v_st_24761 = heff_field(v_x1_24759, 1);
    V v_ru_24x1_24759_24MkPair = heff_take_reuse_n(v_x1_24759, 3ULL, 2);
    switch (heff_tag_of(v_x11_24760)) {
    case TAG_Left: {
      V v_e_24762 = heff_field(v_x11_24760, 0);
      V v_ru_24x11_24760_24Left = heff_take_reuse_n(v_x11_24760, 1ULL, 1);
      return heff_tag_re_n(v_ru_24x1_24759_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x11_24760_24Left, TAG_Left, 1, 1ULL, (V[]){v_e_24762}), v_st_24761});
    }
    case TAG_Right: {
      V v_x_24763 = heff_field(v_x11_24760, 0);
      V v_ru_24x11_24760_24Right = heff_take_reuse_n(v_x11_24760, 1ULL, 1);
      V v_t_24764 = heff_tag_at_n(v_ru_24x11_24760_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Just, 1, (V[]){v_x_24763})});
      return heff_tag_re_n(v_ru_24x1_24759_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){v_t_24764, v_st_24761});
    }
    default: return heff_nomatch(v_x11_24760);
    }
  }
  default: return heff_nomatch(v_x1_24759);
  }
}
V g_heff_2esyntax_2esurface_2eexprL_lam46(V self, V *args) {
  V v_m_24775 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2esyntax_2esurface_2estmtL(v_r_240, v_m_24775));
}
V g_heff_2esyntax_2esurface_2eexprL_lam45(V self, V *args) {
  V v_st_24773 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_body_24740 = heff_env(self)[1];
  V v_t_24774 = heff_dup(heff_rfield(v_st_24773, 1));
  heff_clo_take(self, 2);
  V v_t_24776 = (g_prelude_2etraverse_24s499544530x2060473942(heff_clo_n(g_heff_2esyntax_2esurface_2eexprL_lam46, 1, 1, (V[]){v_r_240}), v_body_24740));
  V v_x1_24777 = heff_tr(heff_call(v_t_24776, 1, (V[]){v_st_24773}));
  switch (heff_tag_of(v_x1_24777)) {
  case TAG_MkPair: {
    V v_x11_24778 = heff_field(v_x1_24777, 0);
    V v_st_24779 = heff_field(v_x1_24777, 1);
    V v_ru_24x1_24777_24MkPair = heff_take_reuse_n(v_x1_24777, 3ULL, 2);
    switch (heff_tag_of(v_x11_24778)) {
    case TAG_Left: {
      V v_e_24780 = heff_field(v_x11_24778, 0);
      V v_ru_24x11_24778_24Left = heff_take_reuse_n(v_x11_24778, 1ULL, 1);
      heff_drop(v_t_24774);
      return heff_tag_re_n(v_ru_24x1_24777_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x11_24778_24Left, TAG_Left, 1, 1ULL, (V[]){v_e_24780}), v_st_24779});
    }
    case TAG_Right: {
      V v_x_24781 = heff_field(v_x11_24778, 0);
      V v_ru_24x11_24778_24Right = heff_take_reuse_n(v_x11_24778, 1ULL, 1);
      V v_st_24782 = (g_heff_2esyntax_2esurface_2esetScope(v_t_24774, v_st_24779));
      return heff_tag_at_n(v_ru_24x1_24777_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_re_n(v_ru_24x11_24778_24Right, TAG_Right, 1, 1ULL, (V[]){v_x_24781}), v_st_24782});
    }
    default: return heff_nomatch(v_x11_24778);
    }
  }
  default: return heff_nomatch(v_x1_24777);
  }
}
HEFF_LIT(g_heff_2esyntax_2esurface_2edeclNameOf_24cpr_str0, 0, "");

HeffT2 g_heff_2esyntax_2esurface_2edeclNameOf_24cpr(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return ((HeffT2){{((V)&g_heff_2esyntax_2esurface_2edeclNameOf_24cpr_str0), heff_rec_n(2, shape_start__end, (V[]){MK_INT(0LL), MK_INT(0LL)})}});
  }
  case TAG_Cons: {
    V v_t_241 = heff_field(v_x1_240, 0);
    V v_x12_242 = heff_field(v_x1_240, 1);
    V v_text_243 = heff_dup(heff_rfield(v_t_241, 1));
    V v_start_244 = heff_dup(heff_rfield(v_t_241, 3));
    V v_end_245 = heff_dup(heff_rfield(v_t_241, 4));
    switch (heff_tag_of(v_x12_242)) {
    case TAG_Nil: {
      V v_f_246 = v_text_243;
      V v_f_247 = heff_rec_n(2, shape_start__end, (V[]){v_start_244, v_end_245});
      return ((HeffT2){{v_f_246, v_f_247}});
    }
    case TAG_Cons: {
      V v_op_248 = heff_field(v_x12_242, 0);
      V v_x122_249 = heff_field(v_x12_242, 1);
      V v_text_2410 = heff_dup(heff_rfield(v_op_248, 1));
      V v_start_2411 = heff_dup(heff_rfield(v_op_248, 3));
      V v_end_2412 = heff_dup(heff_rfield(v_op_248, 4));
      switch (heff_tag_of(v_x122_249)) {
      case TAG_Nil: {
        heff_drop(v_text_2410);
        heff_drop(v_start_2411);
        heff_drop(v_end_2412);
        V v_f_2413 = v_text_243;
        V v_f_2414 = heff_rec_n(2, shape_start__end, (V[]){v_start_244, v_end_245});
        return ((HeffT2){{v_f_2413, v_f_2414}});
      }
      case TAG_Cons: {
        V v_x1222_2416 = heff_field(v_x122_249, 1);
        switch (heff_tag_of(v_x1222_2416)) {
        case TAG_Nil: {
          heff_drop(v_text_243);
          heff_drop(v_start_244);
          heff_drop(v_end_245);
          V v_f_2417 = v_text_2410;
          V v_f_2418 = heff_rec_n(2, shape_start__end, (V[]){v_start_2411, v_end_2412});
          return ((HeffT2){{v_f_2417, v_f_2418}});
        }
        case TAG_Cons: {
          heff_drop(v_text_2410);
          heff_drop(v_start_2411);
          heff_drop(v_end_2412);
          V v_f_2421 = v_text_243;
          V v_f_2422 = heff_rec_n(2, shape_start__end, (V[]){v_start_244, v_end_245});
          return ((HeffT2){{v_f_2421, v_f_2422}});
        }
        default: return ((HeffT2){{heff_nomatch(v_x1222_2416)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x122_249)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x12_242)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
Clo g_heff_2esyntax_2esurface_2erightsOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2erightsOf_entry, 1, 0};

V g_heff_2esyntax_2esurface_2erightsOf(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_Left: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Right: {
      V v_x_244 = heff_field(v_x11_241, 0);
      heff_take_n(v_x11_241, 1ULL, 1);
      V v_cell_245 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_244, heff_hole()});
      V v_u_246 = (g_heff_2esyntax_2esurface_2erightsOf_24dps(v_rest_242, v_cell_245));
      heff_drop(v_u_246);
      return v_cell_245;
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2esurface_2erightsOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2erightsOf(a[0]);
}
HEFF_LIT(g_heff_2esyntax_2esurface_2eprescanGo_str0, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2esurface_2eprescanGo_str1, 6, "mutual");
HEFF_LIT(g_heff_2esyntax_2esurface_2eprescanGo_str2, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2esurface_2eprescanGo_str3, 4, "data");
HEFF_LIT(g_heff_2esyntax_2esurface_2eprescanGo_str4, 4, "type");
HEFF_LIT(g_heff_2esyntax_2esurface_2eprescanGo_str5, 6, "theory");
HEFF_LIT(g_heff_2esyntax_2esurface_2eprescanGo_str6, 8, "instance");
HEFF_LIT(g_heff_2esyntax_2esurface_2eprescanGo_str7, 3, "var");
HEFF_LIT(g_heff_2esyntax_2esurface_2eprescanGo_str8, 3, "con");
HEFF_LIT(g_heff_2esyntax_2esurface_2eprescanGo_str9, 3, "sym");
HEFF_LIT(g_heff_2esyntax_2esurface_2eprescanGo_str10, 1, ":");
HEFF_LIT(g_heff_2esyntax_2esurface_2eprescanGo_str11, 3, "var");
HEFF_LIT(g_heff_2esyntax_2esurface_2eprescanGo_str12, 3, "con");
HEFF_LIT(g_heff_2esyntax_2esurface_2eprescanGo_str13, 1, ",");
Clo g_heff_2esyntax_2esurface_2eprescanGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eprescanGo_entry, 4, 0};

V g_heff_2esyntax_2esurface_2eprescanGo(V v_ts_240, V v_box_24k_241, V v_inMutual_242, V v_acc_243) {
  int64_t v_k_241 = heff_unbox_word(v_box_24k_241);
top: ;
  if (((((int64_t)0ULL) <= v_k_241) && (v_k_241 < heff_unbox_word(heff_arrayLength_lent(v_ts_240, 0))))) {
    V v_t_244 = heff_arrayIndexIn_lent(v_ts_240, heff_box_word(v_k_241), 2);
    V v_first_245 = heff_take_field(v_t_244, 6);
    V v_col_246 = heff_take_field(v_t_244, 5);
    V v_kind_247 = heff_take_field(v_t_244, 0);
    V v_text_248 = heff_get_n(v_t_244, 1, 7);
    int64_t v_i_249 = (v_k_241 + ((int64_t)1ULL));
    if (((((int64_t)0ULL) <= v_i_249) && (v_i_249 < heff_unbox_word(heff_arrayLength_lent(v_ts_240, 0))))) {
      V v_u_2410 = heff_arrayIndexIn_lent(v_ts_240, heff_box_word(v_i_249), 2);
      V v_text_2411 = heff_take_field(v_u_2410, 1);
      V v_kind_2412 = heff_get_n(v_u_2410, 0, 7);
      if (((heff_dup(v_first_245) == NTAG(TAG_True)) && (heff_intEq_c_lent(v_col_246, MK_INT(0LL), 2) && (heff_strEq_c_lent(v_kind_247, ((V)&g_heff_2esyntax_2esurface_2eprescanGo_str0), 2) && heff_strEq_c_lent(v_text_248, ((V)&g_heff_2esyntax_2esurface_2eprescanGo_str1), 2))))) {
        heff_drop(v_inMutual_242);
        heff_drop(v_first_245);
        heff_drop(v_col_246);
        heff_drop(v_kind_247);
        heff_drop(v_text_248);
        heff_drop(v_text_2411);
        heff_drop(v_kind_2412);
        V t_0 = v_ts_240;
        int64_t t_1 = (v_k_241 + ((int64_t)1ULL));
        V t_2 = NTAG(TAG_True);
        V t_3 = v_acc_243;
        v_ts_240 = t_0;
        v_k_241 = t_1;
        v_inMutual_242 = t_2;
        v_acc_243 = t_3;
        goto top;
      } else {
        if (((heff_dup(v_first_245) == NTAG(TAG_True)) && (heff_intEq_c_lent(v_col_246, MK_INT(0LL), 2) && (heff_strEq_c_lent(v_kind_247, ((V)&g_heff_2esyntax_2esurface_2eprescanGo_str2), 2) && (heff_strEq_c_lent(v_text_248, ((V)&g_heff_2esyntax_2esurface_2eprescanGo_str3), 2) || (heff_strEq_c_lent(v_text_248, ((V)&g_heff_2esyntax_2esurface_2eprescanGo_str4), 2) || (heff_strEq_c_lent(v_text_248, ((V)&g_heff_2esyntax_2esurface_2eprescanGo_str5), 2) || heff_strEq_c_lent(v_text_248, ((V)&g_heff_2esyntax_2esurface_2eprescanGo_str6), 2)))))))) {
          heff_drop(v_inMutual_242);
          heff_drop(v_first_245);
          heff_drop(v_col_246);
          heff_drop(v_kind_247);
          heff_drop(v_text_248);
          heff_drop(v_kind_2412);
          V t_0 = v_ts_240;
          int64_t t_1 = (v_k_241 + ((int64_t)1ULL));
          V t_2 = NTAG(TAG_False);
          V t_3 = heff_tag_n(TAG_Cons, 2, (V[]){v_text_2411, v_acc_243});
          v_ts_240 = t_0;
          v_k_241 = t_1;
          v_inMutual_242 = t_2;
          v_acc_243 = t_3;
          goto top;
        } else {
          if (((heff_dup(v_first_245) == NTAG(TAG_True)) && ((heff_intEq_c_lent(v_col_246, MK_INT(0LL), 2) || (heff_dup(v_inMutual_242) == NTAG(TAG_True))) && ((heff_strEq_c_lent(v_kind_247, ((V)&g_heff_2esyntax_2esurface_2eprescanGo_str7), 2) || heff_strEq_c_lent(v_kind_247, ((V)&g_heff_2esyntax_2esurface_2eprescanGo_str8), 2)) && (heff_strEq_c_lent(v_kind_2412, ((V)&g_heff_2esyntax_2esurface_2eprescanGo_str9), 2) && heff_strEq_c_lent(v_text_2411, ((V)&g_heff_2esyntax_2esurface_2eprescanGo_str10), 2)))))) {
            heff_drop(v_first_245);
            heff_drop(v_kind_247);
            heff_drop(v_text_2411);
            heff_drop(v_kind_2412);
            V v_t_2413 = heff_bool(((heff_dup(v_inMutual_242) == NTAG(TAG_True)) && heff_intLt_c_lent(MK_INT(0LL), v_col_246, 1)));
            heff_drop(v_inMutual_242);
            heff_drop(v_col_246);
            V t_0 = v_ts_240;
            int64_t t_1 = (v_k_241 + ((int64_t)1ULL));
            V t_2 = v_t_2413;
            V t_3 = heff_tag_n(TAG_Cons, 2, (V[]){v_text_248, v_acc_243});
            v_ts_240 = t_0;
            v_k_241 = t_1;
            v_inMutual_242 = t_2;
            v_acc_243 = t_3;
            goto top;
          } else {
            heff_drop(v_text_248);
            heff_drop(v_kind_2412);
            if (((heff_dup(v_first_245) == NTAG(TAG_True)) && ((heff_intEq_c_lent(v_col_246, MK_INT(0LL), 2) || (heff_dup(v_inMutual_242) == NTAG(TAG_True))) && ((heff_strEq_c_lent(v_kind_247, ((V)&g_heff_2esyntax_2esurface_2eprescanGo_str11), 2) || heff_strEq_c_lent(v_kind_247, ((V)&g_heff_2esyntax_2esurface_2eprescanGo_str12), 2)) && heff_strEq_c_lent(v_text_2411, ((V)&g_heff_2esyntax_2esurface_2eprescanGo_str13), 2))))) {
              heff_drop(v_first_245);
              heff_drop(v_kind_247);
              heff_drop(v_text_2411);
              V v_t_2414 = (g_heff_2esyntax_2esurface_2esigNamesFrom(v_ts_240, heff_box_word(v_k_241), NTAG(TAG_Nil)));
              V v_t_2415 = (g_heff_2esyntax_2esurface_2eappendS(v_t_2414, v_acc_243));
              V v_t_2416 = heff_bool(((heff_dup(v_inMutual_242) == NTAG(TAG_True)) && heff_intLt_c_lent(MK_INT(0LL), v_col_246, 1)));
              heff_drop(v_inMutual_242);
              heff_drop(v_col_246);
              V t_0 = v_ts_240;
              int64_t t_1 = (v_k_241 + ((int64_t)1ULL));
              V t_2 = v_t_2416;
              V t_3 = v_t_2415;
              v_ts_240 = t_0;
              v_k_241 = t_1;
              v_inMutual_242 = t_2;
              v_acc_243 = t_3;
              goto top;
            } else {
              heff_drop(v_kind_247);
              heff_drop(v_text_2411);
              V v_t_2417 = heff_bool(((heff_dup(v_inMutual_242) == NTAG(TAG_True)) && ((heff_dup(v_first_245) == NTAG(TAG_True)) ? !heff_intEq_c_lent(v_col_246, MK_INT(0LL), 2) : 1)));
              heff_drop(v_inMutual_242);
              heff_drop(v_first_245);
              heff_drop(v_col_246);
              V t_0 = v_ts_240;
              int64_t t_1 = (v_k_241 + ((int64_t)1ULL));
              V t_2 = v_t_2417;
              V t_3 = v_acc_243;
              v_ts_240 = t_0;
              v_k_241 = t_1;
              v_inMutual_242 = t_2;
              v_acc_243 = t_3;
              goto top;
            }
          }
        }
      }
    } else {
      heff_drop(v_first_245);
      heff_drop(v_col_246);
      heff_drop(v_kind_247);
      heff_drop(v_text_248);
      V t_0 = v_ts_240;
      int64_t t_1 = (v_k_241 + ((int64_t)1ULL));
      V t_2 = v_inMutual_242;
      V t_3 = v_acc_243;
      v_ts_240 = t_0;
      v_k_241 = t_1;
      v_inMutual_242 = t_2;
      v_acc_243 = t_3;
      goto top;
    }
  } else {
    heff_drop(v_inMutual_242);
    return (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_243));
  }
}
V g_heff_2esyntax_2esurface_2eprescanGo_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2esurface_2eprescanGo(a0, a[1], a[2], a[3]); heff_drop(a0); return r;
}
Clo g_heff_2esyntax_2esurface_2edropN_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2edropN_entry, 2, 0};

V g_heff_2esyntax_2esurface_2edropN(V v_n_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_n_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (heff_intLe_c_lent(v_n_240, MK_INT(0LL), 2)) {
      heff_drop(v_n_240);
      return heff_tag_re_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, 3ULL, (V[]){v_x_242, v_rest_243});
    } else {
      heff_drop(v_x_242);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = heff_intSub(v_n_240, MK_INT(1LL));
      V t_1 = v_rest_243;
      v_n_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2esurface_2edropN_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2edropN(a[0], a[1]);
}
HEFF_LIT(g_heff_2esyntax_2esurface_2ecycleDiag_str0, 15, "the fixity of `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecycleDiag_str1, 19, "` is declared twice");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecycleDiag_str2, 26, "these fixities go round: `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecycleDiag_str3, 22, "` ends up above itself");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecycleDiag_str4, 26, "these fixities go round: `");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecycleDiag_str5, 22, "` ends up above itself");
V g_heff_2esyntax_2esurface_2ecycleDiag_lam1(V self, V *args);
V g_heff_2esyntax_2esurface_2ecycleDiag_lam0(V self, V *args);
Clo g_heff_2esyntax_2esurface_2ecycleDiag_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2ecycleDiag_entry, 2, 0};

V g_heff_2esyntax_2esurface_2ecycleDiag(V v_all_240, V v_d_241) {
top: ;
  V v_ops_242 = heff_take_field(v_d_241, 1);
  V v_span_243 = heff_get_n(v_d_241, 6, 8);
  V v_t_244 = heff_dup(v_ops_242);
  switch (heff_tag_of(v_t_244)) {
  case TAG_Nil: {
    heff_drop_rec(v_all_240, 2);
    heff_drop(v_ops_242);
    heff_drop(v_span_243);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_g_245 = heff_field(v_t_244, 0);
    V v_ru_24t_244_24Cons = heff_take_reuse_n(v_t_244, 1ULL, 2);
    V v_t_2411 = ({ V a_0 = MK_INT(150LL); V a_1 = ((V)&g_heff_2esyntax_2esurface_2ecycleDiag_str0); V a_2 = ((V)&g_heff_2esyntax_2esurface_2ecycleDiag_str1); V b_3 = heff_clo_n(g_heff_2esyntax_2esurface_2ecycleDiag_lam0, 1, 2, (V[]){heff_dup(v_g_245), heff_dup(v_all_240)}); V a_4 = v_ops_242; V r_ = (g_list_2emap_24f2053285389x511622380(a_0, a_1, a_2, b_3, a_4)); heff_drop(b_3); r_; });
    V v_from_2412 = heff_dup(heff_rfield(v_g_245, 1));
    V v_to_2413 = heff_dup(heff_rfield(v_g_245, 1));
    V v_xs_2414 = (g_heff_2esyntax_2efixity_2elosers(heff_dup(v_all_240), v_from_2412));
    V v_t_2415 = ({ V a_0 = v_to_2413; V a_1 = v_xs_2414; V r_ = (g_list_2eany_24s1006624359x760861690(a_0, a_1)); heff_drop(v_xs_2414); r_; });
    V v_t_2423;
    if ((heff_dup(v_t_2415) == NTAG(TAG_True))) {
      heff_drop_rec(v_all_240, 2);
      heff_drop(v_from_2412);
      heff_drop(v_to_2413);
      heff_drop(v_t_2415);
      V v_t_2416 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ecycleDiag_str2), heff_get_n(v_g_245, 1, 7));
      V v_t_2417 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), heff_strAppend(v_t_2416, ((V)&g_heff_2esyntax_2esurface_2ecycleDiag_str3)), v_span_243, NTAG(TAG_Nothing)});
      v_t_2423 = heff_tag_at_n(v_ru_24t_244_24Cons, TAG_Cons, 2, (V[]){v_t_2417, NTAG(TAG_Nil)});
    } else {
      heff_drop(v_t_2415);
      V v_ys_2418 = (g_heff_2esyntax_2efixity_2elosers(heff_dup(v_all_240), v_from_2412));
      V v_t_2419 = heff_tag_at_n(v_ru_24t_244_24Cons, TAG_Cons, 2, (V[]){v_from_2412, NTAG(TAG_Nil)});
      V v_t_2420 = ({ V a_0 = v_all_240; V a_1 = v_to_2413; V a_2 = v_ys_2418; V a_3 = v_t_2419; V r_ = (g_heff_2esyntax_2efixity_2etighterGo(a_0, a_1, a_2, a_3)); heff_drop_rec(v_all_240, 2); heff_drop(v_to_2413); r_; });
      if ((heff_dup(v_t_2420) == NTAG(TAG_True))) {
        heff_drop(v_t_2420);
        V v_t_2421 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2ecycleDiag_str4), heff_get_n(v_g_245, 1, 7));
        V v_t_2422 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), heff_strAppend(v_t_2421, ((V)&g_heff_2esyntax_2esurface_2ecycleDiag_str5)), v_span_243, NTAG(TAG_Nothing)});
        v_t_2423 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2422, NTAG(TAG_Nil)});
      } else {
        heff_drop(v_span_243);
        heff_drop_rec(v_g_245, 7);
        heff_drop(v_t_2420);
        v_t_2423 = NTAG(TAG_Nil);
      }
    }
    HEFF_LAST return g_heff_2esyntax_2esurface_2eappendS(v_t_2411, v_t_2423);
  }
  default: return heff_nomatch(v_t_244);
  }
}
V g_heff_2esyntax_2esurface_2ecycleDiag_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2ecycleDiag(a[0], a[1]);
}
V g_heff_2esyntax_2esurface_2ecycleDiag_lam1(V self, V *args) {
  V v_h_248 = args[0];
  V v_g_245 = heff_env(self)[0];
  V v_u_247 = heff_env(self)[1];
  V v_id_249 = heff_take_field(v_h_248, 0);
  V v_ops_2410 = heff_get_n(v_h_248, 2, 5);
  if (!heff_strEq_c(heff_dup(v_id_249), heff_dup(heff_rfield(v_g_245, 1)))) {
    heff_clo_take(self, 2);
    heff_drop_rec(v_g_245, 7);
    heff_drop(v_id_249);
    return ({ V a_0 = v_u_247; V a_1 = v_ops_2410; V r_ = (g_list_2eany_24s1137631697x622554211(a_0, a_1)); heff_drop(v_u_247); heff_drop(v_ops_2410); r_; });
  } else {
    heff_drop(self);
    heff_drop(v_id_249);
    heff_drop(v_ops_2410);
    return NTAG(TAG_False);
  }
}
V g_heff_2esyntax_2esurface_2ecycleDiag_lam0(V self, V *args) {
  V v_u_247 = args[0];
  V v_g_245 = heff_env(self)[0];
  V v_all_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return ({ V b_0 = heff_clo_n(g_heff_2esyntax_2esurface_2ecycleDiag_lam1, 1, 2, (V[]){v_g_245, v_u_247}); V b_1 = heff_get_n(v_all_240, 0, 2); V r_ = (g_heff_2esyntax_2esurface_2eanyS(b_0, b_1)); heff_drop(b_0); heff_drop(b_1); r_; });
}
V g_heff_2esyntax_2esurface_2edataL_24s2041319846x1615558476_24cpr_lam0(V self, V *args);
V g_heff_2esyntax_2esurface_2edataL_24s2041319846x1615558476_24cpr_lam1(V self, V *args);
V g_heff_2esyntax_2esurface_2edataL_24s2041319846x1615558476_24cpr_lam2(V self, V *args);

HeffT2 g_heff_2esyntax_2esurface_2edataL_24s2041319846x1615558476_24cpr(V v_d_240, V v_kw_241, V v_name_242, V v_params_243, V v_universe_244, V v_alts_245, V v_z_246) {
top: ;
  V v_start_247 = heff_take_field(v_name_242, 3);
  V v_end_248 = heff_take_field(v_name_242, 4);
  V v_text_249 = heff_get_n(v_name_242, 1, 9);
  V v_m_2410 = (g_prelude_2etraverse_24s518454301x170091462(v_params_243));
  V v_x1_2411 = heff_tr(heff_call(v_m_2410, 1, (V[]){v_z_246}));
  switch (heff_tag_of(v_x1_2411)) {
  case TAG_MkPair: {
    V v_x11_2412 = heff_field(v_x1_2411, 0);
    V v_st_2413 = heff_field(v_x1_2411, 1);
    heff_take_n(v_x1_2411, 3ULL, 2);
    switch (heff_tag_of(v_x11_2412)) {
    case TAG_Left: {
      V v_e_2414 = heff_field(v_x11_2412, 0);
      V v_ru_24x11_2412_24Left = heff_take_reuse_n(v_x11_2412, 1ULL, 1);
      heff_drop(v_d_240);
      heff_drop_rec(v_kw_241, 9);
      heff_drop(v_start_247);
      heff_drop(v_end_248);
      heff_drop(v_text_249);
      return ((HeffT2){{heff_tag_re_n(v_ru_24x11_2412_24Left, TAG_Left, 1, 1ULL, (V[]){v_e_2414}), v_st_2413}});
    }
    case TAG_Right: {
      V v_x_2415 = heff_field(v_x11_2412, 0);
      heff_take_n(v_x11_2412, 1ULL, 1);
      V v_t_2416 = (g_list_2emap_24s1059370217x1267747283(heff_dup(v_x_2415)));
      V v_m_2424;
      switch (heff_tag_of(v_universe_244)) {
      case TAG_Nothing: {
        v_m_2424 = heff_clo_n(g_heff_2esyntax_2esurface_2edataL_24s2041319846x1615558476_24cpr_lam0, 1, 2, (V[]){heff_dup(v_start_247), heff_dup(v_end_248)});
        break;
      }
      case TAG_Just: {
        V v_it1_2420 = heff_field(v_universe_244, 0);
        switch (heff_tag_of(v_it1_2420)) {
        case TAG_MkPair: {
          V v_u_2422 = heff_field(v_it1_2420, 1);
          v_m_2424 = heff_clo_n(g_heff_2esyntax_2esurface_2edataL_24s2041319846x1615558476_24cpr_lam1, 1, 1, (V[]){heff_dup(v_u_2422)});
          break;
        }
        default: heff_nomatch(v_it1_2420);
        }
        break;
      }
      default: heff_nomatch(v_universe_244);
      }
      return (g_heff_2esyntax_2esurface_2ewithScope_24cpr(v_t_2416, heff_clo_n(g_heff_2esyntax_2esurface_2edataL_24s2041319846x1615558476_24cpr_lam2, 1, 8, (V[]){v_m_2424, heff_dup(v_alts_245), v_d_240, v_kw_241, v_text_249, v_start_247, v_end_248, v_x_2415}), v_st_2413));
    }
    default: return ((HeffT2){{heff_nomatch(v_x11_2412)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_2411)}});
  }
}
V g_heff_2esyntax_2esurface_2edataL_24s2041319846x1615558476_24cpr_lam0(V self, V *args) {
  V v_st_2417 = args[0];
  V v_start_247 = heff_env(self)[0];
  V v_end_248 = heff_env(self)[1];
  V v_t_2418 = heff_tag_n(TAG_EWord, 1, (V[]){NTAG(TAG_TypeWord)});
  heff_clo_take(self, 2);
  V v_t_2419 = heff_tag_n(TAG_At, 2, (V[]){v_t_2418, heff_rec_n(2, shape_start__end, (V[]){v_start_247, v_end_248})});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2419}), v_st_2417});
}
V g_heff_2esyntax_2esurface_2edataL_24s2041319846x1615558476_24cpr_lam1(V self, V *args) {
  V v_st_2423 = args[0];
  V v_u_2422 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2esyntax_2esurface_2eexprL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), v_u_2422, v_st_2423));
}
V g_heff_2esyntax_2esurface_2edataL_24s2041319846x1615558476_24cpr_lam2(V self, V *args) {
  V v_st_2425 = args[0];
  V v_m_2424 = heff_env(self)[0];
  V v_alts_245 = heff_env(self)[1];
  V v_d_240 = heff_env(self)[2];
  V v_kw_241 = heff_env(self)[3];
  V v_text_249 = heff_env(self)[4];
  V v_start_247 = heff_env(self)[5];
  V v_end_248 = heff_env(self)[6];
  V v_x_2415 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_x1_2426 = heff_tr(heff_call(v_m_2424, 1, (V[]){v_st_2425}));
  switch (heff_tag_of(v_x1_2426)) {
  case TAG_MkPair: {
    V v_x11_2427 = heff_field(v_x1_2426, 0);
    V v_st_2428 = heff_field(v_x1_2426, 1);
    V v_ru_24x1_2426_24MkPair = heff_take_reuse_n(v_x1_2426, 3ULL, 2);
    switch (heff_tag_of(v_x11_2427)) {
    case TAG_Left: {
      V v_e_2429 = heff_field(v_x11_2427, 0);
      V v_ru_24x11_2427_24Left = heff_take_reuse_n(v_x11_2427, 1ULL, 1);
      heff_drop(v_alts_245);
      heff_drop(v_d_240);
      heff_drop_rec(v_kw_241, 9);
      heff_drop(v_text_249);
      heff_drop(v_start_247);
      heff_drop(v_end_248);
      heff_drop(v_x_2415);
      return heff_tag_re_n(v_ru_24x1_2426_24MkPair, TAG_MkPair, 2, 2ULL, (V[]){heff_tag_re_n(v_ru_24x11_2427_24Left, TAG_Left, 1, 1ULL, (V[]){v_e_2429}), v_st_2428});
    }
    case TAG_Right: {
      V v_x_2430 = heff_field(v_x11_2427, 0);
      V v_ru_24x11_2427_24Right = heff_take_reuse_n(v_x11_2427, 1ULL, 1);
      V v_t_2435;
      switch (heff_tag_of(v_alts_245)) {
      case TAG_Nothing: {
        v_t_2435 = NTAG(TAG_Nil);
        break;
      }
      case TAG_Just: {
        V v_x11_2431 = heff_field(v_alts_245, 0);
        heff_take_n(v_alts_245, 1ULL, 1);
        switch (heff_tag_of(v_x11_2431)) {
        case TAG_MkDAlts: {
          V v_alts_2433 = heff_field(v_x11_2431, 1);
          heff_take_n(v_x11_2431, 2ULL, 3);
          v_t_2435 = v_alts_2433;
          break;
        }
        default: heff_nomatch(v_x11_2431);
        }
        break;
      }
      default: heff_nomatch(v_alts_245);
      }
      HeffT2 v_t_2436 = (g_prelude_2etraverse_24s1726903169x1952011622_24cpr(v_t_2435, v_st_2428));
      {
        V v_field_2437 = v_t_2436.f[0];
        V v_field_2438 = v_t_2436.f[1];
        V v_x11_2439 = v_field_2437;
        V v_st_2440 = v_field_2438;
        switch (heff_tag_of(v_x11_2439)) {
        case TAG_Left: {
          V v_e_2441 = heff_field(v_x11_2439, 0);
          V v_ru_24x11_2439_24Left = heff_take_reuse_n(v_x11_2439, 1ULL, 1);
          heff_drop(v_d_240);
          heff_drop_rec(v_kw_241, 9);
          heff_drop(v_text_249);
          heff_drop(v_start_247);
          heff_drop(v_end_248);
          heff_drop(v_x_2415);
          heff_drop(v_x_2430);
          heff_drop_cell(v_ru_24x11_2427_24Right, 1);
          return heff_tag_at_n(v_ru_24x1_2426_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_re_n(v_ru_24x11_2439_24Left, TAG_Left, 1, 1ULL, (V[]){v_e_2441}), v_st_2440});
        }
        case TAG_Right: {
          V v_x_2442 = heff_field(v_x11_2439, 0);
          V v_ru_24x11_2439_24Right = heff_take_reuse_n(v_x11_2439, 1ULL, 1);
          V v_t_2443 = (g_heff_2esyntax_2ecst_2elastD(heff_dup(v_d_240)));
          V v_e_2444 = heff_get_n(v_t_2443, 4, 9);
          V v_t_2445 = (g_heff_2esyntax_2ecst_2elastD(v_d_240));
          V v_e_2446 = heff_get_n(v_t_2445, 4, 9);
          V v_t_2447 = heff_rec_n(2, shape_start__end, (V[]){heff_dup(heff_rfield(v_kw_241, 3)), v_e_2444});
          V v_t_2448 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_2439_24Right, TAG_ESum, 1, (V[]){v_x_2442}), v_t_2447});
          V v_t_2449 = heff_tag_n(TAG_DeclDefine, 5, (V[]){v_text_249, heff_rec_n(2, shape_start__end, (V[]){v_start_247, v_end_248}), v_x_2415, v_x_2430, v_t_2448});
          V v_t_2450 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_241, 3, 9), v_e_2446});
          V v_t_2451 = heff_tag_n(TAG_Whole, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2449, v_t_2450})});
          V v_x_2452 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2451, NTAG(TAG_Nil)});
          return heff_tag_at_n(v_ru_24x1_2426_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_2427_24Right, TAG_Right, 1, (V[]){v_x_2452}), v_st_2440});
        }
        default: return heff_nomatch(v_x11_2439);
        }
      }
    }
    default: return heff_nomatch(v_x11_2427);
    }
  }
  default: return heff_nomatch(v_x1_2426);
  }
}
Clo g_heff_2esyntax_2esurface_2eappendS_24tok2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eappendS_24tok2_entry, 3, 0};

V g_heff_2esyntax_2esurface_2eappendS_24tok2(V v_tok_240, V v_x1_241, V v_ys_242) {
top: ;
  switch (heff_tag_of(v_x1_241)) {
  case TAG_Nil: {
    heff_drop_cell(v_tok_240, 2);
    return v_ys_242;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x1_241, 0);
    V v_xs_244 = heff_field(v_x1_241, 1);
    heff_take_n(v_x1_241, 3ULL, 2);
    V v_cell_245 = heff_tag_at_n(v_tok_240, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
    V v_u_246 = ({ V a_0 = v_xs_244; V a_1 = v_ys_242; V a_2 = v_cell_245; V r_ = (g_heff_2esyntax_2esurface_2eappendS_24dps(a_0, a_1, a_2)); heff_drop(v_ys_242); r_; });
    heff_drop(v_u_246);
    return v_cell_245;
  }
  default: return heff_nomatch(v_x1_241);
  }
}
V g_heff_2esyntax_2esurface_2eappendS_24tok2_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2eappendS_24tok2(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2esyntax_2esurface_2eparamOf_24tok1_str0, 42, "a parameter is `a`, `(x : T)` or `{x : T}`");
Clo g_heff_2esyntax_2esurface_2eparamOf_24tok1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eparamOf_24tok1_entry, 3, 0};

V g_heff_2esyntax_2esurface_2eparamOf_24tok1(V v_tok_240, V v_p_241, V v_z_242) {
top: ;
  HeffT2 v_t_243 = (g_heff_2esyntax_2esurface_2enameAnn_24cpr(v_p_241));
  {
    V v_field_245 = v_t_243.f[1];
    int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
    if ((v_tag_244 == ((int64_t)0ULL))) {
      V v_q_246 = v_field_245;
      V v_ty_247 = heff_take_field(v_q_246, 2);
      V v_name_248 = heff_take_field(v_q_246, 0);
      V v_span_249 = heff_get_n(v_q_246, 1, 3);
      V v_t_2410 = heff_dup(v_ty_247);
      V v_t_2413;
      switch (heff_tag_of(v_t_2410)) {
      case TAG_At: {
        V v_s_2412 = heff_field(v_t_2410, 1);
        heff_take_n(v_t_2410, 2ULL, 2);
        v_t_2413 = v_s_2412;
        break;
      }
      default: heff_nomatch(v_t_2410);
      }
      V v_t_2414 = ({ V rv_0 = heff_dup(heff_rfield(v_span_249, 0)); V rr_ = heff_rec_reuse_nf(v_t_2413, 2ULL, 2, shape_start__end, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
      V v_t_2415 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ExplicitParam, 3, (V[]){v_name_248, v_span_249, v_ty_247}), v_t_2414});
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_tok_240, TAG_Right, 1, (V[]){v_t_2415}), v_z_242});
    } else {
      heff_drop(v_field_245);
      V v_t_2418;
      switch (heff_tag_of(v_p_241)) {
      case TAG_At: {
        V v_s_2417 = heff_field(v_p_241, 1);
        v_t_2418 = heff_dup(v_s_2417);
        break;
      }
      default: heff_nomatch(v_p_241);
      }
      V v_t_2419 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2eparamOf_24tok1_str0), v_t_2418, NTAG(TAG_Nothing)});
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_tok_240, TAG_Left, 1, (V[]){v_t_2419}), v_z_242});
    }
  }
}
V g_heff_2esyntax_2esurface_2eparamOf_24tok1_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2esyntax_2esurface_2eparamOf_24tok1(a[0], a1, a[2]); heff_drop(a1); return r;
}