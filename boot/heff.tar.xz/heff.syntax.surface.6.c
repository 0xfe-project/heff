// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Ann 13421
#define TAG_App 13485
#define TAG_At 8900
#define TAG_Atom 28502
#define TAG_BAnn 9252
#define TAG_BImp 16911
#define TAG_BVar 29034
#define TAG_Braces 8205
#define TAG_Case 4415
#define TAG_Do 8988
#define TAG_EAlt 33043
#define TAG_EAnn 33099
#define TAG_EAssign 4102
#define TAG_EBinary 42634
#define TAG_EBreak 7195
#define TAG_ECatch 45587
#define TAG_ECon 35052
#define TAG_EContinue 48638
#define TAG_EDo 15964
#define TAG_EFDefault 38038
#define TAG_EFSet 34673
#define TAG_EField 26142
#define TAG_EFor 37939
#define TAG_EIfThen 2245
#define TAG_EInvalid 31081
#define TAG_EJump 55703
#define TAG_ELet 43397
#define TAG_ELetCond 24397
#define TAG_ELetIn 22786
#define TAG_ELetMut 54984
#define TAG_EMatch 41631
#define TAG_ENeg 45306
#define TAG_ENest 28629
#define TAG_EParen 58248
#define TAG_EReturn 59059
#define TAG_ESBind 62182
#define TAG_ESum 50613
#define TAG_ETag 50948
#define TAG_ETry 51493
#define TAG_EUSet 22856
#define TAG_EUpdate 6986
#define TAG_EVar 52881
#define TAG_EWhile 39339
#define TAG_EWith 38507
#define TAG_FloatValue 23118
#define TAG_If 9134
#define TAG_IfThen 36069
#define TAG_InstB 37114
#define TAG_IntValue 62477
#define TAG_Lam 23588
#define TAG_Left 13886
#define TAG_MkAlt 55173
#define TAG_MkSegment 38079
#define TAG_MkTry 8097
#define TAG_Named 2049
#define TAG_Op 9330
#define TAG_OpRhs 36076
#define TAG_Ops 26942
#define TAG_OtherValue 43098
#define TAG_Right 62770
#define TAG_RuneValue 49425
#define TAG_SError 24172
#define TAG_Seg 30433
#define TAG_SegmentBinary 41188
#define TAG_SegmentBits 43687
#define TAG_SegmentFloat 21180
#define TAG_SegmentInteger 22664
#define TAG_SegmentUtf 5205
#define TAG_SizeDefault 11444
#define TAG_StrValue 22621
#define TAG_Sum 30935
#define TAG_Tup 31899
#define TAG_Update 40810
#define LBL_code 9554612
#define LBL_e 319
#define LBL_end 310101
#define LBL_kind 9787483
#define LBL_little 844663329
#define LBL_msg 317947
#define LBL_note 9882809
#define LBL_op 10312
#define LBL_ops 319788
#define LBL_out 319944
#define LBL_pat 320285
#define LBL_severity 75955546
#define LBL_signed 1044674119
#define LBL_size 10026184
#define LBL_span 10032145
#define LBL_start 311115900
#define LBL_text 10052084
#define LBL_ty 10476
#define LBL_unit 10090059
static uint32_t shape_code__severity__msg__span__note[] = {LBL_code, LBL_severity, LBL_msg, LBL_span, LBL_note};
static uint32_t shape_op__e[] = {LBL_op, LBL_e};
static uint32_t shape_ops__out[] = {LBL_ops, LBL_out};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
static uint32_t shape_ty__size__unit__little__signed[] = {LBL_ty, LBL_size, LBL_unit, LBL_little, LBL_signed};
V g_heff_2esyntax_2ecst_2efirstE(V);
V g_heff_2esyntax_2ecst_2efirstE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2efirstE_clo;
V g_heff_2esyntax_2ecst_2elastE(V);
V g_heff_2esyntax_2ecst_2elastE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2elastE_clo;
V g_heff_2esyntax_2epresyntax_2eapp(V, V);
V g_heff_2esyntax_2epresyntax_2eapp_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eapp_clo;
V g_heff_2esyntax_2esurface_2ealtL(V, V);
V g_heff_2esyntax_2esurface_2ealtL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ealtL_clo;
V g_heff_2esyntax_2esurface_2eapplyOp(V, V, V);
V g_heff_2esyntax_2esurface_2eapplyOp_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eapplyOp_clo;
V g_heff_2esyntax_2esurface_2eargL(V, V);
V g_heff_2esyntax_2esurface_2eargL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eargL_clo;
V g_heff_2esyntax_2esurface_2eatomTok(V);
V g_heff_2esyntax_2esurface_2eatomTok_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eatomTok_clo;
V g_heff_2esyntax_2esurface_2eblock(V, V, V);
V g_heff_2esyntax_2esurface_2eblock_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eblock_clo;
HeffT2 g_heff_2esyntax_2esurface_2eblock_24cpr(V, V, V);
V g_heff_2esyntax_2esurface_2eboundBy(V, V);
V g_heff_2esyntax_2esurface_2eboundBy_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eboundBy_clo;
V g_heff_2esyntax_2esurface_2ebracesL(V, V, V, V, V);
V g_heff_2esyntax_2esurface_2ebracesL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ebracesL_clo;
V g_heff_2esyntax_2esurface_2ecatchL(V, V);
V g_heff_2esyntax_2esurface_2ecatchL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ecatchL_clo;
V g_heff_2esyntax_2esurface_2ecommentLinesFrom(V, V, V);
V g_heff_2esyntax_2esurface_2ecommentLinesFrom_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ecommentLinesFrom_clo;
V g_heff_2esyntax_2esurface_2econAtom(V, V, V);
V g_heff_2esyntax_2esurface_2econAtom_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2econAtom_clo;
V g_heff_2esyntax_2esurface_2econL(V, V, V);
V g_heff_2esyntax_2esurface_2econL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2econL_clo;
V g_heff_2esyntax_2esurface_2edeclarationL(V, V);
V g_heff_2esyntax_2esurface_2edeclarationL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2edeclarationL_clo;
V g_heff_2esyntax_2esurface_2edefaultL(V, V);
V g_heff_2esyntax_2esurface_2edefaultL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2edefaultL_clo;
V g_heff_2esyntax_2esurface_2eexprL(V, V, V);
V g_heff_2esyntax_2esurface_2eexprL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eexprL_clo;
HeffT2 g_heff_2esyntax_2esurface_2efieldsOf_24cpr(V, V);
V g_heff_2esyntax_2esurface_2efirstS(V, V, V, V);
V g_heff_2esyntax_2esurface_2efirstS_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2efirstS_clo;
V g_heff_2esyntax_2esurface_2efoldr(V, V, V);
V g_heff_2esyntax_2esurface_2efoldr_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2efoldr_clo;
V g_heff_2esyntax_2esurface_2eifE(V, V, V, V);
V g_heff_2esyntax_2esurface_2eifE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eifE_clo;
V g_heff_2esyntax_2esurface_2eifLetL(V, V, V, V, V, V, V);
V g_heff_2esyntax_2esurface_2eifLetL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eifLetL_clo;
V g_heff_2esyntax_2esurface_2eintOfText(V);
V g_heff_2esyntax_2esurface_2eintOfText_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eintOfText_clo;
V g_heff_2esyntax_2esurface_2ekwAtom(V, V, V);
V g_heff_2esyntax_2esurface_2ekwAtom_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ekwAtom_clo;
V g_heff_2esyntax_2esurface_2elambdaL(V, V, V, V);
V g_heff_2esyntax_2esurface_2elambdaL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2elambdaL_clo;
HeffT2 g_heff_2esyntax_2esurface_2eletBodyL_24cpr(V, V, V, V, V, V);
V g_heff_2esyntax_2esurface_2eletL(V, V, V);
V g_heff_2esyntax_2esurface_2eletL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eletL_clo;
V g_heff_2esyntax_2esurface_2eopL(V, V, V, V, V);
V g_heff_2esyntax_2esurface_2eopL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eopL_clo;
HeffT2 g_heff_2esyntax_2esurface_2eopRhsOf_24cpr(V);
V g_heff_2esyntax_2esurface_2eparenL(V, V, V, V, V);
V g_heff_2esyntax_2esurface_2eparenL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eparenL_clo;
V g_heff_2esyntax_2esurface_2epushS_24s1868233564x1858628873(V, V, V, V);
V g_heff_2esyntax_2esurface_2epushS_24s1868233564x1858628873_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2epushS_24s1868233564x1858628873_clo;
V g_heff_2esyntax_2esurface_2eresolve_24s1832151779x1448561609(V, V, V);
V g_heff_2esyntax_2esurface_2eresolve_24s1832151779x1448561609_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eresolve_24s1832151779x1448561609_clo;
V g_heff_2esyntax_2esurface_2erightsOf(V);
V g_heff_2esyntax_2esurface_2erightsOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2erightsOf_clo;
V g_heff_2esyntax_2esurface_2erightsOf_24dps(V, V);
V g_heff_2esyntax_2esurface_2erightsOf_24dps_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2erightsOf_24dps_clo;
V g_heff_2esyntax_2esurface_2esegmentL(V, V);
V g_heff_2esyntax_2esurface_2esegmentL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2esegmentL_clo;
V g_heff_2esyntax_2esurface_2esegmentOf_24s1547151193x813882637(V, V, V, V, V);
V g_heff_2esyntax_2esurface_2esegmentOf_24s1547151193x813882637_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2esegmentOf_24s1547151193x813882637_clo;
V g_heff_2esyntax_2esurface_2especWord(V, V, V);
V g_heff_2esyntax_2esurface_2especWord_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2especWord_clo;
V g_heff_2esyntax_2esurface_2estmtL(V, V);
V g_heff_2esyntax_2esurface_2estmtL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2estmtL_clo;
V g_heff_2esyntax_2esurface_2etryTypeL(V, V);
V g_heff_2esyntax_2esurface_2etryTypeL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2etryTypeL_clo;
V g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993(V, V, V, V, V);
V g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_clo;
V g_heff_2esyntax_2esurface_2eunitOf(V, V, V);
V g_heff_2esyntax_2esurface_2eunitOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eunitOf_clo;
V g_heff_2esyntax_2esurface_2eupdateSettingL(V, V);
V g_heff_2esyntax_2esurface_2eupdateSettingL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eupdateSettingL_clo;
HeffT2 g_heff_2esyntax_2esurface_2evalueKind_24cpr(V, V, V, V);
V g_heff_2esyntax_2esurface_2evarAtom(V, V, V);
V g_heff_2esyntax_2esurface_2evarAtom_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2evarAtom_clo;
V g_heff_2esyntax_2esurface_2evariantL(V, V);
V g_heff_2esyntax_2esurface_2evariantL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2evariantL_clo;
HeffT2 g_heff_2esyntax_2esurface_2ewithScope_24cpr(V, V, V);
V g_list_2emap_24s513201124x806973253(V);
V g_list_2emap_24s513201124x806973253_entry(V self, V *a);
extern Clo g_list_2emap_24s513201124x806973253_clo;
V g_prelude_2eskipSpaces(V, V, V);
V g_prelude_2eskipSpaces_entry(V self, V *a);
extern Clo g_prelude_2eskipSpaces_clo;
V g_prelude_2etraverse_24s499544530x2060473942(V, V);
V g_prelude_2etraverse_24s499544530x2060473942_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s499544530x2060473942_clo;
HEFF_LIT(g_heff_2esyntax_2esurface_2ecommentLinesFrom_str0, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecommentLinesFrom_str1, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecommentLinesFrom_str2, 2, "--");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecommentLinesFrom_str3, 1, "\012");
Clo g_heff_2esyntax_2esurface_2ecommentLinesFrom_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2ecommentLinesFrom_entry, 3, 0};

V g_heff_2esyntax_2esurface_2ecommentLinesFrom(V v_src_240, V v_i_241, V v_to_242) {
top: ;
  V v_j_243 = heff_strFind_lent(((V)&g_heff_2esyntax_2esurface_2ecommentLinesFrom_str0), v_src_240, v_i_241, 1);
  V v_t_245;
  if (heff_intLt_c_lent(v_j_243, MK_INT(0LL), 2)) {
    heff_drop(v_j_243);
    v_t_245 = heff_strLength_lent(v_src_240, 0);
  } else {
    v_t_245 = v_j_243;
  }
  if (heff_intLe_c_lent(v_to_242, v_t_245, 2)) {
    heff_drop(v_i_241);
    heff_drop(v_to_242);
    return NTAG(TAG_True);
  } else {
    V v_j_247 = heff_strFind_lent(((V)&g_heff_2esyntax_2esurface_2ecommentLinesFrom_str1), v_src_240, v_i_241, 1);
    V v_t_249;
    if (heff_intLt_c_lent(v_j_247, MK_INT(0LL), 2)) {
      heff_drop(v_j_247);
      v_t_249 = heff_strLength_lent(v_src_240, 0);
    } else {
      v_t_249 = v_j_247;
    }
    V v_s_2410 = heff_strSlice_lent(v_src_240, v_i_241, v_t_249, 4);
    V v_t_2411 = (g_prelude_2eskipSpaces(v_s_2410, MK_INT(0LL), MK_INT(1LL)));
    int64_t v_t_2412 = (heff_unbox_word(heff_strLength_lent(v_s_2410, 0)) - ((int64_t)1ULL));
    V v_t_2413 = (g_prelude_2eskipSpaces(v_s_2410, heff_box_word(v_t_2412), MK_INT(-1LL)));
    V v_s_2414 = heff_strSlice(v_s_2410, v_t_2411, heff_intAdd(v_t_2413, MK_INT(1LL)));
    if (heff_strEq_c(heff_strSlice(v_s_2414, MK_INT(0LL), MK_INT(2LL)), ((V)&g_heff_2esyntax_2esurface_2ecommentLinesFrom_str2))) {
      V v_j_2416 = heff_strFind_lent(((V)&g_heff_2esyntax_2esurface_2ecommentLinesFrom_str3), v_src_240, v_i_241, 5);
      V v_t_2418;
      if (heff_intLt_c_lent(v_j_2416, MK_INT(0LL), 2)) {
        heff_drop(v_j_2416);
        v_t_2418 = heff_strLength_lent(v_src_240, 0);
      } else {
        v_t_2418 = v_j_2416;
      }
      V t_0 = v_src_240;
      V t_1 = heff_intAdd(v_t_2418, MK_INT(1LL));
      V t_2 = v_to_242;
      v_src_240 = t_0;
      v_i_241 = t_1;
      v_to_242 = t_2;
      goto top;
    } else {
      heff_drop(v_i_241);
      heff_drop(v_to_242);
      return NTAG(TAG_False);
    }
  }
}
V g_heff_2esyntax_2esurface_2ecommentLinesFrom_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2esurface_2ecommentLinesFrom(a0, a[1], a[2]); heff_drop(a0); return r;
}
V g_heff_2esyntax_2esurface_2eletBodyL_24cpr_lam0(V self, V *args);

HeffT2 g_heff_2esyntax_2esurface_2eletBodyL_24cpr(V v_r_240, V v_kw_241, V v_x3_242, V v_names_243, V v_body_244, V v_z_245) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_MkPair: {
    V v_p_246 = heff_field(v_x3_242, 0);
    V v_rhs_247 = heff_field(v_x3_242, 1);
    heff_take_n(v_x3_242, 3ULL, 2);
    V v_m_248 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_body_244)}));
    return (g_heff_2esyntax_2esurface_2ewithScope_24cpr(v_names_243, heff_clo_n(g_heff_2esyntax_2esurface_2eletBodyL_24cpr_lam0, 1, 5, (V[]){v_m_248, v_p_246, v_body_244, v_kw_241, v_rhs_247}), v_z_245));
  }
  default: return ((HeffT2){{heff_nomatch(v_x3_242)}});
  }
}
V g_heff_2esyntax_2esurface_2eletBodyL_24cpr_lam0(V self, V *args) {
  V v_st_249 = args[0];
  V v_m_248 = heff_env(self)[0];
  V v_p_246 = heff_env(self)[1];
  V v_body_244 = heff_env(self)[2];
  V v_kw_241 = heff_env(self)[3];
  V v_rhs_247 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_x1_2410 = heff_tr(heff_call(v_m_248, 1, (V[]){v_st_249}));
  switch (heff_tag_of(v_x1_2410)) {
  case TAG_MkPair: {
    V v_x11_2411 = heff_field(v_x1_2410, 0);
    V v_st_2412 = heff_field(v_x1_2410, 1);
    V v_ru_24x1_2410_24MkPair = heff_take_reuse_n(v_x1_2410, 3ULL, 2);
    switch (heff_tag_of(v_x11_2411)) {
    case TAG_Left: {
      V v_e_2413 = heff_field(v_x11_2411, 0);
      heff_take_n(v_x11_2411, 1ULL, 1);
      heff_drop(v_p_246);
      heff_drop(v_body_244);
      heff_drop_rec(v_kw_241, 9);
      heff_drop(v_rhs_247);
      return heff_tag_at_n(v_ru_24x1_2410_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2413}), v_st_2412});
    }
    case TAG_Right: {
      V v_x_2414 = heff_field(v_x11_2411, 0);
      heff_take_n(v_x11_2411, 1ULL, 1);
      V v_t_2417;
      switch (heff_tag_of(v_p_246)) {
      case TAG_At: {
        V v_s_2416 = heff_dup(heff_field(v_p_246, 1));
        v_t_2417 = v_s_2416;
        break;
      }
      default: heff_nomatch(v_p_246);
      }
      V v_t_2420;
      switch (heff_tag_of(v_x_2414)) {
      case TAG_At: {
        V v_s_2419 = heff_dup(heff_field(v_x_2414, 1));
        v_t_2420 = v_s_2419;
        break;
      }
      default: heff_nomatch(v_x_2414);
      }
      V v_t_2421 = ({ V rv_1 = heff_get_n(v_t_2420, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_2417, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
      V v_t_2422 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_246, v_x_2414}), v_t_2421});
      V v_t_2423 = (g_heff_2esyntax_2ecst_2elastE(v_body_244));
      V v_e_2424 = heff_get_n(v_t_2423, 4, 9);
      V v_t_2425 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_241, 3, 9), v_e_2424});
      V v_x_2426 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ELetIn, 2, (V[]){v_rhs_247, v_t_2422}), v_t_2425});
      return heff_tag_at_n(v_ru_24x1_2410_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2426}), v_st_2412});
    }
    default: return heff_nomatch(v_x11_2411);
    }
  }
  default: return heff_nomatch(v_x1_2410);
  }
}
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str0, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str1, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str2, 3, "err");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str3, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str4, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str5, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str6, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str7, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str8, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str9, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str10, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str11, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str12, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str13, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str14, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str15, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str16, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str17, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str18, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str19, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str20, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str21, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str22, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str23, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str24, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str25, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str26, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str27, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str28, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str29, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str30, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str31, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str32, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str33, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str34, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str35, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str36, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str37, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str38, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str39, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str40, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str41, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str42, 61, "a `try` names the type of the throws it hears as `(err := T)`");
V g_heff_2esyntax_2esurface_2etryTypeL_lam0(V self, V *args); static Clo g_heff_2esyntax_2esurface_2etryTypeL_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2etryTypeL_lam0, 1, 0};
V g_heff_2esyntax_2esurface_2etryTypeL_lam1(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam2(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam3(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam4(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam5(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam6(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam7(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam8(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam9(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam10(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam11(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam12(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam13(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam14(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam15(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam16(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam17(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam18(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam19(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam20(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam21(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam22(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam23(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam24(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam25(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam26(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam27(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam28(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam29(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam30(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam31(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam32(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam33(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam34(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam35(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam36(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam37(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam38(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam39(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam40(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam41(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam42(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam43(V self, V *args);
Clo g_heff_2esyntax_2esurface_2etryTypeL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2etryTypeL_entry, 2, 0};

V g_heff_2esyntax_2esurface_2etryTypeL(V v_r_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nothing: {
    heff_drop_rec(v_r_240, 3);
    return ((V)&g_heff_2esyntax_2esurface_2etryTypeL_lam0_clo);
  }
  case TAG_Just: {
    V v_x21_244 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24Just = heff_take_reuse_n(v_x2_241, 1ULL, 1);
    switch (heff_tag_of(v_x21_244)) {
    case TAG_Atom: {
      heff_drop_rec(v_r_240, 3);
      V v_t_246 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 1); r_; });
      V v_t_247 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_246, 3), heff_get_n(v_t_246, 4, 9)});
      V v_t_248 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str0)}), v_t_247});
      V v_x_249 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_248});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam1, 1, 1, (V[]){v_x_249});
    }
    case TAG_EParen: {
      heff_drop_rec(v_r_240, 3);
      V v_t_2414 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 3); r_; });
      V v_t_2415 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_2414, 3), heff_get_n(v_t_2414, 4, 9)});
      V v_t_2416 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str1)}), v_t_2415});
      V v_x_2417 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_2416});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam2, 1, 1, (V[]){v_x_2417});
    }
    case TAG_Named: {
      V v_x_2420 = heff_field(v_x21_244, 1);
      V v_e_2422 = heff_field(v_x21_244, 3);
      heff_take_n(v_x21_244, 10ULL, 5);
      heff_drop_cell(v_ru_24x2_241_24Just, 1);
      if (heff_strEq_c(heff_dup(heff_rfield(v_x_2420, 1)), ((V)&g_heff_2esyntax_2esurface_2etryTypeL_str2))) {
        heff_drop_rec(v_x_2420, 9);
        V v_m_2425 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_2422}));
        return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam3, 1, 1, (V[]){v_m_2425});
      } else {
        heff_drop_rec(v_r_240, 3);
        heff_drop(v_e_2422);
        return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam4, 1, 1, (V[]){v_x_2420});
      }
    }
    case TAG_Tup: {
      heff_drop_rec(v_r_240, 3);
      V v_t_2441 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 4); r_; });
      V v_t_2442 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_2441, 3), heff_get_n(v_t_2441, 4, 9)});
      V v_t_2443 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str4)}), v_t_2442});
      V v_x_2444 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_2443});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam5, 1, 1, (V[]){v_x_2444});
    }
    case TAG_Seg: {
      heff_drop_rec(v_r_240, 3);
      V v_t_2449 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 3); r_; });
      V v_t_2450 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_2449, 3), heff_get_n(v_t_2449, 4, 9)});
      V v_t_2451 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str5)}), v_t_2450});
      V v_x_2452 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_2451});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam6, 1, 1, (V[]){v_x_2452});
    }
    case TAG_Braces: {
      heff_drop_rec(v_r_240, 3);
      V v_t_2458 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 4); r_; });
      V v_t_2459 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_2458, 3), heff_get_n(v_t_2458, 4, 9)});
      V v_t_2460 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str6)}), v_t_2459});
      V v_x_2461 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_2460});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam7, 1, 1, (V[]){v_x_2461});
    }
    case TAG_Update: {
      heff_drop_rec(v_r_240, 3);
      V v_t_2469 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 6); r_; });
      V v_t_2470 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_2469, 3), heff_get_n(v_t_2469, 4, 9)});
      V v_t_2471 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str7)}), v_t_2470});
      V v_x_2472 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_2471});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam8, 1, 1, (V[]){v_x_2472});
    }
    case TAG_EUSet: {
      heff_drop_rec(v_r_240, 3);
      V v_t_2477 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 3); r_; });
      V v_t_2478 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_2477, 3), heff_get_n(v_t_2477, 4, 9)});
      V v_t_2479 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str8)}), v_t_2478});
      V v_x_2480 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_2479});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam9, 1, 1, (V[]){v_x_2480});
    }
    case TAG_InstB: {
      heff_drop_rec(v_r_240, 3);
      V v_t_2487 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 5); r_; });
      V v_t_2488 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_2487, 3), heff_get_n(v_t_2487, 4, 9)});
      V v_t_2489 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str9)}), v_t_2488});
      V v_x_2490 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_2489});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam10, 1, 1, (V[]){v_x_2490});
    }
    case TAG_EFSet: {
      heff_drop_rec(v_r_240, 3);
      V v_t_2495 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 3); r_; });
      V v_t_2496 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_2495, 3), heff_get_n(v_t_2495, 4, 9)});
      V v_t_2497 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str10)}), v_t_2496});
      V v_x_2498 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_2497});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam11, 1, 1, (V[]){v_x_2498});
    }
    case TAG_EFDefault: {
      heff_drop_rec(v_r_240, 3);
      V v_t_24103 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 3); r_; });
      V v_t_24104 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24103, 3), heff_get_n(v_t_24103, 4, 9)});
      V v_t_24105 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str11)}), v_t_24104});
      V v_x_24106 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_24105});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam12, 1, 1, (V[]){v_x_24106});
    }
    case TAG_Sum: {
      heff_drop_rec(v_r_240, 3);
      V v_t_24113 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 5); r_; });
      V v_t_24114 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24113, 3), heff_get_n(v_t_24113, 4, 9)});
      V v_t_24115 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str12)}), v_t_24114});
      V v_x_24116 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_24115});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam13, 1, 1, (V[]){v_x_24116});
    }
    case TAG_ECon: {
      heff_drop_rec(v_r_240, 3);
      V v_t_24120 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 2); r_; });
      V v_t_24121 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24120, 3), heff_get_n(v_t_24120, 4, 9)});
      V v_t_24122 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str13)}), v_t_24121});
      V v_x_24123 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_24122});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam14, 1, 1, (V[]){v_x_24123});
    }
    case TAG_EField: {
      heff_drop_rec(v_r_240, 3);
      V v_t_24127 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 2); r_; });
      V v_t_24128 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24127, 3), heff_get_n(v_t_24127, 4, 9)});
      V v_t_24129 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str14)}), v_t_24128});
      V v_x_24130 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_24129});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam15, 1, 1, (V[]){v_x_24130});
    }
    case TAG_ENeg: {
      heff_drop_rec(v_r_240, 3);
      V v_t_24134 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 2); r_; });
      V v_t_24135 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24134, 3), heff_get_n(v_t_24134, 4, 9)});
      V v_t_24136 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str15)}), v_t_24135});
      V v_x_24137 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_24136});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam16, 1, 1, (V[]){v_x_24137});
    }
    case TAG_App: {
      heff_drop_rec(v_r_240, 3);
      V v_t_24141 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 2); r_; });
      V v_t_24142 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24141, 3), heff_get_n(v_t_24141, 4, 9)});
      V v_t_24143 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str16)}), v_t_24142});
      V v_x_24144 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_24143});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam17, 1, 1, (V[]){v_x_24144});
    }
    case TAG_Op: {
      heff_drop_rec(v_r_240, 3);
      V v_t_24149 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 3); r_; });
      V v_t_24150 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24149, 3), heff_get_n(v_t_24149, 4, 9)});
      V v_t_24151 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str17)}), v_t_24150});
      V v_x_24152 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_24151});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam18, 1, 1, (V[]){v_x_24152});
    }
    case TAG_Ops: {
      heff_drop_rec(v_r_240, 3);
      V v_t_24156 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 2); r_; });
      V v_t_24157 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24156, 3), heff_get_n(v_t_24156, 4, 9)});
      V v_t_24158 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str18)}), v_t_24157});
      V v_x_24159 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_24158});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam19, 1, 1, (V[]){v_x_24159});
    }
    case TAG_OpRhs: {
      heff_drop_rec(v_r_240, 3);
      V v_t_24163 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 2); r_; });
      V v_t_24164 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24163, 3), heff_get_n(v_t_24163, 4, 9)});
      V v_t_24165 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str19)}), v_t_24164});
      V v_x_24166 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_24165});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam20, 1, 1, (V[]){v_x_24166});
    }
    case TAG_Ann: {
      heff_drop_rec(v_r_240, 3);
      V v_t_24171 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 3); r_; });
      V v_t_24172 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24171, 3), heff_get_n(v_t_24171, 4, 9)});
      V v_t_24173 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str20)}), v_t_24172});
      V v_x_24174 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_24173});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam21, 1, 1, (V[]){v_x_24174});
    }
    case TAG_BVar: {
      heff_drop_rec(v_r_240, 3);
      V v_t_24177 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 1); r_; });
      V v_t_24178 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24177, 3), heff_get_n(v_t_24177, 4, 9)});
      V v_t_24179 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str21)}), v_t_24178});
      V v_x_24180 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_24179});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam22, 1, 1, (V[]){v_x_24180});
    }
    case TAG_BImp: {
      heff_drop_rec(v_r_240, 3);
      V v_t_24185 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 3); r_; });
      V v_t_24186 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24185, 3), heff_get_n(v_t_24185, 4, 9)});
      V v_t_24187 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str22)}), v_t_24186});
      V v_x_24188 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_24187});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam23, 1, 1, (V[]){v_x_24188});
    }
    case TAG_BAnn: {
      heff_drop_rec(v_r_240, 3);
      V v_t_24195 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 5); r_; });
      V v_t_24196 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24195, 3), heff_get_n(v_t_24195, 4, 9)});
      V v_t_24197 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str23)}), v_t_24196});
      V v_x_24198 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_24197});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam24, 1, 1, (V[]){v_x_24198});
    }
    case TAG_Lam: {
      heff_drop_rec(v_r_240, 3);
      V v_t_24204 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 4); r_; });
      V v_t_24205 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24204, 3), heff_get_n(v_t_24204, 4, 9)});
      V v_t_24206 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str24)}), v_t_24205});
      V v_x_24207 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_24206});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam25, 1, 1, (V[]){v_x_24207});
    }
    case TAG_Case: {
      heff_drop_rec(v_r_240, 3);
      V v_t_24213 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 4); r_; });
      V v_t_24214 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24213, 3), heff_get_n(v_t_24213, 4, 9)});
      V v_t_24215 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str25)}), v_t_24214});
      V v_x_24216 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_24215});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam26, 1, 1, (V[]){v_x_24216});
    }
    case TAG_EAlt: {
      heff_drop_rec(v_r_240, 3);
      V v_t_24221 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 3); r_; });
      V v_t_24222 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24221, 3), heff_get_n(v_t_24221, 4, 9)});
      V v_t_24223 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str26)}), v_t_24222});
      V v_x_24224 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_24223});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam27, 1, 1, (V[]){v_x_24224});
    }
    case TAG_If: {
      heff_drop_rec(v_r_240, 3);
      V v_t_24232 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 6); r_; });
      V v_t_24233 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24232, 3), heff_get_n(v_t_24232, 4, 9)});
      V v_t_24234 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str27)}), v_t_24233});
      V v_x_24235 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_24234});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam28, 1, 1, (V[]){v_x_24235});
    }
    case TAG_Do: {
      heff_drop_rec(v_r_240, 3);
      V v_t_24239 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 2); r_; });
      V v_t_24240 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24239, 3), heff_get_n(v_t_24239, 4, 9)});
      V v_t_24241 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str28)}), v_t_24240});
      V v_x_24242 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_24241});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam29, 1, 1, (V[]){v_x_24242});
    }
    case TAG_ESBind: {
      heff_drop_rec(v_r_240, 3);
      V v_t_24247 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 3); r_; });
      V v_t_24248 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24247, 3), heff_get_n(v_t_24247, 4, 9)});
      V v_t_24249 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str29)}), v_t_24248});
      V v_x_24250 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_24249});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam30, 1, 1, (V[]){v_x_24250});
    }
    case TAG_ELet: {
      heff_drop_rec(v_r_240, 3);
      V v_t_24258 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 6); r_; });
      V v_t_24259 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24258, 3), heff_get_n(v_t_24258, 4, 9)});
      V v_t_24260 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str30)}), v_t_24259});
      V v_x_24261 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_24260});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam31, 1, 1, (V[]){v_x_24261});
    }
    case TAG_ELetMut: {
      heff_drop_rec(v_r_240, 3);
      V v_t_24269 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 6); r_; });
      V v_t_24270 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24269, 3), heff_get_n(v_t_24269, 4, 9)});
      V v_t_24271 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str31)}), v_t_24270});
      V v_x_24272 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_24271});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam32, 1, 1, (V[]){v_x_24272});
    }
    case TAG_EAssign: {
      heff_drop_rec(v_r_240, 3);
      V v_t_24277 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 3); r_; });
      V v_t_24278 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24277, 3), heff_get_n(v_t_24277, 4, 9)});
      V v_t_24279 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str32)}), v_t_24278});
      V v_x_24280 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_24279});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam33, 1, 1, (V[]){v_x_24280});
    }
    case TAG_EWhile: {
      heff_drop_rec(v_r_240, 3);
      V v_t_24286 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 4); r_; });
      V v_t_24287 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24286, 3), heff_get_n(v_t_24286, 4, 9)});
      V v_t_24288 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str33)}), v_t_24287});
      V v_x_24289 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_24288});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam34, 1, 1, (V[]){v_x_24289});
    }
    case TAG_EFor: {
      heff_drop_rec(v_r_240, 3);
      V v_t_24297 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 6); r_; });
      V v_t_24298 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24297, 3), heff_get_n(v_t_24297, 4, 9)});
      V v_t_24299 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str34)}), v_t_24298});
      V v_x_24300 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_24299});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam35, 1, 1, (V[]){v_x_24300});
    }
    case TAG_EJump: {
      heff_drop_rec(v_r_240, 3);
      V v_t_24303 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 1); r_; });
      V v_t_24304 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24303, 3), heff_get_n(v_t_24303, 4, 9)});
      V v_t_24305 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str35)}), v_t_24304});
      V v_x_24306 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_24305});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam36, 1, 1, (V[]){v_x_24306});
    }
    case TAG_EReturn: {
      heff_drop_rec(v_r_240, 3);
      V v_t_24310 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 2); r_; });
      V v_t_24311 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24310, 3), heff_get_n(v_t_24310, 4, 9)});
      V v_t_24312 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str36)}), v_t_24311});
      V v_x_24313 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_24312});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam37, 1, 1, (V[]){v_x_24313});
    }
    case TAG_ENest: {
      heff_drop_rec(v_r_240, 3);
      V v_t_24319 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 4); r_; });
      V v_t_24320 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24319, 3), heff_get_n(v_t_24319, 4, 9)});
      V v_t_24321 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str37)}), v_t_24320});
      V v_x_24322 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_24321});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam38, 1, 1, (V[]){v_x_24322});
    }
    case TAG_IfThen: {
      heff_drop_rec(v_r_240, 3);
      V v_t_24328 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 4); r_; });
      V v_t_24329 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24328, 3), heff_get_n(v_t_24328, 4, 9)});
      V v_t_24330 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str38)}), v_t_24329});
      V v_x_24331 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_24330});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam39, 1, 1, (V[]){v_x_24331});
    }
    case TAG_ELetCond: {
      heff_drop_rec(v_r_240, 3);
      V v_t_24337 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 4); r_; });
      V v_t_24338 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24337, 3), heff_get_n(v_t_24337, 4, 9)});
      V v_t_24339 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str39)}), v_t_24338});
      V v_x_24340 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_24339});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam40, 1, 1, (V[]){v_x_24340});
    }
    case TAG_ETry: {
      heff_drop_rec(v_r_240, 3);
      V v_t_24346 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 4); r_; });
      V v_t_24347 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24346, 3), heff_get_n(v_t_24346, 4, 9)});
      V v_t_24348 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str40)}), v_t_24347});
      V v_x_24349 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_24348});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam41, 1, 1, (V[]){v_x_24349});
    }
    case TAG_ECatch: {
      heff_drop_rec(v_r_240, 3);
      V v_t_24355 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 4); r_; });
      V v_t_24356 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24355, 3), heff_get_n(v_t_24355, 4, 9)});
      V v_t_24357 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str41)}), v_t_24356});
      V v_x_24358 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_24357});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam42, 1, 1, (V[]){v_x_24358});
    }
    case TAG_EWith: {
      heff_drop_rec(v_r_240, 3);
      V v_t_24366 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 6); r_; });
      V v_t_24367 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24366, 3), heff_get_n(v_t_24366, 4, 9)});
      V v_t_24368 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str42)}), v_t_24367});
      V v_x_24369 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_24368});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam43, 1, 1, (V[]){v_x_24369});
    }
    default: return heff_nomatch(v_x21_244);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2esurface_2etryTypeL_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2etryTypeL(a[0], a[1]);
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam0(V self, V *args) {
  V v_st_242 = args[0];
  V v_t_243 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_243, v_st_242});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam1(V self, V *args) {
  V v_st_2410 = args[0];
  V v_x_249 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_249}), v_st_2410});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam2(V self, V *args) {
  V v_st_2418 = args[0];
  V v_x_2417 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2417}), v_st_2418});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam3(V self, V *args) {
  V v_st_2426 = args[0];
  V v_m_2425 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2427 = heff_tr(heff_call(v_m_2425, 1, (V[]){v_st_2426}));
  switch (heff_tag_of(v_x1_2427)) {
  case TAG_MkPair: {
    V v_x11_2428 = heff_field(v_x1_2427, 0);
    V v_st_2429 = heff_field(v_x1_2427, 1);
    V v_ru_24x1_2427_24MkPair = heff_take_reuse_n(v_x1_2427, 3ULL, 2);
    switch (heff_tag_of(v_x11_2428)) {
    case TAG_Left: {
      V v_e_2430 = heff_field(v_x11_2428, 0);
      heff_take_n(v_x11_2428, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_2427_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2430}), v_st_2429});
    }
    case TAG_Right: {
      V v_x_2431 = heff_field(v_x11_2428, 0);
      V v_ru_24x11_2428_24Right = heff_take_reuse_n(v_x11_2428, 1ULL, 1);
      V v_t_2432 = heff_tag_at_n(v_ru_24x11_2428_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Just, 1, (V[]){v_x_2431})});
      return heff_tag_at_n(v_ru_24x1_2427_24MkPair, TAG_MkPair, 2, (V[]){v_t_2432, v_st_2429});
    }
    default: return heff_nomatch(v_x11_2428);
    }
  }
  default: return heff_nomatch(v_x1_2427);
  }
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam4(V self, V *args) {
  V v_st_2433 = args[0];
  V v_x_2420 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2434 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_x_2420, 3), heff_get_n(v_x_2420, 4, 9)});
  V v_t_2435 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str3)}), v_t_2434});
  V v_t_2436 = heff_tag_n(TAG_Right, 1, (V[]){heff_tag_n(TAG_Just, 1, (V[]){v_t_2435})});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2436, v_st_2433});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam5(V self, V *args) {
  V v_st_2445 = args[0];
  V v_x_2444 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2444}), v_st_2445});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam6(V self, V *args) {
  V v_st_2453 = args[0];
  V v_x_2452 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2452}), v_st_2453});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam7(V self, V *args) {
  V v_st_2462 = args[0];
  V v_x_2461 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2461}), v_st_2462});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam8(V self, V *args) {
  V v_st_2473 = args[0];
  V v_x_2472 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2472}), v_st_2473});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam9(V self, V *args) {
  V v_st_2481 = args[0];
  V v_x_2480 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2480}), v_st_2481});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam10(V self, V *args) {
  V v_st_2491 = args[0];
  V v_x_2490 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2490}), v_st_2491});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam11(V self, V *args) {
  V v_st_2499 = args[0];
  V v_x_2498 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2498}), v_st_2499});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam12(V self, V *args) {
  V v_st_24107 = args[0];
  V v_x_24106 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24106}), v_st_24107});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam13(V self, V *args) {
  V v_st_24117 = args[0];
  V v_x_24116 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24116}), v_st_24117});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam14(V self, V *args) {
  V v_st_24124 = args[0];
  V v_x_24123 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24123}), v_st_24124});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam15(V self, V *args) {
  V v_st_24131 = args[0];
  V v_x_24130 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24130}), v_st_24131});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam16(V self, V *args) {
  V v_st_24138 = args[0];
  V v_x_24137 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24137}), v_st_24138});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam17(V self, V *args) {
  V v_st_24145 = args[0];
  V v_x_24144 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24144}), v_st_24145});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam18(V self, V *args) {
  V v_st_24153 = args[0];
  V v_x_24152 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24152}), v_st_24153});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam19(V self, V *args) {
  V v_st_24160 = args[0];
  V v_x_24159 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24159}), v_st_24160});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam20(V self, V *args) {
  V v_st_24167 = args[0];
  V v_x_24166 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24166}), v_st_24167});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam21(V self, V *args) {
  V v_st_24175 = args[0];
  V v_x_24174 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24174}), v_st_24175});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam22(V self, V *args) {
  V v_st_24181 = args[0];
  V v_x_24180 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24180}), v_st_24181});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam23(V self, V *args) {
  V v_st_24189 = args[0];
  V v_x_24188 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24188}), v_st_24189});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam24(V self, V *args) {
  V v_st_24199 = args[0];
  V v_x_24198 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24198}), v_st_24199});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam25(V self, V *args) {
  V v_st_24208 = args[0];
  V v_x_24207 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24207}), v_st_24208});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam26(V self, V *args) {
  V v_st_24217 = args[0];
  V v_x_24216 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24216}), v_st_24217});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam27(V self, V *args) {
  V v_st_24225 = args[0];
  V v_x_24224 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24224}), v_st_24225});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam28(V self, V *args) {
  V v_st_24236 = args[0];
  V v_x_24235 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24235}), v_st_24236});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam29(V self, V *args) {
  V v_st_24243 = args[0];
  V v_x_24242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24242}), v_st_24243});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam30(V self, V *args) {
  V v_st_24251 = args[0];
  V v_x_24250 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24250}), v_st_24251});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam31(V self, V *args) {
  V v_st_24262 = args[0];
  V v_x_24261 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24261}), v_st_24262});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam32(V self, V *args) {
  V v_st_24273 = args[0];
  V v_x_24272 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24272}), v_st_24273});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam33(V self, V *args) {
  V v_st_24281 = args[0];
  V v_x_24280 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24280}), v_st_24281});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam34(V self, V *args) {
  V v_st_24290 = args[0];
  V v_x_24289 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24289}), v_st_24290});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam35(V self, V *args) {
  V v_st_24301 = args[0];
  V v_x_24300 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24300}), v_st_24301});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam36(V self, V *args) {
  V v_st_24307 = args[0];
  V v_x_24306 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24306}), v_st_24307});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam37(V self, V *args) {
  V v_st_24314 = args[0];
  V v_x_24313 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24313}), v_st_24314});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam38(V self, V *args) {
  V v_st_24323 = args[0];
  V v_x_24322 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24322}), v_st_24323});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam39(V self, V *args) {
  V v_st_24332 = args[0];
  V v_x_24331 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24331}), v_st_24332});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam40(V self, V *args) {
  V v_st_24341 = args[0];
  V v_x_24340 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24340}), v_st_24341});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam41(V self, V *args) {
  V v_st_24350 = args[0];
  V v_x_24349 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24349}), v_st_24350});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam42(V self, V *args) {
  V v_st_24359 = args[0];
  V v_x_24358 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24358}), v_st_24359});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam43(V self, V *args) {
  V v_st_24370 = args[0];
  V v_x_24369 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24369}), v_st_24370});
}
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str0, 7, "integer");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str1, 28, "a segment says its type once");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str2, 6, "binary");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str3, 28, "a segment says its type once");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str4, 5, "bytes");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str5, 28, "a segment says its type once");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str6, 4, "bits");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str7, 28, "a segment says its type once");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str8, 9, "bitstring");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str9, 28, "a segment says its type once");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str10, 5, "float");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str11, 28, "a segment says its type once");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str12, 4, "utf8");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str13, 28, "a segment says its type once");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str14, 5, "utf16");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str15, 28, "a segment says its type once");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str16, 5, "utf32");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str17, 28, "a segment says its type once");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str18, 3, "big");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str19, 34, "a segment says its endianness once");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str20, 6, "little");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str21, 34, "a segment says its endianness once");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str22, 6, "signed");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str23, 28, "a segment says its sign once");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str24, 8, "unsigned");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str25, 28, "a segment says its sign once");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str26, 227, "a segment's spec is its type (`integer`, `binary`, `bits`, `float`, `utf8`, `utf16`, `utf32`), size (`16`, `size(n)`), unit (`unit(8)`), endianness (`big`, `little`) and sign (`signed`, `unsigned`), between `-`s: `x::16-little`");
Clo g_heff_2esyntax_2esurface_2especWord_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2especWord_entry, 3, 0};

V g_heff_2esyntax_2esurface_2especWord(V v_t_240, V v_s_241, V v_p_242) {
top: ;
  if (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 1)), ((V)&g_heff_2esyntax_2esurface_2especWord_str0))) {
    V v_t_244 = heff_take_field(v_s_241, 0);
    switch (heff_tag_of(v_t_244)) {
    case TAG_Nothing: {
      heff_drop_rec(v_t_240, 9);
      V v_t_245 = heff_tag_n(TAG_Just, 1, (V[]){NTAG(TAG_SegmentInteger)});
      V v_t_246 = ({ V rv_0 = v_t_245; V rr_ = heff_rec_reuse_nf(v_s_241, 30ULL, 5, shape_ty__size__unit__little__signed, 1020u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_246}), v_p_242});
    }
    case TAG_Just: {
      V v_ru_24t_244_24Just = heff_take_reuse_n(v_t_244, 0ULL, 1);
      heff_drop_rec(v_s_241, 5);
      V v_t_248 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_240, 3), heff_get_n(v_t_240, 4, 9)});
      V v_t_249 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2especWord_str1), v_t_248, NTAG(TAG_Nothing)});
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24t_244_24Just, TAG_Left, 1, (V[]){v_t_249}), v_p_242});
    }
    default: return heff_nomatch(v_t_244);
    }
  } else {
    if (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 1)), ((V)&g_heff_2esyntax_2esurface_2especWord_str2))) {
      V v_t_2411 = heff_take_field(v_s_241, 0);
      switch (heff_tag_of(v_t_2411)) {
      case TAG_Nothing: {
        heff_drop_rec(v_t_240, 9);
        V v_t_2412 = heff_tag_n(TAG_Just, 1, (V[]){NTAG(TAG_SegmentBinary)});
        V v_t_2413 = ({ V rv_0 = v_t_2412; V rr_ = heff_rec_reuse_nf(v_s_241, 30ULL, 5, shape_ty__size__unit__little__signed, 1020u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
        return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2413}), v_p_242});
      }
      case TAG_Just: {
        V v_ru_24t_2411_24Just = heff_take_reuse_n(v_t_2411, 0ULL, 1);
        heff_drop_rec(v_s_241, 5);
        V v_t_2415 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_240, 3), heff_get_n(v_t_240, 4, 9)});
        V v_t_2416 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2especWord_str3), v_t_2415, NTAG(TAG_Nothing)});
        return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24t_2411_24Just, TAG_Left, 1, (V[]){v_t_2416}), v_p_242});
      }
      default: return heff_nomatch(v_t_2411);
      }
    } else {
      if (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 1)), ((V)&g_heff_2esyntax_2esurface_2especWord_str4))) {
        V v_t_2418 = heff_take_field(v_s_241, 0);
        switch (heff_tag_of(v_t_2418)) {
        case TAG_Nothing: {
          heff_drop_rec(v_t_240, 9);
          V v_t_2419 = heff_tag_n(TAG_Just, 1, (V[]){NTAG(TAG_SegmentBinary)});
          V v_t_2420 = ({ V rv_0 = v_t_2419; V rr_ = heff_rec_reuse_nf(v_s_241, 30ULL, 5, shape_ty__size__unit__little__signed, 1020u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
          return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2420}), v_p_242});
        }
        case TAG_Just: {
          V v_ru_24t_2418_24Just = heff_take_reuse_n(v_t_2418, 0ULL, 1);
          heff_drop_rec(v_s_241, 5);
          V v_t_2422 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_240, 3), heff_get_n(v_t_240, 4, 9)});
          V v_t_2423 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2especWord_str5), v_t_2422, NTAG(TAG_Nothing)});
          return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24t_2418_24Just, TAG_Left, 1, (V[]){v_t_2423}), v_p_242});
        }
        default: return heff_nomatch(v_t_2418);
        }
      } else {
        if (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 1)), ((V)&g_heff_2esyntax_2esurface_2especWord_str6))) {
          V v_t_2425 = heff_take_field(v_s_241, 0);
          switch (heff_tag_of(v_t_2425)) {
          case TAG_Nothing: {
            heff_drop_rec(v_t_240, 9);
            V v_t_2426 = heff_tag_n(TAG_Just, 1, (V[]){NTAG(TAG_SegmentBits)});
            V v_t_2427 = ({ V rv_0 = v_t_2426; V rr_ = heff_rec_reuse_nf(v_s_241, 30ULL, 5, shape_ty__size__unit__little__signed, 1020u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
            return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2427}), v_p_242});
          }
          case TAG_Just: {
            V v_ru_24t_2425_24Just = heff_take_reuse_n(v_t_2425, 0ULL, 1);
            heff_drop_rec(v_s_241, 5);
            V v_t_2429 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_240, 3), heff_get_n(v_t_240, 4, 9)});
            V v_t_2430 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2especWord_str7), v_t_2429, NTAG(TAG_Nothing)});
            return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24t_2425_24Just, TAG_Left, 1, (V[]){v_t_2430}), v_p_242});
          }
          default: return heff_nomatch(v_t_2425);
          }
        } else {
          if (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 1)), ((V)&g_heff_2esyntax_2esurface_2especWord_str8))) {
            V v_t_2432 = heff_take_field(v_s_241, 0);
            switch (heff_tag_of(v_t_2432)) {
            case TAG_Nothing: {
              heff_drop_rec(v_t_240, 9);
              V v_t_2433 = heff_tag_n(TAG_Just, 1, (V[]){NTAG(TAG_SegmentBits)});
              V v_t_2434 = ({ V rv_0 = v_t_2433; V rr_ = heff_rec_reuse_nf(v_s_241, 30ULL, 5, shape_ty__size__unit__little__signed, 1020u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
              return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2434}), v_p_242});
            }
            case TAG_Just: {
              V v_ru_24t_2432_24Just = heff_take_reuse_n(v_t_2432, 0ULL, 1);
              heff_drop_rec(v_s_241, 5);
              V v_t_2436 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_240, 3), heff_get_n(v_t_240, 4, 9)});
              V v_t_2437 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2especWord_str9), v_t_2436, NTAG(TAG_Nothing)});
              return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24t_2432_24Just, TAG_Left, 1, (V[]){v_t_2437}), v_p_242});
            }
            default: return heff_nomatch(v_t_2432);
            }
          } else {
            if (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 1)), ((V)&g_heff_2esyntax_2esurface_2especWord_str10))) {
              V v_t_2439 = heff_take_field(v_s_241, 0);
              switch (heff_tag_of(v_t_2439)) {
              case TAG_Nothing: {
                heff_drop_rec(v_t_240, 9);
                V v_t_2440 = heff_tag_n(TAG_Just, 1, (V[]){NTAG(TAG_SegmentFloat)});
                V v_t_2441 = ({ V rv_0 = v_t_2440; V rr_ = heff_rec_reuse_nf(v_s_241, 30ULL, 5, shape_ty__size__unit__little__signed, 1020u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
                return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2441}), v_p_242});
              }
              case TAG_Just: {
                V v_ru_24t_2439_24Just = heff_take_reuse_n(v_t_2439, 0ULL, 1);
                heff_drop_rec(v_s_241, 5);
                V v_t_2443 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_240, 3), heff_get_n(v_t_240, 4, 9)});
                V v_t_2444 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2especWord_str11), v_t_2443, NTAG(TAG_Nothing)});
                return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24t_2439_24Just, TAG_Left, 1, (V[]){v_t_2444}), v_p_242});
              }
              default: return heff_nomatch(v_t_2439);
              }
            } else {
              if (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 1)), ((V)&g_heff_2esyntax_2esurface_2especWord_str12))) {
                V v_t_2446 = heff_take_field(v_s_241, 0);
                switch (heff_tag_of(v_t_2446)) {
                case TAG_Nothing: {
                  heff_drop_rec(v_t_240, 9);
                  V v_t_2447 = heff_tag_n(TAG_Just, 1, (V[]){heff_tag_n(TAG_SegmentUtf, 1, (V[]){MK_INT(8LL)})});
                  V v_t_2448 = ({ V rv_0 = v_t_2447; V rr_ = heff_rec_reuse_nf(v_s_241, 30ULL, 5, shape_ty__size__unit__little__signed, 1020u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
                  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2448}), v_p_242});
                }
                case TAG_Just: {
                  V v_ru_24t_2446_24Just = heff_take_reuse_n(v_t_2446, 0ULL, 1);
                  heff_drop_rec(v_s_241, 5);
                  V v_t_2450 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_240, 3), heff_get_n(v_t_240, 4, 9)});
                  V v_t_2451 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2especWord_str13), v_t_2450, NTAG(TAG_Nothing)});
                  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24t_2446_24Just, TAG_Left, 1, (V[]){v_t_2451}), v_p_242});
                }
                default: return heff_nomatch(v_t_2446);
                }
              } else {
                if (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 1)), ((V)&g_heff_2esyntax_2esurface_2especWord_str14))) {
                  V v_t_2453 = heff_take_field(v_s_241, 0);
                  switch (heff_tag_of(v_t_2453)) {
                  case TAG_Nothing: {
                    heff_drop_rec(v_t_240, 9);
                    V v_t_2454 = heff_tag_n(TAG_Just, 1, (V[]){heff_tag_n(TAG_SegmentUtf, 1, (V[]){MK_INT(16LL)})});
                    V v_t_2455 = ({ V rv_0 = v_t_2454; V rr_ = heff_rec_reuse_nf(v_s_241, 30ULL, 5, shape_ty__size__unit__little__signed, 1020u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
                    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2455}), v_p_242});
                  }
                  case TAG_Just: {
                    V v_ru_24t_2453_24Just = heff_take_reuse_n(v_t_2453, 0ULL, 1);
                    heff_drop_rec(v_s_241, 5);
                    V v_t_2457 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_240, 3), heff_get_n(v_t_240, 4, 9)});
                    V v_t_2458 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2especWord_str15), v_t_2457, NTAG(TAG_Nothing)});
                    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24t_2453_24Just, TAG_Left, 1, (V[]){v_t_2458}), v_p_242});
                  }
                  default: return heff_nomatch(v_t_2453);
                  }
                } else {
                  if (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 1)), ((V)&g_heff_2esyntax_2esurface_2especWord_str16))) {
                    V v_t_2460 = heff_take_field(v_s_241, 0);
                    switch (heff_tag_of(v_t_2460)) {
                    case TAG_Nothing: {
                      heff_drop_rec(v_t_240, 9);
                      V v_t_2461 = heff_tag_n(TAG_Just, 1, (V[]){heff_tag_n(TAG_SegmentUtf, 1, (V[]){MK_INT(32LL)})});
                      V v_t_2462 = ({ V rv_0 = v_t_2461; V rr_ = heff_rec_reuse_nf(v_s_241, 30ULL, 5, shape_ty__size__unit__little__signed, 1020u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
                      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2462}), v_p_242});
                    }
                    case TAG_Just: {
                      V v_ru_24t_2460_24Just = heff_take_reuse_n(v_t_2460, 0ULL, 1);
                      heff_drop_rec(v_s_241, 5);
                      V v_t_2464 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_240, 3), heff_get_n(v_t_240, 4, 9)});
                      V v_t_2465 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2especWord_str17), v_t_2464, NTAG(TAG_Nothing)});
                      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24t_2460_24Just, TAG_Left, 1, (V[]){v_t_2465}), v_p_242});
                    }
                    default: return heff_nomatch(v_t_2460);
                    }
                  } else {
                    if (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 1)), ((V)&g_heff_2esyntax_2esurface_2especWord_str18))) {
                      V v_t_2467 = heff_take_field(v_s_241, 3);
                      switch (heff_tag_of(v_t_2467)) {
                      case TAG_Nothing: {
                        heff_drop_rec(v_t_240, 9);
                        V v_t_2468 = heff_tag_n(TAG_Just, 1, (V[]){NTAG(TAG_False)});
                        V v_t_2469 = ({ V rv_3 = v_t_2468; V rr_ = heff_rec_reuse_nf(v_s_241, 23ULL, 5, shape_ty__size__unit__little__signed, 831u, 0u); heff_rfield(rr_, 3) = rv_3; rr_; });
                        return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2469}), v_p_242});
                      }
                      case TAG_Just: {
                        V v_ru_24t_2467_24Just = heff_take_reuse_n(v_t_2467, 0ULL, 1);
                        heff_drop_rec(v_s_241, 5);
                        V v_t_2471 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_240, 3), heff_get_n(v_t_240, 4, 9)});
                        V v_t_2472 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2especWord_str19), v_t_2471, NTAG(TAG_Nothing)});
                        return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24t_2467_24Just, TAG_Left, 1, (V[]){v_t_2472}), v_p_242});
                      }
                      default: return heff_nomatch(v_t_2467);
                      }
                    } else {
                      if (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 1)), ((V)&g_heff_2esyntax_2esurface_2especWord_str20))) {
                        V v_t_2474 = heff_take_field(v_s_241, 3);
                        switch (heff_tag_of(v_t_2474)) {
                        case TAG_Nothing: {
                          heff_drop_rec(v_t_240, 9);
                          V v_t_2475 = heff_tag_n(TAG_Just, 1, (V[]){NTAG(TAG_True)});
                          V v_t_2476 = ({ V rv_3 = v_t_2475; V rr_ = heff_rec_reuse_nf(v_s_241, 23ULL, 5, shape_ty__size__unit__little__signed, 831u, 0u); heff_rfield(rr_, 3) = rv_3; rr_; });
                          return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2476}), v_p_242});
                        }
                        case TAG_Just: {
                          V v_ru_24t_2474_24Just = heff_take_reuse_n(v_t_2474, 0ULL, 1);
                          heff_drop_rec(v_s_241, 5);
                          V v_t_2478 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_240, 3), heff_get_n(v_t_240, 4, 9)});
                          V v_t_2479 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2especWord_str21), v_t_2478, NTAG(TAG_Nothing)});
                          return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24t_2474_24Just, TAG_Left, 1, (V[]){v_t_2479}), v_p_242});
                        }
                        default: return heff_nomatch(v_t_2474);
                        }
                      } else {
                        if (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 1)), ((V)&g_heff_2esyntax_2esurface_2especWord_str22))) {
                          V v_t_2481 = heff_take_field(v_s_241, 4);
                          switch (heff_tag_of(v_t_2481)) {
                          case TAG_Nothing: {
                            heff_drop_rec(v_t_240, 9);
                            V v_t_2482 = heff_tag_n(TAG_Just, 1, (V[]){NTAG(TAG_True)});
                            V v_t_2483 = ({ V rv_4 = v_t_2482; V rr_ = heff_rec_reuse_nf(v_s_241, 15ULL, 5, shape_ty__size__unit__little__signed, 255u, 0u); heff_rfield(rr_, 4) = rv_4; rr_; });
                            return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2483}), v_p_242});
                          }
                          case TAG_Just: {
                            V v_ru_24t_2481_24Just = heff_take_reuse_n(v_t_2481, 0ULL, 1);
                            heff_drop_rec(v_s_241, 5);
                            V v_t_2485 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_240, 3), heff_get_n(v_t_240, 4, 9)});
                            V v_t_2486 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2especWord_str23), v_t_2485, NTAG(TAG_Nothing)});
                            return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24t_2481_24Just, TAG_Left, 1, (V[]){v_t_2486}), v_p_242});
                          }
                          default: return heff_nomatch(v_t_2481);
                          }
                        } else {
                          if (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 1)), ((V)&g_heff_2esyntax_2esurface_2especWord_str24))) {
                            V v_t_2488 = heff_take_field(v_s_241, 4);
                            switch (heff_tag_of(v_t_2488)) {
                            case TAG_Nothing: {
                              heff_drop_rec(v_t_240, 9);
                              V v_t_2489 = heff_tag_n(TAG_Just, 1, (V[]){NTAG(TAG_False)});
                              V v_t_2490 = ({ V rv_4 = v_t_2489; V rr_ = heff_rec_reuse_nf(v_s_241, 15ULL, 5, shape_ty__size__unit__little__signed, 255u, 0u); heff_rfield(rr_, 4) = rv_4; rr_; });
                              return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2490}), v_p_242});
                            }
                            case TAG_Just: {
                              V v_ru_24t_2488_24Just = heff_take_reuse_n(v_t_2488, 0ULL, 1);
                              heff_drop_rec(v_s_241, 5);
                              V v_t_2492 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_240, 3), heff_get_n(v_t_240, 4, 9)});
                              V v_t_2493 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2especWord_str25), v_t_2492, NTAG(TAG_Nothing)});
                              return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24t_2488_24Just, TAG_Left, 1, (V[]){v_t_2493}), v_p_242});
                            }
                            default: return heff_nomatch(v_t_2488);
                            }
                          } else {
                            heff_drop_rec(v_s_241, 5);
                            V v_t_2494 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_240, 3), heff_get_n(v_t_240, 4, 9)});
                            V v_t_2495 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2especWord_str26), v_t_2494, NTAG(TAG_Nothing)});
                            return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2495}), v_p_242});
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}
V g_heff_2esyntax_2esurface_2especWord_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2especWord(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2esyntax_2esurface_2eunitOf_str0, 3, "int");
HEFF_LIT(g_heff_2esyntax_2esurface_2eunitOf_str1, 28, "a segment says its unit once");
HEFF_LIT(g_heff_2esyntax_2esurface_2eunitOf_str2, 47, "a unit is a number of bits, 1 to 256: `unit(8)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eunitOf_str3, 47, "a unit is a number of bits, 1 to 256: `unit(8)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eunitOf_str4, 47, "a unit is a number of bits, 1 to 256: `unit(8)`");
V g_heff_2esyntax_2esurface_2eunitOf_lam0(V self, V *args);
V g_heff_2esyntax_2esurface_2eunitOf_lam1(V self, V *args);
V g_heff_2esyntax_2esurface_2eunitOf_lam2(V self, V *args);
V g_heff_2esyntax_2esurface_2eunitOf_lam3(V self, V *args);
Clo g_heff_2esyntax_2esurface_2eunitOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eunitOf_entry, 3, 0};

V g_heff_2esyntax_2esurface_2eunitOf(V v_sp_240, V v_n_241, V v_s_242) {
top: ;
  if (heff_strEq_c(heff_dup(heff_rfield(v_n_241, 0)), ((V)&g_heff_2esyntax_2esurface_2eunitOf_str0))) {
    V v_t_244 = (g_heff_2esyntax_2esurface_2eintOfText(heff_rfield(v_n_241, 1)));
    if (heff_intLe_c(MK_INT(1LL), v_t_244)) {
      V v_t_246 = (g_heff_2esyntax_2esurface_2eintOfText(heff_rfield(v_n_241, 1)));
      if (heff_intLe_c(v_t_246, MK_INT(256LL))) {
        V v_n_248 = ({ V b_0 = heff_get_n(v_n_241, 1, 9); V r_ = (g_heff_2esyntax_2esurface_2eintOfText(b_0)); heff_drop(b_0); r_; });
        return heff_clo_n(g_heff_2esyntax_2esurface_2eunitOf_lam0, 1, 3, (V[]){v_s_242, v_n_248, v_sp_240});
      } else {
        heff_drop_rec(v_n_241, 9);
        heff_drop_rec(v_s_242, 5);
        return heff_clo_n(g_heff_2esyntax_2esurface_2eunitOf_lam1, 1, 1, (V[]){v_sp_240});
      }
    } else {
      heff_drop_rec(v_n_241, 9);
      heff_drop_rec(v_s_242, 5);
      return heff_clo_n(g_heff_2esyntax_2esurface_2eunitOf_lam2, 1, 1, (V[]){v_sp_240});
    }
  } else {
    heff_drop_rec(v_n_241, 9);
    heff_drop_rec(v_s_242, 5);
    return heff_clo_n(g_heff_2esyntax_2esurface_2eunitOf_lam3, 1, 1, (V[]){v_sp_240});
  }
}
V g_heff_2esyntax_2esurface_2eunitOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2eunitOf(a[0], a[1], a[2]);
}
V g_heff_2esyntax_2esurface_2eunitOf_lam0(V self, V *args) {
  V v_p_249 = args[0];
  V v_s_242 = heff_env(self)[0];
  V v_n_248 = heff_env(self)[1];
  V v_sp_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2410 = heff_take_field(v_s_242, 2);
  switch (heff_tag_of(v_t_2410)) {
  case TAG_Nothing: {
    heff_drop(v_sp_240);
    V v_t_2411 = ({ V rv_2 = heff_tag_n(TAG_Just, 1, (V[]){v_n_248}); V rr_ = heff_rec_reuse_nf(v_s_242, 27ULL, 5, shape_ty__size__unit__little__signed, 975u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2411}), v_p_249});
  }
  case TAG_Just: {
    V v_ru_24t_2410_24Just = heff_take_reuse_n(v_t_2410, 0ULL, 1);
    heff_drop_rec(v_s_242, 5);
    heff_drop(v_n_248);
    V v_t_2413 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2eunitOf_str1), v_sp_240, NTAG(TAG_Nothing)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24t_2410_24Just, TAG_Left, 1, (V[]){v_t_2413}), v_p_249});
  }
  default: return heff_nomatch(v_t_2410);
  }
}
V g_heff_2esyntax_2esurface_2eunitOf_lam1(V self, V *args) {
  V v_st_2414 = args[0];
  V v_sp_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2415 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2eunitOf_str2), v_sp_240, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2415}), v_st_2414});
}
V g_heff_2esyntax_2esurface_2eunitOf_lam2(V self, V *args) {
  V v_st_2416 = args[0];
  V v_sp_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2417 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2eunitOf_str3), v_sp_240, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2417}), v_st_2416});
}
V g_heff_2esyntax_2esurface_2eunitOf_lam3(V self, V *args) {
  V v_st_2418 = args[0];
  V v_sp_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2419 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2eunitOf_str4), v_sp_240, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2419}), v_st_2418});
}
Clo g_heff_2esyntax_2esurface_2esegmentOf_24s1547151193x813882637_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2esegmentOf_24s1547151193x813882637_entry, 5, 0};

V g_heff_2esyntax_2esurface_2esegmentOf_24s1547151193x813882637(V v_inPat_240, V v_sp_241, V v_e_242, V v_v_243, V v_st_244) {
top: ;
  V v_t_246;
  switch (heff_tag_of(v_v_243)) {
  case TAG_StrValue: {
    v_t_246 = NTAG(TAG_SegmentBinary);
    break;
  }
  case TAG_IntValue: {
    v_t_246 = NTAG(TAG_SegmentInteger);
    break;
  }
  case TAG_FloatValue: {
    v_t_246 = NTAG(TAG_SegmentFloat);
    break;
  }
  case TAG_RuneValue: {
    v_t_246 = heff_tag_n(TAG_SegmentUtf, 1, (V[]){MK_INT(8LL)});
    break;
  }
  case TAG_OtherValue: {
    v_t_246 = NTAG(TAG_SegmentInteger);
    break;
  }
  default: heff_nomatch(v_v_243);
  }
  HeffT2 v_t_247 = (g_heff_2esyntax_2esurface_2evalueKind_24cpr(heff_dup(v_sp_241), heff_dup(v_v_243), v_t_246, v_st_244));
  {
    V v_field_248 = v_t_247.f[0];
    V v_field_249 = v_t_247.f[1];
    V v_x11_2410 = v_field_248;
    V v_st_2411 = v_field_249;
    switch (heff_tag_of(v_x11_2410)) {
    case TAG_Left: {
      V v_e_2412 = heff_field(v_x11_2410, 0);
      V v_ru_24x11_2410_24Left = heff_take_reuse_n(v_x11_2410, 1ULL, 1);
      heff_drop(v_sp_241);
      heff_drop(v_e_242);
      heff_drop(v_v_243);
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_2410_24Left, TAG_Left, 1, (V[]){v_e_2412}), v_st_2411});
    }
    case TAG_Right: {
      V v_ru_24x11_2410_24Right = heff_take_reuse_n(v_x11_2410, 0ULL, 1);
      V v_t_2415;
      switch (heff_tag_of(v_v_243)) {
      case TAG_StrValue: {
        v_t_2415 = NTAG(TAG_SegmentBinary);
        break;
      }
      case TAG_IntValue: {
        v_t_2415 = NTAG(TAG_SegmentInteger);
        break;
      }
      case TAG_FloatValue: {
        v_t_2415 = NTAG(TAG_SegmentFloat);
        break;
      }
      case TAG_RuneValue: {
        v_t_2415 = heff_tag_n(TAG_SegmentUtf, 1, (V[]){MK_INT(8LL)});
        break;
      }
      case TAG_OtherValue: {
        v_t_2415 = NTAG(TAG_SegmentInteger);
        break;
      }
      default: heff_nomatch(v_v_243);
      }
      V v_m_2416 = (g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993(v_inPat_240, heff_dup(v_sp_241), heff_dup(v_v_243), v_t_2415, NTAG(TAG_SizeDefault)));
      V v_x1_2417 = heff_tr(heff_call(v_m_2416, 1, (V[]){v_st_2411}));
      switch (heff_tag_of(v_x1_2417)) {
      case TAG_MkPair: {
        V v_x11_2418 = heff_field(v_x1_2417, 0);
        V v_st_2419 = heff_field(v_x1_2417, 1);
        V v_ru_24x1_2417_24MkPair = heff_take_reuse_n(v_x1_2417, 3ULL, 2);
        switch (heff_tag_of(v_x11_2418)) {
        case TAG_Left: {
          V v_e_2420 = heff_field(v_x11_2418, 0);
          heff_take_n(v_x11_2418, 1ULL, 1);
          heff_drop(v_sp_241);
          heff_drop(v_e_242);
          heff_drop(v_v_243);
          heff_drop_cell(v_ru_24x11_2410_24Right, 1);
          return heff_tag_at_n(v_ru_24x1_2417_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2420}), v_st_2419});
        }
        case TAG_Right: {
          V v_ru_24x11_2418_24Right = heff_take_reuse_n(v_x11_2418, 0ULL, 1);
          V v_t_2423;
          switch (heff_tag_of(v_v_243)) {
          case TAG_StrValue: {
            heff_drop_cell(v_ru_24x11_2418_24Right, 1);
            v_t_2423 = NTAG(TAG_SegmentBinary);
            break;
          }
          case TAG_IntValue: {
            heff_take_n(v_v_243, 0ULL, 1);
            heff_drop_cell(v_ru_24x11_2418_24Right, 1);
            v_t_2423 = NTAG(TAG_SegmentInteger);
            break;
          }
          case TAG_FloatValue: {
            heff_drop_cell(v_ru_24x11_2418_24Right, 1);
            v_t_2423 = NTAG(TAG_SegmentFloat);
            break;
          }
          case TAG_RuneValue: {
            v_t_2423 = heff_tag_at_n(v_ru_24x11_2418_24Right, TAG_SegmentUtf, 1, (V[]){MK_INT(8LL)});
            break;
          }
          case TAG_OtherValue: {
            heff_drop_cell(v_ru_24x11_2418_24Right, 1);
            v_t_2423 = NTAG(TAG_SegmentInteger);
            break;
          }
          default: heff_nomatch(v_v_243);
          }
          V v_t_2424 = heff_tag_n(TAG_MkSegment, 5, (V[]){v_e_242, v_t_2423, NTAG(TAG_SizeDefault), NTAG(TAG_False), NTAG(TAG_False)});
          V v_t_2425 = heff_tag_at_n(v_ru_24x11_2410_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2424, v_sp_241})});
          return heff_tag_at_n(v_ru_24x1_2417_24MkPair, TAG_MkPair, 2, (V[]){v_t_2425, v_st_2419});
        }
        default: return heff_nomatch(v_x11_2418);
        }
      }
      default: return heff_nomatch(v_x1_2417);
      }
    }
    default: return heff_nomatch(v_x11_2410);
    }
  }
}
V g_heff_2esyntax_2esurface_2esegmentOf_24s1547151193x813882637_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2esurface_2esegmentOf_24s1547151193x813882637(a0, a[1], a[2], a[3], a[4]); heff_drop(a0); return r;
}
V g_heff_2esyntax_2esurface_2epushS_24s1868233564x1858628873_lam0(V self, V *args);
V g_heff_2esyntax_2esurface_2epushS_24s1868233564x1858628873_lam1(V self, V *args);
Clo g_heff_2esyntax_2esurface_2epushS_24s1868233564x1858628873_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2epushS_24s1868233564x1858628873_entry, 4, 0};

V g_heff_2esyntax_2esurface_2epushS_24s1868233564x1858628873(V v_fix_240, V v_lenient_241, V v_st_242, V v_r_243) {
top: ;
  V v_t_244 = heff_dup(heff_rfield(v_st_242, 0));
  switch (heff_tag_of(v_t_244)) {
  case TAG_Nil: {
    heff_drop(v_fix_240);
    return heff_clo_n(g_heff_2esyntax_2esurface_2epushS_24s1868233564x1858628873_lam0, 1, 2, (V[]){v_r_243, v_st_242});
  }
  case TAG_Cons: {
    V v_before_249 = heff_field(v_t_244, 0);
    heff_take_n(v_t_244, 1ULL, 2);
    V v_m_2411 = (g_heff_2esyntax_2esurface_2efirstS(heff_dup(v_fix_240), v_lenient_241, v_before_249, heff_dup(heff_rfield(v_r_243, 0))));
    return heff_clo_n(g_heff_2esyntax_2esurface_2epushS_24s1868233564x1858628873_lam1, 1, 5, (V[]){v_m_2411, v_st_242, v_fix_240, heff_dup(v_lenient_241), v_r_243});
  }
  default: return heff_nomatch(v_t_244);
  }
}
V g_heff_2esyntax_2esurface_2epushS_24s1868233564x1858628873_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2esyntax_2esurface_2epushS_24s1868233564x1858628873(a[0], a1, a[2], a[3]); heff_drop(a1); return r;
}
V g_heff_2esyntax_2esurface_2epushS_24s1868233564x1858628873_lam0(V self, V *args) {
  V v_st_245 = args[0];
  V v_r_243 = heff_env(self)[0];
  V v_st_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){heff_take_field(v_r_243, 0), heff_take_field(v_st_242, 0)});
  V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){heff_get_n(v_r_243, 1, 2), heff_get_n(v_st_242, 1, 2)});
  V v_t_248 = heff_tag_n(TAG_Right, 1, (V[]){heff_rec_n(2, shape_ops__out, (V[]){v_t_246, v_t_247})});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_248, v_st_245});
}
V g_heff_2esyntax_2esurface_2epushS_24s1868233564x1858628873_lam1(V self, V *args) {
  V v_st_2412 = args[0];
  V v_m_2411 = heff_env(self)[0];
  V v_st_242 = heff_env(self)[1];
  V v_fix_240 = heff_env(self)[2];
  V v_lenient_241 = heff_env(self)[3];
  V v_r_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_x1_2413 = heff_tr(heff_call(v_m_2411, 1, (V[]){v_st_2412}));
  switch (heff_tag_of(v_x1_2413)) {
  case TAG_MkPair: {
    V v_x11_2414 = heff_field(v_x1_2413, 0);
    V v_st_2415 = heff_field(v_x1_2413, 1);
    V v_ru_24x1_2413_24MkPair = heff_take_reuse_n(v_x1_2413, 3ULL, 2);
    switch (heff_tag_of(v_x11_2414)) {
    case TAG_Left: {
      V v_e_2416 = heff_field(v_x11_2414, 0);
      heff_take_n(v_x11_2414, 1ULL, 1);
      heff_drop_rec(v_st_242, 2);
      heff_drop(v_fix_240);
      heff_drop(v_lenient_241);
      heff_drop_rec(v_r_243, 2);
      return heff_tag_at_n(v_ru_24x1_2413_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2416}), v_st_2415});
    }
    case TAG_Right: {
      V v_x_2417 = heff_field(v_x11_2414, 0);
      V v_ru_24x11_2414_24Right = heff_take_reuse_n(v_x11_2414, 1ULL, 1);
      if ((heff_dup(v_x_2417) == NTAG(TAG_True))) {
        heff_drop_cell(v_ru_24x1_2413_24MkPair, 2);
        heff_drop(v_x_2417);
        heff_drop_cell(v_ru_24x11_2414_24Right, 1);
        V v_t_2418 = heff_dup(heff_rfield(v_st_242, 0));
        V v_t_2427;
        switch (heff_tag_of(v_t_2418)) {
        case TAG_Nil: {
          v_t_2427 = v_st_242;
          break;
        }
        case TAG_Cons: {
          V v_o_2419 = heff_field(v_t_2418, 0);
          V v_os_2420 = heff_field(v_t_2418, 1);
          heff_take_n(v_t_2418, 3ULL, 2);
          V v_t_2421 = heff_dup(heff_rfield(v_st_242, 1));
          switch (heff_tag_of(v_t_2421)) {
          case TAG_Nil: {
            heff_drop(v_o_2419);
            heff_drop(v_os_2420);
            v_t_2427 = v_st_242;
            break;
          }
          case TAG_Cons: {
            V v_r_2422 = heff_field(v_t_2421, 0);
            V v_it2_2423 = heff_field(v_t_2421, 1);
            heff_take_n(v_t_2421, 3ULL, 2);
            switch (heff_tag_of(v_it2_2423)) {
            case TAG_Nil: {
              heff_drop(v_o_2419);
              heff_drop(v_os_2420);
              heff_drop(v_r_2422);
              v_t_2427 = v_st_242;
              break;
            }
            case TAG_Cons: {
              V v_l_2424 = heff_field(v_it2_2423, 0);
              V v_rest_2425 = heff_field(v_it2_2423, 1);
              heff_take_n(v_it2_2423, 3ULL, 2);
              heff_drop_rec(v_st_242, 2);
              V v_t_2426 = (g_heff_2esyntax_2esurface_2eapplyOp(v_o_2419, v_l_2424, v_r_2422));
              v_t_2427 = heff_rec_n(2, shape_ops__out, (V[]){v_os_2420, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2426, v_rest_2425})});
              break;
            }
            default: heff_nomatch(v_it2_2423);
            }
            break;
          }
          default: heff_nomatch(v_t_2421);
          }
          break;
        }
        default: heff_nomatch(v_t_2418);
        }
        V v_t_2428 = ({ V a_0 = v_fix_240; V a_1 = v_lenient_241; V a_2 = v_t_2427; V a_3 = v_r_243; V r_ = (g_heff_2esyntax_2esurface_2epushS_24s1868233564x1858628873(a_0, a_1, a_2, a_3)); heff_drop(v_lenient_241); r_; });
        V f_ = v_t_2428;
        args[0] = v_st_2415;
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      } else {
        heff_drop(v_fix_240);
        heff_drop(v_lenient_241);
        heff_drop(v_x_2417);
        V v_t_2429 = heff_tag_n(TAG_Cons, 2, (V[]){heff_take_field(v_r_243, 0), heff_take_field(v_st_242, 0)});
        V v_t_2430 = heff_tag_n(TAG_Cons, 2, (V[]){heff_get_n(v_r_243, 1, 2), heff_get_n(v_st_242, 1, 2)});
        V v_t_2431 = heff_tag_at_n(v_ru_24x11_2414_24Right, TAG_Right, 1, (V[]){heff_rec_n(2, shape_ops__out, (V[]){v_t_2429, v_t_2430})});
        return heff_tag_at_n(v_ru_24x1_2413_24MkPair, TAG_MkPair, 2, (V[]){v_t_2431, v_st_2415});
      }
    }
    default: return heff_nomatch(v_x11_2414);
    }
  }
  default: return heff_nomatch(v_x1_2413);
  }
}
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str0, 3, "con");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str1, 3, "var");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str2, 7, " := e)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str3, 51, " := ...)` names an argument, after a function: `f (");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str4, 2, "`(");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str5, 2, "b[");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str6, 1, "[");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str7, 3, "Nil");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str8, 4, "Cons");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str9, 70, "heff has no tuples: a record holds values together, `{ x = a, y = b }`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str10, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str11, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str12, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str13, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str14, 61, "an instance argument is bound before `->`: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str15, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str16, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str17, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str18, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str19, 3, "con");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str20, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str21, 3, "var");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str22, 3, "neg");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str23, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str24, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str25, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str26, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str27, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str28, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str29, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str30, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str31, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str32, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str33, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str34, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str35, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str36, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str37, 5, "break");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str38, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str39, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str40, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str41, 12, "unexpected `");
V g_heff_2esyntax_2esurface_2eexprL_lam0(V self, V *args);
V g_heff_2esyntax_2esurface_2eexprL_lam1(V self, V *args);
V g_heff_2esyntax_2esurface_2eexprL_lam2(V self, V *args);
V g_heff_2esyntax_2esurface_2eexprL_lam3(V self, V *args);
V g_heff_2esyntax_2esurface_2eexprL_lam4(V self, V *args);
V g_heff_2esyntax_2esurface_2eexprL_lam6(V self, V *args);
V g_heff_2esyntax_2esurface_2eexprL_lam5(V self, V *args);
V g_heff_2esyntax_2esurface_2eexprL_lam7(V self, V *args);
V g_heff_2esyntax_2esurface_2eexprL_lam8(V self, V *args);
V g_heff_2esyntax_2esurface_2eexprL_lam9(V self, V *args);
V g_heff_2esyntax_2esurface_2eexprL_lam10(V self, V *args);
V g_heff_2esyntax_2esurface_2eexprL_lam11(V self, V *args);
V g_heff_2esyntax_2esurface_2eexprL_lam12(V self, V *args);
Clo g_heff_2esyntax_2esurface_2eexprL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eexprL_entry, 3, 0};

V g_heff_2esyntax_2esurface_2eexprL(V v_r_240, V v_e0_241, V v_z_242) {
top: ;
  switch (heff_tag_of(v_e0_241)) {
  case TAG_Atom: {
    V v_t_243 = heff_field(v_e0_241, 0);
    V v_ru_24e0_241_24Atom = heff_take_reuse_n(v_e0_241, 1ULL, 1);
    heff_drop_rec(v_r_240, 3);
    if (heff_strEq_c(heff_dup(heff_rfield(v_t_243, 0)), ((V)&g_heff_2esyntax_2esurface_2eexprL_str0))) {
      heff_drop_cell(v_ru_24e0_241_24Atom, 1);
      HEFF_LAST return g_heff_2esyntax_2esurface_2econAtom(v_t_243, NTAG(TAG_Nil), v_z_242);
    } else {
      if (heff_strEq_c(heff_dup(heff_rfield(v_t_243, 0)), ((V)&g_heff_2esyntax_2esurface_2eexprL_str1))) {
        heff_drop_cell(v_ru_24e0_241_24Atom, 1);
        HEFF_LAST return g_heff_2esyntax_2esurface_2evarAtom(v_t_243, NTAG(TAG_Nil), v_z_242);
      } else {
        V v_x_246 = (g_heff_2esyntax_2esurface_2eatomTok(v_t_243));
        return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24e0_241_24Atom, TAG_Right, 1, (V[]){v_x_246}), v_z_242});
      }
    }
  }
  case TAG_EParen: {
    V v_o_247 = heff_field(v_e0_241, 0);
    V v_e_248 = heff_field(v_e0_241, 1);
    V v_c_249 = heff_field(v_e0_241, 2);
    heff_take_n(v_e0_241, 7ULL, 3);
    return ({ V a_0 = v_r_240; V a_1 = v_o_247; V a_2 = v_e_248; V a_3 = v_c_249; V a_4 = v_z_242; V r_ = (g_heff_2esyntax_2esurface_2eparenL(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_o_247); r_; });
  }
  case TAG_Named: {
    V v_o_2410 = heff_field(v_e0_241, 0);
    V v_x_2411 = heff_field(v_e0_241, 1);
    V v_e_2413 = heff_field(v_e0_241, 3);
    V v_c_2414 = heff_field(v_e0_241, 4);
    heff_take_n(v_e0_241, 27ULL, 5);
    V v_m_2415 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_2413}));
    V v_x1_2416 = heff_tr(heff_call(v_m_2415, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x1_2416)) {
    case TAG_MkPair: {
      V v_x11_2417 = heff_field(v_x1_2416, 0);
      V v_st_2418 = heff_field(v_x1_2416, 1);
      V v_ru_24x1_2416_24MkPair = heff_take_reuse_n(v_x1_2416, 3ULL, 2);
      switch (heff_tag_of(v_x11_2417)) {
      case TAG_Left: {
        V v_e_2419 = heff_field(v_x11_2417, 0);
        heff_take_n(v_x11_2417, 1ULL, 1);
        heff_drop_rec(v_o_2410, 9);
        heff_drop_rec(v_x_2411, 9);
        heff_drop_rec(v_c_2414, 9);
        return heff_tag_at_n(v_ru_24x1_2416_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2419}), v_st_2418});
      }
      case TAG_Right: {
        V v_ru_24x11_2417_24Right = heff_take_reuse_n(v_x11_2417, 0ULL, 1);
        V v_t_2421 = heff_strAppend(heff_dup(heff_rfield(v_x_2411, 1)), ((V)&g_heff_2esyntax_2esurface_2eexprL_str2));
        V v_t_2422 = heff_strAppend(heff_get_n(v_x_2411, 1, 9), heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eexprL_str3), v_t_2421));
        V v_t_2423 = heff_tag_n(TAG_EInvalid, 1, (V[]){heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eexprL_str4), v_t_2422)});
        V v_t_2424 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_o_2410, 3, 9), heff_get_n(v_c_2414, 4, 9)});
        V v_t_2425 = heff_tag_at_n(v_ru_24x11_2417_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2423, v_t_2424})});
        return heff_tag_at_n(v_ru_24x1_2416_24MkPair, TAG_MkPair, 2, (V[]){v_t_2425, v_st_2418});
      }
      default: return heff_nomatch(v_x11_2417);
      }
    }
    default: return heff_nomatch(v_x1_2416);
    }
  }
  case TAG_Tup: {
    V v_o_2426 = heff_field(v_e0_241, 0);
    V v_es_2427 = heff_field(v_e0_241, 1);
    V v_c_2429 = heff_field(v_e0_241, 3);
    heff_take_n(v_e0_241, 11ULL, 4);
    if (heff_strEq_c(heff_dup(heff_rfield(v_o_2426, 1)), ((V)&g_heff_2esyntax_2esurface_2eexprL_str5))) {
      V v_m_2432 = (g_prelude_2etraverse_24s499544530x2060473942(heff_clo_n(g_heff_2esyntax_2esurface_2eexprL_lam0, 1, 1, (V[]){v_r_240}), v_es_2427));
      V v_x1_2433 = heff_tr(heff_call(v_m_2432, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_2433)) {
      case TAG_MkPair: {
        V v_x11_2434 = heff_field(v_x1_2433, 0);
        V v_st_2435 = heff_field(v_x1_2433, 1);
        V v_ru_24x1_2433_24MkPair = heff_take_reuse_n(v_x1_2433, 3ULL, 2);
        switch (heff_tag_of(v_x11_2434)) {
        case TAG_Left: {
          V v_e_2436 = heff_field(v_x11_2434, 0);
          heff_take_n(v_x11_2434, 1ULL, 1);
          heff_drop_rec(v_o_2426, 9);
          heff_drop_rec(v_c_2429, 9);
          return heff_tag_at_n(v_ru_24x1_2433_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2436}), v_st_2435});
        }
        case TAG_Right: {
          V v_x_2437 = heff_field(v_x11_2434, 0);
          V v_ru_24x11_2434_24Right = heff_take_reuse_n(v_x11_2434, 1ULL, 1);
          V v_t_2438 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_o_2426, 3, 9), heff_get_n(v_c_2429, 4, 9)});
          V v_t_2439 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_2434_24Right, TAG_EBinary, 1, (V[]){v_x_2437}), v_t_2438});
          return heff_tag_at_n(v_ru_24x1_2433_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2439}), v_st_2435});
        }
        default: return heff_nomatch(v_x11_2434);
        }
      }
      default: return heff_nomatch(v_x1_2433);
      }
    } else {
      if (heff_strEq_c(heff_dup(heff_rfield(v_o_2426, 1)), ((V)&g_heff_2esyntax_2esurface_2eexprL_str6))) {
        V v_m_2441 = (g_prelude_2etraverse_24s499544530x2060473942(heff_get_n(v_r_240, 0, 3), v_es_2427));
        V v_x1_2442 = heff_tr(heff_call(v_m_2441, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_2442)) {
        case TAG_MkPair: {
          V v_x11_2443 = heff_field(v_x1_2442, 0);
          V v_st_2444 = heff_field(v_x1_2442, 1);
          V v_ru_24x1_2442_24MkPair = heff_take_reuse_n(v_x1_2442, 3ULL, 2);
          switch (heff_tag_of(v_x11_2443)) {
          case TAG_Left: {
            V v_e_2445 = heff_field(v_x11_2443, 0);
            heff_take_n(v_x11_2443, 1ULL, 1);
            heff_drop_rec(v_o_2426, 9);
            heff_drop_rec(v_c_2429, 9);
            return heff_tag_at_n(v_ru_24x1_2442_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2445}), v_st_2444});
          }
          case TAG_Right: {
            V v_x_2446 = heff_field(v_x11_2443, 0);
            V v_ru_24x11_2443_24Right = heff_take_reuse_n(v_x11_2443, 1ULL, 1);
            V v_sp_2447 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_o_2426, 3, 9), heff_get_n(v_c_2429, 4, 9)});
            V v_t_2448 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_2443_24Right, TAG_ETag, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2eexprL_str7)}), heff_dup(v_sp_2447)});
            V v_x_2453 = ({ V a_0 = heff_clo_n(g_heff_2esyntax_2esurface_2eexprL_lam1, 2, 1, (V[]){v_sp_2447}); V a_1 = v_t_2448; V a_2 = v_x_2446; V r_ = heff_tr(g_heff_2esyntax_2esurface_2efoldr(a_0, a_1, a_2)); heff_drop(v_x_2446); r_; });
            return heff_tag_at_n(v_ru_24x1_2442_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2453}), v_st_2444});
          }
          default: return heff_nomatch(v_x11_2443);
          }
        }
        default: return heff_nomatch(v_x1_2442);
        }
      } else {
        V v_m_2454 = (g_prelude_2etraverse_24s499544530x2060473942(heff_get_n(v_r_240, 0, 3), v_es_2427));
        V v_x1_2455 = heff_tr(heff_call(v_m_2454, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_2455)) {
        case TAG_MkPair: {
          V v_x11_2456 = heff_field(v_x1_2455, 0);
          V v_st_2457 = heff_field(v_x1_2455, 1);
          V v_ru_24x1_2455_24MkPair = heff_take_reuse_n(v_x1_2455, 3ULL, 2);
          switch (heff_tag_of(v_x11_2456)) {
          case TAG_Left: {
            V v_e_2458 = heff_field(v_x11_2456, 0);
            heff_take_n(v_x11_2456, 1ULL, 1);
            heff_drop_rec(v_o_2426, 9);
            heff_drop_rec(v_c_2429, 9);
            return heff_tag_at_n(v_ru_24x1_2455_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2458}), v_st_2457});
          }
          case TAG_Right: {
            V v_ru_24x11_2456_24Right = heff_take_reuse_n(v_x11_2456, 0ULL, 1);
            V v_t_2460 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_o_2426, 3, 9), heff_get_n(v_c_2429, 4, 9)});
            V v_t_2461 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_2456_24Right, TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2eexprL_str9)}), v_t_2460});
            return heff_tag_at_n(v_ru_24x1_2455_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2461}), v_st_2457});
          }
          default: return heff_nomatch(v_x11_2456);
          }
        }
        default: return heff_nomatch(v_x1_2455);
        }
      }
    }
  }
  case TAG_Seg: {
    heff_drop_rec(v_r_240, 3);
    V v_t_2465 = (g_heff_2esyntax_2ecst_2efirstE(v_e0_241));
    V v_t_2466 = ({ V a_0 = v_e0_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e0_241, 3); r_; });
    V v_t_2467 = heff_strAppend(heff_get_n(v_t_2466, 1, 9), ((V)&g_heff_2esyntax_2esurface_2eexprL_str10));
    V v_msg_2468 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eexprL_str11), v_t_2467);
    V v_t_2469 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_2465, 3), heff_get_n(v_t_2465, 4, 9)});
    V v_t_2470 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_2468, v_t_2469, NTAG(TAG_Nothing)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2470}), v_z_242});
  }
  case TAG_Braces: {
    V v_o_2471 = heff_field(v_e0_241, 0);
    V v_fs_2472 = heff_field(v_e0_241, 1);
    V v_c_2474 = heff_field(v_e0_241, 3);
    heff_take_n(v_e0_241, 11ULL, 4);
    return (g_heff_2esyntax_2esurface_2ebracesL(v_r_240, v_o_2471, v_fs_2472, v_c_2474, v_z_242));
  }
  case TAG_Update: {
    V v_o_2475 = heff_field(v_e0_241, 0);
    V v_rec_2476 = heff_field(v_e0_241, 1);
    V v_fs_2478 = heff_field(v_e0_241, 3);
    V v_c_2480 = heff_field(v_e0_241, 5);
    heff_take_n(v_e0_241, 43ULL, 6);
    V v_m_2481 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_rec_2476}));
    V v_x1_2482 = heff_tr(heff_call(v_m_2481, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x1_2482)) {
    case TAG_MkPair: {
      V v_x11_2483 = heff_field(v_x1_2482, 0);
      V v_st_2484 = heff_field(v_x1_2482, 1);
      V v_ru_24x1_2482_24MkPair = heff_take_reuse_n(v_x1_2482, 3ULL, 2);
      switch (heff_tag_of(v_x11_2483)) {
      case TAG_Left: {
        V v_e_2485 = heff_field(v_x11_2483, 0);
        heff_take_n(v_x11_2483, 1ULL, 1);
        heff_drop_rec(v_r_240, 3);
        heff_drop_rec(v_o_2475, 9);
        heff_drop(v_fs_2478);
        heff_drop_rec(v_c_2480, 9);
        return heff_tag_at_n(v_ru_24x1_2482_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2485}), v_st_2484});
      }
      case TAG_Right: {
        V v_x_2486 = heff_field(v_x11_2483, 0);
        heff_take_n(v_x11_2483, 1ULL, 1);
        V v_m_2488 = (g_prelude_2etraverse_24s499544530x2060473942(heff_clo_n(g_heff_2esyntax_2esurface_2eexprL_lam2, 1, 1, (V[]){v_r_240}), v_fs_2478));
        V v_x1_2489 = heff_tr(heff_call(v_m_2488, 1, (V[]){v_st_2484}));
        switch (heff_tag_of(v_x1_2489)) {
        case TAG_MkPair: {
          V v_x11_2490 = heff_field(v_x1_2489, 0);
          V v_st_2491 = heff_field(v_x1_2489, 1);
          V v_ru_24x1_2489_24MkPair = heff_take_reuse_n(v_x1_2489, 3ULL, 2);
          switch (heff_tag_of(v_x11_2490)) {
          case TAG_Left: {
            V v_e_2492 = heff_field(v_x11_2490, 0);
            heff_take_n(v_x11_2490, 1ULL, 1);
            heff_drop_rec(v_o_2475, 9);
            heff_drop_rec(v_c_2480, 9);
            heff_drop(v_x_2486);
            heff_drop_cell(v_ru_24x1_2489_24MkPair, 2);
            return heff_tag_at_n(v_ru_24x1_2482_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2492}), v_st_2491});
          }
          case TAG_Right: {
            V v_x_2493 = heff_field(v_x11_2490, 0);
            heff_take_n(v_x11_2490, 1ULL, 1);
            V v_t_2494 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_o_2475, 3, 9), heff_get_n(v_c_2480, 4, 9)});
            V v_t_2495 = heff_tag_at_n(v_ru_24x1_2489_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_EUpdate, 2, (V[]){v_x_2486, v_x_2493}), v_t_2494});
            return heff_tag_at_n(v_ru_24x1_2482_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2495}), v_st_2491});
          }
          default: return heff_nomatch(v_x11_2490);
          }
        }
        default: return heff_nomatch(v_x1_2489);
        }
      }
      default: return heff_nomatch(v_x11_2483);
      }
    }
    default: return heff_nomatch(v_x1_2482);
    }
  }
  case TAG_EUSet: {
    heff_drop_rec(v_r_240, 3);
    V v_t_2499 = (g_heff_2esyntax_2ecst_2efirstE(v_e0_241));
    V v_t_24100 = ({ V a_0 = v_e0_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e0_241, 3); r_; });
    V v_t_24101 = heff_strAppend(heff_get_n(v_t_24100, 1, 9), ((V)&g_heff_2esyntax_2esurface_2eexprL_str12));
    V v_msg_24102 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eexprL_str13), v_t_24101);
    V v_t_24103 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_2499, 3), heff_get_n(v_t_2499, 4, 9)});
    V v_t_24104 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24102, v_t_24103, NTAG(TAG_Nothing)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24104}), v_z_242});
  }
  case TAG_InstB: {
    V v_o_24105 = heff_field(v_e0_241, 0);
    V v_d_24107 = heff_field(v_e0_241, 2);
    V v_c_24109 = heff_field(v_e0_241, 4);
    heff_take_n(v_e0_241, 21ULL, 5);
    V v_m_24110 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_d_24107));
    V v_x1_24111 = heff_tr(heff_call(v_m_24110, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x1_24111)) {
    case TAG_MkPair: {
      V v_x11_24112 = heff_field(v_x1_24111, 0);
      V v_st_24113 = heff_field(v_x1_24111, 1);
      V v_ru_24x1_24111_24MkPair = heff_take_reuse_n(v_x1_24111, 3ULL, 2);
      switch (heff_tag_of(v_x11_24112)) {
      case TAG_Left: {
        V v_e_24114 = heff_field(v_x11_24112, 0);
        heff_take_n(v_x11_24112, 1ULL, 1);
        heff_drop_rec(v_o_24105, 9);
        heff_drop_rec(v_c_24109, 9);
        return heff_tag_at_n(v_ru_24x1_24111_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24114}), v_st_24113});
      }
      case TAG_Right: {
        V v_ru_24x11_24112_24Right = heff_take_reuse_n(v_x11_24112, 0ULL, 1);
        V v_t_24116 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_o_24105, 3, 9), heff_get_n(v_c_24109, 4, 9)});
        V v_t_24117 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24112_24Right, TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2eexprL_str14)}), v_t_24116});
        return heff_tag_at_n(v_ru_24x1_24111_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24117}), v_st_24113});
      }
      default: return heff_nomatch(v_x11_24112);
      }
    }
    default: return heff_nomatch(v_x1_24111);
    }
  }
  case TAG_EFSet: {
    heff_drop_rec(v_r_240, 3);
    V v_t_24121 = (g_heff_2esyntax_2ecst_2efirstE(v_e0_241));
    V v_t_24122 = ({ V a_0 = v_e0_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e0_241, 3); r_; });
    V v_t_24123 = heff_strAppend(heff_get_n(v_t_24122, 1, 9), ((V)&g_heff_2esyntax_2esurface_2eexprL_str15));
    V v_msg_24124 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eexprL_str16), v_t_24123);
    V v_t_24125 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24121, 3), heff_get_n(v_t_24121, 4, 9)});
    V v_t_24126 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24124, v_t_24125, NTAG(TAG_Nothing)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24126}), v_z_242});
  }
  case TAG_EFDefault: {
    heff_drop_rec(v_r_240, 3);
    V v_t_24130 = (g_heff_2esyntax_2ecst_2efirstE(v_e0_241));
    V v_t_24131 = ({ V a_0 = v_e0_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e0_241, 3); r_; });
    V v_t_24132 = heff_strAppend(heff_get_n(v_t_24131, 1, 9), ((V)&g_heff_2esyntax_2esurface_2eexprL_str17));
    V v_msg_24133 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eexprL_str18), v_t_24132);
    V v_t_24134 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24130, 3), heff_get_n(v_t_24130, 4, 9)});
    V v_t_24135 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24133, v_t_24134, NTAG(TAG_Nothing)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24135}), v_z_242});
  }
  case TAG_Sum: {
    V v_kw_24136 = heff_field(v_e0_241, 0);
    V v_alts_24138 = heff_field(v_e0_241, 2);
    V v_c_24140 = heff_field(v_e0_241, 4);
    heff_take_n(v_e0_241, 21ULL, 5);
    V v_m_24142 = (g_prelude_2etraverse_24s499544530x2060473942(heff_clo_n(g_heff_2esyntax_2esurface_2eexprL_lam3, 1, 1, (V[]){v_r_240}), v_alts_24138));
    V v_x1_24143 = heff_tr(heff_call(v_m_24142, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x1_24143)) {
    case TAG_MkPair: {
      V v_x11_24144 = heff_field(v_x1_24143, 0);
      V v_st_24145 = heff_field(v_x1_24143, 1);
      V v_ru_24x1_24143_24MkPair = heff_take_reuse_n(v_x1_24143, 3ULL, 2);
      switch (heff_tag_of(v_x11_24144)) {
      case TAG_Left: {
        V v_e_24146 = heff_field(v_x11_24144, 0);
        heff_take_n(v_x11_24144, 1ULL, 1);
        heff_drop_rec(v_kw_24136, 9);
        heff_drop_rec(v_c_24140, 9);
        return heff_tag_at_n(v_ru_24x1_24143_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24146}), v_st_24145});
      }
      case TAG_Right: {
        V v_x_24147 = heff_field(v_x11_24144, 0);
        V v_ru_24x11_24144_24Right = heff_take_reuse_n(v_x11_24144, 1ULL, 1);
        V v_t_24148 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_24136, 3, 9), heff_get_n(v_c_24140, 4, 9)});
        V v_t_24149 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24144_24Right, TAG_ESum, 1, (V[]){v_x_24147}), v_t_24148});
        return heff_tag_at_n(v_ru_24x1_24143_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24149}), v_st_24145});
      }
      default: return heff_nomatch(v_x11_24144);
      }
    }
    default: return heff_nomatch(v_x1_24143);
    }
  }
  case TAG_ECon: {
    V v_c_24150 = heff_field(v_e0_241, 0);
    V v_args_24151 = heff_field(v_e0_241, 1);
    heff_take_n(v_e0_241, 3ULL, 2);
    V v_t_24152 = (g_heff_2esyntax_2esurface_2econL(v_r_240, v_c_24150, v_args_24151));
    return heff_tail(v_t_24152, 1, (V[]){v_z_242});
  }
  case TAG_EField: {
    V v_e_24153 = heff_field(v_e0_241, 0);
    V v_f_24154 = heff_field(v_e0_241, 1);
    V v_ru_24e0_241_24EField = heff_take_reuse_n(v_e0_241, 3ULL, 2);
    HeffT2 v_t_24155 = (g_heff_2esyntax_2esurface_2efieldsOf_24cpr(heff_tag_at_n(v_ru_24e0_241_24EField, TAG_EField, 2, (V[]){v_e_24153, v_f_24154}), NTAG(TAG_Nil)));
    {
      V v_field_24156 = v_t_24155.f[0];
      V v_field_24157 = v_t_24155.f[1];
      V v_it1_24158 = v_field_24156;
      V v_fs_24159 = v_field_24157;
      switch (heff_tag_of(v_it1_24158)) {
      case TAG_Atom: {
        V v_t_24160 = heff_field(v_it1_24158, 0);
        V v_ru_24it1_24158_24Atom = heff_take_reuse_n(v_it1_24158, 1ULL, 1);
        heff_drop_rec(v_r_240, 3);
        if (heff_strEq_c(heff_dup(heff_rfield(v_t_24160, 0)), ((V)&g_heff_2esyntax_2esurface_2eexprL_str19))) {
          heff_drop_cell(v_ru_24it1_24158_24Atom, 1);
          HEFF_LAST return g_heff_2esyntax_2esurface_2econAtom(v_t_24160, v_fs_24159, v_z_242);
        } else {
          if (heff_strEq_c(heff_dup(heff_rfield(v_t_24160, 0)), ((V)&g_heff_2esyntax_2esurface_2eexprL_str20))) {
            heff_drop_cell(v_ru_24it1_24158_24Atom, 1);
            HEFF_LAST return g_heff_2esyntax_2esurface_2ekwAtom(v_t_24160, v_fs_24159, v_z_242);
          } else {
            if (heff_strEq_c(heff_dup(heff_rfield(v_t_24160, 0)), ((V)&g_heff_2esyntax_2esurface_2eexprL_str21))) {
              heff_drop_cell(v_ru_24it1_24158_24Atom, 1);
              HEFF_LAST return g_heff_2esyntax_2esurface_2evarAtom(v_t_24160, v_fs_24159, v_z_242);
            } else {
              V v_e_24164 = (g_heff_2esyntax_2esurface_2eatomTok(v_t_24160));
              V v_t_24165 = (g_list_2emap_24s513201124x806973253(v_fs_24159));
              V v_x_24166 = (g_heff_2esyntax_2epresyntax_2eapp(v_e_24164, v_t_24165));
              return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24it1_24158_24Atom, TAG_Right, 1, (V[]){v_x_24166}), v_z_242});
            }
          }
        }
      }
      case TAG_EParen: {
        V v_m_24170 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24158}));
        V v_x1_24171 = heff_tr(heff_call(v_m_24170, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24171)) {
        case TAG_MkPair: {
          V v_x11_24172 = heff_field(v_x1_24171, 0);
          V v_st_24173 = heff_field(v_x1_24171, 1);
          V v_ru_24x1_24171_24MkPair = heff_take_reuse_n(v_x1_24171, 3ULL, 2);
          switch (heff_tag_of(v_x11_24172)) {
          case TAG_Left: {
            V v_e_24174 = heff_field(v_x11_24172, 0);
            heff_take_n(v_x11_24172, 1ULL, 1);
            heff_drop(v_fs_24159);
            return heff_tag_at_n(v_ru_24x1_24171_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24174}), v_st_24173});
          }
          case TAG_Right: {
            V v_x_24175 = heff_field(v_x11_24172, 0);
            heff_take_n(v_x11_24172, 1ULL, 1);
            V v_t_24176 = (g_list_2emap_24s513201124x806973253(v_fs_24159));
            V v_x_24177 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24175, v_t_24176));
            return heff_tag_at_n(v_ru_24x1_24171_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24177}), v_st_24173});
          }
          default: return heff_nomatch(v_x11_24172);
          }
        }
        default: return heff_nomatch(v_x1_24171);
        }
      }
      case TAG_Named: {
        V v_m_24183 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24158}));
        V v_x1_24184 = heff_tr(heff_call(v_m_24183, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24184)) {
        case TAG_MkPair: {
          V v_x11_24185 = heff_field(v_x1_24184, 0);
          V v_st_24186 = heff_field(v_x1_24184, 1);
          V v_ru_24x1_24184_24MkPair = heff_take_reuse_n(v_x1_24184, 3ULL, 2);
          switch (heff_tag_of(v_x11_24185)) {
          case TAG_Left: {
            V v_e_24187 = heff_field(v_x11_24185, 0);
            heff_take_n(v_x11_24185, 1ULL, 1);
            heff_drop(v_fs_24159);
            return heff_tag_at_n(v_ru_24x1_24184_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24187}), v_st_24186});
          }
          case TAG_Right: {
            V v_x_24188 = heff_field(v_x11_24185, 0);
            heff_take_n(v_x11_24185, 1ULL, 1);
            V v_t_24189 = (g_list_2emap_24s513201124x806973253(v_fs_24159));
            V v_x_24190 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24188, v_t_24189));
            return heff_tag_at_n(v_ru_24x1_24184_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24190}), v_st_24186});
          }
          default: return heff_nomatch(v_x11_24185);
          }
        }
        default: return heff_nomatch(v_x1_24184);
        }
      }
      case TAG_Tup: {
        V v_m_24195 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24158}));
        V v_x1_24196 = heff_tr(heff_call(v_m_24195, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24196)) {
        case TAG_MkPair: {
          V v_x11_24197 = heff_field(v_x1_24196, 0);
          V v_st_24198 = heff_field(v_x1_24196, 1);
          V v_ru_24x1_24196_24MkPair = heff_take_reuse_n(v_x1_24196, 3ULL, 2);
          switch (heff_tag_of(v_x11_24197)) {
          case TAG_Left: {
            V v_e_24199 = heff_field(v_x11_24197, 0);
            heff_take_n(v_x11_24197, 1ULL, 1);
            heff_drop(v_fs_24159);
            return heff_tag_at_n(v_ru_24x1_24196_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24199}), v_st_24198});
          }
          case TAG_Right: {
            V v_x_24200 = heff_field(v_x11_24197, 0);
            heff_take_n(v_x11_24197, 1ULL, 1);
            V v_t_24201 = (g_list_2emap_24s513201124x806973253(v_fs_24159));
            V v_x_24202 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24200, v_t_24201));
            return heff_tag_at_n(v_ru_24x1_24196_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24202}), v_st_24198});
          }
          default: return heff_nomatch(v_x11_24197);
          }
        }
        default: return heff_nomatch(v_x1_24196);
        }
      }
      case TAG_Seg: {
        V v_m_24206 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24158}));
        V v_x1_24207 = heff_tr(heff_call(v_m_24206, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24207)) {
        case TAG_MkPair: {
          V v_x11_24208 = heff_field(v_x1_24207, 0);
          V v_st_24209 = heff_field(v_x1_24207, 1);
          V v_ru_24x1_24207_24MkPair = heff_take_reuse_n(v_x1_24207, 3ULL, 2);
          switch (heff_tag_of(v_x11_24208)) {
          case TAG_Left: {
            V v_e_24210 = heff_field(v_x11_24208, 0);
            heff_take_n(v_x11_24208, 1ULL, 1);
            heff_drop(v_fs_24159);
            return heff_tag_at_n(v_ru_24x1_24207_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24210}), v_st_24209});
          }
          case TAG_Right: {
            V v_x_24211 = heff_field(v_x11_24208, 0);
            heff_take_n(v_x11_24208, 1ULL, 1);
            V v_t_24212 = (g_list_2emap_24s513201124x806973253(v_fs_24159));
            V v_x_24213 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24211, v_t_24212));
            return heff_tag_at_n(v_ru_24x1_24207_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24213}), v_st_24209});
          }
          default: return heff_nomatch(v_x11_24208);
          }
        }
        default: return heff_nomatch(v_x1_24207);
        }
      }
      case TAG_Braces: {
        V v_m_24218 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24158}));
        V v_x1_24219 = heff_tr(heff_call(v_m_24218, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24219)) {
        case TAG_MkPair: {
          V v_x11_24220 = heff_field(v_x1_24219, 0);
          V v_st_24221 = heff_field(v_x1_24219, 1);
          V v_ru_24x1_24219_24MkPair = heff_take_reuse_n(v_x1_24219, 3ULL, 2);
          switch (heff_tag_of(v_x11_24220)) {
          case TAG_Left: {
            V v_e_24222 = heff_field(v_x11_24220, 0);
            heff_take_n(v_x11_24220, 1ULL, 1);
            heff_drop(v_fs_24159);
            return heff_tag_at_n(v_ru_24x1_24219_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24222}), v_st_24221});
          }
          case TAG_Right: {
            V v_x_24223 = heff_field(v_x11_24220, 0);
            heff_take_n(v_x11_24220, 1ULL, 1);
            V v_t_24224 = (g_list_2emap_24s513201124x806973253(v_fs_24159));
            V v_x_24225 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24223, v_t_24224));
            return heff_tag_at_n(v_ru_24x1_24219_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24225}), v_st_24221});
          }
          default: return heff_nomatch(v_x11_24220);
          }
        }
        default: return heff_nomatch(v_x1_24219);
        }
      }
      case TAG_Update: {
        V v_m_24232 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24158}));
        V v_x1_24233 = heff_tr(heff_call(v_m_24232, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24233)) {
        case TAG_MkPair: {
          V v_x11_24234 = heff_field(v_x1_24233, 0);
          V v_st_24235 = heff_field(v_x1_24233, 1);
          V v_ru_24x1_24233_24MkPair = heff_take_reuse_n(v_x1_24233, 3ULL, 2);
          switch (heff_tag_of(v_x11_24234)) {
          case TAG_Left: {
            V v_e_24236 = heff_field(v_x11_24234, 0);
            heff_take_n(v_x11_24234, 1ULL, 1);
            heff_drop(v_fs_24159);
            return heff_tag_at_n(v_ru_24x1_24233_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24236}), v_st_24235});
          }
          case TAG_Right: {
            V v_x_24237 = heff_field(v_x11_24234, 0);
            heff_take_n(v_x11_24234, 1ULL, 1);
            V v_t_24238 = (g_list_2emap_24s513201124x806973253(v_fs_24159));
            V v_x_24239 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24237, v_t_24238));
            return heff_tag_at_n(v_ru_24x1_24233_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24239}), v_st_24235});
          }
          default: return heff_nomatch(v_x11_24234);
          }
        }
        default: return heff_nomatch(v_x1_24233);
        }
      }
      case TAG_EUSet: {
        V v_m_24243 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24158}));
        V v_x1_24244 = heff_tr(heff_call(v_m_24243, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24244)) {
        case TAG_MkPair: {
          V v_x11_24245 = heff_field(v_x1_24244, 0);
          V v_st_24246 = heff_field(v_x1_24244, 1);
          V v_ru_24x1_24244_24MkPair = heff_take_reuse_n(v_x1_24244, 3ULL, 2);
          switch (heff_tag_of(v_x11_24245)) {
          case TAG_Left: {
            V v_e_24247 = heff_field(v_x11_24245, 0);
            heff_take_n(v_x11_24245, 1ULL, 1);
            heff_drop(v_fs_24159);
            return heff_tag_at_n(v_ru_24x1_24244_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24247}), v_st_24246});
          }
          case TAG_Right: {
            V v_x_24248 = heff_field(v_x11_24245, 0);
            heff_take_n(v_x11_24245, 1ULL, 1);
            V v_t_24249 = (g_list_2emap_24s513201124x806973253(v_fs_24159));
            V v_x_24250 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24248, v_t_24249));
            return heff_tag_at_n(v_ru_24x1_24244_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24250}), v_st_24246});
          }
          default: return heff_nomatch(v_x11_24245);
          }
        }
        default: return heff_nomatch(v_x1_24244);
        }
      }
      case TAG_InstB: {
        V v_m_24256 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24158}));
        V v_x1_24257 = heff_tr(heff_call(v_m_24256, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24257)) {
        case TAG_MkPair: {
          V v_x11_24258 = heff_field(v_x1_24257, 0);
          V v_st_24259 = heff_field(v_x1_24257, 1);
          V v_ru_24x1_24257_24MkPair = heff_take_reuse_n(v_x1_24257, 3ULL, 2);
          switch (heff_tag_of(v_x11_24258)) {
          case TAG_Left: {
            V v_e_24260 = heff_field(v_x11_24258, 0);
            heff_take_n(v_x11_24258, 1ULL, 1);
            heff_drop(v_fs_24159);
            return heff_tag_at_n(v_ru_24x1_24257_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24260}), v_st_24259});
          }
          case TAG_Right: {
            V v_x_24261 = heff_field(v_x11_24258, 0);
            heff_take_n(v_x11_24258, 1ULL, 1);
            V v_t_24262 = (g_list_2emap_24s513201124x806973253(v_fs_24159));
            V v_x_24263 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24261, v_t_24262));
            return heff_tag_at_n(v_ru_24x1_24257_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24263}), v_st_24259});
          }
          default: return heff_nomatch(v_x11_24258);
          }
        }
        default: return heff_nomatch(v_x1_24257);
        }
      }
      case TAG_EFSet: {
        V v_m_24267 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24158}));
        V v_x1_24268 = heff_tr(heff_call(v_m_24267, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24268)) {
        case TAG_MkPair: {
          V v_x11_24269 = heff_field(v_x1_24268, 0);
          V v_st_24270 = heff_field(v_x1_24268, 1);
          V v_ru_24x1_24268_24MkPair = heff_take_reuse_n(v_x1_24268, 3ULL, 2);
          switch (heff_tag_of(v_x11_24269)) {
          case TAG_Left: {
            V v_e_24271 = heff_field(v_x11_24269, 0);
            heff_take_n(v_x11_24269, 1ULL, 1);
            heff_drop(v_fs_24159);
            return heff_tag_at_n(v_ru_24x1_24268_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24271}), v_st_24270});
          }
          case TAG_Right: {
            V v_x_24272 = heff_field(v_x11_24269, 0);
            heff_take_n(v_x11_24269, 1ULL, 1);
            V v_t_24273 = (g_list_2emap_24s513201124x806973253(v_fs_24159));
            V v_x_24274 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24272, v_t_24273));
            return heff_tag_at_n(v_ru_24x1_24268_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24274}), v_st_24270});
          }
          default: return heff_nomatch(v_x11_24269);
          }
        }
        default: return heff_nomatch(v_x1_24268);
        }
      }
      case TAG_EFDefault: {
        V v_m_24278 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24158}));
        V v_x1_24279 = heff_tr(heff_call(v_m_24278, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24279)) {
        case TAG_MkPair: {
          V v_x11_24280 = heff_field(v_x1_24279, 0);
          V v_st_24281 = heff_field(v_x1_24279, 1);
          V v_ru_24x1_24279_24MkPair = heff_take_reuse_n(v_x1_24279, 3ULL, 2);
          switch (heff_tag_of(v_x11_24280)) {
          case TAG_Left: {
            V v_e_24282 = heff_field(v_x11_24280, 0);
            heff_take_n(v_x11_24280, 1ULL, 1);
            heff_drop(v_fs_24159);
            return heff_tag_at_n(v_ru_24x1_24279_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24282}), v_st_24281});
          }
          case TAG_Right: {
            V v_x_24283 = heff_field(v_x11_24280, 0);
            heff_take_n(v_x11_24280, 1ULL, 1);
            V v_t_24284 = (g_list_2emap_24s513201124x806973253(v_fs_24159));
            V v_x_24285 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24283, v_t_24284));
            return heff_tag_at_n(v_ru_24x1_24279_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24285}), v_st_24281});
          }
          default: return heff_nomatch(v_x11_24280);
          }
        }
        default: return heff_nomatch(v_x1_24279);
        }
      }
      case TAG_Sum: {
        V v_m_24291 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24158}));
        V v_x1_24292 = heff_tr(heff_call(v_m_24291, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24292)) {
        case TAG_MkPair: {
          V v_x11_24293 = heff_field(v_x1_24292, 0);
          V v_st_24294 = heff_field(v_x1_24292, 1);
          V v_ru_24x1_24292_24MkPair = heff_take_reuse_n(v_x1_24292, 3ULL, 2);
          switch (heff_tag_of(v_x11_24293)) {
          case TAG_Left: {
            V v_e_24295 = heff_field(v_x11_24293, 0);
            heff_take_n(v_x11_24293, 1ULL, 1);
            heff_drop(v_fs_24159);
            return heff_tag_at_n(v_ru_24x1_24292_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24295}), v_st_24294});
          }
          case TAG_Right: {
            V v_x_24296 = heff_field(v_x11_24293, 0);
            heff_take_n(v_x11_24293, 1ULL, 1);
            V v_t_24297 = (g_list_2emap_24s513201124x806973253(v_fs_24159));
            V v_x_24298 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24296, v_t_24297));
            return heff_tag_at_n(v_ru_24x1_24292_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24298}), v_st_24294});
          }
          default: return heff_nomatch(v_x11_24293);
          }
        }
        default: return heff_nomatch(v_x1_24292);
        }
      }
      case TAG_ECon: {
        V v_m_24301 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24158}));
        V v_x1_24302 = heff_tr(heff_call(v_m_24301, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24302)) {
        case TAG_MkPair: {
          V v_x11_24303 = heff_field(v_x1_24302, 0);
          V v_st_24304 = heff_field(v_x1_24302, 1);
          V v_ru_24x1_24302_24MkPair = heff_take_reuse_n(v_x1_24302, 3ULL, 2);
          switch (heff_tag_of(v_x11_24303)) {
          case TAG_Left: {
            V v_e_24305 = heff_field(v_x11_24303, 0);
            heff_take_n(v_x11_24303, 1ULL, 1);
            heff_drop(v_fs_24159);
            return heff_tag_at_n(v_ru_24x1_24302_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24305}), v_st_24304});
          }
          case TAG_Right: {
            V v_x_24306 = heff_field(v_x11_24303, 0);
            heff_take_n(v_x11_24303, 1ULL, 1);
            V v_t_24307 = (g_list_2emap_24s513201124x806973253(v_fs_24159));
            V v_x_24308 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24306, v_t_24307));
            return heff_tag_at_n(v_ru_24x1_24302_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24308}), v_st_24304});
          }
          default: return heff_nomatch(v_x11_24303);
          }
        }
        default: return heff_nomatch(v_x1_24302);
        }
      }
      case TAG_EField: {
        V v_m_24311 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24158}));
        V v_x1_24312 = heff_tr(heff_call(v_m_24311, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24312)) {
        case TAG_MkPair: {
          V v_x11_24313 = heff_field(v_x1_24312, 0);
          V v_st_24314 = heff_field(v_x1_24312, 1);
          V v_ru_24x1_24312_24MkPair = heff_take_reuse_n(v_x1_24312, 3ULL, 2);
          switch (heff_tag_of(v_x11_24313)) {
          case TAG_Left: {
            V v_e_24315 = heff_field(v_x11_24313, 0);
            heff_take_n(v_x11_24313, 1ULL, 1);
            heff_drop(v_fs_24159);
            return heff_tag_at_n(v_ru_24x1_24312_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24315}), v_st_24314});
          }
          case TAG_Right: {
            V v_x_24316 = heff_field(v_x11_24313, 0);
            heff_take_n(v_x11_24313, 1ULL, 1);
            V v_t_24317 = (g_list_2emap_24s513201124x806973253(v_fs_24159));
            V v_x_24318 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24316, v_t_24317));
            return heff_tag_at_n(v_ru_24x1_24312_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24318}), v_st_24314});
          }
          default: return heff_nomatch(v_x11_24313);
          }
        }
        default: return heff_nomatch(v_x1_24312);
        }
      }
      case TAG_ENeg: {
        V v_m_24321 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24158}));
        V v_x1_24322 = heff_tr(heff_call(v_m_24321, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24322)) {
        case TAG_MkPair: {
          V v_x11_24323 = heff_field(v_x1_24322, 0);
          V v_st_24324 = heff_field(v_x1_24322, 1);
          V v_ru_24x1_24322_24MkPair = heff_take_reuse_n(v_x1_24322, 3ULL, 2);
          switch (heff_tag_of(v_x11_24323)) {
          case TAG_Left: {
            V v_e_24325 = heff_field(v_x11_24323, 0);
            heff_take_n(v_x11_24323, 1ULL, 1);
            heff_drop(v_fs_24159);
            return heff_tag_at_n(v_ru_24x1_24322_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24325}), v_st_24324});
          }
          case TAG_Right: {
            V v_x_24326 = heff_field(v_x11_24323, 0);
            heff_take_n(v_x11_24323, 1ULL, 1);
            V v_t_24327 = (g_list_2emap_24s513201124x806973253(v_fs_24159));
            V v_x_24328 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24326, v_t_24327));
            return heff_tag_at_n(v_ru_24x1_24322_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24328}), v_st_24324});
          }
          default: return heff_nomatch(v_x11_24323);
          }
        }
        default: return heff_nomatch(v_x1_24322);
        }
      }
      case TAG_App: {
        V v_m_24331 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24158}));
        V v_x1_24332 = heff_tr(heff_call(v_m_24331, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24332)) {
        case TAG_MkPair: {
          V v_x11_24333 = heff_field(v_x1_24332, 0);
          V v_st_24334 = heff_field(v_x1_24332, 1);
          V v_ru_24x1_24332_24MkPair = heff_take_reuse_n(v_x1_24332, 3ULL, 2);
          switch (heff_tag_of(v_x11_24333)) {
          case TAG_Left: {
            V v_e_24335 = heff_field(v_x11_24333, 0);
            heff_take_n(v_x11_24333, 1ULL, 1);
            heff_drop(v_fs_24159);
            return heff_tag_at_n(v_ru_24x1_24332_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24335}), v_st_24334});
          }
          case TAG_Right: {
            V v_x_24336 = heff_field(v_x11_24333, 0);
            heff_take_n(v_x11_24333, 1ULL, 1);
            V v_t_24337 = (g_list_2emap_24s513201124x806973253(v_fs_24159));
            V v_x_24338 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24336, v_t_24337));
            return heff_tag_at_n(v_ru_24x1_24332_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24338}), v_st_24334});
          }
          default: return heff_nomatch(v_x11_24333);
          }
        }
        default: return heff_nomatch(v_x1_24332);
        }
      }
      case TAG_Op: {
        V v_m_24342 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24158}));
        V v_x1_24343 = heff_tr(heff_call(v_m_24342, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24343)) {
        case TAG_MkPair: {
          V v_x11_24344 = heff_field(v_x1_24343, 0);
          V v_st_24345 = heff_field(v_x1_24343, 1);
          V v_ru_24x1_24343_24MkPair = heff_take_reuse_n(v_x1_24343, 3ULL, 2);
          switch (heff_tag_of(v_x11_24344)) {
          case TAG_Left: {
            V v_e_24346 = heff_field(v_x11_24344, 0);
            heff_take_n(v_x11_24344, 1ULL, 1);
            heff_drop(v_fs_24159);
            return heff_tag_at_n(v_ru_24x1_24343_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24346}), v_st_24345});
          }
          case TAG_Right: {
            V v_x_24347 = heff_field(v_x11_24344, 0);
            heff_take_n(v_x11_24344, 1ULL, 1);
            V v_t_24348 = (g_list_2emap_24s513201124x806973253(v_fs_24159));
            V v_x_24349 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24347, v_t_24348));
            return heff_tag_at_n(v_ru_24x1_24343_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24349}), v_st_24345});
          }
          default: return heff_nomatch(v_x11_24344);
          }
        }
        default: return heff_nomatch(v_x1_24343);
        }
      }
      case TAG_Ops: {
        V v_m_24352 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24158}));
        V v_x1_24353 = heff_tr(heff_call(v_m_24352, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24353)) {
        case TAG_MkPair: {
          V v_x11_24354 = heff_field(v_x1_24353, 0);
          V v_st_24355 = heff_field(v_x1_24353, 1);
          V v_ru_24x1_24353_24MkPair = heff_take_reuse_n(v_x1_24353, 3ULL, 2);
          switch (heff_tag_of(v_x11_24354)) {
          case TAG_Left: {
            V v_e_24356 = heff_field(v_x11_24354, 0);
            heff_take_n(v_x11_24354, 1ULL, 1);
            heff_drop(v_fs_24159);
            return heff_tag_at_n(v_ru_24x1_24353_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24356}), v_st_24355});
          }
          case TAG_Right: {
            V v_x_24357 = heff_field(v_x11_24354, 0);
            heff_take_n(v_x11_24354, 1ULL, 1);
            V v_t_24358 = (g_list_2emap_24s513201124x806973253(v_fs_24159));
            V v_x_24359 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24357, v_t_24358));
            return heff_tag_at_n(v_ru_24x1_24353_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24359}), v_st_24355});
          }
          default: return heff_nomatch(v_x11_24354);
          }
        }
        default: return heff_nomatch(v_x1_24353);
        }
      }
      case TAG_OpRhs: {
        V v_m_24362 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24158}));
        V v_x1_24363 = heff_tr(heff_call(v_m_24362, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24363)) {
        case TAG_MkPair: {
          V v_x11_24364 = heff_field(v_x1_24363, 0);
          V v_st_24365 = heff_field(v_x1_24363, 1);
          V v_ru_24x1_24363_24MkPair = heff_take_reuse_n(v_x1_24363, 3ULL, 2);
          switch (heff_tag_of(v_x11_24364)) {
          case TAG_Left: {
            V v_e_24366 = heff_field(v_x11_24364, 0);
            heff_take_n(v_x11_24364, 1ULL, 1);
            heff_drop(v_fs_24159);
            return heff_tag_at_n(v_ru_24x1_24363_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24366}), v_st_24365});
          }
          case TAG_Right: {
            V v_x_24367 = heff_field(v_x11_24364, 0);
            heff_take_n(v_x11_24364, 1ULL, 1);
            V v_t_24368 = (g_list_2emap_24s513201124x806973253(v_fs_24159));
            V v_x_24369 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24367, v_t_24368));
            return heff_tag_at_n(v_ru_24x1_24363_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24369}), v_st_24365});
          }
          default: return heff_nomatch(v_x11_24364);
          }
        }
        default: return heff_nomatch(v_x1_24363);
        }
      }
      case TAG_Ann: {
        V v_m_24373 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24158}));
        V v_x1_24374 = heff_tr(heff_call(v_m_24373, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24374)) {
        case TAG_MkPair: {
          V v_x11_24375 = heff_field(v_x1_24374, 0);
          V v_st_24376 = heff_field(v_x1_24374, 1);
          V v_ru_24x1_24374_24MkPair = heff_take_reuse_n(v_x1_24374, 3ULL, 2);
          switch (heff_tag_of(v_x11_24375)) {
          case TAG_Left: {
            V v_e_24377 = heff_field(v_x11_24375, 0);
            heff_take_n(v_x11_24375, 1ULL, 1);
            heff_drop(v_fs_24159);
            return heff_tag_at_n(v_ru_24x1_24374_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24377}), v_st_24376});
          }
          case TAG_Right: {
            V v_x_24378 = heff_field(v_x11_24375, 0);
            heff_take_n(v_x11_24375, 1ULL, 1);
            V v_t_24379 = (g_list_2emap_24s513201124x806973253(v_fs_24159));
            V v_x_24380 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24378, v_t_24379));
            return heff_tag_at_n(v_ru_24x1_24374_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24380}), v_st_24376});
          }
          default: return heff_nomatch(v_x11_24375);
          }
        }
        default: return heff_nomatch(v_x1_24374);
        }
      }
      case TAG_BVar: {
        V v_m_24382 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24158}));
        V v_x1_24383 = heff_tr(heff_call(v_m_24382, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24383)) {
        case TAG_MkPair: {
          V v_x11_24384 = heff_field(v_x1_24383, 0);
          V v_st_24385 = heff_field(v_x1_24383, 1);
          V v_ru_24x1_24383_24MkPair = heff_take_reuse_n(v_x1_24383, 3ULL, 2);
          switch (heff_tag_of(v_x11_24384)) {
          case TAG_Left: {
            V v_e_24386 = heff_field(v_x11_24384, 0);
            heff_take_n(v_x11_24384, 1ULL, 1);
            heff_drop(v_fs_24159);
            return heff_tag_at_n(v_ru_24x1_24383_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24386}), v_st_24385});
          }
          case TAG_Right: {
            V v_x_24387 = heff_field(v_x11_24384, 0);
            heff_take_n(v_x11_24384, 1ULL, 1);
            V v_t_24388 = (g_list_2emap_24s513201124x806973253(v_fs_24159));
            V v_x_24389 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24387, v_t_24388));
            return heff_tag_at_n(v_ru_24x1_24383_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24389}), v_st_24385});
          }
          default: return heff_nomatch(v_x11_24384);
          }
        }
        default: return heff_nomatch(v_x1_24383);
        }
      }
      case TAG_BImp: {
        V v_m_24393 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24158}));
        V v_x1_24394 = heff_tr(heff_call(v_m_24393, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24394)) {
        case TAG_MkPair: {
          V v_x11_24395 = heff_field(v_x1_24394, 0);
          V v_st_24396 = heff_field(v_x1_24394, 1);
          V v_ru_24x1_24394_24MkPair = heff_take_reuse_n(v_x1_24394, 3ULL, 2);
          switch (heff_tag_of(v_x11_24395)) {
          case TAG_Left: {
            V v_e_24397 = heff_field(v_x11_24395, 0);
            heff_take_n(v_x11_24395, 1ULL, 1);
            heff_drop(v_fs_24159);
            return heff_tag_at_n(v_ru_24x1_24394_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24397}), v_st_24396});
          }
          case TAG_Right: {
            V v_x_24398 = heff_field(v_x11_24395, 0);
            heff_take_n(v_x11_24395, 1ULL, 1);
            V v_t_24399 = (g_list_2emap_24s513201124x806973253(v_fs_24159));
            V v_x_24400 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24398, v_t_24399));
            return heff_tag_at_n(v_ru_24x1_24394_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24400}), v_st_24396});
          }
          default: return heff_nomatch(v_x11_24395);
          }
        }
        default: return heff_nomatch(v_x1_24394);
        }
      }
      case TAG_BAnn: {
        V v_m_24406 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24158}));
        V v_x1_24407 = heff_tr(heff_call(v_m_24406, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24407)) {
        case TAG_MkPair: {
          V v_x11_24408 = heff_field(v_x1_24407, 0);
          V v_st_24409 = heff_field(v_x1_24407, 1);
          V v_ru_24x1_24407_24MkPair = heff_take_reuse_n(v_x1_24407, 3ULL, 2);
          switch (heff_tag_of(v_x11_24408)) {
          case TAG_Left: {
            V v_e_24410 = heff_field(v_x11_24408, 0);
            heff_take_n(v_x11_24408, 1ULL, 1);
            heff_drop(v_fs_24159);
            return heff_tag_at_n(v_ru_24x1_24407_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24410}), v_st_24409});
          }
          case TAG_Right: {
            V v_x_24411 = heff_field(v_x11_24408, 0);
            heff_take_n(v_x11_24408, 1ULL, 1);
            V v_t_24412 = (g_list_2emap_24s513201124x806973253(v_fs_24159));
            V v_x_24413 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24411, v_t_24412));
            return heff_tag_at_n(v_ru_24x1_24407_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24413}), v_st_24409});
          }
          default: return heff_nomatch(v_x11_24408);
          }
        }
        default: return heff_nomatch(v_x1_24407);
        }
      }
      case TAG_Lam: {
        V v_m_24418 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24158}));
        V v_x1_24419 = heff_tr(heff_call(v_m_24418, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24419)) {
        case TAG_MkPair: {
          V v_x11_24420 = heff_field(v_x1_24419, 0);
          V v_st_24421 = heff_field(v_x1_24419, 1);
          V v_ru_24x1_24419_24MkPair = heff_take_reuse_n(v_x1_24419, 3ULL, 2);
          switch (heff_tag_of(v_x11_24420)) {
          case TAG_Left: {
            V v_e_24422 = heff_field(v_x11_24420, 0);
            heff_take_n(v_x11_24420, 1ULL, 1);
            heff_drop(v_fs_24159);
            return heff_tag_at_n(v_ru_24x1_24419_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24422}), v_st_24421});
          }
          case TAG_Right: {
            V v_x_24423 = heff_field(v_x11_24420, 0);
            heff_take_n(v_x11_24420, 1ULL, 1);
            V v_t_24424 = (g_list_2emap_24s513201124x806973253(v_fs_24159));
            V v_x_24425 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24423, v_t_24424));
            return heff_tag_at_n(v_ru_24x1_24419_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24425}), v_st_24421});
          }
          default: return heff_nomatch(v_x11_24420);
          }
        }
        default: return heff_nomatch(v_x1_24419);
        }
      }
      case TAG_Case: {
        V v_m_24430 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24158}));
        V v_x1_24431 = heff_tr(heff_call(v_m_24430, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24431)) {
        case TAG_MkPair: {
          V v_x11_24432 = heff_field(v_x1_24431, 0);
          V v_st_24433 = heff_field(v_x1_24431, 1);
          V v_ru_24x1_24431_24MkPair = heff_take_reuse_n(v_x1_24431, 3ULL, 2);
          switch (heff_tag_of(v_x11_24432)) {
          case TAG_Left: {
            V v_e_24434 = heff_field(v_x11_24432, 0);
            heff_take_n(v_x11_24432, 1ULL, 1);
            heff_drop(v_fs_24159);
            return heff_tag_at_n(v_ru_24x1_24431_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24434}), v_st_24433});
          }
          case TAG_Right: {
            V v_x_24435 = heff_field(v_x11_24432, 0);
            heff_take_n(v_x11_24432, 1ULL, 1);
            V v_t_24436 = (g_list_2emap_24s513201124x806973253(v_fs_24159));
            V v_x_24437 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24435, v_t_24436));
            return heff_tag_at_n(v_ru_24x1_24431_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24437}), v_st_24433});
          }
          default: return heff_nomatch(v_x11_24432);
          }
        }
        default: return heff_nomatch(v_x1_24431);
        }
      }
      case TAG_EAlt: {
        V v_m_24441 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24158}));
        V v_x1_24442 = heff_tr(heff_call(v_m_24441, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24442)) {
        case TAG_MkPair: {
          V v_x11_24443 = heff_field(v_x1_24442, 0);
          V v_st_24444 = heff_field(v_x1_24442, 1);
          V v_ru_24x1_24442_24MkPair = heff_take_reuse_n(v_x1_24442, 3ULL, 2);
          switch (heff_tag_of(v_x11_24443)) {
          case TAG_Left: {
            V v_e_24445 = heff_field(v_x11_24443, 0);
            heff_take_n(v_x11_24443, 1ULL, 1);
            heff_drop(v_fs_24159);
            return heff_tag_at_n(v_ru_24x1_24442_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24445}), v_st_24444});
          }
          case TAG_Right: {
            V v_x_24446 = heff_field(v_x11_24443, 0);
            heff_take_n(v_x11_24443, 1ULL, 1);
            V v_t_24447 = (g_list_2emap_24s513201124x806973253(v_fs_24159));
            V v_x_24448 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24446, v_t_24447));
            return heff_tag_at_n(v_ru_24x1_24442_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24448}), v_st_24444});
          }
          default: return heff_nomatch(v_x11_24443);
          }
        }
        default: return heff_nomatch(v_x1_24442);
        }
      }
      case TAG_If: {
        V v_m_24455 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24158}));
        V v_x1_24456 = heff_tr(heff_call(v_m_24455, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24456)) {
        case TAG_MkPair: {
          V v_x11_24457 = heff_field(v_x1_24456, 0);
          V v_st_24458 = heff_field(v_x1_24456, 1);
          V v_ru_24x1_24456_24MkPair = heff_take_reuse_n(v_x1_24456, 3ULL, 2);
          switch (heff_tag_of(v_x11_24457)) {
          case TAG_Left: {
            V v_e_24459 = heff_field(v_x11_24457, 0);
            heff_take_n(v_x11_24457, 1ULL, 1);
            heff_drop(v_fs_24159);
            return heff_tag_at_n(v_ru_24x1_24456_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24459}), v_st_24458});
          }
          case TAG_Right: {
            V v_x_24460 = heff_field(v_x11_24457, 0);
            heff_take_n(v_x11_24457, 1ULL, 1);
            V v_t_24461 = (g_list_2emap_24s513201124x806973253(v_fs_24159));
            V v_x_24462 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24460, v_t_24461));
            return heff_tag_at_n(v_ru_24x1_24456_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24462}), v_st_24458});
          }
          default: return heff_nomatch(v_x11_24457);
          }
        }
        default: return heff_nomatch(v_x1_24456);
        }
      }
      case TAG_Do: {
        V v_m_24465 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24158}));
        V v_x1_24466 = heff_tr(heff_call(v_m_24465, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24466)) {
        case TAG_MkPair: {
          V v_x11_24467 = heff_field(v_x1_24466, 0);
          V v_st_24468 = heff_field(v_x1_24466, 1);
          V v_ru_24x1_24466_24MkPair = heff_take_reuse_n(v_x1_24466, 3ULL, 2);
          switch (heff_tag_of(v_x11_24467)) {
          case TAG_Left: {
            V v_e_24469 = heff_field(v_x11_24467, 0);
            heff_take_n(v_x11_24467, 1ULL, 1);
            heff_drop(v_fs_24159);
            return heff_tag_at_n(v_ru_24x1_24466_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24469}), v_st_24468});
          }
          case TAG_Right: {
            V v_x_24470 = heff_field(v_x11_24467, 0);
            heff_take_n(v_x11_24467, 1ULL, 1);
            V v_t_24471 = (g_list_2emap_24s513201124x806973253(v_fs_24159));
            V v_x_24472 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24470, v_t_24471));
            return heff_tag_at_n(v_ru_24x1_24466_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24472}), v_st_24468});
          }
          default: return heff_nomatch(v_x11_24467);
          }
        }
        default: return heff_nomatch(v_x1_24466);
        }
      }
      case TAG_ESBind: {
        V v_m_24476 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24158}));
        V v_x1_24477 = heff_tr(heff_call(v_m_24476, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24477)) {
        case TAG_MkPair: {
          V v_x11_24478 = heff_field(v_x1_24477, 0);
          V v_st_24479 = heff_field(v_x1_24477, 1);
          V v_ru_24x1_24477_24MkPair = heff_take_reuse_n(v_x1_24477, 3ULL, 2);
          switch (heff_tag_of(v_x11_24478)) {
          case TAG_Left: {
            V v_e_24480 = heff_field(v_x11_24478, 0);
            heff_take_n(v_x11_24478, 1ULL, 1);
            heff_drop(v_fs_24159);
            return heff_tag_at_n(v_ru_24x1_24477_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24480}), v_st_24479});
          }
          case TAG_Right: {
            V v_x_24481 = heff_field(v_x11_24478, 0);
            heff_take_n(v_x11_24478, 1ULL, 1);
            V v_t_24482 = (g_list_2emap_24s513201124x806973253(v_fs_24159));
            V v_x_24483 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24481, v_t_24482));
            return heff_tag_at_n(v_ru_24x1_24477_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24483}), v_st_24479});
          }
          default: return heff_nomatch(v_x11_24478);
          }
        }
        default: return heff_nomatch(v_x1_24477);
        }
      }
      case TAG_ELet: {
        V v_m_24490 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24158}));
        V v_x1_24491 = heff_tr(heff_call(v_m_24490, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24491)) {
        case TAG_MkPair: {
          V v_x11_24492 = heff_field(v_x1_24491, 0);
          V v_st_24493 = heff_field(v_x1_24491, 1);
          V v_ru_24x1_24491_24MkPair = heff_take_reuse_n(v_x1_24491, 3ULL, 2);
          switch (heff_tag_of(v_x11_24492)) {
          case TAG_Left: {
            V v_e_24494 = heff_field(v_x11_24492, 0);
            heff_take_n(v_x11_24492, 1ULL, 1);
            heff_drop(v_fs_24159);
            return heff_tag_at_n(v_ru_24x1_24491_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24494}), v_st_24493});
          }
          case TAG_Right: {
            V v_x_24495 = heff_field(v_x11_24492, 0);
            heff_take_n(v_x11_24492, 1ULL, 1);
            V v_t_24496 = (g_list_2emap_24s513201124x806973253(v_fs_24159));
            V v_x_24497 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24495, v_t_24496));
            return heff_tag_at_n(v_ru_24x1_24491_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24497}), v_st_24493});
          }
          default: return heff_nomatch(v_x11_24492);
          }
        }
        default: return heff_nomatch(v_x1_24491);
        }
      }
      case TAG_ELetMut: {
        V v_m_24504 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24158}));
        V v_x1_24505 = heff_tr(heff_call(v_m_24504, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24505)) {
        case TAG_MkPair: {
          V v_x11_24506 = heff_field(v_x1_24505, 0);
          V v_st_24507 = heff_field(v_x1_24505, 1);
          V v_ru_24x1_24505_24MkPair = heff_take_reuse_n(v_x1_24505, 3ULL, 2);
          switch (heff_tag_of(v_x11_24506)) {
          case TAG_Left: {
            V v_e_24508 = heff_field(v_x11_24506, 0);
            heff_take_n(v_x11_24506, 1ULL, 1);
            heff_drop(v_fs_24159);
            return heff_tag_at_n(v_ru_24x1_24505_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24508}), v_st_24507});
          }
          case TAG_Right: {
            V v_x_24509 = heff_field(v_x11_24506, 0);
            heff_take_n(v_x11_24506, 1ULL, 1);
            V v_t_24510 = (g_list_2emap_24s513201124x806973253(v_fs_24159));
            V v_x_24511 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24509, v_t_24510));
            return heff_tag_at_n(v_ru_24x1_24505_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24511}), v_st_24507});
          }
          default: return heff_nomatch(v_x11_24506);
          }
        }
        default: return heff_nomatch(v_x1_24505);
        }
      }
      case TAG_EAssign: {
        V v_m_24515 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24158}));
        V v_x1_24516 = heff_tr(heff_call(v_m_24515, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24516)) {
        case TAG_MkPair: {
          V v_x11_24517 = heff_field(v_x1_24516, 0);
          V v_st_24518 = heff_field(v_x1_24516, 1);
          V v_ru_24x1_24516_24MkPair = heff_take_reuse_n(v_x1_24516, 3ULL, 2);
          switch (heff_tag_of(v_x11_24517)) {
          case TAG_Left: {
            V v_e_24519 = heff_field(v_x11_24517, 0);
            heff_take_n(v_x11_24517, 1ULL, 1);
            heff_drop(v_fs_24159);
            return heff_tag_at_n(v_ru_24x1_24516_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24519}), v_st_24518});
          }
          case TAG_Right: {
            V v_x_24520 = heff_field(v_x11_24517, 0);
            heff_take_n(v_x11_24517, 1ULL, 1);
            V v_t_24521 = (g_list_2emap_24s513201124x806973253(v_fs_24159));
            V v_x_24522 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24520, v_t_24521));
            return heff_tag_at_n(v_ru_24x1_24516_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24522}), v_st_24518});
          }
          default: return heff_nomatch(v_x11_24517);
          }
        }
        default: return heff_nomatch(v_x1_24516);
        }
      }
      case TAG_EWhile: {
        V v_m_24527 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24158}));
        V v_x1_24528 = heff_tr(heff_call(v_m_24527, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24528)) {
        case TAG_MkPair: {
          V v_x11_24529 = heff_field(v_x1_24528, 0);
          V v_st_24530 = heff_field(v_x1_24528, 1);
          V v_ru_24x1_24528_24MkPair = heff_take_reuse_n(v_x1_24528, 3ULL, 2);
          switch (heff_tag_of(v_x11_24529)) {
          case TAG_Left: {
            V v_e_24531 = heff_field(v_x11_24529, 0);
            heff_take_n(v_x11_24529, 1ULL, 1);
            heff_drop(v_fs_24159);
            return heff_tag_at_n(v_ru_24x1_24528_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24531}), v_st_24530});
          }
          case TAG_Right: {
            V v_x_24532 = heff_field(v_x11_24529, 0);
            heff_take_n(v_x11_24529, 1ULL, 1);
            V v_t_24533 = (g_list_2emap_24s513201124x806973253(v_fs_24159));
            V v_x_24534 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24532, v_t_24533));
            return heff_tag_at_n(v_ru_24x1_24528_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24534}), v_st_24530});
          }
          default: return heff_nomatch(v_x11_24529);
          }
        }
        default: return heff_nomatch(v_x1_24528);
        }
      }
      case TAG_EFor: {
        V v_m_24541 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24158}));
        V v_x1_24542 = heff_tr(heff_call(v_m_24541, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24542)) {
        case TAG_MkPair: {
          V v_x11_24543 = heff_field(v_x1_24542, 0);
          V v_st_24544 = heff_field(v_x1_24542, 1);
          V v_ru_24x1_24542_24MkPair = heff_take_reuse_n(v_x1_24542, 3ULL, 2);
          switch (heff_tag_of(v_x11_24543)) {
          case TAG_Left: {
            V v_e_24545 = heff_field(v_x11_24543, 0);
            heff_take_n(v_x11_24543, 1ULL, 1);
            heff_drop(v_fs_24159);
            return heff_tag_at_n(v_ru_24x1_24542_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24545}), v_st_24544});
          }
          case TAG_Right: {
            V v_x_24546 = heff_field(v_x11_24543, 0);
            heff_take_n(v_x11_24543, 1ULL, 1);
            V v_t_24547 = (g_list_2emap_24s513201124x806973253(v_fs_24159));
            V v_x_24548 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24546, v_t_24547));
            return heff_tag_at_n(v_ru_24x1_24542_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24548}), v_st_24544});
          }
          default: return heff_nomatch(v_x11_24543);
          }
        }
        default: return heff_nomatch(v_x1_24542);
        }
      }
      case TAG_EJump: {
        V v_m_24550 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24158}));
        V v_x1_24551 = heff_tr(heff_call(v_m_24550, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24551)) {
        case TAG_MkPair: {
          V v_x11_24552 = heff_field(v_x1_24551, 0);
          V v_st_24553 = heff_field(v_x1_24551, 1);
          V v_ru_24x1_24551_24MkPair = heff_take_reuse_n(v_x1_24551, 3ULL, 2);
          switch (heff_tag_of(v_x11_24552)) {
          case TAG_Left: {
            V v_e_24554 = heff_field(v_x11_24552, 0);
            heff_take_n(v_x11_24552, 1ULL, 1);
            heff_drop(v_fs_24159);
            return heff_tag_at_n(v_ru_24x1_24551_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24554}), v_st_24553});
          }
          case TAG_Right: {
            V v_x_24555 = heff_field(v_x11_24552, 0);
            heff_take_n(v_x11_24552, 1ULL, 1);
            V v_t_24556 = (g_list_2emap_24s513201124x806973253(v_fs_24159));
            V v_x_24557 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24555, v_t_24556));
            return heff_tag_at_n(v_ru_24x1_24551_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24557}), v_st_24553});
          }
          default: return heff_nomatch(v_x11_24552);
          }
        }
        default: return heff_nomatch(v_x1_24551);
        }
      }
      case TAG_EReturn: {
        V v_m_24560 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24158}));
        V v_x1_24561 = heff_tr(heff_call(v_m_24560, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24561)) {
        case TAG_MkPair: {
          V v_x11_24562 = heff_field(v_x1_24561, 0);
          V v_st_24563 = heff_field(v_x1_24561, 1);
          V v_ru_24x1_24561_24MkPair = heff_take_reuse_n(v_x1_24561, 3ULL, 2);
          switch (heff_tag_of(v_x11_24562)) {
          case TAG_Left: {
            V v_e_24564 = heff_field(v_x11_24562, 0);
            heff_take_n(v_x11_24562, 1ULL, 1);
            heff_drop(v_fs_24159);
            return heff_tag_at_n(v_ru_24x1_24561_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24564}), v_st_24563});
          }
          case TAG_Right: {
            V v_x_24565 = heff_field(v_x11_24562, 0);
            heff_take_n(v_x11_24562, 1ULL, 1);
            V v_t_24566 = (g_list_2emap_24s513201124x806973253(v_fs_24159));
            V v_x_24567 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24565, v_t_24566));
            return heff_tag_at_n(v_ru_24x1_24561_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24567}), v_st_24563});
          }
          default: return heff_nomatch(v_x11_24562);
          }
        }
        default: return heff_nomatch(v_x1_24561);
        }
      }
      case TAG_ENest: {
        V v_m_24572 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24158}));
        V v_x1_24573 = heff_tr(heff_call(v_m_24572, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24573)) {
        case TAG_MkPair: {
          V v_x11_24574 = heff_field(v_x1_24573, 0);
          V v_st_24575 = heff_field(v_x1_24573, 1);
          V v_ru_24x1_24573_24MkPair = heff_take_reuse_n(v_x1_24573, 3ULL, 2);
          switch (heff_tag_of(v_x11_24574)) {
          case TAG_Left: {
            V v_e_24576 = heff_field(v_x11_24574, 0);
            heff_take_n(v_x11_24574, 1ULL, 1);
            heff_drop(v_fs_24159);
            return heff_tag_at_n(v_ru_24x1_24573_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24576}), v_st_24575});
          }
          case TAG_Right: {
            V v_x_24577 = heff_field(v_x11_24574, 0);
            heff_take_n(v_x11_24574, 1ULL, 1);
            V v_t_24578 = (g_list_2emap_24s513201124x806973253(v_fs_24159));
            V v_x_24579 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24577, v_t_24578));
            return heff_tag_at_n(v_ru_24x1_24573_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24579}), v_st_24575});
          }
          default: return heff_nomatch(v_x11_24574);
          }
        }
        default: return heff_nomatch(v_x1_24573);
        }
      }
      case TAG_IfThen: {
        V v_m_24584 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24158}));
        V v_x1_24585 = heff_tr(heff_call(v_m_24584, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24585)) {
        case TAG_MkPair: {
          V v_x11_24586 = heff_field(v_x1_24585, 0);
          V v_st_24587 = heff_field(v_x1_24585, 1);
          V v_ru_24x1_24585_24MkPair = heff_take_reuse_n(v_x1_24585, 3ULL, 2);
          switch (heff_tag_of(v_x11_24586)) {
          case TAG_Left: {
            V v_e_24588 = heff_field(v_x11_24586, 0);
            heff_take_n(v_x11_24586, 1ULL, 1);
            heff_drop(v_fs_24159);
            return heff_tag_at_n(v_ru_24x1_24585_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24588}), v_st_24587});
          }
          case TAG_Right: {
            V v_x_24589 = heff_field(v_x11_24586, 0);
            heff_take_n(v_x11_24586, 1ULL, 1);
            V v_t_24590 = (g_list_2emap_24s513201124x806973253(v_fs_24159));
            V v_x_24591 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24589, v_t_24590));
            return heff_tag_at_n(v_ru_24x1_24585_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24591}), v_st_24587});
          }
          default: return heff_nomatch(v_x11_24586);
          }
        }
        default: return heff_nomatch(v_x1_24585);
        }
      }
      case TAG_ELetCond: {
        V v_m_24596 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24158}));
        V v_x1_24597 = heff_tr(heff_call(v_m_24596, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24597)) {
        case TAG_MkPair: {
          V v_x11_24598 = heff_field(v_x1_24597, 0);
          V v_st_24599 = heff_field(v_x1_24597, 1);
          V v_ru_24x1_24597_24MkPair = heff_take_reuse_n(v_x1_24597, 3ULL, 2);
          switch (heff_tag_of(v_x11_24598)) {
          case TAG_Left: {
            V v_e_24600 = heff_field(v_x11_24598, 0);
            heff_take_n(v_x11_24598, 1ULL, 1);
            heff_drop(v_fs_24159);
            return heff_tag_at_n(v_ru_24x1_24597_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24600}), v_st_24599});
          }
          case TAG_Right: {
            V v_x_24601 = heff_field(v_x11_24598, 0);
            heff_take_n(v_x11_24598, 1ULL, 1);
            V v_t_24602 = (g_list_2emap_24s513201124x806973253(v_fs_24159));
            V v_x_24603 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24601, v_t_24602));
            return heff_tag_at_n(v_ru_24x1_24597_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24603}), v_st_24599});
          }
          default: return heff_nomatch(v_x11_24598);
          }
        }
        default: return heff_nomatch(v_x1_24597);
        }
      }
      case TAG_ETry: {
        V v_m_24608 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24158}));
        V v_x1_24609 = heff_tr(heff_call(v_m_24608, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24609)) {
        case TAG_MkPair: {
          V v_x11_24610 = heff_field(v_x1_24609, 0);
          V v_st_24611 = heff_field(v_x1_24609, 1);
          V v_ru_24x1_24609_24MkPair = heff_take_reuse_n(v_x1_24609, 3ULL, 2);
          switch (heff_tag_of(v_x11_24610)) {
          case TAG_Left: {
            V v_e_24612 = heff_field(v_x11_24610, 0);
            heff_take_n(v_x11_24610, 1ULL, 1);
            heff_drop(v_fs_24159);
            return heff_tag_at_n(v_ru_24x1_24609_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24612}), v_st_24611});
          }
          case TAG_Right: {
            V v_x_24613 = heff_field(v_x11_24610, 0);
            heff_take_n(v_x11_24610, 1ULL, 1);
            V v_t_24614 = (g_list_2emap_24s513201124x806973253(v_fs_24159));
            V v_x_24615 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24613, v_t_24614));
            return heff_tag_at_n(v_ru_24x1_24609_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24615}), v_st_24611});
          }
          default: return heff_nomatch(v_x11_24610);
          }
        }
        default: return heff_nomatch(v_x1_24609);
        }
      }
      case TAG_ECatch: {
        V v_m_24620 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24158}));
        V v_x1_24621 = heff_tr(heff_call(v_m_24620, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24621)) {
        case TAG_MkPair: {
          V v_x11_24622 = heff_field(v_x1_24621, 0);
          V v_st_24623 = heff_field(v_x1_24621, 1);
          V v_ru_24x1_24621_24MkPair = heff_take_reuse_n(v_x1_24621, 3ULL, 2);
          switch (heff_tag_of(v_x11_24622)) {
          case TAG_Left: {
            V v_e_24624 = heff_field(v_x11_24622, 0);
            heff_take_n(v_x11_24622, 1ULL, 1);
            heff_drop(v_fs_24159);
            return heff_tag_at_n(v_ru_24x1_24621_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24624}), v_st_24623});
          }
          case TAG_Right: {
            V v_x_24625 = heff_field(v_x11_24622, 0);
            heff_take_n(v_x11_24622, 1ULL, 1);
            V v_t_24626 = (g_list_2emap_24s513201124x806973253(v_fs_24159));
            V v_x_24627 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24625, v_t_24626));
            return heff_tag_at_n(v_ru_24x1_24621_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24627}), v_st_24623});
          }
          default: return heff_nomatch(v_x11_24622);
          }
        }
        default: return heff_nomatch(v_x1_24621);
        }
      }
      case TAG_EWith: {
        V v_m_24634 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24158}));
        V v_x1_24635 = heff_tr(heff_call(v_m_24634, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24635)) {
        case TAG_MkPair: {
          V v_x11_24636 = heff_field(v_x1_24635, 0);
          V v_st_24637 = heff_field(v_x1_24635, 1);
          V v_ru_24x1_24635_24MkPair = heff_take_reuse_n(v_x1_24635, 3ULL, 2);
          switch (heff_tag_of(v_x11_24636)) {
          case TAG_Left: {
            V v_e_24638 = heff_field(v_x11_24636, 0);
            heff_take_n(v_x11_24636, 1ULL, 1);
            heff_drop(v_fs_24159);
            return heff_tag_at_n(v_ru_24x1_24635_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24638}), v_st_24637});
          }
          case TAG_Right: {
            V v_x_24639 = heff_field(v_x11_24636, 0);
            heff_take_n(v_x11_24636, 1ULL, 1);
            V v_t_24640 = (g_list_2emap_24s513201124x806973253(v_fs_24159));
            V v_x_24641 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24639, v_t_24640));
            return heff_tag_at_n(v_ru_24x1_24635_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24641}), v_st_24637});
          }
          default: return heff_nomatch(v_x11_24636);
          }
        }
        default: return heff_nomatch(v_x1_24635);
        }
      }
      default: return heff_nomatch(v_it1_24158);
      }
    }
  }
  case TAG_ENeg: {
    V v_m_24642 = heff_field(v_e0_241, 0);
    V v_e_24643 = heff_field(v_e0_241, 1);
    V v_ru_24e0_241_24ENeg = heff_take_reuse_n(v_e0_241, 3ULL, 2);
    V v_m_24644 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_24643}));
    V v_x1_24645 = heff_tr(heff_call(v_m_24644, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x1_24645)) {
    case TAG_MkPair: {
      V v_x11_24646 = heff_field(v_x1_24645, 0);
      V v_st_24647 = heff_field(v_x1_24645, 1);
      V v_ru_24x1_24645_24MkPair = heff_take_reuse_n(v_x1_24645, 3ULL, 2);
      switch (heff_tag_of(v_x11_24646)) {
      case TAG_Left: {
        V v_e_24648 = heff_field(v_x11_24646, 0);
        heff_take_n(v_x11_24646, 1ULL, 1);
        heff_drop_rec(v_m_24642, 9);
        heff_drop_cell(v_ru_24x1_24645_24MkPair, 2);
        return heff_tag_at_n(v_ru_24e0_241_24ENeg, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24648}), v_st_24647});
      }
      case TAG_Right: {
        V v_x_24649 = heff_field(v_x11_24646, 0);
        heff_take_n(v_x11_24646, 1ULL, 1);
        V v_t_24650 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_m_24642, 3), heff_get_n(v_m_24642, 4, 9)});
        V v_t_24651 = heff_tag_at_n(v_ru_24e0_241_24ENeg, TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2eexprL_str22)}), v_t_24650});
        V v_t_24652 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_24649, NTAG(TAG_Nil)});
        V v_x_24653 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_24651, v_t_24652));
        return heff_tag_at_n(v_ru_24x1_24645_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24653}), v_st_24647});
      }
      default: return heff_nomatch(v_x11_24646);
      }
    }
    default: return heff_nomatch(v_x1_24645);
    }
  }
  case TAG_App: {
    V v_h_24654 = heff_field(v_e0_241, 0);
    V v_args_24655 = heff_field(v_e0_241, 1);
    V v_ru_24e0_241_24App = heff_take_reuse_n(v_e0_241, 3ULL, 2);
    V v_m_24656 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_h_24654}));
    V v_x1_24657 = heff_tr(heff_call(v_m_24656, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x1_24657)) {
    case TAG_MkPair: {
      V v_x11_24658 = heff_field(v_x1_24657, 0);
      V v_st_24659 = heff_field(v_x1_24657, 1);
      heff_take_n(v_x1_24657, 3ULL, 2);
      switch (heff_tag_of(v_x11_24658)) {
      case TAG_Left: {
        V v_e_24660 = heff_field(v_x11_24658, 0);
        heff_take_n(v_x11_24658, 1ULL, 1);
        heff_drop_rec(v_r_240, 3);
        heff_drop(v_args_24655);
        return heff_tag_at_n(v_ru_24e0_241_24App, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24660}), v_st_24659});
      }
      case TAG_Right: {
        V v_x_24661 = heff_field(v_x11_24658, 0);
        heff_take_n(v_x11_24658, 1ULL, 1);
        V v_m_24663 = (g_prelude_2etraverse_24s499544530x2060473942(heff_clo_n(g_heff_2esyntax_2esurface_2eexprL_lam4, 1, 1, (V[]){v_r_240}), v_args_24655));
        V v_x1_24664 = heff_tr(heff_call(v_m_24663, 1, (V[]){v_st_24659}));
        switch (heff_tag_of(v_x1_24664)) {
        case TAG_MkPair: {
          V v_x11_24665 = heff_field(v_x1_24664, 0);
          V v_st_24666 = heff_field(v_x1_24664, 1);
          heff_take_n(v_x1_24664, 3ULL, 2);
          switch (heff_tag_of(v_x11_24665)) {
          case TAG_Left: {
            V v_e_24667 = heff_field(v_x11_24665, 0);
            heff_take_n(v_x11_24665, 1ULL, 1);
            heff_drop(v_x_24661);
            return heff_tag_at_n(v_ru_24e0_241_24App, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24667}), v_st_24666});
          }
          case TAG_Right: {
            V v_x_24668 = heff_field(v_x11_24665, 0);
            heff_take_n(v_x11_24665, 1ULL, 1);
            V v_x_24669 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24661, v_x_24668));
            return heff_tag_at_n(v_ru_24e0_241_24App, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24669}), v_st_24666});
          }
          default: return heff_nomatch(v_x11_24665);
          }
        }
        default: return heff_nomatch(v_x1_24664);
        }
      }
      default: return heff_nomatch(v_x11_24658);
      }
    }
    default: return heff_nomatch(v_x1_24657);
    }
  }
  case TAG_Op: {
    V v_a_24670 = heff_field(v_e0_241, 0);
    V v_op_24671 = heff_field(v_e0_241, 1);
    V v_b_24672 = heff_field(v_e0_241, 2);
    heff_take_n(v_e0_241, 7ULL, 3);
    return (g_heff_2esyntax_2esurface_2eopL(v_r_240, v_a_24670, v_op_24671, v_b_24672, v_z_242));
  }
  case TAG_Ops: {
    V v_a_24673 = heff_field(v_e0_241, 0);
    V v_rest_24674 = heff_field(v_e0_241, 1);
    V v_ru_24e0_241_24Ops = heff_take_reuse_n(v_e0_241, 3ULL, 2);
    V v_m_24675 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_24673}));
    V v_x1_24676 = heff_tr(heff_call(v_m_24675, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x1_24676)) {
    case TAG_MkPair: {
      V v_x11_24677 = heff_field(v_x1_24676, 0);
      V v_st_24678 = heff_field(v_x1_24676, 1);
      heff_take_n(v_x1_24676, 3ULL, 2);
      switch (heff_tag_of(v_x11_24677)) {
      case TAG_Left: {
        V v_e_24679 = heff_field(v_x11_24677, 0);
        heff_take_n(v_x11_24677, 1ULL, 1);
        heff_drop_rec(v_r_240, 3);
        heff_drop(v_rest_24674);
        return heff_tag_at_n(v_ru_24e0_241_24Ops, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24679}), v_st_24678});
      }
      case TAG_Right: {
        V v_x_24680 = heff_field(v_x11_24677, 0);
        heff_take_n(v_x11_24677, 1ULL, 1);
        V v_m_24695 = (g_prelude_2etraverse_24s499544530x2060473942(heff_clo_n(g_heff_2esyntax_2esurface_2eexprL_lam5, 1, 1, (V[]){v_r_240}), v_rest_24674));
        V v_x1_24696 = heff_tr(heff_call(v_m_24695, 1, (V[]){v_st_24678}));
        switch (heff_tag_of(v_x1_24696)) {
        case TAG_MkPair: {
          V v_x11_24697 = heff_field(v_x1_24696, 0);
          V v_st_24698 = heff_field(v_x1_24696, 1);
          heff_take_n(v_x1_24696, 3ULL, 2);
          switch (heff_tag_of(v_x11_24697)) {
          case TAG_Left: {
            V v_e_24699 = heff_field(v_x11_24697, 0);
            heff_take_n(v_x11_24697, 1ULL, 1);
            heff_drop(v_x_24680);
            return heff_tag_at_n(v_ru_24e0_241_24Ops, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24699}), v_st_24698});
          }
          case TAG_Right: {
            V v_x_24700 = heff_field(v_x11_24697, 0);
            heff_take_n(v_x11_24697, 1ULL, 1);
            heff_drop_cell(v_ru_24e0_241_24Ops, 2);
            HEFF_LAST return g_heff_2esyntax_2esurface_2eresolve_24s1832151779x1448561609(v_x_24680, v_x_24700, v_st_24698);
          }
          default: return heff_nomatch(v_x11_24697);
          }
        }
        default: return heff_nomatch(v_x1_24696);
        }
      }
      default: return heff_nomatch(v_x11_24677);
      }
    }
    default: return heff_nomatch(v_x1_24676);
    }
  }
  case TAG_OpRhs: {
    heff_drop_rec(v_r_240, 3);
    V v_t_24703 = (g_heff_2esyntax_2ecst_2efirstE(v_e0_241));
    V v_t_24704 = ({ V a_0 = v_e0_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e0_241, 2); r_; });
    V v_t_24705 = heff_strAppend(heff_get_n(v_t_24704, 1, 9), ((V)&g_heff_2esyntax_2esurface_2eexprL_str23));
    V v_msg_24706 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eexprL_str24), v_t_24705);
    V v_t_24707 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24703, 3), heff_get_n(v_t_24703, 4, 9)});
    V v_t_24708 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24706, v_t_24707, NTAG(TAG_Nothing)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24708}), v_z_242});
  }
  case TAG_Ann: {
    V v_e_24709 = heff_field(v_e0_241, 0);
    V v_ty_24711 = heff_field(v_e0_241, 2);
    heff_take_n(v_e0_241, 5ULL, 3);
    V v_m_24712 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e_24709}));
    V v_x1_24713 = heff_tr(heff_call(v_m_24712, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x1_24713)) {
    case TAG_MkPair: {
      V v_x11_24714 = heff_field(v_x1_24713, 0);
      V v_st_24715 = heff_field(v_x1_24713, 1);
      V v_ru_24x1_24713_24MkPair = heff_take_reuse_n(v_x1_24713, 3ULL, 2);
      switch (heff_tag_of(v_x11_24714)) {
      case TAG_Left: {
        V v_e_24716 = heff_field(v_x11_24714, 0);
        heff_take_n(v_x11_24714, 1ULL, 1);
        heff_drop_rec(v_r_240, 3);
        heff_drop(v_ty_24711);
        return heff_tag_at_n(v_ru_24x1_24713_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24716}), v_st_24715});
      }
      case TAG_Right: {
        V v_x_24717 = heff_field(v_x11_24714, 0);
        heff_take_n(v_x11_24714, 1ULL, 1);
        V v_m_24718 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_ty_24711}));
        V v_x1_24719 = heff_tr(heff_call(v_m_24718, 1, (V[]){v_st_24715}));
        switch (heff_tag_of(v_x1_24719)) {
        case TAG_MkPair: {
          V v_x11_24720 = heff_field(v_x1_24719, 0);
          V v_st_24721 = heff_field(v_x1_24719, 1);
          V v_ru_24x1_24719_24MkPair = heff_take_reuse_n(v_x1_24719, 3ULL, 2);
          switch (heff_tag_of(v_x11_24720)) {
          case TAG_Left: {
            V v_e_24722 = heff_field(v_x11_24720, 0);
            heff_take_n(v_x11_24720, 1ULL, 1);
            heff_drop(v_x_24717);
            heff_drop_cell(v_ru_24x1_24719_24MkPair, 2);
            return heff_tag_at_n(v_ru_24x1_24713_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24722}), v_st_24721});
          }
          case TAG_Right: {
            V v_x_24723 = heff_field(v_x11_24720, 0);
            heff_take_n(v_x11_24720, 1ULL, 1);
            V v_t_24726;
            switch (heff_tag_of(v_x_24717)) {
            case TAG_At: {
              V v_s_24725 = heff_dup(heff_field(v_x_24717, 1));
              v_t_24726 = v_s_24725;
              break;
            }
            default: heff_nomatch(v_x_24717);
            }
            V v_t_24729;
            switch (heff_tag_of(v_x_24723)) {
            case TAG_At: {
              V v_s_24728 = heff_dup(heff_field(v_x_24723, 1));
              v_t_24729 = v_s_24728;
              break;
            }
            default: heff_nomatch(v_x_24723);
            }
            V v_t_24730 = ({ V rv_1 = heff_get_n(v_t_24729, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24726, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
            V v_t_24731 = heff_tag_at_n(v_ru_24x1_24719_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_EAnn, 2, (V[]){v_x_24717, v_x_24723}), v_t_24730});
            return heff_tag_at_n(v_ru_24x1_24713_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24731}), v_st_24721});
          }
          default: return heff_nomatch(v_x11_24720);
          }
        }
        default: return heff_nomatch(v_x1_24719);
        }
      }
      default: return heff_nomatch(v_x11_24714);
      }
    }
    default: return heff_nomatch(v_x1_24713);
    }
  }
  case TAG_BVar: {
    heff_drop_rec(v_r_240, 3);
    V v_t_24733 = (g_heff_2esyntax_2ecst_2efirstE(v_e0_241));
    V v_t_24734 = ({ V a_0 = v_e0_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e0_241, 1); r_; });
    V v_t_24735 = heff_strAppend(heff_get_n(v_t_24734, 1, 9), ((V)&g_heff_2esyntax_2esurface_2eexprL_str25));
    V v_msg_24736 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eexprL_str26), v_t_24735);
    V v_t_24737 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24733, 3), heff_get_n(v_t_24733, 4, 9)});
    V v_t_24738 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24736, v_t_24737, NTAG(TAG_Nothing)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24738}), v_z_242});
  }
  case TAG_BImp: {
    heff_drop_rec(v_r_240, 3);
    V v_t_24742 = (g_heff_2esyntax_2ecst_2efirstE(v_e0_241));
    V v_t_24743 = ({ V a_0 = v_e0_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e0_241, 3); r_; });
    V v_t_24744 = heff_strAppend(heff_get_n(v_t_24743, 1, 9), ((V)&g_heff_2esyntax_2esurface_2eexprL_str27));
    V v_msg_24745 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eexprL_str28), v_t_24744);
    V v_t_24746 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24742, 3), heff_get_n(v_t_24742, 4, 9)});
    V v_t_24747 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24745, v_t_24746, NTAG(TAG_Nothing)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24747}), v_z_242});
  }
  case TAG_BAnn: {
    heff_drop_rec(v_r_240, 3);
    V v_t_24753 = (g_heff_2esyntax_2ecst_2efirstE(v_e0_241));
    V v_t_24754 = ({ V a_0 = v_e0_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e0_241, 5); r_; });
    V v_t_24755 = heff_strAppend(heff_get_n(v_t_24754, 1, 9), ((V)&g_heff_2esyntax_2esurface_2eexprL_str29));
    V v_msg_24756 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eexprL_str30), v_t_24755);
    V v_t_24757 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24753, 3), heff_get_n(v_t_24753, 4, 9)});
    V v_t_24758 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24756, v_t_24757, NTAG(TAG_Nothing)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24758}), v_z_242});
  }
  case TAG_Lam: {
    V v_binders_24760 = heff_field(v_e0_241, 1);
    V v_body_24762 = heff_field(v_e0_241, 3);
    heff_take_n(v_e0_241, 10ULL, 4);
    return (g_heff_2esyntax_2esurface_2elambdaL(v_r_240, v_binders_24760, v_body_24762, v_z_242));
  }
  case TAG_Case: {
    V v_kw_24763 = heff_dup(heff_field(v_e0_241, 0));
    V v_scrut_24764 = heff_dup(heff_field(v_e0_241, 1));
    V v_alts_24766 = heff_dup(heff_field(v_e0_241, 3));
    V v_m_24767 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_scrut_24764}));
    V v_x1_24768 = heff_tr(heff_call(v_m_24767, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x1_24768)) {
    case TAG_MkPair: {
      V v_x11_24769 = heff_field(v_x1_24768, 0);
      V v_st_24770 = heff_field(v_x1_24768, 1);
      V v_ru_24x1_24768_24MkPair = heff_take_reuse_n(v_x1_24768, 3ULL, 2);
      switch (heff_tag_of(v_x11_24769)) {
      case TAG_Left: {
        V v_e_24771 = heff_field(v_x11_24769, 0);
        heff_take_n(v_x11_24769, 1ULL, 1);
        heff_drop_rec(v_r_240, 3);
        heff_drop_tag(v_e0_241, 4);
        heff_drop_rec(v_kw_24763, 9);
        heff_drop(v_alts_24766);
        return heff_tag_at_n(v_ru_24x1_24768_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24771}), v_st_24770});
      }
      case TAG_Right: {
        V v_x_24772 = heff_field(v_x11_24769, 0);
        heff_take_n(v_x11_24769, 1ULL, 1);
        HeffT2 v_t_24774 = (g_heff_2esyntax_2esurface_2eblock_24cpr(heff_clo_n(g_heff_2esyntax_2esurface_2eexprL_lam7, 1, 1, (V[]){v_r_240}), v_alts_24766, v_st_24770));
        {
          V v_field_24775 = v_t_24774.f[0];
          V v_field_24776 = v_t_24774.f[1];
          V v_x11_24777 = v_field_24775;
          V v_st_24778 = v_field_24776;
          switch (heff_tag_of(v_x11_24777)) {
          case TAG_Left: {
            V v_e_24779 = heff_field(v_x11_24777, 0);
            heff_take_n(v_x11_24777, 1ULL, 1);
            heff_drop_tag(v_e0_241, 4);
            heff_drop_rec(v_kw_24763, 9);
            heff_drop(v_x_24772);
            return heff_tag_at_n(v_ru_24x1_24768_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24779}), v_st_24778});
          }
          case TAG_Right: {
            V v_x_24780 = heff_field(v_x11_24777, 0);
            heff_take_n(v_x11_24777, 1ULL, 1);
            V v_t_24781 = (g_heff_2esyntax_2ecst_2elastE(v_e0_241));
            V v_e_24782 = heff_get_n(v_t_24781, 4, 9);
            V v_t_24783 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_24763, 3, 9), v_e_24782});
            V v_x_24784 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_x_24772, v_x_24780}), v_t_24783});
            return heff_tag_at_n(v_ru_24x1_24768_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24784}), v_st_24778});
          }
          default: return heff_nomatch(v_x11_24777);
          }
        }
      }
      default: return heff_nomatch(v_x11_24769);
      }
    }
    default: return heff_nomatch(v_x1_24768);
    }
  }
  case TAG_EAlt: {
    heff_drop_rec(v_r_240, 3);
    V v_t_24788 = (g_heff_2esyntax_2ecst_2efirstE(v_e0_241));
    V v_t_24789 = ({ V a_0 = v_e0_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e0_241, 3); r_; });
    V v_t_24790 = heff_strAppend(heff_get_n(v_t_24789, 1, 9), ((V)&g_heff_2esyntax_2esurface_2eexprL_str31));
    V v_msg_24791 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eexprL_str32), v_t_24790);
    V v_t_24792 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24788, 3), heff_get_n(v_t_24788, 4, 9)});
    V v_t_24793 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24791, v_t_24792, NTAG(TAG_Nothing)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24793}), v_z_242});
  }
  case TAG_If: {
    V v_kw_24794 = heff_field(v_e0_241, 0);
    V v_e02_24795 = heff_field(v_e0_241, 1);
    V v_a_24797 = heff_field(v_e0_241, 3);
    V v_b_24799 = heff_field(v_e0_241, 5);
    heff_take_n(v_e0_241, 43ULL, 6);
    switch (heff_tag_of(v_e02_24795)) {
    case TAG_Atom: {
      V v_m_24801 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_24795}));
      V v_x1_24802 = heff_tr(heff_call(v_m_24801, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_24802)) {
      case TAG_MkPair: {
        V v_x11_24803 = heff_field(v_x1_24802, 0);
        V v_st_24804 = heff_field(v_x1_24802, 1);
        V v_ru_24x1_24802_24MkPair = heff_take_reuse_n(v_x1_24802, 3ULL, 2);
        switch (heff_tag_of(v_x11_24803)) {
        case TAG_Left: {
          V v_e_24805 = heff_field(v_x11_24803, 0);
          heff_take_n(v_x11_24803, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_24794, 9);
          heff_drop(v_a_24797);
          heff_drop(v_b_24799);
          return heff_tag_at_n(v_ru_24x1_24802_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24805}), v_st_24804});
        }
        case TAG_Right: {
          V v_x_24806 = heff_field(v_x11_24803, 0);
          heff_take_n(v_x11_24803, 1ULL, 1);
          V v_m_24807 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_24797}));
          V v_x1_24808 = heff_tr(heff_call(v_m_24807, 1, (V[]){v_st_24804}));
          switch (heff_tag_of(v_x1_24808)) {
          case TAG_MkPair: {
            V v_x11_24809 = heff_field(v_x1_24808, 0);
            V v_st_24810 = heff_field(v_x1_24808, 1);
            heff_take_n(v_x1_24808, 3ULL, 2);
            switch (heff_tag_of(v_x11_24809)) {
            case TAG_Left: {
              V v_e_24811 = heff_field(v_x11_24809, 0);
              heff_take_n(v_x11_24809, 1ULL, 1);
              heff_drop_rec(v_r_240, 3);
              heff_drop_rec(v_kw_24794, 9);
              heff_drop(v_b_24799);
              heff_drop(v_x_24806);
              return heff_tag_at_n(v_ru_24x1_24802_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24811}), v_st_24810});
            }
            case TAG_Right: {
              V v_x_24812 = heff_field(v_x11_24809, 0);
              heff_take_n(v_x11_24809, 1ULL, 1);
              V v_m_24813 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_b_24799)}));
              V v_x1_24814 = heff_tr(heff_call(v_m_24813, 1, (V[]){v_st_24810}));
              switch (heff_tag_of(v_x1_24814)) {
              case TAG_MkPair: {
                V v_x11_24815 = heff_field(v_x1_24814, 0);
                V v_st_24816 = heff_field(v_x1_24814, 1);
                heff_take_n(v_x1_24814, 3ULL, 2);
                switch (heff_tag_of(v_x11_24815)) {
                case TAG_Left: {
                  V v_e_24817 = heff_field(v_x11_24815, 0);
                  heff_take_n(v_x11_24815, 1ULL, 1);
                  heff_drop_rec(v_kw_24794, 9);
                  heff_drop(v_b_24799);
                  heff_drop(v_x_24806);
                  heff_drop(v_x_24812);
                  return heff_tag_at_n(v_ru_24x1_24802_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24817}), v_st_24816});
                }
                case TAG_Right: {
                  V v_x_24818 = heff_field(v_x11_24815, 0);
                  heff_take_n(v_x11_24815, 1ULL, 1);
                  V v_t_24819 = (g_heff_2esyntax_2ecst_2elastE(v_b_24799));
                  V v_e_24820 = heff_get_n(v_t_24819, 4, 9);
                  V v_t_24821 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_24794, 3, 9), v_e_24820});
                  V v_x_24822 = (g_heff_2esyntax_2esurface_2eifE(v_t_24821, v_x_24806, v_x_24812, v_x_24818));
                  return heff_tag_at_n(v_ru_24x1_24802_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24822}), v_st_24816});
                }
                default: return heff_nomatch(v_x11_24815);
                }
              }
              default: return heff_nomatch(v_x1_24814);
              }
            }
            default: return heff_nomatch(v_x11_24809);
            }
          }
          default: return heff_nomatch(v_x1_24808);
          }
        }
        default: return heff_nomatch(v_x11_24803);
        }
      }
      default: return heff_nomatch(v_x1_24802);
      }
    }
    case TAG_EParen: {
      V v_m_24826 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_24795}));
      V v_x1_24827 = heff_tr(heff_call(v_m_24826, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_24827)) {
      case TAG_MkPair: {
        V v_x11_24828 = heff_field(v_x1_24827, 0);
        V v_st_24829 = heff_field(v_x1_24827, 1);
        V v_ru_24x1_24827_24MkPair = heff_take_reuse_n(v_x1_24827, 3ULL, 2);
        switch (heff_tag_of(v_x11_24828)) {
        case TAG_Left: {
          V v_e_24830 = heff_field(v_x11_24828, 0);
          heff_take_n(v_x11_24828, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_24794, 9);
          heff_drop(v_a_24797);
          heff_drop(v_b_24799);
          return heff_tag_at_n(v_ru_24x1_24827_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24830}), v_st_24829});
        }
        case TAG_Right: {
          V v_x_24831 = heff_field(v_x11_24828, 0);
          heff_take_n(v_x11_24828, 1ULL, 1);
          V v_m_24832 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_24797}));
          V v_x1_24833 = heff_tr(heff_call(v_m_24832, 1, (V[]){v_st_24829}));
          switch (heff_tag_of(v_x1_24833)) {
          case TAG_MkPair: {
            V v_x11_24834 = heff_field(v_x1_24833, 0);
            V v_st_24835 = heff_field(v_x1_24833, 1);
            heff_take_n(v_x1_24833, 3ULL, 2);
            switch (heff_tag_of(v_x11_24834)) {
            case TAG_Left: {
              V v_e_24836 = heff_field(v_x11_24834, 0);
              heff_take_n(v_x11_24834, 1ULL, 1);
              heff_drop_rec(v_r_240, 3);
              heff_drop_rec(v_kw_24794, 9);
              heff_drop(v_b_24799);
              heff_drop(v_x_24831);
              return heff_tag_at_n(v_ru_24x1_24827_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24836}), v_st_24835});
            }
            case TAG_Right: {
              V v_x_24837 = heff_field(v_x11_24834, 0);
              heff_take_n(v_x11_24834, 1ULL, 1);
              V v_m_24838 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_b_24799)}));
              V v_x1_24839 = heff_tr(heff_call(v_m_24838, 1, (V[]){v_st_24835}));
              switch (heff_tag_of(v_x1_24839)) {
              case TAG_MkPair: {
                V v_x11_24840 = heff_field(v_x1_24839, 0);
                V v_st_24841 = heff_field(v_x1_24839, 1);
                heff_take_n(v_x1_24839, 3ULL, 2);
                switch (heff_tag_of(v_x11_24840)) {
                case TAG_Left: {
                  V v_e_24842 = heff_field(v_x11_24840, 0);
                  heff_take_n(v_x11_24840, 1ULL, 1);
                  heff_drop_rec(v_kw_24794, 9);
                  heff_drop(v_b_24799);
                  heff_drop(v_x_24831);
                  heff_drop(v_x_24837);
                  return heff_tag_at_n(v_ru_24x1_24827_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24842}), v_st_24841});
                }
                case TAG_Right: {
                  V v_x_24843 = heff_field(v_x11_24840, 0);
                  heff_take_n(v_x11_24840, 1ULL, 1);
                  V v_t_24844 = (g_heff_2esyntax_2ecst_2elastE(v_b_24799));
                  V v_e_24845 = heff_get_n(v_t_24844, 4, 9);
                  V v_t_24846 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_24794, 3, 9), v_e_24845});
                  V v_x_24847 = (g_heff_2esyntax_2esurface_2eifE(v_t_24846, v_x_24831, v_x_24837, v_x_24843));
                  return heff_tag_at_n(v_ru_24x1_24827_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24847}), v_st_24841});
                }
                default: return heff_nomatch(v_x11_24840);
                }
              }
              default: return heff_nomatch(v_x1_24839);
              }
            }
            default: return heff_nomatch(v_x11_24834);
            }
          }
          default: return heff_nomatch(v_x1_24833);
          }
        }
        default: return heff_nomatch(v_x11_24828);
        }
      }
      default: return heff_nomatch(v_x1_24827);
      }
    }
    case TAG_Named: {
      V v_m_24853 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_24795}));
      V v_x1_24854 = heff_tr(heff_call(v_m_24853, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_24854)) {
      case TAG_MkPair: {
        V v_x11_24855 = heff_field(v_x1_24854, 0);
        V v_st_24856 = heff_field(v_x1_24854, 1);
        V v_ru_24x1_24854_24MkPair = heff_take_reuse_n(v_x1_24854, 3ULL, 2);
        switch (heff_tag_of(v_x11_24855)) {
        case TAG_Left: {
          V v_e_24857 = heff_field(v_x11_24855, 0);
          heff_take_n(v_x11_24855, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_24794, 9);
          heff_drop(v_a_24797);
          heff_drop(v_b_24799);
          return heff_tag_at_n(v_ru_24x1_24854_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24857}), v_st_24856});
        }
        case TAG_Right: {
          V v_x_24858 = heff_field(v_x11_24855, 0);
          heff_take_n(v_x11_24855, 1ULL, 1);
          V v_m_24859 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_24797}));
          V v_x1_24860 = heff_tr(heff_call(v_m_24859, 1, (V[]){v_st_24856}));
          switch (heff_tag_of(v_x1_24860)) {
          case TAG_MkPair: {
            V v_x11_24861 = heff_field(v_x1_24860, 0);
            V v_st_24862 = heff_field(v_x1_24860, 1);
            heff_take_n(v_x1_24860, 3ULL, 2);
            switch (heff_tag_of(v_x11_24861)) {
            case TAG_Left: {
              V v_e_24863 = heff_field(v_x11_24861, 0);
              heff_take_n(v_x11_24861, 1ULL, 1);
              heff_drop_rec(v_r_240, 3);
              heff_drop_rec(v_kw_24794, 9);
              heff_drop(v_b_24799);
              heff_drop(v_x_24858);
              return heff_tag_at_n(v_ru_24x1_24854_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24863}), v_st_24862});
            }
            case TAG_Right: {
              V v_x_24864 = heff_field(v_x11_24861, 0);
              heff_take_n(v_x11_24861, 1ULL, 1);
              V v_m_24865 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_b_24799)}));
              V v_x1_24866 = heff_tr(heff_call(v_m_24865, 1, (V[]){v_st_24862}));
              switch (heff_tag_of(v_x1_24866)) {
              case TAG_MkPair: {
                V v_x11_24867 = heff_field(v_x1_24866, 0);
                V v_st_24868 = heff_field(v_x1_24866, 1);
                heff_take_n(v_x1_24866, 3ULL, 2);
                switch (heff_tag_of(v_x11_24867)) {
                case TAG_Left: {
                  V v_e_24869 = heff_field(v_x11_24867, 0);
                  heff_take_n(v_x11_24867, 1ULL, 1);
                  heff_drop_rec(v_kw_24794, 9);
                  heff_drop(v_b_24799);
                  heff_drop(v_x_24858);
                  heff_drop(v_x_24864);
                  return heff_tag_at_n(v_ru_24x1_24854_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24869}), v_st_24868});
                }
                case TAG_Right: {
                  V v_x_24870 = heff_field(v_x11_24867, 0);
                  heff_take_n(v_x11_24867, 1ULL, 1);
                  V v_t_24871 = (g_heff_2esyntax_2ecst_2elastE(v_b_24799));
                  V v_e_24872 = heff_get_n(v_t_24871, 4, 9);
                  V v_t_24873 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_24794, 3, 9), v_e_24872});
                  V v_x_24874 = (g_heff_2esyntax_2esurface_2eifE(v_t_24873, v_x_24858, v_x_24864, v_x_24870));
                  return heff_tag_at_n(v_ru_24x1_24854_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24874}), v_st_24868});
                }
                default: return heff_nomatch(v_x11_24867);
                }
              }
              default: return heff_nomatch(v_x1_24866);
              }
            }
            default: return heff_nomatch(v_x11_24861);
            }
          }
          default: return heff_nomatch(v_x1_24860);
          }
        }
        default: return heff_nomatch(v_x11_24855);
        }
      }
      default: return heff_nomatch(v_x1_24854);
      }
    }
    case TAG_Tup: {
      V v_m_24879 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_24795}));
      V v_x1_24880 = heff_tr(heff_call(v_m_24879, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_24880)) {
      case TAG_MkPair: {
        V v_x11_24881 = heff_field(v_x1_24880, 0);
        V v_st_24882 = heff_field(v_x1_24880, 1);
        V v_ru_24x1_24880_24MkPair = heff_take_reuse_n(v_x1_24880, 3ULL, 2);
        switch (heff_tag_of(v_x11_24881)) {
        case TAG_Left: {
          V v_e_24883 = heff_field(v_x11_24881, 0);
          heff_take_n(v_x11_24881, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_24794, 9);
          heff_drop(v_a_24797);
          heff_drop(v_b_24799);
          return heff_tag_at_n(v_ru_24x1_24880_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24883}), v_st_24882});
        }
        case TAG_Right: {
          V v_x_24884 = heff_field(v_x11_24881, 0);
          heff_take_n(v_x11_24881, 1ULL, 1);
          V v_m_24885 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_24797}));
          V v_x1_24886 = heff_tr(heff_call(v_m_24885, 1, (V[]){v_st_24882}));
          switch (heff_tag_of(v_x1_24886)) {
          case TAG_MkPair: {
            V v_x11_24887 = heff_field(v_x1_24886, 0);
            V v_st_24888 = heff_field(v_x1_24886, 1);
            heff_take_n(v_x1_24886, 3ULL, 2);
            switch (heff_tag_of(v_x11_24887)) {
            case TAG_Left: {
              V v_e_24889 = heff_field(v_x11_24887, 0);
              heff_take_n(v_x11_24887, 1ULL, 1);
              heff_drop_rec(v_r_240, 3);
              heff_drop_rec(v_kw_24794, 9);
              heff_drop(v_b_24799);
              heff_drop(v_x_24884);
              return heff_tag_at_n(v_ru_24x1_24880_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24889}), v_st_24888});
            }
            case TAG_Right: {
              V v_x_24890 = heff_field(v_x11_24887, 0);
              heff_take_n(v_x11_24887, 1ULL, 1);
              V v_m_24891 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_b_24799)}));
              V v_x1_24892 = heff_tr(heff_call(v_m_24891, 1, (V[]){v_st_24888}));
              switch (heff_tag_of(v_x1_24892)) {
              case TAG_MkPair: {
                V v_x11_24893 = heff_field(v_x1_24892, 0);
                V v_st_24894 = heff_field(v_x1_24892, 1);
                heff_take_n(v_x1_24892, 3ULL, 2);
                switch (heff_tag_of(v_x11_24893)) {
                case TAG_Left: {
                  V v_e_24895 = heff_field(v_x11_24893, 0);
                  heff_take_n(v_x11_24893, 1ULL, 1);
                  heff_drop_rec(v_kw_24794, 9);
                  heff_drop(v_b_24799);
                  heff_drop(v_x_24884);
                  heff_drop(v_x_24890);
                  return heff_tag_at_n(v_ru_24x1_24880_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24895}), v_st_24894});
                }
                case TAG_Right: {
                  V v_x_24896 = heff_field(v_x11_24893, 0);
                  heff_take_n(v_x11_24893, 1ULL, 1);
                  V v_t_24897 = (g_heff_2esyntax_2ecst_2elastE(v_b_24799));
                  V v_e_24898 = heff_get_n(v_t_24897, 4, 9);
                  V v_t_24899 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_24794, 3, 9), v_e_24898});
                  V v_x_24900 = (g_heff_2esyntax_2esurface_2eifE(v_t_24899, v_x_24884, v_x_24890, v_x_24896));
                  return heff_tag_at_n(v_ru_24x1_24880_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24900}), v_st_24894});
                }
                default: return heff_nomatch(v_x11_24893);
                }
              }
              default: return heff_nomatch(v_x1_24892);
              }
            }
            default: return heff_nomatch(v_x11_24887);
            }
          }
          default: return heff_nomatch(v_x1_24886);
          }
        }
        default: return heff_nomatch(v_x11_24881);
        }
      }
      default: return heff_nomatch(v_x1_24880);
      }
    }
    case TAG_Seg: {
      V v_m_24904 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_24795}));
      V v_x1_24905 = heff_tr(heff_call(v_m_24904, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_24905)) {
      case TAG_MkPair: {
        V v_x11_24906 = heff_field(v_x1_24905, 0);
        V v_st_24907 = heff_field(v_x1_24905, 1);
        V v_ru_24x1_24905_24MkPair = heff_take_reuse_n(v_x1_24905, 3ULL, 2);
        switch (heff_tag_of(v_x11_24906)) {
        case TAG_Left: {
          V v_e_24908 = heff_field(v_x11_24906, 0);
          heff_take_n(v_x11_24906, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_24794, 9);
          heff_drop(v_a_24797);
          heff_drop(v_b_24799);
          return heff_tag_at_n(v_ru_24x1_24905_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24908}), v_st_24907});
        }
        case TAG_Right: {
          V v_x_24909 = heff_field(v_x11_24906, 0);
          heff_take_n(v_x11_24906, 1ULL, 1);
          V v_m_24910 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_24797}));
          V v_x1_24911 = heff_tr(heff_call(v_m_24910, 1, (V[]){v_st_24907}));
          switch (heff_tag_of(v_x1_24911)) {
          case TAG_MkPair: {
            V v_x11_24912 = heff_field(v_x1_24911, 0);
            V v_st_24913 = heff_field(v_x1_24911, 1);
            heff_take_n(v_x1_24911, 3ULL, 2);
            switch (heff_tag_of(v_x11_24912)) {
            case TAG_Left: {
              V v_e_24914 = heff_field(v_x11_24912, 0);
              heff_take_n(v_x11_24912, 1ULL, 1);
              heff_drop_rec(v_r_240, 3);
              heff_drop_rec(v_kw_24794, 9);
              heff_drop(v_b_24799);
              heff_drop(v_x_24909);
              return heff_tag_at_n(v_ru_24x1_24905_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24914}), v_st_24913});
            }
            case TAG_Right: {
              V v_x_24915 = heff_field(v_x11_24912, 0);
              heff_take_n(v_x11_24912, 1ULL, 1);
              V v_m_24916 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_b_24799)}));
              V v_x1_24917 = heff_tr(heff_call(v_m_24916, 1, (V[]){v_st_24913}));
              switch (heff_tag_of(v_x1_24917)) {
              case TAG_MkPair: {
                V v_x11_24918 = heff_field(v_x1_24917, 0);
                V v_st_24919 = heff_field(v_x1_24917, 1);
                heff_take_n(v_x1_24917, 3ULL, 2);
                switch (heff_tag_of(v_x11_24918)) {
                case TAG_Left: {
                  V v_e_24920 = heff_field(v_x11_24918, 0);
                  heff_take_n(v_x11_24918, 1ULL, 1);
                  heff_drop_rec(v_kw_24794, 9);
                  heff_drop(v_b_24799);
                  heff_drop(v_x_24909);
                  heff_drop(v_x_24915);
                  return heff_tag_at_n(v_ru_24x1_24905_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24920}), v_st_24919});
                }
                case TAG_Right: {
                  V v_x_24921 = heff_field(v_x11_24918, 0);
                  heff_take_n(v_x11_24918, 1ULL, 1);
                  V v_t_24922 = (g_heff_2esyntax_2ecst_2elastE(v_b_24799));
                  V v_e_24923 = heff_get_n(v_t_24922, 4, 9);
                  V v_t_24924 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_24794, 3, 9), v_e_24923});
                  V v_x_24925 = (g_heff_2esyntax_2esurface_2eifE(v_t_24924, v_x_24909, v_x_24915, v_x_24921));
                  return heff_tag_at_n(v_ru_24x1_24905_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24925}), v_st_24919});
                }
                default: return heff_nomatch(v_x11_24918);
                }
              }
              default: return heff_nomatch(v_x1_24917);
              }
            }
            default: return heff_nomatch(v_x11_24912);
            }
          }
          default: return heff_nomatch(v_x1_24911);
          }
        }
        default: return heff_nomatch(v_x11_24906);
        }
      }
      default: return heff_nomatch(v_x1_24905);
      }
    }
    case TAG_Braces: {
      V v_m_24930 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_24795}));
      V v_x1_24931 = heff_tr(heff_call(v_m_24930, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_24931)) {
      case TAG_MkPair: {
        V v_x11_24932 = heff_field(v_x1_24931, 0);
        V v_st_24933 = heff_field(v_x1_24931, 1);
        V v_ru_24x1_24931_24MkPair = heff_take_reuse_n(v_x1_24931, 3ULL, 2);
        switch (heff_tag_of(v_x11_24932)) {
        case TAG_Left: {
          V v_e_24934 = heff_field(v_x11_24932, 0);
          heff_take_n(v_x11_24932, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_24794, 9);
          heff_drop(v_a_24797);
          heff_drop(v_b_24799);
          return heff_tag_at_n(v_ru_24x1_24931_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24934}), v_st_24933});
        }
        case TAG_Right: {
          V v_x_24935 = heff_field(v_x11_24932, 0);
          heff_take_n(v_x11_24932, 1ULL, 1);
          V v_m_24936 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_24797}));
          V v_x1_24937 = heff_tr(heff_call(v_m_24936, 1, (V[]){v_st_24933}));
          switch (heff_tag_of(v_x1_24937)) {
          case TAG_MkPair: {
            V v_x11_24938 = heff_field(v_x1_24937, 0);
            V v_st_24939 = heff_field(v_x1_24937, 1);
            heff_take_n(v_x1_24937, 3ULL, 2);
            switch (heff_tag_of(v_x11_24938)) {
            case TAG_Left: {
              V v_e_24940 = heff_field(v_x11_24938, 0);
              heff_take_n(v_x11_24938, 1ULL, 1);
              heff_drop_rec(v_r_240, 3);
              heff_drop_rec(v_kw_24794, 9);
              heff_drop(v_b_24799);
              heff_drop(v_x_24935);
              return heff_tag_at_n(v_ru_24x1_24931_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24940}), v_st_24939});
            }
            case TAG_Right: {
              V v_x_24941 = heff_field(v_x11_24938, 0);
              heff_take_n(v_x11_24938, 1ULL, 1);
              V v_m_24942 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_b_24799)}));
              V v_x1_24943 = heff_tr(heff_call(v_m_24942, 1, (V[]){v_st_24939}));
              switch (heff_tag_of(v_x1_24943)) {
              case TAG_MkPair: {
                V v_x11_24944 = heff_field(v_x1_24943, 0);
                V v_st_24945 = heff_field(v_x1_24943, 1);
                heff_take_n(v_x1_24943, 3ULL, 2);
                switch (heff_tag_of(v_x11_24944)) {
                case TAG_Left: {
                  V v_e_24946 = heff_field(v_x11_24944, 0);
                  heff_take_n(v_x11_24944, 1ULL, 1);
                  heff_drop_rec(v_kw_24794, 9);
                  heff_drop(v_b_24799);
                  heff_drop(v_x_24935);
                  heff_drop(v_x_24941);
                  return heff_tag_at_n(v_ru_24x1_24931_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24946}), v_st_24945});
                }
                case TAG_Right: {
                  V v_x_24947 = heff_field(v_x11_24944, 0);
                  heff_take_n(v_x11_24944, 1ULL, 1);
                  V v_t_24948 = (g_heff_2esyntax_2ecst_2elastE(v_b_24799));
                  V v_e_24949 = heff_get_n(v_t_24948, 4, 9);
                  V v_t_24950 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_24794, 3, 9), v_e_24949});
                  V v_x_24951 = (g_heff_2esyntax_2esurface_2eifE(v_t_24950, v_x_24935, v_x_24941, v_x_24947));
                  return heff_tag_at_n(v_ru_24x1_24931_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24951}), v_st_24945});
                }
                default: return heff_nomatch(v_x11_24944);
                }
              }
              default: return heff_nomatch(v_x1_24943);
              }
            }
            default: return heff_nomatch(v_x11_24938);
            }
          }
          default: return heff_nomatch(v_x1_24937);
          }
        }
        default: return heff_nomatch(v_x11_24932);
        }
      }
      default: return heff_nomatch(v_x1_24931);
      }
    }
    case TAG_Update: {
      V v_m_24958 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_24795}));
      V v_x1_24959 = heff_tr(heff_call(v_m_24958, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_24959)) {
      case TAG_MkPair: {
        V v_x11_24960 = heff_field(v_x1_24959, 0);
        V v_st_24961 = heff_field(v_x1_24959, 1);
        V v_ru_24x1_24959_24MkPair = heff_take_reuse_n(v_x1_24959, 3ULL, 2);
        switch (heff_tag_of(v_x11_24960)) {
        case TAG_Left: {
          V v_e_24962 = heff_field(v_x11_24960, 0);
          heff_take_n(v_x11_24960, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_24794, 9);
          heff_drop(v_a_24797);
          heff_drop(v_b_24799);
          return heff_tag_at_n(v_ru_24x1_24959_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24962}), v_st_24961});
        }
        case TAG_Right: {
          V v_x_24963 = heff_field(v_x11_24960, 0);
          heff_take_n(v_x11_24960, 1ULL, 1);
          V v_m_24964 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_24797}));
          V v_x1_24965 = heff_tr(heff_call(v_m_24964, 1, (V[]){v_st_24961}));
          switch (heff_tag_of(v_x1_24965)) {
          case TAG_MkPair: {
            V v_x11_24966 = heff_field(v_x1_24965, 0);
            V v_st_24967 = heff_field(v_x1_24965, 1);
            heff_take_n(v_x1_24965, 3ULL, 2);
            switch (heff_tag_of(v_x11_24966)) {
            case TAG_Left: {
              V v_e_24968 = heff_field(v_x11_24966, 0);
              heff_take_n(v_x11_24966, 1ULL, 1);
              heff_drop_rec(v_r_240, 3);
              heff_drop_rec(v_kw_24794, 9);
              heff_drop(v_b_24799);
              heff_drop(v_x_24963);
              return heff_tag_at_n(v_ru_24x1_24959_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24968}), v_st_24967});
            }
            case TAG_Right: {
              V v_x_24969 = heff_field(v_x11_24966, 0);
              heff_take_n(v_x11_24966, 1ULL, 1);
              V v_m_24970 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_b_24799)}));
              V v_x1_24971 = heff_tr(heff_call(v_m_24970, 1, (V[]){v_st_24967}));
              switch (heff_tag_of(v_x1_24971)) {
              case TAG_MkPair: {
                V v_x11_24972 = heff_field(v_x1_24971, 0);
                V v_st_24973 = heff_field(v_x1_24971, 1);
                heff_take_n(v_x1_24971, 3ULL, 2);
                switch (heff_tag_of(v_x11_24972)) {
                case TAG_Left: {
                  V v_e_24974 = heff_field(v_x11_24972, 0);
                  heff_take_n(v_x11_24972, 1ULL, 1);
                  heff_drop_rec(v_kw_24794, 9);
                  heff_drop(v_b_24799);
                  heff_drop(v_x_24963);
                  heff_drop(v_x_24969);
                  return heff_tag_at_n(v_ru_24x1_24959_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24974}), v_st_24973});
                }
                case TAG_Right: {
                  V v_x_24975 = heff_field(v_x11_24972, 0);
                  heff_take_n(v_x11_24972, 1ULL, 1);
                  V v_t_24976 = (g_heff_2esyntax_2ecst_2elastE(v_b_24799));
                  V v_e_24977 = heff_get_n(v_t_24976, 4, 9);
                  V v_t_24978 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_24794, 3, 9), v_e_24977});
                  V v_x_24979 = (g_heff_2esyntax_2esurface_2eifE(v_t_24978, v_x_24963, v_x_24969, v_x_24975));
                  return heff_tag_at_n(v_ru_24x1_24959_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24979}), v_st_24973});
                }
                default: return heff_nomatch(v_x11_24972);
                }
              }
              default: return heff_nomatch(v_x1_24971);
              }
            }
            default: return heff_nomatch(v_x11_24966);
            }
          }
          default: return heff_nomatch(v_x1_24965);
          }
        }
        default: return heff_nomatch(v_x11_24960);
        }
      }
      default: return heff_nomatch(v_x1_24959);
      }
    }
    case TAG_EUSet: {
      V v_m_24983 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_24795}));
      V v_x1_24984 = heff_tr(heff_call(v_m_24983, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_24984)) {
      case TAG_MkPair: {
        V v_x11_24985 = heff_field(v_x1_24984, 0);
        V v_st_24986 = heff_field(v_x1_24984, 1);
        V v_ru_24x1_24984_24MkPair = heff_take_reuse_n(v_x1_24984, 3ULL, 2);
        switch (heff_tag_of(v_x11_24985)) {
        case TAG_Left: {
          V v_e_24987 = heff_field(v_x11_24985, 0);
          heff_take_n(v_x11_24985, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_24794, 9);
          heff_drop(v_a_24797);
          heff_drop(v_b_24799);
          return heff_tag_at_n(v_ru_24x1_24984_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24987}), v_st_24986});
        }
        case TAG_Right: {
          V v_x_24988 = heff_field(v_x11_24985, 0);
          heff_take_n(v_x11_24985, 1ULL, 1);
          V v_m_24989 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_24797}));
          V v_x1_24990 = heff_tr(heff_call(v_m_24989, 1, (V[]){v_st_24986}));
          switch (heff_tag_of(v_x1_24990)) {
          case TAG_MkPair: {
            V v_x11_24991 = heff_field(v_x1_24990, 0);
            V v_st_24992 = heff_field(v_x1_24990, 1);
            heff_take_n(v_x1_24990, 3ULL, 2);
            switch (heff_tag_of(v_x11_24991)) {
            case TAG_Left: {
              V v_e_24993 = heff_field(v_x11_24991, 0);
              heff_take_n(v_x11_24991, 1ULL, 1);
              heff_drop_rec(v_r_240, 3);
              heff_drop_rec(v_kw_24794, 9);
              heff_drop(v_b_24799);
              heff_drop(v_x_24988);
              return heff_tag_at_n(v_ru_24x1_24984_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24993}), v_st_24992});
            }
            case TAG_Right: {
              V v_x_24994 = heff_field(v_x11_24991, 0);
              heff_take_n(v_x11_24991, 1ULL, 1);
              V v_m_24995 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_b_24799)}));
              V v_x1_24996 = heff_tr(heff_call(v_m_24995, 1, (V[]){v_st_24992}));
              switch (heff_tag_of(v_x1_24996)) {
              case TAG_MkPair: {
                V v_x11_24997 = heff_field(v_x1_24996, 0);
                V v_st_24998 = heff_field(v_x1_24996, 1);
                heff_take_n(v_x1_24996, 3ULL, 2);
                switch (heff_tag_of(v_x11_24997)) {
                case TAG_Left: {
                  V v_e_24999 = heff_field(v_x11_24997, 0);
                  heff_take_n(v_x11_24997, 1ULL, 1);
                  heff_drop_rec(v_kw_24794, 9);
                  heff_drop(v_b_24799);
                  heff_drop(v_x_24988);
                  heff_drop(v_x_24994);
                  return heff_tag_at_n(v_ru_24x1_24984_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24999}), v_st_24998});
                }
                case TAG_Right: {
                  V v_x_241000 = heff_field(v_x11_24997, 0);
                  heff_take_n(v_x11_24997, 1ULL, 1);
                  V v_t_241001 = (g_heff_2esyntax_2ecst_2elastE(v_b_24799));
                  V v_e_241002 = heff_get_n(v_t_241001, 4, 9);
                  V v_t_241003 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_24794, 3, 9), v_e_241002});
                  V v_x_241004 = (g_heff_2esyntax_2esurface_2eifE(v_t_241003, v_x_24988, v_x_24994, v_x_241000));
                  return heff_tag_at_n(v_ru_24x1_24984_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_241004}), v_st_24998});
                }
                default: return heff_nomatch(v_x11_24997);
                }
              }
              default: return heff_nomatch(v_x1_24996);
              }
            }
            default: return heff_nomatch(v_x11_24991);
            }
          }
          default: return heff_nomatch(v_x1_24990);
          }
        }
        default: return heff_nomatch(v_x11_24985);
        }
      }
      default: return heff_nomatch(v_x1_24984);
      }
    }
    case TAG_InstB: {
      V v_m_241010 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_24795}));
      V v_x1_241011 = heff_tr(heff_call(v_m_241010, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_241011)) {
      case TAG_MkPair: {
        V v_x11_241012 = heff_field(v_x1_241011, 0);
        V v_st_241013 = heff_field(v_x1_241011, 1);
        V v_ru_24x1_241011_24MkPair = heff_take_reuse_n(v_x1_241011, 3ULL, 2);
        switch (heff_tag_of(v_x11_241012)) {
        case TAG_Left: {
          V v_e_241014 = heff_field(v_x11_241012, 0);
          heff_take_n(v_x11_241012, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_24794, 9);
          heff_drop(v_a_24797);
          heff_drop(v_b_24799);
          return heff_tag_at_n(v_ru_24x1_241011_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241014}), v_st_241013});
        }
        case TAG_Right: {
          V v_x_241015 = heff_field(v_x11_241012, 0);
          heff_take_n(v_x11_241012, 1ULL, 1);
          V v_m_241016 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_24797}));
          V v_x1_241017 = heff_tr(heff_call(v_m_241016, 1, (V[]){v_st_241013}));
          switch (heff_tag_of(v_x1_241017)) {
          case TAG_MkPair: {
            V v_x11_241018 = heff_field(v_x1_241017, 0);
            V v_st_241019 = heff_field(v_x1_241017, 1);
            heff_take_n(v_x1_241017, 3ULL, 2);
            switch (heff_tag_of(v_x11_241018)) {
            case TAG_Left: {
              V v_e_241020 = heff_field(v_x11_241018, 0);
              heff_take_n(v_x11_241018, 1ULL, 1);
              heff_drop_rec(v_r_240, 3);
              heff_drop_rec(v_kw_24794, 9);
              heff_drop(v_b_24799);
              heff_drop(v_x_241015);
              return heff_tag_at_n(v_ru_24x1_241011_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241020}), v_st_241019});
            }
            case TAG_Right: {
              V v_x_241021 = heff_field(v_x11_241018, 0);
              heff_take_n(v_x11_241018, 1ULL, 1);
              V v_m_241022 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_b_24799)}));
              V v_x1_241023 = heff_tr(heff_call(v_m_241022, 1, (V[]){v_st_241019}));
              switch (heff_tag_of(v_x1_241023)) {
              case TAG_MkPair: {
                V v_x11_241024 = heff_field(v_x1_241023, 0);
                V v_st_241025 = heff_field(v_x1_241023, 1);
                heff_take_n(v_x1_241023, 3ULL, 2);
                switch (heff_tag_of(v_x11_241024)) {
                case TAG_Left: {
                  V v_e_241026 = heff_field(v_x11_241024, 0);
                  heff_take_n(v_x11_241024, 1ULL, 1);
                  heff_drop_rec(v_kw_24794, 9);
                  heff_drop(v_b_24799);
                  heff_drop(v_x_241015);
                  heff_drop(v_x_241021);
                  return heff_tag_at_n(v_ru_24x1_241011_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241026}), v_st_241025});
                }
                case TAG_Right: {
                  V v_x_241027 = heff_field(v_x11_241024, 0);
                  heff_take_n(v_x11_241024, 1ULL, 1);
                  V v_t_241028 = (g_heff_2esyntax_2ecst_2elastE(v_b_24799));
                  V v_e_241029 = heff_get_n(v_t_241028, 4, 9);
                  V v_t_241030 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_24794, 3, 9), v_e_241029});
                  V v_x_241031 = (g_heff_2esyntax_2esurface_2eifE(v_t_241030, v_x_241015, v_x_241021, v_x_241027));
                  return heff_tag_at_n(v_ru_24x1_241011_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_241031}), v_st_241025});
                }
                default: return heff_nomatch(v_x11_241024);
                }
              }
              default: return heff_nomatch(v_x1_241023);
              }
            }
            default: return heff_nomatch(v_x11_241018);
            }
          }
          default: return heff_nomatch(v_x1_241017);
          }
        }
        default: return heff_nomatch(v_x11_241012);
        }
      }
      default: return heff_nomatch(v_x1_241011);
      }
    }
    case TAG_EFSet: {
      V v_m_241035 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_24795}));
      V v_x1_241036 = heff_tr(heff_call(v_m_241035, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_241036)) {
      case TAG_MkPair: {
        V v_x11_241037 = heff_field(v_x1_241036, 0);
        V v_st_241038 = heff_field(v_x1_241036, 1);
        V v_ru_24x1_241036_24MkPair = heff_take_reuse_n(v_x1_241036, 3ULL, 2);
        switch (heff_tag_of(v_x11_241037)) {
        case TAG_Left: {
          V v_e_241039 = heff_field(v_x11_241037, 0);
          heff_take_n(v_x11_241037, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_24794, 9);
          heff_drop(v_a_24797);
          heff_drop(v_b_24799);
          return heff_tag_at_n(v_ru_24x1_241036_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241039}), v_st_241038});
        }
        case TAG_Right: {
          V v_x_241040 = heff_field(v_x11_241037, 0);
          heff_take_n(v_x11_241037, 1ULL, 1);
          V v_m_241041 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_24797}));
          V v_x1_241042 = heff_tr(heff_call(v_m_241041, 1, (V[]){v_st_241038}));
          switch (heff_tag_of(v_x1_241042)) {
          case TAG_MkPair: {
            V v_x11_241043 = heff_field(v_x1_241042, 0);
            V v_st_241044 = heff_field(v_x1_241042, 1);
            heff_take_n(v_x1_241042, 3ULL, 2);
            switch (heff_tag_of(v_x11_241043)) {
            case TAG_Left: {
              V v_e_241045 = heff_field(v_x11_241043, 0);
              heff_take_n(v_x11_241043, 1ULL, 1);
              heff_drop_rec(v_r_240, 3);
              heff_drop_rec(v_kw_24794, 9);
              heff_drop(v_b_24799);
              heff_drop(v_x_241040);
              return heff_tag_at_n(v_ru_24x1_241036_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241045}), v_st_241044});
            }
            case TAG_Right: {
              V v_x_241046 = heff_field(v_x11_241043, 0);
              heff_take_n(v_x11_241043, 1ULL, 1);
              V v_m_241047 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_b_24799)}));
              V v_x1_241048 = heff_tr(heff_call(v_m_241047, 1, (V[]){v_st_241044}));
              switch (heff_tag_of(v_x1_241048)) {
              case TAG_MkPair: {
                V v_x11_241049 = heff_field(v_x1_241048, 0);
                V v_st_241050 = heff_field(v_x1_241048, 1);
                heff_take_n(v_x1_241048, 3ULL, 2);
                switch (heff_tag_of(v_x11_241049)) {
                case TAG_Left: {
                  V v_e_241051 = heff_field(v_x11_241049, 0);
                  heff_take_n(v_x11_241049, 1ULL, 1);
                  heff_drop_rec(v_kw_24794, 9);
                  heff_drop(v_b_24799);
                  heff_drop(v_x_241040);
                  heff_drop(v_x_241046);
                  return heff_tag_at_n(v_ru_24x1_241036_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241051}), v_st_241050});
                }
                case TAG_Right: {
                  V v_x_241052 = heff_field(v_x11_241049, 0);
                  heff_take_n(v_x11_241049, 1ULL, 1);
                  V v_t_241053 = (g_heff_2esyntax_2ecst_2elastE(v_b_24799));
                  V v_e_241054 = heff_get_n(v_t_241053, 4, 9);
                  V v_t_241055 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_24794, 3, 9), v_e_241054});
                  V v_x_241056 = (g_heff_2esyntax_2esurface_2eifE(v_t_241055, v_x_241040, v_x_241046, v_x_241052));
                  return heff_tag_at_n(v_ru_24x1_241036_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_241056}), v_st_241050});
                }
                default: return heff_nomatch(v_x11_241049);
                }
              }
              default: return heff_nomatch(v_x1_241048);
              }
            }
            default: return heff_nomatch(v_x11_241043);
            }
          }
          default: return heff_nomatch(v_x1_241042);
          }
        }
        default: return heff_nomatch(v_x11_241037);
        }
      }
      default: return heff_nomatch(v_x1_241036);
      }
    }
    case TAG_EFDefault: {
      V v_m_241060 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_24795}));
      V v_x1_241061 = heff_tr(heff_call(v_m_241060, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_241061)) {
      case TAG_MkPair: {
        V v_x11_241062 = heff_field(v_x1_241061, 0);
        V v_st_241063 = heff_field(v_x1_241061, 1);
        V v_ru_24x1_241061_24MkPair = heff_take_reuse_n(v_x1_241061, 3ULL, 2);
        switch (heff_tag_of(v_x11_241062)) {
        case TAG_Left: {
          V v_e_241064 = heff_field(v_x11_241062, 0);
          heff_take_n(v_x11_241062, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_24794, 9);
          heff_drop(v_a_24797);
          heff_drop(v_b_24799);
          return heff_tag_at_n(v_ru_24x1_241061_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241064}), v_st_241063});
        }
        case TAG_Right: {
          V v_x_241065 = heff_field(v_x11_241062, 0);
          heff_take_n(v_x11_241062, 1ULL, 1);
          V v_m_241066 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_24797}));
          V v_x1_241067 = heff_tr(heff_call(v_m_241066, 1, (V[]){v_st_241063}));
          switch (heff_tag_of(v_x1_241067)) {
          case TAG_MkPair: {
            V v_x11_241068 = heff_field(v_x1_241067, 0);
            V v_st_241069 = heff_field(v_x1_241067, 1);
            heff_take_n(v_x1_241067, 3ULL, 2);
            switch (heff_tag_of(v_x11_241068)) {
            case TAG_Left: {
              V v_e_241070 = heff_field(v_x11_241068, 0);
              heff_take_n(v_x11_241068, 1ULL, 1);
              heff_drop_rec(v_r_240, 3);
              heff_drop_rec(v_kw_24794, 9);
              heff_drop(v_b_24799);
              heff_drop(v_x_241065);
              return heff_tag_at_n(v_ru_24x1_241061_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241070}), v_st_241069});
            }
            case TAG_Right: {
              V v_x_241071 = heff_field(v_x11_241068, 0);
              heff_take_n(v_x11_241068, 1ULL, 1);
              V v_m_241072 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_b_24799)}));
              V v_x1_241073 = heff_tr(heff_call(v_m_241072, 1, (V[]){v_st_241069}));
              switch (heff_tag_of(v_x1_241073)) {
              case TAG_MkPair: {
                V v_x11_241074 = heff_field(v_x1_241073, 0);
                V v_st_241075 = heff_field(v_x1_241073, 1);
                heff_take_n(v_x1_241073, 3ULL, 2);
                switch (heff_tag_of(v_x11_241074)) {
                case TAG_Left: {
                  V v_e_241076 = heff_field(v_x11_241074, 0);
                  heff_take_n(v_x11_241074, 1ULL, 1);
                  heff_drop_rec(v_kw_24794, 9);
                  heff_drop(v_b_24799);
                  heff_drop(v_x_241065);
                  heff_drop(v_x_241071);
                  return heff_tag_at_n(v_ru_24x1_241061_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241076}), v_st_241075});
                }
                case TAG_Right: {
                  V v_x_241077 = heff_field(v_x11_241074, 0);
                  heff_take_n(v_x11_241074, 1ULL, 1);
                  V v_t_241078 = (g_heff_2esyntax_2ecst_2elastE(v_b_24799));
                  V v_e_241079 = heff_get_n(v_t_241078, 4, 9);
                  V v_t_241080 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_24794, 3, 9), v_e_241079});
                  V v_x_241081 = (g_heff_2esyntax_2esurface_2eifE(v_t_241080, v_x_241065, v_x_241071, v_x_241077));
                  return heff_tag_at_n(v_ru_24x1_241061_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_241081}), v_st_241075});
                }
                default: return heff_nomatch(v_x11_241074);
                }
              }
              default: return heff_nomatch(v_x1_241073);
              }
            }
            default: return heff_nomatch(v_x11_241068);
            }
          }
          default: return heff_nomatch(v_x1_241067);
          }
        }
        default: return heff_nomatch(v_x11_241062);
        }
      }
      default: return heff_nomatch(v_x1_241061);
      }
    }
    case TAG_Sum: {
      V v_m_241087 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_24795}));
      V v_x1_241088 = heff_tr(heff_call(v_m_241087, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_241088)) {
      case TAG_MkPair: {
        V v_x11_241089 = heff_field(v_x1_241088, 0);
        V v_st_241090 = heff_field(v_x1_241088, 1);
        V v_ru_24x1_241088_24MkPair = heff_take_reuse_n(v_x1_241088, 3ULL, 2);
        switch (heff_tag_of(v_x11_241089)) {
        case TAG_Left: {
          V v_e_241091 = heff_field(v_x11_241089, 0);
          heff_take_n(v_x11_241089, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_24794, 9);
          heff_drop(v_a_24797);
          heff_drop(v_b_24799);
          return heff_tag_at_n(v_ru_24x1_241088_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241091}), v_st_241090});
        }
        case TAG_Right: {
          V v_x_241092 = heff_field(v_x11_241089, 0);
          heff_take_n(v_x11_241089, 1ULL, 1);
          V v_m_241093 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_24797}));
          V v_x1_241094 = heff_tr(heff_call(v_m_241093, 1, (V[]){v_st_241090}));
          switch (heff_tag_of(v_x1_241094)) {
          case TAG_MkPair: {
            V v_x11_241095 = heff_field(v_x1_241094, 0);
            V v_st_241096 = heff_field(v_x1_241094, 1);
            heff_take_n(v_x1_241094, 3ULL, 2);
            switch (heff_tag_of(v_x11_241095)) {
            case TAG_Left: {
              V v_e_241097 = heff_field(v_x11_241095, 0);
              heff_take_n(v_x11_241095, 1ULL, 1);
              heff_drop_rec(v_r_240, 3);
              heff_drop_rec(v_kw_24794, 9);
              heff_drop(v_b_24799);
              heff_drop(v_x_241092);
              return heff_tag_at_n(v_ru_24x1_241088_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241097}), v_st_241096});
            }
            case TAG_Right: {
              V v_x_241098 = heff_field(v_x11_241095, 0);
              heff_take_n(v_x11_241095, 1ULL, 1);
              V v_m_241099 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_b_24799)}));
              V v_x1_241100 = heff_tr(heff_call(v_m_241099, 1, (V[]){v_st_241096}));
              switch (heff_tag_of(v_x1_241100)) {
              case TAG_MkPair: {
                V v_x11_241101 = heff_field(v_x1_241100, 0);
                V v_st_241102 = heff_field(v_x1_241100, 1);
                heff_take_n(v_x1_241100, 3ULL, 2);
                switch (heff_tag_of(v_x11_241101)) {
                case TAG_Left: {
                  V v_e_241103 = heff_field(v_x11_241101, 0);
                  heff_take_n(v_x11_241101, 1ULL, 1);
                  heff_drop_rec(v_kw_24794, 9);
                  heff_drop(v_b_24799);
                  heff_drop(v_x_241092);
                  heff_drop(v_x_241098);
                  return heff_tag_at_n(v_ru_24x1_241088_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241103}), v_st_241102});
                }
                case TAG_Right: {
                  V v_x_241104 = heff_field(v_x11_241101, 0);
                  heff_take_n(v_x11_241101, 1ULL, 1);
                  V v_t_241105 = (g_heff_2esyntax_2ecst_2elastE(v_b_24799));
                  V v_e_241106 = heff_get_n(v_t_241105, 4, 9);
                  V v_t_241107 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_24794, 3, 9), v_e_241106});
                  V v_x_241108 = (g_heff_2esyntax_2esurface_2eifE(v_t_241107, v_x_241092, v_x_241098, v_x_241104));
                  return heff_tag_at_n(v_ru_24x1_241088_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_241108}), v_st_241102});
                }
                default: return heff_nomatch(v_x11_241101);
                }
              }
              default: return heff_nomatch(v_x1_241100);
              }
            }
            default: return heff_nomatch(v_x11_241095);
            }
          }
          default: return heff_nomatch(v_x1_241094);
          }
        }
        default: return heff_nomatch(v_x11_241089);
        }
      }
      default: return heff_nomatch(v_x1_241088);
      }
    }
    case TAG_ECon: {
      V v_m_241111 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_24795}));
      V v_x1_241112 = heff_tr(heff_call(v_m_241111, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_241112)) {
      case TAG_MkPair: {
        V v_x11_241113 = heff_field(v_x1_241112, 0);
        V v_st_241114 = heff_field(v_x1_241112, 1);
        V v_ru_24x1_241112_24MkPair = heff_take_reuse_n(v_x1_241112, 3ULL, 2);
        switch (heff_tag_of(v_x11_241113)) {
        case TAG_Left: {
          V v_e_241115 = heff_field(v_x11_241113, 0);
          heff_take_n(v_x11_241113, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_24794, 9);
          heff_drop(v_a_24797);
          heff_drop(v_b_24799);
          return heff_tag_at_n(v_ru_24x1_241112_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241115}), v_st_241114});
        }
        case TAG_Right: {
          V v_x_241116 = heff_field(v_x11_241113, 0);
          heff_take_n(v_x11_241113, 1ULL, 1);
          V v_m_241117 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_24797}));
          V v_x1_241118 = heff_tr(heff_call(v_m_241117, 1, (V[]){v_st_241114}));
          switch (heff_tag_of(v_x1_241118)) {
          case TAG_MkPair: {
            V v_x11_241119 = heff_field(v_x1_241118, 0);
            V v_st_241120 = heff_field(v_x1_241118, 1);
            heff_take_n(v_x1_241118, 3ULL, 2);
            switch (heff_tag_of(v_x11_241119)) {
            case TAG_Left: {
              V v_e_241121 = heff_field(v_x11_241119, 0);
              heff_take_n(v_x11_241119, 1ULL, 1);
              heff_drop_rec(v_r_240, 3);
              heff_drop_rec(v_kw_24794, 9);
              heff_drop(v_b_24799);
              heff_drop(v_x_241116);
              return heff_tag_at_n(v_ru_24x1_241112_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241121}), v_st_241120});
            }
            case TAG_Right: {
              V v_x_241122 = heff_field(v_x11_241119, 0);
              heff_take_n(v_x11_241119, 1ULL, 1);
              V v_m_241123 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_b_24799)}));
              V v_x1_241124 = heff_tr(heff_call(v_m_241123, 1, (V[]){v_st_241120}));
              switch (heff_tag_of(v_x1_241124)) {
              case TAG_MkPair: {
                V v_x11_241125 = heff_field(v_x1_241124, 0);
                V v_st_241126 = heff_field(v_x1_241124, 1);
                heff_take_n(v_x1_241124, 3ULL, 2);
                switch (heff_tag_of(v_x11_241125)) {
                case TAG_Left: {
                  V v_e_241127 = heff_field(v_x11_241125, 0);
                  heff_take_n(v_x11_241125, 1ULL, 1);
                  heff_drop_rec(v_kw_24794, 9);
                  heff_drop(v_b_24799);
                  heff_drop(v_x_241116);
                  heff_drop(v_x_241122);
                  return heff_tag_at_n(v_ru_24x1_241112_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241127}), v_st_241126});
                }
                case TAG_Right: {
                  V v_x_241128 = heff_field(v_x11_241125, 0);
                  heff_take_n(v_x11_241125, 1ULL, 1);
                  V v_t_241129 = (g_heff_2esyntax_2ecst_2elastE(v_b_24799));
                  V v_e_241130 = heff_get_n(v_t_241129, 4, 9);
                  V v_t_241131 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_24794, 3, 9), v_e_241130});
                  V v_x_241132 = (g_heff_2esyntax_2esurface_2eifE(v_t_241131, v_x_241116, v_x_241122, v_x_241128));
                  return heff_tag_at_n(v_ru_24x1_241112_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_241132}), v_st_241126});
                }
                default: return heff_nomatch(v_x11_241125);
                }
              }
              default: return heff_nomatch(v_x1_241124);
              }
            }
            default: return heff_nomatch(v_x11_241119);
            }
          }
          default: return heff_nomatch(v_x1_241118);
          }
        }
        default: return heff_nomatch(v_x11_241113);
        }
      }
      default: return heff_nomatch(v_x1_241112);
      }
    }
    case TAG_EField: {
      V v_m_241135 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_24795}));
      V v_x1_241136 = heff_tr(heff_call(v_m_241135, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_241136)) {
      case TAG_MkPair: {
        V v_x11_241137 = heff_field(v_x1_241136, 0);
        V v_st_241138 = heff_field(v_x1_241136, 1);
        V v_ru_24x1_241136_24MkPair = heff_take_reuse_n(v_x1_241136, 3ULL, 2);
        switch (heff_tag_of(v_x11_241137)) {
        case TAG_Left: {
          V v_e_241139 = heff_field(v_x11_241137, 0);
          heff_take_n(v_x11_241137, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_24794, 9);
          heff_drop(v_a_24797);
          heff_drop(v_b_24799);
          return heff_tag_at_n(v_ru_24x1_241136_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241139}), v_st_241138});
        }
        case TAG_Right: {
          V v_x_241140 = heff_field(v_x11_241137, 0);
          heff_take_n(v_x11_241137, 1ULL, 1);
          V v_m_241141 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_24797}));
          V v_x1_241142 = heff_tr(heff_call(v_m_241141, 1, (V[]){v_st_241138}));
          switch (heff_tag_of(v_x1_241142)) {
          case TAG_MkPair: {
            V v_x11_241143 = heff_field(v_x1_241142, 0);
            V v_st_241144 = heff_field(v_x1_241142, 1);
            heff_take_n(v_x1_241142, 3ULL, 2);
            switch (heff_tag_of(v_x11_241143)) {
            case TAG_Left: {
              V v_e_241145 = heff_field(v_x11_241143, 0);
              heff_take_n(v_x11_241143, 1ULL, 1);
              heff_drop_rec(v_r_240, 3);
              heff_drop_rec(v_kw_24794, 9);
              heff_drop(v_b_24799);
              heff_drop(v_x_241140);
              return heff_tag_at_n(v_ru_24x1_241136_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241145}), v_st_241144});
            }
            case TAG_Right: {
              V v_x_241146 = heff_field(v_x11_241143, 0);
              heff_take_n(v_x11_241143, 1ULL, 1);
              V v_m_241147 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_b_24799)}));
              V v_x1_241148 = heff_tr(heff_call(v_m_241147, 1, (V[]){v_st_241144}));
              switch (heff_tag_of(v_x1_241148)) {
              case TAG_MkPair: {
                V v_x11_241149 = heff_field(v_x1_241148, 0);
                V v_st_241150 = heff_field(v_x1_241148, 1);
                heff_take_n(v_x1_241148, 3ULL, 2);
                switch (heff_tag_of(v_x11_241149)) {
                case TAG_Left: {
                  V v_e_241151 = heff_field(v_x11_241149, 0);
                  heff_take_n(v_x11_241149, 1ULL, 1);
                  heff_drop_rec(v_kw_24794, 9);
                  heff_drop(v_b_24799);
                  heff_drop(v_x_241140);
                  heff_drop(v_x_241146);
                  return heff_tag_at_n(v_ru_24x1_241136_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241151}), v_st_241150});
                }
                case TAG_Right: {
                  V v_x_241152 = heff_field(v_x11_241149, 0);
                  heff_take_n(v_x11_241149, 1ULL, 1);
                  V v_t_241153 = (g_heff_2esyntax_2ecst_2elastE(v_b_24799));
                  V v_e_241154 = heff_get_n(v_t_241153, 4, 9);
                  V v_t_241155 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_24794, 3, 9), v_e_241154});
                  V v_x_241156 = (g_heff_2esyntax_2esurface_2eifE(v_t_241155, v_x_241140, v_x_241146, v_x_241152));
                  return heff_tag_at_n(v_ru_24x1_241136_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_241156}), v_st_241150});
                }
                default: return heff_nomatch(v_x11_241149);
                }
              }
              default: return heff_nomatch(v_x1_241148);
              }
            }
            default: return heff_nomatch(v_x11_241143);
            }
          }
          default: return heff_nomatch(v_x1_241142);
          }
        }
        default: return heff_nomatch(v_x11_241137);
        }
      }
      default: return heff_nomatch(v_x1_241136);
      }
    }
    case TAG_ENeg: {
      V v_m_241159 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_24795}));
      V v_x1_241160 = heff_tr(heff_call(v_m_241159, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_241160)) {
      case TAG_MkPair: {
        V v_x11_241161 = heff_field(v_x1_241160, 0);
        V v_st_241162 = heff_field(v_x1_241160, 1);
        V v_ru_24x1_241160_24MkPair = heff_take_reuse_n(v_x1_241160, 3ULL, 2);
        switch (heff_tag_of(v_x11_241161)) {
        case TAG_Left: {
          V v_e_241163 = heff_field(v_x11_241161, 0);
          heff_take_n(v_x11_241161, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_24794, 9);
          heff_drop(v_a_24797);
          heff_drop(v_b_24799);
          return heff_tag_at_n(v_ru_24x1_241160_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241163}), v_st_241162});
        }
        case TAG_Right: {
          V v_x_241164 = heff_field(v_x11_241161, 0);
          heff_take_n(v_x11_241161, 1ULL, 1);
          V v_m_241165 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_24797}));
          V v_x1_241166 = heff_tr(heff_call(v_m_241165, 1, (V[]){v_st_241162}));
          switch (heff_tag_of(v_x1_241166)) {
          case TAG_MkPair: {
            V v_x11_241167 = heff_field(v_x1_241166, 0);
            V v_st_241168 = heff_field(v_x1_241166, 1);
            heff_take_n(v_x1_241166, 3ULL, 2);
            switch (heff_tag_of(v_x11_241167)) {
            case TAG_Left: {
              V v_e_241169 = heff_field(v_x11_241167, 0);
              heff_take_n(v_x11_241167, 1ULL, 1);
              heff_drop_rec(v_r_240, 3);
              heff_drop_rec(v_kw_24794, 9);
              heff_drop(v_b_24799);
              heff_drop(v_x_241164);
              return heff_tag_at_n(v_ru_24x1_241160_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241169}), v_st_241168});
            }
            case TAG_Right: {
              V v_x_241170 = heff_field(v_x11_241167, 0);
              heff_take_n(v_x11_241167, 1ULL, 1);
              V v_m_241171 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_b_24799)}));
              V v_x1_241172 = heff_tr(heff_call(v_m_241171, 1, (V[]){v_st_241168}));
              switch (heff_tag_of(v_x1_241172)) {
              case TAG_MkPair: {
                V v_x11_241173 = heff_field(v_x1_241172, 0);
                V v_st_241174 = heff_field(v_x1_241172, 1);
                heff_take_n(v_x1_241172, 3ULL, 2);
                switch (heff_tag_of(v_x11_241173)) {
                case TAG_Left: {
                  V v_e_241175 = heff_field(v_x11_241173, 0);
                  heff_take_n(v_x11_241173, 1ULL, 1);
                  heff_drop_rec(v_kw_24794, 9);
                  heff_drop(v_b_24799);
                  heff_drop(v_x_241164);
                  heff_drop(v_x_241170);
                  return heff_tag_at_n(v_ru_24x1_241160_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241175}), v_st_241174});
                }
                case TAG_Right: {
                  V v_x_241176 = heff_field(v_x11_241173, 0);
                  heff_take_n(v_x11_241173, 1ULL, 1);
                  V v_t_241177 = (g_heff_2esyntax_2ecst_2elastE(v_b_24799));
                  V v_e_241178 = heff_get_n(v_t_241177, 4, 9);
                  V v_t_241179 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_24794, 3, 9), v_e_241178});
                  V v_x_241180 = (g_heff_2esyntax_2esurface_2eifE(v_t_241179, v_x_241164, v_x_241170, v_x_241176));
                  return heff_tag_at_n(v_ru_24x1_241160_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_241180}), v_st_241174});
                }
                default: return heff_nomatch(v_x11_241173);
                }
              }
              default: return heff_nomatch(v_x1_241172);
              }
            }
            default: return heff_nomatch(v_x11_241167);
            }
          }
          default: return heff_nomatch(v_x1_241166);
          }
        }
        default: return heff_nomatch(v_x11_241161);
        }
      }
      default: return heff_nomatch(v_x1_241160);
      }
    }
    case TAG_App: {
      V v_m_241183 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_24795}));
      V v_x1_241184 = heff_tr(heff_call(v_m_241183, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_241184)) {
      case TAG_MkPair: {
        V v_x11_241185 = heff_field(v_x1_241184, 0);
        V v_st_241186 = heff_field(v_x1_241184, 1);
        V v_ru_24x1_241184_24MkPair = heff_take_reuse_n(v_x1_241184, 3ULL, 2);
        switch (heff_tag_of(v_x11_241185)) {
        case TAG_Left: {
          V v_e_241187 = heff_field(v_x11_241185, 0);
          heff_take_n(v_x11_241185, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_24794, 9);
          heff_drop(v_a_24797);
          heff_drop(v_b_24799);
          return heff_tag_at_n(v_ru_24x1_241184_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241187}), v_st_241186});
        }
        case TAG_Right: {
          V v_x_241188 = heff_field(v_x11_241185, 0);
          heff_take_n(v_x11_241185, 1ULL, 1);
          V v_m_241189 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_24797}));
          V v_x1_241190 = heff_tr(heff_call(v_m_241189, 1, (V[]){v_st_241186}));
          switch (heff_tag_of(v_x1_241190)) {
          case TAG_MkPair: {
            V v_x11_241191 = heff_field(v_x1_241190, 0);
            V v_st_241192 = heff_field(v_x1_241190, 1);
            heff_take_n(v_x1_241190, 3ULL, 2);
            switch (heff_tag_of(v_x11_241191)) {
            case TAG_Left: {
              V v_e_241193 = heff_field(v_x11_241191, 0);
              heff_take_n(v_x11_241191, 1ULL, 1);
              heff_drop_rec(v_r_240, 3);
              heff_drop_rec(v_kw_24794, 9);
              heff_drop(v_b_24799);
              heff_drop(v_x_241188);
              return heff_tag_at_n(v_ru_24x1_241184_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241193}), v_st_241192});
            }
            case TAG_Right: {
              V v_x_241194 = heff_field(v_x11_241191, 0);
              heff_take_n(v_x11_241191, 1ULL, 1);
              V v_m_241195 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_b_24799)}));
              V v_x1_241196 = heff_tr(heff_call(v_m_241195, 1, (V[]){v_st_241192}));
              switch (heff_tag_of(v_x1_241196)) {
              case TAG_MkPair: {
                V v_x11_241197 = heff_field(v_x1_241196, 0);
                V v_st_241198 = heff_field(v_x1_241196, 1);
                heff_take_n(v_x1_241196, 3ULL, 2);
                switch (heff_tag_of(v_x11_241197)) {
                case TAG_Left: {
                  V v_e_241199 = heff_field(v_x11_241197, 0);
                  heff_take_n(v_x11_241197, 1ULL, 1);
                  heff_drop_rec(v_kw_24794, 9);
                  heff_drop(v_b_24799);
                  heff_drop(v_x_241188);
                  heff_drop(v_x_241194);
                  return heff_tag_at_n(v_ru_24x1_241184_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241199}), v_st_241198});
                }
                case TAG_Right: {
                  V v_x_241200 = heff_field(v_x11_241197, 0);
                  heff_take_n(v_x11_241197, 1ULL, 1);
                  V v_t_241201 = (g_heff_2esyntax_2ecst_2elastE(v_b_24799));
                  V v_e_241202 = heff_get_n(v_t_241201, 4, 9);
                  V v_t_241203 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_24794, 3, 9), v_e_241202});
                  V v_x_241204 = (g_heff_2esyntax_2esurface_2eifE(v_t_241203, v_x_241188, v_x_241194, v_x_241200));
                  return heff_tag_at_n(v_ru_24x1_241184_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_241204}), v_st_241198});
                }
                default: return heff_nomatch(v_x11_241197);
                }
              }
              default: return heff_nomatch(v_x1_241196);
              }
            }
            default: return heff_nomatch(v_x11_241191);
            }
          }
          default: return heff_nomatch(v_x1_241190);
          }
        }
        default: return heff_nomatch(v_x11_241185);
        }
      }
      default: return heff_nomatch(v_x1_241184);
      }
    }
    case TAG_Op: {
      V v_m_241208 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_24795}));
      V v_x1_241209 = heff_tr(heff_call(v_m_241208, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_241209)) {
      case TAG_MkPair: {
        V v_x11_241210 = heff_field(v_x1_241209, 0);
        V v_st_241211 = heff_field(v_x1_241209, 1);
        V v_ru_24x1_241209_24MkPair = heff_take_reuse_n(v_x1_241209, 3ULL, 2);
        switch (heff_tag_of(v_x11_241210)) {
        case TAG_Left: {
          V v_e_241212 = heff_field(v_x11_241210, 0);
          heff_take_n(v_x11_241210, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_24794, 9);
          heff_drop(v_a_24797);
          heff_drop(v_b_24799);
          return heff_tag_at_n(v_ru_24x1_241209_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241212}), v_st_241211});
        }
        case TAG_Right: {
          V v_x_241213 = heff_field(v_x11_241210, 0);
          heff_take_n(v_x11_241210, 1ULL, 1);
          V v_m_241214 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_24797}));
          V v_x1_241215 = heff_tr(heff_call(v_m_241214, 1, (V[]){v_st_241211}));
          switch (heff_tag_of(v_x1_241215)) {
          case TAG_MkPair: {
            V v_x11_241216 = heff_field(v_x1_241215, 0);
            V v_st_241217 = heff_field(v_x1_241215, 1);
            heff_take_n(v_x1_241215, 3ULL, 2);
            switch (heff_tag_of(v_x11_241216)) {
            case TAG_Left: {
              V v_e_241218 = heff_field(v_x11_241216, 0);
              heff_take_n(v_x11_241216, 1ULL, 1);
              heff_drop_rec(v_r_240, 3);
              heff_drop_rec(v_kw_24794, 9);
              heff_drop(v_b_24799);
              heff_drop(v_x_241213);
              return heff_tag_at_n(v_ru_24x1_241209_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241218}), v_st_241217});
            }
            case TAG_Right: {
              V v_x_241219 = heff_field(v_x11_241216, 0);
              heff_take_n(v_x11_241216, 1ULL, 1);
              V v_m_241220 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_b_24799)}));
              V v_x1_241221 = heff_tr(heff_call(v_m_241220, 1, (V[]){v_st_241217}));
              switch (heff_tag_of(v_x1_241221)) {
              case TAG_MkPair: {
                V v_x11_241222 = heff_field(v_x1_241221, 0);
                V v_st_241223 = heff_field(v_x1_241221, 1);
                heff_take_n(v_x1_241221, 3ULL, 2);
                switch (heff_tag_of(v_x11_241222)) {
                case TAG_Left: {
                  V v_e_241224 = heff_field(v_x11_241222, 0);
                  heff_take_n(v_x11_241222, 1ULL, 1);
                  heff_drop_rec(v_kw_24794, 9);
                  heff_drop(v_b_24799);
                  heff_drop(v_x_241213);
                  heff_drop(v_x_241219);
                  return heff_tag_at_n(v_ru_24x1_241209_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241224}), v_st_241223});
                }
                case TAG_Right: {
                  V v_x_241225 = heff_field(v_x11_241222, 0);
                  heff_take_n(v_x11_241222, 1ULL, 1);
                  V v_t_241226 = (g_heff_2esyntax_2ecst_2elastE(v_b_24799));
                  V v_e_241227 = heff_get_n(v_t_241226, 4, 9);
                  V v_t_241228 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_24794, 3, 9), v_e_241227});
                  V v_x_241229 = (g_heff_2esyntax_2esurface_2eifE(v_t_241228, v_x_241213, v_x_241219, v_x_241225));
                  return heff_tag_at_n(v_ru_24x1_241209_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_241229}), v_st_241223});
                }
                default: return heff_nomatch(v_x11_241222);
                }
              }
              default: return heff_nomatch(v_x1_241221);
              }
            }
            default: return heff_nomatch(v_x11_241216);
            }
          }
          default: return heff_nomatch(v_x1_241215);
          }
        }
        default: return heff_nomatch(v_x11_241210);
        }
      }
      default: return heff_nomatch(v_x1_241209);
      }
    }
    case TAG_Ops: {
      V v_m_241232 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_24795}));
      V v_x1_241233 = heff_tr(heff_call(v_m_241232, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_241233)) {
      case TAG_MkPair: {
        V v_x11_241234 = heff_field(v_x1_241233, 0);
        V v_st_241235 = heff_field(v_x1_241233, 1);
        V v_ru_24x1_241233_24MkPair = heff_take_reuse_n(v_x1_241233, 3ULL, 2);
        switch (heff_tag_of(v_x11_241234)) {
        case TAG_Left: {
          V v_e_241236 = heff_field(v_x11_241234, 0);
          heff_take_n(v_x11_241234, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_24794, 9);
          heff_drop(v_a_24797);
          heff_drop(v_b_24799);
          return heff_tag_at_n(v_ru_24x1_241233_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241236}), v_st_241235});
        }
        case TAG_Right: {
          V v_x_241237 = heff_field(v_x11_241234, 0);
          heff_take_n(v_x11_241234, 1ULL, 1);
          V v_m_241238 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_24797}));
          V v_x1_241239 = heff_tr(heff_call(v_m_241238, 1, (V[]){v_st_241235}));
          switch (heff_tag_of(v_x1_241239)) {
          case TAG_MkPair: {
            V v_x11_241240 = heff_field(v_x1_241239, 0);
            V v_st_241241 = heff_field(v_x1_241239, 1);
            heff_take_n(v_x1_241239, 3ULL, 2);
            switch (heff_tag_of(v_x11_241240)) {
            case TAG_Left: {
              V v_e_241242 = heff_field(v_x11_241240, 0);
              heff_take_n(v_x11_241240, 1ULL, 1);
              heff_drop_rec(v_r_240, 3);
              heff_drop_rec(v_kw_24794, 9);
              heff_drop(v_b_24799);
              heff_drop(v_x_241237);
              return heff_tag_at_n(v_ru_24x1_241233_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241242}), v_st_241241});
            }
            case TAG_Right: {
              V v_x_241243 = heff_field(v_x11_241240, 0);
              heff_take_n(v_x11_241240, 1ULL, 1);
              V v_m_241244 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_b_24799)}));
              V v_x1_241245 = heff_tr(heff_call(v_m_241244, 1, (V[]){v_st_241241}));
              switch (heff_tag_of(v_x1_241245)) {
              case TAG_MkPair: {
                V v_x11_241246 = heff_field(v_x1_241245, 0);
                V v_st_241247 = heff_field(v_x1_241245, 1);
                heff_take_n(v_x1_241245, 3ULL, 2);
                switch (heff_tag_of(v_x11_241246)) {
                case TAG_Left: {
                  V v_e_241248 = heff_field(v_x11_241246, 0);
                  heff_take_n(v_x11_241246, 1ULL, 1);
                  heff_drop_rec(v_kw_24794, 9);
                  heff_drop(v_b_24799);
                  heff_drop(v_x_241237);
                  heff_drop(v_x_241243);
                  return heff_tag_at_n(v_ru_24x1_241233_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241248}), v_st_241247});
                }
                case TAG_Right: {
                  V v_x_241249 = heff_field(v_x11_241246, 0);
                  heff_take_n(v_x11_241246, 1ULL, 1);
                  V v_t_241250 = (g_heff_2esyntax_2ecst_2elastE(v_b_24799));
                  V v_e_241251 = heff_get_n(v_t_241250, 4, 9);
                  V v_t_241252 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_24794, 3, 9), v_e_241251});
                  V v_x_241253 = (g_heff_2esyntax_2esurface_2eifE(v_t_241252, v_x_241237, v_x_241243, v_x_241249));
                  return heff_tag_at_n(v_ru_24x1_241233_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_241253}), v_st_241247});
                }
                default: return heff_nomatch(v_x11_241246);
                }
              }
              default: return heff_nomatch(v_x1_241245);
              }
            }
            default: return heff_nomatch(v_x11_241240);
            }
          }
          default: return heff_nomatch(v_x1_241239);
          }
        }
        default: return heff_nomatch(v_x11_241234);
        }
      }
      default: return heff_nomatch(v_x1_241233);
      }
    }
    case TAG_OpRhs: {
      V v_m_241256 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_24795}));
      V v_x1_241257 = heff_tr(heff_call(v_m_241256, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_241257)) {
      case TAG_MkPair: {
        V v_x11_241258 = heff_field(v_x1_241257, 0);
        V v_st_241259 = heff_field(v_x1_241257, 1);
        V v_ru_24x1_241257_24MkPair = heff_take_reuse_n(v_x1_241257, 3ULL, 2);
        switch (heff_tag_of(v_x11_241258)) {
        case TAG_Left: {
          V v_e_241260 = heff_field(v_x11_241258, 0);
          heff_take_n(v_x11_241258, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_24794, 9);
          heff_drop(v_a_24797);
          heff_drop(v_b_24799);
          return heff_tag_at_n(v_ru_24x1_241257_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241260}), v_st_241259});
        }
        case TAG_Right: {
          V v_x_241261 = heff_field(v_x11_241258, 0);
          heff_take_n(v_x11_241258, 1ULL, 1);
          V v_m_241262 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_24797}));
          V v_x1_241263 = heff_tr(heff_call(v_m_241262, 1, (V[]){v_st_241259}));
          switch (heff_tag_of(v_x1_241263)) {
          case TAG_MkPair: {
            V v_x11_241264 = heff_field(v_x1_241263, 0);
            V v_st_241265 = heff_field(v_x1_241263, 1);
            heff_take_n(v_x1_241263, 3ULL, 2);
            switch (heff_tag_of(v_x11_241264)) {
            case TAG_Left: {
              V v_e_241266 = heff_field(v_x11_241264, 0);
              heff_take_n(v_x11_241264, 1ULL, 1);
              heff_drop_rec(v_r_240, 3);
              heff_drop_rec(v_kw_24794, 9);
              heff_drop(v_b_24799);
              heff_drop(v_x_241261);
              return heff_tag_at_n(v_ru_24x1_241257_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241266}), v_st_241265});
            }
            case TAG_Right: {
              V v_x_241267 = heff_field(v_x11_241264, 0);
              heff_take_n(v_x11_241264, 1ULL, 1);
              V v_m_241268 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_b_24799)}));
              V v_x1_241269 = heff_tr(heff_call(v_m_241268, 1, (V[]){v_st_241265}));
              switch (heff_tag_of(v_x1_241269)) {
              case TAG_MkPair: {
                V v_x11_241270 = heff_field(v_x1_241269, 0);
                V v_st_241271 = heff_field(v_x1_241269, 1);
                heff_take_n(v_x1_241269, 3ULL, 2);
                switch (heff_tag_of(v_x11_241270)) {
                case TAG_Left: {
                  V v_e_241272 = heff_field(v_x11_241270, 0);
                  heff_take_n(v_x11_241270, 1ULL, 1);
                  heff_drop_rec(v_kw_24794, 9);
                  heff_drop(v_b_24799);
                  heff_drop(v_x_241261);
                  heff_drop(v_x_241267);
                  return heff_tag_at_n(v_ru_24x1_241257_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241272}), v_st_241271});
                }
                case TAG_Right: {
                  V v_x_241273 = heff_field(v_x11_241270, 0);
                  heff_take_n(v_x11_241270, 1ULL, 1);
                  V v_t_241274 = (g_heff_2esyntax_2ecst_2elastE(v_b_24799));
                  V v_e_241275 = heff_get_n(v_t_241274, 4, 9);
                  V v_t_241276 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_24794, 3, 9), v_e_241275});
                  V v_x_241277 = (g_heff_2esyntax_2esurface_2eifE(v_t_241276, v_x_241261, v_x_241267, v_x_241273));
                  return heff_tag_at_n(v_ru_24x1_241257_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_241277}), v_st_241271});
                }
                default: return heff_nomatch(v_x11_241270);
                }
              }
              default: return heff_nomatch(v_x1_241269);
              }
            }
            default: return heff_nomatch(v_x11_241264);
            }
          }
          default: return heff_nomatch(v_x1_241263);
          }
        }
        default: return heff_nomatch(v_x11_241258);
        }
      }
      default: return heff_nomatch(v_x1_241257);
      }
    }
    case TAG_Ann: {
      V v_m_241281 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_24795}));
      V v_x1_241282 = heff_tr(heff_call(v_m_241281, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_241282)) {
      case TAG_MkPair: {
        V v_x11_241283 = heff_field(v_x1_241282, 0);
        V v_st_241284 = heff_field(v_x1_241282, 1);
        V v_ru_24x1_241282_24MkPair = heff_take_reuse_n(v_x1_241282, 3ULL, 2);
        switch (heff_tag_of(v_x11_241283)) {
        case TAG_Left: {
          V v_e_241285 = heff_field(v_x11_241283, 0);
          heff_take_n(v_x11_241283, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_24794, 9);
          heff_drop(v_a_24797);
          heff_drop(v_b_24799);
          return heff_tag_at_n(v_ru_24x1_241282_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241285}), v_st_241284});
        }
        case TAG_Right: {
          V v_x_241286 = heff_field(v_x11_241283, 0);
          heff_take_n(v_x11_241283, 1ULL, 1);
          V v_m_241287 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_24797}));
          V v_x1_241288 = heff_tr(heff_call(v_m_241287, 1, (V[]){v_st_241284}));
          switch (heff_tag_of(v_x1_241288)) {
          case TAG_MkPair: {
            V v_x11_241289 = heff_field(v_x1_241288, 0);
            V v_st_241290 = heff_field(v_x1_241288, 1);
            heff_take_n(v_x1_241288, 3ULL, 2);
            switch (heff_tag_of(v_x11_241289)) {
            case TAG_Left: {
              V v_e_241291 = heff_field(v_x11_241289, 0);
              heff_take_n(v_x11_241289, 1ULL, 1);
              heff_drop_rec(v_r_240, 3);
              heff_drop_rec(v_kw_24794, 9);
              heff_drop(v_b_24799);
              heff_drop(v_x_241286);
              return heff_tag_at_n(v_ru_24x1_241282_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241291}), v_st_241290});
            }
            case TAG_Right: {
              V v_x_241292 = heff_field(v_x11_241289, 0);
              heff_take_n(v_x11_241289, 1ULL, 1);
              V v_m_241293 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_b_24799)}));
              V v_x1_241294 = heff_tr(heff_call(v_m_241293, 1, (V[]){v_st_241290}));
              switch (heff_tag_of(v_x1_241294)) {
              case TAG_MkPair: {
                V v_x11_241295 = heff_field(v_x1_241294, 0);
                V v_st_241296 = heff_field(v_x1_241294, 1);
                heff_take_n(v_x1_241294, 3ULL, 2);
                switch (heff_tag_of(v_x11_241295)) {
                case TAG_Left: {
                  V v_e_241297 = heff_field(v_x11_241295, 0);
                  heff_take_n(v_x11_241295, 1ULL, 1);
                  heff_drop_rec(v_kw_24794, 9);
                  heff_drop(v_b_24799);
                  heff_drop(v_x_241286);
                  heff_drop(v_x_241292);
                  return heff_tag_at_n(v_ru_24x1_241282_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241297}), v_st_241296});
                }
                case TAG_Right: {
                  V v_x_241298 = heff_field(v_x11_241295, 0);
                  heff_take_n(v_x11_241295, 1ULL, 1);
                  V v_t_241299 = (g_heff_2esyntax_2ecst_2elastE(v_b_24799));
                  V v_e_241300 = heff_get_n(v_t_241299, 4, 9);
                  V v_t_241301 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_24794, 3, 9), v_e_241300});
                  V v_x_241302 = (g_heff_2esyntax_2esurface_2eifE(v_t_241301, v_x_241286, v_x_241292, v_x_241298));
                  return heff_tag_at_n(v_ru_24x1_241282_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_241302}), v_st_241296});
                }
                default: return heff_nomatch(v_x11_241295);
                }
              }
              default: return heff_nomatch(v_x1_241294);
              }
            }
            default: return heff_nomatch(v_x11_241289);
            }
          }
          default: return heff_nomatch(v_x1_241288);
          }
        }
        default: return heff_nomatch(v_x11_241283);
        }
      }
      default: return heff_nomatch(v_x1_241282);
      }
    }
    case TAG_BVar: {
      V v_m_241304 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_24795}));
      V v_x1_241305 = heff_tr(heff_call(v_m_241304, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_241305)) {
      case TAG_MkPair: {
        V v_x11_241306 = heff_field(v_x1_241305, 0);
        V v_st_241307 = heff_field(v_x1_241305, 1);
        V v_ru_24x1_241305_24MkPair = heff_take_reuse_n(v_x1_241305, 3ULL, 2);
        switch (heff_tag_of(v_x11_241306)) {
        case TAG_Left: {
          V v_e_241308 = heff_field(v_x11_241306, 0);
          heff_take_n(v_x11_241306, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_24794, 9);
          heff_drop(v_a_24797);
          heff_drop(v_b_24799);
          return heff_tag_at_n(v_ru_24x1_241305_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241308}), v_st_241307});
        }
        case TAG_Right: {
          V v_x_241309 = heff_field(v_x11_241306, 0);
          heff_take_n(v_x11_241306, 1ULL, 1);
          V v_m_241310 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_24797}));
          V v_x1_241311 = heff_tr(heff_call(v_m_241310, 1, (V[]){v_st_241307}));
          switch (heff_tag_of(v_x1_241311)) {
          case TAG_MkPair: {
            V v_x11_241312 = heff_field(v_x1_241311, 0);
            V v_st_241313 = heff_field(v_x1_241311, 1);
            heff_take_n(v_x1_241311, 3ULL, 2);
            switch (heff_tag_of(v_x11_241312)) {
            case TAG_Left: {
              V v_e_241314 = heff_field(v_x11_241312, 0);
              heff_take_n(v_x11_241312, 1ULL, 1);
              heff_drop_rec(v_r_240, 3);
              heff_drop_rec(v_kw_24794, 9);
              heff_drop(v_b_24799);
              heff_drop(v_x_241309);
              return heff_tag_at_n(v_ru_24x1_241305_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241314}), v_st_241313});
            }
            case TAG_Right: {
              V v_x_241315 = heff_field(v_x11_241312, 0);
              heff_take_n(v_x11_241312, 1ULL, 1);
              V v_m_241316 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_b_24799)}));
              V v_x1_241317 = heff_tr(heff_call(v_m_241316, 1, (V[]){v_st_241313}));
              switch (heff_tag_of(v_x1_241317)) {
              case TAG_MkPair: {
                V v_x11_241318 = heff_field(v_x1_241317, 0);
                V v_st_241319 = heff_field(v_x1_241317, 1);
                heff_take_n(v_x1_241317, 3ULL, 2);
                switch (heff_tag_of(v_x11_241318)) {
                case TAG_Left: {
                  V v_e_241320 = heff_field(v_x11_241318, 0);
                  heff_take_n(v_x11_241318, 1ULL, 1);
                  heff_drop_rec(v_kw_24794, 9);
                  heff_drop(v_b_24799);
                  heff_drop(v_x_241309);
                  heff_drop(v_x_241315);
                  return heff_tag_at_n(v_ru_24x1_241305_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241320}), v_st_241319});
                }
                case TAG_Right: {
                  V v_x_241321 = heff_field(v_x11_241318, 0);
                  heff_take_n(v_x11_241318, 1ULL, 1);
                  V v_t_241322 = (g_heff_2esyntax_2ecst_2elastE(v_b_24799));
                  V v_e_241323 = heff_get_n(v_t_241322, 4, 9);
                  V v_t_241324 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_24794, 3, 9), v_e_241323});
                  V v_x_241325 = (g_heff_2esyntax_2esurface_2eifE(v_t_241324, v_x_241309, v_x_241315, v_x_241321));
                  return heff_tag_at_n(v_ru_24x1_241305_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_241325}), v_st_241319});
                }
                default: return heff_nomatch(v_x11_241318);
                }
              }
              default: return heff_nomatch(v_x1_241317);
              }
            }
            default: return heff_nomatch(v_x11_241312);
            }
          }
          default: return heff_nomatch(v_x1_241311);
          }
        }
        default: return heff_nomatch(v_x11_241306);
        }
      }
      default: return heff_nomatch(v_x1_241305);
      }
    }
    case TAG_BImp: {
      V v_m_241329 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_24795}));
      V v_x1_241330 = heff_tr(heff_call(v_m_241329, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_241330)) {
      case TAG_MkPair: {
        V v_x11_241331 = heff_field(v_x1_241330, 0);
        V v_st_241332 = heff_field(v_x1_241330, 1);
        V v_ru_24x1_241330_24MkPair = heff_take_reuse_n(v_x1_241330, 3ULL, 2);
        switch (heff_tag_of(v_x11_241331)) {
        case TAG_Left: {
          V v_e_241333 = heff_field(v_x11_241331, 0);
          heff_take_n(v_x11_241331, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_24794, 9);
          heff_drop(v_a_24797);
          heff_drop(v_b_24799);
          return heff_tag_at_n(v_ru_24x1_241330_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241333}), v_st_241332});
        }
        case TAG_Right: {
          V v_x_241334 = heff_field(v_x11_241331, 0);
          heff_take_n(v_x11_241331, 1ULL, 1);
          V v_m_241335 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_24797}));
          V v_x1_241336 = heff_tr(heff_call(v_m_241335, 1, (V[]){v_st_241332}));
          switch (heff_tag_of(v_x1_241336)) {
          case TAG_MkPair: {
            V v_x11_241337 = heff_field(v_x1_241336, 0);
            V v_st_241338 = heff_field(v_x1_241336, 1);
            heff_take_n(v_x1_241336, 3ULL, 2);
            switch (heff_tag_of(v_x11_241337)) {
            case TAG_Left: {
              V v_e_241339 = heff_field(v_x11_241337, 0);
              heff_take_n(v_x11_241337, 1ULL, 1);
              heff_drop_rec(v_r_240, 3);
              heff_drop_rec(v_kw_24794, 9);
              heff_drop(v_b_24799);
              heff_drop(v_x_241334);
              return heff_tag_at_n(v_ru_24x1_241330_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241339}), v_st_241338});
            }
            case TAG_Right: {
              V v_x_241340 = heff_field(v_x11_241337, 0);
              heff_take_n(v_x11_241337, 1ULL, 1);
              V v_m_241341 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_b_24799)}));
              V v_x1_241342 = heff_tr(heff_call(v_m_241341, 1, (V[]){v_st_241338}));
              switch (heff_tag_of(v_x1_241342)) {
              case TAG_MkPair: {
                V v_x11_241343 = heff_field(v_x1_241342, 0);
                V v_st_241344 = heff_field(v_x1_241342, 1);
                heff_take_n(v_x1_241342, 3ULL, 2);
                switch (heff_tag_of(v_x11_241343)) {
                case TAG_Left: {
                  V v_e_241345 = heff_field(v_x11_241343, 0);
                  heff_take_n(v_x11_241343, 1ULL, 1);
                  heff_drop_rec(v_kw_24794, 9);
                  heff_drop(v_b_24799);
                  heff_drop(v_x_241334);
                  heff_drop(v_x_241340);
                  return heff_tag_at_n(v_ru_24x1_241330_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241345}), v_st_241344});
                }
                case TAG_Right: {
                  V v_x_241346 = heff_field(v_x11_241343, 0);
                  heff_take_n(v_x11_241343, 1ULL, 1);
                  V v_t_241347 = (g_heff_2esyntax_2ecst_2elastE(v_b_24799));
                  V v_e_241348 = heff_get_n(v_t_241347, 4, 9);
                  V v_t_241349 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_24794, 3, 9), v_e_241348});
                  V v_x_241350 = (g_heff_2esyntax_2esurface_2eifE(v_t_241349, v_x_241334, v_x_241340, v_x_241346));
                  return heff_tag_at_n(v_ru_24x1_241330_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_241350}), v_st_241344});
                }
                default: return heff_nomatch(v_x11_241343);
                }
              }
              default: return heff_nomatch(v_x1_241342);
              }
            }
            default: return heff_nomatch(v_x11_241337);
            }
          }
          default: return heff_nomatch(v_x1_241336);
          }
        }
        default: return heff_nomatch(v_x11_241331);
        }
      }
      default: return heff_nomatch(v_x1_241330);
      }
    }
    case TAG_BAnn: {
      V v_m_241356 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_24795}));
      V v_x1_241357 = heff_tr(heff_call(v_m_241356, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_241357)) {
      case TAG_MkPair: {
        V v_x11_241358 = heff_field(v_x1_241357, 0);
        V v_st_241359 = heff_field(v_x1_241357, 1);
        V v_ru_24x1_241357_24MkPair = heff_take_reuse_n(v_x1_241357, 3ULL, 2);
        switch (heff_tag_of(v_x11_241358)) {
        case TAG_Left: {
          V v_e_241360 = heff_field(v_x11_241358, 0);
          heff_take_n(v_x11_241358, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_24794, 9);
          heff_drop(v_a_24797);
          heff_drop(v_b_24799);
          return heff_tag_at_n(v_ru_24x1_241357_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241360}), v_st_241359});
        }
        case TAG_Right: {
          V v_x_241361 = heff_field(v_x11_241358, 0);
          heff_take_n(v_x11_241358, 1ULL, 1);
          V v_m_241362 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_24797}));
          V v_x1_241363 = heff_tr(heff_call(v_m_241362, 1, (V[]){v_st_241359}));
          switch (heff_tag_of(v_x1_241363)) {
          case TAG_MkPair: {
            V v_x11_241364 = heff_field(v_x1_241363, 0);
            V v_st_241365 = heff_field(v_x1_241363, 1);
            heff_take_n(v_x1_241363, 3ULL, 2);
            switch (heff_tag_of(v_x11_241364)) {
            case TAG_Left: {
              V v_e_241366 = heff_field(v_x11_241364, 0);
              heff_take_n(v_x11_241364, 1ULL, 1);
              heff_drop_rec(v_r_240, 3);
              heff_drop_rec(v_kw_24794, 9);
              heff_drop(v_b_24799);
              heff_drop(v_x_241361);
              return heff_tag_at_n(v_ru_24x1_241357_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241366}), v_st_241365});
            }
            case TAG_Right: {
              V v_x_241367 = heff_field(v_x11_241364, 0);
              heff_take_n(v_x11_241364, 1ULL, 1);
              V v_m_241368 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_b_24799)}));
              V v_x1_241369 = heff_tr(heff_call(v_m_241368, 1, (V[]){v_st_241365}));
              switch (heff_tag_of(v_x1_241369)) {
              case TAG_MkPair: {
                V v_x11_241370 = heff_field(v_x1_241369, 0);
                V v_st_241371 = heff_field(v_x1_241369, 1);
                heff_take_n(v_x1_241369, 3ULL, 2);
                switch (heff_tag_of(v_x11_241370)) {
                case TAG_Left: {
                  V v_e_241372 = heff_field(v_x11_241370, 0);
                  heff_take_n(v_x11_241370, 1ULL, 1);
                  heff_drop_rec(v_kw_24794, 9);
                  heff_drop(v_b_24799);
                  heff_drop(v_x_241361);
                  heff_drop(v_x_241367);
                  return heff_tag_at_n(v_ru_24x1_241357_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241372}), v_st_241371});
                }
                case TAG_Right: {
                  V v_x_241373 = heff_field(v_x11_241370, 0);
                  heff_take_n(v_x11_241370, 1ULL, 1);
                  V v_t_241374 = (g_heff_2esyntax_2ecst_2elastE(v_b_24799));
                  V v_e_241375 = heff_get_n(v_t_241374, 4, 9);
                  V v_t_241376 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_24794, 3, 9), v_e_241375});
                  V v_x_241377 = (g_heff_2esyntax_2esurface_2eifE(v_t_241376, v_x_241361, v_x_241367, v_x_241373));
                  return heff_tag_at_n(v_ru_24x1_241357_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_241377}), v_st_241371});
                }
                default: return heff_nomatch(v_x11_241370);
                }
              }
              default: return heff_nomatch(v_x1_241369);
              }
            }
            default: return heff_nomatch(v_x11_241364);
            }
          }
          default: return heff_nomatch(v_x1_241363);
          }
        }
        default: return heff_nomatch(v_x11_241358);
        }
      }
      default: return heff_nomatch(v_x1_241357);
      }
    }
    case TAG_Lam: {
      V v_m_241382 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_24795}));
      V v_x1_241383 = heff_tr(heff_call(v_m_241382, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_241383)) {
      case TAG_MkPair: {
        V v_x11_241384 = heff_field(v_x1_241383, 0);
        V v_st_241385 = heff_field(v_x1_241383, 1);
        V v_ru_24x1_241383_24MkPair = heff_take_reuse_n(v_x1_241383, 3ULL, 2);
        switch (heff_tag_of(v_x11_241384)) {
        case TAG_Left: {
          V v_e_241386 = heff_field(v_x11_241384, 0);
          heff_take_n(v_x11_241384, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_24794, 9);
          heff_drop(v_a_24797);
          heff_drop(v_b_24799);
          return heff_tag_at_n(v_ru_24x1_241383_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241386}), v_st_241385});
        }
        case TAG_Right: {
          V v_x_241387 = heff_field(v_x11_241384, 0);
          heff_take_n(v_x11_241384, 1ULL, 1);
          V v_m_241388 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_24797}));
          V v_x1_241389 = heff_tr(heff_call(v_m_241388, 1, (V[]){v_st_241385}));
          switch (heff_tag_of(v_x1_241389)) {
          case TAG_MkPair: {
            V v_x11_241390 = heff_field(v_x1_241389, 0);
            V v_st_241391 = heff_field(v_x1_241389, 1);
            heff_take_n(v_x1_241389, 3ULL, 2);
            switch (heff_tag_of(v_x11_241390)) {
            case TAG_Left: {
              V v_e_241392 = heff_field(v_x11_241390, 0);
              heff_take_n(v_x11_241390, 1ULL, 1);
              heff_drop_rec(v_r_240, 3);
              heff_drop_rec(v_kw_24794, 9);
              heff_drop(v_b_24799);
              heff_drop(v_x_241387);
              return heff_tag_at_n(v_ru_24x1_241383_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241392}), v_st_241391});
            }
            case TAG_Right: {
              V v_x_241393 = heff_field(v_x11_241390, 0);
              heff_take_n(v_x11_241390, 1ULL, 1);
              V v_m_241394 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_b_24799)}));
              V v_x1_241395 = heff_tr(heff_call(v_m_241394, 1, (V[]){v_st_241391}));
              switch (heff_tag_of(v_x1_241395)) {
              case TAG_MkPair: {
                V v_x11_241396 = heff_field(v_x1_241395, 0);
                V v_st_241397 = heff_field(v_x1_241395, 1);
                heff_take_n(v_x1_241395, 3ULL, 2);
                switch (heff_tag_of(v_x11_241396)) {
                case TAG_Left: {
                  V v_e_241398 = heff_field(v_x11_241396, 0);
                  heff_take_n(v_x11_241396, 1ULL, 1);
                  heff_drop_rec(v_kw_24794, 9);
                  heff_drop(v_b_24799);
                  heff_drop(v_x_241387);
                  heff_drop(v_x_241393);
                  return heff_tag_at_n(v_ru_24x1_241383_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241398}), v_st_241397});
                }
                case TAG_Right: {
                  V v_x_241399 = heff_field(v_x11_241396, 0);
                  heff_take_n(v_x11_241396, 1ULL, 1);
                  V v_t_241400 = (g_heff_2esyntax_2ecst_2elastE(v_b_24799));
                  V v_e_241401 = heff_get_n(v_t_241400, 4, 9);
                  V v_t_241402 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_24794, 3, 9), v_e_241401});
                  V v_x_241403 = (g_heff_2esyntax_2esurface_2eifE(v_t_241402, v_x_241387, v_x_241393, v_x_241399));
                  return heff_tag_at_n(v_ru_24x1_241383_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_241403}), v_st_241397});
                }
                default: return heff_nomatch(v_x11_241396);
                }
              }
              default: return heff_nomatch(v_x1_241395);
              }
            }
            default: return heff_nomatch(v_x11_241390);
            }
          }
          default: return heff_nomatch(v_x1_241389);
          }
        }
        default: return heff_nomatch(v_x11_241384);
        }
      }
      default: return heff_nomatch(v_x1_241383);
      }
    }
    case TAG_Case: {
      V v_m_241408 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_24795}));
      V v_x1_241409 = heff_tr(heff_call(v_m_241408, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_241409)) {
      case TAG_MkPair: {
        V v_x11_241410 = heff_field(v_x1_241409, 0);
        V v_st_241411 = heff_field(v_x1_241409, 1);
        V v_ru_24x1_241409_24MkPair = heff_take_reuse_n(v_x1_241409, 3ULL, 2);
        switch (heff_tag_of(v_x11_241410)) {
        case TAG_Left: {
          V v_e_241412 = heff_field(v_x11_241410, 0);
          heff_take_n(v_x11_241410, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_24794, 9);
          heff_drop(v_a_24797);
          heff_drop(v_b_24799);
          return heff_tag_at_n(v_ru_24x1_241409_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241412}), v_st_241411});
        }
        case TAG_Right: {
          V v_x_241413 = heff_field(v_x11_241410, 0);
          heff_take_n(v_x11_241410, 1ULL, 1);
          V v_m_241414 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_24797}));
          V v_x1_241415 = heff_tr(heff_call(v_m_241414, 1, (V[]){v_st_241411}));
          switch (heff_tag_of(v_x1_241415)) {
          case TAG_MkPair: {
            V v_x11_241416 = heff_field(v_x1_241415, 0);
            V v_st_241417 = heff_field(v_x1_241415, 1);
            heff_take_n(v_x1_241415, 3ULL, 2);
            switch (heff_tag_of(v_x11_241416)) {
            case TAG_Left: {
              V v_e_241418 = heff_field(v_x11_241416, 0);
              heff_take_n(v_x11_241416, 1ULL, 1);
              heff_drop_rec(v_r_240, 3);
              heff_drop_rec(v_kw_24794, 9);
              heff_drop(v_b_24799);
              heff_drop(v_x_241413);
              return heff_tag_at_n(v_ru_24x1_241409_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241418}), v_st_241417});
            }
            case TAG_Right: {
              V v_x_241419 = heff_field(v_x11_241416, 0);
              heff_take_n(v_x11_241416, 1ULL, 1);
              V v_m_241420 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_b_24799)}));
              V v_x1_241421 = heff_tr(heff_call(v_m_241420, 1, (V[]){v_st_241417}));
              switch (heff_tag_of(v_x1_241421)) {
              case TAG_MkPair: {
                V v_x11_241422 = heff_field(v_x1_241421, 0);
                V v_st_241423 = heff_field(v_x1_241421, 1);
                heff_take_n(v_x1_241421, 3ULL, 2);
                switch (heff_tag_of(v_x11_241422)) {
                case TAG_Left: {
                  V v_e_241424 = heff_field(v_x11_241422, 0);
                  heff_take_n(v_x11_241422, 1ULL, 1);
                  heff_drop_rec(v_kw_24794, 9);
                  heff_drop(v_b_24799);
                  heff_drop(v_x_241413);
                  heff_drop(v_x_241419);
                  return heff_tag_at_n(v_ru_24x1_241409_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241424}), v_st_241423});
                }
                case TAG_Right: {
                  V v_x_241425 = heff_field(v_x11_241422, 0);
                  heff_take_n(v_x11_241422, 1ULL, 1);
                  V v_t_241426 = (g_heff_2esyntax_2ecst_2elastE(v_b_24799));
                  V v_e_241427 = heff_get_n(v_t_241426, 4, 9);
                  V v_t_241428 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_24794, 3, 9), v_e_241427});
                  V v_x_241429 = (g_heff_2esyntax_2esurface_2eifE(v_t_241428, v_x_241413, v_x_241419, v_x_241425));
                  return heff_tag_at_n(v_ru_24x1_241409_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_241429}), v_st_241423});
                }
                default: return heff_nomatch(v_x11_241422);
                }
              }
              default: return heff_nomatch(v_x1_241421);
              }
            }
            default: return heff_nomatch(v_x11_241416);
            }
          }
          default: return heff_nomatch(v_x1_241415);
          }
        }
        default: return heff_nomatch(v_x11_241410);
        }
      }
      default: return heff_nomatch(v_x1_241409);
      }
    }
    case TAG_EAlt: {
      V v_m_241433 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_24795}));
      V v_x1_241434 = heff_tr(heff_call(v_m_241433, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_241434)) {
      case TAG_MkPair: {
        V v_x11_241435 = heff_field(v_x1_241434, 0);
        V v_st_241436 = heff_field(v_x1_241434, 1);
        V v_ru_24x1_241434_24MkPair = heff_take_reuse_n(v_x1_241434, 3ULL, 2);
        switch (heff_tag_of(v_x11_241435)) {
        case TAG_Left: {
          V v_e_241437 = heff_field(v_x11_241435, 0);
          heff_take_n(v_x11_241435, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_24794, 9);
          heff_drop(v_a_24797);
          heff_drop(v_b_24799);
          return heff_tag_at_n(v_ru_24x1_241434_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241437}), v_st_241436});
        }
        case TAG_Right: {
          V v_x_241438 = heff_field(v_x11_241435, 0);
          heff_take_n(v_x11_241435, 1ULL, 1);
          V v_m_241439 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_24797}));
          V v_x1_241440 = heff_tr(heff_call(v_m_241439, 1, (V[]){v_st_241436}));
          switch (heff_tag_of(v_x1_241440)) {
          case TAG_MkPair: {
            V v_x11_241441 = heff_field(v_x1_241440, 0);
            V v_st_241442 = heff_field(v_x1_241440, 1);
            heff_take_n(v_x1_241440, 3ULL, 2);
            switch (heff_tag_of(v_x11_241441)) {
            case TAG_Left: {
              V v_e_241443 = heff_field(v_x11_241441, 0);
              heff_take_n(v_x11_241441, 1ULL, 1);
              heff_drop_rec(v_r_240, 3);
              heff_drop_rec(v_kw_24794, 9);
              heff_drop(v_b_24799);
              heff_drop(v_x_241438);
              return heff_tag_at_n(v_ru_24x1_241434_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241443}), v_st_241442});
            }
            case TAG_Right: {
              V v_x_241444 = heff_field(v_x11_241441, 0);
              heff_take_n(v_x11_241441, 1ULL, 1);
              V v_m_241445 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_b_24799)}));
              V v_x1_241446 = heff_tr(heff_call(v_m_241445, 1, (V[]){v_st_241442}));
              switch (heff_tag_of(v_x1_241446)) {
              case TAG_MkPair: {
                V v_x11_241447 = heff_field(v_x1_241446, 0);
                V v_st_241448 = heff_field(v_x1_241446, 1);
                heff_take_n(v_x1_241446, 3ULL, 2);
                switch (heff_tag_of(v_x11_241447)) {
                case TAG_Left: {
                  V v_e_241449 = heff_field(v_x11_241447, 0);
                  heff_take_n(v_x11_241447, 1ULL, 1);
                  heff_drop_rec(v_kw_24794, 9);
                  heff_drop(v_b_24799);
                  heff_drop(v_x_241438);
                  heff_drop(v_x_241444);
                  return heff_tag_at_n(v_ru_24x1_241434_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241449}), v_st_241448});
                }
                case TAG_Right: {
                  V v_x_241450 = heff_field(v_x11_241447, 0);
                  heff_take_n(v_x11_241447, 1ULL, 1);
                  V v_t_241451 = (g_heff_2esyntax_2ecst_2elastE(v_b_24799));
                  V v_e_241452 = heff_get_n(v_t_241451, 4, 9);
                  V v_t_241453 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_24794, 3, 9), v_e_241452});
                  V v_x_241454 = (g_heff_2esyntax_2esurface_2eifE(v_t_241453, v_x_241438, v_x_241444, v_x_241450));
                  return heff_tag_at_n(v_ru_24x1_241434_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_241454}), v_st_241448});
                }
                default: return heff_nomatch(v_x11_241447);
                }
              }
              default: return heff_nomatch(v_x1_241446);
              }
            }
            default: return heff_nomatch(v_x11_241441);
            }
          }
          default: return heff_nomatch(v_x1_241440);
          }
        }
        default: return heff_nomatch(v_x11_241435);
        }
      }
      default: return heff_nomatch(v_x1_241434);
      }
    }
    case TAG_If: {
      V v_m_241461 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_24795}));
      V v_x1_241462 = heff_tr(heff_call(v_m_241461, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_241462)) {
      case TAG_MkPair: {
        V v_x11_241463 = heff_field(v_x1_241462, 0);
        V v_st_241464 = heff_field(v_x1_241462, 1);
        V v_ru_24x1_241462_24MkPair = heff_take_reuse_n(v_x1_241462, 3ULL, 2);
        switch (heff_tag_of(v_x11_241463)) {
        case TAG_Left: {
          V v_e_241465 = heff_field(v_x11_241463, 0);
          heff_take_n(v_x11_241463, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_24794, 9);
          heff_drop(v_a_24797);
          heff_drop(v_b_24799);
          return heff_tag_at_n(v_ru_24x1_241462_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241465}), v_st_241464});
        }
        case TAG_Right: {
          V v_x_241466 = heff_field(v_x11_241463, 0);
          heff_take_n(v_x11_241463, 1ULL, 1);
          V v_m_241467 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_24797}));
          V v_x1_241468 = heff_tr(heff_call(v_m_241467, 1, (V[]){v_st_241464}));
          switch (heff_tag_of(v_x1_241468)) {
          case TAG_MkPair: {
            V v_x11_241469 = heff_field(v_x1_241468, 0);
            V v_st_241470 = heff_field(v_x1_241468, 1);
            heff_take_n(v_x1_241468, 3ULL, 2);
            switch (heff_tag_of(v_x11_241469)) {
            case TAG_Left: {
              V v_e_241471 = heff_field(v_x11_241469, 0);
              heff_take_n(v_x11_241469, 1ULL, 1);
              heff_drop_rec(v_r_240, 3);
              heff_drop_rec(v_kw_24794, 9);
              heff_drop(v_b_24799);
              heff_drop(v_x_241466);
              return heff_tag_at_n(v_ru_24x1_241462_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241471}), v_st_241470});
            }
            case TAG_Right: {
              V v_x_241472 = heff_field(v_x11_241469, 0);
              heff_take_n(v_x11_241469, 1ULL, 1);
              V v_m_241473 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_b_24799)}));
              V v_x1_241474 = heff_tr(heff_call(v_m_241473, 1, (V[]){v_st_241470}));
              switch (heff_tag_of(v_x1_241474)) {
              case TAG_MkPair: {
                V v_x11_241475 = heff_field(v_x1_241474, 0);
                V v_st_241476 = heff_field(v_x1_241474, 1);
                heff_take_n(v_x1_241474, 3ULL, 2);
                switch (heff_tag_of(v_x11_241475)) {
                case TAG_Left: {
                  V v_e_241477 = heff_field(v_x11_241475, 0);
                  heff_take_n(v_x11_241475, 1ULL, 1);
                  heff_drop_rec(v_kw_24794, 9);
                  heff_drop(v_b_24799);
                  heff_drop(v_x_241466);
                  heff_drop(v_x_241472);
                  return heff_tag_at_n(v_ru_24x1_241462_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241477}), v_st_241476});
                }
                case TAG_Right: {
                  V v_x_241478 = heff_field(v_x11_241475, 0);
                  heff_take_n(v_x11_241475, 1ULL, 1);
                  V v_t_241479 = (g_heff_2esyntax_2ecst_2elastE(v_b_24799));
                  V v_e_241480 = heff_get_n(v_t_241479, 4, 9);
                  V v_t_241481 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_24794, 3, 9), v_e_241480});
                  V v_x_241482 = (g_heff_2esyntax_2esurface_2eifE(v_t_241481, v_x_241466, v_x_241472, v_x_241478));
                  return heff_tag_at_n(v_ru_24x1_241462_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_241482}), v_st_241476});
                }
                default: return heff_nomatch(v_x11_241475);
                }
              }
              default: return heff_nomatch(v_x1_241474);
              }
            }
            default: return heff_nomatch(v_x11_241469);
            }
          }
          default: return heff_nomatch(v_x1_241468);
          }
        }
        default: return heff_nomatch(v_x11_241463);
        }
      }
      default: return heff_nomatch(v_x1_241462);
      }
    }
    case TAG_Do: {
      V v_m_241485 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_24795}));
      V v_x1_241486 = heff_tr(heff_call(v_m_241485, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_241486)) {
      case TAG_MkPair: {
        V v_x11_241487 = heff_field(v_x1_241486, 0);
        V v_st_241488 = heff_field(v_x1_241486, 1);
        V v_ru_24x1_241486_24MkPair = heff_take_reuse_n(v_x1_241486, 3ULL, 2);
        switch (heff_tag_of(v_x11_241487)) {
        case TAG_Left: {
          V v_e_241489 = heff_field(v_x11_241487, 0);
          heff_take_n(v_x11_241487, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_24794, 9);
          heff_drop(v_a_24797);
          heff_drop(v_b_24799);
          return heff_tag_at_n(v_ru_24x1_241486_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241489}), v_st_241488});
        }
        case TAG_Right: {
          V v_x_241490 = heff_field(v_x11_241487, 0);
          heff_take_n(v_x11_241487, 1ULL, 1);
          V v_m_241491 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_24797}));
          V v_x1_241492 = heff_tr(heff_call(v_m_241491, 1, (V[]){v_st_241488}));
          switch (heff_tag_of(v_x1_241492)) {
          case TAG_MkPair: {
            V v_x11_241493 = heff_field(v_x1_241492, 0);
            V v_st_241494 = heff_field(v_x1_241492, 1);
            heff_take_n(v_x1_241492, 3ULL, 2);
            switch (heff_tag_of(v_x11_241493)) {
            case TAG_Left: {
              V v_e_241495 = heff_field(v_x11_241493, 0);
              heff_take_n(v_x11_241493, 1ULL, 1);
              heff_drop_rec(v_r_240, 3);
              heff_drop_rec(v_kw_24794, 9);
              heff_drop(v_b_24799);
              heff_drop(v_x_241490);
              return heff_tag_at_n(v_ru_24x1_241486_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241495}), v_st_241494});
            }
            case TAG_Right: {
              V v_x_241496 = heff_field(v_x11_241493, 0);
              heff_take_n(v_x11_241493, 1ULL, 1);
              V v_m_241497 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_b_24799)}));
              V v_x1_241498 = heff_tr(heff_call(v_m_241497, 1, (V[]){v_st_241494}));
              switch (heff_tag_of(v_x1_241498)) {
              case TAG_MkPair: {
                V v_x11_241499 = heff_field(v_x1_241498, 0);
                V v_st_241500 = heff_field(v_x1_241498, 1);
                heff_take_n(v_x1_241498, 3ULL, 2);
                switch (heff_tag_of(v_x11_241499)) {
                case TAG_Left: {
                  V v_e_241501 = heff_field(v_x11_241499, 0);
                  heff_take_n(v_x11_241499, 1ULL, 1);
                  heff_drop_rec(v_kw_24794, 9);
                  heff_drop(v_b_24799);
                  heff_drop(v_x_241490);
                  heff_drop(v_x_241496);
                  return heff_tag_at_n(v_ru_24x1_241486_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241501}), v_st_241500});
                }
                case TAG_Right: {
                  V v_x_241502 = heff_field(v_x11_241499, 0);
                  heff_take_n(v_x11_241499, 1ULL, 1);
                  V v_t_241503 = (g_heff_2esyntax_2ecst_2elastE(v_b_24799));
                  V v_e_241504 = heff_get_n(v_t_241503, 4, 9);
                  V v_t_241505 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_24794, 3, 9), v_e_241504});
                  V v_x_241506 = (g_heff_2esyntax_2esurface_2eifE(v_t_241505, v_x_241490, v_x_241496, v_x_241502));
                  return heff_tag_at_n(v_ru_24x1_241486_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_241506}), v_st_241500});
                }
                default: return heff_nomatch(v_x11_241499);
                }
              }
              default: return heff_nomatch(v_x1_241498);
              }
            }
            default: return heff_nomatch(v_x11_241493);
            }
          }
          default: return heff_nomatch(v_x1_241492);
          }
        }
        default: return heff_nomatch(v_x11_241487);
        }
      }
      default: return heff_nomatch(v_x1_241486);
      }
    }
    case TAG_ESBind: {
      V v_m_241510 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_24795}));
      V v_x1_241511 = heff_tr(heff_call(v_m_241510, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_241511)) {
      case TAG_MkPair: {
        V v_x11_241512 = heff_field(v_x1_241511, 0);
        V v_st_241513 = heff_field(v_x1_241511, 1);
        V v_ru_24x1_241511_24MkPair = heff_take_reuse_n(v_x1_241511, 3ULL, 2);
        switch (heff_tag_of(v_x11_241512)) {
        case TAG_Left: {
          V v_e_241514 = heff_field(v_x11_241512, 0);
          heff_take_n(v_x11_241512, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_24794, 9);
          heff_drop(v_a_24797);
          heff_drop(v_b_24799);
          return heff_tag_at_n(v_ru_24x1_241511_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241514}), v_st_241513});
        }
        case TAG_Right: {
          V v_x_241515 = heff_field(v_x11_241512, 0);
          heff_take_n(v_x11_241512, 1ULL, 1);
          V v_m_241516 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_24797}));
          V v_x1_241517 = heff_tr(heff_call(v_m_241516, 1, (V[]){v_st_241513}));
          switch (heff_tag_of(v_x1_241517)) {
          case TAG_MkPair: {
            V v_x11_241518 = heff_field(v_x1_241517, 0);
            V v_st_241519 = heff_field(v_x1_241517, 1);
            heff_take_n(v_x1_241517, 3ULL, 2);
            switch (heff_tag_of(v_x11_241518)) {
            case TAG_Left: {
              V v_e_241520 = heff_field(v_x11_241518, 0);
              heff_take_n(v_x11_241518, 1ULL, 1);
              heff_drop_rec(v_r_240, 3);
              heff_drop_rec(v_kw_24794, 9);
              heff_drop(v_b_24799);
              heff_drop(v_x_241515);
              return heff_tag_at_n(v_ru_24x1_241511_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241520}), v_st_241519});
            }
            case TAG_Right: {
              V v_x_241521 = heff_field(v_x11_241518, 0);
              heff_take_n(v_x11_241518, 1ULL, 1);
              V v_m_241522 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_b_24799)}));
              V v_x1_241523 = heff_tr(heff_call(v_m_241522, 1, (V[]){v_st_241519}));
              switch (heff_tag_of(v_x1_241523)) {
              case TAG_MkPair: {
                V v_x11_241524 = heff_field(v_x1_241523, 0);
                V v_st_241525 = heff_field(v_x1_241523, 1);
                heff_take_n(v_x1_241523, 3ULL, 2);
                switch (heff_tag_of(v_x11_241524)) {
                case TAG_Left: {
                  V v_e_241526 = heff_field(v_x11_241524, 0);
                  heff_take_n(v_x11_241524, 1ULL, 1);
                  heff_drop_rec(v_kw_24794, 9);
                  heff_drop(v_b_24799);
                  heff_drop(v_x_241515);
                  heff_drop(v_x_241521);
                  return heff_tag_at_n(v_ru_24x1_241511_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241526}), v_st_241525});
                }
                case TAG_Right: {
                  V v_x_241527 = heff_field(v_x11_241524, 0);
                  heff_take_n(v_x11_241524, 1ULL, 1);
                  V v_t_241528 = (g_heff_2esyntax_2ecst_2elastE(v_b_24799));
                  V v_e_241529 = heff_get_n(v_t_241528, 4, 9);
                  V v_t_241530 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_24794, 3, 9), v_e_241529});
                  V v_x_241531 = (g_heff_2esyntax_2esurface_2eifE(v_t_241530, v_x_241515, v_x_241521, v_x_241527));
                  return heff_tag_at_n(v_ru_24x1_241511_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_241531}), v_st_241525});
                }
                default: return heff_nomatch(v_x11_241524);
                }
              }
              default: return heff_nomatch(v_x1_241523);
              }
            }
            default: return heff_nomatch(v_x11_241518);
            }
          }
          default: return heff_nomatch(v_x1_241517);
          }
        }
        default: return heff_nomatch(v_x11_241512);
        }
      }
      default: return heff_nomatch(v_x1_241511);
      }
    }
    case TAG_ELet: {
      V v_m_241538 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_24795}));
      V v_x1_241539 = heff_tr(heff_call(v_m_241538, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_241539)) {
      case TAG_MkPair: {
        V v_x11_241540 = heff_field(v_x1_241539, 0);
        V v_st_241541 = heff_field(v_x1_241539, 1);
        V v_ru_24x1_241539_24MkPair = heff_take_reuse_n(v_x1_241539, 3ULL, 2);
        switch (heff_tag_of(v_x11_241540)) {
        case TAG_Left: {
          V v_e_241542 = heff_field(v_x11_241540, 0);
          heff_take_n(v_x11_241540, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_24794, 9);
          heff_drop(v_a_24797);
          heff_drop(v_b_24799);
          return heff_tag_at_n(v_ru_24x1_241539_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241542}), v_st_241541});
        }
        case TAG_Right: {
          V v_x_241543 = heff_field(v_x11_241540, 0);
          heff_take_n(v_x11_241540, 1ULL, 1);
          V v_m_241544 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_24797}));
          V v_x1_241545 = heff_tr(heff_call(v_m_241544, 1, (V[]){v_st_241541}));
          switch (heff_tag_of(v_x1_241545)) {
          case TAG_MkPair: {
            V v_x11_241546 = heff_field(v_x1_241545, 0);
            V v_st_241547 = heff_field(v_x1_241545, 1);
            heff_take_n(v_x1_241545, 3ULL, 2);
            switch (heff_tag_of(v_x11_241546)) {
            case TAG_Left: {
              V v_e_241548 = heff_field(v_x11_241546, 0);
              heff_take_n(v_x11_241546, 1ULL, 1);
              heff_drop_rec(v_r_240, 3);
              heff_drop_rec(v_kw_24794, 9);
              heff_drop(v_b_24799);
              heff_drop(v_x_241543);
              return heff_tag_at_n(v_ru_24x1_241539_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241548}), v_st_241547});
            }
            case TAG_Right: {
              V v_x_241549 = heff_field(v_x11_241546, 0);
              heff_take_n(v_x11_241546, 1ULL, 1);
              V v_m_241550 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_b_24799)}));
              V v_x1_241551 = heff_tr(heff_call(v_m_241550, 1, (V[]){v_st_241547}));
              switch (heff_tag_of(v_x1_241551)) {
              case TAG_MkPair: {
                V v_x11_241552 = heff_field(v_x1_241551, 0);
                V v_st_241553 = heff_field(v_x1_241551, 1);
                heff_take_n(v_x1_241551, 3ULL, 2);
                switch (heff_tag_of(v_x11_241552)) {
                case TAG_Left: {
                  V v_e_241554 = heff_field(v_x11_241552, 0);
                  heff_take_n(v_x11_241552, 1ULL, 1);
                  heff_drop_rec(v_kw_24794, 9);
                  heff_drop(v_b_24799);
                  heff_drop(v_x_241543);
                  heff_drop(v_x_241549);
                  return heff_tag_at_n(v_ru_24x1_241539_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241554}), v_st_241553});
                }
                case TAG_Right: {
                  V v_x_241555 = heff_field(v_x11_241552, 0);
                  heff_take_n(v_x11_241552, 1ULL, 1);
                  V v_t_241556 = (g_heff_2esyntax_2ecst_2elastE(v_b_24799));
                  V v_e_241557 = heff_get_n(v_t_241556, 4, 9);
                  V v_t_241558 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_24794, 3, 9), v_e_241557});
                  V v_x_241559 = (g_heff_2esyntax_2esurface_2eifE(v_t_241558, v_x_241543, v_x_241549, v_x_241555));
                  return heff_tag_at_n(v_ru_24x1_241539_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_241559}), v_st_241553});
                }
                default: return heff_nomatch(v_x11_241552);
                }
              }
              default: return heff_nomatch(v_x1_241551);
              }
            }
            default: return heff_nomatch(v_x11_241546);
            }
          }
          default: return heff_nomatch(v_x1_241545);
          }
        }
        default: return heff_nomatch(v_x11_241540);
        }
      }
      default: return heff_nomatch(v_x1_241539);
      }
    }
    case TAG_ELetMut: {
      V v_m_241566 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_24795}));
      V v_x1_241567 = heff_tr(heff_call(v_m_241566, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_241567)) {
      case TAG_MkPair: {
        V v_x11_241568 = heff_field(v_x1_241567, 0);
        V v_st_241569 = heff_field(v_x1_241567, 1);
        V v_ru_24x1_241567_24MkPair = heff_take_reuse_n(v_x1_241567, 3ULL, 2);
        switch (heff_tag_of(v_x11_241568)) {
        case TAG_Left: {
          V v_e_241570 = heff_field(v_x11_241568, 0);
          heff_take_n(v_x11_241568, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_24794, 9);
          heff_drop(v_a_24797);
          heff_drop(v_b_24799);
          return heff_tag_at_n(v_ru_24x1_241567_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241570}), v_st_241569});
        }
        case TAG_Right: {
          V v_x_241571 = heff_field(v_x11_241568, 0);
          heff_take_n(v_x11_241568, 1ULL, 1);
          V v_m_241572 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_24797}));
          V v_x1_241573 = heff_tr(heff_call(v_m_241572, 1, (V[]){v_st_241569}));
          switch (heff_tag_of(v_x1_241573)) {
          case TAG_MkPair: {
            V v_x11_241574 = heff_field(v_x1_241573, 0);
            V v_st_241575 = heff_field(v_x1_241573, 1);
            heff_take_n(v_x1_241573, 3ULL, 2);
            switch (heff_tag_of(v_x11_241574)) {
            case TAG_Left: {
              V v_e_241576 = heff_field(v_x11_241574, 0);
              heff_take_n(v_x11_241574, 1ULL, 1);
              heff_drop_rec(v_r_240, 3);
              heff_drop_rec(v_kw_24794, 9);
              heff_drop(v_b_24799);
              heff_drop(v_x_241571);
              return heff_tag_at_n(v_ru_24x1_241567_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241576}), v_st_241575});
            }
            case TAG_Right: {
              V v_x_241577 = heff_field(v_x11_241574, 0);
              heff_take_n(v_x11_241574, 1ULL, 1);
              V v_m_241578 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_b_24799)}));
              V v_x1_241579 = heff_tr(heff_call(v_m_241578, 1, (V[]){v_st_241575}));
              switch (heff_tag_of(v_x1_241579)) {
              case TAG_MkPair: {
                V v_x11_241580 = heff_field(v_x1_241579, 0);
                V v_st_241581 = heff_field(v_x1_241579, 1);
                heff_take_n(v_x1_241579, 3ULL, 2);
                switch (heff_tag_of(v_x11_241580)) {
                case TAG_Left: {
                  V v_e_241582 = heff_field(v_x11_241580, 0);
                  heff_take_n(v_x11_241580, 1ULL, 1);
                  heff_drop_rec(v_kw_24794, 9);
                  heff_drop(v_b_24799);
                  heff_drop(v_x_241571);
                  heff_drop(v_x_241577);
                  return heff_tag_at_n(v_ru_24x1_241567_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241582}), v_st_241581});
                }
                case TAG_Right: {
                  V v_x_241583 = heff_field(v_x11_241580, 0);
                  heff_take_n(v_x11_241580, 1ULL, 1);
                  V v_t_241584 = (g_heff_2esyntax_2ecst_2elastE(v_b_24799));
                  V v_e_241585 = heff_get_n(v_t_241584, 4, 9);
                  V v_t_241586 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_24794, 3, 9), v_e_241585});
                  V v_x_241587 = (g_heff_2esyntax_2esurface_2eifE(v_t_241586, v_x_241571, v_x_241577, v_x_241583));
                  return heff_tag_at_n(v_ru_24x1_241567_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_241587}), v_st_241581});
                }
                default: return heff_nomatch(v_x11_241580);
                }
              }
              default: return heff_nomatch(v_x1_241579);
              }
            }
            default: return heff_nomatch(v_x11_241574);
            }
          }
          default: return heff_nomatch(v_x1_241573);
          }
        }
        default: return heff_nomatch(v_x11_241568);
        }
      }
      default: return heff_nomatch(v_x1_241567);
      }
    }
    case TAG_EAssign: {
      V v_m_241591 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_24795}));
      V v_x1_241592 = heff_tr(heff_call(v_m_241591, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_241592)) {
      case TAG_MkPair: {
        V v_x11_241593 = heff_field(v_x1_241592, 0);
        V v_st_241594 = heff_field(v_x1_241592, 1);
        V v_ru_24x1_241592_24MkPair = heff_take_reuse_n(v_x1_241592, 3ULL, 2);
        switch (heff_tag_of(v_x11_241593)) {
        case TAG_Left: {
          V v_e_241595 = heff_field(v_x11_241593, 0);
          heff_take_n(v_x11_241593, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_24794, 9);
          heff_drop(v_a_24797);
          heff_drop(v_b_24799);
          return heff_tag_at_n(v_ru_24x1_241592_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241595}), v_st_241594});
        }
        case TAG_Right: {
          V v_x_241596 = heff_field(v_x11_241593, 0);
          heff_take_n(v_x11_241593, 1ULL, 1);
          V v_m_241597 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_24797}));
          V v_x1_241598 = heff_tr(heff_call(v_m_241597, 1, (V[]){v_st_241594}));
          switch (heff_tag_of(v_x1_241598)) {
          case TAG_MkPair: {
            V v_x11_241599 = heff_field(v_x1_241598, 0);
            V v_st_241600 = heff_field(v_x1_241598, 1);
            heff_take_n(v_x1_241598, 3ULL, 2);
            switch (heff_tag_of(v_x11_241599)) {
            case TAG_Left: {
              V v_e_241601 = heff_field(v_x11_241599, 0);
              heff_take_n(v_x11_241599, 1ULL, 1);
              heff_drop_rec(v_r_240, 3);
              heff_drop_rec(v_kw_24794, 9);
              heff_drop(v_b_24799);
              heff_drop(v_x_241596);
              return heff_tag_at_n(v_ru_24x1_241592_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241601}), v_st_241600});
            }
            case TAG_Right: {
              V v_x_241602 = heff_field(v_x11_241599, 0);
              heff_take_n(v_x11_241599, 1ULL, 1);
              V v_m_241603 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_b_24799)}));
              V v_x1_241604 = heff_tr(heff_call(v_m_241603, 1, (V[]){v_st_241600}));
              switch (heff_tag_of(v_x1_241604)) {
              case TAG_MkPair: {
                V v_x11_241605 = heff_field(v_x1_241604, 0);
                V v_st_241606 = heff_field(v_x1_241604, 1);
                heff_take_n(v_x1_241604, 3ULL, 2);
                switch (heff_tag_of(v_x11_241605)) {
                case TAG_Left: {
                  V v_e_241607 = heff_field(v_x11_241605, 0);
                  heff_take_n(v_x11_241605, 1ULL, 1);
                  heff_drop_rec(v_kw_24794, 9);
                  heff_drop(v_b_24799);
                  heff_drop(v_x_241596);
                  heff_drop(v_x_241602);
                  return heff_tag_at_n(v_ru_24x1_241592_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241607}), v_st_241606});
                }
                case TAG_Right: {
                  V v_x_241608 = heff_field(v_x11_241605, 0);
                  heff_take_n(v_x11_241605, 1ULL, 1);
                  V v_t_241609 = (g_heff_2esyntax_2ecst_2elastE(v_b_24799));
                  V v_e_241610 = heff_get_n(v_t_241609, 4, 9);
                  V v_t_241611 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_24794, 3, 9), v_e_241610});
                  V v_x_241612 = (g_heff_2esyntax_2esurface_2eifE(v_t_241611, v_x_241596, v_x_241602, v_x_241608));
                  return heff_tag_at_n(v_ru_24x1_241592_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_241612}), v_st_241606});
                }
                default: return heff_nomatch(v_x11_241605);
                }
              }
              default: return heff_nomatch(v_x1_241604);
              }
            }
            default: return heff_nomatch(v_x11_241599);
            }
          }
          default: return heff_nomatch(v_x1_241598);
          }
        }
        default: return heff_nomatch(v_x11_241593);
        }
      }
      default: return heff_nomatch(v_x1_241592);
      }
    }
    case TAG_EWhile: {
      V v_m_241617 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_24795}));
      V v_x1_241618 = heff_tr(heff_call(v_m_241617, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_241618)) {
      case TAG_MkPair: {
        V v_x11_241619 = heff_field(v_x1_241618, 0);
        V v_st_241620 = heff_field(v_x1_241618, 1);
        V v_ru_24x1_241618_24MkPair = heff_take_reuse_n(v_x1_241618, 3ULL, 2);
        switch (heff_tag_of(v_x11_241619)) {
        case TAG_Left: {
          V v_e_241621 = heff_field(v_x11_241619, 0);
          heff_take_n(v_x11_241619, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_24794, 9);
          heff_drop(v_a_24797);
          heff_drop(v_b_24799);
          return heff_tag_at_n(v_ru_24x1_241618_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241621}), v_st_241620});
        }
        case TAG_Right: {
          V v_x_241622 = heff_field(v_x11_241619, 0);
          heff_take_n(v_x11_241619, 1ULL, 1);
          V v_m_241623 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_24797}));
          V v_x1_241624 = heff_tr(heff_call(v_m_241623, 1, (V[]){v_st_241620}));
          switch (heff_tag_of(v_x1_241624)) {
          case TAG_MkPair: {
            V v_x11_241625 = heff_field(v_x1_241624, 0);
            V v_st_241626 = heff_field(v_x1_241624, 1);
            heff_take_n(v_x1_241624, 3ULL, 2);
            switch (heff_tag_of(v_x11_241625)) {
            case TAG_Left: {
              V v_e_241627 = heff_field(v_x11_241625, 0);
              heff_take_n(v_x11_241625, 1ULL, 1);
              heff_drop_rec(v_r_240, 3);
              heff_drop_rec(v_kw_24794, 9);
              heff_drop(v_b_24799);
              heff_drop(v_x_241622);
              return heff_tag_at_n(v_ru_24x1_241618_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241627}), v_st_241626});
            }
            case TAG_Right: {
              V v_x_241628 = heff_field(v_x11_241625, 0);
              heff_take_n(v_x11_241625, 1ULL, 1);
              V v_m_241629 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_b_24799)}));
              V v_x1_241630 = heff_tr(heff_call(v_m_241629, 1, (V[]){v_st_241626}));
              switch (heff_tag_of(v_x1_241630)) {
              case TAG_MkPair: {
                V v_x11_241631 = heff_field(v_x1_241630, 0);
                V v_st_241632 = heff_field(v_x1_241630, 1);
                heff_take_n(v_x1_241630, 3ULL, 2);
                switch (heff_tag_of(v_x11_241631)) {
                case TAG_Left: {
                  V v_e_241633 = heff_field(v_x11_241631, 0);
                  heff_take_n(v_x11_241631, 1ULL, 1);
                  heff_drop_rec(v_kw_24794, 9);
                  heff_drop(v_b_24799);
                  heff_drop(v_x_241622);
                  heff_drop(v_x_241628);
                  return heff_tag_at_n(v_ru_24x1_241618_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241633}), v_st_241632});
                }
                case TAG_Right: {
                  V v_x_241634 = heff_field(v_x11_241631, 0);
                  heff_take_n(v_x11_241631, 1ULL, 1);
                  V v_t_241635 = (g_heff_2esyntax_2ecst_2elastE(v_b_24799));
                  V v_e_241636 = heff_get_n(v_t_241635, 4, 9);
                  V v_t_241637 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_24794, 3, 9), v_e_241636});
                  V v_x_241638 = (g_heff_2esyntax_2esurface_2eifE(v_t_241637, v_x_241622, v_x_241628, v_x_241634));
                  return heff_tag_at_n(v_ru_24x1_241618_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_241638}), v_st_241632});
                }
                default: return heff_nomatch(v_x11_241631);
                }
              }
              default: return heff_nomatch(v_x1_241630);
              }
            }
            default: return heff_nomatch(v_x11_241625);
            }
          }
          default: return heff_nomatch(v_x1_241624);
          }
        }
        default: return heff_nomatch(v_x11_241619);
        }
      }
      default: return heff_nomatch(v_x1_241618);
      }
    }
    case TAG_EFor: {
      V v_m_241645 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_24795}));
      V v_x1_241646 = heff_tr(heff_call(v_m_241645, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_241646)) {
      case TAG_MkPair: {
        V v_x11_241647 = heff_field(v_x1_241646, 0);
        V v_st_241648 = heff_field(v_x1_241646, 1);
        V v_ru_24x1_241646_24MkPair = heff_take_reuse_n(v_x1_241646, 3ULL, 2);
        switch (heff_tag_of(v_x11_241647)) {
        case TAG_Left: {
          V v_e_241649 = heff_field(v_x11_241647, 0);
          heff_take_n(v_x11_241647, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_24794, 9);
          heff_drop(v_a_24797);
          heff_drop(v_b_24799);
          return heff_tag_at_n(v_ru_24x1_241646_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241649}), v_st_241648});
        }
        case TAG_Right: {
          V v_x_241650 = heff_field(v_x11_241647, 0);
          heff_take_n(v_x11_241647, 1ULL, 1);
          V v_m_241651 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_24797}));
          V v_x1_241652 = heff_tr(heff_call(v_m_241651, 1, (V[]){v_st_241648}));
          switch (heff_tag_of(v_x1_241652)) {
          case TAG_MkPair: {
            V v_x11_241653 = heff_field(v_x1_241652, 0);
            V v_st_241654 = heff_field(v_x1_241652, 1);
            heff_take_n(v_x1_241652, 3ULL, 2);
            switch (heff_tag_of(v_x11_241653)) {
            case TAG_Left: {
              V v_e_241655 = heff_field(v_x11_241653, 0);
              heff_take_n(v_x11_241653, 1ULL, 1);
              heff_drop_rec(v_r_240, 3);
              heff_drop_rec(v_kw_24794, 9);
              heff_drop(v_b_24799);
              heff_drop(v_x_241650);
              return heff_tag_at_n(v_ru_24x1_241646_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241655}), v_st_241654});
            }
            case TAG_Right: {
              V v_x_241656 = heff_field(v_x11_241653, 0);
              heff_take_n(v_x11_241653, 1ULL, 1);
              V v_m_241657 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_b_24799)}));
              V v_x1_241658 = heff_tr(heff_call(v_m_241657, 1, (V[]){v_st_241654}));
              switch (heff_tag_of(v_x1_241658)) {
              case TAG_MkPair: {
                V v_x11_241659 = heff_field(v_x1_241658, 0);
                V v_st_241660 = heff_field(v_x1_241658, 1);
                heff_take_n(v_x1_241658, 3ULL, 2);
                switch (heff_tag_of(v_x11_241659)) {
                case TAG_Left: {
                  V v_e_241661 = heff_field(v_x11_241659, 0);
                  heff_take_n(v_x11_241659, 1ULL, 1);
                  heff_drop_rec(v_kw_24794, 9);
                  heff_drop(v_b_24799);
                  heff_drop(v_x_241650);
                  heff_drop(v_x_241656);
                  return heff_tag_at_n(v_ru_24x1_241646_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241661}), v_st_241660});
                }
                case TAG_Right: {
                  V v_x_241662 = heff_field(v_x11_241659, 0);
                  heff_take_n(v_x11_241659, 1ULL, 1);
                  V v_t_241663 = (g_heff_2esyntax_2ecst_2elastE(v_b_24799));
                  V v_e_241664 = heff_get_n(v_t_241663, 4, 9);
                  V v_t_241665 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_24794, 3, 9), v_e_241664});
                  V v_x_241666 = (g_heff_2esyntax_2esurface_2eifE(v_t_241665, v_x_241650, v_x_241656, v_x_241662));
                  return heff_tag_at_n(v_ru_24x1_241646_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_241666}), v_st_241660});
                }
                default: return heff_nomatch(v_x11_241659);
                }
              }
              default: return heff_nomatch(v_x1_241658);
              }
            }
            default: return heff_nomatch(v_x11_241653);
            }
          }
          default: return heff_nomatch(v_x1_241652);
          }
        }
        default: return heff_nomatch(v_x11_241647);
        }
      }
      default: return heff_nomatch(v_x1_241646);
      }
    }
    case TAG_EJump: {
      V v_m_241668 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_24795}));
      V v_x1_241669 = heff_tr(heff_call(v_m_241668, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_241669)) {
      case TAG_MkPair: {
        V v_x11_241670 = heff_field(v_x1_241669, 0);
        V v_st_241671 = heff_field(v_x1_241669, 1);
        V v_ru_24x1_241669_24MkPair = heff_take_reuse_n(v_x1_241669, 3ULL, 2);
        switch (heff_tag_of(v_x11_241670)) {
        case TAG_Left: {
          V v_e_241672 = heff_field(v_x11_241670, 0);
          heff_take_n(v_x11_241670, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_24794, 9);
          heff_drop(v_a_24797);
          heff_drop(v_b_24799);
          return heff_tag_at_n(v_ru_24x1_241669_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241672}), v_st_241671});
        }
        case TAG_Right: {
          V v_x_241673 = heff_field(v_x11_241670, 0);
          heff_take_n(v_x11_241670, 1ULL, 1);
          V v_m_241674 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_24797}));
          V v_x1_241675 = heff_tr(heff_call(v_m_241674, 1, (V[]){v_st_241671}));
          switch (heff_tag_of(v_x1_241675)) {
          case TAG_MkPair: {
            V v_x11_241676 = heff_field(v_x1_241675, 0);
            V v_st_241677 = heff_field(v_x1_241675, 1);
            heff_take_n(v_x1_241675, 3ULL, 2);
            switch (heff_tag_of(v_x11_241676)) {
            case TAG_Left: {
              V v_e_241678 = heff_field(v_x11_241676, 0);
              heff_take_n(v_x11_241676, 1ULL, 1);
              heff_drop_rec(v_r_240, 3);
              heff_drop_rec(v_kw_24794, 9);
              heff_drop(v_b_24799);
              heff_drop(v_x_241673);
              return heff_tag_at_n(v_ru_24x1_241669_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241678}), v_st_241677});
            }
            case TAG_Right: {
              V v_x_241679 = heff_field(v_x11_241676, 0);
              heff_take_n(v_x11_241676, 1ULL, 1);
              V v_m_241680 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_b_24799)}));
              V v_x1_241681 = heff_tr(heff_call(v_m_241680, 1, (V[]){v_st_241677}));
              switch (heff_tag_of(v_x1_241681)) {
              case TAG_MkPair: {
                V v_x11_241682 = heff_field(v_x1_241681, 0);
                V v_st_241683 = heff_field(v_x1_241681, 1);
                heff_take_n(v_x1_241681, 3ULL, 2);
                switch (heff_tag_of(v_x11_241682)) {
                case TAG_Left: {
                  V v_e_241684 = heff_field(v_x11_241682, 0);
                  heff_take_n(v_x11_241682, 1ULL, 1);
                  heff_drop_rec(v_kw_24794, 9);
                  heff_drop(v_b_24799);
                  heff_drop(v_x_241673);
                  heff_drop(v_x_241679);
                  return heff_tag_at_n(v_ru_24x1_241669_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241684}), v_st_241683});
                }
                case TAG_Right: {
                  V v_x_241685 = heff_field(v_x11_241682, 0);
                  heff_take_n(v_x11_241682, 1ULL, 1);
                  V v_t_241686 = (g_heff_2esyntax_2ecst_2elastE(v_b_24799));
                  V v_e_241687 = heff_get_n(v_t_241686, 4, 9);
                  V v_t_241688 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_24794, 3, 9), v_e_241687});
                  V v_x_241689 = (g_heff_2esyntax_2esurface_2eifE(v_t_241688, v_x_241673, v_x_241679, v_x_241685));
                  return heff_tag_at_n(v_ru_24x1_241669_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_241689}), v_st_241683});
                }
                default: return heff_nomatch(v_x11_241682);
                }
              }
              default: return heff_nomatch(v_x1_241681);
              }
            }
            default: return heff_nomatch(v_x11_241676);
            }
          }
          default: return heff_nomatch(v_x1_241675);
          }
        }
        default: return heff_nomatch(v_x11_241670);
        }
      }
      default: return heff_nomatch(v_x1_241669);
      }
    }
    case TAG_EReturn: {
      V v_m_241692 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_24795}));
      V v_x1_241693 = heff_tr(heff_call(v_m_241692, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_241693)) {
      case TAG_MkPair: {
        V v_x11_241694 = heff_field(v_x1_241693, 0);
        V v_st_241695 = heff_field(v_x1_241693, 1);
        V v_ru_24x1_241693_24MkPair = heff_take_reuse_n(v_x1_241693, 3ULL, 2);
        switch (heff_tag_of(v_x11_241694)) {
        case TAG_Left: {
          V v_e_241696 = heff_field(v_x11_241694, 0);
          heff_take_n(v_x11_241694, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_24794, 9);
          heff_drop(v_a_24797);
          heff_drop(v_b_24799);
          return heff_tag_at_n(v_ru_24x1_241693_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241696}), v_st_241695});
        }
        case TAG_Right: {
          V v_x_241697 = heff_field(v_x11_241694, 0);
          heff_take_n(v_x11_241694, 1ULL, 1);
          V v_m_241698 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_24797}));
          V v_x1_241699 = heff_tr(heff_call(v_m_241698, 1, (V[]){v_st_241695}));
          switch (heff_tag_of(v_x1_241699)) {
          case TAG_MkPair: {
            V v_x11_241700 = heff_field(v_x1_241699, 0);
            V v_st_241701 = heff_field(v_x1_241699, 1);
            heff_take_n(v_x1_241699, 3ULL, 2);
            switch (heff_tag_of(v_x11_241700)) {
            case TAG_Left: {
              V v_e_241702 = heff_field(v_x11_241700, 0);
              heff_take_n(v_x11_241700, 1ULL, 1);
              heff_drop_rec(v_r_240, 3);
              heff_drop_rec(v_kw_24794, 9);
              heff_drop(v_b_24799);
              heff_drop(v_x_241697);
              return heff_tag_at_n(v_ru_24x1_241693_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241702}), v_st_241701});
            }
            case TAG_Right: {
              V v_x_241703 = heff_field(v_x11_241700, 0);
              heff_take_n(v_x11_241700, 1ULL, 1);
              V v_m_241704 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_b_24799)}));
              V v_x1_241705 = heff_tr(heff_call(v_m_241704, 1, (V[]){v_st_241701}));
              switch (heff_tag_of(v_x1_241705)) {
              case TAG_MkPair: {
                V v_x11_241706 = heff_field(v_x1_241705, 0);
                V v_st_241707 = heff_field(v_x1_241705, 1);
                heff_take_n(v_x1_241705, 3ULL, 2);
                switch (heff_tag_of(v_x11_241706)) {
                case TAG_Left: {
                  V v_e_241708 = heff_field(v_x11_241706, 0);
                  heff_take_n(v_x11_241706, 1ULL, 1);
                  heff_drop_rec(v_kw_24794, 9);
                  heff_drop(v_b_24799);
                  heff_drop(v_x_241697);
                  heff_drop(v_x_241703);
                  return heff_tag_at_n(v_ru_24x1_241693_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241708}), v_st_241707});
                }
                case TAG_Right: {
                  V v_x_241709 = heff_field(v_x11_241706, 0);
                  heff_take_n(v_x11_241706, 1ULL, 1);
                  V v_t_241710 = (g_heff_2esyntax_2ecst_2elastE(v_b_24799));
                  V v_e_241711 = heff_get_n(v_t_241710, 4, 9);
                  V v_t_241712 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_24794, 3, 9), v_e_241711});
                  V v_x_241713 = (g_heff_2esyntax_2esurface_2eifE(v_t_241712, v_x_241697, v_x_241703, v_x_241709));
                  return heff_tag_at_n(v_ru_24x1_241693_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_241713}), v_st_241707});
                }
                default: return heff_nomatch(v_x11_241706);
                }
              }
              default: return heff_nomatch(v_x1_241705);
              }
            }
            default: return heff_nomatch(v_x11_241700);
            }
          }
          default: return heff_nomatch(v_x1_241699);
          }
        }
        default: return heff_nomatch(v_x11_241694);
        }
      }
      default: return heff_nomatch(v_x1_241693);
      }
    }
    case TAG_ENest: {
      V v_m_241718 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_24795}));
      V v_x1_241719 = heff_tr(heff_call(v_m_241718, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_241719)) {
      case TAG_MkPair: {
        V v_x11_241720 = heff_field(v_x1_241719, 0);
        V v_st_241721 = heff_field(v_x1_241719, 1);
        V v_ru_24x1_241719_24MkPair = heff_take_reuse_n(v_x1_241719, 3ULL, 2);
        switch (heff_tag_of(v_x11_241720)) {
        case TAG_Left: {
          V v_e_241722 = heff_field(v_x11_241720, 0);
          heff_take_n(v_x11_241720, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_24794, 9);
          heff_drop(v_a_24797);
          heff_drop(v_b_24799);
          return heff_tag_at_n(v_ru_24x1_241719_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241722}), v_st_241721});
        }
        case TAG_Right: {
          V v_x_241723 = heff_field(v_x11_241720, 0);
          heff_take_n(v_x11_241720, 1ULL, 1);
          V v_m_241724 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_24797}));
          V v_x1_241725 = heff_tr(heff_call(v_m_241724, 1, (V[]){v_st_241721}));
          switch (heff_tag_of(v_x1_241725)) {
          case TAG_MkPair: {
            V v_x11_241726 = heff_field(v_x1_241725, 0);
            V v_st_241727 = heff_field(v_x1_241725, 1);
            heff_take_n(v_x1_241725, 3ULL, 2);
            switch (heff_tag_of(v_x11_241726)) {
            case TAG_Left: {
              V v_e_241728 = heff_field(v_x11_241726, 0);
              heff_take_n(v_x11_241726, 1ULL, 1);
              heff_drop_rec(v_r_240, 3);
              heff_drop_rec(v_kw_24794, 9);
              heff_drop(v_b_24799);
              heff_drop(v_x_241723);
              return heff_tag_at_n(v_ru_24x1_241719_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241728}), v_st_241727});
            }
            case TAG_Right: {
              V v_x_241729 = heff_field(v_x11_241726, 0);
              heff_take_n(v_x11_241726, 1ULL, 1);
              V v_m_241730 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_b_24799)}));
              V v_x1_241731 = heff_tr(heff_call(v_m_241730, 1, (V[]){v_st_241727}));
              switch (heff_tag_of(v_x1_241731)) {
              case TAG_MkPair: {
                V v_x11_241732 = heff_field(v_x1_241731, 0);
                V v_st_241733 = heff_field(v_x1_241731, 1);
                heff_take_n(v_x1_241731, 3ULL, 2);
                switch (heff_tag_of(v_x11_241732)) {
                case TAG_Left: {
                  V v_e_241734 = heff_field(v_x11_241732, 0);
                  heff_take_n(v_x11_241732, 1ULL, 1);
                  heff_drop_rec(v_kw_24794, 9);
                  heff_drop(v_b_24799);
                  heff_drop(v_x_241723);
                  heff_drop(v_x_241729);
                  return heff_tag_at_n(v_ru_24x1_241719_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241734}), v_st_241733});
                }
                case TAG_Right: {
                  V v_x_241735 = heff_field(v_x11_241732, 0);
                  heff_take_n(v_x11_241732, 1ULL, 1);
                  V v_t_241736 = (g_heff_2esyntax_2ecst_2elastE(v_b_24799));
                  V v_e_241737 = heff_get_n(v_t_241736, 4, 9);
                  V v_t_241738 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_24794, 3, 9), v_e_241737});
                  V v_x_241739 = (g_heff_2esyntax_2esurface_2eifE(v_t_241738, v_x_241723, v_x_241729, v_x_241735));
                  return heff_tag_at_n(v_ru_24x1_241719_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_241739}), v_st_241733});
                }
                default: return heff_nomatch(v_x11_241732);
                }
              }
              default: return heff_nomatch(v_x1_241731);
              }
            }
            default: return heff_nomatch(v_x11_241726);
            }
          }
          default: return heff_nomatch(v_x1_241725);
          }
        }
        default: return heff_nomatch(v_x11_241720);
        }
      }
      default: return heff_nomatch(v_x1_241719);
      }
    }
    case TAG_IfThen: {
      V v_m_241744 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_24795}));
      V v_x1_241745 = heff_tr(heff_call(v_m_241744, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_241745)) {
      case TAG_MkPair: {
        V v_x11_241746 = heff_field(v_x1_241745, 0);
        V v_st_241747 = heff_field(v_x1_241745, 1);
        V v_ru_24x1_241745_24MkPair = heff_take_reuse_n(v_x1_241745, 3ULL, 2);
        switch (heff_tag_of(v_x11_241746)) {
        case TAG_Left: {
          V v_e_241748 = heff_field(v_x11_241746, 0);
          heff_take_n(v_x11_241746, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_24794, 9);
          heff_drop(v_a_24797);
          heff_drop(v_b_24799);
          return heff_tag_at_n(v_ru_24x1_241745_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241748}), v_st_241747});
        }
        case TAG_Right: {
          V v_x_241749 = heff_field(v_x11_241746, 0);
          heff_take_n(v_x11_241746, 1ULL, 1);
          V v_m_241750 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_24797}));
          V v_x1_241751 = heff_tr(heff_call(v_m_241750, 1, (V[]){v_st_241747}));
          switch (heff_tag_of(v_x1_241751)) {
          case TAG_MkPair: {
            V v_x11_241752 = heff_field(v_x1_241751, 0);
            V v_st_241753 = heff_field(v_x1_241751, 1);
            heff_take_n(v_x1_241751, 3ULL, 2);
            switch (heff_tag_of(v_x11_241752)) {
            case TAG_Left: {
              V v_e_241754 = heff_field(v_x11_241752, 0);
              heff_take_n(v_x11_241752, 1ULL, 1);
              heff_drop_rec(v_r_240, 3);
              heff_drop_rec(v_kw_24794, 9);
              heff_drop(v_b_24799);
              heff_drop(v_x_241749);
              return heff_tag_at_n(v_ru_24x1_241745_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241754}), v_st_241753});
            }
            case TAG_Right: {
              V v_x_241755 = heff_field(v_x11_241752, 0);
              heff_take_n(v_x11_241752, 1ULL, 1);
              V v_m_241756 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_b_24799)}));
              V v_x1_241757 = heff_tr(heff_call(v_m_241756, 1, (V[]){v_st_241753}));
              switch (heff_tag_of(v_x1_241757)) {
              case TAG_MkPair: {
                V v_x11_241758 = heff_field(v_x1_241757, 0);
                V v_st_241759 = heff_field(v_x1_241757, 1);
                heff_take_n(v_x1_241757, 3ULL, 2);
                switch (heff_tag_of(v_x11_241758)) {
                case TAG_Left: {
                  V v_e_241760 = heff_field(v_x11_241758, 0);
                  heff_take_n(v_x11_241758, 1ULL, 1);
                  heff_drop_rec(v_kw_24794, 9);
                  heff_drop(v_b_24799);
                  heff_drop(v_x_241749);
                  heff_drop(v_x_241755);
                  return heff_tag_at_n(v_ru_24x1_241745_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241760}), v_st_241759});
                }
                case TAG_Right: {
                  V v_x_241761 = heff_field(v_x11_241758, 0);
                  heff_take_n(v_x11_241758, 1ULL, 1);
                  V v_t_241762 = (g_heff_2esyntax_2ecst_2elastE(v_b_24799));
                  V v_e_241763 = heff_get_n(v_t_241762, 4, 9);
                  V v_t_241764 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_24794, 3, 9), v_e_241763});
                  V v_x_241765 = (g_heff_2esyntax_2esurface_2eifE(v_t_241764, v_x_241749, v_x_241755, v_x_241761));
                  return heff_tag_at_n(v_ru_24x1_241745_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_241765}), v_st_241759});
                }
                default: return heff_nomatch(v_x11_241758);
                }
              }
              default: return heff_nomatch(v_x1_241757);
              }
            }
            default: return heff_nomatch(v_x11_241752);
            }
          }
          default: return heff_nomatch(v_x1_241751);
          }
        }
        default: return heff_nomatch(v_x11_241746);
        }
      }
      default: return heff_nomatch(v_x1_241745);
      }
    }
    case TAG_ELetCond: {
      V v_p_241767 = heff_field(v_e02_24795, 1);
      V v_e_241769 = heff_field(v_e02_24795, 3);
      heff_take_n(v_e02_24795, 10ULL, 4);
      V v_t_241770 = (g_heff_2esyntax_2ecst_2elastE(heff_dup(v_b_24799)));
      V v_e_241771 = heff_get_n(v_t_241770, 4, 9);
      V v_t_241772 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_24794, 3, 9), v_e_241771});
      return (g_heff_2esyntax_2esurface_2eifLetL(v_r_240, v_t_241772, v_p_241767, v_e_241769, v_a_24797, heff_tag_n(TAG_Just, 1, (V[]){v_b_24799}), v_z_242));
    }
    case TAG_ETry: {
      V v_m_241777 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_24795}));
      V v_x1_241778 = heff_tr(heff_call(v_m_241777, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_241778)) {
      case TAG_MkPair: {
        V v_x11_241779 = heff_field(v_x1_241778, 0);
        V v_st_241780 = heff_field(v_x1_241778, 1);
        V v_ru_24x1_241778_24MkPair = heff_take_reuse_n(v_x1_241778, 3ULL, 2);
        switch (heff_tag_of(v_x11_241779)) {
        case TAG_Left: {
          V v_e_241781 = heff_field(v_x11_241779, 0);
          heff_take_n(v_x11_241779, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_24794, 9);
          heff_drop(v_a_24797);
          heff_drop(v_b_24799);
          return heff_tag_at_n(v_ru_24x1_241778_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241781}), v_st_241780});
        }
        case TAG_Right: {
          V v_x_241782 = heff_field(v_x11_241779, 0);
          heff_take_n(v_x11_241779, 1ULL, 1);
          V v_m_241783 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_24797}));
          V v_x1_241784 = heff_tr(heff_call(v_m_241783, 1, (V[]){v_st_241780}));
          switch (heff_tag_of(v_x1_241784)) {
          case TAG_MkPair: {
            V v_x11_241785 = heff_field(v_x1_241784, 0);
            V v_st_241786 = heff_field(v_x1_241784, 1);
            heff_take_n(v_x1_241784, 3ULL, 2);
            switch (heff_tag_of(v_x11_241785)) {
            case TAG_Left: {
              V v_e_241787 = heff_field(v_x11_241785, 0);
              heff_take_n(v_x11_241785, 1ULL, 1);
              heff_drop_rec(v_r_240, 3);
              heff_drop_rec(v_kw_24794, 9);
              heff_drop(v_b_24799);
              heff_drop(v_x_241782);
              return heff_tag_at_n(v_ru_24x1_241778_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241787}), v_st_241786});
            }
            case TAG_Right: {
              V v_x_241788 = heff_field(v_x11_241785, 0);
              heff_take_n(v_x11_241785, 1ULL, 1);
              V v_m_241789 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_b_24799)}));
              V v_x1_241790 = heff_tr(heff_call(v_m_241789, 1, (V[]){v_st_241786}));
              switch (heff_tag_of(v_x1_241790)) {
              case TAG_MkPair: {
                V v_x11_241791 = heff_field(v_x1_241790, 0);
                V v_st_241792 = heff_field(v_x1_241790, 1);
                heff_take_n(v_x1_241790, 3ULL, 2);
                switch (heff_tag_of(v_x11_241791)) {
                case TAG_Left: {
                  V v_e_241793 = heff_field(v_x11_241791, 0);
                  heff_take_n(v_x11_241791, 1ULL, 1);
                  heff_drop_rec(v_kw_24794, 9);
                  heff_drop(v_b_24799);
                  heff_drop(v_x_241782);
                  heff_drop(v_x_241788);
                  return heff_tag_at_n(v_ru_24x1_241778_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241793}), v_st_241792});
                }
                case TAG_Right: {
                  V v_x_241794 = heff_field(v_x11_241791, 0);
                  heff_take_n(v_x11_241791, 1ULL, 1);
                  V v_t_241795 = (g_heff_2esyntax_2ecst_2elastE(v_b_24799));
                  V v_e_241796 = heff_get_n(v_t_241795, 4, 9);
                  V v_t_241797 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_24794, 3, 9), v_e_241796});
                  V v_x_241798 = (g_heff_2esyntax_2esurface_2eifE(v_t_241797, v_x_241782, v_x_241788, v_x_241794));
                  return heff_tag_at_n(v_ru_24x1_241778_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_241798}), v_st_241792});
                }
                default: return heff_nomatch(v_x11_241791);
                }
              }
              default: return heff_nomatch(v_x1_241790);
              }
            }
            default: return heff_nomatch(v_x11_241785);
            }
          }
          default: return heff_nomatch(v_x1_241784);
          }
        }
        default: return heff_nomatch(v_x11_241779);
        }
      }
      default: return heff_nomatch(v_x1_241778);
      }
    }
    case TAG_ECatch: {
      V v_m_241803 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_24795}));
      V v_x1_241804 = heff_tr(heff_call(v_m_241803, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_241804)) {
      case TAG_MkPair: {
        V v_x11_241805 = heff_field(v_x1_241804, 0);
        V v_st_241806 = heff_field(v_x1_241804, 1);
        V v_ru_24x1_241804_24MkPair = heff_take_reuse_n(v_x1_241804, 3ULL, 2);
        switch (heff_tag_of(v_x11_241805)) {
        case TAG_Left: {
          V v_e_241807 = heff_field(v_x11_241805, 0);
          heff_take_n(v_x11_241805, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_24794, 9);
          heff_drop(v_a_24797);
          heff_drop(v_b_24799);
          return heff_tag_at_n(v_ru_24x1_241804_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241807}), v_st_241806});
        }
        case TAG_Right: {
          V v_x_241808 = heff_field(v_x11_241805, 0);
          heff_take_n(v_x11_241805, 1ULL, 1);
          V v_m_241809 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_24797}));
          V v_x1_241810 = heff_tr(heff_call(v_m_241809, 1, (V[]){v_st_241806}));
          switch (heff_tag_of(v_x1_241810)) {
          case TAG_MkPair: {
            V v_x11_241811 = heff_field(v_x1_241810, 0);
            V v_st_241812 = heff_field(v_x1_241810, 1);
            heff_take_n(v_x1_241810, 3ULL, 2);
            switch (heff_tag_of(v_x11_241811)) {
            case TAG_Left: {
              V v_e_241813 = heff_field(v_x11_241811, 0);
              heff_take_n(v_x11_241811, 1ULL, 1);
              heff_drop_rec(v_r_240, 3);
              heff_drop_rec(v_kw_24794, 9);
              heff_drop(v_b_24799);
              heff_drop(v_x_241808);
              return heff_tag_at_n(v_ru_24x1_241804_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241813}), v_st_241812});
            }
            case TAG_Right: {
              V v_x_241814 = heff_field(v_x11_241811, 0);
              heff_take_n(v_x11_241811, 1ULL, 1);
              V v_m_241815 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_b_24799)}));
              V v_x1_241816 = heff_tr(heff_call(v_m_241815, 1, (V[]){v_st_241812}));
              switch (heff_tag_of(v_x1_241816)) {
              case TAG_MkPair: {
                V v_x11_241817 = heff_field(v_x1_241816, 0);
                V v_st_241818 = heff_field(v_x1_241816, 1);
                heff_take_n(v_x1_241816, 3ULL, 2);
                switch (heff_tag_of(v_x11_241817)) {
                case TAG_Left: {
                  V v_e_241819 = heff_field(v_x11_241817, 0);
                  heff_take_n(v_x11_241817, 1ULL, 1);
                  heff_drop_rec(v_kw_24794, 9);
                  heff_drop(v_b_24799);
                  heff_drop(v_x_241808);
                  heff_drop(v_x_241814);
                  return heff_tag_at_n(v_ru_24x1_241804_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241819}), v_st_241818});
                }
                case TAG_Right: {
                  V v_x_241820 = heff_field(v_x11_241817, 0);
                  heff_take_n(v_x11_241817, 1ULL, 1);
                  V v_t_241821 = (g_heff_2esyntax_2ecst_2elastE(v_b_24799));
                  V v_e_241822 = heff_get_n(v_t_241821, 4, 9);
                  V v_t_241823 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_24794, 3, 9), v_e_241822});
                  V v_x_241824 = (g_heff_2esyntax_2esurface_2eifE(v_t_241823, v_x_241808, v_x_241814, v_x_241820));
                  return heff_tag_at_n(v_ru_24x1_241804_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_241824}), v_st_241818});
                }
                default: return heff_nomatch(v_x11_241817);
                }
              }
              default: return heff_nomatch(v_x1_241816);
              }
            }
            default: return heff_nomatch(v_x11_241811);
            }
          }
          default: return heff_nomatch(v_x1_241810);
          }
        }
        default: return heff_nomatch(v_x11_241805);
        }
      }
      default: return heff_nomatch(v_x1_241804);
      }
    }
    case TAG_EWith: {
      V v_m_241831 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_24795}));
      V v_x1_241832 = heff_tr(heff_call(v_m_241831, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_241832)) {
      case TAG_MkPair: {
        V v_x11_241833 = heff_field(v_x1_241832, 0);
        V v_st_241834 = heff_field(v_x1_241832, 1);
        V v_ru_24x1_241832_24MkPair = heff_take_reuse_n(v_x1_241832, 3ULL, 2);
        switch (heff_tag_of(v_x11_241833)) {
        case TAG_Left: {
          V v_e_241835 = heff_field(v_x11_241833, 0);
          heff_take_n(v_x11_241833, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_24794, 9);
          heff_drop(v_a_24797);
          heff_drop(v_b_24799);
          return heff_tag_at_n(v_ru_24x1_241832_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241835}), v_st_241834});
        }
        case TAG_Right: {
          V v_x_241836 = heff_field(v_x11_241833, 0);
          heff_take_n(v_x11_241833, 1ULL, 1);
          V v_m_241837 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_24797}));
          V v_x1_241838 = heff_tr(heff_call(v_m_241837, 1, (V[]){v_st_241834}));
          switch (heff_tag_of(v_x1_241838)) {
          case TAG_MkPair: {
            V v_x11_241839 = heff_field(v_x1_241838, 0);
            V v_st_241840 = heff_field(v_x1_241838, 1);
            heff_take_n(v_x1_241838, 3ULL, 2);
            switch (heff_tag_of(v_x11_241839)) {
            case TAG_Left: {
              V v_e_241841 = heff_field(v_x11_241839, 0);
              heff_take_n(v_x11_241839, 1ULL, 1);
              heff_drop_rec(v_r_240, 3);
              heff_drop_rec(v_kw_24794, 9);
              heff_drop(v_b_24799);
              heff_drop(v_x_241836);
              return heff_tag_at_n(v_ru_24x1_241832_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241841}), v_st_241840});
            }
            case TAG_Right: {
              V v_x_241842 = heff_field(v_x11_241839, 0);
              heff_take_n(v_x11_241839, 1ULL, 1);
              V v_m_241843 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_b_24799)}));
              V v_x1_241844 = heff_tr(heff_call(v_m_241843, 1, (V[]){v_st_241840}));
              switch (heff_tag_of(v_x1_241844)) {
              case TAG_MkPair: {
                V v_x11_241845 = heff_field(v_x1_241844, 0);
                V v_st_241846 = heff_field(v_x1_241844, 1);
                heff_take_n(v_x1_241844, 3ULL, 2);
                switch (heff_tag_of(v_x11_241845)) {
                case TAG_Left: {
                  V v_e_241847 = heff_field(v_x11_241845, 0);
                  heff_take_n(v_x11_241845, 1ULL, 1);
                  heff_drop_rec(v_kw_24794, 9);
                  heff_drop(v_b_24799);
                  heff_drop(v_x_241836);
                  heff_drop(v_x_241842);
                  return heff_tag_at_n(v_ru_24x1_241832_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241847}), v_st_241846});
                }
                case TAG_Right: {
                  V v_x_241848 = heff_field(v_x11_241845, 0);
                  heff_take_n(v_x11_241845, 1ULL, 1);
                  V v_t_241849 = (g_heff_2esyntax_2ecst_2elastE(v_b_24799));
                  V v_e_241850 = heff_get_n(v_t_241849, 4, 9);
                  V v_t_241851 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_24794, 3, 9), v_e_241850});
                  V v_x_241852 = (g_heff_2esyntax_2esurface_2eifE(v_t_241851, v_x_241836, v_x_241842, v_x_241848));
                  return heff_tag_at_n(v_ru_24x1_241832_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_241852}), v_st_241846});
                }
                default: return heff_nomatch(v_x11_241845);
                }
              }
              default: return heff_nomatch(v_x1_241844);
              }
            }
            default: return heff_nomatch(v_x11_241839);
            }
          }
          default: return heff_nomatch(v_x1_241838);
          }
        }
        default: return heff_nomatch(v_x11_241833);
        }
      }
      default: return heff_nomatch(v_x1_241832);
      }
    }
    default: return heff_nomatch(v_e02_24795);
    }
  }
  case TAG_Do: {
    V v_kw_241853 = heff_dup(heff_field(v_e0_241, 0));
    V v_stmts_241854 = heff_dup(heff_field(v_e0_241, 1));
    HeffT2 v_t_241856 = (g_heff_2esyntax_2esurface_2eblock_24cpr(heff_clo_n(g_heff_2esyntax_2esurface_2eexprL_lam8, 1, 1, (V[]){v_r_240}), v_stmts_241854, v_z_242));
    {
      V v_field_241857 = v_t_241856.f[0];
      V v_field_241858 = v_t_241856.f[1];
      V v_x11_241859 = v_field_241857;
      V v_st_241860 = v_field_241858;
      switch (heff_tag_of(v_x11_241859)) {
      case TAG_Left: {
        V v_e_241861 = heff_field(v_x11_241859, 0);
        V v_ru_24x11_241859_24Left = heff_take_reuse_n(v_x11_241859, 1ULL, 1);
        heff_drop_tag(v_e0_241, 2);
        heff_drop_rec(v_kw_241853, 9);
        return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_241859_24Left, TAG_Left, 1, (V[]){v_e_241861}), v_st_241860});
      }
      case TAG_Right: {
        V v_x_241862 = heff_field(v_x11_241859, 0);
        V v_ru_24x11_241859_24Right = heff_take_reuse_n(v_x11_241859, 1ULL, 1);
        V v_t_241863 = (g_heff_2esyntax_2ecst_2elastE(v_e0_241));
        V v_e_241864 = heff_get_n(v_t_241863, 4, 9);
        V v_t_241865 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_241853, 3, 9), v_e_241864});
        V v_x_241866 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EDo, 1, (V[]){v_x_241862}), v_t_241865});
        return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_241859_24Right, TAG_Right, 1, (V[]){v_x_241866}), v_st_241860});
      }
      default: return heff_nomatch(v_x11_241859);
      }
    }
  }
  case TAG_ESBind: {
    heff_drop_rec(v_r_240, 3);
    V v_t_241870 = (g_heff_2esyntax_2ecst_2efirstE(v_e0_241));
    V v_t_241871 = ({ V a_0 = v_e0_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e0_241, 3); r_; });
    V v_t_241872 = heff_strAppend(heff_get_n(v_t_241871, 1, 9), ((V)&g_heff_2esyntax_2esurface_2eexprL_str33));
    V v_msg_241873 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eexprL_str34), v_t_241872);
    V v_t_241874 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_241870, 3), heff_get_n(v_t_241870, 4, 9)});
    V v_t_241875 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_241873, v_t_241874, NTAG(TAG_Nothing)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_241875}), v_z_242});
  }
  case TAG_ELet: {
    HEFF_LAST return g_heff_2esyntax_2esurface_2eletL(v_r_240, v_e0_241, v_z_242);
  }
  case TAG_ELetMut: {
    heff_drop_rec(v_r_240, 3);
    V v_t_241888 = (g_heff_2esyntax_2ecst_2efirstE(v_e0_241));
    V v_t_241889 = ({ V a_0 = v_e0_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e0_241, 6); r_; });
    V v_t_241890 = heff_strAppend(heff_get_n(v_t_241889, 1, 9), ((V)&g_heff_2esyntax_2esurface_2eexprL_str35));
    V v_msg_241891 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eexprL_str36), v_t_241890);
    V v_t_241892 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_241888, 3), heff_get_n(v_t_241888, 4, 9)});
    V v_t_241893 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_241891, v_t_241892, NTAG(TAG_Nothing)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_241893}), v_z_242});
  }
  case TAG_EAssign: {
    V v_x_241894 = heff_field(v_e0_241, 0);
    V v_e_241896 = heff_field(v_e0_241, 2);
    V v_ru_24e0_241_24EAssign = heff_take_reuse_n(v_e0_241, 5ULL, 3);
    V v_m_241897 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_e_241896)}));
    V v_x1_241898 = heff_tr(heff_call(v_m_241897, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x1_241898)) {
    case TAG_MkPair: {
      V v_x11_241899 = heff_field(v_x1_241898, 0);
      V v_st_241900 = heff_field(v_x1_241898, 1);
      V v_ru_24x1_241898_24MkPair = heff_take_reuse_n(v_x1_241898, 3ULL, 2);
      switch (heff_tag_of(v_x11_241899)) {
      case TAG_Left: {
        V v_e_241901 = heff_field(v_x11_241899, 0);
        heff_take_n(v_x11_241899, 1ULL, 1);
        heff_drop_rec(v_x_241894, 9);
        heff_drop(v_e_241896);
        heff_drop_cell(v_ru_24e0_241_24EAssign, 3);
        return heff_tag_at_n(v_ru_24x1_241898_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241901}), v_st_241900});
      }
      case TAG_Right: {
        V v_x_241902 = heff_field(v_x11_241899, 0);
        heff_take_n(v_x11_241899, 1ULL, 1);
        V v_t_241903 = heff_rec_n(2, shape_start__end, (V[]){heff_dup(heff_rfield(v_x_241894, 3)), heff_take_field(v_x_241894, 4)});
        V v_t_241904 = heff_tag_at_n(v_ru_24e0_241_24EAssign, TAG_EAssign, 3, (V[]){heff_dup(heff_rfield(v_x_241894, 1)), v_t_241903, v_x_241902});
        V v_t_241905 = (g_heff_2esyntax_2ecst_2elastE(v_e_241896));
        V v_e_241906 = heff_get_n(v_t_241905, 4, 9);
        V v_t_241907 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_x_241894, 3, 9), v_e_241906});
        V v_x_241908 = heff_tag_n(TAG_At, 2, (V[]){v_t_241904, v_t_241907});
        return heff_tag_at_n(v_ru_24x1_241898_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_241908}), v_st_241900});
      }
      default: return heff_nomatch(v_x11_241899);
      }
    }
    default: return heff_nomatch(v_x1_241898);
    }
  }
  case TAG_EWhile: {
    V v_kw_241909 = heff_dup(heff_field(v_e0_241, 0));
    V v_c_241910 = heff_dup(heff_field(v_e0_241, 1));
    V v_body_241912 = heff_dup(heff_field(v_e0_241, 3));
    V v_m_241913 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_c_241910}));
    V v_x1_241914 = heff_tr(heff_call(v_m_241913, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x1_241914)) {
    case TAG_MkPair: {
      V v_x11_241915 = heff_field(v_x1_241914, 0);
      V v_st_241916 = heff_field(v_x1_241914, 1);
      V v_ru_24x1_241914_24MkPair = heff_take_reuse_n(v_x1_241914, 3ULL, 2);
      switch (heff_tag_of(v_x11_241915)) {
      case TAG_Left: {
        V v_e_241917 = heff_field(v_x11_241915, 0);
        heff_take_n(v_x11_241915, 1ULL, 1);
        heff_drop_rec(v_r_240, 3);
        heff_drop_tag(v_e0_241, 4);
        heff_drop_rec(v_kw_241909, 9);
        heff_drop(v_body_241912);
        return heff_tag_at_n(v_ru_24x1_241914_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241917}), v_st_241916});
      }
      case TAG_Right: {
        V v_x_241918 = heff_field(v_x11_241915, 0);
        heff_take_n(v_x11_241915, 1ULL, 1);
        HeffT2 v_t_241920 = (g_heff_2esyntax_2esurface_2eblock_24cpr(heff_clo_n(g_heff_2esyntax_2esurface_2eexprL_lam9, 1, 1, (V[]){v_r_240}), v_body_241912, v_st_241916));
        {
          V v_field_241921 = v_t_241920.f[0];
          V v_field_241922 = v_t_241920.f[1];
          V v_x11_241923 = v_field_241921;
          V v_st_241924 = v_field_241922;
          switch (heff_tag_of(v_x11_241923)) {
          case TAG_Left: {
            V v_e_241925 = heff_field(v_x11_241923, 0);
            heff_take_n(v_x11_241923, 1ULL, 1);
            heff_drop_tag(v_e0_241, 4);
            heff_drop_rec(v_kw_241909, 9);
            heff_drop(v_x_241918);
            return heff_tag_at_n(v_ru_24x1_241914_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241925}), v_st_241924});
          }
          case TAG_Right: {
            V v_x_241926 = heff_field(v_x11_241923, 0);
            heff_take_n(v_x11_241923, 1ULL, 1);
            V v_t_241927 = (g_heff_2esyntax_2ecst_2elastE(v_e0_241));
            V v_e_241928 = heff_get_n(v_t_241927, 4, 9);
            V v_t_241929 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_241909, 3, 9), v_e_241928});
            V v_x_241930 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EWhile, 2, (V[]){v_x_241918, v_x_241926}), v_t_241929});
            return heff_tag_at_n(v_ru_24x1_241914_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_241930}), v_st_241924});
          }
          default: return heff_nomatch(v_x11_241923);
          }
        }
      }
      default: return heff_nomatch(v_x11_241915);
      }
    }
    default: return heff_nomatch(v_x1_241914);
    }
  }
  case TAG_EFor: {
    V v_kw_241931 = heff_dup(heff_field(v_e0_241, 0));
    V v_p_241932 = heff_dup(heff_field(v_e0_241, 1));
    V v_c_241934 = heff_dup(heff_field(v_e0_241, 3));
    V v_body_241936 = heff_dup(heff_field(v_e0_241, 5));
    V v_m_241937 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_c_241934}));
    V v_x1_241938 = heff_tr(heff_call(v_m_241937, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x1_241938)) {
    case TAG_MkPair: {
      V v_x11_241939 = heff_field(v_x1_241938, 0);
      V v_st_241940 = heff_field(v_x1_241938, 1);
      V v_ru_24x1_241938_24MkPair = heff_take_reuse_n(v_x1_241938, 3ULL, 2);
      switch (heff_tag_of(v_x11_241939)) {
      case TAG_Left: {
        V v_e_241941 = heff_field(v_x11_241939, 0);
        heff_take_n(v_x11_241939, 1ULL, 1);
        heff_drop_rec(v_r_240, 3);
        heff_drop_tag(v_e0_241, 6);
        heff_drop_rec(v_kw_241931, 9);
        heff_drop(v_p_241932);
        heff_drop(v_body_241936);
        return heff_tag_at_n(v_ru_24x1_241938_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241941}), v_st_241940});
      }
      case TAG_Right: {
        V v_x_241942 = heff_field(v_x11_241939, 0);
        heff_take_n(v_x11_241939, 1ULL, 1);
        V v_m_241943 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 1)), 1, (V[]){heff_dup(v_p_241932)}));
        V v_x1_241944 = heff_tr(heff_call(v_m_241943, 1, (V[]){v_st_241940}));
        switch (heff_tag_of(v_x1_241944)) {
        case TAG_MkPair: {
          V v_x11_241945 = heff_field(v_x1_241944, 0);
          V v_st_241946 = heff_field(v_x1_241944, 1);
          V v_ru_24x1_241944_24MkPair = heff_take_reuse_n(v_x1_241944, 3ULL, 2);
          switch (heff_tag_of(v_x11_241945)) {
          case TAG_Left: {
            V v_e_241947 = heff_field(v_x11_241945, 0);
            heff_take_n(v_x11_241945, 1ULL, 1);
            heff_drop_rec(v_r_240, 3);
            heff_drop_tag(v_e0_241, 6);
            heff_drop_rec(v_kw_241931, 9);
            heff_drop(v_p_241932);
            heff_drop(v_body_241936);
            heff_drop(v_x_241942);
            heff_drop_cell(v_ru_24x1_241944_24MkPair, 2);
            return heff_tag_at_n(v_ru_24x1_241938_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241947}), v_st_241946});
          }
          case TAG_Right: {
            V v_x_241948 = heff_field(v_x11_241945, 0);
            heff_take_n(v_x11_241945, 1ULL, 1);
            V v_t_241949 = ({ V b_0 = NTAG(TAG_Nil); V a_1 = v_p_241932; V r_ = (g_heff_2esyntax_2esurface_2eboundBy(b_0, a_1)); heff_drop(b_0); heff_drop(v_p_241932); r_; });
            V v_t_241951 = heff_tr(heff_call(((V)&g_heff_2esyntax_2esurface_2eblock_clo), 2, (V[]){heff_clo_n(g_heff_2esyntax_2esurface_2eexprL_lam10, 1, 1, (V[]){v_r_240}), v_body_241936}));
            HeffT2 v_t_241952 = (g_heff_2esyntax_2esurface_2ewithScope_24cpr(v_t_241949, v_t_241951, v_st_241946));
            {
              V v_field_241953 = v_t_241952.f[0];
              V v_field_241954 = v_t_241952.f[1];
              V v_x11_241955 = v_field_241953;
              V v_st_241956 = v_field_241954;
              switch (heff_tag_of(v_x11_241955)) {
              case TAG_Left: {
                V v_e_241957 = heff_field(v_x11_241955, 0);
                heff_take_n(v_x11_241955, 1ULL, 1);
                heff_drop_tag(v_e0_241, 6);
                heff_drop_rec(v_kw_241931, 9);
                heff_drop(v_x_241942);
                heff_drop_cell(v_ru_24x1_241944_24MkPair, 2);
                heff_drop(v_x_241948);
                return heff_tag_at_n(v_ru_24x1_241938_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241957}), v_st_241956});
              }
              case TAG_Right: {
                V v_x_241958 = heff_field(v_x11_241955, 0);
                heff_take_n(v_x11_241955, 1ULL, 1);
                V v_t_241959 = (g_heff_2esyntax_2ecst_2elastE(v_e0_241));
                V v_e_241960 = heff_get_n(v_t_241959, 4, 9);
                V v_t_241961 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_241931, 3, 9), v_e_241960});
                V v_x_241962 = heff_tag_at_n(v_ru_24x1_241944_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_EFor, 3, (V[]){v_x_241948, v_x_241942, v_x_241958}), v_t_241961});
                return heff_tag_at_n(v_ru_24x1_241938_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_241962}), v_st_241956});
              }
              default: return heff_nomatch(v_x11_241955);
              }
            }
          }
          default: return heff_nomatch(v_x11_241945);
          }
        }
        default: return heff_nomatch(v_x1_241944);
        }
      }
      default: return heff_nomatch(v_x11_241939);
      }
    }
    default: return heff_nomatch(v_x1_241938);
    }
  }
  case TAG_EJump: {
    V v_kw_241963 = heff_field(v_e0_241, 0);
    V v_ru_24e0_241_24EJump = heff_take_reuse_n(v_e0_241, 1ULL, 1);
    heff_drop_rec(v_r_240, 3);
    V v_t_241965;
    if (heff_strEq_c(heff_dup(heff_rfield(v_kw_241963, 1)), ((V)&g_heff_2esyntax_2esurface_2eexprL_str37))) {
      v_t_241965 = NTAG(TAG_EBreak);
    } else {
      v_t_241965 = NTAG(TAG_EContinue);
    }
    V v_t_241966 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_kw_241963, 3), heff_get_n(v_kw_241963, 4, 9)});
    V v_t_241967 = heff_tag_at_n(v_ru_24e0_241_24EJump, TAG_Right, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_241965, v_t_241966})});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_241967, v_z_242});
  }
  case TAG_EReturn: {
    V v_kw_241968 = heff_field(v_e0_241, 0);
    V v_e_241969 = heff_field(v_e0_241, 1);
    V v_ru_24e0_241_24EReturn = heff_take_reuse_n(v_e0_241, 3ULL, 2);
    V v_m_241970 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_e_241969)}));
    V v_x1_241971 = heff_tr(heff_call(v_m_241970, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x1_241971)) {
    case TAG_MkPair: {
      V v_x11_241972 = heff_field(v_x1_241971, 0);
      V v_st_241973 = heff_field(v_x1_241971, 1);
      V v_ru_24x1_241971_24MkPair = heff_take_reuse_n(v_x1_241971, 3ULL, 2);
      switch (heff_tag_of(v_x11_241972)) {
      case TAG_Left: {
        V v_e_241974 = heff_field(v_x11_241972, 0);
        heff_take_n(v_x11_241972, 1ULL, 1);
        heff_drop_rec(v_kw_241968, 9);
        heff_drop(v_e_241969);
        heff_drop_cell(v_ru_24x1_241971_24MkPair, 2);
        return heff_tag_at_n(v_ru_24e0_241_24EReturn, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241974}), v_st_241973});
      }
      case TAG_Right: {
        V v_x_241975 = heff_field(v_x11_241972, 0);
        heff_take_n(v_x11_241972, 1ULL, 1);
        V v_t_241976 = (g_heff_2esyntax_2ecst_2elastE(v_e_241969));
        V v_e_241977 = heff_get_n(v_t_241976, 4, 9);
        V v_t_241978 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_241968, 3, 9), v_e_241977});
        V v_x_241979 = heff_tag_at_n(v_ru_24e0_241_24EReturn, TAG_At, 2, (V[]){heff_tag_n(TAG_EReturn, 1, (V[]){v_x_241975}), v_t_241978});
        return heff_tag_at_n(v_ru_24x1_241971_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_241979}), v_st_241973});
      }
      default: return heff_nomatch(v_x11_241972);
      }
    }
    default: return heff_nomatch(v_x1_241971);
    }
  }
  case TAG_ENest: {
    V v_o_241980 = heff_field(v_e0_241, 0);
    V v_e_241982 = heff_field(v_e0_241, 2);
    V v_c_241983 = heff_field(v_e0_241, 3);
    heff_take_n(v_e0_241, 13ULL, 4);
    V v_m_241984 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_241982}));
    V v_x1_241985 = heff_tr(heff_call(v_m_241984, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x1_241985)) {
    case TAG_MkPair: {
      V v_x11_241986 = heff_field(v_x1_241985, 0);
      V v_st_241987 = heff_field(v_x1_241985, 1);
      V v_ru_24x1_241985_24MkPair = heff_take_reuse_n(v_x1_241985, 3ULL, 2);
      switch (heff_tag_of(v_x11_241986)) {
      case TAG_Left: {
        V v_e_241988 = heff_field(v_x11_241986, 0);
        heff_take_n(v_x11_241986, 1ULL, 1);
        heff_drop_rec(v_o_241980, 9);
        heff_drop_rec(v_c_241983, 9);
        return heff_tag_at_n(v_ru_24x1_241985_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241988}), v_st_241987});
      }
      case TAG_Right: {
        V v_x_241989 = heff_field(v_x11_241986, 0);
        V v_ru_24x11_241986_24Right = heff_take_reuse_n(v_x11_241986, 1ULL, 1);
        V v_t_241990 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_o_241980, 3, 9), heff_get_n(v_c_241983, 4, 9)});
        V v_t_241991 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_241986_24Right, TAG_ENest, 1, (V[]){v_x_241989}), v_t_241990});
        return heff_tag_at_n(v_ru_24x1_241985_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_241991}), v_st_241987});
      }
      default: return heff_nomatch(v_x11_241986);
      }
    }
    default: return heff_nomatch(v_x1_241985);
    }
  }
  case TAG_IfThen: {
    V v_kw_241992 = heff_field(v_e0_241, 0);
    V v_e02_241993 = heff_field(v_e0_241, 1);
    V v_a_241995 = heff_field(v_e0_241, 3);
    heff_take_n(v_e0_241, 11ULL, 4);
    switch (heff_tag_of(v_e02_241993)) {
    case TAG_Atom: {
      V v_m_241997 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_241993}));
      V v_x1_241998 = heff_tr(heff_call(v_m_241997, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_241998)) {
      case TAG_MkPair: {
        V v_x11_241999 = heff_field(v_x1_241998, 0);
        V v_st_242000 = heff_field(v_x1_241998, 1);
        V v_ru_24x1_241998_24MkPair = heff_take_reuse_n(v_x1_241998, 3ULL, 2);
        switch (heff_tag_of(v_x11_241999)) {
        case TAG_Left: {
          V v_e_242001 = heff_field(v_x11_241999, 0);
          heff_take_n(v_x11_241999, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_241992, 9);
          heff_drop(v_a_241995);
          return heff_tag_at_n(v_ru_24x1_241998_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242001}), v_st_242000});
        }
        case TAG_Right: {
          V v_x_242002 = heff_field(v_x11_241999, 0);
          heff_take_n(v_x11_241999, 1ULL, 1);
          V v_m_242003 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_a_241995)}));
          V v_x1_242004 = heff_tr(heff_call(v_m_242003, 1, (V[]){v_st_242000}));
          switch (heff_tag_of(v_x1_242004)) {
          case TAG_MkPair: {
            V v_x11_242005 = heff_field(v_x1_242004, 0);
            V v_st_242006 = heff_field(v_x1_242004, 1);
            V v_ru_24x1_242004_24MkPair = heff_take_reuse_n(v_x1_242004, 3ULL, 2);
            switch (heff_tag_of(v_x11_242005)) {
            case TAG_Left: {
              V v_e_242007 = heff_field(v_x11_242005, 0);
              heff_take_n(v_x11_242005, 1ULL, 1);
              heff_drop_rec(v_kw_241992, 9);
              heff_drop(v_a_241995);
              heff_drop(v_x_242002);
              heff_drop_cell(v_ru_24x1_242004_24MkPair, 2);
              return heff_tag_at_n(v_ru_24x1_241998_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242007}), v_st_242006});
            }
            case TAG_Right: {
              V v_x_242008 = heff_field(v_x11_242005, 0);
              heff_take_n(v_x11_242005, 1ULL, 1);
              V v_t_242009 = (g_heff_2esyntax_2ecst_2elastE(v_a_241995));
              V v_e_242010 = heff_get_n(v_t_242009, 4, 9);
              V v_t_242011 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_241992, 3, 9), v_e_242010});
              V v_x_242012 = heff_tag_at_n(v_ru_24x1_242004_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_EIfThen, 2, (V[]){v_x_242002, v_x_242008}), v_t_242011});
              return heff_tag_at_n(v_ru_24x1_241998_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_242012}), v_st_242006});
            }
            default: return heff_nomatch(v_x11_242005);
            }
          }
          default: return heff_nomatch(v_x1_242004);
          }
        }
        default: return heff_nomatch(v_x11_241999);
        }
      }
      default: return heff_nomatch(v_x1_241998);
      }
    }
    case TAG_EParen: {
      V v_m_242016 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_241993}));
      V v_x1_242017 = heff_tr(heff_call(v_m_242016, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_242017)) {
      case TAG_MkPair: {
        V v_x11_242018 = heff_field(v_x1_242017, 0);
        V v_st_242019 = heff_field(v_x1_242017, 1);
        V v_ru_24x1_242017_24MkPair = heff_take_reuse_n(v_x1_242017, 3ULL, 2);
        switch (heff_tag_of(v_x11_242018)) {
        case TAG_Left: {
          V v_e_242020 = heff_field(v_x11_242018, 0);
          heff_take_n(v_x11_242018, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_241992, 9);
          heff_drop(v_a_241995);
          return heff_tag_at_n(v_ru_24x1_242017_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242020}), v_st_242019});
        }
        case TAG_Right: {
          V v_x_242021 = heff_field(v_x11_242018, 0);
          heff_take_n(v_x11_242018, 1ULL, 1);
          V v_m_242022 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_a_241995)}));
          V v_x1_242023 = heff_tr(heff_call(v_m_242022, 1, (V[]){v_st_242019}));
          switch (heff_tag_of(v_x1_242023)) {
          case TAG_MkPair: {
            V v_x11_242024 = heff_field(v_x1_242023, 0);
            V v_st_242025 = heff_field(v_x1_242023, 1);
            V v_ru_24x1_242023_24MkPair = heff_take_reuse_n(v_x1_242023, 3ULL, 2);
            switch (heff_tag_of(v_x11_242024)) {
            case TAG_Left: {
              V v_e_242026 = heff_field(v_x11_242024, 0);
              heff_take_n(v_x11_242024, 1ULL, 1);
              heff_drop_rec(v_kw_241992, 9);
              heff_drop(v_a_241995);
              heff_drop(v_x_242021);
              heff_drop_cell(v_ru_24x1_242023_24MkPair, 2);
              return heff_tag_at_n(v_ru_24x1_242017_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242026}), v_st_242025});
            }
            case TAG_Right: {
              V v_x_242027 = heff_field(v_x11_242024, 0);
              heff_take_n(v_x11_242024, 1ULL, 1);
              V v_t_242028 = (g_heff_2esyntax_2ecst_2elastE(v_a_241995));
              V v_e_242029 = heff_get_n(v_t_242028, 4, 9);
              V v_t_242030 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_241992, 3, 9), v_e_242029});
              V v_x_242031 = heff_tag_at_n(v_ru_24x1_242023_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_EIfThen, 2, (V[]){v_x_242021, v_x_242027}), v_t_242030});
              return heff_tag_at_n(v_ru_24x1_242017_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_242031}), v_st_242025});
            }
            default: return heff_nomatch(v_x11_242024);
            }
          }
          default: return heff_nomatch(v_x1_242023);
          }
        }
        default: return heff_nomatch(v_x11_242018);
        }
      }
      default: return heff_nomatch(v_x1_242017);
      }
    }
    case TAG_Named: {
      V v_m_242037 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_241993}));
      V v_x1_242038 = heff_tr(heff_call(v_m_242037, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_242038)) {
      case TAG_MkPair: {
        V v_x11_242039 = heff_field(v_x1_242038, 0);
        V v_st_242040 = heff_field(v_x1_242038, 1);
        V v_ru_24x1_242038_24MkPair = heff_take_reuse_n(v_x1_242038, 3ULL, 2);
        switch (heff_tag_of(v_x11_242039)) {
        case TAG_Left: {
          V v_e_242041 = heff_field(v_x11_242039, 0);
          heff_take_n(v_x11_242039, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_241992, 9);
          heff_drop(v_a_241995);
          return heff_tag_at_n(v_ru_24x1_242038_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242041}), v_st_242040});
        }
        case TAG_Right: {
          V v_x_242042 = heff_field(v_x11_242039, 0);
          heff_take_n(v_x11_242039, 1ULL, 1);
          V v_m_242043 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_a_241995)}));
          V v_x1_242044 = heff_tr(heff_call(v_m_242043, 1, (V[]){v_st_242040}));
          switch (heff_tag_of(v_x1_242044)) {
          case TAG_MkPair: {
            V v_x11_242045 = heff_field(v_x1_242044, 0);
            V v_st_242046 = heff_field(v_x1_242044, 1);
            V v_ru_24x1_242044_24MkPair = heff_take_reuse_n(v_x1_242044, 3ULL, 2);
            switch (heff_tag_of(v_x11_242045)) {
            case TAG_Left: {
              V v_e_242047 = heff_field(v_x11_242045, 0);
              heff_take_n(v_x11_242045, 1ULL, 1);
              heff_drop_rec(v_kw_241992, 9);
              heff_drop(v_a_241995);
              heff_drop(v_x_242042);
              heff_drop_cell(v_ru_24x1_242044_24MkPair, 2);
              return heff_tag_at_n(v_ru_24x1_242038_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242047}), v_st_242046});
            }
            case TAG_Right: {
              V v_x_242048 = heff_field(v_x11_242045, 0);
              heff_take_n(v_x11_242045, 1ULL, 1);
              V v_t_242049 = (g_heff_2esyntax_2ecst_2elastE(v_a_241995));
              V v_e_242050 = heff_get_n(v_t_242049, 4, 9);
              V v_t_242051 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_241992, 3, 9), v_e_242050});
              V v_x_242052 = heff_tag_at_n(v_ru_24x1_242044_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_EIfThen, 2, (V[]){v_x_242042, v_x_242048}), v_t_242051});
              return heff_tag_at_n(v_ru_24x1_242038_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_242052}), v_st_242046});
            }
            default: return heff_nomatch(v_x11_242045);
            }
          }
          default: return heff_nomatch(v_x1_242044);
          }
        }
        default: return heff_nomatch(v_x11_242039);
        }
      }
      default: return heff_nomatch(v_x1_242038);
      }
    }
    case TAG_Tup: {
      V v_m_242057 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_241993}));
      V v_x1_242058 = heff_tr(heff_call(v_m_242057, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_242058)) {
      case TAG_MkPair: {
        V v_x11_242059 = heff_field(v_x1_242058, 0);
        V v_st_242060 = heff_field(v_x1_242058, 1);
        V v_ru_24x1_242058_24MkPair = heff_take_reuse_n(v_x1_242058, 3ULL, 2);
        switch (heff_tag_of(v_x11_242059)) {
        case TAG_Left: {
          V v_e_242061 = heff_field(v_x11_242059, 0);
          heff_take_n(v_x11_242059, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_241992, 9);
          heff_drop(v_a_241995);
          return heff_tag_at_n(v_ru_24x1_242058_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242061}), v_st_242060});
        }
        case TAG_Right: {
          V v_x_242062 = heff_field(v_x11_242059, 0);
          heff_take_n(v_x11_242059, 1ULL, 1);
          V v_m_242063 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_a_241995)}));
          V v_x1_242064 = heff_tr(heff_call(v_m_242063, 1, (V[]){v_st_242060}));
          switch (heff_tag_of(v_x1_242064)) {
          case TAG_MkPair: {
            V v_x11_242065 = heff_field(v_x1_242064, 0);
            V v_st_242066 = heff_field(v_x1_242064, 1);
            V v_ru_24x1_242064_24MkPair = heff_take_reuse_n(v_x1_242064, 3ULL, 2);
            switch (heff_tag_of(v_x11_242065)) {
            case TAG_Left: {
              V v_e_242067 = heff_field(v_x11_242065, 0);
              heff_take_n(v_x11_242065, 1ULL, 1);
              heff_drop_rec(v_kw_241992, 9);
              heff_drop(v_a_241995);
              heff_drop(v_x_242062);
              heff_drop_cell(v_ru_24x1_242064_24MkPair, 2);
              return heff_tag_at_n(v_ru_24x1_242058_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242067}), v_st_242066});
            }
            case TAG_Right: {
              V v_x_242068 = heff_field(v_x11_242065, 0);
              heff_take_n(v_x11_242065, 1ULL, 1);
              V v_t_242069 = (g_heff_2esyntax_2ecst_2elastE(v_a_241995));
              V v_e_242070 = heff_get_n(v_t_242069, 4, 9);
              V v_t_242071 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_241992, 3, 9), v_e_242070});
              V v_x_242072 = heff_tag_at_n(v_ru_24x1_242064_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_EIfThen, 2, (V[]){v_x_242062, v_x_242068}), v_t_242071});
              return heff_tag_at_n(v_ru_24x1_242058_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_242072}), v_st_242066});
            }
            default: return heff_nomatch(v_x11_242065);
            }
          }
          default: return heff_nomatch(v_x1_242064);
          }
        }
        default: return heff_nomatch(v_x11_242059);
        }
      }
      default: return heff_nomatch(v_x1_242058);
      }
    }
    case TAG_Seg: {
      V v_m_242076 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_241993}));
      V v_x1_242077 = heff_tr(heff_call(v_m_242076, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_242077)) {
      case TAG_MkPair: {
        V v_x11_242078 = heff_field(v_x1_242077, 0);
        V v_st_242079 = heff_field(v_x1_242077, 1);
        V v_ru_24x1_242077_24MkPair = heff_take_reuse_n(v_x1_242077, 3ULL, 2);
        switch (heff_tag_of(v_x11_242078)) {
        case TAG_Left: {
          V v_e_242080 = heff_field(v_x11_242078, 0);
          heff_take_n(v_x11_242078, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_241992, 9);
          heff_drop(v_a_241995);
          return heff_tag_at_n(v_ru_24x1_242077_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242080}), v_st_242079});
        }
        case TAG_Right: {
          V v_x_242081 = heff_field(v_x11_242078, 0);
          heff_take_n(v_x11_242078, 1ULL, 1);
          V v_m_242082 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_a_241995)}));
          V v_x1_242083 = heff_tr(heff_call(v_m_242082, 1, (V[]){v_st_242079}));
          switch (heff_tag_of(v_x1_242083)) {
          case TAG_MkPair: {
            V v_x11_242084 = heff_field(v_x1_242083, 0);
            V v_st_242085 = heff_field(v_x1_242083, 1);
            V v_ru_24x1_242083_24MkPair = heff_take_reuse_n(v_x1_242083, 3ULL, 2);
            switch (heff_tag_of(v_x11_242084)) {
            case TAG_Left: {
              V v_e_242086 = heff_field(v_x11_242084, 0);
              heff_take_n(v_x11_242084, 1ULL, 1);
              heff_drop_rec(v_kw_241992, 9);
              heff_drop(v_a_241995);
              heff_drop(v_x_242081);
              heff_drop_cell(v_ru_24x1_242083_24MkPair, 2);
              return heff_tag_at_n(v_ru_24x1_242077_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242086}), v_st_242085});
            }
            case TAG_Right: {
              V v_x_242087 = heff_field(v_x11_242084, 0);
              heff_take_n(v_x11_242084, 1ULL, 1);
              V v_t_242088 = (g_heff_2esyntax_2ecst_2elastE(v_a_241995));
              V v_e_242089 = heff_get_n(v_t_242088, 4, 9);
              V v_t_242090 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_241992, 3, 9), v_e_242089});
              V v_x_242091 = heff_tag_at_n(v_ru_24x1_242083_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_EIfThen, 2, (V[]){v_x_242081, v_x_242087}), v_t_242090});
              return heff_tag_at_n(v_ru_24x1_242077_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_242091}), v_st_242085});
            }
            default: return heff_nomatch(v_x11_242084);
            }
          }
          default: return heff_nomatch(v_x1_242083);
          }
        }
        default: return heff_nomatch(v_x11_242078);
        }
      }
      default: return heff_nomatch(v_x1_242077);
      }
    }
    case TAG_Braces: {
      V v_m_242096 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_241993}));
      V v_x1_242097 = heff_tr(heff_call(v_m_242096, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_242097)) {
      case TAG_MkPair: {
        V v_x11_242098 = heff_field(v_x1_242097, 0);
        V v_st_242099 = heff_field(v_x1_242097, 1);
        V v_ru_24x1_242097_24MkPair = heff_take_reuse_n(v_x1_242097, 3ULL, 2);
        switch (heff_tag_of(v_x11_242098)) {
        case TAG_Left: {
          V v_e_242100 = heff_field(v_x11_242098, 0);
          heff_take_n(v_x11_242098, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_241992, 9);
          heff_drop(v_a_241995);
          return heff_tag_at_n(v_ru_24x1_242097_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242100}), v_st_242099});
        }
        case TAG_Right: {
          V v_x_242101 = heff_field(v_x11_242098, 0);
          heff_take_n(v_x11_242098, 1ULL, 1);
          V v_m_242102 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_a_241995)}));
          V v_x1_242103 = heff_tr(heff_call(v_m_242102, 1, (V[]){v_st_242099}));
          switch (heff_tag_of(v_x1_242103)) {
          case TAG_MkPair: {
            V v_x11_242104 = heff_field(v_x1_242103, 0);
            V v_st_242105 = heff_field(v_x1_242103, 1);
            V v_ru_24x1_242103_24MkPair = heff_take_reuse_n(v_x1_242103, 3ULL, 2);
            switch (heff_tag_of(v_x11_242104)) {
            case TAG_Left: {
              V v_e_242106 = heff_field(v_x11_242104, 0);
              heff_take_n(v_x11_242104, 1ULL, 1);
              heff_drop_rec(v_kw_241992, 9);
              heff_drop(v_a_241995);
              heff_drop(v_x_242101);
              heff_drop_cell(v_ru_24x1_242103_24MkPair, 2);
              return heff_tag_at_n(v_ru_24x1_242097_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242106}), v_st_242105});
            }
            case TAG_Right: {
              V v_x_242107 = heff_field(v_x11_242104, 0);
              heff_take_n(v_x11_242104, 1ULL, 1);
              V v_t_242108 = (g_heff_2esyntax_2ecst_2elastE(v_a_241995));
              V v_e_242109 = heff_get_n(v_t_242108, 4, 9);
              V v_t_242110 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_241992, 3, 9), v_e_242109});
              V v_x_242111 = heff_tag_at_n(v_ru_24x1_242103_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_EIfThen, 2, (V[]){v_x_242101, v_x_242107}), v_t_242110});
              return heff_tag_at_n(v_ru_24x1_242097_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_242111}), v_st_242105});
            }
            default: return heff_nomatch(v_x11_242104);
            }
          }
          default: return heff_nomatch(v_x1_242103);
          }
        }
        default: return heff_nomatch(v_x11_242098);
        }
      }
      default: return heff_nomatch(v_x1_242097);
      }
    }
    case TAG_Update: {
      V v_m_242118 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_241993}));
      V v_x1_242119 = heff_tr(heff_call(v_m_242118, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_242119)) {
      case TAG_MkPair: {
        V v_x11_242120 = heff_field(v_x1_242119, 0);
        V v_st_242121 = heff_field(v_x1_242119, 1);
        V v_ru_24x1_242119_24MkPair = heff_take_reuse_n(v_x1_242119, 3ULL, 2);
        switch (heff_tag_of(v_x11_242120)) {
        case TAG_Left: {
          V v_e_242122 = heff_field(v_x11_242120, 0);
          heff_take_n(v_x11_242120, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_241992, 9);
          heff_drop(v_a_241995);
          return heff_tag_at_n(v_ru_24x1_242119_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242122}), v_st_242121});
        }
        case TAG_Right: {
          V v_x_242123 = heff_field(v_x11_242120, 0);
          heff_take_n(v_x11_242120, 1ULL, 1);
          V v_m_242124 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_a_241995)}));
          V v_x1_242125 = heff_tr(heff_call(v_m_242124, 1, (V[]){v_st_242121}));
          switch (heff_tag_of(v_x1_242125)) {
          case TAG_MkPair: {
            V v_x11_242126 = heff_field(v_x1_242125, 0);
            V v_st_242127 = heff_field(v_x1_242125, 1);
            V v_ru_24x1_242125_24MkPair = heff_take_reuse_n(v_x1_242125, 3ULL, 2);
            switch (heff_tag_of(v_x11_242126)) {
            case TAG_Left: {
              V v_e_242128 = heff_field(v_x11_242126, 0);
              heff_take_n(v_x11_242126, 1ULL, 1);
              heff_drop_rec(v_kw_241992, 9);
              heff_drop(v_a_241995);
              heff_drop(v_x_242123);
              heff_drop_cell(v_ru_24x1_242125_24MkPair, 2);
              return heff_tag_at_n(v_ru_24x1_242119_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242128}), v_st_242127});
            }
            case TAG_Right: {
              V v_x_242129 = heff_field(v_x11_242126, 0);
              heff_take_n(v_x11_242126, 1ULL, 1);
              V v_t_242130 = (g_heff_2esyntax_2ecst_2elastE(v_a_241995));
              V v_e_242131 = heff_get_n(v_t_242130, 4, 9);
              V v_t_242132 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_241992, 3, 9), v_e_242131});
              V v_x_242133 = heff_tag_at_n(v_ru_24x1_242125_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_EIfThen, 2, (V[]){v_x_242123, v_x_242129}), v_t_242132});
              return heff_tag_at_n(v_ru_24x1_242119_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_242133}), v_st_242127});
            }
            default: return heff_nomatch(v_x11_242126);
            }
          }
          default: return heff_nomatch(v_x1_242125);
          }
        }
        default: return heff_nomatch(v_x11_242120);
        }
      }
      default: return heff_nomatch(v_x1_242119);
      }
    }
    case TAG_EUSet: {
      V v_m_242137 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_241993}));
      V v_x1_242138 = heff_tr(heff_call(v_m_242137, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_242138)) {
      case TAG_MkPair: {
        V v_x11_242139 = heff_field(v_x1_242138, 0);
        V v_st_242140 = heff_field(v_x1_242138, 1);
        V v_ru_24x1_242138_24MkPair = heff_take_reuse_n(v_x1_242138, 3ULL, 2);
        switch (heff_tag_of(v_x11_242139)) {
        case TAG_Left: {
          V v_e_242141 = heff_field(v_x11_242139, 0);
          heff_take_n(v_x11_242139, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_241992, 9);
          heff_drop(v_a_241995);
          return heff_tag_at_n(v_ru_24x1_242138_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242141}), v_st_242140});
        }
        case TAG_Right: {
          V v_x_242142 = heff_field(v_x11_242139, 0);
          heff_take_n(v_x11_242139, 1ULL, 1);
          V v_m_242143 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_a_241995)}));
          V v_x1_242144 = heff_tr(heff_call(v_m_242143, 1, (V[]){v_st_242140}));
          switch (heff_tag_of(v_x1_242144)) {
          case TAG_MkPair: {
            V v_x11_242145 = heff_field(v_x1_242144, 0);
            V v_st_242146 = heff_field(v_x1_242144, 1);
            V v_ru_24x1_242144_24MkPair = heff_take_reuse_n(v_x1_242144, 3ULL, 2);
            switch (heff_tag_of(v_x11_242145)) {
            case TAG_Left: {
              V v_e_242147 = heff_field(v_x11_242145, 0);
              heff_take_n(v_x11_242145, 1ULL, 1);
              heff_drop_rec(v_kw_241992, 9);
              heff_drop(v_a_241995);
              heff_drop(v_x_242142);
              heff_drop_cell(v_ru_24x1_242144_24MkPair, 2);
              return heff_tag_at_n(v_ru_24x1_242138_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242147}), v_st_242146});
            }
            case TAG_Right: {
              V v_x_242148 = heff_field(v_x11_242145, 0);
              heff_take_n(v_x11_242145, 1ULL, 1);
              V v_t_242149 = (g_heff_2esyntax_2ecst_2elastE(v_a_241995));
              V v_e_242150 = heff_get_n(v_t_242149, 4, 9);
              V v_t_242151 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_241992, 3, 9), v_e_242150});
              V v_x_242152 = heff_tag_at_n(v_ru_24x1_242144_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_EIfThen, 2, (V[]){v_x_242142, v_x_242148}), v_t_242151});
              return heff_tag_at_n(v_ru_24x1_242138_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_242152}), v_st_242146});
            }
            default: return heff_nomatch(v_x11_242145);
            }
          }
          default: return heff_nomatch(v_x1_242144);
          }
        }
        default: return heff_nomatch(v_x11_242139);
        }
      }
      default: return heff_nomatch(v_x1_242138);
      }
    }
    case TAG_InstB: {
      V v_m_242158 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_241993}));
      V v_x1_242159 = heff_tr(heff_call(v_m_242158, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_242159)) {
      case TAG_MkPair: {
        V v_x11_242160 = heff_field(v_x1_242159, 0);
        V v_st_242161 = heff_field(v_x1_242159, 1);
        V v_ru_24x1_242159_24MkPair = heff_take_reuse_n(v_x1_242159, 3ULL, 2);
        switch (heff_tag_of(v_x11_242160)) {
        case TAG_Left: {
          V v_e_242162 = heff_field(v_x11_242160, 0);
          heff_take_n(v_x11_242160, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_241992, 9);
          heff_drop(v_a_241995);
          return heff_tag_at_n(v_ru_24x1_242159_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242162}), v_st_242161});
        }
        case TAG_Right: {
          V v_x_242163 = heff_field(v_x11_242160, 0);
          heff_take_n(v_x11_242160, 1ULL, 1);
          V v_m_242164 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_a_241995)}));
          V v_x1_242165 = heff_tr(heff_call(v_m_242164, 1, (V[]){v_st_242161}));
          switch (heff_tag_of(v_x1_242165)) {
          case TAG_MkPair: {
            V v_x11_242166 = heff_field(v_x1_242165, 0);
            V v_st_242167 = heff_field(v_x1_242165, 1);
            V v_ru_24x1_242165_24MkPair = heff_take_reuse_n(v_x1_242165, 3ULL, 2);
            switch (heff_tag_of(v_x11_242166)) {
            case TAG_Left: {
              V v_e_242168 = heff_field(v_x11_242166, 0);
              heff_take_n(v_x11_242166, 1ULL, 1);
              heff_drop_rec(v_kw_241992, 9);
              heff_drop(v_a_241995);
              heff_drop(v_x_242163);
              heff_drop_cell(v_ru_24x1_242165_24MkPair, 2);
              return heff_tag_at_n(v_ru_24x1_242159_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242168}), v_st_242167});
            }
            case TAG_Right: {
              V v_x_242169 = heff_field(v_x11_242166, 0);
              heff_take_n(v_x11_242166, 1ULL, 1);
              V v_t_242170 = (g_heff_2esyntax_2ecst_2elastE(v_a_241995));
              V v_e_242171 = heff_get_n(v_t_242170, 4, 9);
              V v_t_242172 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_241992, 3, 9), v_e_242171});
              V v_x_242173 = heff_tag_at_n(v_ru_24x1_242165_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_EIfThen, 2, (V[]){v_x_242163, v_x_242169}), v_t_242172});
              return heff_tag_at_n(v_ru_24x1_242159_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_242173}), v_st_242167});
            }
            default: return heff_nomatch(v_x11_242166);
            }
          }
          default: return heff_nomatch(v_x1_242165);
          }
        }
        default: return heff_nomatch(v_x11_242160);
        }
      }
      default: return heff_nomatch(v_x1_242159);
      }
    }
    case TAG_EFSet: {
      V v_m_242177 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_241993}));
      V v_x1_242178 = heff_tr(heff_call(v_m_242177, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_242178)) {
      case TAG_MkPair: {
        V v_x11_242179 = heff_field(v_x1_242178, 0);
        V v_st_242180 = heff_field(v_x1_242178, 1);
        V v_ru_24x1_242178_24MkPair = heff_take_reuse_n(v_x1_242178, 3ULL, 2);
        switch (heff_tag_of(v_x11_242179)) {
        case TAG_Left: {
          V v_e_242181 = heff_field(v_x11_242179, 0);
          heff_take_n(v_x11_242179, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_241992, 9);
          heff_drop(v_a_241995);
          return heff_tag_at_n(v_ru_24x1_242178_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242181}), v_st_242180});
        }
        case TAG_Right: {
          V v_x_242182 = heff_field(v_x11_242179, 0);
          heff_take_n(v_x11_242179, 1ULL, 1);
          V v_m_242183 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_a_241995)}));
          V v_x1_242184 = heff_tr(heff_call(v_m_242183, 1, (V[]){v_st_242180}));
          switch (heff_tag_of(v_x1_242184)) {
          case TAG_MkPair: {
            V v_x11_242185 = heff_field(v_x1_242184, 0);
            V v_st_242186 = heff_field(v_x1_242184, 1);
            V v_ru_24x1_242184_24MkPair = heff_take_reuse_n(v_x1_242184, 3ULL, 2);
            switch (heff_tag_of(v_x11_242185)) {
            case TAG_Left: {
              V v_e_242187 = heff_field(v_x11_242185, 0);
              heff_take_n(v_x11_242185, 1ULL, 1);
              heff_drop_rec(v_kw_241992, 9);
              heff_drop(v_a_241995);
              heff_drop(v_x_242182);
              heff_drop_cell(v_ru_24x1_242184_24MkPair, 2);
              return heff_tag_at_n(v_ru_24x1_242178_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242187}), v_st_242186});
            }
            case TAG_Right: {
              V v_x_242188 = heff_field(v_x11_242185, 0);
              heff_take_n(v_x11_242185, 1ULL, 1);
              V v_t_242189 = (g_heff_2esyntax_2ecst_2elastE(v_a_241995));
              V v_e_242190 = heff_get_n(v_t_242189, 4, 9);
              V v_t_242191 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_241992, 3, 9), v_e_242190});
              V v_x_242192 = heff_tag_at_n(v_ru_24x1_242184_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_EIfThen, 2, (V[]){v_x_242182, v_x_242188}), v_t_242191});
              return heff_tag_at_n(v_ru_24x1_242178_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_242192}), v_st_242186});
            }
            default: return heff_nomatch(v_x11_242185);
            }
          }
          default: return heff_nomatch(v_x1_242184);
          }
        }
        default: return heff_nomatch(v_x11_242179);
        }
      }
      default: return heff_nomatch(v_x1_242178);
      }
    }
    case TAG_EFDefault: {
      V v_m_242196 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_241993}));
      V v_x1_242197 = heff_tr(heff_call(v_m_242196, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_242197)) {
      case TAG_MkPair: {
        V v_x11_242198 = heff_field(v_x1_242197, 0);
        V v_st_242199 = heff_field(v_x1_242197, 1);
        V v_ru_24x1_242197_24MkPair = heff_take_reuse_n(v_x1_242197, 3ULL, 2);
        switch (heff_tag_of(v_x11_242198)) {
        case TAG_Left: {
          V v_e_242200 = heff_field(v_x11_242198, 0);
          heff_take_n(v_x11_242198, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_241992, 9);
          heff_drop(v_a_241995);
          return heff_tag_at_n(v_ru_24x1_242197_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242200}), v_st_242199});
        }
        case TAG_Right: {
          V v_x_242201 = heff_field(v_x11_242198, 0);
          heff_take_n(v_x11_242198, 1ULL, 1);
          V v_m_242202 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_a_241995)}));
          V v_x1_242203 = heff_tr(heff_call(v_m_242202, 1, (V[]){v_st_242199}));
          switch (heff_tag_of(v_x1_242203)) {
          case TAG_MkPair: {
            V v_x11_242204 = heff_field(v_x1_242203, 0);
            V v_st_242205 = heff_field(v_x1_242203, 1);
            V v_ru_24x1_242203_24MkPair = heff_take_reuse_n(v_x1_242203, 3ULL, 2);
            switch (heff_tag_of(v_x11_242204)) {
            case TAG_Left: {
              V v_e_242206 = heff_field(v_x11_242204, 0);
              heff_take_n(v_x11_242204, 1ULL, 1);
              heff_drop_rec(v_kw_241992, 9);
              heff_drop(v_a_241995);
              heff_drop(v_x_242201);
              heff_drop_cell(v_ru_24x1_242203_24MkPair, 2);
              return heff_tag_at_n(v_ru_24x1_242197_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242206}), v_st_242205});
            }
            case TAG_Right: {
              V v_x_242207 = heff_field(v_x11_242204, 0);
              heff_take_n(v_x11_242204, 1ULL, 1);
              V v_t_242208 = (g_heff_2esyntax_2ecst_2elastE(v_a_241995));
              V v_e_242209 = heff_get_n(v_t_242208, 4, 9);
              V v_t_242210 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_241992, 3, 9), v_e_242209});
              V v_x_242211 = heff_tag_at_n(v_ru_24x1_242203_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_EIfThen, 2, (V[]){v_x_242201, v_x_242207}), v_t_242210});
              return heff_tag_at_n(v_ru_24x1_242197_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_242211}), v_st_242205});
            }
            default: return heff_nomatch(v_x11_242204);
            }
          }
          default: return heff_nomatch(v_x1_242203);
          }
        }
        default: return heff_nomatch(v_x11_242198);
        }
      }
      default: return heff_nomatch(v_x1_242197);
      }
    }
    case TAG_Sum: {
      V v_m_242217 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_241993}));
      V v_x1_242218 = heff_tr(heff_call(v_m_242217, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_242218)) {
      case TAG_MkPair: {
        V v_x11_242219 = heff_field(v_x1_242218, 0);
        V v_st_242220 = heff_field(v_x1_242218, 1);
        V v_ru_24x1_242218_24MkPair = heff_take_reuse_n(v_x1_242218, 3ULL, 2);
        switch (heff_tag_of(v_x11_242219)) {
        case TAG_Left: {
          V v_e_242221 = heff_field(v_x11_242219, 0);
          heff_take_n(v_x11_242219, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_241992, 9);
          heff_drop(v_a_241995);
          return heff_tag_at_n(v_ru_24x1_242218_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242221}), v_st_242220});
        }
        case TAG_Right: {
          V v_x_242222 = heff_field(v_x11_242219, 0);
          heff_take_n(v_x11_242219, 1ULL, 1);
          V v_m_242223 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_a_241995)}));
          V v_x1_242224 = heff_tr(heff_call(v_m_242223, 1, (V[]){v_st_242220}));
          switch (heff_tag_of(v_x1_242224)) {
          case TAG_MkPair: {
            V v_x11_242225 = heff_field(v_x1_242224, 0);
            V v_st_242226 = heff_field(v_x1_242224, 1);
            V v_ru_24x1_242224_24MkPair = heff_take_reuse_n(v_x1_242224, 3ULL, 2);
            switch (heff_tag_of(v_x11_242225)) {
            case TAG_Left: {
              V v_e_242227 = heff_field(v_x11_242225, 0);
              heff_take_n(v_x11_242225, 1ULL, 1);
              heff_drop_rec(v_kw_241992, 9);
              heff_drop(v_a_241995);
              heff_drop(v_x_242222);
              heff_drop_cell(v_ru_24x1_242224_24MkPair, 2);
              return heff_tag_at_n(v_ru_24x1_242218_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242227}), v_st_242226});
            }
            case TAG_Right: {
              V v_x_242228 = heff_field(v_x11_242225, 0);
              heff_take_n(v_x11_242225, 1ULL, 1);
              V v_t_242229 = (g_heff_2esyntax_2ecst_2elastE(v_a_241995));
              V v_e_242230 = heff_get_n(v_t_242229, 4, 9);
              V v_t_242231 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_241992, 3, 9), v_e_242230});
              V v_x_242232 = heff_tag_at_n(v_ru_24x1_242224_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_EIfThen, 2, (V[]){v_x_242222, v_x_242228}), v_t_242231});
              return heff_tag_at_n(v_ru_24x1_242218_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_242232}), v_st_242226});
            }
            default: return heff_nomatch(v_x11_242225);
            }
          }
          default: return heff_nomatch(v_x1_242224);
          }
        }
        default: return heff_nomatch(v_x11_242219);
        }
      }
      default: return heff_nomatch(v_x1_242218);
      }
    }
    case TAG_ECon: {
      V v_m_242235 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_241993}));
      V v_x1_242236 = heff_tr(heff_call(v_m_242235, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_242236)) {
      case TAG_MkPair: {
        V v_x11_242237 = heff_field(v_x1_242236, 0);
        V v_st_242238 = heff_field(v_x1_242236, 1);
        V v_ru_24x1_242236_24MkPair = heff_take_reuse_n(v_x1_242236, 3ULL, 2);
        switch (heff_tag_of(v_x11_242237)) {
        case TAG_Left: {
          V v_e_242239 = heff_field(v_x11_242237, 0);
          heff_take_n(v_x11_242237, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_241992, 9);
          heff_drop(v_a_241995);
          return heff_tag_at_n(v_ru_24x1_242236_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242239}), v_st_242238});
        }
        case TAG_Right: {
          V v_x_242240 = heff_field(v_x11_242237, 0);
          heff_take_n(v_x11_242237, 1ULL, 1);
          V v_m_242241 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_a_241995)}));
          V v_x1_242242 = heff_tr(heff_call(v_m_242241, 1, (V[]){v_st_242238}));
          switch (heff_tag_of(v_x1_242242)) {
          case TAG_MkPair: {
            V v_x11_242243 = heff_field(v_x1_242242, 0);
            V v_st_242244 = heff_field(v_x1_242242, 1);
            V v_ru_24x1_242242_24MkPair = heff_take_reuse_n(v_x1_242242, 3ULL, 2);
            switch (heff_tag_of(v_x11_242243)) {
            case TAG_Left: {
              V v_e_242245 = heff_field(v_x11_242243, 0);
              heff_take_n(v_x11_242243, 1ULL, 1);
              heff_drop_rec(v_kw_241992, 9);
              heff_drop(v_a_241995);
              heff_drop(v_x_242240);
              heff_drop_cell(v_ru_24x1_242242_24MkPair, 2);
              return heff_tag_at_n(v_ru_24x1_242236_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242245}), v_st_242244});
            }
            case TAG_Right: {
              V v_x_242246 = heff_field(v_x11_242243, 0);
              heff_take_n(v_x11_242243, 1ULL, 1);
              V v_t_242247 = (g_heff_2esyntax_2ecst_2elastE(v_a_241995));
              V v_e_242248 = heff_get_n(v_t_242247, 4, 9);
              V v_t_242249 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_241992, 3, 9), v_e_242248});
              V v_x_242250 = heff_tag_at_n(v_ru_24x1_242242_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_EIfThen, 2, (V[]){v_x_242240, v_x_242246}), v_t_242249});
              return heff_tag_at_n(v_ru_24x1_242236_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_242250}), v_st_242244});
            }
            default: return heff_nomatch(v_x11_242243);
            }
          }
          default: return heff_nomatch(v_x1_242242);
          }
        }
        default: return heff_nomatch(v_x11_242237);
        }
      }
      default: return heff_nomatch(v_x1_242236);
      }
    }
    case TAG_EField: {
      V v_m_242253 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_241993}));
      V v_x1_242254 = heff_tr(heff_call(v_m_242253, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_242254)) {
      case TAG_MkPair: {
        V v_x11_242255 = heff_field(v_x1_242254, 0);
        V v_st_242256 = heff_field(v_x1_242254, 1);
        V v_ru_24x1_242254_24MkPair = heff_take_reuse_n(v_x1_242254, 3ULL, 2);
        switch (heff_tag_of(v_x11_242255)) {
        case TAG_Left: {
          V v_e_242257 = heff_field(v_x11_242255, 0);
          heff_take_n(v_x11_242255, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_241992, 9);
          heff_drop(v_a_241995);
          return heff_tag_at_n(v_ru_24x1_242254_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242257}), v_st_242256});
        }
        case TAG_Right: {
          V v_x_242258 = heff_field(v_x11_242255, 0);
          heff_take_n(v_x11_242255, 1ULL, 1);
          V v_m_242259 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_a_241995)}));
          V v_x1_242260 = heff_tr(heff_call(v_m_242259, 1, (V[]){v_st_242256}));
          switch (heff_tag_of(v_x1_242260)) {
          case TAG_MkPair: {
            V v_x11_242261 = heff_field(v_x1_242260, 0);
            V v_st_242262 = heff_field(v_x1_242260, 1);
            V v_ru_24x1_242260_24MkPair = heff_take_reuse_n(v_x1_242260, 3ULL, 2);
            switch (heff_tag_of(v_x11_242261)) {
            case TAG_Left: {
              V v_e_242263 = heff_field(v_x11_242261, 0);
              heff_take_n(v_x11_242261, 1ULL, 1);
              heff_drop_rec(v_kw_241992, 9);
              heff_drop(v_a_241995);
              heff_drop(v_x_242258);
              heff_drop_cell(v_ru_24x1_242260_24MkPair, 2);
              return heff_tag_at_n(v_ru_24x1_242254_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242263}), v_st_242262});
            }
            case TAG_Right: {
              V v_x_242264 = heff_field(v_x11_242261, 0);
              heff_take_n(v_x11_242261, 1ULL, 1);
              V v_t_242265 = (g_heff_2esyntax_2ecst_2elastE(v_a_241995));
              V v_e_242266 = heff_get_n(v_t_242265, 4, 9);
              V v_t_242267 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_241992, 3, 9), v_e_242266});
              V v_x_242268 = heff_tag_at_n(v_ru_24x1_242260_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_EIfThen, 2, (V[]){v_x_242258, v_x_242264}), v_t_242267});
              return heff_tag_at_n(v_ru_24x1_242254_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_242268}), v_st_242262});
            }
            default: return heff_nomatch(v_x11_242261);
            }
          }
          default: return heff_nomatch(v_x1_242260);
          }
        }
        default: return heff_nomatch(v_x11_242255);
        }
      }
      default: return heff_nomatch(v_x1_242254);
      }
    }
    case TAG_ENeg: {
      V v_m_242271 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_241993}));
      V v_x1_242272 = heff_tr(heff_call(v_m_242271, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_242272)) {
      case TAG_MkPair: {
        V v_x11_242273 = heff_field(v_x1_242272, 0);
        V v_st_242274 = heff_field(v_x1_242272, 1);
        V v_ru_24x1_242272_24MkPair = heff_take_reuse_n(v_x1_242272, 3ULL, 2);
        switch (heff_tag_of(v_x11_242273)) {
        case TAG_Left: {
          V v_e_242275 = heff_field(v_x11_242273, 0);
          heff_take_n(v_x11_242273, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_241992, 9);
          heff_drop(v_a_241995);
          return heff_tag_at_n(v_ru_24x1_242272_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242275}), v_st_242274});
        }
        case TAG_Right: {
          V v_x_242276 = heff_field(v_x11_242273, 0);
          heff_take_n(v_x11_242273, 1ULL, 1);
          V v_m_242277 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_a_241995)}));
          V v_x1_242278 = heff_tr(heff_call(v_m_242277, 1, (V[]){v_st_242274}));
          switch (heff_tag_of(v_x1_242278)) {
          case TAG_MkPair: {
            V v_x11_242279 = heff_field(v_x1_242278, 0);
            V v_st_242280 = heff_field(v_x1_242278, 1);
            V v_ru_24x1_242278_24MkPair = heff_take_reuse_n(v_x1_242278, 3ULL, 2);
            switch (heff_tag_of(v_x11_242279)) {
            case TAG_Left: {
              V v_e_242281 = heff_field(v_x11_242279, 0);
              heff_take_n(v_x11_242279, 1ULL, 1);
              heff_drop_rec(v_kw_241992, 9);
              heff_drop(v_a_241995);
              heff_drop(v_x_242276);
              heff_drop_cell(v_ru_24x1_242278_24MkPair, 2);
              return heff_tag_at_n(v_ru_24x1_242272_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242281}), v_st_242280});
            }
            case TAG_Right: {
              V v_x_242282 = heff_field(v_x11_242279, 0);
              heff_take_n(v_x11_242279, 1ULL, 1);
              V v_t_242283 = (g_heff_2esyntax_2ecst_2elastE(v_a_241995));
              V v_e_242284 = heff_get_n(v_t_242283, 4, 9);
              V v_t_242285 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_241992, 3, 9), v_e_242284});
              V v_x_242286 = heff_tag_at_n(v_ru_24x1_242278_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_EIfThen, 2, (V[]){v_x_242276, v_x_242282}), v_t_242285});
              return heff_tag_at_n(v_ru_24x1_242272_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_242286}), v_st_242280});
            }
            default: return heff_nomatch(v_x11_242279);
            }
          }
          default: return heff_nomatch(v_x1_242278);
          }
        }
        default: return heff_nomatch(v_x11_242273);
        }
      }
      default: return heff_nomatch(v_x1_242272);
      }
    }
    case TAG_App: {
      V v_m_242289 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_241993}));
      V v_x1_242290 = heff_tr(heff_call(v_m_242289, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_242290)) {
      case TAG_MkPair: {
        V v_x11_242291 = heff_field(v_x1_242290, 0);
        V v_st_242292 = heff_field(v_x1_242290, 1);
        V v_ru_24x1_242290_24MkPair = heff_take_reuse_n(v_x1_242290, 3ULL, 2);
        switch (heff_tag_of(v_x11_242291)) {
        case TAG_Left: {
          V v_e_242293 = heff_field(v_x11_242291, 0);
          heff_take_n(v_x11_242291, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_241992, 9);
          heff_drop(v_a_241995);
          return heff_tag_at_n(v_ru_24x1_242290_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242293}), v_st_242292});
        }
        case TAG_Right: {
          V v_x_242294 = heff_field(v_x11_242291, 0);
          heff_take_n(v_x11_242291, 1ULL, 1);
          V v_m_242295 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_a_241995)}));
          V v_x1_242296 = heff_tr(heff_call(v_m_242295, 1, (V[]){v_st_242292}));
          switch (heff_tag_of(v_x1_242296)) {
          case TAG_MkPair: {
            V v_x11_242297 = heff_field(v_x1_242296, 0);
            V v_st_242298 = heff_field(v_x1_242296, 1);
            V v_ru_24x1_242296_24MkPair = heff_take_reuse_n(v_x1_242296, 3ULL, 2);
            switch (heff_tag_of(v_x11_242297)) {
            case TAG_Left: {
              V v_e_242299 = heff_field(v_x11_242297, 0);
              heff_take_n(v_x11_242297, 1ULL, 1);
              heff_drop_rec(v_kw_241992, 9);
              heff_drop(v_a_241995);
              heff_drop(v_x_242294);
              heff_drop_cell(v_ru_24x1_242296_24MkPair, 2);
              return heff_tag_at_n(v_ru_24x1_242290_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242299}), v_st_242298});
            }
            case TAG_Right: {
              V v_x_242300 = heff_field(v_x11_242297, 0);
              heff_take_n(v_x11_242297, 1ULL, 1);
              V v_t_242301 = (g_heff_2esyntax_2ecst_2elastE(v_a_241995));
              V v_e_242302 = heff_get_n(v_t_242301, 4, 9);
              V v_t_242303 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_241992, 3, 9), v_e_242302});
              V v_x_242304 = heff_tag_at_n(v_ru_24x1_242296_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_EIfThen, 2, (V[]){v_x_242294, v_x_242300}), v_t_242303});
              return heff_tag_at_n(v_ru_24x1_242290_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_242304}), v_st_242298});
            }
            default: return heff_nomatch(v_x11_242297);
            }
          }
          default: return heff_nomatch(v_x1_242296);
          }
        }
        default: return heff_nomatch(v_x11_242291);
        }
      }
      default: return heff_nomatch(v_x1_242290);
      }
    }
    case TAG_Op: {
      V v_m_242308 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_241993}));
      V v_x1_242309 = heff_tr(heff_call(v_m_242308, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_242309)) {
      case TAG_MkPair: {
        V v_x11_242310 = heff_field(v_x1_242309, 0);
        V v_st_242311 = heff_field(v_x1_242309, 1);
        V v_ru_24x1_242309_24MkPair = heff_take_reuse_n(v_x1_242309, 3ULL, 2);
        switch (heff_tag_of(v_x11_242310)) {
        case TAG_Left: {
          V v_e_242312 = heff_field(v_x11_242310, 0);
          heff_take_n(v_x11_242310, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_241992, 9);
          heff_drop(v_a_241995);
          return heff_tag_at_n(v_ru_24x1_242309_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242312}), v_st_242311});
        }
        case TAG_Right: {
          V v_x_242313 = heff_field(v_x11_242310, 0);
          heff_take_n(v_x11_242310, 1ULL, 1);
          V v_m_242314 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_a_241995)}));
          V v_x1_242315 = heff_tr(heff_call(v_m_242314, 1, (V[]){v_st_242311}));
          switch (heff_tag_of(v_x1_242315)) {
          case TAG_MkPair: {
            V v_x11_242316 = heff_field(v_x1_242315, 0);
            V v_st_242317 = heff_field(v_x1_242315, 1);
            V v_ru_24x1_242315_24MkPair = heff_take_reuse_n(v_x1_242315, 3ULL, 2);
            switch (heff_tag_of(v_x11_242316)) {
            case TAG_Left: {
              V v_e_242318 = heff_field(v_x11_242316, 0);
              heff_take_n(v_x11_242316, 1ULL, 1);
              heff_drop_rec(v_kw_241992, 9);
              heff_drop(v_a_241995);
              heff_drop(v_x_242313);
              heff_drop_cell(v_ru_24x1_242315_24MkPair, 2);
              return heff_tag_at_n(v_ru_24x1_242309_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242318}), v_st_242317});
            }
            case TAG_Right: {
              V v_x_242319 = heff_field(v_x11_242316, 0);
              heff_take_n(v_x11_242316, 1ULL, 1);
              V v_t_242320 = (g_heff_2esyntax_2ecst_2elastE(v_a_241995));
              V v_e_242321 = heff_get_n(v_t_242320, 4, 9);
              V v_t_242322 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_241992, 3, 9), v_e_242321});
              V v_x_242323 = heff_tag_at_n(v_ru_24x1_242315_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_EIfThen, 2, (V[]){v_x_242313, v_x_242319}), v_t_242322});
              return heff_tag_at_n(v_ru_24x1_242309_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_242323}), v_st_242317});
            }
            default: return heff_nomatch(v_x11_242316);
            }
          }
          default: return heff_nomatch(v_x1_242315);
          }
        }
        default: return heff_nomatch(v_x11_242310);
        }
      }
      default: return heff_nomatch(v_x1_242309);
      }
    }
    case TAG_Ops: {
      V v_m_242326 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_241993}));
      V v_x1_242327 = heff_tr(heff_call(v_m_242326, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_242327)) {
      case TAG_MkPair: {
        V v_x11_242328 = heff_field(v_x1_242327, 0);
        V v_st_242329 = heff_field(v_x1_242327, 1);
        V v_ru_24x1_242327_24MkPair = heff_take_reuse_n(v_x1_242327, 3ULL, 2);
        switch (heff_tag_of(v_x11_242328)) {
        case TAG_Left: {
          V v_e_242330 = heff_field(v_x11_242328, 0);
          heff_take_n(v_x11_242328, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_241992, 9);
          heff_drop(v_a_241995);
          return heff_tag_at_n(v_ru_24x1_242327_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242330}), v_st_242329});
        }
        case TAG_Right: {
          V v_x_242331 = heff_field(v_x11_242328, 0);
          heff_take_n(v_x11_242328, 1ULL, 1);
          V v_m_242332 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_a_241995)}));
          V v_x1_242333 = heff_tr(heff_call(v_m_242332, 1, (V[]){v_st_242329}));
          switch (heff_tag_of(v_x1_242333)) {
          case TAG_MkPair: {
            V v_x11_242334 = heff_field(v_x1_242333, 0);
            V v_st_242335 = heff_field(v_x1_242333, 1);
            V v_ru_24x1_242333_24MkPair = heff_take_reuse_n(v_x1_242333, 3ULL, 2);
            switch (heff_tag_of(v_x11_242334)) {
            case TAG_Left: {
              V v_e_242336 = heff_field(v_x11_242334, 0);
              heff_take_n(v_x11_242334, 1ULL, 1);
              heff_drop_rec(v_kw_241992, 9);
              heff_drop(v_a_241995);
              heff_drop(v_x_242331);
              heff_drop_cell(v_ru_24x1_242333_24MkPair, 2);
              return heff_tag_at_n(v_ru_24x1_242327_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242336}), v_st_242335});
            }
            case TAG_Right: {
              V v_x_242337 = heff_field(v_x11_242334, 0);
              heff_take_n(v_x11_242334, 1ULL, 1);
              V v_t_242338 = (g_heff_2esyntax_2ecst_2elastE(v_a_241995));
              V v_e_242339 = heff_get_n(v_t_242338, 4, 9);
              V v_t_242340 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_241992, 3, 9), v_e_242339});
              V v_x_242341 = heff_tag_at_n(v_ru_24x1_242333_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_EIfThen, 2, (V[]){v_x_242331, v_x_242337}), v_t_242340});
              return heff_tag_at_n(v_ru_24x1_242327_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_242341}), v_st_242335});
            }
            default: return heff_nomatch(v_x11_242334);
            }
          }
          default: return heff_nomatch(v_x1_242333);
          }
        }
        default: return heff_nomatch(v_x11_242328);
        }
      }
      default: return heff_nomatch(v_x1_242327);
      }
    }
    case TAG_OpRhs: {
      V v_m_242344 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_241993}));
      V v_x1_242345 = heff_tr(heff_call(v_m_242344, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_242345)) {
      case TAG_MkPair: {
        V v_x11_242346 = heff_field(v_x1_242345, 0);
        V v_st_242347 = heff_field(v_x1_242345, 1);
        V v_ru_24x1_242345_24MkPair = heff_take_reuse_n(v_x1_242345, 3ULL, 2);
        switch (heff_tag_of(v_x11_242346)) {
        case TAG_Left: {
          V v_e_242348 = heff_field(v_x11_242346, 0);
          heff_take_n(v_x11_242346, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_241992, 9);
          heff_drop(v_a_241995);
          return heff_tag_at_n(v_ru_24x1_242345_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242348}), v_st_242347});
        }
        case TAG_Right: {
          V v_x_242349 = heff_field(v_x11_242346, 0);
          heff_take_n(v_x11_242346, 1ULL, 1);
          V v_m_242350 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_a_241995)}));
          V v_x1_242351 = heff_tr(heff_call(v_m_242350, 1, (V[]){v_st_242347}));
          switch (heff_tag_of(v_x1_242351)) {
          case TAG_MkPair: {
            V v_x11_242352 = heff_field(v_x1_242351, 0);
            V v_st_242353 = heff_field(v_x1_242351, 1);
            V v_ru_24x1_242351_24MkPair = heff_take_reuse_n(v_x1_242351, 3ULL, 2);
            switch (heff_tag_of(v_x11_242352)) {
            case TAG_Left: {
              V v_e_242354 = heff_field(v_x11_242352, 0);
              heff_take_n(v_x11_242352, 1ULL, 1);
              heff_drop_rec(v_kw_241992, 9);
              heff_drop(v_a_241995);
              heff_drop(v_x_242349);
              heff_drop_cell(v_ru_24x1_242351_24MkPair, 2);
              return heff_tag_at_n(v_ru_24x1_242345_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242354}), v_st_242353});
            }
            case TAG_Right: {
              V v_x_242355 = heff_field(v_x11_242352, 0);
              heff_take_n(v_x11_242352, 1ULL, 1);
              V v_t_242356 = (g_heff_2esyntax_2ecst_2elastE(v_a_241995));
              V v_e_242357 = heff_get_n(v_t_242356, 4, 9);
              V v_t_242358 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_241992, 3, 9), v_e_242357});
              V v_x_242359 = heff_tag_at_n(v_ru_24x1_242351_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_EIfThen, 2, (V[]){v_x_242349, v_x_242355}), v_t_242358});
              return heff_tag_at_n(v_ru_24x1_242345_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_242359}), v_st_242353});
            }
            default: return heff_nomatch(v_x11_242352);
            }
          }
          default: return heff_nomatch(v_x1_242351);
          }
        }
        default: return heff_nomatch(v_x11_242346);
        }
      }
      default: return heff_nomatch(v_x1_242345);
      }
    }
    case TAG_Ann: {
      V v_m_242363 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_241993}));
      V v_x1_242364 = heff_tr(heff_call(v_m_242363, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_242364)) {
      case TAG_MkPair: {
        V v_x11_242365 = heff_field(v_x1_242364, 0);
        V v_st_242366 = heff_field(v_x1_242364, 1);
        V v_ru_24x1_242364_24MkPair = heff_take_reuse_n(v_x1_242364, 3ULL, 2);
        switch (heff_tag_of(v_x11_242365)) {
        case TAG_Left: {
          V v_e_242367 = heff_field(v_x11_242365, 0);
          heff_take_n(v_x11_242365, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_241992, 9);
          heff_drop(v_a_241995);
          return heff_tag_at_n(v_ru_24x1_242364_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242367}), v_st_242366});
        }
        case TAG_Right: {
          V v_x_242368 = heff_field(v_x11_242365, 0);
          heff_take_n(v_x11_242365, 1ULL, 1);
          V v_m_242369 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_a_241995)}));
          V v_x1_242370 = heff_tr(heff_call(v_m_242369, 1, (V[]){v_st_242366}));
          switch (heff_tag_of(v_x1_242370)) {
          case TAG_MkPair: {
            V v_x11_242371 = heff_field(v_x1_242370, 0);
            V v_st_242372 = heff_field(v_x1_242370, 1);
            V v_ru_24x1_242370_24MkPair = heff_take_reuse_n(v_x1_242370, 3ULL, 2);
            switch (heff_tag_of(v_x11_242371)) {
            case TAG_Left: {
              V v_e_242373 = heff_field(v_x11_242371, 0);
              heff_take_n(v_x11_242371, 1ULL, 1);
              heff_drop_rec(v_kw_241992, 9);
              heff_drop(v_a_241995);
              heff_drop(v_x_242368);
              heff_drop_cell(v_ru_24x1_242370_24MkPair, 2);
              return heff_tag_at_n(v_ru_24x1_242364_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242373}), v_st_242372});
            }
            case TAG_Right: {
              V v_x_242374 = heff_field(v_x11_242371, 0);
              heff_take_n(v_x11_242371, 1ULL, 1);
              V v_t_242375 = (g_heff_2esyntax_2ecst_2elastE(v_a_241995));
              V v_e_242376 = heff_get_n(v_t_242375, 4, 9);
              V v_t_242377 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_241992, 3, 9), v_e_242376});
              V v_x_242378 = heff_tag_at_n(v_ru_24x1_242370_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_EIfThen, 2, (V[]){v_x_242368, v_x_242374}), v_t_242377});
              return heff_tag_at_n(v_ru_24x1_242364_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_242378}), v_st_242372});
            }
            default: return heff_nomatch(v_x11_242371);
            }
          }
          default: return heff_nomatch(v_x1_242370);
          }
        }
        default: return heff_nomatch(v_x11_242365);
        }
      }
      default: return heff_nomatch(v_x1_242364);
      }
    }
    case TAG_BVar: {
      V v_m_242380 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_241993}));
      V v_x1_242381 = heff_tr(heff_call(v_m_242380, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_242381)) {
      case TAG_MkPair: {
        V v_x11_242382 = heff_field(v_x1_242381, 0);
        V v_st_242383 = heff_field(v_x1_242381, 1);
        V v_ru_24x1_242381_24MkPair = heff_take_reuse_n(v_x1_242381, 3ULL, 2);
        switch (heff_tag_of(v_x11_242382)) {
        case TAG_Left: {
          V v_e_242384 = heff_field(v_x11_242382, 0);
          heff_take_n(v_x11_242382, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_241992, 9);
          heff_drop(v_a_241995);
          return heff_tag_at_n(v_ru_24x1_242381_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242384}), v_st_242383});
        }
        case TAG_Right: {
          V v_x_242385 = heff_field(v_x11_242382, 0);
          heff_take_n(v_x11_242382, 1ULL, 1);
          V v_m_242386 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_a_241995)}));
          V v_x1_242387 = heff_tr(heff_call(v_m_242386, 1, (V[]){v_st_242383}));
          switch (heff_tag_of(v_x1_242387)) {
          case TAG_MkPair: {
            V v_x11_242388 = heff_field(v_x1_242387, 0);
            V v_st_242389 = heff_field(v_x1_242387, 1);
            V v_ru_24x1_242387_24MkPair = heff_take_reuse_n(v_x1_242387, 3ULL, 2);
            switch (heff_tag_of(v_x11_242388)) {
            case TAG_Left: {
              V v_e_242390 = heff_field(v_x11_242388, 0);
              heff_take_n(v_x11_242388, 1ULL, 1);
              heff_drop_rec(v_kw_241992, 9);
              heff_drop(v_a_241995);
              heff_drop(v_x_242385);
              heff_drop_cell(v_ru_24x1_242387_24MkPair, 2);
              return heff_tag_at_n(v_ru_24x1_242381_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242390}), v_st_242389});
            }
            case TAG_Right: {
              V v_x_242391 = heff_field(v_x11_242388, 0);
              heff_take_n(v_x11_242388, 1ULL, 1);
              V v_t_242392 = (g_heff_2esyntax_2ecst_2elastE(v_a_241995));
              V v_e_242393 = heff_get_n(v_t_242392, 4, 9);
              V v_t_242394 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_241992, 3, 9), v_e_242393});
              V v_x_242395 = heff_tag_at_n(v_ru_24x1_242387_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_EIfThen, 2, (V[]){v_x_242385, v_x_242391}), v_t_242394});
              return heff_tag_at_n(v_ru_24x1_242381_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_242395}), v_st_242389});
            }
            default: return heff_nomatch(v_x11_242388);
            }
          }
          default: return heff_nomatch(v_x1_242387);
          }
        }
        default: return heff_nomatch(v_x11_242382);
        }
      }
      default: return heff_nomatch(v_x1_242381);
      }
    }
    case TAG_BImp: {
      V v_m_242399 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_241993}));
      V v_x1_242400 = heff_tr(heff_call(v_m_242399, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_242400)) {
      case TAG_MkPair: {
        V v_x11_242401 = heff_field(v_x1_242400, 0);
        V v_st_242402 = heff_field(v_x1_242400, 1);
        V v_ru_24x1_242400_24MkPair = heff_take_reuse_n(v_x1_242400, 3ULL, 2);
        switch (heff_tag_of(v_x11_242401)) {
        case TAG_Left: {
          V v_e_242403 = heff_field(v_x11_242401, 0);
          heff_take_n(v_x11_242401, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_241992, 9);
          heff_drop(v_a_241995);
          return heff_tag_at_n(v_ru_24x1_242400_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242403}), v_st_242402});
        }
        case TAG_Right: {
          V v_x_242404 = heff_field(v_x11_242401, 0);
          heff_take_n(v_x11_242401, 1ULL, 1);
          V v_m_242405 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_a_241995)}));
          V v_x1_242406 = heff_tr(heff_call(v_m_242405, 1, (V[]){v_st_242402}));
          switch (heff_tag_of(v_x1_242406)) {
          case TAG_MkPair: {
            V v_x11_242407 = heff_field(v_x1_242406, 0);
            V v_st_242408 = heff_field(v_x1_242406, 1);
            V v_ru_24x1_242406_24MkPair = heff_take_reuse_n(v_x1_242406, 3ULL, 2);
            switch (heff_tag_of(v_x11_242407)) {
            case TAG_Left: {
              V v_e_242409 = heff_field(v_x11_242407, 0);
              heff_take_n(v_x11_242407, 1ULL, 1);
              heff_drop_rec(v_kw_241992, 9);
              heff_drop(v_a_241995);
              heff_drop(v_x_242404);
              heff_drop_cell(v_ru_24x1_242406_24MkPair, 2);
              return heff_tag_at_n(v_ru_24x1_242400_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242409}), v_st_242408});
            }
            case TAG_Right: {
              V v_x_242410 = heff_field(v_x11_242407, 0);
              heff_take_n(v_x11_242407, 1ULL, 1);
              V v_t_242411 = (g_heff_2esyntax_2ecst_2elastE(v_a_241995));
              V v_e_242412 = heff_get_n(v_t_242411, 4, 9);
              V v_t_242413 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_241992, 3, 9), v_e_242412});
              V v_x_242414 = heff_tag_at_n(v_ru_24x1_242406_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_EIfThen, 2, (V[]){v_x_242404, v_x_242410}), v_t_242413});
              return heff_tag_at_n(v_ru_24x1_242400_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_242414}), v_st_242408});
            }
            default: return heff_nomatch(v_x11_242407);
            }
          }
          default: return heff_nomatch(v_x1_242406);
          }
        }
        default: return heff_nomatch(v_x11_242401);
        }
      }
      default: return heff_nomatch(v_x1_242400);
      }
    }
    case TAG_BAnn: {
      V v_m_242420 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_241993}));
      V v_x1_242421 = heff_tr(heff_call(v_m_242420, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_242421)) {
      case TAG_MkPair: {
        V v_x11_242422 = heff_field(v_x1_242421, 0);
        V v_st_242423 = heff_field(v_x1_242421, 1);
        V v_ru_24x1_242421_24MkPair = heff_take_reuse_n(v_x1_242421, 3ULL, 2);
        switch (heff_tag_of(v_x11_242422)) {
        case TAG_Left: {
          V v_e_242424 = heff_field(v_x11_242422, 0);
          heff_take_n(v_x11_242422, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_241992, 9);
          heff_drop(v_a_241995);
          return heff_tag_at_n(v_ru_24x1_242421_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242424}), v_st_242423});
        }
        case TAG_Right: {
          V v_x_242425 = heff_field(v_x11_242422, 0);
          heff_take_n(v_x11_242422, 1ULL, 1);
          V v_m_242426 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_a_241995)}));
          V v_x1_242427 = heff_tr(heff_call(v_m_242426, 1, (V[]){v_st_242423}));
          switch (heff_tag_of(v_x1_242427)) {
          case TAG_MkPair: {
            V v_x11_242428 = heff_field(v_x1_242427, 0);
            V v_st_242429 = heff_field(v_x1_242427, 1);
            V v_ru_24x1_242427_24MkPair = heff_take_reuse_n(v_x1_242427, 3ULL, 2);
            switch (heff_tag_of(v_x11_242428)) {
            case TAG_Left: {
              V v_e_242430 = heff_field(v_x11_242428, 0);
              heff_take_n(v_x11_242428, 1ULL, 1);
              heff_drop_rec(v_kw_241992, 9);
              heff_drop(v_a_241995);
              heff_drop(v_x_242425);
              heff_drop_cell(v_ru_24x1_242427_24MkPair, 2);
              return heff_tag_at_n(v_ru_24x1_242421_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242430}), v_st_242429});
            }
            case TAG_Right: {
              V v_x_242431 = heff_field(v_x11_242428, 0);
              heff_take_n(v_x11_242428, 1ULL, 1);
              V v_t_242432 = (g_heff_2esyntax_2ecst_2elastE(v_a_241995));
              V v_e_242433 = heff_get_n(v_t_242432, 4, 9);
              V v_t_242434 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_241992, 3, 9), v_e_242433});
              V v_x_242435 = heff_tag_at_n(v_ru_24x1_242427_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_EIfThen, 2, (V[]){v_x_242425, v_x_242431}), v_t_242434});
              return heff_tag_at_n(v_ru_24x1_242421_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_242435}), v_st_242429});
            }
            default: return heff_nomatch(v_x11_242428);
            }
          }
          default: return heff_nomatch(v_x1_242427);
          }
        }
        default: return heff_nomatch(v_x11_242422);
        }
      }
      default: return heff_nomatch(v_x1_242421);
      }
    }
    case TAG_Lam: {
      V v_m_242440 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_241993}));
      V v_x1_242441 = heff_tr(heff_call(v_m_242440, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_242441)) {
      case TAG_MkPair: {
        V v_x11_242442 = heff_field(v_x1_242441, 0);
        V v_st_242443 = heff_field(v_x1_242441, 1);
        V v_ru_24x1_242441_24MkPair = heff_take_reuse_n(v_x1_242441, 3ULL, 2);
        switch (heff_tag_of(v_x11_242442)) {
        case TAG_Left: {
          V v_e_242444 = heff_field(v_x11_242442, 0);
          heff_take_n(v_x11_242442, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_241992, 9);
          heff_drop(v_a_241995);
          return heff_tag_at_n(v_ru_24x1_242441_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242444}), v_st_242443});
        }
        case TAG_Right: {
          V v_x_242445 = heff_field(v_x11_242442, 0);
          heff_take_n(v_x11_242442, 1ULL, 1);
          V v_m_242446 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_a_241995)}));
          V v_x1_242447 = heff_tr(heff_call(v_m_242446, 1, (V[]){v_st_242443}));
          switch (heff_tag_of(v_x1_242447)) {
          case TAG_MkPair: {
            V v_x11_242448 = heff_field(v_x1_242447, 0);
            V v_st_242449 = heff_field(v_x1_242447, 1);
            V v_ru_24x1_242447_24MkPair = heff_take_reuse_n(v_x1_242447, 3ULL, 2);
            switch (heff_tag_of(v_x11_242448)) {
            case TAG_Left: {
              V v_e_242450 = heff_field(v_x11_242448, 0);
              heff_take_n(v_x11_242448, 1ULL, 1);
              heff_drop_rec(v_kw_241992, 9);
              heff_drop(v_a_241995);
              heff_drop(v_x_242445);
              heff_drop_cell(v_ru_24x1_242447_24MkPair, 2);
              return heff_tag_at_n(v_ru_24x1_242441_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242450}), v_st_242449});
            }
            case TAG_Right: {
              V v_x_242451 = heff_field(v_x11_242448, 0);
              heff_take_n(v_x11_242448, 1ULL, 1);
              V v_t_242452 = (g_heff_2esyntax_2ecst_2elastE(v_a_241995));
              V v_e_242453 = heff_get_n(v_t_242452, 4, 9);
              V v_t_242454 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_241992, 3, 9), v_e_242453});
              V v_x_242455 = heff_tag_at_n(v_ru_24x1_242447_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_EIfThen, 2, (V[]){v_x_242445, v_x_242451}), v_t_242454});
              return heff_tag_at_n(v_ru_24x1_242441_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_242455}), v_st_242449});
            }
            default: return heff_nomatch(v_x11_242448);
            }
          }
          default: return heff_nomatch(v_x1_242447);
          }
        }
        default: return heff_nomatch(v_x11_242442);
        }
      }
      default: return heff_nomatch(v_x1_242441);
      }
    }
    case TAG_Case: {
      V v_m_242460 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_241993}));
      V v_x1_242461 = heff_tr(heff_call(v_m_242460, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_242461)) {
      case TAG_MkPair: {
        V v_x11_242462 = heff_field(v_x1_242461, 0);
        V v_st_242463 = heff_field(v_x1_242461, 1);
        V v_ru_24x1_242461_24MkPair = heff_take_reuse_n(v_x1_242461, 3ULL, 2);
        switch (heff_tag_of(v_x11_242462)) {
        case TAG_Left: {
          V v_e_242464 = heff_field(v_x11_242462, 0);
          heff_take_n(v_x11_242462, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_241992, 9);
          heff_drop(v_a_241995);
          return heff_tag_at_n(v_ru_24x1_242461_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242464}), v_st_242463});
        }
        case TAG_Right: {
          V v_x_242465 = heff_field(v_x11_242462, 0);
          heff_take_n(v_x11_242462, 1ULL, 1);
          V v_m_242466 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_a_241995)}));
          V v_x1_242467 = heff_tr(heff_call(v_m_242466, 1, (V[]){v_st_242463}));
          switch (heff_tag_of(v_x1_242467)) {
          case TAG_MkPair: {
            V v_x11_242468 = heff_field(v_x1_242467, 0);
            V v_st_242469 = heff_field(v_x1_242467, 1);
            V v_ru_24x1_242467_24MkPair = heff_take_reuse_n(v_x1_242467, 3ULL, 2);
            switch (heff_tag_of(v_x11_242468)) {
            case TAG_Left: {
              V v_e_242470 = heff_field(v_x11_242468, 0);
              heff_take_n(v_x11_242468, 1ULL, 1);
              heff_drop_rec(v_kw_241992, 9);
              heff_drop(v_a_241995);
              heff_drop(v_x_242465);
              heff_drop_cell(v_ru_24x1_242467_24MkPair, 2);
              return heff_tag_at_n(v_ru_24x1_242461_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242470}), v_st_242469});
            }
            case TAG_Right: {
              V v_x_242471 = heff_field(v_x11_242468, 0);
              heff_take_n(v_x11_242468, 1ULL, 1);
              V v_t_242472 = (g_heff_2esyntax_2ecst_2elastE(v_a_241995));
              V v_e_242473 = heff_get_n(v_t_242472, 4, 9);
              V v_t_242474 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_241992, 3, 9), v_e_242473});
              V v_x_242475 = heff_tag_at_n(v_ru_24x1_242467_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_EIfThen, 2, (V[]){v_x_242465, v_x_242471}), v_t_242474});
              return heff_tag_at_n(v_ru_24x1_242461_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_242475}), v_st_242469});
            }
            default: return heff_nomatch(v_x11_242468);
            }
          }
          default: return heff_nomatch(v_x1_242467);
          }
        }
        default: return heff_nomatch(v_x11_242462);
        }
      }
      default: return heff_nomatch(v_x1_242461);
      }
    }
    case TAG_EAlt: {
      V v_m_242479 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_241993}));
      V v_x1_242480 = heff_tr(heff_call(v_m_242479, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_242480)) {
      case TAG_MkPair: {
        V v_x11_242481 = heff_field(v_x1_242480, 0);
        V v_st_242482 = heff_field(v_x1_242480, 1);
        V v_ru_24x1_242480_24MkPair = heff_take_reuse_n(v_x1_242480, 3ULL, 2);
        switch (heff_tag_of(v_x11_242481)) {
        case TAG_Left: {
          V v_e_242483 = heff_field(v_x11_242481, 0);
          heff_take_n(v_x11_242481, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_241992, 9);
          heff_drop(v_a_241995);
          return heff_tag_at_n(v_ru_24x1_242480_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242483}), v_st_242482});
        }
        case TAG_Right: {
          V v_x_242484 = heff_field(v_x11_242481, 0);
          heff_take_n(v_x11_242481, 1ULL, 1);
          V v_m_242485 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_a_241995)}));
          V v_x1_242486 = heff_tr(heff_call(v_m_242485, 1, (V[]){v_st_242482}));
          switch (heff_tag_of(v_x1_242486)) {
          case TAG_MkPair: {
            V v_x11_242487 = heff_field(v_x1_242486, 0);
            V v_st_242488 = heff_field(v_x1_242486, 1);
            V v_ru_24x1_242486_24MkPair = heff_take_reuse_n(v_x1_242486, 3ULL, 2);
            switch (heff_tag_of(v_x11_242487)) {
            case TAG_Left: {
              V v_e_242489 = heff_field(v_x11_242487, 0);
              heff_take_n(v_x11_242487, 1ULL, 1);
              heff_drop_rec(v_kw_241992, 9);
              heff_drop(v_a_241995);
              heff_drop(v_x_242484);
              heff_drop_cell(v_ru_24x1_242486_24MkPair, 2);
              return heff_tag_at_n(v_ru_24x1_242480_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242489}), v_st_242488});
            }
            case TAG_Right: {
              V v_x_242490 = heff_field(v_x11_242487, 0);
              heff_take_n(v_x11_242487, 1ULL, 1);
              V v_t_242491 = (g_heff_2esyntax_2ecst_2elastE(v_a_241995));
              V v_e_242492 = heff_get_n(v_t_242491, 4, 9);
              V v_t_242493 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_241992, 3, 9), v_e_242492});
              V v_x_242494 = heff_tag_at_n(v_ru_24x1_242486_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_EIfThen, 2, (V[]){v_x_242484, v_x_242490}), v_t_242493});
              return heff_tag_at_n(v_ru_24x1_242480_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_242494}), v_st_242488});
            }
            default: return heff_nomatch(v_x11_242487);
            }
          }
          default: return heff_nomatch(v_x1_242486);
          }
        }
        default: return heff_nomatch(v_x11_242481);
        }
      }
      default: return heff_nomatch(v_x1_242480);
      }
    }
    case TAG_If: {
      V v_m_242501 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_241993}));
      V v_x1_242502 = heff_tr(heff_call(v_m_242501, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_242502)) {
      case TAG_MkPair: {
        V v_x11_242503 = heff_field(v_x1_242502, 0);
        V v_st_242504 = heff_field(v_x1_242502, 1);
        V v_ru_24x1_242502_24MkPair = heff_take_reuse_n(v_x1_242502, 3ULL, 2);
        switch (heff_tag_of(v_x11_242503)) {
        case TAG_Left: {
          V v_e_242505 = heff_field(v_x11_242503, 0);
          heff_take_n(v_x11_242503, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_241992, 9);
          heff_drop(v_a_241995);
          return heff_tag_at_n(v_ru_24x1_242502_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242505}), v_st_242504});
        }
        case TAG_Right: {
          V v_x_242506 = heff_field(v_x11_242503, 0);
          heff_take_n(v_x11_242503, 1ULL, 1);
          V v_m_242507 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_a_241995)}));
          V v_x1_242508 = heff_tr(heff_call(v_m_242507, 1, (V[]){v_st_242504}));
          switch (heff_tag_of(v_x1_242508)) {
          case TAG_MkPair: {
            V v_x11_242509 = heff_field(v_x1_242508, 0);
            V v_st_242510 = heff_field(v_x1_242508, 1);
            V v_ru_24x1_242508_24MkPair = heff_take_reuse_n(v_x1_242508, 3ULL, 2);
            switch (heff_tag_of(v_x11_242509)) {
            case TAG_Left: {
              V v_e_242511 = heff_field(v_x11_242509, 0);
              heff_take_n(v_x11_242509, 1ULL, 1);
              heff_drop_rec(v_kw_241992, 9);
              heff_drop(v_a_241995);
              heff_drop(v_x_242506);
              heff_drop_cell(v_ru_24x1_242508_24MkPair, 2);
              return heff_tag_at_n(v_ru_24x1_242502_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242511}), v_st_242510});
            }
            case TAG_Right: {
              V v_x_242512 = heff_field(v_x11_242509, 0);
              heff_take_n(v_x11_242509, 1ULL, 1);
              V v_t_242513 = (g_heff_2esyntax_2ecst_2elastE(v_a_241995));
              V v_e_242514 = heff_get_n(v_t_242513, 4, 9);
              V v_t_242515 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_241992, 3, 9), v_e_242514});
              V v_x_242516 = heff_tag_at_n(v_ru_24x1_242508_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_EIfThen, 2, (V[]){v_x_242506, v_x_242512}), v_t_242515});
              return heff_tag_at_n(v_ru_24x1_242502_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_242516}), v_st_242510});
            }
            default: return heff_nomatch(v_x11_242509);
            }
          }
          default: return heff_nomatch(v_x1_242508);
          }
        }
        default: return heff_nomatch(v_x11_242503);
        }
      }
      default: return heff_nomatch(v_x1_242502);
      }
    }
    case TAG_Do: {
      V v_m_242519 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_241993}));
      V v_x1_242520 = heff_tr(heff_call(v_m_242519, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_242520)) {
      case TAG_MkPair: {
        V v_x11_242521 = heff_field(v_x1_242520, 0);
        V v_st_242522 = heff_field(v_x1_242520, 1);
        V v_ru_24x1_242520_24MkPair = heff_take_reuse_n(v_x1_242520, 3ULL, 2);
        switch (heff_tag_of(v_x11_242521)) {
        case TAG_Left: {
          V v_e_242523 = heff_field(v_x11_242521, 0);
          heff_take_n(v_x11_242521, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_241992, 9);
          heff_drop(v_a_241995);
          return heff_tag_at_n(v_ru_24x1_242520_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242523}), v_st_242522});
        }
        case TAG_Right: {
          V v_x_242524 = heff_field(v_x11_242521, 0);
          heff_take_n(v_x11_242521, 1ULL, 1);
          V v_m_242525 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_a_241995)}));
          V v_x1_242526 = heff_tr(heff_call(v_m_242525, 1, (V[]){v_st_242522}));
          switch (heff_tag_of(v_x1_242526)) {
          case TAG_MkPair: {
            V v_x11_242527 = heff_field(v_x1_242526, 0);
            V v_st_242528 = heff_field(v_x1_242526, 1);
            V v_ru_24x1_242526_24MkPair = heff_take_reuse_n(v_x1_242526, 3ULL, 2);
            switch (heff_tag_of(v_x11_242527)) {
            case TAG_Left: {
              V v_e_242529 = heff_field(v_x11_242527, 0);
              heff_take_n(v_x11_242527, 1ULL, 1);
              heff_drop_rec(v_kw_241992, 9);
              heff_drop(v_a_241995);
              heff_drop(v_x_242524);
              heff_drop_cell(v_ru_24x1_242526_24MkPair, 2);
              return heff_tag_at_n(v_ru_24x1_242520_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242529}), v_st_242528});
            }
            case TAG_Right: {
              V v_x_242530 = heff_field(v_x11_242527, 0);
              heff_take_n(v_x11_242527, 1ULL, 1);
              V v_t_242531 = (g_heff_2esyntax_2ecst_2elastE(v_a_241995));
              V v_e_242532 = heff_get_n(v_t_242531, 4, 9);
              V v_t_242533 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_241992, 3, 9), v_e_242532});
              V v_x_242534 = heff_tag_at_n(v_ru_24x1_242526_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_EIfThen, 2, (V[]){v_x_242524, v_x_242530}), v_t_242533});
              return heff_tag_at_n(v_ru_24x1_242520_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_242534}), v_st_242528});
            }
            default: return heff_nomatch(v_x11_242527);
            }
          }
          default: return heff_nomatch(v_x1_242526);
          }
        }
        default: return heff_nomatch(v_x11_242521);
        }
      }
      default: return heff_nomatch(v_x1_242520);
      }
    }
    case TAG_ESBind: {
      V v_m_242538 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_241993}));
      V v_x1_242539 = heff_tr(heff_call(v_m_242538, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_242539)) {
      case TAG_MkPair: {
        V v_x11_242540 = heff_field(v_x1_242539, 0);
        V v_st_242541 = heff_field(v_x1_242539, 1);
        V v_ru_24x1_242539_24MkPair = heff_take_reuse_n(v_x1_242539, 3ULL, 2);
        switch (heff_tag_of(v_x11_242540)) {
        case TAG_Left: {
          V v_e_242542 = heff_field(v_x11_242540, 0);
          heff_take_n(v_x11_242540, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_241992, 9);
          heff_drop(v_a_241995);
          return heff_tag_at_n(v_ru_24x1_242539_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242542}), v_st_242541});
        }
        case TAG_Right: {
          V v_x_242543 = heff_field(v_x11_242540, 0);
          heff_take_n(v_x11_242540, 1ULL, 1);
          V v_m_242544 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_a_241995)}));
          V v_x1_242545 = heff_tr(heff_call(v_m_242544, 1, (V[]){v_st_242541}));
          switch (heff_tag_of(v_x1_242545)) {
          case TAG_MkPair: {
            V v_x11_242546 = heff_field(v_x1_242545, 0);
            V v_st_242547 = heff_field(v_x1_242545, 1);
            V v_ru_24x1_242545_24MkPair = heff_take_reuse_n(v_x1_242545, 3ULL, 2);
            switch (heff_tag_of(v_x11_242546)) {
            case TAG_Left: {
              V v_e_242548 = heff_field(v_x11_242546, 0);
              heff_take_n(v_x11_242546, 1ULL, 1);
              heff_drop_rec(v_kw_241992, 9);
              heff_drop(v_a_241995);
              heff_drop(v_x_242543);
              heff_drop_cell(v_ru_24x1_242545_24MkPair, 2);
              return heff_tag_at_n(v_ru_24x1_242539_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242548}), v_st_242547});
            }
            case TAG_Right: {
              V v_x_242549 = heff_field(v_x11_242546, 0);
              heff_take_n(v_x11_242546, 1ULL, 1);
              V v_t_242550 = (g_heff_2esyntax_2ecst_2elastE(v_a_241995));
              V v_e_242551 = heff_get_n(v_t_242550, 4, 9);
              V v_t_242552 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_241992, 3, 9), v_e_242551});
              V v_x_242553 = heff_tag_at_n(v_ru_24x1_242545_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_EIfThen, 2, (V[]){v_x_242543, v_x_242549}), v_t_242552});
              return heff_tag_at_n(v_ru_24x1_242539_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_242553}), v_st_242547});
            }
            default: return heff_nomatch(v_x11_242546);
            }
          }
          default: return heff_nomatch(v_x1_242545);
          }
        }
        default: return heff_nomatch(v_x11_242540);
        }
      }
      default: return heff_nomatch(v_x1_242539);
      }
    }
    case TAG_ELet: {
      V v_m_242560 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_241993}));
      V v_x1_242561 = heff_tr(heff_call(v_m_242560, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_242561)) {
      case TAG_MkPair: {
        V v_x11_242562 = heff_field(v_x1_242561, 0);
        V v_st_242563 = heff_field(v_x1_242561, 1);
        V v_ru_24x1_242561_24MkPair = heff_take_reuse_n(v_x1_242561, 3ULL, 2);
        switch (heff_tag_of(v_x11_242562)) {
        case TAG_Left: {
          V v_e_242564 = heff_field(v_x11_242562, 0);
          heff_take_n(v_x11_242562, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_241992, 9);
          heff_drop(v_a_241995);
          return heff_tag_at_n(v_ru_24x1_242561_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242564}), v_st_242563});
        }
        case TAG_Right: {
          V v_x_242565 = heff_field(v_x11_242562, 0);
          heff_take_n(v_x11_242562, 1ULL, 1);
          V v_m_242566 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_a_241995)}));
          V v_x1_242567 = heff_tr(heff_call(v_m_242566, 1, (V[]){v_st_242563}));
          switch (heff_tag_of(v_x1_242567)) {
          case TAG_MkPair: {
            V v_x11_242568 = heff_field(v_x1_242567, 0);
            V v_st_242569 = heff_field(v_x1_242567, 1);
            V v_ru_24x1_242567_24MkPair = heff_take_reuse_n(v_x1_242567, 3ULL, 2);
            switch (heff_tag_of(v_x11_242568)) {
            case TAG_Left: {
              V v_e_242570 = heff_field(v_x11_242568, 0);
              heff_take_n(v_x11_242568, 1ULL, 1);
              heff_drop_rec(v_kw_241992, 9);
              heff_drop(v_a_241995);
              heff_drop(v_x_242565);
              heff_drop_cell(v_ru_24x1_242567_24MkPair, 2);
              return heff_tag_at_n(v_ru_24x1_242561_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242570}), v_st_242569});
            }
            case TAG_Right: {
              V v_x_242571 = heff_field(v_x11_242568, 0);
              heff_take_n(v_x11_242568, 1ULL, 1);
              V v_t_242572 = (g_heff_2esyntax_2ecst_2elastE(v_a_241995));
              V v_e_242573 = heff_get_n(v_t_242572, 4, 9);
              V v_t_242574 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_241992, 3, 9), v_e_242573});
              V v_x_242575 = heff_tag_at_n(v_ru_24x1_242567_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_EIfThen, 2, (V[]){v_x_242565, v_x_242571}), v_t_242574});
              return heff_tag_at_n(v_ru_24x1_242561_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_242575}), v_st_242569});
            }
            default: return heff_nomatch(v_x11_242568);
            }
          }
          default: return heff_nomatch(v_x1_242567);
          }
        }
        default: return heff_nomatch(v_x11_242562);
        }
      }
      default: return heff_nomatch(v_x1_242561);
      }
    }
    case TAG_ELetMut: {
      V v_m_242582 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_241993}));
      V v_x1_242583 = heff_tr(heff_call(v_m_242582, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_242583)) {
      case TAG_MkPair: {
        V v_x11_242584 = heff_field(v_x1_242583, 0);
        V v_st_242585 = heff_field(v_x1_242583, 1);
        V v_ru_24x1_242583_24MkPair = heff_take_reuse_n(v_x1_242583, 3ULL, 2);
        switch (heff_tag_of(v_x11_242584)) {
        case TAG_Left: {
          V v_e_242586 = heff_field(v_x11_242584, 0);
          heff_take_n(v_x11_242584, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_241992, 9);
          heff_drop(v_a_241995);
          return heff_tag_at_n(v_ru_24x1_242583_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242586}), v_st_242585});
        }
        case TAG_Right: {
          V v_x_242587 = heff_field(v_x11_242584, 0);
          heff_take_n(v_x11_242584, 1ULL, 1);
          V v_m_242588 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_a_241995)}));
          V v_x1_242589 = heff_tr(heff_call(v_m_242588, 1, (V[]){v_st_242585}));
          switch (heff_tag_of(v_x1_242589)) {
          case TAG_MkPair: {
            V v_x11_242590 = heff_field(v_x1_242589, 0);
            V v_st_242591 = heff_field(v_x1_242589, 1);
            V v_ru_24x1_242589_24MkPair = heff_take_reuse_n(v_x1_242589, 3ULL, 2);
            switch (heff_tag_of(v_x11_242590)) {
            case TAG_Left: {
              V v_e_242592 = heff_field(v_x11_242590, 0);
              heff_take_n(v_x11_242590, 1ULL, 1);
              heff_drop_rec(v_kw_241992, 9);
              heff_drop(v_a_241995);
              heff_drop(v_x_242587);
              heff_drop_cell(v_ru_24x1_242589_24MkPair, 2);
              return heff_tag_at_n(v_ru_24x1_242583_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242592}), v_st_242591});
            }
            case TAG_Right: {
              V v_x_242593 = heff_field(v_x11_242590, 0);
              heff_take_n(v_x11_242590, 1ULL, 1);
              V v_t_242594 = (g_heff_2esyntax_2ecst_2elastE(v_a_241995));
              V v_e_242595 = heff_get_n(v_t_242594, 4, 9);
              V v_t_242596 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_241992, 3, 9), v_e_242595});
              V v_x_242597 = heff_tag_at_n(v_ru_24x1_242589_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_EIfThen, 2, (V[]){v_x_242587, v_x_242593}), v_t_242596});
              return heff_tag_at_n(v_ru_24x1_242583_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_242597}), v_st_242591});
            }
            default: return heff_nomatch(v_x11_242590);
            }
          }
          default: return heff_nomatch(v_x1_242589);
          }
        }
        default: return heff_nomatch(v_x11_242584);
        }
      }
      default: return heff_nomatch(v_x1_242583);
      }
    }
    case TAG_EAssign: {
      V v_m_242601 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_241993}));
      V v_x1_242602 = heff_tr(heff_call(v_m_242601, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_242602)) {
      case TAG_MkPair: {
        V v_x11_242603 = heff_field(v_x1_242602, 0);
        V v_st_242604 = heff_field(v_x1_242602, 1);
        V v_ru_24x1_242602_24MkPair = heff_take_reuse_n(v_x1_242602, 3ULL, 2);
        switch (heff_tag_of(v_x11_242603)) {
        case TAG_Left: {
          V v_e_242605 = heff_field(v_x11_242603, 0);
          heff_take_n(v_x11_242603, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_241992, 9);
          heff_drop(v_a_241995);
          return heff_tag_at_n(v_ru_24x1_242602_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242605}), v_st_242604});
        }
        case TAG_Right: {
          V v_x_242606 = heff_field(v_x11_242603, 0);
          heff_take_n(v_x11_242603, 1ULL, 1);
          V v_m_242607 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_a_241995)}));
          V v_x1_242608 = heff_tr(heff_call(v_m_242607, 1, (V[]){v_st_242604}));
          switch (heff_tag_of(v_x1_242608)) {
          case TAG_MkPair: {
            V v_x11_242609 = heff_field(v_x1_242608, 0);
            V v_st_242610 = heff_field(v_x1_242608, 1);
            V v_ru_24x1_242608_24MkPair = heff_take_reuse_n(v_x1_242608, 3ULL, 2);
            switch (heff_tag_of(v_x11_242609)) {
            case TAG_Left: {
              V v_e_242611 = heff_field(v_x11_242609, 0);
              heff_take_n(v_x11_242609, 1ULL, 1);
              heff_drop_rec(v_kw_241992, 9);
              heff_drop(v_a_241995);
              heff_drop(v_x_242606);
              heff_drop_cell(v_ru_24x1_242608_24MkPair, 2);
              return heff_tag_at_n(v_ru_24x1_242602_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242611}), v_st_242610});
            }
            case TAG_Right: {
              V v_x_242612 = heff_field(v_x11_242609, 0);
              heff_take_n(v_x11_242609, 1ULL, 1);
              V v_t_242613 = (g_heff_2esyntax_2ecst_2elastE(v_a_241995));
              V v_e_242614 = heff_get_n(v_t_242613, 4, 9);
              V v_t_242615 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_241992, 3, 9), v_e_242614});
              V v_x_242616 = heff_tag_at_n(v_ru_24x1_242608_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_EIfThen, 2, (V[]){v_x_242606, v_x_242612}), v_t_242615});
              return heff_tag_at_n(v_ru_24x1_242602_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_242616}), v_st_242610});
            }
            default: return heff_nomatch(v_x11_242609);
            }
          }
          default: return heff_nomatch(v_x1_242608);
          }
        }
        default: return heff_nomatch(v_x11_242603);
        }
      }
      default: return heff_nomatch(v_x1_242602);
      }
    }
    case TAG_EWhile: {
      V v_m_242621 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_241993}));
      V v_x1_242622 = heff_tr(heff_call(v_m_242621, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_242622)) {
      case TAG_MkPair: {
        V v_x11_242623 = heff_field(v_x1_242622, 0);
        V v_st_242624 = heff_field(v_x1_242622, 1);
        V v_ru_24x1_242622_24MkPair = heff_take_reuse_n(v_x1_242622, 3ULL, 2);
        switch (heff_tag_of(v_x11_242623)) {
        case TAG_Left: {
          V v_e_242625 = heff_field(v_x11_242623, 0);
          heff_take_n(v_x11_242623, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_241992, 9);
          heff_drop(v_a_241995);
          return heff_tag_at_n(v_ru_24x1_242622_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242625}), v_st_242624});
        }
        case TAG_Right: {
          V v_x_242626 = heff_field(v_x11_242623, 0);
          heff_take_n(v_x11_242623, 1ULL, 1);
          V v_m_242627 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_a_241995)}));
          V v_x1_242628 = heff_tr(heff_call(v_m_242627, 1, (V[]){v_st_242624}));
          switch (heff_tag_of(v_x1_242628)) {
          case TAG_MkPair: {
            V v_x11_242629 = heff_field(v_x1_242628, 0);
            V v_st_242630 = heff_field(v_x1_242628, 1);
            V v_ru_24x1_242628_24MkPair = heff_take_reuse_n(v_x1_242628, 3ULL, 2);
            switch (heff_tag_of(v_x11_242629)) {
            case TAG_Left: {
              V v_e_242631 = heff_field(v_x11_242629, 0);
              heff_take_n(v_x11_242629, 1ULL, 1);
              heff_drop_rec(v_kw_241992, 9);
              heff_drop(v_a_241995);
              heff_drop(v_x_242626);
              heff_drop_cell(v_ru_24x1_242628_24MkPair, 2);
              return heff_tag_at_n(v_ru_24x1_242622_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242631}), v_st_242630});
            }
            case TAG_Right: {
              V v_x_242632 = heff_field(v_x11_242629, 0);
              heff_take_n(v_x11_242629, 1ULL, 1);
              V v_t_242633 = (g_heff_2esyntax_2ecst_2elastE(v_a_241995));
              V v_e_242634 = heff_get_n(v_t_242633, 4, 9);
              V v_t_242635 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_241992, 3, 9), v_e_242634});
              V v_x_242636 = heff_tag_at_n(v_ru_24x1_242628_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_EIfThen, 2, (V[]){v_x_242626, v_x_242632}), v_t_242635});
              return heff_tag_at_n(v_ru_24x1_242622_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_242636}), v_st_242630});
            }
            default: return heff_nomatch(v_x11_242629);
            }
          }
          default: return heff_nomatch(v_x1_242628);
          }
        }
        default: return heff_nomatch(v_x11_242623);
        }
      }
      default: return heff_nomatch(v_x1_242622);
      }
    }
    case TAG_EFor: {
      V v_m_242643 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_241993}));
      V v_x1_242644 = heff_tr(heff_call(v_m_242643, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_242644)) {
      case TAG_MkPair: {
        V v_x11_242645 = heff_field(v_x1_242644, 0);
        V v_st_242646 = heff_field(v_x1_242644, 1);
        V v_ru_24x1_242644_24MkPair = heff_take_reuse_n(v_x1_242644, 3ULL, 2);
        switch (heff_tag_of(v_x11_242645)) {
        case TAG_Left: {
          V v_e_242647 = heff_field(v_x11_242645, 0);
          heff_take_n(v_x11_242645, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_241992, 9);
          heff_drop(v_a_241995);
          return heff_tag_at_n(v_ru_24x1_242644_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242647}), v_st_242646});
        }
        case TAG_Right: {
          V v_x_242648 = heff_field(v_x11_242645, 0);
          heff_take_n(v_x11_242645, 1ULL, 1);
          V v_m_242649 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_a_241995)}));
          V v_x1_242650 = heff_tr(heff_call(v_m_242649, 1, (V[]){v_st_242646}));
          switch (heff_tag_of(v_x1_242650)) {
          case TAG_MkPair: {
            V v_x11_242651 = heff_field(v_x1_242650, 0);
            V v_st_242652 = heff_field(v_x1_242650, 1);
            V v_ru_24x1_242650_24MkPair = heff_take_reuse_n(v_x1_242650, 3ULL, 2);
            switch (heff_tag_of(v_x11_242651)) {
            case TAG_Left: {
              V v_e_242653 = heff_field(v_x11_242651, 0);
              heff_take_n(v_x11_242651, 1ULL, 1);
              heff_drop_rec(v_kw_241992, 9);
              heff_drop(v_a_241995);
              heff_drop(v_x_242648);
              heff_drop_cell(v_ru_24x1_242650_24MkPair, 2);
              return heff_tag_at_n(v_ru_24x1_242644_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242653}), v_st_242652});
            }
            case TAG_Right: {
              V v_x_242654 = heff_field(v_x11_242651, 0);
              heff_take_n(v_x11_242651, 1ULL, 1);
              V v_t_242655 = (g_heff_2esyntax_2ecst_2elastE(v_a_241995));
              V v_e_242656 = heff_get_n(v_t_242655, 4, 9);
              V v_t_242657 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_241992, 3, 9), v_e_242656});
              V v_x_242658 = heff_tag_at_n(v_ru_24x1_242650_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_EIfThen, 2, (V[]){v_x_242648, v_x_242654}), v_t_242657});
              return heff_tag_at_n(v_ru_24x1_242644_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_242658}), v_st_242652});
            }
            default: return heff_nomatch(v_x11_242651);
            }
          }
          default: return heff_nomatch(v_x1_242650);
          }
        }
        default: return heff_nomatch(v_x11_242645);
        }
      }
      default: return heff_nomatch(v_x1_242644);
      }
    }
    case TAG_EJump: {
      V v_m_242660 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_241993}));
      V v_x1_242661 = heff_tr(heff_call(v_m_242660, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_242661)) {
      case TAG_MkPair: {
        V v_x11_242662 = heff_field(v_x1_242661, 0);
        V v_st_242663 = heff_field(v_x1_242661, 1);
        V v_ru_24x1_242661_24MkPair = heff_take_reuse_n(v_x1_242661, 3ULL, 2);
        switch (heff_tag_of(v_x11_242662)) {
        case TAG_Left: {
          V v_e_242664 = heff_field(v_x11_242662, 0);
          heff_take_n(v_x11_242662, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_241992, 9);
          heff_drop(v_a_241995);
          return heff_tag_at_n(v_ru_24x1_242661_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242664}), v_st_242663});
        }
        case TAG_Right: {
          V v_x_242665 = heff_field(v_x11_242662, 0);
          heff_take_n(v_x11_242662, 1ULL, 1);
          V v_m_242666 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_a_241995)}));
          V v_x1_242667 = heff_tr(heff_call(v_m_242666, 1, (V[]){v_st_242663}));
          switch (heff_tag_of(v_x1_242667)) {
          case TAG_MkPair: {
            V v_x11_242668 = heff_field(v_x1_242667, 0);
            V v_st_242669 = heff_field(v_x1_242667, 1);
            V v_ru_24x1_242667_24MkPair = heff_take_reuse_n(v_x1_242667, 3ULL, 2);
            switch (heff_tag_of(v_x11_242668)) {
            case TAG_Left: {
              V v_e_242670 = heff_field(v_x11_242668, 0);
              heff_take_n(v_x11_242668, 1ULL, 1);
              heff_drop_rec(v_kw_241992, 9);
              heff_drop(v_a_241995);
              heff_drop(v_x_242665);
              heff_drop_cell(v_ru_24x1_242667_24MkPair, 2);
              return heff_tag_at_n(v_ru_24x1_242661_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242670}), v_st_242669});
            }
            case TAG_Right: {
              V v_x_242671 = heff_field(v_x11_242668, 0);
              heff_take_n(v_x11_242668, 1ULL, 1);
              V v_t_242672 = (g_heff_2esyntax_2ecst_2elastE(v_a_241995));
              V v_e_242673 = heff_get_n(v_t_242672, 4, 9);
              V v_t_242674 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_241992, 3, 9), v_e_242673});
              V v_x_242675 = heff_tag_at_n(v_ru_24x1_242667_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_EIfThen, 2, (V[]){v_x_242665, v_x_242671}), v_t_242674});
              return heff_tag_at_n(v_ru_24x1_242661_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_242675}), v_st_242669});
            }
            default: return heff_nomatch(v_x11_242668);
            }
          }
          default: return heff_nomatch(v_x1_242667);
          }
        }
        default: return heff_nomatch(v_x11_242662);
        }
      }
      default: return heff_nomatch(v_x1_242661);
      }
    }
    case TAG_EReturn: {
      V v_m_242678 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_241993}));
      V v_x1_242679 = heff_tr(heff_call(v_m_242678, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_242679)) {
      case TAG_MkPair: {
        V v_x11_242680 = heff_field(v_x1_242679, 0);
        V v_st_242681 = heff_field(v_x1_242679, 1);
        V v_ru_24x1_242679_24MkPair = heff_take_reuse_n(v_x1_242679, 3ULL, 2);
        switch (heff_tag_of(v_x11_242680)) {
        case TAG_Left: {
          V v_e_242682 = heff_field(v_x11_242680, 0);
          heff_take_n(v_x11_242680, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_241992, 9);
          heff_drop(v_a_241995);
          return heff_tag_at_n(v_ru_24x1_242679_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242682}), v_st_242681});
        }
        case TAG_Right: {
          V v_x_242683 = heff_field(v_x11_242680, 0);
          heff_take_n(v_x11_242680, 1ULL, 1);
          V v_m_242684 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_a_241995)}));
          V v_x1_242685 = heff_tr(heff_call(v_m_242684, 1, (V[]){v_st_242681}));
          switch (heff_tag_of(v_x1_242685)) {
          case TAG_MkPair: {
            V v_x11_242686 = heff_field(v_x1_242685, 0);
            V v_st_242687 = heff_field(v_x1_242685, 1);
            V v_ru_24x1_242685_24MkPair = heff_take_reuse_n(v_x1_242685, 3ULL, 2);
            switch (heff_tag_of(v_x11_242686)) {
            case TAG_Left: {
              V v_e_242688 = heff_field(v_x11_242686, 0);
              heff_take_n(v_x11_242686, 1ULL, 1);
              heff_drop_rec(v_kw_241992, 9);
              heff_drop(v_a_241995);
              heff_drop(v_x_242683);
              heff_drop_cell(v_ru_24x1_242685_24MkPair, 2);
              return heff_tag_at_n(v_ru_24x1_242679_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242688}), v_st_242687});
            }
            case TAG_Right: {
              V v_x_242689 = heff_field(v_x11_242686, 0);
              heff_take_n(v_x11_242686, 1ULL, 1);
              V v_t_242690 = (g_heff_2esyntax_2ecst_2elastE(v_a_241995));
              V v_e_242691 = heff_get_n(v_t_242690, 4, 9);
              V v_t_242692 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_241992, 3, 9), v_e_242691});
              V v_x_242693 = heff_tag_at_n(v_ru_24x1_242685_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_EIfThen, 2, (V[]){v_x_242683, v_x_242689}), v_t_242692});
              return heff_tag_at_n(v_ru_24x1_242679_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_242693}), v_st_242687});
            }
            default: return heff_nomatch(v_x11_242686);
            }
          }
          default: return heff_nomatch(v_x1_242685);
          }
        }
        default: return heff_nomatch(v_x11_242680);
        }
      }
      default: return heff_nomatch(v_x1_242679);
      }
    }
    case TAG_ENest: {
      V v_m_242698 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_241993}));
      V v_x1_242699 = heff_tr(heff_call(v_m_242698, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_242699)) {
      case TAG_MkPair: {
        V v_x11_242700 = heff_field(v_x1_242699, 0);
        V v_st_242701 = heff_field(v_x1_242699, 1);
        V v_ru_24x1_242699_24MkPair = heff_take_reuse_n(v_x1_242699, 3ULL, 2);
        switch (heff_tag_of(v_x11_242700)) {
        case TAG_Left: {
          V v_e_242702 = heff_field(v_x11_242700, 0);
          heff_take_n(v_x11_242700, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_241992, 9);
          heff_drop(v_a_241995);
          return heff_tag_at_n(v_ru_24x1_242699_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242702}), v_st_242701});
        }
        case TAG_Right: {
          V v_x_242703 = heff_field(v_x11_242700, 0);
          heff_take_n(v_x11_242700, 1ULL, 1);
          V v_m_242704 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_a_241995)}));
          V v_x1_242705 = heff_tr(heff_call(v_m_242704, 1, (V[]){v_st_242701}));
          switch (heff_tag_of(v_x1_242705)) {
          case TAG_MkPair: {
            V v_x11_242706 = heff_field(v_x1_242705, 0);
            V v_st_242707 = heff_field(v_x1_242705, 1);
            V v_ru_24x1_242705_24MkPair = heff_take_reuse_n(v_x1_242705, 3ULL, 2);
            switch (heff_tag_of(v_x11_242706)) {
            case TAG_Left: {
              V v_e_242708 = heff_field(v_x11_242706, 0);
              heff_take_n(v_x11_242706, 1ULL, 1);
              heff_drop_rec(v_kw_241992, 9);
              heff_drop(v_a_241995);
              heff_drop(v_x_242703);
              heff_drop_cell(v_ru_24x1_242705_24MkPair, 2);
              return heff_tag_at_n(v_ru_24x1_242699_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242708}), v_st_242707});
            }
            case TAG_Right: {
              V v_x_242709 = heff_field(v_x11_242706, 0);
              heff_take_n(v_x11_242706, 1ULL, 1);
              V v_t_242710 = (g_heff_2esyntax_2ecst_2elastE(v_a_241995));
              V v_e_242711 = heff_get_n(v_t_242710, 4, 9);
              V v_t_242712 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_241992, 3, 9), v_e_242711});
              V v_x_242713 = heff_tag_at_n(v_ru_24x1_242705_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_EIfThen, 2, (V[]){v_x_242703, v_x_242709}), v_t_242712});
              return heff_tag_at_n(v_ru_24x1_242699_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_242713}), v_st_242707});
            }
            default: return heff_nomatch(v_x11_242706);
            }
          }
          default: return heff_nomatch(v_x1_242705);
          }
        }
        default: return heff_nomatch(v_x11_242700);
        }
      }
      default: return heff_nomatch(v_x1_242699);
      }
    }
    case TAG_IfThen: {
      V v_m_242718 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_241993}));
      V v_x1_242719 = heff_tr(heff_call(v_m_242718, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_242719)) {
      case TAG_MkPair: {
        V v_x11_242720 = heff_field(v_x1_242719, 0);
        V v_st_242721 = heff_field(v_x1_242719, 1);
        V v_ru_24x1_242719_24MkPair = heff_take_reuse_n(v_x1_242719, 3ULL, 2);
        switch (heff_tag_of(v_x11_242720)) {
        case TAG_Left: {
          V v_e_242722 = heff_field(v_x11_242720, 0);
          heff_take_n(v_x11_242720, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_241992, 9);
          heff_drop(v_a_241995);
          return heff_tag_at_n(v_ru_24x1_242719_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242722}), v_st_242721});
        }
        case TAG_Right: {
          V v_x_242723 = heff_field(v_x11_242720, 0);
          heff_take_n(v_x11_242720, 1ULL, 1);
          V v_m_242724 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_a_241995)}));
          V v_x1_242725 = heff_tr(heff_call(v_m_242724, 1, (V[]){v_st_242721}));
          switch (heff_tag_of(v_x1_242725)) {
          case TAG_MkPair: {
            V v_x11_242726 = heff_field(v_x1_242725, 0);
            V v_st_242727 = heff_field(v_x1_242725, 1);
            V v_ru_24x1_242725_24MkPair = heff_take_reuse_n(v_x1_242725, 3ULL, 2);
            switch (heff_tag_of(v_x11_242726)) {
            case TAG_Left: {
              V v_e_242728 = heff_field(v_x11_242726, 0);
              heff_take_n(v_x11_242726, 1ULL, 1);
              heff_drop_rec(v_kw_241992, 9);
              heff_drop(v_a_241995);
              heff_drop(v_x_242723);
              heff_drop_cell(v_ru_24x1_242725_24MkPair, 2);
              return heff_tag_at_n(v_ru_24x1_242719_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242728}), v_st_242727});
            }
            case TAG_Right: {
              V v_x_242729 = heff_field(v_x11_242726, 0);
              heff_take_n(v_x11_242726, 1ULL, 1);
              V v_t_242730 = (g_heff_2esyntax_2ecst_2elastE(v_a_241995));
              V v_e_242731 = heff_get_n(v_t_242730, 4, 9);
              V v_t_242732 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_241992, 3, 9), v_e_242731});
              V v_x_242733 = heff_tag_at_n(v_ru_24x1_242725_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_EIfThen, 2, (V[]){v_x_242723, v_x_242729}), v_t_242732});
              return heff_tag_at_n(v_ru_24x1_242719_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_242733}), v_st_242727});
            }
            default: return heff_nomatch(v_x11_242726);
            }
          }
          default: return heff_nomatch(v_x1_242725);
          }
        }
        default: return heff_nomatch(v_x11_242720);
        }
      }
      default: return heff_nomatch(v_x1_242719);
      }
    }
    case TAG_ELetCond: {
      V v_p_242735 = heff_field(v_e02_241993, 1);
      V v_e_242737 = heff_field(v_e02_241993, 3);
      heff_take_n(v_e02_241993, 10ULL, 4);
      V v_t_242738 = (g_heff_2esyntax_2ecst_2elastE(heff_dup(v_a_241995)));
      V v_e_242739 = heff_get_n(v_t_242738, 4, 9);
      V v_t_242740 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_241992, 3, 9), v_e_242739});
      return (g_heff_2esyntax_2esurface_2eifLetL(v_r_240, v_t_242740, v_p_242735, v_e_242737, v_a_241995, NTAG(TAG_Nothing), v_z_242));
    }
    case TAG_ETry: {
      V v_m_242745 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_241993}));
      V v_x1_242746 = heff_tr(heff_call(v_m_242745, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_242746)) {
      case TAG_MkPair: {
        V v_x11_242747 = heff_field(v_x1_242746, 0);
        V v_st_242748 = heff_field(v_x1_242746, 1);
        V v_ru_24x1_242746_24MkPair = heff_take_reuse_n(v_x1_242746, 3ULL, 2);
        switch (heff_tag_of(v_x11_242747)) {
        case TAG_Left: {
          V v_e_242749 = heff_field(v_x11_242747, 0);
          heff_take_n(v_x11_242747, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_241992, 9);
          heff_drop(v_a_241995);
          return heff_tag_at_n(v_ru_24x1_242746_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242749}), v_st_242748});
        }
        case TAG_Right: {
          V v_x_242750 = heff_field(v_x11_242747, 0);
          heff_take_n(v_x11_242747, 1ULL, 1);
          V v_m_242751 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_a_241995)}));
          V v_x1_242752 = heff_tr(heff_call(v_m_242751, 1, (V[]){v_st_242748}));
          switch (heff_tag_of(v_x1_242752)) {
          case TAG_MkPair: {
            V v_x11_242753 = heff_field(v_x1_242752, 0);
            V v_st_242754 = heff_field(v_x1_242752, 1);
            V v_ru_24x1_242752_24MkPair = heff_take_reuse_n(v_x1_242752, 3ULL, 2);
            switch (heff_tag_of(v_x11_242753)) {
            case TAG_Left: {
              V v_e_242755 = heff_field(v_x11_242753, 0);
              heff_take_n(v_x11_242753, 1ULL, 1);
              heff_drop_rec(v_kw_241992, 9);
              heff_drop(v_a_241995);
              heff_drop(v_x_242750);
              heff_drop_cell(v_ru_24x1_242752_24MkPair, 2);
              return heff_tag_at_n(v_ru_24x1_242746_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242755}), v_st_242754});
            }
            case TAG_Right: {
              V v_x_242756 = heff_field(v_x11_242753, 0);
              heff_take_n(v_x11_242753, 1ULL, 1);
              V v_t_242757 = (g_heff_2esyntax_2ecst_2elastE(v_a_241995));
              V v_e_242758 = heff_get_n(v_t_242757, 4, 9);
              V v_t_242759 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_241992, 3, 9), v_e_242758});
              V v_x_242760 = heff_tag_at_n(v_ru_24x1_242752_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_EIfThen, 2, (V[]){v_x_242750, v_x_242756}), v_t_242759});
              return heff_tag_at_n(v_ru_24x1_242746_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_242760}), v_st_242754});
            }
            default: return heff_nomatch(v_x11_242753);
            }
          }
          default: return heff_nomatch(v_x1_242752);
          }
        }
        default: return heff_nomatch(v_x11_242747);
        }
      }
      default: return heff_nomatch(v_x1_242746);
      }
    }
    case TAG_ECatch: {
      V v_m_242765 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_241993}));
      V v_x1_242766 = heff_tr(heff_call(v_m_242765, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_242766)) {
      case TAG_MkPair: {
        V v_x11_242767 = heff_field(v_x1_242766, 0);
        V v_st_242768 = heff_field(v_x1_242766, 1);
        V v_ru_24x1_242766_24MkPair = heff_take_reuse_n(v_x1_242766, 3ULL, 2);
        switch (heff_tag_of(v_x11_242767)) {
        case TAG_Left: {
          V v_e_242769 = heff_field(v_x11_242767, 0);
          heff_take_n(v_x11_242767, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_241992, 9);
          heff_drop(v_a_241995);
          return heff_tag_at_n(v_ru_24x1_242766_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242769}), v_st_242768});
        }
        case TAG_Right: {
          V v_x_242770 = heff_field(v_x11_242767, 0);
          heff_take_n(v_x11_242767, 1ULL, 1);
          V v_m_242771 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_a_241995)}));
          V v_x1_242772 = heff_tr(heff_call(v_m_242771, 1, (V[]){v_st_242768}));
          switch (heff_tag_of(v_x1_242772)) {
          case TAG_MkPair: {
            V v_x11_242773 = heff_field(v_x1_242772, 0);
            V v_st_242774 = heff_field(v_x1_242772, 1);
            V v_ru_24x1_242772_24MkPair = heff_take_reuse_n(v_x1_242772, 3ULL, 2);
            switch (heff_tag_of(v_x11_242773)) {
            case TAG_Left: {
              V v_e_242775 = heff_field(v_x11_242773, 0);
              heff_take_n(v_x11_242773, 1ULL, 1);
              heff_drop_rec(v_kw_241992, 9);
              heff_drop(v_a_241995);
              heff_drop(v_x_242770);
              heff_drop_cell(v_ru_24x1_242772_24MkPair, 2);
              return heff_tag_at_n(v_ru_24x1_242766_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242775}), v_st_242774});
            }
            case TAG_Right: {
              V v_x_242776 = heff_field(v_x11_242773, 0);
              heff_take_n(v_x11_242773, 1ULL, 1);
              V v_t_242777 = (g_heff_2esyntax_2ecst_2elastE(v_a_241995));
              V v_e_242778 = heff_get_n(v_t_242777, 4, 9);
              V v_t_242779 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_241992, 3, 9), v_e_242778});
              V v_x_242780 = heff_tag_at_n(v_ru_24x1_242772_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_EIfThen, 2, (V[]){v_x_242770, v_x_242776}), v_t_242779});
              return heff_tag_at_n(v_ru_24x1_242766_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_242780}), v_st_242774});
            }
            default: return heff_nomatch(v_x11_242773);
            }
          }
          default: return heff_nomatch(v_x1_242772);
          }
        }
        default: return heff_nomatch(v_x11_242767);
        }
      }
      default: return heff_nomatch(v_x1_242766);
      }
    }
    case TAG_EWith: {
      V v_m_242787 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_241993}));
      V v_x1_242788 = heff_tr(heff_call(v_m_242787, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_242788)) {
      case TAG_MkPair: {
        V v_x11_242789 = heff_field(v_x1_242788, 0);
        V v_st_242790 = heff_field(v_x1_242788, 1);
        V v_ru_24x1_242788_24MkPair = heff_take_reuse_n(v_x1_242788, 3ULL, 2);
        switch (heff_tag_of(v_x11_242789)) {
        case TAG_Left: {
          V v_e_242791 = heff_field(v_x11_242789, 0);
          heff_take_n(v_x11_242789, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_241992, 9);
          heff_drop(v_a_241995);
          return heff_tag_at_n(v_ru_24x1_242788_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242791}), v_st_242790});
        }
        case TAG_Right: {
          V v_x_242792 = heff_field(v_x11_242789, 0);
          heff_take_n(v_x11_242789, 1ULL, 1);
          V v_m_242793 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_a_241995)}));
          V v_x1_242794 = heff_tr(heff_call(v_m_242793, 1, (V[]){v_st_242790}));
          switch (heff_tag_of(v_x1_242794)) {
          case TAG_MkPair: {
            V v_x11_242795 = heff_field(v_x1_242794, 0);
            V v_st_242796 = heff_field(v_x1_242794, 1);
            V v_ru_24x1_242794_24MkPair = heff_take_reuse_n(v_x1_242794, 3ULL, 2);
            switch (heff_tag_of(v_x11_242795)) {
            case TAG_Left: {
              V v_e_242797 = heff_field(v_x11_242795, 0);
              heff_take_n(v_x11_242795, 1ULL, 1);
              heff_drop_rec(v_kw_241992, 9);
              heff_drop(v_a_241995);
              heff_drop(v_x_242792);
              heff_drop_cell(v_ru_24x1_242794_24MkPair, 2);
              return heff_tag_at_n(v_ru_24x1_242788_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242797}), v_st_242796});
            }
            case TAG_Right: {
              V v_x_242798 = heff_field(v_x11_242795, 0);
              heff_take_n(v_x11_242795, 1ULL, 1);
              V v_t_242799 = (g_heff_2esyntax_2ecst_2elastE(v_a_241995));
              V v_e_242800 = heff_get_n(v_t_242799, 4, 9);
              V v_t_242801 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_241992, 3, 9), v_e_242800});
              V v_x_242802 = heff_tag_at_n(v_ru_24x1_242794_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_EIfThen, 2, (V[]){v_x_242792, v_x_242798}), v_t_242801});
              return heff_tag_at_n(v_ru_24x1_242788_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_242802}), v_st_242796});
            }
            default: return heff_nomatch(v_x11_242795);
            }
          }
          default: return heff_nomatch(v_x1_242794);
          }
        }
        default: return heff_nomatch(v_x11_242789);
        }
      }
      default: return heff_nomatch(v_x1_242788);
      }
    }
    default: return heff_nomatch(v_e02_241993);
    }
  }
  case TAG_ELetCond: {
    heff_drop_rec(v_r_240, 3);
    V v_t_242807 = (g_heff_2esyntax_2ecst_2efirstE(v_e0_241));
    V v_t_242808 = ({ V a_0 = v_e0_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e0_241, 4); r_; });
    V v_t_242809 = heff_strAppend(heff_get_n(v_t_242808, 1, 9), ((V)&g_heff_2esyntax_2esurface_2eexprL_str38));
    V v_msg_242810 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eexprL_str39), v_t_242809);
    V v_t_242811 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_242807, 3), heff_get_n(v_t_242807, 4, 9)});
    V v_t_242812 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_242810, v_t_242811, NTAG(TAG_Nothing)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_242812}), v_z_242});
  }
  case TAG_ETry: {
    V v_kw_242813 = heff_dup(heff_field(v_e0_241, 0));
    V v_ty_242814 = heff_dup(heff_field(v_e0_241, 1));
    V v_body_242815 = heff_dup(heff_field(v_e0_241, 2));
    V v_c_242816 = heff_dup(heff_field(v_e0_241, 3));
    V v_m_242817 = (g_heff_2esyntax_2esurface_2etryTypeL(heff_dup(v_r_240), v_ty_242814));
    V v_x1_242818 = heff_tr(heff_call(v_m_242817, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x1_242818)) {
    case TAG_MkPair: {
      V v_x11_242819 = heff_field(v_x1_242818, 0);
      V v_st_242820 = heff_field(v_x1_242818, 1);
      V v_ru_24x1_242818_24MkPair = heff_take_reuse_n(v_x1_242818, 3ULL, 2);
      switch (heff_tag_of(v_x11_242819)) {
      case TAG_Left: {
        V v_e_242821 = heff_field(v_x11_242819, 0);
        heff_take_n(v_x11_242819, 1ULL, 1);
        heff_drop_rec(v_r_240, 3);
        heff_drop_tag(v_e0_241, 4);
        heff_drop_rec(v_kw_242813, 9);
        heff_drop(v_body_242815);
        heff_drop(v_c_242816);
        return heff_tag_at_n(v_ru_24x1_242818_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242821}), v_st_242820});
      }
      case TAG_Right: {
        V v_x_242822 = heff_field(v_x11_242819, 0);
        V v_ru_24x11_242819_24Right = heff_take_reuse_n(v_x11_242819, 1ULL, 1);
        HeffT2 v_t_242824 = (g_heff_2esyntax_2esurface_2eblock_24cpr(heff_clo_n(g_heff_2esyntax_2esurface_2eexprL_lam11, 1, 1, (V[]){heff_dup(v_r_240)}), v_body_242815, v_st_242820));
        {
          V v_field_242825 = v_t_242824.f[0];
          V v_field_242826 = v_t_242824.f[1];
          V v_x11_242827 = v_field_242825;
          V v_st_242828 = v_field_242826;
          switch (heff_tag_of(v_x11_242827)) {
          case TAG_Left: {
            V v_e_242829 = heff_field(v_x11_242827, 0);
            heff_take_n(v_x11_242827, 1ULL, 1);
            heff_drop_rec(v_r_240, 3);
            heff_drop_tag(v_e0_241, 4);
            heff_drop_rec(v_kw_242813, 9);
            heff_drop(v_c_242816);
            heff_drop(v_x_242822);
            heff_drop_cell(v_ru_24x11_242819_24Right, 1);
            return heff_tag_at_n(v_ru_24x1_242818_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242829}), v_st_242828});
          }
          case TAG_Right: {
            V v_x_242830 = heff_field(v_x11_242827, 0);
            heff_take_n(v_x11_242827, 1ULL, 1);
            V v_m_242831 = (g_heff_2esyntax_2esurface_2ecatchL(v_r_240, v_c_242816));
            V v_x1_242832 = heff_tr(heff_call(v_m_242831, 1, (V[]){v_st_242828}));
            switch (heff_tag_of(v_x1_242832)) {
            case TAG_MkPair: {
              V v_x11_242833 = heff_field(v_x1_242832, 0);
              V v_st_242834 = heff_field(v_x1_242832, 1);
              V v_ru_24x1_242832_24MkPair = heff_take_reuse_n(v_x1_242832, 3ULL, 2);
              switch (heff_tag_of(v_x11_242833)) {
              case TAG_Left: {
                V v_e_242835 = heff_field(v_x11_242833, 0);
                heff_take_n(v_x11_242833, 1ULL, 1);
                heff_drop_tag(v_e0_241, 4);
                heff_drop_rec(v_kw_242813, 9);
                heff_drop(v_x_242822);
                heff_drop_cell(v_ru_24x11_242819_24Right, 1);
                heff_drop(v_x_242830);
                heff_drop_cell(v_ru_24x1_242832_24MkPair, 2);
                return heff_tag_at_n(v_ru_24x1_242818_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242835}), v_st_242834});
              }
              case TAG_Right: {
                V v_x_242836 = heff_field(v_x11_242833, 0);
                heff_take_n(v_x11_242833, 1ULL, 1);
                V v_t_242837 = heff_tag_at_n(v_ru_24x11_242819_24Right, TAG_ETry, 1, (V[]){heff_tag_n(TAG_MkTry, 3, (V[]){v_x_242822, v_x_242830, v_x_242836})});
                V v_t_242838 = (g_heff_2esyntax_2ecst_2elastE(v_e0_241));
                V v_e_242839 = heff_get_n(v_t_242838, 4, 9);
                V v_t_242840 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_242813, 3, 9), v_e_242839});
                V v_x_242841 = heff_tag_at_n(v_ru_24x1_242832_24MkPair, TAG_At, 2, (V[]){v_t_242837, v_t_242840});
                return heff_tag_at_n(v_ru_24x1_242818_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_242841}), v_st_242834});
              }
              default: return heff_nomatch(v_x11_242833);
              }
            }
            default: return heff_nomatch(v_x1_242832);
            }
          }
          default: return heff_nomatch(v_x11_242827);
          }
        }
      }
      default: return heff_nomatch(v_x11_242819);
      }
    }
    default: return heff_nomatch(v_x1_242818);
    }
  }
  case TAG_ECatch: {
    heff_drop_rec(v_r_240, 3);
    V v_t_242846 = (g_heff_2esyntax_2ecst_2efirstE(v_e0_241));
    V v_t_242847 = ({ V a_0 = v_e0_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e0_241, 4); r_; });
    V v_t_242848 = heff_strAppend(heff_get_n(v_t_242847, 1, 9), ((V)&g_heff_2esyntax_2esurface_2eexprL_str40));
    V v_msg_242849 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eexprL_str41), v_t_242848);
    V v_t_242850 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_242846, 3), heff_get_n(v_t_242846, 4, 9)});
    V v_t_242851 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_242849, v_t_242850, NTAG(TAG_Nothing)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_242851}), v_z_242});
  }
  case TAG_EWith: {
    V v_kw_242852 = heff_dup(heff_field(v_e0_241, 0));
    V v_e_242853 = heff_dup(heff_field(v_e0_241, 1));
    V v_x_242855 = heff_dup(heff_field(v_e0_241, 3));
    V v_body_242857 = heff_dup(heff_field(v_e0_241, 5));
    V v_m_242858 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e_242853}));
    V v_x1_242859 = heff_tr(heff_call(v_m_242858, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x1_242859)) {
    case TAG_MkPair: {
      V v_x11_242860 = heff_field(v_x1_242859, 0);
      V v_st_242861 = heff_field(v_x1_242859, 1);
      V v_ru_24x1_242859_24MkPair = heff_take_reuse_n(v_x1_242859, 3ULL, 2);
      switch (heff_tag_of(v_x11_242860)) {
      case TAG_Left: {
        V v_e_242862 = heff_field(v_x11_242860, 0);
        heff_take_n(v_x11_242860, 1ULL, 1);
        heff_drop_rec(v_r_240, 3);
        heff_drop_tag(v_e0_241, 6);
        heff_drop_rec(v_kw_242852, 9);
        heff_drop_rec(v_x_242855, 9);
        heff_drop(v_body_242857);
        return heff_tag_at_n(v_ru_24x1_242859_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242862}), v_st_242861});
      }
      case TAG_Right: {
        V v_x_242863 = heff_field(v_x11_242860, 0);
        heff_take_n(v_x11_242860, 1ULL, 1);
        V v_t_242864 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(heff_rfield(v_x_242855, 1)), NTAG(TAG_Nil)});
        V v_t_242866 = heff_tr(heff_call(((V)&g_heff_2esyntax_2esurface_2eblock_clo), 2, (V[]){heff_clo_n(g_heff_2esyntax_2esurface_2eexprL_lam12, 1, 1, (V[]){v_r_240}), v_body_242857}));
        HeffT2 v_t_242867 = (g_heff_2esyntax_2esurface_2ewithScope_24cpr(v_t_242864, v_t_242866, v_st_242861));
        {
          V v_field_242868 = v_t_242867.f[0];
          V v_field_242869 = v_t_242867.f[1];
          V v_x11_242870 = v_field_242868;
          V v_st_242871 = v_field_242869;
          switch (heff_tag_of(v_x11_242870)) {
          case TAG_Left: {
            V v_e_242872 = heff_field(v_x11_242870, 0);
            heff_take_n(v_x11_242870, 1ULL, 1);
            heff_drop_tag(v_e0_241, 6);
            heff_drop_rec(v_kw_242852, 9);
            heff_drop_rec(v_x_242855, 9);
            heff_drop(v_x_242863);
            return heff_tag_at_n(v_ru_24x1_242859_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242872}), v_st_242871});
          }
          case TAG_Right: {
            V v_x_242873 = heff_field(v_x11_242870, 0);
            heff_take_n(v_x11_242870, 1ULL, 1);
            V v_t_242874 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_x_242855, 3), heff_take_field(v_x_242855, 4)});
            V v_t_242875 = heff_tag_n(TAG_EWith, 4, (V[]){v_x_242863, heff_get_n(v_x_242855, 1, 9), v_t_242874, v_x_242873});
            V v_t_242876 = (g_heff_2esyntax_2ecst_2elastE(v_e0_241));
            V v_e_242877 = heff_get_n(v_t_242876, 4, 9);
            V v_t_242878 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_242852, 3, 9), v_e_242877});
            V v_x_242879 = heff_tag_n(TAG_At, 2, (V[]){v_t_242875, v_t_242878});
            return heff_tag_at_n(v_ru_24x1_242859_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_242879}), v_st_242871});
          }
          default: return heff_nomatch(v_x11_242870);
          }
        }
      }
      default: return heff_nomatch(v_x11_242860);
      }
    }
    default: return heff_nomatch(v_x1_242859);
    }
  }
  default: return heff_nomatch(v_e0_241);
  }
}
V g_heff_2esyntax_2esurface_2eexprL_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2eexprL(a[0], a[1], a[2]);
}
V g_heff_2esyntax_2esurface_2eexprL_lam0(V self, V *args) {
  V v_m_2431 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2esyntax_2esurface_2esegmentL(v_r_240, v_m_2431));
}
V g_heff_2esyntax_2esurface_2eexprL_lam1(V self, V *args) {
  V v_x_2449 = args[0];
  V v_rest_2450 = args[1];
  V v_sp_2447 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2451 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ETag, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2eexprL_str8)}), v_sp_2447});
  V v_t_2452 = heff_tag_n(TAG_Cons, 2, (V[]){v_rest_2450, NTAG(TAG_Nil)});
  return (g_heff_2esyntax_2epresyntax_2eapp(v_t_2451, heff_tag_n(TAG_Cons, 2, (V[]){v_x_2449, v_t_2452})));
}
V g_heff_2esyntax_2esurface_2eexprL_lam2(V self, V *args) {
  V v_m_2487 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2esyntax_2esurface_2eupdateSettingL(v_r_240, v_m_2487));
}
V g_heff_2esyntax_2esurface_2eexprL_lam3(V self, V *args) {
  V v_a_24141 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2esyntax_2esurface_2evariantL(v_r_240, v_a_24141));
}
V g_heff_2esyntax_2esurface_2eexprL_lam4(V self, V *args) {
  V v_m_24662 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2esyntax_2esurface_2eargL(v_r_240, v_m_24662));
}
V g_heff_2esyntax_2esurface_2eexprL_lam6(V self, V *args) {
  V v_st_24688 = args[0];
  V v_m_24687 = heff_env(self)[0];
  V v_op_24685 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24689 = heff_tr(heff_call(v_m_24687, 1, (V[]){v_st_24688}));
  switch (heff_tag_of(v_x1_24689)) {
  case TAG_MkPair: {
    V v_x11_24690 = heff_field(v_x1_24689, 0);
    V v_st_24691 = heff_field(v_x1_24689, 1);
    V v_ru_24x1_24689_24MkPair = heff_take_reuse_n(v_x1_24689, 3ULL, 2);
    switch (heff_tag_of(v_x11_24690)) {
    case TAG_Left: {
      V v_e_24692 = heff_field(v_x11_24690, 0);
      heff_take_n(v_x11_24690, 1ULL, 1);
      heff_drop(v_op_24685);
      return heff_tag_at_n(v_ru_24x1_24689_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24692}), v_st_24691});
    }
    case TAG_Right: {
      V v_x_24693 = heff_field(v_x11_24690, 0);
      V v_ru_24x11_24690_24Right = heff_take_reuse_n(v_x11_24690, 1ULL, 1);
      V v_t_24694 = heff_tag_at_n(v_ru_24x11_24690_24Right, TAG_Right, 1, (V[]){heff_rec_n(2, shape_op__e, (V[]){v_op_24685, v_x_24693})});
      return heff_tag_at_n(v_ru_24x1_24689_24MkPair, TAG_MkPair, 2, (V[]){v_t_24694, v_st_24691});
    }
    default: return heff_nomatch(v_x11_24690);
    }
  }
  default: return heff_nomatch(v_x1_24689);
  }
}
V g_heff_2esyntax_2esurface_2eexprL_lam5(V self, V *args) {
  V v_m_24681 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_24682 = (g_heff_2esyntax_2esurface_2eopRhsOf_24cpr(v_m_24681));
  {
    V v_field_24683 = v_t_24682.f[0];
    V v_field_24684 = v_t_24682.f[1];
    V v_op_24685 = v_field_24683;
    V v_e_24686 = v_field_24684;
    V v_m_24687 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_24686}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2eexprL_lam6, 1, 2, (V[]){v_m_24687, v_op_24685});
  }
}
V g_heff_2esyntax_2esurface_2eexprL_lam7(V self, V *args) {
  V v_a_24773 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2esyntax_2esurface_2ealtL(v_r_240, v_a_24773));
}
V g_heff_2esyntax_2esurface_2eexprL_lam8(V self, V *args) {
  V v_m_241855 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2esyntax_2esurface_2estmtL(v_r_240, v_m_241855));
}
V g_heff_2esyntax_2esurface_2eexprL_lam9(V self, V *args) {
  V v_m_241919 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2esyntax_2esurface_2estmtL(v_r_240, v_m_241919));
}
V g_heff_2esyntax_2esurface_2eexprL_lam10(V self, V *args) {
  V v_m_241950 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2esyntax_2esurface_2estmtL(v_r_240, v_m_241950));
}
V g_heff_2esyntax_2esurface_2eexprL_lam11(V self, V *args) {
  V v_m_242823 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2esyntax_2esurface_2estmtL(v_r_240, v_m_242823));
}
V g_heff_2esyntax_2esurface_2eexprL_lam12(V self, V *args) {
  V v_m_242865 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2esyntax_2esurface_2estmtL(v_r_240, v_m_242865));
}
V g_heff_2esyntax_2esurface_2edefaultL_lam0(V self, V *args); static Clo g_heff_2esyntax_2esurface_2edefaultL_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2edefaultL_lam0, 1, 0};
V g_heff_2esyntax_2esurface_2edefaultL_lam1(V self, V *args);
Clo g_heff_2esyntax_2esurface_2edefaultL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2edefaultL_entry, 2, 0};

V g_heff_2esyntax_2esurface_2edefaultL(V v_r_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nothing: {
    heff_drop_rec(v_r_240, 3);
    return ((V)&g_heff_2esyntax_2esurface_2edefaultL_lam0_clo);
  }
  case TAG_Just: {
    V v_x21_244 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    switch (heff_tag_of(v_x21_244)) {
    case TAG_MkPair: {
      V v_d_246 = heff_field(v_x21_244, 1);
      heff_take_n(v_x21_244, 2ULL, 2);
      V v_m_247 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_d_246}));
      return heff_clo_n(g_heff_2esyntax_2esurface_2edefaultL_lam1, 1, 1, (V[]){v_m_247});
    }
    default: return heff_nomatch(v_x21_244);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2esurface_2edefaultL_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2edefaultL(a[0], a[1]);
}
V g_heff_2esyntax_2esurface_2edefaultL_lam0(V self, V *args) {
  V v_st_242 = args[0];
  V v_t_243 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_243, v_st_242});
}
V g_heff_2esyntax_2esurface_2edefaultL_lam1(V self, V *args) {
  V v_st_248 = args[0];
  V v_m_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_249 = heff_tr(heff_call(v_m_247, 1, (V[]){v_st_248}));
  switch (heff_tag_of(v_x1_249)) {
  case TAG_MkPair: {
    V v_x11_2410 = heff_field(v_x1_249, 0);
    V v_st_2411 = heff_field(v_x1_249, 1);
    V v_ru_24x1_249_24MkPair = heff_take_reuse_n(v_x1_249, 3ULL, 2);
    switch (heff_tag_of(v_x11_2410)) {
    case TAG_Left: {
      V v_e_2412 = heff_field(v_x11_2410, 0);
      heff_take_n(v_x11_2410, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_249_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2412}), v_st_2411});
    }
    case TAG_Right: {
      V v_x_2413 = heff_field(v_x11_2410, 0);
      V v_ru_24x11_2410_24Right = heff_take_reuse_n(v_x11_2410, 1ULL, 1);
      V v_t_2414 = heff_tag_at_n(v_ru_24x11_2410_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Just, 1, (V[]){v_x_2413})});
      return heff_tag_at_n(v_ru_24x1_249_24MkPair, TAG_MkPair, 2, (V[]){v_t_2414, v_st_2411});
    }
    default: return heff_nomatch(v_x11_2410);
    }
  }
  default: return heff_nomatch(v_x1_249);
  }
}
Clo g_heff_2esyntax_2esurface_2erightsOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2erightsOf_entry, 1, 0};

V g_heff_2esyntax_2esurface_2erightsOf(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_Left: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Right: {
      V v_x_244 = heff_field(v_x11_241, 0);
      heff_take_n(v_x11_241, 1ULL, 1);
      V v_cell_245 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_244, heff_hole()});
      V v_u_246 = (g_heff_2esyntax_2esurface_2erightsOf_24dps(v_rest_242, heff_dup(v_cell_245)));
      heff_drop(v_u_246);
      return v_cell_245;
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2esurface_2erightsOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2erightsOf(a[0]);
}