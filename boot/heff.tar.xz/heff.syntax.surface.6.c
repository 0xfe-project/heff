// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Ann 13421
#define TAG_App 13485
#define TAG_At 8900
#define TAG_Atom 28502
#define TAG_BAnn 9252
#define TAG_BImp 16911
#define TAG_BVar 29034
#define TAG_Braces 8205
#define TAG_Case 4415
#define TAG_Do 8988
#define TAG_EAlt 33043
#define TAG_EAnn 33099
#define TAG_EAssign 4102
#define TAG_EBinary 42634
#define TAG_EBreak 7195
#define TAG_ECatch 45587
#define TAG_ECon 35052
#define TAG_EContinue 48638
#define TAG_EDo 15964
#define TAG_EFDefault 38038
#define TAG_EFSet 34673
#define TAG_EField 26142
#define TAG_EFor 37939
#define TAG_EIfThen 2245
#define TAG_EInvalid 31081
#define TAG_EJump 55703
#define TAG_ELet 43397
#define TAG_ELetCond 24397
#define TAG_ELetIn 22786
#define TAG_ELetMut 54984
#define TAG_EMatch 41631
#define TAG_ENeg 45306
#define TAG_ENest 28629
#define TAG_EParen 58248
#define TAG_EReturn 59059
#define TAG_ESBind 62182
#define TAG_ESum 50613
#define TAG_ETag 50948
#define TAG_ETry 51493
#define TAG_EUSet 22856
#define TAG_EUpdate 6986
#define TAG_EVar 52881
#define TAG_EWhile 39339
#define TAG_FloatValue 23118
#define TAG_If 9134
#define TAG_IfThen 36069
#define TAG_InstB 37114
#define TAG_IntValue 62477
#define TAG_Lam 23588
#define TAG_Left 13886
#define TAG_MkAlt 55173
#define TAG_MkSegment 38079
#define TAG_MkTry 8097
#define TAG_Named 2049
#define TAG_Op 9330
#define TAG_OpRhs 36076
#define TAG_Ops 26942
#define TAG_OtherValue 43098
#define TAG_Right 62770
#define TAG_RuneValue 49425
#define TAG_SError 24172
#define TAG_Seg 30433
#define TAG_SegmentBinary 41188
#define TAG_SegmentBits 43687
#define TAG_SegmentFloat 21180
#define TAG_SegmentInteger 22664
#define TAG_SegmentUtf 5205
#define TAG_SizeDefault 11444
#define TAG_StrValue 22621
#define TAG_Sum 30935
#define TAG_Tup 31899
#define TAG_Update 40810
#define LBL_code 9554612
#define LBL_e 319
#define LBL_end 310101
#define LBL_kind 9787483
#define LBL_little 844663329
#define LBL_msg 317947
#define LBL_note 9882809
#define LBL_op 10312
#define LBL_ops 319788
#define LBL_out 319944
#define LBL_pat 320285
#define LBL_severity 75955546
#define LBL_signed 1044674119
#define LBL_size 10026184
#define LBL_span 10032145
#define LBL_start 311115900
#define LBL_text 10052084
#define LBL_ty 10476
#define LBL_unit 10090059
static uint32_t shape_code__severity__msg__span__note[] = {LBL_code, LBL_severity, LBL_msg, LBL_span, LBL_note};
static uint32_t shape_op__e[] = {LBL_op, LBL_e};
static uint32_t shape_ops__out[] = {LBL_ops, LBL_out};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
static uint32_t shape_ty__size__unit__little__signed[] = {LBL_ty, LBL_size, LBL_unit, LBL_little, LBL_signed};
V g_heff_2esyntax_2ecst_2efirstE(V);
V g_heff_2esyntax_2ecst_2efirstE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2efirstE_clo;
V g_heff_2esyntax_2ecst_2elastE(V);
V g_heff_2esyntax_2ecst_2elastE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2elastE_clo;
V g_heff_2esyntax_2epresyntax_2eapp(V, V);
V g_heff_2esyntax_2epresyntax_2eapp_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eapp_clo;
V g_heff_2esyntax_2esurface_2ealtL(V, V);
V g_heff_2esyntax_2esurface_2ealtL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ealtL_clo;
V g_heff_2esyntax_2esurface_2eapplyOp(V, V, V);
V g_heff_2esyntax_2esurface_2eapplyOp_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eapplyOp_clo;
V g_heff_2esyntax_2esurface_2eargL(V, V);
V g_heff_2esyntax_2esurface_2eargL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eargL_clo;
V g_heff_2esyntax_2esurface_2eatomTok(V);
V g_heff_2esyntax_2esurface_2eatomTok_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eatomTok_clo;
V g_heff_2esyntax_2esurface_2eblock(V, V, V);
V g_heff_2esyntax_2esurface_2eblock_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eblock_clo;
HeffT2 g_heff_2esyntax_2esurface_2eblock_24cpr(V, V, V);
V g_heff_2esyntax_2esurface_2eboundBy(V, V);
V g_heff_2esyntax_2esurface_2eboundBy_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eboundBy_clo;
V g_heff_2esyntax_2esurface_2ebracesL(V, V, V, V, V);
V g_heff_2esyntax_2esurface_2ebracesL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ebracesL_clo;
V g_heff_2esyntax_2esurface_2ecatchL(V, V);
V g_heff_2esyntax_2esurface_2ecatchL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ecatchL_clo;
V g_heff_2esyntax_2esurface_2ecommentLinesFrom(V, V, V);
V g_heff_2esyntax_2esurface_2ecommentLinesFrom_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ecommentLinesFrom_clo;
V g_heff_2esyntax_2esurface_2econAtom(V, V, V);
V g_heff_2esyntax_2esurface_2econAtom_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2econAtom_clo;
V g_heff_2esyntax_2esurface_2econL(V, V, V);
V g_heff_2esyntax_2esurface_2econL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2econL_clo;
V g_heff_2esyntax_2esurface_2edeclarationL(V, V);
V g_heff_2esyntax_2esurface_2edeclarationL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2edeclarationL_clo;
V g_heff_2esyntax_2esurface_2edefaultL(V, V);
V g_heff_2esyntax_2esurface_2edefaultL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2edefaultL_clo;
V g_heff_2esyntax_2esurface_2eexprL(V, V, V);
V g_heff_2esyntax_2esurface_2eexprL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eexprL_clo;
HeffT2 g_heff_2esyntax_2esurface_2efieldsOf_24cpr(V, V);
V g_heff_2esyntax_2esurface_2efirstS(V, V, V, V);
V g_heff_2esyntax_2esurface_2efirstS_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2efirstS_clo;
V g_heff_2esyntax_2esurface_2efoldr(V, V, V);
V g_heff_2esyntax_2esurface_2efoldr_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2efoldr_clo;
V g_heff_2esyntax_2esurface_2eifE(V, V, V, V);
V g_heff_2esyntax_2esurface_2eifE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eifE_clo;
V g_heff_2esyntax_2esurface_2eifLetL(V, V, V, V, V, V, V);
V g_heff_2esyntax_2esurface_2eifLetL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eifLetL_clo;
V g_heff_2esyntax_2esurface_2eintOfText(V);
V g_heff_2esyntax_2esurface_2eintOfText_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eintOfText_clo;
V g_heff_2esyntax_2esurface_2ekwAtom(V, V, V);
V g_heff_2esyntax_2esurface_2ekwAtom_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ekwAtom_clo;
V g_heff_2esyntax_2esurface_2elambdaL(V, V, V, V);
V g_heff_2esyntax_2esurface_2elambdaL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2elambdaL_clo;
HeffT2 g_heff_2esyntax_2esurface_2eletBodyL_24cpr(V, V, V, V, V, V);
V g_heff_2esyntax_2esurface_2eletL(V, V, V);
V g_heff_2esyntax_2esurface_2eletL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eletL_clo;
V g_heff_2esyntax_2esurface_2eopL(V, V, V, V, V);
V g_heff_2esyntax_2esurface_2eopL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eopL_clo;
HeffT2 g_heff_2esyntax_2esurface_2eopRhsOf_24cpr(V);
V g_heff_2esyntax_2esurface_2eparenL(V, V, V, V, V);
V g_heff_2esyntax_2esurface_2eparenL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eparenL_clo;
V g_heff_2esyntax_2esurface_2epushS_24s1868233564x1858628873(V, V, V, V);
V g_heff_2esyntax_2esurface_2epushS_24s1868233564x1858628873_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2epushS_24s1868233564x1858628873_clo;
V g_heff_2esyntax_2esurface_2eresolve_24s1832151779x1448561609(V, V, V);
V g_heff_2esyntax_2esurface_2eresolve_24s1832151779x1448561609_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eresolve_24s1832151779x1448561609_clo;
V g_heff_2esyntax_2esurface_2esegmentL(V, V);
V g_heff_2esyntax_2esurface_2esegmentL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2esegmentL_clo;
V g_heff_2esyntax_2esurface_2esegmentOf_24s1547151193x813882637(V, V, V, V, V);
V g_heff_2esyntax_2esurface_2esegmentOf_24s1547151193x813882637_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2esegmentOf_24s1547151193x813882637_clo;
V g_heff_2esyntax_2esurface_2especWord(V, V, V);
V g_heff_2esyntax_2esurface_2especWord_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2especWord_clo;
V g_heff_2esyntax_2esurface_2estmtL(V, V);
V g_heff_2esyntax_2esurface_2estmtL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2estmtL_clo;
V g_heff_2esyntax_2esurface_2etryTypeL(V, V);
V g_heff_2esyntax_2esurface_2etryTypeL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2etryTypeL_clo;
V g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993(V, V, V, V, V);
V g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_clo;
V g_heff_2esyntax_2esurface_2eunitOf(V, V, V);
V g_heff_2esyntax_2esurface_2eunitOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eunitOf_clo;
V g_heff_2esyntax_2esurface_2eupdateSettingL(V, V);
V g_heff_2esyntax_2esurface_2eupdateSettingL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eupdateSettingL_clo;
HeffT2 g_heff_2esyntax_2esurface_2evalueKind_24cpr(V, V, V, V);
V g_heff_2esyntax_2esurface_2evariantL(V, V);
V g_heff_2esyntax_2esurface_2evariantL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2evariantL_clo;
HeffT2 g_heff_2esyntax_2esurface_2ewithScope_24cpr(V, V, V);
V g_list_2emap_24s513201124x806973253(V);
V g_list_2emap_24s513201124x806973253_entry(V self, V *a);
extern Clo g_list_2emap_24s513201124x806973253_clo;
V g_prelude_2eskipSpaces(V, V, V);
V g_prelude_2eskipSpaces_entry(V self, V *a);
extern Clo g_prelude_2eskipSpaces_clo;
V g_prelude_2etraverse_24s499544530x2060473942(V, V);
V g_prelude_2etraverse_24s499544530x2060473942_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s499544530x2060473942_clo;
HEFF_LIT(g_heff_2esyntax_2esurface_2ecommentLinesFrom_str0, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecommentLinesFrom_str1, 2, "--");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecommentLinesFrom_str2, 1, "\012");
Clo g_heff_2esyntax_2esurface_2ecommentLinesFrom_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2ecommentLinesFrom_entry, 3, 0};

V g_heff_2esyntax_2esurface_2ecommentLinesFrom(V v_src_240, V v_i_241, V v_to_242) {
top: ;
  if (heff_intLe_c_lent(v_to_242, v_i_241, 0)) {
    heff_drop(v_i_241);
    heff_drop(v_to_242);
    return NTAG(TAG_True);
  } else {
    V v_j_244 = heff_strFind_lent(((V)&g_heff_2esyntax_2esurface_2ecommentLinesFrom_str0), v_src_240, v_i_241, 1);
    V v_t_246;
    if (heff_intLt_c_lent(v_j_244, MK_INT(0LL), 2)) {
      heff_drop(v_j_244);
      v_t_246 = heff_strLength_lent(v_src_240, 0);
    } else {
      v_t_246 = v_j_244;
    }
    V v_s_247 = heff_strSlice_lent(v_src_240, v_i_241, v_t_246, 4);
    V v_t_248 = (g_prelude_2eskipSpaces(v_s_247, MK_INT(0LL), MK_INT(1LL)));
    int64_t v_t_249 = (heff_unbox_word(heff_strLength_lent(v_s_247, 0)) - ((int64_t)1ULL));
    V v_t_2410 = (g_prelude_2eskipSpaces(v_s_247, heff_box_word(v_t_249), MK_INT(-1LL)));
    V v_s_2411 = heff_strSlice(v_s_247, v_t_248, heff_intAdd(v_t_2410, MK_INT(1LL)));
    if (heff_strEq_c(heff_strSlice(v_s_2411, MK_INT(0LL), MK_INT(2LL)), ((V)&g_heff_2esyntax_2esurface_2ecommentLinesFrom_str1))) {
      V v_j_2413 = heff_strFind_lent(((V)&g_heff_2esyntax_2esurface_2ecommentLinesFrom_str2), v_src_240, v_i_241, 5);
      V v_t_2415;
      if (heff_intLt_c_lent(v_j_2413, MK_INT(0LL), 2)) {
        heff_drop(v_j_2413);
        v_t_2415 = heff_strLength_lent(v_src_240, 0);
      } else {
        v_t_2415 = v_j_2413;
      }
      V t_0 = v_src_240;
      V t_1 = heff_intAdd(v_t_2415, MK_INT(1LL));
      V t_2 = v_to_242;
      v_src_240 = t_0;
      v_i_241 = t_1;
      v_to_242 = t_2;
      goto top;
    } else {
      heff_drop(v_i_241);
      heff_drop(v_to_242);
      return NTAG(TAG_False);
    }
  }
}
V g_heff_2esyntax_2esurface_2ecommentLinesFrom_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2esurface_2ecommentLinesFrom(a0, a[1], a[2]); heff_drop(a0); return r;
}
V g_heff_2esyntax_2esurface_2eletBodyL_24cpr_lam0(V self, V *args);

HeffT2 g_heff_2esyntax_2esurface_2eletBodyL_24cpr(V v_r_240, V v_kw_241, V v_x3_242, V v_names_243, V v_body_244, V v_z_245) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_MkPair: {
    V v_p_246 = heff_field(v_x3_242, 0);
    V v_rhs_247 = heff_field(v_x3_242, 1);
    heff_take_n(v_x3_242, 3ULL, 2);
    V v_m_248 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_body_244)}));
    return (g_heff_2esyntax_2esurface_2ewithScope_24cpr(v_names_243, heff_clo_n(g_heff_2esyntax_2esurface_2eletBodyL_24cpr_lam0, 1, 5, (V[]){v_m_248, v_p_246, v_body_244, v_kw_241, v_rhs_247}), v_z_245));
  }
  default: return ((HeffT2){{heff_nomatch(v_x3_242)}});
  }
}
V g_heff_2esyntax_2esurface_2eletBodyL_24cpr_lam0(V self, V *args) {
  V v_st_249 = args[0];
  V v_m_248 = heff_env(self)[0];
  V v_p_246 = heff_env(self)[1];
  V v_body_244 = heff_env(self)[2];
  V v_kw_241 = heff_env(self)[3];
  V v_rhs_247 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_x1_2410 = heff_tr(heff_call(v_m_248, 1, (V[]){v_st_249}));
  switch (heff_tag_of(v_x1_2410)) {
  case TAG_MkPair: {
    V v_x11_2411 = heff_field(v_x1_2410, 0);
    V v_st_2412 = heff_field(v_x1_2410, 1);
    V v_ru_24x1_2410_24MkPair = heff_take_reuse_n(v_x1_2410, 3ULL, 2);
    switch (heff_tag_of(v_x11_2411)) {
    case TAG_Left: {
      V v_e_2413 = heff_field(v_x11_2411, 0);
      heff_take_n(v_x11_2411, 1ULL, 1);
      heff_drop(v_p_246);
      heff_drop(v_body_244);
      heff_drop_rec(v_kw_241, 9);
      heff_drop(v_rhs_247);
      return heff_tag_at_n(v_ru_24x1_2410_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2413}), v_st_2412});
    }
    case TAG_Right: {
      V v_x_2414 = heff_field(v_x11_2411, 0);
      heff_take_n(v_x11_2411, 1ULL, 1);
      V v_t_2417;
      switch (heff_tag_of(v_p_246)) {
      case TAG_At: {
        V v_s_2416 = heff_dup(heff_field(v_p_246, 1));
        v_t_2417 = v_s_2416;
        break;
      }
      default: heff_nomatch(v_p_246);
      }
      V v_t_2420;
      switch (heff_tag_of(v_x_2414)) {
      case TAG_At: {
        V v_s_2419 = heff_dup(heff_field(v_x_2414, 1));
        v_t_2420 = v_s_2419;
        break;
      }
      default: heff_nomatch(v_x_2414);
      }
      V v_t_2421 = ({ V rv_1 = heff_get_n(v_t_2420, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_2417, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
      V v_t_2422 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_246, v_x_2414}), v_t_2421});
      V v_t_2423 = (g_heff_2esyntax_2ecst_2elastE(v_body_244));
      V v_e_2424 = heff_get_n(v_t_2423, 4, 9);
      V v_t_2425 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_241, 3, 9), v_e_2424});
      V v_x_2426 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ELetIn, 2, (V[]){v_rhs_247, v_t_2422}), v_t_2425});
      return heff_tag_at_n(v_ru_24x1_2410_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2426}), v_st_2412});
    }
    default: return heff_nomatch(v_x11_2411);
    }
  }
  default: return heff_nomatch(v_x1_2410);
  }
}
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str0, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str1, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str2, 3, "err");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str3, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str4, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str5, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str6, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str7, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str8, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str9, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str10, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str11, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str12, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str13, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str14, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str15, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str16, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str17, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str18, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str19, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str20, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str21, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str22, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str23, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str24, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str25, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str26, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str27, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str28, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str29, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str30, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str31, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str32, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str33, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str34, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str35, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str36, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str37, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str38, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str39, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str40, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str41, 61, "a `try` names the type of the throws it hears as `(err := T)`");
V g_heff_2esyntax_2esurface_2etryTypeL_lam0(V self, V *args); static Clo g_heff_2esyntax_2esurface_2etryTypeL_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2etryTypeL_lam0, 1, 0};
V g_heff_2esyntax_2esurface_2etryTypeL_lam1(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam2(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam3(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam4(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam5(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam6(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam7(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam8(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam9(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam10(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam11(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam12(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam13(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam14(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam15(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam16(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam17(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam18(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam19(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam20(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam21(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam22(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam23(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam24(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam25(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam26(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam27(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam28(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam29(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam30(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam31(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam32(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam33(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam34(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam35(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam36(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam37(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam38(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam39(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam40(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam41(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam42(V self, V *args);
Clo g_heff_2esyntax_2esurface_2etryTypeL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2etryTypeL_entry, 2, 0};

V g_heff_2esyntax_2esurface_2etryTypeL(V v_r_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nothing: {
    heff_drop_rec(v_r_240, 3);
    return ((V)&g_heff_2esyntax_2esurface_2etryTypeL_lam0_clo);
  }
  case TAG_Just: {
    V v_x21_244 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24Just = heff_take_reuse_n(v_x2_241, 1ULL, 1);
    switch (heff_tag_of(v_x21_244)) {
    case TAG_Atom: {
      heff_drop_rec(v_r_240, 3);
      V v_t_246 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 1); r_; });
      V v_t_247 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_246, 3), heff_get_n(v_t_246, 4, 9)});
      V v_t_248 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str0)}), v_t_247});
      V v_x_249 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_248});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam1, 1, 1, (V[]){v_x_249});
    }
    case TAG_EParen: {
      heff_drop_rec(v_r_240, 3);
      V v_t_2414 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 3); r_; });
      V v_t_2415 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_2414, 3), heff_get_n(v_t_2414, 4, 9)});
      V v_t_2416 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str1)}), v_t_2415});
      V v_x_2417 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_2416});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam2, 1, 1, (V[]){v_x_2417});
    }
    case TAG_Named: {
      V v_x_2420 = heff_field(v_x21_244, 1);
      V v_e_2422 = heff_field(v_x21_244, 3);
      heff_take_n(v_x21_244, 10ULL, 5);
      heff_drop_cell(v_ru_24x2_241_24Just, 1);
      if (heff_strEq_c(heff_dup(heff_rfield(v_x_2420, 1)), ((V)&g_heff_2esyntax_2esurface_2etryTypeL_str2))) {
        heff_drop_rec(v_x_2420, 9);
        V v_m_2425 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_2422}));
        return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam3, 1, 1, (V[]){v_m_2425});
      } else {
        heff_drop_rec(v_r_240, 3);
        heff_drop(v_e_2422);
        return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam4, 1, 1, (V[]){v_x_2420});
      }
    }
    case TAG_Tup: {
      heff_drop_rec(v_r_240, 3);
      V v_t_2441 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 4); r_; });
      V v_t_2442 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_2441, 3), heff_get_n(v_t_2441, 4, 9)});
      V v_t_2443 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str4)}), v_t_2442});
      V v_x_2444 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_2443});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam5, 1, 1, (V[]){v_x_2444});
    }
    case TAG_Seg: {
      heff_drop_rec(v_r_240, 3);
      V v_t_2449 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 3); r_; });
      V v_t_2450 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_2449, 3), heff_get_n(v_t_2449, 4, 9)});
      V v_t_2451 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str5)}), v_t_2450});
      V v_x_2452 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_2451});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam6, 1, 1, (V[]){v_x_2452});
    }
    case TAG_Braces: {
      heff_drop_rec(v_r_240, 3);
      V v_t_2458 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 4); r_; });
      V v_t_2459 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_2458, 3), heff_get_n(v_t_2458, 4, 9)});
      V v_t_2460 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str6)}), v_t_2459});
      V v_x_2461 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_2460});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam7, 1, 1, (V[]){v_x_2461});
    }
    case TAG_Update: {
      heff_drop_rec(v_r_240, 3);
      V v_t_2469 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 6); r_; });
      V v_t_2470 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_2469, 3), heff_get_n(v_t_2469, 4, 9)});
      V v_t_2471 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str7)}), v_t_2470});
      V v_x_2472 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_2471});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam8, 1, 1, (V[]){v_x_2472});
    }
    case TAG_EUSet: {
      heff_drop_rec(v_r_240, 3);
      V v_t_2477 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 3); r_; });
      V v_t_2478 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_2477, 3), heff_get_n(v_t_2477, 4, 9)});
      V v_t_2479 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str8)}), v_t_2478});
      V v_x_2480 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_2479});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam9, 1, 1, (V[]){v_x_2480});
    }
    case TAG_InstB: {
      heff_drop_rec(v_r_240, 3);
      V v_t_2487 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 5); r_; });
      V v_t_2488 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_2487, 3), heff_get_n(v_t_2487, 4, 9)});
      V v_t_2489 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str9)}), v_t_2488});
      V v_x_2490 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_2489});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam10, 1, 1, (V[]){v_x_2490});
    }
    case TAG_EFSet: {
      heff_drop_rec(v_r_240, 3);
      V v_t_2495 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 3); r_; });
      V v_t_2496 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_2495, 3), heff_get_n(v_t_2495, 4, 9)});
      V v_t_2497 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str10)}), v_t_2496});
      V v_x_2498 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_2497});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam11, 1, 1, (V[]){v_x_2498});
    }
    case TAG_EFDefault: {
      heff_drop_rec(v_r_240, 3);
      V v_t_24103 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 3); r_; });
      V v_t_24104 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24103, 3), heff_get_n(v_t_24103, 4, 9)});
      V v_t_24105 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str11)}), v_t_24104});
      V v_x_24106 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_24105});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam12, 1, 1, (V[]){v_x_24106});
    }
    case TAG_Sum: {
      heff_drop_rec(v_r_240, 3);
      V v_t_24113 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 5); r_; });
      V v_t_24114 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24113, 3), heff_get_n(v_t_24113, 4, 9)});
      V v_t_24115 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str12)}), v_t_24114});
      V v_x_24116 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_24115});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam13, 1, 1, (V[]){v_x_24116});
    }
    case TAG_ECon: {
      heff_drop_rec(v_r_240, 3);
      V v_t_24120 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 2); r_; });
      V v_t_24121 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24120, 3), heff_get_n(v_t_24120, 4, 9)});
      V v_t_24122 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str13)}), v_t_24121});
      V v_x_24123 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_24122});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam14, 1, 1, (V[]){v_x_24123});
    }
    case TAG_EField: {
      heff_drop_rec(v_r_240, 3);
      V v_t_24127 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 2); r_; });
      V v_t_24128 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24127, 3), heff_get_n(v_t_24127, 4, 9)});
      V v_t_24129 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str14)}), v_t_24128});
      V v_x_24130 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_24129});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam15, 1, 1, (V[]){v_x_24130});
    }
    case TAG_ENeg: {
      heff_drop_rec(v_r_240, 3);
      V v_t_24134 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 2); r_; });
      V v_t_24135 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24134, 3), heff_get_n(v_t_24134, 4, 9)});
      V v_t_24136 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str15)}), v_t_24135});
      V v_x_24137 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_24136});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam16, 1, 1, (V[]){v_x_24137});
    }
    case TAG_App: {
      heff_drop_rec(v_r_240, 3);
      V v_t_24141 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 2); r_; });
      V v_t_24142 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24141, 3), heff_get_n(v_t_24141, 4, 9)});
      V v_t_24143 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str16)}), v_t_24142});
      V v_x_24144 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_24143});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam17, 1, 1, (V[]){v_x_24144});
    }
    case TAG_Op: {
      heff_drop_rec(v_r_240, 3);
      V v_t_24149 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 3); r_; });
      V v_t_24150 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24149, 3), heff_get_n(v_t_24149, 4, 9)});
      V v_t_24151 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str17)}), v_t_24150});
      V v_x_24152 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_24151});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam18, 1, 1, (V[]){v_x_24152});
    }
    case TAG_Ops: {
      heff_drop_rec(v_r_240, 3);
      V v_t_24156 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 2); r_; });
      V v_t_24157 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24156, 3), heff_get_n(v_t_24156, 4, 9)});
      V v_t_24158 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str18)}), v_t_24157});
      V v_x_24159 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_24158});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam19, 1, 1, (V[]){v_x_24159});
    }
    case TAG_OpRhs: {
      heff_drop_rec(v_r_240, 3);
      V v_t_24163 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 2); r_; });
      V v_t_24164 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24163, 3), heff_get_n(v_t_24163, 4, 9)});
      V v_t_24165 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str19)}), v_t_24164});
      V v_x_24166 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_24165});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam20, 1, 1, (V[]){v_x_24166});
    }
    case TAG_Ann: {
      heff_drop_rec(v_r_240, 3);
      V v_t_24171 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 3); r_; });
      V v_t_24172 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24171, 3), heff_get_n(v_t_24171, 4, 9)});
      V v_t_24173 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str20)}), v_t_24172});
      V v_x_24174 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_24173});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam21, 1, 1, (V[]){v_x_24174});
    }
    case TAG_BVar: {
      heff_drop_rec(v_r_240, 3);
      V v_t_24177 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 1); r_; });
      V v_t_24178 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24177, 3), heff_get_n(v_t_24177, 4, 9)});
      V v_t_24179 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str21)}), v_t_24178});
      V v_x_24180 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_24179});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam22, 1, 1, (V[]){v_x_24180});
    }
    case TAG_BImp: {
      heff_drop_rec(v_r_240, 3);
      V v_t_24185 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 3); r_; });
      V v_t_24186 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24185, 3), heff_get_n(v_t_24185, 4, 9)});
      V v_t_24187 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str22)}), v_t_24186});
      V v_x_24188 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_24187});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam23, 1, 1, (V[]){v_x_24188});
    }
    case TAG_BAnn: {
      heff_drop_rec(v_r_240, 3);
      V v_t_24195 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 5); r_; });
      V v_t_24196 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24195, 3), heff_get_n(v_t_24195, 4, 9)});
      V v_t_24197 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str23)}), v_t_24196});
      V v_x_24198 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_24197});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam24, 1, 1, (V[]){v_x_24198});
    }
    case TAG_Lam: {
      heff_drop_rec(v_r_240, 3);
      V v_t_24204 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 4); r_; });
      V v_t_24205 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24204, 3), heff_get_n(v_t_24204, 4, 9)});
      V v_t_24206 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str24)}), v_t_24205});
      V v_x_24207 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_24206});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam25, 1, 1, (V[]){v_x_24207});
    }
    case TAG_Case: {
      heff_drop_rec(v_r_240, 3);
      V v_t_24213 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 4); r_; });
      V v_t_24214 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24213, 3), heff_get_n(v_t_24213, 4, 9)});
      V v_t_24215 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str25)}), v_t_24214});
      V v_x_24216 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_24215});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam26, 1, 1, (V[]){v_x_24216});
    }
    case TAG_EAlt: {
      heff_drop_rec(v_r_240, 3);
      V v_t_24221 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 3); r_; });
      V v_t_24222 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24221, 3), heff_get_n(v_t_24221, 4, 9)});
      V v_t_24223 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str26)}), v_t_24222});
      V v_x_24224 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_24223});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam27, 1, 1, (V[]){v_x_24224});
    }
    case TAG_If: {
      heff_drop_rec(v_r_240, 3);
      V v_t_24232 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 6); r_; });
      V v_t_24233 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24232, 3), heff_get_n(v_t_24232, 4, 9)});
      V v_t_24234 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str27)}), v_t_24233});
      V v_x_24235 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_24234});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam28, 1, 1, (V[]){v_x_24235});
    }
    case TAG_Do: {
      heff_drop_rec(v_r_240, 3);
      V v_t_24239 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 2); r_; });
      V v_t_24240 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24239, 3), heff_get_n(v_t_24239, 4, 9)});
      V v_t_24241 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str28)}), v_t_24240});
      V v_x_24242 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_24241});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam29, 1, 1, (V[]){v_x_24242});
    }
    case TAG_ESBind: {
      heff_drop_rec(v_r_240, 3);
      V v_t_24247 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 3); r_; });
      V v_t_24248 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24247, 3), heff_get_n(v_t_24247, 4, 9)});
      V v_t_24249 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str29)}), v_t_24248});
      V v_x_24250 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_24249});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam30, 1, 1, (V[]){v_x_24250});
    }
    case TAG_ELet: {
      heff_drop_rec(v_r_240, 3);
      V v_t_24258 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 6); r_; });
      V v_t_24259 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24258, 3), heff_get_n(v_t_24258, 4, 9)});
      V v_t_24260 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str30)}), v_t_24259});
      V v_x_24261 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_24260});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam31, 1, 1, (V[]){v_x_24261});
    }
    case TAG_ELetMut: {
      heff_drop_rec(v_r_240, 3);
      V v_t_24269 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 6); r_; });
      V v_t_24270 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24269, 3), heff_get_n(v_t_24269, 4, 9)});
      V v_t_24271 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str31)}), v_t_24270});
      V v_x_24272 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_24271});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam32, 1, 1, (V[]){v_x_24272});
    }
    case TAG_EAssign: {
      heff_drop_rec(v_r_240, 3);
      V v_t_24277 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 3); r_; });
      V v_t_24278 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24277, 3), heff_get_n(v_t_24277, 4, 9)});
      V v_t_24279 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str32)}), v_t_24278});
      V v_x_24280 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_24279});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam33, 1, 1, (V[]){v_x_24280});
    }
    case TAG_EWhile: {
      heff_drop_rec(v_r_240, 3);
      V v_t_24286 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 4); r_; });
      V v_t_24287 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24286, 3), heff_get_n(v_t_24286, 4, 9)});
      V v_t_24288 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str33)}), v_t_24287});
      V v_x_24289 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_24288});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam34, 1, 1, (V[]){v_x_24289});
    }
    case TAG_EFor: {
      heff_drop_rec(v_r_240, 3);
      V v_t_24297 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 6); r_; });
      V v_t_24298 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24297, 3), heff_get_n(v_t_24297, 4, 9)});
      V v_t_24299 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str34)}), v_t_24298});
      V v_x_24300 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_24299});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam35, 1, 1, (V[]){v_x_24300});
    }
    case TAG_EJump: {
      heff_drop_rec(v_r_240, 3);
      V v_t_24303 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 1); r_; });
      V v_t_24304 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24303, 3), heff_get_n(v_t_24303, 4, 9)});
      V v_t_24305 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str35)}), v_t_24304});
      V v_x_24306 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_24305});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam36, 1, 1, (V[]){v_x_24306});
    }
    case TAG_EReturn: {
      heff_drop_rec(v_r_240, 3);
      V v_t_24310 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 2); r_; });
      V v_t_24311 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24310, 3), heff_get_n(v_t_24310, 4, 9)});
      V v_t_24312 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str36)}), v_t_24311});
      V v_x_24313 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_24312});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam37, 1, 1, (V[]){v_x_24313});
    }
    case TAG_ENest: {
      heff_drop_rec(v_r_240, 3);
      V v_t_24319 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 4); r_; });
      V v_t_24320 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24319, 3), heff_get_n(v_t_24319, 4, 9)});
      V v_t_24321 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str37)}), v_t_24320});
      V v_x_24322 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_24321});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam38, 1, 1, (V[]){v_x_24322});
    }
    case TAG_IfThen: {
      heff_drop_rec(v_r_240, 3);
      V v_t_24328 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 4); r_; });
      V v_t_24329 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24328, 3), heff_get_n(v_t_24328, 4, 9)});
      V v_t_24330 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str38)}), v_t_24329});
      V v_x_24331 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_24330});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam39, 1, 1, (V[]){v_x_24331});
    }
    case TAG_ELetCond: {
      heff_drop_rec(v_r_240, 3);
      V v_t_24337 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 4); r_; });
      V v_t_24338 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24337, 3), heff_get_n(v_t_24337, 4, 9)});
      V v_t_24339 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str39)}), v_t_24338});
      V v_x_24340 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_24339});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam40, 1, 1, (V[]){v_x_24340});
    }
    case TAG_ETry: {
      heff_drop_rec(v_r_240, 3);
      V v_t_24346 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 4); r_; });
      V v_t_24347 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24346, 3), heff_get_n(v_t_24346, 4, 9)});
      V v_t_24348 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str40)}), v_t_24347});
      V v_x_24349 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_24348});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam41, 1, 1, (V[]){v_x_24349});
    }
    case TAG_ECatch: {
      heff_drop_rec(v_r_240, 3);
      V v_t_24355 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 4); r_; });
      V v_t_24356 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24355, 3), heff_get_n(v_t_24355, 4, 9)});
      V v_t_24357 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str41)}), v_t_24356});
      V v_x_24358 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_24357});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam42, 1, 1, (V[]){v_x_24358});
    }
    default: return heff_nomatch(v_x21_244);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2esurface_2etryTypeL_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2etryTypeL(a[0], a[1]);
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam0(V self, V *args) {
  V v_st_242 = args[0];
  V v_t_243 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_243, v_st_242});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam1(V self, V *args) {
  V v_st_2410 = args[0];
  V v_x_249 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_249}), v_st_2410});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam2(V self, V *args) {
  V v_st_2418 = args[0];
  V v_x_2417 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2417}), v_st_2418});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam3(V self, V *args) {
  V v_st_2426 = args[0];
  V v_m_2425 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2427 = heff_tr(heff_call(v_m_2425, 1, (V[]){v_st_2426}));
  switch (heff_tag_of(v_x1_2427)) {
  case TAG_MkPair: {
    V v_x11_2428 = heff_field(v_x1_2427, 0);
    V v_st_2429 = heff_field(v_x1_2427, 1);
    V v_ru_24x1_2427_24MkPair = heff_take_reuse_n(v_x1_2427, 3ULL, 2);
    switch (heff_tag_of(v_x11_2428)) {
    case TAG_Left: {
      V v_e_2430 = heff_field(v_x11_2428, 0);
      heff_take_n(v_x11_2428, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_2427_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2430}), v_st_2429});
    }
    case TAG_Right: {
      V v_x_2431 = heff_field(v_x11_2428, 0);
      V v_ru_24x11_2428_24Right = heff_take_reuse_n(v_x11_2428, 1ULL, 1);
      V v_t_2432 = heff_tag_at_n(v_ru_24x11_2428_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Just, 1, (V[]){v_x_2431})});
      return heff_tag_at_n(v_ru_24x1_2427_24MkPair, TAG_MkPair, 2, (V[]){v_t_2432, v_st_2429});
    }
    default: return heff_nomatch(v_x11_2428);
    }
  }
  default: return heff_nomatch(v_x1_2427);
  }
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam4(V self, V *args) {
  V v_st_2433 = args[0];
  V v_x_2420 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2434 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_x_2420, 3), heff_get_n(v_x_2420, 4, 9)});
  V v_t_2435 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str3)}), v_t_2434});
  V v_t_2436 = heff_tag_n(TAG_Right, 1, (V[]){heff_tag_n(TAG_Just, 1, (V[]){v_t_2435})});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2436, v_st_2433});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam5(V self, V *args) {
  V v_st_2445 = args[0];
  V v_x_2444 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2444}), v_st_2445});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam6(V self, V *args) {
  V v_st_2453 = args[0];
  V v_x_2452 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2452}), v_st_2453});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam7(V self, V *args) {
  V v_st_2462 = args[0];
  V v_x_2461 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2461}), v_st_2462});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam8(V self, V *args) {
  V v_st_2473 = args[0];
  V v_x_2472 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2472}), v_st_2473});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam9(V self, V *args) {
  V v_st_2481 = args[0];
  V v_x_2480 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2480}), v_st_2481});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam10(V self, V *args) {
  V v_st_2491 = args[0];
  V v_x_2490 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2490}), v_st_2491});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam11(V self, V *args) {
  V v_st_2499 = args[0];
  V v_x_2498 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2498}), v_st_2499});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam12(V self, V *args) {
  V v_st_24107 = args[0];
  V v_x_24106 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24106}), v_st_24107});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam13(V self, V *args) {
  V v_st_24117 = args[0];
  V v_x_24116 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24116}), v_st_24117});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam14(V self, V *args) {
  V v_st_24124 = args[0];
  V v_x_24123 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24123}), v_st_24124});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam15(V self, V *args) {
  V v_st_24131 = args[0];
  V v_x_24130 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24130}), v_st_24131});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam16(V self, V *args) {
  V v_st_24138 = args[0];
  V v_x_24137 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24137}), v_st_24138});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam17(V self, V *args) {
  V v_st_24145 = args[0];
  V v_x_24144 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24144}), v_st_24145});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam18(V self, V *args) {
  V v_st_24153 = args[0];
  V v_x_24152 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24152}), v_st_24153});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam19(V self, V *args) {
  V v_st_24160 = args[0];
  V v_x_24159 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24159}), v_st_24160});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam20(V self, V *args) {
  V v_st_24167 = args[0];
  V v_x_24166 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24166}), v_st_24167});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam21(V self, V *args) {
  V v_st_24175 = args[0];
  V v_x_24174 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24174}), v_st_24175});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam22(V self, V *args) {
  V v_st_24181 = args[0];
  V v_x_24180 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24180}), v_st_24181});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam23(V self, V *args) {
  V v_st_24189 = args[0];
  V v_x_24188 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24188}), v_st_24189});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam24(V self, V *args) {
  V v_st_24199 = args[0];
  V v_x_24198 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24198}), v_st_24199});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam25(V self, V *args) {
  V v_st_24208 = args[0];
  V v_x_24207 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24207}), v_st_24208});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam26(V self, V *args) {
  V v_st_24217 = args[0];
  V v_x_24216 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24216}), v_st_24217});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam27(V self, V *args) {
  V v_st_24225 = args[0];
  V v_x_24224 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24224}), v_st_24225});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam28(V self, V *args) {
  V v_st_24236 = args[0];
  V v_x_24235 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24235}), v_st_24236});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam29(V self, V *args) {
  V v_st_24243 = args[0];
  V v_x_24242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24242}), v_st_24243});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam30(V self, V *args) {
  V v_st_24251 = args[0];
  V v_x_24250 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24250}), v_st_24251});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam31(V self, V *args) {
  V v_st_24262 = args[0];
  V v_x_24261 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24261}), v_st_24262});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam32(V self, V *args) {
  V v_st_24273 = args[0];
  V v_x_24272 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24272}), v_st_24273});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam33(V self, V *args) {
  V v_st_24281 = args[0];
  V v_x_24280 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24280}), v_st_24281});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam34(V self, V *args) {
  V v_st_24290 = args[0];
  V v_x_24289 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24289}), v_st_24290});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam35(V self, V *args) {
  V v_st_24301 = args[0];
  V v_x_24300 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24300}), v_st_24301});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam36(V self, V *args) {
  V v_st_24307 = args[0];
  V v_x_24306 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24306}), v_st_24307});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam37(V self, V *args) {
  V v_st_24314 = args[0];
  V v_x_24313 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24313}), v_st_24314});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam38(V self, V *args) {
  V v_st_24323 = args[0];
  V v_x_24322 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24322}), v_st_24323});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam39(V self, V *args) {
  V v_st_24332 = args[0];
  V v_x_24331 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24331}), v_st_24332});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam40(V self, V *args) {
  V v_st_24341 = args[0];
  V v_x_24340 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24340}), v_st_24341});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam41(V self, V *args) {
  V v_st_24350 = args[0];
  V v_x_24349 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24349}), v_st_24350});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam42(V self, V *args) {
  V v_st_24359 = args[0];
  V v_x_24358 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24358}), v_st_24359});
}
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str0, 7, "integer");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str1, 28, "a segment says its type once");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str2, 6, "binary");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str3, 28, "a segment says its type once");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str4, 5, "bytes");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str5, 28, "a segment says its type once");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str6, 4, "bits");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str7, 28, "a segment says its type once");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str8, 9, "bitstring");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str9, 28, "a segment says its type once");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str10, 5, "float");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str11, 28, "a segment says its type once");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str12, 4, "utf8");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str13, 28, "a segment says its type once");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str14, 5, "utf16");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str15, 28, "a segment says its type once");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str16, 5, "utf32");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str17, 28, "a segment says its type once");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str18, 3, "big");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str19, 34, "a segment says its endianness once");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str20, 6, "little");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str21, 34, "a segment says its endianness once");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str22, 6, "signed");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str23, 28, "a segment says its sign once");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str24, 8, "unsigned");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str25, 28, "a segment says its sign once");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str26, 227, "a segment's spec is its type (`integer`, `binary`, `bits`, `float`, `utf8`, `utf16`, `utf32`), size (`16`, `size(n)`), unit (`unit(8)`), endianness (`big`, `little`) and sign (`signed`, `unsigned`), between `-`s: `x::16-little`");
Clo g_heff_2esyntax_2esurface_2especWord_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2especWord_entry, 3, 0};

V g_heff_2esyntax_2esurface_2especWord(V v_t_240, V v_s_241, V v_p_242) {
top: ;
  if (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 1)), ((V)&g_heff_2esyntax_2esurface_2especWord_str0))) {
    V v_t_244 = heff_take_field(v_s_241, 0);
    switch (heff_tag_of(v_t_244)) {
    case TAG_Nothing: {
      heff_drop_rec(v_t_240, 9);
      V v_t_245 = heff_tag_n(TAG_Just, 1, (V[]){NTAG(TAG_SegmentInteger)});
      V v_t_246 = ({ V rv_0 = v_t_245; V rr_ = heff_rec_reuse_nf(v_s_241, 30ULL, 5, shape_ty__size__unit__little__signed, 1020u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_246}), v_p_242});
    }
    case TAG_Just: {
      V v_ru_24t_244_24Just = heff_take_reuse_n(v_t_244, 0ULL, 1);
      heff_drop_rec(v_s_241, 5);
      V v_t_248 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_240, 3), heff_get_n(v_t_240, 4, 9)});
      V v_t_249 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2especWord_str1), v_t_248, NTAG(TAG_Nothing)});
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24t_244_24Just, TAG_Left, 1, (V[]){v_t_249}), v_p_242});
    }
    default: return heff_nomatch(v_t_244);
    }
  } else {
    if (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 1)), ((V)&g_heff_2esyntax_2esurface_2especWord_str2))) {
      V v_t_2411 = heff_take_field(v_s_241, 0);
      switch (heff_tag_of(v_t_2411)) {
      case TAG_Nothing: {
        heff_drop_rec(v_t_240, 9);
        V v_t_2412 = heff_tag_n(TAG_Just, 1, (V[]){NTAG(TAG_SegmentBinary)});
        V v_t_2413 = ({ V rv_0 = v_t_2412; V rr_ = heff_rec_reuse_nf(v_s_241, 30ULL, 5, shape_ty__size__unit__little__signed, 1020u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
        return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2413}), v_p_242});
      }
      case TAG_Just: {
        V v_ru_24t_2411_24Just = heff_take_reuse_n(v_t_2411, 0ULL, 1);
        heff_drop_rec(v_s_241, 5);
        V v_t_2415 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_240, 3), heff_get_n(v_t_240, 4, 9)});
        V v_t_2416 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2especWord_str3), v_t_2415, NTAG(TAG_Nothing)});
        return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24t_2411_24Just, TAG_Left, 1, (V[]){v_t_2416}), v_p_242});
      }
      default: return heff_nomatch(v_t_2411);
      }
    } else {
      if (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 1)), ((V)&g_heff_2esyntax_2esurface_2especWord_str4))) {
        V v_t_2418 = heff_take_field(v_s_241, 0);
        switch (heff_tag_of(v_t_2418)) {
        case TAG_Nothing: {
          heff_drop_rec(v_t_240, 9);
          V v_t_2419 = heff_tag_n(TAG_Just, 1, (V[]){NTAG(TAG_SegmentBinary)});
          V v_t_2420 = ({ V rv_0 = v_t_2419; V rr_ = heff_rec_reuse_nf(v_s_241, 30ULL, 5, shape_ty__size__unit__little__signed, 1020u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
          return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2420}), v_p_242});
        }
        case TAG_Just: {
          V v_ru_24t_2418_24Just = heff_take_reuse_n(v_t_2418, 0ULL, 1);
          heff_drop_rec(v_s_241, 5);
          V v_t_2422 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_240, 3), heff_get_n(v_t_240, 4, 9)});
          V v_t_2423 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2especWord_str5), v_t_2422, NTAG(TAG_Nothing)});
          return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24t_2418_24Just, TAG_Left, 1, (V[]){v_t_2423}), v_p_242});
        }
        default: return heff_nomatch(v_t_2418);
        }
      } else {
        if (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 1)), ((V)&g_heff_2esyntax_2esurface_2especWord_str6))) {
          V v_t_2425 = heff_take_field(v_s_241, 0);
          switch (heff_tag_of(v_t_2425)) {
          case TAG_Nothing: {
            heff_drop_rec(v_t_240, 9);
            V v_t_2426 = heff_tag_n(TAG_Just, 1, (V[]){NTAG(TAG_SegmentBits)});
            V v_t_2427 = ({ V rv_0 = v_t_2426; V rr_ = heff_rec_reuse_nf(v_s_241, 30ULL, 5, shape_ty__size__unit__little__signed, 1020u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
            return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2427}), v_p_242});
          }
          case TAG_Just: {
            V v_ru_24t_2425_24Just = heff_take_reuse_n(v_t_2425, 0ULL, 1);
            heff_drop_rec(v_s_241, 5);
            V v_t_2429 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_240, 3), heff_get_n(v_t_240, 4, 9)});
            V v_t_2430 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2especWord_str7), v_t_2429, NTAG(TAG_Nothing)});
            return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24t_2425_24Just, TAG_Left, 1, (V[]){v_t_2430}), v_p_242});
          }
          default: return heff_nomatch(v_t_2425);
          }
        } else {
          if (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 1)), ((V)&g_heff_2esyntax_2esurface_2especWord_str8))) {
            V v_t_2432 = heff_take_field(v_s_241, 0);
            switch (heff_tag_of(v_t_2432)) {
            case TAG_Nothing: {
              heff_drop_rec(v_t_240, 9);
              V v_t_2433 = heff_tag_n(TAG_Just, 1, (V[]){NTAG(TAG_SegmentBits)});
              V v_t_2434 = ({ V rv_0 = v_t_2433; V rr_ = heff_rec_reuse_nf(v_s_241, 30ULL, 5, shape_ty__size__unit__little__signed, 1020u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
              return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2434}), v_p_242});
            }
            case TAG_Just: {
              V v_ru_24t_2432_24Just = heff_take_reuse_n(v_t_2432, 0ULL, 1);
              heff_drop_rec(v_s_241, 5);
              V v_t_2436 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_240, 3), heff_get_n(v_t_240, 4, 9)});
              V v_t_2437 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2especWord_str9), v_t_2436, NTAG(TAG_Nothing)});
              return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24t_2432_24Just, TAG_Left, 1, (V[]){v_t_2437}), v_p_242});
            }
            default: return heff_nomatch(v_t_2432);
            }
          } else {
            if (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 1)), ((V)&g_heff_2esyntax_2esurface_2especWord_str10))) {
              V v_t_2439 = heff_take_field(v_s_241, 0);
              switch (heff_tag_of(v_t_2439)) {
              case TAG_Nothing: {
                heff_drop_rec(v_t_240, 9);
                V v_t_2440 = heff_tag_n(TAG_Just, 1, (V[]){NTAG(TAG_SegmentFloat)});
                V v_t_2441 = ({ V rv_0 = v_t_2440; V rr_ = heff_rec_reuse_nf(v_s_241, 30ULL, 5, shape_ty__size__unit__little__signed, 1020u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
                return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2441}), v_p_242});
              }
              case TAG_Just: {
                V v_ru_24t_2439_24Just = heff_take_reuse_n(v_t_2439, 0ULL, 1);
                heff_drop_rec(v_s_241, 5);
                V v_t_2443 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_240, 3), heff_get_n(v_t_240, 4, 9)});
                V v_t_2444 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2especWord_str11), v_t_2443, NTAG(TAG_Nothing)});
                return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24t_2439_24Just, TAG_Left, 1, (V[]){v_t_2444}), v_p_242});
              }
              default: return heff_nomatch(v_t_2439);
              }
            } else {
              if (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 1)), ((V)&g_heff_2esyntax_2esurface_2especWord_str12))) {
                V v_t_2446 = heff_take_field(v_s_241, 0);
                switch (heff_tag_of(v_t_2446)) {
                case TAG_Nothing: {
                  heff_drop_rec(v_t_240, 9);
                  V v_t_2447 = heff_tag_n(TAG_Just, 1, (V[]){heff_tag_n(TAG_SegmentUtf, 1, (V[]){MK_INT(8LL)})});
                  V v_t_2448 = ({ V rv_0 = v_t_2447; V rr_ = heff_rec_reuse_nf(v_s_241, 30ULL, 5, shape_ty__size__unit__little__signed, 1020u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
                  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2448}), v_p_242});
                }
                case TAG_Just: {
                  V v_ru_24t_2446_24Just = heff_take_reuse_n(v_t_2446, 0ULL, 1);
                  heff_drop_rec(v_s_241, 5);
                  V v_t_2450 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_240, 3), heff_get_n(v_t_240, 4, 9)});
                  V v_t_2451 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2especWord_str13), v_t_2450, NTAG(TAG_Nothing)});
                  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24t_2446_24Just, TAG_Left, 1, (V[]){v_t_2451}), v_p_242});
                }
                default: return heff_nomatch(v_t_2446);
                }
              } else {
                if (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 1)), ((V)&g_heff_2esyntax_2esurface_2especWord_str14))) {
                  V v_t_2453 = heff_take_field(v_s_241, 0);
                  switch (heff_tag_of(v_t_2453)) {
                  case TAG_Nothing: {
                    heff_drop_rec(v_t_240, 9);
                    V v_t_2454 = heff_tag_n(TAG_Just, 1, (V[]){heff_tag_n(TAG_SegmentUtf, 1, (V[]){MK_INT(16LL)})});
                    V v_t_2455 = ({ V rv_0 = v_t_2454; V rr_ = heff_rec_reuse_nf(v_s_241, 30ULL, 5, shape_ty__size__unit__little__signed, 1020u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
                    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2455}), v_p_242});
                  }
                  case TAG_Just: {
                    V v_ru_24t_2453_24Just = heff_take_reuse_n(v_t_2453, 0ULL, 1);
                    heff_drop_rec(v_s_241, 5);
                    V v_t_2457 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_240, 3), heff_get_n(v_t_240, 4, 9)});
                    V v_t_2458 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2especWord_str15), v_t_2457, NTAG(TAG_Nothing)});
                    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24t_2453_24Just, TAG_Left, 1, (V[]){v_t_2458}), v_p_242});
                  }
                  default: return heff_nomatch(v_t_2453);
                  }
                } else {
                  if (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 1)), ((V)&g_heff_2esyntax_2esurface_2especWord_str16))) {
                    V v_t_2460 = heff_take_field(v_s_241, 0);
                    switch (heff_tag_of(v_t_2460)) {
                    case TAG_Nothing: {
                      heff_drop_rec(v_t_240, 9);
                      V v_t_2461 = heff_tag_n(TAG_Just, 1, (V[]){heff_tag_n(TAG_SegmentUtf, 1, (V[]){MK_INT(32LL)})});
                      V v_t_2462 = ({ V rv_0 = v_t_2461; V rr_ = heff_rec_reuse_nf(v_s_241, 30ULL, 5, shape_ty__size__unit__little__signed, 1020u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
                      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2462}), v_p_242});
                    }
                    case TAG_Just: {
                      V v_ru_24t_2460_24Just = heff_take_reuse_n(v_t_2460, 0ULL, 1);
                      heff_drop_rec(v_s_241, 5);
                      V v_t_2464 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_240, 3), heff_get_n(v_t_240, 4, 9)});
                      V v_t_2465 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2especWord_str17), v_t_2464, NTAG(TAG_Nothing)});
                      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24t_2460_24Just, TAG_Left, 1, (V[]){v_t_2465}), v_p_242});
                    }
                    default: return heff_nomatch(v_t_2460);
                    }
                  } else {
                    if (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 1)), ((V)&g_heff_2esyntax_2esurface_2especWord_str18))) {
                      V v_t_2467 = heff_take_field(v_s_241, 3);
                      switch (heff_tag_of(v_t_2467)) {
                      case TAG_Nothing: {
                        heff_drop_rec(v_t_240, 9);
                        V v_t_2468 = heff_tag_n(TAG_Just, 1, (V[]){NTAG(TAG_False)});
                        V v_t_2469 = ({ V rv_3 = v_t_2468; V rr_ = heff_rec_reuse_nf(v_s_241, 23ULL, 5, shape_ty__size__unit__little__signed, 831u, 0u); heff_rfield(rr_, 3) = rv_3; rr_; });
                        return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2469}), v_p_242});
                      }
                      case TAG_Just: {
                        V v_ru_24t_2467_24Just = heff_take_reuse_n(v_t_2467, 0ULL, 1);
                        heff_drop_rec(v_s_241, 5);
                        V v_t_2471 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_240, 3), heff_get_n(v_t_240, 4, 9)});
                        V v_t_2472 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2especWord_str19), v_t_2471, NTAG(TAG_Nothing)});
                        return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24t_2467_24Just, TAG_Left, 1, (V[]){v_t_2472}), v_p_242});
                      }
                      default: return heff_nomatch(v_t_2467);
                      }
                    } else {
                      if (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 1)), ((V)&g_heff_2esyntax_2esurface_2especWord_str20))) {
                        V v_t_2474 = heff_take_field(v_s_241, 3);
                        switch (heff_tag_of(v_t_2474)) {
                        case TAG_Nothing: {
                          heff_drop_rec(v_t_240, 9);
                          V v_t_2475 = heff_tag_n(TAG_Just, 1, (V[]){NTAG(TAG_True)});
                          V v_t_2476 = ({ V rv_3 = v_t_2475; V rr_ = heff_rec_reuse_nf(v_s_241, 23ULL, 5, shape_ty__size__unit__little__signed, 831u, 0u); heff_rfield(rr_, 3) = rv_3; rr_; });
                          return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2476}), v_p_242});
                        }
                        case TAG_Just: {
                          V v_ru_24t_2474_24Just = heff_take_reuse_n(v_t_2474, 0ULL, 1);
                          heff_drop_rec(v_s_241, 5);
                          V v_t_2478 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_240, 3), heff_get_n(v_t_240, 4, 9)});
                          V v_t_2479 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2especWord_str21), v_t_2478, NTAG(TAG_Nothing)});
                          return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24t_2474_24Just, TAG_Left, 1, (V[]){v_t_2479}), v_p_242});
                        }
                        default: return heff_nomatch(v_t_2474);
                        }
                      } else {
                        if (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 1)), ((V)&g_heff_2esyntax_2esurface_2especWord_str22))) {
                          V v_t_2481 = heff_take_field(v_s_241, 4);
                          switch (heff_tag_of(v_t_2481)) {
                          case TAG_Nothing: {
                            heff_drop_rec(v_t_240, 9);
                            V v_t_2482 = heff_tag_n(TAG_Just, 1, (V[]){NTAG(TAG_True)});
                            V v_t_2483 = ({ V rv_4 = v_t_2482; V rr_ = heff_rec_reuse_nf(v_s_241, 15ULL, 5, shape_ty__size__unit__little__signed, 255u, 0u); heff_rfield(rr_, 4) = rv_4; rr_; });
                            return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2483}), v_p_242});
                          }
                          case TAG_Just: {
                            V v_ru_24t_2481_24Just = heff_take_reuse_n(v_t_2481, 0ULL, 1);
                            heff_drop_rec(v_s_241, 5);
                            V v_t_2485 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_240, 3), heff_get_n(v_t_240, 4, 9)});
                            V v_t_2486 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2especWord_str23), v_t_2485, NTAG(TAG_Nothing)});
                            return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24t_2481_24Just, TAG_Left, 1, (V[]){v_t_2486}), v_p_242});
                          }
                          default: return heff_nomatch(v_t_2481);
                          }
                        } else {
                          if (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 1)), ((V)&g_heff_2esyntax_2esurface_2especWord_str24))) {
                            V v_t_2488 = heff_take_field(v_s_241, 4);
                            switch (heff_tag_of(v_t_2488)) {
                            case TAG_Nothing: {
                              heff_drop_rec(v_t_240, 9);
                              V v_t_2489 = heff_tag_n(TAG_Just, 1, (V[]){NTAG(TAG_False)});
                              V v_t_2490 = ({ V rv_4 = v_t_2489; V rr_ = heff_rec_reuse_nf(v_s_241, 15ULL, 5, shape_ty__size__unit__little__signed, 255u, 0u); heff_rfield(rr_, 4) = rv_4; rr_; });
                              return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2490}), v_p_242});
                            }
                            case TAG_Just: {
                              V v_ru_24t_2488_24Just = heff_take_reuse_n(v_t_2488, 0ULL, 1);
                              heff_drop_rec(v_s_241, 5);
                              V v_t_2492 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_240, 3), heff_get_n(v_t_240, 4, 9)});
                              V v_t_2493 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2especWord_str25), v_t_2492, NTAG(TAG_Nothing)});
                              return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24t_2488_24Just, TAG_Left, 1, (V[]){v_t_2493}), v_p_242});
                            }
                            default: return heff_nomatch(v_t_2488);
                            }
                          } else {
                            heff_drop_rec(v_s_241, 5);
                            V v_t_2494 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_240, 3), heff_get_n(v_t_240, 4, 9)});
                            V v_t_2495 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2especWord_str26), v_t_2494, NTAG(TAG_Nothing)});
                            return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2495}), v_p_242});
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}
V g_heff_2esyntax_2esurface_2especWord_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2especWord(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2esyntax_2esurface_2eunitOf_str0, 3, "int");
HEFF_LIT(g_heff_2esyntax_2esurface_2eunitOf_str1, 28, "a segment says its unit once");
HEFF_LIT(g_heff_2esyntax_2esurface_2eunitOf_str2, 47, "a unit is a number of bits, 1 to 256: `unit(8)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eunitOf_str3, 47, "a unit is a number of bits, 1 to 256: `unit(8)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eunitOf_str4, 47, "a unit is a number of bits, 1 to 256: `unit(8)`");
V g_heff_2esyntax_2esurface_2eunitOf_lam0(V self, V *args);
V g_heff_2esyntax_2esurface_2eunitOf_lam1(V self, V *args);
V g_heff_2esyntax_2esurface_2eunitOf_lam2(V self, V *args);
V g_heff_2esyntax_2esurface_2eunitOf_lam3(V self, V *args);
Clo g_heff_2esyntax_2esurface_2eunitOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eunitOf_entry, 3, 0};

V g_heff_2esyntax_2esurface_2eunitOf(V v_sp_240, V v_n_241, V v_s_242) {
top: ;
  if (heff_strEq_c(heff_dup(heff_rfield(v_n_241, 0)), ((V)&g_heff_2esyntax_2esurface_2eunitOf_str0))) {
    V v_t_244 = (g_heff_2esyntax_2esurface_2eintOfText(heff_rfield(v_n_241, 1)));
    if (heff_intLe_c(MK_INT(1LL), v_t_244)) {
      V v_t_246 = (g_heff_2esyntax_2esurface_2eintOfText(heff_rfield(v_n_241, 1)));
      if (heff_intLe_c(v_t_246, MK_INT(256LL))) {
        V v_n_248 = ({ V b_0 = heff_get_n(v_n_241, 1, 9); V r_ = (g_heff_2esyntax_2esurface_2eintOfText(b_0)); heff_drop(b_0); r_; });
        return heff_clo_n(g_heff_2esyntax_2esurface_2eunitOf_lam0, 1, 3, (V[]){v_s_242, v_n_248, v_sp_240});
      } else {
        heff_drop_rec(v_n_241, 9);
        heff_drop_rec(v_s_242, 5);
        return heff_clo_n(g_heff_2esyntax_2esurface_2eunitOf_lam1, 1, 1, (V[]){v_sp_240});
      }
    } else {
      heff_drop_rec(v_n_241, 9);
      heff_drop_rec(v_s_242, 5);
      return heff_clo_n(g_heff_2esyntax_2esurface_2eunitOf_lam2, 1, 1, (V[]){v_sp_240});
    }
  } else {
    heff_drop_rec(v_n_241, 9);
    heff_drop_rec(v_s_242, 5);
    return heff_clo_n(g_heff_2esyntax_2esurface_2eunitOf_lam3, 1, 1, (V[]){v_sp_240});
  }
}
V g_heff_2esyntax_2esurface_2eunitOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2eunitOf(a[0], a[1], a[2]);
}
V g_heff_2esyntax_2esurface_2eunitOf_lam0(V self, V *args) {
  V v_p_249 = args[0];
  V v_s_242 = heff_env(self)[0];
  V v_n_248 = heff_env(self)[1];
  V v_sp_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2410 = heff_take_field(v_s_242, 2);
  switch (heff_tag_of(v_t_2410)) {
  case TAG_Nothing: {
    heff_drop(v_sp_240);
    V v_t_2411 = ({ V rv_2 = heff_tag_n(TAG_Just, 1, (V[]){v_n_248}); V rr_ = heff_rec_reuse_nf(v_s_242, 27ULL, 5, shape_ty__size__unit__little__signed, 975u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2411}), v_p_249});
  }
  case TAG_Just: {
    V v_ru_24t_2410_24Just = heff_take_reuse_n(v_t_2410, 0ULL, 1);
    heff_drop_rec(v_s_242, 5);
    heff_drop(v_n_248);
    V v_t_2413 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2eunitOf_str1), v_sp_240, NTAG(TAG_Nothing)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24t_2410_24Just, TAG_Left, 1, (V[]){v_t_2413}), v_p_249});
  }
  default: return heff_nomatch(v_t_2410);
  }
}
V g_heff_2esyntax_2esurface_2eunitOf_lam1(V self, V *args) {
  V v_st_2414 = args[0];
  V v_sp_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2415 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2eunitOf_str2), v_sp_240, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2415}), v_st_2414});
}
V g_heff_2esyntax_2esurface_2eunitOf_lam2(V self, V *args) {
  V v_st_2416 = args[0];
  V v_sp_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2417 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2eunitOf_str3), v_sp_240, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2417}), v_st_2416});
}
V g_heff_2esyntax_2esurface_2eunitOf_lam3(V self, V *args) {
  V v_st_2418 = args[0];
  V v_sp_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2419 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2eunitOf_str4), v_sp_240, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2419}), v_st_2418});
}
Clo g_heff_2esyntax_2esurface_2esegmentOf_24s1547151193x813882637_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2esegmentOf_24s1547151193x813882637_entry, 5, 0};

V g_heff_2esyntax_2esurface_2esegmentOf_24s1547151193x813882637(V v_inPat_240, V v_sp_241, V v_e_242, V v_v_243, V v_st_244) {
top: ;
  V v_t_246;
  switch (heff_tag_of(v_v_243)) {
  case TAG_StrValue: {
    v_t_246 = NTAG(TAG_SegmentBinary);
    break;
  }
  case TAG_IntValue: {
    v_t_246 = NTAG(TAG_SegmentInteger);
    break;
  }
  case TAG_FloatValue: {
    v_t_246 = NTAG(TAG_SegmentFloat);
    break;
  }
  case TAG_RuneValue: {
    v_t_246 = heff_tag_n(TAG_SegmentUtf, 1, (V[]){MK_INT(8LL)});
    break;
  }
  case TAG_OtherValue: {
    v_t_246 = NTAG(TAG_SegmentInteger);
    break;
  }
  default: heff_nomatch(v_v_243);
  }
  HeffT2 v_t_247 = (g_heff_2esyntax_2esurface_2evalueKind_24cpr(heff_dup(v_sp_241), heff_dup(v_v_243), v_t_246, v_st_244));
  {
    V v_field_248 = v_t_247.f[0];
    V v_field_249 = v_t_247.f[1];
    V v_x11_2410 = v_field_248;
    V v_st_2411 = v_field_249;
    switch (heff_tag_of(v_x11_2410)) {
    case TAG_Left: {
      V v_e_2412 = heff_field(v_x11_2410, 0);
      V v_ru_24x11_2410_24Left = heff_take_reuse_n(v_x11_2410, 1ULL, 1);
      heff_drop(v_sp_241);
      heff_drop(v_e_242);
      heff_drop(v_v_243);
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_2410_24Left, TAG_Left, 1, (V[]){v_e_2412}), v_st_2411});
    }
    case TAG_Right: {
      V v_ru_24x11_2410_24Right = heff_take_reuse_n(v_x11_2410, 0ULL, 1);
      V v_t_2415;
      switch (heff_tag_of(v_v_243)) {
      case TAG_StrValue: {
        v_t_2415 = NTAG(TAG_SegmentBinary);
        break;
      }
      case TAG_IntValue: {
        v_t_2415 = NTAG(TAG_SegmentInteger);
        break;
      }
      case TAG_FloatValue: {
        v_t_2415 = NTAG(TAG_SegmentFloat);
        break;
      }
      case TAG_RuneValue: {
        v_t_2415 = heff_tag_n(TAG_SegmentUtf, 1, (V[]){MK_INT(8LL)});
        break;
      }
      case TAG_OtherValue: {
        v_t_2415 = NTAG(TAG_SegmentInteger);
        break;
      }
      default: heff_nomatch(v_v_243);
      }
      V v_m_2416 = (g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993(v_inPat_240, heff_dup(v_sp_241), heff_dup(v_v_243), v_t_2415, NTAG(TAG_SizeDefault)));
      V v_x1_2417 = heff_tr(heff_call(v_m_2416, 1, (V[]){v_st_2411}));
      switch (heff_tag_of(v_x1_2417)) {
      case TAG_MkPair: {
        V v_x11_2418 = heff_field(v_x1_2417, 0);
        V v_st_2419 = heff_field(v_x1_2417, 1);
        V v_ru_24x1_2417_24MkPair = heff_take_reuse_n(v_x1_2417, 3ULL, 2);
        switch (heff_tag_of(v_x11_2418)) {
        case TAG_Left: {
          V v_e_2420 = heff_field(v_x11_2418, 0);
          heff_take_n(v_x11_2418, 1ULL, 1);
          heff_drop(v_sp_241);
          heff_drop(v_e_242);
          heff_drop(v_v_243);
          heff_drop_cell(v_ru_24x11_2410_24Right, 1);
          return heff_tag_at_n(v_ru_24x1_2417_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2420}), v_st_2419});
        }
        case TAG_Right: {
          V v_ru_24x11_2418_24Right = heff_take_reuse_n(v_x11_2418, 0ULL, 1);
          V v_t_2423;
          switch (heff_tag_of(v_v_243)) {
          case TAG_StrValue: {
            heff_drop_cell(v_ru_24x11_2418_24Right, 1);
            v_t_2423 = NTAG(TAG_SegmentBinary);
            break;
          }
          case TAG_IntValue: {
            heff_take_n(v_v_243, 0ULL, 1);
            heff_drop_cell(v_ru_24x11_2418_24Right, 1);
            v_t_2423 = NTAG(TAG_SegmentInteger);
            break;
          }
          case TAG_FloatValue: {
            heff_drop_cell(v_ru_24x11_2418_24Right, 1);
            v_t_2423 = NTAG(TAG_SegmentFloat);
            break;
          }
          case TAG_RuneValue: {
            v_t_2423 = heff_tag_at_n(v_ru_24x11_2418_24Right, TAG_SegmentUtf, 1, (V[]){MK_INT(8LL)});
            break;
          }
          case TAG_OtherValue: {
            heff_drop_cell(v_ru_24x11_2418_24Right, 1);
            v_t_2423 = NTAG(TAG_SegmentInteger);
            break;
          }
          default: heff_nomatch(v_v_243);
          }
          V v_t_2424 = heff_tag_n(TAG_MkSegment, 5, (V[]){v_e_242, v_t_2423, NTAG(TAG_SizeDefault), NTAG(TAG_False), NTAG(TAG_False)});
          V v_t_2425 = heff_tag_at_n(v_ru_24x11_2410_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2424, v_sp_241})});
          return heff_tag_at_n(v_ru_24x1_2417_24MkPair, TAG_MkPair, 2, (V[]){v_t_2425, v_st_2419});
        }
        default: return heff_nomatch(v_x11_2418);
        }
      }
      default: return heff_nomatch(v_x1_2417);
      }
    }
    default: return heff_nomatch(v_x11_2410);
    }
  }
}
V g_heff_2esyntax_2esurface_2esegmentOf_24s1547151193x813882637_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2esurface_2esegmentOf_24s1547151193x813882637(a0, a[1], a[2], a[3], a[4]); heff_drop(a0); return r;
}
V g_heff_2esyntax_2esurface_2epushS_24s1868233564x1858628873_lam0(V self, V *args);
V g_heff_2esyntax_2esurface_2epushS_24s1868233564x1858628873_lam1(V self, V *args);
Clo g_heff_2esyntax_2esurface_2epushS_24s1868233564x1858628873_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2epushS_24s1868233564x1858628873_entry, 4, 0};

V g_heff_2esyntax_2esurface_2epushS_24s1868233564x1858628873(V v_fix_240, V v_lenient_241, V v_st_242, V v_r_243) {
top: ;
  V v_t_244 = heff_dup(heff_rfield(v_st_242, 0));
  switch (heff_tag_of(v_t_244)) {
  case TAG_Nil: {
    heff_drop(v_fix_240);
    return heff_clo_n(g_heff_2esyntax_2esurface_2epushS_24s1868233564x1858628873_lam0, 1, 2, (V[]){v_r_243, v_st_242});
  }
  case TAG_Cons: {
    V v_before_249 = heff_field(v_t_244, 0);
    heff_take_n(v_t_244, 1ULL, 2);
    V v_m_2411 = (g_heff_2esyntax_2esurface_2efirstS(heff_dup(v_fix_240), v_lenient_241, v_before_249, heff_dup(heff_rfield(v_r_243, 0))));
    return heff_clo_n(g_heff_2esyntax_2esurface_2epushS_24s1868233564x1858628873_lam1, 1, 5, (V[]){v_m_2411, v_st_242, v_fix_240, heff_dup(v_lenient_241), v_r_243});
  }
  default: return heff_nomatch(v_t_244);
  }
}
V g_heff_2esyntax_2esurface_2epushS_24s1868233564x1858628873_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2esyntax_2esurface_2epushS_24s1868233564x1858628873(a[0], a1, a[2], a[3]); heff_drop(a1); return r;
}
V g_heff_2esyntax_2esurface_2epushS_24s1868233564x1858628873_lam0(V self, V *args) {
  V v_st_245 = args[0];
  V v_r_243 = heff_env(self)[0];
  V v_st_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){heff_take_field(v_r_243, 0), heff_take_field(v_st_242, 0)});
  V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){heff_get_n(v_r_243, 1, 2), heff_get_n(v_st_242, 1, 2)});
  V v_t_248 = heff_tag_n(TAG_Right, 1, (V[]){heff_rec_n(2, shape_ops__out, (V[]){v_t_246, v_t_247})});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_248, v_st_245});
}
V g_heff_2esyntax_2esurface_2epushS_24s1868233564x1858628873_lam1(V self, V *args) {
  V v_st_2412 = args[0];
  V v_m_2411 = heff_env(self)[0];
  V v_st_242 = heff_env(self)[1];
  V v_fix_240 = heff_env(self)[2];
  V v_lenient_241 = heff_env(self)[3];
  V v_r_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_x1_2413 = heff_tr(heff_call(v_m_2411, 1, (V[]){v_st_2412}));
  switch (heff_tag_of(v_x1_2413)) {
  case TAG_MkPair: {
    V v_x11_2414 = heff_field(v_x1_2413, 0);
    V v_st_2415 = heff_field(v_x1_2413, 1);
    V v_ru_24x1_2413_24MkPair = heff_take_reuse_n(v_x1_2413, 3ULL, 2);
    switch (heff_tag_of(v_x11_2414)) {
    case TAG_Left: {
      V v_e_2416 = heff_field(v_x11_2414, 0);
      heff_take_n(v_x11_2414, 1ULL, 1);
      heff_drop_rec(v_st_242, 2);
      heff_drop(v_fix_240);
      heff_drop(v_lenient_241);
      heff_drop_rec(v_r_243, 2);
      return heff_tag_at_n(v_ru_24x1_2413_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2416}), v_st_2415});
    }
    case TAG_Right: {
      V v_x_2417 = heff_field(v_x11_2414, 0);
      V v_ru_24x11_2414_24Right = heff_take_reuse_n(v_x11_2414, 1ULL, 1);
      if ((heff_dup(v_x_2417) == NTAG(TAG_True))) {
        heff_drop_cell(v_ru_24x1_2413_24MkPair, 2);
        heff_drop(v_x_2417);
        heff_drop_cell(v_ru_24x11_2414_24Right, 1);
        V v_t_2418 = heff_dup(heff_rfield(v_st_242, 0));
        V v_t_2427;
        switch (heff_tag_of(v_t_2418)) {
        case TAG_Nil: {
          v_t_2427 = v_st_242;
          break;
        }
        case TAG_Cons: {
          V v_o_2419 = heff_field(v_t_2418, 0);
          V v_os_2420 = heff_field(v_t_2418, 1);
          heff_take_n(v_t_2418, 3ULL, 2);
          V v_t_2421 = heff_dup(heff_rfield(v_st_242, 1));
          switch (heff_tag_of(v_t_2421)) {
          case TAG_Nil: {
            heff_drop(v_o_2419);
            heff_drop(v_os_2420);
            v_t_2427 = v_st_242;
            break;
          }
          case TAG_Cons: {
            V v_r_2422 = heff_field(v_t_2421, 0);
            V v_it2_2423 = heff_field(v_t_2421, 1);
            heff_take_n(v_t_2421, 3ULL, 2);
            switch (heff_tag_of(v_it2_2423)) {
            case TAG_Nil: {
              heff_drop(v_o_2419);
              heff_drop(v_os_2420);
              heff_drop(v_r_2422);
              v_t_2427 = v_st_242;
              break;
            }
            case TAG_Cons: {
              V v_l_2424 = heff_field(v_it2_2423, 0);
              V v_rest_2425 = heff_field(v_it2_2423, 1);
              heff_take_n(v_it2_2423, 3ULL, 2);
              heff_drop_rec(v_st_242, 2);
              V v_t_2426 = (g_heff_2esyntax_2esurface_2eapplyOp(v_o_2419, v_l_2424, v_r_2422));
              v_t_2427 = heff_rec_n(2, shape_ops__out, (V[]){v_os_2420, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2426, v_rest_2425})});
              break;
            }
            default: heff_nomatch(v_it2_2423);
            }
            break;
          }
          default: heff_nomatch(v_t_2421);
          }
          break;
        }
        default: heff_nomatch(v_t_2418);
        }
        V v_t_2428 = ({ V a_0 = v_fix_240; V a_1 = v_lenient_241; V a_2 = v_t_2427; V a_3 = v_r_243; V r_ = (g_heff_2esyntax_2esurface_2epushS_24s1868233564x1858628873(a_0, a_1, a_2, a_3)); heff_drop(v_lenient_241); r_; });
        V f_ = v_t_2428;
        args[0] = v_st_2415;
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      } else {
        heff_drop(v_fix_240);
        heff_drop(v_lenient_241);
        heff_drop(v_x_2417);
        V v_t_2429 = heff_tag_n(TAG_Cons, 2, (V[]){heff_take_field(v_r_243, 0), heff_take_field(v_st_242, 0)});
        V v_t_2430 = heff_tag_n(TAG_Cons, 2, (V[]){heff_get_n(v_r_243, 1, 2), heff_get_n(v_st_242, 1, 2)});
        V v_t_2431 = heff_tag_at_n(v_ru_24x11_2414_24Right, TAG_Right, 1, (V[]){heff_rec_n(2, shape_ops__out, (V[]){v_t_2429, v_t_2430})});
        return heff_tag_at_n(v_ru_24x1_2413_24MkPair, TAG_MkPair, 2, (V[]){v_t_2431, v_st_2415});
      }
    }
    default: return heff_nomatch(v_x11_2414);
    }
  }
  default: return heff_nomatch(v_x1_2413);
  }
}
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str0, 3, "con");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str1, 7, " := e)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str2, 51, " := ...)` names an argument, after a function: `f (");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str3, 2, "`(");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str4, 2, "b[");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str5, 1, "[");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str6, 3, "Nil");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str7, 4, "Cons");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str8, 70, "heff has no tuples: a record holds values together, `{ x = a, y = b }`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str9, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str10, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str11, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str12, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str13, 61, "an instance argument is bound before `->`: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str14, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str15, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str16, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str17, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str18, 3, "con");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str19, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str20, 3, "neg");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str21, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str22, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str23, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str24, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str25, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str26, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str27, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str28, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str29, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str30, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str31, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str32, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str33, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str34, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str35, 5, "break");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str36, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str37, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str38, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str39, 12, "unexpected `");
V g_heff_2esyntax_2esurface_2eexprL_lam0(V self, V *args);
V g_heff_2esyntax_2esurface_2eexprL_lam1(V self, V *args);
V g_heff_2esyntax_2esurface_2eexprL_lam2(V self, V *args);
V g_heff_2esyntax_2esurface_2eexprL_lam3(V self, V *args);
V g_heff_2esyntax_2esurface_2eexprL_lam4(V self, V *args);
V g_heff_2esyntax_2esurface_2eexprL_lam6(V self, V *args);
V g_heff_2esyntax_2esurface_2eexprL_lam5(V self, V *args);
V g_heff_2esyntax_2esurface_2eexprL_lam7(V self, V *args);
V g_heff_2esyntax_2esurface_2eexprL_lam8(V self, V *args);
V g_heff_2esyntax_2esurface_2eexprL_lam9(V self, V *args);
V g_heff_2esyntax_2esurface_2eexprL_lam10(V self, V *args);
V g_heff_2esyntax_2esurface_2eexprL_lam11(V self, V *args);
Clo g_heff_2esyntax_2esurface_2eexprL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eexprL_entry, 3, 0};

V g_heff_2esyntax_2esurface_2eexprL(V v_r_240, V v_e0_241, V v_z_242) {
top: ;
  switch (heff_tag_of(v_e0_241)) {
  case TAG_Atom: {
    V v_t_243 = heff_field(v_e0_241, 0);
    V v_ru_24e0_241_24Atom = heff_take_reuse_n(v_e0_241, 1ULL, 1);
    heff_drop_rec(v_r_240, 3);
    if (heff_strEq_c(heff_dup(heff_rfield(v_t_243, 0)), ((V)&g_heff_2esyntax_2esurface_2eexprL_str0))) {
      heff_drop_cell(v_ru_24e0_241_24Atom, 1);
      HEFF_LAST return g_heff_2esyntax_2esurface_2econAtom(v_t_243, NTAG(TAG_Nil), v_z_242);
    } else {
      V v_x_245 = (g_heff_2esyntax_2esurface_2eatomTok(v_t_243));
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24e0_241_24Atom, TAG_Right, 1, (V[]){v_x_245}), v_z_242});
    }
  }
  case TAG_EParen: {
    V v_o_246 = heff_field(v_e0_241, 0);
    V v_e_247 = heff_field(v_e0_241, 1);
    V v_c_248 = heff_field(v_e0_241, 2);
    heff_take_n(v_e0_241, 7ULL, 3);
    return ({ V a_0 = v_r_240; V a_1 = v_o_246; V a_2 = v_e_247; V a_3 = v_c_248; V a_4 = v_z_242; V r_ = (g_heff_2esyntax_2esurface_2eparenL(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_o_246); r_; });
  }
  case TAG_Named: {
    V v_o_249 = heff_field(v_e0_241, 0);
    V v_x_2410 = heff_field(v_e0_241, 1);
    V v_e_2412 = heff_field(v_e0_241, 3);
    V v_c_2413 = heff_field(v_e0_241, 4);
    heff_take_n(v_e0_241, 27ULL, 5);
    V v_m_2414 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_2412}));
    V v_x1_2415 = heff_tr(heff_call(v_m_2414, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x1_2415)) {
    case TAG_MkPair: {
      V v_x11_2416 = heff_field(v_x1_2415, 0);
      V v_st_2417 = heff_field(v_x1_2415, 1);
      V v_ru_24x1_2415_24MkPair = heff_take_reuse_n(v_x1_2415, 3ULL, 2);
      switch (heff_tag_of(v_x11_2416)) {
      case TAG_Left: {
        V v_e_2418 = heff_field(v_x11_2416, 0);
        heff_take_n(v_x11_2416, 1ULL, 1);
        heff_drop_rec(v_o_249, 9);
        heff_drop_rec(v_x_2410, 9);
        heff_drop_rec(v_c_2413, 9);
        return heff_tag_at_n(v_ru_24x1_2415_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2418}), v_st_2417});
      }
      case TAG_Right: {
        V v_ru_24x11_2416_24Right = heff_take_reuse_n(v_x11_2416, 0ULL, 1);
        V v_t_2420 = heff_strAppend(heff_dup(heff_rfield(v_x_2410, 1)), ((V)&g_heff_2esyntax_2esurface_2eexprL_str1));
        V v_t_2421 = heff_strAppend(heff_get_n(v_x_2410, 1, 9), heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eexprL_str2), v_t_2420));
        V v_t_2422 = heff_tag_n(TAG_EInvalid, 1, (V[]){heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eexprL_str3), v_t_2421)});
        V v_t_2423 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_o_249, 3, 9), heff_get_n(v_c_2413, 4, 9)});
        V v_t_2424 = heff_tag_at_n(v_ru_24x11_2416_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2422, v_t_2423})});
        return heff_tag_at_n(v_ru_24x1_2415_24MkPair, TAG_MkPair, 2, (V[]){v_t_2424, v_st_2417});
      }
      default: return heff_nomatch(v_x11_2416);
      }
    }
    default: return heff_nomatch(v_x1_2415);
    }
  }
  case TAG_Tup: {
    V v_o_2425 = heff_field(v_e0_241, 0);
    V v_es_2426 = heff_field(v_e0_241, 1);
    V v_c_2428 = heff_field(v_e0_241, 3);
    heff_take_n(v_e0_241, 11ULL, 4);
    if (heff_strEq_c(heff_dup(heff_rfield(v_o_2425, 1)), ((V)&g_heff_2esyntax_2esurface_2eexprL_str4))) {
      V v_m_2431 = (g_prelude_2etraverse_24s499544530x2060473942(heff_clo_n(g_heff_2esyntax_2esurface_2eexprL_lam0, 1, 1, (V[]){v_r_240}), v_es_2426));
      V v_x1_2432 = heff_tr(heff_call(v_m_2431, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_2432)) {
      case TAG_MkPair: {
        V v_x11_2433 = heff_field(v_x1_2432, 0);
        V v_st_2434 = heff_field(v_x1_2432, 1);
        V v_ru_24x1_2432_24MkPair = heff_take_reuse_n(v_x1_2432, 3ULL, 2);
        switch (heff_tag_of(v_x11_2433)) {
        case TAG_Left: {
          V v_e_2435 = heff_field(v_x11_2433, 0);
          heff_take_n(v_x11_2433, 1ULL, 1);
          heff_drop_rec(v_o_2425, 9);
          heff_drop_rec(v_c_2428, 9);
          return heff_tag_at_n(v_ru_24x1_2432_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2435}), v_st_2434});
        }
        case TAG_Right: {
          V v_x_2436 = heff_field(v_x11_2433, 0);
          V v_ru_24x11_2433_24Right = heff_take_reuse_n(v_x11_2433, 1ULL, 1);
          V v_t_2437 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_o_2425, 3, 9), heff_get_n(v_c_2428, 4, 9)});
          V v_t_2438 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_2433_24Right, TAG_EBinary, 1, (V[]){v_x_2436}), v_t_2437});
          return heff_tag_at_n(v_ru_24x1_2432_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2438}), v_st_2434});
        }
        default: return heff_nomatch(v_x11_2433);
        }
      }
      default: return heff_nomatch(v_x1_2432);
      }
    } else {
      if (heff_strEq_c(heff_dup(heff_rfield(v_o_2425, 1)), ((V)&g_heff_2esyntax_2esurface_2eexprL_str5))) {
        V v_m_2440 = (g_prelude_2etraverse_24s499544530x2060473942(heff_get_n(v_r_240, 0, 3), v_es_2426));
        V v_x1_2441 = heff_tr(heff_call(v_m_2440, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_2441)) {
        case TAG_MkPair: {
          V v_x11_2442 = heff_field(v_x1_2441, 0);
          V v_st_2443 = heff_field(v_x1_2441, 1);
          V v_ru_24x1_2441_24MkPair = heff_take_reuse_n(v_x1_2441, 3ULL, 2);
          switch (heff_tag_of(v_x11_2442)) {
          case TAG_Left: {
            V v_e_2444 = heff_field(v_x11_2442, 0);
            heff_take_n(v_x11_2442, 1ULL, 1);
            heff_drop_rec(v_o_2425, 9);
            heff_drop_rec(v_c_2428, 9);
            return heff_tag_at_n(v_ru_24x1_2441_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2444}), v_st_2443});
          }
          case TAG_Right: {
            V v_x_2445 = heff_field(v_x11_2442, 0);
            V v_ru_24x11_2442_24Right = heff_take_reuse_n(v_x11_2442, 1ULL, 1);
            V v_sp_2446 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_o_2425, 3, 9), heff_get_n(v_c_2428, 4, 9)});
            V v_t_2447 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_2442_24Right, TAG_ETag, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2eexprL_str6)}), heff_dup(v_sp_2446)});
            V v_x_2452 = ({ V a_0 = heff_clo_n(g_heff_2esyntax_2esurface_2eexprL_lam1, 2, 1, (V[]){v_sp_2446}); V a_1 = v_t_2447; V a_2 = v_x_2445; V r_ = heff_tr(g_heff_2esyntax_2esurface_2efoldr(a_0, a_1, a_2)); heff_drop(v_x_2445); r_; });
            return heff_tag_at_n(v_ru_24x1_2441_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2452}), v_st_2443});
          }
          default: return heff_nomatch(v_x11_2442);
          }
        }
        default: return heff_nomatch(v_x1_2441);
        }
      } else {
        V v_m_2453 = (g_prelude_2etraverse_24s499544530x2060473942(heff_get_n(v_r_240, 0, 3), v_es_2426));
        V v_x1_2454 = heff_tr(heff_call(v_m_2453, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_2454)) {
        case TAG_MkPair: {
          V v_x11_2455 = heff_field(v_x1_2454, 0);
          V v_st_2456 = heff_field(v_x1_2454, 1);
          V v_ru_24x1_2454_24MkPair = heff_take_reuse_n(v_x1_2454, 3ULL, 2);
          switch (heff_tag_of(v_x11_2455)) {
          case TAG_Left: {
            V v_e_2457 = heff_field(v_x11_2455, 0);
            heff_take_n(v_x11_2455, 1ULL, 1);
            heff_drop_rec(v_o_2425, 9);
            heff_drop_rec(v_c_2428, 9);
            return heff_tag_at_n(v_ru_24x1_2454_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2457}), v_st_2456});
          }
          case TAG_Right: {
            V v_ru_24x11_2455_24Right = heff_take_reuse_n(v_x11_2455, 0ULL, 1);
            V v_t_2459 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_o_2425, 3, 9), heff_get_n(v_c_2428, 4, 9)});
            V v_t_2460 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_2455_24Right, TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2eexprL_str8)}), v_t_2459});
            return heff_tag_at_n(v_ru_24x1_2454_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2460}), v_st_2456});
          }
          default: return heff_nomatch(v_x11_2455);
          }
        }
        default: return heff_nomatch(v_x1_2454);
        }
      }
    }
  }
  case TAG_Seg: {
    heff_drop_rec(v_r_240, 3);
    V v_t_2464 = (g_heff_2esyntax_2ecst_2efirstE(v_e0_241));
    V v_t_2465 = ({ V a_0 = v_e0_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e0_241, 3); r_; });
    V v_t_2466 = heff_strAppend(heff_get_n(v_t_2465, 1, 9), ((V)&g_heff_2esyntax_2esurface_2eexprL_str9));
    V v_msg_2467 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eexprL_str10), v_t_2466);
    V v_t_2468 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_2464, 3), heff_get_n(v_t_2464, 4, 9)});
    V v_t_2469 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_2467, v_t_2468, NTAG(TAG_Nothing)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2469}), v_z_242});
  }
  case TAG_Braces: {
    V v_o_2470 = heff_field(v_e0_241, 0);
    V v_fs_2471 = heff_field(v_e0_241, 1);
    V v_c_2473 = heff_field(v_e0_241, 3);
    heff_take_n(v_e0_241, 11ULL, 4);
    return (g_heff_2esyntax_2esurface_2ebracesL(v_r_240, v_o_2470, v_fs_2471, v_c_2473, v_z_242));
  }
  case TAG_Update: {
    V v_o_2474 = heff_field(v_e0_241, 0);
    V v_rec_2475 = heff_field(v_e0_241, 1);
    V v_fs_2477 = heff_field(v_e0_241, 3);
    V v_c_2479 = heff_field(v_e0_241, 5);
    heff_take_n(v_e0_241, 43ULL, 6);
    V v_m_2480 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_rec_2475}));
    V v_x1_2481 = heff_tr(heff_call(v_m_2480, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x1_2481)) {
    case TAG_MkPair: {
      V v_x11_2482 = heff_field(v_x1_2481, 0);
      V v_st_2483 = heff_field(v_x1_2481, 1);
      V v_ru_24x1_2481_24MkPair = heff_take_reuse_n(v_x1_2481, 3ULL, 2);
      switch (heff_tag_of(v_x11_2482)) {
      case TAG_Left: {
        V v_e_2484 = heff_field(v_x11_2482, 0);
        heff_take_n(v_x11_2482, 1ULL, 1);
        heff_drop_rec(v_r_240, 3);
        heff_drop_rec(v_o_2474, 9);
        heff_drop(v_fs_2477);
        heff_drop_rec(v_c_2479, 9);
        return heff_tag_at_n(v_ru_24x1_2481_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2484}), v_st_2483});
      }
      case TAG_Right: {
        V v_x_2485 = heff_field(v_x11_2482, 0);
        heff_take_n(v_x11_2482, 1ULL, 1);
        V v_m_2487 = (g_prelude_2etraverse_24s499544530x2060473942(heff_clo_n(g_heff_2esyntax_2esurface_2eexprL_lam2, 1, 1, (V[]){v_r_240}), v_fs_2477));
        V v_x1_2488 = heff_tr(heff_call(v_m_2487, 1, (V[]){v_st_2483}));
        switch (heff_tag_of(v_x1_2488)) {
        case TAG_MkPair: {
          V v_x11_2489 = heff_field(v_x1_2488, 0);
          V v_st_2490 = heff_field(v_x1_2488, 1);
          V v_ru_24x1_2488_24MkPair = heff_take_reuse_n(v_x1_2488, 3ULL, 2);
          switch (heff_tag_of(v_x11_2489)) {
          case TAG_Left: {
            V v_e_2491 = heff_field(v_x11_2489, 0);
            heff_take_n(v_x11_2489, 1ULL, 1);
            heff_drop_rec(v_o_2474, 9);
            heff_drop_rec(v_c_2479, 9);
            heff_drop(v_x_2485);
            heff_drop_cell(v_ru_24x1_2488_24MkPair, 2);
            return heff_tag_at_n(v_ru_24x1_2481_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2491}), v_st_2490});
          }
          case TAG_Right: {
            V v_x_2492 = heff_field(v_x11_2489, 0);
            heff_take_n(v_x11_2489, 1ULL, 1);
            V v_t_2493 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_o_2474, 3, 9), heff_get_n(v_c_2479, 4, 9)});
            V v_t_2494 = heff_tag_at_n(v_ru_24x1_2488_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_EUpdate, 2, (V[]){v_x_2485, v_x_2492}), v_t_2493});
            return heff_tag_at_n(v_ru_24x1_2481_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2494}), v_st_2490});
          }
          default: return heff_nomatch(v_x11_2489);
          }
        }
        default: return heff_nomatch(v_x1_2488);
        }
      }
      default: return heff_nomatch(v_x11_2482);
      }
    }
    default: return heff_nomatch(v_x1_2481);
    }
  }
  case TAG_EUSet: {
    heff_drop_rec(v_r_240, 3);
    V v_t_2498 = (g_heff_2esyntax_2ecst_2efirstE(v_e0_241));
    V v_t_2499 = ({ V a_0 = v_e0_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e0_241, 3); r_; });
    V v_t_24100 = heff_strAppend(heff_get_n(v_t_2499, 1, 9), ((V)&g_heff_2esyntax_2esurface_2eexprL_str11));
    V v_msg_24101 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eexprL_str12), v_t_24100);
    V v_t_24102 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_2498, 3), heff_get_n(v_t_2498, 4, 9)});
    V v_t_24103 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24101, v_t_24102, NTAG(TAG_Nothing)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24103}), v_z_242});
  }
  case TAG_InstB: {
    V v_o_24104 = heff_field(v_e0_241, 0);
    V v_d_24106 = heff_field(v_e0_241, 2);
    V v_c_24108 = heff_field(v_e0_241, 4);
    heff_take_n(v_e0_241, 21ULL, 5);
    V v_m_24109 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_d_24106));
    V v_x1_24110 = heff_tr(heff_call(v_m_24109, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x1_24110)) {
    case TAG_MkPair: {
      V v_x11_24111 = heff_field(v_x1_24110, 0);
      V v_st_24112 = heff_field(v_x1_24110, 1);
      V v_ru_24x1_24110_24MkPair = heff_take_reuse_n(v_x1_24110, 3ULL, 2);
      switch (heff_tag_of(v_x11_24111)) {
      case TAG_Left: {
        V v_e_24113 = heff_field(v_x11_24111, 0);
        heff_take_n(v_x11_24111, 1ULL, 1);
        heff_drop_rec(v_o_24104, 9);
        heff_drop_rec(v_c_24108, 9);
        return heff_tag_at_n(v_ru_24x1_24110_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24113}), v_st_24112});
      }
      case TAG_Right: {
        V v_ru_24x11_24111_24Right = heff_take_reuse_n(v_x11_24111, 0ULL, 1);
        V v_t_24115 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_o_24104, 3, 9), heff_get_n(v_c_24108, 4, 9)});
        V v_t_24116 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24111_24Right, TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2eexprL_str13)}), v_t_24115});
        return heff_tag_at_n(v_ru_24x1_24110_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24116}), v_st_24112});
      }
      default: return heff_nomatch(v_x11_24111);
      }
    }
    default: return heff_nomatch(v_x1_24110);
    }
  }
  case TAG_EFSet: {
    heff_drop_rec(v_r_240, 3);
    V v_t_24120 = (g_heff_2esyntax_2ecst_2efirstE(v_e0_241));
    V v_t_24121 = ({ V a_0 = v_e0_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e0_241, 3); r_; });
    V v_t_24122 = heff_strAppend(heff_get_n(v_t_24121, 1, 9), ((V)&g_heff_2esyntax_2esurface_2eexprL_str14));
    V v_msg_24123 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eexprL_str15), v_t_24122);
    V v_t_24124 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24120, 3), heff_get_n(v_t_24120, 4, 9)});
    V v_t_24125 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24123, v_t_24124, NTAG(TAG_Nothing)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24125}), v_z_242});
  }
  case TAG_EFDefault: {
    heff_drop_rec(v_r_240, 3);
    V v_t_24129 = (g_heff_2esyntax_2ecst_2efirstE(v_e0_241));
    V v_t_24130 = ({ V a_0 = v_e0_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e0_241, 3); r_; });
    V v_t_24131 = heff_strAppend(heff_get_n(v_t_24130, 1, 9), ((V)&g_heff_2esyntax_2esurface_2eexprL_str16));
    V v_msg_24132 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eexprL_str17), v_t_24131);
    V v_t_24133 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24129, 3), heff_get_n(v_t_24129, 4, 9)});
    V v_t_24134 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24132, v_t_24133, NTAG(TAG_Nothing)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24134}), v_z_242});
  }
  case TAG_Sum: {
    V v_kw_24135 = heff_field(v_e0_241, 0);
    V v_alts_24137 = heff_field(v_e0_241, 2);
    V v_c_24139 = heff_field(v_e0_241, 4);
    heff_take_n(v_e0_241, 21ULL, 5);
    V v_m_24141 = (g_prelude_2etraverse_24s499544530x2060473942(heff_clo_n(g_heff_2esyntax_2esurface_2eexprL_lam3, 1, 1, (V[]){v_r_240}), v_alts_24137));
    V v_x1_24142 = heff_tr(heff_call(v_m_24141, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x1_24142)) {
    case TAG_MkPair: {
      V v_x11_24143 = heff_field(v_x1_24142, 0);
      V v_st_24144 = heff_field(v_x1_24142, 1);
      V v_ru_24x1_24142_24MkPair = heff_take_reuse_n(v_x1_24142, 3ULL, 2);
      switch (heff_tag_of(v_x11_24143)) {
      case TAG_Left: {
        V v_e_24145 = heff_field(v_x11_24143, 0);
        heff_take_n(v_x11_24143, 1ULL, 1);
        heff_drop_rec(v_kw_24135, 9);
        heff_drop_rec(v_c_24139, 9);
        return heff_tag_at_n(v_ru_24x1_24142_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24145}), v_st_24144});
      }
      case TAG_Right: {
        V v_x_24146 = heff_field(v_x11_24143, 0);
        V v_ru_24x11_24143_24Right = heff_take_reuse_n(v_x11_24143, 1ULL, 1);
        V v_t_24147 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_24135, 3, 9), heff_get_n(v_c_24139, 4, 9)});
        V v_t_24148 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24143_24Right, TAG_ESum, 1, (V[]){v_x_24146}), v_t_24147});
        return heff_tag_at_n(v_ru_24x1_24142_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24148}), v_st_24144});
      }
      default: return heff_nomatch(v_x11_24143);
      }
    }
    default: return heff_nomatch(v_x1_24142);
    }
  }
  case TAG_ECon: {
    V v_c_24149 = heff_field(v_e0_241, 0);
    V v_args_24150 = heff_field(v_e0_241, 1);
    heff_take_n(v_e0_241, 3ULL, 2);
    V v_t_24151 = (g_heff_2esyntax_2esurface_2econL(v_r_240, v_c_24149, v_args_24150));
    return heff_tail(v_t_24151, 1, (V[]){v_z_242});
  }
  case TAG_EField: {
    V v_e_24152 = heff_field(v_e0_241, 0);
    V v_f_24153 = heff_field(v_e0_241, 1);
    V v_ru_24e0_241_24EField = heff_take_reuse_n(v_e0_241, 3ULL, 2);
    HeffT2 v_t_24154 = (g_heff_2esyntax_2esurface_2efieldsOf_24cpr(heff_tag_at_n(v_ru_24e0_241_24EField, TAG_EField, 2, (V[]){v_e_24152, v_f_24153}), NTAG(TAG_Nil)));
    {
      V v_field_24155 = v_t_24154.f[0];
      V v_field_24156 = v_t_24154.f[1];
      V v_it1_24157 = v_field_24155;
      V v_fs_24158 = v_field_24156;
      switch (heff_tag_of(v_it1_24157)) {
      case TAG_Atom: {
        V v_t_24159 = heff_field(v_it1_24157, 0);
        V v_ru_24it1_24157_24Atom = heff_take_reuse_n(v_it1_24157, 1ULL, 1);
        heff_drop_rec(v_r_240, 3);
        if (heff_strEq_c(heff_dup(heff_rfield(v_t_24159, 0)), ((V)&g_heff_2esyntax_2esurface_2eexprL_str18))) {
          heff_drop_cell(v_ru_24it1_24157_24Atom, 1);
          HEFF_LAST return g_heff_2esyntax_2esurface_2econAtom(v_t_24159, v_fs_24158, v_z_242);
        } else {
          if (heff_strEq_c(heff_dup(heff_rfield(v_t_24159, 0)), ((V)&g_heff_2esyntax_2esurface_2eexprL_str19))) {
            heff_drop_cell(v_ru_24it1_24157_24Atom, 1);
            HEFF_LAST return g_heff_2esyntax_2esurface_2ekwAtom(v_t_24159, v_fs_24158, v_z_242);
          } else {
            V v_e_24162 = (g_heff_2esyntax_2esurface_2eatomTok(v_t_24159));
            V v_t_24163 = (g_list_2emap_24s513201124x806973253(v_fs_24158));
            V v_x_24164 = (g_heff_2esyntax_2epresyntax_2eapp(v_e_24162, v_t_24163));
            return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24it1_24157_24Atom, TAG_Right, 1, (V[]){v_x_24164}), v_z_242});
          }
        }
      }
      case TAG_EParen: {
        V v_m_24168 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24157}));
        V v_x1_24169 = heff_tr(heff_call(v_m_24168, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24169)) {
        case TAG_MkPair: {
          V v_x11_24170 = heff_field(v_x1_24169, 0);
          V v_st_24171 = heff_field(v_x1_24169, 1);
          V v_ru_24x1_24169_24MkPair = heff_take_reuse_n(v_x1_24169, 3ULL, 2);
          switch (heff_tag_of(v_x11_24170)) {
          case TAG_Left: {
            V v_e_24172 = heff_field(v_x11_24170, 0);
            heff_take_n(v_x11_24170, 1ULL, 1);
            heff_drop(v_fs_24158);
            return heff_tag_at_n(v_ru_24x1_24169_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24172}), v_st_24171});
          }
          case TAG_Right: {
            V v_x_24173 = heff_field(v_x11_24170, 0);
            heff_take_n(v_x11_24170, 1ULL, 1);
            V v_t_24174 = (g_list_2emap_24s513201124x806973253(v_fs_24158));
            V v_x_24175 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24173, v_t_24174));
            return heff_tag_at_n(v_ru_24x1_24169_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24175}), v_st_24171});
          }
          default: return heff_nomatch(v_x11_24170);
          }
        }
        default: return heff_nomatch(v_x1_24169);
        }
      }
      case TAG_Named: {
        V v_m_24181 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24157}));
        V v_x1_24182 = heff_tr(heff_call(v_m_24181, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24182)) {
        case TAG_MkPair: {
          V v_x11_24183 = heff_field(v_x1_24182, 0);
          V v_st_24184 = heff_field(v_x1_24182, 1);
          V v_ru_24x1_24182_24MkPair = heff_take_reuse_n(v_x1_24182, 3ULL, 2);
          switch (heff_tag_of(v_x11_24183)) {
          case TAG_Left: {
            V v_e_24185 = heff_field(v_x11_24183, 0);
            heff_take_n(v_x11_24183, 1ULL, 1);
            heff_drop(v_fs_24158);
            return heff_tag_at_n(v_ru_24x1_24182_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24185}), v_st_24184});
          }
          case TAG_Right: {
            V v_x_24186 = heff_field(v_x11_24183, 0);
            heff_take_n(v_x11_24183, 1ULL, 1);
            V v_t_24187 = (g_list_2emap_24s513201124x806973253(v_fs_24158));
            V v_x_24188 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24186, v_t_24187));
            return heff_tag_at_n(v_ru_24x1_24182_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24188}), v_st_24184});
          }
          default: return heff_nomatch(v_x11_24183);
          }
        }
        default: return heff_nomatch(v_x1_24182);
        }
      }
      case TAG_Tup: {
        V v_m_24193 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24157}));
        V v_x1_24194 = heff_tr(heff_call(v_m_24193, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24194)) {
        case TAG_MkPair: {
          V v_x11_24195 = heff_field(v_x1_24194, 0);
          V v_st_24196 = heff_field(v_x1_24194, 1);
          V v_ru_24x1_24194_24MkPair = heff_take_reuse_n(v_x1_24194, 3ULL, 2);
          switch (heff_tag_of(v_x11_24195)) {
          case TAG_Left: {
            V v_e_24197 = heff_field(v_x11_24195, 0);
            heff_take_n(v_x11_24195, 1ULL, 1);
            heff_drop(v_fs_24158);
            return heff_tag_at_n(v_ru_24x1_24194_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24197}), v_st_24196});
          }
          case TAG_Right: {
            V v_x_24198 = heff_field(v_x11_24195, 0);
            heff_take_n(v_x11_24195, 1ULL, 1);
            V v_t_24199 = (g_list_2emap_24s513201124x806973253(v_fs_24158));
            V v_x_24200 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24198, v_t_24199));
            return heff_tag_at_n(v_ru_24x1_24194_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24200}), v_st_24196});
          }
          default: return heff_nomatch(v_x11_24195);
          }
        }
        default: return heff_nomatch(v_x1_24194);
        }
      }
      case TAG_Seg: {
        V v_m_24204 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24157}));
        V v_x1_24205 = heff_tr(heff_call(v_m_24204, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24205)) {
        case TAG_MkPair: {
          V v_x11_24206 = heff_field(v_x1_24205, 0);
          V v_st_24207 = heff_field(v_x1_24205, 1);
          V v_ru_24x1_24205_24MkPair = heff_take_reuse_n(v_x1_24205, 3ULL, 2);
          switch (heff_tag_of(v_x11_24206)) {
          case TAG_Left: {
            V v_e_24208 = heff_field(v_x11_24206, 0);
            heff_take_n(v_x11_24206, 1ULL, 1);
            heff_drop(v_fs_24158);
            return heff_tag_at_n(v_ru_24x1_24205_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24208}), v_st_24207});
          }
          case TAG_Right: {
            V v_x_24209 = heff_field(v_x11_24206, 0);
            heff_take_n(v_x11_24206, 1ULL, 1);
            V v_t_24210 = (g_list_2emap_24s513201124x806973253(v_fs_24158));
            V v_x_24211 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24209, v_t_24210));
            return heff_tag_at_n(v_ru_24x1_24205_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24211}), v_st_24207});
          }
          default: return heff_nomatch(v_x11_24206);
          }
        }
        default: return heff_nomatch(v_x1_24205);
        }
      }
      case TAG_Braces: {
        V v_m_24216 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24157}));
        V v_x1_24217 = heff_tr(heff_call(v_m_24216, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24217)) {
        case TAG_MkPair: {
          V v_x11_24218 = heff_field(v_x1_24217, 0);
          V v_st_24219 = heff_field(v_x1_24217, 1);
          V v_ru_24x1_24217_24MkPair = heff_take_reuse_n(v_x1_24217, 3ULL, 2);
          switch (heff_tag_of(v_x11_24218)) {
          case TAG_Left: {
            V v_e_24220 = heff_field(v_x11_24218, 0);
            heff_take_n(v_x11_24218, 1ULL, 1);
            heff_drop(v_fs_24158);
            return heff_tag_at_n(v_ru_24x1_24217_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24220}), v_st_24219});
          }
          case TAG_Right: {
            V v_x_24221 = heff_field(v_x11_24218, 0);
            heff_take_n(v_x11_24218, 1ULL, 1);
            V v_t_24222 = (g_list_2emap_24s513201124x806973253(v_fs_24158));
            V v_x_24223 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24221, v_t_24222));
            return heff_tag_at_n(v_ru_24x1_24217_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24223}), v_st_24219});
          }
          default: return heff_nomatch(v_x11_24218);
          }
        }
        default: return heff_nomatch(v_x1_24217);
        }
      }
      case TAG_Update: {
        V v_m_24230 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24157}));
        V v_x1_24231 = heff_tr(heff_call(v_m_24230, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24231)) {
        case TAG_MkPair: {
          V v_x11_24232 = heff_field(v_x1_24231, 0);
          V v_st_24233 = heff_field(v_x1_24231, 1);
          V v_ru_24x1_24231_24MkPair = heff_take_reuse_n(v_x1_24231, 3ULL, 2);
          switch (heff_tag_of(v_x11_24232)) {
          case TAG_Left: {
            V v_e_24234 = heff_field(v_x11_24232, 0);
            heff_take_n(v_x11_24232, 1ULL, 1);
            heff_drop(v_fs_24158);
            return heff_tag_at_n(v_ru_24x1_24231_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24234}), v_st_24233});
          }
          case TAG_Right: {
            V v_x_24235 = heff_field(v_x11_24232, 0);
            heff_take_n(v_x11_24232, 1ULL, 1);
            V v_t_24236 = (g_list_2emap_24s513201124x806973253(v_fs_24158));
            V v_x_24237 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24235, v_t_24236));
            return heff_tag_at_n(v_ru_24x1_24231_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24237}), v_st_24233});
          }
          default: return heff_nomatch(v_x11_24232);
          }
        }
        default: return heff_nomatch(v_x1_24231);
        }
      }
      case TAG_EUSet: {
        V v_m_24241 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24157}));
        V v_x1_24242 = heff_tr(heff_call(v_m_24241, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24242)) {
        case TAG_MkPair: {
          V v_x11_24243 = heff_field(v_x1_24242, 0);
          V v_st_24244 = heff_field(v_x1_24242, 1);
          V v_ru_24x1_24242_24MkPair = heff_take_reuse_n(v_x1_24242, 3ULL, 2);
          switch (heff_tag_of(v_x11_24243)) {
          case TAG_Left: {
            V v_e_24245 = heff_field(v_x11_24243, 0);
            heff_take_n(v_x11_24243, 1ULL, 1);
            heff_drop(v_fs_24158);
            return heff_tag_at_n(v_ru_24x1_24242_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24245}), v_st_24244});
          }
          case TAG_Right: {
            V v_x_24246 = heff_field(v_x11_24243, 0);
            heff_take_n(v_x11_24243, 1ULL, 1);
            V v_t_24247 = (g_list_2emap_24s513201124x806973253(v_fs_24158));
            V v_x_24248 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24246, v_t_24247));
            return heff_tag_at_n(v_ru_24x1_24242_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24248}), v_st_24244});
          }
          default: return heff_nomatch(v_x11_24243);
          }
        }
        default: return heff_nomatch(v_x1_24242);
        }
      }
      case TAG_InstB: {
        V v_m_24254 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24157}));
        V v_x1_24255 = heff_tr(heff_call(v_m_24254, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24255)) {
        case TAG_MkPair: {
          V v_x11_24256 = heff_field(v_x1_24255, 0);
          V v_st_24257 = heff_field(v_x1_24255, 1);
          V v_ru_24x1_24255_24MkPair = heff_take_reuse_n(v_x1_24255, 3ULL, 2);
          switch (heff_tag_of(v_x11_24256)) {
          case TAG_Left: {
            V v_e_24258 = heff_field(v_x11_24256, 0);
            heff_take_n(v_x11_24256, 1ULL, 1);
            heff_drop(v_fs_24158);
            return heff_tag_at_n(v_ru_24x1_24255_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24258}), v_st_24257});
          }
          case TAG_Right: {
            V v_x_24259 = heff_field(v_x11_24256, 0);
            heff_take_n(v_x11_24256, 1ULL, 1);
            V v_t_24260 = (g_list_2emap_24s513201124x806973253(v_fs_24158));
            V v_x_24261 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24259, v_t_24260));
            return heff_tag_at_n(v_ru_24x1_24255_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24261}), v_st_24257});
          }
          default: return heff_nomatch(v_x11_24256);
          }
        }
        default: return heff_nomatch(v_x1_24255);
        }
      }
      case TAG_EFSet: {
        V v_m_24265 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24157}));
        V v_x1_24266 = heff_tr(heff_call(v_m_24265, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24266)) {
        case TAG_MkPair: {
          V v_x11_24267 = heff_field(v_x1_24266, 0);
          V v_st_24268 = heff_field(v_x1_24266, 1);
          V v_ru_24x1_24266_24MkPair = heff_take_reuse_n(v_x1_24266, 3ULL, 2);
          switch (heff_tag_of(v_x11_24267)) {
          case TAG_Left: {
            V v_e_24269 = heff_field(v_x11_24267, 0);
            heff_take_n(v_x11_24267, 1ULL, 1);
            heff_drop(v_fs_24158);
            return heff_tag_at_n(v_ru_24x1_24266_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24269}), v_st_24268});
          }
          case TAG_Right: {
            V v_x_24270 = heff_field(v_x11_24267, 0);
            heff_take_n(v_x11_24267, 1ULL, 1);
            V v_t_24271 = (g_list_2emap_24s513201124x806973253(v_fs_24158));
            V v_x_24272 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24270, v_t_24271));
            return heff_tag_at_n(v_ru_24x1_24266_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24272}), v_st_24268});
          }
          default: return heff_nomatch(v_x11_24267);
          }
        }
        default: return heff_nomatch(v_x1_24266);
        }
      }
      case TAG_EFDefault: {
        V v_m_24276 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24157}));
        V v_x1_24277 = heff_tr(heff_call(v_m_24276, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24277)) {
        case TAG_MkPair: {
          V v_x11_24278 = heff_field(v_x1_24277, 0);
          V v_st_24279 = heff_field(v_x1_24277, 1);
          V v_ru_24x1_24277_24MkPair = heff_take_reuse_n(v_x1_24277, 3ULL, 2);
          switch (heff_tag_of(v_x11_24278)) {
          case TAG_Left: {
            V v_e_24280 = heff_field(v_x11_24278, 0);
            heff_take_n(v_x11_24278, 1ULL, 1);
            heff_drop(v_fs_24158);
            return heff_tag_at_n(v_ru_24x1_24277_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24280}), v_st_24279});
          }
          case TAG_Right: {
            V v_x_24281 = heff_field(v_x11_24278, 0);
            heff_take_n(v_x11_24278, 1ULL, 1);
            V v_t_24282 = (g_list_2emap_24s513201124x806973253(v_fs_24158));
            V v_x_24283 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24281, v_t_24282));
            return heff_tag_at_n(v_ru_24x1_24277_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24283}), v_st_24279});
          }
          default: return heff_nomatch(v_x11_24278);
          }
        }
        default: return heff_nomatch(v_x1_24277);
        }
      }
      case TAG_Sum: {
        V v_m_24289 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24157}));
        V v_x1_24290 = heff_tr(heff_call(v_m_24289, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24290)) {
        case TAG_MkPair: {
          V v_x11_24291 = heff_field(v_x1_24290, 0);
          V v_st_24292 = heff_field(v_x1_24290, 1);
          V v_ru_24x1_24290_24MkPair = heff_take_reuse_n(v_x1_24290, 3ULL, 2);
          switch (heff_tag_of(v_x11_24291)) {
          case TAG_Left: {
            V v_e_24293 = heff_field(v_x11_24291, 0);
            heff_take_n(v_x11_24291, 1ULL, 1);
            heff_drop(v_fs_24158);
            return heff_tag_at_n(v_ru_24x1_24290_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24293}), v_st_24292});
          }
          case TAG_Right: {
            V v_x_24294 = heff_field(v_x11_24291, 0);
            heff_take_n(v_x11_24291, 1ULL, 1);
            V v_t_24295 = (g_list_2emap_24s513201124x806973253(v_fs_24158));
            V v_x_24296 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24294, v_t_24295));
            return heff_tag_at_n(v_ru_24x1_24290_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24296}), v_st_24292});
          }
          default: return heff_nomatch(v_x11_24291);
          }
        }
        default: return heff_nomatch(v_x1_24290);
        }
      }
      case TAG_ECon: {
        V v_m_24299 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24157}));
        V v_x1_24300 = heff_tr(heff_call(v_m_24299, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24300)) {
        case TAG_MkPair: {
          V v_x11_24301 = heff_field(v_x1_24300, 0);
          V v_st_24302 = heff_field(v_x1_24300, 1);
          V v_ru_24x1_24300_24MkPair = heff_take_reuse_n(v_x1_24300, 3ULL, 2);
          switch (heff_tag_of(v_x11_24301)) {
          case TAG_Left: {
            V v_e_24303 = heff_field(v_x11_24301, 0);
            heff_take_n(v_x11_24301, 1ULL, 1);
            heff_drop(v_fs_24158);
            return heff_tag_at_n(v_ru_24x1_24300_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24303}), v_st_24302});
          }
          case TAG_Right: {
            V v_x_24304 = heff_field(v_x11_24301, 0);
            heff_take_n(v_x11_24301, 1ULL, 1);
            V v_t_24305 = (g_list_2emap_24s513201124x806973253(v_fs_24158));
            V v_x_24306 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24304, v_t_24305));
            return heff_tag_at_n(v_ru_24x1_24300_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24306}), v_st_24302});
          }
          default: return heff_nomatch(v_x11_24301);
          }
        }
        default: return heff_nomatch(v_x1_24300);
        }
      }
      case TAG_EField: {
        V v_m_24309 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24157}));
        V v_x1_24310 = heff_tr(heff_call(v_m_24309, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24310)) {
        case TAG_MkPair: {
          V v_x11_24311 = heff_field(v_x1_24310, 0);
          V v_st_24312 = heff_field(v_x1_24310, 1);
          V v_ru_24x1_24310_24MkPair = heff_take_reuse_n(v_x1_24310, 3ULL, 2);
          switch (heff_tag_of(v_x11_24311)) {
          case TAG_Left: {
            V v_e_24313 = heff_field(v_x11_24311, 0);
            heff_take_n(v_x11_24311, 1ULL, 1);
            heff_drop(v_fs_24158);
            return heff_tag_at_n(v_ru_24x1_24310_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24313}), v_st_24312});
          }
          case TAG_Right: {
            V v_x_24314 = heff_field(v_x11_24311, 0);
            heff_take_n(v_x11_24311, 1ULL, 1);
            V v_t_24315 = (g_list_2emap_24s513201124x806973253(v_fs_24158));
            V v_x_24316 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24314, v_t_24315));
            return heff_tag_at_n(v_ru_24x1_24310_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24316}), v_st_24312});
          }
          default: return heff_nomatch(v_x11_24311);
          }
        }
        default: return heff_nomatch(v_x1_24310);
        }
      }
      case TAG_ENeg: {
        V v_m_24319 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24157}));
        V v_x1_24320 = heff_tr(heff_call(v_m_24319, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24320)) {
        case TAG_MkPair: {
          V v_x11_24321 = heff_field(v_x1_24320, 0);
          V v_st_24322 = heff_field(v_x1_24320, 1);
          V v_ru_24x1_24320_24MkPair = heff_take_reuse_n(v_x1_24320, 3ULL, 2);
          switch (heff_tag_of(v_x11_24321)) {
          case TAG_Left: {
            V v_e_24323 = heff_field(v_x11_24321, 0);
            heff_take_n(v_x11_24321, 1ULL, 1);
            heff_drop(v_fs_24158);
            return heff_tag_at_n(v_ru_24x1_24320_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24323}), v_st_24322});
          }
          case TAG_Right: {
            V v_x_24324 = heff_field(v_x11_24321, 0);
            heff_take_n(v_x11_24321, 1ULL, 1);
            V v_t_24325 = (g_list_2emap_24s513201124x806973253(v_fs_24158));
            V v_x_24326 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24324, v_t_24325));
            return heff_tag_at_n(v_ru_24x1_24320_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24326}), v_st_24322});
          }
          default: return heff_nomatch(v_x11_24321);
          }
        }
        default: return heff_nomatch(v_x1_24320);
        }
      }
      case TAG_App: {
        V v_m_24329 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24157}));
        V v_x1_24330 = heff_tr(heff_call(v_m_24329, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24330)) {
        case TAG_MkPair: {
          V v_x11_24331 = heff_field(v_x1_24330, 0);
          V v_st_24332 = heff_field(v_x1_24330, 1);
          V v_ru_24x1_24330_24MkPair = heff_take_reuse_n(v_x1_24330, 3ULL, 2);
          switch (heff_tag_of(v_x11_24331)) {
          case TAG_Left: {
            V v_e_24333 = heff_field(v_x11_24331, 0);
            heff_take_n(v_x11_24331, 1ULL, 1);
            heff_drop(v_fs_24158);
            return heff_tag_at_n(v_ru_24x1_24330_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24333}), v_st_24332});
          }
          case TAG_Right: {
            V v_x_24334 = heff_field(v_x11_24331, 0);
            heff_take_n(v_x11_24331, 1ULL, 1);
            V v_t_24335 = (g_list_2emap_24s513201124x806973253(v_fs_24158));
            V v_x_24336 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24334, v_t_24335));
            return heff_tag_at_n(v_ru_24x1_24330_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24336}), v_st_24332});
          }
          default: return heff_nomatch(v_x11_24331);
          }
        }
        default: return heff_nomatch(v_x1_24330);
        }
      }
      case TAG_Op: {
        V v_m_24340 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24157}));
        V v_x1_24341 = heff_tr(heff_call(v_m_24340, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24341)) {
        case TAG_MkPair: {
          V v_x11_24342 = heff_field(v_x1_24341, 0);
          V v_st_24343 = heff_field(v_x1_24341, 1);
          V v_ru_24x1_24341_24MkPair = heff_take_reuse_n(v_x1_24341, 3ULL, 2);
          switch (heff_tag_of(v_x11_24342)) {
          case TAG_Left: {
            V v_e_24344 = heff_field(v_x11_24342, 0);
            heff_take_n(v_x11_24342, 1ULL, 1);
            heff_drop(v_fs_24158);
            return heff_tag_at_n(v_ru_24x1_24341_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24344}), v_st_24343});
          }
          case TAG_Right: {
            V v_x_24345 = heff_field(v_x11_24342, 0);
            heff_take_n(v_x11_24342, 1ULL, 1);
            V v_t_24346 = (g_list_2emap_24s513201124x806973253(v_fs_24158));
            V v_x_24347 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24345, v_t_24346));
            return heff_tag_at_n(v_ru_24x1_24341_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24347}), v_st_24343});
          }
          default: return heff_nomatch(v_x11_24342);
          }
        }
        default: return heff_nomatch(v_x1_24341);
        }
      }
      case TAG_Ops: {
        V v_m_24350 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24157}));
        V v_x1_24351 = heff_tr(heff_call(v_m_24350, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24351)) {
        case TAG_MkPair: {
          V v_x11_24352 = heff_field(v_x1_24351, 0);
          V v_st_24353 = heff_field(v_x1_24351, 1);
          V v_ru_24x1_24351_24MkPair = heff_take_reuse_n(v_x1_24351, 3ULL, 2);
          switch (heff_tag_of(v_x11_24352)) {
          case TAG_Left: {
            V v_e_24354 = heff_field(v_x11_24352, 0);
            heff_take_n(v_x11_24352, 1ULL, 1);
            heff_drop(v_fs_24158);
            return heff_tag_at_n(v_ru_24x1_24351_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24354}), v_st_24353});
          }
          case TAG_Right: {
            V v_x_24355 = heff_field(v_x11_24352, 0);
            heff_take_n(v_x11_24352, 1ULL, 1);
            V v_t_24356 = (g_list_2emap_24s513201124x806973253(v_fs_24158));
            V v_x_24357 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24355, v_t_24356));
            return heff_tag_at_n(v_ru_24x1_24351_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24357}), v_st_24353});
          }
          default: return heff_nomatch(v_x11_24352);
          }
        }
        default: return heff_nomatch(v_x1_24351);
        }
      }
      case TAG_OpRhs: {
        V v_m_24360 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24157}));
        V v_x1_24361 = heff_tr(heff_call(v_m_24360, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24361)) {
        case TAG_MkPair: {
          V v_x11_24362 = heff_field(v_x1_24361, 0);
          V v_st_24363 = heff_field(v_x1_24361, 1);
          V v_ru_24x1_24361_24MkPair = heff_take_reuse_n(v_x1_24361, 3ULL, 2);
          switch (heff_tag_of(v_x11_24362)) {
          case TAG_Left: {
            V v_e_24364 = heff_field(v_x11_24362, 0);
            heff_take_n(v_x11_24362, 1ULL, 1);
            heff_drop(v_fs_24158);
            return heff_tag_at_n(v_ru_24x1_24361_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24364}), v_st_24363});
          }
          case TAG_Right: {
            V v_x_24365 = heff_field(v_x11_24362, 0);
            heff_take_n(v_x11_24362, 1ULL, 1);
            V v_t_24366 = (g_list_2emap_24s513201124x806973253(v_fs_24158));
            V v_x_24367 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24365, v_t_24366));
            return heff_tag_at_n(v_ru_24x1_24361_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24367}), v_st_24363});
          }
          default: return heff_nomatch(v_x11_24362);
          }
        }
        default: return heff_nomatch(v_x1_24361);
        }
      }
      case TAG_Ann: {
        V v_m_24371 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24157}));
        V v_x1_24372 = heff_tr(heff_call(v_m_24371, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24372)) {
        case TAG_MkPair: {
          V v_x11_24373 = heff_field(v_x1_24372, 0);
          V v_st_24374 = heff_field(v_x1_24372, 1);
          V v_ru_24x1_24372_24MkPair = heff_take_reuse_n(v_x1_24372, 3ULL, 2);
          switch (heff_tag_of(v_x11_24373)) {
          case TAG_Left: {
            V v_e_24375 = heff_field(v_x11_24373, 0);
            heff_take_n(v_x11_24373, 1ULL, 1);
            heff_drop(v_fs_24158);
            return heff_tag_at_n(v_ru_24x1_24372_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24375}), v_st_24374});
          }
          case TAG_Right: {
            V v_x_24376 = heff_field(v_x11_24373, 0);
            heff_take_n(v_x11_24373, 1ULL, 1);
            V v_t_24377 = (g_list_2emap_24s513201124x806973253(v_fs_24158));
            V v_x_24378 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24376, v_t_24377));
            return heff_tag_at_n(v_ru_24x1_24372_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24378}), v_st_24374});
          }
          default: return heff_nomatch(v_x11_24373);
          }
        }
        default: return heff_nomatch(v_x1_24372);
        }
      }
      case TAG_BVar: {
        V v_m_24380 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24157}));
        V v_x1_24381 = heff_tr(heff_call(v_m_24380, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24381)) {
        case TAG_MkPair: {
          V v_x11_24382 = heff_field(v_x1_24381, 0);
          V v_st_24383 = heff_field(v_x1_24381, 1);
          V v_ru_24x1_24381_24MkPair = heff_take_reuse_n(v_x1_24381, 3ULL, 2);
          switch (heff_tag_of(v_x11_24382)) {
          case TAG_Left: {
            V v_e_24384 = heff_field(v_x11_24382, 0);
            heff_take_n(v_x11_24382, 1ULL, 1);
            heff_drop(v_fs_24158);
            return heff_tag_at_n(v_ru_24x1_24381_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24384}), v_st_24383});
          }
          case TAG_Right: {
            V v_x_24385 = heff_field(v_x11_24382, 0);
            heff_take_n(v_x11_24382, 1ULL, 1);
            V v_t_24386 = (g_list_2emap_24s513201124x806973253(v_fs_24158));
            V v_x_24387 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24385, v_t_24386));
            return heff_tag_at_n(v_ru_24x1_24381_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24387}), v_st_24383});
          }
          default: return heff_nomatch(v_x11_24382);
          }
        }
        default: return heff_nomatch(v_x1_24381);
        }
      }
      case TAG_BImp: {
        V v_m_24391 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24157}));
        V v_x1_24392 = heff_tr(heff_call(v_m_24391, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24392)) {
        case TAG_MkPair: {
          V v_x11_24393 = heff_field(v_x1_24392, 0);
          V v_st_24394 = heff_field(v_x1_24392, 1);
          V v_ru_24x1_24392_24MkPair = heff_take_reuse_n(v_x1_24392, 3ULL, 2);
          switch (heff_tag_of(v_x11_24393)) {
          case TAG_Left: {
            V v_e_24395 = heff_field(v_x11_24393, 0);
            heff_take_n(v_x11_24393, 1ULL, 1);
            heff_drop(v_fs_24158);
            return heff_tag_at_n(v_ru_24x1_24392_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24395}), v_st_24394});
          }
          case TAG_Right: {
            V v_x_24396 = heff_field(v_x11_24393, 0);
            heff_take_n(v_x11_24393, 1ULL, 1);
            V v_t_24397 = (g_list_2emap_24s513201124x806973253(v_fs_24158));
            V v_x_24398 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24396, v_t_24397));
            return heff_tag_at_n(v_ru_24x1_24392_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24398}), v_st_24394});
          }
          default: return heff_nomatch(v_x11_24393);
          }
        }
        default: return heff_nomatch(v_x1_24392);
        }
      }
      case TAG_BAnn: {
        V v_m_24404 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24157}));
        V v_x1_24405 = heff_tr(heff_call(v_m_24404, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24405)) {
        case TAG_MkPair: {
          V v_x11_24406 = heff_field(v_x1_24405, 0);
          V v_st_24407 = heff_field(v_x1_24405, 1);
          V v_ru_24x1_24405_24MkPair = heff_take_reuse_n(v_x1_24405, 3ULL, 2);
          switch (heff_tag_of(v_x11_24406)) {
          case TAG_Left: {
            V v_e_24408 = heff_field(v_x11_24406, 0);
            heff_take_n(v_x11_24406, 1ULL, 1);
            heff_drop(v_fs_24158);
            return heff_tag_at_n(v_ru_24x1_24405_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24408}), v_st_24407});
          }
          case TAG_Right: {
            V v_x_24409 = heff_field(v_x11_24406, 0);
            heff_take_n(v_x11_24406, 1ULL, 1);
            V v_t_24410 = (g_list_2emap_24s513201124x806973253(v_fs_24158));
            V v_x_24411 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24409, v_t_24410));
            return heff_tag_at_n(v_ru_24x1_24405_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24411}), v_st_24407});
          }
          default: return heff_nomatch(v_x11_24406);
          }
        }
        default: return heff_nomatch(v_x1_24405);
        }
      }
      case TAG_Lam: {
        V v_m_24416 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24157}));
        V v_x1_24417 = heff_tr(heff_call(v_m_24416, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24417)) {
        case TAG_MkPair: {
          V v_x11_24418 = heff_field(v_x1_24417, 0);
          V v_st_24419 = heff_field(v_x1_24417, 1);
          V v_ru_24x1_24417_24MkPair = heff_take_reuse_n(v_x1_24417, 3ULL, 2);
          switch (heff_tag_of(v_x11_24418)) {
          case TAG_Left: {
            V v_e_24420 = heff_field(v_x11_24418, 0);
            heff_take_n(v_x11_24418, 1ULL, 1);
            heff_drop(v_fs_24158);
            return heff_tag_at_n(v_ru_24x1_24417_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24420}), v_st_24419});
          }
          case TAG_Right: {
            V v_x_24421 = heff_field(v_x11_24418, 0);
            heff_take_n(v_x11_24418, 1ULL, 1);
            V v_t_24422 = (g_list_2emap_24s513201124x806973253(v_fs_24158));
            V v_x_24423 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24421, v_t_24422));
            return heff_tag_at_n(v_ru_24x1_24417_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24423}), v_st_24419});
          }
          default: return heff_nomatch(v_x11_24418);
          }
        }
        default: return heff_nomatch(v_x1_24417);
        }
      }
      case TAG_Case: {
        V v_m_24428 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24157}));
        V v_x1_24429 = heff_tr(heff_call(v_m_24428, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24429)) {
        case TAG_MkPair: {
          V v_x11_24430 = heff_field(v_x1_24429, 0);
          V v_st_24431 = heff_field(v_x1_24429, 1);
          V v_ru_24x1_24429_24MkPair = heff_take_reuse_n(v_x1_24429, 3ULL, 2);
          switch (heff_tag_of(v_x11_24430)) {
          case TAG_Left: {
            V v_e_24432 = heff_field(v_x11_24430, 0);
            heff_take_n(v_x11_24430, 1ULL, 1);
            heff_drop(v_fs_24158);
            return heff_tag_at_n(v_ru_24x1_24429_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24432}), v_st_24431});
          }
          case TAG_Right: {
            V v_x_24433 = heff_field(v_x11_24430, 0);
            heff_take_n(v_x11_24430, 1ULL, 1);
            V v_t_24434 = (g_list_2emap_24s513201124x806973253(v_fs_24158));
            V v_x_24435 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24433, v_t_24434));
            return heff_tag_at_n(v_ru_24x1_24429_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24435}), v_st_24431});
          }
          default: return heff_nomatch(v_x11_24430);
          }
        }
        default: return heff_nomatch(v_x1_24429);
        }
      }
      case TAG_EAlt: {
        V v_m_24439 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24157}));
        V v_x1_24440 = heff_tr(heff_call(v_m_24439, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24440)) {
        case TAG_MkPair: {
          V v_x11_24441 = heff_field(v_x1_24440, 0);
          V v_st_24442 = heff_field(v_x1_24440, 1);
          V v_ru_24x1_24440_24MkPair = heff_take_reuse_n(v_x1_24440, 3ULL, 2);
          switch (heff_tag_of(v_x11_24441)) {
          case TAG_Left: {
            V v_e_24443 = heff_field(v_x11_24441, 0);
            heff_take_n(v_x11_24441, 1ULL, 1);
            heff_drop(v_fs_24158);
            return heff_tag_at_n(v_ru_24x1_24440_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24443}), v_st_24442});
          }
          case TAG_Right: {
            V v_x_24444 = heff_field(v_x11_24441, 0);
            heff_take_n(v_x11_24441, 1ULL, 1);
            V v_t_24445 = (g_list_2emap_24s513201124x806973253(v_fs_24158));
            V v_x_24446 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24444, v_t_24445));
            return heff_tag_at_n(v_ru_24x1_24440_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24446}), v_st_24442});
          }
          default: return heff_nomatch(v_x11_24441);
          }
        }
        default: return heff_nomatch(v_x1_24440);
        }
      }
      case TAG_If: {
        V v_m_24453 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24157}));
        V v_x1_24454 = heff_tr(heff_call(v_m_24453, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24454)) {
        case TAG_MkPair: {
          V v_x11_24455 = heff_field(v_x1_24454, 0);
          V v_st_24456 = heff_field(v_x1_24454, 1);
          V v_ru_24x1_24454_24MkPair = heff_take_reuse_n(v_x1_24454, 3ULL, 2);
          switch (heff_tag_of(v_x11_24455)) {
          case TAG_Left: {
            V v_e_24457 = heff_field(v_x11_24455, 0);
            heff_take_n(v_x11_24455, 1ULL, 1);
            heff_drop(v_fs_24158);
            return heff_tag_at_n(v_ru_24x1_24454_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24457}), v_st_24456});
          }
          case TAG_Right: {
            V v_x_24458 = heff_field(v_x11_24455, 0);
            heff_take_n(v_x11_24455, 1ULL, 1);
            V v_t_24459 = (g_list_2emap_24s513201124x806973253(v_fs_24158));
            V v_x_24460 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24458, v_t_24459));
            return heff_tag_at_n(v_ru_24x1_24454_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24460}), v_st_24456});
          }
          default: return heff_nomatch(v_x11_24455);
          }
        }
        default: return heff_nomatch(v_x1_24454);
        }
      }
      case TAG_Do: {
        V v_m_24463 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24157}));
        V v_x1_24464 = heff_tr(heff_call(v_m_24463, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24464)) {
        case TAG_MkPair: {
          V v_x11_24465 = heff_field(v_x1_24464, 0);
          V v_st_24466 = heff_field(v_x1_24464, 1);
          V v_ru_24x1_24464_24MkPair = heff_take_reuse_n(v_x1_24464, 3ULL, 2);
          switch (heff_tag_of(v_x11_24465)) {
          case TAG_Left: {
            V v_e_24467 = heff_field(v_x11_24465, 0);
            heff_take_n(v_x11_24465, 1ULL, 1);
            heff_drop(v_fs_24158);
            return heff_tag_at_n(v_ru_24x1_24464_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24467}), v_st_24466});
          }
          case TAG_Right: {
            V v_x_24468 = heff_field(v_x11_24465, 0);
            heff_take_n(v_x11_24465, 1ULL, 1);
            V v_t_24469 = (g_list_2emap_24s513201124x806973253(v_fs_24158));
            V v_x_24470 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24468, v_t_24469));
            return heff_tag_at_n(v_ru_24x1_24464_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24470}), v_st_24466});
          }
          default: return heff_nomatch(v_x11_24465);
          }
        }
        default: return heff_nomatch(v_x1_24464);
        }
      }
      case TAG_ESBind: {
        V v_m_24474 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24157}));
        V v_x1_24475 = heff_tr(heff_call(v_m_24474, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24475)) {
        case TAG_MkPair: {
          V v_x11_24476 = heff_field(v_x1_24475, 0);
          V v_st_24477 = heff_field(v_x1_24475, 1);
          V v_ru_24x1_24475_24MkPair = heff_take_reuse_n(v_x1_24475, 3ULL, 2);
          switch (heff_tag_of(v_x11_24476)) {
          case TAG_Left: {
            V v_e_24478 = heff_field(v_x11_24476, 0);
            heff_take_n(v_x11_24476, 1ULL, 1);
            heff_drop(v_fs_24158);
            return heff_tag_at_n(v_ru_24x1_24475_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24478}), v_st_24477});
          }
          case TAG_Right: {
            V v_x_24479 = heff_field(v_x11_24476, 0);
            heff_take_n(v_x11_24476, 1ULL, 1);
            V v_t_24480 = (g_list_2emap_24s513201124x806973253(v_fs_24158));
            V v_x_24481 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24479, v_t_24480));
            return heff_tag_at_n(v_ru_24x1_24475_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24481}), v_st_24477});
          }
          default: return heff_nomatch(v_x11_24476);
          }
        }
        default: return heff_nomatch(v_x1_24475);
        }
      }
      case TAG_ELet: {
        V v_m_24488 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24157}));
        V v_x1_24489 = heff_tr(heff_call(v_m_24488, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24489)) {
        case TAG_MkPair: {
          V v_x11_24490 = heff_field(v_x1_24489, 0);
          V v_st_24491 = heff_field(v_x1_24489, 1);
          V v_ru_24x1_24489_24MkPair = heff_take_reuse_n(v_x1_24489, 3ULL, 2);
          switch (heff_tag_of(v_x11_24490)) {
          case TAG_Left: {
            V v_e_24492 = heff_field(v_x11_24490, 0);
            heff_take_n(v_x11_24490, 1ULL, 1);
            heff_drop(v_fs_24158);
            return heff_tag_at_n(v_ru_24x1_24489_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24492}), v_st_24491});
          }
          case TAG_Right: {
            V v_x_24493 = heff_field(v_x11_24490, 0);
            heff_take_n(v_x11_24490, 1ULL, 1);
            V v_t_24494 = (g_list_2emap_24s513201124x806973253(v_fs_24158));
            V v_x_24495 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24493, v_t_24494));
            return heff_tag_at_n(v_ru_24x1_24489_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24495}), v_st_24491});
          }
          default: return heff_nomatch(v_x11_24490);
          }
        }
        default: return heff_nomatch(v_x1_24489);
        }
      }
      case TAG_ELetMut: {
        V v_m_24502 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24157}));
        V v_x1_24503 = heff_tr(heff_call(v_m_24502, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24503)) {
        case TAG_MkPair: {
          V v_x11_24504 = heff_field(v_x1_24503, 0);
          V v_st_24505 = heff_field(v_x1_24503, 1);
          V v_ru_24x1_24503_24MkPair = heff_take_reuse_n(v_x1_24503, 3ULL, 2);
          switch (heff_tag_of(v_x11_24504)) {
          case TAG_Left: {
            V v_e_24506 = heff_field(v_x11_24504, 0);
            heff_take_n(v_x11_24504, 1ULL, 1);
            heff_drop(v_fs_24158);
            return heff_tag_at_n(v_ru_24x1_24503_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24506}), v_st_24505});
          }
          case TAG_Right: {
            V v_x_24507 = heff_field(v_x11_24504, 0);
            heff_take_n(v_x11_24504, 1ULL, 1);
            V v_t_24508 = (g_list_2emap_24s513201124x806973253(v_fs_24158));
            V v_x_24509 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24507, v_t_24508));
            return heff_tag_at_n(v_ru_24x1_24503_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24509}), v_st_24505});
          }
          default: return heff_nomatch(v_x11_24504);
          }
        }
        default: return heff_nomatch(v_x1_24503);
        }
      }
      case TAG_EAssign: {
        V v_m_24513 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24157}));
        V v_x1_24514 = heff_tr(heff_call(v_m_24513, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24514)) {
        case TAG_MkPair: {
          V v_x11_24515 = heff_field(v_x1_24514, 0);
          V v_st_24516 = heff_field(v_x1_24514, 1);
          V v_ru_24x1_24514_24MkPair = heff_take_reuse_n(v_x1_24514, 3ULL, 2);
          switch (heff_tag_of(v_x11_24515)) {
          case TAG_Left: {
            V v_e_24517 = heff_field(v_x11_24515, 0);
            heff_take_n(v_x11_24515, 1ULL, 1);
            heff_drop(v_fs_24158);
            return heff_tag_at_n(v_ru_24x1_24514_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24517}), v_st_24516});
          }
          case TAG_Right: {
            V v_x_24518 = heff_field(v_x11_24515, 0);
            heff_take_n(v_x11_24515, 1ULL, 1);
            V v_t_24519 = (g_list_2emap_24s513201124x806973253(v_fs_24158));
            V v_x_24520 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24518, v_t_24519));
            return heff_tag_at_n(v_ru_24x1_24514_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24520}), v_st_24516});
          }
          default: return heff_nomatch(v_x11_24515);
          }
        }
        default: return heff_nomatch(v_x1_24514);
        }
      }
      case TAG_EWhile: {
        V v_m_24525 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24157}));
        V v_x1_24526 = heff_tr(heff_call(v_m_24525, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24526)) {
        case TAG_MkPair: {
          V v_x11_24527 = heff_field(v_x1_24526, 0);
          V v_st_24528 = heff_field(v_x1_24526, 1);
          V v_ru_24x1_24526_24MkPair = heff_take_reuse_n(v_x1_24526, 3ULL, 2);
          switch (heff_tag_of(v_x11_24527)) {
          case TAG_Left: {
            V v_e_24529 = heff_field(v_x11_24527, 0);
            heff_take_n(v_x11_24527, 1ULL, 1);
            heff_drop(v_fs_24158);
            return heff_tag_at_n(v_ru_24x1_24526_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24529}), v_st_24528});
          }
          case TAG_Right: {
            V v_x_24530 = heff_field(v_x11_24527, 0);
            heff_take_n(v_x11_24527, 1ULL, 1);
            V v_t_24531 = (g_list_2emap_24s513201124x806973253(v_fs_24158));
            V v_x_24532 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24530, v_t_24531));
            return heff_tag_at_n(v_ru_24x1_24526_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24532}), v_st_24528});
          }
          default: return heff_nomatch(v_x11_24527);
          }
        }
        default: return heff_nomatch(v_x1_24526);
        }
      }
      case TAG_EFor: {
        V v_m_24539 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24157}));
        V v_x1_24540 = heff_tr(heff_call(v_m_24539, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24540)) {
        case TAG_MkPair: {
          V v_x11_24541 = heff_field(v_x1_24540, 0);
          V v_st_24542 = heff_field(v_x1_24540, 1);
          V v_ru_24x1_24540_24MkPair = heff_take_reuse_n(v_x1_24540, 3ULL, 2);
          switch (heff_tag_of(v_x11_24541)) {
          case TAG_Left: {
            V v_e_24543 = heff_field(v_x11_24541, 0);
            heff_take_n(v_x11_24541, 1ULL, 1);
            heff_drop(v_fs_24158);
            return heff_tag_at_n(v_ru_24x1_24540_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24543}), v_st_24542});
          }
          case TAG_Right: {
            V v_x_24544 = heff_field(v_x11_24541, 0);
            heff_take_n(v_x11_24541, 1ULL, 1);
            V v_t_24545 = (g_list_2emap_24s513201124x806973253(v_fs_24158));
            V v_x_24546 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24544, v_t_24545));
            return heff_tag_at_n(v_ru_24x1_24540_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24546}), v_st_24542});
          }
          default: return heff_nomatch(v_x11_24541);
          }
        }
        default: return heff_nomatch(v_x1_24540);
        }
      }
      case TAG_EJump: {
        V v_m_24548 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24157}));
        V v_x1_24549 = heff_tr(heff_call(v_m_24548, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24549)) {
        case TAG_MkPair: {
          V v_x11_24550 = heff_field(v_x1_24549, 0);
          V v_st_24551 = heff_field(v_x1_24549, 1);
          V v_ru_24x1_24549_24MkPair = heff_take_reuse_n(v_x1_24549, 3ULL, 2);
          switch (heff_tag_of(v_x11_24550)) {
          case TAG_Left: {
            V v_e_24552 = heff_field(v_x11_24550, 0);
            heff_take_n(v_x11_24550, 1ULL, 1);
            heff_drop(v_fs_24158);
            return heff_tag_at_n(v_ru_24x1_24549_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24552}), v_st_24551});
          }
          case TAG_Right: {
            V v_x_24553 = heff_field(v_x11_24550, 0);
            heff_take_n(v_x11_24550, 1ULL, 1);
            V v_t_24554 = (g_list_2emap_24s513201124x806973253(v_fs_24158));
            V v_x_24555 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24553, v_t_24554));
            return heff_tag_at_n(v_ru_24x1_24549_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24555}), v_st_24551});
          }
          default: return heff_nomatch(v_x11_24550);
          }
        }
        default: return heff_nomatch(v_x1_24549);
        }
      }
      case TAG_EReturn: {
        V v_m_24558 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24157}));
        V v_x1_24559 = heff_tr(heff_call(v_m_24558, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24559)) {
        case TAG_MkPair: {
          V v_x11_24560 = heff_field(v_x1_24559, 0);
          V v_st_24561 = heff_field(v_x1_24559, 1);
          V v_ru_24x1_24559_24MkPair = heff_take_reuse_n(v_x1_24559, 3ULL, 2);
          switch (heff_tag_of(v_x11_24560)) {
          case TAG_Left: {
            V v_e_24562 = heff_field(v_x11_24560, 0);
            heff_take_n(v_x11_24560, 1ULL, 1);
            heff_drop(v_fs_24158);
            return heff_tag_at_n(v_ru_24x1_24559_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24562}), v_st_24561});
          }
          case TAG_Right: {
            V v_x_24563 = heff_field(v_x11_24560, 0);
            heff_take_n(v_x11_24560, 1ULL, 1);
            V v_t_24564 = (g_list_2emap_24s513201124x806973253(v_fs_24158));
            V v_x_24565 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24563, v_t_24564));
            return heff_tag_at_n(v_ru_24x1_24559_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24565}), v_st_24561});
          }
          default: return heff_nomatch(v_x11_24560);
          }
        }
        default: return heff_nomatch(v_x1_24559);
        }
      }
      case TAG_ENest: {
        V v_m_24570 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24157}));
        V v_x1_24571 = heff_tr(heff_call(v_m_24570, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24571)) {
        case TAG_MkPair: {
          V v_x11_24572 = heff_field(v_x1_24571, 0);
          V v_st_24573 = heff_field(v_x1_24571, 1);
          V v_ru_24x1_24571_24MkPair = heff_take_reuse_n(v_x1_24571, 3ULL, 2);
          switch (heff_tag_of(v_x11_24572)) {
          case TAG_Left: {
            V v_e_24574 = heff_field(v_x11_24572, 0);
            heff_take_n(v_x11_24572, 1ULL, 1);
            heff_drop(v_fs_24158);
            return heff_tag_at_n(v_ru_24x1_24571_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24574}), v_st_24573});
          }
          case TAG_Right: {
            V v_x_24575 = heff_field(v_x11_24572, 0);
            heff_take_n(v_x11_24572, 1ULL, 1);
            V v_t_24576 = (g_list_2emap_24s513201124x806973253(v_fs_24158));
            V v_x_24577 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24575, v_t_24576));
            return heff_tag_at_n(v_ru_24x1_24571_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24577}), v_st_24573});
          }
          default: return heff_nomatch(v_x11_24572);
          }
        }
        default: return heff_nomatch(v_x1_24571);
        }
      }
      case TAG_IfThen: {
        V v_m_24582 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24157}));
        V v_x1_24583 = heff_tr(heff_call(v_m_24582, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24583)) {
        case TAG_MkPair: {
          V v_x11_24584 = heff_field(v_x1_24583, 0);
          V v_st_24585 = heff_field(v_x1_24583, 1);
          V v_ru_24x1_24583_24MkPair = heff_take_reuse_n(v_x1_24583, 3ULL, 2);
          switch (heff_tag_of(v_x11_24584)) {
          case TAG_Left: {
            V v_e_24586 = heff_field(v_x11_24584, 0);
            heff_take_n(v_x11_24584, 1ULL, 1);
            heff_drop(v_fs_24158);
            return heff_tag_at_n(v_ru_24x1_24583_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24586}), v_st_24585});
          }
          case TAG_Right: {
            V v_x_24587 = heff_field(v_x11_24584, 0);
            heff_take_n(v_x11_24584, 1ULL, 1);
            V v_t_24588 = (g_list_2emap_24s513201124x806973253(v_fs_24158));
            V v_x_24589 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24587, v_t_24588));
            return heff_tag_at_n(v_ru_24x1_24583_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24589}), v_st_24585});
          }
          default: return heff_nomatch(v_x11_24584);
          }
        }
        default: return heff_nomatch(v_x1_24583);
        }
      }
      case TAG_ELetCond: {
        V v_m_24594 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24157}));
        V v_x1_24595 = heff_tr(heff_call(v_m_24594, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24595)) {
        case TAG_MkPair: {
          V v_x11_24596 = heff_field(v_x1_24595, 0);
          V v_st_24597 = heff_field(v_x1_24595, 1);
          V v_ru_24x1_24595_24MkPair = heff_take_reuse_n(v_x1_24595, 3ULL, 2);
          switch (heff_tag_of(v_x11_24596)) {
          case TAG_Left: {
            V v_e_24598 = heff_field(v_x11_24596, 0);
            heff_take_n(v_x11_24596, 1ULL, 1);
            heff_drop(v_fs_24158);
            return heff_tag_at_n(v_ru_24x1_24595_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24598}), v_st_24597});
          }
          case TAG_Right: {
            V v_x_24599 = heff_field(v_x11_24596, 0);
            heff_take_n(v_x11_24596, 1ULL, 1);
            V v_t_24600 = (g_list_2emap_24s513201124x806973253(v_fs_24158));
            V v_x_24601 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24599, v_t_24600));
            return heff_tag_at_n(v_ru_24x1_24595_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24601}), v_st_24597});
          }
          default: return heff_nomatch(v_x11_24596);
          }
        }
        default: return heff_nomatch(v_x1_24595);
        }
      }
      case TAG_ETry: {
        V v_m_24606 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24157}));
        V v_x1_24607 = heff_tr(heff_call(v_m_24606, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24607)) {
        case TAG_MkPair: {
          V v_x11_24608 = heff_field(v_x1_24607, 0);
          V v_st_24609 = heff_field(v_x1_24607, 1);
          V v_ru_24x1_24607_24MkPair = heff_take_reuse_n(v_x1_24607, 3ULL, 2);
          switch (heff_tag_of(v_x11_24608)) {
          case TAG_Left: {
            V v_e_24610 = heff_field(v_x11_24608, 0);
            heff_take_n(v_x11_24608, 1ULL, 1);
            heff_drop(v_fs_24158);
            return heff_tag_at_n(v_ru_24x1_24607_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24610}), v_st_24609});
          }
          case TAG_Right: {
            V v_x_24611 = heff_field(v_x11_24608, 0);
            heff_take_n(v_x11_24608, 1ULL, 1);
            V v_t_24612 = (g_list_2emap_24s513201124x806973253(v_fs_24158));
            V v_x_24613 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24611, v_t_24612));
            return heff_tag_at_n(v_ru_24x1_24607_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24613}), v_st_24609});
          }
          default: return heff_nomatch(v_x11_24608);
          }
        }
        default: return heff_nomatch(v_x1_24607);
        }
      }
      case TAG_ECatch: {
        V v_m_24618 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24157}));
        V v_x1_24619 = heff_tr(heff_call(v_m_24618, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24619)) {
        case TAG_MkPair: {
          V v_x11_24620 = heff_field(v_x1_24619, 0);
          V v_st_24621 = heff_field(v_x1_24619, 1);
          V v_ru_24x1_24619_24MkPair = heff_take_reuse_n(v_x1_24619, 3ULL, 2);
          switch (heff_tag_of(v_x11_24620)) {
          case TAG_Left: {
            V v_e_24622 = heff_field(v_x11_24620, 0);
            heff_take_n(v_x11_24620, 1ULL, 1);
            heff_drop(v_fs_24158);
            return heff_tag_at_n(v_ru_24x1_24619_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24622}), v_st_24621});
          }
          case TAG_Right: {
            V v_x_24623 = heff_field(v_x11_24620, 0);
            heff_take_n(v_x11_24620, 1ULL, 1);
            V v_t_24624 = (g_list_2emap_24s513201124x806973253(v_fs_24158));
            V v_x_24625 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24623, v_t_24624));
            return heff_tag_at_n(v_ru_24x1_24619_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24625}), v_st_24621});
          }
          default: return heff_nomatch(v_x11_24620);
          }
        }
        default: return heff_nomatch(v_x1_24619);
        }
      }
      default: return heff_nomatch(v_it1_24157);
      }
    }
  }
  case TAG_ENeg: {
    V v_m_24626 = heff_field(v_e0_241, 0);
    V v_e_24627 = heff_field(v_e0_241, 1);
    V v_ru_24e0_241_24ENeg = heff_take_reuse_n(v_e0_241, 3ULL, 2);
    V v_m_24628 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_24627}));
    V v_x1_24629 = heff_tr(heff_call(v_m_24628, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x1_24629)) {
    case TAG_MkPair: {
      V v_x11_24630 = heff_field(v_x1_24629, 0);
      V v_st_24631 = heff_field(v_x1_24629, 1);
      V v_ru_24x1_24629_24MkPair = heff_take_reuse_n(v_x1_24629, 3ULL, 2);
      switch (heff_tag_of(v_x11_24630)) {
      case TAG_Left: {
        V v_e_24632 = heff_field(v_x11_24630, 0);
        heff_take_n(v_x11_24630, 1ULL, 1);
        heff_drop_rec(v_m_24626, 9);
        heff_drop_cell(v_ru_24x1_24629_24MkPair, 2);
        return heff_tag_at_n(v_ru_24e0_241_24ENeg, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24632}), v_st_24631});
      }
      case TAG_Right: {
        V v_x_24633 = heff_field(v_x11_24630, 0);
        heff_take_n(v_x11_24630, 1ULL, 1);
        V v_t_24634 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_m_24626, 3), heff_get_n(v_m_24626, 4, 9)});
        V v_t_24635 = heff_tag_at_n(v_ru_24e0_241_24ENeg, TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2eexprL_str20)}), v_t_24634});
        V v_t_24636 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_24633, NTAG(TAG_Nil)});
        V v_x_24637 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_24635, v_t_24636));
        return heff_tag_at_n(v_ru_24x1_24629_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24637}), v_st_24631});
      }
      default: return heff_nomatch(v_x11_24630);
      }
    }
    default: return heff_nomatch(v_x1_24629);
    }
  }
  case TAG_App: {
    V v_h_24638 = heff_field(v_e0_241, 0);
    V v_args_24639 = heff_field(v_e0_241, 1);
    V v_ru_24e0_241_24App = heff_take_reuse_n(v_e0_241, 3ULL, 2);
    V v_m_24640 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_h_24638}));
    V v_x1_24641 = heff_tr(heff_call(v_m_24640, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x1_24641)) {
    case TAG_MkPair: {
      V v_x11_24642 = heff_field(v_x1_24641, 0);
      V v_st_24643 = heff_field(v_x1_24641, 1);
      heff_take_n(v_x1_24641, 3ULL, 2);
      switch (heff_tag_of(v_x11_24642)) {
      case TAG_Left: {
        V v_e_24644 = heff_field(v_x11_24642, 0);
        heff_take_n(v_x11_24642, 1ULL, 1);
        heff_drop_rec(v_r_240, 3);
        heff_drop(v_args_24639);
        return heff_tag_at_n(v_ru_24e0_241_24App, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24644}), v_st_24643});
      }
      case TAG_Right: {
        V v_x_24645 = heff_field(v_x11_24642, 0);
        heff_take_n(v_x11_24642, 1ULL, 1);
        V v_m_24647 = (g_prelude_2etraverse_24s499544530x2060473942(heff_clo_n(g_heff_2esyntax_2esurface_2eexprL_lam4, 1, 1, (V[]){v_r_240}), v_args_24639));
        V v_x1_24648 = heff_tr(heff_call(v_m_24647, 1, (V[]){v_st_24643}));
        switch (heff_tag_of(v_x1_24648)) {
        case TAG_MkPair: {
          V v_x11_24649 = heff_field(v_x1_24648, 0);
          V v_st_24650 = heff_field(v_x1_24648, 1);
          heff_take_n(v_x1_24648, 3ULL, 2);
          switch (heff_tag_of(v_x11_24649)) {
          case TAG_Left: {
            V v_e_24651 = heff_field(v_x11_24649, 0);
            heff_take_n(v_x11_24649, 1ULL, 1);
            heff_drop(v_x_24645);
            return heff_tag_at_n(v_ru_24e0_241_24App, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24651}), v_st_24650});
          }
          case TAG_Right: {
            V v_x_24652 = heff_field(v_x11_24649, 0);
            heff_take_n(v_x11_24649, 1ULL, 1);
            V v_x_24653 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24645, v_x_24652));
            return heff_tag_at_n(v_ru_24e0_241_24App, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24653}), v_st_24650});
          }
          default: return heff_nomatch(v_x11_24649);
          }
        }
        default: return heff_nomatch(v_x1_24648);
        }
      }
      default: return heff_nomatch(v_x11_24642);
      }
    }
    default: return heff_nomatch(v_x1_24641);
    }
  }
  case TAG_Op: {
    V v_a_24654 = heff_field(v_e0_241, 0);
    V v_op_24655 = heff_field(v_e0_241, 1);
    V v_b_24656 = heff_field(v_e0_241, 2);
    heff_take_n(v_e0_241, 7ULL, 3);
    return (g_heff_2esyntax_2esurface_2eopL(v_r_240, v_a_24654, v_op_24655, v_b_24656, v_z_242));
  }
  case TAG_Ops: {
    V v_a_24657 = heff_field(v_e0_241, 0);
    V v_rest_24658 = heff_field(v_e0_241, 1);
    V v_ru_24e0_241_24Ops = heff_take_reuse_n(v_e0_241, 3ULL, 2);
    V v_m_24659 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_24657}));
    V v_x1_24660 = heff_tr(heff_call(v_m_24659, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x1_24660)) {
    case TAG_MkPair: {
      V v_x11_24661 = heff_field(v_x1_24660, 0);
      V v_st_24662 = heff_field(v_x1_24660, 1);
      heff_take_n(v_x1_24660, 3ULL, 2);
      switch (heff_tag_of(v_x11_24661)) {
      case TAG_Left: {
        V v_e_24663 = heff_field(v_x11_24661, 0);
        heff_take_n(v_x11_24661, 1ULL, 1);
        heff_drop_rec(v_r_240, 3);
        heff_drop(v_rest_24658);
        return heff_tag_at_n(v_ru_24e0_241_24Ops, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24663}), v_st_24662});
      }
      case TAG_Right: {
        V v_x_24664 = heff_field(v_x11_24661, 0);
        heff_take_n(v_x11_24661, 1ULL, 1);
        V v_m_24679 = (g_prelude_2etraverse_24s499544530x2060473942(heff_clo_n(g_heff_2esyntax_2esurface_2eexprL_lam5, 1, 1, (V[]){v_r_240}), v_rest_24658));
        V v_x1_24680 = heff_tr(heff_call(v_m_24679, 1, (V[]){v_st_24662}));
        switch (heff_tag_of(v_x1_24680)) {
        case TAG_MkPair: {
          V v_x11_24681 = heff_field(v_x1_24680, 0);
          V v_st_24682 = heff_field(v_x1_24680, 1);
          heff_take_n(v_x1_24680, 3ULL, 2);
          switch (heff_tag_of(v_x11_24681)) {
          case TAG_Left: {
            V v_e_24683 = heff_field(v_x11_24681, 0);
            heff_take_n(v_x11_24681, 1ULL, 1);
            heff_drop(v_x_24664);
            return heff_tag_at_n(v_ru_24e0_241_24Ops, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24683}), v_st_24682});
          }
          case TAG_Right: {
            V v_x_24684 = heff_field(v_x11_24681, 0);
            heff_take_n(v_x11_24681, 1ULL, 1);
            heff_drop_cell(v_ru_24e0_241_24Ops, 2);
            HEFF_LAST return g_heff_2esyntax_2esurface_2eresolve_24s1832151779x1448561609(v_x_24664, v_x_24684, v_st_24682);
          }
          default: return heff_nomatch(v_x11_24681);
          }
        }
        default: return heff_nomatch(v_x1_24680);
        }
      }
      default: return heff_nomatch(v_x11_24661);
      }
    }
    default: return heff_nomatch(v_x1_24660);
    }
  }
  case TAG_OpRhs: {
    heff_drop_rec(v_r_240, 3);
    V v_t_24687 = (g_heff_2esyntax_2ecst_2efirstE(v_e0_241));
    V v_t_24688 = ({ V a_0 = v_e0_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e0_241, 2); r_; });
    V v_t_24689 = heff_strAppend(heff_get_n(v_t_24688, 1, 9), ((V)&g_heff_2esyntax_2esurface_2eexprL_str21));
    V v_msg_24690 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eexprL_str22), v_t_24689);
    V v_t_24691 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24687, 3), heff_get_n(v_t_24687, 4, 9)});
    V v_t_24692 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24690, v_t_24691, NTAG(TAG_Nothing)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24692}), v_z_242});
  }
  case TAG_Ann: {
    V v_e_24693 = heff_field(v_e0_241, 0);
    V v_ty_24695 = heff_field(v_e0_241, 2);
    heff_take_n(v_e0_241, 5ULL, 3);
    V v_m_24696 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e_24693}));
    V v_x1_24697 = heff_tr(heff_call(v_m_24696, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x1_24697)) {
    case TAG_MkPair: {
      V v_x11_24698 = heff_field(v_x1_24697, 0);
      V v_st_24699 = heff_field(v_x1_24697, 1);
      V v_ru_24x1_24697_24MkPair = heff_take_reuse_n(v_x1_24697, 3ULL, 2);
      switch (heff_tag_of(v_x11_24698)) {
      case TAG_Left: {
        V v_e_24700 = heff_field(v_x11_24698, 0);
        heff_take_n(v_x11_24698, 1ULL, 1);
        heff_drop_rec(v_r_240, 3);
        heff_drop(v_ty_24695);
        return heff_tag_at_n(v_ru_24x1_24697_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24700}), v_st_24699});
      }
      case TAG_Right: {
        V v_x_24701 = heff_field(v_x11_24698, 0);
        heff_take_n(v_x11_24698, 1ULL, 1);
        V v_m_24702 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_ty_24695}));
        V v_x1_24703 = heff_tr(heff_call(v_m_24702, 1, (V[]){v_st_24699}));
        switch (heff_tag_of(v_x1_24703)) {
        case TAG_MkPair: {
          V v_x11_24704 = heff_field(v_x1_24703, 0);
          V v_st_24705 = heff_field(v_x1_24703, 1);
          V v_ru_24x1_24703_24MkPair = heff_take_reuse_n(v_x1_24703, 3ULL, 2);
          switch (heff_tag_of(v_x11_24704)) {
          case TAG_Left: {
            V v_e_24706 = heff_field(v_x11_24704, 0);
            heff_take_n(v_x11_24704, 1ULL, 1);
            heff_drop(v_x_24701);
            heff_drop_cell(v_ru_24x1_24703_24MkPair, 2);
            return heff_tag_at_n(v_ru_24x1_24697_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24706}), v_st_24705});
          }
          case TAG_Right: {
            V v_x_24707 = heff_field(v_x11_24704, 0);
            heff_take_n(v_x11_24704, 1ULL, 1);
            V v_t_24710;
            switch (heff_tag_of(v_x_24701)) {
            case TAG_At: {
              V v_s_24709 = heff_dup(heff_field(v_x_24701, 1));
              v_t_24710 = v_s_24709;
              break;
            }
            default: heff_nomatch(v_x_24701);
            }
            V v_t_24713;
            switch (heff_tag_of(v_x_24707)) {
            case TAG_At: {
              V v_s_24712 = heff_dup(heff_field(v_x_24707, 1));
              v_t_24713 = v_s_24712;
              break;
            }
            default: heff_nomatch(v_x_24707);
            }
            V v_t_24714 = ({ V rv_1 = heff_get_n(v_t_24713, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24710, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
            V v_t_24715 = heff_tag_at_n(v_ru_24x1_24703_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_EAnn, 2, (V[]){v_x_24701, v_x_24707}), v_t_24714});
            return heff_tag_at_n(v_ru_24x1_24697_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24715}), v_st_24705});
          }
          default: return heff_nomatch(v_x11_24704);
          }
        }
        default: return heff_nomatch(v_x1_24703);
        }
      }
      default: return heff_nomatch(v_x11_24698);
      }
    }
    default: return heff_nomatch(v_x1_24697);
    }
  }
  case TAG_BVar: {
    heff_drop_rec(v_r_240, 3);
    V v_t_24717 = (g_heff_2esyntax_2ecst_2efirstE(v_e0_241));
    V v_t_24718 = ({ V a_0 = v_e0_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e0_241, 1); r_; });
    V v_t_24719 = heff_strAppend(heff_get_n(v_t_24718, 1, 9), ((V)&g_heff_2esyntax_2esurface_2eexprL_str23));
    V v_msg_24720 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eexprL_str24), v_t_24719);
    V v_t_24721 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24717, 3), heff_get_n(v_t_24717, 4, 9)});
    V v_t_24722 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24720, v_t_24721, NTAG(TAG_Nothing)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24722}), v_z_242});
  }
  case TAG_BImp: {
    heff_drop_rec(v_r_240, 3);
    V v_t_24726 = (g_heff_2esyntax_2ecst_2efirstE(v_e0_241));
    V v_t_24727 = ({ V a_0 = v_e0_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e0_241, 3); r_; });
    V v_t_24728 = heff_strAppend(heff_get_n(v_t_24727, 1, 9), ((V)&g_heff_2esyntax_2esurface_2eexprL_str25));
    V v_msg_24729 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eexprL_str26), v_t_24728);
    V v_t_24730 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24726, 3), heff_get_n(v_t_24726, 4, 9)});
    V v_t_24731 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24729, v_t_24730, NTAG(TAG_Nothing)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24731}), v_z_242});
  }
  case TAG_BAnn: {
    heff_drop_rec(v_r_240, 3);
    V v_t_24737 = (g_heff_2esyntax_2ecst_2efirstE(v_e0_241));
    V v_t_24738 = ({ V a_0 = v_e0_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e0_241, 5); r_; });
    V v_t_24739 = heff_strAppend(heff_get_n(v_t_24738, 1, 9), ((V)&g_heff_2esyntax_2esurface_2eexprL_str27));
    V v_msg_24740 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eexprL_str28), v_t_24739);
    V v_t_24741 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24737, 3), heff_get_n(v_t_24737, 4, 9)});
    V v_t_24742 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24740, v_t_24741, NTAG(TAG_Nothing)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24742}), v_z_242});
  }
  case TAG_Lam: {
    V v_binders_24744 = heff_field(v_e0_241, 1);
    V v_body_24746 = heff_field(v_e0_241, 3);
    heff_take_n(v_e0_241, 10ULL, 4);
    return (g_heff_2esyntax_2esurface_2elambdaL(v_r_240, v_binders_24744, v_body_24746, v_z_242));
  }
  case TAG_Case: {
    V v_kw_24747 = heff_dup(heff_field(v_e0_241, 0));
    V v_scrut_24748 = heff_dup(heff_field(v_e0_241, 1));
    V v_alts_24750 = heff_dup(heff_field(v_e0_241, 3));
    V v_m_24751 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_scrut_24748}));
    V v_x1_24752 = heff_tr(heff_call(v_m_24751, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x1_24752)) {
    case TAG_MkPair: {
      V v_x11_24753 = heff_field(v_x1_24752, 0);
      V v_st_24754 = heff_field(v_x1_24752, 1);
      V v_ru_24x1_24752_24MkPair = heff_take_reuse_n(v_x1_24752, 3ULL, 2);
      switch (heff_tag_of(v_x11_24753)) {
      case TAG_Left: {
        V v_e_24755 = heff_field(v_x11_24753, 0);
        heff_take_n(v_x11_24753, 1ULL, 1);
        heff_drop_rec(v_r_240, 3);
        heff_drop_tag(v_e0_241, 4);
        heff_drop_rec(v_kw_24747, 9);
        heff_drop(v_alts_24750);
        return heff_tag_at_n(v_ru_24x1_24752_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24755}), v_st_24754});
      }
      case TAG_Right: {
        V v_x_24756 = heff_field(v_x11_24753, 0);
        heff_take_n(v_x11_24753, 1ULL, 1);
        HeffT2 v_t_24758 = (g_heff_2esyntax_2esurface_2eblock_24cpr(heff_clo_n(g_heff_2esyntax_2esurface_2eexprL_lam7, 1, 1, (V[]){v_r_240}), v_alts_24750, v_st_24754));
        {
          V v_field_24759 = v_t_24758.f[0];
          V v_field_24760 = v_t_24758.f[1];
          V v_x11_24761 = v_field_24759;
          V v_st_24762 = v_field_24760;
          switch (heff_tag_of(v_x11_24761)) {
          case TAG_Left: {
            V v_e_24763 = heff_field(v_x11_24761, 0);
            heff_take_n(v_x11_24761, 1ULL, 1);
            heff_drop_tag(v_e0_241, 4);
            heff_drop_rec(v_kw_24747, 9);
            heff_drop(v_x_24756);
            return heff_tag_at_n(v_ru_24x1_24752_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24763}), v_st_24762});
          }
          case TAG_Right: {
            V v_x_24764 = heff_field(v_x11_24761, 0);
            heff_take_n(v_x11_24761, 1ULL, 1);
            V v_t_24765 = (g_heff_2esyntax_2ecst_2elastE(v_e0_241));
            V v_e_24766 = heff_get_n(v_t_24765, 4, 9);
            V v_t_24767 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_24747, 3, 9), v_e_24766});
            V v_x_24768 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_x_24756, v_x_24764}), v_t_24767});
            return heff_tag_at_n(v_ru_24x1_24752_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24768}), v_st_24762});
          }
          default: return heff_nomatch(v_x11_24761);
          }
        }
      }
      default: return heff_nomatch(v_x11_24753);
      }
    }
    default: return heff_nomatch(v_x1_24752);
    }
  }
  case TAG_EAlt: {
    heff_drop_rec(v_r_240, 3);
    V v_t_24772 = (g_heff_2esyntax_2ecst_2efirstE(v_e0_241));
    V v_t_24773 = ({ V a_0 = v_e0_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e0_241, 3); r_; });
    V v_t_24774 = heff_strAppend(heff_get_n(v_t_24773, 1, 9), ((V)&g_heff_2esyntax_2esurface_2eexprL_str29));
    V v_msg_24775 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eexprL_str30), v_t_24774);
    V v_t_24776 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24772, 3), heff_get_n(v_t_24772, 4, 9)});
    V v_t_24777 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24775, v_t_24776, NTAG(TAG_Nothing)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24777}), v_z_242});
  }
  case TAG_If: {
    V v_kw_24778 = heff_field(v_e0_241, 0);
    V v_e02_24779 = heff_field(v_e0_241, 1);
    V v_a_24781 = heff_field(v_e0_241, 3);
    V v_b_24783 = heff_field(v_e0_241, 5);
    heff_take_n(v_e0_241, 43ULL, 6);
    switch (heff_tag_of(v_e02_24779)) {
    case TAG_Atom: {
      V v_m_24785 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_24779}));
      V v_x1_24786 = heff_tr(heff_call(v_m_24785, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_24786)) {
      case TAG_MkPair: {
        V v_x11_24787 = heff_field(v_x1_24786, 0);
        V v_st_24788 = heff_field(v_x1_24786, 1);
        V v_ru_24x1_24786_24MkPair = heff_take_reuse_n(v_x1_24786, 3ULL, 2);
        switch (heff_tag_of(v_x11_24787)) {
        case TAG_Left: {
          V v_e_24789 = heff_field(v_x11_24787, 0);
          heff_take_n(v_x11_24787, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_24778, 9);
          heff_drop(v_a_24781);
          heff_drop(v_b_24783);
          return heff_tag_at_n(v_ru_24x1_24786_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24789}), v_st_24788});
        }
        case TAG_Right: {
          V v_x_24790 = heff_field(v_x11_24787, 0);
          heff_take_n(v_x11_24787, 1ULL, 1);
          V v_m_24791 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_24781}));
          V v_x1_24792 = heff_tr(heff_call(v_m_24791, 1, (V[]){v_st_24788}));
          switch (heff_tag_of(v_x1_24792)) {
          case TAG_MkPair: {
            V v_x11_24793 = heff_field(v_x1_24792, 0);
            V v_st_24794 = heff_field(v_x1_24792, 1);
            heff_take_n(v_x1_24792, 3ULL, 2);
            switch (heff_tag_of(v_x11_24793)) {
            case TAG_Left: {
              V v_e_24795 = heff_field(v_x11_24793, 0);
              heff_take_n(v_x11_24793, 1ULL, 1);
              heff_drop_rec(v_r_240, 3);
              heff_drop_rec(v_kw_24778, 9);
              heff_drop(v_b_24783);
              heff_drop(v_x_24790);
              return heff_tag_at_n(v_ru_24x1_24786_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24795}), v_st_24794});
            }
            case TAG_Right: {
              V v_x_24796 = heff_field(v_x11_24793, 0);
              heff_take_n(v_x11_24793, 1ULL, 1);
              V v_m_24797 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_b_24783)}));
              V v_x1_24798 = heff_tr(heff_call(v_m_24797, 1, (V[]){v_st_24794}));
              switch (heff_tag_of(v_x1_24798)) {
              case TAG_MkPair: {
                V v_x11_24799 = heff_field(v_x1_24798, 0);
                V v_st_24800 = heff_field(v_x1_24798, 1);
                heff_take_n(v_x1_24798, 3ULL, 2);
                switch (heff_tag_of(v_x11_24799)) {
                case TAG_Left: {
                  V v_e_24801 = heff_field(v_x11_24799, 0);
                  heff_take_n(v_x11_24799, 1ULL, 1);
                  heff_drop_rec(v_kw_24778, 9);
                  heff_drop(v_b_24783);
                  heff_drop(v_x_24790);
                  heff_drop(v_x_24796);
                  return heff_tag_at_n(v_ru_24x1_24786_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24801}), v_st_24800});
                }
                case TAG_Right: {
                  V v_x_24802 = heff_field(v_x11_24799, 0);
                  heff_take_n(v_x11_24799, 1ULL, 1);
                  V v_t_24803 = (g_heff_2esyntax_2ecst_2elastE(v_b_24783));
                  V v_e_24804 = heff_get_n(v_t_24803, 4, 9);
                  V v_t_24805 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_24778, 3, 9), v_e_24804});
                  V v_x_24806 = (g_heff_2esyntax_2esurface_2eifE(v_t_24805, v_x_24790, v_x_24796, v_x_24802));
                  return heff_tag_at_n(v_ru_24x1_24786_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24806}), v_st_24800});
                }
                default: return heff_nomatch(v_x11_24799);
                }
              }
              default: return heff_nomatch(v_x1_24798);
              }
            }
            default: return heff_nomatch(v_x11_24793);
            }
          }
          default: return heff_nomatch(v_x1_24792);
          }
        }
        default: return heff_nomatch(v_x11_24787);
        }
      }
      default: return heff_nomatch(v_x1_24786);
      }
    }
    case TAG_EParen: {
      V v_m_24810 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_24779}));
      V v_x1_24811 = heff_tr(heff_call(v_m_24810, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_24811)) {
      case TAG_MkPair: {
        V v_x11_24812 = heff_field(v_x1_24811, 0);
        V v_st_24813 = heff_field(v_x1_24811, 1);
        V v_ru_24x1_24811_24MkPair = heff_take_reuse_n(v_x1_24811, 3ULL, 2);
        switch (heff_tag_of(v_x11_24812)) {
        case TAG_Left: {
          V v_e_24814 = heff_field(v_x11_24812, 0);
          heff_take_n(v_x11_24812, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_24778, 9);
          heff_drop(v_a_24781);
          heff_drop(v_b_24783);
          return heff_tag_at_n(v_ru_24x1_24811_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24814}), v_st_24813});
        }
        case TAG_Right: {
          V v_x_24815 = heff_field(v_x11_24812, 0);
          heff_take_n(v_x11_24812, 1ULL, 1);
          V v_m_24816 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_24781}));
          V v_x1_24817 = heff_tr(heff_call(v_m_24816, 1, (V[]){v_st_24813}));
          switch (heff_tag_of(v_x1_24817)) {
          case TAG_MkPair: {
            V v_x11_24818 = heff_field(v_x1_24817, 0);
            V v_st_24819 = heff_field(v_x1_24817, 1);
            heff_take_n(v_x1_24817, 3ULL, 2);
            switch (heff_tag_of(v_x11_24818)) {
            case TAG_Left: {
              V v_e_24820 = heff_field(v_x11_24818, 0);
              heff_take_n(v_x11_24818, 1ULL, 1);
              heff_drop_rec(v_r_240, 3);
              heff_drop_rec(v_kw_24778, 9);
              heff_drop(v_b_24783);
              heff_drop(v_x_24815);
              return heff_tag_at_n(v_ru_24x1_24811_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24820}), v_st_24819});
            }
            case TAG_Right: {
              V v_x_24821 = heff_field(v_x11_24818, 0);
              heff_take_n(v_x11_24818, 1ULL, 1);
              V v_m_24822 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_b_24783)}));
              V v_x1_24823 = heff_tr(heff_call(v_m_24822, 1, (V[]){v_st_24819}));
              switch (heff_tag_of(v_x1_24823)) {
              case TAG_MkPair: {
                V v_x11_24824 = heff_field(v_x1_24823, 0);
                V v_st_24825 = heff_field(v_x1_24823, 1);
                heff_take_n(v_x1_24823, 3ULL, 2);
                switch (heff_tag_of(v_x11_24824)) {
                case TAG_Left: {
                  V v_e_24826 = heff_field(v_x11_24824, 0);
                  heff_take_n(v_x11_24824, 1ULL, 1);
                  heff_drop_rec(v_kw_24778, 9);
                  heff_drop(v_b_24783);
                  heff_drop(v_x_24815);
                  heff_drop(v_x_24821);
                  return heff_tag_at_n(v_ru_24x1_24811_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24826}), v_st_24825});
                }
                case TAG_Right: {
                  V v_x_24827 = heff_field(v_x11_24824, 0);
                  heff_take_n(v_x11_24824, 1ULL, 1);
                  V v_t_24828 = (g_heff_2esyntax_2ecst_2elastE(v_b_24783));
                  V v_e_24829 = heff_get_n(v_t_24828, 4, 9);
                  V v_t_24830 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_24778, 3, 9), v_e_24829});
                  V v_x_24831 = (g_heff_2esyntax_2esurface_2eifE(v_t_24830, v_x_24815, v_x_24821, v_x_24827));
                  return heff_tag_at_n(v_ru_24x1_24811_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24831}), v_st_24825});
                }
                default: return heff_nomatch(v_x11_24824);
                }
              }
              default: return heff_nomatch(v_x1_24823);
              }
            }
            default: return heff_nomatch(v_x11_24818);
            }
          }
          default: return heff_nomatch(v_x1_24817);
          }
        }
        default: return heff_nomatch(v_x11_24812);
        }
      }
      default: return heff_nomatch(v_x1_24811);
      }
    }
    case TAG_Named: {
      V v_m_24837 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_24779}));
      V v_x1_24838 = heff_tr(heff_call(v_m_24837, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_24838)) {
      case TAG_MkPair: {
        V v_x11_24839 = heff_field(v_x1_24838, 0);
        V v_st_24840 = heff_field(v_x1_24838, 1);
        V v_ru_24x1_24838_24MkPair = heff_take_reuse_n(v_x1_24838, 3ULL, 2);
        switch (heff_tag_of(v_x11_24839)) {
        case TAG_Left: {
          V v_e_24841 = heff_field(v_x11_24839, 0);
          heff_take_n(v_x11_24839, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_24778, 9);
          heff_drop(v_a_24781);
          heff_drop(v_b_24783);
          return heff_tag_at_n(v_ru_24x1_24838_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24841}), v_st_24840});
        }
        case TAG_Right: {
          V v_x_24842 = heff_field(v_x11_24839, 0);
          heff_take_n(v_x11_24839, 1ULL, 1);
          V v_m_24843 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_24781}));
          V v_x1_24844 = heff_tr(heff_call(v_m_24843, 1, (V[]){v_st_24840}));
          switch (heff_tag_of(v_x1_24844)) {
          case TAG_MkPair: {
            V v_x11_24845 = heff_field(v_x1_24844, 0);
            V v_st_24846 = heff_field(v_x1_24844, 1);
            heff_take_n(v_x1_24844, 3ULL, 2);
            switch (heff_tag_of(v_x11_24845)) {
            case TAG_Left: {
              V v_e_24847 = heff_field(v_x11_24845, 0);
              heff_take_n(v_x11_24845, 1ULL, 1);
              heff_drop_rec(v_r_240, 3);
              heff_drop_rec(v_kw_24778, 9);
              heff_drop(v_b_24783);
              heff_drop(v_x_24842);
              return heff_tag_at_n(v_ru_24x1_24838_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24847}), v_st_24846});
            }
            case TAG_Right: {
              V v_x_24848 = heff_field(v_x11_24845, 0);
              heff_take_n(v_x11_24845, 1ULL, 1);
              V v_m_24849 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_b_24783)}));
              V v_x1_24850 = heff_tr(heff_call(v_m_24849, 1, (V[]){v_st_24846}));
              switch (heff_tag_of(v_x1_24850)) {
              case TAG_MkPair: {
                V v_x11_24851 = heff_field(v_x1_24850, 0);
                V v_st_24852 = heff_field(v_x1_24850, 1);
                heff_take_n(v_x1_24850, 3ULL, 2);
                switch (heff_tag_of(v_x11_24851)) {
                case TAG_Left: {
                  V v_e_24853 = heff_field(v_x11_24851, 0);
                  heff_take_n(v_x11_24851, 1ULL, 1);
                  heff_drop_rec(v_kw_24778, 9);
                  heff_drop(v_b_24783);
                  heff_drop(v_x_24842);
                  heff_drop(v_x_24848);
                  return heff_tag_at_n(v_ru_24x1_24838_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24853}), v_st_24852});
                }
                case TAG_Right: {
                  V v_x_24854 = heff_field(v_x11_24851, 0);
                  heff_take_n(v_x11_24851, 1ULL, 1);
                  V v_t_24855 = (g_heff_2esyntax_2ecst_2elastE(v_b_24783));
                  V v_e_24856 = heff_get_n(v_t_24855, 4, 9);
                  V v_t_24857 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_24778, 3, 9), v_e_24856});
                  V v_x_24858 = (g_heff_2esyntax_2esurface_2eifE(v_t_24857, v_x_24842, v_x_24848, v_x_24854));
                  return heff_tag_at_n(v_ru_24x1_24838_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24858}), v_st_24852});
                }
                default: return heff_nomatch(v_x11_24851);
                }
              }
              default: return heff_nomatch(v_x1_24850);
              }
            }
            default: return heff_nomatch(v_x11_24845);
            }
          }
          default: return heff_nomatch(v_x1_24844);
          }
        }
        default: return heff_nomatch(v_x11_24839);
        }
      }
      default: return heff_nomatch(v_x1_24838);
      }
    }
    case TAG_Tup: {
      V v_m_24863 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_24779}));
      V v_x1_24864 = heff_tr(heff_call(v_m_24863, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_24864)) {
      case TAG_MkPair: {
        V v_x11_24865 = heff_field(v_x1_24864, 0);
        V v_st_24866 = heff_field(v_x1_24864, 1);
        V v_ru_24x1_24864_24MkPair = heff_take_reuse_n(v_x1_24864, 3ULL, 2);
        switch (heff_tag_of(v_x11_24865)) {
        case TAG_Left: {
          V v_e_24867 = heff_field(v_x11_24865, 0);
          heff_take_n(v_x11_24865, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_24778, 9);
          heff_drop(v_a_24781);
          heff_drop(v_b_24783);
          return heff_tag_at_n(v_ru_24x1_24864_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24867}), v_st_24866});
        }
        case TAG_Right: {
          V v_x_24868 = heff_field(v_x11_24865, 0);
          heff_take_n(v_x11_24865, 1ULL, 1);
          V v_m_24869 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_24781}));
          V v_x1_24870 = heff_tr(heff_call(v_m_24869, 1, (V[]){v_st_24866}));
          switch (heff_tag_of(v_x1_24870)) {
          case TAG_MkPair: {
            V v_x11_24871 = heff_field(v_x1_24870, 0);
            V v_st_24872 = heff_field(v_x1_24870, 1);
            heff_take_n(v_x1_24870, 3ULL, 2);
            switch (heff_tag_of(v_x11_24871)) {
            case TAG_Left: {
              V v_e_24873 = heff_field(v_x11_24871, 0);
              heff_take_n(v_x11_24871, 1ULL, 1);
              heff_drop_rec(v_r_240, 3);
              heff_drop_rec(v_kw_24778, 9);
              heff_drop(v_b_24783);
              heff_drop(v_x_24868);
              return heff_tag_at_n(v_ru_24x1_24864_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24873}), v_st_24872});
            }
            case TAG_Right: {
              V v_x_24874 = heff_field(v_x11_24871, 0);
              heff_take_n(v_x11_24871, 1ULL, 1);
              V v_m_24875 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_b_24783)}));
              V v_x1_24876 = heff_tr(heff_call(v_m_24875, 1, (V[]){v_st_24872}));
              switch (heff_tag_of(v_x1_24876)) {
              case TAG_MkPair: {
                V v_x11_24877 = heff_field(v_x1_24876, 0);
                V v_st_24878 = heff_field(v_x1_24876, 1);
                heff_take_n(v_x1_24876, 3ULL, 2);
                switch (heff_tag_of(v_x11_24877)) {
                case TAG_Left: {
                  V v_e_24879 = heff_field(v_x11_24877, 0);
                  heff_take_n(v_x11_24877, 1ULL, 1);
                  heff_drop_rec(v_kw_24778, 9);
                  heff_drop(v_b_24783);
                  heff_drop(v_x_24868);
                  heff_drop(v_x_24874);
                  return heff_tag_at_n(v_ru_24x1_24864_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24879}), v_st_24878});
                }
                case TAG_Right: {
                  V v_x_24880 = heff_field(v_x11_24877, 0);
                  heff_take_n(v_x11_24877, 1ULL, 1);
                  V v_t_24881 = (g_heff_2esyntax_2ecst_2elastE(v_b_24783));
                  V v_e_24882 = heff_get_n(v_t_24881, 4, 9);
                  V v_t_24883 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_24778, 3, 9), v_e_24882});
                  V v_x_24884 = (g_heff_2esyntax_2esurface_2eifE(v_t_24883, v_x_24868, v_x_24874, v_x_24880));
                  return heff_tag_at_n(v_ru_24x1_24864_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24884}), v_st_24878});
                }
                default: return heff_nomatch(v_x11_24877);
                }
              }
              default: return heff_nomatch(v_x1_24876);
              }
            }
            default: return heff_nomatch(v_x11_24871);
            }
          }
          default: return heff_nomatch(v_x1_24870);
          }
        }
        default: return heff_nomatch(v_x11_24865);
        }
      }
      default: return heff_nomatch(v_x1_24864);
      }
    }
    case TAG_Seg: {
      V v_m_24888 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_24779}));
      V v_x1_24889 = heff_tr(heff_call(v_m_24888, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_24889)) {
      case TAG_MkPair: {
        V v_x11_24890 = heff_field(v_x1_24889, 0);
        V v_st_24891 = heff_field(v_x1_24889, 1);
        V v_ru_24x1_24889_24MkPair = heff_take_reuse_n(v_x1_24889, 3ULL, 2);
        switch (heff_tag_of(v_x11_24890)) {
        case TAG_Left: {
          V v_e_24892 = heff_field(v_x11_24890, 0);
          heff_take_n(v_x11_24890, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_24778, 9);
          heff_drop(v_a_24781);
          heff_drop(v_b_24783);
          return heff_tag_at_n(v_ru_24x1_24889_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24892}), v_st_24891});
        }
        case TAG_Right: {
          V v_x_24893 = heff_field(v_x11_24890, 0);
          heff_take_n(v_x11_24890, 1ULL, 1);
          V v_m_24894 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_24781}));
          V v_x1_24895 = heff_tr(heff_call(v_m_24894, 1, (V[]){v_st_24891}));
          switch (heff_tag_of(v_x1_24895)) {
          case TAG_MkPair: {
            V v_x11_24896 = heff_field(v_x1_24895, 0);
            V v_st_24897 = heff_field(v_x1_24895, 1);
            heff_take_n(v_x1_24895, 3ULL, 2);
            switch (heff_tag_of(v_x11_24896)) {
            case TAG_Left: {
              V v_e_24898 = heff_field(v_x11_24896, 0);
              heff_take_n(v_x11_24896, 1ULL, 1);
              heff_drop_rec(v_r_240, 3);
              heff_drop_rec(v_kw_24778, 9);
              heff_drop(v_b_24783);
              heff_drop(v_x_24893);
              return heff_tag_at_n(v_ru_24x1_24889_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24898}), v_st_24897});
            }
            case TAG_Right: {
              V v_x_24899 = heff_field(v_x11_24896, 0);
              heff_take_n(v_x11_24896, 1ULL, 1);
              V v_m_24900 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_b_24783)}));
              V v_x1_24901 = heff_tr(heff_call(v_m_24900, 1, (V[]){v_st_24897}));
              switch (heff_tag_of(v_x1_24901)) {
              case TAG_MkPair: {
                V v_x11_24902 = heff_field(v_x1_24901, 0);
                V v_st_24903 = heff_field(v_x1_24901, 1);
                heff_take_n(v_x1_24901, 3ULL, 2);
                switch (heff_tag_of(v_x11_24902)) {
                case TAG_Left: {
                  V v_e_24904 = heff_field(v_x11_24902, 0);
                  heff_take_n(v_x11_24902, 1ULL, 1);
                  heff_drop_rec(v_kw_24778, 9);
                  heff_drop(v_b_24783);
                  heff_drop(v_x_24893);
                  heff_drop(v_x_24899);
                  return heff_tag_at_n(v_ru_24x1_24889_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24904}), v_st_24903});
                }
                case TAG_Right: {
                  V v_x_24905 = heff_field(v_x11_24902, 0);
                  heff_take_n(v_x11_24902, 1ULL, 1);
                  V v_t_24906 = (g_heff_2esyntax_2ecst_2elastE(v_b_24783));
                  V v_e_24907 = heff_get_n(v_t_24906, 4, 9);
                  V v_t_24908 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_24778, 3, 9), v_e_24907});
                  V v_x_24909 = (g_heff_2esyntax_2esurface_2eifE(v_t_24908, v_x_24893, v_x_24899, v_x_24905));
                  return heff_tag_at_n(v_ru_24x1_24889_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24909}), v_st_24903});
                }
                default: return heff_nomatch(v_x11_24902);
                }
              }
              default: return heff_nomatch(v_x1_24901);
              }
            }
            default: return heff_nomatch(v_x11_24896);
            }
          }
          default: return heff_nomatch(v_x1_24895);
          }
        }
        default: return heff_nomatch(v_x11_24890);
        }
      }
      default: return heff_nomatch(v_x1_24889);
      }
    }
    case TAG_Braces: {
      V v_m_24914 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_24779}));
      V v_x1_24915 = heff_tr(heff_call(v_m_24914, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_24915)) {
      case TAG_MkPair: {
        V v_x11_24916 = heff_field(v_x1_24915, 0);
        V v_st_24917 = heff_field(v_x1_24915, 1);
        V v_ru_24x1_24915_24MkPair = heff_take_reuse_n(v_x1_24915, 3ULL, 2);
        switch (heff_tag_of(v_x11_24916)) {
        case TAG_Left: {
          V v_e_24918 = heff_field(v_x11_24916, 0);
          heff_take_n(v_x11_24916, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_24778, 9);
          heff_drop(v_a_24781);
          heff_drop(v_b_24783);
          return heff_tag_at_n(v_ru_24x1_24915_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24918}), v_st_24917});
        }
        case TAG_Right: {
          V v_x_24919 = heff_field(v_x11_24916, 0);
          heff_take_n(v_x11_24916, 1ULL, 1);
          V v_m_24920 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_24781}));
          V v_x1_24921 = heff_tr(heff_call(v_m_24920, 1, (V[]){v_st_24917}));
          switch (heff_tag_of(v_x1_24921)) {
          case TAG_MkPair: {
            V v_x11_24922 = heff_field(v_x1_24921, 0);
            V v_st_24923 = heff_field(v_x1_24921, 1);
            heff_take_n(v_x1_24921, 3ULL, 2);
            switch (heff_tag_of(v_x11_24922)) {
            case TAG_Left: {
              V v_e_24924 = heff_field(v_x11_24922, 0);
              heff_take_n(v_x11_24922, 1ULL, 1);
              heff_drop_rec(v_r_240, 3);
              heff_drop_rec(v_kw_24778, 9);
              heff_drop(v_b_24783);
              heff_drop(v_x_24919);
              return heff_tag_at_n(v_ru_24x1_24915_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24924}), v_st_24923});
            }
            case TAG_Right: {
              V v_x_24925 = heff_field(v_x11_24922, 0);
              heff_take_n(v_x11_24922, 1ULL, 1);
              V v_m_24926 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_b_24783)}));
              V v_x1_24927 = heff_tr(heff_call(v_m_24926, 1, (V[]){v_st_24923}));
              switch (heff_tag_of(v_x1_24927)) {
              case TAG_MkPair: {
                V v_x11_24928 = heff_field(v_x1_24927, 0);
                V v_st_24929 = heff_field(v_x1_24927, 1);
                heff_take_n(v_x1_24927, 3ULL, 2);
                switch (heff_tag_of(v_x11_24928)) {
                case TAG_Left: {
                  V v_e_24930 = heff_field(v_x11_24928, 0);
                  heff_take_n(v_x11_24928, 1ULL, 1);
                  heff_drop_rec(v_kw_24778, 9);
                  heff_drop(v_b_24783);
                  heff_drop(v_x_24919);
                  heff_drop(v_x_24925);
                  return heff_tag_at_n(v_ru_24x1_24915_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24930}), v_st_24929});
                }
                case TAG_Right: {
                  V v_x_24931 = heff_field(v_x11_24928, 0);
                  heff_take_n(v_x11_24928, 1ULL, 1);
                  V v_t_24932 = (g_heff_2esyntax_2ecst_2elastE(v_b_24783));
                  V v_e_24933 = heff_get_n(v_t_24932, 4, 9);
                  V v_t_24934 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_24778, 3, 9), v_e_24933});
                  V v_x_24935 = (g_heff_2esyntax_2esurface_2eifE(v_t_24934, v_x_24919, v_x_24925, v_x_24931));
                  return heff_tag_at_n(v_ru_24x1_24915_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24935}), v_st_24929});
                }
                default: return heff_nomatch(v_x11_24928);
                }
              }
              default: return heff_nomatch(v_x1_24927);
              }
            }
            default: return heff_nomatch(v_x11_24922);
            }
          }
          default: return heff_nomatch(v_x1_24921);
          }
        }
        default: return heff_nomatch(v_x11_24916);
        }
      }
      default: return heff_nomatch(v_x1_24915);
      }
    }
    case TAG_Update: {
      V v_m_24942 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_24779}));
      V v_x1_24943 = heff_tr(heff_call(v_m_24942, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_24943)) {
      case TAG_MkPair: {
        V v_x11_24944 = heff_field(v_x1_24943, 0);
        V v_st_24945 = heff_field(v_x1_24943, 1);
        V v_ru_24x1_24943_24MkPair = heff_take_reuse_n(v_x1_24943, 3ULL, 2);
        switch (heff_tag_of(v_x11_24944)) {
        case TAG_Left: {
          V v_e_24946 = heff_field(v_x11_24944, 0);
          heff_take_n(v_x11_24944, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_24778, 9);
          heff_drop(v_a_24781);
          heff_drop(v_b_24783);
          return heff_tag_at_n(v_ru_24x1_24943_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24946}), v_st_24945});
        }
        case TAG_Right: {
          V v_x_24947 = heff_field(v_x11_24944, 0);
          heff_take_n(v_x11_24944, 1ULL, 1);
          V v_m_24948 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_24781}));
          V v_x1_24949 = heff_tr(heff_call(v_m_24948, 1, (V[]){v_st_24945}));
          switch (heff_tag_of(v_x1_24949)) {
          case TAG_MkPair: {
            V v_x11_24950 = heff_field(v_x1_24949, 0);
            V v_st_24951 = heff_field(v_x1_24949, 1);
            heff_take_n(v_x1_24949, 3ULL, 2);
            switch (heff_tag_of(v_x11_24950)) {
            case TAG_Left: {
              V v_e_24952 = heff_field(v_x11_24950, 0);
              heff_take_n(v_x11_24950, 1ULL, 1);
              heff_drop_rec(v_r_240, 3);
              heff_drop_rec(v_kw_24778, 9);
              heff_drop(v_b_24783);
              heff_drop(v_x_24947);
              return heff_tag_at_n(v_ru_24x1_24943_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24952}), v_st_24951});
            }
            case TAG_Right: {
              V v_x_24953 = heff_field(v_x11_24950, 0);
              heff_take_n(v_x11_24950, 1ULL, 1);
              V v_m_24954 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_b_24783)}));
              V v_x1_24955 = heff_tr(heff_call(v_m_24954, 1, (V[]){v_st_24951}));
              switch (heff_tag_of(v_x1_24955)) {
              case TAG_MkPair: {
                V v_x11_24956 = heff_field(v_x1_24955, 0);
                V v_st_24957 = heff_field(v_x1_24955, 1);
                heff_take_n(v_x1_24955, 3ULL, 2);
                switch (heff_tag_of(v_x11_24956)) {
                case TAG_Left: {
                  V v_e_24958 = heff_field(v_x11_24956, 0);
                  heff_take_n(v_x11_24956, 1ULL, 1);
                  heff_drop_rec(v_kw_24778, 9);
                  heff_drop(v_b_24783);
                  heff_drop(v_x_24947);
                  heff_drop(v_x_24953);
                  return heff_tag_at_n(v_ru_24x1_24943_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24958}), v_st_24957});
                }
                case TAG_Right: {
                  V v_x_24959 = heff_field(v_x11_24956, 0);
                  heff_take_n(v_x11_24956, 1ULL, 1);
                  V v_t_24960 = (g_heff_2esyntax_2ecst_2elastE(v_b_24783));
                  V v_e_24961 = heff_get_n(v_t_24960, 4, 9);
                  V v_t_24962 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_24778, 3, 9), v_e_24961});
                  V v_x_24963 = (g_heff_2esyntax_2esurface_2eifE(v_t_24962, v_x_24947, v_x_24953, v_x_24959));
                  return heff_tag_at_n(v_ru_24x1_24943_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24963}), v_st_24957});
                }
                default: return heff_nomatch(v_x11_24956);
                }
              }
              default: return heff_nomatch(v_x1_24955);
              }
            }
            default: return heff_nomatch(v_x11_24950);
            }
          }
          default: return heff_nomatch(v_x1_24949);
          }
        }
        default: return heff_nomatch(v_x11_24944);
        }
      }
      default: return heff_nomatch(v_x1_24943);
      }
    }
    case TAG_EUSet: {
      V v_m_24967 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_24779}));
      V v_x1_24968 = heff_tr(heff_call(v_m_24967, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_24968)) {
      case TAG_MkPair: {
        V v_x11_24969 = heff_field(v_x1_24968, 0);
        V v_st_24970 = heff_field(v_x1_24968, 1);
        V v_ru_24x1_24968_24MkPair = heff_take_reuse_n(v_x1_24968, 3ULL, 2);
        switch (heff_tag_of(v_x11_24969)) {
        case TAG_Left: {
          V v_e_24971 = heff_field(v_x11_24969, 0);
          heff_take_n(v_x11_24969, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_24778, 9);
          heff_drop(v_a_24781);
          heff_drop(v_b_24783);
          return heff_tag_at_n(v_ru_24x1_24968_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24971}), v_st_24970});
        }
        case TAG_Right: {
          V v_x_24972 = heff_field(v_x11_24969, 0);
          heff_take_n(v_x11_24969, 1ULL, 1);
          V v_m_24973 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_24781}));
          V v_x1_24974 = heff_tr(heff_call(v_m_24973, 1, (V[]){v_st_24970}));
          switch (heff_tag_of(v_x1_24974)) {
          case TAG_MkPair: {
            V v_x11_24975 = heff_field(v_x1_24974, 0);
            V v_st_24976 = heff_field(v_x1_24974, 1);
            heff_take_n(v_x1_24974, 3ULL, 2);
            switch (heff_tag_of(v_x11_24975)) {
            case TAG_Left: {
              V v_e_24977 = heff_field(v_x11_24975, 0);
              heff_take_n(v_x11_24975, 1ULL, 1);
              heff_drop_rec(v_r_240, 3);
              heff_drop_rec(v_kw_24778, 9);
              heff_drop(v_b_24783);
              heff_drop(v_x_24972);
              return heff_tag_at_n(v_ru_24x1_24968_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24977}), v_st_24976});
            }
            case TAG_Right: {
              V v_x_24978 = heff_field(v_x11_24975, 0);
              heff_take_n(v_x11_24975, 1ULL, 1);
              V v_m_24979 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_b_24783)}));
              V v_x1_24980 = heff_tr(heff_call(v_m_24979, 1, (V[]){v_st_24976}));
              switch (heff_tag_of(v_x1_24980)) {
              case TAG_MkPair: {
                V v_x11_24981 = heff_field(v_x1_24980, 0);
                V v_st_24982 = heff_field(v_x1_24980, 1);
                heff_take_n(v_x1_24980, 3ULL, 2);
                switch (heff_tag_of(v_x11_24981)) {
                case TAG_Left: {
                  V v_e_24983 = heff_field(v_x11_24981, 0);
                  heff_take_n(v_x11_24981, 1ULL, 1);
                  heff_drop_rec(v_kw_24778, 9);
                  heff_drop(v_b_24783);
                  heff_drop(v_x_24972);
                  heff_drop(v_x_24978);
                  return heff_tag_at_n(v_ru_24x1_24968_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24983}), v_st_24982});
                }
                case TAG_Right: {
                  V v_x_24984 = heff_field(v_x11_24981, 0);
                  heff_take_n(v_x11_24981, 1ULL, 1);
                  V v_t_24985 = (g_heff_2esyntax_2ecst_2elastE(v_b_24783));
                  V v_e_24986 = heff_get_n(v_t_24985, 4, 9);
                  V v_t_24987 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_24778, 3, 9), v_e_24986});
                  V v_x_24988 = (g_heff_2esyntax_2esurface_2eifE(v_t_24987, v_x_24972, v_x_24978, v_x_24984));
                  return heff_tag_at_n(v_ru_24x1_24968_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24988}), v_st_24982});
                }
                default: return heff_nomatch(v_x11_24981);
                }
              }
              default: return heff_nomatch(v_x1_24980);
              }
            }
            default: return heff_nomatch(v_x11_24975);
            }
          }
          default: return heff_nomatch(v_x1_24974);
          }
        }
        default: return heff_nomatch(v_x11_24969);
        }
      }
      default: return heff_nomatch(v_x1_24968);
      }
    }
    case TAG_InstB: {
      V v_m_24994 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_24779}));
      V v_x1_24995 = heff_tr(heff_call(v_m_24994, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_24995)) {
      case TAG_MkPair: {
        V v_x11_24996 = heff_field(v_x1_24995, 0);
        V v_st_24997 = heff_field(v_x1_24995, 1);
        V v_ru_24x1_24995_24MkPair = heff_take_reuse_n(v_x1_24995, 3ULL, 2);
        switch (heff_tag_of(v_x11_24996)) {
        case TAG_Left: {
          V v_e_24998 = heff_field(v_x11_24996, 0);
          heff_take_n(v_x11_24996, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_24778, 9);
          heff_drop(v_a_24781);
          heff_drop(v_b_24783);
          return heff_tag_at_n(v_ru_24x1_24995_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24998}), v_st_24997});
        }
        case TAG_Right: {
          V v_x_24999 = heff_field(v_x11_24996, 0);
          heff_take_n(v_x11_24996, 1ULL, 1);
          V v_m_241000 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_24781}));
          V v_x1_241001 = heff_tr(heff_call(v_m_241000, 1, (V[]){v_st_24997}));
          switch (heff_tag_of(v_x1_241001)) {
          case TAG_MkPair: {
            V v_x11_241002 = heff_field(v_x1_241001, 0);
            V v_st_241003 = heff_field(v_x1_241001, 1);
            heff_take_n(v_x1_241001, 3ULL, 2);
            switch (heff_tag_of(v_x11_241002)) {
            case TAG_Left: {
              V v_e_241004 = heff_field(v_x11_241002, 0);
              heff_take_n(v_x11_241002, 1ULL, 1);
              heff_drop_rec(v_r_240, 3);
              heff_drop_rec(v_kw_24778, 9);
              heff_drop(v_b_24783);
              heff_drop(v_x_24999);
              return heff_tag_at_n(v_ru_24x1_24995_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241004}), v_st_241003});
            }
            case TAG_Right: {
              V v_x_241005 = heff_field(v_x11_241002, 0);
              heff_take_n(v_x11_241002, 1ULL, 1);
              V v_m_241006 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_b_24783)}));
              V v_x1_241007 = heff_tr(heff_call(v_m_241006, 1, (V[]){v_st_241003}));
              switch (heff_tag_of(v_x1_241007)) {
              case TAG_MkPair: {
                V v_x11_241008 = heff_field(v_x1_241007, 0);
                V v_st_241009 = heff_field(v_x1_241007, 1);
                heff_take_n(v_x1_241007, 3ULL, 2);
                switch (heff_tag_of(v_x11_241008)) {
                case TAG_Left: {
                  V v_e_241010 = heff_field(v_x11_241008, 0);
                  heff_take_n(v_x11_241008, 1ULL, 1);
                  heff_drop_rec(v_kw_24778, 9);
                  heff_drop(v_b_24783);
                  heff_drop(v_x_24999);
                  heff_drop(v_x_241005);
                  return heff_tag_at_n(v_ru_24x1_24995_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241010}), v_st_241009});
                }
                case TAG_Right: {
                  V v_x_241011 = heff_field(v_x11_241008, 0);
                  heff_take_n(v_x11_241008, 1ULL, 1);
                  V v_t_241012 = (g_heff_2esyntax_2ecst_2elastE(v_b_24783));
                  V v_e_241013 = heff_get_n(v_t_241012, 4, 9);
                  V v_t_241014 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_24778, 3, 9), v_e_241013});
                  V v_x_241015 = (g_heff_2esyntax_2esurface_2eifE(v_t_241014, v_x_24999, v_x_241005, v_x_241011));
                  return heff_tag_at_n(v_ru_24x1_24995_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_241015}), v_st_241009});
                }
                default: return heff_nomatch(v_x11_241008);
                }
              }
              default: return heff_nomatch(v_x1_241007);
              }
            }
            default: return heff_nomatch(v_x11_241002);
            }
          }
          default: return heff_nomatch(v_x1_241001);
          }
        }
        default: return heff_nomatch(v_x11_24996);
        }
      }
      default: return heff_nomatch(v_x1_24995);
      }
    }
    case TAG_EFSet: {
      V v_m_241019 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_24779}));
      V v_x1_241020 = heff_tr(heff_call(v_m_241019, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_241020)) {
      case TAG_MkPair: {
        V v_x11_241021 = heff_field(v_x1_241020, 0);
        V v_st_241022 = heff_field(v_x1_241020, 1);
        V v_ru_24x1_241020_24MkPair = heff_take_reuse_n(v_x1_241020, 3ULL, 2);
        switch (heff_tag_of(v_x11_241021)) {
        case TAG_Left: {
          V v_e_241023 = heff_field(v_x11_241021, 0);
          heff_take_n(v_x11_241021, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_24778, 9);
          heff_drop(v_a_24781);
          heff_drop(v_b_24783);
          return heff_tag_at_n(v_ru_24x1_241020_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241023}), v_st_241022});
        }
        case TAG_Right: {
          V v_x_241024 = heff_field(v_x11_241021, 0);
          heff_take_n(v_x11_241021, 1ULL, 1);
          V v_m_241025 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_24781}));
          V v_x1_241026 = heff_tr(heff_call(v_m_241025, 1, (V[]){v_st_241022}));
          switch (heff_tag_of(v_x1_241026)) {
          case TAG_MkPair: {
            V v_x11_241027 = heff_field(v_x1_241026, 0);
            V v_st_241028 = heff_field(v_x1_241026, 1);
            heff_take_n(v_x1_241026, 3ULL, 2);
            switch (heff_tag_of(v_x11_241027)) {
            case TAG_Left: {
              V v_e_241029 = heff_field(v_x11_241027, 0);
              heff_take_n(v_x11_241027, 1ULL, 1);
              heff_drop_rec(v_r_240, 3);
              heff_drop_rec(v_kw_24778, 9);
              heff_drop(v_b_24783);
              heff_drop(v_x_241024);
              return heff_tag_at_n(v_ru_24x1_241020_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241029}), v_st_241028});
            }
            case TAG_Right: {
              V v_x_241030 = heff_field(v_x11_241027, 0);
              heff_take_n(v_x11_241027, 1ULL, 1);
              V v_m_241031 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_b_24783)}));
              V v_x1_241032 = heff_tr(heff_call(v_m_241031, 1, (V[]){v_st_241028}));
              switch (heff_tag_of(v_x1_241032)) {
              case TAG_MkPair: {
                V v_x11_241033 = heff_field(v_x1_241032, 0);
                V v_st_241034 = heff_field(v_x1_241032, 1);
                heff_take_n(v_x1_241032, 3ULL, 2);
                switch (heff_tag_of(v_x11_241033)) {
                case TAG_Left: {
                  V v_e_241035 = heff_field(v_x11_241033, 0);
                  heff_take_n(v_x11_241033, 1ULL, 1);
                  heff_drop_rec(v_kw_24778, 9);
                  heff_drop(v_b_24783);
                  heff_drop(v_x_241024);
                  heff_drop(v_x_241030);
                  return heff_tag_at_n(v_ru_24x1_241020_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241035}), v_st_241034});
                }
                case TAG_Right: {
                  V v_x_241036 = heff_field(v_x11_241033, 0);
                  heff_take_n(v_x11_241033, 1ULL, 1);
                  V v_t_241037 = (g_heff_2esyntax_2ecst_2elastE(v_b_24783));
                  V v_e_241038 = heff_get_n(v_t_241037, 4, 9);
                  V v_t_241039 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_24778, 3, 9), v_e_241038});
                  V v_x_241040 = (g_heff_2esyntax_2esurface_2eifE(v_t_241039, v_x_241024, v_x_241030, v_x_241036));
                  return heff_tag_at_n(v_ru_24x1_241020_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_241040}), v_st_241034});
                }
                default: return heff_nomatch(v_x11_241033);
                }
              }
              default: return heff_nomatch(v_x1_241032);
              }
            }
            default: return heff_nomatch(v_x11_241027);
            }
          }
          default: return heff_nomatch(v_x1_241026);
          }
        }
        default: return heff_nomatch(v_x11_241021);
        }
      }
      default: return heff_nomatch(v_x1_241020);
      }
    }
    case TAG_EFDefault: {
      V v_m_241044 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_24779}));
      V v_x1_241045 = heff_tr(heff_call(v_m_241044, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_241045)) {
      case TAG_MkPair: {
        V v_x11_241046 = heff_field(v_x1_241045, 0);
        V v_st_241047 = heff_field(v_x1_241045, 1);
        V v_ru_24x1_241045_24MkPair = heff_take_reuse_n(v_x1_241045, 3ULL, 2);
        switch (heff_tag_of(v_x11_241046)) {
        case TAG_Left: {
          V v_e_241048 = heff_field(v_x11_241046, 0);
          heff_take_n(v_x11_241046, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_24778, 9);
          heff_drop(v_a_24781);
          heff_drop(v_b_24783);
          return heff_tag_at_n(v_ru_24x1_241045_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241048}), v_st_241047});
        }
        case TAG_Right: {
          V v_x_241049 = heff_field(v_x11_241046, 0);
          heff_take_n(v_x11_241046, 1ULL, 1);
          V v_m_241050 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_24781}));
          V v_x1_241051 = heff_tr(heff_call(v_m_241050, 1, (V[]){v_st_241047}));
          switch (heff_tag_of(v_x1_241051)) {
          case TAG_MkPair: {
            V v_x11_241052 = heff_field(v_x1_241051, 0);
            V v_st_241053 = heff_field(v_x1_241051, 1);
            heff_take_n(v_x1_241051, 3ULL, 2);
            switch (heff_tag_of(v_x11_241052)) {
            case TAG_Left: {
              V v_e_241054 = heff_field(v_x11_241052, 0);
              heff_take_n(v_x11_241052, 1ULL, 1);
              heff_drop_rec(v_r_240, 3);
              heff_drop_rec(v_kw_24778, 9);
              heff_drop(v_b_24783);
              heff_drop(v_x_241049);
              return heff_tag_at_n(v_ru_24x1_241045_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241054}), v_st_241053});
            }
            case TAG_Right: {
              V v_x_241055 = heff_field(v_x11_241052, 0);
              heff_take_n(v_x11_241052, 1ULL, 1);
              V v_m_241056 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_b_24783)}));
              V v_x1_241057 = heff_tr(heff_call(v_m_241056, 1, (V[]){v_st_241053}));
              switch (heff_tag_of(v_x1_241057)) {
              case TAG_MkPair: {
                V v_x11_241058 = heff_field(v_x1_241057, 0);
                V v_st_241059 = heff_field(v_x1_241057, 1);
                heff_take_n(v_x1_241057, 3ULL, 2);
                switch (heff_tag_of(v_x11_241058)) {
                case TAG_Left: {
                  V v_e_241060 = heff_field(v_x11_241058, 0);
                  heff_take_n(v_x11_241058, 1ULL, 1);
                  heff_drop_rec(v_kw_24778, 9);
                  heff_drop(v_b_24783);
                  heff_drop(v_x_241049);
                  heff_drop(v_x_241055);
                  return heff_tag_at_n(v_ru_24x1_241045_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241060}), v_st_241059});
                }
                case TAG_Right: {
                  V v_x_241061 = heff_field(v_x11_241058, 0);
                  heff_take_n(v_x11_241058, 1ULL, 1);
                  V v_t_241062 = (g_heff_2esyntax_2ecst_2elastE(v_b_24783));
                  V v_e_241063 = heff_get_n(v_t_241062, 4, 9);
                  V v_t_241064 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_24778, 3, 9), v_e_241063});
                  V v_x_241065 = (g_heff_2esyntax_2esurface_2eifE(v_t_241064, v_x_241049, v_x_241055, v_x_241061));
                  return heff_tag_at_n(v_ru_24x1_241045_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_241065}), v_st_241059});
                }
                default: return heff_nomatch(v_x11_241058);
                }
              }
              default: return heff_nomatch(v_x1_241057);
              }
            }
            default: return heff_nomatch(v_x11_241052);
            }
          }
          default: return heff_nomatch(v_x1_241051);
          }
        }
        default: return heff_nomatch(v_x11_241046);
        }
      }
      default: return heff_nomatch(v_x1_241045);
      }
    }
    case TAG_Sum: {
      V v_m_241071 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_24779}));
      V v_x1_241072 = heff_tr(heff_call(v_m_241071, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_241072)) {
      case TAG_MkPair: {
        V v_x11_241073 = heff_field(v_x1_241072, 0);
        V v_st_241074 = heff_field(v_x1_241072, 1);
        V v_ru_24x1_241072_24MkPair = heff_take_reuse_n(v_x1_241072, 3ULL, 2);
        switch (heff_tag_of(v_x11_241073)) {
        case TAG_Left: {
          V v_e_241075 = heff_field(v_x11_241073, 0);
          heff_take_n(v_x11_241073, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_24778, 9);
          heff_drop(v_a_24781);
          heff_drop(v_b_24783);
          return heff_tag_at_n(v_ru_24x1_241072_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241075}), v_st_241074});
        }
        case TAG_Right: {
          V v_x_241076 = heff_field(v_x11_241073, 0);
          heff_take_n(v_x11_241073, 1ULL, 1);
          V v_m_241077 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_24781}));
          V v_x1_241078 = heff_tr(heff_call(v_m_241077, 1, (V[]){v_st_241074}));
          switch (heff_tag_of(v_x1_241078)) {
          case TAG_MkPair: {
            V v_x11_241079 = heff_field(v_x1_241078, 0);
            V v_st_241080 = heff_field(v_x1_241078, 1);
            heff_take_n(v_x1_241078, 3ULL, 2);
            switch (heff_tag_of(v_x11_241079)) {
            case TAG_Left: {
              V v_e_241081 = heff_field(v_x11_241079, 0);
              heff_take_n(v_x11_241079, 1ULL, 1);
              heff_drop_rec(v_r_240, 3);
              heff_drop_rec(v_kw_24778, 9);
              heff_drop(v_b_24783);
              heff_drop(v_x_241076);
              return heff_tag_at_n(v_ru_24x1_241072_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241081}), v_st_241080});
            }
            case TAG_Right: {
              V v_x_241082 = heff_field(v_x11_241079, 0);
              heff_take_n(v_x11_241079, 1ULL, 1);
              V v_m_241083 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_b_24783)}));
              V v_x1_241084 = heff_tr(heff_call(v_m_241083, 1, (V[]){v_st_241080}));
              switch (heff_tag_of(v_x1_241084)) {
              case TAG_MkPair: {
                V v_x11_241085 = heff_field(v_x1_241084, 0);
                V v_st_241086 = heff_field(v_x1_241084, 1);
                heff_take_n(v_x1_241084, 3ULL, 2);
                switch (heff_tag_of(v_x11_241085)) {
                case TAG_Left: {
                  V v_e_241087 = heff_field(v_x11_241085, 0);
                  heff_take_n(v_x11_241085, 1ULL, 1);
                  heff_drop_rec(v_kw_24778, 9);
                  heff_drop(v_b_24783);
                  heff_drop(v_x_241076);
                  heff_drop(v_x_241082);
                  return heff_tag_at_n(v_ru_24x1_241072_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241087}), v_st_241086});
                }
                case TAG_Right: {
                  V v_x_241088 = heff_field(v_x11_241085, 0);
                  heff_take_n(v_x11_241085, 1ULL, 1);
                  V v_t_241089 = (g_heff_2esyntax_2ecst_2elastE(v_b_24783));
                  V v_e_241090 = heff_get_n(v_t_241089, 4, 9);
                  V v_t_241091 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_24778, 3, 9), v_e_241090});
                  V v_x_241092 = (g_heff_2esyntax_2esurface_2eifE(v_t_241091, v_x_241076, v_x_241082, v_x_241088));
                  return heff_tag_at_n(v_ru_24x1_241072_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_241092}), v_st_241086});
                }
                default: return heff_nomatch(v_x11_241085);
                }
              }
              default: return heff_nomatch(v_x1_241084);
              }
            }
            default: return heff_nomatch(v_x11_241079);
            }
          }
          default: return heff_nomatch(v_x1_241078);
          }
        }
        default: return heff_nomatch(v_x11_241073);
        }
      }
      default: return heff_nomatch(v_x1_241072);
      }
    }
    case TAG_ECon: {
      V v_m_241095 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_24779}));
      V v_x1_241096 = heff_tr(heff_call(v_m_241095, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_241096)) {
      case TAG_MkPair: {
        V v_x11_241097 = heff_field(v_x1_241096, 0);
        V v_st_241098 = heff_field(v_x1_241096, 1);
        V v_ru_24x1_241096_24MkPair = heff_take_reuse_n(v_x1_241096, 3ULL, 2);
        switch (heff_tag_of(v_x11_241097)) {
        case TAG_Left: {
          V v_e_241099 = heff_field(v_x11_241097, 0);
          heff_take_n(v_x11_241097, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_24778, 9);
          heff_drop(v_a_24781);
          heff_drop(v_b_24783);
          return heff_tag_at_n(v_ru_24x1_241096_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241099}), v_st_241098});
        }
        case TAG_Right: {
          V v_x_241100 = heff_field(v_x11_241097, 0);
          heff_take_n(v_x11_241097, 1ULL, 1);
          V v_m_241101 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_24781}));
          V v_x1_241102 = heff_tr(heff_call(v_m_241101, 1, (V[]){v_st_241098}));
          switch (heff_tag_of(v_x1_241102)) {
          case TAG_MkPair: {
            V v_x11_241103 = heff_field(v_x1_241102, 0);
            V v_st_241104 = heff_field(v_x1_241102, 1);
            heff_take_n(v_x1_241102, 3ULL, 2);
            switch (heff_tag_of(v_x11_241103)) {
            case TAG_Left: {
              V v_e_241105 = heff_field(v_x11_241103, 0);
              heff_take_n(v_x11_241103, 1ULL, 1);
              heff_drop_rec(v_r_240, 3);
              heff_drop_rec(v_kw_24778, 9);
              heff_drop(v_b_24783);
              heff_drop(v_x_241100);
              return heff_tag_at_n(v_ru_24x1_241096_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241105}), v_st_241104});
            }
            case TAG_Right: {
              V v_x_241106 = heff_field(v_x11_241103, 0);
              heff_take_n(v_x11_241103, 1ULL, 1);
              V v_m_241107 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_b_24783)}));
              V v_x1_241108 = heff_tr(heff_call(v_m_241107, 1, (V[]){v_st_241104}));
              switch (heff_tag_of(v_x1_241108)) {
              case TAG_MkPair: {
                V v_x11_241109 = heff_field(v_x1_241108, 0);
                V v_st_241110 = heff_field(v_x1_241108, 1);
                heff_take_n(v_x1_241108, 3ULL, 2);
                switch (heff_tag_of(v_x11_241109)) {
                case TAG_Left: {
                  V v_e_241111 = heff_field(v_x11_241109, 0);
                  heff_take_n(v_x11_241109, 1ULL, 1);
                  heff_drop_rec(v_kw_24778, 9);
                  heff_drop(v_b_24783);
                  heff_drop(v_x_241100);
                  heff_drop(v_x_241106);
                  return heff_tag_at_n(v_ru_24x1_241096_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241111}), v_st_241110});
                }
                case TAG_Right: {
                  V v_x_241112 = heff_field(v_x11_241109, 0);
                  heff_take_n(v_x11_241109, 1ULL, 1);
                  V v_t_241113 = (g_heff_2esyntax_2ecst_2elastE(v_b_24783));
                  V v_e_241114 = heff_get_n(v_t_241113, 4, 9);
                  V v_t_241115 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_24778, 3, 9), v_e_241114});
                  V v_x_241116 = (g_heff_2esyntax_2esurface_2eifE(v_t_241115, v_x_241100, v_x_241106, v_x_241112));
                  return heff_tag_at_n(v_ru_24x1_241096_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_241116}), v_st_241110});
                }
                default: return heff_nomatch(v_x11_241109);
                }
              }
              default: return heff_nomatch(v_x1_241108);
              }
            }
            default: return heff_nomatch(v_x11_241103);
            }
          }
          default: return heff_nomatch(v_x1_241102);
          }
        }
        default: return heff_nomatch(v_x11_241097);
        }
      }
      default: return heff_nomatch(v_x1_241096);
      }
    }
    case TAG_EField: {
      V v_m_241119 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_24779}));
      V v_x1_241120 = heff_tr(heff_call(v_m_241119, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_241120)) {
      case TAG_MkPair: {
        V v_x11_241121 = heff_field(v_x1_241120, 0);
        V v_st_241122 = heff_field(v_x1_241120, 1);
        V v_ru_24x1_241120_24MkPair = heff_take_reuse_n(v_x1_241120, 3ULL, 2);
        switch (heff_tag_of(v_x11_241121)) {
        case TAG_Left: {
          V v_e_241123 = heff_field(v_x11_241121, 0);
          heff_take_n(v_x11_241121, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_24778, 9);
          heff_drop(v_a_24781);
          heff_drop(v_b_24783);
          return heff_tag_at_n(v_ru_24x1_241120_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241123}), v_st_241122});
        }
        case TAG_Right: {
          V v_x_241124 = heff_field(v_x11_241121, 0);
          heff_take_n(v_x11_241121, 1ULL, 1);
          V v_m_241125 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_24781}));
          V v_x1_241126 = heff_tr(heff_call(v_m_241125, 1, (V[]){v_st_241122}));
          switch (heff_tag_of(v_x1_241126)) {
          case TAG_MkPair: {
            V v_x11_241127 = heff_field(v_x1_241126, 0);
            V v_st_241128 = heff_field(v_x1_241126, 1);
            heff_take_n(v_x1_241126, 3ULL, 2);
            switch (heff_tag_of(v_x11_241127)) {
            case TAG_Left: {
              V v_e_241129 = heff_field(v_x11_241127, 0);
              heff_take_n(v_x11_241127, 1ULL, 1);
              heff_drop_rec(v_r_240, 3);
              heff_drop_rec(v_kw_24778, 9);
              heff_drop(v_b_24783);
              heff_drop(v_x_241124);
              return heff_tag_at_n(v_ru_24x1_241120_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241129}), v_st_241128});
            }
            case TAG_Right: {
              V v_x_241130 = heff_field(v_x11_241127, 0);
              heff_take_n(v_x11_241127, 1ULL, 1);
              V v_m_241131 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_b_24783)}));
              V v_x1_241132 = heff_tr(heff_call(v_m_241131, 1, (V[]){v_st_241128}));
              switch (heff_tag_of(v_x1_241132)) {
              case TAG_MkPair: {
                V v_x11_241133 = heff_field(v_x1_241132, 0);
                V v_st_241134 = heff_field(v_x1_241132, 1);
                heff_take_n(v_x1_241132, 3ULL, 2);
                switch (heff_tag_of(v_x11_241133)) {
                case TAG_Left: {
                  V v_e_241135 = heff_field(v_x11_241133, 0);
                  heff_take_n(v_x11_241133, 1ULL, 1);
                  heff_drop_rec(v_kw_24778, 9);
                  heff_drop(v_b_24783);
                  heff_drop(v_x_241124);
                  heff_drop(v_x_241130);
                  return heff_tag_at_n(v_ru_24x1_241120_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241135}), v_st_241134});
                }
                case TAG_Right: {
                  V v_x_241136 = heff_field(v_x11_241133, 0);
                  heff_take_n(v_x11_241133, 1ULL, 1);
                  V v_t_241137 = (g_heff_2esyntax_2ecst_2elastE(v_b_24783));
                  V v_e_241138 = heff_get_n(v_t_241137, 4, 9);
                  V v_t_241139 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_24778, 3, 9), v_e_241138});
                  V v_x_241140 = (g_heff_2esyntax_2esurface_2eifE(v_t_241139, v_x_241124, v_x_241130, v_x_241136));
                  return heff_tag_at_n(v_ru_24x1_241120_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_241140}), v_st_241134});
                }
                default: return heff_nomatch(v_x11_241133);
                }
              }
              default: return heff_nomatch(v_x1_241132);
              }
            }
            default: return heff_nomatch(v_x11_241127);
            }
          }
          default: return heff_nomatch(v_x1_241126);
          }
        }
        default: return heff_nomatch(v_x11_241121);
        }
      }
      default: return heff_nomatch(v_x1_241120);
      }
    }
    case TAG_ENeg: {
      V v_m_241143 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_24779}));
      V v_x1_241144 = heff_tr(heff_call(v_m_241143, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_241144)) {
      case TAG_MkPair: {
        V v_x11_241145 = heff_field(v_x1_241144, 0);
        V v_st_241146 = heff_field(v_x1_241144, 1);
        V v_ru_24x1_241144_24MkPair = heff_take_reuse_n(v_x1_241144, 3ULL, 2);
        switch (heff_tag_of(v_x11_241145)) {
        case TAG_Left: {
          V v_e_241147 = heff_field(v_x11_241145, 0);
          heff_take_n(v_x11_241145, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_24778, 9);
          heff_drop(v_a_24781);
          heff_drop(v_b_24783);
          return heff_tag_at_n(v_ru_24x1_241144_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241147}), v_st_241146});
        }
        case TAG_Right: {
          V v_x_241148 = heff_field(v_x11_241145, 0);
          heff_take_n(v_x11_241145, 1ULL, 1);
          V v_m_241149 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_24781}));
          V v_x1_241150 = heff_tr(heff_call(v_m_241149, 1, (V[]){v_st_241146}));
          switch (heff_tag_of(v_x1_241150)) {
          case TAG_MkPair: {
            V v_x11_241151 = heff_field(v_x1_241150, 0);
            V v_st_241152 = heff_field(v_x1_241150, 1);
            heff_take_n(v_x1_241150, 3ULL, 2);
            switch (heff_tag_of(v_x11_241151)) {
            case TAG_Left: {
              V v_e_241153 = heff_field(v_x11_241151, 0);
              heff_take_n(v_x11_241151, 1ULL, 1);
              heff_drop_rec(v_r_240, 3);
              heff_drop_rec(v_kw_24778, 9);
              heff_drop(v_b_24783);
              heff_drop(v_x_241148);
              return heff_tag_at_n(v_ru_24x1_241144_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241153}), v_st_241152});
            }
            case TAG_Right: {
              V v_x_241154 = heff_field(v_x11_241151, 0);
              heff_take_n(v_x11_241151, 1ULL, 1);
              V v_m_241155 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_b_24783)}));
              V v_x1_241156 = heff_tr(heff_call(v_m_241155, 1, (V[]){v_st_241152}));
              switch (heff_tag_of(v_x1_241156)) {
              case TAG_MkPair: {
                V v_x11_241157 = heff_field(v_x1_241156, 0);
                V v_st_241158 = heff_field(v_x1_241156, 1);
                heff_take_n(v_x1_241156, 3ULL, 2);
                switch (heff_tag_of(v_x11_241157)) {
                case TAG_Left: {
                  V v_e_241159 = heff_field(v_x11_241157, 0);
                  heff_take_n(v_x11_241157, 1ULL, 1);
                  heff_drop_rec(v_kw_24778, 9);
                  heff_drop(v_b_24783);
                  heff_drop(v_x_241148);
                  heff_drop(v_x_241154);
                  return heff_tag_at_n(v_ru_24x1_241144_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241159}), v_st_241158});
                }
                case TAG_Right: {
                  V v_x_241160 = heff_field(v_x11_241157, 0);
                  heff_take_n(v_x11_241157, 1ULL, 1);
                  V v_t_241161 = (g_heff_2esyntax_2ecst_2elastE(v_b_24783));
                  V v_e_241162 = heff_get_n(v_t_241161, 4, 9);
                  V v_t_241163 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_24778, 3, 9), v_e_241162});
                  V v_x_241164 = (g_heff_2esyntax_2esurface_2eifE(v_t_241163, v_x_241148, v_x_241154, v_x_241160));
                  return heff_tag_at_n(v_ru_24x1_241144_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_241164}), v_st_241158});
                }
                default: return heff_nomatch(v_x11_241157);
                }
              }
              default: return heff_nomatch(v_x1_241156);
              }
            }
            default: return heff_nomatch(v_x11_241151);
            }
          }
          default: return heff_nomatch(v_x1_241150);
          }
        }
        default: return heff_nomatch(v_x11_241145);
        }
      }
      default: return heff_nomatch(v_x1_241144);
      }
    }
    case TAG_App: {
      V v_m_241167 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_24779}));
      V v_x1_241168 = heff_tr(heff_call(v_m_241167, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_241168)) {
      case TAG_MkPair: {
        V v_x11_241169 = heff_field(v_x1_241168, 0);
        V v_st_241170 = heff_field(v_x1_241168, 1);
        V v_ru_24x1_241168_24MkPair = heff_take_reuse_n(v_x1_241168, 3ULL, 2);
        switch (heff_tag_of(v_x11_241169)) {
        case TAG_Left: {
          V v_e_241171 = heff_field(v_x11_241169, 0);
          heff_take_n(v_x11_241169, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_24778, 9);
          heff_drop(v_a_24781);
          heff_drop(v_b_24783);
          return heff_tag_at_n(v_ru_24x1_241168_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241171}), v_st_241170});
        }
        case TAG_Right: {
          V v_x_241172 = heff_field(v_x11_241169, 0);
          heff_take_n(v_x11_241169, 1ULL, 1);
          V v_m_241173 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_24781}));
          V v_x1_241174 = heff_tr(heff_call(v_m_241173, 1, (V[]){v_st_241170}));
          switch (heff_tag_of(v_x1_241174)) {
          case TAG_MkPair: {
            V v_x11_241175 = heff_field(v_x1_241174, 0);
            V v_st_241176 = heff_field(v_x1_241174, 1);
            heff_take_n(v_x1_241174, 3ULL, 2);
            switch (heff_tag_of(v_x11_241175)) {
            case TAG_Left: {
              V v_e_241177 = heff_field(v_x11_241175, 0);
              heff_take_n(v_x11_241175, 1ULL, 1);
              heff_drop_rec(v_r_240, 3);
              heff_drop_rec(v_kw_24778, 9);
              heff_drop(v_b_24783);
              heff_drop(v_x_241172);
              return heff_tag_at_n(v_ru_24x1_241168_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241177}), v_st_241176});
            }
            case TAG_Right: {
              V v_x_241178 = heff_field(v_x11_241175, 0);
              heff_take_n(v_x11_241175, 1ULL, 1);
              V v_m_241179 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_b_24783)}));
              V v_x1_241180 = heff_tr(heff_call(v_m_241179, 1, (V[]){v_st_241176}));
              switch (heff_tag_of(v_x1_241180)) {
              case TAG_MkPair: {
                V v_x11_241181 = heff_field(v_x1_241180, 0);
                V v_st_241182 = heff_field(v_x1_241180, 1);
                heff_take_n(v_x1_241180, 3ULL, 2);
                switch (heff_tag_of(v_x11_241181)) {
                case TAG_Left: {
                  V v_e_241183 = heff_field(v_x11_241181, 0);
                  heff_take_n(v_x11_241181, 1ULL, 1);
                  heff_drop_rec(v_kw_24778, 9);
                  heff_drop(v_b_24783);
                  heff_drop(v_x_241172);
                  heff_drop(v_x_241178);
                  return heff_tag_at_n(v_ru_24x1_241168_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241183}), v_st_241182});
                }
                case TAG_Right: {
                  V v_x_241184 = heff_field(v_x11_241181, 0);
                  heff_take_n(v_x11_241181, 1ULL, 1);
                  V v_t_241185 = (g_heff_2esyntax_2ecst_2elastE(v_b_24783));
                  V v_e_241186 = heff_get_n(v_t_241185, 4, 9);
                  V v_t_241187 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_24778, 3, 9), v_e_241186});
                  V v_x_241188 = (g_heff_2esyntax_2esurface_2eifE(v_t_241187, v_x_241172, v_x_241178, v_x_241184));
                  return heff_tag_at_n(v_ru_24x1_241168_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_241188}), v_st_241182});
                }
                default: return heff_nomatch(v_x11_241181);
                }
              }
              default: return heff_nomatch(v_x1_241180);
              }
            }
            default: return heff_nomatch(v_x11_241175);
            }
          }
          default: return heff_nomatch(v_x1_241174);
          }
        }
        default: return heff_nomatch(v_x11_241169);
        }
      }
      default: return heff_nomatch(v_x1_241168);
      }
    }
    case TAG_Op: {
      V v_m_241192 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_24779}));
      V v_x1_241193 = heff_tr(heff_call(v_m_241192, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_241193)) {
      case TAG_MkPair: {
        V v_x11_241194 = heff_field(v_x1_241193, 0);
        V v_st_241195 = heff_field(v_x1_241193, 1);
        V v_ru_24x1_241193_24MkPair = heff_take_reuse_n(v_x1_241193, 3ULL, 2);
        switch (heff_tag_of(v_x11_241194)) {
        case TAG_Left: {
          V v_e_241196 = heff_field(v_x11_241194, 0);
          heff_take_n(v_x11_241194, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_24778, 9);
          heff_drop(v_a_24781);
          heff_drop(v_b_24783);
          return heff_tag_at_n(v_ru_24x1_241193_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241196}), v_st_241195});
        }
        case TAG_Right: {
          V v_x_241197 = heff_field(v_x11_241194, 0);
          heff_take_n(v_x11_241194, 1ULL, 1);
          V v_m_241198 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_24781}));
          V v_x1_241199 = heff_tr(heff_call(v_m_241198, 1, (V[]){v_st_241195}));
          switch (heff_tag_of(v_x1_241199)) {
          case TAG_MkPair: {
            V v_x11_241200 = heff_field(v_x1_241199, 0);
            V v_st_241201 = heff_field(v_x1_241199, 1);
            heff_take_n(v_x1_241199, 3ULL, 2);
            switch (heff_tag_of(v_x11_241200)) {
            case TAG_Left: {
              V v_e_241202 = heff_field(v_x11_241200, 0);
              heff_take_n(v_x11_241200, 1ULL, 1);
              heff_drop_rec(v_r_240, 3);
              heff_drop_rec(v_kw_24778, 9);
              heff_drop(v_b_24783);
              heff_drop(v_x_241197);
              return heff_tag_at_n(v_ru_24x1_241193_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241202}), v_st_241201});
            }
            case TAG_Right: {
              V v_x_241203 = heff_field(v_x11_241200, 0);
              heff_take_n(v_x11_241200, 1ULL, 1);
              V v_m_241204 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_b_24783)}));
              V v_x1_241205 = heff_tr(heff_call(v_m_241204, 1, (V[]){v_st_241201}));
              switch (heff_tag_of(v_x1_241205)) {
              case TAG_MkPair: {
                V v_x11_241206 = heff_field(v_x1_241205, 0);
                V v_st_241207 = heff_field(v_x1_241205, 1);
                heff_take_n(v_x1_241205, 3ULL, 2);
                switch (heff_tag_of(v_x11_241206)) {
                case TAG_Left: {
                  V v_e_241208 = heff_field(v_x11_241206, 0);
                  heff_take_n(v_x11_241206, 1ULL, 1);
                  heff_drop_rec(v_kw_24778, 9);
                  heff_drop(v_b_24783);
                  heff_drop(v_x_241197);
                  heff_drop(v_x_241203);
                  return heff_tag_at_n(v_ru_24x1_241193_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241208}), v_st_241207});
                }
                case TAG_Right: {
                  V v_x_241209 = heff_field(v_x11_241206, 0);
                  heff_take_n(v_x11_241206, 1ULL, 1);
                  V v_t_241210 = (g_heff_2esyntax_2ecst_2elastE(v_b_24783));
                  V v_e_241211 = heff_get_n(v_t_241210, 4, 9);
                  V v_t_241212 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_24778, 3, 9), v_e_241211});
                  V v_x_241213 = (g_heff_2esyntax_2esurface_2eifE(v_t_241212, v_x_241197, v_x_241203, v_x_241209));
                  return heff_tag_at_n(v_ru_24x1_241193_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_241213}), v_st_241207});
                }
                default: return heff_nomatch(v_x11_241206);
                }
              }
              default: return heff_nomatch(v_x1_241205);
              }
            }
            default: return heff_nomatch(v_x11_241200);
            }
          }
          default: return heff_nomatch(v_x1_241199);
          }
        }
        default: return heff_nomatch(v_x11_241194);
        }
      }
      default: return heff_nomatch(v_x1_241193);
      }
    }
    case TAG_Ops: {
      V v_m_241216 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_24779}));
      V v_x1_241217 = heff_tr(heff_call(v_m_241216, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_241217)) {
      case TAG_MkPair: {
        V v_x11_241218 = heff_field(v_x1_241217, 0);
        V v_st_241219 = heff_field(v_x1_241217, 1);
        V v_ru_24x1_241217_24MkPair = heff_take_reuse_n(v_x1_241217, 3ULL, 2);
        switch (heff_tag_of(v_x11_241218)) {
        case TAG_Left: {
          V v_e_241220 = heff_field(v_x11_241218, 0);
          heff_take_n(v_x11_241218, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_24778, 9);
          heff_drop(v_a_24781);
          heff_drop(v_b_24783);
          return heff_tag_at_n(v_ru_24x1_241217_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241220}), v_st_241219});
        }
        case TAG_Right: {
          V v_x_241221 = heff_field(v_x11_241218, 0);
          heff_take_n(v_x11_241218, 1ULL, 1);
          V v_m_241222 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_24781}));
          V v_x1_241223 = heff_tr(heff_call(v_m_241222, 1, (V[]){v_st_241219}));
          switch (heff_tag_of(v_x1_241223)) {
          case TAG_MkPair: {
            V v_x11_241224 = heff_field(v_x1_241223, 0);
            V v_st_241225 = heff_field(v_x1_241223, 1);
            heff_take_n(v_x1_241223, 3ULL, 2);
            switch (heff_tag_of(v_x11_241224)) {
            case TAG_Left: {
              V v_e_241226 = heff_field(v_x11_241224, 0);
              heff_take_n(v_x11_241224, 1ULL, 1);
              heff_drop_rec(v_r_240, 3);
              heff_drop_rec(v_kw_24778, 9);
              heff_drop(v_b_24783);
              heff_drop(v_x_241221);
              return heff_tag_at_n(v_ru_24x1_241217_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241226}), v_st_241225});
            }
            case TAG_Right: {
              V v_x_241227 = heff_field(v_x11_241224, 0);
              heff_take_n(v_x11_241224, 1ULL, 1);
              V v_m_241228 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_b_24783)}));
              V v_x1_241229 = heff_tr(heff_call(v_m_241228, 1, (V[]){v_st_241225}));
              switch (heff_tag_of(v_x1_241229)) {
              case TAG_MkPair: {
                V v_x11_241230 = heff_field(v_x1_241229, 0);
                V v_st_241231 = heff_field(v_x1_241229, 1);
                heff_take_n(v_x1_241229, 3ULL, 2);
                switch (heff_tag_of(v_x11_241230)) {
                case TAG_Left: {
                  V v_e_241232 = heff_field(v_x11_241230, 0);
                  heff_take_n(v_x11_241230, 1ULL, 1);
                  heff_drop_rec(v_kw_24778, 9);
                  heff_drop(v_b_24783);
                  heff_drop(v_x_241221);
                  heff_drop(v_x_241227);
                  return heff_tag_at_n(v_ru_24x1_241217_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241232}), v_st_241231});
                }
                case TAG_Right: {
                  V v_x_241233 = heff_field(v_x11_241230, 0);
                  heff_take_n(v_x11_241230, 1ULL, 1);
                  V v_t_241234 = (g_heff_2esyntax_2ecst_2elastE(v_b_24783));
                  V v_e_241235 = heff_get_n(v_t_241234, 4, 9);
                  V v_t_241236 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_24778, 3, 9), v_e_241235});
                  V v_x_241237 = (g_heff_2esyntax_2esurface_2eifE(v_t_241236, v_x_241221, v_x_241227, v_x_241233));
                  return heff_tag_at_n(v_ru_24x1_241217_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_241237}), v_st_241231});
                }
                default: return heff_nomatch(v_x11_241230);
                }
              }
              default: return heff_nomatch(v_x1_241229);
              }
            }
            default: return heff_nomatch(v_x11_241224);
            }
          }
          default: return heff_nomatch(v_x1_241223);
          }
        }
        default: return heff_nomatch(v_x11_241218);
        }
      }
      default: return heff_nomatch(v_x1_241217);
      }
    }
    case TAG_OpRhs: {
      V v_m_241240 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_24779}));
      V v_x1_241241 = heff_tr(heff_call(v_m_241240, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_241241)) {
      case TAG_MkPair: {
        V v_x11_241242 = heff_field(v_x1_241241, 0);
        V v_st_241243 = heff_field(v_x1_241241, 1);
        V v_ru_24x1_241241_24MkPair = heff_take_reuse_n(v_x1_241241, 3ULL, 2);
        switch (heff_tag_of(v_x11_241242)) {
        case TAG_Left: {
          V v_e_241244 = heff_field(v_x11_241242, 0);
          heff_take_n(v_x11_241242, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_24778, 9);
          heff_drop(v_a_24781);
          heff_drop(v_b_24783);
          return heff_tag_at_n(v_ru_24x1_241241_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241244}), v_st_241243});
        }
        case TAG_Right: {
          V v_x_241245 = heff_field(v_x11_241242, 0);
          heff_take_n(v_x11_241242, 1ULL, 1);
          V v_m_241246 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_24781}));
          V v_x1_241247 = heff_tr(heff_call(v_m_241246, 1, (V[]){v_st_241243}));
          switch (heff_tag_of(v_x1_241247)) {
          case TAG_MkPair: {
            V v_x11_241248 = heff_field(v_x1_241247, 0);
            V v_st_241249 = heff_field(v_x1_241247, 1);
            heff_take_n(v_x1_241247, 3ULL, 2);
            switch (heff_tag_of(v_x11_241248)) {
            case TAG_Left: {
              V v_e_241250 = heff_field(v_x11_241248, 0);
              heff_take_n(v_x11_241248, 1ULL, 1);
              heff_drop_rec(v_r_240, 3);
              heff_drop_rec(v_kw_24778, 9);
              heff_drop(v_b_24783);
              heff_drop(v_x_241245);
              return heff_tag_at_n(v_ru_24x1_241241_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241250}), v_st_241249});
            }
            case TAG_Right: {
              V v_x_241251 = heff_field(v_x11_241248, 0);
              heff_take_n(v_x11_241248, 1ULL, 1);
              V v_m_241252 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_b_24783)}));
              V v_x1_241253 = heff_tr(heff_call(v_m_241252, 1, (V[]){v_st_241249}));
              switch (heff_tag_of(v_x1_241253)) {
              case TAG_MkPair: {
                V v_x11_241254 = heff_field(v_x1_241253, 0);
                V v_st_241255 = heff_field(v_x1_241253, 1);
                heff_take_n(v_x1_241253, 3ULL, 2);
                switch (heff_tag_of(v_x11_241254)) {
                case TAG_Left: {
                  V v_e_241256 = heff_field(v_x11_241254, 0);
                  heff_take_n(v_x11_241254, 1ULL, 1);
                  heff_drop_rec(v_kw_24778, 9);
                  heff_drop(v_b_24783);
                  heff_drop(v_x_241245);
                  heff_drop(v_x_241251);
                  return heff_tag_at_n(v_ru_24x1_241241_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241256}), v_st_241255});
                }
                case TAG_Right: {
                  V v_x_241257 = heff_field(v_x11_241254, 0);
                  heff_take_n(v_x11_241254, 1ULL, 1);
                  V v_t_241258 = (g_heff_2esyntax_2ecst_2elastE(v_b_24783));
                  V v_e_241259 = heff_get_n(v_t_241258, 4, 9);
                  V v_t_241260 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_24778, 3, 9), v_e_241259});
                  V v_x_241261 = (g_heff_2esyntax_2esurface_2eifE(v_t_241260, v_x_241245, v_x_241251, v_x_241257));
                  return heff_tag_at_n(v_ru_24x1_241241_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_241261}), v_st_241255});
                }
                default: return heff_nomatch(v_x11_241254);
                }
              }
              default: return heff_nomatch(v_x1_241253);
              }
            }
            default: return heff_nomatch(v_x11_241248);
            }
          }
          default: return heff_nomatch(v_x1_241247);
          }
        }
        default: return heff_nomatch(v_x11_241242);
        }
      }
      default: return heff_nomatch(v_x1_241241);
      }
    }
    case TAG_Ann: {
      V v_m_241265 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_24779}));
      V v_x1_241266 = heff_tr(heff_call(v_m_241265, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_241266)) {
      case TAG_MkPair: {
        V v_x11_241267 = heff_field(v_x1_241266, 0);
        V v_st_241268 = heff_field(v_x1_241266, 1);
        V v_ru_24x1_241266_24MkPair = heff_take_reuse_n(v_x1_241266, 3ULL, 2);
        switch (heff_tag_of(v_x11_241267)) {
        case TAG_Left: {
          V v_e_241269 = heff_field(v_x11_241267, 0);
          heff_take_n(v_x11_241267, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_24778, 9);
          heff_drop(v_a_24781);
          heff_drop(v_b_24783);
          return heff_tag_at_n(v_ru_24x1_241266_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241269}), v_st_241268});
        }
        case TAG_Right: {
          V v_x_241270 = heff_field(v_x11_241267, 0);
          heff_take_n(v_x11_241267, 1ULL, 1);
          V v_m_241271 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_24781}));
          V v_x1_241272 = heff_tr(heff_call(v_m_241271, 1, (V[]){v_st_241268}));
          switch (heff_tag_of(v_x1_241272)) {
          case TAG_MkPair: {
            V v_x11_241273 = heff_field(v_x1_241272, 0);
            V v_st_241274 = heff_field(v_x1_241272, 1);
            heff_take_n(v_x1_241272, 3ULL, 2);
            switch (heff_tag_of(v_x11_241273)) {
            case TAG_Left: {
              V v_e_241275 = heff_field(v_x11_241273, 0);
              heff_take_n(v_x11_241273, 1ULL, 1);
              heff_drop_rec(v_r_240, 3);
              heff_drop_rec(v_kw_24778, 9);
              heff_drop(v_b_24783);
              heff_drop(v_x_241270);
              return heff_tag_at_n(v_ru_24x1_241266_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241275}), v_st_241274});
            }
            case TAG_Right: {
              V v_x_241276 = heff_field(v_x11_241273, 0);
              heff_take_n(v_x11_241273, 1ULL, 1);
              V v_m_241277 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_b_24783)}));
              V v_x1_241278 = heff_tr(heff_call(v_m_241277, 1, (V[]){v_st_241274}));
              switch (heff_tag_of(v_x1_241278)) {
              case TAG_MkPair: {
                V v_x11_241279 = heff_field(v_x1_241278, 0);
                V v_st_241280 = heff_field(v_x1_241278, 1);
                heff_take_n(v_x1_241278, 3ULL, 2);
                switch (heff_tag_of(v_x11_241279)) {
                case TAG_Left: {
                  V v_e_241281 = heff_field(v_x11_241279, 0);
                  heff_take_n(v_x11_241279, 1ULL, 1);
                  heff_drop_rec(v_kw_24778, 9);
                  heff_drop(v_b_24783);
                  heff_drop(v_x_241270);
                  heff_drop(v_x_241276);
                  return heff_tag_at_n(v_ru_24x1_241266_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241281}), v_st_241280});
                }
                case TAG_Right: {
                  V v_x_241282 = heff_field(v_x11_241279, 0);
                  heff_take_n(v_x11_241279, 1ULL, 1);
                  V v_t_241283 = (g_heff_2esyntax_2ecst_2elastE(v_b_24783));
                  V v_e_241284 = heff_get_n(v_t_241283, 4, 9);
                  V v_t_241285 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_24778, 3, 9), v_e_241284});
                  V v_x_241286 = (g_heff_2esyntax_2esurface_2eifE(v_t_241285, v_x_241270, v_x_241276, v_x_241282));
                  return heff_tag_at_n(v_ru_24x1_241266_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_241286}), v_st_241280});
                }
                default: return heff_nomatch(v_x11_241279);
                }
              }
              default: return heff_nomatch(v_x1_241278);
              }
            }
            default: return heff_nomatch(v_x11_241273);
            }
          }
          default: return heff_nomatch(v_x1_241272);
          }
        }
        default: return heff_nomatch(v_x11_241267);
        }
      }
      default: return heff_nomatch(v_x1_241266);
      }
    }
    case TAG_BVar: {
      V v_m_241288 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_24779}));
      V v_x1_241289 = heff_tr(heff_call(v_m_241288, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_241289)) {
      case TAG_MkPair: {
        V v_x11_241290 = heff_field(v_x1_241289, 0);
        V v_st_241291 = heff_field(v_x1_241289, 1);
        V v_ru_24x1_241289_24MkPair = heff_take_reuse_n(v_x1_241289, 3ULL, 2);
        switch (heff_tag_of(v_x11_241290)) {
        case TAG_Left: {
          V v_e_241292 = heff_field(v_x11_241290, 0);
          heff_take_n(v_x11_241290, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_24778, 9);
          heff_drop(v_a_24781);
          heff_drop(v_b_24783);
          return heff_tag_at_n(v_ru_24x1_241289_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241292}), v_st_241291});
        }
        case TAG_Right: {
          V v_x_241293 = heff_field(v_x11_241290, 0);
          heff_take_n(v_x11_241290, 1ULL, 1);
          V v_m_241294 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_24781}));
          V v_x1_241295 = heff_tr(heff_call(v_m_241294, 1, (V[]){v_st_241291}));
          switch (heff_tag_of(v_x1_241295)) {
          case TAG_MkPair: {
            V v_x11_241296 = heff_field(v_x1_241295, 0);
            V v_st_241297 = heff_field(v_x1_241295, 1);
            heff_take_n(v_x1_241295, 3ULL, 2);
            switch (heff_tag_of(v_x11_241296)) {
            case TAG_Left: {
              V v_e_241298 = heff_field(v_x11_241296, 0);
              heff_take_n(v_x11_241296, 1ULL, 1);
              heff_drop_rec(v_r_240, 3);
              heff_drop_rec(v_kw_24778, 9);
              heff_drop(v_b_24783);
              heff_drop(v_x_241293);
              return heff_tag_at_n(v_ru_24x1_241289_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241298}), v_st_241297});
            }
            case TAG_Right: {
              V v_x_241299 = heff_field(v_x11_241296, 0);
              heff_take_n(v_x11_241296, 1ULL, 1);
              V v_m_241300 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_b_24783)}));
              V v_x1_241301 = heff_tr(heff_call(v_m_241300, 1, (V[]){v_st_241297}));
              switch (heff_tag_of(v_x1_241301)) {
              case TAG_MkPair: {
                V v_x11_241302 = heff_field(v_x1_241301, 0);
                V v_st_241303 = heff_field(v_x1_241301, 1);
                heff_take_n(v_x1_241301, 3ULL, 2);
                switch (heff_tag_of(v_x11_241302)) {
                case TAG_Left: {
                  V v_e_241304 = heff_field(v_x11_241302, 0);
                  heff_take_n(v_x11_241302, 1ULL, 1);
                  heff_drop_rec(v_kw_24778, 9);
                  heff_drop(v_b_24783);
                  heff_drop(v_x_241293);
                  heff_drop(v_x_241299);
                  return heff_tag_at_n(v_ru_24x1_241289_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241304}), v_st_241303});
                }
                case TAG_Right: {
                  V v_x_241305 = heff_field(v_x11_241302, 0);
                  heff_take_n(v_x11_241302, 1ULL, 1);
                  V v_t_241306 = (g_heff_2esyntax_2ecst_2elastE(v_b_24783));
                  V v_e_241307 = heff_get_n(v_t_241306, 4, 9);
                  V v_t_241308 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_24778, 3, 9), v_e_241307});
                  V v_x_241309 = (g_heff_2esyntax_2esurface_2eifE(v_t_241308, v_x_241293, v_x_241299, v_x_241305));
                  return heff_tag_at_n(v_ru_24x1_241289_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_241309}), v_st_241303});
                }
                default: return heff_nomatch(v_x11_241302);
                }
              }
              default: return heff_nomatch(v_x1_241301);
              }
            }
            default: return heff_nomatch(v_x11_241296);
            }
          }
          default: return heff_nomatch(v_x1_241295);
          }
        }
        default: return heff_nomatch(v_x11_241290);
        }
      }
      default: return heff_nomatch(v_x1_241289);
      }
    }
    case TAG_BImp: {
      V v_m_241313 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_24779}));
      V v_x1_241314 = heff_tr(heff_call(v_m_241313, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_241314)) {
      case TAG_MkPair: {
        V v_x11_241315 = heff_field(v_x1_241314, 0);
        V v_st_241316 = heff_field(v_x1_241314, 1);
        V v_ru_24x1_241314_24MkPair = heff_take_reuse_n(v_x1_241314, 3ULL, 2);
        switch (heff_tag_of(v_x11_241315)) {
        case TAG_Left: {
          V v_e_241317 = heff_field(v_x11_241315, 0);
          heff_take_n(v_x11_241315, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_24778, 9);
          heff_drop(v_a_24781);
          heff_drop(v_b_24783);
          return heff_tag_at_n(v_ru_24x1_241314_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241317}), v_st_241316});
        }
        case TAG_Right: {
          V v_x_241318 = heff_field(v_x11_241315, 0);
          heff_take_n(v_x11_241315, 1ULL, 1);
          V v_m_241319 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_24781}));
          V v_x1_241320 = heff_tr(heff_call(v_m_241319, 1, (V[]){v_st_241316}));
          switch (heff_tag_of(v_x1_241320)) {
          case TAG_MkPair: {
            V v_x11_241321 = heff_field(v_x1_241320, 0);
            V v_st_241322 = heff_field(v_x1_241320, 1);
            heff_take_n(v_x1_241320, 3ULL, 2);
            switch (heff_tag_of(v_x11_241321)) {
            case TAG_Left: {
              V v_e_241323 = heff_field(v_x11_241321, 0);
              heff_take_n(v_x11_241321, 1ULL, 1);
              heff_drop_rec(v_r_240, 3);
              heff_drop_rec(v_kw_24778, 9);
              heff_drop(v_b_24783);
              heff_drop(v_x_241318);
              return heff_tag_at_n(v_ru_24x1_241314_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241323}), v_st_241322});
            }
            case TAG_Right: {
              V v_x_241324 = heff_field(v_x11_241321, 0);
              heff_take_n(v_x11_241321, 1ULL, 1);
              V v_m_241325 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_b_24783)}));
              V v_x1_241326 = heff_tr(heff_call(v_m_241325, 1, (V[]){v_st_241322}));
              switch (heff_tag_of(v_x1_241326)) {
              case TAG_MkPair: {
                V v_x11_241327 = heff_field(v_x1_241326, 0);
                V v_st_241328 = heff_field(v_x1_241326, 1);
                heff_take_n(v_x1_241326, 3ULL, 2);
                switch (heff_tag_of(v_x11_241327)) {
                case TAG_Left: {
                  V v_e_241329 = heff_field(v_x11_241327, 0);
                  heff_take_n(v_x11_241327, 1ULL, 1);
                  heff_drop_rec(v_kw_24778, 9);
                  heff_drop(v_b_24783);
                  heff_drop(v_x_241318);
                  heff_drop(v_x_241324);
                  return heff_tag_at_n(v_ru_24x1_241314_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241329}), v_st_241328});
                }
                case TAG_Right: {
                  V v_x_241330 = heff_field(v_x11_241327, 0);
                  heff_take_n(v_x11_241327, 1ULL, 1);
                  V v_t_241331 = (g_heff_2esyntax_2ecst_2elastE(v_b_24783));
                  V v_e_241332 = heff_get_n(v_t_241331, 4, 9);
                  V v_t_241333 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_24778, 3, 9), v_e_241332});
                  V v_x_241334 = (g_heff_2esyntax_2esurface_2eifE(v_t_241333, v_x_241318, v_x_241324, v_x_241330));
                  return heff_tag_at_n(v_ru_24x1_241314_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_241334}), v_st_241328});
                }
                default: return heff_nomatch(v_x11_241327);
                }
              }
              default: return heff_nomatch(v_x1_241326);
              }
            }
            default: return heff_nomatch(v_x11_241321);
            }
          }
          default: return heff_nomatch(v_x1_241320);
          }
        }
        default: return heff_nomatch(v_x11_241315);
        }
      }
      default: return heff_nomatch(v_x1_241314);
      }
    }
    case TAG_BAnn: {
      V v_m_241340 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_24779}));
      V v_x1_241341 = heff_tr(heff_call(v_m_241340, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_241341)) {
      case TAG_MkPair: {
        V v_x11_241342 = heff_field(v_x1_241341, 0);
        V v_st_241343 = heff_field(v_x1_241341, 1);
        V v_ru_24x1_241341_24MkPair = heff_take_reuse_n(v_x1_241341, 3ULL, 2);
        switch (heff_tag_of(v_x11_241342)) {
        case TAG_Left: {
          V v_e_241344 = heff_field(v_x11_241342, 0);
          heff_take_n(v_x11_241342, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_24778, 9);
          heff_drop(v_a_24781);
          heff_drop(v_b_24783);
          return heff_tag_at_n(v_ru_24x1_241341_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241344}), v_st_241343});
        }
        case TAG_Right: {
          V v_x_241345 = heff_field(v_x11_241342, 0);
          heff_take_n(v_x11_241342, 1ULL, 1);
          V v_m_241346 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_24781}));
          V v_x1_241347 = heff_tr(heff_call(v_m_241346, 1, (V[]){v_st_241343}));
          switch (heff_tag_of(v_x1_241347)) {
          case TAG_MkPair: {
            V v_x11_241348 = heff_field(v_x1_241347, 0);
            V v_st_241349 = heff_field(v_x1_241347, 1);
            heff_take_n(v_x1_241347, 3ULL, 2);
            switch (heff_tag_of(v_x11_241348)) {
            case TAG_Left: {
              V v_e_241350 = heff_field(v_x11_241348, 0);
              heff_take_n(v_x11_241348, 1ULL, 1);
              heff_drop_rec(v_r_240, 3);
              heff_drop_rec(v_kw_24778, 9);
              heff_drop(v_b_24783);
              heff_drop(v_x_241345);
              return heff_tag_at_n(v_ru_24x1_241341_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241350}), v_st_241349});
            }
            case TAG_Right: {
              V v_x_241351 = heff_field(v_x11_241348, 0);
              heff_take_n(v_x11_241348, 1ULL, 1);
              V v_m_241352 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_b_24783)}));
              V v_x1_241353 = heff_tr(heff_call(v_m_241352, 1, (V[]){v_st_241349}));
              switch (heff_tag_of(v_x1_241353)) {
              case TAG_MkPair: {
                V v_x11_241354 = heff_field(v_x1_241353, 0);
                V v_st_241355 = heff_field(v_x1_241353, 1);
                heff_take_n(v_x1_241353, 3ULL, 2);
                switch (heff_tag_of(v_x11_241354)) {
                case TAG_Left: {
                  V v_e_241356 = heff_field(v_x11_241354, 0);
                  heff_take_n(v_x11_241354, 1ULL, 1);
                  heff_drop_rec(v_kw_24778, 9);
                  heff_drop(v_b_24783);
                  heff_drop(v_x_241345);
                  heff_drop(v_x_241351);
                  return heff_tag_at_n(v_ru_24x1_241341_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241356}), v_st_241355});
                }
                case TAG_Right: {
                  V v_x_241357 = heff_field(v_x11_241354, 0);
                  heff_take_n(v_x11_241354, 1ULL, 1);
                  V v_t_241358 = (g_heff_2esyntax_2ecst_2elastE(v_b_24783));
                  V v_e_241359 = heff_get_n(v_t_241358, 4, 9);
                  V v_t_241360 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_24778, 3, 9), v_e_241359});
                  V v_x_241361 = (g_heff_2esyntax_2esurface_2eifE(v_t_241360, v_x_241345, v_x_241351, v_x_241357));
                  return heff_tag_at_n(v_ru_24x1_241341_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_241361}), v_st_241355});
                }
                default: return heff_nomatch(v_x11_241354);
                }
              }
              default: return heff_nomatch(v_x1_241353);
              }
            }
            default: return heff_nomatch(v_x11_241348);
            }
          }
          default: return heff_nomatch(v_x1_241347);
          }
        }
        default: return heff_nomatch(v_x11_241342);
        }
      }
      default: return heff_nomatch(v_x1_241341);
      }
    }
    case TAG_Lam: {
      V v_m_241366 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_24779}));
      V v_x1_241367 = heff_tr(heff_call(v_m_241366, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_241367)) {
      case TAG_MkPair: {
        V v_x11_241368 = heff_field(v_x1_241367, 0);
        V v_st_241369 = heff_field(v_x1_241367, 1);
        V v_ru_24x1_241367_24MkPair = heff_take_reuse_n(v_x1_241367, 3ULL, 2);
        switch (heff_tag_of(v_x11_241368)) {
        case TAG_Left: {
          V v_e_241370 = heff_field(v_x11_241368, 0);
          heff_take_n(v_x11_241368, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_24778, 9);
          heff_drop(v_a_24781);
          heff_drop(v_b_24783);
          return heff_tag_at_n(v_ru_24x1_241367_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241370}), v_st_241369});
        }
        case TAG_Right: {
          V v_x_241371 = heff_field(v_x11_241368, 0);
          heff_take_n(v_x11_241368, 1ULL, 1);
          V v_m_241372 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_24781}));
          V v_x1_241373 = heff_tr(heff_call(v_m_241372, 1, (V[]){v_st_241369}));
          switch (heff_tag_of(v_x1_241373)) {
          case TAG_MkPair: {
            V v_x11_241374 = heff_field(v_x1_241373, 0);
            V v_st_241375 = heff_field(v_x1_241373, 1);
            heff_take_n(v_x1_241373, 3ULL, 2);
            switch (heff_tag_of(v_x11_241374)) {
            case TAG_Left: {
              V v_e_241376 = heff_field(v_x11_241374, 0);
              heff_take_n(v_x11_241374, 1ULL, 1);
              heff_drop_rec(v_r_240, 3);
              heff_drop_rec(v_kw_24778, 9);
              heff_drop(v_b_24783);
              heff_drop(v_x_241371);
              return heff_tag_at_n(v_ru_24x1_241367_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241376}), v_st_241375});
            }
            case TAG_Right: {
              V v_x_241377 = heff_field(v_x11_241374, 0);
              heff_take_n(v_x11_241374, 1ULL, 1);
              V v_m_241378 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_b_24783)}));
              V v_x1_241379 = heff_tr(heff_call(v_m_241378, 1, (V[]){v_st_241375}));
              switch (heff_tag_of(v_x1_241379)) {
              case TAG_MkPair: {
                V v_x11_241380 = heff_field(v_x1_241379, 0);
                V v_st_241381 = heff_field(v_x1_241379, 1);
                heff_take_n(v_x1_241379, 3ULL, 2);
                switch (heff_tag_of(v_x11_241380)) {
                case TAG_Left: {
                  V v_e_241382 = heff_field(v_x11_241380, 0);
                  heff_take_n(v_x11_241380, 1ULL, 1);
                  heff_drop_rec(v_kw_24778, 9);
                  heff_drop(v_b_24783);
                  heff_drop(v_x_241371);
                  heff_drop(v_x_241377);
                  return heff_tag_at_n(v_ru_24x1_241367_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241382}), v_st_241381});
                }
                case TAG_Right: {
                  V v_x_241383 = heff_field(v_x11_241380, 0);
                  heff_take_n(v_x11_241380, 1ULL, 1);
                  V v_t_241384 = (g_heff_2esyntax_2ecst_2elastE(v_b_24783));
                  V v_e_241385 = heff_get_n(v_t_241384, 4, 9);
                  V v_t_241386 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_24778, 3, 9), v_e_241385});
                  V v_x_241387 = (g_heff_2esyntax_2esurface_2eifE(v_t_241386, v_x_241371, v_x_241377, v_x_241383));
                  return heff_tag_at_n(v_ru_24x1_241367_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_241387}), v_st_241381});
                }
                default: return heff_nomatch(v_x11_241380);
                }
              }
              default: return heff_nomatch(v_x1_241379);
              }
            }
            default: return heff_nomatch(v_x11_241374);
            }
          }
          default: return heff_nomatch(v_x1_241373);
          }
        }
        default: return heff_nomatch(v_x11_241368);
        }
      }
      default: return heff_nomatch(v_x1_241367);
      }
    }
    case TAG_Case: {
      V v_m_241392 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_24779}));
      V v_x1_241393 = heff_tr(heff_call(v_m_241392, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_241393)) {
      case TAG_MkPair: {
        V v_x11_241394 = heff_field(v_x1_241393, 0);
        V v_st_241395 = heff_field(v_x1_241393, 1);
        V v_ru_24x1_241393_24MkPair = heff_take_reuse_n(v_x1_241393, 3ULL, 2);
        switch (heff_tag_of(v_x11_241394)) {
        case TAG_Left: {
          V v_e_241396 = heff_field(v_x11_241394, 0);
          heff_take_n(v_x11_241394, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_24778, 9);
          heff_drop(v_a_24781);
          heff_drop(v_b_24783);
          return heff_tag_at_n(v_ru_24x1_241393_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241396}), v_st_241395});
        }
        case TAG_Right: {
          V v_x_241397 = heff_field(v_x11_241394, 0);
          heff_take_n(v_x11_241394, 1ULL, 1);
          V v_m_241398 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_24781}));
          V v_x1_241399 = heff_tr(heff_call(v_m_241398, 1, (V[]){v_st_241395}));
          switch (heff_tag_of(v_x1_241399)) {
          case TAG_MkPair: {
            V v_x11_241400 = heff_field(v_x1_241399, 0);
            V v_st_241401 = heff_field(v_x1_241399, 1);
            heff_take_n(v_x1_241399, 3ULL, 2);
            switch (heff_tag_of(v_x11_241400)) {
            case TAG_Left: {
              V v_e_241402 = heff_field(v_x11_241400, 0);
              heff_take_n(v_x11_241400, 1ULL, 1);
              heff_drop_rec(v_r_240, 3);
              heff_drop_rec(v_kw_24778, 9);
              heff_drop(v_b_24783);
              heff_drop(v_x_241397);
              return heff_tag_at_n(v_ru_24x1_241393_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241402}), v_st_241401});
            }
            case TAG_Right: {
              V v_x_241403 = heff_field(v_x11_241400, 0);
              heff_take_n(v_x11_241400, 1ULL, 1);
              V v_m_241404 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_b_24783)}));
              V v_x1_241405 = heff_tr(heff_call(v_m_241404, 1, (V[]){v_st_241401}));
              switch (heff_tag_of(v_x1_241405)) {
              case TAG_MkPair: {
                V v_x11_241406 = heff_field(v_x1_241405, 0);
                V v_st_241407 = heff_field(v_x1_241405, 1);
                heff_take_n(v_x1_241405, 3ULL, 2);
                switch (heff_tag_of(v_x11_241406)) {
                case TAG_Left: {
                  V v_e_241408 = heff_field(v_x11_241406, 0);
                  heff_take_n(v_x11_241406, 1ULL, 1);
                  heff_drop_rec(v_kw_24778, 9);
                  heff_drop(v_b_24783);
                  heff_drop(v_x_241397);
                  heff_drop(v_x_241403);
                  return heff_tag_at_n(v_ru_24x1_241393_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241408}), v_st_241407});
                }
                case TAG_Right: {
                  V v_x_241409 = heff_field(v_x11_241406, 0);
                  heff_take_n(v_x11_241406, 1ULL, 1);
                  V v_t_241410 = (g_heff_2esyntax_2ecst_2elastE(v_b_24783));
                  V v_e_241411 = heff_get_n(v_t_241410, 4, 9);
                  V v_t_241412 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_24778, 3, 9), v_e_241411});
                  V v_x_241413 = (g_heff_2esyntax_2esurface_2eifE(v_t_241412, v_x_241397, v_x_241403, v_x_241409));
                  return heff_tag_at_n(v_ru_24x1_241393_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_241413}), v_st_241407});
                }
                default: return heff_nomatch(v_x11_241406);
                }
              }
              default: return heff_nomatch(v_x1_241405);
              }
            }
            default: return heff_nomatch(v_x11_241400);
            }
          }
          default: return heff_nomatch(v_x1_241399);
          }
        }
        default: return heff_nomatch(v_x11_241394);
        }
      }
      default: return heff_nomatch(v_x1_241393);
      }
    }
    case TAG_EAlt: {
      V v_m_241417 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_24779}));
      V v_x1_241418 = heff_tr(heff_call(v_m_241417, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_241418)) {
      case TAG_MkPair: {
        V v_x11_241419 = heff_field(v_x1_241418, 0);
        V v_st_241420 = heff_field(v_x1_241418, 1);
        V v_ru_24x1_241418_24MkPair = heff_take_reuse_n(v_x1_241418, 3ULL, 2);
        switch (heff_tag_of(v_x11_241419)) {
        case TAG_Left: {
          V v_e_241421 = heff_field(v_x11_241419, 0);
          heff_take_n(v_x11_241419, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_24778, 9);
          heff_drop(v_a_24781);
          heff_drop(v_b_24783);
          return heff_tag_at_n(v_ru_24x1_241418_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241421}), v_st_241420});
        }
        case TAG_Right: {
          V v_x_241422 = heff_field(v_x11_241419, 0);
          heff_take_n(v_x11_241419, 1ULL, 1);
          V v_m_241423 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_24781}));
          V v_x1_241424 = heff_tr(heff_call(v_m_241423, 1, (V[]){v_st_241420}));
          switch (heff_tag_of(v_x1_241424)) {
          case TAG_MkPair: {
            V v_x11_241425 = heff_field(v_x1_241424, 0);
            V v_st_241426 = heff_field(v_x1_241424, 1);
            heff_take_n(v_x1_241424, 3ULL, 2);
            switch (heff_tag_of(v_x11_241425)) {
            case TAG_Left: {
              V v_e_241427 = heff_field(v_x11_241425, 0);
              heff_take_n(v_x11_241425, 1ULL, 1);
              heff_drop_rec(v_r_240, 3);
              heff_drop_rec(v_kw_24778, 9);
              heff_drop(v_b_24783);
              heff_drop(v_x_241422);
              return heff_tag_at_n(v_ru_24x1_241418_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241427}), v_st_241426});
            }
            case TAG_Right: {
              V v_x_241428 = heff_field(v_x11_241425, 0);
              heff_take_n(v_x11_241425, 1ULL, 1);
              V v_m_241429 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_b_24783)}));
              V v_x1_241430 = heff_tr(heff_call(v_m_241429, 1, (V[]){v_st_241426}));
              switch (heff_tag_of(v_x1_241430)) {
              case TAG_MkPair: {
                V v_x11_241431 = heff_field(v_x1_241430, 0);
                V v_st_241432 = heff_field(v_x1_241430, 1);
                heff_take_n(v_x1_241430, 3ULL, 2);
                switch (heff_tag_of(v_x11_241431)) {
                case TAG_Left: {
                  V v_e_241433 = heff_field(v_x11_241431, 0);
                  heff_take_n(v_x11_241431, 1ULL, 1);
                  heff_drop_rec(v_kw_24778, 9);
                  heff_drop(v_b_24783);
                  heff_drop(v_x_241422);
                  heff_drop(v_x_241428);
                  return heff_tag_at_n(v_ru_24x1_241418_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241433}), v_st_241432});
                }
                case TAG_Right: {
                  V v_x_241434 = heff_field(v_x11_241431, 0);
                  heff_take_n(v_x11_241431, 1ULL, 1);
                  V v_t_241435 = (g_heff_2esyntax_2ecst_2elastE(v_b_24783));
                  V v_e_241436 = heff_get_n(v_t_241435, 4, 9);
                  V v_t_241437 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_24778, 3, 9), v_e_241436});
                  V v_x_241438 = (g_heff_2esyntax_2esurface_2eifE(v_t_241437, v_x_241422, v_x_241428, v_x_241434));
                  return heff_tag_at_n(v_ru_24x1_241418_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_241438}), v_st_241432});
                }
                default: return heff_nomatch(v_x11_241431);
                }
              }
              default: return heff_nomatch(v_x1_241430);
              }
            }
            default: return heff_nomatch(v_x11_241425);
            }
          }
          default: return heff_nomatch(v_x1_241424);
          }
        }
        default: return heff_nomatch(v_x11_241419);
        }
      }
      default: return heff_nomatch(v_x1_241418);
      }
    }
    case TAG_If: {
      V v_m_241445 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_24779}));
      V v_x1_241446 = heff_tr(heff_call(v_m_241445, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_241446)) {
      case TAG_MkPair: {
        V v_x11_241447 = heff_field(v_x1_241446, 0);
        V v_st_241448 = heff_field(v_x1_241446, 1);
        V v_ru_24x1_241446_24MkPair = heff_take_reuse_n(v_x1_241446, 3ULL, 2);
        switch (heff_tag_of(v_x11_241447)) {
        case TAG_Left: {
          V v_e_241449 = heff_field(v_x11_241447, 0);
          heff_take_n(v_x11_241447, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_24778, 9);
          heff_drop(v_a_24781);
          heff_drop(v_b_24783);
          return heff_tag_at_n(v_ru_24x1_241446_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241449}), v_st_241448});
        }
        case TAG_Right: {
          V v_x_241450 = heff_field(v_x11_241447, 0);
          heff_take_n(v_x11_241447, 1ULL, 1);
          V v_m_241451 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_24781}));
          V v_x1_241452 = heff_tr(heff_call(v_m_241451, 1, (V[]){v_st_241448}));
          switch (heff_tag_of(v_x1_241452)) {
          case TAG_MkPair: {
            V v_x11_241453 = heff_field(v_x1_241452, 0);
            V v_st_241454 = heff_field(v_x1_241452, 1);
            heff_take_n(v_x1_241452, 3ULL, 2);
            switch (heff_tag_of(v_x11_241453)) {
            case TAG_Left: {
              V v_e_241455 = heff_field(v_x11_241453, 0);
              heff_take_n(v_x11_241453, 1ULL, 1);
              heff_drop_rec(v_r_240, 3);
              heff_drop_rec(v_kw_24778, 9);
              heff_drop(v_b_24783);
              heff_drop(v_x_241450);
              return heff_tag_at_n(v_ru_24x1_241446_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241455}), v_st_241454});
            }
            case TAG_Right: {
              V v_x_241456 = heff_field(v_x11_241453, 0);
              heff_take_n(v_x11_241453, 1ULL, 1);
              V v_m_241457 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_b_24783)}));
              V v_x1_241458 = heff_tr(heff_call(v_m_241457, 1, (V[]){v_st_241454}));
              switch (heff_tag_of(v_x1_241458)) {
              case TAG_MkPair: {
                V v_x11_241459 = heff_field(v_x1_241458, 0);
                V v_st_241460 = heff_field(v_x1_241458, 1);
                heff_take_n(v_x1_241458, 3ULL, 2);
                switch (heff_tag_of(v_x11_241459)) {
                case TAG_Left: {
                  V v_e_241461 = heff_field(v_x11_241459, 0);
                  heff_take_n(v_x11_241459, 1ULL, 1);
                  heff_drop_rec(v_kw_24778, 9);
                  heff_drop(v_b_24783);
                  heff_drop(v_x_241450);
                  heff_drop(v_x_241456);
                  return heff_tag_at_n(v_ru_24x1_241446_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241461}), v_st_241460});
                }
                case TAG_Right: {
                  V v_x_241462 = heff_field(v_x11_241459, 0);
                  heff_take_n(v_x11_241459, 1ULL, 1);
                  V v_t_241463 = (g_heff_2esyntax_2ecst_2elastE(v_b_24783));
                  V v_e_241464 = heff_get_n(v_t_241463, 4, 9);
                  V v_t_241465 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_24778, 3, 9), v_e_241464});
                  V v_x_241466 = (g_heff_2esyntax_2esurface_2eifE(v_t_241465, v_x_241450, v_x_241456, v_x_241462));
                  return heff_tag_at_n(v_ru_24x1_241446_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_241466}), v_st_241460});
                }
                default: return heff_nomatch(v_x11_241459);
                }
              }
              default: return heff_nomatch(v_x1_241458);
              }
            }
            default: return heff_nomatch(v_x11_241453);
            }
          }
          default: return heff_nomatch(v_x1_241452);
          }
        }
        default: return heff_nomatch(v_x11_241447);
        }
      }
      default: return heff_nomatch(v_x1_241446);
      }
    }
    case TAG_Do: {
      V v_m_241469 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_24779}));
      V v_x1_241470 = heff_tr(heff_call(v_m_241469, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_241470)) {
      case TAG_MkPair: {
        V v_x11_241471 = heff_field(v_x1_241470, 0);
        V v_st_241472 = heff_field(v_x1_241470, 1);
        V v_ru_24x1_241470_24MkPair = heff_take_reuse_n(v_x1_241470, 3ULL, 2);
        switch (heff_tag_of(v_x11_241471)) {
        case TAG_Left: {
          V v_e_241473 = heff_field(v_x11_241471, 0);
          heff_take_n(v_x11_241471, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_24778, 9);
          heff_drop(v_a_24781);
          heff_drop(v_b_24783);
          return heff_tag_at_n(v_ru_24x1_241470_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241473}), v_st_241472});
        }
        case TAG_Right: {
          V v_x_241474 = heff_field(v_x11_241471, 0);
          heff_take_n(v_x11_241471, 1ULL, 1);
          V v_m_241475 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_24781}));
          V v_x1_241476 = heff_tr(heff_call(v_m_241475, 1, (V[]){v_st_241472}));
          switch (heff_tag_of(v_x1_241476)) {
          case TAG_MkPair: {
            V v_x11_241477 = heff_field(v_x1_241476, 0);
            V v_st_241478 = heff_field(v_x1_241476, 1);
            heff_take_n(v_x1_241476, 3ULL, 2);
            switch (heff_tag_of(v_x11_241477)) {
            case TAG_Left: {
              V v_e_241479 = heff_field(v_x11_241477, 0);
              heff_take_n(v_x11_241477, 1ULL, 1);
              heff_drop_rec(v_r_240, 3);
              heff_drop_rec(v_kw_24778, 9);
              heff_drop(v_b_24783);
              heff_drop(v_x_241474);
              return heff_tag_at_n(v_ru_24x1_241470_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241479}), v_st_241478});
            }
            case TAG_Right: {
              V v_x_241480 = heff_field(v_x11_241477, 0);
              heff_take_n(v_x11_241477, 1ULL, 1);
              V v_m_241481 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_b_24783)}));
              V v_x1_241482 = heff_tr(heff_call(v_m_241481, 1, (V[]){v_st_241478}));
              switch (heff_tag_of(v_x1_241482)) {
              case TAG_MkPair: {
                V v_x11_241483 = heff_field(v_x1_241482, 0);
                V v_st_241484 = heff_field(v_x1_241482, 1);
                heff_take_n(v_x1_241482, 3ULL, 2);
                switch (heff_tag_of(v_x11_241483)) {
                case TAG_Left: {
                  V v_e_241485 = heff_field(v_x11_241483, 0);
                  heff_take_n(v_x11_241483, 1ULL, 1);
                  heff_drop_rec(v_kw_24778, 9);
                  heff_drop(v_b_24783);
                  heff_drop(v_x_241474);
                  heff_drop(v_x_241480);
                  return heff_tag_at_n(v_ru_24x1_241470_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241485}), v_st_241484});
                }
                case TAG_Right: {
                  V v_x_241486 = heff_field(v_x11_241483, 0);
                  heff_take_n(v_x11_241483, 1ULL, 1);
                  V v_t_241487 = (g_heff_2esyntax_2ecst_2elastE(v_b_24783));
                  V v_e_241488 = heff_get_n(v_t_241487, 4, 9);
                  V v_t_241489 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_24778, 3, 9), v_e_241488});
                  V v_x_241490 = (g_heff_2esyntax_2esurface_2eifE(v_t_241489, v_x_241474, v_x_241480, v_x_241486));
                  return heff_tag_at_n(v_ru_24x1_241470_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_241490}), v_st_241484});
                }
                default: return heff_nomatch(v_x11_241483);
                }
              }
              default: return heff_nomatch(v_x1_241482);
              }
            }
            default: return heff_nomatch(v_x11_241477);
            }
          }
          default: return heff_nomatch(v_x1_241476);
          }
        }
        default: return heff_nomatch(v_x11_241471);
        }
      }
      default: return heff_nomatch(v_x1_241470);
      }
    }
    case TAG_ESBind: {
      V v_m_241494 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_24779}));
      V v_x1_241495 = heff_tr(heff_call(v_m_241494, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_241495)) {
      case TAG_MkPair: {
        V v_x11_241496 = heff_field(v_x1_241495, 0);
        V v_st_241497 = heff_field(v_x1_241495, 1);
        V v_ru_24x1_241495_24MkPair = heff_take_reuse_n(v_x1_241495, 3ULL, 2);
        switch (heff_tag_of(v_x11_241496)) {
        case TAG_Left: {
          V v_e_241498 = heff_field(v_x11_241496, 0);
          heff_take_n(v_x11_241496, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_24778, 9);
          heff_drop(v_a_24781);
          heff_drop(v_b_24783);
          return heff_tag_at_n(v_ru_24x1_241495_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241498}), v_st_241497});
        }
        case TAG_Right: {
          V v_x_241499 = heff_field(v_x11_241496, 0);
          heff_take_n(v_x11_241496, 1ULL, 1);
          V v_m_241500 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_24781}));
          V v_x1_241501 = heff_tr(heff_call(v_m_241500, 1, (V[]){v_st_241497}));
          switch (heff_tag_of(v_x1_241501)) {
          case TAG_MkPair: {
            V v_x11_241502 = heff_field(v_x1_241501, 0);
            V v_st_241503 = heff_field(v_x1_241501, 1);
            heff_take_n(v_x1_241501, 3ULL, 2);
            switch (heff_tag_of(v_x11_241502)) {
            case TAG_Left: {
              V v_e_241504 = heff_field(v_x11_241502, 0);
              heff_take_n(v_x11_241502, 1ULL, 1);
              heff_drop_rec(v_r_240, 3);
              heff_drop_rec(v_kw_24778, 9);
              heff_drop(v_b_24783);
              heff_drop(v_x_241499);
              return heff_tag_at_n(v_ru_24x1_241495_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241504}), v_st_241503});
            }
            case TAG_Right: {
              V v_x_241505 = heff_field(v_x11_241502, 0);
              heff_take_n(v_x11_241502, 1ULL, 1);
              V v_m_241506 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_b_24783)}));
              V v_x1_241507 = heff_tr(heff_call(v_m_241506, 1, (V[]){v_st_241503}));
              switch (heff_tag_of(v_x1_241507)) {
              case TAG_MkPair: {
                V v_x11_241508 = heff_field(v_x1_241507, 0);
                V v_st_241509 = heff_field(v_x1_241507, 1);
                heff_take_n(v_x1_241507, 3ULL, 2);
                switch (heff_tag_of(v_x11_241508)) {
                case TAG_Left: {
                  V v_e_241510 = heff_field(v_x11_241508, 0);
                  heff_take_n(v_x11_241508, 1ULL, 1);
                  heff_drop_rec(v_kw_24778, 9);
                  heff_drop(v_b_24783);
                  heff_drop(v_x_241499);
                  heff_drop(v_x_241505);
                  return heff_tag_at_n(v_ru_24x1_241495_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241510}), v_st_241509});
                }
                case TAG_Right: {
                  V v_x_241511 = heff_field(v_x11_241508, 0);
                  heff_take_n(v_x11_241508, 1ULL, 1);
                  V v_t_241512 = (g_heff_2esyntax_2ecst_2elastE(v_b_24783));
                  V v_e_241513 = heff_get_n(v_t_241512, 4, 9);
                  V v_t_241514 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_24778, 3, 9), v_e_241513});
                  V v_x_241515 = (g_heff_2esyntax_2esurface_2eifE(v_t_241514, v_x_241499, v_x_241505, v_x_241511));
                  return heff_tag_at_n(v_ru_24x1_241495_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_241515}), v_st_241509});
                }
                default: return heff_nomatch(v_x11_241508);
                }
              }
              default: return heff_nomatch(v_x1_241507);
              }
            }
            default: return heff_nomatch(v_x11_241502);
            }
          }
          default: return heff_nomatch(v_x1_241501);
          }
        }
        default: return heff_nomatch(v_x11_241496);
        }
      }
      default: return heff_nomatch(v_x1_241495);
      }
    }
    case TAG_ELet: {
      V v_m_241522 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_24779}));
      V v_x1_241523 = heff_tr(heff_call(v_m_241522, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_241523)) {
      case TAG_MkPair: {
        V v_x11_241524 = heff_field(v_x1_241523, 0);
        V v_st_241525 = heff_field(v_x1_241523, 1);
        V v_ru_24x1_241523_24MkPair = heff_take_reuse_n(v_x1_241523, 3ULL, 2);
        switch (heff_tag_of(v_x11_241524)) {
        case TAG_Left: {
          V v_e_241526 = heff_field(v_x11_241524, 0);
          heff_take_n(v_x11_241524, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_24778, 9);
          heff_drop(v_a_24781);
          heff_drop(v_b_24783);
          return heff_tag_at_n(v_ru_24x1_241523_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241526}), v_st_241525});
        }
        case TAG_Right: {
          V v_x_241527 = heff_field(v_x11_241524, 0);
          heff_take_n(v_x11_241524, 1ULL, 1);
          V v_m_241528 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_24781}));
          V v_x1_241529 = heff_tr(heff_call(v_m_241528, 1, (V[]){v_st_241525}));
          switch (heff_tag_of(v_x1_241529)) {
          case TAG_MkPair: {
            V v_x11_241530 = heff_field(v_x1_241529, 0);
            V v_st_241531 = heff_field(v_x1_241529, 1);
            heff_take_n(v_x1_241529, 3ULL, 2);
            switch (heff_tag_of(v_x11_241530)) {
            case TAG_Left: {
              V v_e_241532 = heff_field(v_x11_241530, 0);
              heff_take_n(v_x11_241530, 1ULL, 1);
              heff_drop_rec(v_r_240, 3);
              heff_drop_rec(v_kw_24778, 9);
              heff_drop(v_b_24783);
              heff_drop(v_x_241527);
              return heff_tag_at_n(v_ru_24x1_241523_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241532}), v_st_241531});
            }
            case TAG_Right: {
              V v_x_241533 = heff_field(v_x11_241530, 0);
              heff_take_n(v_x11_241530, 1ULL, 1);
              V v_m_241534 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_b_24783)}));
              V v_x1_241535 = heff_tr(heff_call(v_m_241534, 1, (V[]){v_st_241531}));
              switch (heff_tag_of(v_x1_241535)) {
              case TAG_MkPair: {
                V v_x11_241536 = heff_field(v_x1_241535, 0);
                V v_st_241537 = heff_field(v_x1_241535, 1);
                heff_take_n(v_x1_241535, 3ULL, 2);
                switch (heff_tag_of(v_x11_241536)) {
                case TAG_Left: {
                  V v_e_241538 = heff_field(v_x11_241536, 0);
                  heff_take_n(v_x11_241536, 1ULL, 1);
                  heff_drop_rec(v_kw_24778, 9);
                  heff_drop(v_b_24783);
                  heff_drop(v_x_241527);
                  heff_drop(v_x_241533);
                  return heff_tag_at_n(v_ru_24x1_241523_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241538}), v_st_241537});
                }
                case TAG_Right: {
                  V v_x_241539 = heff_field(v_x11_241536, 0);
                  heff_take_n(v_x11_241536, 1ULL, 1);
                  V v_t_241540 = (g_heff_2esyntax_2ecst_2elastE(v_b_24783));
                  V v_e_241541 = heff_get_n(v_t_241540, 4, 9);
                  V v_t_241542 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_24778, 3, 9), v_e_241541});
                  V v_x_241543 = (g_heff_2esyntax_2esurface_2eifE(v_t_241542, v_x_241527, v_x_241533, v_x_241539));
                  return heff_tag_at_n(v_ru_24x1_241523_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_241543}), v_st_241537});
                }
                default: return heff_nomatch(v_x11_241536);
                }
              }
              default: return heff_nomatch(v_x1_241535);
              }
            }
            default: return heff_nomatch(v_x11_241530);
            }
          }
          default: return heff_nomatch(v_x1_241529);
          }
        }
        default: return heff_nomatch(v_x11_241524);
        }
      }
      default: return heff_nomatch(v_x1_241523);
      }
    }
    case TAG_ELetMut: {
      V v_m_241550 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_24779}));
      V v_x1_241551 = heff_tr(heff_call(v_m_241550, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_241551)) {
      case TAG_MkPair: {
        V v_x11_241552 = heff_field(v_x1_241551, 0);
        V v_st_241553 = heff_field(v_x1_241551, 1);
        V v_ru_24x1_241551_24MkPair = heff_take_reuse_n(v_x1_241551, 3ULL, 2);
        switch (heff_tag_of(v_x11_241552)) {
        case TAG_Left: {
          V v_e_241554 = heff_field(v_x11_241552, 0);
          heff_take_n(v_x11_241552, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_24778, 9);
          heff_drop(v_a_24781);
          heff_drop(v_b_24783);
          return heff_tag_at_n(v_ru_24x1_241551_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241554}), v_st_241553});
        }
        case TAG_Right: {
          V v_x_241555 = heff_field(v_x11_241552, 0);
          heff_take_n(v_x11_241552, 1ULL, 1);
          V v_m_241556 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_24781}));
          V v_x1_241557 = heff_tr(heff_call(v_m_241556, 1, (V[]){v_st_241553}));
          switch (heff_tag_of(v_x1_241557)) {
          case TAG_MkPair: {
            V v_x11_241558 = heff_field(v_x1_241557, 0);
            V v_st_241559 = heff_field(v_x1_241557, 1);
            heff_take_n(v_x1_241557, 3ULL, 2);
            switch (heff_tag_of(v_x11_241558)) {
            case TAG_Left: {
              V v_e_241560 = heff_field(v_x11_241558, 0);
              heff_take_n(v_x11_241558, 1ULL, 1);
              heff_drop_rec(v_r_240, 3);
              heff_drop_rec(v_kw_24778, 9);
              heff_drop(v_b_24783);
              heff_drop(v_x_241555);
              return heff_tag_at_n(v_ru_24x1_241551_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241560}), v_st_241559});
            }
            case TAG_Right: {
              V v_x_241561 = heff_field(v_x11_241558, 0);
              heff_take_n(v_x11_241558, 1ULL, 1);
              V v_m_241562 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_b_24783)}));
              V v_x1_241563 = heff_tr(heff_call(v_m_241562, 1, (V[]){v_st_241559}));
              switch (heff_tag_of(v_x1_241563)) {
              case TAG_MkPair: {
                V v_x11_241564 = heff_field(v_x1_241563, 0);
                V v_st_241565 = heff_field(v_x1_241563, 1);
                heff_take_n(v_x1_241563, 3ULL, 2);
                switch (heff_tag_of(v_x11_241564)) {
                case TAG_Left: {
                  V v_e_241566 = heff_field(v_x11_241564, 0);
                  heff_take_n(v_x11_241564, 1ULL, 1);
                  heff_drop_rec(v_kw_24778, 9);
                  heff_drop(v_b_24783);
                  heff_drop(v_x_241555);
                  heff_drop(v_x_241561);
                  return heff_tag_at_n(v_ru_24x1_241551_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241566}), v_st_241565});
                }
                case TAG_Right: {
                  V v_x_241567 = heff_field(v_x11_241564, 0);
                  heff_take_n(v_x11_241564, 1ULL, 1);
                  V v_t_241568 = (g_heff_2esyntax_2ecst_2elastE(v_b_24783));
                  V v_e_241569 = heff_get_n(v_t_241568, 4, 9);
                  V v_t_241570 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_24778, 3, 9), v_e_241569});
                  V v_x_241571 = (g_heff_2esyntax_2esurface_2eifE(v_t_241570, v_x_241555, v_x_241561, v_x_241567));
                  return heff_tag_at_n(v_ru_24x1_241551_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_241571}), v_st_241565});
                }
                default: return heff_nomatch(v_x11_241564);
                }
              }
              default: return heff_nomatch(v_x1_241563);
              }
            }
            default: return heff_nomatch(v_x11_241558);
            }
          }
          default: return heff_nomatch(v_x1_241557);
          }
        }
        default: return heff_nomatch(v_x11_241552);
        }
      }
      default: return heff_nomatch(v_x1_241551);
      }
    }
    case TAG_EAssign: {
      V v_m_241575 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_24779}));
      V v_x1_241576 = heff_tr(heff_call(v_m_241575, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_241576)) {
      case TAG_MkPair: {
        V v_x11_241577 = heff_field(v_x1_241576, 0);
        V v_st_241578 = heff_field(v_x1_241576, 1);
        V v_ru_24x1_241576_24MkPair = heff_take_reuse_n(v_x1_241576, 3ULL, 2);
        switch (heff_tag_of(v_x11_241577)) {
        case TAG_Left: {
          V v_e_241579 = heff_field(v_x11_241577, 0);
          heff_take_n(v_x11_241577, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_24778, 9);
          heff_drop(v_a_24781);
          heff_drop(v_b_24783);
          return heff_tag_at_n(v_ru_24x1_241576_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241579}), v_st_241578});
        }
        case TAG_Right: {
          V v_x_241580 = heff_field(v_x11_241577, 0);
          heff_take_n(v_x11_241577, 1ULL, 1);
          V v_m_241581 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_24781}));
          V v_x1_241582 = heff_tr(heff_call(v_m_241581, 1, (V[]){v_st_241578}));
          switch (heff_tag_of(v_x1_241582)) {
          case TAG_MkPair: {
            V v_x11_241583 = heff_field(v_x1_241582, 0);
            V v_st_241584 = heff_field(v_x1_241582, 1);
            heff_take_n(v_x1_241582, 3ULL, 2);
            switch (heff_tag_of(v_x11_241583)) {
            case TAG_Left: {
              V v_e_241585 = heff_field(v_x11_241583, 0);
              heff_take_n(v_x11_241583, 1ULL, 1);
              heff_drop_rec(v_r_240, 3);
              heff_drop_rec(v_kw_24778, 9);
              heff_drop(v_b_24783);
              heff_drop(v_x_241580);
              return heff_tag_at_n(v_ru_24x1_241576_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241585}), v_st_241584});
            }
            case TAG_Right: {
              V v_x_241586 = heff_field(v_x11_241583, 0);
              heff_take_n(v_x11_241583, 1ULL, 1);
              V v_m_241587 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_b_24783)}));
              V v_x1_241588 = heff_tr(heff_call(v_m_241587, 1, (V[]){v_st_241584}));
              switch (heff_tag_of(v_x1_241588)) {
              case TAG_MkPair: {
                V v_x11_241589 = heff_field(v_x1_241588, 0);
                V v_st_241590 = heff_field(v_x1_241588, 1);
                heff_take_n(v_x1_241588, 3ULL, 2);
                switch (heff_tag_of(v_x11_241589)) {
                case TAG_Left: {
                  V v_e_241591 = heff_field(v_x11_241589, 0);
                  heff_take_n(v_x11_241589, 1ULL, 1);
                  heff_drop_rec(v_kw_24778, 9);
                  heff_drop(v_b_24783);
                  heff_drop(v_x_241580);
                  heff_drop(v_x_241586);
                  return heff_tag_at_n(v_ru_24x1_241576_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241591}), v_st_241590});
                }
                case TAG_Right: {
                  V v_x_241592 = heff_field(v_x11_241589, 0);
                  heff_take_n(v_x11_241589, 1ULL, 1);
                  V v_t_241593 = (g_heff_2esyntax_2ecst_2elastE(v_b_24783));
                  V v_e_241594 = heff_get_n(v_t_241593, 4, 9);
                  V v_t_241595 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_24778, 3, 9), v_e_241594});
                  V v_x_241596 = (g_heff_2esyntax_2esurface_2eifE(v_t_241595, v_x_241580, v_x_241586, v_x_241592));
                  return heff_tag_at_n(v_ru_24x1_241576_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_241596}), v_st_241590});
                }
                default: return heff_nomatch(v_x11_241589);
                }
              }
              default: return heff_nomatch(v_x1_241588);
              }
            }
            default: return heff_nomatch(v_x11_241583);
            }
          }
          default: return heff_nomatch(v_x1_241582);
          }
        }
        default: return heff_nomatch(v_x11_241577);
        }
      }
      default: return heff_nomatch(v_x1_241576);
      }
    }
    case TAG_EWhile: {
      V v_m_241601 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_24779}));
      V v_x1_241602 = heff_tr(heff_call(v_m_241601, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_241602)) {
      case TAG_MkPair: {
        V v_x11_241603 = heff_field(v_x1_241602, 0);
        V v_st_241604 = heff_field(v_x1_241602, 1);
        V v_ru_24x1_241602_24MkPair = heff_take_reuse_n(v_x1_241602, 3ULL, 2);
        switch (heff_tag_of(v_x11_241603)) {
        case TAG_Left: {
          V v_e_241605 = heff_field(v_x11_241603, 0);
          heff_take_n(v_x11_241603, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_24778, 9);
          heff_drop(v_a_24781);
          heff_drop(v_b_24783);
          return heff_tag_at_n(v_ru_24x1_241602_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241605}), v_st_241604});
        }
        case TAG_Right: {
          V v_x_241606 = heff_field(v_x11_241603, 0);
          heff_take_n(v_x11_241603, 1ULL, 1);
          V v_m_241607 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_24781}));
          V v_x1_241608 = heff_tr(heff_call(v_m_241607, 1, (V[]){v_st_241604}));
          switch (heff_tag_of(v_x1_241608)) {
          case TAG_MkPair: {
            V v_x11_241609 = heff_field(v_x1_241608, 0);
            V v_st_241610 = heff_field(v_x1_241608, 1);
            heff_take_n(v_x1_241608, 3ULL, 2);
            switch (heff_tag_of(v_x11_241609)) {
            case TAG_Left: {
              V v_e_241611 = heff_field(v_x11_241609, 0);
              heff_take_n(v_x11_241609, 1ULL, 1);
              heff_drop_rec(v_r_240, 3);
              heff_drop_rec(v_kw_24778, 9);
              heff_drop(v_b_24783);
              heff_drop(v_x_241606);
              return heff_tag_at_n(v_ru_24x1_241602_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241611}), v_st_241610});
            }
            case TAG_Right: {
              V v_x_241612 = heff_field(v_x11_241609, 0);
              heff_take_n(v_x11_241609, 1ULL, 1);
              V v_m_241613 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_b_24783)}));
              V v_x1_241614 = heff_tr(heff_call(v_m_241613, 1, (V[]){v_st_241610}));
              switch (heff_tag_of(v_x1_241614)) {
              case TAG_MkPair: {
                V v_x11_241615 = heff_field(v_x1_241614, 0);
                V v_st_241616 = heff_field(v_x1_241614, 1);
                heff_take_n(v_x1_241614, 3ULL, 2);
                switch (heff_tag_of(v_x11_241615)) {
                case TAG_Left: {
                  V v_e_241617 = heff_field(v_x11_241615, 0);
                  heff_take_n(v_x11_241615, 1ULL, 1);
                  heff_drop_rec(v_kw_24778, 9);
                  heff_drop(v_b_24783);
                  heff_drop(v_x_241606);
                  heff_drop(v_x_241612);
                  return heff_tag_at_n(v_ru_24x1_241602_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241617}), v_st_241616});
                }
                case TAG_Right: {
                  V v_x_241618 = heff_field(v_x11_241615, 0);
                  heff_take_n(v_x11_241615, 1ULL, 1);
                  V v_t_241619 = (g_heff_2esyntax_2ecst_2elastE(v_b_24783));
                  V v_e_241620 = heff_get_n(v_t_241619, 4, 9);
                  V v_t_241621 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_24778, 3, 9), v_e_241620});
                  V v_x_241622 = (g_heff_2esyntax_2esurface_2eifE(v_t_241621, v_x_241606, v_x_241612, v_x_241618));
                  return heff_tag_at_n(v_ru_24x1_241602_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_241622}), v_st_241616});
                }
                default: return heff_nomatch(v_x11_241615);
                }
              }
              default: return heff_nomatch(v_x1_241614);
              }
            }
            default: return heff_nomatch(v_x11_241609);
            }
          }
          default: return heff_nomatch(v_x1_241608);
          }
        }
        default: return heff_nomatch(v_x11_241603);
        }
      }
      default: return heff_nomatch(v_x1_241602);
      }
    }
    case TAG_EFor: {
      V v_m_241629 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_24779}));
      V v_x1_241630 = heff_tr(heff_call(v_m_241629, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_241630)) {
      case TAG_MkPair: {
        V v_x11_241631 = heff_field(v_x1_241630, 0);
        V v_st_241632 = heff_field(v_x1_241630, 1);
        V v_ru_24x1_241630_24MkPair = heff_take_reuse_n(v_x1_241630, 3ULL, 2);
        switch (heff_tag_of(v_x11_241631)) {
        case TAG_Left: {
          V v_e_241633 = heff_field(v_x11_241631, 0);
          heff_take_n(v_x11_241631, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_24778, 9);
          heff_drop(v_a_24781);
          heff_drop(v_b_24783);
          return heff_tag_at_n(v_ru_24x1_241630_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241633}), v_st_241632});
        }
        case TAG_Right: {
          V v_x_241634 = heff_field(v_x11_241631, 0);
          heff_take_n(v_x11_241631, 1ULL, 1);
          V v_m_241635 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_24781}));
          V v_x1_241636 = heff_tr(heff_call(v_m_241635, 1, (V[]){v_st_241632}));
          switch (heff_tag_of(v_x1_241636)) {
          case TAG_MkPair: {
            V v_x11_241637 = heff_field(v_x1_241636, 0);
            V v_st_241638 = heff_field(v_x1_241636, 1);
            heff_take_n(v_x1_241636, 3ULL, 2);
            switch (heff_tag_of(v_x11_241637)) {
            case TAG_Left: {
              V v_e_241639 = heff_field(v_x11_241637, 0);
              heff_take_n(v_x11_241637, 1ULL, 1);
              heff_drop_rec(v_r_240, 3);
              heff_drop_rec(v_kw_24778, 9);
              heff_drop(v_b_24783);
              heff_drop(v_x_241634);
              return heff_tag_at_n(v_ru_24x1_241630_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241639}), v_st_241638});
            }
            case TAG_Right: {
              V v_x_241640 = heff_field(v_x11_241637, 0);
              heff_take_n(v_x11_241637, 1ULL, 1);
              V v_m_241641 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_b_24783)}));
              V v_x1_241642 = heff_tr(heff_call(v_m_241641, 1, (V[]){v_st_241638}));
              switch (heff_tag_of(v_x1_241642)) {
              case TAG_MkPair: {
                V v_x11_241643 = heff_field(v_x1_241642, 0);
                V v_st_241644 = heff_field(v_x1_241642, 1);
                heff_take_n(v_x1_241642, 3ULL, 2);
                switch (heff_tag_of(v_x11_241643)) {
                case TAG_Left: {
                  V v_e_241645 = heff_field(v_x11_241643, 0);
                  heff_take_n(v_x11_241643, 1ULL, 1);
                  heff_drop_rec(v_kw_24778, 9);
                  heff_drop(v_b_24783);
                  heff_drop(v_x_241634);
                  heff_drop(v_x_241640);
                  return heff_tag_at_n(v_ru_24x1_241630_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241645}), v_st_241644});
                }
                case TAG_Right: {
                  V v_x_241646 = heff_field(v_x11_241643, 0);
                  heff_take_n(v_x11_241643, 1ULL, 1);
                  V v_t_241647 = (g_heff_2esyntax_2ecst_2elastE(v_b_24783));
                  V v_e_241648 = heff_get_n(v_t_241647, 4, 9);
                  V v_t_241649 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_24778, 3, 9), v_e_241648});
                  V v_x_241650 = (g_heff_2esyntax_2esurface_2eifE(v_t_241649, v_x_241634, v_x_241640, v_x_241646));
                  return heff_tag_at_n(v_ru_24x1_241630_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_241650}), v_st_241644});
                }
                default: return heff_nomatch(v_x11_241643);
                }
              }
              default: return heff_nomatch(v_x1_241642);
              }
            }
            default: return heff_nomatch(v_x11_241637);
            }
          }
          default: return heff_nomatch(v_x1_241636);
          }
        }
        default: return heff_nomatch(v_x11_241631);
        }
      }
      default: return heff_nomatch(v_x1_241630);
      }
    }
    case TAG_EJump: {
      V v_m_241652 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_24779}));
      V v_x1_241653 = heff_tr(heff_call(v_m_241652, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_241653)) {
      case TAG_MkPair: {
        V v_x11_241654 = heff_field(v_x1_241653, 0);
        V v_st_241655 = heff_field(v_x1_241653, 1);
        V v_ru_24x1_241653_24MkPair = heff_take_reuse_n(v_x1_241653, 3ULL, 2);
        switch (heff_tag_of(v_x11_241654)) {
        case TAG_Left: {
          V v_e_241656 = heff_field(v_x11_241654, 0);
          heff_take_n(v_x11_241654, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_24778, 9);
          heff_drop(v_a_24781);
          heff_drop(v_b_24783);
          return heff_tag_at_n(v_ru_24x1_241653_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241656}), v_st_241655});
        }
        case TAG_Right: {
          V v_x_241657 = heff_field(v_x11_241654, 0);
          heff_take_n(v_x11_241654, 1ULL, 1);
          V v_m_241658 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_24781}));
          V v_x1_241659 = heff_tr(heff_call(v_m_241658, 1, (V[]){v_st_241655}));
          switch (heff_tag_of(v_x1_241659)) {
          case TAG_MkPair: {
            V v_x11_241660 = heff_field(v_x1_241659, 0);
            V v_st_241661 = heff_field(v_x1_241659, 1);
            heff_take_n(v_x1_241659, 3ULL, 2);
            switch (heff_tag_of(v_x11_241660)) {
            case TAG_Left: {
              V v_e_241662 = heff_field(v_x11_241660, 0);
              heff_take_n(v_x11_241660, 1ULL, 1);
              heff_drop_rec(v_r_240, 3);
              heff_drop_rec(v_kw_24778, 9);
              heff_drop(v_b_24783);
              heff_drop(v_x_241657);
              return heff_tag_at_n(v_ru_24x1_241653_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241662}), v_st_241661});
            }
            case TAG_Right: {
              V v_x_241663 = heff_field(v_x11_241660, 0);
              heff_take_n(v_x11_241660, 1ULL, 1);
              V v_m_241664 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_b_24783)}));
              V v_x1_241665 = heff_tr(heff_call(v_m_241664, 1, (V[]){v_st_241661}));
              switch (heff_tag_of(v_x1_241665)) {
              case TAG_MkPair: {
                V v_x11_241666 = heff_field(v_x1_241665, 0);
                V v_st_241667 = heff_field(v_x1_241665, 1);
                heff_take_n(v_x1_241665, 3ULL, 2);
                switch (heff_tag_of(v_x11_241666)) {
                case TAG_Left: {
                  V v_e_241668 = heff_field(v_x11_241666, 0);
                  heff_take_n(v_x11_241666, 1ULL, 1);
                  heff_drop_rec(v_kw_24778, 9);
                  heff_drop(v_b_24783);
                  heff_drop(v_x_241657);
                  heff_drop(v_x_241663);
                  return heff_tag_at_n(v_ru_24x1_241653_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241668}), v_st_241667});
                }
                case TAG_Right: {
                  V v_x_241669 = heff_field(v_x11_241666, 0);
                  heff_take_n(v_x11_241666, 1ULL, 1);
                  V v_t_241670 = (g_heff_2esyntax_2ecst_2elastE(v_b_24783));
                  V v_e_241671 = heff_get_n(v_t_241670, 4, 9);
                  V v_t_241672 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_24778, 3, 9), v_e_241671});
                  V v_x_241673 = (g_heff_2esyntax_2esurface_2eifE(v_t_241672, v_x_241657, v_x_241663, v_x_241669));
                  return heff_tag_at_n(v_ru_24x1_241653_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_241673}), v_st_241667});
                }
                default: return heff_nomatch(v_x11_241666);
                }
              }
              default: return heff_nomatch(v_x1_241665);
              }
            }
            default: return heff_nomatch(v_x11_241660);
            }
          }
          default: return heff_nomatch(v_x1_241659);
          }
        }
        default: return heff_nomatch(v_x11_241654);
        }
      }
      default: return heff_nomatch(v_x1_241653);
      }
    }
    case TAG_EReturn: {
      V v_m_241676 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_24779}));
      V v_x1_241677 = heff_tr(heff_call(v_m_241676, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_241677)) {
      case TAG_MkPair: {
        V v_x11_241678 = heff_field(v_x1_241677, 0);
        V v_st_241679 = heff_field(v_x1_241677, 1);
        V v_ru_24x1_241677_24MkPair = heff_take_reuse_n(v_x1_241677, 3ULL, 2);
        switch (heff_tag_of(v_x11_241678)) {
        case TAG_Left: {
          V v_e_241680 = heff_field(v_x11_241678, 0);
          heff_take_n(v_x11_241678, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_24778, 9);
          heff_drop(v_a_24781);
          heff_drop(v_b_24783);
          return heff_tag_at_n(v_ru_24x1_241677_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241680}), v_st_241679});
        }
        case TAG_Right: {
          V v_x_241681 = heff_field(v_x11_241678, 0);
          heff_take_n(v_x11_241678, 1ULL, 1);
          V v_m_241682 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_24781}));
          V v_x1_241683 = heff_tr(heff_call(v_m_241682, 1, (V[]){v_st_241679}));
          switch (heff_tag_of(v_x1_241683)) {
          case TAG_MkPair: {
            V v_x11_241684 = heff_field(v_x1_241683, 0);
            V v_st_241685 = heff_field(v_x1_241683, 1);
            heff_take_n(v_x1_241683, 3ULL, 2);
            switch (heff_tag_of(v_x11_241684)) {
            case TAG_Left: {
              V v_e_241686 = heff_field(v_x11_241684, 0);
              heff_take_n(v_x11_241684, 1ULL, 1);
              heff_drop_rec(v_r_240, 3);
              heff_drop_rec(v_kw_24778, 9);
              heff_drop(v_b_24783);
              heff_drop(v_x_241681);
              return heff_tag_at_n(v_ru_24x1_241677_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241686}), v_st_241685});
            }
            case TAG_Right: {
              V v_x_241687 = heff_field(v_x11_241684, 0);
              heff_take_n(v_x11_241684, 1ULL, 1);
              V v_m_241688 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_b_24783)}));
              V v_x1_241689 = heff_tr(heff_call(v_m_241688, 1, (V[]){v_st_241685}));
              switch (heff_tag_of(v_x1_241689)) {
              case TAG_MkPair: {
                V v_x11_241690 = heff_field(v_x1_241689, 0);
                V v_st_241691 = heff_field(v_x1_241689, 1);
                heff_take_n(v_x1_241689, 3ULL, 2);
                switch (heff_tag_of(v_x11_241690)) {
                case TAG_Left: {
                  V v_e_241692 = heff_field(v_x11_241690, 0);
                  heff_take_n(v_x11_241690, 1ULL, 1);
                  heff_drop_rec(v_kw_24778, 9);
                  heff_drop(v_b_24783);
                  heff_drop(v_x_241681);
                  heff_drop(v_x_241687);
                  return heff_tag_at_n(v_ru_24x1_241677_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241692}), v_st_241691});
                }
                case TAG_Right: {
                  V v_x_241693 = heff_field(v_x11_241690, 0);
                  heff_take_n(v_x11_241690, 1ULL, 1);
                  V v_t_241694 = (g_heff_2esyntax_2ecst_2elastE(v_b_24783));
                  V v_e_241695 = heff_get_n(v_t_241694, 4, 9);
                  V v_t_241696 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_24778, 3, 9), v_e_241695});
                  V v_x_241697 = (g_heff_2esyntax_2esurface_2eifE(v_t_241696, v_x_241681, v_x_241687, v_x_241693));
                  return heff_tag_at_n(v_ru_24x1_241677_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_241697}), v_st_241691});
                }
                default: return heff_nomatch(v_x11_241690);
                }
              }
              default: return heff_nomatch(v_x1_241689);
              }
            }
            default: return heff_nomatch(v_x11_241684);
            }
          }
          default: return heff_nomatch(v_x1_241683);
          }
        }
        default: return heff_nomatch(v_x11_241678);
        }
      }
      default: return heff_nomatch(v_x1_241677);
      }
    }
    case TAG_ENest: {
      V v_m_241702 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_24779}));
      V v_x1_241703 = heff_tr(heff_call(v_m_241702, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_241703)) {
      case TAG_MkPair: {
        V v_x11_241704 = heff_field(v_x1_241703, 0);
        V v_st_241705 = heff_field(v_x1_241703, 1);
        V v_ru_24x1_241703_24MkPair = heff_take_reuse_n(v_x1_241703, 3ULL, 2);
        switch (heff_tag_of(v_x11_241704)) {
        case TAG_Left: {
          V v_e_241706 = heff_field(v_x11_241704, 0);
          heff_take_n(v_x11_241704, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_24778, 9);
          heff_drop(v_a_24781);
          heff_drop(v_b_24783);
          return heff_tag_at_n(v_ru_24x1_241703_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241706}), v_st_241705});
        }
        case TAG_Right: {
          V v_x_241707 = heff_field(v_x11_241704, 0);
          heff_take_n(v_x11_241704, 1ULL, 1);
          V v_m_241708 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_24781}));
          V v_x1_241709 = heff_tr(heff_call(v_m_241708, 1, (V[]){v_st_241705}));
          switch (heff_tag_of(v_x1_241709)) {
          case TAG_MkPair: {
            V v_x11_241710 = heff_field(v_x1_241709, 0);
            V v_st_241711 = heff_field(v_x1_241709, 1);
            heff_take_n(v_x1_241709, 3ULL, 2);
            switch (heff_tag_of(v_x11_241710)) {
            case TAG_Left: {
              V v_e_241712 = heff_field(v_x11_241710, 0);
              heff_take_n(v_x11_241710, 1ULL, 1);
              heff_drop_rec(v_r_240, 3);
              heff_drop_rec(v_kw_24778, 9);
              heff_drop(v_b_24783);
              heff_drop(v_x_241707);
              return heff_tag_at_n(v_ru_24x1_241703_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241712}), v_st_241711});
            }
            case TAG_Right: {
              V v_x_241713 = heff_field(v_x11_241710, 0);
              heff_take_n(v_x11_241710, 1ULL, 1);
              V v_m_241714 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_b_24783)}));
              V v_x1_241715 = heff_tr(heff_call(v_m_241714, 1, (V[]){v_st_241711}));
              switch (heff_tag_of(v_x1_241715)) {
              case TAG_MkPair: {
                V v_x11_241716 = heff_field(v_x1_241715, 0);
                V v_st_241717 = heff_field(v_x1_241715, 1);
                heff_take_n(v_x1_241715, 3ULL, 2);
                switch (heff_tag_of(v_x11_241716)) {
                case TAG_Left: {
                  V v_e_241718 = heff_field(v_x11_241716, 0);
                  heff_take_n(v_x11_241716, 1ULL, 1);
                  heff_drop_rec(v_kw_24778, 9);
                  heff_drop(v_b_24783);
                  heff_drop(v_x_241707);
                  heff_drop(v_x_241713);
                  return heff_tag_at_n(v_ru_24x1_241703_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241718}), v_st_241717});
                }
                case TAG_Right: {
                  V v_x_241719 = heff_field(v_x11_241716, 0);
                  heff_take_n(v_x11_241716, 1ULL, 1);
                  V v_t_241720 = (g_heff_2esyntax_2ecst_2elastE(v_b_24783));
                  V v_e_241721 = heff_get_n(v_t_241720, 4, 9);
                  V v_t_241722 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_24778, 3, 9), v_e_241721});
                  V v_x_241723 = (g_heff_2esyntax_2esurface_2eifE(v_t_241722, v_x_241707, v_x_241713, v_x_241719));
                  return heff_tag_at_n(v_ru_24x1_241703_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_241723}), v_st_241717});
                }
                default: return heff_nomatch(v_x11_241716);
                }
              }
              default: return heff_nomatch(v_x1_241715);
              }
            }
            default: return heff_nomatch(v_x11_241710);
            }
          }
          default: return heff_nomatch(v_x1_241709);
          }
        }
        default: return heff_nomatch(v_x11_241704);
        }
      }
      default: return heff_nomatch(v_x1_241703);
      }
    }
    case TAG_IfThen: {
      V v_m_241728 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_24779}));
      V v_x1_241729 = heff_tr(heff_call(v_m_241728, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_241729)) {
      case TAG_MkPair: {
        V v_x11_241730 = heff_field(v_x1_241729, 0);
        V v_st_241731 = heff_field(v_x1_241729, 1);
        V v_ru_24x1_241729_24MkPair = heff_take_reuse_n(v_x1_241729, 3ULL, 2);
        switch (heff_tag_of(v_x11_241730)) {
        case TAG_Left: {
          V v_e_241732 = heff_field(v_x11_241730, 0);
          heff_take_n(v_x11_241730, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_24778, 9);
          heff_drop(v_a_24781);
          heff_drop(v_b_24783);
          return heff_tag_at_n(v_ru_24x1_241729_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241732}), v_st_241731});
        }
        case TAG_Right: {
          V v_x_241733 = heff_field(v_x11_241730, 0);
          heff_take_n(v_x11_241730, 1ULL, 1);
          V v_m_241734 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_24781}));
          V v_x1_241735 = heff_tr(heff_call(v_m_241734, 1, (V[]){v_st_241731}));
          switch (heff_tag_of(v_x1_241735)) {
          case TAG_MkPair: {
            V v_x11_241736 = heff_field(v_x1_241735, 0);
            V v_st_241737 = heff_field(v_x1_241735, 1);
            heff_take_n(v_x1_241735, 3ULL, 2);
            switch (heff_tag_of(v_x11_241736)) {
            case TAG_Left: {
              V v_e_241738 = heff_field(v_x11_241736, 0);
              heff_take_n(v_x11_241736, 1ULL, 1);
              heff_drop_rec(v_r_240, 3);
              heff_drop_rec(v_kw_24778, 9);
              heff_drop(v_b_24783);
              heff_drop(v_x_241733);
              return heff_tag_at_n(v_ru_24x1_241729_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241738}), v_st_241737});
            }
            case TAG_Right: {
              V v_x_241739 = heff_field(v_x11_241736, 0);
              heff_take_n(v_x11_241736, 1ULL, 1);
              V v_m_241740 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_b_24783)}));
              V v_x1_241741 = heff_tr(heff_call(v_m_241740, 1, (V[]){v_st_241737}));
              switch (heff_tag_of(v_x1_241741)) {
              case TAG_MkPair: {
                V v_x11_241742 = heff_field(v_x1_241741, 0);
                V v_st_241743 = heff_field(v_x1_241741, 1);
                heff_take_n(v_x1_241741, 3ULL, 2);
                switch (heff_tag_of(v_x11_241742)) {
                case TAG_Left: {
                  V v_e_241744 = heff_field(v_x11_241742, 0);
                  heff_take_n(v_x11_241742, 1ULL, 1);
                  heff_drop_rec(v_kw_24778, 9);
                  heff_drop(v_b_24783);
                  heff_drop(v_x_241733);
                  heff_drop(v_x_241739);
                  return heff_tag_at_n(v_ru_24x1_241729_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241744}), v_st_241743});
                }
                case TAG_Right: {
                  V v_x_241745 = heff_field(v_x11_241742, 0);
                  heff_take_n(v_x11_241742, 1ULL, 1);
                  V v_t_241746 = (g_heff_2esyntax_2ecst_2elastE(v_b_24783));
                  V v_e_241747 = heff_get_n(v_t_241746, 4, 9);
                  V v_t_241748 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_24778, 3, 9), v_e_241747});
                  V v_x_241749 = (g_heff_2esyntax_2esurface_2eifE(v_t_241748, v_x_241733, v_x_241739, v_x_241745));
                  return heff_tag_at_n(v_ru_24x1_241729_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_241749}), v_st_241743});
                }
                default: return heff_nomatch(v_x11_241742);
                }
              }
              default: return heff_nomatch(v_x1_241741);
              }
            }
            default: return heff_nomatch(v_x11_241736);
            }
          }
          default: return heff_nomatch(v_x1_241735);
          }
        }
        default: return heff_nomatch(v_x11_241730);
        }
      }
      default: return heff_nomatch(v_x1_241729);
      }
    }
    case TAG_ELetCond: {
      V v_p_241751 = heff_field(v_e02_24779, 1);
      V v_e_241753 = heff_field(v_e02_24779, 3);
      heff_take_n(v_e02_24779, 10ULL, 4);
      V v_t_241754 = (g_heff_2esyntax_2ecst_2elastE(heff_dup(v_b_24783)));
      V v_e_241755 = heff_get_n(v_t_241754, 4, 9);
      V v_t_241756 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_24778, 3, 9), v_e_241755});
      return (g_heff_2esyntax_2esurface_2eifLetL(v_r_240, v_t_241756, v_p_241751, v_e_241753, v_a_24781, heff_tag_n(TAG_Just, 1, (V[]){v_b_24783}), v_z_242));
    }
    case TAG_ETry: {
      V v_m_241761 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_24779}));
      V v_x1_241762 = heff_tr(heff_call(v_m_241761, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_241762)) {
      case TAG_MkPair: {
        V v_x11_241763 = heff_field(v_x1_241762, 0);
        V v_st_241764 = heff_field(v_x1_241762, 1);
        V v_ru_24x1_241762_24MkPair = heff_take_reuse_n(v_x1_241762, 3ULL, 2);
        switch (heff_tag_of(v_x11_241763)) {
        case TAG_Left: {
          V v_e_241765 = heff_field(v_x11_241763, 0);
          heff_take_n(v_x11_241763, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_24778, 9);
          heff_drop(v_a_24781);
          heff_drop(v_b_24783);
          return heff_tag_at_n(v_ru_24x1_241762_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241765}), v_st_241764});
        }
        case TAG_Right: {
          V v_x_241766 = heff_field(v_x11_241763, 0);
          heff_take_n(v_x11_241763, 1ULL, 1);
          V v_m_241767 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_24781}));
          V v_x1_241768 = heff_tr(heff_call(v_m_241767, 1, (V[]){v_st_241764}));
          switch (heff_tag_of(v_x1_241768)) {
          case TAG_MkPair: {
            V v_x11_241769 = heff_field(v_x1_241768, 0);
            V v_st_241770 = heff_field(v_x1_241768, 1);
            heff_take_n(v_x1_241768, 3ULL, 2);
            switch (heff_tag_of(v_x11_241769)) {
            case TAG_Left: {
              V v_e_241771 = heff_field(v_x11_241769, 0);
              heff_take_n(v_x11_241769, 1ULL, 1);
              heff_drop_rec(v_r_240, 3);
              heff_drop_rec(v_kw_24778, 9);
              heff_drop(v_b_24783);
              heff_drop(v_x_241766);
              return heff_tag_at_n(v_ru_24x1_241762_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241771}), v_st_241770});
            }
            case TAG_Right: {
              V v_x_241772 = heff_field(v_x11_241769, 0);
              heff_take_n(v_x11_241769, 1ULL, 1);
              V v_m_241773 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_b_24783)}));
              V v_x1_241774 = heff_tr(heff_call(v_m_241773, 1, (V[]){v_st_241770}));
              switch (heff_tag_of(v_x1_241774)) {
              case TAG_MkPair: {
                V v_x11_241775 = heff_field(v_x1_241774, 0);
                V v_st_241776 = heff_field(v_x1_241774, 1);
                heff_take_n(v_x1_241774, 3ULL, 2);
                switch (heff_tag_of(v_x11_241775)) {
                case TAG_Left: {
                  V v_e_241777 = heff_field(v_x11_241775, 0);
                  heff_take_n(v_x11_241775, 1ULL, 1);
                  heff_drop_rec(v_kw_24778, 9);
                  heff_drop(v_b_24783);
                  heff_drop(v_x_241766);
                  heff_drop(v_x_241772);
                  return heff_tag_at_n(v_ru_24x1_241762_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241777}), v_st_241776});
                }
                case TAG_Right: {
                  V v_x_241778 = heff_field(v_x11_241775, 0);
                  heff_take_n(v_x11_241775, 1ULL, 1);
                  V v_t_241779 = (g_heff_2esyntax_2ecst_2elastE(v_b_24783));
                  V v_e_241780 = heff_get_n(v_t_241779, 4, 9);
                  V v_t_241781 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_24778, 3, 9), v_e_241780});
                  V v_x_241782 = (g_heff_2esyntax_2esurface_2eifE(v_t_241781, v_x_241766, v_x_241772, v_x_241778));
                  return heff_tag_at_n(v_ru_24x1_241762_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_241782}), v_st_241776});
                }
                default: return heff_nomatch(v_x11_241775);
                }
              }
              default: return heff_nomatch(v_x1_241774);
              }
            }
            default: return heff_nomatch(v_x11_241769);
            }
          }
          default: return heff_nomatch(v_x1_241768);
          }
        }
        default: return heff_nomatch(v_x11_241763);
        }
      }
      default: return heff_nomatch(v_x1_241762);
      }
    }
    case TAG_ECatch: {
      V v_m_241787 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_24779}));
      V v_x1_241788 = heff_tr(heff_call(v_m_241787, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_241788)) {
      case TAG_MkPair: {
        V v_x11_241789 = heff_field(v_x1_241788, 0);
        V v_st_241790 = heff_field(v_x1_241788, 1);
        V v_ru_24x1_241788_24MkPair = heff_take_reuse_n(v_x1_241788, 3ULL, 2);
        switch (heff_tag_of(v_x11_241789)) {
        case TAG_Left: {
          V v_e_241791 = heff_field(v_x11_241789, 0);
          heff_take_n(v_x11_241789, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_24778, 9);
          heff_drop(v_a_24781);
          heff_drop(v_b_24783);
          return heff_tag_at_n(v_ru_24x1_241788_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241791}), v_st_241790});
        }
        case TAG_Right: {
          V v_x_241792 = heff_field(v_x11_241789, 0);
          heff_take_n(v_x11_241789, 1ULL, 1);
          V v_m_241793 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_24781}));
          V v_x1_241794 = heff_tr(heff_call(v_m_241793, 1, (V[]){v_st_241790}));
          switch (heff_tag_of(v_x1_241794)) {
          case TAG_MkPair: {
            V v_x11_241795 = heff_field(v_x1_241794, 0);
            V v_st_241796 = heff_field(v_x1_241794, 1);
            heff_take_n(v_x1_241794, 3ULL, 2);
            switch (heff_tag_of(v_x11_241795)) {
            case TAG_Left: {
              V v_e_241797 = heff_field(v_x11_241795, 0);
              heff_take_n(v_x11_241795, 1ULL, 1);
              heff_drop_rec(v_r_240, 3);
              heff_drop_rec(v_kw_24778, 9);
              heff_drop(v_b_24783);
              heff_drop(v_x_241792);
              return heff_tag_at_n(v_ru_24x1_241788_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241797}), v_st_241796});
            }
            case TAG_Right: {
              V v_x_241798 = heff_field(v_x11_241795, 0);
              heff_take_n(v_x11_241795, 1ULL, 1);
              V v_m_241799 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_b_24783)}));
              V v_x1_241800 = heff_tr(heff_call(v_m_241799, 1, (V[]){v_st_241796}));
              switch (heff_tag_of(v_x1_241800)) {
              case TAG_MkPair: {
                V v_x11_241801 = heff_field(v_x1_241800, 0);
                V v_st_241802 = heff_field(v_x1_241800, 1);
                heff_take_n(v_x1_241800, 3ULL, 2);
                switch (heff_tag_of(v_x11_241801)) {
                case TAG_Left: {
                  V v_e_241803 = heff_field(v_x11_241801, 0);
                  heff_take_n(v_x11_241801, 1ULL, 1);
                  heff_drop_rec(v_kw_24778, 9);
                  heff_drop(v_b_24783);
                  heff_drop(v_x_241792);
                  heff_drop(v_x_241798);
                  return heff_tag_at_n(v_ru_24x1_241788_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241803}), v_st_241802});
                }
                case TAG_Right: {
                  V v_x_241804 = heff_field(v_x11_241801, 0);
                  heff_take_n(v_x11_241801, 1ULL, 1);
                  V v_t_241805 = (g_heff_2esyntax_2ecst_2elastE(v_b_24783));
                  V v_e_241806 = heff_get_n(v_t_241805, 4, 9);
                  V v_t_241807 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_24778, 3, 9), v_e_241806});
                  V v_x_241808 = (g_heff_2esyntax_2esurface_2eifE(v_t_241807, v_x_241792, v_x_241798, v_x_241804));
                  return heff_tag_at_n(v_ru_24x1_241788_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_241808}), v_st_241802});
                }
                default: return heff_nomatch(v_x11_241801);
                }
              }
              default: return heff_nomatch(v_x1_241800);
              }
            }
            default: return heff_nomatch(v_x11_241795);
            }
          }
          default: return heff_nomatch(v_x1_241794);
          }
        }
        default: return heff_nomatch(v_x11_241789);
        }
      }
      default: return heff_nomatch(v_x1_241788);
      }
    }
    default: return heff_nomatch(v_e02_24779);
    }
  }
  case TAG_Do: {
    V v_kw_241809 = heff_dup(heff_field(v_e0_241, 0));
    V v_stmts_241810 = heff_dup(heff_field(v_e0_241, 1));
    HeffT2 v_t_241812 = (g_heff_2esyntax_2esurface_2eblock_24cpr(heff_clo_n(g_heff_2esyntax_2esurface_2eexprL_lam8, 1, 1, (V[]){v_r_240}), v_stmts_241810, v_z_242));
    {
      V v_field_241813 = v_t_241812.f[0];
      V v_field_241814 = v_t_241812.f[1];
      V v_x11_241815 = v_field_241813;
      V v_st_241816 = v_field_241814;
      switch (heff_tag_of(v_x11_241815)) {
      case TAG_Left: {
        V v_e_241817 = heff_field(v_x11_241815, 0);
        V v_ru_24x11_241815_24Left = heff_take_reuse_n(v_x11_241815, 1ULL, 1);
        heff_drop_tag(v_e0_241, 2);
        heff_drop_rec(v_kw_241809, 9);
        return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_241815_24Left, TAG_Left, 1, (V[]){v_e_241817}), v_st_241816});
      }
      case TAG_Right: {
        V v_x_241818 = heff_field(v_x11_241815, 0);
        V v_ru_24x11_241815_24Right = heff_take_reuse_n(v_x11_241815, 1ULL, 1);
        V v_t_241819 = (g_heff_2esyntax_2ecst_2elastE(v_e0_241));
        V v_e_241820 = heff_get_n(v_t_241819, 4, 9);
        V v_t_241821 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_241809, 3, 9), v_e_241820});
        V v_x_241822 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EDo, 1, (V[]){v_x_241818}), v_t_241821});
        return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_241815_24Right, TAG_Right, 1, (V[]){v_x_241822}), v_st_241816});
      }
      default: return heff_nomatch(v_x11_241815);
      }
    }
  }
  case TAG_ESBind: {
    heff_drop_rec(v_r_240, 3);
    V v_t_241826 = (g_heff_2esyntax_2ecst_2efirstE(v_e0_241));
    V v_t_241827 = ({ V a_0 = v_e0_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e0_241, 3); r_; });
    V v_t_241828 = heff_strAppend(heff_get_n(v_t_241827, 1, 9), ((V)&g_heff_2esyntax_2esurface_2eexprL_str31));
    V v_msg_241829 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eexprL_str32), v_t_241828);
    V v_t_241830 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_241826, 3), heff_get_n(v_t_241826, 4, 9)});
    V v_t_241831 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_241829, v_t_241830, NTAG(TAG_Nothing)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_241831}), v_z_242});
  }
  case TAG_ELet: {
    HEFF_LAST return g_heff_2esyntax_2esurface_2eletL(v_r_240, v_e0_241, v_z_242);
  }
  case TAG_ELetMut: {
    heff_drop_rec(v_r_240, 3);
    V v_t_241844 = (g_heff_2esyntax_2ecst_2efirstE(v_e0_241));
    V v_t_241845 = ({ V a_0 = v_e0_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e0_241, 6); r_; });
    V v_t_241846 = heff_strAppend(heff_get_n(v_t_241845, 1, 9), ((V)&g_heff_2esyntax_2esurface_2eexprL_str33));
    V v_msg_241847 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eexprL_str34), v_t_241846);
    V v_t_241848 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_241844, 3), heff_get_n(v_t_241844, 4, 9)});
    V v_t_241849 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_241847, v_t_241848, NTAG(TAG_Nothing)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_241849}), v_z_242});
  }
  case TAG_EAssign: {
    V v_x_241850 = heff_field(v_e0_241, 0);
    V v_e_241852 = heff_field(v_e0_241, 2);
    V v_ru_24e0_241_24EAssign = heff_take_reuse_n(v_e0_241, 5ULL, 3);
    V v_m_241853 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_e_241852)}));
    V v_x1_241854 = heff_tr(heff_call(v_m_241853, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x1_241854)) {
    case TAG_MkPair: {
      V v_x11_241855 = heff_field(v_x1_241854, 0);
      V v_st_241856 = heff_field(v_x1_241854, 1);
      V v_ru_24x1_241854_24MkPair = heff_take_reuse_n(v_x1_241854, 3ULL, 2);
      switch (heff_tag_of(v_x11_241855)) {
      case TAG_Left: {
        V v_e_241857 = heff_field(v_x11_241855, 0);
        heff_take_n(v_x11_241855, 1ULL, 1);
        heff_drop_rec(v_x_241850, 9);
        heff_drop(v_e_241852);
        heff_drop_cell(v_ru_24e0_241_24EAssign, 3);
        return heff_tag_at_n(v_ru_24x1_241854_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241857}), v_st_241856});
      }
      case TAG_Right: {
        V v_x_241858 = heff_field(v_x11_241855, 0);
        heff_take_n(v_x11_241855, 1ULL, 1);
        V v_t_241859 = heff_rec_n(2, shape_start__end, (V[]){heff_dup(heff_rfield(v_x_241850, 3)), heff_take_field(v_x_241850, 4)});
        V v_t_241860 = heff_tag_at_n(v_ru_24e0_241_24EAssign, TAG_EAssign, 3, (V[]){heff_dup(heff_rfield(v_x_241850, 1)), v_t_241859, v_x_241858});
        V v_t_241861 = (g_heff_2esyntax_2ecst_2elastE(v_e_241852));
        V v_e_241862 = heff_get_n(v_t_241861, 4, 9);
        V v_t_241863 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_x_241850, 3, 9), v_e_241862});
        V v_x_241864 = heff_tag_n(TAG_At, 2, (V[]){v_t_241860, v_t_241863});
        return heff_tag_at_n(v_ru_24x1_241854_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_241864}), v_st_241856});
      }
      default: return heff_nomatch(v_x11_241855);
      }
    }
    default: return heff_nomatch(v_x1_241854);
    }
  }
  case TAG_EWhile: {
    V v_kw_241865 = heff_dup(heff_field(v_e0_241, 0));
    V v_c_241866 = heff_dup(heff_field(v_e0_241, 1));
    V v_body_241868 = heff_dup(heff_field(v_e0_241, 3));
    V v_m_241869 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_c_241866}));
    V v_x1_241870 = heff_tr(heff_call(v_m_241869, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x1_241870)) {
    case TAG_MkPair: {
      V v_x11_241871 = heff_field(v_x1_241870, 0);
      V v_st_241872 = heff_field(v_x1_241870, 1);
      V v_ru_24x1_241870_24MkPair = heff_take_reuse_n(v_x1_241870, 3ULL, 2);
      switch (heff_tag_of(v_x11_241871)) {
      case TAG_Left: {
        V v_e_241873 = heff_field(v_x11_241871, 0);
        heff_take_n(v_x11_241871, 1ULL, 1);
        heff_drop_rec(v_r_240, 3);
        heff_drop_tag(v_e0_241, 4);
        heff_drop_rec(v_kw_241865, 9);
        heff_drop(v_body_241868);
        return heff_tag_at_n(v_ru_24x1_241870_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241873}), v_st_241872});
      }
      case TAG_Right: {
        V v_x_241874 = heff_field(v_x11_241871, 0);
        heff_take_n(v_x11_241871, 1ULL, 1);
        HeffT2 v_t_241876 = (g_heff_2esyntax_2esurface_2eblock_24cpr(heff_clo_n(g_heff_2esyntax_2esurface_2eexprL_lam9, 1, 1, (V[]){v_r_240}), v_body_241868, v_st_241872));
        {
          V v_field_241877 = v_t_241876.f[0];
          V v_field_241878 = v_t_241876.f[1];
          V v_x11_241879 = v_field_241877;
          V v_st_241880 = v_field_241878;
          switch (heff_tag_of(v_x11_241879)) {
          case TAG_Left: {
            V v_e_241881 = heff_field(v_x11_241879, 0);
            heff_take_n(v_x11_241879, 1ULL, 1);
            heff_drop_tag(v_e0_241, 4);
            heff_drop_rec(v_kw_241865, 9);
            heff_drop(v_x_241874);
            return heff_tag_at_n(v_ru_24x1_241870_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241881}), v_st_241880});
          }
          case TAG_Right: {
            V v_x_241882 = heff_field(v_x11_241879, 0);
            heff_take_n(v_x11_241879, 1ULL, 1);
            V v_t_241883 = (g_heff_2esyntax_2ecst_2elastE(v_e0_241));
            V v_e_241884 = heff_get_n(v_t_241883, 4, 9);
            V v_t_241885 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_241865, 3, 9), v_e_241884});
            V v_x_241886 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EWhile, 2, (V[]){v_x_241874, v_x_241882}), v_t_241885});
            return heff_tag_at_n(v_ru_24x1_241870_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_241886}), v_st_241880});
          }
          default: return heff_nomatch(v_x11_241879);
          }
        }
      }
      default: return heff_nomatch(v_x11_241871);
      }
    }
    default: return heff_nomatch(v_x1_241870);
    }
  }
  case TAG_EFor: {
    V v_kw_241887 = heff_dup(heff_field(v_e0_241, 0));
    V v_p_241888 = heff_dup(heff_field(v_e0_241, 1));
    V v_c_241890 = heff_dup(heff_field(v_e0_241, 3));
    V v_body_241892 = heff_dup(heff_field(v_e0_241, 5));
    V v_m_241893 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_c_241890}));
    V v_x1_241894 = heff_tr(heff_call(v_m_241893, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x1_241894)) {
    case TAG_MkPair: {
      V v_x11_241895 = heff_field(v_x1_241894, 0);
      V v_st_241896 = heff_field(v_x1_241894, 1);
      V v_ru_24x1_241894_24MkPair = heff_take_reuse_n(v_x1_241894, 3ULL, 2);
      switch (heff_tag_of(v_x11_241895)) {
      case TAG_Left: {
        V v_e_241897 = heff_field(v_x11_241895, 0);
        heff_take_n(v_x11_241895, 1ULL, 1);
        heff_drop_rec(v_r_240, 3);
        heff_drop_tag(v_e0_241, 6);
        heff_drop_rec(v_kw_241887, 9);
        heff_drop(v_p_241888);
        heff_drop(v_body_241892);
        return heff_tag_at_n(v_ru_24x1_241894_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241897}), v_st_241896});
      }
      case TAG_Right: {
        V v_x_241898 = heff_field(v_x11_241895, 0);
        heff_take_n(v_x11_241895, 1ULL, 1);
        V v_m_241899 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 1)), 1, (V[]){heff_dup(v_p_241888)}));
        V v_x1_241900 = heff_tr(heff_call(v_m_241899, 1, (V[]){v_st_241896}));
        switch (heff_tag_of(v_x1_241900)) {
        case TAG_MkPair: {
          V v_x11_241901 = heff_field(v_x1_241900, 0);
          V v_st_241902 = heff_field(v_x1_241900, 1);
          V v_ru_24x1_241900_24MkPair = heff_take_reuse_n(v_x1_241900, 3ULL, 2);
          switch (heff_tag_of(v_x11_241901)) {
          case TAG_Left: {
            V v_e_241903 = heff_field(v_x11_241901, 0);
            heff_take_n(v_x11_241901, 1ULL, 1);
            heff_drop_rec(v_r_240, 3);
            heff_drop_tag(v_e0_241, 6);
            heff_drop_rec(v_kw_241887, 9);
            heff_drop(v_p_241888);
            heff_drop(v_body_241892);
            heff_drop(v_x_241898);
            heff_drop_cell(v_ru_24x1_241900_24MkPair, 2);
            return heff_tag_at_n(v_ru_24x1_241894_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241903}), v_st_241902});
          }
          case TAG_Right: {
            V v_x_241904 = heff_field(v_x11_241901, 0);
            heff_take_n(v_x11_241901, 1ULL, 1);
            V v_t_241905 = ({ V b_0 = NTAG(TAG_Nil); V a_1 = v_p_241888; V r_ = (g_heff_2esyntax_2esurface_2eboundBy(b_0, a_1)); heff_drop(b_0); heff_drop(v_p_241888); r_; });
            V v_t_241907 = heff_tr(heff_call(((V)&g_heff_2esyntax_2esurface_2eblock_clo), 2, (V[]){heff_clo_n(g_heff_2esyntax_2esurface_2eexprL_lam10, 1, 1, (V[]){v_r_240}), v_body_241892}));
            HeffT2 v_t_241908 = (g_heff_2esyntax_2esurface_2ewithScope_24cpr(v_t_241905, v_t_241907, v_st_241902));
            {
              V v_field_241909 = v_t_241908.f[0];
              V v_field_241910 = v_t_241908.f[1];
              V v_x11_241911 = v_field_241909;
              V v_st_241912 = v_field_241910;
              switch (heff_tag_of(v_x11_241911)) {
              case TAG_Left: {
                V v_e_241913 = heff_field(v_x11_241911, 0);
                heff_take_n(v_x11_241911, 1ULL, 1);
                heff_drop_tag(v_e0_241, 6);
                heff_drop_rec(v_kw_241887, 9);
                heff_drop(v_x_241898);
                heff_drop_cell(v_ru_24x1_241900_24MkPair, 2);
                heff_drop(v_x_241904);
                return heff_tag_at_n(v_ru_24x1_241894_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241913}), v_st_241912});
              }
              case TAG_Right: {
                V v_x_241914 = heff_field(v_x11_241911, 0);
                heff_take_n(v_x11_241911, 1ULL, 1);
                V v_t_241915 = (g_heff_2esyntax_2ecst_2elastE(v_e0_241));
                V v_e_241916 = heff_get_n(v_t_241915, 4, 9);
                V v_t_241917 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_241887, 3, 9), v_e_241916});
                V v_x_241918 = heff_tag_at_n(v_ru_24x1_241900_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_EFor, 3, (V[]){v_x_241904, v_x_241898, v_x_241914}), v_t_241917});
                return heff_tag_at_n(v_ru_24x1_241894_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_241918}), v_st_241912});
              }
              default: return heff_nomatch(v_x11_241911);
              }
            }
          }
          default: return heff_nomatch(v_x11_241901);
          }
        }
        default: return heff_nomatch(v_x1_241900);
        }
      }
      default: return heff_nomatch(v_x11_241895);
      }
    }
    default: return heff_nomatch(v_x1_241894);
    }
  }
  case TAG_EJump: {
    V v_kw_241919 = heff_field(v_e0_241, 0);
    V v_ru_24e0_241_24EJump = heff_take_reuse_n(v_e0_241, 1ULL, 1);
    heff_drop_rec(v_r_240, 3);
    V v_t_241921;
    if (heff_strEq_c(heff_dup(heff_rfield(v_kw_241919, 1)), ((V)&g_heff_2esyntax_2esurface_2eexprL_str35))) {
      v_t_241921 = NTAG(TAG_EBreak);
    } else {
      v_t_241921 = NTAG(TAG_EContinue);
    }
    V v_t_241922 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_kw_241919, 3), heff_get_n(v_kw_241919, 4, 9)});
    V v_t_241923 = heff_tag_at_n(v_ru_24e0_241_24EJump, TAG_Right, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_241921, v_t_241922})});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_241923, v_z_242});
  }
  case TAG_EReturn: {
    V v_kw_241924 = heff_field(v_e0_241, 0);
    V v_e_241925 = heff_field(v_e0_241, 1);
    V v_ru_24e0_241_24EReturn = heff_take_reuse_n(v_e0_241, 3ULL, 2);
    V v_m_241926 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_e_241925)}));
    V v_x1_241927 = heff_tr(heff_call(v_m_241926, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x1_241927)) {
    case TAG_MkPair: {
      V v_x11_241928 = heff_field(v_x1_241927, 0);
      V v_st_241929 = heff_field(v_x1_241927, 1);
      V v_ru_24x1_241927_24MkPair = heff_take_reuse_n(v_x1_241927, 3ULL, 2);
      switch (heff_tag_of(v_x11_241928)) {
      case TAG_Left: {
        V v_e_241930 = heff_field(v_x11_241928, 0);
        heff_take_n(v_x11_241928, 1ULL, 1);
        heff_drop_rec(v_kw_241924, 9);
        heff_drop(v_e_241925);
        heff_drop_cell(v_ru_24x1_241927_24MkPair, 2);
        return heff_tag_at_n(v_ru_24e0_241_24EReturn, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241930}), v_st_241929});
      }
      case TAG_Right: {
        V v_x_241931 = heff_field(v_x11_241928, 0);
        heff_take_n(v_x11_241928, 1ULL, 1);
        V v_t_241932 = (g_heff_2esyntax_2ecst_2elastE(v_e_241925));
        V v_e_241933 = heff_get_n(v_t_241932, 4, 9);
        V v_t_241934 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_241924, 3, 9), v_e_241933});
        V v_x_241935 = heff_tag_at_n(v_ru_24e0_241_24EReturn, TAG_At, 2, (V[]){heff_tag_n(TAG_EReturn, 1, (V[]){v_x_241931}), v_t_241934});
        return heff_tag_at_n(v_ru_24x1_241927_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_241935}), v_st_241929});
      }
      default: return heff_nomatch(v_x11_241928);
      }
    }
    default: return heff_nomatch(v_x1_241927);
    }
  }
  case TAG_ENest: {
    V v_o_241936 = heff_field(v_e0_241, 0);
    V v_e_241938 = heff_field(v_e0_241, 2);
    V v_c_241939 = heff_field(v_e0_241, 3);
    heff_take_n(v_e0_241, 13ULL, 4);
    V v_m_241940 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_241938}));
    V v_x1_241941 = heff_tr(heff_call(v_m_241940, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x1_241941)) {
    case TAG_MkPair: {
      V v_x11_241942 = heff_field(v_x1_241941, 0);
      V v_st_241943 = heff_field(v_x1_241941, 1);
      V v_ru_24x1_241941_24MkPair = heff_take_reuse_n(v_x1_241941, 3ULL, 2);
      switch (heff_tag_of(v_x11_241942)) {
      case TAG_Left: {
        V v_e_241944 = heff_field(v_x11_241942, 0);
        heff_take_n(v_x11_241942, 1ULL, 1);
        heff_drop_rec(v_o_241936, 9);
        heff_drop_rec(v_c_241939, 9);
        return heff_tag_at_n(v_ru_24x1_241941_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241944}), v_st_241943});
      }
      case TAG_Right: {
        V v_x_241945 = heff_field(v_x11_241942, 0);
        V v_ru_24x11_241942_24Right = heff_take_reuse_n(v_x11_241942, 1ULL, 1);
        V v_t_241946 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_o_241936, 3, 9), heff_get_n(v_c_241939, 4, 9)});
        V v_t_241947 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_241942_24Right, TAG_ENest, 1, (V[]){v_x_241945}), v_t_241946});
        return heff_tag_at_n(v_ru_24x1_241941_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_241947}), v_st_241943});
      }
      default: return heff_nomatch(v_x11_241942);
      }
    }
    default: return heff_nomatch(v_x1_241941);
    }
  }
  case TAG_IfThen: {
    V v_kw_241948 = heff_field(v_e0_241, 0);
    V v_e02_241949 = heff_field(v_e0_241, 1);
    V v_a_241951 = heff_field(v_e0_241, 3);
    heff_take_n(v_e0_241, 11ULL, 4);
    switch (heff_tag_of(v_e02_241949)) {
    case TAG_Atom: {
      V v_m_241953 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_241949}));
      V v_x1_241954 = heff_tr(heff_call(v_m_241953, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_241954)) {
      case TAG_MkPair: {
        V v_x11_241955 = heff_field(v_x1_241954, 0);
        V v_st_241956 = heff_field(v_x1_241954, 1);
        V v_ru_24x1_241954_24MkPair = heff_take_reuse_n(v_x1_241954, 3ULL, 2);
        switch (heff_tag_of(v_x11_241955)) {
        case TAG_Left: {
          V v_e_241957 = heff_field(v_x11_241955, 0);
          heff_take_n(v_x11_241955, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_241948, 9);
          heff_drop(v_a_241951);
          return heff_tag_at_n(v_ru_24x1_241954_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241957}), v_st_241956});
        }
        case TAG_Right: {
          V v_x_241958 = heff_field(v_x11_241955, 0);
          heff_take_n(v_x11_241955, 1ULL, 1);
          V v_m_241959 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_a_241951)}));
          V v_x1_241960 = heff_tr(heff_call(v_m_241959, 1, (V[]){v_st_241956}));
          switch (heff_tag_of(v_x1_241960)) {
          case TAG_MkPair: {
            V v_x11_241961 = heff_field(v_x1_241960, 0);
            V v_st_241962 = heff_field(v_x1_241960, 1);
            V v_ru_24x1_241960_24MkPair = heff_take_reuse_n(v_x1_241960, 3ULL, 2);
            switch (heff_tag_of(v_x11_241961)) {
            case TAG_Left: {
              V v_e_241963 = heff_field(v_x11_241961, 0);
              heff_take_n(v_x11_241961, 1ULL, 1);
              heff_drop_rec(v_kw_241948, 9);
              heff_drop(v_a_241951);
              heff_drop(v_x_241958);
              heff_drop_cell(v_ru_24x1_241960_24MkPair, 2);
              return heff_tag_at_n(v_ru_24x1_241954_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241963}), v_st_241962});
            }
            case TAG_Right: {
              V v_x_241964 = heff_field(v_x11_241961, 0);
              heff_take_n(v_x11_241961, 1ULL, 1);
              V v_t_241965 = (g_heff_2esyntax_2ecst_2elastE(v_a_241951));
              V v_e_241966 = heff_get_n(v_t_241965, 4, 9);
              V v_t_241967 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_241948, 3, 9), v_e_241966});
              V v_x_241968 = heff_tag_at_n(v_ru_24x1_241960_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_EIfThen, 2, (V[]){v_x_241958, v_x_241964}), v_t_241967});
              return heff_tag_at_n(v_ru_24x1_241954_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_241968}), v_st_241962});
            }
            default: return heff_nomatch(v_x11_241961);
            }
          }
          default: return heff_nomatch(v_x1_241960);
          }
        }
        default: return heff_nomatch(v_x11_241955);
        }
      }
      default: return heff_nomatch(v_x1_241954);
      }
    }
    case TAG_EParen: {
      V v_m_241972 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_241949}));
      V v_x1_241973 = heff_tr(heff_call(v_m_241972, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_241973)) {
      case TAG_MkPair: {
        V v_x11_241974 = heff_field(v_x1_241973, 0);
        V v_st_241975 = heff_field(v_x1_241973, 1);
        V v_ru_24x1_241973_24MkPair = heff_take_reuse_n(v_x1_241973, 3ULL, 2);
        switch (heff_tag_of(v_x11_241974)) {
        case TAG_Left: {
          V v_e_241976 = heff_field(v_x11_241974, 0);
          heff_take_n(v_x11_241974, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_241948, 9);
          heff_drop(v_a_241951);
          return heff_tag_at_n(v_ru_24x1_241973_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241976}), v_st_241975});
        }
        case TAG_Right: {
          V v_x_241977 = heff_field(v_x11_241974, 0);
          heff_take_n(v_x11_241974, 1ULL, 1);
          V v_m_241978 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_a_241951)}));
          V v_x1_241979 = heff_tr(heff_call(v_m_241978, 1, (V[]){v_st_241975}));
          switch (heff_tag_of(v_x1_241979)) {
          case TAG_MkPair: {
            V v_x11_241980 = heff_field(v_x1_241979, 0);
            V v_st_241981 = heff_field(v_x1_241979, 1);
            V v_ru_24x1_241979_24MkPair = heff_take_reuse_n(v_x1_241979, 3ULL, 2);
            switch (heff_tag_of(v_x11_241980)) {
            case TAG_Left: {
              V v_e_241982 = heff_field(v_x11_241980, 0);
              heff_take_n(v_x11_241980, 1ULL, 1);
              heff_drop_rec(v_kw_241948, 9);
              heff_drop(v_a_241951);
              heff_drop(v_x_241977);
              heff_drop_cell(v_ru_24x1_241979_24MkPair, 2);
              return heff_tag_at_n(v_ru_24x1_241973_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241982}), v_st_241981});
            }
            case TAG_Right: {
              V v_x_241983 = heff_field(v_x11_241980, 0);
              heff_take_n(v_x11_241980, 1ULL, 1);
              V v_t_241984 = (g_heff_2esyntax_2ecst_2elastE(v_a_241951));
              V v_e_241985 = heff_get_n(v_t_241984, 4, 9);
              V v_t_241986 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_241948, 3, 9), v_e_241985});
              V v_x_241987 = heff_tag_at_n(v_ru_24x1_241979_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_EIfThen, 2, (V[]){v_x_241977, v_x_241983}), v_t_241986});
              return heff_tag_at_n(v_ru_24x1_241973_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_241987}), v_st_241981});
            }
            default: return heff_nomatch(v_x11_241980);
            }
          }
          default: return heff_nomatch(v_x1_241979);
          }
        }
        default: return heff_nomatch(v_x11_241974);
        }
      }
      default: return heff_nomatch(v_x1_241973);
      }
    }
    case TAG_Named: {
      V v_m_241993 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_241949}));
      V v_x1_241994 = heff_tr(heff_call(v_m_241993, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_241994)) {
      case TAG_MkPair: {
        V v_x11_241995 = heff_field(v_x1_241994, 0);
        V v_st_241996 = heff_field(v_x1_241994, 1);
        V v_ru_24x1_241994_24MkPair = heff_take_reuse_n(v_x1_241994, 3ULL, 2);
        switch (heff_tag_of(v_x11_241995)) {
        case TAG_Left: {
          V v_e_241997 = heff_field(v_x11_241995, 0);
          heff_take_n(v_x11_241995, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_241948, 9);
          heff_drop(v_a_241951);
          return heff_tag_at_n(v_ru_24x1_241994_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241997}), v_st_241996});
        }
        case TAG_Right: {
          V v_x_241998 = heff_field(v_x11_241995, 0);
          heff_take_n(v_x11_241995, 1ULL, 1);
          V v_m_241999 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_a_241951)}));
          V v_x1_242000 = heff_tr(heff_call(v_m_241999, 1, (V[]){v_st_241996}));
          switch (heff_tag_of(v_x1_242000)) {
          case TAG_MkPair: {
            V v_x11_242001 = heff_field(v_x1_242000, 0);
            V v_st_242002 = heff_field(v_x1_242000, 1);
            V v_ru_24x1_242000_24MkPair = heff_take_reuse_n(v_x1_242000, 3ULL, 2);
            switch (heff_tag_of(v_x11_242001)) {
            case TAG_Left: {
              V v_e_242003 = heff_field(v_x11_242001, 0);
              heff_take_n(v_x11_242001, 1ULL, 1);
              heff_drop_rec(v_kw_241948, 9);
              heff_drop(v_a_241951);
              heff_drop(v_x_241998);
              heff_drop_cell(v_ru_24x1_242000_24MkPair, 2);
              return heff_tag_at_n(v_ru_24x1_241994_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242003}), v_st_242002});
            }
            case TAG_Right: {
              V v_x_242004 = heff_field(v_x11_242001, 0);
              heff_take_n(v_x11_242001, 1ULL, 1);
              V v_t_242005 = (g_heff_2esyntax_2ecst_2elastE(v_a_241951));
              V v_e_242006 = heff_get_n(v_t_242005, 4, 9);
              V v_t_242007 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_241948, 3, 9), v_e_242006});
              V v_x_242008 = heff_tag_at_n(v_ru_24x1_242000_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_EIfThen, 2, (V[]){v_x_241998, v_x_242004}), v_t_242007});
              return heff_tag_at_n(v_ru_24x1_241994_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_242008}), v_st_242002});
            }
            default: return heff_nomatch(v_x11_242001);
            }
          }
          default: return heff_nomatch(v_x1_242000);
          }
        }
        default: return heff_nomatch(v_x11_241995);
        }
      }
      default: return heff_nomatch(v_x1_241994);
      }
    }
    case TAG_Tup: {
      V v_m_242013 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_241949}));
      V v_x1_242014 = heff_tr(heff_call(v_m_242013, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_242014)) {
      case TAG_MkPair: {
        V v_x11_242015 = heff_field(v_x1_242014, 0);
        V v_st_242016 = heff_field(v_x1_242014, 1);
        V v_ru_24x1_242014_24MkPair = heff_take_reuse_n(v_x1_242014, 3ULL, 2);
        switch (heff_tag_of(v_x11_242015)) {
        case TAG_Left: {
          V v_e_242017 = heff_field(v_x11_242015, 0);
          heff_take_n(v_x11_242015, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_241948, 9);
          heff_drop(v_a_241951);
          return heff_tag_at_n(v_ru_24x1_242014_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242017}), v_st_242016});
        }
        case TAG_Right: {
          V v_x_242018 = heff_field(v_x11_242015, 0);
          heff_take_n(v_x11_242015, 1ULL, 1);
          V v_m_242019 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_a_241951)}));
          V v_x1_242020 = heff_tr(heff_call(v_m_242019, 1, (V[]){v_st_242016}));
          switch (heff_tag_of(v_x1_242020)) {
          case TAG_MkPair: {
            V v_x11_242021 = heff_field(v_x1_242020, 0);
            V v_st_242022 = heff_field(v_x1_242020, 1);
            V v_ru_24x1_242020_24MkPair = heff_take_reuse_n(v_x1_242020, 3ULL, 2);
            switch (heff_tag_of(v_x11_242021)) {
            case TAG_Left: {
              V v_e_242023 = heff_field(v_x11_242021, 0);
              heff_take_n(v_x11_242021, 1ULL, 1);
              heff_drop_rec(v_kw_241948, 9);
              heff_drop(v_a_241951);
              heff_drop(v_x_242018);
              heff_drop_cell(v_ru_24x1_242020_24MkPair, 2);
              return heff_tag_at_n(v_ru_24x1_242014_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242023}), v_st_242022});
            }
            case TAG_Right: {
              V v_x_242024 = heff_field(v_x11_242021, 0);
              heff_take_n(v_x11_242021, 1ULL, 1);
              V v_t_242025 = (g_heff_2esyntax_2ecst_2elastE(v_a_241951));
              V v_e_242026 = heff_get_n(v_t_242025, 4, 9);
              V v_t_242027 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_241948, 3, 9), v_e_242026});
              V v_x_242028 = heff_tag_at_n(v_ru_24x1_242020_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_EIfThen, 2, (V[]){v_x_242018, v_x_242024}), v_t_242027});
              return heff_tag_at_n(v_ru_24x1_242014_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_242028}), v_st_242022});
            }
            default: return heff_nomatch(v_x11_242021);
            }
          }
          default: return heff_nomatch(v_x1_242020);
          }
        }
        default: return heff_nomatch(v_x11_242015);
        }
      }
      default: return heff_nomatch(v_x1_242014);
      }
    }
    case TAG_Seg: {
      V v_m_242032 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_241949}));
      V v_x1_242033 = heff_tr(heff_call(v_m_242032, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_242033)) {
      case TAG_MkPair: {
        V v_x11_242034 = heff_field(v_x1_242033, 0);
        V v_st_242035 = heff_field(v_x1_242033, 1);
        V v_ru_24x1_242033_24MkPair = heff_take_reuse_n(v_x1_242033, 3ULL, 2);
        switch (heff_tag_of(v_x11_242034)) {
        case TAG_Left: {
          V v_e_242036 = heff_field(v_x11_242034, 0);
          heff_take_n(v_x11_242034, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_241948, 9);
          heff_drop(v_a_241951);
          return heff_tag_at_n(v_ru_24x1_242033_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242036}), v_st_242035});
        }
        case TAG_Right: {
          V v_x_242037 = heff_field(v_x11_242034, 0);
          heff_take_n(v_x11_242034, 1ULL, 1);
          V v_m_242038 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_a_241951)}));
          V v_x1_242039 = heff_tr(heff_call(v_m_242038, 1, (V[]){v_st_242035}));
          switch (heff_tag_of(v_x1_242039)) {
          case TAG_MkPair: {
            V v_x11_242040 = heff_field(v_x1_242039, 0);
            V v_st_242041 = heff_field(v_x1_242039, 1);
            V v_ru_24x1_242039_24MkPair = heff_take_reuse_n(v_x1_242039, 3ULL, 2);
            switch (heff_tag_of(v_x11_242040)) {
            case TAG_Left: {
              V v_e_242042 = heff_field(v_x11_242040, 0);
              heff_take_n(v_x11_242040, 1ULL, 1);
              heff_drop_rec(v_kw_241948, 9);
              heff_drop(v_a_241951);
              heff_drop(v_x_242037);
              heff_drop_cell(v_ru_24x1_242039_24MkPair, 2);
              return heff_tag_at_n(v_ru_24x1_242033_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242042}), v_st_242041});
            }
            case TAG_Right: {
              V v_x_242043 = heff_field(v_x11_242040, 0);
              heff_take_n(v_x11_242040, 1ULL, 1);
              V v_t_242044 = (g_heff_2esyntax_2ecst_2elastE(v_a_241951));
              V v_e_242045 = heff_get_n(v_t_242044, 4, 9);
              V v_t_242046 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_241948, 3, 9), v_e_242045});
              V v_x_242047 = heff_tag_at_n(v_ru_24x1_242039_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_EIfThen, 2, (V[]){v_x_242037, v_x_242043}), v_t_242046});
              return heff_tag_at_n(v_ru_24x1_242033_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_242047}), v_st_242041});
            }
            default: return heff_nomatch(v_x11_242040);
            }
          }
          default: return heff_nomatch(v_x1_242039);
          }
        }
        default: return heff_nomatch(v_x11_242034);
        }
      }
      default: return heff_nomatch(v_x1_242033);
      }
    }
    case TAG_Braces: {
      V v_m_242052 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_241949}));
      V v_x1_242053 = heff_tr(heff_call(v_m_242052, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_242053)) {
      case TAG_MkPair: {
        V v_x11_242054 = heff_field(v_x1_242053, 0);
        V v_st_242055 = heff_field(v_x1_242053, 1);
        V v_ru_24x1_242053_24MkPair = heff_take_reuse_n(v_x1_242053, 3ULL, 2);
        switch (heff_tag_of(v_x11_242054)) {
        case TAG_Left: {
          V v_e_242056 = heff_field(v_x11_242054, 0);
          heff_take_n(v_x11_242054, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_241948, 9);
          heff_drop(v_a_241951);
          return heff_tag_at_n(v_ru_24x1_242053_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242056}), v_st_242055});
        }
        case TAG_Right: {
          V v_x_242057 = heff_field(v_x11_242054, 0);
          heff_take_n(v_x11_242054, 1ULL, 1);
          V v_m_242058 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_a_241951)}));
          V v_x1_242059 = heff_tr(heff_call(v_m_242058, 1, (V[]){v_st_242055}));
          switch (heff_tag_of(v_x1_242059)) {
          case TAG_MkPair: {
            V v_x11_242060 = heff_field(v_x1_242059, 0);
            V v_st_242061 = heff_field(v_x1_242059, 1);
            V v_ru_24x1_242059_24MkPair = heff_take_reuse_n(v_x1_242059, 3ULL, 2);
            switch (heff_tag_of(v_x11_242060)) {
            case TAG_Left: {
              V v_e_242062 = heff_field(v_x11_242060, 0);
              heff_take_n(v_x11_242060, 1ULL, 1);
              heff_drop_rec(v_kw_241948, 9);
              heff_drop(v_a_241951);
              heff_drop(v_x_242057);
              heff_drop_cell(v_ru_24x1_242059_24MkPair, 2);
              return heff_tag_at_n(v_ru_24x1_242053_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242062}), v_st_242061});
            }
            case TAG_Right: {
              V v_x_242063 = heff_field(v_x11_242060, 0);
              heff_take_n(v_x11_242060, 1ULL, 1);
              V v_t_242064 = (g_heff_2esyntax_2ecst_2elastE(v_a_241951));
              V v_e_242065 = heff_get_n(v_t_242064, 4, 9);
              V v_t_242066 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_241948, 3, 9), v_e_242065});
              V v_x_242067 = heff_tag_at_n(v_ru_24x1_242059_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_EIfThen, 2, (V[]){v_x_242057, v_x_242063}), v_t_242066});
              return heff_tag_at_n(v_ru_24x1_242053_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_242067}), v_st_242061});
            }
            default: return heff_nomatch(v_x11_242060);
            }
          }
          default: return heff_nomatch(v_x1_242059);
          }
        }
        default: return heff_nomatch(v_x11_242054);
        }
      }
      default: return heff_nomatch(v_x1_242053);
      }
    }
    case TAG_Update: {
      V v_m_242074 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_241949}));
      V v_x1_242075 = heff_tr(heff_call(v_m_242074, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_242075)) {
      case TAG_MkPair: {
        V v_x11_242076 = heff_field(v_x1_242075, 0);
        V v_st_242077 = heff_field(v_x1_242075, 1);
        V v_ru_24x1_242075_24MkPair = heff_take_reuse_n(v_x1_242075, 3ULL, 2);
        switch (heff_tag_of(v_x11_242076)) {
        case TAG_Left: {
          V v_e_242078 = heff_field(v_x11_242076, 0);
          heff_take_n(v_x11_242076, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_241948, 9);
          heff_drop(v_a_241951);
          return heff_tag_at_n(v_ru_24x1_242075_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242078}), v_st_242077});
        }
        case TAG_Right: {
          V v_x_242079 = heff_field(v_x11_242076, 0);
          heff_take_n(v_x11_242076, 1ULL, 1);
          V v_m_242080 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_a_241951)}));
          V v_x1_242081 = heff_tr(heff_call(v_m_242080, 1, (V[]){v_st_242077}));
          switch (heff_tag_of(v_x1_242081)) {
          case TAG_MkPair: {
            V v_x11_242082 = heff_field(v_x1_242081, 0);
            V v_st_242083 = heff_field(v_x1_242081, 1);
            V v_ru_24x1_242081_24MkPair = heff_take_reuse_n(v_x1_242081, 3ULL, 2);
            switch (heff_tag_of(v_x11_242082)) {
            case TAG_Left: {
              V v_e_242084 = heff_field(v_x11_242082, 0);
              heff_take_n(v_x11_242082, 1ULL, 1);
              heff_drop_rec(v_kw_241948, 9);
              heff_drop(v_a_241951);
              heff_drop(v_x_242079);
              heff_drop_cell(v_ru_24x1_242081_24MkPair, 2);
              return heff_tag_at_n(v_ru_24x1_242075_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242084}), v_st_242083});
            }
            case TAG_Right: {
              V v_x_242085 = heff_field(v_x11_242082, 0);
              heff_take_n(v_x11_242082, 1ULL, 1);
              V v_t_242086 = (g_heff_2esyntax_2ecst_2elastE(v_a_241951));
              V v_e_242087 = heff_get_n(v_t_242086, 4, 9);
              V v_t_242088 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_241948, 3, 9), v_e_242087});
              V v_x_242089 = heff_tag_at_n(v_ru_24x1_242081_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_EIfThen, 2, (V[]){v_x_242079, v_x_242085}), v_t_242088});
              return heff_tag_at_n(v_ru_24x1_242075_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_242089}), v_st_242083});
            }
            default: return heff_nomatch(v_x11_242082);
            }
          }
          default: return heff_nomatch(v_x1_242081);
          }
        }
        default: return heff_nomatch(v_x11_242076);
        }
      }
      default: return heff_nomatch(v_x1_242075);
      }
    }
    case TAG_EUSet: {
      V v_m_242093 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_241949}));
      V v_x1_242094 = heff_tr(heff_call(v_m_242093, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_242094)) {
      case TAG_MkPair: {
        V v_x11_242095 = heff_field(v_x1_242094, 0);
        V v_st_242096 = heff_field(v_x1_242094, 1);
        V v_ru_24x1_242094_24MkPair = heff_take_reuse_n(v_x1_242094, 3ULL, 2);
        switch (heff_tag_of(v_x11_242095)) {
        case TAG_Left: {
          V v_e_242097 = heff_field(v_x11_242095, 0);
          heff_take_n(v_x11_242095, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_241948, 9);
          heff_drop(v_a_241951);
          return heff_tag_at_n(v_ru_24x1_242094_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242097}), v_st_242096});
        }
        case TAG_Right: {
          V v_x_242098 = heff_field(v_x11_242095, 0);
          heff_take_n(v_x11_242095, 1ULL, 1);
          V v_m_242099 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_a_241951)}));
          V v_x1_242100 = heff_tr(heff_call(v_m_242099, 1, (V[]){v_st_242096}));
          switch (heff_tag_of(v_x1_242100)) {
          case TAG_MkPair: {
            V v_x11_242101 = heff_field(v_x1_242100, 0);
            V v_st_242102 = heff_field(v_x1_242100, 1);
            V v_ru_24x1_242100_24MkPair = heff_take_reuse_n(v_x1_242100, 3ULL, 2);
            switch (heff_tag_of(v_x11_242101)) {
            case TAG_Left: {
              V v_e_242103 = heff_field(v_x11_242101, 0);
              heff_take_n(v_x11_242101, 1ULL, 1);
              heff_drop_rec(v_kw_241948, 9);
              heff_drop(v_a_241951);
              heff_drop(v_x_242098);
              heff_drop_cell(v_ru_24x1_242100_24MkPair, 2);
              return heff_tag_at_n(v_ru_24x1_242094_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242103}), v_st_242102});
            }
            case TAG_Right: {
              V v_x_242104 = heff_field(v_x11_242101, 0);
              heff_take_n(v_x11_242101, 1ULL, 1);
              V v_t_242105 = (g_heff_2esyntax_2ecst_2elastE(v_a_241951));
              V v_e_242106 = heff_get_n(v_t_242105, 4, 9);
              V v_t_242107 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_241948, 3, 9), v_e_242106});
              V v_x_242108 = heff_tag_at_n(v_ru_24x1_242100_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_EIfThen, 2, (V[]){v_x_242098, v_x_242104}), v_t_242107});
              return heff_tag_at_n(v_ru_24x1_242094_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_242108}), v_st_242102});
            }
            default: return heff_nomatch(v_x11_242101);
            }
          }
          default: return heff_nomatch(v_x1_242100);
          }
        }
        default: return heff_nomatch(v_x11_242095);
        }
      }
      default: return heff_nomatch(v_x1_242094);
      }
    }
    case TAG_InstB: {
      V v_m_242114 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_241949}));
      V v_x1_242115 = heff_tr(heff_call(v_m_242114, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_242115)) {
      case TAG_MkPair: {
        V v_x11_242116 = heff_field(v_x1_242115, 0);
        V v_st_242117 = heff_field(v_x1_242115, 1);
        V v_ru_24x1_242115_24MkPair = heff_take_reuse_n(v_x1_242115, 3ULL, 2);
        switch (heff_tag_of(v_x11_242116)) {
        case TAG_Left: {
          V v_e_242118 = heff_field(v_x11_242116, 0);
          heff_take_n(v_x11_242116, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_241948, 9);
          heff_drop(v_a_241951);
          return heff_tag_at_n(v_ru_24x1_242115_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242118}), v_st_242117});
        }
        case TAG_Right: {
          V v_x_242119 = heff_field(v_x11_242116, 0);
          heff_take_n(v_x11_242116, 1ULL, 1);
          V v_m_242120 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_a_241951)}));
          V v_x1_242121 = heff_tr(heff_call(v_m_242120, 1, (V[]){v_st_242117}));
          switch (heff_tag_of(v_x1_242121)) {
          case TAG_MkPair: {
            V v_x11_242122 = heff_field(v_x1_242121, 0);
            V v_st_242123 = heff_field(v_x1_242121, 1);
            V v_ru_24x1_242121_24MkPair = heff_take_reuse_n(v_x1_242121, 3ULL, 2);
            switch (heff_tag_of(v_x11_242122)) {
            case TAG_Left: {
              V v_e_242124 = heff_field(v_x11_242122, 0);
              heff_take_n(v_x11_242122, 1ULL, 1);
              heff_drop_rec(v_kw_241948, 9);
              heff_drop(v_a_241951);
              heff_drop(v_x_242119);
              heff_drop_cell(v_ru_24x1_242121_24MkPair, 2);
              return heff_tag_at_n(v_ru_24x1_242115_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242124}), v_st_242123});
            }
            case TAG_Right: {
              V v_x_242125 = heff_field(v_x11_242122, 0);
              heff_take_n(v_x11_242122, 1ULL, 1);
              V v_t_242126 = (g_heff_2esyntax_2ecst_2elastE(v_a_241951));
              V v_e_242127 = heff_get_n(v_t_242126, 4, 9);
              V v_t_242128 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_241948, 3, 9), v_e_242127});
              V v_x_242129 = heff_tag_at_n(v_ru_24x1_242121_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_EIfThen, 2, (V[]){v_x_242119, v_x_242125}), v_t_242128});
              return heff_tag_at_n(v_ru_24x1_242115_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_242129}), v_st_242123});
            }
            default: return heff_nomatch(v_x11_242122);
            }
          }
          default: return heff_nomatch(v_x1_242121);
          }
        }
        default: return heff_nomatch(v_x11_242116);
        }
      }
      default: return heff_nomatch(v_x1_242115);
      }
    }
    case TAG_EFSet: {
      V v_m_242133 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_241949}));
      V v_x1_242134 = heff_tr(heff_call(v_m_242133, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_242134)) {
      case TAG_MkPair: {
        V v_x11_242135 = heff_field(v_x1_242134, 0);
        V v_st_242136 = heff_field(v_x1_242134, 1);
        V v_ru_24x1_242134_24MkPair = heff_take_reuse_n(v_x1_242134, 3ULL, 2);
        switch (heff_tag_of(v_x11_242135)) {
        case TAG_Left: {
          V v_e_242137 = heff_field(v_x11_242135, 0);
          heff_take_n(v_x11_242135, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_241948, 9);
          heff_drop(v_a_241951);
          return heff_tag_at_n(v_ru_24x1_242134_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242137}), v_st_242136});
        }
        case TAG_Right: {
          V v_x_242138 = heff_field(v_x11_242135, 0);
          heff_take_n(v_x11_242135, 1ULL, 1);
          V v_m_242139 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_a_241951)}));
          V v_x1_242140 = heff_tr(heff_call(v_m_242139, 1, (V[]){v_st_242136}));
          switch (heff_tag_of(v_x1_242140)) {
          case TAG_MkPair: {
            V v_x11_242141 = heff_field(v_x1_242140, 0);
            V v_st_242142 = heff_field(v_x1_242140, 1);
            V v_ru_24x1_242140_24MkPair = heff_take_reuse_n(v_x1_242140, 3ULL, 2);
            switch (heff_tag_of(v_x11_242141)) {
            case TAG_Left: {
              V v_e_242143 = heff_field(v_x11_242141, 0);
              heff_take_n(v_x11_242141, 1ULL, 1);
              heff_drop_rec(v_kw_241948, 9);
              heff_drop(v_a_241951);
              heff_drop(v_x_242138);
              heff_drop_cell(v_ru_24x1_242140_24MkPair, 2);
              return heff_tag_at_n(v_ru_24x1_242134_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242143}), v_st_242142});
            }
            case TAG_Right: {
              V v_x_242144 = heff_field(v_x11_242141, 0);
              heff_take_n(v_x11_242141, 1ULL, 1);
              V v_t_242145 = (g_heff_2esyntax_2ecst_2elastE(v_a_241951));
              V v_e_242146 = heff_get_n(v_t_242145, 4, 9);
              V v_t_242147 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_241948, 3, 9), v_e_242146});
              V v_x_242148 = heff_tag_at_n(v_ru_24x1_242140_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_EIfThen, 2, (V[]){v_x_242138, v_x_242144}), v_t_242147});
              return heff_tag_at_n(v_ru_24x1_242134_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_242148}), v_st_242142});
            }
            default: return heff_nomatch(v_x11_242141);
            }
          }
          default: return heff_nomatch(v_x1_242140);
          }
        }
        default: return heff_nomatch(v_x11_242135);
        }
      }
      default: return heff_nomatch(v_x1_242134);
      }
    }
    case TAG_EFDefault: {
      V v_m_242152 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_241949}));
      V v_x1_242153 = heff_tr(heff_call(v_m_242152, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_242153)) {
      case TAG_MkPair: {
        V v_x11_242154 = heff_field(v_x1_242153, 0);
        V v_st_242155 = heff_field(v_x1_242153, 1);
        V v_ru_24x1_242153_24MkPair = heff_take_reuse_n(v_x1_242153, 3ULL, 2);
        switch (heff_tag_of(v_x11_242154)) {
        case TAG_Left: {
          V v_e_242156 = heff_field(v_x11_242154, 0);
          heff_take_n(v_x11_242154, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_241948, 9);
          heff_drop(v_a_241951);
          return heff_tag_at_n(v_ru_24x1_242153_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242156}), v_st_242155});
        }
        case TAG_Right: {
          V v_x_242157 = heff_field(v_x11_242154, 0);
          heff_take_n(v_x11_242154, 1ULL, 1);
          V v_m_242158 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_a_241951)}));
          V v_x1_242159 = heff_tr(heff_call(v_m_242158, 1, (V[]){v_st_242155}));
          switch (heff_tag_of(v_x1_242159)) {
          case TAG_MkPair: {
            V v_x11_242160 = heff_field(v_x1_242159, 0);
            V v_st_242161 = heff_field(v_x1_242159, 1);
            V v_ru_24x1_242159_24MkPair = heff_take_reuse_n(v_x1_242159, 3ULL, 2);
            switch (heff_tag_of(v_x11_242160)) {
            case TAG_Left: {
              V v_e_242162 = heff_field(v_x11_242160, 0);
              heff_take_n(v_x11_242160, 1ULL, 1);
              heff_drop_rec(v_kw_241948, 9);
              heff_drop(v_a_241951);
              heff_drop(v_x_242157);
              heff_drop_cell(v_ru_24x1_242159_24MkPair, 2);
              return heff_tag_at_n(v_ru_24x1_242153_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242162}), v_st_242161});
            }
            case TAG_Right: {
              V v_x_242163 = heff_field(v_x11_242160, 0);
              heff_take_n(v_x11_242160, 1ULL, 1);
              V v_t_242164 = (g_heff_2esyntax_2ecst_2elastE(v_a_241951));
              V v_e_242165 = heff_get_n(v_t_242164, 4, 9);
              V v_t_242166 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_241948, 3, 9), v_e_242165});
              V v_x_242167 = heff_tag_at_n(v_ru_24x1_242159_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_EIfThen, 2, (V[]){v_x_242157, v_x_242163}), v_t_242166});
              return heff_tag_at_n(v_ru_24x1_242153_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_242167}), v_st_242161});
            }
            default: return heff_nomatch(v_x11_242160);
            }
          }
          default: return heff_nomatch(v_x1_242159);
          }
        }
        default: return heff_nomatch(v_x11_242154);
        }
      }
      default: return heff_nomatch(v_x1_242153);
      }
    }
    case TAG_Sum: {
      V v_m_242173 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_241949}));
      V v_x1_242174 = heff_tr(heff_call(v_m_242173, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_242174)) {
      case TAG_MkPair: {
        V v_x11_242175 = heff_field(v_x1_242174, 0);
        V v_st_242176 = heff_field(v_x1_242174, 1);
        V v_ru_24x1_242174_24MkPair = heff_take_reuse_n(v_x1_242174, 3ULL, 2);
        switch (heff_tag_of(v_x11_242175)) {
        case TAG_Left: {
          V v_e_242177 = heff_field(v_x11_242175, 0);
          heff_take_n(v_x11_242175, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_241948, 9);
          heff_drop(v_a_241951);
          return heff_tag_at_n(v_ru_24x1_242174_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242177}), v_st_242176});
        }
        case TAG_Right: {
          V v_x_242178 = heff_field(v_x11_242175, 0);
          heff_take_n(v_x11_242175, 1ULL, 1);
          V v_m_242179 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_a_241951)}));
          V v_x1_242180 = heff_tr(heff_call(v_m_242179, 1, (V[]){v_st_242176}));
          switch (heff_tag_of(v_x1_242180)) {
          case TAG_MkPair: {
            V v_x11_242181 = heff_field(v_x1_242180, 0);
            V v_st_242182 = heff_field(v_x1_242180, 1);
            V v_ru_24x1_242180_24MkPair = heff_take_reuse_n(v_x1_242180, 3ULL, 2);
            switch (heff_tag_of(v_x11_242181)) {
            case TAG_Left: {
              V v_e_242183 = heff_field(v_x11_242181, 0);
              heff_take_n(v_x11_242181, 1ULL, 1);
              heff_drop_rec(v_kw_241948, 9);
              heff_drop(v_a_241951);
              heff_drop(v_x_242178);
              heff_drop_cell(v_ru_24x1_242180_24MkPair, 2);
              return heff_tag_at_n(v_ru_24x1_242174_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242183}), v_st_242182});
            }
            case TAG_Right: {
              V v_x_242184 = heff_field(v_x11_242181, 0);
              heff_take_n(v_x11_242181, 1ULL, 1);
              V v_t_242185 = (g_heff_2esyntax_2ecst_2elastE(v_a_241951));
              V v_e_242186 = heff_get_n(v_t_242185, 4, 9);
              V v_t_242187 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_241948, 3, 9), v_e_242186});
              V v_x_242188 = heff_tag_at_n(v_ru_24x1_242180_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_EIfThen, 2, (V[]){v_x_242178, v_x_242184}), v_t_242187});
              return heff_tag_at_n(v_ru_24x1_242174_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_242188}), v_st_242182});
            }
            default: return heff_nomatch(v_x11_242181);
            }
          }
          default: return heff_nomatch(v_x1_242180);
          }
        }
        default: return heff_nomatch(v_x11_242175);
        }
      }
      default: return heff_nomatch(v_x1_242174);
      }
    }
    case TAG_ECon: {
      V v_m_242191 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_241949}));
      V v_x1_242192 = heff_tr(heff_call(v_m_242191, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_242192)) {
      case TAG_MkPair: {
        V v_x11_242193 = heff_field(v_x1_242192, 0);
        V v_st_242194 = heff_field(v_x1_242192, 1);
        V v_ru_24x1_242192_24MkPair = heff_take_reuse_n(v_x1_242192, 3ULL, 2);
        switch (heff_tag_of(v_x11_242193)) {
        case TAG_Left: {
          V v_e_242195 = heff_field(v_x11_242193, 0);
          heff_take_n(v_x11_242193, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_241948, 9);
          heff_drop(v_a_241951);
          return heff_tag_at_n(v_ru_24x1_242192_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242195}), v_st_242194});
        }
        case TAG_Right: {
          V v_x_242196 = heff_field(v_x11_242193, 0);
          heff_take_n(v_x11_242193, 1ULL, 1);
          V v_m_242197 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_a_241951)}));
          V v_x1_242198 = heff_tr(heff_call(v_m_242197, 1, (V[]){v_st_242194}));
          switch (heff_tag_of(v_x1_242198)) {
          case TAG_MkPair: {
            V v_x11_242199 = heff_field(v_x1_242198, 0);
            V v_st_242200 = heff_field(v_x1_242198, 1);
            V v_ru_24x1_242198_24MkPair = heff_take_reuse_n(v_x1_242198, 3ULL, 2);
            switch (heff_tag_of(v_x11_242199)) {
            case TAG_Left: {
              V v_e_242201 = heff_field(v_x11_242199, 0);
              heff_take_n(v_x11_242199, 1ULL, 1);
              heff_drop_rec(v_kw_241948, 9);
              heff_drop(v_a_241951);
              heff_drop(v_x_242196);
              heff_drop_cell(v_ru_24x1_242198_24MkPair, 2);
              return heff_tag_at_n(v_ru_24x1_242192_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242201}), v_st_242200});
            }
            case TAG_Right: {
              V v_x_242202 = heff_field(v_x11_242199, 0);
              heff_take_n(v_x11_242199, 1ULL, 1);
              V v_t_242203 = (g_heff_2esyntax_2ecst_2elastE(v_a_241951));
              V v_e_242204 = heff_get_n(v_t_242203, 4, 9);
              V v_t_242205 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_241948, 3, 9), v_e_242204});
              V v_x_242206 = heff_tag_at_n(v_ru_24x1_242198_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_EIfThen, 2, (V[]){v_x_242196, v_x_242202}), v_t_242205});
              return heff_tag_at_n(v_ru_24x1_242192_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_242206}), v_st_242200});
            }
            default: return heff_nomatch(v_x11_242199);
            }
          }
          default: return heff_nomatch(v_x1_242198);
          }
        }
        default: return heff_nomatch(v_x11_242193);
        }
      }
      default: return heff_nomatch(v_x1_242192);
      }
    }
    case TAG_EField: {
      V v_m_242209 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_241949}));
      V v_x1_242210 = heff_tr(heff_call(v_m_242209, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_242210)) {
      case TAG_MkPair: {
        V v_x11_242211 = heff_field(v_x1_242210, 0);
        V v_st_242212 = heff_field(v_x1_242210, 1);
        V v_ru_24x1_242210_24MkPair = heff_take_reuse_n(v_x1_242210, 3ULL, 2);
        switch (heff_tag_of(v_x11_242211)) {
        case TAG_Left: {
          V v_e_242213 = heff_field(v_x11_242211, 0);
          heff_take_n(v_x11_242211, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_241948, 9);
          heff_drop(v_a_241951);
          return heff_tag_at_n(v_ru_24x1_242210_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242213}), v_st_242212});
        }
        case TAG_Right: {
          V v_x_242214 = heff_field(v_x11_242211, 0);
          heff_take_n(v_x11_242211, 1ULL, 1);
          V v_m_242215 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_a_241951)}));
          V v_x1_242216 = heff_tr(heff_call(v_m_242215, 1, (V[]){v_st_242212}));
          switch (heff_tag_of(v_x1_242216)) {
          case TAG_MkPair: {
            V v_x11_242217 = heff_field(v_x1_242216, 0);
            V v_st_242218 = heff_field(v_x1_242216, 1);
            V v_ru_24x1_242216_24MkPair = heff_take_reuse_n(v_x1_242216, 3ULL, 2);
            switch (heff_tag_of(v_x11_242217)) {
            case TAG_Left: {
              V v_e_242219 = heff_field(v_x11_242217, 0);
              heff_take_n(v_x11_242217, 1ULL, 1);
              heff_drop_rec(v_kw_241948, 9);
              heff_drop(v_a_241951);
              heff_drop(v_x_242214);
              heff_drop_cell(v_ru_24x1_242216_24MkPair, 2);
              return heff_tag_at_n(v_ru_24x1_242210_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242219}), v_st_242218});
            }
            case TAG_Right: {
              V v_x_242220 = heff_field(v_x11_242217, 0);
              heff_take_n(v_x11_242217, 1ULL, 1);
              V v_t_242221 = (g_heff_2esyntax_2ecst_2elastE(v_a_241951));
              V v_e_242222 = heff_get_n(v_t_242221, 4, 9);
              V v_t_242223 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_241948, 3, 9), v_e_242222});
              V v_x_242224 = heff_tag_at_n(v_ru_24x1_242216_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_EIfThen, 2, (V[]){v_x_242214, v_x_242220}), v_t_242223});
              return heff_tag_at_n(v_ru_24x1_242210_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_242224}), v_st_242218});
            }
            default: return heff_nomatch(v_x11_242217);
            }
          }
          default: return heff_nomatch(v_x1_242216);
          }
        }
        default: return heff_nomatch(v_x11_242211);
        }
      }
      default: return heff_nomatch(v_x1_242210);
      }
    }
    case TAG_ENeg: {
      V v_m_242227 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_241949}));
      V v_x1_242228 = heff_tr(heff_call(v_m_242227, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_242228)) {
      case TAG_MkPair: {
        V v_x11_242229 = heff_field(v_x1_242228, 0);
        V v_st_242230 = heff_field(v_x1_242228, 1);
        V v_ru_24x1_242228_24MkPair = heff_take_reuse_n(v_x1_242228, 3ULL, 2);
        switch (heff_tag_of(v_x11_242229)) {
        case TAG_Left: {
          V v_e_242231 = heff_field(v_x11_242229, 0);
          heff_take_n(v_x11_242229, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_241948, 9);
          heff_drop(v_a_241951);
          return heff_tag_at_n(v_ru_24x1_242228_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242231}), v_st_242230});
        }
        case TAG_Right: {
          V v_x_242232 = heff_field(v_x11_242229, 0);
          heff_take_n(v_x11_242229, 1ULL, 1);
          V v_m_242233 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_a_241951)}));
          V v_x1_242234 = heff_tr(heff_call(v_m_242233, 1, (V[]){v_st_242230}));
          switch (heff_tag_of(v_x1_242234)) {
          case TAG_MkPair: {
            V v_x11_242235 = heff_field(v_x1_242234, 0);
            V v_st_242236 = heff_field(v_x1_242234, 1);
            V v_ru_24x1_242234_24MkPair = heff_take_reuse_n(v_x1_242234, 3ULL, 2);
            switch (heff_tag_of(v_x11_242235)) {
            case TAG_Left: {
              V v_e_242237 = heff_field(v_x11_242235, 0);
              heff_take_n(v_x11_242235, 1ULL, 1);
              heff_drop_rec(v_kw_241948, 9);
              heff_drop(v_a_241951);
              heff_drop(v_x_242232);
              heff_drop_cell(v_ru_24x1_242234_24MkPair, 2);
              return heff_tag_at_n(v_ru_24x1_242228_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242237}), v_st_242236});
            }
            case TAG_Right: {
              V v_x_242238 = heff_field(v_x11_242235, 0);
              heff_take_n(v_x11_242235, 1ULL, 1);
              V v_t_242239 = (g_heff_2esyntax_2ecst_2elastE(v_a_241951));
              V v_e_242240 = heff_get_n(v_t_242239, 4, 9);
              V v_t_242241 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_241948, 3, 9), v_e_242240});
              V v_x_242242 = heff_tag_at_n(v_ru_24x1_242234_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_EIfThen, 2, (V[]){v_x_242232, v_x_242238}), v_t_242241});
              return heff_tag_at_n(v_ru_24x1_242228_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_242242}), v_st_242236});
            }
            default: return heff_nomatch(v_x11_242235);
            }
          }
          default: return heff_nomatch(v_x1_242234);
          }
        }
        default: return heff_nomatch(v_x11_242229);
        }
      }
      default: return heff_nomatch(v_x1_242228);
      }
    }
    case TAG_App: {
      V v_m_242245 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_241949}));
      V v_x1_242246 = heff_tr(heff_call(v_m_242245, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_242246)) {
      case TAG_MkPair: {
        V v_x11_242247 = heff_field(v_x1_242246, 0);
        V v_st_242248 = heff_field(v_x1_242246, 1);
        V v_ru_24x1_242246_24MkPair = heff_take_reuse_n(v_x1_242246, 3ULL, 2);
        switch (heff_tag_of(v_x11_242247)) {
        case TAG_Left: {
          V v_e_242249 = heff_field(v_x11_242247, 0);
          heff_take_n(v_x11_242247, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_241948, 9);
          heff_drop(v_a_241951);
          return heff_tag_at_n(v_ru_24x1_242246_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242249}), v_st_242248});
        }
        case TAG_Right: {
          V v_x_242250 = heff_field(v_x11_242247, 0);
          heff_take_n(v_x11_242247, 1ULL, 1);
          V v_m_242251 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_a_241951)}));
          V v_x1_242252 = heff_tr(heff_call(v_m_242251, 1, (V[]){v_st_242248}));
          switch (heff_tag_of(v_x1_242252)) {
          case TAG_MkPair: {
            V v_x11_242253 = heff_field(v_x1_242252, 0);
            V v_st_242254 = heff_field(v_x1_242252, 1);
            V v_ru_24x1_242252_24MkPair = heff_take_reuse_n(v_x1_242252, 3ULL, 2);
            switch (heff_tag_of(v_x11_242253)) {
            case TAG_Left: {
              V v_e_242255 = heff_field(v_x11_242253, 0);
              heff_take_n(v_x11_242253, 1ULL, 1);
              heff_drop_rec(v_kw_241948, 9);
              heff_drop(v_a_241951);
              heff_drop(v_x_242250);
              heff_drop_cell(v_ru_24x1_242252_24MkPair, 2);
              return heff_tag_at_n(v_ru_24x1_242246_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242255}), v_st_242254});
            }
            case TAG_Right: {
              V v_x_242256 = heff_field(v_x11_242253, 0);
              heff_take_n(v_x11_242253, 1ULL, 1);
              V v_t_242257 = (g_heff_2esyntax_2ecst_2elastE(v_a_241951));
              V v_e_242258 = heff_get_n(v_t_242257, 4, 9);
              V v_t_242259 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_241948, 3, 9), v_e_242258});
              V v_x_242260 = heff_tag_at_n(v_ru_24x1_242252_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_EIfThen, 2, (V[]){v_x_242250, v_x_242256}), v_t_242259});
              return heff_tag_at_n(v_ru_24x1_242246_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_242260}), v_st_242254});
            }
            default: return heff_nomatch(v_x11_242253);
            }
          }
          default: return heff_nomatch(v_x1_242252);
          }
        }
        default: return heff_nomatch(v_x11_242247);
        }
      }
      default: return heff_nomatch(v_x1_242246);
      }
    }
    case TAG_Op: {
      V v_m_242264 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_241949}));
      V v_x1_242265 = heff_tr(heff_call(v_m_242264, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_242265)) {
      case TAG_MkPair: {
        V v_x11_242266 = heff_field(v_x1_242265, 0);
        V v_st_242267 = heff_field(v_x1_242265, 1);
        V v_ru_24x1_242265_24MkPair = heff_take_reuse_n(v_x1_242265, 3ULL, 2);
        switch (heff_tag_of(v_x11_242266)) {
        case TAG_Left: {
          V v_e_242268 = heff_field(v_x11_242266, 0);
          heff_take_n(v_x11_242266, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_241948, 9);
          heff_drop(v_a_241951);
          return heff_tag_at_n(v_ru_24x1_242265_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242268}), v_st_242267});
        }
        case TAG_Right: {
          V v_x_242269 = heff_field(v_x11_242266, 0);
          heff_take_n(v_x11_242266, 1ULL, 1);
          V v_m_242270 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_a_241951)}));
          V v_x1_242271 = heff_tr(heff_call(v_m_242270, 1, (V[]){v_st_242267}));
          switch (heff_tag_of(v_x1_242271)) {
          case TAG_MkPair: {
            V v_x11_242272 = heff_field(v_x1_242271, 0);
            V v_st_242273 = heff_field(v_x1_242271, 1);
            V v_ru_24x1_242271_24MkPair = heff_take_reuse_n(v_x1_242271, 3ULL, 2);
            switch (heff_tag_of(v_x11_242272)) {
            case TAG_Left: {
              V v_e_242274 = heff_field(v_x11_242272, 0);
              heff_take_n(v_x11_242272, 1ULL, 1);
              heff_drop_rec(v_kw_241948, 9);
              heff_drop(v_a_241951);
              heff_drop(v_x_242269);
              heff_drop_cell(v_ru_24x1_242271_24MkPair, 2);
              return heff_tag_at_n(v_ru_24x1_242265_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242274}), v_st_242273});
            }
            case TAG_Right: {
              V v_x_242275 = heff_field(v_x11_242272, 0);
              heff_take_n(v_x11_242272, 1ULL, 1);
              V v_t_242276 = (g_heff_2esyntax_2ecst_2elastE(v_a_241951));
              V v_e_242277 = heff_get_n(v_t_242276, 4, 9);
              V v_t_242278 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_241948, 3, 9), v_e_242277});
              V v_x_242279 = heff_tag_at_n(v_ru_24x1_242271_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_EIfThen, 2, (V[]){v_x_242269, v_x_242275}), v_t_242278});
              return heff_tag_at_n(v_ru_24x1_242265_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_242279}), v_st_242273});
            }
            default: return heff_nomatch(v_x11_242272);
            }
          }
          default: return heff_nomatch(v_x1_242271);
          }
        }
        default: return heff_nomatch(v_x11_242266);
        }
      }
      default: return heff_nomatch(v_x1_242265);
      }
    }
    case TAG_Ops: {
      V v_m_242282 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_241949}));
      V v_x1_242283 = heff_tr(heff_call(v_m_242282, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_242283)) {
      case TAG_MkPair: {
        V v_x11_242284 = heff_field(v_x1_242283, 0);
        V v_st_242285 = heff_field(v_x1_242283, 1);
        V v_ru_24x1_242283_24MkPair = heff_take_reuse_n(v_x1_242283, 3ULL, 2);
        switch (heff_tag_of(v_x11_242284)) {
        case TAG_Left: {
          V v_e_242286 = heff_field(v_x11_242284, 0);
          heff_take_n(v_x11_242284, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_241948, 9);
          heff_drop(v_a_241951);
          return heff_tag_at_n(v_ru_24x1_242283_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242286}), v_st_242285});
        }
        case TAG_Right: {
          V v_x_242287 = heff_field(v_x11_242284, 0);
          heff_take_n(v_x11_242284, 1ULL, 1);
          V v_m_242288 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_a_241951)}));
          V v_x1_242289 = heff_tr(heff_call(v_m_242288, 1, (V[]){v_st_242285}));
          switch (heff_tag_of(v_x1_242289)) {
          case TAG_MkPair: {
            V v_x11_242290 = heff_field(v_x1_242289, 0);
            V v_st_242291 = heff_field(v_x1_242289, 1);
            V v_ru_24x1_242289_24MkPair = heff_take_reuse_n(v_x1_242289, 3ULL, 2);
            switch (heff_tag_of(v_x11_242290)) {
            case TAG_Left: {
              V v_e_242292 = heff_field(v_x11_242290, 0);
              heff_take_n(v_x11_242290, 1ULL, 1);
              heff_drop_rec(v_kw_241948, 9);
              heff_drop(v_a_241951);
              heff_drop(v_x_242287);
              heff_drop_cell(v_ru_24x1_242289_24MkPair, 2);
              return heff_tag_at_n(v_ru_24x1_242283_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242292}), v_st_242291});
            }
            case TAG_Right: {
              V v_x_242293 = heff_field(v_x11_242290, 0);
              heff_take_n(v_x11_242290, 1ULL, 1);
              V v_t_242294 = (g_heff_2esyntax_2ecst_2elastE(v_a_241951));
              V v_e_242295 = heff_get_n(v_t_242294, 4, 9);
              V v_t_242296 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_241948, 3, 9), v_e_242295});
              V v_x_242297 = heff_tag_at_n(v_ru_24x1_242289_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_EIfThen, 2, (V[]){v_x_242287, v_x_242293}), v_t_242296});
              return heff_tag_at_n(v_ru_24x1_242283_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_242297}), v_st_242291});
            }
            default: return heff_nomatch(v_x11_242290);
            }
          }
          default: return heff_nomatch(v_x1_242289);
          }
        }
        default: return heff_nomatch(v_x11_242284);
        }
      }
      default: return heff_nomatch(v_x1_242283);
      }
    }
    case TAG_OpRhs: {
      V v_m_242300 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_241949}));
      V v_x1_242301 = heff_tr(heff_call(v_m_242300, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_242301)) {
      case TAG_MkPair: {
        V v_x11_242302 = heff_field(v_x1_242301, 0);
        V v_st_242303 = heff_field(v_x1_242301, 1);
        V v_ru_24x1_242301_24MkPair = heff_take_reuse_n(v_x1_242301, 3ULL, 2);
        switch (heff_tag_of(v_x11_242302)) {
        case TAG_Left: {
          V v_e_242304 = heff_field(v_x11_242302, 0);
          heff_take_n(v_x11_242302, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_241948, 9);
          heff_drop(v_a_241951);
          return heff_tag_at_n(v_ru_24x1_242301_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242304}), v_st_242303});
        }
        case TAG_Right: {
          V v_x_242305 = heff_field(v_x11_242302, 0);
          heff_take_n(v_x11_242302, 1ULL, 1);
          V v_m_242306 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_a_241951)}));
          V v_x1_242307 = heff_tr(heff_call(v_m_242306, 1, (V[]){v_st_242303}));
          switch (heff_tag_of(v_x1_242307)) {
          case TAG_MkPair: {
            V v_x11_242308 = heff_field(v_x1_242307, 0);
            V v_st_242309 = heff_field(v_x1_242307, 1);
            V v_ru_24x1_242307_24MkPair = heff_take_reuse_n(v_x1_242307, 3ULL, 2);
            switch (heff_tag_of(v_x11_242308)) {
            case TAG_Left: {
              V v_e_242310 = heff_field(v_x11_242308, 0);
              heff_take_n(v_x11_242308, 1ULL, 1);
              heff_drop_rec(v_kw_241948, 9);
              heff_drop(v_a_241951);
              heff_drop(v_x_242305);
              heff_drop_cell(v_ru_24x1_242307_24MkPair, 2);
              return heff_tag_at_n(v_ru_24x1_242301_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242310}), v_st_242309});
            }
            case TAG_Right: {
              V v_x_242311 = heff_field(v_x11_242308, 0);
              heff_take_n(v_x11_242308, 1ULL, 1);
              V v_t_242312 = (g_heff_2esyntax_2ecst_2elastE(v_a_241951));
              V v_e_242313 = heff_get_n(v_t_242312, 4, 9);
              V v_t_242314 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_241948, 3, 9), v_e_242313});
              V v_x_242315 = heff_tag_at_n(v_ru_24x1_242307_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_EIfThen, 2, (V[]){v_x_242305, v_x_242311}), v_t_242314});
              return heff_tag_at_n(v_ru_24x1_242301_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_242315}), v_st_242309});
            }
            default: return heff_nomatch(v_x11_242308);
            }
          }
          default: return heff_nomatch(v_x1_242307);
          }
        }
        default: return heff_nomatch(v_x11_242302);
        }
      }
      default: return heff_nomatch(v_x1_242301);
      }
    }
    case TAG_Ann: {
      V v_m_242319 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_241949}));
      V v_x1_242320 = heff_tr(heff_call(v_m_242319, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_242320)) {
      case TAG_MkPair: {
        V v_x11_242321 = heff_field(v_x1_242320, 0);
        V v_st_242322 = heff_field(v_x1_242320, 1);
        V v_ru_24x1_242320_24MkPair = heff_take_reuse_n(v_x1_242320, 3ULL, 2);
        switch (heff_tag_of(v_x11_242321)) {
        case TAG_Left: {
          V v_e_242323 = heff_field(v_x11_242321, 0);
          heff_take_n(v_x11_242321, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_241948, 9);
          heff_drop(v_a_241951);
          return heff_tag_at_n(v_ru_24x1_242320_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242323}), v_st_242322});
        }
        case TAG_Right: {
          V v_x_242324 = heff_field(v_x11_242321, 0);
          heff_take_n(v_x11_242321, 1ULL, 1);
          V v_m_242325 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_a_241951)}));
          V v_x1_242326 = heff_tr(heff_call(v_m_242325, 1, (V[]){v_st_242322}));
          switch (heff_tag_of(v_x1_242326)) {
          case TAG_MkPair: {
            V v_x11_242327 = heff_field(v_x1_242326, 0);
            V v_st_242328 = heff_field(v_x1_242326, 1);
            V v_ru_24x1_242326_24MkPair = heff_take_reuse_n(v_x1_242326, 3ULL, 2);
            switch (heff_tag_of(v_x11_242327)) {
            case TAG_Left: {
              V v_e_242329 = heff_field(v_x11_242327, 0);
              heff_take_n(v_x11_242327, 1ULL, 1);
              heff_drop_rec(v_kw_241948, 9);
              heff_drop(v_a_241951);
              heff_drop(v_x_242324);
              heff_drop_cell(v_ru_24x1_242326_24MkPair, 2);
              return heff_tag_at_n(v_ru_24x1_242320_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242329}), v_st_242328});
            }
            case TAG_Right: {
              V v_x_242330 = heff_field(v_x11_242327, 0);
              heff_take_n(v_x11_242327, 1ULL, 1);
              V v_t_242331 = (g_heff_2esyntax_2ecst_2elastE(v_a_241951));
              V v_e_242332 = heff_get_n(v_t_242331, 4, 9);
              V v_t_242333 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_241948, 3, 9), v_e_242332});
              V v_x_242334 = heff_tag_at_n(v_ru_24x1_242326_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_EIfThen, 2, (V[]){v_x_242324, v_x_242330}), v_t_242333});
              return heff_tag_at_n(v_ru_24x1_242320_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_242334}), v_st_242328});
            }
            default: return heff_nomatch(v_x11_242327);
            }
          }
          default: return heff_nomatch(v_x1_242326);
          }
        }
        default: return heff_nomatch(v_x11_242321);
        }
      }
      default: return heff_nomatch(v_x1_242320);
      }
    }
    case TAG_BVar: {
      V v_m_242336 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_241949}));
      V v_x1_242337 = heff_tr(heff_call(v_m_242336, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_242337)) {
      case TAG_MkPair: {
        V v_x11_242338 = heff_field(v_x1_242337, 0);
        V v_st_242339 = heff_field(v_x1_242337, 1);
        V v_ru_24x1_242337_24MkPair = heff_take_reuse_n(v_x1_242337, 3ULL, 2);
        switch (heff_tag_of(v_x11_242338)) {
        case TAG_Left: {
          V v_e_242340 = heff_field(v_x11_242338, 0);
          heff_take_n(v_x11_242338, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_241948, 9);
          heff_drop(v_a_241951);
          return heff_tag_at_n(v_ru_24x1_242337_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242340}), v_st_242339});
        }
        case TAG_Right: {
          V v_x_242341 = heff_field(v_x11_242338, 0);
          heff_take_n(v_x11_242338, 1ULL, 1);
          V v_m_242342 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_a_241951)}));
          V v_x1_242343 = heff_tr(heff_call(v_m_242342, 1, (V[]){v_st_242339}));
          switch (heff_tag_of(v_x1_242343)) {
          case TAG_MkPair: {
            V v_x11_242344 = heff_field(v_x1_242343, 0);
            V v_st_242345 = heff_field(v_x1_242343, 1);
            V v_ru_24x1_242343_24MkPair = heff_take_reuse_n(v_x1_242343, 3ULL, 2);
            switch (heff_tag_of(v_x11_242344)) {
            case TAG_Left: {
              V v_e_242346 = heff_field(v_x11_242344, 0);
              heff_take_n(v_x11_242344, 1ULL, 1);
              heff_drop_rec(v_kw_241948, 9);
              heff_drop(v_a_241951);
              heff_drop(v_x_242341);
              heff_drop_cell(v_ru_24x1_242343_24MkPair, 2);
              return heff_tag_at_n(v_ru_24x1_242337_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242346}), v_st_242345});
            }
            case TAG_Right: {
              V v_x_242347 = heff_field(v_x11_242344, 0);
              heff_take_n(v_x11_242344, 1ULL, 1);
              V v_t_242348 = (g_heff_2esyntax_2ecst_2elastE(v_a_241951));
              V v_e_242349 = heff_get_n(v_t_242348, 4, 9);
              V v_t_242350 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_241948, 3, 9), v_e_242349});
              V v_x_242351 = heff_tag_at_n(v_ru_24x1_242343_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_EIfThen, 2, (V[]){v_x_242341, v_x_242347}), v_t_242350});
              return heff_tag_at_n(v_ru_24x1_242337_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_242351}), v_st_242345});
            }
            default: return heff_nomatch(v_x11_242344);
            }
          }
          default: return heff_nomatch(v_x1_242343);
          }
        }
        default: return heff_nomatch(v_x11_242338);
        }
      }
      default: return heff_nomatch(v_x1_242337);
      }
    }
    case TAG_BImp: {
      V v_m_242355 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_241949}));
      V v_x1_242356 = heff_tr(heff_call(v_m_242355, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_242356)) {
      case TAG_MkPair: {
        V v_x11_242357 = heff_field(v_x1_242356, 0);
        V v_st_242358 = heff_field(v_x1_242356, 1);
        V v_ru_24x1_242356_24MkPair = heff_take_reuse_n(v_x1_242356, 3ULL, 2);
        switch (heff_tag_of(v_x11_242357)) {
        case TAG_Left: {
          V v_e_242359 = heff_field(v_x11_242357, 0);
          heff_take_n(v_x11_242357, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_241948, 9);
          heff_drop(v_a_241951);
          return heff_tag_at_n(v_ru_24x1_242356_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242359}), v_st_242358});
        }
        case TAG_Right: {
          V v_x_242360 = heff_field(v_x11_242357, 0);
          heff_take_n(v_x11_242357, 1ULL, 1);
          V v_m_242361 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_a_241951)}));
          V v_x1_242362 = heff_tr(heff_call(v_m_242361, 1, (V[]){v_st_242358}));
          switch (heff_tag_of(v_x1_242362)) {
          case TAG_MkPair: {
            V v_x11_242363 = heff_field(v_x1_242362, 0);
            V v_st_242364 = heff_field(v_x1_242362, 1);
            V v_ru_24x1_242362_24MkPair = heff_take_reuse_n(v_x1_242362, 3ULL, 2);
            switch (heff_tag_of(v_x11_242363)) {
            case TAG_Left: {
              V v_e_242365 = heff_field(v_x11_242363, 0);
              heff_take_n(v_x11_242363, 1ULL, 1);
              heff_drop_rec(v_kw_241948, 9);
              heff_drop(v_a_241951);
              heff_drop(v_x_242360);
              heff_drop_cell(v_ru_24x1_242362_24MkPair, 2);
              return heff_tag_at_n(v_ru_24x1_242356_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242365}), v_st_242364});
            }
            case TAG_Right: {
              V v_x_242366 = heff_field(v_x11_242363, 0);
              heff_take_n(v_x11_242363, 1ULL, 1);
              V v_t_242367 = (g_heff_2esyntax_2ecst_2elastE(v_a_241951));
              V v_e_242368 = heff_get_n(v_t_242367, 4, 9);
              V v_t_242369 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_241948, 3, 9), v_e_242368});
              V v_x_242370 = heff_tag_at_n(v_ru_24x1_242362_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_EIfThen, 2, (V[]){v_x_242360, v_x_242366}), v_t_242369});
              return heff_tag_at_n(v_ru_24x1_242356_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_242370}), v_st_242364});
            }
            default: return heff_nomatch(v_x11_242363);
            }
          }
          default: return heff_nomatch(v_x1_242362);
          }
        }
        default: return heff_nomatch(v_x11_242357);
        }
      }
      default: return heff_nomatch(v_x1_242356);
      }
    }
    case TAG_BAnn: {
      V v_m_242376 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_241949}));
      V v_x1_242377 = heff_tr(heff_call(v_m_242376, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_242377)) {
      case TAG_MkPair: {
        V v_x11_242378 = heff_field(v_x1_242377, 0);
        V v_st_242379 = heff_field(v_x1_242377, 1);
        V v_ru_24x1_242377_24MkPair = heff_take_reuse_n(v_x1_242377, 3ULL, 2);
        switch (heff_tag_of(v_x11_242378)) {
        case TAG_Left: {
          V v_e_242380 = heff_field(v_x11_242378, 0);
          heff_take_n(v_x11_242378, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_241948, 9);
          heff_drop(v_a_241951);
          return heff_tag_at_n(v_ru_24x1_242377_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242380}), v_st_242379});
        }
        case TAG_Right: {
          V v_x_242381 = heff_field(v_x11_242378, 0);
          heff_take_n(v_x11_242378, 1ULL, 1);
          V v_m_242382 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_a_241951)}));
          V v_x1_242383 = heff_tr(heff_call(v_m_242382, 1, (V[]){v_st_242379}));
          switch (heff_tag_of(v_x1_242383)) {
          case TAG_MkPair: {
            V v_x11_242384 = heff_field(v_x1_242383, 0);
            V v_st_242385 = heff_field(v_x1_242383, 1);
            V v_ru_24x1_242383_24MkPair = heff_take_reuse_n(v_x1_242383, 3ULL, 2);
            switch (heff_tag_of(v_x11_242384)) {
            case TAG_Left: {
              V v_e_242386 = heff_field(v_x11_242384, 0);
              heff_take_n(v_x11_242384, 1ULL, 1);
              heff_drop_rec(v_kw_241948, 9);
              heff_drop(v_a_241951);
              heff_drop(v_x_242381);
              heff_drop_cell(v_ru_24x1_242383_24MkPair, 2);
              return heff_tag_at_n(v_ru_24x1_242377_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242386}), v_st_242385});
            }
            case TAG_Right: {
              V v_x_242387 = heff_field(v_x11_242384, 0);
              heff_take_n(v_x11_242384, 1ULL, 1);
              V v_t_242388 = (g_heff_2esyntax_2ecst_2elastE(v_a_241951));
              V v_e_242389 = heff_get_n(v_t_242388, 4, 9);
              V v_t_242390 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_241948, 3, 9), v_e_242389});
              V v_x_242391 = heff_tag_at_n(v_ru_24x1_242383_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_EIfThen, 2, (V[]){v_x_242381, v_x_242387}), v_t_242390});
              return heff_tag_at_n(v_ru_24x1_242377_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_242391}), v_st_242385});
            }
            default: return heff_nomatch(v_x11_242384);
            }
          }
          default: return heff_nomatch(v_x1_242383);
          }
        }
        default: return heff_nomatch(v_x11_242378);
        }
      }
      default: return heff_nomatch(v_x1_242377);
      }
    }
    case TAG_Lam: {
      V v_m_242396 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_241949}));
      V v_x1_242397 = heff_tr(heff_call(v_m_242396, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_242397)) {
      case TAG_MkPair: {
        V v_x11_242398 = heff_field(v_x1_242397, 0);
        V v_st_242399 = heff_field(v_x1_242397, 1);
        V v_ru_24x1_242397_24MkPair = heff_take_reuse_n(v_x1_242397, 3ULL, 2);
        switch (heff_tag_of(v_x11_242398)) {
        case TAG_Left: {
          V v_e_242400 = heff_field(v_x11_242398, 0);
          heff_take_n(v_x11_242398, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_241948, 9);
          heff_drop(v_a_241951);
          return heff_tag_at_n(v_ru_24x1_242397_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242400}), v_st_242399});
        }
        case TAG_Right: {
          V v_x_242401 = heff_field(v_x11_242398, 0);
          heff_take_n(v_x11_242398, 1ULL, 1);
          V v_m_242402 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_a_241951)}));
          V v_x1_242403 = heff_tr(heff_call(v_m_242402, 1, (V[]){v_st_242399}));
          switch (heff_tag_of(v_x1_242403)) {
          case TAG_MkPair: {
            V v_x11_242404 = heff_field(v_x1_242403, 0);
            V v_st_242405 = heff_field(v_x1_242403, 1);
            V v_ru_24x1_242403_24MkPair = heff_take_reuse_n(v_x1_242403, 3ULL, 2);
            switch (heff_tag_of(v_x11_242404)) {
            case TAG_Left: {
              V v_e_242406 = heff_field(v_x11_242404, 0);
              heff_take_n(v_x11_242404, 1ULL, 1);
              heff_drop_rec(v_kw_241948, 9);
              heff_drop(v_a_241951);
              heff_drop(v_x_242401);
              heff_drop_cell(v_ru_24x1_242403_24MkPair, 2);
              return heff_tag_at_n(v_ru_24x1_242397_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242406}), v_st_242405});
            }
            case TAG_Right: {
              V v_x_242407 = heff_field(v_x11_242404, 0);
              heff_take_n(v_x11_242404, 1ULL, 1);
              V v_t_242408 = (g_heff_2esyntax_2ecst_2elastE(v_a_241951));
              V v_e_242409 = heff_get_n(v_t_242408, 4, 9);
              V v_t_242410 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_241948, 3, 9), v_e_242409});
              V v_x_242411 = heff_tag_at_n(v_ru_24x1_242403_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_EIfThen, 2, (V[]){v_x_242401, v_x_242407}), v_t_242410});
              return heff_tag_at_n(v_ru_24x1_242397_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_242411}), v_st_242405});
            }
            default: return heff_nomatch(v_x11_242404);
            }
          }
          default: return heff_nomatch(v_x1_242403);
          }
        }
        default: return heff_nomatch(v_x11_242398);
        }
      }
      default: return heff_nomatch(v_x1_242397);
      }
    }
    case TAG_Case: {
      V v_m_242416 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_241949}));
      V v_x1_242417 = heff_tr(heff_call(v_m_242416, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_242417)) {
      case TAG_MkPair: {
        V v_x11_242418 = heff_field(v_x1_242417, 0);
        V v_st_242419 = heff_field(v_x1_242417, 1);
        V v_ru_24x1_242417_24MkPair = heff_take_reuse_n(v_x1_242417, 3ULL, 2);
        switch (heff_tag_of(v_x11_242418)) {
        case TAG_Left: {
          V v_e_242420 = heff_field(v_x11_242418, 0);
          heff_take_n(v_x11_242418, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_241948, 9);
          heff_drop(v_a_241951);
          return heff_tag_at_n(v_ru_24x1_242417_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242420}), v_st_242419});
        }
        case TAG_Right: {
          V v_x_242421 = heff_field(v_x11_242418, 0);
          heff_take_n(v_x11_242418, 1ULL, 1);
          V v_m_242422 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_a_241951)}));
          V v_x1_242423 = heff_tr(heff_call(v_m_242422, 1, (V[]){v_st_242419}));
          switch (heff_tag_of(v_x1_242423)) {
          case TAG_MkPair: {
            V v_x11_242424 = heff_field(v_x1_242423, 0);
            V v_st_242425 = heff_field(v_x1_242423, 1);
            V v_ru_24x1_242423_24MkPair = heff_take_reuse_n(v_x1_242423, 3ULL, 2);
            switch (heff_tag_of(v_x11_242424)) {
            case TAG_Left: {
              V v_e_242426 = heff_field(v_x11_242424, 0);
              heff_take_n(v_x11_242424, 1ULL, 1);
              heff_drop_rec(v_kw_241948, 9);
              heff_drop(v_a_241951);
              heff_drop(v_x_242421);
              heff_drop_cell(v_ru_24x1_242423_24MkPair, 2);
              return heff_tag_at_n(v_ru_24x1_242417_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242426}), v_st_242425});
            }
            case TAG_Right: {
              V v_x_242427 = heff_field(v_x11_242424, 0);
              heff_take_n(v_x11_242424, 1ULL, 1);
              V v_t_242428 = (g_heff_2esyntax_2ecst_2elastE(v_a_241951));
              V v_e_242429 = heff_get_n(v_t_242428, 4, 9);
              V v_t_242430 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_241948, 3, 9), v_e_242429});
              V v_x_242431 = heff_tag_at_n(v_ru_24x1_242423_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_EIfThen, 2, (V[]){v_x_242421, v_x_242427}), v_t_242430});
              return heff_tag_at_n(v_ru_24x1_242417_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_242431}), v_st_242425});
            }
            default: return heff_nomatch(v_x11_242424);
            }
          }
          default: return heff_nomatch(v_x1_242423);
          }
        }
        default: return heff_nomatch(v_x11_242418);
        }
      }
      default: return heff_nomatch(v_x1_242417);
      }
    }
    case TAG_EAlt: {
      V v_m_242435 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_241949}));
      V v_x1_242436 = heff_tr(heff_call(v_m_242435, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_242436)) {
      case TAG_MkPair: {
        V v_x11_242437 = heff_field(v_x1_242436, 0);
        V v_st_242438 = heff_field(v_x1_242436, 1);
        V v_ru_24x1_242436_24MkPair = heff_take_reuse_n(v_x1_242436, 3ULL, 2);
        switch (heff_tag_of(v_x11_242437)) {
        case TAG_Left: {
          V v_e_242439 = heff_field(v_x11_242437, 0);
          heff_take_n(v_x11_242437, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_241948, 9);
          heff_drop(v_a_241951);
          return heff_tag_at_n(v_ru_24x1_242436_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242439}), v_st_242438});
        }
        case TAG_Right: {
          V v_x_242440 = heff_field(v_x11_242437, 0);
          heff_take_n(v_x11_242437, 1ULL, 1);
          V v_m_242441 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_a_241951)}));
          V v_x1_242442 = heff_tr(heff_call(v_m_242441, 1, (V[]){v_st_242438}));
          switch (heff_tag_of(v_x1_242442)) {
          case TAG_MkPair: {
            V v_x11_242443 = heff_field(v_x1_242442, 0);
            V v_st_242444 = heff_field(v_x1_242442, 1);
            V v_ru_24x1_242442_24MkPair = heff_take_reuse_n(v_x1_242442, 3ULL, 2);
            switch (heff_tag_of(v_x11_242443)) {
            case TAG_Left: {
              V v_e_242445 = heff_field(v_x11_242443, 0);
              heff_take_n(v_x11_242443, 1ULL, 1);
              heff_drop_rec(v_kw_241948, 9);
              heff_drop(v_a_241951);
              heff_drop(v_x_242440);
              heff_drop_cell(v_ru_24x1_242442_24MkPair, 2);
              return heff_tag_at_n(v_ru_24x1_242436_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242445}), v_st_242444});
            }
            case TAG_Right: {
              V v_x_242446 = heff_field(v_x11_242443, 0);
              heff_take_n(v_x11_242443, 1ULL, 1);
              V v_t_242447 = (g_heff_2esyntax_2ecst_2elastE(v_a_241951));
              V v_e_242448 = heff_get_n(v_t_242447, 4, 9);
              V v_t_242449 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_241948, 3, 9), v_e_242448});
              V v_x_242450 = heff_tag_at_n(v_ru_24x1_242442_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_EIfThen, 2, (V[]){v_x_242440, v_x_242446}), v_t_242449});
              return heff_tag_at_n(v_ru_24x1_242436_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_242450}), v_st_242444});
            }
            default: return heff_nomatch(v_x11_242443);
            }
          }
          default: return heff_nomatch(v_x1_242442);
          }
        }
        default: return heff_nomatch(v_x11_242437);
        }
      }
      default: return heff_nomatch(v_x1_242436);
      }
    }
    case TAG_If: {
      V v_m_242457 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_241949}));
      V v_x1_242458 = heff_tr(heff_call(v_m_242457, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_242458)) {
      case TAG_MkPair: {
        V v_x11_242459 = heff_field(v_x1_242458, 0);
        V v_st_242460 = heff_field(v_x1_242458, 1);
        V v_ru_24x1_242458_24MkPair = heff_take_reuse_n(v_x1_242458, 3ULL, 2);
        switch (heff_tag_of(v_x11_242459)) {
        case TAG_Left: {
          V v_e_242461 = heff_field(v_x11_242459, 0);
          heff_take_n(v_x11_242459, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_241948, 9);
          heff_drop(v_a_241951);
          return heff_tag_at_n(v_ru_24x1_242458_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242461}), v_st_242460});
        }
        case TAG_Right: {
          V v_x_242462 = heff_field(v_x11_242459, 0);
          heff_take_n(v_x11_242459, 1ULL, 1);
          V v_m_242463 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_a_241951)}));
          V v_x1_242464 = heff_tr(heff_call(v_m_242463, 1, (V[]){v_st_242460}));
          switch (heff_tag_of(v_x1_242464)) {
          case TAG_MkPair: {
            V v_x11_242465 = heff_field(v_x1_242464, 0);
            V v_st_242466 = heff_field(v_x1_242464, 1);
            V v_ru_24x1_242464_24MkPair = heff_take_reuse_n(v_x1_242464, 3ULL, 2);
            switch (heff_tag_of(v_x11_242465)) {
            case TAG_Left: {
              V v_e_242467 = heff_field(v_x11_242465, 0);
              heff_take_n(v_x11_242465, 1ULL, 1);
              heff_drop_rec(v_kw_241948, 9);
              heff_drop(v_a_241951);
              heff_drop(v_x_242462);
              heff_drop_cell(v_ru_24x1_242464_24MkPair, 2);
              return heff_tag_at_n(v_ru_24x1_242458_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242467}), v_st_242466});
            }
            case TAG_Right: {
              V v_x_242468 = heff_field(v_x11_242465, 0);
              heff_take_n(v_x11_242465, 1ULL, 1);
              V v_t_242469 = (g_heff_2esyntax_2ecst_2elastE(v_a_241951));
              V v_e_242470 = heff_get_n(v_t_242469, 4, 9);
              V v_t_242471 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_241948, 3, 9), v_e_242470});
              V v_x_242472 = heff_tag_at_n(v_ru_24x1_242464_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_EIfThen, 2, (V[]){v_x_242462, v_x_242468}), v_t_242471});
              return heff_tag_at_n(v_ru_24x1_242458_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_242472}), v_st_242466});
            }
            default: return heff_nomatch(v_x11_242465);
            }
          }
          default: return heff_nomatch(v_x1_242464);
          }
        }
        default: return heff_nomatch(v_x11_242459);
        }
      }
      default: return heff_nomatch(v_x1_242458);
      }
    }
    case TAG_Do: {
      V v_m_242475 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_241949}));
      V v_x1_242476 = heff_tr(heff_call(v_m_242475, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_242476)) {
      case TAG_MkPair: {
        V v_x11_242477 = heff_field(v_x1_242476, 0);
        V v_st_242478 = heff_field(v_x1_242476, 1);
        V v_ru_24x1_242476_24MkPair = heff_take_reuse_n(v_x1_242476, 3ULL, 2);
        switch (heff_tag_of(v_x11_242477)) {
        case TAG_Left: {
          V v_e_242479 = heff_field(v_x11_242477, 0);
          heff_take_n(v_x11_242477, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_241948, 9);
          heff_drop(v_a_241951);
          return heff_tag_at_n(v_ru_24x1_242476_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242479}), v_st_242478});
        }
        case TAG_Right: {
          V v_x_242480 = heff_field(v_x11_242477, 0);
          heff_take_n(v_x11_242477, 1ULL, 1);
          V v_m_242481 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_a_241951)}));
          V v_x1_242482 = heff_tr(heff_call(v_m_242481, 1, (V[]){v_st_242478}));
          switch (heff_tag_of(v_x1_242482)) {
          case TAG_MkPair: {
            V v_x11_242483 = heff_field(v_x1_242482, 0);
            V v_st_242484 = heff_field(v_x1_242482, 1);
            V v_ru_24x1_242482_24MkPair = heff_take_reuse_n(v_x1_242482, 3ULL, 2);
            switch (heff_tag_of(v_x11_242483)) {
            case TAG_Left: {
              V v_e_242485 = heff_field(v_x11_242483, 0);
              heff_take_n(v_x11_242483, 1ULL, 1);
              heff_drop_rec(v_kw_241948, 9);
              heff_drop(v_a_241951);
              heff_drop(v_x_242480);
              heff_drop_cell(v_ru_24x1_242482_24MkPair, 2);
              return heff_tag_at_n(v_ru_24x1_242476_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242485}), v_st_242484});
            }
            case TAG_Right: {
              V v_x_242486 = heff_field(v_x11_242483, 0);
              heff_take_n(v_x11_242483, 1ULL, 1);
              V v_t_242487 = (g_heff_2esyntax_2ecst_2elastE(v_a_241951));
              V v_e_242488 = heff_get_n(v_t_242487, 4, 9);
              V v_t_242489 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_241948, 3, 9), v_e_242488});
              V v_x_242490 = heff_tag_at_n(v_ru_24x1_242482_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_EIfThen, 2, (V[]){v_x_242480, v_x_242486}), v_t_242489});
              return heff_tag_at_n(v_ru_24x1_242476_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_242490}), v_st_242484});
            }
            default: return heff_nomatch(v_x11_242483);
            }
          }
          default: return heff_nomatch(v_x1_242482);
          }
        }
        default: return heff_nomatch(v_x11_242477);
        }
      }
      default: return heff_nomatch(v_x1_242476);
      }
    }
    case TAG_ESBind: {
      V v_m_242494 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_241949}));
      V v_x1_242495 = heff_tr(heff_call(v_m_242494, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_242495)) {
      case TAG_MkPair: {
        V v_x11_242496 = heff_field(v_x1_242495, 0);
        V v_st_242497 = heff_field(v_x1_242495, 1);
        V v_ru_24x1_242495_24MkPair = heff_take_reuse_n(v_x1_242495, 3ULL, 2);
        switch (heff_tag_of(v_x11_242496)) {
        case TAG_Left: {
          V v_e_242498 = heff_field(v_x11_242496, 0);
          heff_take_n(v_x11_242496, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_241948, 9);
          heff_drop(v_a_241951);
          return heff_tag_at_n(v_ru_24x1_242495_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242498}), v_st_242497});
        }
        case TAG_Right: {
          V v_x_242499 = heff_field(v_x11_242496, 0);
          heff_take_n(v_x11_242496, 1ULL, 1);
          V v_m_242500 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_a_241951)}));
          V v_x1_242501 = heff_tr(heff_call(v_m_242500, 1, (V[]){v_st_242497}));
          switch (heff_tag_of(v_x1_242501)) {
          case TAG_MkPair: {
            V v_x11_242502 = heff_field(v_x1_242501, 0);
            V v_st_242503 = heff_field(v_x1_242501, 1);
            V v_ru_24x1_242501_24MkPair = heff_take_reuse_n(v_x1_242501, 3ULL, 2);
            switch (heff_tag_of(v_x11_242502)) {
            case TAG_Left: {
              V v_e_242504 = heff_field(v_x11_242502, 0);
              heff_take_n(v_x11_242502, 1ULL, 1);
              heff_drop_rec(v_kw_241948, 9);
              heff_drop(v_a_241951);
              heff_drop(v_x_242499);
              heff_drop_cell(v_ru_24x1_242501_24MkPair, 2);
              return heff_tag_at_n(v_ru_24x1_242495_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242504}), v_st_242503});
            }
            case TAG_Right: {
              V v_x_242505 = heff_field(v_x11_242502, 0);
              heff_take_n(v_x11_242502, 1ULL, 1);
              V v_t_242506 = (g_heff_2esyntax_2ecst_2elastE(v_a_241951));
              V v_e_242507 = heff_get_n(v_t_242506, 4, 9);
              V v_t_242508 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_241948, 3, 9), v_e_242507});
              V v_x_242509 = heff_tag_at_n(v_ru_24x1_242501_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_EIfThen, 2, (V[]){v_x_242499, v_x_242505}), v_t_242508});
              return heff_tag_at_n(v_ru_24x1_242495_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_242509}), v_st_242503});
            }
            default: return heff_nomatch(v_x11_242502);
            }
          }
          default: return heff_nomatch(v_x1_242501);
          }
        }
        default: return heff_nomatch(v_x11_242496);
        }
      }
      default: return heff_nomatch(v_x1_242495);
      }
    }
    case TAG_ELet: {
      V v_m_242516 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_241949}));
      V v_x1_242517 = heff_tr(heff_call(v_m_242516, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_242517)) {
      case TAG_MkPair: {
        V v_x11_242518 = heff_field(v_x1_242517, 0);
        V v_st_242519 = heff_field(v_x1_242517, 1);
        V v_ru_24x1_242517_24MkPair = heff_take_reuse_n(v_x1_242517, 3ULL, 2);
        switch (heff_tag_of(v_x11_242518)) {
        case TAG_Left: {
          V v_e_242520 = heff_field(v_x11_242518, 0);
          heff_take_n(v_x11_242518, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_241948, 9);
          heff_drop(v_a_241951);
          return heff_tag_at_n(v_ru_24x1_242517_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242520}), v_st_242519});
        }
        case TAG_Right: {
          V v_x_242521 = heff_field(v_x11_242518, 0);
          heff_take_n(v_x11_242518, 1ULL, 1);
          V v_m_242522 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_a_241951)}));
          V v_x1_242523 = heff_tr(heff_call(v_m_242522, 1, (V[]){v_st_242519}));
          switch (heff_tag_of(v_x1_242523)) {
          case TAG_MkPair: {
            V v_x11_242524 = heff_field(v_x1_242523, 0);
            V v_st_242525 = heff_field(v_x1_242523, 1);
            V v_ru_24x1_242523_24MkPair = heff_take_reuse_n(v_x1_242523, 3ULL, 2);
            switch (heff_tag_of(v_x11_242524)) {
            case TAG_Left: {
              V v_e_242526 = heff_field(v_x11_242524, 0);
              heff_take_n(v_x11_242524, 1ULL, 1);
              heff_drop_rec(v_kw_241948, 9);
              heff_drop(v_a_241951);
              heff_drop(v_x_242521);
              heff_drop_cell(v_ru_24x1_242523_24MkPair, 2);
              return heff_tag_at_n(v_ru_24x1_242517_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242526}), v_st_242525});
            }
            case TAG_Right: {
              V v_x_242527 = heff_field(v_x11_242524, 0);
              heff_take_n(v_x11_242524, 1ULL, 1);
              V v_t_242528 = (g_heff_2esyntax_2ecst_2elastE(v_a_241951));
              V v_e_242529 = heff_get_n(v_t_242528, 4, 9);
              V v_t_242530 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_241948, 3, 9), v_e_242529});
              V v_x_242531 = heff_tag_at_n(v_ru_24x1_242523_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_EIfThen, 2, (V[]){v_x_242521, v_x_242527}), v_t_242530});
              return heff_tag_at_n(v_ru_24x1_242517_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_242531}), v_st_242525});
            }
            default: return heff_nomatch(v_x11_242524);
            }
          }
          default: return heff_nomatch(v_x1_242523);
          }
        }
        default: return heff_nomatch(v_x11_242518);
        }
      }
      default: return heff_nomatch(v_x1_242517);
      }
    }
    case TAG_ELetMut: {
      V v_m_242538 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_241949}));
      V v_x1_242539 = heff_tr(heff_call(v_m_242538, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_242539)) {
      case TAG_MkPair: {
        V v_x11_242540 = heff_field(v_x1_242539, 0);
        V v_st_242541 = heff_field(v_x1_242539, 1);
        V v_ru_24x1_242539_24MkPair = heff_take_reuse_n(v_x1_242539, 3ULL, 2);
        switch (heff_tag_of(v_x11_242540)) {
        case TAG_Left: {
          V v_e_242542 = heff_field(v_x11_242540, 0);
          heff_take_n(v_x11_242540, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_241948, 9);
          heff_drop(v_a_241951);
          return heff_tag_at_n(v_ru_24x1_242539_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242542}), v_st_242541});
        }
        case TAG_Right: {
          V v_x_242543 = heff_field(v_x11_242540, 0);
          heff_take_n(v_x11_242540, 1ULL, 1);
          V v_m_242544 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_a_241951)}));
          V v_x1_242545 = heff_tr(heff_call(v_m_242544, 1, (V[]){v_st_242541}));
          switch (heff_tag_of(v_x1_242545)) {
          case TAG_MkPair: {
            V v_x11_242546 = heff_field(v_x1_242545, 0);
            V v_st_242547 = heff_field(v_x1_242545, 1);
            V v_ru_24x1_242545_24MkPair = heff_take_reuse_n(v_x1_242545, 3ULL, 2);
            switch (heff_tag_of(v_x11_242546)) {
            case TAG_Left: {
              V v_e_242548 = heff_field(v_x11_242546, 0);
              heff_take_n(v_x11_242546, 1ULL, 1);
              heff_drop_rec(v_kw_241948, 9);
              heff_drop(v_a_241951);
              heff_drop(v_x_242543);
              heff_drop_cell(v_ru_24x1_242545_24MkPair, 2);
              return heff_tag_at_n(v_ru_24x1_242539_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242548}), v_st_242547});
            }
            case TAG_Right: {
              V v_x_242549 = heff_field(v_x11_242546, 0);
              heff_take_n(v_x11_242546, 1ULL, 1);
              V v_t_242550 = (g_heff_2esyntax_2ecst_2elastE(v_a_241951));
              V v_e_242551 = heff_get_n(v_t_242550, 4, 9);
              V v_t_242552 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_241948, 3, 9), v_e_242551});
              V v_x_242553 = heff_tag_at_n(v_ru_24x1_242545_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_EIfThen, 2, (V[]){v_x_242543, v_x_242549}), v_t_242552});
              return heff_tag_at_n(v_ru_24x1_242539_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_242553}), v_st_242547});
            }
            default: return heff_nomatch(v_x11_242546);
            }
          }
          default: return heff_nomatch(v_x1_242545);
          }
        }
        default: return heff_nomatch(v_x11_242540);
        }
      }
      default: return heff_nomatch(v_x1_242539);
      }
    }
    case TAG_EAssign: {
      V v_m_242557 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_241949}));
      V v_x1_242558 = heff_tr(heff_call(v_m_242557, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_242558)) {
      case TAG_MkPair: {
        V v_x11_242559 = heff_field(v_x1_242558, 0);
        V v_st_242560 = heff_field(v_x1_242558, 1);
        V v_ru_24x1_242558_24MkPair = heff_take_reuse_n(v_x1_242558, 3ULL, 2);
        switch (heff_tag_of(v_x11_242559)) {
        case TAG_Left: {
          V v_e_242561 = heff_field(v_x11_242559, 0);
          heff_take_n(v_x11_242559, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_241948, 9);
          heff_drop(v_a_241951);
          return heff_tag_at_n(v_ru_24x1_242558_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242561}), v_st_242560});
        }
        case TAG_Right: {
          V v_x_242562 = heff_field(v_x11_242559, 0);
          heff_take_n(v_x11_242559, 1ULL, 1);
          V v_m_242563 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_a_241951)}));
          V v_x1_242564 = heff_tr(heff_call(v_m_242563, 1, (V[]){v_st_242560}));
          switch (heff_tag_of(v_x1_242564)) {
          case TAG_MkPair: {
            V v_x11_242565 = heff_field(v_x1_242564, 0);
            V v_st_242566 = heff_field(v_x1_242564, 1);
            V v_ru_24x1_242564_24MkPair = heff_take_reuse_n(v_x1_242564, 3ULL, 2);
            switch (heff_tag_of(v_x11_242565)) {
            case TAG_Left: {
              V v_e_242567 = heff_field(v_x11_242565, 0);
              heff_take_n(v_x11_242565, 1ULL, 1);
              heff_drop_rec(v_kw_241948, 9);
              heff_drop(v_a_241951);
              heff_drop(v_x_242562);
              heff_drop_cell(v_ru_24x1_242564_24MkPair, 2);
              return heff_tag_at_n(v_ru_24x1_242558_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242567}), v_st_242566});
            }
            case TAG_Right: {
              V v_x_242568 = heff_field(v_x11_242565, 0);
              heff_take_n(v_x11_242565, 1ULL, 1);
              V v_t_242569 = (g_heff_2esyntax_2ecst_2elastE(v_a_241951));
              V v_e_242570 = heff_get_n(v_t_242569, 4, 9);
              V v_t_242571 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_241948, 3, 9), v_e_242570});
              V v_x_242572 = heff_tag_at_n(v_ru_24x1_242564_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_EIfThen, 2, (V[]){v_x_242562, v_x_242568}), v_t_242571});
              return heff_tag_at_n(v_ru_24x1_242558_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_242572}), v_st_242566});
            }
            default: return heff_nomatch(v_x11_242565);
            }
          }
          default: return heff_nomatch(v_x1_242564);
          }
        }
        default: return heff_nomatch(v_x11_242559);
        }
      }
      default: return heff_nomatch(v_x1_242558);
      }
    }
    case TAG_EWhile: {
      V v_m_242577 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_241949}));
      V v_x1_242578 = heff_tr(heff_call(v_m_242577, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_242578)) {
      case TAG_MkPair: {
        V v_x11_242579 = heff_field(v_x1_242578, 0);
        V v_st_242580 = heff_field(v_x1_242578, 1);
        V v_ru_24x1_242578_24MkPair = heff_take_reuse_n(v_x1_242578, 3ULL, 2);
        switch (heff_tag_of(v_x11_242579)) {
        case TAG_Left: {
          V v_e_242581 = heff_field(v_x11_242579, 0);
          heff_take_n(v_x11_242579, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_241948, 9);
          heff_drop(v_a_241951);
          return heff_tag_at_n(v_ru_24x1_242578_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242581}), v_st_242580});
        }
        case TAG_Right: {
          V v_x_242582 = heff_field(v_x11_242579, 0);
          heff_take_n(v_x11_242579, 1ULL, 1);
          V v_m_242583 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_a_241951)}));
          V v_x1_242584 = heff_tr(heff_call(v_m_242583, 1, (V[]){v_st_242580}));
          switch (heff_tag_of(v_x1_242584)) {
          case TAG_MkPair: {
            V v_x11_242585 = heff_field(v_x1_242584, 0);
            V v_st_242586 = heff_field(v_x1_242584, 1);
            V v_ru_24x1_242584_24MkPair = heff_take_reuse_n(v_x1_242584, 3ULL, 2);
            switch (heff_tag_of(v_x11_242585)) {
            case TAG_Left: {
              V v_e_242587 = heff_field(v_x11_242585, 0);
              heff_take_n(v_x11_242585, 1ULL, 1);
              heff_drop_rec(v_kw_241948, 9);
              heff_drop(v_a_241951);
              heff_drop(v_x_242582);
              heff_drop_cell(v_ru_24x1_242584_24MkPair, 2);
              return heff_tag_at_n(v_ru_24x1_242578_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242587}), v_st_242586});
            }
            case TAG_Right: {
              V v_x_242588 = heff_field(v_x11_242585, 0);
              heff_take_n(v_x11_242585, 1ULL, 1);
              V v_t_242589 = (g_heff_2esyntax_2ecst_2elastE(v_a_241951));
              V v_e_242590 = heff_get_n(v_t_242589, 4, 9);
              V v_t_242591 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_241948, 3, 9), v_e_242590});
              V v_x_242592 = heff_tag_at_n(v_ru_24x1_242584_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_EIfThen, 2, (V[]){v_x_242582, v_x_242588}), v_t_242591});
              return heff_tag_at_n(v_ru_24x1_242578_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_242592}), v_st_242586});
            }
            default: return heff_nomatch(v_x11_242585);
            }
          }
          default: return heff_nomatch(v_x1_242584);
          }
        }
        default: return heff_nomatch(v_x11_242579);
        }
      }
      default: return heff_nomatch(v_x1_242578);
      }
    }
    case TAG_EFor: {
      V v_m_242599 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_241949}));
      V v_x1_242600 = heff_tr(heff_call(v_m_242599, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_242600)) {
      case TAG_MkPair: {
        V v_x11_242601 = heff_field(v_x1_242600, 0);
        V v_st_242602 = heff_field(v_x1_242600, 1);
        V v_ru_24x1_242600_24MkPair = heff_take_reuse_n(v_x1_242600, 3ULL, 2);
        switch (heff_tag_of(v_x11_242601)) {
        case TAG_Left: {
          V v_e_242603 = heff_field(v_x11_242601, 0);
          heff_take_n(v_x11_242601, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_241948, 9);
          heff_drop(v_a_241951);
          return heff_tag_at_n(v_ru_24x1_242600_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242603}), v_st_242602});
        }
        case TAG_Right: {
          V v_x_242604 = heff_field(v_x11_242601, 0);
          heff_take_n(v_x11_242601, 1ULL, 1);
          V v_m_242605 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_a_241951)}));
          V v_x1_242606 = heff_tr(heff_call(v_m_242605, 1, (V[]){v_st_242602}));
          switch (heff_tag_of(v_x1_242606)) {
          case TAG_MkPair: {
            V v_x11_242607 = heff_field(v_x1_242606, 0);
            V v_st_242608 = heff_field(v_x1_242606, 1);
            V v_ru_24x1_242606_24MkPair = heff_take_reuse_n(v_x1_242606, 3ULL, 2);
            switch (heff_tag_of(v_x11_242607)) {
            case TAG_Left: {
              V v_e_242609 = heff_field(v_x11_242607, 0);
              heff_take_n(v_x11_242607, 1ULL, 1);
              heff_drop_rec(v_kw_241948, 9);
              heff_drop(v_a_241951);
              heff_drop(v_x_242604);
              heff_drop_cell(v_ru_24x1_242606_24MkPair, 2);
              return heff_tag_at_n(v_ru_24x1_242600_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242609}), v_st_242608});
            }
            case TAG_Right: {
              V v_x_242610 = heff_field(v_x11_242607, 0);
              heff_take_n(v_x11_242607, 1ULL, 1);
              V v_t_242611 = (g_heff_2esyntax_2ecst_2elastE(v_a_241951));
              V v_e_242612 = heff_get_n(v_t_242611, 4, 9);
              V v_t_242613 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_241948, 3, 9), v_e_242612});
              V v_x_242614 = heff_tag_at_n(v_ru_24x1_242606_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_EIfThen, 2, (V[]){v_x_242604, v_x_242610}), v_t_242613});
              return heff_tag_at_n(v_ru_24x1_242600_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_242614}), v_st_242608});
            }
            default: return heff_nomatch(v_x11_242607);
            }
          }
          default: return heff_nomatch(v_x1_242606);
          }
        }
        default: return heff_nomatch(v_x11_242601);
        }
      }
      default: return heff_nomatch(v_x1_242600);
      }
    }
    case TAG_EJump: {
      V v_m_242616 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_241949}));
      V v_x1_242617 = heff_tr(heff_call(v_m_242616, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_242617)) {
      case TAG_MkPair: {
        V v_x11_242618 = heff_field(v_x1_242617, 0);
        V v_st_242619 = heff_field(v_x1_242617, 1);
        V v_ru_24x1_242617_24MkPair = heff_take_reuse_n(v_x1_242617, 3ULL, 2);
        switch (heff_tag_of(v_x11_242618)) {
        case TAG_Left: {
          V v_e_242620 = heff_field(v_x11_242618, 0);
          heff_take_n(v_x11_242618, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_241948, 9);
          heff_drop(v_a_241951);
          return heff_tag_at_n(v_ru_24x1_242617_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242620}), v_st_242619});
        }
        case TAG_Right: {
          V v_x_242621 = heff_field(v_x11_242618, 0);
          heff_take_n(v_x11_242618, 1ULL, 1);
          V v_m_242622 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_a_241951)}));
          V v_x1_242623 = heff_tr(heff_call(v_m_242622, 1, (V[]){v_st_242619}));
          switch (heff_tag_of(v_x1_242623)) {
          case TAG_MkPair: {
            V v_x11_242624 = heff_field(v_x1_242623, 0);
            V v_st_242625 = heff_field(v_x1_242623, 1);
            V v_ru_24x1_242623_24MkPair = heff_take_reuse_n(v_x1_242623, 3ULL, 2);
            switch (heff_tag_of(v_x11_242624)) {
            case TAG_Left: {
              V v_e_242626 = heff_field(v_x11_242624, 0);
              heff_take_n(v_x11_242624, 1ULL, 1);
              heff_drop_rec(v_kw_241948, 9);
              heff_drop(v_a_241951);
              heff_drop(v_x_242621);
              heff_drop_cell(v_ru_24x1_242623_24MkPair, 2);
              return heff_tag_at_n(v_ru_24x1_242617_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242626}), v_st_242625});
            }
            case TAG_Right: {
              V v_x_242627 = heff_field(v_x11_242624, 0);
              heff_take_n(v_x11_242624, 1ULL, 1);
              V v_t_242628 = (g_heff_2esyntax_2ecst_2elastE(v_a_241951));
              V v_e_242629 = heff_get_n(v_t_242628, 4, 9);
              V v_t_242630 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_241948, 3, 9), v_e_242629});
              V v_x_242631 = heff_tag_at_n(v_ru_24x1_242623_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_EIfThen, 2, (V[]){v_x_242621, v_x_242627}), v_t_242630});
              return heff_tag_at_n(v_ru_24x1_242617_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_242631}), v_st_242625});
            }
            default: return heff_nomatch(v_x11_242624);
            }
          }
          default: return heff_nomatch(v_x1_242623);
          }
        }
        default: return heff_nomatch(v_x11_242618);
        }
      }
      default: return heff_nomatch(v_x1_242617);
      }
    }
    case TAG_EReturn: {
      V v_m_242634 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_241949}));
      V v_x1_242635 = heff_tr(heff_call(v_m_242634, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_242635)) {
      case TAG_MkPair: {
        V v_x11_242636 = heff_field(v_x1_242635, 0);
        V v_st_242637 = heff_field(v_x1_242635, 1);
        V v_ru_24x1_242635_24MkPair = heff_take_reuse_n(v_x1_242635, 3ULL, 2);
        switch (heff_tag_of(v_x11_242636)) {
        case TAG_Left: {
          V v_e_242638 = heff_field(v_x11_242636, 0);
          heff_take_n(v_x11_242636, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_241948, 9);
          heff_drop(v_a_241951);
          return heff_tag_at_n(v_ru_24x1_242635_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242638}), v_st_242637});
        }
        case TAG_Right: {
          V v_x_242639 = heff_field(v_x11_242636, 0);
          heff_take_n(v_x11_242636, 1ULL, 1);
          V v_m_242640 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_a_241951)}));
          V v_x1_242641 = heff_tr(heff_call(v_m_242640, 1, (V[]){v_st_242637}));
          switch (heff_tag_of(v_x1_242641)) {
          case TAG_MkPair: {
            V v_x11_242642 = heff_field(v_x1_242641, 0);
            V v_st_242643 = heff_field(v_x1_242641, 1);
            V v_ru_24x1_242641_24MkPair = heff_take_reuse_n(v_x1_242641, 3ULL, 2);
            switch (heff_tag_of(v_x11_242642)) {
            case TAG_Left: {
              V v_e_242644 = heff_field(v_x11_242642, 0);
              heff_take_n(v_x11_242642, 1ULL, 1);
              heff_drop_rec(v_kw_241948, 9);
              heff_drop(v_a_241951);
              heff_drop(v_x_242639);
              heff_drop_cell(v_ru_24x1_242641_24MkPair, 2);
              return heff_tag_at_n(v_ru_24x1_242635_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242644}), v_st_242643});
            }
            case TAG_Right: {
              V v_x_242645 = heff_field(v_x11_242642, 0);
              heff_take_n(v_x11_242642, 1ULL, 1);
              V v_t_242646 = (g_heff_2esyntax_2ecst_2elastE(v_a_241951));
              V v_e_242647 = heff_get_n(v_t_242646, 4, 9);
              V v_t_242648 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_241948, 3, 9), v_e_242647});
              V v_x_242649 = heff_tag_at_n(v_ru_24x1_242641_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_EIfThen, 2, (V[]){v_x_242639, v_x_242645}), v_t_242648});
              return heff_tag_at_n(v_ru_24x1_242635_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_242649}), v_st_242643});
            }
            default: return heff_nomatch(v_x11_242642);
            }
          }
          default: return heff_nomatch(v_x1_242641);
          }
        }
        default: return heff_nomatch(v_x11_242636);
        }
      }
      default: return heff_nomatch(v_x1_242635);
      }
    }
    case TAG_ENest: {
      V v_m_242654 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_241949}));
      V v_x1_242655 = heff_tr(heff_call(v_m_242654, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_242655)) {
      case TAG_MkPair: {
        V v_x11_242656 = heff_field(v_x1_242655, 0);
        V v_st_242657 = heff_field(v_x1_242655, 1);
        V v_ru_24x1_242655_24MkPair = heff_take_reuse_n(v_x1_242655, 3ULL, 2);
        switch (heff_tag_of(v_x11_242656)) {
        case TAG_Left: {
          V v_e_242658 = heff_field(v_x11_242656, 0);
          heff_take_n(v_x11_242656, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_241948, 9);
          heff_drop(v_a_241951);
          return heff_tag_at_n(v_ru_24x1_242655_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242658}), v_st_242657});
        }
        case TAG_Right: {
          V v_x_242659 = heff_field(v_x11_242656, 0);
          heff_take_n(v_x11_242656, 1ULL, 1);
          V v_m_242660 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_a_241951)}));
          V v_x1_242661 = heff_tr(heff_call(v_m_242660, 1, (V[]){v_st_242657}));
          switch (heff_tag_of(v_x1_242661)) {
          case TAG_MkPair: {
            V v_x11_242662 = heff_field(v_x1_242661, 0);
            V v_st_242663 = heff_field(v_x1_242661, 1);
            V v_ru_24x1_242661_24MkPair = heff_take_reuse_n(v_x1_242661, 3ULL, 2);
            switch (heff_tag_of(v_x11_242662)) {
            case TAG_Left: {
              V v_e_242664 = heff_field(v_x11_242662, 0);
              heff_take_n(v_x11_242662, 1ULL, 1);
              heff_drop_rec(v_kw_241948, 9);
              heff_drop(v_a_241951);
              heff_drop(v_x_242659);
              heff_drop_cell(v_ru_24x1_242661_24MkPair, 2);
              return heff_tag_at_n(v_ru_24x1_242655_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242664}), v_st_242663});
            }
            case TAG_Right: {
              V v_x_242665 = heff_field(v_x11_242662, 0);
              heff_take_n(v_x11_242662, 1ULL, 1);
              V v_t_242666 = (g_heff_2esyntax_2ecst_2elastE(v_a_241951));
              V v_e_242667 = heff_get_n(v_t_242666, 4, 9);
              V v_t_242668 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_241948, 3, 9), v_e_242667});
              V v_x_242669 = heff_tag_at_n(v_ru_24x1_242661_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_EIfThen, 2, (V[]){v_x_242659, v_x_242665}), v_t_242668});
              return heff_tag_at_n(v_ru_24x1_242655_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_242669}), v_st_242663});
            }
            default: return heff_nomatch(v_x11_242662);
            }
          }
          default: return heff_nomatch(v_x1_242661);
          }
        }
        default: return heff_nomatch(v_x11_242656);
        }
      }
      default: return heff_nomatch(v_x1_242655);
      }
    }
    case TAG_IfThen: {
      V v_m_242674 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_241949}));
      V v_x1_242675 = heff_tr(heff_call(v_m_242674, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_242675)) {
      case TAG_MkPair: {
        V v_x11_242676 = heff_field(v_x1_242675, 0);
        V v_st_242677 = heff_field(v_x1_242675, 1);
        V v_ru_24x1_242675_24MkPair = heff_take_reuse_n(v_x1_242675, 3ULL, 2);
        switch (heff_tag_of(v_x11_242676)) {
        case TAG_Left: {
          V v_e_242678 = heff_field(v_x11_242676, 0);
          heff_take_n(v_x11_242676, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_241948, 9);
          heff_drop(v_a_241951);
          return heff_tag_at_n(v_ru_24x1_242675_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242678}), v_st_242677});
        }
        case TAG_Right: {
          V v_x_242679 = heff_field(v_x11_242676, 0);
          heff_take_n(v_x11_242676, 1ULL, 1);
          V v_m_242680 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_a_241951)}));
          V v_x1_242681 = heff_tr(heff_call(v_m_242680, 1, (V[]){v_st_242677}));
          switch (heff_tag_of(v_x1_242681)) {
          case TAG_MkPair: {
            V v_x11_242682 = heff_field(v_x1_242681, 0);
            V v_st_242683 = heff_field(v_x1_242681, 1);
            V v_ru_24x1_242681_24MkPair = heff_take_reuse_n(v_x1_242681, 3ULL, 2);
            switch (heff_tag_of(v_x11_242682)) {
            case TAG_Left: {
              V v_e_242684 = heff_field(v_x11_242682, 0);
              heff_take_n(v_x11_242682, 1ULL, 1);
              heff_drop_rec(v_kw_241948, 9);
              heff_drop(v_a_241951);
              heff_drop(v_x_242679);
              heff_drop_cell(v_ru_24x1_242681_24MkPair, 2);
              return heff_tag_at_n(v_ru_24x1_242675_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242684}), v_st_242683});
            }
            case TAG_Right: {
              V v_x_242685 = heff_field(v_x11_242682, 0);
              heff_take_n(v_x11_242682, 1ULL, 1);
              V v_t_242686 = (g_heff_2esyntax_2ecst_2elastE(v_a_241951));
              V v_e_242687 = heff_get_n(v_t_242686, 4, 9);
              V v_t_242688 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_241948, 3, 9), v_e_242687});
              V v_x_242689 = heff_tag_at_n(v_ru_24x1_242681_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_EIfThen, 2, (V[]){v_x_242679, v_x_242685}), v_t_242688});
              return heff_tag_at_n(v_ru_24x1_242675_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_242689}), v_st_242683});
            }
            default: return heff_nomatch(v_x11_242682);
            }
          }
          default: return heff_nomatch(v_x1_242681);
          }
        }
        default: return heff_nomatch(v_x11_242676);
        }
      }
      default: return heff_nomatch(v_x1_242675);
      }
    }
    case TAG_ELetCond: {
      V v_p_242691 = heff_field(v_e02_241949, 1);
      V v_e_242693 = heff_field(v_e02_241949, 3);
      heff_take_n(v_e02_241949, 10ULL, 4);
      V v_t_242694 = (g_heff_2esyntax_2ecst_2elastE(heff_dup(v_a_241951)));
      V v_e_242695 = heff_get_n(v_t_242694, 4, 9);
      V v_t_242696 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_241948, 3, 9), v_e_242695});
      return (g_heff_2esyntax_2esurface_2eifLetL(v_r_240, v_t_242696, v_p_242691, v_e_242693, v_a_241951, NTAG(TAG_Nothing), v_z_242));
    }
    case TAG_ETry: {
      V v_m_242701 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_241949}));
      V v_x1_242702 = heff_tr(heff_call(v_m_242701, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_242702)) {
      case TAG_MkPair: {
        V v_x11_242703 = heff_field(v_x1_242702, 0);
        V v_st_242704 = heff_field(v_x1_242702, 1);
        V v_ru_24x1_242702_24MkPair = heff_take_reuse_n(v_x1_242702, 3ULL, 2);
        switch (heff_tag_of(v_x11_242703)) {
        case TAG_Left: {
          V v_e_242705 = heff_field(v_x11_242703, 0);
          heff_take_n(v_x11_242703, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_241948, 9);
          heff_drop(v_a_241951);
          return heff_tag_at_n(v_ru_24x1_242702_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242705}), v_st_242704});
        }
        case TAG_Right: {
          V v_x_242706 = heff_field(v_x11_242703, 0);
          heff_take_n(v_x11_242703, 1ULL, 1);
          V v_m_242707 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_a_241951)}));
          V v_x1_242708 = heff_tr(heff_call(v_m_242707, 1, (V[]){v_st_242704}));
          switch (heff_tag_of(v_x1_242708)) {
          case TAG_MkPair: {
            V v_x11_242709 = heff_field(v_x1_242708, 0);
            V v_st_242710 = heff_field(v_x1_242708, 1);
            V v_ru_24x1_242708_24MkPair = heff_take_reuse_n(v_x1_242708, 3ULL, 2);
            switch (heff_tag_of(v_x11_242709)) {
            case TAG_Left: {
              V v_e_242711 = heff_field(v_x11_242709, 0);
              heff_take_n(v_x11_242709, 1ULL, 1);
              heff_drop_rec(v_kw_241948, 9);
              heff_drop(v_a_241951);
              heff_drop(v_x_242706);
              heff_drop_cell(v_ru_24x1_242708_24MkPair, 2);
              return heff_tag_at_n(v_ru_24x1_242702_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242711}), v_st_242710});
            }
            case TAG_Right: {
              V v_x_242712 = heff_field(v_x11_242709, 0);
              heff_take_n(v_x11_242709, 1ULL, 1);
              V v_t_242713 = (g_heff_2esyntax_2ecst_2elastE(v_a_241951));
              V v_e_242714 = heff_get_n(v_t_242713, 4, 9);
              V v_t_242715 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_241948, 3, 9), v_e_242714});
              V v_x_242716 = heff_tag_at_n(v_ru_24x1_242708_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_EIfThen, 2, (V[]){v_x_242706, v_x_242712}), v_t_242715});
              return heff_tag_at_n(v_ru_24x1_242702_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_242716}), v_st_242710});
            }
            default: return heff_nomatch(v_x11_242709);
            }
          }
          default: return heff_nomatch(v_x1_242708);
          }
        }
        default: return heff_nomatch(v_x11_242703);
        }
      }
      default: return heff_nomatch(v_x1_242702);
      }
    }
    case TAG_ECatch: {
      V v_m_242721 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e02_241949}));
      V v_x1_242722 = heff_tr(heff_call(v_m_242721, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_242722)) {
      case TAG_MkPair: {
        V v_x11_242723 = heff_field(v_x1_242722, 0);
        V v_st_242724 = heff_field(v_x1_242722, 1);
        V v_ru_24x1_242722_24MkPair = heff_take_reuse_n(v_x1_242722, 3ULL, 2);
        switch (heff_tag_of(v_x11_242723)) {
        case TAG_Left: {
          V v_e_242725 = heff_field(v_x11_242723, 0);
          heff_take_n(v_x11_242723, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_rec(v_kw_241948, 9);
          heff_drop(v_a_241951);
          return heff_tag_at_n(v_ru_24x1_242722_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242725}), v_st_242724});
        }
        case TAG_Right: {
          V v_x_242726 = heff_field(v_x11_242723, 0);
          heff_take_n(v_x11_242723, 1ULL, 1);
          V v_m_242727 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_a_241951)}));
          V v_x1_242728 = heff_tr(heff_call(v_m_242727, 1, (V[]){v_st_242724}));
          switch (heff_tag_of(v_x1_242728)) {
          case TAG_MkPair: {
            V v_x11_242729 = heff_field(v_x1_242728, 0);
            V v_st_242730 = heff_field(v_x1_242728, 1);
            V v_ru_24x1_242728_24MkPair = heff_take_reuse_n(v_x1_242728, 3ULL, 2);
            switch (heff_tag_of(v_x11_242729)) {
            case TAG_Left: {
              V v_e_242731 = heff_field(v_x11_242729, 0);
              heff_take_n(v_x11_242729, 1ULL, 1);
              heff_drop_rec(v_kw_241948, 9);
              heff_drop(v_a_241951);
              heff_drop(v_x_242726);
              heff_drop_cell(v_ru_24x1_242728_24MkPair, 2);
              return heff_tag_at_n(v_ru_24x1_242722_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242731}), v_st_242730});
            }
            case TAG_Right: {
              V v_x_242732 = heff_field(v_x11_242729, 0);
              heff_take_n(v_x11_242729, 1ULL, 1);
              V v_t_242733 = (g_heff_2esyntax_2ecst_2elastE(v_a_241951));
              V v_e_242734 = heff_get_n(v_t_242733, 4, 9);
              V v_t_242735 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_241948, 3, 9), v_e_242734});
              V v_x_242736 = heff_tag_at_n(v_ru_24x1_242728_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_EIfThen, 2, (V[]){v_x_242726, v_x_242732}), v_t_242735});
              return heff_tag_at_n(v_ru_24x1_242722_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_242736}), v_st_242730});
            }
            default: return heff_nomatch(v_x11_242729);
            }
          }
          default: return heff_nomatch(v_x1_242728);
          }
        }
        default: return heff_nomatch(v_x11_242723);
        }
      }
      default: return heff_nomatch(v_x1_242722);
      }
    }
    default: return heff_nomatch(v_e02_241949);
    }
  }
  case TAG_ELetCond: {
    heff_drop_rec(v_r_240, 3);
    V v_t_242741 = (g_heff_2esyntax_2ecst_2efirstE(v_e0_241));
    V v_t_242742 = ({ V a_0 = v_e0_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e0_241, 4); r_; });
    V v_t_242743 = heff_strAppend(heff_get_n(v_t_242742, 1, 9), ((V)&g_heff_2esyntax_2esurface_2eexprL_str36));
    V v_msg_242744 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eexprL_str37), v_t_242743);
    V v_t_242745 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_242741, 3), heff_get_n(v_t_242741, 4, 9)});
    V v_t_242746 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_242744, v_t_242745, NTAG(TAG_Nothing)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_242746}), v_z_242});
  }
  case TAG_ETry: {
    V v_kw_242747 = heff_dup(heff_field(v_e0_241, 0));
    V v_ty_242748 = heff_dup(heff_field(v_e0_241, 1));
    V v_body_242749 = heff_dup(heff_field(v_e0_241, 2));
    V v_c_242750 = heff_dup(heff_field(v_e0_241, 3));
    V v_m_242751 = (g_heff_2esyntax_2esurface_2etryTypeL(heff_dup(v_r_240), v_ty_242748));
    V v_x1_242752 = heff_tr(heff_call(v_m_242751, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x1_242752)) {
    case TAG_MkPair: {
      V v_x11_242753 = heff_field(v_x1_242752, 0);
      V v_st_242754 = heff_field(v_x1_242752, 1);
      V v_ru_24x1_242752_24MkPair = heff_take_reuse_n(v_x1_242752, 3ULL, 2);
      switch (heff_tag_of(v_x11_242753)) {
      case TAG_Left: {
        V v_e_242755 = heff_field(v_x11_242753, 0);
        heff_take_n(v_x11_242753, 1ULL, 1);
        heff_drop_rec(v_r_240, 3);
        heff_drop_tag(v_e0_241, 4);
        heff_drop_rec(v_kw_242747, 9);
        heff_drop(v_body_242749);
        heff_drop(v_c_242750);
        return heff_tag_at_n(v_ru_24x1_242752_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242755}), v_st_242754});
      }
      case TAG_Right: {
        V v_x_242756 = heff_field(v_x11_242753, 0);
        V v_ru_24x11_242753_24Right = heff_take_reuse_n(v_x11_242753, 1ULL, 1);
        HeffT2 v_t_242758 = (g_heff_2esyntax_2esurface_2eblock_24cpr(heff_clo_n(g_heff_2esyntax_2esurface_2eexprL_lam11, 1, 1, (V[]){heff_dup(v_r_240)}), v_body_242749, v_st_242754));
        {
          V v_field_242759 = v_t_242758.f[0];
          V v_field_242760 = v_t_242758.f[1];
          V v_x11_242761 = v_field_242759;
          V v_st_242762 = v_field_242760;
          switch (heff_tag_of(v_x11_242761)) {
          case TAG_Left: {
            V v_e_242763 = heff_field(v_x11_242761, 0);
            heff_take_n(v_x11_242761, 1ULL, 1);
            heff_drop_rec(v_r_240, 3);
            heff_drop_tag(v_e0_241, 4);
            heff_drop_rec(v_kw_242747, 9);
            heff_drop(v_c_242750);
            heff_drop(v_x_242756);
            heff_drop_cell(v_ru_24x11_242753_24Right, 1);
            return heff_tag_at_n(v_ru_24x1_242752_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242763}), v_st_242762});
          }
          case TAG_Right: {
            V v_x_242764 = heff_field(v_x11_242761, 0);
            heff_take_n(v_x11_242761, 1ULL, 1);
            V v_m_242765 = (g_heff_2esyntax_2esurface_2ecatchL(v_r_240, v_c_242750));
            V v_x1_242766 = heff_tr(heff_call(v_m_242765, 1, (V[]){v_st_242762}));
            switch (heff_tag_of(v_x1_242766)) {
            case TAG_MkPair: {
              V v_x11_242767 = heff_field(v_x1_242766, 0);
              V v_st_242768 = heff_field(v_x1_242766, 1);
              V v_ru_24x1_242766_24MkPair = heff_take_reuse_n(v_x1_242766, 3ULL, 2);
              switch (heff_tag_of(v_x11_242767)) {
              case TAG_Left: {
                V v_e_242769 = heff_field(v_x11_242767, 0);
                heff_take_n(v_x11_242767, 1ULL, 1);
                heff_drop_tag(v_e0_241, 4);
                heff_drop_rec(v_kw_242747, 9);
                heff_drop(v_x_242756);
                heff_drop_cell(v_ru_24x11_242753_24Right, 1);
                heff_drop(v_x_242764);
                heff_drop_cell(v_ru_24x1_242766_24MkPair, 2);
                return heff_tag_at_n(v_ru_24x1_242752_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_242769}), v_st_242768});
              }
              case TAG_Right: {
                V v_x_242770 = heff_field(v_x11_242767, 0);
                heff_take_n(v_x11_242767, 1ULL, 1);
                V v_t_242771 = heff_tag_at_n(v_ru_24x11_242753_24Right, TAG_ETry, 1, (V[]){heff_tag_n(TAG_MkTry, 3, (V[]){v_x_242756, v_x_242764, v_x_242770})});
                V v_t_242772 = (g_heff_2esyntax_2ecst_2elastE(v_e0_241));
                V v_e_242773 = heff_get_n(v_t_242772, 4, 9);
                V v_t_242774 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_242747, 3, 9), v_e_242773});
                V v_x_242775 = heff_tag_at_n(v_ru_24x1_242766_24MkPair, TAG_At, 2, (V[]){v_t_242771, v_t_242774});
                return heff_tag_at_n(v_ru_24x1_242752_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_242775}), v_st_242768});
              }
              default: return heff_nomatch(v_x11_242767);
              }
            }
            default: return heff_nomatch(v_x1_242766);
            }
          }
          default: return heff_nomatch(v_x11_242761);
          }
        }
      }
      default: return heff_nomatch(v_x11_242753);
      }
    }
    default: return heff_nomatch(v_x1_242752);
    }
  }
  case TAG_ECatch: {
    heff_drop_rec(v_r_240, 3);
    V v_t_242780 = (g_heff_2esyntax_2ecst_2efirstE(v_e0_241));
    V v_t_242781 = ({ V a_0 = v_e0_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e0_241, 4); r_; });
    V v_t_242782 = heff_strAppend(heff_get_n(v_t_242781, 1, 9), ((V)&g_heff_2esyntax_2esurface_2eexprL_str38));
    V v_msg_242783 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eexprL_str39), v_t_242782);
    V v_t_242784 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_242780, 3), heff_get_n(v_t_242780, 4, 9)});
    V v_t_242785 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_242783, v_t_242784, NTAG(TAG_Nothing)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_242785}), v_z_242});
  }
  default: return heff_nomatch(v_e0_241);
  }
}
V g_heff_2esyntax_2esurface_2eexprL_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2eexprL(a[0], a[1], a[2]);
}
V g_heff_2esyntax_2esurface_2eexprL_lam0(V self, V *args) {
  V v_m_2430 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2esyntax_2esurface_2esegmentL(v_r_240, v_m_2430));
}
V g_heff_2esyntax_2esurface_2eexprL_lam1(V self, V *args) {
  V v_x_2448 = args[0];
  V v_rest_2449 = args[1];
  V v_sp_2446 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2450 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ETag, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2eexprL_str7)}), v_sp_2446});
  V v_t_2451 = heff_tag_n(TAG_Cons, 2, (V[]){v_rest_2449, NTAG(TAG_Nil)});
  return (g_heff_2esyntax_2epresyntax_2eapp(v_t_2450, heff_tag_n(TAG_Cons, 2, (V[]){v_x_2448, v_t_2451})));
}
V g_heff_2esyntax_2esurface_2eexprL_lam2(V self, V *args) {
  V v_m_2486 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2esyntax_2esurface_2eupdateSettingL(v_r_240, v_m_2486));
}
V g_heff_2esyntax_2esurface_2eexprL_lam3(V self, V *args) {
  V v_a_24140 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2esyntax_2esurface_2evariantL(v_r_240, v_a_24140));
}
V g_heff_2esyntax_2esurface_2eexprL_lam4(V self, V *args) {
  V v_m_24646 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2esyntax_2esurface_2eargL(v_r_240, v_m_24646));
}
V g_heff_2esyntax_2esurface_2eexprL_lam6(V self, V *args) {
  V v_st_24672 = args[0];
  V v_m_24671 = heff_env(self)[0];
  V v_op_24669 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24673 = heff_tr(heff_call(v_m_24671, 1, (V[]){v_st_24672}));
  switch (heff_tag_of(v_x1_24673)) {
  case TAG_MkPair: {
    V v_x11_24674 = heff_field(v_x1_24673, 0);
    V v_st_24675 = heff_field(v_x1_24673, 1);
    V v_ru_24x1_24673_24MkPair = heff_take_reuse_n(v_x1_24673, 3ULL, 2);
    switch (heff_tag_of(v_x11_24674)) {
    case TAG_Left: {
      V v_e_24676 = heff_field(v_x11_24674, 0);
      heff_take_n(v_x11_24674, 1ULL, 1);
      heff_drop(v_op_24669);
      return heff_tag_at_n(v_ru_24x1_24673_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24676}), v_st_24675});
    }
    case TAG_Right: {
      V v_x_24677 = heff_field(v_x11_24674, 0);
      V v_ru_24x11_24674_24Right = heff_take_reuse_n(v_x11_24674, 1ULL, 1);
      V v_t_24678 = heff_tag_at_n(v_ru_24x11_24674_24Right, TAG_Right, 1, (V[]){heff_rec_n(2, shape_op__e, (V[]){v_op_24669, v_x_24677})});
      return heff_tag_at_n(v_ru_24x1_24673_24MkPair, TAG_MkPair, 2, (V[]){v_t_24678, v_st_24675});
    }
    default: return heff_nomatch(v_x11_24674);
    }
  }
  default: return heff_nomatch(v_x1_24673);
  }
}
V g_heff_2esyntax_2esurface_2eexprL_lam5(V self, V *args) {
  V v_m_24665 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_24666 = (g_heff_2esyntax_2esurface_2eopRhsOf_24cpr(v_m_24665));
  {
    V v_field_24667 = v_t_24666.f[0];
    V v_field_24668 = v_t_24666.f[1];
    V v_op_24669 = v_field_24667;
    V v_e_24670 = v_field_24668;
    V v_m_24671 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_24670}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2eexprL_lam6, 1, 2, (V[]){v_m_24671, v_op_24669});
  }
}
V g_heff_2esyntax_2esurface_2eexprL_lam7(V self, V *args) {
  V v_a_24757 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2esyntax_2esurface_2ealtL(v_r_240, v_a_24757));
}
V g_heff_2esyntax_2esurface_2eexprL_lam8(V self, V *args) {
  V v_m_241811 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2esyntax_2esurface_2estmtL(v_r_240, v_m_241811));
}
V g_heff_2esyntax_2esurface_2eexprL_lam9(V self, V *args) {
  V v_m_241875 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2esyntax_2esurface_2estmtL(v_r_240, v_m_241875));
}
V g_heff_2esyntax_2esurface_2eexprL_lam10(V self, V *args) {
  V v_m_241906 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2esyntax_2esurface_2estmtL(v_r_240, v_m_241906));
}
V g_heff_2esyntax_2esurface_2eexprL_lam11(V self, V *args) {
  V v_m_242757 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2esyntax_2esurface_2estmtL(v_r_240, v_m_242757));
}
V g_heff_2esyntax_2esurface_2edefaultL_lam0(V self, V *args); static Clo g_heff_2esyntax_2esurface_2edefaultL_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2edefaultL_lam0, 1, 0};
V g_heff_2esyntax_2esurface_2edefaultL_lam1(V self, V *args);
Clo g_heff_2esyntax_2esurface_2edefaultL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2edefaultL_entry, 2, 0};

V g_heff_2esyntax_2esurface_2edefaultL(V v_r_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nothing: {
    heff_drop_rec(v_r_240, 3);
    return ((V)&g_heff_2esyntax_2esurface_2edefaultL_lam0_clo);
  }
  case TAG_Just: {
    V v_x21_244 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    switch (heff_tag_of(v_x21_244)) {
    case TAG_MkPair: {
      V v_d_246 = heff_field(v_x21_244, 1);
      heff_take_n(v_x21_244, 2ULL, 2);
      V v_m_247 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_d_246}));
      return heff_clo_n(g_heff_2esyntax_2esurface_2edefaultL_lam1, 1, 1, (V[]){v_m_247});
    }
    default: return heff_nomatch(v_x21_244);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2esurface_2edefaultL_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2edefaultL(a[0], a[1]);
}
V g_heff_2esyntax_2esurface_2edefaultL_lam0(V self, V *args) {
  V v_st_242 = args[0];
  V v_t_243 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_243, v_st_242});
}
V g_heff_2esyntax_2esurface_2edefaultL_lam1(V self, V *args) {
  V v_st_248 = args[0];
  V v_m_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_249 = heff_tr(heff_call(v_m_247, 1, (V[]){v_st_248}));
  switch (heff_tag_of(v_x1_249)) {
  case TAG_MkPair: {
    V v_x11_2410 = heff_field(v_x1_249, 0);
    V v_st_2411 = heff_field(v_x1_249, 1);
    V v_ru_24x1_249_24MkPair = heff_take_reuse_n(v_x1_249, 3ULL, 2);
    switch (heff_tag_of(v_x11_2410)) {
    case TAG_Left: {
      V v_e_2412 = heff_field(v_x11_2410, 0);
      heff_take_n(v_x11_2410, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_249_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2412}), v_st_2411});
    }
    case TAG_Right: {
      V v_x_2413 = heff_field(v_x11_2410, 0);
      V v_ru_24x11_2410_24Right = heff_take_reuse_n(v_x11_2410, 1ULL, 1);
      V v_t_2414 = heff_tag_at_n(v_ru_24x11_2410_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Just, 1, (V[]){v_x_2413})});
      return heff_tag_at_n(v_ru_24x1_249_24MkPair, TAG_MkPair, 2, (V[]){v_t_2414, v_st_2411});
    }
    default: return heff_nomatch(v_x11_2410);
    }
  }
  default: return heff_nomatch(v_x1_249);
  }
}