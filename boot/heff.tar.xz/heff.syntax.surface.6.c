// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Ann 13421
#define TAG_App 13485
#define TAG_At 8900
#define TAG_Atom 28502
#define TAG_BAnn 9252
#define TAG_BImp 16911
#define TAG_BPat 23270
#define TAG_BVar 29034
#define TAG_Braces 8205
#define TAG_Case 4415
#define TAG_DeclDefine 5286
#define TAG_DeclEquations 25755
#define TAG_DeclPrimitive 46335
#define TAG_DeclTest 38719
#define TAG_DeclTheory 39552
#define TAG_DeclWatch 51419
#define TAG_Do 8988
#define TAG_Doc 16324
#define TAG_EAnn 33099
#define TAG_EArrow 13977
#define TAG_EAssign 4102
#define TAG_EBinary 42634
#define TAG_EBreak 7195
#define TAG_ECon 35052
#define TAG_EContinue 48638
#define TAG_EDo 15964
#define TAG_EField 26142
#define TAG_EFor 37939
#define TAG_EIfThen 2245
#define TAG_EInvalid 31081
#define TAG_EJump 55703
#define TAG_ELazy 30951
#define TAG_ELet 43397
#define TAG_ELetIn 22786
#define TAG_EMatch 41631
#define TAG_ENamed 41119
#define TAG_ENeg 45306
#define TAG_ENest 28629
#define TAG_EParen 58248
#define TAG_EProject 35489
#define TAG_EReturn 59059
#define TAG_ESum 50613
#define TAG_ETag 50948
#define TAG_ETilde 53294
#define TAG_ETry 51493
#define TAG_ETuple 21722
#define TAG_EUSet 22856
#define TAG_EUpdate 6986
#define TAG_EVar 52881
#define TAG_EWhile 39339
#define TAG_EWith 38507
#define TAG_EWord 44207
#define TAG_Eqn 17358
#define TAG_ExplicitParam 63083
#define TAG_If 9134
#define TAG_IfThen 36069
#define TAG_InstB 37114
#define TAG_Lam 23588
#define TAG_LamAnn 40466
#define TAG_LamImplicit 28191
#define TAG_LamName 56383
#define TAG_Left 13886
#define TAG_MkAlt 55173
#define TAG_MkDAlts 45152
#define TAG_MkEquation 38417
#define TAG_MkTry 8097
#define TAG_Named 2049
#define TAG_Names 2064
#define TAG_Op 9330
#define TAG_OpRhs 36076
#define TAG_Ops 26942
#define TAG_PAtom 50987
#define TAG_Passes 47566
#define TAG_PatTag 47430
#define TAG_Right 62770
#define TAG_SError 24172
#define TAG_SegmentBinary 41188
#define TAG_SegmentBits 43687
#define TAG_SegmentFloat 21180
#define TAG_SegmentInteger 22664
#define TAG_SegmentUtf 5205
#define TAG_SetPath 11095
#define TAG_Sig 30557
#define TAG_SizeDefault 11444
#define TAG_SizeName 63845
#define TAG_SizeNumber 5591
#define TAG_StmtLet 16809
#define TAG_Sum 30935
#define TAG_Tup 31899
#define TAG_TypeWord 10401
#define TAG_Update 40810
#define TAG_Whole 6035
#define LBL_arms 9498206
#define LBL_at 9882
#define LBL_binder 558177493
#define LBL_binders 123633223
#define LBL_code 9554612
#define LBL_col 308218
#define LBL_diags 296935042
#define LBL_e 319
#define LBL_end 310101
#define LBL_first 298798794
#define LBL_fix 310927
#define LBL_items 301884378
#define LBL_kind 9787483
#define LBL_knot 9792335
#define LBL_known 303562589
#define LBL_lenient 294367673
#define LBL_little 844663329
#define LBL_msg 317947
#define LBL_name 9869138
#define LBL_note 9882809
#define LBL_op 10312
#define LBL_ops 319788
#define LBL_out 319944
#define LBL_pat 320285
#define LBL_patVars 1587353522
#define LBL_scope 310622830
#define LBL_severity 75955546
#define LBL_signed 1044674119
#define LBL_size 10026184
#define LBL_span 10032145
#define LBL_start 311115900
#define LBL_text 10052084
#define LBL_toks 10061290
#define LBL_ty 10476
#define LBL_unit 10090059
#define LBL_waiting 1348170899
static uint32_t shape_binder__span__pat[] = {LBL_binder, LBL_span, LBL_pat};
static uint32_t shape_code__severity__msg__span__note[] = {LBL_code, LBL_severity, LBL_msg, LBL_span, LBL_note};
static uint32_t shape_items__waiting__diags[] = {LBL_items, LBL_waiting, LBL_diags};
static uint32_t shape_op__e[] = {LBL_op, LBL_e};
static uint32_t shape_ops__out[] = {LBL_ops, LBL_out};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
static uint32_t shape_toks__scope__known__binders__patVars__fix__lenient__at__knot__arms[] = {LBL_toks, LBL_scope, LBL_known, LBL_binders, LBL_patVars, LBL_fix, LBL_lenient, LBL_at, LBL_knot, LBL_arms};
static uint32_t shape_ty__size__unit__little__signed[] = {LBL_ty, LBL_size, LBL_unit, LBL_little, LBL_signed};
static V prim_strEq_entry(V self, V *a) { (void)self; return heff_strEq(a[0], a[1]); }
static Clo prim_strEq_clo = {{0x80000000u, K_CLO, 0}, prim_strEq_entry, 2, 0};
V g_heff_2esyntax_2ecst_2efirstE(V);
V g_heff_2esyntax_2ecst_2efirstE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2efirstE_clo;
V g_heff_2esyntax_2ecst_2elastD(V);
V g_heff_2esyntax_2ecst_2elastD_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2elastD_clo;
V g_heff_2esyntax_2ecst_2elastE(V);
V g_heff_2esyntax_2ecst_2elastE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2elastE_clo;
V g_heff_2esyntax_2epresyntax_2eapp(V, V);
V g_heff_2esyntax_2epresyntax_2eapp_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eapp_clo;
V g_heff_2esyntax_2epresyntax_2eboolOf(V);
V g_heff_2esyntax_2epresyntax_2eboolOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eboolOf_clo;
V g_heff_2esyntax_2esurface_2ealtL(V, V);
V g_heff_2esyntax_2esurface_2ealtL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ealtL_clo;
V g_heff_2esyntax_2esurface_2eappendS(V, V);
V g_heff_2esyntax_2esurface_2eappendS_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eappendS_clo;
V g_heff_2esyntax_2esurface_2eappendS_24dps(V, V, V);
V g_heff_2esyntax_2esurface_2eappendS_24dps_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eappendS_24dps_clo;
V g_heff_2esyntax_2esurface_2eappendS_24f1650453221x1165775554(V, V);
V g_heff_2esyntax_2esurface_2eappendS_24f1650453221x1165775554_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eappendS_24f1650453221x1165775554_clo;
V g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830(V, V);
V g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830_clo;
V g_heff_2esyntax_2esurface_2eappendS_24tok2(V, V, V);
V g_heff_2esyntax_2esurface_2eappendS_24tok2_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eappendS_24tok2_clo;
V g_heff_2esyntax_2esurface_2eapplyOp(V, V, V);
V g_heff_2esyntax_2esurface_2eapplyOp_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eapplyOp_clo;
V g_heff_2esyntax_2esurface_2easBinderOn(V, V);
V g_heff_2esyntax_2esurface_2easBinderOn_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2easBinderOn_clo;
V g_heff_2esyntax_2esurface_2easBinderOn_24tok1(V, V, V);
V g_heff_2esyntax_2esurface_2easBinderOn_24tok1_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2easBinderOn_24tok1_clo;
V g_heff_2esyntax_2esurface_2easBinderOn_24tok2(V, V, V);
V g_heff_2esyntax_2esurface_2easBinderOn_24tok2_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2easBinderOn_24tok2_clo;
V g_heff_2esyntax_2esurface_2eatomTok(V);
V g_heff_2esyntax_2esurface_2eatomTok_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eatomTok_clo;
V g_heff_2esyntax_2esurface_2ebind(V, V, V);
V g_heff_2esyntax_2esurface_2ebind_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ebind_clo;
V g_heff_2esyntax_2esurface_2ebind_24s273834694x1861812659(V, V, V, V);
V g_heff_2esyntax_2esurface_2ebind_24s273834694x1861812659_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ebind_24s273834694x1861812659_clo;
V g_heff_2esyntax_2esurface_2ebind_24s273834694x1861812659_24tok2(V, V, V, V, V);
V g_heff_2esyntax_2esurface_2ebind_24s273834694x1861812659_24tok2_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ebind_24s273834694x1861812659_24tok2_clo;
V g_heff_2esyntax_2esurface_2ebind_24tok1(V, V, V, V);
V g_heff_2esyntax_2esurface_2ebind_24tok1_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ebind_24tok1_clo;
V g_heff_2esyntax_2esurface_2ebind_24tok2(V, V, V, V);
V g_heff_2esyntax_2esurface_2ebind_24tok2_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ebind_24tok2_clo;
V g_heff_2esyntax_2esurface_2eblock(V, V, V);
V g_heff_2esyntax_2esurface_2eblock_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eblock_clo;
V g_heff_2esyntax_2esurface_2eboundBy(V, V);
V g_heff_2esyntax_2esurface_2eboundBy_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eboundBy_clo;
V g_heff_2esyntax_2esurface_2ebracesL(V, V, V, V, V);
V g_heff_2esyntax_2esurface_2ebracesL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ebracesL_clo;
V g_heff_2esyntax_2esurface_2ecatchL(V, V);
V g_heff_2esyntax_2esurface_2ecatchL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ecatchL_clo;
V g_heff_2esyntax_2esurface_2echeckFixOf(V, V, V);
V g_heff_2esyntax_2esurface_2echeckFixOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2echeckFixOf_clo;
V g_heff_2esyntax_2esurface_2ecommentLinesFrom(V, V, V);
V g_heff_2esyntax_2esurface_2ecommentLinesFrom_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ecommentLinesFrom_clo;
V g_heff_2esyntax_2esurface_2econAtom(V, V, V);
V g_heff_2esyntax_2esurface_2econAtom_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2econAtom_clo;
V g_heff_2esyntax_2esurface_2econL(V, V, V);
V g_heff_2esyntax_2esurface_2econL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2econL_clo;
V g_heff_2esyntax_2esurface_2econcatMapS_24s1449391958x677358818(V);
V g_heff_2esyntax_2esurface_2econcatMapS_24s1449391958x677358818_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2econcatMapS_24s1449391958x677358818_clo;
HeffT2 g_heff_2esyntax_2esurface_2edataL_24s2041319846x1615558476_24cpr(V, V, V, V, V, V, V);
HeffT2 g_heff_2esyntax_2esurface_2edeclNameOf_24cpr(V);
V g_heff_2esyntax_2esurface_2edefNext(V, V, V);
V g_heff_2esyntax_2esurface_2edefNext_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2edefNext_clo;
V g_heff_2esyntax_2esurface_2edefinesOf(V, V);
V g_heff_2esyntax_2esurface_2edefinesOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2edefinesOf_clo;
V g_heff_2esyntax_2esurface_2edropN(V, V);
V g_heff_2esyntax_2esurface_2edropN_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2edropN_clo;
V g_heff_2esyntax_2esurface_2eexprL(V, V, V);
V g_heff_2esyntax_2esurface_2eexprL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eexprL_clo;
HeffT2 g_heff_2esyntax_2esurface_2efieldsOf_24cpr(V, V);
V g_heff_2esyntax_2esurface_2efirstS(V, V, V, V);
V g_heff_2esyntax_2esurface_2efirstS_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2efirstS_clo;
V g_heff_2esyntax_2esurface_2efoldr(V, V, V);
V g_heff_2esyntax_2esurface_2efoldr_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2efoldr_clo;
V g_heff_2esyntax_2esurface_2efoldr_24s503335349x1048908132(V, V);
V g_heff_2esyntax_2esurface_2efoldr_24s503335349x1048908132_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2efoldr_24s503335349x1048908132_clo;
V g_heff_2esyntax_2esurface_2ekwAtom(V, V, V);
V g_heff_2esyntax_2esurface_2ekwAtom_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ekwAtom_clo;
V g_heff_2esyntax_2esurface_2ekwAtom_24tok1(V, V, V, V);
V g_heff_2esyntax_2esurface_2ekwAtom_24tok1_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ekwAtom_24tok1_clo;
V g_heff_2esyntax_2esurface_2elamBinderL(V, V);
V g_heff_2esyntax_2esurface_2elamBinderL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2elamBinderL_clo;
HeffT2 g_heff_2esyntax_2esurface_2eletBodyL_24cpr(V, V, V, V, V, V);
V g_heff_2esyntax_2esurface_2eletL(V, V, V);
V g_heff_2esyntax_2esurface_2eletL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eletL_clo;
V g_heff_2esyntax_2esurface_2elw_get(void);
HeffT2 g_heff_2esyntax_2esurface_2enameAnn_24cpr(V);
V g_heff_2esyntax_2esurface_2enameBinder(V);
V g_heff_2esyntax_2esurface_2enameBinder_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2enameBinder_clo;
V g_heff_2esyntax_2esurface_2enameSet(V);
V g_heff_2esyntax_2esurface_2enameSet_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2enameSet_clo;
V g_heff_2esyntax_2esurface_2eopL(V, V, V, V, V);
V g_heff_2esyntax_2esurface_2eopL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eopL_clo;
V g_heff_2esyntax_2esurface_2eparamOf_24tok1(V, V, V);
V g_heff_2esyntax_2esurface_2eparamOf_24tok1_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eparamOf_24tok1_clo;
V g_heff_2esyntax_2esurface_2eparenL(V, V, V, V, V);
V g_heff_2esyntax_2esurface_2eparenL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eparenL_clo;
V g_heff_2esyntax_2esurface_2epathOf(V, V);
V g_heff_2esyntax_2esurface_2epathOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2epathOf_clo;
V g_heff_2esyntax_2esurface_2eprescanGo(V, V, V, V);
V g_heff_2esyntax_2esurface_2eprescanGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eprescanGo_clo;
V g_heff_2esyntax_2esurface_2epushAll_24s1143154608x134136784(V, V, V, V);
V g_heff_2esyntax_2esurface_2epushAll_24s1143154608x134136784_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2epushAll_24s1143154608x134136784_clo;
V g_heff_2esyntax_2esurface_2epushAll_24s44754596x1125302717(V, V, V, V);
V g_heff_2esyntax_2esurface_2epushAll_24s44754596x1125302717_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2epushAll_24s44754596x1125302717_clo;
V g_heff_2esyntax_2esurface_2epushS_24s1497306188x253922067(V, V, V, V);
V g_heff_2esyntax_2esurface_2epushS_24s1497306188x253922067_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2epushS_24s1497306188x253922067_clo;
V g_heff_2esyntax_2esurface_2epushS_24s1868233564x1858628873(V, V, V, V);
V g_heff_2esyntax_2esurface_2epushS_24s1868233564x1858628873_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2epushS_24s1868233564x1858628873_clo;
V g_heff_2esyntax_2esurface_2ereduceAll_24s2102953891x2078576216(V);
V g_heff_2esyntax_2esurface_2ereduceAll_24s2102953891x2078576216_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ereduceAll_24s2102953891x2078576216_clo;
V g_heff_2esyntax_2esurface_2erightsOf(V);
V g_heff_2esyntax_2esurface_2erightsOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2erightsOf_clo;
V g_heff_2esyntax_2esurface_2erightsOf_24dps(V, V);
V g_heff_2esyntax_2esurface_2erightsOf_24dps_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2erightsOf_24dps_clo;
V g_heff_2esyntax_2esurface_2esegmentL(V, V);
V g_heff_2esyntax_2esurface_2esegmentL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2esegmentL_clo;
V g_heff_2esyntax_2esurface_2esigNamesFrom(V, V, V);
V g_heff_2esyntax_2esurface_2esigNamesFrom_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2esigNamesFrom_clo;
V g_heff_2esyntax_2esurface_2esizeSaid(V, V, V, V, V);
V g_heff_2esyntax_2esurface_2esizeSaid_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2esizeSaid_clo;
V g_heff_2esyntax_2esurface_2especWord(V, V, V);
V g_heff_2esyntax_2esurface_2especWord_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2especWord_clo;
V g_heff_2esyntax_2esurface_2estmtL(V, V);
V g_heff_2esyntax_2esurface_2estmtL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2estmtL_clo;
V g_heff_2esyntax_2esurface_2evarAtom(V, V, V);
V g_heff_2esyntax_2esurface_2evarAtom_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2evarAtom_clo;
V g_heff_2esyntax_2esurface_2evarAtom_24tok1(V, V, V, V);
V g_heff_2esyntax_2esurface_2evarAtom_24tok1_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2evarAtom_24tok1_clo;
V g_heff_2esyntax_2esurface_2evariantL(V, V);
V g_heff_2esyntax_2esurface_2evariantL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2evariantL_clo;
V g_heff_2esyntax_2esurface_2evariantOf(V);
V g_heff_2esyntax_2esurface_2evariantOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2evariantOf_clo;
V g_heff_2esyntax_2esurface_2ewithScope(V, V, V);
V g_heff_2esyntax_2esurface_2ewithScope_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ewithScope_clo;
HeffT2 g_heff_2esyntax_2esurface_2ewithScope_24cpr(V, V, V);
V g_heff_2esyntax_2esurface_2ewithScope_24tok2(V, V, V, V);
V g_heff_2esyntax_2esurface_2ewithScope_24tok2_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ewithScope_24tok2_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1422286737x1936996242(V, V);
V g_list_2efoldl_24s1422286737x1936996242_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1422286737x1936996242_clo;
V g_list_2emap_24s1059370217x1267747283(V);
V g_list_2emap_24s1059370217x1267747283_entry(V self, V *a);
extern Clo g_list_2emap_24s1059370217x1267747283_clo;
V g_list_2emap_24s513201124x806973253(V);
V g_list_2emap_24s513201124x806973253_entry(V self, V *a);
extern Clo g_list_2emap_24s513201124x806973253_clo;
V g_prelude_2eskipSpaces(V, V, V);
V g_prelude_2eskipSpaces_entry(V self, V *a);
extern Clo g_prelude_2eskipSpaces_clo;
V g_prelude_2etraverse_24s1726903169x1952011622(V);
V g_prelude_2etraverse_24s1726903169x1952011622_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s1726903169x1952011622_clo;
V g_prelude_2etraverse_24s499544530x2060473942(V, V);
V g_prelude_2etraverse_24s499544530x2060473942_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s499544530x2060473942_clo;
V g_prelude_2etraverse_24s518454301x170091462(V);
V g_prelude_2etraverse_24s518454301x170091462_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s518454301x170091462_clo;
V g_std_2eordmap_2eempty_get(void);
V g_std_2eordmap_2einsert_24s615484302x989744458(V, V, V);
V g_std_2eordmap_2einsert_24s615484302x989744458_entry(V self, V *a);
extern Clo g_std_2eordmap_2einsert_24s615484302x989744458_clo;
HeffT2 g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(V, V);
Clo g_heff_2esyntax_2esurface_2ebind_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2ebind_entry, 3, 0};

V g_heff_2esyntax_2esurface_2ebind(V v_m_240, V v_f_241, V v_st_242) {
top: ;
  V v_x1_243 = heff_tr(heff_call(v_m_240, 1, (V[]){v_st_242}));
  switch (heff_tag_of(v_x1_243)) {
  case TAG_MkPair: {
    V v_x11_244 = heff_field(v_x1_243, 0);
    V v_st_245 = heff_field(v_x1_243, 1);
    V v_ru_24x1_243_24MkPair = heff_take_reuse_n(v_x1_243, 3ULL, 2);
    switch (heff_tag_of(v_x11_244)) {
    case TAG_Left: {
      V v_e_246 = heff_field(v_x11_244, 0);
      V v_ru_24x11_244_24Left = heff_take_reuse_n(v_x11_244, 1ULL, 1);
      heff_drop(v_f_241);
      return heff_tag_at_n(v_ru_24x1_243_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_244_24Left, TAG_Left, 1, (V[]){v_e_246}), v_st_245});
    }
    case TAG_Right: {
      V v_x_247 = heff_field(v_x11_244, 0);
      heff_take_n(v_x11_244, 1ULL, 1);
      heff_drop_cell(v_ru_24x1_243_24MkPair, 2);
      return heff_tail(v_f_241, 2, (V[]){v_x_247, v_st_245});
    }
    default: return heff_nomatch(v_x11_244);
    }
  }
  default: return heff_nomatch(v_x1_243);
  }
}
V g_heff_2esyntax_2esurface_2ebind_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2ebind(a[0], a[1], a[2]);
}
Clo g_heff_2esyntax_2esurface_2enameSet_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2enameSet_entry, 1, 0};

V g_heff_2esyntax_2esurface_2enameSet(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_dup(g_std_2eordmap_2eempty_get());
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    V v_t_243 = (g_heff_2esyntax_2esurface_2enameSet(v_rest_242));
    return (g_std_2eordmap_2einsert_24s615484302x989744458(v_t_243, heff_dup(v_x_241), NTAG(TAG_MkUnit)));
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2esurface_2enameSet_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2esurface_2enameSet(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2esyntax_2esurface_2edefinesOf_str0, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2edefinesOf_str1, 18, "` is defined twice");
HEFF_LIT(g_heff_2esyntax_2esurface_2edefinesOf_str2, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2edefinesOf_str3, 76, "` is defined twice: its equations are apart, another definition between them");
HEFF_LIT(g_heff_2esyntax_2esurface_2edefinesOf_str4, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2edefinesOf_str5, 76, "` is defined twice: its equations are apart, another definition between them");
HEFF_LIT(g_heff_2esyntax_2esurface_2edefinesOf_str6, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2edefinesOf_str7, 18, "` is defined twice");
HEFF_LIT(g_heff_2esyntax_2esurface_2edefinesOf_str8, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2edefinesOf_str9, 18, "` is defined twice");
HEFF_LIT(g_heff_2esyntax_2esurface_2edefinesOf_str10, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2edefinesOf_str11, 18, "` is defined twice");
Clo g_heff_2esyntax_2esurface_2edefinesOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2edefinesOf_entry, 2, 0};

V g_heff_2esyntax_2esurface_2edefinesOf(V v_open_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Sig: {
    V v_f_243 = heff_field(v_x2_241, 1);
    V v_fsp_244 = heff_field(v_x2_241, 2);
    V v_ru_24x2_241_24Sig = heff_take_reuse_n(v_x2_241, 6ULL, 5);
    heff_drop(v_open_240);
    V v_t_247 = heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2esurface_2edefinesOf_str0), heff_dup(v_f_243)), ((V)&g_heff_2esyntax_2esurface_2edefinesOf_str1));
    return heff_tag_at_n(v_ru_24x2_241_24Sig, TAG_Names, 5, (V[]){heff_dup(v_f_243), v_fsp_244, heff_tag_n(TAG_Just, 1, (V[]){v_f_243}), v_t_247, NTAG(TAG_False)});
  }
  case TAG_Eqn: {
    V v_g_248 = heff_field(v_x2_241, 0);
    V v_e_249 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 3);
    switch (heff_tag_of(v_open_240)) {
    case TAG_Nothing: {
      V v_t_2417;
      switch (heff_tag_of(v_e_249)) {
      case TAG_At: {
        V v_x11_2411 = heff_field(v_e_249, 0);
        heff_take_n(v_e_249, 1ULL, 2);
        switch (heff_tag_of(v_x11_2411)) {
        case TAG_MkEquation: {
          V v_fsp_2414 = heff_field(v_x11_2411, 1);
          heff_take_n(v_x11_2411, 2ULL, 4);
          v_t_2417 = v_fsp_2414;
          break;
        }
        default: heff_nomatch(v_x11_2411);
        }
        break;
      }
      default: heff_nomatch(v_e_249);
      }
      V v_t_2418 = heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2esurface_2edefinesOf_str2), heff_dup(v_g_248)), ((V)&g_heff_2esyntax_2esurface_2edefinesOf_str3));
      return heff_tag_n(TAG_Names, 5, (V[]){heff_dup(v_g_248), v_t_2417, heff_tag_n(TAG_Just, 1, (V[]){v_g_248}), v_t_2418, NTAG(TAG_False)});
    }
    case TAG_Just: {
      V v_f_2419 = heff_field(v_open_240, 0);
      V v_ru_24open_240_24Just = heff_take_reuse_n(v_open_240, 1ULL, 1);
      if (heff_strEq_c_lent(v_f_2419, v_g_248, 1)) {
        heff_drop(v_g_248);
        heff_drop(v_e_249);
        heff_drop_cell(v_ru_24open_240_24Just, 1);
        return NTAG(TAG_Passes);
      } else {
        V v_t_2426;
        switch (heff_tag_of(v_e_249)) {
        case TAG_At: {
          V v_x11_2420 = heff_field(v_e_249, 0);
          heff_take_n(v_e_249, 1ULL, 2);
          switch (heff_tag_of(v_x11_2420)) {
          case TAG_MkEquation: {
            V v_fsp_2423 = heff_field(v_x11_2420, 1);
            heff_take_n(v_x11_2420, 2ULL, 4);
            v_t_2426 = v_fsp_2423;
            break;
          }
          default: heff_nomatch(v_x11_2420);
          }
          break;
        }
        default: heff_nomatch(v_e_249);
        }
        V v_t_2427 = heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2esurface_2edefinesOf_str4), heff_dup(v_g_248)), ((V)&g_heff_2esyntax_2esurface_2edefinesOf_str5));
        return heff_tag_n(TAG_Names, 5, (V[]){heff_dup(v_g_248), v_t_2426, heff_tag_at_n(v_ru_24open_240_24Just, TAG_Just, 1, (V[]){v_g_248}), v_t_2427, NTAG(TAG_False)});
      }
    }
    default: return heff_nomatch(v_open_240);
    }
  }
  case TAG_Whole: {
    V v_d_2428 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    heff_drop(v_open_240);
    V v_x1_2429 = v_d_2428;
    switch (heff_tag_of(v_x1_2429)) {
    case TAG_At: {
      V v_x11_2430 = heff_field(v_x1_2429, 0);
      heff_take_n(v_x1_2429, 1ULL, 2);
      switch (heff_tag_of(v_x11_2430)) {
      case TAG_DeclEquations: {
        heff_take_n(v_x11_2430, 0ULL, 5);
        return NTAG(TAG_Passes);
      }
      case TAG_DeclDefine: {
        V v_x_2437 = heff_field(v_x11_2430, 0);
        V v_xsp_2438 = heff_field(v_x11_2430, 1);
        V v_ru_24x11_2430_24DeclDefine = heff_take_reuse_n(v_x11_2430, 3ULL, 5);
        V v_t_2442 = heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2esurface_2edefinesOf_str6), heff_dup(v_x_2437)), ((V)&g_heff_2esyntax_2esurface_2edefinesOf_str7));
        return heff_tag_at_n(v_ru_24x11_2430_24DeclDefine, TAG_Names, 5, (V[]){v_x_2437, v_xsp_2438, NTAG(TAG_Nothing), v_t_2442, NTAG(TAG_False)});
      }
      case TAG_DeclTheory: {
        V v_x_2443 = heff_field(v_x11_2430, 0);
        V v_xsp_2444 = heff_field(v_x11_2430, 1);
        heff_take_n(v_x11_2430, 3ULL, 4);
        V v_t_2447 = heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2esurface_2edefinesOf_str8), heff_dup(v_x_2443)), ((V)&g_heff_2esyntax_2esurface_2edefinesOf_str9));
        return heff_tag_n(TAG_Names, 5, (V[]){v_x_2443, v_xsp_2444, NTAG(TAG_Nothing), v_t_2447, NTAG(TAG_False)});
      }
      case TAG_DeclPrimitive: {
        V v_x_2448 = heff_field(v_x11_2430, 0);
        V v_xsp_2449 = heff_field(v_x11_2430, 1);
        heff_take_n(v_x11_2430, 3ULL, 3);
        V v_t_2451 = heff_strAppend(heff_strAppend(((V)&g_heff_2esyntax_2esurface_2edefinesOf_str10), heff_dup(v_x_2448)), ((V)&g_heff_2esyntax_2esurface_2edefinesOf_str11));
        return heff_tag_n(TAG_Names, 5, (V[]){v_x_2448, v_xsp_2449, NTAG(TAG_Nothing), v_t_2451, NTAG(TAG_True)});
      }
      case TAG_DeclTest: {
        heff_take_n(v_x11_2430, 0ULL, 2);
        return NTAG(TAG_Passes);
      }
      case TAG_DeclWatch: {
        heff_take_n(v_x11_2430, 0ULL, 1);
        return NTAG(TAG_Passes);
      }
      default: return heff_nomatch(v_x11_2430);
      }
    }
    default: return heff_nomatch(v_x1_2429);
    }
  }
  case TAG_Doc: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_open_240);
    return NTAG(TAG_Passes);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2esurface_2edefinesOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2edefinesOf(a[0], a[1]);
}
HEFF_LIT(g_heff_2esyntax_2esurface_2ecommentLinesFrom_str0, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecommentLinesFrom_str1, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecommentLinesFrom_str2, 2, "--");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecommentLinesFrom_str3, 1, "\012");
Clo g_heff_2esyntax_2esurface_2ecommentLinesFrom_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2ecommentLinesFrom_entry, 3, 0};

V g_heff_2esyntax_2esurface_2ecommentLinesFrom(V v_src_240, V v_i_241, V v_to_242) {
top: ;
  V v_j_243 = heff_strFind_lent(((V)&g_heff_2esyntax_2esurface_2ecommentLinesFrom_str0), v_src_240, v_i_241, 1);
  V v_t_244;
  if (heff_intLt_c_lent(v_j_243, MK_INT(0LL), 2)) {
    heff_drop(v_j_243);
    v_t_244 = heff_strLength_lent(v_src_240, 0);
  } else {
    v_t_244 = v_j_243;
  }
  if (heff_intLe_c_lent(v_to_242, v_t_244, 2)) {
    heff_drop(v_i_241);
    heff_drop(v_to_242);
    return NTAG(TAG_True);
  } else {
    V v_d_245 = heff_strLength_lent(v_src_240, 0);
    V v_j_246 = heff_strFind_lent(((V)&g_heff_2esyntax_2esurface_2ecommentLinesFrom_str1), v_src_240, v_i_241, 1);
    V v_t_247;
    if (heff_intLt_c_lent(v_j_246, MK_INT(0LL), 2)) {
      heff_drop(v_j_246);
      v_t_247 = v_d_245;
    } else {
      heff_drop(v_d_245);
      v_t_247 = v_j_246;
    }
    V v_s_248 = heff_strSlice_lent(v_src_240, v_i_241, v_t_247, 4);
    V v_t_249 = (g_prelude_2eskipSpaces(v_s_248, MK_INT(0LL), MK_INT(1LL)));
    int64_t v_t_2410 = (heff_unbox_word(heff_strLength_lent(v_s_248, 0)) - ((int64_t)1ULL));
    V v_t_2411 = (g_prelude_2eskipSpaces(v_s_248, heff_box_word(v_t_2410), MK_INT(-1LL)));
    V v_s_2412 = heff_strSlice(v_s_248, v_t_249, heff_intAdd(v_t_2411, MK_INT(1LL)));
    if (heff_strEq_c(heff_strSlice(v_s_2412, MK_INT(0LL), MK_INT(2LL)), ((V)&g_heff_2esyntax_2esurface_2ecommentLinesFrom_str2))) {
      V v_d_2413 = heff_strLength_lent(v_src_240, 0);
      V v_j_2414 = heff_strFind_lent(((V)&g_heff_2esyntax_2esurface_2ecommentLinesFrom_str3), v_src_240, v_i_241, 5);
      V v_t_2415;
      if (heff_intLt_c_lent(v_j_2414, MK_INT(0LL), 2)) {
        heff_drop(v_j_2414);
        v_t_2415 = v_d_2413;
      } else {
        heff_drop(v_d_2413);
        v_t_2415 = v_j_2414;
      }
      V t_0 = v_src_240;
      V t_1 = heff_intAdd(v_t_2415, MK_INT(1LL));
      V t_2 = v_to_242;
      v_src_240 = t_0;
      v_i_241 = t_1;
      v_to_242 = t_2;
      goto top;
    } else {
      heff_drop(v_i_241);
      heff_drop(v_to_242);
      return NTAG(TAG_False);
    }
  }
}
V g_heff_2esyntax_2esurface_2ecommentLinesFrom_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2esurface_2ecommentLinesFrom(a0, a[1], a[2]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2esyntax_2esurface_2edefNext_str0, 1, "\012");
Clo g_heff_2esyntax_2esurface_2edefNext_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2edefNext_entry, 3, 0};

V g_heff_2esyntax_2esurface_2edefNext(V v_src_240, V v_p_241, V v_it_242) {
top: ;
  V v_t_243 = heff_dup(heff_rfield(v_p_241, 1));
  V v_t_2429;
  switch (heff_tag_of(v_t_243)) {
  case TAG_Nil: {
    v_t_2429 = NTAG(TAG_False);
    break;
  }
  case TAG_Cons: {
    V v_d_244 = heff_field(v_t_243, 0);
    heff_take_n(v_t_243, 1ULL, 2);
    V v_d_246 = heff_strLength_lent(v_src_240, 0);
    V v_t_249;
    switch (heff_tag_of(v_d_244)) {
    case TAG_At: {
      V v_s_248 = heff_field(v_d_244, 1);
      heff_take_n(v_d_244, 2ULL, 2);
      v_t_249 = v_s_248;
      break;
    }
    default: heff_nomatch(v_d_244);
    }
    V v_j_2410 = heff_strFind(((V)&g_heff_2esyntax_2esurface_2edefNext_str0), heff_dup(v_src_240), heff_get_n(v_t_249, 1, 2));
    V v_t_2411;
    if (heff_intLt_c_lent(v_j_2410, MK_INT(0LL), 2)) {
      heff_drop(v_j_2410);
      v_t_2411 = v_d_246;
    } else {
      heff_drop(v_d_246);
      v_t_2411 = v_j_2410;
    }
    V v_t_2428;
    switch (heff_tag_of(v_it_242)) {
    case TAG_Sig: {
      V v_sp_2416 = heff_dup(heff_field(v_it_242, 4));
      v_t_2428 = heff_get_n(v_sp_2416, 0, 2);
      break;
    }
    case TAG_Eqn: {
      V v_sp_2419 = heff_dup(heff_field(v_it_242, 2));
      v_t_2428 = heff_get_n(v_sp_2419, 0, 2);
      break;
    }
    case TAG_Whole: {
      V v_d_2420 = heff_dup(heff_field(v_it_242, 0));
      V v_t_2423;
      switch (heff_tag_of(v_d_2420)) {
      case TAG_At: {
        V v_s_2422 = heff_field(v_d_2420, 1);
        heff_take_n(v_d_2420, 2ULL, 2);
        v_t_2423 = v_s_2422;
        break;
      }
      default: heff_nomatch(v_d_2420);
      }
      v_t_2428 = heff_get_n(v_t_2423, 0, 2);
      break;
    }
    case TAG_Doc: {
      V v_d_2424 = heff_dup(heff_field(v_it_242, 0));
      V v_t_2427;
      switch (heff_tag_of(v_d_2424)) {
      case TAG_At: {
        V v_s_2426 = heff_field(v_d_2424, 1);
        heff_take_n(v_d_2424, 2ULL, 2);
        v_t_2427 = v_s_2426;
        break;
      }
      default: heff_nomatch(v_d_2424);
      }
      v_t_2428 = heff_get_n(v_t_2427, 0, 2);
      break;
    }
    default: heff_nomatch(v_it_242);
    }
    v_t_2429 = (g_heff_2esyntax_2esurface_2ecommentLinesFrom(v_src_240, heff_intAdd(v_t_2411, MK_INT(1LL)), v_t_2428));
    break;
  }
  default: heff_nomatch(v_t_243);
  }
  if ((heff_dup(v_t_2429) == NTAG(TAG_True))) {
    heff_drop(v_t_2429);
    V v_t_2430 = heff_tag_n(TAG_Cons, 2, (V[]){v_it_242, heff_take_field(v_p_241, 0)});
    V v_items_2431 = (g_heff_2esyntax_2esurface_2eappendS_24f1650453221x1165775554(v_t_2430, heff_take_field(v_p_241, 1)));
    return ({ V rv_0 = v_items_2431; V rv_1 = NTAG(TAG_Nil); V rr_ = heff_rec_reuse_nf(v_p_241, 4ULL, 3, shape_items__waiting__diags, 48u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; rr_; });
  } else {
    heff_drop(v_t_2429);
    V v_items_2432 = (g_heff_2esyntax_2esurface_2eappendS_24f1650453221x1165775554(heff_dup(heff_rfield(v_p_241, 0)), heff_dup(heff_rfield(v_p_241, 1))));
    V v_diags_2433 = (g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830(heff_dup(heff_rfield(v_p_241, 2)), heff_dup(heff_rfield(v_p_241, 1))));
    heff_drop(v_diags_2433);
    V v_items_2434 = heff_tag_n(TAG_Cons, 2, (V[]){v_it_242, v_items_2432});
    V v_items_2435 = (g_heff_2esyntax_2esurface_2eappendS_24f1650453221x1165775554(heff_take_field(v_p_241, 0), heff_dup(heff_rfield(v_p_241, 1))));
    heff_drop(v_items_2435);
    V v_diags_2436 = (g_heff_2esyntax_2esurface_2eappendS_24f1782976261x1407183830(heff_take_field(v_p_241, 2), heff_get_n(v_p_241, 1, 3)));
    return heff_rec_n(3, shape_items__waiting__diags, (V[]){v_items_2434, NTAG(TAG_Nil), v_diags_2436});
  }
}
V g_heff_2esyntax_2esurface_2edefNext_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2esurface_2edefNext(a0, a[1], a[2]); heff_drop(a0); return r;
}
V g_heff_2esyntax_2esurface_2evariantL_lam0(V self, V *args);
V g_heff_2esyntax_2esurface_2evariantL_lam1(V self, V *args);
Clo g_heff_2esyntax_2esurface_2evariantL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2evariantL_entry, 2, 0};

V g_heff_2esyntax_2esurface_2evariantL(V v_r_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_ECon: {
    V v_c_242 = heff_field(v_x2_241, 0);
    V v_args_243 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_m_244 = (g_heff_2esyntax_2esurface_2econL(v_r_240, v_c_242, v_args_243));
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_lam0, 1, 1, (V[]){v_m_244});
  }
  default: {
    V v_m_2412 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_x2_241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2evariantL_lam1, 1, 1, (V[]){v_m_2412});
  }
  }
}
V g_heff_2esyntax_2esurface_2evariantL_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2evariantL(a[0], a[1]);
}
V g_heff_2esyntax_2esurface_2evariantL_lam0(V self, V *args) {
  V v_st_245 = args[0];
  V v_m_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_246 = heff_tr(heff_call(v_m_244, 1, (V[]){v_st_245}));
  switch (heff_tag_of(v_x1_246)) {
  case TAG_MkPair: {
    V v_x11_247 = heff_field(v_x1_246, 0);
    V v_st_248 = heff_field(v_x1_246, 1);
    V v_ru_24x1_246_24MkPair = heff_take_reuse_n(v_x1_246, 3ULL, 2);
    switch (heff_tag_of(v_x11_247)) {
    case TAG_Left: {
      V v_e_249 = heff_field(v_x11_247, 0);
      V v_ru_24x11_247_24Left = heff_take_reuse_n(v_x11_247, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_246_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_247_24Left, TAG_Left, 1, (V[]){v_e_249}), v_st_248});
    }
    case TAG_Right: {
      V v_x_2410 = heff_field(v_x11_247, 0);
      V v_ru_24x11_247_24Right = heff_take_reuse_n(v_x11_247, 1ULL, 1);
      V v_x_2411 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_2410));
      return heff_tag_at_n(v_ru_24x1_246_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_247_24Right, TAG_Right, 1, (V[]){v_x_2411}), v_st_248});
    }
    default: return heff_nomatch(v_x11_247);
    }
  }
  default: return heff_nomatch(v_x1_246);
  }
}
V g_heff_2esyntax_2esurface_2evariantL_lam1(V self, V *args) {
  V v_st_2413 = args[0];
  V v_m_2412 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2414 = heff_tr(heff_call(v_m_2412, 1, (V[]){v_st_2413}));
  switch (heff_tag_of(v_x1_2414)) {
  case TAG_MkPair: {
    V v_x11_2415 = heff_field(v_x1_2414, 0);
    V v_st_2416 = heff_field(v_x1_2414, 1);
    V v_ru_24x1_2414_24MkPair = heff_take_reuse_n(v_x1_2414, 3ULL, 2);
    switch (heff_tag_of(v_x11_2415)) {
    case TAG_Left: {
      V v_e_2417 = heff_field(v_x11_2415, 0);
      V v_ru_24x11_2415_24Left = heff_take_reuse_n(v_x11_2415, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_2414_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_2415_24Left, TAG_Left, 1, (V[]){v_e_2417}), v_st_2416});
    }
    case TAG_Right: {
      V v_x_2418 = heff_field(v_x11_2415, 0);
      V v_ru_24x11_2415_24Right = heff_take_reuse_n(v_x11_2415, 1ULL, 1);
      V v_x_2419 = (g_heff_2esyntax_2esurface_2evariantOf(v_x_2418));
      return heff_tag_at_n(v_ru_24x1_2414_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_2415_24Right, TAG_Right, 1, (V[]){v_x_2419}), v_st_2416});
    }
    default: return heff_nomatch(v_x11_2415);
    }
  }
  default: return heff_nomatch(v_x1_2414);
  }
}
HEFF_LIT(g_heff_2esyntax_2esurface_2elamBinderL_str0, 7, "pat#arg");
HEFF_LIT(g_heff_2esyntax_2esurface_2elamBinderL_str1, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2elamBinderL_str2, 1, "`");
V g_heff_2esyntax_2esurface_2elamBinderL_lam0(V self, V *args);
V g_heff_2esyntax_2esurface_2elamBinderL_lam1(V self, V *args);
V g_heff_2esyntax_2esurface_2elamBinderL_lam2(V self, V *args);
V g_heff_2esyntax_2esurface_2elamBinderL_lam3(V self, V *args);
V g_heff_2esyntax_2esurface_2elamBinderL_lam4(V self, V *args);
Clo g_heff_2esyntax_2esurface_2elamBinderL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2elamBinderL_entry, 2, 0};

V g_heff_2esyntax_2esurface_2elamBinderL(V v_r_240, V v_e_241) {
top: ;
  V v_e_242 = heff_take_field(v_r_240, 0);
  V v_pat_243 = heff_get_n(v_r_240, 1, 3);
  switch (heff_tag_of(v_e_241)) {
  case TAG_BVar: {
    V v_x_244 = heff_field(v_e_241, 0);
    heff_take_n(v_e_241, 1ULL, 1);
    heff_drop(v_e_242);
    heff_drop(v_pat_243);
    V v_text_245 = heff_take_field(v_x_244, 1);
    V v_start_246 = heff_take_field(v_x_244, 3);
    V v_end_247 = heff_get_n(v_x_244, 4, 9);
    return heff_clo_n(g_heff_2esyntax_2esurface_2elamBinderL_lam0, 1, 3, (V[]){v_text_245, v_start_246, v_end_247});
  }
  case TAG_BImp: {
    V v_o_2411 = heff_field(v_e_241, 0);
    V v_x_2412 = heff_field(v_e_241, 1);
    V v_c_2413 = heff_field(v_e_241, 2);
    heff_take_n(v_e_241, 7ULL, 3);
    heff_drop(v_e_242);
    heff_drop(v_pat_243);
    V v_text_2414 = heff_take_field(v_x_2412, 1);
    V v_start_2415 = heff_take_field(v_x_2412, 3);
    V v_end_2416 = heff_get_n(v_x_2412, 4, 9);
    return heff_clo_n(g_heff_2esyntax_2esurface_2elamBinderL_lam1, 1, 5, (V[]){v_text_2414, v_start_2415, v_end_2416, v_o_2411, v_c_2413});
  }
  case TAG_BAnn: {
    V v_x_2422 = heff_field(v_e_241, 1);
    V v_ty_2424 = heff_field(v_e_241, 3);
    heff_take_n(v_e_241, 10ULL, 5);
    heff_drop(v_pat_243);
    V v_text_2426 = heff_take_field(v_x_2422, 1);
    V v_start_2427 = heff_take_field(v_x_2422, 3);
    V v_end_2428 = heff_get_n(v_x_2422, 4, 9);
    V v_m_2429 = heff_tr(heff_call(v_e_242, 1, (V[]){v_ty_2424}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2elamBinderL_lam2, 1, 4, (V[]){v_m_2429, v_text_2426, v_start_2427, v_end_2428});
  }
  case TAG_BPat: {
    V v_p_2442 = heff_field(v_e_241, 0);
    heff_take_n(v_e_241, 1ULL, 1);
    heff_drop(v_e_242);
    V v_m_2443 = heff_tr(heff_call(v_pat_243, 1, (V[]){v_p_2442}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2elamBinderL_lam3, 1, 1, (V[]){v_m_2443});
  }
  default: {
    heff_drop(v_e_242);
    heff_drop(v_pat_243);
    V v_t_2457 = (g_heff_2esyntax_2ecst_2efirstE(v_e_241));
    V v_start_2458 = heff_take_field(v_t_2457, 3);
    V v_end_2459 = heff_get_n(v_t_2457, 4, 9);
    V v_t_2460 = ({ V a_0 = v_e_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop(v_e_241); r_; });
    V v_t_2461 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2elamBinderL_str1), heff_get_n(v_t_2460, 1, 9));
    V v_msg_2462 = heff_strAppend(v_t_2461, ((V)&g_heff_2esyntax_2esurface_2elamBinderL_str2));
    return heff_clo_n(g_heff_2esyntax_2esurface_2elamBinderL_lam4, 1, 3, (V[]){v_msg_2462, v_start_2458, v_end_2459});
  }
  }
}
V g_heff_2esyntax_2esurface_2elamBinderL_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2elamBinderL(a[0], a[1]);
}
V g_heff_2esyntax_2esurface_2elamBinderL_lam0(V self, V *args) {
  V v_st_248 = args[0];
  V v_text_245 = heff_env(self)[0];
  V v_start_246 = heff_env(self)[1];
  V v_end_247 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_249 = heff_tag_n(TAG_LamName, 2, (V[]){v_text_245, heff_rec_n(2, shape_start__end, (V[]){heff_dup(v_start_246), heff_dup(v_end_247)})});
  V v_t_2410 = heff_rec_n(3, shape_binder__span__pat, (V[]){v_t_249, heff_rec_n(2, shape_start__end, (V[]){v_start_246, v_end_247}), NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2410}), v_st_248});
}
V g_heff_2esyntax_2esurface_2elamBinderL_lam1(V self, V *args) {
  V v_st_2417 = args[0];
  V v_text_2414 = heff_env(self)[0];
  V v_start_2415 = heff_env(self)[1];
  V v_end_2416 = heff_env(self)[2];
  V v_o_2411 = heff_env(self)[3];
  V v_c_2413 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2418 = heff_tag_n(TAG_LamImplicit, 2, (V[]){v_text_2414, heff_rec_n(2, shape_start__end, (V[]){v_start_2415, v_end_2416})});
  V v_t_2419 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_o_2411, 3, 9), heff_get_n(v_c_2413, 4, 9)});
  V v_t_2420 = heff_rec_n(3, shape_binder__span__pat, (V[]){v_t_2418, v_t_2419, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2420}), v_st_2417});
}
V g_heff_2esyntax_2esurface_2elamBinderL_lam2(V self, V *args) {
  V v_st_2430 = args[0];
  V v_m_2429 = heff_env(self)[0];
  V v_text_2426 = heff_env(self)[1];
  V v_start_2427 = heff_env(self)[2];
  V v_end_2428 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x1_2431 = heff_tr(heff_call(v_m_2429, 1, (V[]){v_st_2430}));
  switch (heff_tag_of(v_x1_2431)) {
  case TAG_MkPair: {
    V v_x11_2432 = heff_field(v_x1_2431, 0);
    V v_st_2433 = heff_field(v_x1_2431, 1);
    V v_ru_24x1_2431_24MkPair = heff_take_reuse_n(v_x1_2431, 3ULL, 2);
    switch (heff_tag_of(v_x11_2432)) {
    case TAG_Left: {
      V v_e_2434 = heff_field(v_x11_2432, 0);
      V v_ru_24x11_2432_24Left = heff_take_reuse_n(v_x11_2432, 1ULL, 1);
      heff_drop(v_text_2426);
      heff_drop(v_start_2427);
      heff_drop(v_end_2428);
      return heff_tag_at_n(v_ru_24x1_2431_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_2432_24Left, TAG_Left, 1, (V[]){v_e_2434}), v_st_2433});
    }
    case TAG_Right: {
      V v_x_2435 = heff_field(v_x11_2432, 0);
      V v_ru_24x11_2432_24Right = heff_take_reuse_n(v_x11_2432, 1ULL, 1);
      V v_t_2436 = heff_tag_n(TAG_LamAnn, 3, (V[]){v_text_2426, heff_rec_n(2, shape_start__end, (V[]){heff_dup(v_start_2427), v_end_2428}), heff_dup(v_x_2435)});
      V v_t_2439;
      switch (heff_tag_of(v_x_2435)) {
      case TAG_At: {
        V v_s_2438 = heff_field(v_x_2435, 1);
        heff_take_n(v_x_2435, 2ULL, 2);
        v_t_2439 = v_s_2438;
        break;
      }
      default: heff_nomatch(v_x_2435);
      }
      V v_t_2440 = ({ V rv_0 = v_start_2427; V rr_ = heff_rec_reuse_nf(v_t_2439, 2ULL, 2, shape_start__end, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
      V v_t_2441 = heff_rec_n(3, shape_binder__span__pat, (V[]){v_t_2436, v_t_2440, NTAG(TAG_Nothing)});
      return heff_tag_at_n(v_ru_24x1_2431_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_2432_24Right, TAG_Right, 1, (V[]){v_t_2441}), v_st_2433});
    }
    default: return heff_nomatch(v_x11_2432);
    }
  }
  default: return heff_nomatch(v_x1_2431);
  }
}
V g_heff_2esyntax_2esurface_2elamBinderL_lam3(V self, V *args) {
  V v_st_2444 = args[0];
  V v_m_2443 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2445 = heff_tr(heff_call(v_m_2443, 1, (V[]){v_st_2444}));
  switch (heff_tag_of(v_x1_2445)) {
  case TAG_MkPair: {
    V v_x11_2446 = heff_field(v_x1_2445, 0);
    V v_st_2447 = heff_field(v_x1_2445, 1);
    V v_ru_24x1_2445_24MkPair = heff_take_reuse_n(v_x1_2445, 3ULL, 2);
    switch (heff_tag_of(v_x11_2446)) {
    case TAG_Left: {
      V v_e_2448 = heff_field(v_x11_2446, 0);
      V v_ru_24x11_2446_24Left = heff_take_reuse_n(v_x11_2446, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_2445_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_2446_24Left, TAG_Left, 1, (V[]){v_e_2448}), v_st_2447});
    }
    case TAG_Right: {
      V v_x_2449 = heff_field(v_x11_2446, 0);
      V v_ru_24x11_2446_24Right = heff_take_reuse_n(v_x11_2446, 1ULL, 1);
      V v_t_2452;
      switch (heff_tag_of(v_x_2449)) {
      case TAG_At: {
        V v_s_2451 = heff_dup(heff_field(v_x_2449, 1));
        v_t_2452 = v_s_2451;
        break;
      }
      default: heff_nomatch(v_x_2449);
      }
      V v_t_2455;
      switch (heff_tag_of(v_x_2449)) {
      case TAG_At: {
        V v_s_2454 = heff_dup(heff_field(v_x_2449, 1));
        v_t_2455 = v_s_2454;
        break;
      }
      default: heff_nomatch(v_x_2449);
      }
      V v_t_2456 = heff_rec_n(3, shape_binder__span__pat, (V[]){heff_tag_n(TAG_LamName, 2, (V[]){((V)&g_heff_2esyntax_2esurface_2elamBinderL_str0), v_t_2452}), v_t_2455, heff_tag_n(TAG_Just, 1, (V[]){v_x_2449})});
      return heff_tag_at_n(v_ru_24x1_2445_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_2446_24Right, TAG_Right, 1, (V[]){v_t_2456}), v_st_2447});
    }
    default: return heff_nomatch(v_x11_2446);
    }
  }
  default: return heff_nomatch(v_x1_2445);
  }
}
V g_heff_2esyntax_2esurface_2elamBinderL_lam4(V self, V *args) {
  V v_st_2463 = args[0];
  V v_msg_2462 = heff_env(self)[0];
  V v_start_2458 = heff_env(self)[1];
  V v_end_2459 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2464 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_2462, heff_rec_n(2, shape_start__end, (V[]){v_start_2458, v_end_2459}), NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2464}), v_st_2463});
}
V g_heff_2esyntax_2esurface_2eletBodyL_24cpr_lam0(V self, V *args);

HeffT2 g_heff_2esyntax_2esurface_2eletBodyL_24cpr(V v_r_240, V v_kw_241, V v_x3_242, V v_names_243, V v_body_244, V v_z_245) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_MkPair: {
    V v_p_246 = heff_field(v_x3_242, 0);
    V v_rhs_247 = heff_field(v_x3_242, 1);
    heff_take_n(v_x3_242, 3ULL, 2);
    V v_m_248 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_body_244)}));
    return (g_heff_2esyntax_2esurface_2ewithScope_24cpr(v_names_243, heff_clo_n(g_heff_2esyntax_2esurface_2eletBodyL_24cpr_lam0, 1, 5, (V[]){v_m_248, v_p_246, v_body_244, v_kw_241, v_rhs_247}), v_z_245));
  }
  default: return ((HeffT2){{heff_nomatch(v_x3_242)}});
  }
}
V g_heff_2esyntax_2esurface_2eletBodyL_24cpr_lam0(V self, V *args) {
  V v_st_249 = args[0];
  V v_m_248 = heff_env(self)[0];
  V v_p_246 = heff_env(self)[1];
  V v_body_244 = heff_env(self)[2];
  V v_kw_241 = heff_env(self)[3];
  V v_rhs_247 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_x1_2410 = heff_tr(heff_call(v_m_248, 1, (V[]){v_st_249}));
  switch (heff_tag_of(v_x1_2410)) {
  case TAG_MkPair: {
    V v_x11_2411 = heff_field(v_x1_2410, 0);
    V v_st_2412 = heff_field(v_x1_2410, 1);
    V v_ru_24x1_2410_24MkPair = heff_take_reuse_n(v_x1_2410, 3ULL, 2);
    switch (heff_tag_of(v_x11_2411)) {
    case TAG_Left: {
      V v_e_2413 = heff_field(v_x11_2411, 0);
      V v_ru_24x11_2411_24Left = heff_take_reuse_n(v_x11_2411, 1ULL, 1);
      heff_drop(v_p_246);
      heff_drop(v_body_244);
      heff_drop_rec(v_kw_241, 9);
      heff_drop(v_rhs_247);
      return heff_tag_at_n(v_ru_24x1_2410_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_2411_24Left, TAG_Left, 1, (V[]){v_e_2413}), v_st_2412});
    }
    case TAG_Right: {
      V v_x_2414 = heff_field(v_x11_2411, 0);
      V v_ru_24x11_2411_24Right = heff_take_reuse_n(v_x11_2411, 1ULL, 1);
      V v_t_2417;
      switch (heff_tag_of(v_p_246)) {
      case TAG_At: {
        V v_s_2416 = heff_dup(heff_field(v_p_246, 1));
        v_t_2417 = v_s_2416;
        break;
      }
      default: heff_nomatch(v_p_246);
      }
      V v_t_2420;
      switch (heff_tag_of(v_x_2414)) {
      case TAG_At: {
        V v_s_2419 = heff_dup(heff_field(v_x_2414, 1));
        v_t_2420 = v_s_2419;
        break;
      }
      default: heff_nomatch(v_x_2414);
      }
      V v_t_2421 = ({ V rv_1 = heff_get_n(v_t_2420, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_2417, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
      V v_t_2422 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_246, v_x_2414}), v_t_2421});
      V v_t_2423 = (g_heff_2esyntax_2ecst_2elastE(v_body_244));
      V v_e_2424 = heff_get_n(v_t_2423, 4, 9);
      V v_t_2425 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_241, 3, 9), v_e_2424});
      V v_x_2426 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ELetIn, 2, (V[]){v_rhs_247, v_t_2422}), v_t_2425});
      return heff_tag_at_n(v_ru_24x1_2410_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_2411_24Right, TAG_Right, 1, (V[]){v_x_2426}), v_st_2412});
    }
    default: return heff_nomatch(v_x11_2411);
    }
  }
  default: return heff_nomatch(v_x1_2410);
  }
}
HEFF_LIT(g_heff_2esyntax_2esurface_2esizeSaid_str0, 28, "a segment says its size once");
HEFF_LIT(g_heff_2esyntax_2esurface_2esizeSaid_str1, 28, "a segment says its size once");
Clo g_heff_2esyntax_2esurface_2esizeSaid_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2esizeSaid_entry, 5, 0};

V g_heff_2esyntax_2esurface_2esizeSaid(V v_sp_240, V v_n_241, V v_x3_242, V v_s_243, V v_p_244) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_SizeDefault: {
    heff_drop(v_sp_240);
    V v_t_245 = ({ V rv_1 = v_n_241; V rr_ = heff_rec_reuse_nf(v_s_243, 29ULL, 5, shape_ty__size__unit__little__signed, 1011u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_245}), v_p_244});
  }
  case TAG_SizeNumber: {
    V v_ru_24x3_242_24SizeNumber = heff_take_reuse_n(v_x3_242, 0ULL, 1);
    heff_drop(v_n_241);
    heff_drop_rec(v_s_243, 5);
    V v_t_247 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2esizeSaid_str0), v_sp_240, NTAG(TAG_Nothing)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x3_242_24SizeNumber, TAG_Left, 1, (V[]){v_t_247}), v_p_244});
  }
  case TAG_SizeName: {
    heff_take_n(v_x3_242, 0ULL, 3);
    heff_drop(v_n_241);
    heff_drop_rec(v_s_243, 5);
    V v_t_2411 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2esizeSaid_str1), v_sp_240, NTAG(TAG_Nothing)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2411}), v_p_244});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2esyntax_2esurface_2esizeSaid_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2esizeSaid(a[0], a[1], a[2], a[3], a[4]);
}
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str0, 7, "integer");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str1, 28, "a segment says its type once");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str2, 6, "binary");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str3, 5, "bytes");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str4, 28, "a segment says its type once");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str5, 4, "bits");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str6, 9, "bitstring");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str7, 28, "a segment says its type once");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str8, 5, "float");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str9, 28, "a segment says its type once");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str10, 4, "utf8");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str11, 28, "a segment says its type once");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str12, 5, "utf16");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str13, 28, "a segment says its type once");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str14, 5, "utf32");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str15, 28, "a segment says its type once");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str16, 3, "big");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str17, 34, "a segment says its endianness once");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str18, 6, "little");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str19, 34, "a segment says its endianness once");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str20, 6, "signed");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str21, 28, "a segment says its sign once");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str22, 8, "unsigned");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str23, 28, "a segment says its sign once");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str24, 227, "a segment's spec is its type (`integer`, `binary`, `bits`, `float`, `utf8`, `utf16`, `utf32`), size (`16`, `size(n)`), unit (`unit(8)`), endianness (`big`, `little`) and sign (`signed`, `unsigned`), between `-`s: `x::16-little`");
Clo g_heff_2esyntax_2esurface_2especWord_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2especWord_entry, 3, 0};

V g_heff_2esyntax_2esurface_2especWord(V v_t_240, V v_s_241, V v_p_242) {
top: ;
  V v_text_243 = heff_take_field(v_t_240, 1);
  V v_start_244 = heff_take_field(v_t_240, 3);
  V v_end_245 = heff_get_n(v_t_240, 4, 9);
  if (heff_strEq_c_lent(v_text_243, ((V)&g_heff_2esyntax_2esurface_2especWord_str0), 2)) {
    heff_drop(v_text_243);
    V v_t_246 = heff_take_field(v_s_241, 0);
    switch (heff_tag_of(v_t_246)) {
    case TAG_Nothing: {
      heff_drop(v_start_244);
      heff_drop(v_end_245);
      V v_t_247 = heff_tag_n(TAG_Just, 1, (V[]){NTAG(TAG_SegmentInteger)});
      V v_t_248 = ({ V rv_0 = v_t_247; V rr_ = heff_rec_reuse_nf(v_s_241, 30ULL, 5, shape_ty__size__unit__little__signed, 1020u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_248}), v_p_242});
    }
    case TAG_Just: {
      V v_ru_24t_246_24Just = heff_take_reuse_n(v_t_246, 0ULL, 1);
      heff_drop_rec(v_s_241, 5);
      V v_t_2410 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2especWord_str1), heff_rec_n(2, shape_start__end, (V[]){v_start_244, v_end_245}), NTAG(TAG_Nothing)});
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24t_246_24Just, TAG_Left, 1, (V[]){v_t_2410}), v_p_242});
    }
    default: return heff_nomatch(v_t_246);
    }
  } else {
    if ((heff_strEq_c_lent(v_text_243, ((V)&g_heff_2esyntax_2esurface_2especWord_str2), 2) || heff_strEq_c_lent(v_text_243, ((V)&g_heff_2esyntax_2esurface_2especWord_str3), 2))) {
      heff_drop(v_text_243);
      V v_t_2411 = heff_take_field(v_s_241, 0);
      switch (heff_tag_of(v_t_2411)) {
      case TAG_Nothing: {
        heff_drop(v_start_244);
        heff_drop(v_end_245);
        V v_t_2412 = heff_tag_n(TAG_Just, 1, (V[]){NTAG(TAG_SegmentBinary)});
        V v_t_2413 = ({ V rv_0 = v_t_2412; V rr_ = heff_rec_reuse_nf(v_s_241, 30ULL, 5, shape_ty__size__unit__little__signed, 1020u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
        return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2413}), v_p_242});
      }
      case TAG_Just: {
        V v_ru_24t_2411_24Just = heff_take_reuse_n(v_t_2411, 0ULL, 1);
        heff_drop_rec(v_s_241, 5);
        V v_t_2415 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2especWord_str4), heff_rec_n(2, shape_start__end, (V[]){v_start_244, v_end_245}), NTAG(TAG_Nothing)});
        return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24t_2411_24Just, TAG_Left, 1, (V[]){v_t_2415}), v_p_242});
      }
      default: return heff_nomatch(v_t_2411);
      }
    } else {
      if ((heff_strEq_c_lent(v_text_243, ((V)&g_heff_2esyntax_2esurface_2especWord_str5), 2) || heff_strEq_c_lent(v_text_243, ((V)&g_heff_2esyntax_2esurface_2especWord_str6), 2))) {
        heff_drop(v_text_243);
        V v_t_2416 = heff_take_field(v_s_241, 0);
        switch (heff_tag_of(v_t_2416)) {
        case TAG_Nothing: {
          heff_drop(v_start_244);
          heff_drop(v_end_245);
          V v_t_2417 = heff_tag_n(TAG_Just, 1, (V[]){NTAG(TAG_SegmentBits)});
          V v_t_2418 = ({ V rv_0 = v_t_2417; V rr_ = heff_rec_reuse_nf(v_s_241, 30ULL, 5, shape_ty__size__unit__little__signed, 1020u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
          return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2418}), v_p_242});
        }
        case TAG_Just: {
          V v_ru_24t_2416_24Just = heff_take_reuse_n(v_t_2416, 0ULL, 1);
          heff_drop_rec(v_s_241, 5);
          V v_t_2420 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2especWord_str7), heff_rec_n(2, shape_start__end, (V[]){v_start_244, v_end_245}), NTAG(TAG_Nothing)});
          return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24t_2416_24Just, TAG_Left, 1, (V[]){v_t_2420}), v_p_242});
        }
        default: return heff_nomatch(v_t_2416);
        }
      } else {
        if (heff_strEq_c_lent(v_text_243, ((V)&g_heff_2esyntax_2esurface_2especWord_str8), 2)) {
          heff_drop(v_text_243);
          V v_t_2421 = heff_take_field(v_s_241, 0);
          switch (heff_tag_of(v_t_2421)) {
          case TAG_Nothing: {
            heff_drop(v_start_244);
            heff_drop(v_end_245);
            V v_t_2422 = heff_tag_n(TAG_Just, 1, (V[]){NTAG(TAG_SegmentFloat)});
            V v_t_2423 = ({ V rv_0 = v_t_2422; V rr_ = heff_rec_reuse_nf(v_s_241, 30ULL, 5, shape_ty__size__unit__little__signed, 1020u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
            return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2423}), v_p_242});
          }
          case TAG_Just: {
            V v_ru_24t_2421_24Just = heff_take_reuse_n(v_t_2421, 0ULL, 1);
            heff_drop_rec(v_s_241, 5);
            V v_t_2425 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2especWord_str9), heff_rec_n(2, shape_start__end, (V[]){v_start_244, v_end_245}), NTAG(TAG_Nothing)});
            return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24t_2421_24Just, TAG_Left, 1, (V[]){v_t_2425}), v_p_242});
          }
          default: return heff_nomatch(v_t_2421);
          }
        } else {
          if (heff_strEq_c_lent(v_text_243, ((V)&g_heff_2esyntax_2esurface_2especWord_str10), 2)) {
            heff_drop(v_text_243);
            V v_t_2426 = heff_take_field(v_s_241, 0);
            switch (heff_tag_of(v_t_2426)) {
            case TAG_Nothing: {
              heff_drop(v_start_244);
              heff_drop(v_end_245);
              V v_t_2427 = heff_tag_n(TAG_Just, 1, (V[]){heff_tag_n(TAG_SegmentUtf, 1, (V[]){MK_INT(8LL)})});
              V v_t_2428 = ({ V rv_0 = v_t_2427; V rr_ = heff_rec_reuse_nf(v_s_241, 30ULL, 5, shape_ty__size__unit__little__signed, 1020u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
              return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2428}), v_p_242});
            }
            case TAG_Just: {
              V v_ru_24t_2426_24Just = heff_take_reuse_n(v_t_2426, 0ULL, 1);
              heff_drop_rec(v_s_241, 5);
              V v_t_2430 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2especWord_str11), heff_rec_n(2, shape_start__end, (V[]){v_start_244, v_end_245}), NTAG(TAG_Nothing)});
              return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24t_2426_24Just, TAG_Left, 1, (V[]){v_t_2430}), v_p_242});
            }
            default: return heff_nomatch(v_t_2426);
            }
          } else {
            if (heff_strEq_c_lent(v_text_243, ((V)&g_heff_2esyntax_2esurface_2especWord_str12), 2)) {
              heff_drop(v_text_243);
              V v_t_2431 = heff_take_field(v_s_241, 0);
              switch (heff_tag_of(v_t_2431)) {
              case TAG_Nothing: {
                heff_drop(v_start_244);
                heff_drop(v_end_245);
                V v_t_2432 = heff_tag_n(TAG_Just, 1, (V[]){heff_tag_n(TAG_SegmentUtf, 1, (V[]){MK_INT(16LL)})});
                V v_t_2433 = ({ V rv_0 = v_t_2432; V rr_ = heff_rec_reuse_nf(v_s_241, 30ULL, 5, shape_ty__size__unit__little__signed, 1020u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
                return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2433}), v_p_242});
              }
              case TAG_Just: {
                V v_ru_24t_2431_24Just = heff_take_reuse_n(v_t_2431, 0ULL, 1);
                heff_drop_rec(v_s_241, 5);
                V v_t_2435 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2especWord_str13), heff_rec_n(2, shape_start__end, (V[]){v_start_244, v_end_245}), NTAG(TAG_Nothing)});
                return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24t_2431_24Just, TAG_Left, 1, (V[]){v_t_2435}), v_p_242});
              }
              default: return heff_nomatch(v_t_2431);
              }
            } else {
              if (heff_strEq_c_lent(v_text_243, ((V)&g_heff_2esyntax_2esurface_2especWord_str14), 2)) {
                heff_drop(v_text_243);
                V v_t_2436 = heff_take_field(v_s_241, 0);
                switch (heff_tag_of(v_t_2436)) {
                case TAG_Nothing: {
                  heff_drop(v_start_244);
                  heff_drop(v_end_245);
                  V v_t_2437 = heff_tag_n(TAG_Just, 1, (V[]){heff_tag_n(TAG_SegmentUtf, 1, (V[]){MK_INT(32LL)})});
                  V v_t_2438 = ({ V rv_0 = v_t_2437; V rr_ = heff_rec_reuse_nf(v_s_241, 30ULL, 5, shape_ty__size__unit__little__signed, 1020u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
                  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2438}), v_p_242});
                }
                case TAG_Just: {
                  V v_ru_24t_2436_24Just = heff_take_reuse_n(v_t_2436, 0ULL, 1);
                  heff_drop_rec(v_s_241, 5);
                  V v_t_2440 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2especWord_str15), heff_rec_n(2, shape_start__end, (V[]){v_start_244, v_end_245}), NTAG(TAG_Nothing)});
                  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24t_2436_24Just, TAG_Left, 1, (V[]){v_t_2440}), v_p_242});
                }
                default: return heff_nomatch(v_t_2436);
                }
              } else {
                if (heff_strEq_c_lent(v_text_243, ((V)&g_heff_2esyntax_2esurface_2especWord_str16), 2)) {
                  heff_drop(v_text_243);
                  V v_t_2441 = heff_take_field(v_s_241, 3);
                  switch (heff_tag_of(v_t_2441)) {
                  case TAG_Nothing: {
                    heff_drop(v_start_244);
                    heff_drop(v_end_245);
                    V v_t_2442 = heff_tag_n(TAG_Just, 1, (V[]){NTAG(TAG_False)});
                    V v_t_2443 = ({ V rv_3 = v_t_2442; V rr_ = heff_rec_reuse_nf(v_s_241, 23ULL, 5, shape_ty__size__unit__little__signed, 831u, 0u); heff_rfield(rr_, 3) = rv_3; rr_; });
                    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2443}), v_p_242});
                  }
                  case TAG_Just: {
                    V v_ru_24t_2441_24Just = heff_take_reuse_n(v_t_2441, 0ULL, 1);
                    heff_drop_rec(v_s_241, 5);
                    V v_t_2445 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2especWord_str17), heff_rec_n(2, shape_start__end, (V[]){v_start_244, v_end_245}), NTAG(TAG_Nothing)});
                    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24t_2441_24Just, TAG_Left, 1, (V[]){v_t_2445}), v_p_242});
                  }
                  default: return heff_nomatch(v_t_2441);
                  }
                } else {
                  if (heff_strEq_c_lent(v_text_243, ((V)&g_heff_2esyntax_2esurface_2especWord_str18), 2)) {
                    heff_drop(v_text_243);
                    V v_t_2446 = heff_take_field(v_s_241, 3);
                    switch (heff_tag_of(v_t_2446)) {
                    case TAG_Nothing: {
                      heff_drop(v_start_244);
                      heff_drop(v_end_245);
                      V v_t_2447 = heff_tag_n(TAG_Just, 1, (V[]){NTAG(TAG_True)});
                      V v_t_2448 = ({ V rv_3 = v_t_2447; V rr_ = heff_rec_reuse_nf(v_s_241, 23ULL, 5, shape_ty__size__unit__little__signed, 831u, 0u); heff_rfield(rr_, 3) = rv_3; rr_; });
                      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2448}), v_p_242});
                    }
                    case TAG_Just: {
                      V v_ru_24t_2446_24Just = heff_take_reuse_n(v_t_2446, 0ULL, 1);
                      heff_drop_rec(v_s_241, 5);
                      V v_t_2450 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2especWord_str19), heff_rec_n(2, shape_start__end, (V[]){v_start_244, v_end_245}), NTAG(TAG_Nothing)});
                      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24t_2446_24Just, TAG_Left, 1, (V[]){v_t_2450}), v_p_242});
                    }
                    default: return heff_nomatch(v_t_2446);
                    }
                  } else {
                    if (heff_strEq_c_lent(v_text_243, ((V)&g_heff_2esyntax_2esurface_2especWord_str20), 2)) {
                      heff_drop(v_text_243);
                      V v_t_2451 = heff_take_field(v_s_241, 4);
                      switch (heff_tag_of(v_t_2451)) {
                      case TAG_Nothing: {
                        heff_drop(v_start_244);
                        heff_drop(v_end_245);
                        V v_t_2452 = heff_tag_n(TAG_Just, 1, (V[]){NTAG(TAG_True)});
                        V v_t_2453 = ({ V rv_4 = v_t_2452; V rr_ = heff_rec_reuse_nf(v_s_241, 15ULL, 5, shape_ty__size__unit__little__signed, 255u, 0u); heff_rfield(rr_, 4) = rv_4; rr_; });
                        return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2453}), v_p_242});
                      }
                      case TAG_Just: {
                        V v_ru_24t_2451_24Just = heff_take_reuse_n(v_t_2451, 0ULL, 1);
                        heff_drop_rec(v_s_241, 5);
                        V v_t_2455 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2especWord_str21), heff_rec_n(2, shape_start__end, (V[]){v_start_244, v_end_245}), NTAG(TAG_Nothing)});
                        return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24t_2451_24Just, TAG_Left, 1, (V[]){v_t_2455}), v_p_242});
                      }
                      default: return heff_nomatch(v_t_2451);
                      }
                    } else {
                      if (heff_strEq_c(v_text_243, ((V)&g_heff_2esyntax_2esurface_2especWord_str22))) {
                        V v_t_2456 = heff_take_field(v_s_241, 4);
                        switch (heff_tag_of(v_t_2456)) {
                        case TAG_Nothing: {
                          heff_drop(v_start_244);
                          heff_drop(v_end_245);
                          V v_t_2457 = heff_tag_n(TAG_Just, 1, (V[]){NTAG(TAG_False)});
                          V v_t_2458 = ({ V rv_4 = v_t_2457; V rr_ = heff_rec_reuse_nf(v_s_241, 15ULL, 5, shape_ty__size__unit__little__signed, 255u, 0u); heff_rfield(rr_, 4) = rv_4; rr_; });
                          return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2458}), v_p_242});
                        }
                        case TAG_Just: {
                          V v_ru_24t_2456_24Just = heff_take_reuse_n(v_t_2456, 0ULL, 1);
                          heff_drop_rec(v_s_241, 5);
                          V v_t_2460 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2especWord_str23), heff_rec_n(2, shape_start__end, (V[]){v_start_244, v_end_245}), NTAG(TAG_Nothing)});
                          return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24t_2456_24Just, TAG_Left, 1, (V[]){v_t_2460}), v_p_242});
                        }
                        default: return heff_nomatch(v_t_2456);
                        }
                      } else {
                        heff_drop_rec(v_s_241, 5);
                        V v_t_2461 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2especWord_str24), heff_rec_n(2, shape_start__end, (V[]){v_start_244, v_end_245}), NTAG(TAG_Nothing)});
                        return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2461}), v_p_242});
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}
V g_heff_2esyntax_2esurface_2especWord_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2especWord(a[0], a[1], a[2]);
}
Clo g_heff_2esyntax_2esurface_2evarAtom_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2evarAtom_entry, 3, 0};

V g_heff_2esyntax_2esurface_2evarAtom(V v_t_240, V v_fs_241, V v_st_242) {
top: ;
  V v_t_243 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(heff_rfield(v_t_240, 1))}));
  V v_t_244 = (g_list_2eany(v_t_243, heff_rfield(v_st_242, 1)));
  HeffT2 v_t_245 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(heff_rfield(v_st_242, 8), heff_rfield(v_t_240, 1)));
  {
    V v_field_247 = v_t_245.f[1];
    int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
    V v_x_2420;
    if ((v_tag_246 == ((int64_t)0ULL))) {
      V v_k_248 = v_field_247;
      if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
        heff_drop(v_t_244);
        heff_drop(v_k_248);
        V v_e_249 = (g_heff_2esyntax_2esurface_2eatomTok(v_t_240));
        V v_t_2410 = (g_list_2emap_24s513201124x806973253(v_fs_241));
        v_x_2420 = (g_heff_2esyntax_2epresyntax_2eapp(v_e_249, v_t_2410));
      } else {
        heff_drop(v_t_244);
        V v_t_2411 = heff_intAdd(heff_dup(heff_rfield(v_t_240, 3)), heff_strLength_lent(v_k_248, 0));
        V v_t_2412 = heff_rec_n(2, shape_start__end, (V[]){heff_dup(heff_rfield(v_t_240, 3)), heff_intAdd(v_t_2411, MK_INT(2LL))});
        V v_t_2413 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_k_248}), v_t_2412});
        V v_t_2414 = heff_tag_n(TAG_EProject, 1, (V[]){heff_take_field(v_t_240, 1)});
        V v_t_2415 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_240, 3), heff_get_n(v_t_240, 4, 9)});
        V v_t_2416 = (g_list_2emap_24s513201124x806973253(v_fs_241));
        V v_t_2417 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2414, v_t_2415}), v_t_2416});
        v_x_2420 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_2413, v_t_2417));
      }
    } else {
      heff_drop(v_t_244);
      heff_drop(v_field_247);
      V v_e_2418 = (g_heff_2esyntax_2esurface_2eatomTok(v_t_240));
      V v_t_2419 = (g_list_2emap_24s513201124x806973253(v_fs_241));
      v_x_2420 = (g_heff_2esyntax_2epresyntax_2eapp(v_e_2418, v_t_2419));
    }
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2420}), v_st_242});
  }
}
V g_heff_2esyntax_2esurface_2evarAtom_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2evarAtom(a[0], a[1], a[2]);
}
V g_heff_2esyntax_2esurface_2epushS_24s1868233564x1858628873_lam0(V self, V *args);
V g_heff_2esyntax_2esurface_2epushS_24s1868233564x1858628873_lam1(V self, V *args);
Clo g_heff_2esyntax_2esurface_2epushS_24s1868233564x1858628873_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2epushS_24s1868233564x1858628873_entry, 4, 0};

V g_heff_2esyntax_2esurface_2epushS_24s1868233564x1858628873(V v_fix_240, V v_lenient_241, V v_st_242, V v_r_243) {
top: ;
  V v_t_244 = heff_dup(heff_rfield(v_st_242, 0));
  switch (heff_tag_of(v_t_244)) {
  case TAG_Nil: {
    heff_drop(v_fix_240);
    return heff_clo_n(g_heff_2esyntax_2esurface_2epushS_24s1868233564x1858628873_lam0, 1, 2, (V[]){v_r_243, v_st_242});
  }
  case TAG_Cons: {
    V v_before_249 = heff_field(v_t_244, 0);
    heff_take_n(v_t_244, 1ULL, 2);
    V v_m_2411 = (g_heff_2esyntax_2esurface_2efirstS(heff_dup(v_fix_240), v_lenient_241, v_before_249, heff_dup(heff_rfield(v_r_243, 0))));
    return heff_clo_n(g_heff_2esyntax_2esurface_2epushS_24s1868233564x1858628873_lam1, 1, 5, (V[]){v_m_2411, v_st_242, v_fix_240, heff_dup(v_lenient_241), v_r_243});
  }
  default: return heff_nomatch(v_t_244);
  }
}
V g_heff_2esyntax_2esurface_2epushS_24s1868233564x1858628873_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2esyntax_2esurface_2epushS_24s1868233564x1858628873(a[0], a1, a[2], a[3]); heff_drop(a1); return r;
}
V g_heff_2esyntax_2esurface_2epushS_24s1868233564x1858628873_lam0(V self, V *args) {
  V v_st_245 = args[0];
  V v_r_243 = heff_env(self)[0];
  V v_st_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){heff_take_field(v_r_243, 0), heff_take_field(v_st_242, 0)});
  V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){heff_get_n(v_r_243, 1, 2), heff_get_n(v_st_242, 1, 2)});
  V v_t_248 = heff_tag_n(TAG_Right, 1, (V[]){heff_rec_n(2, shape_ops__out, (V[]){v_t_246, v_t_247})});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_248, v_st_245});
}
V g_heff_2esyntax_2esurface_2epushS_24s1868233564x1858628873_lam1(V self, V *args) {
  V v_st_2412 = args[0];
  V v_m_2411 = heff_env(self)[0];
  V v_st_242 = heff_env(self)[1];
  V v_fix_240 = heff_env(self)[2];
  V v_lenient_241 = heff_env(self)[3];
  V v_r_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_x1_2413 = heff_tr(heff_call(v_m_2411, 1, (V[]){v_st_2412}));
  switch (heff_tag_of(v_x1_2413)) {
  case TAG_MkPair: {
    V v_x11_2414 = heff_field(v_x1_2413, 0);
    V v_st_2415 = heff_field(v_x1_2413, 1);
    V v_ru_24x1_2413_24MkPair = heff_take_reuse_n(v_x1_2413, 3ULL, 2);
    switch (heff_tag_of(v_x11_2414)) {
    case TAG_Left: {
      V v_e_2416 = heff_field(v_x11_2414, 0);
      V v_ru_24x11_2414_24Left = heff_take_reuse_n(v_x11_2414, 1ULL, 1);
      heff_drop_rec(v_st_242, 2);
      heff_drop(v_fix_240);
      heff_drop(v_lenient_241);
      heff_drop_rec(v_r_243, 2);
      return heff_tag_at_n(v_ru_24x1_2413_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_2414_24Left, TAG_Left, 1, (V[]){v_e_2416}), v_st_2415});
    }
    case TAG_Right: {
      V v_x_2417 = heff_field(v_x11_2414, 0);
      V v_ru_24x11_2414_24Right = heff_take_reuse_n(v_x11_2414, 1ULL, 1);
      if ((heff_dup(v_x_2417) == NTAG(TAG_True))) {
        heff_drop_cell(v_ru_24x1_2413_24MkPair, 2);
        heff_drop(v_x_2417);
        heff_drop_cell(v_ru_24x11_2414_24Right, 1);
        V v_t_2418 = heff_dup(heff_rfield(v_st_242, 0));
        V v_t_2427;
        switch (heff_tag_of(v_t_2418)) {
        case TAG_Nil: {
          v_t_2427 = v_st_242;
          break;
        }
        case TAG_Cons: {
          V v_o_2419 = heff_field(v_t_2418, 0);
          V v_os_2420 = heff_field(v_t_2418, 1);
          heff_take_n(v_t_2418, 3ULL, 2);
          V v_t_2421 = heff_dup(heff_rfield(v_st_242, 1));
          switch (heff_tag_of(v_t_2421)) {
          case TAG_Nil: {
            heff_drop(v_o_2419);
            heff_drop(v_os_2420);
            v_t_2427 = v_st_242;
            break;
          }
          case TAG_Cons: {
            V v_r_2422 = heff_field(v_t_2421, 0);
            V v_it2_2423 = heff_field(v_t_2421, 1);
            heff_take_n(v_t_2421, 3ULL, 2);
            switch (heff_tag_of(v_it2_2423)) {
            case TAG_Nil: {
              heff_drop(v_o_2419);
              heff_drop(v_os_2420);
              heff_drop(v_r_2422);
              v_t_2427 = v_st_242;
              break;
            }
            case TAG_Cons: {
              V v_l_2424 = heff_field(v_it2_2423, 0);
              V v_rest_2425 = heff_field(v_it2_2423, 1);
              heff_take_n(v_it2_2423, 3ULL, 2);
              heff_drop_rec(v_st_242, 2);
              V v_t_2426 = (g_heff_2esyntax_2esurface_2eapplyOp(v_o_2419, v_l_2424, v_r_2422));
              v_t_2427 = heff_rec_n(2, shape_ops__out, (V[]){v_os_2420, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2426, v_rest_2425})});
              break;
            }
            default: heff_nomatch(v_it2_2423);
            }
            break;
          }
          default: heff_nomatch(v_t_2421);
          }
          break;
        }
        default: heff_nomatch(v_t_2418);
        }
        V v_t_2428 = ({ V a_0 = v_fix_240; V a_1 = v_lenient_241; V a_2 = v_t_2427; V a_3 = v_r_243; V r_ = (g_heff_2esyntax_2esurface_2epushS_24s1868233564x1858628873(a_0, a_1, a_2, a_3)); heff_drop(v_lenient_241); r_; });
        V f_ = v_t_2428;
        args[0] = v_st_2415;
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      } else {
        heff_drop(v_fix_240);
        heff_drop(v_lenient_241);
        heff_drop(v_x_2417);
        V v_t_2429 = heff_tag_n(TAG_Cons, 2, (V[]){heff_take_field(v_r_243, 0), heff_take_field(v_st_242, 0)});
        V v_t_2430 = heff_tag_n(TAG_Cons, 2, (V[]){heff_get_n(v_r_243, 1, 2), heff_get_n(v_st_242, 1, 2)});
        V v_t_2431 = heff_tag_at_n(v_ru_24x11_2414_24Right, TAG_Right, 1, (V[]){heff_rec_n(2, shape_ops__out, (V[]){v_t_2429, v_t_2430})});
        return heff_tag_at_n(v_ru_24x1_2413_24MkPair, TAG_MkPair, 2, (V[]){v_t_2431, v_st_2415});
      }
    }
    default: return heff_nomatch(v_x11_2414);
    }
  }
  default: return heff_nomatch(v_x1_2413);
  }
}
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str0, 3, "con");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str1, 3, "var");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str2, 2, "`(");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str3, 51, " := ...)` names an argument, after a function: `f (");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str4, 7, " := e)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str5, 2, "b[");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str6, 1, "[");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str7, 3, "Nil");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str8, 4, "Cons");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str9, 24, "a field is `name : Type`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str10, 61, "an instance argument is bound before `->`: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str11, 3, "con");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str12, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str13, 3, "var");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str14, 3, "neg");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str15, 4, "True");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str16, 5, "False");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str17, 5, "break");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str18, 3, "err");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str19, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str20, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str21, 8, "with#arg");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str22, 8, "with#arg");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str23, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str24, 1, "`");
V g_heff_2esyntax_2esurface_2eexprL_lam0(V self, V *args);
V g_heff_2esyntax_2esurface_2eexprL_lam1(V self, V *args);
V g_heff_2esyntax_2esurface_2eexprL_lam3(V self, V *args);
V g_heff_2esyntax_2esurface_2eexprL_lam4(V self, V *args);
V g_heff_2esyntax_2esurface_2eexprL_lam2(V self, V *args);
V g_heff_2esyntax_2esurface_2eexprL_lam5(V self, V *args);
V g_heff_2esyntax_2esurface_2eexprL_lam6(V self, V *args);
V g_heff_2esyntax_2esurface_2eexprL_lam7(V self, V *args);
V g_heff_2esyntax_2esurface_2eexprL_lam9(V self, V *args);
V g_heff_2esyntax_2esurface_2eexprL_lam8(V self, V *args);
V g_heff_2esyntax_2esurface_2eexprL_lam11(V self, V *args);
V g_heff_2esyntax_2esurface_2eexprL_lam12(V self, V *args);
V g_heff_2esyntax_2esurface_2eexprL_lam10(V self, V *args);
V g_heff_2esyntax_2esurface_2eexprL_lam13(V self, V *args);
V g_heff_2esyntax_2esurface_2eexprL_lam14(V self, V *args);
V g_heff_2esyntax_2esurface_2eexprL_lam15(V self, V *args);
V g_heff_2esyntax_2esurface_2eexprL_lam16(V self, V *args);
V g_heff_2esyntax_2esurface_2eexprL_lam17(V self, V *args);
V g_heff_2esyntax_2esurface_2eexprL_lam18(V self, V *args);
V g_heff_2esyntax_2esurface_2eexprL_lam19(V self, V *args);
V g_heff_2esyntax_2esurface_2eexprL_lam20(V self, V *args);
V g_heff_2esyntax_2esurface_2eexprL_lam21(V self, V *args);
V g_heff_2esyntax_2esurface_2eexprL_lam22(V self, V *args); static Clo g_heff_2esyntax_2esurface_2eexprL_lam22_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eexprL_lam22, 1, 0};
V g_heff_2esyntax_2esurface_2eexprL_lam23(V self, V *args);
V g_heff_2esyntax_2esurface_2eexprL_lam24(V self, V *args);
V g_heff_2esyntax_2esurface_2eexprL_lam25(V self, V *args);
V g_heff_2esyntax_2esurface_2eexprL_lam26(V self, V *args);
V g_heff_2esyntax_2esurface_2eexprL_lam27(V self, V *args);
V g_heff_2esyntax_2esurface_2eexprL_lam28(V self, V *args);
V g_heff_2esyntax_2esurface_2eexprL_lam29(V self, V *args);
Clo g_heff_2esyntax_2esurface_2eexprL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eexprL_entry, 3, 0};

V g_heff_2esyntax_2esurface_2eexprL(V v_r_240, V v_e0_241, V v_z_242) {
top: ;
  switch (heff_tag_of(v_e0_241)) {
  case TAG_Atom: {
    V v_t_243 = heff_field(v_e0_241, 0);
    V v_ru_24e0_241_24Atom = heff_take_reuse_n(v_e0_241, 1ULL, 1);
    heff_drop_rec(v_r_240, 3);
    if (heff_strEq_c(heff_dup(heff_rfield(v_t_243, 0)), ((V)&g_heff_2esyntax_2esurface_2eexprL_str0))) {
      heff_drop_cell(v_ru_24e0_241_24Atom, 1);
      HEFF_LAST return g_heff_2esyntax_2esurface_2econAtom(v_t_243, NTAG(TAG_Nil), v_z_242);
    } else {
      if (heff_strEq_c(heff_dup(heff_rfield(v_t_243, 0)), ((V)&g_heff_2esyntax_2esurface_2eexprL_str1))) {
        return (g_heff_2esyntax_2esurface_2evarAtom_24tok1(v_ru_24e0_241_24Atom, v_t_243, NTAG(TAG_Nil), v_z_242));
      } else {
        V v_x_244 = (g_heff_2esyntax_2esurface_2eatomTok(v_t_243));
        return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24e0_241_24Atom, TAG_Right, 1, (V[]){v_x_244}), v_z_242});
      }
    }
  }
  case TAG_EParen: {
    V v_o_245 = heff_field(v_e0_241, 0);
    V v_e_246 = heff_field(v_e0_241, 1);
    V v_c_247 = heff_field(v_e0_241, 2);
    heff_take_n(v_e0_241, 7ULL, 3);
    return ({ V a_0 = v_r_240; V a_1 = v_o_245; V a_2 = v_e_246; V a_3 = v_c_247; V a_4 = v_z_242; V r_ = (g_heff_2esyntax_2esurface_2eparenL(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_o_245); r_; });
  }
  case TAG_Named: {
    V v_o_248 = heff_field(v_e0_241, 0);
    V v_x_249 = heff_field(v_e0_241, 1);
    V v_e_2411 = heff_field(v_e0_241, 3);
    V v_c_2412 = heff_field(v_e0_241, 4);
    heff_take_n(v_e0_241, 27ULL, 5);
    V v_m_2413 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_2411}));
    V v_x1_2414 = heff_tr(heff_call(v_m_2413, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x1_2414)) {
    case TAG_MkPair: {
      V v_x11_2415 = heff_field(v_x1_2414, 0);
      V v_st_2416 = heff_field(v_x1_2414, 1);
      V v_ru_24x1_2414_24MkPair = heff_take_reuse_n(v_x1_2414, 3ULL, 2);
      switch (heff_tag_of(v_x11_2415)) {
      case TAG_Left: {
        V v_e_2417 = heff_field(v_x11_2415, 0);
        V v_ru_24x11_2415_24Left = heff_take_reuse_n(v_x11_2415, 1ULL, 1);
        heff_drop_rec(v_o_248, 9);
        heff_drop_rec(v_x_249, 9);
        heff_drop_rec(v_c_2412, 9);
        return heff_tag_at_n(v_ru_24x1_2414_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_2415_24Left, TAG_Left, 1, (V[]){v_e_2417}), v_st_2416});
      }
      case TAG_Right: {
        V v_ru_24x11_2415_24Right = heff_take_reuse_n(v_x11_2415, 0ULL, 1);
        V v_t_2419 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eexprL_str2), heff_dup(heff_rfield(v_x_249, 1)));
        V v_t_2420 = heff_strAppend(heff_strAppend(v_t_2419, ((V)&g_heff_2esyntax_2esurface_2eexprL_str3)), heff_get_n(v_x_249, 1, 9));
        V v_t_2421 = heff_tag_n(TAG_EInvalid, 1, (V[]){heff_strAppend(v_t_2420, ((V)&g_heff_2esyntax_2esurface_2eexprL_str4))});
        V v_t_2422 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_o_248, 3, 9), heff_get_n(v_c_2412, 4, 9)});
        V v_t_2423 = heff_tag_at_n(v_ru_24x11_2415_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2421, v_t_2422})});
        return heff_tag_at_n(v_ru_24x1_2414_24MkPair, TAG_MkPair, 2, (V[]){v_t_2423, v_st_2416});
      }
      default: return heff_nomatch(v_x11_2415);
      }
    }
    default: return heff_nomatch(v_x1_2414);
    }
  }
  case TAG_Tup: {
    V v_o_2424 = heff_field(v_e0_241, 0);
    V v_es_2425 = heff_field(v_e0_241, 1);
    V v_c_2427 = heff_field(v_e0_241, 3);
    heff_take_n(v_e0_241, 11ULL, 4);
    V v_text_2428 = heff_take_field(v_o_2424, 1);
    V v_start_2429 = heff_get_n(v_o_2424, 3, 9);
    if (heff_strEq_c_lent(v_text_2428, ((V)&g_heff_2esyntax_2esurface_2eexprL_str5), 2)) {
      heff_drop(v_text_2428);
      V v_m_2431 = (g_prelude_2etraverse_24s499544530x2060473942(heff_clo_n(g_heff_2esyntax_2esurface_2eexprL_lam0, 1, 1, (V[]){v_r_240}), v_es_2425));
      V v_x1_2432 = heff_tr(heff_call(v_m_2431, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_2432)) {
      case TAG_MkPair: {
        V v_x11_2433 = heff_field(v_x1_2432, 0);
        V v_st_2434 = heff_field(v_x1_2432, 1);
        V v_ru_24x1_2432_24MkPair = heff_take_reuse_n(v_x1_2432, 3ULL, 2);
        switch (heff_tag_of(v_x11_2433)) {
        case TAG_Left: {
          V v_e_2435 = heff_field(v_x11_2433, 0);
          V v_ru_24x11_2433_24Left = heff_take_reuse_n(v_x11_2433, 1ULL, 1);
          heff_drop_rec(v_c_2427, 9);
          heff_drop(v_start_2429);
          return heff_tag_at_n(v_ru_24x1_2432_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_2433_24Left, TAG_Left, 1, (V[]){v_e_2435}), v_st_2434});
        }
        case TAG_Right: {
          V v_x_2436 = heff_field(v_x11_2433, 0);
          V v_ru_24x11_2433_24Right = heff_take_reuse_n(v_x11_2433, 1ULL, 1);
          V v_t_2437 = heff_rec_n(2, shape_start__end, (V[]){v_start_2429, heff_get_n(v_c_2427, 4, 9)});
          V v_t_2438 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EBinary, 1, (V[]){v_x_2436}), v_t_2437});
          return heff_tag_at_n(v_ru_24x1_2432_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_2433_24Right, TAG_Right, 1, (V[]){v_t_2438}), v_st_2434});
        }
        default: return heff_nomatch(v_x11_2433);
        }
      }
      default: return heff_nomatch(v_x1_2432);
      }
    } else {
      if (heff_strEq_c(v_text_2428, ((V)&g_heff_2esyntax_2esurface_2eexprL_str6))) {
        V v_m_2439 = (g_prelude_2etraverse_24s499544530x2060473942(heff_get_n(v_r_240, 0, 3), v_es_2425));
        V v_x1_2440 = heff_tr(heff_call(v_m_2439, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_2440)) {
        case TAG_MkPair: {
          V v_x11_2441 = heff_field(v_x1_2440, 0);
          V v_st_2442 = heff_field(v_x1_2440, 1);
          V v_ru_24x1_2440_24MkPair = heff_take_reuse_n(v_x1_2440, 3ULL, 2);
          switch (heff_tag_of(v_x11_2441)) {
          case TAG_Left: {
            V v_e_2443 = heff_field(v_x11_2441, 0);
            V v_ru_24x11_2441_24Left = heff_take_reuse_n(v_x11_2441, 1ULL, 1);
            heff_drop_rec(v_c_2427, 9);
            heff_drop(v_start_2429);
            return heff_tag_at_n(v_ru_24x1_2440_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_2441_24Left, TAG_Left, 1, (V[]){v_e_2443}), v_st_2442});
          }
          case TAG_Right: {
            V v_x_2444 = heff_field(v_x11_2441, 0);
            V v_ru_24x11_2441_24Right = heff_take_reuse_n(v_x11_2441, 1ULL, 1);
            V v_sp_2445 = heff_rec_n(2, shape_start__end, (V[]){v_start_2429, heff_get_n(v_c_2427, 4, 9)});
            V v_t_2446 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ETag, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2eexprL_str7)}), heff_dup(v_sp_2445)});
            V v_x_2451 = ({ V a_0 = heff_clo_n(g_heff_2esyntax_2esurface_2eexprL_lam1, 2, 1, (V[]){v_sp_2445}); V a_1 = v_t_2446; V a_2 = v_x_2444; V r_ = heff_tr(g_heff_2esyntax_2esurface_2efoldr(a_0, a_1, a_2)); heff_drop(v_x_2444); r_; });
            return heff_tag_at_n(v_ru_24x1_2440_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_2441_24Right, TAG_Right, 1, (V[]){v_x_2451}), v_st_2442});
          }
          default: return heff_nomatch(v_x11_2441);
          }
        }
        default: return heff_nomatch(v_x1_2440);
        }
      } else {
        V v_m_2452 = (g_prelude_2etraverse_24s499544530x2060473942(heff_get_n(v_r_240, 0, 3), v_es_2425));
        V v_x1_2453 = heff_tr(heff_call(v_m_2452, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_2453)) {
        case TAG_MkPair: {
          V v_x11_2454 = heff_field(v_x1_2453, 0);
          V v_st_2455 = heff_field(v_x1_2453, 1);
          V v_ru_24x1_2453_24MkPair = heff_take_reuse_n(v_x1_2453, 3ULL, 2);
          switch (heff_tag_of(v_x11_2454)) {
          case TAG_Left: {
            V v_e_2456 = heff_field(v_x11_2454, 0);
            V v_ru_24x11_2454_24Left = heff_take_reuse_n(v_x11_2454, 1ULL, 1);
            heff_drop_rec(v_c_2427, 9);
            heff_drop(v_start_2429);
            return heff_tag_at_n(v_ru_24x1_2453_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_2454_24Left, TAG_Left, 1, (V[]){v_e_2456}), v_st_2455});
          }
          case TAG_Right: {
            V v_x_2457 = heff_field(v_x11_2454, 0);
            V v_ru_24x11_2454_24Right = heff_take_reuse_n(v_x11_2454, 1ULL, 1);
            V v_t_2458 = heff_rec_n(2, shape_start__end, (V[]){v_start_2429, heff_get_n(v_c_2427, 4, 9)});
            V v_t_2459 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ETuple, 1, (V[]){v_x_2457}), v_t_2458});
            return heff_tag_at_n(v_ru_24x1_2453_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_2454_24Right, TAG_Right, 1, (V[]){v_t_2459}), v_st_2455});
          }
          default: return heff_nomatch(v_x11_2454);
          }
        }
        default: return heff_nomatch(v_x1_2453);
        }
      }
    }
  }
  case TAG_Braces: {
    V v_o_2460 = heff_field(v_e0_241, 0);
    V v_fs_2461 = heff_field(v_e0_241, 1);
    V v_c_2463 = heff_field(v_e0_241, 3);
    heff_take_n(v_e0_241, 11ULL, 4);
    return (g_heff_2esyntax_2esurface_2ebracesL(v_r_240, v_o_2460, v_fs_2461, v_c_2463, v_z_242));
  }
  case TAG_Update: {
    V v_o_2464 = heff_field(v_e0_241, 0);
    V v_rec_2465 = heff_field(v_e0_241, 1);
    V v_fs_2467 = heff_field(v_e0_241, 3);
    V v_c_2469 = heff_field(v_e0_241, 5);
    heff_take_n(v_e0_241, 43ULL, 6);
    V v_m_2470 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_rec_2465}));
    V v_x1_2471 = heff_tr(heff_call(v_m_2470, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x1_2471)) {
    case TAG_MkPair: {
      V v_x11_2472 = heff_field(v_x1_2471, 0);
      V v_st_2473 = heff_field(v_x1_2471, 1);
      V v_ru_24x1_2471_24MkPair = heff_take_reuse_n(v_x1_2471, 3ULL, 2);
      switch (heff_tag_of(v_x11_2472)) {
      case TAG_Left: {
        V v_e_2474 = heff_field(v_x11_2472, 0);
        V v_ru_24x11_2472_24Left = heff_take_reuse_n(v_x11_2472, 1ULL, 1);
        heff_drop_rec(v_r_240, 3);
        heff_drop_rec(v_o_2464, 9);
        heff_drop(v_fs_2467);
        heff_drop_rec(v_c_2469, 9);
        return heff_tag_at_n(v_ru_24x1_2471_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_2472_24Left, TAG_Left, 1, (V[]){v_e_2474}), v_st_2473});
      }
      case TAG_Right: {
        V v_x_2475 = heff_field(v_x11_2472, 0);
        V v_ru_24x11_2472_24Right = heff_take_reuse_n(v_x11_2472, 1ULL, 1);
        V v_m_24108 = (g_prelude_2etraverse_24s499544530x2060473942(heff_clo_n(g_heff_2esyntax_2esurface_2eexprL_lam2, 1, 1, (V[]){v_r_240}), v_fs_2467));
        V v_x1_24109 = heff_tr(heff_call(v_m_24108, 1, (V[]){v_st_2473}));
        switch (heff_tag_of(v_x1_24109)) {
        case TAG_MkPair: {
          V v_x11_24110 = heff_field(v_x1_24109, 0);
          V v_st_24111 = heff_field(v_x1_24109, 1);
          V v_ru_24x1_24109_24MkPair = heff_take_reuse_n(v_x1_24109, 3ULL, 2);
          switch (heff_tag_of(v_x11_24110)) {
          case TAG_Left: {
            V v_e_24112 = heff_field(v_x11_24110, 0);
            V v_ru_24x11_24110_24Left = heff_take_reuse_n(v_x11_24110, 1ULL, 1);
            heff_drop_rec(v_o_2464, 9);
            heff_drop_rec(v_c_2469, 9);
            heff_drop(v_x_2475);
            heff_drop_cell(v_ru_24x11_2472_24Right, 1);
            heff_drop_cell(v_ru_24x1_24109_24MkPair, 2);
            return heff_tag_at_n(v_ru_24x1_2471_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_24110_24Left, TAG_Left, 1, (V[]){v_e_24112}), v_st_24111});
          }
          case TAG_Right: {
            V v_x_24113 = heff_field(v_x11_24110, 0);
            heff_take_n(v_x11_24110, 1ULL, 1);
            V v_t_24114 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_o_2464, 3, 9), heff_get_n(v_c_2469, 4, 9)});
            V v_t_24115 = heff_tag_at_n(v_ru_24x1_24109_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_EUpdate, 2, (V[]){v_x_2475, v_x_24113}), v_t_24114});
            return heff_tag_at_n(v_ru_24x1_2471_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_2472_24Right, TAG_Right, 1, (V[]){v_t_24115}), v_st_24111});
          }
          default: return heff_nomatch(v_x11_24110);
          }
        }
        default: return heff_nomatch(v_x1_24109);
        }
      }
      default: return heff_nomatch(v_x11_2472);
      }
    }
    default: return heff_nomatch(v_x1_2471);
    }
  }
  case TAG_InstB: {
    V v_o_24116 = heff_field(v_e0_241, 0);
    V v_d_24118 = heff_field(v_e0_241, 2);
    V v_c_24120 = heff_field(v_e0_241, 4);
    heff_take_n(v_e0_241, 21ULL, 5);
    V v_m_24121 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_d_24118}));
    HEFF_LAST return g_heff_2esyntax_2esurface_2ebind(heff_clo_n(g_heff_2esyntax_2esurface_2eexprL_lam5, 1, 1, (V[]){v_m_24121}), heff_clo_n(g_heff_2esyntax_2esurface_2eexprL_lam6, 2, 2, (V[]){v_o_24116, v_c_24120}), v_z_242);
  }
  case TAG_Sum: {
    V v_kw_24134 = heff_field(v_e0_241, 0);
    V v_alts_24136 = heff_field(v_e0_241, 2);
    V v_c_24138 = heff_field(v_e0_241, 4);
    heff_take_n(v_e0_241, 21ULL, 5);
    V v_m_24140 = (g_prelude_2etraverse_24s499544530x2060473942(heff_clo_n(g_heff_2esyntax_2esurface_2eexprL_lam7, 1, 1, (V[]){v_r_240}), v_alts_24136));
    V v_x1_24141 = heff_tr(heff_call(v_m_24140, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x1_24141)) {
    case TAG_MkPair: {
      V v_x11_24142 = heff_field(v_x1_24141, 0);
      V v_st_24143 = heff_field(v_x1_24141, 1);
      V v_ru_24x1_24141_24MkPair = heff_take_reuse_n(v_x1_24141, 3ULL, 2);
      switch (heff_tag_of(v_x11_24142)) {
      case TAG_Left: {
        V v_e_24144 = heff_field(v_x11_24142, 0);
        V v_ru_24x11_24142_24Left = heff_take_reuse_n(v_x11_24142, 1ULL, 1);
        heff_drop_rec(v_kw_24134, 9);
        heff_drop_rec(v_c_24138, 9);
        return heff_tag_at_n(v_ru_24x1_24141_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_24142_24Left, TAG_Left, 1, (V[]){v_e_24144}), v_st_24143});
      }
      case TAG_Right: {
        V v_x_24145 = heff_field(v_x11_24142, 0);
        V v_ru_24x11_24142_24Right = heff_take_reuse_n(v_x11_24142, 1ULL, 1);
        V v_t_24146 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_24134, 3, 9), heff_get_n(v_c_24138, 4, 9)});
        V v_t_24147 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ESum, 1, (V[]){v_x_24145}), v_t_24146});
        return heff_tag_at_n(v_ru_24x1_24141_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_24142_24Right, TAG_Right, 1, (V[]){v_t_24147}), v_st_24143});
      }
      default: return heff_nomatch(v_x11_24142);
      }
    }
    default: return heff_nomatch(v_x1_24141);
    }
  }
  case TAG_ECon: {
    V v_c_24148 = heff_field(v_e0_241, 0);
    V v_args_24149 = heff_field(v_e0_241, 1);
    heff_take_n(v_e0_241, 3ULL, 2);
    V v_t_24150 = (g_heff_2esyntax_2esurface_2econL(v_r_240, v_c_24148, v_args_24149));
    return heff_tail(v_t_24150, 1, (V[]){v_z_242});
  }
  case TAG_EField: {
    V v_e_24151 = heff_field(v_e0_241, 0);
    V v_f_24152 = heff_field(v_e0_241, 1);
    V v_ru_24e0_241_24EField = heff_take_reuse_n(v_e0_241, 3ULL, 2);
    HeffT2 v_t_24153 = (g_heff_2esyntax_2esurface_2efieldsOf_24cpr(heff_tag_at_n(v_ru_24e0_241_24EField, TAG_EField, 2, (V[]){v_e_24151, v_f_24152}), NTAG(TAG_Nil)));
    {
      V v_field_24154 = v_t_24153.f[0];
      V v_field_24155 = v_t_24153.f[1];
      V v_it1_24156 = v_field_24154;
      V v_fs_24157 = v_field_24155;
      switch (heff_tag_of(v_it1_24156)) {
      case TAG_Atom: {
        V v_t_24158 = heff_field(v_it1_24156, 0);
        V v_ru_24it1_24156_24Atom = heff_take_reuse_n(v_it1_24156, 1ULL, 1);
        heff_drop_rec(v_r_240, 3);
        if (heff_strEq_c(heff_dup(heff_rfield(v_t_24158, 0)), ((V)&g_heff_2esyntax_2esurface_2eexprL_str11))) {
          heff_drop_cell(v_ru_24it1_24156_24Atom, 1);
          HEFF_LAST return g_heff_2esyntax_2esurface_2econAtom(v_t_24158, v_fs_24157, v_z_242);
        } else {
          if (heff_strEq_c(heff_dup(heff_rfield(v_t_24158, 0)), ((V)&g_heff_2esyntax_2esurface_2eexprL_str12))) {
            return (g_heff_2esyntax_2esurface_2ekwAtom_24tok1(v_ru_24it1_24156_24Atom, v_t_24158, v_fs_24157, v_z_242));
          } else {
            if (heff_strEq_c(heff_dup(heff_rfield(v_t_24158, 0)), ((V)&g_heff_2esyntax_2esurface_2eexprL_str13))) {
              return (g_heff_2esyntax_2esurface_2evarAtom_24tok1(v_ru_24it1_24156_24Atom, v_t_24158, v_fs_24157, v_z_242));
            } else {
              V v_e_24159 = (g_heff_2esyntax_2esurface_2eatomTok(v_t_24158));
              V v_t_24160 = (g_list_2emap_24s513201124x806973253(v_fs_24157));
              V v_x_24161 = (g_heff_2esyntax_2epresyntax_2eapp(v_e_24159, v_t_24160));
              return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24it1_24156_24Atom, TAG_Right, 1, (V[]){v_x_24161}), v_z_242});
            }
          }
        }
      }
      default: {
        V v_m_24162 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24156}));
        V v_x1_24163 = heff_tr(heff_call(v_m_24162, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24163)) {
        case TAG_MkPair: {
          V v_x11_24164 = heff_field(v_x1_24163, 0);
          V v_st_24165 = heff_field(v_x1_24163, 1);
          V v_ru_24x1_24163_24MkPair = heff_take_reuse_n(v_x1_24163, 3ULL, 2);
          switch (heff_tag_of(v_x11_24164)) {
          case TAG_Left: {
            V v_e_24166 = heff_field(v_x11_24164, 0);
            V v_ru_24x11_24164_24Left = heff_take_reuse_n(v_x11_24164, 1ULL, 1);
            heff_drop(v_fs_24157);
            return heff_tag_at_n(v_ru_24x1_24163_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_24164_24Left, TAG_Left, 1, (V[]){v_e_24166}), v_st_24165});
          }
          case TAG_Right: {
            V v_x_24167 = heff_field(v_x11_24164, 0);
            V v_ru_24x11_24164_24Right = heff_take_reuse_n(v_x11_24164, 1ULL, 1);
            V v_t_24168 = (g_list_2emap_24s513201124x806973253(v_fs_24157));
            V v_x_24169 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24167, v_t_24168));
            return heff_tag_at_n(v_ru_24x1_24163_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_24164_24Right, TAG_Right, 1, (V[]){v_x_24169}), v_st_24165});
          }
          default: return heff_nomatch(v_x11_24164);
          }
        }
        default: return heff_nomatch(v_x1_24163);
        }
      }
      }
    }
  }
  case TAG_ENeg: {
    V v_m_24170 = heff_field(v_e0_241, 0);
    V v_e_24171 = heff_field(v_e0_241, 1);
    V v_ru_24e0_241_24ENeg = heff_take_reuse_n(v_e0_241, 3ULL, 2);
    V v_start_24172 = heff_take_field(v_m_24170, 3);
    V v_end_24173 = heff_get_n(v_m_24170, 4, 9);
    V v_m_24174 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_24171}));
    V v_x1_24175 = heff_tr(heff_call(v_m_24174, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x1_24175)) {
    case TAG_MkPair: {
      V v_x11_24176 = heff_field(v_x1_24175, 0);
      V v_st_24177 = heff_field(v_x1_24175, 1);
      V v_ru_24x1_24175_24MkPair = heff_take_reuse_n(v_x1_24175, 3ULL, 2);
      switch (heff_tag_of(v_x11_24176)) {
      case TAG_Left: {
        V v_e_24178 = heff_field(v_x11_24176, 0);
        V v_ru_24x11_24176_24Left = heff_take_reuse_n(v_x11_24176, 1ULL, 1);
        heff_drop(v_start_24172);
        heff_drop(v_end_24173);
        heff_drop_cell(v_ru_24x1_24175_24MkPair, 2);
        return heff_tag_at_n(v_ru_24e0_241_24ENeg, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_24176_24Left, TAG_Left, 1, (V[]){v_e_24178}), v_st_24177});
      }
      case TAG_Right: {
        V v_x_24179 = heff_field(v_x11_24176, 0);
        V v_ru_24x11_24176_24Right = heff_take_reuse_n(v_x11_24176, 1ULL, 1);
        V v_t_24180 = heff_tag_at_n(v_ru_24e0_241_24ENeg, TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2eexprL_str14)}), heff_rec_n(2, shape_start__end, (V[]){v_start_24172, v_end_24173})});
        V v_t_24181 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_24179, NTAG(TAG_Nil)});
        V v_x_24182 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_24180, v_t_24181));
        return heff_tag_at_n(v_ru_24x1_24175_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_24176_24Right, TAG_Right, 1, (V[]){v_x_24182}), v_st_24177});
      }
      default: return heff_nomatch(v_x11_24176);
      }
    }
    default: return heff_nomatch(v_x1_24175);
    }
  }
  case TAG_ETilde: {
    V v_m_24183 = heff_field(v_e0_241, 0);
    V v_e_24184 = heff_field(v_e0_241, 1);
    V v_ru_24e0_241_24ETilde = heff_take_reuse_n(v_e0_241, 3ULL, 2);
    V v_m_24185 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_e_24184)}));
    V v_x1_24186 = heff_tr(heff_call(v_m_24185, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x1_24186)) {
    case TAG_MkPair: {
      V v_x11_24187 = heff_field(v_x1_24186, 0);
      V v_st_24188 = heff_field(v_x1_24186, 1);
      V v_ru_24x1_24186_24MkPair = heff_take_reuse_n(v_x1_24186, 3ULL, 2);
      switch (heff_tag_of(v_x11_24187)) {
      case TAG_Left: {
        V v_e_24189 = heff_field(v_x11_24187, 0);
        V v_ru_24x11_24187_24Left = heff_take_reuse_n(v_x11_24187, 1ULL, 1);
        heff_drop_rec(v_m_24183, 9);
        heff_drop(v_e_24184);
        heff_drop_cell(v_ru_24x1_24186_24MkPair, 2);
        return heff_tag_at_n(v_ru_24e0_241_24ETilde, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_24187_24Left, TAG_Left, 1, (V[]){v_e_24189}), v_st_24188});
      }
      case TAG_Right: {
        V v_x_24190 = heff_field(v_x11_24187, 0);
        V v_ru_24x11_24187_24Right = heff_take_reuse_n(v_x11_24187, 1ULL, 1);
        V v_t_24191 = (g_heff_2esyntax_2ecst_2elastE(v_e_24184));
        V v_e_24192 = heff_get_n(v_t_24191, 4, 9);
        V v_t_24193 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_m_24183, 3, 9), v_e_24192});
        V v_x_24194 = heff_tag_at_n(v_ru_24e0_241_24ETilde, TAG_At, 2, (V[]){heff_tag_n(TAG_ELazy, 1, (V[]){v_x_24190}), v_t_24193});
        return heff_tag_at_n(v_ru_24x1_24186_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_24187_24Right, TAG_Right, 1, (V[]){v_x_24194}), v_st_24188});
      }
      default: return heff_nomatch(v_x11_24187);
      }
    }
    default: return heff_nomatch(v_x1_24186);
    }
  }
  case TAG_App: {
    V v_h_24195 = heff_field(v_e0_241, 0);
    V v_args_24196 = heff_field(v_e0_241, 1);
    V v_ru_24e0_241_24App = heff_take_reuse_n(v_e0_241, 3ULL, 2);
    V v_m_24197 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_h_24195}));
    V v_x1_24198 = heff_tr(heff_call(v_m_24197, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x1_24198)) {
    case TAG_MkPair: {
      V v_x11_24199 = heff_field(v_x1_24198, 0);
      V v_st_24200 = heff_field(v_x1_24198, 1);
      heff_take_n(v_x1_24198, 3ULL, 2);
      switch (heff_tag_of(v_x11_24199)) {
      case TAG_Left: {
        V v_e_24201 = heff_field(v_x11_24199, 0);
        V v_ru_24x11_24199_24Left = heff_take_reuse_n(v_x11_24199, 1ULL, 1);
        heff_drop_rec(v_r_240, 3);
        heff_drop(v_args_24196);
        return heff_tag_at_n(v_ru_24e0_241_24App, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_24199_24Left, TAG_Left, 1, (V[]){v_e_24201}), v_st_24200});
      }
      case TAG_Right: {
        V v_x_24202 = heff_field(v_x11_24199, 0);
        V v_ru_24x11_24199_24Right = heff_take_reuse_n(v_x11_24199, 1ULL, 1);
        V v_m_24221 = (g_prelude_2etraverse_24s499544530x2060473942(heff_clo_n(g_heff_2esyntax_2esurface_2eexprL_lam8, 1, 1, (V[]){v_r_240}), v_args_24196));
        V v_x1_24222 = heff_tr(heff_call(v_m_24221, 1, (V[]){v_st_24200}));
        switch (heff_tag_of(v_x1_24222)) {
        case TAG_MkPair: {
          V v_x11_24223 = heff_field(v_x1_24222, 0);
          V v_st_24224 = heff_field(v_x1_24222, 1);
          heff_take_n(v_x1_24222, 3ULL, 2);
          switch (heff_tag_of(v_x11_24223)) {
          case TAG_Left: {
            V v_e_24225 = heff_field(v_x11_24223, 0);
            V v_ru_24x11_24223_24Left = heff_take_reuse_n(v_x11_24223, 1ULL, 1);
            heff_drop(v_x_24202);
            heff_drop_cell(v_ru_24x11_24199_24Right, 1);
            return heff_tag_at_n(v_ru_24e0_241_24App, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_24223_24Left, TAG_Left, 1, (V[]){v_e_24225}), v_st_24224});
          }
          case TAG_Right: {
            V v_x_24226 = heff_field(v_x11_24223, 0);
            heff_take_n(v_x11_24223, 1ULL, 1);
            V v_x_24227 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24202, v_x_24226));
            return heff_tag_at_n(v_ru_24e0_241_24App, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_24199_24Right, TAG_Right, 1, (V[]){v_x_24227}), v_st_24224});
          }
          default: return heff_nomatch(v_x11_24223);
          }
        }
        default: return heff_nomatch(v_x1_24222);
        }
      }
      default: return heff_nomatch(v_x11_24199);
      }
    }
    default: return heff_nomatch(v_x1_24198);
    }
  }
  case TAG_Op: {
    V v_a_24228 = heff_field(v_e0_241, 0);
    V v_op_24229 = heff_field(v_e0_241, 1);
    V v_b_24230 = heff_field(v_e0_241, 2);
    heff_take_n(v_e0_241, 7ULL, 3);
    return (g_heff_2esyntax_2esurface_2eopL(v_r_240, v_a_24228, v_op_24229, v_b_24230, v_z_242));
  }
  case TAG_Ops: {
    V v_a_24231 = heff_field(v_e0_241, 0);
    V v_rest_24232 = heff_field(v_e0_241, 1);
    V v_ru_24e0_241_24Ops = heff_take_reuse_n(v_e0_241, 3ULL, 2);
    V v_m_24233 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_24231}));
    V v_x1_24234 = heff_tr(heff_call(v_m_24233, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x1_24234)) {
    case TAG_MkPair: {
      V v_x11_24235 = heff_field(v_x1_24234, 0);
      V v_st_24236 = heff_field(v_x1_24234, 1);
      V v_ru_24x1_24234_24MkPair = heff_take_reuse_n(v_x1_24234, 3ULL, 2);
      switch (heff_tag_of(v_x11_24235)) {
      case TAG_Left: {
        V v_e_24237 = heff_field(v_x11_24235, 0);
        V v_ru_24x11_24235_24Left = heff_take_reuse_n(v_x11_24235, 1ULL, 1);
        heff_drop_rec(v_r_240, 3);
        heff_drop(v_rest_24232);
        heff_drop_cell(v_ru_24x1_24234_24MkPair, 2);
        return heff_tag_at_n(v_ru_24e0_241_24Ops, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_24235_24Left, TAG_Left, 1, (V[]){v_e_24237}), v_st_24236});
      }
      case TAG_Right: {
        V v_x_24238 = heff_field(v_x11_24235, 0);
        V v_ru_24x11_24235_24Right = heff_take_reuse_n(v_x11_24235, 1ULL, 1);
        V v_m_24261 = (g_prelude_2etraverse_24s499544530x2060473942(heff_clo_n(g_heff_2esyntax_2esurface_2eexprL_lam10, 1, 1, (V[]){v_r_240}), v_rest_24232));
        V v_x1_24262 = heff_tr(heff_call(v_m_24261, 1, (V[]){v_st_24236}));
        switch (heff_tag_of(v_x1_24262)) {
        case TAG_MkPair: {
          V v_x11_24263 = heff_field(v_x1_24262, 0);
          V v_st_24264 = heff_field(v_x1_24262, 1);
          heff_take_n(v_x1_24262, 3ULL, 2);
          switch (heff_tag_of(v_x11_24263)) {
          case TAG_Left: {
            V v_e_24265 = heff_field(v_x11_24263, 0);
            V v_ru_24x11_24263_24Left = heff_take_reuse_n(v_x11_24263, 1ULL, 1);
            heff_drop_cell(v_ru_24x1_24234_24MkPair, 2);
            heff_drop(v_x_24238);
            heff_drop_cell(v_ru_24x11_24235_24Right, 1);
            return heff_tag_at_n(v_ru_24e0_241_24Ops, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_24263_24Left, TAG_Left, 1, (V[]){v_e_24265}), v_st_24264});
          }
          case TAG_Right: {
            V v_x_24266 = heff_field(v_x11_24263, 0);
            V v_ru_24x11_24263_24Right = heff_take_reuse_n(v_x11_24263, 1ULL, 1);
            V v_e0_24267 = v_x_24238;
            V v_rest_24268 = v_x_24266;
            V v_st_24269 = v_st_24264;
            V v_t_24270 = heff_dup(heff_rfield(v_st_24269, 5));
            V v_t_24271 = heff_dup(heff_rfield(v_st_24269, 6));
            V v_m_24272 = (g_heff_2esyntax_2esurface_2echeckFixOf(heff_dup(v_t_24270), v_t_24271, heff_dup(v_rest_24268)));
            V v_x1_24273 = heff_tr(heff_call(v_m_24272, 1, (V[]){v_st_24269}));
            switch (heff_tag_of(v_x1_24273)) {
            case TAG_MkPair: {
              V v_x11_24274 = heff_field(v_x1_24273, 0);
              V v_st_24275 = heff_field(v_x1_24273, 1);
              heff_take_n(v_x1_24273, 3ULL, 2);
              switch (heff_tag_of(v_x11_24274)) {
              case TAG_Left: {
                V v_e_24276 = heff_field(v_x11_24274, 0);
                heff_take_n(v_x11_24274, 1ULL, 1);
                heff_drop_cell(v_ru_24x1_24234_24MkPair, 2);
                heff_drop_cell(v_ru_24x11_24235_24Right, 1);
                heff_drop(v_e0_24267);
                heff_drop(v_rest_24268);
                heff_drop(v_t_24270);
                heff_drop(v_t_24271);
                return heff_tag_at_n(v_ru_24e0_241_24Ops, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_24263_24Right, TAG_Left, 1, (V[]){v_e_24276}), v_st_24275});
              }
              case TAG_Right: {
                heff_take_n(v_x11_24274, 0ULL, 1);
                V v_t_24278 = heff_tag_at_n(v_ru_24e0_241_24Ops, TAG_Cons, 2, (V[]){heff_dup(v_e0_24267), NTAG(TAG_Nil)});
                V v_t_24279 = heff_rec_n(2, shape_ops__out, (V[]){NTAG(TAG_Nil), v_t_24278});
                V v_m_24280 = ({ V a_0 = v_t_24270; V a_1 = v_t_24271; V a_2 = v_t_24279; V a_3 = v_rest_24268; V r_ = (g_heff_2esyntax_2esurface_2epushAll_24s1143154608x134136784(a_0, a_1, a_2, a_3)); heff_drop(v_t_24271); r_; });
                V v_x1_24281 = heff_tr(heff_call(v_m_24280, 1, (V[]){v_st_24275}));
                switch (heff_tag_of(v_x1_24281)) {
                case TAG_MkPair: {
                  V v_x11_24282 = heff_field(v_x1_24281, 0);
                  V v_st_24283 = heff_field(v_x1_24281, 1);
                  heff_take_n(v_x1_24281, 3ULL, 2);
                  switch (heff_tag_of(v_x11_24282)) {
                  case TAG_Left: {
                    V v_e_24284 = heff_field(v_x11_24282, 0);
                    heff_take_n(v_x11_24282, 1ULL, 1);
                    heff_drop_cell(v_ru_24x11_24235_24Right, 1);
                    heff_drop(v_e0_24267);
                    return heff_tag_at_n(v_ru_24x1_24234_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_24263_24Right, TAG_Left, 1, (V[]){v_e_24284}), v_st_24283});
                  }
                  case TAG_Right: {
                    V v_x_24285 = heff_field(v_x11_24282, 0);
                    heff_take_n(v_x11_24282, 1ULL, 1);
                    heff_drop_cell(v_ru_24x11_24263_24Right, 1);
                    V v_st_24286 = (g_heff_2esyntax_2esurface_2ereduceAll_24s2102953891x2078576216(v_x_24285));
                    V v_t_24287 = heff_get_n(v_st_24286, 1, 2);
                    V v_t_24290;
                    switch (heff_tag_of(v_t_24287)) {
                    case TAG_Nil: {
                      v_t_24290 = v_e0_24267;
                      break;
                    }
                    case TAG_Cons: {
                      V v_x_24288 = heff_field(v_t_24287, 0);
                      heff_take_n(v_t_24287, 1ULL, 2);
                      heff_drop(v_e0_24267);
                      v_t_24290 = v_x_24288;
                      break;
                    }
                    default: heff_nomatch(v_t_24287);
                    }
                    return heff_tag_at_n(v_ru_24x1_24234_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_24235_24Right, TAG_Right, 1, (V[]){v_t_24290}), v_st_24283});
                  }
                  default: return heff_nomatch(v_x11_24282);
                  }
                }
                default: return heff_nomatch(v_x1_24281);
                }
              }
              default: return heff_nomatch(v_x11_24274);
              }
            }
            default: return heff_nomatch(v_x1_24273);
            }
          }
          default: return heff_nomatch(v_x11_24263);
          }
        }
        default: return heff_nomatch(v_x1_24262);
        }
      }
      default: return heff_nomatch(v_x11_24235);
      }
    }
    default: return heff_nomatch(v_x1_24234);
    }
  }
  case TAG_Ann: {
    V v_e_24291 = heff_field(v_e0_241, 0);
    V v_ty_24293 = heff_field(v_e0_241, 2);
    heff_take_n(v_e0_241, 5ULL, 3);
    V v_m_24294 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e_24291}));
    V v_x1_24295 = heff_tr(heff_call(v_m_24294, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x1_24295)) {
    case TAG_MkPair: {
      V v_x11_24296 = heff_field(v_x1_24295, 0);
      V v_st_24297 = heff_field(v_x1_24295, 1);
      V v_ru_24x1_24295_24MkPair = heff_take_reuse_n(v_x1_24295, 3ULL, 2);
      switch (heff_tag_of(v_x11_24296)) {
      case TAG_Left: {
        V v_e_24298 = heff_field(v_x11_24296, 0);
        V v_ru_24x11_24296_24Left = heff_take_reuse_n(v_x11_24296, 1ULL, 1);
        heff_drop_rec(v_r_240, 3);
        heff_drop(v_ty_24293);
        return heff_tag_at_n(v_ru_24x1_24295_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_24296_24Left, TAG_Left, 1, (V[]){v_e_24298}), v_st_24297});
      }
      case TAG_Right: {
        V v_x_24299 = heff_field(v_x11_24296, 0);
        V v_ru_24x11_24296_24Right = heff_take_reuse_n(v_x11_24296, 1ULL, 1);
        V v_m_24300 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_ty_24293}));
        V v_x1_24301 = heff_tr(heff_call(v_m_24300, 1, (V[]){v_st_24297}));
        switch (heff_tag_of(v_x1_24301)) {
        case TAG_MkPair: {
          V v_x11_24302 = heff_field(v_x1_24301, 0);
          V v_st_24303 = heff_field(v_x1_24301, 1);
          V v_ru_24x1_24301_24MkPair = heff_take_reuse_n(v_x1_24301, 3ULL, 2);
          switch (heff_tag_of(v_x11_24302)) {
          case TAG_Left: {
            V v_e_24304 = heff_field(v_x11_24302, 0);
            V v_ru_24x11_24302_24Left = heff_take_reuse_n(v_x11_24302, 1ULL, 1);
            heff_drop(v_x_24299);
            heff_drop_cell(v_ru_24x11_24296_24Right, 1);
            heff_drop_cell(v_ru_24x1_24301_24MkPair, 2);
            return heff_tag_at_n(v_ru_24x1_24295_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_24302_24Left, TAG_Left, 1, (V[]){v_e_24304}), v_st_24303});
          }
          case TAG_Right: {
            V v_x_24305 = heff_field(v_x11_24302, 0);
            heff_take_n(v_x11_24302, 1ULL, 1);
            V v_t_24308;
            switch (heff_tag_of(v_x_24299)) {
            case TAG_At: {
              V v_s_24307 = heff_dup(heff_field(v_x_24299, 1));
              v_t_24308 = v_s_24307;
              break;
            }
            default: heff_nomatch(v_x_24299);
            }
            V v_t_24311;
            switch (heff_tag_of(v_x_24305)) {
            case TAG_At: {
              V v_s_24310 = heff_dup(heff_field(v_x_24305, 1));
              v_t_24311 = v_s_24310;
              break;
            }
            default: heff_nomatch(v_x_24305);
            }
            V v_t_24312 = ({ V rv_1 = heff_get_n(v_t_24311, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24308, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
            V v_t_24313 = heff_tag_at_n(v_ru_24x1_24301_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_EAnn, 2, (V[]){v_x_24299, v_x_24305}), v_t_24312});
            return heff_tag_at_n(v_ru_24x1_24295_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_24296_24Right, TAG_Right, 1, (V[]){v_t_24313}), v_st_24303});
          }
          default: return heff_nomatch(v_x11_24302);
          }
        }
        default: return heff_nomatch(v_x1_24301);
        }
      }
      default: return heff_nomatch(v_x11_24296);
      }
    }
    default: return heff_nomatch(v_x1_24295);
    }
  }
  case TAG_Lam: {
    V v_binders_24315 = heff_field(v_e0_241, 1);
    V v_body_24317 = heff_field(v_e0_241, 3);
    heff_take_n(v_e0_241, 10ULL, 4);
    V v_r_24318 = v_r_240;
    V v_binders_24319 = v_binders_24315;
    V v_body_24320 = v_body_24317;
    V v_m_24322 = (g_prelude_2etraverse_24s499544530x2060473942(heff_clo_n(g_heff_2esyntax_2esurface_2eexprL_lam13, 1, 1, (V[]){heff_dup(v_r_24318)}), v_binders_24319));
    V v_x1_24323 = heff_tr(heff_call(v_m_24322, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x1_24323)) {
    case TAG_MkPair: {
      V v_x11_24324 = heff_field(v_x1_24323, 0);
      V v_st_24325 = heff_field(v_x1_24323, 1);
      V v_ru_24x1_24323_24MkPair = heff_take_reuse_n(v_x1_24323, 3ULL, 2);
      switch (heff_tag_of(v_x11_24324)) {
      case TAG_Left: {
        V v_e_24326 = heff_field(v_x11_24324, 0);
        V v_ru_24x11_24324_24Left = heff_take_reuse_n(v_x11_24324, 1ULL, 1);
        heff_drop_rec(v_r_24318, 3);
        heff_drop(v_body_24320);
        return heff_tag_at_n(v_ru_24x1_24323_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_24324_24Left, TAG_Left, 1, (V[]){v_e_24326}), v_st_24325});
      }
      case TAG_Right: {
        V v_x_24327 = heff_field(v_x11_24324, 0);
        heff_take_n(v_x11_24324, 1ULL, 1);
        V v_t_24328 = (g_heff_2esyntax_2esurface_2econcatMapS_24s1449391958x677358818(heff_dup(v_x_24327)));
        V v_m_24329 = heff_tr(heff_call(heff_get_n(v_r_24318, 0, 3), 1, (V[]){v_body_24320}));
        return (g_heff_2esyntax_2esurface_2ewithScope_24tok2(v_ru_24x1_24323_24MkPair, v_t_24328, heff_clo_n(g_heff_2esyntax_2esurface_2eexprL_lam14, 1, 2, (V[]){v_m_24329, v_x_24327}), v_st_24325));
      }
      default: return heff_nomatch(v_x11_24324);
      }
    }
    default: return heff_nomatch(v_x1_24323);
    }
  }
  case TAG_Case: {
    V v_kw_24337 = heff_dup(heff_field(v_e0_241, 0));
    V v_scrut_24338 = heff_dup(heff_field(v_e0_241, 1));
    V v_alts_24340 = heff_dup(heff_field(v_e0_241, 3));
    V v_m_24341 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_scrut_24338}));
    V v_x1_24342 = heff_tr(heff_call(v_m_24341, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x1_24342)) {
    case TAG_MkPair: {
      V v_x11_24343 = heff_field(v_x1_24342, 0);
      V v_st_24344 = heff_field(v_x1_24342, 1);
      V v_ru_24x1_24342_24MkPair = heff_take_reuse_n(v_x1_24342, 3ULL, 2);
      switch (heff_tag_of(v_x11_24343)) {
      case TAG_Left: {
        V v_e_24345 = heff_field(v_x11_24343, 0);
        V v_ru_24x11_24343_24Left = heff_take_reuse_n(v_x11_24343, 1ULL, 1);
        heff_drop_rec(v_r_240, 3);
        heff_drop_tag(v_e0_241, 4);
        heff_drop_rec(v_kw_24337, 9);
        heff_drop(v_alts_24340);
        return heff_tag_at_n(v_ru_24x1_24342_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_24343_24Left, TAG_Left, 1, (V[]){v_e_24345}), v_st_24344});
      }
      case TAG_Right: {
        V v_x_24346 = heff_field(v_x11_24343, 0);
        heff_take_n(v_x11_24343, 1ULL, 1);
        V v_t_24348 = heff_tr(heff_call(((V)&g_heff_2esyntax_2esurface_2eblock_clo), 2, (V[]){heff_clo_n(g_heff_2esyntax_2esurface_2eexprL_lam15, 1, 1, (V[]){v_r_240}), v_alts_24340}));
        return (g_heff_2esyntax_2esurface_2ebind_24tok2(v_ru_24x1_24342_24MkPair, v_t_24348, heff_clo_n(g_heff_2esyntax_2esurface_2eexprL_lam16, 2, 3, (V[]){v_e0_241, v_kw_24337, v_x_24346}), v_st_24344));
      }
      default: return heff_nomatch(v_x11_24343);
      }
    }
    default: return heff_nomatch(v_x1_24342);
    }
  }
  case TAG_If: {
    V v_kw_24367 = heff_field(v_e0_241, 0);
    V v_c_24368 = heff_field(v_e0_241, 1);
    V v_a_24370 = heff_field(v_e0_241, 3);
    V v_b_24372 = heff_field(v_e0_241, 5);
    heff_take_n(v_e0_241, 43ULL, 6);
    V v_m_24373 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_c_24368}));
    V v_x1_24374 = heff_tr(heff_call(v_m_24373, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x1_24374)) {
    case TAG_MkPair: {
      V v_x11_24375 = heff_field(v_x1_24374, 0);
      V v_st_24376 = heff_field(v_x1_24374, 1);
      V v_ru_24x1_24374_24MkPair = heff_take_reuse_n(v_x1_24374, 3ULL, 2);
      switch (heff_tag_of(v_x11_24375)) {
      case TAG_Left: {
        V v_e_24377 = heff_field(v_x11_24375, 0);
        V v_ru_24x11_24375_24Left = heff_take_reuse_n(v_x11_24375, 1ULL, 1);
        heff_drop_rec(v_r_240, 3);
        heff_drop_rec(v_kw_24367, 9);
        heff_drop(v_a_24370);
        heff_drop(v_b_24372);
        return heff_tag_at_n(v_ru_24x1_24374_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_24375_24Left, TAG_Left, 1, (V[]){v_e_24377}), v_st_24376});
      }
      case TAG_Right: {
        V v_x_24378 = heff_field(v_x11_24375, 0);
        V v_ru_24x11_24375_24Right = heff_take_reuse_n(v_x11_24375, 1ULL, 1);
        V v_m_24379 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_24370}));
        V v_x1_24380 = heff_tr(heff_call(v_m_24379, 1, (V[]){v_st_24376}));
        switch (heff_tag_of(v_x1_24380)) {
        case TAG_MkPair: {
          V v_x11_24381 = heff_field(v_x1_24380, 0);
          V v_st_24382 = heff_field(v_x1_24380, 1);
          V v_ru_24x1_24380_24MkPair = heff_take_reuse_n(v_x1_24380, 3ULL, 2);
          switch (heff_tag_of(v_x11_24381)) {
          case TAG_Left: {
            V v_e_24383 = heff_field(v_x11_24381, 0);
            V v_ru_24x11_24381_24Left = heff_take_reuse_n(v_x11_24381, 1ULL, 1);
            heff_drop_rec(v_r_240, 3);
            heff_drop_rec(v_kw_24367, 9);
            heff_drop(v_b_24372);
            heff_drop(v_x_24378);
            heff_drop_cell(v_ru_24x11_24375_24Right, 1);
            heff_drop_cell(v_ru_24x1_24380_24MkPair, 2);
            return heff_tag_at_n(v_ru_24x1_24374_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_24381_24Left, TAG_Left, 1, (V[]){v_e_24383}), v_st_24382});
          }
          case TAG_Right: {
            V v_x_24384 = heff_field(v_x11_24381, 0);
            V v_ru_24x11_24381_24Right = heff_take_reuse_n(v_x11_24381, 1ULL, 1);
            V v_m_24385 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_b_24372)}));
            V v_x1_24386 = heff_tr(heff_call(v_m_24385, 1, (V[]){v_st_24382}));
            switch (heff_tag_of(v_x1_24386)) {
            case TAG_MkPair: {
              V v_x11_24387 = heff_field(v_x1_24386, 0);
              V v_st_24388 = heff_field(v_x1_24386, 1);
              V v_ru_24x1_24386_24MkPair = heff_take_reuse_n(v_x1_24386, 3ULL, 2);
              switch (heff_tag_of(v_x11_24387)) {
              case TAG_Left: {
                V v_e_24389 = heff_field(v_x11_24387, 0);
                heff_take_n(v_x11_24387, 1ULL, 1);
                heff_drop_rec(v_kw_24367, 9);
                heff_drop(v_b_24372);
                heff_drop(v_x_24378);
                heff_drop_cell(v_ru_24x11_24375_24Right, 1);
                heff_drop_cell(v_ru_24x1_24380_24MkPair, 2);
                heff_drop(v_x_24384);
                heff_drop_cell(v_ru_24x1_24386_24MkPair, 2);
                return heff_tag_at_n(v_ru_24x1_24374_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_24381_24Right, TAG_Left, 1, (V[]){v_e_24389}), v_st_24388});
              }
              case TAG_Right: {
                V v_x_24390 = heff_field(v_x11_24387, 0);
                heff_take_n(v_x11_24387, 1ULL, 1);
                heff_drop_cell(v_ru_24x11_24381_24Right, 1);
                V v_t_24391 = (g_heff_2esyntax_2ecst_2elastE(v_b_24372));
                V v_e_24392 = heff_get_n(v_t_24391, 4, 9);
                V v_sp_24393 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_24367, 3, 9), v_e_24392});
                V v_c_24394 = v_x_24378;
                V v_a_24395 = v_x_24384;
                V v_b_24396 = v_x_24390;
                V v_t_24397 = (g_heff_2esyntax_2epresyntax_2eboolOf(v_c_24394));
                V v_t_24398 = heff_rec_n(2, shape_start__end, (V[]){heff_dup(heff_rfield(v_sp_24393, 0)), heff_dup(heff_rfield(v_sp_24393, 1))});
                V v_t_24399 = heff_tag_n(TAG_PatTag, 3, (V[]){((V)&g_heff_2esyntax_2esurface_2eexprL_str15), heff_dup(v_sp_24393), NTAG(TAG_Nil)});
                V v_t_24400 = heff_tag_at_n(v_ru_24x1_24380_24MkPair, TAG_MkAlt, 2, (V[]){heff_tag_at_n(v_ru_24x1_24386_24MkPair, TAG_At, 2, (V[]){v_t_24399, heff_dup(v_t_24398)}), heff_dup(v_a_24395)});
                V v_t_24403;
                switch (heff_tag_of(v_a_24395)) {
                case TAG_At: {
                  V v_s_24402 = heff_field(v_a_24395, 1);
                  heff_take_n(v_a_24395, 2ULL, 2);
                  v_t_24403 = v_s_24402;
                  break;
                }
                default: heff_nomatch(v_a_24395);
                }
                V v_t_24404 = ({ V rv_1 = heff_get_n(v_t_24403, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24398, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                V v_t_24405 = heff_rec_n(2, shape_start__end, (V[]){heff_dup(heff_rfield(v_sp_24393, 0)), heff_dup(heff_rfield(v_sp_24393, 1))});
                V v_t_24406 = heff_tag_n(TAG_PatTag, 3, (V[]){((V)&g_heff_2esyntax_2esurface_2eexprL_str16), heff_dup(v_sp_24393), NTAG(TAG_Nil)});
                V v_t_24407 = heff_tag_n(TAG_MkAlt, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24406, heff_dup(v_t_24405)}), heff_dup(v_b_24396)});
                V v_t_24410;
                switch (heff_tag_of(v_b_24396)) {
                case TAG_At: {
                  V v_s_24409 = heff_field(v_b_24396, 1);
                  heff_take_n(v_b_24396, 2ULL, 2);
                  v_t_24410 = v_s_24409;
                  break;
                }
                default: heff_nomatch(v_b_24396);
                }
                V v_t_24411 = ({ V rv_1 = heff_get_n(v_t_24410, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24405, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
                V v_t_24412 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24407, v_t_24411}), NTAG(TAG_Nil)});
                V v_t_24413 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24400, v_t_24404}), v_t_24412});
                V v_x_24414 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_t_24397, v_t_24413}), v_sp_24393});
                return heff_tag_at_n(v_ru_24x1_24374_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_24375_24Right, TAG_Right, 1, (V[]){v_x_24414}), v_st_24388});
              }
              default: return heff_nomatch(v_x11_24387);
              }
            }
            default: return heff_nomatch(v_x1_24386);
            }
          }
          default: return heff_nomatch(v_x11_24381);
          }
        }
        default: return heff_nomatch(v_x1_24380);
        }
      }
      default: return heff_nomatch(v_x11_24375);
      }
    }
    default: return heff_nomatch(v_x1_24374);
    }
  }
  case TAG_Do: {
    V v_kw_24415 = heff_dup(heff_field(v_e0_241, 0));
    V v_stmts_24416 = heff_dup(heff_field(v_e0_241, 1));
    V v_t_24418 = heff_tr(heff_call(((V)&g_heff_2esyntax_2esurface_2eblock_clo), 2, (V[]){heff_clo_n(g_heff_2esyntax_2esurface_2eexprL_lam17, 1, 1, (V[]){v_r_240}), v_stmts_24416}));
    HEFF_LAST return g_heff_2esyntax_2esurface_2ebind(v_t_24418, heff_clo_n(g_heff_2esyntax_2esurface_2eexprL_lam18, 2, 2, (V[]){v_e0_241, v_kw_24415}), v_z_242);
  }
  case TAG_ELet: {
    return ({ V a_0 = v_r_240; V a_1 = v_e0_241; V a_2 = v_z_242; V r_ = (g_heff_2esyntax_2esurface_2eletL(a_0, a_1, a_2)); heff_drop_tag(v_e0_241, 6); r_; });
  }
  case TAG_EAssign: {
    V v_x_24431 = heff_field(v_e0_241, 0);
    V v_e_24433 = heff_field(v_e0_241, 2);
    V v_ru_24e0_241_24EAssign = heff_take_reuse_n(v_e0_241, 5ULL, 3);
    V v_text_24434 = heff_take_field(v_x_24431, 1);
    V v_start_24435 = heff_take_field(v_x_24431, 3);
    V v_end_24436 = heff_get_n(v_x_24431, 4, 9);
    V v_m_24437 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_e_24433)}));
    V v_x1_24438 = heff_tr(heff_call(v_m_24437, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x1_24438)) {
    case TAG_MkPair: {
      V v_x11_24439 = heff_field(v_x1_24438, 0);
      V v_st_24440 = heff_field(v_x1_24438, 1);
      V v_ru_24x1_24438_24MkPair = heff_take_reuse_n(v_x1_24438, 3ULL, 2);
      switch (heff_tag_of(v_x11_24439)) {
      case TAG_Left: {
        V v_e_24441 = heff_field(v_x11_24439, 0);
        V v_ru_24x11_24439_24Left = heff_take_reuse_n(v_x11_24439, 1ULL, 1);
        heff_drop(v_e_24433);
        heff_drop_cell(v_ru_24e0_241_24EAssign, 3);
        heff_drop(v_text_24434);
        heff_drop(v_start_24435);
        heff_drop(v_end_24436);
        return heff_tag_at_n(v_ru_24x1_24438_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_24439_24Left, TAG_Left, 1, (V[]){v_e_24441}), v_st_24440});
      }
      case TAG_Right: {
        V v_x_24442 = heff_field(v_x11_24439, 0);
        V v_ru_24x11_24439_24Right = heff_take_reuse_n(v_x11_24439, 1ULL, 1);
        V v_t_24443 = heff_tag_at_n(v_ru_24e0_241_24EAssign, TAG_EAssign, 3, (V[]){v_text_24434, heff_rec_n(2, shape_start__end, (V[]){heff_dup(v_start_24435), v_end_24436}), v_x_24442});
        V v_t_24444 = (g_heff_2esyntax_2ecst_2elastE(v_e_24433));
        V v_e_24445 = heff_get_n(v_t_24444, 4, 9);
        V v_x_24446 = heff_tag_n(TAG_At, 2, (V[]){v_t_24443, heff_rec_n(2, shape_start__end, (V[]){v_start_24435, v_e_24445})});
        return heff_tag_at_n(v_ru_24x1_24438_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_24439_24Right, TAG_Right, 1, (V[]){v_x_24446}), v_st_24440});
      }
      default: return heff_nomatch(v_x11_24439);
      }
    }
    default: return heff_nomatch(v_x1_24438);
    }
  }
  case TAG_EWhile: {
    V v_kw_24447 = heff_dup(heff_field(v_e0_241, 0));
    V v_c_24448 = heff_dup(heff_field(v_e0_241, 1));
    V v_body_24450 = heff_dup(heff_field(v_e0_241, 3));
    V v_m_24451 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_c_24448}));
    V v_x1_24452 = heff_tr(heff_call(v_m_24451, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x1_24452)) {
    case TAG_MkPair: {
      V v_x11_24453 = heff_field(v_x1_24452, 0);
      V v_st_24454 = heff_field(v_x1_24452, 1);
      V v_ru_24x1_24452_24MkPair = heff_take_reuse_n(v_x1_24452, 3ULL, 2);
      switch (heff_tag_of(v_x11_24453)) {
      case TAG_Left: {
        V v_e_24455 = heff_field(v_x11_24453, 0);
        V v_ru_24x11_24453_24Left = heff_take_reuse_n(v_x11_24453, 1ULL, 1);
        heff_drop_rec(v_r_240, 3);
        heff_drop_tag(v_e0_241, 4);
        heff_drop_rec(v_kw_24447, 9);
        heff_drop(v_body_24450);
        return heff_tag_at_n(v_ru_24x1_24452_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_24453_24Left, TAG_Left, 1, (V[]){v_e_24455}), v_st_24454});
      }
      case TAG_Right: {
        V v_x_24456 = heff_field(v_x11_24453, 0);
        heff_take_n(v_x11_24453, 1ULL, 1);
        V v_t_24458 = heff_tr(heff_call(((V)&g_heff_2esyntax_2esurface_2eblock_clo), 2, (V[]){heff_clo_n(g_heff_2esyntax_2esurface_2eexprL_lam19, 1, 1, (V[]){v_r_240}), v_body_24450}));
        return (g_heff_2esyntax_2esurface_2ebind_24tok2(v_ru_24x1_24452_24MkPair, v_t_24458, heff_clo_n(g_heff_2esyntax_2esurface_2eexprL_lam20, 2, 3, (V[]){v_e0_241, v_kw_24447, v_x_24456}), v_st_24454));
      }
      default: return heff_nomatch(v_x11_24453);
      }
    }
    default: return heff_nomatch(v_x1_24452);
    }
  }
  case TAG_EFor: {
    V v_kw_24465 = heff_dup(heff_field(v_e0_241, 0));
    V v_p_24466 = heff_dup(heff_field(v_e0_241, 1));
    V v_c_24468 = heff_dup(heff_field(v_e0_241, 3));
    V v_body_24470 = heff_dup(heff_field(v_e0_241, 5));
    V v_m_24471 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_c_24468}));
    V v_x1_24472 = heff_tr(heff_call(v_m_24471, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x1_24472)) {
    case TAG_MkPair: {
      V v_x11_24473 = heff_field(v_x1_24472, 0);
      V v_st_24474 = heff_field(v_x1_24472, 1);
      V v_ru_24x1_24472_24MkPair = heff_take_reuse_n(v_x1_24472, 3ULL, 2);
      switch (heff_tag_of(v_x11_24473)) {
      case TAG_Left: {
        V v_e_24475 = heff_field(v_x11_24473, 0);
        V v_ru_24x11_24473_24Left = heff_take_reuse_n(v_x11_24473, 1ULL, 1);
        heff_drop_rec(v_r_240, 3);
        heff_drop_tag(v_e0_241, 6);
        heff_drop_rec(v_kw_24465, 9);
        heff_drop(v_p_24466);
        heff_drop(v_body_24470);
        return heff_tag_at_n(v_ru_24x1_24472_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_24473_24Left, TAG_Left, 1, (V[]){v_e_24475}), v_st_24474});
      }
      case TAG_Right: {
        V v_x_24476 = heff_field(v_x11_24473, 0);
        V v_ru_24x11_24473_24Right = heff_take_reuse_n(v_x11_24473, 1ULL, 1);
        V v_m_24477 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 1)), 1, (V[]){heff_dup(v_p_24466)}));
        V v_x1_24478 = heff_tr(heff_call(v_m_24477, 1, (V[]){v_st_24474}));
        switch (heff_tag_of(v_x1_24478)) {
        case TAG_MkPair: {
          V v_x11_24479 = heff_field(v_x1_24478, 0);
          V v_st_24480 = heff_field(v_x1_24478, 1);
          V v_ru_24x1_24478_24MkPair = heff_take_reuse_n(v_x1_24478, 3ULL, 2);
          switch (heff_tag_of(v_x11_24479)) {
          case TAG_Left: {
            V v_e_24481 = heff_field(v_x11_24479, 0);
            V v_ru_24x11_24479_24Left = heff_take_reuse_n(v_x11_24479, 1ULL, 1);
            heff_drop_rec(v_r_240, 3);
            heff_drop_tag(v_e0_241, 6);
            heff_drop_rec(v_kw_24465, 9);
            heff_drop(v_p_24466);
            heff_drop(v_body_24470);
            heff_drop(v_x_24476);
            heff_drop_cell(v_ru_24x11_24473_24Right, 1);
            heff_drop_cell(v_ru_24x1_24478_24MkPair, 2);
            return heff_tag_at_n(v_ru_24x1_24472_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_24479_24Left, TAG_Left, 1, (V[]){v_e_24481}), v_st_24480});
          }
          case TAG_Right: {
            V v_x_24482 = heff_field(v_x11_24479, 0);
            V v_ru_24x11_24479_24Right = heff_take_reuse_n(v_x11_24479, 1ULL, 1);
            V v_t_24483 = ({ V b_0 = NTAG(TAG_Nil); V a_1 = v_p_24466; V r_ = (g_heff_2esyntax_2esurface_2eboundBy(b_0, a_1)); heff_drop(b_0); heff_drop(v_p_24466); r_; });
            V v_t_24485 = heff_tr(heff_call(((V)&g_heff_2esyntax_2esurface_2eblock_clo), 2, (V[]){heff_clo_n(g_heff_2esyntax_2esurface_2eexprL_lam21, 1, 1, (V[]){v_r_240}), v_body_24470}));
            HeffT2 v_t_24486 = (g_heff_2esyntax_2esurface_2ewithScope_24cpr(v_t_24483, v_t_24485, v_st_24480));
            {
              V v_field_24487 = v_t_24486.f[0];
              V v_field_24488 = v_t_24486.f[1];
              V v_x11_24489 = v_field_24487;
              V v_st_24490 = v_field_24488;
              switch (heff_tag_of(v_x11_24489)) {
              case TAG_Left: {
                V v_e_24491 = heff_field(v_x11_24489, 0);
                heff_take_n(v_x11_24489, 1ULL, 1);
                heff_drop_tag(v_e0_241, 6);
                heff_drop_rec(v_kw_24465, 9);
                heff_drop(v_x_24476);
                heff_drop_cell(v_ru_24x11_24473_24Right, 1);
                heff_drop_cell(v_ru_24x1_24478_24MkPair, 2);
                heff_drop(v_x_24482);
                return heff_tag_at_n(v_ru_24x1_24472_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_24479_24Right, TAG_Left, 1, (V[]){v_e_24491}), v_st_24490});
              }
              case TAG_Right: {
                V v_x_24492 = heff_field(v_x11_24489, 0);
                heff_take_n(v_x11_24489, 1ULL, 1);
                heff_drop_cell(v_ru_24x11_24479_24Right, 1);
                V v_t_24493 = (g_heff_2esyntax_2ecst_2elastE(v_e0_241));
                V v_e_24494 = heff_get_n(v_t_24493, 4, 9);
                V v_t_24495 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_24465, 3, 9), v_e_24494});
                V v_x_24496 = heff_tag_at_n(v_ru_24x1_24478_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_EFor, 3, (V[]){v_x_24482, v_x_24476, v_x_24492}), v_t_24495});
                return heff_tag_at_n(v_ru_24x1_24472_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_24473_24Right, TAG_Right, 1, (V[]){v_x_24496}), v_st_24490});
              }
              default: return heff_nomatch(v_x11_24489);
              }
            }
          }
          default: return heff_nomatch(v_x11_24479);
          }
        }
        default: return heff_nomatch(v_x1_24478);
        }
      }
      default: return heff_nomatch(v_x11_24473);
      }
    }
    default: return heff_nomatch(v_x1_24472);
    }
  }
  case TAG_EJump: {
    V v_kw_24497 = heff_field(v_e0_241, 0);
    V v_ru_24e0_241_24EJump = heff_take_reuse_n(v_e0_241, 1ULL, 1);
    heff_drop_rec(v_r_240, 3);
    V v_text_24498 = heff_take_field(v_kw_24497, 1);
    V v_start_24499 = heff_take_field(v_kw_24497, 3);
    V v_end_24500 = heff_get_n(v_kw_24497, 4, 9);
    V v_t_24501;
    if (heff_strEq_c(v_text_24498, ((V)&g_heff_2esyntax_2esurface_2eexprL_str17))) {
      v_t_24501 = NTAG(TAG_EBreak);
    } else {
      v_t_24501 = NTAG(TAG_EContinue);
    }
    V v_t_24502 = heff_tag_n(TAG_At, 2, (V[]){v_t_24501, heff_rec_n(2, shape_start__end, (V[]){v_start_24499, v_end_24500})});
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24e0_241_24EJump, TAG_Right, 1, (V[]){v_t_24502}), v_z_242});
  }
  case TAG_EReturn: {
    V v_kw_24503 = heff_field(v_e0_241, 0);
    V v_e_24504 = heff_field(v_e0_241, 1);
    V v_ru_24e0_241_24EReturn = heff_take_reuse_n(v_e0_241, 3ULL, 2);
    V v_m_24505 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_e_24504)}));
    V v_x1_24506 = heff_tr(heff_call(v_m_24505, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x1_24506)) {
    case TAG_MkPair: {
      V v_x11_24507 = heff_field(v_x1_24506, 0);
      V v_st_24508 = heff_field(v_x1_24506, 1);
      V v_ru_24x1_24506_24MkPair = heff_take_reuse_n(v_x1_24506, 3ULL, 2);
      switch (heff_tag_of(v_x11_24507)) {
      case TAG_Left: {
        V v_e_24509 = heff_field(v_x11_24507, 0);
        V v_ru_24x11_24507_24Left = heff_take_reuse_n(v_x11_24507, 1ULL, 1);
        heff_drop_rec(v_kw_24503, 9);
        heff_drop(v_e_24504);
        heff_drop_cell(v_ru_24x1_24506_24MkPair, 2);
        return heff_tag_at_n(v_ru_24e0_241_24EReturn, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_24507_24Left, TAG_Left, 1, (V[]){v_e_24509}), v_st_24508});
      }
      case TAG_Right: {
        V v_x_24510 = heff_field(v_x11_24507, 0);
        V v_ru_24x11_24507_24Right = heff_take_reuse_n(v_x11_24507, 1ULL, 1);
        V v_t_24511 = (g_heff_2esyntax_2ecst_2elastE(v_e_24504));
        V v_e_24512 = heff_get_n(v_t_24511, 4, 9);
        V v_t_24513 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_24503, 3, 9), v_e_24512});
        V v_x_24514 = heff_tag_at_n(v_ru_24e0_241_24EReturn, TAG_At, 2, (V[]){heff_tag_n(TAG_EReturn, 1, (V[]){v_x_24510}), v_t_24513});
        return heff_tag_at_n(v_ru_24x1_24506_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_24507_24Right, TAG_Right, 1, (V[]){v_x_24514}), v_st_24508});
      }
      default: return heff_nomatch(v_x11_24507);
      }
    }
    default: return heff_nomatch(v_x1_24506);
    }
  }
  case TAG_ENest: {
    V v_o_24515 = heff_field(v_e0_241, 0);
    V v_e_24517 = heff_field(v_e0_241, 2);
    V v_c_24518 = heff_field(v_e0_241, 3);
    heff_take_n(v_e0_241, 13ULL, 4);
    V v_m_24519 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_24517}));
    V v_x1_24520 = heff_tr(heff_call(v_m_24519, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x1_24520)) {
    case TAG_MkPair: {
      V v_x11_24521 = heff_field(v_x1_24520, 0);
      V v_st_24522 = heff_field(v_x1_24520, 1);
      V v_ru_24x1_24520_24MkPair = heff_take_reuse_n(v_x1_24520, 3ULL, 2);
      switch (heff_tag_of(v_x11_24521)) {
      case TAG_Left: {
        V v_e_24523 = heff_field(v_x11_24521, 0);
        V v_ru_24x11_24521_24Left = heff_take_reuse_n(v_x11_24521, 1ULL, 1);
        heff_drop_rec(v_o_24515, 9);
        heff_drop_rec(v_c_24518, 9);
        return heff_tag_at_n(v_ru_24x1_24520_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_24521_24Left, TAG_Left, 1, (V[]){v_e_24523}), v_st_24522});
      }
      case TAG_Right: {
        V v_x_24524 = heff_field(v_x11_24521, 0);
        V v_ru_24x11_24521_24Right = heff_take_reuse_n(v_x11_24521, 1ULL, 1);
        V v_t_24525 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_o_24515, 3, 9), heff_get_n(v_c_24518, 4, 9)});
        V v_t_24526 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ENest, 1, (V[]){v_x_24524}), v_t_24525});
        return heff_tag_at_n(v_ru_24x1_24520_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_24521_24Right, TAG_Right, 1, (V[]){v_t_24526}), v_st_24522});
      }
      default: return heff_nomatch(v_x11_24521);
      }
    }
    default: return heff_nomatch(v_x1_24520);
    }
  }
  case TAG_EArrow: {
    V v_arrow_24527 = heff_field(v_e0_241, 0);
    V v_e_24528 = heff_field(v_e0_241, 1);
    V v_ru_24e0_241_24EArrow = heff_take_reuse_n(v_e0_241, 3ULL, 2);
    V v_m_24529 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_e_24528)}));
    V v_x1_24530 = heff_tr(heff_call(v_m_24529, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x1_24530)) {
    case TAG_MkPair: {
      V v_x11_24531 = heff_field(v_x1_24530, 0);
      V v_st_24532 = heff_field(v_x1_24530, 1);
      V v_ru_24x1_24530_24MkPair = heff_take_reuse_n(v_x1_24530, 3ULL, 2);
      switch (heff_tag_of(v_x11_24531)) {
      case TAG_Left: {
        V v_e_24533 = heff_field(v_x11_24531, 0);
        V v_ru_24x11_24531_24Left = heff_take_reuse_n(v_x11_24531, 1ULL, 1);
        heff_drop_rec(v_arrow_24527, 9);
        heff_drop(v_e_24528);
        heff_drop_cell(v_ru_24x1_24530_24MkPair, 2);
        return heff_tag_at_n(v_ru_24e0_241_24EArrow, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_24531_24Left, TAG_Left, 1, (V[]){v_e_24533}), v_st_24532});
      }
      case TAG_Right: {
        V v_x_24534 = heff_field(v_x11_24531, 0);
        V v_ru_24x11_24531_24Right = heff_take_reuse_n(v_x11_24531, 1ULL, 1);
        V v_t_24535 = (g_heff_2esyntax_2ecst_2elastE(v_e_24528));
        V v_e_24536 = heff_get_n(v_t_24535, 4, 9);
        V v_t_24537 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_arrow_24527, 3, 9), v_e_24536});
        V v_x_24538 = heff_tag_at_n(v_ru_24e0_241_24EArrow, TAG_At, 2, (V[]){heff_tag_n(TAG_ENest, 1, (V[]){v_x_24534}), v_t_24537});
        return heff_tag_at_n(v_ru_24x1_24530_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_24531_24Right, TAG_Right, 1, (V[]){v_x_24538}), v_st_24532});
      }
      default: return heff_nomatch(v_x11_24531);
      }
    }
    default: return heff_nomatch(v_x1_24530);
    }
  }
  case TAG_IfThen: {
    V v_kw_24539 = heff_field(v_e0_241, 0);
    V v_c_24540 = heff_field(v_e0_241, 1);
    V v_a_24542 = heff_field(v_e0_241, 3);
    heff_take_n(v_e0_241, 11ULL, 4);
    V v_m_24543 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_c_24540}));
    V v_x1_24544 = heff_tr(heff_call(v_m_24543, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x1_24544)) {
    case TAG_MkPair: {
      V v_x11_24545 = heff_field(v_x1_24544, 0);
      V v_st_24546 = heff_field(v_x1_24544, 1);
      V v_ru_24x1_24544_24MkPair = heff_take_reuse_n(v_x1_24544, 3ULL, 2);
      switch (heff_tag_of(v_x11_24545)) {
      case TAG_Left: {
        V v_e_24547 = heff_field(v_x11_24545, 0);
        V v_ru_24x11_24545_24Left = heff_take_reuse_n(v_x11_24545, 1ULL, 1);
        heff_drop_rec(v_r_240, 3);
        heff_drop_rec(v_kw_24539, 9);
        heff_drop(v_a_24542);
        return heff_tag_at_n(v_ru_24x1_24544_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_24545_24Left, TAG_Left, 1, (V[]){v_e_24547}), v_st_24546});
      }
      case TAG_Right: {
        V v_x_24548 = heff_field(v_x11_24545, 0);
        V v_ru_24x11_24545_24Right = heff_take_reuse_n(v_x11_24545, 1ULL, 1);
        V v_m_24549 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_a_24542)}));
        V v_x1_24550 = heff_tr(heff_call(v_m_24549, 1, (V[]){v_st_24546}));
        switch (heff_tag_of(v_x1_24550)) {
        case TAG_MkPair: {
          V v_x11_24551 = heff_field(v_x1_24550, 0);
          V v_st_24552 = heff_field(v_x1_24550, 1);
          V v_ru_24x1_24550_24MkPair = heff_take_reuse_n(v_x1_24550, 3ULL, 2);
          switch (heff_tag_of(v_x11_24551)) {
          case TAG_Left: {
            V v_e_24553 = heff_field(v_x11_24551, 0);
            V v_ru_24x11_24551_24Left = heff_take_reuse_n(v_x11_24551, 1ULL, 1);
            heff_drop_rec(v_kw_24539, 9);
            heff_drop(v_a_24542);
            heff_drop(v_x_24548);
            heff_drop_cell(v_ru_24x11_24545_24Right, 1);
            heff_drop_cell(v_ru_24x1_24550_24MkPair, 2);
            return heff_tag_at_n(v_ru_24x1_24544_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_24551_24Left, TAG_Left, 1, (V[]){v_e_24553}), v_st_24552});
          }
          case TAG_Right: {
            V v_x_24554 = heff_field(v_x11_24551, 0);
            heff_take_n(v_x11_24551, 1ULL, 1);
            V v_t_24555 = (g_heff_2esyntax_2ecst_2elastE(v_a_24542));
            V v_e_24556 = heff_get_n(v_t_24555, 4, 9);
            V v_t_24557 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_24539, 3, 9), v_e_24556});
            V v_x_24558 = heff_tag_at_n(v_ru_24x1_24550_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_EIfThen, 2, (V[]){v_x_24548, v_x_24554}), v_t_24557});
            return heff_tag_at_n(v_ru_24x1_24544_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_24545_24Right, TAG_Right, 1, (V[]){v_x_24558}), v_st_24552});
          }
          default: return heff_nomatch(v_x11_24551);
          }
        }
        default: return heff_nomatch(v_x1_24550);
        }
      }
      default: return heff_nomatch(v_x11_24545);
      }
    }
    default: return heff_nomatch(v_x1_24544);
    }
  }
  case TAG_ETry: {
    V v_kw_24559 = heff_dup(heff_field(v_e0_241, 0));
    V v_ty_24560 = heff_dup(heff_field(v_e0_241, 1));
    V v_body_24561 = heff_dup(heff_field(v_e0_241, 2));
    V v_c_24562 = heff_dup(heff_field(v_e0_241, 3));
    V v_r_24563 = heff_dup(v_r_240);
    V v_x2_24564 = v_ty_24560;
    V v_m_24593;
    switch (heff_tag_of(v_x2_24564)) {
    case TAG_Nothing: {
      heff_drop_rec(v_r_24563, 3);
      v_m_24593 = ((V)&g_heff_2esyntax_2esurface_2eexprL_lam22_clo);
      break;
    }
    case TAG_Just: {
      V v_x21_24567 = heff_field(v_x2_24564, 0);
      V v_ru_24x2_24564_24Just = heff_take_reuse_n(v_x2_24564, 1ULL, 1);
      switch (heff_tag_of(v_x21_24567)) {
      case TAG_Named: {
        V v_x_24569 = heff_field(v_x21_24567, 1);
        V v_e_24571 = heff_field(v_x21_24567, 3);
        heff_take_n(v_x21_24567, 10ULL, 5);
        heff_drop_cell(v_ru_24x2_24564_24Just, 1);
        V v_text_24573 = heff_take_field(v_x_24569, 1);
        V v_start_24574 = heff_take_field(v_x_24569, 3);
        V v_end_24575 = heff_get_n(v_x_24569, 4, 9);
        if (heff_strEq_c(v_text_24573, ((V)&g_heff_2esyntax_2esurface_2eexprL_str18))) {
          heff_drop(v_start_24574);
          heff_drop(v_end_24575);
          V v_m_24576 = heff_tr(heff_call(heff_get_n(v_r_24563, 0, 3), 1, (V[]){v_e_24571}));
          v_m_24593 = heff_clo_n(g_heff_2esyntax_2esurface_2eexprL_lam23, 1, 1, (V[]){v_m_24576});
        } else {
          heff_drop_rec(v_r_24563, 3);
          heff_drop(v_e_24571);
          v_m_24593 = heff_clo_n(g_heff_2esyntax_2esurface_2eexprL_lam24, 1, 2, (V[]){v_start_24574, v_end_24575});
        }
        break;
      }
      default: {
        heff_drop_rec(v_r_24563, 3);
        V v_t_24587 = ({ V a_0 = v_x21_24567; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop(v_x21_24567); r_; });
        V v_start_24588 = heff_take_field(v_t_24587, 3);
        V v_end_24589 = heff_get_n(v_t_24587, 4, 9);
        V v_t_24590 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2eexprL_str20)}), heff_rec_n(2, shape_start__end, (V[]){v_start_24588, v_end_24589})});
        V v_x_24591 = heff_tag_at_n(v_ru_24x2_24564_24Just, TAG_Just, 1, (V[]){v_t_24590});
        v_m_24593 = heff_clo_n(g_heff_2esyntax_2esurface_2eexprL_lam25, 1, 1, (V[]){v_x_24591});
        break;
      }
      }
      break;
    }
    default: heff_nomatch(v_x2_24564);
    }
    V v_x1_24594 = heff_tr(heff_call(v_m_24593, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x1_24594)) {
    case TAG_MkPair: {
      V v_x11_24595 = heff_field(v_x1_24594, 0);
      V v_st_24596 = heff_field(v_x1_24594, 1);
      V v_ru_24x1_24594_24MkPair = heff_take_reuse_n(v_x1_24594, 3ULL, 2);
      switch (heff_tag_of(v_x11_24595)) {
      case TAG_Left: {
        V v_e_24597 = heff_field(v_x11_24595, 0);
        V v_ru_24x11_24595_24Left = heff_take_reuse_n(v_x11_24595, 1ULL, 1);
        heff_drop_rec(v_r_240, 3);
        heff_drop_tag(v_e0_241, 4);
        heff_drop_rec(v_kw_24559, 9);
        heff_drop(v_body_24561);
        heff_drop(v_c_24562);
        return heff_tag_at_n(v_ru_24x1_24594_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_24595_24Left, TAG_Left, 1, (V[]){v_e_24597}), v_st_24596});
      }
      case TAG_Right: {
        V v_x_24598 = heff_field(v_x11_24595, 0);
        heff_take_n(v_x11_24595, 1ULL, 1);
        V v_t_24600 = heff_tr(heff_call(((V)&g_heff_2esyntax_2esurface_2eblock_clo), 2, (V[]){heff_clo_n(g_heff_2esyntax_2esurface_2eexprL_lam26, 1, 1, (V[]){heff_dup(v_r_240)}), v_body_24561}));
        return (g_heff_2esyntax_2esurface_2ebind_24tok2(v_ru_24x1_24594_24MkPair, v_t_24600, heff_clo_n(g_heff_2esyntax_2esurface_2eexprL_lam27, 2, 5, (V[]){v_r_240, v_c_24562, v_x_24598, v_e0_241, v_kw_24559}), v_st_24596));
      }
      default: return heff_nomatch(v_x11_24595);
      }
    }
    default: return heff_nomatch(v_x1_24594);
    }
  }
  case TAG_EWith: {
    V v_kw_24614 = heff_dup(heff_field(v_e0_241, 0));
    V v_e_24615 = heff_dup(heff_field(v_e0_241, 1));
    V v_e04_24617 = heff_dup(heff_field(v_e0_241, 3));
    V v_body_24619 = heff_dup(heff_field(v_e0_241, 5));
    switch (heff_tag_of(v_e04_24617)) {
    case TAG_PAtom: {
      V v_x_24620 = heff_field(v_e04_24617, 0);
      V v_ru_24e04_24617_24PAtom = heff_take_reuse_n(v_e04_24617, 1ULL, 1);
      V v_text_24621 = heff_take_field(v_x_24620, 1);
      V v_start_24622 = heff_take_field(v_x_24620, 3);
      V v_end_24623 = heff_get_n(v_x_24620, 4, 9);
      V v_m_24624 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e_24615}));
      V v_x1_24625 = heff_tr(heff_call(v_m_24624, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_24625)) {
      case TAG_MkPair: {
        V v_x11_24626 = heff_field(v_x1_24625, 0);
        V v_st_24627 = heff_field(v_x1_24625, 1);
        V v_ru_24x1_24625_24MkPair = heff_take_reuse_n(v_x1_24625, 3ULL, 2);
        switch (heff_tag_of(v_x11_24626)) {
        case TAG_Left: {
          V v_e_24628 = heff_field(v_x11_24626, 0);
          heff_take_n(v_x11_24626, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_tag(v_e0_241, 6);
          heff_drop_rec(v_kw_24614, 9);
          heff_drop(v_body_24619);
          heff_drop(v_text_24621);
          heff_drop(v_start_24622);
          heff_drop(v_end_24623);
          return heff_tag_at_n(v_ru_24x1_24625_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24e04_24617_24PAtom, TAG_Left, 1, (V[]){v_e_24628}), v_st_24627});
        }
        case TAG_Right: {
          V v_x_24629 = heff_field(v_x11_24626, 0);
          heff_take_n(v_x11_24626, 1ULL, 1);
          V v_t_24630 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_text_24621), NTAG(TAG_Nil)});
          V v_t_24632 = heff_tr(heff_call(((V)&g_heff_2esyntax_2esurface_2eblock_clo), 2, (V[]){heff_clo_n(g_heff_2esyntax_2esurface_2eexprL_lam28, 1, 1, (V[]){v_r_240}), v_body_24619}));
          HeffT2 v_t_24633 = (g_heff_2esyntax_2esurface_2ewithScope_24cpr(v_t_24630, v_t_24632, v_st_24627));
          {
            V v_field_24634 = v_t_24633.f[0];
            V v_field_24635 = v_t_24633.f[1];
            V v_x11_24636 = v_field_24634;
            V v_st_24637 = v_field_24635;
            switch (heff_tag_of(v_x11_24636)) {
            case TAG_Left: {
              V v_e_24638 = heff_field(v_x11_24636, 0);
              heff_take_n(v_x11_24636, 1ULL, 1);
              heff_drop_tag(v_e0_241, 6);
              heff_drop_rec(v_kw_24614, 9);
              heff_drop(v_text_24621);
              heff_drop(v_start_24622);
              heff_drop(v_end_24623);
              heff_drop(v_x_24629);
              return heff_tag_at_n(v_ru_24x1_24625_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24e04_24617_24PAtom, TAG_Left, 1, (V[]){v_e_24638}), v_st_24637});
            }
            case TAG_Right: {
              V v_x_24639 = heff_field(v_x11_24636, 0);
              heff_take_n(v_x11_24636, 1ULL, 1);
              V v_t_24640 = heff_tag_n(TAG_EWith, 4, (V[]){v_x_24629, v_text_24621, heff_rec_n(2, shape_start__end, (V[]){v_start_24622, v_end_24623}), v_x_24639});
              V v_t_24641 = (g_heff_2esyntax_2ecst_2elastE(v_e0_241));
              V v_e_24642 = heff_get_n(v_t_24641, 4, 9);
              V v_t_24643 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_24614, 3, 9), v_e_24642});
              V v_x_24644 = heff_tag_n(TAG_At, 2, (V[]){v_t_24640, v_t_24643});
              return heff_tag_at_n(v_ru_24x1_24625_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24e04_24617_24PAtom, TAG_Right, 1, (V[]){v_x_24644}), v_st_24637});
            }
            default: return heff_nomatch(v_x11_24636);
            }
          }
        }
        default: return heff_nomatch(v_x11_24626);
        }
      }
      default: return heff_nomatch(v_x1_24625);
      }
    }
    default: {
      V v_m_24645 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e_24615}));
      V v_x1_24646 = heff_tr(heff_call(v_m_24645, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_24646)) {
      case TAG_MkPair: {
        V v_x11_24647 = heff_field(v_x1_24646, 0);
        V v_st_24648 = heff_field(v_x1_24646, 1);
        V v_ru_24x1_24646_24MkPair = heff_take_reuse_n(v_x1_24646, 3ULL, 2);
        switch (heff_tag_of(v_x11_24647)) {
        case TAG_Left: {
          V v_e_24649 = heff_field(v_x11_24647, 0);
          V v_ru_24x11_24647_24Left = heff_take_reuse_n(v_x11_24647, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_tag(v_e0_241, 6);
          heff_drop_rec(v_kw_24614, 9);
          heff_drop(v_e04_24617);
          heff_drop(v_body_24619);
          return heff_tag_at_n(v_ru_24x1_24646_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_24647_24Left, TAG_Left, 1, (V[]){v_e_24649}), v_st_24648});
        }
        case TAG_Right: {
          V v_x_24650 = heff_field(v_x11_24647, 0);
          V v_ru_24x11_24647_24Right = heff_take_reuse_n(v_x11_24647, 1ULL, 1);
          V v_m_24651 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 1)), 1, (V[]){heff_dup(v_e04_24617)}));
          V v_x1_24652 = heff_tr(heff_call(v_m_24651, 1, (V[]){v_st_24648}));
          switch (heff_tag_of(v_x1_24652)) {
          case TAG_MkPair: {
            V v_x11_24653 = heff_field(v_x1_24652, 0);
            V v_st_24654 = heff_field(v_x1_24652, 1);
            V v_ru_24x1_24652_24MkPair = heff_take_reuse_n(v_x1_24652, 3ULL, 2);
            switch (heff_tag_of(v_x11_24653)) {
            case TAG_Left: {
              V v_e_24655 = heff_field(v_x11_24653, 0);
              V v_ru_24x11_24653_24Left = heff_take_reuse_n(v_x11_24653, 1ULL, 1);
              heff_drop_rec(v_r_240, 3);
              heff_drop_tag(v_e0_241, 6);
              heff_drop_rec(v_kw_24614, 9);
              heff_drop(v_e04_24617);
              heff_drop(v_body_24619);
              heff_drop(v_x_24650);
              heff_drop_cell(v_ru_24x11_24647_24Right, 1);
              heff_drop_cell(v_ru_24x1_24652_24MkPair, 2);
              return heff_tag_at_n(v_ru_24x1_24646_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_24653_24Left, TAG_Left, 1, (V[]){v_e_24655}), v_st_24654});
            }
            case TAG_Right: {
              V v_x_24656 = heff_field(v_x11_24653, 0);
              V v_ru_24x11_24653_24Right = heff_take_reuse_n(v_x11_24653, 1ULL, 1);
              V v_t_24657 = ({ V b_0 = NTAG(TAG_Nil); V a_1 = v_e04_24617; V r_ = (g_heff_2esyntax_2esurface_2eboundBy(b_0, a_1)); heff_drop(b_0); heff_drop(v_e04_24617); r_; });
              V v_t_24659 = heff_tr(heff_call(((V)&g_heff_2esyntax_2esurface_2eblock_clo), 2, (V[]){heff_clo_n(g_heff_2esyntax_2esurface_2eexprL_lam29, 1, 1, (V[]){v_r_240}), v_body_24619}));
              HeffT2 v_t_24660 = (g_heff_2esyntax_2esurface_2ewithScope_24cpr(v_t_24657, v_t_24659, v_st_24654));
              {
                V v_field_24661 = v_t_24660.f[0];
                V v_field_24662 = v_t_24660.f[1];
                V v_x11_24663 = v_field_24661;
                V v_st_24664 = v_field_24662;
                switch (heff_tag_of(v_x11_24663)) {
                case TAG_Left: {
                  V v_e_24665 = heff_field(v_x11_24663, 0);
                  heff_take_n(v_x11_24663, 1ULL, 1);
                  heff_drop_tag(v_e0_241, 6);
                  heff_drop_rec(v_kw_24614, 9);
                  heff_drop(v_x_24650);
                  heff_drop_cell(v_ru_24x11_24647_24Right, 1);
                  heff_drop_cell(v_ru_24x1_24652_24MkPair, 2);
                  heff_drop(v_x_24656);
                  return heff_tag_at_n(v_ru_24x1_24646_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_24653_24Right, TAG_Left, 1, (V[]){v_e_24665}), v_st_24664});
                }
                case TAG_Right: {
                  V v_x_24666 = heff_field(v_x11_24663, 0);
                  heff_take_n(v_x11_24663, 1ULL, 1);
                  V v_t_24669;
                  switch (heff_tag_of(v_x_24656)) {
                  case TAG_At: {
                    V v_s_24668 = heff_dup(heff_field(v_x_24656, 1));
                    v_t_24669 = v_s_24668;
                    break;
                  }
                  default: heff_nomatch(v_x_24656);
                  }
                  V v_t_24672;
                  switch (heff_tag_of(v_x_24656)) {
                  case TAG_At: {
                    V v_s_24671 = heff_dup(heff_field(v_x_24656, 1));
                    v_t_24672 = v_s_24671;
                    break;
                  }
                  default: heff_nomatch(v_x_24656);
                  }
                  V v_t_24673 = heff_tag_at_n(v_ru_24x1_24652_24MkPair, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24653_24Right, TAG_EVar, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2eexprL_str21)}), v_t_24672});
                  V v_t_24676;
                  switch (heff_tag_of(v_x_24656)) {
                  case TAG_At: {
                    V v_s_24675 = heff_dup(heff_field(v_x_24656, 1));
                    v_t_24676 = v_s_24675;
                    break;
                  }
                  default: heff_nomatch(v_x_24656);
                  }
                  V v_t_24677 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_StmtLet, 2, (V[]){v_x_24656, v_t_24673}), v_t_24676});
                  V v_t_24678 = heff_tag_n(TAG_EWith, 4, (V[]){v_x_24650, ((V)&g_heff_2esyntax_2esurface_2eexprL_str22), v_t_24669, heff_tag_n(TAG_Cons, 2, (V[]){v_t_24677, v_x_24666})});
                  V v_t_24679 = (g_heff_2esyntax_2ecst_2elastE(v_e0_241));
                  V v_e_24680 = heff_get_n(v_t_24679, 4, 9);
                  V v_t_24681 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_24614, 3, 9), v_e_24680});
                  V v_x_24682 = heff_tag_n(TAG_At, 2, (V[]){v_t_24678, v_t_24681});
                  return heff_tag_at_n(v_ru_24x1_24646_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_24647_24Right, TAG_Right, 1, (V[]){v_x_24682}), v_st_24664});
                }
                default: return heff_nomatch(v_x11_24663);
                }
              }
            }
            default: return heff_nomatch(v_x11_24653);
            }
          }
          default: return heff_nomatch(v_x1_24652);
          }
        }
        default: return heff_nomatch(v_x11_24647);
        }
      }
      default: return heff_nomatch(v_x1_24646);
      }
    }
    }
  }
  default: {
    heff_drop_rec(v_r_240, 3);
    V v_t_24683 = (g_heff_2esyntax_2ecst_2efirstE(v_e0_241));
    V v_start_24684 = heff_take_field(v_t_24683, 3);
    V v_end_24685 = heff_get_n(v_t_24683, 4, 9);
    V v_t_24686 = ({ V a_0 = v_e0_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop(v_e0_241); r_; });
    V v_t_24687 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eexprL_str23), heff_get_n(v_t_24686, 1, 9));
    V v_msg_24688 = heff_strAppend(v_t_24687, ((V)&g_heff_2esyntax_2esurface_2eexprL_str24));
    V v_t_24689 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24688, heff_rec_n(2, shape_start__end, (V[]){v_start_24684, v_end_24685}), NTAG(TAG_Nothing)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24689}), v_z_242});
  }
  }
}
V g_heff_2esyntax_2esurface_2eexprL_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2eexprL(a[0], a[1], a[2]);
}
V g_heff_2esyntax_2esurface_2eexprL_lam0(V self, V *args) {
  V v_m_2430 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2esyntax_2esurface_2esegmentL(v_r_240, v_m_2430));
}
V g_heff_2esyntax_2esurface_2eexprL_lam1(V self, V *args) {
  V v_x_2447 = args[0];
  V v_rest_2448 = args[1];
  V v_sp_2445 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2449 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ETag, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2eexprL_str8)}), v_sp_2445});
  V v_t_2450 = heff_tag_n(TAG_Cons, 2, (V[]){v_rest_2448, NTAG(TAG_Nil)});
  return (g_heff_2esyntax_2epresyntax_2eapp(v_t_2449, heff_tag_n(TAG_Cons, 2, (V[]){v_x_2447, v_t_2450})));
}
V g_heff_2esyntax_2esurface_2eexprL_lam3(V self, V *args) {
  V v_st_2483 = args[0];
  V v_m_2482 = heff_env(self)[0];
  V v_path_2479 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_2484 = heff_tr(heff_call(v_m_2482, 1, (V[]){v_st_2483}));
  switch (heff_tag_of(v_x1_2484)) {
  case TAG_MkPair: {
    V v_x11_2485 = heff_field(v_x1_2484, 0);
    V v_st_2486 = heff_field(v_x1_2484, 1);
    V v_ru_24x1_2484_24MkPair = heff_take_reuse_n(v_x1_2484, 3ULL, 2);
    switch (heff_tag_of(v_x11_2485)) {
    case TAG_Left: {
      V v_e_2487 = heff_field(v_x11_2485, 0);
      V v_ru_24x11_2485_24Left = heff_take_reuse_n(v_x11_2485, 1ULL, 1);
      heff_drop(v_path_2479);
      return heff_tag_at_n(v_ru_24x1_2484_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_2485_24Left, TAG_Left, 1, (V[]){v_e_2487}), v_st_2486});
    }
    case TAG_Right: {
      V v_x_2488 = heff_field(v_x11_2485, 0);
      V v_ru_24x11_2485_24Right = heff_take_reuse_n(v_x11_2485, 1ULL, 1);
      V v_t_2489 = (g_heff_2esyntax_2esurface_2epathOf(heff_dup(v_path_2479), NTAG(TAG_Nil)));
      V v_t_2490 = ({ V a_0 = v_path_2479; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop(v_path_2479); r_; });
      V v_t_2493;
      switch (heff_tag_of(v_x_2488)) {
      case TAG_At: {
        V v_s_2492 = heff_dup(heff_field(v_x_2488, 1));
        v_t_2493 = v_s_2492;
        break;
      }
      default: heff_nomatch(v_x_2488);
      }
      V v_t_2494 = ({ V rv_0 = heff_get_n(v_t_2490, 3, 9); V rr_ = heff_rec_reuse_nf(v_t_2493, 2ULL, 2, shape_start__end, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
      V v_x_2495 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_SetPath, 2, (V[]){v_t_2489, v_x_2488}), v_t_2494});
      return heff_tag_at_n(v_ru_24x1_2484_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_2485_24Right, TAG_Right, 1, (V[]){v_x_2495}), v_st_2486});
    }
    default: return heff_nomatch(v_x11_2485);
    }
  }
  default: return heff_nomatch(v_x1_2484);
  }
}
V g_heff_2esyntax_2esurface_2eexprL_lam4(V self, V *args) {
  V v_st_2497 = args[0];
  V v_m_2496 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2498 = heff_tr(heff_call(v_m_2496, 1, (V[]){v_st_2497}));
  switch (heff_tag_of(v_x1_2498)) {
  case TAG_MkPair: {
    V v_x11_2499 = heff_field(v_x1_2498, 0);
    V v_st_24100 = heff_field(v_x1_2498, 1);
    V v_ru_24x1_2498_24MkPair = heff_take_reuse_n(v_x1_2498, 3ULL, 2);
    switch (heff_tag_of(v_x11_2499)) {
    case TAG_Left: {
      V v_e_24101 = heff_field(v_x11_2499, 0);
      V v_ru_24x11_2499_24Left = heff_take_reuse_n(v_x11_2499, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_2498_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_2499_24Left, TAG_Left, 1, (V[]){v_e_24101}), v_st_24100});
    }
    case TAG_Right: {
      V v_x_24102 = heff_field(v_x11_2499, 0);
      V v_ru_24x11_2499_24Right = heff_take_reuse_n(v_x11_2499, 1ULL, 1);
      V v_t_24103 = heff_tag_n(TAG_SetPath, 2, (V[]){NTAG(TAG_Nil), heff_dup(v_x_24102)});
      V v_t_24106;
      switch (heff_tag_of(v_x_24102)) {
      case TAG_At: {
        V v_s_24105 = heff_field(v_x_24102, 1);
        heff_take_n(v_x_24102, 2ULL, 2);
        v_t_24106 = v_s_24105;
        break;
      }
      default: heff_nomatch(v_x_24102);
      }
      V v_t_24107 = heff_tag_at_n(v_ru_24x11_2499_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24103, v_t_24106})});
      return heff_tag_at_n(v_ru_24x1_2498_24MkPair, TAG_MkPair, 2, (V[]){v_t_24107, v_st_24100});
    }
    default: return heff_nomatch(v_x11_2499);
    }
  }
  default: return heff_nomatch(v_x1_2498);
  }
}
V g_heff_2esyntax_2esurface_2eexprL_lam2(V self, V *args) {
  V v_m_2476 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_r_2477 = v_r_240;
  V v_x2_2478 = v_m_2476;
  switch (heff_tag_of(v_x2_2478)) {
  case TAG_EUSet: {
    V v_path_2479 = heff_field(v_x2_2478, 0);
    V v_e_2481 = heff_field(v_x2_2478, 2);
    heff_take_n(v_x2_2478, 5ULL, 3);
    V v_m_2482 = heff_tr(heff_call(heff_get_n(v_r_2477, 0, 3), 1, (V[]){v_e_2481}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2eexprL_lam3, 1, 2, (V[]){v_m_2482, v_path_2479});
  }
  default: {
    V v_m_2496 = heff_tr(heff_call(heff_get_n(v_r_2477, 0, 3), 1, (V[]){v_x2_2478}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2eexprL_lam4, 1, 1, (V[]){v_m_2496});
  }
  }
}
V g_heff_2esyntax_2esurface_2eexprL_lam5(V self, V *args) {
  V v_st_24122 = args[0];
  V v_m_24121 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24123 = heff_tr(heff_call(v_m_24121, 1, (V[]){v_st_24122}));
  switch (heff_tag_of(v_x1_24123)) {
  case TAG_MkPair: {
    V v_x11_24124 = heff_field(v_x1_24123, 0);
    V v_st_24125 = heff_field(v_x1_24123, 1);
    V v_ru_24x1_24123_24MkPair = heff_take_reuse_n(v_x1_24123, 3ULL, 2);
    switch (heff_tag_of(v_x11_24124)) {
    case TAG_Left: {
      V v_e_24126 = heff_field(v_x11_24124, 0);
      V v_ru_24x11_24124_24Left = heff_take_reuse_n(v_x11_24124, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24123_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_24124_24Left, TAG_Left, 1, (V[]){v_e_24126}), v_st_24125});
    }
    case TAG_Right: {
      V v_x_24127 = heff_field(v_x11_24124, 0);
      heff_take_n(v_x11_24124, 1ULL, 1);
      V v_t_24128 = (g_heff_2esyntax_2esurface_2enameBinder(v_x_24127));
      V v_t_24129 = heff_tr(heff_call(((V)&g_heff_2esyntax_2esurface_2easBinderOn_clo), 1, (V[]){v_t_24128}));
      return (g_heff_2esyntax_2esurface_2ebind_24s273834694x1861812659_24tok2(v_ru_24x1_24123_24MkPair, MK_INT(150LL), ((V)&g_heff_2esyntax_2esurface_2eexprL_str9), v_t_24129, v_st_24125));
    }
    default: return heff_nomatch(v_x11_24124);
    }
  }
  default: return heff_nomatch(v_x1_24123);
  }
}
V g_heff_2esyntax_2esurface_2eexprL_lam6(V self, V *args) {
  V v_d_27_24130 = args[0];
  V v_st_24131 = args[1];
  V v_o_24116 = heff_env(self)[0];
  V v_c_24120 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_d_27_24130);
  V v_t_24132 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_o_24116, 3, 9), heff_get_n(v_c_24120, 4, 9)});
  V v_t_24133 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2eexprL_str10)}), v_t_24132});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24133}), v_st_24131});
}
V g_heff_2esyntax_2esurface_2eexprL_lam7(V self, V *args) {
  V v_a_24139 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2esyntax_2esurface_2evariantL(v_r_240, v_a_24139));
}
V g_heff_2esyntax_2esurface_2eexprL_lam9(V self, V *args) {
  V v_st_24212 = args[0];
  V v_m_24211 = heff_env(self)[0];
  V v_x_24207 = heff_env(self)[1];
  V v_o_24206 = heff_env(self)[2];
  V v_c_24210 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x1_24213 = heff_tr(heff_call(v_m_24211, 1, (V[]){v_st_24212}));
  switch (heff_tag_of(v_x1_24213)) {
  case TAG_MkPair: {
    V v_x11_24214 = heff_field(v_x1_24213, 0);
    V v_st_24215 = heff_field(v_x1_24213, 1);
    V v_ru_24x1_24213_24MkPair = heff_take_reuse_n(v_x1_24213, 3ULL, 2);
    switch (heff_tag_of(v_x11_24214)) {
    case TAG_Left: {
      V v_e_24216 = heff_field(v_x11_24214, 0);
      V v_ru_24x11_24214_24Left = heff_take_reuse_n(v_x11_24214, 1ULL, 1);
      heff_drop_rec(v_x_24207, 9);
      heff_drop_rec(v_o_24206, 9);
      heff_drop_rec(v_c_24210, 9);
      return heff_tag_at_n(v_ru_24x1_24213_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_24214_24Left, TAG_Left, 1, (V[]){v_e_24216}), v_st_24215});
    }
    case TAG_Right: {
      V v_x_24217 = heff_field(v_x11_24214, 0);
      V v_ru_24x11_24214_24Right = heff_take_reuse_n(v_x11_24214, 1ULL, 1);
      V v_t_24218 = heff_tag_n(TAG_ENamed, 2, (V[]){heff_get_n(v_x_24207, 1, 9), v_x_24217});
      V v_t_24219 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_o_24206, 3, 9), heff_get_n(v_c_24210, 4, 9)});
      V v_t_24220 = heff_tag_at_n(v_ru_24x11_24214_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24218, v_t_24219})});
      return heff_tag_at_n(v_ru_24x1_24213_24MkPair, TAG_MkPair, 2, (V[]){v_t_24220, v_st_24215});
    }
    default: return heff_nomatch(v_x11_24214);
    }
  }
  default: return heff_nomatch(v_x1_24213);
  }
}
V g_heff_2esyntax_2esurface_2eexprL_lam8(V self, V *args) {
  V v_m_24203 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_r_24204 = v_r_240;
  V v_x2_24205 = v_m_24203;
  switch (heff_tag_of(v_x2_24205)) {
  case TAG_Named: {
    V v_o_24206 = heff_field(v_x2_24205, 0);
    V v_x_24207 = heff_field(v_x2_24205, 1);
    V v_e_24209 = heff_field(v_x2_24205, 3);
    V v_c_24210 = heff_field(v_x2_24205, 4);
    heff_take_n(v_x2_24205, 27ULL, 5);
    V v_m_24211 = heff_tr(heff_call(heff_get_n(v_r_24204, 0, 3), 1, (V[]){v_e_24209}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2eexprL_lam9, 1, 4, (V[]){v_m_24211, v_x_24207, v_o_24206, v_c_24210});
  }
  default: {
    V f_ = heff_get_n(v_r_24204, 0, 3);
    args[0] = v_x2_24205;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  }
}
V g_heff_2esyntax_2esurface_2eexprL_lam11(V self, V *args) {
  V v_st_24245 = args[0];
  V v_m_24244 = heff_env(self)[0];
  V v_op_24242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24246 = heff_tr(heff_call(v_m_24244, 1, (V[]){v_st_24245}));
  switch (heff_tag_of(v_x1_24246)) {
  case TAG_MkPair: {
    V v_x11_24247 = heff_field(v_x1_24246, 0);
    V v_st_24248 = heff_field(v_x1_24246, 1);
    V v_ru_24x1_24246_24MkPair = heff_take_reuse_n(v_x1_24246, 3ULL, 2);
    switch (heff_tag_of(v_x11_24247)) {
    case TAG_Left: {
      V v_e_24249 = heff_field(v_x11_24247, 0);
      V v_ru_24x11_24247_24Left = heff_take_reuse_n(v_x11_24247, 1ULL, 1);
      heff_drop(v_op_24242);
      return heff_tag_at_n(v_ru_24x1_24246_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_24247_24Left, TAG_Left, 1, (V[]){v_e_24249}), v_st_24248});
    }
    case TAG_Right: {
      V v_x_24250 = heff_field(v_x11_24247, 0);
      V v_ru_24x11_24247_24Right = heff_take_reuse_n(v_x11_24247, 1ULL, 1);
      V v_t_24251 = heff_tag_at_n(v_ru_24x11_24247_24Right, TAG_Right, 1, (V[]){heff_rec_n(2, shape_op__e, (V[]){v_op_24242, v_x_24250})});
      return heff_tag_at_n(v_ru_24x1_24246_24MkPair, TAG_MkPair, 2, (V[]){v_t_24251, v_st_24248});
    }
    default: return heff_nomatch(v_x11_24247);
    }
  }
  default: return heff_nomatch(v_x1_24246);
  }
}
V g_heff_2esyntax_2esurface_2eexprL_lam12(V self, V *args) {
  V v_st_24254 = args[0];
  V v_m_24253 = heff_env(self)[0];
  V v_op_24252 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24255 = heff_tr(heff_call(v_m_24253, 1, (V[]){v_st_24254}));
  switch (heff_tag_of(v_x1_24255)) {
  case TAG_MkPair: {
    V v_x11_24256 = heff_field(v_x1_24255, 0);
    V v_st_24257 = heff_field(v_x1_24255, 1);
    V v_ru_24x1_24255_24MkPair = heff_take_reuse_n(v_x1_24255, 3ULL, 2);
    switch (heff_tag_of(v_x11_24256)) {
    case TAG_Left: {
      V v_e_24258 = heff_field(v_x11_24256, 0);
      V v_ru_24x11_24256_24Left = heff_take_reuse_n(v_x11_24256, 1ULL, 1);
      heff_drop(v_op_24252);
      return heff_tag_at_n(v_ru_24x1_24255_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_24256_24Left, TAG_Left, 1, (V[]){v_e_24258}), v_st_24257});
    }
    case TAG_Right: {
      V v_x_24259 = heff_field(v_x11_24256, 0);
      V v_ru_24x11_24256_24Right = heff_take_reuse_n(v_x11_24256, 1ULL, 1);
      V v_t_24260 = heff_tag_at_n(v_ru_24x11_24256_24Right, TAG_Right, 1, (V[]){heff_rec_n(2, shape_op__e, (V[]){v_op_24252, v_x_24259})});
      return heff_tag_at_n(v_ru_24x1_24255_24MkPair, TAG_MkPair, 2, (V[]){v_t_24260, v_st_24257});
    }
    default: return heff_nomatch(v_x11_24256);
    }
  }
  default: return heff_nomatch(v_x1_24255);
  }
}
V g_heff_2esyntax_2esurface_2eexprL_lam10(V self, V *args) {
  V v_m_24239 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_r_24240 = v_r_240;
  V v_m_24241 = v_m_24239;
  switch (heff_tag_of(v_m_24241)) {
  case TAG_OpRhs: {
    V v_op_24242 = heff_field(v_m_24241, 0);
    V v_e_24243 = heff_field(v_m_24241, 1);
    heff_take_n(v_m_24241, 3ULL, 2);
    V v_m_24244 = heff_tr(heff_call(heff_get_n(v_r_24240, 0, 3), 1, (V[]){v_e_24243}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2eexprL_lam11, 1, 2, (V[]){v_m_24244, v_op_24242});
  }
  default: {
    V v_op_24252 = (g_heff_2esyntax_2ecst_2efirstE(v_m_24241));
    V v_m_24253 = heff_tr(heff_call(heff_get_n(v_r_24240, 0, 3), 1, (V[]){v_m_24241}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2eexprL_lam12, 1, 2, (V[]){v_m_24253, v_op_24252});
  }
  }
}
V g_heff_2esyntax_2esurface_2eexprL_lam13(V self, V *args) {
  V v_b_24321 = args[0];
  V v_r_24318 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2esyntax_2esurface_2elamBinderL(v_r_24318, v_b_24321));
}
V g_heff_2esyntax_2esurface_2eexprL_lam14(V self, V *args) {
  V v_st_24330 = args[0];
  V v_m_24329 = heff_env(self)[0];
  V v_x_24327 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24331 = heff_tr(heff_call(v_m_24329, 1, (V[]){v_st_24330}));
  switch (heff_tag_of(v_x1_24331)) {
  case TAG_MkPair: {
    V v_x11_24332 = heff_field(v_x1_24331, 0);
    V v_st_24333 = heff_field(v_x1_24331, 1);
    V v_ru_24x1_24331_24MkPair = heff_take_reuse_n(v_x1_24331, 3ULL, 2);
    switch (heff_tag_of(v_x11_24332)) {
    case TAG_Left: {
      V v_e_24334 = heff_field(v_x11_24332, 0);
      V v_ru_24x11_24332_24Left = heff_take_reuse_n(v_x11_24332, 1ULL, 1);
      heff_drop(v_x_24327);
      return heff_tag_at_n(v_ru_24x1_24331_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_24332_24Left, TAG_Left, 1, (V[]){v_e_24334}), v_st_24333});
    }
    case TAG_Right: {
      V v_x_24335 = heff_field(v_x11_24332, 0);
      V v_ru_24x11_24332_24Right = heff_take_reuse_n(v_x11_24332, 1ULL, 1);
      V v_x_24336 = (g_heff_2esyntax_2esurface_2efoldr_24s503335349x1048908132(v_x_24335, v_x_24327));
      return heff_tag_at_n(v_ru_24x1_24331_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_24332_24Right, TAG_Right, 1, (V[]){v_x_24336}), v_st_24333});
    }
    default: return heff_nomatch(v_x11_24332);
    }
  }
  default: return heff_nomatch(v_x1_24331);
  }
}
V g_heff_2esyntax_2esurface_2eexprL_lam15(V self, V *args) {
  V v_a_24347 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_r_240; V a_1 = v_a_24347; V r_ = (g_heff_2esyntax_2esurface_2ealtL(a_0, a_1)); heff_drop(v_a_24347); r_; });
}
V g_heff_2esyntax_2esurface_2eexprL_lam16(V self, V *args) {
  V v_alts_27_24349 = args[0];
  V v_z_24350 = args[1];
  V v_e0_241 = heff_env(self)[0];
  V v_kw_24337 = heff_env(self)[1];
  V v_x_24346 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_24351 = (g_list_2efoldl_24s1422286737x1936996242(NTAG(TAG_Nil), heff_dup(v_alts_27_24349)));
  V v_sps_24352 = v_t_24351;
  V v_s_24353 = v_z_24350;
  V v_known_24354 = heff_take_field(v_s_24353, 2);
  V v_binders_24355 = heff_take_field(v_s_24353, 3);
  V v_patVars_24356 = heff_take_field(v_s_24353, 4);
  V v_fix_24357 = heff_take_field(v_s_24353, 5);
  V v_lenient_24358 = heff_take_field(v_s_24353, 6);
  V v_at_24359 = heff_take_field(v_s_24353, 7);
  V v_knot_24360 = heff_take_field(v_s_24353, 8);
  V v_arms_24361 = (g_heff_2esyntax_2esurface_2eappendS(v_sps_24352, heff_take_field(v_s_24353, 9)));
  V v_st_24362 = ({ V rv_2 = v_known_24354; V rv_3 = v_binders_24355; V rv_4 = v_patVars_24356; V rv_5 = v_fix_24357; V rv_6 = v_lenient_24358; V rv_7 = v_at_24359; V rv_8 = v_knot_24360; V rv_9 = v_arms_24361; V rr_ = heff_rec_reuse_nf(v_s_24353, 3ULL, 10, shape_toks__scope__known__binders__patVars__fix__lenient__at__knot__arms, 15u, 0u); heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; heff_rfield(rr_, 5) = rv_5; heff_rfield(rr_, 6) = rv_6; heff_rfield(rr_, 7) = rv_7; heff_rfield(rr_, 8) = rv_8; heff_rfield(rr_, 9) = rv_9; rr_; });
  V v_t_24363 = (g_heff_2esyntax_2ecst_2elastE(v_e0_241));
  V v_e_24364 = heff_get_n(v_t_24363, 4, 9);
  V v_t_24365 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_24337, 3, 9), v_e_24364});
  V v_x_24366 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_x_24346, v_alts_27_24349}), v_t_24365});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24366}), v_st_24362});
}
V g_heff_2esyntax_2esurface_2eexprL_lam17(V self, V *args) {
  V v_m_24417 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2esyntax_2esurface_2estmtL(v_r_240, v_m_24417));
}
V g_heff_2esyntax_2esurface_2eexprL_lam18(V self, V *args) {
  V v_stmts_27_24419 = args[0];
  V v_z_24420 = args[1];
  V v_e0_241 = heff_env(self)[0];
  V v_kw_24415 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24421 = (g_heff_2esyntax_2ecst_2elastE(v_e0_241));
  V v_e_24422 = heff_get_n(v_t_24421, 4, 9);
  V v_t_24423 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_24415, 3, 9), v_e_24422});
  V v_x_24424 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EDo, 1, (V[]){v_stmts_27_24419}), v_t_24423});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24424}), v_z_24420});
}
V g_heff_2esyntax_2esurface_2eexprL_lam19(V self, V *args) {
  V v_m_24457 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2esyntax_2esurface_2estmtL(v_r_240, v_m_24457));
}
V g_heff_2esyntax_2esurface_2eexprL_lam20(V self, V *args) {
  V v_body_27_24459 = args[0];
  V v_z_24460 = args[1];
  V v_e0_241 = heff_env(self)[0];
  V v_kw_24447 = heff_env(self)[1];
  V v_x_24456 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_24461 = (g_heff_2esyntax_2ecst_2elastE(v_e0_241));
  V v_e_24462 = heff_get_n(v_t_24461, 4, 9);
  V v_t_24463 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_24447, 3, 9), v_e_24462});
  V v_x_24464 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EWhile, 2, (V[]){v_x_24456, v_body_27_24459}), v_t_24463});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24464}), v_z_24460});
}
V g_heff_2esyntax_2esurface_2eexprL_lam21(V self, V *args) {
  V v_m_24484 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2esyntax_2esurface_2estmtL(v_r_240, v_m_24484));
}
V g_heff_2esyntax_2esurface_2eexprL_lam22(V self, V *args) {
  V v_st_24565 = args[0];
  V v_t_24566 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24566, v_st_24565});
}
V g_heff_2esyntax_2esurface_2eexprL_lam23(V self, V *args) {
  V v_st_24577 = args[0];
  V v_m_24576 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_24578 = heff_tr(heff_call(v_m_24576, 1, (V[]){v_st_24577}));
  switch (heff_tag_of(v_x1_24578)) {
  case TAG_MkPair: {
    V v_x11_24579 = heff_field(v_x1_24578, 0);
    V v_st_24580 = heff_field(v_x1_24578, 1);
    V v_ru_24x1_24578_24MkPair = heff_take_reuse_n(v_x1_24578, 3ULL, 2);
    switch (heff_tag_of(v_x11_24579)) {
    case TAG_Left: {
      V v_e_24581 = heff_field(v_x11_24579, 0);
      V v_ru_24x11_24579_24Left = heff_take_reuse_n(v_x11_24579, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_24578_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_24579_24Left, TAG_Left, 1, (V[]){v_e_24581}), v_st_24580});
    }
    case TAG_Right: {
      V v_x_24582 = heff_field(v_x11_24579, 0);
      V v_ru_24x11_24579_24Right = heff_take_reuse_n(v_x11_24579, 1ULL, 1);
      V v_t_24583 = heff_tag_at_n(v_ru_24x11_24579_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Just, 1, (V[]){v_x_24582})});
      return heff_tag_at_n(v_ru_24x1_24578_24MkPair, TAG_MkPair, 2, (V[]){v_t_24583, v_st_24580});
    }
    default: return heff_nomatch(v_x11_24579);
    }
  }
  default: return heff_nomatch(v_x1_24578);
  }
}
V g_heff_2esyntax_2esurface_2eexprL_lam24(V self, V *args) {
  V v_st_24584 = args[0];
  V v_start_24574 = heff_env(self)[0];
  V v_end_24575 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24585 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2eexprL_str19)}), heff_rec_n(2, shape_start__end, (V[]){v_start_24574, v_end_24575})});
  V v_t_24586 = heff_tag_n(TAG_Right, 1, (V[]){heff_tag_n(TAG_Just, 1, (V[]){v_t_24585})});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24586, v_st_24584});
}
V g_heff_2esyntax_2esurface_2eexprL_lam25(V self, V *args) {
  V v_st_24592 = args[0];
  V v_x_24591 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24591}), v_st_24592});
}
V g_heff_2esyntax_2esurface_2eexprL_lam26(V self, V *args) {
  V v_m_24599 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2esyntax_2esurface_2estmtL(v_r_240, v_m_24599));
}
V g_heff_2esyntax_2esurface_2eexprL_lam27(V self, V *args) {
  V v_body_27_24601 = args[0];
  V v_z_24602 = args[1];
  V v_r_240 = heff_env(self)[0];
  V v_c_24562 = heff_env(self)[1];
  V v_x_24598 = heff_env(self)[2];
  V v_e0_241 = heff_env(self)[3];
  V v_kw_24559 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_m_24603 = ({ V a_0 = v_r_240; V a_1 = v_c_24562; V r_ = (g_heff_2esyntax_2esurface_2ecatchL(a_0, a_1)); heff_drop(v_c_24562); r_; });
  V v_x1_24604 = heff_tr(heff_call(v_m_24603, 1, (V[]){v_z_24602}));
  switch (heff_tag_of(v_x1_24604)) {
  case TAG_MkPair: {
    V v_x11_24605 = heff_field(v_x1_24604, 0);
    V v_st_24606 = heff_field(v_x1_24604, 1);
    V v_ru_24x1_24604_24MkPair = heff_take_reuse_n(v_x1_24604, 3ULL, 2);
    switch (heff_tag_of(v_x11_24605)) {
    case TAG_Left: {
      V v_e_24607 = heff_field(v_x11_24605, 0);
      V v_ru_24x11_24605_24Left = heff_take_reuse_n(v_x11_24605, 1ULL, 1);
      heff_drop(v_body_27_24601);
      heff_drop(v_x_24598);
      heff_drop_tag(v_e0_241, 4);
      heff_drop_rec(v_kw_24559, 9);
      return heff_tag_at_n(v_ru_24x1_24604_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_24605_24Left, TAG_Left, 1, (V[]){v_e_24607}), v_st_24606});
    }
    case TAG_Right: {
      V v_x_24608 = heff_field(v_x11_24605, 0);
      V v_ru_24x11_24605_24Right = heff_take_reuse_n(v_x11_24605, 1ULL, 1);
      V v_t_24609 = heff_tag_n(TAG_ETry, 1, (V[]){heff_tag_n(TAG_MkTry, 3, (V[]){v_x_24598, v_body_27_24601, v_x_24608})});
      V v_t_24610 = (g_heff_2esyntax_2ecst_2elastE(v_e0_241));
      V v_e_24611 = heff_get_n(v_t_24610, 4, 9);
      V v_t_24612 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_24559, 3, 9), v_e_24611});
      V v_x_24613 = heff_tag_n(TAG_At, 2, (V[]){v_t_24609, v_t_24612});
      return heff_tag_at_n(v_ru_24x1_24604_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_24605_24Right, TAG_Right, 1, (V[]){v_x_24613}), v_st_24606});
    }
    default: return heff_nomatch(v_x11_24605);
    }
  }
  default: return heff_nomatch(v_x1_24604);
  }
}
V g_heff_2esyntax_2esurface_2eexprL_lam28(V self, V *args) {
  V v_m_24631 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2esyntax_2esurface_2estmtL(v_r_240, v_m_24631));
}
V g_heff_2esyntax_2esurface_2eexprL_lam29(V self, V *args) {
  V v_m_24658 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2esyntax_2esurface_2estmtL(v_r_240, v_m_24658));
}
V g_heff_2esyntax_2esurface_2epushAll_24s44754596x1125302717_lam0(V self, V *args);
V g_heff_2esyntax_2esurface_2epushAll_24s44754596x1125302717_lam1(V self, V *args);
Clo g_heff_2esyntax_2esurface_2epushAll_24s44754596x1125302717_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2epushAll_24s44754596x1125302717_entry, 4, 0};

V g_heff_2esyntax_2esurface_2epushAll_24s44754596x1125302717(V v_fix_240, V v_lenient_241, V v_st_242, V v_x5_243) {
top: ;
  switch (heff_tag_of(v_x5_243)) {
  case TAG_Nil: {
    heff_drop(v_fix_240);
    return heff_clo_n(g_heff_2esyntax_2esurface_2epushAll_24s44754596x1125302717_lam0, 1, 1, (V[]){v_st_242});
  }
  case TAG_Cons: {
    V v_r_245 = heff_field(v_x5_243, 0);
    V v_rest_246 = heff_field(v_x5_243, 1);
    heff_take_n(v_x5_243, 3ULL, 2);
    V v_m_247 = (g_heff_2esyntax_2esurface_2epushS_24s1497306188x253922067(heff_dup(v_fix_240), v_lenient_241, v_st_242, v_r_245));
    return heff_clo_n(g_heff_2esyntax_2esurface_2epushAll_24s44754596x1125302717_lam1, 1, 4, (V[]){v_m_247, v_fix_240, heff_dup(v_lenient_241), v_rest_246});
  }
  default: return heff_nomatch(v_x5_243);
  }
}
V g_heff_2esyntax_2esurface_2epushAll_24s44754596x1125302717_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2esyntax_2esurface_2epushAll_24s44754596x1125302717(a[0], a1, a[2], a[3]); heff_drop(a1); return r;
}
V g_heff_2esyntax_2esurface_2epushAll_24s44754596x1125302717_lam0(V self, V *args) {
  V v_st_244 = args[0];
  V v_st_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_st_242}), v_st_244});
}
V g_heff_2esyntax_2esurface_2epushAll_24s44754596x1125302717_lam1(V self, V *args) {
  V v_st_248 = args[0];
  V v_m_247 = heff_env(self)[0];
  V v_fix_240 = heff_env(self)[1];
  V v_lenient_241 = heff_env(self)[2];
  V v_rest_246 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x1_249 = heff_tr(heff_call(v_m_247, 1, (V[]){v_st_248}));
  switch (heff_tag_of(v_x1_249)) {
  case TAG_MkPair: {
    V v_x11_2410 = heff_field(v_x1_249, 0);
    V v_st_2411 = heff_field(v_x1_249, 1);
    V v_ru_24x1_249_24MkPair = heff_take_reuse_n(v_x1_249, 3ULL, 2);
    switch (heff_tag_of(v_x11_2410)) {
    case TAG_Left: {
      V v_e_2412 = heff_field(v_x11_2410, 0);
      V v_ru_24x11_2410_24Left = heff_take_reuse_n(v_x11_2410, 1ULL, 1);
      heff_drop(v_fix_240);
      heff_drop(v_lenient_241);
      heff_drop(v_rest_246);
      return heff_tag_at_n(v_ru_24x1_249_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_2410_24Left, TAG_Left, 1, (V[]){v_e_2412}), v_st_2411});
    }
    case TAG_Right: {
      V v_x_2413 = heff_field(v_x11_2410, 0);
      heff_take_n(v_x11_2410, 1ULL, 1);
      heff_drop_cell(v_ru_24x1_249_24MkPair, 2);
      V v_t_2414 = ({ V a_0 = v_fix_240; V a_1 = v_lenient_241; V a_2 = v_x_2413; V a_3 = v_rest_246; V r_ = (g_heff_2esyntax_2esurface_2epushAll_24s44754596x1125302717(a_0, a_1, a_2, a_3)); heff_drop(v_lenient_241); r_; });
      V f_ = v_t_2414;
      args[0] = v_st_2411;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    default: return heff_nomatch(v_x11_2410);
    }
  }
  default: return heff_nomatch(v_x1_249);
  }
}
HEFF_LIT(g_heff_2esyntax_2esurface_2edeclNameOf_24cpr_str0, 0, "");

HeffT2 g_heff_2esyntax_2esurface_2edeclNameOf_24cpr(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return ((HeffT2){{((V)&g_heff_2esyntax_2esurface_2edeclNameOf_24cpr_str0), heff_rec_n(2, shape_start__end, (V[]){MK_INT(0LL), MK_INT(0LL)})}});
  }
  case TAG_Cons: {
    V v_t_241 = heff_field(v_x1_240, 0);
    V v_x12_242 = heff_field(v_x1_240, 1);
    V v_text_243 = heff_dup(heff_rfield(v_t_241, 1));
    V v_start_244 = heff_dup(heff_rfield(v_t_241, 3));
    V v_end_245 = heff_dup(heff_rfield(v_t_241, 4));
    switch (heff_tag_of(v_x12_242)) {
    case TAG_Nil: {
      V v_f_246 = v_text_243;
      V v_f_247 = heff_rec_n(2, shape_start__end, (V[]){v_start_244, v_end_245});
      return ((HeffT2){{v_f_246, v_f_247}});
    }
    case TAG_Cons: {
      V v_op_248 = heff_field(v_x12_242, 0);
      V v_x122_249 = heff_field(v_x12_242, 1);
      V v_text_2410 = heff_dup(heff_rfield(v_op_248, 1));
      V v_start_2411 = heff_dup(heff_rfield(v_op_248, 3));
      V v_end_2412 = heff_dup(heff_rfield(v_op_248, 4));
      switch (heff_tag_of(v_x122_249)) {
      case TAG_Nil: {
        heff_drop(v_text_2410);
        heff_drop(v_start_2411);
        heff_drop(v_end_2412);
        V v_f_2413 = v_text_243;
        V v_f_2414 = heff_rec_n(2, shape_start__end, (V[]){v_start_244, v_end_245});
        return ((HeffT2){{v_f_2413, v_f_2414}});
      }
      case TAG_Cons: {
        V v_x1222_2416 = heff_field(v_x122_249, 1);
        switch (heff_tag_of(v_x1222_2416)) {
        case TAG_Nil: {
          heff_drop(v_text_243);
          heff_drop(v_start_244);
          heff_drop(v_end_245);
          V v_f_2417 = v_text_2410;
          V v_f_2418 = heff_rec_n(2, shape_start__end, (V[]){v_start_2411, v_end_2412});
          return ((HeffT2){{v_f_2417, v_f_2418}});
        }
        case TAG_Cons: {
          heff_drop(v_text_2410);
          heff_drop(v_start_2411);
          heff_drop(v_end_2412);
          V v_f_2421 = v_text_243;
          V v_f_2422 = heff_rec_n(2, shape_start__end, (V[]){v_start_244, v_end_245});
          return ((HeffT2){{v_f_2421, v_f_2422}});
        }
        default: return ((HeffT2){{heff_nomatch(v_x1222_2416)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x122_249)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x12_242)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
Clo g_heff_2esyntax_2esurface_2erightsOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2erightsOf_entry, 1, 0};

V g_heff_2esyntax_2esurface_2erightsOf(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_Left: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Right: {
      V v_x_244 = heff_field(v_x11_241, 0);
      heff_take_n(v_x11_241, 1ULL, 1);
      V v_cell_245 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_244, heff_hole()});
      V v_u_246 = (g_heff_2esyntax_2esurface_2erightsOf_24dps(v_rest_242, heff_dup(v_cell_245)));
      heff_drop(v_u_246);
      return v_cell_245;
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2esurface_2erightsOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2erightsOf(a[0]);
}
HEFF_LIT(g_heff_2esyntax_2esurface_2eprescanGo_str0, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2esurface_2eprescanGo_str1, 6, "mutual");
HEFF_LIT(g_heff_2esyntax_2esurface_2eprescanGo_str2, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2esurface_2eprescanGo_str3, 4, "data");
HEFF_LIT(g_heff_2esyntax_2esurface_2eprescanGo_str4, 4, "type");
HEFF_LIT(g_heff_2esyntax_2esurface_2eprescanGo_str5, 6, "theory");
HEFF_LIT(g_heff_2esyntax_2esurface_2eprescanGo_str6, 8, "instance");
HEFF_LIT(g_heff_2esyntax_2esurface_2eprescanGo_str7, 3, "var");
HEFF_LIT(g_heff_2esyntax_2esurface_2eprescanGo_str8, 3, "con");
HEFF_LIT(g_heff_2esyntax_2esurface_2eprescanGo_str9, 3, "sym");
HEFF_LIT(g_heff_2esyntax_2esurface_2eprescanGo_str10, 1, ":");
HEFF_LIT(g_heff_2esyntax_2esurface_2eprescanGo_str11, 3, "var");
HEFF_LIT(g_heff_2esyntax_2esurface_2eprescanGo_str12, 3, "con");
HEFF_LIT(g_heff_2esyntax_2esurface_2eprescanGo_str13, 1, ",");
Clo g_heff_2esyntax_2esurface_2eprescanGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eprescanGo_entry, 4, 0};

V g_heff_2esyntax_2esurface_2eprescanGo(V v_ts_240, V v_box_24k_241, V v_inMutual_242, V v_acc_243) {
  int64_t v_k_241 = heff_unbox_word(v_box_24k_241);
top: ;
  if (((((int64_t)0ULL) <= v_k_241) && (v_k_241 < heff_unbox_word(heff_arrayLength_lent(v_ts_240, 0))))) {
    V v_t_244 = heff_arrayIndexIn_lent(v_ts_240, heff_box_word(v_k_241), 2);
    V v_first_245 = heff_take_field(v_t_244, 6);
    V v_col_246 = heff_take_field(v_t_244, 5);
    V v_kind_247 = heff_take_field(v_t_244, 0);
    V v_text_248 = heff_get_n(v_t_244, 1, 7);
    int64_t v_i_249 = (v_k_241 + ((int64_t)1ULL));
    if (((((int64_t)0ULL) <= v_i_249) && (v_i_249 < heff_unbox_word(heff_arrayLength_lent(v_ts_240, 0))))) {
      V v_u_2410 = heff_arrayIndexIn_lent(v_ts_240, heff_box_word(v_i_249), 2);
      V v_text_2411 = heff_take_field(v_u_2410, 1);
      V v_kind_2412 = heff_get_n(v_u_2410, 0, 7);
      if (((heff_dup(v_first_245) == NTAG(TAG_True)) && (heff_intEq_c_lent(v_col_246, MK_INT(0LL), 2) && (heff_strEq_c_lent(v_kind_247, ((V)&g_heff_2esyntax_2esurface_2eprescanGo_str0), 2) && heff_strEq_c_lent(v_text_248, ((V)&g_heff_2esyntax_2esurface_2eprescanGo_str1), 2))))) {
        heff_drop(v_inMutual_242);
        heff_drop(v_first_245);
        heff_drop(v_col_246);
        heff_drop(v_kind_247);
        heff_drop(v_text_248);
        heff_drop(v_text_2411);
        heff_drop(v_kind_2412);
        V t_0 = v_ts_240;
        int64_t t_1 = (v_k_241 + ((int64_t)1ULL));
        V t_2 = NTAG(TAG_True);
        V t_3 = v_acc_243;
        v_ts_240 = t_0;
        v_k_241 = t_1;
        v_inMutual_242 = t_2;
        v_acc_243 = t_3;
        goto top;
      } else {
        V v_t_2417;
        if ((heff_dup(v_first_245) == NTAG(TAG_True))) {
          if (heff_intEq_c_lent(v_col_246, MK_INT(0LL), 2)) {
            if (heff_strEq_c_lent(v_kind_247, ((V)&g_heff_2esyntax_2esurface_2eprescanGo_str2), 2)) {
              V v_p_2413 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(v_text_248)}));
              V v_t_2414 = heff_tr(heff_call(heff_dup(v_p_2413), 1, (V[]){((V)&g_heff_2esyntax_2esurface_2eprescanGo_str3)}));
              if ((heff_dup(v_t_2414) == NTAG(TAG_True))) {
                heff_drop(v_p_2413);
                heff_drop(v_t_2414);
                v_t_2417 = NTAG(TAG_True);
              } else {
                heff_drop(v_t_2414);
                V v_t_2415 = heff_tr(heff_call(heff_dup(v_p_2413), 1, (V[]){((V)&g_heff_2esyntax_2esurface_2eprescanGo_str4)}));
                if ((heff_dup(v_t_2415) == NTAG(TAG_True))) {
                  heff_drop(v_p_2413);
                  heff_drop(v_t_2415);
                  v_t_2417 = NTAG(TAG_True);
                } else {
                  heff_drop(v_t_2415);
                  V v_t_2416 = heff_tr(heff_call(heff_dup(v_p_2413), 1, (V[]){((V)&g_heff_2esyntax_2esurface_2eprescanGo_str5)}));
                  if ((heff_dup(v_t_2416) == NTAG(TAG_True))) {
                    heff_drop(v_p_2413);
                    heff_drop(v_t_2416);
                    v_t_2417 = NTAG(TAG_True);
                  } else {
                    heff_drop(v_t_2416);
                    v_t_2417 = heff_tr(heff_call(v_p_2413, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2eprescanGo_str6)}));
                  }
                }
              }
            } else {
              v_t_2417 = NTAG(TAG_False);
            }
          } else {
            v_t_2417 = NTAG(TAG_False);
          }
        } else {
          v_t_2417 = NTAG(TAG_False);
        }
        if ((heff_dup(v_t_2417) == NTAG(TAG_True))) {
          heff_drop(v_inMutual_242);
          heff_drop(v_first_245);
          heff_drop(v_col_246);
          heff_drop(v_kind_247);
          heff_drop(v_text_248);
          heff_drop(v_kind_2412);
          heff_drop(v_t_2417);
          V t_0 = v_ts_240;
          int64_t t_1 = (v_k_241 + ((int64_t)1ULL));
          V t_2 = NTAG(TAG_False);
          V t_3 = heff_tag_n(TAG_Cons, 2, (V[]){v_text_2411, v_acc_243});
          v_ts_240 = t_0;
          v_k_241 = t_1;
          v_inMutual_242 = t_2;
          v_acc_243 = t_3;
          goto top;
        } else {
          heff_drop(v_t_2417);
          if (((heff_dup(v_first_245) == NTAG(TAG_True)) && ((heff_intEq_c_lent(v_col_246, MK_INT(0LL), 2) || (heff_dup(v_inMutual_242) == NTAG(TAG_True))) && ((heff_strEq_c_lent(v_kind_247, ((V)&g_heff_2esyntax_2esurface_2eprescanGo_str7), 2) || heff_strEq_c_lent(v_kind_247, ((V)&g_heff_2esyntax_2esurface_2eprescanGo_str8), 2)) && (heff_strEq_c_lent(v_kind_2412, ((V)&g_heff_2esyntax_2esurface_2eprescanGo_str9), 2) && heff_strEq_c_lent(v_text_2411, ((V)&g_heff_2esyntax_2esurface_2eprescanGo_str10), 2)))))) {
            heff_drop(v_first_245);
            heff_drop(v_kind_247);
            heff_drop(v_text_2411);
            heff_drop(v_kind_2412);
            V v_t_2418 = heff_bool(((heff_dup(v_inMutual_242) == NTAG(TAG_True)) && heff_intLt_c_lent(MK_INT(0LL), v_col_246, 1)));
            heff_drop(v_inMutual_242);
            heff_drop(v_col_246);
            V t_0 = v_ts_240;
            int64_t t_1 = (v_k_241 + ((int64_t)1ULL));
            V t_2 = v_t_2418;
            V t_3 = heff_tag_n(TAG_Cons, 2, (V[]){v_text_248, v_acc_243});
            v_ts_240 = t_0;
            v_k_241 = t_1;
            v_inMutual_242 = t_2;
            v_acc_243 = t_3;
            goto top;
          } else {
            heff_drop(v_text_248);
            heff_drop(v_kind_2412);
            if (((heff_dup(v_first_245) == NTAG(TAG_True)) && ((heff_intEq_c_lent(v_col_246, MK_INT(0LL), 2) || (heff_dup(v_inMutual_242) == NTAG(TAG_True))) && ((heff_strEq_c_lent(v_kind_247, ((V)&g_heff_2esyntax_2esurface_2eprescanGo_str11), 2) || heff_strEq_c_lent(v_kind_247, ((V)&g_heff_2esyntax_2esurface_2eprescanGo_str12), 2)) && heff_strEq_c_lent(v_text_2411, ((V)&g_heff_2esyntax_2esurface_2eprescanGo_str13), 2))))) {
              heff_drop(v_first_245);
              heff_drop(v_kind_247);
              heff_drop(v_text_2411);
              V v_t_2419 = heff_bool(((heff_dup(v_inMutual_242) == NTAG(TAG_True)) && heff_intLt_c_lent(MK_INT(0LL), v_col_246, 1)));
              heff_drop(v_inMutual_242);
              heff_drop(v_col_246);
              V v_t_2420 = (g_heff_2esyntax_2esurface_2esigNamesFrom(v_ts_240, heff_box_word(v_k_241), NTAG(TAG_Nil)));
              V v_t_2421 = (g_heff_2esyntax_2esurface_2eappendS(v_t_2420, v_acc_243));
              V t_0 = v_ts_240;
              int64_t t_1 = (v_k_241 + ((int64_t)1ULL));
              V t_2 = v_t_2419;
              V t_3 = v_t_2421;
              v_ts_240 = t_0;
              v_k_241 = t_1;
              v_inMutual_242 = t_2;
              v_acc_243 = t_3;
              goto top;
            } else {
              heff_drop(v_kind_247);
              heff_drop(v_text_2411);
              V v_t_2422 = heff_bool(((heff_dup(v_inMutual_242) == NTAG(TAG_True)) && ((heff_dup(v_first_245) == NTAG(TAG_True)) ? !heff_intEq_c_lent(v_col_246, MK_INT(0LL), 2) : 1)));
              heff_drop(v_inMutual_242);
              heff_drop(v_first_245);
              heff_drop(v_col_246);
              V t_0 = v_ts_240;
              int64_t t_1 = (v_k_241 + ((int64_t)1ULL));
              V t_2 = v_t_2422;
              V t_3 = v_acc_243;
              v_ts_240 = t_0;
              v_k_241 = t_1;
              v_inMutual_242 = t_2;
              v_acc_243 = t_3;
              goto top;
            }
          }
        }
      }
    } else {
      heff_drop(v_first_245);
      heff_drop(v_col_246);
      heff_drop(v_kind_247);
      heff_drop(v_text_248);
      V t_0 = v_ts_240;
      int64_t t_1 = (v_k_241 + ((int64_t)1ULL));
      V t_2 = v_inMutual_242;
      V t_3 = v_acc_243;
      v_ts_240 = t_0;
      v_k_241 = t_1;
      v_inMutual_242 = t_2;
      v_acc_243 = t_3;
      goto top;
    }
  } else {
    heff_drop(v_inMutual_242);
    return (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_243));
  }
}
V g_heff_2esyntax_2esurface_2eprescanGo_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2esurface_2eprescanGo(a0, a[1], a[2], a[3]); heff_drop(a0); return r;
}
Clo g_heff_2esyntax_2esurface_2edropN_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2edropN_entry, 2, 0};

V g_heff_2esyntax_2esurface_2edropN(V v_n_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_n_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (heff_intLe_c_lent(v_n_240, MK_INT(0LL), 2)) {
      heff_drop(v_n_240);
      return heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_242, v_rest_243});
    } else {
      heff_drop(v_x_242);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = heff_intSub(v_n_240, MK_INT(1LL));
      V t_1 = v_rest_243;
      v_n_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2esurface_2edropN_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2edropN(a[0], a[1]);
}
V g_heff_2esyntax_2esurface_2edataL_24s2041319846x1615558476_24cpr_lam0(V self, V *args);
V g_heff_2esyntax_2esurface_2edataL_24s2041319846x1615558476_24cpr_lam1(V self, V *args);
V g_heff_2esyntax_2esurface_2edataL_24s2041319846x1615558476_24cpr_lam2(V self, V *args);

HeffT2 g_heff_2esyntax_2esurface_2edataL_24s2041319846x1615558476_24cpr(V v_d_240, V v_kw_241, V v_name_242, V v_params_243, V v_universe_244, V v_alts_245, V v_z_246) {
top: ;
  V v_start_247 = heff_take_field(v_name_242, 3);
  V v_end_248 = heff_take_field(v_name_242, 4);
  V v_text_249 = heff_get_n(v_name_242, 1, 9);
  V v_m_2410 = (g_prelude_2etraverse_24s518454301x170091462(v_params_243));
  V v_x1_2411 = heff_tr(heff_call(v_m_2410, 1, (V[]){v_z_246}));
  switch (heff_tag_of(v_x1_2411)) {
  case TAG_MkPair: {
    V v_x11_2412 = heff_field(v_x1_2411, 0);
    V v_st_2413 = heff_field(v_x1_2411, 1);
    heff_take_n(v_x1_2411, 3ULL, 2);
    switch (heff_tag_of(v_x11_2412)) {
    case TAG_Left: {
      V v_e_2414 = heff_field(v_x11_2412, 0);
      V v_ru_24x11_2412_24Left = heff_take_reuse_n(v_x11_2412, 1ULL, 1);
      heff_drop(v_d_240);
      heff_drop_rec(v_kw_241, 9);
      heff_drop(v_start_247);
      heff_drop(v_end_248);
      heff_drop(v_text_249);
      return ((HeffT2){{heff_tag_at_n(v_ru_24x11_2412_24Left, TAG_Left, 1, (V[]){v_e_2414}), v_st_2413}});
    }
    case TAG_Right: {
      V v_x_2415 = heff_field(v_x11_2412, 0);
      heff_take_n(v_x11_2412, 1ULL, 1);
      V v_t_2416 = (g_list_2emap_24s1059370217x1267747283(heff_dup(v_x_2415)));
      V v_m_2424;
      switch (heff_tag_of(v_universe_244)) {
      case TAG_Nothing: {
        v_m_2424 = heff_clo_n(g_heff_2esyntax_2esurface_2edataL_24s2041319846x1615558476_24cpr_lam0, 1, 2, (V[]){heff_dup(v_start_247), heff_dup(v_end_248)});
        break;
      }
      case TAG_Just: {
        V v_it1_2420 = heff_field(v_universe_244, 0);
        switch (heff_tag_of(v_it1_2420)) {
        case TAG_MkPair: {
          V v_u_2422 = heff_field(v_it1_2420, 1);
          v_m_2424 = heff_clo_n(g_heff_2esyntax_2esurface_2edataL_24s2041319846x1615558476_24cpr_lam1, 1, 1, (V[]){heff_dup(v_u_2422)});
          break;
        }
        default: heff_nomatch(v_it1_2420);
        }
        break;
      }
      default: heff_nomatch(v_universe_244);
      }
      return (g_heff_2esyntax_2esurface_2ewithScope_24cpr(v_t_2416, heff_clo_n(g_heff_2esyntax_2esurface_2edataL_24s2041319846x1615558476_24cpr_lam2, 1, 8, (V[]){v_m_2424, heff_dup(v_alts_245), v_d_240, v_kw_241, v_text_249, v_start_247, v_end_248, v_x_2415}), v_st_2413));
    }
    default: return ((HeffT2){{heff_nomatch(v_x11_2412)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_2411)}});
  }
}
V g_heff_2esyntax_2esurface_2edataL_24s2041319846x1615558476_24cpr_lam0(V self, V *args) {
  V v_st_2417 = args[0];
  V v_start_247 = heff_env(self)[0];
  V v_end_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2418 = heff_tag_n(TAG_EWord, 1, (V[]){NTAG(TAG_TypeWord)});
  V v_t_2419 = heff_tag_n(TAG_At, 2, (V[]){v_t_2418, heff_rec_n(2, shape_start__end, (V[]){v_start_247, v_end_248})});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2419}), v_st_2417});
}
V g_heff_2esyntax_2esurface_2edataL_24s2041319846x1615558476_24cpr_lam1(V self, V *args) {
  V v_st_2423 = args[0];
  V v_u_2422 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2esyntax_2esurface_2eexprL(heff_dup(g_heff_2esyntax_2esurface_2elw_get()), v_u_2422, v_st_2423));
}
V g_heff_2esyntax_2esurface_2edataL_24s2041319846x1615558476_24cpr_lam2(V self, V *args) {
  V v_st_2425 = args[0];
  V v_m_2424 = heff_env(self)[0];
  V v_alts_245 = heff_env(self)[1];
  V v_d_240 = heff_env(self)[2];
  V v_kw_241 = heff_env(self)[3];
  V v_text_249 = heff_env(self)[4];
  V v_start_247 = heff_env(self)[5];
  V v_end_248 = heff_env(self)[6];
  V v_x_2415 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_x1_2426 = heff_tr(heff_call(v_m_2424, 1, (V[]){v_st_2425}));
  switch (heff_tag_of(v_x1_2426)) {
  case TAG_MkPair: {
    V v_x11_2427 = heff_field(v_x1_2426, 0);
    V v_st_2428 = heff_field(v_x1_2426, 1);
    V v_ru_24x1_2426_24MkPair = heff_take_reuse_n(v_x1_2426, 3ULL, 2);
    switch (heff_tag_of(v_x11_2427)) {
    case TAG_Left: {
      V v_e_2429 = heff_field(v_x11_2427, 0);
      V v_ru_24x11_2427_24Left = heff_take_reuse_n(v_x11_2427, 1ULL, 1);
      heff_drop(v_alts_245);
      heff_drop(v_d_240);
      heff_drop_rec(v_kw_241, 9);
      heff_drop(v_text_249);
      heff_drop(v_start_247);
      heff_drop(v_end_248);
      heff_drop(v_x_2415);
      return heff_tag_at_n(v_ru_24x1_2426_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_2427_24Left, TAG_Left, 1, (V[]){v_e_2429}), v_st_2428});
    }
    case TAG_Right: {
      V v_x_2430 = heff_field(v_x11_2427, 0);
      V v_ru_24x11_2427_24Right = heff_take_reuse_n(v_x11_2427, 1ULL, 1);
      V v_t_2435;
      switch (heff_tag_of(v_alts_245)) {
      case TAG_Nothing: {
        v_t_2435 = NTAG(TAG_Nil);
        break;
      }
      case TAG_Just: {
        V v_x11_2431 = heff_field(v_alts_245, 0);
        heff_take_n(v_alts_245, 1ULL, 1);
        switch (heff_tag_of(v_x11_2431)) {
        case TAG_MkDAlts: {
          V v_alts_2433 = heff_field(v_x11_2431, 1);
          heff_take_n(v_x11_2431, 2ULL, 3);
          v_t_2435 = v_alts_2433;
          break;
        }
        default: heff_nomatch(v_x11_2431);
        }
        break;
      }
      default: heff_nomatch(v_alts_245);
      }
      V v_m_2436 = (g_prelude_2etraverse_24s1726903169x1952011622(v_t_2435));
      V v_x1_2437 = heff_tr(heff_call(v_m_2436, 1, (V[]){v_st_2428}));
      switch (heff_tag_of(v_x1_2437)) {
      case TAG_MkPair: {
        V v_x11_2438 = heff_field(v_x1_2437, 0);
        V v_st_2439 = heff_field(v_x1_2437, 1);
        V v_ru_24x1_2437_24MkPair = heff_take_reuse_n(v_x1_2437, 3ULL, 2);
        switch (heff_tag_of(v_x11_2438)) {
        case TAG_Left: {
          V v_e_2440 = heff_field(v_x11_2438, 0);
          V v_ru_24x11_2438_24Left = heff_take_reuse_n(v_x11_2438, 1ULL, 1);
          heff_drop(v_d_240);
          heff_drop_rec(v_kw_241, 9);
          heff_drop(v_text_249);
          heff_drop(v_start_247);
          heff_drop(v_end_248);
          heff_drop(v_x_2415);
          heff_drop(v_x_2430);
          heff_drop_cell(v_ru_24x11_2427_24Right, 1);
          heff_drop_cell(v_ru_24x1_2437_24MkPair, 2);
          return heff_tag_at_n(v_ru_24x1_2426_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_2438_24Left, TAG_Left, 1, (V[]){v_e_2440}), v_st_2439});
        }
        case TAG_Right: {
          V v_x_2441 = heff_field(v_x11_2438, 0);
          V v_ru_24x11_2438_24Right = heff_take_reuse_n(v_x11_2438, 1ULL, 1);
          V v_t_2442 = (g_heff_2esyntax_2ecst_2elastD(heff_dup(v_d_240)));
          V v_e_2443 = heff_get_n(v_t_2442, 4, 9);
          V v_t_2444 = heff_rec_n(2, shape_start__end, (V[]){heff_dup(heff_rfield(v_kw_241, 3)), v_e_2443});
          V v_t_2445 = heff_tag_at_n(v_ru_24x1_2437_24MkPair, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_2438_24Right, TAG_ESum, 1, (V[]){v_x_2441}), v_t_2444});
          V v_t_2446 = heff_tag_n(TAG_DeclDefine, 5, (V[]){v_text_249, heff_rec_n(2, shape_start__end, (V[]){v_start_247, v_end_248}), v_x_2415, v_x_2430, v_t_2445});
          V v_t_2447 = (g_heff_2esyntax_2ecst_2elastD(v_d_240));
          V v_e_2448 = heff_get_n(v_t_2447, 4, 9);
          V v_t_2449 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_241, 3, 9), v_e_2448});
          V v_t_2450 = heff_tag_n(TAG_Whole, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2446, v_t_2449})});
          V v_x_2451 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2450, NTAG(TAG_Nil)});
          return heff_tag_at_n(v_ru_24x1_2426_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_2427_24Right, TAG_Right, 1, (V[]){v_x_2451}), v_st_2439});
        }
        default: return heff_nomatch(v_x11_2438);
        }
      }
      default: return heff_nomatch(v_x1_2437);
      }
    }
    default: return heff_nomatch(v_x11_2427);
    }
  }
  default: return heff_nomatch(v_x1_2426);
  }
}
Clo g_heff_2esyntax_2esurface_2eappendS_24tok2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eappendS_24tok2_entry, 3, 0};

V g_heff_2esyntax_2esurface_2eappendS_24tok2(V v_tok_240, V v_x1_241, V v_ys_242) {
top: ;
  switch (heff_tag_of(v_x1_241)) {
  case TAG_Nil: {
    heff_drop_cell(v_tok_240, 2);
    return v_ys_242;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x1_241, 0);
    V v_xs_244 = heff_field(v_x1_241, 1);
    heff_take_n(v_x1_241, 3ULL, 2);
    V v_cell_245 = heff_tag_at_n(v_tok_240, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
    V v_u_246 = (g_heff_2esyntax_2esurface_2eappendS_24dps(v_xs_244, v_ys_242, heff_dup(v_cell_245)));
    heff_drop(v_u_246);
    return v_cell_245;
  }
  default: return heff_nomatch(v_x1_241);
  }
}
V g_heff_2esyntax_2esurface_2eappendS_24tok2_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2eappendS_24tok2(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2esyntax_2esurface_2eparamOf_24tok1_str0, 42, "a parameter is `a`, `(x : T)` or `{x : T}`");
Clo g_heff_2esyntax_2esurface_2eparamOf_24tok1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eparamOf_24tok1_entry, 3, 0};

V g_heff_2esyntax_2esurface_2eparamOf_24tok1(V v_tok_240, V v_p_241, V v_z_242) {
top: ;
  HeffT2 v_t_243 = (g_heff_2esyntax_2esurface_2enameAnn_24cpr(v_p_241));
  {
    V v_field_245 = v_t_243.f[1];
    int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
    if ((v_tag_244 == ((int64_t)0ULL))) {
      V v_q_246 = v_field_245;
      V v_name_247 = heff_take_field(v_q_246, 0);
      V v_span_248 = heff_take_field(v_q_246, 1);
      V v_ty_249 = heff_get_n(v_q_246, 2, 3);
      V v_t_2412;
      switch (heff_tag_of(v_ty_249)) {
      case TAG_At: {
        V v_s_2411 = heff_dup(heff_field(v_ty_249, 1));
        v_t_2412 = v_s_2411;
        break;
      }
      default: heff_nomatch(v_ty_249);
      }
      V v_t_2413 = ({ V rv_0 = heff_dup(heff_rfield(v_span_248, 0)); V rr_ = heff_rec_reuse_nf(v_t_2412, 2ULL, 2, shape_start__end, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
      V v_t_2414 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ExplicitParam, 3, (V[]){v_name_247, v_span_248, v_ty_249}), v_t_2413});
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_tok_240, TAG_Right, 1, (V[]){v_t_2414}), v_z_242});
    } else {
      heff_drop(v_field_245);
      V v_t_2417;
      switch (heff_tag_of(v_p_241)) {
      case TAG_At: {
        V v_s_2416 = heff_field(v_p_241, 1);
        v_t_2417 = heff_dup(v_s_2416);
        break;
      }
      default: heff_nomatch(v_p_241);
      }
      V v_t_2418 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2eparamOf_24tok1_str0), v_t_2417, NTAG(TAG_Nothing)});
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_tok_240, TAG_Left, 1, (V[]){v_t_2418}), v_z_242});
    }
  }
}
V g_heff_2esyntax_2esurface_2eparamOf_24tok1_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2esyntax_2esurface_2eparamOf_24tok1(a[0], a1, a[2]); heff_drop(a1); return r;
}