// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Ann 13421
#define TAG_App 13485
#define TAG_At 8900
#define TAG_Atom 28502
#define TAG_BAnn 9252
#define TAG_BImp 16911
#define TAG_BVar 29034
#define TAG_Braces 8205
#define TAG_Case 4415
#define TAG_Do 8988
#define TAG_EAlt 33043
#define TAG_EAnn 33099
#define TAG_EBinary 42634
#define TAG_ECon 35052
#define TAG_EDo 15964
#define TAG_EFDefault 38038
#define TAG_EFSet 34673
#define TAG_EField 26142
#define TAG_EInvalid 31081
#define TAG_ELet 43397
#define TAG_ELetIn 22786
#define TAG_EMatch 41631
#define TAG_ENeg 45306
#define TAG_EParen 58248
#define TAG_ESBind 62182
#define TAG_ESum 50613
#define TAG_ETag 50948
#define TAG_EUSet 22856
#define TAG_EUpdate 6986
#define TAG_EVar 52881
#define TAG_If 9134
#define TAG_InstB 37114
#define TAG_IntValue 62477
#define TAG_Lam 23588
#define TAG_Left 13886
#define TAG_MkAlt 55173
#define TAG_MkFields 41650
#define TAG_MkSegment 38079
#define TAG_Named 2049
#define TAG_Op 9330
#define TAG_OpRhs 36076
#define TAG_Ops 26942
#define TAG_OtherValue 43098
#define TAG_Right 62770
#define TAG_SError 24172
#define TAG_Seg 30433
#define TAG_SegmentBinary 41188
#define TAG_SegmentInteger 22664
#define TAG_SizeDefault 11444
#define TAG_StrValue 22621
#define TAG_Sum 30935
#define TAG_Tup 31899
#define TAG_Update 40810
#define LBL_code 9554612
#define LBL_e 319
#define LBL_end 310101
#define LBL_kind 9787483
#define LBL_little 844663329
#define LBL_msg 317947
#define LBL_note 9882809
#define LBL_op 10312
#define LBL_ops 319788
#define LBL_out 319944
#define LBL_severity 75955546
#define LBL_signed 1044674119
#define LBL_size 10026184
#define LBL_span 10032145
#define LBL_start 311115900
#define LBL_text 10052084
#define LBL_ty 10476
static uint32_t shape_code__severity__msg__span__note[] = {LBL_code, LBL_severity, LBL_msg, LBL_span, LBL_note};
static uint32_t shape_op__e[] = {LBL_op, LBL_e};
static uint32_t shape_ops__out[] = {LBL_ops, LBL_out};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
static uint32_t shape_ty__size__little__signed[] = {LBL_ty, LBL_size, LBL_little, LBL_signed};
V g_heff_2esyntax_2ecst_2efirstE(V);
V g_heff_2esyntax_2ecst_2efirstE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2efirstE_clo;
V g_heff_2esyntax_2ecst_2elastE(V);
V g_heff_2esyntax_2ecst_2elastE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2elastE_clo;
V g_heff_2esyntax_2epresyntax_2eapp(V, V);
V g_heff_2esyntax_2epresyntax_2eapp_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eapp_clo;
V g_heff_2esyntax_2esurface_2ealtL(V, V);
V g_heff_2esyntax_2esurface_2ealtL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ealtL_clo;
V g_heff_2esyntax_2esurface_2eapplyOp(V, V, V);
V g_heff_2esyntax_2esurface_2eapplyOp_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eapplyOp_clo;
V g_heff_2esyntax_2esurface_2eargL(V, V);
V g_heff_2esyntax_2esurface_2eargL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eargL_clo;
V g_heff_2esyntax_2esurface_2eatomTok(V);
V g_heff_2esyntax_2esurface_2eatomTok_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eatomTok_clo;
V g_heff_2esyntax_2esurface_2eblock(V, V, V);
V g_heff_2esyntax_2esurface_2eblock_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eblock_clo;
V g_heff_2esyntax_2esurface_2ebracesL(V, V, V, V, V);
V g_heff_2esyntax_2esurface_2ebracesL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ebracesL_clo;
V g_heff_2esyntax_2esurface_2echeckBinary_24s239798054x1083465754(V, V, V);
V g_heff_2esyntax_2esurface_2echeckBinary_24s239798054x1083465754_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2echeckBinary_24s239798054x1083465754_clo;
V g_heff_2esyntax_2esurface_2ecommentLinesFrom(V, V, V);
V g_heff_2esyntax_2esurface_2ecommentLinesFrom_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ecommentLinesFrom_clo;
V g_heff_2esyntax_2esurface_2econAtom(V, V, V);
V g_heff_2esyntax_2esurface_2econAtom_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2econAtom_clo;
V g_heff_2esyntax_2esurface_2econL(V, V, V);
V g_heff_2esyntax_2esurface_2econL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2econL_clo;
V g_heff_2esyntax_2esurface_2edeclarationL(V, V);
V g_heff_2esyntax_2esurface_2edeclarationL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2edeclarationL_clo;
V g_heff_2esyntax_2esurface_2edefaultL(V, V);
V g_heff_2esyntax_2esurface_2edefaultL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2edefaultL_clo;
V g_heff_2esyntax_2esurface_2eexprL(V, V, V);
V g_heff_2esyntax_2esurface_2eexprL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eexprL_clo;
V g_heff_2esyntax_2esurface_2efieldsOf(V, V);
V g_heff_2esyntax_2esurface_2efieldsOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2efieldsOf_clo;
V g_heff_2esyntax_2esurface_2efirstS(V, V, V, V);
V g_heff_2esyntax_2esurface_2efirstS_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2efirstS_clo;
V g_heff_2esyntax_2esurface_2efoldr(V, V, V);
V g_heff_2esyntax_2esurface_2efoldr_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2efoldr_clo;
V g_heff_2esyntax_2esurface_2eifE(V, V, V, V);
V g_heff_2esyntax_2esurface_2eifE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eifE_clo;
V g_heff_2esyntax_2esurface_2eintegerChecks_24s2046200185x2026207419(V, V, V, V);
V g_heff_2esyntax_2esurface_2eintegerChecks_24s2046200185x2026207419_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eintegerChecks_24s2046200185x2026207419_clo;
V g_heff_2esyntax_2esurface_2ekwAtom(V, V, V);
V g_heff_2esyntax_2esurface_2ekwAtom_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ekwAtom_clo;
V g_heff_2esyntax_2esurface_2elambdaL(V, V, V, V);
V g_heff_2esyntax_2esurface_2elambdaL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2elambdaL_clo;
V g_heff_2esyntax_2esurface_2eletBodyL(V, V, V, V, V, V);
V g_heff_2esyntax_2esurface_2eletBodyL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eletBodyL_clo;
V g_heff_2esyntax_2esurface_2eletL(V, V, V);
V g_heff_2esyntax_2esurface_2eletL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eletL_clo;
V g_heff_2esyntax_2esurface_2eopL(V, V, V, V, V);
V g_heff_2esyntax_2esurface_2eopL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eopL_clo;
V g_heff_2esyntax_2esurface_2eopRhsOf(V);
V g_heff_2esyntax_2esurface_2eopRhsOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eopRhsOf_clo;
V g_heff_2esyntax_2esurface_2eparenL(V, V, V, V, V);
V g_heff_2esyntax_2esurface_2eparenL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eparenL_clo;
V g_heff_2esyntax_2esurface_2epushS_24s1868233564x1858628873(V, V, V, V);
V g_heff_2esyntax_2esurface_2epushS_24s1868233564x1858628873_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2epushS_24s1868233564x1858628873_clo;
V g_heff_2esyntax_2esurface_2eresolve_24s1832151779x1448561609(V, V, V);
V g_heff_2esyntax_2esurface_2eresolve_24s1832151779x1448561609_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eresolve_24s1832151779x1448561609_clo;
V g_heff_2esyntax_2esurface_2esegmentL(V, V);
V g_heff_2esyntax_2esurface_2esegmentL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2esegmentL_clo;
V g_heff_2esyntax_2esurface_2esegmentOf_24s1547151193x813882637(V, V, V, V);
V g_heff_2esyntax_2esurface_2esegmentOf_24s1547151193x813882637_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2esegmentOf_24s1547151193x813882637_clo;
V g_heff_2esyntax_2esurface_2especWord(V, V, V);
V g_heff_2esyntax_2esurface_2especWord_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2especWord_clo;
V g_heff_2esyntax_2esurface_2estmtL(V, V);
V g_heff_2esyntax_2esurface_2estmtL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2estmtL_clo;
V g_heff_2esyntax_2esurface_2etraverseS(V, V);
V g_heff_2esyntax_2esurface_2etraverseS_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2etraverseS_clo;
V g_heff_2esyntax_2esurface_2eupdateSettingL(V, V);
V g_heff_2esyntax_2esurface_2eupdateSettingL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eupdateSettingL_clo;
V g_heff_2esyntax_2esurface_2evariantL(V, V);
V g_heff_2esyntax_2esurface_2evariantL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2evariantL_clo;
V g_heff_2esyntax_2esurface_2ewithScope(V, V, V);
V g_heff_2esyntax_2esurface_2ewithScope_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ewithScope_clo;
V g_list_2emap_24s513201124x806973253(V);
V g_list_2emap_24s513201124x806973253_entry(V self, V *a);
extern Clo g_list_2emap_24s513201124x806973253_clo;
V g_prelude_2eskipSpaces(V, V, V);
V g_prelude_2eskipSpaces_entry(V self, V *a);
extern Clo g_prelude_2eskipSpaces_clo;
V g_prelude_2estrFind(V, V, V);
V g_prelude_2estrFind_entry(V self, V *a);
extern Clo g_prelude_2estrFind_clo;
HEFF_LIT(g_heff_2esyntax_2esurface_2ecommentLinesFrom_str0, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecommentLinesFrom_str1, 2, "--");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecommentLinesFrom_str2, 1, "\012");
Clo g_heff_2esyntax_2esurface_2ecommentLinesFrom_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2ecommentLinesFrom_entry, 3, 0};

V g_heff_2esyntax_2esurface_2ecommentLinesFrom(V v_src_240, V v_i_241, V v_to_242) {
top: ;
  if (heff_intLe_c(heff_dup(v_to_242), heff_dup(v_i_241))) {
    heff_drop(v_src_240);
    heff_drop(v_i_241);
    heff_drop(v_to_242);
    return NTAG(TAG_True);
  } else {
    V v_j_244 = (g_prelude_2estrFind(((V)&g_heff_2esyntax_2esurface_2ecommentLinesFrom_str0), heff_dup(v_src_240), heff_dup(v_i_241)));
    V v_t_246;
    if (heff_intLt_c(heff_dup(v_j_244), MK_INT(0LL))) {
      heff_drop(v_j_244);
      v_t_246 = heff_strLength_lent(v_src_240, 0);
    } else {
      v_t_246 = v_j_244;
    }
    V v_s_247 = heff_strSlice_lent(v_src_240, v_i_241, v_t_246, 4);
    V v_t_248 = (g_prelude_2eskipSpaces(heff_dup(v_s_247), MK_INT(0LL), MK_INT(1LL)));
    V v_t_249 = heff_intSub(heff_strLength_lent(v_s_247, 0), MK_INT(1LL));
    V v_t_2410 = (g_prelude_2eskipSpaces(heff_dup(v_s_247), v_t_249, MK_INT(-1LL)));
    V v_s_2411 = heff_strSlice(v_s_247, v_t_248, heff_intAdd(v_t_2410, MK_INT(1LL)));
    if (heff_strEq_c(heff_strSlice(v_s_2411, MK_INT(0LL), MK_INT(2LL)), ((V)&g_heff_2esyntax_2esurface_2ecommentLinesFrom_str1))) {
      V v_j_2413 = (g_prelude_2estrFind(((V)&g_heff_2esyntax_2esurface_2ecommentLinesFrom_str2), heff_dup(v_src_240), v_i_241));
      V v_t_2415;
      if (heff_intLt_c(heff_dup(v_j_2413), MK_INT(0LL))) {
        heff_drop(v_j_2413);
        v_t_2415 = heff_strLength_lent(v_src_240, 0);
      } else {
        v_t_2415 = v_j_2413;
      }
      V t_0 = v_src_240;
      V t_1 = heff_intAdd(v_t_2415, MK_INT(1LL));
      V t_2 = v_to_242;
      v_src_240 = t_0;
      v_i_241 = t_1;
      v_to_242 = t_2;
      goto top;
    } else {
      heff_drop(v_src_240);
      heff_drop(v_i_241);
      heff_drop(v_to_242);
      return NTAG(TAG_False);
    }
  }
}
V g_heff_2esyntax_2esurface_2ecommentLinesFrom_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2ecommentLinesFrom(a[0], a[1], a[2]);
}
V g_heff_2esyntax_2esurface_2eletBodyL_lam0(V self, V *args);
Clo g_heff_2esyntax_2esurface_2eletBodyL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eletBodyL_entry, 6, 0};

V g_heff_2esyntax_2esurface_2eletBodyL(V v_r_240, V v_kw_241, V v_x3_242, V v_names_243, V v_body_244, V v_z_245) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_MkPair: {
    V v_p_246 = heff_field(v_x3_242, 0);
    V v_rhs_247 = heff_field(v_x3_242, 1);
    heff_take_n(v_x3_242, 3ULL, 2);
    V v_m_248 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_body_244)}));
    return (g_heff_2esyntax_2esurface_2ewithScope(v_names_243, heff_clo_n(g_heff_2esyntax_2esurface_2eletBodyL_lam0, 1, 5, (V[]){v_m_248, v_p_246, v_body_244, v_kw_241, v_rhs_247}), v_z_245));
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2esyntax_2esurface_2eletBodyL_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2eletBodyL(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2esyntax_2esurface_2eletBodyL_lam0(V self, V *args) {
  V v_st_249 = args[0];
  V v_m_248 = heff_env(self)[0];
  V v_p_246 = heff_env(self)[1];
  V v_body_244 = heff_env(self)[2];
  V v_kw_241 = heff_env(self)[3];
  V v_rhs_247 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_x1_2410 = heff_tr(heff_call(v_m_248, 1, (V[]){v_st_249}));
  switch (heff_tag_of(v_x1_2410)) {
  case TAG_MkPair: {
    V v_x11_2411 = heff_field(v_x1_2410, 0);
    V v_st_2412 = heff_field(v_x1_2410, 1);
    V v_ru_24x1_2410_24MkPair = heff_take_reuse_n(v_x1_2410, 3ULL, 2);
    switch (heff_tag_of(v_x11_2411)) {
    case TAG_Left: {
      V v_e_2413 = heff_field(v_x11_2411, 0);
      heff_take_n(v_x11_2411, 1ULL, 1);
      heff_drop(v_p_246);
      heff_drop(v_body_244);
      heff_drop_rec(v_kw_241, 9);
      heff_drop(v_rhs_247);
      return heff_tag_at_n(v_ru_24x1_2410_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2413}), v_st_2412});
    }
    case TAG_Right: {
      V v_x_2414 = heff_field(v_x11_2411, 0);
      heff_take_n(v_x11_2411, 1ULL, 1);
      V v_t_2417;
      switch (heff_tag_of(v_p_246)) {
      case TAG_At: {
        V v_s_2416 = heff_dup(heff_field(v_p_246, 1));
        v_t_2417 = v_s_2416;
        break;
      }
      default: heff_nomatch(v_p_246);
      }
      V v_t_2420;
      switch (heff_tag_of(v_x_2414)) {
      case TAG_At: {
        V v_s_2419 = heff_dup(heff_field(v_x_2414, 1));
        v_t_2420 = v_s_2419;
        break;
      }
      default: heff_nomatch(v_x_2414);
      }
      V v_t_2421 = ({ V rv_1 = heff_get_n(v_t_2420, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_2417, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
      V v_t_2422 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_246, v_x_2414}), v_t_2421});
      V v_t_2423 = (g_heff_2esyntax_2ecst_2elastE(v_body_244));
      V v_e_2424 = heff_get_n(v_t_2423, 4, 9);
      V v_t_2425 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_241, 3, 9), v_e_2424});
      V v_x_2426 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ELetIn, 2, (V[]){v_rhs_247, v_t_2422}), v_t_2425});
      return heff_tag_at_n(v_ru_24x1_2410_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2426}), v_st_2412});
    }
    default: return heff_nomatch(v_x11_2411);
    }
  }
  default: return heff_nomatch(v_x1_2410);
  }
}
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str0, 7, "integer");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str1, 28, "a segment says its type once");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str2, 6, "binary");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str3, 5, "bytes");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str4, 28, "a segment says its type once");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str5, 3, "big");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str6, 34, "a segment says its endianness once");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str7, 6, "little");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str8, 34, "a segment says its endianness once");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str9, 6, "signed");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str10, 28, "a segment says its sign once");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str11, 8, "unsigned");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str12, 28, "a segment says its sign once");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str13, 175, "a segment's spec is its type (`integer`, `binary`, `bytes`), size (`16`, `size(n)`), endianness (`big`, `little`) and sign (`signed`, `unsigned`), between `-`s: `x::16-little`");
Clo g_heff_2esyntax_2esurface_2especWord_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2especWord_entry, 3, 0};

V g_heff_2esyntax_2esurface_2especWord(V v_t_240, V v_s_241, V v_p_242) {
top: ;
  if (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 1)), ((V)&g_heff_2esyntax_2esurface_2especWord_str0))) {
    V v_t_244 = heff_take_field(v_s_241, 0);
    switch (heff_tag_of(v_t_244)) {
    case TAG_Nothing: {
      heff_drop_rec(v_t_240, 9);
      V v_t_245 = heff_tag_n(TAG_Just, 1, (V[]){NTAG(TAG_SegmentInteger)});
      V v_t_246 = ({ V rv_0 = v_t_245; V rr_ = heff_rec_reuse_nf(v_s_241, 14ULL, 4, shape_ty__size__little__signed, 252u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_246}), v_p_242});
    }
    case TAG_Just: {
      V v_ru_24t_244_24Just = heff_take_reuse_n(v_t_244, 0ULL, 1);
      heff_drop_rec(v_s_241, 4);
      V v_t_248 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_240, 3), heff_get_n(v_t_240, 4, 9)});
      V v_t_249 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2especWord_str1), v_t_248, NTAG(TAG_Nothing)});
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24t_244_24Just, TAG_Left, 1, (V[]){v_t_249}), v_p_242});
    }
    default: return heff_nomatch(v_t_244);
    }
  } else {
    V v_t_2411 = heff_bool((heff_strEq_c(heff_dup(heff_rfield(v_t_240, 1)), ((V)&g_heff_2esyntax_2esurface_2especWord_str2)) || heff_strEq_c(heff_dup(heff_rfield(v_t_240, 1)), ((V)&g_heff_2esyntax_2esurface_2especWord_str3))));
    if ((heff_dup(v_t_2411) == NTAG(TAG_True))) {
      heff_drop(v_t_2411);
      V v_t_2412 = heff_take_field(v_s_241, 0);
      switch (heff_tag_of(v_t_2412)) {
      case TAG_Nothing: {
        heff_drop_rec(v_t_240, 9);
        V v_t_2413 = heff_tag_n(TAG_Just, 1, (V[]){NTAG(TAG_SegmentBinary)});
        V v_t_2414 = ({ V rv_0 = v_t_2413; V rr_ = heff_rec_reuse_nf(v_s_241, 14ULL, 4, shape_ty__size__little__signed, 252u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
        return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2414}), v_p_242});
      }
      case TAG_Just: {
        V v_ru_24t_2412_24Just = heff_take_reuse_n(v_t_2412, 0ULL, 1);
        heff_drop_rec(v_s_241, 4);
        V v_t_2416 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_240, 3), heff_get_n(v_t_240, 4, 9)});
        V v_t_2417 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2especWord_str4), v_t_2416, NTAG(TAG_Nothing)});
        return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24t_2412_24Just, TAG_Left, 1, (V[]){v_t_2417}), v_p_242});
      }
      default: return heff_nomatch(v_t_2412);
      }
    } else {
      heff_drop(v_t_2411);
      if (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 1)), ((V)&g_heff_2esyntax_2esurface_2especWord_str5))) {
        V v_t_2419 = heff_take_field(v_s_241, 2);
        switch (heff_tag_of(v_t_2419)) {
        case TAG_Nothing: {
          heff_drop_rec(v_t_240, 9);
          V v_t_2420 = heff_tag_n(TAG_Just, 1, (V[]){NTAG(TAG_False)});
          V v_t_2421 = ({ V rv_2 = v_t_2420; V rr_ = heff_rec_reuse_nf(v_s_241, 11ULL, 4, shape_ty__size__little__signed, 207u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
          return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2421}), v_p_242});
        }
        case TAG_Just: {
          V v_ru_24t_2419_24Just = heff_take_reuse_n(v_t_2419, 0ULL, 1);
          heff_drop_rec(v_s_241, 4);
          V v_t_2423 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_240, 3), heff_get_n(v_t_240, 4, 9)});
          V v_t_2424 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2especWord_str6), v_t_2423, NTAG(TAG_Nothing)});
          return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24t_2419_24Just, TAG_Left, 1, (V[]){v_t_2424}), v_p_242});
        }
        default: return heff_nomatch(v_t_2419);
        }
      } else {
        if (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 1)), ((V)&g_heff_2esyntax_2esurface_2especWord_str7))) {
          V v_t_2426 = heff_take_field(v_s_241, 2);
          switch (heff_tag_of(v_t_2426)) {
          case TAG_Nothing: {
            heff_drop_rec(v_t_240, 9);
            V v_t_2427 = heff_tag_n(TAG_Just, 1, (V[]){NTAG(TAG_True)});
            V v_t_2428 = ({ V rv_2 = v_t_2427; V rr_ = heff_rec_reuse_nf(v_s_241, 11ULL, 4, shape_ty__size__little__signed, 207u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
            return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2428}), v_p_242});
          }
          case TAG_Just: {
            V v_ru_24t_2426_24Just = heff_take_reuse_n(v_t_2426, 0ULL, 1);
            heff_drop_rec(v_s_241, 4);
            V v_t_2430 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_240, 3), heff_get_n(v_t_240, 4, 9)});
            V v_t_2431 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2especWord_str8), v_t_2430, NTAG(TAG_Nothing)});
            return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24t_2426_24Just, TAG_Left, 1, (V[]){v_t_2431}), v_p_242});
          }
          default: return heff_nomatch(v_t_2426);
          }
        } else {
          if (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 1)), ((V)&g_heff_2esyntax_2esurface_2especWord_str9))) {
            V v_t_2433 = heff_take_field(v_s_241, 3);
            switch (heff_tag_of(v_t_2433)) {
            case TAG_Nothing: {
              heff_drop_rec(v_t_240, 9);
              V v_t_2434 = heff_tag_n(TAG_Just, 1, (V[]){NTAG(TAG_True)});
              V v_t_2435 = ({ V rv_3 = v_t_2434; V rr_ = heff_rec_reuse_nf(v_s_241, 7ULL, 4, shape_ty__size__little__signed, 63u, 0u); heff_rfield(rr_, 3) = rv_3; rr_; });
              return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2435}), v_p_242});
            }
            case TAG_Just: {
              V v_ru_24t_2433_24Just = heff_take_reuse_n(v_t_2433, 0ULL, 1);
              heff_drop_rec(v_s_241, 4);
              V v_t_2437 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_240, 3), heff_get_n(v_t_240, 4, 9)});
              V v_t_2438 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2especWord_str10), v_t_2437, NTAG(TAG_Nothing)});
              return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24t_2433_24Just, TAG_Left, 1, (V[]){v_t_2438}), v_p_242});
            }
            default: return heff_nomatch(v_t_2433);
            }
          } else {
            if (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 1)), ((V)&g_heff_2esyntax_2esurface_2especWord_str11))) {
              V v_t_2440 = heff_take_field(v_s_241, 3);
              switch (heff_tag_of(v_t_2440)) {
              case TAG_Nothing: {
                heff_drop_rec(v_t_240, 9);
                V v_t_2441 = heff_tag_n(TAG_Just, 1, (V[]){NTAG(TAG_False)});
                V v_t_2442 = ({ V rv_3 = v_t_2441; V rr_ = heff_rec_reuse_nf(v_s_241, 7ULL, 4, shape_ty__size__little__signed, 63u, 0u); heff_rfield(rr_, 3) = rv_3; rr_; });
                return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2442}), v_p_242});
              }
              case TAG_Just: {
                V v_ru_24t_2440_24Just = heff_take_reuse_n(v_t_2440, 0ULL, 1);
                heff_drop_rec(v_s_241, 4);
                V v_t_2444 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_240, 3), heff_get_n(v_t_240, 4, 9)});
                V v_t_2445 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2especWord_str12), v_t_2444, NTAG(TAG_Nothing)});
                return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24t_2440_24Just, TAG_Left, 1, (V[]){v_t_2445}), v_p_242});
              }
              default: return heff_nomatch(v_t_2440);
              }
            } else {
              heff_drop_rec(v_s_241, 4);
              V v_t_2446 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_240, 3), heff_get_n(v_t_240, 4, 9)});
              V v_t_2447 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2especWord_str13), v_t_2446, NTAG(TAG_Nothing)});
              return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2447}), v_p_242});
            }
          }
        }
      }
    }
  }
}
V g_heff_2esyntax_2esurface_2especWord_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2especWord(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2esyntax_2esurface_2esegmentOf_24s1547151193x813882637_str0, 56, "a string's segment is its bytes: `\"GET\"`, not an integer");
V g_heff_2esyntax_2esurface_2esegmentOf_24s1547151193x813882637_lam0(V self, V *args);
V g_heff_2esyntax_2esurface_2esegmentOf_24s1547151193x813882637_lam1(V self, V *args);
Clo g_heff_2esyntax_2esurface_2esegmentOf_24s1547151193x813882637_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2esegmentOf_24s1547151193x813882637_entry, 4, 0};

V g_heff_2esyntax_2esurface_2esegmentOf_24s1547151193x813882637(V v_inPat_240, V v_sp_241, V v_e_242, V v_v_243) {
top: ;
  V v_t_245;
  switch (heff_tag_of(v_v_243)) {
  case TAG_StrValue: {
    v_t_245 = NTAG(TAG_SegmentBinary);
    break;
  }
  case TAG_IntValue: {
    v_t_245 = NTAG(TAG_SegmentInteger);
    break;
  }
  case TAG_OtherValue: {
    v_t_245 = NTAG(TAG_SegmentInteger);
    break;
  }
  default: heff_nomatch(v_v_243);
  }
  V v_m_249;
  switch (heff_tag_of(v_t_245)) {
  case TAG_SegmentInteger: {
    switch (heff_tag_of(v_v_243)) {
    case TAG_StrValue: {
      v_m_249 = heff_clo_n(g_heff_2esyntax_2esurface_2esegmentOf_24s1547151193x813882637_lam0, 1, 1, (V[]){heff_dup(v_sp_241)});
      break;
    }
    case TAG_IntValue: {
      v_m_249 = (g_heff_2esyntax_2esurface_2eintegerChecks_24s2046200185x2026207419(v_inPat_240, heff_dup(v_sp_241), heff_dup(v_v_243), heff_tag_n(TAG_Just, 1, (V[]){MK_INT(8LL)})));
      break;
    }
    case TAG_OtherValue: {
      v_m_249 = (g_heff_2esyntax_2esurface_2eintegerChecks_24s2046200185x2026207419(v_inPat_240, heff_dup(v_sp_241), heff_dup(v_v_243), heff_tag_n(TAG_Just, 1, (V[]){MK_INT(8LL)})));
      break;
    }
    default: heff_nomatch(v_v_243);
    }
    break;
  }
  case TAG_SegmentBinary: {
    v_m_249 = heff_tr(heff_call(((V)&g_heff_2esyntax_2esurface_2echeckBinary_24s239798054x1083465754_clo), 2, (V[]){heff_dup(v_sp_241), heff_dup(v_v_243)}));
    break;
  }
  default: heff_nomatch(v_t_245);
  }
  return heff_clo_n(g_heff_2esyntax_2esurface_2esegmentOf_24s1547151193x813882637_lam1, 1, 4, (V[]){v_m_249, v_v_243, v_e_242, v_sp_241});
}
V g_heff_2esyntax_2esurface_2esegmentOf_24s1547151193x813882637_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2esurface_2esegmentOf_24s1547151193x813882637(a0, a[1], a[2], a[3]); heff_drop(a0); return r;
}
V g_heff_2esyntax_2esurface_2esegmentOf_24s1547151193x813882637_lam0(V self, V *args) {
  V v_st_246 = args[0];
  V v_sp_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_247 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2esegmentOf_24s1547151193x813882637_str0), v_sp_241, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_247}), v_st_246});
}
V g_heff_2esyntax_2esurface_2esegmentOf_24s1547151193x813882637_lam1(V self, V *args) {
  V v_st_2410 = args[0];
  V v_m_249 = heff_env(self)[0];
  V v_v_243 = heff_env(self)[1];
  V v_e_242 = heff_env(self)[2];
  V v_sp_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x1_2411 = heff_tr(heff_call(v_m_249, 1, (V[]){v_st_2410}));
  switch (heff_tag_of(v_x1_2411)) {
  case TAG_MkPair: {
    V v_x11_2412 = heff_field(v_x1_2411, 0);
    V v_st_2413 = heff_field(v_x1_2411, 1);
    V v_ru_24x1_2411_24MkPair = heff_take_reuse_n(v_x1_2411, 3ULL, 2);
    switch (heff_tag_of(v_x11_2412)) {
    case TAG_Left: {
      V v_e_2414 = heff_field(v_x11_2412, 0);
      heff_take_n(v_x11_2412, 1ULL, 1);
      heff_drop(v_v_243);
      heff_drop(v_e_242);
      heff_drop(v_sp_241);
      return heff_tag_at_n(v_ru_24x1_2411_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2414}), v_st_2413});
    }
    case TAG_Right: {
      V v_ru_24x11_2412_24Right = heff_take_reuse_n(v_x11_2412, 0ULL, 1);
      V v_t_2417;
      switch (heff_tag_of(v_v_243)) {
      case TAG_StrValue: {
        v_t_2417 = NTAG(TAG_SegmentBinary);
        break;
      }
      case TAG_IntValue: {
        heff_take_n(v_v_243, 0ULL, 1);
        v_t_2417 = NTAG(TAG_SegmentInteger);
        break;
      }
      case TAG_OtherValue: {
        v_t_2417 = NTAG(TAG_SegmentInteger);
        break;
      }
      default: heff_nomatch(v_v_243);
      }
      V v_t_2418 = heff_tag_n(TAG_MkSegment, 5, (V[]){v_e_242, v_t_2417, NTAG(TAG_SizeDefault), NTAG(TAG_False), NTAG(TAG_False)});
      V v_t_2419 = heff_tag_at_n(v_ru_24x11_2412_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2418, v_sp_241})});
      return heff_tag_at_n(v_ru_24x1_2411_24MkPair, TAG_MkPair, 2, (V[]){v_t_2419, v_st_2413});
    }
    default: return heff_nomatch(v_x11_2412);
    }
  }
  default: return heff_nomatch(v_x1_2411);
  }
}
V g_heff_2esyntax_2esurface_2epushS_24s1868233564x1858628873_lam0(V self, V *args);
V g_heff_2esyntax_2esurface_2epushS_24s1868233564x1858628873_lam1(V self, V *args);
Clo g_heff_2esyntax_2esurface_2epushS_24s1868233564x1858628873_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2epushS_24s1868233564x1858628873_entry, 4, 0};

V g_heff_2esyntax_2esurface_2epushS_24s1868233564x1858628873(V v_fix_240, V v_lenient_241, V v_st_242, V v_r_243) {
top: ;
  V v_t_244 = heff_dup(heff_rfield(v_st_242, 0));
  switch (heff_tag_of(v_t_244)) {
  case TAG_Nil: {
    heff_drop(v_fix_240);
    return heff_clo_n(g_heff_2esyntax_2esurface_2epushS_24s1868233564x1858628873_lam0, 1, 2, (V[]){v_r_243, v_st_242});
  }
  case TAG_Cons: {
    V v_before_249 = heff_field(v_t_244, 0);
    heff_take_n(v_t_244, 1ULL, 2);
    V v_m_2411 = (g_heff_2esyntax_2esurface_2efirstS(heff_dup(v_fix_240), v_lenient_241, v_before_249, heff_dup(heff_rfield(v_r_243, 0))));
    return heff_clo_n(g_heff_2esyntax_2esurface_2epushS_24s1868233564x1858628873_lam1, 1, 5, (V[]){v_m_2411, v_st_242, v_fix_240, heff_dup(v_lenient_241), v_r_243});
  }
  default: return heff_nomatch(v_t_244);
  }
}
V g_heff_2esyntax_2esurface_2epushS_24s1868233564x1858628873_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2esyntax_2esurface_2epushS_24s1868233564x1858628873(a[0], a1, a[2], a[3]); heff_drop(a1); return r;
}
V g_heff_2esyntax_2esurface_2epushS_24s1868233564x1858628873_lam0(V self, V *args) {
  V v_st_245 = args[0];
  V v_r_243 = heff_env(self)[0];
  V v_st_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){heff_take_field(v_r_243, 0), heff_take_field(v_st_242, 0)});
  V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){heff_get_n(v_r_243, 1, 2), heff_get_n(v_st_242, 1, 2)});
  V v_t_248 = heff_tag_n(TAG_Right, 1, (V[]){heff_rec_n(2, shape_ops__out, (V[]){v_t_246, v_t_247})});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_248, v_st_245});
}
V g_heff_2esyntax_2esurface_2epushS_24s1868233564x1858628873_lam1(V self, V *args) {
  V v_st_2412 = args[0];
  V v_m_2411 = heff_env(self)[0];
  V v_st_242 = heff_env(self)[1];
  V v_fix_240 = heff_env(self)[2];
  V v_lenient_241 = heff_env(self)[3];
  V v_r_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_x1_2413 = heff_tr(heff_call(v_m_2411, 1, (V[]){v_st_2412}));
  switch (heff_tag_of(v_x1_2413)) {
  case TAG_MkPair: {
    V v_x11_2414 = heff_field(v_x1_2413, 0);
    V v_st_2415 = heff_field(v_x1_2413, 1);
    V v_ru_24x1_2413_24MkPair = heff_take_reuse_n(v_x1_2413, 3ULL, 2);
    switch (heff_tag_of(v_x11_2414)) {
    case TAG_Left: {
      V v_e_2416 = heff_field(v_x11_2414, 0);
      heff_take_n(v_x11_2414, 1ULL, 1);
      heff_drop_rec(v_st_242, 2);
      heff_drop(v_fix_240);
      heff_drop(v_lenient_241);
      heff_drop_rec(v_r_243, 2);
      return heff_tag_at_n(v_ru_24x1_2413_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2416}), v_st_2415});
    }
    case TAG_Right: {
      V v_x_2417 = heff_field(v_x11_2414, 0);
      V v_ru_24x11_2414_24Right = heff_take_reuse_n(v_x11_2414, 1ULL, 1);
      if ((heff_dup(v_x_2417) == NTAG(TAG_True))) {
        heff_drop_cell(v_ru_24x1_2413_24MkPair, 2);
        heff_drop(v_x_2417);
        heff_drop_cell(v_ru_24x11_2414_24Right, 1);
        V v_t_2418 = heff_dup(heff_rfield(v_st_242, 0));
        V v_t_2427;
        switch (heff_tag_of(v_t_2418)) {
        case TAG_Nil: {
          v_t_2427 = v_st_242;
          break;
        }
        case TAG_Cons: {
          V v_o_2419 = heff_field(v_t_2418, 0);
          V v_os_2420 = heff_field(v_t_2418, 1);
          heff_take_n(v_t_2418, 3ULL, 2);
          V v_t_2421 = heff_dup(heff_rfield(v_st_242, 1));
          switch (heff_tag_of(v_t_2421)) {
          case TAG_Nil: {
            heff_drop(v_o_2419);
            heff_drop(v_os_2420);
            v_t_2427 = v_st_242;
            break;
          }
          case TAG_Cons: {
            V v_r_2422 = heff_field(v_t_2421, 0);
            V v_it2_2423 = heff_field(v_t_2421, 1);
            heff_take_n(v_t_2421, 3ULL, 2);
            switch (heff_tag_of(v_it2_2423)) {
            case TAG_Nil: {
              heff_drop(v_o_2419);
              heff_drop(v_os_2420);
              heff_drop(v_r_2422);
              v_t_2427 = v_st_242;
              break;
            }
            case TAG_Cons: {
              V v_l_2424 = heff_field(v_it2_2423, 0);
              V v_rest_2425 = heff_field(v_it2_2423, 1);
              heff_take_n(v_it2_2423, 3ULL, 2);
              heff_drop_rec(v_st_242, 2);
              V v_t_2426 = (g_heff_2esyntax_2esurface_2eapplyOp(v_o_2419, v_l_2424, v_r_2422));
              v_t_2427 = heff_rec_n(2, shape_ops__out, (V[]){v_os_2420, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2426, v_rest_2425})});
              break;
            }
            default: heff_nomatch(v_it2_2423);
            }
            break;
          }
          default: heff_nomatch(v_t_2421);
          }
          break;
        }
        default: heff_nomatch(v_t_2418);
        }
        V v_t_2428 = ({ V a_0 = v_fix_240; V a_1 = v_lenient_241; V a_2 = v_t_2427; V a_3 = v_r_243; V r_ = (g_heff_2esyntax_2esurface_2epushS_24s1868233564x1858628873(a_0, a_1, a_2, a_3)); heff_drop(v_lenient_241); r_; });
        V f_ = v_t_2428;
        args[0] = v_st_2415;
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      } else {
        heff_drop(v_fix_240);
        heff_drop(v_lenient_241);
        heff_drop(v_x_2417);
        V v_t_2429 = heff_tag_n(TAG_Cons, 2, (V[]){heff_take_field(v_r_243, 0), heff_take_field(v_st_242, 0)});
        V v_t_2430 = heff_tag_n(TAG_Cons, 2, (V[]){heff_get_n(v_r_243, 1, 2), heff_get_n(v_st_242, 1, 2)});
        V v_t_2431 = heff_tag_at_n(v_ru_24x11_2414_24Right, TAG_Right, 1, (V[]){heff_rec_n(2, shape_ops__out, (V[]){v_t_2429, v_t_2430})});
        return heff_tag_at_n(v_ru_24x1_2413_24MkPair, TAG_MkPair, 2, (V[]){v_t_2431, v_st_2415});
      }
    }
    default: return heff_nomatch(v_x11_2414);
    }
  }
  default: return heff_nomatch(v_x1_2413);
  }
}
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str0, 3, "con");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str1, 7, " := e)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str2, 51, " := ...)` names an argument, after a function: `f (");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str3, 2, "`(");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str4, 2, "b[");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str5, 1, "[");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str6, 3, "Nil");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str7, 4, "Cons");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str8, 70, "heff has no tuples: a record holds values together, `{ x = a, y = b }`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str9, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str10, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str11, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str12, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str13, 61, "an instance argument is bound before `->`: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str14, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str15, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str16, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str17, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str18, 3, "con");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str19, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str20, 3, "neg");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str21, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str22, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str23, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str24, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str25, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str26, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str27, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str28, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str29, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str30, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str31, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str32, 12, "unexpected `");
V g_heff_2esyntax_2esurface_2eexprL_lam0(V self, V *args);
V g_heff_2esyntax_2esurface_2eexprL_lam1(V self, V *args);
V g_heff_2esyntax_2esurface_2eexprL_lam2(V self, V *args);
V g_heff_2esyntax_2esurface_2eexprL_lam3(V self, V *args);
V g_heff_2esyntax_2esurface_2eexprL_lam4(V self, V *args);
V g_heff_2esyntax_2esurface_2eexprL_lam6(V self, V *args);
V g_heff_2esyntax_2esurface_2eexprL_lam5(V self, V *args);
V g_heff_2esyntax_2esurface_2eexprL_lam7(V self, V *args);
V g_heff_2esyntax_2esurface_2eexprL_lam8(V self, V *args);
Clo g_heff_2esyntax_2esurface_2eexprL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eexprL_entry, 3, 0};

V g_heff_2esyntax_2esurface_2eexprL(V v_r_240, V v_e0_241, V v_z_242) {
top: ;
  switch (heff_tag_of(v_e0_241)) {
  case TAG_Atom: {
    V v_t_243 = heff_field(v_e0_241, 0);
    V v_ru_24e0_241_24Atom = heff_take_reuse_n(v_e0_241, 1ULL, 1);
    heff_drop_rec(v_r_240, 3);
    if (heff_strEq_c(heff_dup(heff_rfield(v_t_243, 0)), ((V)&g_heff_2esyntax_2esurface_2eexprL_str0))) {
      heff_drop_cell(v_ru_24e0_241_24Atom, 1);
      HEFF_LAST return g_heff_2esyntax_2esurface_2econAtom(v_t_243, NTAG(TAG_Nil), v_z_242);
    } else {
      V v_x_245 = (g_heff_2esyntax_2esurface_2eatomTok(v_t_243));
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24e0_241_24Atom, TAG_Right, 1, (V[]){v_x_245}), v_z_242});
    }
  }
  case TAG_EParen: {
    V v_o_246 = heff_field(v_e0_241, 0);
    V v_e_247 = heff_field(v_e0_241, 1);
    V v_c_248 = heff_field(v_e0_241, 2);
    heff_take_n(v_e0_241, 7ULL, 3);
    return ({ V a_0 = v_r_240; V a_1 = v_o_246; V a_2 = v_e_247; V a_3 = v_c_248; V a_4 = v_z_242; V r_ = (g_heff_2esyntax_2esurface_2eparenL(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_o_246); r_; });
  }
  case TAG_Named: {
    V v_o_249 = heff_field(v_e0_241, 0);
    V v_x_2410 = heff_field(v_e0_241, 1);
    V v_e_2412 = heff_field(v_e0_241, 3);
    V v_c_2413 = heff_field(v_e0_241, 4);
    heff_take_n(v_e0_241, 27ULL, 5);
    V v_m_2414 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_2412}));
    V v_x1_2415 = heff_tr(heff_call(v_m_2414, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x1_2415)) {
    case TAG_MkPair: {
      V v_x11_2416 = heff_field(v_x1_2415, 0);
      V v_st_2417 = heff_field(v_x1_2415, 1);
      V v_ru_24x1_2415_24MkPair = heff_take_reuse_n(v_x1_2415, 3ULL, 2);
      switch (heff_tag_of(v_x11_2416)) {
      case TAG_Left: {
        V v_e_2418 = heff_field(v_x11_2416, 0);
        heff_take_n(v_x11_2416, 1ULL, 1);
        heff_drop_rec(v_o_249, 9);
        heff_drop_rec(v_x_2410, 9);
        heff_drop_rec(v_c_2413, 9);
        return heff_tag_at_n(v_ru_24x1_2415_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2418}), v_st_2417});
      }
      case TAG_Right: {
        V v_ru_24x11_2416_24Right = heff_take_reuse_n(v_x11_2416, 0ULL, 1);
        V v_t_2420 = heff_strAppend(heff_dup(heff_rfield(v_x_2410, 1)), ((V)&g_heff_2esyntax_2esurface_2eexprL_str1));
        V v_t_2421 = heff_strAppend(heff_get_n(v_x_2410, 1, 9), heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eexprL_str2), v_t_2420));
        V v_t_2422 = heff_tag_n(TAG_EInvalid, 1, (V[]){heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eexprL_str3), v_t_2421)});
        V v_t_2423 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_o_249, 3, 9), heff_get_n(v_c_2413, 4, 9)});
        V v_t_2424 = heff_tag_at_n(v_ru_24x11_2416_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2422, v_t_2423})});
        return heff_tag_at_n(v_ru_24x1_2415_24MkPair, TAG_MkPair, 2, (V[]){v_t_2424, v_st_2417});
      }
      default: return heff_nomatch(v_x11_2416);
      }
    }
    default: return heff_nomatch(v_x1_2415);
    }
  }
  case TAG_Tup: {
    V v_o_2425 = heff_field(v_e0_241, 0);
    V v_es_2426 = heff_field(v_e0_241, 1);
    V v_c_2428 = heff_field(v_e0_241, 3);
    heff_take_n(v_e0_241, 11ULL, 4);
    if (heff_strEq_c(heff_dup(heff_rfield(v_o_2425, 1)), ((V)&g_heff_2esyntax_2esurface_2eexprL_str4))) {
      V v_m_2431 = (g_heff_2esyntax_2esurface_2etraverseS(heff_clo_n(g_heff_2esyntax_2esurface_2eexprL_lam0, 1, 1, (V[]){v_r_240}), v_es_2426));
      V v_x1_2432 = heff_tr(heff_call(v_m_2431, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_2432)) {
      case TAG_MkPair: {
        V v_x11_2433 = heff_field(v_x1_2432, 0);
        V v_st_2434 = heff_field(v_x1_2432, 1);
        V v_ru_24x1_2432_24MkPair = heff_take_reuse_n(v_x1_2432, 3ULL, 2);
        switch (heff_tag_of(v_x11_2433)) {
        case TAG_Left: {
          V v_e_2435 = heff_field(v_x11_2433, 0);
          heff_take_n(v_x11_2433, 1ULL, 1);
          heff_drop_rec(v_o_2425, 9);
          heff_drop_rec(v_c_2428, 9);
          return heff_tag_at_n(v_ru_24x1_2432_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2435}), v_st_2434});
        }
        case TAG_Right: {
          V v_x_2436 = heff_field(v_x11_2433, 0);
          V v_ru_24x11_2433_24Right = heff_take_reuse_n(v_x11_2433, 1ULL, 1);
          V v_t_2437 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_o_2425, 3, 9), heff_get_n(v_c_2428, 4, 9)});
          V v_t_2438 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_2433_24Right, TAG_EBinary, 1, (V[]){v_x_2436}), v_t_2437});
          return heff_tag_at_n(v_ru_24x1_2432_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2438}), v_st_2434});
        }
        default: return heff_nomatch(v_x11_2433);
        }
      }
      default: return heff_nomatch(v_x1_2432);
      }
    } else {
      if (heff_strEq_c(heff_dup(heff_rfield(v_o_2425, 1)), ((V)&g_heff_2esyntax_2esurface_2eexprL_str5))) {
        V v_m_2440 = (g_heff_2esyntax_2esurface_2etraverseS(heff_get_n(v_r_240, 0, 3), v_es_2426));
        V v_x1_2441 = heff_tr(heff_call(v_m_2440, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_2441)) {
        case TAG_MkPair: {
          V v_x11_2442 = heff_field(v_x1_2441, 0);
          V v_st_2443 = heff_field(v_x1_2441, 1);
          V v_ru_24x1_2441_24MkPair = heff_take_reuse_n(v_x1_2441, 3ULL, 2);
          switch (heff_tag_of(v_x11_2442)) {
          case TAG_Left: {
            V v_e_2444 = heff_field(v_x11_2442, 0);
            heff_take_n(v_x11_2442, 1ULL, 1);
            heff_drop_rec(v_o_2425, 9);
            heff_drop_rec(v_c_2428, 9);
            return heff_tag_at_n(v_ru_24x1_2441_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2444}), v_st_2443});
          }
          case TAG_Right: {
            V v_x_2445 = heff_field(v_x11_2442, 0);
            V v_ru_24x11_2442_24Right = heff_take_reuse_n(v_x11_2442, 1ULL, 1);
            V v_sp_2446 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_o_2425, 3, 9), heff_get_n(v_c_2428, 4, 9)});
            V v_t_2447 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_2442_24Right, TAG_ETag, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2eexprL_str6)}), heff_dup(v_sp_2446)});
            V v_x_2452 = ({ V a_0 = heff_clo_n(g_heff_2esyntax_2esurface_2eexprL_lam1, 2, 1, (V[]){v_sp_2446}); V a_1 = v_t_2447; V a_2 = v_x_2445; V r_ = heff_tr(g_heff_2esyntax_2esurface_2efoldr(a_0, a_1, a_2)); heff_drop(v_x_2445); r_; });
            return heff_tag_at_n(v_ru_24x1_2441_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2452}), v_st_2443});
          }
          default: return heff_nomatch(v_x11_2442);
          }
        }
        default: return heff_nomatch(v_x1_2441);
        }
      } else {
        V v_m_2453 = (g_heff_2esyntax_2esurface_2etraverseS(heff_get_n(v_r_240, 0, 3), v_es_2426));
        V v_x1_2454 = heff_tr(heff_call(v_m_2453, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_2454)) {
        case TAG_MkPair: {
          V v_x11_2455 = heff_field(v_x1_2454, 0);
          V v_st_2456 = heff_field(v_x1_2454, 1);
          V v_ru_24x1_2454_24MkPair = heff_take_reuse_n(v_x1_2454, 3ULL, 2);
          switch (heff_tag_of(v_x11_2455)) {
          case TAG_Left: {
            V v_e_2457 = heff_field(v_x11_2455, 0);
            heff_take_n(v_x11_2455, 1ULL, 1);
            heff_drop_rec(v_o_2425, 9);
            heff_drop_rec(v_c_2428, 9);
            return heff_tag_at_n(v_ru_24x1_2454_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2457}), v_st_2456});
          }
          case TAG_Right: {
            V v_ru_24x11_2455_24Right = heff_take_reuse_n(v_x11_2455, 0ULL, 1);
            V v_t_2459 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_o_2425, 3, 9), heff_get_n(v_c_2428, 4, 9)});
            V v_t_2460 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_2455_24Right, TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2eexprL_str8)}), v_t_2459});
            return heff_tag_at_n(v_ru_24x1_2454_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2460}), v_st_2456});
          }
          default: return heff_nomatch(v_x11_2455);
          }
        }
        default: return heff_nomatch(v_x1_2454);
        }
      }
    }
  }
  case TAG_Seg: {
    heff_drop_rec(v_r_240, 3);
    V v_t_2464 = (g_heff_2esyntax_2ecst_2efirstE(v_e0_241));
    V v_t_2465 = ({ V a_0 = v_e0_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e0_241, 3); r_; });
    V v_t_2466 = heff_strAppend(heff_get_n(v_t_2465, 1, 9), ((V)&g_heff_2esyntax_2esurface_2eexprL_str9));
    V v_msg_2467 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eexprL_str10), v_t_2466);
    V v_t_2468 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_2464, 3), heff_get_n(v_t_2464, 4, 9)});
    V v_t_2469 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_2467, v_t_2468, NTAG(TAG_Nothing)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2469}), v_z_242});
  }
  case TAG_Braces: {
    V v_o_2470 = heff_field(v_e0_241, 0);
    V v_fs_2471 = heff_field(v_e0_241, 1);
    V v_c_2473 = heff_field(v_e0_241, 3);
    heff_take_n(v_e0_241, 11ULL, 4);
    return (g_heff_2esyntax_2esurface_2ebracesL(v_r_240, v_o_2470, v_fs_2471, v_c_2473, v_z_242));
  }
  case TAG_Update: {
    V v_o_2474 = heff_field(v_e0_241, 0);
    V v_rec_2475 = heff_field(v_e0_241, 1);
    V v_fs_2477 = heff_field(v_e0_241, 3);
    V v_c_2479 = heff_field(v_e0_241, 5);
    heff_take_n(v_e0_241, 43ULL, 6);
    V v_m_2480 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_rec_2475}));
    V v_x1_2481 = heff_tr(heff_call(v_m_2480, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x1_2481)) {
    case TAG_MkPair: {
      V v_x11_2482 = heff_field(v_x1_2481, 0);
      V v_st_2483 = heff_field(v_x1_2481, 1);
      V v_ru_24x1_2481_24MkPair = heff_take_reuse_n(v_x1_2481, 3ULL, 2);
      switch (heff_tag_of(v_x11_2482)) {
      case TAG_Left: {
        V v_e_2484 = heff_field(v_x11_2482, 0);
        heff_take_n(v_x11_2482, 1ULL, 1);
        heff_drop_rec(v_r_240, 3);
        heff_drop_rec(v_o_2474, 9);
        heff_drop(v_fs_2477);
        heff_drop_rec(v_c_2479, 9);
        return heff_tag_at_n(v_ru_24x1_2481_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2484}), v_st_2483});
      }
      case TAG_Right: {
        V v_x_2485 = heff_field(v_x11_2482, 0);
        heff_take_n(v_x11_2482, 1ULL, 1);
        V v_m_2487 = (g_heff_2esyntax_2esurface_2etraverseS(heff_clo_n(g_heff_2esyntax_2esurface_2eexprL_lam2, 1, 1, (V[]){v_r_240}), v_fs_2477));
        V v_x1_2488 = heff_tr(heff_call(v_m_2487, 1, (V[]){v_st_2483}));
        switch (heff_tag_of(v_x1_2488)) {
        case TAG_MkPair: {
          V v_x11_2489 = heff_field(v_x1_2488, 0);
          V v_st_2490 = heff_field(v_x1_2488, 1);
          V v_ru_24x1_2488_24MkPair = heff_take_reuse_n(v_x1_2488, 3ULL, 2);
          switch (heff_tag_of(v_x11_2489)) {
          case TAG_Left: {
            V v_e_2491 = heff_field(v_x11_2489, 0);
            heff_take_n(v_x11_2489, 1ULL, 1);
            heff_drop_rec(v_o_2474, 9);
            heff_drop_rec(v_c_2479, 9);
            heff_drop(v_x_2485);
            heff_drop_cell(v_ru_24x1_2488_24MkPair, 2);
            return heff_tag_at_n(v_ru_24x1_2481_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2491}), v_st_2490});
          }
          case TAG_Right: {
            V v_x_2492 = heff_field(v_x11_2489, 0);
            heff_take_n(v_x11_2489, 1ULL, 1);
            V v_t_2493 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_o_2474, 3, 9), heff_get_n(v_c_2479, 4, 9)});
            V v_t_2494 = heff_tag_at_n(v_ru_24x1_2488_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_EUpdate, 2, (V[]){v_x_2485, v_x_2492}), v_t_2493});
            return heff_tag_at_n(v_ru_24x1_2481_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2494}), v_st_2490});
          }
          default: return heff_nomatch(v_x11_2489);
          }
        }
        default: return heff_nomatch(v_x1_2488);
        }
      }
      default: return heff_nomatch(v_x11_2482);
      }
    }
    default: return heff_nomatch(v_x1_2481);
    }
  }
  case TAG_EUSet: {
    heff_drop_rec(v_r_240, 3);
    V v_t_2498 = (g_heff_2esyntax_2ecst_2efirstE(v_e0_241));
    V v_t_2499 = ({ V a_0 = v_e0_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e0_241, 3); r_; });
    V v_t_24100 = heff_strAppend(heff_get_n(v_t_2499, 1, 9), ((V)&g_heff_2esyntax_2esurface_2eexprL_str11));
    V v_msg_24101 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eexprL_str12), v_t_24100);
    V v_t_24102 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_2498, 3), heff_get_n(v_t_2498, 4, 9)});
    V v_t_24103 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24101, v_t_24102, NTAG(TAG_Nothing)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24103}), v_z_242});
  }
  case TAG_InstB: {
    V v_o_24104 = heff_field(v_e0_241, 0);
    V v_d_24106 = heff_field(v_e0_241, 2);
    V v_c_24108 = heff_field(v_e0_241, 4);
    heff_take_n(v_e0_241, 21ULL, 5);
    V v_m_24109 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_d_24106));
    V v_x1_24110 = heff_tr(heff_call(v_m_24109, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x1_24110)) {
    case TAG_MkPair: {
      V v_x11_24111 = heff_field(v_x1_24110, 0);
      V v_st_24112 = heff_field(v_x1_24110, 1);
      V v_ru_24x1_24110_24MkPair = heff_take_reuse_n(v_x1_24110, 3ULL, 2);
      switch (heff_tag_of(v_x11_24111)) {
      case TAG_Left: {
        V v_e_24113 = heff_field(v_x11_24111, 0);
        heff_take_n(v_x11_24111, 1ULL, 1);
        heff_drop_rec(v_o_24104, 9);
        heff_drop_rec(v_c_24108, 9);
        return heff_tag_at_n(v_ru_24x1_24110_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24113}), v_st_24112});
      }
      case TAG_Right: {
        V v_ru_24x11_24111_24Right = heff_take_reuse_n(v_x11_24111, 0ULL, 1);
        V v_t_24115 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_o_24104, 3, 9), heff_get_n(v_c_24108, 4, 9)});
        V v_t_24116 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24111_24Right, TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2eexprL_str13)}), v_t_24115});
        return heff_tag_at_n(v_ru_24x1_24110_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24116}), v_st_24112});
      }
      default: return heff_nomatch(v_x11_24111);
      }
    }
    default: return heff_nomatch(v_x1_24110);
    }
  }
  case TAG_EFSet: {
    heff_drop_rec(v_r_240, 3);
    V v_t_24120 = (g_heff_2esyntax_2ecst_2efirstE(v_e0_241));
    V v_t_24121 = ({ V a_0 = v_e0_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e0_241, 3); r_; });
    V v_t_24122 = heff_strAppend(heff_get_n(v_t_24121, 1, 9), ((V)&g_heff_2esyntax_2esurface_2eexprL_str14));
    V v_msg_24123 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eexprL_str15), v_t_24122);
    V v_t_24124 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24120, 3), heff_get_n(v_t_24120, 4, 9)});
    V v_t_24125 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24123, v_t_24124, NTAG(TAG_Nothing)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24125}), v_z_242});
  }
  case TAG_EFDefault: {
    heff_drop_rec(v_r_240, 3);
    V v_t_24129 = (g_heff_2esyntax_2ecst_2efirstE(v_e0_241));
    V v_t_24130 = ({ V a_0 = v_e0_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e0_241, 3); r_; });
    V v_t_24131 = heff_strAppend(heff_get_n(v_t_24130, 1, 9), ((V)&g_heff_2esyntax_2esurface_2eexprL_str16));
    V v_msg_24132 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eexprL_str17), v_t_24131);
    V v_t_24133 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24129, 3), heff_get_n(v_t_24129, 4, 9)});
    V v_t_24134 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24132, v_t_24133, NTAG(TAG_Nothing)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24134}), v_z_242});
  }
  case TAG_Sum: {
    V v_kw_24135 = heff_field(v_e0_241, 0);
    V v_alts_24137 = heff_field(v_e0_241, 2);
    V v_c_24139 = heff_field(v_e0_241, 4);
    heff_take_n(v_e0_241, 21ULL, 5);
    V v_m_24141 = (g_heff_2esyntax_2esurface_2etraverseS(heff_clo_n(g_heff_2esyntax_2esurface_2eexprL_lam3, 1, 1, (V[]){v_r_240}), v_alts_24137));
    V v_x1_24142 = heff_tr(heff_call(v_m_24141, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x1_24142)) {
    case TAG_MkPair: {
      V v_x11_24143 = heff_field(v_x1_24142, 0);
      V v_st_24144 = heff_field(v_x1_24142, 1);
      V v_ru_24x1_24142_24MkPair = heff_take_reuse_n(v_x1_24142, 3ULL, 2);
      switch (heff_tag_of(v_x11_24143)) {
      case TAG_Left: {
        V v_e_24145 = heff_field(v_x11_24143, 0);
        heff_take_n(v_x11_24143, 1ULL, 1);
        heff_drop_rec(v_kw_24135, 9);
        heff_drop_rec(v_c_24139, 9);
        return heff_tag_at_n(v_ru_24x1_24142_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24145}), v_st_24144});
      }
      case TAG_Right: {
        V v_x_24146 = heff_field(v_x11_24143, 0);
        V v_ru_24x11_24143_24Right = heff_take_reuse_n(v_x11_24143, 1ULL, 1);
        V v_t_24147 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_24135, 3, 9), heff_get_n(v_c_24139, 4, 9)});
        V v_t_24148 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24143_24Right, TAG_ESum, 1, (V[]){v_x_24146}), v_t_24147});
        return heff_tag_at_n(v_ru_24x1_24142_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24148}), v_st_24144});
      }
      default: return heff_nomatch(v_x11_24143);
      }
    }
    default: return heff_nomatch(v_x1_24142);
    }
  }
  case TAG_ECon: {
    V v_c_24149 = heff_field(v_e0_241, 0);
    V v_args_24150 = heff_field(v_e0_241, 1);
    heff_take_n(v_e0_241, 3ULL, 2);
    V v_t_24151 = (g_heff_2esyntax_2esurface_2econL(v_r_240, v_c_24149, v_args_24150));
    return heff_tail(v_t_24151, 1, (V[]){v_z_242});
  }
  case TAG_EField: {
    V v_e_24152 = heff_field(v_e0_241, 0);
    V v_f_24153 = heff_field(v_e0_241, 1);
    V v_ru_24e0_241_24EField = heff_take_reuse_n(v_e0_241, 3ULL, 2);
    V v_it_24154 = (g_heff_2esyntax_2esurface_2efieldsOf(heff_tag_at_n(v_ru_24e0_241_24EField, TAG_EField, 2, (V[]){v_e_24152, v_f_24153}), NTAG(TAG_Nil)));
    switch (heff_tag_of(v_it_24154)) {
    case TAG_MkFields: {
      V v_it1_24155 = heff_field(v_it_24154, 0);
      V v_fs_24156 = heff_field(v_it_24154, 1);
      V v_ru_24it_24154_24MkFields = heff_take_reuse_n(v_it_24154, 3ULL, 2);
      switch (heff_tag_of(v_it1_24155)) {
      case TAG_Atom: {
        V v_t_24157 = heff_field(v_it1_24155, 0);
        heff_take_n(v_it1_24155, 1ULL, 1);
        heff_drop_rec(v_r_240, 3);
        if (heff_strEq_c(heff_dup(heff_rfield(v_t_24157, 0)), ((V)&g_heff_2esyntax_2esurface_2eexprL_str18))) {
          heff_drop_cell(v_ru_24it_24154_24MkFields, 2);
          HEFF_LAST return g_heff_2esyntax_2esurface_2econAtom(v_t_24157, v_fs_24156, v_z_242);
        } else {
          if (heff_strEq_c(heff_dup(heff_rfield(v_t_24157, 0)), ((V)&g_heff_2esyntax_2esurface_2eexprL_str19))) {
            heff_drop_cell(v_ru_24it_24154_24MkFields, 2);
            HEFF_LAST return g_heff_2esyntax_2esurface_2ekwAtom(v_t_24157, v_fs_24156, v_z_242);
          } else {
            V v_e_24160 = (g_heff_2esyntax_2esurface_2eatomTok(v_t_24157));
            V v_t_24161 = (g_list_2emap_24s513201124x806973253(v_fs_24156));
            V v_x_24162 = (g_heff_2esyntax_2epresyntax_2eapp(v_e_24160, v_t_24161));
            return heff_tag_at_n(v_ru_24it_24154_24MkFields, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24162}), v_z_242});
          }
        }
      }
      case TAG_EParen: {
        V v_m_24166 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24155}));
        V v_x1_24167 = heff_tr(heff_call(v_m_24166, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24167)) {
        case TAG_MkPair: {
          V v_x11_24168 = heff_field(v_x1_24167, 0);
          V v_st_24169 = heff_field(v_x1_24167, 1);
          heff_take_n(v_x1_24167, 3ULL, 2);
          switch (heff_tag_of(v_x11_24168)) {
          case TAG_Left: {
            V v_e_24170 = heff_field(v_x11_24168, 0);
            heff_take_n(v_x11_24168, 1ULL, 1);
            heff_drop(v_fs_24156);
            return heff_tag_at_n(v_ru_24it_24154_24MkFields, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24170}), v_st_24169});
          }
          case TAG_Right: {
            V v_x_24171 = heff_field(v_x11_24168, 0);
            heff_take_n(v_x11_24168, 1ULL, 1);
            V v_t_24172 = (g_list_2emap_24s513201124x806973253(v_fs_24156));
            V v_x_24173 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24171, v_t_24172));
            return heff_tag_at_n(v_ru_24it_24154_24MkFields, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24173}), v_st_24169});
          }
          default: return heff_nomatch(v_x11_24168);
          }
        }
        default: return heff_nomatch(v_x1_24167);
        }
      }
      case TAG_Named: {
        V v_m_24179 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24155}));
        V v_x1_24180 = heff_tr(heff_call(v_m_24179, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24180)) {
        case TAG_MkPair: {
          V v_x11_24181 = heff_field(v_x1_24180, 0);
          V v_st_24182 = heff_field(v_x1_24180, 1);
          heff_take_n(v_x1_24180, 3ULL, 2);
          switch (heff_tag_of(v_x11_24181)) {
          case TAG_Left: {
            V v_e_24183 = heff_field(v_x11_24181, 0);
            heff_take_n(v_x11_24181, 1ULL, 1);
            heff_drop(v_fs_24156);
            return heff_tag_at_n(v_ru_24it_24154_24MkFields, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24183}), v_st_24182});
          }
          case TAG_Right: {
            V v_x_24184 = heff_field(v_x11_24181, 0);
            heff_take_n(v_x11_24181, 1ULL, 1);
            V v_t_24185 = (g_list_2emap_24s513201124x806973253(v_fs_24156));
            V v_x_24186 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24184, v_t_24185));
            return heff_tag_at_n(v_ru_24it_24154_24MkFields, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24186}), v_st_24182});
          }
          default: return heff_nomatch(v_x11_24181);
          }
        }
        default: return heff_nomatch(v_x1_24180);
        }
      }
      case TAG_Tup: {
        V v_m_24191 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24155}));
        V v_x1_24192 = heff_tr(heff_call(v_m_24191, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24192)) {
        case TAG_MkPair: {
          V v_x11_24193 = heff_field(v_x1_24192, 0);
          V v_st_24194 = heff_field(v_x1_24192, 1);
          heff_take_n(v_x1_24192, 3ULL, 2);
          switch (heff_tag_of(v_x11_24193)) {
          case TAG_Left: {
            V v_e_24195 = heff_field(v_x11_24193, 0);
            heff_take_n(v_x11_24193, 1ULL, 1);
            heff_drop(v_fs_24156);
            return heff_tag_at_n(v_ru_24it_24154_24MkFields, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24195}), v_st_24194});
          }
          case TAG_Right: {
            V v_x_24196 = heff_field(v_x11_24193, 0);
            heff_take_n(v_x11_24193, 1ULL, 1);
            V v_t_24197 = (g_list_2emap_24s513201124x806973253(v_fs_24156));
            V v_x_24198 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24196, v_t_24197));
            return heff_tag_at_n(v_ru_24it_24154_24MkFields, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24198}), v_st_24194});
          }
          default: return heff_nomatch(v_x11_24193);
          }
        }
        default: return heff_nomatch(v_x1_24192);
        }
      }
      case TAG_Seg: {
        V v_m_24202 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24155}));
        V v_x1_24203 = heff_tr(heff_call(v_m_24202, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24203)) {
        case TAG_MkPair: {
          V v_x11_24204 = heff_field(v_x1_24203, 0);
          V v_st_24205 = heff_field(v_x1_24203, 1);
          heff_take_n(v_x1_24203, 3ULL, 2);
          switch (heff_tag_of(v_x11_24204)) {
          case TAG_Left: {
            V v_e_24206 = heff_field(v_x11_24204, 0);
            heff_take_n(v_x11_24204, 1ULL, 1);
            heff_drop(v_fs_24156);
            return heff_tag_at_n(v_ru_24it_24154_24MkFields, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24206}), v_st_24205});
          }
          case TAG_Right: {
            V v_x_24207 = heff_field(v_x11_24204, 0);
            heff_take_n(v_x11_24204, 1ULL, 1);
            V v_t_24208 = (g_list_2emap_24s513201124x806973253(v_fs_24156));
            V v_x_24209 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24207, v_t_24208));
            return heff_tag_at_n(v_ru_24it_24154_24MkFields, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24209}), v_st_24205});
          }
          default: return heff_nomatch(v_x11_24204);
          }
        }
        default: return heff_nomatch(v_x1_24203);
        }
      }
      case TAG_Braces: {
        V v_m_24214 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24155}));
        V v_x1_24215 = heff_tr(heff_call(v_m_24214, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24215)) {
        case TAG_MkPair: {
          V v_x11_24216 = heff_field(v_x1_24215, 0);
          V v_st_24217 = heff_field(v_x1_24215, 1);
          heff_take_n(v_x1_24215, 3ULL, 2);
          switch (heff_tag_of(v_x11_24216)) {
          case TAG_Left: {
            V v_e_24218 = heff_field(v_x11_24216, 0);
            heff_take_n(v_x11_24216, 1ULL, 1);
            heff_drop(v_fs_24156);
            return heff_tag_at_n(v_ru_24it_24154_24MkFields, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24218}), v_st_24217});
          }
          case TAG_Right: {
            V v_x_24219 = heff_field(v_x11_24216, 0);
            heff_take_n(v_x11_24216, 1ULL, 1);
            V v_t_24220 = (g_list_2emap_24s513201124x806973253(v_fs_24156));
            V v_x_24221 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24219, v_t_24220));
            return heff_tag_at_n(v_ru_24it_24154_24MkFields, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24221}), v_st_24217});
          }
          default: return heff_nomatch(v_x11_24216);
          }
        }
        default: return heff_nomatch(v_x1_24215);
        }
      }
      case TAG_Update: {
        V v_m_24228 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24155}));
        V v_x1_24229 = heff_tr(heff_call(v_m_24228, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24229)) {
        case TAG_MkPair: {
          V v_x11_24230 = heff_field(v_x1_24229, 0);
          V v_st_24231 = heff_field(v_x1_24229, 1);
          heff_take_n(v_x1_24229, 3ULL, 2);
          switch (heff_tag_of(v_x11_24230)) {
          case TAG_Left: {
            V v_e_24232 = heff_field(v_x11_24230, 0);
            heff_take_n(v_x11_24230, 1ULL, 1);
            heff_drop(v_fs_24156);
            return heff_tag_at_n(v_ru_24it_24154_24MkFields, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24232}), v_st_24231});
          }
          case TAG_Right: {
            V v_x_24233 = heff_field(v_x11_24230, 0);
            heff_take_n(v_x11_24230, 1ULL, 1);
            V v_t_24234 = (g_list_2emap_24s513201124x806973253(v_fs_24156));
            V v_x_24235 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24233, v_t_24234));
            return heff_tag_at_n(v_ru_24it_24154_24MkFields, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24235}), v_st_24231});
          }
          default: return heff_nomatch(v_x11_24230);
          }
        }
        default: return heff_nomatch(v_x1_24229);
        }
      }
      case TAG_EUSet: {
        V v_m_24239 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24155}));
        V v_x1_24240 = heff_tr(heff_call(v_m_24239, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24240)) {
        case TAG_MkPair: {
          V v_x11_24241 = heff_field(v_x1_24240, 0);
          V v_st_24242 = heff_field(v_x1_24240, 1);
          heff_take_n(v_x1_24240, 3ULL, 2);
          switch (heff_tag_of(v_x11_24241)) {
          case TAG_Left: {
            V v_e_24243 = heff_field(v_x11_24241, 0);
            heff_take_n(v_x11_24241, 1ULL, 1);
            heff_drop(v_fs_24156);
            return heff_tag_at_n(v_ru_24it_24154_24MkFields, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24243}), v_st_24242});
          }
          case TAG_Right: {
            V v_x_24244 = heff_field(v_x11_24241, 0);
            heff_take_n(v_x11_24241, 1ULL, 1);
            V v_t_24245 = (g_list_2emap_24s513201124x806973253(v_fs_24156));
            V v_x_24246 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24244, v_t_24245));
            return heff_tag_at_n(v_ru_24it_24154_24MkFields, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24246}), v_st_24242});
          }
          default: return heff_nomatch(v_x11_24241);
          }
        }
        default: return heff_nomatch(v_x1_24240);
        }
      }
      case TAG_InstB: {
        V v_m_24252 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24155}));
        V v_x1_24253 = heff_tr(heff_call(v_m_24252, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24253)) {
        case TAG_MkPair: {
          V v_x11_24254 = heff_field(v_x1_24253, 0);
          V v_st_24255 = heff_field(v_x1_24253, 1);
          heff_take_n(v_x1_24253, 3ULL, 2);
          switch (heff_tag_of(v_x11_24254)) {
          case TAG_Left: {
            V v_e_24256 = heff_field(v_x11_24254, 0);
            heff_take_n(v_x11_24254, 1ULL, 1);
            heff_drop(v_fs_24156);
            return heff_tag_at_n(v_ru_24it_24154_24MkFields, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24256}), v_st_24255});
          }
          case TAG_Right: {
            V v_x_24257 = heff_field(v_x11_24254, 0);
            heff_take_n(v_x11_24254, 1ULL, 1);
            V v_t_24258 = (g_list_2emap_24s513201124x806973253(v_fs_24156));
            V v_x_24259 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24257, v_t_24258));
            return heff_tag_at_n(v_ru_24it_24154_24MkFields, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24259}), v_st_24255});
          }
          default: return heff_nomatch(v_x11_24254);
          }
        }
        default: return heff_nomatch(v_x1_24253);
        }
      }
      case TAG_EFSet: {
        V v_m_24263 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24155}));
        V v_x1_24264 = heff_tr(heff_call(v_m_24263, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24264)) {
        case TAG_MkPair: {
          V v_x11_24265 = heff_field(v_x1_24264, 0);
          V v_st_24266 = heff_field(v_x1_24264, 1);
          heff_take_n(v_x1_24264, 3ULL, 2);
          switch (heff_tag_of(v_x11_24265)) {
          case TAG_Left: {
            V v_e_24267 = heff_field(v_x11_24265, 0);
            heff_take_n(v_x11_24265, 1ULL, 1);
            heff_drop(v_fs_24156);
            return heff_tag_at_n(v_ru_24it_24154_24MkFields, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24267}), v_st_24266});
          }
          case TAG_Right: {
            V v_x_24268 = heff_field(v_x11_24265, 0);
            heff_take_n(v_x11_24265, 1ULL, 1);
            V v_t_24269 = (g_list_2emap_24s513201124x806973253(v_fs_24156));
            V v_x_24270 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24268, v_t_24269));
            return heff_tag_at_n(v_ru_24it_24154_24MkFields, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24270}), v_st_24266});
          }
          default: return heff_nomatch(v_x11_24265);
          }
        }
        default: return heff_nomatch(v_x1_24264);
        }
      }
      case TAG_EFDefault: {
        V v_m_24274 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24155}));
        V v_x1_24275 = heff_tr(heff_call(v_m_24274, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24275)) {
        case TAG_MkPair: {
          V v_x11_24276 = heff_field(v_x1_24275, 0);
          V v_st_24277 = heff_field(v_x1_24275, 1);
          heff_take_n(v_x1_24275, 3ULL, 2);
          switch (heff_tag_of(v_x11_24276)) {
          case TAG_Left: {
            V v_e_24278 = heff_field(v_x11_24276, 0);
            heff_take_n(v_x11_24276, 1ULL, 1);
            heff_drop(v_fs_24156);
            return heff_tag_at_n(v_ru_24it_24154_24MkFields, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24278}), v_st_24277});
          }
          case TAG_Right: {
            V v_x_24279 = heff_field(v_x11_24276, 0);
            heff_take_n(v_x11_24276, 1ULL, 1);
            V v_t_24280 = (g_list_2emap_24s513201124x806973253(v_fs_24156));
            V v_x_24281 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24279, v_t_24280));
            return heff_tag_at_n(v_ru_24it_24154_24MkFields, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24281}), v_st_24277});
          }
          default: return heff_nomatch(v_x11_24276);
          }
        }
        default: return heff_nomatch(v_x1_24275);
        }
      }
      case TAG_Sum: {
        V v_m_24287 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24155}));
        V v_x1_24288 = heff_tr(heff_call(v_m_24287, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24288)) {
        case TAG_MkPair: {
          V v_x11_24289 = heff_field(v_x1_24288, 0);
          V v_st_24290 = heff_field(v_x1_24288, 1);
          heff_take_n(v_x1_24288, 3ULL, 2);
          switch (heff_tag_of(v_x11_24289)) {
          case TAG_Left: {
            V v_e_24291 = heff_field(v_x11_24289, 0);
            heff_take_n(v_x11_24289, 1ULL, 1);
            heff_drop(v_fs_24156);
            return heff_tag_at_n(v_ru_24it_24154_24MkFields, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24291}), v_st_24290});
          }
          case TAG_Right: {
            V v_x_24292 = heff_field(v_x11_24289, 0);
            heff_take_n(v_x11_24289, 1ULL, 1);
            V v_t_24293 = (g_list_2emap_24s513201124x806973253(v_fs_24156));
            V v_x_24294 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24292, v_t_24293));
            return heff_tag_at_n(v_ru_24it_24154_24MkFields, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24294}), v_st_24290});
          }
          default: return heff_nomatch(v_x11_24289);
          }
        }
        default: return heff_nomatch(v_x1_24288);
        }
      }
      case TAG_ECon: {
        V v_m_24297 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24155}));
        V v_x1_24298 = heff_tr(heff_call(v_m_24297, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24298)) {
        case TAG_MkPair: {
          V v_x11_24299 = heff_field(v_x1_24298, 0);
          V v_st_24300 = heff_field(v_x1_24298, 1);
          heff_take_n(v_x1_24298, 3ULL, 2);
          switch (heff_tag_of(v_x11_24299)) {
          case TAG_Left: {
            V v_e_24301 = heff_field(v_x11_24299, 0);
            heff_take_n(v_x11_24299, 1ULL, 1);
            heff_drop(v_fs_24156);
            return heff_tag_at_n(v_ru_24it_24154_24MkFields, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24301}), v_st_24300});
          }
          case TAG_Right: {
            V v_x_24302 = heff_field(v_x11_24299, 0);
            heff_take_n(v_x11_24299, 1ULL, 1);
            V v_t_24303 = (g_list_2emap_24s513201124x806973253(v_fs_24156));
            V v_x_24304 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24302, v_t_24303));
            return heff_tag_at_n(v_ru_24it_24154_24MkFields, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24304}), v_st_24300});
          }
          default: return heff_nomatch(v_x11_24299);
          }
        }
        default: return heff_nomatch(v_x1_24298);
        }
      }
      case TAG_EField: {
        V v_m_24307 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24155}));
        V v_x1_24308 = heff_tr(heff_call(v_m_24307, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24308)) {
        case TAG_MkPair: {
          V v_x11_24309 = heff_field(v_x1_24308, 0);
          V v_st_24310 = heff_field(v_x1_24308, 1);
          heff_take_n(v_x1_24308, 3ULL, 2);
          switch (heff_tag_of(v_x11_24309)) {
          case TAG_Left: {
            V v_e_24311 = heff_field(v_x11_24309, 0);
            heff_take_n(v_x11_24309, 1ULL, 1);
            heff_drop(v_fs_24156);
            return heff_tag_at_n(v_ru_24it_24154_24MkFields, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24311}), v_st_24310});
          }
          case TAG_Right: {
            V v_x_24312 = heff_field(v_x11_24309, 0);
            heff_take_n(v_x11_24309, 1ULL, 1);
            V v_t_24313 = (g_list_2emap_24s513201124x806973253(v_fs_24156));
            V v_x_24314 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24312, v_t_24313));
            return heff_tag_at_n(v_ru_24it_24154_24MkFields, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24314}), v_st_24310});
          }
          default: return heff_nomatch(v_x11_24309);
          }
        }
        default: return heff_nomatch(v_x1_24308);
        }
      }
      case TAG_ENeg: {
        V v_m_24317 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24155}));
        V v_x1_24318 = heff_tr(heff_call(v_m_24317, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24318)) {
        case TAG_MkPair: {
          V v_x11_24319 = heff_field(v_x1_24318, 0);
          V v_st_24320 = heff_field(v_x1_24318, 1);
          heff_take_n(v_x1_24318, 3ULL, 2);
          switch (heff_tag_of(v_x11_24319)) {
          case TAG_Left: {
            V v_e_24321 = heff_field(v_x11_24319, 0);
            heff_take_n(v_x11_24319, 1ULL, 1);
            heff_drop(v_fs_24156);
            return heff_tag_at_n(v_ru_24it_24154_24MkFields, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24321}), v_st_24320});
          }
          case TAG_Right: {
            V v_x_24322 = heff_field(v_x11_24319, 0);
            heff_take_n(v_x11_24319, 1ULL, 1);
            V v_t_24323 = (g_list_2emap_24s513201124x806973253(v_fs_24156));
            V v_x_24324 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24322, v_t_24323));
            return heff_tag_at_n(v_ru_24it_24154_24MkFields, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24324}), v_st_24320});
          }
          default: return heff_nomatch(v_x11_24319);
          }
        }
        default: return heff_nomatch(v_x1_24318);
        }
      }
      case TAG_App: {
        V v_m_24327 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24155}));
        V v_x1_24328 = heff_tr(heff_call(v_m_24327, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24328)) {
        case TAG_MkPair: {
          V v_x11_24329 = heff_field(v_x1_24328, 0);
          V v_st_24330 = heff_field(v_x1_24328, 1);
          heff_take_n(v_x1_24328, 3ULL, 2);
          switch (heff_tag_of(v_x11_24329)) {
          case TAG_Left: {
            V v_e_24331 = heff_field(v_x11_24329, 0);
            heff_take_n(v_x11_24329, 1ULL, 1);
            heff_drop(v_fs_24156);
            return heff_tag_at_n(v_ru_24it_24154_24MkFields, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24331}), v_st_24330});
          }
          case TAG_Right: {
            V v_x_24332 = heff_field(v_x11_24329, 0);
            heff_take_n(v_x11_24329, 1ULL, 1);
            V v_t_24333 = (g_list_2emap_24s513201124x806973253(v_fs_24156));
            V v_x_24334 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24332, v_t_24333));
            return heff_tag_at_n(v_ru_24it_24154_24MkFields, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24334}), v_st_24330});
          }
          default: return heff_nomatch(v_x11_24329);
          }
        }
        default: return heff_nomatch(v_x1_24328);
        }
      }
      case TAG_Op: {
        V v_m_24338 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24155}));
        V v_x1_24339 = heff_tr(heff_call(v_m_24338, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24339)) {
        case TAG_MkPair: {
          V v_x11_24340 = heff_field(v_x1_24339, 0);
          V v_st_24341 = heff_field(v_x1_24339, 1);
          heff_take_n(v_x1_24339, 3ULL, 2);
          switch (heff_tag_of(v_x11_24340)) {
          case TAG_Left: {
            V v_e_24342 = heff_field(v_x11_24340, 0);
            heff_take_n(v_x11_24340, 1ULL, 1);
            heff_drop(v_fs_24156);
            return heff_tag_at_n(v_ru_24it_24154_24MkFields, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24342}), v_st_24341});
          }
          case TAG_Right: {
            V v_x_24343 = heff_field(v_x11_24340, 0);
            heff_take_n(v_x11_24340, 1ULL, 1);
            V v_t_24344 = (g_list_2emap_24s513201124x806973253(v_fs_24156));
            V v_x_24345 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24343, v_t_24344));
            return heff_tag_at_n(v_ru_24it_24154_24MkFields, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24345}), v_st_24341});
          }
          default: return heff_nomatch(v_x11_24340);
          }
        }
        default: return heff_nomatch(v_x1_24339);
        }
      }
      case TAG_Ops: {
        V v_m_24348 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24155}));
        V v_x1_24349 = heff_tr(heff_call(v_m_24348, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24349)) {
        case TAG_MkPair: {
          V v_x11_24350 = heff_field(v_x1_24349, 0);
          V v_st_24351 = heff_field(v_x1_24349, 1);
          heff_take_n(v_x1_24349, 3ULL, 2);
          switch (heff_tag_of(v_x11_24350)) {
          case TAG_Left: {
            V v_e_24352 = heff_field(v_x11_24350, 0);
            heff_take_n(v_x11_24350, 1ULL, 1);
            heff_drop(v_fs_24156);
            return heff_tag_at_n(v_ru_24it_24154_24MkFields, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24352}), v_st_24351});
          }
          case TAG_Right: {
            V v_x_24353 = heff_field(v_x11_24350, 0);
            heff_take_n(v_x11_24350, 1ULL, 1);
            V v_t_24354 = (g_list_2emap_24s513201124x806973253(v_fs_24156));
            V v_x_24355 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24353, v_t_24354));
            return heff_tag_at_n(v_ru_24it_24154_24MkFields, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24355}), v_st_24351});
          }
          default: return heff_nomatch(v_x11_24350);
          }
        }
        default: return heff_nomatch(v_x1_24349);
        }
      }
      case TAG_OpRhs: {
        V v_m_24358 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24155}));
        V v_x1_24359 = heff_tr(heff_call(v_m_24358, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24359)) {
        case TAG_MkPair: {
          V v_x11_24360 = heff_field(v_x1_24359, 0);
          V v_st_24361 = heff_field(v_x1_24359, 1);
          heff_take_n(v_x1_24359, 3ULL, 2);
          switch (heff_tag_of(v_x11_24360)) {
          case TAG_Left: {
            V v_e_24362 = heff_field(v_x11_24360, 0);
            heff_take_n(v_x11_24360, 1ULL, 1);
            heff_drop(v_fs_24156);
            return heff_tag_at_n(v_ru_24it_24154_24MkFields, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24362}), v_st_24361});
          }
          case TAG_Right: {
            V v_x_24363 = heff_field(v_x11_24360, 0);
            heff_take_n(v_x11_24360, 1ULL, 1);
            V v_t_24364 = (g_list_2emap_24s513201124x806973253(v_fs_24156));
            V v_x_24365 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24363, v_t_24364));
            return heff_tag_at_n(v_ru_24it_24154_24MkFields, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24365}), v_st_24361});
          }
          default: return heff_nomatch(v_x11_24360);
          }
        }
        default: return heff_nomatch(v_x1_24359);
        }
      }
      case TAG_Ann: {
        V v_m_24369 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24155}));
        V v_x1_24370 = heff_tr(heff_call(v_m_24369, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24370)) {
        case TAG_MkPair: {
          V v_x11_24371 = heff_field(v_x1_24370, 0);
          V v_st_24372 = heff_field(v_x1_24370, 1);
          heff_take_n(v_x1_24370, 3ULL, 2);
          switch (heff_tag_of(v_x11_24371)) {
          case TAG_Left: {
            V v_e_24373 = heff_field(v_x11_24371, 0);
            heff_take_n(v_x11_24371, 1ULL, 1);
            heff_drop(v_fs_24156);
            return heff_tag_at_n(v_ru_24it_24154_24MkFields, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24373}), v_st_24372});
          }
          case TAG_Right: {
            V v_x_24374 = heff_field(v_x11_24371, 0);
            heff_take_n(v_x11_24371, 1ULL, 1);
            V v_t_24375 = (g_list_2emap_24s513201124x806973253(v_fs_24156));
            V v_x_24376 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24374, v_t_24375));
            return heff_tag_at_n(v_ru_24it_24154_24MkFields, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24376}), v_st_24372});
          }
          default: return heff_nomatch(v_x11_24371);
          }
        }
        default: return heff_nomatch(v_x1_24370);
        }
      }
      case TAG_BVar: {
        V v_m_24378 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24155}));
        V v_x1_24379 = heff_tr(heff_call(v_m_24378, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24379)) {
        case TAG_MkPair: {
          V v_x11_24380 = heff_field(v_x1_24379, 0);
          V v_st_24381 = heff_field(v_x1_24379, 1);
          heff_take_n(v_x1_24379, 3ULL, 2);
          switch (heff_tag_of(v_x11_24380)) {
          case TAG_Left: {
            V v_e_24382 = heff_field(v_x11_24380, 0);
            heff_take_n(v_x11_24380, 1ULL, 1);
            heff_drop(v_fs_24156);
            return heff_tag_at_n(v_ru_24it_24154_24MkFields, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24382}), v_st_24381});
          }
          case TAG_Right: {
            V v_x_24383 = heff_field(v_x11_24380, 0);
            heff_take_n(v_x11_24380, 1ULL, 1);
            V v_t_24384 = (g_list_2emap_24s513201124x806973253(v_fs_24156));
            V v_x_24385 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24383, v_t_24384));
            return heff_tag_at_n(v_ru_24it_24154_24MkFields, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24385}), v_st_24381});
          }
          default: return heff_nomatch(v_x11_24380);
          }
        }
        default: return heff_nomatch(v_x1_24379);
        }
      }
      case TAG_BImp: {
        V v_m_24389 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24155}));
        V v_x1_24390 = heff_tr(heff_call(v_m_24389, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24390)) {
        case TAG_MkPair: {
          V v_x11_24391 = heff_field(v_x1_24390, 0);
          V v_st_24392 = heff_field(v_x1_24390, 1);
          heff_take_n(v_x1_24390, 3ULL, 2);
          switch (heff_tag_of(v_x11_24391)) {
          case TAG_Left: {
            V v_e_24393 = heff_field(v_x11_24391, 0);
            heff_take_n(v_x11_24391, 1ULL, 1);
            heff_drop(v_fs_24156);
            return heff_tag_at_n(v_ru_24it_24154_24MkFields, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24393}), v_st_24392});
          }
          case TAG_Right: {
            V v_x_24394 = heff_field(v_x11_24391, 0);
            heff_take_n(v_x11_24391, 1ULL, 1);
            V v_t_24395 = (g_list_2emap_24s513201124x806973253(v_fs_24156));
            V v_x_24396 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24394, v_t_24395));
            return heff_tag_at_n(v_ru_24it_24154_24MkFields, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24396}), v_st_24392});
          }
          default: return heff_nomatch(v_x11_24391);
          }
        }
        default: return heff_nomatch(v_x1_24390);
        }
      }
      case TAG_BAnn: {
        V v_m_24402 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24155}));
        V v_x1_24403 = heff_tr(heff_call(v_m_24402, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24403)) {
        case TAG_MkPair: {
          V v_x11_24404 = heff_field(v_x1_24403, 0);
          V v_st_24405 = heff_field(v_x1_24403, 1);
          heff_take_n(v_x1_24403, 3ULL, 2);
          switch (heff_tag_of(v_x11_24404)) {
          case TAG_Left: {
            V v_e_24406 = heff_field(v_x11_24404, 0);
            heff_take_n(v_x11_24404, 1ULL, 1);
            heff_drop(v_fs_24156);
            return heff_tag_at_n(v_ru_24it_24154_24MkFields, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24406}), v_st_24405});
          }
          case TAG_Right: {
            V v_x_24407 = heff_field(v_x11_24404, 0);
            heff_take_n(v_x11_24404, 1ULL, 1);
            V v_t_24408 = (g_list_2emap_24s513201124x806973253(v_fs_24156));
            V v_x_24409 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24407, v_t_24408));
            return heff_tag_at_n(v_ru_24it_24154_24MkFields, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24409}), v_st_24405});
          }
          default: return heff_nomatch(v_x11_24404);
          }
        }
        default: return heff_nomatch(v_x1_24403);
        }
      }
      case TAG_Lam: {
        V v_m_24414 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24155}));
        V v_x1_24415 = heff_tr(heff_call(v_m_24414, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24415)) {
        case TAG_MkPair: {
          V v_x11_24416 = heff_field(v_x1_24415, 0);
          V v_st_24417 = heff_field(v_x1_24415, 1);
          heff_take_n(v_x1_24415, 3ULL, 2);
          switch (heff_tag_of(v_x11_24416)) {
          case TAG_Left: {
            V v_e_24418 = heff_field(v_x11_24416, 0);
            heff_take_n(v_x11_24416, 1ULL, 1);
            heff_drop(v_fs_24156);
            return heff_tag_at_n(v_ru_24it_24154_24MkFields, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24418}), v_st_24417});
          }
          case TAG_Right: {
            V v_x_24419 = heff_field(v_x11_24416, 0);
            heff_take_n(v_x11_24416, 1ULL, 1);
            V v_t_24420 = (g_list_2emap_24s513201124x806973253(v_fs_24156));
            V v_x_24421 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24419, v_t_24420));
            return heff_tag_at_n(v_ru_24it_24154_24MkFields, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24421}), v_st_24417});
          }
          default: return heff_nomatch(v_x11_24416);
          }
        }
        default: return heff_nomatch(v_x1_24415);
        }
      }
      case TAG_Case: {
        V v_m_24426 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24155}));
        V v_x1_24427 = heff_tr(heff_call(v_m_24426, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24427)) {
        case TAG_MkPair: {
          V v_x11_24428 = heff_field(v_x1_24427, 0);
          V v_st_24429 = heff_field(v_x1_24427, 1);
          heff_take_n(v_x1_24427, 3ULL, 2);
          switch (heff_tag_of(v_x11_24428)) {
          case TAG_Left: {
            V v_e_24430 = heff_field(v_x11_24428, 0);
            heff_take_n(v_x11_24428, 1ULL, 1);
            heff_drop(v_fs_24156);
            return heff_tag_at_n(v_ru_24it_24154_24MkFields, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24430}), v_st_24429});
          }
          case TAG_Right: {
            V v_x_24431 = heff_field(v_x11_24428, 0);
            heff_take_n(v_x11_24428, 1ULL, 1);
            V v_t_24432 = (g_list_2emap_24s513201124x806973253(v_fs_24156));
            V v_x_24433 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24431, v_t_24432));
            return heff_tag_at_n(v_ru_24it_24154_24MkFields, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24433}), v_st_24429});
          }
          default: return heff_nomatch(v_x11_24428);
          }
        }
        default: return heff_nomatch(v_x1_24427);
        }
      }
      case TAG_EAlt: {
        V v_m_24437 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24155}));
        V v_x1_24438 = heff_tr(heff_call(v_m_24437, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24438)) {
        case TAG_MkPair: {
          V v_x11_24439 = heff_field(v_x1_24438, 0);
          V v_st_24440 = heff_field(v_x1_24438, 1);
          heff_take_n(v_x1_24438, 3ULL, 2);
          switch (heff_tag_of(v_x11_24439)) {
          case TAG_Left: {
            V v_e_24441 = heff_field(v_x11_24439, 0);
            heff_take_n(v_x11_24439, 1ULL, 1);
            heff_drop(v_fs_24156);
            return heff_tag_at_n(v_ru_24it_24154_24MkFields, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24441}), v_st_24440});
          }
          case TAG_Right: {
            V v_x_24442 = heff_field(v_x11_24439, 0);
            heff_take_n(v_x11_24439, 1ULL, 1);
            V v_t_24443 = (g_list_2emap_24s513201124x806973253(v_fs_24156));
            V v_x_24444 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24442, v_t_24443));
            return heff_tag_at_n(v_ru_24it_24154_24MkFields, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24444}), v_st_24440});
          }
          default: return heff_nomatch(v_x11_24439);
          }
        }
        default: return heff_nomatch(v_x1_24438);
        }
      }
      case TAG_If: {
        V v_m_24451 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24155}));
        V v_x1_24452 = heff_tr(heff_call(v_m_24451, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24452)) {
        case TAG_MkPair: {
          V v_x11_24453 = heff_field(v_x1_24452, 0);
          V v_st_24454 = heff_field(v_x1_24452, 1);
          heff_take_n(v_x1_24452, 3ULL, 2);
          switch (heff_tag_of(v_x11_24453)) {
          case TAG_Left: {
            V v_e_24455 = heff_field(v_x11_24453, 0);
            heff_take_n(v_x11_24453, 1ULL, 1);
            heff_drop(v_fs_24156);
            return heff_tag_at_n(v_ru_24it_24154_24MkFields, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24455}), v_st_24454});
          }
          case TAG_Right: {
            V v_x_24456 = heff_field(v_x11_24453, 0);
            heff_take_n(v_x11_24453, 1ULL, 1);
            V v_t_24457 = (g_list_2emap_24s513201124x806973253(v_fs_24156));
            V v_x_24458 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24456, v_t_24457));
            return heff_tag_at_n(v_ru_24it_24154_24MkFields, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24458}), v_st_24454});
          }
          default: return heff_nomatch(v_x11_24453);
          }
        }
        default: return heff_nomatch(v_x1_24452);
        }
      }
      case TAG_Do: {
        V v_m_24461 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24155}));
        V v_x1_24462 = heff_tr(heff_call(v_m_24461, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24462)) {
        case TAG_MkPair: {
          V v_x11_24463 = heff_field(v_x1_24462, 0);
          V v_st_24464 = heff_field(v_x1_24462, 1);
          heff_take_n(v_x1_24462, 3ULL, 2);
          switch (heff_tag_of(v_x11_24463)) {
          case TAG_Left: {
            V v_e_24465 = heff_field(v_x11_24463, 0);
            heff_take_n(v_x11_24463, 1ULL, 1);
            heff_drop(v_fs_24156);
            return heff_tag_at_n(v_ru_24it_24154_24MkFields, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24465}), v_st_24464});
          }
          case TAG_Right: {
            V v_x_24466 = heff_field(v_x11_24463, 0);
            heff_take_n(v_x11_24463, 1ULL, 1);
            V v_t_24467 = (g_list_2emap_24s513201124x806973253(v_fs_24156));
            V v_x_24468 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24466, v_t_24467));
            return heff_tag_at_n(v_ru_24it_24154_24MkFields, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24468}), v_st_24464});
          }
          default: return heff_nomatch(v_x11_24463);
          }
        }
        default: return heff_nomatch(v_x1_24462);
        }
      }
      case TAG_ESBind: {
        V v_m_24472 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24155}));
        V v_x1_24473 = heff_tr(heff_call(v_m_24472, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24473)) {
        case TAG_MkPair: {
          V v_x11_24474 = heff_field(v_x1_24473, 0);
          V v_st_24475 = heff_field(v_x1_24473, 1);
          heff_take_n(v_x1_24473, 3ULL, 2);
          switch (heff_tag_of(v_x11_24474)) {
          case TAG_Left: {
            V v_e_24476 = heff_field(v_x11_24474, 0);
            heff_take_n(v_x11_24474, 1ULL, 1);
            heff_drop(v_fs_24156);
            return heff_tag_at_n(v_ru_24it_24154_24MkFields, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24476}), v_st_24475});
          }
          case TAG_Right: {
            V v_x_24477 = heff_field(v_x11_24474, 0);
            heff_take_n(v_x11_24474, 1ULL, 1);
            V v_t_24478 = (g_list_2emap_24s513201124x806973253(v_fs_24156));
            V v_x_24479 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24477, v_t_24478));
            return heff_tag_at_n(v_ru_24it_24154_24MkFields, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24479}), v_st_24475});
          }
          default: return heff_nomatch(v_x11_24474);
          }
        }
        default: return heff_nomatch(v_x1_24473);
        }
      }
      case TAG_ELet: {
        V v_m_24486 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24155}));
        V v_x1_24487 = heff_tr(heff_call(v_m_24486, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24487)) {
        case TAG_MkPair: {
          V v_x11_24488 = heff_field(v_x1_24487, 0);
          V v_st_24489 = heff_field(v_x1_24487, 1);
          heff_take_n(v_x1_24487, 3ULL, 2);
          switch (heff_tag_of(v_x11_24488)) {
          case TAG_Left: {
            V v_e_24490 = heff_field(v_x11_24488, 0);
            heff_take_n(v_x11_24488, 1ULL, 1);
            heff_drop(v_fs_24156);
            return heff_tag_at_n(v_ru_24it_24154_24MkFields, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24490}), v_st_24489});
          }
          case TAG_Right: {
            V v_x_24491 = heff_field(v_x11_24488, 0);
            heff_take_n(v_x11_24488, 1ULL, 1);
            V v_t_24492 = (g_list_2emap_24s513201124x806973253(v_fs_24156));
            V v_x_24493 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24491, v_t_24492));
            return heff_tag_at_n(v_ru_24it_24154_24MkFields, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24493}), v_st_24489});
          }
          default: return heff_nomatch(v_x11_24488);
          }
        }
        default: return heff_nomatch(v_x1_24487);
        }
      }
      default: return heff_nomatch(v_it1_24155);
      }
    }
    default: return heff_nomatch(v_it_24154);
    }
  }
  case TAG_ENeg: {
    V v_m_24494 = heff_field(v_e0_241, 0);
    V v_e_24495 = heff_field(v_e0_241, 1);
    V v_ru_24e0_241_24ENeg = heff_take_reuse_n(v_e0_241, 3ULL, 2);
    V v_m_24496 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_24495}));
    V v_x1_24497 = heff_tr(heff_call(v_m_24496, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x1_24497)) {
    case TAG_MkPair: {
      V v_x11_24498 = heff_field(v_x1_24497, 0);
      V v_st_24499 = heff_field(v_x1_24497, 1);
      V v_ru_24x1_24497_24MkPair = heff_take_reuse_n(v_x1_24497, 3ULL, 2);
      switch (heff_tag_of(v_x11_24498)) {
      case TAG_Left: {
        V v_e_24500 = heff_field(v_x11_24498, 0);
        heff_take_n(v_x11_24498, 1ULL, 1);
        heff_drop_rec(v_m_24494, 9);
        heff_drop_cell(v_ru_24x1_24497_24MkPair, 2);
        return heff_tag_at_n(v_ru_24e0_241_24ENeg, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24500}), v_st_24499});
      }
      case TAG_Right: {
        V v_x_24501 = heff_field(v_x11_24498, 0);
        heff_take_n(v_x11_24498, 1ULL, 1);
        V v_t_24502 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_m_24494, 3), heff_get_n(v_m_24494, 4, 9)});
        V v_t_24503 = heff_tag_at_n(v_ru_24e0_241_24ENeg, TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2eexprL_str20)}), v_t_24502});
        V v_t_24504 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_24501, NTAG(TAG_Nil)});
        V v_x_24505 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_24503, v_t_24504));
        return heff_tag_at_n(v_ru_24x1_24497_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24505}), v_st_24499});
      }
      default: return heff_nomatch(v_x11_24498);
      }
    }
    default: return heff_nomatch(v_x1_24497);
    }
  }
  case TAG_App: {
    V v_h_24506 = heff_field(v_e0_241, 0);
    V v_args_24507 = heff_field(v_e0_241, 1);
    V v_ru_24e0_241_24App = heff_take_reuse_n(v_e0_241, 3ULL, 2);
    V v_m_24508 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_h_24506}));
    V v_x1_24509 = heff_tr(heff_call(v_m_24508, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x1_24509)) {
    case TAG_MkPair: {
      V v_x11_24510 = heff_field(v_x1_24509, 0);
      V v_st_24511 = heff_field(v_x1_24509, 1);
      heff_take_n(v_x1_24509, 3ULL, 2);
      switch (heff_tag_of(v_x11_24510)) {
      case TAG_Left: {
        V v_e_24512 = heff_field(v_x11_24510, 0);
        heff_take_n(v_x11_24510, 1ULL, 1);
        heff_drop_rec(v_r_240, 3);
        heff_drop(v_args_24507);
        return heff_tag_at_n(v_ru_24e0_241_24App, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24512}), v_st_24511});
      }
      case TAG_Right: {
        V v_x_24513 = heff_field(v_x11_24510, 0);
        heff_take_n(v_x11_24510, 1ULL, 1);
        V v_m_24515 = (g_heff_2esyntax_2esurface_2etraverseS(heff_clo_n(g_heff_2esyntax_2esurface_2eexprL_lam4, 1, 1, (V[]){v_r_240}), v_args_24507));
        V v_x1_24516 = heff_tr(heff_call(v_m_24515, 1, (V[]){v_st_24511}));
        switch (heff_tag_of(v_x1_24516)) {
        case TAG_MkPair: {
          V v_x11_24517 = heff_field(v_x1_24516, 0);
          V v_st_24518 = heff_field(v_x1_24516, 1);
          heff_take_n(v_x1_24516, 3ULL, 2);
          switch (heff_tag_of(v_x11_24517)) {
          case TAG_Left: {
            V v_e_24519 = heff_field(v_x11_24517, 0);
            heff_take_n(v_x11_24517, 1ULL, 1);
            heff_drop(v_x_24513);
            return heff_tag_at_n(v_ru_24e0_241_24App, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24519}), v_st_24518});
          }
          case TAG_Right: {
            V v_x_24520 = heff_field(v_x11_24517, 0);
            heff_take_n(v_x11_24517, 1ULL, 1);
            V v_x_24521 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24513, v_x_24520));
            return heff_tag_at_n(v_ru_24e0_241_24App, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24521}), v_st_24518});
          }
          default: return heff_nomatch(v_x11_24517);
          }
        }
        default: return heff_nomatch(v_x1_24516);
        }
      }
      default: return heff_nomatch(v_x11_24510);
      }
    }
    default: return heff_nomatch(v_x1_24509);
    }
  }
  case TAG_Op: {
    V v_a_24522 = heff_field(v_e0_241, 0);
    V v_op_24523 = heff_field(v_e0_241, 1);
    V v_b_24524 = heff_field(v_e0_241, 2);
    heff_take_n(v_e0_241, 7ULL, 3);
    return (g_heff_2esyntax_2esurface_2eopL(v_r_240, v_a_24522, v_op_24523, v_b_24524, v_z_242));
  }
  case TAG_Ops: {
    V v_a_24525 = heff_field(v_e0_241, 0);
    V v_rest_24526 = heff_field(v_e0_241, 1);
    V v_ru_24e0_241_24Ops = heff_take_reuse_n(v_e0_241, 3ULL, 2);
    V v_m_24527 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_24525}));
    V v_x1_24528 = heff_tr(heff_call(v_m_24527, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x1_24528)) {
    case TAG_MkPair: {
      V v_x11_24529 = heff_field(v_x1_24528, 0);
      V v_st_24530 = heff_field(v_x1_24528, 1);
      heff_take_n(v_x1_24528, 3ULL, 2);
      switch (heff_tag_of(v_x11_24529)) {
      case TAG_Left: {
        V v_e_24531 = heff_field(v_x11_24529, 0);
        heff_take_n(v_x11_24529, 1ULL, 1);
        heff_drop_rec(v_r_240, 3);
        heff_drop(v_rest_24526);
        return heff_tag_at_n(v_ru_24e0_241_24Ops, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24531}), v_st_24530});
      }
      case TAG_Right: {
        V v_x_24532 = heff_field(v_x11_24529, 0);
        heff_take_n(v_x11_24529, 1ULL, 1);
        V v_m_24545 = (g_heff_2esyntax_2esurface_2etraverseS(heff_clo_n(g_heff_2esyntax_2esurface_2eexprL_lam5, 1, 1, (V[]){v_r_240}), v_rest_24526));
        V v_x1_24546 = heff_tr(heff_call(v_m_24545, 1, (V[]){v_st_24530}));
        switch (heff_tag_of(v_x1_24546)) {
        case TAG_MkPair: {
          V v_x11_24547 = heff_field(v_x1_24546, 0);
          V v_st_24548 = heff_field(v_x1_24546, 1);
          heff_take_n(v_x1_24546, 3ULL, 2);
          switch (heff_tag_of(v_x11_24547)) {
          case TAG_Left: {
            V v_e_24549 = heff_field(v_x11_24547, 0);
            heff_take_n(v_x11_24547, 1ULL, 1);
            heff_drop(v_x_24532);
            return heff_tag_at_n(v_ru_24e0_241_24Ops, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24549}), v_st_24548});
          }
          case TAG_Right: {
            V v_x_24550 = heff_field(v_x11_24547, 0);
            heff_take_n(v_x11_24547, 1ULL, 1);
            heff_drop_cell(v_ru_24e0_241_24Ops, 2);
            HEFF_LAST return g_heff_2esyntax_2esurface_2eresolve_24s1832151779x1448561609(v_x_24532, v_x_24550, v_st_24548);
          }
          default: return heff_nomatch(v_x11_24547);
          }
        }
        default: return heff_nomatch(v_x1_24546);
        }
      }
      default: return heff_nomatch(v_x11_24529);
      }
    }
    default: return heff_nomatch(v_x1_24528);
    }
  }
  case TAG_OpRhs: {
    heff_drop_rec(v_r_240, 3);
    V v_t_24553 = (g_heff_2esyntax_2ecst_2efirstE(v_e0_241));
    V v_t_24554 = ({ V a_0 = v_e0_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e0_241, 2); r_; });
    V v_t_24555 = heff_strAppend(heff_get_n(v_t_24554, 1, 9), ((V)&g_heff_2esyntax_2esurface_2eexprL_str21));
    V v_msg_24556 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eexprL_str22), v_t_24555);
    V v_t_24557 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24553, 3), heff_get_n(v_t_24553, 4, 9)});
    V v_t_24558 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24556, v_t_24557, NTAG(TAG_Nothing)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24558}), v_z_242});
  }
  case TAG_Ann: {
    V v_e_24559 = heff_field(v_e0_241, 0);
    V v_ty_24561 = heff_field(v_e0_241, 2);
    heff_take_n(v_e0_241, 5ULL, 3);
    V v_m_24562 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e_24559}));
    V v_x1_24563 = heff_tr(heff_call(v_m_24562, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x1_24563)) {
    case TAG_MkPair: {
      V v_x11_24564 = heff_field(v_x1_24563, 0);
      V v_st_24565 = heff_field(v_x1_24563, 1);
      V v_ru_24x1_24563_24MkPair = heff_take_reuse_n(v_x1_24563, 3ULL, 2);
      switch (heff_tag_of(v_x11_24564)) {
      case TAG_Left: {
        V v_e_24566 = heff_field(v_x11_24564, 0);
        heff_take_n(v_x11_24564, 1ULL, 1);
        heff_drop_rec(v_r_240, 3);
        heff_drop(v_ty_24561);
        return heff_tag_at_n(v_ru_24x1_24563_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24566}), v_st_24565});
      }
      case TAG_Right: {
        V v_x_24567 = heff_field(v_x11_24564, 0);
        heff_take_n(v_x11_24564, 1ULL, 1);
        V v_m_24568 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_ty_24561}));
        V v_x1_24569 = heff_tr(heff_call(v_m_24568, 1, (V[]){v_st_24565}));
        switch (heff_tag_of(v_x1_24569)) {
        case TAG_MkPair: {
          V v_x11_24570 = heff_field(v_x1_24569, 0);
          V v_st_24571 = heff_field(v_x1_24569, 1);
          V v_ru_24x1_24569_24MkPair = heff_take_reuse_n(v_x1_24569, 3ULL, 2);
          switch (heff_tag_of(v_x11_24570)) {
          case TAG_Left: {
            V v_e_24572 = heff_field(v_x11_24570, 0);
            heff_take_n(v_x11_24570, 1ULL, 1);
            heff_drop(v_x_24567);
            heff_drop_cell(v_ru_24x1_24569_24MkPair, 2);
            return heff_tag_at_n(v_ru_24x1_24563_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24572}), v_st_24571});
          }
          case TAG_Right: {
            V v_x_24573 = heff_field(v_x11_24570, 0);
            heff_take_n(v_x11_24570, 1ULL, 1);
            V v_t_24576;
            switch (heff_tag_of(v_x_24567)) {
            case TAG_At: {
              V v_s_24575 = heff_dup(heff_field(v_x_24567, 1));
              v_t_24576 = v_s_24575;
              break;
            }
            default: heff_nomatch(v_x_24567);
            }
            V v_t_24579;
            switch (heff_tag_of(v_x_24573)) {
            case TAG_At: {
              V v_s_24578 = heff_dup(heff_field(v_x_24573, 1));
              v_t_24579 = v_s_24578;
              break;
            }
            default: heff_nomatch(v_x_24573);
            }
            V v_t_24580 = ({ V rv_1 = heff_get_n(v_t_24579, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24576, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
            V v_t_24581 = heff_tag_at_n(v_ru_24x1_24569_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_EAnn, 2, (V[]){v_x_24567, v_x_24573}), v_t_24580});
            return heff_tag_at_n(v_ru_24x1_24563_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24581}), v_st_24571});
          }
          default: return heff_nomatch(v_x11_24570);
          }
        }
        default: return heff_nomatch(v_x1_24569);
        }
      }
      default: return heff_nomatch(v_x11_24564);
      }
    }
    default: return heff_nomatch(v_x1_24563);
    }
  }
  case TAG_BVar: {
    heff_drop_rec(v_r_240, 3);
    V v_t_24583 = (g_heff_2esyntax_2ecst_2efirstE(v_e0_241));
    V v_t_24584 = ({ V a_0 = v_e0_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e0_241, 1); r_; });
    V v_t_24585 = heff_strAppend(heff_get_n(v_t_24584, 1, 9), ((V)&g_heff_2esyntax_2esurface_2eexprL_str23));
    V v_msg_24586 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eexprL_str24), v_t_24585);
    V v_t_24587 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24583, 3), heff_get_n(v_t_24583, 4, 9)});
    V v_t_24588 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24586, v_t_24587, NTAG(TAG_Nothing)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24588}), v_z_242});
  }
  case TAG_BImp: {
    heff_drop_rec(v_r_240, 3);
    V v_t_24592 = (g_heff_2esyntax_2ecst_2efirstE(v_e0_241));
    V v_t_24593 = ({ V a_0 = v_e0_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e0_241, 3); r_; });
    V v_t_24594 = heff_strAppend(heff_get_n(v_t_24593, 1, 9), ((V)&g_heff_2esyntax_2esurface_2eexprL_str25));
    V v_msg_24595 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eexprL_str26), v_t_24594);
    V v_t_24596 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24592, 3), heff_get_n(v_t_24592, 4, 9)});
    V v_t_24597 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24595, v_t_24596, NTAG(TAG_Nothing)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24597}), v_z_242});
  }
  case TAG_BAnn: {
    heff_drop_rec(v_r_240, 3);
    V v_t_24603 = (g_heff_2esyntax_2ecst_2efirstE(v_e0_241));
    V v_t_24604 = ({ V a_0 = v_e0_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e0_241, 5); r_; });
    V v_t_24605 = heff_strAppend(heff_get_n(v_t_24604, 1, 9), ((V)&g_heff_2esyntax_2esurface_2eexprL_str27));
    V v_msg_24606 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eexprL_str28), v_t_24605);
    V v_t_24607 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24603, 3), heff_get_n(v_t_24603, 4, 9)});
    V v_t_24608 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24606, v_t_24607, NTAG(TAG_Nothing)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24608}), v_z_242});
  }
  case TAG_Lam: {
    V v_binders_24610 = heff_field(v_e0_241, 1);
    V v_body_24612 = heff_field(v_e0_241, 3);
    heff_take_n(v_e0_241, 10ULL, 4);
    return (g_heff_2esyntax_2esurface_2elambdaL(v_r_240, v_binders_24610, v_body_24612, v_z_242));
  }
  case TAG_Case: {
    V v_kw_24613 = heff_dup(heff_field(v_e0_241, 0));
    V v_scrut_24614 = heff_dup(heff_field(v_e0_241, 1));
    V v_alts_24616 = heff_dup(heff_field(v_e0_241, 3));
    V v_m_24617 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_scrut_24614}));
    V v_x1_24618 = heff_tr(heff_call(v_m_24617, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x1_24618)) {
    case TAG_MkPair: {
      V v_x11_24619 = heff_field(v_x1_24618, 0);
      V v_st_24620 = heff_field(v_x1_24618, 1);
      V v_ru_24x1_24618_24MkPair = heff_take_reuse_n(v_x1_24618, 3ULL, 2);
      switch (heff_tag_of(v_x11_24619)) {
      case TAG_Left: {
        V v_e_24621 = heff_field(v_x11_24619, 0);
        heff_take_n(v_x11_24619, 1ULL, 1);
        heff_drop_rec(v_r_240, 3);
        heff_drop_tag(v_e0_241, 4);
        heff_drop_rec(v_kw_24613, 9);
        heff_drop(v_alts_24616);
        return heff_tag_at_n(v_ru_24x1_24618_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24621}), v_st_24620});
      }
      case TAG_Right: {
        V v_x_24622 = heff_field(v_x11_24619, 0);
        heff_take_n(v_x11_24619, 1ULL, 1);
        V v_x1_24624 = (g_heff_2esyntax_2esurface_2eblock(heff_clo_n(g_heff_2esyntax_2esurface_2eexprL_lam7, 1, 1, (V[]){v_r_240}), v_alts_24616, v_st_24620));
        switch (heff_tag_of(v_x1_24624)) {
        case TAG_MkPair: {
          V v_x11_24625 = heff_field(v_x1_24624, 0);
          V v_st_24626 = heff_field(v_x1_24624, 1);
          V v_ru_24x1_24624_24MkPair = heff_take_reuse_n(v_x1_24624, 3ULL, 2);
          switch (heff_tag_of(v_x11_24625)) {
          case TAG_Left: {
            V v_e_24627 = heff_field(v_x11_24625, 0);
            heff_take_n(v_x11_24625, 1ULL, 1);
            heff_drop_tag(v_e0_241, 4);
            heff_drop_rec(v_kw_24613, 9);
            heff_drop(v_x_24622);
            heff_drop_cell(v_ru_24x1_24624_24MkPair, 2);
            return heff_tag_at_n(v_ru_24x1_24618_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24627}), v_st_24626});
          }
          case TAG_Right: {
            V v_x_24628 = heff_field(v_x11_24625, 0);
            heff_take_n(v_x11_24625, 1ULL, 1);
            V v_t_24629 = (g_heff_2esyntax_2ecst_2elastE(v_e0_241));
            V v_e_24630 = heff_get_n(v_t_24629, 4, 9);
            V v_t_24631 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_24613, 3, 9), v_e_24630});
            V v_x_24632 = heff_tag_at_n(v_ru_24x1_24624_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_x_24622, v_x_24628}), v_t_24631});
            return heff_tag_at_n(v_ru_24x1_24618_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24632}), v_st_24626});
          }
          default: return heff_nomatch(v_x11_24625);
          }
        }
        default: return heff_nomatch(v_x1_24624);
        }
      }
      default: return heff_nomatch(v_x11_24619);
      }
    }
    default: return heff_nomatch(v_x1_24618);
    }
  }
  case TAG_EAlt: {
    heff_drop_rec(v_r_240, 3);
    V v_t_24636 = (g_heff_2esyntax_2ecst_2efirstE(v_e0_241));
    V v_t_24637 = ({ V a_0 = v_e0_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e0_241, 3); r_; });
    V v_t_24638 = heff_strAppend(heff_get_n(v_t_24637, 1, 9), ((V)&g_heff_2esyntax_2esurface_2eexprL_str29));
    V v_msg_24639 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eexprL_str30), v_t_24638);
    V v_t_24640 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24636, 3), heff_get_n(v_t_24636, 4, 9)});
    V v_t_24641 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24639, v_t_24640, NTAG(TAG_Nothing)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24641}), v_z_242});
  }
  case TAG_If: {
    V v_kw_24642 = heff_field(v_e0_241, 0);
    V v_c_24643 = heff_field(v_e0_241, 1);
    V v_a_24645 = heff_field(v_e0_241, 3);
    V v_b_24647 = heff_field(v_e0_241, 5);
    heff_take_n(v_e0_241, 43ULL, 6);
    V v_m_24648 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_c_24643}));
    V v_x1_24649 = heff_tr(heff_call(v_m_24648, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x1_24649)) {
    case TAG_MkPair: {
      V v_x11_24650 = heff_field(v_x1_24649, 0);
      V v_st_24651 = heff_field(v_x1_24649, 1);
      V v_ru_24x1_24649_24MkPair = heff_take_reuse_n(v_x1_24649, 3ULL, 2);
      switch (heff_tag_of(v_x11_24650)) {
      case TAG_Left: {
        V v_e_24652 = heff_field(v_x11_24650, 0);
        heff_take_n(v_x11_24650, 1ULL, 1);
        heff_drop_rec(v_r_240, 3);
        heff_drop_rec(v_kw_24642, 9);
        heff_drop(v_a_24645);
        heff_drop(v_b_24647);
        return heff_tag_at_n(v_ru_24x1_24649_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24652}), v_st_24651});
      }
      case TAG_Right: {
        V v_x_24653 = heff_field(v_x11_24650, 0);
        heff_take_n(v_x11_24650, 1ULL, 1);
        V v_m_24654 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_24645}));
        V v_x1_24655 = heff_tr(heff_call(v_m_24654, 1, (V[]){v_st_24651}));
        switch (heff_tag_of(v_x1_24655)) {
        case TAG_MkPair: {
          V v_x11_24656 = heff_field(v_x1_24655, 0);
          V v_st_24657 = heff_field(v_x1_24655, 1);
          heff_take_n(v_x1_24655, 3ULL, 2);
          switch (heff_tag_of(v_x11_24656)) {
          case TAG_Left: {
            V v_e_24658 = heff_field(v_x11_24656, 0);
            heff_take_n(v_x11_24656, 1ULL, 1);
            heff_drop_rec(v_r_240, 3);
            heff_drop_rec(v_kw_24642, 9);
            heff_drop(v_b_24647);
            heff_drop(v_x_24653);
            return heff_tag_at_n(v_ru_24x1_24649_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24658}), v_st_24657});
          }
          case TAG_Right: {
            V v_x_24659 = heff_field(v_x11_24656, 0);
            heff_take_n(v_x11_24656, 1ULL, 1);
            V v_m_24660 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_b_24647)}));
            V v_x1_24661 = heff_tr(heff_call(v_m_24660, 1, (V[]){v_st_24657}));
            switch (heff_tag_of(v_x1_24661)) {
            case TAG_MkPair: {
              V v_x11_24662 = heff_field(v_x1_24661, 0);
              V v_st_24663 = heff_field(v_x1_24661, 1);
              heff_take_n(v_x1_24661, 3ULL, 2);
              switch (heff_tag_of(v_x11_24662)) {
              case TAG_Left: {
                V v_e_24664 = heff_field(v_x11_24662, 0);
                heff_take_n(v_x11_24662, 1ULL, 1);
                heff_drop_rec(v_kw_24642, 9);
                heff_drop(v_b_24647);
                heff_drop(v_x_24653);
                heff_drop(v_x_24659);
                return heff_tag_at_n(v_ru_24x1_24649_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24664}), v_st_24663});
              }
              case TAG_Right: {
                V v_x_24665 = heff_field(v_x11_24662, 0);
                heff_take_n(v_x11_24662, 1ULL, 1);
                V v_t_24666 = (g_heff_2esyntax_2ecst_2elastE(v_b_24647));
                V v_e_24667 = heff_get_n(v_t_24666, 4, 9);
                V v_t_24668 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_24642, 3, 9), v_e_24667});
                V v_x_24669 = (g_heff_2esyntax_2esurface_2eifE(v_t_24668, v_x_24653, v_x_24659, v_x_24665));
                return heff_tag_at_n(v_ru_24x1_24649_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24669}), v_st_24663});
              }
              default: return heff_nomatch(v_x11_24662);
              }
            }
            default: return heff_nomatch(v_x1_24661);
            }
          }
          default: return heff_nomatch(v_x11_24656);
          }
        }
        default: return heff_nomatch(v_x1_24655);
        }
      }
      default: return heff_nomatch(v_x11_24650);
      }
    }
    default: return heff_nomatch(v_x1_24649);
    }
  }
  case TAG_Do: {
    V v_kw_24670 = heff_dup(heff_field(v_e0_241, 0));
    V v_stmts_24671 = heff_dup(heff_field(v_e0_241, 1));
    V v_x1_24673 = (g_heff_2esyntax_2esurface_2eblock(heff_clo_n(g_heff_2esyntax_2esurface_2eexprL_lam8, 1, 1, (V[]){v_r_240}), v_stmts_24671, v_z_242));
    switch (heff_tag_of(v_x1_24673)) {
    case TAG_MkPair: {
      V v_x11_24674 = heff_field(v_x1_24673, 0);
      V v_st_24675 = heff_field(v_x1_24673, 1);
      V v_ru_24x1_24673_24MkPair = heff_take_reuse_n(v_x1_24673, 3ULL, 2);
      switch (heff_tag_of(v_x11_24674)) {
      case TAG_Left: {
        V v_e_24676 = heff_field(v_x11_24674, 0);
        heff_take_n(v_x11_24674, 1ULL, 1);
        heff_drop_tag(v_e0_241, 2);
        heff_drop_rec(v_kw_24670, 9);
        return heff_tag_at_n(v_ru_24x1_24673_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24676}), v_st_24675});
      }
      case TAG_Right: {
        V v_x_24677 = heff_field(v_x11_24674, 0);
        V v_ru_24x11_24674_24Right = heff_take_reuse_n(v_x11_24674, 1ULL, 1);
        V v_t_24678 = (g_heff_2esyntax_2ecst_2elastE(v_e0_241));
        V v_e_24679 = heff_get_n(v_t_24678, 4, 9);
        V v_t_24680 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_24670, 3, 9), v_e_24679});
        V v_x_24681 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24674_24Right, TAG_EDo, 1, (V[]){v_x_24677}), v_t_24680});
        return heff_tag_at_n(v_ru_24x1_24673_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24681}), v_st_24675});
      }
      default: return heff_nomatch(v_x11_24674);
      }
    }
    default: return heff_nomatch(v_x1_24673);
    }
  }
  case TAG_ESBind: {
    heff_drop_rec(v_r_240, 3);
    V v_t_24685 = (g_heff_2esyntax_2ecst_2efirstE(v_e0_241));
    V v_t_24686 = ({ V a_0 = v_e0_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e0_241, 3); r_; });
    V v_t_24687 = heff_strAppend(heff_get_n(v_t_24686, 1, 9), ((V)&g_heff_2esyntax_2esurface_2eexprL_str31));
    V v_msg_24688 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eexprL_str32), v_t_24687);
    V v_t_24689 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24685, 3), heff_get_n(v_t_24685, 4, 9)});
    V v_t_24690 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24688, v_t_24689, NTAG(TAG_Nothing)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24690}), v_z_242});
  }
  case TAG_ELet: {
    HEFF_LAST return g_heff_2esyntax_2esurface_2eletL(v_r_240, v_e0_241, v_z_242);
  }
  default: return heff_nomatch(v_e0_241);
  }
}
V g_heff_2esyntax_2esurface_2eexprL_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2eexprL(a[0], a[1], a[2]);
}
V g_heff_2esyntax_2esurface_2eexprL_lam0(V self, V *args) {
  V v_m_2430 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2esyntax_2esurface_2esegmentL(v_r_240, v_m_2430));
}
V g_heff_2esyntax_2esurface_2eexprL_lam1(V self, V *args) {
  V v_x_2448 = args[0];
  V v_rest_2449 = args[1];
  V v_sp_2446 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2450 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ETag, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2eexprL_str7)}), v_sp_2446});
  V v_t_2451 = heff_tag_n(TAG_Cons, 2, (V[]){v_rest_2449, NTAG(TAG_Nil)});
  return (g_heff_2esyntax_2epresyntax_2eapp(v_t_2450, heff_tag_n(TAG_Cons, 2, (V[]){v_x_2448, v_t_2451})));
}
V g_heff_2esyntax_2esurface_2eexprL_lam2(V self, V *args) {
  V v_m_2486 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2esyntax_2esurface_2eupdateSettingL(v_r_240, v_m_2486));
}
V g_heff_2esyntax_2esurface_2eexprL_lam3(V self, V *args) {
  V v_a_24140 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2esyntax_2esurface_2evariantL(v_r_240, v_a_24140));
}
V g_heff_2esyntax_2esurface_2eexprL_lam4(V self, V *args) {
  V v_m_24514 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2esyntax_2esurface_2eargL(v_r_240, v_m_24514));
}
V g_heff_2esyntax_2esurface_2eexprL_lam6(V self, V *args) {
  V v_st_24538 = args[0];
  V v_m_24537 = heff_env(self)[0];
  V v_op_24535 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24539 = heff_tr(heff_call(v_m_24537, 1, (V[]){v_st_24538}));
  switch (heff_tag_of(v_x1_24539)) {
  case TAG_MkPair: {
    V v_x11_24540 = heff_field(v_x1_24539, 0);
    V v_st_24541 = heff_field(v_x1_24539, 1);
    V v_ru_24x1_24539_24MkPair = heff_take_reuse_n(v_x1_24539, 3ULL, 2);
    switch (heff_tag_of(v_x11_24540)) {
    case TAG_Left: {
      V v_e_24542 = heff_field(v_x11_24540, 0);
      heff_take_n(v_x11_24540, 1ULL, 1);
      heff_drop(v_op_24535);
      return heff_tag_at_n(v_ru_24x1_24539_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24542}), v_st_24541});
    }
    case TAG_Right: {
      V v_x_24543 = heff_field(v_x11_24540, 0);
      V v_ru_24x11_24540_24Right = heff_take_reuse_n(v_x11_24540, 1ULL, 1);
      V v_t_24544 = heff_tag_at_n(v_ru_24x11_24540_24Right, TAG_Right, 1, (V[]){heff_rec_n(2, shape_op__e, (V[]){v_op_24535, v_x_24543})});
      return heff_tag_at_n(v_ru_24x1_24539_24MkPair, TAG_MkPair, 2, (V[]){v_t_24544, v_st_24541});
    }
    default: return heff_nomatch(v_x11_24540);
    }
  }
  default: return heff_nomatch(v_x1_24539);
  }
}
V g_heff_2esyntax_2esurface_2eexprL_lam5(V self, V *args) {
  V v_m_24533 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24534 = (g_heff_2esyntax_2esurface_2eopRhsOf(v_m_24533));
  switch (heff_tag_of(v_t_24534)) {
  case TAG_MkPair: {
    V v_op_24535 = heff_field(v_t_24534, 0);
    V v_e_24536 = heff_field(v_t_24534, 1);
    heff_take_n(v_t_24534, 3ULL, 2);
    V v_m_24537 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_24536}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2eexprL_lam6, 1, 2, (V[]){v_m_24537, v_op_24535});
  }
  default: return heff_nomatch(v_t_24534);
  }
}
V g_heff_2esyntax_2esurface_2eexprL_lam7(V self, V *args) {
  V v_a_24623 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2esyntax_2esurface_2ealtL(v_r_240, v_a_24623));
}
V g_heff_2esyntax_2esurface_2eexprL_lam8(V self, V *args) {
  V v_m_24672 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2esyntax_2esurface_2estmtL(v_r_240, v_m_24672));
}
V g_heff_2esyntax_2esurface_2edefaultL_lam0(V self, V *args); static Clo g_heff_2esyntax_2esurface_2edefaultL_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2edefaultL_lam0, 1, 0};
V g_heff_2esyntax_2esurface_2edefaultL_lam1(V self, V *args);
Clo g_heff_2esyntax_2esurface_2edefaultL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2edefaultL_entry, 2, 0};

V g_heff_2esyntax_2esurface_2edefaultL(V v_r_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nothing: {
    heff_drop_rec(v_r_240, 3);
    return ((V)&g_heff_2esyntax_2esurface_2edefaultL_lam0_clo);
  }
  case TAG_Just: {
    V v_x21_244 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    switch (heff_tag_of(v_x21_244)) {
    case TAG_MkPair: {
      V v_d_246 = heff_field(v_x21_244, 1);
      heff_take_n(v_x21_244, 2ULL, 2);
      V v_m_247 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_d_246}));
      return heff_clo_n(g_heff_2esyntax_2esurface_2edefaultL_lam1, 1, 1, (V[]){v_m_247});
    }
    default: return heff_nomatch(v_x21_244);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2esurface_2edefaultL_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2edefaultL(a[0], a[1]);
}
V g_heff_2esyntax_2esurface_2edefaultL_lam0(V self, V *args) {
  V v_st_242 = args[0];
  V v_t_243 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_243, v_st_242});
}
V g_heff_2esyntax_2esurface_2edefaultL_lam1(V self, V *args) {
  V v_st_248 = args[0];
  V v_m_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_249 = heff_tr(heff_call(v_m_247, 1, (V[]){v_st_248}));
  switch (heff_tag_of(v_x1_249)) {
  case TAG_MkPair: {
    V v_x11_2410 = heff_field(v_x1_249, 0);
    V v_st_2411 = heff_field(v_x1_249, 1);
    V v_ru_24x1_249_24MkPair = heff_take_reuse_n(v_x1_249, 3ULL, 2);
    switch (heff_tag_of(v_x11_2410)) {
    case TAG_Left: {
      V v_e_2412 = heff_field(v_x11_2410, 0);
      heff_take_n(v_x11_2410, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_249_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2412}), v_st_2411});
    }
    case TAG_Right: {
      V v_x_2413 = heff_field(v_x11_2410, 0);
      V v_ru_24x11_2410_24Right = heff_take_reuse_n(v_x11_2410, 1ULL, 1);
      V v_t_2414 = heff_tag_at_n(v_ru_24x11_2410_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Just, 1, (V[]){v_x_2413})});
      return heff_tag_at_n(v_ru_24x1_249_24MkPair, TAG_MkPair, 2, (V[]){v_t_2414, v_st_2411});
    }
    default: return heff_nomatch(v_x11_2410);
    }
  }
  default: return heff_nomatch(v_x1_249);
  }
}