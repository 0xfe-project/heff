// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Ann 13421
#define TAG_App 13485
#define TAG_At 8900
#define TAG_Atom 28502
#define TAG_BAnn 9252
#define TAG_BImp 16911
#define TAG_BVar 29034
#define TAG_Braces 8205
#define TAG_Case 4415
#define TAG_Do 8988
#define TAG_EAlt 33043
#define TAG_EAnn 33099
#define TAG_EAssign 4102
#define TAG_EBinary 42634
#define TAG_EBreak 7195
#define TAG_ECon 35052
#define TAG_EContinue 48638
#define TAG_EDo 15964
#define TAG_EFDefault 38038
#define TAG_EFSet 34673
#define TAG_EField 26142
#define TAG_EFor 37939
#define TAG_EIfThen 2245
#define TAG_EInvalid 31081
#define TAG_EJump 55703
#define TAG_ELet 43397
#define TAG_ELetIn 22786
#define TAG_ELetMut 54984
#define TAG_EMatch 41631
#define TAG_ENeg 45306
#define TAG_ENest 28629
#define TAG_EParen 58248
#define TAG_EReturn 59059
#define TAG_ESBind 62182
#define TAG_ESum 50613
#define TAG_ETag 50948
#define TAG_EUSet 22856
#define TAG_EUpdate 6986
#define TAG_EVar 52881
#define TAG_EWhile 39339
#define TAG_FloatValue 23118
#define TAG_If 9134
#define TAG_IfThen 36069
#define TAG_InstB 37114
#define TAG_IntValue 62477
#define TAG_Lam 23588
#define TAG_Left 13886
#define TAG_MkAlt 55173
#define TAG_MkSegment 38079
#define TAG_Named 2049
#define TAG_Op 9330
#define TAG_OpRhs 36076
#define TAG_Ops 26942
#define TAG_OtherValue 43098
#define TAG_Right 62770
#define TAG_RuneValue 49425
#define TAG_SError 24172
#define TAG_Seg 30433
#define TAG_SegmentBinary 41188
#define TAG_SegmentBits 43687
#define TAG_SegmentFloat 21180
#define TAG_SegmentInteger 22664
#define TAG_SegmentUtf 5205
#define TAG_SizeDefault 11444
#define TAG_StrValue 22621
#define TAG_Sum 30935
#define TAG_Tup 31899
#define TAG_Update 40810
#define LBL_code 9554612
#define LBL_e 319
#define LBL_end 310101
#define LBL_errors 652506774
#define LBL_fixities 357800079
#define LBL_kind 9787483
#define LBL_known 303562589
#define LBL_lenient 294367673
#define LBL_little 844663329
#define LBL_msg 317947
#define LBL_note 9882809
#define LBL_op 10312
#define LBL_ops 319788
#define LBL_out 319944
#define LBL_pat 320285
#define LBL_path 9928940
#define LBL_place 308106529
#define LBL_severity 75955546
#define LBL_signed 1044674119
#define LBL_size 10026184
#define LBL_span 10032145
#define LBL_start 311115900
#define LBL_text 10052084
#define LBL_tokens 1078955205
#define LBL_ty 10476
#define LBL_unit 10090059
static uint32_t shape_code__severity__msg__span__note[] = {LBL_code, LBL_severity, LBL_msg, LBL_span, LBL_note};
static uint32_t shape_known__fixities__lenient__place__path[] = {LBL_known, LBL_fixities, LBL_lenient, LBL_place, LBL_path};
static uint32_t shape_op__e[] = {LBL_op, LBL_e};
static uint32_t shape_ops__out[] = {LBL_ops, LBL_out};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
static uint32_t shape_ty__size__unit__little__signed[] = {LBL_ty, LBL_size, LBL_unit, LBL_little, LBL_signed};
V g_heff_2esyntax_2ecst_2efirstE(V);
V g_heff_2esyntax_2ecst_2efirstE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2efirstE_clo;
V g_heff_2esyntax_2ecst_2elastE(V);
V g_heff_2esyntax_2ecst_2elastE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2elastE_clo;
V g_heff_2esyntax_2efixity_2eemptyFixities_get(void);
V g_heff_2esyntax_2efmt_2etokens_2eplainGo(V, V, V);
V g_heff_2esyntax_2efmt_2etokens_2eplainGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2efmt_2etokens_2eplainGo_clo;
V g_heff_2esyntax_2epresyntax_2eapp(V, V);
V g_heff_2esyntax_2epresyntax_2eapp_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eapp_clo;
V g_heff_2esyntax_2esurface_2ealtL(V, V);
V g_heff_2esyntax_2esurface_2ealtL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ealtL_clo;
V g_heff_2esyntax_2esurface_2eapplyOp(V, V, V);
V g_heff_2esyntax_2esurface_2eapplyOp_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eapplyOp_clo;
V g_heff_2esyntax_2esurface_2eargL(V, V);
V g_heff_2esyntax_2esurface_2eargL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eargL_clo;
V g_heff_2esyntax_2esurface_2eatomTok(V);
V g_heff_2esyntax_2esurface_2eatomTok_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eatomTok_clo;
V g_heff_2esyntax_2esurface_2eblock(V, V, V);
V g_heff_2esyntax_2esurface_2eblock_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eblock_clo;
HeffT2 g_heff_2esyntax_2esurface_2eblock_24cpr(V, V, V);
V g_heff_2esyntax_2esurface_2eboundBy(V, V);
V g_heff_2esyntax_2esurface_2eboundBy_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eboundBy_clo;
V g_heff_2esyntax_2esurface_2ebracesL(V, V, V, V, V);
V g_heff_2esyntax_2esurface_2ebracesL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ebracesL_clo;
V g_heff_2esyntax_2esurface_2ecommentLinesFrom(V, V, V);
V g_heff_2esyntax_2esurface_2ecommentLinesFrom_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ecommentLinesFrom_clo;
V g_heff_2esyntax_2esurface_2econAtom(V, V, V);
V g_heff_2esyntax_2esurface_2econAtom_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2econAtom_clo;
V g_heff_2esyntax_2esurface_2econL(V, V, V);
V g_heff_2esyntax_2esurface_2econL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2econL_clo;
V g_heff_2esyntax_2esurface_2edeclarationL(V, V);
V g_heff_2esyntax_2esurface_2edeclarationL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2edeclarationL_clo;
V g_heff_2esyntax_2esurface_2edefaultL(V, V);
V g_heff_2esyntax_2esurface_2edefaultL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2edefaultL_clo;
V g_heff_2esyntax_2esurface_2eexprL(V, V, V);
V g_heff_2esyntax_2esurface_2eexprL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eexprL_clo;
HeffT2 g_heff_2esyntax_2esurface_2efieldsOf_24cpr(V, V);
V g_heff_2esyntax_2esurface_2efirstS(V, V, V, V);
V g_heff_2esyntax_2esurface_2efirstS_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2efirstS_clo;
V g_heff_2esyntax_2esurface_2efixDecls(V, V, V);
V g_heff_2esyntax_2esurface_2efixDecls_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2efixDecls_clo;
V g_heff_2esyntax_2esurface_2efixityFrom_24s1371314581x1750522054(V, V);
V g_heff_2esyntax_2esurface_2efixityFrom_24s1371314581x1750522054_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2efixityFrom_24s1371314581x1750522054_clo;
V g_heff_2esyntax_2esurface_2efoldr(V, V, V);
V g_heff_2esyntax_2esurface_2efoldr_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2efoldr_clo;
V g_heff_2esyntax_2esurface_2eifE(V, V, V, V);
V g_heff_2esyntax_2esurface_2eifE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eifE_clo;
V g_heff_2esyntax_2esurface_2eintOfText(V);
V g_heff_2esyntax_2esurface_2eintOfText_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eintOfText_clo;
V g_heff_2esyntax_2esurface_2ekwAtom(V, V, V);
V g_heff_2esyntax_2esurface_2ekwAtom_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ekwAtom_clo;
V g_heff_2esyntax_2esurface_2elambdaL(V, V, V, V);
V g_heff_2esyntax_2esurface_2elambdaL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2elambdaL_clo;
HeffT2 g_heff_2esyntax_2esurface_2eletBodyL_24cpr(V, V, V, V, V, V);
V g_heff_2esyntax_2esurface_2eletL(V, V, V);
V g_heff_2esyntax_2esurface_2eletL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eletL_clo;
V g_heff_2esyntax_2esurface_2enoKnown(V);
V g_heff_2esyntax_2esurface_2enoKnown_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2enoKnown_clo;
V g_heff_2esyntax_2esurface_2eopL(V, V, V, V, V);
V g_heff_2esyntax_2esurface_2eopL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eopL_clo;
HeffT2 g_heff_2esyntax_2esurface_2eopRhsOf_24cpr(V);
V g_heff_2esyntax_2esurface_2eparenL(V, V, V, V, V);
V g_heff_2esyntax_2esurface_2eparenL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eparenL_clo;
V g_heff_2esyntax_2esurface_2eprescanGo(V, V, V);
V g_heff_2esyntax_2esurface_2eprescanGo_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eprescanGo_clo;
V g_heff_2esyntax_2esurface_2epushS_24s1868233564x1858628873(V, V, V, V);
V g_heff_2esyntax_2esurface_2epushS_24s1868233564x1858628873_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2epushS_24s1868233564x1858628873_clo;
HeffT4 g_heff_2esyntax_2esurface_2ereadLexed_24s350283117x1909926642_24cpr(V, V, V, V);
HeffT4 g_heff_2esyntax_2esurface_2ereadRun_24cpr(V, V, V, V, V, V);
V g_heff_2esyntax_2esurface_2eresolve_24s1832151779x1448561609(V, V, V);
V g_heff_2esyntax_2esurface_2eresolve_24s1832151779x1448561609_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eresolve_24s1832151779x1448561609_clo;
V g_heff_2esyntax_2esurface_2esegmentL(V, V);
V g_heff_2esyntax_2esurface_2esegmentL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2esegmentL_clo;
V g_heff_2esyntax_2esurface_2esegmentOf_24s1547151193x813882637(V, V, V, V, V);
V g_heff_2esyntax_2esurface_2esegmentOf_24s1547151193x813882637_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2esegmentOf_24s1547151193x813882637_clo;
V g_heff_2esyntax_2esurface_2especWord(V, V, V);
V g_heff_2esyntax_2esurface_2especWord_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2especWord_clo;
V g_heff_2esyntax_2esurface_2estmtL(V, V);
V g_heff_2esyntax_2esurface_2estmtL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2estmtL_clo;
V g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993(V, V, V, V, V);
V g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_clo;
V g_heff_2esyntax_2esurface_2eunitOf(V, V, V);
V g_heff_2esyntax_2esurface_2eunitOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eunitOf_clo;
V g_heff_2esyntax_2esurface_2eupdateSettingL(V, V);
V g_heff_2esyntax_2esurface_2eupdateSettingL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eupdateSettingL_clo;
HeffT2 g_heff_2esyntax_2esurface_2evalueKind_24cpr(V, V, V, V);
V g_heff_2esyntax_2esurface_2evariantL(V, V);
V g_heff_2esyntax_2esurface_2evariantL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2evariantL_clo;
HeffT2 g_heff_2esyntax_2esurface_2ewithScope_24cpr(V, V, V);
V g_list_2emap_24s338694954x1326523169(V);
V g_list_2emap_24s338694954x1326523169_entry(V self, V *a);
extern Clo g_list_2emap_24s338694954x1326523169_clo;
V g_list_2emap_24s513201124x806973253(V);
V g_list_2emap_24s513201124x806973253_entry(V self, V *a);
extern Clo g_list_2emap_24s513201124x806973253_clo;
V g_prelude_2eskipSpaces(V, V, V);
V g_prelude_2eskipSpaces_entry(V self, V *a);
extern Clo g_prelude_2eskipSpaces_clo;
V g_prelude_2etraverse_24s499544530x2060473942(V, V);
V g_prelude_2etraverse_24s499544530x2060473942_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s499544530x2060473942_clo;
HEFF_LIT(g_heff_2esyntax_2esurface_2ecommentLinesFrom_str0, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecommentLinesFrom_str1, 2, "--");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecommentLinesFrom_str2, 1, "\012");
Clo g_heff_2esyntax_2esurface_2ecommentLinesFrom_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2ecommentLinesFrom_entry, 3, 0};

V g_heff_2esyntax_2esurface_2ecommentLinesFrom(V v_src_240, V v_i_241, V v_to_242) {
top: ;
  if (heff_intLe_c_lent(v_to_242, v_i_241, 0)) {
    heff_drop(v_i_241);
    heff_drop(v_to_242);
    return NTAG(TAG_True);
  } else {
    V v_j_244 = heff_strFind_lent(((V)&g_heff_2esyntax_2esurface_2ecommentLinesFrom_str0), v_src_240, v_i_241, 1);
    V v_t_246;
    if (heff_intLt_c_lent(v_j_244, MK_INT(0LL), 2)) {
      heff_drop(v_j_244);
      v_t_246 = heff_strLength_lent(v_src_240, 0);
    } else {
      v_t_246 = v_j_244;
    }
    V v_s_247 = heff_strSlice_lent(v_src_240, v_i_241, v_t_246, 4);
    V v_t_248 = (g_prelude_2eskipSpaces(v_s_247, MK_INT(0LL), MK_INT(1LL)));
    int64_t v_t_249 = (heff_unbox_word(heff_strLength_lent(v_s_247, 0)) - ((int64_t)1ULL));
    V v_t_2410 = (g_prelude_2eskipSpaces(v_s_247, heff_box_word(v_t_249), MK_INT(-1LL)));
    V v_s_2411 = heff_strSlice(v_s_247, v_t_248, heff_intAdd(v_t_2410, MK_INT(1LL)));
    if (heff_strEq_c(heff_strSlice(v_s_2411, MK_INT(0LL), MK_INT(2LL)), ((V)&g_heff_2esyntax_2esurface_2ecommentLinesFrom_str1))) {
      V v_j_2413 = heff_strFind_lent(((V)&g_heff_2esyntax_2esurface_2ecommentLinesFrom_str2), v_src_240, v_i_241, 5);
      V v_t_2415;
      if (heff_intLt_c_lent(v_j_2413, MK_INT(0LL), 2)) {
        heff_drop(v_j_2413);
        v_t_2415 = heff_strLength_lent(v_src_240, 0);
      } else {
        v_t_2415 = v_j_2413;
      }
      V t_0 = v_src_240;
      V t_1 = heff_intAdd(v_t_2415, MK_INT(1LL));
      V t_2 = v_to_242;
      v_src_240 = t_0;
      v_i_241 = t_1;
      v_to_242 = t_2;
      goto top;
    } else {
      heff_drop(v_i_241);
      heff_drop(v_to_242);
      return NTAG(TAG_False);
    }
  }
}
V g_heff_2esyntax_2esurface_2ecommentLinesFrom_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2esurface_2ecommentLinesFrom(a0, a[1], a[2]); heff_drop(a0); return r;
}
V g_heff_2esyntax_2esurface_2eletBodyL_24cpr_lam0(V self, V *args);

HeffT2 g_heff_2esyntax_2esurface_2eletBodyL_24cpr(V v_r_240, V v_kw_241, V v_x3_242, V v_names_243, V v_body_244, V v_z_245) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_MkPair: {
    V v_p_246 = heff_field(v_x3_242, 0);
    V v_rhs_247 = heff_field(v_x3_242, 1);
    heff_take_n(v_x3_242, 3ULL, 2);
    V v_m_248 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_body_244)}));
    return (g_heff_2esyntax_2esurface_2ewithScope_24cpr(v_names_243, heff_clo_n(g_heff_2esyntax_2esurface_2eletBodyL_24cpr_lam0, 1, 5, (V[]){v_m_248, v_p_246, v_body_244, v_kw_241, v_rhs_247}), v_z_245));
  }
  default: return ((HeffT2){{heff_nomatch(v_x3_242)}});
  }
}
V g_heff_2esyntax_2esurface_2eletBodyL_24cpr_lam0(V self, V *args) {
  V v_st_249 = args[0];
  V v_m_248 = heff_env(self)[0];
  V v_p_246 = heff_env(self)[1];
  V v_body_244 = heff_env(self)[2];
  V v_kw_241 = heff_env(self)[3];
  V v_rhs_247 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_x1_2410 = heff_tr(heff_call(v_m_248, 1, (V[]){v_st_249}));
  switch (heff_tag_of(v_x1_2410)) {
  case TAG_MkPair: {
    V v_x11_2411 = heff_field(v_x1_2410, 0);
    V v_st_2412 = heff_field(v_x1_2410, 1);
    V v_ru_24x1_2410_24MkPair = heff_take_reuse_n(v_x1_2410, 3ULL, 2);
    switch (heff_tag_of(v_x11_2411)) {
    case TAG_Left: {
      V v_e_2413 = heff_field(v_x11_2411, 0);
      heff_take_n(v_x11_2411, 1ULL, 1);
      heff_drop(v_p_246);
      heff_drop(v_body_244);
      heff_drop_rec(v_kw_241, 9);
      heff_drop(v_rhs_247);
      return heff_tag_at_n(v_ru_24x1_2410_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2413}), v_st_2412});
    }
    case TAG_Right: {
      V v_x_2414 = heff_field(v_x11_2411, 0);
      heff_take_n(v_x11_2411, 1ULL, 1);
      V v_t_2417;
      switch (heff_tag_of(v_p_246)) {
      case TAG_At: {
        V v_s_2416 = heff_dup(heff_field(v_p_246, 1));
        v_t_2417 = v_s_2416;
        break;
      }
      default: heff_nomatch(v_p_246);
      }
      V v_t_2420;
      switch (heff_tag_of(v_x_2414)) {
      case TAG_At: {
        V v_s_2419 = heff_dup(heff_field(v_x_2414, 1));
        v_t_2420 = v_s_2419;
        break;
      }
      default: heff_nomatch(v_x_2414);
      }
      V v_t_2421 = ({ V rv_1 = heff_get_n(v_t_2420, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_2417, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
      V v_t_2422 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_246, v_x_2414}), v_t_2421});
      V v_t_2423 = (g_heff_2esyntax_2ecst_2elastE(v_body_244));
      V v_e_2424 = heff_get_n(v_t_2423, 4, 9);
      V v_t_2425 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_241, 3, 9), v_e_2424});
      V v_x_2426 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ELetIn, 2, (V[]){v_rhs_247, v_t_2422}), v_t_2425});
      return heff_tag_at_n(v_ru_24x1_2410_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2426}), v_st_2412});
    }
    default: return heff_nomatch(v_x11_2411);
    }
  }
  default: return heff_nomatch(v_x1_2410);
  }
}
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str0, 7, "integer");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str1, 28, "a segment says its type once");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str2, 6, "binary");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str3, 5, "bytes");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str4, 28, "a segment says its type once");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str5, 4, "bits");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str6, 9, "bitstring");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str7, 28, "a segment says its type once");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str8, 5, "float");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str9, 28, "a segment says its type once");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str10, 4, "utf8");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str11, 28, "a segment says its type once");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str12, 5, "utf16");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str13, 28, "a segment says its type once");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str14, 5, "utf32");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str15, 28, "a segment says its type once");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str16, 3, "big");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str17, 34, "a segment says its endianness once");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str18, 6, "little");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str19, 34, "a segment says its endianness once");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str20, 6, "signed");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str21, 28, "a segment says its sign once");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str22, 8, "unsigned");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str23, 28, "a segment says its sign once");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str24, 227, "a segment's spec is its type (`integer`, `binary`, `bits`, `float`, `utf8`, `utf16`, `utf32`), size (`16`, `size(n)`), unit (`unit(8)`), endianness (`big`, `little`) and sign (`signed`, `unsigned`), between `-`s: `x::16-little`");
Clo g_heff_2esyntax_2esurface_2especWord_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2especWord_entry, 3, 0};

V g_heff_2esyntax_2esurface_2especWord(V v_t_240, V v_s_241, V v_p_242) {
top: ;
  if (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 1)), ((V)&g_heff_2esyntax_2esurface_2especWord_str0))) {
    V v_t_244 = heff_take_field(v_s_241, 0);
    switch (heff_tag_of(v_t_244)) {
    case TAG_Nothing: {
      heff_drop_rec(v_t_240, 9);
      V v_t_245 = heff_tag_n(TAG_Just, 1, (V[]){NTAG(TAG_SegmentInteger)});
      V v_t_246 = ({ V rv_0 = v_t_245; V rr_ = heff_rec_reuse_nf(v_s_241, 30ULL, 5, shape_ty__size__unit__little__signed, 1020u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_246}), v_p_242});
    }
    case TAG_Just: {
      V v_ru_24t_244_24Just = heff_take_reuse_n(v_t_244, 0ULL, 1);
      heff_drop_rec(v_s_241, 5);
      V v_t_248 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_240, 3), heff_get_n(v_t_240, 4, 9)});
      V v_t_249 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2especWord_str1), v_t_248, NTAG(TAG_Nothing)});
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24t_244_24Just, TAG_Left, 1, (V[]){v_t_249}), v_p_242});
    }
    default: return heff_nomatch(v_t_244);
    }
  } else {
    V v_t_2411 = heff_bool((heff_strEq_c(heff_dup(heff_rfield(v_t_240, 1)), ((V)&g_heff_2esyntax_2esurface_2especWord_str2)) || heff_strEq_c(heff_dup(heff_rfield(v_t_240, 1)), ((V)&g_heff_2esyntax_2esurface_2especWord_str3))));
    if ((heff_dup(v_t_2411) == NTAG(TAG_True))) {
      heff_drop(v_t_2411);
      V v_t_2412 = heff_take_field(v_s_241, 0);
      switch (heff_tag_of(v_t_2412)) {
      case TAG_Nothing: {
        heff_drop_rec(v_t_240, 9);
        V v_t_2413 = heff_tag_n(TAG_Just, 1, (V[]){NTAG(TAG_SegmentBinary)});
        V v_t_2414 = ({ V rv_0 = v_t_2413; V rr_ = heff_rec_reuse_nf(v_s_241, 30ULL, 5, shape_ty__size__unit__little__signed, 1020u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
        return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2414}), v_p_242});
      }
      case TAG_Just: {
        V v_ru_24t_2412_24Just = heff_take_reuse_n(v_t_2412, 0ULL, 1);
        heff_drop_rec(v_s_241, 5);
        V v_t_2416 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_240, 3), heff_get_n(v_t_240, 4, 9)});
        V v_t_2417 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2especWord_str4), v_t_2416, NTAG(TAG_Nothing)});
        return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24t_2412_24Just, TAG_Left, 1, (V[]){v_t_2417}), v_p_242});
      }
      default: return heff_nomatch(v_t_2412);
      }
    } else {
      heff_drop(v_t_2411);
      V v_t_2419 = heff_bool((heff_strEq_c(heff_dup(heff_rfield(v_t_240, 1)), ((V)&g_heff_2esyntax_2esurface_2especWord_str5)) || heff_strEq_c(heff_dup(heff_rfield(v_t_240, 1)), ((V)&g_heff_2esyntax_2esurface_2especWord_str6))));
      if ((heff_dup(v_t_2419) == NTAG(TAG_True))) {
        heff_drop(v_t_2419);
        V v_t_2420 = heff_take_field(v_s_241, 0);
        switch (heff_tag_of(v_t_2420)) {
        case TAG_Nothing: {
          heff_drop_rec(v_t_240, 9);
          V v_t_2421 = heff_tag_n(TAG_Just, 1, (V[]){NTAG(TAG_SegmentBits)});
          V v_t_2422 = ({ V rv_0 = v_t_2421; V rr_ = heff_rec_reuse_nf(v_s_241, 30ULL, 5, shape_ty__size__unit__little__signed, 1020u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
          return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2422}), v_p_242});
        }
        case TAG_Just: {
          V v_ru_24t_2420_24Just = heff_take_reuse_n(v_t_2420, 0ULL, 1);
          heff_drop_rec(v_s_241, 5);
          V v_t_2424 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_240, 3), heff_get_n(v_t_240, 4, 9)});
          V v_t_2425 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2especWord_str7), v_t_2424, NTAG(TAG_Nothing)});
          return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24t_2420_24Just, TAG_Left, 1, (V[]){v_t_2425}), v_p_242});
        }
        default: return heff_nomatch(v_t_2420);
        }
      } else {
        heff_drop(v_t_2419);
        if (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 1)), ((V)&g_heff_2esyntax_2esurface_2especWord_str8))) {
          V v_t_2427 = heff_take_field(v_s_241, 0);
          switch (heff_tag_of(v_t_2427)) {
          case TAG_Nothing: {
            heff_drop_rec(v_t_240, 9);
            V v_t_2428 = heff_tag_n(TAG_Just, 1, (V[]){NTAG(TAG_SegmentFloat)});
            V v_t_2429 = ({ V rv_0 = v_t_2428; V rr_ = heff_rec_reuse_nf(v_s_241, 30ULL, 5, shape_ty__size__unit__little__signed, 1020u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
            return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2429}), v_p_242});
          }
          case TAG_Just: {
            V v_ru_24t_2427_24Just = heff_take_reuse_n(v_t_2427, 0ULL, 1);
            heff_drop_rec(v_s_241, 5);
            V v_t_2431 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_240, 3), heff_get_n(v_t_240, 4, 9)});
            V v_t_2432 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2especWord_str9), v_t_2431, NTAG(TAG_Nothing)});
            return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24t_2427_24Just, TAG_Left, 1, (V[]){v_t_2432}), v_p_242});
          }
          default: return heff_nomatch(v_t_2427);
          }
        } else {
          if (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 1)), ((V)&g_heff_2esyntax_2esurface_2especWord_str10))) {
            V v_t_2434 = heff_take_field(v_s_241, 0);
            switch (heff_tag_of(v_t_2434)) {
            case TAG_Nothing: {
              heff_drop_rec(v_t_240, 9);
              V v_t_2435 = heff_tag_n(TAG_Just, 1, (V[]){heff_tag_n(TAG_SegmentUtf, 1, (V[]){MK_INT(8LL)})});
              V v_t_2436 = ({ V rv_0 = v_t_2435; V rr_ = heff_rec_reuse_nf(v_s_241, 30ULL, 5, shape_ty__size__unit__little__signed, 1020u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
              return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2436}), v_p_242});
            }
            case TAG_Just: {
              V v_ru_24t_2434_24Just = heff_take_reuse_n(v_t_2434, 0ULL, 1);
              heff_drop_rec(v_s_241, 5);
              V v_t_2438 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_240, 3), heff_get_n(v_t_240, 4, 9)});
              V v_t_2439 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2especWord_str11), v_t_2438, NTAG(TAG_Nothing)});
              return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24t_2434_24Just, TAG_Left, 1, (V[]){v_t_2439}), v_p_242});
            }
            default: return heff_nomatch(v_t_2434);
            }
          } else {
            if (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 1)), ((V)&g_heff_2esyntax_2esurface_2especWord_str12))) {
              V v_t_2441 = heff_take_field(v_s_241, 0);
              switch (heff_tag_of(v_t_2441)) {
              case TAG_Nothing: {
                heff_drop_rec(v_t_240, 9);
                V v_t_2442 = heff_tag_n(TAG_Just, 1, (V[]){heff_tag_n(TAG_SegmentUtf, 1, (V[]){MK_INT(16LL)})});
                V v_t_2443 = ({ V rv_0 = v_t_2442; V rr_ = heff_rec_reuse_nf(v_s_241, 30ULL, 5, shape_ty__size__unit__little__signed, 1020u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
                return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2443}), v_p_242});
              }
              case TAG_Just: {
                V v_ru_24t_2441_24Just = heff_take_reuse_n(v_t_2441, 0ULL, 1);
                heff_drop_rec(v_s_241, 5);
                V v_t_2445 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_240, 3), heff_get_n(v_t_240, 4, 9)});
                V v_t_2446 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2especWord_str13), v_t_2445, NTAG(TAG_Nothing)});
                return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24t_2441_24Just, TAG_Left, 1, (V[]){v_t_2446}), v_p_242});
              }
              default: return heff_nomatch(v_t_2441);
              }
            } else {
              if (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 1)), ((V)&g_heff_2esyntax_2esurface_2especWord_str14))) {
                V v_t_2448 = heff_take_field(v_s_241, 0);
                switch (heff_tag_of(v_t_2448)) {
                case TAG_Nothing: {
                  heff_drop_rec(v_t_240, 9);
                  V v_t_2449 = heff_tag_n(TAG_Just, 1, (V[]){heff_tag_n(TAG_SegmentUtf, 1, (V[]){MK_INT(32LL)})});
                  V v_t_2450 = ({ V rv_0 = v_t_2449; V rr_ = heff_rec_reuse_nf(v_s_241, 30ULL, 5, shape_ty__size__unit__little__signed, 1020u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
                  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2450}), v_p_242});
                }
                case TAG_Just: {
                  V v_ru_24t_2448_24Just = heff_take_reuse_n(v_t_2448, 0ULL, 1);
                  heff_drop_rec(v_s_241, 5);
                  V v_t_2452 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_240, 3), heff_get_n(v_t_240, 4, 9)});
                  V v_t_2453 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2especWord_str15), v_t_2452, NTAG(TAG_Nothing)});
                  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24t_2448_24Just, TAG_Left, 1, (V[]){v_t_2453}), v_p_242});
                }
                default: return heff_nomatch(v_t_2448);
                }
              } else {
                if (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 1)), ((V)&g_heff_2esyntax_2esurface_2especWord_str16))) {
                  V v_t_2455 = heff_take_field(v_s_241, 3);
                  switch (heff_tag_of(v_t_2455)) {
                  case TAG_Nothing: {
                    heff_drop_rec(v_t_240, 9);
                    V v_t_2456 = heff_tag_n(TAG_Just, 1, (V[]){NTAG(TAG_False)});
                    V v_t_2457 = ({ V rv_3 = v_t_2456; V rr_ = heff_rec_reuse_nf(v_s_241, 23ULL, 5, shape_ty__size__unit__little__signed, 831u, 0u); heff_rfield(rr_, 3) = rv_3; rr_; });
                    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2457}), v_p_242});
                  }
                  case TAG_Just: {
                    V v_ru_24t_2455_24Just = heff_take_reuse_n(v_t_2455, 0ULL, 1);
                    heff_drop_rec(v_s_241, 5);
                    V v_t_2459 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_240, 3), heff_get_n(v_t_240, 4, 9)});
                    V v_t_2460 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2especWord_str17), v_t_2459, NTAG(TAG_Nothing)});
                    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24t_2455_24Just, TAG_Left, 1, (V[]){v_t_2460}), v_p_242});
                  }
                  default: return heff_nomatch(v_t_2455);
                  }
                } else {
                  if (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 1)), ((V)&g_heff_2esyntax_2esurface_2especWord_str18))) {
                    V v_t_2462 = heff_take_field(v_s_241, 3);
                    switch (heff_tag_of(v_t_2462)) {
                    case TAG_Nothing: {
                      heff_drop_rec(v_t_240, 9);
                      V v_t_2463 = heff_tag_n(TAG_Just, 1, (V[]){NTAG(TAG_True)});
                      V v_t_2464 = ({ V rv_3 = v_t_2463; V rr_ = heff_rec_reuse_nf(v_s_241, 23ULL, 5, shape_ty__size__unit__little__signed, 831u, 0u); heff_rfield(rr_, 3) = rv_3; rr_; });
                      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2464}), v_p_242});
                    }
                    case TAG_Just: {
                      V v_ru_24t_2462_24Just = heff_take_reuse_n(v_t_2462, 0ULL, 1);
                      heff_drop_rec(v_s_241, 5);
                      V v_t_2466 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_240, 3), heff_get_n(v_t_240, 4, 9)});
                      V v_t_2467 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2especWord_str19), v_t_2466, NTAG(TAG_Nothing)});
                      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24t_2462_24Just, TAG_Left, 1, (V[]){v_t_2467}), v_p_242});
                    }
                    default: return heff_nomatch(v_t_2462);
                    }
                  } else {
                    if (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 1)), ((V)&g_heff_2esyntax_2esurface_2especWord_str20))) {
                      V v_t_2469 = heff_take_field(v_s_241, 4);
                      switch (heff_tag_of(v_t_2469)) {
                      case TAG_Nothing: {
                        heff_drop_rec(v_t_240, 9);
                        V v_t_2470 = heff_tag_n(TAG_Just, 1, (V[]){NTAG(TAG_True)});
                        V v_t_2471 = ({ V rv_4 = v_t_2470; V rr_ = heff_rec_reuse_nf(v_s_241, 15ULL, 5, shape_ty__size__unit__little__signed, 255u, 0u); heff_rfield(rr_, 4) = rv_4; rr_; });
                        return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2471}), v_p_242});
                      }
                      case TAG_Just: {
                        V v_ru_24t_2469_24Just = heff_take_reuse_n(v_t_2469, 0ULL, 1);
                        heff_drop_rec(v_s_241, 5);
                        V v_t_2473 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_240, 3), heff_get_n(v_t_240, 4, 9)});
                        V v_t_2474 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2especWord_str21), v_t_2473, NTAG(TAG_Nothing)});
                        return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24t_2469_24Just, TAG_Left, 1, (V[]){v_t_2474}), v_p_242});
                      }
                      default: return heff_nomatch(v_t_2469);
                      }
                    } else {
                      if (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 1)), ((V)&g_heff_2esyntax_2esurface_2especWord_str22))) {
                        V v_t_2476 = heff_take_field(v_s_241, 4);
                        switch (heff_tag_of(v_t_2476)) {
                        case TAG_Nothing: {
                          heff_drop_rec(v_t_240, 9);
                          V v_t_2477 = heff_tag_n(TAG_Just, 1, (V[]){NTAG(TAG_False)});
                          V v_t_2478 = ({ V rv_4 = v_t_2477; V rr_ = heff_rec_reuse_nf(v_s_241, 15ULL, 5, shape_ty__size__unit__little__signed, 255u, 0u); heff_rfield(rr_, 4) = rv_4; rr_; });
                          return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2478}), v_p_242});
                        }
                        case TAG_Just: {
                          V v_ru_24t_2476_24Just = heff_take_reuse_n(v_t_2476, 0ULL, 1);
                          heff_drop_rec(v_s_241, 5);
                          V v_t_2480 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_240, 3), heff_get_n(v_t_240, 4, 9)});
                          V v_t_2481 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2especWord_str23), v_t_2480, NTAG(TAG_Nothing)});
                          return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24t_2476_24Just, TAG_Left, 1, (V[]){v_t_2481}), v_p_242});
                        }
                        default: return heff_nomatch(v_t_2476);
                        }
                      } else {
                        heff_drop_rec(v_s_241, 5);
                        V v_t_2482 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_240, 3), heff_get_n(v_t_240, 4, 9)});
                        V v_t_2483 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2especWord_str24), v_t_2482, NTAG(TAG_Nothing)});
                        return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2483}), v_p_242});
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}
V g_heff_2esyntax_2esurface_2especWord_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2especWord(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2esyntax_2esurface_2eunitOf_str0, 3, "int");
HEFF_LIT(g_heff_2esyntax_2esurface_2eunitOf_str1, 28, "a segment says its unit once");
HEFF_LIT(g_heff_2esyntax_2esurface_2eunitOf_str2, 47, "a unit is a number of bits, 1 to 256: `unit(8)`");
V g_heff_2esyntax_2esurface_2eunitOf_lam0(V self, V *args);
V g_heff_2esyntax_2esurface_2eunitOf_lam1(V self, V *args);
Clo g_heff_2esyntax_2esurface_2eunitOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eunitOf_entry, 3, 0};

V g_heff_2esyntax_2esurface_2eunitOf(V v_sp_240, V v_n_241, V v_s_242) {
top: ;
  V v_t_247 = heff_bool((heff_strEq_c(heff_dup(heff_rfield(v_n_241, 0)), ((V)&g_heff_2esyntax_2esurface_2eunitOf_str0)) && ({ V v_t_244 = (g_heff_2esyntax_2esurface_2eintOfText(heff_rfield(v_n_241, 1))); int c_ = (heff_intLe_c_lent(MK_INT(1LL), v_t_244, 1) && ({ V v_t_246 = (g_heff_2esyntax_2esurface_2eintOfText(heff_rfield(v_n_241, 1))); int c_ = heff_intLe_c_lent(v_t_246, MK_INT(256LL), 2); heff_drop(v_t_246); c_; })); heff_drop(v_t_244); c_; })));
  if ((heff_dup(v_t_247) == NTAG(TAG_True))) {
    heff_drop(v_t_247);
    V v_n_248 = ({ V b_0 = heff_get_n(v_n_241, 1, 9); V r_ = (g_heff_2esyntax_2esurface_2eintOfText(b_0)); heff_drop(b_0); r_; });
    return heff_clo_n(g_heff_2esyntax_2esurface_2eunitOf_lam0, 1, 3, (V[]){v_s_242, v_n_248, v_sp_240});
  } else {
    heff_drop_rec(v_n_241, 9);
    heff_drop_rec(v_s_242, 5);
    heff_drop(v_t_247);
    return heff_clo_n(g_heff_2esyntax_2esurface_2eunitOf_lam1, 1, 1, (V[]){v_sp_240});
  }
}
V g_heff_2esyntax_2esurface_2eunitOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2eunitOf(a[0], a[1], a[2]);
}
V g_heff_2esyntax_2esurface_2eunitOf_lam0(V self, V *args) {
  V v_p_249 = args[0];
  V v_s_242 = heff_env(self)[0];
  V v_n_248 = heff_env(self)[1];
  V v_sp_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2410 = heff_take_field(v_s_242, 2);
  switch (heff_tag_of(v_t_2410)) {
  case TAG_Nothing: {
    heff_drop(v_sp_240);
    V v_t_2411 = ({ V rv_2 = heff_tag_n(TAG_Just, 1, (V[]){v_n_248}); V rr_ = heff_rec_reuse_nf(v_s_242, 27ULL, 5, shape_ty__size__unit__little__signed, 975u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2411}), v_p_249});
  }
  case TAG_Just: {
    V v_ru_24t_2410_24Just = heff_take_reuse_n(v_t_2410, 0ULL, 1);
    heff_drop_rec(v_s_242, 5);
    heff_drop(v_n_248);
    V v_t_2413 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2eunitOf_str1), v_sp_240, NTAG(TAG_Nothing)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24t_2410_24Just, TAG_Left, 1, (V[]){v_t_2413}), v_p_249});
  }
  default: return heff_nomatch(v_t_2410);
  }
}
V g_heff_2esyntax_2esurface_2eunitOf_lam1(V self, V *args) {
  V v_st_2414 = args[0];
  V v_sp_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2415 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2eunitOf_str2), v_sp_240, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2415}), v_st_2414});
}
Clo g_heff_2esyntax_2esurface_2esegmentOf_24s1547151193x813882637_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2esegmentOf_24s1547151193x813882637_entry, 5, 0};

V g_heff_2esyntax_2esurface_2esegmentOf_24s1547151193x813882637(V v_inPat_240, V v_sp_241, V v_e_242, V v_v_243, V v_st_244) {
top: ;
  V v_t_246;
  switch (heff_tag_of(v_v_243)) {
  case TAG_StrValue: {
    v_t_246 = NTAG(TAG_SegmentBinary);
    break;
  }
  case TAG_IntValue: {
    v_t_246 = NTAG(TAG_SegmentInteger);
    break;
  }
  case TAG_FloatValue: {
    v_t_246 = NTAG(TAG_SegmentFloat);
    break;
  }
  case TAG_RuneValue: {
    v_t_246 = heff_tag_n(TAG_SegmentUtf, 1, (V[]){MK_INT(8LL)});
    break;
  }
  case TAG_OtherValue: {
    v_t_246 = NTAG(TAG_SegmentInteger);
    break;
  }
  default: heff_nomatch(v_v_243);
  }
  HeffT2 v_t_247 = (g_heff_2esyntax_2esurface_2evalueKind_24cpr(heff_dup(v_sp_241), heff_dup(v_v_243), v_t_246, v_st_244));
  {
    V v_field_248 = v_t_247.f[0];
    V v_field_249 = v_t_247.f[1];
    V v_x11_2410 = v_field_248;
    V v_st_2411 = v_field_249;
    switch (heff_tag_of(v_x11_2410)) {
    case TAG_Left: {
      V v_e_2412 = heff_field(v_x11_2410, 0);
      V v_ru_24x11_2410_24Left = heff_take_reuse_n(v_x11_2410, 1ULL, 1);
      heff_drop(v_sp_241);
      heff_drop(v_e_242);
      heff_drop(v_v_243);
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_2410_24Left, TAG_Left, 1, (V[]){v_e_2412}), v_st_2411});
    }
    case TAG_Right: {
      V v_ru_24x11_2410_24Right = heff_take_reuse_n(v_x11_2410, 0ULL, 1);
      V v_t_2415;
      switch (heff_tag_of(v_v_243)) {
      case TAG_StrValue: {
        v_t_2415 = NTAG(TAG_SegmentBinary);
        break;
      }
      case TAG_IntValue: {
        v_t_2415 = NTAG(TAG_SegmentInteger);
        break;
      }
      case TAG_FloatValue: {
        v_t_2415 = NTAG(TAG_SegmentFloat);
        break;
      }
      case TAG_RuneValue: {
        v_t_2415 = heff_tag_n(TAG_SegmentUtf, 1, (V[]){MK_INT(8LL)});
        break;
      }
      case TAG_OtherValue: {
        v_t_2415 = NTAG(TAG_SegmentInteger);
        break;
      }
      default: heff_nomatch(v_v_243);
      }
      V v_m_2416 = (g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993(v_inPat_240, heff_dup(v_sp_241), heff_dup(v_v_243), v_t_2415, NTAG(TAG_SizeDefault)));
      V v_x1_2417 = heff_tr(heff_call(v_m_2416, 1, (V[]){v_st_2411}));
      switch (heff_tag_of(v_x1_2417)) {
      case TAG_MkPair: {
        V v_x11_2418 = heff_field(v_x1_2417, 0);
        V v_st_2419 = heff_field(v_x1_2417, 1);
        V v_ru_24x1_2417_24MkPair = heff_take_reuse_n(v_x1_2417, 3ULL, 2);
        switch (heff_tag_of(v_x11_2418)) {
        case TAG_Left: {
          V v_e_2420 = heff_field(v_x11_2418, 0);
          heff_take_n(v_x11_2418, 1ULL, 1);
          heff_drop(v_sp_241);
          heff_drop(v_e_242);
          heff_drop(v_v_243);
          heff_drop_cell(v_ru_24x11_2410_24Right, 1);
          return heff_tag_at_n(v_ru_24x1_2417_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2420}), v_st_2419});
        }
        case TAG_Right: {
          V v_ru_24x11_2418_24Right = heff_take_reuse_n(v_x11_2418, 0ULL, 1);
          V v_t_2423;
          switch (heff_tag_of(v_v_243)) {
          case TAG_StrValue: {
            heff_drop_cell(v_ru_24x11_2418_24Right, 1);
            v_t_2423 = NTAG(TAG_SegmentBinary);
            break;
          }
          case TAG_IntValue: {
            heff_take_n(v_v_243, 0ULL, 1);
            heff_drop_cell(v_ru_24x11_2418_24Right, 1);
            v_t_2423 = NTAG(TAG_SegmentInteger);
            break;
          }
          case TAG_FloatValue: {
            heff_drop_cell(v_ru_24x11_2418_24Right, 1);
            v_t_2423 = NTAG(TAG_SegmentFloat);
            break;
          }
          case TAG_RuneValue: {
            v_t_2423 = heff_tag_at_n(v_ru_24x11_2418_24Right, TAG_SegmentUtf, 1, (V[]){MK_INT(8LL)});
            break;
          }
          case TAG_OtherValue: {
            heff_drop_cell(v_ru_24x11_2418_24Right, 1);
            v_t_2423 = NTAG(TAG_SegmentInteger);
            break;
          }
          default: heff_nomatch(v_v_243);
          }
          V v_t_2424 = heff_tag_n(TAG_MkSegment, 5, (V[]){v_e_242, v_t_2423, NTAG(TAG_SizeDefault), NTAG(TAG_False), NTAG(TAG_False)});
          V v_t_2425 = heff_tag_at_n(v_ru_24x11_2410_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2424, v_sp_241})});
          return heff_tag_at_n(v_ru_24x1_2417_24MkPair, TAG_MkPair, 2, (V[]){v_t_2425, v_st_2419});
        }
        default: return heff_nomatch(v_x11_2418);
        }
      }
      default: return heff_nomatch(v_x1_2417);
      }
    }
    default: return heff_nomatch(v_x11_2410);
    }
  }
}
V g_heff_2esyntax_2esurface_2esegmentOf_24s1547151193x813882637_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2esurface_2esegmentOf_24s1547151193x813882637(a0, a[1], a[2], a[3], a[4]); heff_drop(a0); return r;
}
V g_heff_2esyntax_2esurface_2epushS_24s1868233564x1858628873_lam0(V self, V *args);
V g_heff_2esyntax_2esurface_2epushS_24s1868233564x1858628873_lam1(V self, V *args);
Clo g_heff_2esyntax_2esurface_2epushS_24s1868233564x1858628873_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2epushS_24s1868233564x1858628873_entry, 4, 0};

V g_heff_2esyntax_2esurface_2epushS_24s1868233564x1858628873(V v_fix_240, V v_lenient_241, V v_st_242, V v_r_243) {
top: ;
  V v_t_244 = heff_dup(heff_rfield(v_st_242, 0));
  switch (heff_tag_of(v_t_244)) {
  case TAG_Nil: {
    heff_drop(v_fix_240);
    return heff_clo_n(g_heff_2esyntax_2esurface_2epushS_24s1868233564x1858628873_lam0, 1, 2, (V[]){v_r_243, v_st_242});
  }
  case TAG_Cons: {
    V v_before_249 = heff_field(v_t_244, 0);
    heff_take_n(v_t_244, 1ULL, 2);
    V v_m_2411 = (g_heff_2esyntax_2esurface_2efirstS(heff_dup(v_fix_240), v_lenient_241, v_before_249, heff_dup(heff_rfield(v_r_243, 0))));
    return heff_clo_n(g_heff_2esyntax_2esurface_2epushS_24s1868233564x1858628873_lam1, 1, 5, (V[]){v_m_2411, v_st_242, v_fix_240, heff_dup(v_lenient_241), v_r_243});
  }
  default: return heff_nomatch(v_t_244);
  }
}
V g_heff_2esyntax_2esurface_2epushS_24s1868233564x1858628873_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2esyntax_2esurface_2epushS_24s1868233564x1858628873(a[0], a1, a[2], a[3]); heff_drop(a1); return r;
}
V g_heff_2esyntax_2esurface_2epushS_24s1868233564x1858628873_lam0(V self, V *args) {
  V v_st_245 = args[0];
  V v_r_243 = heff_env(self)[0];
  V v_st_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){heff_take_field(v_r_243, 0), heff_take_field(v_st_242, 0)});
  V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){heff_get_n(v_r_243, 1, 2), heff_get_n(v_st_242, 1, 2)});
  V v_t_248 = heff_tag_n(TAG_Right, 1, (V[]){heff_rec_n(2, shape_ops__out, (V[]){v_t_246, v_t_247})});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_248, v_st_245});
}
V g_heff_2esyntax_2esurface_2epushS_24s1868233564x1858628873_lam1(V self, V *args) {
  V v_st_2412 = args[0];
  V v_m_2411 = heff_env(self)[0];
  V v_st_242 = heff_env(self)[1];
  V v_fix_240 = heff_env(self)[2];
  V v_lenient_241 = heff_env(self)[3];
  V v_r_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_x1_2413 = heff_tr(heff_call(v_m_2411, 1, (V[]){v_st_2412}));
  switch (heff_tag_of(v_x1_2413)) {
  case TAG_MkPair: {
    V v_x11_2414 = heff_field(v_x1_2413, 0);
    V v_st_2415 = heff_field(v_x1_2413, 1);
    V v_ru_24x1_2413_24MkPair = heff_take_reuse_n(v_x1_2413, 3ULL, 2);
    switch (heff_tag_of(v_x11_2414)) {
    case TAG_Left: {
      V v_e_2416 = heff_field(v_x11_2414, 0);
      heff_take_n(v_x11_2414, 1ULL, 1);
      heff_drop_rec(v_st_242, 2);
      heff_drop(v_fix_240);
      heff_drop(v_lenient_241);
      heff_drop_rec(v_r_243, 2);
      return heff_tag_at_n(v_ru_24x1_2413_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2416}), v_st_2415});
    }
    case TAG_Right: {
      V v_x_2417 = heff_field(v_x11_2414, 0);
      V v_ru_24x11_2414_24Right = heff_take_reuse_n(v_x11_2414, 1ULL, 1);
      if ((heff_dup(v_x_2417) == NTAG(TAG_True))) {
        heff_drop_cell(v_ru_24x1_2413_24MkPair, 2);
        heff_drop(v_x_2417);
        heff_drop_cell(v_ru_24x11_2414_24Right, 1);
        V v_t_2418 = heff_dup(heff_rfield(v_st_242, 0));
        V v_t_2427;
        switch (heff_tag_of(v_t_2418)) {
        case TAG_Nil: {
          v_t_2427 = v_st_242;
          break;
        }
        case TAG_Cons: {
          V v_o_2419 = heff_field(v_t_2418, 0);
          V v_os_2420 = heff_field(v_t_2418, 1);
          heff_take_n(v_t_2418, 3ULL, 2);
          V v_t_2421 = heff_dup(heff_rfield(v_st_242, 1));
          switch (heff_tag_of(v_t_2421)) {
          case TAG_Nil: {
            heff_drop(v_o_2419);
            heff_drop(v_os_2420);
            v_t_2427 = v_st_242;
            break;
          }
          case TAG_Cons: {
            V v_r_2422 = heff_field(v_t_2421, 0);
            V v_it2_2423 = heff_field(v_t_2421, 1);
            heff_take_n(v_t_2421, 3ULL, 2);
            switch (heff_tag_of(v_it2_2423)) {
            case TAG_Nil: {
              heff_drop(v_o_2419);
              heff_drop(v_os_2420);
              heff_drop(v_r_2422);
              v_t_2427 = v_st_242;
              break;
            }
            case TAG_Cons: {
              V v_l_2424 = heff_field(v_it2_2423, 0);
              V v_rest_2425 = heff_field(v_it2_2423, 1);
              heff_take_n(v_it2_2423, 3ULL, 2);
              heff_drop_rec(v_st_242, 2);
              V v_t_2426 = (g_heff_2esyntax_2esurface_2eapplyOp(v_o_2419, v_l_2424, v_r_2422));
              v_t_2427 = heff_rec_n(2, shape_ops__out, (V[]){v_os_2420, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2426, v_rest_2425})});
              break;
            }
            default: heff_nomatch(v_it2_2423);
            }
            break;
          }
          default: heff_nomatch(v_t_2421);
          }
          break;
        }
        default: heff_nomatch(v_t_2418);
        }
        V v_t_2428 = ({ V a_0 = v_fix_240; V a_1 = v_lenient_241; V a_2 = v_t_2427; V a_3 = v_r_243; V r_ = (g_heff_2esyntax_2esurface_2epushS_24s1868233564x1858628873(a_0, a_1, a_2, a_3)); heff_drop(v_lenient_241); r_; });
        V f_ = v_t_2428;
        args[0] = v_st_2415;
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      } else {
        heff_drop(v_fix_240);
        heff_drop(v_lenient_241);
        heff_drop(v_x_2417);
        V v_t_2429 = heff_tag_n(TAG_Cons, 2, (V[]){heff_take_field(v_r_243, 0), heff_take_field(v_st_242, 0)});
        V v_t_2430 = heff_tag_n(TAG_Cons, 2, (V[]){heff_get_n(v_r_243, 1, 2), heff_get_n(v_st_242, 1, 2)});
        V v_t_2431 = heff_tag_at_n(v_ru_24x11_2414_24Right, TAG_Right, 1, (V[]){heff_rec_n(2, shape_ops__out, (V[]){v_t_2429, v_t_2430})});
        return heff_tag_at_n(v_ru_24x1_2413_24MkPair, TAG_MkPair, 2, (V[]){v_t_2431, v_st_2415});
      }
    }
    default: return heff_nomatch(v_x11_2414);
    }
  }
  default: return heff_nomatch(v_x1_2413);
  }
}
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str0, 3, "con");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str1, 7, " := e)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str2, 51, " := ...)` names an argument, after a function: `f (");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str3, 2, "`(");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str4, 2, "b[");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str5, 1, "[");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str6, 3, "Nil");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str7, 4, "Cons");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str8, 70, "heff has no tuples: a record holds values together, `{ x = a, y = b }`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str9, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str10, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str11, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str12, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str13, 61, "an instance argument is bound before `->`: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str14, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str15, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str16, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str17, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str18, 3, "con");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str19, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str20, 3, "neg");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str21, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str22, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str23, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str24, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str25, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str26, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str27, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str28, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str29, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str30, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str31, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str32, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str33, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str34, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str35, 5, "break");
V g_heff_2esyntax_2esurface_2eexprL_lam0(V self, V *args);
V g_heff_2esyntax_2esurface_2eexprL_lam1(V self, V *args);
V g_heff_2esyntax_2esurface_2eexprL_lam2(V self, V *args);
V g_heff_2esyntax_2esurface_2eexprL_lam3(V self, V *args);
V g_heff_2esyntax_2esurface_2eexprL_lam4(V self, V *args);
V g_heff_2esyntax_2esurface_2eexprL_lam6(V self, V *args);
V g_heff_2esyntax_2esurface_2eexprL_lam5(V self, V *args);
V g_heff_2esyntax_2esurface_2eexprL_lam7(V self, V *args);
V g_heff_2esyntax_2esurface_2eexprL_lam8(V self, V *args);
V g_heff_2esyntax_2esurface_2eexprL_lam9(V self, V *args);
V g_heff_2esyntax_2esurface_2eexprL_lam10(V self, V *args);
Clo g_heff_2esyntax_2esurface_2eexprL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eexprL_entry, 3, 0};

V g_heff_2esyntax_2esurface_2eexprL(V v_r_240, V v_e0_241, V v_z_242) {
top: ;
  switch (heff_tag_of(v_e0_241)) {
  case TAG_Atom: {
    V v_t_243 = heff_field(v_e0_241, 0);
    V v_ru_24e0_241_24Atom = heff_take_reuse_n(v_e0_241, 1ULL, 1);
    heff_drop_rec(v_r_240, 3);
    if (heff_strEq_c(heff_dup(heff_rfield(v_t_243, 0)), ((V)&g_heff_2esyntax_2esurface_2eexprL_str0))) {
      heff_drop_cell(v_ru_24e0_241_24Atom, 1);
      HEFF_LAST return g_heff_2esyntax_2esurface_2econAtom(v_t_243, NTAG(TAG_Nil), v_z_242);
    } else {
      V v_x_245 = (g_heff_2esyntax_2esurface_2eatomTok(v_t_243));
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24e0_241_24Atom, TAG_Right, 1, (V[]){v_x_245}), v_z_242});
    }
  }
  case TAG_EParen: {
    V v_o_246 = heff_field(v_e0_241, 0);
    V v_e_247 = heff_field(v_e0_241, 1);
    V v_c_248 = heff_field(v_e0_241, 2);
    heff_take_n(v_e0_241, 7ULL, 3);
    return ({ V a_0 = v_r_240; V a_1 = v_o_246; V a_2 = v_e_247; V a_3 = v_c_248; V a_4 = v_z_242; V r_ = (g_heff_2esyntax_2esurface_2eparenL(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_o_246); r_; });
  }
  case TAG_Named: {
    V v_o_249 = heff_field(v_e0_241, 0);
    V v_x_2410 = heff_field(v_e0_241, 1);
    V v_e_2412 = heff_field(v_e0_241, 3);
    V v_c_2413 = heff_field(v_e0_241, 4);
    heff_take_n(v_e0_241, 27ULL, 5);
    V v_m_2414 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_2412}));
    V v_x1_2415 = heff_tr(heff_call(v_m_2414, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x1_2415)) {
    case TAG_MkPair: {
      V v_x11_2416 = heff_field(v_x1_2415, 0);
      V v_st_2417 = heff_field(v_x1_2415, 1);
      V v_ru_24x1_2415_24MkPair = heff_take_reuse_n(v_x1_2415, 3ULL, 2);
      switch (heff_tag_of(v_x11_2416)) {
      case TAG_Left: {
        V v_e_2418 = heff_field(v_x11_2416, 0);
        heff_take_n(v_x11_2416, 1ULL, 1);
        heff_drop_rec(v_o_249, 9);
        heff_drop_rec(v_x_2410, 9);
        heff_drop_rec(v_c_2413, 9);
        return heff_tag_at_n(v_ru_24x1_2415_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2418}), v_st_2417});
      }
      case TAG_Right: {
        V v_ru_24x11_2416_24Right = heff_take_reuse_n(v_x11_2416, 0ULL, 1);
        V v_t_2420 = heff_strAppend(heff_dup(heff_rfield(v_x_2410, 1)), ((V)&g_heff_2esyntax_2esurface_2eexprL_str1));
        V v_t_2421 = heff_strAppend(heff_get_n(v_x_2410, 1, 9), heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eexprL_str2), v_t_2420));
        V v_t_2422 = heff_tag_n(TAG_EInvalid, 1, (V[]){heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eexprL_str3), v_t_2421)});
        V v_t_2423 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_o_249, 3, 9), heff_get_n(v_c_2413, 4, 9)});
        V v_t_2424 = heff_tag_at_n(v_ru_24x11_2416_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2422, v_t_2423})});
        return heff_tag_at_n(v_ru_24x1_2415_24MkPair, TAG_MkPair, 2, (V[]){v_t_2424, v_st_2417});
      }
      default: return heff_nomatch(v_x11_2416);
      }
    }
    default: return heff_nomatch(v_x1_2415);
    }
  }
  case TAG_Tup: {
    V v_o_2425 = heff_field(v_e0_241, 0);
    V v_es_2426 = heff_field(v_e0_241, 1);
    V v_c_2428 = heff_field(v_e0_241, 3);
    heff_take_n(v_e0_241, 11ULL, 4);
    if (heff_strEq_c(heff_dup(heff_rfield(v_o_2425, 1)), ((V)&g_heff_2esyntax_2esurface_2eexprL_str4))) {
      V v_m_2431 = (g_prelude_2etraverse_24s499544530x2060473942(heff_clo_n(g_heff_2esyntax_2esurface_2eexprL_lam0, 1, 1, (V[]){v_r_240}), v_es_2426));
      V v_x1_2432 = heff_tr(heff_call(v_m_2431, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_2432)) {
      case TAG_MkPair: {
        V v_x11_2433 = heff_field(v_x1_2432, 0);
        V v_st_2434 = heff_field(v_x1_2432, 1);
        V v_ru_24x1_2432_24MkPair = heff_take_reuse_n(v_x1_2432, 3ULL, 2);
        switch (heff_tag_of(v_x11_2433)) {
        case TAG_Left: {
          V v_e_2435 = heff_field(v_x11_2433, 0);
          heff_take_n(v_x11_2433, 1ULL, 1);
          heff_drop_rec(v_o_2425, 9);
          heff_drop_rec(v_c_2428, 9);
          return heff_tag_at_n(v_ru_24x1_2432_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2435}), v_st_2434});
        }
        case TAG_Right: {
          V v_x_2436 = heff_field(v_x11_2433, 0);
          V v_ru_24x11_2433_24Right = heff_take_reuse_n(v_x11_2433, 1ULL, 1);
          V v_t_2437 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_o_2425, 3, 9), heff_get_n(v_c_2428, 4, 9)});
          V v_t_2438 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_2433_24Right, TAG_EBinary, 1, (V[]){v_x_2436}), v_t_2437});
          return heff_tag_at_n(v_ru_24x1_2432_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2438}), v_st_2434});
        }
        default: return heff_nomatch(v_x11_2433);
        }
      }
      default: return heff_nomatch(v_x1_2432);
      }
    } else {
      if (heff_strEq_c(heff_dup(heff_rfield(v_o_2425, 1)), ((V)&g_heff_2esyntax_2esurface_2eexprL_str5))) {
        V v_m_2440 = (g_prelude_2etraverse_24s499544530x2060473942(heff_get_n(v_r_240, 0, 3), v_es_2426));
        V v_x1_2441 = heff_tr(heff_call(v_m_2440, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_2441)) {
        case TAG_MkPair: {
          V v_x11_2442 = heff_field(v_x1_2441, 0);
          V v_st_2443 = heff_field(v_x1_2441, 1);
          V v_ru_24x1_2441_24MkPair = heff_take_reuse_n(v_x1_2441, 3ULL, 2);
          switch (heff_tag_of(v_x11_2442)) {
          case TAG_Left: {
            V v_e_2444 = heff_field(v_x11_2442, 0);
            heff_take_n(v_x11_2442, 1ULL, 1);
            heff_drop_rec(v_o_2425, 9);
            heff_drop_rec(v_c_2428, 9);
            return heff_tag_at_n(v_ru_24x1_2441_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2444}), v_st_2443});
          }
          case TAG_Right: {
            V v_x_2445 = heff_field(v_x11_2442, 0);
            V v_ru_24x11_2442_24Right = heff_take_reuse_n(v_x11_2442, 1ULL, 1);
            V v_sp_2446 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_o_2425, 3, 9), heff_get_n(v_c_2428, 4, 9)});
            V v_t_2447 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_2442_24Right, TAG_ETag, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2eexprL_str6)}), heff_dup(v_sp_2446)});
            V v_x_2452 = ({ V a_0 = heff_clo_n(g_heff_2esyntax_2esurface_2eexprL_lam1, 2, 1, (V[]){v_sp_2446}); V a_1 = v_t_2447; V a_2 = v_x_2445; V r_ = heff_tr(g_heff_2esyntax_2esurface_2efoldr(a_0, a_1, a_2)); heff_drop(v_x_2445); r_; });
            return heff_tag_at_n(v_ru_24x1_2441_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2452}), v_st_2443});
          }
          default: return heff_nomatch(v_x11_2442);
          }
        }
        default: return heff_nomatch(v_x1_2441);
        }
      } else {
        V v_m_2453 = (g_prelude_2etraverse_24s499544530x2060473942(heff_get_n(v_r_240, 0, 3), v_es_2426));
        V v_x1_2454 = heff_tr(heff_call(v_m_2453, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_2454)) {
        case TAG_MkPair: {
          V v_x11_2455 = heff_field(v_x1_2454, 0);
          V v_st_2456 = heff_field(v_x1_2454, 1);
          V v_ru_24x1_2454_24MkPair = heff_take_reuse_n(v_x1_2454, 3ULL, 2);
          switch (heff_tag_of(v_x11_2455)) {
          case TAG_Left: {
            V v_e_2457 = heff_field(v_x11_2455, 0);
            heff_take_n(v_x11_2455, 1ULL, 1);
            heff_drop_rec(v_o_2425, 9);
            heff_drop_rec(v_c_2428, 9);
            return heff_tag_at_n(v_ru_24x1_2454_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2457}), v_st_2456});
          }
          case TAG_Right: {
            V v_ru_24x11_2455_24Right = heff_take_reuse_n(v_x11_2455, 0ULL, 1);
            V v_t_2459 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_o_2425, 3, 9), heff_get_n(v_c_2428, 4, 9)});
            V v_t_2460 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_2455_24Right, TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2eexprL_str8)}), v_t_2459});
            return heff_tag_at_n(v_ru_24x1_2454_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2460}), v_st_2456});
          }
          default: return heff_nomatch(v_x11_2455);
          }
        }
        default: return heff_nomatch(v_x1_2454);
        }
      }
    }
  }
  case TAG_Seg: {
    heff_drop_rec(v_r_240, 3);
    V v_t_2464 = (g_heff_2esyntax_2ecst_2efirstE(v_e0_241));
    V v_t_2465 = ({ V a_0 = v_e0_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e0_241, 3); r_; });
    V v_t_2466 = heff_strAppend(heff_get_n(v_t_2465, 1, 9), ((V)&g_heff_2esyntax_2esurface_2eexprL_str9));
    V v_msg_2467 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eexprL_str10), v_t_2466);
    V v_t_2468 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_2464, 3), heff_get_n(v_t_2464, 4, 9)});
    V v_t_2469 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_2467, v_t_2468, NTAG(TAG_Nothing)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2469}), v_z_242});
  }
  case TAG_Braces: {
    V v_o_2470 = heff_field(v_e0_241, 0);
    V v_fs_2471 = heff_field(v_e0_241, 1);
    V v_c_2473 = heff_field(v_e0_241, 3);
    heff_take_n(v_e0_241, 11ULL, 4);
    return (g_heff_2esyntax_2esurface_2ebracesL(v_r_240, v_o_2470, v_fs_2471, v_c_2473, v_z_242));
  }
  case TAG_Update: {
    V v_o_2474 = heff_field(v_e0_241, 0);
    V v_rec_2475 = heff_field(v_e0_241, 1);
    V v_fs_2477 = heff_field(v_e0_241, 3);
    V v_c_2479 = heff_field(v_e0_241, 5);
    heff_take_n(v_e0_241, 43ULL, 6);
    V v_m_2480 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_rec_2475}));
    V v_x1_2481 = heff_tr(heff_call(v_m_2480, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x1_2481)) {
    case TAG_MkPair: {
      V v_x11_2482 = heff_field(v_x1_2481, 0);
      V v_st_2483 = heff_field(v_x1_2481, 1);
      V v_ru_24x1_2481_24MkPair = heff_take_reuse_n(v_x1_2481, 3ULL, 2);
      switch (heff_tag_of(v_x11_2482)) {
      case TAG_Left: {
        V v_e_2484 = heff_field(v_x11_2482, 0);
        heff_take_n(v_x11_2482, 1ULL, 1);
        heff_drop_rec(v_r_240, 3);
        heff_drop_rec(v_o_2474, 9);
        heff_drop(v_fs_2477);
        heff_drop_rec(v_c_2479, 9);
        return heff_tag_at_n(v_ru_24x1_2481_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2484}), v_st_2483});
      }
      case TAG_Right: {
        V v_x_2485 = heff_field(v_x11_2482, 0);
        heff_take_n(v_x11_2482, 1ULL, 1);
        V v_m_2487 = (g_prelude_2etraverse_24s499544530x2060473942(heff_clo_n(g_heff_2esyntax_2esurface_2eexprL_lam2, 1, 1, (V[]){v_r_240}), v_fs_2477));
        V v_x1_2488 = heff_tr(heff_call(v_m_2487, 1, (V[]){v_st_2483}));
        switch (heff_tag_of(v_x1_2488)) {
        case TAG_MkPair: {
          V v_x11_2489 = heff_field(v_x1_2488, 0);
          V v_st_2490 = heff_field(v_x1_2488, 1);
          V v_ru_24x1_2488_24MkPair = heff_take_reuse_n(v_x1_2488, 3ULL, 2);
          switch (heff_tag_of(v_x11_2489)) {
          case TAG_Left: {
            V v_e_2491 = heff_field(v_x11_2489, 0);
            heff_take_n(v_x11_2489, 1ULL, 1);
            heff_drop_rec(v_o_2474, 9);
            heff_drop_rec(v_c_2479, 9);
            heff_drop(v_x_2485);
            heff_drop_cell(v_ru_24x1_2488_24MkPair, 2);
            return heff_tag_at_n(v_ru_24x1_2481_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2491}), v_st_2490});
          }
          case TAG_Right: {
            V v_x_2492 = heff_field(v_x11_2489, 0);
            heff_take_n(v_x11_2489, 1ULL, 1);
            V v_t_2493 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_o_2474, 3, 9), heff_get_n(v_c_2479, 4, 9)});
            V v_t_2494 = heff_tag_at_n(v_ru_24x1_2488_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_EUpdate, 2, (V[]){v_x_2485, v_x_2492}), v_t_2493});
            return heff_tag_at_n(v_ru_24x1_2481_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2494}), v_st_2490});
          }
          default: return heff_nomatch(v_x11_2489);
          }
        }
        default: return heff_nomatch(v_x1_2488);
        }
      }
      default: return heff_nomatch(v_x11_2482);
      }
    }
    default: return heff_nomatch(v_x1_2481);
    }
  }
  case TAG_EUSet: {
    heff_drop_rec(v_r_240, 3);
    V v_t_2498 = (g_heff_2esyntax_2ecst_2efirstE(v_e0_241));
    V v_t_2499 = ({ V a_0 = v_e0_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e0_241, 3); r_; });
    V v_t_24100 = heff_strAppend(heff_get_n(v_t_2499, 1, 9), ((V)&g_heff_2esyntax_2esurface_2eexprL_str11));
    V v_msg_24101 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eexprL_str12), v_t_24100);
    V v_t_24102 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_2498, 3), heff_get_n(v_t_2498, 4, 9)});
    V v_t_24103 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24101, v_t_24102, NTAG(TAG_Nothing)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24103}), v_z_242});
  }
  case TAG_InstB: {
    V v_o_24104 = heff_field(v_e0_241, 0);
    V v_d_24106 = heff_field(v_e0_241, 2);
    V v_c_24108 = heff_field(v_e0_241, 4);
    heff_take_n(v_e0_241, 21ULL, 5);
    V v_m_24109 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_d_24106));
    V v_x1_24110 = heff_tr(heff_call(v_m_24109, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x1_24110)) {
    case TAG_MkPair: {
      V v_x11_24111 = heff_field(v_x1_24110, 0);
      V v_st_24112 = heff_field(v_x1_24110, 1);
      V v_ru_24x1_24110_24MkPair = heff_take_reuse_n(v_x1_24110, 3ULL, 2);
      switch (heff_tag_of(v_x11_24111)) {
      case TAG_Left: {
        V v_e_24113 = heff_field(v_x11_24111, 0);
        heff_take_n(v_x11_24111, 1ULL, 1);
        heff_drop_rec(v_o_24104, 9);
        heff_drop_rec(v_c_24108, 9);
        return heff_tag_at_n(v_ru_24x1_24110_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24113}), v_st_24112});
      }
      case TAG_Right: {
        V v_ru_24x11_24111_24Right = heff_take_reuse_n(v_x11_24111, 0ULL, 1);
        V v_t_24115 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_o_24104, 3, 9), heff_get_n(v_c_24108, 4, 9)});
        V v_t_24116 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24111_24Right, TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2eexprL_str13)}), v_t_24115});
        return heff_tag_at_n(v_ru_24x1_24110_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24116}), v_st_24112});
      }
      default: return heff_nomatch(v_x11_24111);
      }
    }
    default: return heff_nomatch(v_x1_24110);
    }
  }
  case TAG_EFSet: {
    heff_drop_rec(v_r_240, 3);
    V v_t_24120 = (g_heff_2esyntax_2ecst_2efirstE(v_e0_241));
    V v_t_24121 = ({ V a_0 = v_e0_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e0_241, 3); r_; });
    V v_t_24122 = heff_strAppend(heff_get_n(v_t_24121, 1, 9), ((V)&g_heff_2esyntax_2esurface_2eexprL_str14));
    V v_msg_24123 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eexprL_str15), v_t_24122);
    V v_t_24124 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24120, 3), heff_get_n(v_t_24120, 4, 9)});
    V v_t_24125 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24123, v_t_24124, NTAG(TAG_Nothing)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24125}), v_z_242});
  }
  case TAG_EFDefault: {
    heff_drop_rec(v_r_240, 3);
    V v_t_24129 = (g_heff_2esyntax_2ecst_2efirstE(v_e0_241));
    V v_t_24130 = ({ V a_0 = v_e0_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e0_241, 3); r_; });
    V v_t_24131 = heff_strAppend(heff_get_n(v_t_24130, 1, 9), ((V)&g_heff_2esyntax_2esurface_2eexprL_str16));
    V v_msg_24132 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eexprL_str17), v_t_24131);
    V v_t_24133 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24129, 3), heff_get_n(v_t_24129, 4, 9)});
    V v_t_24134 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24132, v_t_24133, NTAG(TAG_Nothing)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24134}), v_z_242});
  }
  case TAG_Sum: {
    V v_kw_24135 = heff_field(v_e0_241, 0);
    V v_alts_24137 = heff_field(v_e0_241, 2);
    V v_c_24139 = heff_field(v_e0_241, 4);
    heff_take_n(v_e0_241, 21ULL, 5);
    V v_m_24141 = (g_prelude_2etraverse_24s499544530x2060473942(heff_clo_n(g_heff_2esyntax_2esurface_2eexprL_lam3, 1, 1, (V[]){v_r_240}), v_alts_24137));
    V v_x1_24142 = heff_tr(heff_call(v_m_24141, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x1_24142)) {
    case TAG_MkPair: {
      V v_x11_24143 = heff_field(v_x1_24142, 0);
      V v_st_24144 = heff_field(v_x1_24142, 1);
      V v_ru_24x1_24142_24MkPair = heff_take_reuse_n(v_x1_24142, 3ULL, 2);
      switch (heff_tag_of(v_x11_24143)) {
      case TAG_Left: {
        V v_e_24145 = heff_field(v_x11_24143, 0);
        heff_take_n(v_x11_24143, 1ULL, 1);
        heff_drop_rec(v_kw_24135, 9);
        heff_drop_rec(v_c_24139, 9);
        return heff_tag_at_n(v_ru_24x1_24142_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24145}), v_st_24144});
      }
      case TAG_Right: {
        V v_x_24146 = heff_field(v_x11_24143, 0);
        V v_ru_24x11_24143_24Right = heff_take_reuse_n(v_x11_24143, 1ULL, 1);
        V v_t_24147 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_24135, 3, 9), heff_get_n(v_c_24139, 4, 9)});
        V v_t_24148 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24143_24Right, TAG_ESum, 1, (V[]){v_x_24146}), v_t_24147});
        return heff_tag_at_n(v_ru_24x1_24142_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24148}), v_st_24144});
      }
      default: return heff_nomatch(v_x11_24143);
      }
    }
    default: return heff_nomatch(v_x1_24142);
    }
  }
  case TAG_ECon: {
    V v_c_24149 = heff_field(v_e0_241, 0);
    V v_args_24150 = heff_field(v_e0_241, 1);
    heff_take_n(v_e0_241, 3ULL, 2);
    V v_t_24151 = (g_heff_2esyntax_2esurface_2econL(v_r_240, v_c_24149, v_args_24150));
    return heff_tail(v_t_24151, 1, (V[]){v_z_242});
  }
  case TAG_EField: {
    V v_e_24152 = heff_field(v_e0_241, 0);
    V v_f_24153 = heff_field(v_e0_241, 1);
    V v_ru_24e0_241_24EField = heff_take_reuse_n(v_e0_241, 3ULL, 2);
    HeffT2 v_t_24154 = (g_heff_2esyntax_2esurface_2efieldsOf_24cpr(heff_tag_at_n(v_ru_24e0_241_24EField, TAG_EField, 2, (V[]){v_e_24152, v_f_24153}), NTAG(TAG_Nil)));
    {
      V v_field_24155 = v_t_24154.f[0];
      V v_field_24156 = v_t_24154.f[1];
      V v_it1_24157 = v_field_24155;
      V v_fs_24158 = v_field_24156;
      switch (heff_tag_of(v_it1_24157)) {
      case TAG_Atom: {
        V v_t_24159 = heff_field(v_it1_24157, 0);
        V v_ru_24it1_24157_24Atom = heff_take_reuse_n(v_it1_24157, 1ULL, 1);
        heff_drop_rec(v_r_240, 3);
        if (heff_strEq_c(heff_dup(heff_rfield(v_t_24159, 0)), ((V)&g_heff_2esyntax_2esurface_2eexprL_str18))) {
          heff_drop_cell(v_ru_24it1_24157_24Atom, 1);
          HEFF_LAST return g_heff_2esyntax_2esurface_2econAtom(v_t_24159, v_fs_24158, v_z_242);
        } else {
          if (heff_strEq_c(heff_dup(heff_rfield(v_t_24159, 0)), ((V)&g_heff_2esyntax_2esurface_2eexprL_str19))) {
            heff_drop_cell(v_ru_24it1_24157_24Atom, 1);
            HEFF_LAST return g_heff_2esyntax_2esurface_2ekwAtom(v_t_24159, v_fs_24158, v_z_242);
          } else {
            V v_e_24162 = (g_heff_2esyntax_2esurface_2eatomTok(v_t_24159));
            V v_t_24163 = (g_list_2emap_24s513201124x806973253(v_fs_24158));
            V v_x_24164 = (g_heff_2esyntax_2epresyntax_2eapp(v_e_24162, v_t_24163));
            return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24it1_24157_24Atom, TAG_Right, 1, (V[]){v_x_24164}), v_z_242});
          }
        }
      }
      case TAG_EParen: {
        V v_m_24168 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24157}));
        V v_x1_24169 = heff_tr(heff_call(v_m_24168, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24169)) {
        case TAG_MkPair: {
          V v_x11_24170 = heff_field(v_x1_24169, 0);
          V v_st_24171 = heff_field(v_x1_24169, 1);
          V v_ru_24x1_24169_24MkPair = heff_take_reuse_n(v_x1_24169, 3ULL, 2);
          switch (heff_tag_of(v_x11_24170)) {
          case TAG_Left: {
            V v_e_24172 = heff_field(v_x11_24170, 0);
            heff_take_n(v_x11_24170, 1ULL, 1);
            heff_drop(v_fs_24158);
            return heff_tag_at_n(v_ru_24x1_24169_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24172}), v_st_24171});
          }
          case TAG_Right: {
            V v_x_24173 = heff_field(v_x11_24170, 0);
            heff_take_n(v_x11_24170, 1ULL, 1);
            V v_t_24174 = (g_list_2emap_24s513201124x806973253(v_fs_24158));
            V v_x_24175 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24173, v_t_24174));
            return heff_tag_at_n(v_ru_24x1_24169_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24175}), v_st_24171});
          }
          default: return heff_nomatch(v_x11_24170);
          }
        }
        default: return heff_nomatch(v_x1_24169);
        }
      }
      case TAG_Named: {
        V v_m_24181 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24157}));
        V v_x1_24182 = heff_tr(heff_call(v_m_24181, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24182)) {
        case TAG_MkPair: {
          V v_x11_24183 = heff_field(v_x1_24182, 0);
          V v_st_24184 = heff_field(v_x1_24182, 1);
          V v_ru_24x1_24182_24MkPair = heff_take_reuse_n(v_x1_24182, 3ULL, 2);
          switch (heff_tag_of(v_x11_24183)) {
          case TAG_Left: {
            V v_e_24185 = heff_field(v_x11_24183, 0);
            heff_take_n(v_x11_24183, 1ULL, 1);
            heff_drop(v_fs_24158);
            return heff_tag_at_n(v_ru_24x1_24182_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24185}), v_st_24184});
          }
          case TAG_Right: {
            V v_x_24186 = heff_field(v_x11_24183, 0);
            heff_take_n(v_x11_24183, 1ULL, 1);
            V v_t_24187 = (g_list_2emap_24s513201124x806973253(v_fs_24158));
            V v_x_24188 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24186, v_t_24187));
            return heff_tag_at_n(v_ru_24x1_24182_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24188}), v_st_24184});
          }
          default: return heff_nomatch(v_x11_24183);
          }
        }
        default: return heff_nomatch(v_x1_24182);
        }
      }
      case TAG_Tup: {
        V v_m_24193 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24157}));
        V v_x1_24194 = heff_tr(heff_call(v_m_24193, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24194)) {
        case TAG_MkPair: {
          V v_x11_24195 = heff_field(v_x1_24194, 0);
          V v_st_24196 = heff_field(v_x1_24194, 1);
          V v_ru_24x1_24194_24MkPair = heff_take_reuse_n(v_x1_24194, 3ULL, 2);
          switch (heff_tag_of(v_x11_24195)) {
          case TAG_Left: {
            V v_e_24197 = heff_field(v_x11_24195, 0);
            heff_take_n(v_x11_24195, 1ULL, 1);
            heff_drop(v_fs_24158);
            return heff_tag_at_n(v_ru_24x1_24194_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24197}), v_st_24196});
          }
          case TAG_Right: {
            V v_x_24198 = heff_field(v_x11_24195, 0);
            heff_take_n(v_x11_24195, 1ULL, 1);
            V v_t_24199 = (g_list_2emap_24s513201124x806973253(v_fs_24158));
            V v_x_24200 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24198, v_t_24199));
            return heff_tag_at_n(v_ru_24x1_24194_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24200}), v_st_24196});
          }
          default: return heff_nomatch(v_x11_24195);
          }
        }
        default: return heff_nomatch(v_x1_24194);
        }
      }
      case TAG_Seg: {
        V v_m_24204 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24157}));
        V v_x1_24205 = heff_tr(heff_call(v_m_24204, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24205)) {
        case TAG_MkPair: {
          V v_x11_24206 = heff_field(v_x1_24205, 0);
          V v_st_24207 = heff_field(v_x1_24205, 1);
          V v_ru_24x1_24205_24MkPair = heff_take_reuse_n(v_x1_24205, 3ULL, 2);
          switch (heff_tag_of(v_x11_24206)) {
          case TAG_Left: {
            V v_e_24208 = heff_field(v_x11_24206, 0);
            heff_take_n(v_x11_24206, 1ULL, 1);
            heff_drop(v_fs_24158);
            return heff_tag_at_n(v_ru_24x1_24205_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24208}), v_st_24207});
          }
          case TAG_Right: {
            V v_x_24209 = heff_field(v_x11_24206, 0);
            heff_take_n(v_x11_24206, 1ULL, 1);
            V v_t_24210 = (g_list_2emap_24s513201124x806973253(v_fs_24158));
            V v_x_24211 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24209, v_t_24210));
            return heff_tag_at_n(v_ru_24x1_24205_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24211}), v_st_24207});
          }
          default: return heff_nomatch(v_x11_24206);
          }
        }
        default: return heff_nomatch(v_x1_24205);
        }
      }
      case TAG_Braces: {
        V v_m_24216 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24157}));
        V v_x1_24217 = heff_tr(heff_call(v_m_24216, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24217)) {
        case TAG_MkPair: {
          V v_x11_24218 = heff_field(v_x1_24217, 0);
          V v_st_24219 = heff_field(v_x1_24217, 1);
          V v_ru_24x1_24217_24MkPair = heff_take_reuse_n(v_x1_24217, 3ULL, 2);
          switch (heff_tag_of(v_x11_24218)) {
          case TAG_Left: {
            V v_e_24220 = heff_field(v_x11_24218, 0);
            heff_take_n(v_x11_24218, 1ULL, 1);
            heff_drop(v_fs_24158);
            return heff_tag_at_n(v_ru_24x1_24217_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24220}), v_st_24219});
          }
          case TAG_Right: {
            V v_x_24221 = heff_field(v_x11_24218, 0);
            heff_take_n(v_x11_24218, 1ULL, 1);
            V v_t_24222 = (g_list_2emap_24s513201124x806973253(v_fs_24158));
            V v_x_24223 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24221, v_t_24222));
            return heff_tag_at_n(v_ru_24x1_24217_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24223}), v_st_24219});
          }
          default: return heff_nomatch(v_x11_24218);
          }
        }
        default: return heff_nomatch(v_x1_24217);
        }
      }
      case TAG_Update: {
        V v_m_24230 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24157}));
        V v_x1_24231 = heff_tr(heff_call(v_m_24230, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24231)) {
        case TAG_MkPair: {
          V v_x11_24232 = heff_field(v_x1_24231, 0);
          V v_st_24233 = heff_field(v_x1_24231, 1);
          V v_ru_24x1_24231_24MkPair = heff_take_reuse_n(v_x1_24231, 3ULL, 2);
          switch (heff_tag_of(v_x11_24232)) {
          case TAG_Left: {
            V v_e_24234 = heff_field(v_x11_24232, 0);
            heff_take_n(v_x11_24232, 1ULL, 1);
            heff_drop(v_fs_24158);
            return heff_tag_at_n(v_ru_24x1_24231_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24234}), v_st_24233});
          }
          case TAG_Right: {
            V v_x_24235 = heff_field(v_x11_24232, 0);
            heff_take_n(v_x11_24232, 1ULL, 1);
            V v_t_24236 = (g_list_2emap_24s513201124x806973253(v_fs_24158));
            V v_x_24237 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24235, v_t_24236));
            return heff_tag_at_n(v_ru_24x1_24231_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24237}), v_st_24233});
          }
          default: return heff_nomatch(v_x11_24232);
          }
        }
        default: return heff_nomatch(v_x1_24231);
        }
      }
      case TAG_EUSet: {
        V v_m_24241 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24157}));
        V v_x1_24242 = heff_tr(heff_call(v_m_24241, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24242)) {
        case TAG_MkPair: {
          V v_x11_24243 = heff_field(v_x1_24242, 0);
          V v_st_24244 = heff_field(v_x1_24242, 1);
          V v_ru_24x1_24242_24MkPair = heff_take_reuse_n(v_x1_24242, 3ULL, 2);
          switch (heff_tag_of(v_x11_24243)) {
          case TAG_Left: {
            V v_e_24245 = heff_field(v_x11_24243, 0);
            heff_take_n(v_x11_24243, 1ULL, 1);
            heff_drop(v_fs_24158);
            return heff_tag_at_n(v_ru_24x1_24242_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24245}), v_st_24244});
          }
          case TAG_Right: {
            V v_x_24246 = heff_field(v_x11_24243, 0);
            heff_take_n(v_x11_24243, 1ULL, 1);
            V v_t_24247 = (g_list_2emap_24s513201124x806973253(v_fs_24158));
            V v_x_24248 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24246, v_t_24247));
            return heff_tag_at_n(v_ru_24x1_24242_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24248}), v_st_24244});
          }
          default: return heff_nomatch(v_x11_24243);
          }
        }
        default: return heff_nomatch(v_x1_24242);
        }
      }
      case TAG_InstB: {
        V v_m_24254 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24157}));
        V v_x1_24255 = heff_tr(heff_call(v_m_24254, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24255)) {
        case TAG_MkPair: {
          V v_x11_24256 = heff_field(v_x1_24255, 0);
          V v_st_24257 = heff_field(v_x1_24255, 1);
          V v_ru_24x1_24255_24MkPair = heff_take_reuse_n(v_x1_24255, 3ULL, 2);
          switch (heff_tag_of(v_x11_24256)) {
          case TAG_Left: {
            V v_e_24258 = heff_field(v_x11_24256, 0);
            heff_take_n(v_x11_24256, 1ULL, 1);
            heff_drop(v_fs_24158);
            return heff_tag_at_n(v_ru_24x1_24255_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24258}), v_st_24257});
          }
          case TAG_Right: {
            V v_x_24259 = heff_field(v_x11_24256, 0);
            heff_take_n(v_x11_24256, 1ULL, 1);
            V v_t_24260 = (g_list_2emap_24s513201124x806973253(v_fs_24158));
            V v_x_24261 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24259, v_t_24260));
            return heff_tag_at_n(v_ru_24x1_24255_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24261}), v_st_24257});
          }
          default: return heff_nomatch(v_x11_24256);
          }
        }
        default: return heff_nomatch(v_x1_24255);
        }
      }
      case TAG_EFSet: {
        V v_m_24265 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24157}));
        V v_x1_24266 = heff_tr(heff_call(v_m_24265, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24266)) {
        case TAG_MkPair: {
          V v_x11_24267 = heff_field(v_x1_24266, 0);
          V v_st_24268 = heff_field(v_x1_24266, 1);
          V v_ru_24x1_24266_24MkPair = heff_take_reuse_n(v_x1_24266, 3ULL, 2);
          switch (heff_tag_of(v_x11_24267)) {
          case TAG_Left: {
            V v_e_24269 = heff_field(v_x11_24267, 0);
            heff_take_n(v_x11_24267, 1ULL, 1);
            heff_drop(v_fs_24158);
            return heff_tag_at_n(v_ru_24x1_24266_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24269}), v_st_24268});
          }
          case TAG_Right: {
            V v_x_24270 = heff_field(v_x11_24267, 0);
            heff_take_n(v_x11_24267, 1ULL, 1);
            V v_t_24271 = (g_list_2emap_24s513201124x806973253(v_fs_24158));
            V v_x_24272 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24270, v_t_24271));
            return heff_tag_at_n(v_ru_24x1_24266_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24272}), v_st_24268});
          }
          default: return heff_nomatch(v_x11_24267);
          }
        }
        default: return heff_nomatch(v_x1_24266);
        }
      }
      case TAG_EFDefault: {
        V v_m_24276 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24157}));
        V v_x1_24277 = heff_tr(heff_call(v_m_24276, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24277)) {
        case TAG_MkPair: {
          V v_x11_24278 = heff_field(v_x1_24277, 0);
          V v_st_24279 = heff_field(v_x1_24277, 1);
          V v_ru_24x1_24277_24MkPair = heff_take_reuse_n(v_x1_24277, 3ULL, 2);
          switch (heff_tag_of(v_x11_24278)) {
          case TAG_Left: {
            V v_e_24280 = heff_field(v_x11_24278, 0);
            heff_take_n(v_x11_24278, 1ULL, 1);
            heff_drop(v_fs_24158);
            return heff_tag_at_n(v_ru_24x1_24277_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24280}), v_st_24279});
          }
          case TAG_Right: {
            V v_x_24281 = heff_field(v_x11_24278, 0);
            heff_take_n(v_x11_24278, 1ULL, 1);
            V v_t_24282 = (g_list_2emap_24s513201124x806973253(v_fs_24158));
            V v_x_24283 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24281, v_t_24282));
            return heff_tag_at_n(v_ru_24x1_24277_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24283}), v_st_24279});
          }
          default: return heff_nomatch(v_x11_24278);
          }
        }
        default: return heff_nomatch(v_x1_24277);
        }
      }
      case TAG_Sum: {
        V v_m_24289 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24157}));
        V v_x1_24290 = heff_tr(heff_call(v_m_24289, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24290)) {
        case TAG_MkPair: {
          V v_x11_24291 = heff_field(v_x1_24290, 0);
          V v_st_24292 = heff_field(v_x1_24290, 1);
          V v_ru_24x1_24290_24MkPair = heff_take_reuse_n(v_x1_24290, 3ULL, 2);
          switch (heff_tag_of(v_x11_24291)) {
          case TAG_Left: {
            V v_e_24293 = heff_field(v_x11_24291, 0);
            heff_take_n(v_x11_24291, 1ULL, 1);
            heff_drop(v_fs_24158);
            return heff_tag_at_n(v_ru_24x1_24290_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24293}), v_st_24292});
          }
          case TAG_Right: {
            V v_x_24294 = heff_field(v_x11_24291, 0);
            heff_take_n(v_x11_24291, 1ULL, 1);
            V v_t_24295 = (g_list_2emap_24s513201124x806973253(v_fs_24158));
            V v_x_24296 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24294, v_t_24295));
            return heff_tag_at_n(v_ru_24x1_24290_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24296}), v_st_24292});
          }
          default: return heff_nomatch(v_x11_24291);
          }
        }
        default: return heff_nomatch(v_x1_24290);
        }
      }
      case TAG_ECon: {
        V v_m_24299 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24157}));
        V v_x1_24300 = heff_tr(heff_call(v_m_24299, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24300)) {
        case TAG_MkPair: {
          V v_x11_24301 = heff_field(v_x1_24300, 0);
          V v_st_24302 = heff_field(v_x1_24300, 1);
          V v_ru_24x1_24300_24MkPair = heff_take_reuse_n(v_x1_24300, 3ULL, 2);
          switch (heff_tag_of(v_x11_24301)) {
          case TAG_Left: {
            V v_e_24303 = heff_field(v_x11_24301, 0);
            heff_take_n(v_x11_24301, 1ULL, 1);
            heff_drop(v_fs_24158);
            return heff_tag_at_n(v_ru_24x1_24300_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24303}), v_st_24302});
          }
          case TAG_Right: {
            V v_x_24304 = heff_field(v_x11_24301, 0);
            heff_take_n(v_x11_24301, 1ULL, 1);
            V v_t_24305 = (g_list_2emap_24s513201124x806973253(v_fs_24158));
            V v_x_24306 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24304, v_t_24305));
            return heff_tag_at_n(v_ru_24x1_24300_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24306}), v_st_24302});
          }
          default: return heff_nomatch(v_x11_24301);
          }
        }
        default: return heff_nomatch(v_x1_24300);
        }
      }
      case TAG_EField: {
        V v_m_24309 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24157}));
        V v_x1_24310 = heff_tr(heff_call(v_m_24309, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24310)) {
        case TAG_MkPair: {
          V v_x11_24311 = heff_field(v_x1_24310, 0);
          V v_st_24312 = heff_field(v_x1_24310, 1);
          V v_ru_24x1_24310_24MkPair = heff_take_reuse_n(v_x1_24310, 3ULL, 2);
          switch (heff_tag_of(v_x11_24311)) {
          case TAG_Left: {
            V v_e_24313 = heff_field(v_x11_24311, 0);
            heff_take_n(v_x11_24311, 1ULL, 1);
            heff_drop(v_fs_24158);
            return heff_tag_at_n(v_ru_24x1_24310_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24313}), v_st_24312});
          }
          case TAG_Right: {
            V v_x_24314 = heff_field(v_x11_24311, 0);
            heff_take_n(v_x11_24311, 1ULL, 1);
            V v_t_24315 = (g_list_2emap_24s513201124x806973253(v_fs_24158));
            V v_x_24316 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24314, v_t_24315));
            return heff_tag_at_n(v_ru_24x1_24310_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24316}), v_st_24312});
          }
          default: return heff_nomatch(v_x11_24311);
          }
        }
        default: return heff_nomatch(v_x1_24310);
        }
      }
      case TAG_ENeg: {
        V v_m_24319 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24157}));
        V v_x1_24320 = heff_tr(heff_call(v_m_24319, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24320)) {
        case TAG_MkPair: {
          V v_x11_24321 = heff_field(v_x1_24320, 0);
          V v_st_24322 = heff_field(v_x1_24320, 1);
          V v_ru_24x1_24320_24MkPair = heff_take_reuse_n(v_x1_24320, 3ULL, 2);
          switch (heff_tag_of(v_x11_24321)) {
          case TAG_Left: {
            V v_e_24323 = heff_field(v_x11_24321, 0);
            heff_take_n(v_x11_24321, 1ULL, 1);
            heff_drop(v_fs_24158);
            return heff_tag_at_n(v_ru_24x1_24320_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24323}), v_st_24322});
          }
          case TAG_Right: {
            V v_x_24324 = heff_field(v_x11_24321, 0);
            heff_take_n(v_x11_24321, 1ULL, 1);
            V v_t_24325 = (g_list_2emap_24s513201124x806973253(v_fs_24158));
            V v_x_24326 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24324, v_t_24325));
            return heff_tag_at_n(v_ru_24x1_24320_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24326}), v_st_24322});
          }
          default: return heff_nomatch(v_x11_24321);
          }
        }
        default: return heff_nomatch(v_x1_24320);
        }
      }
      case TAG_App: {
        V v_m_24329 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24157}));
        V v_x1_24330 = heff_tr(heff_call(v_m_24329, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24330)) {
        case TAG_MkPair: {
          V v_x11_24331 = heff_field(v_x1_24330, 0);
          V v_st_24332 = heff_field(v_x1_24330, 1);
          V v_ru_24x1_24330_24MkPair = heff_take_reuse_n(v_x1_24330, 3ULL, 2);
          switch (heff_tag_of(v_x11_24331)) {
          case TAG_Left: {
            V v_e_24333 = heff_field(v_x11_24331, 0);
            heff_take_n(v_x11_24331, 1ULL, 1);
            heff_drop(v_fs_24158);
            return heff_tag_at_n(v_ru_24x1_24330_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24333}), v_st_24332});
          }
          case TAG_Right: {
            V v_x_24334 = heff_field(v_x11_24331, 0);
            heff_take_n(v_x11_24331, 1ULL, 1);
            V v_t_24335 = (g_list_2emap_24s513201124x806973253(v_fs_24158));
            V v_x_24336 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24334, v_t_24335));
            return heff_tag_at_n(v_ru_24x1_24330_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24336}), v_st_24332});
          }
          default: return heff_nomatch(v_x11_24331);
          }
        }
        default: return heff_nomatch(v_x1_24330);
        }
      }
      case TAG_Op: {
        V v_m_24340 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24157}));
        V v_x1_24341 = heff_tr(heff_call(v_m_24340, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24341)) {
        case TAG_MkPair: {
          V v_x11_24342 = heff_field(v_x1_24341, 0);
          V v_st_24343 = heff_field(v_x1_24341, 1);
          V v_ru_24x1_24341_24MkPair = heff_take_reuse_n(v_x1_24341, 3ULL, 2);
          switch (heff_tag_of(v_x11_24342)) {
          case TAG_Left: {
            V v_e_24344 = heff_field(v_x11_24342, 0);
            heff_take_n(v_x11_24342, 1ULL, 1);
            heff_drop(v_fs_24158);
            return heff_tag_at_n(v_ru_24x1_24341_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24344}), v_st_24343});
          }
          case TAG_Right: {
            V v_x_24345 = heff_field(v_x11_24342, 0);
            heff_take_n(v_x11_24342, 1ULL, 1);
            V v_t_24346 = (g_list_2emap_24s513201124x806973253(v_fs_24158));
            V v_x_24347 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24345, v_t_24346));
            return heff_tag_at_n(v_ru_24x1_24341_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24347}), v_st_24343});
          }
          default: return heff_nomatch(v_x11_24342);
          }
        }
        default: return heff_nomatch(v_x1_24341);
        }
      }
      case TAG_Ops: {
        V v_m_24350 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24157}));
        V v_x1_24351 = heff_tr(heff_call(v_m_24350, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24351)) {
        case TAG_MkPair: {
          V v_x11_24352 = heff_field(v_x1_24351, 0);
          V v_st_24353 = heff_field(v_x1_24351, 1);
          V v_ru_24x1_24351_24MkPair = heff_take_reuse_n(v_x1_24351, 3ULL, 2);
          switch (heff_tag_of(v_x11_24352)) {
          case TAG_Left: {
            V v_e_24354 = heff_field(v_x11_24352, 0);
            heff_take_n(v_x11_24352, 1ULL, 1);
            heff_drop(v_fs_24158);
            return heff_tag_at_n(v_ru_24x1_24351_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24354}), v_st_24353});
          }
          case TAG_Right: {
            V v_x_24355 = heff_field(v_x11_24352, 0);
            heff_take_n(v_x11_24352, 1ULL, 1);
            V v_t_24356 = (g_list_2emap_24s513201124x806973253(v_fs_24158));
            V v_x_24357 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24355, v_t_24356));
            return heff_tag_at_n(v_ru_24x1_24351_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24357}), v_st_24353});
          }
          default: return heff_nomatch(v_x11_24352);
          }
        }
        default: return heff_nomatch(v_x1_24351);
        }
      }
      case TAG_OpRhs: {
        V v_m_24360 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24157}));
        V v_x1_24361 = heff_tr(heff_call(v_m_24360, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24361)) {
        case TAG_MkPair: {
          V v_x11_24362 = heff_field(v_x1_24361, 0);
          V v_st_24363 = heff_field(v_x1_24361, 1);
          V v_ru_24x1_24361_24MkPair = heff_take_reuse_n(v_x1_24361, 3ULL, 2);
          switch (heff_tag_of(v_x11_24362)) {
          case TAG_Left: {
            V v_e_24364 = heff_field(v_x11_24362, 0);
            heff_take_n(v_x11_24362, 1ULL, 1);
            heff_drop(v_fs_24158);
            return heff_tag_at_n(v_ru_24x1_24361_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24364}), v_st_24363});
          }
          case TAG_Right: {
            V v_x_24365 = heff_field(v_x11_24362, 0);
            heff_take_n(v_x11_24362, 1ULL, 1);
            V v_t_24366 = (g_list_2emap_24s513201124x806973253(v_fs_24158));
            V v_x_24367 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24365, v_t_24366));
            return heff_tag_at_n(v_ru_24x1_24361_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24367}), v_st_24363});
          }
          default: return heff_nomatch(v_x11_24362);
          }
        }
        default: return heff_nomatch(v_x1_24361);
        }
      }
      case TAG_Ann: {
        V v_m_24371 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24157}));
        V v_x1_24372 = heff_tr(heff_call(v_m_24371, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24372)) {
        case TAG_MkPair: {
          V v_x11_24373 = heff_field(v_x1_24372, 0);
          V v_st_24374 = heff_field(v_x1_24372, 1);
          V v_ru_24x1_24372_24MkPair = heff_take_reuse_n(v_x1_24372, 3ULL, 2);
          switch (heff_tag_of(v_x11_24373)) {
          case TAG_Left: {
            V v_e_24375 = heff_field(v_x11_24373, 0);
            heff_take_n(v_x11_24373, 1ULL, 1);
            heff_drop(v_fs_24158);
            return heff_tag_at_n(v_ru_24x1_24372_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24375}), v_st_24374});
          }
          case TAG_Right: {
            V v_x_24376 = heff_field(v_x11_24373, 0);
            heff_take_n(v_x11_24373, 1ULL, 1);
            V v_t_24377 = (g_list_2emap_24s513201124x806973253(v_fs_24158));
            V v_x_24378 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24376, v_t_24377));
            return heff_tag_at_n(v_ru_24x1_24372_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24378}), v_st_24374});
          }
          default: return heff_nomatch(v_x11_24373);
          }
        }
        default: return heff_nomatch(v_x1_24372);
        }
      }
      case TAG_BVar: {
        V v_m_24380 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24157}));
        V v_x1_24381 = heff_tr(heff_call(v_m_24380, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24381)) {
        case TAG_MkPair: {
          V v_x11_24382 = heff_field(v_x1_24381, 0);
          V v_st_24383 = heff_field(v_x1_24381, 1);
          V v_ru_24x1_24381_24MkPair = heff_take_reuse_n(v_x1_24381, 3ULL, 2);
          switch (heff_tag_of(v_x11_24382)) {
          case TAG_Left: {
            V v_e_24384 = heff_field(v_x11_24382, 0);
            heff_take_n(v_x11_24382, 1ULL, 1);
            heff_drop(v_fs_24158);
            return heff_tag_at_n(v_ru_24x1_24381_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24384}), v_st_24383});
          }
          case TAG_Right: {
            V v_x_24385 = heff_field(v_x11_24382, 0);
            heff_take_n(v_x11_24382, 1ULL, 1);
            V v_t_24386 = (g_list_2emap_24s513201124x806973253(v_fs_24158));
            V v_x_24387 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24385, v_t_24386));
            return heff_tag_at_n(v_ru_24x1_24381_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24387}), v_st_24383});
          }
          default: return heff_nomatch(v_x11_24382);
          }
        }
        default: return heff_nomatch(v_x1_24381);
        }
      }
      case TAG_BImp: {
        V v_m_24391 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24157}));
        V v_x1_24392 = heff_tr(heff_call(v_m_24391, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24392)) {
        case TAG_MkPair: {
          V v_x11_24393 = heff_field(v_x1_24392, 0);
          V v_st_24394 = heff_field(v_x1_24392, 1);
          V v_ru_24x1_24392_24MkPair = heff_take_reuse_n(v_x1_24392, 3ULL, 2);
          switch (heff_tag_of(v_x11_24393)) {
          case TAG_Left: {
            V v_e_24395 = heff_field(v_x11_24393, 0);
            heff_take_n(v_x11_24393, 1ULL, 1);
            heff_drop(v_fs_24158);
            return heff_tag_at_n(v_ru_24x1_24392_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24395}), v_st_24394});
          }
          case TAG_Right: {
            V v_x_24396 = heff_field(v_x11_24393, 0);
            heff_take_n(v_x11_24393, 1ULL, 1);
            V v_t_24397 = (g_list_2emap_24s513201124x806973253(v_fs_24158));
            V v_x_24398 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24396, v_t_24397));
            return heff_tag_at_n(v_ru_24x1_24392_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24398}), v_st_24394});
          }
          default: return heff_nomatch(v_x11_24393);
          }
        }
        default: return heff_nomatch(v_x1_24392);
        }
      }
      case TAG_BAnn: {
        V v_m_24404 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24157}));
        V v_x1_24405 = heff_tr(heff_call(v_m_24404, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24405)) {
        case TAG_MkPair: {
          V v_x11_24406 = heff_field(v_x1_24405, 0);
          V v_st_24407 = heff_field(v_x1_24405, 1);
          V v_ru_24x1_24405_24MkPair = heff_take_reuse_n(v_x1_24405, 3ULL, 2);
          switch (heff_tag_of(v_x11_24406)) {
          case TAG_Left: {
            V v_e_24408 = heff_field(v_x11_24406, 0);
            heff_take_n(v_x11_24406, 1ULL, 1);
            heff_drop(v_fs_24158);
            return heff_tag_at_n(v_ru_24x1_24405_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24408}), v_st_24407});
          }
          case TAG_Right: {
            V v_x_24409 = heff_field(v_x11_24406, 0);
            heff_take_n(v_x11_24406, 1ULL, 1);
            V v_t_24410 = (g_list_2emap_24s513201124x806973253(v_fs_24158));
            V v_x_24411 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24409, v_t_24410));
            return heff_tag_at_n(v_ru_24x1_24405_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24411}), v_st_24407});
          }
          default: return heff_nomatch(v_x11_24406);
          }
        }
        default: return heff_nomatch(v_x1_24405);
        }
      }
      case TAG_Lam: {
        V v_m_24416 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24157}));
        V v_x1_24417 = heff_tr(heff_call(v_m_24416, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24417)) {
        case TAG_MkPair: {
          V v_x11_24418 = heff_field(v_x1_24417, 0);
          V v_st_24419 = heff_field(v_x1_24417, 1);
          V v_ru_24x1_24417_24MkPair = heff_take_reuse_n(v_x1_24417, 3ULL, 2);
          switch (heff_tag_of(v_x11_24418)) {
          case TAG_Left: {
            V v_e_24420 = heff_field(v_x11_24418, 0);
            heff_take_n(v_x11_24418, 1ULL, 1);
            heff_drop(v_fs_24158);
            return heff_tag_at_n(v_ru_24x1_24417_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24420}), v_st_24419});
          }
          case TAG_Right: {
            V v_x_24421 = heff_field(v_x11_24418, 0);
            heff_take_n(v_x11_24418, 1ULL, 1);
            V v_t_24422 = (g_list_2emap_24s513201124x806973253(v_fs_24158));
            V v_x_24423 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24421, v_t_24422));
            return heff_tag_at_n(v_ru_24x1_24417_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24423}), v_st_24419});
          }
          default: return heff_nomatch(v_x11_24418);
          }
        }
        default: return heff_nomatch(v_x1_24417);
        }
      }
      case TAG_Case: {
        V v_m_24428 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24157}));
        V v_x1_24429 = heff_tr(heff_call(v_m_24428, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24429)) {
        case TAG_MkPair: {
          V v_x11_24430 = heff_field(v_x1_24429, 0);
          V v_st_24431 = heff_field(v_x1_24429, 1);
          V v_ru_24x1_24429_24MkPair = heff_take_reuse_n(v_x1_24429, 3ULL, 2);
          switch (heff_tag_of(v_x11_24430)) {
          case TAG_Left: {
            V v_e_24432 = heff_field(v_x11_24430, 0);
            heff_take_n(v_x11_24430, 1ULL, 1);
            heff_drop(v_fs_24158);
            return heff_tag_at_n(v_ru_24x1_24429_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24432}), v_st_24431});
          }
          case TAG_Right: {
            V v_x_24433 = heff_field(v_x11_24430, 0);
            heff_take_n(v_x11_24430, 1ULL, 1);
            V v_t_24434 = (g_list_2emap_24s513201124x806973253(v_fs_24158));
            V v_x_24435 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24433, v_t_24434));
            return heff_tag_at_n(v_ru_24x1_24429_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24435}), v_st_24431});
          }
          default: return heff_nomatch(v_x11_24430);
          }
        }
        default: return heff_nomatch(v_x1_24429);
        }
      }
      case TAG_EAlt: {
        V v_m_24439 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24157}));
        V v_x1_24440 = heff_tr(heff_call(v_m_24439, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24440)) {
        case TAG_MkPair: {
          V v_x11_24441 = heff_field(v_x1_24440, 0);
          V v_st_24442 = heff_field(v_x1_24440, 1);
          V v_ru_24x1_24440_24MkPair = heff_take_reuse_n(v_x1_24440, 3ULL, 2);
          switch (heff_tag_of(v_x11_24441)) {
          case TAG_Left: {
            V v_e_24443 = heff_field(v_x11_24441, 0);
            heff_take_n(v_x11_24441, 1ULL, 1);
            heff_drop(v_fs_24158);
            return heff_tag_at_n(v_ru_24x1_24440_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24443}), v_st_24442});
          }
          case TAG_Right: {
            V v_x_24444 = heff_field(v_x11_24441, 0);
            heff_take_n(v_x11_24441, 1ULL, 1);
            V v_t_24445 = (g_list_2emap_24s513201124x806973253(v_fs_24158));
            V v_x_24446 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24444, v_t_24445));
            return heff_tag_at_n(v_ru_24x1_24440_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24446}), v_st_24442});
          }
          default: return heff_nomatch(v_x11_24441);
          }
        }
        default: return heff_nomatch(v_x1_24440);
        }
      }
      case TAG_If: {
        V v_m_24453 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24157}));
        V v_x1_24454 = heff_tr(heff_call(v_m_24453, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24454)) {
        case TAG_MkPair: {
          V v_x11_24455 = heff_field(v_x1_24454, 0);
          V v_st_24456 = heff_field(v_x1_24454, 1);
          V v_ru_24x1_24454_24MkPair = heff_take_reuse_n(v_x1_24454, 3ULL, 2);
          switch (heff_tag_of(v_x11_24455)) {
          case TAG_Left: {
            V v_e_24457 = heff_field(v_x11_24455, 0);
            heff_take_n(v_x11_24455, 1ULL, 1);
            heff_drop(v_fs_24158);
            return heff_tag_at_n(v_ru_24x1_24454_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24457}), v_st_24456});
          }
          case TAG_Right: {
            V v_x_24458 = heff_field(v_x11_24455, 0);
            heff_take_n(v_x11_24455, 1ULL, 1);
            V v_t_24459 = (g_list_2emap_24s513201124x806973253(v_fs_24158));
            V v_x_24460 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24458, v_t_24459));
            return heff_tag_at_n(v_ru_24x1_24454_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24460}), v_st_24456});
          }
          default: return heff_nomatch(v_x11_24455);
          }
        }
        default: return heff_nomatch(v_x1_24454);
        }
      }
      case TAG_Do: {
        V v_m_24463 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24157}));
        V v_x1_24464 = heff_tr(heff_call(v_m_24463, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24464)) {
        case TAG_MkPair: {
          V v_x11_24465 = heff_field(v_x1_24464, 0);
          V v_st_24466 = heff_field(v_x1_24464, 1);
          V v_ru_24x1_24464_24MkPair = heff_take_reuse_n(v_x1_24464, 3ULL, 2);
          switch (heff_tag_of(v_x11_24465)) {
          case TAG_Left: {
            V v_e_24467 = heff_field(v_x11_24465, 0);
            heff_take_n(v_x11_24465, 1ULL, 1);
            heff_drop(v_fs_24158);
            return heff_tag_at_n(v_ru_24x1_24464_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24467}), v_st_24466});
          }
          case TAG_Right: {
            V v_x_24468 = heff_field(v_x11_24465, 0);
            heff_take_n(v_x11_24465, 1ULL, 1);
            V v_t_24469 = (g_list_2emap_24s513201124x806973253(v_fs_24158));
            V v_x_24470 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24468, v_t_24469));
            return heff_tag_at_n(v_ru_24x1_24464_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24470}), v_st_24466});
          }
          default: return heff_nomatch(v_x11_24465);
          }
        }
        default: return heff_nomatch(v_x1_24464);
        }
      }
      case TAG_ESBind: {
        V v_m_24474 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24157}));
        V v_x1_24475 = heff_tr(heff_call(v_m_24474, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24475)) {
        case TAG_MkPair: {
          V v_x11_24476 = heff_field(v_x1_24475, 0);
          V v_st_24477 = heff_field(v_x1_24475, 1);
          V v_ru_24x1_24475_24MkPair = heff_take_reuse_n(v_x1_24475, 3ULL, 2);
          switch (heff_tag_of(v_x11_24476)) {
          case TAG_Left: {
            V v_e_24478 = heff_field(v_x11_24476, 0);
            heff_take_n(v_x11_24476, 1ULL, 1);
            heff_drop(v_fs_24158);
            return heff_tag_at_n(v_ru_24x1_24475_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24478}), v_st_24477});
          }
          case TAG_Right: {
            V v_x_24479 = heff_field(v_x11_24476, 0);
            heff_take_n(v_x11_24476, 1ULL, 1);
            V v_t_24480 = (g_list_2emap_24s513201124x806973253(v_fs_24158));
            V v_x_24481 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24479, v_t_24480));
            return heff_tag_at_n(v_ru_24x1_24475_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24481}), v_st_24477});
          }
          default: return heff_nomatch(v_x11_24476);
          }
        }
        default: return heff_nomatch(v_x1_24475);
        }
      }
      case TAG_ELet: {
        V v_m_24488 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24157}));
        V v_x1_24489 = heff_tr(heff_call(v_m_24488, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24489)) {
        case TAG_MkPair: {
          V v_x11_24490 = heff_field(v_x1_24489, 0);
          V v_st_24491 = heff_field(v_x1_24489, 1);
          V v_ru_24x1_24489_24MkPair = heff_take_reuse_n(v_x1_24489, 3ULL, 2);
          switch (heff_tag_of(v_x11_24490)) {
          case TAG_Left: {
            V v_e_24492 = heff_field(v_x11_24490, 0);
            heff_take_n(v_x11_24490, 1ULL, 1);
            heff_drop(v_fs_24158);
            return heff_tag_at_n(v_ru_24x1_24489_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24492}), v_st_24491});
          }
          case TAG_Right: {
            V v_x_24493 = heff_field(v_x11_24490, 0);
            heff_take_n(v_x11_24490, 1ULL, 1);
            V v_t_24494 = (g_list_2emap_24s513201124x806973253(v_fs_24158));
            V v_x_24495 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24493, v_t_24494));
            return heff_tag_at_n(v_ru_24x1_24489_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24495}), v_st_24491});
          }
          default: return heff_nomatch(v_x11_24490);
          }
        }
        default: return heff_nomatch(v_x1_24489);
        }
      }
      case TAG_ELetMut: {
        V v_m_24502 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24157}));
        V v_x1_24503 = heff_tr(heff_call(v_m_24502, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24503)) {
        case TAG_MkPair: {
          V v_x11_24504 = heff_field(v_x1_24503, 0);
          V v_st_24505 = heff_field(v_x1_24503, 1);
          V v_ru_24x1_24503_24MkPair = heff_take_reuse_n(v_x1_24503, 3ULL, 2);
          switch (heff_tag_of(v_x11_24504)) {
          case TAG_Left: {
            V v_e_24506 = heff_field(v_x11_24504, 0);
            heff_take_n(v_x11_24504, 1ULL, 1);
            heff_drop(v_fs_24158);
            return heff_tag_at_n(v_ru_24x1_24503_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24506}), v_st_24505});
          }
          case TAG_Right: {
            V v_x_24507 = heff_field(v_x11_24504, 0);
            heff_take_n(v_x11_24504, 1ULL, 1);
            V v_t_24508 = (g_list_2emap_24s513201124x806973253(v_fs_24158));
            V v_x_24509 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24507, v_t_24508));
            return heff_tag_at_n(v_ru_24x1_24503_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24509}), v_st_24505});
          }
          default: return heff_nomatch(v_x11_24504);
          }
        }
        default: return heff_nomatch(v_x1_24503);
        }
      }
      case TAG_EAssign: {
        V v_m_24513 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24157}));
        V v_x1_24514 = heff_tr(heff_call(v_m_24513, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24514)) {
        case TAG_MkPair: {
          V v_x11_24515 = heff_field(v_x1_24514, 0);
          V v_st_24516 = heff_field(v_x1_24514, 1);
          V v_ru_24x1_24514_24MkPair = heff_take_reuse_n(v_x1_24514, 3ULL, 2);
          switch (heff_tag_of(v_x11_24515)) {
          case TAG_Left: {
            V v_e_24517 = heff_field(v_x11_24515, 0);
            heff_take_n(v_x11_24515, 1ULL, 1);
            heff_drop(v_fs_24158);
            return heff_tag_at_n(v_ru_24x1_24514_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24517}), v_st_24516});
          }
          case TAG_Right: {
            V v_x_24518 = heff_field(v_x11_24515, 0);
            heff_take_n(v_x11_24515, 1ULL, 1);
            V v_t_24519 = (g_list_2emap_24s513201124x806973253(v_fs_24158));
            V v_x_24520 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24518, v_t_24519));
            return heff_tag_at_n(v_ru_24x1_24514_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24520}), v_st_24516});
          }
          default: return heff_nomatch(v_x11_24515);
          }
        }
        default: return heff_nomatch(v_x1_24514);
        }
      }
      case TAG_EWhile: {
        V v_m_24525 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24157}));
        V v_x1_24526 = heff_tr(heff_call(v_m_24525, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24526)) {
        case TAG_MkPair: {
          V v_x11_24527 = heff_field(v_x1_24526, 0);
          V v_st_24528 = heff_field(v_x1_24526, 1);
          V v_ru_24x1_24526_24MkPair = heff_take_reuse_n(v_x1_24526, 3ULL, 2);
          switch (heff_tag_of(v_x11_24527)) {
          case TAG_Left: {
            V v_e_24529 = heff_field(v_x11_24527, 0);
            heff_take_n(v_x11_24527, 1ULL, 1);
            heff_drop(v_fs_24158);
            return heff_tag_at_n(v_ru_24x1_24526_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24529}), v_st_24528});
          }
          case TAG_Right: {
            V v_x_24530 = heff_field(v_x11_24527, 0);
            heff_take_n(v_x11_24527, 1ULL, 1);
            V v_t_24531 = (g_list_2emap_24s513201124x806973253(v_fs_24158));
            V v_x_24532 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24530, v_t_24531));
            return heff_tag_at_n(v_ru_24x1_24526_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24532}), v_st_24528});
          }
          default: return heff_nomatch(v_x11_24527);
          }
        }
        default: return heff_nomatch(v_x1_24526);
        }
      }
      case TAG_EFor: {
        V v_m_24539 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24157}));
        V v_x1_24540 = heff_tr(heff_call(v_m_24539, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24540)) {
        case TAG_MkPair: {
          V v_x11_24541 = heff_field(v_x1_24540, 0);
          V v_st_24542 = heff_field(v_x1_24540, 1);
          V v_ru_24x1_24540_24MkPair = heff_take_reuse_n(v_x1_24540, 3ULL, 2);
          switch (heff_tag_of(v_x11_24541)) {
          case TAG_Left: {
            V v_e_24543 = heff_field(v_x11_24541, 0);
            heff_take_n(v_x11_24541, 1ULL, 1);
            heff_drop(v_fs_24158);
            return heff_tag_at_n(v_ru_24x1_24540_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24543}), v_st_24542});
          }
          case TAG_Right: {
            V v_x_24544 = heff_field(v_x11_24541, 0);
            heff_take_n(v_x11_24541, 1ULL, 1);
            V v_t_24545 = (g_list_2emap_24s513201124x806973253(v_fs_24158));
            V v_x_24546 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24544, v_t_24545));
            return heff_tag_at_n(v_ru_24x1_24540_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24546}), v_st_24542});
          }
          default: return heff_nomatch(v_x11_24541);
          }
        }
        default: return heff_nomatch(v_x1_24540);
        }
      }
      case TAG_EJump: {
        V v_m_24548 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24157}));
        V v_x1_24549 = heff_tr(heff_call(v_m_24548, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24549)) {
        case TAG_MkPair: {
          V v_x11_24550 = heff_field(v_x1_24549, 0);
          V v_st_24551 = heff_field(v_x1_24549, 1);
          V v_ru_24x1_24549_24MkPair = heff_take_reuse_n(v_x1_24549, 3ULL, 2);
          switch (heff_tag_of(v_x11_24550)) {
          case TAG_Left: {
            V v_e_24552 = heff_field(v_x11_24550, 0);
            heff_take_n(v_x11_24550, 1ULL, 1);
            heff_drop(v_fs_24158);
            return heff_tag_at_n(v_ru_24x1_24549_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24552}), v_st_24551});
          }
          case TAG_Right: {
            V v_x_24553 = heff_field(v_x11_24550, 0);
            heff_take_n(v_x11_24550, 1ULL, 1);
            V v_t_24554 = (g_list_2emap_24s513201124x806973253(v_fs_24158));
            V v_x_24555 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24553, v_t_24554));
            return heff_tag_at_n(v_ru_24x1_24549_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24555}), v_st_24551});
          }
          default: return heff_nomatch(v_x11_24550);
          }
        }
        default: return heff_nomatch(v_x1_24549);
        }
      }
      case TAG_EReturn: {
        V v_m_24558 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24157}));
        V v_x1_24559 = heff_tr(heff_call(v_m_24558, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24559)) {
        case TAG_MkPair: {
          V v_x11_24560 = heff_field(v_x1_24559, 0);
          V v_st_24561 = heff_field(v_x1_24559, 1);
          V v_ru_24x1_24559_24MkPair = heff_take_reuse_n(v_x1_24559, 3ULL, 2);
          switch (heff_tag_of(v_x11_24560)) {
          case TAG_Left: {
            V v_e_24562 = heff_field(v_x11_24560, 0);
            heff_take_n(v_x11_24560, 1ULL, 1);
            heff_drop(v_fs_24158);
            return heff_tag_at_n(v_ru_24x1_24559_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24562}), v_st_24561});
          }
          case TAG_Right: {
            V v_x_24563 = heff_field(v_x11_24560, 0);
            heff_take_n(v_x11_24560, 1ULL, 1);
            V v_t_24564 = (g_list_2emap_24s513201124x806973253(v_fs_24158));
            V v_x_24565 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24563, v_t_24564));
            return heff_tag_at_n(v_ru_24x1_24559_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24565}), v_st_24561});
          }
          default: return heff_nomatch(v_x11_24560);
          }
        }
        default: return heff_nomatch(v_x1_24559);
        }
      }
      case TAG_ENest: {
        V v_m_24570 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24157}));
        V v_x1_24571 = heff_tr(heff_call(v_m_24570, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24571)) {
        case TAG_MkPair: {
          V v_x11_24572 = heff_field(v_x1_24571, 0);
          V v_st_24573 = heff_field(v_x1_24571, 1);
          V v_ru_24x1_24571_24MkPair = heff_take_reuse_n(v_x1_24571, 3ULL, 2);
          switch (heff_tag_of(v_x11_24572)) {
          case TAG_Left: {
            V v_e_24574 = heff_field(v_x11_24572, 0);
            heff_take_n(v_x11_24572, 1ULL, 1);
            heff_drop(v_fs_24158);
            return heff_tag_at_n(v_ru_24x1_24571_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24574}), v_st_24573});
          }
          case TAG_Right: {
            V v_x_24575 = heff_field(v_x11_24572, 0);
            heff_take_n(v_x11_24572, 1ULL, 1);
            V v_t_24576 = (g_list_2emap_24s513201124x806973253(v_fs_24158));
            V v_x_24577 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24575, v_t_24576));
            return heff_tag_at_n(v_ru_24x1_24571_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24577}), v_st_24573});
          }
          default: return heff_nomatch(v_x11_24572);
          }
        }
        default: return heff_nomatch(v_x1_24571);
        }
      }
      case TAG_IfThen: {
        V v_m_24582 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24157}));
        V v_x1_24583 = heff_tr(heff_call(v_m_24582, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24583)) {
        case TAG_MkPair: {
          V v_x11_24584 = heff_field(v_x1_24583, 0);
          V v_st_24585 = heff_field(v_x1_24583, 1);
          V v_ru_24x1_24583_24MkPair = heff_take_reuse_n(v_x1_24583, 3ULL, 2);
          switch (heff_tag_of(v_x11_24584)) {
          case TAG_Left: {
            V v_e_24586 = heff_field(v_x11_24584, 0);
            heff_take_n(v_x11_24584, 1ULL, 1);
            heff_drop(v_fs_24158);
            return heff_tag_at_n(v_ru_24x1_24583_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24586}), v_st_24585});
          }
          case TAG_Right: {
            V v_x_24587 = heff_field(v_x11_24584, 0);
            heff_take_n(v_x11_24584, 1ULL, 1);
            V v_t_24588 = (g_list_2emap_24s513201124x806973253(v_fs_24158));
            V v_x_24589 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24587, v_t_24588));
            return heff_tag_at_n(v_ru_24x1_24583_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24589}), v_st_24585});
          }
          default: return heff_nomatch(v_x11_24584);
          }
        }
        default: return heff_nomatch(v_x1_24583);
        }
      }
      default: return heff_nomatch(v_it1_24157);
      }
    }
  }
  case TAG_ENeg: {
    V v_m_24590 = heff_field(v_e0_241, 0);
    V v_e_24591 = heff_field(v_e0_241, 1);
    V v_ru_24e0_241_24ENeg = heff_take_reuse_n(v_e0_241, 3ULL, 2);
    V v_m_24592 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_24591}));
    V v_x1_24593 = heff_tr(heff_call(v_m_24592, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x1_24593)) {
    case TAG_MkPair: {
      V v_x11_24594 = heff_field(v_x1_24593, 0);
      V v_st_24595 = heff_field(v_x1_24593, 1);
      V v_ru_24x1_24593_24MkPair = heff_take_reuse_n(v_x1_24593, 3ULL, 2);
      switch (heff_tag_of(v_x11_24594)) {
      case TAG_Left: {
        V v_e_24596 = heff_field(v_x11_24594, 0);
        heff_take_n(v_x11_24594, 1ULL, 1);
        heff_drop_rec(v_m_24590, 9);
        heff_drop_cell(v_ru_24x1_24593_24MkPair, 2);
        return heff_tag_at_n(v_ru_24e0_241_24ENeg, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24596}), v_st_24595});
      }
      case TAG_Right: {
        V v_x_24597 = heff_field(v_x11_24594, 0);
        heff_take_n(v_x11_24594, 1ULL, 1);
        V v_t_24598 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_m_24590, 3), heff_get_n(v_m_24590, 4, 9)});
        V v_t_24599 = heff_tag_at_n(v_ru_24e0_241_24ENeg, TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2eexprL_str20)}), v_t_24598});
        V v_t_24600 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_24597, NTAG(TAG_Nil)});
        V v_x_24601 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_24599, v_t_24600));
        return heff_tag_at_n(v_ru_24x1_24593_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24601}), v_st_24595});
      }
      default: return heff_nomatch(v_x11_24594);
      }
    }
    default: return heff_nomatch(v_x1_24593);
    }
  }
  case TAG_App: {
    V v_h_24602 = heff_field(v_e0_241, 0);
    V v_args_24603 = heff_field(v_e0_241, 1);
    V v_ru_24e0_241_24App = heff_take_reuse_n(v_e0_241, 3ULL, 2);
    V v_m_24604 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_h_24602}));
    V v_x1_24605 = heff_tr(heff_call(v_m_24604, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x1_24605)) {
    case TAG_MkPair: {
      V v_x11_24606 = heff_field(v_x1_24605, 0);
      V v_st_24607 = heff_field(v_x1_24605, 1);
      heff_take_n(v_x1_24605, 3ULL, 2);
      switch (heff_tag_of(v_x11_24606)) {
      case TAG_Left: {
        V v_e_24608 = heff_field(v_x11_24606, 0);
        heff_take_n(v_x11_24606, 1ULL, 1);
        heff_drop_rec(v_r_240, 3);
        heff_drop(v_args_24603);
        return heff_tag_at_n(v_ru_24e0_241_24App, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24608}), v_st_24607});
      }
      case TAG_Right: {
        V v_x_24609 = heff_field(v_x11_24606, 0);
        heff_take_n(v_x11_24606, 1ULL, 1);
        V v_m_24611 = (g_prelude_2etraverse_24s499544530x2060473942(heff_clo_n(g_heff_2esyntax_2esurface_2eexprL_lam4, 1, 1, (V[]){v_r_240}), v_args_24603));
        V v_x1_24612 = heff_tr(heff_call(v_m_24611, 1, (V[]){v_st_24607}));
        switch (heff_tag_of(v_x1_24612)) {
        case TAG_MkPair: {
          V v_x11_24613 = heff_field(v_x1_24612, 0);
          V v_st_24614 = heff_field(v_x1_24612, 1);
          heff_take_n(v_x1_24612, 3ULL, 2);
          switch (heff_tag_of(v_x11_24613)) {
          case TAG_Left: {
            V v_e_24615 = heff_field(v_x11_24613, 0);
            heff_take_n(v_x11_24613, 1ULL, 1);
            heff_drop(v_x_24609);
            return heff_tag_at_n(v_ru_24e0_241_24App, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24615}), v_st_24614});
          }
          case TAG_Right: {
            V v_x_24616 = heff_field(v_x11_24613, 0);
            heff_take_n(v_x11_24613, 1ULL, 1);
            V v_x_24617 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24609, v_x_24616));
            return heff_tag_at_n(v_ru_24e0_241_24App, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24617}), v_st_24614});
          }
          default: return heff_nomatch(v_x11_24613);
          }
        }
        default: return heff_nomatch(v_x1_24612);
        }
      }
      default: return heff_nomatch(v_x11_24606);
      }
    }
    default: return heff_nomatch(v_x1_24605);
    }
  }
  case TAG_Op: {
    V v_a_24618 = heff_field(v_e0_241, 0);
    V v_op_24619 = heff_field(v_e0_241, 1);
    V v_b_24620 = heff_field(v_e0_241, 2);
    heff_take_n(v_e0_241, 7ULL, 3);
    return (g_heff_2esyntax_2esurface_2eopL(v_r_240, v_a_24618, v_op_24619, v_b_24620, v_z_242));
  }
  case TAG_Ops: {
    V v_a_24621 = heff_field(v_e0_241, 0);
    V v_rest_24622 = heff_field(v_e0_241, 1);
    V v_ru_24e0_241_24Ops = heff_take_reuse_n(v_e0_241, 3ULL, 2);
    V v_m_24623 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_24621}));
    V v_x1_24624 = heff_tr(heff_call(v_m_24623, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x1_24624)) {
    case TAG_MkPair: {
      V v_x11_24625 = heff_field(v_x1_24624, 0);
      V v_st_24626 = heff_field(v_x1_24624, 1);
      heff_take_n(v_x1_24624, 3ULL, 2);
      switch (heff_tag_of(v_x11_24625)) {
      case TAG_Left: {
        V v_e_24627 = heff_field(v_x11_24625, 0);
        heff_take_n(v_x11_24625, 1ULL, 1);
        heff_drop_rec(v_r_240, 3);
        heff_drop(v_rest_24622);
        return heff_tag_at_n(v_ru_24e0_241_24Ops, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24627}), v_st_24626});
      }
      case TAG_Right: {
        V v_x_24628 = heff_field(v_x11_24625, 0);
        heff_take_n(v_x11_24625, 1ULL, 1);
        V v_m_24643 = (g_prelude_2etraverse_24s499544530x2060473942(heff_clo_n(g_heff_2esyntax_2esurface_2eexprL_lam5, 1, 1, (V[]){v_r_240}), v_rest_24622));
        V v_x1_24644 = heff_tr(heff_call(v_m_24643, 1, (V[]){v_st_24626}));
        switch (heff_tag_of(v_x1_24644)) {
        case TAG_MkPair: {
          V v_x11_24645 = heff_field(v_x1_24644, 0);
          V v_st_24646 = heff_field(v_x1_24644, 1);
          heff_take_n(v_x1_24644, 3ULL, 2);
          switch (heff_tag_of(v_x11_24645)) {
          case TAG_Left: {
            V v_e_24647 = heff_field(v_x11_24645, 0);
            heff_take_n(v_x11_24645, 1ULL, 1);
            heff_drop(v_x_24628);
            return heff_tag_at_n(v_ru_24e0_241_24Ops, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24647}), v_st_24646});
          }
          case TAG_Right: {
            V v_x_24648 = heff_field(v_x11_24645, 0);
            heff_take_n(v_x11_24645, 1ULL, 1);
            heff_drop_cell(v_ru_24e0_241_24Ops, 2);
            HEFF_LAST return g_heff_2esyntax_2esurface_2eresolve_24s1832151779x1448561609(v_x_24628, v_x_24648, v_st_24646);
          }
          default: return heff_nomatch(v_x11_24645);
          }
        }
        default: return heff_nomatch(v_x1_24644);
        }
      }
      default: return heff_nomatch(v_x11_24625);
      }
    }
    default: return heff_nomatch(v_x1_24624);
    }
  }
  case TAG_OpRhs: {
    heff_drop_rec(v_r_240, 3);
    V v_t_24651 = (g_heff_2esyntax_2ecst_2efirstE(v_e0_241));
    V v_t_24652 = ({ V a_0 = v_e0_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e0_241, 2); r_; });
    V v_t_24653 = heff_strAppend(heff_get_n(v_t_24652, 1, 9), ((V)&g_heff_2esyntax_2esurface_2eexprL_str21));
    V v_msg_24654 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eexprL_str22), v_t_24653);
    V v_t_24655 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24651, 3), heff_get_n(v_t_24651, 4, 9)});
    V v_t_24656 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24654, v_t_24655, NTAG(TAG_Nothing)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24656}), v_z_242});
  }
  case TAG_Ann: {
    V v_e_24657 = heff_field(v_e0_241, 0);
    V v_ty_24659 = heff_field(v_e0_241, 2);
    heff_take_n(v_e0_241, 5ULL, 3);
    V v_m_24660 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e_24657}));
    V v_x1_24661 = heff_tr(heff_call(v_m_24660, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x1_24661)) {
    case TAG_MkPair: {
      V v_x11_24662 = heff_field(v_x1_24661, 0);
      V v_st_24663 = heff_field(v_x1_24661, 1);
      V v_ru_24x1_24661_24MkPair = heff_take_reuse_n(v_x1_24661, 3ULL, 2);
      switch (heff_tag_of(v_x11_24662)) {
      case TAG_Left: {
        V v_e_24664 = heff_field(v_x11_24662, 0);
        heff_take_n(v_x11_24662, 1ULL, 1);
        heff_drop_rec(v_r_240, 3);
        heff_drop(v_ty_24659);
        return heff_tag_at_n(v_ru_24x1_24661_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24664}), v_st_24663});
      }
      case TAG_Right: {
        V v_x_24665 = heff_field(v_x11_24662, 0);
        heff_take_n(v_x11_24662, 1ULL, 1);
        V v_m_24666 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_ty_24659}));
        V v_x1_24667 = heff_tr(heff_call(v_m_24666, 1, (V[]){v_st_24663}));
        switch (heff_tag_of(v_x1_24667)) {
        case TAG_MkPair: {
          V v_x11_24668 = heff_field(v_x1_24667, 0);
          V v_st_24669 = heff_field(v_x1_24667, 1);
          V v_ru_24x1_24667_24MkPair = heff_take_reuse_n(v_x1_24667, 3ULL, 2);
          switch (heff_tag_of(v_x11_24668)) {
          case TAG_Left: {
            V v_e_24670 = heff_field(v_x11_24668, 0);
            heff_take_n(v_x11_24668, 1ULL, 1);
            heff_drop(v_x_24665);
            heff_drop_cell(v_ru_24x1_24667_24MkPair, 2);
            return heff_tag_at_n(v_ru_24x1_24661_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24670}), v_st_24669});
          }
          case TAG_Right: {
            V v_x_24671 = heff_field(v_x11_24668, 0);
            heff_take_n(v_x11_24668, 1ULL, 1);
            V v_t_24674;
            switch (heff_tag_of(v_x_24665)) {
            case TAG_At: {
              V v_s_24673 = heff_dup(heff_field(v_x_24665, 1));
              v_t_24674 = v_s_24673;
              break;
            }
            default: heff_nomatch(v_x_24665);
            }
            V v_t_24677;
            switch (heff_tag_of(v_x_24671)) {
            case TAG_At: {
              V v_s_24676 = heff_dup(heff_field(v_x_24671, 1));
              v_t_24677 = v_s_24676;
              break;
            }
            default: heff_nomatch(v_x_24671);
            }
            V v_t_24678 = ({ V rv_1 = heff_get_n(v_t_24677, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24674, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
            V v_t_24679 = heff_tag_at_n(v_ru_24x1_24667_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_EAnn, 2, (V[]){v_x_24665, v_x_24671}), v_t_24678});
            return heff_tag_at_n(v_ru_24x1_24661_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24679}), v_st_24669});
          }
          default: return heff_nomatch(v_x11_24668);
          }
        }
        default: return heff_nomatch(v_x1_24667);
        }
      }
      default: return heff_nomatch(v_x11_24662);
      }
    }
    default: return heff_nomatch(v_x1_24661);
    }
  }
  case TAG_BVar: {
    heff_drop_rec(v_r_240, 3);
    V v_t_24681 = (g_heff_2esyntax_2ecst_2efirstE(v_e0_241));
    V v_t_24682 = ({ V a_0 = v_e0_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e0_241, 1); r_; });
    V v_t_24683 = heff_strAppend(heff_get_n(v_t_24682, 1, 9), ((V)&g_heff_2esyntax_2esurface_2eexprL_str23));
    V v_msg_24684 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eexprL_str24), v_t_24683);
    V v_t_24685 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24681, 3), heff_get_n(v_t_24681, 4, 9)});
    V v_t_24686 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24684, v_t_24685, NTAG(TAG_Nothing)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24686}), v_z_242});
  }
  case TAG_BImp: {
    heff_drop_rec(v_r_240, 3);
    V v_t_24690 = (g_heff_2esyntax_2ecst_2efirstE(v_e0_241));
    V v_t_24691 = ({ V a_0 = v_e0_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e0_241, 3); r_; });
    V v_t_24692 = heff_strAppend(heff_get_n(v_t_24691, 1, 9), ((V)&g_heff_2esyntax_2esurface_2eexprL_str25));
    V v_msg_24693 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eexprL_str26), v_t_24692);
    V v_t_24694 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24690, 3), heff_get_n(v_t_24690, 4, 9)});
    V v_t_24695 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24693, v_t_24694, NTAG(TAG_Nothing)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24695}), v_z_242});
  }
  case TAG_BAnn: {
    heff_drop_rec(v_r_240, 3);
    V v_t_24701 = (g_heff_2esyntax_2ecst_2efirstE(v_e0_241));
    V v_t_24702 = ({ V a_0 = v_e0_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e0_241, 5); r_; });
    V v_t_24703 = heff_strAppend(heff_get_n(v_t_24702, 1, 9), ((V)&g_heff_2esyntax_2esurface_2eexprL_str27));
    V v_msg_24704 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eexprL_str28), v_t_24703);
    V v_t_24705 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24701, 3), heff_get_n(v_t_24701, 4, 9)});
    V v_t_24706 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24704, v_t_24705, NTAG(TAG_Nothing)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24706}), v_z_242});
  }
  case TAG_Lam: {
    V v_binders_24708 = heff_field(v_e0_241, 1);
    V v_body_24710 = heff_field(v_e0_241, 3);
    heff_take_n(v_e0_241, 10ULL, 4);
    return (g_heff_2esyntax_2esurface_2elambdaL(v_r_240, v_binders_24708, v_body_24710, v_z_242));
  }
  case TAG_Case: {
    V v_kw_24711 = heff_dup(heff_field(v_e0_241, 0));
    V v_scrut_24712 = heff_dup(heff_field(v_e0_241, 1));
    V v_alts_24714 = heff_dup(heff_field(v_e0_241, 3));
    V v_m_24715 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_scrut_24712}));
    V v_x1_24716 = heff_tr(heff_call(v_m_24715, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x1_24716)) {
    case TAG_MkPair: {
      V v_x11_24717 = heff_field(v_x1_24716, 0);
      V v_st_24718 = heff_field(v_x1_24716, 1);
      V v_ru_24x1_24716_24MkPair = heff_take_reuse_n(v_x1_24716, 3ULL, 2);
      switch (heff_tag_of(v_x11_24717)) {
      case TAG_Left: {
        V v_e_24719 = heff_field(v_x11_24717, 0);
        heff_take_n(v_x11_24717, 1ULL, 1);
        heff_drop_rec(v_r_240, 3);
        heff_drop_tag(v_e0_241, 4);
        heff_drop_rec(v_kw_24711, 9);
        heff_drop(v_alts_24714);
        return heff_tag_at_n(v_ru_24x1_24716_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24719}), v_st_24718});
      }
      case TAG_Right: {
        V v_x_24720 = heff_field(v_x11_24717, 0);
        heff_take_n(v_x11_24717, 1ULL, 1);
        HeffT2 v_t_24722 = (g_heff_2esyntax_2esurface_2eblock_24cpr(heff_clo_n(g_heff_2esyntax_2esurface_2eexprL_lam7, 1, 1, (V[]){v_r_240}), v_alts_24714, v_st_24718));
        {
          V v_field_24723 = v_t_24722.f[0];
          V v_field_24724 = v_t_24722.f[1];
          V v_x11_24725 = v_field_24723;
          V v_st_24726 = v_field_24724;
          switch (heff_tag_of(v_x11_24725)) {
          case TAG_Left: {
            V v_e_24727 = heff_field(v_x11_24725, 0);
            heff_take_n(v_x11_24725, 1ULL, 1);
            heff_drop_tag(v_e0_241, 4);
            heff_drop_rec(v_kw_24711, 9);
            heff_drop(v_x_24720);
            return heff_tag_at_n(v_ru_24x1_24716_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24727}), v_st_24726});
          }
          case TAG_Right: {
            V v_x_24728 = heff_field(v_x11_24725, 0);
            heff_take_n(v_x11_24725, 1ULL, 1);
            V v_t_24729 = (g_heff_2esyntax_2ecst_2elastE(v_e0_241));
            V v_e_24730 = heff_get_n(v_t_24729, 4, 9);
            V v_t_24731 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_24711, 3, 9), v_e_24730});
            V v_x_24732 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_x_24720, v_x_24728}), v_t_24731});
            return heff_tag_at_n(v_ru_24x1_24716_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24732}), v_st_24726});
          }
          default: return heff_nomatch(v_x11_24725);
          }
        }
      }
      default: return heff_nomatch(v_x11_24717);
      }
    }
    default: return heff_nomatch(v_x1_24716);
    }
  }
  case TAG_EAlt: {
    heff_drop_rec(v_r_240, 3);
    V v_t_24736 = (g_heff_2esyntax_2ecst_2efirstE(v_e0_241));
    V v_t_24737 = ({ V a_0 = v_e0_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e0_241, 3); r_; });
    V v_t_24738 = heff_strAppend(heff_get_n(v_t_24737, 1, 9), ((V)&g_heff_2esyntax_2esurface_2eexprL_str29));
    V v_msg_24739 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eexprL_str30), v_t_24738);
    V v_t_24740 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24736, 3), heff_get_n(v_t_24736, 4, 9)});
    V v_t_24741 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24739, v_t_24740, NTAG(TAG_Nothing)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24741}), v_z_242});
  }
  case TAG_If: {
    V v_kw_24742 = heff_field(v_e0_241, 0);
    V v_c_24743 = heff_field(v_e0_241, 1);
    V v_a_24745 = heff_field(v_e0_241, 3);
    V v_b_24747 = heff_field(v_e0_241, 5);
    heff_take_n(v_e0_241, 43ULL, 6);
    V v_m_24748 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_c_24743}));
    V v_x1_24749 = heff_tr(heff_call(v_m_24748, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x1_24749)) {
    case TAG_MkPair: {
      V v_x11_24750 = heff_field(v_x1_24749, 0);
      V v_st_24751 = heff_field(v_x1_24749, 1);
      V v_ru_24x1_24749_24MkPair = heff_take_reuse_n(v_x1_24749, 3ULL, 2);
      switch (heff_tag_of(v_x11_24750)) {
      case TAG_Left: {
        V v_e_24752 = heff_field(v_x11_24750, 0);
        heff_take_n(v_x11_24750, 1ULL, 1);
        heff_drop_rec(v_r_240, 3);
        heff_drop_rec(v_kw_24742, 9);
        heff_drop(v_a_24745);
        heff_drop(v_b_24747);
        return heff_tag_at_n(v_ru_24x1_24749_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24752}), v_st_24751});
      }
      case TAG_Right: {
        V v_x_24753 = heff_field(v_x11_24750, 0);
        heff_take_n(v_x11_24750, 1ULL, 1);
        V v_m_24754 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_24745}));
        V v_x1_24755 = heff_tr(heff_call(v_m_24754, 1, (V[]){v_st_24751}));
        switch (heff_tag_of(v_x1_24755)) {
        case TAG_MkPair: {
          V v_x11_24756 = heff_field(v_x1_24755, 0);
          V v_st_24757 = heff_field(v_x1_24755, 1);
          heff_take_n(v_x1_24755, 3ULL, 2);
          switch (heff_tag_of(v_x11_24756)) {
          case TAG_Left: {
            V v_e_24758 = heff_field(v_x11_24756, 0);
            heff_take_n(v_x11_24756, 1ULL, 1);
            heff_drop_rec(v_r_240, 3);
            heff_drop_rec(v_kw_24742, 9);
            heff_drop(v_b_24747);
            heff_drop(v_x_24753);
            return heff_tag_at_n(v_ru_24x1_24749_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24758}), v_st_24757});
          }
          case TAG_Right: {
            V v_x_24759 = heff_field(v_x11_24756, 0);
            heff_take_n(v_x11_24756, 1ULL, 1);
            V v_m_24760 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_b_24747)}));
            V v_x1_24761 = heff_tr(heff_call(v_m_24760, 1, (V[]){v_st_24757}));
            switch (heff_tag_of(v_x1_24761)) {
            case TAG_MkPair: {
              V v_x11_24762 = heff_field(v_x1_24761, 0);
              V v_st_24763 = heff_field(v_x1_24761, 1);
              heff_take_n(v_x1_24761, 3ULL, 2);
              switch (heff_tag_of(v_x11_24762)) {
              case TAG_Left: {
                V v_e_24764 = heff_field(v_x11_24762, 0);
                heff_take_n(v_x11_24762, 1ULL, 1);
                heff_drop_rec(v_kw_24742, 9);
                heff_drop(v_b_24747);
                heff_drop(v_x_24753);
                heff_drop(v_x_24759);
                return heff_tag_at_n(v_ru_24x1_24749_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24764}), v_st_24763});
              }
              case TAG_Right: {
                V v_x_24765 = heff_field(v_x11_24762, 0);
                heff_take_n(v_x11_24762, 1ULL, 1);
                V v_t_24766 = (g_heff_2esyntax_2ecst_2elastE(v_b_24747));
                V v_e_24767 = heff_get_n(v_t_24766, 4, 9);
                V v_t_24768 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_24742, 3, 9), v_e_24767});
                V v_x_24769 = (g_heff_2esyntax_2esurface_2eifE(v_t_24768, v_x_24753, v_x_24759, v_x_24765));
                return heff_tag_at_n(v_ru_24x1_24749_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24769}), v_st_24763});
              }
              default: return heff_nomatch(v_x11_24762);
              }
            }
            default: return heff_nomatch(v_x1_24761);
            }
          }
          default: return heff_nomatch(v_x11_24756);
          }
        }
        default: return heff_nomatch(v_x1_24755);
        }
      }
      default: return heff_nomatch(v_x11_24750);
      }
    }
    default: return heff_nomatch(v_x1_24749);
    }
  }
  case TAG_Do: {
    V v_kw_24770 = heff_dup(heff_field(v_e0_241, 0));
    V v_stmts_24771 = heff_dup(heff_field(v_e0_241, 1));
    HeffT2 v_t_24773 = (g_heff_2esyntax_2esurface_2eblock_24cpr(heff_clo_n(g_heff_2esyntax_2esurface_2eexprL_lam8, 1, 1, (V[]){v_r_240}), v_stmts_24771, v_z_242));
    {
      V v_field_24774 = v_t_24773.f[0];
      V v_field_24775 = v_t_24773.f[1];
      V v_x11_24776 = v_field_24774;
      V v_st_24777 = v_field_24775;
      switch (heff_tag_of(v_x11_24776)) {
      case TAG_Left: {
        V v_e_24778 = heff_field(v_x11_24776, 0);
        V v_ru_24x11_24776_24Left = heff_take_reuse_n(v_x11_24776, 1ULL, 1);
        heff_drop_tag(v_e0_241, 2);
        heff_drop_rec(v_kw_24770, 9);
        return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_24776_24Left, TAG_Left, 1, (V[]){v_e_24778}), v_st_24777});
      }
      case TAG_Right: {
        V v_x_24779 = heff_field(v_x11_24776, 0);
        V v_ru_24x11_24776_24Right = heff_take_reuse_n(v_x11_24776, 1ULL, 1);
        V v_t_24780 = (g_heff_2esyntax_2ecst_2elastE(v_e0_241));
        V v_e_24781 = heff_get_n(v_t_24780, 4, 9);
        V v_t_24782 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_24770, 3, 9), v_e_24781});
        V v_x_24783 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EDo, 1, (V[]){v_x_24779}), v_t_24782});
        return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_24776_24Right, TAG_Right, 1, (V[]){v_x_24783}), v_st_24777});
      }
      default: return heff_nomatch(v_x11_24776);
      }
    }
  }
  case TAG_ESBind: {
    heff_drop_rec(v_r_240, 3);
    V v_t_24787 = (g_heff_2esyntax_2ecst_2efirstE(v_e0_241));
    V v_t_24788 = ({ V a_0 = v_e0_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e0_241, 3); r_; });
    V v_t_24789 = heff_strAppend(heff_get_n(v_t_24788, 1, 9), ((V)&g_heff_2esyntax_2esurface_2eexprL_str31));
    V v_msg_24790 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eexprL_str32), v_t_24789);
    V v_t_24791 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24787, 3), heff_get_n(v_t_24787, 4, 9)});
    V v_t_24792 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24790, v_t_24791, NTAG(TAG_Nothing)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24792}), v_z_242});
  }
  case TAG_ELet: {
    HEFF_LAST return g_heff_2esyntax_2esurface_2eletL(v_r_240, v_e0_241, v_z_242);
  }
  case TAG_ELetMut: {
    heff_drop_rec(v_r_240, 3);
    V v_t_24805 = (g_heff_2esyntax_2ecst_2efirstE(v_e0_241));
    V v_t_24806 = ({ V a_0 = v_e0_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e0_241, 6); r_; });
    V v_t_24807 = heff_strAppend(heff_get_n(v_t_24806, 1, 9), ((V)&g_heff_2esyntax_2esurface_2eexprL_str33));
    V v_msg_24808 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eexprL_str34), v_t_24807);
    V v_t_24809 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24805, 3), heff_get_n(v_t_24805, 4, 9)});
    V v_t_24810 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24808, v_t_24809, NTAG(TAG_Nothing)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24810}), v_z_242});
  }
  case TAG_EAssign: {
    V v_x_24811 = heff_field(v_e0_241, 0);
    V v_e_24813 = heff_field(v_e0_241, 2);
    V v_ru_24e0_241_24EAssign = heff_take_reuse_n(v_e0_241, 5ULL, 3);
    V v_m_24814 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_e_24813)}));
    V v_x1_24815 = heff_tr(heff_call(v_m_24814, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x1_24815)) {
    case TAG_MkPair: {
      V v_x11_24816 = heff_field(v_x1_24815, 0);
      V v_st_24817 = heff_field(v_x1_24815, 1);
      V v_ru_24x1_24815_24MkPair = heff_take_reuse_n(v_x1_24815, 3ULL, 2);
      switch (heff_tag_of(v_x11_24816)) {
      case TAG_Left: {
        V v_e_24818 = heff_field(v_x11_24816, 0);
        heff_take_n(v_x11_24816, 1ULL, 1);
        heff_drop_rec(v_x_24811, 9);
        heff_drop(v_e_24813);
        heff_drop_cell(v_ru_24e0_241_24EAssign, 3);
        return heff_tag_at_n(v_ru_24x1_24815_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24818}), v_st_24817});
      }
      case TAG_Right: {
        V v_x_24819 = heff_field(v_x11_24816, 0);
        heff_take_n(v_x11_24816, 1ULL, 1);
        V v_t_24820 = heff_rec_n(2, shape_start__end, (V[]){heff_dup(heff_rfield(v_x_24811, 3)), heff_take_field(v_x_24811, 4)});
        V v_t_24821 = heff_tag_at_n(v_ru_24e0_241_24EAssign, TAG_EAssign, 3, (V[]){heff_dup(heff_rfield(v_x_24811, 1)), v_t_24820, v_x_24819});
        V v_t_24822 = (g_heff_2esyntax_2ecst_2elastE(v_e_24813));
        V v_e_24823 = heff_get_n(v_t_24822, 4, 9);
        V v_t_24824 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_x_24811, 3, 9), v_e_24823});
        V v_x_24825 = heff_tag_n(TAG_At, 2, (V[]){v_t_24821, v_t_24824});
        return heff_tag_at_n(v_ru_24x1_24815_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24825}), v_st_24817});
      }
      default: return heff_nomatch(v_x11_24816);
      }
    }
    default: return heff_nomatch(v_x1_24815);
    }
  }
  case TAG_EWhile: {
    V v_kw_24826 = heff_dup(heff_field(v_e0_241, 0));
    V v_c_24827 = heff_dup(heff_field(v_e0_241, 1));
    V v_body_24829 = heff_dup(heff_field(v_e0_241, 3));
    V v_m_24830 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_c_24827}));
    V v_x1_24831 = heff_tr(heff_call(v_m_24830, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x1_24831)) {
    case TAG_MkPair: {
      V v_x11_24832 = heff_field(v_x1_24831, 0);
      V v_st_24833 = heff_field(v_x1_24831, 1);
      V v_ru_24x1_24831_24MkPair = heff_take_reuse_n(v_x1_24831, 3ULL, 2);
      switch (heff_tag_of(v_x11_24832)) {
      case TAG_Left: {
        V v_e_24834 = heff_field(v_x11_24832, 0);
        heff_take_n(v_x11_24832, 1ULL, 1);
        heff_drop_rec(v_r_240, 3);
        heff_drop_tag(v_e0_241, 4);
        heff_drop_rec(v_kw_24826, 9);
        heff_drop(v_body_24829);
        return heff_tag_at_n(v_ru_24x1_24831_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24834}), v_st_24833});
      }
      case TAG_Right: {
        V v_x_24835 = heff_field(v_x11_24832, 0);
        heff_take_n(v_x11_24832, 1ULL, 1);
        HeffT2 v_t_24837 = (g_heff_2esyntax_2esurface_2eblock_24cpr(heff_clo_n(g_heff_2esyntax_2esurface_2eexprL_lam9, 1, 1, (V[]){v_r_240}), v_body_24829, v_st_24833));
        {
          V v_field_24838 = v_t_24837.f[0];
          V v_field_24839 = v_t_24837.f[1];
          V v_x11_24840 = v_field_24838;
          V v_st_24841 = v_field_24839;
          switch (heff_tag_of(v_x11_24840)) {
          case TAG_Left: {
            V v_e_24842 = heff_field(v_x11_24840, 0);
            heff_take_n(v_x11_24840, 1ULL, 1);
            heff_drop_tag(v_e0_241, 4);
            heff_drop_rec(v_kw_24826, 9);
            heff_drop(v_x_24835);
            return heff_tag_at_n(v_ru_24x1_24831_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24842}), v_st_24841});
          }
          case TAG_Right: {
            V v_x_24843 = heff_field(v_x11_24840, 0);
            heff_take_n(v_x11_24840, 1ULL, 1);
            V v_t_24844 = (g_heff_2esyntax_2ecst_2elastE(v_e0_241));
            V v_e_24845 = heff_get_n(v_t_24844, 4, 9);
            V v_t_24846 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_24826, 3, 9), v_e_24845});
            V v_x_24847 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EWhile, 2, (V[]){v_x_24835, v_x_24843}), v_t_24846});
            return heff_tag_at_n(v_ru_24x1_24831_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24847}), v_st_24841});
          }
          default: return heff_nomatch(v_x11_24840);
          }
        }
      }
      default: return heff_nomatch(v_x11_24832);
      }
    }
    default: return heff_nomatch(v_x1_24831);
    }
  }
  case TAG_EFor: {
    V v_kw_24848 = heff_dup(heff_field(v_e0_241, 0));
    V v_p_24849 = heff_dup(heff_field(v_e0_241, 1));
    V v_c_24851 = heff_dup(heff_field(v_e0_241, 3));
    V v_body_24853 = heff_dup(heff_field(v_e0_241, 5));
    V v_m_24854 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_c_24851}));
    V v_x1_24855 = heff_tr(heff_call(v_m_24854, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x1_24855)) {
    case TAG_MkPair: {
      V v_x11_24856 = heff_field(v_x1_24855, 0);
      V v_st_24857 = heff_field(v_x1_24855, 1);
      V v_ru_24x1_24855_24MkPair = heff_take_reuse_n(v_x1_24855, 3ULL, 2);
      switch (heff_tag_of(v_x11_24856)) {
      case TAG_Left: {
        V v_e_24858 = heff_field(v_x11_24856, 0);
        heff_take_n(v_x11_24856, 1ULL, 1);
        heff_drop_rec(v_r_240, 3);
        heff_drop_tag(v_e0_241, 6);
        heff_drop_rec(v_kw_24848, 9);
        heff_drop(v_p_24849);
        heff_drop(v_body_24853);
        return heff_tag_at_n(v_ru_24x1_24855_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24858}), v_st_24857});
      }
      case TAG_Right: {
        V v_x_24859 = heff_field(v_x11_24856, 0);
        heff_take_n(v_x11_24856, 1ULL, 1);
        V v_m_24860 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 1)), 1, (V[]){heff_dup(v_p_24849)}));
        V v_x1_24861 = heff_tr(heff_call(v_m_24860, 1, (V[]){v_st_24857}));
        switch (heff_tag_of(v_x1_24861)) {
        case TAG_MkPair: {
          V v_x11_24862 = heff_field(v_x1_24861, 0);
          V v_st_24863 = heff_field(v_x1_24861, 1);
          V v_ru_24x1_24861_24MkPair = heff_take_reuse_n(v_x1_24861, 3ULL, 2);
          switch (heff_tag_of(v_x11_24862)) {
          case TAG_Left: {
            V v_e_24864 = heff_field(v_x11_24862, 0);
            heff_take_n(v_x11_24862, 1ULL, 1);
            heff_drop_rec(v_r_240, 3);
            heff_drop_tag(v_e0_241, 6);
            heff_drop_rec(v_kw_24848, 9);
            heff_drop(v_p_24849);
            heff_drop(v_body_24853);
            heff_drop(v_x_24859);
            heff_drop_cell(v_ru_24x1_24861_24MkPair, 2);
            return heff_tag_at_n(v_ru_24x1_24855_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24864}), v_st_24863});
          }
          case TAG_Right: {
            V v_x_24865 = heff_field(v_x11_24862, 0);
            heff_take_n(v_x11_24862, 1ULL, 1);
            V v_t_24866 = ({ V b_0 = NTAG(TAG_Nil); V a_1 = v_p_24849; V r_ = (g_heff_2esyntax_2esurface_2eboundBy(b_0, a_1)); heff_drop(b_0); heff_drop(v_p_24849); r_; });
            V v_t_24868 = heff_tr(heff_call(((V)&g_heff_2esyntax_2esurface_2eblock_clo), 2, (V[]){heff_clo_n(g_heff_2esyntax_2esurface_2eexprL_lam10, 1, 1, (V[]){v_r_240}), v_body_24853}));
            HeffT2 v_t_24869 = (g_heff_2esyntax_2esurface_2ewithScope_24cpr(v_t_24866, v_t_24868, v_st_24863));
            {
              V v_field_24870 = v_t_24869.f[0];
              V v_field_24871 = v_t_24869.f[1];
              V v_x11_24872 = v_field_24870;
              V v_st_24873 = v_field_24871;
              switch (heff_tag_of(v_x11_24872)) {
              case TAG_Left: {
                V v_e_24874 = heff_field(v_x11_24872, 0);
                heff_take_n(v_x11_24872, 1ULL, 1);
                heff_drop_tag(v_e0_241, 6);
                heff_drop_rec(v_kw_24848, 9);
                heff_drop(v_x_24859);
                heff_drop_cell(v_ru_24x1_24861_24MkPair, 2);
                heff_drop(v_x_24865);
                return heff_tag_at_n(v_ru_24x1_24855_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24874}), v_st_24873});
              }
              case TAG_Right: {
                V v_x_24875 = heff_field(v_x11_24872, 0);
                heff_take_n(v_x11_24872, 1ULL, 1);
                V v_t_24876 = (g_heff_2esyntax_2ecst_2elastE(v_e0_241));
                V v_e_24877 = heff_get_n(v_t_24876, 4, 9);
                V v_t_24878 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_24848, 3, 9), v_e_24877});
                V v_x_24879 = heff_tag_at_n(v_ru_24x1_24861_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_EFor, 3, (V[]){v_x_24865, v_x_24859, v_x_24875}), v_t_24878});
                return heff_tag_at_n(v_ru_24x1_24855_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24879}), v_st_24873});
              }
              default: return heff_nomatch(v_x11_24872);
              }
            }
          }
          default: return heff_nomatch(v_x11_24862);
          }
        }
        default: return heff_nomatch(v_x1_24861);
        }
      }
      default: return heff_nomatch(v_x11_24856);
      }
    }
    default: return heff_nomatch(v_x1_24855);
    }
  }
  case TAG_EJump: {
    V v_kw_24880 = heff_field(v_e0_241, 0);
    V v_ru_24e0_241_24EJump = heff_take_reuse_n(v_e0_241, 1ULL, 1);
    heff_drop_rec(v_r_240, 3);
    V v_t_24882;
    if (heff_strEq_c(heff_dup(heff_rfield(v_kw_24880, 1)), ((V)&g_heff_2esyntax_2esurface_2eexprL_str35))) {
      v_t_24882 = NTAG(TAG_EBreak);
    } else {
      v_t_24882 = NTAG(TAG_EContinue);
    }
    V v_t_24883 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_kw_24880, 3), heff_get_n(v_kw_24880, 4, 9)});
    V v_t_24884 = heff_tag_at_n(v_ru_24e0_241_24EJump, TAG_Right, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24882, v_t_24883})});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24884, v_z_242});
  }
  case TAG_EReturn: {
    V v_kw_24885 = heff_field(v_e0_241, 0);
    V v_e_24886 = heff_field(v_e0_241, 1);
    V v_ru_24e0_241_24EReturn = heff_take_reuse_n(v_e0_241, 3ULL, 2);
    V v_m_24887 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_e_24886)}));
    V v_x1_24888 = heff_tr(heff_call(v_m_24887, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x1_24888)) {
    case TAG_MkPair: {
      V v_x11_24889 = heff_field(v_x1_24888, 0);
      V v_st_24890 = heff_field(v_x1_24888, 1);
      V v_ru_24x1_24888_24MkPair = heff_take_reuse_n(v_x1_24888, 3ULL, 2);
      switch (heff_tag_of(v_x11_24889)) {
      case TAG_Left: {
        V v_e_24891 = heff_field(v_x11_24889, 0);
        heff_take_n(v_x11_24889, 1ULL, 1);
        heff_drop_rec(v_kw_24885, 9);
        heff_drop(v_e_24886);
        heff_drop_cell(v_ru_24x1_24888_24MkPair, 2);
        return heff_tag_at_n(v_ru_24e0_241_24EReturn, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24891}), v_st_24890});
      }
      case TAG_Right: {
        V v_x_24892 = heff_field(v_x11_24889, 0);
        heff_take_n(v_x11_24889, 1ULL, 1);
        V v_t_24893 = (g_heff_2esyntax_2ecst_2elastE(v_e_24886));
        V v_e_24894 = heff_get_n(v_t_24893, 4, 9);
        V v_t_24895 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_24885, 3, 9), v_e_24894});
        V v_x_24896 = heff_tag_at_n(v_ru_24e0_241_24EReturn, TAG_At, 2, (V[]){heff_tag_n(TAG_EReturn, 1, (V[]){v_x_24892}), v_t_24895});
        return heff_tag_at_n(v_ru_24x1_24888_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24896}), v_st_24890});
      }
      default: return heff_nomatch(v_x11_24889);
      }
    }
    default: return heff_nomatch(v_x1_24888);
    }
  }
  case TAG_ENest: {
    V v_o_24897 = heff_field(v_e0_241, 0);
    V v_e_24899 = heff_field(v_e0_241, 2);
    V v_c_24900 = heff_field(v_e0_241, 3);
    heff_take_n(v_e0_241, 13ULL, 4);
    V v_m_24901 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_24899}));
    V v_x1_24902 = heff_tr(heff_call(v_m_24901, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x1_24902)) {
    case TAG_MkPair: {
      V v_x11_24903 = heff_field(v_x1_24902, 0);
      V v_st_24904 = heff_field(v_x1_24902, 1);
      V v_ru_24x1_24902_24MkPair = heff_take_reuse_n(v_x1_24902, 3ULL, 2);
      switch (heff_tag_of(v_x11_24903)) {
      case TAG_Left: {
        V v_e_24905 = heff_field(v_x11_24903, 0);
        heff_take_n(v_x11_24903, 1ULL, 1);
        heff_drop_rec(v_o_24897, 9);
        heff_drop_rec(v_c_24900, 9);
        return heff_tag_at_n(v_ru_24x1_24902_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24905}), v_st_24904});
      }
      case TAG_Right: {
        V v_x_24906 = heff_field(v_x11_24903, 0);
        V v_ru_24x11_24903_24Right = heff_take_reuse_n(v_x11_24903, 1ULL, 1);
        V v_t_24907 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_o_24897, 3, 9), heff_get_n(v_c_24900, 4, 9)});
        V v_t_24908 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24903_24Right, TAG_ENest, 1, (V[]){v_x_24906}), v_t_24907});
        return heff_tag_at_n(v_ru_24x1_24902_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24908}), v_st_24904});
      }
      default: return heff_nomatch(v_x11_24903);
      }
    }
    default: return heff_nomatch(v_x1_24902);
    }
  }
  case TAG_IfThen: {
    V v_kw_24909 = heff_field(v_e0_241, 0);
    V v_c_24910 = heff_field(v_e0_241, 1);
    V v_a_24912 = heff_field(v_e0_241, 3);
    heff_take_n(v_e0_241, 11ULL, 4);
    V v_m_24913 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_c_24910}));
    V v_x1_24914 = heff_tr(heff_call(v_m_24913, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x1_24914)) {
    case TAG_MkPair: {
      V v_x11_24915 = heff_field(v_x1_24914, 0);
      V v_st_24916 = heff_field(v_x1_24914, 1);
      V v_ru_24x1_24914_24MkPair = heff_take_reuse_n(v_x1_24914, 3ULL, 2);
      switch (heff_tag_of(v_x11_24915)) {
      case TAG_Left: {
        V v_e_24917 = heff_field(v_x11_24915, 0);
        heff_take_n(v_x11_24915, 1ULL, 1);
        heff_drop_rec(v_r_240, 3);
        heff_drop_rec(v_kw_24909, 9);
        heff_drop(v_a_24912);
        return heff_tag_at_n(v_ru_24x1_24914_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24917}), v_st_24916});
      }
      case TAG_Right: {
        V v_x_24918 = heff_field(v_x11_24915, 0);
        heff_take_n(v_x11_24915, 1ULL, 1);
        V v_m_24919 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_a_24912)}));
        V v_x1_24920 = heff_tr(heff_call(v_m_24919, 1, (V[]){v_st_24916}));
        switch (heff_tag_of(v_x1_24920)) {
        case TAG_MkPair: {
          V v_x11_24921 = heff_field(v_x1_24920, 0);
          V v_st_24922 = heff_field(v_x1_24920, 1);
          V v_ru_24x1_24920_24MkPair = heff_take_reuse_n(v_x1_24920, 3ULL, 2);
          switch (heff_tag_of(v_x11_24921)) {
          case TAG_Left: {
            V v_e_24923 = heff_field(v_x11_24921, 0);
            heff_take_n(v_x11_24921, 1ULL, 1);
            heff_drop_rec(v_kw_24909, 9);
            heff_drop(v_a_24912);
            heff_drop(v_x_24918);
            heff_drop_cell(v_ru_24x1_24920_24MkPair, 2);
            return heff_tag_at_n(v_ru_24x1_24914_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24923}), v_st_24922});
          }
          case TAG_Right: {
            V v_x_24924 = heff_field(v_x11_24921, 0);
            heff_take_n(v_x11_24921, 1ULL, 1);
            V v_t_24925 = (g_heff_2esyntax_2ecst_2elastE(v_a_24912));
            V v_e_24926 = heff_get_n(v_t_24925, 4, 9);
            V v_t_24927 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_24909, 3, 9), v_e_24926});
            V v_x_24928 = heff_tag_at_n(v_ru_24x1_24920_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_EIfThen, 2, (V[]){v_x_24918, v_x_24924}), v_t_24927});
            return heff_tag_at_n(v_ru_24x1_24914_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24928}), v_st_24922});
          }
          default: return heff_nomatch(v_x11_24921);
          }
        }
        default: return heff_nomatch(v_x1_24920);
        }
      }
      default: return heff_nomatch(v_x11_24915);
      }
    }
    default: return heff_nomatch(v_x1_24914);
    }
  }
  default: return heff_nomatch(v_e0_241);
  }
}
V g_heff_2esyntax_2esurface_2eexprL_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2eexprL(a[0], a[1], a[2]);
}
V g_heff_2esyntax_2esurface_2eexprL_lam0(V self, V *args) {
  V v_m_2430 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2esyntax_2esurface_2esegmentL(v_r_240, v_m_2430));
}
V g_heff_2esyntax_2esurface_2eexprL_lam1(V self, V *args) {
  V v_x_2448 = args[0];
  V v_rest_2449 = args[1];
  V v_sp_2446 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2450 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ETag, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2eexprL_str7)}), v_sp_2446});
  V v_t_2451 = heff_tag_n(TAG_Cons, 2, (V[]){v_rest_2449, NTAG(TAG_Nil)});
  return (g_heff_2esyntax_2epresyntax_2eapp(v_t_2450, heff_tag_n(TAG_Cons, 2, (V[]){v_x_2448, v_t_2451})));
}
V g_heff_2esyntax_2esurface_2eexprL_lam2(V self, V *args) {
  V v_m_2486 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2esyntax_2esurface_2eupdateSettingL(v_r_240, v_m_2486));
}
V g_heff_2esyntax_2esurface_2eexprL_lam3(V self, V *args) {
  V v_a_24140 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2esyntax_2esurface_2evariantL(v_r_240, v_a_24140));
}
V g_heff_2esyntax_2esurface_2eexprL_lam4(V self, V *args) {
  V v_m_24610 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2esyntax_2esurface_2eargL(v_r_240, v_m_24610));
}
V g_heff_2esyntax_2esurface_2eexprL_lam6(V self, V *args) {
  V v_st_24636 = args[0];
  V v_m_24635 = heff_env(self)[0];
  V v_op_24633 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24637 = heff_tr(heff_call(v_m_24635, 1, (V[]){v_st_24636}));
  switch (heff_tag_of(v_x1_24637)) {
  case TAG_MkPair: {
    V v_x11_24638 = heff_field(v_x1_24637, 0);
    V v_st_24639 = heff_field(v_x1_24637, 1);
    V v_ru_24x1_24637_24MkPair = heff_take_reuse_n(v_x1_24637, 3ULL, 2);
    switch (heff_tag_of(v_x11_24638)) {
    case TAG_Left: {
      V v_e_24640 = heff_field(v_x11_24638, 0);
      heff_take_n(v_x11_24638, 1ULL, 1);
      heff_drop(v_op_24633);
      return heff_tag_at_n(v_ru_24x1_24637_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24640}), v_st_24639});
    }
    case TAG_Right: {
      V v_x_24641 = heff_field(v_x11_24638, 0);
      V v_ru_24x11_24638_24Right = heff_take_reuse_n(v_x11_24638, 1ULL, 1);
      V v_t_24642 = heff_tag_at_n(v_ru_24x11_24638_24Right, TAG_Right, 1, (V[]){heff_rec_n(2, shape_op__e, (V[]){v_op_24633, v_x_24641})});
      return heff_tag_at_n(v_ru_24x1_24637_24MkPair, TAG_MkPair, 2, (V[]){v_t_24642, v_st_24639});
    }
    default: return heff_nomatch(v_x11_24638);
    }
  }
  default: return heff_nomatch(v_x1_24637);
  }
}
V g_heff_2esyntax_2esurface_2eexprL_lam5(V self, V *args) {
  V v_m_24629 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_24630 = (g_heff_2esyntax_2esurface_2eopRhsOf_24cpr(v_m_24629));
  {
    V v_field_24631 = v_t_24630.f[0];
    V v_field_24632 = v_t_24630.f[1];
    V v_op_24633 = v_field_24631;
    V v_e_24634 = v_field_24632;
    V v_m_24635 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_24634}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2eexprL_lam6, 1, 2, (V[]){v_m_24635, v_op_24633});
  }
}
V g_heff_2esyntax_2esurface_2eexprL_lam7(V self, V *args) {
  V v_a_24721 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2esyntax_2esurface_2ealtL(v_r_240, v_a_24721));
}
V g_heff_2esyntax_2esurface_2eexprL_lam8(V self, V *args) {
  V v_m_24772 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2esyntax_2esurface_2estmtL(v_r_240, v_m_24772));
}
V g_heff_2esyntax_2esurface_2eexprL_lam9(V self, V *args) {
  V v_m_24836 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2esyntax_2esurface_2estmtL(v_r_240, v_m_24836));
}
V g_heff_2esyntax_2esurface_2eexprL_lam10(V self, V *args) {
  V v_m_24867 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2esyntax_2esurface_2estmtL(v_r_240, v_m_24867));
}
V g_heff_2esyntax_2esurface_2edefaultL_lam0(V self, V *args); static Clo g_heff_2esyntax_2esurface_2edefaultL_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2edefaultL_lam0, 1, 0};
V g_heff_2esyntax_2esurface_2edefaultL_lam1(V self, V *args);
Clo g_heff_2esyntax_2esurface_2edefaultL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2edefaultL_entry, 2, 0};

V g_heff_2esyntax_2esurface_2edefaultL(V v_r_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nothing: {
    heff_drop_rec(v_r_240, 3);
    return ((V)&g_heff_2esyntax_2esurface_2edefaultL_lam0_clo);
  }
  case TAG_Just: {
    V v_x21_244 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    switch (heff_tag_of(v_x21_244)) {
    case TAG_MkPair: {
      V v_d_246 = heff_field(v_x21_244, 1);
      heff_take_n(v_x21_244, 2ULL, 2);
      V v_m_247 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_d_246}));
      return heff_clo_n(g_heff_2esyntax_2esurface_2edefaultL_lam1, 1, 1, (V[]){v_m_247});
    }
    default: return heff_nomatch(v_x21_244);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2esurface_2edefaultL_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2edefaultL(a[0], a[1]);
}
V g_heff_2esyntax_2esurface_2edefaultL_lam0(V self, V *args) {
  V v_st_242 = args[0];
  V v_t_243 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_243, v_st_242});
}
V g_heff_2esyntax_2esurface_2edefaultL_lam1(V self, V *args) {
  V v_st_248 = args[0];
  V v_m_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_249 = heff_tr(heff_call(v_m_247, 1, (V[]){v_st_248}));
  switch (heff_tag_of(v_x1_249)) {
  case TAG_MkPair: {
    V v_x11_2410 = heff_field(v_x1_249, 0);
    V v_st_2411 = heff_field(v_x1_249, 1);
    V v_ru_24x1_249_24MkPair = heff_take_reuse_n(v_x1_249, 3ULL, 2);
    switch (heff_tag_of(v_x11_2410)) {
    case TAG_Left: {
      V v_e_2412 = heff_field(v_x11_2410, 0);
      heff_take_n(v_x11_2410, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_249_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2412}), v_st_2411});
    }
    case TAG_Right: {
      V v_x_2413 = heff_field(v_x11_2410, 0);
      V v_ru_24x11_2410_24Right = heff_take_reuse_n(v_x11_2410, 1ULL, 1);
      V v_t_2414 = heff_tag_at_n(v_ru_24x11_2410_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Just, 1, (V[]){v_x_2413})});
      return heff_tag_at_n(v_ru_24x1_249_24MkPair, TAG_MkPair, 2, (V[]){v_t_2414, v_st_2411});
    }
    default: return heff_nomatch(v_x11_2410);
    }
  }
  default: return heff_nomatch(v_x1_249);
  }
}

HeffT4 g_heff_2esyntax_2esurface_2ereadLexed_24s350283117x1909926642_24cpr(V v_lit_240, V v_lit_241, V v_src_242, V v_l_243) {
top: ;
  V v_ltoks_244 = heff_arrayFromList(heff_dup(heff_rfield(v_l_243, 0)));
  V v_t_245 = (g_heff_2esyntax_2efmt_2etokens_2eplainGo(MK_INT(0LL), NTAG(TAG_Nil), heff_take_field(v_l_243, 0)));
  V v_toks_246 = heff_arrayFromList(v_t_245);
  V v_lexDiags_247 = (g_list_2emap_24s338694954x1326523169(heff_get_n(v_l_243, 1, 3)));
  V v_t_248 = heff_rec_n(5, shape_known__fixities__lenient__place__path, (V[]){((V)&g_heff_2esyntax_2esurface_2enoKnown_clo), heff_dup(g_heff_2esyntax_2efixity_2eemptyFixities_get()), NTAG(TAG_True), heff_dup(v_lit_240), v_lit_241});
  V v_t_249 = (g_heff_2esyntax_2esurface_2eprescanGo(v_ltoks_244, MK_INT(0LL), NTAG(TAG_Nil)));
  V v_t_2410 = ({ V a_0 = v_ltoks_244; V a_1 = MK_INT(0LL); V a_2 = NTAG(TAG_Nil); V r_ = (g_heff_2esyntax_2esurface_2efixDecls(a_0, a_1, a_2)); heff_drop(v_ltoks_244); r_; });
  V v_t_2411 = (g_heff_2esyntax_2esurface_2efixityFrom_24s1371314581x1750522054(v_lit_240, v_t_2410));
  return ({ V a_0 = v_src_242; V a_1 = v_t_248; V a_2 = v_toks_246; V a_3 = v_lexDiags_247; V a_4 = v_t_249; V a_5 = v_t_2411; HeffT4 r_ = (g_heff_2esyntax_2esurface_2ereadRun_24cpr(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_t_249); r_; });
}