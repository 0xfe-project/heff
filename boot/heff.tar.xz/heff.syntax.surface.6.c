// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Ann 13421
#define TAG_App 13485
#define TAG_At 8900
#define TAG_Atom 28502
#define TAG_BAnn 9252
#define TAG_BImp 16911
#define TAG_BPat 23270
#define TAG_BVar 29034
#define TAG_Braces 8205
#define TAG_Case 4415
#define TAG_Do 8988
#define TAG_EAlt 33043
#define TAG_EAnn 33099
#define TAG_EAssign 4102
#define TAG_EBinary 42634
#define TAG_EBreak 7195
#define TAG_ECatch 45587
#define TAG_ECon 35052
#define TAG_EContinue 48638
#define TAG_EDo 15964
#define TAG_EFDefault 38038
#define TAG_EFSet 34673
#define TAG_EField 26142
#define TAG_EFor 37939
#define TAG_EIfThen 2245
#define TAG_EInvalid 31081
#define TAG_EJump 55703
#define TAG_ELazy 30951
#define TAG_ELet 43397
#define TAG_ELetElse 15726
#define TAG_ELetIn 22786
#define TAG_ELetMut 54984
#define TAG_EMatch 41631
#define TAG_ENeg 45306
#define TAG_ENest 28629
#define TAG_EParen 58248
#define TAG_EReturn 59059
#define TAG_ESBind 62182
#define TAG_ESum 50613
#define TAG_ETag 50948
#define TAG_ETilde 53294
#define TAG_ETry 51493
#define TAG_ETuple 21722
#define TAG_EUSet 22856
#define TAG_EUpdate 6986
#define TAG_EVar 52881
#define TAG_EWhile 39339
#define TAG_EWith 38507
#define TAG_FloatValue 23118
#define TAG_If 9134
#define TAG_IfThen 36069
#define TAG_InstB 37114
#define TAG_IntValue 62477
#define TAG_Lam 23588
#define TAG_Left 13886
#define TAG_MkAlt 55173
#define TAG_MkSegment 38079
#define TAG_MkTry 8097
#define TAG_Named 2049
#define TAG_Op 9330
#define TAG_OpRhs 36076
#define TAG_Ops 26942
#define TAG_OtherValue 43098
#define TAG_PAs 26446
#define TAG_PAtom 50987
#define TAG_PCon 35123
#define TAG_PField 28847
#define TAG_PList 40618
#define TAG_POp 26877
#define TAG_PParen 60953
#define TAG_PRec 49217
#define TAG_PSeg 50182
#define TAG_Right 62770
#define TAG_RuneValue 49425
#define TAG_SError 24172
#define TAG_Seg 30433
#define TAG_SegmentBinary 41188
#define TAG_SegmentBits 43687
#define TAG_SegmentFloat 21180
#define TAG_SegmentInteger 22664
#define TAG_SegmentUtf 5205
#define TAG_SizeDefault 11444
#define TAG_StmtLet 16809
#define TAG_StrValue 22621
#define TAG_Sum 30935
#define TAG_Tup 31899
#define TAG_Update 40810
#define LBL_code 9554612
#define LBL_e 319
#define LBL_end 310101
#define LBL_kind 9787483
#define LBL_little 844663329
#define LBL_msg 317947
#define LBL_note 9882809
#define LBL_op 10312
#define LBL_ops 319788
#define LBL_out 319944
#define LBL_pat 320285
#define LBL_severity 75955546
#define LBL_signed 1044674119
#define LBL_size 10026184
#define LBL_span 10032145
#define LBL_start 311115900
#define LBL_text 10052084
#define LBL_ty 10476
#define LBL_unit 10090059
static uint32_t shape_code__severity__msg__span__note[] = {LBL_code, LBL_severity, LBL_msg, LBL_span, LBL_note};
static uint32_t shape_op__e[] = {LBL_op, LBL_e};
static uint32_t shape_ops__out[] = {LBL_ops, LBL_out};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
static uint32_t shape_ty__size__unit__little__signed[] = {LBL_ty, LBL_size, LBL_unit, LBL_little, LBL_signed};
V g_heff_2esyntax_2ecst_2efirstE(V);
V g_heff_2esyntax_2ecst_2efirstE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2efirstE_clo;
V g_heff_2esyntax_2ecst_2elastE(V);
V g_heff_2esyntax_2ecst_2elastE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2elastE_clo;
V g_heff_2esyntax_2epresyntax_2eapp(V, V);
V g_heff_2esyntax_2epresyntax_2eapp_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eapp_clo;
V g_heff_2esyntax_2esurface_2ealtL(V, V);
V g_heff_2esyntax_2esurface_2ealtL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ealtL_clo;
V g_heff_2esyntax_2esurface_2eapplyOp(V, V, V);
V g_heff_2esyntax_2esurface_2eapplyOp_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eapplyOp_clo;
V g_heff_2esyntax_2esurface_2eargL(V, V);
V g_heff_2esyntax_2esurface_2eargL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eargL_clo;
V g_heff_2esyntax_2esurface_2eatomTok(V);
V g_heff_2esyntax_2esurface_2eatomTok_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eatomTok_clo;
V g_heff_2esyntax_2esurface_2eblock(V, V, V);
V g_heff_2esyntax_2esurface_2eblock_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eblock_clo;
HeffT2 g_heff_2esyntax_2esurface_2eblock_24cpr(V, V, V);
V g_heff_2esyntax_2esurface_2eboundBy(V, V);
V g_heff_2esyntax_2esurface_2eboundBy_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eboundBy_clo;
V g_heff_2esyntax_2esurface_2ebracesL(V, V, V, V, V);
V g_heff_2esyntax_2esurface_2ebracesL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ebracesL_clo;
V g_heff_2esyntax_2esurface_2ecatchL(V, V);
V g_heff_2esyntax_2esurface_2ecatchL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ecatchL_clo;
V g_heff_2esyntax_2esurface_2ecommentLinesFrom(V, V, V);
V g_heff_2esyntax_2esurface_2ecommentLinesFrom_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ecommentLinesFrom_clo;
V g_heff_2esyntax_2esurface_2econAtom(V, V, V);
V g_heff_2esyntax_2esurface_2econAtom_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2econAtom_clo;
V g_heff_2esyntax_2esurface_2econL(V, V, V);
V g_heff_2esyntax_2esurface_2econL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2econL_clo;
HeffT2 g_heff_2esyntax_2esurface_2edeclNameOf_24cpr(V);
V g_heff_2esyntax_2esurface_2edeclarationL(V, V);
V g_heff_2esyntax_2esurface_2edeclarationL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2edeclarationL_clo;
V g_heff_2esyntax_2esurface_2edefaultL(V, V);
V g_heff_2esyntax_2esurface_2edefaultL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2edefaultL_clo;
V g_heff_2esyntax_2esurface_2eexprL(V, V, V);
V g_heff_2esyntax_2esurface_2eexprL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eexprL_clo;
HeffT2 g_heff_2esyntax_2esurface_2efieldsOf_24cpr(V, V);
V g_heff_2esyntax_2esurface_2efirstS(V, V, V, V);
V g_heff_2esyntax_2esurface_2efirstS_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2efirstS_clo;
V g_heff_2esyntax_2esurface_2efoldr(V, V, V);
V g_heff_2esyntax_2esurface_2efoldr_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2efoldr_clo;
V g_heff_2esyntax_2esurface_2eifE(V, V, V, V);
V g_heff_2esyntax_2esurface_2eifE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eifE_clo;
V g_heff_2esyntax_2esurface_2eintOfText(V);
V g_heff_2esyntax_2esurface_2eintOfText_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eintOfText_clo;
V g_heff_2esyntax_2esurface_2ekwAtom(V, V, V);
V g_heff_2esyntax_2esurface_2ekwAtom_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ekwAtom_clo;
V g_heff_2esyntax_2esurface_2elambdaL(V, V, V, V);
V g_heff_2esyntax_2esurface_2elambdaL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2elambdaL_clo;
HeffT2 g_heff_2esyntax_2esurface_2eletBodyL_24cpr(V, V, V, V, V, V);
V g_heff_2esyntax_2esurface_2eletL(V, V, V);
V g_heff_2esyntax_2esurface_2eletL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eletL_clo;
V g_heff_2esyntax_2esurface_2eopL(V, V, V, V, V);
V g_heff_2esyntax_2esurface_2eopL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eopL_clo;
HeffT2 g_heff_2esyntax_2esurface_2eopRhsOf_24cpr(V);
V g_heff_2esyntax_2esurface_2eparenL(V, V, V, V, V);
V g_heff_2esyntax_2esurface_2eparenL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eparenL_clo;
V g_heff_2esyntax_2esurface_2epushS_24s1868233564x1858628873(V, V, V, V);
V g_heff_2esyntax_2esurface_2epushS_24s1868233564x1858628873_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2epushS_24s1868233564x1858628873_clo;
V g_heff_2esyntax_2esurface_2eresolve_24s1832151779x1448561609(V, V, V);
V g_heff_2esyntax_2esurface_2eresolve_24s1832151779x1448561609_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eresolve_24s1832151779x1448561609_clo;
V g_heff_2esyntax_2esurface_2erightsOf(V);
V g_heff_2esyntax_2esurface_2erightsOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2erightsOf_clo;
V g_heff_2esyntax_2esurface_2erightsOf_24dps(V, V);
V g_heff_2esyntax_2esurface_2erightsOf_24dps_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2erightsOf_24dps_clo;
V g_heff_2esyntax_2esurface_2esegmentL(V, V);
V g_heff_2esyntax_2esurface_2esegmentL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2esegmentL_clo;
V g_heff_2esyntax_2esurface_2esegmentOf_24s1547151193x813882637(V, V, V, V, V);
V g_heff_2esyntax_2esurface_2esegmentOf_24s1547151193x813882637_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2esegmentOf_24s1547151193x813882637_clo;
V g_heff_2esyntax_2esurface_2especWord(V, V, V);
V g_heff_2esyntax_2esurface_2especWord_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2especWord_clo;
V g_heff_2esyntax_2esurface_2estmtL(V, V);
V g_heff_2esyntax_2esurface_2estmtL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2estmtL_clo;
V g_heff_2esyntax_2esurface_2etryTypeL(V, V);
V g_heff_2esyntax_2esurface_2etryTypeL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2etryTypeL_clo;
V g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993(V, V, V, V, V);
V g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_clo;
V g_heff_2esyntax_2esurface_2eunitOf(V, V, V);
V g_heff_2esyntax_2esurface_2eunitOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eunitOf_clo;
V g_heff_2esyntax_2esurface_2eupdateSettingL(V, V);
V g_heff_2esyntax_2esurface_2eupdateSettingL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eupdateSettingL_clo;
HeffT2 g_heff_2esyntax_2esurface_2evalueKind_24cpr(V, V, V, V);
V g_heff_2esyntax_2esurface_2evarAtom(V, V, V);
V g_heff_2esyntax_2esurface_2evarAtom_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2evarAtom_clo;
V g_heff_2esyntax_2esurface_2evariantL(V, V);
V g_heff_2esyntax_2esurface_2evariantL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2evariantL_clo;
HeffT2 g_heff_2esyntax_2esurface_2ewithScope_24cpr(V, V, V);
V g_list_2emap_24s513201124x806973253(V);
V g_list_2emap_24s513201124x806973253_entry(V self, V *a);
extern Clo g_list_2emap_24s513201124x806973253_clo;
V g_prelude_2eskipSpaces(V, V, V);
V g_prelude_2eskipSpaces_entry(V self, V *a);
extern Clo g_prelude_2eskipSpaces_clo;
V g_prelude_2etraverse_24s499544530x2060473942(V, V);
V g_prelude_2etraverse_24s499544530x2060473942_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s499544530x2060473942_clo;
HEFF_LIT(g_heff_2esyntax_2esurface_2ecommentLinesFrom_str0, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecommentLinesFrom_str1, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecommentLinesFrom_str2, 2, "--");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecommentLinesFrom_str3, 1, "\012");
Clo g_heff_2esyntax_2esurface_2ecommentLinesFrom_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2ecommentLinesFrom_entry, 3, 0};

V g_heff_2esyntax_2esurface_2ecommentLinesFrom(V v_src_240, V v_i_241, V v_to_242) {
top: ;
  V v_j_243 = heff_strFind_lent(((V)&g_heff_2esyntax_2esurface_2ecommentLinesFrom_str0), v_src_240, v_i_241, 1);
  V v_t_245;
  if (heff_intLt_c_lent(v_j_243, MK_INT(0LL), 2)) {
    heff_drop(v_j_243);
    v_t_245 = heff_strLength_lent(v_src_240, 0);
  } else {
    v_t_245 = v_j_243;
  }
  if (heff_intLe_c_lent(v_to_242, v_t_245, 2)) {
    heff_drop(v_i_241);
    heff_drop(v_to_242);
    return NTAG(TAG_True);
  } else {
    V v_j_247 = heff_strFind_lent(((V)&g_heff_2esyntax_2esurface_2ecommentLinesFrom_str1), v_src_240, v_i_241, 1);
    V v_t_249;
    if (heff_intLt_c_lent(v_j_247, MK_INT(0LL), 2)) {
      heff_drop(v_j_247);
      v_t_249 = heff_strLength_lent(v_src_240, 0);
    } else {
      v_t_249 = v_j_247;
    }
    V v_s_2410 = heff_strSlice_lent(v_src_240, v_i_241, v_t_249, 4);
    V v_t_2411 = (g_prelude_2eskipSpaces(v_s_2410, MK_INT(0LL), MK_INT(1LL)));
    int64_t v_t_2412 = (heff_unbox_word(heff_strLength_lent(v_s_2410, 0)) - ((int64_t)1ULL));
    V v_t_2413 = (g_prelude_2eskipSpaces(v_s_2410, heff_box_word(v_t_2412), MK_INT(-1LL)));
    V v_s_2414 = heff_strSlice(v_s_2410, v_t_2411, heff_intAdd(v_t_2413, MK_INT(1LL)));
    if (heff_strEq_c(heff_strSlice(v_s_2414, MK_INT(0LL), MK_INT(2LL)), ((V)&g_heff_2esyntax_2esurface_2ecommentLinesFrom_str2))) {
      V v_j_2416 = heff_strFind_lent(((V)&g_heff_2esyntax_2esurface_2ecommentLinesFrom_str3), v_src_240, v_i_241, 5);
      V v_t_2418;
      if (heff_intLt_c_lent(v_j_2416, MK_INT(0LL), 2)) {
        heff_drop(v_j_2416);
        v_t_2418 = heff_strLength_lent(v_src_240, 0);
      } else {
        v_t_2418 = v_j_2416;
      }
      V t_0 = v_src_240;
      V t_1 = heff_intAdd(v_t_2418, MK_INT(1LL));
      V t_2 = v_to_242;
      v_src_240 = t_0;
      v_i_241 = t_1;
      v_to_242 = t_2;
      goto top;
    } else {
      heff_drop(v_i_241);
      heff_drop(v_to_242);
      return NTAG(TAG_False);
    }
  }
}
V g_heff_2esyntax_2esurface_2ecommentLinesFrom_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2esurface_2ecommentLinesFrom(a0, a[1], a[2]); heff_drop(a0); return r;
}
V g_heff_2esyntax_2esurface_2eletBodyL_24cpr_lam0(V self, V *args);

HeffT2 g_heff_2esyntax_2esurface_2eletBodyL_24cpr(V v_r_240, V v_kw_241, V v_x3_242, V v_names_243, V v_body_244, V v_z_245) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_MkPair: {
    V v_p_246 = heff_field(v_x3_242, 0);
    V v_rhs_247 = heff_field(v_x3_242, 1);
    heff_take_n(v_x3_242, 3ULL, 2);
    V v_m_248 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_body_244)}));
    return (g_heff_2esyntax_2esurface_2ewithScope_24cpr(v_names_243, heff_clo_n(g_heff_2esyntax_2esurface_2eletBodyL_24cpr_lam0, 1, 5, (V[]){v_m_248, v_p_246, v_body_244, v_kw_241, v_rhs_247}), v_z_245));
  }
  default: return ((HeffT2){{heff_nomatch(v_x3_242)}});
  }
}
V g_heff_2esyntax_2esurface_2eletBodyL_24cpr_lam0(V self, V *args) {
  V v_st_249 = args[0];
  V v_m_248 = heff_env(self)[0];
  V v_p_246 = heff_env(self)[1];
  V v_body_244 = heff_env(self)[2];
  V v_kw_241 = heff_env(self)[3];
  V v_rhs_247 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_x1_2410 = heff_tr(heff_call(v_m_248, 1, (V[]){v_st_249}));
  switch (heff_tag_of(v_x1_2410)) {
  case TAG_MkPair: {
    V v_x11_2411 = heff_field(v_x1_2410, 0);
    V v_st_2412 = heff_field(v_x1_2410, 1);
    V v_ru_24x1_2410_24MkPair = heff_take_reuse_n(v_x1_2410, 3ULL, 2);
    switch (heff_tag_of(v_x11_2411)) {
    case TAG_Left: {
      V v_e_2413 = heff_field(v_x11_2411, 0);
      heff_take_n(v_x11_2411, 1ULL, 1);
      heff_drop(v_p_246);
      heff_drop(v_body_244);
      heff_drop_rec(v_kw_241, 9);
      heff_drop(v_rhs_247);
      return heff_tag_at_n(v_ru_24x1_2410_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2413}), v_st_2412});
    }
    case TAG_Right: {
      V v_x_2414 = heff_field(v_x11_2411, 0);
      heff_take_n(v_x11_2411, 1ULL, 1);
      V v_t_2417;
      switch (heff_tag_of(v_p_246)) {
      case TAG_At: {
        V v_s_2416 = heff_dup(heff_field(v_p_246, 1));
        v_t_2417 = v_s_2416;
        break;
      }
      default: heff_nomatch(v_p_246);
      }
      V v_t_2420;
      switch (heff_tag_of(v_x_2414)) {
      case TAG_At: {
        V v_s_2419 = heff_dup(heff_field(v_x_2414, 1));
        v_t_2420 = v_s_2419;
        break;
      }
      default: heff_nomatch(v_x_2414);
      }
      V v_t_2421 = ({ V rv_1 = heff_get_n(v_t_2420, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_2417, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
      V v_t_2422 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_246, v_x_2414}), v_t_2421});
      V v_t_2423 = (g_heff_2esyntax_2ecst_2elastE(v_body_244));
      V v_e_2424 = heff_get_n(v_t_2423, 4, 9);
      V v_t_2425 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_241, 3, 9), v_e_2424});
      V v_x_2426 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ELetIn, 2, (V[]){v_rhs_247, v_t_2422}), v_t_2425});
      return heff_tag_at_n(v_ru_24x1_2410_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2426}), v_st_2412});
    }
    default: return heff_nomatch(v_x11_2411);
    }
  }
  default: return heff_nomatch(v_x1_2410);
  }
}
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str0, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str1, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str2, 3, "err");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str3, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str4, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str5, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str6, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str7, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str8, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str9, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str10, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str11, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str12, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str13, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str14, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str15, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str16, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str17, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str18, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str19, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str20, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str21, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str22, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str23, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str24, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str25, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str26, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str27, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str28, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str29, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str30, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str31, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str32, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str33, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str34, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str35, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str36, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str37, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str38, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str39, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str40, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str41, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str42, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str43, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str44, 61, "a `try` names the type of the throws it hears as `(err := T)`");
V g_heff_2esyntax_2esurface_2etryTypeL_lam0(V self, V *args); static Clo g_heff_2esyntax_2esurface_2etryTypeL_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2etryTypeL_lam0, 1, 0};
V g_heff_2esyntax_2esurface_2etryTypeL_lam1(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam2(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam3(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam4(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam5(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam6(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam7(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam8(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam9(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam10(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam11(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam12(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam13(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam14(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam15(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam16(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam17(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam18(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam19(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam20(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam21(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam22(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam23(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam24(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam25(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam26(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam27(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam28(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam29(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam30(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam31(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam32(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam33(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam34(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam35(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam36(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam37(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam38(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam39(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam40(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam41(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam42(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam43(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam44(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam45(V self, V *args);
Clo g_heff_2esyntax_2esurface_2etryTypeL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2etryTypeL_entry, 2, 0};

V g_heff_2esyntax_2esurface_2etryTypeL(V v_r_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nothing: {
    heff_drop_rec(v_r_240, 3);
    return ((V)&g_heff_2esyntax_2esurface_2etryTypeL_lam0_clo);
  }
  case TAG_Just: {
    V v_x21_244 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24Just = heff_take_reuse_n(v_x2_241, 1ULL, 1);
    switch (heff_tag_of(v_x21_244)) {
    case TAG_Atom: {
      heff_drop_rec(v_r_240, 3);
      V v_t_246 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 1); r_; });
      V v_t_247 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_246, 3), heff_get_n(v_t_246, 4, 9)});
      V v_t_248 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str0)}), v_t_247});
      V v_x_249 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_248});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam1, 1, 1, (V[]){v_x_249});
    }
    case TAG_EParen: {
      heff_drop_rec(v_r_240, 3);
      V v_t_2414 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 3); r_; });
      V v_t_2415 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_2414, 3), heff_get_n(v_t_2414, 4, 9)});
      V v_t_2416 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str1)}), v_t_2415});
      V v_x_2417 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_2416});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam2, 1, 1, (V[]){v_x_2417});
    }
    case TAG_Named: {
      V v_x_2420 = heff_field(v_x21_244, 1);
      V v_e_2422 = heff_field(v_x21_244, 3);
      heff_take_n(v_x21_244, 10ULL, 5);
      heff_drop_cell(v_ru_24x2_241_24Just, 1);
      if (heff_strEq_c(heff_dup(heff_rfield(v_x_2420, 1)), ((V)&g_heff_2esyntax_2esurface_2etryTypeL_str2))) {
        heff_drop_rec(v_x_2420, 9);
        V v_m_2425 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_2422}));
        return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam3, 1, 1, (V[]){v_m_2425});
      } else {
        heff_drop_rec(v_r_240, 3);
        heff_drop(v_e_2422);
        return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam4, 1, 1, (V[]){v_x_2420});
      }
    }
    case TAG_Tup: {
      heff_drop_rec(v_r_240, 3);
      V v_t_2441 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 4); r_; });
      V v_t_2442 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_2441, 3), heff_get_n(v_t_2441, 4, 9)});
      V v_t_2443 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str4)}), v_t_2442});
      V v_x_2444 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_2443});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam5, 1, 1, (V[]){v_x_2444});
    }
    case TAG_Seg: {
      heff_drop_rec(v_r_240, 3);
      V v_t_2449 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 3); r_; });
      V v_t_2450 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_2449, 3), heff_get_n(v_t_2449, 4, 9)});
      V v_t_2451 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str5)}), v_t_2450});
      V v_x_2452 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_2451});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam6, 1, 1, (V[]){v_x_2452});
    }
    case TAG_Braces: {
      heff_drop_rec(v_r_240, 3);
      V v_t_2458 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 4); r_; });
      V v_t_2459 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_2458, 3), heff_get_n(v_t_2458, 4, 9)});
      V v_t_2460 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str6)}), v_t_2459});
      V v_x_2461 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_2460});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam7, 1, 1, (V[]){v_x_2461});
    }
    case TAG_Update: {
      heff_drop_rec(v_r_240, 3);
      V v_t_2469 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 6); r_; });
      V v_t_2470 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_2469, 3), heff_get_n(v_t_2469, 4, 9)});
      V v_t_2471 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str7)}), v_t_2470});
      V v_x_2472 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_2471});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam8, 1, 1, (V[]){v_x_2472});
    }
    case TAG_EUSet: {
      heff_drop_rec(v_r_240, 3);
      V v_t_2477 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 3); r_; });
      V v_t_2478 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_2477, 3), heff_get_n(v_t_2477, 4, 9)});
      V v_t_2479 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str8)}), v_t_2478});
      V v_x_2480 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_2479});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam9, 1, 1, (V[]){v_x_2480});
    }
    case TAG_InstB: {
      heff_drop_rec(v_r_240, 3);
      V v_t_2487 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 5); r_; });
      V v_t_2488 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_2487, 3), heff_get_n(v_t_2487, 4, 9)});
      V v_t_2489 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str9)}), v_t_2488});
      V v_x_2490 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_2489});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam10, 1, 1, (V[]){v_x_2490});
    }
    case TAG_EFSet: {
      heff_drop_rec(v_r_240, 3);
      V v_t_2495 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 3); r_; });
      V v_t_2496 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_2495, 3), heff_get_n(v_t_2495, 4, 9)});
      V v_t_2497 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str10)}), v_t_2496});
      V v_x_2498 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_2497});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam11, 1, 1, (V[]){v_x_2498});
    }
    case TAG_EFDefault: {
      heff_drop_rec(v_r_240, 3);
      V v_t_24103 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 3); r_; });
      V v_t_24104 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24103, 3), heff_get_n(v_t_24103, 4, 9)});
      V v_t_24105 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str11)}), v_t_24104});
      V v_x_24106 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_24105});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam12, 1, 1, (V[]){v_x_24106});
    }
    case TAG_Sum: {
      heff_drop_rec(v_r_240, 3);
      V v_t_24113 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 5); r_; });
      V v_t_24114 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24113, 3), heff_get_n(v_t_24113, 4, 9)});
      V v_t_24115 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str12)}), v_t_24114});
      V v_x_24116 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_24115});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam13, 1, 1, (V[]){v_x_24116});
    }
    case TAG_ECon: {
      heff_drop_rec(v_r_240, 3);
      V v_t_24120 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 2); r_; });
      V v_t_24121 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24120, 3), heff_get_n(v_t_24120, 4, 9)});
      V v_t_24122 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str13)}), v_t_24121});
      V v_x_24123 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_24122});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam14, 1, 1, (V[]){v_x_24123});
    }
    case TAG_EField: {
      heff_drop_rec(v_r_240, 3);
      V v_t_24127 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 2); r_; });
      V v_t_24128 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24127, 3), heff_get_n(v_t_24127, 4, 9)});
      V v_t_24129 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str14)}), v_t_24128});
      V v_x_24130 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_24129});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam15, 1, 1, (V[]){v_x_24130});
    }
    case TAG_ENeg: {
      heff_drop_rec(v_r_240, 3);
      V v_t_24134 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 2); r_; });
      V v_t_24135 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24134, 3), heff_get_n(v_t_24134, 4, 9)});
      V v_t_24136 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str15)}), v_t_24135});
      V v_x_24137 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_24136});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam16, 1, 1, (V[]){v_x_24137});
    }
    case TAG_ETilde: {
      heff_drop_rec(v_r_240, 3);
      V v_t_24141 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 2); r_; });
      V v_t_24142 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24141, 3), heff_get_n(v_t_24141, 4, 9)});
      V v_t_24143 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str16)}), v_t_24142});
      V v_x_24144 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_24143});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam17, 1, 1, (V[]){v_x_24144});
    }
    case TAG_App: {
      heff_drop_rec(v_r_240, 3);
      V v_t_24148 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 2); r_; });
      V v_t_24149 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24148, 3), heff_get_n(v_t_24148, 4, 9)});
      V v_t_24150 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str17)}), v_t_24149});
      V v_x_24151 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_24150});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam18, 1, 1, (V[]){v_x_24151});
    }
    case TAG_Op: {
      heff_drop_rec(v_r_240, 3);
      V v_t_24156 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 3); r_; });
      V v_t_24157 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24156, 3), heff_get_n(v_t_24156, 4, 9)});
      V v_t_24158 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str18)}), v_t_24157});
      V v_x_24159 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_24158});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam19, 1, 1, (V[]){v_x_24159});
    }
    case TAG_Ops: {
      heff_drop_rec(v_r_240, 3);
      V v_t_24163 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 2); r_; });
      V v_t_24164 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24163, 3), heff_get_n(v_t_24163, 4, 9)});
      V v_t_24165 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str19)}), v_t_24164});
      V v_x_24166 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_24165});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam20, 1, 1, (V[]){v_x_24166});
    }
    case TAG_OpRhs: {
      heff_drop_rec(v_r_240, 3);
      V v_t_24170 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 2); r_; });
      V v_t_24171 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24170, 3), heff_get_n(v_t_24170, 4, 9)});
      V v_t_24172 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str20)}), v_t_24171});
      V v_x_24173 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_24172});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam21, 1, 1, (V[]){v_x_24173});
    }
    case TAG_Ann: {
      heff_drop_rec(v_r_240, 3);
      V v_t_24178 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 3); r_; });
      V v_t_24179 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24178, 3), heff_get_n(v_t_24178, 4, 9)});
      V v_t_24180 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str21)}), v_t_24179});
      V v_x_24181 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_24180});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam22, 1, 1, (V[]){v_x_24181});
    }
    case TAG_BVar: {
      heff_drop_rec(v_r_240, 3);
      V v_t_24184 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 1); r_; });
      V v_t_24185 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24184, 3), heff_get_n(v_t_24184, 4, 9)});
      V v_t_24186 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str22)}), v_t_24185});
      V v_x_24187 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_24186});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam23, 1, 1, (V[]){v_x_24187});
    }
    case TAG_BImp: {
      heff_drop_rec(v_r_240, 3);
      V v_t_24192 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 3); r_; });
      V v_t_24193 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24192, 3), heff_get_n(v_t_24192, 4, 9)});
      V v_t_24194 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str23)}), v_t_24193});
      V v_x_24195 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_24194});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam24, 1, 1, (V[]){v_x_24195});
    }
    case TAG_BAnn: {
      heff_drop_rec(v_r_240, 3);
      V v_t_24202 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 5); r_; });
      V v_t_24203 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24202, 3), heff_get_n(v_t_24202, 4, 9)});
      V v_t_24204 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str24)}), v_t_24203});
      V v_x_24205 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_24204});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam25, 1, 1, (V[]){v_x_24205});
    }
    case TAG_BPat: {
      heff_drop_rec(v_r_240, 3);
      V v_t_24208 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 1); r_; });
      V v_t_24209 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24208, 3), heff_get_n(v_t_24208, 4, 9)});
      V v_t_24210 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str25)}), v_t_24209});
      V v_x_24211 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_24210});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam26, 1, 1, (V[]){v_x_24211});
    }
    case TAG_Lam: {
      heff_drop_rec(v_r_240, 3);
      V v_t_24217 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 4); r_; });
      V v_t_24218 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24217, 3), heff_get_n(v_t_24217, 4, 9)});
      V v_t_24219 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str26)}), v_t_24218});
      V v_x_24220 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_24219});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam27, 1, 1, (V[]){v_x_24220});
    }
    case TAG_Case: {
      heff_drop_rec(v_r_240, 3);
      V v_t_24226 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 4); r_; });
      V v_t_24227 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24226, 3), heff_get_n(v_t_24226, 4, 9)});
      V v_t_24228 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str27)}), v_t_24227});
      V v_x_24229 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_24228});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam28, 1, 1, (V[]){v_x_24229});
    }
    case TAG_EAlt: {
      heff_drop_rec(v_r_240, 3);
      V v_t_24234 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 3); r_; });
      V v_t_24235 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24234, 3), heff_get_n(v_t_24234, 4, 9)});
      V v_t_24236 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str28)}), v_t_24235});
      V v_x_24237 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_24236});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam29, 1, 1, (V[]){v_x_24237});
    }
    case TAG_If: {
      heff_drop_rec(v_r_240, 3);
      V v_t_24245 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 6); r_; });
      V v_t_24246 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24245, 3), heff_get_n(v_t_24245, 4, 9)});
      V v_t_24247 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str29)}), v_t_24246});
      V v_x_24248 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_24247});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam30, 1, 1, (V[]){v_x_24248});
    }
    case TAG_Do: {
      heff_drop_rec(v_r_240, 3);
      V v_t_24252 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 2); r_; });
      V v_t_24253 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24252, 3), heff_get_n(v_t_24252, 4, 9)});
      V v_t_24254 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str30)}), v_t_24253});
      V v_x_24255 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_24254});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam31, 1, 1, (V[]){v_x_24255});
    }
    case TAG_ESBind: {
      heff_drop_rec(v_r_240, 3);
      V v_t_24260 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 3); r_; });
      V v_t_24261 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24260, 3), heff_get_n(v_t_24260, 4, 9)});
      V v_t_24262 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str31)}), v_t_24261});
      V v_x_24263 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_24262});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam32, 1, 1, (V[]){v_x_24263});
    }
    case TAG_ELet: {
      heff_drop_rec(v_r_240, 3);
      V v_t_24271 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 6); r_; });
      V v_t_24272 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24271, 3), heff_get_n(v_t_24271, 4, 9)});
      V v_t_24273 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str32)}), v_t_24272});
      V v_x_24274 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_24273});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam33, 1, 1, (V[]){v_x_24274});
    }
    case TAG_ELetElse: {
      heff_drop_rec(v_r_240, 3);
      V v_t_24283 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 7); r_; });
      V v_t_24284 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24283, 3), heff_get_n(v_t_24283, 4, 9)});
      V v_t_24285 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str33)}), v_t_24284});
      V v_x_24286 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_24285});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam34, 1, 1, (V[]){v_x_24286});
    }
    case TAG_ELetMut: {
      heff_drop_rec(v_r_240, 3);
      V v_t_24294 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 6); r_; });
      V v_t_24295 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24294, 3), heff_get_n(v_t_24294, 4, 9)});
      V v_t_24296 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str34)}), v_t_24295});
      V v_x_24297 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_24296});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam35, 1, 1, (V[]){v_x_24297});
    }
    case TAG_EAssign: {
      heff_drop_rec(v_r_240, 3);
      V v_t_24302 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 3); r_; });
      V v_t_24303 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24302, 3), heff_get_n(v_t_24302, 4, 9)});
      V v_t_24304 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str35)}), v_t_24303});
      V v_x_24305 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_24304});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam36, 1, 1, (V[]){v_x_24305});
    }
    case TAG_EWhile: {
      heff_drop_rec(v_r_240, 3);
      V v_t_24311 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 4); r_; });
      V v_t_24312 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24311, 3), heff_get_n(v_t_24311, 4, 9)});
      V v_t_24313 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str36)}), v_t_24312});
      V v_x_24314 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_24313});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam37, 1, 1, (V[]){v_x_24314});
    }
    case TAG_EFor: {
      heff_drop_rec(v_r_240, 3);
      V v_t_24322 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 6); r_; });
      V v_t_24323 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24322, 3), heff_get_n(v_t_24322, 4, 9)});
      V v_t_24324 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str37)}), v_t_24323});
      V v_x_24325 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_24324});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam38, 1, 1, (V[]){v_x_24325});
    }
    case TAG_EJump: {
      heff_drop_rec(v_r_240, 3);
      V v_t_24328 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 1); r_; });
      V v_t_24329 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24328, 3), heff_get_n(v_t_24328, 4, 9)});
      V v_t_24330 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str38)}), v_t_24329});
      V v_x_24331 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_24330});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam39, 1, 1, (V[]){v_x_24331});
    }
    case TAG_EReturn: {
      heff_drop_rec(v_r_240, 3);
      V v_t_24335 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 2); r_; });
      V v_t_24336 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24335, 3), heff_get_n(v_t_24335, 4, 9)});
      V v_t_24337 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str39)}), v_t_24336});
      V v_x_24338 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_24337});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam40, 1, 1, (V[]){v_x_24338});
    }
    case TAG_ENest: {
      heff_drop_rec(v_r_240, 3);
      V v_t_24344 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 4); r_; });
      V v_t_24345 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24344, 3), heff_get_n(v_t_24344, 4, 9)});
      V v_t_24346 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str40)}), v_t_24345});
      V v_x_24347 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_24346});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam41, 1, 1, (V[]){v_x_24347});
    }
    case TAG_IfThen: {
      heff_drop_rec(v_r_240, 3);
      V v_t_24353 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 4); r_; });
      V v_t_24354 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24353, 3), heff_get_n(v_t_24353, 4, 9)});
      V v_t_24355 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str41)}), v_t_24354});
      V v_x_24356 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_24355});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam42, 1, 1, (V[]){v_x_24356});
    }
    case TAG_ETry: {
      heff_drop_rec(v_r_240, 3);
      V v_t_24362 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 4); r_; });
      V v_t_24363 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24362, 3), heff_get_n(v_t_24362, 4, 9)});
      V v_t_24364 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str42)}), v_t_24363});
      V v_x_24365 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_24364});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam43, 1, 1, (V[]){v_x_24365});
    }
    case TAG_ECatch: {
      heff_drop_rec(v_r_240, 3);
      V v_t_24371 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 4); r_; });
      V v_t_24372 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24371, 3), heff_get_n(v_t_24371, 4, 9)});
      V v_t_24373 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str43)}), v_t_24372});
      V v_x_24374 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_24373});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam44, 1, 1, (V[]){v_x_24374});
    }
    case TAG_EWith: {
      heff_drop_rec(v_r_240, 3);
      V v_t_24382 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 6); r_; });
      V v_t_24383 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24382, 3), heff_get_n(v_t_24382, 4, 9)});
      V v_t_24384 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str44)}), v_t_24383});
      V v_x_24385 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_24384});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam45, 1, 1, (V[]){v_x_24385});
    }
    default: return heff_nomatch(v_x21_244);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2esurface_2etryTypeL_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2etryTypeL(a[0], a[1]);
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam0(V self, V *args) {
  V v_st_242 = args[0];
  V v_t_243 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_243, v_st_242});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam1(V self, V *args) {
  V v_st_2410 = args[0];
  V v_x_249 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_249}), v_st_2410});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam2(V self, V *args) {
  V v_st_2418 = args[0];
  V v_x_2417 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2417}), v_st_2418});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam3(V self, V *args) {
  V v_st_2426 = args[0];
  V v_m_2425 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2427 = heff_tr(heff_call(v_m_2425, 1, (V[]){v_st_2426}));
  switch (heff_tag_of(v_x1_2427)) {
  case TAG_MkPair: {
    V v_x11_2428 = heff_field(v_x1_2427, 0);
    V v_st_2429 = heff_field(v_x1_2427, 1);
    V v_ru_24x1_2427_24MkPair = heff_take_reuse_n(v_x1_2427, 3ULL, 2);
    switch (heff_tag_of(v_x11_2428)) {
    case TAG_Left: {
      V v_e_2430 = heff_field(v_x11_2428, 0);
      heff_take_n(v_x11_2428, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_2427_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2430}), v_st_2429});
    }
    case TAG_Right: {
      V v_x_2431 = heff_field(v_x11_2428, 0);
      V v_ru_24x11_2428_24Right = heff_take_reuse_n(v_x11_2428, 1ULL, 1);
      V v_t_2432 = heff_tag_at_n(v_ru_24x11_2428_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Just, 1, (V[]){v_x_2431})});
      return heff_tag_at_n(v_ru_24x1_2427_24MkPair, TAG_MkPair, 2, (V[]){v_t_2432, v_st_2429});
    }
    default: return heff_nomatch(v_x11_2428);
    }
  }
  default: return heff_nomatch(v_x1_2427);
  }
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam4(V self, V *args) {
  V v_st_2433 = args[0];
  V v_x_2420 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2434 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_x_2420, 3), heff_get_n(v_x_2420, 4, 9)});
  V v_t_2435 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str3)}), v_t_2434});
  V v_t_2436 = heff_tag_n(TAG_Right, 1, (V[]){heff_tag_n(TAG_Just, 1, (V[]){v_t_2435})});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2436, v_st_2433});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam5(V self, V *args) {
  V v_st_2445 = args[0];
  V v_x_2444 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2444}), v_st_2445});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam6(V self, V *args) {
  V v_st_2453 = args[0];
  V v_x_2452 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2452}), v_st_2453});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam7(V self, V *args) {
  V v_st_2462 = args[0];
  V v_x_2461 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2461}), v_st_2462});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam8(V self, V *args) {
  V v_st_2473 = args[0];
  V v_x_2472 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2472}), v_st_2473});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam9(V self, V *args) {
  V v_st_2481 = args[0];
  V v_x_2480 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2480}), v_st_2481});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam10(V self, V *args) {
  V v_st_2491 = args[0];
  V v_x_2490 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2490}), v_st_2491});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam11(V self, V *args) {
  V v_st_2499 = args[0];
  V v_x_2498 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2498}), v_st_2499});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam12(V self, V *args) {
  V v_st_24107 = args[0];
  V v_x_24106 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24106}), v_st_24107});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam13(V self, V *args) {
  V v_st_24117 = args[0];
  V v_x_24116 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24116}), v_st_24117});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam14(V self, V *args) {
  V v_st_24124 = args[0];
  V v_x_24123 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24123}), v_st_24124});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam15(V self, V *args) {
  V v_st_24131 = args[0];
  V v_x_24130 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24130}), v_st_24131});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam16(V self, V *args) {
  V v_st_24138 = args[0];
  V v_x_24137 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24137}), v_st_24138});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam17(V self, V *args) {
  V v_st_24145 = args[0];
  V v_x_24144 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24144}), v_st_24145});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam18(V self, V *args) {
  V v_st_24152 = args[0];
  V v_x_24151 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24151}), v_st_24152});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam19(V self, V *args) {
  V v_st_24160 = args[0];
  V v_x_24159 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24159}), v_st_24160});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam20(V self, V *args) {
  V v_st_24167 = args[0];
  V v_x_24166 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24166}), v_st_24167});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam21(V self, V *args) {
  V v_st_24174 = args[0];
  V v_x_24173 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24173}), v_st_24174});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam22(V self, V *args) {
  V v_st_24182 = args[0];
  V v_x_24181 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24181}), v_st_24182});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam23(V self, V *args) {
  V v_st_24188 = args[0];
  V v_x_24187 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24187}), v_st_24188});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam24(V self, V *args) {
  V v_st_24196 = args[0];
  V v_x_24195 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24195}), v_st_24196});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam25(V self, V *args) {
  V v_st_24206 = args[0];
  V v_x_24205 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24205}), v_st_24206});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam26(V self, V *args) {
  V v_st_24212 = args[0];
  V v_x_24211 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24211}), v_st_24212});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam27(V self, V *args) {
  V v_st_24221 = args[0];
  V v_x_24220 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24220}), v_st_24221});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam28(V self, V *args) {
  V v_st_24230 = args[0];
  V v_x_24229 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24229}), v_st_24230});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam29(V self, V *args) {
  V v_st_24238 = args[0];
  V v_x_24237 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24237}), v_st_24238});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam30(V self, V *args) {
  V v_st_24249 = args[0];
  V v_x_24248 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24248}), v_st_24249});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam31(V self, V *args) {
  V v_st_24256 = args[0];
  V v_x_24255 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24255}), v_st_24256});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam32(V self, V *args) {
  V v_st_24264 = args[0];
  V v_x_24263 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24263}), v_st_24264});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam33(V self, V *args) {
  V v_st_24275 = args[0];
  V v_x_24274 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24274}), v_st_24275});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam34(V self, V *args) {
  V v_st_24287 = args[0];
  V v_x_24286 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24286}), v_st_24287});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam35(V self, V *args) {
  V v_st_24298 = args[0];
  V v_x_24297 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24297}), v_st_24298});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam36(V self, V *args) {
  V v_st_24306 = args[0];
  V v_x_24305 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24305}), v_st_24306});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam37(V self, V *args) {
  V v_st_24315 = args[0];
  V v_x_24314 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24314}), v_st_24315});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam38(V self, V *args) {
  V v_st_24326 = args[0];
  V v_x_24325 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24325}), v_st_24326});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam39(V self, V *args) {
  V v_st_24332 = args[0];
  V v_x_24331 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24331}), v_st_24332});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam40(V self, V *args) {
  V v_st_24339 = args[0];
  V v_x_24338 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24338}), v_st_24339});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam41(V self, V *args) {
  V v_st_24348 = args[0];
  V v_x_24347 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24347}), v_st_24348});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam42(V self, V *args) {
  V v_st_24357 = args[0];
  V v_x_24356 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24356}), v_st_24357});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam43(V self, V *args) {
  V v_st_24366 = args[0];
  V v_x_24365 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24365}), v_st_24366});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam44(V self, V *args) {
  V v_st_24375 = args[0];
  V v_x_24374 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24374}), v_st_24375});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam45(V self, V *args) {
  V v_st_24386 = args[0];
  V v_x_24385 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24385}), v_st_24386});
}
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str0, 7, "integer");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str1, 28, "a segment says its type once");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str2, 6, "binary");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str3, 28, "a segment says its type once");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str4, 5, "bytes");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str5, 28, "a segment says its type once");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str6, 4, "bits");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str7, 28, "a segment says its type once");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str8, 9, "bitstring");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str9, 28, "a segment says its type once");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str10, 5, "float");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str11, 28, "a segment says its type once");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str12, 4, "utf8");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str13, 28, "a segment says its type once");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str14, 5, "utf16");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str15, 28, "a segment says its type once");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str16, 5, "utf32");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str17, 28, "a segment says its type once");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str18, 3, "big");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str19, 34, "a segment says its endianness once");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str20, 6, "little");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str21, 34, "a segment says its endianness once");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str22, 6, "signed");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str23, 28, "a segment says its sign once");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str24, 8, "unsigned");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str25, 28, "a segment says its sign once");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str26, 227, "a segment's spec is its type (`integer`, `binary`, `bits`, `float`, `utf8`, `utf16`, `utf32`), size (`16`, `size(n)`), unit (`unit(8)`), endianness (`big`, `little`) and sign (`signed`, `unsigned`), between `-`s: `x::16-little`");
Clo g_heff_2esyntax_2esurface_2especWord_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2especWord_entry, 3, 0};

V g_heff_2esyntax_2esurface_2especWord(V v_t_240, V v_s_241, V v_p_242) {
top: ;
  if (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 1)), ((V)&g_heff_2esyntax_2esurface_2especWord_str0))) {
    V v_t_244 = heff_take_field(v_s_241, 0);
    switch (heff_tag_of(v_t_244)) {
    case TAG_Nothing: {
      heff_drop_rec(v_t_240, 9);
      V v_t_245 = heff_tag_n(TAG_Just, 1, (V[]){NTAG(TAG_SegmentInteger)});
      V v_t_246 = ({ V rv_0 = v_t_245; V rr_ = heff_rec_reuse_nf(v_s_241, 30ULL, 5, shape_ty__size__unit__little__signed, 1020u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_246}), v_p_242});
    }
    case TAG_Just: {
      V v_ru_24t_244_24Just = heff_take_reuse_n(v_t_244, 0ULL, 1);
      heff_drop_rec(v_s_241, 5);
      V v_t_248 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_240, 3), heff_get_n(v_t_240, 4, 9)});
      V v_t_249 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2especWord_str1), v_t_248, NTAG(TAG_Nothing)});
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24t_244_24Just, TAG_Left, 1, (V[]){v_t_249}), v_p_242});
    }
    default: return heff_nomatch(v_t_244);
    }
  } else {
    if (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 1)), ((V)&g_heff_2esyntax_2esurface_2especWord_str2))) {
      V v_t_2411 = heff_take_field(v_s_241, 0);
      switch (heff_tag_of(v_t_2411)) {
      case TAG_Nothing: {
        heff_drop_rec(v_t_240, 9);
        V v_t_2412 = heff_tag_n(TAG_Just, 1, (V[]){NTAG(TAG_SegmentBinary)});
        V v_t_2413 = ({ V rv_0 = v_t_2412; V rr_ = heff_rec_reuse_nf(v_s_241, 30ULL, 5, shape_ty__size__unit__little__signed, 1020u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
        return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2413}), v_p_242});
      }
      case TAG_Just: {
        V v_ru_24t_2411_24Just = heff_take_reuse_n(v_t_2411, 0ULL, 1);
        heff_drop_rec(v_s_241, 5);
        V v_t_2415 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_240, 3), heff_get_n(v_t_240, 4, 9)});
        V v_t_2416 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2especWord_str3), v_t_2415, NTAG(TAG_Nothing)});
        return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24t_2411_24Just, TAG_Left, 1, (V[]){v_t_2416}), v_p_242});
      }
      default: return heff_nomatch(v_t_2411);
      }
    } else {
      if (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 1)), ((V)&g_heff_2esyntax_2esurface_2especWord_str4))) {
        V v_t_2418 = heff_take_field(v_s_241, 0);
        switch (heff_tag_of(v_t_2418)) {
        case TAG_Nothing: {
          heff_drop_rec(v_t_240, 9);
          V v_t_2419 = heff_tag_n(TAG_Just, 1, (V[]){NTAG(TAG_SegmentBinary)});
          V v_t_2420 = ({ V rv_0 = v_t_2419; V rr_ = heff_rec_reuse_nf(v_s_241, 30ULL, 5, shape_ty__size__unit__little__signed, 1020u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
          return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2420}), v_p_242});
        }
        case TAG_Just: {
          V v_ru_24t_2418_24Just = heff_take_reuse_n(v_t_2418, 0ULL, 1);
          heff_drop_rec(v_s_241, 5);
          V v_t_2422 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_240, 3), heff_get_n(v_t_240, 4, 9)});
          V v_t_2423 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2especWord_str5), v_t_2422, NTAG(TAG_Nothing)});
          return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24t_2418_24Just, TAG_Left, 1, (V[]){v_t_2423}), v_p_242});
        }
        default: return heff_nomatch(v_t_2418);
        }
      } else {
        if (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 1)), ((V)&g_heff_2esyntax_2esurface_2especWord_str6))) {
          V v_t_2425 = heff_take_field(v_s_241, 0);
          switch (heff_tag_of(v_t_2425)) {
          case TAG_Nothing: {
            heff_drop_rec(v_t_240, 9);
            V v_t_2426 = heff_tag_n(TAG_Just, 1, (V[]){NTAG(TAG_SegmentBits)});
            V v_t_2427 = ({ V rv_0 = v_t_2426; V rr_ = heff_rec_reuse_nf(v_s_241, 30ULL, 5, shape_ty__size__unit__little__signed, 1020u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
            return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2427}), v_p_242});
          }
          case TAG_Just: {
            V v_ru_24t_2425_24Just = heff_take_reuse_n(v_t_2425, 0ULL, 1);
            heff_drop_rec(v_s_241, 5);
            V v_t_2429 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_240, 3), heff_get_n(v_t_240, 4, 9)});
            V v_t_2430 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2especWord_str7), v_t_2429, NTAG(TAG_Nothing)});
            return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24t_2425_24Just, TAG_Left, 1, (V[]){v_t_2430}), v_p_242});
          }
          default: return heff_nomatch(v_t_2425);
          }
        } else {
          if (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 1)), ((V)&g_heff_2esyntax_2esurface_2especWord_str8))) {
            V v_t_2432 = heff_take_field(v_s_241, 0);
            switch (heff_tag_of(v_t_2432)) {
            case TAG_Nothing: {
              heff_drop_rec(v_t_240, 9);
              V v_t_2433 = heff_tag_n(TAG_Just, 1, (V[]){NTAG(TAG_SegmentBits)});
              V v_t_2434 = ({ V rv_0 = v_t_2433; V rr_ = heff_rec_reuse_nf(v_s_241, 30ULL, 5, shape_ty__size__unit__little__signed, 1020u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
              return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2434}), v_p_242});
            }
            case TAG_Just: {
              V v_ru_24t_2432_24Just = heff_take_reuse_n(v_t_2432, 0ULL, 1);
              heff_drop_rec(v_s_241, 5);
              V v_t_2436 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_240, 3), heff_get_n(v_t_240, 4, 9)});
              V v_t_2437 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2especWord_str9), v_t_2436, NTAG(TAG_Nothing)});
              return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24t_2432_24Just, TAG_Left, 1, (V[]){v_t_2437}), v_p_242});
            }
            default: return heff_nomatch(v_t_2432);
            }
          } else {
            if (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 1)), ((V)&g_heff_2esyntax_2esurface_2especWord_str10))) {
              V v_t_2439 = heff_take_field(v_s_241, 0);
              switch (heff_tag_of(v_t_2439)) {
              case TAG_Nothing: {
                heff_drop_rec(v_t_240, 9);
                V v_t_2440 = heff_tag_n(TAG_Just, 1, (V[]){NTAG(TAG_SegmentFloat)});
                V v_t_2441 = ({ V rv_0 = v_t_2440; V rr_ = heff_rec_reuse_nf(v_s_241, 30ULL, 5, shape_ty__size__unit__little__signed, 1020u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
                return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2441}), v_p_242});
              }
              case TAG_Just: {
                V v_ru_24t_2439_24Just = heff_take_reuse_n(v_t_2439, 0ULL, 1);
                heff_drop_rec(v_s_241, 5);
                V v_t_2443 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_240, 3), heff_get_n(v_t_240, 4, 9)});
                V v_t_2444 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2especWord_str11), v_t_2443, NTAG(TAG_Nothing)});
                return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24t_2439_24Just, TAG_Left, 1, (V[]){v_t_2444}), v_p_242});
              }
              default: return heff_nomatch(v_t_2439);
              }
            } else {
              if (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 1)), ((V)&g_heff_2esyntax_2esurface_2especWord_str12))) {
                V v_t_2446 = heff_take_field(v_s_241, 0);
                switch (heff_tag_of(v_t_2446)) {
                case TAG_Nothing: {
                  heff_drop_rec(v_t_240, 9);
                  V v_t_2447 = heff_tag_n(TAG_Just, 1, (V[]){heff_tag_n(TAG_SegmentUtf, 1, (V[]){MK_INT(8LL)})});
                  V v_t_2448 = ({ V rv_0 = v_t_2447; V rr_ = heff_rec_reuse_nf(v_s_241, 30ULL, 5, shape_ty__size__unit__little__signed, 1020u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
                  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2448}), v_p_242});
                }
                case TAG_Just: {
                  V v_ru_24t_2446_24Just = heff_take_reuse_n(v_t_2446, 0ULL, 1);
                  heff_drop_rec(v_s_241, 5);
                  V v_t_2450 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_240, 3), heff_get_n(v_t_240, 4, 9)});
                  V v_t_2451 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2especWord_str13), v_t_2450, NTAG(TAG_Nothing)});
                  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24t_2446_24Just, TAG_Left, 1, (V[]){v_t_2451}), v_p_242});
                }
                default: return heff_nomatch(v_t_2446);
                }
              } else {
                if (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 1)), ((V)&g_heff_2esyntax_2esurface_2especWord_str14))) {
                  V v_t_2453 = heff_take_field(v_s_241, 0);
                  switch (heff_tag_of(v_t_2453)) {
                  case TAG_Nothing: {
                    heff_drop_rec(v_t_240, 9);
                    V v_t_2454 = heff_tag_n(TAG_Just, 1, (V[]){heff_tag_n(TAG_SegmentUtf, 1, (V[]){MK_INT(16LL)})});
                    V v_t_2455 = ({ V rv_0 = v_t_2454; V rr_ = heff_rec_reuse_nf(v_s_241, 30ULL, 5, shape_ty__size__unit__little__signed, 1020u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
                    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2455}), v_p_242});
                  }
                  case TAG_Just: {
                    V v_ru_24t_2453_24Just = heff_take_reuse_n(v_t_2453, 0ULL, 1);
                    heff_drop_rec(v_s_241, 5);
                    V v_t_2457 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_240, 3), heff_get_n(v_t_240, 4, 9)});
                    V v_t_2458 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2especWord_str15), v_t_2457, NTAG(TAG_Nothing)});
                    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24t_2453_24Just, TAG_Left, 1, (V[]){v_t_2458}), v_p_242});
                  }
                  default: return heff_nomatch(v_t_2453);
                  }
                } else {
                  if (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 1)), ((V)&g_heff_2esyntax_2esurface_2especWord_str16))) {
                    V v_t_2460 = heff_take_field(v_s_241, 0);
                    switch (heff_tag_of(v_t_2460)) {
                    case TAG_Nothing: {
                      heff_drop_rec(v_t_240, 9);
                      V v_t_2461 = heff_tag_n(TAG_Just, 1, (V[]){heff_tag_n(TAG_SegmentUtf, 1, (V[]){MK_INT(32LL)})});
                      V v_t_2462 = ({ V rv_0 = v_t_2461; V rr_ = heff_rec_reuse_nf(v_s_241, 30ULL, 5, shape_ty__size__unit__little__signed, 1020u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
                      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2462}), v_p_242});
                    }
                    case TAG_Just: {
                      V v_ru_24t_2460_24Just = heff_take_reuse_n(v_t_2460, 0ULL, 1);
                      heff_drop_rec(v_s_241, 5);
                      V v_t_2464 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_240, 3), heff_get_n(v_t_240, 4, 9)});
                      V v_t_2465 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2especWord_str17), v_t_2464, NTAG(TAG_Nothing)});
                      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24t_2460_24Just, TAG_Left, 1, (V[]){v_t_2465}), v_p_242});
                    }
                    default: return heff_nomatch(v_t_2460);
                    }
                  } else {
                    if (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 1)), ((V)&g_heff_2esyntax_2esurface_2especWord_str18))) {
                      V v_t_2467 = heff_take_field(v_s_241, 3);
                      switch (heff_tag_of(v_t_2467)) {
                      case TAG_Nothing: {
                        heff_drop_rec(v_t_240, 9);
                        V v_t_2468 = heff_tag_n(TAG_Just, 1, (V[]){NTAG(TAG_False)});
                        V v_t_2469 = ({ V rv_3 = v_t_2468; V rr_ = heff_rec_reuse_nf(v_s_241, 23ULL, 5, shape_ty__size__unit__little__signed, 831u, 0u); heff_rfield(rr_, 3) = rv_3; rr_; });
                        return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2469}), v_p_242});
                      }
                      case TAG_Just: {
                        V v_ru_24t_2467_24Just = heff_take_reuse_n(v_t_2467, 0ULL, 1);
                        heff_drop_rec(v_s_241, 5);
                        V v_t_2471 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_240, 3), heff_get_n(v_t_240, 4, 9)});
                        V v_t_2472 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2especWord_str19), v_t_2471, NTAG(TAG_Nothing)});
                        return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24t_2467_24Just, TAG_Left, 1, (V[]){v_t_2472}), v_p_242});
                      }
                      default: return heff_nomatch(v_t_2467);
                      }
                    } else {
                      if (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 1)), ((V)&g_heff_2esyntax_2esurface_2especWord_str20))) {
                        V v_t_2474 = heff_take_field(v_s_241, 3);
                        switch (heff_tag_of(v_t_2474)) {
                        case TAG_Nothing: {
                          heff_drop_rec(v_t_240, 9);
                          V v_t_2475 = heff_tag_n(TAG_Just, 1, (V[]){NTAG(TAG_True)});
                          V v_t_2476 = ({ V rv_3 = v_t_2475; V rr_ = heff_rec_reuse_nf(v_s_241, 23ULL, 5, shape_ty__size__unit__little__signed, 831u, 0u); heff_rfield(rr_, 3) = rv_3; rr_; });
                          return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2476}), v_p_242});
                        }
                        case TAG_Just: {
                          V v_ru_24t_2474_24Just = heff_take_reuse_n(v_t_2474, 0ULL, 1);
                          heff_drop_rec(v_s_241, 5);
                          V v_t_2478 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_240, 3), heff_get_n(v_t_240, 4, 9)});
                          V v_t_2479 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2especWord_str21), v_t_2478, NTAG(TAG_Nothing)});
                          return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24t_2474_24Just, TAG_Left, 1, (V[]){v_t_2479}), v_p_242});
                        }
                        default: return heff_nomatch(v_t_2474);
                        }
                      } else {
                        if (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 1)), ((V)&g_heff_2esyntax_2esurface_2especWord_str22))) {
                          V v_t_2481 = heff_take_field(v_s_241, 4);
                          switch (heff_tag_of(v_t_2481)) {
                          case TAG_Nothing: {
                            heff_drop_rec(v_t_240, 9);
                            V v_t_2482 = heff_tag_n(TAG_Just, 1, (V[]){NTAG(TAG_True)});
                            V v_t_2483 = ({ V rv_4 = v_t_2482; V rr_ = heff_rec_reuse_nf(v_s_241, 15ULL, 5, shape_ty__size__unit__little__signed, 255u, 0u); heff_rfield(rr_, 4) = rv_4; rr_; });
                            return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2483}), v_p_242});
                          }
                          case TAG_Just: {
                            V v_ru_24t_2481_24Just = heff_take_reuse_n(v_t_2481, 0ULL, 1);
                            heff_drop_rec(v_s_241, 5);
                            V v_t_2485 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_240, 3), heff_get_n(v_t_240, 4, 9)});
                            V v_t_2486 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2especWord_str23), v_t_2485, NTAG(TAG_Nothing)});
                            return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24t_2481_24Just, TAG_Left, 1, (V[]){v_t_2486}), v_p_242});
                          }
                          default: return heff_nomatch(v_t_2481);
                          }
                        } else {
                          if (heff_strEq_c(heff_dup(heff_rfield(v_t_240, 1)), ((V)&g_heff_2esyntax_2esurface_2especWord_str24))) {
                            V v_t_2488 = heff_take_field(v_s_241, 4);
                            switch (heff_tag_of(v_t_2488)) {
                            case TAG_Nothing: {
                              heff_drop_rec(v_t_240, 9);
                              V v_t_2489 = heff_tag_n(TAG_Just, 1, (V[]){NTAG(TAG_False)});
                              V v_t_2490 = ({ V rv_4 = v_t_2489; V rr_ = heff_rec_reuse_nf(v_s_241, 15ULL, 5, shape_ty__size__unit__little__signed, 255u, 0u); heff_rfield(rr_, 4) = rv_4; rr_; });
                              return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2490}), v_p_242});
                            }
                            case TAG_Just: {
                              V v_ru_24t_2488_24Just = heff_take_reuse_n(v_t_2488, 0ULL, 1);
                              heff_drop_rec(v_s_241, 5);
                              V v_t_2492 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_240, 3), heff_get_n(v_t_240, 4, 9)});
                              V v_t_2493 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2especWord_str25), v_t_2492, NTAG(TAG_Nothing)});
                              return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24t_2488_24Just, TAG_Left, 1, (V[]){v_t_2493}), v_p_242});
                            }
                            default: return heff_nomatch(v_t_2488);
                            }
                          } else {
                            heff_drop_rec(v_s_241, 5);
                            V v_t_2494 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_240, 3), heff_get_n(v_t_240, 4, 9)});
                            V v_t_2495 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2especWord_str26), v_t_2494, NTAG(TAG_Nothing)});
                            return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2495}), v_p_242});
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}
V g_heff_2esyntax_2esurface_2especWord_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2especWord(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2esyntax_2esurface_2eunitOf_str0, 3, "int");
HEFF_LIT(g_heff_2esyntax_2esurface_2eunitOf_str1, 28, "a segment says its unit once");
HEFF_LIT(g_heff_2esyntax_2esurface_2eunitOf_str2, 47, "a unit is a number of bits, 1 to 256: `unit(8)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eunitOf_str3, 47, "a unit is a number of bits, 1 to 256: `unit(8)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eunitOf_str4, 47, "a unit is a number of bits, 1 to 256: `unit(8)`");
V g_heff_2esyntax_2esurface_2eunitOf_lam0(V self, V *args);
V g_heff_2esyntax_2esurface_2eunitOf_lam1(V self, V *args);
V g_heff_2esyntax_2esurface_2eunitOf_lam2(V self, V *args);
V g_heff_2esyntax_2esurface_2eunitOf_lam3(V self, V *args);
Clo g_heff_2esyntax_2esurface_2eunitOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eunitOf_entry, 3, 0};

V g_heff_2esyntax_2esurface_2eunitOf(V v_sp_240, V v_n_241, V v_s_242) {
top: ;
  if (heff_strEq_c(heff_dup(heff_rfield(v_n_241, 0)), ((V)&g_heff_2esyntax_2esurface_2eunitOf_str0))) {
    V v_t_244 = (g_heff_2esyntax_2esurface_2eintOfText(heff_rfield(v_n_241, 1)));
    if (heff_intLe_c(MK_INT(1LL), v_t_244)) {
      V v_t_246 = (g_heff_2esyntax_2esurface_2eintOfText(heff_rfield(v_n_241, 1)));
      if (heff_intLe_c(v_t_246, MK_INT(256LL))) {
        V v_n_248 = ({ V b_0 = heff_get_n(v_n_241, 1, 9); V r_ = (g_heff_2esyntax_2esurface_2eintOfText(b_0)); heff_drop(b_0); r_; });
        return heff_clo_n(g_heff_2esyntax_2esurface_2eunitOf_lam0, 1, 3, (V[]){v_s_242, v_n_248, v_sp_240});
      } else {
        heff_drop_rec(v_n_241, 9);
        heff_drop_rec(v_s_242, 5);
        return heff_clo_n(g_heff_2esyntax_2esurface_2eunitOf_lam1, 1, 1, (V[]){v_sp_240});
      }
    } else {
      heff_drop_rec(v_n_241, 9);
      heff_drop_rec(v_s_242, 5);
      return heff_clo_n(g_heff_2esyntax_2esurface_2eunitOf_lam2, 1, 1, (V[]){v_sp_240});
    }
  } else {
    heff_drop_rec(v_n_241, 9);
    heff_drop_rec(v_s_242, 5);
    return heff_clo_n(g_heff_2esyntax_2esurface_2eunitOf_lam3, 1, 1, (V[]){v_sp_240});
  }
}
V g_heff_2esyntax_2esurface_2eunitOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2eunitOf(a[0], a[1], a[2]);
}
V g_heff_2esyntax_2esurface_2eunitOf_lam0(V self, V *args) {
  V v_p_249 = args[0];
  V v_s_242 = heff_env(self)[0];
  V v_n_248 = heff_env(self)[1];
  V v_sp_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2410 = heff_take_field(v_s_242, 2);
  switch (heff_tag_of(v_t_2410)) {
  case TAG_Nothing: {
    heff_drop(v_sp_240);
    V v_t_2411 = ({ V rv_2 = heff_tag_n(TAG_Just, 1, (V[]){v_n_248}); V rr_ = heff_rec_reuse_nf(v_s_242, 27ULL, 5, shape_ty__size__unit__little__signed, 975u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2411}), v_p_249});
  }
  case TAG_Just: {
    V v_ru_24t_2410_24Just = heff_take_reuse_n(v_t_2410, 0ULL, 1);
    heff_drop_rec(v_s_242, 5);
    heff_drop(v_n_248);
    V v_t_2413 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2eunitOf_str1), v_sp_240, NTAG(TAG_Nothing)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24t_2410_24Just, TAG_Left, 1, (V[]){v_t_2413}), v_p_249});
  }
  default: return heff_nomatch(v_t_2410);
  }
}
V g_heff_2esyntax_2esurface_2eunitOf_lam1(V self, V *args) {
  V v_st_2414 = args[0];
  V v_sp_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2415 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2eunitOf_str2), v_sp_240, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2415}), v_st_2414});
}
V g_heff_2esyntax_2esurface_2eunitOf_lam2(V self, V *args) {
  V v_st_2416 = args[0];
  V v_sp_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2417 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2eunitOf_str3), v_sp_240, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2417}), v_st_2416});
}
V g_heff_2esyntax_2esurface_2eunitOf_lam3(V self, V *args) {
  V v_st_2418 = args[0];
  V v_sp_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2419 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2eunitOf_str4), v_sp_240, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2419}), v_st_2418});
}
Clo g_heff_2esyntax_2esurface_2esegmentOf_24s1547151193x813882637_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2esegmentOf_24s1547151193x813882637_entry, 5, 0};

V g_heff_2esyntax_2esurface_2esegmentOf_24s1547151193x813882637(V v_inPat_240, V v_sp_241, V v_e_242, V v_v_243, V v_st_244) {
top: ;
  V v_t_246;
  switch (heff_tag_of(v_v_243)) {
  case TAG_StrValue: {
    v_t_246 = NTAG(TAG_SegmentBinary);
    break;
  }
  case TAG_IntValue: {
    v_t_246 = NTAG(TAG_SegmentInteger);
    break;
  }
  case TAG_FloatValue: {
    v_t_246 = NTAG(TAG_SegmentFloat);
    break;
  }
  case TAG_RuneValue: {
    v_t_246 = heff_tag_n(TAG_SegmentUtf, 1, (V[]){MK_INT(8LL)});
    break;
  }
  case TAG_OtherValue: {
    v_t_246 = NTAG(TAG_SegmentInteger);
    break;
  }
  default: heff_nomatch(v_v_243);
  }
  HeffT2 v_t_247 = (g_heff_2esyntax_2esurface_2evalueKind_24cpr(heff_dup(v_sp_241), heff_dup(v_v_243), v_t_246, v_st_244));
  {
    V v_field_248 = v_t_247.f[0];
    V v_field_249 = v_t_247.f[1];
    V v_x11_2410 = v_field_248;
    V v_st_2411 = v_field_249;
    switch (heff_tag_of(v_x11_2410)) {
    case TAG_Left: {
      V v_e_2412 = heff_field(v_x11_2410, 0);
      V v_ru_24x11_2410_24Left = heff_take_reuse_n(v_x11_2410, 1ULL, 1);
      heff_drop(v_sp_241);
      heff_drop(v_e_242);
      heff_drop(v_v_243);
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_2410_24Left, TAG_Left, 1, (V[]){v_e_2412}), v_st_2411});
    }
    case TAG_Right: {
      V v_ru_24x11_2410_24Right = heff_take_reuse_n(v_x11_2410, 0ULL, 1);
      V v_t_2415;
      switch (heff_tag_of(v_v_243)) {
      case TAG_StrValue: {
        v_t_2415 = NTAG(TAG_SegmentBinary);
        break;
      }
      case TAG_IntValue: {
        v_t_2415 = NTAG(TAG_SegmentInteger);
        break;
      }
      case TAG_FloatValue: {
        v_t_2415 = NTAG(TAG_SegmentFloat);
        break;
      }
      case TAG_RuneValue: {
        v_t_2415 = heff_tag_n(TAG_SegmentUtf, 1, (V[]){MK_INT(8LL)});
        break;
      }
      case TAG_OtherValue: {
        v_t_2415 = NTAG(TAG_SegmentInteger);
        break;
      }
      default: heff_nomatch(v_v_243);
      }
      V v_m_2416 = (g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993(v_inPat_240, heff_dup(v_sp_241), heff_dup(v_v_243), v_t_2415, NTAG(TAG_SizeDefault)));
      V v_x1_2417 = heff_tr(heff_call(v_m_2416, 1, (V[]){v_st_2411}));
      switch (heff_tag_of(v_x1_2417)) {
      case TAG_MkPair: {
        V v_x11_2418 = heff_field(v_x1_2417, 0);
        V v_st_2419 = heff_field(v_x1_2417, 1);
        V v_ru_24x1_2417_24MkPair = heff_take_reuse_n(v_x1_2417, 3ULL, 2);
        switch (heff_tag_of(v_x11_2418)) {
        case TAG_Left: {
          V v_e_2420 = heff_field(v_x11_2418, 0);
          heff_take_n(v_x11_2418, 1ULL, 1);
          heff_drop(v_sp_241);
          heff_drop(v_e_242);
          heff_drop(v_v_243);
          heff_drop_cell(v_ru_24x11_2410_24Right, 1);
          return heff_tag_at_n(v_ru_24x1_2417_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2420}), v_st_2419});
        }
        case TAG_Right: {
          V v_ru_24x11_2418_24Right = heff_take_reuse_n(v_x11_2418, 0ULL, 1);
          V v_t_2423;
          switch (heff_tag_of(v_v_243)) {
          case TAG_StrValue: {
            heff_drop_cell(v_ru_24x11_2418_24Right, 1);
            v_t_2423 = NTAG(TAG_SegmentBinary);
            break;
          }
          case TAG_IntValue: {
            heff_take_n(v_v_243, 0ULL, 1);
            heff_drop_cell(v_ru_24x11_2418_24Right, 1);
            v_t_2423 = NTAG(TAG_SegmentInteger);
            break;
          }
          case TAG_FloatValue: {
            heff_drop_cell(v_ru_24x11_2418_24Right, 1);
            v_t_2423 = NTAG(TAG_SegmentFloat);
            break;
          }
          case TAG_RuneValue: {
            v_t_2423 = heff_tag_at_n(v_ru_24x11_2418_24Right, TAG_SegmentUtf, 1, (V[]){MK_INT(8LL)});
            break;
          }
          case TAG_OtherValue: {
            heff_drop_cell(v_ru_24x11_2418_24Right, 1);
            v_t_2423 = NTAG(TAG_SegmentInteger);
            break;
          }
          default: heff_nomatch(v_v_243);
          }
          V v_t_2424 = heff_tag_n(TAG_MkSegment, 5, (V[]){v_e_242, v_t_2423, NTAG(TAG_SizeDefault), NTAG(TAG_False), NTAG(TAG_False)});
          V v_t_2425 = heff_tag_at_n(v_ru_24x11_2410_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2424, v_sp_241})});
          return heff_tag_at_n(v_ru_24x1_2417_24MkPair, TAG_MkPair, 2, (V[]){v_t_2425, v_st_2419});
        }
        default: return heff_nomatch(v_x11_2418);
        }
      }
      default: return heff_nomatch(v_x1_2417);
      }
    }
    default: return heff_nomatch(v_x11_2410);
    }
  }
}
V g_heff_2esyntax_2esurface_2esegmentOf_24s1547151193x813882637_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2esurface_2esegmentOf_24s1547151193x813882637(a0, a[1], a[2], a[3], a[4]); heff_drop(a0); return r;
}
V g_heff_2esyntax_2esurface_2epushS_24s1868233564x1858628873_lam0(V self, V *args);
V g_heff_2esyntax_2esurface_2epushS_24s1868233564x1858628873_lam1(V self, V *args);
Clo g_heff_2esyntax_2esurface_2epushS_24s1868233564x1858628873_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2epushS_24s1868233564x1858628873_entry, 4, 0};

V g_heff_2esyntax_2esurface_2epushS_24s1868233564x1858628873(V v_fix_240, V v_lenient_241, V v_st_242, V v_r_243) {
top: ;
  V v_t_244 = heff_dup(heff_rfield(v_st_242, 0));
  switch (heff_tag_of(v_t_244)) {
  case TAG_Nil: {
    heff_drop(v_fix_240);
    return heff_clo_n(g_heff_2esyntax_2esurface_2epushS_24s1868233564x1858628873_lam0, 1, 2, (V[]){v_r_243, v_st_242});
  }
  case TAG_Cons: {
    V v_before_249 = heff_field(v_t_244, 0);
    heff_take_n(v_t_244, 1ULL, 2);
    V v_m_2411 = (g_heff_2esyntax_2esurface_2efirstS(heff_dup(v_fix_240), v_lenient_241, v_before_249, heff_dup(heff_rfield(v_r_243, 0))));
    return heff_clo_n(g_heff_2esyntax_2esurface_2epushS_24s1868233564x1858628873_lam1, 1, 5, (V[]){v_m_2411, v_st_242, v_fix_240, heff_dup(v_lenient_241), v_r_243});
  }
  default: return heff_nomatch(v_t_244);
  }
}
V g_heff_2esyntax_2esurface_2epushS_24s1868233564x1858628873_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2esyntax_2esurface_2epushS_24s1868233564x1858628873(a[0], a1, a[2], a[3]); heff_drop(a1); return r;
}
V g_heff_2esyntax_2esurface_2epushS_24s1868233564x1858628873_lam0(V self, V *args) {
  V v_st_245 = args[0];
  V v_r_243 = heff_env(self)[0];
  V v_st_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){heff_take_field(v_r_243, 0), heff_take_field(v_st_242, 0)});
  V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){heff_get_n(v_r_243, 1, 2), heff_get_n(v_st_242, 1, 2)});
  V v_t_248 = heff_tag_n(TAG_Right, 1, (V[]){heff_rec_n(2, shape_ops__out, (V[]){v_t_246, v_t_247})});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_248, v_st_245});
}
V g_heff_2esyntax_2esurface_2epushS_24s1868233564x1858628873_lam1(V self, V *args) {
  V v_st_2412 = args[0];
  V v_m_2411 = heff_env(self)[0];
  V v_st_242 = heff_env(self)[1];
  V v_fix_240 = heff_env(self)[2];
  V v_lenient_241 = heff_env(self)[3];
  V v_r_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_x1_2413 = heff_tr(heff_call(v_m_2411, 1, (V[]){v_st_2412}));
  switch (heff_tag_of(v_x1_2413)) {
  case TAG_MkPair: {
    V v_x11_2414 = heff_field(v_x1_2413, 0);
    V v_st_2415 = heff_field(v_x1_2413, 1);
    V v_ru_24x1_2413_24MkPair = heff_take_reuse_n(v_x1_2413, 3ULL, 2);
    switch (heff_tag_of(v_x11_2414)) {
    case TAG_Left: {
      V v_e_2416 = heff_field(v_x11_2414, 0);
      heff_take_n(v_x11_2414, 1ULL, 1);
      heff_drop_rec(v_st_242, 2);
      heff_drop(v_fix_240);
      heff_drop(v_lenient_241);
      heff_drop_rec(v_r_243, 2);
      return heff_tag_at_n(v_ru_24x1_2413_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2416}), v_st_2415});
    }
    case TAG_Right: {
      V v_x_2417 = heff_field(v_x11_2414, 0);
      V v_ru_24x11_2414_24Right = heff_take_reuse_n(v_x11_2414, 1ULL, 1);
      if ((heff_dup(v_x_2417) == NTAG(TAG_True))) {
        heff_drop_cell(v_ru_24x1_2413_24MkPair, 2);
        heff_drop(v_x_2417);
        heff_drop_cell(v_ru_24x11_2414_24Right, 1);
        V v_t_2418 = heff_dup(heff_rfield(v_st_242, 0));
        V v_t_2427;
        switch (heff_tag_of(v_t_2418)) {
        case TAG_Nil: {
          v_t_2427 = v_st_242;
          break;
        }
        case TAG_Cons: {
          V v_o_2419 = heff_field(v_t_2418, 0);
          V v_os_2420 = heff_field(v_t_2418, 1);
          heff_take_n(v_t_2418, 3ULL, 2);
          V v_t_2421 = heff_dup(heff_rfield(v_st_242, 1));
          switch (heff_tag_of(v_t_2421)) {
          case TAG_Nil: {
            heff_drop(v_o_2419);
            heff_drop(v_os_2420);
            v_t_2427 = v_st_242;
            break;
          }
          case TAG_Cons: {
            V v_r_2422 = heff_field(v_t_2421, 0);
            V v_it2_2423 = heff_field(v_t_2421, 1);
            heff_take_n(v_t_2421, 3ULL, 2);
            switch (heff_tag_of(v_it2_2423)) {
            case TAG_Nil: {
              heff_drop(v_o_2419);
              heff_drop(v_os_2420);
              heff_drop(v_r_2422);
              v_t_2427 = v_st_242;
              break;
            }
            case TAG_Cons: {
              V v_l_2424 = heff_field(v_it2_2423, 0);
              V v_rest_2425 = heff_field(v_it2_2423, 1);
              heff_take_n(v_it2_2423, 3ULL, 2);
              heff_drop_rec(v_st_242, 2);
              V v_t_2426 = (g_heff_2esyntax_2esurface_2eapplyOp(v_o_2419, v_l_2424, v_r_2422));
              v_t_2427 = heff_rec_n(2, shape_ops__out, (V[]){v_os_2420, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2426, v_rest_2425})});
              break;
            }
            default: heff_nomatch(v_it2_2423);
            }
            break;
          }
          default: heff_nomatch(v_t_2421);
          }
          break;
        }
        default: heff_nomatch(v_t_2418);
        }
        V v_t_2428 = ({ V a_0 = v_fix_240; V a_1 = v_lenient_241; V a_2 = v_t_2427; V a_3 = v_r_243; V r_ = (g_heff_2esyntax_2esurface_2epushS_24s1868233564x1858628873(a_0, a_1, a_2, a_3)); heff_drop(v_lenient_241); r_; });
        V f_ = v_t_2428;
        args[0] = v_st_2415;
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      } else {
        heff_drop(v_fix_240);
        heff_drop(v_lenient_241);
        heff_drop(v_x_2417);
        V v_t_2429 = heff_tag_n(TAG_Cons, 2, (V[]){heff_take_field(v_r_243, 0), heff_take_field(v_st_242, 0)});
        V v_t_2430 = heff_tag_n(TAG_Cons, 2, (V[]){heff_get_n(v_r_243, 1, 2), heff_get_n(v_st_242, 1, 2)});
        V v_t_2431 = heff_tag_at_n(v_ru_24x11_2414_24Right, TAG_Right, 1, (V[]){heff_rec_n(2, shape_ops__out, (V[]){v_t_2429, v_t_2430})});
        return heff_tag_at_n(v_ru_24x1_2413_24MkPair, TAG_MkPair, 2, (V[]){v_t_2431, v_st_2415});
      }
    }
    default: return heff_nomatch(v_x11_2414);
    }
  }
  default: return heff_nomatch(v_x1_2413);
  }
}
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str0, 3, "con");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str1, 3, "var");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str2, 7, " := e)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str3, 51, " := ...)` names an argument, after a function: `f (");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str4, 2, "`(");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str5, 2, "b[");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str6, 1, "[");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str7, 3, "Nil");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str8, 4, "Cons");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str9, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str10, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str11, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str12, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str13, 61, "an instance argument is bound before `->`: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str14, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str15, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str16, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str17, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str18, 3, "con");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str19, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str20, 3, "var");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str21, 3, "neg");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str22, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str23, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str24, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str25, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str26, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str27, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str28, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str29, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str30, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str31, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str32, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str33, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str34, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str35, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str36, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str37, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str38, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str39, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str40, 5, "break");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str41, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str42, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str43, 8, "with#arg");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str44, 8, "with#arg");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str45, 8, "with#arg");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str46, 8, "with#arg");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str47, 8, "with#arg");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str48, 8, "with#arg");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str49, 8, "with#arg");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str50, 8, "with#arg");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str51, 8, "with#arg");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str52, 8, "with#arg");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str53, 8, "with#arg");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str54, 8, "with#arg");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str55, 8, "with#arg");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str56, 8, "with#arg");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str57, 8, "with#arg");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str58, 8, "with#arg");
V g_heff_2esyntax_2esurface_2eexprL_lam0(V self, V *args);
V g_heff_2esyntax_2esurface_2eexprL_lam1(V self, V *args);
V g_heff_2esyntax_2esurface_2eexprL_lam2(V self, V *args);
V g_heff_2esyntax_2esurface_2eexprL_lam3(V self, V *args);
V g_heff_2esyntax_2esurface_2eexprL_lam4(V self, V *args);
V g_heff_2esyntax_2esurface_2eexprL_lam6(V self, V *args);
V g_heff_2esyntax_2esurface_2eexprL_lam5(V self, V *args);
V g_heff_2esyntax_2esurface_2eexprL_lam7(V self, V *args);
V g_heff_2esyntax_2esurface_2eexprL_lam8(V self, V *args);
V g_heff_2esyntax_2esurface_2eexprL_lam9(V self, V *args);
V g_heff_2esyntax_2esurface_2eexprL_lam10(V self, V *args);
V g_heff_2esyntax_2esurface_2eexprL_lam11(V self, V *args);
V g_heff_2esyntax_2esurface_2eexprL_lam12(V self, V *args);
V g_heff_2esyntax_2esurface_2eexprL_lam13(V self, V *args);
V g_heff_2esyntax_2esurface_2eexprL_lam14(V self, V *args);
V g_heff_2esyntax_2esurface_2eexprL_lam15(V self, V *args);
V g_heff_2esyntax_2esurface_2eexprL_lam16(V self, V *args);
V g_heff_2esyntax_2esurface_2eexprL_lam17(V self, V *args);
V g_heff_2esyntax_2esurface_2eexprL_lam18(V self, V *args);
V g_heff_2esyntax_2esurface_2eexprL_lam19(V self, V *args);
V g_heff_2esyntax_2esurface_2eexprL_lam20(V self, V *args);
Clo g_heff_2esyntax_2esurface_2eexprL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eexprL_entry, 3, 0};

V g_heff_2esyntax_2esurface_2eexprL(V v_r_240, V v_e0_241, V v_z_242) {
top: ;
  switch (heff_tag_of(v_e0_241)) {
  case TAG_Atom: {
    V v_t_243 = heff_field(v_e0_241, 0);
    V v_ru_24e0_241_24Atom = heff_take_reuse_n(v_e0_241, 1ULL, 1);
    heff_drop_rec(v_r_240, 3);
    if (heff_strEq_c(heff_dup(heff_rfield(v_t_243, 0)), ((V)&g_heff_2esyntax_2esurface_2eexprL_str0))) {
      heff_drop_cell(v_ru_24e0_241_24Atom, 1);
      HEFF_LAST return g_heff_2esyntax_2esurface_2econAtom(v_t_243, NTAG(TAG_Nil), v_z_242);
    } else {
      if (heff_strEq_c(heff_dup(heff_rfield(v_t_243, 0)), ((V)&g_heff_2esyntax_2esurface_2eexprL_str1))) {
        heff_drop_cell(v_ru_24e0_241_24Atom, 1);
        HEFF_LAST return g_heff_2esyntax_2esurface_2evarAtom(v_t_243, NTAG(TAG_Nil), v_z_242);
      } else {
        V v_x_246 = (g_heff_2esyntax_2esurface_2eatomTok(v_t_243));
        return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24e0_241_24Atom, TAG_Right, 1, (V[]){v_x_246}), v_z_242});
      }
    }
  }
  case TAG_EParen: {
    V v_o_247 = heff_field(v_e0_241, 0);
    V v_e_248 = heff_field(v_e0_241, 1);
    V v_c_249 = heff_field(v_e0_241, 2);
    heff_take_n(v_e0_241, 7ULL, 3);
    return ({ V a_0 = v_r_240; V a_1 = v_o_247; V a_2 = v_e_248; V a_3 = v_c_249; V a_4 = v_z_242; V r_ = (g_heff_2esyntax_2esurface_2eparenL(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_o_247); r_; });
  }
  case TAG_Named: {
    V v_o_2410 = heff_field(v_e0_241, 0);
    V v_x_2411 = heff_field(v_e0_241, 1);
    V v_e_2413 = heff_field(v_e0_241, 3);
    V v_c_2414 = heff_field(v_e0_241, 4);
    heff_take_n(v_e0_241, 27ULL, 5);
    V v_m_2415 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_2413}));
    V v_x1_2416 = heff_tr(heff_call(v_m_2415, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x1_2416)) {
    case TAG_MkPair: {
      V v_x11_2417 = heff_field(v_x1_2416, 0);
      V v_st_2418 = heff_field(v_x1_2416, 1);
      V v_ru_24x1_2416_24MkPair = heff_take_reuse_n(v_x1_2416, 3ULL, 2);
      switch (heff_tag_of(v_x11_2417)) {
      case TAG_Left: {
        V v_e_2419 = heff_field(v_x11_2417, 0);
        heff_take_n(v_x11_2417, 1ULL, 1);
        heff_drop_rec(v_o_2410, 9);
        heff_drop_rec(v_x_2411, 9);
        heff_drop_rec(v_c_2414, 9);
        return heff_tag_at_n(v_ru_24x1_2416_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2419}), v_st_2418});
      }
      case TAG_Right: {
        V v_ru_24x11_2417_24Right = heff_take_reuse_n(v_x11_2417, 0ULL, 1);
        V v_t_2421 = heff_strAppend(heff_dup(heff_rfield(v_x_2411, 1)), ((V)&g_heff_2esyntax_2esurface_2eexprL_str2));
        V v_t_2422 = heff_strAppend(heff_get_n(v_x_2411, 1, 9), heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eexprL_str3), v_t_2421));
        V v_t_2423 = heff_tag_n(TAG_EInvalid, 1, (V[]){heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eexprL_str4), v_t_2422)});
        V v_t_2424 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_o_2410, 3, 9), heff_get_n(v_c_2414, 4, 9)});
        V v_t_2425 = heff_tag_at_n(v_ru_24x11_2417_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2423, v_t_2424})});
        return heff_tag_at_n(v_ru_24x1_2416_24MkPair, TAG_MkPair, 2, (V[]){v_t_2425, v_st_2418});
      }
      default: return heff_nomatch(v_x11_2417);
      }
    }
    default: return heff_nomatch(v_x1_2416);
    }
  }
  case TAG_Tup: {
    V v_o_2426 = heff_field(v_e0_241, 0);
    V v_es_2427 = heff_field(v_e0_241, 1);
    V v_c_2429 = heff_field(v_e0_241, 3);
    heff_take_n(v_e0_241, 11ULL, 4);
    if (heff_strEq_c(heff_dup(heff_rfield(v_o_2426, 1)), ((V)&g_heff_2esyntax_2esurface_2eexprL_str5))) {
      V v_m_2432 = (g_prelude_2etraverse_24s499544530x2060473942(heff_clo_n(g_heff_2esyntax_2esurface_2eexprL_lam0, 1, 1, (V[]){v_r_240}), v_es_2427));
      V v_x1_2433 = heff_tr(heff_call(v_m_2432, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_2433)) {
      case TAG_MkPair: {
        V v_x11_2434 = heff_field(v_x1_2433, 0);
        V v_st_2435 = heff_field(v_x1_2433, 1);
        V v_ru_24x1_2433_24MkPair = heff_take_reuse_n(v_x1_2433, 3ULL, 2);
        switch (heff_tag_of(v_x11_2434)) {
        case TAG_Left: {
          V v_e_2436 = heff_field(v_x11_2434, 0);
          heff_take_n(v_x11_2434, 1ULL, 1);
          heff_drop_rec(v_o_2426, 9);
          heff_drop_rec(v_c_2429, 9);
          return heff_tag_at_n(v_ru_24x1_2433_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2436}), v_st_2435});
        }
        case TAG_Right: {
          V v_x_2437 = heff_field(v_x11_2434, 0);
          V v_ru_24x11_2434_24Right = heff_take_reuse_n(v_x11_2434, 1ULL, 1);
          V v_t_2438 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_o_2426, 3, 9), heff_get_n(v_c_2429, 4, 9)});
          V v_t_2439 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_2434_24Right, TAG_EBinary, 1, (V[]){v_x_2437}), v_t_2438});
          return heff_tag_at_n(v_ru_24x1_2433_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2439}), v_st_2435});
        }
        default: return heff_nomatch(v_x11_2434);
        }
      }
      default: return heff_nomatch(v_x1_2433);
      }
    } else {
      if (heff_strEq_c(heff_dup(heff_rfield(v_o_2426, 1)), ((V)&g_heff_2esyntax_2esurface_2eexprL_str6))) {
        V v_m_2441 = (g_prelude_2etraverse_24s499544530x2060473942(heff_get_n(v_r_240, 0, 3), v_es_2427));
        V v_x1_2442 = heff_tr(heff_call(v_m_2441, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_2442)) {
        case TAG_MkPair: {
          V v_x11_2443 = heff_field(v_x1_2442, 0);
          V v_st_2444 = heff_field(v_x1_2442, 1);
          V v_ru_24x1_2442_24MkPair = heff_take_reuse_n(v_x1_2442, 3ULL, 2);
          switch (heff_tag_of(v_x11_2443)) {
          case TAG_Left: {
            V v_e_2445 = heff_field(v_x11_2443, 0);
            heff_take_n(v_x11_2443, 1ULL, 1);
            heff_drop_rec(v_o_2426, 9);
            heff_drop_rec(v_c_2429, 9);
            return heff_tag_at_n(v_ru_24x1_2442_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2445}), v_st_2444});
          }
          case TAG_Right: {
            V v_x_2446 = heff_field(v_x11_2443, 0);
            V v_ru_24x11_2443_24Right = heff_take_reuse_n(v_x11_2443, 1ULL, 1);
            V v_sp_2447 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_o_2426, 3, 9), heff_get_n(v_c_2429, 4, 9)});
            V v_t_2448 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_2443_24Right, TAG_ETag, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2eexprL_str7)}), heff_dup(v_sp_2447)});
            V v_x_2453 = ({ V a_0 = heff_clo_n(g_heff_2esyntax_2esurface_2eexprL_lam1, 2, 1, (V[]){v_sp_2447}); V a_1 = v_t_2448; V a_2 = v_x_2446; V r_ = heff_tr(g_heff_2esyntax_2esurface_2efoldr(a_0, a_1, a_2)); heff_drop(v_x_2446); r_; });
            return heff_tag_at_n(v_ru_24x1_2442_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2453}), v_st_2444});
          }
          default: return heff_nomatch(v_x11_2443);
          }
        }
        default: return heff_nomatch(v_x1_2442);
        }
      } else {
        V v_m_2454 = (g_prelude_2etraverse_24s499544530x2060473942(heff_get_n(v_r_240, 0, 3), v_es_2427));
        V v_x1_2455 = heff_tr(heff_call(v_m_2454, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_2455)) {
        case TAG_MkPair: {
          V v_x11_2456 = heff_field(v_x1_2455, 0);
          V v_st_2457 = heff_field(v_x1_2455, 1);
          V v_ru_24x1_2455_24MkPair = heff_take_reuse_n(v_x1_2455, 3ULL, 2);
          switch (heff_tag_of(v_x11_2456)) {
          case TAG_Left: {
            V v_e_2458 = heff_field(v_x11_2456, 0);
            heff_take_n(v_x11_2456, 1ULL, 1);
            heff_drop_rec(v_o_2426, 9);
            heff_drop_rec(v_c_2429, 9);
            return heff_tag_at_n(v_ru_24x1_2455_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2458}), v_st_2457});
          }
          case TAG_Right: {
            V v_x_2459 = heff_field(v_x11_2456, 0);
            V v_ru_24x11_2456_24Right = heff_take_reuse_n(v_x11_2456, 1ULL, 1);
            V v_t_2460 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_o_2426, 3, 9), heff_get_n(v_c_2429, 4, 9)});
            V v_t_2461 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_2456_24Right, TAG_ETuple, 1, (V[]){v_x_2459}), v_t_2460});
            return heff_tag_at_n(v_ru_24x1_2455_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2461}), v_st_2457});
          }
          default: return heff_nomatch(v_x11_2456);
          }
        }
        default: return heff_nomatch(v_x1_2455);
        }
      }
    }
  }
  case TAG_Seg: {
    heff_drop_rec(v_r_240, 3);
    V v_t_2465 = (g_heff_2esyntax_2ecst_2efirstE(v_e0_241));
    V v_t_2466 = ({ V a_0 = v_e0_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e0_241, 3); r_; });
    V v_t_2467 = heff_strAppend(heff_get_n(v_t_2466, 1, 9), ((V)&g_heff_2esyntax_2esurface_2eexprL_str9));
    V v_msg_2468 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eexprL_str10), v_t_2467);
    V v_t_2469 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_2465, 3), heff_get_n(v_t_2465, 4, 9)});
    V v_t_2470 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_2468, v_t_2469, NTAG(TAG_Nothing)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2470}), v_z_242});
  }
  case TAG_Braces: {
    V v_o_2471 = heff_field(v_e0_241, 0);
    V v_fs_2472 = heff_field(v_e0_241, 1);
    V v_c_2474 = heff_field(v_e0_241, 3);
    heff_take_n(v_e0_241, 11ULL, 4);
    return (g_heff_2esyntax_2esurface_2ebracesL(v_r_240, v_o_2471, v_fs_2472, v_c_2474, v_z_242));
  }
  case TAG_Update: {
    V v_o_2475 = heff_field(v_e0_241, 0);
    V v_rec_2476 = heff_field(v_e0_241, 1);
    V v_fs_2478 = heff_field(v_e0_241, 3);
    V v_c_2480 = heff_field(v_e0_241, 5);
    heff_take_n(v_e0_241, 43ULL, 6);
    V v_m_2481 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_rec_2476}));
    V v_x1_2482 = heff_tr(heff_call(v_m_2481, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x1_2482)) {
    case TAG_MkPair: {
      V v_x11_2483 = heff_field(v_x1_2482, 0);
      V v_st_2484 = heff_field(v_x1_2482, 1);
      V v_ru_24x1_2482_24MkPair = heff_take_reuse_n(v_x1_2482, 3ULL, 2);
      switch (heff_tag_of(v_x11_2483)) {
      case TAG_Left: {
        V v_e_2485 = heff_field(v_x11_2483, 0);
        heff_take_n(v_x11_2483, 1ULL, 1);
        heff_drop_rec(v_r_240, 3);
        heff_drop_rec(v_o_2475, 9);
        heff_drop(v_fs_2478);
        heff_drop_rec(v_c_2480, 9);
        return heff_tag_at_n(v_ru_24x1_2482_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2485}), v_st_2484});
      }
      case TAG_Right: {
        V v_x_2486 = heff_field(v_x11_2483, 0);
        heff_take_n(v_x11_2483, 1ULL, 1);
        V v_m_2488 = (g_prelude_2etraverse_24s499544530x2060473942(heff_clo_n(g_heff_2esyntax_2esurface_2eexprL_lam2, 1, 1, (V[]){v_r_240}), v_fs_2478));
        V v_x1_2489 = heff_tr(heff_call(v_m_2488, 1, (V[]){v_st_2484}));
        switch (heff_tag_of(v_x1_2489)) {
        case TAG_MkPair: {
          V v_x11_2490 = heff_field(v_x1_2489, 0);
          V v_st_2491 = heff_field(v_x1_2489, 1);
          V v_ru_24x1_2489_24MkPair = heff_take_reuse_n(v_x1_2489, 3ULL, 2);
          switch (heff_tag_of(v_x11_2490)) {
          case TAG_Left: {
            V v_e_2492 = heff_field(v_x11_2490, 0);
            heff_take_n(v_x11_2490, 1ULL, 1);
            heff_drop_rec(v_o_2475, 9);
            heff_drop_rec(v_c_2480, 9);
            heff_drop(v_x_2486);
            heff_drop_cell(v_ru_24x1_2489_24MkPair, 2);
            return heff_tag_at_n(v_ru_24x1_2482_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2492}), v_st_2491});
          }
          case TAG_Right: {
            V v_x_2493 = heff_field(v_x11_2490, 0);
            heff_take_n(v_x11_2490, 1ULL, 1);
            V v_t_2494 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_o_2475, 3, 9), heff_get_n(v_c_2480, 4, 9)});
            V v_t_2495 = heff_tag_at_n(v_ru_24x1_2489_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_EUpdate, 2, (V[]){v_x_2486, v_x_2493}), v_t_2494});
            return heff_tag_at_n(v_ru_24x1_2482_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2495}), v_st_2491});
          }
          default: return heff_nomatch(v_x11_2490);
          }
        }
        default: return heff_nomatch(v_x1_2489);
        }
      }
      default: return heff_nomatch(v_x11_2483);
      }
    }
    default: return heff_nomatch(v_x1_2482);
    }
  }
  case TAG_EUSet: {
    heff_drop_rec(v_r_240, 3);
    V v_t_2499 = (g_heff_2esyntax_2ecst_2efirstE(v_e0_241));
    V v_t_24100 = ({ V a_0 = v_e0_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e0_241, 3); r_; });
    V v_t_24101 = heff_strAppend(heff_get_n(v_t_24100, 1, 9), ((V)&g_heff_2esyntax_2esurface_2eexprL_str11));
    V v_msg_24102 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eexprL_str12), v_t_24101);
    V v_t_24103 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_2499, 3), heff_get_n(v_t_2499, 4, 9)});
    V v_t_24104 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24102, v_t_24103, NTAG(TAG_Nothing)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24104}), v_z_242});
  }
  case TAG_InstB: {
    V v_o_24105 = heff_field(v_e0_241, 0);
    V v_d_24107 = heff_field(v_e0_241, 2);
    V v_c_24109 = heff_field(v_e0_241, 4);
    heff_take_n(v_e0_241, 21ULL, 5);
    V v_m_24110 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_d_24107));
    V v_x1_24111 = heff_tr(heff_call(v_m_24110, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x1_24111)) {
    case TAG_MkPair: {
      V v_x11_24112 = heff_field(v_x1_24111, 0);
      V v_st_24113 = heff_field(v_x1_24111, 1);
      V v_ru_24x1_24111_24MkPair = heff_take_reuse_n(v_x1_24111, 3ULL, 2);
      switch (heff_tag_of(v_x11_24112)) {
      case TAG_Left: {
        V v_e_24114 = heff_field(v_x11_24112, 0);
        heff_take_n(v_x11_24112, 1ULL, 1);
        heff_drop_rec(v_o_24105, 9);
        heff_drop_rec(v_c_24109, 9);
        return heff_tag_at_n(v_ru_24x1_24111_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24114}), v_st_24113});
      }
      case TAG_Right: {
        V v_ru_24x11_24112_24Right = heff_take_reuse_n(v_x11_24112, 0ULL, 1);
        V v_t_24116 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_o_24105, 3, 9), heff_get_n(v_c_24109, 4, 9)});
        V v_t_24117 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24112_24Right, TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2eexprL_str13)}), v_t_24116});
        return heff_tag_at_n(v_ru_24x1_24111_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24117}), v_st_24113});
      }
      default: return heff_nomatch(v_x11_24112);
      }
    }
    default: return heff_nomatch(v_x1_24111);
    }
  }
  case TAG_EFSet: {
    heff_drop_rec(v_r_240, 3);
    V v_t_24121 = (g_heff_2esyntax_2ecst_2efirstE(v_e0_241));
    V v_t_24122 = ({ V a_0 = v_e0_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e0_241, 3); r_; });
    V v_t_24123 = heff_strAppend(heff_get_n(v_t_24122, 1, 9), ((V)&g_heff_2esyntax_2esurface_2eexprL_str14));
    V v_msg_24124 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eexprL_str15), v_t_24123);
    V v_t_24125 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24121, 3), heff_get_n(v_t_24121, 4, 9)});
    V v_t_24126 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24124, v_t_24125, NTAG(TAG_Nothing)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24126}), v_z_242});
  }
  case TAG_EFDefault: {
    heff_drop_rec(v_r_240, 3);
    V v_t_24130 = (g_heff_2esyntax_2ecst_2efirstE(v_e0_241));
    V v_t_24131 = ({ V a_0 = v_e0_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e0_241, 3); r_; });
    V v_t_24132 = heff_strAppend(heff_get_n(v_t_24131, 1, 9), ((V)&g_heff_2esyntax_2esurface_2eexprL_str16));
    V v_msg_24133 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eexprL_str17), v_t_24132);
    V v_t_24134 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24130, 3), heff_get_n(v_t_24130, 4, 9)});
    V v_t_24135 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24133, v_t_24134, NTAG(TAG_Nothing)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24135}), v_z_242});
  }
  case TAG_Sum: {
    V v_kw_24136 = heff_field(v_e0_241, 0);
    V v_alts_24138 = heff_field(v_e0_241, 2);
    V v_c_24140 = heff_field(v_e0_241, 4);
    heff_take_n(v_e0_241, 21ULL, 5);
    V v_m_24142 = (g_prelude_2etraverse_24s499544530x2060473942(heff_clo_n(g_heff_2esyntax_2esurface_2eexprL_lam3, 1, 1, (V[]){v_r_240}), v_alts_24138));
    V v_x1_24143 = heff_tr(heff_call(v_m_24142, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x1_24143)) {
    case TAG_MkPair: {
      V v_x11_24144 = heff_field(v_x1_24143, 0);
      V v_st_24145 = heff_field(v_x1_24143, 1);
      V v_ru_24x1_24143_24MkPair = heff_take_reuse_n(v_x1_24143, 3ULL, 2);
      switch (heff_tag_of(v_x11_24144)) {
      case TAG_Left: {
        V v_e_24146 = heff_field(v_x11_24144, 0);
        heff_take_n(v_x11_24144, 1ULL, 1);
        heff_drop_rec(v_kw_24136, 9);
        heff_drop_rec(v_c_24140, 9);
        return heff_tag_at_n(v_ru_24x1_24143_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24146}), v_st_24145});
      }
      case TAG_Right: {
        V v_x_24147 = heff_field(v_x11_24144, 0);
        V v_ru_24x11_24144_24Right = heff_take_reuse_n(v_x11_24144, 1ULL, 1);
        V v_t_24148 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_24136, 3, 9), heff_get_n(v_c_24140, 4, 9)});
        V v_t_24149 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24144_24Right, TAG_ESum, 1, (V[]){v_x_24147}), v_t_24148});
        return heff_tag_at_n(v_ru_24x1_24143_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24149}), v_st_24145});
      }
      default: return heff_nomatch(v_x11_24144);
      }
    }
    default: return heff_nomatch(v_x1_24143);
    }
  }
  case TAG_ECon: {
    V v_c_24150 = heff_field(v_e0_241, 0);
    V v_args_24151 = heff_field(v_e0_241, 1);
    heff_take_n(v_e0_241, 3ULL, 2);
    V v_t_24152 = (g_heff_2esyntax_2esurface_2econL(v_r_240, v_c_24150, v_args_24151));
    return heff_tail(v_t_24152, 1, (V[]){v_z_242});
  }
  case TAG_EField: {
    V v_e_24153 = heff_field(v_e0_241, 0);
    V v_f_24154 = heff_field(v_e0_241, 1);
    V v_ru_24e0_241_24EField = heff_take_reuse_n(v_e0_241, 3ULL, 2);
    HeffT2 v_t_24155 = (g_heff_2esyntax_2esurface_2efieldsOf_24cpr(heff_tag_at_n(v_ru_24e0_241_24EField, TAG_EField, 2, (V[]){v_e_24153, v_f_24154}), NTAG(TAG_Nil)));
    {
      V v_field_24156 = v_t_24155.f[0];
      V v_field_24157 = v_t_24155.f[1];
      V v_it1_24158 = v_field_24156;
      V v_fs_24159 = v_field_24157;
      switch (heff_tag_of(v_it1_24158)) {
      case TAG_Atom: {
        V v_t_24160 = heff_field(v_it1_24158, 0);
        V v_ru_24it1_24158_24Atom = heff_take_reuse_n(v_it1_24158, 1ULL, 1);
        heff_drop_rec(v_r_240, 3);
        if (heff_strEq_c(heff_dup(heff_rfield(v_t_24160, 0)), ((V)&g_heff_2esyntax_2esurface_2eexprL_str18))) {
          heff_drop_cell(v_ru_24it1_24158_24Atom, 1);
          HEFF_LAST return g_heff_2esyntax_2esurface_2econAtom(v_t_24160, v_fs_24159, v_z_242);
        } else {
          if (heff_strEq_c(heff_dup(heff_rfield(v_t_24160, 0)), ((V)&g_heff_2esyntax_2esurface_2eexprL_str19))) {
            heff_drop_cell(v_ru_24it1_24158_24Atom, 1);
            HEFF_LAST return g_heff_2esyntax_2esurface_2ekwAtom(v_t_24160, v_fs_24159, v_z_242);
          } else {
            if (heff_strEq_c(heff_dup(heff_rfield(v_t_24160, 0)), ((V)&g_heff_2esyntax_2esurface_2eexprL_str20))) {
              heff_drop_cell(v_ru_24it1_24158_24Atom, 1);
              HEFF_LAST return g_heff_2esyntax_2esurface_2evarAtom(v_t_24160, v_fs_24159, v_z_242);
            } else {
              V v_e_24164 = (g_heff_2esyntax_2esurface_2eatomTok(v_t_24160));
              V v_t_24165 = (g_list_2emap_24s513201124x806973253(v_fs_24159));
              V v_x_24166 = (g_heff_2esyntax_2epresyntax_2eapp(v_e_24164, v_t_24165));
              return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24it1_24158_24Atom, TAG_Right, 1, (V[]){v_x_24166}), v_z_242});
            }
          }
        }
      }
      case TAG_EParen: {
        V v_m_24170 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24158}));
        V v_x1_24171 = heff_tr(heff_call(v_m_24170, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24171)) {
        case TAG_MkPair: {
          V v_x11_24172 = heff_field(v_x1_24171, 0);
          V v_st_24173 = heff_field(v_x1_24171, 1);
          V v_ru_24x1_24171_24MkPair = heff_take_reuse_n(v_x1_24171, 3ULL, 2);
          switch (heff_tag_of(v_x11_24172)) {
          case TAG_Left: {
            V v_e_24174 = heff_field(v_x11_24172, 0);
            heff_take_n(v_x11_24172, 1ULL, 1);
            heff_drop(v_fs_24159);
            return heff_tag_at_n(v_ru_24x1_24171_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24174}), v_st_24173});
          }
          case TAG_Right: {
            V v_x_24175 = heff_field(v_x11_24172, 0);
            heff_take_n(v_x11_24172, 1ULL, 1);
            V v_t_24176 = (g_list_2emap_24s513201124x806973253(v_fs_24159));
            V v_x_24177 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24175, v_t_24176));
            return heff_tag_at_n(v_ru_24x1_24171_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24177}), v_st_24173});
          }
          default: return heff_nomatch(v_x11_24172);
          }
        }
        default: return heff_nomatch(v_x1_24171);
        }
      }
      case TAG_Named: {
        V v_m_24183 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24158}));
        V v_x1_24184 = heff_tr(heff_call(v_m_24183, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24184)) {
        case TAG_MkPair: {
          V v_x11_24185 = heff_field(v_x1_24184, 0);
          V v_st_24186 = heff_field(v_x1_24184, 1);
          V v_ru_24x1_24184_24MkPair = heff_take_reuse_n(v_x1_24184, 3ULL, 2);
          switch (heff_tag_of(v_x11_24185)) {
          case TAG_Left: {
            V v_e_24187 = heff_field(v_x11_24185, 0);
            heff_take_n(v_x11_24185, 1ULL, 1);
            heff_drop(v_fs_24159);
            return heff_tag_at_n(v_ru_24x1_24184_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24187}), v_st_24186});
          }
          case TAG_Right: {
            V v_x_24188 = heff_field(v_x11_24185, 0);
            heff_take_n(v_x11_24185, 1ULL, 1);
            V v_t_24189 = (g_list_2emap_24s513201124x806973253(v_fs_24159));
            V v_x_24190 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24188, v_t_24189));
            return heff_tag_at_n(v_ru_24x1_24184_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24190}), v_st_24186});
          }
          default: return heff_nomatch(v_x11_24185);
          }
        }
        default: return heff_nomatch(v_x1_24184);
        }
      }
      case TAG_Tup: {
        V v_m_24195 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24158}));
        V v_x1_24196 = heff_tr(heff_call(v_m_24195, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24196)) {
        case TAG_MkPair: {
          V v_x11_24197 = heff_field(v_x1_24196, 0);
          V v_st_24198 = heff_field(v_x1_24196, 1);
          V v_ru_24x1_24196_24MkPair = heff_take_reuse_n(v_x1_24196, 3ULL, 2);
          switch (heff_tag_of(v_x11_24197)) {
          case TAG_Left: {
            V v_e_24199 = heff_field(v_x11_24197, 0);
            heff_take_n(v_x11_24197, 1ULL, 1);
            heff_drop(v_fs_24159);
            return heff_tag_at_n(v_ru_24x1_24196_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24199}), v_st_24198});
          }
          case TAG_Right: {
            V v_x_24200 = heff_field(v_x11_24197, 0);
            heff_take_n(v_x11_24197, 1ULL, 1);
            V v_t_24201 = (g_list_2emap_24s513201124x806973253(v_fs_24159));
            V v_x_24202 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24200, v_t_24201));
            return heff_tag_at_n(v_ru_24x1_24196_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24202}), v_st_24198});
          }
          default: return heff_nomatch(v_x11_24197);
          }
        }
        default: return heff_nomatch(v_x1_24196);
        }
      }
      case TAG_Seg: {
        V v_m_24206 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24158}));
        V v_x1_24207 = heff_tr(heff_call(v_m_24206, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24207)) {
        case TAG_MkPair: {
          V v_x11_24208 = heff_field(v_x1_24207, 0);
          V v_st_24209 = heff_field(v_x1_24207, 1);
          V v_ru_24x1_24207_24MkPair = heff_take_reuse_n(v_x1_24207, 3ULL, 2);
          switch (heff_tag_of(v_x11_24208)) {
          case TAG_Left: {
            V v_e_24210 = heff_field(v_x11_24208, 0);
            heff_take_n(v_x11_24208, 1ULL, 1);
            heff_drop(v_fs_24159);
            return heff_tag_at_n(v_ru_24x1_24207_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24210}), v_st_24209});
          }
          case TAG_Right: {
            V v_x_24211 = heff_field(v_x11_24208, 0);
            heff_take_n(v_x11_24208, 1ULL, 1);
            V v_t_24212 = (g_list_2emap_24s513201124x806973253(v_fs_24159));
            V v_x_24213 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24211, v_t_24212));
            return heff_tag_at_n(v_ru_24x1_24207_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24213}), v_st_24209});
          }
          default: return heff_nomatch(v_x11_24208);
          }
        }
        default: return heff_nomatch(v_x1_24207);
        }
      }
      case TAG_Braces: {
        V v_m_24218 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24158}));
        V v_x1_24219 = heff_tr(heff_call(v_m_24218, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24219)) {
        case TAG_MkPair: {
          V v_x11_24220 = heff_field(v_x1_24219, 0);
          V v_st_24221 = heff_field(v_x1_24219, 1);
          V v_ru_24x1_24219_24MkPair = heff_take_reuse_n(v_x1_24219, 3ULL, 2);
          switch (heff_tag_of(v_x11_24220)) {
          case TAG_Left: {
            V v_e_24222 = heff_field(v_x11_24220, 0);
            heff_take_n(v_x11_24220, 1ULL, 1);
            heff_drop(v_fs_24159);
            return heff_tag_at_n(v_ru_24x1_24219_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24222}), v_st_24221});
          }
          case TAG_Right: {
            V v_x_24223 = heff_field(v_x11_24220, 0);
            heff_take_n(v_x11_24220, 1ULL, 1);
            V v_t_24224 = (g_list_2emap_24s513201124x806973253(v_fs_24159));
            V v_x_24225 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24223, v_t_24224));
            return heff_tag_at_n(v_ru_24x1_24219_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24225}), v_st_24221});
          }
          default: return heff_nomatch(v_x11_24220);
          }
        }
        default: return heff_nomatch(v_x1_24219);
        }
      }
      case TAG_Update: {
        V v_m_24232 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24158}));
        V v_x1_24233 = heff_tr(heff_call(v_m_24232, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24233)) {
        case TAG_MkPair: {
          V v_x11_24234 = heff_field(v_x1_24233, 0);
          V v_st_24235 = heff_field(v_x1_24233, 1);
          V v_ru_24x1_24233_24MkPair = heff_take_reuse_n(v_x1_24233, 3ULL, 2);
          switch (heff_tag_of(v_x11_24234)) {
          case TAG_Left: {
            V v_e_24236 = heff_field(v_x11_24234, 0);
            heff_take_n(v_x11_24234, 1ULL, 1);
            heff_drop(v_fs_24159);
            return heff_tag_at_n(v_ru_24x1_24233_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24236}), v_st_24235});
          }
          case TAG_Right: {
            V v_x_24237 = heff_field(v_x11_24234, 0);
            heff_take_n(v_x11_24234, 1ULL, 1);
            V v_t_24238 = (g_list_2emap_24s513201124x806973253(v_fs_24159));
            V v_x_24239 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24237, v_t_24238));
            return heff_tag_at_n(v_ru_24x1_24233_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24239}), v_st_24235});
          }
          default: return heff_nomatch(v_x11_24234);
          }
        }
        default: return heff_nomatch(v_x1_24233);
        }
      }
      case TAG_EUSet: {
        V v_m_24243 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24158}));
        V v_x1_24244 = heff_tr(heff_call(v_m_24243, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24244)) {
        case TAG_MkPair: {
          V v_x11_24245 = heff_field(v_x1_24244, 0);
          V v_st_24246 = heff_field(v_x1_24244, 1);
          V v_ru_24x1_24244_24MkPair = heff_take_reuse_n(v_x1_24244, 3ULL, 2);
          switch (heff_tag_of(v_x11_24245)) {
          case TAG_Left: {
            V v_e_24247 = heff_field(v_x11_24245, 0);
            heff_take_n(v_x11_24245, 1ULL, 1);
            heff_drop(v_fs_24159);
            return heff_tag_at_n(v_ru_24x1_24244_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24247}), v_st_24246});
          }
          case TAG_Right: {
            V v_x_24248 = heff_field(v_x11_24245, 0);
            heff_take_n(v_x11_24245, 1ULL, 1);
            V v_t_24249 = (g_list_2emap_24s513201124x806973253(v_fs_24159));
            V v_x_24250 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24248, v_t_24249));
            return heff_tag_at_n(v_ru_24x1_24244_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24250}), v_st_24246});
          }
          default: return heff_nomatch(v_x11_24245);
          }
        }
        default: return heff_nomatch(v_x1_24244);
        }
      }
      case TAG_InstB: {
        V v_m_24256 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24158}));
        V v_x1_24257 = heff_tr(heff_call(v_m_24256, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24257)) {
        case TAG_MkPair: {
          V v_x11_24258 = heff_field(v_x1_24257, 0);
          V v_st_24259 = heff_field(v_x1_24257, 1);
          V v_ru_24x1_24257_24MkPair = heff_take_reuse_n(v_x1_24257, 3ULL, 2);
          switch (heff_tag_of(v_x11_24258)) {
          case TAG_Left: {
            V v_e_24260 = heff_field(v_x11_24258, 0);
            heff_take_n(v_x11_24258, 1ULL, 1);
            heff_drop(v_fs_24159);
            return heff_tag_at_n(v_ru_24x1_24257_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24260}), v_st_24259});
          }
          case TAG_Right: {
            V v_x_24261 = heff_field(v_x11_24258, 0);
            heff_take_n(v_x11_24258, 1ULL, 1);
            V v_t_24262 = (g_list_2emap_24s513201124x806973253(v_fs_24159));
            V v_x_24263 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24261, v_t_24262));
            return heff_tag_at_n(v_ru_24x1_24257_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24263}), v_st_24259});
          }
          default: return heff_nomatch(v_x11_24258);
          }
        }
        default: return heff_nomatch(v_x1_24257);
        }
      }
      case TAG_EFSet: {
        V v_m_24267 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24158}));
        V v_x1_24268 = heff_tr(heff_call(v_m_24267, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24268)) {
        case TAG_MkPair: {
          V v_x11_24269 = heff_field(v_x1_24268, 0);
          V v_st_24270 = heff_field(v_x1_24268, 1);
          V v_ru_24x1_24268_24MkPair = heff_take_reuse_n(v_x1_24268, 3ULL, 2);
          switch (heff_tag_of(v_x11_24269)) {
          case TAG_Left: {
            V v_e_24271 = heff_field(v_x11_24269, 0);
            heff_take_n(v_x11_24269, 1ULL, 1);
            heff_drop(v_fs_24159);
            return heff_tag_at_n(v_ru_24x1_24268_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24271}), v_st_24270});
          }
          case TAG_Right: {
            V v_x_24272 = heff_field(v_x11_24269, 0);
            heff_take_n(v_x11_24269, 1ULL, 1);
            V v_t_24273 = (g_list_2emap_24s513201124x806973253(v_fs_24159));
            V v_x_24274 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24272, v_t_24273));
            return heff_tag_at_n(v_ru_24x1_24268_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24274}), v_st_24270});
          }
          default: return heff_nomatch(v_x11_24269);
          }
        }
        default: return heff_nomatch(v_x1_24268);
        }
      }
      case TAG_EFDefault: {
        V v_m_24278 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24158}));
        V v_x1_24279 = heff_tr(heff_call(v_m_24278, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24279)) {
        case TAG_MkPair: {
          V v_x11_24280 = heff_field(v_x1_24279, 0);
          V v_st_24281 = heff_field(v_x1_24279, 1);
          V v_ru_24x1_24279_24MkPair = heff_take_reuse_n(v_x1_24279, 3ULL, 2);
          switch (heff_tag_of(v_x11_24280)) {
          case TAG_Left: {
            V v_e_24282 = heff_field(v_x11_24280, 0);
            heff_take_n(v_x11_24280, 1ULL, 1);
            heff_drop(v_fs_24159);
            return heff_tag_at_n(v_ru_24x1_24279_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24282}), v_st_24281});
          }
          case TAG_Right: {
            V v_x_24283 = heff_field(v_x11_24280, 0);
            heff_take_n(v_x11_24280, 1ULL, 1);
            V v_t_24284 = (g_list_2emap_24s513201124x806973253(v_fs_24159));
            V v_x_24285 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24283, v_t_24284));
            return heff_tag_at_n(v_ru_24x1_24279_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24285}), v_st_24281});
          }
          default: return heff_nomatch(v_x11_24280);
          }
        }
        default: return heff_nomatch(v_x1_24279);
        }
      }
      case TAG_Sum: {
        V v_m_24291 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24158}));
        V v_x1_24292 = heff_tr(heff_call(v_m_24291, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24292)) {
        case TAG_MkPair: {
          V v_x11_24293 = heff_field(v_x1_24292, 0);
          V v_st_24294 = heff_field(v_x1_24292, 1);
          V v_ru_24x1_24292_24MkPair = heff_take_reuse_n(v_x1_24292, 3ULL, 2);
          switch (heff_tag_of(v_x11_24293)) {
          case TAG_Left: {
            V v_e_24295 = heff_field(v_x11_24293, 0);
            heff_take_n(v_x11_24293, 1ULL, 1);
            heff_drop(v_fs_24159);
            return heff_tag_at_n(v_ru_24x1_24292_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24295}), v_st_24294});
          }
          case TAG_Right: {
            V v_x_24296 = heff_field(v_x11_24293, 0);
            heff_take_n(v_x11_24293, 1ULL, 1);
            V v_t_24297 = (g_list_2emap_24s513201124x806973253(v_fs_24159));
            V v_x_24298 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24296, v_t_24297));
            return heff_tag_at_n(v_ru_24x1_24292_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24298}), v_st_24294});
          }
          default: return heff_nomatch(v_x11_24293);
          }
        }
        default: return heff_nomatch(v_x1_24292);
        }
      }
      case TAG_ECon: {
        V v_m_24301 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24158}));
        V v_x1_24302 = heff_tr(heff_call(v_m_24301, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24302)) {
        case TAG_MkPair: {
          V v_x11_24303 = heff_field(v_x1_24302, 0);
          V v_st_24304 = heff_field(v_x1_24302, 1);
          V v_ru_24x1_24302_24MkPair = heff_take_reuse_n(v_x1_24302, 3ULL, 2);
          switch (heff_tag_of(v_x11_24303)) {
          case TAG_Left: {
            V v_e_24305 = heff_field(v_x11_24303, 0);
            heff_take_n(v_x11_24303, 1ULL, 1);
            heff_drop(v_fs_24159);
            return heff_tag_at_n(v_ru_24x1_24302_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24305}), v_st_24304});
          }
          case TAG_Right: {
            V v_x_24306 = heff_field(v_x11_24303, 0);
            heff_take_n(v_x11_24303, 1ULL, 1);
            V v_t_24307 = (g_list_2emap_24s513201124x806973253(v_fs_24159));
            V v_x_24308 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24306, v_t_24307));
            return heff_tag_at_n(v_ru_24x1_24302_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24308}), v_st_24304});
          }
          default: return heff_nomatch(v_x11_24303);
          }
        }
        default: return heff_nomatch(v_x1_24302);
        }
      }
      case TAG_EField: {
        V v_m_24311 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24158}));
        V v_x1_24312 = heff_tr(heff_call(v_m_24311, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24312)) {
        case TAG_MkPair: {
          V v_x11_24313 = heff_field(v_x1_24312, 0);
          V v_st_24314 = heff_field(v_x1_24312, 1);
          V v_ru_24x1_24312_24MkPair = heff_take_reuse_n(v_x1_24312, 3ULL, 2);
          switch (heff_tag_of(v_x11_24313)) {
          case TAG_Left: {
            V v_e_24315 = heff_field(v_x11_24313, 0);
            heff_take_n(v_x11_24313, 1ULL, 1);
            heff_drop(v_fs_24159);
            return heff_tag_at_n(v_ru_24x1_24312_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24315}), v_st_24314});
          }
          case TAG_Right: {
            V v_x_24316 = heff_field(v_x11_24313, 0);
            heff_take_n(v_x11_24313, 1ULL, 1);
            V v_t_24317 = (g_list_2emap_24s513201124x806973253(v_fs_24159));
            V v_x_24318 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24316, v_t_24317));
            return heff_tag_at_n(v_ru_24x1_24312_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24318}), v_st_24314});
          }
          default: return heff_nomatch(v_x11_24313);
          }
        }
        default: return heff_nomatch(v_x1_24312);
        }
      }
      case TAG_ENeg: {
        V v_m_24321 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24158}));
        V v_x1_24322 = heff_tr(heff_call(v_m_24321, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24322)) {
        case TAG_MkPair: {
          V v_x11_24323 = heff_field(v_x1_24322, 0);
          V v_st_24324 = heff_field(v_x1_24322, 1);
          V v_ru_24x1_24322_24MkPair = heff_take_reuse_n(v_x1_24322, 3ULL, 2);
          switch (heff_tag_of(v_x11_24323)) {
          case TAG_Left: {
            V v_e_24325 = heff_field(v_x11_24323, 0);
            heff_take_n(v_x11_24323, 1ULL, 1);
            heff_drop(v_fs_24159);
            return heff_tag_at_n(v_ru_24x1_24322_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24325}), v_st_24324});
          }
          case TAG_Right: {
            V v_x_24326 = heff_field(v_x11_24323, 0);
            heff_take_n(v_x11_24323, 1ULL, 1);
            V v_t_24327 = (g_list_2emap_24s513201124x806973253(v_fs_24159));
            V v_x_24328 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24326, v_t_24327));
            return heff_tag_at_n(v_ru_24x1_24322_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24328}), v_st_24324});
          }
          default: return heff_nomatch(v_x11_24323);
          }
        }
        default: return heff_nomatch(v_x1_24322);
        }
      }
      case TAG_ETilde: {
        V v_m_24331 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24158}));
        V v_x1_24332 = heff_tr(heff_call(v_m_24331, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24332)) {
        case TAG_MkPair: {
          V v_x11_24333 = heff_field(v_x1_24332, 0);
          V v_st_24334 = heff_field(v_x1_24332, 1);
          V v_ru_24x1_24332_24MkPair = heff_take_reuse_n(v_x1_24332, 3ULL, 2);
          switch (heff_tag_of(v_x11_24333)) {
          case TAG_Left: {
            V v_e_24335 = heff_field(v_x11_24333, 0);
            heff_take_n(v_x11_24333, 1ULL, 1);
            heff_drop(v_fs_24159);
            return heff_tag_at_n(v_ru_24x1_24332_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24335}), v_st_24334});
          }
          case TAG_Right: {
            V v_x_24336 = heff_field(v_x11_24333, 0);
            heff_take_n(v_x11_24333, 1ULL, 1);
            V v_t_24337 = (g_list_2emap_24s513201124x806973253(v_fs_24159));
            V v_x_24338 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24336, v_t_24337));
            return heff_tag_at_n(v_ru_24x1_24332_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24338}), v_st_24334});
          }
          default: return heff_nomatch(v_x11_24333);
          }
        }
        default: return heff_nomatch(v_x1_24332);
        }
      }
      case TAG_App: {
        V v_m_24341 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24158}));
        V v_x1_24342 = heff_tr(heff_call(v_m_24341, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24342)) {
        case TAG_MkPair: {
          V v_x11_24343 = heff_field(v_x1_24342, 0);
          V v_st_24344 = heff_field(v_x1_24342, 1);
          V v_ru_24x1_24342_24MkPair = heff_take_reuse_n(v_x1_24342, 3ULL, 2);
          switch (heff_tag_of(v_x11_24343)) {
          case TAG_Left: {
            V v_e_24345 = heff_field(v_x11_24343, 0);
            heff_take_n(v_x11_24343, 1ULL, 1);
            heff_drop(v_fs_24159);
            return heff_tag_at_n(v_ru_24x1_24342_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24345}), v_st_24344});
          }
          case TAG_Right: {
            V v_x_24346 = heff_field(v_x11_24343, 0);
            heff_take_n(v_x11_24343, 1ULL, 1);
            V v_t_24347 = (g_list_2emap_24s513201124x806973253(v_fs_24159));
            V v_x_24348 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24346, v_t_24347));
            return heff_tag_at_n(v_ru_24x1_24342_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24348}), v_st_24344});
          }
          default: return heff_nomatch(v_x11_24343);
          }
        }
        default: return heff_nomatch(v_x1_24342);
        }
      }
      case TAG_Op: {
        V v_m_24352 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24158}));
        V v_x1_24353 = heff_tr(heff_call(v_m_24352, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24353)) {
        case TAG_MkPair: {
          V v_x11_24354 = heff_field(v_x1_24353, 0);
          V v_st_24355 = heff_field(v_x1_24353, 1);
          V v_ru_24x1_24353_24MkPair = heff_take_reuse_n(v_x1_24353, 3ULL, 2);
          switch (heff_tag_of(v_x11_24354)) {
          case TAG_Left: {
            V v_e_24356 = heff_field(v_x11_24354, 0);
            heff_take_n(v_x11_24354, 1ULL, 1);
            heff_drop(v_fs_24159);
            return heff_tag_at_n(v_ru_24x1_24353_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24356}), v_st_24355});
          }
          case TAG_Right: {
            V v_x_24357 = heff_field(v_x11_24354, 0);
            heff_take_n(v_x11_24354, 1ULL, 1);
            V v_t_24358 = (g_list_2emap_24s513201124x806973253(v_fs_24159));
            V v_x_24359 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24357, v_t_24358));
            return heff_tag_at_n(v_ru_24x1_24353_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24359}), v_st_24355});
          }
          default: return heff_nomatch(v_x11_24354);
          }
        }
        default: return heff_nomatch(v_x1_24353);
        }
      }
      case TAG_Ops: {
        V v_m_24362 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24158}));
        V v_x1_24363 = heff_tr(heff_call(v_m_24362, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24363)) {
        case TAG_MkPair: {
          V v_x11_24364 = heff_field(v_x1_24363, 0);
          V v_st_24365 = heff_field(v_x1_24363, 1);
          V v_ru_24x1_24363_24MkPair = heff_take_reuse_n(v_x1_24363, 3ULL, 2);
          switch (heff_tag_of(v_x11_24364)) {
          case TAG_Left: {
            V v_e_24366 = heff_field(v_x11_24364, 0);
            heff_take_n(v_x11_24364, 1ULL, 1);
            heff_drop(v_fs_24159);
            return heff_tag_at_n(v_ru_24x1_24363_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24366}), v_st_24365});
          }
          case TAG_Right: {
            V v_x_24367 = heff_field(v_x11_24364, 0);
            heff_take_n(v_x11_24364, 1ULL, 1);
            V v_t_24368 = (g_list_2emap_24s513201124x806973253(v_fs_24159));
            V v_x_24369 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24367, v_t_24368));
            return heff_tag_at_n(v_ru_24x1_24363_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24369}), v_st_24365});
          }
          default: return heff_nomatch(v_x11_24364);
          }
        }
        default: return heff_nomatch(v_x1_24363);
        }
      }
      case TAG_OpRhs: {
        V v_m_24372 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24158}));
        V v_x1_24373 = heff_tr(heff_call(v_m_24372, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24373)) {
        case TAG_MkPair: {
          V v_x11_24374 = heff_field(v_x1_24373, 0);
          V v_st_24375 = heff_field(v_x1_24373, 1);
          V v_ru_24x1_24373_24MkPair = heff_take_reuse_n(v_x1_24373, 3ULL, 2);
          switch (heff_tag_of(v_x11_24374)) {
          case TAG_Left: {
            V v_e_24376 = heff_field(v_x11_24374, 0);
            heff_take_n(v_x11_24374, 1ULL, 1);
            heff_drop(v_fs_24159);
            return heff_tag_at_n(v_ru_24x1_24373_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24376}), v_st_24375});
          }
          case TAG_Right: {
            V v_x_24377 = heff_field(v_x11_24374, 0);
            heff_take_n(v_x11_24374, 1ULL, 1);
            V v_t_24378 = (g_list_2emap_24s513201124x806973253(v_fs_24159));
            V v_x_24379 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24377, v_t_24378));
            return heff_tag_at_n(v_ru_24x1_24373_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24379}), v_st_24375});
          }
          default: return heff_nomatch(v_x11_24374);
          }
        }
        default: return heff_nomatch(v_x1_24373);
        }
      }
      case TAG_Ann: {
        V v_m_24383 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24158}));
        V v_x1_24384 = heff_tr(heff_call(v_m_24383, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24384)) {
        case TAG_MkPair: {
          V v_x11_24385 = heff_field(v_x1_24384, 0);
          V v_st_24386 = heff_field(v_x1_24384, 1);
          V v_ru_24x1_24384_24MkPair = heff_take_reuse_n(v_x1_24384, 3ULL, 2);
          switch (heff_tag_of(v_x11_24385)) {
          case TAG_Left: {
            V v_e_24387 = heff_field(v_x11_24385, 0);
            heff_take_n(v_x11_24385, 1ULL, 1);
            heff_drop(v_fs_24159);
            return heff_tag_at_n(v_ru_24x1_24384_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24387}), v_st_24386});
          }
          case TAG_Right: {
            V v_x_24388 = heff_field(v_x11_24385, 0);
            heff_take_n(v_x11_24385, 1ULL, 1);
            V v_t_24389 = (g_list_2emap_24s513201124x806973253(v_fs_24159));
            V v_x_24390 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24388, v_t_24389));
            return heff_tag_at_n(v_ru_24x1_24384_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24390}), v_st_24386});
          }
          default: return heff_nomatch(v_x11_24385);
          }
        }
        default: return heff_nomatch(v_x1_24384);
        }
      }
      case TAG_BVar: {
        V v_m_24392 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24158}));
        V v_x1_24393 = heff_tr(heff_call(v_m_24392, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24393)) {
        case TAG_MkPair: {
          V v_x11_24394 = heff_field(v_x1_24393, 0);
          V v_st_24395 = heff_field(v_x1_24393, 1);
          V v_ru_24x1_24393_24MkPair = heff_take_reuse_n(v_x1_24393, 3ULL, 2);
          switch (heff_tag_of(v_x11_24394)) {
          case TAG_Left: {
            V v_e_24396 = heff_field(v_x11_24394, 0);
            heff_take_n(v_x11_24394, 1ULL, 1);
            heff_drop(v_fs_24159);
            return heff_tag_at_n(v_ru_24x1_24393_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24396}), v_st_24395});
          }
          case TAG_Right: {
            V v_x_24397 = heff_field(v_x11_24394, 0);
            heff_take_n(v_x11_24394, 1ULL, 1);
            V v_t_24398 = (g_list_2emap_24s513201124x806973253(v_fs_24159));
            V v_x_24399 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24397, v_t_24398));
            return heff_tag_at_n(v_ru_24x1_24393_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24399}), v_st_24395});
          }
          default: return heff_nomatch(v_x11_24394);
          }
        }
        default: return heff_nomatch(v_x1_24393);
        }
      }
      case TAG_BImp: {
        V v_m_24403 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24158}));
        V v_x1_24404 = heff_tr(heff_call(v_m_24403, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24404)) {
        case TAG_MkPair: {
          V v_x11_24405 = heff_field(v_x1_24404, 0);
          V v_st_24406 = heff_field(v_x1_24404, 1);
          V v_ru_24x1_24404_24MkPair = heff_take_reuse_n(v_x1_24404, 3ULL, 2);
          switch (heff_tag_of(v_x11_24405)) {
          case TAG_Left: {
            V v_e_24407 = heff_field(v_x11_24405, 0);
            heff_take_n(v_x11_24405, 1ULL, 1);
            heff_drop(v_fs_24159);
            return heff_tag_at_n(v_ru_24x1_24404_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24407}), v_st_24406});
          }
          case TAG_Right: {
            V v_x_24408 = heff_field(v_x11_24405, 0);
            heff_take_n(v_x11_24405, 1ULL, 1);
            V v_t_24409 = (g_list_2emap_24s513201124x806973253(v_fs_24159));
            V v_x_24410 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24408, v_t_24409));
            return heff_tag_at_n(v_ru_24x1_24404_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24410}), v_st_24406});
          }
          default: return heff_nomatch(v_x11_24405);
          }
        }
        default: return heff_nomatch(v_x1_24404);
        }
      }
      case TAG_BAnn: {
        V v_m_24416 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24158}));
        V v_x1_24417 = heff_tr(heff_call(v_m_24416, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24417)) {
        case TAG_MkPair: {
          V v_x11_24418 = heff_field(v_x1_24417, 0);
          V v_st_24419 = heff_field(v_x1_24417, 1);
          V v_ru_24x1_24417_24MkPair = heff_take_reuse_n(v_x1_24417, 3ULL, 2);
          switch (heff_tag_of(v_x11_24418)) {
          case TAG_Left: {
            V v_e_24420 = heff_field(v_x11_24418, 0);
            heff_take_n(v_x11_24418, 1ULL, 1);
            heff_drop(v_fs_24159);
            return heff_tag_at_n(v_ru_24x1_24417_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24420}), v_st_24419});
          }
          case TAG_Right: {
            V v_x_24421 = heff_field(v_x11_24418, 0);
            heff_take_n(v_x11_24418, 1ULL, 1);
            V v_t_24422 = (g_list_2emap_24s513201124x806973253(v_fs_24159));
            V v_x_24423 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24421, v_t_24422));
            return heff_tag_at_n(v_ru_24x1_24417_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24423}), v_st_24419});
          }
          default: return heff_nomatch(v_x11_24418);
          }
        }
        default: return heff_nomatch(v_x1_24417);
        }
      }
      case TAG_BPat: {
        V v_m_24425 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24158}));
        V v_x1_24426 = heff_tr(heff_call(v_m_24425, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24426)) {
        case TAG_MkPair: {
          V v_x11_24427 = heff_field(v_x1_24426, 0);
          V v_st_24428 = heff_field(v_x1_24426, 1);
          V v_ru_24x1_24426_24MkPair = heff_take_reuse_n(v_x1_24426, 3ULL, 2);
          switch (heff_tag_of(v_x11_24427)) {
          case TAG_Left: {
            V v_e_24429 = heff_field(v_x11_24427, 0);
            heff_take_n(v_x11_24427, 1ULL, 1);
            heff_drop(v_fs_24159);
            return heff_tag_at_n(v_ru_24x1_24426_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24429}), v_st_24428});
          }
          case TAG_Right: {
            V v_x_24430 = heff_field(v_x11_24427, 0);
            heff_take_n(v_x11_24427, 1ULL, 1);
            V v_t_24431 = (g_list_2emap_24s513201124x806973253(v_fs_24159));
            V v_x_24432 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24430, v_t_24431));
            return heff_tag_at_n(v_ru_24x1_24426_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24432}), v_st_24428});
          }
          default: return heff_nomatch(v_x11_24427);
          }
        }
        default: return heff_nomatch(v_x1_24426);
        }
      }
      case TAG_Lam: {
        V v_m_24437 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24158}));
        V v_x1_24438 = heff_tr(heff_call(v_m_24437, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24438)) {
        case TAG_MkPair: {
          V v_x11_24439 = heff_field(v_x1_24438, 0);
          V v_st_24440 = heff_field(v_x1_24438, 1);
          V v_ru_24x1_24438_24MkPair = heff_take_reuse_n(v_x1_24438, 3ULL, 2);
          switch (heff_tag_of(v_x11_24439)) {
          case TAG_Left: {
            V v_e_24441 = heff_field(v_x11_24439, 0);
            heff_take_n(v_x11_24439, 1ULL, 1);
            heff_drop(v_fs_24159);
            return heff_tag_at_n(v_ru_24x1_24438_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24441}), v_st_24440});
          }
          case TAG_Right: {
            V v_x_24442 = heff_field(v_x11_24439, 0);
            heff_take_n(v_x11_24439, 1ULL, 1);
            V v_t_24443 = (g_list_2emap_24s513201124x806973253(v_fs_24159));
            V v_x_24444 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24442, v_t_24443));
            return heff_tag_at_n(v_ru_24x1_24438_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24444}), v_st_24440});
          }
          default: return heff_nomatch(v_x11_24439);
          }
        }
        default: return heff_nomatch(v_x1_24438);
        }
      }
      case TAG_Case: {
        V v_m_24449 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24158}));
        V v_x1_24450 = heff_tr(heff_call(v_m_24449, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24450)) {
        case TAG_MkPair: {
          V v_x11_24451 = heff_field(v_x1_24450, 0);
          V v_st_24452 = heff_field(v_x1_24450, 1);
          V v_ru_24x1_24450_24MkPair = heff_take_reuse_n(v_x1_24450, 3ULL, 2);
          switch (heff_tag_of(v_x11_24451)) {
          case TAG_Left: {
            V v_e_24453 = heff_field(v_x11_24451, 0);
            heff_take_n(v_x11_24451, 1ULL, 1);
            heff_drop(v_fs_24159);
            return heff_tag_at_n(v_ru_24x1_24450_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24453}), v_st_24452});
          }
          case TAG_Right: {
            V v_x_24454 = heff_field(v_x11_24451, 0);
            heff_take_n(v_x11_24451, 1ULL, 1);
            V v_t_24455 = (g_list_2emap_24s513201124x806973253(v_fs_24159));
            V v_x_24456 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24454, v_t_24455));
            return heff_tag_at_n(v_ru_24x1_24450_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24456}), v_st_24452});
          }
          default: return heff_nomatch(v_x11_24451);
          }
        }
        default: return heff_nomatch(v_x1_24450);
        }
      }
      case TAG_EAlt: {
        V v_m_24460 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24158}));
        V v_x1_24461 = heff_tr(heff_call(v_m_24460, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24461)) {
        case TAG_MkPair: {
          V v_x11_24462 = heff_field(v_x1_24461, 0);
          V v_st_24463 = heff_field(v_x1_24461, 1);
          V v_ru_24x1_24461_24MkPair = heff_take_reuse_n(v_x1_24461, 3ULL, 2);
          switch (heff_tag_of(v_x11_24462)) {
          case TAG_Left: {
            V v_e_24464 = heff_field(v_x11_24462, 0);
            heff_take_n(v_x11_24462, 1ULL, 1);
            heff_drop(v_fs_24159);
            return heff_tag_at_n(v_ru_24x1_24461_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24464}), v_st_24463});
          }
          case TAG_Right: {
            V v_x_24465 = heff_field(v_x11_24462, 0);
            heff_take_n(v_x11_24462, 1ULL, 1);
            V v_t_24466 = (g_list_2emap_24s513201124x806973253(v_fs_24159));
            V v_x_24467 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24465, v_t_24466));
            return heff_tag_at_n(v_ru_24x1_24461_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24467}), v_st_24463});
          }
          default: return heff_nomatch(v_x11_24462);
          }
        }
        default: return heff_nomatch(v_x1_24461);
        }
      }
      case TAG_If: {
        V v_m_24474 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24158}));
        V v_x1_24475 = heff_tr(heff_call(v_m_24474, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24475)) {
        case TAG_MkPair: {
          V v_x11_24476 = heff_field(v_x1_24475, 0);
          V v_st_24477 = heff_field(v_x1_24475, 1);
          V v_ru_24x1_24475_24MkPair = heff_take_reuse_n(v_x1_24475, 3ULL, 2);
          switch (heff_tag_of(v_x11_24476)) {
          case TAG_Left: {
            V v_e_24478 = heff_field(v_x11_24476, 0);
            heff_take_n(v_x11_24476, 1ULL, 1);
            heff_drop(v_fs_24159);
            return heff_tag_at_n(v_ru_24x1_24475_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24478}), v_st_24477});
          }
          case TAG_Right: {
            V v_x_24479 = heff_field(v_x11_24476, 0);
            heff_take_n(v_x11_24476, 1ULL, 1);
            V v_t_24480 = (g_list_2emap_24s513201124x806973253(v_fs_24159));
            V v_x_24481 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24479, v_t_24480));
            return heff_tag_at_n(v_ru_24x1_24475_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24481}), v_st_24477});
          }
          default: return heff_nomatch(v_x11_24476);
          }
        }
        default: return heff_nomatch(v_x1_24475);
        }
      }
      case TAG_Do: {
        V v_m_24484 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24158}));
        V v_x1_24485 = heff_tr(heff_call(v_m_24484, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24485)) {
        case TAG_MkPair: {
          V v_x11_24486 = heff_field(v_x1_24485, 0);
          V v_st_24487 = heff_field(v_x1_24485, 1);
          V v_ru_24x1_24485_24MkPair = heff_take_reuse_n(v_x1_24485, 3ULL, 2);
          switch (heff_tag_of(v_x11_24486)) {
          case TAG_Left: {
            V v_e_24488 = heff_field(v_x11_24486, 0);
            heff_take_n(v_x11_24486, 1ULL, 1);
            heff_drop(v_fs_24159);
            return heff_tag_at_n(v_ru_24x1_24485_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24488}), v_st_24487});
          }
          case TAG_Right: {
            V v_x_24489 = heff_field(v_x11_24486, 0);
            heff_take_n(v_x11_24486, 1ULL, 1);
            V v_t_24490 = (g_list_2emap_24s513201124x806973253(v_fs_24159));
            V v_x_24491 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24489, v_t_24490));
            return heff_tag_at_n(v_ru_24x1_24485_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24491}), v_st_24487});
          }
          default: return heff_nomatch(v_x11_24486);
          }
        }
        default: return heff_nomatch(v_x1_24485);
        }
      }
      case TAG_ESBind: {
        V v_m_24495 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24158}));
        V v_x1_24496 = heff_tr(heff_call(v_m_24495, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24496)) {
        case TAG_MkPair: {
          V v_x11_24497 = heff_field(v_x1_24496, 0);
          V v_st_24498 = heff_field(v_x1_24496, 1);
          V v_ru_24x1_24496_24MkPair = heff_take_reuse_n(v_x1_24496, 3ULL, 2);
          switch (heff_tag_of(v_x11_24497)) {
          case TAG_Left: {
            V v_e_24499 = heff_field(v_x11_24497, 0);
            heff_take_n(v_x11_24497, 1ULL, 1);
            heff_drop(v_fs_24159);
            return heff_tag_at_n(v_ru_24x1_24496_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24499}), v_st_24498});
          }
          case TAG_Right: {
            V v_x_24500 = heff_field(v_x11_24497, 0);
            heff_take_n(v_x11_24497, 1ULL, 1);
            V v_t_24501 = (g_list_2emap_24s513201124x806973253(v_fs_24159));
            V v_x_24502 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24500, v_t_24501));
            return heff_tag_at_n(v_ru_24x1_24496_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24502}), v_st_24498});
          }
          default: return heff_nomatch(v_x11_24497);
          }
        }
        default: return heff_nomatch(v_x1_24496);
        }
      }
      case TAG_ELet: {
        V v_m_24509 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24158}));
        V v_x1_24510 = heff_tr(heff_call(v_m_24509, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24510)) {
        case TAG_MkPair: {
          V v_x11_24511 = heff_field(v_x1_24510, 0);
          V v_st_24512 = heff_field(v_x1_24510, 1);
          V v_ru_24x1_24510_24MkPair = heff_take_reuse_n(v_x1_24510, 3ULL, 2);
          switch (heff_tag_of(v_x11_24511)) {
          case TAG_Left: {
            V v_e_24513 = heff_field(v_x11_24511, 0);
            heff_take_n(v_x11_24511, 1ULL, 1);
            heff_drop(v_fs_24159);
            return heff_tag_at_n(v_ru_24x1_24510_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24513}), v_st_24512});
          }
          case TAG_Right: {
            V v_x_24514 = heff_field(v_x11_24511, 0);
            heff_take_n(v_x11_24511, 1ULL, 1);
            V v_t_24515 = (g_list_2emap_24s513201124x806973253(v_fs_24159));
            V v_x_24516 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24514, v_t_24515));
            return heff_tag_at_n(v_ru_24x1_24510_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24516}), v_st_24512});
          }
          default: return heff_nomatch(v_x11_24511);
          }
        }
        default: return heff_nomatch(v_x1_24510);
        }
      }
      case TAG_ELetElse: {
        V v_m_24524 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24158}));
        V v_x1_24525 = heff_tr(heff_call(v_m_24524, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24525)) {
        case TAG_MkPair: {
          V v_x11_24526 = heff_field(v_x1_24525, 0);
          V v_st_24527 = heff_field(v_x1_24525, 1);
          V v_ru_24x1_24525_24MkPair = heff_take_reuse_n(v_x1_24525, 3ULL, 2);
          switch (heff_tag_of(v_x11_24526)) {
          case TAG_Left: {
            V v_e_24528 = heff_field(v_x11_24526, 0);
            heff_take_n(v_x11_24526, 1ULL, 1);
            heff_drop(v_fs_24159);
            return heff_tag_at_n(v_ru_24x1_24525_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24528}), v_st_24527});
          }
          case TAG_Right: {
            V v_x_24529 = heff_field(v_x11_24526, 0);
            heff_take_n(v_x11_24526, 1ULL, 1);
            V v_t_24530 = (g_list_2emap_24s513201124x806973253(v_fs_24159));
            V v_x_24531 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24529, v_t_24530));
            return heff_tag_at_n(v_ru_24x1_24525_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24531}), v_st_24527});
          }
          default: return heff_nomatch(v_x11_24526);
          }
        }
        default: return heff_nomatch(v_x1_24525);
        }
      }
      case TAG_ELetMut: {
        V v_m_24538 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24158}));
        V v_x1_24539 = heff_tr(heff_call(v_m_24538, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24539)) {
        case TAG_MkPair: {
          V v_x11_24540 = heff_field(v_x1_24539, 0);
          V v_st_24541 = heff_field(v_x1_24539, 1);
          V v_ru_24x1_24539_24MkPair = heff_take_reuse_n(v_x1_24539, 3ULL, 2);
          switch (heff_tag_of(v_x11_24540)) {
          case TAG_Left: {
            V v_e_24542 = heff_field(v_x11_24540, 0);
            heff_take_n(v_x11_24540, 1ULL, 1);
            heff_drop(v_fs_24159);
            return heff_tag_at_n(v_ru_24x1_24539_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24542}), v_st_24541});
          }
          case TAG_Right: {
            V v_x_24543 = heff_field(v_x11_24540, 0);
            heff_take_n(v_x11_24540, 1ULL, 1);
            V v_t_24544 = (g_list_2emap_24s513201124x806973253(v_fs_24159));
            V v_x_24545 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24543, v_t_24544));
            return heff_tag_at_n(v_ru_24x1_24539_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24545}), v_st_24541});
          }
          default: return heff_nomatch(v_x11_24540);
          }
        }
        default: return heff_nomatch(v_x1_24539);
        }
      }
      case TAG_EAssign: {
        V v_m_24549 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24158}));
        V v_x1_24550 = heff_tr(heff_call(v_m_24549, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24550)) {
        case TAG_MkPair: {
          V v_x11_24551 = heff_field(v_x1_24550, 0);
          V v_st_24552 = heff_field(v_x1_24550, 1);
          V v_ru_24x1_24550_24MkPair = heff_take_reuse_n(v_x1_24550, 3ULL, 2);
          switch (heff_tag_of(v_x11_24551)) {
          case TAG_Left: {
            V v_e_24553 = heff_field(v_x11_24551, 0);
            heff_take_n(v_x11_24551, 1ULL, 1);
            heff_drop(v_fs_24159);
            return heff_tag_at_n(v_ru_24x1_24550_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24553}), v_st_24552});
          }
          case TAG_Right: {
            V v_x_24554 = heff_field(v_x11_24551, 0);
            heff_take_n(v_x11_24551, 1ULL, 1);
            V v_t_24555 = (g_list_2emap_24s513201124x806973253(v_fs_24159));
            V v_x_24556 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24554, v_t_24555));
            return heff_tag_at_n(v_ru_24x1_24550_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24556}), v_st_24552});
          }
          default: return heff_nomatch(v_x11_24551);
          }
        }
        default: return heff_nomatch(v_x1_24550);
        }
      }
      case TAG_EWhile: {
        V v_m_24561 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24158}));
        V v_x1_24562 = heff_tr(heff_call(v_m_24561, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24562)) {
        case TAG_MkPair: {
          V v_x11_24563 = heff_field(v_x1_24562, 0);
          V v_st_24564 = heff_field(v_x1_24562, 1);
          V v_ru_24x1_24562_24MkPair = heff_take_reuse_n(v_x1_24562, 3ULL, 2);
          switch (heff_tag_of(v_x11_24563)) {
          case TAG_Left: {
            V v_e_24565 = heff_field(v_x11_24563, 0);
            heff_take_n(v_x11_24563, 1ULL, 1);
            heff_drop(v_fs_24159);
            return heff_tag_at_n(v_ru_24x1_24562_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24565}), v_st_24564});
          }
          case TAG_Right: {
            V v_x_24566 = heff_field(v_x11_24563, 0);
            heff_take_n(v_x11_24563, 1ULL, 1);
            V v_t_24567 = (g_list_2emap_24s513201124x806973253(v_fs_24159));
            V v_x_24568 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24566, v_t_24567));
            return heff_tag_at_n(v_ru_24x1_24562_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24568}), v_st_24564});
          }
          default: return heff_nomatch(v_x11_24563);
          }
        }
        default: return heff_nomatch(v_x1_24562);
        }
      }
      case TAG_EFor: {
        V v_m_24575 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24158}));
        V v_x1_24576 = heff_tr(heff_call(v_m_24575, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24576)) {
        case TAG_MkPair: {
          V v_x11_24577 = heff_field(v_x1_24576, 0);
          V v_st_24578 = heff_field(v_x1_24576, 1);
          V v_ru_24x1_24576_24MkPair = heff_take_reuse_n(v_x1_24576, 3ULL, 2);
          switch (heff_tag_of(v_x11_24577)) {
          case TAG_Left: {
            V v_e_24579 = heff_field(v_x11_24577, 0);
            heff_take_n(v_x11_24577, 1ULL, 1);
            heff_drop(v_fs_24159);
            return heff_tag_at_n(v_ru_24x1_24576_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24579}), v_st_24578});
          }
          case TAG_Right: {
            V v_x_24580 = heff_field(v_x11_24577, 0);
            heff_take_n(v_x11_24577, 1ULL, 1);
            V v_t_24581 = (g_list_2emap_24s513201124x806973253(v_fs_24159));
            V v_x_24582 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24580, v_t_24581));
            return heff_tag_at_n(v_ru_24x1_24576_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24582}), v_st_24578});
          }
          default: return heff_nomatch(v_x11_24577);
          }
        }
        default: return heff_nomatch(v_x1_24576);
        }
      }
      case TAG_EJump: {
        V v_m_24584 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24158}));
        V v_x1_24585 = heff_tr(heff_call(v_m_24584, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24585)) {
        case TAG_MkPair: {
          V v_x11_24586 = heff_field(v_x1_24585, 0);
          V v_st_24587 = heff_field(v_x1_24585, 1);
          V v_ru_24x1_24585_24MkPair = heff_take_reuse_n(v_x1_24585, 3ULL, 2);
          switch (heff_tag_of(v_x11_24586)) {
          case TAG_Left: {
            V v_e_24588 = heff_field(v_x11_24586, 0);
            heff_take_n(v_x11_24586, 1ULL, 1);
            heff_drop(v_fs_24159);
            return heff_tag_at_n(v_ru_24x1_24585_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24588}), v_st_24587});
          }
          case TAG_Right: {
            V v_x_24589 = heff_field(v_x11_24586, 0);
            heff_take_n(v_x11_24586, 1ULL, 1);
            V v_t_24590 = (g_list_2emap_24s513201124x806973253(v_fs_24159));
            V v_x_24591 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24589, v_t_24590));
            return heff_tag_at_n(v_ru_24x1_24585_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24591}), v_st_24587});
          }
          default: return heff_nomatch(v_x11_24586);
          }
        }
        default: return heff_nomatch(v_x1_24585);
        }
      }
      case TAG_EReturn: {
        V v_m_24594 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24158}));
        V v_x1_24595 = heff_tr(heff_call(v_m_24594, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24595)) {
        case TAG_MkPair: {
          V v_x11_24596 = heff_field(v_x1_24595, 0);
          V v_st_24597 = heff_field(v_x1_24595, 1);
          V v_ru_24x1_24595_24MkPair = heff_take_reuse_n(v_x1_24595, 3ULL, 2);
          switch (heff_tag_of(v_x11_24596)) {
          case TAG_Left: {
            V v_e_24598 = heff_field(v_x11_24596, 0);
            heff_take_n(v_x11_24596, 1ULL, 1);
            heff_drop(v_fs_24159);
            return heff_tag_at_n(v_ru_24x1_24595_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24598}), v_st_24597});
          }
          case TAG_Right: {
            V v_x_24599 = heff_field(v_x11_24596, 0);
            heff_take_n(v_x11_24596, 1ULL, 1);
            V v_t_24600 = (g_list_2emap_24s513201124x806973253(v_fs_24159));
            V v_x_24601 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24599, v_t_24600));
            return heff_tag_at_n(v_ru_24x1_24595_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24601}), v_st_24597});
          }
          default: return heff_nomatch(v_x11_24596);
          }
        }
        default: return heff_nomatch(v_x1_24595);
        }
      }
      case TAG_ENest: {
        V v_m_24606 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24158}));
        V v_x1_24607 = heff_tr(heff_call(v_m_24606, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24607)) {
        case TAG_MkPair: {
          V v_x11_24608 = heff_field(v_x1_24607, 0);
          V v_st_24609 = heff_field(v_x1_24607, 1);
          V v_ru_24x1_24607_24MkPair = heff_take_reuse_n(v_x1_24607, 3ULL, 2);
          switch (heff_tag_of(v_x11_24608)) {
          case TAG_Left: {
            V v_e_24610 = heff_field(v_x11_24608, 0);
            heff_take_n(v_x11_24608, 1ULL, 1);
            heff_drop(v_fs_24159);
            return heff_tag_at_n(v_ru_24x1_24607_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24610}), v_st_24609});
          }
          case TAG_Right: {
            V v_x_24611 = heff_field(v_x11_24608, 0);
            heff_take_n(v_x11_24608, 1ULL, 1);
            V v_t_24612 = (g_list_2emap_24s513201124x806973253(v_fs_24159));
            V v_x_24613 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24611, v_t_24612));
            return heff_tag_at_n(v_ru_24x1_24607_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24613}), v_st_24609});
          }
          default: return heff_nomatch(v_x11_24608);
          }
        }
        default: return heff_nomatch(v_x1_24607);
        }
      }
      case TAG_IfThen: {
        V v_m_24618 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24158}));
        V v_x1_24619 = heff_tr(heff_call(v_m_24618, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24619)) {
        case TAG_MkPair: {
          V v_x11_24620 = heff_field(v_x1_24619, 0);
          V v_st_24621 = heff_field(v_x1_24619, 1);
          V v_ru_24x1_24619_24MkPair = heff_take_reuse_n(v_x1_24619, 3ULL, 2);
          switch (heff_tag_of(v_x11_24620)) {
          case TAG_Left: {
            V v_e_24622 = heff_field(v_x11_24620, 0);
            heff_take_n(v_x11_24620, 1ULL, 1);
            heff_drop(v_fs_24159);
            return heff_tag_at_n(v_ru_24x1_24619_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24622}), v_st_24621});
          }
          case TAG_Right: {
            V v_x_24623 = heff_field(v_x11_24620, 0);
            heff_take_n(v_x11_24620, 1ULL, 1);
            V v_t_24624 = (g_list_2emap_24s513201124x806973253(v_fs_24159));
            V v_x_24625 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24623, v_t_24624));
            return heff_tag_at_n(v_ru_24x1_24619_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24625}), v_st_24621});
          }
          default: return heff_nomatch(v_x11_24620);
          }
        }
        default: return heff_nomatch(v_x1_24619);
        }
      }
      case TAG_ETry: {
        V v_m_24630 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24158}));
        V v_x1_24631 = heff_tr(heff_call(v_m_24630, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24631)) {
        case TAG_MkPair: {
          V v_x11_24632 = heff_field(v_x1_24631, 0);
          V v_st_24633 = heff_field(v_x1_24631, 1);
          V v_ru_24x1_24631_24MkPair = heff_take_reuse_n(v_x1_24631, 3ULL, 2);
          switch (heff_tag_of(v_x11_24632)) {
          case TAG_Left: {
            V v_e_24634 = heff_field(v_x11_24632, 0);
            heff_take_n(v_x11_24632, 1ULL, 1);
            heff_drop(v_fs_24159);
            return heff_tag_at_n(v_ru_24x1_24631_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24634}), v_st_24633});
          }
          case TAG_Right: {
            V v_x_24635 = heff_field(v_x11_24632, 0);
            heff_take_n(v_x11_24632, 1ULL, 1);
            V v_t_24636 = (g_list_2emap_24s513201124x806973253(v_fs_24159));
            V v_x_24637 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24635, v_t_24636));
            return heff_tag_at_n(v_ru_24x1_24631_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24637}), v_st_24633});
          }
          default: return heff_nomatch(v_x11_24632);
          }
        }
        default: return heff_nomatch(v_x1_24631);
        }
      }
      case TAG_ECatch: {
        V v_m_24642 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24158}));
        V v_x1_24643 = heff_tr(heff_call(v_m_24642, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24643)) {
        case TAG_MkPair: {
          V v_x11_24644 = heff_field(v_x1_24643, 0);
          V v_st_24645 = heff_field(v_x1_24643, 1);
          V v_ru_24x1_24643_24MkPair = heff_take_reuse_n(v_x1_24643, 3ULL, 2);
          switch (heff_tag_of(v_x11_24644)) {
          case TAG_Left: {
            V v_e_24646 = heff_field(v_x11_24644, 0);
            heff_take_n(v_x11_24644, 1ULL, 1);
            heff_drop(v_fs_24159);
            return heff_tag_at_n(v_ru_24x1_24643_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24646}), v_st_24645});
          }
          case TAG_Right: {
            V v_x_24647 = heff_field(v_x11_24644, 0);
            heff_take_n(v_x11_24644, 1ULL, 1);
            V v_t_24648 = (g_list_2emap_24s513201124x806973253(v_fs_24159));
            V v_x_24649 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24647, v_t_24648));
            return heff_tag_at_n(v_ru_24x1_24643_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24649}), v_st_24645});
          }
          default: return heff_nomatch(v_x11_24644);
          }
        }
        default: return heff_nomatch(v_x1_24643);
        }
      }
      case TAG_EWith: {
        V v_m_24656 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24158}));
        V v_x1_24657 = heff_tr(heff_call(v_m_24656, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24657)) {
        case TAG_MkPair: {
          V v_x11_24658 = heff_field(v_x1_24657, 0);
          V v_st_24659 = heff_field(v_x1_24657, 1);
          V v_ru_24x1_24657_24MkPair = heff_take_reuse_n(v_x1_24657, 3ULL, 2);
          switch (heff_tag_of(v_x11_24658)) {
          case TAG_Left: {
            V v_e_24660 = heff_field(v_x11_24658, 0);
            heff_take_n(v_x11_24658, 1ULL, 1);
            heff_drop(v_fs_24159);
            return heff_tag_at_n(v_ru_24x1_24657_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24660}), v_st_24659});
          }
          case TAG_Right: {
            V v_x_24661 = heff_field(v_x11_24658, 0);
            heff_take_n(v_x11_24658, 1ULL, 1);
            V v_t_24662 = (g_list_2emap_24s513201124x806973253(v_fs_24159));
            V v_x_24663 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24661, v_t_24662));
            return heff_tag_at_n(v_ru_24x1_24657_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24663}), v_st_24659});
          }
          default: return heff_nomatch(v_x11_24658);
          }
        }
        default: return heff_nomatch(v_x1_24657);
        }
      }
      default: return heff_nomatch(v_it1_24158);
      }
    }
  }
  case TAG_ENeg: {
    V v_m_24664 = heff_field(v_e0_241, 0);
    V v_e_24665 = heff_field(v_e0_241, 1);
    V v_ru_24e0_241_24ENeg = heff_take_reuse_n(v_e0_241, 3ULL, 2);
    V v_m_24666 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_24665}));
    V v_x1_24667 = heff_tr(heff_call(v_m_24666, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x1_24667)) {
    case TAG_MkPair: {
      V v_x11_24668 = heff_field(v_x1_24667, 0);
      V v_st_24669 = heff_field(v_x1_24667, 1);
      V v_ru_24x1_24667_24MkPair = heff_take_reuse_n(v_x1_24667, 3ULL, 2);
      switch (heff_tag_of(v_x11_24668)) {
      case TAG_Left: {
        V v_e_24670 = heff_field(v_x11_24668, 0);
        heff_take_n(v_x11_24668, 1ULL, 1);
        heff_drop_rec(v_m_24664, 9);
        heff_drop_cell(v_ru_24x1_24667_24MkPair, 2);
        return heff_tag_at_n(v_ru_24e0_241_24ENeg, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24670}), v_st_24669});
      }
      case TAG_Right: {
        V v_x_24671 = heff_field(v_x11_24668, 0);
        heff_take_n(v_x11_24668, 1ULL, 1);
        V v_t_24672 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_m_24664, 3), heff_get_n(v_m_24664, 4, 9)});
        V v_t_24673 = heff_tag_at_n(v_ru_24e0_241_24ENeg, TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2eexprL_str21)}), v_t_24672});
        V v_t_24674 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_24671, NTAG(TAG_Nil)});
        V v_x_24675 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_24673, v_t_24674));
        return heff_tag_at_n(v_ru_24x1_24667_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24675}), v_st_24669});
      }
      default: return heff_nomatch(v_x11_24668);
      }
    }
    default: return heff_nomatch(v_x1_24667);
    }
  }
  case TAG_ETilde: {
    V v_m_24676 = heff_field(v_e0_241, 0);
    V v_e_24677 = heff_field(v_e0_241, 1);
    V v_ru_24e0_241_24ETilde = heff_take_reuse_n(v_e0_241, 3ULL, 2);
    V v_m_24678 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_e_24677)}));
    V v_x1_24679 = heff_tr(heff_call(v_m_24678, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x1_24679)) {
    case TAG_MkPair: {
      V v_x11_24680 = heff_field(v_x1_24679, 0);
      V v_st_24681 = heff_field(v_x1_24679, 1);
      V v_ru_24x1_24679_24MkPair = heff_take_reuse_n(v_x1_24679, 3ULL, 2);
      switch (heff_tag_of(v_x11_24680)) {
      case TAG_Left: {
        V v_e_24682 = heff_field(v_x11_24680, 0);
        heff_take_n(v_x11_24680, 1ULL, 1);
        heff_drop_rec(v_m_24676, 9);
        heff_drop(v_e_24677);
        heff_drop_cell(v_ru_24x1_24679_24MkPair, 2);
        return heff_tag_at_n(v_ru_24e0_241_24ETilde, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24682}), v_st_24681});
      }
      case TAG_Right: {
        V v_x_24683 = heff_field(v_x11_24680, 0);
        heff_take_n(v_x11_24680, 1ULL, 1);
        V v_t_24684 = (g_heff_2esyntax_2ecst_2elastE(v_e_24677));
        V v_e_24685 = heff_get_n(v_t_24684, 4, 9);
        V v_t_24686 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_m_24676, 3, 9), v_e_24685});
        V v_x_24687 = heff_tag_at_n(v_ru_24e0_241_24ETilde, TAG_At, 2, (V[]){heff_tag_n(TAG_ELazy, 1, (V[]){v_x_24683}), v_t_24686});
        return heff_tag_at_n(v_ru_24x1_24679_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24687}), v_st_24681});
      }
      default: return heff_nomatch(v_x11_24680);
      }
    }
    default: return heff_nomatch(v_x1_24679);
    }
  }
  case TAG_App: {
    V v_h_24688 = heff_field(v_e0_241, 0);
    V v_args_24689 = heff_field(v_e0_241, 1);
    V v_ru_24e0_241_24App = heff_take_reuse_n(v_e0_241, 3ULL, 2);
    V v_m_24690 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_h_24688}));
    V v_x1_24691 = heff_tr(heff_call(v_m_24690, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x1_24691)) {
    case TAG_MkPair: {
      V v_x11_24692 = heff_field(v_x1_24691, 0);
      V v_st_24693 = heff_field(v_x1_24691, 1);
      heff_take_n(v_x1_24691, 3ULL, 2);
      switch (heff_tag_of(v_x11_24692)) {
      case TAG_Left: {
        V v_e_24694 = heff_field(v_x11_24692, 0);
        heff_take_n(v_x11_24692, 1ULL, 1);
        heff_drop_rec(v_r_240, 3);
        heff_drop(v_args_24689);
        return heff_tag_at_n(v_ru_24e0_241_24App, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24694}), v_st_24693});
      }
      case TAG_Right: {
        V v_x_24695 = heff_field(v_x11_24692, 0);
        heff_take_n(v_x11_24692, 1ULL, 1);
        V v_m_24697 = (g_prelude_2etraverse_24s499544530x2060473942(heff_clo_n(g_heff_2esyntax_2esurface_2eexprL_lam4, 1, 1, (V[]){v_r_240}), v_args_24689));
        V v_x1_24698 = heff_tr(heff_call(v_m_24697, 1, (V[]){v_st_24693}));
        switch (heff_tag_of(v_x1_24698)) {
        case TAG_MkPair: {
          V v_x11_24699 = heff_field(v_x1_24698, 0);
          V v_st_24700 = heff_field(v_x1_24698, 1);
          heff_take_n(v_x1_24698, 3ULL, 2);
          switch (heff_tag_of(v_x11_24699)) {
          case TAG_Left: {
            V v_e_24701 = heff_field(v_x11_24699, 0);
            heff_take_n(v_x11_24699, 1ULL, 1);
            heff_drop(v_x_24695);
            return heff_tag_at_n(v_ru_24e0_241_24App, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24701}), v_st_24700});
          }
          case TAG_Right: {
            V v_x_24702 = heff_field(v_x11_24699, 0);
            heff_take_n(v_x11_24699, 1ULL, 1);
            V v_x_24703 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24695, v_x_24702));
            return heff_tag_at_n(v_ru_24e0_241_24App, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24703}), v_st_24700});
          }
          default: return heff_nomatch(v_x11_24699);
          }
        }
        default: return heff_nomatch(v_x1_24698);
        }
      }
      default: return heff_nomatch(v_x11_24692);
      }
    }
    default: return heff_nomatch(v_x1_24691);
    }
  }
  case TAG_Op: {
    V v_a_24704 = heff_field(v_e0_241, 0);
    V v_op_24705 = heff_field(v_e0_241, 1);
    V v_b_24706 = heff_field(v_e0_241, 2);
    heff_take_n(v_e0_241, 7ULL, 3);
    return (g_heff_2esyntax_2esurface_2eopL(v_r_240, v_a_24704, v_op_24705, v_b_24706, v_z_242));
  }
  case TAG_Ops: {
    V v_a_24707 = heff_field(v_e0_241, 0);
    V v_rest_24708 = heff_field(v_e0_241, 1);
    V v_ru_24e0_241_24Ops = heff_take_reuse_n(v_e0_241, 3ULL, 2);
    V v_m_24709 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_24707}));
    V v_x1_24710 = heff_tr(heff_call(v_m_24709, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x1_24710)) {
    case TAG_MkPair: {
      V v_x11_24711 = heff_field(v_x1_24710, 0);
      V v_st_24712 = heff_field(v_x1_24710, 1);
      heff_take_n(v_x1_24710, 3ULL, 2);
      switch (heff_tag_of(v_x11_24711)) {
      case TAG_Left: {
        V v_e_24713 = heff_field(v_x11_24711, 0);
        heff_take_n(v_x11_24711, 1ULL, 1);
        heff_drop_rec(v_r_240, 3);
        heff_drop(v_rest_24708);
        return heff_tag_at_n(v_ru_24e0_241_24Ops, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24713}), v_st_24712});
      }
      case TAG_Right: {
        V v_x_24714 = heff_field(v_x11_24711, 0);
        heff_take_n(v_x11_24711, 1ULL, 1);
        V v_m_24729 = (g_prelude_2etraverse_24s499544530x2060473942(heff_clo_n(g_heff_2esyntax_2esurface_2eexprL_lam5, 1, 1, (V[]){v_r_240}), v_rest_24708));
        V v_x1_24730 = heff_tr(heff_call(v_m_24729, 1, (V[]){v_st_24712}));
        switch (heff_tag_of(v_x1_24730)) {
        case TAG_MkPair: {
          V v_x11_24731 = heff_field(v_x1_24730, 0);
          V v_st_24732 = heff_field(v_x1_24730, 1);
          heff_take_n(v_x1_24730, 3ULL, 2);
          switch (heff_tag_of(v_x11_24731)) {
          case TAG_Left: {
            V v_e_24733 = heff_field(v_x11_24731, 0);
            heff_take_n(v_x11_24731, 1ULL, 1);
            heff_drop(v_x_24714);
            return heff_tag_at_n(v_ru_24e0_241_24Ops, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24733}), v_st_24732});
          }
          case TAG_Right: {
            V v_x_24734 = heff_field(v_x11_24731, 0);
            heff_take_n(v_x11_24731, 1ULL, 1);
            heff_drop_cell(v_ru_24e0_241_24Ops, 2);
            HEFF_LAST return g_heff_2esyntax_2esurface_2eresolve_24s1832151779x1448561609(v_x_24714, v_x_24734, v_st_24732);
          }
          default: return heff_nomatch(v_x11_24731);
          }
        }
        default: return heff_nomatch(v_x1_24730);
        }
      }
      default: return heff_nomatch(v_x11_24711);
      }
    }
    default: return heff_nomatch(v_x1_24710);
    }
  }
  case TAG_OpRhs: {
    heff_drop_rec(v_r_240, 3);
    V v_t_24737 = (g_heff_2esyntax_2ecst_2efirstE(v_e0_241));
    V v_t_24738 = ({ V a_0 = v_e0_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e0_241, 2); r_; });
    V v_t_24739 = heff_strAppend(heff_get_n(v_t_24738, 1, 9), ((V)&g_heff_2esyntax_2esurface_2eexprL_str22));
    V v_msg_24740 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eexprL_str23), v_t_24739);
    V v_t_24741 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24737, 3), heff_get_n(v_t_24737, 4, 9)});
    V v_t_24742 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24740, v_t_24741, NTAG(TAG_Nothing)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24742}), v_z_242});
  }
  case TAG_Ann: {
    V v_e_24743 = heff_field(v_e0_241, 0);
    V v_ty_24745 = heff_field(v_e0_241, 2);
    heff_take_n(v_e0_241, 5ULL, 3);
    V v_m_24746 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e_24743}));
    V v_x1_24747 = heff_tr(heff_call(v_m_24746, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x1_24747)) {
    case TAG_MkPair: {
      V v_x11_24748 = heff_field(v_x1_24747, 0);
      V v_st_24749 = heff_field(v_x1_24747, 1);
      V v_ru_24x1_24747_24MkPair = heff_take_reuse_n(v_x1_24747, 3ULL, 2);
      switch (heff_tag_of(v_x11_24748)) {
      case TAG_Left: {
        V v_e_24750 = heff_field(v_x11_24748, 0);
        heff_take_n(v_x11_24748, 1ULL, 1);
        heff_drop_rec(v_r_240, 3);
        heff_drop(v_ty_24745);
        return heff_tag_at_n(v_ru_24x1_24747_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24750}), v_st_24749});
      }
      case TAG_Right: {
        V v_x_24751 = heff_field(v_x11_24748, 0);
        heff_take_n(v_x11_24748, 1ULL, 1);
        V v_m_24752 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_ty_24745}));
        V v_x1_24753 = heff_tr(heff_call(v_m_24752, 1, (V[]){v_st_24749}));
        switch (heff_tag_of(v_x1_24753)) {
        case TAG_MkPair: {
          V v_x11_24754 = heff_field(v_x1_24753, 0);
          V v_st_24755 = heff_field(v_x1_24753, 1);
          V v_ru_24x1_24753_24MkPair = heff_take_reuse_n(v_x1_24753, 3ULL, 2);
          switch (heff_tag_of(v_x11_24754)) {
          case TAG_Left: {
            V v_e_24756 = heff_field(v_x11_24754, 0);
            heff_take_n(v_x11_24754, 1ULL, 1);
            heff_drop(v_x_24751);
            heff_drop_cell(v_ru_24x1_24753_24MkPair, 2);
            return heff_tag_at_n(v_ru_24x1_24747_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24756}), v_st_24755});
          }
          case TAG_Right: {
            V v_x_24757 = heff_field(v_x11_24754, 0);
            heff_take_n(v_x11_24754, 1ULL, 1);
            V v_t_24760;
            switch (heff_tag_of(v_x_24751)) {
            case TAG_At: {
              V v_s_24759 = heff_dup(heff_field(v_x_24751, 1));
              v_t_24760 = v_s_24759;
              break;
            }
            default: heff_nomatch(v_x_24751);
            }
            V v_t_24763;
            switch (heff_tag_of(v_x_24757)) {
            case TAG_At: {
              V v_s_24762 = heff_dup(heff_field(v_x_24757, 1));
              v_t_24763 = v_s_24762;
              break;
            }
            default: heff_nomatch(v_x_24757);
            }
            V v_t_24764 = ({ V rv_1 = heff_get_n(v_t_24763, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24760, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
            V v_t_24765 = heff_tag_at_n(v_ru_24x1_24753_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_EAnn, 2, (V[]){v_x_24751, v_x_24757}), v_t_24764});
            return heff_tag_at_n(v_ru_24x1_24747_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24765}), v_st_24755});
          }
          default: return heff_nomatch(v_x11_24754);
          }
        }
        default: return heff_nomatch(v_x1_24753);
        }
      }
      default: return heff_nomatch(v_x11_24748);
      }
    }
    default: return heff_nomatch(v_x1_24747);
    }
  }
  case TAG_BVar: {
    heff_drop_rec(v_r_240, 3);
    V v_t_24767 = (g_heff_2esyntax_2ecst_2efirstE(v_e0_241));
    V v_t_24768 = ({ V a_0 = v_e0_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e0_241, 1); r_; });
    V v_t_24769 = heff_strAppend(heff_get_n(v_t_24768, 1, 9), ((V)&g_heff_2esyntax_2esurface_2eexprL_str24));
    V v_msg_24770 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eexprL_str25), v_t_24769);
    V v_t_24771 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24767, 3), heff_get_n(v_t_24767, 4, 9)});
    V v_t_24772 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24770, v_t_24771, NTAG(TAG_Nothing)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24772}), v_z_242});
  }
  case TAG_BImp: {
    heff_drop_rec(v_r_240, 3);
    V v_t_24776 = (g_heff_2esyntax_2ecst_2efirstE(v_e0_241));
    V v_t_24777 = ({ V a_0 = v_e0_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e0_241, 3); r_; });
    V v_t_24778 = heff_strAppend(heff_get_n(v_t_24777, 1, 9), ((V)&g_heff_2esyntax_2esurface_2eexprL_str26));
    V v_msg_24779 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eexprL_str27), v_t_24778);
    V v_t_24780 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24776, 3), heff_get_n(v_t_24776, 4, 9)});
    V v_t_24781 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24779, v_t_24780, NTAG(TAG_Nothing)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24781}), v_z_242});
  }
  case TAG_BAnn: {
    heff_drop_rec(v_r_240, 3);
    V v_t_24787 = (g_heff_2esyntax_2ecst_2efirstE(v_e0_241));
    V v_t_24788 = ({ V a_0 = v_e0_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e0_241, 5); r_; });
    V v_t_24789 = heff_strAppend(heff_get_n(v_t_24788, 1, 9), ((V)&g_heff_2esyntax_2esurface_2eexprL_str28));
    V v_msg_24790 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eexprL_str29), v_t_24789);
    V v_t_24791 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24787, 3), heff_get_n(v_t_24787, 4, 9)});
    V v_t_24792 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24790, v_t_24791, NTAG(TAG_Nothing)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24792}), v_z_242});
  }
  case TAG_BPat: {
    heff_drop_rec(v_r_240, 3);
    V v_t_24794 = (g_heff_2esyntax_2ecst_2efirstE(v_e0_241));
    V v_t_24795 = ({ V a_0 = v_e0_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e0_241, 1); r_; });
    V v_t_24796 = heff_strAppend(heff_get_n(v_t_24795, 1, 9), ((V)&g_heff_2esyntax_2esurface_2eexprL_str30));
    V v_msg_24797 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eexprL_str31), v_t_24796);
    V v_t_24798 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24794, 3), heff_get_n(v_t_24794, 4, 9)});
    V v_t_24799 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24797, v_t_24798, NTAG(TAG_Nothing)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24799}), v_z_242});
  }
  case TAG_Lam: {
    V v_binders_24801 = heff_field(v_e0_241, 1);
    V v_body_24803 = heff_field(v_e0_241, 3);
    heff_take_n(v_e0_241, 10ULL, 4);
    return (g_heff_2esyntax_2esurface_2elambdaL(v_r_240, v_binders_24801, v_body_24803, v_z_242));
  }
  case TAG_Case: {
    V v_kw_24804 = heff_dup(heff_field(v_e0_241, 0));
    V v_scrut_24805 = heff_dup(heff_field(v_e0_241, 1));
    V v_alts_24807 = heff_dup(heff_field(v_e0_241, 3));
    V v_m_24808 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_scrut_24805}));
    V v_x1_24809 = heff_tr(heff_call(v_m_24808, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x1_24809)) {
    case TAG_MkPair: {
      V v_x11_24810 = heff_field(v_x1_24809, 0);
      V v_st_24811 = heff_field(v_x1_24809, 1);
      V v_ru_24x1_24809_24MkPair = heff_take_reuse_n(v_x1_24809, 3ULL, 2);
      switch (heff_tag_of(v_x11_24810)) {
      case TAG_Left: {
        V v_e_24812 = heff_field(v_x11_24810, 0);
        heff_take_n(v_x11_24810, 1ULL, 1);
        heff_drop_rec(v_r_240, 3);
        heff_drop_tag(v_e0_241, 4);
        heff_drop_rec(v_kw_24804, 9);
        heff_drop(v_alts_24807);
        return heff_tag_at_n(v_ru_24x1_24809_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24812}), v_st_24811});
      }
      case TAG_Right: {
        V v_x_24813 = heff_field(v_x11_24810, 0);
        heff_take_n(v_x11_24810, 1ULL, 1);
        HeffT2 v_t_24815 = (g_heff_2esyntax_2esurface_2eblock_24cpr(heff_clo_n(g_heff_2esyntax_2esurface_2eexprL_lam7, 1, 1, (V[]){v_r_240}), v_alts_24807, v_st_24811));
        {
          V v_field_24816 = v_t_24815.f[0];
          V v_field_24817 = v_t_24815.f[1];
          V v_x11_24818 = v_field_24816;
          V v_st_24819 = v_field_24817;
          switch (heff_tag_of(v_x11_24818)) {
          case TAG_Left: {
            V v_e_24820 = heff_field(v_x11_24818, 0);
            heff_take_n(v_x11_24818, 1ULL, 1);
            heff_drop_tag(v_e0_241, 4);
            heff_drop_rec(v_kw_24804, 9);
            heff_drop(v_x_24813);
            return heff_tag_at_n(v_ru_24x1_24809_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24820}), v_st_24819});
          }
          case TAG_Right: {
            V v_x_24821 = heff_field(v_x11_24818, 0);
            heff_take_n(v_x11_24818, 1ULL, 1);
            V v_t_24822 = (g_heff_2esyntax_2ecst_2elastE(v_e0_241));
            V v_e_24823 = heff_get_n(v_t_24822, 4, 9);
            V v_t_24824 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_24804, 3, 9), v_e_24823});
            V v_x_24825 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_x_24813, v_x_24821}), v_t_24824});
            return heff_tag_at_n(v_ru_24x1_24809_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24825}), v_st_24819});
          }
          default: return heff_nomatch(v_x11_24818);
          }
        }
      }
      default: return heff_nomatch(v_x11_24810);
      }
    }
    default: return heff_nomatch(v_x1_24809);
    }
  }
  case TAG_EAlt: {
    heff_drop_rec(v_r_240, 3);
    V v_t_24829 = (g_heff_2esyntax_2ecst_2efirstE(v_e0_241));
    V v_t_24830 = ({ V a_0 = v_e0_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e0_241, 3); r_; });
    V v_t_24831 = heff_strAppend(heff_get_n(v_t_24830, 1, 9), ((V)&g_heff_2esyntax_2esurface_2eexprL_str32));
    V v_msg_24832 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eexprL_str33), v_t_24831);
    V v_t_24833 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24829, 3), heff_get_n(v_t_24829, 4, 9)});
    V v_t_24834 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24832, v_t_24833, NTAG(TAG_Nothing)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24834}), v_z_242});
  }
  case TAG_If: {
    V v_kw_24835 = heff_field(v_e0_241, 0);
    V v_c_24836 = heff_field(v_e0_241, 1);
    V v_a_24838 = heff_field(v_e0_241, 3);
    V v_b_24840 = heff_field(v_e0_241, 5);
    heff_take_n(v_e0_241, 43ULL, 6);
    V v_m_24841 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_c_24836}));
    V v_x1_24842 = heff_tr(heff_call(v_m_24841, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x1_24842)) {
    case TAG_MkPair: {
      V v_x11_24843 = heff_field(v_x1_24842, 0);
      V v_st_24844 = heff_field(v_x1_24842, 1);
      V v_ru_24x1_24842_24MkPair = heff_take_reuse_n(v_x1_24842, 3ULL, 2);
      switch (heff_tag_of(v_x11_24843)) {
      case TAG_Left: {
        V v_e_24845 = heff_field(v_x11_24843, 0);
        heff_take_n(v_x11_24843, 1ULL, 1);
        heff_drop_rec(v_r_240, 3);
        heff_drop_rec(v_kw_24835, 9);
        heff_drop(v_a_24838);
        heff_drop(v_b_24840);
        return heff_tag_at_n(v_ru_24x1_24842_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24845}), v_st_24844});
      }
      case TAG_Right: {
        V v_x_24846 = heff_field(v_x11_24843, 0);
        heff_take_n(v_x11_24843, 1ULL, 1);
        V v_m_24847 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_24838}));
        V v_x1_24848 = heff_tr(heff_call(v_m_24847, 1, (V[]){v_st_24844}));
        switch (heff_tag_of(v_x1_24848)) {
        case TAG_MkPair: {
          V v_x11_24849 = heff_field(v_x1_24848, 0);
          V v_st_24850 = heff_field(v_x1_24848, 1);
          heff_take_n(v_x1_24848, 3ULL, 2);
          switch (heff_tag_of(v_x11_24849)) {
          case TAG_Left: {
            V v_e_24851 = heff_field(v_x11_24849, 0);
            heff_take_n(v_x11_24849, 1ULL, 1);
            heff_drop_rec(v_r_240, 3);
            heff_drop_rec(v_kw_24835, 9);
            heff_drop(v_b_24840);
            heff_drop(v_x_24846);
            return heff_tag_at_n(v_ru_24x1_24842_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24851}), v_st_24850});
          }
          case TAG_Right: {
            V v_x_24852 = heff_field(v_x11_24849, 0);
            heff_take_n(v_x11_24849, 1ULL, 1);
            V v_m_24853 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_b_24840)}));
            V v_x1_24854 = heff_tr(heff_call(v_m_24853, 1, (V[]){v_st_24850}));
            switch (heff_tag_of(v_x1_24854)) {
            case TAG_MkPair: {
              V v_x11_24855 = heff_field(v_x1_24854, 0);
              V v_st_24856 = heff_field(v_x1_24854, 1);
              heff_take_n(v_x1_24854, 3ULL, 2);
              switch (heff_tag_of(v_x11_24855)) {
              case TAG_Left: {
                V v_e_24857 = heff_field(v_x11_24855, 0);
                heff_take_n(v_x11_24855, 1ULL, 1);
                heff_drop_rec(v_kw_24835, 9);
                heff_drop(v_b_24840);
                heff_drop(v_x_24846);
                heff_drop(v_x_24852);
                return heff_tag_at_n(v_ru_24x1_24842_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24857}), v_st_24856});
              }
              case TAG_Right: {
                V v_x_24858 = heff_field(v_x11_24855, 0);
                heff_take_n(v_x11_24855, 1ULL, 1);
                V v_t_24859 = (g_heff_2esyntax_2ecst_2elastE(v_b_24840));
                V v_e_24860 = heff_get_n(v_t_24859, 4, 9);
                V v_t_24861 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_24835, 3, 9), v_e_24860});
                V v_x_24862 = (g_heff_2esyntax_2esurface_2eifE(v_t_24861, v_x_24846, v_x_24852, v_x_24858));
                return heff_tag_at_n(v_ru_24x1_24842_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24862}), v_st_24856});
              }
              default: return heff_nomatch(v_x11_24855);
              }
            }
            default: return heff_nomatch(v_x1_24854);
            }
          }
          default: return heff_nomatch(v_x11_24849);
          }
        }
        default: return heff_nomatch(v_x1_24848);
        }
      }
      default: return heff_nomatch(v_x11_24843);
      }
    }
    default: return heff_nomatch(v_x1_24842);
    }
  }
  case TAG_Do: {
    V v_kw_24863 = heff_dup(heff_field(v_e0_241, 0));
    V v_stmts_24864 = heff_dup(heff_field(v_e0_241, 1));
    HeffT2 v_t_24866 = (g_heff_2esyntax_2esurface_2eblock_24cpr(heff_clo_n(g_heff_2esyntax_2esurface_2eexprL_lam8, 1, 1, (V[]){v_r_240}), v_stmts_24864, v_z_242));
    {
      V v_field_24867 = v_t_24866.f[0];
      V v_field_24868 = v_t_24866.f[1];
      V v_x11_24869 = v_field_24867;
      V v_st_24870 = v_field_24868;
      switch (heff_tag_of(v_x11_24869)) {
      case TAG_Left: {
        V v_e_24871 = heff_field(v_x11_24869, 0);
        V v_ru_24x11_24869_24Left = heff_take_reuse_n(v_x11_24869, 1ULL, 1);
        heff_drop_tag(v_e0_241, 2);
        heff_drop_rec(v_kw_24863, 9);
        return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_24869_24Left, TAG_Left, 1, (V[]){v_e_24871}), v_st_24870});
      }
      case TAG_Right: {
        V v_x_24872 = heff_field(v_x11_24869, 0);
        V v_ru_24x11_24869_24Right = heff_take_reuse_n(v_x11_24869, 1ULL, 1);
        V v_t_24873 = (g_heff_2esyntax_2ecst_2elastE(v_e0_241));
        V v_e_24874 = heff_get_n(v_t_24873, 4, 9);
        V v_t_24875 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_24863, 3, 9), v_e_24874});
        V v_x_24876 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EDo, 1, (V[]){v_x_24872}), v_t_24875});
        return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_24869_24Right, TAG_Right, 1, (V[]){v_x_24876}), v_st_24870});
      }
      default: return heff_nomatch(v_x11_24869);
      }
    }
  }
  case TAG_ESBind: {
    heff_drop_rec(v_r_240, 3);
    V v_t_24880 = (g_heff_2esyntax_2ecst_2efirstE(v_e0_241));
    V v_t_24881 = ({ V a_0 = v_e0_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e0_241, 3); r_; });
    V v_t_24882 = heff_strAppend(heff_get_n(v_t_24881, 1, 9), ((V)&g_heff_2esyntax_2esurface_2eexprL_str34));
    V v_msg_24883 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eexprL_str35), v_t_24882);
    V v_t_24884 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24880, 3), heff_get_n(v_t_24880, 4, 9)});
    V v_t_24885 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24883, v_t_24884, NTAG(TAG_Nothing)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24885}), v_z_242});
  }
  case TAG_ELet: {
    HEFF_LAST return g_heff_2esyntax_2esurface_2eletL(v_r_240, v_e0_241, v_z_242);
  }
  case TAG_ELetElse: {
    heff_drop_rec(v_r_240, 3);
    V v_t_24899 = (g_heff_2esyntax_2ecst_2efirstE(v_e0_241));
    V v_t_24900 = ({ V a_0 = v_e0_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e0_241, 7); r_; });
    V v_t_24901 = heff_strAppend(heff_get_n(v_t_24900, 1, 9), ((V)&g_heff_2esyntax_2esurface_2eexprL_str36));
    V v_msg_24902 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eexprL_str37), v_t_24901);
    V v_t_24903 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24899, 3), heff_get_n(v_t_24899, 4, 9)});
    V v_t_24904 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24902, v_t_24903, NTAG(TAG_Nothing)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24904}), v_z_242});
  }
  case TAG_ELetMut: {
    heff_drop_rec(v_r_240, 3);
    V v_t_24911 = (g_heff_2esyntax_2ecst_2efirstE(v_e0_241));
    V v_t_24912 = ({ V a_0 = v_e0_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e0_241, 6); r_; });
    V v_t_24913 = heff_strAppend(heff_get_n(v_t_24912, 1, 9), ((V)&g_heff_2esyntax_2esurface_2eexprL_str38));
    V v_msg_24914 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eexprL_str39), v_t_24913);
    V v_t_24915 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_24911, 3), heff_get_n(v_t_24911, 4, 9)});
    V v_t_24916 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24914, v_t_24915, NTAG(TAG_Nothing)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24916}), v_z_242});
  }
  case TAG_EAssign: {
    V v_x_24917 = heff_field(v_e0_241, 0);
    V v_e_24919 = heff_field(v_e0_241, 2);
    V v_ru_24e0_241_24EAssign = heff_take_reuse_n(v_e0_241, 5ULL, 3);
    V v_m_24920 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_e_24919)}));
    V v_x1_24921 = heff_tr(heff_call(v_m_24920, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x1_24921)) {
    case TAG_MkPair: {
      V v_x11_24922 = heff_field(v_x1_24921, 0);
      V v_st_24923 = heff_field(v_x1_24921, 1);
      V v_ru_24x1_24921_24MkPair = heff_take_reuse_n(v_x1_24921, 3ULL, 2);
      switch (heff_tag_of(v_x11_24922)) {
      case TAG_Left: {
        V v_e_24924 = heff_field(v_x11_24922, 0);
        heff_take_n(v_x11_24922, 1ULL, 1);
        heff_drop_rec(v_x_24917, 9);
        heff_drop(v_e_24919);
        heff_drop_cell(v_ru_24e0_241_24EAssign, 3);
        return heff_tag_at_n(v_ru_24x1_24921_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24924}), v_st_24923});
      }
      case TAG_Right: {
        V v_x_24925 = heff_field(v_x11_24922, 0);
        heff_take_n(v_x11_24922, 1ULL, 1);
        V v_t_24926 = heff_rec_n(2, shape_start__end, (V[]){heff_dup(heff_rfield(v_x_24917, 3)), heff_take_field(v_x_24917, 4)});
        V v_t_24927 = heff_tag_at_n(v_ru_24e0_241_24EAssign, TAG_EAssign, 3, (V[]){heff_dup(heff_rfield(v_x_24917, 1)), v_t_24926, v_x_24925});
        V v_t_24928 = (g_heff_2esyntax_2ecst_2elastE(v_e_24919));
        V v_e_24929 = heff_get_n(v_t_24928, 4, 9);
        V v_t_24930 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_x_24917, 3, 9), v_e_24929});
        V v_x_24931 = heff_tag_n(TAG_At, 2, (V[]){v_t_24927, v_t_24930});
        return heff_tag_at_n(v_ru_24x1_24921_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24931}), v_st_24923});
      }
      default: return heff_nomatch(v_x11_24922);
      }
    }
    default: return heff_nomatch(v_x1_24921);
    }
  }
  case TAG_EWhile: {
    V v_kw_24932 = heff_dup(heff_field(v_e0_241, 0));
    V v_c_24933 = heff_dup(heff_field(v_e0_241, 1));
    V v_body_24935 = heff_dup(heff_field(v_e0_241, 3));
    V v_m_24936 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_c_24933}));
    V v_x1_24937 = heff_tr(heff_call(v_m_24936, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x1_24937)) {
    case TAG_MkPair: {
      V v_x11_24938 = heff_field(v_x1_24937, 0);
      V v_st_24939 = heff_field(v_x1_24937, 1);
      V v_ru_24x1_24937_24MkPair = heff_take_reuse_n(v_x1_24937, 3ULL, 2);
      switch (heff_tag_of(v_x11_24938)) {
      case TAG_Left: {
        V v_e_24940 = heff_field(v_x11_24938, 0);
        heff_take_n(v_x11_24938, 1ULL, 1);
        heff_drop_rec(v_r_240, 3);
        heff_drop_tag(v_e0_241, 4);
        heff_drop_rec(v_kw_24932, 9);
        heff_drop(v_body_24935);
        return heff_tag_at_n(v_ru_24x1_24937_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24940}), v_st_24939});
      }
      case TAG_Right: {
        V v_x_24941 = heff_field(v_x11_24938, 0);
        heff_take_n(v_x11_24938, 1ULL, 1);
        HeffT2 v_t_24943 = (g_heff_2esyntax_2esurface_2eblock_24cpr(heff_clo_n(g_heff_2esyntax_2esurface_2eexprL_lam9, 1, 1, (V[]){v_r_240}), v_body_24935, v_st_24939));
        {
          V v_field_24944 = v_t_24943.f[0];
          V v_field_24945 = v_t_24943.f[1];
          V v_x11_24946 = v_field_24944;
          V v_st_24947 = v_field_24945;
          switch (heff_tag_of(v_x11_24946)) {
          case TAG_Left: {
            V v_e_24948 = heff_field(v_x11_24946, 0);
            heff_take_n(v_x11_24946, 1ULL, 1);
            heff_drop_tag(v_e0_241, 4);
            heff_drop_rec(v_kw_24932, 9);
            heff_drop(v_x_24941);
            return heff_tag_at_n(v_ru_24x1_24937_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24948}), v_st_24947});
          }
          case TAG_Right: {
            V v_x_24949 = heff_field(v_x11_24946, 0);
            heff_take_n(v_x11_24946, 1ULL, 1);
            V v_t_24950 = (g_heff_2esyntax_2ecst_2elastE(v_e0_241));
            V v_e_24951 = heff_get_n(v_t_24950, 4, 9);
            V v_t_24952 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_24932, 3, 9), v_e_24951});
            V v_x_24953 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EWhile, 2, (V[]){v_x_24941, v_x_24949}), v_t_24952});
            return heff_tag_at_n(v_ru_24x1_24937_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24953}), v_st_24947});
          }
          default: return heff_nomatch(v_x11_24946);
          }
        }
      }
      default: return heff_nomatch(v_x11_24938);
      }
    }
    default: return heff_nomatch(v_x1_24937);
    }
  }
  case TAG_EFor: {
    V v_kw_24954 = heff_dup(heff_field(v_e0_241, 0));
    V v_p_24955 = heff_dup(heff_field(v_e0_241, 1));
    V v_c_24957 = heff_dup(heff_field(v_e0_241, 3));
    V v_body_24959 = heff_dup(heff_field(v_e0_241, 5));
    V v_m_24960 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_c_24957}));
    V v_x1_24961 = heff_tr(heff_call(v_m_24960, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x1_24961)) {
    case TAG_MkPair: {
      V v_x11_24962 = heff_field(v_x1_24961, 0);
      V v_st_24963 = heff_field(v_x1_24961, 1);
      V v_ru_24x1_24961_24MkPair = heff_take_reuse_n(v_x1_24961, 3ULL, 2);
      switch (heff_tag_of(v_x11_24962)) {
      case TAG_Left: {
        V v_e_24964 = heff_field(v_x11_24962, 0);
        heff_take_n(v_x11_24962, 1ULL, 1);
        heff_drop_rec(v_r_240, 3);
        heff_drop_tag(v_e0_241, 6);
        heff_drop_rec(v_kw_24954, 9);
        heff_drop(v_p_24955);
        heff_drop(v_body_24959);
        return heff_tag_at_n(v_ru_24x1_24961_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24964}), v_st_24963});
      }
      case TAG_Right: {
        V v_x_24965 = heff_field(v_x11_24962, 0);
        heff_take_n(v_x11_24962, 1ULL, 1);
        V v_m_24966 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 1)), 1, (V[]){heff_dup(v_p_24955)}));
        V v_x1_24967 = heff_tr(heff_call(v_m_24966, 1, (V[]){v_st_24963}));
        switch (heff_tag_of(v_x1_24967)) {
        case TAG_MkPair: {
          V v_x11_24968 = heff_field(v_x1_24967, 0);
          V v_st_24969 = heff_field(v_x1_24967, 1);
          V v_ru_24x1_24967_24MkPair = heff_take_reuse_n(v_x1_24967, 3ULL, 2);
          switch (heff_tag_of(v_x11_24968)) {
          case TAG_Left: {
            V v_e_24970 = heff_field(v_x11_24968, 0);
            heff_take_n(v_x11_24968, 1ULL, 1);
            heff_drop_rec(v_r_240, 3);
            heff_drop_tag(v_e0_241, 6);
            heff_drop_rec(v_kw_24954, 9);
            heff_drop(v_p_24955);
            heff_drop(v_body_24959);
            heff_drop(v_x_24965);
            heff_drop_cell(v_ru_24x1_24967_24MkPair, 2);
            return heff_tag_at_n(v_ru_24x1_24961_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24970}), v_st_24969});
          }
          case TAG_Right: {
            V v_x_24971 = heff_field(v_x11_24968, 0);
            heff_take_n(v_x11_24968, 1ULL, 1);
            V v_t_24972 = ({ V b_0 = NTAG(TAG_Nil); V a_1 = v_p_24955; V r_ = (g_heff_2esyntax_2esurface_2eboundBy(b_0, a_1)); heff_drop(b_0); heff_drop(v_p_24955); r_; });
            V v_t_24974 = heff_tr(heff_call(((V)&g_heff_2esyntax_2esurface_2eblock_clo), 2, (V[]){heff_clo_n(g_heff_2esyntax_2esurface_2eexprL_lam10, 1, 1, (V[]){v_r_240}), v_body_24959}));
            HeffT2 v_t_24975 = (g_heff_2esyntax_2esurface_2ewithScope_24cpr(v_t_24972, v_t_24974, v_st_24969));
            {
              V v_field_24976 = v_t_24975.f[0];
              V v_field_24977 = v_t_24975.f[1];
              V v_x11_24978 = v_field_24976;
              V v_st_24979 = v_field_24977;
              switch (heff_tag_of(v_x11_24978)) {
              case TAG_Left: {
                V v_e_24980 = heff_field(v_x11_24978, 0);
                heff_take_n(v_x11_24978, 1ULL, 1);
                heff_drop_tag(v_e0_241, 6);
                heff_drop_rec(v_kw_24954, 9);
                heff_drop(v_x_24965);
                heff_drop_cell(v_ru_24x1_24967_24MkPair, 2);
                heff_drop(v_x_24971);
                return heff_tag_at_n(v_ru_24x1_24961_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24980}), v_st_24979});
              }
              case TAG_Right: {
                V v_x_24981 = heff_field(v_x11_24978, 0);
                heff_take_n(v_x11_24978, 1ULL, 1);
                V v_t_24982 = (g_heff_2esyntax_2ecst_2elastE(v_e0_241));
                V v_e_24983 = heff_get_n(v_t_24982, 4, 9);
                V v_t_24984 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_24954, 3, 9), v_e_24983});
                V v_x_24985 = heff_tag_at_n(v_ru_24x1_24967_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_EFor, 3, (V[]){v_x_24971, v_x_24965, v_x_24981}), v_t_24984});
                return heff_tag_at_n(v_ru_24x1_24961_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24985}), v_st_24979});
              }
              default: return heff_nomatch(v_x11_24978);
              }
            }
          }
          default: return heff_nomatch(v_x11_24968);
          }
        }
        default: return heff_nomatch(v_x1_24967);
        }
      }
      default: return heff_nomatch(v_x11_24962);
      }
    }
    default: return heff_nomatch(v_x1_24961);
    }
  }
  case TAG_EJump: {
    V v_kw_24986 = heff_field(v_e0_241, 0);
    V v_ru_24e0_241_24EJump = heff_take_reuse_n(v_e0_241, 1ULL, 1);
    heff_drop_rec(v_r_240, 3);
    V v_t_24988;
    if (heff_strEq_c(heff_dup(heff_rfield(v_kw_24986, 1)), ((V)&g_heff_2esyntax_2esurface_2eexprL_str40))) {
      v_t_24988 = NTAG(TAG_EBreak);
    } else {
      v_t_24988 = NTAG(TAG_EContinue);
    }
    V v_t_24989 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_kw_24986, 3), heff_get_n(v_kw_24986, 4, 9)});
    V v_t_24990 = heff_tag_at_n(v_ru_24e0_241_24EJump, TAG_Right, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24988, v_t_24989})});
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_24990, v_z_242});
  }
  case TAG_EReturn: {
    V v_kw_24991 = heff_field(v_e0_241, 0);
    V v_e_24992 = heff_field(v_e0_241, 1);
    V v_ru_24e0_241_24EReturn = heff_take_reuse_n(v_e0_241, 3ULL, 2);
    V v_m_24993 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_e_24992)}));
    V v_x1_24994 = heff_tr(heff_call(v_m_24993, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x1_24994)) {
    case TAG_MkPair: {
      V v_x11_24995 = heff_field(v_x1_24994, 0);
      V v_st_24996 = heff_field(v_x1_24994, 1);
      V v_ru_24x1_24994_24MkPair = heff_take_reuse_n(v_x1_24994, 3ULL, 2);
      switch (heff_tag_of(v_x11_24995)) {
      case TAG_Left: {
        V v_e_24997 = heff_field(v_x11_24995, 0);
        heff_take_n(v_x11_24995, 1ULL, 1);
        heff_drop_rec(v_kw_24991, 9);
        heff_drop(v_e_24992);
        heff_drop_cell(v_ru_24x1_24994_24MkPair, 2);
        return heff_tag_at_n(v_ru_24e0_241_24EReturn, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24997}), v_st_24996});
      }
      case TAG_Right: {
        V v_x_24998 = heff_field(v_x11_24995, 0);
        heff_take_n(v_x11_24995, 1ULL, 1);
        V v_t_24999 = (g_heff_2esyntax_2ecst_2elastE(v_e_24992));
        V v_e_241000 = heff_get_n(v_t_24999, 4, 9);
        V v_t_241001 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_24991, 3, 9), v_e_241000});
        V v_x_241002 = heff_tag_at_n(v_ru_24e0_241_24EReturn, TAG_At, 2, (V[]){heff_tag_n(TAG_EReturn, 1, (V[]){v_x_24998}), v_t_241001});
        return heff_tag_at_n(v_ru_24x1_24994_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_241002}), v_st_24996});
      }
      default: return heff_nomatch(v_x11_24995);
      }
    }
    default: return heff_nomatch(v_x1_24994);
    }
  }
  case TAG_ENest: {
    V v_o_241003 = heff_field(v_e0_241, 0);
    V v_e_241005 = heff_field(v_e0_241, 2);
    V v_c_241006 = heff_field(v_e0_241, 3);
    heff_take_n(v_e0_241, 13ULL, 4);
    V v_m_241007 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_241005}));
    V v_x1_241008 = heff_tr(heff_call(v_m_241007, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x1_241008)) {
    case TAG_MkPair: {
      V v_x11_241009 = heff_field(v_x1_241008, 0);
      V v_st_241010 = heff_field(v_x1_241008, 1);
      V v_ru_24x1_241008_24MkPair = heff_take_reuse_n(v_x1_241008, 3ULL, 2);
      switch (heff_tag_of(v_x11_241009)) {
      case TAG_Left: {
        V v_e_241011 = heff_field(v_x11_241009, 0);
        heff_take_n(v_x11_241009, 1ULL, 1);
        heff_drop_rec(v_o_241003, 9);
        heff_drop_rec(v_c_241006, 9);
        return heff_tag_at_n(v_ru_24x1_241008_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241011}), v_st_241010});
      }
      case TAG_Right: {
        V v_x_241012 = heff_field(v_x11_241009, 0);
        V v_ru_24x11_241009_24Right = heff_take_reuse_n(v_x11_241009, 1ULL, 1);
        V v_t_241013 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_o_241003, 3, 9), heff_get_n(v_c_241006, 4, 9)});
        V v_t_241014 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_241009_24Right, TAG_ENest, 1, (V[]){v_x_241012}), v_t_241013});
        return heff_tag_at_n(v_ru_24x1_241008_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_241014}), v_st_241010});
      }
      default: return heff_nomatch(v_x11_241009);
      }
    }
    default: return heff_nomatch(v_x1_241008);
    }
  }
  case TAG_IfThen: {
    V v_kw_241015 = heff_field(v_e0_241, 0);
    V v_c_241016 = heff_field(v_e0_241, 1);
    V v_a_241018 = heff_field(v_e0_241, 3);
    heff_take_n(v_e0_241, 11ULL, 4);
    V v_m_241019 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_c_241016}));
    V v_x1_241020 = heff_tr(heff_call(v_m_241019, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x1_241020)) {
    case TAG_MkPair: {
      V v_x11_241021 = heff_field(v_x1_241020, 0);
      V v_st_241022 = heff_field(v_x1_241020, 1);
      V v_ru_24x1_241020_24MkPair = heff_take_reuse_n(v_x1_241020, 3ULL, 2);
      switch (heff_tag_of(v_x11_241021)) {
      case TAG_Left: {
        V v_e_241023 = heff_field(v_x11_241021, 0);
        heff_take_n(v_x11_241021, 1ULL, 1);
        heff_drop_rec(v_r_240, 3);
        heff_drop_rec(v_kw_241015, 9);
        heff_drop(v_a_241018);
        return heff_tag_at_n(v_ru_24x1_241020_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241023}), v_st_241022});
      }
      case TAG_Right: {
        V v_x_241024 = heff_field(v_x11_241021, 0);
        heff_take_n(v_x11_241021, 1ULL, 1);
        V v_m_241025 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_a_241018)}));
        V v_x1_241026 = heff_tr(heff_call(v_m_241025, 1, (V[]){v_st_241022}));
        switch (heff_tag_of(v_x1_241026)) {
        case TAG_MkPair: {
          V v_x11_241027 = heff_field(v_x1_241026, 0);
          V v_st_241028 = heff_field(v_x1_241026, 1);
          V v_ru_24x1_241026_24MkPair = heff_take_reuse_n(v_x1_241026, 3ULL, 2);
          switch (heff_tag_of(v_x11_241027)) {
          case TAG_Left: {
            V v_e_241029 = heff_field(v_x11_241027, 0);
            heff_take_n(v_x11_241027, 1ULL, 1);
            heff_drop_rec(v_kw_241015, 9);
            heff_drop(v_a_241018);
            heff_drop(v_x_241024);
            heff_drop_cell(v_ru_24x1_241026_24MkPair, 2);
            return heff_tag_at_n(v_ru_24x1_241020_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241029}), v_st_241028});
          }
          case TAG_Right: {
            V v_x_241030 = heff_field(v_x11_241027, 0);
            heff_take_n(v_x11_241027, 1ULL, 1);
            V v_t_241031 = (g_heff_2esyntax_2ecst_2elastE(v_a_241018));
            V v_e_241032 = heff_get_n(v_t_241031, 4, 9);
            V v_t_241033 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_241015, 3, 9), v_e_241032});
            V v_x_241034 = heff_tag_at_n(v_ru_24x1_241026_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_EIfThen, 2, (V[]){v_x_241024, v_x_241030}), v_t_241033});
            return heff_tag_at_n(v_ru_24x1_241020_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_241034}), v_st_241028});
          }
          default: return heff_nomatch(v_x11_241027);
          }
        }
        default: return heff_nomatch(v_x1_241026);
        }
      }
      default: return heff_nomatch(v_x11_241021);
      }
    }
    default: return heff_nomatch(v_x1_241020);
    }
  }
  case TAG_ETry: {
    V v_kw_241035 = heff_dup(heff_field(v_e0_241, 0));
    V v_ty_241036 = heff_dup(heff_field(v_e0_241, 1));
    V v_body_241037 = heff_dup(heff_field(v_e0_241, 2));
    V v_c_241038 = heff_dup(heff_field(v_e0_241, 3));
    V v_m_241039 = (g_heff_2esyntax_2esurface_2etryTypeL(heff_dup(v_r_240), v_ty_241036));
    V v_x1_241040 = heff_tr(heff_call(v_m_241039, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x1_241040)) {
    case TAG_MkPair: {
      V v_x11_241041 = heff_field(v_x1_241040, 0);
      V v_st_241042 = heff_field(v_x1_241040, 1);
      V v_ru_24x1_241040_24MkPair = heff_take_reuse_n(v_x1_241040, 3ULL, 2);
      switch (heff_tag_of(v_x11_241041)) {
      case TAG_Left: {
        V v_e_241043 = heff_field(v_x11_241041, 0);
        heff_take_n(v_x11_241041, 1ULL, 1);
        heff_drop_rec(v_r_240, 3);
        heff_drop_tag(v_e0_241, 4);
        heff_drop_rec(v_kw_241035, 9);
        heff_drop(v_body_241037);
        heff_drop(v_c_241038);
        return heff_tag_at_n(v_ru_24x1_241040_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241043}), v_st_241042});
      }
      case TAG_Right: {
        V v_x_241044 = heff_field(v_x11_241041, 0);
        V v_ru_24x11_241041_24Right = heff_take_reuse_n(v_x11_241041, 1ULL, 1);
        HeffT2 v_t_241046 = (g_heff_2esyntax_2esurface_2eblock_24cpr(heff_clo_n(g_heff_2esyntax_2esurface_2eexprL_lam11, 1, 1, (V[]){heff_dup(v_r_240)}), v_body_241037, v_st_241042));
        {
          V v_field_241047 = v_t_241046.f[0];
          V v_field_241048 = v_t_241046.f[1];
          V v_x11_241049 = v_field_241047;
          V v_st_241050 = v_field_241048;
          switch (heff_tag_of(v_x11_241049)) {
          case TAG_Left: {
            V v_e_241051 = heff_field(v_x11_241049, 0);
            heff_take_n(v_x11_241049, 1ULL, 1);
            heff_drop_rec(v_r_240, 3);
            heff_drop_tag(v_e0_241, 4);
            heff_drop_rec(v_kw_241035, 9);
            heff_drop(v_c_241038);
            heff_drop(v_x_241044);
            heff_drop_cell(v_ru_24x11_241041_24Right, 1);
            return heff_tag_at_n(v_ru_24x1_241040_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241051}), v_st_241050});
          }
          case TAG_Right: {
            V v_x_241052 = heff_field(v_x11_241049, 0);
            heff_take_n(v_x11_241049, 1ULL, 1);
            V v_m_241053 = (g_heff_2esyntax_2esurface_2ecatchL(v_r_240, v_c_241038));
            V v_x1_241054 = heff_tr(heff_call(v_m_241053, 1, (V[]){v_st_241050}));
            switch (heff_tag_of(v_x1_241054)) {
            case TAG_MkPair: {
              V v_x11_241055 = heff_field(v_x1_241054, 0);
              V v_st_241056 = heff_field(v_x1_241054, 1);
              V v_ru_24x1_241054_24MkPair = heff_take_reuse_n(v_x1_241054, 3ULL, 2);
              switch (heff_tag_of(v_x11_241055)) {
              case TAG_Left: {
                V v_e_241057 = heff_field(v_x11_241055, 0);
                heff_take_n(v_x11_241055, 1ULL, 1);
                heff_drop_tag(v_e0_241, 4);
                heff_drop_rec(v_kw_241035, 9);
                heff_drop(v_x_241044);
                heff_drop_cell(v_ru_24x11_241041_24Right, 1);
                heff_drop(v_x_241052);
                heff_drop_cell(v_ru_24x1_241054_24MkPair, 2);
                return heff_tag_at_n(v_ru_24x1_241040_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241057}), v_st_241056});
              }
              case TAG_Right: {
                V v_x_241058 = heff_field(v_x11_241055, 0);
                heff_take_n(v_x11_241055, 1ULL, 1);
                V v_t_241059 = heff_tag_at_n(v_ru_24x11_241041_24Right, TAG_ETry, 1, (V[]){heff_tag_n(TAG_MkTry, 3, (V[]){v_x_241044, v_x_241052, v_x_241058})});
                V v_t_241060 = (g_heff_2esyntax_2ecst_2elastE(v_e0_241));
                V v_e_241061 = heff_get_n(v_t_241060, 4, 9);
                V v_t_241062 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_241035, 3, 9), v_e_241061});
                V v_x_241063 = heff_tag_at_n(v_ru_24x1_241054_24MkPair, TAG_At, 2, (V[]){v_t_241059, v_t_241062});
                return heff_tag_at_n(v_ru_24x1_241040_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_241063}), v_st_241056});
              }
              default: return heff_nomatch(v_x11_241055);
              }
            }
            default: return heff_nomatch(v_x1_241054);
            }
          }
          default: return heff_nomatch(v_x11_241049);
          }
        }
      }
      default: return heff_nomatch(v_x11_241041);
      }
    }
    default: return heff_nomatch(v_x1_241040);
    }
  }
  case TAG_ECatch: {
    heff_drop_rec(v_r_240, 3);
    V v_t_241068 = (g_heff_2esyntax_2ecst_2efirstE(v_e0_241));
    V v_t_241069 = ({ V a_0 = v_e0_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e0_241, 4); r_; });
    V v_t_241070 = heff_strAppend(heff_get_n(v_t_241069, 1, 9), ((V)&g_heff_2esyntax_2esurface_2eexprL_str41));
    V v_msg_241071 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eexprL_str42), v_t_241070);
    V v_t_241072 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_241068, 3), heff_get_n(v_t_241068, 4, 9)});
    V v_t_241073 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_241071, v_t_241072, NTAG(TAG_Nothing)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_241073}), v_z_242});
  }
  case TAG_EWith: {
    V v_kw_241074 = heff_dup(heff_field(v_e0_241, 0));
    V v_e_241075 = heff_dup(heff_field(v_e0_241, 1));
    V v_e04_241077 = heff_dup(heff_field(v_e0_241, 3));
    V v_body_241079 = heff_dup(heff_field(v_e0_241, 5));
    switch (heff_tag_of(v_e04_241077)) {
    case TAG_PCon: {
      V v_m_241082 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e_241075}));
      V v_x1_241083 = heff_tr(heff_call(v_m_241082, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_241083)) {
      case TAG_MkPair: {
        V v_x11_241084 = heff_field(v_x1_241083, 0);
        V v_st_241085 = heff_field(v_x1_241083, 1);
        V v_ru_24x1_241083_24MkPair = heff_take_reuse_n(v_x1_241083, 3ULL, 2);
        switch (heff_tag_of(v_x11_241084)) {
        case TAG_Left: {
          V v_e_241086 = heff_field(v_x11_241084, 0);
          heff_take_n(v_x11_241084, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_tag(v_e0_241, 6);
          heff_drop_rec(v_kw_241074, 9);
          heff_drop_tag(v_e04_241077, 2);
          heff_drop(v_body_241079);
          return heff_tag_at_n(v_ru_24x1_241083_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241086}), v_st_241085});
        }
        case TAG_Right: {
          V v_x_241087 = heff_field(v_x11_241084, 0);
          V v_ru_24x11_241084_24Right = heff_take_reuse_n(v_x11_241084, 1ULL, 1);
          V v_m_241088 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 1)), 1, (V[]){heff_dup(v_e04_241077)}));
          V v_x1_241089 = heff_tr(heff_call(v_m_241088, 1, (V[]){v_st_241085}));
          switch (heff_tag_of(v_x1_241089)) {
          case TAG_MkPair: {
            V v_x11_241090 = heff_field(v_x1_241089, 0);
            V v_st_241091 = heff_field(v_x1_241089, 1);
            V v_ru_24x1_241089_24MkPair = heff_take_reuse_n(v_x1_241089, 3ULL, 2);
            switch (heff_tag_of(v_x11_241090)) {
            case TAG_Left: {
              V v_e_241092 = heff_field(v_x11_241090, 0);
              heff_take_n(v_x11_241090, 1ULL, 1);
              heff_drop_rec(v_r_240, 3);
              heff_drop_tag(v_e0_241, 6);
              heff_drop_rec(v_kw_241074, 9);
              heff_drop_tag(v_e04_241077, 2);
              heff_drop(v_body_241079);
              heff_drop(v_x_241087);
              heff_drop_cell(v_ru_24x11_241084_24Right, 1);
              heff_drop_cell(v_ru_24x1_241089_24MkPair, 2);
              return heff_tag_at_n(v_ru_24x1_241083_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241092}), v_st_241091});
            }
            case TAG_Right: {
              V v_x_241093 = heff_field(v_x11_241090, 0);
              heff_take_n(v_x11_241090, 1ULL, 1);
              V v_t_241094 = ({ V b_0 = NTAG(TAG_Nil); V a_1 = v_e04_241077; V r_ = (g_heff_2esyntax_2esurface_2eboundBy(b_0, a_1)); heff_drop(b_0); heff_drop_tag(v_e04_241077, 2); r_; });
              V v_t_241096 = heff_tr(heff_call(((V)&g_heff_2esyntax_2esurface_2eblock_clo), 2, (V[]){heff_clo_n(g_heff_2esyntax_2esurface_2eexprL_lam12, 1, 1, (V[]){v_r_240}), v_body_241079}));
              HeffT2 v_t_241097 = (g_heff_2esyntax_2esurface_2ewithScope_24cpr(v_t_241094, v_t_241096, v_st_241091));
              {
                V v_field_241098 = v_t_241097.f[0];
                V v_field_241099 = v_t_241097.f[1];
                V v_x11_241100 = v_field_241098;
                V v_st_241101 = v_field_241099;
                switch (heff_tag_of(v_x11_241100)) {
                case TAG_Left: {
                  V v_e_241102 = heff_field(v_x11_241100, 0);
                  heff_take_n(v_x11_241100, 1ULL, 1);
                  heff_drop_tag(v_e0_241, 6);
                  heff_drop_rec(v_kw_241074, 9);
                  heff_drop(v_x_241087);
                  heff_drop_cell(v_ru_24x11_241084_24Right, 1);
                  heff_drop_cell(v_ru_24x1_241089_24MkPair, 2);
                  heff_drop(v_x_241093);
                  return heff_tag_at_n(v_ru_24x1_241083_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241102}), v_st_241101});
                }
                case TAG_Right: {
                  V v_x_241103 = heff_field(v_x11_241100, 0);
                  heff_take_n(v_x11_241100, 1ULL, 1);
                  V v_t_241106;
                  switch (heff_tag_of(v_x_241093)) {
                  case TAG_At: {
                    V v_s_241105 = heff_dup(heff_field(v_x_241093, 1));
                    v_t_241106 = v_s_241105;
                    break;
                  }
                  default: heff_nomatch(v_x_241093);
                  }
                  V v_t_241109;
                  switch (heff_tag_of(v_x_241093)) {
                  case TAG_At: {
                    V v_s_241108 = heff_dup(heff_field(v_x_241093, 1));
                    v_t_241109 = v_s_241108;
                    break;
                  }
                  default: heff_nomatch(v_x_241093);
                  }
                  V v_t_241110 = heff_tag_at_n(v_ru_24x1_241089_24MkPair, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_241084_24Right, TAG_EVar, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2eexprL_str43)}), v_t_241109});
                  V v_t_241113;
                  switch (heff_tag_of(v_x_241093)) {
                  case TAG_At: {
                    V v_s_241112 = heff_dup(heff_field(v_x_241093, 1));
                    v_t_241113 = v_s_241112;
                    break;
                  }
                  default: heff_nomatch(v_x_241093);
                  }
                  V v_t_241114 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_StmtLet, 2, (V[]){v_x_241093, v_t_241110}), v_t_241113});
                  V v_t_241115 = heff_tag_n(TAG_EWith, 4, (V[]){v_x_241087, ((V)&g_heff_2esyntax_2esurface_2eexprL_str44), v_t_241106, heff_tag_n(TAG_Cons, 2, (V[]){v_t_241114, v_x_241103})});
                  V v_t_241116 = (g_heff_2esyntax_2ecst_2elastE(v_e0_241));
                  V v_e_241117 = heff_get_n(v_t_241116, 4, 9);
                  V v_t_241118 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_241074, 3, 9), v_e_241117});
                  V v_x_241119 = heff_tag_n(TAG_At, 2, (V[]){v_t_241115, v_t_241118});
                  return heff_tag_at_n(v_ru_24x1_241083_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_241119}), v_st_241101});
                }
                default: return heff_nomatch(v_x11_241100);
                }
              }
            }
            default: return heff_nomatch(v_x11_241090);
            }
          }
          default: return heff_nomatch(v_x1_241089);
          }
        }
        default: return heff_nomatch(v_x11_241084);
        }
      }
      default: return heff_nomatch(v_x1_241083);
      }
    }
    case TAG_PAtom: {
      V v_x_241120 = heff_field(v_e04_241077, 0);
      V v_ru_24e04_241077_24PAtom = heff_take_reuse_n(v_e04_241077, 1ULL, 1);
      V v_m_241121 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e_241075}));
      V v_x1_241122 = heff_tr(heff_call(v_m_241121, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_241122)) {
      case TAG_MkPair: {
        V v_x11_241123 = heff_field(v_x1_241122, 0);
        V v_st_241124 = heff_field(v_x1_241122, 1);
        V v_ru_24x1_241122_24MkPair = heff_take_reuse_n(v_x1_241122, 3ULL, 2);
        switch (heff_tag_of(v_x11_241123)) {
        case TAG_Left: {
          V v_e_241125 = heff_field(v_x11_241123, 0);
          heff_take_n(v_x11_241123, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_tag(v_e0_241, 6);
          heff_drop_rec(v_kw_241074, 9);
          heff_drop(v_body_241079);
          heff_drop_rec(v_x_241120, 9);
          return heff_tag_at_n(v_ru_24x1_241122_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24e04_241077_24PAtom, TAG_Left, 1, (V[]){v_e_241125}), v_st_241124});
        }
        case TAG_Right: {
          V v_x_241126 = heff_field(v_x11_241123, 0);
          heff_take_n(v_x11_241123, 1ULL, 1);
          V v_t_241127 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(heff_rfield(v_x_241120, 1)), NTAG(TAG_Nil)});
          V v_t_241129 = heff_tr(heff_call(((V)&g_heff_2esyntax_2esurface_2eblock_clo), 2, (V[]){heff_clo_n(g_heff_2esyntax_2esurface_2eexprL_lam13, 1, 1, (V[]){v_r_240}), v_body_241079}));
          HeffT2 v_t_241130 = (g_heff_2esyntax_2esurface_2ewithScope_24cpr(v_t_241127, v_t_241129, v_st_241124));
          {
            V v_field_241131 = v_t_241130.f[0];
            V v_field_241132 = v_t_241130.f[1];
            V v_x11_241133 = v_field_241131;
            V v_st_241134 = v_field_241132;
            switch (heff_tag_of(v_x11_241133)) {
            case TAG_Left: {
              V v_e_241135 = heff_field(v_x11_241133, 0);
              heff_take_n(v_x11_241133, 1ULL, 1);
              heff_drop_tag(v_e0_241, 6);
              heff_drop_rec(v_kw_241074, 9);
              heff_drop_rec(v_x_241120, 9);
              heff_drop(v_x_241126);
              return heff_tag_at_n(v_ru_24x1_241122_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24e04_241077_24PAtom, TAG_Left, 1, (V[]){v_e_241135}), v_st_241134});
            }
            case TAG_Right: {
              V v_x_241136 = heff_field(v_x11_241133, 0);
              heff_take_n(v_x11_241133, 1ULL, 1);
              V v_t_241137 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_x_241120, 3), heff_take_field(v_x_241120, 4)});
              V v_t_241138 = heff_tag_n(TAG_EWith, 4, (V[]){v_x_241126, heff_get_n(v_x_241120, 1, 9), v_t_241137, v_x_241136});
              V v_t_241139 = (g_heff_2esyntax_2ecst_2elastE(v_e0_241));
              V v_e_241140 = heff_get_n(v_t_241139, 4, 9);
              V v_t_241141 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_241074, 3, 9), v_e_241140});
              V v_x_241142 = heff_tag_n(TAG_At, 2, (V[]){v_t_241138, v_t_241141});
              return heff_tag_at_n(v_ru_24x1_241122_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24e04_241077_24PAtom, TAG_Right, 1, (V[]){v_x_241142}), v_st_241134});
            }
            default: return heff_nomatch(v_x11_241133);
            }
          }
        }
        default: return heff_nomatch(v_x11_241123);
        }
      }
      default: return heff_nomatch(v_x1_241122);
      }
    }
    case TAG_PParen: {
      V v_m_241146 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e_241075}));
      V v_x1_241147 = heff_tr(heff_call(v_m_241146, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_241147)) {
      case TAG_MkPair: {
        V v_x11_241148 = heff_field(v_x1_241147, 0);
        V v_st_241149 = heff_field(v_x1_241147, 1);
        V v_ru_24x1_241147_24MkPair = heff_take_reuse_n(v_x1_241147, 3ULL, 2);
        switch (heff_tag_of(v_x11_241148)) {
        case TAG_Left: {
          V v_e_241150 = heff_field(v_x11_241148, 0);
          heff_take_n(v_x11_241148, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_tag(v_e0_241, 6);
          heff_drop_rec(v_kw_241074, 9);
          heff_drop_tag(v_e04_241077, 3);
          heff_drop(v_body_241079);
          return heff_tag_at_n(v_ru_24x1_241147_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241150}), v_st_241149});
        }
        case TAG_Right: {
          V v_x_241151 = heff_field(v_x11_241148, 0);
          V v_ru_24x11_241148_24Right = heff_take_reuse_n(v_x11_241148, 1ULL, 1);
          V v_m_241152 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 1)), 1, (V[]){heff_dup(v_e04_241077)}));
          V v_x1_241153 = heff_tr(heff_call(v_m_241152, 1, (V[]){v_st_241149}));
          switch (heff_tag_of(v_x1_241153)) {
          case TAG_MkPair: {
            V v_x11_241154 = heff_field(v_x1_241153, 0);
            V v_st_241155 = heff_field(v_x1_241153, 1);
            V v_ru_24x1_241153_24MkPair = heff_take_reuse_n(v_x1_241153, 3ULL, 2);
            switch (heff_tag_of(v_x11_241154)) {
            case TAG_Left: {
              V v_e_241156 = heff_field(v_x11_241154, 0);
              heff_take_n(v_x11_241154, 1ULL, 1);
              heff_drop_rec(v_r_240, 3);
              heff_drop_tag(v_e0_241, 6);
              heff_drop_rec(v_kw_241074, 9);
              heff_drop_tag(v_e04_241077, 3);
              heff_drop(v_body_241079);
              heff_drop(v_x_241151);
              heff_drop_cell(v_ru_24x11_241148_24Right, 1);
              heff_drop_cell(v_ru_24x1_241153_24MkPair, 2);
              return heff_tag_at_n(v_ru_24x1_241147_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241156}), v_st_241155});
            }
            case TAG_Right: {
              V v_x_241157 = heff_field(v_x11_241154, 0);
              heff_take_n(v_x11_241154, 1ULL, 1);
              V v_t_241158 = ({ V b_0 = NTAG(TAG_Nil); V a_1 = v_e04_241077; V r_ = (g_heff_2esyntax_2esurface_2eboundBy(b_0, a_1)); heff_drop(b_0); heff_drop_tag(v_e04_241077, 3); r_; });
              V v_t_241160 = heff_tr(heff_call(((V)&g_heff_2esyntax_2esurface_2eblock_clo), 2, (V[]){heff_clo_n(g_heff_2esyntax_2esurface_2eexprL_lam14, 1, 1, (V[]){v_r_240}), v_body_241079}));
              HeffT2 v_t_241161 = (g_heff_2esyntax_2esurface_2ewithScope_24cpr(v_t_241158, v_t_241160, v_st_241155));
              {
                V v_field_241162 = v_t_241161.f[0];
                V v_field_241163 = v_t_241161.f[1];
                V v_x11_241164 = v_field_241162;
                V v_st_241165 = v_field_241163;
                switch (heff_tag_of(v_x11_241164)) {
                case TAG_Left: {
                  V v_e_241166 = heff_field(v_x11_241164, 0);
                  heff_take_n(v_x11_241164, 1ULL, 1);
                  heff_drop_tag(v_e0_241, 6);
                  heff_drop_rec(v_kw_241074, 9);
                  heff_drop(v_x_241151);
                  heff_drop_cell(v_ru_24x11_241148_24Right, 1);
                  heff_drop_cell(v_ru_24x1_241153_24MkPair, 2);
                  heff_drop(v_x_241157);
                  return heff_tag_at_n(v_ru_24x1_241147_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241166}), v_st_241165});
                }
                case TAG_Right: {
                  V v_x_241167 = heff_field(v_x11_241164, 0);
                  heff_take_n(v_x11_241164, 1ULL, 1);
                  V v_t_241170;
                  switch (heff_tag_of(v_x_241157)) {
                  case TAG_At: {
                    V v_s_241169 = heff_dup(heff_field(v_x_241157, 1));
                    v_t_241170 = v_s_241169;
                    break;
                  }
                  default: heff_nomatch(v_x_241157);
                  }
                  V v_t_241173;
                  switch (heff_tag_of(v_x_241157)) {
                  case TAG_At: {
                    V v_s_241172 = heff_dup(heff_field(v_x_241157, 1));
                    v_t_241173 = v_s_241172;
                    break;
                  }
                  default: heff_nomatch(v_x_241157);
                  }
                  V v_t_241174 = heff_tag_at_n(v_ru_24x1_241153_24MkPair, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_241148_24Right, TAG_EVar, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2eexprL_str45)}), v_t_241173});
                  V v_t_241177;
                  switch (heff_tag_of(v_x_241157)) {
                  case TAG_At: {
                    V v_s_241176 = heff_dup(heff_field(v_x_241157, 1));
                    v_t_241177 = v_s_241176;
                    break;
                  }
                  default: heff_nomatch(v_x_241157);
                  }
                  V v_t_241178 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_StmtLet, 2, (V[]){v_x_241157, v_t_241174}), v_t_241177});
                  V v_t_241179 = heff_tag_n(TAG_EWith, 4, (V[]){v_x_241151, ((V)&g_heff_2esyntax_2esurface_2eexprL_str46), v_t_241170, heff_tag_n(TAG_Cons, 2, (V[]){v_t_241178, v_x_241167})});
                  V v_t_241180 = (g_heff_2esyntax_2ecst_2elastE(v_e0_241));
                  V v_e_241181 = heff_get_n(v_t_241180, 4, 9);
                  V v_t_241182 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_241074, 3, 9), v_e_241181});
                  V v_x_241183 = heff_tag_n(TAG_At, 2, (V[]){v_t_241179, v_t_241182});
                  return heff_tag_at_n(v_ru_24x1_241147_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_241183}), v_st_241165});
                }
                default: return heff_nomatch(v_x11_241164);
                }
              }
            }
            default: return heff_nomatch(v_x11_241154);
            }
          }
          default: return heff_nomatch(v_x1_241153);
          }
        }
        default: return heff_nomatch(v_x11_241148);
        }
      }
      default: return heff_nomatch(v_x1_241147);
      }
    }
    case TAG_PList: {
      V v_m_241188 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e_241075}));
      V v_x1_241189 = heff_tr(heff_call(v_m_241188, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_241189)) {
      case TAG_MkPair: {
        V v_x11_241190 = heff_field(v_x1_241189, 0);
        V v_st_241191 = heff_field(v_x1_241189, 1);
        V v_ru_24x1_241189_24MkPair = heff_take_reuse_n(v_x1_241189, 3ULL, 2);
        switch (heff_tag_of(v_x11_241190)) {
        case TAG_Left: {
          V v_e_241192 = heff_field(v_x11_241190, 0);
          heff_take_n(v_x11_241190, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_tag(v_e0_241, 6);
          heff_drop_rec(v_kw_241074, 9);
          heff_drop_tag(v_e04_241077, 4);
          heff_drop(v_body_241079);
          return heff_tag_at_n(v_ru_24x1_241189_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241192}), v_st_241191});
        }
        case TAG_Right: {
          V v_x_241193 = heff_field(v_x11_241190, 0);
          V v_ru_24x11_241190_24Right = heff_take_reuse_n(v_x11_241190, 1ULL, 1);
          V v_m_241194 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 1)), 1, (V[]){heff_dup(v_e04_241077)}));
          V v_x1_241195 = heff_tr(heff_call(v_m_241194, 1, (V[]){v_st_241191}));
          switch (heff_tag_of(v_x1_241195)) {
          case TAG_MkPair: {
            V v_x11_241196 = heff_field(v_x1_241195, 0);
            V v_st_241197 = heff_field(v_x1_241195, 1);
            V v_ru_24x1_241195_24MkPair = heff_take_reuse_n(v_x1_241195, 3ULL, 2);
            switch (heff_tag_of(v_x11_241196)) {
            case TAG_Left: {
              V v_e_241198 = heff_field(v_x11_241196, 0);
              heff_take_n(v_x11_241196, 1ULL, 1);
              heff_drop_rec(v_r_240, 3);
              heff_drop_tag(v_e0_241, 6);
              heff_drop_rec(v_kw_241074, 9);
              heff_drop_tag(v_e04_241077, 4);
              heff_drop(v_body_241079);
              heff_drop(v_x_241193);
              heff_drop_cell(v_ru_24x11_241190_24Right, 1);
              heff_drop_cell(v_ru_24x1_241195_24MkPair, 2);
              return heff_tag_at_n(v_ru_24x1_241189_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241198}), v_st_241197});
            }
            case TAG_Right: {
              V v_x_241199 = heff_field(v_x11_241196, 0);
              heff_take_n(v_x11_241196, 1ULL, 1);
              V v_t_241200 = ({ V b_0 = NTAG(TAG_Nil); V a_1 = v_e04_241077; V r_ = (g_heff_2esyntax_2esurface_2eboundBy(b_0, a_1)); heff_drop(b_0); heff_drop_tag(v_e04_241077, 4); r_; });
              V v_t_241202 = heff_tr(heff_call(((V)&g_heff_2esyntax_2esurface_2eblock_clo), 2, (V[]){heff_clo_n(g_heff_2esyntax_2esurface_2eexprL_lam15, 1, 1, (V[]){v_r_240}), v_body_241079}));
              HeffT2 v_t_241203 = (g_heff_2esyntax_2esurface_2ewithScope_24cpr(v_t_241200, v_t_241202, v_st_241197));
              {
                V v_field_241204 = v_t_241203.f[0];
                V v_field_241205 = v_t_241203.f[1];
                V v_x11_241206 = v_field_241204;
                V v_st_241207 = v_field_241205;
                switch (heff_tag_of(v_x11_241206)) {
                case TAG_Left: {
                  V v_e_241208 = heff_field(v_x11_241206, 0);
                  heff_take_n(v_x11_241206, 1ULL, 1);
                  heff_drop_tag(v_e0_241, 6);
                  heff_drop_rec(v_kw_241074, 9);
                  heff_drop(v_x_241193);
                  heff_drop_cell(v_ru_24x11_241190_24Right, 1);
                  heff_drop_cell(v_ru_24x1_241195_24MkPair, 2);
                  heff_drop(v_x_241199);
                  return heff_tag_at_n(v_ru_24x1_241189_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241208}), v_st_241207});
                }
                case TAG_Right: {
                  V v_x_241209 = heff_field(v_x11_241206, 0);
                  heff_take_n(v_x11_241206, 1ULL, 1);
                  V v_t_241212;
                  switch (heff_tag_of(v_x_241199)) {
                  case TAG_At: {
                    V v_s_241211 = heff_dup(heff_field(v_x_241199, 1));
                    v_t_241212 = v_s_241211;
                    break;
                  }
                  default: heff_nomatch(v_x_241199);
                  }
                  V v_t_241215;
                  switch (heff_tag_of(v_x_241199)) {
                  case TAG_At: {
                    V v_s_241214 = heff_dup(heff_field(v_x_241199, 1));
                    v_t_241215 = v_s_241214;
                    break;
                  }
                  default: heff_nomatch(v_x_241199);
                  }
                  V v_t_241216 = heff_tag_at_n(v_ru_24x1_241195_24MkPair, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_241190_24Right, TAG_EVar, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2eexprL_str47)}), v_t_241215});
                  V v_t_241219;
                  switch (heff_tag_of(v_x_241199)) {
                  case TAG_At: {
                    V v_s_241218 = heff_dup(heff_field(v_x_241199, 1));
                    v_t_241219 = v_s_241218;
                    break;
                  }
                  default: heff_nomatch(v_x_241199);
                  }
                  V v_t_241220 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_StmtLet, 2, (V[]){v_x_241199, v_t_241216}), v_t_241219});
                  V v_t_241221 = heff_tag_n(TAG_EWith, 4, (V[]){v_x_241193, ((V)&g_heff_2esyntax_2esurface_2eexprL_str48), v_t_241212, heff_tag_n(TAG_Cons, 2, (V[]){v_t_241220, v_x_241209})});
                  V v_t_241222 = (g_heff_2esyntax_2ecst_2elastE(v_e0_241));
                  V v_e_241223 = heff_get_n(v_t_241222, 4, 9);
                  V v_t_241224 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_241074, 3, 9), v_e_241223});
                  V v_x_241225 = heff_tag_n(TAG_At, 2, (V[]){v_t_241221, v_t_241224});
                  return heff_tag_at_n(v_ru_24x1_241189_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_241225}), v_st_241207});
                }
                default: return heff_nomatch(v_x11_241206);
                }
              }
            }
            default: return heff_nomatch(v_x11_241196);
            }
          }
          default: return heff_nomatch(v_x1_241195);
          }
        }
        default: return heff_nomatch(v_x11_241190);
        }
      }
      default: return heff_nomatch(v_x1_241189);
      }
    }
    case TAG_POp: {
      V v_m_241229 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e_241075}));
      V v_x1_241230 = heff_tr(heff_call(v_m_241229, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_241230)) {
      case TAG_MkPair: {
        V v_x11_241231 = heff_field(v_x1_241230, 0);
        V v_st_241232 = heff_field(v_x1_241230, 1);
        V v_ru_24x1_241230_24MkPair = heff_take_reuse_n(v_x1_241230, 3ULL, 2);
        switch (heff_tag_of(v_x11_241231)) {
        case TAG_Left: {
          V v_e_241233 = heff_field(v_x11_241231, 0);
          heff_take_n(v_x11_241231, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_tag(v_e0_241, 6);
          heff_drop_rec(v_kw_241074, 9);
          heff_drop_tag(v_e04_241077, 3);
          heff_drop(v_body_241079);
          return heff_tag_at_n(v_ru_24x1_241230_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241233}), v_st_241232});
        }
        case TAG_Right: {
          V v_x_241234 = heff_field(v_x11_241231, 0);
          V v_ru_24x11_241231_24Right = heff_take_reuse_n(v_x11_241231, 1ULL, 1);
          V v_m_241235 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 1)), 1, (V[]){heff_dup(v_e04_241077)}));
          V v_x1_241236 = heff_tr(heff_call(v_m_241235, 1, (V[]){v_st_241232}));
          switch (heff_tag_of(v_x1_241236)) {
          case TAG_MkPair: {
            V v_x11_241237 = heff_field(v_x1_241236, 0);
            V v_st_241238 = heff_field(v_x1_241236, 1);
            V v_ru_24x1_241236_24MkPair = heff_take_reuse_n(v_x1_241236, 3ULL, 2);
            switch (heff_tag_of(v_x11_241237)) {
            case TAG_Left: {
              V v_e_241239 = heff_field(v_x11_241237, 0);
              heff_take_n(v_x11_241237, 1ULL, 1);
              heff_drop_rec(v_r_240, 3);
              heff_drop_tag(v_e0_241, 6);
              heff_drop_rec(v_kw_241074, 9);
              heff_drop_tag(v_e04_241077, 3);
              heff_drop(v_body_241079);
              heff_drop(v_x_241234);
              heff_drop_cell(v_ru_24x11_241231_24Right, 1);
              heff_drop_cell(v_ru_24x1_241236_24MkPair, 2);
              return heff_tag_at_n(v_ru_24x1_241230_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241239}), v_st_241238});
            }
            case TAG_Right: {
              V v_x_241240 = heff_field(v_x11_241237, 0);
              heff_take_n(v_x11_241237, 1ULL, 1);
              V v_t_241241 = ({ V b_0 = NTAG(TAG_Nil); V a_1 = v_e04_241077; V r_ = (g_heff_2esyntax_2esurface_2eboundBy(b_0, a_1)); heff_drop(b_0); heff_drop_tag(v_e04_241077, 3); r_; });
              V v_t_241243 = heff_tr(heff_call(((V)&g_heff_2esyntax_2esurface_2eblock_clo), 2, (V[]){heff_clo_n(g_heff_2esyntax_2esurface_2eexprL_lam16, 1, 1, (V[]){v_r_240}), v_body_241079}));
              HeffT2 v_t_241244 = (g_heff_2esyntax_2esurface_2ewithScope_24cpr(v_t_241241, v_t_241243, v_st_241238));
              {
                V v_field_241245 = v_t_241244.f[0];
                V v_field_241246 = v_t_241244.f[1];
                V v_x11_241247 = v_field_241245;
                V v_st_241248 = v_field_241246;
                switch (heff_tag_of(v_x11_241247)) {
                case TAG_Left: {
                  V v_e_241249 = heff_field(v_x11_241247, 0);
                  heff_take_n(v_x11_241247, 1ULL, 1);
                  heff_drop_tag(v_e0_241, 6);
                  heff_drop_rec(v_kw_241074, 9);
                  heff_drop(v_x_241234);
                  heff_drop_cell(v_ru_24x11_241231_24Right, 1);
                  heff_drop_cell(v_ru_24x1_241236_24MkPair, 2);
                  heff_drop(v_x_241240);
                  return heff_tag_at_n(v_ru_24x1_241230_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241249}), v_st_241248});
                }
                case TAG_Right: {
                  V v_x_241250 = heff_field(v_x11_241247, 0);
                  heff_take_n(v_x11_241247, 1ULL, 1);
                  V v_t_241253;
                  switch (heff_tag_of(v_x_241240)) {
                  case TAG_At: {
                    V v_s_241252 = heff_dup(heff_field(v_x_241240, 1));
                    v_t_241253 = v_s_241252;
                    break;
                  }
                  default: heff_nomatch(v_x_241240);
                  }
                  V v_t_241256;
                  switch (heff_tag_of(v_x_241240)) {
                  case TAG_At: {
                    V v_s_241255 = heff_dup(heff_field(v_x_241240, 1));
                    v_t_241256 = v_s_241255;
                    break;
                  }
                  default: heff_nomatch(v_x_241240);
                  }
                  V v_t_241257 = heff_tag_at_n(v_ru_24x1_241236_24MkPair, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_241231_24Right, TAG_EVar, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2eexprL_str49)}), v_t_241256});
                  V v_t_241260;
                  switch (heff_tag_of(v_x_241240)) {
                  case TAG_At: {
                    V v_s_241259 = heff_dup(heff_field(v_x_241240, 1));
                    v_t_241260 = v_s_241259;
                    break;
                  }
                  default: heff_nomatch(v_x_241240);
                  }
                  V v_t_241261 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_StmtLet, 2, (V[]){v_x_241240, v_t_241257}), v_t_241260});
                  V v_t_241262 = heff_tag_n(TAG_EWith, 4, (V[]){v_x_241234, ((V)&g_heff_2esyntax_2esurface_2eexprL_str50), v_t_241253, heff_tag_n(TAG_Cons, 2, (V[]){v_t_241261, v_x_241250})});
                  V v_t_241263 = (g_heff_2esyntax_2ecst_2elastE(v_e0_241));
                  V v_e_241264 = heff_get_n(v_t_241263, 4, 9);
                  V v_t_241265 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_241074, 3, 9), v_e_241264});
                  V v_x_241266 = heff_tag_n(TAG_At, 2, (V[]){v_t_241262, v_t_241265});
                  return heff_tag_at_n(v_ru_24x1_241230_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_241266}), v_st_241248});
                }
                default: return heff_nomatch(v_x11_241247);
                }
              }
            }
            default: return heff_nomatch(v_x11_241237);
            }
          }
          default: return heff_nomatch(v_x1_241236);
          }
        }
        default: return heff_nomatch(v_x11_241231);
        }
      }
      default: return heff_nomatch(v_x1_241230);
      }
    }
    case TAG_PRec: {
      V v_m_241271 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e_241075}));
      V v_x1_241272 = heff_tr(heff_call(v_m_241271, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_241272)) {
      case TAG_MkPair: {
        V v_x11_241273 = heff_field(v_x1_241272, 0);
        V v_st_241274 = heff_field(v_x1_241272, 1);
        V v_ru_24x1_241272_24MkPair = heff_take_reuse_n(v_x1_241272, 3ULL, 2);
        switch (heff_tag_of(v_x11_241273)) {
        case TAG_Left: {
          V v_e_241275 = heff_field(v_x11_241273, 0);
          heff_take_n(v_x11_241273, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_tag(v_e0_241, 6);
          heff_drop_rec(v_kw_241074, 9);
          heff_drop_tag(v_e04_241077, 4);
          heff_drop(v_body_241079);
          return heff_tag_at_n(v_ru_24x1_241272_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241275}), v_st_241274});
        }
        case TAG_Right: {
          V v_x_241276 = heff_field(v_x11_241273, 0);
          V v_ru_24x11_241273_24Right = heff_take_reuse_n(v_x11_241273, 1ULL, 1);
          V v_m_241277 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 1)), 1, (V[]){heff_dup(v_e04_241077)}));
          V v_x1_241278 = heff_tr(heff_call(v_m_241277, 1, (V[]){v_st_241274}));
          switch (heff_tag_of(v_x1_241278)) {
          case TAG_MkPair: {
            V v_x11_241279 = heff_field(v_x1_241278, 0);
            V v_st_241280 = heff_field(v_x1_241278, 1);
            V v_ru_24x1_241278_24MkPair = heff_take_reuse_n(v_x1_241278, 3ULL, 2);
            switch (heff_tag_of(v_x11_241279)) {
            case TAG_Left: {
              V v_e_241281 = heff_field(v_x11_241279, 0);
              heff_take_n(v_x11_241279, 1ULL, 1);
              heff_drop_rec(v_r_240, 3);
              heff_drop_tag(v_e0_241, 6);
              heff_drop_rec(v_kw_241074, 9);
              heff_drop_tag(v_e04_241077, 4);
              heff_drop(v_body_241079);
              heff_drop(v_x_241276);
              heff_drop_cell(v_ru_24x11_241273_24Right, 1);
              heff_drop_cell(v_ru_24x1_241278_24MkPair, 2);
              return heff_tag_at_n(v_ru_24x1_241272_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241281}), v_st_241280});
            }
            case TAG_Right: {
              V v_x_241282 = heff_field(v_x11_241279, 0);
              heff_take_n(v_x11_241279, 1ULL, 1);
              V v_t_241283 = ({ V b_0 = NTAG(TAG_Nil); V a_1 = v_e04_241077; V r_ = (g_heff_2esyntax_2esurface_2eboundBy(b_0, a_1)); heff_drop(b_0); heff_drop_tag(v_e04_241077, 4); r_; });
              V v_t_241285 = heff_tr(heff_call(((V)&g_heff_2esyntax_2esurface_2eblock_clo), 2, (V[]){heff_clo_n(g_heff_2esyntax_2esurface_2eexprL_lam17, 1, 1, (V[]){v_r_240}), v_body_241079}));
              HeffT2 v_t_241286 = (g_heff_2esyntax_2esurface_2ewithScope_24cpr(v_t_241283, v_t_241285, v_st_241280));
              {
                V v_field_241287 = v_t_241286.f[0];
                V v_field_241288 = v_t_241286.f[1];
                V v_x11_241289 = v_field_241287;
                V v_st_241290 = v_field_241288;
                switch (heff_tag_of(v_x11_241289)) {
                case TAG_Left: {
                  V v_e_241291 = heff_field(v_x11_241289, 0);
                  heff_take_n(v_x11_241289, 1ULL, 1);
                  heff_drop_tag(v_e0_241, 6);
                  heff_drop_rec(v_kw_241074, 9);
                  heff_drop(v_x_241276);
                  heff_drop_cell(v_ru_24x11_241273_24Right, 1);
                  heff_drop_cell(v_ru_24x1_241278_24MkPair, 2);
                  heff_drop(v_x_241282);
                  return heff_tag_at_n(v_ru_24x1_241272_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241291}), v_st_241290});
                }
                case TAG_Right: {
                  V v_x_241292 = heff_field(v_x11_241289, 0);
                  heff_take_n(v_x11_241289, 1ULL, 1);
                  V v_t_241295;
                  switch (heff_tag_of(v_x_241282)) {
                  case TAG_At: {
                    V v_s_241294 = heff_dup(heff_field(v_x_241282, 1));
                    v_t_241295 = v_s_241294;
                    break;
                  }
                  default: heff_nomatch(v_x_241282);
                  }
                  V v_t_241298;
                  switch (heff_tag_of(v_x_241282)) {
                  case TAG_At: {
                    V v_s_241297 = heff_dup(heff_field(v_x_241282, 1));
                    v_t_241298 = v_s_241297;
                    break;
                  }
                  default: heff_nomatch(v_x_241282);
                  }
                  V v_t_241299 = heff_tag_at_n(v_ru_24x1_241278_24MkPair, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_241273_24Right, TAG_EVar, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2eexprL_str51)}), v_t_241298});
                  V v_t_241302;
                  switch (heff_tag_of(v_x_241282)) {
                  case TAG_At: {
                    V v_s_241301 = heff_dup(heff_field(v_x_241282, 1));
                    v_t_241302 = v_s_241301;
                    break;
                  }
                  default: heff_nomatch(v_x_241282);
                  }
                  V v_t_241303 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_StmtLet, 2, (V[]){v_x_241282, v_t_241299}), v_t_241302});
                  V v_t_241304 = heff_tag_n(TAG_EWith, 4, (V[]){v_x_241276, ((V)&g_heff_2esyntax_2esurface_2eexprL_str52), v_t_241295, heff_tag_n(TAG_Cons, 2, (V[]){v_t_241303, v_x_241292})});
                  V v_t_241305 = (g_heff_2esyntax_2ecst_2elastE(v_e0_241));
                  V v_e_241306 = heff_get_n(v_t_241305, 4, 9);
                  V v_t_241307 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_241074, 3, 9), v_e_241306});
                  V v_x_241308 = heff_tag_n(TAG_At, 2, (V[]){v_t_241304, v_t_241307});
                  return heff_tag_at_n(v_ru_24x1_241272_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_241308}), v_st_241290});
                }
                default: return heff_nomatch(v_x11_241289);
                }
              }
            }
            default: return heff_nomatch(v_x11_241279);
            }
          }
          default: return heff_nomatch(v_x1_241278);
          }
        }
        default: return heff_nomatch(v_x11_241273);
        }
      }
      default: return heff_nomatch(v_x1_241272);
      }
    }
    case TAG_PField: {
      V v_m_241312 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e_241075}));
      V v_x1_241313 = heff_tr(heff_call(v_m_241312, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_241313)) {
      case TAG_MkPair: {
        V v_x11_241314 = heff_field(v_x1_241313, 0);
        V v_st_241315 = heff_field(v_x1_241313, 1);
        V v_ru_24x1_241313_24MkPair = heff_take_reuse_n(v_x1_241313, 3ULL, 2);
        switch (heff_tag_of(v_x11_241314)) {
        case TAG_Left: {
          V v_e_241316 = heff_field(v_x11_241314, 0);
          heff_take_n(v_x11_241314, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_tag(v_e0_241, 6);
          heff_drop_rec(v_kw_241074, 9);
          heff_drop_tag(v_e04_241077, 3);
          heff_drop(v_body_241079);
          return heff_tag_at_n(v_ru_24x1_241313_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241316}), v_st_241315});
        }
        case TAG_Right: {
          V v_x_241317 = heff_field(v_x11_241314, 0);
          V v_ru_24x11_241314_24Right = heff_take_reuse_n(v_x11_241314, 1ULL, 1);
          V v_m_241318 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 1)), 1, (V[]){heff_dup(v_e04_241077)}));
          V v_x1_241319 = heff_tr(heff_call(v_m_241318, 1, (V[]){v_st_241315}));
          switch (heff_tag_of(v_x1_241319)) {
          case TAG_MkPair: {
            V v_x11_241320 = heff_field(v_x1_241319, 0);
            V v_st_241321 = heff_field(v_x1_241319, 1);
            V v_ru_24x1_241319_24MkPair = heff_take_reuse_n(v_x1_241319, 3ULL, 2);
            switch (heff_tag_of(v_x11_241320)) {
            case TAG_Left: {
              V v_e_241322 = heff_field(v_x11_241320, 0);
              heff_take_n(v_x11_241320, 1ULL, 1);
              heff_drop_rec(v_r_240, 3);
              heff_drop_tag(v_e0_241, 6);
              heff_drop_rec(v_kw_241074, 9);
              heff_drop_tag(v_e04_241077, 3);
              heff_drop(v_body_241079);
              heff_drop(v_x_241317);
              heff_drop_cell(v_ru_24x11_241314_24Right, 1);
              heff_drop_cell(v_ru_24x1_241319_24MkPair, 2);
              return heff_tag_at_n(v_ru_24x1_241313_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241322}), v_st_241321});
            }
            case TAG_Right: {
              V v_x_241323 = heff_field(v_x11_241320, 0);
              heff_take_n(v_x11_241320, 1ULL, 1);
              V v_t_241324 = ({ V b_0 = NTAG(TAG_Nil); V a_1 = v_e04_241077; V r_ = (g_heff_2esyntax_2esurface_2eboundBy(b_0, a_1)); heff_drop(b_0); heff_drop_tag(v_e04_241077, 3); r_; });
              V v_t_241326 = heff_tr(heff_call(((V)&g_heff_2esyntax_2esurface_2eblock_clo), 2, (V[]){heff_clo_n(g_heff_2esyntax_2esurface_2eexprL_lam18, 1, 1, (V[]){v_r_240}), v_body_241079}));
              HeffT2 v_t_241327 = (g_heff_2esyntax_2esurface_2ewithScope_24cpr(v_t_241324, v_t_241326, v_st_241321));
              {
                V v_field_241328 = v_t_241327.f[0];
                V v_field_241329 = v_t_241327.f[1];
                V v_x11_241330 = v_field_241328;
                V v_st_241331 = v_field_241329;
                switch (heff_tag_of(v_x11_241330)) {
                case TAG_Left: {
                  V v_e_241332 = heff_field(v_x11_241330, 0);
                  heff_take_n(v_x11_241330, 1ULL, 1);
                  heff_drop_tag(v_e0_241, 6);
                  heff_drop_rec(v_kw_241074, 9);
                  heff_drop(v_x_241317);
                  heff_drop_cell(v_ru_24x11_241314_24Right, 1);
                  heff_drop_cell(v_ru_24x1_241319_24MkPair, 2);
                  heff_drop(v_x_241323);
                  return heff_tag_at_n(v_ru_24x1_241313_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241332}), v_st_241331});
                }
                case TAG_Right: {
                  V v_x_241333 = heff_field(v_x11_241330, 0);
                  heff_take_n(v_x11_241330, 1ULL, 1);
                  V v_t_241336;
                  switch (heff_tag_of(v_x_241323)) {
                  case TAG_At: {
                    V v_s_241335 = heff_dup(heff_field(v_x_241323, 1));
                    v_t_241336 = v_s_241335;
                    break;
                  }
                  default: heff_nomatch(v_x_241323);
                  }
                  V v_t_241339;
                  switch (heff_tag_of(v_x_241323)) {
                  case TAG_At: {
                    V v_s_241338 = heff_dup(heff_field(v_x_241323, 1));
                    v_t_241339 = v_s_241338;
                    break;
                  }
                  default: heff_nomatch(v_x_241323);
                  }
                  V v_t_241340 = heff_tag_at_n(v_ru_24x1_241319_24MkPair, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_241314_24Right, TAG_EVar, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2eexprL_str53)}), v_t_241339});
                  V v_t_241343;
                  switch (heff_tag_of(v_x_241323)) {
                  case TAG_At: {
                    V v_s_241342 = heff_dup(heff_field(v_x_241323, 1));
                    v_t_241343 = v_s_241342;
                    break;
                  }
                  default: heff_nomatch(v_x_241323);
                  }
                  V v_t_241344 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_StmtLet, 2, (V[]){v_x_241323, v_t_241340}), v_t_241343});
                  V v_t_241345 = heff_tag_n(TAG_EWith, 4, (V[]){v_x_241317, ((V)&g_heff_2esyntax_2esurface_2eexprL_str54), v_t_241336, heff_tag_n(TAG_Cons, 2, (V[]){v_t_241344, v_x_241333})});
                  V v_t_241346 = (g_heff_2esyntax_2ecst_2elastE(v_e0_241));
                  V v_e_241347 = heff_get_n(v_t_241346, 4, 9);
                  V v_t_241348 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_241074, 3, 9), v_e_241347});
                  V v_x_241349 = heff_tag_n(TAG_At, 2, (V[]){v_t_241345, v_t_241348});
                  return heff_tag_at_n(v_ru_24x1_241313_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_241349}), v_st_241331});
                }
                default: return heff_nomatch(v_x11_241330);
                }
              }
            }
            default: return heff_nomatch(v_x11_241320);
            }
          }
          default: return heff_nomatch(v_x1_241319);
          }
        }
        default: return heff_nomatch(v_x11_241314);
        }
      }
      default: return heff_nomatch(v_x1_241313);
      }
    }
    case TAG_PAs: {
      V v_m_241353 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e_241075}));
      V v_x1_241354 = heff_tr(heff_call(v_m_241353, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_241354)) {
      case TAG_MkPair: {
        V v_x11_241355 = heff_field(v_x1_241354, 0);
        V v_st_241356 = heff_field(v_x1_241354, 1);
        V v_ru_24x1_241354_24MkPair = heff_take_reuse_n(v_x1_241354, 3ULL, 2);
        switch (heff_tag_of(v_x11_241355)) {
        case TAG_Left: {
          V v_e_241357 = heff_field(v_x11_241355, 0);
          heff_take_n(v_x11_241355, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_tag(v_e0_241, 6);
          heff_drop_rec(v_kw_241074, 9);
          heff_drop_tag(v_e04_241077, 3);
          heff_drop(v_body_241079);
          return heff_tag_at_n(v_ru_24x1_241354_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241357}), v_st_241356});
        }
        case TAG_Right: {
          V v_x_241358 = heff_field(v_x11_241355, 0);
          V v_ru_24x11_241355_24Right = heff_take_reuse_n(v_x11_241355, 1ULL, 1);
          V v_m_241359 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 1)), 1, (V[]){heff_dup(v_e04_241077)}));
          V v_x1_241360 = heff_tr(heff_call(v_m_241359, 1, (V[]){v_st_241356}));
          switch (heff_tag_of(v_x1_241360)) {
          case TAG_MkPair: {
            V v_x11_241361 = heff_field(v_x1_241360, 0);
            V v_st_241362 = heff_field(v_x1_241360, 1);
            V v_ru_24x1_241360_24MkPair = heff_take_reuse_n(v_x1_241360, 3ULL, 2);
            switch (heff_tag_of(v_x11_241361)) {
            case TAG_Left: {
              V v_e_241363 = heff_field(v_x11_241361, 0);
              heff_take_n(v_x11_241361, 1ULL, 1);
              heff_drop_rec(v_r_240, 3);
              heff_drop_tag(v_e0_241, 6);
              heff_drop_rec(v_kw_241074, 9);
              heff_drop_tag(v_e04_241077, 3);
              heff_drop(v_body_241079);
              heff_drop(v_x_241358);
              heff_drop_cell(v_ru_24x11_241355_24Right, 1);
              heff_drop_cell(v_ru_24x1_241360_24MkPair, 2);
              return heff_tag_at_n(v_ru_24x1_241354_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241363}), v_st_241362});
            }
            case TAG_Right: {
              V v_x_241364 = heff_field(v_x11_241361, 0);
              heff_take_n(v_x11_241361, 1ULL, 1);
              V v_t_241365 = ({ V b_0 = NTAG(TAG_Nil); V a_1 = v_e04_241077; V r_ = (g_heff_2esyntax_2esurface_2eboundBy(b_0, a_1)); heff_drop(b_0); heff_drop_tag(v_e04_241077, 3); r_; });
              V v_t_241367 = heff_tr(heff_call(((V)&g_heff_2esyntax_2esurface_2eblock_clo), 2, (V[]){heff_clo_n(g_heff_2esyntax_2esurface_2eexprL_lam19, 1, 1, (V[]){v_r_240}), v_body_241079}));
              HeffT2 v_t_241368 = (g_heff_2esyntax_2esurface_2ewithScope_24cpr(v_t_241365, v_t_241367, v_st_241362));
              {
                V v_field_241369 = v_t_241368.f[0];
                V v_field_241370 = v_t_241368.f[1];
                V v_x11_241371 = v_field_241369;
                V v_st_241372 = v_field_241370;
                switch (heff_tag_of(v_x11_241371)) {
                case TAG_Left: {
                  V v_e_241373 = heff_field(v_x11_241371, 0);
                  heff_take_n(v_x11_241371, 1ULL, 1);
                  heff_drop_tag(v_e0_241, 6);
                  heff_drop_rec(v_kw_241074, 9);
                  heff_drop(v_x_241358);
                  heff_drop_cell(v_ru_24x11_241355_24Right, 1);
                  heff_drop_cell(v_ru_24x1_241360_24MkPair, 2);
                  heff_drop(v_x_241364);
                  return heff_tag_at_n(v_ru_24x1_241354_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241373}), v_st_241372});
                }
                case TAG_Right: {
                  V v_x_241374 = heff_field(v_x11_241371, 0);
                  heff_take_n(v_x11_241371, 1ULL, 1);
                  V v_t_241377;
                  switch (heff_tag_of(v_x_241364)) {
                  case TAG_At: {
                    V v_s_241376 = heff_dup(heff_field(v_x_241364, 1));
                    v_t_241377 = v_s_241376;
                    break;
                  }
                  default: heff_nomatch(v_x_241364);
                  }
                  V v_t_241380;
                  switch (heff_tag_of(v_x_241364)) {
                  case TAG_At: {
                    V v_s_241379 = heff_dup(heff_field(v_x_241364, 1));
                    v_t_241380 = v_s_241379;
                    break;
                  }
                  default: heff_nomatch(v_x_241364);
                  }
                  V v_t_241381 = heff_tag_at_n(v_ru_24x1_241360_24MkPair, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_241355_24Right, TAG_EVar, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2eexprL_str55)}), v_t_241380});
                  V v_t_241384;
                  switch (heff_tag_of(v_x_241364)) {
                  case TAG_At: {
                    V v_s_241383 = heff_dup(heff_field(v_x_241364, 1));
                    v_t_241384 = v_s_241383;
                    break;
                  }
                  default: heff_nomatch(v_x_241364);
                  }
                  V v_t_241385 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_StmtLet, 2, (V[]){v_x_241364, v_t_241381}), v_t_241384});
                  V v_t_241386 = heff_tag_n(TAG_EWith, 4, (V[]){v_x_241358, ((V)&g_heff_2esyntax_2esurface_2eexprL_str56), v_t_241377, heff_tag_n(TAG_Cons, 2, (V[]){v_t_241385, v_x_241374})});
                  V v_t_241387 = (g_heff_2esyntax_2ecst_2elastE(v_e0_241));
                  V v_e_241388 = heff_get_n(v_t_241387, 4, 9);
                  V v_t_241389 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_241074, 3, 9), v_e_241388});
                  V v_x_241390 = heff_tag_n(TAG_At, 2, (V[]){v_t_241386, v_t_241389});
                  return heff_tag_at_n(v_ru_24x1_241354_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_241390}), v_st_241372});
                }
                default: return heff_nomatch(v_x11_241371);
                }
              }
            }
            default: return heff_nomatch(v_x11_241361);
            }
          }
          default: return heff_nomatch(v_x1_241360);
          }
        }
        default: return heff_nomatch(v_x11_241355);
        }
      }
      default: return heff_nomatch(v_x1_241354);
      }
    }
    case TAG_PSeg: {
      V v_m_241394 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e_241075}));
      V v_x1_241395 = heff_tr(heff_call(v_m_241394, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_241395)) {
      case TAG_MkPair: {
        V v_x11_241396 = heff_field(v_x1_241395, 0);
        V v_st_241397 = heff_field(v_x1_241395, 1);
        V v_ru_24x1_241395_24MkPair = heff_take_reuse_n(v_x1_241395, 3ULL, 2);
        switch (heff_tag_of(v_x11_241396)) {
        case TAG_Left: {
          V v_e_241398 = heff_field(v_x11_241396, 0);
          heff_take_n(v_x11_241396, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_tag(v_e0_241, 6);
          heff_drop_rec(v_kw_241074, 9);
          heff_drop_tag(v_e04_241077, 3);
          heff_drop(v_body_241079);
          return heff_tag_at_n(v_ru_24x1_241395_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241398}), v_st_241397});
        }
        case TAG_Right: {
          V v_x_241399 = heff_field(v_x11_241396, 0);
          V v_ru_24x11_241396_24Right = heff_take_reuse_n(v_x11_241396, 1ULL, 1);
          V v_m_241400 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 1)), 1, (V[]){heff_dup(v_e04_241077)}));
          V v_x1_241401 = heff_tr(heff_call(v_m_241400, 1, (V[]){v_st_241397}));
          switch (heff_tag_of(v_x1_241401)) {
          case TAG_MkPair: {
            V v_x11_241402 = heff_field(v_x1_241401, 0);
            V v_st_241403 = heff_field(v_x1_241401, 1);
            V v_ru_24x1_241401_24MkPair = heff_take_reuse_n(v_x1_241401, 3ULL, 2);
            switch (heff_tag_of(v_x11_241402)) {
            case TAG_Left: {
              V v_e_241404 = heff_field(v_x11_241402, 0);
              heff_take_n(v_x11_241402, 1ULL, 1);
              heff_drop_rec(v_r_240, 3);
              heff_drop_tag(v_e0_241, 6);
              heff_drop_rec(v_kw_241074, 9);
              heff_drop_tag(v_e04_241077, 3);
              heff_drop(v_body_241079);
              heff_drop(v_x_241399);
              heff_drop_cell(v_ru_24x11_241396_24Right, 1);
              heff_drop_cell(v_ru_24x1_241401_24MkPair, 2);
              return heff_tag_at_n(v_ru_24x1_241395_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241404}), v_st_241403});
            }
            case TAG_Right: {
              V v_x_241405 = heff_field(v_x11_241402, 0);
              heff_take_n(v_x11_241402, 1ULL, 1);
              V v_t_241406 = ({ V b_0 = NTAG(TAG_Nil); V a_1 = v_e04_241077; V r_ = (g_heff_2esyntax_2esurface_2eboundBy(b_0, a_1)); heff_drop(b_0); heff_drop_tag(v_e04_241077, 3); r_; });
              V v_t_241408 = heff_tr(heff_call(((V)&g_heff_2esyntax_2esurface_2eblock_clo), 2, (V[]){heff_clo_n(g_heff_2esyntax_2esurface_2eexprL_lam20, 1, 1, (V[]){v_r_240}), v_body_241079}));
              HeffT2 v_t_241409 = (g_heff_2esyntax_2esurface_2ewithScope_24cpr(v_t_241406, v_t_241408, v_st_241403));
              {
                V v_field_241410 = v_t_241409.f[0];
                V v_field_241411 = v_t_241409.f[1];
                V v_x11_241412 = v_field_241410;
                V v_st_241413 = v_field_241411;
                switch (heff_tag_of(v_x11_241412)) {
                case TAG_Left: {
                  V v_e_241414 = heff_field(v_x11_241412, 0);
                  heff_take_n(v_x11_241412, 1ULL, 1);
                  heff_drop_tag(v_e0_241, 6);
                  heff_drop_rec(v_kw_241074, 9);
                  heff_drop(v_x_241399);
                  heff_drop_cell(v_ru_24x11_241396_24Right, 1);
                  heff_drop_cell(v_ru_24x1_241401_24MkPair, 2);
                  heff_drop(v_x_241405);
                  return heff_tag_at_n(v_ru_24x1_241395_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241414}), v_st_241413});
                }
                case TAG_Right: {
                  V v_x_241415 = heff_field(v_x11_241412, 0);
                  heff_take_n(v_x11_241412, 1ULL, 1);
                  V v_t_241418;
                  switch (heff_tag_of(v_x_241405)) {
                  case TAG_At: {
                    V v_s_241417 = heff_dup(heff_field(v_x_241405, 1));
                    v_t_241418 = v_s_241417;
                    break;
                  }
                  default: heff_nomatch(v_x_241405);
                  }
                  V v_t_241421;
                  switch (heff_tag_of(v_x_241405)) {
                  case TAG_At: {
                    V v_s_241420 = heff_dup(heff_field(v_x_241405, 1));
                    v_t_241421 = v_s_241420;
                    break;
                  }
                  default: heff_nomatch(v_x_241405);
                  }
                  V v_t_241422 = heff_tag_at_n(v_ru_24x1_241401_24MkPair, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_241396_24Right, TAG_EVar, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2eexprL_str57)}), v_t_241421});
                  V v_t_241425;
                  switch (heff_tag_of(v_x_241405)) {
                  case TAG_At: {
                    V v_s_241424 = heff_dup(heff_field(v_x_241405, 1));
                    v_t_241425 = v_s_241424;
                    break;
                  }
                  default: heff_nomatch(v_x_241405);
                  }
                  V v_t_241426 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_StmtLet, 2, (V[]){v_x_241405, v_t_241422}), v_t_241425});
                  V v_t_241427 = heff_tag_n(TAG_EWith, 4, (V[]){v_x_241399, ((V)&g_heff_2esyntax_2esurface_2eexprL_str58), v_t_241418, heff_tag_n(TAG_Cons, 2, (V[]){v_t_241426, v_x_241415})});
                  V v_t_241428 = (g_heff_2esyntax_2ecst_2elastE(v_e0_241));
                  V v_e_241429 = heff_get_n(v_t_241428, 4, 9);
                  V v_t_241430 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_241074, 3, 9), v_e_241429});
                  V v_x_241431 = heff_tag_n(TAG_At, 2, (V[]){v_t_241427, v_t_241430});
                  return heff_tag_at_n(v_ru_24x1_241395_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_241431}), v_st_241413});
                }
                default: return heff_nomatch(v_x11_241412);
                }
              }
            }
            default: return heff_nomatch(v_x11_241402);
            }
          }
          default: return heff_nomatch(v_x1_241401);
          }
        }
        default: return heff_nomatch(v_x11_241396);
        }
      }
      default: return heff_nomatch(v_x1_241395);
      }
    }
    default: return heff_nomatch(v_e04_241077);
    }
  }
  default: return heff_nomatch(v_e0_241);
  }
}
V g_heff_2esyntax_2esurface_2eexprL_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2eexprL(a[0], a[1], a[2]);
}
V g_heff_2esyntax_2esurface_2eexprL_lam0(V self, V *args) {
  V v_m_2431 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2esyntax_2esurface_2esegmentL(v_r_240, v_m_2431));
}
V g_heff_2esyntax_2esurface_2eexprL_lam1(V self, V *args) {
  V v_x_2449 = args[0];
  V v_rest_2450 = args[1];
  V v_sp_2447 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2451 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ETag, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2eexprL_str8)}), v_sp_2447});
  V v_t_2452 = heff_tag_n(TAG_Cons, 2, (V[]){v_rest_2450, NTAG(TAG_Nil)});
  return (g_heff_2esyntax_2epresyntax_2eapp(v_t_2451, heff_tag_n(TAG_Cons, 2, (V[]){v_x_2449, v_t_2452})));
}
V g_heff_2esyntax_2esurface_2eexprL_lam2(V self, V *args) {
  V v_m_2487 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2esyntax_2esurface_2eupdateSettingL(v_r_240, v_m_2487));
}
V g_heff_2esyntax_2esurface_2eexprL_lam3(V self, V *args) {
  V v_a_24141 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2esyntax_2esurface_2evariantL(v_r_240, v_a_24141));
}
V g_heff_2esyntax_2esurface_2eexprL_lam4(V self, V *args) {
  V v_m_24696 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2esyntax_2esurface_2eargL(v_r_240, v_m_24696));
}
V g_heff_2esyntax_2esurface_2eexprL_lam6(V self, V *args) {
  V v_st_24722 = args[0];
  V v_m_24721 = heff_env(self)[0];
  V v_op_24719 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24723 = heff_tr(heff_call(v_m_24721, 1, (V[]){v_st_24722}));
  switch (heff_tag_of(v_x1_24723)) {
  case TAG_MkPair: {
    V v_x11_24724 = heff_field(v_x1_24723, 0);
    V v_st_24725 = heff_field(v_x1_24723, 1);
    V v_ru_24x1_24723_24MkPair = heff_take_reuse_n(v_x1_24723, 3ULL, 2);
    switch (heff_tag_of(v_x11_24724)) {
    case TAG_Left: {
      V v_e_24726 = heff_field(v_x11_24724, 0);
      heff_take_n(v_x11_24724, 1ULL, 1);
      heff_drop(v_op_24719);
      return heff_tag_at_n(v_ru_24x1_24723_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24726}), v_st_24725});
    }
    case TAG_Right: {
      V v_x_24727 = heff_field(v_x11_24724, 0);
      V v_ru_24x11_24724_24Right = heff_take_reuse_n(v_x11_24724, 1ULL, 1);
      V v_t_24728 = heff_tag_at_n(v_ru_24x11_24724_24Right, TAG_Right, 1, (V[]){heff_rec_n(2, shape_op__e, (V[]){v_op_24719, v_x_24727})});
      return heff_tag_at_n(v_ru_24x1_24723_24MkPair, TAG_MkPair, 2, (V[]){v_t_24728, v_st_24725});
    }
    default: return heff_nomatch(v_x11_24724);
    }
  }
  default: return heff_nomatch(v_x1_24723);
  }
}
V g_heff_2esyntax_2esurface_2eexprL_lam5(V self, V *args) {
  V v_m_24715 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_24716 = (g_heff_2esyntax_2esurface_2eopRhsOf_24cpr(v_m_24715));
  {
    V v_field_24717 = v_t_24716.f[0];
    V v_field_24718 = v_t_24716.f[1];
    V v_op_24719 = v_field_24717;
    V v_e_24720 = v_field_24718;
    V v_m_24721 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_24720}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2eexprL_lam6, 1, 2, (V[]){v_m_24721, v_op_24719});
  }
}
V g_heff_2esyntax_2esurface_2eexprL_lam7(V self, V *args) {
  V v_a_24814 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2esyntax_2esurface_2ealtL(v_r_240, v_a_24814));
}
V g_heff_2esyntax_2esurface_2eexprL_lam8(V self, V *args) {
  V v_m_24865 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2esyntax_2esurface_2estmtL(v_r_240, v_m_24865));
}
V g_heff_2esyntax_2esurface_2eexprL_lam9(V self, V *args) {
  V v_m_24942 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2esyntax_2esurface_2estmtL(v_r_240, v_m_24942));
}
V g_heff_2esyntax_2esurface_2eexprL_lam10(V self, V *args) {
  V v_m_24973 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2esyntax_2esurface_2estmtL(v_r_240, v_m_24973));
}
V g_heff_2esyntax_2esurface_2eexprL_lam11(V self, V *args) {
  V v_m_241045 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2esyntax_2esurface_2estmtL(v_r_240, v_m_241045));
}
V g_heff_2esyntax_2esurface_2eexprL_lam12(V self, V *args) {
  V v_m_241095 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2esyntax_2esurface_2estmtL(v_r_240, v_m_241095));
}
V g_heff_2esyntax_2esurface_2eexprL_lam13(V self, V *args) {
  V v_m_241128 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2esyntax_2esurface_2estmtL(v_r_240, v_m_241128));
}
V g_heff_2esyntax_2esurface_2eexprL_lam14(V self, V *args) {
  V v_m_241159 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2esyntax_2esurface_2estmtL(v_r_240, v_m_241159));
}
V g_heff_2esyntax_2esurface_2eexprL_lam15(V self, V *args) {
  V v_m_241201 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2esyntax_2esurface_2estmtL(v_r_240, v_m_241201));
}
V g_heff_2esyntax_2esurface_2eexprL_lam16(V self, V *args) {
  V v_m_241242 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2esyntax_2esurface_2estmtL(v_r_240, v_m_241242));
}
V g_heff_2esyntax_2esurface_2eexprL_lam17(V self, V *args) {
  V v_m_241284 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2esyntax_2esurface_2estmtL(v_r_240, v_m_241284));
}
V g_heff_2esyntax_2esurface_2eexprL_lam18(V self, V *args) {
  V v_m_241325 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2esyntax_2esurface_2estmtL(v_r_240, v_m_241325));
}
V g_heff_2esyntax_2esurface_2eexprL_lam19(V self, V *args) {
  V v_m_241366 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2esyntax_2esurface_2estmtL(v_r_240, v_m_241366));
}
V g_heff_2esyntax_2esurface_2eexprL_lam20(V self, V *args) {
  V v_m_241407 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2esyntax_2esurface_2estmtL(v_r_240, v_m_241407));
}
HEFF_LIT(g_heff_2esyntax_2esurface_2edeclNameOf_24cpr_str0, 0, "");

HeffT2 g_heff_2esyntax_2esurface_2edeclNameOf_24cpr(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return ((HeffT2){{((V)&g_heff_2esyntax_2esurface_2edeclNameOf_24cpr_str0), heff_rec_n(2, shape_start__end, (V[]){MK_INT(0LL), MK_INT(0LL)})}});
  }
  case TAG_Cons: {
    V v_t_241 = heff_field(v_x1_240, 0);
    V v_x12_242 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x12_242)) {
    case TAG_Nil: {
      V v_f_243 = heff_take_field(v_t_241, 1);
      V v_f_244 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_241, 3), heff_get_n(v_t_241, 4, 9)});
      return ((HeffT2){{v_f_243, v_f_244}});
    }
    case TAG_Cons: {
      V v_op_245 = heff_field(v_x12_242, 0);
      V v_x122_246 = heff_field(v_x12_242, 1);
      heff_take_n(v_x12_242, 3ULL, 2);
      switch (heff_tag_of(v_x122_246)) {
      case TAG_Nil: {
        heff_drop_rec(v_op_245, 9);
        V v_f_247 = heff_take_field(v_t_241, 1);
        V v_f_248 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_241, 3), heff_get_n(v_t_241, 4, 9)});
        return ((HeffT2){{v_f_247, v_f_248}});
      }
      case TAG_Cons: {
        V v_x1222_2410 = heff_field(v_x122_246, 1);
        heff_take_n(v_x122_246, 2ULL, 2);
        switch (heff_tag_of(v_x1222_2410)) {
        case TAG_Nil: {
          heff_drop_rec(v_t_241, 9);
          V v_f_2411 = heff_take_field(v_op_245, 1);
          V v_f_2412 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_op_245, 3), heff_get_n(v_op_245, 4, 9)});
          return ((HeffT2){{v_f_2411, v_f_2412}});
        }
        case TAG_Cons: {
          heff_take_n(v_x1222_2410, 0ULL, 2);
          heff_drop_rec(v_op_245, 9);
          V v_f_2415 = heff_take_field(v_t_241, 1);
          V v_f_2416 = heff_rec_n(2, shape_start__end, (V[]){heff_take_field(v_t_241, 3), heff_get_n(v_t_241, 4, 9)});
          return ((HeffT2){{v_f_2415, v_f_2416}});
        }
        default: return ((HeffT2){{heff_nomatch(v_x1222_2410)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x122_246)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x12_242)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
V g_heff_2esyntax_2esurface_2edefaultL_lam0(V self, V *args); static Clo g_heff_2esyntax_2esurface_2edefaultL_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2edefaultL_lam0, 1, 0};
V g_heff_2esyntax_2esurface_2edefaultL_lam1(V self, V *args);
Clo g_heff_2esyntax_2esurface_2edefaultL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2edefaultL_entry, 2, 0};

V g_heff_2esyntax_2esurface_2edefaultL(V v_r_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nothing: {
    heff_drop_rec(v_r_240, 3);
    return ((V)&g_heff_2esyntax_2esurface_2edefaultL_lam0_clo);
  }
  case TAG_Just: {
    V v_x21_244 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    switch (heff_tag_of(v_x21_244)) {
    case TAG_MkPair: {
      V v_d_246 = heff_field(v_x21_244, 1);
      heff_take_n(v_x21_244, 2ULL, 2);
      V v_m_247 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_d_246}));
      return heff_clo_n(g_heff_2esyntax_2esurface_2edefaultL_lam1, 1, 1, (V[]){v_m_247});
    }
    default: return heff_nomatch(v_x21_244);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2esurface_2edefaultL_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2edefaultL(a[0], a[1]);
}
V g_heff_2esyntax_2esurface_2edefaultL_lam0(V self, V *args) {
  V v_st_242 = args[0];
  V v_t_243 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_243, v_st_242});
}
V g_heff_2esyntax_2esurface_2edefaultL_lam1(V self, V *args) {
  V v_st_248 = args[0];
  V v_m_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_249 = heff_tr(heff_call(v_m_247, 1, (V[]){v_st_248}));
  switch (heff_tag_of(v_x1_249)) {
  case TAG_MkPair: {
    V v_x11_2410 = heff_field(v_x1_249, 0);
    V v_st_2411 = heff_field(v_x1_249, 1);
    V v_ru_24x1_249_24MkPair = heff_take_reuse_n(v_x1_249, 3ULL, 2);
    switch (heff_tag_of(v_x11_2410)) {
    case TAG_Left: {
      V v_e_2412 = heff_field(v_x11_2410, 0);
      heff_take_n(v_x11_2410, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_249_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2412}), v_st_2411});
    }
    case TAG_Right: {
      V v_x_2413 = heff_field(v_x11_2410, 0);
      V v_ru_24x11_2410_24Right = heff_take_reuse_n(v_x11_2410, 1ULL, 1);
      V v_t_2414 = heff_tag_at_n(v_ru_24x11_2410_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Just, 1, (V[]){v_x_2413})});
      return heff_tag_at_n(v_ru_24x1_249_24MkPair, TAG_MkPair, 2, (V[]){v_t_2414, v_st_2411});
    }
    default: return heff_nomatch(v_x11_2410);
    }
  }
  default: return heff_nomatch(v_x1_249);
  }
}
Clo g_heff_2esyntax_2esurface_2erightsOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2erightsOf_entry, 1, 0};

V g_heff_2esyntax_2esurface_2erightsOf(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_Left: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Right: {
      V v_x_244 = heff_field(v_x11_241, 0);
      heff_take_n(v_x11_241, 1ULL, 1);
      V v_cell_245 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_244, heff_hole()});
      V v_u_246 = (g_heff_2esyntax_2esurface_2erightsOf_24dps(v_rest_242, heff_dup(v_cell_245)));
      heff_drop(v_u_246);
      return v_cell_245;
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2esurface_2erightsOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2erightsOf(a[0]);
}