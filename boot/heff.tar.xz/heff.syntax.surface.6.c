// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Ann 13421
#define TAG_App 13485
#define TAG_At 8900
#define TAG_Atom 28502
#define TAG_BAnn 9252
#define TAG_BImp 16911
#define TAG_BPat 23270
#define TAG_BVar 29034
#define TAG_Braces 8205
#define TAG_Case 4415
#define TAG_Do 8988
#define TAG_EAlt 33043
#define TAG_EAnn 33099
#define TAG_EArrow 13977
#define TAG_EAssign 4102
#define TAG_EBinary 42634
#define TAG_EBreak 7195
#define TAG_ECatch 45587
#define TAG_ECon 35052
#define TAG_EContinue 48638
#define TAG_EDo 15964
#define TAG_EFDefault 38038
#define TAG_EFSet 34673
#define TAG_EField 26142
#define TAG_EFor 37939
#define TAG_EIfThen 2245
#define TAG_EInvalid 31081
#define TAG_EJump 55703
#define TAG_ELazy 30951
#define TAG_ELet 43397
#define TAG_ELetElse 15726
#define TAG_ELetIn 22786
#define TAG_ELetMut 54984
#define TAG_EMatch 41631
#define TAG_ENeg 45306
#define TAG_ENest 28629
#define TAG_EParen 58248
#define TAG_EReturn 59059
#define TAG_ESBind 62182
#define TAG_ESum 50613
#define TAG_ETag 50948
#define TAG_ETilde 53294
#define TAG_ETry 51493
#define TAG_ETuple 21722
#define TAG_EUSet 22856
#define TAG_EUpdate 6986
#define TAG_EVar 52881
#define TAG_EWhile 39339
#define TAG_EWith 38507
#define TAG_FloatValue 23118
#define TAG_If 9134
#define TAG_IfThen 36069
#define TAG_InstB 37114
#define TAG_IntValue 62477
#define TAG_Lam 23588
#define TAG_Left 13886
#define TAG_MkAlt 55173
#define TAG_MkSegment 38079
#define TAG_MkTry 8097
#define TAG_Named 2049
#define TAG_Op 9330
#define TAG_OpRhs 36076
#define TAG_Ops 26942
#define TAG_OtherValue 43098
#define TAG_PAs 26446
#define TAG_PAtom 50987
#define TAG_PCon 35123
#define TAG_PField 28847
#define TAG_PList 40618
#define TAG_POp 26877
#define TAG_PParen 60953
#define TAG_PRec 49217
#define TAG_PSeg 50182
#define TAG_Right 62770
#define TAG_RuneValue 49425
#define TAG_SError 24172
#define TAG_Seg 30433
#define TAG_SegmentBinary 41188
#define TAG_SegmentBits 43687
#define TAG_SegmentFloat 21180
#define TAG_SegmentInteger 22664
#define TAG_SegmentUtf 5205
#define TAG_SizeDefault 11444
#define TAG_StmtLet 16809
#define TAG_StrValue 22621
#define TAG_Sum 30935
#define TAG_Tup 31899
#define TAG_Update 40810
#define LBL_code 9554612
#define LBL_e 319
#define LBL_end 310101
#define LBL_kind 9787483
#define LBL_little 844663329
#define LBL_msg 317947
#define LBL_note 9882809
#define LBL_op 10312
#define LBL_ops 319788
#define LBL_out 319944
#define LBL_pat 320285
#define LBL_severity 75955546
#define LBL_signed 1044674119
#define LBL_size 10026184
#define LBL_span 10032145
#define LBL_start 311115900
#define LBL_text 10052084
#define LBL_ty 10476
#define LBL_unit 10090059
static uint32_t shape_code__severity__msg__span__note[] = {LBL_code, LBL_severity, LBL_msg, LBL_span, LBL_note};
static uint32_t shape_op__e[] = {LBL_op, LBL_e};
static uint32_t shape_ops__out[] = {LBL_ops, LBL_out};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
static uint32_t shape_ty__size__unit__little__signed[] = {LBL_ty, LBL_size, LBL_unit, LBL_little, LBL_signed};
V g_heff_2esyntax_2ecst_2efirstE(V);
V g_heff_2esyntax_2ecst_2efirstE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2efirstE_clo;
V g_heff_2esyntax_2ecst_2elastE(V);
V g_heff_2esyntax_2ecst_2elastE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2ecst_2elastE_clo;
V g_heff_2esyntax_2epresyntax_2eapp(V, V);
V g_heff_2esyntax_2epresyntax_2eapp_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2eapp_clo;
V g_heff_2esyntax_2esurface_2ealtL(V, V);
V g_heff_2esyntax_2esurface_2ealtL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ealtL_clo;
V g_heff_2esyntax_2esurface_2eappendS_24dps(V, V, V);
V g_heff_2esyntax_2esurface_2eappendS_24dps_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eappendS_24dps_clo;
V g_heff_2esyntax_2esurface_2eappendS_24tok2(V, V, V);
V g_heff_2esyntax_2esurface_2eappendS_24tok2_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eappendS_24tok2_clo;
V g_heff_2esyntax_2esurface_2eapplyOp(V, V, V);
V g_heff_2esyntax_2esurface_2eapplyOp_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eapplyOp_clo;
V g_heff_2esyntax_2esurface_2eargL(V, V);
V g_heff_2esyntax_2esurface_2eargL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eargL_clo;
V g_heff_2esyntax_2esurface_2eatomTok(V);
V g_heff_2esyntax_2esurface_2eatomTok_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eatomTok_clo;
V g_heff_2esyntax_2esurface_2eblock(V, V, V);
V g_heff_2esyntax_2esurface_2eblock_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eblock_clo;
HeffT2 g_heff_2esyntax_2esurface_2eblock_24cpr(V, V, V);
V g_heff_2esyntax_2esurface_2eboundBy(V, V);
V g_heff_2esyntax_2esurface_2eboundBy_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eboundBy_clo;
V g_heff_2esyntax_2esurface_2ebracesL(V, V, V, V, V);
V g_heff_2esyntax_2esurface_2ebracesL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ebracesL_clo;
V g_heff_2esyntax_2esurface_2ecatchL(V, V);
V g_heff_2esyntax_2esurface_2ecatchL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ecatchL_clo;
V g_heff_2esyntax_2esurface_2ecommentLinesFrom(V, V, V);
V g_heff_2esyntax_2esurface_2ecommentLinesFrom_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ecommentLinesFrom_clo;
V g_heff_2esyntax_2esurface_2econAtom(V, V, V);
V g_heff_2esyntax_2esurface_2econAtom_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2econAtom_clo;
V g_heff_2esyntax_2esurface_2econL(V, V, V);
V g_heff_2esyntax_2esurface_2econL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2econL_clo;
HeffT2 g_heff_2esyntax_2esurface_2edeclNameOf_24cpr(V);
V g_heff_2esyntax_2esurface_2edeclarationL(V, V);
V g_heff_2esyntax_2esurface_2edeclarationL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2edeclarationL_clo;
V g_heff_2esyntax_2esurface_2edefaultL(V, V);
V g_heff_2esyntax_2esurface_2edefaultL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2edefaultL_clo;
V g_heff_2esyntax_2esurface_2eexprL(V, V, V);
V g_heff_2esyntax_2esurface_2eexprL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eexprL_clo;
HeffT2 g_heff_2esyntax_2esurface_2efieldsOf_24cpr(V, V);
V g_heff_2esyntax_2esurface_2efirstS(V, V, V, V);
V g_heff_2esyntax_2esurface_2efirstS_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2efirstS_clo;
V g_heff_2esyntax_2esurface_2efoldr(V, V, V);
V g_heff_2esyntax_2esurface_2efoldr_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2efoldr_clo;
V g_heff_2esyntax_2esurface_2eifE(V, V, V, V);
V g_heff_2esyntax_2esurface_2eifE_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eifE_clo;
V g_heff_2esyntax_2esurface_2eintOfText(V);
V g_heff_2esyntax_2esurface_2eintOfText_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eintOfText_clo;
V g_heff_2esyntax_2esurface_2ekwAtom(V, V, V);
V g_heff_2esyntax_2esurface_2ekwAtom_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ekwAtom_clo;
V g_heff_2esyntax_2esurface_2ekwAtom_24tok1(V, V, V, V);
V g_heff_2esyntax_2esurface_2ekwAtom_24tok1_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2ekwAtom_24tok1_clo;
V g_heff_2esyntax_2esurface_2elambdaL(V, V, V, V);
V g_heff_2esyntax_2esurface_2elambdaL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2elambdaL_clo;
HeffT2 g_heff_2esyntax_2esurface_2eletBodyL_24cpr(V, V, V, V, V, V);
V g_heff_2esyntax_2esurface_2eletL(V, V, V);
V g_heff_2esyntax_2esurface_2eletL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eletL_clo;
V g_heff_2esyntax_2esurface_2eopL(V, V, V, V, V);
V g_heff_2esyntax_2esurface_2eopL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eopL_clo;
HeffT2 g_heff_2esyntax_2esurface_2eopRhsOf_24cpr(V);
V g_heff_2esyntax_2esurface_2eparenL(V, V, V, V, V);
V g_heff_2esyntax_2esurface_2eparenL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eparenL_clo;
V g_heff_2esyntax_2esurface_2epushS_24s1868233564x1858628873(V, V, V, V);
V g_heff_2esyntax_2esurface_2epushS_24s1868233564x1858628873_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2epushS_24s1868233564x1858628873_clo;
V g_heff_2esyntax_2esurface_2eresolve_24s1832151779x1448561609(V, V, V);
V g_heff_2esyntax_2esurface_2eresolve_24s1832151779x1448561609_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eresolve_24s1832151779x1448561609_clo;
V g_heff_2esyntax_2esurface_2eresolve_24s1832151779x1448561609_24tok1(V, V, V, V);
V g_heff_2esyntax_2esurface_2eresolve_24s1832151779x1448561609_24tok1_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eresolve_24s1832151779x1448561609_24tok1_clo;
V g_heff_2esyntax_2esurface_2eresolve_24s1832151779x1448561609_24tok2(V, V, V, V);
V g_heff_2esyntax_2esurface_2eresolve_24s1832151779x1448561609_24tok2_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eresolve_24s1832151779x1448561609_24tok2_clo;
V g_heff_2esyntax_2esurface_2erightsOf(V);
V g_heff_2esyntax_2esurface_2erightsOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2erightsOf_clo;
V g_heff_2esyntax_2esurface_2erightsOf_24dps(V, V);
V g_heff_2esyntax_2esurface_2erightsOf_24dps_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2erightsOf_24dps_clo;
V g_heff_2esyntax_2esurface_2esegmentL(V, V);
V g_heff_2esyntax_2esurface_2esegmentL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2esegmentL_clo;
V g_heff_2esyntax_2esurface_2esegmentOf_24s1547151193x813882637(V, V, V, V, V);
V g_heff_2esyntax_2esurface_2esegmentOf_24s1547151193x813882637_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2esegmentOf_24s1547151193x813882637_clo;
V g_heff_2esyntax_2esurface_2esegmentOf_24s1547151193x813882637_24tok1(V, V, V, V, V, V);
V g_heff_2esyntax_2esurface_2esegmentOf_24s1547151193x813882637_24tok1_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2esegmentOf_24s1547151193x813882637_24tok1_clo;
V g_heff_2esyntax_2esurface_2especWord(V, V, V);
V g_heff_2esyntax_2esurface_2especWord_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2especWord_clo;
V g_heff_2esyntax_2esurface_2estmtL(V, V);
V g_heff_2esyntax_2esurface_2estmtL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2estmtL_clo;
V g_heff_2esyntax_2esurface_2etryTypeL(V, V);
V g_heff_2esyntax_2esurface_2etryTypeL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2etryTypeL_clo;
V g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993(V, V, V, V, V);
V g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993_clo;
V g_heff_2esyntax_2esurface_2eunitOf(V, V, V);
V g_heff_2esyntax_2esurface_2eunitOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eunitOf_clo;
V g_heff_2esyntax_2esurface_2eupdateSettingL(V, V);
V g_heff_2esyntax_2esurface_2eupdateSettingL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2eupdateSettingL_clo;
HeffT2 g_heff_2esyntax_2esurface_2evalueKind_24cpr(V, V, V, V);
V g_heff_2esyntax_2esurface_2evarAtom(V, V, V);
V g_heff_2esyntax_2esurface_2evarAtom_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2evarAtom_clo;
V g_heff_2esyntax_2esurface_2evarAtom_24tok1(V, V, V, V);
V g_heff_2esyntax_2esurface_2evarAtom_24tok1_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2evarAtom_24tok1_clo;
V g_heff_2esyntax_2esurface_2evariantL(V, V);
V g_heff_2esyntax_2esurface_2evariantL_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurface_2evariantL_clo;
HeffT2 g_heff_2esyntax_2esurface_2ewithScope_24cpr(V, V, V);
V g_list_2emap_24s513201124x806973253(V);
V g_list_2emap_24s513201124x806973253_entry(V self, V *a);
extern Clo g_list_2emap_24s513201124x806973253_clo;
V g_prelude_2eskipSpaces(V, V, V);
V g_prelude_2eskipSpaces_entry(V self, V *a);
extern Clo g_prelude_2eskipSpaces_clo;
V g_prelude_2etraverse_24s499544530x2060473942(V, V);
V g_prelude_2etraverse_24s499544530x2060473942_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s499544530x2060473942_clo;
HEFF_LIT(g_heff_2esyntax_2esurface_2ecommentLinesFrom_str0, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecommentLinesFrom_str1, 1, "\012");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecommentLinesFrom_str2, 2, "--");
HEFF_LIT(g_heff_2esyntax_2esurface_2ecommentLinesFrom_str3, 1, "\012");
Clo g_heff_2esyntax_2esurface_2ecommentLinesFrom_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2ecommentLinesFrom_entry, 3, 0};

V g_heff_2esyntax_2esurface_2ecommentLinesFrom(V v_src_240, V v_i_241, V v_to_242) {
top: ;
  V v_j_243 = heff_strFind_lent(((V)&g_heff_2esyntax_2esurface_2ecommentLinesFrom_str0), v_src_240, v_i_241, 1);
  V v_t_244;
  if (heff_intLt_c_lent(v_j_243, MK_INT(0LL), 2)) {
    heff_drop(v_j_243);
    v_t_244 = heff_strLength_lent(v_src_240, 0);
  } else {
    v_t_244 = v_j_243;
  }
  if (heff_intLe_c_lent(v_to_242, v_t_244, 2)) {
    heff_drop(v_i_241);
    heff_drop(v_to_242);
    return NTAG(TAG_True);
  } else {
    V v_j_245 = heff_strFind_lent(((V)&g_heff_2esyntax_2esurface_2ecommentLinesFrom_str1), v_src_240, v_i_241, 1);
    V v_t_246;
    if (heff_intLt_c_lent(v_j_245, MK_INT(0LL), 2)) {
      heff_drop(v_j_245);
      v_t_246 = heff_strLength_lent(v_src_240, 0);
    } else {
      v_t_246 = v_j_245;
    }
    V v_s_247 = heff_strSlice_lent(v_src_240, v_i_241, v_t_246, 4);
    V v_t_248 = (g_prelude_2eskipSpaces(v_s_247, MK_INT(0LL), MK_INT(1LL)));
    int64_t v_t_249 = (heff_unbox_word(heff_strLength_lent(v_s_247, 0)) - ((int64_t)1ULL));
    V v_t_2410 = (g_prelude_2eskipSpaces(v_s_247, heff_box_word(v_t_249), MK_INT(-1LL)));
    V v_s_2411 = heff_strSlice(v_s_247, v_t_248, heff_intAdd(v_t_2410, MK_INT(1LL)));
    if (heff_strEq_c(heff_strSlice(v_s_2411, MK_INT(0LL), MK_INT(2LL)), ((V)&g_heff_2esyntax_2esurface_2ecommentLinesFrom_str2))) {
      V v_j_2412 = heff_strFind_lent(((V)&g_heff_2esyntax_2esurface_2ecommentLinesFrom_str3), v_src_240, v_i_241, 5);
      V v_t_2413;
      if (heff_intLt_c_lent(v_j_2412, MK_INT(0LL), 2)) {
        heff_drop(v_j_2412);
        v_t_2413 = heff_strLength_lent(v_src_240, 0);
      } else {
        v_t_2413 = v_j_2412;
      }
      V t_0 = v_src_240;
      V t_1 = heff_intAdd(v_t_2413, MK_INT(1LL));
      V t_2 = v_to_242;
      v_src_240 = t_0;
      v_i_241 = t_1;
      v_to_242 = t_2;
      goto top;
    } else {
      heff_drop(v_i_241);
      heff_drop(v_to_242);
      return NTAG(TAG_False);
    }
  }
}
V g_heff_2esyntax_2esurface_2ecommentLinesFrom_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2esurface_2ecommentLinesFrom(a0, a[1], a[2]); heff_drop(a0); return r;
}
V g_heff_2esyntax_2esurface_2eletBodyL_24cpr_lam0(V self, V *args);

HeffT2 g_heff_2esyntax_2esurface_2eletBodyL_24cpr(V v_r_240, V v_kw_241, V v_x3_242, V v_names_243, V v_body_244, V v_z_245) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_MkPair: {
    V v_p_246 = heff_field(v_x3_242, 0);
    V v_rhs_247 = heff_field(v_x3_242, 1);
    heff_take_n(v_x3_242, 3ULL, 2);
    V v_m_248 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_body_244)}));
    return (g_heff_2esyntax_2esurface_2ewithScope_24cpr(v_names_243, heff_clo_n(g_heff_2esyntax_2esurface_2eletBodyL_24cpr_lam0, 1, 5, (V[]){v_m_248, v_p_246, v_body_244, v_kw_241, v_rhs_247}), v_z_245));
  }
  default: return ((HeffT2){{heff_nomatch(v_x3_242)}});
  }
}
V g_heff_2esyntax_2esurface_2eletBodyL_24cpr_lam0(V self, V *args) {
  V v_st_249 = args[0];
  V v_m_248 = heff_env(self)[0];
  V v_p_246 = heff_env(self)[1];
  V v_body_244 = heff_env(self)[2];
  V v_kw_241 = heff_env(self)[3];
  V v_rhs_247 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_x1_2410 = heff_tr(heff_call(v_m_248, 1, (V[]){v_st_249}));
  switch (heff_tag_of(v_x1_2410)) {
  case TAG_MkPair: {
    V v_x11_2411 = heff_field(v_x1_2410, 0);
    V v_st_2412 = heff_field(v_x1_2410, 1);
    V v_ru_24x1_2410_24MkPair = heff_take_reuse_n(v_x1_2410, 3ULL, 2);
    switch (heff_tag_of(v_x11_2411)) {
    case TAG_Left: {
      V v_e_2413 = heff_field(v_x11_2411, 0);
      heff_take_n(v_x11_2411, 1ULL, 1);
      heff_drop(v_p_246);
      heff_drop(v_body_244);
      heff_drop_rec(v_kw_241, 9);
      heff_drop(v_rhs_247);
      return heff_tag_at_n(v_ru_24x1_2410_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2413}), v_st_2412});
    }
    case TAG_Right: {
      V v_x_2414 = heff_field(v_x11_2411, 0);
      heff_take_n(v_x11_2411, 1ULL, 1);
      V v_t_2417;
      switch (heff_tag_of(v_p_246)) {
      case TAG_At: {
        V v_s_2416 = heff_dup(heff_field(v_p_246, 1));
        v_t_2417 = v_s_2416;
        break;
      }
      default: heff_nomatch(v_p_246);
      }
      V v_t_2420;
      switch (heff_tag_of(v_x_2414)) {
      case TAG_At: {
        V v_s_2419 = heff_dup(heff_field(v_x_2414, 1));
        v_t_2420 = v_s_2419;
        break;
      }
      default: heff_nomatch(v_x_2414);
      }
      V v_t_2421 = ({ V rv_1 = heff_get_n(v_t_2420, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_2417, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
      V v_t_2422 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_p_246, v_x_2414}), v_t_2421});
      V v_t_2423 = (g_heff_2esyntax_2ecst_2elastE(v_body_244));
      V v_e_2424 = heff_get_n(v_t_2423, 4, 9);
      V v_t_2425 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_241, 3, 9), v_e_2424});
      V v_x_2426 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ELetIn, 2, (V[]){v_rhs_247, v_t_2422}), v_t_2425});
      return heff_tag_at_n(v_ru_24x1_2410_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2426}), v_st_2412});
    }
    default: return heff_nomatch(v_x11_2411);
    }
  }
  default: return heff_nomatch(v_x1_2410);
  }
}
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str0, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str1, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str2, 3, "err");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str3, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str4, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str5, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str6, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str7, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str8, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str9, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str10, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str11, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str12, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str13, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str14, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str15, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str16, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str17, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str18, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str19, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str20, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str21, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str22, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str23, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str24, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str25, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str26, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str27, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str28, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str29, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str30, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str31, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str32, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str33, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str34, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str35, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str36, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str37, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str38, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str39, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str40, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str41, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str42, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str43, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str44, 61, "a `try` names the type of the throws it hears as `(err := T)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2etryTypeL_str45, 61, "a `try` names the type of the throws it hears as `(err := T)`");
V g_heff_2esyntax_2esurface_2etryTypeL_lam0(V self, V *args); static Clo g_heff_2esyntax_2esurface_2etryTypeL_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2etryTypeL_lam0, 1, 0};
V g_heff_2esyntax_2esurface_2etryTypeL_lam1(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam2(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam3(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam4(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam5(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam6(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam7(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam8(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam9(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam10(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam11(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam12(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam13(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam14(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam15(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam16(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam17(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam18(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam19(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam20(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam21(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam22(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam23(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam24(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam25(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam26(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam27(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam28(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam29(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam30(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam31(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam32(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam33(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam34(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam35(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam36(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam37(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam38(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam39(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam40(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam41(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam42(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam43(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam44(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam45(V self, V *args);
V g_heff_2esyntax_2esurface_2etryTypeL_lam46(V self, V *args);
Clo g_heff_2esyntax_2esurface_2etryTypeL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2etryTypeL_entry, 2, 0};

V g_heff_2esyntax_2esurface_2etryTypeL(V v_r_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nothing: {
    heff_drop_rec(v_r_240, 3);
    return ((V)&g_heff_2esyntax_2esurface_2etryTypeL_lam0_clo);
  }
  case TAG_Just: {
    V v_x21_244 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24Just = heff_take_reuse_n(v_x2_241, 1ULL, 1);
    switch (heff_tag_of(v_x21_244)) {
    case TAG_Atom: {
      heff_drop_rec(v_r_240, 3);
      V v_t_246 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 1); r_; });
      V v_start_247 = heff_take_field(v_t_246, 3);
      V v_end_248 = heff_get_n(v_t_246, 4, 9);
      V v_t_249 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str0)}), heff_rec_n(2, shape_start__end, (V[]){v_start_247, v_end_248})});
      V v_x_2410 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_249});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam1, 1, 1, (V[]){v_x_2410});
    }
    case TAG_EParen: {
      heff_drop_rec(v_r_240, 3);
      V v_t_2415 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 3); r_; });
      V v_start_2416 = heff_take_field(v_t_2415, 3);
      V v_end_2417 = heff_get_n(v_t_2415, 4, 9);
      V v_t_2418 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str1)}), heff_rec_n(2, shape_start__end, (V[]){v_start_2416, v_end_2417})});
      V v_x_2419 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_2418});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam2, 1, 1, (V[]){v_x_2419});
    }
    case TAG_Named: {
      V v_x_2422 = heff_field(v_x21_244, 1);
      V v_e_2424 = heff_field(v_x21_244, 3);
      heff_take_n(v_x21_244, 10ULL, 5);
      heff_drop_cell(v_ru_24x2_241_24Just, 1);
      V v_text_2426 = heff_take_field(v_x_2422, 1);
      V v_start_2427 = heff_take_field(v_x_2422, 3);
      V v_end_2428 = heff_get_n(v_x_2422, 4, 9);
      if (heff_strEq_c(v_text_2426, ((V)&g_heff_2esyntax_2esurface_2etryTypeL_str2))) {
        heff_drop(v_start_2427);
        heff_drop(v_end_2428);
        V v_m_2429 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_2424}));
        return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam3, 1, 1, (V[]){v_m_2429});
      } else {
        heff_drop_rec(v_r_240, 3);
        heff_drop(v_e_2424);
        return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam4, 1, 2, (V[]){v_start_2427, v_end_2428});
      }
    }
    case TAG_Tup: {
      heff_drop_rec(v_r_240, 3);
      V v_t_2444 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 4); r_; });
      V v_start_2445 = heff_take_field(v_t_2444, 3);
      V v_end_2446 = heff_get_n(v_t_2444, 4, 9);
      V v_t_2447 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str4)}), heff_rec_n(2, shape_start__end, (V[]){v_start_2445, v_end_2446})});
      V v_x_2448 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_2447});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam5, 1, 1, (V[]){v_x_2448});
    }
    case TAG_Seg: {
      heff_drop_rec(v_r_240, 3);
      V v_t_2453 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 3); r_; });
      V v_start_2454 = heff_take_field(v_t_2453, 3);
      V v_end_2455 = heff_get_n(v_t_2453, 4, 9);
      V v_t_2456 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str5)}), heff_rec_n(2, shape_start__end, (V[]){v_start_2454, v_end_2455})});
      V v_x_2457 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_2456});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam6, 1, 1, (V[]){v_x_2457});
    }
    case TAG_Braces: {
      heff_drop_rec(v_r_240, 3);
      V v_t_2463 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 4); r_; });
      V v_start_2464 = heff_take_field(v_t_2463, 3);
      V v_end_2465 = heff_get_n(v_t_2463, 4, 9);
      V v_t_2466 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str6)}), heff_rec_n(2, shape_start__end, (V[]){v_start_2464, v_end_2465})});
      V v_x_2467 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_2466});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam7, 1, 1, (V[]){v_x_2467});
    }
    case TAG_Update: {
      heff_drop_rec(v_r_240, 3);
      V v_t_2475 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 6); r_; });
      V v_start_2476 = heff_take_field(v_t_2475, 3);
      V v_end_2477 = heff_get_n(v_t_2475, 4, 9);
      V v_t_2478 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str7)}), heff_rec_n(2, shape_start__end, (V[]){v_start_2476, v_end_2477})});
      V v_x_2479 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_2478});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam8, 1, 1, (V[]){v_x_2479});
    }
    case TAG_EUSet: {
      heff_drop_rec(v_r_240, 3);
      V v_t_2484 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 3); r_; });
      V v_start_2485 = heff_take_field(v_t_2484, 3);
      V v_end_2486 = heff_get_n(v_t_2484, 4, 9);
      V v_t_2487 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str8)}), heff_rec_n(2, shape_start__end, (V[]){v_start_2485, v_end_2486})});
      V v_x_2488 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_2487});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam9, 1, 1, (V[]){v_x_2488});
    }
    case TAG_InstB: {
      heff_drop_rec(v_r_240, 3);
      V v_t_2495 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 5); r_; });
      V v_start_2496 = heff_take_field(v_t_2495, 3);
      V v_end_2497 = heff_get_n(v_t_2495, 4, 9);
      V v_t_2498 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str9)}), heff_rec_n(2, shape_start__end, (V[]){v_start_2496, v_end_2497})});
      V v_x_2499 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_2498});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam10, 1, 1, (V[]){v_x_2499});
    }
    case TAG_EFSet: {
      heff_drop_rec(v_r_240, 3);
      V v_t_24104 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 3); r_; });
      V v_start_24105 = heff_take_field(v_t_24104, 3);
      V v_end_24106 = heff_get_n(v_t_24104, 4, 9);
      V v_t_24107 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str10)}), heff_rec_n(2, shape_start__end, (V[]){v_start_24105, v_end_24106})});
      V v_x_24108 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_24107});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam11, 1, 1, (V[]){v_x_24108});
    }
    case TAG_EFDefault: {
      heff_drop_rec(v_r_240, 3);
      V v_t_24113 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 3); r_; });
      V v_start_24114 = heff_take_field(v_t_24113, 3);
      V v_end_24115 = heff_get_n(v_t_24113, 4, 9);
      V v_t_24116 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str11)}), heff_rec_n(2, shape_start__end, (V[]){v_start_24114, v_end_24115})});
      V v_x_24117 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_24116});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam12, 1, 1, (V[]){v_x_24117});
    }
    case TAG_Sum: {
      heff_drop_rec(v_r_240, 3);
      V v_t_24124 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 5); r_; });
      V v_start_24125 = heff_take_field(v_t_24124, 3);
      V v_end_24126 = heff_get_n(v_t_24124, 4, 9);
      V v_t_24127 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str12)}), heff_rec_n(2, shape_start__end, (V[]){v_start_24125, v_end_24126})});
      V v_x_24128 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_24127});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam13, 1, 1, (V[]){v_x_24128});
    }
    case TAG_ECon: {
      heff_drop_rec(v_r_240, 3);
      V v_t_24132 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 2); r_; });
      V v_start_24133 = heff_take_field(v_t_24132, 3);
      V v_end_24134 = heff_get_n(v_t_24132, 4, 9);
      V v_t_24135 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str13)}), heff_rec_n(2, shape_start__end, (V[]){v_start_24133, v_end_24134})});
      V v_x_24136 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_24135});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam14, 1, 1, (V[]){v_x_24136});
    }
    case TAG_EField: {
      heff_drop_rec(v_r_240, 3);
      V v_t_24140 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 2); r_; });
      V v_start_24141 = heff_take_field(v_t_24140, 3);
      V v_end_24142 = heff_get_n(v_t_24140, 4, 9);
      V v_t_24143 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str14)}), heff_rec_n(2, shape_start__end, (V[]){v_start_24141, v_end_24142})});
      V v_x_24144 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_24143});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam15, 1, 1, (V[]){v_x_24144});
    }
    case TAG_ENeg: {
      heff_drop_rec(v_r_240, 3);
      V v_t_24148 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 2); r_; });
      V v_start_24149 = heff_take_field(v_t_24148, 3);
      V v_end_24150 = heff_get_n(v_t_24148, 4, 9);
      V v_t_24151 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str15)}), heff_rec_n(2, shape_start__end, (V[]){v_start_24149, v_end_24150})});
      V v_x_24152 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_24151});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam16, 1, 1, (V[]){v_x_24152});
    }
    case TAG_ETilde: {
      heff_drop_rec(v_r_240, 3);
      V v_t_24156 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 2); r_; });
      V v_start_24157 = heff_take_field(v_t_24156, 3);
      V v_end_24158 = heff_get_n(v_t_24156, 4, 9);
      V v_t_24159 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str16)}), heff_rec_n(2, shape_start__end, (V[]){v_start_24157, v_end_24158})});
      V v_x_24160 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_24159});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam17, 1, 1, (V[]){v_x_24160});
    }
    case TAG_App: {
      heff_drop_rec(v_r_240, 3);
      V v_t_24164 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 2); r_; });
      V v_start_24165 = heff_take_field(v_t_24164, 3);
      V v_end_24166 = heff_get_n(v_t_24164, 4, 9);
      V v_t_24167 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str17)}), heff_rec_n(2, shape_start__end, (V[]){v_start_24165, v_end_24166})});
      V v_x_24168 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_24167});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam18, 1, 1, (V[]){v_x_24168});
    }
    case TAG_Op: {
      heff_drop_rec(v_r_240, 3);
      V v_t_24173 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 3); r_; });
      V v_start_24174 = heff_take_field(v_t_24173, 3);
      V v_end_24175 = heff_get_n(v_t_24173, 4, 9);
      V v_t_24176 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str18)}), heff_rec_n(2, shape_start__end, (V[]){v_start_24174, v_end_24175})});
      V v_x_24177 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_24176});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam19, 1, 1, (V[]){v_x_24177});
    }
    case TAG_Ops: {
      heff_drop_rec(v_r_240, 3);
      V v_t_24181 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 2); r_; });
      V v_start_24182 = heff_take_field(v_t_24181, 3);
      V v_end_24183 = heff_get_n(v_t_24181, 4, 9);
      V v_t_24184 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str19)}), heff_rec_n(2, shape_start__end, (V[]){v_start_24182, v_end_24183})});
      V v_x_24185 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_24184});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam20, 1, 1, (V[]){v_x_24185});
    }
    case TAG_OpRhs: {
      heff_drop_rec(v_r_240, 3);
      V v_t_24189 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 2); r_; });
      V v_start_24190 = heff_take_field(v_t_24189, 3);
      V v_end_24191 = heff_get_n(v_t_24189, 4, 9);
      V v_t_24192 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str20)}), heff_rec_n(2, shape_start__end, (V[]){v_start_24190, v_end_24191})});
      V v_x_24193 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_24192});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam21, 1, 1, (V[]){v_x_24193});
    }
    case TAG_Ann: {
      heff_drop_rec(v_r_240, 3);
      V v_t_24198 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 3); r_; });
      V v_start_24199 = heff_take_field(v_t_24198, 3);
      V v_end_24200 = heff_get_n(v_t_24198, 4, 9);
      V v_t_24201 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str21)}), heff_rec_n(2, shape_start__end, (V[]){v_start_24199, v_end_24200})});
      V v_x_24202 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_24201});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam22, 1, 1, (V[]){v_x_24202});
    }
    case TAG_BVar: {
      heff_drop_rec(v_r_240, 3);
      V v_t_24205 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 1); r_; });
      V v_start_24206 = heff_take_field(v_t_24205, 3);
      V v_end_24207 = heff_get_n(v_t_24205, 4, 9);
      V v_t_24208 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str22)}), heff_rec_n(2, shape_start__end, (V[]){v_start_24206, v_end_24207})});
      V v_x_24209 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_24208});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam23, 1, 1, (V[]){v_x_24209});
    }
    case TAG_BImp: {
      heff_drop_rec(v_r_240, 3);
      V v_t_24214 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 3); r_; });
      V v_start_24215 = heff_take_field(v_t_24214, 3);
      V v_end_24216 = heff_get_n(v_t_24214, 4, 9);
      V v_t_24217 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str23)}), heff_rec_n(2, shape_start__end, (V[]){v_start_24215, v_end_24216})});
      V v_x_24218 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_24217});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam24, 1, 1, (V[]){v_x_24218});
    }
    case TAG_BAnn: {
      heff_drop_rec(v_r_240, 3);
      V v_t_24225 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 5); r_; });
      V v_start_24226 = heff_take_field(v_t_24225, 3);
      V v_end_24227 = heff_get_n(v_t_24225, 4, 9);
      V v_t_24228 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str24)}), heff_rec_n(2, shape_start__end, (V[]){v_start_24226, v_end_24227})});
      V v_x_24229 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_24228});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam25, 1, 1, (V[]){v_x_24229});
    }
    case TAG_BPat: {
      heff_drop_rec(v_r_240, 3);
      V v_t_24232 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 1); r_; });
      V v_start_24233 = heff_take_field(v_t_24232, 3);
      V v_end_24234 = heff_get_n(v_t_24232, 4, 9);
      V v_t_24235 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str25)}), heff_rec_n(2, shape_start__end, (V[]){v_start_24233, v_end_24234})});
      V v_x_24236 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_24235});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam26, 1, 1, (V[]){v_x_24236});
    }
    case TAG_Lam: {
      heff_drop_rec(v_r_240, 3);
      V v_t_24242 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 4); r_; });
      V v_start_24243 = heff_take_field(v_t_24242, 3);
      V v_end_24244 = heff_get_n(v_t_24242, 4, 9);
      V v_t_24245 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str26)}), heff_rec_n(2, shape_start__end, (V[]){v_start_24243, v_end_24244})});
      V v_x_24246 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_24245});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam27, 1, 1, (V[]){v_x_24246});
    }
    case TAG_Case: {
      heff_drop_rec(v_r_240, 3);
      V v_t_24252 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 4); r_; });
      V v_start_24253 = heff_take_field(v_t_24252, 3);
      V v_end_24254 = heff_get_n(v_t_24252, 4, 9);
      V v_t_24255 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str27)}), heff_rec_n(2, shape_start__end, (V[]){v_start_24253, v_end_24254})});
      V v_x_24256 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_24255});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam28, 1, 1, (V[]){v_x_24256});
    }
    case TAG_EAlt: {
      heff_drop_rec(v_r_240, 3);
      V v_t_24261 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 3); r_; });
      V v_start_24262 = heff_take_field(v_t_24261, 3);
      V v_end_24263 = heff_get_n(v_t_24261, 4, 9);
      V v_t_24264 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str28)}), heff_rec_n(2, shape_start__end, (V[]){v_start_24262, v_end_24263})});
      V v_x_24265 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_24264});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam29, 1, 1, (V[]){v_x_24265});
    }
    case TAG_If: {
      heff_drop_rec(v_r_240, 3);
      V v_t_24273 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 6); r_; });
      V v_start_24274 = heff_take_field(v_t_24273, 3);
      V v_end_24275 = heff_get_n(v_t_24273, 4, 9);
      V v_t_24276 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str29)}), heff_rec_n(2, shape_start__end, (V[]){v_start_24274, v_end_24275})});
      V v_x_24277 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_24276});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam30, 1, 1, (V[]){v_x_24277});
    }
    case TAG_Do: {
      heff_drop_rec(v_r_240, 3);
      V v_t_24281 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 2); r_; });
      V v_start_24282 = heff_take_field(v_t_24281, 3);
      V v_end_24283 = heff_get_n(v_t_24281, 4, 9);
      V v_t_24284 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str30)}), heff_rec_n(2, shape_start__end, (V[]){v_start_24282, v_end_24283})});
      V v_x_24285 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_24284});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam31, 1, 1, (V[]){v_x_24285});
    }
    case TAG_ESBind: {
      heff_drop_rec(v_r_240, 3);
      V v_t_24290 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 3); r_; });
      V v_start_24291 = heff_take_field(v_t_24290, 3);
      V v_end_24292 = heff_get_n(v_t_24290, 4, 9);
      V v_t_24293 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str31)}), heff_rec_n(2, shape_start__end, (V[]){v_start_24291, v_end_24292})});
      V v_x_24294 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_24293});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam32, 1, 1, (V[]){v_x_24294});
    }
    case TAG_ELet: {
      heff_drop_rec(v_r_240, 3);
      V v_t_24302 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 6); r_; });
      V v_start_24303 = heff_take_field(v_t_24302, 3);
      V v_end_24304 = heff_get_n(v_t_24302, 4, 9);
      V v_t_24305 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str32)}), heff_rec_n(2, shape_start__end, (V[]){v_start_24303, v_end_24304})});
      V v_x_24306 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_24305});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam33, 1, 1, (V[]){v_x_24306});
    }
    case TAG_ELetElse: {
      heff_drop_rec(v_r_240, 3);
      V v_t_24315 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 7); r_; });
      V v_start_24316 = heff_take_field(v_t_24315, 3);
      V v_end_24317 = heff_get_n(v_t_24315, 4, 9);
      V v_t_24318 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str33)}), heff_rec_n(2, shape_start__end, (V[]){v_start_24316, v_end_24317})});
      V v_x_24319 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_24318});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam34, 1, 1, (V[]){v_x_24319});
    }
    case TAG_ELetMut: {
      heff_drop_rec(v_r_240, 3);
      V v_t_24327 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 6); r_; });
      V v_start_24328 = heff_take_field(v_t_24327, 3);
      V v_end_24329 = heff_get_n(v_t_24327, 4, 9);
      V v_t_24330 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str34)}), heff_rec_n(2, shape_start__end, (V[]){v_start_24328, v_end_24329})});
      V v_x_24331 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_24330});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam35, 1, 1, (V[]){v_x_24331});
    }
    case TAG_EAssign: {
      heff_drop_rec(v_r_240, 3);
      V v_t_24336 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 3); r_; });
      V v_start_24337 = heff_take_field(v_t_24336, 3);
      V v_end_24338 = heff_get_n(v_t_24336, 4, 9);
      V v_t_24339 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str35)}), heff_rec_n(2, shape_start__end, (V[]){v_start_24337, v_end_24338})});
      V v_x_24340 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_24339});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam36, 1, 1, (V[]){v_x_24340});
    }
    case TAG_EWhile: {
      heff_drop_rec(v_r_240, 3);
      V v_t_24346 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 4); r_; });
      V v_start_24347 = heff_take_field(v_t_24346, 3);
      V v_end_24348 = heff_get_n(v_t_24346, 4, 9);
      V v_t_24349 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str36)}), heff_rec_n(2, shape_start__end, (V[]){v_start_24347, v_end_24348})});
      V v_x_24350 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_24349});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam37, 1, 1, (V[]){v_x_24350});
    }
    case TAG_EFor: {
      heff_drop_rec(v_r_240, 3);
      V v_t_24358 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 6); r_; });
      V v_start_24359 = heff_take_field(v_t_24358, 3);
      V v_end_24360 = heff_get_n(v_t_24358, 4, 9);
      V v_t_24361 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str37)}), heff_rec_n(2, shape_start__end, (V[]){v_start_24359, v_end_24360})});
      V v_x_24362 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_24361});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam38, 1, 1, (V[]){v_x_24362});
    }
    case TAG_EJump: {
      heff_drop_rec(v_r_240, 3);
      V v_t_24365 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 1); r_; });
      V v_start_24366 = heff_take_field(v_t_24365, 3);
      V v_end_24367 = heff_get_n(v_t_24365, 4, 9);
      V v_t_24368 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str38)}), heff_rec_n(2, shape_start__end, (V[]){v_start_24366, v_end_24367})});
      V v_x_24369 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_24368});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam39, 1, 1, (V[]){v_x_24369});
    }
    case TAG_EReturn: {
      heff_drop_rec(v_r_240, 3);
      V v_t_24373 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 2); r_; });
      V v_start_24374 = heff_take_field(v_t_24373, 3);
      V v_end_24375 = heff_get_n(v_t_24373, 4, 9);
      V v_t_24376 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str39)}), heff_rec_n(2, shape_start__end, (V[]){v_start_24374, v_end_24375})});
      V v_x_24377 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_24376});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam40, 1, 1, (V[]){v_x_24377});
    }
    case TAG_ENest: {
      heff_drop_rec(v_r_240, 3);
      V v_t_24383 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 4); r_; });
      V v_start_24384 = heff_take_field(v_t_24383, 3);
      V v_end_24385 = heff_get_n(v_t_24383, 4, 9);
      V v_t_24386 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str40)}), heff_rec_n(2, shape_start__end, (V[]){v_start_24384, v_end_24385})});
      V v_x_24387 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_24386});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam41, 1, 1, (V[]){v_x_24387});
    }
    case TAG_EArrow: {
      heff_drop_rec(v_r_240, 3);
      V v_t_24391 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 2); r_; });
      V v_start_24392 = heff_take_field(v_t_24391, 3);
      V v_end_24393 = heff_get_n(v_t_24391, 4, 9);
      V v_t_24394 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str41)}), heff_rec_n(2, shape_start__end, (V[]){v_start_24392, v_end_24393})});
      V v_x_24395 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_24394});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam42, 1, 1, (V[]){v_x_24395});
    }
    case TAG_IfThen: {
      heff_drop_rec(v_r_240, 3);
      V v_t_24401 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 4); r_; });
      V v_start_24402 = heff_take_field(v_t_24401, 3);
      V v_end_24403 = heff_get_n(v_t_24401, 4, 9);
      V v_t_24404 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str42)}), heff_rec_n(2, shape_start__end, (V[]){v_start_24402, v_end_24403})});
      V v_x_24405 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_24404});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam43, 1, 1, (V[]){v_x_24405});
    }
    case TAG_ETry: {
      heff_drop_rec(v_r_240, 3);
      V v_t_24411 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 4); r_; });
      V v_start_24412 = heff_take_field(v_t_24411, 3);
      V v_end_24413 = heff_get_n(v_t_24411, 4, 9);
      V v_t_24414 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str43)}), heff_rec_n(2, shape_start__end, (V[]){v_start_24412, v_end_24413})});
      V v_x_24415 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_24414});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam44, 1, 1, (V[]){v_x_24415});
    }
    case TAG_ECatch: {
      heff_drop_rec(v_r_240, 3);
      V v_t_24421 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 4); r_; });
      V v_start_24422 = heff_take_field(v_t_24421, 3);
      V v_end_24423 = heff_get_n(v_t_24421, 4, 9);
      V v_t_24424 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str44)}), heff_rec_n(2, shape_start__end, (V[]){v_start_24422, v_end_24423})});
      V v_x_24425 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_24424});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam45, 1, 1, (V[]){v_x_24425});
    }
    case TAG_EWith: {
      heff_drop_rec(v_r_240, 3);
      V v_t_24433 = ({ V a_0 = v_x21_244; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_x21_244, 6); r_; });
      V v_start_24434 = heff_take_field(v_t_24433, 3);
      V v_end_24435 = heff_get_n(v_t_24433, 4, 9);
      V v_t_24436 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str45)}), heff_rec_n(2, shape_start__end, (V[]){v_start_24434, v_end_24435})});
      V v_x_24437 = heff_tag_at_n(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){v_t_24436});
      return heff_clo_n(g_heff_2esyntax_2esurface_2etryTypeL_lam46, 1, 1, (V[]){v_x_24437});
    }
    default: return heff_nomatch(v_x21_244);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2esurface_2etryTypeL_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2etryTypeL(a[0], a[1]);
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam0(V self, V *args) {
  V v_st_242 = args[0];
  V v_t_243 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_243, v_st_242});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam1(V self, V *args) {
  V v_st_2411 = args[0];
  V v_x_2410 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2410}), v_st_2411});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam2(V self, V *args) {
  V v_st_2420 = args[0];
  V v_x_2419 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2419}), v_st_2420});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam3(V self, V *args) {
  V v_st_2430 = args[0];
  V v_m_2429 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2431 = heff_tr(heff_call(v_m_2429, 1, (V[]){v_st_2430}));
  switch (heff_tag_of(v_x1_2431)) {
  case TAG_MkPair: {
    V v_x11_2432 = heff_field(v_x1_2431, 0);
    V v_st_2433 = heff_field(v_x1_2431, 1);
    V v_ru_24x1_2431_24MkPair = heff_take_reuse_n(v_x1_2431, 3ULL, 2);
    switch (heff_tag_of(v_x11_2432)) {
    case TAG_Left: {
      V v_e_2434 = heff_field(v_x11_2432, 0);
      heff_take_n(v_x11_2432, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_2431_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2434}), v_st_2433});
    }
    case TAG_Right: {
      V v_x_2435 = heff_field(v_x11_2432, 0);
      V v_ru_24x11_2432_24Right = heff_take_reuse_n(v_x11_2432, 1ULL, 1);
      V v_t_2436 = heff_tag_at_n(v_ru_24x11_2432_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Just, 1, (V[]){v_x_2435})});
      return heff_tag_at_n(v_ru_24x1_2431_24MkPair, TAG_MkPair, 2, (V[]){v_t_2436, v_st_2433});
    }
    default: return heff_nomatch(v_x11_2432);
    }
  }
  default: return heff_nomatch(v_x1_2431);
  }
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam4(V self, V *args) {
  V v_st_2437 = args[0];
  V v_start_2427 = heff_env(self)[0];
  V v_end_2428 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2438 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2etryTypeL_str3)}), heff_rec_n(2, shape_start__end, (V[]){v_start_2427, v_end_2428})});
  V v_t_2439 = heff_tag_n(TAG_Right, 1, (V[]){heff_tag_n(TAG_Just, 1, (V[]){v_t_2438})});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2439, v_st_2437});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam5(V self, V *args) {
  V v_st_2449 = args[0];
  V v_x_2448 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2448}), v_st_2449});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam6(V self, V *args) {
  V v_st_2458 = args[0];
  V v_x_2457 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2457}), v_st_2458});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam7(V self, V *args) {
  V v_st_2468 = args[0];
  V v_x_2467 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2467}), v_st_2468});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam8(V self, V *args) {
  V v_st_2480 = args[0];
  V v_x_2479 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2479}), v_st_2480});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam9(V self, V *args) {
  V v_st_2489 = args[0];
  V v_x_2488 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2488}), v_st_2489});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam10(V self, V *args) {
  V v_st_24100 = args[0];
  V v_x_2499 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2499}), v_st_24100});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam11(V self, V *args) {
  V v_st_24109 = args[0];
  V v_x_24108 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24108}), v_st_24109});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam12(V self, V *args) {
  V v_st_24118 = args[0];
  V v_x_24117 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24117}), v_st_24118});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam13(V self, V *args) {
  V v_st_24129 = args[0];
  V v_x_24128 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24128}), v_st_24129});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam14(V self, V *args) {
  V v_st_24137 = args[0];
  V v_x_24136 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24136}), v_st_24137});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam15(V self, V *args) {
  V v_st_24145 = args[0];
  V v_x_24144 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24144}), v_st_24145});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam16(V self, V *args) {
  V v_st_24153 = args[0];
  V v_x_24152 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24152}), v_st_24153});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam17(V self, V *args) {
  V v_st_24161 = args[0];
  V v_x_24160 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24160}), v_st_24161});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam18(V self, V *args) {
  V v_st_24169 = args[0];
  V v_x_24168 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24168}), v_st_24169});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam19(V self, V *args) {
  V v_st_24178 = args[0];
  V v_x_24177 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24177}), v_st_24178});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam20(V self, V *args) {
  V v_st_24186 = args[0];
  V v_x_24185 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24185}), v_st_24186});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam21(V self, V *args) {
  V v_st_24194 = args[0];
  V v_x_24193 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24193}), v_st_24194});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam22(V self, V *args) {
  V v_st_24203 = args[0];
  V v_x_24202 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24202}), v_st_24203});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam23(V self, V *args) {
  V v_st_24210 = args[0];
  V v_x_24209 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24209}), v_st_24210});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam24(V self, V *args) {
  V v_st_24219 = args[0];
  V v_x_24218 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24218}), v_st_24219});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam25(V self, V *args) {
  V v_st_24230 = args[0];
  V v_x_24229 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24229}), v_st_24230});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam26(V self, V *args) {
  V v_st_24237 = args[0];
  V v_x_24236 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24236}), v_st_24237});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam27(V self, V *args) {
  V v_st_24247 = args[0];
  V v_x_24246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24246}), v_st_24247});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam28(V self, V *args) {
  V v_st_24257 = args[0];
  V v_x_24256 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24256}), v_st_24257});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam29(V self, V *args) {
  V v_st_24266 = args[0];
  V v_x_24265 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24265}), v_st_24266});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam30(V self, V *args) {
  V v_st_24278 = args[0];
  V v_x_24277 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24277}), v_st_24278});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam31(V self, V *args) {
  V v_st_24286 = args[0];
  V v_x_24285 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24285}), v_st_24286});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam32(V self, V *args) {
  V v_st_24295 = args[0];
  V v_x_24294 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24294}), v_st_24295});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam33(V self, V *args) {
  V v_st_24307 = args[0];
  V v_x_24306 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24306}), v_st_24307});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam34(V self, V *args) {
  V v_st_24320 = args[0];
  V v_x_24319 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24319}), v_st_24320});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam35(V self, V *args) {
  V v_st_24332 = args[0];
  V v_x_24331 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24331}), v_st_24332});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam36(V self, V *args) {
  V v_st_24341 = args[0];
  V v_x_24340 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24340}), v_st_24341});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam37(V self, V *args) {
  V v_st_24351 = args[0];
  V v_x_24350 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24350}), v_st_24351});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam38(V self, V *args) {
  V v_st_24363 = args[0];
  V v_x_24362 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24362}), v_st_24363});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam39(V self, V *args) {
  V v_st_24370 = args[0];
  V v_x_24369 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24369}), v_st_24370});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam40(V self, V *args) {
  V v_st_24378 = args[0];
  V v_x_24377 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24377}), v_st_24378});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam41(V self, V *args) {
  V v_st_24388 = args[0];
  V v_x_24387 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24387}), v_st_24388});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam42(V self, V *args) {
  V v_st_24396 = args[0];
  V v_x_24395 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24395}), v_st_24396});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam43(V self, V *args) {
  V v_st_24406 = args[0];
  V v_x_24405 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24405}), v_st_24406});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam44(V self, V *args) {
  V v_st_24416 = args[0];
  V v_x_24415 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24415}), v_st_24416});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam45(V self, V *args) {
  V v_st_24426 = args[0];
  V v_x_24425 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24425}), v_st_24426});
}
V g_heff_2esyntax_2esurface_2etryTypeL_lam46(V self, V *args) {
  V v_st_24438 = args[0];
  V v_x_24437 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24437}), v_st_24438});
}
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str0, 7, "integer");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str1, 28, "a segment says its type once");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str2, 6, "binary");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str3, 5, "bytes");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str4, 28, "a segment says its type once");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str5, 4, "bits");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str6, 9, "bitstring");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str7, 28, "a segment says its type once");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str8, 5, "float");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str9, 28, "a segment says its type once");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str10, 4, "utf8");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str11, 28, "a segment says its type once");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str12, 5, "utf16");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str13, 28, "a segment says its type once");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str14, 5, "utf32");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str15, 28, "a segment says its type once");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str16, 3, "big");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str17, 34, "a segment says its endianness once");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str18, 6, "little");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str19, 34, "a segment says its endianness once");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str20, 6, "signed");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str21, 28, "a segment says its sign once");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str22, 8, "unsigned");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str23, 28, "a segment says its sign once");
HEFF_LIT(g_heff_2esyntax_2esurface_2especWord_str24, 227, "a segment's spec is its type (`integer`, `binary`, `bits`, `float`, `utf8`, `utf16`, `utf32`), size (`16`, `size(n)`), unit (`unit(8)`), endianness (`big`, `little`) and sign (`signed`, `unsigned`), between `-`s: `x::16-little`");
Clo g_heff_2esyntax_2esurface_2especWord_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2especWord_entry, 3, 0};

V g_heff_2esyntax_2esurface_2especWord(V v_t_240, V v_s_241, V v_p_242) {
top: ;
  V v_ty_243 = heff_take_field(v_s_241, 0);
  V v_size_244 = heff_take_field(v_s_241, 1);
  V v_unit_245 = heff_take_field(v_s_241, 2);
  V v_little_246 = heff_take_field(v_s_241, 3);
  V v_signed_247 = heff_get_n(v_s_241, 4, 5);
  V v_text_248 = heff_take_field(v_t_240, 1);
  V v_start_249 = heff_take_field(v_t_240, 3);
  V v_end_2410 = heff_get_n(v_t_240, 4, 9);
  if (heff_strEq_c_lent(v_text_248, ((V)&g_heff_2esyntax_2esurface_2especWord_str0), 2)) {
    heff_drop(v_text_248);
    switch (heff_tag_of(v_ty_243)) {
    case TAG_Nothing: {
      heff_drop(v_start_249);
      heff_drop(v_end_2410);
      V v_t_2411 = heff_tag_n(TAG_Just, 1, (V[]){NTAG(TAG_SegmentInteger)});
      V v_t_2412 = heff_tag_n(TAG_Right, 1, (V[]){heff_rec_n(5, shape_ty__size__unit__little__signed, (V[]){v_t_2411, v_size_244, v_unit_245, v_little_246, v_signed_247})});
      return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2412, v_p_242});
    }
    case TAG_Just: {
      V v_ru_24ty_243_24Just = heff_take_reuse_n(v_ty_243, 0ULL, 1);
      heff_drop(v_size_244);
      heff_drop(v_unit_245);
      heff_drop(v_little_246);
      heff_drop(v_signed_247);
      V v_t_2414 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2especWord_str1), heff_rec_n(2, shape_start__end, (V[]){v_start_249, v_end_2410}), NTAG(TAG_Nothing)});
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24ty_243_24Just, TAG_Left, 1, (V[]){v_t_2414}), v_p_242});
    }
    default: return heff_nomatch(v_ty_243);
    }
  } else {
    if ((heff_strEq_c_lent(v_text_248, ((V)&g_heff_2esyntax_2esurface_2especWord_str2), 2) || heff_strEq_c_lent(v_text_248, ((V)&g_heff_2esyntax_2esurface_2especWord_str3), 2))) {
      heff_drop(v_text_248);
      switch (heff_tag_of(v_ty_243)) {
      case TAG_Nothing: {
        heff_drop(v_start_249);
        heff_drop(v_end_2410);
        V v_t_2415 = heff_tag_n(TAG_Just, 1, (V[]){NTAG(TAG_SegmentBinary)});
        V v_t_2416 = heff_tag_n(TAG_Right, 1, (V[]){heff_rec_n(5, shape_ty__size__unit__little__signed, (V[]){v_t_2415, v_size_244, v_unit_245, v_little_246, v_signed_247})});
        return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2416, v_p_242});
      }
      case TAG_Just: {
        V v_ru_24ty_243_24Just = heff_take_reuse_n(v_ty_243, 0ULL, 1);
        heff_drop(v_size_244);
        heff_drop(v_unit_245);
        heff_drop(v_little_246);
        heff_drop(v_signed_247);
        V v_t_2418 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2especWord_str4), heff_rec_n(2, shape_start__end, (V[]){v_start_249, v_end_2410}), NTAG(TAG_Nothing)});
        return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24ty_243_24Just, TAG_Left, 1, (V[]){v_t_2418}), v_p_242});
      }
      default: return heff_nomatch(v_ty_243);
      }
    } else {
      if ((heff_strEq_c_lent(v_text_248, ((V)&g_heff_2esyntax_2esurface_2especWord_str5), 2) || heff_strEq_c_lent(v_text_248, ((V)&g_heff_2esyntax_2esurface_2especWord_str6), 2))) {
        heff_drop(v_text_248);
        switch (heff_tag_of(v_ty_243)) {
        case TAG_Nothing: {
          heff_drop(v_start_249);
          heff_drop(v_end_2410);
          V v_t_2419 = heff_tag_n(TAG_Just, 1, (V[]){NTAG(TAG_SegmentBits)});
          V v_t_2420 = heff_tag_n(TAG_Right, 1, (V[]){heff_rec_n(5, shape_ty__size__unit__little__signed, (V[]){v_t_2419, v_size_244, v_unit_245, v_little_246, v_signed_247})});
          return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2420, v_p_242});
        }
        case TAG_Just: {
          V v_ru_24ty_243_24Just = heff_take_reuse_n(v_ty_243, 0ULL, 1);
          heff_drop(v_size_244);
          heff_drop(v_unit_245);
          heff_drop(v_little_246);
          heff_drop(v_signed_247);
          V v_t_2422 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2especWord_str7), heff_rec_n(2, shape_start__end, (V[]){v_start_249, v_end_2410}), NTAG(TAG_Nothing)});
          return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24ty_243_24Just, TAG_Left, 1, (V[]){v_t_2422}), v_p_242});
        }
        default: return heff_nomatch(v_ty_243);
        }
      } else {
        if (heff_strEq_c_lent(v_text_248, ((V)&g_heff_2esyntax_2esurface_2especWord_str8), 2)) {
          heff_drop(v_text_248);
          switch (heff_tag_of(v_ty_243)) {
          case TAG_Nothing: {
            heff_drop(v_start_249);
            heff_drop(v_end_2410);
            V v_t_2423 = heff_tag_n(TAG_Just, 1, (V[]){NTAG(TAG_SegmentFloat)});
            V v_t_2424 = heff_tag_n(TAG_Right, 1, (V[]){heff_rec_n(5, shape_ty__size__unit__little__signed, (V[]){v_t_2423, v_size_244, v_unit_245, v_little_246, v_signed_247})});
            return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2424, v_p_242});
          }
          case TAG_Just: {
            V v_ru_24ty_243_24Just = heff_take_reuse_n(v_ty_243, 0ULL, 1);
            heff_drop(v_size_244);
            heff_drop(v_unit_245);
            heff_drop(v_little_246);
            heff_drop(v_signed_247);
            V v_t_2426 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2especWord_str9), heff_rec_n(2, shape_start__end, (V[]){v_start_249, v_end_2410}), NTAG(TAG_Nothing)});
            return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24ty_243_24Just, TAG_Left, 1, (V[]){v_t_2426}), v_p_242});
          }
          default: return heff_nomatch(v_ty_243);
          }
        } else {
          if (heff_strEq_c_lent(v_text_248, ((V)&g_heff_2esyntax_2esurface_2especWord_str10), 2)) {
            heff_drop(v_text_248);
            switch (heff_tag_of(v_ty_243)) {
            case TAG_Nothing: {
              heff_drop(v_start_249);
              heff_drop(v_end_2410);
              V v_t_2427 = heff_tag_n(TAG_Just, 1, (V[]){heff_tag_n(TAG_SegmentUtf, 1, (V[]){MK_INT(8LL)})});
              V v_t_2428 = heff_tag_n(TAG_Right, 1, (V[]){heff_rec_n(5, shape_ty__size__unit__little__signed, (V[]){v_t_2427, v_size_244, v_unit_245, v_little_246, v_signed_247})});
              return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2428, v_p_242});
            }
            case TAG_Just: {
              V v_ru_24ty_243_24Just = heff_take_reuse_n(v_ty_243, 0ULL, 1);
              heff_drop(v_size_244);
              heff_drop(v_unit_245);
              heff_drop(v_little_246);
              heff_drop(v_signed_247);
              V v_t_2430 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2especWord_str11), heff_rec_n(2, shape_start__end, (V[]){v_start_249, v_end_2410}), NTAG(TAG_Nothing)});
              return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24ty_243_24Just, TAG_Left, 1, (V[]){v_t_2430}), v_p_242});
            }
            default: return heff_nomatch(v_ty_243);
            }
          } else {
            if (heff_strEq_c_lent(v_text_248, ((V)&g_heff_2esyntax_2esurface_2especWord_str12), 2)) {
              heff_drop(v_text_248);
              switch (heff_tag_of(v_ty_243)) {
              case TAG_Nothing: {
                heff_drop(v_start_249);
                heff_drop(v_end_2410);
                V v_t_2431 = heff_tag_n(TAG_Just, 1, (V[]){heff_tag_n(TAG_SegmentUtf, 1, (V[]){MK_INT(16LL)})});
                V v_t_2432 = heff_tag_n(TAG_Right, 1, (V[]){heff_rec_n(5, shape_ty__size__unit__little__signed, (V[]){v_t_2431, v_size_244, v_unit_245, v_little_246, v_signed_247})});
                return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2432, v_p_242});
              }
              case TAG_Just: {
                V v_ru_24ty_243_24Just = heff_take_reuse_n(v_ty_243, 0ULL, 1);
                heff_drop(v_size_244);
                heff_drop(v_unit_245);
                heff_drop(v_little_246);
                heff_drop(v_signed_247);
                V v_t_2434 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2especWord_str13), heff_rec_n(2, shape_start__end, (V[]){v_start_249, v_end_2410}), NTAG(TAG_Nothing)});
                return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24ty_243_24Just, TAG_Left, 1, (V[]){v_t_2434}), v_p_242});
              }
              default: return heff_nomatch(v_ty_243);
              }
            } else {
              if (heff_strEq_c_lent(v_text_248, ((V)&g_heff_2esyntax_2esurface_2especWord_str14), 2)) {
                heff_drop(v_text_248);
                switch (heff_tag_of(v_ty_243)) {
                case TAG_Nothing: {
                  heff_drop(v_start_249);
                  heff_drop(v_end_2410);
                  V v_t_2435 = heff_tag_n(TAG_Just, 1, (V[]){heff_tag_n(TAG_SegmentUtf, 1, (V[]){MK_INT(32LL)})});
                  V v_t_2436 = heff_tag_n(TAG_Right, 1, (V[]){heff_rec_n(5, shape_ty__size__unit__little__signed, (V[]){v_t_2435, v_size_244, v_unit_245, v_little_246, v_signed_247})});
                  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2436, v_p_242});
                }
                case TAG_Just: {
                  V v_ru_24ty_243_24Just = heff_take_reuse_n(v_ty_243, 0ULL, 1);
                  heff_drop(v_size_244);
                  heff_drop(v_unit_245);
                  heff_drop(v_little_246);
                  heff_drop(v_signed_247);
                  V v_t_2438 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2especWord_str15), heff_rec_n(2, shape_start__end, (V[]){v_start_249, v_end_2410}), NTAG(TAG_Nothing)});
                  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24ty_243_24Just, TAG_Left, 1, (V[]){v_t_2438}), v_p_242});
                }
                default: return heff_nomatch(v_ty_243);
                }
              } else {
                if (heff_strEq_c_lent(v_text_248, ((V)&g_heff_2esyntax_2esurface_2especWord_str16), 2)) {
                  heff_drop(v_text_248);
                  switch (heff_tag_of(v_little_246)) {
                  case TAG_Nothing: {
                    heff_drop(v_start_249);
                    heff_drop(v_end_2410);
                    V v_t_2439 = heff_tag_n(TAG_Just, 1, (V[]){NTAG(TAG_False)});
                    V v_t_2440 = heff_tag_n(TAG_Right, 1, (V[]){heff_rec_n(5, shape_ty__size__unit__little__signed, (V[]){v_ty_243, v_size_244, v_unit_245, v_t_2439, v_signed_247})});
                    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2440, v_p_242});
                  }
                  case TAG_Just: {
                    V v_ru_24little_246_24Just = heff_take_reuse_n(v_little_246, 0ULL, 1);
                    heff_drop(v_ty_243);
                    heff_drop(v_size_244);
                    heff_drop(v_unit_245);
                    heff_drop(v_signed_247);
                    V v_t_2442 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2especWord_str17), heff_rec_n(2, shape_start__end, (V[]){v_start_249, v_end_2410}), NTAG(TAG_Nothing)});
                    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24little_246_24Just, TAG_Left, 1, (V[]){v_t_2442}), v_p_242});
                  }
                  default: return heff_nomatch(v_little_246);
                  }
                } else {
                  if (heff_strEq_c_lent(v_text_248, ((V)&g_heff_2esyntax_2esurface_2especWord_str18), 2)) {
                    heff_drop(v_text_248);
                    switch (heff_tag_of(v_little_246)) {
                    case TAG_Nothing: {
                      heff_drop(v_start_249);
                      heff_drop(v_end_2410);
                      V v_t_2443 = heff_tag_n(TAG_Just, 1, (V[]){NTAG(TAG_True)});
                      V v_t_2444 = heff_tag_n(TAG_Right, 1, (V[]){heff_rec_n(5, shape_ty__size__unit__little__signed, (V[]){v_ty_243, v_size_244, v_unit_245, v_t_2443, v_signed_247})});
                      return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2444, v_p_242});
                    }
                    case TAG_Just: {
                      V v_ru_24little_246_24Just = heff_take_reuse_n(v_little_246, 0ULL, 1);
                      heff_drop(v_ty_243);
                      heff_drop(v_size_244);
                      heff_drop(v_unit_245);
                      heff_drop(v_signed_247);
                      V v_t_2446 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2especWord_str19), heff_rec_n(2, shape_start__end, (V[]){v_start_249, v_end_2410}), NTAG(TAG_Nothing)});
                      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24little_246_24Just, TAG_Left, 1, (V[]){v_t_2446}), v_p_242});
                    }
                    default: return heff_nomatch(v_little_246);
                    }
                  } else {
                    if (heff_strEq_c_lent(v_text_248, ((V)&g_heff_2esyntax_2esurface_2especWord_str20), 2)) {
                      heff_drop(v_text_248);
                      switch (heff_tag_of(v_signed_247)) {
                      case TAG_Nothing: {
                        heff_drop(v_start_249);
                        heff_drop(v_end_2410);
                        V v_t_2447 = heff_tag_n(TAG_Just, 1, (V[]){NTAG(TAG_True)});
                        V v_t_2448 = heff_tag_n(TAG_Right, 1, (V[]){heff_rec_n(5, shape_ty__size__unit__little__signed, (V[]){v_ty_243, v_size_244, v_unit_245, v_little_246, v_t_2447})});
                        return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2448, v_p_242});
                      }
                      case TAG_Just: {
                        V v_ru_24signed_247_24Just = heff_take_reuse_n(v_signed_247, 0ULL, 1);
                        heff_drop(v_ty_243);
                        heff_drop(v_size_244);
                        heff_drop(v_unit_245);
                        heff_drop(v_little_246);
                        V v_t_2450 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2especWord_str21), heff_rec_n(2, shape_start__end, (V[]){v_start_249, v_end_2410}), NTAG(TAG_Nothing)});
                        return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24signed_247_24Just, TAG_Left, 1, (V[]){v_t_2450}), v_p_242});
                      }
                      default: return heff_nomatch(v_signed_247);
                      }
                    } else {
                      if (heff_strEq_c(v_text_248, ((V)&g_heff_2esyntax_2esurface_2especWord_str22))) {
                        switch (heff_tag_of(v_signed_247)) {
                        case TAG_Nothing: {
                          heff_drop(v_start_249);
                          heff_drop(v_end_2410);
                          V v_t_2451 = heff_tag_n(TAG_Just, 1, (V[]){NTAG(TAG_False)});
                          V v_t_2452 = heff_tag_n(TAG_Right, 1, (V[]){heff_rec_n(5, shape_ty__size__unit__little__signed, (V[]){v_ty_243, v_size_244, v_unit_245, v_little_246, v_t_2451})});
                          return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2452, v_p_242});
                        }
                        case TAG_Just: {
                          V v_ru_24signed_247_24Just = heff_take_reuse_n(v_signed_247, 0ULL, 1);
                          heff_drop(v_ty_243);
                          heff_drop(v_size_244);
                          heff_drop(v_unit_245);
                          heff_drop(v_little_246);
                          V v_t_2454 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2especWord_str23), heff_rec_n(2, shape_start__end, (V[]){v_start_249, v_end_2410}), NTAG(TAG_Nothing)});
                          return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24signed_247_24Just, TAG_Left, 1, (V[]){v_t_2454}), v_p_242});
                        }
                        default: return heff_nomatch(v_signed_247);
                        }
                      } else {
                        heff_drop(v_ty_243);
                        heff_drop(v_size_244);
                        heff_drop(v_unit_245);
                        heff_drop(v_little_246);
                        heff_drop(v_signed_247);
                        V v_t_2455 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2especWord_str24), heff_rec_n(2, shape_start__end, (V[]){v_start_249, v_end_2410}), NTAG(TAG_Nothing)});
                        return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2455}), v_p_242});
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}
V g_heff_2esyntax_2esurface_2especWord_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2especWord(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2esyntax_2esurface_2eunitOf_str0, 3, "int");
HEFF_LIT(g_heff_2esyntax_2esurface_2eunitOf_str1, 28, "a segment says its unit once");
HEFF_LIT(g_heff_2esyntax_2esurface_2eunitOf_str2, 47, "a unit is a number of bits, 1 to 256: `unit(8)`");
V g_heff_2esyntax_2esurface_2eunitOf_lam0(V self, V *args);
V g_heff_2esyntax_2esurface_2eunitOf_lam1(V self, V *args);
Clo g_heff_2esyntax_2esurface_2eunitOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eunitOf_entry, 3, 0};

V g_heff_2esyntax_2esurface_2eunitOf(V v_sp_240, V v_n_241, V v_s_242) {
top: ;
  V v_unit_243 = heff_take_field(v_s_242, 2);
  V v_ty_244 = heff_take_field(v_s_242, 0);
  V v_size_245 = heff_take_field(v_s_242, 1);
  V v_little_246 = heff_take_field(v_s_242, 3);
  V v_signed_247 = heff_get_n(v_s_242, 4, 5);
  V v_kind_248 = heff_take_field(v_n_241, 0);
  V v_text_249 = heff_get_n(v_n_241, 1, 9);
  if ((heff_strEq_c_lent(v_kind_248, ((V)&g_heff_2esyntax_2esurface_2eunitOf_str0), 2) && ({ V v_t_2417 = (g_heff_2esyntax_2esurface_2eintOfText(v_text_249)); int c_ = (heff_intLe_c_lent(MK_INT(1LL), v_t_2417, 1) && ({ V v_t_2418 = (g_heff_2esyntax_2esurface_2eintOfText(v_text_249)); int c_ = heff_intLe_c_lent(v_t_2418, MK_INT(256LL), 2); heff_drop(v_t_2418); c_; })); heff_drop(v_t_2417); c_; }))) {
    heff_drop(v_kind_248);
    V v_n_2410 = ({ V a_0 = v_text_249; V r_ = (g_heff_2esyntax_2esurface_2eintOfText(a_0)); heff_drop(v_text_249); r_; });
    return heff_clo_n(g_heff_2esyntax_2esurface_2eunitOf_lam0, 1, 7, (V[]){v_unit_243, v_ty_244, v_size_245, v_n_2410, v_little_246, v_signed_247, v_sp_240});
  } else {
    heff_drop(v_unit_243);
    heff_drop(v_ty_244);
    heff_drop(v_size_245);
    heff_drop(v_little_246);
    heff_drop(v_signed_247);
    heff_drop(v_kind_248);
    heff_drop(v_text_249);
    return heff_clo_n(g_heff_2esyntax_2esurface_2eunitOf_lam1, 1, 1, (V[]){v_sp_240});
  }
}
V g_heff_2esyntax_2esurface_2eunitOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2eunitOf(a[0], a[1], a[2]);
}
V g_heff_2esyntax_2esurface_2eunitOf_lam0(V self, V *args) {
  V v_p_2411 = args[0];
  V v_unit_243 = heff_env(self)[0];
  V v_ty_244 = heff_env(self)[1];
  V v_size_245 = heff_env(self)[2];
  V v_n_2410 = heff_env(self)[3];
  V v_little_246 = heff_env(self)[4];
  V v_signed_247 = heff_env(self)[5];
  V v_sp_240 = heff_env(self)[6];
  heff_clo_take(self, 7);
  switch (heff_tag_of(v_unit_243)) {
  case TAG_Nothing: {
    heff_drop(v_sp_240);
    V v_t_2412 = heff_rec_n(5, shape_ty__size__unit__little__signed, (V[]){v_ty_244, v_size_245, heff_tag_n(TAG_Just, 1, (V[]){v_n_2410}), v_little_246, v_signed_247});
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2412}), v_p_2411});
  }
  case TAG_Just: {
    V v_ru_24unit_243_24Just = heff_take_reuse_n(v_unit_243, 0ULL, 1);
    heff_drop(v_ty_244);
    heff_drop(v_size_245);
    heff_drop(v_n_2410);
    heff_drop(v_little_246);
    heff_drop(v_signed_247);
    V v_t_2414 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2eunitOf_str1), v_sp_240, NTAG(TAG_Nothing)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24unit_243_24Just, TAG_Left, 1, (V[]){v_t_2414}), v_p_2411});
  }
  default: return heff_nomatch(v_unit_243);
  }
}
V g_heff_2esyntax_2esurface_2eunitOf_lam1(V self, V *args) {
  V v_st_2415 = args[0];
  V v_sp_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2416 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), ((V)&g_heff_2esyntax_2esurface_2eunitOf_str2), v_sp_240, NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2416}), v_st_2415});
}
Clo g_heff_2esyntax_2esurface_2esegmentOf_24s1547151193x813882637_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2esegmentOf_24s1547151193x813882637_entry, 5, 0};

V g_heff_2esyntax_2esurface_2esegmentOf_24s1547151193x813882637(V v_inPat_240, V v_sp_241, V v_e_242, V v_v_243, V v_st_244) {
top: ;
  V v_t_246;
  switch (heff_tag_of(v_v_243)) {
  case TAG_StrValue: {
    v_t_246 = NTAG(TAG_SegmentBinary);
    break;
  }
  case TAG_IntValue: {
    v_t_246 = NTAG(TAG_SegmentInteger);
    break;
  }
  case TAG_FloatValue: {
    v_t_246 = NTAG(TAG_SegmentFloat);
    break;
  }
  case TAG_RuneValue: {
    v_t_246 = heff_tag_n(TAG_SegmentUtf, 1, (V[]){MK_INT(8LL)});
    break;
  }
  case TAG_OtherValue: {
    v_t_246 = NTAG(TAG_SegmentInteger);
    break;
  }
  default: heff_nomatch(v_v_243);
  }
  HeffT2 v_t_247 = (g_heff_2esyntax_2esurface_2evalueKind_24cpr(heff_dup(v_sp_241), heff_dup(v_v_243), v_t_246, v_st_244));
  {
    V v_field_248 = v_t_247.f[0];
    V v_field_249 = v_t_247.f[1];
    V v_x11_2410 = v_field_248;
    V v_st_2411 = v_field_249;
    switch (heff_tag_of(v_x11_2410)) {
    case TAG_Left: {
      V v_e_2412 = heff_field(v_x11_2410, 0);
      V v_ru_24x11_2410_24Left = heff_take_reuse_n(v_x11_2410, 1ULL, 1);
      heff_drop(v_sp_241);
      heff_drop(v_e_242);
      heff_drop(v_v_243);
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_2410_24Left, TAG_Left, 1, (V[]){v_e_2412}), v_st_2411});
    }
    case TAG_Right: {
      V v_ru_24x11_2410_24Right = heff_take_reuse_n(v_x11_2410, 0ULL, 1);
      V v_t_2415;
      switch (heff_tag_of(v_v_243)) {
      case TAG_StrValue: {
        v_t_2415 = NTAG(TAG_SegmentBinary);
        break;
      }
      case TAG_IntValue: {
        v_t_2415 = NTAG(TAG_SegmentInteger);
        break;
      }
      case TAG_FloatValue: {
        v_t_2415 = NTAG(TAG_SegmentFloat);
        break;
      }
      case TAG_RuneValue: {
        v_t_2415 = heff_tag_n(TAG_SegmentUtf, 1, (V[]){MK_INT(8LL)});
        break;
      }
      case TAG_OtherValue: {
        v_t_2415 = NTAG(TAG_SegmentInteger);
        break;
      }
      default: heff_nomatch(v_v_243);
      }
      V v_m_2416 = (g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993(v_inPat_240, heff_dup(v_sp_241), heff_dup(v_v_243), v_t_2415, NTAG(TAG_SizeDefault)));
      V v_x1_2417 = heff_tr(heff_call(v_m_2416, 1, (V[]){v_st_2411}));
      switch (heff_tag_of(v_x1_2417)) {
      case TAG_MkPair: {
        V v_x11_2418 = heff_field(v_x1_2417, 0);
        V v_st_2419 = heff_field(v_x1_2417, 1);
        V v_ru_24x1_2417_24MkPair = heff_take_reuse_n(v_x1_2417, 3ULL, 2);
        switch (heff_tag_of(v_x11_2418)) {
        case TAG_Left: {
          V v_e_2420 = heff_field(v_x11_2418, 0);
          heff_take_n(v_x11_2418, 1ULL, 1);
          heff_drop(v_sp_241);
          heff_drop(v_e_242);
          heff_drop(v_v_243);
          heff_drop_cell(v_ru_24x11_2410_24Right, 1);
          return heff_tag_at_n(v_ru_24x1_2417_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2420}), v_st_2419});
        }
        case TAG_Right: {
          V v_ru_24x11_2418_24Right = heff_take_reuse_n(v_x11_2418, 0ULL, 1);
          V v_t_2423;
          switch (heff_tag_of(v_v_243)) {
          case TAG_StrValue: {
            heff_drop_cell(v_ru_24x11_2418_24Right, 1);
            v_t_2423 = NTAG(TAG_SegmentBinary);
            break;
          }
          case TAG_IntValue: {
            heff_take_n(v_v_243, 0ULL, 1);
            heff_drop_cell(v_ru_24x11_2418_24Right, 1);
            v_t_2423 = NTAG(TAG_SegmentInteger);
            break;
          }
          case TAG_FloatValue: {
            heff_drop_cell(v_ru_24x11_2418_24Right, 1);
            v_t_2423 = NTAG(TAG_SegmentFloat);
            break;
          }
          case TAG_RuneValue: {
            v_t_2423 = heff_tag_at_n(v_ru_24x11_2418_24Right, TAG_SegmentUtf, 1, (V[]){MK_INT(8LL)});
            break;
          }
          case TAG_OtherValue: {
            heff_drop_cell(v_ru_24x11_2418_24Right, 1);
            v_t_2423 = NTAG(TAG_SegmentInteger);
            break;
          }
          default: heff_nomatch(v_v_243);
          }
          V v_t_2424 = heff_tag_n(TAG_MkSegment, 5, (V[]){v_e_242, v_t_2423, NTAG(TAG_SizeDefault), NTAG(TAG_False), NTAG(TAG_False)});
          V v_t_2425 = heff_tag_at_n(v_ru_24x11_2410_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2424, v_sp_241})});
          return heff_tag_at_n(v_ru_24x1_2417_24MkPair, TAG_MkPair, 2, (V[]){v_t_2425, v_st_2419});
        }
        default: return heff_nomatch(v_x11_2418);
        }
      }
      default: return heff_nomatch(v_x1_2417);
      }
    }
    default: return heff_nomatch(v_x11_2410);
    }
  }
}
V g_heff_2esyntax_2esurface_2esegmentOf_24s1547151193x813882637_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2esyntax_2esurface_2esegmentOf_24s1547151193x813882637(a0, a[1], a[2], a[3], a[4]); heff_drop(a0); return r;
}
V g_heff_2esyntax_2esurface_2epushS_24s1868233564x1858628873_lam0(V self, V *args);
V g_heff_2esyntax_2esurface_2epushS_24s1868233564x1858628873_lam1(V self, V *args);
Clo g_heff_2esyntax_2esurface_2epushS_24s1868233564x1858628873_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2epushS_24s1868233564x1858628873_entry, 4, 0};

V g_heff_2esyntax_2esurface_2epushS_24s1868233564x1858628873(V v_fix_240, V v_lenient_241, V v_st_242, V v_r_243) {
top: ;
  V v_t_244 = heff_dup(heff_rfield(v_st_242, 0));
  switch (heff_tag_of(v_t_244)) {
  case TAG_Nil: {
    heff_drop(v_fix_240);
    return heff_clo_n(g_heff_2esyntax_2esurface_2epushS_24s1868233564x1858628873_lam0, 1, 2, (V[]){v_r_243, v_st_242});
  }
  case TAG_Cons: {
    V v_before_249 = heff_field(v_t_244, 0);
    heff_take_n(v_t_244, 1ULL, 2);
    V v_m_2411 = (g_heff_2esyntax_2esurface_2efirstS(heff_dup(v_fix_240), v_lenient_241, v_before_249, heff_dup(heff_rfield(v_r_243, 0))));
    return heff_clo_n(g_heff_2esyntax_2esurface_2epushS_24s1868233564x1858628873_lam1, 1, 5, (V[]){v_m_2411, v_st_242, v_fix_240, heff_dup(v_lenient_241), v_r_243});
  }
  default: return heff_nomatch(v_t_244);
  }
}
V g_heff_2esyntax_2esurface_2epushS_24s1868233564x1858628873_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2esyntax_2esurface_2epushS_24s1868233564x1858628873(a[0], a1, a[2], a[3]); heff_drop(a1); return r;
}
V g_heff_2esyntax_2esurface_2epushS_24s1868233564x1858628873_lam0(V self, V *args) {
  V v_st_245 = args[0];
  V v_r_243 = heff_env(self)[0];
  V v_st_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){heff_take_field(v_r_243, 0), heff_take_field(v_st_242, 0)});
  V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){heff_get_n(v_r_243, 1, 2), heff_get_n(v_st_242, 1, 2)});
  V v_t_248 = heff_tag_n(TAG_Right, 1, (V[]){heff_rec_n(2, shape_ops__out, (V[]){v_t_246, v_t_247})});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_248, v_st_245});
}
V g_heff_2esyntax_2esurface_2epushS_24s1868233564x1858628873_lam1(V self, V *args) {
  V v_st_2412 = args[0];
  V v_m_2411 = heff_env(self)[0];
  V v_st_242 = heff_env(self)[1];
  V v_fix_240 = heff_env(self)[2];
  V v_lenient_241 = heff_env(self)[3];
  V v_r_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_x1_2413 = heff_tr(heff_call(v_m_2411, 1, (V[]){v_st_2412}));
  switch (heff_tag_of(v_x1_2413)) {
  case TAG_MkPair: {
    V v_x11_2414 = heff_field(v_x1_2413, 0);
    V v_st_2415 = heff_field(v_x1_2413, 1);
    V v_ru_24x1_2413_24MkPair = heff_take_reuse_n(v_x1_2413, 3ULL, 2);
    switch (heff_tag_of(v_x11_2414)) {
    case TAG_Left: {
      V v_e_2416 = heff_field(v_x11_2414, 0);
      heff_take_n(v_x11_2414, 1ULL, 1);
      heff_drop_rec(v_st_242, 2);
      heff_drop(v_fix_240);
      heff_drop(v_lenient_241);
      heff_drop_rec(v_r_243, 2);
      return heff_tag_at_n(v_ru_24x1_2413_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2416}), v_st_2415});
    }
    case TAG_Right: {
      V v_x_2417 = heff_field(v_x11_2414, 0);
      V v_ru_24x11_2414_24Right = heff_take_reuse_n(v_x11_2414, 1ULL, 1);
      if ((heff_dup(v_x_2417) == NTAG(TAG_True))) {
        heff_drop_cell(v_ru_24x1_2413_24MkPair, 2);
        heff_drop(v_x_2417);
        heff_drop_cell(v_ru_24x11_2414_24Right, 1);
        V v_t_2418 = heff_dup(heff_rfield(v_st_242, 0));
        V v_t_2427;
        switch (heff_tag_of(v_t_2418)) {
        case TAG_Nil: {
          v_t_2427 = v_st_242;
          break;
        }
        case TAG_Cons: {
          V v_o_2419 = heff_field(v_t_2418, 0);
          V v_os_2420 = heff_field(v_t_2418, 1);
          heff_take_n(v_t_2418, 3ULL, 2);
          V v_t_2421 = heff_dup(heff_rfield(v_st_242, 1));
          switch (heff_tag_of(v_t_2421)) {
          case TAG_Nil: {
            heff_drop(v_o_2419);
            heff_drop(v_os_2420);
            v_t_2427 = v_st_242;
            break;
          }
          case TAG_Cons: {
            V v_r_2422 = heff_field(v_t_2421, 0);
            V v_it2_2423 = heff_field(v_t_2421, 1);
            heff_take_n(v_t_2421, 3ULL, 2);
            switch (heff_tag_of(v_it2_2423)) {
            case TAG_Nil: {
              heff_drop(v_o_2419);
              heff_drop(v_os_2420);
              heff_drop(v_r_2422);
              v_t_2427 = v_st_242;
              break;
            }
            case TAG_Cons: {
              V v_l_2424 = heff_field(v_it2_2423, 0);
              V v_rest_2425 = heff_field(v_it2_2423, 1);
              heff_take_n(v_it2_2423, 3ULL, 2);
              heff_drop_rec(v_st_242, 2);
              V v_t_2426 = (g_heff_2esyntax_2esurface_2eapplyOp(v_o_2419, v_l_2424, v_r_2422));
              v_t_2427 = heff_rec_n(2, shape_ops__out, (V[]){v_os_2420, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2426, v_rest_2425})});
              break;
            }
            default: heff_nomatch(v_it2_2423);
            }
            break;
          }
          default: heff_nomatch(v_t_2421);
          }
          break;
        }
        default: heff_nomatch(v_t_2418);
        }
        V v_t_2428 = ({ V a_0 = v_fix_240; V a_1 = v_lenient_241; V a_2 = v_t_2427; V a_3 = v_r_243; V r_ = (g_heff_2esyntax_2esurface_2epushS_24s1868233564x1858628873(a_0, a_1, a_2, a_3)); heff_drop(v_lenient_241); r_; });
        V f_ = v_t_2428;
        args[0] = v_st_2415;
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      } else {
        heff_drop(v_fix_240);
        heff_drop(v_lenient_241);
        heff_drop(v_x_2417);
        V v_t_2429 = heff_tag_n(TAG_Cons, 2, (V[]){heff_take_field(v_r_243, 0), heff_take_field(v_st_242, 0)});
        V v_t_2430 = heff_tag_n(TAG_Cons, 2, (V[]){heff_get_n(v_r_243, 1, 2), heff_get_n(v_st_242, 1, 2)});
        V v_t_2431 = heff_tag_at_n(v_ru_24x11_2414_24Right, TAG_Right, 1, (V[]){heff_rec_n(2, shape_ops__out, (V[]){v_t_2429, v_t_2430})});
        return heff_tag_at_n(v_ru_24x1_2413_24MkPair, TAG_MkPair, 2, (V[]){v_t_2431, v_st_2415});
      }
    }
    default: return heff_nomatch(v_x11_2414);
    }
  }
  default: return heff_nomatch(v_x1_2413);
  }
}
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str0, 3, "con");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str1, 3, "var");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str2, 7, " := e)`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str3, 51, " := ...)` names an argument, after a function: `f (");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str4, 2, "`(");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str5, 2, "b[");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str6, 1, "[");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str7, 3, "Nil");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str8, 4, "Cons");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str9, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str10, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str11, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str12, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str13, 61, "an instance argument is bound before `->`: `{{x : T}} -> ...`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str14, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str15, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str16, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str17, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str18, 3, "con");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str19, 2, "kw");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str20, 3, "var");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str21, 3, "neg");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str22, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str23, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str24, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str25, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str26, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str27, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str28, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str29, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str30, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str31, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str32, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str33, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str34, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str35, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str36, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str37, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str38, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str39, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str40, 5, "break");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str41, 1, "`");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str42, 12, "unexpected `");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str43, 8, "with#arg");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str44, 8, "with#arg");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str45, 8, "with#arg");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str46, 8, "with#arg");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str47, 8, "with#arg");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str48, 8, "with#arg");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str49, 8, "with#arg");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str50, 8, "with#arg");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str51, 8, "with#arg");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str52, 8, "with#arg");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str53, 8, "with#arg");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str54, 8, "with#arg");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str55, 8, "with#arg");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str56, 8, "with#arg");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str57, 8, "with#arg");
HEFF_LIT(g_heff_2esyntax_2esurface_2eexprL_str58, 8, "with#arg");
V g_heff_2esyntax_2esurface_2eexprL_lam0(V self, V *args);
V g_heff_2esyntax_2esurface_2eexprL_lam1(V self, V *args);
V g_heff_2esyntax_2esurface_2eexprL_lam2(V self, V *args);
V g_heff_2esyntax_2esurface_2eexprL_lam3(V self, V *args);
V g_heff_2esyntax_2esurface_2eexprL_lam4(V self, V *args);
V g_heff_2esyntax_2esurface_2eexprL_lam6(V self, V *args);
V g_heff_2esyntax_2esurface_2eexprL_lam5(V self, V *args);
V g_heff_2esyntax_2esurface_2eexprL_lam7(V self, V *args);
V g_heff_2esyntax_2esurface_2eexprL_lam8(V self, V *args);
V g_heff_2esyntax_2esurface_2eexprL_lam9(V self, V *args);
V g_heff_2esyntax_2esurface_2eexprL_lam10(V self, V *args);
V g_heff_2esyntax_2esurface_2eexprL_lam11(V self, V *args);
V g_heff_2esyntax_2esurface_2eexprL_lam12(V self, V *args);
V g_heff_2esyntax_2esurface_2eexprL_lam13(V self, V *args);
V g_heff_2esyntax_2esurface_2eexprL_lam14(V self, V *args);
V g_heff_2esyntax_2esurface_2eexprL_lam15(V self, V *args);
V g_heff_2esyntax_2esurface_2eexprL_lam16(V self, V *args);
V g_heff_2esyntax_2esurface_2eexprL_lam17(V self, V *args);
V g_heff_2esyntax_2esurface_2eexprL_lam18(V self, V *args);
V g_heff_2esyntax_2esurface_2eexprL_lam19(V self, V *args);
V g_heff_2esyntax_2esurface_2eexprL_lam20(V self, V *args);
Clo g_heff_2esyntax_2esurface_2eexprL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eexprL_entry, 3, 0};

V g_heff_2esyntax_2esurface_2eexprL(V v_r_240, V v_e0_241, V v_z_242) {
top: ;
  switch (heff_tag_of(v_e0_241)) {
  case TAG_Atom: {
    V v_t_243 = heff_field(v_e0_241, 0);
    V v_ru_24e0_241_24Atom = heff_take_reuse_n(v_e0_241, 1ULL, 1);
    heff_drop_rec(v_r_240, 3);
    if (heff_strEq_c(heff_dup(heff_rfield(v_t_243, 0)), ((V)&g_heff_2esyntax_2esurface_2eexprL_str0))) {
      heff_drop_cell(v_ru_24e0_241_24Atom, 1);
      HEFF_LAST return g_heff_2esyntax_2esurface_2econAtom(v_t_243, NTAG(TAG_Nil), v_z_242);
    } else {
      if (heff_strEq_c(heff_dup(heff_rfield(v_t_243, 0)), ((V)&g_heff_2esyntax_2esurface_2eexprL_str1))) {
        return (g_heff_2esyntax_2esurface_2evarAtom_24tok1(v_ru_24e0_241_24Atom, v_t_243, NTAG(TAG_Nil), v_z_242));
      } else {
        V v_x_244 = (g_heff_2esyntax_2esurface_2eatomTok(v_t_243));
        return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24e0_241_24Atom, TAG_Right, 1, (V[]){v_x_244}), v_z_242});
      }
    }
  }
  case TAG_EParen: {
    V v_o_245 = heff_field(v_e0_241, 0);
    V v_e_246 = heff_field(v_e0_241, 1);
    V v_c_247 = heff_field(v_e0_241, 2);
    heff_take_n(v_e0_241, 7ULL, 3);
    return ({ V a_0 = v_r_240; V a_1 = v_o_245; V a_2 = v_e_246; V a_3 = v_c_247; V a_4 = v_z_242; V r_ = (g_heff_2esyntax_2esurface_2eparenL(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_o_245); r_; });
  }
  case TAG_Named: {
    V v_o_248 = heff_field(v_e0_241, 0);
    V v_x_249 = heff_field(v_e0_241, 1);
    V v_e_2411 = heff_field(v_e0_241, 3);
    V v_c_2412 = heff_field(v_e0_241, 4);
    heff_take_n(v_e0_241, 27ULL, 5);
    V v_m_2413 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_2411}));
    V v_x1_2414 = heff_tr(heff_call(v_m_2413, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x1_2414)) {
    case TAG_MkPair: {
      V v_x11_2415 = heff_field(v_x1_2414, 0);
      V v_st_2416 = heff_field(v_x1_2414, 1);
      V v_ru_24x1_2414_24MkPair = heff_take_reuse_n(v_x1_2414, 3ULL, 2);
      switch (heff_tag_of(v_x11_2415)) {
      case TAG_Left: {
        V v_e_2417 = heff_field(v_x11_2415, 0);
        heff_take_n(v_x11_2415, 1ULL, 1);
        heff_drop_rec(v_o_248, 9);
        heff_drop_rec(v_x_249, 9);
        heff_drop_rec(v_c_2412, 9);
        return heff_tag_at_n(v_ru_24x1_2414_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2417}), v_st_2416});
      }
      case TAG_Right: {
        V v_ru_24x11_2415_24Right = heff_take_reuse_n(v_x11_2415, 0ULL, 1);
        V v_t_2419 = heff_strAppend(heff_dup(heff_rfield(v_x_249, 1)), ((V)&g_heff_2esyntax_2esurface_2eexprL_str2));
        V v_t_2420 = heff_strAppend(heff_get_n(v_x_249, 1, 9), heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eexprL_str3), v_t_2419));
        V v_t_2421 = heff_tag_n(TAG_EInvalid, 1, (V[]){heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eexprL_str4), v_t_2420)});
        V v_t_2422 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_o_248, 3, 9), heff_get_n(v_c_2412, 4, 9)});
        V v_t_2423 = heff_tag_at_n(v_ru_24x11_2415_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2421, v_t_2422})});
        return heff_tag_at_n(v_ru_24x1_2414_24MkPair, TAG_MkPair, 2, (V[]){v_t_2423, v_st_2416});
      }
      default: return heff_nomatch(v_x11_2415);
      }
    }
    default: return heff_nomatch(v_x1_2414);
    }
  }
  case TAG_Tup: {
    V v_o_2424 = heff_field(v_e0_241, 0);
    V v_es_2425 = heff_field(v_e0_241, 1);
    V v_c_2427 = heff_field(v_e0_241, 3);
    heff_take_n(v_e0_241, 11ULL, 4);
    V v_text_2428 = heff_take_field(v_o_2424, 1);
    V v_start_2429 = heff_get_n(v_o_2424, 3, 9);
    if (heff_strEq_c_lent(v_text_2428, ((V)&g_heff_2esyntax_2esurface_2eexprL_str5), 2)) {
      heff_drop(v_text_2428);
      V v_m_2431 = (g_prelude_2etraverse_24s499544530x2060473942(heff_clo_n(g_heff_2esyntax_2esurface_2eexprL_lam0, 1, 1, (V[]){v_r_240}), v_es_2425));
      V v_x1_2432 = heff_tr(heff_call(v_m_2431, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_2432)) {
      case TAG_MkPair: {
        V v_x11_2433 = heff_field(v_x1_2432, 0);
        V v_st_2434 = heff_field(v_x1_2432, 1);
        V v_ru_24x1_2432_24MkPair = heff_take_reuse_n(v_x1_2432, 3ULL, 2);
        switch (heff_tag_of(v_x11_2433)) {
        case TAG_Left: {
          V v_e_2435 = heff_field(v_x11_2433, 0);
          heff_take_n(v_x11_2433, 1ULL, 1);
          heff_drop_rec(v_c_2427, 9);
          heff_drop(v_start_2429);
          return heff_tag_at_n(v_ru_24x1_2432_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2435}), v_st_2434});
        }
        case TAG_Right: {
          V v_x_2436 = heff_field(v_x11_2433, 0);
          V v_ru_24x11_2433_24Right = heff_take_reuse_n(v_x11_2433, 1ULL, 1);
          V v_t_2437 = heff_rec_n(2, shape_start__end, (V[]){v_start_2429, heff_get_n(v_c_2427, 4, 9)});
          V v_t_2438 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_2433_24Right, TAG_EBinary, 1, (V[]){v_x_2436}), v_t_2437});
          return heff_tag_at_n(v_ru_24x1_2432_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2438}), v_st_2434});
        }
        default: return heff_nomatch(v_x11_2433);
        }
      }
      default: return heff_nomatch(v_x1_2432);
      }
    } else {
      if (heff_strEq_c(v_text_2428, ((V)&g_heff_2esyntax_2esurface_2eexprL_str6))) {
        V v_m_2439 = (g_prelude_2etraverse_24s499544530x2060473942(heff_get_n(v_r_240, 0, 3), v_es_2425));
        V v_x1_2440 = heff_tr(heff_call(v_m_2439, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_2440)) {
        case TAG_MkPair: {
          V v_x11_2441 = heff_field(v_x1_2440, 0);
          V v_st_2442 = heff_field(v_x1_2440, 1);
          V v_ru_24x1_2440_24MkPair = heff_take_reuse_n(v_x1_2440, 3ULL, 2);
          switch (heff_tag_of(v_x11_2441)) {
          case TAG_Left: {
            V v_e_2443 = heff_field(v_x11_2441, 0);
            heff_take_n(v_x11_2441, 1ULL, 1);
            heff_drop_rec(v_c_2427, 9);
            heff_drop(v_start_2429);
            return heff_tag_at_n(v_ru_24x1_2440_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2443}), v_st_2442});
          }
          case TAG_Right: {
            V v_x_2444 = heff_field(v_x11_2441, 0);
            V v_ru_24x11_2441_24Right = heff_take_reuse_n(v_x11_2441, 1ULL, 1);
            V v_sp_2445 = heff_rec_n(2, shape_start__end, (V[]){v_start_2429, heff_get_n(v_c_2427, 4, 9)});
            V v_t_2446 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_2441_24Right, TAG_ETag, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2eexprL_str7)}), heff_dup(v_sp_2445)});
            V v_x_2451 = ({ V a_0 = heff_clo_n(g_heff_2esyntax_2esurface_2eexprL_lam1, 2, 1, (V[]){v_sp_2445}); V a_1 = v_t_2446; V a_2 = v_x_2444; V r_ = heff_tr(g_heff_2esyntax_2esurface_2efoldr(a_0, a_1, a_2)); heff_drop(v_x_2444); r_; });
            return heff_tag_at_n(v_ru_24x1_2440_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_2451}), v_st_2442});
          }
          default: return heff_nomatch(v_x11_2441);
          }
        }
        default: return heff_nomatch(v_x1_2440);
        }
      } else {
        V v_m_2452 = (g_prelude_2etraverse_24s499544530x2060473942(heff_get_n(v_r_240, 0, 3), v_es_2425));
        V v_x1_2453 = heff_tr(heff_call(v_m_2452, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_2453)) {
        case TAG_MkPair: {
          V v_x11_2454 = heff_field(v_x1_2453, 0);
          V v_st_2455 = heff_field(v_x1_2453, 1);
          V v_ru_24x1_2453_24MkPair = heff_take_reuse_n(v_x1_2453, 3ULL, 2);
          switch (heff_tag_of(v_x11_2454)) {
          case TAG_Left: {
            V v_e_2456 = heff_field(v_x11_2454, 0);
            heff_take_n(v_x11_2454, 1ULL, 1);
            heff_drop_rec(v_c_2427, 9);
            heff_drop(v_start_2429);
            return heff_tag_at_n(v_ru_24x1_2453_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2456}), v_st_2455});
          }
          case TAG_Right: {
            V v_x_2457 = heff_field(v_x11_2454, 0);
            V v_ru_24x11_2454_24Right = heff_take_reuse_n(v_x11_2454, 1ULL, 1);
            V v_t_2458 = heff_rec_n(2, shape_start__end, (V[]){v_start_2429, heff_get_n(v_c_2427, 4, 9)});
            V v_t_2459 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_2454_24Right, TAG_ETuple, 1, (V[]){v_x_2457}), v_t_2458});
            return heff_tag_at_n(v_ru_24x1_2453_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2459}), v_st_2455});
          }
          default: return heff_nomatch(v_x11_2454);
          }
        }
        default: return heff_nomatch(v_x1_2453);
        }
      }
    }
  }
  case TAG_Seg: {
    heff_drop_rec(v_r_240, 3);
    V v_t_2463 = (g_heff_2esyntax_2ecst_2efirstE(v_e0_241));
    V v_start_2464 = heff_take_field(v_t_2463, 3);
    V v_end_2465 = heff_get_n(v_t_2463, 4, 9);
    V v_t_2466 = ({ V a_0 = v_e0_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e0_241, 3); r_; });
    V v_t_2467 = heff_strAppend(heff_get_n(v_t_2466, 1, 9), ((V)&g_heff_2esyntax_2esurface_2eexprL_str9));
    V v_msg_2468 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eexprL_str10), v_t_2467);
    V v_t_2469 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_2468, heff_rec_n(2, shape_start__end, (V[]){v_start_2464, v_end_2465}), NTAG(TAG_Nothing)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_2469}), v_z_242});
  }
  case TAG_Braces: {
    V v_o_2470 = heff_field(v_e0_241, 0);
    V v_fs_2471 = heff_field(v_e0_241, 1);
    V v_c_2473 = heff_field(v_e0_241, 3);
    heff_take_n(v_e0_241, 11ULL, 4);
    return (g_heff_2esyntax_2esurface_2ebracesL(v_r_240, v_o_2470, v_fs_2471, v_c_2473, v_z_242));
  }
  case TAG_Update: {
    V v_o_2474 = heff_field(v_e0_241, 0);
    V v_rec_2475 = heff_field(v_e0_241, 1);
    V v_fs_2477 = heff_field(v_e0_241, 3);
    V v_c_2479 = heff_field(v_e0_241, 5);
    heff_take_n(v_e0_241, 43ULL, 6);
    V v_m_2480 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_rec_2475}));
    V v_x1_2481 = heff_tr(heff_call(v_m_2480, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x1_2481)) {
    case TAG_MkPair: {
      V v_x11_2482 = heff_field(v_x1_2481, 0);
      V v_st_2483 = heff_field(v_x1_2481, 1);
      V v_ru_24x1_2481_24MkPair = heff_take_reuse_n(v_x1_2481, 3ULL, 2);
      switch (heff_tag_of(v_x11_2482)) {
      case TAG_Left: {
        V v_e_2484 = heff_field(v_x11_2482, 0);
        heff_take_n(v_x11_2482, 1ULL, 1);
        heff_drop_rec(v_r_240, 3);
        heff_drop_rec(v_o_2474, 9);
        heff_drop(v_fs_2477);
        heff_drop_rec(v_c_2479, 9);
        return heff_tag_at_n(v_ru_24x1_2481_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2484}), v_st_2483});
      }
      case TAG_Right: {
        V v_x_2485 = heff_field(v_x11_2482, 0);
        heff_take_n(v_x11_2482, 1ULL, 1);
        V v_m_2487 = (g_prelude_2etraverse_24s499544530x2060473942(heff_clo_n(g_heff_2esyntax_2esurface_2eexprL_lam2, 1, 1, (V[]){v_r_240}), v_fs_2477));
        V v_x1_2488 = heff_tr(heff_call(v_m_2487, 1, (V[]){v_st_2483}));
        switch (heff_tag_of(v_x1_2488)) {
        case TAG_MkPair: {
          V v_x11_2489 = heff_field(v_x1_2488, 0);
          V v_st_2490 = heff_field(v_x1_2488, 1);
          V v_ru_24x1_2488_24MkPair = heff_take_reuse_n(v_x1_2488, 3ULL, 2);
          switch (heff_tag_of(v_x11_2489)) {
          case TAG_Left: {
            V v_e_2491 = heff_field(v_x11_2489, 0);
            heff_take_n(v_x11_2489, 1ULL, 1);
            heff_drop_rec(v_o_2474, 9);
            heff_drop_rec(v_c_2479, 9);
            heff_drop(v_x_2485);
            heff_drop_cell(v_ru_24x1_2488_24MkPair, 2);
            return heff_tag_at_n(v_ru_24x1_2481_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2491}), v_st_2490});
          }
          case TAG_Right: {
            V v_x_2492 = heff_field(v_x11_2489, 0);
            heff_take_n(v_x11_2489, 1ULL, 1);
            V v_t_2493 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_o_2474, 3, 9), heff_get_n(v_c_2479, 4, 9)});
            V v_t_2494 = heff_tag_at_n(v_ru_24x1_2488_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_EUpdate, 2, (V[]){v_x_2485, v_x_2492}), v_t_2493});
            return heff_tag_at_n(v_ru_24x1_2481_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_2494}), v_st_2490});
          }
          default: return heff_nomatch(v_x11_2489);
          }
        }
        default: return heff_nomatch(v_x1_2488);
        }
      }
      default: return heff_nomatch(v_x11_2482);
      }
    }
    default: return heff_nomatch(v_x1_2481);
    }
  }
  case TAG_EUSet: {
    heff_drop_rec(v_r_240, 3);
    V v_t_2498 = (g_heff_2esyntax_2ecst_2efirstE(v_e0_241));
    V v_start_2499 = heff_take_field(v_t_2498, 3);
    V v_end_24100 = heff_get_n(v_t_2498, 4, 9);
    V v_t_24101 = ({ V a_0 = v_e0_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e0_241, 3); r_; });
    V v_t_24102 = heff_strAppend(heff_get_n(v_t_24101, 1, 9), ((V)&g_heff_2esyntax_2esurface_2eexprL_str11));
    V v_msg_24103 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eexprL_str12), v_t_24102);
    V v_t_24104 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24103, heff_rec_n(2, shape_start__end, (V[]){v_start_2499, v_end_24100}), NTAG(TAG_Nothing)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24104}), v_z_242});
  }
  case TAG_InstB: {
    V v_o_24105 = heff_field(v_e0_241, 0);
    V v_d_24107 = heff_field(v_e0_241, 2);
    V v_c_24109 = heff_field(v_e0_241, 4);
    heff_take_n(v_e0_241, 21ULL, 5);
    V v_m_24110 = (g_heff_2esyntax_2esurface_2edeclarationL(v_r_240, v_d_24107));
    V v_x1_24111 = heff_tr(heff_call(v_m_24110, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x1_24111)) {
    case TAG_MkPair: {
      V v_x11_24112 = heff_field(v_x1_24111, 0);
      V v_st_24113 = heff_field(v_x1_24111, 1);
      V v_ru_24x1_24111_24MkPair = heff_take_reuse_n(v_x1_24111, 3ULL, 2);
      switch (heff_tag_of(v_x11_24112)) {
      case TAG_Left: {
        V v_e_24114 = heff_field(v_x11_24112, 0);
        heff_take_n(v_x11_24112, 1ULL, 1);
        heff_drop_rec(v_o_24105, 9);
        heff_drop_rec(v_c_24109, 9);
        return heff_tag_at_n(v_ru_24x1_24111_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24114}), v_st_24113});
      }
      case TAG_Right: {
        V v_ru_24x11_24112_24Right = heff_take_reuse_n(v_x11_24112, 0ULL, 1);
        V v_t_24116 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_o_24105, 3, 9), heff_get_n(v_c_24109, 4, 9)});
        V v_t_24117 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24112_24Right, TAG_EInvalid, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2eexprL_str13)}), v_t_24116});
        return heff_tag_at_n(v_ru_24x1_24111_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24117}), v_st_24113});
      }
      default: return heff_nomatch(v_x11_24112);
      }
    }
    default: return heff_nomatch(v_x1_24111);
    }
  }
  case TAG_EFSet: {
    heff_drop_rec(v_r_240, 3);
    V v_t_24121 = (g_heff_2esyntax_2ecst_2efirstE(v_e0_241));
    V v_start_24122 = heff_take_field(v_t_24121, 3);
    V v_end_24123 = heff_get_n(v_t_24121, 4, 9);
    V v_t_24124 = ({ V a_0 = v_e0_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e0_241, 3); r_; });
    V v_t_24125 = heff_strAppend(heff_get_n(v_t_24124, 1, 9), ((V)&g_heff_2esyntax_2esurface_2eexprL_str14));
    V v_msg_24126 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eexprL_str15), v_t_24125);
    V v_t_24127 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24126, heff_rec_n(2, shape_start__end, (V[]){v_start_24122, v_end_24123}), NTAG(TAG_Nothing)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24127}), v_z_242});
  }
  case TAG_EFDefault: {
    heff_drop_rec(v_r_240, 3);
    V v_t_24131 = (g_heff_2esyntax_2ecst_2efirstE(v_e0_241));
    V v_start_24132 = heff_take_field(v_t_24131, 3);
    V v_end_24133 = heff_get_n(v_t_24131, 4, 9);
    V v_t_24134 = ({ V a_0 = v_e0_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e0_241, 3); r_; });
    V v_t_24135 = heff_strAppend(heff_get_n(v_t_24134, 1, 9), ((V)&g_heff_2esyntax_2esurface_2eexprL_str16));
    V v_msg_24136 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eexprL_str17), v_t_24135);
    V v_t_24137 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24136, heff_rec_n(2, shape_start__end, (V[]){v_start_24132, v_end_24133}), NTAG(TAG_Nothing)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24137}), v_z_242});
  }
  case TAG_Sum: {
    V v_kw_24138 = heff_field(v_e0_241, 0);
    V v_alts_24140 = heff_field(v_e0_241, 2);
    V v_c_24142 = heff_field(v_e0_241, 4);
    heff_take_n(v_e0_241, 21ULL, 5);
    V v_m_24144 = (g_prelude_2etraverse_24s499544530x2060473942(heff_clo_n(g_heff_2esyntax_2esurface_2eexprL_lam3, 1, 1, (V[]){v_r_240}), v_alts_24140));
    V v_x1_24145 = heff_tr(heff_call(v_m_24144, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x1_24145)) {
    case TAG_MkPair: {
      V v_x11_24146 = heff_field(v_x1_24145, 0);
      V v_st_24147 = heff_field(v_x1_24145, 1);
      V v_ru_24x1_24145_24MkPair = heff_take_reuse_n(v_x1_24145, 3ULL, 2);
      switch (heff_tag_of(v_x11_24146)) {
      case TAG_Left: {
        V v_e_24148 = heff_field(v_x11_24146, 0);
        heff_take_n(v_x11_24146, 1ULL, 1);
        heff_drop_rec(v_kw_24138, 9);
        heff_drop_rec(v_c_24142, 9);
        return heff_tag_at_n(v_ru_24x1_24145_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24148}), v_st_24147});
      }
      case TAG_Right: {
        V v_x_24149 = heff_field(v_x11_24146, 0);
        V v_ru_24x11_24146_24Right = heff_take_reuse_n(v_x11_24146, 1ULL, 1);
        V v_t_24150 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_24138, 3, 9), heff_get_n(v_c_24142, 4, 9)});
        V v_t_24151 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_24146_24Right, TAG_ESum, 1, (V[]){v_x_24149}), v_t_24150});
        return heff_tag_at_n(v_ru_24x1_24145_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24151}), v_st_24147});
      }
      default: return heff_nomatch(v_x11_24146);
      }
    }
    default: return heff_nomatch(v_x1_24145);
    }
  }
  case TAG_ECon: {
    V v_c_24152 = heff_field(v_e0_241, 0);
    V v_args_24153 = heff_field(v_e0_241, 1);
    heff_take_n(v_e0_241, 3ULL, 2);
    V v_t_24154 = (g_heff_2esyntax_2esurface_2econL(v_r_240, v_c_24152, v_args_24153));
    return heff_tail(v_t_24154, 1, (V[]){v_z_242});
  }
  case TAG_EField: {
    V v_e_24155 = heff_field(v_e0_241, 0);
    V v_f_24156 = heff_field(v_e0_241, 1);
    V v_ru_24e0_241_24EField = heff_take_reuse_n(v_e0_241, 3ULL, 2);
    HeffT2 v_t_24157 = (g_heff_2esyntax_2esurface_2efieldsOf_24cpr(heff_tag_at_n(v_ru_24e0_241_24EField, TAG_EField, 2, (V[]){v_e_24155, v_f_24156}), NTAG(TAG_Nil)));
    {
      V v_field_24158 = v_t_24157.f[0];
      V v_field_24159 = v_t_24157.f[1];
      V v_it1_24160 = v_field_24158;
      V v_fs_24161 = v_field_24159;
      switch (heff_tag_of(v_it1_24160)) {
      case TAG_Atom: {
        V v_t_24162 = heff_field(v_it1_24160, 0);
        V v_ru_24it1_24160_24Atom = heff_take_reuse_n(v_it1_24160, 1ULL, 1);
        heff_drop_rec(v_r_240, 3);
        if (heff_strEq_c(heff_dup(heff_rfield(v_t_24162, 0)), ((V)&g_heff_2esyntax_2esurface_2eexprL_str18))) {
          heff_drop_cell(v_ru_24it1_24160_24Atom, 1);
          HEFF_LAST return g_heff_2esyntax_2esurface_2econAtom(v_t_24162, v_fs_24161, v_z_242);
        } else {
          if (heff_strEq_c(heff_dup(heff_rfield(v_t_24162, 0)), ((V)&g_heff_2esyntax_2esurface_2eexprL_str19))) {
            return (g_heff_2esyntax_2esurface_2ekwAtom_24tok1(v_ru_24it1_24160_24Atom, v_t_24162, v_fs_24161, v_z_242));
          } else {
            if (heff_strEq_c(heff_dup(heff_rfield(v_t_24162, 0)), ((V)&g_heff_2esyntax_2esurface_2eexprL_str20))) {
              return (g_heff_2esyntax_2esurface_2evarAtom_24tok1(v_ru_24it1_24160_24Atom, v_t_24162, v_fs_24161, v_z_242));
            } else {
              V v_e_24163 = (g_heff_2esyntax_2esurface_2eatomTok(v_t_24162));
              V v_t_24164 = (g_list_2emap_24s513201124x806973253(v_fs_24161));
              V v_x_24165 = (g_heff_2esyntax_2epresyntax_2eapp(v_e_24163, v_t_24164));
              return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24it1_24160_24Atom, TAG_Right, 1, (V[]){v_x_24165}), v_z_242});
            }
          }
        }
      }
      case TAG_EParen: {
        V v_m_24169 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24160}));
        V v_x1_24170 = heff_tr(heff_call(v_m_24169, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24170)) {
        case TAG_MkPair: {
          V v_x11_24171 = heff_field(v_x1_24170, 0);
          V v_st_24172 = heff_field(v_x1_24170, 1);
          V v_ru_24x1_24170_24MkPair = heff_take_reuse_n(v_x1_24170, 3ULL, 2);
          switch (heff_tag_of(v_x11_24171)) {
          case TAG_Left: {
            V v_e_24173 = heff_field(v_x11_24171, 0);
            heff_take_n(v_x11_24171, 1ULL, 1);
            heff_drop(v_fs_24161);
            return heff_tag_at_n(v_ru_24x1_24170_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24173}), v_st_24172});
          }
          case TAG_Right: {
            V v_x_24174 = heff_field(v_x11_24171, 0);
            heff_take_n(v_x11_24171, 1ULL, 1);
            V v_t_24175 = (g_list_2emap_24s513201124x806973253(v_fs_24161));
            V v_x_24176 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24174, v_t_24175));
            return heff_tag_at_n(v_ru_24x1_24170_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24176}), v_st_24172});
          }
          default: return heff_nomatch(v_x11_24171);
          }
        }
        default: return heff_nomatch(v_x1_24170);
        }
      }
      case TAG_Named: {
        V v_m_24182 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24160}));
        V v_x1_24183 = heff_tr(heff_call(v_m_24182, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24183)) {
        case TAG_MkPair: {
          V v_x11_24184 = heff_field(v_x1_24183, 0);
          V v_st_24185 = heff_field(v_x1_24183, 1);
          V v_ru_24x1_24183_24MkPair = heff_take_reuse_n(v_x1_24183, 3ULL, 2);
          switch (heff_tag_of(v_x11_24184)) {
          case TAG_Left: {
            V v_e_24186 = heff_field(v_x11_24184, 0);
            heff_take_n(v_x11_24184, 1ULL, 1);
            heff_drop(v_fs_24161);
            return heff_tag_at_n(v_ru_24x1_24183_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24186}), v_st_24185});
          }
          case TAG_Right: {
            V v_x_24187 = heff_field(v_x11_24184, 0);
            heff_take_n(v_x11_24184, 1ULL, 1);
            V v_t_24188 = (g_list_2emap_24s513201124x806973253(v_fs_24161));
            V v_x_24189 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24187, v_t_24188));
            return heff_tag_at_n(v_ru_24x1_24183_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24189}), v_st_24185});
          }
          default: return heff_nomatch(v_x11_24184);
          }
        }
        default: return heff_nomatch(v_x1_24183);
        }
      }
      case TAG_Tup: {
        V v_m_24194 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24160}));
        V v_x1_24195 = heff_tr(heff_call(v_m_24194, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24195)) {
        case TAG_MkPair: {
          V v_x11_24196 = heff_field(v_x1_24195, 0);
          V v_st_24197 = heff_field(v_x1_24195, 1);
          V v_ru_24x1_24195_24MkPair = heff_take_reuse_n(v_x1_24195, 3ULL, 2);
          switch (heff_tag_of(v_x11_24196)) {
          case TAG_Left: {
            V v_e_24198 = heff_field(v_x11_24196, 0);
            heff_take_n(v_x11_24196, 1ULL, 1);
            heff_drop(v_fs_24161);
            return heff_tag_at_n(v_ru_24x1_24195_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24198}), v_st_24197});
          }
          case TAG_Right: {
            V v_x_24199 = heff_field(v_x11_24196, 0);
            heff_take_n(v_x11_24196, 1ULL, 1);
            V v_t_24200 = (g_list_2emap_24s513201124x806973253(v_fs_24161));
            V v_x_24201 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24199, v_t_24200));
            return heff_tag_at_n(v_ru_24x1_24195_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24201}), v_st_24197});
          }
          default: return heff_nomatch(v_x11_24196);
          }
        }
        default: return heff_nomatch(v_x1_24195);
        }
      }
      case TAG_Seg: {
        V v_m_24205 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24160}));
        V v_x1_24206 = heff_tr(heff_call(v_m_24205, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24206)) {
        case TAG_MkPair: {
          V v_x11_24207 = heff_field(v_x1_24206, 0);
          V v_st_24208 = heff_field(v_x1_24206, 1);
          V v_ru_24x1_24206_24MkPair = heff_take_reuse_n(v_x1_24206, 3ULL, 2);
          switch (heff_tag_of(v_x11_24207)) {
          case TAG_Left: {
            V v_e_24209 = heff_field(v_x11_24207, 0);
            heff_take_n(v_x11_24207, 1ULL, 1);
            heff_drop(v_fs_24161);
            return heff_tag_at_n(v_ru_24x1_24206_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24209}), v_st_24208});
          }
          case TAG_Right: {
            V v_x_24210 = heff_field(v_x11_24207, 0);
            heff_take_n(v_x11_24207, 1ULL, 1);
            V v_t_24211 = (g_list_2emap_24s513201124x806973253(v_fs_24161));
            V v_x_24212 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24210, v_t_24211));
            return heff_tag_at_n(v_ru_24x1_24206_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24212}), v_st_24208});
          }
          default: return heff_nomatch(v_x11_24207);
          }
        }
        default: return heff_nomatch(v_x1_24206);
        }
      }
      case TAG_Braces: {
        V v_m_24217 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24160}));
        V v_x1_24218 = heff_tr(heff_call(v_m_24217, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24218)) {
        case TAG_MkPair: {
          V v_x11_24219 = heff_field(v_x1_24218, 0);
          V v_st_24220 = heff_field(v_x1_24218, 1);
          V v_ru_24x1_24218_24MkPair = heff_take_reuse_n(v_x1_24218, 3ULL, 2);
          switch (heff_tag_of(v_x11_24219)) {
          case TAG_Left: {
            V v_e_24221 = heff_field(v_x11_24219, 0);
            heff_take_n(v_x11_24219, 1ULL, 1);
            heff_drop(v_fs_24161);
            return heff_tag_at_n(v_ru_24x1_24218_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24221}), v_st_24220});
          }
          case TAG_Right: {
            V v_x_24222 = heff_field(v_x11_24219, 0);
            heff_take_n(v_x11_24219, 1ULL, 1);
            V v_t_24223 = (g_list_2emap_24s513201124x806973253(v_fs_24161));
            V v_x_24224 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24222, v_t_24223));
            return heff_tag_at_n(v_ru_24x1_24218_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24224}), v_st_24220});
          }
          default: return heff_nomatch(v_x11_24219);
          }
        }
        default: return heff_nomatch(v_x1_24218);
        }
      }
      case TAG_Update: {
        V v_m_24231 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24160}));
        V v_x1_24232 = heff_tr(heff_call(v_m_24231, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24232)) {
        case TAG_MkPair: {
          V v_x11_24233 = heff_field(v_x1_24232, 0);
          V v_st_24234 = heff_field(v_x1_24232, 1);
          V v_ru_24x1_24232_24MkPair = heff_take_reuse_n(v_x1_24232, 3ULL, 2);
          switch (heff_tag_of(v_x11_24233)) {
          case TAG_Left: {
            V v_e_24235 = heff_field(v_x11_24233, 0);
            heff_take_n(v_x11_24233, 1ULL, 1);
            heff_drop(v_fs_24161);
            return heff_tag_at_n(v_ru_24x1_24232_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24235}), v_st_24234});
          }
          case TAG_Right: {
            V v_x_24236 = heff_field(v_x11_24233, 0);
            heff_take_n(v_x11_24233, 1ULL, 1);
            V v_t_24237 = (g_list_2emap_24s513201124x806973253(v_fs_24161));
            V v_x_24238 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24236, v_t_24237));
            return heff_tag_at_n(v_ru_24x1_24232_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24238}), v_st_24234});
          }
          default: return heff_nomatch(v_x11_24233);
          }
        }
        default: return heff_nomatch(v_x1_24232);
        }
      }
      case TAG_EUSet: {
        V v_m_24242 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24160}));
        V v_x1_24243 = heff_tr(heff_call(v_m_24242, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24243)) {
        case TAG_MkPair: {
          V v_x11_24244 = heff_field(v_x1_24243, 0);
          V v_st_24245 = heff_field(v_x1_24243, 1);
          V v_ru_24x1_24243_24MkPair = heff_take_reuse_n(v_x1_24243, 3ULL, 2);
          switch (heff_tag_of(v_x11_24244)) {
          case TAG_Left: {
            V v_e_24246 = heff_field(v_x11_24244, 0);
            heff_take_n(v_x11_24244, 1ULL, 1);
            heff_drop(v_fs_24161);
            return heff_tag_at_n(v_ru_24x1_24243_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24246}), v_st_24245});
          }
          case TAG_Right: {
            V v_x_24247 = heff_field(v_x11_24244, 0);
            heff_take_n(v_x11_24244, 1ULL, 1);
            V v_t_24248 = (g_list_2emap_24s513201124x806973253(v_fs_24161));
            V v_x_24249 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24247, v_t_24248));
            return heff_tag_at_n(v_ru_24x1_24243_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24249}), v_st_24245});
          }
          default: return heff_nomatch(v_x11_24244);
          }
        }
        default: return heff_nomatch(v_x1_24243);
        }
      }
      case TAG_InstB: {
        V v_m_24255 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24160}));
        V v_x1_24256 = heff_tr(heff_call(v_m_24255, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24256)) {
        case TAG_MkPair: {
          V v_x11_24257 = heff_field(v_x1_24256, 0);
          V v_st_24258 = heff_field(v_x1_24256, 1);
          V v_ru_24x1_24256_24MkPair = heff_take_reuse_n(v_x1_24256, 3ULL, 2);
          switch (heff_tag_of(v_x11_24257)) {
          case TAG_Left: {
            V v_e_24259 = heff_field(v_x11_24257, 0);
            heff_take_n(v_x11_24257, 1ULL, 1);
            heff_drop(v_fs_24161);
            return heff_tag_at_n(v_ru_24x1_24256_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24259}), v_st_24258});
          }
          case TAG_Right: {
            V v_x_24260 = heff_field(v_x11_24257, 0);
            heff_take_n(v_x11_24257, 1ULL, 1);
            V v_t_24261 = (g_list_2emap_24s513201124x806973253(v_fs_24161));
            V v_x_24262 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24260, v_t_24261));
            return heff_tag_at_n(v_ru_24x1_24256_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24262}), v_st_24258});
          }
          default: return heff_nomatch(v_x11_24257);
          }
        }
        default: return heff_nomatch(v_x1_24256);
        }
      }
      case TAG_EFSet: {
        V v_m_24266 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24160}));
        V v_x1_24267 = heff_tr(heff_call(v_m_24266, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24267)) {
        case TAG_MkPair: {
          V v_x11_24268 = heff_field(v_x1_24267, 0);
          V v_st_24269 = heff_field(v_x1_24267, 1);
          V v_ru_24x1_24267_24MkPair = heff_take_reuse_n(v_x1_24267, 3ULL, 2);
          switch (heff_tag_of(v_x11_24268)) {
          case TAG_Left: {
            V v_e_24270 = heff_field(v_x11_24268, 0);
            heff_take_n(v_x11_24268, 1ULL, 1);
            heff_drop(v_fs_24161);
            return heff_tag_at_n(v_ru_24x1_24267_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24270}), v_st_24269});
          }
          case TAG_Right: {
            V v_x_24271 = heff_field(v_x11_24268, 0);
            heff_take_n(v_x11_24268, 1ULL, 1);
            V v_t_24272 = (g_list_2emap_24s513201124x806973253(v_fs_24161));
            V v_x_24273 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24271, v_t_24272));
            return heff_tag_at_n(v_ru_24x1_24267_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24273}), v_st_24269});
          }
          default: return heff_nomatch(v_x11_24268);
          }
        }
        default: return heff_nomatch(v_x1_24267);
        }
      }
      case TAG_EFDefault: {
        V v_m_24277 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24160}));
        V v_x1_24278 = heff_tr(heff_call(v_m_24277, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24278)) {
        case TAG_MkPair: {
          V v_x11_24279 = heff_field(v_x1_24278, 0);
          V v_st_24280 = heff_field(v_x1_24278, 1);
          V v_ru_24x1_24278_24MkPair = heff_take_reuse_n(v_x1_24278, 3ULL, 2);
          switch (heff_tag_of(v_x11_24279)) {
          case TAG_Left: {
            V v_e_24281 = heff_field(v_x11_24279, 0);
            heff_take_n(v_x11_24279, 1ULL, 1);
            heff_drop(v_fs_24161);
            return heff_tag_at_n(v_ru_24x1_24278_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24281}), v_st_24280});
          }
          case TAG_Right: {
            V v_x_24282 = heff_field(v_x11_24279, 0);
            heff_take_n(v_x11_24279, 1ULL, 1);
            V v_t_24283 = (g_list_2emap_24s513201124x806973253(v_fs_24161));
            V v_x_24284 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24282, v_t_24283));
            return heff_tag_at_n(v_ru_24x1_24278_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24284}), v_st_24280});
          }
          default: return heff_nomatch(v_x11_24279);
          }
        }
        default: return heff_nomatch(v_x1_24278);
        }
      }
      case TAG_Sum: {
        V v_m_24290 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24160}));
        V v_x1_24291 = heff_tr(heff_call(v_m_24290, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24291)) {
        case TAG_MkPair: {
          V v_x11_24292 = heff_field(v_x1_24291, 0);
          V v_st_24293 = heff_field(v_x1_24291, 1);
          V v_ru_24x1_24291_24MkPair = heff_take_reuse_n(v_x1_24291, 3ULL, 2);
          switch (heff_tag_of(v_x11_24292)) {
          case TAG_Left: {
            V v_e_24294 = heff_field(v_x11_24292, 0);
            heff_take_n(v_x11_24292, 1ULL, 1);
            heff_drop(v_fs_24161);
            return heff_tag_at_n(v_ru_24x1_24291_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24294}), v_st_24293});
          }
          case TAG_Right: {
            V v_x_24295 = heff_field(v_x11_24292, 0);
            heff_take_n(v_x11_24292, 1ULL, 1);
            V v_t_24296 = (g_list_2emap_24s513201124x806973253(v_fs_24161));
            V v_x_24297 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24295, v_t_24296));
            return heff_tag_at_n(v_ru_24x1_24291_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24297}), v_st_24293});
          }
          default: return heff_nomatch(v_x11_24292);
          }
        }
        default: return heff_nomatch(v_x1_24291);
        }
      }
      case TAG_ECon: {
        V v_m_24300 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24160}));
        V v_x1_24301 = heff_tr(heff_call(v_m_24300, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24301)) {
        case TAG_MkPair: {
          V v_x11_24302 = heff_field(v_x1_24301, 0);
          V v_st_24303 = heff_field(v_x1_24301, 1);
          V v_ru_24x1_24301_24MkPair = heff_take_reuse_n(v_x1_24301, 3ULL, 2);
          switch (heff_tag_of(v_x11_24302)) {
          case TAG_Left: {
            V v_e_24304 = heff_field(v_x11_24302, 0);
            heff_take_n(v_x11_24302, 1ULL, 1);
            heff_drop(v_fs_24161);
            return heff_tag_at_n(v_ru_24x1_24301_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24304}), v_st_24303});
          }
          case TAG_Right: {
            V v_x_24305 = heff_field(v_x11_24302, 0);
            heff_take_n(v_x11_24302, 1ULL, 1);
            V v_t_24306 = (g_list_2emap_24s513201124x806973253(v_fs_24161));
            V v_x_24307 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24305, v_t_24306));
            return heff_tag_at_n(v_ru_24x1_24301_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24307}), v_st_24303});
          }
          default: return heff_nomatch(v_x11_24302);
          }
        }
        default: return heff_nomatch(v_x1_24301);
        }
      }
      case TAG_EField: {
        V v_m_24310 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24160}));
        V v_x1_24311 = heff_tr(heff_call(v_m_24310, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24311)) {
        case TAG_MkPair: {
          V v_x11_24312 = heff_field(v_x1_24311, 0);
          V v_st_24313 = heff_field(v_x1_24311, 1);
          V v_ru_24x1_24311_24MkPair = heff_take_reuse_n(v_x1_24311, 3ULL, 2);
          switch (heff_tag_of(v_x11_24312)) {
          case TAG_Left: {
            V v_e_24314 = heff_field(v_x11_24312, 0);
            heff_take_n(v_x11_24312, 1ULL, 1);
            heff_drop(v_fs_24161);
            return heff_tag_at_n(v_ru_24x1_24311_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24314}), v_st_24313});
          }
          case TAG_Right: {
            V v_x_24315 = heff_field(v_x11_24312, 0);
            heff_take_n(v_x11_24312, 1ULL, 1);
            V v_t_24316 = (g_list_2emap_24s513201124x806973253(v_fs_24161));
            V v_x_24317 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24315, v_t_24316));
            return heff_tag_at_n(v_ru_24x1_24311_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24317}), v_st_24313});
          }
          default: return heff_nomatch(v_x11_24312);
          }
        }
        default: return heff_nomatch(v_x1_24311);
        }
      }
      case TAG_ENeg: {
        V v_m_24320 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24160}));
        V v_x1_24321 = heff_tr(heff_call(v_m_24320, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24321)) {
        case TAG_MkPair: {
          V v_x11_24322 = heff_field(v_x1_24321, 0);
          V v_st_24323 = heff_field(v_x1_24321, 1);
          V v_ru_24x1_24321_24MkPair = heff_take_reuse_n(v_x1_24321, 3ULL, 2);
          switch (heff_tag_of(v_x11_24322)) {
          case TAG_Left: {
            V v_e_24324 = heff_field(v_x11_24322, 0);
            heff_take_n(v_x11_24322, 1ULL, 1);
            heff_drop(v_fs_24161);
            return heff_tag_at_n(v_ru_24x1_24321_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24324}), v_st_24323});
          }
          case TAG_Right: {
            V v_x_24325 = heff_field(v_x11_24322, 0);
            heff_take_n(v_x11_24322, 1ULL, 1);
            V v_t_24326 = (g_list_2emap_24s513201124x806973253(v_fs_24161));
            V v_x_24327 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24325, v_t_24326));
            return heff_tag_at_n(v_ru_24x1_24321_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24327}), v_st_24323});
          }
          default: return heff_nomatch(v_x11_24322);
          }
        }
        default: return heff_nomatch(v_x1_24321);
        }
      }
      case TAG_ETilde: {
        V v_m_24330 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24160}));
        V v_x1_24331 = heff_tr(heff_call(v_m_24330, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24331)) {
        case TAG_MkPair: {
          V v_x11_24332 = heff_field(v_x1_24331, 0);
          V v_st_24333 = heff_field(v_x1_24331, 1);
          V v_ru_24x1_24331_24MkPair = heff_take_reuse_n(v_x1_24331, 3ULL, 2);
          switch (heff_tag_of(v_x11_24332)) {
          case TAG_Left: {
            V v_e_24334 = heff_field(v_x11_24332, 0);
            heff_take_n(v_x11_24332, 1ULL, 1);
            heff_drop(v_fs_24161);
            return heff_tag_at_n(v_ru_24x1_24331_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24334}), v_st_24333});
          }
          case TAG_Right: {
            V v_x_24335 = heff_field(v_x11_24332, 0);
            heff_take_n(v_x11_24332, 1ULL, 1);
            V v_t_24336 = (g_list_2emap_24s513201124x806973253(v_fs_24161));
            V v_x_24337 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24335, v_t_24336));
            return heff_tag_at_n(v_ru_24x1_24331_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24337}), v_st_24333});
          }
          default: return heff_nomatch(v_x11_24332);
          }
        }
        default: return heff_nomatch(v_x1_24331);
        }
      }
      case TAG_App: {
        V v_m_24340 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24160}));
        V v_x1_24341 = heff_tr(heff_call(v_m_24340, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24341)) {
        case TAG_MkPair: {
          V v_x11_24342 = heff_field(v_x1_24341, 0);
          V v_st_24343 = heff_field(v_x1_24341, 1);
          V v_ru_24x1_24341_24MkPair = heff_take_reuse_n(v_x1_24341, 3ULL, 2);
          switch (heff_tag_of(v_x11_24342)) {
          case TAG_Left: {
            V v_e_24344 = heff_field(v_x11_24342, 0);
            heff_take_n(v_x11_24342, 1ULL, 1);
            heff_drop(v_fs_24161);
            return heff_tag_at_n(v_ru_24x1_24341_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24344}), v_st_24343});
          }
          case TAG_Right: {
            V v_x_24345 = heff_field(v_x11_24342, 0);
            heff_take_n(v_x11_24342, 1ULL, 1);
            V v_t_24346 = (g_list_2emap_24s513201124x806973253(v_fs_24161));
            V v_x_24347 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24345, v_t_24346));
            return heff_tag_at_n(v_ru_24x1_24341_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24347}), v_st_24343});
          }
          default: return heff_nomatch(v_x11_24342);
          }
        }
        default: return heff_nomatch(v_x1_24341);
        }
      }
      case TAG_Op: {
        V v_m_24351 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24160}));
        V v_x1_24352 = heff_tr(heff_call(v_m_24351, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24352)) {
        case TAG_MkPair: {
          V v_x11_24353 = heff_field(v_x1_24352, 0);
          V v_st_24354 = heff_field(v_x1_24352, 1);
          V v_ru_24x1_24352_24MkPair = heff_take_reuse_n(v_x1_24352, 3ULL, 2);
          switch (heff_tag_of(v_x11_24353)) {
          case TAG_Left: {
            V v_e_24355 = heff_field(v_x11_24353, 0);
            heff_take_n(v_x11_24353, 1ULL, 1);
            heff_drop(v_fs_24161);
            return heff_tag_at_n(v_ru_24x1_24352_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24355}), v_st_24354});
          }
          case TAG_Right: {
            V v_x_24356 = heff_field(v_x11_24353, 0);
            heff_take_n(v_x11_24353, 1ULL, 1);
            V v_t_24357 = (g_list_2emap_24s513201124x806973253(v_fs_24161));
            V v_x_24358 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24356, v_t_24357));
            return heff_tag_at_n(v_ru_24x1_24352_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24358}), v_st_24354});
          }
          default: return heff_nomatch(v_x11_24353);
          }
        }
        default: return heff_nomatch(v_x1_24352);
        }
      }
      case TAG_Ops: {
        V v_m_24361 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24160}));
        V v_x1_24362 = heff_tr(heff_call(v_m_24361, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24362)) {
        case TAG_MkPair: {
          V v_x11_24363 = heff_field(v_x1_24362, 0);
          V v_st_24364 = heff_field(v_x1_24362, 1);
          V v_ru_24x1_24362_24MkPair = heff_take_reuse_n(v_x1_24362, 3ULL, 2);
          switch (heff_tag_of(v_x11_24363)) {
          case TAG_Left: {
            V v_e_24365 = heff_field(v_x11_24363, 0);
            heff_take_n(v_x11_24363, 1ULL, 1);
            heff_drop(v_fs_24161);
            return heff_tag_at_n(v_ru_24x1_24362_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24365}), v_st_24364});
          }
          case TAG_Right: {
            V v_x_24366 = heff_field(v_x11_24363, 0);
            heff_take_n(v_x11_24363, 1ULL, 1);
            V v_t_24367 = (g_list_2emap_24s513201124x806973253(v_fs_24161));
            V v_x_24368 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24366, v_t_24367));
            return heff_tag_at_n(v_ru_24x1_24362_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24368}), v_st_24364});
          }
          default: return heff_nomatch(v_x11_24363);
          }
        }
        default: return heff_nomatch(v_x1_24362);
        }
      }
      case TAG_OpRhs: {
        V v_m_24371 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24160}));
        V v_x1_24372 = heff_tr(heff_call(v_m_24371, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24372)) {
        case TAG_MkPair: {
          V v_x11_24373 = heff_field(v_x1_24372, 0);
          V v_st_24374 = heff_field(v_x1_24372, 1);
          V v_ru_24x1_24372_24MkPair = heff_take_reuse_n(v_x1_24372, 3ULL, 2);
          switch (heff_tag_of(v_x11_24373)) {
          case TAG_Left: {
            V v_e_24375 = heff_field(v_x11_24373, 0);
            heff_take_n(v_x11_24373, 1ULL, 1);
            heff_drop(v_fs_24161);
            return heff_tag_at_n(v_ru_24x1_24372_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24375}), v_st_24374});
          }
          case TAG_Right: {
            V v_x_24376 = heff_field(v_x11_24373, 0);
            heff_take_n(v_x11_24373, 1ULL, 1);
            V v_t_24377 = (g_list_2emap_24s513201124x806973253(v_fs_24161));
            V v_x_24378 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24376, v_t_24377));
            return heff_tag_at_n(v_ru_24x1_24372_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24378}), v_st_24374});
          }
          default: return heff_nomatch(v_x11_24373);
          }
        }
        default: return heff_nomatch(v_x1_24372);
        }
      }
      case TAG_Ann: {
        V v_m_24382 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24160}));
        V v_x1_24383 = heff_tr(heff_call(v_m_24382, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24383)) {
        case TAG_MkPair: {
          V v_x11_24384 = heff_field(v_x1_24383, 0);
          V v_st_24385 = heff_field(v_x1_24383, 1);
          V v_ru_24x1_24383_24MkPair = heff_take_reuse_n(v_x1_24383, 3ULL, 2);
          switch (heff_tag_of(v_x11_24384)) {
          case TAG_Left: {
            V v_e_24386 = heff_field(v_x11_24384, 0);
            heff_take_n(v_x11_24384, 1ULL, 1);
            heff_drop(v_fs_24161);
            return heff_tag_at_n(v_ru_24x1_24383_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24386}), v_st_24385});
          }
          case TAG_Right: {
            V v_x_24387 = heff_field(v_x11_24384, 0);
            heff_take_n(v_x11_24384, 1ULL, 1);
            V v_t_24388 = (g_list_2emap_24s513201124x806973253(v_fs_24161));
            V v_x_24389 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24387, v_t_24388));
            return heff_tag_at_n(v_ru_24x1_24383_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24389}), v_st_24385});
          }
          default: return heff_nomatch(v_x11_24384);
          }
        }
        default: return heff_nomatch(v_x1_24383);
        }
      }
      case TAG_BVar: {
        V v_m_24391 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24160}));
        V v_x1_24392 = heff_tr(heff_call(v_m_24391, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24392)) {
        case TAG_MkPair: {
          V v_x11_24393 = heff_field(v_x1_24392, 0);
          V v_st_24394 = heff_field(v_x1_24392, 1);
          V v_ru_24x1_24392_24MkPair = heff_take_reuse_n(v_x1_24392, 3ULL, 2);
          switch (heff_tag_of(v_x11_24393)) {
          case TAG_Left: {
            V v_e_24395 = heff_field(v_x11_24393, 0);
            heff_take_n(v_x11_24393, 1ULL, 1);
            heff_drop(v_fs_24161);
            return heff_tag_at_n(v_ru_24x1_24392_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24395}), v_st_24394});
          }
          case TAG_Right: {
            V v_x_24396 = heff_field(v_x11_24393, 0);
            heff_take_n(v_x11_24393, 1ULL, 1);
            V v_t_24397 = (g_list_2emap_24s513201124x806973253(v_fs_24161));
            V v_x_24398 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24396, v_t_24397));
            return heff_tag_at_n(v_ru_24x1_24392_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24398}), v_st_24394});
          }
          default: return heff_nomatch(v_x11_24393);
          }
        }
        default: return heff_nomatch(v_x1_24392);
        }
      }
      case TAG_BImp: {
        V v_m_24402 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24160}));
        V v_x1_24403 = heff_tr(heff_call(v_m_24402, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24403)) {
        case TAG_MkPair: {
          V v_x11_24404 = heff_field(v_x1_24403, 0);
          V v_st_24405 = heff_field(v_x1_24403, 1);
          V v_ru_24x1_24403_24MkPair = heff_take_reuse_n(v_x1_24403, 3ULL, 2);
          switch (heff_tag_of(v_x11_24404)) {
          case TAG_Left: {
            V v_e_24406 = heff_field(v_x11_24404, 0);
            heff_take_n(v_x11_24404, 1ULL, 1);
            heff_drop(v_fs_24161);
            return heff_tag_at_n(v_ru_24x1_24403_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24406}), v_st_24405});
          }
          case TAG_Right: {
            V v_x_24407 = heff_field(v_x11_24404, 0);
            heff_take_n(v_x11_24404, 1ULL, 1);
            V v_t_24408 = (g_list_2emap_24s513201124x806973253(v_fs_24161));
            V v_x_24409 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24407, v_t_24408));
            return heff_tag_at_n(v_ru_24x1_24403_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24409}), v_st_24405});
          }
          default: return heff_nomatch(v_x11_24404);
          }
        }
        default: return heff_nomatch(v_x1_24403);
        }
      }
      case TAG_BAnn: {
        V v_m_24415 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24160}));
        V v_x1_24416 = heff_tr(heff_call(v_m_24415, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24416)) {
        case TAG_MkPair: {
          V v_x11_24417 = heff_field(v_x1_24416, 0);
          V v_st_24418 = heff_field(v_x1_24416, 1);
          V v_ru_24x1_24416_24MkPair = heff_take_reuse_n(v_x1_24416, 3ULL, 2);
          switch (heff_tag_of(v_x11_24417)) {
          case TAG_Left: {
            V v_e_24419 = heff_field(v_x11_24417, 0);
            heff_take_n(v_x11_24417, 1ULL, 1);
            heff_drop(v_fs_24161);
            return heff_tag_at_n(v_ru_24x1_24416_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24419}), v_st_24418});
          }
          case TAG_Right: {
            V v_x_24420 = heff_field(v_x11_24417, 0);
            heff_take_n(v_x11_24417, 1ULL, 1);
            V v_t_24421 = (g_list_2emap_24s513201124x806973253(v_fs_24161));
            V v_x_24422 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24420, v_t_24421));
            return heff_tag_at_n(v_ru_24x1_24416_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24422}), v_st_24418});
          }
          default: return heff_nomatch(v_x11_24417);
          }
        }
        default: return heff_nomatch(v_x1_24416);
        }
      }
      case TAG_BPat: {
        V v_m_24424 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24160}));
        V v_x1_24425 = heff_tr(heff_call(v_m_24424, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24425)) {
        case TAG_MkPair: {
          V v_x11_24426 = heff_field(v_x1_24425, 0);
          V v_st_24427 = heff_field(v_x1_24425, 1);
          V v_ru_24x1_24425_24MkPair = heff_take_reuse_n(v_x1_24425, 3ULL, 2);
          switch (heff_tag_of(v_x11_24426)) {
          case TAG_Left: {
            V v_e_24428 = heff_field(v_x11_24426, 0);
            heff_take_n(v_x11_24426, 1ULL, 1);
            heff_drop(v_fs_24161);
            return heff_tag_at_n(v_ru_24x1_24425_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24428}), v_st_24427});
          }
          case TAG_Right: {
            V v_x_24429 = heff_field(v_x11_24426, 0);
            heff_take_n(v_x11_24426, 1ULL, 1);
            V v_t_24430 = (g_list_2emap_24s513201124x806973253(v_fs_24161));
            V v_x_24431 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24429, v_t_24430));
            return heff_tag_at_n(v_ru_24x1_24425_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24431}), v_st_24427});
          }
          default: return heff_nomatch(v_x11_24426);
          }
        }
        default: return heff_nomatch(v_x1_24425);
        }
      }
      case TAG_Lam: {
        V v_m_24436 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24160}));
        V v_x1_24437 = heff_tr(heff_call(v_m_24436, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24437)) {
        case TAG_MkPair: {
          V v_x11_24438 = heff_field(v_x1_24437, 0);
          V v_st_24439 = heff_field(v_x1_24437, 1);
          V v_ru_24x1_24437_24MkPair = heff_take_reuse_n(v_x1_24437, 3ULL, 2);
          switch (heff_tag_of(v_x11_24438)) {
          case TAG_Left: {
            V v_e_24440 = heff_field(v_x11_24438, 0);
            heff_take_n(v_x11_24438, 1ULL, 1);
            heff_drop(v_fs_24161);
            return heff_tag_at_n(v_ru_24x1_24437_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24440}), v_st_24439});
          }
          case TAG_Right: {
            V v_x_24441 = heff_field(v_x11_24438, 0);
            heff_take_n(v_x11_24438, 1ULL, 1);
            V v_t_24442 = (g_list_2emap_24s513201124x806973253(v_fs_24161));
            V v_x_24443 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24441, v_t_24442));
            return heff_tag_at_n(v_ru_24x1_24437_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24443}), v_st_24439});
          }
          default: return heff_nomatch(v_x11_24438);
          }
        }
        default: return heff_nomatch(v_x1_24437);
        }
      }
      case TAG_Case: {
        V v_m_24448 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24160}));
        V v_x1_24449 = heff_tr(heff_call(v_m_24448, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24449)) {
        case TAG_MkPair: {
          V v_x11_24450 = heff_field(v_x1_24449, 0);
          V v_st_24451 = heff_field(v_x1_24449, 1);
          V v_ru_24x1_24449_24MkPair = heff_take_reuse_n(v_x1_24449, 3ULL, 2);
          switch (heff_tag_of(v_x11_24450)) {
          case TAG_Left: {
            V v_e_24452 = heff_field(v_x11_24450, 0);
            heff_take_n(v_x11_24450, 1ULL, 1);
            heff_drop(v_fs_24161);
            return heff_tag_at_n(v_ru_24x1_24449_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24452}), v_st_24451});
          }
          case TAG_Right: {
            V v_x_24453 = heff_field(v_x11_24450, 0);
            heff_take_n(v_x11_24450, 1ULL, 1);
            V v_t_24454 = (g_list_2emap_24s513201124x806973253(v_fs_24161));
            V v_x_24455 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24453, v_t_24454));
            return heff_tag_at_n(v_ru_24x1_24449_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24455}), v_st_24451});
          }
          default: return heff_nomatch(v_x11_24450);
          }
        }
        default: return heff_nomatch(v_x1_24449);
        }
      }
      case TAG_EAlt: {
        V v_m_24459 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24160}));
        V v_x1_24460 = heff_tr(heff_call(v_m_24459, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24460)) {
        case TAG_MkPair: {
          V v_x11_24461 = heff_field(v_x1_24460, 0);
          V v_st_24462 = heff_field(v_x1_24460, 1);
          V v_ru_24x1_24460_24MkPair = heff_take_reuse_n(v_x1_24460, 3ULL, 2);
          switch (heff_tag_of(v_x11_24461)) {
          case TAG_Left: {
            V v_e_24463 = heff_field(v_x11_24461, 0);
            heff_take_n(v_x11_24461, 1ULL, 1);
            heff_drop(v_fs_24161);
            return heff_tag_at_n(v_ru_24x1_24460_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24463}), v_st_24462});
          }
          case TAG_Right: {
            V v_x_24464 = heff_field(v_x11_24461, 0);
            heff_take_n(v_x11_24461, 1ULL, 1);
            V v_t_24465 = (g_list_2emap_24s513201124x806973253(v_fs_24161));
            V v_x_24466 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24464, v_t_24465));
            return heff_tag_at_n(v_ru_24x1_24460_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24466}), v_st_24462});
          }
          default: return heff_nomatch(v_x11_24461);
          }
        }
        default: return heff_nomatch(v_x1_24460);
        }
      }
      case TAG_If: {
        V v_m_24473 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24160}));
        V v_x1_24474 = heff_tr(heff_call(v_m_24473, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24474)) {
        case TAG_MkPair: {
          V v_x11_24475 = heff_field(v_x1_24474, 0);
          V v_st_24476 = heff_field(v_x1_24474, 1);
          V v_ru_24x1_24474_24MkPair = heff_take_reuse_n(v_x1_24474, 3ULL, 2);
          switch (heff_tag_of(v_x11_24475)) {
          case TAG_Left: {
            V v_e_24477 = heff_field(v_x11_24475, 0);
            heff_take_n(v_x11_24475, 1ULL, 1);
            heff_drop(v_fs_24161);
            return heff_tag_at_n(v_ru_24x1_24474_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24477}), v_st_24476});
          }
          case TAG_Right: {
            V v_x_24478 = heff_field(v_x11_24475, 0);
            heff_take_n(v_x11_24475, 1ULL, 1);
            V v_t_24479 = (g_list_2emap_24s513201124x806973253(v_fs_24161));
            V v_x_24480 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24478, v_t_24479));
            return heff_tag_at_n(v_ru_24x1_24474_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24480}), v_st_24476});
          }
          default: return heff_nomatch(v_x11_24475);
          }
        }
        default: return heff_nomatch(v_x1_24474);
        }
      }
      case TAG_Do: {
        V v_m_24483 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24160}));
        V v_x1_24484 = heff_tr(heff_call(v_m_24483, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24484)) {
        case TAG_MkPair: {
          V v_x11_24485 = heff_field(v_x1_24484, 0);
          V v_st_24486 = heff_field(v_x1_24484, 1);
          V v_ru_24x1_24484_24MkPair = heff_take_reuse_n(v_x1_24484, 3ULL, 2);
          switch (heff_tag_of(v_x11_24485)) {
          case TAG_Left: {
            V v_e_24487 = heff_field(v_x11_24485, 0);
            heff_take_n(v_x11_24485, 1ULL, 1);
            heff_drop(v_fs_24161);
            return heff_tag_at_n(v_ru_24x1_24484_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24487}), v_st_24486});
          }
          case TAG_Right: {
            V v_x_24488 = heff_field(v_x11_24485, 0);
            heff_take_n(v_x11_24485, 1ULL, 1);
            V v_t_24489 = (g_list_2emap_24s513201124x806973253(v_fs_24161));
            V v_x_24490 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24488, v_t_24489));
            return heff_tag_at_n(v_ru_24x1_24484_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24490}), v_st_24486});
          }
          default: return heff_nomatch(v_x11_24485);
          }
        }
        default: return heff_nomatch(v_x1_24484);
        }
      }
      case TAG_ESBind: {
        V v_m_24494 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24160}));
        V v_x1_24495 = heff_tr(heff_call(v_m_24494, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24495)) {
        case TAG_MkPair: {
          V v_x11_24496 = heff_field(v_x1_24495, 0);
          V v_st_24497 = heff_field(v_x1_24495, 1);
          V v_ru_24x1_24495_24MkPair = heff_take_reuse_n(v_x1_24495, 3ULL, 2);
          switch (heff_tag_of(v_x11_24496)) {
          case TAG_Left: {
            V v_e_24498 = heff_field(v_x11_24496, 0);
            heff_take_n(v_x11_24496, 1ULL, 1);
            heff_drop(v_fs_24161);
            return heff_tag_at_n(v_ru_24x1_24495_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24498}), v_st_24497});
          }
          case TAG_Right: {
            V v_x_24499 = heff_field(v_x11_24496, 0);
            heff_take_n(v_x11_24496, 1ULL, 1);
            V v_t_24500 = (g_list_2emap_24s513201124x806973253(v_fs_24161));
            V v_x_24501 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24499, v_t_24500));
            return heff_tag_at_n(v_ru_24x1_24495_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24501}), v_st_24497});
          }
          default: return heff_nomatch(v_x11_24496);
          }
        }
        default: return heff_nomatch(v_x1_24495);
        }
      }
      case TAG_ELet: {
        V v_m_24508 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24160}));
        V v_x1_24509 = heff_tr(heff_call(v_m_24508, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24509)) {
        case TAG_MkPair: {
          V v_x11_24510 = heff_field(v_x1_24509, 0);
          V v_st_24511 = heff_field(v_x1_24509, 1);
          V v_ru_24x1_24509_24MkPair = heff_take_reuse_n(v_x1_24509, 3ULL, 2);
          switch (heff_tag_of(v_x11_24510)) {
          case TAG_Left: {
            V v_e_24512 = heff_field(v_x11_24510, 0);
            heff_take_n(v_x11_24510, 1ULL, 1);
            heff_drop(v_fs_24161);
            return heff_tag_at_n(v_ru_24x1_24509_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24512}), v_st_24511});
          }
          case TAG_Right: {
            V v_x_24513 = heff_field(v_x11_24510, 0);
            heff_take_n(v_x11_24510, 1ULL, 1);
            V v_t_24514 = (g_list_2emap_24s513201124x806973253(v_fs_24161));
            V v_x_24515 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24513, v_t_24514));
            return heff_tag_at_n(v_ru_24x1_24509_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24515}), v_st_24511});
          }
          default: return heff_nomatch(v_x11_24510);
          }
        }
        default: return heff_nomatch(v_x1_24509);
        }
      }
      case TAG_ELetElse: {
        V v_m_24523 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24160}));
        V v_x1_24524 = heff_tr(heff_call(v_m_24523, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24524)) {
        case TAG_MkPair: {
          V v_x11_24525 = heff_field(v_x1_24524, 0);
          V v_st_24526 = heff_field(v_x1_24524, 1);
          V v_ru_24x1_24524_24MkPair = heff_take_reuse_n(v_x1_24524, 3ULL, 2);
          switch (heff_tag_of(v_x11_24525)) {
          case TAG_Left: {
            V v_e_24527 = heff_field(v_x11_24525, 0);
            heff_take_n(v_x11_24525, 1ULL, 1);
            heff_drop(v_fs_24161);
            return heff_tag_at_n(v_ru_24x1_24524_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24527}), v_st_24526});
          }
          case TAG_Right: {
            V v_x_24528 = heff_field(v_x11_24525, 0);
            heff_take_n(v_x11_24525, 1ULL, 1);
            V v_t_24529 = (g_list_2emap_24s513201124x806973253(v_fs_24161));
            V v_x_24530 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24528, v_t_24529));
            return heff_tag_at_n(v_ru_24x1_24524_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24530}), v_st_24526});
          }
          default: return heff_nomatch(v_x11_24525);
          }
        }
        default: return heff_nomatch(v_x1_24524);
        }
      }
      case TAG_ELetMut: {
        V v_m_24537 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24160}));
        V v_x1_24538 = heff_tr(heff_call(v_m_24537, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24538)) {
        case TAG_MkPair: {
          V v_x11_24539 = heff_field(v_x1_24538, 0);
          V v_st_24540 = heff_field(v_x1_24538, 1);
          V v_ru_24x1_24538_24MkPair = heff_take_reuse_n(v_x1_24538, 3ULL, 2);
          switch (heff_tag_of(v_x11_24539)) {
          case TAG_Left: {
            V v_e_24541 = heff_field(v_x11_24539, 0);
            heff_take_n(v_x11_24539, 1ULL, 1);
            heff_drop(v_fs_24161);
            return heff_tag_at_n(v_ru_24x1_24538_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24541}), v_st_24540});
          }
          case TAG_Right: {
            V v_x_24542 = heff_field(v_x11_24539, 0);
            heff_take_n(v_x11_24539, 1ULL, 1);
            V v_t_24543 = (g_list_2emap_24s513201124x806973253(v_fs_24161));
            V v_x_24544 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24542, v_t_24543));
            return heff_tag_at_n(v_ru_24x1_24538_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24544}), v_st_24540});
          }
          default: return heff_nomatch(v_x11_24539);
          }
        }
        default: return heff_nomatch(v_x1_24538);
        }
      }
      case TAG_EAssign: {
        V v_m_24548 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24160}));
        V v_x1_24549 = heff_tr(heff_call(v_m_24548, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24549)) {
        case TAG_MkPair: {
          V v_x11_24550 = heff_field(v_x1_24549, 0);
          V v_st_24551 = heff_field(v_x1_24549, 1);
          V v_ru_24x1_24549_24MkPair = heff_take_reuse_n(v_x1_24549, 3ULL, 2);
          switch (heff_tag_of(v_x11_24550)) {
          case TAG_Left: {
            V v_e_24552 = heff_field(v_x11_24550, 0);
            heff_take_n(v_x11_24550, 1ULL, 1);
            heff_drop(v_fs_24161);
            return heff_tag_at_n(v_ru_24x1_24549_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24552}), v_st_24551});
          }
          case TAG_Right: {
            V v_x_24553 = heff_field(v_x11_24550, 0);
            heff_take_n(v_x11_24550, 1ULL, 1);
            V v_t_24554 = (g_list_2emap_24s513201124x806973253(v_fs_24161));
            V v_x_24555 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24553, v_t_24554));
            return heff_tag_at_n(v_ru_24x1_24549_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24555}), v_st_24551});
          }
          default: return heff_nomatch(v_x11_24550);
          }
        }
        default: return heff_nomatch(v_x1_24549);
        }
      }
      case TAG_EWhile: {
        V v_m_24560 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24160}));
        V v_x1_24561 = heff_tr(heff_call(v_m_24560, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24561)) {
        case TAG_MkPair: {
          V v_x11_24562 = heff_field(v_x1_24561, 0);
          V v_st_24563 = heff_field(v_x1_24561, 1);
          V v_ru_24x1_24561_24MkPair = heff_take_reuse_n(v_x1_24561, 3ULL, 2);
          switch (heff_tag_of(v_x11_24562)) {
          case TAG_Left: {
            V v_e_24564 = heff_field(v_x11_24562, 0);
            heff_take_n(v_x11_24562, 1ULL, 1);
            heff_drop(v_fs_24161);
            return heff_tag_at_n(v_ru_24x1_24561_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24564}), v_st_24563});
          }
          case TAG_Right: {
            V v_x_24565 = heff_field(v_x11_24562, 0);
            heff_take_n(v_x11_24562, 1ULL, 1);
            V v_t_24566 = (g_list_2emap_24s513201124x806973253(v_fs_24161));
            V v_x_24567 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24565, v_t_24566));
            return heff_tag_at_n(v_ru_24x1_24561_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24567}), v_st_24563});
          }
          default: return heff_nomatch(v_x11_24562);
          }
        }
        default: return heff_nomatch(v_x1_24561);
        }
      }
      case TAG_EFor: {
        V v_m_24574 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24160}));
        V v_x1_24575 = heff_tr(heff_call(v_m_24574, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24575)) {
        case TAG_MkPair: {
          V v_x11_24576 = heff_field(v_x1_24575, 0);
          V v_st_24577 = heff_field(v_x1_24575, 1);
          V v_ru_24x1_24575_24MkPair = heff_take_reuse_n(v_x1_24575, 3ULL, 2);
          switch (heff_tag_of(v_x11_24576)) {
          case TAG_Left: {
            V v_e_24578 = heff_field(v_x11_24576, 0);
            heff_take_n(v_x11_24576, 1ULL, 1);
            heff_drop(v_fs_24161);
            return heff_tag_at_n(v_ru_24x1_24575_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24578}), v_st_24577});
          }
          case TAG_Right: {
            V v_x_24579 = heff_field(v_x11_24576, 0);
            heff_take_n(v_x11_24576, 1ULL, 1);
            V v_t_24580 = (g_list_2emap_24s513201124x806973253(v_fs_24161));
            V v_x_24581 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24579, v_t_24580));
            return heff_tag_at_n(v_ru_24x1_24575_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24581}), v_st_24577});
          }
          default: return heff_nomatch(v_x11_24576);
          }
        }
        default: return heff_nomatch(v_x1_24575);
        }
      }
      case TAG_EJump: {
        V v_m_24583 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24160}));
        V v_x1_24584 = heff_tr(heff_call(v_m_24583, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24584)) {
        case TAG_MkPair: {
          V v_x11_24585 = heff_field(v_x1_24584, 0);
          V v_st_24586 = heff_field(v_x1_24584, 1);
          V v_ru_24x1_24584_24MkPair = heff_take_reuse_n(v_x1_24584, 3ULL, 2);
          switch (heff_tag_of(v_x11_24585)) {
          case TAG_Left: {
            V v_e_24587 = heff_field(v_x11_24585, 0);
            heff_take_n(v_x11_24585, 1ULL, 1);
            heff_drop(v_fs_24161);
            return heff_tag_at_n(v_ru_24x1_24584_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24587}), v_st_24586});
          }
          case TAG_Right: {
            V v_x_24588 = heff_field(v_x11_24585, 0);
            heff_take_n(v_x11_24585, 1ULL, 1);
            V v_t_24589 = (g_list_2emap_24s513201124x806973253(v_fs_24161));
            V v_x_24590 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24588, v_t_24589));
            return heff_tag_at_n(v_ru_24x1_24584_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24590}), v_st_24586});
          }
          default: return heff_nomatch(v_x11_24585);
          }
        }
        default: return heff_nomatch(v_x1_24584);
        }
      }
      case TAG_EReturn: {
        V v_m_24593 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24160}));
        V v_x1_24594 = heff_tr(heff_call(v_m_24593, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24594)) {
        case TAG_MkPair: {
          V v_x11_24595 = heff_field(v_x1_24594, 0);
          V v_st_24596 = heff_field(v_x1_24594, 1);
          V v_ru_24x1_24594_24MkPair = heff_take_reuse_n(v_x1_24594, 3ULL, 2);
          switch (heff_tag_of(v_x11_24595)) {
          case TAG_Left: {
            V v_e_24597 = heff_field(v_x11_24595, 0);
            heff_take_n(v_x11_24595, 1ULL, 1);
            heff_drop(v_fs_24161);
            return heff_tag_at_n(v_ru_24x1_24594_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24597}), v_st_24596});
          }
          case TAG_Right: {
            V v_x_24598 = heff_field(v_x11_24595, 0);
            heff_take_n(v_x11_24595, 1ULL, 1);
            V v_t_24599 = (g_list_2emap_24s513201124x806973253(v_fs_24161));
            V v_x_24600 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24598, v_t_24599));
            return heff_tag_at_n(v_ru_24x1_24594_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24600}), v_st_24596});
          }
          default: return heff_nomatch(v_x11_24595);
          }
        }
        default: return heff_nomatch(v_x1_24594);
        }
      }
      case TAG_ENest: {
        V v_m_24605 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24160}));
        V v_x1_24606 = heff_tr(heff_call(v_m_24605, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24606)) {
        case TAG_MkPair: {
          V v_x11_24607 = heff_field(v_x1_24606, 0);
          V v_st_24608 = heff_field(v_x1_24606, 1);
          V v_ru_24x1_24606_24MkPair = heff_take_reuse_n(v_x1_24606, 3ULL, 2);
          switch (heff_tag_of(v_x11_24607)) {
          case TAG_Left: {
            V v_e_24609 = heff_field(v_x11_24607, 0);
            heff_take_n(v_x11_24607, 1ULL, 1);
            heff_drop(v_fs_24161);
            return heff_tag_at_n(v_ru_24x1_24606_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24609}), v_st_24608});
          }
          case TAG_Right: {
            V v_x_24610 = heff_field(v_x11_24607, 0);
            heff_take_n(v_x11_24607, 1ULL, 1);
            V v_t_24611 = (g_list_2emap_24s513201124x806973253(v_fs_24161));
            V v_x_24612 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24610, v_t_24611));
            return heff_tag_at_n(v_ru_24x1_24606_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24612}), v_st_24608});
          }
          default: return heff_nomatch(v_x11_24607);
          }
        }
        default: return heff_nomatch(v_x1_24606);
        }
      }
      case TAG_EArrow: {
        V v_m_24615 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24160}));
        V v_x1_24616 = heff_tr(heff_call(v_m_24615, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24616)) {
        case TAG_MkPair: {
          V v_x11_24617 = heff_field(v_x1_24616, 0);
          V v_st_24618 = heff_field(v_x1_24616, 1);
          V v_ru_24x1_24616_24MkPair = heff_take_reuse_n(v_x1_24616, 3ULL, 2);
          switch (heff_tag_of(v_x11_24617)) {
          case TAG_Left: {
            V v_e_24619 = heff_field(v_x11_24617, 0);
            heff_take_n(v_x11_24617, 1ULL, 1);
            heff_drop(v_fs_24161);
            return heff_tag_at_n(v_ru_24x1_24616_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24619}), v_st_24618});
          }
          case TAG_Right: {
            V v_x_24620 = heff_field(v_x11_24617, 0);
            heff_take_n(v_x11_24617, 1ULL, 1);
            V v_t_24621 = (g_list_2emap_24s513201124x806973253(v_fs_24161));
            V v_x_24622 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24620, v_t_24621));
            return heff_tag_at_n(v_ru_24x1_24616_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24622}), v_st_24618});
          }
          default: return heff_nomatch(v_x11_24617);
          }
        }
        default: return heff_nomatch(v_x1_24616);
        }
      }
      case TAG_IfThen: {
        V v_m_24627 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24160}));
        V v_x1_24628 = heff_tr(heff_call(v_m_24627, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24628)) {
        case TAG_MkPair: {
          V v_x11_24629 = heff_field(v_x1_24628, 0);
          V v_st_24630 = heff_field(v_x1_24628, 1);
          V v_ru_24x1_24628_24MkPair = heff_take_reuse_n(v_x1_24628, 3ULL, 2);
          switch (heff_tag_of(v_x11_24629)) {
          case TAG_Left: {
            V v_e_24631 = heff_field(v_x11_24629, 0);
            heff_take_n(v_x11_24629, 1ULL, 1);
            heff_drop(v_fs_24161);
            return heff_tag_at_n(v_ru_24x1_24628_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24631}), v_st_24630});
          }
          case TAG_Right: {
            V v_x_24632 = heff_field(v_x11_24629, 0);
            heff_take_n(v_x11_24629, 1ULL, 1);
            V v_t_24633 = (g_list_2emap_24s513201124x806973253(v_fs_24161));
            V v_x_24634 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24632, v_t_24633));
            return heff_tag_at_n(v_ru_24x1_24628_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24634}), v_st_24630});
          }
          default: return heff_nomatch(v_x11_24629);
          }
        }
        default: return heff_nomatch(v_x1_24628);
        }
      }
      case TAG_ETry: {
        V v_m_24639 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24160}));
        V v_x1_24640 = heff_tr(heff_call(v_m_24639, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24640)) {
        case TAG_MkPair: {
          V v_x11_24641 = heff_field(v_x1_24640, 0);
          V v_st_24642 = heff_field(v_x1_24640, 1);
          V v_ru_24x1_24640_24MkPair = heff_take_reuse_n(v_x1_24640, 3ULL, 2);
          switch (heff_tag_of(v_x11_24641)) {
          case TAG_Left: {
            V v_e_24643 = heff_field(v_x11_24641, 0);
            heff_take_n(v_x11_24641, 1ULL, 1);
            heff_drop(v_fs_24161);
            return heff_tag_at_n(v_ru_24x1_24640_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24643}), v_st_24642});
          }
          case TAG_Right: {
            V v_x_24644 = heff_field(v_x11_24641, 0);
            heff_take_n(v_x11_24641, 1ULL, 1);
            V v_t_24645 = (g_list_2emap_24s513201124x806973253(v_fs_24161));
            V v_x_24646 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24644, v_t_24645));
            return heff_tag_at_n(v_ru_24x1_24640_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24646}), v_st_24642});
          }
          default: return heff_nomatch(v_x11_24641);
          }
        }
        default: return heff_nomatch(v_x1_24640);
        }
      }
      case TAG_ECatch: {
        V v_m_24651 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24160}));
        V v_x1_24652 = heff_tr(heff_call(v_m_24651, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24652)) {
        case TAG_MkPair: {
          V v_x11_24653 = heff_field(v_x1_24652, 0);
          V v_st_24654 = heff_field(v_x1_24652, 1);
          V v_ru_24x1_24652_24MkPair = heff_take_reuse_n(v_x1_24652, 3ULL, 2);
          switch (heff_tag_of(v_x11_24653)) {
          case TAG_Left: {
            V v_e_24655 = heff_field(v_x11_24653, 0);
            heff_take_n(v_x11_24653, 1ULL, 1);
            heff_drop(v_fs_24161);
            return heff_tag_at_n(v_ru_24x1_24652_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24655}), v_st_24654});
          }
          case TAG_Right: {
            V v_x_24656 = heff_field(v_x11_24653, 0);
            heff_take_n(v_x11_24653, 1ULL, 1);
            V v_t_24657 = (g_list_2emap_24s513201124x806973253(v_fs_24161));
            V v_x_24658 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24656, v_t_24657));
            return heff_tag_at_n(v_ru_24x1_24652_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24658}), v_st_24654});
          }
          default: return heff_nomatch(v_x11_24653);
          }
        }
        default: return heff_nomatch(v_x1_24652);
        }
      }
      case TAG_EWith: {
        V v_m_24665 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_it1_24160}));
        V v_x1_24666 = heff_tr(heff_call(v_m_24665, 1, (V[]){v_z_242}));
        switch (heff_tag_of(v_x1_24666)) {
        case TAG_MkPair: {
          V v_x11_24667 = heff_field(v_x1_24666, 0);
          V v_st_24668 = heff_field(v_x1_24666, 1);
          V v_ru_24x1_24666_24MkPair = heff_take_reuse_n(v_x1_24666, 3ULL, 2);
          switch (heff_tag_of(v_x11_24667)) {
          case TAG_Left: {
            V v_e_24669 = heff_field(v_x11_24667, 0);
            heff_take_n(v_x11_24667, 1ULL, 1);
            heff_drop(v_fs_24161);
            return heff_tag_at_n(v_ru_24x1_24666_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24669}), v_st_24668});
          }
          case TAG_Right: {
            V v_x_24670 = heff_field(v_x11_24667, 0);
            heff_take_n(v_x11_24667, 1ULL, 1);
            V v_t_24671 = (g_list_2emap_24s513201124x806973253(v_fs_24161));
            V v_x_24672 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24670, v_t_24671));
            return heff_tag_at_n(v_ru_24x1_24666_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24672}), v_st_24668});
          }
          default: return heff_nomatch(v_x11_24667);
          }
        }
        default: return heff_nomatch(v_x1_24666);
        }
      }
      default: return heff_nomatch(v_it1_24160);
      }
    }
  }
  case TAG_ENeg: {
    V v_m_24673 = heff_field(v_e0_241, 0);
    V v_e_24674 = heff_field(v_e0_241, 1);
    V v_ru_24e0_241_24ENeg = heff_take_reuse_n(v_e0_241, 3ULL, 2);
    V v_start_24675 = heff_take_field(v_m_24673, 3);
    V v_end_24676 = heff_get_n(v_m_24673, 4, 9);
    V v_m_24677 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_24674}));
    V v_x1_24678 = heff_tr(heff_call(v_m_24677, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x1_24678)) {
    case TAG_MkPair: {
      V v_x11_24679 = heff_field(v_x1_24678, 0);
      V v_st_24680 = heff_field(v_x1_24678, 1);
      V v_ru_24x1_24678_24MkPair = heff_take_reuse_n(v_x1_24678, 3ULL, 2);
      switch (heff_tag_of(v_x11_24679)) {
      case TAG_Left: {
        V v_e_24681 = heff_field(v_x11_24679, 0);
        heff_take_n(v_x11_24679, 1ULL, 1);
        heff_drop(v_start_24675);
        heff_drop(v_end_24676);
        heff_drop_cell(v_ru_24x1_24678_24MkPair, 2);
        return heff_tag_at_n(v_ru_24e0_241_24ENeg, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24681}), v_st_24680});
      }
      case TAG_Right: {
        V v_x_24682 = heff_field(v_x11_24679, 0);
        heff_take_n(v_x11_24679, 1ULL, 1);
        V v_t_24683 = heff_tag_at_n(v_ru_24e0_241_24ENeg, TAG_At, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2eexprL_str21)}), heff_rec_n(2, shape_start__end, (V[]){v_start_24675, v_end_24676})});
        V v_t_24684 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_24682, NTAG(TAG_Nil)});
        V v_x_24685 = (g_heff_2esyntax_2epresyntax_2eapp(v_t_24683, v_t_24684));
        return heff_tag_at_n(v_ru_24x1_24678_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24685}), v_st_24680});
      }
      default: return heff_nomatch(v_x11_24679);
      }
    }
    default: return heff_nomatch(v_x1_24678);
    }
  }
  case TAG_ETilde: {
    V v_m_24686 = heff_field(v_e0_241, 0);
    V v_e_24687 = heff_field(v_e0_241, 1);
    V v_ru_24e0_241_24ETilde = heff_take_reuse_n(v_e0_241, 3ULL, 2);
    V v_m_24688 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_e_24687)}));
    V v_x1_24689 = heff_tr(heff_call(v_m_24688, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x1_24689)) {
    case TAG_MkPair: {
      V v_x11_24690 = heff_field(v_x1_24689, 0);
      V v_st_24691 = heff_field(v_x1_24689, 1);
      V v_ru_24x1_24689_24MkPair = heff_take_reuse_n(v_x1_24689, 3ULL, 2);
      switch (heff_tag_of(v_x11_24690)) {
      case TAG_Left: {
        V v_e_24692 = heff_field(v_x11_24690, 0);
        heff_take_n(v_x11_24690, 1ULL, 1);
        heff_drop_rec(v_m_24686, 9);
        heff_drop(v_e_24687);
        heff_drop_cell(v_ru_24x1_24689_24MkPair, 2);
        return heff_tag_at_n(v_ru_24e0_241_24ETilde, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24692}), v_st_24691});
      }
      case TAG_Right: {
        V v_x_24693 = heff_field(v_x11_24690, 0);
        heff_take_n(v_x11_24690, 1ULL, 1);
        V v_t_24694 = (g_heff_2esyntax_2ecst_2elastE(v_e_24687));
        V v_e_24695 = heff_get_n(v_t_24694, 4, 9);
        V v_t_24696 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_m_24686, 3, 9), v_e_24695});
        V v_x_24697 = heff_tag_at_n(v_ru_24e0_241_24ETilde, TAG_At, 2, (V[]){heff_tag_n(TAG_ELazy, 1, (V[]){v_x_24693}), v_t_24696});
        return heff_tag_at_n(v_ru_24x1_24689_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24697}), v_st_24691});
      }
      default: return heff_nomatch(v_x11_24690);
      }
    }
    default: return heff_nomatch(v_x1_24689);
    }
  }
  case TAG_App: {
    V v_h_24698 = heff_field(v_e0_241, 0);
    V v_args_24699 = heff_field(v_e0_241, 1);
    V v_ru_24e0_241_24App = heff_take_reuse_n(v_e0_241, 3ULL, 2);
    V v_m_24700 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_h_24698}));
    V v_x1_24701 = heff_tr(heff_call(v_m_24700, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x1_24701)) {
    case TAG_MkPair: {
      V v_x11_24702 = heff_field(v_x1_24701, 0);
      V v_st_24703 = heff_field(v_x1_24701, 1);
      heff_take_n(v_x1_24701, 3ULL, 2);
      switch (heff_tag_of(v_x11_24702)) {
      case TAG_Left: {
        V v_e_24704 = heff_field(v_x11_24702, 0);
        heff_take_n(v_x11_24702, 1ULL, 1);
        heff_drop_rec(v_r_240, 3);
        heff_drop(v_args_24699);
        return heff_tag_at_n(v_ru_24e0_241_24App, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24704}), v_st_24703});
      }
      case TAG_Right: {
        V v_x_24705 = heff_field(v_x11_24702, 0);
        heff_take_n(v_x11_24702, 1ULL, 1);
        V v_m_24707 = (g_prelude_2etraverse_24s499544530x2060473942(heff_clo_n(g_heff_2esyntax_2esurface_2eexprL_lam4, 1, 1, (V[]){v_r_240}), v_args_24699));
        V v_x1_24708 = heff_tr(heff_call(v_m_24707, 1, (V[]){v_st_24703}));
        switch (heff_tag_of(v_x1_24708)) {
        case TAG_MkPair: {
          V v_x11_24709 = heff_field(v_x1_24708, 0);
          V v_st_24710 = heff_field(v_x1_24708, 1);
          heff_take_n(v_x1_24708, 3ULL, 2);
          switch (heff_tag_of(v_x11_24709)) {
          case TAG_Left: {
            V v_e_24711 = heff_field(v_x11_24709, 0);
            heff_take_n(v_x11_24709, 1ULL, 1);
            heff_drop(v_x_24705);
            return heff_tag_at_n(v_ru_24e0_241_24App, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24711}), v_st_24710});
          }
          case TAG_Right: {
            V v_x_24712 = heff_field(v_x11_24709, 0);
            heff_take_n(v_x11_24709, 1ULL, 1);
            V v_x_24713 = (g_heff_2esyntax_2epresyntax_2eapp(v_x_24705, v_x_24712));
            return heff_tag_at_n(v_ru_24e0_241_24App, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24713}), v_st_24710});
          }
          default: return heff_nomatch(v_x11_24709);
          }
        }
        default: return heff_nomatch(v_x1_24708);
        }
      }
      default: return heff_nomatch(v_x11_24702);
      }
    }
    default: return heff_nomatch(v_x1_24701);
    }
  }
  case TAG_Op: {
    V v_a_24714 = heff_field(v_e0_241, 0);
    V v_op_24715 = heff_field(v_e0_241, 1);
    V v_b_24716 = heff_field(v_e0_241, 2);
    heff_take_n(v_e0_241, 7ULL, 3);
    return (g_heff_2esyntax_2esurface_2eopL(v_r_240, v_a_24714, v_op_24715, v_b_24716, v_z_242));
  }
  case TAG_Ops: {
    V v_a_24717 = heff_field(v_e0_241, 0);
    V v_rest_24718 = heff_field(v_e0_241, 1);
    V v_ru_24e0_241_24Ops = heff_take_reuse_n(v_e0_241, 3ULL, 2);
    V v_m_24719 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_24717}));
    V v_x1_24720 = heff_tr(heff_call(v_m_24719, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x1_24720)) {
    case TAG_MkPair: {
      V v_x11_24721 = heff_field(v_x1_24720, 0);
      V v_st_24722 = heff_field(v_x1_24720, 1);
      heff_take_n(v_x1_24720, 3ULL, 2);
      switch (heff_tag_of(v_x11_24721)) {
      case TAG_Left: {
        V v_e_24723 = heff_field(v_x11_24721, 0);
        heff_take_n(v_x11_24721, 1ULL, 1);
        heff_drop_rec(v_r_240, 3);
        heff_drop(v_rest_24718);
        return heff_tag_at_n(v_ru_24e0_241_24Ops, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24723}), v_st_24722});
      }
      case TAG_Right: {
        V v_x_24724 = heff_field(v_x11_24721, 0);
        heff_take_n(v_x11_24721, 1ULL, 1);
        V v_m_24739 = (g_prelude_2etraverse_24s499544530x2060473942(heff_clo_n(g_heff_2esyntax_2esurface_2eexprL_lam5, 1, 1, (V[]){v_r_240}), v_rest_24718));
        V v_x1_24740 = heff_tr(heff_call(v_m_24739, 1, (V[]){v_st_24722}));
        switch (heff_tag_of(v_x1_24740)) {
        case TAG_MkPair: {
          V v_x11_24741 = heff_field(v_x1_24740, 0);
          V v_st_24742 = heff_field(v_x1_24740, 1);
          heff_take_n(v_x1_24740, 3ULL, 2);
          switch (heff_tag_of(v_x11_24741)) {
          case TAG_Left: {
            V v_e_24743 = heff_field(v_x11_24741, 0);
            heff_take_n(v_x11_24741, 1ULL, 1);
            heff_drop(v_x_24724);
            return heff_tag_at_n(v_ru_24e0_241_24Ops, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24743}), v_st_24742});
          }
          case TAG_Right: {
            V v_x_24744 = heff_field(v_x11_24741, 0);
            heff_take_n(v_x11_24741, 1ULL, 1);
            return (g_heff_2esyntax_2esurface_2eresolve_24s1832151779x1448561609_24tok2(v_ru_24e0_241_24Ops, v_x_24724, v_x_24744, v_st_24742));
          }
          default: return heff_nomatch(v_x11_24741);
          }
        }
        default: return heff_nomatch(v_x1_24740);
        }
      }
      default: return heff_nomatch(v_x11_24721);
      }
    }
    default: return heff_nomatch(v_x1_24720);
    }
  }
  case TAG_OpRhs: {
    heff_drop_rec(v_r_240, 3);
    V v_t_24747 = (g_heff_2esyntax_2ecst_2efirstE(v_e0_241));
    V v_start_24748 = heff_take_field(v_t_24747, 3);
    V v_end_24749 = heff_get_n(v_t_24747, 4, 9);
    V v_t_24750 = ({ V a_0 = v_e0_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e0_241, 2); r_; });
    V v_t_24751 = heff_strAppend(heff_get_n(v_t_24750, 1, 9), ((V)&g_heff_2esyntax_2esurface_2eexprL_str22));
    V v_msg_24752 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eexprL_str23), v_t_24751);
    V v_t_24753 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24752, heff_rec_n(2, shape_start__end, (V[]){v_start_24748, v_end_24749}), NTAG(TAG_Nothing)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24753}), v_z_242});
  }
  case TAG_Ann: {
    V v_e_24754 = heff_field(v_e0_241, 0);
    V v_ty_24756 = heff_field(v_e0_241, 2);
    heff_take_n(v_e0_241, 5ULL, 3);
    V v_m_24757 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e_24754}));
    V v_x1_24758 = heff_tr(heff_call(v_m_24757, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x1_24758)) {
    case TAG_MkPair: {
      V v_x11_24759 = heff_field(v_x1_24758, 0);
      V v_st_24760 = heff_field(v_x1_24758, 1);
      V v_ru_24x1_24758_24MkPair = heff_take_reuse_n(v_x1_24758, 3ULL, 2);
      switch (heff_tag_of(v_x11_24759)) {
      case TAG_Left: {
        V v_e_24761 = heff_field(v_x11_24759, 0);
        heff_take_n(v_x11_24759, 1ULL, 1);
        heff_drop_rec(v_r_240, 3);
        heff_drop(v_ty_24756);
        return heff_tag_at_n(v_ru_24x1_24758_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24761}), v_st_24760});
      }
      case TAG_Right: {
        V v_x_24762 = heff_field(v_x11_24759, 0);
        heff_take_n(v_x11_24759, 1ULL, 1);
        V v_m_24763 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_ty_24756}));
        V v_x1_24764 = heff_tr(heff_call(v_m_24763, 1, (V[]){v_st_24760}));
        switch (heff_tag_of(v_x1_24764)) {
        case TAG_MkPair: {
          V v_x11_24765 = heff_field(v_x1_24764, 0);
          V v_st_24766 = heff_field(v_x1_24764, 1);
          V v_ru_24x1_24764_24MkPair = heff_take_reuse_n(v_x1_24764, 3ULL, 2);
          switch (heff_tag_of(v_x11_24765)) {
          case TAG_Left: {
            V v_e_24767 = heff_field(v_x11_24765, 0);
            heff_take_n(v_x11_24765, 1ULL, 1);
            heff_drop(v_x_24762);
            heff_drop_cell(v_ru_24x1_24764_24MkPair, 2);
            return heff_tag_at_n(v_ru_24x1_24758_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24767}), v_st_24766});
          }
          case TAG_Right: {
            V v_x_24768 = heff_field(v_x11_24765, 0);
            heff_take_n(v_x11_24765, 1ULL, 1);
            V v_t_24771;
            switch (heff_tag_of(v_x_24762)) {
            case TAG_At: {
              V v_s_24770 = heff_dup(heff_field(v_x_24762, 1));
              v_t_24771 = v_s_24770;
              break;
            }
            default: heff_nomatch(v_x_24762);
            }
            V v_t_24774;
            switch (heff_tag_of(v_x_24768)) {
            case TAG_At: {
              V v_s_24773 = heff_dup(heff_field(v_x_24768, 1));
              v_t_24774 = v_s_24773;
              break;
            }
            default: heff_nomatch(v_x_24768);
            }
            V v_t_24775 = ({ V rv_1 = heff_get_n(v_t_24774, 1, 2); V rr_ = heff_rec_reuse_nf(v_t_24771, 1ULL, 2, shape_start__end, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
            V v_t_24776 = heff_tag_at_n(v_ru_24x1_24764_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_EAnn, 2, (V[]){v_x_24762, v_x_24768}), v_t_24775});
            return heff_tag_at_n(v_ru_24x1_24758_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_24776}), v_st_24766});
          }
          default: return heff_nomatch(v_x11_24765);
          }
        }
        default: return heff_nomatch(v_x1_24764);
        }
      }
      default: return heff_nomatch(v_x11_24759);
      }
    }
    default: return heff_nomatch(v_x1_24758);
    }
  }
  case TAG_BVar: {
    heff_drop_rec(v_r_240, 3);
    V v_t_24778 = (g_heff_2esyntax_2ecst_2efirstE(v_e0_241));
    V v_start_24779 = heff_take_field(v_t_24778, 3);
    V v_end_24780 = heff_get_n(v_t_24778, 4, 9);
    V v_t_24781 = ({ V a_0 = v_e0_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e0_241, 1); r_; });
    V v_t_24782 = heff_strAppend(heff_get_n(v_t_24781, 1, 9), ((V)&g_heff_2esyntax_2esurface_2eexprL_str24));
    V v_msg_24783 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eexprL_str25), v_t_24782);
    V v_t_24784 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24783, heff_rec_n(2, shape_start__end, (V[]){v_start_24779, v_end_24780}), NTAG(TAG_Nothing)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24784}), v_z_242});
  }
  case TAG_BImp: {
    heff_drop_rec(v_r_240, 3);
    V v_t_24788 = (g_heff_2esyntax_2ecst_2efirstE(v_e0_241));
    V v_start_24789 = heff_take_field(v_t_24788, 3);
    V v_end_24790 = heff_get_n(v_t_24788, 4, 9);
    V v_t_24791 = ({ V a_0 = v_e0_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e0_241, 3); r_; });
    V v_t_24792 = heff_strAppend(heff_get_n(v_t_24791, 1, 9), ((V)&g_heff_2esyntax_2esurface_2eexprL_str26));
    V v_msg_24793 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eexprL_str27), v_t_24792);
    V v_t_24794 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24793, heff_rec_n(2, shape_start__end, (V[]){v_start_24789, v_end_24790}), NTAG(TAG_Nothing)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24794}), v_z_242});
  }
  case TAG_BAnn: {
    heff_drop_rec(v_r_240, 3);
    V v_t_24800 = (g_heff_2esyntax_2ecst_2efirstE(v_e0_241));
    V v_start_24801 = heff_take_field(v_t_24800, 3);
    V v_end_24802 = heff_get_n(v_t_24800, 4, 9);
    V v_t_24803 = ({ V a_0 = v_e0_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e0_241, 5); r_; });
    V v_t_24804 = heff_strAppend(heff_get_n(v_t_24803, 1, 9), ((V)&g_heff_2esyntax_2esurface_2eexprL_str28));
    V v_msg_24805 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eexprL_str29), v_t_24804);
    V v_t_24806 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24805, heff_rec_n(2, shape_start__end, (V[]){v_start_24801, v_end_24802}), NTAG(TAG_Nothing)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24806}), v_z_242});
  }
  case TAG_BPat: {
    heff_drop_rec(v_r_240, 3);
    V v_t_24808 = (g_heff_2esyntax_2ecst_2efirstE(v_e0_241));
    V v_start_24809 = heff_take_field(v_t_24808, 3);
    V v_end_24810 = heff_get_n(v_t_24808, 4, 9);
    V v_t_24811 = ({ V a_0 = v_e0_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e0_241, 1); r_; });
    V v_t_24812 = heff_strAppend(heff_get_n(v_t_24811, 1, 9), ((V)&g_heff_2esyntax_2esurface_2eexprL_str30));
    V v_msg_24813 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eexprL_str31), v_t_24812);
    V v_t_24814 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24813, heff_rec_n(2, shape_start__end, (V[]){v_start_24809, v_end_24810}), NTAG(TAG_Nothing)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24814}), v_z_242});
  }
  case TAG_Lam: {
    V v_binders_24816 = heff_field(v_e0_241, 1);
    V v_body_24818 = heff_field(v_e0_241, 3);
    heff_take_n(v_e0_241, 10ULL, 4);
    return (g_heff_2esyntax_2esurface_2elambdaL(v_r_240, v_binders_24816, v_body_24818, v_z_242));
  }
  case TAG_Case: {
    V v_kw_24819 = heff_dup(heff_field(v_e0_241, 0));
    V v_scrut_24820 = heff_dup(heff_field(v_e0_241, 1));
    V v_alts_24822 = heff_dup(heff_field(v_e0_241, 3));
    V v_m_24823 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_scrut_24820}));
    V v_x1_24824 = heff_tr(heff_call(v_m_24823, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x1_24824)) {
    case TAG_MkPair: {
      V v_x11_24825 = heff_field(v_x1_24824, 0);
      V v_st_24826 = heff_field(v_x1_24824, 1);
      V v_ru_24x1_24824_24MkPair = heff_take_reuse_n(v_x1_24824, 3ULL, 2);
      switch (heff_tag_of(v_x11_24825)) {
      case TAG_Left: {
        V v_e_24827 = heff_field(v_x11_24825, 0);
        heff_take_n(v_x11_24825, 1ULL, 1);
        heff_drop_rec(v_r_240, 3);
        heff_drop_tag(v_e0_241, 4);
        heff_drop_rec(v_kw_24819, 9);
        heff_drop(v_alts_24822);
        return heff_tag_at_n(v_ru_24x1_24824_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24827}), v_st_24826});
      }
      case TAG_Right: {
        V v_x_24828 = heff_field(v_x11_24825, 0);
        heff_take_n(v_x11_24825, 1ULL, 1);
        HeffT2 v_t_24830 = (g_heff_2esyntax_2esurface_2eblock_24cpr(heff_clo_n(g_heff_2esyntax_2esurface_2eexprL_lam7, 1, 1, (V[]){v_r_240}), v_alts_24822, v_st_24826));
        {
          V v_field_24831 = v_t_24830.f[0];
          V v_field_24832 = v_t_24830.f[1];
          V v_x11_24833 = v_field_24831;
          V v_st_24834 = v_field_24832;
          switch (heff_tag_of(v_x11_24833)) {
          case TAG_Left: {
            V v_e_24835 = heff_field(v_x11_24833, 0);
            heff_take_n(v_x11_24833, 1ULL, 1);
            heff_drop_tag(v_e0_241, 4);
            heff_drop_rec(v_kw_24819, 9);
            heff_drop(v_x_24828);
            return heff_tag_at_n(v_ru_24x1_24824_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24835}), v_st_24834});
          }
          case TAG_Right: {
            V v_x_24836 = heff_field(v_x11_24833, 0);
            heff_take_n(v_x11_24833, 1ULL, 1);
            V v_t_24837 = (g_heff_2esyntax_2ecst_2elastE(v_e0_241));
            V v_e_24838 = heff_get_n(v_t_24837, 4, 9);
            V v_t_24839 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_24819, 3, 9), v_e_24838});
            V v_x_24840 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_x_24828, v_x_24836}), v_t_24839});
            return heff_tag_at_n(v_ru_24x1_24824_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24840}), v_st_24834});
          }
          default: return heff_nomatch(v_x11_24833);
          }
        }
      }
      default: return heff_nomatch(v_x11_24825);
      }
    }
    default: return heff_nomatch(v_x1_24824);
    }
  }
  case TAG_EAlt: {
    heff_drop_rec(v_r_240, 3);
    V v_t_24844 = (g_heff_2esyntax_2ecst_2efirstE(v_e0_241));
    V v_start_24845 = heff_take_field(v_t_24844, 3);
    V v_end_24846 = heff_get_n(v_t_24844, 4, 9);
    V v_t_24847 = ({ V a_0 = v_e0_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e0_241, 3); r_; });
    V v_t_24848 = heff_strAppend(heff_get_n(v_t_24847, 1, 9), ((V)&g_heff_2esyntax_2esurface_2eexprL_str32));
    V v_msg_24849 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eexprL_str33), v_t_24848);
    V v_t_24850 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24849, heff_rec_n(2, shape_start__end, (V[]){v_start_24845, v_end_24846}), NTAG(TAG_Nothing)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24850}), v_z_242});
  }
  case TAG_If: {
    V v_kw_24851 = heff_field(v_e0_241, 0);
    V v_c_24852 = heff_field(v_e0_241, 1);
    V v_a_24854 = heff_field(v_e0_241, 3);
    V v_b_24856 = heff_field(v_e0_241, 5);
    heff_take_n(v_e0_241, 43ULL, 6);
    V v_m_24857 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_c_24852}));
    V v_x1_24858 = heff_tr(heff_call(v_m_24857, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x1_24858)) {
    case TAG_MkPair: {
      V v_x11_24859 = heff_field(v_x1_24858, 0);
      V v_st_24860 = heff_field(v_x1_24858, 1);
      V v_ru_24x1_24858_24MkPair = heff_take_reuse_n(v_x1_24858, 3ULL, 2);
      switch (heff_tag_of(v_x11_24859)) {
      case TAG_Left: {
        V v_e_24861 = heff_field(v_x11_24859, 0);
        heff_take_n(v_x11_24859, 1ULL, 1);
        heff_drop_rec(v_r_240, 3);
        heff_drop_rec(v_kw_24851, 9);
        heff_drop(v_a_24854);
        heff_drop(v_b_24856);
        return heff_tag_at_n(v_ru_24x1_24858_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24861}), v_st_24860});
      }
      case TAG_Right: {
        V v_x_24862 = heff_field(v_x11_24859, 0);
        heff_take_n(v_x11_24859, 1ULL, 1);
        V v_m_24863 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_a_24854}));
        V v_x1_24864 = heff_tr(heff_call(v_m_24863, 1, (V[]){v_st_24860}));
        switch (heff_tag_of(v_x1_24864)) {
        case TAG_MkPair: {
          V v_x11_24865 = heff_field(v_x1_24864, 0);
          V v_st_24866 = heff_field(v_x1_24864, 1);
          heff_take_n(v_x1_24864, 3ULL, 2);
          switch (heff_tag_of(v_x11_24865)) {
          case TAG_Left: {
            V v_e_24867 = heff_field(v_x11_24865, 0);
            heff_take_n(v_x11_24865, 1ULL, 1);
            heff_drop_rec(v_r_240, 3);
            heff_drop_rec(v_kw_24851, 9);
            heff_drop(v_b_24856);
            heff_drop(v_x_24862);
            return heff_tag_at_n(v_ru_24x1_24858_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24867}), v_st_24866});
          }
          case TAG_Right: {
            V v_x_24868 = heff_field(v_x11_24865, 0);
            heff_take_n(v_x11_24865, 1ULL, 1);
            V v_m_24869 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_b_24856)}));
            V v_x1_24870 = heff_tr(heff_call(v_m_24869, 1, (V[]){v_st_24866}));
            switch (heff_tag_of(v_x1_24870)) {
            case TAG_MkPair: {
              V v_x11_24871 = heff_field(v_x1_24870, 0);
              V v_st_24872 = heff_field(v_x1_24870, 1);
              heff_take_n(v_x1_24870, 3ULL, 2);
              switch (heff_tag_of(v_x11_24871)) {
              case TAG_Left: {
                V v_e_24873 = heff_field(v_x11_24871, 0);
                heff_take_n(v_x11_24871, 1ULL, 1);
                heff_drop_rec(v_kw_24851, 9);
                heff_drop(v_b_24856);
                heff_drop(v_x_24862);
                heff_drop(v_x_24868);
                return heff_tag_at_n(v_ru_24x1_24858_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24873}), v_st_24872});
              }
              case TAG_Right: {
                V v_x_24874 = heff_field(v_x11_24871, 0);
                heff_take_n(v_x11_24871, 1ULL, 1);
                V v_t_24875 = (g_heff_2esyntax_2ecst_2elastE(v_b_24856));
                V v_e_24876 = heff_get_n(v_t_24875, 4, 9);
                V v_t_24877 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_24851, 3, 9), v_e_24876});
                V v_x_24878 = (g_heff_2esyntax_2esurface_2eifE(v_t_24877, v_x_24862, v_x_24868, v_x_24874));
                return heff_tag_at_n(v_ru_24x1_24858_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24878}), v_st_24872});
              }
              default: return heff_nomatch(v_x11_24871);
              }
            }
            default: return heff_nomatch(v_x1_24870);
            }
          }
          default: return heff_nomatch(v_x11_24865);
          }
        }
        default: return heff_nomatch(v_x1_24864);
        }
      }
      default: return heff_nomatch(v_x11_24859);
      }
    }
    default: return heff_nomatch(v_x1_24858);
    }
  }
  case TAG_Do: {
    V v_kw_24879 = heff_dup(heff_field(v_e0_241, 0));
    V v_stmts_24880 = heff_dup(heff_field(v_e0_241, 1));
    HeffT2 v_t_24882 = (g_heff_2esyntax_2esurface_2eblock_24cpr(heff_clo_n(g_heff_2esyntax_2esurface_2eexprL_lam8, 1, 1, (V[]){v_r_240}), v_stmts_24880, v_z_242));
    {
      V v_field_24883 = v_t_24882.f[0];
      V v_field_24884 = v_t_24882.f[1];
      V v_x11_24885 = v_field_24883;
      V v_st_24886 = v_field_24884;
      switch (heff_tag_of(v_x11_24885)) {
      case TAG_Left: {
        V v_e_24887 = heff_field(v_x11_24885, 0);
        V v_ru_24x11_24885_24Left = heff_take_reuse_n(v_x11_24885, 1ULL, 1);
        heff_drop_tag(v_e0_241, 2);
        heff_drop_rec(v_kw_24879, 9);
        return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_24885_24Left, TAG_Left, 1, (V[]){v_e_24887}), v_st_24886});
      }
      case TAG_Right: {
        V v_x_24888 = heff_field(v_x11_24885, 0);
        V v_ru_24x11_24885_24Right = heff_take_reuse_n(v_x11_24885, 1ULL, 1);
        V v_t_24889 = (g_heff_2esyntax_2ecst_2elastE(v_e0_241));
        V v_e_24890 = heff_get_n(v_t_24889, 4, 9);
        V v_t_24891 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_24879, 3, 9), v_e_24890});
        V v_x_24892 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EDo, 1, (V[]){v_x_24888}), v_t_24891});
        return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_24885_24Right, TAG_Right, 1, (V[]){v_x_24892}), v_st_24886});
      }
      default: return heff_nomatch(v_x11_24885);
      }
    }
  }
  case TAG_ESBind: {
    heff_drop_rec(v_r_240, 3);
    V v_t_24896 = (g_heff_2esyntax_2ecst_2efirstE(v_e0_241));
    V v_start_24897 = heff_take_field(v_t_24896, 3);
    V v_end_24898 = heff_get_n(v_t_24896, 4, 9);
    V v_t_24899 = ({ V a_0 = v_e0_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e0_241, 3); r_; });
    V v_t_24900 = heff_strAppend(heff_get_n(v_t_24899, 1, 9), ((V)&g_heff_2esyntax_2esurface_2eexprL_str34));
    V v_msg_24901 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eexprL_str35), v_t_24900);
    V v_t_24902 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24901, heff_rec_n(2, shape_start__end, (V[]){v_start_24897, v_end_24898}), NTAG(TAG_Nothing)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24902}), v_z_242});
  }
  case TAG_ELet: {
    HEFF_LAST return g_heff_2esyntax_2esurface_2eletL(v_r_240, v_e0_241, v_z_242);
  }
  case TAG_ELetElse: {
    heff_drop_rec(v_r_240, 3);
    V v_t_24916 = (g_heff_2esyntax_2ecst_2efirstE(v_e0_241));
    V v_start_24917 = heff_take_field(v_t_24916, 3);
    V v_end_24918 = heff_get_n(v_t_24916, 4, 9);
    V v_t_24919 = ({ V a_0 = v_e0_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e0_241, 7); r_; });
    V v_t_24920 = heff_strAppend(heff_get_n(v_t_24919, 1, 9), ((V)&g_heff_2esyntax_2esurface_2eexprL_str36));
    V v_msg_24921 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eexprL_str37), v_t_24920);
    V v_t_24922 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24921, heff_rec_n(2, shape_start__end, (V[]){v_start_24917, v_end_24918}), NTAG(TAG_Nothing)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24922}), v_z_242});
  }
  case TAG_ELetMut: {
    heff_drop_rec(v_r_240, 3);
    V v_t_24929 = (g_heff_2esyntax_2ecst_2efirstE(v_e0_241));
    V v_start_24930 = heff_take_field(v_t_24929, 3);
    V v_end_24931 = heff_get_n(v_t_24929, 4, 9);
    V v_t_24932 = ({ V a_0 = v_e0_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e0_241, 6); r_; });
    V v_t_24933 = heff_strAppend(heff_get_n(v_t_24932, 1, 9), ((V)&g_heff_2esyntax_2esurface_2eexprL_str38));
    V v_msg_24934 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eexprL_str39), v_t_24933);
    V v_t_24935 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_24934, heff_rec_n(2, shape_start__end, (V[]){v_start_24930, v_end_24931}), NTAG(TAG_Nothing)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_24935}), v_z_242});
  }
  case TAG_EAssign: {
    V v_x_24936 = heff_field(v_e0_241, 0);
    V v_e_24938 = heff_field(v_e0_241, 2);
    V v_ru_24e0_241_24EAssign = heff_take_reuse_n(v_e0_241, 5ULL, 3);
    V v_text_24939 = heff_take_field(v_x_24936, 1);
    V v_start_24940 = heff_take_field(v_x_24936, 3);
    V v_end_24941 = heff_get_n(v_x_24936, 4, 9);
    V v_m_24942 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_e_24938)}));
    V v_x1_24943 = heff_tr(heff_call(v_m_24942, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x1_24943)) {
    case TAG_MkPair: {
      V v_x11_24944 = heff_field(v_x1_24943, 0);
      V v_st_24945 = heff_field(v_x1_24943, 1);
      V v_ru_24x1_24943_24MkPair = heff_take_reuse_n(v_x1_24943, 3ULL, 2);
      switch (heff_tag_of(v_x11_24944)) {
      case TAG_Left: {
        V v_e_24946 = heff_field(v_x11_24944, 0);
        heff_take_n(v_x11_24944, 1ULL, 1);
        heff_drop(v_e_24938);
        heff_drop_cell(v_ru_24e0_241_24EAssign, 3);
        heff_drop(v_text_24939);
        heff_drop(v_start_24940);
        heff_drop(v_end_24941);
        return heff_tag_at_n(v_ru_24x1_24943_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24946}), v_st_24945});
      }
      case TAG_Right: {
        V v_x_24947 = heff_field(v_x11_24944, 0);
        heff_take_n(v_x11_24944, 1ULL, 1);
        V v_t_24948 = heff_tag_at_n(v_ru_24e0_241_24EAssign, TAG_EAssign, 3, (V[]){v_text_24939, heff_rec_n(2, shape_start__end, (V[]){heff_dup(v_start_24940), v_end_24941}), v_x_24947});
        V v_t_24949 = (g_heff_2esyntax_2ecst_2elastE(v_e_24938));
        V v_e_24950 = heff_get_n(v_t_24949, 4, 9);
        V v_x_24951 = heff_tag_n(TAG_At, 2, (V[]){v_t_24948, heff_rec_n(2, shape_start__end, (V[]){v_start_24940, v_e_24950})});
        return heff_tag_at_n(v_ru_24x1_24943_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24951}), v_st_24945});
      }
      default: return heff_nomatch(v_x11_24944);
      }
    }
    default: return heff_nomatch(v_x1_24943);
    }
  }
  case TAG_EWhile: {
    V v_kw_24952 = heff_dup(heff_field(v_e0_241, 0));
    V v_c_24953 = heff_dup(heff_field(v_e0_241, 1));
    V v_body_24955 = heff_dup(heff_field(v_e0_241, 3));
    V v_m_24956 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_c_24953}));
    V v_x1_24957 = heff_tr(heff_call(v_m_24956, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x1_24957)) {
    case TAG_MkPair: {
      V v_x11_24958 = heff_field(v_x1_24957, 0);
      V v_st_24959 = heff_field(v_x1_24957, 1);
      V v_ru_24x1_24957_24MkPair = heff_take_reuse_n(v_x1_24957, 3ULL, 2);
      switch (heff_tag_of(v_x11_24958)) {
      case TAG_Left: {
        V v_e_24960 = heff_field(v_x11_24958, 0);
        heff_take_n(v_x11_24958, 1ULL, 1);
        heff_drop_rec(v_r_240, 3);
        heff_drop_tag(v_e0_241, 4);
        heff_drop_rec(v_kw_24952, 9);
        heff_drop(v_body_24955);
        return heff_tag_at_n(v_ru_24x1_24957_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24960}), v_st_24959});
      }
      case TAG_Right: {
        V v_x_24961 = heff_field(v_x11_24958, 0);
        heff_take_n(v_x11_24958, 1ULL, 1);
        HeffT2 v_t_24963 = (g_heff_2esyntax_2esurface_2eblock_24cpr(heff_clo_n(g_heff_2esyntax_2esurface_2eexprL_lam9, 1, 1, (V[]){v_r_240}), v_body_24955, v_st_24959));
        {
          V v_field_24964 = v_t_24963.f[0];
          V v_field_24965 = v_t_24963.f[1];
          V v_x11_24966 = v_field_24964;
          V v_st_24967 = v_field_24965;
          switch (heff_tag_of(v_x11_24966)) {
          case TAG_Left: {
            V v_e_24968 = heff_field(v_x11_24966, 0);
            heff_take_n(v_x11_24966, 1ULL, 1);
            heff_drop_tag(v_e0_241, 4);
            heff_drop_rec(v_kw_24952, 9);
            heff_drop(v_x_24961);
            return heff_tag_at_n(v_ru_24x1_24957_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24968}), v_st_24967});
          }
          case TAG_Right: {
            V v_x_24969 = heff_field(v_x11_24966, 0);
            heff_take_n(v_x11_24966, 1ULL, 1);
            V v_t_24970 = (g_heff_2esyntax_2ecst_2elastE(v_e0_241));
            V v_e_24971 = heff_get_n(v_t_24970, 4, 9);
            V v_t_24972 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_24952, 3, 9), v_e_24971});
            V v_x_24973 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_EWhile, 2, (V[]){v_x_24961, v_x_24969}), v_t_24972});
            return heff_tag_at_n(v_ru_24x1_24957_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_24973}), v_st_24967});
          }
          default: return heff_nomatch(v_x11_24966);
          }
        }
      }
      default: return heff_nomatch(v_x11_24958);
      }
    }
    default: return heff_nomatch(v_x1_24957);
    }
  }
  case TAG_EFor: {
    V v_kw_24974 = heff_dup(heff_field(v_e0_241, 0));
    V v_p_24975 = heff_dup(heff_field(v_e0_241, 1));
    V v_c_24977 = heff_dup(heff_field(v_e0_241, 3));
    V v_body_24979 = heff_dup(heff_field(v_e0_241, 5));
    V v_m_24980 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_c_24977}));
    V v_x1_24981 = heff_tr(heff_call(v_m_24980, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x1_24981)) {
    case TAG_MkPair: {
      V v_x11_24982 = heff_field(v_x1_24981, 0);
      V v_st_24983 = heff_field(v_x1_24981, 1);
      V v_ru_24x1_24981_24MkPair = heff_take_reuse_n(v_x1_24981, 3ULL, 2);
      switch (heff_tag_of(v_x11_24982)) {
      case TAG_Left: {
        V v_e_24984 = heff_field(v_x11_24982, 0);
        heff_take_n(v_x11_24982, 1ULL, 1);
        heff_drop_rec(v_r_240, 3);
        heff_drop_tag(v_e0_241, 6);
        heff_drop_rec(v_kw_24974, 9);
        heff_drop(v_p_24975);
        heff_drop(v_body_24979);
        return heff_tag_at_n(v_ru_24x1_24981_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24984}), v_st_24983});
      }
      case TAG_Right: {
        V v_x_24985 = heff_field(v_x11_24982, 0);
        heff_take_n(v_x11_24982, 1ULL, 1);
        V v_m_24986 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 1)), 1, (V[]){heff_dup(v_p_24975)}));
        V v_x1_24987 = heff_tr(heff_call(v_m_24986, 1, (V[]){v_st_24983}));
        switch (heff_tag_of(v_x1_24987)) {
        case TAG_MkPair: {
          V v_x11_24988 = heff_field(v_x1_24987, 0);
          V v_st_24989 = heff_field(v_x1_24987, 1);
          V v_ru_24x1_24987_24MkPair = heff_take_reuse_n(v_x1_24987, 3ULL, 2);
          switch (heff_tag_of(v_x11_24988)) {
          case TAG_Left: {
            V v_e_24990 = heff_field(v_x11_24988, 0);
            heff_take_n(v_x11_24988, 1ULL, 1);
            heff_drop_rec(v_r_240, 3);
            heff_drop_tag(v_e0_241, 6);
            heff_drop_rec(v_kw_24974, 9);
            heff_drop(v_p_24975);
            heff_drop(v_body_24979);
            heff_drop(v_x_24985);
            heff_drop_cell(v_ru_24x1_24987_24MkPair, 2);
            return heff_tag_at_n(v_ru_24x1_24981_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24990}), v_st_24989});
          }
          case TAG_Right: {
            V v_x_24991 = heff_field(v_x11_24988, 0);
            heff_take_n(v_x11_24988, 1ULL, 1);
            V v_t_24992 = ({ V b_0 = NTAG(TAG_Nil); V a_1 = v_p_24975; V r_ = (g_heff_2esyntax_2esurface_2eboundBy(b_0, a_1)); heff_drop(b_0); heff_drop(v_p_24975); r_; });
            V v_t_24994 = heff_tr(heff_call(((V)&g_heff_2esyntax_2esurface_2eblock_clo), 2, (V[]){heff_clo_n(g_heff_2esyntax_2esurface_2eexprL_lam10, 1, 1, (V[]){v_r_240}), v_body_24979}));
            HeffT2 v_t_24995 = (g_heff_2esyntax_2esurface_2ewithScope_24cpr(v_t_24992, v_t_24994, v_st_24989));
            {
              V v_field_24996 = v_t_24995.f[0];
              V v_field_24997 = v_t_24995.f[1];
              V v_x11_24998 = v_field_24996;
              V v_st_24999 = v_field_24997;
              switch (heff_tag_of(v_x11_24998)) {
              case TAG_Left: {
                V v_e_241000 = heff_field(v_x11_24998, 0);
                heff_take_n(v_x11_24998, 1ULL, 1);
                heff_drop_tag(v_e0_241, 6);
                heff_drop_rec(v_kw_24974, 9);
                heff_drop(v_x_24985);
                heff_drop_cell(v_ru_24x1_24987_24MkPair, 2);
                heff_drop(v_x_24991);
                return heff_tag_at_n(v_ru_24x1_24981_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241000}), v_st_24999});
              }
              case TAG_Right: {
                V v_x_241001 = heff_field(v_x11_24998, 0);
                heff_take_n(v_x11_24998, 1ULL, 1);
                V v_t_241002 = (g_heff_2esyntax_2ecst_2elastE(v_e0_241));
                V v_e_241003 = heff_get_n(v_t_241002, 4, 9);
                V v_t_241004 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_24974, 3, 9), v_e_241003});
                V v_x_241005 = heff_tag_at_n(v_ru_24x1_24987_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_EFor, 3, (V[]){v_x_24991, v_x_24985, v_x_241001}), v_t_241004});
                return heff_tag_at_n(v_ru_24x1_24981_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_241005}), v_st_24999});
              }
              default: return heff_nomatch(v_x11_24998);
              }
            }
          }
          default: return heff_nomatch(v_x11_24988);
          }
        }
        default: return heff_nomatch(v_x1_24987);
        }
      }
      default: return heff_nomatch(v_x11_24982);
      }
    }
    default: return heff_nomatch(v_x1_24981);
    }
  }
  case TAG_EJump: {
    V v_kw_241006 = heff_field(v_e0_241, 0);
    V v_ru_24e0_241_24EJump = heff_take_reuse_n(v_e0_241, 1ULL, 1);
    heff_drop_rec(v_r_240, 3);
    V v_text_241007 = heff_take_field(v_kw_241006, 1);
    V v_start_241008 = heff_take_field(v_kw_241006, 3);
    V v_end_241009 = heff_get_n(v_kw_241006, 4, 9);
    V v_t_241010;
    if (heff_strEq_c(v_text_241007, ((V)&g_heff_2esyntax_2esurface_2eexprL_str40))) {
      v_t_241010 = NTAG(TAG_EBreak);
    } else {
      v_t_241010 = NTAG(TAG_EContinue);
    }
    V v_t_241011 = heff_tag_n(TAG_At, 2, (V[]){v_t_241010, heff_rec_n(2, shape_start__end, (V[]){v_start_241008, v_end_241009})});
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24e0_241_24EJump, TAG_Right, 1, (V[]){v_t_241011}), v_z_242});
  }
  case TAG_EReturn: {
    V v_kw_241012 = heff_field(v_e0_241, 0);
    V v_e_241013 = heff_field(v_e0_241, 1);
    V v_ru_24e0_241_24EReturn = heff_take_reuse_n(v_e0_241, 3ULL, 2);
    V v_m_241014 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_e_241013)}));
    V v_x1_241015 = heff_tr(heff_call(v_m_241014, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x1_241015)) {
    case TAG_MkPair: {
      V v_x11_241016 = heff_field(v_x1_241015, 0);
      V v_st_241017 = heff_field(v_x1_241015, 1);
      V v_ru_24x1_241015_24MkPair = heff_take_reuse_n(v_x1_241015, 3ULL, 2);
      switch (heff_tag_of(v_x11_241016)) {
      case TAG_Left: {
        V v_e_241018 = heff_field(v_x11_241016, 0);
        heff_take_n(v_x11_241016, 1ULL, 1);
        heff_drop_rec(v_kw_241012, 9);
        heff_drop(v_e_241013);
        heff_drop_cell(v_ru_24x1_241015_24MkPair, 2);
        return heff_tag_at_n(v_ru_24e0_241_24EReturn, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241018}), v_st_241017});
      }
      case TAG_Right: {
        V v_x_241019 = heff_field(v_x11_241016, 0);
        heff_take_n(v_x11_241016, 1ULL, 1);
        V v_t_241020 = (g_heff_2esyntax_2ecst_2elastE(v_e_241013));
        V v_e_241021 = heff_get_n(v_t_241020, 4, 9);
        V v_t_241022 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_241012, 3, 9), v_e_241021});
        V v_x_241023 = heff_tag_at_n(v_ru_24e0_241_24EReturn, TAG_At, 2, (V[]){heff_tag_n(TAG_EReturn, 1, (V[]){v_x_241019}), v_t_241022});
        return heff_tag_at_n(v_ru_24x1_241015_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_241023}), v_st_241017});
      }
      default: return heff_nomatch(v_x11_241016);
      }
    }
    default: return heff_nomatch(v_x1_241015);
    }
  }
  case TAG_ENest: {
    V v_o_241024 = heff_field(v_e0_241, 0);
    V v_e_241026 = heff_field(v_e0_241, 2);
    V v_c_241027 = heff_field(v_e0_241, 3);
    heff_take_n(v_e0_241, 13ULL, 4);
    V v_m_241028 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_241026}));
    V v_x1_241029 = heff_tr(heff_call(v_m_241028, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x1_241029)) {
    case TAG_MkPair: {
      V v_x11_241030 = heff_field(v_x1_241029, 0);
      V v_st_241031 = heff_field(v_x1_241029, 1);
      V v_ru_24x1_241029_24MkPair = heff_take_reuse_n(v_x1_241029, 3ULL, 2);
      switch (heff_tag_of(v_x11_241030)) {
      case TAG_Left: {
        V v_e_241032 = heff_field(v_x11_241030, 0);
        heff_take_n(v_x11_241030, 1ULL, 1);
        heff_drop_rec(v_o_241024, 9);
        heff_drop_rec(v_c_241027, 9);
        return heff_tag_at_n(v_ru_24x1_241029_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241032}), v_st_241031});
      }
      case TAG_Right: {
        V v_x_241033 = heff_field(v_x11_241030, 0);
        V v_ru_24x11_241030_24Right = heff_take_reuse_n(v_x11_241030, 1ULL, 1);
        V v_t_241034 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_o_241024, 3, 9), heff_get_n(v_c_241027, 4, 9)});
        V v_t_241035 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_241030_24Right, TAG_ENest, 1, (V[]){v_x_241033}), v_t_241034});
        return heff_tag_at_n(v_ru_24x1_241029_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_t_241035}), v_st_241031});
      }
      default: return heff_nomatch(v_x11_241030);
      }
    }
    default: return heff_nomatch(v_x1_241029);
    }
  }
  case TAG_EArrow: {
    V v_arrow_241036 = heff_field(v_e0_241, 0);
    V v_e_241037 = heff_field(v_e0_241, 1);
    V v_ru_24e0_241_24EArrow = heff_take_reuse_n(v_e0_241, 3ULL, 2);
    V v_m_241038 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_e_241037)}));
    V v_x1_241039 = heff_tr(heff_call(v_m_241038, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x1_241039)) {
    case TAG_MkPair: {
      V v_x11_241040 = heff_field(v_x1_241039, 0);
      V v_st_241041 = heff_field(v_x1_241039, 1);
      V v_ru_24x1_241039_24MkPair = heff_take_reuse_n(v_x1_241039, 3ULL, 2);
      switch (heff_tag_of(v_x11_241040)) {
      case TAG_Left: {
        V v_e_241042 = heff_field(v_x11_241040, 0);
        heff_take_n(v_x11_241040, 1ULL, 1);
        heff_drop_rec(v_arrow_241036, 9);
        heff_drop(v_e_241037);
        heff_drop_cell(v_ru_24x1_241039_24MkPair, 2);
        return heff_tag_at_n(v_ru_24e0_241_24EArrow, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241042}), v_st_241041});
      }
      case TAG_Right: {
        V v_x_241043 = heff_field(v_x11_241040, 0);
        heff_take_n(v_x11_241040, 1ULL, 1);
        V v_t_241044 = (g_heff_2esyntax_2ecst_2elastE(v_e_241037));
        V v_e_241045 = heff_get_n(v_t_241044, 4, 9);
        V v_t_241046 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_arrow_241036, 3, 9), v_e_241045});
        V v_x_241047 = heff_tag_at_n(v_ru_24e0_241_24EArrow, TAG_At, 2, (V[]){heff_tag_n(TAG_ENest, 1, (V[]){v_x_241043}), v_t_241046});
        return heff_tag_at_n(v_ru_24x1_241039_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_241047}), v_st_241041});
      }
      default: return heff_nomatch(v_x11_241040);
      }
    }
    default: return heff_nomatch(v_x1_241039);
    }
  }
  case TAG_IfThen: {
    V v_kw_241048 = heff_field(v_e0_241, 0);
    V v_c_241049 = heff_field(v_e0_241, 1);
    V v_a_241051 = heff_field(v_e0_241, 3);
    heff_take_n(v_e0_241, 11ULL, 4);
    V v_m_241052 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_c_241049}));
    V v_x1_241053 = heff_tr(heff_call(v_m_241052, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x1_241053)) {
    case TAG_MkPair: {
      V v_x11_241054 = heff_field(v_x1_241053, 0);
      V v_st_241055 = heff_field(v_x1_241053, 1);
      V v_ru_24x1_241053_24MkPair = heff_take_reuse_n(v_x1_241053, 3ULL, 2);
      switch (heff_tag_of(v_x11_241054)) {
      case TAG_Left: {
        V v_e_241056 = heff_field(v_x11_241054, 0);
        heff_take_n(v_x11_241054, 1ULL, 1);
        heff_drop_rec(v_r_240, 3);
        heff_drop_rec(v_kw_241048, 9);
        heff_drop(v_a_241051);
        return heff_tag_at_n(v_ru_24x1_241053_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241056}), v_st_241055});
      }
      case TAG_Right: {
        V v_x_241057 = heff_field(v_x11_241054, 0);
        heff_take_n(v_x11_241054, 1ULL, 1);
        V v_m_241058 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){heff_dup(v_a_241051)}));
        V v_x1_241059 = heff_tr(heff_call(v_m_241058, 1, (V[]){v_st_241055}));
        switch (heff_tag_of(v_x1_241059)) {
        case TAG_MkPair: {
          V v_x11_241060 = heff_field(v_x1_241059, 0);
          V v_st_241061 = heff_field(v_x1_241059, 1);
          V v_ru_24x1_241059_24MkPair = heff_take_reuse_n(v_x1_241059, 3ULL, 2);
          switch (heff_tag_of(v_x11_241060)) {
          case TAG_Left: {
            V v_e_241062 = heff_field(v_x11_241060, 0);
            heff_take_n(v_x11_241060, 1ULL, 1);
            heff_drop_rec(v_kw_241048, 9);
            heff_drop(v_a_241051);
            heff_drop(v_x_241057);
            heff_drop_cell(v_ru_24x1_241059_24MkPair, 2);
            return heff_tag_at_n(v_ru_24x1_241053_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241062}), v_st_241061});
          }
          case TAG_Right: {
            V v_x_241063 = heff_field(v_x11_241060, 0);
            heff_take_n(v_x11_241060, 1ULL, 1);
            V v_t_241064 = (g_heff_2esyntax_2ecst_2elastE(v_a_241051));
            V v_e_241065 = heff_get_n(v_t_241064, 4, 9);
            V v_t_241066 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_241048, 3, 9), v_e_241065});
            V v_x_241067 = heff_tag_at_n(v_ru_24x1_241059_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_EIfThen, 2, (V[]){v_x_241057, v_x_241063}), v_t_241066});
            return heff_tag_at_n(v_ru_24x1_241053_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_241067}), v_st_241061});
          }
          default: return heff_nomatch(v_x11_241060);
          }
        }
        default: return heff_nomatch(v_x1_241059);
        }
      }
      default: return heff_nomatch(v_x11_241054);
      }
    }
    default: return heff_nomatch(v_x1_241053);
    }
  }
  case TAG_ETry: {
    V v_kw_241068 = heff_dup(heff_field(v_e0_241, 0));
    V v_ty_241069 = heff_dup(heff_field(v_e0_241, 1));
    V v_body_241070 = heff_dup(heff_field(v_e0_241, 2));
    V v_c_241071 = heff_dup(heff_field(v_e0_241, 3));
    V v_m_241072 = (g_heff_2esyntax_2esurface_2etryTypeL(heff_dup(v_r_240), v_ty_241069));
    V v_x1_241073 = heff_tr(heff_call(v_m_241072, 1, (V[]){v_z_242}));
    switch (heff_tag_of(v_x1_241073)) {
    case TAG_MkPair: {
      V v_x11_241074 = heff_field(v_x1_241073, 0);
      V v_st_241075 = heff_field(v_x1_241073, 1);
      V v_ru_24x1_241073_24MkPair = heff_take_reuse_n(v_x1_241073, 3ULL, 2);
      switch (heff_tag_of(v_x11_241074)) {
      case TAG_Left: {
        V v_e_241076 = heff_field(v_x11_241074, 0);
        heff_take_n(v_x11_241074, 1ULL, 1);
        heff_drop_rec(v_r_240, 3);
        heff_drop_tag(v_e0_241, 4);
        heff_drop_rec(v_kw_241068, 9);
        heff_drop(v_body_241070);
        heff_drop(v_c_241071);
        return heff_tag_at_n(v_ru_24x1_241073_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241076}), v_st_241075});
      }
      case TAG_Right: {
        V v_x_241077 = heff_field(v_x11_241074, 0);
        V v_ru_24x11_241074_24Right = heff_take_reuse_n(v_x11_241074, 1ULL, 1);
        HeffT2 v_t_241079 = (g_heff_2esyntax_2esurface_2eblock_24cpr(heff_clo_n(g_heff_2esyntax_2esurface_2eexprL_lam11, 1, 1, (V[]){heff_dup(v_r_240)}), v_body_241070, v_st_241075));
        {
          V v_field_241080 = v_t_241079.f[0];
          V v_field_241081 = v_t_241079.f[1];
          V v_x11_241082 = v_field_241080;
          V v_st_241083 = v_field_241081;
          switch (heff_tag_of(v_x11_241082)) {
          case TAG_Left: {
            V v_e_241084 = heff_field(v_x11_241082, 0);
            heff_take_n(v_x11_241082, 1ULL, 1);
            heff_drop_rec(v_r_240, 3);
            heff_drop_tag(v_e0_241, 4);
            heff_drop_rec(v_kw_241068, 9);
            heff_drop(v_c_241071);
            heff_drop(v_x_241077);
            heff_drop_cell(v_ru_24x11_241074_24Right, 1);
            return heff_tag_at_n(v_ru_24x1_241073_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241084}), v_st_241083});
          }
          case TAG_Right: {
            V v_x_241085 = heff_field(v_x11_241082, 0);
            heff_take_n(v_x11_241082, 1ULL, 1);
            V v_m_241086 = (g_heff_2esyntax_2esurface_2ecatchL(v_r_240, v_c_241071));
            V v_x1_241087 = heff_tr(heff_call(v_m_241086, 1, (V[]){v_st_241083}));
            switch (heff_tag_of(v_x1_241087)) {
            case TAG_MkPair: {
              V v_x11_241088 = heff_field(v_x1_241087, 0);
              V v_st_241089 = heff_field(v_x1_241087, 1);
              V v_ru_24x1_241087_24MkPair = heff_take_reuse_n(v_x1_241087, 3ULL, 2);
              switch (heff_tag_of(v_x11_241088)) {
              case TAG_Left: {
                V v_e_241090 = heff_field(v_x11_241088, 0);
                heff_take_n(v_x11_241088, 1ULL, 1);
                heff_drop_tag(v_e0_241, 4);
                heff_drop_rec(v_kw_241068, 9);
                heff_drop(v_x_241077);
                heff_drop_cell(v_ru_24x11_241074_24Right, 1);
                heff_drop(v_x_241085);
                heff_drop_cell(v_ru_24x1_241087_24MkPair, 2);
                return heff_tag_at_n(v_ru_24x1_241073_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241090}), v_st_241089});
              }
              case TAG_Right: {
                V v_x_241091 = heff_field(v_x11_241088, 0);
                heff_take_n(v_x11_241088, 1ULL, 1);
                V v_t_241092 = heff_tag_at_n(v_ru_24x11_241074_24Right, TAG_ETry, 1, (V[]){heff_tag_n(TAG_MkTry, 3, (V[]){v_x_241077, v_x_241085, v_x_241091})});
                V v_t_241093 = (g_heff_2esyntax_2ecst_2elastE(v_e0_241));
                V v_e_241094 = heff_get_n(v_t_241093, 4, 9);
                V v_t_241095 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_241068, 3, 9), v_e_241094});
                V v_x_241096 = heff_tag_at_n(v_ru_24x1_241087_24MkPair, TAG_At, 2, (V[]){v_t_241092, v_t_241095});
                return heff_tag_at_n(v_ru_24x1_241073_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_241096}), v_st_241089});
              }
              default: return heff_nomatch(v_x11_241088);
              }
            }
            default: return heff_nomatch(v_x1_241087);
            }
          }
          default: return heff_nomatch(v_x11_241082);
          }
        }
      }
      default: return heff_nomatch(v_x11_241074);
      }
    }
    default: return heff_nomatch(v_x1_241073);
    }
  }
  case TAG_ECatch: {
    heff_drop_rec(v_r_240, 3);
    V v_t_241101 = (g_heff_2esyntax_2ecst_2efirstE(v_e0_241));
    V v_start_241102 = heff_take_field(v_t_241101, 3);
    V v_end_241103 = heff_get_n(v_t_241101, 4, 9);
    V v_t_241104 = ({ V a_0 = v_e0_241; V r_ = (g_heff_2esyntax_2ecst_2efirstE(a_0)); heff_drop_tag(v_e0_241, 4); r_; });
    V v_t_241105 = heff_strAppend(heff_get_n(v_t_241104, 1, 9), ((V)&g_heff_2esyntax_2esurface_2eexprL_str41));
    V v_msg_241106 = heff_strAppend(((V)&g_heff_2esyntax_2esurface_2eexprL_str42), v_t_241105);
    V v_t_241107 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(150LL), NTAG(TAG_SError), v_msg_241106, heff_rec_n(2, shape_start__end, (V[]){v_start_241102, v_end_241103}), NTAG(TAG_Nothing)});
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_t_241107}), v_z_242});
  }
  case TAG_EWith: {
    V v_kw_241108 = heff_dup(heff_field(v_e0_241, 0));
    V v_e_241109 = heff_dup(heff_field(v_e0_241, 1));
    V v_e04_241111 = heff_dup(heff_field(v_e0_241, 3));
    V v_body_241113 = heff_dup(heff_field(v_e0_241, 5));
    switch (heff_tag_of(v_e04_241111)) {
    case TAG_PCon: {
      V v_m_241116 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e_241109}));
      V v_x1_241117 = heff_tr(heff_call(v_m_241116, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_241117)) {
      case TAG_MkPair: {
        V v_x11_241118 = heff_field(v_x1_241117, 0);
        V v_st_241119 = heff_field(v_x1_241117, 1);
        V v_ru_24x1_241117_24MkPair = heff_take_reuse_n(v_x1_241117, 3ULL, 2);
        switch (heff_tag_of(v_x11_241118)) {
        case TAG_Left: {
          V v_e_241120 = heff_field(v_x11_241118, 0);
          heff_take_n(v_x11_241118, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_tag(v_e0_241, 6);
          heff_drop_rec(v_kw_241108, 9);
          heff_drop_tag(v_e04_241111, 2);
          heff_drop(v_body_241113);
          return heff_tag_at_n(v_ru_24x1_241117_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241120}), v_st_241119});
        }
        case TAG_Right: {
          V v_x_241121 = heff_field(v_x11_241118, 0);
          V v_ru_24x11_241118_24Right = heff_take_reuse_n(v_x11_241118, 1ULL, 1);
          V v_m_241122 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 1)), 1, (V[]){heff_dup(v_e04_241111)}));
          V v_x1_241123 = heff_tr(heff_call(v_m_241122, 1, (V[]){v_st_241119}));
          switch (heff_tag_of(v_x1_241123)) {
          case TAG_MkPair: {
            V v_x11_241124 = heff_field(v_x1_241123, 0);
            V v_st_241125 = heff_field(v_x1_241123, 1);
            V v_ru_24x1_241123_24MkPair = heff_take_reuse_n(v_x1_241123, 3ULL, 2);
            switch (heff_tag_of(v_x11_241124)) {
            case TAG_Left: {
              V v_e_241126 = heff_field(v_x11_241124, 0);
              heff_take_n(v_x11_241124, 1ULL, 1);
              heff_drop_rec(v_r_240, 3);
              heff_drop_tag(v_e0_241, 6);
              heff_drop_rec(v_kw_241108, 9);
              heff_drop_tag(v_e04_241111, 2);
              heff_drop(v_body_241113);
              heff_drop(v_x_241121);
              heff_drop_cell(v_ru_24x11_241118_24Right, 1);
              heff_drop_cell(v_ru_24x1_241123_24MkPair, 2);
              return heff_tag_at_n(v_ru_24x1_241117_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241126}), v_st_241125});
            }
            case TAG_Right: {
              V v_x_241127 = heff_field(v_x11_241124, 0);
              heff_take_n(v_x11_241124, 1ULL, 1);
              V v_t_241128 = ({ V b_0 = NTAG(TAG_Nil); V a_1 = v_e04_241111; V r_ = (g_heff_2esyntax_2esurface_2eboundBy(b_0, a_1)); heff_drop(b_0); heff_drop_tag(v_e04_241111, 2); r_; });
              V v_t_241130 = heff_tr(heff_call(((V)&g_heff_2esyntax_2esurface_2eblock_clo), 2, (V[]){heff_clo_n(g_heff_2esyntax_2esurface_2eexprL_lam12, 1, 1, (V[]){v_r_240}), v_body_241113}));
              HeffT2 v_t_241131 = (g_heff_2esyntax_2esurface_2ewithScope_24cpr(v_t_241128, v_t_241130, v_st_241125));
              {
                V v_field_241132 = v_t_241131.f[0];
                V v_field_241133 = v_t_241131.f[1];
                V v_x11_241134 = v_field_241132;
                V v_st_241135 = v_field_241133;
                switch (heff_tag_of(v_x11_241134)) {
                case TAG_Left: {
                  V v_e_241136 = heff_field(v_x11_241134, 0);
                  heff_take_n(v_x11_241134, 1ULL, 1);
                  heff_drop_tag(v_e0_241, 6);
                  heff_drop_rec(v_kw_241108, 9);
                  heff_drop(v_x_241121);
                  heff_drop_cell(v_ru_24x11_241118_24Right, 1);
                  heff_drop_cell(v_ru_24x1_241123_24MkPair, 2);
                  heff_drop(v_x_241127);
                  return heff_tag_at_n(v_ru_24x1_241117_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241136}), v_st_241135});
                }
                case TAG_Right: {
                  V v_x_241137 = heff_field(v_x11_241134, 0);
                  heff_take_n(v_x11_241134, 1ULL, 1);
                  V v_t_241140;
                  switch (heff_tag_of(v_x_241127)) {
                  case TAG_At: {
                    V v_s_241139 = heff_dup(heff_field(v_x_241127, 1));
                    v_t_241140 = v_s_241139;
                    break;
                  }
                  default: heff_nomatch(v_x_241127);
                  }
                  V v_t_241143;
                  switch (heff_tag_of(v_x_241127)) {
                  case TAG_At: {
                    V v_s_241142 = heff_dup(heff_field(v_x_241127, 1));
                    v_t_241143 = v_s_241142;
                    break;
                  }
                  default: heff_nomatch(v_x_241127);
                  }
                  V v_t_241144 = heff_tag_at_n(v_ru_24x1_241123_24MkPair, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_241118_24Right, TAG_EVar, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2eexprL_str43)}), v_t_241143});
                  V v_t_241147;
                  switch (heff_tag_of(v_x_241127)) {
                  case TAG_At: {
                    V v_s_241146 = heff_dup(heff_field(v_x_241127, 1));
                    v_t_241147 = v_s_241146;
                    break;
                  }
                  default: heff_nomatch(v_x_241127);
                  }
                  V v_t_241148 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_StmtLet, 2, (V[]){v_x_241127, v_t_241144}), v_t_241147});
                  V v_t_241149 = heff_tag_n(TAG_EWith, 4, (V[]){v_x_241121, ((V)&g_heff_2esyntax_2esurface_2eexprL_str44), v_t_241140, heff_tag_n(TAG_Cons, 2, (V[]){v_t_241148, v_x_241137})});
                  V v_t_241150 = (g_heff_2esyntax_2ecst_2elastE(v_e0_241));
                  V v_e_241151 = heff_get_n(v_t_241150, 4, 9);
                  V v_t_241152 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_241108, 3, 9), v_e_241151});
                  V v_x_241153 = heff_tag_n(TAG_At, 2, (V[]){v_t_241149, v_t_241152});
                  return heff_tag_at_n(v_ru_24x1_241117_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_241153}), v_st_241135});
                }
                default: return heff_nomatch(v_x11_241134);
                }
              }
            }
            default: return heff_nomatch(v_x11_241124);
            }
          }
          default: return heff_nomatch(v_x1_241123);
          }
        }
        default: return heff_nomatch(v_x11_241118);
        }
      }
      default: return heff_nomatch(v_x1_241117);
      }
    }
    case TAG_PAtom: {
      V v_x_241154 = heff_field(v_e04_241111, 0);
      V v_ru_24e04_241111_24PAtom = heff_take_reuse_n(v_e04_241111, 1ULL, 1);
      V v_text_241155 = heff_take_field(v_x_241154, 1);
      V v_start_241156 = heff_take_field(v_x_241154, 3);
      V v_end_241157 = heff_get_n(v_x_241154, 4, 9);
      V v_m_241158 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e_241109}));
      V v_x1_241159 = heff_tr(heff_call(v_m_241158, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_241159)) {
      case TAG_MkPair: {
        V v_x11_241160 = heff_field(v_x1_241159, 0);
        V v_st_241161 = heff_field(v_x1_241159, 1);
        V v_ru_24x1_241159_24MkPair = heff_take_reuse_n(v_x1_241159, 3ULL, 2);
        switch (heff_tag_of(v_x11_241160)) {
        case TAG_Left: {
          V v_e_241162 = heff_field(v_x11_241160, 0);
          heff_take_n(v_x11_241160, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_tag(v_e0_241, 6);
          heff_drop_rec(v_kw_241108, 9);
          heff_drop(v_body_241113);
          heff_drop(v_text_241155);
          heff_drop(v_start_241156);
          heff_drop(v_end_241157);
          return heff_tag_at_n(v_ru_24x1_241159_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24e04_241111_24PAtom, TAG_Left, 1, (V[]){v_e_241162}), v_st_241161});
        }
        case TAG_Right: {
          V v_x_241163 = heff_field(v_x11_241160, 0);
          heff_take_n(v_x11_241160, 1ULL, 1);
          V v_t_241164 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_text_241155), NTAG(TAG_Nil)});
          V v_t_241166 = heff_tr(heff_call(((V)&g_heff_2esyntax_2esurface_2eblock_clo), 2, (V[]){heff_clo_n(g_heff_2esyntax_2esurface_2eexprL_lam13, 1, 1, (V[]){v_r_240}), v_body_241113}));
          HeffT2 v_t_241167 = (g_heff_2esyntax_2esurface_2ewithScope_24cpr(v_t_241164, v_t_241166, v_st_241161));
          {
            V v_field_241168 = v_t_241167.f[0];
            V v_field_241169 = v_t_241167.f[1];
            V v_x11_241170 = v_field_241168;
            V v_st_241171 = v_field_241169;
            switch (heff_tag_of(v_x11_241170)) {
            case TAG_Left: {
              V v_e_241172 = heff_field(v_x11_241170, 0);
              heff_take_n(v_x11_241170, 1ULL, 1);
              heff_drop_tag(v_e0_241, 6);
              heff_drop_rec(v_kw_241108, 9);
              heff_drop(v_text_241155);
              heff_drop(v_start_241156);
              heff_drop(v_end_241157);
              heff_drop(v_x_241163);
              return heff_tag_at_n(v_ru_24x1_241159_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24e04_241111_24PAtom, TAG_Left, 1, (V[]){v_e_241172}), v_st_241171});
            }
            case TAG_Right: {
              V v_x_241173 = heff_field(v_x11_241170, 0);
              heff_take_n(v_x11_241170, 1ULL, 1);
              V v_t_241174 = heff_tag_n(TAG_EWith, 4, (V[]){v_x_241163, v_text_241155, heff_rec_n(2, shape_start__end, (V[]){v_start_241156, v_end_241157}), v_x_241173});
              V v_t_241175 = (g_heff_2esyntax_2ecst_2elastE(v_e0_241));
              V v_e_241176 = heff_get_n(v_t_241175, 4, 9);
              V v_t_241177 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_241108, 3, 9), v_e_241176});
              V v_x_241178 = heff_tag_n(TAG_At, 2, (V[]){v_t_241174, v_t_241177});
              return heff_tag_at_n(v_ru_24x1_241159_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24e04_241111_24PAtom, TAG_Right, 1, (V[]){v_x_241178}), v_st_241171});
            }
            default: return heff_nomatch(v_x11_241170);
            }
          }
        }
        default: return heff_nomatch(v_x11_241160);
        }
      }
      default: return heff_nomatch(v_x1_241159);
      }
    }
    case TAG_PParen: {
      V v_m_241182 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e_241109}));
      V v_x1_241183 = heff_tr(heff_call(v_m_241182, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_241183)) {
      case TAG_MkPair: {
        V v_x11_241184 = heff_field(v_x1_241183, 0);
        V v_st_241185 = heff_field(v_x1_241183, 1);
        V v_ru_24x1_241183_24MkPair = heff_take_reuse_n(v_x1_241183, 3ULL, 2);
        switch (heff_tag_of(v_x11_241184)) {
        case TAG_Left: {
          V v_e_241186 = heff_field(v_x11_241184, 0);
          heff_take_n(v_x11_241184, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_tag(v_e0_241, 6);
          heff_drop_rec(v_kw_241108, 9);
          heff_drop_tag(v_e04_241111, 3);
          heff_drop(v_body_241113);
          return heff_tag_at_n(v_ru_24x1_241183_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241186}), v_st_241185});
        }
        case TAG_Right: {
          V v_x_241187 = heff_field(v_x11_241184, 0);
          V v_ru_24x11_241184_24Right = heff_take_reuse_n(v_x11_241184, 1ULL, 1);
          V v_m_241188 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 1)), 1, (V[]){heff_dup(v_e04_241111)}));
          V v_x1_241189 = heff_tr(heff_call(v_m_241188, 1, (V[]){v_st_241185}));
          switch (heff_tag_of(v_x1_241189)) {
          case TAG_MkPair: {
            V v_x11_241190 = heff_field(v_x1_241189, 0);
            V v_st_241191 = heff_field(v_x1_241189, 1);
            V v_ru_24x1_241189_24MkPair = heff_take_reuse_n(v_x1_241189, 3ULL, 2);
            switch (heff_tag_of(v_x11_241190)) {
            case TAG_Left: {
              V v_e_241192 = heff_field(v_x11_241190, 0);
              heff_take_n(v_x11_241190, 1ULL, 1);
              heff_drop_rec(v_r_240, 3);
              heff_drop_tag(v_e0_241, 6);
              heff_drop_rec(v_kw_241108, 9);
              heff_drop_tag(v_e04_241111, 3);
              heff_drop(v_body_241113);
              heff_drop(v_x_241187);
              heff_drop_cell(v_ru_24x11_241184_24Right, 1);
              heff_drop_cell(v_ru_24x1_241189_24MkPair, 2);
              return heff_tag_at_n(v_ru_24x1_241183_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241192}), v_st_241191});
            }
            case TAG_Right: {
              V v_x_241193 = heff_field(v_x11_241190, 0);
              heff_take_n(v_x11_241190, 1ULL, 1);
              V v_t_241194 = ({ V b_0 = NTAG(TAG_Nil); V a_1 = v_e04_241111; V r_ = (g_heff_2esyntax_2esurface_2eboundBy(b_0, a_1)); heff_drop(b_0); heff_drop_tag(v_e04_241111, 3); r_; });
              V v_t_241196 = heff_tr(heff_call(((V)&g_heff_2esyntax_2esurface_2eblock_clo), 2, (V[]){heff_clo_n(g_heff_2esyntax_2esurface_2eexprL_lam14, 1, 1, (V[]){v_r_240}), v_body_241113}));
              HeffT2 v_t_241197 = (g_heff_2esyntax_2esurface_2ewithScope_24cpr(v_t_241194, v_t_241196, v_st_241191));
              {
                V v_field_241198 = v_t_241197.f[0];
                V v_field_241199 = v_t_241197.f[1];
                V v_x11_241200 = v_field_241198;
                V v_st_241201 = v_field_241199;
                switch (heff_tag_of(v_x11_241200)) {
                case TAG_Left: {
                  V v_e_241202 = heff_field(v_x11_241200, 0);
                  heff_take_n(v_x11_241200, 1ULL, 1);
                  heff_drop_tag(v_e0_241, 6);
                  heff_drop_rec(v_kw_241108, 9);
                  heff_drop(v_x_241187);
                  heff_drop_cell(v_ru_24x11_241184_24Right, 1);
                  heff_drop_cell(v_ru_24x1_241189_24MkPair, 2);
                  heff_drop(v_x_241193);
                  return heff_tag_at_n(v_ru_24x1_241183_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241202}), v_st_241201});
                }
                case TAG_Right: {
                  V v_x_241203 = heff_field(v_x11_241200, 0);
                  heff_take_n(v_x11_241200, 1ULL, 1);
                  V v_t_241206;
                  switch (heff_tag_of(v_x_241193)) {
                  case TAG_At: {
                    V v_s_241205 = heff_dup(heff_field(v_x_241193, 1));
                    v_t_241206 = v_s_241205;
                    break;
                  }
                  default: heff_nomatch(v_x_241193);
                  }
                  V v_t_241209;
                  switch (heff_tag_of(v_x_241193)) {
                  case TAG_At: {
                    V v_s_241208 = heff_dup(heff_field(v_x_241193, 1));
                    v_t_241209 = v_s_241208;
                    break;
                  }
                  default: heff_nomatch(v_x_241193);
                  }
                  V v_t_241210 = heff_tag_at_n(v_ru_24x1_241189_24MkPair, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_241184_24Right, TAG_EVar, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2eexprL_str45)}), v_t_241209});
                  V v_t_241213;
                  switch (heff_tag_of(v_x_241193)) {
                  case TAG_At: {
                    V v_s_241212 = heff_dup(heff_field(v_x_241193, 1));
                    v_t_241213 = v_s_241212;
                    break;
                  }
                  default: heff_nomatch(v_x_241193);
                  }
                  V v_t_241214 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_StmtLet, 2, (V[]){v_x_241193, v_t_241210}), v_t_241213});
                  V v_t_241215 = heff_tag_n(TAG_EWith, 4, (V[]){v_x_241187, ((V)&g_heff_2esyntax_2esurface_2eexprL_str46), v_t_241206, heff_tag_n(TAG_Cons, 2, (V[]){v_t_241214, v_x_241203})});
                  V v_t_241216 = (g_heff_2esyntax_2ecst_2elastE(v_e0_241));
                  V v_e_241217 = heff_get_n(v_t_241216, 4, 9);
                  V v_t_241218 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_241108, 3, 9), v_e_241217});
                  V v_x_241219 = heff_tag_n(TAG_At, 2, (V[]){v_t_241215, v_t_241218});
                  return heff_tag_at_n(v_ru_24x1_241183_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_241219}), v_st_241201});
                }
                default: return heff_nomatch(v_x11_241200);
                }
              }
            }
            default: return heff_nomatch(v_x11_241190);
            }
          }
          default: return heff_nomatch(v_x1_241189);
          }
        }
        default: return heff_nomatch(v_x11_241184);
        }
      }
      default: return heff_nomatch(v_x1_241183);
      }
    }
    case TAG_PList: {
      V v_m_241224 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e_241109}));
      V v_x1_241225 = heff_tr(heff_call(v_m_241224, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_241225)) {
      case TAG_MkPair: {
        V v_x11_241226 = heff_field(v_x1_241225, 0);
        V v_st_241227 = heff_field(v_x1_241225, 1);
        V v_ru_24x1_241225_24MkPair = heff_take_reuse_n(v_x1_241225, 3ULL, 2);
        switch (heff_tag_of(v_x11_241226)) {
        case TAG_Left: {
          V v_e_241228 = heff_field(v_x11_241226, 0);
          heff_take_n(v_x11_241226, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_tag(v_e0_241, 6);
          heff_drop_rec(v_kw_241108, 9);
          heff_drop_tag(v_e04_241111, 4);
          heff_drop(v_body_241113);
          return heff_tag_at_n(v_ru_24x1_241225_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241228}), v_st_241227});
        }
        case TAG_Right: {
          V v_x_241229 = heff_field(v_x11_241226, 0);
          V v_ru_24x11_241226_24Right = heff_take_reuse_n(v_x11_241226, 1ULL, 1);
          V v_m_241230 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 1)), 1, (V[]){heff_dup(v_e04_241111)}));
          V v_x1_241231 = heff_tr(heff_call(v_m_241230, 1, (V[]){v_st_241227}));
          switch (heff_tag_of(v_x1_241231)) {
          case TAG_MkPair: {
            V v_x11_241232 = heff_field(v_x1_241231, 0);
            V v_st_241233 = heff_field(v_x1_241231, 1);
            V v_ru_24x1_241231_24MkPair = heff_take_reuse_n(v_x1_241231, 3ULL, 2);
            switch (heff_tag_of(v_x11_241232)) {
            case TAG_Left: {
              V v_e_241234 = heff_field(v_x11_241232, 0);
              heff_take_n(v_x11_241232, 1ULL, 1);
              heff_drop_rec(v_r_240, 3);
              heff_drop_tag(v_e0_241, 6);
              heff_drop_rec(v_kw_241108, 9);
              heff_drop_tag(v_e04_241111, 4);
              heff_drop(v_body_241113);
              heff_drop(v_x_241229);
              heff_drop_cell(v_ru_24x11_241226_24Right, 1);
              heff_drop_cell(v_ru_24x1_241231_24MkPair, 2);
              return heff_tag_at_n(v_ru_24x1_241225_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241234}), v_st_241233});
            }
            case TAG_Right: {
              V v_x_241235 = heff_field(v_x11_241232, 0);
              heff_take_n(v_x11_241232, 1ULL, 1);
              V v_t_241236 = ({ V b_0 = NTAG(TAG_Nil); V a_1 = v_e04_241111; V r_ = (g_heff_2esyntax_2esurface_2eboundBy(b_0, a_1)); heff_drop(b_0); heff_drop_tag(v_e04_241111, 4); r_; });
              V v_t_241238 = heff_tr(heff_call(((V)&g_heff_2esyntax_2esurface_2eblock_clo), 2, (V[]){heff_clo_n(g_heff_2esyntax_2esurface_2eexprL_lam15, 1, 1, (V[]){v_r_240}), v_body_241113}));
              HeffT2 v_t_241239 = (g_heff_2esyntax_2esurface_2ewithScope_24cpr(v_t_241236, v_t_241238, v_st_241233));
              {
                V v_field_241240 = v_t_241239.f[0];
                V v_field_241241 = v_t_241239.f[1];
                V v_x11_241242 = v_field_241240;
                V v_st_241243 = v_field_241241;
                switch (heff_tag_of(v_x11_241242)) {
                case TAG_Left: {
                  V v_e_241244 = heff_field(v_x11_241242, 0);
                  heff_take_n(v_x11_241242, 1ULL, 1);
                  heff_drop_tag(v_e0_241, 6);
                  heff_drop_rec(v_kw_241108, 9);
                  heff_drop(v_x_241229);
                  heff_drop_cell(v_ru_24x11_241226_24Right, 1);
                  heff_drop_cell(v_ru_24x1_241231_24MkPair, 2);
                  heff_drop(v_x_241235);
                  return heff_tag_at_n(v_ru_24x1_241225_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241244}), v_st_241243});
                }
                case TAG_Right: {
                  V v_x_241245 = heff_field(v_x11_241242, 0);
                  heff_take_n(v_x11_241242, 1ULL, 1);
                  V v_t_241248;
                  switch (heff_tag_of(v_x_241235)) {
                  case TAG_At: {
                    V v_s_241247 = heff_dup(heff_field(v_x_241235, 1));
                    v_t_241248 = v_s_241247;
                    break;
                  }
                  default: heff_nomatch(v_x_241235);
                  }
                  V v_t_241251;
                  switch (heff_tag_of(v_x_241235)) {
                  case TAG_At: {
                    V v_s_241250 = heff_dup(heff_field(v_x_241235, 1));
                    v_t_241251 = v_s_241250;
                    break;
                  }
                  default: heff_nomatch(v_x_241235);
                  }
                  V v_t_241252 = heff_tag_at_n(v_ru_24x1_241231_24MkPair, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_241226_24Right, TAG_EVar, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2eexprL_str47)}), v_t_241251});
                  V v_t_241255;
                  switch (heff_tag_of(v_x_241235)) {
                  case TAG_At: {
                    V v_s_241254 = heff_dup(heff_field(v_x_241235, 1));
                    v_t_241255 = v_s_241254;
                    break;
                  }
                  default: heff_nomatch(v_x_241235);
                  }
                  V v_t_241256 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_StmtLet, 2, (V[]){v_x_241235, v_t_241252}), v_t_241255});
                  V v_t_241257 = heff_tag_n(TAG_EWith, 4, (V[]){v_x_241229, ((V)&g_heff_2esyntax_2esurface_2eexprL_str48), v_t_241248, heff_tag_n(TAG_Cons, 2, (V[]){v_t_241256, v_x_241245})});
                  V v_t_241258 = (g_heff_2esyntax_2ecst_2elastE(v_e0_241));
                  V v_e_241259 = heff_get_n(v_t_241258, 4, 9);
                  V v_t_241260 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_241108, 3, 9), v_e_241259});
                  V v_x_241261 = heff_tag_n(TAG_At, 2, (V[]){v_t_241257, v_t_241260});
                  return heff_tag_at_n(v_ru_24x1_241225_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_241261}), v_st_241243});
                }
                default: return heff_nomatch(v_x11_241242);
                }
              }
            }
            default: return heff_nomatch(v_x11_241232);
            }
          }
          default: return heff_nomatch(v_x1_241231);
          }
        }
        default: return heff_nomatch(v_x11_241226);
        }
      }
      default: return heff_nomatch(v_x1_241225);
      }
    }
    case TAG_POp: {
      V v_m_241265 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e_241109}));
      V v_x1_241266 = heff_tr(heff_call(v_m_241265, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_241266)) {
      case TAG_MkPair: {
        V v_x11_241267 = heff_field(v_x1_241266, 0);
        V v_st_241268 = heff_field(v_x1_241266, 1);
        V v_ru_24x1_241266_24MkPair = heff_take_reuse_n(v_x1_241266, 3ULL, 2);
        switch (heff_tag_of(v_x11_241267)) {
        case TAG_Left: {
          V v_e_241269 = heff_field(v_x11_241267, 0);
          heff_take_n(v_x11_241267, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_tag(v_e0_241, 6);
          heff_drop_rec(v_kw_241108, 9);
          heff_drop_tag(v_e04_241111, 3);
          heff_drop(v_body_241113);
          return heff_tag_at_n(v_ru_24x1_241266_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241269}), v_st_241268});
        }
        case TAG_Right: {
          V v_x_241270 = heff_field(v_x11_241267, 0);
          V v_ru_24x11_241267_24Right = heff_take_reuse_n(v_x11_241267, 1ULL, 1);
          V v_m_241271 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 1)), 1, (V[]){heff_dup(v_e04_241111)}));
          V v_x1_241272 = heff_tr(heff_call(v_m_241271, 1, (V[]){v_st_241268}));
          switch (heff_tag_of(v_x1_241272)) {
          case TAG_MkPair: {
            V v_x11_241273 = heff_field(v_x1_241272, 0);
            V v_st_241274 = heff_field(v_x1_241272, 1);
            V v_ru_24x1_241272_24MkPair = heff_take_reuse_n(v_x1_241272, 3ULL, 2);
            switch (heff_tag_of(v_x11_241273)) {
            case TAG_Left: {
              V v_e_241275 = heff_field(v_x11_241273, 0);
              heff_take_n(v_x11_241273, 1ULL, 1);
              heff_drop_rec(v_r_240, 3);
              heff_drop_tag(v_e0_241, 6);
              heff_drop_rec(v_kw_241108, 9);
              heff_drop_tag(v_e04_241111, 3);
              heff_drop(v_body_241113);
              heff_drop(v_x_241270);
              heff_drop_cell(v_ru_24x11_241267_24Right, 1);
              heff_drop_cell(v_ru_24x1_241272_24MkPair, 2);
              return heff_tag_at_n(v_ru_24x1_241266_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241275}), v_st_241274});
            }
            case TAG_Right: {
              V v_x_241276 = heff_field(v_x11_241273, 0);
              heff_take_n(v_x11_241273, 1ULL, 1);
              V v_t_241277 = ({ V b_0 = NTAG(TAG_Nil); V a_1 = v_e04_241111; V r_ = (g_heff_2esyntax_2esurface_2eboundBy(b_0, a_1)); heff_drop(b_0); heff_drop_tag(v_e04_241111, 3); r_; });
              V v_t_241279 = heff_tr(heff_call(((V)&g_heff_2esyntax_2esurface_2eblock_clo), 2, (V[]){heff_clo_n(g_heff_2esyntax_2esurface_2eexprL_lam16, 1, 1, (V[]){v_r_240}), v_body_241113}));
              HeffT2 v_t_241280 = (g_heff_2esyntax_2esurface_2ewithScope_24cpr(v_t_241277, v_t_241279, v_st_241274));
              {
                V v_field_241281 = v_t_241280.f[0];
                V v_field_241282 = v_t_241280.f[1];
                V v_x11_241283 = v_field_241281;
                V v_st_241284 = v_field_241282;
                switch (heff_tag_of(v_x11_241283)) {
                case TAG_Left: {
                  V v_e_241285 = heff_field(v_x11_241283, 0);
                  heff_take_n(v_x11_241283, 1ULL, 1);
                  heff_drop_tag(v_e0_241, 6);
                  heff_drop_rec(v_kw_241108, 9);
                  heff_drop(v_x_241270);
                  heff_drop_cell(v_ru_24x11_241267_24Right, 1);
                  heff_drop_cell(v_ru_24x1_241272_24MkPair, 2);
                  heff_drop(v_x_241276);
                  return heff_tag_at_n(v_ru_24x1_241266_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241285}), v_st_241284});
                }
                case TAG_Right: {
                  V v_x_241286 = heff_field(v_x11_241283, 0);
                  heff_take_n(v_x11_241283, 1ULL, 1);
                  V v_t_241289;
                  switch (heff_tag_of(v_x_241276)) {
                  case TAG_At: {
                    V v_s_241288 = heff_dup(heff_field(v_x_241276, 1));
                    v_t_241289 = v_s_241288;
                    break;
                  }
                  default: heff_nomatch(v_x_241276);
                  }
                  V v_t_241292;
                  switch (heff_tag_of(v_x_241276)) {
                  case TAG_At: {
                    V v_s_241291 = heff_dup(heff_field(v_x_241276, 1));
                    v_t_241292 = v_s_241291;
                    break;
                  }
                  default: heff_nomatch(v_x_241276);
                  }
                  V v_t_241293 = heff_tag_at_n(v_ru_24x1_241272_24MkPair, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_241267_24Right, TAG_EVar, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2eexprL_str49)}), v_t_241292});
                  V v_t_241296;
                  switch (heff_tag_of(v_x_241276)) {
                  case TAG_At: {
                    V v_s_241295 = heff_dup(heff_field(v_x_241276, 1));
                    v_t_241296 = v_s_241295;
                    break;
                  }
                  default: heff_nomatch(v_x_241276);
                  }
                  V v_t_241297 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_StmtLet, 2, (V[]){v_x_241276, v_t_241293}), v_t_241296});
                  V v_t_241298 = heff_tag_n(TAG_EWith, 4, (V[]){v_x_241270, ((V)&g_heff_2esyntax_2esurface_2eexprL_str50), v_t_241289, heff_tag_n(TAG_Cons, 2, (V[]){v_t_241297, v_x_241286})});
                  V v_t_241299 = (g_heff_2esyntax_2ecst_2elastE(v_e0_241));
                  V v_e_241300 = heff_get_n(v_t_241299, 4, 9);
                  V v_t_241301 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_241108, 3, 9), v_e_241300});
                  V v_x_241302 = heff_tag_n(TAG_At, 2, (V[]){v_t_241298, v_t_241301});
                  return heff_tag_at_n(v_ru_24x1_241266_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_241302}), v_st_241284});
                }
                default: return heff_nomatch(v_x11_241283);
                }
              }
            }
            default: return heff_nomatch(v_x11_241273);
            }
          }
          default: return heff_nomatch(v_x1_241272);
          }
        }
        default: return heff_nomatch(v_x11_241267);
        }
      }
      default: return heff_nomatch(v_x1_241266);
      }
    }
    case TAG_PRec: {
      V v_m_241307 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e_241109}));
      V v_x1_241308 = heff_tr(heff_call(v_m_241307, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_241308)) {
      case TAG_MkPair: {
        V v_x11_241309 = heff_field(v_x1_241308, 0);
        V v_st_241310 = heff_field(v_x1_241308, 1);
        V v_ru_24x1_241308_24MkPair = heff_take_reuse_n(v_x1_241308, 3ULL, 2);
        switch (heff_tag_of(v_x11_241309)) {
        case TAG_Left: {
          V v_e_241311 = heff_field(v_x11_241309, 0);
          heff_take_n(v_x11_241309, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_tag(v_e0_241, 6);
          heff_drop_rec(v_kw_241108, 9);
          heff_drop_tag(v_e04_241111, 4);
          heff_drop(v_body_241113);
          return heff_tag_at_n(v_ru_24x1_241308_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241311}), v_st_241310});
        }
        case TAG_Right: {
          V v_x_241312 = heff_field(v_x11_241309, 0);
          V v_ru_24x11_241309_24Right = heff_take_reuse_n(v_x11_241309, 1ULL, 1);
          V v_m_241313 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 1)), 1, (V[]){heff_dup(v_e04_241111)}));
          V v_x1_241314 = heff_tr(heff_call(v_m_241313, 1, (V[]){v_st_241310}));
          switch (heff_tag_of(v_x1_241314)) {
          case TAG_MkPair: {
            V v_x11_241315 = heff_field(v_x1_241314, 0);
            V v_st_241316 = heff_field(v_x1_241314, 1);
            V v_ru_24x1_241314_24MkPair = heff_take_reuse_n(v_x1_241314, 3ULL, 2);
            switch (heff_tag_of(v_x11_241315)) {
            case TAG_Left: {
              V v_e_241317 = heff_field(v_x11_241315, 0);
              heff_take_n(v_x11_241315, 1ULL, 1);
              heff_drop_rec(v_r_240, 3);
              heff_drop_tag(v_e0_241, 6);
              heff_drop_rec(v_kw_241108, 9);
              heff_drop_tag(v_e04_241111, 4);
              heff_drop(v_body_241113);
              heff_drop(v_x_241312);
              heff_drop_cell(v_ru_24x11_241309_24Right, 1);
              heff_drop_cell(v_ru_24x1_241314_24MkPair, 2);
              return heff_tag_at_n(v_ru_24x1_241308_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241317}), v_st_241316});
            }
            case TAG_Right: {
              V v_x_241318 = heff_field(v_x11_241315, 0);
              heff_take_n(v_x11_241315, 1ULL, 1);
              V v_t_241319 = ({ V b_0 = NTAG(TAG_Nil); V a_1 = v_e04_241111; V r_ = (g_heff_2esyntax_2esurface_2eboundBy(b_0, a_1)); heff_drop(b_0); heff_drop_tag(v_e04_241111, 4); r_; });
              V v_t_241321 = heff_tr(heff_call(((V)&g_heff_2esyntax_2esurface_2eblock_clo), 2, (V[]){heff_clo_n(g_heff_2esyntax_2esurface_2eexprL_lam17, 1, 1, (V[]){v_r_240}), v_body_241113}));
              HeffT2 v_t_241322 = (g_heff_2esyntax_2esurface_2ewithScope_24cpr(v_t_241319, v_t_241321, v_st_241316));
              {
                V v_field_241323 = v_t_241322.f[0];
                V v_field_241324 = v_t_241322.f[1];
                V v_x11_241325 = v_field_241323;
                V v_st_241326 = v_field_241324;
                switch (heff_tag_of(v_x11_241325)) {
                case TAG_Left: {
                  V v_e_241327 = heff_field(v_x11_241325, 0);
                  heff_take_n(v_x11_241325, 1ULL, 1);
                  heff_drop_tag(v_e0_241, 6);
                  heff_drop_rec(v_kw_241108, 9);
                  heff_drop(v_x_241312);
                  heff_drop_cell(v_ru_24x11_241309_24Right, 1);
                  heff_drop_cell(v_ru_24x1_241314_24MkPair, 2);
                  heff_drop(v_x_241318);
                  return heff_tag_at_n(v_ru_24x1_241308_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241327}), v_st_241326});
                }
                case TAG_Right: {
                  V v_x_241328 = heff_field(v_x11_241325, 0);
                  heff_take_n(v_x11_241325, 1ULL, 1);
                  V v_t_241331;
                  switch (heff_tag_of(v_x_241318)) {
                  case TAG_At: {
                    V v_s_241330 = heff_dup(heff_field(v_x_241318, 1));
                    v_t_241331 = v_s_241330;
                    break;
                  }
                  default: heff_nomatch(v_x_241318);
                  }
                  V v_t_241334;
                  switch (heff_tag_of(v_x_241318)) {
                  case TAG_At: {
                    V v_s_241333 = heff_dup(heff_field(v_x_241318, 1));
                    v_t_241334 = v_s_241333;
                    break;
                  }
                  default: heff_nomatch(v_x_241318);
                  }
                  V v_t_241335 = heff_tag_at_n(v_ru_24x1_241314_24MkPair, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_241309_24Right, TAG_EVar, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2eexprL_str51)}), v_t_241334});
                  V v_t_241338;
                  switch (heff_tag_of(v_x_241318)) {
                  case TAG_At: {
                    V v_s_241337 = heff_dup(heff_field(v_x_241318, 1));
                    v_t_241338 = v_s_241337;
                    break;
                  }
                  default: heff_nomatch(v_x_241318);
                  }
                  V v_t_241339 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_StmtLet, 2, (V[]){v_x_241318, v_t_241335}), v_t_241338});
                  V v_t_241340 = heff_tag_n(TAG_EWith, 4, (V[]){v_x_241312, ((V)&g_heff_2esyntax_2esurface_2eexprL_str52), v_t_241331, heff_tag_n(TAG_Cons, 2, (V[]){v_t_241339, v_x_241328})});
                  V v_t_241341 = (g_heff_2esyntax_2ecst_2elastE(v_e0_241));
                  V v_e_241342 = heff_get_n(v_t_241341, 4, 9);
                  V v_t_241343 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_241108, 3, 9), v_e_241342});
                  V v_x_241344 = heff_tag_n(TAG_At, 2, (V[]){v_t_241340, v_t_241343});
                  return heff_tag_at_n(v_ru_24x1_241308_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_241344}), v_st_241326});
                }
                default: return heff_nomatch(v_x11_241325);
                }
              }
            }
            default: return heff_nomatch(v_x11_241315);
            }
          }
          default: return heff_nomatch(v_x1_241314);
          }
        }
        default: return heff_nomatch(v_x11_241309);
        }
      }
      default: return heff_nomatch(v_x1_241308);
      }
    }
    case TAG_PField: {
      V v_m_241348 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e_241109}));
      V v_x1_241349 = heff_tr(heff_call(v_m_241348, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_241349)) {
      case TAG_MkPair: {
        V v_x11_241350 = heff_field(v_x1_241349, 0);
        V v_st_241351 = heff_field(v_x1_241349, 1);
        V v_ru_24x1_241349_24MkPair = heff_take_reuse_n(v_x1_241349, 3ULL, 2);
        switch (heff_tag_of(v_x11_241350)) {
        case TAG_Left: {
          V v_e_241352 = heff_field(v_x11_241350, 0);
          heff_take_n(v_x11_241350, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_tag(v_e0_241, 6);
          heff_drop_rec(v_kw_241108, 9);
          heff_drop_tag(v_e04_241111, 3);
          heff_drop(v_body_241113);
          return heff_tag_at_n(v_ru_24x1_241349_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241352}), v_st_241351});
        }
        case TAG_Right: {
          V v_x_241353 = heff_field(v_x11_241350, 0);
          V v_ru_24x11_241350_24Right = heff_take_reuse_n(v_x11_241350, 1ULL, 1);
          V v_m_241354 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 1)), 1, (V[]){heff_dup(v_e04_241111)}));
          V v_x1_241355 = heff_tr(heff_call(v_m_241354, 1, (V[]){v_st_241351}));
          switch (heff_tag_of(v_x1_241355)) {
          case TAG_MkPair: {
            V v_x11_241356 = heff_field(v_x1_241355, 0);
            V v_st_241357 = heff_field(v_x1_241355, 1);
            V v_ru_24x1_241355_24MkPair = heff_take_reuse_n(v_x1_241355, 3ULL, 2);
            switch (heff_tag_of(v_x11_241356)) {
            case TAG_Left: {
              V v_e_241358 = heff_field(v_x11_241356, 0);
              heff_take_n(v_x11_241356, 1ULL, 1);
              heff_drop_rec(v_r_240, 3);
              heff_drop_tag(v_e0_241, 6);
              heff_drop_rec(v_kw_241108, 9);
              heff_drop_tag(v_e04_241111, 3);
              heff_drop(v_body_241113);
              heff_drop(v_x_241353);
              heff_drop_cell(v_ru_24x11_241350_24Right, 1);
              heff_drop_cell(v_ru_24x1_241355_24MkPair, 2);
              return heff_tag_at_n(v_ru_24x1_241349_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241358}), v_st_241357});
            }
            case TAG_Right: {
              V v_x_241359 = heff_field(v_x11_241356, 0);
              heff_take_n(v_x11_241356, 1ULL, 1);
              V v_t_241360 = ({ V b_0 = NTAG(TAG_Nil); V a_1 = v_e04_241111; V r_ = (g_heff_2esyntax_2esurface_2eboundBy(b_0, a_1)); heff_drop(b_0); heff_drop_tag(v_e04_241111, 3); r_; });
              V v_t_241362 = heff_tr(heff_call(((V)&g_heff_2esyntax_2esurface_2eblock_clo), 2, (V[]){heff_clo_n(g_heff_2esyntax_2esurface_2eexprL_lam18, 1, 1, (V[]){v_r_240}), v_body_241113}));
              HeffT2 v_t_241363 = (g_heff_2esyntax_2esurface_2ewithScope_24cpr(v_t_241360, v_t_241362, v_st_241357));
              {
                V v_field_241364 = v_t_241363.f[0];
                V v_field_241365 = v_t_241363.f[1];
                V v_x11_241366 = v_field_241364;
                V v_st_241367 = v_field_241365;
                switch (heff_tag_of(v_x11_241366)) {
                case TAG_Left: {
                  V v_e_241368 = heff_field(v_x11_241366, 0);
                  heff_take_n(v_x11_241366, 1ULL, 1);
                  heff_drop_tag(v_e0_241, 6);
                  heff_drop_rec(v_kw_241108, 9);
                  heff_drop(v_x_241353);
                  heff_drop_cell(v_ru_24x11_241350_24Right, 1);
                  heff_drop_cell(v_ru_24x1_241355_24MkPair, 2);
                  heff_drop(v_x_241359);
                  return heff_tag_at_n(v_ru_24x1_241349_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241368}), v_st_241367});
                }
                case TAG_Right: {
                  V v_x_241369 = heff_field(v_x11_241366, 0);
                  heff_take_n(v_x11_241366, 1ULL, 1);
                  V v_t_241372;
                  switch (heff_tag_of(v_x_241359)) {
                  case TAG_At: {
                    V v_s_241371 = heff_dup(heff_field(v_x_241359, 1));
                    v_t_241372 = v_s_241371;
                    break;
                  }
                  default: heff_nomatch(v_x_241359);
                  }
                  V v_t_241375;
                  switch (heff_tag_of(v_x_241359)) {
                  case TAG_At: {
                    V v_s_241374 = heff_dup(heff_field(v_x_241359, 1));
                    v_t_241375 = v_s_241374;
                    break;
                  }
                  default: heff_nomatch(v_x_241359);
                  }
                  V v_t_241376 = heff_tag_at_n(v_ru_24x1_241355_24MkPair, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_241350_24Right, TAG_EVar, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2eexprL_str53)}), v_t_241375});
                  V v_t_241379;
                  switch (heff_tag_of(v_x_241359)) {
                  case TAG_At: {
                    V v_s_241378 = heff_dup(heff_field(v_x_241359, 1));
                    v_t_241379 = v_s_241378;
                    break;
                  }
                  default: heff_nomatch(v_x_241359);
                  }
                  V v_t_241380 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_StmtLet, 2, (V[]){v_x_241359, v_t_241376}), v_t_241379});
                  V v_t_241381 = heff_tag_n(TAG_EWith, 4, (V[]){v_x_241353, ((V)&g_heff_2esyntax_2esurface_2eexprL_str54), v_t_241372, heff_tag_n(TAG_Cons, 2, (V[]){v_t_241380, v_x_241369})});
                  V v_t_241382 = (g_heff_2esyntax_2ecst_2elastE(v_e0_241));
                  V v_e_241383 = heff_get_n(v_t_241382, 4, 9);
                  V v_t_241384 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_241108, 3, 9), v_e_241383});
                  V v_x_241385 = heff_tag_n(TAG_At, 2, (V[]){v_t_241381, v_t_241384});
                  return heff_tag_at_n(v_ru_24x1_241349_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_241385}), v_st_241367});
                }
                default: return heff_nomatch(v_x11_241366);
                }
              }
            }
            default: return heff_nomatch(v_x11_241356);
            }
          }
          default: return heff_nomatch(v_x1_241355);
          }
        }
        default: return heff_nomatch(v_x11_241350);
        }
      }
      default: return heff_nomatch(v_x1_241349);
      }
    }
    case TAG_PAs: {
      V v_m_241389 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e_241109}));
      V v_x1_241390 = heff_tr(heff_call(v_m_241389, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_241390)) {
      case TAG_MkPair: {
        V v_x11_241391 = heff_field(v_x1_241390, 0);
        V v_st_241392 = heff_field(v_x1_241390, 1);
        V v_ru_24x1_241390_24MkPair = heff_take_reuse_n(v_x1_241390, 3ULL, 2);
        switch (heff_tag_of(v_x11_241391)) {
        case TAG_Left: {
          V v_e_241393 = heff_field(v_x11_241391, 0);
          heff_take_n(v_x11_241391, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_tag(v_e0_241, 6);
          heff_drop_rec(v_kw_241108, 9);
          heff_drop_tag(v_e04_241111, 3);
          heff_drop(v_body_241113);
          return heff_tag_at_n(v_ru_24x1_241390_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241393}), v_st_241392});
        }
        case TAG_Right: {
          V v_x_241394 = heff_field(v_x11_241391, 0);
          V v_ru_24x11_241391_24Right = heff_take_reuse_n(v_x11_241391, 1ULL, 1);
          V v_m_241395 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 1)), 1, (V[]){heff_dup(v_e04_241111)}));
          V v_x1_241396 = heff_tr(heff_call(v_m_241395, 1, (V[]){v_st_241392}));
          switch (heff_tag_of(v_x1_241396)) {
          case TAG_MkPair: {
            V v_x11_241397 = heff_field(v_x1_241396, 0);
            V v_st_241398 = heff_field(v_x1_241396, 1);
            V v_ru_24x1_241396_24MkPair = heff_take_reuse_n(v_x1_241396, 3ULL, 2);
            switch (heff_tag_of(v_x11_241397)) {
            case TAG_Left: {
              V v_e_241399 = heff_field(v_x11_241397, 0);
              heff_take_n(v_x11_241397, 1ULL, 1);
              heff_drop_rec(v_r_240, 3);
              heff_drop_tag(v_e0_241, 6);
              heff_drop_rec(v_kw_241108, 9);
              heff_drop_tag(v_e04_241111, 3);
              heff_drop(v_body_241113);
              heff_drop(v_x_241394);
              heff_drop_cell(v_ru_24x11_241391_24Right, 1);
              heff_drop_cell(v_ru_24x1_241396_24MkPair, 2);
              return heff_tag_at_n(v_ru_24x1_241390_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241399}), v_st_241398});
            }
            case TAG_Right: {
              V v_x_241400 = heff_field(v_x11_241397, 0);
              heff_take_n(v_x11_241397, 1ULL, 1);
              V v_t_241401 = ({ V b_0 = NTAG(TAG_Nil); V a_1 = v_e04_241111; V r_ = (g_heff_2esyntax_2esurface_2eboundBy(b_0, a_1)); heff_drop(b_0); heff_drop_tag(v_e04_241111, 3); r_; });
              V v_t_241403 = heff_tr(heff_call(((V)&g_heff_2esyntax_2esurface_2eblock_clo), 2, (V[]){heff_clo_n(g_heff_2esyntax_2esurface_2eexprL_lam19, 1, 1, (V[]){v_r_240}), v_body_241113}));
              HeffT2 v_t_241404 = (g_heff_2esyntax_2esurface_2ewithScope_24cpr(v_t_241401, v_t_241403, v_st_241398));
              {
                V v_field_241405 = v_t_241404.f[0];
                V v_field_241406 = v_t_241404.f[1];
                V v_x11_241407 = v_field_241405;
                V v_st_241408 = v_field_241406;
                switch (heff_tag_of(v_x11_241407)) {
                case TAG_Left: {
                  V v_e_241409 = heff_field(v_x11_241407, 0);
                  heff_take_n(v_x11_241407, 1ULL, 1);
                  heff_drop_tag(v_e0_241, 6);
                  heff_drop_rec(v_kw_241108, 9);
                  heff_drop(v_x_241394);
                  heff_drop_cell(v_ru_24x11_241391_24Right, 1);
                  heff_drop_cell(v_ru_24x1_241396_24MkPair, 2);
                  heff_drop(v_x_241400);
                  return heff_tag_at_n(v_ru_24x1_241390_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241409}), v_st_241408});
                }
                case TAG_Right: {
                  V v_x_241410 = heff_field(v_x11_241407, 0);
                  heff_take_n(v_x11_241407, 1ULL, 1);
                  V v_t_241413;
                  switch (heff_tag_of(v_x_241400)) {
                  case TAG_At: {
                    V v_s_241412 = heff_dup(heff_field(v_x_241400, 1));
                    v_t_241413 = v_s_241412;
                    break;
                  }
                  default: heff_nomatch(v_x_241400);
                  }
                  V v_t_241416;
                  switch (heff_tag_of(v_x_241400)) {
                  case TAG_At: {
                    V v_s_241415 = heff_dup(heff_field(v_x_241400, 1));
                    v_t_241416 = v_s_241415;
                    break;
                  }
                  default: heff_nomatch(v_x_241400);
                  }
                  V v_t_241417 = heff_tag_at_n(v_ru_24x1_241396_24MkPair, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_241391_24Right, TAG_EVar, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2eexprL_str55)}), v_t_241416});
                  V v_t_241420;
                  switch (heff_tag_of(v_x_241400)) {
                  case TAG_At: {
                    V v_s_241419 = heff_dup(heff_field(v_x_241400, 1));
                    v_t_241420 = v_s_241419;
                    break;
                  }
                  default: heff_nomatch(v_x_241400);
                  }
                  V v_t_241421 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_StmtLet, 2, (V[]){v_x_241400, v_t_241417}), v_t_241420});
                  V v_t_241422 = heff_tag_n(TAG_EWith, 4, (V[]){v_x_241394, ((V)&g_heff_2esyntax_2esurface_2eexprL_str56), v_t_241413, heff_tag_n(TAG_Cons, 2, (V[]){v_t_241421, v_x_241410})});
                  V v_t_241423 = (g_heff_2esyntax_2ecst_2elastE(v_e0_241));
                  V v_e_241424 = heff_get_n(v_t_241423, 4, 9);
                  V v_t_241425 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_241108, 3, 9), v_e_241424});
                  V v_x_241426 = heff_tag_n(TAG_At, 2, (V[]){v_t_241422, v_t_241425});
                  return heff_tag_at_n(v_ru_24x1_241390_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_241426}), v_st_241408});
                }
                default: return heff_nomatch(v_x11_241407);
                }
              }
            }
            default: return heff_nomatch(v_x11_241397);
            }
          }
          default: return heff_nomatch(v_x1_241396);
          }
        }
        default: return heff_nomatch(v_x11_241391);
        }
      }
      default: return heff_nomatch(v_x1_241390);
      }
    }
    case TAG_PSeg: {
      V v_m_241430 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e_241109}));
      V v_x1_241431 = heff_tr(heff_call(v_m_241430, 1, (V[]){v_z_242}));
      switch (heff_tag_of(v_x1_241431)) {
      case TAG_MkPair: {
        V v_x11_241432 = heff_field(v_x1_241431, 0);
        V v_st_241433 = heff_field(v_x1_241431, 1);
        V v_ru_24x1_241431_24MkPair = heff_take_reuse_n(v_x1_241431, 3ULL, 2);
        switch (heff_tag_of(v_x11_241432)) {
        case TAG_Left: {
          V v_e_241434 = heff_field(v_x11_241432, 0);
          heff_take_n(v_x11_241432, 1ULL, 1);
          heff_drop_rec(v_r_240, 3);
          heff_drop_tag(v_e0_241, 6);
          heff_drop_rec(v_kw_241108, 9);
          heff_drop_tag(v_e04_241111, 3);
          heff_drop(v_body_241113);
          return heff_tag_at_n(v_ru_24x1_241431_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241434}), v_st_241433});
        }
        case TAG_Right: {
          V v_x_241435 = heff_field(v_x11_241432, 0);
          V v_ru_24x11_241432_24Right = heff_take_reuse_n(v_x11_241432, 1ULL, 1);
          V v_m_241436 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 1)), 1, (V[]){heff_dup(v_e04_241111)}));
          V v_x1_241437 = heff_tr(heff_call(v_m_241436, 1, (V[]){v_st_241433}));
          switch (heff_tag_of(v_x1_241437)) {
          case TAG_MkPair: {
            V v_x11_241438 = heff_field(v_x1_241437, 0);
            V v_st_241439 = heff_field(v_x1_241437, 1);
            V v_ru_24x1_241437_24MkPair = heff_take_reuse_n(v_x1_241437, 3ULL, 2);
            switch (heff_tag_of(v_x11_241438)) {
            case TAG_Left: {
              V v_e_241440 = heff_field(v_x11_241438, 0);
              heff_take_n(v_x11_241438, 1ULL, 1);
              heff_drop_rec(v_r_240, 3);
              heff_drop_tag(v_e0_241, 6);
              heff_drop_rec(v_kw_241108, 9);
              heff_drop_tag(v_e04_241111, 3);
              heff_drop(v_body_241113);
              heff_drop(v_x_241435);
              heff_drop_cell(v_ru_24x11_241432_24Right, 1);
              heff_drop_cell(v_ru_24x1_241437_24MkPair, 2);
              return heff_tag_at_n(v_ru_24x1_241431_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241440}), v_st_241439});
            }
            case TAG_Right: {
              V v_x_241441 = heff_field(v_x11_241438, 0);
              heff_take_n(v_x11_241438, 1ULL, 1);
              V v_t_241442 = ({ V b_0 = NTAG(TAG_Nil); V a_1 = v_e04_241111; V r_ = (g_heff_2esyntax_2esurface_2eboundBy(b_0, a_1)); heff_drop(b_0); heff_drop_tag(v_e04_241111, 3); r_; });
              V v_t_241444 = heff_tr(heff_call(((V)&g_heff_2esyntax_2esurface_2eblock_clo), 2, (V[]){heff_clo_n(g_heff_2esyntax_2esurface_2eexprL_lam20, 1, 1, (V[]){v_r_240}), v_body_241113}));
              HeffT2 v_t_241445 = (g_heff_2esyntax_2esurface_2ewithScope_24cpr(v_t_241442, v_t_241444, v_st_241439));
              {
                V v_field_241446 = v_t_241445.f[0];
                V v_field_241447 = v_t_241445.f[1];
                V v_x11_241448 = v_field_241446;
                V v_st_241449 = v_field_241447;
                switch (heff_tag_of(v_x11_241448)) {
                case TAG_Left: {
                  V v_e_241450 = heff_field(v_x11_241448, 0);
                  heff_take_n(v_x11_241448, 1ULL, 1);
                  heff_drop_tag(v_e0_241, 6);
                  heff_drop_rec(v_kw_241108, 9);
                  heff_drop(v_x_241435);
                  heff_drop_cell(v_ru_24x11_241432_24Right, 1);
                  heff_drop_cell(v_ru_24x1_241437_24MkPair, 2);
                  heff_drop(v_x_241441);
                  return heff_tag_at_n(v_ru_24x1_241431_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_241450}), v_st_241449});
                }
                case TAG_Right: {
                  V v_x_241451 = heff_field(v_x11_241448, 0);
                  heff_take_n(v_x11_241448, 1ULL, 1);
                  V v_t_241454;
                  switch (heff_tag_of(v_x_241441)) {
                  case TAG_At: {
                    V v_s_241453 = heff_dup(heff_field(v_x_241441, 1));
                    v_t_241454 = v_s_241453;
                    break;
                  }
                  default: heff_nomatch(v_x_241441);
                  }
                  V v_t_241457;
                  switch (heff_tag_of(v_x_241441)) {
                  case TAG_At: {
                    V v_s_241456 = heff_dup(heff_field(v_x_241441, 1));
                    v_t_241457 = v_s_241456;
                    break;
                  }
                  default: heff_nomatch(v_x_241441);
                  }
                  V v_t_241458 = heff_tag_at_n(v_ru_24x1_241437_24MkPair, TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24x11_241432_24Right, TAG_EVar, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2eexprL_str57)}), v_t_241457});
                  V v_t_241461;
                  switch (heff_tag_of(v_x_241441)) {
                  case TAG_At: {
                    V v_s_241460 = heff_dup(heff_field(v_x_241441, 1));
                    v_t_241461 = v_s_241460;
                    break;
                  }
                  default: heff_nomatch(v_x_241441);
                  }
                  V v_t_241462 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_StmtLet, 2, (V[]){v_x_241441, v_t_241458}), v_t_241461});
                  V v_t_241463 = heff_tag_n(TAG_EWith, 4, (V[]){v_x_241435, ((V)&g_heff_2esyntax_2esurface_2eexprL_str58), v_t_241454, heff_tag_n(TAG_Cons, 2, (V[]){v_t_241462, v_x_241451})});
                  V v_t_241464 = (g_heff_2esyntax_2ecst_2elastE(v_e0_241));
                  V v_e_241465 = heff_get_n(v_t_241464, 4, 9);
                  V v_t_241466 = heff_rec_n(2, shape_start__end, (V[]){heff_get_n(v_kw_241108, 3, 9), v_e_241465});
                  V v_x_241467 = heff_tag_n(TAG_At, 2, (V[]){v_t_241463, v_t_241466});
                  return heff_tag_at_n(v_ru_24x1_241431_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Right, 1, (V[]){v_x_241467}), v_st_241449});
                }
                default: return heff_nomatch(v_x11_241448);
                }
              }
            }
            default: return heff_nomatch(v_x11_241438);
            }
          }
          default: return heff_nomatch(v_x1_241437);
          }
        }
        default: return heff_nomatch(v_x11_241432);
        }
      }
      default: return heff_nomatch(v_x1_241431);
      }
    }
    default: return heff_nomatch(v_e04_241111);
    }
  }
  default: return heff_nomatch(v_e0_241);
  }
}
V g_heff_2esyntax_2esurface_2eexprL_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2eexprL(a[0], a[1], a[2]);
}
V g_heff_2esyntax_2esurface_2eexprL_lam0(V self, V *args) {
  V v_m_2430 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2esyntax_2esurface_2esegmentL(v_r_240, v_m_2430));
}
V g_heff_2esyntax_2esurface_2eexprL_lam1(V self, V *args) {
  V v_x_2447 = args[0];
  V v_rest_2448 = args[1];
  V v_sp_2445 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2449 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ETag, 1, (V[]){((V)&g_heff_2esyntax_2esurface_2eexprL_str8)}), v_sp_2445});
  V v_t_2450 = heff_tag_n(TAG_Cons, 2, (V[]){v_rest_2448, NTAG(TAG_Nil)});
  return (g_heff_2esyntax_2epresyntax_2eapp(v_t_2449, heff_tag_n(TAG_Cons, 2, (V[]){v_x_2447, v_t_2450})));
}
V g_heff_2esyntax_2esurface_2eexprL_lam2(V self, V *args) {
  V v_m_2486 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2esyntax_2esurface_2eupdateSettingL(v_r_240, v_m_2486));
}
V g_heff_2esyntax_2esurface_2eexprL_lam3(V self, V *args) {
  V v_a_24143 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2esyntax_2esurface_2evariantL(v_r_240, v_a_24143));
}
V g_heff_2esyntax_2esurface_2eexprL_lam4(V self, V *args) {
  V v_m_24706 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2esyntax_2esurface_2eargL(v_r_240, v_m_24706));
}
V g_heff_2esyntax_2esurface_2eexprL_lam6(V self, V *args) {
  V v_st_24732 = args[0];
  V v_m_24731 = heff_env(self)[0];
  V v_op_24729 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x1_24733 = heff_tr(heff_call(v_m_24731, 1, (V[]){v_st_24732}));
  switch (heff_tag_of(v_x1_24733)) {
  case TAG_MkPair: {
    V v_x11_24734 = heff_field(v_x1_24733, 0);
    V v_st_24735 = heff_field(v_x1_24733, 1);
    V v_ru_24x1_24733_24MkPair = heff_take_reuse_n(v_x1_24733, 3ULL, 2);
    switch (heff_tag_of(v_x11_24734)) {
    case TAG_Left: {
      V v_e_24736 = heff_field(v_x11_24734, 0);
      heff_take_n(v_x11_24734, 1ULL, 1);
      heff_drop(v_op_24729);
      return heff_tag_at_n(v_ru_24x1_24733_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_24736}), v_st_24735});
    }
    case TAG_Right: {
      V v_x_24737 = heff_field(v_x11_24734, 0);
      V v_ru_24x11_24734_24Right = heff_take_reuse_n(v_x11_24734, 1ULL, 1);
      V v_t_24738 = heff_tag_at_n(v_ru_24x11_24734_24Right, TAG_Right, 1, (V[]){heff_rec_n(2, shape_op__e, (V[]){v_op_24729, v_x_24737})});
      return heff_tag_at_n(v_ru_24x1_24733_24MkPair, TAG_MkPair, 2, (V[]){v_t_24738, v_st_24735});
    }
    default: return heff_nomatch(v_x11_24734);
    }
  }
  default: return heff_nomatch(v_x1_24733);
  }
}
V g_heff_2esyntax_2esurface_2eexprL_lam5(V self, V *args) {
  V v_m_24725 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_24726 = (g_heff_2esyntax_2esurface_2eopRhsOf_24cpr(v_m_24725));
  {
    V v_field_24727 = v_t_24726.f[0];
    V v_field_24728 = v_t_24726.f[1];
    V v_op_24729 = v_field_24727;
    V v_e_24730 = v_field_24728;
    V v_m_24731 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_e_24730}));
    return heff_clo_n(g_heff_2esyntax_2esurface_2eexprL_lam6, 1, 2, (V[]){v_m_24731, v_op_24729});
  }
}
V g_heff_2esyntax_2esurface_2eexprL_lam7(V self, V *args) {
  V v_a_24829 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2esyntax_2esurface_2ealtL(v_r_240, v_a_24829));
}
V g_heff_2esyntax_2esurface_2eexprL_lam8(V self, V *args) {
  V v_m_24881 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2esyntax_2esurface_2estmtL(v_r_240, v_m_24881));
}
V g_heff_2esyntax_2esurface_2eexprL_lam9(V self, V *args) {
  V v_m_24962 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2esyntax_2esurface_2estmtL(v_r_240, v_m_24962));
}
V g_heff_2esyntax_2esurface_2eexprL_lam10(V self, V *args) {
  V v_m_24993 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2esyntax_2esurface_2estmtL(v_r_240, v_m_24993));
}
V g_heff_2esyntax_2esurface_2eexprL_lam11(V self, V *args) {
  V v_m_241078 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2esyntax_2esurface_2estmtL(v_r_240, v_m_241078));
}
V g_heff_2esyntax_2esurface_2eexprL_lam12(V self, V *args) {
  V v_m_241129 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2esyntax_2esurface_2estmtL(v_r_240, v_m_241129));
}
V g_heff_2esyntax_2esurface_2eexprL_lam13(V self, V *args) {
  V v_m_241165 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2esyntax_2esurface_2estmtL(v_r_240, v_m_241165));
}
V g_heff_2esyntax_2esurface_2eexprL_lam14(V self, V *args) {
  V v_m_241195 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2esyntax_2esurface_2estmtL(v_r_240, v_m_241195));
}
V g_heff_2esyntax_2esurface_2eexprL_lam15(V self, V *args) {
  V v_m_241237 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2esyntax_2esurface_2estmtL(v_r_240, v_m_241237));
}
V g_heff_2esyntax_2esurface_2eexprL_lam16(V self, V *args) {
  V v_m_241278 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2esyntax_2esurface_2estmtL(v_r_240, v_m_241278));
}
V g_heff_2esyntax_2esurface_2eexprL_lam17(V self, V *args) {
  V v_m_241320 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2esyntax_2esurface_2estmtL(v_r_240, v_m_241320));
}
V g_heff_2esyntax_2esurface_2eexprL_lam18(V self, V *args) {
  V v_m_241361 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2esyntax_2esurface_2estmtL(v_r_240, v_m_241361));
}
V g_heff_2esyntax_2esurface_2eexprL_lam19(V self, V *args) {
  V v_m_241402 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2esyntax_2esurface_2estmtL(v_r_240, v_m_241402));
}
V g_heff_2esyntax_2esurface_2eexprL_lam20(V self, V *args) {
  V v_m_241443 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2esyntax_2esurface_2estmtL(v_r_240, v_m_241443));
}
HEFF_LIT(g_heff_2esyntax_2esurface_2edeclNameOf_24cpr_str0, 0, "");

HeffT2 g_heff_2esyntax_2esurface_2edeclNameOf_24cpr(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return ((HeffT2){{((V)&g_heff_2esyntax_2esurface_2edeclNameOf_24cpr_str0), heff_rec_n(2, shape_start__end, (V[]){MK_INT(0LL), MK_INT(0LL)})}});
  }
  case TAG_Cons: {
    V v_t_241 = heff_field(v_x1_240, 0);
    V v_x12_242 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 3ULL, 2);
    V v_text_243 = heff_take_field(v_t_241, 1);
    V v_start_244 = heff_take_field(v_t_241, 3);
    V v_end_245 = heff_get_n(v_t_241, 4, 9);
    switch (heff_tag_of(v_x12_242)) {
    case TAG_Nil: {
      V v_f_246 = v_text_243;
      V v_f_247 = heff_rec_n(2, shape_start__end, (V[]){v_start_244, v_end_245});
      return ((HeffT2){{v_f_246, v_f_247}});
    }
    case TAG_Cons: {
      V v_op_248 = heff_field(v_x12_242, 0);
      V v_x122_249 = heff_field(v_x12_242, 1);
      heff_take_n(v_x12_242, 3ULL, 2);
      V v_text_2410 = heff_take_field(v_op_248, 1);
      V v_start_2411 = heff_take_field(v_op_248, 3);
      V v_end_2412 = heff_get_n(v_op_248, 4, 9);
      switch (heff_tag_of(v_x122_249)) {
      case TAG_Nil: {
        heff_drop(v_text_2410);
        heff_drop(v_start_2411);
        heff_drop(v_end_2412);
        V v_f_2413 = v_text_243;
        V v_f_2414 = heff_rec_n(2, shape_start__end, (V[]){v_start_244, v_end_245});
        return ((HeffT2){{v_f_2413, v_f_2414}});
      }
      case TAG_Cons: {
        V v_x1222_2416 = heff_field(v_x122_249, 1);
        heff_take_n(v_x122_249, 2ULL, 2);
        switch (heff_tag_of(v_x1222_2416)) {
        case TAG_Nil: {
          heff_drop(v_text_243);
          heff_drop(v_start_244);
          heff_drop(v_end_245);
          V v_f_2417 = v_text_2410;
          V v_f_2418 = heff_rec_n(2, shape_start__end, (V[]){v_start_2411, v_end_2412});
          return ((HeffT2){{v_f_2417, v_f_2418}});
        }
        case TAG_Cons: {
          heff_take_n(v_x1222_2416, 0ULL, 2);
          heff_drop(v_text_2410);
          heff_drop(v_start_2411);
          heff_drop(v_end_2412);
          V v_f_2421 = v_text_243;
          V v_f_2422 = heff_rec_n(2, shape_start__end, (V[]){v_start_244, v_end_245});
          return ((HeffT2){{v_f_2421, v_f_2422}});
        }
        default: return ((HeffT2){{heff_nomatch(v_x1222_2416)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x122_249)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x12_242)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
V g_heff_2esyntax_2esurface_2edefaultL_lam0(V self, V *args); static Clo g_heff_2esyntax_2esurface_2edefaultL_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2edefaultL_lam0, 1, 0};
V g_heff_2esyntax_2esurface_2edefaultL_lam1(V self, V *args);
Clo g_heff_2esyntax_2esurface_2edefaultL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2edefaultL_entry, 2, 0};

V g_heff_2esyntax_2esurface_2edefaultL(V v_r_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nothing: {
    heff_drop_rec(v_r_240, 3);
    return ((V)&g_heff_2esyntax_2esurface_2edefaultL_lam0_clo);
  }
  case TAG_Just: {
    V v_x21_244 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    switch (heff_tag_of(v_x21_244)) {
    case TAG_MkPair: {
      V v_d_246 = heff_field(v_x21_244, 1);
      heff_take_n(v_x21_244, 2ULL, 2);
      V v_m_247 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 3), 1, (V[]){v_d_246}));
      return heff_clo_n(g_heff_2esyntax_2esurface_2edefaultL_lam1, 1, 1, (V[]){v_m_247});
    }
    default: return heff_nomatch(v_x21_244);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2esyntax_2esurface_2edefaultL_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2edefaultL(a[0], a[1]);
}
V g_heff_2esyntax_2esurface_2edefaultL_lam0(V self, V *args) {
  V v_st_242 = args[0];
  V v_t_243 = heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_Nothing)});
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_243, v_st_242});
}
V g_heff_2esyntax_2esurface_2edefaultL_lam1(V self, V *args) {
  V v_st_248 = args[0];
  V v_m_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_249 = heff_tr(heff_call(v_m_247, 1, (V[]){v_st_248}));
  switch (heff_tag_of(v_x1_249)) {
  case TAG_MkPair: {
    V v_x11_2410 = heff_field(v_x1_249, 0);
    V v_st_2411 = heff_field(v_x1_249, 1);
    V v_ru_24x1_249_24MkPair = heff_take_reuse_n(v_x1_249, 3ULL, 2);
    switch (heff_tag_of(v_x11_2410)) {
    case TAG_Left: {
      V v_e_2412 = heff_field(v_x11_2410, 0);
      heff_take_n(v_x11_2410, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_249_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2412}), v_st_2411});
    }
    case TAG_Right: {
      V v_x_2413 = heff_field(v_x11_2410, 0);
      V v_ru_24x11_2410_24Right = heff_take_reuse_n(v_x11_2410, 1ULL, 1);
      V v_t_2414 = heff_tag_at_n(v_ru_24x11_2410_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_Just, 1, (V[]){v_x_2413})});
      return heff_tag_at_n(v_ru_24x1_249_24MkPair, TAG_MkPair, 2, (V[]){v_t_2414, v_st_2411});
    }
    default: return heff_nomatch(v_x11_2410);
    }
  }
  default: return heff_nomatch(v_x1_249);
  }
}
Clo g_heff_2esyntax_2esurface_2erightsOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2erightsOf_entry, 1, 0};

V g_heff_2esyntax_2esurface_2erightsOf(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_Left: {
      heff_take_n(v_x11_241, 0ULL, 1);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Right: {
      V v_x_244 = heff_field(v_x11_241, 0);
      heff_take_n(v_x11_241, 1ULL, 1);
      V v_cell_245 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_244, heff_hole()});
      V v_u_246 = (g_heff_2esyntax_2esurface_2erightsOf_24dps(v_rest_242, heff_dup(v_cell_245)));
      heff_drop(v_u_246);
      return v_cell_245;
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2esyntax_2esurface_2erightsOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2erightsOf(a[0]);
}
Clo g_heff_2esyntax_2esurface_2eappendS_24tok2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2eappendS_24tok2_entry, 3, 0};

V g_heff_2esyntax_2esurface_2eappendS_24tok2(V v_tok_240, V v_x1_241, V v_ys_242) {
top: ;
  switch (heff_tag_of(v_x1_241)) {
  case TAG_Nil: {
    heff_drop_cell(v_tok_240, 2);
    return v_ys_242;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x1_241, 0);
    V v_xs_244 = heff_field(v_x1_241, 1);
    heff_take_n(v_x1_241, 3ULL, 2);
    V v_cell_245 = heff_tag_at_n(v_tok_240, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
    V v_u_246 = (g_heff_2esyntax_2esurface_2eappendS_24dps(v_xs_244, v_ys_242, heff_dup(v_cell_245)));
    heff_drop(v_u_246);
    return v_cell_245;
  }
  default: return heff_nomatch(v_x1_241);
  }
}
V g_heff_2esyntax_2esurface_2eappendS_24tok2_entry(V self, V *a) {
  (void)self;
  return g_heff_2esyntax_2esurface_2eappendS_24tok2(a[0], a[1], a[2]);
}
Clo g_heff_2esyntax_2esurface_2esegmentOf_24s1547151193x813882637_24tok1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2esyntax_2esurface_2esegmentOf_24s1547151193x813882637_24tok1_entry, 6, 0};

V g_heff_2esyntax_2esurface_2esegmentOf_24s1547151193x813882637_24tok1(V v_tok_240, V v_inPat_241, V v_sp_242, V v_e_243, V v_v_244, V v_st_245) {
top: ;
  V v_t_247;
  switch (heff_tag_of(v_v_244)) {
  case TAG_StrValue: {
    heff_drop_cell(v_tok_240, 1);
    v_t_247 = NTAG(TAG_SegmentBinary);
    break;
  }
  case TAG_IntValue: {
    heff_drop_cell(v_tok_240, 1);
    v_t_247 = NTAG(TAG_SegmentInteger);
    break;
  }
  case TAG_FloatValue: {
    heff_drop_cell(v_tok_240, 1);
    v_t_247 = NTAG(TAG_SegmentFloat);
    break;
  }
  case TAG_RuneValue: {
    v_t_247 = heff_tag_at_n(v_tok_240, TAG_SegmentUtf, 1, (V[]){MK_INT(8LL)});
    break;
  }
  case TAG_OtherValue: {
    heff_drop_cell(v_tok_240, 1);
    v_t_247 = NTAG(TAG_SegmentInteger);
    break;
  }
  default: heff_nomatch(v_v_244);
  }
  HeffT2 v_t_248 = (g_heff_2esyntax_2esurface_2evalueKind_24cpr(heff_dup(v_sp_242), heff_dup(v_v_244), v_t_247, v_st_245));
  {
    V v_field_249 = v_t_248.f[0];
    V v_field_2410 = v_t_248.f[1];
    V v_x11_2411 = v_field_249;
    V v_st_2412 = v_field_2410;
    switch (heff_tag_of(v_x11_2411)) {
    case TAG_Left: {
      V v_e_2413 = heff_field(v_x11_2411, 0);
      V v_ru_24x11_2411_24Left = heff_take_reuse_n(v_x11_2411, 1ULL, 1);
      heff_drop(v_sp_242);
      heff_drop(v_e_243);
      heff_drop(v_v_244);
      return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24x11_2411_24Left, TAG_Left, 1, (V[]){v_e_2413}), v_st_2412});
    }
    case TAG_Right: {
      V v_ru_24x11_2411_24Right = heff_take_reuse_n(v_x11_2411, 0ULL, 1);
      V v_t_2416;
      switch (heff_tag_of(v_v_244)) {
      case TAG_StrValue: {
        v_t_2416 = NTAG(TAG_SegmentBinary);
        break;
      }
      case TAG_IntValue: {
        v_t_2416 = NTAG(TAG_SegmentInteger);
        break;
      }
      case TAG_FloatValue: {
        v_t_2416 = NTAG(TAG_SegmentFloat);
        break;
      }
      case TAG_RuneValue: {
        v_t_2416 = heff_tag_n(TAG_SegmentUtf, 1, (V[]){MK_INT(8LL)});
        break;
      }
      case TAG_OtherValue: {
        v_t_2416 = NTAG(TAG_SegmentInteger);
        break;
      }
      default: heff_nomatch(v_v_244);
      }
      V v_m_2417 = (g_heff_2esyntax_2esurface_2etypeChecks_24s1730997437x1852866993(v_inPat_241, heff_dup(v_sp_242), heff_dup(v_v_244), v_t_2416, NTAG(TAG_SizeDefault)));
      V v_x1_2418 = heff_tr(heff_call(v_m_2417, 1, (V[]){v_st_2412}));
      switch (heff_tag_of(v_x1_2418)) {
      case TAG_MkPair: {
        V v_x11_2419 = heff_field(v_x1_2418, 0);
        V v_st_2420 = heff_field(v_x1_2418, 1);
        V v_ru_24x1_2418_24MkPair = heff_take_reuse_n(v_x1_2418, 3ULL, 2);
        switch (heff_tag_of(v_x11_2419)) {
        case TAG_Left: {
          V v_e_2421 = heff_field(v_x11_2419, 0);
          heff_take_n(v_x11_2419, 1ULL, 1);
          heff_drop(v_sp_242);
          heff_drop(v_e_243);
          heff_drop(v_v_244);
          heff_drop_cell(v_ru_24x11_2411_24Right, 1);
          return heff_tag_at_n(v_ru_24x1_2418_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Left, 1, (V[]){v_e_2421}), v_st_2420});
        }
        case TAG_Right: {
          V v_ru_24x11_2419_24Right = heff_take_reuse_n(v_x11_2419, 0ULL, 1);
          V v_t_2424;
          switch (heff_tag_of(v_v_244)) {
          case TAG_StrValue: {
            heff_drop_cell(v_ru_24x11_2419_24Right, 1);
            v_t_2424 = NTAG(TAG_SegmentBinary);
            break;
          }
          case TAG_IntValue: {
            heff_take_n(v_v_244, 0ULL, 1);
            heff_drop_cell(v_ru_24x11_2419_24Right, 1);
            v_t_2424 = NTAG(TAG_SegmentInteger);
            break;
          }
          case TAG_FloatValue: {
            heff_drop_cell(v_ru_24x11_2419_24Right, 1);
            v_t_2424 = NTAG(TAG_SegmentFloat);
            break;
          }
          case TAG_RuneValue: {
            v_t_2424 = heff_tag_at_n(v_ru_24x11_2419_24Right, TAG_SegmentUtf, 1, (V[]){MK_INT(8LL)});
            break;
          }
          case TAG_OtherValue: {
            heff_drop_cell(v_ru_24x11_2419_24Right, 1);
            v_t_2424 = NTAG(TAG_SegmentInteger);
            break;
          }
          default: heff_nomatch(v_v_244);
          }
          V v_t_2425 = heff_tag_n(TAG_MkSegment, 5, (V[]){v_e_243, v_t_2424, NTAG(TAG_SizeDefault), NTAG(TAG_False), NTAG(TAG_False)});
          V v_t_2426 = heff_tag_at_n(v_ru_24x11_2411_24Right, TAG_Right, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2425, v_sp_242})});
          return heff_tag_at_n(v_ru_24x1_2418_24MkPair, TAG_MkPair, 2, (V[]){v_t_2426, v_st_2420});
        }
        default: return heff_nomatch(v_x11_2419);
        }
      }
      default: return heff_nomatch(v_x1_2418);
      }
    }
    default: return heff_nomatch(v_x11_2411);
    }
  }
}
V g_heff_2esyntax_2esurface_2esegmentOf_24s1547151193x813882637_24tok1_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2esyntax_2esurface_2esegmentOf_24s1547151193x813882637_24tok1(a[0], a1, a[2], a[3], a[4], a[5]); heff_drop(a1); return r;
}