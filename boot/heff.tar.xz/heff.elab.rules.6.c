// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_AbsConst 8406
#define TAG_Become 65038
#define TAG_CloConst 61868
#define TAG_De 8978
#define TAG_Describe 2650
#define TAG_Expl 20488
#define TAG_ForDescriptive 19066
#define TAG_ForNominative 23095
#define TAG_Get 18914
#define TAG_HError 21467
#define TAG_HGlobal 55847
#define TAG_HLocal 25864
#define TAG_HMeta 17321
#define TAG_Impl 63555
#define TAG_Inst 64617
#define TAG_LSnoc 32613
#define TAG_Left 13886
#define TAG_LikeArray 39974
#define TAG_LikeFixed 5087
#define TAG_LikeFloat 20177
#define TAG_LikeFunction 24416
#define TAG_LikeInt 5296
#define TAG_LikeRecord 38505
#define TAG_LikeRune 45482
#define TAG_LikeString 41919
#define TAG_LikeSum 15116
#define TAG_LikeU 29548
#define TAG_MkAbs 54862
#define TAG_MkChk 56962
#define TAG_MkClo 57090
#define TAG_MkSyn 7342
#define TAG_MkTyp 8305
#define TAG_N 306
#define TAG_NoRules 38560
#define TAG_Nom 25944
#define TAG_Right 62770
#define TAG_SApp 57081
#define TAG_SCons 58684
#define TAG_SError 24172
#define TAG_SFunction 64505
#define TAG_SLam 1658
#define TAG_SMatch 27203
#define TAG_STag 9340
#define TAG_SpApp 44612
#define TAG_SpId 35501
#define TAG_SpProj 62333
#define TAG_SpSpec 18415
#define TAG_Throw 56084
#define TAG_UpdateIn 26667
#define TAG_UpdateTo 27009
#define TAG_VDecode 24012
#define TAG_VFixed 12623
#define TAG_VFunction 37316
#define TAG_VOpaque 37311
#define TAG_VPrimArray 11892
#define TAG_VPrimFloat 57621
#define TAG_VPrimInt 4244
#define TAG_VPrimRune 12870
#define TAG_VPrimString 23215
#define TAG_VRecord 10017
#define TAG_VSum 32852
#define TAG_VU 9520
#define LBL_aliases 1464806715
#define LBL_applied 1586106042
#define LBL_bind 9519364
#define LBL_byName 571997869
#define LBL_code 9554612
#define LBL_conclusion 1382344475
#define LBL_elabFor 712452832
#define LBL_globals 352931696
#define LBL_insts 301719303
#define LBL_keys 9783995
#define LBL_lams 9809570
#define LBL_len 316559
#define LBL_locals 849679763
#define LBL_malg 9839318
#define LBL_metas 305145640
#define LBL_msg 317947
#define LBL_name 9869138
#define LBL_names 305943394
#define LBL_note 9882809
#define LBL_scheme 1039154384
#define LBL_scope 310622830
#define LBL_self 10021907
#define LBL_severity 75955546
#define LBL_span 10032145
#define LBL_stx 323761
#define LBL_subgoals 820279267
#define LBL_ty 10476
#define LBL_v 336
#define LBL_val 326043
#define LBL_values 1123329101
static uint32_t shape_applied__conclusion__subgoals[] = {LBL_applied, LBL_conclusion, LBL_subgoals};
static uint32_t shape_code__severity__msg__span__note[] = {LBL_code, LBL_severity, LBL_msg, LBL_span, LBL_note};
static uint32_t shape_keys__byName__values[] = {LBL_keys, LBL_byName, LBL_values};
static uint32_t shape_len__names[] = {LBL_len, LBL_names};
static uint32_t shape_name__ty__v[] = {LBL_name, LBL_ty, LBL_v};
static uint32_t shape_scope__globals__elabFor__lams__self__insts[] = {LBL_scope, LBL_globals, LBL_elabFor, LBL_lams, LBL_self, LBL_insts};
static uint32_t shape_stx__val[] = {LBL_stx, LBL_val};
V g_co_2ebind_24s441514442x2097556756(V, V, V, V);
V g_co_2ebind_24s441514442x2097556756_entry(V self, V *a);
extern Clo g_co_2ebind_24s441514442x2097556756_clo;
V g_heff_2eelab_2eenvironment_2ewithBound(V, V, V, V);
V g_heff_2eelab_2eenvironment_2ewithBound_entry(V self, V *a);
extern Clo g_heff_2eelab_2eenvironment_2ewithBound_clo;
V g_heff_2eelab_2ememoed_2edecode(V);
V g_heff_2eelab_2ememoed_2edecode_entry(V self, V *a);
extern Clo g_heff_2eelab_2ememoed_2edecode_clo;
V g_heff_2eelab_2ememoed_2elam(V, V, V, V, V);
V g_heff_2eelab_2ememoed_2elam_entry(V self, V *a);
extern Clo g_heff_2eelab_2ememoed_2elam_clo;
V g_heff_2eelab_2emeta_2eliftU(V, V, V);
V g_heff_2eelab_2emeta_2eliftU_entry(V self, V *a);
extern Clo g_heff_2eelab_2emeta_2eliftU_clo;
V g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(V, V);
V g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276_entry(V self, V *a);
extern Clo g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276_clo;
V g_heff_2eelab_2erename_2edescribeKey(V);
V g_heff_2eelab_2erename_2edescribeKey_entry(V self, V *a);
extern Clo g_heff_2eelab_2erename_2edescribeKey_clo;
HeffT2 g_heff_2eelab_2erename_2efirstAliasOf_24cpr(V, V);
V g_heff_2eelab_2erename_2erkOf(V);
V g_heff_2eelab_2erename_2erkOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2erename_2erkOf_clo;
V g_heff_2eelab_2erules_2eapartSpines(V, V, V);
V g_heff_2eelab_2erules_2eapartSpines_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eapartSpines_clo;
V g_heff_2eelab_2erules_2eappendP(V, V);
V g_heff_2eelab_2erules_2eappendP_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eappendP_clo;
V g_heff_2eelab_2erules_2ecaseArm(V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2ecaseArm_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2ecaseArm_clo;
V g_heff_2eelab_2erules_2ecasesAt(V, V, V, V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2ecasesAt_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2ecasesAt_clo;
V g_heff_2eelab_2erules_2econclusionOf(V, V);
V g_heff_2eelab_2erules_2econclusionOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2econclusionOf_clo;
V g_heff_2eelab_2erules_2edelayedCheck(V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2edelayedCheck_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2edelayedCheck_clo;
V g_heff_2eelab_2erules_2edescribedBound(V, V);
V g_heff_2eelab_2erules_2edescribedBound_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2edescribedBound_clo;
V g_heff_2eelab_2erules_2edownFrom_24dps(V, V);
V g_heff_2eelab_2erules_2edownFrom_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2edownFrom_24dps_clo;
V g_heff_2eelab_2erules_2eentriesGo(V, V, V, V, V, V);
V g_heff_2eelab_2erules_2eentriesGo_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eentriesGo_clo;
HeffT1 g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr(V, V, V, V);
V g_heff_2eelab_2erules_2einstantiate(V, V, V);
V g_heff_2eelab_2erules_2einstantiate_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2einstantiate_clo;
V g_heff_2eelab_2erules_2einstantiateGo(V, V, V, V, V);
V g_heff_2eelab_2erules_2einstantiateGo_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2einstantiateGo_clo;
V g_heff_2eelab_2erules_2eletsAround(V, V, V, V, V);
V g_heff_2eelab_2erules_2eletsAround_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eletsAround_clo;
V g_heff_2eelab_2erules_2elettedAt(V, V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2elettedAt_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2elettedAt_clo;
HeffT2 g_heff_2eelab_2erules_2elookupP_24cpr(V, V);
V g_heff_2eelab_2erules_2eprettyEqErr(V, V);
V g_heff_2eelab_2erules_2eprettyEqErr_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eprettyEqErr_clo;
V g_heff_2eelab_2erules_2erecordName(V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2erecordName_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2erecordName_clo;
V g_heff_2eelab_2erules_2erecordTags(V, V, V, V);
V g_heff_2eelab_2erules_2erecordTags_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2erecordTags_clo;
V g_heff_2eelab_2erules_2erequireAgree(V, V, V);
V g_heff_2eelab_2erules_2erequireAgree_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2erequireAgree_clo;
HeffT2 g_heff_2eelab_2erules_2erigidFormer_24cpr(V, V);
V g_heff_2eelab_2erules_2esolveHole(V, V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2esolveHole_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2esolveHole_clo;
V g_heff_2eelab_2erules_2especialized(V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2especialized_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2especialized_clo;
V g_heff_2eelab_2erules_2especializedGo(V, V, V, V, V, V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2especializedGo_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2especializedGo_clo;
HeffT1 g_heff_2eelab_2erules_2esumIntroNow_24cpr(V, V, V, V);
V g_heff_2eelab_2erules_2etagArgsGo(V, V, V);
V g_heff_2eelab_2erules_2etagArgsGo_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2etagArgsGo_clo;
V g_heff_2eelab_2erules_2etyStr(V, V);
V g_heff_2eelab_2erules_2etyStr_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2etyStr_clo;
V g_heff_2eelab_2erules_2euniverseAt(V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2euniverseAt_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2euniverseAt_clo;
V g_heff_2eelab_2erules_2euniverseElimSyn(V, V);
V g_heff_2eelab_2erules_2euniverseElimSyn_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2euniverseElimSyn_clo;
V g_heff_2eelab_2erules_2euniverseIntro(V, V);
V g_heff_2eelab_2erules_2euniverseIntro_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2euniverseIntro_clo;
HeffT2 g_heff_2eelab_2erules_2eupdateInner_24cpr(V);
V g_heff_2eelab_2erules_2evaluesGo(V, V, V, V, V);
V g_heff_2eelab_2erules_2evaluesGo_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2evaluesGo_clo;
V g_heff_2eelab_2eunify_2euTypeF_24s1972392790x1695903351(V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2euTypeF_24s1972392790x1695903351_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2euTypeF_24s1972392790x1695903351_clo;
V g_heff_2eelab_2evalue_2ebehavior(V);
V g_heff_2eelab_2evalue_2ebehavior_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2ebehavior_clo;
V g_heff_2eelab_2evalue_2eforceTy(V, V);
V g_heff_2eelab_2evalue_2eforceTy_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eforceTy_clo;
V g_heff_2eelab_2evalue_2elevelOf(V);
V g_heff_2eelab_2evalue_2elevelOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2elevelOf_clo;
V g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(V, V, V, V);
V g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190_clo;
V g_heff_2esyntax_2esurfaceprint_2etyF_24s1921338660x1500721774(V, V, V, V);
V g_heff_2esyntax_2esurfaceprint_2etyF_24s1921338660x1500721774_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2etyF_24s1921338660x1500721774_clo;
V g_heff_2eutil_2edict_2eindexed(V, V);
V g_heff_2eutil_2edict_2eindexed_entry(V self, V *a);
extern Clo g_heff_2eutil_2edict_2eindexed_clo;
V g_heff_2eutil_2edict_2ezipKV(V, V);
V g_heff_2eutil_2edict_2ezipKV_entry(V self, V *a);
extern Clo g_heff_2eutil_2edict_2ezipKV_clo;
V g_list_2efoldl_24f625837968x2121675523(V, V, V);
V g_list_2efoldl_24f625837968x2121675523_entry(V self, V *a);
extern Clo g_list_2efoldl_24f625837968x2121675523_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2emap_24s1173914895x100384474(V);
V g_list_2emap_24s1173914895x100384474_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_clo;
V g_list_2emap_24s1937570095x2110149801(V);
V g_list_2emap_24s1937570095x2110149801_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_clo;
V g_prelude_2etraverse_24s1934076392x614790049(V, V);
V g_prelude_2etraverse_24s1934076392x614790049_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s1934076392x614790049_clo;
HeffT2 g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(V, V);
V g_std_2emap_2etoListOnto(V, V);
V g_std_2emap_2etoListOnto_entry(V self, V *a);
extern Clo g_std_2emap_2etoListOnto_clo;
Clo g_heff_2eelab_2erules_2edownFrom_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2edownFrom_24dps_entry, 2, 0};

V g_heff_2eelab_2erules_2edownFrom_24dps(V v_n_240, V v_d_241) {
top: ;
  if (heff_intLt_c_lent(v_n_240, MK_INT(0LL), 2)) {
    heff_drop(v_n_240);
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  } else {
    V v_cell_243 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_n_240), heff_hole()});
    V v_u_244 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_243));
    heff_drop(v_u_244);
    V t_0 = heff_intSub(v_n_240, MK_INT(1LL));
    V t_1 = v_cell_243;
    v_n_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
}
V g_heff_2eelab_2erules_2edownFrom_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2edownFrom_24dps(a[0], a[1]);
}
V g_heff_2eelab_2erules_2etyStr_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2etyStr_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2etyStr_entry, 2, 0};

V g_heff_2eelab_2erules_2etyStr(V v_e_240, V v_t_241) {
top: ;
  V v_t_242 = heff_get_n(heff_dup(heff_rfield(v_e_240, 0)), 0, 4);
  V v_t_243 = (g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(v_t_242, v_t_241));
  V v_t_2413 = (g_heff_2eelab_2erename_2erkOf(heff_clo_n(g_heff_2eelab_2erules_2etyStr_lam0, 1, 1, (V[]){heff_dup(v_e_240)})));
  V v_t_2414 = heff_tr(heff_call(heff_get_n(v_t_2413, 1, 2), 1, (V[]){v_t_243}));
  V v_t_2415 = heff_get_n(heff_get_n(v_e_240, 0, 6), 1, 4);
  return ({ V a_0 = MK_INT(0LL); V a_1 = MK_INT(0LL); V a_2 = v_t_2415; V a_3 = v_t_2414; V r_ = (g_heff_2esyntax_2esurfaceprint_2etyF_24s1921338660x1500721774(a_0, a_1, a_2, a_3)); heff_drop(v_t_2414); r_; });
}
V g_heff_2eelab_2erules_2etyStr_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2etyStr(a[0], a[1]);
}
V g_heff_2eelab_2erules_2etyStr_lam0(V self, V *args) {
  V v_x_244 = args[0];
  V v_e_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_d_245 = (g_heff_2eelab_2erename_2edescribeKey(heff_dup(v_x_244)));
  V v_t_246 = heff_get_n(heff_get_n(v_e_240, 1, 6), 2, 7);
  V v_t_247 = ({ V a_0 = v_t_246; V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2emap_2etoListOnto(a_0, a_1)); heff_drop(v_t_246); r_; });
  HeffT2 v_t_248 = ({ V a_0 = v_t_247; V a_1 = v_x_244; HeffT2 r_ = (g_heff_2eelab_2erename_2efirstAliasOf_24cpr(a_0, a_1)); heff_drop(v_x_244); r_; });
  {
    V v_field_2410 = v_t_248.f[1];
    int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
    if ((v_tag_249 == ((int64_t)0ULL))) {
      heff_drop(v_d_245);
      V v_x_2412 = v_field_2410;
      return v_x_2412;
    } else {
      heff_drop(v_field_2410);
      return v_d_245;
    }
  }
}
V g_heff_2eelab_2erules_2einstantiate_lam0(V self, V *args);
V g_heff_2eelab_2erules_2einstantiate_lam2(V self, V *args);
V g_heff_2eelab_2erules_2einstantiate_lam1(V self, V *args);
Clo g_heff_2eelab_2erules_2einstantiate_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2einstantiate_entry, 3, 0};

V g_heff_2eelab_2erules_2einstantiate(V v_e_240, V v_sp_241, V v_w_242) {
top: ;
  V v_t_243 = heff_dup(heff_rfield(v_w_242, 2));
  if ((heff_dup(v_t_243) == NTAG(TAG_True))) {
    heff_drop(v_t_243);
    V v_t_245 = heff_rec_n(2, shape_stx__val, (V[]){heff_dup(heff_rfield(v_w_242, 4)), heff_clo_n(g_heff_2eelab_2erules_2einstantiate_lam0, 1, 1, (V[]){heff_dup(v_w_242)})});
    return (g_heff_2eelab_2erules_2einstantiateGo(v_e_240, v_sp_241, v_t_245, heff_get_n(v_w_242, 3, 6), NTAG(TAG_Nil)));
  } else {
    heff_drop(v_e_240);
    heff_drop(v_sp_241);
    heff_drop(v_t_243);
    return heff_clo_n(g_heff_2eelab_2erules_2einstantiate_lam1, 2, 1, (V[]){v_w_242});
  }
}
V g_heff_2eelab_2erules_2einstantiate_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2einstantiate(a[0], a[1], a[2]);
}
V g_heff_2eelab_2erules_2einstantiate_lam0(V self, V *args) {
  V v_u_244 = args[0];
  V v_w_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_244);
  return heff_tag_n(TAG_Nom, 1, (V[]){heff_get_n(v_w_242, 5, 6)});
}
V g_heff_2eelab_2erules_2einstantiate_lam2(V self, V *args) {
  V v_u_248 = args[0];
  V v_w_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_248);
  return heff_tag_n(TAG_Nom, 1, (V[]){heff_get_n(v_w_242, 5, 6)});
}
V g_heff_2eelab_2erules_2einstantiate_lam1(V self, V *args) {
  V v_hd_246 = args[0];
  V v_k_247 = args[1];
  V v_w_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_246);
  V v_t_249 = heff_rec_n(2, shape_stx__val, (V[]){heff_dup(heff_rfield(v_w_242, 4)), heff_clo_n(g_heff_2eelab_2erules_2einstantiate_lam2, 1, 1, (V[]){heff_dup(v_w_242)})});
  V v_t_2410 = heff_rec_n(3, shape_applied__conclusion__subgoals, (V[]){v_t_249, heff_get_n(v_w_242, 3, 6), NTAG(TAG_Nil)});
  V f_ = v_k_247;
  args[0] = v_t_2410;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2econclusionOf_lam1(V self, V *args);
V g_heff_2eelab_2erules_2econclusionOf_lam0(V self, V *args);
V g_heff_2eelab_2erules_2econclusionOf_lam3(V self, V *args);
V g_heff_2eelab_2erules_2econclusionOf_lam2(V self, V *args);
Clo g_heff_2eelab_2erules_2econclusionOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2econclusionOf_entry, 2, 0};

V g_heff_2eelab_2erules_2econclusionOf(V v_n_240, V v_ty_241) {
top: ;
  switch (heff_tag_of(v_ty_241)) {
  case TAG_VU: {
    heff_drop(v_n_240);
    return v_ty_241;
  }
  case TAG_VDecode: {
    heff_drop(v_n_240);
    return v_ty_241;
  }
  case TAG_VFunction: {
    V v_dom_249 = heff_dup(heff_field(v_ty_241, 1));
    V v_cod_2410 = heff_dup(heff_field(v_ty_241, 2));
    V v_it4_2411 = heff_dup(heff_field(v_ty_241, 3));
    switch (heff_tag_of(v_it4_2411)) {
    case TAG_Expl: {
      heff_drop(v_n_240);
      heff_drop(v_dom_249);
      heff_drop(v_cod_2410);
      return v_ty_241;
    }
    case TAG_Impl: {
      heff_drop_tag(v_ty_241, 5);
      V v_x1_2419;
      switch (heff_tag_of(v_cod_2410)) {
      case TAG_MkClo: {
        V v_vs_2414 = heff_field(v_cod_2410, 1);
        V v_body_2415 = heff_field(v_cod_2410, 2);
        heff_take_n(v_cod_2410, 6ULL, 3);
        v_x1_2419 = heff_tr(heff_call(v_body_2415, 1, (V[]){heff_tag_n(TAG_LSnoc, 2, (V[]){v_vs_2414, heff_clo_n(g_heff_2eelab_2erules_2econclusionOf_lam0, 1, 2, (V[]){heff_dup(v_n_240), v_dom_249})})}));
        break;
      }
      case TAG_CloConst: {
        V v_body_2418 = heff_field(v_cod_2410, 0);
        heff_take_n(v_cod_2410, 1ULL, 1);
        heff_drop(v_dom_249);
        v_x1_2419 = v_body_2418;
        break;
      }
      default: heff_nomatch(v_cod_2410);
      }
      V v_t_2423;
      switch (heff_tag_of(v_x1_2419)) {
      case TAG_Nom: {
        V v_x_2420 = heff_field(v_x1_2419, 0);
        heff_take_n(v_x1_2419, 1ULL, 1);
        v_t_2423 = v_x_2420;
        break;
      }
      case TAG_Describe: {
        heff_take_n(v_x1_2419, 0ULL, 1);
        v_t_2423 = heff_abandon();
        break;
      }
      case TAG_Become: {
        V v_x_2422 = heff_field(v_x1_2419, 0);
        heff_take_n(v_x1_2419, 1ULL, 1);
        v_t_2423 = v_x_2422;
        break;
      }
      default: heff_nomatch(v_x1_2419);
      }
      V t_0 = heff_intAdd(v_n_240, MK_INT(1LL));
      V t_1 = v_t_2423;
      v_n_240 = t_0;
      v_ty_241 = t_1;
      goto top;
    }
    case TAG_Inst: {
      heff_drop_tag(v_ty_241, 5);
      V v_x1_2430;
      switch (heff_tag_of(v_cod_2410)) {
      case TAG_MkClo: {
        V v_vs_2425 = heff_field(v_cod_2410, 1);
        V v_body_2426 = heff_field(v_cod_2410, 2);
        heff_take_n(v_cod_2410, 6ULL, 3);
        v_x1_2430 = heff_tr(heff_call(v_body_2426, 1, (V[]){heff_tag_n(TAG_LSnoc, 2, (V[]){v_vs_2425, heff_clo_n(g_heff_2eelab_2erules_2econclusionOf_lam2, 1, 2, (V[]){heff_dup(v_n_240), v_dom_249})})}));
        break;
      }
      case TAG_CloConst: {
        V v_body_2429 = heff_field(v_cod_2410, 0);
        heff_take_n(v_cod_2410, 1ULL, 1);
        heff_drop(v_dom_249);
        v_x1_2430 = v_body_2429;
        break;
      }
      default: heff_nomatch(v_cod_2410);
      }
      V v_t_2434;
      switch (heff_tag_of(v_x1_2430)) {
      case TAG_Nom: {
        V v_x_2431 = heff_field(v_x1_2430, 0);
        heff_take_n(v_x1_2430, 1ULL, 1);
        v_t_2434 = v_x_2431;
        break;
      }
      case TAG_Describe: {
        heff_take_n(v_x1_2430, 0ULL, 1);
        v_t_2434 = heff_abandon();
        break;
      }
      case TAG_Become: {
        V v_x_2433 = heff_field(v_x1_2430, 0);
        heff_take_n(v_x1_2430, 1ULL, 1);
        v_t_2434 = v_x_2433;
        break;
      }
      default: heff_nomatch(v_x1_2430);
      }
      V t_0 = heff_intAdd(v_n_240, MK_INT(1LL));
      V t_1 = v_t_2434;
      v_n_240 = t_0;
      v_ty_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_it4_2411);
    }
  }
  case TAG_VRecord: {
    heff_drop(v_n_240);
    return v_ty_241;
  }
  case TAG_VSum: {
    heff_drop(v_n_240);
    return v_ty_241;
  }
  case TAG_VPrimInt: {
    heff_drop(v_n_240);
    return v_ty_241;
  }
  case TAG_VPrimFloat: {
    heff_drop(v_n_240);
    return v_ty_241;
  }
  case TAG_VPrimString: {
    heff_drop(v_n_240);
    return v_ty_241;
  }
  case TAG_VPrimRune: {
    heff_drop(v_n_240);
    return v_ty_241;
  }
  case TAG_VPrimArray: {
    heff_drop(v_n_240);
    return v_ty_241;
  }
  case TAG_VFixed: {
    heff_drop(v_n_240);
    return v_ty_241;
  }
  default: return heff_nomatch(v_ty_241);
  }
}
V g_heff_2eelab_2erules_2econclusionOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2econclusionOf(a[0], a[1]);
}
V g_heff_2eelab_2erules_2econclusionOf_lam1(V self, V *args) {
  V v_u_2417 = args[0];
  V v_dom_249 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2417);
  return v_dom_249;
}
V g_heff_2eelab_2erules_2econclusionOf_lam0(V self, V *args) {
  V v_u_2416 = args[0];
  V v_n_240 = heff_env(self)[0];
  V v_dom_249 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_u_2416);
  return (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(heff_tag_n(TAG_HLocal, 1, (V[]){v_n_240}), NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2erules_2econclusionOf_lam1, 1, 1, (V[]){v_dom_249}), NTAG(TAG_Nothing)));
}
V g_heff_2eelab_2erules_2econclusionOf_lam3(V self, V *args) {
  V v_u_2428 = args[0];
  V v_dom_249 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2428);
  return v_dom_249;
}
V g_heff_2eelab_2erules_2econclusionOf_lam2(V self, V *args) {
  V v_u_2427 = args[0];
  V v_n_240 = heff_env(self)[0];
  V v_dom_249 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_u_2427);
  return (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(heff_tag_n(TAG_HLocal, 1, (V[]){v_n_240}), NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2erules_2econclusionOf_lam3, 1, 1, (V[]){v_dom_249}), NTAG(TAG_Nothing)));
}
Clo g_heff_2eelab_2erules_2eapartSpines_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eapartSpines_entry, 3, 0};

V g_heff_2eelab_2erules_2eapartSpines(V v_mc_240, V v_x2_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_SpId: {
    return NTAG(TAG_False);
  }
  case TAG_SpApp: {
    V v_sp_243 = heff_field(v_x2_241, 0);
    V v_a_244 = heff_field(v_x2_241, 1);
    switch (heff_tag_of(v_x3_242)) {
    case TAG_SpId: {
      return NTAG(TAG_False);
    }
    case TAG_SpApp: {
      V v_sp2_245 = heff_field(v_x3_242, 0);
      V v_b_246 = heff_field(v_x3_242, 1);
      HeffT2 v_t_247 = (g_heff_2eelab_2erules_2erigidFormer_24cpr(v_mc_240, heff_dup(v_a_244)));
      {
        V v_field_249 = v_t_247.f[1];
        int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
        if ((v_tag_248 == ((int64_t)0ULL))) {
          V v_k_2411 = v_field_249;
          HeffT2 v_t_2412 = (g_heff_2eelab_2erules_2erigidFormer_24cpr(v_mc_240, heff_dup(v_b_246)));
          {
            V v_field_2414 = v_t_2412.f[1];
            int64_t v_tag_2413 = ((int64_t)v_t_2412.f[0]);
            if ((v_tag_2413 == ((int64_t)0ULL))) {
              V v_k2_2416 = v_field_2414;
              if (heff_strEq_c(v_k_2411, v_k2_2416)) {
                V t_0 = v_mc_240;
                V t_1 = v_sp_243;
                V t_2 = v_sp2_245;
                v_mc_240 = t_0;
                v_x2_241 = t_1;
                v_x3_242 = t_2;
                goto top;
              } else {
                return NTAG(TAG_True);
              }
            } else {
              heff_drop(v_k_2411);
              heff_drop(v_field_2414);
              V t_0 = v_mc_240;
              V t_1 = v_sp_243;
              V t_2 = v_sp2_245;
              v_mc_240 = t_0;
              v_x2_241 = t_1;
              v_x3_242 = t_2;
              goto top;
            }
          }
        } else {
          heff_drop(v_field_249);
          V t_0 = v_mc_240;
          V t_1 = v_sp_243;
          V t_2 = v_sp2_245;
          v_mc_240 = t_0;
          v_x2_241 = t_1;
          v_x3_242 = t_2;
          goto top;
        }
      }
    }
    case TAG_SpProj: {
      return NTAG(TAG_False);
    }
    case TAG_SpSpec: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x3_242);
    }
  }
  case TAG_SpProj: {
    return NTAG(TAG_False);
  }
  case TAG_SpSpec: {
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eelab_2erules_2eapartSpines_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V r = g_heff_2eelab_2erules_2eapartSpines(a0, a1, a2); heff_drop(a0); heff_drop(a1); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_str0, 57, "tried to check a lambda expression at a non-function type");
HEFF_LIT(g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_str1, 1, "_");
HEFF_LIT(g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_str2, 1, "_");
HEFF_LIT(g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_str3, 1, "_");
HEFF_LIT(g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_str4, 57, "tried to check a lambda expression at a non-function type");
HEFF_LIT(g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_str5, 57, "tried to check a lambda expression at a non-function type");
HEFF_LIT(g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_str6, 57, "tried to check a lambda expression at a non-function type");
HEFF_LIT(g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_str7, 57, "tried to check a lambda expression at a non-function type");
HEFF_LIT(g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_str8, 57, "tried to check a lambda expression at a non-function type");
HEFF_LIT(g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_str9, 57, "tried to check a lambda expression at a non-function type");
HEFF_LIT(g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_str10, 57, "tried to check a lambda expression at a non-function type");
HEFF_LIT(g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_str11, 57, "tried to check a lambda expression at a non-function type");
HEFF_LIT(g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_str12, 57, "tried to check a lambda expression at a non-function type");
V g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_lam1(V self, V *args);
V g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_lam4(V self, V *args);
V g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_lam8(V self, V *args);
V g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_lam11(V self, V *args);
V g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_lam10(V self, V *args);
V g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_lam9(V self, V *args);
V g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_lam7(V self, V *args);
V g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_lam6(V self, V *args);
V g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_lam5(V self, V *args);
V g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_lam3(V self, V *args);
V g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_lam13(V self, V *args);
V g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_lam16(V self, V *args);
V g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_lam15(V self, V *args);
V g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_lam14(V self, V *args);
V g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_lam12(V self, V *args);
V g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_lam2(V self, V *args);
V g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_lam0(V self, V *args);

HeffT1 g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr(V v_sp_240, V v_x_241, V v_dom_242, V v_body_243) {
top: ;
  return ((HeffT1){{heff_clo_n(g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_lam0, 4, 4, (V[]){v_sp_240, heff_dup(v_dom_242), v_x_241, heff_dup(v_body_243)})}});
}
V g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_lam1(V self, V *args) {
  V v_c_248 = args[0];
  V v_a0_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_c_248, 3, 8); V a_1 = v_a0_245; V r_ = (g_heff_2eelab_2evalue_2eforceTy(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_lam4(V self, V *args) {
  V v_p_2433 = args[0];
  V v_p_2434 = args[1];
  V v_c_2427 = heff_env(self)[0];
  V v_e_244 = heff_env(self)[1];
  V v_fdom_2420 = heff_env(self)[2];
  V v_b_2432 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2435 = heff_rec_n(2, shape_len__names, (V[]){heff_take_field(v_c_2427, 0), heff_get_n(v_c_2427, 1, 4)});
  V v_t_2436 = heff_tr(heff_call(((V)&g_heff_2eelab_2eunify_2euTypeF_24s1972392790x1695903351_clo), 4, (V[]){heff_get_n(v_e_244, 1, 6), v_t_2435, v_fdom_2420, v_b_2432}));
  return (g_heff_2eelab_2emeta_2eliftU(v_t_2436, v_p_2433, v_p_2434));
}
V g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_lam8(V self, V *args) {
  V v_u_2452 = args[0];
  V v_v_2447 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2452);
  return v_v_2447;
}
V g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_lam11(V self, V *args) {
  V v_u_2477 = args[0];
  V v_x_2412 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2477);
  return heff_tag_n(TAG_Nom, 1, (V[]){v_x_2412});
}
V g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_lam10(V self, V *args) {
  V v_x_2469 = args[0];
  V v_e_244 = heff_env(self)[0];
  V v_x_2412 = heff_env(self)[1];
  V v_x_241 = heff_env(self)[2];
  V v_k_2468 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2470 = heff_take_field(v_e_244, 2);
  V v_t_2473;
  switch (heff_tag_of(v_t_2470)) {
  case TAG_ForNominative: {
    v_t_2473 = NTAG(TAG_N);
    break;
  }
  case TAG_ForDescriptive: {
    heff_take_n(v_t_2470, 0ULL, 2);
    v_t_2473 = NTAG(TAG_De);
    break;
  }
  default: heff_nomatch(v_t_2470);
  }
  V v_t_2474 = heff_get_n(heff_dup(heff_rfield(v_e_244, 0)), 2, 4);
  V v_t_2475 = heff_get_n(heff_dup(heff_rfield(v_e_244, 0)), 0, 4);
  V v_t_2476 = (g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(v_t_2475, heff_dup(v_x_2412)));
  V v_x_2478 = (g_heff_2eelab_2ememoed_2elam(v_t_2473, heff_get_n(v_e_244, 1, 6), v_t_2474, heff_rec_n(2, shape_stx__val, (V[]){v_t_2476, heff_clo_n(g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_lam11, 1, 1, (V[]){v_x_2412})}), heff_tag_n(TAG_MkAbs, 2, (V[]){v_x_241, v_x_2469})));
  V f_ = v_k_2468;
  args[0] = v_x_2478;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_lam9(V self, V *args) {
  V v_hd_2467 = args[0];
  V v_k_2468 = args[1];
  V v_c_2466 = heff_env(self)[0];
  V v_e_244 = heff_env(self)[1];
  V v_x_2412 = heff_env(self)[2];
  V v_x_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_2466;
  args[0] = v_hd_2467;
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_lam10, 1, 4, (V[]){v_e_244, v_x_2412, v_x_241, v_k_2468});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_lam7(V self, V *args) {
  V v_v_2447 = args[0];
  V v_scope_27_2448 = args[1];
  V v_cod_2421 = heff_env(self)[0];
  V v_body_243 = heff_env(self)[1];
  V v_e_244 = heff_env(self)[2];
  V v_x_2412 = heff_env(self)[3];
  V v_x_241 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_x1_2454;
  switch (heff_tag_of(v_cod_2421)) {
  case TAG_MkClo: {
    V v_vs_2450 = heff_field(v_cod_2421, 1);
    V v_body_2451 = heff_field(v_cod_2421, 2);
    heff_take_n(v_cod_2421, 6ULL, 3);
    v_x1_2454 = heff_tr(heff_call(v_body_2451, 1, (V[]){heff_tag_n(TAG_LSnoc, 2, (V[]){v_vs_2450, heff_clo_n(g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_lam8, 1, 1, (V[]){heff_dup(v_v_2447)})})}));
    break;
  }
  case TAG_CloConst: {
    V v_body_2453 = heff_field(v_cod_2421, 0);
    heff_take_n(v_cod_2421, 1ULL, 1);
    v_x1_2454 = v_body_2453;
    break;
  }
  default: heff_nomatch(v_cod_2421);
  }
  V v_a_2458;
  switch (heff_tag_of(v_x1_2454)) {
  case TAG_Nom: {
    V v_x_2455 = heff_field(v_x1_2454, 0);
    heff_take_n(v_x1_2454, 1ULL, 1);
    v_a_2458 = v_x_2455;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2454, 0ULL, 1);
    v_a_2458 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2457 = heff_field(v_x1_2454, 0);
    heff_take_n(v_x1_2454, 1ULL, 1);
    v_a_2458 = v_x_2457;
    break;
  }
  default: heff_nomatch(v_x1_2454);
  }
  V v_c_2466;
  switch (heff_tag_of(v_body_243)) {
  case TAG_MkChk: {
    V v_f_2459 = heff_field(v_body_243, 0);
    heff_take_n(v_body_243, 1ULL, 1);
    V v_t_2460 = heff_dup(heff_rfield(v_e_244, 2));
    V v_t_2463;
    switch (heff_tag_of(v_t_2460)) {
    case TAG_ForNominative: {
      heff_drop(v_v_2447);
      v_t_2463 = NTAG(TAG_ForNominative);
      break;
    }
    case TAG_ForDescriptive: {
      V v_h_2461 = heff_field(v_t_2460, 0);
      V v_sp_2462 = heff_field(v_t_2460, 1);
      V v_ru_24t_2460_24ForDescriptive = heff_take_reuse_n(v_t_2460, 3ULL, 2);
      v_t_2463 = heff_tag_at_n(v_ru_24t_2460_24ForDescriptive, TAG_ForDescriptive, 2, (V[]){v_h_2461, heff_tag_n(TAG_SpApp, 2, (V[]){v_sp_2462, v_v_2447})});
      break;
    }
    default: heff_nomatch(v_t_2460);
    }
    V v_t_2464 = heff_intAdd(heff_dup(heff_rfield(v_e_244, 3)), MK_INT(1LL));
    V v_t_2465 = heff_rec_n(6, shape_scope__globals__elabFor__lams__self__insts, (V[]){v_scope_27_2448, heff_dup(heff_rfield(v_e_244, 1)), v_t_2463, v_t_2464, heff_dup(heff_rfield(v_e_244, 4)), heff_dup(heff_rfield(v_e_244, 5))});
    v_c_2466 = heff_tr(heff_call(v_f_2459, 2, (V[]){v_t_2465, v_a_2458}));
    break;
  }
  default: heff_nomatch(v_body_243);
  }
  return heff_clo_n(g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_lam9, 2, 4, (V[]){v_c_2466, v_e_244, v_x_2412, v_x_241});
}
V g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_lam6(V self, V *args) {
  V v_x_2441 = args[0];
  V v_x_2426 = heff_env(self)[0];
  V v_x_241 = heff_env(self)[1];
  V v_e_244 = heff_env(self)[2];
  V v_cod_2421 = heff_env(self)[3];
  V v_body_243 = heff_env(self)[4];
  V v_x_2412 = heff_env(self)[5];
  V v_z_2438 = heff_env(self)[6];
  V v_z_2439 = heff_env(self)[7];
  heff_clo_take(self, 8);
  heff_drop(v_x_2441);
  V v_x1_2442 = heff_tr(heff_call(heff_get_n(v_x_2426, 1, 2), 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_t_2446;
  switch (heff_tag_of(v_x1_2442)) {
  case TAG_Nom: {
    V v_x_2443 = heff_field(v_x1_2442, 0);
    heff_take_n(v_x1_2442, 1ULL, 1);
    v_t_2446 = v_x_2443;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2442, 0ULL, 1);
    v_t_2446 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2445 = heff_field(v_x1_2442, 0);
    heff_take_n(v_x1_2442, 1ULL, 1);
    v_t_2446 = v_x_2445;
    break;
  }
  default: heff_nomatch(v_x1_2442);
  }
  V v_t_2479 = heff_tr(g_heff_2eelab_2eenvironment_2ewithBound(heff_dup(v_x_241), v_t_2446, heff_dup(heff_rfield(v_e_244, 0)), heff_clo_n(g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_lam7, 2, 5, (V[]){v_cod_2421, v_body_243, v_e_244, v_x_2412, v_x_241})));
  V f_ = v_t_2479;
  heff_room[0] = v_z_2438;
  heff_room[1] = v_z_2439;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_lam5(V self, V *args) {
  V v_agree_2437 = args[0];
  V v_z_2438 = args[1];
  V v_z_2439 = args[2];
  V v_e_244 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  V v_x_2426 = heff_env(self)[2];
  V v_x_241 = heff_env(self)[3];
  V v_cod_2421 = heff_env(self)[4];
  V v_body_243 = heff_env(self)[5];
  V v_x_2412 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_c_2440 = (g_heff_2eelab_2erules_2erequireAgree(heff_dup(v_e_244), v_sp_240, v_agree_2437));
  V f_ = v_c_2440;
  args[0] = heff_dup(v_z_2438);
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_lam6, 1, 8, (V[]){v_x_2426, v_x_241, v_e_244, v_cod_2421, v_body_243, v_x_2412, v_z_2438, v_z_2439});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_lam3(V self, V *args) {
  V v_x_2426 = args[0];
  V v_e_244 = heff_env(self)[0];
  V v_fdom_2420 = heff_env(self)[1];
  V v_sp_240 = heff_env(self)[2];
  V v_x_241 = heff_env(self)[3];
  V v_cod_2421 = heff_env(self)[4];
  V v_body_243 = heff_env(self)[5];
  V v_x_2412 = heff_env(self)[6];
  V v_hd_246 = heff_env(self)[7];
  V v_k_247 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_c_2427 = heff_dup(heff_rfield(v_e_244, 0));
  V v_x1_2428 = heff_tr(heff_call(heff_dup(heff_rfield(v_x_2426, 1)), 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_b_2432;
  switch (heff_tag_of(v_x1_2428)) {
  case TAG_Nom: {
    V v_x_2429 = heff_field(v_x1_2428, 0);
    heff_take_n(v_x1_2428, 1ULL, 1);
    v_b_2432 = v_x_2429;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2428, 0ULL, 1);
    v_b_2432 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2431 = heff_field(v_x1_2428, 0);
    heff_take_n(v_x1_2428, 1ULL, 1);
    v_b_2432 = v_x_2431;
    break;
  }
  default: heff_nomatch(v_x1_2428);
  }
  return (g_co_2ebind_24s441514442x2097556756(heff_clo_n(g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_lam4, 2, 4, (V[]){v_c_2427, heff_dup(v_e_244), v_fdom_2420, v_b_2432}), heff_clo_n(g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_lam5, 3, 7, (V[]){v_e_244, v_sp_240, v_x_2426, v_x_241, v_cod_2421, v_body_243, v_x_2412}), v_hd_246, v_k_247));
}
V g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_lam13(V self, V *args) {
  V v_u_2492 = args[0];
  V v_v_2485 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2492);
  return v_v_2485;
}
V g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_lam16(V self, V *args) {
  V v_u_24128 = args[0];
  V v_x_2412 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_24128);
  return heff_tag_n(TAG_Nom, 1, (V[]){v_x_2412});
}
V g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_lam15(V self, V *args) {
  V v_x_24115 = args[0];
  V v_e_244 = heff_env(self)[0];
  V v_x_2412 = heff_env(self)[1];
  V v_cod_2421 = heff_env(self)[2];
  V v_k_24114 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_24116 = heff_take_field(v_e_244, 2);
  V v_t_24119;
  switch (heff_tag_of(v_t_24116)) {
  case TAG_ForNominative: {
    v_t_24119 = NTAG(TAG_N);
    break;
  }
  case TAG_ForDescriptive: {
    heff_take_n(v_t_24116, 0ULL, 2);
    v_t_24119 = NTAG(TAG_De);
    break;
  }
  default: heff_nomatch(v_t_24116);
  }
  V v_t_24120 = heff_get_n(heff_dup(heff_rfield(v_e_244, 0)), 2, 4);
  V v_t_24121 = heff_get_n(heff_dup(heff_rfield(v_e_244, 0)), 0, 4);
  V v_t_24122 = (g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(v_t_24121, heff_dup(v_x_2412)));
  V v_t_24127;
  switch (heff_tag_of(v_cod_2421)) {
  case TAG_MkClo: {
    V v_n_24123 = heff_field(v_cod_2421, 0);
    heff_take_n(v_cod_2421, 1ULL, 3);
    v_t_24127 = v_n_24123;
    break;
  }
  case TAG_CloConst: {
    heff_take_n(v_cod_2421, 0ULL, 1);
    v_t_24127 = ((V)&g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_str3);
    break;
  }
  default: heff_nomatch(v_cod_2421);
  }
  V v_x_24129 = (g_heff_2eelab_2ememoed_2elam(v_t_24119, heff_get_n(v_e_244, 1, 6), v_t_24120, heff_rec_n(2, shape_stx__val, (V[]){v_t_24122, heff_clo_n(g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_lam16, 1, 1, (V[]){v_x_2412})}), heff_tag_n(TAG_MkAbs, 2, (V[]){v_t_24127, v_x_24115})));
  V f_ = v_k_24114;
  args[0] = v_x_24129;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_lam14(V self, V *args) {
  V v_hd_24113 = args[0];
  V v_k_24114 = args[1];
  V v_c_24112 = heff_env(self)[0];
  V v_e_244 = heff_env(self)[1];
  V v_x_2412 = heff_env(self)[2];
  V v_cod_2421 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_24112;
  args[0] = v_hd_24113;
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_lam15, 1, 4, (V[]){v_e_244, v_x_2412, v_cod_2421, v_k_24114});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_lam12(V self, V *args) {
  V v_v_2485 = args[0];
  V v_scope_27_2486 = args[1];
  V v_sp_240 = heff_env(self)[0];
  V v_x_241 = heff_env(self)[1];
  V v_dom_242 = heff_env(self)[2];
  V v_body_243 = heff_env(self)[3];
  V v_cod_2421 = heff_env(self)[4];
  V v_e_244 = heff_env(self)[5];
  V v_implicit_2422 = heff_env(self)[6];
  V v_fdom_2420 = heff_env(self)[7];
  V v_x_2412 = heff_env(self)[8];
  heff_clo_take(self, 9);
  HeffT1 v_t_2487 = ({ V a_0 = v_sp_240; V a_1 = v_x_241; V a_2 = v_dom_242; V a_3 = v_body_243; HeffT1 r_ = (g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_dom_242); heff_drop(v_body_243); r_; });
  {
    V v_field_2488 = v_t_2487.f[0];
    V v_x1_2494;
    switch (heff_tag_of(v_cod_2421)) {
    case TAG_MkClo: {
      V v_vs_2490 = heff_dup(heff_field(v_cod_2421, 1));
      V v_body_2491 = heff_dup(heff_field(v_cod_2421, 2));
      v_x1_2494 = heff_tr(heff_call(v_body_2491, 1, (V[]){heff_tag_n(TAG_LSnoc, 2, (V[]){v_vs_2490, heff_clo_n(g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_lam13, 1, 1, (V[]){heff_dup(v_v_2485)})})}));
      break;
    }
    case TAG_CloConst: {
      V v_body_2493 = heff_dup(heff_field(v_cod_2421, 0));
      v_x1_2494 = v_body_2493;
      break;
    }
    default: heff_nomatch(v_cod_2421);
    }
    V v_a_2498;
    switch (heff_tag_of(v_x1_2494)) {
    case TAG_Nom: {
      V v_x_2495 = heff_field(v_x1_2494, 0);
      heff_take_n(v_x1_2494, 1ULL, 1);
      v_a_2498 = v_x_2495;
      break;
    }
    case TAG_Describe: {
      heff_take_n(v_x1_2494, 0ULL, 1);
      v_a_2498 = heff_abandon();
      break;
    }
    case TAG_Become: {
      V v_x_2497 = heff_field(v_x1_2494, 0);
      heff_take_n(v_x1_2494, 1ULL, 1);
      v_a_2498 = v_x_2497;
      break;
    }
    default: heff_nomatch(v_x1_2494);
    }
    V v_f_2499 = v_field_2488;
    V v_t_24100 = heff_dup(heff_rfield(v_e_244, 2));
    V v_t_24103;
    switch (heff_tag_of(v_t_24100)) {
    case TAG_ForNominative: {
      v_t_24103 = NTAG(TAG_ForNominative);
      break;
    }
    case TAG_ForDescriptive: {
      V v_h_24101 = heff_field(v_t_24100, 0);
      V v_sp_24102 = heff_field(v_t_24100, 1);
      V v_ru_24t_24100_24ForDescriptive = heff_take_reuse_n(v_t_24100, 3ULL, 2);
      v_t_24103 = heff_tag_at_n(v_ru_24t_24100_24ForDescriptive, TAG_ForDescriptive, 2, (V[]){v_h_24101, heff_tag_n(TAG_SpApp, 2, (V[]){v_sp_24102, heff_dup(v_v_2485)})});
      break;
    }
    default: heff_nomatch(v_t_24100);
    }
    V v_t_24104 = heff_intAdd(heff_dup(heff_rfield(v_e_244, 3)), MK_INT(1LL));
    V v_t_24110;
    switch (heff_tag_of(v_implicit_2422)) {
    case TAG_Expl: {
      heff_drop(v_v_2485);
      heff_drop(v_fdom_2420);
      v_t_24110 = heff_dup(heff_rfield(v_e_244, 5));
      break;
    }
    case TAG_Impl: {
      heff_drop(v_v_2485);
      heff_drop(v_fdom_2420);
      v_t_24110 = heff_dup(heff_rfield(v_e_244, 5));
      break;
    }
    case TAG_Inst: {
      V v_t_24109;
      switch (heff_tag_of(v_cod_2421)) {
      case TAG_MkClo: {
        V v_n_24105 = heff_dup(heff_field(v_cod_2421, 0));
        v_t_24109 = v_n_24105;
        break;
      }
      case TAG_CloConst: {
        v_t_24109 = ((V)&g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_str2);
        break;
      }
      default: heff_nomatch(v_cod_2421);
      }
      v_t_24110 = heff_tag_n(TAG_Cons, 2, (V[]){heff_rec_n(3, shape_name__ty__v, (V[]){v_t_24109, v_fdom_2420, v_v_2485}), heff_dup(heff_rfield(v_e_244, 5))});
      break;
    }
    default: heff_nomatch(v_implicit_2422);
    }
    V v_t_24111 = heff_rec_n(6, shape_scope__globals__elabFor__lams__self__insts, (V[]){v_scope_27_2486, heff_dup(heff_rfield(v_e_244, 1)), v_t_24103, v_t_24104, heff_dup(heff_rfield(v_e_244, 4)), v_t_24110});
    V v_c_24112 = heff_tr(heff_call(v_f_2499, 2, (V[]){v_t_24111, v_a_2498}));
    return heff_clo_n(g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_lam14, 2, 4, (V[]){v_c_24112, v_e_244, v_x_2412, v_cod_2421});
  }
}
V g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_lam2(V self, V *args) {
  V v_x_2412 = args[0];
  V v_sp_240 = heff_env(self)[0];
  V v_hd_246 = heff_env(self)[1];
  V v_k_247 = heff_env(self)[2];
  V v_dom_242 = heff_env(self)[3];
  V v_e_244 = heff_env(self)[4];
  V v_x_241 = heff_env(self)[5];
  V v_body_243 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2413 = (g_heff_2eelab_2evalue_2ebehavior(heff_dup(v_x_2412)));
  switch (heff_tag_of(v_t_2413)) {
  case TAG_LikeU: {
    V v_ru_24t_2413_24LikeU = heff_take_reuse_n(v_t_2413, 0ULL, 1);
    heff_drop(v_x_2412);
    heff_drop(v_dom_242);
    heff_drop_rec(v_e_244, 6);
    heff_drop(v_x_241);
    heff_drop(v_body_243);
    V v_t_2415 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(301LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_str0), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2416 = heff_tag_at_n(v_ru_24t_2413_24LikeU, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2415})});
    V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
    V v_t_2418 = heff_tr(heff_call(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_2417}));
    V f_ = heff_get_n(v_hd_246, 1, 3);
    heff_room[0] = v_t_2418;
    heff_room[1] = v_k_247;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_LikeFunction: {
    V v_fdom_2420 = heff_field(v_t_2413, 1);
    V v_cod_2421 = heff_field(v_t_2413, 2);
    V v_implicit_2422 = heff_field(v_t_2413, 3);
    heff_take_n(v_t_2413, 14ULL, 4);
    V v_t_2423;
    switch (heff_tag_of(v_implicit_2422)) {
    case TAG_Expl: {
      v_t_2423 = NTAG(TAG_True);
      break;
    }
    case TAG_Impl: {
      v_t_2423 = NTAG(TAG_False);
      break;
    }
    case TAG_Inst: {
      v_t_2423 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_implicit_2422);
    }
    if ((heff_dup(v_t_2423) == NTAG(TAG_True))) {
      heff_drop(v_implicit_2422);
      heff_drop(v_t_2423);
      V v_c_2425;
      switch (heff_tag_of(v_dom_242)) {
      case TAG_MkTyp: {
        V v_f_2424 = heff_field(v_dom_242, 0);
        heff_take_n(v_dom_242, 1ULL, 1);
        v_c_2425 = heff_tr(heff_call(v_f_2424, 1, (V[]){heff_dup(v_e_244)}));
        break;
      }
      default: heff_nomatch(v_dom_242);
      }
      V f_ = v_c_2425;
      heff_room[0] = heff_dup(v_hd_246);
      heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_lam3, 1, 9, (V[]){v_e_244, v_fdom_2420, v_sp_240, v_x_241, v_cod_2421, v_body_243, v_x_2412, v_hd_246, v_k_247});
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    } else {
      heff_drop(v_t_2423);
      V v_t_2484;
      switch (heff_tag_of(v_cod_2421)) {
      case TAG_MkClo: {
        V v_n_2480 = heff_dup(heff_field(v_cod_2421, 0));
        v_t_2484 = v_n_2480;
        break;
      }
      case TAG_CloConst: {
        v_t_2484 = ((V)&g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_str1);
        break;
      }
      default: heff_nomatch(v_cod_2421);
      }
      V v_t_24130 = heff_tr(g_heff_2eelab_2eenvironment_2ewithBound(v_t_2484, heff_dup(v_fdom_2420), heff_dup(heff_rfield(v_e_244, 0)), heff_clo_n(g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_lam12, 2, 9, (V[]){v_sp_240, v_x_241, v_dom_242, v_body_243, v_cod_2421, v_e_244, v_implicit_2422, v_fdom_2420, v_x_2412})));
      V f_ = v_t_24130;
      heff_room[0] = v_hd_246;
      heff_room[1] = v_k_247;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
  }
  case TAG_LikeRecord: {
    heff_take_n(v_t_2413, 0ULL, 3);
    heff_drop(v_x_2412);
    heff_drop(v_dom_242);
    heff_drop_rec(v_e_244, 6);
    heff_drop(v_x_241);
    heff_drop(v_body_243);
    V v_t_24134 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(301LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_str4), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_24135 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24134})});
    V v_t_24136 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24135})});
    V v_t_24137 = heff_tr(heff_call(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_24136}));
    V f_ = heff_get_n(v_hd_246, 1, 3);
    heff_room[0] = v_t_24137;
    heff_room[1] = v_k_247;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_LikeSum: {
    V v_ru_24t_2413_24LikeSum = heff_take_reuse_n(v_t_2413, 0ULL, 1);
    heff_drop(v_x_2412);
    heff_drop(v_dom_242);
    heff_drop_rec(v_e_244, 6);
    heff_drop(v_x_241);
    heff_drop(v_body_243);
    V v_t_24139 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(301LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_str5), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_24140 = heff_tag_at_n(v_ru_24t_2413_24LikeSum, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24139})});
    V v_t_24141 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24140})});
    V v_t_24142 = heff_tr(heff_call(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_24141}));
    V f_ = heff_get_n(v_hd_246, 1, 3);
    heff_room[0] = v_t_24142;
    heff_room[1] = v_k_247;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_LikeInt: {
    heff_drop(v_x_2412);
    heff_drop(v_dom_242);
    heff_drop_rec(v_e_244, 6);
    heff_drop(v_x_241);
    heff_drop(v_body_243);
    V v_t_24143 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(301LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_str6), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_24144 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24143})});
    V v_t_24145 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24144})});
    V v_t_24146 = heff_tr(heff_call(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_24145}));
    V f_ = heff_get_n(v_hd_246, 1, 3);
    heff_room[0] = v_t_24146;
    heff_room[1] = v_k_247;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_LikeFloat: {
    heff_drop(v_x_2412);
    heff_drop(v_dom_242);
    heff_drop_rec(v_e_244, 6);
    heff_drop(v_x_241);
    heff_drop(v_body_243);
    V v_t_24147 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(301LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_str7), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_24148 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24147})});
    V v_t_24149 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24148})});
    V v_t_24150 = heff_tr(heff_call(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_24149}));
    V f_ = heff_get_n(v_hd_246, 1, 3);
    heff_room[0] = v_t_24150;
    heff_room[1] = v_k_247;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_LikeString: {
    heff_drop(v_x_2412);
    heff_drop(v_dom_242);
    heff_drop_rec(v_e_244, 6);
    heff_drop(v_x_241);
    heff_drop(v_body_243);
    V v_t_24151 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(301LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_str8), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_24152 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24151})});
    V v_t_24153 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24152})});
    V v_t_24154 = heff_tr(heff_call(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_24153}));
    V f_ = heff_get_n(v_hd_246, 1, 3);
    heff_room[0] = v_t_24154;
    heff_room[1] = v_k_247;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_LikeRune: {
    heff_drop(v_x_2412);
    heff_drop(v_dom_242);
    heff_drop_rec(v_e_244, 6);
    heff_drop(v_x_241);
    heff_drop(v_body_243);
    V v_t_24155 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(301LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_str9), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_24156 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24155})});
    V v_t_24157 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24156})});
    V v_t_24158 = heff_tr(heff_call(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_24157}));
    V f_ = heff_get_n(v_hd_246, 1, 3);
    heff_room[0] = v_t_24158;
    heff_room[1] = v_k_247;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_LikeArray: {
    V v_ru_24t_2413_24LikeArray = heff_take_reuse_n(v_t_2413, 0ULL, 1);
    heff_drop(v_x_2412);
    heff_drop(v_dom_242);
    heff_drop_rec(v_e_244, 6);
    heff_drop(v_x_241);
    heff_drop(v_body_243);
    V v_t_24160 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(301LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_str10), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_24161 = heff_tag_at_n(v_ru_24t_2413_24LikeArray, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24160})});
    V v_t_24162 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24161})});
    V v_t_24163 = heff_tr(heff_call(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_24162}));
    V f_ = heff_get_n(v_hd_246, 1, 3);
    heff_room[0] = v_t_24163;
    heff_room[1] = v_k_247;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_LikeFixed: {
    V v_ru_24t_2413_24LikeFixed = heff_take_reuse_n(v_t_2413, 0ULL, 1);
    heff_drop(v_x_2412);
    heff_drop(v_dom_242);
    heff_drop_rec(v_e_244, 6);
    heff_drop(v_x_241);
    heff_drop(v_body_243);
    V v_t_24165 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(301LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_str11), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_24166 = heff_tag_at_n(v_ru_24t_2413_24LikeFixed, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24165})});
    V v_t_24167 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24166})});
    V v_t_24168 = heff_tr(heff_call(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_24167}));
    V f_ = heff_get_n(v_hd_246, 1, 3);
    heff_room[0] = v_t_24168;
    heff_room[1] = v_k_247;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_NoRules: {
    heff_drop(v_x_2412);
    heff_drop(v_dom_242);
    heff_drop_rec(v_e_244, 6);
    heff_drop(v_x_241);
    heff_drop(v_body_243);
    V v_t_24169 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(301LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_str12), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_24170 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24169})});
    V v_t_24171 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24170})});
    V v_t_24172 = heff_tr(heff_call(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_24171}));
    V f_ = heff_get_n(v_hd_246, 1, 3);
    heff_room[0] = v_t_24172;
    heff_room[1] = v_k_247;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_t_2413);
  }
}
V g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_lam0(V self, V *args) {
  V v_e_244 = args[0];
  V v_a0_245 = args[1];
  V v_hd_246 = args[2];
  V v_k_247 = args[3];
  V v_sp_240 = heff_env(self)[0];
  V v_dom_242 = heff_env(self)[1];
  V v_x_241 = heff_env(self)[2];
  V v_body_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_lam1, 1, 1, (V[]){v_a0_245})})});
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_246, 2)), 1, (V[]){v_t_2410}));
  V f_ = heff_dup(heff_rfield(v_hd_246, 1));
  args[0] = v_t_2411;
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_lam2, 1, 7, (V[]){v_sp_240, v_hd_246, v_k_247, v_dom_242, v_e_244, v_x_241, v_body_243});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2eelab_2erules_2edelayedCheck_str0, 5, "this ");
HEFF_LIT(g_heff_2eelab_2erules_2edelayedCheck_str1, 28, " does not fit how it is used");
V g_heff_2eelab_2erules_2edelayedCheck_lam2(V self, V *args);
V g_heff_2eelab_2erules_2edelayedCheck_lam1(V self, V *args);
V g_heff_2eelab_2erules_2edelayedCheck_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2edelayedCheck_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2edelayedCheck_entry, 7, 0};

V g_heff_2eelab_2erules_2edelayedCheck(V v_e_240, V v_sp_241, V v_what_242, V v_c_243, V v_ty_244, V v_m_245, V v_hole_246) {
top: ;
  V v_c_248;
  switch (heff_tag_of(v_c_243)) {
  case TAG_MkChk: {
    V v_f_247 = heff_field(v_c_243, 0);
    v_c_248 = heff_tr(heff_call(heff_dup(v_f_247), 2, (V[]){heff_dup(v_e_240), v_ty_244}));
    break;
  }
  default: heff_nomatch(v_c_243);
  }
  return heff_clo_n(g_heff_2eelab_2erules_2edelayedCheck_lam0, 2, 6, (V[]){v_c_248, v_e_240, v_m_245, v_hole_246, v_what_242, v_sp_241});
}
V g_heff_2eelab_2erules_2edelayedCheck_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2eelab_2erules_2edelayedCheck(a[0], a[1], a[2], a3, a[4], a[5], a[6]); heff_drop(a3); return r;
}
V g_heff_2eelab_2erules_2edelayedCheck_lam2(V self, V *args) {
  V v_x_2419 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_what_242 = heff_env(self)[1];
  V v_sp_241 = heff_env(self)[2];
  V v_hd_249 = heff_env(self)[3];
  V v_k_2410 = heff_env(self)[4];
  heff_clo_take(self, 5);
  switch (heff_tag_of(v_x_2419)) {
  case TAG_Left: {
    V v_err_2420 = heff_field(v_x_2419, 0);
    V v_ru_24x_2419_24Left = heff_take_reuse_n(v_x_2419, 1ULL, 1);
    V v_note_2421 = ({ V a_0 = heff_get_n(v_e_240, 1, 6); V a_1 = v_err_2420; V r_ = (g_heff_2eelab_2erules_2eprettyEqErr(a_0, a_1)); heff_drop(v_err_2420); r_; });
    V v_t_2422 = heff_strAppend(((V)&g_heff_2eelab_2erules_2edelayedCheck_str0), heff_strAppend(v_what_242, ((V)&g_heff_2eelab_2erules_2edelayedCheck_str1)));
    V v_t_2423 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(311LL), NTAG(TAG_SError), v_t_2422, v_sp_241, heff_tag_n(TAG_Just, 1, (V[]){v_note_2421})});
    V v_t_2424 = heff_tag_at_n(v_ru_24x_2419_24Left, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2423})});
    V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
    V v_t_2426 = heff_tr(heff_call(heff_take_field(v_hd_249, 2), 1, (V[]){v_t_2425}));
    V f_ = heff_get_n(v_hd_249, 1, 3);
    heff_room[0] = v_t_2426;
    heff_room[1] = v_k_2410;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_Right: {
    heff_take_n(v_x_2419, 0ULL, 1);
    heff_drop_rec(v_e_240, 6);
    heff_drop(v_what_242);
    heff_drop(v_sp_241);
    heff_drop_rec(v_hd_249, 3);
    V f_ = v_k_2410;
    args[0] = NTAG(TAG_MkUnit);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_2419);
  }
}
V g_heff_2eelab_2erules_2edelayedCheck_lam1(V self, V *args) {
  V v_x_2411 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_m_245 = heff_env(self)[1];
  V v_hole_246 = heff_env(self)[2];
  V v_hd_249 = heff_env(self)[3];
  V v_what_242 = heff_env(self)[4];
  V v_sp_241 = heff_env(self)[5];
  V v_k_2410 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_x1_2412 = heff_tr(heff_call(heff_take_field(v_x_2411, 1), 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_t_2416;
  switch (heff_tag_of(v_x1_2412)) {
  case TAG_Nom: {
    V v_x_2413 = heff_field(v_x1_2412, 0);
    heff_take_n(v_x1_2412, 1ULL, 1);
    v_t_2416 = v_x_2413;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2412, 0ULL, 1);
    v_t_2416 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2415 = heff_field(v_x1_2412, 0);
    heff_take_n(v_x1_2412, 1ULL, 1);
    v_t_2416 = v_x_2415;
    break;
  }
  default: heff_nomatch(v_x1_2412);
  }
  V v_c_2417 = heff_dup(heff_rfield(v_e_240, 0));
  V v_t_2418 = heff_rec_n(2, shape_len__names, (V[]){heff_take_field(v_c_2417, 0), heff_get_n(v_c_2417, 1, 4)});
  return (g_heff_2eelab_2erules_2esolveHole(heff_dup(heff_rfield(v_e_240, 1)), v_t_2418, v_m_245, heff_get_n(v_hole_246, 1, 2), heff_get_n(v_x_2411, 0, 2), v_t_2416, heff_dup(v_hd_249), heff_clo_n(g_heff_2eelab_2erules_2edelayedCheck_lam2, 1, 5, (V[]){v_e_240, v_what_242, v_sp_241, v_hd_249, v_k_2410})));
}
V g_heff_2eelab_2erules_2edelayedCheck_lam0(V self, V *args) {
  V v_hd_249 = args[0];
  V v_k_2410 = args[1];
  V v_c_248 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_m_245 = heff_env(self)[2];
  V v_hole_246 = heff_env(self)[3];
  V v_what_242 = heff_env(self)[4];
  V v_sp_241 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V f_ = v_c_248;
  args[0] = heff_dup(v_hd_249);
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2edelayedCheck_lam1, 1, 7, (V[]){v_e_240, v_m_245, v_hole_246, v_hd_249, v_what_242, v_sp_241, v_k_2410});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
Clo g_heff_2eelab_2erules_2especialized_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2especialized_entry, 7, 0};

V g_heff_2eelab_2erules_2especialized(V v_e_240, V v_v_241, V v_a_242, V v_a_27_243, V v_err_244, V v_p_245, V v_p_246) {
top: ;
  switch (heff_tag_of(v_a_242)) {
  case TAG_VU: {
    heff_drop(v_e_240);
    heff_drop(v_v_241);
    heff_drop(v_a_27_243);
    heff_drop(v_p_245);
    return heff_tail(v_p_246, 1, (V[]){v_err_244});
  }
  case TAG_VDecode: {
    V v_h_248 = heff_field(v_a_242, 0);
    V v_sp_249 = heff_field(v_a_242, 1);
    V v_u_2410 = heff_field(v_a_242, 2);
    V v_described_2411 = heff_field(v_a_242, 3);
    V v_el_2412 = heff_field(v_a_242, 4);
    return (g_heff_2eelab_2erules_2especializedGo(v_e_240, v_v_241, v_a_27_243, heff_dup(v_h_248), v_sp_249, heff_dup(v_u_2410), heff_dup(v_described_2411), heff_dup(v_el_2412), NTAG(TAG_Nil), v_err_244, v_p_245, v_p_246));
  }
  case TAG_VFunction: {
    heff_drop(v_e_240);
    heff_drop(v_v_241);
    heff_drop(v_a_27_243);
    heff_drop(v_p_245);
    return heff_tail(v_p_246, 1, (V[]){v_err_244});
  }
  case TAG_VRecord: {
    heff_drop(v_e_240);
    heff_drop(v_v_241);
    heff_drop(v_a_27_243);
    heff_drop(v_p_245);
    return heff_tail(v_p_246, 1, (V[]){v_err_244});
  }
  case TAG_VSum: {
    heff_drop(v_e_240);
    heff_drop(v_v_241);
    heff_drop(v_a_27_243);
    heff_drop(v_p_245);
    return heff_tail(v_p_246, 1, (V[]){v_err_244});
  }
  case TAG_VPrimInt: {
    heff_drop(v_e_240);
    heff_drop(v_v_241);
    heff_drop(v_a_27_243);
    heff_drop(v_p_245);
    return heff_tail(v_p_246, 1, (V[]){v_err_244});
  }
  case TAG_VPrimFloat: {
    heff_drop(v_e_240);
    heff_drop(v_v_241);
    heff_drop(v_a_27_243);
    heff_drop(v_p_245);
    return heff_tail(v_p_246, 1, (V[]){v_err_244});
  }
  case TAG_VPrimString: {
    heff_drop(v_e_240);
    heff_drop(v_v_241);
    heff_drop(v_a_27_243);
    heff_drop(v_p_245);
    return heff_tail(v_p_246, 1, (V[]){v_err_244});
  }
  case TAG_VPrimRune: {
    heff_drop(v_e_240);
    heff_drop(v_v_241);
    heff_drop(v_a_27_243);
    heff_drop(v_p_245);
    return heff_tail(v_p_246, 1, (V[]){v_err_244});
  }
  case TAG_VPrimArray: {
    heff_drop(v_e_240);
    heff_drop(v_v_241);
    heff_drop(v_a_27_243);
    heff_drop(v_p_245);
    return heff_tail(v_p_246, 1, (V[]){v_err_244});
  }
  case TAG_VFixed: {
    heff_drop(v_e_240);
    heff_drop(v_v_241);
    heff_drop(v_a_27_243);
    heff_drop(v_p_245);
    return heff_tail(v_p_246, 1, (V[]){v_err_244});
  }
  default: return heff_nomatch(v_a_242);
  }
}
V g_heff_2eelab_2erules_2especialized_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2eelab_2erules_2especialized(a[0], a[1], a2, a[3], a[4], a[5], a[6]); heff_drop(a2); return r;
}

HeffT2 g_heff_2eelab_2erules_2elookupP_24cpr(V v_x1_240, V v_x_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_x11_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_MkPair: {
      V v_y_244 = heff_field(v_x11_242, 0);
      V v_v_245 = heff_field(v_x11_242, 1);
      heff_take_n(v_x11_242, 3ULL, 2);
      if (heff_strEq_c_lent(v_y_244, v_x_241, 1)) {
        heff_drop(v_rest_243);
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_v_245}});
      } else {
        heff_drop(v_v_245);
        V t_0 = v_rest_243;
        V t_1 = v_x_241;
        v_x1_240 = t_0;
        v_x_241 = t_1;
        goto top;
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x11_242)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
Clo g_heff_2eelab_2erules_2eletsAround_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eletsAround_entry, 5, 0};

V g_heff_2eelab_2erules_2eletsAround(V v_n_240, V v_a_241, V v_x3_242, V v_p_243, V v_body_244) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_n_240);
    heff_drop(v_a_241);
    heff_drop(v_p_243);
    return v_body_244;
  }
  case TAG_Cons: {
    V v_x31_245 = heff_field(v_x3_242, 0);
    V v_rest_246 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    switch (heff_tag_of(v_x31_245)) {
    case TAG_MkPair: {
      V v_m_247 = heff_field(v_x31_245, 0);
      V v_v_248 = heff_field(v_x31_245, 1);
      V v_ru_24x31_245_24MkPair = heff_take_reuse_n(v_x31_245, 3ULL, 2);
      V v_t_249 = (g_heff_2eelab_2evalue_2elevelOf(v_a_241));
      V v_t_2410 = (g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(heff_intAdd(heff_dup(v_n_240), heff_dup(v_p_243)), heff_take_field(v_m_247, 1)));
      V v_t_2411 = (g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(heff_intAdd(heff_dup(v_n_240), heff_dup(v_p_243)), heff_dup(v_a_241)));
      V v_t_2412 = heff_tag_n(TAG_SFunction, 5, (V[]){v_t_249, v_t_2410, heff_tag_n(TAG_AbsConst, 1, (V[]){v_t_2411}), NTAG(TAG_Expl), NTAG(TAG_Nothing)});
      V v_t_2413 = (g_heff_2eelab_2erules_2eletsAround(v_n_240, v_a_241, v_rest_246, heff_intAdd(v_p_243, MK_INT(1LL)), v_body_244));
      V v_t_2414 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_MkAbs, 2, (V[]){heff_get_n(v_m_247, 0, 5), v_t_2413});
      return heff_tag_at_n(v_ru_24x31_245_24MkPair, TAG_SApp, 2, (V[]){heff_tag_n(TAG_SLam, 2, (V[]){v_t_2412, v_t_2414}), v_v_248});
    }
    default: return heff_nomatch(v_x31_245);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2eelab_2erules_2eletsAround_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2eletsAround(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2eelab_2erules_2elettedAt_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2elettedAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2elettedAt_entry, 8, 0};

V g_heff_2eelab_2erules_2elettedAt(V v_e_240, V v_a_241, V v_made_242, V v_record_243, V v_bound_244, V v_places_245, V v_z_246, V v_z_247) {
top: ;
  V v_c_248 = (g_heff_2eelab_2erules_2edescribedBound(v_made_242, v_bound_244));
  return heff_tail(v_c_248, 2, (V[]){v_z_246, heff_clo_n(g_heff_2eelab_2erules_2elettedAt_lam0, 1, 7, (V[]){v_e_240, v_places_245, v_made_242, heff_dup(v_bound_244), v_a_241, v_record_243, v_z_247})});
}
V g_heff_2eelab_2erules_2elettedAt_entry(V self, V *a) {
  (void)self;
  V a4 = a[4]; V r = g_heff_2eelab_2erules_2elettedAt(a[0], a[1], a[2], a[3], a4, a[5], a[6], a[7]); heff_drop(a4); return r;
}
V g_heff_2eelab_2erules_2elettedAt_lam0(V self, V *args) {
  V v_x_249 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_places_245 = heff_env(self)[1];
  V v_made_242 = heff_env(self)[2];
  V v_bound_244 = heff_env(self)[3];
  V v_a_241 = heff_env(self)[4];
  V v_record_243 = heff_env(self)[5];
  V v_z_247 = heff_env(self)[6];
  heff_clo_take(self, 7);
  heff_drop(v_x_249);
  V v_t_2410 = heff_get_n(heff_dup(heff_rfield(v_e_240, 0)), 0, 4);
  V v_t_2411 = heff_get_n(heff_dup(heff_rfield(v_e_240, 0)), 0, 4);
  V v_t_2412 = (g_heff_2eelab_2erules_2evaluesGo(v_t_2411, heff_dup(v_places_245), heff_dup(v_made_242), heff_dup(v_places_245), MK_INT(0LL)));
  V v_t_2413 = heff_get_n(heff_get_n(v_e_240, 0, 6), 0, 4);
  V v_t_2414 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_bound_244; V r_ = (g_list_2efoldl_24f625837968x2121675523(a_0, a_1, a_2)); heff_drop(v_bound_244); r_; });
  V v_pairs_2415 = (g_heff_2eelab_2erules_2eentriesGo(v_t_2413, v_t_2414, heff_dup(v_places_245), v_made_242, v_places_245, MK_INT(0LL)));
  V v_t_2416 = (g_list_2emap_24s1937570095x2110149801(heff_dup(v_pairs_2415)));
  V v_t_2417 = (g_heff_2eutil_2edict_2eindexed(MK_INT(0LL), v_pairs_2415));
  V v_t_2418 = (g_list_2emap_24s1173914895x100384474(v_pairs_2415));
  V v_t_2419 = heff_rec_n(3, shape_keys__byName__values, (V[]){heff_arrayFromList(v_t_2416), v_t_2417, heff_arrayFromList(v_t_2418)});
  V v_t_2420 = (g_heff_2eelab_2erules_2eletsAround(v_t_2410, v_a_241, v_t_2412, MK_INT(0LL), heff_tag_n(TAG_SCons, 1, (V[]){v_t_2419})));
  V v_x_2421 = ({ V rv_0 = v_t_2420; V rr_ = heff_rec_reuse_nf(v_record_243, 2ULL, 2, shape_stx__val, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
  V f_ = v_z_247;
  args[0] = v_x_2421;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
HEFF_LIT(g_heff_2eelab_2erules_2esumIntroNow_24cpr_str0, 74, "cannot check tag syntax at a type that is not known: annotate it, as in `(");
HEFF_LIT(g_heff_2eelab_2erules_2esumIntroNow_24cpr_str1, 10, " ... : T)`");
HEFF_LIT(g_heff_2eelab_2erules_2esumIntroNow_24cpr_str2, 18, ", but got the tag ");
HEFF_LIT(g_heff_2eelab_2erules_2esumIntroNow_24cpr_str3, 14, "expected type ");
HEFF_LIT(g_heff_2eelab_2erules_2esumIntroNow_24cpr_str4, 63, " names no definition or binder in scope, so it is read as a tag");
HEFF_LIT(g_heff_2eelab_2erules_2esumIntroNow_24cpr_str5, 74, "cannot check tag syntax at a type that is not known: annotate it, as in `(");
HEFF_LIT(g_heff_2eelab_2erules_2esumIntroNow_24cpr_str6, 10, " ... : T)`");
HEFF_LIT(g_heff_2eelab_2erules_2esumIntroNow_24cpr_str7, 18, ", but got the tag ");
HEFF_LIT(g_heff_2eelab_2erules_2esumIntroNow_24cpr_str8, 14, "expected type ");
HEFF_LIT(g_heff_2eelab_2erules_2esumIntroNow_24cpr_str9, 63, " names no definition or binder in scope, so it is read as a tag");
HEFF_LIT(g_heff_2eelab_2erules_2esumIntroNow_24cpr_str10, 74, "cannot check tag syntax at a type that is not known: annotate it, as in `(");
HEFF_LIT(g_heff_2eelab_2erules_2esumIntroNow_24cpr_str11, 10, " ... : T)`");
HEFF_LIT(g_heff_2eelab_2erules_2esumIntroNow_24cpr_str12, 18, ", but got the tag ");
HEFF_LIT(g_heff_2eelab_2erules_2esumIntroNow_24cpr_str13, 14, "expected type ");
HEFF_LIT(g_heff_2eelab_2erules_2esumIntroNow_24cpr_str14, 63, " names no definition or binder in scope, so it is read as a tag");
HEFF_LIT(g_heff_2eelab_2erules_2esumIntroNow_24cpr_str15, 9, " in type ");
HEFF_LIT(g_heff_2eelab_2erules_2esumIntroNow_24cpr_str16, 12, "no such tag ");
HEFF_LIT(g_heff_2eelab_2erules_2esumIntroNow_24cpr_str17, 9, " in type ");
HEFF_LIT(g_heff_2eelab_2erules_2esumIntroNow_24cpr_str18, 34, "wrong number of arguments for tag ");
HEFF_LIT(g_heff_2eelab_2erules_2esumIntroNow_24cpr_str19, 74, "cannot check tag syntax at a type that is not known: annotate it, as in `(");
HEFF_LIT(g_heff_2eelab_2erules_2esumIntroNow_24cpr_str20, 10, " ... : T)`");
HEFF_LIT(g_heff_2eelab_2erules_2esumIntroNow_24cpr_str21, 18, ", but got the tag ");
HEFF_LIT(g_heff_2eelab_2erules_2esumIntroNow_24cpr_str22, 14, "expected type ");
HEFF_LIT(g_heff_2eelab_2erules_2esumIntroNow_24cpr_str23, 63, " names no definition or binder in scope, so it is read as a tag");
HEFF_LIT(g_heff_2eelab_2erules_2esumIntroNow_24cpr_str24, 74, "cannot check tag syntax at a type that is not known: annotate it, as in `(");
HEFF_LIT(g_heff_2eelab_2erules_2esumIntroNow_24cpr_str25, 10, " ... : T)`");
HEFF_LIT(g_heff_2eelab_2erules_2esumIntroNow_24cpr_str26, 18, ", but got the tag ");
HEFF_LIT(g_heff_2eelab_2erules_2esumIntroNow_24cpr_str27, 14, "expected type ");
HEFF_LIT(g_heff_2eelab_2erules_2esumIntroNow_24cpr_str28, 63, " names no definition or binder in scope, so it is read as a tag");
HEFF_LIT(g_heff_2eelab_2erules_2esumIntroNow_24cpr_str29, 74, "cannot check tag syntax at a type that is not known: annotate it, as in `(");
HEFF_LIT(g_heff_2eelab_2erules_2esumIntroNow_24cpr_str30, 10, " ... : T)`");
HEFF_LIT(g_heff_2eelab_2erules_2esumIntroNow_24cpr_str31, 18, ", but got the tag ");
HEFF_LIT(g_heff_2eelab_2erules_2esumIntroNow_24cpr_str32, 14, "expected type ");
HEFF_LIT(g_heff_2eelab_2erules_2esumIntroNow_24cpr_str33, 63, " names no definition or binder in scope, so it is read as a tag");
HEFF_LIT(g_heff_2eelab_2erules_2esumIntroNow_24cpr_str34, 74, "cannot check tag syntax at a type that is not known: annotate it, as in `(");
HEFF_LIT(g_heff_2eelab_2erules_2esumIntroNow_24cpr_str35, 10, " ... : T)`");
HEFF_LIT(g_heff_2eelab_2erules_2esumIntroNow_24cpr_str36, 18, ", but got the tag ");
HEFF_LIT(g_heff_2eelab_2erules_2esumIntroNow_24cpr_str37, 14, "expected type ");
HEFF_LIT(g_heff_2eelab_2erules_2esumIntroNow_24cpr_str38, 63, " names no definition or binder in scope, so it is read as a tag");
HEFF_LIT(g_heff_2eelab_2erules_2esumIntroNow_24cpr_str39, 74, "cannot check tag syntax at a type that is not known: annotate it, as in `(");
HEFF_LIT(g_heff_2eelab_2erules_2esumIntroNow_24cpr_str40, 10, " ... : T)`");
HEFF_LIT(g_heff_2eelab_2erules_2esumIntroNow_24cpr_str41, 18, ", but got the tag ");
HEFF_LIT(g_heff_2eelab_2erules_2esumIntroNow_24cpr_str42, 14, "expected type ");
HEFF_LIT(g_heff_2eelab_2erules_2esumIntroNow_24cpr_str43, 63, " names no definition or binder in scope, so it is read as a tag");
HEFF_LIT(g_heff_2eelab_2erules_2esumIntroNow_24cpr_str44, 74, "cannot check tag syntax at a type that is not known: annotate it, as in `(");
HEFF_LIT(g_heff_2eelab_2erules_2esumIntroNow_24cpr_str45, 10, " ... : T)`");
HEFF_LIT(g_heff_2eelab_2erules_2esumIntroNow_24cpr_str46, 18, ", but got the tag ");
HEFF_LIT(g_heff_2eelab_2erules_2esumIntroNow_24cpr_str47, 14, "expected type ");
HEFF_LIT(g_heff_2eelab_2erules_2esumIntroNow_24cpr_str48, 63, " names no definition or binder in scope, so it is read as a tag");
HEFF_LIT(g_heff_2eelab_2erules_2esumIntroNow_24cpr_str49, 74, "cannot check tag syntax at a type that is not known: annotate it, as in `(");
HEFF_LIT(g_heff_2eelab_2erules_2esumIntroNow_24cpr_str50, 10, " ... : T)`");
HEFF_LIT(g_heff_2eelab_2erules_2esumIntroNow_24cpr_str51, 18, ", but got the tag ");
HEFF_LIT(g_heff_2eelab_2erules_2esumIntroNow_24cpr_str52, 14, "expected type ");
HEFF_LIT(g_heff_2eelab_2erules_2esumIntroNow_24cpr_str53, 63, " names no definition or binder in scope, so it is read as a tag");
V g_heff_2eelab_2erules_2esumIntroNow_24cpr_lam1(V self, V *args);
V g_heff_2eelab_2erules_2esumIntroNow_24cpr_lam5(V self, V *args);
V g_heff_2eelab_2erules_2esumIntroNow_24cpr_lam6(V self, V *args); static Clo g_heff_2eelab_2erules_2esumIntroNow_24cpr_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2esumIntroNow_24cpr_lam6, 1, 0};
V g_heff_2eelab_2erules_2esumIntroNow_24cpr_lam4(V self, V *args);
V g_heff_2eelab_2erules_2esumIntroNow_24cpr_lam3(V self, V *args);
V g_heff_2eelab_2erules_2esumIntroNow_24cpr_lam2(V self, V *args);
V g_heff_2eelab_2erules_2esumIntroNow_24cpr_lam0(V self, V *args);

HeffT1 g_heff_2eelab_2erules_2esumIntroNow_24cpr(V v_sp_240, V v_tsp_241, V v_x_242, V v_cs_243) {
top: ;
  return ((HeffT1){{heff_clo_n(g_heff_2eelab_2erules_2esumIntroNow_24cpr_lam0, 4, 4, (V[]){v_x_242, v_sp_240, v_tsp_241, v_cs_243})}});
}
V g_heff_2eelab_2erules_2esumIntroNow_24cpr_lam1(V self, V *args) {
  V v_c_248 = args[0];
  V v_a0_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_c_248, 3, 8); V a_1 = v_a0_245; V r_ = (g_heff_2eelab_2evalue_2eforceTy(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2eelab_2erules_2esumIntroNow_24cpr_lam5(V self, V *args) {
  V v_i_24152 = args[0];
  V v_gs_24151 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_m_24153 = heff_arrayIndex(v_gs_24151, v_i_24152);
  return heff_get_n(v_m_24153, 0, 2);
}
V g_heff_2eelab_2erules_2esumIntroNow_24cpr_lam6(V self, V *args) {
  V v_u_24155 = args[0];
  heff_drop(v_u_24155);
  return heff_tag_n(TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
}
V g_heff_2eelab_2erules_2esumIntroNow_24cpr_lam4(V self, V *args) {
  V v_x_24150 = args[0];
  V v_x_242 = heff_env(self)[0];
  V v_k_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_gs_24151 = heff_arrayFromList(v_x_24150);
  V v_t_24154 = heff_arrayGenerate(heff_arrayLength_lent(v_gs_24151, 0), heff_clo_n(g_heff_2eelab_2erules_2esumIntroNow_24cpr_lam5, 1, 1, (V[]){v_gs_24151}));
  V v_x_24156 = heff_rec_n(2, shape_stx__val, (V[]){heff_tag_n(TAG_STag, 2, (V[]){v_x_242, v_t_24154}), ((V)&g_heff_2eelab_2erules_2esumIntroNow_24cpr_lam6_clo)});
  V f_ = v_k_247;
  args[0] = v_x_24156;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2esumIntroNow_24cpr_lam3(V self, V *args) {
  V v_x_24148 = args[0];
  V v_e_244 = heff_env(self)[0];
  V v_cs_243 = heff_env(self)[1];
  V v_ts_24145 = heff_env(self)[2];
  V v_hd_246 = heff_env(self)[3];
  V v_x_242 = heff_env(self)[4];
  V v_k_247 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_24148);
  V v_c_24149 = (g_heff_2eelab_2erules_2etagArgsGo(v_e_244, v_cs_243, heff_arrayToList(v_ts_24145)));
  V f_ = v_c_24149;
  heff_room[0] = v_hd_246;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2esumIntroNow_24cpr_lam4, 1, 2, (V[]){v_x_242, v_k_247});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2esumIntroNow_24cpr_lam2(V self, V *args) {
  V v_x_2412 = args[0];
  V v_x_242 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  V v_hd_246 = heff_env(self)[2];
  V v_k_247 = heff_env(self)[3];
  V v_e_244 = heff_env(self)[4];
  V v_tsp_241 = heff_env(self)[5];
  V v_cs_243 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2413 = (g_heff_2eelab_2evalue_2ebehavior(heff_dup(v_x_2412)));
  switch (heff_tag_of(v_t_2413)) {
  case TAG_LikeU: {
    V v_ru_24t_2413_24LikeU = heff_take_reuse_n(v_t_2413, 0ULL, 1);
    heff_drop(v_cs_243);
    V v_t_2436;
    switch (heff_tag_of(v_x_2412)) {
    case TAG_VU: {
      v_t_2436 = NTAG(TAG_False);
      break;
    }
    case TAG_VDecode: {
      V v_t1_2416 = heff_dup(heff_field(v_x_2412, 0));
      switch (heff_tag_of(v_t1_2416)) {
      case TAG_HLocal: {
        heff_take_n(v_t1_2416, 0ULL, 1);
        v_t_2436 = NTAG(TAG_False);
        break;
      }
      case TAG_HGlobal: {
        heff_take_n(v_t1_2416, 0ULL, 1);
        v_t_2436 = NTAG(TAG_False);
        break;
      }
      case TAG_HMeta: {
        heff_take_n(v_t1_2416, 0ULL, 1);
        v_t_2436 = NTAG(TAG_True);
        break;
      }
      case TAG_HError: {
        v_t_2436 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_t1_2416);
      }
      break;
    }
    case TAG_VFunction: {
      v_t_2436 = NTAG(TAG_False);
      break;
    }
    case TAG_VRecord: {
      v_t_2436 = NTAG(TAG_False);
      break;
    }
    case TAG_VSum: {
      v_t_2436 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimInt: {
      v_t_2436 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimFloat: {
      v_t_2436 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimString: {
      v_t_2436 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimRune: {
      v_t_2436 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimArray: {
      v_t_2436 = NTAG(TAG_False);
      break;
    }
    case TAG_VFixed: {
      v_t_2436 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x_2412);
    }
    if ((heff_dup(v_t_2436) == NTAG(TAG_True))) {
      heff_drop(v_x_2412);
      heff_drop(v_e_244);
      heff_drop(v_tsp_241);
      heff_drop(v_t_2436);
      V v_t_2437 = heff_strAppend(((V)&g_heff_2eelab_2erules_2esumIntroNow_24cpr_str0), heff_strAppend(v_x_242, ((V)&g_heff_2eelab_2erules_2esumIntroNow_24cpr_str1)));
      V v_t_2438 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(314LL), NTAG(TAG_SError), v_t_2437, v_sp_240, NTAG(TAG_Nothing)});
      V v_t_2439 = heff_tag_at_n(v_ru_24t_2413_24LikeU, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2438})});
      V v_t_2440 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2439})});
      V v_t_2441 = heff_tr(heff_call(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_2440}));
      V f_ = heff_get_n(v_hd_246, 1, 3);
      heff_room[0] = v_t_2441;
      heff_room[1] = v_k_247;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    } else {
      heff_drop(v_sp_240);
      heff_drop(v_t_2436);
      V v_t_2442 = (g_heff_2eelab_2erules_2etyStr(v_e_244, v_x_2412));
      V v_t_2443 = heff_strAppend(v_t_2442, heff_strAppend(((V)&g_heff_2eelab_2erules_2esumIntroNow_24cpr_str2), heff_dup(v_x_242)));
      V v_msg_2444 = heff_strAppend(((V)&g_heff_2eelab_2erules_2esumIntroNow_24cpr_str3), v_t_2443);
      V v_t_2445 = heff_tag_at_n(v_ru_24t_2413_24LikeU, TAG_Just, 1, (V[]){heff_strAppend(v_x_242, ((V)&g_heff_2eelab_2erules_2esumIntroNow_24cpr_str4))});
      V v_t_2446 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(314LL), NTAG(TAG_SError), v_msg_2444, v_tsp_241, v_t_2445});
      V v_t_2447 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2446})});
      V v_t_2448 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2447})});
      V v_t_2449 = heff_tr(heff_call(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_2448}));
      V f_ = heff_get_n(v_hd_246, 1, 3);
      heff_room[0] = v_t_2449;
      heff_room[1] = v_k_247;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
  }
  case TAG_LikeFunction: {
    heff_take_n(v_t_2413, 0ULL, 4);
    heff_drop(v_cs_243);
    V v_t_2475;
    switch (heff_tag_of(v_x_2412)) {
    case TAG_VU: {
      v_t_2475 = NTAG(TAG_False);
      break;
    }
    case TAG_VDecode: {
      V v_t1_2455 = heff_dup(heff_field(v_x_2412, 0));
      switch (heff_tag_of(v_t1_2455)) {
      case TAG_HLocal: {
        heff_take_n(v_t1_2455, 0ULL, 1);
        v_t_2475 = NTAG(TAG_False);
        break;
      }
      case TAG_HGlobal: {
        heff_take_n(v_t1_2455, 0ULL, 1);
        v_t_2475 = NTAG(TAG_False);
        break;
      }
      case TAG_HMeta: {
        heff_take_n(v_t1_2455, 0ULL, 1);
        v_t_2475 = NTAG(TAG_True);
        break;
      }
      case TAG_HError: {
        v_t_2475 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_t1_2455);
      }
      break;
    }
    case TAG_VFunction: {
      v_t_2475 = NTAG(TAG_False);
      break;
    }
    case TAG_VRecord: {
      v_t_2475 = NTAG(TAG_False);
      break;
    }
    case TAG_VSum: {
      v_t_2475 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimInt: {
      v_t_2475 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimFloat: {
      v_t_2475 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimString: {
      v_t_2475 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimRune: {
      v_t_2475 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimArray: {
      v_t_2475 = NTAG(TAG_False);
      break;
    }
    case TAG_VFixed: {
      v_t_2475 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x_2412);
    }
    if ((heff_dup(v_t_2475) == NTAG(TAG_True))) {
      heff_drop(v_x_2412);
      heff_drop(v_e_244);
      heff_drop(v_tsp_241);
      heff_drop(v_t_2475);
      V v_t_2476 = heff_strAppend(((V)&g_heff_2eelab_2erules_2esumIntroNow_24cpr_str5), heff_strAppend(v_x_242, ((V)&g_heff_2eelab_2erules_2esumIntroNow_24cpr_str6)));
      V v_t_2477 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(314LL), NTAG(TAG_SError), v_t_2476, v_sp_240, NTAG(TAG_Nothing)});
      V v_t_2478 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2477})});
      V v_t_2479 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2478})});
      V v_t_2480 = heff_tr(heff_call(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_2479}));
      V f_ = heff_get_n(v_hd_246, 1, 3);
      heff_room[0] = v_t_2480;
      heff_room[1] = v_k_247;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    } else {
      heff_drop(v_sp_240);
      heff_drop(v_t_2475);
      V v_t_2481 = (g_heff_2eelab_2erules_2etyStr(v_e_244, v_x_2412));
      V v_t_2482 = heff_strAppend(v_t_2481, heff_strAppend(((V)&g_heff_2eelab_2erules_2esumIntroNow_24cpr_str7), heff_dup(v_x_242)));
      V v_msg_2483 = heff_strAppend(((V)&g_heff_2eelab_2erules_2esumIntroNow_24cpr_str8), v_t_2482);
      V v_t_2484 = heff_tag_n(TAG_Just, 1, (V[]){heff_strAppend(v_x_242, ((V)&g_heff_2eelab_2erules_2esumIntroNow_24cpr_str9))});
      V v_t_2485 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(314LL), NTAG(TAG_SError), v_msg_2483, v_tsp_241, v_t_2484});
      V v_t_2486 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2485})});
      V v_t_2487 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2486})});
      V v_t_2488 = heff_tr(heff_call(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_2487}));
      V f_ = heff_get_n(v_hd_246, 1, 3);
      heff_room[0] = v_t_2488;
      heff_room[1] = v_k_247;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
  }
  case TAG_LikeRecord: {
    heff_take_n(v_t_2413, 0ULL, 3);
    heff_drop(v_cs_243);
    V v_t_24113;
    switch (heff_tag_of(v_x_2412)) {
    case TAG_VU: {
      v_t_24113 = NTAG(TAG_False);
      break;
    }
    case TAG_VDecode: {
      V v_t1_2493 = heff_dup(heff_field(v_x_2412, 0));
      switch (heff_tag_of(v_t1_2493)) {
      case TAG_HLocal: {
        heff_take_n(v_t1_2493, 0ULL, 1);
        v_t_24113 = NTAG(TAG_False);
        break;
      }
      case TAG_HGlobal: {
        heff_take_n(v_t1_2493, 0ULL, 1);
        v_t_24113 = NTAG(TAG_False);
        break;
      }
      case TAG_HMeta: {
        heff_take_n(v_t1_2493, 0ULL, 1);
        v_t_24113 = NTAG(TAG_True);
        break;
      }
      case TAG_HError: {
        v_t_24113 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_t1_2493);
      }
      break;
    }
    case TAG_VFunction: {
      v_t_24113 = NTAG(TAG_False);
      break;
    }
    case TAG_VRecord: {
      v_t_24113 = NTAG(TAG_False);
      break;
    }
    case TAG_VSum: {
      v_t_24113 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimInt: {
      v_t_24113 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimFloat: {
      v_t_24113 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimString: {
      v_t_24113 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimRune: {
      v_t_24113 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimArray: {
      v_t_24113 = NTAG(TAG_False);
      break;
    }
    case TAG_VFixed: {
      v_t_24113 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x_2412);
    }
    if ((heff_dup(v_t_24113) == NTAG(TAG_True))) {
      heff_drop(v_x_2412);
      heff_drop(v_e_244);
      heff_drop(v_tsp_241);
      heff_drop(v_t_24113);
      V v_t_24114 = heff_strAppend(((V)&g_heff_2eelab_2erules_2esumIntroNow_24cpr_str10), heff_strAppend(v_x_242, ((V)&g_heff_2eelab_2erules_2esumIntroNow_24cpr_str11)));
      V v_t_24115 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(314LL), NTAG(TAG_SError), v_t_24114, v_sp_240, NTAG(TAG_Nothing)});
      V v_t_24116 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24115})});
      V v_t_24117 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24116})});
      V v_t_24118 = heff_tr(heff_call(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_24117}));
      V f_ = heff_get_n(v_hd_246, 1, 3);
      heff_room[0] = v_t_24118;
      heff_room[1] = v_k_247;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    } else {
      heff_drop(v_sp_240);
      heff_drop(v_t_24113);
      V v_t_24119 = (g_heff_2eelab_2erules_2etyStr(v_e_244, v_x_2412));
      V v_t_24120 = heff_strAppend(v_t_24119, heff_strAppend(((V)&g_heff_2eelab_2erules_2esumIntroNow_24cpr_str12), heff_dup(v_x_242)));
      V v_msg_24121 = heff_strAppend(((V)&g_heff_2eelab_2erules_2esumIntroNow_24cpr_str13), v_t_24120);
      V v_t_24122 = heff_tag_n(TAG_Just, 1, (V[]){heff_strAppend(v_x_242, ((V)&g_heff_2eelab_2erules_2esumIntroNow_24cpr_str14))});
      V v_t_24123 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(314LL), NTAG(TAG_SError), v_msg_24121, v_tsp_241, v_t_24122});
      V v_t_24124 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24123})});
      V v_t_24125 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24124})});
      V v_t_24126 = heff_tr(heff_call(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_24125}));
      V f_ = heff_get_n(v_hd_246, 1, 3);
      heff_room[0] = v_t_24126;
      heff_room[1] = v_k_247;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
  }
  case TAG_LikeSum: {
    V v_vs_24127 = heff_field(v_t_2413, 0);
    V v_ru_24t_2413_24LikeSum = heff_take_reuse_n(v_t_2413, 1ULL, 1);
    HeffT2 v_t_24128 = (g_std_2emap_2elookup_24s1963842891x1660122411_24cpr(heff_rfield(v_vs_24127, 1), v_x_242));
    V v_t_24137;
    {
      V v_field_24130 = v_t_24128.f[1];
      int64_t v_tag_24129 = ((int64_t)v_t_24128.f[0]);
      if ((v_tag_24129 == ((int64_t)0ULL))) {
        V v_i_24132 = v_field_24130;
        V v_xs_24133 = heff_get_n(v_vs_24127, 2, 3);
        if (heff_intLe_c_lent(MK_INT(0LL), v_i_24132, 1)) {
          if (heff_intLt_c(heff_dup(v_i_24132), heff_arrayLength_lent(v_xs_24133, 0))) {
            V v_t_24136 = heff_arrayIndex(v_xs_24133, v_i_24132);
            v_t_24137 = heff_tag_at_n(v_ru_24t_2413_24LikeSum, TAG_Just, 1, (V[]){v_t_24136});
          } else {
            heff_drop_cell(v_ru_24t_2413_24LikeSum, 1);
            heff_drop(v_i_24132);
            heff_drop(v_xs_24133);
            v_t_24137 = NTAG(TAG_Nothing);
          }
        } else {
          heff_drop_cell(v_ru_24t_2413_24LikeSum, 1);
          heff_drop(v_i_24132);
          heff_drop(v_xs_24133);
          v_t_24137 = NTAG(TAG_Nothing);
        }
      } else {
        heff_drop_rec(v_vs_24127, 3);
        heff_drop_cell(v_ru_24t_2413_24LikeSum, 1);
        heff_drop(v_field_24130);
        v_t_24137 = NTAG(TAG_Nothing);
      }
    }
    switch (heff_tag_of(v_t_24137)) {
    case TAG_Nothing: {
      heff_drop(v_tsp_241);
      heff_drop(v_cs_243);
      V v_t_24138 = (g_heff_2eelab_2erules_2etyStr(v_e_244, v_x_2412));
      V v_t_24139 = heff_strAppend(v_x_242, heff_strAppend(((V)&g_heff_2eelab_2erules_2esumIntroNow_24cpr_str15), v_t_24138));
      V v_msg_24140 = heff_strAppend(((V)&g_heff_2eelab_2erules_2esumIntroNow_24cpr_str16), v_t_24139);
      V v_t_24141 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(315LL), NTAG(TAG_SError), v_msg_24140, v_sp_240, NTAG(TAG_Nothing)});
      V v_t_24142 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24141})});
      V v_t_24143 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24142})});
      V v_t_24144 = heff_tr(heff_call(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_24143}));
      V f_ = heff_get_n(v_hd_246, 1, 3);
      heff_room[0] = v_t_24144;
      heff_room[1] = v_k_247;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
    case TAG_Just: {
      V v_ts_24145 = heff_field(v_t_24137, 0);
      V v_ru_24t_24137_24Just = heff_take_reuse_n(v_t_24137, 1ULL, 1);
      V v_t_24146 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_cs_243));
      if (heff_intEq_c(heff_arrayLength_lent(v_ts_24145, 0), v_t_24146)) {
        heff_drop(v_sp_240);
        heff_drop_cell(v_ru_24t_24137_24Just, 1);
        return ({ V a_0 = heff_dup(v_e_244); V a_1 = v_x_2412; V a_2 = heff_dup(v_x_242); V a_3 = v_tsp_241; V a_4 = heff_dup(v_x_2412); V a_5 = heff_dup(v_hd_246); V a_6 = heff_clo_n(g_heff_2eelab_2erules_2esumIntroNow_24cpr_lam3, 1, 6, (V[]){v_e_244, v_cs_243, v_ts_24145, v_hd_246, v_x_242, v_k_247}); V r_ = (g_heff_2eelab_2erules_2erecordName(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_x_2412); r_; });
      } else {
        heff_drop(v_tsp_241);
        heff_drop(v_cs_243);
        heff_drop(v_ts_24145);
        V v_t_24157 = (g_heff_2eelab_2erules_2etyStr(v_e_244, v_x_2412));
        V v_t_24158 = heff_strAppend(v_x_242, heff_strAppend(((V)&g_heff_2eelab_2erules_2esumIntroNow_24cpr_str17), v_t_24157));
        V v_msg_24159 = heff_strAppend(((V)&g_heff_2eelab_2erules_2esumIntroNow_24cpr_str18), v_t_24158);
        V v_t_24160 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(316LL), NTAG(TAG_SError), v_msg_24159, v_sp_240, NTAG(TAG_Nothing)});
        V v_t_24161 = heff_tag_at_n(v_ru_24t_24137_24Just, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24160})});
        V v_t_24162 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24161})});
        V v_t_24163 = heff_tr(heff_call(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_24162}));
        V f_ = heff_get_n(v_hd_246, 1, 3);
        heff_room[0] = v_t_24163;
        heff_room[1] = v_k_247;
        if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
      }
    }
    default: return heff_nomatch(v_t_24137);
    }
  }
  case TAG_LikeInt: {
    heff_drop(v_cs_243);
    V v_t_24185;
    switch (heff_tag_of(v_x_2412)) {
    case TAG_VU: {
      v_t_24185 = NTAG(TAG_False);
      break;
    }
    case TAG_VDecode: {
      V v_t1_24165 = heff_dup(heff_field(v_x_2412, 0));
      switch (heff_tag_of(v_t1_24165)) {
      case TAG_HLocal: {
        heff_take_n(v_t1_24165, 0ULL, 1);
        v_t_24185 = NTAG(TAG_False);
        break;
      }
      case TAG_HGlobal: {
        heff_take_n(v_t1_24165, 0ULL, 1);
        v_t_24185 = NTAG(TAG_False);
        break;
      }
      case TAG_HMeta: {
        heff_take_n(v_t1_24165, 0ULL, 1);
        v_t_24185 = NTAG(TAG_True);
        break;
      }
      case TAG_HError: {
        v_t_24185 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_t1_24165);
      }
      break;
    }
    case TAG_VFunction: {
      v_t_24185 = NTAG(TAG_False);
      break;
    }
    case TAG_VRecord: {
      v_t_24185 = NTAG(TAG_False);
      break;
    }
    case TAG_VSum: {
      v_t_24185 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimInt: {
      v_t_24185 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimFloat: {
      v_t_24185 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimString: {
      v_t_24185 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimRune: {
      v_t_24185 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimArray: {
      v_t_24185 = NTAG(TAG_False);
      break;
    }
    case TAG_VFixed: {
      v_t_24185 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x_2412);
    }
    if ((heff_dup(v_t_24185) == NTAG(TAG_True))) {
      heff_drop(v_x_2412);
      heff_drop(v_e_244);
      heff_drop(v_tsp_241);
      heff_drop(v_t_24185);
      V v_t_24186 = heff_strAppend(((V)&g_heff_2eelab_2erules_2esumIntroNow_24cpr_str19), heff_strAppend(v_x_242, ((V)&g_heff_2eelab_2erules_2esumIntroNow_24cpr_str20)));
      V v_t_24187 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(314LL), NTAG(TAG_SError), v_t_24186, v_sp_240, NTAG(TAG_Nothing)});
      V v_t_24188 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24187})});
      V v_t_24189 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24188})});
      V v_t_24190 = heff_tr(heff_call(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_24189}));
      V f_ = heff_get_n(v_hd_246, 1, 3);
      heff_room[0] = v_t_24190;
      heff_room[1] = v_k_247;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    } else {
      heff_drop(v_sp_240);
      heff_drop(v_t_24185);
      V v_t_24191 = (g_heff_2eelab_2erules_2etyStr(v_e_244, v_x_2412));
      V v_t_24192 = heff_strAppend(v_t_24191, heff_strAppend(((V)&g_heff_2eelab_2erules_2esumIntroNow_24cpr_str21), heff_dup(v_x_242)));
      V v_msg_24193 = heff_strAppend(((V)&g_heff_2eelab_2erules_2esumIntroNow_24cpr_str22), v_t_24192);
      V v_t_24194 = heff_tag_n(TAG_Just, 1, (V[]){heff_strAppend(v_x_242, ((V)&g_heff_2eelab_2erules_2esumIntroNow_24cpr_str23))});
      V v_t_24195 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(314LL), NTAG(TAG_SError), v_msg_24193, v_tsp_241, v_t_24194});
      V v_t_24196 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24195})});
      V v_t_24197 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24196})});
      V v_t_24198 = heff_tr(heff_call(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_24197}));
      V f_ = heff_get_n(v_hd_246, 1, 3);
      heff_room[0] = v_t_24198;
      heff_room[1] = v_k_247;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
  }
  case TAG_LikeFloat: {
    heff_drop(v_cs_243);
    V v_t_24220;
    switch (heff_tag_of(v_x_2412)) {
    case TAG_VU: {
      v_t_24220 = NTAG(TAG_False);
      break;
    }
    case TAG_VDecode: {
      V v_t1_24200 = heff_dup(heff_field(v_x_2412, 0));
      switch (heff_tag_of(v_t1_24200)) {
      case TAG_HLocal: {
        heff_take_n(v_t1_24200, 0ULL, 1);
        v_t_24220 = NTAG(TAG_False);
        break;
      }
      case TAG_HGlobal: {
        heff_take_n(v_t1_24200, 0ULL, 1);
        v_t_24220 = NTAG(TAG_False);
        break;
      }
      case TAG_HMeta: {
        heff_take_n(v_t1_24200, 0ULL, 1);
        v_t_24220 = NTAG(TAG_True);
        break;
      }
      case TAG_HError: {
        v_t_24220 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_t1_24200);
      }
      break;
    }
    case TAG_VFunction: {
      v_t_24220 = NTAG(TAG_False);
      break;
    }
    case TAG_VRecord: {
      v_t_24220 = NTAG(TAG_False);
      break;
    }
    case TAG_VSum: {
      v_t_24220 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimInt: {
      v_t_24220 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimFloat: {
      v_t_24220 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimString: {
      v_t_24220 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimRune: {
      v_t_24220 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimArray: {
      v_t_24220 = NTAG(TAG_False);
      break;
    }
    case TAG_VFixed: {
      v_t_24220 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x_2412);
    }
    if ((heff_dup(v_t_24220) == NTAG(TAG_True))) {
      heff_drop(v_x_2412);
      heff_drop(v_e_244);
      heff_drop(v_tsp_241);
      heff_drop(v_t_24220);
      V v_t_24221 = heff_strAppend(((V)&g_heff_2eelab_2erules_2esumIntroNow_24cpr_str24), heff_strAppend(v_x_242, ((V)&g_heff_2eelab_2erules_2esumIntroNow_24cpr_str25)));
      V v_t_24222 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(314LL), NTAG(TAG_SError), v_t_24221, v_sp_240, NTAG(TAG_Nothing)});
      V v_t_24223 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24222})});
      V v_t_24224 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24223})});
      V v_t_24225 = heff_tr(heff_call(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_24224}));
      V f_ = heff_get_n(v_hd_246, 1, 3);
      heff_room[0] = v_t_24225;
      heff_room[1] = v_k_247;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    } else {
      heff_drop(v_sp_240);
      heff_drop(v_t_24220);
      V v_t_24226 = (g_heff_2eelab_2erules_2etyStr(v_e_244, v_x_2412));
      V v_t_24227 = heff_strAppend(v_t_24226, heff_strAppend(((V)&g_heff_2eelab_2erules_2esumIntroNow_24cpr_str26), heff_dup(v_x_242)));
      V v_msg_24228 = heff_strAppend(((V)&g_heff_2eelab_2erules_2esumIntroNow_24cpr_str27), v_t_24227);
      V v_t_24229 = heff_tag_n(TAG_Just, 1, (V[]){heff_strAppend(v_x_242, ((V)&g_heff_2eelab_2erules_2esumIntroNow_24cpr_str28))});
      V v_t_24230 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(314LL), NTAG(TAG_SError), v_msg_24228, v_tsp_241, v_t_24229});
      V v_t_24231 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24230})});
      V v_t_24232 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24231})});
      V v_t_24233 = heff_tr(heff_call(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_24232}));
      V f_ = heff_get_n(v_hd_246, 1, 3);
      heff_room[0] = v_t_24233;
      heff_room[1] = v_k_247;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
  }
  case TAG_LikeString: {
    heff_drop(v_cs_243);
    V v_t_24255;
    switch (heff_tag_of(v_x_2412)) {
    case TAG_VU: {
      v_t_24255 = NTAG(TAG_False);
      break;
    }
    case TAG_VDecode: {
      V v_t1_24235 = heff_dup(heff_field(v_x_2412, 0));
      switch (heff_tag_of(v_t1_24235)) {
      case TAG_HLocal: {
        heff_take_n(v_t1_24235, 0ULL, 1);
        v_t_24255 = NTAG(TAG_False);
        break;
      }
      case TAG_HGlobal: {
        heff_take_n(v_t1_24235, 0ULL, 1);
        v_t_24255 = NTAG(TAG_False);
        break;
      }
      case TAG_HMeta: {
        heff_take_n(v_t1_24235, 0ULL, 1);
        v_t_24255 = NTAG(TAG_True);
        break;
      }
      case TAG_HError: {
        v_t_24255 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_t1_24235);
      }
      break;
    }
    case TAG_VFunction: {
      v_t_24255 = NTAG(TAG_False);
      break;
    }
    case TAG_VRecord: {
      v_t_24255 = NTAG(TAG_False);
      break;
    }
    case TAG_VSum: {
      v_t_24255 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimInt: {
      v_t_24255 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimFloat: {
      v_t_24255 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimString: {
      v_t_24255 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimRune: {
      v_t_24255 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimArray: {
      v_t_24255 = NTAG(TAG_False);
      break;
    }
    case TAG_VFixed: {
      v_t_24255 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x_2412);
    }
    if ((heff_dup(v_t_24255) == NTAG(TAG_True))) {
      heff_drop(v_x_2412);
      heff_drop(v_e_244);
      heff_drop(v_tsp_241);
      heff_drop(v_t_24255);
      V v_t_24256 = heff_strAppend(((V)&g_heff_2eelab_2erules_2esumIntroNow_24cpr_str29), heff_strAppend(v_x_242, ((V)&g_heff_2eelab_2erules_2esumIntroNow_24cpr_str30)));
      V v_t_24257 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(314LL), NTAG(TAG_SError), v_t_24256, v_sp_240, NTAG(TAG_Nothing)});
      V v_t_24258 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24257})});
      V v_t_24259 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24258})});
      V v_t_24260 = heff_tr(heff_call(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_24259}));
      V f_ = heff_get_n(v_hd_246, 1, 3);
      heff_room[0] = v_t_24260;
      heff_room[1] = v_k_247;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    } else {
      heff_drop(v_sp_240);
      heff_drop(v_t_24255);
      V v_t_24261 = (g_heff_2eelab_2erules_2etyStr(v_e_244, v_x_2412));
      V v_t_24262 = heff_strAppend(v_t_24261, heff_strAppend(((V)&g_heff_2eelab_2erules_2esumIntroNow_24cpr_str31), heff_dup(v_x_242)));
      V v_msg_24263 = heff_strAppend(((V)&g_heff_2eelab_2erules_2esumIntroNow_24cpr_str32), v_t_24262);
      V v_t_24264 = heff_tag_n(TAG_Just, 1, (V[]){heff_strAppend(v_x_242, ((V)&g_heff_2eelab_2erules_2esumIntroNow_24cpr_str33))});
      V v_t_24265 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(314LL), NTAG(TAG_SError), v_msg_24263, v_tsp_241, v_t_24264});
      V v_t_24266 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24265})});
      V v_t_24267 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24266})});
      V v_t_24268 = heff_tr(heff_call(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_24267}));
      V f_ = heff_get_n(v_hd_246, 1, 3);
      heff_room[0] = v_t_24268;
      heff_room[1] = v_k_247;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
  }
  case TAG_LikeRune: {
    heff_drop(v_cs_243);
    V v_t_24290;
    switch (heff_tag_of(v_x_2412)) {
    case TAG_VU: {
      v_t_24290 = NTAG(TAG_False);
      break;
    }
    case TAG_VDecode: {
      V v_t1_24270 = heff_dup(heff_field(v_x_2412, 0));
      switch (heff_tag_of(v_t1_24270)) {
      case TAG_HLocal: {
        heff_take_n(v_t1_24270, 0ULL, 1);
        v_t_24290 = NTAG(TAG_False);
        break;
      }
      case TAG_HGlobal: {
        heff_take_n(v_t1_24270, 0ULL, 1);
        v_t_24290 = NTAG(TAG_False);
        break;
      }
      case TAG_HMeta: {
        heff_take_n(v_t1_24270, 0ULL, 1);
        v_t_24290 = NTAG(TAG_True);
        break;
      }
      case TAG_HError: {
        v_t_24290 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_t1_24270);
      }
      break;
    }
    case TAG_VFunction: {
      v_t_24290 = NTAG(TAG_False);
      break;
    }
    case TAG_VRecord: {
      v_t_24290 = NTAG(TAG_False);
      break;
    }
    case TAG_VSum: {
      v_t_24290 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimInt: {
      v_t_24290 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimFloat: {
      v_t_24290 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimString: {
      v_t_24290 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimRune: {
      v_t_24290 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimArray: {
      v_t_24290 = NTAG(TAG_False);
      break;
    }
    case TAG_VFixed: {
      v_t_24290 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x_2412);
    }
    if ((heff_dup(v_t_24290) == NTAG(TAG_True))) {
      heff_drop(v_x_2412);
      heff_drop(v_e_244);
      heff_drop(v_tsp_241);
      heff_drop(v_t_24290);
      V v_t_24291 = heff_strAppend(((V)&g_heff_2eelab_2erules_2esumIntroNow_24cpr_str34), heff_strAppend(v_x_242, ((V)&g_heff_2eelab_2erules_2esumIntroNow_24cpr_str35)));
      V v_t_24292 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(314LL), NTAG(TAG_SError), v_t_24291, v_sp_240, NTAG(TAG_Nothing)});
      V v_t_24293 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24292})});
      V v_t_24294 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24293})});
      V v_t_24295 = heff_tr(heff_call(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_24294}));
      V f_ = heff_get_n(v_hd_246, 1, 3);
      heff_room[0] = v_t_24295;
      heff_room[1] = v_k_247;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    } else {
      heff_drop(v_sp_240);
      heff_drop(v_t_24290);
      V v_t_24296 = (g_heff_2eelab_2erules_2etyStr(v_e_244, v_x_2412));
      V v_t_24297 = heff_strAppend(v_t_24296, heff_strAppend(((V)&g_heff_2eelab_2erules_2esumIntroNow_24cpr_str36), heff_dup(v_x_242)));
      V v_msg_24298 = heff_strAppend(((V)&g_heff_2eelab_2erules_2esumIntroNow_24cpr_str37), v_t_24297);
      V v_t_24299 = heff_tag_n(TAG_Just, 1, (V[]){heff_strAppend(v_x_242, ((V)&g_heff_2eelab_2erules_2esumIntroNow_24cpr_str38))});
      V v_t_24300 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(314LL), NTAG(TAG_SError), v_msg_24298, v_tsp_241, v_t_24299});
      V v_t_24301 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24300})});
      V v_t_24302 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24301})});
      V v_t_24303 = heff_tr(heff_call(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_24302}));
      V f_ = heff_get_n(v_hd_246, 1, 3);
      heff_room[0] = v_t_24303;
      heff_room[1] = v_k_247;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
  }
  case TAG_LikeArray: {
    V v_ru_24t_2413_24LikeArray = heff_take_reuse_n(v_t_2413, 0ULL, 1);
    heff_drop(v_cs_243);
    V v_t_24326;
    switch (heff_tag_of(v_x_2412)) {
    case TAG_VU: {
      v_t_24326 = NTAG(TAG_False);
      break;
    }
    case TAG_VDecode: {
      V v_t1_24306 = heff_dup(heff_field(v_x_2412, 0));
      switch (heff_tag_of(v_t1_24306)) {
      case TAG_HLocal: {
        heff_take_n(v_t1_24306, 0ULL, 1);
        v_t_24326 = NTAG(TAG_False);
        break;
      }
      case TAG_HGlobal: {
        heff_take_n(v_t1_24306, 0ULL, 1);
        v_t_24326 = NTAG(TAG_False);
        break;
      }
      case TAG_HMeta: {
        heff_take_n(v_t1_24306, 0ULL, 1);
        v_t_24326 = NTAG(TAG_True);
        break;
      }
      case TAG_HError: {
        v_t_24326 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_t1_24306);
      }
      break;
    }
    case TAG_VFunction: {
      v_t_24326 = NTAG(TAG_False);
      break;
    }
    case TAG_VRecord: {
      v_t_24326 = NTAG(TAG_False);
      break;
    }
    case TAG_VSum: {
      v_t_24326 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimInt: {
      v_t_24326 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimFloat: {
      v_t_24326 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimString: {
      v_t_24326 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimRune: {
      v_t_24326 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimArray: {
      v_t_24326 = NTAG(TAG_False);
      break;
    }
    case TAG_VFixed: {
      v_t_24326 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x_2412);
    }
    if ((heff_dup(v_t_24326) == NTAG(TAG_True))) {
      heff_drop(v_x_2412);
      heff_drop(v_e_244);
      heff_drop(v_tsp_241);
      heff_drop(v_t_24326);
      V v_t_24327 = heff_strAppend(((V)&g_heff_2eelab_2erules_2esumIntroNow_24cpr_str39), heff_strAppend(v_x_242, ((V)&g_heff_2eelab_2erules_2esumIntroNow_24cpr_str40)));
      V v_t_24328 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(314LL), NTAG(TAG_SError), v_t_24327, v_sp_240, NTAG(TAG_Nothing)});
      V v_t_24329 = heff_tag_at_n(v_ru_24t_2413_24LikeArray, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24328})});
      V v_t_24330 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24329})});
      V v_t_24331 = heff_tr(heff_call(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_24330}));
      V f_ = heff_get_n(v_hd_246, 1, 3);
      heff_room[0] = v_t_24331;
      heff_room[1] = v_k_247;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    } else {
      heff_drop(v_sp_240);
      heff_drop(v_t_24326);
      V v_t_24332 = (g_heff_2eelab_2erules_2etyStr(v_e_244, v_x_2412));
      V v_t_24333 = heff_strAppend(v_t_24332, heff_strAppend(((V)&g_heff_2eelab_2erules_2esumIntroNow_24cpr_str41), heff_dup(v_x_242)));
      V v_msg_24334 = heff_strAppend(((V)&g_heff_2eelab_2erules_2esumIntroNow_24cpr_str42), v_t_24333);
      V v_t_24335 = heff_tag_at_n(v_ru_24t_2413_24LikeArray, TAG_Just, 1, (V[]){heff_strAppend(v_x_242, ((V)&g_heff_2eelab_2erules_2esumIntroNow_24cpr_str43))});
      V v_t_24336 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(314LL), NTAG(TAG_SError), v_msg_24334, v_tsp_241, v_t_24335});
      V v_t_24337 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24336})});
      V v_t_24338 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24337})});
      V v_t_24339 = heff_tr(heff_call(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_24338}));
      V f_ = heff_get_n(v_hd_246, 1, 3);
      heff_room[0] = v_t_24339;
      heff_room[1] = v_k_247;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
  }
  case TAG_LikeFixed: {
    V v_ru_24t_2413_24LikeFixed = heff_take_reuse_n(v_t_2413, 0ULL, 1);
    heff_drop(v_cs_243);
    V v_t_24362;
    switch (heff_tag_of(v_x_2412)) {
    case TAG_VU: {
      v_t_24362 = NTAG(TAG_False);
      break;
    }
    case TAG_VDecode: {
      V v_t1_24342 = heff_dup(heff_field(v_x_2412, 0));
      switch (heff_tag_of(v_t1_24342)) {
      case TAG_HLocal: {
        heff_take_n(v_t1_24342, 0ULL, 1);
        v_t_24362 = NTAG(TAG_False);
        break;
      }
      case TAG_HGlobal: {
        heff_take_n(v_t1_24342, 0ULL, 1);
        v_t_24362 = NTAG(TAG_False);
        break;
      }
      case TAG_HMeta: {
        heff_take_n(v_t1_24342, 0ULL, 1);
        v_t_24362 = NTAG(TAG_True);
        break;
      }
      case TAG_HError: {
        v_t_24362 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_t1_24342);
      }
      break;
    }
    case TAG_VFunction: {
      v_t_24362 = NTAG(TAG_False);
      break;
    }
    case TAG_VRecord: {
      v_t_24362 = NTAG(TAG_False);
      break;
    }
    case TAG_VSum: {
      v_t_24362 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimInt: {
      v_t_24362 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimFloat: {
      v_t_24362 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimString: {
      v_t_24362 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimRune: {
      v_t_24362 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimArray: {
      v_t_24362 = NTAG(TAG_False);
      break;
    }
    case TAG_VFixed: {
      v_t_24362 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x_2412);
    }
    if ((heff_dup(v_t_24362) == NTAG(TAG_True))) {
      heff_drop(v_x_2412);
      heff_drop(v_e_244);
      heff_drop(v_tsp_241);
      heff_drop(v_t_24362);
      V v_t_24363 = heff_strAppend(((V)&g_heff_2eelab_2erules_2esumIntroNow_24cpr_str44), heff_strAppend(v_x_242, ((V)&g_heff_2eelab_2erules_2esumIntroNow_24cpr_str45)));
      V v_t_24364 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(314LL), NTAG(TAG_SError), v_t_24363, v_sp_240, NTAG(TAG_Nothing)});
      V v_t_24365 = heff_tag_at_n(v_ru_24t_2413_24LikeFixed, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24364})});
      V v_t_24366 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24365})});
      V v_t_24367 = heff_tr(heff_call(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_24366}));
      V f_ = heff_get_n(v_hd_246, 1, 3);
      heff_room[0] = v_t_24367;
      heff_room[1] = v_k_247;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    } else {
      heff_drop(v_sp_240);
      heff_drop(v_t_24362);
      V v_t_24368 = (g_heff_2eelab_2erules_2etyStr(v_e_244, v_x_2412));
      V v_t_24369 = heff_strAppend(v_t_24368, heff_strAppend(((V)&g_heff_2eelab_2erules_2esumIntroNow_24cpr_str46), heff_dup(v_x_242)));
      V v_msg_24370 = heff_strAppend(((V)&g_heff_2eelab_2erules_2esumIntroNow_24cpr_str47), v_t_24369);
      V v_t_24371 = heff_tag_at_n(v_ru_24t_2413_24LikeFixed, TAG_Just, 1, (V[]){heff_strAppend(v_x_242, ((V)&g_heff_2eelab_2erules_2esumIntroNow_24cpr_str48))});
      V v_t_24372 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(314LL), NTAG(TAG_SError), v_msg_24370, v_tsp_241, v_t_24371});
      V v_t_24373 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24372})});
      V v_t_24374 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24373})});
      V v_t_24375 = heff_tr(heff_call(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_24374}));
      V f_ = heff_get_n(v_hd_246, 1, 3);
      heff_room[0] = v_t_24375;
      heff_room[1] = v_k_247;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
  }
  case TAG_NoRules: {
    heff_drop(v_cs_243);
    V v_t_24397;
    switch (heff_tag_of(v_x_2412)) {
    case TAG_VU: {
      v_t_24397 = NTAG(TAG_False);
      break;
    }
    case TAG_VDecode: {
      V v_t1_24377 = heff_dup(heff_field(v_x_2412, 0));
      switch (heff_tag_of(v_t1_24377)) {
      case TAG_HLocal: {
        heff_take_n(v_t1_24377, 0ULL, 1);
        v_t_24397 = NTAG(TAG_False);
        break;
      }
      case TAG_HGlobal: {
        heff_take_n(v_t1_24377, 0ULL, 1);
        v_t_24397 = NTAG(TAG_False);
        break;
      }
      case TAG_HMeta: {
        heff_take_n(v_t1_24377, 0ULL, 1);
        v_t_24397 = NTAG(TAG_True);
        break;
      }
      case TAG_HError: {
        v_t_24397 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_t1_24377);
      }
      break;
    }
    case TAG_VFunction: {
      v_t_24397 = NTAG(TAG_False);
      break;
    }
    case TAG_VRecord: {
      v_t_24397 = NTAG(TAG_False);
      break;
    }
    case TAG_VSum: {
      v_t_24397 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimInt: {
      v_t_24397 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimFloat: {
      v_t_24397 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimString: {
      v_t_24397 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimRune: {
      v_t_24397 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimArray: {
      v_t_24397 = NTAG(TAG_False);
      break;
    }
    case TAG_VFixed: {
      v_t_24397 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_x_2412);
    }
    if ((heff_dup(v_t_24397) == NTAG(TAG_True))) {
      heff_drop(v_x_2412);
      heff_drop(v_e_244);
      heff_drop(v_tsp_241);
      heff_drop(v_t_24397);
      V v_t_24398 = heff_strAppend(((V)&g_heff_2eelab_2erules_2esumIntroNow_24cpr_str49), heff_strAppend(v_x_242, ((V)&g_heff_2eelab_2erules_2esumIntroNow_24cpr_str50)));
      V v_t_24399 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(314LL), NTAG(TAG_SError), v_t_24398, v_sp_240, NTAG(TAG_Nothing)});
      V v_t_24400 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24399})});
      V v_t_24401 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24400})});
      V v_t_24402 = heff_tr(heff_call(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_24401}));
      V f_ = heff_get_n(v_hd_246, 1, 3);
      heff_room[0] = v_t_24402;
      heff_room[1] = v_k_247;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    } else {
      heff_drop(v_sp_240);
      heff_drop(v_t_24397);
      V v_t_24403 = (g_heff_2eelab_2erules_2etyStr(v_e_244, v_x_2412));
      V v_t_24404 = heff_strAppend(v_t_24403, heff_strAppend(((V)&g_heff_2eelab_2erules_2esumIntroNow_24cpr_str51), heff_dup(v_x_242)));
      V v_msg_24405 = heff_strAppend(((V)&g_heff_2eelab_2erules_2esumIntroNow_24cpr_str52), v_t_24404);
      V v_t_24406 = heff_tag_n(TAG_Just, 1, (V[]){heff_strAppend(v_x_242, ((V)&g_heff_2eelab_2erules_2esumIntroNow_24cpr_str53))});
      V v_t_24407 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(314LL), NTAG(TAG_SError), v_msg_24405, v_tsp_241, v_t_24406});
      V v_t_24408 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24407})});
      V v_t_24409 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24408})});
      V v_t_24410 = heff_tr(heff_call(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_24409}));
      V f_ = heff_get_n(v_hd_246, 1, 3);
      heff_room[0] = v_t_24410;
      heff_room[1] = v_k_247;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
  }
  default: return heff_nomatch(v_t_2413);
  }
}
V g_heff_2eelab_2erules_2esumIntroNow_24cpr_lam0(V self, V *args) {
  V v_e_244 = args[0];
  V v_a0_245 = args[1];
  V v_hd_246 = args[2];
  V v_k_247 = args[3];
  V v_x_242 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  V v_tsp_241 = heff_env(self)[2];
  V v_cs_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2esumIntroNow_24cpr_lam1, 1, 1, (V[]){v_a0_245})})});
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_246, 2)), 1, (V[]){v_t_2410}));
  V f_ = heff_dup(heff_rfield(v_hd_246, 1));
  args[0] = v_t_2411;
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2esumIntroNow_24cpr_lam2, 1, 7, (V[]){v_x_242, v_sp_240, v_hd_246, v_k_247, v_e_244, v_tsp_241, v_cs_243});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2ecasesAt_lam1(V self, V *args);
V g_heff_2eelab_2erules_2ecasesAt_lam3(V self, V *args); static Clo g_heff_2eelab_2erules_2ecasesAt_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2ecasesAt_lam3, 1, 0};
V g_heff_2eelab_2erules_2ecasesAt_lam2(V self, V *args);
V g_heff_2eelab_2erules_2ecasesAt_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2ecasesAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2ecasesAt_entry, 10, 0};

V g_heff_2eelab_2erules_2ecasesAt(V v_sp_240, V v_e_241, V v_b_242, V v_scrut_243, V v_a_244, V v_vs_245, V v_tags_246, V v_casesChk_247, V v_z_248, V v_z_249) {
top: ;
  V v_c_2410 = (g_heff_2eelab_2erules_2erecordTags(heff_dup(v_e_241), heff_dup(v_a_244), heff_dup(v_vs_245), v_tags_246));
  return heff_tail(v_c_2410, 2, (V[]){heff_dup(v_z_248), heff_clo_n(g_heff_2eelab_2erules_2ecasesAt_lam0, 1, 9, (V[]){v_vs_245, v_sp_240, v_e_241, v_b_242, v_a_244, v_casesChk_247, v_z_248, v_scrut_243, v_z_249})});
}
V g_heff_2eelab_2erules_2ecasesAt_entry(V self, V *a) {
  (void)self;
  V a6 = a[6]; V r = g_heff_2eelab_2erules_2ecasesAt(a[0], a[1], a[2], a[3], a[4], a[5], a6, a[7], a[8], a[9]); heff_drop(a6); return r;
}
V g_heff_2eelab_2erules_2ecasesAt_lam1(V self, V *args) {
  V v_p_2415 = args[0];
  V v_sp_240 = heff_env(self)[0];
  V v_e_241 = heff_env(self)[1];
  V v_b_242 = heff_env(self)[2];
  V v_a_244 = heff_env(self)[3];
  V v_casesChk_247 = heff_env(self)[4];
  heff_clo_take(self, 5);
  switch (heff_tag_of(v_p_2415)) {
  case TAG_MkPair: {
    V v_x_2416 = heff_field(v_p_2415, 0);
    V v_ts_2417 = heff_field(v_p_2415, 1);
    heff_take_n(v_p_2415, 3ULL, 2);
    return ({ V a_0 = v_sp_240; V a_1 = v_e_241; V a_2 = v_b_242; V a_3 = v_a_244; V a_4 = v_x_2416; V a_5 = heff_arrayToList(v_ts_2417); V a_6 = v_casesChk_247; V r_ = (g_heff_2eelab_2erules_2ecaseArm(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_a_244); r_; });
  }
  default: return heff_nomatch(v_p_2415);
  }
}
V g_heff_2eelab_2erules_2ecasesAt_lam3(V self, V *args) {
  V v_u_2425 = args[0];
  heff_drop(v_u_2425);
  return heff_tag_n(TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
}
V g_heff_2eelab_2erules_2ecasesAt_lam2(V self, V *args) {
  V v_x_2419 = args[0];
  V v_scrut_243 = heff_env(self)[0];
  V v_z_249 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2420 = (g_list_2emap_24s1937570095x2110149801(heff_dup(v_x_2419)));
  V v_t_2421 = (g_heff_2eutil_2edict_2eindexed(MK_INT(0LL), v_x_2419));
  V v_t_2422 = (g_list_2emap_24s1173914895x100384474(v_x_2419));
  V v_cases_2423 = heff_rec_n(3, shape_keys__byName__values, (V[]){heff_arrayFromList(v_t_2420), v_t_2421, heff_arrayFromList(v_t_2422)});
  V v_t_2424 = heff_tag_n(TAG_SMatch, 2, (V[]){heff_get_n(v_scrut_243, 0, 2), v_cases_2423});
  V f_ = v_z_249;
  args[0] = heff_rec_n(2, shape_stx__val, (V[]){v_t_2424, ((V)&g_heff_2eelab_2erules_2ecasesAt_lam3_clo)});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2ecasesAt_lam0(V self, V *args) {
  V v_x_2411 = args[0];
  V v_vs_245 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  V v_e_241 = heff_env(self)[2];
  V v_b_242 = heff_env(self)[3];
  V v_a_244 = heff_env(self)[4];
  V v_casesChk_247 = heff_env(self)[5];
  V v_z_248 = heff_env(self)[6];
  V v_scrut_243 = heff_env(self)[7];
  V v_z_249 = heff_env(self)[8];
  heff_clo_take(self, 9);
  heff_drop(v_x_2411);
  V v_t_2412 = heff_arrayToList(heff_take_field(v_vs_245, 0));
  V v_t_2413 = heff_arrayToList(heff_get_n(v_vs_245, 2, 3));
  V v_t_2414 = (g_heff_2eutil_2edict_2ezipKV(v_t_2412, v_t_2413));
  V v_c_2418 = (g_prelude_2etraverse_24s1934076392x614790049(heff_clo_n(g_heff_2eelab_2erules_2ecasesAt_lam1, 1, 5, (V[]){v_sp_240, v_e_241, v_b_242, v_a_244, v_casesChk_247}), v_t_2414));
  V f_ = v_c_2418;
  heff_room[0] = v_z_248;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2ecasesAt_lam2, 1, 2, (V[]){v_scrut_243, v_z_249});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}

HeffT2 g_heff_2eelab_2erules_2eupdateInner_24cpr(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), NTAG(TAG_Nil)}});
  }
  case TAG_Cons: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_UpdateTo: {
      heff_take_n(v_x11_241, 0ULL, 4);
      heff_drop(v_rest_242);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_UpdateIn: {
      V v_fs_2410 = heff_field(v_x11_241, 3);
      heff_take_n(v_x11_241, 8ULL, 4);
      HeffT2 v_t_2411 = (g_heff_2eelab_2erules_2eupdateInner_24cpr(v_rest_242));
      {
        V v_field_2413 = v_t_2411.f[1];
        int64_t v_tag_2412 = ((int64_t)v_t_2411.f[0]);
        if ((v_tag_2412 == ((int64_t)0ULL))) {
          V v_more_2415 = v_field_2413;
          V v_f_2416 = (g_heff_2eelab_2erules_2eappendP(v_fs_2410, v_more_2415));
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2416}});
        } else {
          heff_drop(v_fs_2410);
          heff_drop(v_field_2413);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x11_241)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
V g_heff_2eelab_2erules_2euniverseIntro_lam1(V self, V *args);
V g_heff_2eelab_2erules_2euniverseIntro_lam3(V self, V *args);
V g_heff_2eelab_2erules_2euniverseIntro_lam2(V self, V *args);
V g_heff_2eelab_2erules_2euniverseIntro_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2euniverseIntro_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2euniverseIntro_entry, 2, 0};

V g_heff_2eelab_2erules_2euniverseIntro(V v_sp_240, V v_typ_241) {
top: ;
  return heff_tag_n(TAG_MkChk, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2euniverseIntro_lam0, 4, 2, (V[]){heff_dup(v_typ_241), v_sp_240})});
}
V g_heff_2eelab_2erules_2euniverseIntro_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2erules_2euniverseIntro(a[0], a1); heff_drop(a1); return r;
}
V g_heff_2eelab_2erules_2euniverseIntro_lam1(V self, V *args) {
  V v_c_246 = args[0];
  V v_a0_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_c_246, 3, 8); V a_1 = v_a0_243; V r_ = (g_heff_2eelab_2evalue_2eforceTy(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2eelab_2erules_2euniverseIntro_lam3(V self, V *args) {
  V v_x_2413 = args[0];
  V v_sp_240 = heff_env(self)[0];
  V v_e_242 = heff_env(self)[1];
  V v_x_2410 = heff_env(self)[2];
  V v_hd_244 = heff_env(self)[3];
  V v_k_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2eelab_2erules_2euniverseAt(v_sp_240, NTAG(TAG_Nothing), v_e_242, v_x_2410, v_x_2413, v_hd_244, v_k_245));
}
V g_heff_2eelab_2erules_2euniverseIntro_lam2(V self, V *args) {
  V v_x_2410 = args[0];
  V v_typ_241 = heff_env(self)[0];
  V v_e_242 = heff_env(self)[1];
  V v_hd_244 = heff_env(self)[2];
  V v_sp_240 = heff_env(self)[3];
  V v_k_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_c_2412;
  switch (heff_tag_of(v_typ_241)) {
  case TAG_MkTyp: {
    V v_f_2411 = heff_field(v_typ_241, 0);
    heff_take_n(v_typ_241, 1ULL, 1);
    v_c_2412 = heff_tr(heff_call(v_f_2411, 1, (V[]){heff_dup(v_e_242)}));
    break;
  }
  default: heff_nomatch(v_typ_241);
  }
  V f_ = v_c_2412;
  heff_room[0] = heff_dup(v_hd_244);
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2euniverseIntro_lam3, 1, 5, (V[]){v_sp_240, v_e_242, v_x_2410, v_hd_244, v_k_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2euniverseIntro_lam0(V self, V *args) {
  V v_e_242 = args[0];
  V v_a0_243 = args[1];
  V v_hd_244 = args[2];
  V v_k_245 = args[3];
  V v_typ_241 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2euniverseIntro_lam1, 1, 1, (V[]){v_a0_243})})});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_244, 2)), 1, (V[]){v_t_248}));
  V f_ = heff_dup(heff_rfield(v_hd_244, 1));
  args[0] = v_t_249;
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2euniverseIntro_lam2, 1, 5, (V[]){v_typ_241, v_e_242, v_hd_244, v_sp_240, v_k_245});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2eelab_2erules_2euniverseElimSyn_str0, 45, "cannot decode an element of non-universe type");
HEFF_LIT(g_heff_2eelab_2erules_2euniverseElimSyn_str1, 45, "cannot decode an element of non-universe type");
HEFF_LIT(g_heff_2eelab_2erules_2euniverseElimSyn_str2, 45, "cannot decode an element of non-universe type");
HEFF_LIT(g_heff_2eelab_2erules_2euniverseElimSyn_str3, 45, "cannot decode an element of non-universe type");
HEFF_LIT(g_heff_2eelab_2erules_2euniverseElimSyn_str4, 45, "cannot decode an element of non-universe type");
HEFF_LIT(g_heff_2eelab_2erules_2euniverseElimSyn_str5, 45, "cannot decode an element of non-universe type");
HEFF_LIT(g_heff_2eelab_2erules_2euniverseElimSyn_str6, 45, "cannot decode an element of non-universe type");
HEFF_LIT(g_heff_2eelab_2erules_2euniverseElimSyn_str7, 45, "cannot decode an element of non-universe type");
HEFF_LIT(g_heff_2eelab_2erules_2euniverseElimSyn_str8, 45, "cannot decode an element of non-universe type");
HEFF_LIT(g_heff_2eelab_2erules_2euniverseElimSyn_str9, 45, "cannot decode an element of non-universe type");
V g_heff_2eelab_2erules_2euniverseElimSyn_lam2(V self, V *args);
V g_heff_2eelab_2erules_2euniverseElimSyn_lam1(V self, V *args);
V g_heff_2eelab_2erules_2euniverseElimSyn_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2euniverseElimSyn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2euniverseElimSyn_entry, 2, 0};

V g_heff_2eelab_2erules_2euniverseElimSyn(V v_sp_240, V v_syn_241) {
top: ;
  return heff_tag_n(TAG_MkTyp, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2euniverseElimSyn_lam0, 1, 2, (V[]){heff_dup(v_syn_241), v_sp_240})});
}
V g_heff_2eelab_2erules_2euniverseElimSyn_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2erules_2euniverseElimSyn(a[0], a1); heff_drop(a1); return r;
}
V g_heff_2eelab_2erules_2euniverseElimSyn_lam2(V self, V *args) {
  V v_x_247 = args[0];
  V v_k_246 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  V v_hd_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_x_247)) {
  case TAG_MkPair: {
    V v_m_248 = heff_field(v_x_247, 0);
    V v_a_249 = heff_field(v_x_247, 1);
    heff_take_n(v_x_247, 3ULL, 2);
    switch (heff_tag_of(v_a_249)) {
    case TAG_VU: {
      heff_take_n(v_a_249, 0ULL, 1);
      heff_drop(v_sp_240);
      heff_drop_rec(v_hd_245, 3);
      V v_t_2411 = (g_heff_2eelab_2ememoed_2edecode(v_m_248));
      V f_ = v_k_246;
      args[0] = v_t_2411;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    case TAG_VDecode: {
      heff_take_n(v_a_249, 0ULL, 5);
      heff_drop(v_m_248);
      V v_t_2417 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(310LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2euniverseElimSyn_str0), v_sp_240, NTAG(TAG_Nothing)});
      V v_t_2418 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2417})});
      V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
      V v_t_2420 = heff_tr(heff_call(heff_take_field(v_hd_245, 2), 1, (V[]){v_t_2419}));
      V f_ = heff_get_n(v_hd_245, 1, 3);
      heff_room[0] = v_t_2420;
      heff_room[1] = v_k_246;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
    case TAG_VFunction: {
      heff_take_n(v_a_249, 0ULL, 5);
      heff_drop(v_m_248);
      V v_t_2426 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(310LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2euniverseElimSyn_str1), v_sp_240, NTAG(TAG_Nothing)});
      V v_t_2427 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2426})});
      V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
      V v_t_2429 = heff_tr(heff_call(heff_take_field(v_hd_245, 2), 1, (V[]){v_t_2428}));
      V f_ = heff_get_n(v_hd_245, 1, 3);
      heff_room[0] = v_t_2429;
      heff_room[1] = v_k_246;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
    case TAG_VRecord: {
      heff_take_n(v_a_249, 0ULL, 4);
      heff_drop(v_m_248);
      V v_t_2434 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(310LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2euniverseElimSyn_str2), v_sp_240, NTAG(TAG_Nothing)});
      V v_t_2435 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2434})});
      V v_t_2436 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2435})});
      V v_t_2437 = heff_tr(heff_call(heff_take_field(v_hd_245, 2), 1, (V[]){v_t_2436}));
      V f_ = heff_get_n(v_hd_245, 1, 3);
      heff_room[0] = v_t_2437;
      heff_room[1] = v_k_246;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
    case TAG_VSum: {
      V v_ru_24a_249_24VSum = heff_take_reuse_n(v_a_249, 0ULL, 1);
      heff_drop(v_m_248);
      V v_t_2439 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(310LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2euniverseElimSyn_str3), v_sp_240, NTAG(TAG_Nothing)});
      V v_t_2440 = heff_tag_at_n(v_ru_24a_249_24VSum, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2439})});
      V v_t_2441 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2440})});
      V v_t_2442 = heff_tr(heff_call(heff_take_field(v_hd_245, 2), 1, (V[]){v_t_2441}));
      V f_ = heff_get_n(v_hd_245, 1, 3);
      heff_room[0] = v_t_2442;
      heff_room[1] = v_k_246;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
    case TAG_VPrimInt: {
      heff_drop(v_m_248);
      V v_t_2443 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(310LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2euniverseElimSyn_str4), v_sp_240, NTAG(TAG_Nothing)});
      V v_t_2444 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2443})});
      V v_t_2445 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2444})});
      V v_t_2446 = heff_tr(heff_call(heff_take_field(v_hd_245, 2), 1, (V[]){v_t_2445}));
      V f_ = heff_get_n(v_hd_245, 1, 3);
      heff_room[0] = v_t_2446;
      heff_room[1] = v_k_246;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
    case TAG_VPrimFloat: {
      heff_drop(v_m_248);
      V v_t_2447 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(310LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2euniverseElimSyn_str5), v_sp_240, NTAG(TAG_Nothing)});
      V v_t_2448 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2447})});
      V v_t_2449 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2448})});
      V v_t_2450 = heff_tr(heff_call(heff_take_field(v_hd_245, 2), 1, (V[]){v_t_2449}));
      V f_ = heff_get_n(v_hd_245, 1, 3);
      heff_room[0] = v_t_2450;
      heff_room[1] = v_k_246;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
    case TAG_VPrimString: {
      heff_drop(v_m_248);
      V v_t_2451 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(310LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2euniverseElimSyn_str6), v_sp_240, NTAG(TAG_Nothing)});
      V v_t_2452 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2451})});
      V v_t_2453 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2452})});
      V v_t_2454 = heff_tr(heff_call(heff_take_field(v_hd_245, 2), 1, (V[]){v_t_2453}));
      V f_ = heff_get_n(v_hd_245, 1, 3);
      heff_room[0] = v_t_2454;
      heff_room[1] = v_k_246;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
    case TAG_VPrimRune: {
      heff_drop(v_m_248);
      V v_t_2455 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(310LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2euniverseElimSyn_str7), v_sp_240, NTAG(TAG_Nothing)});
      V v_t_2456 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2455})});
      V v_t_2457 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2456})});
      V v_t_2458 = heff_tr(heff_call(heff_take_field(v_hd_245, 2), 1, (V[]){v_t_2457}));
      V f_ = heff_get_n(v_hd_245, 1, 3);
      heff_room[0] = v_t_2458;
      heff_room[1] = v_k_246;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
    case TAG_VPrimArray: {
      V v_ru_24a_249_24VPrimArray = heff_take_reuse_n(v_a_249, 0ULL, 1);
      heff_drop(v_m_248);
      V v_t_2460 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(310LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2euniverseElimSyn_str8), v_sp_240, NTAG(TAG_Nothing)});
      V v_t_2461 = heff_tag_at_n(v_ru_24a_249_24VPrimArray, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2460})});
      V v_t_2462 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2461})});
      V v_t_2463 = heff_tr(heff_call(heff_take_field(v_hd_245, 2), 1, (V[]){v_t_2462}));
      V f_ = heff_get_n(v_hd_245, 1, 3);
      heff_room[0] = v_t_2463;
      heff_room[1] = v_k_246;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
    case TAG_VFixed: {
      V v_ru_24a_249_24VFixed = heff_take_reuse_n(v_a_249, 0ULL, 1);
      heff_drop(v_m_248);
      V v_t_2465 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(310LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2euniverseElimSyn_str9), v_sp_240, NTAG(TAG_Nothing)});
      V v_t_2466 = heff_tag_at_n(v_ru_24a_249_24VFixed, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2465})});
      V v_t_2467 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2466})});
      V v_t_2468 = heff_tr(heff_call(heff_take_field(v_hd_245, 2), 1, (V[]){v_t_2467}));
      V f_ = heff_get_n(v_hd_245, 1, 3);
      heff_room[0] = v_t_2468;
      heff_room[1] = v_k_246;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
    default: return heff_nomatch(v_a_249);
    }
  }
  default: return heff_nomatch(v_x_247);
  }
}
V g_heff_2eelab_2erules_2euniverseElimSyn_lam1(V self, V *args) {
  V v_hd_245 = args[0];
  V v_k_246 = args[1];
  V v_c_244 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_244;
  args[0] = heff_dup(v_hd_245);
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2euniverseElimSyn_lam2, 1, 3, (V[]){v_k_246, v_sp_240, v_hd_245});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2euniverseElimSyn_lam0(V self, V *args) {
  V v_e_242 = args[0];
  V v_syn_241 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_c_244;
  switch (heff_tag_of(v_syn_241)) {
  case TAG_MkSyn: {
    V v_f_243 = heff_field(v_syn_241, 0);
    heff_take_n(v_syn_241, 1ULL, 1);
    v_c_244 = heff_tr(heff_call(v_f_243, 1, (V[]){v_e_242}));
    break;
  }
  default: heff_nomatch(v_syn_241);
  }
  return heff_clo_n(g_heff_2eelab_2erules_2euniverseElimSyn_lam1, 2, 2, (V[]){v_c_244, v_sp_240});
}