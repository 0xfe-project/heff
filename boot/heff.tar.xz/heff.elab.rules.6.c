// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_AbsConst 8406
#define TAG_Become 65038
#define TAG_CloConst 61868
#define TAG_De 8978
#define TAG_Describe 2650
#define TAG_Expl 20488
#define TAG_ForDescriptive 19066
#define TAG_ForNominative 23095
#define TAG_Get 18914
#define TAG_HError 21467
#define TAG_HGlobal 55847
#define TAG_HLocal 25864
#define TAG_HMeta 17321
#define TAG_Impl 63555
#define TAG_Inst 64617
#define TAG_LSnoc 32613
#define TAG_Left 13886
#define TAG_LikeArray 39974
#define TAG_LikeFixed 5087
#define TAG_LikeFloat 20177
#define TAG_LikeFunction 24416
#define TAG_LikeInt 5296
#define TAG_LikeRecord 38505
#define TAG_LikeRune 45482
#define TAG_LikeString 41919
#define TAG_LikeSum 15116
#define TAG_LikeU 29548
#define TAG_MkAbs 54862
#define TAG_MkChk 56962
#define TAG_MkClo 57090
#define TAG_MkField 62648
#define TAG_MkFolded 17353
#define TAG_MkSyn 7342
#define TAG_MkTyp 8305
#define TAG_N 306
#define TAG_NoRules 38560
#define TAG_Nom 25944
#define TAG_Right 62770
#define TAG_SAbandon 23437
#define TAG_SApp 57081
#define TAG_SCode 58360
#define TAG_SCons 58684
#define TAG_SError 24172
#define TAG_SFix 61677
#define TAG_SFunction 64505
#define TAG_SGlobal 8650
#define TAG_SImplicit 59448
#define TAG_SIs 29577
#define TAG_SLam 1658
#define TAG_SLitBytes 43891
#define TAG_SLitFixed 54374
#define TAG_SLitFloat 3938
#define TAG_SLitFloat32 41499
#define TAG_SLitInt 21439
#define TAG_SLitRune 21707
#define TAG_SLitString 62718
#define TAG_SLocal 28569
#define TAG_SMatch 27203
#define TAG_SMetaApp 2372
#define TAG_SOpaque 44226
#define TAG_SPrim 55533
#define TAG_SProj 55716
#define TAG_SRec 7538
#define TAG_SSpecialize 52996
#define TAG_STag 9340
#define TAG_SpApp 44612
#define TAG_SpId 35501
#define TAG_SpProj 62333
#define TAG_SpSpec 18415
#define TAG_Throw 56084
#define TAG_Trace 9637
#define TAG_UpdateIn 26667
#define TAG_UpdateTo 27009
#define TAG_VCode 11305
#define TAG_VCons 11629
#define TAG_VDecode 24012
#define TAG_VFixed 12623
#define TAG_VFunction 37316
#define TAG_VLam 25505
#define TAG_VNeu 27559
#define TAG_VOpaque 37311
#define TAG_VPrimArray 11892
#define TAG_VPrimFloat 57621
#define TAG_VPrimInt 4244
#define TAG_VPrimRune 12870
#define TAG_VPrimString 23215
#define TAG_VRecord 10017
#define TAG_VSum 32852
#define TAG_VU 9520
#define LBL_aliases 1464806715
#define LBL_bind 9519364
#define LBL_byName 571997869
#define LBL_code 9554612
#define LBL_elabFor 712452832
#define LBL_evidence 1128105991
#define LBL_globals 352931696
#define LBL_insts 301719303
#define LBL_keys 9783995
#define LBL_kind 9787483
#define LBL_lams 9809570
#define LBL_len 316559
#define LBL_locals 849679763
#define LBL_malg 9839318
#define LBL_metas 305145640
#define LBL_msg 317947
#define LBL_name 9869138
#define LBL_named 305943379
#define LBL_names 305943394
#define LBL_note 9882809
#define LBL_scope 310622830
#define LBL_self 10021907
#define LBL_severity 75955546
#define LBL_span 10032145
#define LBL_stx 323761
#define LBL_text 10052084
#define LBL_ty 10476
#define LBL_val 326043
#define LBL_values 1123329101
static uint32_t shape_code__severity__msg__span__note[] = {LBL_code, LBL_severity, LBL_msg, LBL_span, LBL_note};
static uint32_t shape_keys__byName__values[] = {LBL_keys, LBL_byName, LBL_values};
static uint32_t shape_len__names[] = {LBL_len, LBL_names};
static uint32_t shape_scope__globals__elabFor__lams__self__insts__named__evidence[] = {LBL_scope, LBL_globals, LBL_elabFor, LBL_lams, LBL_self, LBL_insts, LBL_named, LBL_evidence};
static uint32_t shape_span__kind__text[] = {LBL_span, LBL_kind, LBL_text};
static uint32_t shape_stx__val[] = {LBL_stx, LBL_val};
V g_co_2ebind_24s1421083649x484987773(V, V, V, V);
V g_co_2ebind_24s1421083649x484987773_entry(V self, V *a);
extern Clo g_co_2ebind_24s1421083649x484987773_clo;
V g_heff_2eelab_2eenvironment_2ewithBound(V, V, V, V, V, V);
V g_heff_2eelab_2eenvironment_2ewithBound_entry(V self, V *a);
extern Clo g_heff_2eelab_2eenvironment_2ewithBound_clo;
V g_heff_2eelab_2eenvironment_2ewithInserted(V, V, V, V, V, V);
V g_heff_2eelab_2eenvironment_2ewithInserted_entry(V self, V *a);
extern Clo g_heff_2eelab_2eenvironment_2ewithInserted_clo;
HeffT2 g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr(V, V, V, V);
V g_heff_2eelab_2ememoed_2elam(V, V, V, V, V);
V g_heff_2eelab_2ememoed_2elam_entry(V self, V *a);
extern Clo g_heff_2eelab_2ememoed_2elam_clo;
V g_heff_2eelab_2ememoed_2elam_24s656135179x1177830782(V, V, V, V, V, V);
V g_heff_2eelab_2ememoed_2elam_24s656135179x1177830782_entry(V self, V *a);
extern Clo g_heff_2eelab_2ememoed_2elam_24s656135179x1177830782_clo;
V g_heff_2eelab_2emeta_2eliftU(V, V, V);
V g_heff_2eelab_2emeta_2eliftU_entry(V self, V *a);
extern Clo g_heff_2eelab_2emeta_2eliftU_clo;
V g_heff_2eelab_2emeta_2eliftU_24tok1(V, V, V, V);
V g_heff_2eelab_2emeta_2eliftU_24tok1_entry(V self, V *a);
extern Clo g_heff_2eelab_2emeta_2eliftU_24tok1_clo;
V g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(V, V);
V g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276_entry(V self, V *a);
extern Clo g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276_clo;
HeffT2 g_heff_2eelab_2ereadback_2eshownForcedRb_24cpr(V);
V g_heff_2eelab_2ereadback_2eshownTyF_24s1199850829x559778932(V, V, V);
V g_heff_2eelab_2ereadback_2eshownTyF_24s1199850829x559778932_entry(V self, V *a);
extern Clo g_heff_2eelab_2ereadback_2eshownTyF_24s1199850829x559778932_clo;
V g_heff_2eelab_2ereadback_2eshownTyF_24s1199850829x559778932_24tok1(V, V, V, V);
V g_heff_2eelab_2ereadback_2eshownTyF_24s1199850829x559778932_24tok1_entry(V self, V *a);
extern Clo g_heff_2eelab_2ereadback_2eshownTyF_24s1199850829x559778932_24tok1_clo;
V g_heff_2eelab_2erename_2edescribeKey(V);
V g_heff_2eelab_2erename_2edescribeKey_entry(V self, V *a);
extern Clo g_heff_2eelab_2erename_2edescribeKey_clo;
HeffT2 g_heff_2eelab_2erename_2efirstAliasOf_24cpr(V, V);
HeffT2 g_heff_2eelab_2erename_2erkOf_24cpr(V);
V g_heff_2eelab_2erules_2eapartSpines(V, V, V);
V g_heff_2eelab_2erules_2eapartSpines_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eapartSpines_clo;
V g_heff_2eelab_2erules_2eappendP(V, V);
V g_heff_2eelab_2erules_2eappendP_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eappendP_clo;
V g_heff_2eelab_2erules_2eappendP_24f1466307730x554320163(V, V);
V g_heff_2eelab_2erules_2eappendP_24f1466307730x554320163_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eappendP_24f1466307730x554320163_clo;
V g_heff_2eelab_2erules_2eappendP_24f269230951x1054333672(V, V);
V g_heff_2eelab_2erules_2eappendP_24f269230951x1054333672_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eappendP_24f269230951x1054333672_clo;
V g_heff_2eelab_2erules_2eappendP_24tok2(V, V, V);
V g_heff_2eelab_2erules_2eappendP_24tok2_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eappendP_24tok2_clo;
V g_heff_2eelab_2erules_2ecaseArm(V, V, V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2ecaseArm_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2ecaseArm_clo;
V g_heff_2eelab_2erules_2ecasesAt(V, V, V, V, V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2ecasesAt_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2ecasesAt_clo;
V g_heff_2eelab_2erules_2ecasesWith(V, V, V, V, V, V, V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2ecasesWith_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2ecasesWith_clo;
V g_heff_2eelab_2erules_2echeckingCandidates(V, V, V, V, V);
V g_heff_2eelab_2erules_2echeckingCandidates_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2echeckingCandidates_clo;
V g_heff_2eelab_2erules_2econclusionOf(V, V);
V g_heff_2eelab_2erules_2econclusionOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2econclusionOf_clo;
V g_heff_2eelab_2erules_2edefaultCopy(V, V, V);
V g_heff_2eelab_2erules_2edefaultCopy_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2edefaultCopy_clo;
V g_heff_2eelab_2erules_2edelayAt(V, V, V);
V g_heff_2eelab_2erules_2edelayAt_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2edelayAt_clo;
HeffT1 g_heff_2eelab_2erules_2edelayAt_24cpr(V, V, V);
V g_heff_2eelab_2erules_2edelayedCheck(V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2edelayedCheck_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2edelayedCheck_clo;
V g_heff_2eelab_2erules_2edownFrom_24dps(V, V);
V g_heff_2eelab_2erules_2edownFrom_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2edownFrom_24dps_clo;
HeffT3 g_heff_2eelab_2erules_2eeffectAndWorld_24cpr(V, V);
V g_heff_2eelab_2erules_2eeffectFits(V, V, V, V, V);
V g_heff_2eelab_2erules_2eeffectFits_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eeffectFits_clo;
V g_heff_2eelab_2erules_2eeffectInWorld(V, V, V);
V g_heff_2eelab_2erules_2eeffectInWorld_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eeffectInWorld_clo;
V g_heff_2eelab_2erules_2eeffectSaid(V, V, V, V);
V g_heff_2eelab_2erules_2eeffectSaid_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eeffectSaid_clo;
V g_heff_2eelab_2erules_2eeffectSaid_2efilterM_241(V, V, V, V);
V g_heff_2eelab_2erules_2eeffectSaid_2efilterM_241_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eeffectSaid_2efilterM_241_clo;
V g_heff_2eelab_2erules_2eevidenceFound(V, V, V, V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2eevidenceFound_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eevidenceFound_clo;
V g_heff_2eelab_2erules_2efreshMeta_24rec0_get(void);
HeffT1 g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr(V, V, V, V);
V g_heff_2eelab_2erules_2egoalShown(V, V, V);
V g_heff_2eelab_2erules_2egoalShown_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2egoalShown_clo;
V g_heff_2eelab_2erules_2einOrder(V, V, V, V, V);
V g_heff_2eelab_2erules_2einOrder_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2einOrder_clo;
V g_heff_2eelab_2erules_2einOrder_24dps(V, V, V, V, V, V);
V g_heff_2eelab_2erules_2einOrder_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2einOrder_24dps_clo;
V g_heff_2eelab_2erules_2einstLocals(V);
V g_heff_2eelab_2erules_2einstLocals_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2einstLocals_clo;
V g_heff_2eelab_2erules_2eintoSilent(V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2eintoSilent_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eintoSilent_clo;
V g_heff_2eelab_2erules_2eisEvidence(V, V);
V g_heff_2eelab_2erules_2eisEvidence_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eisEvidence_clo;
V g_heff_2eelab_2erules_2eletsAround(V, V, V, V, V);
V g_heff_2eelab_2erules_2eletsAround_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eletsAround_clo;
V g_heff_2eelab_2erules_2eletted_24generate1(V, V, V);
V g_heff_2eelab_2erules_2eletted_24generate1_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eletted_24generate1_clo;
V g_heff_2eelab_2erules_2eletted_24map1(V, V);
V g_heff_2eelab_2erules_2eletted_24map1_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eletted_24map1_clo;
HeffT2 g_heff_2eelab_2erules_2elookupP_24cpr(V, V);
V g_heff_2eelab_2erules_2epathSaid_2edown_241(V, V);
V g_heff_2eelab_2erules_2epathSaid_2edown_241_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2epathSaid_2edown_241_clo;
V g_heff_2eelab_2erules_2eprettyEqErr(V, V);
V g_heff_2eelab_2erules_2eprettyEqErr_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eprettyEqErr_clo;
V g_heff_2eelab_2erules_2erecordOf_24map0(V, V, V);
V g_heff_2eelab_2erules_2erecordOf_24map0_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2erecordOf_24map0_clo;
V g_heff_2eelab_2erules_2erecordTags(V, V, V, V);
V g_heff_2eelab_2erules_2erecordTags_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2erecordTags_clo;
HeffT2 g_heff_2eelab_2erules_2erigidFormer_24cpr(V, V);
V g_heff_2eelab_2erules_2eseeCovered(V, V, V, V, V);
V g_heff_2eelab_2erules_2eseeCovered_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eseeCovered_clo;
V g_heff_2eelab_2erules_2esolveHole(V, V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2esolveHole_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2esolveHole_clo;
V g_heff_2eelab_2erules_2esumFormation_24generate0(V, V, V);
V g_heff_2eelab_2erules_2esumFormation_24generate0_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2esumFormation_24generate0_clo;
V g_heff_2eelab_2erules_2esumFormation_24generate1(V, V, V);
V g_heff_2eelab_2erules_2esumFormation_24generate1_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2esumFormation_24generate1_clo;
V g_heff_2eelab_2erules_2esumFormation_24map0(V, V);
V g_heff_2eelab_2erules_2esumFormation_24map0_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2esumFormation_24map0_clo;
V g_heff_2eelab_2erules_2esumPaths(V, V);
V g_heff_2eelab_2erules_2esumPaths_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2esumPaths_clo;
V g_heff_2eelab_2erules_2etagsExposed(V, V, V, V, V, V);
V g_heff_2eelab_2erules_2etagsExposed_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2etagsExposed_clo;
V g_heff_2eelab_2erules_2etermParts(V, V);
V g_heff_2eelab_2erules_2etermParts_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2etermParts_clo;
V g_heff_2eelab_2erules_2ethroughCandidates(V, V, V);
V g_heff_2eelab_2erules_2ethroughCandidates_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2ethroughCandidates_clo;
V g_heff_2eelab_2erules_2etyStr(V, V);
V g_heff_2eelab_2erules_2etyStr_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2etyStr_clo;
HeffT2 g_heff_2eelab_2erules_2eupdateInner_24cpr(V);
HeffT2 g_heff_2eelab_2erules_2eworldOf_24cpr(V);
V g_heff_2eelab_2erules_2ewrittenAt(V, V);
V g_heff_2eelab_2erules_2ewrittenAt_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2ewrittenAt_clo;
HeffT3 g_heff_2eelab_2eunify_2emetasK_24cpr(V);
V g_heff_2eelab_2eunify_2euTermF_24s1310369198x1220154344(V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2euTermF_24s1310369198x1220154344_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2euTermF_24s1310369198x1220154344_clo;
V g_heff_2eelab_2eunify_2euTypeF_24s584682120x2121508022(V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2euTypeF_24s584682120x2121508022_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2euTypeF_24s584682120x2121508022_clo;
V g_heff_2eelab_2evalue_2ebehavior(V);
V g_heff_2eelab_2evalue_2ebehavior_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2ebehavior_clo;
V g_heff_2eelab_2evalue_2eforceEl(V, V);
V g_heff_2eelab_2evalue_2eforceEl_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eforceEl_clo;
V g_heff_2eelab_2evalue_2eforceTy(V, V);
V g_heff_2eelab_2evalue_2eforceTy_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eforceTy_clo;
V g_heff_2eelab_2evalue_2elevelOf(V);
V g_heff_2eelab_2evalue_2elevelOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2elevelOf_clo;
V g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(V, V, V, V);
V g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190_clo;
V g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(V, V, V, V);
V g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301_clo;
V g_heff_2eutil_2edict_2eindexed(V, V);
V g_heff_2eutil_2edict_2eindexed_entry(V self, V *a);
extern Clo g_heff_2eutil_2edict_2eindexed_clo;
V g_heff_2eutil_2edict_2ezipKV(V, V);
V g_heff_2eutil_2edict_2ezipKV_entry(V self, V *a);
extern Clo g_heff_2eutil_2edict_2ezipKV_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2ekeepIf(V, V);
V g_list_2ekeepIf_entry(V self, V *a);
extern Clo g_list_2ekeepIf_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1173914895x100384474(V);
V g_list_2emap_24s1173914895x100384474_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_clo;
V g_list_2emap_24s1173914895x100384474_24tok2(V, V);
V g_list_2emap_24s1173914895x100384474_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_24tok2_clo;
V g_list_2emap_24s1937570095x2110149801(V);
V g_list_2emap_24s1937570095x2110149801_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_clo;
V g_list_2emap_24s1937570095x2110149801_24tok2(V, V);
V g_list_2emap_24s1937570095x2110149801_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_24tok2_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2etraverse_24s1934076392x614790049(V, V);
V g_prelude_2etraverse_24s1934076392x614790049_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s1934076392x614790049_clo;
HeffT2 g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(V, V);
V g_std_2eordmap_2etoList_2etoListOnto_240(V, V);
V g_std_2eordmap_2etoList_2etoListOnto_240_entry(V self, V *a);
extern Clo g_std_2eordmap_2etoList_2etoListOnto_240_clo;
Clo g_heff_2eelab_2erules_2edownFrom_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2edownFrom_24dps_entry, 2, 0};

V g_heff_2eelab_2erules_2edownFrom_24dps(V v_n_240, V v_d_241) {
top: ;
  if (heff_intLt_c_lent(v_n_240, MK_INT(0LL), 2)) {
    heff_drop(v_n_240);
    return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
  } else {
    V v_cell_242 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_n_240), heff_hole()});
    V v_u_243 = heff_setFieldPeek(v_d_241, MK_INT(1LL), v_cell_242);
    V t_0 = heff_intSub(v_n_240, MK_INT(1LL));
    V t_1 = v_u_243;
    v_n_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
}
V g_heff_2eelab_2erules_2edownFrom_24dps_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2erules_2edownFrom_24dps(a[0], a1); heff_drop(a1); return r;
}
V g_heff_2eelab_2erules_2etyStr_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2etyStr_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2etyStr_entry, 2, 0};

V g_heff_2eelab_2erules_2etyStr(V v_e_240, V v_t_241) {
top: ;
  V v_scope_242 = heff_take_field(v_e_240, 0);
  V v_globals_243 = heff_get_n(v_e_240, 1, 8);
  V v_t_2423;
  switch (heff_tag_of(v_t_241)) {
  case TAG_VU: {
    v_t_2423 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_VDecode: {
    v_t_2423 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_VFunction: {
    V v_folded_2415 = heff_dup(heff_field(v_t_241, 5));
    v_t_2423 = v_folded_2415;
    break;
  }
  case TAG_VRecord: {
    v_t_2423 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_VSum: {
    v_t_2423 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_VPrimInt: {
    v_t_2423 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_VPrimFloat: {
    v_t_2423 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_VPrimString: {
    v_t_2423 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_VPrimRune: {
    v_t_2423 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_VPrimArray: {
    v_t_2423 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_VFixed: {
    v_t_2423 = NTAG(TAG_Nothing);
    break;
  }
  default: heff_nomatch(v_t_241);
  }
  V v_t_2424 = (g_heff_2eelab_2ereadback_2eshownTyF_24s1199850829x559778932(heff_take_field(v_scope_242, 0), v_t_241, v_t_2423));
  HeffT2 v_t_2432 = (g_heff_2eelab_2erename_2erkOf_24cpr(heff_clo_n(g_heff_2eelab_2erules_2etyStr_lam0, 1, 1, (V[]){v_globals_243})));
  {
    V v_field_2434 = v_t_2432.f[1];
    heff_drop(v_t_2432.f[0]);
    V v_t_2435 = heff_tr(heff_call(v_field_2434, 1, (V[]){v_t_2424}));
    return ({ V a_0 = heff_dup(g_heff_2eelab_2erules_2efreshMeta_24rec0_get()); V a_1 = MK_INT(0LL); V b_2 = heff_get_n(v_scope_242, 1, 5); V a_3 = v_t_2435; V r_ = (g_heff_2esyntax_2esurfaceprint_2etyF_24s35957631x1610618301(a_0, a_1, b_2, a_3)); heff_drop(b_2); r_; });
  }
}
V g_heff_2eelab_2erules_2etyStr_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2etyStr(a[0], a[1]);
}
V g_heff_2eelab_2erules_2etyStr_lam0(V self, V *args) {
  V v_x_2425 = args[0];
  V v_globals_243 = heff_env(self)[0];
  V v_d_2426 = (g_heff_2eelab_2erename_2edescribeKey(heff_dup(v_x_2425)));
  heff_clo_take(self, 1);
  V v_t_2427 = ({ V b_0 = heff_get_n(v_globals_243, 2, 8); V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2eordmap_2etoList_2etoListOnto_240(b_0, a_1)); heff_drop(b_0); r_; });
  HeffT2 v_t_2428 = ({ V a_0 = v_t_2427; V a_1 = v_x_2425; HeffT2 r_ = (g_heff_2eelab_2erename_2efirstAliasOf_24cpr(a_0, a_1)); heff_drop(v_t_2427); heff_drop(v_x_2425); r_; });
  {
    V v_field_2430 = v_t_2428.f[1];
    int64_t v_tag_2429 = ((int64_t)v_t_2428.f[0]);
    if ((v_tag_2429 == ((int64_t)0ULL))) {
      heff_drop(v_d_2426);
      V v_x_2431 = v_field_2430;
      return v_x_2431;
    } else {
      heff_drop(v_field_2430);
      return v_d_2426;
    }
  }
}
HEFF_LIT(g_heff_2eelab_2erules_2eisEvidence_str0, 5, "co.<:");
HEFF_LIT(g_heff_2eelab_2erules_2eisEvidence_str1, 5, "co.<:");
Clo g_heff_2eelab_2erules_2eisEvidence_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eisEvidence_entry, 2, 0};

V g_heff_2eelab_2erules_2eisEvidence(V v_mc_240, V v_goal_241) {
top: ;
  V v_it_242 = (g_heff_2eelab_2evalue_2eforceTy(v_mc_240, v_goal_241));
  switch (heff_tag_of(v_it_242)) {
  case TAG_VU: {
    heff_take_n(v_it_242, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_VDecode: {
    V v_it1_244 = heff_field(v_it_242, 0);
    V v_sp_245 = heff_field(v_it_242, 1);
    heff_take_n(v_it_242, 3ULL, 5);
    switch (heff_tag_of(v_it1_244)) {
    case TAG_HLocal: {
      heff_take_n(v_it1_244, 0ULL, 1);
      heff_drop(v_sp_245);
      return NTAG(TAG_False);
    }
    case TAG_HGlobal: {
      V v_k_2410 = heff_field(v_it1_244, 0);
      heff_take_n(v_it1_244, 1ULL, 1);
      switch (heff_tag_of(v_sp_245)) {
      case TAG_SpId: {
        heff_drop(v_k_2410);
        return NTAG(TAG_False);
      }
      case TAG_SpApp: {
        V v_sp1_2411 = heff_field(v_sp_245, 0);
        heff_take_n(v_sp_245, 1ULL, 2);
        switch (heff_tag_of(v_sp1_2411)) {
        case TAG_SpId: {
          heff_drop(v_k_2410);
          return NTAG(TAG_False);
        }
        case TAG_SpApp: {
          V v_sp11_2413 = heff_field(v_sp1_2411, 0);
          heff_take_n(v_sp1_2411, 1ULL, 2);
          switch (heff_tag_of(v_sp11_2413)) {
          case TAG_SpId: {
            V v_ret_24bool = heff_bool(heff_strEq_c_lent(v_k_2410, ((V)&g_heff_2eelab_2erules_2eisEvidence_str0), 2));
            heff_drop(v_k_2410);
            return v_ret_24bool;
          }
          case TAG_SpApp: {
            heff_take_n(v_sp11_2413, 0ULL, 2);
            heff_drop(v_k_2410);
            return NTAG(TAG_False);
          }
          case TAG_SpProj: {
            heff_take_n(v_sp11_2413, 0ULL, 2);
            heff_drop(v_k_2410);
            return NTAG(TAG_False);
          }
          case TAG_SpSpec: {
            heff_take_n(v_sp11_2413, 0ULL, 3);
            heff_drop(v_k_2410);
            return NTAG(TAG_False);
          }
          default: return heff_nomatch(v_sp11_2413);
          }
        }
        case TAG_SpProj: {
          heff_take_n(v_sp1_2411, 0ULL, 2);
          heff_drop(v_k_2410);
          return NTAG(TAG_False);
        }
        case TAG_SpSpec: {
          heff_take_n(v_sp1_2411, 0ULL, 3);
          heff_drop(v_k_2410);
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_sp1_2411);
        }
      }
      case TAG_SpProj: {
        heff_take_n(v_sp_245, 0ULL, 2);
        heff_drop(v_k_2410);
        return NTAG(TAG_False);
      }
      case TAG_SpSpec: {
        heff_take_n(v_sp_245, 0ULL, 3);
        heff_drop(v_k_2410);
        return NTAG(TAG_False);
      }
      default: return heff_nomatch(v_sp_245);
      }
    }
    case TAG_HMeta: {
      heff_take_n(v_it1_244, 0ULL, 1);
      heff_drop(v_sp_245);
      return NTAG(TAG_False);
    }
    case TAG_HError: {
      heff_drop(v_sp_245);
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_it1_244);
    }
  }
  case TAG_VFunction: {
    V v_it6_2438 = heff_field(v_it_242, 5);
    heff_take_n(v_it_242, 32ULL, 6);
    switch (heff_tag_of(v_it6_2438)) {
    case TAG_Nothing: {
      return NTAG(TAG_False);
    }
    case TAG_Just: {
      V v_it61_2439 = heff_field(v_it6_2438, 0);
      heff_take_n(v_it6_2438, 1ULL, 1);
      switch (heff_tag_of(v_it61_2439)) {
      case TAG_MkFolded: {
        V v_it611_2440 = heff_field(v_it61_2439, 0);
        V v_spTh_2441 = heff_field(v_it61_2439, 1);
        heff_take_n(v_it61_2439, 3ULL, 2);
        switch (heff_tag_of(v_it611_2440)) {
        case TAG_HLocal: {
          heff_take_n(v_it611_2440, 0ULL, 1);
          heff_drop(v_spTh_2441);
          return NTAG(TAG_False);
        }
        case TAG_HGlobal: {
          V v_k_2443 = heff_field(v_it611_2440, 0);
          heff_take_n(v_it611_2440, 1ULL, 1);
          V v_sp_2444 = heff_tr(heff_call(v_spTh_2441, 1, (V[]){NTAG(TAG_MkUnit)}));
          switch (heff_tag_of(v_sp_2444)) {
          case TAG_SpId: {
            heff_drop(v_k_2443);
            return NTAG(TAG_False);
          }
          case TAG_SpApp: {
            V v_sp1_2445 = heff_field(v_sp_2444, 0);
            heff_take_n(v_sp_2444, 1ULL, 2);
            switch (heff_tag_of(v_sp1_2445)) {
            case TAG_SpId: {
              heff_drop(v_k_2443);
              return NTAG(TAG_False);
            }
            case TAG_SpApp: {
              V v_sp11_2447 = heff_field(v_sp1_2445, 0);
              heff_take_n(v_sp1_2445, 1ULL, 2);
              switch (heff_tag_of(v_sp11_2447)) {
              case TAG_SpId: {
                V v_ret_24bool = heff_bool(heff_strEq_c_lent(v_k_2443, ((V)&g_heff_2eelab_2erules_2eisEvidence_str1), 2));
                heff_drop(v_k_2443);
                return v_ret_24bool;
              }
              case TAG_SpApp: {
                heff_take_n(v_sp11_2447, 0ULL, 2);
                heff_drop(v_k_2443);
                return NTAG(TAG_False);
              }
              case TAG_SpProj: {
                heff_take_n(v_sp11_2447, 0ULL, 2);
                heff_drop(v_k_2443);
                return NTAG(TAG_False);
              }
              case TAG_SpSpec: {
                heff_take_n(v_sp11_2447, 0ULL, 3);
                heff_drop(v_k_2443);
                return NTAG(TAG_False);
              }
              default: return heff_nomatch(v_sp11_2447);
              }
            }
            case TAG_SpProj: {
              heff_take_n(v_sp1_2445, 0ULL, 2);
              heff_drop(v_k_2443);
              return NTAG(TAG_False);
            }
            case TAG_SpSpec: {
              heff_take_n(v_sp1_2445, 0ULL, 3);
              heff_drop(v_k_2443);
              return NTAG(TAG_False);
            }
            default: return heff_nomatch(v_sp1_2445);
            }
          }
          case TAG_SpProj: {
            heff_take_n(v_sp_2444, 0ULL, 2);
            heff_drop(v_k_2443);
            return NTAG(TAG_False);
          }
          case TAG_SpSpec: {
            heff_take_n(v_sp_2444, 0ULL, 3);
            heff_drop(v_k_2443);
            return NTAG(TAG_False);
          }
          default: return heff_nomatch(v_sp_2444);
          }
        }
        case TAG_HMeta: {
          heff_take_n(v_it611_2440, 0ULL, 1);
          heff_drop(v_spTh_2441);
          return NTAG(TAG_False);
        }
        case TAG_HError: {
          heff_drop(v_spTh_2441);
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_it611_2440);
        }
      }
      default: return heff_nomatch(v_it61_2439);
      }
    }
    default: return heff_nomatch(v_it6_2438);
    }
  }
  case TAG_VRecord: {
    heff_take_n(v_it_242, 0ULL, 4);
    return NTAG(TAG_False);
  }
  case TAG_VSum: {
    heff_take_n(v_it_242, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_VPrimInt: {
    return NTAG(TAG_False);
  }
  case TAG_VPrimFloat: {
    return NTAG(TAG_False);
  }
  case TAG_VPrimString: {
    return NTAG(TAG_False);
  }
  case TAG_VPrimRune: {
    return NTAG(TAG_False);
  }
  case TAG_VPrimArray: {
    heff_take_n(v_it_242, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_VFixed: {
    heff_take_n(v_it_242, 0ULL, 1);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_it_242);
  }
}
V g_heff_2eelab_2erules_2eisEvidence_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2erules_2eisEvidence(a0, a[1]); heff_drop(a0); return r;
}
V g_heff_2eelab_2erules_2econclusionOf_lam1(V self, V *args);
V g_heff_2eelab_2erules_2econclusionOf_lam0(V self, V *args);
V g_heff_2eelab_2erules_2econclusionOf_lam3(V self, V *args);
V g_heff_2eelab_2erules_2econclusionOf_lam2(V self, V *args);
Clo g_heff_2eelab_2erules_2econclusionOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2econclusionOf_entry, 2, 0};

V g_heff_2eelab_2erules_2econclusionOf(V v_n_240, V v_ty_241) {
top: ;
  switch (heff_tag_of(v_ty_241)) {
  case TAG_VU: {
    heff_drop(v_n_240);
    return v_ty_241;
  }
  case TAG_VDecode: {
    heff_drop(v_n_240);
    return v_ty_241;
  }
  case TAG_VFunction: {
    V v_it4_2411 = heff_dup(heff_field(v_ty_241, 3));
    switch (heff_tag_of(v_it4_2411)) {
    case TAG_Expl: {
      heff_drop(v_n_240);
      return v_ty_241;
    }
    case TAG_Impl: {
      switch (heff_tag_of(v_ty_241)) {
      case TAG_VFunction: {
        V v_dom_2415 = heff_field(v_ty_241, 1);
        V v_cod_2416 = heff_field(v_ty_241, 2);
        heff_take_n(v_ty_241, 6ULL, 6);
        V v_x1_2426;
        switch (heff_tag_of(v_cod_2416)) {
        case TAG_MkClo: {
          V v_vs_2421 = heff_field(v_cod_2416, 1);
          V v_body_2422 = heff_field(v_cod_2416, 2);
          heff_take_n(v_cod_2416, 6ULL, 3);
          v_x1_2426 = heff_tr(heff_call(v_body_2422, 1, (V[]){heff_tag_n(TAG_LSnoc, 2, (V[]){v_vs_2421, heff_clo_n(g_heff_2eelab_2erules_2econclusionOf_lam0, 1, 2, (V[]){heff_dup(v_n_240), v_dom_2415})})}));
          break;
        }
        case TAG_CloConst: {
          V v_body_2425 = heff_field(v_cod_2416, 0);
          heff_take_n(v_cod_2416, 1ULL, 1);
          heff_drop(v_dom_2415);
          v_x1_2426 = v_body_2425;
          break;
        }
        default: heff_nomatch(v_cod_2416);
        }
        V v_t_2430;
        switch (heff_tag_of(v_x1_2426)) {
        case TAG_Nom: {
          V v_x_2427 = heff_field(v_x1_2426, 0);
          heff_take_n(v_x1_2426, 1ULL, 1);
          v_t_2430 = v_x_2427;
          break;
        }
        case TAG_Describe: {
          heff_take_n(v_x1_2426, 0ULL, 1);
          v_t_2430 = heff_abandon();
          break;
        }
        case TAG_Become: {
          V v_x_2429 = heff_field(v_x1_2426, 0);
          heff_take_n(v_x1_2426, 1ULL, 1);
          v_t_2430 = v_x_2429;
          break;
        }
        default: heff_nomatch(v_x1_2426);
        }
        V t_0 = heff_intAdd(v_n_240, MK_INT(1LL));
        V t_1 = v_t_2430;
        v_n_240 = t_0;
        v_ty_241 = t_1;
        goto top;
      }
      default: return heff_nomatch(v_ty_241);
      }
    }
    case TAG_Inst: {
      switch (heff_tag_of(v_ty_241)) {
      case TAG_VFunction: {
        V v_dom_2432 = heff_field(v_ty_241, 1);
        V v_cod_2433 = heff_field(v_ty_241, 2);
        heff_take_n(v_ty_241, 6ULL, 6);
        V v_x1_2443;
        switch (heff_tag_of(v_cod_2433)) {
        case TAG_MkClo: {
          V v_vs_2438 = heff_field(v_cod_2433, 1);
          V v_body_2439 = heff_field(v_cod_2433, 2);
          heff_take_n(v_cod_2433, 6ULL, 3);
          v_x1_2443 = heff_tr(heff_call(v_body_2439, 1, (V[]){heff_tag_n(TAG_LSnoc, 2, (V[]){v_vs_2438, heff_clo_n(g_heff_2eelab_2erules_2econclusionOf_lam2, 1, 2, (V[]){heff_dup(v_n_240), v_dom_2432})})}));
          break;
        }
        case TAG_CloConst: {
          V v_body_2442 = heff_field(v_cod_2433, 0);
          heff_take_n(v_cod_2433, 1ULL, 1);
          heff_drop(v_dom_2432);
          v_x1_2443 = v_body_2442;
          break;
        }
        default: heff_nomatch(v_cod_2433);
        }
        V v_t_2447;
        switch (heff_tag_of(v_x1_2443)) {
        case TAG_Nom: {
          V v_x_2444 = heff_field(v_x1_2443, 0);
          heff_take_n(v_x1_2443, 1ULL, 1);
          v_t_2447 = v_x_2444;
          break;
        }
        case TAG_Describe: {
          heff_take_n(v_x1_2443, 0ULL, 1);
          v_t_2447 = heff_abandon();
          break;
        }
        case TAG_Become: {
          V v_x_2446 = heff_field(v_x1_2443, 0);
          heff_take_n(v_x1_2443, 1ULL, 1);
          v_t_2447 = v_x_2446;
          break;
        }
        default: heff_nomatch(v_x1_2443);
        }
        V t_0 = heff_intAdd(v_n_240, MK_INT(1LL));
        V t_1 = v_t_2447;
        v_n_240 = t_0;
        v_ty_241 = t_1;
        goto top;
      }
      default: return heff_nomatch(v_ty_241);
      }
    }
    default: return heff_nomatch(v_it4_2411);
    }
  }
  case TAG_VRecord: {
    heff_drop(v_n_240);
    return v_ty_241;
  }
  case TAG_VSum: {
    heff_drop(v_n_240);
    return v_ty_241;
  }
  case TAG_VPrimInt: {
    heff_drop(v_n_240);
    return v_ty_241;
  }
  case TAG_VPrimFloat: {
    heff_drop(v_n_240);
    return v_ty_241;
  }
  case TAG_VPrimString: {
    heff_drop(v_n_240);
    return v_ty_241;
  }
  case TAG_VPrimRune: {
    heff_drop(v_n_240);
    return v_ty_241;
  }
  case TAG_VPrimArray: {
    heff_drop(v_n_240);
    return v_ty_241;
  }
  case TAG_VFixed: {
    heff_drop(v_n_240);
    return v_ty_241;
  }
  default: return heff_nomatch(v_ty_241);
  }
}
V g_heff_2eelab_2erules_2econclusionOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2econclusionOf(a[0], a[1]);
}
V g_heff_2eelab_2erules_2econclusionOf_lam1(V self, V *args) {
  V v_u_2424 = args[0];
  V v_dom_2415 = heff_env(self)[0];
  heff_drop(v_u_2424);
  heff_clo_take(self, 1);
  return v_dom_2415;
}
V g_heff_2eelab_2erules_2econclusionOf_lam0(V self, V *args) {
  V v_u_2423 = args[0];
  V v_n_240 = heff_env(self)[0];
  V v_dom_2415 = heff_env(self)[1];
  heff_drop(v_u_2423);
  heff_clo_take(self, 2);
  return (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(heff_tag_n(TAG_HLocal, 1, (V[]){v_n_240}), NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2erules_2econclusionOf_lam1, 1, 1, (V[]){v_dom_2415}), NTAG(TAG_Nothing)));
}
V g_heff_2eelab_2erules_2econclusionOf_lam3(V self, V *args) {
  V v_u_2441 = args[0];
  V v_dom_2432 = heff_env(self)[0];
  heff_drop(v_u_2441);
  heff_clo_take(self, 1);
  return v_dom_2432;
}
V g_heff_2eelab_2erules_2econclusionOf_lam2(V self, V *args) {
  V v_u_2440 = args[0];
  V v_n_240 = heff_env(self)[0];
  V v_dom_2432 = heff_env(self)[1];
  heff_drop(v_u_2440);
  heff_clo_take(self, 2);
  return (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(heff_tag_n(TAG_HLocal, 1, (V[]){v_n_240}), NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2erules_2econclusionOf_lam3, 1, 1, (V[]){v_dom_2432}), NTAG(TAG_Nothing)));
}
Clo g_heff_2eelab_2erules_2eapartSpines_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eapartSpines_entry, 3, 0};

V g_heff_2eelab_2erules_2eapartSpines(V v_mc_240, V v_x2_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_SpId: {
    return NTAG(TAG_False);
  }
  case TAG_SpApp: {
    V v_sp_243 = heff_field(v_x2_241, 0);
    V v_a_244 = heff_field(v_x2_241, 1);
    switch (heff_tag_of(v_x3_242)) {
    case TAG_SpId: {
      return NTAG(TAG_False);
    }
    case TAG_SpApp: {
      V v_sp2_245 = heff_field(v_x3_242, 0);
      V v_b_246 = heff_field(v_x3_242, 1);
      HeffT2 v_t_247 = (g_heff_2eelab_2erules_2erigidFormer_24cpr(v_mc_240, heff_dup(v_a_244)));
      {
        V v_field_249 = v_t_247.f[1];
        int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
        if ((v_tag_248 == ((int64_t)0ULL))) {
          V v_k_2410 = v_field_249;
          HeffT2 v_t_2411 = (g_heff_2eelab_2erules_2erigidFormer_24cpr(v_mc_240, heff_dup(v_b_246)));
          {
            V v_field_2413 = v_t_2411.f[1];
            int64_t v_tag_2412 = ((int64_t)v_t_2411.f[0]);
            if ((v_tag_2412 == ((int64_t)0ULL))) {
              V v_k2_2414 = v_field_2413;
              if (!heff_strEq_c_lent(v_k_2410, v_k2_2414, 0)) {
                heff_drop(v_k_2410);
                heff_drop(v_k2_2414);
                return NTAG(TAG_True);
              } else {
                heff_drop(v_k_2410);
                heff_drop(v_k2_2414);
                V t_0 = v_mc_240;
                V t_1 = v_sp_243;
                V t_2 = v_sp2_245;
                v_mc_240 = t_0;
                v_x2_241 = t_1;
                v_x3_242 = t_2;
                goto top;
              }
            } else {
              heff_drop(v_k_2410);
              heff_drop(v_field_2413);
              V t_0 = v_mc_240;
              V t_1 = v_sp_243;
              V t_2 = v_sp2_245;
              v_mc_240 = t_0;
              v_x2_241 = t_1;
              v_x3_242 = t_2;
              goto top;
            }
          }
        } else {
          heff_drop(v_field_249);
          V t_0 = v_mc_240;
          V t_1 = v_sp_243;
          V t_2 = v_sp2_245;
          v_mc_240 = t_0;
          v_x2_241 = t_1;
          v_x3_242 = t_2;
          goto top;
        }
      }
    }
    case TAG_SpProj: {
      return NTAG(TAG_False);
    }
    case TAG_SpSpec: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x3_242);
    }
  }
  case TAG_SpProj: {
    return NTAG(TAG_False);
  }
  case TAG_SpSpec: {
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eelab_2erules_2eapartSpines_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V r = g_heff_2eelab_2erules_2eapartSpines(a0, a1, a2); heff_drop(a0); heff_drop(a1); heff_drop(a2); return r;
}
V g_heff_2eelab_2erules_2eeffectSaid_lam0(V self, V *args); static Clo g_heff_2eelab_2erules_2eeffectSaid_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eeffectSaid_lam0, 1, 0};
V g_heff_2eelab_2erules_2eeffectSaid_lam2(V self, V *args);
V g_heff_2eelab_2erules_2eeffectSaid_lam4(V self, V *args);
V g_heff_2eelab_2erules_2eeffectSaid_lam5(V self, V *args);
V g_heff_2eelab_2erules_2eeffectSaid_lam3(V self, V *args);
V g_heff_2eelab_2erules_2eeffectSaid_lam1(V self, V *args);
Clo g_heff_2eelab_2erules_2eeffectSaid_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eeffectSaid_entry, 4, 0};

V g_heff_2eelab_2erules_2eeffectSaid(V v_e_240, V v_goal_241, V v_hd_242, V v_k_243) {
top: ;
  V v_t_245 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2erules_2eeffectSaid_lam0_clo)})});
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_245})});
  V v_t_247 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_242, 2)), 1, (V[]){v_t_246}));
  return heff_tail(heff_dup(heff_rfield(v_hd_242, 1)), 2, (V[]){v_t_247, heff_clo_n(g_heff_2eelab_2erules_2eeffectSaid_lam1, 1, 4, (V[]){v_goal_241, v_e_240, v_k_243, v_hd_242})});
}
V g_heff_2eelab_2erules_2eeffectSaid_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2eeffectSaid(a[0], a[1], a[2], a[3]);
}
V g_heff_2eelab_2erules_2eeffectSaid_lam0(V self, V *args) {
  V v_c_244 = args[0];
  return heff_get_n(v_c_244, 3, 9);
}
V g_heff_2eelab_2erules_2eeffectSaid_lam2(V self, V *args) {
  V v_w_2439 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_h_2413 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = ((V)&g_heff_2eelab_2erules_2eeffectFits_clo);
  heff_room[0] = v_e_240;
  heff_room[1] = v_h_2413;
  heff_room[2] = v_w_2439;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
V g_heff_2eelab_2erules_2eeffectSaid_lam4(V self, V *args) {
  V v_p_2453 = args[0];
  V v_p_2454 = args[1];
  V v_g_2449 = heff_env(self)[0];
  V v_len_2451 = heff_env(self)[1];
  V v_names_2452 = heff_env(self)[2];
  V v_h_2413 = heff_env(self)[3];
  V v_hw_2447 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2455 = heff_tr(heff_call(((V)&g_heff_2eelab_2eunify_2euTermF_24s1310369198x1220154344_clo), 4, (V[]){v_g_2449, heff_rec_n(2, shape_len__names, (V[]){v_len_2451, v_names_2452}), v_h_2413, v_hw_2447}));
  return (g_heff_2eelab_2emeta_2eliftU(v_t_2455, v_p_2453, v_p_2454));
}
V g_heff_2eelab_2erules_2eeffectSaid_lam5(V self, V *args) {
  V v_x_2459 = args[0];
  V v_k_2458 = heff_env(self)[0];
  heff_drop(v_x_2459);
  heff_clo_take(self, 1);
  V f_ = v_k_2458;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2eeffectSaid_lam3(V self, V *args) {
  V v_x_2440 = args[0];
  V v_k_243 = heff_env(self)[0];
  V v_x_248 = heff_env(self)[1];
  V v_e_240 = heff_env(self)[2];
  V v_h_2413 = heff_env(self)[3];
  V v_hd_242 = heff_env(self)[4];
  switch (heff_tag_of(v_x_2440)) {
  case TAG_Nil: {
    heff_clo_take(self, 5);
    heff_drop(v_x_248);
    heff_drop_rec(v_e_240, 8);
    heff_drop(v_h_2413);
    heff_drop_rec(v_hd_242, 3);
    V f_ = v_k_243;
    args[0] = NTAG(TAG_MkUnit);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Cons: {
    V v_one_2441 = heff_field(v_x_2440, 0);
    V v_it2_2442 = heff_field(v_x_2440, 1);
    heff_take_n(v_x_2440, 3ULL, 2);
    switch (heff_tag_of(v_it2_2442)) {
    case TAG_Nil: {
      heff_clo_take(self, 5);
      HeffT3 v_t_2443 = ({ V a_0 = v_x_248; V a_1 = heff_get_n(v_one_2441, 3, 6); HeffT3 r_ = (g_heff_2eelab_2erules_2eeffectAndWorld_24cpr(a_0, a_1)); heff_drop(v_x_248); r_; });
      {
        V v_field_2445 = v_t_2443.f[1];
        V v_field_2446 = v_t_2443.f[2];
        int64_t v_tag_2444 = ((int64_t)v_t_2443.f[0]);
        if ((v_tag_2444 == ((int64_t)0ULL))) {
          V v_hw_2447 = v_field_2445;
          V v_it12_2448 = v_field_2446;
          heff_drop(v_it12_2448);
          V v_g_2449 = heff_take_field(v_e_240, 1);
          V v_c_2450 = heff_get_n(v_e_240, 0, 8);
          V v_len_2451 = heff_take_field(v_c_2450, 0);
          V v_names_2452 = heff_get_n(v_c_2450, 1, 5);
          V v_c_2456 = heff_clo_n(g_heff_2eelab_2erules_2eeffectSaid_lam4, 2, 5, (V[]){v_g_2449, v_len_2451, v_names_2452, v_h_2413, v_hw_2447});
          V v_hd_2457 = v_hd_242;
          V v_k_2458 = v_k_243;
          V f_ = v_c_2456;
          heff_room[0] = v_hd_2457;
          heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2eeffectSaid_lam5, 1, 1, (V[]){v_k_2458});
          if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
          return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
        } else {
          heff_drop_rec(v_e_240, 8);
          heff_drop(v_h_2413);
          heff_drop_rec(v_hd_242, 3);
          heff_drop(v_field_2445);
          heff_drop(v_field_2446);
          V f_ = v_k_243;
          args[0] = NTAG(TAG_MkUnit);
          if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
          return heff_tail(f_, 1, args);
        }
      }
    }
    case TAG_Cons: {
      heff_take_n(v_it2_2442, 0ULL, 2);
      heff_clo_take(self, 5);
      heff_drop(v_x_248);
      heff_drop_rec(v_e_240, 8);
      heff_drop(v_h_2413);
      heff_drop_rec(v_hd_242, 3);
      heff_drop_rec(v_one_2441, 6);
      V f_ = v_k_243;
      args[0] = NTAG(TAG_MkUnit);
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    default: return heff_nomatch(v_it2_2442);
    }
  }
  default: return heff_nomatch(v_x_2440);
  }
}
V g_heff_2eelab_2erules_2eeffectSaid_lam1(V self, V *args) {
  V v_x_248 = args[0];
  V v_goal_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_k_243 = heff_env(self)[2];
  V v_hd_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  HeffT3 v_t_249 = (g_heff_2eelab_2erules_2eeffectAndWorld_24cpr(v_x_248, v_goal_241));
  {
    V v_field_2411 = v_t_249.f[1];
    V v_field_2412 = v_t_249.f[2];
    int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
    if ((v_tag_2410 == ((int64_t)0ULL))) {
      V v_h_2413 = v_field_2411;
      V v_w_2414 = v_field_2412;
      HeffT3 v_t_2415 = (g_heff_2eelab_2eunify_2emetasK_24cpr(heff_dup(v_x_248)));
      {
        V v_field_2416 = v_t_2415.f[0];
        heff_drop(v_t_2415.f[1]);
        heff_drop(v_t_2415.f[2]);
        V v_t_2419 = heff_get_n(heff_dup(heff_rfield(v_e_240, 0)), 0, 5);
        V v_x1_2420 = heff_tr(heff_call(v_field_2416, 3, (V[]){MK_INT(20LL), v_t_2419, heff_dup(v_h_2413)}));
        switch (heff_tag_of(v_x1_2420)) {
        case TAG_Nil: {
          heff_drop(v_x_248);
          heff_drop_rec(v_e_240, 8);
          heff_drop_rec(v_hd_242, 3);
          heff_drop(v_h_2413);
          heff_drop(v_w_2414);
          V f_ = v_k_243;
          args[0] = NTAG(TAG_MkUnit);
          if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
          return heff_tail(f_, 1, args);
        }
        case TAG_Cons: {
          heff_take_n(v_x1_2420, 0ULL, 2);
          V v_v_2423 = (g_heff_2eelab_2evalue_2eforceEl(v_x_248, heff_dup(v_h_2413)));
          V v_t_2436;
          switch (heff_tag_of(v_v_2423)) {
          case TAG_VNeu: {
            V v_v1_2424 = heff_field(v_v_2423, 0);
            heff_take_n(v_v_2423, 1ULL, 5);
            switch (heff_tag_of(v_v1_2424)) {
            case TAG_HLocal: {
              heff_take_n(v_v1_2424, 0ULL, 1);
              v_t_2436 = NTAG(TAG_False);
              break;
            }
            case TAG_HGlobal: {
              heff_take_n(v_v1_2424, 0ULL, 1);
              v_t_2436 = NTAG(TAG_False);
              break;
            }
            case TAG_HMeta: {
              heff_take_n(v_v1_2424, 0ULL, 1);
              v_t_2436 = NTAG(TAG_True);
              break;
            }
            case TAG_HError: {
              v_t_2436 = NTAG(TAG_False);
              break;
            }
            default: heff_nomatch(v_v1_2424);
            }
            break;
          }
          case TAG_VCode: {
            heff_take_n(v_v_2423, 0ULL, 1);
            v_t_2436 = NTAG(TAG_False);
            break;
          }
          case TAG_VLam: {
            heff_take_n(v_v_2423, 0ULL, 2);
            v_t_2436 = NTAG(TAG_False);
            break;
          }
          case TAG_VCons: {
            heff_take_n(v_v_2423, 0ULL, 1);
            v_t_2436 = NTAG(TAG_False);
            break;
          }
          case TAG_VOpaque: {
            v_t_2436 = NTAG(TAG_False);
            break;
          }
          default: heff_nomatch(v_v_2423);
          }
          if ((heff_dup(v_t_2436) == NTAG(TAG_True))) {
            heff_drop(v_x_248);
            heff_drop_rec(v_e_240, 8);
            heff_drop_rec(v_hd_242, 3);
            heff_drop(v_h_2413);
            heff_drop(v_w_2414);
            heff_drop(v_t_2436);
            V f_ = v_k_243;
            args[0] = NTAG(TAG_MkUnit);
            if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
            return heff_tail(f_, 1, args);
          } else {
            heff_drop(v_t_2436);
            V v_t_2437 = (g_heff_2eelab_2erules_2eeffectInWorld(v_x_248, v_h_2413, v_w_2414));
            if ((heff_dup(v_t_2437) == NTAG(TAG_True))) {
              heff_drop(v_x_248);
              heff_drop_rec(v_e_240, 8);
              heff_drop_rec(v_hd_242, 3);
              heff_drop(v_h_2413);
              heff_drop(v_t_2437);
              V f_ = v_k_243;
              args[0] = NTAG(TAG_MkUnit);
              if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
              return heff_tail(f_, 1, args);
            } else {
              heff_drop(v_t_2437);
              V v_t_2438 = (g_heff_2eelab_2erules_2einstLocals(heff_dup(v_e_240)));
              return (g_heff_2eelab_2erules_2eeffectSaid_2efilterM_241(heff_clo_n(g_heff_2eelab_2erules_2eeffectSaid_lam2, 1, 2, (V[]){heff_dup(v_e_240), heff_dup(v_h_2413)}), v_t_2438, heff_dup(v_hd_242), heff_clo_n(g_heff_2eelab_2erules_2eeffectSaid_lam3, 1, 5, (V[]){v_k_243, v_x_248, v_e_240, v_h_2413, v_hd_242})));
            }
          }
        }
        default: return heff_nomatch(v_x1_2420);
        }
      }
    } else {
      heff_drop(v_x_248);
      heff_drop_rec(v_e_240, 8);
      heff_drop_rec(v_hd_242, 3);
      heff_drop(v_field_2411);
      heff_drop(v_field_2412);
      V f_ = v_k_243;
      args[0] = NTAG(TAG_MkUnit);
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
  }
}
HEFF_LIT(g_heff_2eelab_2erules_2edelayedCheck_str0, 5, "this ");
HEFF_LIT(g_heff_2eelab_2erules_2edelayedCheck_str1, 28, " does not fit how it is used");
V g_heff_2eelab_2erules_2edelayedCheck_lam2(V self, V *args);
V g_heff_2eelab_2erules_2edelayedCheck_lam1(V self, V *args);
V g_heff_2eelab_2erules_2edelayedCheck_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2edelayedCheck_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2edelayedCheck_entry, 7, 0};

V g_heff_2eelab_2erules_2edelayedCheck(V v_e_240, V v_sp_241, V v_what_242, V v_c_243, V v_ty_244, V v_m_245, V v_hole_246) {
top: ;
  V v_c_248;
  switch (heff_tag_of(v_c_243)) {
  case TAG_MkChk: {
    V v_f_247 = heff_field(v_c_243, 0);
    v_c_248 = heff_tr(heff_call(heff_dup(v_f_247), 2, (V[]){heff_dup(v_e_240), v_ty_244}));
    break;
  }
  default: heff_nomatch(v_c_243);
  }
  return heff_clo_n(g_heff_2eelab_2erules_2edelayedCheck_lam0, 2, 6, (V[]){v_c_248, v_e_240, v_m_245, v_hole_246, v_what_242, v_sp_241});
}
V g_heff_2eelab_2erules_2edelayedCheck_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2eelab_2erules_2edelayedCheck(a[0], a[1], a[2], a3, a[4], a[5], a[6]); heff_drop(a3); return r;
}
V g_heff_2eelab_2erules_2edelayedCheck_lam2(V self, V *args) {
  V v_x_2422 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_what_242 = heff_env(self)[1];
  V v_sp_241 = heff_env(self)[2];
  V v_hd_249 = heff_env(self)[3];
  V v_k_2410 = heff_env(self)[4];
  switch (heff_tag_of(v_x_2422)) {
  case TAG_Left: {
    V v_err_2423 = heff_field(v_x_2422, 0);
    V v_ru_24x_2422_24Left = heff_take_reuse_n(v_x_2422, 1ULL, 1);
    heff_clo_take(self, 5);
    V v_note_2424 = ({ V a_0 = heff_get_n(v_e_240, 1, 8); V a_1 = v_err_2423; V r_ = (g_heff_2eelab_2erules_2eprettyEqErr(a_0, a_1)); heff_drop(v_err_2423); r_; });
    V v_t_2425 = heff_strAppend(heff_strAppend(((V)&g_heff_2eelab_2erules_2edelayedCheck_str0), v_what_242), ((V)&g_heff_2eelab_2erules_2edelayedCheck_str1));
    V v_t_2426 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(311LL), NTAG(TAG_SError), v_t_2425, v_sp_241, heff_tag_n(TAG_Just, 1, (V[]){v_note_2424})});
    V v_t_2427 = heff_tag_at_n(v_ru_24x_2422_24Left, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2426})});
    V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
    V v_t_2429 = heff_tr(heff_call(heff_take_field(v_hd_249, 2), 1, (V[]){v_t_2428}));
    V f_ = heff_get_n(v_hd_249, 1, 3);
    heff_room[0] = v_t_2429;
    heff_room[1] = v_k_2410;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_Right: {
    heff_take_n(v_x_2422, 0ULL, 1);
    heff_clo_take(self, 5);
    heff_drop_rec(v_e_240, 8);
    heff_drop(v_what_242);
    heff_drop(v_sp_241);
    heff_drop_rec(v_hd_249, 3);
    V f_ = v_k_2410;
    args[0] = NTAG(TAG_MkUnit);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_2422);
  }
}
V g_heff_2eelab_2erules_2edelayedCheck_lam1(V self, V *args) {
  V v_x_2411 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_m_245 = heff_env(self)[1];
  V v_hole_246 = heff_env(self)[2];
  V v_hd_249 = heff_env(self)[3];
  V v_what_242 = heff_env(self)[4];
  V v_sp_241 = heff_env(self)[5];
  V v_k_2410 = heff_env(self)[6];
  V v_val_2412 = heff_take_field(v_x_2411, 1);
  V v_stx_2413 = heff_get_n(v_x_2411, 0, 2);
  V v_x1_2414 = heff_tr(heff_call(v_val_2412, 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_t_2418;
  switch (heff_tag_of(v_x1_2414)) {
  case TAG_Nom: {
    V v_x_2415 = heff_field(v_x1_2414, 0);
    heff_take_n(v_x1_2414, 1ULL, 1);
    v_t_2418 = v_x_2415;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2414, 0ULL, 1);
    v_t_2418 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2417 = heff_field(v_x1_2414, 0);
    heff_take_n(v_x1_2414, 1ULL, 1);
    v_t_2418 = v_x_2417;
    break;
  }
  default: heff_nomatch(v_x1_2414);
  }
  V v_c_2419 = heff_dup(heff_rfield(v_e_240, 0));
  V v_len_2420 = heff_take_field(v_c_2419, 0);
  V v_names_2421 = heff_get_n(v_c_2419, 1, 5);
  heff_clo_take(self, 7);
  return (g_heff_2eelab_2erules_2esolveHole(heff_dup(heff_rfield(v_e_240, 1)), heff_rec_n(2, shape_len__names, (V[]){v_len_2420, v_names_2421}), v_m_245, heff_get_n(v_hole_246, 1, 2), v_stx_2413, v_t_2418, heff_dup(v_hd_249), heff_clo_n(g_heff_2eelab_2erules_2edelayedCheck_lam2, 1, 5, (V[]){v_e_240, v_what_242, v_sp_241, v_hd_249, v_k_2410})));
}
V g_heff_2eelab_2erules_2edelayedCheck_lam0(V self, V *args) {
  V v_hd_249 = args[0];
  V v_k_2410 = args[1];
  V v_c_248 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_m_245 = heff_env(self)[2];
  V v_hole_246 = heff_env(self)[3];
  V v_what_242 = heff_env(self)[4];
  V v_sp_241 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V f_ = v_c_248;
  args[0] = heff_dup(v_hd_249);
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2edelayedCheck_lam1, 1, 7, (V[]){v_e_240, v_m_245, v_hole_246, v_hd_249, v_what_242, v_sp_241, v_k_2410});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_str0, 57, "tried to check a lambda expression at a non-function type");
HEFF_LIT(g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_str1, 62, "the binder's annotation is not the argument type expected here");
HEFF_LIT(g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_str2, 1, "_");
HEFF_LIT(g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_str3, 1, "_");
HEFF_LIT(g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_str4, 1, "_");
HEFF_LIT(g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_str5, 57, "tried to check a lambda expression at a non-function type");
HEFF_LIT(g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_str6, 57, "tried to check a lambda expression at a non-function type");
HEFF_LIT(g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_str7, 57, "tried to check a lambda expression at a non-function type");
HEFF_LIT(g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_str8, 57, "tried to check a lambda expression at a non-function type");
HEFF_LIT(g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_str9, 57, "tried to check a lambda expression at a non-function type");
HEFF_LIT(g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_str10, 57, "tried to check a lambda expression at a non-function type");
HEFF_LIT(g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_str11, 57, "tried to check a lambda expression at a non-function type");
HEFF_LIT(g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_str12, 57, "tried to check a lambda expression at a non-function type");
HEFF_LIT(g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_str13, 57, "tried to check a lambda expression at a non-function type");
V g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_lam1(V self, V *args);
V g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_lam4(V self, V *args);
V g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_lam6(V self, V *args);
V g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_lam7(V self, V *args); static Clo g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_lam7, 2, 0};
V g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_lam10(V self, V *args);
V g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_lam12(V self, V *args);
V g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_lam11(V self, V *args);
V g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_lam9(V self, V *args);
V g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_lam8(V self, V *args);
V g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_lam5(V self, V *args);
V g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_lam3(V self, V *args);
V g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_lam14(V self, V *args);
V g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_lam17(V self, V *args);
V g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_lam16(V self, V *args);
V g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_lam15(V self, V *args);
V g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_lam13(V self, V *args);
V g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_lam2(V self, V *args);
V g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_lam0(V self, V *args);

HeffT1 g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr(V v_sp_240, V v_x_241, V v_dom_242, V v_body_243) {
top: ;
  return ((HeffT1){{heff_clo_n(g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_lam0, 4, 4, (V[]){v_sp_240, heff_dup(v_dom_242), v_x_241, heff_dup(v_body_243)})}});
}
V g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_lam1(V self, V *args) {
  V v_c_248 = args[0];
  V v_a0_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_c_248, 3, 9); V a_1 = v_a0_245; V r_ = (g_heff_2eelab_2evalue_2eforceTy(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_lam4(V self, V *args) {
  V v_p_2436 = args[0];
  V v_p_2437 = args[1];
  V v_g_2427 = heff_env(self)[0];
  V v_len_2429 = heff_env(self)[1];
  V v_names_2430 = heff_env(self)[2];
  V v_fdom_2420 = heff_env(self)[3];
  V v_b_2435 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2438 = heff_tr(heff_call(((V)&g_heff_2eelab_2eunify_2euTypeF_24s584682120x2121508022_clo), 4, (V[]){v_g_2427, heff_rec_n(2, shape_len__names, (V[]){v_len_2429, v_names_2430}), v_fdom_2420, v_b_2435}));
  return (g_heff_2eelab_2emeta_2eliftU(v_t_2438, v_p_2436, v_p_2437));
}
V g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_lam6(V self, V *args) {
  V v_hd_2447 = args[0];
  V v_k2_2448 = args[1];
  V v_sp_2443 = heff_env(self)[0];
  V v_note_2446 = heff_env(self)[1];
  V v_malg_2449 = heff_take_field(v_hd_2447, 2);
  V v_bind_2450 = heff_get_n(v_hd_2447, 1, 3);
  heff_clo_take(self, 2);
  V v_t_2451 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(311LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_str1), v_sp_2443, heff_tag_n(TAG_Just, 1, (V[]){v_note_2446})});
  V v_t_2452 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2451})});
  V v_t_2453 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2452})});
  V v_t_2454 = heff_tr(heff_call(v_malg_2449, 1, (V[]){v_t_2453}));
  V f_ = v_bind_2450;
  args[0] = v_t_2454;
  args[1] = v_k2_2448;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_lam7(V self, V *args) {
  V v_hd_2456 = args[0];
  V v_k_2457 = args[1];
  heff_drop(v_hd_2456);
  V f_ = v_k_2457;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_lam10(V self, V *args) {
  V v_u_2472 = args[0];
  V v_v_2465 = heff_env(self)[0];
  heff_drop(v_u_2472);
  heff_clo_take(self, 1);
  return v_v_2465;
}
V g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_lam12(V self, V *args) {
  V v_u_2495 = args[0];
  V v_x_2412 = heff_env(self)[0];
  heff_drop(v_u_2495);
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_Nom, 1, (V[]){v_x_2412});
}
V g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_lam11(V self, V *args) {
  V v_x_2487 = args[0];
  V v_e_244 = heff_env(self)[0];
  V v_x_2412 = heff_env(self)[1];
  V v_x_241 = heff_env(self)[2];
  V v_z_2468 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2488 = heff_take_field(v_e_244, 2);
  V v_t_2491;
  switch (heff_tag_of(v_t_2488)) {
  case TAG_ForNominative: {
    v_t_2491 = NTAG(TAG_N);
    break;
  }
  case TAG_ForDescriptive: {
    heff_take_n(v_t_2488, 0ULL, 2);
    v_t_2491 = NTAG(TAG_De);
    break;
  }
  default: heff_nomatch(v_t_2488);
  }
  V v_t_2492 = heff_get_n(heff_dup(heff_rfield(v_e_244, 0)), 0, 5);
  V v_t_2493 = (g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(v_t_2492, heff_dup(v_x_2412)));
  V v_t_2494 = heff_get_n(heff_dup(heff_rfield(v_e_244, 0)), 2, 5);
  V v_x_2496 = ({ V a_0 = v_x_241; V a_1 = v_x_2487; V a_2 = v_t_2491; V b_3 = heff_get_n(v_e_244, 1, 8); V a_4 = v_t_2494; V a_5 = heff_rec_n(2, shape_stx__val, (V[]){v_t_2493, heff_clo_n(g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_lam12, 1, 1, (V[]){v_x_2412})}); V r_ = (g_heff_2eelab_2ememoed_2elam_24s656135179x1177830782(a_0, a_1, a_2, b_3, a_4, a_5)); heff_drop(v_t_2491); heff_drop(b_3); r_; });
  V f_ = v_z_2468;
  args[0] = v_x_2496;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_lam9(V self, V *args) {
  V v_v_2465 = args[0];
  V v_scope_27_2466 = args[1];
  V v_z_2467 = args[2];
  V v_z_2468 = args[3];
  V v_cod_2421 = heff_env(self)[0];
  V v_body_243 = heff_env(self)[1];
  V v_e_244 = heff_env(self)[2];
  V v_x_2412 = heff_env(self)[3];
  V v_x_241 = heff_env(self)[4];
  V v_x1_2474;
  heff_clo_take(self, 5);
  switch (heff_tag_of(v_cod_2421)) {
  case TAG_MkClo: {
    V v_vs_2470 = heff_field(v_cod_2421, 1);
    V v_body_2471 = heff_field(v_cod_2421, 2);
    heff_take_n(v_cod_2421, 6ULL, 3);
    v_x1_2474 = heff_tr(heff_call(v_body_2471, 1, (V[]){heff_tag_n(TAG_LSnoc, 2, (V[]){v_vs_2470, heff_clo_n(g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_lam10, 1, 1, (V[]){heff_dup(v_v_2465)})})}));
    break;
  }
  case TAG_CloConst: {
    V v_body_2473 = heff_field(v_cod_2421, 0);
    heff_take_n(v_cod_2421, 1ULL, 1);
    v_x1_2474 = v_body_2473;
    break;
  }
  default: heff_nomatch(v_cod_2421);
  }
  V v_a_2478;
  switch (heff_tag_of(v_x1_2474)) {
  case TAG_Nom: {
    V v_x_2475 = heff_field(v_x1_2474, 0);
    heff_take_n(v_x1_2474, 1ULL, 1);
    v_a_2478 = v_x_2475;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2474, 0ULL, 1);
    v_a_2478 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2477 = heff_field(v_x1_2474, 0);
    heff_take_n(v_x1_2474, 1ULL, 1);
    v_a_2478 = v_x_2477;
    break;
  }
  default: heff_nomatch(v_x1_2474);
  }
  V v_c_2486;
  switch (heff_tag_of(v_body_243)) {
  case TAG_MkChk: {
    V v_f_2479 = heff_field(v_body_243, 0);
    heff_take_n(v_body_243, 1ULL, 1);
    V v_t_2480 = heff_dup(heff_rfield(v_e_244, 2));
    V v_t_2483;
    switch (heff_tag_of(v_t_2480)) {
    case TAG_ForNominative: {
      heff_drop(v_v_2465);
      v_t_2483 = NTAG(TAG_ForNominative);
      break;
    }
    case TAG_ForDescriptive: {
      V v_h_2481 = heff_field(v_t_2480, 0);
      V v_sp_2482 = heff_field(v_t_2480, 1);
      V v_ru_24t_2480_24ForDescriptive = heff_take_reuse_n(v_t_2480, 3ULL, 2);
      v_t_2483 = heff_tag_re_n(v_ru_24t_2480_24ForDescriptive, TAG_ForDescriptive, 2, 1ULL, (V[]){v_h_2481, heff_tag_n(TAG_SpApp, 2, (V[]){v_sp_2482, v_v_2465})});
      break;
    }
    default: heff_nomatch(v_t_2480);
    }
    V v_t_2484 = heff_intAdd(heff_dup(heff_rfield(v_e_244, 3)), MK_INT(1LL));
    V v_t_2485 = heff_rec_n(8, shape_scope__globals__elabFor__lams__self__insts__named__evidence, (V[]){v_scope_27_2466, heff_dup(heff_rfield(v_e_244, 1)), v_t_2483, v_t_2484, heff_dup(heff_rfield(v_e_244, 4)), heff_dup(heff_rfield(v_e_244, 5)), heff_dup(heff_rfield(v_e_244, 6)), heff_dup(heff_rfield(v_e_244, 7))});
    v_c_2486 = heff_tr(heff_call(v_f_2479, 2, (V[]){v_t_2485, v_a_2478}));
    break;
  }
  default: heff_nomatch(v_body_243);
  }
  V f_ = v_c_2486;
  args[0] = v_z_2467;
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_lam11, 1, 4, (V[]){v_e_244, v_x_2412, v_x_241, v_z_2468});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_lam8(V self, V *args) {
  V v_x_2459 = args[0];
  V v_x_2426 = heff_env(self)[0];
  V v_x_241 = heff_env(self)[1];
  V v_e_244 = heff_env(self)[2];
  V v_cod_2421 = heff_env(self)[3];
  V v_body_243 = heff_env(self)[4];
  V v_x_2412 = heff_env(self)[5];
  V v_z_2440 = heff_env(self)[6];
  V v_z_2441 = heff_env(self)[7];
  heff_drop(v_x_2459);
  heff_clo_take(self, 8);
  V v_x1_2460 = heff_tr(heff_call(heff_get_n(v_x_2426, 1, 2), 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_t_2464;
  switch (heff_tag_of(v_x1_2460)) {
  case TAG_Nom: {
    V v_x_2461 = heff_field(v_x1_2460, 0);
    heff_take_n(v_x1_2460, 1ULL, 1);
    v_t_2464 = v_x_2461;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2460, 0ULL, 1);
    v_t_2464 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2463 = heff_field(v_x1_2460, 0);
    heff_take_n(v_x1_2460, 1ULL, 1);
    v_t_2464 = v_x_2463;
    break;
  }
  default: heff_nomatch(v_x1_2460);
  }
  return (g_heff_2eelab_2eenvironment_2ewithBound(heff_dup(v_x_241), v_t_2464, heff_dup(heff_rfield(v_e_244, 0)), heff_clo_n(g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_lam9, 4, 5, (V[]){v_cod_2421, v_body_243, v_e_244, v_x_2412, v_x_241}), v_z_2440, v_z_2441));
}
V g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_lam5(V self, V *args) {
  V v_agree_2439 = args[0];
  V v_z_2440 = args[1];
  V v_z_2441 = args[2];
  V v_e_244 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  V v_x_2426 = heff_env(self)[2];
  V v_x_241 = heff_env(self)[3];
  V v_cod_2421 = heff_env(self)[4];
  V v_body_243 = heff_env(self)[5];
  V v_x_2412 = heff_env(self)[6];
  V v_e_2442 = heff_dup(v_e_244);
  heff_clo_take(self, 7);
  V v_sp_2443 = v_sp_240;
  V v_x3_2444 = v_agree_2439;
  V v_c_2458;
  switch (heff_tag_of(v_x3_2444)) {
  case TAG_Left: {
    V v_err_2445 = heff_field(v_x3_2444, 0);
    heff_take_n(v_x3_2444, 1ULL, 1);
    V v_note_2446 = ({ V a_0 = heff_get_n(v_e_2442, 1, 8); V a_1 = v_err_2445; V r_ = (g_heff_2eelab_2erules_2eprettyEqErr(a_0, a_1)); heff_drop(v_err_2445); r_; });
    v_c_2458 = heff_clo_n(g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_lam6, 2, 2, (V[]){v_sp_2443, v_note_2446});
    break;
  }
  case TAG_Right: {
    heff_take_n(v_x3_2444, 0ULL, 1);
    heff_drop_rec(v_e_2442, 8);
    heff_drop(v_sp_2443);
    v_c_2458 = ((V)&g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_lam7_clo);
    break;
  }
  default: heff_nomatch(v_x3_2444);
  }
  V f_ = v_c_2458;
  args[0] = heff_dup(v_z_2440);
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_lam8, 1, 8, (V[]){v_x_2426, v_x_241, v_e_244, v_cod_2421, v_body_243, v_x_2412, v_z_2440, v_z_2441});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_lam3(V self, V *args) {
  V v_x_2426 = args[0];
  V v_e_244 = heff_env(self)[0];
  V v_fdom_2420 = heff_env(self)[1];
  V v_sp_240 = heff_env(self)[2];
  V v_x_241 = heff_env(self)[3];
  V v_cod_2421 = heff_env(self)[4];
  V v_body_243 = heff_env(self)[5];
  V v_x_2412 = heff_env(self)[6];
  V v_hd_246 = heff_env(self)[7];
  V v_k_247 = heff_env(self)[8];
  V v_g_2427 = heff_dup(heff_rfield(v_e_244, 1));
  V v_c_2428 = heff_dup(heff_rfield(v_e_244, 0));
  V v_len_2429 = heff_take_field(v_c_2428, 0);
  V v_names_2430 = heff_get_n(v_c_2428, 1, 5);
  V v_x1_2431 = heff_tr(heff_call(heff_dup(heff_rfield(v_x_2426, 1)), 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_b_2435;
  switch (heff_tag_of(v_x1_2431)) {
  case TAG_Nom: {
    V v_x_2432 = heff_field(v_x1_2431, 0);
    heff_take_n(v_x1_2431, 1ULL, 1);
    v_b_2435 = v_x_2432;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2431, 0ULL, 1);
    v_b_2435 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2434 = heff_field(v_x1_2431, 0);
    heff_take_n(v_x1_2431, 1ULL, 1);
    v_b_2435 = v_x_2434;
    break;
  }
  default: heff_nomatch(v_x1_2431);
  }
  heff_clo_take(self, 9);
  return (g_co_2ebind_24s1421083649x484987773(heff_clo_n(g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_lam4, 2, 5, (V[]){v_g_2427, v_len_2429, v_names_2430, v_fdom_2420, v_b_2435}), heff_clo_n(g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_lam5, 3, 7, (V[]){v_e_244, v_sp_240, v_x_2426, v_x_241, v_cod_2421, v_body_243, v_x_2412}), v_hd_246, v_k_247));
}
V g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_lam14(V self, V *args) {
  V v_u_24116 = args[0];
  V v_v_24103 = heff_env(self)[0];
  heff_drop(v_u_24116);
  heff_clo_take(self, 1);
  return v_v_24103;
}
V g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_lam17(V self, V *args) {
  V v_u_24140 = args[0];
  V v_x_2412 = heff_env(self)[0];
  heff_drop(v_u_24140);
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_Nom, 1, (V[]){v_x_2412});
}
V g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_lam16(V self, V *args) {
  V v_x_24127 = args[0];
  V v_e_244 = heff_env(self)[0];
  V v_x_2412 = heff_env(self)[1];
  V v_cod_2421 = heff_env(self)[2];
  V v_k_24126 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_24128 = heff_take_field(v_e_244, 2);
  V v_t_24131;
  switch (heff_tag_of(v_t_24128)) {
  case TAG_ForNominative: {
    v_t_24131 = NTAG(TAG_N);
    break;
  }
  case TAG_ForDescriptive: {
    heff_take_n(v_t_24128, 0ULL, 2);
    v_t_24131 = NTAG(TAG_De);
    break;
  }
  default: heff_nomatch(v_t_24128);
  }
  V v_t_24132 = heff_get_n(heff_dup(heff_rfield(v_e_244, 0)), 0, 5);
  V v_t_24133 = (g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(v_t_24132, heff_dup(v_x_2412)));
  V v_t_24138;
  switch (heff_tag_of(v_cod_2421)) {
  case TAG_MkClo: {
    V v_n_24134 = heff_field(v_cod_2421, 0);
    heff_take_n(v_cod_2421, 1ULL, 3);
    v_t_24138 = v_n_24134;
    break;
  }
  case TAG_CloConst: {
    heff_take_n(v_cod_2421, 0ULL, 1);
    v_t_24138 = ((V)&g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_str4);
    break;
  }
  default: heff_nomatch(v_cod_2421);
  }
  V v_t_24139 = heff_get_n(heff_dup(heff_rfield(v_e_244, 0)), 2, 5);
  V v_x_24141 = ({ V a_0 = v_t_24131; V b_1 = heff_get_n(v_e_244, 1, 8); V a_2 = v_t_24139; V a_3 = heff_rec_n(2, shape_stx__val, (V[]){v_t_24133, heff_clo_n(g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_lam17, 1, 1, (V[]){v_x_2412})}); V a_4 = heff_tag_n(TAG_MkAbs, 2, (V[]){v_t_24138, v_x_24127}); V r_ = (g_heff_2eelab_2ememoed_2elam(a_0, b_1, a_2, a_3, a_4)); heff_drop(v_t_24131); heff_drop(b_1); r_; });
  V f_ = v_k_24126;
  args[0] = v_x_24141;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_lam15(V self, V *args) {
  V v_hd_24125 = args[0];
  V v_k_24126 = args[1];
  V v_c_24124 = heff_env(self)[0];
  V v_e_244 = heff_env(self)[1];
  V v_x_2412 = heff_env(self)[2];
  V v_cod_2421 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_24124;
  args[0] = v_hd_24125;
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_lam16, 1, 4, (V[]){v_e_244, v_x_2412, v_cod_2421, v_k_24126});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_lam13(V self, V *args) {
  V v_v_24103 = args[0];
  V v_scope_27_24104 = args[1];
  V v_sp_240 = heff_env(self)[0];
  V v_x_241 = heff_env(self)[1];
  V v_dom_242 = heff_env(self)[2];
  V v_body_243 = heff_env(self)[3];
  V v_cod_2421 = heff_env(self)[4];
  V v_e_244 = heff_env(self)[5];
  V v_implicit_2422 = heff_env(self)[6];
  V v_fdom_2420 = heff_env(self)[7];
  V v_x_2412 = heff_env(self)[8];
  heff_clo_take(self, 9);
  HeffT1 v_t_24105 = ({ V a_0 = v_sp_240; V a_1 = v_x_241; V a_2 = v_dom_242; V a_3 = v_body_243; HeffT1 r_ = (g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_dom_242); heff_drop(v_body_243); r_; });
  {
    V v_field_24106 = v_t_24105.f[0];
    V v_t_24111;
    switch (heff_tag_of(v_cod_2421)) {
    case TAG_MkClo: {
      V v_n_24107 = heff_dup(heff_field(v_cod_2421, 0));
      v_t_24111 = v_n_24107;
      break;
    }
    case TAG_CloConst: {
      v_t_24111 = ((V)&g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_str3);
      break;
    }
    default: heff_nomatch(v_cod_2421);
    }
    V v_e_24112 = ({ V a_0 = heff_dup(v_e_244); V a_1 = v_implicit_2422; V a_2 = v_t_24111; V a_3 = v_fdom_2420; V a_4 = v_scope_27_24104; V a_5 = heff_dup(v_v_24103); V a_6 = NTAG(TAG_True); V r_ = (g_heff_2eelab_2erules_2eintoSilent(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_implicit_2422); r_; });
    V v_x1_24118;
    switch (heff_tag_of(v_cod_2421)) {
    case TAG_MkClo: {
      V v_vs_24114 = heff_dup(heff_field(v_cod_2421, 1));
      V v_body_24115 = heff_dup(heff_field(v_cod_2421, 2));
      v_x1_24118 = heff_tr(heff_call(v_body_24115, 1, (V[]){heff_tag_n(TAG_LSnoc, 2, (V[]){v_vs_24114, heff_clo_n(g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_lam14, 1, 1, (V[]){v_v_24103})})}));
      break;
    }
    case TAG_CloConst: {
      V v_body_24117 = heff_dup(heff_field(v_cod_2421, 0));
      heff_drop(v_v_24103);
      v_x1_24118 = v_body_24117;
      break;
    }
    default: heff_nomatch(v_cod_2421);
    }
    V v_a_24122;
    switch (heff_tag_of(v_x1_24118)) {
    case TAG_Nom: {
      V v_x_24119 = heff_field(v_x1_24118, 0);
      heff_take_n(v_x1_24118, 1ULL, 1);
      v_a_24122 = v_x_24119;
      break;
    }
    case TAG_Describe: {
      heff_take_n(v_x1_24118, 0ULL, 1);
      v_a_24122 = heff_abandon();
      break;
    }
    case TAG_Become: {
      V v_x_24121 = heff_field(v_x1_24118, 0);
      heff_take_n(v_x1_24118, 1ULL, 1);
      v_a_24122 = v_x_24121;
      break;
    }
    default: heff_nomatch(v_x1_24118);
    }
    V v_f_24123 = v_field_24106;
    V v_c_24124 = heff_tr(heff_call(v_f_24123, 2, (V[]){v_e_24112, v_a_24122}));
    return heff_clo_n(g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_lam15, 2, 4, (V[]){v_c_24124, v_e_244, v_x_2412, v_cod_2421});
  }
}
V g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_lam2(V self, V *args) {
  V v_x_2412 = args[0];
  V v_sp_240 = heff_env(self)[0];
  V v_hd_246 = heff_env(self)[1];
  V v_k_247 = heff_env(self)[2];
  V v_dom_242 = heff_env(self)[3];
  V v_e_244 = heff_env(self)[4];
  V v_x_241 = heff_env(self)[5];
  V v_body_243 = heff_env(self)[6];
  V v_t_2413 = (g_heff_2eelab_2evalue_2ebehavior(heff_dup(v_x_2412)));
  switch (heff_tag_of(v_t_2413)) {
  case TAG_LikeU: {
    V v_ru_24t_2413_24LikeU = heff_take_reuse_n(v_t_2413, 0ULL, 1);
    heff_drop(v_x_2412);
    heff_clo_take(self, 7);
    heff_drop(v_dom_242);
    heff_drop_rec(v_e_244, 8);
    heff_drop(v_x_241);
    heff_drop(v_body_243);
    V v_t_2415 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(301LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_str0), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2416 = heff_tag_at_n(v_ru_24t_2413_24LikeU, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2415})});
    V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
    V v_t_2418 = heff_tr(heff_call(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_2417}));
    V f_ = heff_get_n(v_hd_246, 1, 3);
    heff_room[0] = v_t_2418;
    heff_room[1] = v_k_247;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_LikeFunction: {
    V v_fdom_2420 = heff_field(v_t_2413, 1);
    V v_cod_2421 = heff_field(v_t_2413, 2);
    V v_implicit_2422 = heff_field(v_t_2413, 3);
    heff_take_n(v_t_2413, 14ULL, 4);
    V v_t_2423;
    switch (heff_tag_of(v_implicit_2422)) {
    case TAG_Expl: {
      v_t_2423 = NTAG(TAG_True);
      break;
    }
    case TAG_Impl: {
      v_t_2423 = NTAG(TAG_False);
      break;
    }
    case TAG_Inst: {
      v_t_2423 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_implicit_2422);
    }
    if ((heff_dup(v_t_2423) == NTAG(TAG_True))) {
      heff_drop(v_implicit_2422);
      heff_drop(v_t_2423);
      V v_c_2425;
      heff_clo_take(self, 7);
      switch (heff_tag_of(v_dom_242)) {
      case TAG_MkTyp: {
        V v_f_2424 = heff_field(v_dom_242, 0);
        heff_take_n(v_dom_242, 1ULL, 1);
        v_c_2425 = heff_tr(heff_call(v_f_2424, 1, (V[]){heff_dup(v_e_244)}));
        break;
      }
      default: heff_nomatch(v_dom_242);
      }
      V f_ = v_c_2425;
      heff_room[0] = heff_dup(v_hd_246);
      heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_lam3, 1, 9, (V[]){v_e_244, v_fdom_2420, v_sp_240, v_x_241, v_cod_2421, v_body_243, v_x_2412, v_hd_246, v_k_247});
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    } else {
      heff_drop(v_t_2423);
      V v_x_24101;
      switch (heff_tag_of(v_cod_2421)) {
      case TAG_MkClo: {
        V v_n_2497 = heff_dup(heff_field(v_cod_2421, 0));
        v_x_24101 = v_n_2497;
        break;
      }
      case TAG_CloConst: {
        v_x_24101 = ((V)&g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_str2);
        break;
      }
      default: heff_nomatch(v_cod_2421);
      }
      V v_c_24102 = heff_dup(heff_rfield(v_e_244, 0));
      heff_clo_take(self, 7);
      V v_action_24142 = heff_clo_n(g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_lam13, 2, 9, (V[]){v_sp_240, v_x_241, v_dom_242, v_body_243, v_cod_2421, heff_dup(v_e_244), v_implicit_2422, heff_dup(v_fdom_2420), v_x_2412});
      V v_t_24143 = heff_get_n(v_e_244, 6, 8);
      if ((heff_dup(v_t_24143) == NTAG(TAG_True))) {
        heff_drop(v_t_24143);
        return (g_heff_2eelab_2eenvironment_2ewithBound(v_x_24101, v_fdom_2420, v_c_24102, v_action_24142, v_hd_246, v_k_247));
      } else {
        heff_drop(v_t_24143);
        return (g_heff_2eelab_2eenvironment_2ewithInserted(v_x_24101, v_fdom_2420, v_c_24102, v_action_24142, v_hd_246, v_k_247));
      }
    }
  }
  case TAG_LikeRecord: {
    heff_take_n(v_t_2413, 0ULL, 3);
    heff_drop(v_x_2412);
    heff_clo_take(self, 7);
    heff_drop(v_dom_242);
    heff_drop_rec(v_e_244, 8);
    heff_drop(v_x_241);
    heff_drop(v_body_243);
    V v_t_24147 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(301LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_str5), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_24148 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24147})});
    V v_t_24149 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24148})});
    V v_t_24150 = heff_tr(heff_call(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_24149}));
    V f_ = heff_get_n(v_hd_246, 1, 3);
    heff_room[0] = v_t_24150;
    heff_room[1] = v_k_247;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_LikeSum: {
    V v_ru_24t_2413_24LikeSum = heff_take_reuse_n(v_t_2413, 0ULL, 1);
    heff_drop(v_x_2412);
    heff_clo_take(self, 7);
    heff_drop(v_dom_242);
    heff_drop_rec(v_e_244, 8);
    heff_drop(v_x_241);
    heff_drop(v_body_243);
    V v_t_24152 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(301LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_str6), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_24153 = heff_tag_at_n(v_ru_24t_2413_24LikeSum, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24152})});
    V v_t_24154 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24153})});
    V v_t_24155 = heff_tr(heff_call(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_24154}));
    V f_ = heff_get_n(v_hd_246, 1, 3);
    heff_room[0] = v_t_24155;
    heff_room[1] = v_k_247;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_LikeInt: {
    heff_drop(v_x_2412);
    heff_clo_take(self, 7);
    heff_drop(v_dom_242);
    heff_drop_rec(v_e_244, 8);
    heff_drop(v_x_241);
    heff_drop(v_body_243);
    V v_t_24156 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(301LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_str7), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_24157 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24156})});
    V v_t_24158 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24157})});
    V v_t_24159 = heff_tr(heff_call(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_24158}));
    V f_ = heff_get_n(v_hd_246, 1, 3);
    heff_room[0] = v_t_24159;
    heff_room[1] = v_k_247;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_LikeFloat: {
    heff_drop(v_x_2412);
    heff_clo_take(self, 7);
    heff_drop(v_dom_242);
    heff_drop_rec(v_e_244, 8);
    heff_drop(v_x_241);
    heff_drop(v_body_243);
    V v_t_24160 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(301LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_str8), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_24161 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24160})});
    V v_t_24162 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24161})});
    V v_t_24163 = heff_tr(heff_call(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_24162}));
    V f_ = heff_get_n(v_hd_246, 1, 3);
    heff_room[0] = v_t_24163;
    heff_room[1] = v_k_247;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_LikeString: {
    heff_drop(v_x_2412);
    heff_clo_take(self, 7);
    heff_drop(v_dom_242);
    heff_drop_rec(v_e_244, 8);
    heff_drop(v_x_241);
    heff_drop(v_body_243);
    V v_t_24164 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(301LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_str9), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_24165 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24164})});
    V v_t_24166 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24165})});
    V v_t_24167 = heff_tr(heff_call(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_24166}));
    V f_ = heff_get_n(v_hd_246, 1, 3);
    heff_room[0] = v_t_24167;
    heff_room[1] = v_k_247;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_LikeRune: {
    heff_drop(v_x_2412);
    heff_clo_take(self, 7);
    heff_drop(v_dom_242);
    heff_drop_rec(v_e_244, 8);
    heff_drop(v_x_241);
    heff_drop(v_body_243);
    V v_t_24168 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(301LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_str10), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_24169 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24168})});
    V v_t_24170 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24169})});
    V v_t_24171 = heff_tr(heff_call(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_24170}));
    V f_ = heff_get_n(v_hd_246, 1, 3);
    heff_room[0] = v_t_24171;
    heff_room[1] = v_k_247;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_LikeArray: {
    V v_ru_24t_2413_24LikeArray = heff_take_reuse_n(v_t_2413, 0ULL, 1);
    heff_drop(v_x_2412);
    heff_clo_take(self, 7);
    heff_drop(v_dom_242);
    heff_drop_rec(v_e_244, 8);
    heff_drop(v_x_241);
    heff_drop(v_body_243);
    V v_t_24173 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(301LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_str11), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_24174 = heff_tag_at_n(v_ru_24t_2413_24LikeArray, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24173})});
    V v_t_24175 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24174})});
    V v_t_24176 = heff_tr(heff_call(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_24175}));
    V f_ = heff_get_n(v_hd_246, 1, 3);
    heff_room[0] = v_t_24176;
    heff_room[1] = v_k_247;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_LikeFixed: {
    V v_ru_24t_2413_24LikeFixed = heff_take_reuse_n(v_t_2413, 0ULL, 1);
    heff_drop(v_x_2412);
    heff_clo_take(self, 7);
    heff_drop(v_dom_242);
    heff_drop_rec(v_e_244, 8);
    heff_drop(v_x_241);
    heff_drop(v_body_243);
    V v_t_24178 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(301LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_str12), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_24179 = heff_tag_at_n(v_ru_24t_2413_24LikeFixed, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24178})});
    V v_t_24180 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24179})});
    V v_t_24181 = heff_tr(heff_call(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_24180}));
    V f_ = heff_get_n(v_hd_246, 1, 3);
    heff_room[0] = v_t_24181;
    heff_room[1] = v_k_247;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_NoRules: {
    heff_drop(v_x_2412);
    heff_clo_take(self, 7);
    heff_drop(v_dom_242);
    heff_drop_rec(v_e_244, 8);
    heff_drop(v_x_241);
    heff_drop(v_body_243);
    V v_t_24182 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(301LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_str13), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_24183 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24182})});
    V v_t_24184 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24183})});
    V v_t_24185 = heff_tr(heff_call(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_24184}));
    V f_ = heff_get_n(v_hd_246, 1, 3);
    heff_room[0] = v_t_24185;
    heff_room[1] = v_k_247;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_t_2413);
  }
}
V g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_lam0(V self, V *args) {
  V v_e_244 = args[0];
  V v_a0_245 = args[1];
  V v_hd_246 = args[2];
  V v_k_247 = args[3];
  V v_sp_240 = heff_env(self)[0];
  V v_dom_242 = heff_env(self)[1];
  V v_x_241 = heff_env(self)[2];
  V v_body_243 = heff_env(self)[3];
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_lam1, 1, 1, (V[]){v_a0_245})})});
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_246, 2)), 1, (V[]){v_t_2410}));
  heff_clo_take(self, 4);
  V f_ = heff_dup(heff_rfield(v_hd_246, 1));
  args[0] = v_t_2411;
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_lam2, 1, 7, (V[]){v_sp_240, v_hd_246, v_k_247, v_dom_242, v_e_244, v_x_241, v_body_243});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2eelab_2erules_2eevidenceFound_str0, 31, "the world `_` finds evidence in");
HEFF_LIT(g_heff_2eelab_2erules_2eevidenceFound_str1, 53, "the world an instance argument's evidence is found in");
HEFF_LIT(g_heff_2eelab_2erules_2eevidenceFound_str2, 25, " is not determined here: ");
HEFF_LIT(g_heff_2eelab_2erules_2eevidenceFound_str3, 85, "annotate where the world is said, as `main : Co (a <+> b) Unit`, or give the argument");
HEFF_LIT(g_heff_2eelab_2erules_2eevidenceFound_str4, 6, "\\p -> ");
HEFF_LIT(g_heff_2eelab_2erules_2eevidenceFound_str5, 40, "the effect is in no place of the world: ");
HEFF_LIT(g_heff_2eelab_2erules_2eevidenceFound_str6, 73, "the world has each effect it is given, once: add it, or give the argument");
HEFF_LIT(g_heff_2eelab_2erules_2eevidenceFound_str7, 134, "the world has each effect it is given, once: add it, bind the evidence, `{{x : T}} -> ...`, where this is used, or give it: `(x := e)`");
HEFF_LIT(g_heff_2eelab_2erules_2eevidenceFound_str8, 46, "the evidence found does not fit how it is used");
HEFF_LIT(g_heff_2eelab_2erules_2eevidenceFound_str9, 8, "instance");
HEFF_LIT(g_heff_2eelab_2erules_2eevidenceFound_str10, 6, "found ");
HEFF_LIT(g_heff_2eelab_2erules_2eevidenceFound_str11, 3, " : ");
HEFF_LIT(g_heff_2eelab_2erules_2eevidenceFound_str12, 0, "");
HEFF_LIT(g_heff_2eelab_2erules_2eevidenceFound_str13, 2, ", ");
HEFF_LIT(g_heff_2eelab_2erules_2eevidenceFound_str14, 51, "the effect is in more than one place of the world: ");
HEFF_LIT(g_heff_2eelab_2erules_2eevidenceFound_str15, 2, ": ");
HEFF_LIT(g_heff_2eelab_2erules_2eevidenceFound_str16, 38, "give the argument: the one place meant");
HEFF_LIT(g_heff_2eelab_2erules_2eevidenceFound_str17, 80, "`_` finds evidence that an effect is in a world, `h <: e`, but this argument is ");
HEFF_LIT(g_heff_2eelab_2erules_2eevidenceFound_str18, 17, "give the argument");
V g_heff_2eelab_2erules_2eevidenceFound_lam0(V self, V *args); static Clo g_heff_2eelab_2erules_2eevidenceFound_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eevidenceFound_lam0, 1, 0};
V g_heff_2eelab_2erules_2eevidenceFound_lam2(V self, V *args);
V g_heff_2eelab_2erules_2eevidenceFound_lam4(V self, V *args);
V g_heff_2eelab_2erules_2eevidenceFound_lam8(V self, V *args);
V g_heff_2eelab_2erules_2eevidenceFound_lam9(V self, V *args);
V g_heff_2eelab_2erules_2eevidenceFound_lam7(V self, V *args);
V g_heff_2eelab_2erules_2eevidenceFound_lam6(V self, V *args);
V g_heff_2eelab_2erules_2eevidenceFound_lam5(V self, V *args);
V g_heff_2eelab_2erules_2eevidenceFound_lam3(V self, V *args);
V g_heff_2eelab_2erules_2eevidenceFound_lam1(V self, V *args);
Clo g_heff_2eelab_2erules_2eevidenceFound_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eevidenceFound_entry, 10, 0};

V g_heff_2eelab_2erules_2eevidenceFound(V v_e_240, V v_sp_241, V v_hm_242, V v_holeVal_243, V v_goal_244, V v_cand_245, V v_written_246, V v_final_247, V v_hd_248, V v_k_249) {
top: ;
  V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2erules_2eevidenceFound_lam0_clo)})});
  V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_248, 2)), 1, (V[]){v_t_2412}));
  return heff_tail(heff_dup(heff_rfield(v_hd_248, 1)), 2, (V[]){v_t_2413, heff_clo_n(g_heff_2eelab_2erules_2eevidenceFound_lam1, 1, 10, (V[]){v_e_240, v_goal_244, heff_dup(v_final_247), heff_dup(v_written_246), v_sp_241, v_hd_248, v_k_249, v_cand_245, v_hm_242, v_holeVal_243})});
}
V g_heff_2eelab_2erules_2eevidenceFound_entry(V self, V *a) {
  (void)self;
  V a6 = a[6]; V a7 = a[7]; V r = g_heff_2eelab_2erules_2eevidenceFound(a[0], a[1], a[2], a[3], a[4], a[5], a6, a7, a[8], a[9]); heff_drop(a6); heff_drop(a7); return r;
}
V g_heff_2eelab_2erules_2eevidenceFound_lam0(V self, V *args) {
  V v_c_2410 = args[0];
  return heff_get_n(v_c_2410, 3, 9);
}
V g_heff_2eelab_2erules_2eevidenceFound_lam2(V self, V *args) {
  V v_path_2494 = args[0];
  V v_cand_245 = heff_env(self)[0];
  V v_t_2495 = (g_heff_2eelab_2erules_2epathSaid_2edown_241(NTAG(TAG_Nothing), v_path_2494));
  heff_clo_take(self, 1);
  V v_t_2496 = heff_tr(heff_call(v_cand_245, 2, (V[]){v_path_2494, NTAG(TAG_Nothing)}));
  return heff_tag_n(TAG_MkPair, 2, (V[]){heff_strAppend(((V)&g_heff_2eelab_2erules_2eevidenceFound_str4), v_t_2495), v_t_2496});
}
V g_heff_2eelab_2erules_2eevidenceFound_lam4(V self, V *args) {
  V v_hd_24103 = args[0];
  V v_k_24104 = args[1];
  V v_x_2498 = heff_env(self)[0];
  heff_drop(v_hd_24103);
  heff_clo_take(self, 1);
  V f_ = v_k_24104;
  args[0] = v_x_2498;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2eevidenceFound_lam8(V self, V *args) {
  V v_u_24142 = args[0];
  V v_one_24116 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_x_2414 = heff_env(self)[2];
  V v_goal_244 = heff_env(self)[3];
  heff_drop(v_u_24142);
  V v_t_24145;
  heff_clo_take(self, 4);
  switch (heff_tag_of(v_one_24116)) {
  case TAG_MkPair: {
    V v_x_24143 = heff_field(v_one_24116, 0);
    heff_take_n(v_one_24116, 1ULL, 2);
    v_t_24145 = v_x_24143;
    break;
  }
  default: heff_nomatch(v_one_24116);
  }
  V v_t_24146 = ({ V a_0 = v_e_240; V a_1 = v_x_2414; V a_2 = v_goal_244; V r_ = (g_heff_2eelab_2erules_2egoalShown(a_0, a_1, a_2)); heff_drop(v_x_2414); r_; });
  V v_t_24147 = heff_strAppend(heff_strAppend(((V)&g_heff_2eelab_2erules_2eevidenceFound_str10), v_t_24145), ((V)&g_heff_2eelab_2erules_2eevidenceFound_str11));
  return heff_strAppend(v_t_24147, v_t_24146);
}
V g_heff_2eelab_2erules_2eevidenceFound_lam9(V self, V *args) {
  V v_x_24150 = args[0];
  V v_k_249 = heff_env(self)[0];
  heff_drop(v_x_24150);
  heff_clo_take(self, 1);
  V f_ = v_k_249;
  args[0] = NTAG(TAG_True);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2eevidenceFound_lam7(V self, V *args) {
  V v_x_24134 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_sp_241 = heff_env(self)[1];
  V v_hd_248 = heff_env(self)[2];
  V v_k_249 = heff_env(self)[3];
  V v_one_24116 = heff_env(self)[4];
  V v_x_2414 = heff_env(self)[5];
  V v_goal_244 = heff_env(self)[6];
  switch (heff_tag_of(v_x_24134)) {
  case TAG_Left: {
    V v_err_24135 = heff_field(v_x_24134, 0);
    V v_ru_24x_24134_24Left = heff_take_reuse_n(v_x_24134, 1ULL, 1);
    heff_clo_take(self, 7);
    heff_drop(v_one_24116);
    heff_drop(v_x_2414);
    heff_drop(v_goal_244);
    V v_note_24136 = ({ V a_0 = heff_get_n(v_e_240, 1, 8); V a_1 = v_err_24135; V r_ = (g_heff_2eelab_2erules_2eprettyEqErr(a_0, a_1)); heff_drop(v_err_24135); r_; });
    V v_t_24137 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(311LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2eevidenceFound_str8), v_sp_241, heff_tag_n(TAG_Just, 1, (V[]){v_note_24136})});
    V v_t_24138 = heff_tag_at_n(v_ru_24x_24134_24Left, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24137})});
    V v_t_24139 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24138})});
    V v_t_24140 = heff_tr(heff_call(heff_take_field(v_hd_248, 2), 1, (V[]){v_t_24139}));
    V f_ = heff_get_n(v_hd_248, 1, 3);
    heff_room[0] = v_t_24140;
    heff_room[1] = v_k_249;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_Right: {
    heff_take_n(v_x_24134, 0ULL, 1);
    heff_clo_take(self, 7);
    V v_t_24148 = heff_tag_n(TAG_Trace, 2, (V[]){heff_rec_n(3, shape_span__kind__text, (V[]){v_sp_241, ((V)&g_heff_2eelab_2erules_2eevidenceFound_str9), heff_clo_n(g_heff_2eelab_2erules_2eevidenceFound_lam8, 1, 4, (V[]){v_one_24116, v_e_240, v_x_2414, v_goal_244})}), NTAG(TAG_MkUnit)});
    V v_t_24149 = heff_tr(heff_call(heff_take_field(v_hd_248, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24148})}));
    V f_ = heff_get_n(v_hd_248, 1, 3);
    heff_room[0] = v_t_24149;
    heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2eevidenceFound_lam9, 1, 1, (V[]){v_k_249});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_x_24134);
  }
}
V g_heff_2eelab_2erules_2eevidenceFound_lam6(V self, V *args) {
  V v_x_24123 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_hm_242 = heff_env(self)[1];
  V v_holeVal_243 = heff_env(self)[2];
  V v_hd_248 = heff_env(self)[3];
  V v_sp_241 = heff_env(self)[4];
  V v_k_249 = heff_env(self)[5];
  V v_one_24116 = heff_env(self)[6];
  V v_x_2414 = heff_env(self)[7];
  V v_goal_244 = heff_env(self)[8];
  V v_val_24124 = heff_take_field(v_x_24123, 1);
  V v_stx_24125 = heff_get_n(v_x_24123, 0, 2);
  V v_x1_24126 = heff_tr(heff_call(v_val_24124, 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_t_24130;
  switch (heff_tag_of(v_x1_24126)) {
  case TAG_Nom: {
    V v_x_24127 = heff_field(v_x1_24126, 0);
    heff_take_n(v_x1_24126, 1ULL, 1);
    v_t_24130 = v_x_24127;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_24126, 0ULL, 1);
    v_t_24130 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_24129 = heff_field(v_x1_24126, 0);
    heff_take_n(v_x1_24126, 1ULL, 1);
    v_t_24130 = v_x_24129;
    break;
  }
  default: heff_nomatch(v_x1_24126);
  }
  V v_c_24131 = heff_dup(heff_rfield(v_e_240, 0));
  V v_len_24132 = heff_take_field(v_c_24131, 0);
  V v_names_24133 = heff_get_n(v_c_24131, 1, 5);
  heff_clo_take(self, 9);
  return (g_heff_2eelab_2erules_2esolveHole(heff_dup(heff_rfield(v_e_240, 1)), heff_rec_n(2, shape_len__names, (V[]){v_len_24132, v_names_24133}), v_hm_242, v_holeVal_243, v_stx_24125, v_t_24130, heff_dup(v_hd_248), heff_clo_n(g_heff_2eelab_2erules_2eevidenceFound_lam7, 1, 7, (V[]){v_e_240, v_sp_241, v_hd_248, v_k_249, v_one_24116, v_x_2414, v_goal_244})));
}
V g_heff_2eelab_2erules_2eevidenceFound_lam5(V self, V *args) {
  V v_x_24106 = args[0];
  V v_inEffect_2423 = heff_env(self)[0];
  V v_final_247 = heff_env(self)[1];
  V v_k_249 = heff_env(self)[2];
  V v_e_240 = heff_env(self)[3];
  V v_x_2414 = heff_env(self)[4];
  V v_goal_244 = heff_env(self)[5];
  V v_written_246 = heff_env(self)[6];
  V v_sp_241 = heff_env(self)[7];
  V v_hd_248 = heff_env(self)[8];
  V v_hm_242 = heff_env(self)[9];
  V v_holeVal_243 = heff_env(self)[10];
  switch (heff_tag_of(v_x_24106)) {
  case TAG_Nil: {
    heff_clo_take(self, 11);
    heff_drop(v_hm_242);
    heff_drop(v_holeVal_243);
    if (((heff_dup(v_inEffect_2423) == NTAG(TAG_True)) && !(heff_dup(v_final_247) == NTAG(TAG_True)))) {
      heff_drop(v_inEffect_2423);
      heff_drop(v_final_247);
      heff_drop_rec(v_e_240, 8);
      heff_drop(v_x_2414);
      heff_drop(v_goal_244);
      heff_drop(v_written_246);
      heff_drop(v_sp_241);
      heff_drop_rec(v_hd_248, 3);
      V f_ = v_k_249;
      args[0] = NTAG(TAG_False);
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    } else {
      heff_drop(v_inEffect_2423);
      heff_drop(v_final_247);
      V v_t_24107 = ({ V a_0 = v_e_240; V a_1 = v_x_2414; V a_2 = v_goal_244; V r_ = (g_heff_2eelab_2erules_2egoalShown(a_0, a_1, a_2)); heff_drop(v_x_2414); r_; });
      V v_msg_24108 = heff_strAppend(((V)&g_heff_2eelab_2erules_2eevidenceFound_str5), v_t_24107);
      V v_t_24109;
      if ((heff_dup(v_written_246) == NTAG(TAG_True))) {
        heff_drop(v_written_246);
        v_t_24109 = ((V)&g_heff_2eelab_2erules_2eevidenceFound_str6);
      } else {
        heff_drop(v_written_246);
        v_t_24109 = ((V)&g_heff_2eelab_2erules_2eevidenceFound_str7);
      }
      V v_t_24110 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(355LL), NTAG(TAG_SError), v_msg_24108, v_sp_241, heff_tag_n(TAG_Just, 1, (V[]){v_t_24109})});
      V v_t_24111 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24110})});
      V v_t_24112 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24111})});
      V v_t_24113 = heff_tr(heff_call(heff_take_field(v_hd_248, 2), 1, (V[]){v_t_24112}));
      V f_ = heff_get_n(v_hd_248, 1, 3);
      heff_room[0] = v_t_24113;
      heff_room[1] = v_k_249;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
  }
  case TAG_Cons: {
    V v_it2_24115 = heff_dup(heff_field(v_x_24106, 1));
    heff_clo_take(self, 11);
    heff_drop(v_written_246);
    switch (heff_tag_of(v_it2_24115)) {
    case TAG_Nil: {
      heff_drop(v_inEffect_2423);
      heff_drop(v_final_247);
      switch (heff_tag_of(v_x_24106)) {
      case TAG_Cons: {
        V v_one_24116 = heff_field(v_x_24106, 0);
        heff_take_n(v_x_24106, 1ULL, 2);
        V v_t_24120;
        switch (heff_tag_of(v_one_24116)) {
        case TAG_MkPair: {
          V v_y_24119 = heff_dup(heff_field(v_one_24116, 1));
          v_t_24120 = v_y_24119;
          break;
        }
        default: heff_nomatch(v_one_24116);
        }
        V v_c_24122;
        switch (heff_tag_of(v_t_24120)) {
        case TAG_MkChk: {
          V v_f_24121 = heff_field(v_t_24120, 0);
          heff_take_n(v_t_24120, 1ULL, 1);
          v_c_24122 = heff_tr(heff_call(v_f_24121, 2, (V[]){heff_dup(v_e_240), heff_dup(v_goal_244)}));
          break;
        }
        default: heff_nomatch(v_t_24120);
        }
        V f_ = v_c_24122;
        heff_room[0] = heff_dup(v_hd_248);
        heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2eevidenceFound_lam6, 1, 9, (V[]){v_e_240, v_hm_242, v_holeVal_243, v_hd_248, v_sp_241, v_k_249, v_one_24116, v_x_2414, v_goal_244});
        if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
      }
      default: return heff_nomatch(v_x_24106);
      }
    }
    case TAG_Cons: {
      V v_ru_24it2_24115_24Cons = heff_take_reuse_n(v_it2_24115, 0ULL, 2);
      heff_drop(v_hm_242);
      heff_drop(v_holeVal_243);
      if (((heff_dup(v_inEffect_2423) == NTAG(TAG_True)) && !(heff_dup(v_final_247) == NTAG(TAG_True)))) {
        heff_drop_tag(v_x_24106, 2);
        heff_drop(v_inEffect_2423);
        heff_drop(v_final_247);
        heff_drop_rec(v_e_240, 8);
        heff_drop(v_x_2414);
        heff_drop(v_goal_244);
        heff_drop(v_sp_241);
        heff_drop_rec(v_hd_248, 3);
        heff_drop_cell(v_ru_24it2_24115_24Cons, 2);
        V f_ = v_k_249;
        args[0] = NTAG(TAG_False);
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      } else {
        heff_drop(v_inEffect_2423);
        heff_drop(v_final_247);
        V v_t_24153 = ({ V a_0 = v_e_240; V a_1 = v_x_2414; V a_2 = v_goal_244; V r_ = (g_heff_2eelab_2erules_2egoalShown(a_0, a_1, a_2)); heff_drop(v_x_2414); r_; });
        V v_x2_24154 = (g_list_2emap_24s1937570095x2110149801_24tok2(v_ru_24it2_24115_24Cons, v_x_24106));
        V v_t_24157;
        switch (heff_tag_of(v_x2_24154)) {
        case TAG_Nil: {
          v_t_24157 = ((V)&g_heff_2eelab_2erules_2eevidenceFound_str12);
          break;
        }
        case TAG_Cons: {
          V v_x_24155 = heff_field(v_x2_24154, 0);
          V v_xs_24156 = heff_field(v_x2_24154, 1);
          heff_take_n(v_x2_24154, 3ULL, 2);
          v_t_24157 = ({ V a_0 = ((V)&g_heff_2eelab_2erules_2eevidenceFound_str13); V a_1 = v_x_24155; V a_2 = v_xs_24156; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24156); r_; });
          break;
        }
        default: heff_nomatch(v_x2_24154);
        }
        V v_t_24158 = heff_strAppend(heff_strAppend(((V)&g_heff_2eelab_2erules_2eevidenceFound_str14), v_t_24153), ((V)&g_heff_2eelab_2erules_2eevidenceFound_str15));
        V v_msg_24159 = heff_strAppend(v_t_24158, v_t_24157);
        V v_t_24160 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(356LL), NTAG(TAG_SError), v_msg_24159, v_sp_241, heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2eelab_2erules_2eevidenceFound_str16)})});
        V v_t_24161 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24160})});
        V v_t_24162 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24161})});
        V v_t_24163 = heff_tr(heff_call(heff_take_field(v_hd_248, 2), 1, (V[]){v_t_24162}));
        V f_ = heff_get_n(v_hd_248, 1, 3);
        heff_room[0] = v_t_24163;
        heff_room[1] = v_k_249;
        if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
      }
    }
    default: return heff_nomatch(v_it2_24115);
    }
  }
  default: return heff_nomatch(v_x_24106);
  }
}
V g_heff_2eelab_2erules_2eevidenceFound_lam3(V self, V *args) {
  V v_x_2498 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_w_2492 = heff_env(self)[1];
  V v_cand_245 = heff_env(self)[2];
  V v_goal_244 = heff_env(self)[3];
  V v_hd_248 = heff_env(self)[4];
  V v_inEffect_2423 = heff_env(self)[5];
  V v_final_247 = heff_env(self)[6];
  V v_k_249 = heff_env(self)[7];
  V v_x_2414 = heff_env(self)[8];
  V v_written_246 = heff_env(self)[9];
  V v_sp_241 = heff_env(self)[10];
  V v_hm_242 = heff_env(self)[11];
  V v_holeVal_243 = heff_env(self)[12];
  V v_c_24105;
  heff_clo_take(self, 13);
  switch (heff_tag_of(v_x_2498)) {
  case TAG_Nil: {
    V v_t_2499 = (g_heff_2eelab_2erules_2esumPaths(heff_rfield(v_e_240, 1), v_w_2492));
    V v_t_24100 = ({ V a_0 = v_e_240; V a_1 = v_cand_245; V a_2 = v_t_2499; V r_ = (g_heff_2eelab_2erules_2ethroughCandidates(a_0, a_1, a_2)); heff_drop(v_cand_245); r_; });
    v_c_24105 = heff_tr(heff_call(((V)&g_heff_2eelab_2erules_2echeckingCandidates_clo), 3, (V[]){heff_dup(v_e_240), heff_dup(v_goal_244), v_t_24100}));
    break;
  }
  case TAG_Cons: {
    heff_drop(v_w_2492);
    heff_drop(v_cand_245);
    v_c_24105 = heff_clo_n(g_heff_2eelab_2erules_2eevidenceFound_lam4, 2, 1, (V[]){v_x_2498});
    break;
  }
  default: heff_nomatch(v_x_2498);
  }
  V f_ = v_c_24105;
  heff_room[0] = heff_dup(v_hd_248);
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2eevidenceFound_lam5, 1, 11, (V[]){v_inEffect_2423, v_final_247, v_k_249, v_e_240, v_x_2414, v_goal_244, v_written_246, v_sp_241, v_hd_248, v_hm_242, v_holeVal_243});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2eevidenceFound_lam1(V self, V *args) {
  V v_x_2414 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_goal_244 = heff_env(self)[1];
  V v_final_247 = heff_env(self)[2];
  V v_written_246 = heff_env(self)[3];
  V v_sp_241 = heff_env(self)[4];
  V v_hd_248 = heff_env(self)[5];
  V v_k_249 = heff_env(self)[6];
  V v_cand_245 = heff_env(self)[7];
  V v_hm_242 = heff_env(self)[8];
  V v_holeVal_243 = heff_env(self)[9];
  HeffT3 v_t_2415 = (g_heff_2eelab_2eunify_2emetasK_24cpr(heff_dup(v_x_2414)));
  {
    V v_field_2417 = v_t_2415.f[1];
    heff_drop(v_t_2415.f[0]);
    heff_drop(v_t_2415.f[2]);
    V v_t_2419 = heff_get_n(heff_dup(heff_rfield(v_e_240, 0)), 0, 5);
    V v_x1_2420 = heff_tr(heff_call(v_field_2417, 3, (V[]){MK_INT(20LL), v_t_2419, heff_dup(v_goal_244)}));
    V v_inEffect_2423;
    switch (heff_tag_of(v_x1_2420)) {
    case TAG_Nil: {
      v_inEffect_2423 = NTAG(TAG_False);
      break;
    }
    case TAG_Cons: {
      heff_take_n(v_x1_2420, 0ULL, 2);
      v_inEffect_2423 = NTAG(TAG_True);
      break;
    }
    default: heff_nomatch(v_x1_2420);
    }
    HeffT3 v_t_2424 = (g_heff_2eelab_2erules_2eeffectAndWorld_24cpr(v_x_2414, heff_dup(v_goal_244)));
    {
      V v_field_2426 = v_t_2424.f[1];
      V v_field_2427 = v_t_2424.f[2];
      int64_t v_tag_2425 = ((int64_t)v_t_2424.f[0]);
      V v_t_2476;
      if ((v_tag_2425 == ((int64_t)0ULL))) {
        V v_h_2428 = v_field_2426;
        heff_drop(v_h_2428);
        V v_w_2429 = v_field_2427;
        HeffT3 v_t_2430 = (g_heff_2eelab_2eunify_2emetasK_24cpr(heff_dup(v_x_2414)));
        {
          V v_field_2431 = v_t_2430.f[0];
          heff_drop(v_t_2430.f[1]);
          heff_drop(v_t_2430.f[2]);
          V v_t_2434 = heff_get_n(heff_dup(heff_rfield(v_e_240, 0)), 0, 5);
          V v_x1_2435 = heff_tr(heff_call(v_field_2431, 3, (V[]){MK_INT(20LL), v_t_2434, v_w_2429}));
          switch (heff_tag_of(v_x1_2435)) {
          case TAG_Nil: {
            HeffT3 v_t_2436 = (g_heff_2eelab_2erules_2eeffectAndWorld_24cpr(v_x_2414, heff_dup(v_goal_244)));
            {
              V v_field_2438 = v_t_2436.f[1];
              V v_field_2439 = v_t_2436.f[2];
              int64_t v_tag_2437 = ((int64_t)v_t_2436.f[0]);
              if ((v_tag_2437 == ((int64_t)0ULL))) {
                V v_h_2440 = v_field_2438;
                V v_w_2441 = v_field_2439;
                heff_drop(v_w_2441);
                V v_it_2442 = (g_heff_2eelab_2evalue_2eforceEl(v_x_2414, v_h_2440));
                switch (heff_tag_of(v_it_2442)) {
                case TAG_VNeu: {
                  V v_it1_2443 = heff_field(v_it_2442, 0);
                  heff_take_n(v_it_2442, 1ULL, 5);
                  switch (heff_tag_of(v_it1_2443)) {
                  case TAG_HLocal: {
                    heff_take_n(v_it1_2443, 0ULL, 1);
                    v_t_2476 = NTAG(TAG_False);
                    break;
                  }
                  case TAG_HGlobal: {
                    heff_take_n(v_it1_2443, 0ULL, 1);
                    v_t_2476 = NTAG(TAG_False);
                    break;
                  }
                  case TAG_HMeta: {
                    heff_take_n(v_it1_2443, 0ULL, 1);
                    v_t_2476 = NTAG(TAG_True);
                    break;
                  }
                  case TAG_HError: {
                    v_t_2476 = NTAG(TAG_False);
                    break;
                  }
                  default: heff_nomatch(v_it1_2443);
                  }
                  break;
                }
                case TAG_VCode: {
                  heff_take_n(v_it_2442, 0ULL, 1);
                  v_t_2476 = NTAG(TAG_False);
                  break;
                }
                case TAG_VLam: {
                  heff_take_n(v_it_2442, 0ULL, 2);
                  v_t_2476 = NTAG(TAG_False);
                  break;
                }
                case TAG_VCons: {
                  heff_take_n(v_it_2442, 0ULL, 1);
                  v_t_2476 = NTAG(TAG_False);
                  break;
                }
                case TAG_VOpaque: {
                  v_t_2476 = NTAG(TAG_False);
                  break;
                }
                default: heff_nomatch(v_it_2442);
                }
              } else {
                heff_drop(v_field_2438);
                heff_drop(v_field_2439);
                v_t_2476 = NTAG(TAG_False);
              }
            }
            break;
          }
          case TAG_Cons: {
            heff_take_n(v_x1_2435, 0ULL, 2);
            v_t_2476 = NTAG(TAG_True);
            break;
          }
          default: heff_nomatch(v_x1_2435);
          }
        }
      } else {
        heff_drop(v_field_2426);
        heff_drop(v_field_2427);
        HeffT3 v_t_2457 = (g_heff_2eelab_2erules_2eeffectAndWorld_24cpr(v_x_2414, heff_dup(v_goal_244)));
        {
          V v_field_2459 = v_t_2457.f[1];
          V v_field_2460 = v_t_2457.f[2];
          int64_t v_tag_2458 = ((int64_t)v_t_2457.f[0]);
          if ((v_tag_2458 == ((int64_t)0ULL))) {
            V v_h_2461 = v_field_2459;
            V v_w_2462 = v_field_2460;
            heff_drop(v_w_2462);
            V v_it_2463 = (g_heff_2eelab_2evalue_2eforceEl(v_x_2414, v_h_2461));
            switch (heff_tag_of(v_it_2463)) {
            case TAG_VNeu: {
              V v_it1_2464 = heff_field(v_it_2463, 0);
              heff_take_n(v_it_2463, 1ULL, 5);
              switch (heff_tag_of(v_it1_2464)) {
              case TAG_HLocal: {
                heff_take_n(v_it1_2464, 0ULL, 1);
                v_t_2476 = NTAG(TAG_False);
                break;
              }
              case TAG_HGlobal: {
                heff_take_n(v_it1_2464, 0ULL, 1);
                v_t_2476 = NTAG(TAG_False);
                break;
              }
              case TAG_HMeta: {
                heff_take_n(v_it1_2464, 0ULL, 1);
                v_t_2476 = NTAG(TAG_True);
                break;
              }
              case TAG_HError: {
                v_t_2476 = NTAG(TAG_False);
                break;
              }
              default: heff_nomatch(v_it1_2464);
              }
              break;
            }
            case TAG_VCode: {
              heff_take_n(v_it_2463, 0ULL, 1);
              v_t_2476 = NTAG(TAG_False);
              break;
            }
            case TAG_VLam: {
              heff_take_n(v_it_2463, 0ULL, 2);
              v_t_2476 = NTAG(TAG_False);
              break;
            }
            case TAG_VCons: {
              heff_take_n(v_it_2463, 0ULL, 1);
              v_t_2476 = NTAG(TAG_False);
              break;
            }
            case TAG_VOpaque: {
              v_t_2476 = NTAG(TAG_False);
              break;
            }
            default: heff_nomatch(v_it_2463);
            }
          } else {
            heff_drop(v_field_2459);
            heff_drop(v_field_2460);
            v_t_2476 = NTAG(TAG_False);
          }
        }
      }
      if ((heff_dup(v_t_2476) == NTAG(TAG_True))) {
        heff_clo_take(self, 10);
        heff_drop(v_cand_245);
        heff_drop(v_hm_242);
        heff_drop(v_holeVal_243);
        heff_drop(v_inEffect_2423);
        heff_drop(v_t_2476);
        if ((heff_dup(v_final_247) == NTAG(TAG_True))) {
          heff_drop(v_final_247);
          V v_t_2477;
          if ((heff_dup(v_written_246) == NTAG(TAG_True))) {
            heff_drop(v_written_246);
            v_t_2477 = ((V)&g_heff_2eelab_2erules_2eevidenceFound_str0);
          } else {
            heff_drop(v_written_246);
            v_t_2477 = ((V)&g_heff_2eelab_2erules_2eevidenceFound_str1);
          }
          V v_t_2478 = ({ V a_0 = v_e_240; V a_1 = v_x_2414; V a_2 = v_goal_244; V r_ = (g_heff_2eelab_2erules_2egoalShown(a_0, a_1, a_2)); heff_drop(v_x_2414); r_; });
          V v_msg_2479 = heff_strAppend(heff_strAppend(v_t_2477, ((V)&g_heff_2eelab_2erules_2eevidenceFound_str2)), v_t_2478);
          V v_t_2480 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(357LL), NTAG(TAG_SError), v_msg_2479, v_sp_241, heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2eelab_2erules_2eevidenceFound_str3)})});
          V v_t_2481 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2480})});
          V v_t_2482 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2481})});
          V v_t_2483 = heff_tr(heff_call(heff_take_field(v_hd_248, 2), 1, (V[]){v_t_2482}));
          V f_ = heff_get_n(v_hd_248, 1, 3);
          heff_room[0] = v_t_2483;
          heff_room[1] = v_k_249;
          if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
          return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
        } else {
          heff_drop(v_x_2414);
          heff_drop_rec(v_e_240, 8);
          heff_drop(v_goal_244);
          heff_drop(v_final_247);
          heff_drop(v_written_246);
          heff_drop(v_sp_241);
          heff_drop_rec(v_hd_248, 3);
          V f_ = v_k_249;
          args[0] = NTAG(TAG_False);
          if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
          return heff_tail(f_, 1, args);
        }
      } else {
        heff_drop(v_t_2476);
        HeffT2 v_t_2484 = (g_heff_2eelab_2ereadback_2eshownForcedRb_24cpr(v_x_2414));
        {
          V v_field_2486 = v_t_2484.f[1];
          heff_drop(v_t_2484.f[0]);
          V v_t_2487 = heff_get_n(heff_dup(heff_rfield(v_e_240, 0)), 0, 5);
          V v_t_2488 = heff_tr(heff_call(v_field_2486, 2, (V[]){v_t_2487, heff_dup(v_goal_244)}));
          HeffT2 v_t_2489 = ({ V a_0 = v_t_2488; HeffT2 r_ = (g_heff_2eelab_2erules_2eworldOf_24cpr(a_0)); heff_drop(v_t_2488); r_; });
          {
            V v_field_2491 = v_t_2489.f[1];
            int64_t v_tag_2490 = ((int64_t)v_t_2489.f[0]);
            if ((v_tag_2490 == ((int64_t)0ULL))) {
              V v_w_2492 = v_field_2491;
              V v_paths_2493 = (g_heff_2eelab_2erules_2esumPaths(heff_rfield(v_e_240, 1), heff_dup(v_w_2492)));
              V v_t_2497 = (g_list_2emap(heff_clo_n(g_heff_2eelab_2erules_2eevidenceFound_lam2, 1, 1, (V[]){heff_dup(v_cand_245)}), v_paths_2493));
              heff_clo_take(self, 10);
              return (g_heff_2eelab_2erules_2echeckingCandidates(heff_dup(v_e_240), heff_dup(v_goal_244), v_t_2497, heff_dup(v_hd_248), heff_clo_n(g_heff_2eelab_2erules_2eevidenceFound_lam3, 1, 13, (V[]){v_e_240, v_w_2492, v_cand_245, v_goal_244, v_hd_248, v_inEffect_2423, v_final_247, v_k_249, v_x_2414, v_written_246, v_sp_241, v_hm_242, v_holeVal_243})));
            } else {
              heff_clo_take(self, 10);
              heff_drop(v_final_247);
              heff_drop(v_written_246);
              heff_drop(v_cand_245);
              heff_drop(v_hm_242);
              heff_drop(v_holeVal_243);
              heff_drop(v_inEffect_2423);
              heff_drop(v_field_2491);
              V v_t_24164 = ({ V a_0 = v_e_240; V a_1 = v_x_2414; V a_2 = v_goal_244; V r_ = (g_heff_2eelab_2erules_2egoalShown(a_0, a_1, a_2)); heff_drop(v_x_2414); r_; });
              V v_msg_24165 = heff_strAppend(((V)&g_heff_2eelab_2erules_2eevidenceFound_str17), v_t_24164);
              V v_t_24166 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(357LL), NTAG(TAG_SError), v_msg_24165, v_sp_241, heff_tag_n(TAG_Just, 1, (V[]){((V)&g_heff_2eelab_2erules_2eevidenceFound_str18)})});
              V v_t_24167 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24166})});
              V v_t_24168 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24167})});
              V v_t_24169 = heff_tr(heff_call(heff_take_field(v_hd_248, 2), 1, (V[]){v_t_24168}));
              V f_ = heff_get_n(v_hd_248, 1, 3);
              heff_room[0] = v_t_24169;
              heff_room[1] = v_k_249;
              if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
              return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
            }
          }
        }
      }
    }
  }
}
V g_heff_2eelab_2erules_2erecordOf_24map0_lam0(V self, V *args);
V g_heff_2eelab_2erules_2erecordOf_24map0_lam1(V self, V *args);
Clo g_heff_2eelab_2erules_2erecordOf_24map0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2erecordOf_24map0_entry, 3, 0};

V g_heff_2eelab_2erules_2erecordOf_24map0(V v_g_240, V v_box_24i_241, V v_a_242) {
  int64_t v_i_241 = heff_unbox_word(v_box_24i_241);
  v_a_242 = heff_arrayOwn(v_a_242);
  if ((((int64_t)0ULL) <= v_i_241)) {
    top_TAG_InRange: ;
    if ((v_i_241 < heff_unbox_word(heff_arrayLength_lent(v_a_242, 0)))) {
      V v_t_243 = heff_arrayIndexIn_lent(v_a_242, heff_box_word(v_i_241), 2);
      V v_t_2412 = heff_arraySetOwnedIn(v_a_242, heff_box_word(v_i_241), heff_clo_n(g_heff_2eelab_2erules_2erecordOf_24map0_lam0, 1, 2, (V[]){heff_dup(v_g_240), v_t_243}));
      V t_0 = v_g_240;
      int64_t t_1 = (v_i_241 + ((int64_t)1ULL));
      V t_2 = v_t_2412;
      v_g_240 = t_0;
      v_i_241 = t_1;
      v_a_242 = t_2;
      goto top_TAG_InRange;
    } else {
      return v_a_242;
    }
  } else {
  }
top: ;
  if ((v_i_241 < heff_unbox_word(heff_arrayLength_lent(v_a_242, 0)))) {
    V v_t_243 = heff_arrayIndex_lent(v_a_242, heff_box_word(v_i_241), 2);
    V v_t_2412 = heff_arraySetOwned(v_a_242, heff_box_word(v_i_241), heff_clo_n(g_heff_2eelab_2erules_2erecordOf_24map0_lam1, 1, 2, (V[]){heff_dup(v_g_240), v_t_243}));
    V t_0 = v_g_240;
    int64_t t_1 = (v_i_241 + ((int64_t)1ULL));
    V t_2 = v_t_2412;
    v_g_240 = t_0;
    v_i_241 = t_1;
    v_a_242 = t_2;
    goto top;
  } else {
    return v_a_242;
  }
}
V g_heff_2eelab_2erules_2erecordOf_24map0_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2erules_2erecordOf_24map0(a0, a[1], a[2]); heff_drop(a0); return r;
}
V g_heff_2eelab_2erules_2erecordOf_24map0_lam0(V self, V *args) {
  V v_vs2_244 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_t_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  HeffT2 v_t_245 = ({ V a_0 = v_g_240; V a_1 = NTAG(TAG_N); V a_2 = v_t_243; V a_3 = v_vs2_244; HeffT2 r_ = (g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_g_240); heff_drop(v_vs2_244); r_; });
  {
    V v_field_247 = v_t_245.f[1];
    int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
    V v_t_2411;
    if ((v_tag_246 == ((int64_t)0ULL))) {
      V v_x_248 = v_field_247;
      v_t_2411 = v_x_248;
    } else {
      if ((v_tag_246 == ((int64_t)1ULL))) {
        V v_x11_249 = v_field_247;
        heff_drop(v_x11_249);
        v_t_2411 = heff_abandon();
      } else {
        V v_x_2410 = v_field_247;
        v_t_2411 = v_x_2410;
      }
    }
    return heff_tag_n(TAG_MkField, 2, (V[]){v_t_2411, NTAG(TAG_Nothing)});
  }
}
V g_heff_2eelab_2erules_2erecordOf_24map0_lam1(V self, V *args) {
  V v_vs2_244 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_t_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  HeffT2 v_t_245 = ({ V a_0 = v_g_240; V a_1 = NTAG(TAG_N); V a_2 = v_t_243; V a_3 = v_vs2_244; HeffT2 r_ = (g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_g_240); heff_drop(v_vs2_244); r_; });
  {
    V v_field_247 = v_t_245.f[1];
    int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
    V v_t_2411;
    if ((v_tag_246 == ((int64_t)0ULL))) {
      V v_x_248 = v_field_247;
      v_t_2411 = v_x_248;
    } else {
      if ((v_tag_246 == ((int64_t)1ULL))) {
        V v_x11_249 = v_field_247;
        heff_drop(v_x11_249);
        v_t_2411 = heff_abandon();
      } else {
        V v_x_2410 = v_field_247;
        v_t_2411 = v_x_2410;
      }
    }
    return heff_tag_n(TAG_MkField, 2, (V[]){v_t_2411, NTAG(TAG_Nothing)});
  }
}

HeffT2 g_heff_2eelab_2erules_2elookupP_24cpr(V v_x1_240, V v_x_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_x11_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_MkPair: {
      V v_y_244 = heff_field(v_x11_242, 0);
      V v_v_245 = heff_field(v_x11_242, 1);
      if (heff_strEq_c_lent(v_y_244, v_x_241, 0)) {
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_v_245)}});
      } else {
        V t_0 = v_rest_243;
        V t_1 = v_x_241;
        v_x1_240 = t_0;
        v_x_241 = t_1;
        goto top;
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x11_242)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
Clo g_heff_2eelab_2erules_2eletsAround_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eletsAround_entry, 5, 0};

V g_heff_2eelab_2erules_2eletsAround(V v_n_240, V v_a_241, V v_x3_242, V v_p_243, V v_body_244) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_p_243);
    return heff_dup(v_body_244);
  }
  case TAG_Cons: {
    V v_x31_245 = heff_field(v_x3_242, 0);
    V v_rest_246 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    switch (heff_tag_of(v_x31_245)) {
    case TAG_MkPair: {
      V v_m_247 = heff_field(v_x31_245, 0);
      V v_v_248 = heff_field(v_x31_245, 1);
      V v_ru_24x31_245_24MkPair = heff_take_reuse_n(v_x31_245, 3ULL, 2);
      V v_ty_249 = heff_take_field(v_m_247, 1);
      V v_name_2410 = heff_get_n(v_m_247, 0, 5);
      V v_t_2411 = (g_heff_2eelab_2evalue_2elevelOf(v_a_241));
      V v_t_2412 = (g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(heff_intAdd_lent(v_n_240, v_p_243, 0), v_ty_249));
      V v_t_2413 = (g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(heff_intAdd_lent(v_n_240, v_p_243, 0), heff_dup(v_a_241)));
      V v_t_2414 = (g_heff_2eelab_2erules_2eletsAround(v_n_240, v_a_241, v_rest_246, heff_intAdd(v_p_243, MK_INT(1LL)), v_body_244));
      V v_t_2415 = heff_tag_n(TAG_SFunction, 5, (V[]){v_t_2411, v_t_2412, heff_tag_n(TAG_AbsConst, 1, (V[]){v_t_2413}), NTAG(TAG_Expl), NTAG(TAG_Nothing)});
      V v_t_2416 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_SLam, 2, (V[]){v_t_2415, heff_tag_at_n(v_ru_24x31_245_24MkPair, TAG_MkAbs, 2, (V[]){v_name_2410, v_t_2414})});
      return heff_tag_n(TAG_SApp, 2, (V[]){v_t_2416, v_v_248});
    }
    default: return heff_nomatch(v_x31_245);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2eelab_2erules_2eletsAround_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a4 = a[4]; V r = g_heff_2eelab_2erules_2eletsAround(a0, a1, a[2], a[3], a4); heff_drop(a0); heff_drop(a1); heff_drop(a4); return r;
}
Clo g_heff_2eelab_2erules_2eletted_24generate1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eletted_24generate1_entry, 3, 0};

V g_heff_2eelab_2erules_2eletted_24generate1(V v_xs_240, V v_box_24i_241, V v_a_242) {
  int64_t v_i_241 = heff_unbox_word(v_box_24i_241);
  v_a_242 = heff_arrayOwn(v_a_242);
  if (((((int64_t)0ULL) <= v_i_241) && (heff_unbox_word(heff_arrayLength_lent(v_a_242, 0)) <= heff_unbox_word(heff_arrayLength_lent(v_xs_240, 0))))) {
    top_TAG_InRange: ;
    if ((v_i_241 < heff_unbox_word(heff_arrayLength_lent(v_a_242, 0)))) {
      V v_m_243 = heff_arrayIndexIn_lent(v_xs_240, heff_box_word(v_i_241), 2);
      V v_t_244 = heff_tr(heff_call(heff_get_n(v_m_243, 1, 2), 1, (V[]){NTAG(TAG_MkUnit)}));
      V t_0 = v_xs_240;
      int64_t t_1 = (v_i_241 + ((int64_t)1ULL));
      V t_2 = heff_arraySetOwnedIn(v_a_242, heff_box_word(v_i_241), v_t_244);
      v_xs_240 = t_0;
      v_i_241 = t_1;
      v_a_242 = t_2;
      goto top_TAG_InRange;
    } else {
      return v_a_242;
    }
  } else {
  }
top: ;
  if ((v_i_241 < heff_unbox_word(heff_arrayLength_lent(v_a_242, 0)))) {
    V v_m_243 = heff_arrayIndex_lent(v_xs_240, heff_box_word(v_i_241), 2);
    V v_t_244 = heff_tr(heff_call(heff_get_n(v_m_243, 1, 2), 1, (V[]){NTAG(TAG_MkUnit)}));
    V t_0 = v_xs_240;
    int64_t t_1 = (v_i_241 + ((int64_t)1ULL));
    V t_2 = heff_arraySetOwned(v_a_242, heff_box_word(v_i_241), v_t_244);
    v_xs_240 = t_0;
    v_i_241 = t_1;
    v_a_242 = t_2;
    goto top;
  } else {
    return v_a_242;
  }
}
V g_heff_2eelab_2erules_2eletted_24generate1_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2erules_2eletted_24generate1(a0, a[1], a[2]); heff_drop(a0); return r;
}
Clo g_heff_2eelab_2erules_2eletted_24map1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eletted_24map1_entry, 2, 0};

V g_heff_2eelab_2erules_2eletted_24map1(V v_box_24i_240, V v_a_241) {
  int64_t v_i_240 = heff_unbox_word(v_box_24i_240);
  v_a_241 = heff_arrayOwn(v_a_241);
  if ((((int64_t)0ULL) <= v_i_240)) {
    top_TAG_InRange: ;
    if ((v_i_240 < heff_unbox_word(heff_arrayLength_lent(v_a_241, 0)))) {
      V v_m_242 = heff_arrayIndexIn_lent(v_a_241, heff_box_word(v_i_240), 2);
      V v_t_243 = heff_tr(heff_call(heff_get_n(v_m_242, 1, 2), 1, (V[]){NTAG(TAG_MkUnit)}));
      int64_t t_0 = (v_i_240 + ((int64_t)1ULL));
      V t_1 = heff_arraySetOwnedIn(v_a_241, heff_box_word(v_i_240), v_t_243);
      v_i_240 = t_0;
      v_a_241 = t_1;
      goto top_TAG_InRange;
    } else {
      return v_a_241;
    }
  } else {
  }
top: ;
  if ((v_i_240 < heff_unbox_word(heff_arrayLength_lent(v_a_241, 0)))) {
    V v_m_242 = heff_arrayIndex_lent(v_a_241, heff_box_word(v_i_240), 2);
    V v_t_243 = heff_tr(heff_call(heff_get_n(v_m_242, 1, 2), 1, (V[]){NTAG(TAG_MkUnit)}));
    int64_t t_0 = (v_i_240 + ((int64_t)1ULL));
    V t_1 = heff_arraySetOwned(v_a_241, heff_box_word(v_i_240), v_t_243);
    v_i_240 = t_0;
    v_a_241 = t_1;
    goto top;
  } else {
    return v_a_241;
  }
}
V g_heff_2eelab_2erules_2eletted_24map1_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2eletted_24map1(a[0], a[1]);
}
V g_heff_2eelab_2erules_2esumFormation_24generate1_lam0(V self, V *args); static Clo g_heff_2eelab_2erules_2esumFormation_24generate1_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2esumFormation_24generate1_lam0, 1, 0};
V g_heff_2eelab_2erules_2esumFormation_24generate1_lam1(V self, V *args); static Clo g_heff_2eelab_2erules_2esumFormation_24generate1_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2esumFormation_24generate1_lam1, 1, 0};
Clo g_heff_2eelab_2erules_2esumFormation_24generate1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2esumFormation_24generate1_entry, 3, 0};

V g_heff_2eelab_2erules_2esumFormation_24generate1(V v_xs_240, V v_box_24i_241, V v_a_242) {
  int64_t v_i_241 = heff_unbox_word(v_box_24i_241);
  v_a_242 = heff_arrayOwn(v_a_242);
  if (((((int64_t)0ULL) <= v_i_241) && (heff_unbox_word(heff_arrayLength_lent(v_a_242, 0)) <= heff_unbox_word(heff_arrayLength_lent(v_xs_240, 0))))) {
    top_TAG_InRange: ;
    if ((v_i_241 < heff_unbox_word(heff_arrayLength_lent(v_a_242, 0)))) {
      V v_xs_243 = heff_arrayIndexIn_lent(v_xs_240, heff_box_word(v_i_241), 2);
      V v_m_244 = heff_arrayLength_lent(v_xs_243, 0);
      V v_t_249;
      if ((heff_peek_word(v_m_244) <= ((int64_t)0ULL))) {
        heff_drop(v_xs_243);
        v_t_249 = heff_arrayGenerate(v_m_244, ((V)&g_heff_2eelab_2erules_2esumFormation_24generate1_lam0_clo));
      } else {
        V v_m_246 = heff_arrayIndex_lent(v_xs_243, MK_INT(0LL), 2);
        V v_y_247 = heff_get_n(v_m_246, 0, 2);
        V v_t_248 = heff_arrayKeepsAs_lent(v_xs_243, v_y_247, 0);
        if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
          heff_drop(v_m_244);
          heff_drop(v_t_248);
          v_t_249 = (g_heff_2eelab_2erules_2esumFormation_24map0(MK_INT(1LL), heff_arraySet(v_xs_243, MK_INT(0LL), v_y_247)));
        } else {
          heff_drop(v_t_248);
          v_t_249 = ({ V a_0 = v_xs_243; V a_1 = MK_INT(1LL); V a_2 = heff_arrayReplicate(v_m_244, v_y_247); V r_ = (g_heff_2eelab_2erules_2esumFormation_24generate0(a_0, a_1, a_2)); heff_drop(v_xs_243); r_; });
        }
      }
      V t_0 = v_xs_240;
      int64_t t_1 = (v_i_241 + ((int64_t)1ULL));
      V t_2 = heff_arraySetOwnedIn(v_a_242, heff_box_word(v_i_241), v_t_249);
      v_xs_240 = t_0;
      v_i_241 = t_1;
      v_a_242 = t_2;
      goto top_TAG_InRange;
    } else {
      return v_a_242;
    }
  } else {
  }
top: ;
  if ((v_i_241 < heff_unbox_word(heff_arrayLength_lent(v_a_242, 0)))) {
    V v_xs_243 = heff_arrayIndex_lent(v_xs_240, heff_box_word(v_i_241), 2);
    V v_m_244 = heff_arrayLength_lent(v_xs_243, 0);
    V v_t_249;
    if ((heff_peek_word(v_m_244) <= ((int64_t)0ULL))) {
      heff_drop(v_xs_243);
      v_t_249 = heff_arrayGenerate(v_m_244, ((V)&g_heff_2eelab_2erules_2esumFormation_24generate1_lam1_clo));
    } else {
      V v_m_246 = heff_arrayIndex_lent(v_xs_243, MK_INT(0LL), 2);
      V v_y_247 = heff_get_n(v_m_246, 0, 2);
      V v_t_248 = heff_arrayKeepsAs_lent(v_xs_243, v_y_247, 0);
      if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
        heff_drop(v_m_244);
        heff_drop(v_t_248);
        v_t_249 = (g_heff_2eelab_2erules_2esumFormation_24map0(MK_INT(1LL), heff_arraySet(v_xs_243, MK_INT(0LL), v_y_247)));
      } else {
        heff_drop(v_t_248);
        v_t_249 = ({ V a_0 = v_xs_243; V a_1 = MK_INT(1LL); V a_2 = heff_arrayReplicate(v_m_244, v_y_247); V r_ = (g_heff_2eelab_2erules_2esumFormation_24generate0(a_0, a_1, a_2)); heff_drop(v_xs_243); r_; });
      }
    }
    V t_0 = v_xs_240;
    int64_t t_1 = (v_i_241 + ((int64_t)1ULL));
    V t_2 = heff_arraySetOwned(v_a_242, heff_box_word(v_i_241), v_t_249);
    v_xs_240 = t_0;
    v_i_241 = t_1;
    v_a_242 = t_2;
    goto top;
  } else {
    return v_a_242;
  }
}
V g_heff_2eelab_2erules_2esumFormation_24generate1_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2erules_2esumFormation_24generate1(a0, a[1], a[2]); heff_drop(a0); return r;
}
V g_heff_2eelab_2erules_2esumFormation_24generate1_lam0(V self, V *args) {
  V v_u_245 = args[0];
  heff_drop(v_u_245);
  return heff_abandon();
}
V g_heff_2eelab_2erules_2esumFormation_24generate1_lam1(V self, V *args) {
  V v_u_245 = args[0];
  heff_drop(v_u_245);
  return heff_abandon();
}
Clo g_heff_2eelab_2erules_2etermParts_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2etermParts_entry, 2, 0};

V g_heff_2eelab_2erules_2etermParts(V v_x1_240, V v_rest_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_SLocal: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return v_rest_241;
  }
  case TAG_SGlobal: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return v_rest_241;
  }
  case TAG_SCode: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return v_rest_241;
  }
  case TAG_SApp: {
    V v_f_245 = heff_field(v_x1_240, 0);
    V v_x_246 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24SApp = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x1_240_24SApp, TAG_Cons, 2, (V[]){v_f_245, heff_tag_n(TAG_Cons, 2, (V[]){v_x_246, v_rest_241})});
  }
  case TAG_SLam: {
    V v_x12_248 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24SLam = heff_take_reuse_n(v_x1_240, 2ULL, 2);
    switch (heff_tag_of(v_x12_248)) {
    case TAG_MkAbs: {
      V v_x_2410 = heff_field(v_x12_248, 1);
      heff_take_n(v_x12_248, 2ULL, 2);
      return heff_tag_at_n(v_ru_24x1_240_24SLam, TAG_Cons, 2, (V[]){v_x_2410, v_rest_241});
    }
    case TAG_AbsConst: {
      V v_x_2411 = heff_field(v_x12_248, 0);
      heff_take_n(v_x12_248, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_240_24SLam, TAG_Cons, 2, (V[]){v_x_2411, v_rest_241});
    }
    default: return heff_nomatch(v_x12_248);
    }
  }
  case TAG_SCons: {
    V v_d_2412 = heff_field(v_x1_240, 0);
    heff_take_n(v_x1_240, 1ULL, 1);
    V v_keys_2413 = heff_take_field(v_d_2412, 0);
    V v_values_2414 = heff_get_n(v_d_2412, 2, 3);
    V v_t_2415 = (g_heff_2eutil_2edict_2ezipKV(heff_arrayToList(v_keys_2413), heff_arrayToList(v_values_2414)));
    HEFF_LAST return g_heff_2eelab_2erules_2eappendP_24f269230951x1054333672(v_rest_241, v_t_2415);
  }
  case TAG_SProj: {
    V v_x_2416 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24SProj = heff_take_reuse_n(v_x1_240, 1ULL, 2);
    return heff_tag_at_n(v_ru_24x1_240_24SProj, TAG_Cons, 2, (V[]){v_x_2416, v_rest_241});
  }
  case TAG_STag: {
    V v_xs_2419 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24STag = heff_take_reuse_n(v_x1_240, 2ULL, 2);
    return (g_heff_2eelab_2erules_2eappendP_24tok2(v_ru_24x1_240_24STag, heff_arrayToList(v_xs_2419), v_rest_241));
  }
  case TAG_SMatch: {
    V v_x_2420 = heff_field(v_x1_240, 0);
    V v_cs_2421 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24SMatch = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_keys_2422 = heff_take_field(v_cs_2421, 0);
    V v_values_2423 = heff_get_n(v_cs_2421, 2, 3);
    V v_t_2424 = (g_heff_2eutil_2edict_2ezipKV(heff_arrayToList(v_keys_2422), heff_arrayToList(v_values_2423)));
    V v_t_2425 = (g_heff_2eelab_2erules_2eappendP_24f1466307730x554320163(v_rest_241, v_t_2424));
    return heff_tag_at_n(v_ru_24x1_240_24SMatch, TAG_Cons, 2, (V[]){v_x_2420, v_t_2425});
  }
  case TAG_SSpecialize: {
    V v_x_2426 = heff_field(v_x1_240, 0);
    V v_y_2428 = heff_field(v_x1_240, 2);
    heff_take_n(v_x1_240, 5ULL, 3);
    return heff_tag_n(TAG_Cons, 2, (V[]){v_x_2426, heff_tag_n(TAG_Cons, 2, (V[]){v_y_2428, v_rest_241})});
  }
  case TAG_SIs: {
    V v_x_2429 = heff_field(v_x1_240, 0);
    heff_take_n(v_x1_240, 1ULL, 1);
    return heff_tag_n(TAG_Cons, 2, (V[]){v_x_2429, v_rest_241});
  }
  case TAG_SOpaque: {
    return v_rest_241;
  }
  case TAG_SAbandon: {
    return v_rest_241;
  }
  case TAG_SRec: {
    V v_x_2430 = heff_field(v_x1_240, 0);
    heff_take_n(v_x1_240, 1ULL, 1);
    return heff_tag_n(TAG_Cons, 2, (V[]){v_x_2430, v_rest_241});
  }
  case TAG_SFix: {
    V v_x12_2432 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24SFix = heff_take_reuse_n(v_x1_240, 2ULL, 2);
    switch (heff_tag_of(v_x12_2432)) {
    case TAG_MkAbs: {
      V v_x_2434 = heff_field(v_x12_2432, 1);
      heff_take_n(v_x12_2432, 2ULL, 2);
      return heff_tag_at_n(v_ru_24x1_240_24SFix, TAG_Cons, 2, (V[]){v_x_2434, v_rest_241});
    }
    case TAG_AbsConst: {
      V v_x_2435 = heff_field(v_x12_2432, 0);
      heff_take_n(v_x12_2432, 1ULL, 1);
      return heff_tag_at_n(v_ru_24x1_240_24SFix, TAG_Cons, 2, (V[]){v_x_2435, v_rest_241});
    }
    default: return heff_nomatch(v_x12_2432);
    }
  }
  case TAG_SImplicit: {
    V v_x_2437 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24SImplicit = heff_take_reuse_n(v_x1_240, 2ULL, 2);
    return heff_tag_at_n(v_ru_24x1_240_24SImplicit, TAG_Cons, 2, (V[]){v_x_2437, v_rest_241});
  }
  case TAG_SPrim: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return v_rest_241;
  }
  case TAG_SMetaApp: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return v_rest_241;
  }
  case TAG_SLitInt: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return v_rest_241;
  }
  case TAG_SLitFloat: {
    heff_take_na(v_x1_240, 0ULL, 1);
    return v_rest_241;
  }
  case TAG_SLitString: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return v_rest_241;
  }
  case TAG_SLitBytes: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return v_rest_241;
  }
  case TAG_SLitRune: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return v_rest_241;
  }
  case TAG_SLitFixed: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return v_rest_241;
  }
  case TAG_SLitFloat32: {
    heff_take_na(v_x1_240, 0ULL, 1);
    return v_rest_241;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2erules_2etermParts_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2etermParts(a[0], a[1]);
}
Clo g_heff_2eelab_2erules_2einOrder_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2einOrder_entry, 5, 0};

V g_heff_2eelab_2erules_2einOrder(V v_n_240, V v_body_241, V v_casesChk_242, V v_x4_243, V v_x5_244) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nil: {
    heff_drop(v_n_240);
    heff_drop(v_body_241);
    heff_drop_rec(v_casesChk_242, 3);
    heff_drop(v_x5_244);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_p_245 = heff_field(v_x4_243, 0);
    V v_rest_246 = heff_field(v_x4_243, 1);
    V v_ru_24x4_243_24Cons = heff_take_reuse_n(v_x4_243, 3ULL, 2);
    switch (heff_tag_of(v_x5_244)) {
    case TAG_Nil: {
      V v_t_247 = (g_heff_2eelab_2erules_2edefaultCopy(heff_dup(v_n_240), heff_dup(v_body_241), v_p_245));
      V v_cell_248 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){v_t_247, heff_hole()});
      V v_u_249 = ({ V a_0 = v_n_240; V a_1 = v_body_241; V a_2 = v_casesChk_242; V a_3 = v_rest_246; V a_4 = NTAG(TAG_Nil); V a_5 = v_cell_248; V r_ = (g_heff_2eelab_2erules_2einOrder_24dps(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_n_240); heff_drop(v_body_241); heff_drop_rec(v_casesChk_242, 3); r_; });
      heff_drop(v_u_249);
      return v_cell_248;
    }
    case TAG_Cons: {
      V v_c_2410 = heff_field(v_x5_244, 0);
      V v_done_2411 = heff_field(v_x5_244, 1);
      V v_ru_24x5_244_24Cons = heff_take_reuse_n(v_x5_244, 3ULL, 2);
      switch (heff_tag_of(v_p_245)) {
      case TAG_MkPair: {
        V v_x_2412 = heff_dup(heff_field(v_p_245, 0));
        HeffT2 v_t_2414 = ({ V a_0 = heff_rfield(v_casesChk_242, 1); V a_1 = v_x_2412; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_x_2412); r_; });
        {
          V v_field_2416 = v_t_2414.f[1];
          int64_t v_tag_2415 = ((int64_t)v_t_2414.f[0]);
          if ((v_tag_2415 == ((int64_t)0ULL))) {
            V v_i_2417 = v_field_2416;
            V v_xs_2418 = heff_dup(heff_rfield(v_casesChk_242, 2));
            if ((heff_intLe_c_lent(MK_INT(0LL), v_i_2417, 1) && heff_intLt_c_lent(v_i_2417, heff_arrayLength_lent(v_xs_2418, 0), 2))) {
              heff_drop_tag(v_p_245, 2);
              heff_drop_cell(v_ru_24x5_244_24Cons, 2);
              V v_x_2419 = heff_arrayIndex(v_xs_2418, v_i_2417);
              heff_drop(v_x_2419);
              V v_cell_2420 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){v_c_2410, heff_hole()});
              V v_u_2421 = ({ V a_0 = v_n_240; V a_1 = v_body_241; V a_2 = v_casesChk_242; V a_3 = v_rest_246; V a_4 = v_done_2411; V a_5 = v_cell_2420; V r_ = (g_heff_2eelab_2erules_2einOrder_24dps(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_n_240); heff_drop(v_body_241); heff_drop_rec(v_casesChk_242, 3); r_; });
              heff_drop(v_u_2421);
              return v_cell_2420;
            } else {
              heff_drop(v_i_2417);
              heff_drop(v_xs_2418);
              V v_t_2422 = (g_heff_2eelab_2erules_2edefaultCopy(heff_dup(v_n_240), heff_dup(v_body_241), v_p_245));
              V v_cell_2423 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){v_t_2422, heff_hole()});
              V v_u_2424 = ({ V a_0 = v_n_240; V a_1 = v_body_241; V a_2 = v_casesChk_242; V a_3 = v_rest_246; V a_4 = heff_tag_re_n(v_ru_24x5_244_24Cons, TAG_Cons, 2, 3ULL, (V[]){v_c_2410, v_done_2411}); V a_5 = v_cell_2423; V r_ = (g_heff_2eelab_2erules_2einOrder_24dps(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_n_240); heff_drop(v_body_241); heff_drop_rec(v_casesChk_242, 3); r_; });
              heff_drop(v_u_2424);
              return v_cell_2423;
            }
          } else {
            heff_drop(v_field_2416);
            V v_t_2425 = (g_heff_2eelab_2erules_2edefaultCopy(heff_dup(v_n_240), heff_dup(v_body_241), v_p_245));
            V v_cell_2426 = heff_tag_at_n(v_ru_24x4_243_24Cons, TAG_Cons, 2, (V[]){v_t_2425, heff_hole()});
            V v_u_2427 = ({ V a_0 = v_n_240; V a_1 = v_body_241; V a_2 = v_casesChk_242; V a_3 = v_rest_246; V a_4 = heff_tag_re_n(v_ru_24x5_244_24Cons, TAG_Cons, 2, 3ULL, (V[]){v_c_2410, v_done_2411}); V a_5 = v_cell_2426; V r_ = (g_heff_2eelab_2erules_2einOrder_24dps(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_n_240); heff_drop(v_body_241); heff_drop_rec(v_casesChk_242, 3); r_; });
            heff_drop(v_u_2427);
            return v_cell_2426;
          }
        }
      }
      default: return heff_nomatch(v_p_245);
      }
    }
    default: return heff_nomatch(v_x5_244);
    }
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2eelab_2erules_2einOrder_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2einOrder(a[0], a[1], a[2], a[3], a[4]);
}
HEFF_LIT(g_heff_2eelab_2erules_2ecasesAt_str0, 1, "_");
HEFF_LIT(g_heff_2eelab_2erules_2ecasesAt_str1, 1, "_");
HEFF_LIT(g_heff_2eelab_2erules_2ecasesAt_str2, 1, "_");
V g_heff_2eelab_2erules_2ecasesAt_lam2(V self, V *args);
V g_heff_2eelab_2erules_2ecasesAt_lam4(V self, V *args);
V g_heff_2eelab_2erules_2ecasesAt_lam6(V self, V *args); static Clo g_heff_2eelab_2erules_2ecasesAt_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2ecasesAt_lam6, 1, 0};
V g_heff_2eelab_2erules_2ecasesAt_lam5(V self, V *args);
V g_heff_2eelab_2erules_2ecasesAt_lam3(V self, V *args);
V g_heff_2eelab_2erules_2ecasesAt_lam1(V self, V *args);
V g_heff_2eelab_2erules_2ecasesAt_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2ecasesAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2ecasesAt_entry, 11, 0};

V g_heff_2eelab_2erules_2ecasesAt(V v_sp_240, V v_e_241, V v_b_242, V v_scrut_243, V v_a_244, V v_part_245, V v_vs_246, V v_tags_247, V v_casesChk_248, V v_z_249, V v_z_2410) {
top: ;
  V v_c_2411 = (g_heff_2eelab_2erules_2erecordTags(heff_dup(v_e_241), heff_dup(v_a_244), heff_dup(v_vs_246), v_tags_247));
  return heff_tail(v_c_2411, 2, (V[]){heff_dup(v_z_249), heff_clo_n(g_heff_2eelab_2erules_2ecasesAt_lam0, 1, 11, (V[]){v_e_241, v_a_244, v_vs_246, heff_dup(v_tags_247), v_z_249, v_casesChk_248, v_sp_240, v_b_242, v_part_245, v_scrut_243, v_z_2410})});
}
V g_heff_2eelab_2erules_2ecasesAt_entry(V self, V *a) {
  (void)self;
  V a7 = a[7]; V r = g_heff_2eelab_2erules_2ecasesAt(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a7, a[8], a[9], a[10]); heff_drop(a7); return r;
}
V g_heff_2eelab_2erules_2ecasesAt_lam2(V self, V *args) {
  V v_p_2417 = args[0];
  V v_casesChk_248 = heff_env(self)[0];
  switch (heff_tag_of(v_p_2417)) {
  case TAG_MkPair: {
    V v_x_2418 = heff_field(v_p_2417, 0);
    heff_take_n(v_p_2417, 1ULL, 2);
    HeffT2 v_t_2420 = ({ V a_0 = heff_rfield(v_casesChk_248, 1); V a_1 = v_x_2418; HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_x_2418); r_; });
    {
      V v_field_2422 = v_t_2420.f[1];
      int64_t v_tag_2421 = ((int64_t)v_t_2420.f[0]);
      V v_ret_24bool = heff_bool(((v_tag_2421 == ((int64_t)0ULL)) && ({ V v_i_2423 = heff_dup(v_field_2422); int c_ = ({ V v_xs_2424 = heff_dup(heff_rfield(v_casesChk_248, 2)); int c_ = ((heff_intLe_c_lent(MK_INT(0LL), v_i_2423, 1) && heff_intLt_c_lent(v_i_2423, heff_arrayLength_lent(v_xs_2424, 0), 2)) && ({ V v_x_2425 = heff_arrayIndex_lent(v_xs_2424, v_i_2423, 0); int c_ = 1; heff_drop(v_x_2425); c_; })); heff_drop(v_xs_2424); c_; }); heff_drop(v_i_2423); c_; })));
      heff_drop(self);
      heff_drop(v_field_2422);
      return v_ret_24bool;
    }
  }
  default: return heff_nomatch(v_p_2417);
  }
}
V g_heff_2eelab_2erules_2ecasesAt_lam4(V self, V *args) {
  V v_p_2456 = args[0];
  V v_sp_240 = heff_env(self)[0];
  V v_e_241 = heff_env(self)[1];
  V v_b_242 = heff_env(self)[2];
  V v_a_244 = heff_env(self)[3];
  V v_part_245 = heff_env(self)[4];
  V v_tags_247 = heff_env(self)[5];
  V v_casesChk_248 = heff_env(self)[6];
  switch (heff_tag_of(v_p_2456)) {
  case TAG_MkPair: {
    V v_x_2457 = heff_field(v_p_2456, 0);
    V v_fs_2458 = heff_field(v_p_2456, 1);
    heff_take_n(v_p_2456, 3ULL, 2);
    heff_clo_take(self, 7);
    return ({ V a_0 = v_sp_240; V a_1 = v_e_241; V a_2 = v_b_242; V a_3 = v_a_244; V a_4 = v_part_245; V a_5 = v_tags_247; V a_6 = v_x_2457; V a_7 = heff_arrayToList(v_fs_2458); V a_8 = v_casesChk_248; V r_ = (g_heff_2eelab_2erules_2ecaseArm(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8)); heff_drop(v_a_244); heff_drop(v_tags_247); r_; });
  }
  default: return heff_nomatch(v_p_2456);
  }
}
V g_heff_2eelab_2erules_2ecasesAt_lam6(V self, V *args) {
  V v_u_2466 = args[0];
  heff_drop(v_u_2466);
  return heff_tag_n(TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
}
V g_heff_2eelab_2erules_2ecasesAt_lam5(V self, V *args) {
  V v_x_2460 = args[0];
  V v_scrut_243 = heff_env(self)[0];
  V v_z_2410 = heff_env(self)[1];
  V v_t_2461 = (g_list_2emap_24s1937570095x2110149801(heff_dup(v_x_2460)));
  V v_t_2462 = (g_heff_2eutil_2edict_2eindexed(MK_INT(0LL), v_x_2460));
  V v_t_2463 = (g_list_2emap_24s1173914895x100384474(v_x_2460));
  V v_cases_2464 = heff_rec_n(3, shape_keys__byName__values, (V[]){heff_arrayFromList(v_t_2461), v_t_2462, heff_arrayFromList(v_t_2463)});
  heff_clo_take(self, 2);
  V v_t_2465 = heff_tag_n(TAG_SMatch, 2, (V[]){heff_take_field(v_scrut_243, 0), v_cases_2464});
  V f_ = v_z_2410;
  args[0] = ({ V rv_0 = v_t_2465; V rv_1 = ((V)&g_heff_2eelab_2erules_2ecasesAt_lam6_clo); V rr_ = heff_rec_reuse_nf(v_scrut_243, 0ULL, 2, shape_stx__val, 0u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 1) = rv_1; rr_; });
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2ecasesAt_lam3(V self, V *args) {
  V v_x_2436 = args[0];
  V v_casesChk_248 = heff_env(self)[0];
  V v_every_2416 = heff_env(self)[1];
  V v_named_2426 = heff_env(self)[2];
  V v_sp_240 = heff_env(self)[3];
  V v_e_241 = heff_env(self)[4];
  V v_b_242 = heff_env(self)[5];
  V v_a_244 = heff_env(self)[6];
  V v_part_245 = heff_env(self)[7];
  V v_tags_247 = heff_env(self)[8];
  V v_z_249 = heff_env(self)[9];
  V v_scrut_243 = heff_env(self)[10];
  V v_z_2410 = heff_env(self)[11];
  heff_drop(v_x_2436);
  V v_casesChk_2437 = heff_dup(v_casesChk_248);
  V v_byName_2438 = heff_take_field(v_casesChk_2437, 1);
  V v_values_2439 = heff_get_n(v_casesChk_2437, 2, 3);
  V v_every_2440 = heff_dup(v_every_2416);
  V v_named_2441 = heff_dup(v_named_2426);
  V v_t_2442 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_every_2440; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_every_2440); r_; });
  V v_t_2443 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_named_2441));
  V v_x_2444 = heff_intSub(v_t_2442, v_t_2443);
  V v_t_2455;
  if (heff_intLt_c(MK_INT(1LL), v_x_2444)) {
    switch (heff_tag_of(v_named_2441)) {
    case TAG_Nil: {
      heff_drop(v_byName_2438);
      heff_drop(v_values_2439);
      v_t_2455 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Cons: {
      heff_take_n(v_named_2441, 0ULL, 2);
      HeffT2 v_t_2447 = ({ V a_0 = v_byName_2438; V a_1 = ((V)&g_heff_2eelab_2erules_2ecasesAt_str2); HeffT2 r_ = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(a_0, a_1)); heff_drop(v_byName_2438); r_; });
      {
        V v_field_2449 = v_t_2447.f[1];
        int64_t v_tag_2448 = ((int64_t)v_t_2447.f[0]);
        if ((v_tag_2448 == ((int64_t)0ULL))) {
          V v_i_2450 = v_field_2449;
          V v_xs_2451 = v_values_2439;
          if ((heff_intLe_c_lent(MK_INT(0LL), v_i_2450, 1) && heff_intLt_c_lent(v_i_2450, heff_arrayLength_lent(v_xs_2451, 0), 2))) {
            V v_t_2452 = heff_arrayIndex(v_xs_2451, v_i_2450);
            switch (heff_tag_of(v_t_2452)) {
            case TAG_MkPair: {
              V v_c_2454 = heff_field(v_t_2452, 1);
              heff_take_n(v_t_2452, 2ULL, 2);
              v_t_2455 = heff_tag_n(TAG_Just, 1, (V[]){v_c_2454});
              break;
            }
            default: heff_nomatch(v_t_2452);
            }
          } else {
            heff_drop(v_i_2450);
            heff_drop(v_xs_2451);
            v_t_2455 = NTAG(TAG_Nothing);
          }
        } else {
          heff_drop(v_values_2439);
          heff_drop(v_field_2449);
          v_t_2455 = NTAG(TAG_Nothing);
        }
      }
      break;
    }
    default: heff_nomatch(v_named_2441);
    }
  } else {
    heff_drop(v_byName_2438);
    heff_drop(v_values_2439);
    heff_drop(v_named_2441);
    v_t_2455 = NTAG(TAG_Nothing);
  }
  switch (heff_tag_of(v_t_2455)) {
  case TAG_Nothing: {
    heff_clo_take(self, 12);
    heff_drop(v_named_2426);
    V v_t_2459 = (g_prelude_2etraverse_24s1934076392x614790049(heff_clo_n(g_heff_2eelab_2erules_2ecasesAt_lam4, 1, 7, (V[]){v_sp_240, v_e_241, v_b_242, v_a_244, v_part_245, v_tags_247, v_casesChk_248}), v_every_2416));
    V f_ = v_t_2459;
    heff_room[0] = v_z_249;
    heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2ecasesAt_lam5, 1, 2, (V[]){v_scrut_243, v_z_2410});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_Just: {
    V v_d_2467 = heff_field(v_t_2455, 0);
    heff_take_n(v_t_2455, 1ULL, 1);
    heff_clo_take(self, 12);
    return ({ V a_0 = v_sp_240; V a_1 = v_e_241; V a_2 = v_b_242; V a_3 = v_scrut_243; V a_4 = v_a_244; V a_5 = v_part_245; V a_6 = v_tags_247; V a_7 = v_every_2416; V a_8 = v_named_2426; V a_9 = v_casesChk_248; V a_10 = v_d_2467; V a_11 = v_z_249; V a_12 = v_z_2410; V r_ = (g_heff_2eelab_2erules_2ecasesWith(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9, a_10, a_11, a_12)); heff_drop(v_a_244); heff_drop(v_tags_247); heff_drop(v_d_2467); r_; });
  }
  default: return heff_nomatch(v_t_2455);
  }
}
V g_heff_2eelab_2erules_2ecasesAt_lam1(V self, V *args) {
  V v_x_2413 = args[0];
  V v_vs_246 = heff_env(self)[0];
  V v_casesChk_248 = heff_env(self)[1];
  V v_tags_247 = heff_env(self)[2];
  V v_e_241 = heff_env(self)[3];
  V v_z_249 = heff_env(self)[4];
  V v_sp_240 = heff_env(self)[5];
  V v_b_242 = heff_env(self)[6];
  V v_a_244 = heff_env(self)[7];
  V v_part_245 = heff_env(self)[8];
  V v_scrut_243 = heff_env(self)[9];
  V v_z_2410 = heff_env(self)[10];
  heff_drop(v_x_2413);
  heff_clo_take(self, 11);
  V v_t_2414 = heff_arrayToList(heff_take_field(v_vs_246, 0));
  V v_t_2415 = heff_arrayToList(heff_get_n(v_vs_246, 2, 3));
  V v_every_2416 = (g_heff_2eutil_2edict_2ezipKV(v_t_2414, v_t_2415));
  V v_named_2426 = ({ V b_0 = heff_clo_n(g_heff_2eelab_2erules_2ecasesAt_lam2, 1, 1, (V[]){heff_dup(v_casesChk_248)}); V a_1 = heff_dup(v_every_2416); V r_ = (g_list_2ekeepIf(b_0, a_1)); heff_drop(b_0); r_; });
  HeffT2 v_t_2427 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(heff_rfield(v_casesChk_248, 1), ((V)&g_heff_2eelab_2erules_2ecasesAt_str0)));
  {
    V v_field_2429 = v_t_2427.f[1];
    int64_t v_tag_2428 = ((int64_t)v_t_2427.f[0]);
    V v_t_2433 = heff_bool(((v_tag_2428 == ((int64_t)0ULL)) && ({ V v_i_2430 = heff_dup(v_field_2429); int c_ = ({ V v_xs_2431 = heff_dup(heff_rfield(v_casesChk_248, 2)); int c_ = ((heff_intLe_c_lent(MK_INT(0LL), v_i_2430, 1) && heff_intLt_c_lent(v_i_2430, heff_arrayLength_lent(v_xs_2431, 0), 2)) && ({ V v_x_2432 = heff_arrayIndex_lent(v_xs_2431, v_i_2430, 0); int c_ = 1; heff_drop(v_x_2432); c_; })); heff_drop(v_xs_2431); c_; }); heff_drop(v_i_2430); c_; })));
    heff_drop(v_field_2429);
    V v_t_2434 = heff_bool(((heff_dup(v_t_2433) == NTAG(TAG_True)) && ({ V v_t_2468 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_named_2426)); int c_ = ({ V v_t_2469 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_every_2416)); int c_ = heff_intEq_c_lent(v_t_2468, v_t_2469, 0); heff_drop(v_t_2469); c_; }); heff_drop(v_t_2468); c_; })));
    heff_drop(v_t_2433);
    V v_t_2435 = (g_heff_2eelab_2erules_2ewrittenAt(v_tags_247, ((V)&g_heff_2eelab_2erules_2ecasesAt_str1)));
    return ({ V a_0 = heff_dup(heff_rfield(v_e_241, 0)); V a_1 = v_t_2434; V a_2 = v_t_2435; V a_3 = heff_dup(v_z_249); V a_4 = heff_clo_n(g_heff_2eelab_2erules_2ecasesAt_lam3, 1, 12, (V[]){v_casesChk_248, v_every_2416, v_named_2426, v_sp_240, v_e_241, v_b_242, v_a_244, v_part_245, v_tags_247, v_z_249, v_scrut_243, v_z_2410}); V r_ = (g_heff_2eelab_2erules_2eseeCovered(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_t_2434); r_; });
  }
}
V g_heff_2eelab_2erules_2ecasesAt_lam0(V self, V *args) {
  V v_x_2412 = args[0];
  V v_e_241 = heff_env(self)[0];
  V v_a_244 = heff_env(self)[1];
  V v_vs_246 = heff_env(self)[2];
  V v_tags_247 = heff_env(self)[3];
  V v_z_249 = heff_env(self)[4];
  V v_casesChk_248 = heff_env(self)[5];
  V v_sp_240 = heff_env(self)[6];
  V v_b_242 = heff_env(self)[7];
  V v_part_245 = heff_env(self)[8];
  V v_scrut_243 = heff_env(self)[9];
  V v_z_2410 = heff_env(self)[10];
  heff_drop(v_x_2412);
  heff_clo_take(self, 11);
  return ({ V a_0 = heff_dup(v_e_241); V a_1 = heff_dup(v_a_244); V a_2 = heff_dup(v_vs_246); V a_3 = v_tags_247; V a_4 = heff_dup(v_z_249); V a_5 = heff_clo_n(g_heff_2eelab_2erules_2ecasesAt_lam1, 1, 11, (V[]){v_vs_246, v_casesChk_248, heff_dup(v_tags_247), v_e_241, v_z_249, v_sp_240, v_b_242, v_a_244, v_part_245, v_scrut_243, v_z_2410}); V r_ = (g_heff_2eelab_2erules_2etagsExposed(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_tags_247); r_; });
}

HeffT2 g_heff_2eelab_2erules_2eupdateInner_24cpr(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), NTAG(TAG_Nil)}});
  }
  case TAG_Cons: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_UpdateTo: {
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_UpdateIn: {
      V v_fs_2410 = heff_field(v_x11_241, 3);
      HeffT2 v_t_2411 = (g_heff_2eelab_2erules_2eupdateInner_24cpr(v_rest_242));
      {
        V v_field_2413 = v_t_2411.f[1];
        int64_t v_tag_2412 = ((int64_t)v_t_2411.f[0]);
        if ((v_tag_2412 == ((int64_t)0ULL))) {
          V v_more_2414 = v_field_2413;
          V v_t_2415 = (g_heff_2eelab_2erules_2eappendP(heff_dup(v_fs_2410), v_more_2414));
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_t_2415}});
        } else {
          heff_drop(v_field_2413);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x11_241)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
Clo g_heff_2eelab_2erules_2edelayAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2edelayAt_entry, 3, 0};

V g_heff_2eelab_2erules_2edelayAt(V v_sp_240, V v_a_241, V v_thunk_242) {
top: ;
  HeffT1 v_t_243 = (g_heff_2eelab_2erules_2edelayAt_24cpr(v_sp_240, v_a_241, v_thunk_242));
  {
    V v_field_244 = v_t_243.f[0];
    return heff_tag_n(TAG_MkSyn, 1, (V[]){v_field_244});
  }
}
V g_heff_2eelab_2erules_2edelayAt_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2erules_2edelayAt(a[0], a1, a[2]); heff_drop(a1); return r;
}