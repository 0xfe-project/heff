// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_AbsConst 8406
#define TAG_Become 65038
#define TAG_CloConst 61868
#define TAG_Describe 2650
#define TAG_Expl 20488
#define TAG_Get 18914
#define TAG_HLocal 25864
#define TAG_Impl 63555
#define TAG_Inst 64617
#define TAG_LSnoc 32613
#define TAG_Left 13886
#define TAG_MkAbs 54862
#define TAG_MkChk 56962
#define TAG_MkClo 57090
#define TAG_MkSyn 7342
#define TAG_MkTyp 8305
#define TAG_Nom 25944
#define TAG_Right 62770
#define TAG_SApp 57081
#define TAG_SCons 58684
#define TAG_SError 24172
#define TAG_SFunction 64505
#define TAG_SLam 1658
#define TAG_SMatch 27203
#define TAG_SpApp 44612
#define TAG_SpId 35501
#define TAG_SpProj 62333
#define TAG_SpSpec 18415
#define TAG_Throw 56084
#define TAG_VDecode 24012
#define TAG_VFixed 12623
#define TAG_VFunction 37316
#define TAG_VOpaque 37311
#define TAG_VPrimArray 11892
#define TAG_VPrimFloat 57621
#define TAG_VPrimInt 4244
#define TAG_VPrimRune 12870
#define TAG_VPrimString 23215
#define TAG_VRecord 10017
#define TAG_VSum 32852
#define TAG_VU 9520
#define LBL_aliases 1464806715
#define LBL_applied 1586106042
#define LBL_bind 9519364
#define LBL_byName 571997869
#define LBL_code 9554612
#define LBL_conclusion 1382344475
#define LBL_globals 352931696
#define LBL_keys 9783995
#define LBL_len 316559
#define LBL_malg 9839318
#define LBL_metas 305145640
#define LBL_msg 317947
#define LBL_name 9869138
#define LBL_names 305943394
#define LBL_note 9882809
#define LBL_scheme 1039154384
#define LBL_scope 310622830
#define LBL_severity 75955546
#define LBL_span 10032145
#define LBL_stx 323761
#define LBL_subgoals 820279267
#define LBL_ty 10476
#define LBL_val 326043
#define LBL_values 1123329101
static uint32_t shape_applied__conclusion__subgoals[] = {LBL_applied, LBL_conclusion, LBL_subgoals};
static uint32_t shape_code__severity__msg__span__note[] = {LBL_code, LBL_severity, LBL_msg, LBL_span, LBL_note};
static uint32_t shape_keys__byName__values[] = {LBL_keys, LBL_byName, LBL_values};
static uint32_t shape_len__names[] = {LBL_len, LBL_names};
static uint32_t shape_stx__val[] = {LBL_stx, LBL_val};
V g_heff_2eelab_2ememoed_2edecode(V);
V g_heff_2eelab_2ememoed_2edecode_entry(V self, V *a);
extern Clo g_heff_2eelab_2ememoed_2edecode_clo;
V g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(V, V);
V g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276_entry(V self, V *a);
extern Clo g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276_clo;
V g_heff_2eelab_2erename_2edescribeKey(V);
V g_heff_2eelab_2erename_2edescribeKey_entry(V self, V *a);
extern Clo g_heff_2eelab_2erename_2edescribeKey_clo;
V g_heff_2eelab_2erename_2efirstAliasOf(V, V);
V g_heff_2eelab_2erename_2efirstAliasOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2erename_2efirstAliasOf_clo;
V g_heff_2eelab_2erename_2erkOf(V);
V g_heff_2eelab_2erename_2erkOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2erename_2erkOf_clo;
V g_heff_2eelab_2erules_2eapartSpines(V, V, V);
V g_heff_2eelab_2erules_2eapartSpines_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eapartSpines_clo;
V g_heff_2eelab_2erules_2ecaseArm(V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2ecaseArm_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2ecaseArm_clo;
V g_heff_2eelab_2erules_2ecasesAt(V, V, V, V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2ecasesAt_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2ecasesAt_clo;
V g_heff_2eelab_2erules_2econclusionOf(V, V);
V g_heff_2eelab_2erules_2econclusionOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2econclusionOf_clo;
V g_heff_2eelab_2erules_2edelayedCheck(V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2edelayedCheck_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2edelayedCheck_clo;
V g_heff_2eelab_2erules_2edescribedBound(V, V);
V g_heff_2eelab_2erules_2edescribedBound_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2edescribedBound_clo;
V g_heff_2eelab_2erules_2edownFrom_24dps(V, V);
V g_heff_2eelab_2erules_2edownFrom_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2edownFrom_24dps_clo;
V g_heff_2eelab_2erules_2eentriesGo(V, V, V, V, V, V);
V g_heff_2eelab_2erules_2eentriesGo_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eentriesGo_clo;
V g_heff_2eelab_2erules_2eindexOfName(V, V, V);
V g_heff_2eelab_2erules_2eindexOfName_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eindexOfName_clo;
V g_heff_2eelab_2erules_2einstantiate(V, V, V);
V g_heff_2eelab_2erules_2einstantiate_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2einstantiate_clo;
V g_heff_2eelab_2erules_2einstantiateGo(V, V, V, V, V);
V g_heff_2eelab_2erules_2einstantiateGo_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2einstantiateGo_clo;
V g_heff_2eelab_2erules_2eletsAround(V, V, V, V, V);
V g_heff_2eelab_2erules_2eletsAround_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eletsAround_clo;
V g_heff_2eelab_2erules_2elettedAt(V, V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2elettedAt_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2elettedAt_clo;
V g_heff_2eelab_2erules_2elookupP(V, V);
V g_heff_2eelab_2erules_2elookupP_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2elookupP_clo;
V g_heff_2eelab_2erules_2eprettyEqErr(V, V);
V g_heff_2eelab_2erules_2eprettyEqErr_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eprettyEqErr_clo;
V g_heff_2eelab_2erules_2erecordTags(V, V, V, V);
V g_heff_2eelab_2erules_2erecordTags_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2erecordTags_clo;
V g_heff_2eelab_2erules_2erigidFormer(V, V);
V g_heff_2eelab_2erules_2erigidFormer_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2erigidFormer_clo;
V g_heff_2eelab_2erules_2esolveHole(V, V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2esolveHole_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2esolveHole_clo;
V g_heff_2eelab_2erules_2especialized(V, V, V, V, V);
V g_heff_2eelab_2erules_2especialized_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2especialized_clo;
V g_heff_2eelab_2erules_2especializedGo(V, V, V, V, V, V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2especializedGo_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2especializedGo_clo;
V g_heff_2eelab_2erules_2etraverseE(V, V);
V g_heff_2eelab_2erules_2etraverseE_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2etraverseE_clo;
V g_heff_2eelab_2erules_2etyStr(V, V);
V g_heff_2eelab_2erules_2etyStr_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2etyStr_clo;
V g_heff_2eelab_2erules_2euniverseAt(V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2euniverseAt_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2euniverseAt_clo;
V g_heff_2eelab_2erules_2euniverseElimSyn(V, V);
V g_heff_2eelab_2erules_2euniverseElimSyn_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2euniverseElimSyn_clo;
V g_heff_2eelab_2erules_2euniverseIntro(V, V);
V g_heff_2eelab_2erules_2euniverseIntro_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2euniverseIntro_clo;
V g_heff_2eelab_2erules_2evaluesGo(V, V, V, V, V);
V g_heff_2eelab_2erules_2evaluesGo_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2evaluesGo_clo;
V g_heff_2eelab_2evalue_2eforceTy(V, V);
V g_heff_2eelab_2evalue_2eforceTy_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eforceTy_clo;
V g_heff_2eelab_2evalue_2elevelOf(V);
V g_heff_2eelab_2evalue_2elevelOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2elevelOf_clo;
V g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(V, V, V, V);
V g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190_clo;
V g_heff_2esyntax_2epsurface_2etyF_24s1393470031x806019530(V, V, V, V);
V g_heff_2esyntax_2epsurface_2etyF_24s1393470031x806019530_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epsurface_2etyF_24s1393470031x806019530_clo;
V g_heff_2eutil_2edict_2eindexed(V, V);
V g_heff_2eutil_2edict_2eindexed_entry(V self, V *a);
extern Clo g_heff_2eutil_2edict_2eindexed_clo;
V g_heff_2eutil_2edict_2ezipKV(V, V);
V g_heff_2eutil_2edict_2ezipKV_entry(V self, V *a);
extern Clo g_heff_2eutil_2edict_2ezipKV_clo;
V g_list_2efoldl_24f1090240733x1330738919(V, V, V);
V g_list_2efoldl_24f1090240733x1330738919_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1090240733x1330738919_clo;
V g_list_2emap_24s1173914895x100384474(V);
V g_list_2emap_24s1173914895x100384474_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_clo;
V g_list_2emap_24s1937570095x2110149801(V);
V g_list_2emap_24s1937570095x2110149801_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_clo;
V g_map_2etoListOnto(V, V);
V g_map_2etoListOnto_entry(V self, V *a);
extern Clo g_map_2etoListOnto_clo;
Clo g_heff_2eelab_2erules_2edownFrom_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2edownFrom_24dps_entry, 2, 0};

V g_heff_2eelab_2erules_2edownFrom_24dps(V v_n_240, V v_d_241) {
top: ;
  if (heff_intLt_c(heff_dup(v_n_240), MK_INT(0LL))) {
    heff_drop(v_n_240);
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  } else {
    V v_cell_243 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_n_240), heff_hole()});
    V v_u_244 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_243));
    heff_drop(v_u_244);
    V t_0 = heff_intSub(v_n_240, MK_INT(1LL));
    V t_1 = v_cell_243;
    v_n_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
}
V g_heff_2eelab_2erules_2edownFrom_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2edownFrom_24dps(a[0], a[1]);
}
V g_heff_2eelab_2erules_2etyStr_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2etyStr_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2etyStr_entry, 2, 0};

V g_heff_2eelab_2erules_2etyStr(V v_e_240, V v_t_241) {
top: ;
  V v_t_242 = heff_get_n(heff_dup(heff_rfield(v_e_240, 0)), 0, 4);
  V v_t_243 = (g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(v_t_242, v_t_241));
  V v_t_2410 = (g_heff_2eelab_2erename_2erkOf(heff_clo_n(g_heff_2eelab_2erules_2etyStr_lam0, 1, 1, (V[]){heff_dup(v_e_240)})));
  V v_t_2411 = heff_tr(heff_call(heff_get_n(v_t_2410, 1, 2), 1, (V[]){v_t_243}));
  V v_t_2412 = heff_get_n(heff_get_n(v_e_240, 0, 6), 1, 4);
  return ({ V a_0 = MK_INT(0LL); V a_1 = MK_INT(0LL); V a_2 = v_t_2412; V a_3 = v_t_2411; V r_ = (g_heff_2esyntax_2epsurface_2etyF_24s1393470031x806019530(a_0, a_1, a_2, a_3)); heff_drop(v_t_2411); r_; });
}
V g_heff_2eelab_2erules_2etyStr_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2etyStr(a[0], a[1]);
}
V g_heff_2eelab_2erules_2etyStr_lam0(V self, V *args) {
  V v_x_244 = args[0];
  V v_e_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_d_245 = (g_heff_2eelab_2erename_2edescribeKey(heff_dup(v_x_244)));
  V v_t_246 = heff_get_n(heff_get_n(v_e_240, 1, 6), 2, 7);
  V v_t_247 = ({ V a_0 = v_t_246; V a_1 = NTAG(TAG_Nil); V r_ = (g_map_2etoListOnto(a_0, a_1)); heff_drop(v_t_246); r_; });
  V v_x2_248 = ({ V a_0 = v_t_247; V a_1 = v_x_244; V r_ = (g_heff_2eelab_2erename_2efirstAliasOf(a_0, a_1)); heff_drop(v_t_247); r_; });
  switch (heff_tag_of(v_x2_248)) {
  case TAG_Nothing: {
    return v_d_245;
  }
  case TAG_Just: {
    V v_x_249 = heff_field(v_x2_248, 0);
    heff_take_n(v_x2_248, 1ULL, 1);
    heff_drop(v_d_245);
    return v_x_249;
  }
  default: return heff_nomatch(v_x2_248);
  }
}
V g_heff_2eelab_2erules_2einstantiate_lam0(V self, V *args);
V g_heff_2eelab_2erules_2einstantiate_lam2(V self, V *args);
V g_heff_2eelab_2erules_2einstantiate_lam1(V self, V *args);
Clo g_heff_2eelab_2erules_2einstantiate_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2einstantiate_entry, 3, 0};

V g_heff_2eelab_2erules_2einstantiate(V v_e_240, V v_sp_241, V v_w_242) {
top: ;
  V v_t_243 = heff_dup(heff_rfield(v_w_242, 2));
  if ((heff_dup(v_t_243) == NTAG(TAG_True))) {
    heff_drop(v_t_243);
    V v_t_245 = heff_rec_n(2, shape_stx__val, (V[]){heff_dup(heff_rfield(v_w_242, 4)), heff_clo_n(g_heff_2eelab_2erules_2einstantiate_lam0, 1, 1, (V[]){heff_dup(v_w_242)})});
    return (g_heff_2eelab_2erules_2einstantiateGo(v_e_240, v_sp_241, v_t_245, heff_get_n(v_w_242, 3, 6), NTAG(TAG_Nil)));
  } else {
    heff_drop(v_e_240);
    heff_drop(v_sp_241);
    heff_drop(v_t_243);
    return heff_clo_n(g_heff_2eelab_2erules_2einstantiate_lam1, 2, 1, (V[]){v_w_242});
  }
}
V g_heff_2eelab_2erules_2einstantiate_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2einstantiate(a[0], a[1], a[2]);
}
V g_heff_2eelab_2erules_2einstantiate_lam0(V self, V *args) {
  V v_u_244 = args[0];
  V v_w_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_244);
  return heff_tag_n(TAG_Nom, 1, (V[]){heff_get_n(v_w_242, 5, 6)});
}
V g_heff_2eelab_2erules_2einstantiate_lam2(V self, V *args) {
  V v_u_248 = args[0];
  V v_w_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_248);
  return heff_tag_n(TAG_Nom, 1, (V[]){heff_get_n(v_w_242, 5, 6)});
}
V g_heff_2eelab_2erules_2einstantiate_lam1(V self, V *args) {
  V v_hd_246 = args[0];
  V v_k_247 = args[1];
  V v_w_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_246);
  V v_t_249 = heff_rec_n(2, shape_stx__val, (V[]){heff_dup(heff_rfield(v_w_242, 4)), heff_clo_n(g_heff_2eelab_2erules_2einstantiate_lam2, 1, 1, (V[]){heff_dup(v_w_242)})});
  V v_t_2410 = heff_rec_n(3, shape_applied__conclusion__subgoals, (V[]){v_t_249, heff_get_n(v_w_242, 3, 6), NTAG(TAG_Nil)});
  V f_ = v_k_247;
  args[0] = v_t_2410;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2econclusionOf_lam1(V self, V *args);
V g_heff_2eelab_2erules_2econclusionOf_lam0(V self, V *args);
V g_heff_2eelab_2erules_2econclusionOf_lam3(V self, V *args);
V g_heff_2eelab_2erules_2econclusionOf_lam2(V self, V *args);
Clo g_heff_2eelab_2erules_2econclusionOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2econclusionOf_entry, 2, 0};

V g_heff_2eelab_2erules_2econclusionOf(V v_n_240, V v_ty_241) {
top: ;
  switch (heff_tag_of(v_ty_241)) {
  case TAG_VU: {
    heff_drop(v_n_240);
    return v_ty_241;
  }
  case TAG_VDecode: {
    heff_drop(v_n_240);
    return v_ty_241;
  }
  case TAG_VFunction: {
    V v_dom_249 = heff_dup(heff_field(v_ty_241, 1));
    V v_cod_2410 = heff_dup(heff_field(v_ty_241, 2));
    V v_it4_2411 = heff_dup(heff_field(v_ty_241, 3));
    switch (heff_tag_of(v_it4_2411)) {
    case TAG_Expl: {
      heff_drop(v_n_240);
      heff_drop(v_dom_249);
      heff_drop(v_cod_2410);
      return v_ty_241;
    }
    case TAG_Impl: {
      heff_drop_tag(v_ty_241, 5);
      V v_x1_2419;
      switch (heff_tag_of(v_cod_2410)) {
      case TAG_MkClo: {
        V v_vs_2414 = heff_field(v_cod_2410, 1);
        V v_body_2415 = heff_field(v_cod_2410, 2);
        heff_take_n(v_cod_2410, 6ULL, 3);
        v_x1_2419 = heff_tr(heff_call(v_body_2415, 1, (V[]){heff_tag_n(TAG_LSnoc, 2, (V[]){v_vs_2414, heff_clo_n(g_heff_2eelab_2erules_2econclusionOf_lam0, 1, 2, (V[]){heff_dup(v_n_240), v_dom_249})})}));
        break;
      }
      case TAG_CloConst: {
        V v_body_2418 = heff_field(v_cod_2410, 0);
        heff_take_n(v_cod_2410, 1ULL, 1);
        heff_drop(v_dom_249);
        v_x1_2419 = v_body_2418;
        break;
      }
      default: heff_nomatch(v_cod_2410);
      }
      V v_t_2423;
      switch (heff_tag_of(v_x1_2419)) {
      case TAG_Nom: {
        V v_x_2420 = heff_field(v_x1_2419, 0);
        heff_take_n(v_x1_2419, 1ULL, 1);
        v_t_2423 = v_x_2420;
        break;
      }
      case TAG_Describe: {
        heff_take_n(v_x1_2419, 0ULL, 1);
        v_t_2423 = heff_abandon();
        break;
      }
      case TAG_Become: {
        V v_x_2422 = heff_field(v_x1_2419, 0);
        heff_take_n(v_x1_2419, 1ULL, 1);
        v_t_2423 = v_x_2422;
        break;
      }
      default: heff_nomatch(v_x1_2419);
      }
      V t_0 = heff_intAdd(v_n_240, MK_INT(1LL));
      V t_1 = v_t_2423;
      v_n_240 = t_0;
      v_ty_241 = t_1;
      goto top;
    }
    case TAG_Inst: {
      heff_drop_tag(v_ty_241, 5);
      V v_x1_2430;
      switch (heff_tag_of(v_cod_2410)) {
      case TAG_MkClo: {
        V v_vs_2425 = heff_field(v_cod_2410, 1);
        V v_body_2426 = heff_field(v_cod_2410, 2);
        heff_take_n(v_cod_2410, 6ULL, 3);
        v_x1_2430 = heff_tr(heff_call(v_body_2426, 1, (V[]){heff_tag_n(TAG_LSnoc, 2, (V[]){v_vs_2425, heff_clo_n(g_heff_2eelab_2erules_2econclusionOf_lam2, 1, 2, (V[]){heff_dup(v_n_240), v_dom_249})})}));
        break;
      }
      case TAG_CloConst: {
        V v_body_2429 = heff_field(v_cod_2410, 0);
        heff_take_n(v_cod_2410, 1ULL, 1);
        heff_drop(v_dom_249);
        v_x1_2430 = v_body_2429;
        break;
      }
      default: heff_nomatch(v_cod_2410);
      }
      V v_t_2434;
      switch (heff_tag_of(v_x1_2430)) {
      case TAG_Nom: {
        V v_x_2431 = heff_field(v_x1_2430, 0);
        heff_take_n(v_x1_2430, 1ULL, 1);
        v_t_2434 = v_x_2431;
        break;
      }
      case TAG_Describe: {
        heff_take_n(v_x1_2430, 0ULL, 1);
        v_t_2434 = heff_abandon();
        break;
      }
      case TAG_Become: {
        V v_x_2433 = heff_field(v_x1_2430, 0);
        heff_take_n(v_x1_2430, 1ULL, 1);
        v_t_2434 = v_x_2433;
        break;
      }
      default: heff_nomatch(v_x1_2430);
      }
      V t_0 = heff_intAdd(v_n_240, MK_INT(1LL));
      V t_1 = v_t_2434;
      v_n_240 = t_0;
      v_ty_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_it4_2411);
    }
  }
  case TAG_VRecord: {
    heff_drop(v_n_240);
    return v_ty_241;
  }
  case TAG_VSum: {
    heff_drop(v_n_240);
    return v_ty_241;
  }
  case TAG_VPrimInt: {
    heff_drop(v_n_240);
    return v_ty_241;
  }
  case TAG_VPrimFloat: {
    heff_drop(v_n_240);
    return v_ty_241;
  }
  case TAG_VPrimString: {
    heff_drop(v_n_240);
    return v_ty_241;
  }
  case TAG_VPrimRune: {
    heff_drop(v_n_240);
    return v_ty_241;
  }
  case TAG_VPrimArray: {
    heff_drop(v_n_240);
    return v_ty_241;
  }
  case TAG_VFixed: {
    heff_drop(v_n_240);
    return v_ty_241;
  }
  default: return heff_nomatch(v_ty_241);
  }
}
V g_heff_2eelab_2erules_2econclusionOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2econclusionOf(a[0], a[1]);
}
V g_heff_2eelab_2erules_2econclusionOf_lam1(V self, V *args) {
  V v_u_2417 = args[0];
  V v_dom_249 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2417);
  return v_dom_249;
}
V g_heff_2eelab_2erules_2econclusionOf_lam0(V self, V *args) {
  V v_u_2416 = args[0];
  V v_n_240 = heff_env(self)[0];
  V v_dom_249 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_u_2416);
  return (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(heff_tag_n(TAG_HLocal, 1, (V[]){v_n_240}), NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2erules_2econclusionOf_lam1, 1, 1, (V[]){v_dom_249}), NTAG(TAG_Nothing)));
}
V g_heff_2eelab_2erules_2econclusionOf_lam3(V self, V *args) {
  V v_u_2428 = args[0];
  V v_dom_249 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2428);
  return v_dom_249;
}
V g_heff_2eelab_2erules_2econclusionOf_lam2(V self, V *args) {
  V v_u_2427 = args[0];
  V v_n_240 = heff_env(self)[0];
  V v_dom_249 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_u_2427);
  return (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(heff_tag_n(TAG_HLocal, 1, (V[]){v_n_240}), NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2erules_2econclusionOf_lam3, 1, 1, (V[]){v_dom_249}), NTAG(TAG_Nothing)));
}
Clo g_heff_2eelab_2erules_2eapartSpines_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eapartSpines_entry, 3, 0};

V g_heff_2eelab_2erules_2eapartSpines(V v_mc_240, V v_x2_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_SpId: {
    return NTAG(TAG_False);
  }
  case TAG_SpApp: {
    V v_sp_243 = heff_field(v_x2_241, 0);
    V v_a_244 = heff_field(v_x2_241, 1);
    switch (heff_tag_of(v_x3_242)) {
    case TAG_SpId: {
      return NTAG(TAG_False);
    }
    case TAG_SpApp: {
      V v_sp2_245 = heff_field(v_x3_242, 0);
      V v_b_246 = heff_field(v_x3_242, 1);
      V v_t_247 = (g_heff_2eelab_2erules_2erigidFormer(v_mc_240, heff_dup(v_a_244)));
      switch (heff_tag_of(v_t_247)) {
      case TAG_Nothing: {
        V t_0 = v_mc_240;
        V t_1 = v_sp_243;
        V t_2 = v_sp2_245;
        v_mc_240 = t_0;
        v_x2_241 = t_1;
        v_x3_242 = t_2;
        goto top;
      }
      case TAG_Just: {
        V v_k_248 = heff_field(v_t_247, 0);
        heff_take_n(v_t_247, 1ULL, 1);
        V v_t_249 = (g_heff_2eelab_2erules_2erigidFormer(v_mc_240, heff_dup(v_b_246)));
        switch (heff_tag_of(v_t_249)) {
        case TAG_Nothing: {
          heff_drop(v_k_248);
          V t_0 = v_mc_240;
          V t_1 = v_sp_243;
          V t_2 = v_sp2_245;
          v_mc_240 = t_0;
          v_x2_241 = t_1;
          v_x3_242 = t_2;
          goto top;
        }
        case TAG_Just: {
          V v_k2_2410 = heff_field(v_t_249, 0);
          heff_take_n(v_t_249, 1ULL, 1);
          if (heff_strEq_c(v_k_248, v_k2_2410)) {
            V t_0 = v_mc_240;
            V t_1 = v_sp_243;
            V t_2 = v_sp2_245;
            v_mc_240 = t_0;
            v_x2_241 = t_1;
            v_x3_242 = t_2;
            goto top;
          } else {
            return NTAG(TAG_True);
          }
        }
        default: return heff_nomatch(v_t_249);
        }
      }
      default: return heff_nomatch(v_t_247);
      }
    }
    case TAG_SpProj: {
      return NTAG(TAG_False);
    }
    case TAG_SpSpec: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x3_242);
    }
  }
  case TAG_SpProj: {
    return NTAG(TAG_False);
  }
  case TAG_SpSpec: {
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eelab_2erules_2eapartSpines_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V r = g_heff_2eelab_2erules_2eapartSpines(a0, a1, a2); heff_drop(a0); heff_drop(a1); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2eelab_2erules_2edelayedCheck_str0, 5, "this ");
HEFF_LIT(g_heff_2eelab_2erules_2edelayedCheck_str1, 28, " does not fit how it is used");
V g_heff_2eelab_2erules_2edelayedCheck_lam2(V self, V *args);
V g_heff_2eelab_2erules_2edelayedCheck_lam1(V self, V *args);
V g_heff_2eelab_2erules_2edelayedCheck_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2edelayedCheck_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2edelayedCheck_entry, 7, 0};

V g_heff_2eelab_2erules_2edelayedCheck(V v_e_240, V v_sp_241, V v_what_242, V v_c_243, V v_ty_244, V v_m_245, V v_hole_246) {
top: ;
  V v_c_248;
  switch (heff_tag_of(v_c_243)) {
  case TAG_MkChk: {
    V v_f_247 = heff_field(v_c_243, 0);
    v_c_248 = heff_tr(heff_call(heff_dup(v_f_247), 2, (V[]){heff_dup(v_e_240), v_ty_244}));
    break;
  }
  default: heff_nomatch(v_c_243);
  }
  return heff_clo_n(g_heff_2eelab_2erules_2edelayedCheck_lam0, 2, 6, (V[]){v_c_248, v_e_240, v_m_245, v_hole_246, v_what_242, v_sp_241});
}
V g_heff_2eelab_2erules_2edelayedCheck_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2eelab_2erules_2edelayedCheck(a[0], a[1], a[2], a3, a[4], a[5], a[6]); heff_drop(a3); return r;
}
V g_heff_2eelab_2erules_2edelayedCheck_lam2(V self, V *args) {
  V v_x_2419 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_what_242 = heff_env(self)[1];
  V v_sp_241 = heff_env(self)[2];
  V v_hd_249 = heff_env(self)[3];
  V v_k_2410 = heff_env(self)[4];
  heff_clo_take(self, 5);
  switch (heff_tag_of(v_x_2419)) {
  case TAG_Left: {
    V v_err_2420 = heff_field(v_x_2419, 0);
    V v_ru_24x_2419_24Left = heff_take_reuse_n(v_x_2419, 1ULL, 1);
    V v_note_2421 = ({ V a_0 = heff_get_n(v_e_240, 1, 6); V a_1 = v_err_2420; V r_ = (g_heff_2eelab_2erules_2eprettyEqErr(a_0, a_1)); heff_drop(v_err_2420); r_; });
    V v_t_2422 = heff_strAppend(((V)&g_heff_2eelab_2erules_2edelayedCheck_str0), heff_strAppend(v_what_242, ((V)&g_heff_2eelab_2erules_2edelayedCheck_str1)));
    V v_t_2423 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(311LL), NTAG(TAG_SError), v_t_2422, v_sp_241, heff_tag_n(TAG_Just, 1, (V[]){v_note_2421})});
    V v_t_2424 = heff_tag_at_n(v_ru_24x_2419_24Left, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2423})});
    V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
    V v_t_2426 = heff_tr(heff_call(heff_take_field(v_hd_249, 2), 1, (V[]){v_t_2425}));
    V f_ = heff_get_n(v_hd_249, 1, 3);
    heff_room[0] = v_t_2426;
    heff_room[1] = v_k_2410;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_Right: {
    heff_take_n(v_x_2419, 0ULL, 1);
    heff_drop_rec(v_e_240, 6);
    heff_drop(v_what_242);
    heff_drop(v_sp_241);
    heff_drop_rec(v_hd_249, 3);
    V f_ = v_k_2410;
    args[0] = NTAG(TAG_MkUnit);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_2419);
  }
}
V g_heff_2eelab_2erules_2edelayedCheck_lam1(V self, V *args) {
  V v_x_2411 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_m_245 = heff_env(self)[1];
  V v_hole_246 = heff_env(self)[2];
  V v_hd_249 = heff_env(self)[3];
  V v_what_242 = heff_env(self)[4];
  V v_sp_241 = heff_env(self)[5];
  V v_k_2410 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_c_2412 = heff_dup(heff_rfield(v_e_240, 0));
  V v_x1_2413 = heff_tr(heff_call(heff_take_field(v_x_2411, 1), 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_t_2417;
  switch (heff_tag_of(v_x1_2413)) {
  case TAG_Nom: {
    V v_x_2414 = heff_field(v_x1_2413, 0);
    heff_take_n(v_x1_2413, 1ULL, 1);
    v_t_2417 = v_x_2414;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2413, 0ULL, 1);
    v_t_2417 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2416 = heff_field(v_x1_2413, 0);
    heff_take_n(v_x1_2413, 1ULL, 1);
    v_t_2417 = v_x_2416;
    break;
  }
  default: heff_nomatch(v_x1_2413);
  }
  V v_t_2418 = heff_rec_n(2, shape_len__names, (V[]){heff_take_field(v_c_2412, 0), heff_get_n(v_c_2412, 1, 4)});
  return (g_heff_2eelab_2erules_2esolveHole(heff_dup(heff_rfield(v_e_240, 1)), v_t_2418, v_m_245, heff_get_n(v_hole_246, 1, 2), heff_get_n(v_x_2411, 0, 2), v_t_2417, heff_dup(v_hd_249), heff_clo_n(g_heff_2eelab_2erules_2edelayedCheck_lam2, 1, 5, (V[]){v_e_240, v_what_242, v_sp_241, v_hd_249, v_k_2410})));
}
V g_heff_2eelab_2erules_2edelayedCheck_lam0(V self, V *args) {
  V v_hd_249 = args[0];
  V v_k_2410 = args[1];
  V v_c_248 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_m_245 = heff_env(self)[2];
  V v_hole_246 = heff_env(self)[3];
  V v_what_242 = heff_env(self)[4];
  V v_sp_241 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V f_ = v_c_248;
  args[0] = heff_dup(v_hd_249);
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2edelayedCheck_lam1, 1, 7, (V[]){v_e_240, v_m_245, v_hole_246, v_hd_249, v_what_242, v_sp_241, v_k_2410});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2especialized_lam0(V self, V *args);
V g_heff_2eelab_2erules_2especialized_lam1(V self, V *args);
V g_heff_2eelab_2erules_2especialized_lam2(V self, V *args);
V g_heff_2eelab_2erules_2especialized_lam3(V self, V *args);
V g_heff_2eelab_2erules_2especialized_lam4(V self, V *args);
V g_heff_2eelab_2erules_2especialized_lam5(V self, V *args);
V g_heff_2eelab_2erules_2especialized_lam6(V self, V *args);
V g_heff_2eelab_2erules_2especialized_lam7(V self, V *args);
V g_heff_2eelab_2erules_2especialized_lam8(V self, V *args);
V g_heff_2eelab_2erules_2especialized_lam9(V self, V *args);
Clo g_heff_2eelab_2erules_2especialized_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2especialized_entry, 5, 0};

V g_heff_2eelab_2erules_2especialized(V v_e_240, V v_v_241, V v_a_242, V v_a_27_243, V v_err_244) {
top: ;
  switch (heff_tag_of(v_a_242)) {
  case TAG_VU: {
    heff_drop(v_e_240);
    heff_drop(v_v_241);
    heff_drop(v_a_27_243);
    return heff_clo_n(g_heff_2eelab_2erules_2especialized_lam0, 2, 1, (V[]){v_err_244});
  }
  case TAG_VDecode: {
    V v_h_248 = heff_field(v_a_242, 0);
    V v_sp_249 = heff_field(v_a_242, 1);
    V v_u_2410 = heff_field(v_a_242, 2);
    V v_described_2411 = heff_field(v_a_242, 3);
    V v_el_2412 = heff_field(v_a_242, 4);
    return heff_tail(((V)&g_heff_2eelab_2erules_2especializedGo_clo), 10, (V[]){v_e_240, v_v_241, v_a_27_243, heff_dup(v_h_248), heff_dup(v_sp_249), heff_dup(v_u_2410), heff_dup(v_described_2411), heff_dup(v_el_2412), NTAG(TAG_Nil), v_err_244});
  }
  case TAG_VFunction: {
    heff_drop(v_e_240);
    heff_drop(v_v_241);
    heff_drop(v_a_27_243);
    return heff_clo_n(g_heff_2eelab_2erules_2especialized_lam1, 2, 1, (V[]){v_err_244});
  }
  case TAG_VRecord: {
    heff_drop(v_e_240);
    heff_drop(v_v_241);
    heff_drop(v_a_27_243);
    return heff_clo_n(g_heff_2eelab_2erules_2especialized_lam2, 2, 1, (V[]){v_err_244});
  }
  case TAG_VSum: {
    heff_drop(v_e_240);
    heff_drop(v_v_241);
    heff_drop(v_a_27_243);
    return heff_clo_n(g_heff_2eelab_2erules_2especialized_lam3, 2, 1, (V[]){v_err_244});
  }
  case TAG_VPrimInt: {
    heff_drop(v_e_240);
    heff_drop(v_v_241);
    heff_drop(v_a_27_243);
    return heff_clo_n(g_heff_2eelab_2erules_2especialized_lam4, 2, 1, (V[]){v_err_244});
  }
  case TAG_VPrimFloat: {
    heff_drop(v_e_240);
    heff_drop(v_v_241);
    heff_drop(v_a_27_243);
    return heff_clo_n(g_heff_2eelab_2erules_2especialized_lam5, 2, 1, (V[]){v_err_244});
  }
  case TAG_VPrimString: {
    heff_drop(v_e_240);
    heff_drop(v_v_241);
    heff_drop(v_a_27_243);
    return heff_clo_n(g_heff_2eelab_2erules_2especialized_lam6, 2, 1, (V[]){v_err_244});
  }
  case TAG_VPrimRune: {
    heff_drop(v_e_240);
    heff_drop(v_v_241);
    heff_drop(v_a_27_243);
    return heff_clo_n(g_heff_2eelab_2erules_2especialized_lam7, 2, 1, (V[]){v_err_244});
  }
  case TAG_VPrimArray: {
    heff_drop(v_e_240);
    heff_drop(v_v_241);
    heff_drop(v_a_27_243);
    return heff_clo_n(g_heff_2eelab_2erules_2especialized_lam8, 2, 1, (V[]){v_err_244});
  }
  case TAG_VFixed: {
    heff_drop(v_e_240);
    heff_drop(v_v_241);
    heff_drop(v_a_27_243);
    return heff_clo_n(g_heff_2eelab_2erules_2especialized_lam9, 2, 1, (V[]){v_err_244});
  }
  default: return heff_nomatch(v_a_242);
  }
}
V g_heff_2eelab_2erules_2especialized_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2eelab_2erules_2especialized(a[0], a[1], a2, a[3], a[4]); heff_drop(a2); return r;
}
V g_heff_2eelab_2erules_2especialized_lam0(V self, V *args) {
  V v_hd_246 = args[0];
  V v_k_247 = args[1];
  V v_err_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_246);
  V f_ = v_k_247;
  args[0] = v_err_244;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2especialized_lam1(V self, V *args) {
  V v_hd_2418 = args[0];
  V v_k_2419 = args[1];
  V v_err_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2418);
  V f_ = v_k_2419;
  args[0] = v_err_244;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2especialized_lam2(V self, V *args) {
  V v_hd_2424 = args[0];
  V v_k_2425 = args[1];
  V v_err_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2424);
  V f_ = v_k_2425;
  args[0] = v_err_244;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2especialized_lam3(V self, V *args) {
  V v_hd_2427 = args[0];
  V v_k_2428 = args[1];
  V v_err_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2427);
  V f_ = v_k_2428;
  args[0] = v_err_244;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2especialized_lam4(V self, V *args) {
  V v_hd_2429 = args[0];
  V v_k_2430 = args[1];
  V v_err_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2429);
  V f_ = v_k_2430;
  args[0] = v_err_244;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2especialized_lam5(V self, V *args) {
  V v_hd_2431 = args[0];
  V v_k_2432 = args[1];
  V v_err_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2431);
  V f_ = v_k_2432;
  args[0] = v_err_244;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2especialized_lam6(V self, V *args) {
  V v_hd_2433 = args[0];
  V v_k_2434 = args[1];
  V v_err_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2433);
  V f_ = v_k_2434;
  args[0] = v_err_244;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2especialized_lam7(V self, V *args) {
  V v_hd_2435 = args[0];
  V v_k_2436 = args[1];
  V v_err_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2435);
  V f_ = v_k_2436;
  args[0] = v_err_244;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2especialized_lam8(V self, V *args) {
  V v_hd_2438 = args[0];
  V v_k_2439 = args[1];
  V v_err_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2438);
  V f_ = v_k_2439;
  args[0] = v_err_244;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2especialized_lam9(V self, V *args) {
  V v_hd_2441 = args[0];
  V v_k_2442 = args[1];
  V v_err_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2441);
  V f_ = v_k_2442;
  args[0] = v_err_244;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
Clo g_heff_2eelab_2erules_2elookupP_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2elookupP_entry, 2, 0};

V g_heff_2eelab_2erules_2elookupP(V v_x1_240, V v_x_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_x_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_x11_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_MkPair: {
      V v_y_244 = heff_field(v_x11_242, 0);
      V v_v_245 = heff_field(v_x11_242, 1);
      if (heff_strEq_c(heff_dup(v_y_244), heff_dup(v_x_241))) {
        heff_drop(v_x_241);
        return heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_v_245)});
      } else {
        V t_0 = v_rest_243;
        V t_1 = v_x_241;
        v_x1_240 = t_0;
        v_x_241 = t_1;
        goto top;
      }
    }
    default: return heff_nomatch(v_x11_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2erules_2elookupP_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2erules_2elookupP(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2eelab_2erules_2eletsAround_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eletsAround_entry, 5, 0};

V g_heff_2eelab_2erules_2eletsAround(V v_n_240, V v_a_241, V v_x3_242, V v_p_243, V v_body_244) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_n_240);
    heff_drop(v_a_241);
    heff_drop(v_p_243);
    return v_body_244;
  }
  case TAG_Cons: {
    V v_x31_245 = heff_field(v_x3_242, 0);
    V v_rest_246 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    switch (heff_tag_of(v_x31_245)) {
    case TAG_MkPair: {
      V v_m_247 = heff_field(v_x31_245, 0);
      V v_v_248 = heff_field(v_x31_245, 1);
      V v_ru_24x31_245_24MkPair = heff_take_reuse_n(v_x31_245, 3ULL, 2);
      V v_t_249 = (g_heff_2eelab_2evalue_2elevelOf(v_a_241));
      V v_t_2410 = (g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(heff_intAdd(heff_dup(v_n_240), heff_dup(v_p_243)), heff_take_field(v_m_247, 1)));
      V v_t_2411 = (g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(heff_intAdd(heff_dup(v_n_240), heff_dup(v_p_243)), heff_dup(v_a_241)));
      V v_t_2412 = heff_tag_n(TAG_SFunction, 5, (V[]){v_t_249, v_t_2410, heff_tag_n(TAG_AbsConst, 1, (V[]){v_t_2411}), NTAG(TAG_Expl), NTAG(TAG_Nothing)});
      V v_t_2413 = (g_heff_2eelab_2erules_2eletsAround(v_n_240, v_a_241, v_rest_246, heff_intAdd(v_p_243, MK_INT(1LL)), v_body_244));
      V v_t_2414 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_MkAbs, 2, (V[]){heff_get_n(v_m_247, 0, 5), v_t_2413});
      return heff_tag_at_n(v_ru_24x31_245_24MkPair, TAG_SApp, 2, (V[]){heff_tag_n(TAG_SLam, 2, (V[]){v_t_2412, v_t_2414}), v_v_248});
    }
    default: return heff_nomatch(v_x31_245);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2eelab_2erules_2eletsAround_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2eletsAround(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2eelab_2erules_2elettedAt_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2elettedAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2elettedAt_entry, 8, 0};

V g_heff_2eelab_2erules_2elettedAt(V v_e_240, V v_a_241, V v_made_242, V v_record_243, V v_bound_244, V v_places_245, V v_z_246, V v_z_247) {
top: ;
  V v_c_248 = (g_heff_2eelab_2erules_2edescribedBound(v_made_242, v_bound_244));
  return heff_tail(v_c_248, 2, (V[]){v_z_246, heff_clo_n(g_heff_2eelab_2erules_2elettedAt_lam0, 1, 7, (V[]){v_e_240, v_places_245, v_made_242, heff_dup(v_bound_244), v_a_241, v_record_243, v_z_247})});
}
V g_heff_2eelab_2erules_2elettedAt_entry(V self, V *a) {
  (void)self;
  V a4 = a[4]; V r = g_heff_2eelab_2erules_2elettedAt(a[0], a[1], a[2], a[3], a4, a[5], a[6], a[7]); heff_drop(a4); return r;
}
V g_heff_2eelab_2erules_2elettedAt_lam0(V self, V *args) {
  V v_x_249 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_places_245 = heff_env(self)[1];
  V v_made_242 = heff_env(self)[2];
  V v_bound_244 = heff_env(self)[3];
  V v_a_241 = heff_env(self)[4];
  V v_record_243 = heff_env(self)[5];
  V v_z_247 = heff_env(self)[6];
  heff_clo_take(self, 7);
  heff_drop(v_x_249);
  V v_t_2410 = heff_get_n(heff_dup(heff_rfield(v_e_240, 0)), 0, 4);
  V v_t_2411 = heff_get_n(heff_dup(heff_rfield(v_e_240, 0)), 0, 4);
  V v_t_2412 = (g_heff_2eelab_2erules_2evaluesGo(v_t_2411, heff_dup(v_places_245), heff_dup(v_made_242), heff_dup(v_places_245), MK_INT(0LL)));
  V v_t_2413 = heff_get_n(heff_get_n(v_e_240, 0, 6), 0, 4);
  V v_t_2414 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_bound_244; V r_ = (g_list_2efoldl_24f1090240733x1330738919(a_0, a_1, a_2)); heff_drop(v_bound_244); r_; });
  V v_pairs_2415 = (g_heff_2eelab_2erules_2eentriesGo(v_t_2413, v_t_2414, heff_dup(v_places_245), v_made_242, v_places_245, MK_INT(0LL)));
  V v_t_2416 = (g_list_2emap_24s1937570095x2110149801(heff_dup(v_pairs_2415)));
  V v_t_2417 = (g_heff_2eutil_2edict_2eindexed(MK_INT(0LL), v_pairs_2415));
  V v_t_2418 = (g_list_2emap_24s1173914895x100384474(v_pairs_2415));
  V v_t_2419 = heff_rec_n(3, shape_keys__byName__values, (V[]){heff_arrayFromList(v_t_2416), v_t_2417, heff_arrayFromList(v_t_2418)});
  V v_t_2420 = (g_heff_2eelab_2erules_2eletsAround(v_t_2410, v_a_241, v_t_2412, MK_INT(0LL), heff_tag_n(TAG_SCons, 1, (V[]){v_t_2419})));
  V v_x_2421 = ({ V rv_0 = v_t_2420; V rr_ = heff_rec_reuse_nf(v_record_243, 2ULL, 2, shape_stx__val, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
  V f_ = v_z_247;
  args[0] = v_x_2421;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2ecasesAt_lam1(V self, V *args);
V g_heff_2eelab_2erules_2ecasesAt_lam3(V self, V *args); static Clo g_heff_2eelab_2erules_2ecasesAt_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2ecasesAt_lam3, 1, 0};
V g_heff_2eelab_2erules_2ecasesAt_lam2(V self, V *args);
V g_heff_2eelab_2erules_2ecasesAt_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2ecasesAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2ecasesAt_entry, 10, 0};

V g_heff_2eelab_2erules_2ecasesAt(V v_sp_240, V v_e_241, V v_b_242, V v_scrut_243, V v_a_244, V v_vs_245, V v_tags_246, V v_casesChk_247, V v_z_248, V v_z_249) {
top: ;
  V v_c_2410 = (g_heff_2eelab_2erules_2erecordTags(heff_dup(v_e_241), heff_dup(v_a_244), heff_dup(v_vs_245), v_tags_246));
  return heff_tail(v_c_2410, 2, (V[]){heff_dup(v_z_248), heff_clo_n(g_heff_2eelab_2erules_2ecasesAt_lam0, 1, 9, (V[]){v_vs_245, v_sp_240, v_e_241, v_b_242, v_a_244, v_casesChk_247, v_z_248, v_scrut_243, v_z_249})});
}
V g_heff_2eelab_2erules_2ecasesAt_entry(V self, V *a) {
  (void)self;
  V a6 = a[6]; V r = g_heff_2eelab_2erules_2ecasesAt(a[0], a[1], a[2], a[3], a[4], a[5], a6, a[7], a[8], a[9]); heff_drop(a6); return r;
}
V g_heff_2eelab_2erules_2ecasesAt_lam1(V self, V *args) {
  V v_p_2415 = args[0];
  V v_sp_240 = heff_env(self)[0];
  V v_e_241 = heff_env(self)[1];
  V v_b_242 = heff_env(self)[2];
  V v_a_244 = heff_env(self)[3];
  V v_casesChk_247 = heff_env(self)[4];
  heff_clo_take(self, 5);
  switch (heff_tag_of(v_p_2415)) {
  case TAG_MkPair: {
    V v_x_2416 = heff_field(v_p_2415, 0);
    V v_ts_2417 = heff_field(v_p_2415, 1);
    heff_take_n(v_p_2415, 3ULL, 2);
    return ({ V a_0 = v_sp_240; V a_1 = v_e_241; V a_2 = v_b_242; V a_3 = v_a_244; V a_4 = v_x_2416; V a_5 = heff_arrayToList(v_ts_2417); V a_6 = v_casesChk_247; V r_ = (g_heff_2eelab_2erules_2ecaseArm(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_a_244); r_; });
  }
  default: return heff_nomatch(v_p_2415);
  }
}
V g_heff_2eelab_2erules_2ecasesAt_lam3(V self, V *args) {
  V v_u_2425 = args[0];
  heff_drop(v_u_2425);
  return heff_tag_n(TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
}
V g_heff_2eelab_2erules_2ecasesAt_lam2(V self, V *args) {
  V v_x_2419 = args[0];
  V v_scrut_243 = heff_env(self)[0];
  V v_z_249 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2420 = (g_list_2emap_24s1937570095x2110149801(heff_dup(v_x_2419)));
  V v_t_2421 = (g_heff_2eutil_2edict_2eindexed(MK_INT(0LL), v_x_2419));
  V v_t_2422 = (g_list_2emap_24s1173914895x100384474(v_x_2419));
  V v_cases_2423 = heff_rec_n(3, shape_keys__byName__values, (V[]){heff_arrayFromList(v_t_2420), v_t_2421, heff_arrayFromList(v_t_2422)});
  V v_t_2424 = heff_tag_n(TAG_SMatch, 2, (V[]){heff_get_n(v_scrut_243, 0, 2), v_cases_2423});
  V f_ = v_z_249;
  args[0] = heff_rec_n(2, shape_stx__val, (V[]){v_t_2424, ((V)&g_heff_2eelab_2erules_2ecasesAt_lam3_clo)});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2ecasesAt_lam0(V self, V *args) {
  V v_x_2411 = args[0];
  V v_vs_245 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  V v_e_241 = heff_env(self)[2];
  V v_b_242 = heff_env(self)[3];
  V v_a_244 = heff_env(self)[4];
  V v_casesChk_247 = heff_env(self)[5];
  V v_z_248 = heff_env(self)[6];
  V v_scrut_243 = heff_env(self)[7];
  V v_z_249 = heff_env(self)[8];
  heff_clo_take(self, 9);
  heff_drop(v_x_2411);
  V v_t_2412 = heff_arrayToList(heff_take_field(v_vs_245, 0));
  V v_t_2413 = heff_arrayToList(heff_get_n(v_vs_245, 2, 3));
  V v_t_2414 = (g_heff_2eutil_2edict_2ezipKV(v_t_2412, v_t_2413));
  V v_c_2418 = (g_heff_2eelab_2erules_2etraverseE(heff_clo_n(g_heff_2eelab_2erules_2ecasesAt_lam1, 1, 5, (V[]){v_sp_240, v_e_241, v_b_242, v_a_244, v_casesChk_247}), v_t_2414));
  V f_ = v_c_2418;
  heff_room[0] = v_z_248;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2ecasesAt_lam2, 1, 2, (V[]){v_scrut_243, v_z_249});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2euniverseIntro_lam1(V self, V *args);
V g_heff_2eelab_2erules_2euniverseIntro_lam3(V self, V *args);
V g_heff_2eelab_2erules_2euniverseIntro_lam2(V self, V *args);
V g_heff_2eelab_2erules_2euniverseIntro_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2euniverseIntro_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2euniverseIntro_entry, 2, 0};

V g_heff_2eelab_2erules_2euniverseIntro(V v_sp_240, V v_typ_241) {
top: ;
  return heff_tag_n(TAG_MkChk, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2euniverseIntro_lam0, 4, 2, (V[]){heff_dup(v_typ_241), v_sp_240})});
}
V g_heff_2eelab_2erules_2euniverseIntro_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2erules_2euniverseIntro(a[0], a1); heff_drop(a1); return r;
}
V g_heff_2eelab_2erules_2euniverseIntro_lam1(V self, V *args) {
  V v_c_246 = args[0];
  V v_a0_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_c_246, 3, 8); V a_1 = v_a0_243; V r_ = (g_heff_2eelab_2evalue_2eforceTy(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2eelab_2erules_2euniverseIntro_lam3(V self, V *args) {
  V v_x_2413 = args[0];
  V v_sp_240 = heff_env(self)[0];
  V v_e_242 = heff_env(self)[1];
  V v_x_2410 = heff_env(self)[2];
  V v_hd_244 = heff_env(self)[3];
  V v_k_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2eelab_2erules_2euniverseAt(v_sp_240, NTAG(TAG_Nothing), v_e_242, v_x_2410, v_x_2413, v_hd_244, v_k_245));
}
V g_heff_2eelab_2erules_2euniverseIntro_lam2(V self, V *args) {
  V v_x_2410 = args[0];
  V v_typ_241 = heff_env(self)[0];
  V v_e_242 = heff_env(self)[1];
  V v_hd_244 = heff_env(self)[2];
  V v_sp_240 = heff_env(self)[3];
  V v_k_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_c_2412;
  switch (heff_tag_of(v_typ_241)) {
  case TAG_MkTyp: {
    V v_f_2411 = heff_field(v_typ_241, 0);
    heff_take_n(v_typ_241, 1ULL, 1);
    v_c_2412 = heff_tr(heff_call(v_f_2411, 1, (V[]){heff_dup(v_e_242)}));
    break;
  }
  default: heff_nomatch(v_typ_241);
  }
  V f_ = v_c_2412;
  heff_room[0] = heff_dup(v_hd_244);
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2euniverseIntro_lam3, 1, 5, (V[]){v_sp_240, v_e_242, v_x_2410, v_hd_244, v_k_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2euniverseIntro_lam0(V self, V *args) {
  V v_e_242 = args[0];
  V v_a0_243 = args[1];
  V v_hd_244 = args[2];
  V v_k_245 = args[3];
  V v_typ_241 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2euniverseIntro_lam1, 1, 1, (V[]){v_a0_243})})});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_244, 2)), 1, (V[]){v_t_248}));
  V f_ = heff_dup(heff_rfield(v_hd_244, 1));
  args[0] = v_t_249;
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2euniverseIntro_lam2, 1, 5, (V[]){v_typ_241, v_e_242, v_hd_244, v_sp_240, v_k_245});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2eelab_2erules_2euniverseElimSyn_str0, 45, "cannot decode an element of non-universe type");
HEFF_LIT(g_heff_2eelab_2erules_2euniverseElimSyn_str1, 45, "cannot decode an element of non-universe type");
HEFF_LIT(g_heff_2eelab_2erules_2euniverseElimSyn_str2, 45, "cannot decode an element of non-universe type");
HEFF_LIT(g_heff_2eelab_2erules_2euniverseElimSyn_str3, 45, "cannot decode an element of non-universe type");
HEFF_LIT(g_heff_2eelab_2erules_2euniverseElimSyn_str4, 45, "cannot decode an element of non-universe type");
HEFF_LIT(g_heff_2eelab_2erules_2euniverseElimSyn_str5, 45, "cannot decode an element of non-universe type");
HEFF_LIT(g_heff_2eelab_2erules_2euniverseElimSyn_str6, 45, "cannot decode an element of non-universe type");
HEFF_LIT(g_heff_2eelab_2erules_2euniverseElimSyn_str7, 45, "cannot decode an element of non-universe type");
HEFF_LIT(g_heff_2eelab_2erules_2euniverseElimSyn_str8, 45, "cannot decode an element of non-universe type");
HEFF_LIT(g_heff_2eelab_2erules_2euniverseElimSyn_str9, 45, "cannot decode an element of non-universe type");
V g_heff_2eelab_2erules_2euniverseElimSyn_lam2(V self, V *args);
V g_heff_2eelab_2erules_2euniverseElimSyn_lam1(V self, V *args);
V g_heff_2eelab_2erules_2euniverseElimSyn_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2euniverseElimSyn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2euniverseElimSyn_entry, 2, 0};

V g_heff_2eelab_2erules_2euniverseElimSyn(V v_sp_240, V v_syn_241) {
top: ;
  return heff_tag_n(TAG_MkTyp, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2euniverseElimSyn_lam0, 1, 2, (V[]){heff_dup(v_syn_241), v_sp_240})});
}
V g_heff_2eelab_2erules_2euniverseElimSyn_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2erules_2euniverseElimSyn(a[0], a1); heff_drop(a1); return r;
}
V g_heff_2eelab_2erules_2euniverseElimSyn_lam2(V self, V *args) {
  V v_x_247 = args[0];
  V v_k_246 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  V v_hd_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_x_247)) {
  case TAG_MkPair: {
    V v_m_248 = heff_field(v_x_247, 0);
    V v_a_249 = heff_field(v_x_247, 1);
    heff_take_n(v_x_247, 3ULL, 2);
    switch (heff_tag_of(v_a_249)) {
    case TAG_VU: {
      heff_take_n(v_a_249, 0ULL, 1);
      heff_drop(v_sp_240);
      heff_drop_rec(v_hd_245, 3);
      V v_t_2411 = (g_heff_2eelab_2ememoed_2edecode(v_m_248));
      V f_ = v_k_246;
      args[0] = v_t_2411;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    case TAG_VDecode: {
      heff_take_n(v_a_249, 0ULL, 5);
      heff_drop(v_m_248);
      V v_t_2417 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(310LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2euniverseElimSyn_str0), v_sp_240, NTAG(TAG_Nothing)});
      V v_t_2418 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2417})});
      V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
      V v_t_2420 = heff_tr(heff_call(heff_take_field(v_hd_245, 2), 1, (V[]){v_t_2419}));
      V f_ = heff_get_n(v_hd_245, 1, 3);
      heff_room[0] = v_t_2420;
      heff_room[1] = v_k_246;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
    case TAG_VFunction: {
      heff_take_n(v_a_249, 0ULL, 5);
      heff_drop(v_m_248);
      V v_t_2426 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(310LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2euniverseElimSyn_str1), v_sp_240, NTAG(TAG_Nothing)});
      V v_t_2427 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2426})});
      V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
      V v_t_2429 = heff_tr(heff_call(heff_take_field(v_hd_245, 2), 1, (V[]){v_t_2428}));
      V f_ = heff_get_n(v_hd_245, 1, 3);
      heff_room[0] = v_t_2429;
      heff_room[1] = v_k_246;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
    case TAG_VRecord: {
      heff_take_n(v_a_249, 0ULL, 4);
      heff_drop(v_m_248);
      V v_t_2434 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(310LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2euniverseElimSyn_str2), v_sp_240, NTAG(TAG_Nothing)});
      V v_t_2435 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2434})});
      V v_t_2436 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2435})});
      V v_t_2437 = heff_tr(heff_call(heff_take_field(v_hd_245, 2), 1, (V[]){v_t_2436}));
      V f_ = heff_get_n(v_hd_245, 1, 3);
      heff_room[0] = v_t_2437;
      heff_room[1] = v_k_246;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
    case TAG_VSum: {
      V v_ru_24a_249_24VSum = heff_take_reuse_n(v_a_249, 0ULL, 1);
      heff_drop(v_m_248);
      V v_t_2439 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(310LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2euniverseElimSyn_str3), v_sp_240, NTAG(TAG_Nothing)});
      V v_t_2440 = heff_tag_at_n(v_ru_24a_249_24VSum, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2439})});
      V v_t_2441 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2440})});
      V v_t_2442 = heff_tr(heff_call(heff_take_field(v_hd_245, 2), 1, (V[]){v_t_2441}));
      V f_ = heff_get_n(v_hd_245, 1, 3);
      heff_room[0] = v_t_2442;
      heff_room[1] = v_k_246;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
    case TAG_VPrimInt: {
      heff_drop(v_m_248);
      V v_t_2443 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(310LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2euniverseElimSyn_str4), v_sp_240, NTAG(TAG_Nothing)});
      V v_t_2444 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2443})});
      V v_t_2445 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2444})});
      V v_t_2446 = heff_tr(heff_call(heff_take_field(v_hd_245, 2), 1, (V[]){v_t_2445}));
      V f_ = heff_get_n(v_hd_245, 1, 3);
      heff_room[0] = v_t_2446;
      heff_room[1] = v_k_246;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
    case TAG_VPrimFloat: {
      heff_drop(v_m_248);
      V v_t_2447 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(310LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2euniverseElimSyn_str5), v_sp_240, NTAG(TAG_Nothing)});
      V v_t_2448 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2447})});
      V v_t_2449 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2448})});
      V v_t_2450 = heff_tr(heff_call(heff_take_field(v_hd_245, 2), 1, (V[]){v_t_2449}));
      V f_ = heff_get_n(v_hd_245, 1, 3);
      heff_room[0] = v_t_2450;
      heff_room[1] = v_k_246;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
    case TAG_VPrimString: {
      heff_drop(v_m_248);
      V v_t_2451 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(310LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2euniverseElimSyn_str6), v_sp_240, NTAG(TAG_Nothing)});
      V v_t_2452 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2451})});
      V v_t_2453 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2452})});
      V v_t_2454 = heff_tr(heff_call(heff_take_field(v_hd_245, 2), 1, (V[]){v_t_2453}));
      V f_ = heff_get_n(v_hd_245, 1, 3);
      heff_room[0] = v_t_2454;
      heff_room[1] = v_k_246;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
    case TAG_VPrimRune: {
      heff_drop(v_m_248);
      V v_t_2455 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(310LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2euniverseElimSyn_str7), v_sp_240, NTAG(TAG_Nothing)});
      V v_t_2456 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2455})});
      V v_t_2457 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2456})});
      V v_t_2458 = heff_tr(heff_call(heff_take_field(v_hd_245, 2), 1, (V[]){v_t_2457}));
      V f_ = heff_get_n(v_hd_245, 1, 3);
      heff_room[0] = v_t_2458;
      heff_room[1] = v_k_246;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
    case TAG_VPrimArray: {
      V v_ru_24a_249_24VPrimArray = heff_take_reuse_n(v_a_249, 0ULL, 1);
      heff_drop(v_m_248);
      V v_t_2460 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(310LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2euniverseElimSyn_str8), v_sp_240, NTAG(TAG_Nothing)});
      V v_t_2461 = heff_tag_at_n(v_ru_24a_249_24VPrimArray, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2460})});
      V v_t_2462 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2461})});
      V v_t_2463 = heff_tr(heff_call(heff_take_field(v_hd_245, 2), 1, (V[]){v_t_2462}));
      V f_ = heff_get_n(v_hd_245, 1, 3);
      heff_room[0] = v_t_2463;
      heff_room[1] = v_k_246;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
    case TAG_VFixed: {
      V v_ru_24a_249_24VFixed = heff_take_reuse_n(v_a_249, 0ULL, 1);
      heff_drop(v_m_248);
      V v_t_2465 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(310LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2euniverseElimSyn_str9), v_sp_240, NTAG(TAG_Nothing)});
      V v_t_2466 = heff_tag_at_n(v_ru_24a_249_24VFixed, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2465})});
      V v_t_2467 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2466})});
      V v_t_2468 = heff_tr(heff_call(heff_take_field(v_hd_245, 2), 1, (V[]){v_t_2467}));
      V f_ = heff_get_n(v_hd_245, 1, 3);
      heff_room[0] = v_t_2468;
      heff_room[1] = v_k_246;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
    default: return heff_nomatch(v_a_249);
    }
  }
  default: return heff_nomatch(v_x_247);
  }
}
V g_heff_2eelab_2erules_2euniverseElimSyn_lam1(V self, V *args) {
  V v_hd_245 = args[0];
  V v_k_246 = args[1];
  V v_c_244 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_244;
  args[0] = heff_dup(v_hd_245);
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2euniverseElimSyn_lam2, 1, 3, (V[]){v_k_246, v_sp_240, v_hd_245});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2euniverseElimSyn_lam0(V self, V *args) {
  V v_e_242 = args[0];
  V v_syn_241 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_c_244;
  switch (heff_tag_of(v_syn_241)) {
  case TAG_MkSyn: {
    V v_f_243 = heff_field(v_syn_241, 0);
    heff_take_n(v_syn_241, 1ULL, 1);
    v_c_244 = heff_tr(heff_call(v_f_243, 1, (V[]){v_e_242}));
    break;
  }
  default: heff_nomatch(v_syn_241);
  }
  return heff_clo_n(g_heff_2eelab_2erules_2euniverseElimSyn_lam1, 2, 2, (V[]){v_c_244, v_sp_240});
}
Clo g_heff_2eelab_2erules_2eindexOfName_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eindexOfName_entry, 3, 0};

V g_heff_2eelab_2erules_2eindexOfName(V v_x1_240, V v_x_241, V v_i_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_x_241);
    heff_drop(v_i_242);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_y_243 = heff_field(v_x1_240, 0);
    V v_ys_244 = heff_field(v_x1_240, 1);
    if (heff_strEq_c(heff_dup(v_y_243), heff_dup(v_x_241))) {
      heff_drop(v_x_241);
      return heff_tag_n(TAG_Just, 1, (V[]){v_i_242});
    } else {
      V t_0 = v_ys_244;
      V t_1 = v_x_241;
      V t_2 = heff_intAdd(v_i_242, MK_INT(1LL));
      v_x1_240 = t_0;
      v_x_241 = t_1;
      v_i_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2erules_2eindexOfName_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2erules_2eindexOfName(a0, a[1], a[2]); heff_drop(a0); return r;
}