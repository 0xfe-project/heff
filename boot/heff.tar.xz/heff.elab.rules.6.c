// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_AbsConst 8406
#define TAG_Become 65038
#define TAG_CloConst 61868
#define TAG_De 8978
#define TAG_Describe 2650
#define TAG_Expl 20488
#define TAG_ForDescriptive 19066
#define TAG_ForNominative 23095
#define TAG_Get 18914
#define TAG_HLocal 25864
#define TAG_Impl 63555
#define TAG_Inst 64617
#define TAG_LSnoc 32613
#define TAG_Left 13886
#define TAG_LikeArray 39974
#define TAG_LikeFixed 5087
#define TAG_LikeFloat 20177
#define TAG_LikeFunction 24416
#define TAG_LikeInt 5296
#define TAG_LikeRecord 38505
#define TAG_LikeRune 45482
#define TAG_LikeString 41919
#define TAG_LikeSum 15116
#define TAG_LikeU 29548
#define TAG_MkAbs 54862
#define TAG_MkChk 56962
#define TAG_MkClo 57090
#define TAG_MkTyp 8305
#define TAG_N 306
#define TAG_NoRules 38560
#define TAG_Nom 25944
#define TAG_Right 62770
#define TAG_SApp 57081
#define TAG_SError 24172
#define TAG_SFunction 64505
#define TAG_SLam 1658
#define TAG_SMatch 27203
#define TAG_SpApp 44612
#define TAG_SpId 35501
#define TAG_SpProj 62333
#define TAG_SpSpec 18415
#define TAG_Throw 56084
#define TAG_UpdateIn 26667
#define TAG_UpdateTo 27009
#define TAG_VDecode 24012
#define TAG_VFixed 12623
#define TAG_VFunction 37316
#define TAG_VOpaque 37311
#define TAG_VPrimArray 11892
#define TAG_VPrimFloat 57621
#define TAG_VPrimInt 4244
#define TAG_VPrimRune 12870
#define TAG_VPrimString 23215
#define TAG_VRecord 10017
#define TAG_VSum 32852
#define TAG_VU 9520
#define LBL_aliases 1464806715
#define LBL_bind 9519364
#define LBL_byName 571997869
#define LBL_code 9554612
#define LBL_elabFor 712452832
#define LBL_globals 352931696
#define LBL_insts 301719303
#define LBL_keys 9783995
#define LBL_lams 9809570
#define LBL_len 316559
#define LBL_locals 849679763
#define LBL_malg 9839318
#define LBL_metas 305145640
#define LBL_msg 317947
#define LBL_name 9869138
#define LBL_names 305943394
#define LBL_note 9882809
#define LBL_scope 310622830
#define LBL_self 10021907
#define LBL_severity 75955546
#define LBL_span 10032145
#define LBL_stx 323761
#define LBL_ty 10476
#define LBL_v 336
#define LBL_val 326043
#define LBL_values 1123329101
static uint32_t shape_code__severity__msg__span__note[] = {LBL_code, LBL_severity, LBL_msg, LBL_span, LBL_note};
static uint32_t shape_keys__byName__values[] = {LBL_keys, LBL_byName, LBL_values};
static uint32_t shape_len__names[] = {LBL_len, LBL_names};
static uint32_t shape_name__ty__v[] = {LBL_name, LBL_ty, LBL_v};
static uint32_t shape_scope__globals__elabFor__lams__self__insts[] = {LBL_scope, LBL_globals, LBL_elabFor, LBL_lams, LBL_self, LBL_insts};
static uint32_t shape_stx__val[] = {LBL_stx, LBL_val};
V g_co_2ebind_24s441514442x2097556756(V, V, V, V);
V g_co_2ebind_24s441514442x2097556756_entry(V self, V *a);
extern Clo g_co_2ebind_24s441514442x2097556756_clo;
V g_heff_2eelab_2eenvironment_2ewithBound(V, V, V, V);
V g_heff_2eelab_2eenvironment_2ewithBound_entry(V self, V *a);
extern Clo g_heff_2eelab_2eenvironment_2ewithBound_clo;
V g_heff_2eelab_2ememoed_2elam(V, V, V, V, V);
V g_heff_2eelab_2ememoed_2elam_entry(V self, V *a);
extern Clo g_heff_2eelab_2ememoed_2elam_clo;
V g_heff_2eelab_2emeta_2eliftU(V, V, V);
V g_heff_2eelab_2emeta_2eliftU_entry(V self, V *a);
extern Clo g_heff_2eelab_2emeta_2eliftU_clo;
V g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(V, V);
V g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276_entry(V self, V *a);
extern Clo g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276_clo;
V g_heff_2eelab_2erename_2edescribeKey(V);
V g_heff_2eelab_2erename_2edescribeKey_entry(V self, V *a);
extern Clo g_heff_2eelab_2erename_2edescribeKey_clo;
HeffT2 g_heff_2eelab_2erename_2efirstAliasOf_24cpr(V, V);
V g_heff_2eelab_2erename_2erkOf(V);
V g_heff_2eelab_2erename_2erkOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2erename_2erkOf_clo;
V g_heff_2eelab_2erules_2eapartSpines(V, V, V);
V g_heff_2eelab_2erules_2eapartSpines_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eapartSpines_clo;
V g_heff_2eelab_2erules_2eappendP(V, V);
V g_heff_2eelab_2erules_2eappendP_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eappendP_clo;
V g_heff_2eelab_2erules_2ecaseArm(V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2ecaseArm_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2ecaseArm_clo;
V g_heff_2eelab_2erules_2ecasesAt(V, V, V, V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2ecasesAt_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2ecasesAt_clo;
V g_heff_2eelab_2erules_2econclusionOf(V, V);
V g_heff_2eelab_2erules_2econclusionOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2econclusionOf_clo;
V g_heff_2eelab_2erules_2edelayedCheck(V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2edelayedCheck_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2edelayedCheck_clo;
V g_heff_2eelab_2erules_2edownFrom_24dps(V, V);
V g_heff_2eelab_2erules_2edownFrom_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2edownFrom_24dps_clo;
HeffT1 g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr(V, V, V, V);
V g_heff_2eelab_2erules_2eletsAround(V, V, V, V, V);
V g_heff_2eelab_2erules_2eletsAround_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eletsAround_clo;
HeffT2 g_heff_2eelab_2erules_2elookupP_24cpr(V, V);
V g_heff_2eelab_2erules_2eprettyEqErr(V, V);
V g_heff_2eelab_2erules_2eprettyEqErr_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2eprettyEqErr_clo;
V g_heff_2eelab_2erules_2erecordTags(V, V, V, V);
V g_heff_2eelab_2erules_2erecordTags_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2erecordTags_clo;
V g_heff_2eelab_2erules_2erequireAgree(V, V, V);
V g_heff_2eelab_2erules_2erequireAgree_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2erequireAgree_clo;
HeffT2 g_heff_2eelab_2erules_2erigidFormer_24cpr(V, V);
V g_heff_2eelab_2erules_2esolveHole(V, V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2esolveHole_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2esolveHole_clo;
V g_heff_2eelab_2erules_2etagsExposed(V, V, V, V);
V g_heff_2eelab_2erules_2etagsExposed_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2etagsExposed_clo;
V g_heff_2eelab_2erules_2etyStr(V, V);
V g_heff_2eelab_2erules_2etyStr_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2etyStr_clo;
V g_heff_2eelab_2erules_2euniverseAt(V, V, V, V, V, V, V);
V g_heff_2eelab_2erules_2euniverseAt_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2euniverseAt_clo;
V g_heff_2eelab_2erules_2euniverseIntro(V, V);
V g_heff_2eelab_2erules_2euniverseIntro_entry(V self, V *a);
extern Clo g_heff_2eelab_2erules_2euniverseIntro_clo;
HeffT2 g_heff_2eelab_2erules_2eupdateInner_24cpr(V);
V g_heff_2eelab_2eunify_2euTypeF_24s1972392790x1695903351(V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2euTypeF_24s1972392790x1695903351_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2euTypeF_24s1972392790x1695903351_clo;
V g_heff_2eelab_2evalue_2ebehavior(V);
V g_heff_2eelab_2evalue_2ebehavior_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2ebehavior_clo;
V g_heff_2eelab_2evalue_2eforceTy(V, V);
V g_heff_2eelab_2evalue_2eforceTy_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eforceTy_clo;
V g_heff_2eelab_2evalue_2elevelOf(V);
V g_heff_2eelab_2evalue_2elevelOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2elevelOf_clo;
V g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(V, V, V, V);
V g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190_clo;
V g_heff_2esyntax_2esurfaceprint_2etyF_24s1921338660x1500721774(V, V, V, V);
V g_heff_2esyntax_2esurfaceprint_2etyF_24s1921338660x1500721774_entry(V self, V *a);
extern Clo g_heff_2esyntax_2esurfaceprint_2etyF_24s1921338660x1500721774_clo;
V g_heff_2eutil_2edict_2eindexed(V, V);
V g_heff_2eutil_2edict_2eindexed_entry(V self, V *a);
extern Clo g_heff_2eutil_2edict_2eindexed_clo;
V g_heff_2eutil_2edict_2ezipKV(V, V);
V g_heff_2eutil_2edict_2ezipKV_entry(V self, V *a);
extern Clo g_heff_2eutil_2edict_2ezipKV_clo;
V g_list_2emap_24s1173914895x100384474(V);
V g_list_2emap_24s1173914895x100384474_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_clo;
V g_list_2emap_24s1937570095x2110149801(V);
V g_list_2emap_24s1937570095x2110149801_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_clo;
V g_prelude_2etraverse_24s1934076392x614790049(V, V);
V g_prelude_2etraverse_24s1934076392x614790049_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s1934076392x614790049_clo;
V g_std_2emap_2etoListOnto(V, V);
V g_std_2emap_2etoListOnto_entry(V self, V *a);
extern Clo g_std_2emap_2etoListOnto_clo;
Clo g_heff_2eelab_2erules_2edownFrom_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2edownFrom_24dps_entry, 2, 0};

V g_heff_2eelab_2erules_2edownFrom_24dps(V v_n_240, V v_d_241) {
top: ;
  if (heff_intLt_c_lent(v_n_240, MK_INT(0LL), 2)) {
    heff_drop(v_n_240);
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  } else {
    V v_cell_243 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_n_240), heff_hole()});
    V v_u_244 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_243));
    heff_drop(v_u_244);
    V t_0 = heff_intSub(v_n_240, MK_INT(1LL));
    V t_1 = v_cell_243;
    v_n_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
}
V g_heff_2eelab_2erules_2edownFrom_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2edownFrom_24dps(a[0], a[1]);
}
V g_heff_2eelab_2erules_2etyStr_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2etyStr_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2etyStr_entry, 2, 0};

V g_heff_2eelab_2erules_2etyStr(V v_e_240, V v_t_241) {
top: ;
  V v_t_242 = heff_get_n(heff_dup(heff_rfield(v_e_240, 0)), 0, 4);
  V v_t_243 = (g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(v_t_242, v_t_241));
  V v_t_2413 = (g_heff_2eelab_2erename_2erkOf(heff_clo_n(g_heff_2eelab_2erules_2etyStr_lam0, 1, 1, (V[]){heff_dup(v_e_240)})));
  V v_t_2414 = heff_tr(heff_call(heff_get_n(v_t_2413, 1, 2), 1, (V[]){v_t_243}));
  V v_t_2415 = heff_get_n(heff_get_n(v_e_240, 0, 6), 1, 4);
  return ({ V a_0 = MK_INT(0LL); V a_1 = MK_INT(0LL); V a_2 = v_t_2415; V a_3 = v_t_2414; V r_ = (g_heff_2esyntax_2esurfaceprint_2etyF_24s1921338660x1500721774(a_0, a_1, a_2, a_3)); heff_drop(v_t_2414); r_; });
}
V g_heff_2eelab_2erules_2etyStr_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2etyStr(a[0], a[1]);
}
V g_heff_2eelab_2erules_2etyStr_lam0(V self, V *args) {
  V v_x_244 = args[0];
  V v_e_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_d_245 = (g_heff_2eelab_2erename_2edescribeKey(heff_dup(v_x_244)));
  V v_t_246 = heff_get_n(heff_get_n(v_e_240, 1, 6), 2, 8);
  V v_t_247 = ({ V a_0 = v_t_246; V a_1 = NTAG(TAG_Nil); V r_ = (g_std_2emap_2etoListOnto(a_0, a_1)); heff_drop(v_t_246); r_; });
  HeffT2 v_t_248 = ({ V a_0 = v_t_247; V a_1 = v_x_244; HeffT2 r_ = (g_heff_2eelab_2erename_2efirstAliasOf_24cpr(a_0, a_1)); heff_drop(v_x_244); r_; });
  {
    V v_field_2410 = v_t_248.f[1];
    int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
    if ((v_tag_249 == ((int64_t)0ULL))) {
      heff_drop(v_d_245);
      V v_x_2412 = v_field_2410;
      return v_x_2412;
    } else {
      heff_drop(v_field_2410);
      return v_d_245;
    }
  }
}
V g_heff_2eelab_2erules_2econclusionOf_lam1(V self, V *args);
V g_heff_2eelab_2erules_2econclusionOf_lam0(V self, V *args);
V g_heff_2eelab_2erules_2econclusionOf_lam3(V self, V *args);
V g_heff_2eelab_2erules_2econclusionOf_lam2(V self, V *args);
Clo g_heff_2eelab_2erules_2econclusionOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2econclusionOf_entry, 2, 0};

V g_heff_2eelab_2erules_2econclusionOf(V v_n_240, V v_ty_241) {
top: ;
  switch (heff_tag_of(v_ty_241)) {
  case TAG_VU: {
    heff_drop(v_n_240);
    return v_ty_241;
  }
  case TAG_VDecode: {
    heff_drop(v_n_240);
    return v_ty_241;
  }
  case TAG_VFunction: {
    V v_dom_249 = heff_dup(heff_field(v_ty_241, 1));
    V v_cod_2410 = heff_dup(heff_field(v_ty_241, 2));
    V v_it4_2411 = heff_dup(heff_field(v_ty_241, 3));
    switch (heff_tag_of(v_it4_2411)) {
    case TAG_Expl: {
      heff_drop(v_n_240);
      heff_drop(v_dom_249);
      heff_drop(v_cod_2410);
      return v_ty_241;
    }
    case TAG_Impl: {
      heff_drop_tag(v_ty_241, 5);
      V v_x1_2419;
      switch (heff_tag_of(v_cod_2410)) {
      case TAG_MkClo: {
        V v_vs_2414 = heff_field(v_cod_2410, 1);
        V v_body_2415 = heff_field(v_cod_2410, 2);
        heff_take_n(v_cod_2410, 6ULL, 3);
        v_x1_2419 = heff_tr(heff_call(v_body_2415, 1, (V[]){heff_tag_n(TAG_LSnoc, 2, (V[]){v_vs_2414, heff_clo_n(g_heff_2eelab_2erules_2econclusionOf_lam0, 1, 2, (V[]){heff_dup(v_n_240), v_dom_249})})}));
        break;
      }
      case TAG_CloConst: {
        V v_body_2418 = heff_field(v_cod_2410, 0);
        heff_take_n(v_cod_2410, 1ULL, 1);
        heff_drop(v_dom_249);
        v_x1_2419 = v_body_2418;
        break;
      }
      default: heff_nomatch(v_cod_2410);
      }
      V v_t_2423;
      switch (heff_tag_of(v_x1_2419)) {
      case TAG_Nom: {
        V v_x_2420 = heff_field(v_x1_2419, 0);
        heff_take_n(v_x1_2419, 1ULL, 1);
        v_t_2423 = v_x_2420;
        break;
      }
      case TAG_Describe: {
        heff_take_n(v_x1_2419, 0ULL, 1);
        v_t_2423 = heff_abandon();
        break;
      }
      case TAG_Become: {
        V v_x_2422 = heff_field(v_x1_2419, 0);
        heff_take_n(v_x1_2419, 1ULL, 1);
        v_t_2423 = v_x_2422;
        break;
      }
      default: heff_nomatch(v_x1_2419);
      }
      V t_0 = heff_intAdd(v_n_240, MK_INT(1LL));
      V t_1 = v_t_2423;
      v_n_240 = t_0;
      v_ty_241 = t_1;
      goto top;
    }
    case TAG_Inst: {
      heff_drop_tag(v_ty_241, 5);
      V v_x1_2430;
      switch (heff_tag_of(v_cod_2410)) {
      case TAG_MkClo: {
        V v_vs_2425 = heff_field(v_cod_2410, 1);
        V v_body_2426 = heff_field(v_cod_2410, 2);
        heff_take_n(v_cod_2410, 6ULL, 3);
        v_x1_2430 = heff_tr(heff_call(v_body_2426, 1, (V[]){heff_tag_n(TAG_LSnoc, 2, (V[]){v_vs_2425, heff_clo_n(g_heff_2eelab_2erules_2econclusionOf_lam2, 1, 2, (V[]){heff_dup(v_n_240), v_dom_249})})}));
        break;
      }
      case TAG_CloConst: {
        V v_body_2429 = heff_field(v_cod_2410, 0);
        heff_take_n(v_cod_2410, 1ULL, 1);
        heff_drop(v_dom_249);
        v_x1_2430 = v_body_2429;
        break;
      }
      default: heff_nomatch(v_cod_2410);
      }
      V v_t_2434;
      switch (heff_tag_of(v_x1_2430)) {
      case TAG_Nom: {
        V v_x_2431 = heff_field(v_x1_2430, 0);
        heff_take_n(v_x1_2430, 1ULL, 1);
        v_t_2434 = v_x_2431;
        break;
      }
      case TAG_Describe: {
        heff_take_n(v_x1_2430, 0ULL, 1);
        v_t_2434 = heff_abandon();
        break;
      }
      case TAG_Become: {
        V v_x_2433 = heff_field(v_x1_2430, 0);
        heff_take_n(v_x1_2430, 1ULL, 1);
        v_t_2434 = v_x_2433;
        break;
      }
      default: heff_nomatch(v_x1_2430);
      }
      V t_0 = heff_intAdd(v_n_240, MK_INT(1LL));
      V t_1 = v_t_2434;
      v_n_240 = t_0;
      v_ty_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_it4_2411);
    }
  }
  case TAG_VRecord: {
    heff_drop(v_n_240);
    return v_ty_241;
  }
  case TAG_VSum: {
    heff_drop(v_n_240);
    return v_ty_241;
  }
  case TAG_VPrimInt: {
    heff_drop(v_n_240);
    return v_ty_241;
  }
  case TAG_VPrimFloat: {
    heff_drop(v_n_240);
    return v_ty_241;
  }
  case TAG_VPrimString: {
    heff_drop(v_n_240);
    return v_ty_241;
  }
  case TAG_VPrimRune: {
    heff_drop(v_n_240);
    return v_ty_241;
  }
  case TAG_VPrimArray: {
    heff_drop(v_n_240);
    return v_ty_241;
  }
  case TAG_VFixed: {
    heff_drop(v_n_240);
    return v_ty_241;
  }
  default: return heff_nomatch(v_ty_241);
  }
}
V g_heff_2eelab_2erules_2econclusionOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2econclusionOf(a[0], a[1]);
}
V g_heff_2eelab_2erules_2econclusionOf_lam1(V self, V *args) {
  V v_u_2417 = args[0];
  V v_dom_249 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2417);
  return v_dom_249;
}
V g_heff_2eelab_2erules_2econclusionOf_lam0(V self, V *args) {
  V v_u_2416 = args[0];
  V v_n_240 = heff_env(self)[0];
  V v_dom_249 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_u_2416);
  return (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(heff_tag_n(TAG_HLocal, 1, (V[]){v_n_240}), NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2erules_2econclusionOf_lam1, 1, 1, (V[]){v_dom_249}), NTAG(TAG_Nothing)));
}
V g_heff_2eelab_2erules_2econclusionOf_lam3(V self, V *args) {
  V v_u_2428 = args[0];
  V v_dom_249 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2428);
  return v_dom_249;
}
V g_heff_2eelab_2erules_2econclusionOf_lam2(V self, V *args) {
  V v_u_2427 = args[0];
  V v_n_240 = heff_env(self)[0];
  V v_dom_249 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_u_2427);
  return (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(heff_tag_n(TAG_HLocal, 1, (V[]){v_n_240}), NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2erules_2econclusionOf_lam3, 1, 1, (V[]){v_dom_249}), NTAG(TAG_Nothing)));
}
Clo g_heff_2eelab_2erules_2eapartSpines_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eapartSpines_entry, 3, 0};

V g_heff_2eelab_2erules_2eapartSpines(V v_mc_240, V v_x2_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_SpId: {
    return NTAG(TAG_False);
  }
  case TAG_SpApp: {
    V v_sp_243 = heff_field(v_x2_241, 0);
    V v_a_244 = heff_field(v_x2_241, 1);
    switch (heff_tag_of(v_x3_242)) {
    case TAG_SpId: {
      return NTAG(TAG_False);
    }
    case TAG_SpApp: {
      V v_sp2_245 = heff_field(v_x3_242, 0);
      V v_b_246 = heff_field(v_x3_242, 1);
      HeffT2 v_t_247 = (g_heff_2eelab_2erules_2erigidFormer_24cpr(v_mc_240, heff_dup(v_a_244)));
      {
        V v_field_249 = v_t_247.f[1];
        int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
        if ((v_tag_248 == ((int64_t)0ULL))) {
          V v_k_2411 = v_field_249;
          HeffT2 v_t_2412 = (g_heff_2eelab_2erules_2erigidFormer_24cpr(v_mc_240, heff_dup(v_b_246)));
          {
            V v_field_2414 = v_t_2412.f[1];
            int64_t v_tag_2413 = ((int64_t)v_t_2412.f[0]);
            if ((v_tag_2413 == ((int64_t)0ULL))) {
              V v_k2_2416 = v_field_2414;
              if (heff_strEq_c(v_k_2411, v_k2_2416)) {
                V t_0 = v_mc_240;
                V t_1 = v_sp_243;
                V t_2 = v_sp2_245;
                v_mc_240 = t_0;
                v_x2_241 = t_1;
                v_x3_242 = t_2;
                goto top;
              } else {
                return NTAG(TAG_True);
              }
            } else {
              heff_drop(v_k_2411);
              heff_drop(v_field_2414);
              V t_0 = v_mc_240;
              V t_1 = v_sp_243;
              V t_2 = v_sp2_245;
              v_mc_240 = t_0;
              v_x2_241 = t_1;
              v_x3_242 = t_2;
              goto top;
            }
          }
        } else {
          heff_drop(v_field_249);
          V t_0 = v_mc_240;
          V t_1 = v_sp_243;
          V t_2 = v_sp2_245;
          v_mc_240 = t_0;
          v_x2_241 = t_1;
          v_x3_242 = t_2;
          goto top;
        }
      }
    }
    case TAG_SpProj: {
      return NTAG(TAG_False);
    }
    case TAG_SpSpec: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x3_242);
    }
  }
  case TAG_SpProj: {
    return NTAG(TAG_False);
  }
  case TAG_SpSpec: {
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eelab_2erules_2eapartSpines_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V r = g_heff_2eelab_2erules_2eapartSpines(a0, a1, a2); heff_drop(a0); heff_drop(a1); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_str0, 57, "tried to check a lambda expression at a non-function type");
HEFF_LIT(g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_str1, 1, "_");
HEFF_LIT(g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_str2, 1, "_");
HEFF_LIT(g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_str3, 1, "_");
HEFF_LIT(g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_str4, 57, "tried to check a lambda expression at a non-function type");
HEFF_LIT(g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_str5, 57, "tried to check a lambda expression at a non-function type");
HEFF_LIT(g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_str6, 57, "tried to check a lambda expression at a non-function type");
HEFF_LIT(g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_str7, 57, "tried to check a lambda expression at a non-function type");
HEFF_LIT(g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_str8, 57, "tried to check a lambda expression at a non-function type");
HEFF_LIT(g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_str9, 57, "tried to check a lambda expression at a non-function type");
HEFF_LIT(g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_str10, 57, "tried to check a lambda expression at a non-function type");
HEFF_LIT(g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_str11, 57, "tried to check a lambda expression at a non-function type");
HEFF_LIT(g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_str12, 57, "tried to check a lambda expression at a non-function type");
V g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_lam1(V self, V *args);
V g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_lam4(V self, V *args);
V g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_lam8(V self, V *args);
V g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_lam11(V self, V *args);
V g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_lam10(V self, V *args);
V g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_lam9(V self, V *args);
V g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_lam7(V self, V *args);
V g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_lam6(V self, V *args);
V g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_lam5(V self, V *args);
V g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_lam3(V self, V *args);
V g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_lam13(V self, V *args);
V g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_lam16(V self, V *args);
V g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_lam15(V self, V *args);
V g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_lam14(V self, V *args);
V g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_lam12(V self, V *args);
V g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_lam2(V self, V *args);
V g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_lam0(V self, V *args);

HeffT1 g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr(V v_sp_240, V v_x_241, V v_dom_242, V v_body_243) {
top: ;
  return ((HeffT1){{heff_clo_n(g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_lam0, 4, 4, (V[]){v_sp_240, heff_dup(v_dom_242), v_x_241, heff_dup(v_body_243)})}});
}
V g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_lam1(V self, V *args) {
  V v_c_248 = args[0];
  V v_a0_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_c_248, 3, 8); V a_1 = v_a0_245; V r_ = (g_heff_2eelab_2evalue_2eforceTy(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_lam4(V self, V *args) {
  V v_p_2433 = args[0];
  V v_p_2434 = args[1];
  V v_c_2427 = heff_env(self)[0];
  V v_e_244 = heff_env(self)[1];
  V v_fdom_2420 = heff_env(self)[2];
  V v_b_2432 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2435 = heff_rec_n(2, shape_len__names, (V[]){heff_take_field(v_c_2427, 0), heff_get_n(v_c_2427, 1, 4)});
  V v_t_2436 = heff_tr(heff_call(((V)&g_heff_2eelab_2eunify_2euTypeF_24s1972392790x1695903351_clo), 4, (V[]){heff_get_n(v_e_244, 1, 6), v_t_2435, v_fdom_2420, v_b_2432}));
  return (g_heff_2eelab_2emeta_2eliftU(v_t_2436, v_p_2433, v_p_2434));
}
V g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_lam8(V self, V *args) {
  V v_u_2452 = args[0];
  V v_v_2447 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2452);
  return v_v_2447;
}
V g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_lam11(V self, V *args) {
  V v_u_2477 = args[0];
  V v_x_2412 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2477);
  return heff_tag_n(TAG_Nom, 1, (V[]){v_x_2412});
}
V g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_lam10(V self, V *args) {
  V v_x_2469 = args[0];
  V v_e_244 = heff_env(self)[0];
  V v_x_2412 = heff_env(self)[1];
  V v_x_241 = heff_env(self)[2];
  V v_k_2468 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2470 = heff_take_field(v_e_244, 2);
  V v_t_2473;
  switch (heff_tag_of(v_t_2470)) {
  case TAG_ForNominative: {
    v_t_2473 = NTAG(TAG_N);
    break;
  }
  case TAG_ForDescriptive: {
    heff_take_n(v_t_2470, 0ULL, 2);
    v_t_2473 = NTAG(TAG_De);
    break;
  }
  default: heff_nomatch(v_t_2470);
  }
  V v_t_2474 = heff_get_n(heff_dup(heff_rfield(v_e_244, 0)), 2, 4);
  V v_t_2475 = heff_get_n(heff_dup(heff_rfield(v_e_244, 0)), 0, 4);
  V v_t_2476 = (g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(v_t_2475, heff_dup(v_x_2412)));
  V v_x_2478 = (g_heff_2eelab_2ememoed_2elam(v_t_2473, heff_get_n(v_e_244, 1, 6), v_t_2474, heff_rec_n(2, shape_stx__val, (V[]){v_t_2476, heff_clo_n(g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_lam11, 1, 1, (V[]){v_x_2412})}), heff_tag_n(TAG_MkAbs, 2, (V[]){v_x_241, v_x_2469})));
  V f_ = v_k_2468;
  args[0] = v_x_2478;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_lam9(V self, V *args) {
  V v_hd_2467 = args[0];
  V v_k_2468 = args[1];
  V v_c_2466 = heff_env(self)[0];
  V v_e_244 = heff_env(self)[1];
  V v_x_2412 = heff_env(self)[2];
  V v_x_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_2466;
  args[0] = v_hd_2467;
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_lam10, 1, 4, (V[]){v_e_244, v_x_2412, v_x_241, v_k_2468});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_lam7(V self, V *args) {
  V v_v_2447 = args[0];
  V v_scope_27_2448 = args[1];
  V v_cod_2421 = heff_env(self)[0];
  V v_body_243 = heff_env(self)[1];
  V v_e_244 = heff_env(self)[2];
  V v_x_2412 = heff_env(self)[3];
  V v_x_241 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_x1_2454;
  switch (heff_tag_of(v_cod_2421)) {
  case TAG_MkClo: {
    V v_vs_2450 = heff_field(v_cod_2421, 1);
    V v_body_2451 = heff_field(v_cod_2421, 2);
    heff_take_n(v_cod_2421, 6ULL, 3);
    v_x1_2454 = heff_tr(heff_call(v_body_2451, 1, (V[]){heff_tag_n(TAG_LSnoc, 2, (V[]){v_vs_2450, heff_clo_n(g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_lam8, 1, 1, (V[]){heff_dup(v_v_2447)})})}));
    break;
  }
  case TAG_CloConst: {
    V v_body_2453 = heff_field(v_cod_2421, 0);
    heff_take_n(v_cod_2421, 1ULL, 1);
    v_x1_2454 = v_body_2453;
    break;
  }
  default: heff_nomatch(v_cod_2421);
  }
  V v_a_2458;
  switch (heff_tag_of(v_x1_2454)) {
  case TAG_Nom: {
    V v_x_2455 = heff_field(v_x1_2454, 0);
    heff_take_n(v_x1_2454, 1ULL, 1);
    v_a_2458 = v_x_2455;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2454, 0ULL, 1);
    v_a_2458 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2457 = heff_field(v_x1_2454, 0);
    heff_take_n(v_x1_2454, 1ULL, 1);
    v_a_2458 = v_x_2457;
    break;
  }
  default: heff_nomatch(v_x1_2454);
  }
  V v_c_2466;
  switch (heff_tag_of(v_body_243)) {
  case TAG_MkChk: {
    V v_f_2459 = heff_field(v_body_243, 0);
    heff_take_n(v_body_243, 1ULL, 1);
    V v_t_2460 = heff_dup(heff_rfield(v_e_244, 2));
    V v_t_2463;
    switch (heff_tag_of(v_t_2460)) {
    case TAG_ForNominative: {
      heff_drop(v_v_2447);
      v_t_2463 = NTAG(TAG_ForNominative);
      break;
    }
    case TAG_ForDescriptive: {
      V v_h_2461 = heff_field(v_t_2460, 0);
      V v_sp_2462 = heff_field(v_t_2460, 1);
      V v_ru_24t_2460_24ForDescriptive = heff_take_reuse_n(v_t_2460, 3ULL, 2);
      v_t_2463 = heff_tag_at_n(v_ru_24t_2460_24ForDescriptive, TAG_ForDescriptive, 2, (V[]){v_h_2461, heff_tag_n(TAG_SpApp, 2, (V[]){v_sp_2462, v_v_2447})});
      break;
    }
    default: heff_nomatch(v_t_2460);
    }
    V v_t_2464 = heff_intAdd(heff_dup(heff_rfield(v_e_244, 3)), MK_INT(1LL));
    V v_t_2465 = heff_rec_n(6, shape_scope__globals__elabFor__lams__self__insts, (V[]){v_scope_27_2448, heff_dup(heff_rfield(v_e_244, 1)), v_t_2463, v_t_2464, heff_dup(heff_rfield(v_e_244, 4)), heff_dup(heff_rfield(v_e_244, 5))});
    v_c_2466 = heff_tr(heff_call(v_f_2459, 2, (V[]){v_t_2465, v_a_2458}));
    break;
  }
  default: heff_nomatch(v_body_243);
  }
  return heff_clo_n(g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_lam9, 2, 4, (V[]){v_c_2466, v_e_244, v_x_2412, v_x_241});
}
V g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_lam6(V self, V *args) {
  V v_x_2441 = args[0];
  V v_x_2426 = heff_env(self)[0];
  V v_x_241 = heff_env(self)[1];
  V v_e_244 = heff_env(self)[2];
  V v_cod_2421 = heff_env(self)[3];
  V v_body_243 = heff_env(self)[4];
  V v_x_2412 = heff_env(self)[5];
  V v_z_2438 = heff_env(self)[6];
  V v_z_2439 = heff_env(self)[7];
  heff_clo_take(self, 8);
  heff_drop(v_x_2441);
  V v_x1_2442 = heff_tr(heff_call(heff_get_n(v_x_2426, 1, 2), 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_t_2446;
  switch (heff_tag_of(v_x1_2442)) {
  case TAG_Nom: {
    V v_x_2443 = heff_field(v_x1_2442, 0);
    heff_take_n(v_x1_2442, 1ULL, 1);
    v_t_2446 = v_x_2443;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2442, 0ULL, 1);
    v_t_2446 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2445 = heff_field(v_x1_2442, 0);
    heff_take_n(v_x1_2442, 1ULL, 1);
    v_t_2446 = v_x_2445;
    break;
  }
  default: heff_nomatch(v_x1_2442);
  }
  V v_t_2479 = heff_tr(g_heff_2eelab_2eenvironment_2ewithBound(heff_dup(v_x_241), v_t_2446, heff_dup(heff_rfield(v_e_244, 0)), heff_clo_n(g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_lam7, 2, 5, (V[]){v_cod_2421, v_body_243, v_e_244, v_x_2412, v_x_241})));
  V f_ = v_t_2479;
  heff_room[0] = v_z_2438;
  heff_room[1] = v_z_2439;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_lam5(V self, V *args) {
  V v_agree_2437 = args[0];
  V v_z_2438 = args[1];
  V v_z_2439 = args[2];
  V v_e_244 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  V v_x_2426 = heff_env(self)[2];
  V v_x_241 = heff_env(self)[3];
  V v_cod_2421 = heff_env(self)[4];
  V v_body_243 = heff_env(self)[5];
  V v_x_2412 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_c_2440 = (g_heff_2eelab_2erules_2erequireAgree(heff_dup(v_e_244), v_sp_240, v_agree_2437));
  V f_ = v_c_2440;
  args[0] = heff_dup(v_z_2438);
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_lam6, 1, 8, (V[]){v_x_2426, v_x_241, v_e_244, v_cod_2421, v_body_243, v_x_2412, v_z_2438, v_z_2439});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_lam3(V self, V *args) {
  V v_x_2426 = args[0];
  V v_e_244 = heff_env(self)[0];
  V v_fdom_2420 = heff_env(self)[1];
  V v_sp_240 = heff_env(self)[2];
  V v_x_241 = heff_env(self)[3];
  V v_cod_2421 = heff_env(self)[4];
  V v_body_243 = heff_env(self)[5];
  V v_x_2412 = heff_env(self)[6];
  V v_hd_246 = heff_env(self)[7];
  V v_k_247 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_c_2427 = heff_dup(heff_rfield(v_e_244, 0));
  V v_x1_2428 = heff_tr(heff_call(heff_dup(heff_rfield(v_x_2426, 1)), 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_b_2432;
  switch (heff_tag_of(v_x1_2428)) {
  case TAG_Nom: {
    V v_x_2429 = heff_field(v_x1_2428, 0);
    heff_take_n(v_x1_2428, 1ULL, 1);
    v_b_2432 = v_x_2429;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2428, 0ULL, 1);
    v_b_2432 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2431 = heff_field(v_x1_2428, 0);
    heff_take_n(v_x1_2428, 1ULL, 1);
    v_b_2432 = v_x_2431;
    break;
  }
  default: heff_nomatch(v_x1_2428);
  }
  return (g_co_2ebind_24s441514442x2097556756(heff_clo_n(g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_lam4, 2, 4, (V[]){v_c_2427, heff_dup(v_e_244), v_fdom_2420, v_b_2432}), heff_clo_n(g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_lam5, 3, 7, (V[]){v_e_244, v_sp_240, v_x_2426, v_x_241, v_cod_2421, v_body_243, v_x_2412}), v_hd_246, v_k_247));
}
V g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_lam13(V self, V *args) {
  V v_u_2492 = args[0];
  V v_v_2485 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2492);
  return v_v_2485;
}
V g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_lam16(V self, V *args) {
  V v_u_24128 = args[0];
  V v_x_2412 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_24128);
  return heff_tag_n(TAG_Nom, 1, (V[]){v_x_2412});
}
V g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_lam15(V self, V *args) {
  V v_x_24115 = args[0];
  V v_e_244 = heff_env(self)[0];
  V v_x_2412 = heff_env(self)[1];
  V v_cod_2421 = heff_env(self)[2];
  V v_k_24114 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_24116 = heff_take_field(v_e_244, 2);
  V v_t_24119;
  switch (heff_tag_of(v_t_24116)) {
  case TAG_ForNominative: {
    v_t_24119 = NTAG(TAG_N);
    break;
  }
  case TAG_ForDescriptive: {
    heff_take_n(v_t_24116, 0ULL, 2);
    v_t_24119 = NTAG(TAG_De);
    break;
  }
  default: heff_nomatch(v_t_24116);
  }
  V v_t_24120 = heff_get_n(heff_dup(heff_rfield(v_e_244, 0)), 2, 4);
  V v_t_24121 = heff_get_n(heff_dup(heff_rfield(v_e_244, 0)), 0, 4);
  V v_t_24122 = (g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(v_t_24121, heff_dup(v_x_2412)));
  V v_t_24127;
  switch (heff_tag_of(v_cod_2421)) {
  case TAG_MkClo: {
    V v_n_24123 = heff_field(v_cod_2421, 0);
    heff_take_n(v_cod_2421, 1ULL, 3);
    v_t_24127 = v_n_24123;
    break;
  }
  case TAG_CloConst: {
    heff_take_n(v_cod_2421, 0ULL, 1);
    v_t_24127 = ((V)&g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_str3);
    break;
  }
  default: heff_nomatch(v_cod_2421);
  }
  V v_x_24129 = (g_heff_2eelab_2ememoed_2elam(v_t_24119, heff_get_n(v_e_244, 1, 6), v_t_24120, heff_rec_n(2, shape_stx__val, (V[]){v_t_24122, heff_clo_n(g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_lam16, 1, 1, (V[]){v_x_2412})}), heff_tag_n(TAG_MkAbs, 2, (V[]){v_t_24127, v_x_24115})));
  V f_ = v_k_24114;
  args[0] = v_x_24129;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_lam14(V self, V *args) {
  V v_hd_24113 = args[0];
  V v_k_24114 = args[1];
  V v_c_24112 = heff_env(self)[0];
  V v_e_244 = heff_env(self)[1];
  V v_x_2412 = heff_env(self)[2];
  V v_cod_2421 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_24112;
  args[0] = v_hd_24113;
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_lam15, 1, 4, (V[]){v_e_244, v_x_2412, v_cod_2421, v_k_24114});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_lam12(V self, V *args) {
  V v_v_2485 = args[0];
  V v_scope_27_2486 = args[1];
  V v_sp_240 = heff_env(self)[0];
  V v_x_241 = heff_env(self)[1];
  V v_dom_242 = heff_env(self)[2];
  V v_body_243 = heff_env(self)[3];
  V v_cod_2421 = heff_env(self)[4];
  V v_e_244 = heff_env(self)[5];
  V v_implicit_2422 = heff_env(self)[6];
  V v_fdom_2420 = heff_env(self)[7];
  V v_x_2412 = heff_env(self)[8];
  heff_clo_take(self, 9);
  HeffT1 v_t_2487 = ({ V a_0 = v_sp_240; V a_1 = v_x_241; V a_2 = v_dom_242; V a_3 = v_body_243; HeffT1 r_ = (g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_dom_242); heff_drop(v_body_243); r_; });
  {
    V v_field_2488 = v_t_2487.f[0];
    V v_x1_2494;
    switch (heff_tag_of(v_cod_2421)) {
    case TAG_MkClo: {
      V v_vs_2490 = heff_dup(heff_field(v_cod_2421, 1));
      V v_body_2491 = heff_dup(heff_field(v_cod_2421, 2));
      v_x1_2494 = heff_tr(heff_call(v_body_2491, 1, (V[]){heff_tag_n(TAG_LSnoc, 2, (V[]){v_vs_2490, heff_clo_n(g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_lam13, 1, 1, (V[]){heff_dup(v_v_2485)})})}));
      break;
    }
    case TAG_CloConst: {
      V v_body_2493 = heff_dup(heff_field(v_cod_2421, 0));
      v_x1_2494 = v_body_2493;
      break;
    }
    default: heff_nomatch(v_cod_2421);
    }
    V v_a_2498;
    switch (heff_tag_of(v_x1_2494)) {
    case TAG_Nom: {
      V v_x_2495 = heff_field(v_x1_2494, 0);
      heff_take_n(v_x1_2494, 1ULL, 1);
      v_a_2498 = v_x_2495;
      break;
    }
    case TAG_Describe: {
      heff_take_n(v_x1_2494, 0ULL, 1);
      v_a_2498 = heff_abandon();
      break;
    }
    case TAG_Become: {
      V v_x_2497 = heff_field(v_x1_2494, 0);
      heff_take_n(v_x1_2494, 1ULL, 1);
      v_a_2498 = v_x_2497;
      break;
    }
    default: heff_nomatch(v_x1_2494);
    }
    V v_f_2499 = v_field_2488;
    V v_t_24100 = heff_dup(heff_rfield(v_e_244, 2));
    V v_t_24103;
    switch (heff_tag_of(v_t_24100)) {
    case TAG_ForNominative: {
      v_t_24103 = NTAG(TAG_ForNominative);
      break;
    }
    case TAG_ForDescriptive: {
      V v_h_24101 = heff_field(v_t_24100, 0);
      V v_sp_24102 = heff_field(v_t_24100, 1);
      V v_ru_24t_24100_24ForDescriptive = heff_take_reuse_n(v_t_24100, 3ULL, 2);
      v_t_24103 = heff_tag_at_n(v_ru_24t_24100_24ForDescriptive, TAG_ForDescriptive, 2, (V[]){v_h_24101, heff_tag_n(TAG_SpApp, 2, (V[]){v_sp_24102, heff_dup(v_v_2485)})});
      break;
    }
    default: heff_nomatch(v_t_24100);
    }
    V v_t_24104 = heff_intAdd(heff_dup(heff_rfield(v_e_244, 3)), MK_INT(1LL));
    V v_t_24110;
    switch (heff_tag_of(v_implicit_2422)) {
    case TAG_Expl: {
      heff_drop(v_v_2485);
      heff_drop(v_fdom_2420);
      v_t_24110 = heff_dup(heff_rfield(v_e_244, 5));
      break;
    }
    case TAG_Impl: {
      heff_drop(v_v_2485);
      heff_drop(v_fdom_2420);
      v_t_24110 = heff_dup(heff_rfield(v_e_244, 5));
      break;
    }
    case TAG_Inst: {
      V v_t_24109;
      switch (heff_tag_of(v_cod_2421)) {
      case TAG_MkClo: {
        V v_n_24105 = heff_dup(heff_field(v_cod_2421, 0));
        v_t_24109 = v_n_24105;
        break;
      }
      case TAG_CloConst: {
        v_t_24109 = ((V)&g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_str2);
        break;
      }
      default: heff_nomatch(v_cod_2421);
      }
      v_t_24110 = heff_tag_n(TAG_Cons, 2, (V[]){heff_rec_n(3, shape_name__ty__v, (V[]){v_t_24109, v_fdom_2420, v_v_2485}), heff_dup(heff_rfield(v_e_244, 5))});
      break;
    }
    default: heff_nomatch(v_implicit_2422);
    }
    V v_t_24111 = heff_rec_n(6, shape_scope__globals__elabFor__lams__self__insts, (V[]){v_scope_27_2486, heff_dup(heff_rfield(v_e_244, 1)), v_t_24103, v_t_24104, heff_dup(heff_rfield(v_e_244, 4)), v_t_24110});
    V v_c_24112 = heff_tr(heff_call(v_f_2499, 2, (V[]){v_t_24111, v_a_2498}));
    return heff_clo_n(g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_lam14, 2, 4, (V[]){v_c_24112, v_e_244, v_x_2412, v_cod_2421});
  }
}
V g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_lam2(V self, V *args) {
  V v_x_2412 = args[0];
  V v_sp_240 = heff_env(self)[0];
  V v_hd_246 = heff_env(self)[1];
  V v_k_247 = heff_env(self)[2];
  V v_dom_242 = heff_env(self)[3];
  V v_e_244 = heff_env(self)[4];
  V v_x_241 = heff_env(self)[5];
  V v_body_243 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2413 = (g_heff_2eelab_2evalue_2ebehavior(heff_dup(v_x_2412)));
  switch (heff_tag_of(v_t_2413)) {
  case TAG_LikeU: {
    V v_ru_24t_2413_24LikeU = heff_take_reuse_n(v_t_2413, 0ULL, 1);
    heff_drop(v_x_2412);
    heff_drop(v_dom_242);
    heff_drop_rec(v_e_244, 6);
    heff_drop(v_x_241);
    heff_drop(v_body_243);
    V v_t_2415 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(301LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_str0), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_2416 = heff_tag_at_n(v_ru_24t_2413_24LikeU, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2415})});
    V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
    V v_t_2418 = heff_tr(heff_call(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_2417}));
    V f_ = heff_get_n(v_hd_246, 1, 3);
    heff_room[0] = v_t_2418;
    heff_room[1] = v_k_247;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_LikeFunction: {
    V v_fdom_2420 = heff_field(v_t_2413, 1);
    V v_cod_2421 = heff_field(v_t_2413, 2);
    V v_implicit_2422 = heff_field(v_t_2413, 3);
    heff_take_n(v_t_2413, 14ULL, 4);
    V v_t_2423;
    switch (heff_tag_of(v_implicit_2422)) {
    case TAG_Expl: {
      v_t_2423 = NTAG(TAG_True);
      break;
    }
    case TAG_Impl: {
      v_t_2423 = NTAG(TAG_False);
      break;
    }
    case TAG_Inst: {
      v_t_2423 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_implicit_2422);
    }
    if ((heff_dup(v_t_2423) == NTAG(TAG_True))) {
      heff_drop(v_implicit_2422);
      heff_drop(v_t_2423);
      V v_c_2425;
      switch (heff_tag_of(v_dom_242)) {
      case TAG_MkTyp: {
        V v_f_2424 = heff_field(v_dom_242, 0);
        heff_take_n(v_dom_242, 1ULL, 1);
        v_c_2425 = heff_tr(heff_call(v_f_2424, 1, (V[]){heff_dup(v_e_244)}));
        break;
      }
      default: heff_nomatch(v_dom_242);
      }
      V f_ = v_c_2425;
      heff_room[0] = heff_dup(v_hd_246);
      heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_lam3, 1, 9, (V[]){v_e_244, v_fdom_2420, v_sp_240, v_x_241, v_cod_2421, v_body_243, v_x_2412, v_hd_246, v_k_247});
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    } else {
      heff_drop(v_t_2423);
      V v_t_2484;
      switch (heff_tag_of(v_cod_2421)) {
      case TAG_MkClo: {
        V v_n_2480 = heff_dup(heff_field(v_cod_2421, 0));
        v_t_2484 = v_n_2480;
        break;
      }
      case TAG_CloConst: {
        v_t_2484 = ((V)&g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_str1);
        break;
      }
      default: heff_nomatch(v_cod_2421);
      }
      V v_t_24130 = heff_tr(g_heff_2eelab_2eenvironment_2ewithBound(v_t_2484, heff_dup(v_fdom_2420), heff_dup(heff_rfield(v_e_244, 0)), heff_clo_n(g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_lam12, 2, 9, (V[]){v_sp_240, v_x_241, v_dom_242, v_body_243, v_cod_2421, v_e_244, v_implicit_2422, v_fdom_2420, v_x_2412})));
      V f_ = v_t_24130;
      heff_room[0] = v_hd_246;
      heff_room[1] = v_k_247;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
  }
  case TAG_LikeRecord: {
    heff_take_n(v_t_2413, 0ULL, 3);
    heff_drop(v_x_2412);
    heff_drop(v_dom_242);
    heff_drop_rec(v_e_244, 6);
    heff_drop(v_x_241);
    heff_drop(v_body_243);
    V v_t_24134 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(301LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_str4), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_24135 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24134})});
    V v_t_24136 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24135})});
    V v_t_24137 = heff_tr(heff_call(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_24136}));
    V f_ = heff_get_n(v_hd_246, 1, 3);
    heff_room[0] = v_t_24137;
    heff_room[1] = v_k_247;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_LikeSum: {
    V v_ru_24t_2413_24LikeSum = heff_take_reuse_n(v_t_2413, 0ULL, 1);
    heff_drop(v_x_2412);
    heff_drop(v_dom_242);
    heff_drop_rec(v_e_244, 6);
    heff_drop(v_x_241);
    heff_drop(v_body_243);
    V v_t_24139 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(301LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_str5), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_24140 = heff_tag_at_n(v_ru_24t_2413_24LikeSum, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24139})});
    V v_t_24141 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24140})});
    V v_t_24142 = heff_tr(heff_call(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_24141}));
    V f_ = heff_get_n(v_hd_246, 1, 3);
    heff_room[0] = v_t_24142;
    heff_room[1] = v_k_247;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_LikeInt: {
    heff_drop(v_x_2412);
    heff_drop(v_dom_242);
    heff_drop_rec(v_e_244, 6);
    heff_drop(v_x_241);
    heff_drop(v_body_243);
    V v_t_24143 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(301LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_str6), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_24144 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24143})});
    V v_t_24145 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24144})});
    V v_t_24146 = heff_tr(heff_call(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_24145}));
    V f_ = heff_get_n(v_hd_246, 1, 3);
    heff_room[0] = v_t_24146;
    heff_room[1] = v_k_247;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_LikeFloat: {
    heff_drop(v_x_2412);
    heff_drop(v_dom_242);
    heff_drop_rec(v_e_244, 6);
    heff_drop(v_x_241);
    heff_drop(v_body_243);
    V v_t_24147 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(301LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_str7), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_24148 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24147})});
    V v_t_24149 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24148})});
    V v_t_24150 = heff_tr(heff_call(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_24149}));
    V f_ = heff_get_n(v_hd_246, 1, 3);
    heff_room[0] = v_t_24150;
    heff_room[1] = v_k_247;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_LikeString: {
    heff_drop(v_x_2412);
    heff_drop(v_dom_242);
    heff_drop_rec(v_e_244, 6);
    heff_drop(v_x_241);
    heff_drop(v_body_243);
    V v_t_24151 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(301LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_str8), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_24152 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24151})});
    V v_t_24153 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24152})});
    V v_t_24154 = heff_tr(heff_call(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_24153}));
    V f_ = heff_get_n(v_hd_246, 1, 3);
    heff_room[0] = v_t_24154;
    heff_room[1] = v_k_247;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_LikeRune: {
    heff_drop(v_x_2412);
    heff_drop(v_dom_242);
    heff_drop_rec(v_e_244, 6);
    heff_drop(v_x_241);
    heff_drop(v_body_243);
    V v_t_24155 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(301LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_str9), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_24156 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24155})});
    V v_t_24157 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24156})});
    V v_t_24158 = heff_tr(heff_call(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_24157}));
    V f_ = heff_get_n(v_hd_246, 1, 3);
    heff_room[0] = v_t_24158;
    heff_room[1] = v_k_247;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_LikeArray: {
    V v_ru_24t_2413_24LikeArray = heff_take_reuse_n(v_t_2413, 0ULL, 1);
    heff_drop(v_x_2412);
    heff_drop(v_dom_242);
    heff_drop_rec(v_e_244, 6);
    heff_drop(v_x_241);
    heff_drop(v_body_243);
    V v_t_24160 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(301LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_str10), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_24161 = heff_tag_at_n(v_ru_24t_2413_24LikeArray, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24160})});
    V v_t_24162 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24161})});
    V v_t_24163 = heff_tr(heff_call(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_24162}));
    V f_ = heff_get_n(v_hd_246, 1, 3);
    heff_room[0] = v_t_24163;
    heff_room[1] = v_k_247;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_LikeFixed: {
    V v_ru_24t_2413_24LikeFixed = heff_take_reuse_n(v_t_2413, 0ULL, 1);
    heff_drop(v_x_2412);
    heff_drop(v_dom_242);
    heff_drop_rec(v_e_244, 6);
    heff_drop(v_x_241);
    heff_drop(v_body_243);
    V v_t_24165 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(301LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_str11), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_24166 = heff_tag_at_n(v_ru_24t_2413_24LikeFixed, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24165})});
    V v_t_24167 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24166})});
    V v_t_24168 = heff_tr(heff_call(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_24167}));
    V f_ = heff_get_n(v_hd_246, 1, 3);
    heff_room[0] = v_t_24168;
    heff_room[1] = v_k_247;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_NoRules: {
    heff_drop(v_x_2412);
    heff_drop(v_dom_242);
    heff_drop_rec(v_e_244, 6);
    heff_drop(v_x_241);
    heff_drop(v_body_243);
    V v_t_24169 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(301LL), NTAG(TAG_SError), ((V)&g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_str12), v_sp_240, NTAG(TAG_Nothing)});
    V v_t_24170 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_24169})});
    V v_t_24171 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24170})});
    V v_t_24172 = heff_tr(heff_call(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_24171}));
    V f_ = heff_get_n(v_hd_246, 1, 3);
    heff_room[0] = v_t_24172;
    heff_room[1] = v_k_247;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_t_2413);
  }
}
V g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_lam0(V self, V *args) {
  V v_e_244 = args[0];
  V v_a0_245 = args[1];
  V v_hd_246 = args[2];
  V v_k_247 = args[3];
  V v_sp_240 = heff_env(self)[0];
  V v_dom_242 = heff_env(self)[1];
  V v_x_241 = heff_env(self)[2];
  V v_body_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_lam1, 1, 1, (V[]){v_a0_245})})});
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_246, 2)), 1, (V[]){v_t_2410}));
  V f_ = heff_dup(heff_rfield(v_hd_246, 1));
  args[0] = v_t_2411;
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2efunctionIntroAnn_24cpr_lam2, 1, 7, (V[]){v_sp_240, v_hd_246, v_k_247, v_dom_242, v_e_244, v_x_241, v_body_243});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2eelab_2erules_2edelayedCheck_str0, 5, "this ");
HEFF_LIT(g_heff_2eelab_2erules_2edelayedCheck_str1, 28, " does not fit how it is used");
V g_heff_2eelab_2erules_2edelayedCheck_lam2(V self, V *args);
V g_heff_2eelab_2erules_2edelayedCheck_lam1(V self, V *args);
V g_heff_2eelab_2erules_2edelayedCheck_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2edelayedCheck_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2edelayedCheck_entry, 7, 0};

V g_heff_2eelab_2erules_2edelayedCheck(V v_e_240, V v_sp_241, V v_what_242, V v_c_243, V v_ty_244, V v_m_245, V v_hole_246) {
top: ;
  V v_c_248;
  switch (heff_tag_of(v_c_243)) {
  case TAG_MkChk: {
    V v_f_247 = heff_field(v_c_243, 0);
    v_c_248 = heff_tr(heff_call(heff_dup(v_f_247), 2, (V[]){heff_dup(v_e_240), v_ty_244}));
    break;
  }
  default: heff_nomatch(v_c_243);
  }
  return heff_clo_n(g_heff_2eelab_2erules_2edelayedCheck_lam0, 2, 6, (V[]){v_c_248, v_e_240, v_m_245, v_hole_246, v_what_242, v_sp_241});
}
V g_heff_2eelab_2erules_2edelayedCheck_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2eelab_2erules_2edelayedCheck(a[0], a[1], a[2], a3, a[4], a[5], a[6]); heff_drop(a3); return r;
}
V g_heff_2eelab_2erules_2edelayedCheck_lam2(V self, V *args) {
  V v_x_2419 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_what_242 = heff_env(self)[1];
  V v_sp_241 = heff_env(self)[2];
  V v_hd_249 = heff_env(self)[3];
  V v_k_2410 = heff_env(self)[4];
  heff_clo_take(self, 5);
  switch (heff_tag_of(v_x_2419)) {
  case TAG_Left: {
    V v_err_2420 = heff_field(v_x_2419, 0);
    V v_ru_24x_2419_24Left = heff_take_reuse_n(v_x_2419, 1ULL, 1);
    V v_note_2421 = ({ V a_0 = heff_get_n(v_e_240, 1, 6); V a_1 = v_err_2420; V r_ = (g_heff_2eelab_2erules_2eprettyEqErr(a_0, a_1)); heff_drop(v_err_2420); r_; });
    V v_t_2422 = heff_strAppend(((V)&g_heff_2eelab_2erules_2edelayedCheck_str0), heff_strAppend(v_what_242, ((V)&g_heff_2eelab_2erules_2edelayedCheck_str1)));
    V v_t_2423 = heff_rec_n(5, shape_code__severity__msg__span__note, (V[]){MK_INT(311LL), NTAG(TAG_SError), v_t_2422, v_sp_241, heff_tag_n(TAG_Just, 1, (V[]){v_note_2421})});
    V v_t_2424 = heff_tag_at_n(v_ru_24x_2419_24Left, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2423})});
    V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
    V v_t_2426 = heff_tr(heff_call(heff_take_field(v_hd_249, 2), 1, (V[]){v_t_2425}));
    V f_ = heff_get_n(v_hd_249, 1, 3);
    heff_room[0] = v_t_2426;
    heff_room[1] = v_k_2410;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_Right: {
    heff_take_n(v_x_2419, 0ULL, 1);
    heff_drop_rec(v_e_240, 6);
    heff_drop(v_what_242);
    heff_drop(v_sp_241);
    heff_drop_rec(v_hd_249, 3);
    V f_ = v_k_2410;
    args[0] = NTAG(TAG_MkUnit);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_2419);
  }
}
V g_heff_2eelab_2erules_2edelayedCheck_lam1(V self, V *args) {
  V v_x_2411 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_m_245 = heff_env(self)[1];
  V v_hole_246 = heff_env(self)[2];
  V v_hd_249 = heff_env(self)[3];
  V v_what_242 = heff_env(self)[4];
  V v_sp_241 = heff_env(self)[5];
  V v_k_2410 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_x1_2412 = heff_tr(heff_call(heff_take_field(v_x_2411, 1), 1, (V[]){NTAG(TAG_MkUnit)}));
  V v_t_2416;
  switch (heff_tag_of(v_x1_2412)) {
  case TAG_Nom: {
    V v_x_2413 = heff_field(v_x1_2412, 0);
    heff_take_n(v_x1_2412, 1ULL, 1);
    v_t_2416 = v_x_2413;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2412, 0ULL, 1);
    v_t_2416 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2415 = heff_field(v_x1_2412, 0);
    heff_take_n(v_x1_2412, 1ULL, 1);
    v_t_2416 = v_x_2415;
    break;
  }
  default: heff_nomatch(v_x1_2412);
  }
  V v_c_2417 = heff_dup(heff_rfield(v_e_240, 0));
  V v_t_2418 = heff_rec_n(2, shape_len__names, (V[]){heff_take_field(v_c_2417, 0), heff_get_n(v_c_2417, 1, 4)});
  return (g_heff_2eelab_2erules_2esolveHole(heff_dup(heff_rfield(v_e_240, 1)), v_t_2418, v_m_245, heff_get_n(v_hole_246, 1, 2), heff_get_n(v_x_2411, 0, 2), v_t_2416, heff_dup(v_hd_249), heff_clo_n(g_heff_2eelab_2erules_2edelayedCheck_lam2, 1, 5, (V[]){v_e_240, v_what_242, v_sp_241, v_hd_249, v_k_2410})));
}
V g_heff_2eelab_2erules_2edelayedCheck_lam0(V self, V *args) {
  V v_hd_249 = args[0];
  V v_k_2410 = args[1];
  V v_c_248 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_m_245 = heff_env(self)[2];
  V v_hole_246 = heff_env(self)[3];
  V v_what_242 = heff_env(self)[4];
  V v_sp_241 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V f_ = v_c_248;
  args[0] = heff_dup(v_hd_249);
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2edelayedCheck_lam1, 1, 7, (V[]){v_e_240, v_m_245, v_hole_246, v_hd_249, v_what_242, v_sp_241, v_k_2410});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}

HeffT2 g_heff_2eelab_2erules_2elookupP_24cpr(V v_x1_240, V v_x_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_x11_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_MkPair: {
      V v_y_244 = heff_field(v_x11_242, 0);
      V v_v_245 = heff_field(v_x11_242, 1);
      heff_take_n(v_x11_242, 3ULL, 2);
      if (heff_strEq_c_lent(v_y_244, v_x_241, 1)) {
        heff_drop(v_rest_243);
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_v_245}});
      } else {
        heff_drop(v_v_245);
        V t_0 = v_rest_243;
        V t_1 = v_x_241;
        v_x1_240 = t_0;
        v_x_241 = t_1;
        goto top;
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x11_242)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
Clo g_heff_2eelab_2erules_2eletsAround_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2eletsAround_entry, 5, 0};

V g_heff_2eelab_2erules_2eletsAround(V v_n_240, V v_a_241, V v_x3_242, V v_p_243, V v_body_244) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_n_240);
    heff_drop(v_a_241);
    heff_drop(v_p_243);
    return v_body_244;
  }
  case TAG_Cons: {
    V v_x31_245 = heff_field(v_x3_242, 0);
    V v_rest_246 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    switch (heff_tag_of(v_x31_245)) {
    case TAG_MkPair: {
      V v_m_247 = heff_field(v_x31_245, 0);
      V v_v_248 = heff_field(v_x31_245, 1);
      V v_ru_24x31_245_24MkPair = heff_take_reuse_n(v_x31_245, 3ULL, 2);
      V v_t_249 = (g_heff_2eelab_2evalue_2elevelOf(v_a_241));
      V v_t_2410 = (g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(heff_intAdd(heff_dup(v_n_240), heff_dup(v_p_243)), heff_take_field(v_m_247, 1)));
      V v_t_2411 = (g_heff_2eelab_2ereadback_2ereadbTypeF_24s385067166x155164276(heff_intAdd(heff_dup(v_n_240), heff_dup(v_p_243)), heff_dup(v_a_241)));
      V v_t_2412 = heff_tag_n(TAG_SFunction, 5, (V[]){v_t_249, v_t_2410, heff_tag_n(TAG_AbsConst, 1, (V[]){v_t_2411}), NTAG(TAG_Expl), NTAG(TAG_Nothing)});
      V v_t_2413 = (g_heff_2eelab_2erules_2eletsAround(v_n_240, v_a_241, v_rest_246, heff_intAdd(v_p_243, MK_INT(1LL)), v_body_244));
      V v_t_2414 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_MkAbs, 2, (V[]){heff_get_n(v_m_247, 0, 5), v_t_2413});
      return heff_tag_at_n(v_ru_24x31_245_24MkPair, TAG_SApp, 2, (V[]){heff_tag_n(TAG_SLam, 2, (V[]){v_t_2412, v_t_2414}), v_v_248});
    }
    default: return heff_nomatch(v_x31_245);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2eelab_2erules_2eletsAround_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erules_2eletsAround(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2eelab_2erules_2ecasesAt_lam2(V self, V *args);
V g_heff_2eelab_2erules_2ecasesAt_lam4(V self, V *args); static Clo g_heff_2eelab_2erules_2ecasesAt_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2ecasesAt_lam4, 1, 0};
V g_heff_2eelab_2erules_2ecasesAt_lam3(V self, V *args);
V g_heff_2eelab_2erules_2ecasesAt_lam1(V self, V *args);
V g_heff_2eelab_2erules_2ecasesAt_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2ecasesAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2ecasesAt_entry, 10, 0};

V g_heff_2eelab_2erules_2ecasesAt(V v_sp_240, V v_e_241, V v_b_242, V v_scrut_243, V v_a_244, V v_vs_245, V v_tags_246, V v_casesChk_247, V v_z_248, V v_z_249) {
top: ;
  V v_c_2410 = (g_heff_2eelab_2erules_2erecordTags(heff_dup(v_e_241), heff_dup(v_a_244), heff_dup(v_vs_245), v_tags_246));
  return heff_tail(v_c_2410, 2, (V[]){heff_dup(v_z_248), heff_clo_n(g_heff_2eelab_2erules_2ecasesAt_lam0, 1, 10, (V[]){v_e_241, v_a_244, v_vs_245, heff_dup(v_tags_246), v_z_248, v_sp_240, v_b_242, v_casesChk_247, v_scrut_243, v_z_249})});
}
V g_heff_2eelab_2erules_2ecasesAt_entry(V self, V *a) {
  (void)self;
  V a6 = a[6]; V r = g_heff_2eelab_2erules_2ecasesAt(a[0], a[1], a[2], a[3], a[4], a[5], a6, a[7], a[8], a[9]); heff_drop(a6); return r;
}
V g_heff_2eelab_2erules_2ecasesAt_lam2(V self, V *args) {
  V v_p_2417 = args[0];
  V v_sp_240 = heff_env(self)[0];
  V v_e_241 = heff_env(self)[1];
  V v_b_242 = heff_env(self)[2];
  V v_a_244 = heff_env(self)[3];
  V v_casesChk_247 = heff_env(self)[4];
  heff_clo_take(self, 5);
  switch (heff_tag_of(v_p_2417)) {
  case TAG_MkPair: {
    V v_x_2418 = heff_field(v_p_2417, 0);
    V v_ts_2419 = heff_field(v_p_2417, 1);
    heff_take_n(v_p_2417, 3ULL, 2);
    return ({ V a_0 = v_sp_240; V a_1 = v_e_241; V a_2 = v_b_242; V a_3 = v_a_244; V a_4 = v_x_2418; V a_5 = heff_arrayToList(v_ts_2419); V a_6 = v_casesChk_247; V r_ = (g_heff_2eelab_2erules_2ecaseArm(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_a_244); r_; });
  }
  default: return heff_nomatch(v_p_2417);
  }
}
V g_heff_2eelab_2erules_2ecasesAt_lam4(V self, V *args) {
  V v_u_2427 = args[0];
  heff_drop(v_u_2427);
  return heff_tag_n(TAG_Nom, 1, (V[]){NTAG(TAG_VOpaque)});
}
V g_heff_2eelab_2erules_2ecasesAt_lam3(V self, V *args) {
  V v_x_2421 = args[0];
  V v_scrut_243 = heff_env(self)[0];
  V v_z_249 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2422 = (g_list_2emap_24s1937570095x2110149801(heff_dup(v_x_2421)));
  V v_t_2423 = (g_heff_2eutil_2edict_2eindexed(MK_INT(0LL), v_x_2421));
  V v_t_2424 = (g_list_2emap_24s1173914895x100384474(v_x_2421));
  V v_cases_2425 = heff_rec_n(3, shape_keys__byName__values, (V[]){heff_arrayFromList(v_t_2422), v_t_2423, heff_arrayFromList(v_t_2424)});
  V v_t_2426 = heff_tag_n(TAG_SMatch, 2, (V[]){heff_get_n(v_scrut_243, 0, 2), v_cases_2425});
  V f_ = v_z_249;
  args[0] = heff_rec_n(2, shape_stx__val, (V[]){v_t_2426, ((V)&g_heff_2eelab_2erules_2ecasesAt_lam4_clo)});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erules_2ecasesAt_lam1(V self, V *args) {
  V v_x_2413 = args[0];
  V v_vs_245 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  V v_e_241 = heff_env(self)[2];
  V v_b_242 = heff_env(self)[3];
  V v_a_244 = heff_env(self)[4];
  V v_casesChk_247 = heff_env(self)[5];
  V v_z_248 = heff_env(self)[6];
  V v_scrut_243 = heff_env(self)[7];
  V v_z_249 = heff_env(self)[8];
  heff_clo_take(self, 9);
  heff_drop(v_x_2413);
  V v_t_2414 = heff_arrayToList(heff_take_field(v_vs_245, 0));
  V v_t_2415 = heff_arrayToList(heff_get_n(v_vs_245, 2, 3));
  V v_t_2416 = (g_heff_2eutil_2edict_2ezipKV(v_t_2414, v_t_2415));
  V v_c_2420 = (g_prelude_2etraverse_24s1934076392x614790049(heff_clo_n(g_heff_2eelab_2erules_2ecasesAt_lam2, 1, 5, (V[]){v_sp_240, v_e_241, v_b_242, v_a_244, v_casesChk_247}), v_t_2416));
  V f_ = v_c_2420;
  heff_room[0] = v_z_248;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2ecasesAt_lam3, 1, 2, (V[]){v_scrut_243, v_z_249});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2ecasesAt_lam0(V self, V *args) {
  V v_x_2411 = args[0];
  V v_e_241 = heff_env(self)[0];
  V v_a_244 = heff_env(self)[1];
  V v_vs_245 = heff_env(self)[2];
  V v_tags_246 = heff_env(self)[3];
  V v_z_248 = heff_env(self)[4];
  V v_sp_240 = heff_env(self)[5];
  V v_b_242 = heff_env(self)[6];
  V v_casesChk_247 = heff_env(self)[7];
  V v_scrut_243 = heff_env(self)[8];
  V v_z_249 = heff_env(self)[9];
  heff_clo_take(self, 10);
  heff_drop(v_x_2411);
  V v_c_2412 = ({ V a_0 = heff_dup(v_e_241); V a_1 = heff_dup(v_a_244); V a_2 = heff_dup(v_vs_245); V a_3 = v_tags_246; V r_ = (g_heff_2eelab_2erules_2etagsExposed(a_0, a_1, a_2, a_3)); heff_drop(v_tags_246); r_; });
  V f_ = v_c_2412;
  heff_room[0] = heff_dup(v_z_248);
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2ecasesAt_lam1, 1, 9, (V[]){v_vs_245, v_sp_240, v_e_241, v_b_242, v_a_244, v_casesChk_247, v_z_248, v_scrut_243, v_z_249});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}

HeffT2 g_heff_2eelab_2erules_2eupdateInner_24cpr(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), NTAG(TAG_Nil)}});
  }
  case TAG_Cons: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_UpdateTo: {
      heff_take_n(v_x11_241, 0ULL, 4);
      heff_drop(v_rest_242);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_UpdateIn: {
      V v_fs_2410 = heff_field(v_x11_241, 3);
      heff_take_n(v_x11_241, 8ULL, 4);
      HeffT2 v_t_2411 = (g_heff_2eelab_2erules_2eupdateInner_24cpr(v_rest_242));
      {
        V v_field_2413 = v_t_2411.f[1];
        int64_t v_tag_2412 = ((int64_t)v_t_2411.f[0]);
        if ((v_tag_2412 == ((int64_t)0ULL))) {
          V v_more_2415 = v_field_2413;
          V v_f_2416 = (g_heff_2eelab_2erules_2eappendP(v_fs_2410, v_more_2415));
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2416}});
        } else {
          heff_drop(v_fs_2410);
          heff_drop(v_field_2413);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        }
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x11_241)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
V g_heff_2eelab_2erules_2euniverseIntro_lam1(V self, V *args);
V g_heff_2eelab_2erules_2euniverseIntro_lam3(V self, V *args);
V g_heff_2eelab_2erules_2euniverseIntro_lam2(V self, V *args);
V g_heff_2eelab_2erules_2euniverseIntro_lam0(V self, V *args);
Clo g_heff_2eelab_2erules_2euniverseIntro_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erules_2euniverseIntro_entry, 2, 0};

V g_heff_2eelab_2erules_2euniverseIntro(V v_sp_240, V v_typ_241) {
top: ;
  return heff_tag_n(TAG_MkChk, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2euniverseIntro_lam0, 4, 2, (V[]){heff_dup(v_typ_241), v_sp_240})});
}
V g_heff_2eelab_2erules_2euniverseIntro_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2erules_2euniverseIntro(a[0], a1); heff_drop(a1); return r;
}
V g_heff_2eelab_2erules_2euniverseIntro_lam1(V self, V *args) {
  V v_c_246 = args[0];
  V v_a0_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_c_246, 3, 8); V a_1 = v_a0_243; V r_ = (g_heff_2eelab_2evalue_2eforceTy(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2eelab_2erules_2euniverseIntro_lam3(V self, V *args) {
  V v_x_2413 = args[0];
  V v_sp_240 = heff_env(self)[0];
  V v_e_242 = heff_env(self)[1];
  V v_x_2410 = heff_env(self)[2];
  V v_hd_244 = heff_env(self)[3];
  V v_k_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2eelab_2erules_2euniverseAt(v_sp_240, NTAG(TAG_Nothing), v_e_242, v_x_2410, v_x_2413, v_hd_244, v_k_245));
}
V g_heff_2eelab_2erules_2euniverseIntro_lam2(V self, V *args) {
  V v_x_2410 = args[0];
  V v_typ_241 = heff_env(self)[0];
  V v_e_242 = heff_env(self)[1];
  V v_hd_244 = heff_env(self)[2];
  V v_sp_240 = heff_env(self)[3];
  V v_k_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_c_2412;
  switch (heff_tag_of(v_typ_241)) {
  case TAG_MkTyp: {
    V v_f_2411 = heff_field(v_typ_241, 0);
    heff_take_n(v_typ_241, 1ULL, 1);
    v_c_2412 = heff_tr(heff_call(v_f_2411, 1, (V[]){heff_dup(v_e_242)}));
    break;
  }
  default: heff_nomatch(v_typ_241);
  }
  V f_ = v_c_2412;
  heff_room[0] = heff_dup(v_hd_244);
  heff_room[1] = heff_clo_n(g_heff_2eelab_2erules_2euniverseIntro_lam3, 1, 5, (V[]){v_sp_240, v_e_242, v_x_2410, v_hd_244, v_k_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2erules_2euniverseIntro_lam0(V self, V *args) {
  V v_e_242 = args[0];
  V v_a0_243 = args[1];
  V v_hd_244 = args[2];
  V v_k_245 = args[3];
  V v_typ_241 = heff_env(self)[0];
  V v_sp_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2erules_2euniverseIntro_lam1, 1, 1, (V[]){v_a0_243})})});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_244, 2)), 1, (V[]){v_t_248}));
  V f_ = heff_dup(heff_rfield(v_hd_244, 1));
  args[0] = v_t_249;
  args[1] = heff_clo_n(g_heff_2eelab_2erules_2euniverseIntro_lam2, 1, 5, (V[]){v_typ_241, v_e_242, v_hd_244, v_sp_240, v_k_245});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}