// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EVar 52881
#define TAG_F32 16337
#define TAG_FtAny 18156
#define TAG_FtFixed 23584
#define TAG_FtFloat 38674
#define TAG_FtOther 63706
#define TAG_I16 19162
#define TAG_I32 19220
#define TAG_I64 19315
#define TAG_I8 9088
#define TAG_MkArm 55352
#define TAG_U16 30694
#define TAG_U32 30752
#define TAG_U64 30847
#define TAG_U8 9460
#define LBL_body 9524841
#define LBL_key 315609
#define LBL_l 326
#define LBL_name 9869138
#define LBL_r 332
#define LBL_sh 10428
#define LBL_t 334
#define LBL_v 336
#define LBL_x 338
static uint32_t shape_key__name__body[] = {LBL_key, LBL_name, LBL_body};
static uint32_t shape_r__x[] = {LBL_r, LBL_x};
static uint32_t shape_v__l__sh__t[] = {LBL_v, LBL_l, LBL_sh, LBL_t};
V g_heff_2ecompile_2eearly_2earmRead_24s208354557x207572461(V, V);
V g_heff_2ecompile_2eearly_2earmRead_24s208354557x207572461_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eearly_2earmRead_24s208354557x207572461_clo;
V g_heff_2ecompile_2eearly_2eatBinding(V, V, V, V);
V g_heff_2ecompile_2eearly_2eatBinding_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eearly_2eatBinding_clo;
V g_heff_2ecompile_2eearly_2eatEnd(V, V);
V g_heff_2ecompile_2eearly_2eatEnd_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eearly_2eatEnd_clo;
V g_heff_2ecompile_2eearly_2eatMatch(V, V, V);
V g_heff_2ecompile_2eearly_2eatMatch_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eearly_2eatMatch_clo;
V g_heff_2ecompile_2eearly_2ecallsW(V);
V g_heff_2ecompile_2eearly_2ecallsW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eearly_2ecallsW_clo;
HeffT2 g_heff_2ecompile_2eearly_2ecutGo_24cpr(V, V);
HeffT2 g_heff_2ecompile_2eearly_2eearlyAt_24cpr(V, V, V);
V g_heff_2ecompile_2eearly_2eearlyDef(V);
V g_heff_2ecompile_2eearly_2eearlyDef_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eearly_2eearlyDef_clo;
V g_heff_2ecompile_2eearly_2eelemE(V, V);
V g_heff_2ecompile_2eearly_2eelemE_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eearly_2eelemE_clo;
V g_heff_2ecompile_2eearly_2eisNumber(V);
V g_heff_2ecompile_2eearly_2eisNumber_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eearly_2eisNumber_clo;
V g_heff_2ecompile_2eearly_2ekidsWith(V, V);
V g_heff_2ecompile_2eearly_2ekidsWith_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eearly_2ekidsWith_clo;
V g_heff_2ecompile_2eearly_2eletsEarly(V, V);
V g_heff_2ecompile_2eearly_2eletsEarly_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eearly_2eletsEarly_clo;
V g_heff_2ecompile_2eearly_2eletsEarly_24dps(V, V, V);
V g_heff_2ecompile_2eearly_2eletsEarly_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eearly_2eletsEarly_24dps_clo;
V g_heff_2ecompile_2eearly_2eletsOf(V, V);
V g_heff_2ecompile_2eearly_2eletsOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eearly_2eletsOf_clo;
V g_heff_2ecompile_2eearly_2eletsOf_24dps(V, V, V);
V g_heff_2ecompile_2eearly_2eletsOf_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eearly_2eletsOf_24dps_clo;
V g_heff_2ecompile_2eearly_2enumbersW(V);
V g_heff_2ecompile_2eearly_2enumbersW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eearly_2enumbersW_clo;
V g_heff_2ecompile_2eearly_2eownField(V, V, V);
V g_heff_2ecompile_2eearly_2eownField_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eearly_2eownField_clo;
V g_heff_2ecompile_2eearly_2eprojRead(V, V, V, V, V);
V g_heff_2ecompile_2eearly_2eprojRead_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eearly_2eprojRead_clo;
V g_heff_2ecompile_2eearly_2eprojW(V, V, V);
V g_heff_2ecompile_2eearly_2eprojW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eearly_2eprojW_clo;
V g_heff_2ecompile_2eearly_2epushKids(V, V, V);
V g_heff_2ecompile_2eearly_2epushKids_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eearly_2epushKids_clo;
V g_heff_2ecompile_2eearly_2ereadGo(V, V);
V g_heff_2ecompile_2eearly_2ereadGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eearly_2ereadGo_clo;
V g_heff_2ecompile_2eearly_2ereadGo_24dps(V, V, V, V);
V g_heff_2ecompile_2eearly_2ereadGo_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eearly_2ereadGo_24dps_clo;
V g_heff_2ecompile_2eearly_2ereadOfE(V);
V g_heff_2ecompile_2eearly_2ereadOfE_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eearly_2ereadOfE_clo;
HeffT2 g_heff_2ecompile_2eearly_2ereadOfE_24cpr(V);
V g_heff_2ecompile_2eearly_2ereadsEarly(V, V, V, V, V);
V g_heff_2ecompile_2eearly_2ereadsEarly_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eearly_2ereadsEarly_clo;
V g_heff_2ecompile_2eearly_2ereadsOnce(V, V);
V g_heff_2ecompile_2eearly_2ereadsOnce_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eearly_2ereadsOnce_clo;
V g_heff_2ecompile_2eearly_2ereadsW(V, V);
V g_heff_2ecompile_2eearly_2ereadsW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eearly_2ereadsW_clo;
V g_heff_2ecompile_2eearly_2erebuilds(V, V);
V g_heff_2ecompile_2eearly_2erebuilds_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eearly_2erebuilds_clo;
V g_heff_2ecompile_2eearly_2erebuiltW(V, V);
V g_heff_2ecompile_2eearly_2erebuiltW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eearly_2erebuiltW_clo;
V g_heff_2ecompile_2eearly_2esameLabels(V, V);
V g_heff_2ecompile_2eearly_2esameLabels_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eearly_2esameLabels_clo;
HeffT2 g_heff_2ecompile_2eearly_2espineOf_24cpr(V);
V g_heff_2ecompile_2eearly_2etraverseS(V, V);
V g_heff_2ecompile_2eearly_2etraverseS_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eearly_2etraverseS_clo;
V g_heff_2ecompile_2eearly_2etraverseS_24s1904693382x1197638938(V);
V g_heff_2ecompile_2eearly_2etraverseS_24s1904693382x1197638938_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eearly_2etraverseS_24s1904693382x1197638938_clo;
HeffT2 g_heff_2ecompile_2eearly_2etraverseS_24s282732620x734369920_24cpr(V, V);
V g_heff_2ecompile_2eearly_2ewalk(V, V);
V g_heff_2ecompile_2eearly_2ewalk_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eearly_2ewalk_clo;
V g_heff_2ecompile_2eir_2eappendI(V, V);
V g_heff_2ecompile_2eir_2eappendI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eappendI_clo;
V g_heff_2ecompile_2eir_2ecountW(V, V, V);
V g_heff_2ecompile_2eir_2ecountW_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2ecountW_clo;
V g_heff_2ecompile_2eir_2epushArms(V, V);
V g_heff_2ecompile_2eir_2epushArms_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2epushArms_clo;
V g_heff_2ecompile_2eir_2epushFields(V, V);
V g_heff_2ecompile_2eir_2epushFields_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2epushFields_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2eany_24s1658412854x30850816(V, V);
V g_list_2eany_24s1658412854x30850816_entry(V self, V *a);
extern Clo g_list_2eany_24s1658412854x30850816_clo;
V g_list_2efilter(V, V);
V g_list_2efilter_entry(V self, V *a);
extern Clo g_list_2efilter_clo;
V g_list_2efoldl_24f2107672210x353362204(V, V, V, V);
V g_list_2efoldl_24f2107672210x353362204_entry(V self, V *a);
extern Clo g_list_2efoldl_24f2107672210x353362204_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1530401830x609500251(V, V);
V g_list_2efoldl_24s1530401830x609500251_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1530401830x609500251_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1173914895x100384474(V);
V g_list_2emap_24s1173914895x100384474_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_clo;
V g_list_2emap_24s1937570095x2110149801(V);
V g_list_2emap_24s1937570095x2110149801_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_clo;
V g_list_2emap_24s60612435x257154841(V);
V g_list_2emap_24s60612435x257154841_entry(V self, V *a);
extern Clo g_list_2emap_24s60612435x257154841_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24f1085359736x1262841716(V, V);
V g_prelude_2e_2b_2b_24f1085359736x1262841716_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24f1085359736x1262841716_clo;
V g_heff_2ecompile_2eearly_2etraverseS_lam0(V self, V *args); static Clo g_heff_2ecompile_2eearly_2etraverseS_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eearly_2etraverseS_lam0, 1, 0};
V g_heff_2ecompile_2eearly_2etraverseS_lam1(V self, V *args);
Clo g_heff_2ecompile_2eearly_2etraverseS_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eearly_2etraverseS_entry, 2, 0};

V g_heff_2ecompile_2eearly_2etraverseS(V v_f_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_f_240);
    return ((V)&g_heff_2ecompile_2eearly_2etraverseS_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_m_245 = heff_tr(heff_call(heff_dup(v_f_240), 1, (V[]){v_x_243}));
    return heff_clo_n(g_heff_2ecompile_2eearly_2etraverseS_lam1, 1, 3, (V[]){v_m_245, v_f_240, v_xs_244});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eearly_2etraverseS_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eearly_2etraverseS(a[0], a[1]);
}
V g_heff_2ecompile_2eearly_2etraverseS_lam0(V self, V *args) {
  V v_n_242 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_n_242});
}
V g_heff_2ecompile_2eearly_2etraverseS_lam1(V self, V *args) {
  V v_n_246 = args[0];
  V v_m_245 = heff_env(self)[0];
  V v_f_240 = heff_env(self)[1];
  V v_xs_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_247 = heff_tr(heff_call(v_m_245, 1, (V[]){v_n_246}));
  switch (heff_tag_of(v_x2_247)) {
  case TAG_MkPair: {
    V v_x_248 = heff_field(v_x2_247, 0);
    V v_n_249 = heff_field(v_x2_247, 1);
    V v_ru_24x2_247_24MkPair = heff_take_reuse_n(v_x2_247, 3ULL, 2);
    V v_m_2410 = (g_heff_2ecompile_2eearly_2etraverseS(v_f_240, v_xs_244));
    V v_x2_2411 = heff_tr(heff_call(v_m_2410, 1, (V[]){v_n_249}));
    switch (heff_tag_of(v_x2_2411)) {
    case TAG_MkPair: {
      V v_x_2412 = heff_field(v_x2_2411, 0);
      V v_n_2413 = heff_field(v_x2_2411, 1);
      heff_take_n(v_x2_2411, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_247_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_x_248, v_x_2412}), v_n_2413});
    }
    default: return heff_nomatch(v_x2_2411);
    }
  }
  default: return heff_nomatch(v_x2_247);
  }
}
Clo g_heff_2ecompile_2eearly_2eelemE_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eearly_2eelemE_entry, 2, 0};

V g_heff_2ecompile_2eearly_2eelemE(V v_x_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_x_240);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_y_242 = heff_field(v_x2_241, 0);
    V v_ys_243 = heff_field(v_x2_241, 1);
    if (heff_strEq_c_lent(v_x_240, v_y_242, 0)) {
      heff_drop(v_x_240);
      return NTAG(TAG_True);
    } else {
      V t_0 = v_x_240;
      V t_1 = v_ys_243;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eearly_2eelemE_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2eearly_2eelemE(a[0], a1); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2eearly_2esameLabels_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eearly_2esameLabels_entry, 2, 0};

V g_heff_2ecompile_2eearly_2esameLabels(V v_x1_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      return NTAG(TAG_True);
    }
    case TAG_Cons: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  case TAG_Cons: {
    V v_a_244 = heff_field(v_x1_240, 0);
    V v_as_245 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      return NTAG(TAG_False);
    }
    case TAG_Cons: {
      V v_b_246 = heff_field(v_x2_241, 0);
      V v_bs_247 = heff_field(v_x2_241, 1);
      if (heff_strEq_c_lent(v_a_244, v_b_246, 0)) {
        V t_0 = v_as_245;
        V t_1 = v_bs_247;
        v_x1_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      } else {
        return NTAG(TAG_False);
      }
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eearly_2esameLabels_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2eearly_2esameLabels(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2eearly_2epushKids_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eearly_2epushKids_entry, 3, 0};

V g_heff_2ecompile_2eearly_2epushKids(V v_lams_240, V v_x2_241, V v_rest_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_EVar: {
    heff_take_n(v_x2_241, 0ULL, 1);
    return v_rest_242;
  }
  case TAG_EGlobal: {
    heff_take_n(v_x2_241, 0ULL, 1);
    return v_rest_242;
  }
  case TAG_ELam: {
    V v_b_246 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24ELam = heff_take_reuse_n(v_x2_241, 2ULL, 2);
    if ((heff_dup(v_lams_240) == NTAG(TAG_True))) {
      return heff_tag_at_n(v_ru_24x2_241_24ELam, TAG_Cons, 2, (V[]){v_b_246, v_rest_242});
    } else {
      heff_drop(v_b_246);
      heff_drop_cell(v_ru_24x2_241_24ELam, 2);
      return v_rest_242;
    }
  }
  case TAG_EApp: {
    V v_f_247 = heff_field(v_x2_241, 0);
    V v_as_248 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24EApp = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_249 = (g_heff_2ecompile_2eir_2eappendI(v_as_248, v_rest_242));
    return heff_tag_at_n(v_ru_24x2_241_24EApp, TAG_Cons, 2, (V[]){v_f_247, v_t_249});
  }
  case TAG_ELet: {
    V v_a_2411 = heff_field(v_x2_241, 1);
    V v_b_2412 = heff_field(v_x2_241, 2);
    heff_take_n(v_x2_241, 6ULL, 3);
    return heff_tag_n(TAG_Cons, 2, (V[]){v_a_2411, heff_tag_n(TAG_Cons, 2, (V[]){v_b_2412, v_rest_242})});
  }
  case TAG_ERecord: {
    V v_fs_2413 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 2);
    return (g_heff_2ecompile_2eir_2epushFields(v_fs_2413, v_rest_242));
  }
  case TAG_EProj: {
    V v_e_2415 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 4);
    return heff_tag_n(TAG_Cons, 2, (V[]){v_e_2415, v_rest_242});
  }
  case TAG_ETag: {
    V v_as_2420 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 2ULL, 3);
    return (g_heff_2ecompile_2eir_2eappendI(v_as_2420, v_rest_242));
  }
  case TAG_EMatch: {
    V v_s_2422 = heff_field(v_x2_241, 0);
    V v_arms_2423 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24EMatch = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_2424 = (g_heff_2ecompile_2eir_2epushArms(v_arms_2423, v_rest_242));
    return heff_tag_at_n(v_ru_24x2_241_24EMatch, TAG_Cons, 2, (V[]){v_s_2422, v_t_2424});
  }
  case TAG_EPrim: {
    heff_take_n(v_x2_241, 0ULL, 1);
    return v_rest_242;
  }
  case TAG_EPrimCall: {
    V v_as_2427 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 2ULL, 2);
    return (g_heff_2ecompile_2eir_2eappendI(v_as_2427, v_rest_242));
  }
  case TAG_ECall: {
    V v_as_2429 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 2ULL, 2);
    return (g_heff_2ecompile_2eir_2eappendI(v_as_2429, v_rest_242));
  }
  case TAG_EInt: {
    heff_take_n(v_x2_241, 0ULL, 1);
    return v_rest_242;
  }
  case TAG_EFloat: {
    heff_take_na(v_x2_241, 0ULL, 1);
    return v_rest_242;
  }
  case TAG_EStr: {
    heff_take_n(v_x2_241, 0ULL, 1);
    return v_rest_242;
  }
  case TAG_EBytes: {
    heff_take_n(v_x2_241, 0ULL, 1);
    return v_rest_242;
  }
  case TAG_EFixed: {
    heff_take_n(v_x2_241, 0ULL, 2);
    return v_rest_242;
  }
  case TAG_EFloat32: {
    heff_take_na(v_x2_241, 0ULL, 1);
    return v_rest_242;
  }
  case TAG_EAbandon: {
    return v_rest_242;
  }
  case TAG_EFix: {
    heff_take_n(v_x2_241, 0ULL, 2);
    return v_rest_242;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eearly_2epushKids_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eearly_2epushKids(a0, a[1], a[2]); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2eearly_2ecallsW_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eearly_2ecallsW_entry, 1, 0};

V g_heff_2ecompile_2eearly_2ecallsW(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_e_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 3ULL, 2);
    V v_t_2437;
    switch (heff_tag_of(v_e_241)) {
    case TAG_EVar: {
      v_t_2437 = NTAG(TAG_False);
      break;
    }
    case TAG_EGlobal: {
      v_t_2437 = NTAG(TAG_False);
      break;
    }
    case TAG_ELam: {
      v_t_2437 = NTAG(TAG_False);
      break;
    }
    case TAG_EApp: {
      v_t_2437 = NTAG(TAG_True);
      break;
    }
    case TAG_ELet: {
      v_t_2437 = NTAG(TAG_False);
      break;
    }
    case TAG_ERecord: {
      v_t_2437 = NTAG(TAG_False);
      break;
    }
    case TAG_EProj: {
      v_t_2437 = NTAG(TAG_False);
      break;
    }
    case TAG_ETag: {
      v_t_2437 = NTAG(TAG_False);
      break;
    }
    case TAG_EMatch: {
      v_t_2437 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrim: {
      v_t_2437 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrimCall: {
      v_t_2437 = NTAG(TAG_False);
      break;
    }
    case TAG_ECall: {
      v_t_2437 = NTAG(TAG_True);
      break;
    }
    case TAG_EInt: {
      v_t_2437 = NTAG(TAG_False);
      break;
    }
    case TAG_EFloat: {
      v_t_2437 = NTAG(TAG_False);
      break;
    }
    case TAG_EStr: {
      v_t_2437 = NTAG(TAG_False);
      break;
    }
    case TAG_EBytes: {
      v_t_2437 = NTAG(TAG_False);
      break;
    }
    case TAG_EFixed: {
      v_t_2437 = NTAG(TAG_False);
      break;
    }
    case TAG_EFloat32: {
      v_t_2437 = NTAG(TAG_False);
      break;
    }
    case TAG_EAbandon: {
      v_t_2437 = NTAG(TAG_False);
      break;
    }
    case TAG_EFix: {
      v_t_2437 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_e_241);
    }
    if ((heff_dup(v_t_2437) == NTAG(TAG_True))) {
      heff_drop(v_e_241);
      heff_drop(v_rest_242);
      heff_drop(v_t_2437);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_2437);
      V v_t_2438 = ({ V b_0 = NTAG(TAG_False); V a_1 = v_e_241; V a_2 = v_rest_242; V r_ = (g_heff_2ecompile_2eearly_2epushKids(b_0, a_1, a_2)); heff_drop(b_0); r_; });
      V t_0 = v_t_2438;
      v_x1_240 = t_0;
      goto top;
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eearly_2ecallsW_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eearly_2ecallsW(a[0]);
}

HeffT2 g_heff_2ecompile_2eearly_2ereadOfE_24cpr(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_EVar: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EGlobal: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ELam: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EApp: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ELet: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ERecord: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EProj: {
    V v_e_2412 = heff_field(v_x1_240, 0);
    V v_l_2413 = heff_field(v_x1_240, 1);
    V v_sh_2414 = heff_field(v_x1_240, 2);
    V v_t_2415 = heff_field(v_x1_240, 3);
    heff_take_n(v_x1_240, 15ULL, 4);
    V v_t_2451;
    switch (heff_tag_of(v_e_2412)) {
    case TAG_EVar: {
      V v_v_2416 = heff_field(v_e_2412, 0);
      V v_ru_24e_2412_24EVar = heff_take_reuse_n(v_e_2412, 1ULL, 1);
      V v_t_2417 = heff_rec_n(4, shape_v__l__sh__t, (V[]){v_v_2416, v_l_2413, NTAG(TAG_Nil), NTAG(TAG_FtAny)});
      v_t_2451 = heff_tag_at_n(v_ru_24e_2412_24EVar, TAG_Just, 1, (V[]){v_t_2417});
      break;
    }
    case TAG_EGlobal: {
      heff_take_n(v_e_2412, 0ULL, 1);
      heff_drop(v_l_2413);
      v_t_2451 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_ELam: {
      heff_take_n(v_e_2412, 0ULL, 2);
      heff_drop(v_l_2413);
      v_t_2451 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EApp: {
      heff_take_n(v_e_2412, 0ULL, 2);
      heff_drop(v_l_2413);
      v_t_2451 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_ELet: {
      heff_take_n(v_e_2412, 0ULL, 3);
      heff_drop(v_l_2413);
      v_t_2451 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_ERecord: {
      heff_take_n(v_e_2412, 0ULL, 2);
      heff_drop(v_l_2413);
      v_t_2451 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EProj: {
      heff_take_n(v_e_2412, 0ULL, 4);
      heff_drop(v_l_2413);
      v_t_2451 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_ETag: {
      heff_take_n(v_e_2412, 0ULL, 3);
      heff_drop(v_l_2413);
      v_t_2451 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EMatch: {
      heff_take_n(v_e_2412, 0ULL, 2);
      heff_drop(v_l_2413);
      v_t_2451 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EPrim: {
      heff_take_n(v_e_2412, 0ULL, 1);
      heff_drop(v_l_2413);
      v_t_2451 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EPrimCall: {
      heff_take_n(v_e_2412, 0ULL, 2);
      heff_drop(v_l_2413);
      v_t_2451 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_ECall: {
      heff_take_n(v_e_2412, 0ULL, 2);
      heff_drop(v_l_2413);
      v_t_2451 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EInt: {
      heff_take_n(v_e_2412, 0ULL, 1);
      heff_drop(v_l_2413);
      v_t_2451 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EFloat: {
      heff_take_na(v_e_2412, 0ULL, 1);
      heff_drop(v_l_2413);
      v_t_2451 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EStr: {
      heff_take_n(v_e_2412, 0ULL, 1);
      heff_drop(v_l_2413);
      v_t_2451 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EBytes: {
      heff_take_n(v_e_2412, 0ULL, 1);
      heff_drop(v_l_2413);
      v_t_2451 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EFixed: {
      heff_take_n(v_e_2412, 0ULL, 2);
      heff_drop(v_l_2413);
      v_t_2451 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EFloat32: {
      heff_take_na(v_e_2412, 0ULL, 1);
      heff_drop(v_l_2413);
      v_t_2451 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EAbandon: {
      heff_drop(v_l_2413);
      v_t_2451 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_EFix: {
      heff_take_n(v_e_2412, 0ULL, 2);
      heff_drop(v_l_2413);
      v_t_2451 = NTAG(TAG_Nothing);
      break;
    }
    default: heff_nomatch(v_e_2412);
    }
    switch (heff_tag_of(v_t_2451)) {
    case TAG_Nothing: {
      heff_drop(v_sh_2414);
      heff_drop(v_t_2415);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_Just: {
      V v_r_2452 = heff_field(v_t_2451, 0);
      heff_take_n(v_t_2451, 1ULL, 1);
      V v_f_2453 = ({ V rv_2 = v_sh_2414; V rv_3 = v_t_2415; V rr_ = heff_rec_reuse_nf(v_r_2452, 3ULL, 4, shape_v__l__sh__t, 15u, 0u); heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; rr_; });
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2453}});
    }
    default: return ((HeffT2){{heff_nomatch(v_t_2451)}});
    }
  }
  case TAG_ETag: {
    heff_take_n(v_x1_240, 0ULL, 3);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EMatch: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EPrim: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EPrimCall: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ECall: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EInt: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EFloat: {
    heff_take_na(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EStr: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EBytes: {
    heff_take_n(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EFixed: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EFloat32: {
    heff_take_na(v_x1_240, 0ULL, 1);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EAbandon: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EFix: {
    heff_take_n(v_x1_240, 0ULL, 2);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
Clo g_heff_2ecompile_2eearly_2ereadOfE_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eearly_2ereadOfE_entry, 1, 0};

V g_heff_2ecompile_2eearly_2ereadOfE(V v_x1_240) {
top: ;
  HeffT2 v_t_241 = (g_heff_2ecompile_2eearly_2ereadOfE_24cpr(v_x1_240));
  {
    V v_field_243 = v_t_241.f[1];
    int64_t v_tag_242 = ((int64_t)v_t_241.f[0]);
    if ((v_tag_242 == ((int64_t)0ULL))) {
      return heff_tag_n(TAG_Just, 1, (V[]){v_field_243});
    } else {
      heff_drop(v_field_243);
      return NTAG(TAG_Nothing);
    }
  }
}
V g_heff_2ecompile_2eearly_2ereadOfE_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eearly_2ereadOfE(a[0]);
}
Clo g_heff_2ecompile_2eearly_2eisNumber_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eearly_2eisNumber_entry, 1, 0};

V g_heff_2ecompile_2eearly_2eisNumber(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nothing: {
    return NTAG(TAG_False);
  }
  case TAG_Just: {
    V v_r_241 = heff_field(v_x1_240, 0);
    V v_t_242 = heff_dup(heff_rfield(v_r_241, 3));
    switch (heff_tag_of(v_t_242)) {
    case TAG_FtFloat: {
      V v_t_243 = heff_dup(heff_rfield(v_r_241, 2));
      switch (heff_tag_of(v_t_243)) {
      case TAG_Nil: {
        return NTAG(TAG_False);
      }
      case TAG_Cons: {
        heff_take_n(v_t_243, 0ULL, 2);
        return NTAG(TAG_True);
      }
      default: return heff_nomatch(v_t_243);
      }
    }
    case TAG_FtFixed: {
      V v_w_246 = heff_field(v_t_242, 0);
      heff_take_n(v_t_242, 1ULL, 1);
      int64_t v_t_247;
      switch (heff_tag_of(v_w_246)) {
      case TAG_I8: {
        v_t_247 = ((int64_t)8ULL);
        break;
      }
      case TAG_I16: {
        v_t_247 = ((int64_t)16ULL);
        break;
      }
      case TAG_I32: {
        v_t_247 = ((int64_t)32ULL);
        break;
      }
      case TAG_I64: {
        v_t_247 = ((int64_t)64ULL);
        break;
      }
      case TAG_U8: {
        v_t_247 = ((int64_t)8ULL);
        break;
      }
      case TAG_U16: {
        v_t_247 = ((int64_t)16ULL);
        break;
      }
      case TAG_U32: {
        v_t_247 = ((int64_t)32ULL);
        break;
      }
      case TAG_U64: {
        v_t_247 = ((int64_t)64ULL);
        break;
      }
      case TAG_F32: {
        v_t_247 = ((int64_t)32ULL);
        break;
      }
      default: heff_nomatch(v_w_246);
      }
      if ((v_t_247 == ((int64_t)64ULL))) {
        V v_t_249 = heff_dup(heff_rfield(v_r_241, 2));
        switch (heff_tag_of(v_t_249)) {
        case TAG_Nil: {
          return NTAG(TAG_False);
        }
        case TAG_Cons: {
          heff_take_n(v_t_249, 0ULL, 2);
          return NTAG(TAG_True);
        }
        default: return heff_nomatch(v_t_249);
        }
      } else {
        return NTAG(TAG_False);
      }
    }
    case TAG_FtOther: {
      return NTAG(TAG_False);
    }
    case TAG_FtAny: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_t_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eearly_2eisNumber_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eearly_2eisNumber(a0); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2eearly_2enumbersW_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eearly_2enumbersW_entry, 1, 0};

V g_heff_2ecompile_2eearly_2enumbersW(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_e_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 3ULL, 2);
    V v_t_243 = (g_heff_2ecompile_2eearly_2ereadOfE(heff_dup(v_e_241)));
    V v_t_244 = ({ V a_0 = v_t_243; V r_ = (g_heff_2ecompile_2eearly_2eisNumber(a_0)); heff_drop(v_t_243); r_; });
    if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
      heff_drop(v_e_241);
      heff_drop(v_rest_242);
      heff_drop(v_t_244);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_244);
      V v_t_245 = ({ V b_0 = NTAG(TAG_True); V a_1 = v_e_241; V a_2 = v_rest_242; V r_ = (g_heff_2ecompile_2eearly_2epushKids(b_0, a_1, a_2)); heff_drop(b_0); r_; });
      V t_0 = v_t_245;
      v_x1_240 = t_0;
      goto top;
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eearly_2enumbersW_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eearly_2enumbersW(a[0]);
}
Clo g_heff_2ecompile_2eearly_2ereadsW_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eearly_2ereadsW_entry, 2, 0};

V g_heff_2ecompile_2eearly_2ereadsW(V v_acc_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return v_acc_240;
  }
  case TAG_Cons: {
    V v_e_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    HeffT2 v_t_244 = (g_heff_2ecompile_2eearly_2ereadOfE_24cpr(heff_dup(v_e_242)));
    V v_t_2410;
    {
      V v_field_246 = v_t_244.f[1];
      int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
      if ((v_tag_245 == ((int64_t)0ULL))) {
        V v_r_248 = v_field_246;
        V v_t_249 = ({ V b_0 = heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_r_248)}); V r_ = (g_heff_2ecompile_2eearly_2eisNumber(b_0)); heff_drop(b_0); r_; });
        if ((heff_dup(v_t_249) == NTAG(TAG_True))) {
          heff_drop(v_t_249);
          v_t_2410 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_r_248, v_acc_240});
        } else {
          heff_drop_cell(v_ru_24x2_241_24Cons, 2);
          heff_drop(v_r_248);
          heff_drop(v_t_249);
          v_t_2410 = v_acc_240;
        }
      } else {
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        heff_drop(v_field_246);
        v_t_2410 = v_acc_240;
      }
    }
    V v_t_2411 = ({ V b_0 = NTAG(TAG_True); V a_1 = v_e_242; V a_2 = v_rest_243; V r_ = (g_heff_2ecompile_2eearly_2epushKids(b_0, a_1, a_2)); heff_drop(b_0); r_; });
    V t_0 = v_t_2410;
    V t_1 = v_t_2411;
    v_acc_240 = t_0;
    v_x2_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eearly_2ereadsW_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eearly_2ereadsW(a[0], a[1]);
}
Clo g_heff_2ecompile_2eearly_2eprojW_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eearly_2eprojW_entry, 3, 0};

V g_heff_2ecompile_2eearly_2eprojW(V v_x_240, V v_n_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_x_240);
    return v_n_241;
  }
  case TAG_Cons: {
    V v_e_243 = heff_field(v_x3_242, 0);
    V v_rest_244 = heff_field(v_x3_242, 1);
    heff_take_n(v_x3_242, 3ULL, 2);
    HeffT2 v_t_245 = (g_heff_2ecompile_2eearly_2ereadOfE_24cpr(heff_dup(v_e_243)));
    V v_t_2411;
    {
      V v_field_247 = v_t_245.f[1];
      int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
      if ((v_tag_246 == ((int64_t)0ULL))) {
        V v_r_249 = v_field_247;
        if (heff_strEq_c(heff_dup(v_x_240), heff_get_n(v_r_249, 0, 4))) {
          v_t_2411 = heff_intAdd(v_n_241, MK_INT(1LL));
        } else {
          v_t_2411 = v_n_241;
        }
      } else {
        heff_drop(v_field_247);
        v_t_2411 = v_n_241;
      }
    }
    V v_t_2412 = ({ V b_0 = NTAG(TAG_True); V a_1 = v_e_243; V a_2 = v_rest_244; V r_ = (g_heff_2ecompile_2eearly_2epushKids(b_0, a_1, a_2)); heff_drop(b_0); r_; });
    V t_0 = v_x_240;
    V t_1 = v_t_2411;
    V t_2 = v_t_2412;
    v_x_240 = t_0;
    v_n_241 = t_1;
    v_x3_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2eearly_2eprojW_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eearly_2eprojW(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2eearly_2eownField_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eearly_2eownField_entry, 3, 0};

V g_heff_2ecompile_2eearly_2eownField(V v_x_240, V v_ls_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_MkPair: {
    V v_l_243 = heff_field(v_x3_242, 0);
    V v_e_244 = heff_field(v_x3_242, 1);
    HeffT2 v_t_245 = (g_heff_2ecompile_2eearly_2ereadOfE_24cpr(heff_dup(v_e_244)));
    {
      V v_field_247 = v_t_245.f[1];
      int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
      if ((v_tag_246 == ((int64_t)0ULL))) {
        V v_r_249 = v_field_247;
        if (heff_strEq_c(v_x_240, heff_dup(heff_rfield(v_r_249, 0)))) {
          if (heff_strEq_c(heff_dup(v_l_243), heff_dup(heff_rfield(v_r_249, 1)))) {
            return ({ V a_0 = v_ls_241; V b_1 = heff_get_n(v_r_249, 2, 4); V r_ = (g_heff_2ecompile_2eearly_2esameLabels(a_0, b_1)); heff_drop(b_1); r_; });
          } else {
            heff_drop_rec(v_r_249, 4);
            return NTAG(TAG_False);
          }
        } else {
          heff_drop_rec(v_r_249, 4);
          return NTAG(TAG_False);
        }
      } else {
        heff_drop(v_x_240);
        heff_drop(v_field_247);
        return NTAG(TAG_False);
      }
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2eearly_2eownField_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a2 = a[2]; V r = g_heff_2ecompile_2eearly_2eownField(a[0], a1, a2); heff_drop(a1); heff_drop(a2); return r;
}
Clo g_heff_2ecompile_2eearly_2erebuilds_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eearly_2erebuilds_entry, 2, 0};

V g_heff_2ecompile_2eearly_2erebuilds(V v_x_240, V v_e_241) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_EVar: {
    heff_drop(v_x_240);
    return NTAG(TAG_False);
  }
  case TAG_EGlobal: {
    heff_drop(v_x_240);
    return NTAG(TAG_False);
  }
  case TAG_ELam: {
    heff_drop(v_x_240);
    return NTAG(TAG_False);
  }
  case TAG_EApp: {
    heff_drop(v_x_240);
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    heff_drop(v_x_240);
    return NTAG(TAG_False);
  }
  case TAG_ERecord: {
    V v_fs_2411 = heff_field(v_e_241, 0);
    V v_t_2413 = (g_list_2emap_24s1937570095x2110149801(heff_dup(v_fs_2411)));
    V v_t_2414 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eearly_2eownField_clo), 2, (V[]){v_x_240, v_t_2413}));
    HEFF_LAST return g_list_2eany(v_t_2414, v_fs_2411);
  }
  case TAG_EProj: {
    heff_drop(v_x_240);
    return NTAG(TAG_False);
  }
  case TAG_ETag: {
    heff_drop(v_x_240);
    return NTAG(TAG_False);
  }
  case TAG_EMatch: {
    heff_drop(v_x_240);
    return NTAG(TAG_False);
  }
  case TAG_EPrim: {
    heff_drop(v_x_240);
    return NTAG(TAG_False);
  }
  case TAG_EPrimCall: {
    heff_drop(v_x_240);
    return NTAG(TAG_False);
  }
  case TAG_ECall: {
    heff_drop(v_x_240);
    return NTAG(TAG_False);
  }
  case TAG_EInt: {
    heff_drop(v_x_240);
    return NTAG(TAG_False);
  }
  case TAG_EFloat: {
    heff_drop(v_x_240);
    return NTAG(TAG_False);
  }
  case TAG_EStr: {
    heff_drop(v_x_240);
    return NTAG(TAG_False);
  }
  case TAG_EBytes: {
    heff_drop(v_x_240);
    return NTAG(TAG_False);
  }
  case TAG_EFixed: {
    heff_drop(v_x_240);
    return NTAG(TAG_False);
  }
  case TAG_EFloat32: {
    heff_drop(v_x_240);
    return NTAG(TAG_False);
  }
  case TAG_EAbandon: {
    heff_drop(v_x_240);
    return NTAG(TAG_False);
  }
  case TAG_EFix: {
    heff_drop(v_x_240);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_e_241);
  }
}
V g_heff_2ecompile_2eearly_2erebuilds_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2eearly_2erebuilds(a[0], a1); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2eearly_2erebuiltW_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eearly_2erebuiltW_entry, 2, 0};

V g_heff_2ecompile_2eearly_2erebuiltW(V v_x_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_x_240);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_e_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_t_244 = (g_heff_2ecompile_2eearly_2erebuilds(heff_dup(v_x_240), v_e_242));
    if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
      heff_drop(v_x_240);
      heff_drop(v_e_242);
      heff_drop(v_rest_243);
      heff_drop(v_t_244);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_244);
      V v_t_245 = ({ V b_0 = NTAG(TAG_True); V a_1 = v_e_242; V a_2 = v_rest_243; V r_ = (g_heff_2ecompile_2eearly_2epushKids(b_0, a_1, a_2)); heff_drop(b_0); r_; });
      V t_0 = v_x_240;
      V t_1 = v_t_245;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eearly_2erebuiltW_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eearly_2erebuiltW(a[0], a[1]);
}
Clo g_heff_2ecompile_2eearly_2ereadsEarly_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eearly_2ereadsEarly_entry, 5, 0};

V g_heff_2ecompile_2eearly_2ereadsEarly(V v_bound_240, V v_before_241, V v_after_242, V v_rs_243, V v_x_244) {
top: ;
  V v_x1_245 = (g_heff_2ecompile_2eearly_2eelemE(heff_dup(v_x_244), v_bound_240));
  V v_t_246 = heff_bool(!(heff_dup(v_x1_245) == NTAG(TAG_True)));
  heff_drop(v_x1_245);
  V v_ret_24bool = heff_bool(((heff_dup(v_t_246) == NTAG(TAG_True)) && ({ V v_t_247 = (g_heff_2ecompile_2eir_2ecountW(heff_dup(v_x_244), MK_INT(0LL), heff_dup(v_after_242))); int c_ = ({ V v_t_248 = (g_list_2efoldl_24f2107672210x353362204(MK_INT(1LL), MK_INT(0LL), heff_dup(v_x_244), v_rs_243)); int c_ = (heff_intEq_c(heff_dup(v_t_247), heff_dup(v_t_248)) && ({ V v_t_2410 = (g_heff_2ecompile_2eearly_2erebuiltW(heff_dup(v_x_244), heff_dup(v_before_241))); int c_ = ((heff_dup(v_t_2410) == NTAG(TAG_True)) || ({ V v_x_2411 = (g_heff_2ecompile_2eir_2ecountW(heff_dup(v_x_244), MK_INT(0LL), heff_dup(v_before_241))); int c_ = ({ V v_y_2412 = (g_heff_2ecompile_2eearly_2eprojW(heff_dup(v_x_244), MK_INT(0LL), heff_dup(v_before_241))); int c_ = heff_intLt_c(heff_dup(v_y_2412), heff_dup(v_x_2411)); heff_drop(v_y_2412); c_; }); heff_drop(v_x_2411); c_; })); heff_drop(v_t_2410); c_; })); heff_drop(v_t_248); c_; }); heff_drop(v_t_247); c_; })));
  heff_drop(v_before_241);
  heff_drop(v_after_242);
  heff_drop(v_x_244);
  heff_drop(v_t_246);
  return v_ret_24bool;
}
V g_heff_2ecompile_2eearly_2ereadsEarly_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a3 = a[3]; V r = g_heff_2ecompile_2eearly_2ereadsEarly(a0, a[1], a[2], a3, a[4]); heff_drop(a0); heff_drop(a3); return r;
}
Clo g_heff_2ecompile_2eearly_2ereadsOnce_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eearly_2ereadsOnce_entry, 2, 0};

V g_heff_2ecompile_2eearly_2ereadsOnce(V v_acc_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    HEFF_LAST return g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_240);
  }
  case TAG_Cons: {
    V v_r_242 = heff_field(v_x2_241, 0);
    V v_rs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_244 = (g_list_2eany_24s1658412854x30850816(heff_dup(v_r_242), v_acc_240));
    if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
      heff_drop(v_r_242);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      heff_drop(v_t_244);
      V t_0 = v_acc_240;
      V t_1 = v_rs_243;
      v_acc_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    } else {
      heff_drop(v_t_244);
      V t_0 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_r_242, v_acc_240});
      V t_1 = v_rs_243;
      v_acc_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eearly_2ereadsOnce_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eearly_2ereadsOnce(a[0], a[1]);
}

HeffT2 g_heff_2ecompile_2eearly_2eearlyAt_24cpr(V v_x1_240, V v_v_241, V v_l_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_v_241);
    heff_drop(v_l_242);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_e_243 = heff_field(v_x1_240, 0);
    V v_es_244 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 3ULL, 2);
    V v_t_245 = heff_get_n(heff_dup(heff_rfield(v_e_243, 0)), 0, 4);
    if (heff_strEq_c_lent(v_t_245, v_v_241, 1)) {
      V v_t_247 = heff_get_n(heff_dup(heff_rfield(v_e_243, 0)), 1, 4);
      if (heff_strEq_c_lent(v_t_247, v_l_242, 1)) {
        heff_drop(v_v_241);
        heff_drop(v_l_242);
        heff_drop(v_es_244);
        V v_f_249 = heff_get_n(v_e_243, 1, 2);
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_249}});
      } else {
        heff_drop_rec(v_e_243, 2);
        V t_0 = v_es_244;
        V t_1 = v_v_241;
        V t_2 = v_l_242;
        v_x1_240 = t_0;
        v_v_241 = t_1;
        v_l_242 = t_2;
        goto top;
      }
    } else {
      heff_drop_rec(v_e_243, 2);
      V t_0 = v_es_244;
      V t_1 = v_v_241;
      V t_2 = v_l_242;
      v_x1_240 = t_0;
      v_v_241 = t_1;
      v_l_242 = t_2;
      goto top;
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
Clo g_heff_2ecompile_2eearly_2eprojRead_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eearly_2eprojRead_entry, 5, 0};

V g_heff_2ecompile_2eearly_2eprojRead(V v_es_240, V v_e_241, V v_l_242, V v_sh_243, V v_t_244) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_EVar: {
    V v_v_245 = heff_field(v_e_241, 0);
    V v_ru_24e_241_24EVar = heff_take_reuse_n(v_e_241, 1ULL, 1);
    HeffT2 v_t_246 = (g_heff_2ecompile_2eearly_2eearlyAt_24cpr(v_es_240, heff_dup(v_v_245), heff_dup(v_l_242)));
    {
      V v_field_248 = v_t_246.f[1];
      int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
      if ((v_tag_247 == ((int64_t)0ULL))) {
        heff_drop(v_l_242);
        heff_drop(v_sh_243);
        heff_drop(v_t_244);
        heff_drop(v_v_245);
        V v_x_2410 = v_field_248;
        return heff_tag_at_n(v_ru_24e_241_24EVar, TAG_EVar, 1, (V[]){v_x_2410});
      } else {
        heff_drop(v_field_248);
        return heff_tag_n(TAG_EProj, 4, (V[]){heff_tag_at_n(v_ru_24e_241_24EVar, TAG_EVar, 1, (V[]){v_v_245}), v_l_242, v_sh_243, v_t_244});
      }
    }
  }
  case TAG_EGlobal: {
    heff_drop(v_es_240);
    return heff_tag_n(TAG_EProj, 4, (V[]){v_e_241, v_l_242, v_sh_243, v_t_244});
  }
  case TAG_ELam: {
    heff_drop(v_es_240);
    return heff_tag_n(TAG_EProj, 4, (V[]){v_e_241, v_l_242, v_sh_243, v_t_244});
  }
  case TAG_EApp: {
    heff_drop(v_es_240);
    return heff_tag_n(TAG_EProj, 4, (V[]){v_e_241, v_l_242, v_sh_243, v_t_244});
  }
  case TAG_ELet: {
    heff_drop(v_es_240);
    return heff_tag_n(TAG_EProj, 4, (V[]){v_e_241, v_l_242, v_sh_243, v_t_244});
  }
  case TAG_ERecord: {
    heff_drop(v_es_240);
    return heff_tag_n(TAG_EProj, 4, (V[]){v_e_241, v_l_242, v_sh_243, v_t_244});
  }
  case TAG_EProj: {
    heff_drop(v_es_240);
    return heff_tag_n(TAG_EProj, 4, (V[]){v_e_241, v_l_242, v_sh_243, v_t_244});
  }
  case TAG_ETag: {
    heff_drop(v_es_240);
    return heff_tag_n(TAG_EProj, 4, (V[]){v_e_241, v_l_242, v_sh_243, v_t_244});
  }
  case TAG_EMatch: {
    heff_drop(v_es_240);
    return heff_tag_n(TAG_EProj, 4, (V[]){v_e_241, v_l_242, v_sh_243, v_t_244});
  }
  case TAG_EPrim: {
    heff_drop(v_es_240);
    return heff_tag_n(TAG_EProj, 4, (V[]){v_e_241, v_l_242, v_sh_243, v_t_244});
  }
  case TAG_EPrimCall: {
    heff_drop(v_es_240);
    return heff_tag_n(TAG_EProj, 4, (V[]){v_e_241, v_l_242, v_sh_243, v_t_244});
  }
  case TAG_ECall: {
    heff_drop(v_es_240);
    return heff_tag_n(TAG_EProj, 4, (V[]){v_e_241, v_l_242, v_sh_243, v_t_244});
  }
  case TAG_EInt: {
    heff_drop(v_es_240);
    return heff_tag_n(TAG_EProj, 4, (V[]){v_e_241, v_l_242, v_sh_243, v_t_244});
  }
  case TAG_EFloat: {
    heff_drop(v_es_240);
    return heff_tag_n(TAG_EProj, 4, (V[]){v_e_241, v_l_242, v_sh_243, v_t_244});
  }
  case TAG_EStr: {
    heff_drop(v_es_240);
    return heff_tag_n(TAG_EProj, 4, (V[]){v_e_241, v_l_242, v_sh_243, v_t_244});
  }
  case TAG_EBytes: {
    heff_drop(v_es_240);
    return heff_tag_n(TAG_EProj, 4, (V[]){v_e_241, v_l_242, v_sh_243, v_t_244});
  }
  case TAG_EFixed: {
    heff_drop(v_es_240);
    return heff_tag_n(TAG_EProj, 4, (V[]){v_e_241, v_l_242, v_sh_243, v_t_244});
  }
  case TAG_EFloat32: {
    heff_drop(v_es_240);
    return heff_tag_n(TAG_EProj, 4, (V[]){v_e_241, v_l_242, v_sh_243, v_t_244});
  }
  case TAG_EAbandon: {
    heff_drop(v_es_240);
    return heff_tag_n(TAG_EProj, 4, (V[]){v_e_241, v_l_242, v_sh_243, v_t_244});
  }
  case TAG_EFix: {
    heff_drop(v_es_240);
    return heff_tag_n(TAG_EProj, 4, (V[]){v_e_241, v_l_242, v_sh_243, v_t_244});
  }
  default: return heff_nomatch(v_e_241);
  }
}
V g_heff_2ecompile_2eearly_2eprojRead_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eearly_2eprojRead(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ecompile_2eearly_2ereadGo_lam0(V self, V *args);
V g_heff_2ecompile_2eearly_2ereadGo_lam1(V self, V *args);
V g_heff_2ecompile_2eearly_2ereadGo_lam2(V self, V *args);
V g_heff_2ecompile_2eearly_2ereadGo_lam4(V self, V *args);
V g_heff_2ecompile_2eearly_2ereadGo_lam3(V self, V *args);
Clo g_heff_2ecompile_2eearly_2ereadGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eearly_2ereadGo_entry, 2, 0};

V g_heff_2ecompile_2eearly_2ereadGo(V v_es_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_EVar: {
    heff_drop(v_es_240);
    return v_x2_241;
  }
  case TAG_EGlobal: {
    heff_drop(v_es_240);
    return v_x2_241;
  }
  case TAG_ELam: {
    V v_xs_244 = heff_field(v_x2_241, 0);
    V v_b_245 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24ELam = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_cell_246 = heff_tag_at_n(v_ru_24x2_241_24ELam, TAG_ELam, 2, (V[]){heff_dup(v_xs_244), heff_hole()});
    V v_t_2410 = (g_list_2efilter(heff_clo_n(g_heff_2ecompile_2eearly_2ereadGo_lam0, 1, 1, (V[]){v_xs_244}), v_es_240));
    V v_u_2411 = (g_heff_2ecompile_2eearly_2ereadGo_24dps(v_t_2410, v_b_245, heff_dup(v_cell_246), MK_INT(1LL)));
    heff_drop(v_u_2411);
    return v_cell_246;
  }
  case TAG_EApp: {
    V v_f_2412 = heff_field(v_x2_241, 0);
    V v_as_2413 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24EApp = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_2414 = (g_heff_2ecompile_2eearly_2ereadGo(heff_dup(v_es_240), v_f_2412));
    V v_t_2415 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eearly_2ereadGo_clo), 1, (V[]){v_es_240}));
    V v_t_2416 = (g_list_2emap(v_t_2415, v_as_2413));
    return heff_tag_at_n(v_ru_24x2_241_24EApp, TAG_EApp, 2, (V[]){v_t_2414, v_t_2416});
  }
  case TAG_ELet: {
    V v_x_2417 = heff_field(v_x2_241, 0);
    V v_a_2418 = heff_field(v_x2_241, 1);
    V v_b_2419 = heff_field(v_x2_241, 2);
    V v_ru_24x2_241_24ELet = heff_take_reuse_n(v_x2_241, 7ULL, 3);
    V v_t_2420 = (g_heff_2ecompile_2eearly_2ereadGo(heff_dup(v_es_240), v_a_2418));
    V v_cell_2421 = heff_tag_at_n(v_ru_24x2_241_24ELet, TAG_ELet, 3, (V[]){heff_dup(v_x_2417), v_t_2420, heff_hole()});
    V v_t_2426 = (g_list_2efilter(heff_clo_n(g_heff_2ecompile_2eearly_2ereadGo_lam1, 1, 1, (V[]){v_x_2417}), v_es_240));
    V v_u_2427 = (g_heff_2ecompile_2eearly_2ereadGo_24dps(v_t_2426, v_b_2419, heff_dup(v_cell_2421), MK_INT(2LL)));
    heff_drop(v_u_2427);
    return v_cell_2421;
  }
  case TAG_ERecord: {
    V v_fs_2428 = heff_field(v_x2_241, 0);
    V v_ts_2429 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24ERecord = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_2438 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eearly_2ereadGo_lam2, 1, 1, (V[]){v_es_240}), v_fs_2428));
    return heff_tag_at_n(v_ru_24x2_241_24ERecord, TAG_ERecord, 2, (V[]){v_t_2438, v_ts_2429});
  }
  case TAG_EProj: {
    V v_e_2439 = heff_field(v_x2_241, 0);
    V v_l_2440 = heff_field(v_x2_241, 1);
    V v_sh_2441 = heff_field(v_x2_241, 2);
    V v_t_2442 = heff_field(v_x2_241, 3);
    heff_take_n(v_x2_241, 15ULL, 4);
    V v_t_2443 = (g_heff_2ecompile_2eearly_2ereadGo(heff_dup(v_es_240), v_e_2439));
    return (g_heff_2ecompile_2eearly_2eprojRead(v_es_240, v_t_2443, v_l_2440, v_sh_2441, v_t_2442));
  }
  case TAG_ETag: {
    V v_t_2444 = heff_field(v_x2_241, 0);
    V v_as_2445 = heff_field(v_x2_241, 1);
    V v_ts_2446 = heff_field(v_x2_241, 2);
    V v_ru_24x2_241_24ETag = heff_take_reuse_n(v_x2_241, 7ULL, 3);
    V v_t_2447 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eearly_2ereadGo_clo), 1, (V[]){v_es_240}));
    V v_t_2448 = (g_list_2emap(v_t_2447, v_as_2445));
    return heff_tag_at_n(v_ru_24x2_241_24ETag, TAG_ETag, 3, (V[]){v_t_2444, v_t_2448, v_ts_2446});
  }
  case TAG_EMatch: {
    V v_s_2449 = heff_field(v_x2_241, 0);
    V v_arms_2450 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24EMatch = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_2451 = (g_heff_2ecompile_2eearly_2ereadGo(heff_dup(v_es_240), v_s_2449));
    V v_t_2461 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eearly_2ereadGo_lam3, 1, 1, (V[]){v_es_240}), v_arms_2450));
    return heff_tag_at_n(v_ru_24x2_241_24EMatch, TAG_EMatch, 2, (V[]){v_t_2451, v_t_2461});
  }
  case TAG_EPrim: {
    heff_drop(v_es_240);
    return v_x2_241;
  }
  case TAG_EPrimCall: {
    V v_p_2463 = heff_field(v_x2_241, 0);
    V v_as_2464 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24EPrimCall = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_2465 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eearly_2ereadGo_clo), 1, (V[]){v_es_240}));
    V v_t_2466 = (g_list_2emap(v_t_2465, v_as_2464));
    return heff_tag_at_n(v_ru_24x2_241_24EPrimCall, TAG_EPrimCall, 2, (V[]){v_p_2463, v_t_2466});
  }
  case TAG_ECall: {
    V v_g_2467 = heff_field(v_x2_241, 0);
    V v_as_2468 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24ECall = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_2469 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eearly_2ereadGo_clo), 1, (V[]){v_es_240}));
    V v_t_2470 = (g_list_2emap(v_t_2469, v_as_2468));
    return heff_tag_at_n(v_ru_24x2_241_24ECall, TAG_ECall, 2, (V[]){v_g_2467, v_t_2470});
  }
  case TAG_EInt: {
    heff_drop(v_es_240);
    return v_x2_241;
  }
  case TAG_EFloat: {
    heff_drop(v_es_240);
    return v_x2_241;
  }
  case TAG_EStr: {
    heff_drop(v_es_240);
    return v_x2_241;
  }
  case TAG_EBytes: {
    heff_drop(v_es_240);
    return v_x2_241;
  }
  case TAG_EFixed: {
    heff_drop(v_es_240);
    return v_x2_241;
  }
  case TAG_EFloat32: {
    heff_drop(v_es_240);
    return v_x2_241;
  }
  case TAG_EAbandon: {
    heff_drop(v_es_240);
    return v_x2_241;
  }
  case TAG_EFix: {
    heff_drop(v_es_240);
    return v_x2_241;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eearly_2ereadGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eearly_2ereadGo(a[0], a[1]);
}
V g_heff_2ecompile_2eearly_2ereadGo_lam0(V self, V *args) {
  V v_e_247 = args[0];
  V v_xs_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_248 = heff_get_n(heff_get_n(v_e_247, 0, 2), 0, 4);
  V v_x1_249 = ({ V a_0 = v_t_248; V a_1 = v_xs_244; V r_ = (g_heff_2ecompile_2eearly_2eelemE(a_0, a_1)); heff_drop(v_xs_244); r_; });
  V v_ret_24bool = heff_bool(!(heff_dup(v_x1_249) == NTAG(TAG_True)));
  heff_drop(v_x1_249);
  return v_ret_24bool;
}
V g_heff_2ecompile_2eearly_2ereadGo_lam1(V self, V *args) {
  V v_e_2422 = args[0];
  V v_x_2417 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2423 = heff_get_n(heff_get_n(v_e_2422, 0, 2), 0, 4);
  V v_t_2424 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2417, NTAG(TAG_Nil)});
  V v_x1_2425 = ({ V a_0 = v_t_2423; V a_1 = v_t_2424; V r_ = (g_heff_2ecompile_2eearly_2eelemE(a_0, a_1)); heff_drop_tag(v_t_2424, 2); r_; });
  V v_ret_24bool = heff_bool(!(heff_dup(v_x1_2425) == NTAG(TAG_True)));
  heff_drop(v_x1_2425);
  return v_ret_24bool;
}
V g_heff_2ecompile_2eearly_2ereadGo_lam2(V self, V *args) {
  V v_p_2430 = args[0];
  V v_es_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2433;
  switch (heff_tag_of(v_p_2430)) {
  case TAG_MkPair: {
    V v_x_2431 = heff_dup(heff_field(v_p_2430, 0));
    v_t_2433 = v_x_2431;
    break;
  }
  default: heff_nomatch(v_p_2430);
  }
  V v_t_2436;
  switch (heff_tag_of(v_p_2430)) {
  case TAG_MkPair: {
    V v_y_2435 = heff_field(v_p_2430, 1);
    heff_take_n(v_p_2430, 2ULL, 2);
    v_t_2436 = v_y_2435;
    break;
  }
  default: heff_nomatch(v_p_2430);
  }
  V v_t_2437 = (g_heff_2ecompile_2eearly_2ereadGo(v_es_240, v_t_2436));
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2433, v_t_2437});
}
V g_heff_2ecompile_2eearly_2ereadGo_lam4(V self, V *args) {
  V v_e_2456 = args[0];
  V v_vs_2454 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2457 = heff_get_n(heff_get_n(v_e_2456, 0, 2), 0, 4);
  V v_x1_2458 = ({ V a_0 = v_t_2457; V a_1 = v_vs_2454; V r_ = (g_heff_2ecompile_2eearly_2eelemE(a_0, a_1)); heff_drop(v_vs_2454); r_; });
  V v_ret_24bool = heff_bool(!(heff_dup(v_x1_2458) == NTAG(TAG_True)));
  heff_drop(v_x1_2458);
  return v_ret_24bool;
}
V g_heff_2ecompile_2eearly_2ereadGo_lam3(V self, V *args) {
  V v_x3_2452 = args[0];
  V v_es_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x3_2452)) {
  case TAG_MkArm: {
    V v_t_2453 = heff_field(v_x3_2452, 0);
    V v_vs_2454 = heff_field(v_x3_2452, 1);
    V v_b_2455 = heff_field(v_x3_2452, 2);
    V v_ru_24x3_2452_24MkArm = heff_take_reuse_n(v_x3_2452, 7ULL, 3);
    V v_t_2459 = (g_list_2efilter(heff_clo_n(g_heff_2ecompile_2eearly_2ereadGo_lam4, 1, 1, (V[]){heff_dup(v_vs_2454)}), v_es_240));
    V v_t_2460 = (g_heff_2ecompile_2eearly_2ereadGo(v_t_2459, v_b_2455));
    return heff_tag_at_n(v_ru_24x3_2452_24MkArm, TAG_MkArm, 3, (V[]){v_t_2453, v_vs_2454, v_t_2460});
  }
  default: return heff_nomatch(v_x3_2452);
  }
}
V g_heff_2ecompile_2eearly_2ereadGo_24dps_lam0(V self, V *args);
V g_heff_2ecompile_2eearly_2ereadGo_24dps_lam1(V self, V *args);
V g_heff_2ecompile_2eearly_2ereadGo_24dps_lam2(V self, V *args);
V g_heff_2ecompile_2eearly_2ereadGo_24dps_lam4(V self, V *args);
V g_heff_2ecompile_2eearly_2ereadGo_24dps_lam3(V self, V *args);
Clo g_heff_2ecompile_2eearly_2ereadGo_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eearly_2ereadGo_24dps_entry, 4, 0};

V g_heff_2ecompile_2eearly_2ereadGo_24dps(V v_es_240, V v_x2_241, V v_d_242, V v_i_243) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_EVar: {
    heff_drop(v_es_240);
    return heff_setField(v_d_242, v_i_243, v_x2_241);
  }
  case TAG_EGlobal: {
    heff_drop(v_es_240);
    return heff_setField(v_d_242, v_i_243, v_x2_241);
  }
  case TAG_ELam: {
    V v_xs_246 = heff_field(v_x2_241, 0);
    V v_b_247 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24ELam = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_cell_248 = heff_tag_at_n(v_ru_24x2_241_24ELam, TAG_ELam, 2, (V[]){heff_dup(v_xs_246), heff_hole()});
    V v_u_249 = heff_setField(v_d_242, v_i_243, heff_dup(v_cell_248));
    heff_drop(v_u_249);
    V v_t_2413 = (g_list_2efilter(heff_clo_n(g_heff_2ecompile_2eearly_2ereadGo_24dps_lam0, 1, 1, (V[]){v_xs_246}), v_es_240));
    V t_0 = v_t_2413;
    V t_1 = v_b_247;
    V t_2 = v_cell_248;
    V t_3 = MK_INT(1LL);
    v_es_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    v_i_243 = t_3;
    goto top;
  }
  case TAG_EApp: {
    V v_f_2414 = heff_field(v_x2_241, 0);
    V v_as_2415 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_t_2416 = (g_heff_2ecompile_2eearly_2ereadGo(heff_dup(v_es_240), v_f_2414));
    V v_t_2417 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eearly_2ereadGo_clo), 1, (V[]){v_es_240}));
    V v_t_2418 = (g_list_2emap(v_t_2417, v_as_2415));
    return heff_setField(v_d_242, v_i_243, heff_tag_n(TAG_EApp, 2, (V[]){v_t_2416, v_t_2418}));
  }
  case TAG_ELet: {
    V v_x_2419 = heff_field(v_x2_241, 0);
    V v_a_2420 = heff_field(v_x2_241, 1);
    V v_b_2421 = heff_field(v_x2_241, 2);
    V v_ru_24x2_241_24ELet = heff_take_reuse_n(v_x2_241, 7ULL, 3);
    V v_t_2422 = (g_heff_2ecompile_2eearly_2ereadGo(heff_dup(v_es_240), v_a_2420));
    V v_cell_2423 = heff_tag_at_n(v_ru_24x2_241_24ELet, TAG_ELet, 3, (V[]){heff_dup(v_x_2419), v_t_2422, heff_hole()});
    V v_u_2424 = heff_setField(v_d_242, v_i_243, heff_dup(v_cell_2423));
    heff_drop(v_u_2424);
    V v_t_2429 = (g_list_2efilter(heff_clo_n(g_heff_2ecompile_2eearly_2ereadGo_24dps_lam1, 1, 1, (V[]){v_x_2419}), v_es_240));
    V t_0 = v_t_2429;
    V t_1 = v_b_2421;
    V t_2 = v_cell_2423;
    V t_3 = MK_INT(2LL);
    v_es_240 = t_0;
    v_x2_241 = t_1;
    v_d_242 = t_2;
    v_i_243 = t_3;
    goto top;
  }
  case TAG_ERecord: {
    V v_fs_2430 = heff_field(v_x2_241, 0);
    V v_ts_2431 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_t_2440 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eearly_2ereadGo_24dps_lam2, 1, 1, (V[]){v_es_240}), v_fs_2430));
    return heff_setField(v_d_242, v_i_243, heff_tag_n(TAG_ERecord, 2, (V[]){v_t_2440, v_ts_2431}));
  }
  case TAG_EProj: {
    V v_e_2441 = heff_field(v_x2_241, 0);
    V v_l_2442 = heff_field(v_x2_241, 1);
    V v_sh_2443 = heff_field(v_x2_241, 2);
    V v_t_2444 = heff_field(v_x2_241, 3);
    heff_take_n(v_x2_241, 15ULL, 4);
    V v_t_2445 = (g_heff_2ecompile_2eearly_2ereadGo(heff_dup(v_es_240), v_e_2441));
    V v_t_2446 = (g_heff_2ecompile_2eearly_2eprojRead(v_es_240, v_t_2445, v_l_2442, v_sh_2443, v_t_2444));
    return heff_setField(v_d_242, v_i_243, v_t_2446);
  }
  case TAG_ETag: {
    V v_t_2447 = heff_field(v_x2_241, 0);
    V v_as_2448 = heff_field(v_x2_241, 1);
    V v_ts_2449 = heff_field(v_x2_241, 2);
    heff_take_n(v_x2_241, 7ULL, 3);
    V v_t_2450 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eearly_2ereadGo_clo), 1, (V[]){v_es_240}));
    V v_t_2451 = (g_list_2emap(v_t_2450, v_as_2448));
    return heff_setField(v_d_242, v_i_243, heff_tag_n(TAG_ETag, 3, (V[]){v_t_2447, v_t_2451, v_ts_2449}));
  }
  case TAG_EMatch: {
    V v_s_2452 = heff_field(v_x2_241, 0);
    V v_arms_2453 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_t_2454 = (g_heff_2ecompile_2eearly_2ereadGo(heff_dup(v_es_240), v_s_2452));
    V v_t_2464 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eearly_2ereadGo_24dps_lam3, 1, 1, (V[]){v_es_240}), v_arms_2453));
    return heff_setField(v_d_242, v_i_243, heff_tag_n(TAG_EMatch, 2, (V[]){v_t_2454, v_t_2464}));
  }
  case TAG_EPrim: {
    heff_drop(v_es_240);
    return heff_setField(v_d_242, v_i_243, v_x2_241);
  }
  case TAG_EPrimCall: {
    V v_p_2466 = heff_field(v_x2_241, 0);
    V v_as_2467 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_t_2468 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eearly_2ereadGo_clo), 1, (V[]){v_es_240}));
    V v_t_2469 = (g_list_2emap(v_t_2468, v_as_2467));
    return heff_setField(v_d_242, v_i_243, heff_tag_n(TAG_EPrimCall, 2, (V[]){v_p_2466, v_t_2469}));
  }
  case TAG_ECall: {
    V v_g_2470 = heff_field(v_x2_241, 0);
    V v_as_2471 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_t_2472 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eearly_2ereadGo_clo), 1, (V[]){v_es_240}));
    V v_t_2473 = (g_list_2emap(v_t_2472, v_as_2471));
    return heff_setField(v_d_242, v_i_243, heff_tag_n(TAG_ECall, 2, (V[]){v_g_2470, v_t_2473}));
  }
  case TAG_EInt: {
    heff_drop(v_es_240);
    return heff_setField(v_d_242, v_i_243, v_x2_241);
  }
  case TAG_EFloat: {
    heff_drop(v_es_240);
    return heff_setField(v_d_242, v_i_243, v_x2_241);
  }
  case TAG_EStr: {
    heff_drop(v_es_240);
    return heff_setField(v_d_242, v_i_243, v_x2_241);
  }
  case TAG_EBytes: {
    heff_drop(v_es_240);
    return heff_setField(v_d_242, v_i_243, v_x2_241);
  }
  case TAG_EFixed: {
    heff_drop(v_es_240);
    return heff_setField(v_d_242, v_i_243, v_x2_241);
  }
  case TAG_EFloat32: {
    heff_drop(v_es_240);
    return heff_setField(v_d_242, v_i_243, v_x2_241);
  }
  case TAG_EAbandon: {
    heff_drop(v_es_240);
    return heff_setField(v_d_242, v_i_243, v_x2_241);
  }
  case TAG_EFix: {
    heff_drop(v_es_240);
    return heff_setField(v_d_242, v_i_243, v_x2_241);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eearly_2ereadGo_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eearly_2ereadGo_24dps(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2eearly_2ereadGo_24dps_lam0(V self, V *args) {
  V v_e_2410 = args[0];
  V v_xs_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2411 = heff_get_n(heff_get_n(v_e_2410, 0, 2), 0, 4);
  V v_x1_2412 = ({ V a_0 = v_t_2411; V a_1 = v_xs_246; V r_ = (g_heff_2ecompile_2eearly_2eelemE(a_0, a_1)); heff_drop(v_xs_246); r_; });
  V v_ret_24bool = heff_bool(!(heff_dup(v_x1_2412) == NTAG(TAG_True)));
  heff_drop(v_x1_2412);
  return v_ret_24bool;
}
V g_heff_2ecompile_2eearly_2ereadGo_24dps_lam1(V self, V *args) {
  V v_e_2425 = args[0];
  V v_x_2419 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2426 = heff_get_n(heff_get_n(v_e_2425, 0, 2), 0, 4);
  V v_t_2427 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2419, NTAG(TAG_Nil)});
  V v_x1_2428 = ({ V a_0 = v_t_2426; V a_1 = v_t_2427; V r_ = (g_heff_2ecompile_2eearly_2eelemE(a_0, a_1)); heff_drop_tag(v_t_2427, 2); r_; });
  V v_ret_24bool = heff_bool(!(heff_dup(v_x1_2428) == NTAG(TAG_True)));
  heff_drop(v_x1_2428);
  return v_ret_24bool;
}
V g_heff_2ecompile_2eearly_2ereadGo_24dps_lam2(V self, V *args) {
  V v_p_2432 = args[0];
  V v_es_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2435;
  switch (heff_tag_of(v_p_2432)) {
  case TAG_MkPair: {
    V v_x_2433 = heff_dup(heff_field(v_p_2432, 0));
    v_t_2435 = v_x_2433;
    break;
  }
  default: heff_nomatch(v_p_2432);
  }
  V v_t_2438;
  switch (heff_tag_of(v_p_2432)) {
  case TAG_MkPair: {
    V v_y_2437 = heff_field(v_p_2432, 1);
    heff_take_n(v_p_2432, 2ULL, 2);
    v_t_2438 = v_y_2437;
    break;
  }
  default: heff_nomatch(v_p_2432);
  }
  V v_t_2439 = (g_heff_2ecompile_2eearly_2ereadGo(v_es_240, v_t_2438));
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2435, v_t_2439});
}
V g_heff_2ecompile_2eearly_2ereadGo_24dps_lam4(V self, V *args) {
  V v_e_2459 = args[0];
  V v_vs_2457 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2460 = heff_get_n(heff_get_n(v_e_2459, 0, 2), 0, 4);
  V v_x1_2461 = ({ V a_0 = v_t_2460; V a_1 = v_vs_2457; V r_ = (g_heff_2ecompile_2eearly_2eelemE(a_0, a_1)); heff_drop(v_vs_2457); r_; });
  V v_ret_24bool = heff_bool(!(heff_dup(v_x1_2461) == NTAG(TAG_True)));
  heff_drop(v_x1_2461);
  return v_ret_24bool;
}
V g_heff_2ecompile_2eearly_2ereadGo_24dps_lam3(V self, V *args) {
  V v_x3_2455 = args[0];
  V v_es_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x3_2455)) {
  case TAG_MkArm: {
    V v_t_2456 = heff_field(v_x3_2455, 0);
    V v_vs_2457 = heff_field(v_x3_2455, 1);
    V v_b_2458 = heff_field(v_x3_2455, 2);
    V v_ru_24x3_2455_24MkArm = heff_take_reuse_n(v_x3_2455, 7ULL, 3);
    V v_t_2462 = (g_list_2efilter(heff_clo_n(g_heff_2ecompile_2eearly_2ereadGo_24dps_lam4, 1, 1, (V[]){heff_dup(v_vs_2457)}), v_es_240));
    V v_t_2463 = (g_heff_2ecompile_2eearly_2ereadGo(v_t_2462, v_b_2458));
    return heff_tag_at_n(v_ru_24x3_2455_24MkArm, TAG_MkArm, 3, (V[]){v_t_2456, v_vs_2457, v_t_2463});
  }
  default: return heff_nomatch(v_x3_2455);
  }
}
Clo g_heff_2ecompile_2eearly_2eletsEarly_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eearly_2eletsEarly_entry, 2, 0};

V g_heff_2ecompile_2eearly_2eletsEarly(V v_x1_240, V v_e_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return v_e_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    V v_t_244 = heff_get_n(heff_dup(heff_rfield(v_x_242, 0)), 0, 4);
    V v_t_245 = heff_get_n(heff_dup(heff_rfield(v_x_242, 0)), 1, 4);
    V v_t_246 = heff_get_n(heff_dup(heff_rfield(v_x_242, 0)), 2, 4);
    V v_t_247 = heff_get_n(heff_dup(heff_rfield(v_x_242, 0)), 3, 4);
    V v_t_248 = heff_tag_n(TAG_EProj, 4, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_t_244}), v_t_245, v_t_246, v_t_247});
    V v_cell_249 = heff_tag_n(TAG_ELet, 3, (V[]){heff_dup(heff_rfield(v_x_242, 1)), v_t_248, heff_hole()});
    V v_u_2410 = (g_heff_2ecompile_2eearly_2eletsEarly_24dps(v_xs_243, v_e_241, heff_dup(v_cell_249)));
    heff_drop(v_u_2410);
    return v_cell_249;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eearly_2eletsEarly_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eearly_2eletsEarly(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2eearly_2eletsEarly_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eearly_2eletsEarly_24dps_entry, 3, 0};

V g_heff_2ecompile_2eearly_2eletsEarly_24dps(V v_x1_240, V v_e_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_242, MK_INT(2LL), v_e_241);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x1_240, 0);
    V v_xs_244 = heff_field(v_x1_240, 1);
    V v_t_245 = heff_get_n(heff_dup(heff_rfield(v_x_243, 0)), 0, 4);
    V v_t_246 = heff_get_n(heff_dup(heff_rfield(v_x_243, 0)), 1, 4);
    V v_t_247 = heff_get_n(heff_dup(heff_rfield(v_x_243, 0)), 2, 4);
    V v_t_248 = heff_get_n(heff_dup(heff_rfield(v_x_243, 0)), 3, 4);
    V v_t_249 = heff_tag_n(TAG_EProj, 4, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_t_245}), v_t_246, v_t_247, v_t_248});
    V v_cell_2410 = heff_tag_n(TAG_ELet, 3, (V[]){heff_dup(heff_rfield(v_x_243, 1)), v_t_249, heff_hole()});
    V v_u_2411 = heff_setField(v_d_242, MK_INT(2LL), heff_dup(v_cell_2410));
    heff_drop(v_u_2411);
    V t_0 = v_xs_244;
    V t_1 = v_e_241;
    V t_2 = v_cell_2410;
    v_x1_240 = t_0;
    v_e_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eearly_2eletsEarly_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eearly_2eletsEarly_24dps(a0, a[1], a[2]); heff_drop(a0); return r;
}

HeffT2 g_heff_2ecompile_2eearly_2espineOf_24cpr(V v_e_240) {
top: ;
  switch (heff_tag_of(v_e_240)) {
  case TAG_EVar: {
    return ((HeffT2){{NTAG(TAG_Nil), v_e_240}});
  }
  case TAG_EGlobal: {
    return ((HeffT2){{NTAG(TAG_Nil), v_e_240}});
  }
  case TAG_ELam: {
    return ((HeffT2){{NTAG(TAG_Nil), v_e_240}});
  }
  case TAG_EApp: {
    return ((HeffT2){{NTAG(TAG_Nil), v_e_240}});
  }
  case TAG_ELet: {
    V v_x_247 = heff_field(v_e_240, 0);
    V v_a_248 = heff_field(v_e_240, 1);
    V v_b_249 = heff_field(v_e_240, 2);
    heff_take_n(v_e_240, 7ULL, 3);
    HeffT2 v_t_2410 = (g_heff_2ecompile_2eearly_2espineOf_24cpr(v_b_249));
    {
      V v_field_2411 = v_t_2410.f[0];
      V v_field_2412 = v_t_2410.f[1];
      V v_bs_2413 = v_field_2411;
      V v_e_2414 = v_field_2412;
      V v_t_2415 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_x_247, v_a_248}), v_bs_2413});
      return ((HeffT2){{v_t_2415, v_e_2414}});
    }
  }
  case TAG_ERecord: {
    return ((HeffT2){{NTAG(TAG_Nil), v_e_240}});
  }
  case TAG_EProj: {
    return ((HeffT2){{NTAG(TAG_Nil), v_e_240}});
  }
  case TAG_ETag: {
    return ((HeffT2){{NTAG(TAG_Nil), v_e_240}});
  }
  case TAG_EMatch: {
    return ((HeffT2){{NTAG(TAG_Nil), v_e_240}});
  }
  case TAG_EPrim: {
    return ((HeffT2){{NTAG(TAG_Nil), v_e_240}});
  }
  case TAG_EPrimCall: {
    return ((HeffT2){{NTAG(TAG_Nil), v_e_240}});
  }
  case TAG_ECall: {
    return ((HeffT2){{NTAG(TAG_Nil), v_e_240}});
  }
  case TAG_EInt: {
    return ((HeffT2){{NTAG(TAG_Nil), v_e_240}});
  }
  case TAG_EFloat: {
    return ((HeffT2){{NTAG(TAG_Nil), v_e_240}});
  }
  case TAG_EStr: {
    return ((HeffT2){{NTAG(TAG_Nil), v_e_240}});
  }
  case TAG_EBytes: {
    return ((HeffT2){{NTAG(TAG_Nil), v_e_240}});
  }
  case TAG_EFixed: {
    return ((HeffT2){{NTAG(TAG_Nil), v_e_240}});
  }
  case TAG_EFloat32: {
    return ((HeffT2){{NTAG(TAG_Nil), v_e_240}});
  }
  case TAG_EAbandon: {
    return ((HeffT2){{NTAG(TAG_Nil), v_e_240}});
  }
  case TAG_EFix: {
    return ((HeffT2){{NTAG(TAG_Nil), v_e_240}});
  }
  default: return ((HeffT2){{heff_nomatch(v_e_240)}});
  }
}
Clo g_heff_2ecompile_2eearly_2eletsOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eearly_2eletsOf_entry, 2, 0};

V g_heff_2ecompile_2eearly_2eletsOf(V v_x1_240, V v_e_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return v_e_241;
  }
  case TAG_Cons: {
    V v_x11_242 = heff_field(v_x1_240, 0);
    V v_bs_243 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_MkPair: {
      V v_x_244 = heff_field(v_x11_242, 0);
      V v_a_245 = heff_field(v_x11_242, 1);
      V v_cell_246 = heff_tag_n(TAG_ELet, 3, (V[]){heff_dup(v_x_244), heff_dup(v_a_245), heff_hole()});
      V v_u_247 = (g_heff_2ecompile_2eearly_2eletsOf_24dps(v_bs_243, v_e_241, heff_dup(v_cell_246)));
      heff_drop(v_u_247);
      return v_cell_246;
    }
    default: return heff_nomatch(v_x11_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eearly_2eletsOf_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eearly_2eletsOf(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2eearly_2eletsOf_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eearly_2eletsOf_24dps_entry, 3, 0};

V g_heff_2ecompile_2eearly_2eletsOf_24dps(V v_x1_240, V v_e_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_242, MK_INT(2LL), v_e_241);
  }
  case TAG_Cons: {
    V v_x11_243 = heff_field(v_x1_240, 0);
    V v_bs_244 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x11_243)) {
    case TAG_MkPair: {
      V v_x_245 = heff_field(v_x11_243, 0);
      V v_a_246 = heff_field(v_x11_243, 1);
      V v_cell_247 = heff_tag_n(TAG_ELet, 3, (V[]){heff_dup(v_x_245), heff_dup(v_a_246), heff_hole()});
      V v_u_248 = heff_setField(v_d_242, MK_INT(2LL), heff_dup(v_cell_247));
      heff_drop(v_u_248);
      V t_0 = v_bs_244;
      V t_1 = v_e_241;
      V t_2 = v_cell_247;
      v_x1_240 = t_0;
      v_e_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_x11_243);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2eearly_2eletsOf_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eearly_2eletsOf_24dps(a0, a[1], a[2]); heff_drop(a0); return r;
}

HeffT2 g_heff_2ecompile_2eearly_2ecutGo_24cpr(V v_acc_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    V v_f_242 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_240));
    return ((HeffT2){{v_f_242, NTAG(TAG_Nil)}});
  }
  case TAG_Cons: {
    V v_b_243 = heff_field(v_x2_241, 0);
    V v_bs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_247;
    switch (heff_tag_of(v_b_243)) {
    case TAG_MkPair: {
      V v_y_246 = heff_dup(heff_field(v_b_243, 1));
      v_t_247 = v_y_246;
      break;
    }
    default: heff_nomatch(v_b_243);
    }
    V v_t_248 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_247, NTAG(TAG_Nil)});
    V v_t_249 = (g_heff_2ecompile_2eearly_2ecallsW(v_t_248));
    if ((heff_dup(v_t_249) == NTAG(TAG_True))) {
      heff_drop(v_t_249);
      V v_f_2410 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_240));
      return ((HeffT2){{v_f_2410, heff_tag_n(TAG_Cons, 2, (V[]){v_b_243, v_bs_244})}});
    } else {
      heff_drop(v_t_249);
      V t_0 = heff_tag_n(TAG_Cons, 2, (V[]){v_b_243, v_acc_240});
      V t_1 = v_bs_244;
      v_acc_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
HEFF_LIT(g_heff_2ecompile_2eearly_2etraverseS_24s282732620x734369920_24cpr_str0, 1, "$");

HeffT2 g_heff_2ecompile_2eearly_2etraverseS_24s282732620x734369920_24cpr(V v_x2_240, V v_p_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return ((HeffT2){{NTAG(TAG_Nil), v_p_241}});
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    HeffT2 v_t_244 = (g_heff_2ecompile_2eearly_2etraverseS_24s282732620x734369920_24cpr(v_xs_243, heff_intAdd(heff_dup(v_p_241), MK_INT(1LL))));
    {
      V v_field_245 = v_t_244.f[0];
      V v_field_246 = v_t_244.f[1];
      V v_x_247 = v_field_245;
      V v_n_248 = v_field_246;
      V v_t_249 = heff_strAppend(((V)&g_heff_2ecompile_2eearly_2etraverseS_24s282732620x734369920_24cpr_str0), heff_intShow(v_p_241));
      V v_t_2410 = heff_strAppend(heff_dup(heff_rfield(v_x_242, 1)), v_t_249);
      V v_f_2411 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){heff_rec_n(2, shape_r__x, (V[]){v_x_242, v_t_2410}), v_x_247});
      return ((HeffT2){{v_f_2411, v_n_248}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_240)}});
  }
}
V g_heff_2ecompile_2eearly_2eatBinding_lam0(V self, V *args);
V g_heff_2ecompile_2eearly_2eatBinding_lam2(V self, V *args);
V g_heff_2ecompile_2eearly_2eatBinding_lam1(V self, V *args);
Clo g_heff_2ecompile_2eearly_2eatBinding_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eearly_2eatBinding_entry, 4, 0};

V g_heff_2ecompile_2eearly_2eatBinding(V v_before_240, V v_call_241, V v_after_242, V v_last_243) {
top: ;
  V v_t_244 = (g_prelude_2e_2b_2b(heff_dup(v_before_240), heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_call_241), heff_dup(v_after_242)})));
  V v_bound_245 = (g_list_2emap_24s1937570095x2110149801(v_t_244));
  V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_call_241), NTAG(TAG_Nil)});
  V v_t_247 = (g_prelude_2e_2b_2b(heff_dup(v_before_240), v_t_246));
  V v_before_248 = (g_list_2emap_24s1173914895x100384474(v_t_247));
  V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_last_243), NTAG(TAG_Nil)});
  V v_after_2410 = (g_prelude_2e_2b_2b_24f1085359736x1262841716(v_t_249, heff_dup(v_after_242)));
  V v_rs_2411 = (g_heff_2ecompile_2eearly_2ereadsW(NTAG(TAG_Nil), heff_dup(v_after_2410)));
  V v_t_2413 = (g_list_2efilter(heff_clo_n(g_heff_2ecompile_2eearly_2eatBinding_lam0, 1, 4, (V[]){v_bound_245, v_before_248, v_after_2410, heff_dup(v_rs_2411)}), v_rs_2411));
  V v_t_2414 = (g_heff_2ecompile_2eearly_2ereadsOnce(NTAG(TAG_Nil), v_t_2413));
  return heff_clo_n(g_heff_2ecompile_2eearly_2eatBinding_lam1, 1, 5, (V[]){v_t_2414, v_after_242, v_before_240, v_call_241, v_last_243});
}
V g_heff_2ecompile_2eearly_2eatBinding_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eearly_2eatBinding(a[0], a[1], a[2], a[3]);
}
V g_heff_2ecompile_2eearly_2eatBinding_lam0(V self, V *args) {
  V v_r_2412 = args[0];
  V v_bound_245 = heff_env(self)[0];
  V v_before_248 = heff_env(self)[1];
  V v_after_2410 = heff_env(self)[2];
  V v_rs_2411 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return ({ V a_0 = v_bound_245; V a_1 = v_before_248; V a_2 = v_after_2410; V a_3 = v_rs_2411; V a_4 = heff_get_n(v_r_2412, 0, 4); V r_ = (g_heff_2ecompile_2eearly_2ereadsEarly(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_bound_245); heff_drop(v_rs_2411); r_; });
}
V g_heff_2ecompile_2eearly_2eatBinding_lam2(V self, V *args) {
  V v_x2_2421 = args[0];
  V v_x_2419 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x2_2421)) {
  case TAG_MkPair: {
    V v_x_2422 = heff_field(v_x2_2421, 0);
    V v_a_2423 = heff_field(v_x2_2421, 1);
    V v_ru_24x2_2421_24MkPair = heff_take_reuse_n(v_x2_2421, 3ULL, 2);
    V v_t_2426;
    switch (heff_tag_of(v_x_2419)) {
    case TAG_Nil: {
      v_t_2426 = v_a_2423;
      break;
    }
    case TAG_Cons: {
      v_t_2426 = (g_heff_2ecompile_2eearly_2ereadGo(v_x_2419, v_a_2423));
      break;
    }
    default: heff_nomatch(v_x_2419);
    }
    return heff_tag_at_n(v_ru_24x2_2421_24MkPair, TAG_MkPair, 2, (V[]){v_x_2422, v_t_2426});
  }
  default: return heff_nomatch(v_x2_2421);
  }
}
V g_heff_2ecompile_2eearly_2eatBinding_lam1(V self, V *args) {
  V v_n_2415 = args[0];
  V v_t_2414 = heff_env(self)[0];
  V v_after_242 = heff_env(self)[1];
  V v_before_240 = heff_env(self)[2];
  V v_call_241 = heff_env(self)[3];
  V v_last_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  HeffT2 v_t_2416 = (g_heff_2ecompile_2eearly_2etraverseS_24s282732620x734369920_24cpr(v_t_2414, v_n_2415));
  {
    V v_field_2417 = v_t_2416.f[0];
    V v_field_2418 = v_t_2416.f[1];
    V v_x_2419 = v_field_2417;
    V v_n_2420 = v_field_2418;
    V v_t_2427 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2eearly_2eatBinding_lam2, 1, 1, (V[]){heff_dup(v_x_2419)}), v_after_242));
    V v_t_2428 = (g_prelude_2e_2b_2b(v_before_240, heff_tag_n(TAG_Cons, 2, (V[]){v_call_241, v_t_2427})));
    V v_t_2431;
    switch (heff_tag_of(v_x_2419)) {
    case TAG_Nil: {
      v_t_2431 = v_last_243;
      break;
    }
    case TAG_Cons: {
      v_t_2431 = (g_heff_2ecompile_2eearly_2ereadGo(heff_dup(v_x_2419), v_last_243));
      break;
    }
    default: heff_nomatch(v_x_2419);
    }
    V v_t_2432 = ({ V a_0 = v_t_2428; V a_1 = v_t_2431; V r_ = (g_heff_2ecompile_2eearly_2eletsOf(a_0, a_1)); heff_drop(v_t_2428); r_; });
    V v_x_2433 = ({ V a_0 = v_x_2419; V a_1 = v_t_2432; V r_ = (g_heff_2ecompile_2eearly_2eletsEarly(a_0, a_1)); heff_drop(v_x_2419); r_; });
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2433, v_n_2420});
  }
}
V g_heff_2ecompile_2eearly_2earmRead_24s208354557x207572461_lam0(V self, V *args);
Clo g_heff_2ecompile_2eearly_2earmRead_24s208354557x207572461_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eearly_2earmRead_24s208354557x207572461_entry, 2, 0};

V g_heff_2ecompile_2eearly_2earmRead_24s208354557x207572461(V v_es_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_MkArm: {
    V v_t_242 = heff_field(v_x3_241, 0);
    V v_vs_243 = heff_field(v_x3_241, 1);
    V v_b_244 = heff_field(v_x3_241, 2);
    V v_ru_24x3_241_24MkArm = heff_take_reuse_n(v_x3_241, 7ULL, 3);
    V v_es_248 = (g_list_2efilter(heff_clo_n(g_heff_2ecompile_2eearly_2earmRead_24s208354557x207572461_lam0, 1, 1, (V[]){heff_dup(v_vs_243)}), v_es_240));
    V v_t_2411;
    switch (heff_tag_of(v_es_248)) {
    case TAG_Nil: {
      v_t_2411 = v_b_244;
      break;
    }
    case TAG_Cons: {
      v_t_2411 = (g_heff_2ecompile_2eearly_2ereadGo(v_es_248, v_b_244));
      break;
    }
    default: heff_nomatch(v_es_248);
    }
    return heff_tag_at_n(v_ru_24x3_241_24MkArm, TAG_MkArm, 3, (V[]){v_t_242, v_vs_243, v_t_2411});
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_heff_2ecompile_2eearly_2earmRead_24s208354557x207572461_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eearly_2earmRead_24s208354557x207572461(a[0], a[1]);
}
V g_heff_2ecompile_2eearly_2earmRead_24s208354557x207572461_lam0(V self, V *args) {
  V v_e_245 = args[0];
  V v_vs_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_246 = heff_get_n(heff_get_n(v_e_245, 0, 2), 0, 4);
  V v_x1_247 = ({ V a_0 = v_t_246; V a_1 = v_vs_243; V r_ = (g_heff_2ecompile_2eearly_2eelemE(a_0, a_1)); heff_drop(v_vs_243); r_; });
  V v_ret_24bool = heff_bool(!(heff_dup(v_x1_247) == NTAG(TAG_True)));
  heff_drop(v_x1_247);
  return v_ret_24bool;
}
V g_heff_2ecompile_2eearly_2eatMatch_lam0(V self, V *args);
V g_heff_2ecompile_2eearly_2eatMatch_lam1(V self, V *args);
Clo g_heff_2ecompile_2eearly_2eatMatch_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eearly_2eatMatch_entry, 3, 0};

V g_heff_2ecompile_2eearly_2eatMatch(V v_before_240, V v_s_241, V v_arms_242) {
top: ;
  V v_t_243 = (g_list_2emap_24s1937570095x2110149801(heff_dup(v_before_240)));
  V v_t_244 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_arms_242)));
  V v_t_245 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_244; V r_ = (g_list_2efoldl_24s1530401830x609500251(a_0, a_1)); heff_drop(v_t_244); r_; });
  V v_bound_246 = (g_prelude_2e_2b_2b(v_t_243, v_t_245));
  V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_s_241), NTAG(TAG_Nil)});
  V v_before_248 = (g_prelude_2e_2b_2b_24f1085359736x1262841716(v_t_247, heff_dup(v_before_240)));
  V v_after_249 = (g_list_2emap_24s60612435x257154841(heff_dup(v_arms_242)));
  V v_rs_2410 = (g_heff_2ecompile_2eearly_2ereadsW(NTAG(TAG_Nil), heff_dup(v_after_249)));
  V v_t_2412 = (g_list_2efilter(heff_clo_n(g_heff_2ecompile_2eearly_2eatMatch_lam0, 1, 4, (V[]){v_bound_246, v_before_248, v_after_249, heff_dup(v_rs_2410)}), v_rs_2410));
  V v_t_2413 = (g_heff_2ecompile_2eearly_2ereadsOnce(NTAG(TAG_Nil), v_t_2412));
  return heff_clo_n(g_heff_2ecompile_2eearly_2eatMatch_lam1, 1, 4, (V[]){v_t_2413, v_arms_242, v_before_240, v_s_241});
}
V g_heff_2ecompile_2eearly_2eatMatch_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eearly_2eatMatch(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2eearly_2eatMatch_lam0(V self, V *args) {
  V v_r_2411 = args[0];
  V v_bound_246 = heff_env(self)[0];
  V v_before_248 = heff_env(self)[1];
  V v_after_249 = heff_env(self)[2];
  V v_rs_2410 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return ({ V a_0 = v_bound_246; V a_1 = v_before_248; V a_2 = v_after_249; V a_3 = v_rs_2410; V a_4 = heff_get_n(v_r_2411, 0, 4); V r_ = (g_heff_2ecompile_2eearly_2ereadsEarly(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_bound_246); heff_drop(v_rs_2410); r_; });
}
V g_heff_2ecompile_2eearly_2eatMatch_lam1(V self, V *args) {
  V v_n_2414 = args[0];
  V v_t_2413 = heff_env(self)[0];
  V v_arms_242 = heff_env(self)[1];
  V v_before_240 = heff_env(self)[2];
  V v_s_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  HeffT2 v_t_2415 = (g_heff_2ecompile_2eearly_2etraverseS_24s282732620x734369920_24cpr(v_t_2413, v_n_2414));
  {
    V v_field_2416 = v_t_2415.f[0];
    V v_field_2417 = v_t_2415.f[1];
    V v_x_2418 = v_field_2416;
    V v_n_2419 = v_field_2417;
    V v_t_2420 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eearly_2earmRead_24s208354557x207572461_clo), 1, (V[]){heff_dup(v_x_2418)}));
    V v_t_2421 = (g_list_2emap(v_t_2420, v_arms_242));
    V v_t_2422 = ({ V a_0 = v_before_240; V a_1 = heff_tag_n(TAG_EMatch, 2, (V[]){v_s_241, v_t_2421}); V r_ = (g_heff_2ecompile_2eearly_2eletsOf(a_0, a_1)); heff_drop(v_before_240); r_; });
    V v_x_2423 = ({ V a_0 = v_x_2418; V a_1 = v_t_2422; V r_ = (g_heff_2ecompile_2eearly_2eletsEarly(a_0, a_1)); heff_drop(v_x_2418); r_; });
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2423, v_n_2419});
  }
}
V g_heff_2ecompile_2eearly_2eatEnd_lam0(V self, V *args);
V g_heff_2ecompile_2eearly_2eatEnd_lam1(V self, V *args);
V g_heff_2ecompile_2eearly_2eatEnd_lam2(V self, V *args);
V g_heff_2ecompile_2eearly_2eatEnd_lam3(V self, V *args);
V g_heff_2ecompile_2eearly_2eatEnd_lam4(V self, V *args);
V g_heff_2ecompile_2eearly_2eatEnd_lam5(V self, V *args);
V g_heff_2ecompile_2eearly_2eatEnd_lam6(V self, V *args);
V g_heff_2ecompile_2eearly_2eatEnd_lam7(V self, V *args);
V g_heff_2ecompile_2eearly_2eatEnd_lam8(V self, V *args);
V g_heff_2ecompile_2eearly_2eatEnd_lam9(V self, V *args);
V g_heff_2ecompile_2eearly_2eatEnd_lam10(V self, V *args);
V g_heff_2ecompile_2eearly_2eatEnd_lam11(V self, V *args);
V g_heff_2ecompile_2eearly_2eatEnd_lam12(V self, V *args);
V g_heff_2ecompile_2eearly_2eatEnd_lam13(V self, V *args);
V g_heff_2ecompile_2eearly_2eatEnd_lam14(V self, V *args);
V g_heff_2ecompile_2eearly_2eatEnd_lam15(V self, V *args);
V g_heff_2ecompile_2eearly_2eatEnd_lam16(V self, V *args);
V g_heff_2ecompile_2eearly_2eatEnd_lam17(V self, V *args);
V g_heff_2ecompile_2eearly_2eatEnd_lam18(V self, V *args);
V g_heff_2ecompile_2eearly_2eatEnd_lam19(V self, V *args);
Clo g_heff_2ecompile_2eearly_2eatEnd_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eearly_2eatEnd_entry, 2, 0};

V g_heff_2ecompile_2eearly_2eatEnd(V v_before_240, V v_last_241) {
top: ;
  switch (heff_tag_of(v_last_241)) {
  case TAG_EVar: {
    V v_x_243 = ({ V a_0 = v_before_240; V a_1 = v_last_241; V r_ = (g_heff_2ecompile_2eearly_2eletsOf(a_0, a_1)); heff_drop(v_before_240); r_; });
    return heff_clo_n(g_heff_2ecompile_2eearly_2eatEnd_lam0, 1, 1, (V[]){v_x_243});
  }
  case TAG_EGlobal: {
    V v_x_246 = ({ V a_0 = v_before_240; V a_1 = v_last_241; V r_ = (g_heff_2ecompile_2eearly_2eletsOf(a_0, a_1)); heff_drop(v_before_240); r_; });
    return heff_clo_n(g_heff_2ecompile_2eearly_2eatEnd_lam1, 1, 1, (V[]){v_x_246});
  }
  case TAG_ELam: {
    V v_x_2410 = ({ V a_0 = v_before_240; V a_1 = v_last_241; V r_ = (g_heff_2ecompile_2eearly_2eletsOf(a_0, a_1)); heff_drop(v_before_240); r_; });
    return heff_clo_n(g_heff_2ecompile_2eearly_2eatEnd_lam2, 1, 1, (V[]){v_x_2410});
  }
  case TAG_EApp: {
    V v_x_2414 = ({ V a_0 = v_before_240; V a_1 = v_last_241; V r_ = (g_heff_2ecompile_2eearly_2eletsOf(a_0, a_1)); heff_drop(v_before_240); r_; });
    return heff_clo_n(g_heff_2ecompile_2eearly_2eatEnd_lam3, 1, 1, (V[]){v_x_2414});
  }
  case TAG_ELet: {
    V v_x_2419 = ({ V a_0 = v_before_240; V a_1 = v_last_241; V r_ = (g_heff_2ecompile_2eearly_2eletsOf(a_0, a_1)); heff_drop(v_before_240); r_; });
    return heff_clo_n(g_heff_2ecompile_2eearly_2eatEnd_lam4, 1, 1, (V[]){v_x_2419});
  }
  case TAG_ERecord: {
    V v_x_2423 = ({ V a_0 = v_before_240; V a_1 = v_last_241; V r_ = (g_heff_2ecompile_2eearly_2eletsOf(a_0, a_1)); heff_drop(v_before_240); r_; });
    return heff_clo_n(g_heff_2ecompile_2eearly_2eatEnd_lam5, 1, 1, (V[]){v_x_2423});
  }
  case TAG_EProj: {
    V v_x_2429 = ({ V a_0 = v_before_240; V a_1 = v_last_241; V r_ = (g_heff_2ecompile_2eearly_2eletsOf(a_0, a_1)); heff_drop(v_before_240); r_; });
    return heff_clo_n(g_heff_2ecompile_2eearly_2eatEnd_lam6, 1, 1, (V[]){v_x_2429});
  }
  case TAG_ETag: {
    V v_x_2434 = ({ V a_0 = v_before_240; V a_1 = v_last_241; V r_ = (g_heff_2ecompile_2eearly_2eletsOf(a_0, a_1)); heff_drop(v_before_240); r_; });
    return heff_clo_n(g_heff_2ecompile_2eearly_2eatEnd_lam7, 1, 1, (V[]){v_x_2434});
  }
  case TAG_EMatch: {
    V v_s_2436 = heff_field(v_last_241, 0);
    V v_arms_2437 = heff_field(v_last_241, 1);
    V v_ru_24last_241_24EMatch = heff_take_reuse_n(v_last_241, 3ULL, 2);
    V v_t_2438 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_s_2436), NTAG(TAG_Nil)});
    V v_t_2439 = (g_heff_2ecompile_2eearly_2ecallsW(v_t_2438));
    if ((heff_dup(v_t_2439) == NTAG(TAG_True))) {
      heff_drop_cell(v_ru_24last_241_24EMatch, 2);
      heff_drop(v_t_2439);
      return (g_heff_2ecompile_2eearly_2eatMatch(v_before_240, v_s_2436, v_arms_2437));
    } else {
      heff_drop(v_t_2439);
      V v_x_2440 = ({ V a_0 = v_before_240; V a_1 = heff_tag_at_n(v_ru_24last_241_24EMatch, TAG_EMatch, 2, (V[]){v_s_2436, v_arms_2437}); V r_ = (g_heff_2ecompile_2eearly_2eletsOf(a_0, a_1)); heff_drop(v_before_240); r_; });
      return heff_clo_n(g_heff_2ecompile_2eearly_2eatEnd_lam8, 1, 1, (V[]){v_x_2440});
    }
  }
  case TAG_EPrim: {
    V v_x_2443 = ({ V a_0 = v_before_240; V a_1 = v_last_241; V r_ = (g_heff_2ecompile_2eearly_2eletsOf(a_0, a_1)); heff_drop(v_before_240); r_; });
    return heff_clo_n(g_heff_2ecompile_2eearly_2eatEnd_lam9, 1, 1, (V[]){v_x_2443});
  }
  case TAG_EPrimCall: {
    V v_x_2447 = ({ V a_0 = v_before_240; V a_1 = v_last_241; V r_ = (g_heff_2ecompile_2eearly_2eletsOf(a_0, a_1)); heff_drop(v_before_240); r_; });
    return heff_clo_n(g_heff_2ecompile_2eearly_2eatEnd_lam10, 1, 1, (V[]){v_x_2447});
  }
  case TAG_ECall: {
    V v_x_2451 = ({ V a_0 = v_before_240; V a_1 = v_last_241; V r_ = (g_heff_2ecompile_2eearly_2eletsOf(a_0, a_1)); heff_drop(v_before_240); r_; });
    return heff_clo_n(g_heff_2ecompile_2eearly_2eatEnd_lam11, 1, 1, (V[]){v_x_2451});
  }
  case TAG_EInt: {
    V v_x_2454 = ({ V a_0 = v_before_240; V a_1 = v_last_241; V r_ = (g_heff_2ecompile_2eearly_2eletsOf(a_0, a_1)); heff_drop(v_before_240); r_; });
    return heff_clo_n(g_heff_2ecompile_2eearly_2eatEnd_lam12, 1, 1, (V[]){v_x_2454});
  }
  case TAG_EFloat: {
    V v_x_2457 = ({ V a_0 = v_before_240; V a_1 = v_last_241; V r_ = (g_heff_2ecompile_2eearly_2eletsOf(a_0, a_1)); heff_drop(v_before_240); r_; });
    return heff_clo_n(g_heff_2ecompile_2eearly_2eatEnd_lam13, 1, 1, (V[]){v_x_2457});
  }
  case TAG_EStr: {
    V v_x_2460 = ({ V a_0 = v_before_240; V a_1 = v_last_241; V r_ = (g_heff_2ecompile_2eearly_2eletsOf(a_0, a_1)); heff_drop(v_before_240); r_; });
    return heff_clo_n(g_heff_2ecompile_2eearly_2eatEnd_lam14, 1, 1, (V[]){v_x_2460});
  }
  case TAG_EBytes: {
    V v_x_2463 = ({ V a_0 = v_before_240; V a_1 = v_last_241; V r_ = (g_heff_2ecompile_2eearly_2eletsOf(a_0, a_1)); heff_drop(v_before_240); r_; });
    return heff_clo_n(g_heff_2ecompile_2eearly_2eatEnd_lam15, 1, 1, (V[]){v_x_2463});
  }
  case TAG_EFixed: {
    V v_x_2467 = ({ V a_0 = v_before_240; V a_1 = v_last_241; V r_ = (g_heff_2ecompile_2eearly_2eletsOf(a_0, a_1)); heff_drop(v_before_240); r_; });
    return heff_clo_n(g_heff_2ecompile_2eearly_2eatEnd_lam16, 1, 1, (V[]){v_x_2467});
  }
  case TAG_EFloat32: {
    V v_x_2470 = ({ V a_0 = v_before_240; V a_1 = v_last_241; V r_ = (g_heff_2ecompile_2eearly_2eletsOf(a_0, a_1)); heff_drop(v_before_240); r_; });
    return heff_clo_n(g_heff_2ecompile_2eearly_2eatEnd_lam17, 1, 1, (V[]){v_x_2470});
  }
  case TAG_EAbandon: {
    V v_x_2472 = ({ V a_0 = v_before_240; V a_1 = v_last_241; V r_ = (g_heff_2ecompile_2eearly_2eletsOf(a_0, a_1)); heff_drop(v_before_240); r_; });
    return heff_clo_n(g_heff_2ecompile_2eearly_2eatEnd_lam18, 1, 1, (V[]){v_x_2472});
  }
  case TAG_EFix: {
    V v_x_2476 = ({ V a_0 = v_before_240; V a_1 = v_last_241; V r_ = (g_heff_2ecompile_2eearly_2eletsOf(a_0, a_1)); heff_drop(v_before_240); r_; });
    return heff_clo_n(g_heff_2ecompile_2eearly_2eatEnd_lam19, 1, 1, (V[]){v_x_2476});
  }
  default: return heff_nomatch(v_last_241);
  }
}
V g_heff_2ecompile_2eearly_2eatEnd_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eearly_2eatEnd(a[0], a[1]);
}
V g_heff_2ecompile_2eearly_2eatEnd_lam0(V self, V *args) {
  V v_n_244 = args[0];
  V v_x_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_243, v_n_244});
}
V g_heff_2ecompile_2eearly_2eatEnd_lam1(V self, V *args) {
  V v_n_247 = args[0];
  V v_x_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_246, v_n_247});
}
V g_heff_2ecompile_2eearly_2eatEnd_lam2(V self, V *args) {
  V v_n_2411 = args[0];
  V v_x_2410 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2410, v_n_2411});
}
V g_heff_2ecompile_2eearly_2eatEnd_lam3(V self, V *args) {
  V v_n_2415 = args[0];
  V v_x_2414 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2414, v_n_2415});
}
V g_heff_2ecompile_2eearly_2eatEnd_lam4(V self, V *args) {
  V v_n_2420 = args[0];
  V v_x_2419 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2419, v_n_2420});
}
V g_heff_2ecompile_2eearly_2eatEnd_lam5(V self, V *args) {
  V v_n_2424 = args[0];
  V v_x_2423 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2423, v_n_2424});
}
V g_heff_2ecompile_2eearly_2eatEnd_lam6(V self, V *args) {
  V v_n_2430 = args[0];
  V v_x_2429 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2429, v_n_2430});
}
V g_heff_2ecompile_2eearly_2eatEnd_lam7(V self, V *args) {
  V v_n_2435 = args[0];
  V v_x_2434 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2434, v_n_2435});
}
V g_heff_2ecompile_2eearly_2eatEnd_lam8(V self, V *args) {
  V v_n_2441 = args[0];
  V v_x_2440 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2440, v_n_2441});
}
V g_heff_2ecompile_2eearly_2eatEnd_lam9(V self, V *args) {
  V v_n_2444 = args[0];
  V v_x_2443 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2443, v_n_2444});
}
V g_heff_2ecompile_2eearly_2eatEnd_lam10(V self, V *args) {
  V v_n_2448 = args[0];
  V v_x_2447 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2447, v_n_2448});
}
V g_heff_2ecompile_2eearly_2eatEnd_lam11(V self, V *args) {
  V v_n_2452 = args[0];
  V v_x_2451 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2451, v_n_2452});
}
V g_heff_2ecompile_2eearly_2eatEnd_lam12(V self, V *args) {
  V v_n_2455 = args[0];
  V v_x_2454 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2454, v_n_2455});
}
V g_heff_2ecompile_2eearly_2eatEnd_lam13(V self, V *args) {
  V v_n_2458 = args[0];
  V v_x_2457 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2457, v_n_2458});
}
V g_heff_2ecompile_2eearly_2eatEnd_lam14(V self, V *args) {
  V v_n_2461 = args[0];
  V v_x_2460 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2460, v_n_2461});
}
V g_heff_2ecompile_2eearly_2eatEnd_lam15(V self, V *args) {
  V v_n_2464 = args[0];
  V v_x_2463 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2463, v_n_2464});
}
V g_heff_2ecompile_2eearly_2eatEnd_lam16(V self, V *args) {
  V v_n_2468 = args[0];
  V v_x_2467 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2467, v_n_2468});
}
V g_heff_2ecompile_2eearly_2eatEnd_lam17(V self, V *args) {
  V v_n_2471 = args[0];
  V v_x_2470 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2470, v_n_2471});
}
V g_heff_2ecompile_2eearly_2eatEnd_lam18(V self, V *args) {
  V v_n_2473 = args[0];
  V v_x_2472 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2472, v_n_2473});
}
V g_heff_2ecompile_2eearly_2eatEnd_lam19(V self, V *args) {
  V v_n_2477 = args[0];
  V v_x_2476 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x_2476, v_n_2477});
}
V g_heff_2ecompile_2eearly_2ekidsWith_lam0(V self, V *args);
V g_heff_2ecompile_2eearly_2ekidsWith_lam1(V self, V *args);
V g_heff_2ecompile_2eearly_2ekidsWith_lam2(V self, V *args);
V g_heff_2ecompile_2eearly_2ekidsWith_lam3(V self, V *args);
V g_heff_2ecompile_2eearly_2ekidsWith_lam4(V self, V *args);
V g_heff_2ecompile_2eearly_2ekidsWith_lam6(V self, V *args);
V g_heff_2ecompile_2eearly_2ekidsWith_lam5(V self, V *args);
V g_heff_2ecompile_2eearly_2ekidsWith_lam7(V self, V *args);
V g_heff_2ecompile_2eearly_2ekidsWith_lam8(V self, V *args);
V g_heff_2ecompile_2eearly_2ekidsWith_lam9(V self, V *args);
V g_heff_2ecompile_2eearly_2ekidsWith_lam12(V self, V *args);
V g_heff_2ecompile_2eearly_2ekidsWith_lam11(V self, V *args);
V g_heff_2ecompile_2eearly_2ekidsWith_lam10(V self, V *args);
V g_heff_2ecompile_2eearly_2ekidsWith_lam13(V self, V *args);
V g_heff_2ecompile_2eearly_2ekidsWith_lam14(V self, V *args);
V g_heff_2ecompile_2eearly_2ekidsWith_lam15(V self, V *args);
V g_heff_2ecompile_2eearly_2ekidsWith_lam16(V self, V *args);
V g_heff_2ecompile_2eearly_2ekidsWith_lam17(V self, V *args);
V g_heff_2ecompile_2eearly_2ekidsWith_lam18(V self, V *args);
V g_heff_2ecompile_2eearly_2ekidsWith_lam19(V self, V *args);
V g_heff_2ecompile_2eearly_2ekidsWith_lam20(V self, V *args);
V g_heff_2ecompile_2eearly_2ekidsWith_lam21(V self, V *args);
V g_heff_2ecompile_2eearly_2ekidsWith_lam22(V self, V *args);
V g_heff_2ecompile_2eearly_2ekidsWith_lam23(V self, V *args);
Clo g_heff_2ecompile_2eearly_2ekidsWith_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eearly_2ekidsWith_entry, 2, 0};

V g_heff_2ecompile_2eearly_2ekidsWith(V v_go_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_EVar: {
    heff_drop(v_go_240);
    return heff_clo_n(g_heff_2ecompile_2eearly_2ekidsWith_lam0, 1, 1, (V[]){v_x2_241});
  }
  case TAG_EGlobal: {
    heff_drop(v_go_240);
    return heff_clo_n(g_heff_2ecompile_2eearly_2ekidsWith_lam1, 1, 1, (V[]){v_x2_241});
  }
  case TAG_ELam: {
    V v_xs_246 = heff_field(v_x2_241, 0);
    V v_b_247 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_m_248 = heff_tr(heff_call(v_go_240, 2, (V[]){NTAG(TAG_True), v_b_247}));
    return heff_clo_n(g_heff_2ecompile_2eearly_2ekidsWith_lam2, 1, 2, (V[]){v_m_248, v_xs_246});
  }
  case TAG_EApp: {
    V v_f_2413 = heff_field(v_x2_241, 0);
    V v_as_2414 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_m_2415 = heff_tr(heff_call(heff_dup(v_go_240), 2, (V[]){NTAG(TAG_True), v_f_2413}));
    return heff_clo_n(g_heff_2ecompile_2eearly_2ekidsWith_lam3, 1, 3, (V[]){v_m_2415, v_go_240, v_as_2414});
  }
  case TAG_ELet: {
    V v_x_2425 = heff_field(v_x2_241, 0);
    V v_a_2426 = heff_field(v_x2_241, 1);
    V v_b_2427 = heff_field(v_x2_241, 2);
    heff_take_n(v_x2_241, 7ULL, 3);
    V v_m_2428 = heff_tr(heff_call(heff_dup(v_go_240), 2, (V[]){NTAG(TAG_True), v_a_2426}));
    return heff_clo_n(g_heff_2ecompile_2eearly_2ekidsWith_lam4, 1, 4, (V[]){v_m_2428, v_go_240, v_b_2427, v_x_2425});
  }
  case TAG_ERecord: {
    V v_fs_2437 = heff_field(v_x2_241, 0);
    V v_ts_2438 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_m_2447 = (g_heff_2ecompile_2eearly_2etraverseS(heff_clo_n(g_heff_2ecompile_2eearly_2ekidsWith_lam5, 1, 1, (V[]){v_go_240}), v_fs_2437));
    return heff_clo_n(g_heff_2ecompile_2eearly_2ekidsWith_lam7, 1, 2, (V[]){v_m_2447, v_ts_2438});
  }
  case TAG_EProj: {
    V v_e_2452 = heff_field(v_x2_241, 0);
    V v_l_2453 = heff_field(v_x2_241, 1);
    V v_sh_2454 = heff_field(v_x2_241, 2);
    V v_t_2455 = heff_field(v_x2_241, 3);
    heff_take_n(v_x2_241, 15ULL, 4);
    V v_m_2456 = heff_tr(heff_call(v_go_240, 2, (V[]){NTAG(TAG_True), v_e_2452}));
    return heff_clo_n(g_heff_2ecompile_2eearly_2ekidsWith_lam8, 1, 4, (V[]){v_m_2456, v_l_2453, v_sh_2454, v_t_2455});
  }
  case TAG_ETag: {
    V v_t_2461 = heff_field(v_x2_241, 0);
    V v_as_2462 = heff_field(v_x2_241, 1);
    V v_ts_2463 = heff_field(v_x2_241, 2);
    heff_take_n(v_x2_241, 7ULL, 3);
    V v_t_2464 = heff_tr(heff_call(v_go_240, 1, (V[]){NTAG(TAG_True)}));
    V v_m_2465 = (g_heff_2ecompile_2eearly_2etraverseS(v_t_2464, v_as_2462));
    return heff_clo_n(g_heff_2ecompile_2eearly_2ekidsWith_lam9, 1, 3, (V[]){v_m_2465, v_t_2461, v_ts_2463});
  }
  case TAG_EMatch: {
    V v_s_2470 = heff_field(v_x2_241, 0);
    V v_arms_2471 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_m_2472 = heff_tr(heff_call(heff_dup(v_go_240), 2, (V[]){NTAG(TAG_True), v_s_2470}));
    return heff_clo_n(g_heff_2ecompile_2eearly_2ekidsWith_lam10, 1, 3, (V[]){v_m_2472, v_go_240, v_arms_2471});
  }
  case TAG_EPrim: {
    heff_drop(v_go_240);
    return heff_clo_n(g_heff_2ecompile_2eearly_2ekidsWith_lam13, 1, 1, (V[]){v_x2_241});
  }
  case TAG_EPrimCall: {
    V v_p_2492 = heff_field(v_x2_241, 0);
    V v_as_2493 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_t_2494 = heff_tr(heff_call(v_go_240, 1, (V[]){NTAG(TAG_True)}));
    V v_m_2495 = (g_heff_2ecompile_2eearly_2etraverseS(v_t_2494, v_as_2493));
    return heff_clo_n(g_heff_2ecompile_2eearly_2ekidsWith_lam14, 1, 2, (V[]){v_m_2495, v_p_2492});
  }
  case TAG_ECall: {
    V v_g_24100 = heff_field(v_x2_241, 0);
    V v_as_24101 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_t_24102 = heff_tr(heff_call(v_go_240, 1, (V[]){NTAG(TAG_True)}));
    V v_m_24103 = (g_heff_2ecompile_2eearly_2etraverseS(v_t_24102, v_as_24101));
    return heff_clo_n(g_heff_2ecompile_2eearly_2ekidsWith_lam15, 1, 2, (V[]){v_m_24103, v_g_24100});
  }
  case TAG_EInt: {
    heff_drop(v_go_240);
    return heff_clo_n(g_heff_2ecompile_2eearly_2ekidsWith_lam16, 1, 1, (V[]){v_x2_241});
  }
  case TAG_EFloat: {
    heff_drop(v_go_240);
    return heff_clo_n(g_heff_2ecompile_2eearly_2ekidsWith_lam17, 1, 1, (V[]){v_x2_241});
  }
  case TAG_EStr: {
    heff_drop(v_go_240);
    return heff_clo_n(g_heff_2ecompile_2eearly_2ekidsWith_lam18, 1, 1, (V[]){v_x2_241});
  }
  case TAG_EBytes: {
    heff_drop(v_go_240);
    return heff_clo_n(g_heff_2ecompile_2eearly_2ekidsWith_lam19, 1, 1, (V[]){v_x2_241});
  }
  case TAG_EFixed: {
    heff_drop(v_go_240);
    return heff_clo_n(g_heff_2ecompile_2eearly_2ekidsWith_lam20, 1, 1, (V[]){v_x2_241});
  }
  case TAG_EFloat32: {
    heff_drop(v_go_240);
    return heff_clo_n(g_heff_2ecompile_2eearly_2ekidsWith_lam21, 1, 1, (V[]){v_x2_241});
  }
  case TAG_EAbandon: {
    heff_drop(v_go_240);
    return heff_clo_n(g_heff_2ecompile_2eearly_2ekidsWith_lam22, 1, 1, (V[]){v_x2_241});
  }
  case TAG_EFix: {
    heff_drop(v_go_240);
    return heff_clo_n(g_heff_2ecompile_2eearly_2ekidsWith_lam23, 1, 1, (V[]){v_x2_241});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2eearly_2ekidsWith_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eearly_2ekidsWith(a[0], a[1]);
}
V g_heff_2ecompile_2eearly_2ekidsWith_lam0(V self, V *args) {
  V v_n_243 = args[0];
  V v_x2_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x2_241, v_n_243});
}
V g_heff_2ecompile_2eearly_2ekidsWith_lam1(V self, V *args) {
  V v_n_245 = args[0];
  V v_x2_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x2_241, v_n_245});
}
V g_heff_2ecompile_2eearly_2ekidsWith_lam2(V self, V *args) {
  V v_n_249 = args[0];
  V v_m_248 = heff_env(self)[0];
  V v_xs_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2410 = heff_tr(heff_call(v_m_248, 1, (V[]){v_n_249}));
  switch (heff_tag_of(v_x2_2410)) {
  case TAG_MkPair: {
    V v_x_2411 = heff_field(v_x2_2410, 0);
    V v_n_2412 = heff_field(v_x2_2410, 1);
    V v_ru_24x2_2410_24MkPair = heff_take_reuse_n(v_x2_2410, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2410_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELam, 2, (V[]){v_xs_246, v_x_2411}), v_n_2412});
  }
  default: return heff_nomatch(v_x2_2410);
  }
}
V g_heff_2ecompile_2eearly_2ekidsWith_lam3(V self, V *args) {
  V v_n_2416 = args[0];
  V v_m_2415 = heff_env(self)[0];
  V v_go_240 = heff_env(self)[1];
  V v_as_2414 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2417 = heff_tr(heff_call(v_m_2415, 1, (V[]){v_n_2416}));
  switch (heff_tag_of(v_x2_2417)) {
  case TAG_MkPair: {
    V v_x_2418 = heff_field(v_x2_2417, 0);
    V v_n_2419 = heff_field(v_x2_2417, 1);
    V v_ru_24x2_2417_24MkPair = heff_take_reuse_n(v_x2_2417, 3ULL, 2);
    V v_t_2420 = heff_tr(heff_call(v_go_240, 1, (V[]){NTAG(TAG_True)}));
    V v_m_2421 = (g_heff_2ecompile_2eearly_2etraverseS(v_t_2420, v_as_2414));
    V v_x2_2422 = heff_tr(heff_call(v_m_2421, 1, (V[]){v_n_2419}));
    switch (heff_tag_of(v_x2_2422)) {
    case TAG_MkPair: {
      V v_x_2423 = heff_field(v_x2_2422, 0);
      V v_n_2424 = heff_field(v_x2_2422, 1);
      heff_take_n(v_x2_2422, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2417_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_x_2418, v_x_2423}), v_n_2424});
    }
    default: return heff_nomatch(v_x2_2422);
    }
  }
  default: return heff_nomatch(v_x2_2417);
  }
}
V g_heff_2ecompile_2eearly_2ekidsWith_lam4(V self, V *args) {
  V v_n_2429 = args[0];
  V v_m_2428 = heff_env(self)[0];
  V v_go_240 = heff_env(self)[1];
  V v_b_2427 = heff_env(self)[2];
  V v_x_2425 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2430 = heff_tr(heff_call(v_m_2428, 1, (V[]){v_n_2429}));
  switch (heff_tag_of(v_x2_2430)) {
  case TAG_MkPair: {
    V v_x_2431 = heff_field(v_x2_2430, 0);
    V v_n_2432 = heff_field(v_x2_2430, 1);
    V v_ru_24x2_2430_24MkPair = heff_take_reuse_n(v_x2_2430, 3ULL, 2);
    V v_m_2433 = heff_tr(heff_call(v_go_240, 2, (V[]){NTAG(TAG_False), v_b_2427}));
    V v_x2_2434 = heff_tr(heff_call(v_m_2433, 1, (V[]){v_n_2432}));
    switch (heff_tag_of(v_x2_2434)) {
    case TAG_MkPair: {
      V v_x_2435 = heff_field(v_x2_2434, 0);
      V v_n_2436 = heff_field(v_x2_2434, 1);
      heff_take_n(v_x2_2434, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2430_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_x_2425, v_x_2431, v_x_2435}), v_n_2436});
    }
    default: return heff_nomatch(v_x2_2434);
    }
  }
  default: return heff_nomatch(v_x2_2430);
  }
}
V g_heff_2ecompile_2eearly_2ekidsWith_lam6(V self, V *args) {
  V v_n_2443 = args[0];
  V v_m_2442 = heff_env(self)[0];
  V v_l_2440 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2444 = heff_tr(heff_call(v_m_2442, 1, (V[]){v_n_2443}));
  switch (heff_tag_of(v_x2_2444)) {
  case TAG_MkPair: {
    V v_x_2445 = heff_field(v_x2_2444, 0);
    V v_n_2446 = heff_field(v_x2_2444, 1);
    V v_ru_24x2_2444_24MkPair = heff_take_reuse_n(v_x2_2444, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2444_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_l_2440, v_x_2445}), v_n_2446});
  }
  default: return heff_nomatch(v_x2_2444);
  }
}
V g_heff_2ecompile_2eearly_2ekidsWith_lam5(V self, V *args) {
  V v_x2_2439 = args[0];
  V v_go_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x2_2439)) {
  case TAG_MkPair: {
    V v_l_2440 = heff_field(v_x2_2439, 0);
    V v_e_2441 = heff_field(v_x2_2439, 1);
    heff_take_n(v_x2_2439, 3ULL, 2);
    V v_m_2442 = heff_tr(heff_call(v_go_240, 2, (V[]){NTAG(TAG_True), v_e_2441}));
    return heff_clo_n(g_heff_2ecompile_2eearly_2ekidsWith_lam6, 1, 2, (V[]){v_m_2442, v_l_2440});
  }
  default: return heff_nomatch(v_x2_2439);
  }
}
V g_heff_2ecompile_2eearly_2ekidsWith_lam7(V self, V *args) {
  V v_n_2448 = args[0];
  V v_m_2447 = heff_env(self)[0];
  V v_ts_2438 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2449 = heff_tr(heff_call(v_m_2447, 1, (V[]){v_n_2448}));
  switch (heff_tag_of(v_x2_2449)) {
  case TAG_MkPair: {
    V v_x_2450 = heff_field(v_x2_2449, 0);
    V v_n_2451 = heff_field(v_x2_2449, 1);
    V v_ru_24x2_2449_24MkPair = heff_take_reuse_n(v_x2_2449, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2449_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ERecord, 2, (V[]){v_x_2450, v_ts_2438}), v_n_2451});
  }
  default: return heff_nomatch(v_x2_2449);
  }
}
V g_heff_2ecompile_2eearly_2ekidsWith_lam8(V self, V *args) {
  V v_n_2457 = args[0];
  V v_m_2456 = heff_env(self)[0];
  V v_l_2453 = heff_env(self)[1];
  V v_sh_2454 = heff_env(self)[2];
  V v_t_2455 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x2_2458 = heff_tr(heff_call(v_m_2456, 1, (V[]){v_n_2457}));
  switch (heff_tag_of(v_x2_2458)) {
  case TAG_MkPair: {
    V v_x_2459 = heff_field(v_x2_2458, 0);
    V v_n_2460 = heff_field(v_x2_2458, 1);
    V v_ru_24x2_2458_24MkPair = heff_take_reuse_n(v_x2_2458, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2458_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EProj, 4, (V[]){v_x_2459, v_l_2453, v_sh_2454, v_t_2455}), v_n_2460});
  }
  default: return heff_nomatch(v_x2_2458);
  }
}
V g_heff_2ecompile_2eearly_2ekidsWith_lam9(V self, V *args) {
  V v_n_2466 = args[0];
  V v_m_2465 = heff_env(self)[0];
  V v_t_2461 = heff_env(self)[1];
  V v_ts_2463 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2467 = heff_tr(heff_call(v_m_2465, 1, (V[]){v_n_2466}));
  switch (heff_tag_of(v_x2_2467)) {
  case TAG_MkPair: {
    V v_x_2468 = heff_field(v_x2_2467, 0);
    V v_n_2469 = heff_field(v_x2_2467, 1);
    V v_ru_24x2_2467_24MkPair = heff_take_reuse_n(v_x2_2467, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2467_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ETag, 3, (V[]){v_t_2461, v_x_2468, v_ts_2463}), v_n_2469});
  }
  default: return heff_nomatch(v_x2_2467);
  }
}
V g_heff_2ecompile_2eearly_2ekidsWith_lam12(V self, V *args) {
  V v_n_2482 = args[0];
  V v_m_2481 = heff_env(self)[0];
  V v_t_2478 = heff_env(self)[1];
  V v_vs_2479 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2483 = heff_tr(heff_call(v_m_2481, 1, (V[]){v_n_2482}));
  switch (heff_tag_of(v_x2_2483)) {
  case TAG_MkPair: {
    V v_x_2484 = heff_field(v_x2_2483, 0);
    V v_n_2485 = heff_field(v_x2_2483, 1);
    V v_ru_24x2_2483_24MkPair = heff_take_reuse_n(v_x2_2483, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2483_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_MkArm, 3, (V[]){v_t_2478, v_vs_2479, v_x_2484}), v_n_2485});
  }
  default: return heff_nomatch(v_x2_2483);
  }
}
V g_heff_2ecompile_2eearly_2ekidsWith_lam11(V self, V *args) {
  V v_x2_2477 = args[0];
  V v_go_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x2_2477)) {
  case TAG_MkArm: {
    V v_t_2478 = heff_field(v_x2_2477, 0);
    V v_vs_2479 = heff_field(v_x2_2477, 1);
    V v_b_2480 = heff_field(v_x2_2477, 2);
    heff_take_n(v_x2_2477, 7ULL, 3);
    V v_m_2481 = heff_tr(heff_call(v_go_240, 2, (V[]){NTAG(TAG_True), v_b_2480}));
    return heff_clo_n(g_heff_2ecompile_2eearly_2ekidsWith_lam12, 1, 3, (V[]){v_m_2481, v_t_2478, v_vs_2479});
  }
  default: return heff_nomatch(v_x2_2477);
  }
}
V g_heff_2ecompile_2eearly_2ekidsWith_lam10(V self, V *args) {
  V v_n_2473 = args[0];
  V v_m_2472 = heff_env(self)[0];
  V v_go_240 = heff_env(self)[1];
  V v_arms_2471 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_x2_2474 = heff_tr(heff_call(v_m_2472, 1, (V[]){v_n_2473}));
  switch (heff_tag_of(v_x2_2474)) {
  case TAG_MkPair: {
    V v_x_2475 = heff_field(v_x2_2474, 0);
    V v_n_2476 = heff_field(v_x2_2474, 1);
    V v_ru_24x2_2474_24MkPair = heff_take_reuse_n(v_x2_2474, 3ULL, 2);
    V v_m_2486 = (g_heff_2ecompile_2eearly_2etraverseS(heff_clo_n(g_heff_2ecompile_2eearly_2ekidsWith_lam11, 1, 1, (V[]){v_go_240}), v_arms_2471));
    V v_x2_2487 = heff_tr(heff_call(v_m_2486, 1, (V[]){v_n_2476}));
    switch (heff_tag_of(v_x2_2487)) {
    case TAG_MkPair: {
      V v_x_2488 = heff_field(v_x2_2487, 0);
      V v_n_2489 = heff_field(v_x2_2487, 1);
      heff_take_n(v_x2_2487, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2474_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_x_2475, v_x_2488}), v_n_2489});
    }
    default: return heff_nomatch(v_x2_2487);
    }
  }
  default: return heff_nomatch(v_x2_2474);
  }
}
V g_heff_2ecompile_2eearly_2ekidsWith_lam13(V self, V *args) {
  V v_n_2491 = args[0];
  V v_x2_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x2_241, v_n_2491});
}
V g_heff_2ecompile_2eearly_2ekidsWith_lam14(V self, V *args) {
  V v_n_2496 = args[0];
  V v_m_2495 = heff_env(self)[0];
  V v_p_2492 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2497 = heff_tr(heff_call(v_m_2495, 1, (V[]){v_n_2496}));
  switch (heff_tag_of(v_x2_2497)) {
  case TAG_MkPair: {
    V v_x_2498 = heff_field(v_x2_2497, 0);
    V v_n_2499 = heff_field(v_x2_2497, 1);
    V v_ru_24x2_2497_24MkPair = heff_take_reuse_n(v_x2_2497, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_2497_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EPrimCall, 2, (V[]){v_p_2492, v_x_2498}), v_n_2499});
  }
  default: return heff_nomatch(v_x2_2497);
  }
}
V g_heff_2ecompile_2eearly_2ekidsWith_lam15(V self, V *args) {
  V v_n_24104 = args[0];
  V v_m_24103 = heff_env(self)[0];
  V v_g_24100 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_24105 = heff_tr(heff_call(v_m_24103, 1, (V[]){v_n_24104}));
  switch (heff_tag_of(v_x2_24105)) {
  case TAG_MkPair: {
    V v_x_24106 = heff_field(v_x2_24105, 0);
    V v_n_24107 = heff_field(v_x2_24105, 1);
    V v_ru_24x2_24105_24MkPair = heff_take_reuse_n(v_x2_24105, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x2_24105_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ECall, 2, (V[]){v_g_24100, v_x_24106}), v_n_24107});
  }
  default: return heff_nomatch(v_x2_24105);
  }
}
V g_heff_2ecompile_2eearly_2ekidsWith_lam16(V self, V *args) {
  V v_n_24109 = args[0];
  V v_x2_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x2_241, v_n_24109});
}
V g_heff_2ecompile_2eearly_2ekidsWith_lam17(V self, V *args) {
  V v_n_24111 = args[0];
  V v_x2_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x2_241, v_n_24111});
}
V g_heff_2ecompile_2eearly_2ekidsWith_lam18(V self, V *args) {
  V v_n_24113 = args[0];
  V v_x2_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x2_241, v_n_24113});
}
V g_heff_2ecompile_2eearly_2ekidsWith_lam19(V self, V *args) {
  V v_n_24115 = args[0];
  V v_x2_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x2_241, v_n_24115});
}
V g_heff_2ecompile_2eearly_2ekidsWith_lam20(V self, V *args) {
  V v_n_24118 = args[0];
  V v_x2_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x2_241, v_n_24118});
}
V g_heff_2ecompile_2eearly_2ekidsWith_lam21(V self, V *args) {
  V v_n_24120 = args[0];
  V v_x2_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x2_241, v_n_24120});
}
V g_heff_2ecompile_2eearly_2ekidsWith_lam22(V self, V *args) {
  V v_n_24121 = args[0];
  V v_x2_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x2_241, v_n_24121});
}
V g_heff_2ecompile_2eearly_2ekidsWith_lam23(V self, V *args) {
  V v_n_24124 = args[0];
  V v_x2_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_x2_241, v_n_24124});
}
V g_heff_2ecompile_2eearly_2ewalk_lam0(V self, V *args);
Clo g_heff_2ecompile_2eearly_2ewalk_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eearly_2ewalk_entry, 2, 0};

V g_heff_2ecompile_2eearly_2ewalk(V v_at_240, V v_e_241) {
top: ;
  V v_t_2436;
  if ((heff_dup(v_at_240) == NTAG(TAG_True))) {
    switch (heff_tag_of(v_e_241)) {
    case TAG_EVar: {
      v_t_2436 = NTAG(TAG_False);
      break;
    }
    case TAG_EGlobal: {
      v_t_2436 = NTAG(TAG_False);
      break;
    }
    case TAG_ELam: {
      v_t_2436 = NTAG(TAG_False);
      break;
    }
    case TAG_EApp: {
      v_t_2436 = NTAG(TAG_False);
      break;
    }
    case TAG_ELet: {
      v_t_2436 = NTAG(TAG_True);
      break;
    }
    case TAG_ERecord: {
      v_t_2436 = NTAG(TAG_False);
      break;
    }
    case TAG_EProj: {
      v_t_2436 = NTAG(TAG_False);
      break;
    }
    case TAG_ETag: {
      v_t_2436 = NTAG(TAG_False);
      break;
    }
    case TAG_EMatch: {
      v_t_2436 = NTAG(TAG_True);
      break;
    }
    case TAG_EPrim: {
      v_t_2436 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrimCall: {
      v_t_2436 = NTAG(TAG_False);
      break;
    }
    case TAG_ECall: {
      v_t_2436 = NTAG(TAG_False);
      break;
    }
    case TAG_EInt: {
      v_t_2436 = NTAG(TAG_False);
      break;
    }
    case TAG_EFloat: {
      v_t_2436 = NTAG(TAG_False);
      break;
    }
    case TAG_EStr: {
      v_t_2436 = NTAG(TAG_False);
      break;
    }
    case TAG_EBytes: {
      v_t_2436 = NTAG(TAG_False);
      break;
    }
    case TAG_EFixed: {
      v_t_2436 = NTAG(TAG_False);
      break;
    }
    case TAG_EFloat32: {
      v_t_2436 = NTAG(TAG_False);
      break;
    }
    case TAG_EAbandon: {
      v_t_2436 = NTAG(TAG_False);
      break;
    }
    case TAG_EFix: {
      v_t_2436 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_e_241);
    }
  } else {
    v_t_2436 = NTAG(TAG_False);
  }
  if ((heff_dup(v_t_2436) == NTAG(TAG_True))) {
    heff_drop(v_t_2436);
    HeffT2 v_t_2437 = (g_heff_2ecompile_2eearly_2espineOf_24cpr(v_e_241));
    V v_m_2448;
    {
      V v_field_2438 = v_t_2437.f[0];
      V v_field_2439 = v_t_2437.f[1];
      V v_bs_2440 = v_field_2438;
      V v_last_2441 = v_field_2439;
      HeffT2 v_t_2442 = (g_heff_2ecompile_2eearly_2ecutGo_24cpr(NTAG(TAG_Nil), v_bs_2440));
      {
        V v_field_2443 = v_t_2442.f[0];
        V v_field_2444 = v_t_2442.f[1];
        V v_before_2445 = v_field_2443;
        switch (heff_tag_of(v_field_2444)) {
        case TAG_Nil: {
          v_m_2448 = (g_heff_2ecompile_2eearly_2eatEnd(v_before_2445, v_last_2441));
          break;
        }
        case TAG_Cons: {
          V v_call_2446 = heff_field(v_field_2444, 0);
          V v_after_2447 = heff_field(v_field_2444, 1);
          heff_take_n(v_field_2444, 3ULL, 2);
          v_m_2448 = (g_heff_2ecompile_2eearly_2eatBinding(v_before_2445, v_call_2446, v_after_2447, v_last_2441));
          break;
        }
        default: heff_nomatch(v_field_2444);
        }
      }
    }
    V v_f_2449 = heff_tr(heff_call(((V)&g_heff_2ecompile_2eearly_2ewalk_clo), 1, (V[]){NTAG(TAG_False)}));
    return heff_clo_n(g_heff_2ecompile_2eearly_2ewalk_lam0, 1, 2, (V[]){v_m_2448, v_f_2449});
  } else {
    heff_drop(v_t_2436);
    HEFF_LAST return g_heff_2ecompile_2eearly_2ekidsWith(((V)&g_heff_2ecompile_2eearly_2ewalk_clo), v_e_241);
  }
}
V g_heff_2ecompile_2eearly_2ewalk_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2eearly_2ewalk(a0, a[1]); heff_drop(a0); return r;
}
V g_heff_2ecompile_2eearly_2ewalk_lam0(V self, V *args) {
  V v_n_2450 = args[0];
  V v_m_2448 = heff_env(self)[0];
  V v_f_2449 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_2451 = heff_tr(heff_call(v_m_2448, 1, (V[]){v_n_2450}));
  switch (heff_tag_of(v_x2_2451)) {
  case TAG_MkPair: {
    V v_x_2452 = heff_field(v_x2_2451, 0);
    V v_n_2453 = heff_field(v_x2_2451, 1);
    heff_take_n(v_x2_2451, 3ULL, 2);
    V f_ = v_f_2449;
    heff_room[0] = v_x_2452;
    heff_room[1] = v_n_2453;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_x2_2451);
  }
}
V g_heff_2ecompile_2eearly_2eearlyDef_lam0(V self, V *args);
V g_heff_2ecompile_2eearly_2eearlyDef_lam1(V self, V *args);
Clo g_heff_2ecompile_2eearly_2eearlyDef_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eearly_2eearlyDef_entry, 1, 0};

V g_heff_2ecompile_2eearly_2eearlyDef(V v_d_240) {
top: ;
  V v_t_241 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(heff_rfield(v_d_240, 2)), NTAG(TAG_Nil)});
  V v_t_242 = (g_heff_2ecompile_2eearly_2enumbersW(v_t_241));
  if ((heff_dup(v_t_242) == NTAG(TAG_True))) {
    heff_drop(v_t_242);
    V v_m_243 = ({ V b_0 = NTAG(TAG_True); V a_1 = heff_dup(heff_rfield(v_d_240, 2)); V r_ = (g_heff_2ecompile_2eearly_2ewalk(b_0, a_1)); heff_drop(b_0); r_; });
    return heff_clo_n(g_heff_2ecompile_2eearly_2eearlyDef_lam0, 1, 2, (V[]){v_m_243, v_d_240});
  } else {
    heff_drop(v_t_242);
    return heff_clo_n(g_heff_2ecompile_2eearly_2eearlyDef_lam1, 1, 1, (V[]){v_d_240});
  }
}
V g_heff_2ecompile_2eearly_2eearlyDef_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eearly_2eearlyDef(a[0]);
}
V g_heff_2ecompile_2eearly_2eearlyDef_lam0(V self, V *args) {
  V v_n_244 = args[0];
  V v_m_243 = heff_env(self)[0];
  V v_d_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_245 = heff_tr(heff_call(v_m_243, 1, (V[]){v_n_244}));
  switch (heff_tag_of(v_x2_245)) {
  case TAG_MkPair: {
    V v_x_246 = heff_field(v_x2_245, 0);
    V v_n_247 = heff_field(v_x2_245, 1);
    V v_ru_24x2_245_24MkPair = heff_take_reuse_n(v_x2_245, 3ULL, 2);
    V v_t_248 = ({ V rv_2 = v_x_246; V rr_ = heff_rec_reuse_nf(v_d_240, 3ULL, 3, shape_key__name__body, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    return heff_tag_at_n(v_ru_24x2_245_24MkPair, TAG_MkPair, 2, (V[]){v_t_248, v_n_247});
  }
  default: return heff_nomatch(v_x2_245);
  }
}
V g_heff_2ecompile_2eearly_2eearlyDef_lam1(V self, V *args) {
  V v_n_249 = args[0];
  V v_d_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_tag_n(TAG_MkPair, 2, (V[]){v_d_240, v_n_249});
}
V g_heff_2ecompile_2eearly_2etraverseS_24s1904693382x1197638938_lam0(V self, V *args); static Clo g_heff_2ecompile_2eearly_2etraverseS_24s1904693382x1197638938_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eearly_2etraverseS_24s1904693382x1197638938_lam0, 1, 0};
V g_heff_2ecompile_2eearly_2etraverseS_24s1904693382x1197638938_lam1(V self, V *args);
Clo g_heff_2ecompile_2eearly_2etraverseS_24s1904693382x1197638938_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2eearly_2etraverseS_24s1904693382x1197638938_entry, 1, 0};

V g_heff_2ecompile_2eearly_2etraverseS_24s1904693382x1197638938(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return ((V)&g_heff_2ecompile_2eearly_2etraverseS_24s1904693382x1197638938_lam0_clo);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    heff_take_n(v_x2_240, 3ULL, 2);
    V v_m_244 = (g_heff_2ecompile_2eearly_2eearlyDef(v_x_242));
    return heff_clo_n(g_heff_2ecompile_2eearly_2etraverseS_24s1904693382x1197638938_lam1, 1, 2, (V[]){v_m_244, v_xs_243});
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2ecompile_2eearly_2etraverseS_24s1904693382x1197638938_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2eearly_2etraverseS_24s1904693382x1197638938(a[0]);
}
V g_heff_2ecompile_2eearly_2etraverseS_24s1904693382x1197638938_lam0(V self, V *args) {
  V v_n_241 = args[0];
  return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_n_241});
}
V g_heff_2ecompile_2eearly_2etraverseS_24s1904693382x1197638938_lam1(V self, V *args) {
  V v_n_245 = args[0];
  V v_m_244 = heff_env(self)[0];
  V v_xs_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x2_246 = heff_tr(heff_call(v_m_244, 1, (V[]){v_n_245}));
  switch (heff_tag_of(v_x2_246)) {
  case TAG_MkPair: {
    V v_x_247 = heff_field(v_x2_246, 0);
    V v_n_248 = heff_field(v_x2_246, 1);
    V v_ru_24x2_246_24MkPair = heff_take_reuse_n(v_x2_246, 3ULL, 2);
    V v_m_249 = (g_heff_2ecompile_2eearly_2etraverseS_24s1904693382x1197638938(v_xs_243));
    V v_x2_2410 = heff_tr(heff_call(v_m_249, 1, (V[]){v_n_248}));
    switch (heff_tag_of(v_x2_2410)) {
    case TAG_MkPair: {
      V v_x_2411 = heff_field(v_x2_2410, 0);
      V v_n_2412 = heff_field(v_x2_2410, 1);
      heff_take_n(v_x2_2410, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_246_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_x_247, v_x_2411}), v_n_2412});
    }
    default: return heff_nomatch(v_x2_2410);
    }
  }
  default: return heff_nomatch(v_x2_246);
  }
}