// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Collected 38917
#define TAG_Exit 20279
#define TAG_Exited 20560
#define TAG_FailedWith 25914
#define TAG_JArray 50516
#define TAG_JBool 39030
#define TAG_JFloat 30719
#define TAG_JInt 58696
#define TAG_JNull 9039
#define TAG_JObject 38239
#define TAG_JString 41091
#define TAG_Measured 52135
#define TAG_NoInput 41055
#define TAG_NotRun 12703
#define TAG_Run 29975
#define TAG_Signalled 34337
#define TAG_SkippedWith 54656
#define TAG_TimedOut 6056
#define TAG_Times 15230
#define TAG_Value 50841
#define TAG_Write 36323
#define TAG_WriteErr 37283
#define LBL_args 9498020
#define LBL_command 1182252425
#define LBL_count 296209705
#define LBL_dir 308999
#define LBL_done 9584713
#define LBL_ended 298010324
#define LBL_env 310119
#define LBL_errors 652506774
#define LBL_failed 665164648
#define LBL_group 299987609
#define LBL_implicit 319715269
#define LBL_input 301716452
#define LBL_json 9767343
#define LBL_keep 9783372
#define LBL_module 878357911
#define LBL_out 319944
#define LBL_output 941629484
#define LBL_own 320000
#define LBL_package 1572278921
#define LBL_packages 1496006433
#define LBL_paths 307797256
#define LBL_pattern 1588251091
#define LBL_ran 322201
#define LBL_renames 1324191545
#define LBL_root 10001833
#define LBL_source 1050636102
#define LBL_sources 357464573
#define LBL_style 311138763
#define LBL_time 10055572
#define LBL_timeout 1065429926
static uint32_t shape_command__args__dir__env__input__output__errors__timeout__keep__group[] = {LBL_command, LBL_args, LBL_dir, LBL_env, LBL_input, LBL_output, LBL_errors, LBL_timeout, LBL_keep, LBL_group};
static uint32_t shape_pattern__time__count__json[] = {LBL_pattern, LBL_time, LBL_count, LBL_json};
static uint32_t shape_ran__failed[] = {LBL_ran, LBL_failed};
static uint32_t shape_sources__errors__paths__package__packages[] = {LBL_sources, LBL_errors, LBL_paths, LBL_package, LBL_packages};
V g_co_2eop_24s22628809x1035315751(V, V, V);
V g_co_2eop_24s22628809x1035315751_entry(V self, V *a);
extern Clo g_co_2eop_24s22628809x1035315751_clo;
V g_co_2eop_24s495635622x733177935(V, V, V);
V g_co_2eop_24s495635622x733177935_entry(V self, V *a);
extern Clo g_co_2eop_24s495635622x733177935_clo;
HeffT2 g_heff_2ebuild_2ebenchmarks_2ebenchAdded_24cpr(V, V, V);
V g_heff_2ebuild_2ebenchmarks_2ebenchDir(V, V);
V g_heff_2ebuild_2ebenchmarks_2ebenchDir_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebenchmarks_2ebenchDir_clo;
V g_heff_2ebuild_2ebenchmarks_2ebenchEach_24s2122599649x1048694221(V, V, V, V, V, V, V);
V g_heff_2ebuild_2ebenchmarks_2ebenchEach_24s2122599649x1048694221_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebenchmarks_2ebenchEach_24s2122599649x1048694221_clo;
V g_heff_2ebuild_2ebenchmarks_2ebenchFile_24s1130874047x1407191497(V, V, V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ebenchmarks_2ebenchFile_24s1130874047x1407191497_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebenchmarks_2ebenchFile_24s1130874047x1407191497_clo;
V g_heff_2ebuild_2ebenchmarks_2ebenchMainName_get(void);
V g_heff_2ebuild_2ebenchmarks_2ebenchOptions_24s1318533244x2074895986(V, V, V, V);
V g_heff_2ebuild_2ebenchmarks_2ebenchOptions_24s1318533244x2074895986_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebenchmarks_2ebenchOptions_24s1318533244x2074895986_clo;
HeffT2 g_heff_2ebuild_2ebenchmarks_2ebenchQualifier_24cpr(V);
V g_heff_2ebuild_2ebenchmarks_2ebenchSummary_24s155169312x1036209580(V, V, V, V);
V g_heff_2ebuild_2ebenchmarks_2ebenchSummary_24s155169312x1036209580_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebenchmarks_2ebenchSummary_24s155169312x1036209580_clo;
V g_heff_2ebuild_2ebenchmarks_2ebenchText(V, V);
V g_heff_2ebuild_2ebenchmarks_2ebenchText_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebenchmarks_2ebenchText_clo;
HeffT2 g_heff_2ebuild_2ebenchmarks_2ebenchTime_24cpr(V);
V g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s1238445759x439245818(V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s1238445759x439245818_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s1238445759x439245818_clo;
V g_heff_2ebuild_2ebenchmarks_2ecapital(V);
V g_heff_2ebuild_2ebenchmarks_2ecapital_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebenchmarks_2ecapital_clo;
V g_heff_2ebuild_2ebenchmarks_2ecountGiven_24s1419575577x1110690646(V);
V g_heff_2ebuild_2ebenchmarks_2ecountGiven_24s1419575577x1110690646_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebenchmarks_2ecountGiven_24s1419575577x1110690646_clo;
V g_heff_2ebuild_2ebenchmarks_2edecimalParts(V, V);
V g_heff_2ebuild_2ebenchmarks_2edecimalParts_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebenchmarks_2edecimalParts_clo;
HeffT2 g_heff_2ebuild_2ebenchmarks_2edurationOf_24cpr(V, V);
V g_heff_2ebuild_2ebenchmarks_2eendedWhy(V);
V g_heff_2ebuild_2ebenchmarks_2eendedWhy_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebenchmarks_2eendedWhy_clo;
HeffT2 g_heff_2ebuild_2ebenchmarks_2elistedOf_24cpr(V);
V g_heff_2ebuild_2ebenchmarks_2enotBenched_24s1500087693x194837604(V, V, V);
V g_heff_2ebuild_2ebenchmarks_2enotBenched_24s1500087693x194837604_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebenchmarks_2enotBenched_24s1500087693x194837604_clo;
V g_heff_2ebuild_2ebenchmarks_2eoutcomeFields(V);
V g_heff_2ebuild_2ebenchmarks_2eoutcomeFields_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebenchmarks_2eoutcomeFields_clo;
V g_heff_2ebuild_2ebenchmarks_2eoutcomeJson(V, V, V);
V g_heff_2ebuild_2ebenchmarks_2eoutcomeJson_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebenchmarks_2eoutcomeJson_clo;
V g_heff_2ebuild_2ebenchmarks_2eoutcomeOfLine(V);
V g_heff_2ebuild_2ebenchmarks_2eoutcomeOfLine_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebenchmarks_2eoutcomeOfLine_clo;
V g_heff_2ebuild_2ebenchmarks_2eperOp(V, V);
V g_heff_2ebuild_2ebenchmarks_2eperOp_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebenchmarks_2eperOp_clo;
V g_heff_2ebuild_2ebenchmarks_2eplacesOf(V, V, V);
V g_heff_2ebuild_2ebenchmarks_2eplacesOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebenchmarks_2eplacesOf_clo;
V g_heff_2ebuild_2ebenchmarks_2erunBuilt_24s1240224601x352191580(V, V, V);
V g_heff_2ebuild_2ebenchmarks_2erunBuilt_24s1240224601x352191580_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebenchmarks_2erunBuilt_24s1240224601x352191580_clo;
V g_heff_2ebuild_2ebenchmarks_2erunEach_24s1029322272x552871994(V, V, V, V, V, V);
V g_heff_2ebuild_2ebenchmarks_2erunEach_24s1029322272x552871994_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebenchmarks_2erunEach_24s1029322272x552871994_clo;
V g_heff_2ebuild_2ebenchmarks_2erunListed_24s1367290375x1394144908(V, V, V, V, V, V);
V g_heff_2ebuild_2ebenchmarks_2erunListed_24s1367290375x1394144908_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebenchmarks_2erunListed_24s1367290375x1394144908_clo;
V g_heff_2ebuild_2ebenchmarks_2espaced(V);
V g_heff_2ebuild_2ebenchmarks_2espaced_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebenchmarks_2espaced_clo;
V g_heff_2ebuild_2ebenchmarks_2espaces(V);
V g_heff_2ebuild_2ebenchmarks_2espaces_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebenchmarks_2espaces_clo;
V g_heff_2ebuild_2ebenchmarks_2espaces_24acc(V, V);
V g_heff_2ebuild_2ebenchmarks_2espaces_24acc_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebenchmarks_2espaces_24acc_clo;
V g_heff_2ebuild_2ebenchmarks_2etenTo(V);
V g_heff_2ebuild_2ebenchmarks_2etenTo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebenchmarks_2etenTo_clo;
V g_heff_2ebuild_2ebenchmarks_2etimeGiven_24s1230712360x789314041(V);
V g_heff_2ebuild_2ebenchmarks_2etimeGiven_24s1230712360x789314041_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebenchmarks_2etimeGiven_24s1230712360x789314041_clo;
V g_heff_2ebuild_2ebenchmarks_2eunits_get(void);
V g_heff_2ebuild_2ebenchmarks_2ezeroPadded(V, V);
V g_heff_2ebuild_2ebenchmarks_2ezeroPadded_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebenchmarks_2ezeroPadded_clo;
V g_heff_2ebuild_2ecommands_2ediagCount_24s920027481x727902174(V);
V g_heff_2ebuild_2ecommands_2ediagCount_24s920027481x727902174_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ediagCount_24s920027481x727902174_clo;
HeffT2 g_heff_2ebuild_2ecommands_2efirstErrorOf_24cpr(V);
V g_heff_2ebuild_2ecommands_2eload_24s81450283x65507788(V);
V g_heff_2ebuild_2ecommands_2eload_24s81450283x65507788_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eload_24s81450283x65507788_clo;
V g_heff_2ebuild_2ecommands_2eprintErrs_24s2072048709x1630503544(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eprintErrs_24s2072048709x1630503544_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprintErrs_24s2072048709x1630503544_clo;
V g_heff_2ebuild_2edriver_2eisBenchOwn(V, V);
V g_heff_2ebuild_2edriver_2eisBenchOwn_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eisBenchOwn_clo;
HeffT2 g_heff_2ebuild_2edriver_2elastChecked_24cpr(V);
V g_heff_2ebuild_2edriver_2erootsAmong(V, V);
V g_heff_2ebuild_2edriver_2erootsAmong_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2erootsAmong_clo;
V g_heff_2ebuild_2esession_2ecachedAcc_24s1931332253x1949976425(V);
V g_heff_2ebuild_2esession_2ecachedAcc_24s1931332253x1949976425_entry(V self, V *a);
extern Clo g_heff_2ebuild_2esession_2ecachedAcc_24s1931332253x1949976425_clo;
V g_heff_2esyntax_2eimport_2eimportsOf(V, V);
V g_heff_2esyntax_2eimport_2eimportsOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eimport_2eimportsOf_clo;
HeffT4 g_heff_2esyntax_2eimport_2erenamed_24cpr(V, V);
HeffT2 g_json_2eat_24cpr(V, V);
HeffT2 g_json_2esteps_24cpr(V, V);
V g_json_2estringify(V);
V g_json_2estringify_entry(V self, V *a);
extern Clo g_json_2estringify_clo;
V g_list_2eall_24s443219008x474491297(V, V, V, V);
V g_list_2eall_24s443219008x474491297_entry(V self, V *a);
extern Clo g_list_2eall_24s443219008x474491297_clo;
V g_list_2eany_24s469495312x865582084(V);
V g_list_2eany_24s469495312x865582084_entry(V self, V *a);
extern Clo g_list_2eany_24s469495312x865582084_clo;
V g_list_2efilter(V, V);
V g_list_2efilter_entry(V self, V *a);
extern Clo g_list_2efilter_clo;
V g_list_2efind_24s1816408632x1283768171(V, V);
V g_list_2efind_24s1816408632x1283768171_entry(V self, V *a);
extern Clo g_list_2efind_24s1816408632x1283768171_clo;
V g_list_2efoldl_24f470245410x241064089(V, V, V);
V g_list_2efoldl_24f470245410x241064089_entry(V self, V *a);
extern Clo g_list_2efoldl_24f470245410x241064089_clo;
V g_list_2efoldl_24s1313398329x1387572461(V, V, V, V, V, V, V);
V g_list_2efoldl_24s1313398329x1387572461_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1313398329x1387572461_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s778605472x971322441(V, V, V, V, V);
V g_list_2efoldl_24s778605472x971322441_entry(V self, V *a);
extern Clo g_list_2efoldl_24s778605472x971322441_clo;
V g_list_2emap_24s1007499915x73800978(V);
V g_list_2emap_24s1007499915x73800978_entry(V self, V *a);
extern Clo g_list_2emap_24s1007499915x73800978_clo;
V g_list_2emap_24s1750766838x1556198350(V, V, V);
V g_list_2emap_24s1750766838x1556198350_entry(V self, V *a);
extern Clo g_list_2emap_24s1750766838x1556198350_clo;
V g_list_2emap_24s723912745x1713553694(V);
V g_list_2emap_24s723912745x1713553694_entry(V self, V *a);
extern Clo g_list_2emap_24s723912745x1713553694_clo;
V g_list_2emap_24s849938259x51049885(V);
V g_list_2emap_24s849938259x51049885_entry(V self, V *a);
extern Clo g_list_2emap_24s849938259x51049885_clo;
V g_list_2erange(V, V);
V g_list_2erange_entry(V self, V *a);
extern Clo g_list_2erange_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2ejoinWith_2eafter_240_24f591888720x1996727869(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_24f591888720x1996727869_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_24f591888720x1996727869_clo;
V g_prelude_2eparseInt(V);
V g_prelude_2eparseInt_entry(V self, V *a);
extern Clo g_prelude_2eparseInt_clo;
HeffT2 g_prelude_2eparseInt_24cpr(V);
V g_prelude_2esplitFrom(V, V, V, V, V);
V g_prelude_2esplitFrom_entry(V self, V *a);
extern Clo g_prelude_2esplitFrom_clo;
HeffT2 g_regex_2eallRead_24cpr(V);
V g_regex_2esplitGo(V, V, V, V, V, V);
V g_regex_2esplitGo_entry(V self, V *a);
extern Clo g_regex_2esplitGo_clo;
V g_std_2epath_2ecurrent_get(void);
V g_std_2epath_2ejoin(V, V);
V g_std_2epath_2ejoin_entry(V self, V *a);
extern Clo g_std_2epath_2ejoin_clo;
V g_std_2epath_2enative_get(void);
V g_std_2epath_2eparse(V, V);
V g_std_2epath_2eparse_entry(V self, V *a);
extern Clo g_std_2epath_2eparse_clo;
HeffT3 g_std_2epath_2eparse_24cpr(V, V);
V g_std_2epath_2erender(V, V);
V g_std_2epath_2erender_entry(V self, V *a);
extern Clo g_std_2epath_2erender_clo;
V g_std_2epath_2esameSegments(V, V);
V g_std_2epath_2esameSegments_entry(V self, V *a);
extern Clo g_std_2epath_2esameSegments_clo;
Clo g_heff_2ebuild_2ebenchmarks_2etenTo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebenchmarks_2etenTo_entry, 1, 0};

V g_heff_2ebuild_2ebenchmarks_2etenTo(V v_k_240) {
top: ;
  if (heff_intLe_c_lent(v_k_240, MK_INT(0LL), 2)) {
    heff_drop(v_k_240);
    return MK_INT(1LL);
  } else {
    V v_t_242 = (g_heff_2ebuild_2ebenchmarks_2etenTo(heff_intSub(v_k_240, MK_INT(1LL))));
    return heff_intMul(MK_INT(10LL), v_t_242);
  }
}
V g_heff_2ebuild_2ebenchmarks_2etenTo_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ebenchmarks_2etenTo(a[0]);
}
V g_heff_2ebuild_2ebenchmarks_2edecimalParts_lam0(V self, V *args);
V g_heff_2ebuild_2ebenchmarks_2edecimalParts_lam1(V self, V *args); static Clo g_heff_2ebuild_2ebenchmarks_2edecimalParts_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebenchmarks_2edecimalParts_lam1, 2, 0};
V g_heff_2ebuild_2ebenchmarks_2edecimalParts_lam2(V self, V *args); static Clo g_heff_2ebuild_2ebenchmarks_2edecimalParts_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebenchmarks_2edecimalParts_lam2, 2, 0};
V g_heff_2ebuild_2ebenchmarks_2edecimalParts_lam3(V self, V *args);
V g_heff_2ebuild_2ebenchmarks_2edecimalParts_lam4(V self, V *args); static Clo g_heff_2ebuild_2ebenchmarks_2edecimalParts_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebenchmarks_2edecimalParts_lam4, 2, 0};
V g_heff_2ebuild_2ebenchmarks_2edecimalParts_lam5(V self, V *args); static Clo g_heff_2ebuild_2ebenchmarks_2edecimalParts_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebenchmarks_2edecimalParts_lam5, 2, 0};
Clo g_heff_2ebuild_2ebenchmarks_2edecimalParts_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebenchmarks_2edecimalParts_entry, 2, 0};

V g_heff_2ebuild_2ebenchmarks_2edecimalParts(V v_unit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_unit_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_w_242 = heff_field(v_x2_241, 0);
    V v_x22_243 = heff_field(v_x2_241, 1);
    switch (heff_tag_of(v_x22_243)) {
    case TAG_Nil: {
      V v_t_2423;
      if ((((int64_t)0ULL) < heff_unbox_word(heff_strLength_lent(v_w_242, 0)))) {
        int64_t v_t_245 = (heff_unbox_word(heff_strLength_lent(v_w_242, 0)) - ((int64_t)1ULL));
        V v_t_246 = (g_list_2erange(MK_INT(0LL), heff_box_word(v_t_245)));
        V v_t_247 = ({ V a_0 = MK_INT(48LL); V a_1 = v_w_242; V a_2 = MK_INT(57LL); V a_3 = v_t_246; V r_ = (g_list_2eall_24s443219008x474491297(a_0, a_1, a_2, a_3)); heff_drop(v_t_246); r_; });
        if ((heff_dup(v_t_247) == NTAG(TAG_True))) {
          heff_drop(v_t_247);
          HeffT2 v_t_248 = (g_prelude_2eparseInt_24cpr(v_w_242));
          {
            V v_field_2410 = v_t_248.f[1];
            V v_tag_249 = heff_box_i64(((int64_t)v_t_248.f[0]));
            v_t_2423 = heff_clo_n(g_heff_2ebuild_2ebenchmarks_2edecimalParts_lam0, 2, 3, (V[]){v_tag_249, v_field_2410, v_unit_240});
          }
        } else {
          heff_drop(v_unit_240);
          heff_drop(v_t_247);
          v_t_2423 = ((V)&g_heff_2ebuild_2ebenchmarks_2edecimalParts_lam1_clo);
        }
      } else {
        heff_drop(v_unit_240);
        v_t_2423 = ((V)&g_heff_2ebuild_2ebenchmarks_2edecimalParts_lam2_clo);
      }
      return heff_tail(v_t_2423, 2, (V[]){heff_tag_n(TAG_Just, 1, (V[]){MK_INT(0LL)}), MK_INT(0LL)});
    }
    case TAG_Cons: {
      V v_f_2424 = heff_field(v_x22_243, 0);
      V v_x222_2425 = heff_field(v_x22_243, 1);
      switch (heff_tag_of(v_x222_2425)) {
      case TAG_Nil: {
        V v_t_2445;
        if ((((int64_t)0ULL) < heff_unbox_word(heff_strLength_lent(v_w_242, 0)))) {
          int64_t v_t_2427 = (heff_unbox_word(heff_strLength_lent(v_w_242, 0)) - ((int64_t)1ULL));
          V v_t_2428 = (g_list_2erange(MK_INT(0LL), heff_box_word(v_t_2427)));
          V v_t_2429 = ({ V a_0 = MK_INT(48LL); V a_1 = v_w_242; V a_2 = MK_INT(57LL); V a_3 = v_t_2428; V r_ = (g_list_2eall_24s443219008x474491297(a_0, a_1, a_2, a_3)); heff_drop(v_t_2428); r_; });
          if ((heff_dup(v_t_2429) == NTAG(TAG_True))) {
            heff_drop(v_t_2429);
            HeffT2 v_t_2430 = (g_prelude_2eparseInt_24cpr(v_w_242));
            {
              V v_field_2432 = v_t_2430.f[1];
              V v_tag_2431 = heff_box_i64(((int64_t)v_t_2430.f[0]));
              v_t_2445 = heff_clo_n(g_heff_2ebuild_2ebenchmarks_2edecimalParts_lam3, 2, 3, (V[]){v_tag_2431, v_field_2432, v_unit_240});
            }
          } else {
            heff_drop(v_unit_240);
            heff_drop(v_t_2429);
            v_t_2445 = ((V)&g_heff_2ebuild_2ebenchmarks_2edecimalParts_lam4_clo);
          }
        } else {
          heff_drop(v_unit_240);
          v_t_2445 = ((V)&g_heff_2ebuild_2ebenchmarks_2edecimalParts_lam5_clo);
        }
        V v_t_2450;
        if ((((int64_t)0ULL) < heff_unbox_word(heff_strLength_lent(v_f_2424, 0)))) {
          int64_t v_t_2447 = (heff_unbox_word(heff_strLength_lent(v_f_2424, 0)) - ((int64_t)1ULL));
          V v_t_2448 = (g_list_2erange(MK_INT(0LL), heff_box_word(v_t_2447)));
          V v_t_2449 = ({ V a_0 = MK_INT(48LL); V a_1 = v_f_2424; V a_2 = MK_INT(57LL); V a_3 = v_t_2448; V r_ = (g_list_2eall_24s443219008x474491297(a_0, a_1, a_2, a_3)); heff_drop(v_t_2448); r_; });
          if ((heff_dup(v_t_2449) == NTAG(TAG_True))) {
            heff_drop(v_t_2449);
            v_t_2450 = (g_prelude_2eparseInt(v_f_2424));
          } else {
            heff_drop(v_t_2449);
            v_t_2450 = NTAG(TAG_Nothing);
          }
        } else {
          v_t_2450 = NTAG(TAG_Nothing);
        }
        return heff_tail(v_t_2445, 2, (V[]){v_t_2450, heff_strLength_lent(v_f_2424, 0)});
      }
      case TAG_Cons: {
        heff_drop(v_unit_240);
        return NTAG(TAG_Nothing);
      }
      default: return heff_nomatch(v_x222_2425);
      }
    }
    default: return heff_nomatch(v_x22_243);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2ebenchmarks_2edecimalParts_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2ebenchmarks_2edecimalParts(a[0], a1); heff_drop(a1); return r;
}
V g_heff_2ebuild_2ebenchmarks_2edecimalParts_lam0(V self, V *args) {
  V v_x3_2411 = args[0];
  V v_places_2412 = args[1];
  V v_tag_249 = heff_env(self)[0];
  V v_field_2410 = heff_env(self)[1];
  V v_unit_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  if ((heff_unbox_i64(v_tag_249) == ((int64_t)0ULL))) {
    V v_w_2414 = v_field_2410;
    switch (heff_tag_of(v_x3_2411)) {
    case TAG_Nothing: {
      heff_drop(v_places_2412);
      heff_drop(v_unit_240);
      heff_drop(v_w_2414);
      return NTAG(TAG_Nothing);
    }
    case TAG_Just: {
      V v_f_2415 = heff_field(v_x3_2411, 0);
      V v_ru_24x3_2411_24Just = heff_take_reuse_n(v_x3_2411, 1ULL, 1);
      V v_t_2416 = (g_heff_2ebuild_2ebenchmarks_2etenTo(v_places_2412));
      V v_t_2417 = heff_intDiv(heff_intMul(v_f_2415, heff_dup(v_unit_240)), v_t_2416);
      V v_t_2418 = heff_intAdd(heff_intMul(v_w_2414, v_unit_240), v_t_2417);
      return heff_tag_at_n(v_ru_24x3_2411_24Just, TAG_Just, 1, (V[]){v_t_2418});
    }
    default: return heff_nomatch(v_x3_2411);
    }
  } else {
    heff_drop(v_x3_2411);
    heff_drop(v_places_2412);
    heff_drop(v_field_2410);
    heff_drop(v_unit_240);
    return NTAG(TAG_Nothing);
  }
}
V g_heff_2ebuild_2ebenchmarks_2edecimalParts_lam1(V self, V *args) {
  V v_x3_2419 = args[0];
  V v_places_2420 = args[1];
  heff_drop(v_x3_2419);
  heff_drop(v_places_2420);
  return NTAG(TAG_Nothing);
}
V g_heff_2ebuild_2ebenchmarks_2edecimalParts_lam2(V self, V *args) {
  V v_x3_2421 = args[0];
  V v_places_2422 = args[1];
  heff_drop(v_x3_2421);
  heff_drop(v_places_2422);
  return NTAG(TAG_Nothing);
}
V g_heff_2ebuild_2ebenchmarks_2edecimalParts_lam3(V self, V *args) {
  V v_x3_2433 = args[0];
  V v_places_2434 = args[1];
  V v_tag_2431 = heff_env(self)[0];
  V v_field_2432 = heff_env(self)[1];
  V v_unit_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  if ((heff_unbox_i64(v_tag_2431) == ((int64_t)0ULL))) {
    V v_w_2436 = v_field_2432;
    switch (heff_tag_of(v_x3_2433)) {
    case TAG_Nothing: {
      heff_drop(v_places_2434);
      heff_drop(v_unit_240);
      heff_drop(v_w_2436);
      return NTAG(TAG_Nothing);
    }
    case TAG_Just: {
      V v_f_2437 = heff_field(v_x3_2433, 0);
      V v_ru_24x3_2433_24Just = heff_take_reuse_n(v_x3_2433, 1ULL, 1);
      V v_t_2438 = (g_heff_2ebuild_2ebenchmarks_2etenTo(v_places_2434));
      V v_t_2439 = heff_intDiv(heff_intMul(v_f_2437, heff_dup(v_unit_240)), v_t_2438);
      V v_t_2440 = heff_intAdd(heff_intMul(v_w_2436, v_unit_240), v_t_2439);
      return heff_tag_at_n(v_ru_24x3_2433_24Just, TAG_Just, 1, (V[]){v_t_2440});
    }
    default: return heff_nomatch(v_x3_2433);
    }
  } else {
    heff_drop(v_x3_2433);
    heff_drop(v_places_2434);
    heff_drop(v_field_2432);
    heff_drop(v_unit_240);
    return NTAG(TAG_Nothing);
  }
}
V g_heff_2ebuild_2ebenchmarks_2edecimalParts_lam4(V self, V *args) {
  V v_x3_2441 = args[0];
  V v_places_2442 = args[1];
  heff_drop(v_x3_2441);
  heff_drop(v_places_2442);
  return NTAG(TAG_Nothing);
}
V g_heff_2ebuild_2ebenchmarks_2edecimalParts_lam5(V self, V *args) {
  V v_x3_2443 = args[0];
  V v_places_2444 = args[1];
  heff_drop(v_x3_2443);
  heff_drop(v_places_2444);
  return NTAG(TAG_Nothing);
}
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2ebenchTime_24cpr_str0, 1, "x");

HeffT2 g_heff_2ebuild_2ebenchmarks_2ebenchTime_24cpr(V v_s_240) {
top: ;
  int64_t v_t_241 = (heff_unbox_word(heff_strLength_lent(v_s_240, 0)) - ((int64_t)1ULL));
  V v_t_242 = heff_strSlice(heff_dup(v_s_240), heff_box_word(v_t_241), heff_strLength_lent(v_s_240, 0));
  if (heff_strEq_c(v_t_242, ((V)&g_heff_2ebuild_2ebenchmarks_2ebenchTime_24cpr_str0))) {
    int64_t v_t_244 = (heff_unbox_word(heff_strLength_lent(v_s_240, 0)) - ((int64_t)1ULL));
    V v_s_245 = heff_strSlice_lent(v_s_240, MK_INT(0LL), heff_box_word(v_t_244), 6);
    if ((((int64_t)0ULL) < heff_unbox_word(heff_strLength_lent(v_s_245, 0)))) {
      int64_t v_t_247 = (heff_unbox_word(heff_strLength_lent(v_s_245, 0)) - ((int64_t)1ULL));
      V v_t_248 = (g_list_2erange(MK_INT(0LL), heff_box_word(v_t_247)));
      V v_t_249 = ({ V a_0 = MK_INT(48LL); V a_1 = v_s_245; V a_2 = MK_INT(57LL); V a_3 = v_t_248; V r_ = (g_list_2eall_24s443219008x474491297(a_0, a_1, a_2, a_3)); heff_drop(v_t_248); r_; });
      if ((heff_dup(v_t_249) == NTAG(TAG_True))) {
        heff_drop(v_t_249);
        HeffT2 v_t_2410 = ({ V a_0 = v_s_245; HeffT2 r_ = (g_prelude_2eparseInt_24cpr(a_0)); heff_drop(v_s_245); r_; });
        {
          V v_field_2412 = v_t_2410.f[1];
          int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
          if ((v_tag_2411 == ((int64_t)0ULL))) {
            V v_n_2414 = v_field_2412;
            if (heff_intLt_c_lent(MK_INT(0LL), v_n_2414, 1)) {
              return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_n(TAG_Times, 1, (V[]){v_n_2414})}});
            } else {
              heff_drop(v_n_2414);
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
            }
          } else {
            heff_drop(v_field_2412);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
        }
      } else {
        heff_drop(v_s_245);
        heff_drop(v_t_249);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    } else {
      heff_drop(v_s_245);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
  } else {
    V v_t_2416 = ({ V a_0 = v_s_240; V b_1 = heff_dup(g_heff_2ebuild_2ebenchmarks_2eunits_get()); V r_ = (g_list_2efind_24s1816408632x1283768171(a_0, b_1)); heff_drop(b_1); r_; });
    return (g_heff_2ebuild_2ebenchmarks_2edurationOf_24cpr(v_s_240, v_t_2416));
  }
}
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2espaces_24acc_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2espaces_24acc_str1, 1, " ");
Clo g_heff_2ebuild_2ebenchmarks_2espaces_24acc_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebenchmarks_2espaces_24acc_entry, 2, 0};

V g_heff_2ebuild_2ebenchmarks_2espaces_24acc(V v_n_240, V v_acc_241) {
top: ;
  if (heff_intLe_c_lent(v_n_240, MK_INT(0LL), 2)) {
    heff_drop(v_n_240);
    return heff_strAppend(v_acc_241, ((V)&g_heff_2ebuild_2ebenchmarks_2espaces_24acc_str0));
  } else {
    V v_s_243 = heff_strAppend(v_acc_241, ((V)&g_heff_2ebuild_2ebenchmarks_2espaces_24acc_str1));
    V t_0 = heff_intSub(v_n_240, MK_INT(1LL));
    V t_1 = v_s_243;
    v_n_240 = t_0;
    v_acc_241 = t_1;
    goto top;
  }
}
V g_heff_2ebuild_2ebenchmarks_2espaces_24acc_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ebenchmarks_2espaces_24acc(a[0], a[1]);
}
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2espaced_str0, 1, "\011");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2espaced_str1, 1, "\011");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2espaced_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2espaced_str3, 1, "_");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2espaced_str4, 1, " ");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2espaced_str5, 1, " ");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2espaced_str6, 0, "");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2espaced_str7, 1, "_");
Clo g_heff_2ebuild_2ebenchmarks_2espaced_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebenchmarks_2espaced_entry, 1, 0};

V g_heff_2ebuild_2ebenchmarks_2espaced(V v_s_240) {
top: ;
  V v_x2_241 = ({ V b_0 = ((V)&g_heff_2ebuild_2ebenchmarks_2espaced_str0); V a_1 = v_s_240; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2ebenchmarks_2espaced_str1), v_s_240, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
  V v_s_244;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    v_s_244 = ((V)&g_heff_2ebuild_2ebenchmarks_2espaced_str2);
    break;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    v_s_244 = ({ V a_0 = ((V)&g_heff_2ebuild_2ebenchmarks_2espaced_str3); V a_1 = v_x_242; V a_2 = v_xs_243; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_243); r_; });
    break;
  }
  default: heff_nomatch(v_x2_241);
  }
  V v_x2_245 = ({ V b_0 = ((V)&g_heff_2ebuild_2ebenchmarks_2espaced_str4); V a_1 = v_s_244; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2ebenchmarks_2espaced_str5), v_s_244, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); heff_drop(v_s_244); r_; });
  switch (heff_tag_of(v_x2_245)) {
  case TAG_Nil: {
    return ((V)&g_heff_2ebuild_2ebenchmarks_2espaced_str6);
  }
  case TAG_Cons: {
    V v_x_246 = heff_field(v_x2_245, 0);
    V v_xs_247 = heff_field(v_x2_245, 1);
    heff_take_n(v_x2_245, 3ULL, 2);
    return ({ V a_0 = ((V)&g_heff_2ebuild_2ebenchmarks_2espaced_str7); V a_1 = v_x_246; V a_2 = v_xs_247; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_247); r_; });
  }
  default: return heff_nomatch(v_x2_245);
  }
}
V g_heff_2ebuild_2ebenchmarks_2espaced_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ebenchmarks_2espaced(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eperOp_str0, 1, "0");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eperOp_str1, 1, ".");
Clo g_heff_2ebuild_2ebenchmarks_2eperOp_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebenchmarks_2eperOp_entry, 2, 0};

V g_heff_2ebuild_2ebenchmarks_2eperOp(V v_total_240, V v_n_241) {
top: ;
  if (heff_intEq_c_lent(v_total_240, MK_INT(0LL), 2)) {
    heff_drop(v_total_240);
    heff_drop(v_n_241);
    V v_t_243 = (g_heff_2ebuild_2ebenchmarks_2espaces(MK_INT(9LL)));
    return heff_strAppend(v_t_243, ((V)&g_heff_2ebuild_2ebenchmarks_2eperOp_str0));
  } else {
    V v_t_244 = (g_heff_2ebuild_2ebenchmarks_2eplacesOf(heff_dup(v_total_240), heff_dup(v_n_241), MK_INT(0LL)));
    V v_x_245 = (g_heff_2ebuild_2ebenchmarks_2eplacesOf(heff_dup(v_total_240), heff_dup(v_n_241), MK_INT(0LL)));
    V v_t_247;
    if (heff_intLt_c(MK_INT(0LL), v_x_245)) {
      v_t_247 = MK_INT(1LL);
    } else {
      v_t_247 = MK_INT(0LL);
    }
    V v_n_248 = heff_intAdd(heff_intAdd(MK_INT(10LL), v_t_244), v_t_247);
    V v_places_249 = (g_heff_2ebuild_2ebenchmarks_2eplacesOf(heff_dup(v_total_240), heff_dup(v_n_241), MK_INT(0LL)));
    V v_t_2410 = (g_heff_2ebuild_2ebenchmarks_2eplacesOf(heff_dup(v_total_240), heff_dup(v_n_241), MK_INT(0LL)));
    V v_t_2411 = (g_heff_2ebuild_2ebenchmarks_2etenTo(v_t_2410));
    V v_t_2412 = heff_intMul(heff_intMul(MK_INT(2LL), v_total_240), v_t_2411);
    V v_scaled_2413 = heff_intDiv(heff_intAdd(v_t_2412, heff_dup(v_n_241)), heff_intMul(MK_INT(2LL), v_n_241));
    V v_s_2420;
    if (heff_intEq_c_lent(v_places_249, MK_INT(0LL), 2)) {
      heff_drop(v_places_249);
      v_s_2420 = heff_intShow(v_scaled_2413);
    } else {
      V v_t_2415 = (g_heff_2ebuild_2ebenchmarks_2etenTo(heff_dup(v_places_249)));
      V v_t_2416 = heff_intShow(heff_intDiv(heff_dup(v_scaled_2413), v_t_2415));
      V v_t_2417 = (g_heff_2ebuild_2ebenchmarks_2etenTo(heff_dup(v_places_249)));
      V v_t_2418 = heff_intShow(heff_intMod(v_scaled_2413, v_t_2417));
      V v_t_2419 = (g_heff_2ebuild_2ebenchmarks_2ezeroPadded(v_places_249, v_t_2418));
      v_s_2420 = heff_strAppend(v_t_2416, heff_strAppend(((V)&g_heff_2ebuild_2ebenchmarks_2eperOp_str1), v_t_2419));
    }
    V v_t_2421 = heff_intSub(v_n_248, heff_strLength_lent(v_s_2420, 0));
    V v_t_2422 = (g_heff_2ebuild_2ebenchmarks_2espaces(v_t_2421));
    return heff_strAppend(v_t_2422, v_s_2420);
  }
}
V g_heff_2ebuild_2ebenchmarks_2eperOp_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ebenchmarks_2eperOp(a[0], a[1]);
}
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eoutcomeJson_str0, 4, "file");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eoutcomeJson_str1, 9, "Benchmark");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eoutcomeJson_str2, 1, "/");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eoutcomeJson_str3, 9, "Benchmark");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eoutcomeJson_str4, 4, "name");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eoutcomeJson_str5, 5, "names");
Clo g_heff_2ebuild_2ebenchmarks_2eoutcomeJson_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebenchmarks_2eoutcomeJson_entry, 3, 0};

V g_heff_2ebuild_2ebenchmarks_2eoutcomeJson(V v_f_240, V v_names_241, V v_o_242) {
top: ;
  V v_t_243 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2ebenchmarks_2eoutcomeJson_str0), heff_tag_n(TAG_JString, 1, (V[]){v_f_240})});
  V v_t_249;
  switch (heff_tag_of(v_names_241)) {
  case TAG_Nil: {
    v_t_249 = ((V)&g_heff_2ebuild_2ebenchmarks_2eoutcomeJson_str1);
    break;
  }
  case TAG_Cons: {
    V v_n_244 = heff_dup(heff_field(v_names_241, 0));
    V v_rest_245 = heff_dup(heff_field(v_names_241, 1));
    V v_t_246 = ({ V a_0 = v_n_244; V r_ = (g_heff_2ebuild_2ebenchmarks_2espaced(a_0)); heff_drop(v_n_244); r_; });
    V v_t_247 = (g_heff_2ebuild_2ebenchmarks_2ecapital(v_t_246));
    V v_t_248 = ({ V a_0 = ((V)&g_heff_2ebuild_2ebenchmarks_2eoutcomeJson_str2); V a_1 = v_t_247; V a_2 = v_rest_245; V r_ = (g_prelude_2ejoinWith_2eafter_240_24f591888720x1996727869(a_0, a_1, a_2)); heff_drop(v_rest_245); r_; });
    v_t_249 = heff_strAppend(((V)&g_heff_2ebuild_2ebenchmarks_2eoutcomeJson_str3), v_t_248);
    break;
  }
  default: heff_nomatch(v_names_241);
  }
  V v_t_2410 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2ebenchmarks_2eoutcomeJson_str4), heff_tag_n(TAG_JString, 1, (V[]){v_t_249})});
  V v_t_2411 = (g_list_2emap_24s723912745x1713553694(v_names_241));
  V v_t_2412 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2ebenchmarks_2eoutcomeJson_str5), heff_tag_n(TAG_JArray, 1, (V[]){v_t_2411})});
  V v_t_2413 = (g_heff_2ebuild_2ebenchmarks_2eoutcomeFields(v_o_242));
  V v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2410, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2412, v_t_2413})});
  V v_t_2415 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_243, v_t_2414})});
  return ({ V a_0 = v_t_2415; V r_ = (g_json_2estringify(a_0)); heff_drop_tag(v_t_2415, 1); r_; });
}
V g_heff_2ebuild_2ebenchmarks_2eoutcomeJson_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ebenchmarks_2eoutcomeJson(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2ebenchMainName_str0, 13, "heffBenchMain");

static V g_heff_2ebuild_2ebenchmarks_2ebenchMainName_val;
static HEFF_ONCE g_heff_2ebuild_2ebenchmarks_2ebenchMainName_st;
static V g_heff_2ebuild_2ebenchmarks_2ebenchMainName_init(void) {
  return ((V)&g_heff_2ebuild_2ebenchmarks_2ebenchMainName_str0);
}
V g_heff_2ebuild_2ebenchmarks_2ebenchMainName_get(void) {
  if (HEFF_DONE(g_heff_2ebuild_2ebenchmarks_2ebenchMainName_st)) return g_heff_2ebuild_2ebenchmarks_2ebenchMainName_val;
  return heff_global(&g_heff_2ebuild_2ebenchmarks_2ebenchMainName_val, &g_heff_2ebuild_2ebenchmarks_2ebenchMainName_st, g_heff_2ebuild_2ebenchmarks_2ebenchMainName_init);
}
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2ebenchAdded_24cpr_str0, 51, "it does not import bench, which runs its benchmarks");
V g_heff_2ebuild_2ebenchmarks_2ebenchAdded_24cpr_lam0(V self, V *args);

HeffT2 g_heff_2ebuild_2ebenchmarks_2ebenchAdded_24cpr(V v_l_240, V v_c_241, V v_src_242) {
top: ;
  V v_t_243 = (g_heff_2esyntax_2eimport_2eimportsOf(heff_take_field(v_src_242, 6), heff_take_field(v_src_242, 4)));
  HeffT4 v_t_244 = ({ V b_0 = heff_get_n(v_src_242, 5, 8); V a_1 = v_t_243; HeffT4 r_ = (g_heff_2esyntax_2eimport_2erenamed_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
  V v_t_249;
  {
    V v_field_245 = v_t_244.f[0];
    heff_drop(v_t_244.f[1]);
    heff_drop(v_t_244.f[2]);
    heff_drop(v_t_244.f[3]);
    v_t_249 = v_field_245;
  }
  HeffT2 v_t_2410 = (g_heff_2ebuild_2ebenchmarks_2ebenchQualifier_24cpr(v_t_249));
  {
    V v_field_2412 = v_t_2410.f[1];
    int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
    if ((v_tag_2411 == ((int64_t)0ULL))) {
      V v_q_2414 = v_field_2412;
      V v_t_2416 = (g_list_2efilter(heff_clo_n(g_heff_2ebuild_2ebenchmarks_2ebenchAdded_24cpr_lam0, 1, 1, (V[]){heff_dup(v_c_241)}), heff_dup(heff_rfield(v_c_241, 7))));
      V v_t_2417 = (g_heff_2ebuild_2edriver_2erootsAmong(heff_dup(v_c_241), v_t_2416));
      V v_t_2418 = (g_heff_2ebuild_2ebenchmarks_2ebenchText(v_q_2414, v_t_2417));
      V v_sources_2419 = ({ V b_0 = heff_get_n(v_c_241, 0, 14); V a_1 = v_t_2418; V a_2 = heff_take_field(v_l_240, 0); V r_ = (g_list_2emap_24s1750766838x1556198350(b_0, a_1, a_2)); heff_drop(b_0); r_; });
      V v_f_2420 = ({ V rv_0 = v_sources_2419; V rr_ = heff_rec_reuse_nf(v_l_240, 30ULL, 5, shape_sources__errors__paths__package__packages, 1020u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_f_2420}});
    } else {
      heff_drop_rec(v_l_240, 5);
      heff_drop_rec(v_c_241, 14);
      heff_drop(v_field_2412);
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), ((V)&g_heff_2ebuild_2ebenchmarks_2ebenchAdded_24cpr_str0)}});
    }
  }
}
V g_heff_2ebuild_2ebenchmarks_2ebenchAdded_24cpr_lam0(V self, V *args) {
  V v_o_2415 = args[0];
  V v_c_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2ebuild_2edriver_2eisBenchOwn(v_c_241, v_o_2415));
}
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2ebenchDir_str0, 11, ".heff/bench");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2ebenchDir_str1, 2, "..");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2ebenchDir_str2, 2, "..");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2ebenchDir_str3, 2, "..");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2ebenchDir_str4, 2, "..");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2ebenchDir_str5, 0, "");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2ebenchDir_str6, 1, "_");
Clo g_heff_2ebuild_2ebenchmarks_2ebenchDir_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebenchmarks_2ebenchDir_entry, 2, 0};

V g_heff_2ebuild_2ebenchmarks_2ebenchDir(V v_paths_240, V v_file_241) {
top: ;
  V v_st_242 = heff_dup(heff_rfield(v_paths_240, 5));
  V v_t_243 = (g_std_2epath_2eparse(v_st_242, heff_take_field(v_paths_240, 0)));
  V v_t_244 = (g_std_2epath_2eparse(v_st_242, ((V)&g_heff_2ebuild_2ebenchmarks_2ebenchDir_str0)));
  V v_t_245 = (g_std_2epath_2ejoin(v_t_243, v_t_244));
  V v_d_246 = ({ V a_0 = v_st_242; V a_1 = v_t_245; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_242); heff_drop(v_t_245); r_; });
  HeffT3 v_t_247 = (g_std_2epath_2eparse_24cpr(heff_rfield(v_paths_240, 5), v_file_241));
  {
    V v_field_248 = v_t_247.f[0];
    V v_field_249 = v_t_247.f[1];
    V v_field_2410 = v_t_247.f[2];
    V v_d_2411 = v_field_248;
    heff_drop(v_d_2411);
    V v_a_2412 = v_field_249;
    V v_xs_2413 = v_field_2410;
    V v_xs_2414 = ({ V b_0 = ((V)&g_heff_2ebuild_2ebenchmarks_2ebenchDir_str1); V a_1 = v_a_2412; V a_2 = ((V)&g_heff_2ebuild_2ebenchmarks_2ebenchDir_str2); V b_3 = ((V)&g_heff_2ebuild_2ebenchmarks_2ebenchDir_str3); V a_4 = ((V)&g_heff_2ebuild_2ebenchmarks_2ebenchDir_str4); V a_5 = NTAG(TAG_Nil); V a_6 = v_xs_2413; V r_ = (g_list_2efoldl_24s1313398329x1387572461(b_0, a_1, a_2, b_3, a_4, a_5, a_6)); heff_drop(b_0); heff_drop(v_a_2412); heff_drop(b_3); r_; });
    V v_t_2415 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2414));
    V v_x2_2416 = v_t_2415;
    V v_p_2419;
    switch (heff_tag_of(v_x2_2416)) {
    case TAG_Nil: {
      v_p_2419 = ((V)&g_heff_2ebuild_2ebenchmarks_2ebenchDir_str5);
      break;
    }
    case TAG_Cons: {
      V v_x_2417 = heff_field(v_x2_2416, 0);
      V v_xs_2418 = heff_field(v_x2_2416, 1);
      heff_take_n(v_x2_2416, 3ULL, 2);
      v_p_2419 = ({ V a_0 = ((V)&g_heff_2ebuild_2ebenchmarks_2ebenchDir_str6); V a_1 = v_x_2417; V a_2 = v_xs_2418; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2418); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2416);
    }
    V v_st_2420 = heff_get_n(v_paths_240, 5, 6);
    V v_t_2421 = (g_std_2epath_2eparse(v_st_2420, v_d_246));
    V v_t_2422 = (g_std_2epath_2eparse(v_st_2420, v_p_2419));
    V v_t_2423 = (g_std_2epath_2ejoin(v_t_2421, v_t_2422));
    return ({ V a_0 = v_st_2420; V a_1 = v_t_2423; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2420); heff_drop(v_t_2423); r_; });
  }
}
V g_heff_2ebuild_2ebenchmarks_2ebenchDir_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ebenchmarks_2ebenchDir(a[0], a[1]);
}
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eoutcomeOfLine_str0, 1, "n");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eoutcomeOfLine_str1, 7, "skipped");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eoutcomeOfLine_str2, 6, "failed");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eoutcomeOfLine_str3, 30, "it said nothing of how it went");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eoutcomeOfLine_str4, 30, "it said nothing of how it went");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eoutcomeOfLine_str5, 30, "it said nothing of how it went");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eoutcomeOfLine_str6, 30, "it said nothing of how it went");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eoutcomeOfLine_str7, 30, "it said nothing of how it went");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eoutcomeOfLine_str8, 30, "it said nothing of how it went");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eoutcomeOfLine_str9, 30, "it said nothing of how it went");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eoutcomeOfLine_str10, 2, "ns");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eoutcomeOfLine_str11, 6, "allocs");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eoutcomeOfLine_str12, 5, "bytes");
Clo g_heff_2ebuild_2ebenchmarks_2eoutcomeOfLine_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebenchmarks_2eoutcomeOfLine_entry, 1, 0};

V g_heff_2ebuild_2ebenchmarks_2eoutcomeOfLine(V v_j_240) {
top: ;
  V v_t_241 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ebenchmarks_2eoutcomeOfLine_str0), NTAG(TAG_Nil)});
  HeffT2 v_t_242 = (g_json_2eat_24cpr(v_t_241, heff_dup(v_j_240)));
  {
    V v_field_244 = v_t_242.f[1];
    int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
    V v_t_2413;
    if ((v_tag_243 == ((int64_t)0ULL))) {
      V v_it1_246 = v_field_244;
      switch (heff_tag_of(v_it1_246)) {
      case TAG_JNull: {
        v_t_2413 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_JBool: {
        heff_take_n(v_it1_246, 0ULL, 1);
        v_t_2413 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_JInt: {
        V v_i_248 = heff_field(v_it1_246, 0);
        V v_ru_24it1_246_24JInt = heff_take_reuse_n(v_it1_246, 1ULL, 1);
        v_t_2413 = heff_tag_at_n(v_ru_24it1_246_24JInt, TAG_Just, 1, (V[]){v_i_248});
        break;
      }
      case TAG_JFloat: {
        double v_x_249 = heff_tflat_f64(v_it1_246, 0);
        V v_ru_24it1_246_24JFloat = heff_take_reuse_na(v_it1_246, 0ULL, 1);
        v_t_2413 = heff_tag_at_n(v_ru_24it1_246_24JFloat, TAG_Just, 1, (V[]){heff_floor_f64(v_x_249)});
        break;
      }
      case TAG_JString: {
        heff_take_n(v_it1_246, 0ULL, 1);
        v_t_2413 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_JArray: {
        heff_take_n(v_it1_246, 0ULL, 1);
        v_t_2413 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_JObject: {
        heff_take_n(v_it1_246, 0ULL, 1);
        v_t_2413 = NTAG(TAG_Nothing);
        break;
      }
      default: heff_nomatch(v_it1_246);
      }
    } else {
      heff_drop(v_field_244);
      v_t_2413 = NTAG(TAG_Nothing);
    }
    switch (heff_tag_of(v_t_2413)) {
    case TAG_Nothing: {
      V v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ebenchmarks_2eoutcomeOfLine_str1), NTAG(TAG_Nil)});
      HeffT2 v_t_2415 = (g_json_2eat_24cpr(v_t_2414, heff_dup(v_j_240)));
      {
        V v_field_2417 = v_t_2415.f[1];
        int64_t v_tag_2416 = ((int64_t)v_t_2415.f[0]);
        V v_t_2426;
        if ((v_tag_2416 == ((int64_t)0ULL))) {
          V v_it1_2419 = v_field_2417;
          switch (heff_tag_of(v_it1_2419)) {
          case TAG_JNull: {
            v_t_2426 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_JBool: {
            heff_take_n(v_it1_2419, 0ULL, 1);
            v_t_2426 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_JInt: {
            heff_take_n(v_it1_2419, 0ULL, 1);
            v_t_2426 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_JFloat: {
            heff_take_na(v_it1_2419, 0ULL, 1);
            v_t_2426 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_JString: {
            V v_s_2423 = heff_field(v_it1_2419, 0);
            V v_ru_24it1_2419_24JString = heff_take_reuse_n(v_it1_2419, 1ULL, 1);
            v_t_2426 = heff_tag_at_n(v_ru_24it1_2419_24JString, TAG_Just, 1, (V[]){v_s_2423});
            break;
          }
          case TAG_JArray: {
            heff_take_n(v_it1_2419, 0ULL, 1);
            v_t_2426 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_JObject: {
            heff_take_n(v_it1_2419, 0ULL, 1);
            v_t_2426 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_it1_2419);
          }
        } else {
          heff_drop(v_field_2417);
          v_t_2426 = NTAG(TAG_Nothing);
        }
        switch (heff_tag_of(v_t_2426)) {
        case TAG_Nothing: {
          V v_t_2427 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ebenchmarks_2eoutcomeOfLine_str2), NTAG(TAG_Nil)});
          HeffT2 v_t_2428 = (g_json_2eat_24cpr(v_t_2427, v_j_240));
          V v_t_2439;
          {
            V v_field_2430 = v_t_2428.f[1];
            int64_t v_tag_2429 = ((int64_t)v_t_2428.f[0]);
            if ((v_tag_2429 == ((int64_t)0ULL))) {
              V v_it1_2432 = v_field_2430;
              switch (heff_tag_of(v_it1_2432)) {
              case TAG_JNull: {
                v_t_2439 = ((V)&g_heff_2ebuild_2ebenchmarks_2eoutcomeOfLine_str3);
                break;
              }
              case TAG_JBool: {
                heff_take_n(v_it1_2432, 0ULL, 1);
                v_t_2439 = ((V)&g_heff_2ebuild_2ebenchmarks_2eoutcomeOfLine_str4);
                break;
              }
              case TAG_JInt: {
                heff_take_n(v_it1_2432, 0ULL, 1);
                v_t_2439 = ((V)&g_heff_2ebuild_2ebenchmarks_2eoutcomeOfLine_str5);
                break;
              }
              case TAG_JFloat: {
                heff_take_na(v_it1_2432, 0ULL, 1);
                v_t_2439 = ((V)&g_heff_2ebuild_2ebenchmarks_2eoutcomeOfLine_str6);
                break;
              }
              case TAG_JString: {
                V v_s_2436 = heff_field(v_it1_2432, 0);
                heff_take_n(v_it1_2432, 1ULL, 1);
                v_t_2439 = v_s_2436;
                break;
              }
              case TAG_JArray: {
                heff_take_n(v_it1_2432, 0ULL, 1);
                v_t_2439 = ((V)&g_heff_2ebuild_2ebenchmarks_2eoutcomeOfLine_str7);
                break;
              }
              case TAG_JObject: {
                heff_take_n(v_it1_2432, 0ULL, 1);
                v_t_2439 = ((V)&g_heff_2ebuild_2ebenchmarks_2eoutcomeOfLine_str8);
                break;
              }
              default: heff_nomatch(v_it1_2432);
              }
            } else {
              heff_drop(v_field_2430);
              v_t_2439 = ((V)&g_heff_2ebuild_2ebenchmarks_2eoutcomeOfLine_str9);
            }
          }
          return heff_tag_n(TAG_FailedWith, 1, (V[]){v_t_2439});
        }
        case TAG_Just: {
          V v_why_2440 = heff_field(v_t_2426, 0);
          V v_ru_24t_2426_24Just = heff_take_reuse_n(v_t_2426, 1ULL, 1);
          heff_drop(v_j_240);
          return heff_tag_at_n(v_ru_24t_2426_24Just, TAG_SkippedWith, 1, (V[]){v_why_2440});
        }
        default: return heff_nomatch(v_t_2426);
        }
      }
    }
    case TAG_Just: {
      V v_n_2441 = heff_field(v_t_2413, 0);
      heff_take_n(v_t_2413, 1ULL, 1);
      V v_t_2442 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ebenchmarks_2eoutcomeOfLine_str10), NTAG(TAG_Nil)});
      HeffT2 v_t_2443 = (g_json_2eat_24cpr(v_t_2442, heff_dup(v_j_240)));
      V v_t_2454;
      {
        V v_field_2445 = v_t_2443.f[1];
        int64_t v_tag_2444 = ((int64_t)v_t_2443.f[0]);
        if ((v_tag_2444 == ((int64_t)0ULL))) {
          V v_it1_2447 = v_field_2445;
          switch (heff_tag_of(v_it1_2447)) {
          case TAG_JNull: {
            v_t_2454 = MK_INT(0LL);
            break;
          }
          case TAG_JBool: {
            heff_take_n(v_it1_2447, 0ULL, 1);
            v_t_2454 = MK_INT(0LL);
            break;
          }
          case TAG_JInt: {
            V v_i_2449 = heff_field(v_it1_2447, 0);
            heff_take_n(v_it1_2447, 1ULL, 1);
            v_t_2454 = v_i_2449;
            break;
          }
          case TAG_JFloat: {
            double v_x_2450 = heff_tflat_f64(v_it1_2447, 0);
            heff_take_na(v_it1_2447, 0ULL, 1);
            v_t_2454 = heff_floor_f64(v_x_2450);
            break;
          }
          case TAG_JString: {
            heff_take_n(v_it1_2447, 0ULL, 1);
            v_t_2454 = MK_INT(0LL);
            break;
          }
          case TAG_JArray: {
            heff_take_n(v_it1_2447, 0ULL, 1);
            v_t_2454 = MK_INT(0LL);
            break;
          }
          case TAG_JObject: {
            heff_take_n(v_it1_2447, 0ULL, 1);
            v_t_2454 = MK_INT(0LL);
            break;
          }
          default: heff_nomatch(v_it1_2447);
          }
        } else {
          heff_drop(v_field_2445);
          v_t_2454 = MK_INT(0LL);
        }
      }
      V v_t_2455 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ebenchmarks_2eoutcomeOfLine_str11), NTAG(TAG_Nil)});
      HeffT2 v_t_2456 = (g_json_2eat_24cpr(v_t_2455, heff_dup(v_j_240)));
      V v_t_2467;
      {
        V v_field_2458 = v_t_2456.f[1];
        int64_t v_tag_2457 = ((int64_t)v_t_2456.f[0]);
        if ((v_tag_2457 == ((int64_t)0ULL))) {
          V v_it1_2460 = v_field_2458;
          switch (heff_tag_of(v_it1_2460)) {
          case TAG_JNull: {
            v_t_2467 = MK_INT(0LL);
            break;
          }
          case TAG_JBool: {
            heff_take_n(v_it1_2460, 0ULL, 1);
            v_t_2467 = MK_INT(0LL);
            break;
          }
          case TAG_JInt: {
            V v_i_2462 = heff_field(v_it1_2460, 0);
            heff_take_n(v_it1_2460, 1ULL, 1);
            v_t_2467 = v_i_2462;
            break;
          }
          case TAG_JFloat: {
            double v_x_2463 = heff_tflat_f64(v_it1_2460, 0);
            heff_take_na(v_it1_2460, 0ULL, 1);
            v_t_2467 = heff_floor_f64(v_x_2463);
            break;
          }
          case TAG_JString: {
            heff_take_n(v_it1_2460, 0ULL, 1);
            v_t_2467 = MK_INT(0LL);
            break;
          }
          case TAG_JArray: {
            heff_take_n(v_it1_2460, 0ULL, 1);
            v_t_2467 = MK_INT(0LL);
            break;
          }
          case TAG_JObject: {
            heff_take_n(v_it1_2460, 0ULL, 1);
            v_t_2467 = MK_INT(0LL);
            break;
          }
          default: heff_nomatch(v_it1_2460);
          }
        } else {
          heff_drop(v_field_2458);
          v_t_2467 = MK_INT(0LL);
        }
      }
      V v_t_2468 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ebenchmarks_2eoutcomeOfLine_str12), NTAG(TAG_Nil)});
      HeffT2 v_t_2469 = (g_json_2eat_24cpr(v_t_2468, v_j_240));
      V v_t_2480;
      {
        V v_field_2471 = v_t_2469.f[1];
        int64_t v_tag_2470 = ((int64_t)v_t_2469.f[0]);
        if ((v_tag_2470 == ((int64_t)0ULL))) {
          V v_it1_2473 = v_field_2471;
          switch (heff_tag_of(v_it1_2473)) {
          case TAG_JNull: {
            v_t_2480 = MK_INT(0LL);
            break;
          }
          case TAG_JBool: {
            heff_take_n(v_it1_2473, 0ULL, 1);
            v_t_2480 = MK_INT(0LL);
            break;
          }
          case TAG_JInt: {
            V v_i_2475 = heff_field(v_it1_2473, 0);
            heff_take_n(v_it1_2473, 1ULL, 1);
            v_t_2480 = v_i_2475;
            break;
          }
          case TAG_JFloat: {
            double v_x_2476 = heff_tflat_f64(v_it1_2473, 0);
            heff_take_na(v_it1_2473, 0ULL, 1);
            v_t_2480 = heff_floor_f64(v_x_2476);
            break;
          }
          case TAG_JString: {
            heff_take_n(v_it1_2473, 0ULL, 1);
            v_t_2480 = MK_INT(0LL);
            break;
          }
          case TAG_JArray: {
            heff_take_n(v_it1_2473, 0ULL, 1);
            v_t_2480 = MK_INT(0LL);
            break;
          }
          case TAG_JObject: {
            heff_take_n(v_it1_2473, 0ULL, 1);
            v_t_2480 = MK_INT(0LL);
            break;
          }
          default: heff_nomatch(v_it1_2473);
          }
        } else {
          heff_drop(v_field_2471);
          v_t_2480 = MK_INT(0LL);
        }
      }
      return heff_tag_n(TAG_Measured, 4, (V[]){v_n_2441, v_t_2454, v_t_2467, v_t_2480});
    }
    default: return heff_nomatch(v_t_2413);
    }
  }
}
V g_heff_2ebuild_2ebenchmarks_2eoutcomeOfLine_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ebenchmarks_2eoutcomeOfLine(a[0]);
}
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2elistedOf_24cpr_str0, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2elistedOf_24cpr_str1, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2elistedOf_24cpr_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2elistedOf_24cpr_str3, 0, "");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2elistedOf_24cpr_str4, 32, "what it listed could not be read");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2elistedOf_24cpr_str5, 32, "what it listed could not be read");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2elistedOf_24cpr_str6, 32, "what it listed could not be read");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2elistedOf_24cpr_str7, 32, "what it listed could not be read");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2elistedOf_24cpr_str8, 32, "what it listed could not be read");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2elistedOf_24cpr_str9, 32, "what it listed could not be read");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2elistedOf_24cpr_str10, 32, "what it listed could not be read");

HeffT2 g_heff_2ebuild_2ebenchmarks_2elistedOf_24cpr(V v_r_240) {
top: ;
  V v_t_241 = heff_dup(heff_rfield(v_r_240, 0));
  switch (heff_tag_of(v_t_241)) {
  case TAG_Exited: {
    V v_n_242 = heff_field(v_t_241, 0);
    heff_take_n(v_t_241, 1ULL, 1);
    if (heff_intEq_c(v_n_242, MK_INT(0LL))) {
      V v_t_244 = heff_get_n(v_r_240, 1, 3);
      V v_t_245 = ({ V b_0 = ((V)&g_heff_2ebuild_2ebenchmarks_2elistedOf_24cpr_str0); V a_1 = v_t_244; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2ebenchmarks_2elistedOf_24cpr_str1), v_t_244, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); heff_drop(v_t_244); r_; });
      V v_x1_246 = ({ V a_0 = NTAG(TAG_Nil); V b_1 = ((V)&g_heff_2ebuild_2ebenchmarks_2elistedOf_24cpr_str2); V a_2 = v_t_245; V r_ = (g_list_2efoldl_24f470245410x241064089(a_0, b_1, a_2)); heff_drop(b_1); r_; });
      V v_t_249;
      switch (heff_tag_of(v_x1_246)) {
      case TAG_Nil: {
        v_t_249 = ((V)&g_heff_2ebuild_2ebenchmarks_2elistedOf_24cpr_str3);
        break;
      }
      case TAG_Cons: {
        V v_x_247 = heff_field(v_x1_246, 0);
        heff_take_n(v_x1_246, 1ULL, 2);
        v_t_249 = v_x_247;
        break;
      }
      default: heff_nomatch(v_x1_246);
      }
      V v_t_2410 = heff_tag_n(TAG_Value, 2, (V[]){MK_INT(0LL), NTAG(TAG_Nil)});
      HeffT2 v_t_2411 = ({ V a_0 = v_t_249; V a_1 = v_t_2410; HeffT2 r_ = (g_json_2esteps_24cpr(a_0, a_1)); heff_drop(v_t_249); r_; });
      {
        V v_field_2413 = v_t_2411.f[1];
        int64_t v_tag_2412 = ((int64_t)v_t_2411.f[0]);
        if ((v_tag_2412 == ((int64_t)0ULL))) {
          V v_x_2415 = v_field_2413;
          heff_drop(v_x_2415);
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), ((V)&g_heff_2ebuild_2ebenchmarks_2elistedOf_24cpr_str4)}});
        } else {
          V v_it1_2416 = v_field_2413;
          switch (heff_tag_of(v_it1_2416)) {
          case TAG_JNull: {
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), ((V)&g_heff_2ebuild_2ebenchmarks_2elistedOf_24cpr_str5)}});
          }
          case TAG_JBool: {
            heff_take_n(v_it1_2416, 0ULL, 1);
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), ((V)&g_heff_2ebuild_2ebenchmarks_2elistedOf_24cpr_str6)}});
          }
          case TAG_JInt: {
            heff_take_n(v_it1_2416, 0ULL, 1);
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), ((V)&g_heff_2ebuild_2ebenchmarks_2elistedOf_24cpr_str7)}});
          }
          case TAG_JFloat: {
            heff_take_na(v_it1_2416, 0ULL, 1);
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), ((V)&g_heff_2ebuild_2ebenchmarks_2elistedOf_24cpr_str8)}});
          }
          case TAG_JString: {
            heff_take_n(v_it1_2416, 0ULL, 1);
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), ((V)&g_heff_2ebuild_2ebenchmarks_2elistedOf_24cpr_str9)}});
          }
          case TAG_JArray: {
            V v_bs_2421 = heff_field(v_it1_2416, 0);
            heff_take_n(v_it1_2416, 1ULL, 1);
            V v_f_2422 = (g_list_2emap_24s849938259x51049885(v_bs_2421));
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_f_2422}});
          }
          case TAG_JObject: {
            heff_take_n(v_it1_2416, 0ULL, 1);
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), ((V)&g_heff_2ebuild_2ebenchmarks_2elistedOf_24cpr_str10)}});
          }
          default: return ((HeffT2){{heff_nomatch(v_it1_2416)}});
          }
        }
      }
    } else {
      V v_f_2424 = (g_heff_2ebuild_2ebenchmarks_2eendedWhy(v_r_240));
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2424}});
    }
  }
  case TAG_Signalled: {
    heff_take_n(v_t_241, 0ULL, 1);
    V v_f_2426 = (g_heff_2ebuild_2ebenchmarks_2eendedWhy(v_r_240));
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2426}});
  }
  case TAG_TimedOut: {
    V v_f_2427 = (g_heff_2ebuild_2ebenchmarks_2eendedWhy(v_r_240));
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2427}});
  }
  case TAG_NotRun: {
    V v_f_2428 = (g_heff_2ebuild_2ebenchmarks_2eendedWhy(v_r_240));
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2428}});
  }
  default: return ((HeffT2){{heff_nomatch(v_t_241)}});
  }
}
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2ebenchOptions_24s1318533244x2074895986_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2ebenchOptions_24s1318533244x2074895986_str1, 0, "");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2ebenchOptions_24s1318533244x2074895986_str2, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2ebenchOptions_24s1318533244x2074895986_str3, 18, "heff bench: --run ");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2ebenchOptions_24s1318533244x2074895986_str4, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2ebenchOptions_24s1318533244x2074895986_str5, 0, "");
V g_heff_2ebuild_2ebenchmarks_2ebenchOptions_24s1318533244x2074895986_lam1(V self, V *args);
V g_heff_2ebuild_2ebenchmarks_2ebenchOptions_24s1318533244x2074895986_lam0(V self, V *args);
V g_heff_2ebuild_2ebenchmarks_2ebenchOptions_24s1318533244x2074895986_lam2(V self, V *args); static Clo g_heff_2ebuild_2ebenchmarks_2ebenchOptions_24s1318533244x2074895986_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebenchmarks_2ebenchOptions_24s1318533244x2074895986_lam2, 2, 0};
V g_heff_2ebuild_2ebenchmarks_2ebenchOptions_24s1318533244x2074895986_lam6(V self, V *args);
V g_heff_2ebuild_2ebenchmarks_2ebenchOptions_24s1318533244x2074895986_lam5(V self, V *args);
V g_heff_2ebuild_2ebenchmarks_2ebenchOptions_24s1318533244x2074895986_lam4(V self, V *args);
V g_heff_2ebuild_2ebenchmarks_2ebenchOptions_24s1318533244x2074895986_lam3(V self, V *args);
Clo g_heff_2ebuild_2ebenchmarks_2ebenchOptions_24s1318533244x2074895986_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebenchmarks_2ebenchOptions_24s1318533244x2074895986_entry, 4, 0};

V g_heff_2ebuild_2ebenchmarks_2ebenchOptions_24s1318533244x2074895986(V v_pattern_240, V v_time_241, V v_count_242, V v_json_243) {
top: ;
  V v_t_245;
  switch (heff_tag_of(v_pattern_240)) {
  case TAG_Nothing: {
    v_t_245 = ((V)&g_heff_2ebuild_2ebenchmarks_2ebenchOptions_24s1318533244x2074895986_str0);
    break;
  }
  case TAG_Just: {
    V v_x_244 = heff_field(v_pattern_240, 0);
    v_t_245 = heff_dup(v_x_244);
    break;
  }
  default: heff_nomatch(v_pattern_240);
  }
  V v_t_246 = ({ V a_0 = MK_INT(47LL); V a_1 = v_t_245; V a_2 = MK_INT(0LL); V a_3 = MK_INT(0LL); V a_4 = NTAG(TAG_False); V a_5 = NTAG(TAG_Nil); V r_ = (g_regex_2esplitGo(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_t_245); r_; });
  V v_t_247 = (g_list_2emap_24s1007499915x73800978(v_t_246));
  HeffT2 v_t_248 = (g_regex_2eallRead_24cpr(v_t_247));
  V v_c_2437;
  {
    V v_field_2410 = v_t_248.f[1];
    int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
    if ((v_tag_249 == ((int64_t)0ULL))) {
      V v_why_2412 = v_field_2410;
      v_c_2437 = heff_clo_n(g_heff_2ebuild_2ebenchmarks_2ebenchOptions_24s1318533244x2074895986_lam0, 2, 2, (V[]){heff_dup(v_pattern_240), v_why_2412});
    } else {
      V v_x_2434 = v_field_2410;
      heff_drop(v_x_2434);
      v_c_2437 = ((V)&g_heff_2ebuild_2ebenchmarks_2ebenchOptions_24s1318533244x2074895986_lam2_clo);
    }
  }
  return heff_clo_n(g_heff_2ebuild_2ebenchmarks_2ebenchOptions_24s1318533244x2074895986_lam3, 2, 5, (V[]){v_c_2437, v_time_241, v_count_242, heff_dup(v_pattern_240), v_json_243});
}
V g_heff_2ebuild_2ebenchmarks_2ebenchOptions_24s1318533244x2074895986_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ebenchmarks_2ebenchOptions_24s1318533244x2074895986(a0, a[1], a[2], a[3]); heff_drop(a0); return r;
}
V g_heff_2ebuild_2ebenchmarks_2ebenchOptions_24s1318533244x2074895986_lam1(V self, V *args) {
  V v_x_2426 = args[0];
  V v_hd_2413 = heff_env(self)[0];
  V v_k_2414 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2426);
  V v_t_2427 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(2LL), NTAG(TAG_MkUnit)});
  V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2427})});
  V v_t_2429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
  V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
  V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
  V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
  V v_t_2433 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2432})});
  return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2433}), v_hd_2413, v_k_2414));
}
V g_heff_2ebuild_2ebenchmarks_2ebenchOptions_24s1318533244x2074895986_lam0(V self, V *args) {
  V v_hd_2413 = args[0];
  V v_k_2414 = args[1];
  V v_pattern_240 = heff_env(self)[0];
  V v_why_2412 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2416;
  switch (heff_tag_of(v_pattern_240)) {
  case TAG_Nothing: {
    v_t_2416 = ((V)&g_heff_2ebuild_2ebenchmarks_2ebenchOptions_24s1318533244x2074895986_str1);
    break;
  }
  case TAG_Just: {
    V v_x_2415 = heff_field(v_pattern_240, 0);
    heff_take_n(v_pattern_240, 1ULL, 1);
    v_t_2416 = v_x_2415;
    break;
  }
  default: heff_nomatch(v_pattern_240);
  }
  V v_t_2417 = heff_strAppend(v_t_2416, heff_strAppend(((V)&g_heff_2ebuild_2ebenchmarks_2ebenchOptions_24s1318533244x2074895986_str2), v_why_2412));
  V v_t_2418 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ebenchmarks_2ebenchOptions_24s1318533244x2074895986_str3), v_t_2417), ((V)&g_heff_2ebuild_2ebenchmarks_2ebenchOptions_24s1318533244x2074895986_str4));
  V v_t_2419 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2418, NTAG(TAG_MkUnit)});
  V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
  V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
  V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
  V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
  V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
  V v_t_2425 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2424})});
  return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2425}), heff_dup(v_hd_2413), heff_clo_n(g_heff_2ebuild_2ebenchmarks_2ebenchOptions_24s1318533244x2074895986_lam1, 1, 2, (V[]){v_hd_2413, v_k_2414})));
}
V g_heff_2ebuild_2ebenchmarks_2ebenchOptions_24s1318533244x2074895986_lam2(V self, V *args) {
  V v_hd_2435 = args[0];
  V v_k_2436 = args[1];
  heff_drop(v_hd_2435);
  V f_ = v_k_2436;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ebenchmarks_2ebenchOptions_24s1318533244x2074895986_lam6(V self, V *args) {
  V v_x_2444 = args[0];
  V v_pattern_240 = heff_env(self)[0];
  V v_k_2439 = heff_env(self)[1];
  V v_x_2442 = heff_env(self)[2];
  V v_json_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2446;
  switch (heff_tag_of(v_pattern_240)) {
  case TAG_Nothing: {
    v_t_2446 = ((V)&g_heff_2ebuild_2ebenchmarks_2ebenchOptions_24s1318533244x2074895986_str5);
    break;
  }
  case TAG_Just: {
    V v_x_2445 = heff_field(v_pattern_240, 0);
    heff_take_n(v_pattern_240, 1ULL, 1);
    v_t_2446 = v_x_2445;
    break;
  }
  default: heff_nomatch(v_pattern_240);
  }
  V f_ = v_k_2439;
  args[0] = heff_rec_n(4, shape_pattern__time__count__json, (V[]){v_t_2446, v_x_2442, v_x_2444, v_json_243});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ebenchmarks_2ebenchOptions_24s1318533244x2074895986_lam5(V self, V *args) {
  V v_x_2442 = args[0];
  V v_count_242 = heff_env(self)[0];
  V v_hd_2438 = heff_env(self)[1];
  V v_pattern_240 = heff_env(self)[2];
  V v_k_2439 = heff_env(self)[3];
  V v_json_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_c_2443 = (g_heff_2ebuild_2ebenchmarks_2ecountGiven_24s1419575577x1110690646(v_count_242));
  V f_ = v_c_2443;
  heff_room[0] = v_hd_2438;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ebenchmarks_2ebenchOptions_24s1318533244x2074895986_lam6, 1, 4, (V[]){v_pattern_240, v_k_2439, v_x_2442, v_json_243});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ebenchmarks_2ebenchOptions_24s1318533244x2074895986_lam4(V self, V *args) {
  V v_x_2440 = args[0];
  V v_time_241 = heff_env(self)[0];
  V v_hd_2438 = heff_env(self)[1];
  V v_count_242 = heff_env(self)[2];
  V v_pattern_240 = heff_env(self)[3];
  V v_k_2439 = heff_env(self)[4];
  V v_json_243 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_2440);
  V v_c_2441 = (g_heff_2ebuild_2ebenchmarks_2etimeGiven_24s1230712360x789314041(v_time_241));
  V f_ = v_c_2441;
  heff_room[0] = heff_dup(v_hd_2438);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ebenchmarks_2ebenchOptions_24s1318533244x2074895986_lam5, 1, 5, (V[]){v_count_242, v_hd_2438, v_pattern_240, v_k_2439, v_json_243});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ebenchmarks_2ebenchOptions_24s1318533244x2074895986_lam3(V self, V *args) {
  V v_hd_2438 = args[0];
  V v_k_2439 = args[1];
  V v_c_2437 = heff_env(self)[0];
  V v_time_241 = heff_env(self)[1];
  V v_count_242 = heff_env(self)[2];
  V v_pattern_240 = heff_env(self)[3];
  V v_json_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_2437;
  args[0] = heff_dup(v_hd_2438);
  args[1] = heff_clo_n(g_heff_2ebuild_2ebenchmarks_2ebenchOptions_24s1318533244x2074895986_lam4, 1, 6, (V[]){v_time_241, v_hd_2438, v_count_242, v_pattern_240, v_k_2439, v_json_243});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2erunListed_24s1367290375x1394144908_str0, 5, "pkg: ");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2erunListed_24s1367290375x1394144908_str1, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2erunListed_24s1367290375x1394144908_str2, 9, "Benchmark");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2erunListed_24s1367290375x1394144908_str3, 9, "Benchmark");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2erunListed_24s1367290375x1394144908_str4, 1, "/");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2erunListed_24s1367290375x1394144908_str5, 6, "FAIL  ");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2erunListed_24s1367290375x1394144908_str6, 6, "ok    ");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2erunListed_24s1367290375x1394144908_str7, 1, "\012");
V g_heff_2ebuild_2ebenchmarks_2erunListed_24s1367290375x1394144908_lam0(V self, V *args); static Clo g_heff_2ebuild_2ebenchmarks_2erunListed_24s1367290375x1394144908_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebenchmarks_2erunListed_24s1367290375x1394144908_lam0, 2, 0};
V g_heff_2ebuild_2ebenchmarks_2erunListed_24s1367290375x1394144908_lam3(V self, V *args); static Clo g_heff_2ebuild_2ebenchmarks_2erunListed_24s1367290375x1394144908_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebenchmarks_2erunListed_24s1367290375x1394144908_lam3, 2, 0};
V g_heff_2ebuild_2ebenchmarks_2erunListed_24s1367290375x1394144908_lam4(V self, V *args);
V g_heff_2ebuild_2ebenchmarks_2erunListed_24s1367290375x1394144908_lam2(V self, V *args);
V g_heff_2ebuild_2ebenchmarks_2erunListed_24s1367290375x1394144908_lam1(V self, V *args);
Clo g_heff_2ebuild_2ebenchmarks_2erunListed_24s1367290375x1394144908_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebenchmarks_2erunListed_24s1367290375x1394144908_entry, 6, 0};

V g_heff_2ebuild_2ebenchmarks_2erunListed_24s1367290375x1394144908(V v_opts_240, V v_f_241, V v_prog_242, V v_bs_243, V v_p_244, V v_p_245) {
top: ;
  switch (heff_tag_of(v_bs_243)) {
  case TAG_Nil: {
    heff_drop_rec(v_opts_240, 4);
    heff_drop(v_f_241);
    heff_drop(v_prog_242);
    heff_drop(v_p_244);
    return heff_tail(v_p_245, 1, (V[]){heff_rec_n(2, shape_ran__failed, (V[]){MK_INT(0LL), MK_INT(0LL)})});
  }
  case TAG_Cons: {
    V v_t_248 = heff_dup(heff_rfield(v_opts_240, 3));
    V v_t_2419;
    if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
      heff_drop(v_t_248);
      v_t_2419 = ((V)&g_heff_2ebuild_2ebenchmarks_2erunListed_24s1367290375x1394144908_lam0_clo);
    } else {
      heff_drop(v_t_248);
      V v_t_2411 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ebenchmarks_2erunListed_24s1367290375x1394144908_str0), heff_dup(v_f_241)), ((V)&g_heff_2ebuild_2ebenchmarks_2erunListed_24s1367290375x1394144908_str1));
      V v_t_2412 = heff_tag_n(TAG_Write, 2, (V[]){v_t_2411, NTAG(TAG_MkUnit)});
      V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
      V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
      V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
      V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
      V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
      V v_t_2418 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2417})});
      v_t_2419 = heff_tr(heff_call(((V)&g_co_2eop_24s22628809x1035315751_clo), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2418})}));
    }
    return heff_tail(v_t_2419, 2, (V[]){heff_dup(v_p_244), heff_clo_n(g_heff_2ebuild_2ebenchmarks_2erunListed_24s1367290375x1394144908_lam1, 1, 6, (V[]){v_bs_243, v_opts_240, v_f_241, v_prog_242, v_p_244, v_p_245})});
  }
  default: return heff_nomatch(v_bs_243);
  }
}
V g_heff_2ebuild_2ebenchmarks_2erunListed_24s1367290375x1394144908_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ebenchmarks_2erunListed_24s1367290375x1394144908(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2ebuild_2ebenchmarks_2erunListed_24s1367290375x1394144908_lam0(V self, V *args) {
  V v_hd_249 = args[0];
  V v_k_2410 = args[1];
  heff_drop(v_hd_249);
  V f_ = v_k_2410;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ebenchmarks_2erunListed_24s1367290375x1394144908_lam3(V self, V *args) {
  V v_hd_2425 = args[0];
  V v_k_2426 = args[1];
  heff_drop(v_hd_2425);
  V f_ = v_k_2426;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ebenchmarks_2erunListed_24s1367290375x1394144908_lam4(V self, V *args) {
  V v_x_2438 = args[0];
  V v_p_245 = heff_env(self)[0];
  V v_x_2423 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2438);
  V f_ = v_p_245;
  args[0] = v_x_2423;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ebenchmarks_2erunListed_24s1367290375x1394144908_lam2(V self, V *args) {
  V v_x_2423 = args[0];
  V v_opts_240 = heff_env(self)[0];
  V v_f_241 = heff_env(self)[1];
  V v_p_244 = heff_env(self)[2];
  V v_p_245 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2424 = heff_get_n(v_opts_240, 3, 4);
  V v_t_2437;
  if ((heff_dup(v_t_2424) == NTAG(TAG_True))) {
    heff_drop(v_f_241);
    heff_drop(v_t_2424);
    v_t_2437 = ((V)&g_heff_2ebuild_2ebenchmarks_2erunListed_24s1367290375x1394144908_lam3_clo);
  } else {
    heff_drop(v_t_2424);
    V v_t_2428;
    if (heff_intLt_c(MK_INT(0LL), heff_dup(heff_rfield(v_x_2423, 1)))) {
      v_t_2428 = ((V)&g_heff_2ebuild_2ebenchmarks_2erunListed_24s1367290375x1394144908_str5);
    } else {
      v_t_2428 = ((V)&g_heff_2ebuild_2ebenchmarks_2erunListed_24s1367290375x1394144908_str6);
    }
    V v_t_2429 = heff_strAppend(heff_strAppend(v_t_2428, v_f_241), ((V)&g_heff_2ebuild_2ebenchmarks_2erunListed_24s1367290375x1394144908_str7));
    V v_t_2430 = heff_tag_n(TAG_Write, 2, (V[]){v_t_2429, NTAG(TAG_MkUnit)});
    V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
    V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
    V v_t_2433 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2432})});
    V v_t_2434 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2433})});
    V v_t_2435 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2434})});
    V v_t_2436 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2435})});
    v_t_2437 = heff_tr(heff_call(((V)&g_co_2eop_24s22628809x1035315751_clo), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2436})}));
  }
  V f_ = v_t_2437;
  heff_room[0] = v_p_244;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ebenchmarks_2erunListed_24s1367290375x1394144908_lam4, 1, 2, (V[]){v_p_245, v_x_2423});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ebenchmarks_2erunListed_24s1367290375x1394144908_lam1(V self, V *args) {
  V v_x_2420 = args[0];
  V v_bs_243 = heff_env(self)[0];
  V v_opts_240 = heff_env(self)[1];
  V v_f_241 = heff_env(self)[2];
  V v_prog_242 = heff_env(self)[3];
  V v_p_244 = heff_env(self)[4];
  V v_p_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_2420);
  V v_t_2421 = (g_list_2efoldl_24s778605472x971322441(((V)&g_heff_2ebuild_2ebenchmarks_2erunListed_24s1367290375x1394144908_str2), ((V)&g_heff_2ebuild_2ebenchmarks_2erunListed_24s1367290375x1394144908_str3), ((V)&g_heff_2ebuild_2ebenchmarks_2erunListed_24s1367290375x1394144908_str4), MK_INT(0LL), v_bs_243));
  V v_c_2422 = ({ V a_0 = heff_dup(v_opts_240); V a_1 = heff_dup(v_f_241); V a_2 = v_prog_242; V a_3 = v_t_2421; V a_4 = v_bs_243; V a_5 = heff_rec_n(2, shape_ran__failed, (V[]){MK_INT(0LL), MK_INT(0LL)}); V r_ = (g_heff_2ebuild_2ebenchmarks_2erunEach_24s1029322272x552871994(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop_tag(v_bs_243, 2); r_; });
  V f_ = v_c_2422;
  heff_room[0] = heff_dup(v_p_244);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ebenchmarks_2erunListed_24s1367290375x1394144908_lam2, 1, 4, (V[]){v_opts_240, v_f_241, v_p_244, v_p_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2erunBuilt_24s1240224601x352191580_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2erunBuilt_24s1240224601x352191580_str1, 4, "list");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2erunBuilt_24s1240224601x352191580_str2, 36, "its benchmarks could not be listed: ");
V g_heff_2ebuild_2ebenchmarks_2erunBuilt_24s1240224601x352191580_lam0(V self, V *args); static Clo g_heff_2ebuild_2ebenchmarks_2erunBuilt_24s1240224601x352191580_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebenchmarks_2erunBuilt_24s1240224601x352191580_lam0, 1, 0};
V g_heff_2ebuild_2ebenchmarks_2erunBuilt_24s1240224601x352191580_lam2(V self, V *args);
V g_heff_2ebuild_2ebenchmarks_2erunBuilt_24s1240224601x352191580_lam1(V self, V *args);
Clo g_heff_2ebuild_2ebenchmarks_2erunBuilt_24s1240224601x352191580_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebenchmarks_2erunBuilt_24s1240224601x352191580_entry, 3, 0};

V g_heff_2ebuild_2ebenchmarks_2erunBuilt_24s1240224601x352191580(V v_opts_240, V v_f_241, V v_prog_242) {
top: ;
  V v_t_243 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(heff_rfield(v_opts_240, 0)), NTAG(TAG_Nil)});
  V v_t_244 = ({ V b_0 = NTAG(TAG_Nil); V b_1 = NTAG(TAG_Nil); V r_ = (g_std_2epath_2esameSegments(b_0, b_1)); heff_drop(b_0); heff_drop(b_1); r_; });
  V v_t_245;
  if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
    heff_drop(v_t_244);
    v_t_245 = ((V)&g_heff_2ebuild_2ebenchmarks_2erunBuilt_24s1240224601x352191580_str0);
  } else {
    heff_drop(v_t_244);
    v_t_245 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V b_1 = heff_dup(g_std_2epath_2ecurrent_get()); V r_ = (g_std_2epath_2erender(b_0, b_1)); heff_drop(b_0); heff_drop(b_1); r_; });
  }
  V v_t_246 = heff_rec_n(10, shape_command__args__dir__env__input__output__errors__timeout__keep__group, (V[]){heff_dup(v_prog_242), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ebenchmarks_2erunBuilt_24s1240224601x352191580_str1), v_t_243}), v_t_245, NTAG(TAG_Nil), NTAG(TAG_NoInput), NTAG(TAG_Collected), NTAG(TAG_Collected), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_False)});
  V v_a_248 = heff_tag_n(TAG_Run, 2, (V[]){v_t_246, ((V)&g_heff_2ebuild_2ebenchmarks_2erunBuilt_24s1240224601x352191580_lam0_clo)});
  return heff_clo_n(g_heff_2ebuild_2ebenchmarks_2erunBuilt_24s1240224601x352191580_lam1, 2, 4, (V[]){v_a_248, v_opts_240, v_f_241, v_prog_242});
}
V g_heff_2ebuild_2ebenchmarks_2erunBuilt_24s1240224601x352191580_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ebenchmarks_2erunBuilt_24s1240224601x352191580(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2ebenchmarks_2erunBuilt_24s1240224601x352191580_lam0(V self, V *args) {
  V v_r_247 = args[0];
  return v_r_247;
}
V g_heff_2ebuild_2ebenchmarks_2erunBuilt_24s1240224601x352191580_lam2(V self, V *args) {
  V v_x_2417 = args[0];
  V v_opts_240 = heff_env(self)[0];
  V v_f_241 = heff_env(self)[1];
  V v_hd_249 = heff_env(self)[2];
  V v_k_2410 = heff_env(self)[3];
  V v_prog_242 = heff_env(self)[4];
  heff_clo_take(self, 5);
  HeffT2 v_t_2418 = (g_heff_2ebuild_2ebenchmarks_2elistedOf_24cpr(v_x_2417));
  {
    V v_field_2420 = v_t_2418.f[1];
    int64_t v_tag_2419 = ((int64_t)v_t_2418.f[0]);
    if ((v_tag_2419 == ((int64_t)0ULL))) {
      heff_drop(v_prog_242);
      V v_why_2422 = v_field_2420;
      V v_t_2423 = (g_heff_2ebuild_2ebenchmarks_2enotBenched_24s1500087693x194837604(v_opts_240, v_f_241, heff_strAppend(((V)&g_heff_2ebuild_2ebenchmarks_2erunBuilt_24s1240224601x352191580_str2), v_why_2422)));
      V f_ = v_t_2423;
      heff_room[0] = v_hd_249;
      heff_room[1] = v_k_2410;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    } else {
      V v_bs_2424 = v_field_2420;
      return (g_heff_2ebuild_2ebenchmarks_2erunListed_24s1367290375x1394144908(v_opts_240, v_f_241, v_prog_242, v_bs_2424, v_hd_249, v_k_2410));
    }
  }
}
V g_heff_2ebuild_2ebenchmarks_2erunBuilt_24s1240224601x352191580_lam1(V self, V *args) {
  V v_hd_249 = args[0];
  V v_k_2410 = args[1];
  V v_a_248 = heff_env(self)[0];
  V v_opts_240 = heff_env(self)[1];
  V v_f_241 = heff_env(self)[2];
  V v_prog_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_248})});
  V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
  V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
  V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
  V v_t_2416 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2415})});
  return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2416}), heff_dup(v_hd_249), heff_clo_n(g_heff_2ebuild_2ebenchmarks_2erunBuilt_24s1240224601x352191580_lam2, 1, 5, (V[]){v_opts_240, v_f_241, v_hd_249, v_k_2410, v_prog_242})));
}
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2ebenchFile_24s1130874047x1407191497_str0, 4, "heff");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2ebenchFile_24s1130874047x1407191497_str1, 13, ": not checked");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2ebenchFile_24s1130874047x1407191497_str2, 4, "heff");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2ebenchFile_24s1130874047x1407191497_str3, 13, ": not checked");
V g_heff_2ebuild_2ebenchmarks_2ebenchFile_24s1130874047x1407191497_lam2(V self, V *args);
V g_heff_2ebuild_2ebenchmarks_2ebenchFile_24s1130874047x1407191497_lam3(V self, V *args);
V g_heff_2ebuild_2ebenchmarks_2ebenchFile_24s1130874047x1407191497_lam6(V self, V *args);
V g_heff_2ebuild_2ebenchmarks_2ebenchFile_24s1130874047x1407191497_lam5(V self, V *args);
V g_heff_2ebuild_2ebenchmarks_2ebenchFile_24s1130874047x1407191497_lam4(V self, V *args);
V g_heff_2ebuild_2ebenchmarks_2ebenchFile_24s1130874047x1407191497_lam8(V self, V *args);
V g_heff_2ebuild_2ebenchmarks_2ebenchFile_24s1130874047x1407191497_lam7(V self, V *args);
V g_heff_2ebuild_2ebenchmarks_2ebenchFile_24s1130874047x1407191497_lam1(V self, V *args);
V g_heff_2ebuild_2ebenchmarks_2ebenchFile_24s1130874047x1407191497_lam0(V self, V *args);
Clo g_heff_2ebuild_2ebenchmarks_2ebenchFile_24s1130874047x1407191497_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebenchmarks_2ebenchFile_24s1130874047x1407191497_entry, 11, 0};

V g_heff_2ebuild_2ebenchmarks_2ebenchFile_24s1130874047x1407191497(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_rep_245, V v_prog_246, V v_opts_247, V v_f_248, V v_z_249, V v_z_2410) {
top: ;
  V v_c_2411 = (g_heff_2ebuild_2ecommands_2eload_24s81450283x65507788(heff_dup(v_f_248)));
  return heff_tail(v_c_2411, 2, (V[]){heff_dup(v_z_249), heff_clo_n(g_heff_2ebuild_2ebenchmarks_2ebenchFile_24s1130874047x1407191497_lam0, 1, 11, (V[]){v_z_249, v_lit_244, v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_z_2410, v_rep_245, v_prog_246, v_opts_247, v_f_248})});
}
V g_heff_2ebuild_2ebenchmarks_2ebenchFile_24s1130874047x1407191497_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ebenchmarks_2ebenchFile_24s1130874047x1407191497(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8], a[9], a[10]);
}
V g_heff_2ebuild_2ebenchmarks_2ebenchFile_24s1130874047x1407191497_lam2(V self, V *args) {
  V v_o_2426 = args[0];
  V v_c_2420 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2ebuild_2edriver_2eisBenchOwn(v_c_2420, v_o_2426));
}
V g_heff_2ebuild_2ebenchmarks_2ebenchFile_24s1130874047x1407191497_lam3(V self, V *args) {
  V v_a_2433 = args[0];
  V v_z_2434 = args[1];
  V v_z_2435 = args[2];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  V v_lit_242 = heff_env(self)[2];
  V v_lit_243 = heff_env(self)[3];
  V v_lit_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_rep_2436 = v_lit_240;
  V v_prog_2437 = v_lit_241;
  V v_opts_2438 = v_lit_242;
  V v_x2_2439 = v_lit_243;
  V v_t_2440 = heff_intAdd(heff_take_field(v_lit_244, 0), heff_take_field(v_a_2433, 0));
  V v_t_2441 = heff_intAdd(heff_get_n(v_lit_244, 1, 2), heff_get_n(v_a_2433, 1, 2));
  V v_acc_2442 = heff_rec_n(2, shape_ran__failed, (V[]){v_t_2440, v_t_2441});
  switch (heff_tag_of(v_x2_2439)) {
  case TAG_Nil: {
    heff_drop(v_rep_2436);
    heff_drop(v_prog_2437);
    return (g_heff_2ebuild_2ebenchmarks_2ebenchSummary_24s155169312x1036209580(v_opts_2438, v_acc_2442, v_z_2434, v_z_2435));
  }
  case TAG_Cons: {
    V v_f_2443 = heff_field(v_x2_2439, 0);
    V v_rest_2444 = heff_field(v_x2_2439, 1);
    heff_take_n(v_x2_2439, 3ULL, 2);
    return (g_heff_2ebuild_2ebenchmarks_2ebenchFile_24s1130874047x1407191497(heff_dup(v_rep_2436), heff_dup(v_prog_2437), heff_dup(v_opts_2438), v_rest_2444, v_acc_2442, v_rep_2436, v_prog_2437, v_opts_2438, v_f_2443, v_z_2434, v_z_2435));
  }
  default: return heff_nomatch(v_x2_2439);
  }
}
V g_heff_2ebuild_2ebenchmarks_2ebenchFile_24s1130874047x1407191497_lam6(V self, V *args) {
  V v_x_2458 = args[0];
  V v_lit_244 = heff_env(self)[0];
  V v_lit_240 = heff_env(self)[1];
  V v_lit_241 = heff_env(self)[2];
  V v_lit_242 = heff_env(self)[3];
  V v_lit_243 = heff_env(self)[4];
  V v_z_249 = heff_env(self)[5];
  V v_z_2410 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2459 = heff_intAdd(heff_take_field(v_lit_244, 0), heff_take_field(v_x_2458, 0));
  V v_t_2460 = heff_intAdd(heff_get_n(v_lit_244, 1, 2), heff_get_n(v_x_2458, 1, 2));
  return ({ V a_0 = v_lit_240; V a_1 = v_lit_241; V a_2 = v_lit_242; V a_3 = v_lit_243; V a_4 = heff_rec_n(2, shape_ran__failed, (V[]){v_t_2459, v_t_2460}); V a_5 = v_z_249; V a_6 = v_z_2410; V r_ = (g_heff_2ebuild_2ebenchmarks_2ebenchEach_24s2122599649x1048694221(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_lit_243); r_; });
}
V g_heff_2ebuild_2ebenchmarks_2ebenchFile_24s1130874047x1407191497_lam5(V self, V *args) {
  V v_x_2447 = args[0];
  V v_x_2412 = heff_env(self)[0];
  V v_cs_2415 = heff_env(self)[1];
  V v_f_248 = heff_env(self)[2];
  V v_opts_247 = heff_env(self)[3];
  V v_z_249 = heff_env(self)[4];
  V v_lit_244 = heff_env(self)[5];
  V v_lit_240 = heff_env(self)[6];
  V v_lit_241 = heff_env(self)[7];
  V v_lit_242 = heff_env(self)[8];
  V v_lit_243 = heff_env(self)[9];
  V v_z_2410 = heff_env(self)[10];
  heff_clo_take(self, 11);
  heff_drop(v_x_2447);
  V v_t_2448 = heff_get_n(v_x_2412, 1, 5);
  V v_t_2456;
  switch (heff_tag_of(v_t_2448)) {
  case TAG_Nil: {
    HeffT2 v_t_2449 = (g_heff_2ebuild_2ecommands_2efirstErrorOf_24cpr(v_cs_2415));
    {
      V v_field_2451 = v_t_2449.f[1];
      int64_t v_tag_2450 = ((int64_t)v_t_2449.f[0]);
      if ((v_tag_2450 == ((int64_t)0ULL))) {
        V v_x_2453 = v_field_2451;
        v_t_2456 = v_x_2453;
      } else {
        heff_drop(v_field_2451);
        v_t_2456 = heff_strAppend(heff_dup(v_f_248), ((V)&g_heff_2ebuild_2ebenchmarks_2ebenchFile_24s1130874047x1407191497_str1));
      }
    }
    break;
  }
  case TAG_Cons: {
    V v_why_2454 = heff_field(v_t_2448, 0);
    heff_take_n(v_t_2448, 1ULL, 2);
    heff_drop(v_cs_2415);
    v_t_2456 = v_why_2454;
    break;
  }
  default: heff_nomatch(v_t_2448);
  }
  V v_c_2457 = (g_heff_2ebuild_2ebenchmarks_2enotBenched_24s1500087693x194837604(v_opts_247, v_f_248, v_t_2456));
  V f_ = v_c_2457;
  heff_room[0] = heff_dup(v_z_249);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ebenchmarks_2ebenchFile_24s1130874047x1407191497_lam6, 1, 7, (V[]){v_lit_244, v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_z_249, v_z_2410});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ebenchmarks_2ebenchFile_24s1130874047x1407191497_lam4(V self, V *args) {
  V v_x_2445 = args[0];
  V v_cs_2415 = heff_env(self)[0];
  V v_z_249 = heff_env(self)[1];
  V v_x_2412 = heff_env(self)[2];
  V v_f_248 = heff_env(self)[3];
  V v_opts_247 = heff_env(self)[4];
  V v_lit_244 = heff_env(self)[5];
  V v_lit_240 = heff_env(self)[6];
  V v_lit_241 = heff_env(self)[7];
  V v_lit_242 = heff_env(self)[8];
  V v_lit_243 = heff_env(self)[9];
  V v_z_2410 = heff_env(self)[10];
  heff_clo_take(self, 11);
  heff_drop(v_x_2445);
  V v_c_2446 = (g_heff_2ebuild_2ecommands_2ediagCount_24s920027481x727902174(v_cs_2415));
  V f_ = v_c_2446;
  heff_room[0] = heff_dup(v_z_249);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ebenchmarks_2ebenchFile_24s1130874047x1407191497_lam5, 1, 11, (V[]){v_x_2412, v_cs_2415, v_f_248, v_opts_247, v_z_249, v_lit_244, v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_z_2410});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ebenchmarks_2ebenchFile_24s1130874047x1407191497_lam8(V self, V *args) {
  V v_x_2472 = args[0];
  V v_lit_244 = heff_env(self)[0];
  V v_lit_240 = heff_env(self)[1];
  V v_lit_241 = heff_env(self)[2];
  V v_lit_242 = heff_env(self)[3];
  V v_lit_243 = heff_env(self)[4];
  V v_z_249 = heff_env(self)[5];
  V v_z_2410 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2473 = heff_intAdd(heff_take_field(v_lit_244, 0), heff_take_field(v_x_2472, 0));
  V v_t_2474 = heff_intAdd(heff_get_n(v_lit_244, 1, 2), heff_get_n(v_x_2472, 1, 2));
  return ({ V a_0 = v_lit_240; V a_1 = v_lit_241; V a_2 = v_lit_242; V a_3 = v_lit_243; V a_4 = heff_rec_n(2, shape_ran__failed, (V[]){v_t_2473, v_t_2474}); V a_5 = v_z_249; V a_6 = v_z_2410; V r_ = (g_heff_2ebuild_2ebenchmarks_2ebenchEach_24s2122599649x1048694221(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_lit_243); r_; });
}
V g_heff_2ebuild_2ebenchmarks_2ebenchFile_24s1130874047x1407191497_lam7(V self, V *args) {
  V v_x_2461 = args[0];
  V v_x_2412 = heff_env(self)[0];
  V v_cs_2415 = heff_env(self)[1];
  V v_f_248 = heff_env(self)[2];
  V v_opts_247 = heff_env(self)[3];
  V v_z_249 = heff_env(self)[4];
  V v_lit_244 = heff_env(self)[5];
  V v_lit_240 = heff_env(self)[6];
  V v_lit_241 = heff_env(self)[7];
  V v_lit_242 = heff_env(self)[8];
  V v_lit_243 = heff_env(self)[9];
  V v_z_2410 = heff_env(self)[10];
  heff_clo_take(self, 11);
  heff_drop(v_x_2461);
  V v_t_2462 = heff_get_n(v_x_2412, 1, 5);
  V v_t_2470;
  switch (heff_tag_of(v_t_2462)) {
  case TAG_Nil: {
    HeffT2 v_t_2463 = (g_heff_2ebuild_2ecommands_2efirstErrorOf_24cpr(v_cs_2415));
    {
      V v_field_2465 = v_t_2463.f[1];
      int64_t v_tag_2464 = ((int64_t)v_t_2463.f[0]);
      if ((v_tag_2464 == ((int64_t)0ULL))) {
        V v_x_2467 = v_field_2465;
        v_t_2470 = v_x_2467;
      } else {
        heff_drop(v_field_2465);
        v_t_2470 = heff_strAppend(heff_dup(v_f_248), ((V)&g_heff_2ebuild_2ebenchmarks_2ebenchFile_24s1130874047x1407191497_str3));
      }
    }
    break;
  }
  case TAG_Cons: {
    V v_why_2468 = heff_field(v_t_2462, 0);
    heff_take_n(v_t_2462, 1ULL, 2);
    heff_drop(v_cs_2415);
    v_t_2470 = v_why_2468;
    break;
  }
  default: heff_nomatch(v_t_2462);
  }
  V v_c_2471 = (g_heff_2ebuild_2ebenchmarks_2enotBenched_24s1500087693x194837604(v_opts_247, v_f_248, v_t_2470));
  V f_ = v_c_2471;
  heff_room[0] = heff_dup(v_z_249);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ebenchmarks_2ebenchFile_24s1130874047x1407191497_lam8, 1, 7, (V[]){v_lit_244, v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_z_249, v_z_2410});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ebenchmarks_2ebenchFile_24s1130874047x1407191497_lam1(V self, V *args) {
  V v_x_2414 = args[0];
  V v_x_2412 = heff_env(self)[0];
  V v_lit_244 = heff_env(self)[1];
  V v_lit_240 = heff_env(self)[2];
  V v_lit_241 = heff_env(self)[3];
  V v_lit_242 = heff_env(self)[4];
  V v_lit_243 = heff_env(self)[5];
  V v_z_249 = heff_env(self)[6];
  V v_z_2410 = heff_env(self)[7];
  V v_rep_245 = heff_env(self)[8];
  V v_prog_246 = heff_env(self)[9];
  V v_opts_247 = heff_env(self)[10];
  V v_f_248 = heff_env(self)[11];
  heff_clo_take(self, 12);
  V v_cs_2415 = heff_get_n(v_x_2414, 0, 2);
  HeffT2 v_t_2416 = (g_heff_2ebuild_2edriver_2elastChecked_24cpr(heff_dup(v_cs_2415)));
  {
    V v_field_2418 = v_t_2416.f[1];
    int64_t v_tag_2417 = ((int64_t)v_t_2416.f[0]);
    if ((v_tag_2417 == ((int64_t)0ULL))) {
      V v_c_2420 = v_field_2418;
      V v_t_2421 = heff_dup(heff_rfield(v_x_2412, 1));
      V v_t_2425;
      switch (heff_tag_of(v_t_2421)) {
      case TAG_Nil: {
        V v_x1_2422 = (g_list_2eany_24s469495312x865582084(v_cs_2415));
        v_t_2425 = heff_bool(!(heff_dup(v_x1_2422) == NTAG(TAG_True)));
        heff_drop(v_x1_2422);
        break;
      }
      case TAG_Cons: {
        heff_take_n(v_t_2421, 0ULL, 2);
        v_t_2425 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_t_2421);
      }
      if ((heff_dup(v_t_2425) == NTAG(TAG_True))) {
        heff_drop(v_cs_2415);
        heff_drop(v_t_2425);
        V v_t_2427 = (g_list_2efilter(heff_clo_n(g_heff_2ebuild_2ebenchmarks_2ebenchFile_24s1130874047x1407191497_lam2, 1, 1, (V[]){heff_dup(v_c_2420)}), heff_dup(heff_rfield(v_c_2420, 7))));
        V v_x1_2428 = (g_heff_2ebuild_2edriver_2erootsAmong(heff_dup(v_c_2420), v_t_2427));
        switch (heff_tag_of(v_x1_2428)) {
        case TAG_Nil: {
          heff_drop_rec(v_x_2412, 5);
          heff_drop(v_rep_245);
          heff_drop(v_prog_246);
          heff_drop(v_opts_247);
          heff_drop(v_f_248);
          heff_drop_rec(v_c_2420, 14);
          V v_t_2429 = heff_intAdd(heff_take_field(v_lit_244, 0), MK_INT(0LL));
          V v_t_2430 = heff_intAdd(heff_get_n(v_lit_244, 1, 2), MK_INT(0LL));
          return ({ V a_0 = v_lit_240; V a_1 = v_lit_241; V a_2 = v_lit_242; V a_3 = v_lit_243; V a_4 = heff_rec_n(2, shape_ran__failed, (V[]){v_t_2429, v_t_2430}); V a_5 = v_z_249; V a_6 = v_z_2410; V r_ = (g_heff_2ebuild_2ebenchmarks_2ebenchEach_24s2122599649x1048694221(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_lit_243); r_; });
        }
        case TAG_Cons: {
          heff_take_n(v_x1_2428, 0ULL, 2);
          return (g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s1238445759x439245818(v_rep_245, v_prog_246, v_opts_247, v_f_248, v_x_2412, v_c_2420, heff_clo_n(g_heff_2ebuild_2ebenchmarks_2ebenchFile_24s1130874047x1407191497_lam3, 3, 5, (V[]){v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_lit_244}), v_z_249, v_z_2410));
        }
        default: return heff_nomatch(v_x1_2428);
        }
      } else {
        heff_drop(v_rep_245);
        heff_drop(v_prog_246);
        heff_drop_rec(v_c_2420, 14);
        heff_drop(v_t_2425);
        return (g_heff_2ebuild_2ecommands_2eprintErrs_24s2072048709x1630503544(((V)&g_heff_2ebuild_2ebenchmarks_2ebenchFile_24s1130874047x1407191497_str0), heff_dup(heff_rfield(v_x_2412, 1)), MK_INT(0LL), heff_dup(v_z_249), heff_clo_n(g_heff_2ebuild_2ebenchmarks_2ebenchFile_24s1130874047x1407191497_lam4, 1, 11, (V[]){v_cs_2415, v_z_249, v_x_2412, v_f_248, v_opts_247, v_lit_244, v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_z_2410})));
      }
    } else {
      heff_drop(v_rep_245);
      heff_drop(v_prog_246);
      heff_drop(v_field_2418);
      return (g_heff_2ebuild_2ecommands_2eprintErrs_24s2072048709x1630503544(((V)&g_heff_2ebuild_2ebenchmarks_2ebenchFile_24s1130874047x1407191497_str2), heff_dup(heff_rfield(v_x_2412, 1)), MK_INT(0LL), heff_dup(v_z_249), heff_clo_n(g_heff_2ebuild_2ebenchmarks_2ebenchFile_24s1130874047x1407191497_lam7, 1, 11, (V[]){v_x_2412, v_cs_2415, v_f_248, v_opts_247, v_z_249, v_lit_244, v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_z_2410})));
    }
  }
}
V g_heff_2ebuild_2ebenchmarks_2ebenchFile_24s1130874047x1407191497_lam0(V self, V *args) {
  V v_x_2412 = args[0];
  V v_z_249 = heff_env(self)[0];
  V v_lit_244 = heff_env(self)[1];
  V v_lit_240 = heff_env(self)[2];
  V v_lit_241 = heff_env(self)[3];
  V v_lit_242 = heff_env(self)[4];
  V v_lit_243 = heff_env(self)[5];
  V v_z_2410 = heff_env(self)[6];
  V v_rep_245 = heff_env(self)[7];
  V v_prog_246 = heff_env(self)[8];
  V v_opts_247 = heff_env(self)[9];
  V v_f_248 = heff_env(self)[10];
  heff_clo_take(self, 11);
  V v_c_2413 = (g_heff_2ebuild_2esession_2ecachedAcc_24s1931332253x1949976425(heff_dup(v_x_2412)));
  V f_ = v_c_2413;
  heff_room[0] = heff_dup(v_z_249);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ebenchmarks_2ebenchFile_24s1130874047x1407191497_lam1, 1, 12, (V[]){v_x_2412, v_lit_244, v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_z_249, v_z_2410, v_rep_245, v_prog_246, v_opts_247, v_f_248});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
Clo g_heff_2ebuild_2ebenchmarks_2ebenchEach_24s2122599649x1048694221_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebenchmarks_2ebenchEach_24s2122599649x1048694221_entry, 7, 0};

V g_heff_2ebuild_2ebenchmarks_2ebenchEach_24s2122599649x1048694221(V v_rep_240, V v_prog_241, V v_opts_242, V v_x2_243, V v_acc_244, V v_z_245, V v_z_246) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_rep_240);
    heff_drop(v_prog_241);
    return (g_heff_2ebuild_2ebenchmarks_2ebenchSummary_24s155169312x1036209580(v_opts_242, v_acc_244, v_z_245, v_z_246));
  }
  case TAG_Cons: {
    V v_f_247 = heff_field(v_x2_243, 0);
    V v_rest_248 = heff_field(v_x2_243, 1);
    return (g_heff_2ebuild_2ebenchmarks_2ebenchFile_24s1130874047x1407191497(heff_dup(v_rep_240), heff_dup(v_prog_241), heff_dup(v_opts_242), heff_dup(v_rest_248), v_acc_244, v_rep_240, v_prog_241, v_opts_242, heff_dup(v_f_247), v_z_245, v_z_246));
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_heff_2ebuild_2ebenchmarks_2ebenchEach_24s2122599649x1048694221_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2ebuild_2ebenchmarks_2ebenchEach_24s2122599649x1048694221(a[0], a[1], a[2], a3, a[4], a[5], a[6]); heff_drop(a3); return r;
}