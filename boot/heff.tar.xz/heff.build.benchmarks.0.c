// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Collected 38917
#define TAG_End 17255
#define TAG_Exit 20279
#define TAG_Exited 20560
#define TAG_FailedWith 25914
#define TAG_JArray 50516
#define TAG_JBool 39030
#define TAG_JFloat 30719
#define TAG_JInt 58696
#define TAG_JNull 9039
#define TAG_JObject 38239
#define TAG_JString 41091
#define TAG_Left 13886
#define TAG_Measured 52135
#define TAG_Nanos 3335
#define TAG_NoInput 41055
#define TAG_NotRun 12703
#define TAG_Posix 44191
#define TAG_RealPath 18882
#define TAG_Right 62770
#define TAG_Run 29975
#define TAG_Signalled 34337
#define TAG_SkippedWith 54656
#define TAG_Start 63542
#define TAG_TimedOut 6056
#define TAG_Times 15230
#define TAG_Value 50841
#define TAG_Windows 49101
#define TAG_Write 36323
#define TAG_WriteErr 37283
#define LBL_args 9498020
#define LBL_bind 9519364
#define LBL_command 1182252425
#define LBL_count 296209705
#define LBL_dir 308999
#define LBL_done 9584713
#define LBL_ended 298010324
#define LBL_env 310119
#define LBL_errors 652506774
#define LBL_failed 665164648
#define LBL_group 299987609
#define LBL_implicit 319715269
#define LBL_input 301716452
#define LBL_json 9767343
#define LBL_keep 9783372
#define LBL_malg 9839318
#define LBL_module 878357911
#define LBL_out 319944
#define LBL_output 941629484
#define LBL_package 1572278921
#define LBL_packages 1496006433
#define LBL_paths 307797256
#define LBL_ran 322201
#define LBL_renames 1324191545
#define LBL_root 10001833
#define LBL_source 1050636102
#define LBL_sources 357464573
#define LBL_style 311138763
#define LBL_time 10055572
#define LBL_timeout 1065429926
static uint32_t shape_command__args__dir__env__input__output__errors__timeout__keep__group[] = {LBL_command, LBL_args, LBL_dir, LBL_env, LBL_input, LBL_output, LBL_errors, LBL_timeout, LBL_keep, LBL_group};
static uint32_t shape_ran__failed[] = {LBL_ran, LBL_failed};
static uint32_t shape_sources__errors__paths__package__packages[] = {LBL_sources, LBL_errors, LBL_paths, LBL_package, LBL_packages};
V g_co_2eop_24s615738393x1686646143(V, V, V);
V g_co_2eop_24s615738393x1686646143_entry(V self, V *a);
extern Clo g_co_2eop_24s615738393x1686646143_clo;
V g_co_2eop_24s615738393x1686646143_24tok1(V, V, V, V);
V g_co_2eop_24s615738393x1686646143_24tok1_entry(V self, V *a);
extern Clo g_co_2eop_24s615738393x1686646143_24tok1_clo;
V g_co_2eop_24s615738393x1686646143_24tok2(V, V, V, V);
V g_co_2eop_24s615738393x1686646143_24tok2_entry(V self, V *a);
extern Clo g_co_2eop_24s615738393x1686646143_24tok2_clo;
V g_co_2eop_24s747777320x140686263(V, V, V);
V g_co_2eop_24s747777320x140686263_entry(V self, V *a);
extern Clo g_co_2eop_24s747777320x140686263_clo;
V g_co_2eop_24s847889387x1388281137(V, V, V);
V g_co_2eop_24s847889387x1388281137_entry(V self, V *a);
extern Clo g_co_2eop_24s847889387x1388281137_clo;
HeffT2 g_heff_2ebuild_2ebenchmarks_2ebenchAdded_24cpr(V, V, V);
V g_heff_2ebuild_2ebenchmarks_2ebenchDir(V, V);
V g_heff_2ebuild_2ebenchmarks_2ebenchDir_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebenchmarks_2ebenchDir_clo;
V g_heff_2ebuild_2ebenchmarks_2ebenchEach_24s569761754x1094361140(V, V, V, V, V, V, V);
V g_heff_2ebuild_2ebenchmarks_2ebenchEach_24s569761754x1094361140_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebenchmarks_2ebenchEach_24s569761754x1094361140_clo;
V g_heff_2ebuild_2ebenchmarks_2ebenchFile_24s843626549x1899484728(V, V, V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ebenchmarks_2ebenchFile_24s843626549x1899484728_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebenchmarks_2ebenchFile_24s843626549x1899484728_clo;
V g_heff_2ebuild_2ebenchmarks_2ebenchMainName_get(void);
HeffT2 g_heff_2ebuild_2ebenchmarks_2ebenchQualifier_24cpr(V);
V g_heff_2ebuild_2ebenchmarks_2ebenchSummary_24s1621298555x666587532(V, V, V, V);
V g_heff_2ebuild_2ebenchmarks_2ebenchSummary_24s1621298555x666587532_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebenchmarks_2ebenchSummary_24s1621298555x666587532_clo;
V g_heff_2ebuild_2ebenchmarks_2ebenchText(V, V);
V g_heff_2ebuild_2ebenchmarks_2ebenchText_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebenchmarks_2ebenchText_clo;
HeffT2 g_heff_2ebuild_2ebenchmarks_2ebenchTime_24cpr(V);
V g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s885862188x1878351915(V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s885862188x1878351915_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s885862188x1878351915_clo;
V g_heff_2ebuild_2ebenchmarks_2ecapital(V);
V g_heff_2ebuild_2ebenchmarks_2ecapital_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebenchmarks_2ecapital_clo;
V g_heff_2ebuild_2ebenchmarks_2ecountGiven_24s1787086774x1151984647(V);
V g_heff_2ebuild_2ebenchmarks_2ecountGiven_24s1787086774x1151984647_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebenchmarks_2ecountGiven_24s1787086774x1151984647_clo;
V g_heff_2ebuild_2ebenchmarks_2edecimalParts(V, V);
V g_heff_2ebuild_2ebenchmarks_2edecimalParts_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebenchmarks_2edecimalParts_clo;
V g_heff_2ebuild_2ebenchmarks_2edefaultTime_get(void);
HeffT2 g_heff_2ebuild_2ebenchmarks_2edurationOf_24cpr(V, V);
V g_heff_2ebuild_2ebenchmarks_2eendedWhy(V);
V g_heff_2ebuild_2ebenchmarks_2eendedWhy_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebenchmarks_2eendedWhy_clo;
HeffT2 g_heff_2ebuild_2ebenchmarks_2elistedOf_24cpr(V);
V g_heff_2ebuild_2ebenchmarks_2enotBenched_24s1690640086x1508912593(V, V, V);
V g_heff_2ebuild_2ebenchmarks_2enotBenched_24s1690640086x1508912593_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebenchmarks_2enotBenched_24s1690640086x1508912593_clo;
V g_heff_2ebuild_2ebenchmarks_2eoutcomeFields(V);
V g_heff_2ebuild_2ebenchmarks_2eoutcomeFields_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebenchmarks_2eoutcomeFields_clo;
V g_heff_2ebuild_2ebenchmarks_2eoutcomeJson(V, V, V);
V g_heff_2ebuild_2ebenchmarks_2eoutcomeJson_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebenchmarks_2eoutcomeJson_clo;
V g_heff_2ebuild_2ebenchmarks_2eoutcomeOfLine(V);
V g_heff_2ebuild_2ebenchmarks_2eoutcomeOfLine_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebenchmarks_2eoutcomeOfLine_clo;
V g_heff_2ebuild_2ebenchmarks_2eoutcomeOfRan(V);
V g_heff_2ebuild_2ebenchmarks_2eoutcomeOfRan_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebenchmarks_2eoutcomeOfRan_clo;
V g_heff_2ebuild_2ebenchmarks_2eoutcomeText(V, V, V);
V g_heff_2ebuild_2ebenchmarks_2eoutcomeText_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebenchmarks_2eoutcomeText_clo;
V g_heff_2ebuild_2ebenchmarks_2eperOp(V, V);
V g_heff_2ebuild_2ebenchmarks_2eperOp_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebenchmarks_2eperOp_clo;
V g_heff_2ebuild_2ebenchmarks_2eplacesOf(V, V, V);
V g_heff_2ebuild_2ebenchmarks_2eplacesOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebenchmarks_2eplacesOf_clo;
V g_heff_2ebuild_2ebenchmarks_2erunBuilt_24s698375629x1535015491(V, V, V);
V g_heff_2ebuild_2ebenchmarks_2erunBuilt_24s698375629x1535015491_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebenchmarks_2erunBuilt_24s698375629x1535015491_clo;
V g_heff_2ebuild_2ebenchmarks_2erunEach_24s4089150x124991981(V, V, V, V, V, V);
V g_heff_2ebuild_2ebenchmarks_2erunEach_24s4089150x124991981_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebenchmarks_2erunEach_24s4089150x124991981_clo;
V g_heff_2ebuild_2ebenchmarks_2erunListed_24s936792459x264817624(V, V, V, V, V, V);
V g_heff_2ebuild_2ebenchmarks_2erunListed_24s936792459x264817624_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebenchmarks_2erunListed_24s936792459x264817624_clo;
V g_heff_2ebuild_2ebenchmarks_2erunTimes_24s650970993x1258428477(V, V, V, V, V, V, V);
V g_heff_2ebuild_2ebenchmarks_2erunTimes_24s650970993x1258428477_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebenchmarks_2erunTimes_24s650970993x1258428477_clo;
V g_heff_2ebuild_2ebenchmarks_2esaidRun_24s832625301x247770201(V, V, V, V, V);
V g_heff_2ebuild_2ebenchmarks_2esaidRun_24s832625301x247770201_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebenchmarks_2esaidRun_24s832625301x247770201_clo;
V g_heff_2ebuild_2ebenchmarks_2espaced(V);
V g_heff_2ebuild_2ebenchmarks_2espaced_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebenchmarks_2espaced_clo;
V g_heff_2ebuild_2ebenchmarks_2espaces(V);
V g_heff_2ebuild_2ebenchmarks_2espaces_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebenchmarks_2espaces_clo;
V g_heff_2ebuild_2ebenchmarks_2espaces_24acc(V, V);
V g_heff_2ebuild_2ebenchmarks_2espaces_24acc_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebenchmarks_2espaces_24acc_clo;
V g_heff_2ebuild_2ebenchmarks_2etenTo(V);
V g_heff_2ebuild_2ebenchmarks_2etenTo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebenchmarks_2etenTo_clo;
V g_heff_2ebuild_2ebenchmarks_2etimeGiven_24s1598223557x830608042(V);
V g_heff_2ebuild_2ebenchmarks_2etimeGiven_24s1598223557x830608042_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebenchmarks_2etimeGiven_24s1598223557x830608042_clo;
V g_heff_2ebuild_2ebenchmarks_2eunits_get(void);
V g_heff_2ebuild_2ebenchmarks_2ezeroPadded(V, V);
V g_heff_2ebuild_2ebenchmarks_2ezeroPadded_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebenchmarks_2ezeroPadded_clo;
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s896753706x563678558(V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s896753706x563678558_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecLoadedOr_24s896753706x563678558_clo;
V g_heff_2ebuild_2ecommands_2ediagCount_24s823746706x1248851912(V);
V g_heff_2ebuild_2ecommands_2ediagCount_24s823746706x1248851912_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ediagCount_24s823746706x1248851912_clo;
HeffT2 g_heff_2ebuild_2ecommands_2efirstErrorOf_24cpr(V);
V g_heff_2ebuild_2ecommands_2eload_24s1410275656x228048283(V);
V g_heff_2ebuild_2ecommands_2eload_24s1410275656x228048283_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eload_24s1410275656x228048283_clo;
V g_heff_2ebuild_2ecommands_2eprintErrs_24s115117455x797094904(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eprintErrs_24s115117455x797094904_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprintErrs_24s115117455x797094904_clo;
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535(V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535_clo;
V g_heff_2ebuild_2edriver_2ebenchesOf(V);
V g_heff_2ebuild_2edriver_2ebenchesOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ebenchesOf_clo;
HeffT2 g_heff_2ebuild_2edriver_2elastChecked_24cpr(V);
V g_heff_2ebuild_2esession_2ecachedAcc_24s1827793511x304312721(V);
V g_heff_2ebuild_2esession_2ecachedAcc_24s1827793511x304312721_entry(V self, V *a);
extern Clo g_heff_2ebuild_2esession_2ecachedAcc_24s1827793511x304312721_clo;
V g_heff_2esyntax_2eimport_2eimportsOf(V, V);
V g_heff_2esyntax_2eimport_2eimportsOf_entry(V self, V *a);
extern Clo g_heff_2esyntax_2eimport_2eimportsOf_clo;
HeffT4 g_heff_2esyntax_2eimport_2erenamed_24cpr(V, V);
HeffT2 g_json_2eat_24cpr(V, V);
HeffT2 g_json_2esteps_24cpr(V, V);
V g_json_2estringify(V);
V g_json_2estringify_entry(V self, V *a);
extern Clo g_json_2estringify_clo;
V g_list_2eall_24s2093734251x1702493483(V, V, V, V);
V g_list_2eall_24s2093734251x1702493483_entry(V self, V *a);
extern Clo g_list_2eall_24s2093734251x1702493483_clo;
V g_list_2eany_24s1740858080x874135214(V);
V g_list_2eany_24s1740858080x874135214_entry(V self, V *a);
extern Clo g_list_2eany_24s1740858080x874135214_clo;
V g_list_2efind_24s1136367117x833793205(V, V);
V g_list_2efind_24s1136367117x833793205_entry(V self, V *a);
extern Clo g_list_2efind_24s1136367117x833793205_clo;
HeffT2 g_list_2efind_24s4435330x644005164_24cpr(V, V);
V g_list_2efoldl_24f1221993074x1235215335(V, V, V);
V g_list_2efoldl_24f1221993074x1235215335_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1221993074x1235215335_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s141260856x1366916752(V, V, V, V, V);
V g_list_2efoldl_24s141260856x1366916752_entry(V self, V *a);
extern Clo g_list_2efoldl_24s141260856x1366916752_clo;
V g_list_2efoldl_24s680990791x1764841948(V, V, V, V, V, V, V);
V g_list_2efoldl_24s680990791x1764841948_entry(V self, V *a);
extern Clo g_list_2efoldl_24s680990791x1764841948_clo;
V g_list_2emap_24s1681408447x1763680441(V, V, V);
V g_list_2emap_24s1681408447x1763680441_entry(V self, V *a);
extern Clo g_list_2emap_24s1681408447x1763680441_clo;
V g_list_2emap_24s723912745x1713553694(V);
V g_list_2emap_24s723912745x1713553694_entry(V self, V *a);
extern Clo g_list_2emap_24s723912745x1713553694_clo;
V g_list_2emap_24s849938259x51049885(V);
V g_list_2emap_24s849938259x51049885_entry(V self, V *a);
extern Clo g_list_2emap_24s849938259x51049885_clo;
V g_list_2erange(V, V);
V g_list_2erange_entry(V self, V *a);
extern Clo g_list_2erange_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2ejoinWith_2eafter_240_24f591888720x1996727869(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_24f591888720x1996727869_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_24f591888720x1996727869_clo;
V g_prelude_2eparseInt(V);
V g_prelude_2eparseInt_entry(V self, V *a);
extern Clo g_prelude_2eparseInt_clo;
HeffT2 g_prelude_2eparseInt_24cpr(V);
V g_prelude_2esplitFrom(V, V, V, V, V);
V g_prelude_2esplitFrom_entry(V self, V *a);
extern Clo g_prelude_2esplitFrom_clo;
V g_std_2efilesystem_2efromSystem_24s1003849434x1875331781(V);
V g_std_2efilesystem_2efromSystem_24s1003849434x1875331781_entry(V self, V *a);
extern Clo g_std_2efilesystem_2efromSystem_24s1003849434x1875331781_clo;
V g_std_2epath_2ecurrent_get(void);
V g_std_2epath_2ejoin(V, V);
V g_std_2epath_2ejoin_entry(V self, V *a);
extern Clo g_std_2epath_2ejoin_clo;
V g_std_2epath_2enative_get(void);
V g_std_2epath_2eparse(V, V);
V g_std_2epath_2eparse_entry(V self, V *a);
extern Clo g_std_2epath_2eparse_clo;
HeffT3 g_std_2epath_2eparse_24cpr(V, V);
V g_std_2epath_2erender(V, V);
V g_std_2epath_2erender_entry(V self, V *a);
extern Clo g_std_2epath_2erender_clo;
V g_std_2epath_2esameSegments(V, V);
V g_std_2epath_2esameSegments_entry(V self, V *a);
extern Clo g_std_2epath_2esameSegments_clo;
V g_std_2eprogress_2eroot_get(void);
Clo g_heff_2ebuild_2ebenchmarks_2etenTo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebenchmarks_2etenTo_entry, 1, 0};

V g_heff_2ebuild_2ebenchmarks_2etenTo(V v_k_240) {
top: ;
  if (heff_intLe_c_lent(v_k_240, MK_INT(0LL), 2)) {
    heff_drop(v_k_240);
    return MK_INT(1LL);
  } else {
    V v_t_241 = (g_heff_2ebuild_2ebenchmarks_2etenTo(heff_intSub(v_k_240, MK_INT(1LL))));
    return heff_intMul(MK_INT(10LL), v_t_241);
  }
}
V g_heff_2ebuild_2ebenchmarks_2etenTo_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ebenchmarks_2etenTo(a[0]);
}
V g_heff_2ebuild_2ebenchmarks_2edecimalParts_lam0(V self, V *args);
V g_heff_2ebuild_2ebenchmarks_2edecimalParts_lam1(V self, V *args); static Clo g_heff_2ebuild_2ebenchmarks_2edecimalParts_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebenchmarks_2edecimalParts_lam1, 2, 0};
V g_heff_2ebuild_2ebenchmarks_2edecimalParts_lam2(V self, V *args); static Clo g_heff_2ebuild_2ebenchmarks_2edecimalParts_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebenchmarks_2edecimalParts_lam2, 2, 0};
V g_heff_2ebuild_2ebenchmarks_2edecimalParts_lam3(V self, V *args);
V g_heff_2ebuild_2ebenchmarks_2edecimalParts_lam4(V self, V *args); static Clo g_heff_2ebuild_2ebenchmarks_2edecimalParts_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebenchmarks_2edecimalParts_lam4, 2, 0};
V g_heff_2ebuild_2ebenchmarks_2edecimalParts_lam5(V self, V *args); static Clo g_heff_2ebuild_2ebenchmarks_2edecimalParts_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebenchmarks_2edecimalParts_lam5, 2, 0};
Clo g_heff_2ebuild_2ebenchmarks_2edecimalParts_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebenchmarks_2edecimalParts_entry, 2, 0};

V g_heff_2ebuild_2ebenchmarks_2edecimalParts(V v_unit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_unit_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_w_242 = heff_field(v_x2_241, 0);
    V v_x22_243 = heff_field(v_x2_241, 1);
    switch (heff_tag_of(v_x22_243)) {
    case TAG_Nil: {
      V v_t_2421;
      if ((((int64_t)0ULL) < heff_unbox_word(heff_strLength_lent(v_w_242, 0)))) {
        int64_t v_t_244 = (heff_unbox_word(heff_strLength_lent(v_w_242, 0)) - ((int64_t)1ULL));
        V v_t_245 = (g_list_2erange(MK_INT(0LL), heff_box_word(v_t_244)));
        V v_t_246 = ({ V a_0 = MK_INT(48LL); V a_1 = v_w_242; V a_2 = MK_INT(57LL); V a_3 = v_t_245; V r_ = (g_list_2eall_24s2093734251x1702493483(a_0, a_1, a_2, a_3)); heff_drop(v_t_245); r_; });
        if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
          heff_drop(v_t_246);
          HeffT2 v_t_247 = (g_prelude_2eparseInt_24cpr(v_w_242));
          {
            V v_field_249 = v_t_247.f[1];
            V v_tag_248 = heff_box_i64(((int64_t)v_t_247.f[0]));
            v_t_2421 = heff_clo_n(g_heff_2ebuild_2ebenchmarks_2edecimalParts_lam0, 2, 3, (V[]){v_tag_248, v_field_249, v_unit_240});
          }
        } else {
          heff_drop(v_unit_240);
          heff_drop(v_t_246);
          v_t_2421 = ((V)&g_heff_2ebuild_2ebenchmarks_2edecimalParts_lam1_clo);
        }
      } else {
        heff_drop(v_unit_240);
        v_t_2421 = ((V)&g_heff_2ebuild_2ebenchmarks_2edecimalParts_lam2_clo);
      }
      return heff_tail(v_t_2421, 2, (V[]){heff_tag_n(TAG_Just, 1, (V[]){MK_INT(0LL)}), MK_INT(0LL)});
    }
    case TAG_Cons: {
      V v_f_2422 = heff_field(v_x22_243, 0);
      V v_x222_2423 = heff_field(v_x22_243, 1);
      switch (heff_tag_of(v_x222_2423)) {
      case TAG_Nil: {
        V v_t_2441;
        if ((((int64_t)0ULL) < heff_unbox_word(heff_strLength_lent(v_w_242, 0)))) {
          int64_t v_t_2424 = (heff_unbox_word(heff_strLength_lent(v_w_242, 0)) - ((int64_t)1ULL));
          V v_t_2425 = (g_list_2erange(MK_INT(0LL), heff_box_word(v_t_2424)));
          V v_t_2426 = ({ V a_0 = MK_INT(48LL); V a_1 = v_w_242; V a_2 = MK_INT(57LL); V a_3 = v_t_2425; V r_ = (g_list_2eall_24s2093734251x1702493483(a_0, a_1, a_2, a_3)); heff_drop(v_t_2425); r_; });
          if ((heff_dup(v_t_2426) == NTAG(TAG_True))) {
            heff_drop(v_t_2426);
            HeffT2 v_t_2427 = (g_prelude_2eparseInt_24cpr(v_w_242));
            {
              V v_field_2429 = v_t_2427.f[1];
              V v_tag_2428 = heff_box_i64(((int64_t)v_t_2427.f[0]));
              v_t_2441 = heff_clo_n(g_heff_2ebuild_2ebenchmarks_2edecimalParts_lam3, 2, 3, (V[]){v_tag_2428, v_field_2429, v_unit_240});
            }
          } else {
            heff_drop(v_unit_240);
            heff_drop(v_t_2426);
            v_t_2441 = ((V)&g_heff_2ebuild_2ebenchmarks_2edecimalParts_lam4_clo);
          }
        } else {
          heff_drop(v_unit_240);
          v_t_2441 = ((V)&g_heff_2ebuild_2ebenchmarks_2edecimalParts_lam5_clo);
        }
        V v_t_2445;
        if ((((int64_t)0ULL) < heff_unbox_word(heff_strLength_lent(v_f_2422, 0)))) {
          int64_t v_t_2442 = (heff_unbox_word(heff_strLength_lent(v_f_2422, 0)) - ((int64_t)1ULL));
          V v_t_2443 = (g_list_2erange(MK_INT(0LL), heff_box_word(v_t_2442)));
          V v_t_2444 = ({ V a_0 = MK_INT(48LL); V a_1 = v_f_2422; V a_2 = MK_INT(57LL); V a_3 = v_t_2443; V r_ = (g_list_2eall_24s2093734251x1702493483(a_0, a_1, a_2, a_3)); heff_drop(v_t_2443); r_; });
          if ((heff_dup(v_t_2444) == NTAG(TAG_True))) {
            heff_drop(v_t_2444);
            v_t_2445 = (g_prelude_2eparseInt(v_f_2422));
          } else {
            heff_drop(v_t_2444);
            v_t_2445 = NTAG(TAG_Nothing);
          }
        } else {
          v_t_2445 = NTAG(TAG_Nothing);
        }
        return heff_tail(v_t_2441, 2, (V[]){v_t_2445, heff_strLength_lent(v_f_2422, 0)});
      }
      case TAG_Cons: {
        heff_drop(v_unit_240);
        return NTAG(TAG_Nothing);
      }
      default: return heff_nomatch(v_x222_2423);
      }
    }
    default: return heff_nomatch(v_x22_243);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2ebenchmarks_2edecimalParts_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2ebenchmarks_2edecimalParts(a[0], a1); heff_drop(a1); return r;
}
V g_heff_2ebuild_2ebenchmarks_2edecimalParts_lam0(V self, V *args) {
  V v_x3_2410 = args[0];
  V v_places_2411 = args[1];
  V v_tag_248 = heff_env(self)[0];
  V v_field_249 = heff_env(self)[1];
  V v_unit_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  if ((heff_unbox_i64(v_tag_248) == ((int64_t)0ULL))) {
    V v_w_2412 = v_field_249;
    switch (heff_tag_of(v_x3_2410)) {
    case TAG_Nothing: {
      heff_drop(v_places_2411);
      heff_drop(v_unit_240);
      heff_drop(v_w_2412);
      return NTAG(TAG_Nothing);
    }
    case TAG_Just: {
      V v_f_2413 = heff_field(v_x3_2410, 0);
      V v_ru_24x3_2410_24Just = heff_take_reuse_n(v_x3_2410, 1ULL, 1);
      V v_t_2414 = (g_heff_2ebuild_2ebenchmarks_2etenTo(v_places_2411));
      V v_t_2415 = heff_intDiv(heff_intMul(v_f_2413, heff_dup(v_unit_240)), v_t_2414);
      V v_t_2416 = heff_intAdd(heff_intMul(v_w_2412, v_unit_240), v_t_2415);
      return heff_tag_at_n(v_ru_24x3_2410_24Just, TAG_Just, 1, (V[]){v_t_2416});
    }
    default: return heff_nomatch(v_x3_2410);
    }
  } else {
    heff_drop(v_x3_2410);
    heff_drop(v_places_2411);
    heff_drop(v_field_249);
    heff_drop(v_unit_240);
    return NTAG(TAG_Nothing);
  }
}
V g_heff_2ebuild_2ebenchmarks_2edecimalParts_lam1(V self, V *args) {
  V v_x3_2417 = args[0];
  V v_places_2418 = args[1];
  heff_drop(v_x3_2417);
  heff_drop(v_places_2418);
  return NTAG(TAG_Nothing);
}
V g_heff_2ebuild_2ebenchmarks_2edecimalParts_lam2(V self, V *args) {
  V v_x3_2419 = args[0];
  V v_places_2420 = args[1];
  heff_drop(v_x3_2419);
  heff_drop(v_places_2420);
  return NTAG(TAG_Nothing);
}
V g_heff_2ebuild_2ebenchmarks_2edecimalParts_lam3(V self, V *args) {
  V v_x3_2430 = args[0];
  V v_places_2431 = args[1];
  V v_tag_2428 = heff_env(self)[0];
  V v_field_2429 = heff_env(self)[1];
  V v_unit_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  if ((heff_unbox_i64(v_tag_2428) == ((int64_t)0ULL))) {
    V v_w_2432 = v_field_2429;
    switch (heff_tag_of(v_x3_2430)) {
    case TAG_Nothing: {
      heff_drop(v_places_2431);
      heff_drop(v_unit_240);
      heff_drop(v_w_2432);
      return NTAG(TAG_Nothing);
    }
    case TAG_Just: {
      V v_f_2433 = heff_field(v_x3_2430, 0);
      V v_ru_24x3_2430_24Just = heff_take_reuse_n(v_x3_2430, 1ULL, 1);
      V v_t_2434 = (g_heff_2ebuild_2ebenchmarks_2etenTo(v_places_2431));
      V v_t_2435 = heff_intDiv(heff_intMul(v_f_2433, heff_dup(v_unit_240)), v_t_2434);
      V v_t_2436 = heff_intAdd(heff_intMul(v_w_2432, v_unit_240), v_t_2435);
      return heff_tag_at_n(v_ru_24x3_2430_24Just, TAG_Just, 1, (V[]){v_t_2436});
    }
    default: return heff_nomatch(v_x3_2430);
    }
  } else {
    heff_drop(v_x3_2430);
    heff_drop(v_places_2431);
    heff_drop(v_field_2429);
    heff_drop(v_unit_240);
    return NTAG(TAG_Nothing);
  }
}
V g_heff_2ebuild_2ebenchmarks_2edecimalParts_lam4(V self, V *args) {
  V v_x3_2437 = args[0];
  V v_places_2438 = args[1];
  heff_drop(v_x3_2437);
  heff_drop(v_places_2438);
  return NTAG(TAG_Nothing);
}
V g_heff_2ebuild_2ebenchmarks_2edecimalParts_lam5(V self, V *args) {
  V v_x3_2439 = args[0];
  V v_places_2440 = args[1];
  heff_drop(v_x3_2439);
  heff_drop(v_places_2440);
  return NTAG(TAG_Nothing);
}
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2ebenchTime_24cpr_str0, 1, "x");

HeffT2 g_heff_2ebuild_2ebenchmarks_2ebenchTime_24cpr(V v_s_240) {
top: ;
  int64_t v_t_241 = (heff_unbox_word(heff_strLength_lent(v_s_240, 0)) - ((int64_t)1ULL));
  V v_t_242 = heff_strSlice(heff_dup(v_s_240), heff_box_word(v_t_241), heff_strLength_lent(v_s_240, 0));
  if (heff_strEq_c(v_t_242, ((V)&g_heff_2ebuild_2ebenchmarks_2ebenchTime_24cpr_str0))) {
    int64_t v_t_243 = (heff_unbox_word(heff_strLength_lent(v_s_240, 0)) - ((int64_t)1ULL));
    V v_s_244 = heff_strSlice_lent(v_s_240, MK_INT(0LL), heff_box_word(v_t_243), 6);
    if ((((int64_t)0ULL) < heff_unbox_word(heff_strLength_lent(v_s_244, 0)))) {
      int64_t v_t_245 = (heff_unbox_word(heff_strLength_lent(v_s_244, 0)) - ((int64_t)1ULL));
      V v_t_246 = (g_list_2erange(MK_INT(0LL), heff_box_word(v_t_245)));
      V v_t_247 = ({ V a_0 = MK_INT(48LL); V a_1 = v_s_244; V a_2 = MK_INT(57LL); V a_3 = v_t_246; V r_ = (g_list_2eall_24s2093734251x1702493483(a_0, a_1, a_2, a_3)); heff_drop(v_t_246); r_; });
      if ((heff_dup(v_t_247) == NTAG(TAG_True))) {
        heff_drop(v_t_247);
        HeffT2 v_t_248 = ({ V a_0 = v_s_244; HeffT2 r_ = (g_prelude_2eparseInt_24cpr(a_0)); heff_drop(v_s_244); r_; });
        {
          V v_field_2410 = v_t_248.f[1];
          int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
          if ((v_tag_249 == ((int64_t)0ULL))) {
            V v_n_2411 = v_field_2410;
            if (heff_intLt_c_lent(MK_INT(0LL), v_n_2411, 1)) {
              return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_tag_n(TAG_Times, 1, (V[]){v_n_2411})}});
            } else {
              heff_drop(v_n_2411);
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
            }
          } else {
            heff_drop(v_field_2410);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
        }
      } else {
        heff_drop(v_s_244);
        heff_drop(v_t_247);
        return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
      }
    } else {
      heff_drop(v_s_244);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
  } else {
    V v_t_2412 = ({ V a_0 = v_s_240; V b_1 = heff_dup(g_heff_2ebuild_2ebenchmarks_2eunits_get()); V r_ = (g_list_2efind_24s1136367117x833793205(a_0, b_1)); heff_drop(b_1); r_; });
    return (g_heff_2ebuild_2ebenchmarks_2edurationOf_24cpr(v_s_240, v_t_2412));
  }
}
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2espaces_24acc_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2espaces_24acc_str1, 1, " ");
Clo g_heff_2ebuild_2ebenchmarks_2espaces_24acc_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebenchmarks_2espaces_24acc_entry, 2, 0};

V g_heff_2ebuild_2ebenchmarks_2espaces_24acc(V v_n_240, V v_acc_241) {
top: ;
  if (heff_intLe_c_lent(v_n_240, MK_INT(0LL), 2)) {
    heff_drop(v_n_240);
    return heff_strAppend(v_acc_241, ((V)&g_heff_2ebuild_2ebenchmarks_2espaces_24acc_str0));
  } else {
    V v_s_242 = heff_strAppend(v_acc_241, ((V)&g_heff_2ebuild_2ebenchmarks_2espaces_24acc_str1));
    V t_0 = heff_intSub(v_n_240, MK_INT(1LL));
    V t_1 = v_s_242;
    v_n_240 = t_0;
    v_acc_241 = t_1;
    goto top;
  }
}
V g_heff_2ebuild_2ebenchmarks_2espaces_24acc_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ebenchmarks_2espaces_24acc(a[0], a[1]);
}
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2espaced_str0, 1, "\011");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2espaced_str1, 1, "\011");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2espaced_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2espaced_str3, 1, "_");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2espaced_str4, 1, " ");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2espaced_str5, 1, " ");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2espaced_str6, 0, "");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2espaced_str7, 1, "_");
Clo g_heff_2ebuild_2ebenchmarks_2espaced_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebenchmarks_2espaced_entry, 1, 0};

V g_heff_2ebuild_2ebenchmarks_2espaced(V v_s_240) {
top: ;
  V v_x2_241 = ({ V b_0 = ((V)&g_heff_2ebuild_2ebenchmarks_2espaced_str0); V a_1 = v_s_240; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2ebenchmarks_2espaced_str1), v_s_240, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
  V v_s_244;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    v_s_244 = ((V)&g_heff_2ebuild_2ebenchmarks_2espaced_str2);
    break;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    v_s_244 = ({ V a_0 = ((V)&g_heff_2ebuild_2ebenchmarks_2espaced_str3); V a_1 = v_x_242; V a_2 = v_xs_243; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_243); r_; });
    break;
  }
  default: heff_nomatch(v_x2_241);
  }
  V v_x2_245 = ({ V b_0 = ((V)&g_heff_2ebuild_2ebenchmarks_2espaced_str4); V a_1 = v_s_244; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2ebenchmarks_2espaced_str5), v_s_244, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); heff_drop(v_s_244); r_; });
  switch (heff_tag_of(v_x2_245)) {
  case TAG_Nil: {
    return ((V)&g_heff_2ebuild_2ebenchmarks_2espaced_str6);
  }
  case TAG_Cons: {
    V v_x_246 = heff_field(v_x2_245, 0);
    V v_xs_247 = heff_field(v_x2_245, 1);
    heff_take_n(v_x2_245, 3ULL, 2);
    return ({ V a_0 = ((V)&g_heff_2ebuild_2ebenchmarks_2espaced_str7); V a_1 = v_x_246; V a_2 = v_xs_247; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_247); r_; });
  }
  default: return heff_nomatch(v_x2_245);
  }
}
V g_heff_2ebuild_2ebenchmarks_2espaced_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ebenchmarks_2espaced(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eperOp_str0, 1, "0");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eperOp_str1, 1, ".");
Clo g_heff_2ebuild_2ebenchmarks_2eperOp_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebenchmarks_2eperOp_entry, 2, 0};

V g_heff_2ebuild_2ebenchmarks_2eperOp(V v_total_240, V v_n_241) {
top: ;
  if (heff_intEq_c_lent(v_total_240, MK_INT(0LL), 2)) {
    heff_drop(v_total_240);
    heff_drop(v_n_241);
    V v_t_242 = (g_heff_2ebuild_2ebenchmarks_2espaces(MK_INT(9LL)));
    return heff_strAppend(v_t_242, ((V)&g_heff_2ebuild_2ebenchmarks_2eperOp_str0));
  } else {
    V v_t_243 = (g_heff_2ebuild_2ebenchmarks_2eplacesOf(heff_dup(v_total_240), heff_dup(v_n_241), MK_INT(0LL)));
    V v_x_244 = (g_heff_2ebuild_2ebenchmarks_2eplacesOf(heff_dup(v_total_240), heff_dup(v_n_241), MK_INT(0LL)));
    V v_t_245;
    if (heff_intLt_c(MK_INT(0LL), v_x_244)) {
      v_t_245 = MK_INT(1LL);
    } else {
      v_t_245 = MK_INT(0LL);
    }
    V v_n_246 = heff_intAdd(heff_intAdd(MK_INT(10LL), v_t_243), v_t_245);
    V v_places_247 = (g_heff_2ebuild_2ebenchmarks_2eplacesOf(heff_dup(v_total_240), heff_dup(v_n_241), MK_INT(0LL)));
    V v_t_248 = (g_heff_2ebuild_2ebenchmarks_2eplacesOf(heff_dup(v_total_240), heff_dup(v_n_241), MK_INT(0LL)));
    V v_t_249 = (g_heff_2ebuild_2ebenchmarks_2etenTo(v_t_248));
    V v_t_2410 = heff_intMul(heff_intMul(MK_INT(2LL), v_total_240), v_t_249);
    V v_scaled_2411 = heff_intDiv(heff_intAdd(v_t_2410, heff_dup(v_n_241)), heff_intMul(MK_INT(2LL), v_n_241));
    V v_s_2417;
    if (heff_intEq_c_lent(v_places_247, MK_INT(0LL), 2)) {
      heff_drop(v_places_247);
      v_s_2417 = heff_intShow(v_scaled_2411);
    } else {
      V v_t_2412 = (g_heff_2ebuild_2ebenchmarks_2etenTo(heff_dup(v_places_247)));
      V v_t_2413 = heff_intShow(heff_intDiv(heff_dup(v_scaled_2411), v_t_2412));
      V v_t_2414 = (g_heff_2ebuild_2ebenchmarks_2etenTo(heff_dup(v_places_247)));
      V v_t_2415 = heff_intShow(heff_intMod(v_scaled_2411, v_t_2414));
      V v_t_2416 = (g_heff_2ebuild_2ebenchmarks_2ezeroPadded(v_places_247, v_t_2415));
      v_s_2417 = heff_strAppend(v_t_2413, heff_strAppend(((V)&g_heff_2ebuild_2ebenchmarks_2eperOp_str1), v_t_2416));
    }
    V v_t_2418 = heff_intSub(v_n_246, heff_strLength_lent(v_s_2417, 0));
    V v_t_2419 = (g_heff_2ebuild_2ebenchmarks_2espaces(v_t_2418));
    return heff_strAppend(v_t_2419, v_s_2417);
  }
}
V g_heff_2ebuild_2ebenchmarks_2eperOp_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ebenchmarks_2eperOp(a[0], a[1]);
}
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eoutcomeJson_str0, 4, "file");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eoutcomeJson_str1, 9, "Benchmark");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eoutcomeJson_str2, 1, "/");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eoutcomeJson_str3, 9, "Benchmark");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eoutcomeJson_str4, 4, "name");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eoutcomeJson_str5, 5, "names");
Clo g_heff_2ebuild_2ebenchmarks_2eoutcomeJson_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebenchmarks_2eoutcomeJson_entry, 3, 0};

V g_heff_2ebuild_2ebenchmarks_2eoutcomeJson(V v_f_240, V v_names_241, V v_o_242) {
top: ;
  V v_t_243 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2ebenchmarks_2eoutcomeJson_str0), heff_tag_n(TAG_JString, 1, (V[]){v_f_240})});
  V v_t_249;
  switch (heff_tag_of(v_names_241)) {
  case TAG_Nil: {
    v_t_249 = ((V)&g_heff_2ebuild_2ebenchmarks_2eoutcomeJson_str1);
    break;
  }
  case TAG_Cons: {
    V v_n_244 = heff_dup(heff_field(v_names_241, 0));
    V v_rest_245 = heff_dup(heff_field(v_names_241, 1));
    V v_t_246 = ({ V a_0 = v_n_244; V r_ = (g_heff_2ebuild_2ebenchmarks_2espaced(a_0)); heff_drop(v_n_244); r_; });
    V v_t_247 = (g_heff_2ebuild_2ebenchmarks_2ecapital(v_t_246));
    V v_t_248 = ({ V a_0 = ((V)&g_heff_2ebuild_2ebenchmarks_2eoutcomeJson_str2); V a_1 = v_t_247; V a_2 = v_rest_245; V r_ = (g_prelude_2ejoinWith_2eafter_240_24f591888720x1996727869(a_0, a_1, a_2)); heff_drop(v_rest_245); r_; });
    v_t_249 = heff_strAppend(((V)&g_heff_2ebuild_2ebenchmarks_2eoutcomeJson_str3), v_t_248);
    break;
  }
  default: heff_nomatch(v_names_241);
  }
  V v_t_2410 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2ebenchmarks_2eoutcomeJson_str4), heff_tag_n(TAG_JString, 1, (V[]){v_t_249})});
  V v_t_2411 = (g_list_2emap_24s723912745x1713553694(v_names_241));
  V v_t_2412 = heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2ebenchmarks_2eoutcomeJson_str5), heff_tag_n(TAG_JArray, 1, (V[]){v_t_2411})});
  V v_t_2413 = (g_heff_2ebuild_2ebenchmarks_2eoutcomeFields(v_o_242));
  V v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2410, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2412, v_t_2413})});
  V v_t_2415 = heff_tag_n(TAG_JObject, 1, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_243, v_t_2414})});
  return ({ V a_0 = v_t_2415; V r_ = (g_json_2estringify(a_0)); heff_drop_tag(v_t_2415, 1); r_; });
}
V g_heff_2ebuild_2ebenchmarks_2eoutcomeJson_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ebenchmarks_2eoutcomeJson(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2ebenchMainName_str0, 13, "heffBenchMain");

static V g_heff_2ebuild_2ebenchmarks_2ebenchMainName_val;
static HEFF_ONCE g_heff_2ebuild_2ebenchmarks_2ebenchMainName_st;
static V g_heff_2ebuild_2ebenchmarks_2ebenchMainName_init(void) {
  return ((V)&g_heff_2ebuild_2ebenchmarks_2ebenchMainName_str0);
}
V g_heff_2ebuild_2ebenchmarks_2ebenchMainName_get(void) {
  if (HEFF_DONE(g_heff_2ebuild_2ebenchmarks_2ebenchMainName_st)) return g_heff_2ebuild_2ebenchmarks_2ebenchMainName_val;
  return heff_global(&g_heff_2ebuild_2ebenchmarks_2ebenchMainName_val, &g_heff_2ebuild_2ebenchmarks_2ebenchMainName_st, g_heff_2ebuild_2ebenchmarks_2ebenchMainName_init);
}
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2ebenchAdded_24cpr_str0, 51, "it does not import bench, which runs its benchmarks");

HeffT2 g_heff_2ebuild_2ebenchmarks_2ebenchAdded_24cpr(V v_l_240, V v_c_241, V v_src_242) {
top: ;
  V v_renames_243 = heff_take_field(v_src_242, 5);
  V v_implicit_244 = heff_take_field(v_src_242, 6);
  V v_source_245 = heff_get_n(v_src_242, 4, 8);
  V v_sources_246 = heff_take_field(v_l_240, 0);
  V v_errors_247 = heff_take_field(v_l_240, 1);
  V v_paths_248 = heff_take_field(v_l_240, 2);
  V v_package_249 = heff_take_field(v_l_240, 3);
  V v_packages_2410 = heff_get_n(v_l_240, 4, 5);
  V v_t_2411 = (g_heff_2esyntax_2eimport_2eimportsOf(v_implicit_244, v_source_245));
  HeffT4 v_t_2412 = ({ V a_0 = v_renames_243; V a_1 = v_t_2411; HeffT4 r_ = (g_heff_2esyntax_2eimport_2erenamed_24cpr(a_0, a_1)); heff_drop(v_renames_243); r_; });
  V v_t_2417;
  {
    V v_field_2413 = v_t_2412.f[0];
    heff_drop(v_t_2412.f[1]);
    heff_drop(v_t_2412.f[2]);
    heff_drop(v_t_2412.f[3]);
    v_t_2417 = v_field_2413;
  }
  HeffT2 v_t_2418 = (g_heff_2ebuild_2ebenchmarks_2ebenchQualifier_24cpr(v_t_2417));
  {
    V v_field_2420 = v_t_2418.f[1];
    int64_t v_tag_2419 = ((int64_t)v_t_2418.f[0]);
    if ((v_tag_2419 == ((int64_t)0ULL))) {
      V v_q_2421 = v_field_2420;
      V v_t_2422 = (g_heff_2ebuild_2edriver_2ebenchesOf(heff_dup(v_c_241)));
      V v_t_2423 = (g_heff_2ebuild_2ebenchmarks_2ebenchText(v_q_2421, v_t_2422));
      V v_sources_2424 = ({ V b_0 = heff_get_n(v_c_241, 0, 14); V a_1 = v_t_2423; V a_2 = v_sources_246; V r_ = (g_list_2emap_24s1681408447x1763680441(b_0, a_1, a_2)); heff_drop(b_0); r_; });
      V v_f_2425 = heff_rec_n(5, shape_sources__errors__paths__package__packages, (V[]){v_sources_2424, v_errors_247, v_paths_248, v_package_249, v_packages_2410});
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_f_2425}});
    } else {
      heff_drop_rec(v_c_241, 14);
      heff_drop(v_sources_246);
      heff_drop(v_errors_247);
      heff_drop(v_paths_248);
      heff_drop(v_package_249);
      heff_drop(v_packages_2410);
      heff_drop(v_field_2420);
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), ((V)&g_heff_2ebuild_2ebenchmarks_2ebenchAdded_24cpr_str0)}});
    }
  }
}
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2ebenchDir_str0, 11, ".heff/bench");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2ebenchDir_str1, 2, "..");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2ebenchDir_str2, 2, "..");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2ebenchDir_str3, 2, "..");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2ebenchDir_str4, 2, "..");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2ebenchDir_str5, 0, "");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2ebenchDir_str6, 1, "_");
Clo g_heff_2ebuild_2ebenchmarks_2ebenchDir_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebenchmarks_2ebenchDir_entry, 2, 0};

V g_heff_2ebuild_2ebenchmarks_2ebenchDir(V v_paths_240, V v_file_241) {
top: ;
  V v_style_242 = heff_take_field(v_paths_240, 5);
  V v_root_243 = heff_get_n(v_paths_240, 0, 6);
  V v_st_244 = heff_dup(v_style_242);
  V v_t_245 = (g_std_2epath_2eparse(v_st_244, v_root_243));
  V v_t_246 = (g_std_2epath_2eparse(v_st_244, ((V)&g_heff_2ebuild_2ebenchmarks_2ebenchDir_str0)));
  V v_t_247 = (g_std_2epath_2ejoin(v_t_245, v_t_246));
  V v_d_248 = ({ V a_0 = v_st_244; V a_1 = v_t_247; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_244); heff_drop(v_t_247); r_; });
  HeffT3 v_t_249 = (g_std_2epath_2eparse_24cpr(v_style_242, v_file_241));
  {
    V v_field_2410 = v_t_249.f[0];
    V v_field_2411 = v_t_249.f[1];
    V v_field_2412 = v_t_249.f[2];
    V v_d_2413 = v_field_2410;
    heff_drop(v_d_2413);
    V v_a_2414 = v_field_2411;
    V v_xs_2415 = v_field_2412;
    V v_xs_2416 = ({ V b_0 = ((V)&g_heff_2ebuild_2ebenchmarks_2ebenchDir_str1); V a_1 = v_a_2414; V a_2 = ((V)&g_heff_2ebuild_2ebenchmarks_2ebenchDir_str2); V b_3 = ((V)&g_heff_2ebuild_2ebenchmarks_2ebenchDir_str3); V a_4 = ((V)&g_heff_2ebuild_2ebenchmarks_2ebenchDir_str4); V a_5 = NTAG(TAG_Nil); V a_6 = v_xs_2415; V r_ = (g_list_2efoldl_24s680990791x1764841948(b_0, a_1, a_2, b_3, a_4, a_5, a_6)); heff_drop(b_0); heff_drop(v_a_2414); heff_drop(b_3); r_; });
    V v_t_2417 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2416));
    V v_x2_2418 = v_t_2417;
    V v_p_2421;
    switch (heff_tag_of(v_x2_2418)) {
    case TAG_Nil: {
      v_p_2421 = ((V)&g_heff_2ebuild_2ebenchmarks_2ebenchDir_str5);
      break;
    }
    case TAG_Cons: {
      V v_x_2419 = heff_field(v_x2_2418, 0);
      V v_xs_2420 = heff_field(v_x2_2418, 1);
      heff_take_n(v_x2_2418, 3ULL, 2);
      v_p_2421 = ({ V a_0 = ((V)&g_heff_2ebuild_2ebenchmarks_2ebenchDir_str6); V a_1 = v_x_2419; V a_2 = v_xs_2420; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2420); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2418);
    }
    V v_st_2422 = v_style_242;
    V v_t_2423 = (g_std_2epath_2eparse(v_st_2422, v_d_248));
    V v_t_2424 = (g_std_2epath_2eparse(v_st_2422, v_p_2421));
    V v_t_2425 = (g_std_2epath_2ejoin(v_t_2423, v_t_2424));
    return ({ V a_0 = v_st_2422; V a_1 = v_t_2425; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2422); heff_drop(v_t_2425); r_; });
  }
}
V g_heff_2ebuild_2ebenchmarks_2ebenchDir_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ebenchmarks_2ebenchDir(a[0], a[1]);
}
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eoutcomeOfLine_str0, 1, "n");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eoutcomeOfLine_str1, 7, "skipped");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eoutcomeOfLine_str2, 6, "failed");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eoutcomeOfLine_str3, 30, "it said nothing of how it went");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eoutcomeOfLine_str4, 30, "it said nothing of how it went");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eoutcomeOfLine_str5, 30, "it said nothing of how it went");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eoutcomeOfLine_str6, 30, "it said nothing of how it went");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eoutcomeOfLine_str7, 30, "it said nothing of how it went");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eoutcomeOfLine_str8, 30, "it said nothing of how it went");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eoutcomeOfLine_str9, 30, "it said nothing of how it went");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eoutcomeOfLine_str10, 2, "ns");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eoutcomeOfLine_str11, 6, "allocs");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2eoutcomeOfLine_str12, 5, "bytes");
Clo g_heff_2ebuild_2ebenchmarks_2eoutcomeOfLine_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebenchmarks_2eoutcomeOfLine_entry, 1, 0};

V g_heff_2ebuild_2ebenchmarks_2eoutcomeOfLine(V v_j_240) {
top: ;
  V v_t_241 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ebenchmarks_2eoutcomeOfLine_str0), NTAG(TAG_Nil)});
  HeffT2 v_t_242 = (g_json_2eat_24cpr(v_t_241, heff_dup(v_j_240)));
  {
    V v_field_244 = v_t_242.f[1];
    int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
    V v_t_2412;
    if ((v_tag_243 == ((int64_t)0ULL))) {
      V v_it1_245 = v_field_244;
      switch (heff_tag_of(v_it1_245)) {
      case TAG_JNull: {
        v_t_2412 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_JBool: {
        heff_take_n(v_it1_245, 0ULL, 1);
        v_t_2412 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_JInt: {
        V v_i_247 = heff_field(v_it1_245, 0);
        V v_ru_24it1_245_24JInt = heff_take_reuse_n(v_it1_245, 1ULL, 1);
        v_t_2412 = heff_tag_at_n(v_ru_24it1_245_24JInt, TAG_Just, 1, (V[]){v_i_247});
        break;
      }
      case TAG_JFloat: {
        double v_x_248 = heff_tflat_f64(v_it1_245, 0);
        V v_ru_24it1_245_24JFloat = heff_take_reuse_na(v_it1_245, 0ULL, 1);
        v_t_2412 = heff_tag_at_n(v_ru_24it1_245_24JFloat, TAG_Just, 1, (V[]){heff_floor_f64(v_x_248)});
        break;
      }
      case TAG_JString: {
        heff_take_n(v_it1_245, 0ULL, 1);
        v_t_2412 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_JArray: {
        heff_take_n(v_it1_245, 0ULL, 1);
        v_t_2412 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_JObject: {
        heff_take_n(v_it1_245, 0ULL, 1);
        v_t_2412 = NTAG(TAG_Nothing);
        break;
      }
      default: heff_nomatch(v_it1_245);
      }
    } else {
      heff_drop(v_field_244);
      v_t_2412 = NTAG(TAG_Nothing);
    }
    switch (heff_tag_of(v_t_2412)) {
    case TAG_Nothing: {
      V v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ebenchmarks_2eoutcomeOfLine_str1), NTAG(TAG_Nil)});
      HeffT2 v_t_2414 = (g_json_2eat_24cpr(v_t_2413, heff_dup(v_j_240)));
      {
        V v_field_2416 = v_t_2414.f[1];
        int64_t v_tag_2415 = ((int64_t)v_t_2414.f[0]);
        V v_t_2424;
        if ((v_tag_2415 == ((int64_t)0ULL))) {
          V v_it1_2417 = v_field_2416;
          switch (heff_tag_of(v_it1_2417)) {
          case TAG_JNull: {
            v_t_2424 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_JBool: {
            heff_take_n(v_it1_2417, 0ULL, 1);
            v_t_2424 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_JInt: {
            heff_take_n(v_it1_2417, 0ULL, 1);
            v_t_2424 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_JFloat: {
            heff_take_na(v_it1_2417, 0ULL, 1);
            v_t_2424 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_JString: {
            V v_s_2421 = heff_field(v_it1_2417, 0);
            V v_ru_24it1_2417_24JString = heff_take_reuse_n(v_it1_2417, 1ULL, 1);
            v_t_2424 = heff_tag_at_n(v_ru_24it1_2417_24JString, TAG_Just, 1, (V[]){v_s_2421});
            break;
          }
          case TAG_JArray: {
            heff_take_n(v_it1_2417, 0ULL, 1);
            v_t_2424 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_JObject: {
            heff_take_n(v_it1_2417, 0ULL, 1);
            v_t_2424 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_it1_2417);
          }
        } else {
          heff_drop(v_field_2416);
          v_t_2424 = NTAG(TAG_Nothing);
        }
        switch (heff_tag_of(v_t_2424)) {
        case TAG_Nothing: {
          V v_t_2425 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ebenchmarks_2eoutcomeOfLine_str2), NTAG(TAG_Nil)});
          HeffT2 v_t_2426 = (g_json_2eat_24cpr(v_t_2425, v_j_240));
          V v_t_2436;
          {
            V v_field_2428 = v_t_2426.f[1];
            int64_t v_tag_2427 = ((int64_t)v_t_2426.f[0]);
            if ((v_tag_2427 == ((int64_t)0ULL))) {
              V v_it1_2429 = v_field_2428;
              switch (heff_tag_of(v_it1_2429)) {
              case TAG_JNull: {
                v_t_2436 = ((V)&g_heff_2ebuild_2ebenchmarks_2eoutcomeOfLine_str3);
                break;
              }
              case TAG_JBool: {
                heff_take_n(v_it1_2429, 0ULL, 1);
                v_t_2436 = ((V)&g_heff_2ebuild_2ebenchmarks_2eoutcomeOfLine_str4);
                break;
              }
              case TAG_JInt: {
                heff_take_n(v_it1_2429, 0ULL, 1);
                v_t_2436 = ((V)&g_heff_2ebuild_2ebenchmarks_2eoutcomeOfLine_str5);
                break;
              }
              case TAG_JFloat: {
                heff_take_na(v_it1_2429, 0ULL, 1);
                v_t_2436 = ((V)&g_heff_2ebuild_2ebenchmarks_2eoutcomeOfLine_str6);
                break;
              }
              case TAG_JString: {
                V v_s_2433 = heff_field(v_it1_2429, 0);
                heff_take_n(v_it1_2429, 1ULL, 1);
                v_t_2436 = v_s_2433;
                break;
              }
              case TAG_JArray: {
                heff_take_n(v_it1_2429, 0ULL, 1);
                v_t_2436 = ((V)&g_heff_2ebuild_2ebenchmarks_2eoutcomeOfLine_str7);
                break;
              }
              case TAG_JObject: {
                heff_take_n(v_it1_2429, 0ULL, 1);
                v_t_2436 = ((V)&g_heff_2ebuild_2ebenchmarks_2eoutcomeOfLine_str8);
                break;
              }
              default: heff_nomatch(v_it1_2429);
              }
            } else {
              heff_drop(v_field_2428);
              v_t_2436 = ((V)&g_heff_2ebuild_2ebenchmarks_2eoutcomeOfLine_str9);
            }
          }
          return heff_tag_n(TAG_FailedWith, 1, (V[]){v_t_2436});
        }
        case TAG_Just: {
          V v_why_2437 = heff_field(v_t_2424, 0);
          V v_ru_24t_2424_24Just = heff_take_reuse_n(v_t_2424, 1ULL, 1);
          heff_drop(v_j_240);
          return heff_tag_at_n(v_ru_24t_2424_24Just, TAG_SkippedWith, 1, (V[]){v_why_2437});
        }
        default: return heff_nomatch(v_t_2424);
        }
      }
    }
    case TAG_Just: {
      V v_n_2438 = heff_field(v_t_2412, 0);
      heff_take_n(v_t_2412, 1ULL, 1);
      V v_t_2439 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ebenchmarks_2eoutcomeOfLine_str10), NTAG(TAG_Nil)});
      HeffT2 v_t_2440 = (g_json_2eat_24cpr(v_t_2439, heff_dup(v_j_240)));
      V v_t_2450;
      {
        V v_field_2442 = v_t_2440.f[1];
        int64_t v_tag_2441 = ((int64_t)v_t_2440.f[0]);
        if ((v_tag_2441 == ((int64_t)0ULL))) {
          V v_it1_2443 = v_field_2442;
          switch (heff_tag_of(v_it1_2443)) {
          case TAG_JNull: {
            v_t_2450 = MK_INT(0LL);
            break;
          }
          case TAG_JBool: {
            heff_take_n(v_it1_2443, 0ULL, 1);
            v_t_2450 = MK_INT(0LL);
            break;
          }
          case TAG_JInt: {
            V v_i_2445 = heff_field(v_it1_2443, 0);
            heff_take_n(v_it1_2443, 1ULL, 1);
            v_t_2450 = v_i_2445;
            break;
          }
          case TAG_JFloat: {
            double v_x_2446 = heff_tflat_f64(v_it1_2443, 0);
            heff_take_na(v_it1_2443, 0ULL, 1);
            v_t_2450 = heff_floor_f64(v_x_2446);
            break;
          }
          case TAG_JString: {
            heff_take_n(v_it1_2443, 0ULL, 1);
            v_t_2450 = MK_INT(0LL);
            break;
          }
          case TAG_JArray: {
            heff_take_n(v_it1_2443, 0ULL, 1);
            v_t_2450 = MK_INT(0LL);
            break;
          }
          case TAG_JObject: {
            heff_take_n(v_it1_2443, 0ULL, 1);
            v_t_2450 = MK_INT(0LL);
            break;
          }
          default: heff_nomatch(v_it1_2443);
          }
        } else {
          heff_drop(v_field_2442);
          v_t_2450 = MK_INT(0LL);
        }
      }
      V v_t_2451 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ebenchmarks_2eoutcomeOfLine_str11), NTAG(TAG_Nil)});
      HeffT2 v_t_2452 = (g_json_2eat_24cpr(v_t_2451, heff_dup(v_j_240)));
      V v_t_2462;
      {
        V v_field_2454 = v_t_2452.f[1];
        int64_t v_tag_2453 = ((int64_t)v_t_2452.f[0]);
        if ((v_tag_2453 == ((int64_t)0ULL))) {
          V v_it1_2455 = v_field_2454;
          switch (heff_tag_of(v_it1_2455)) {
          case TAG_JNull: {
            v_t_2462 = MK_INT(0LL);
            break;
          }
          case TAG_JBool: {
            heff_take_n(v_it1_2455, 0ULL, 1);
            v_t_2462 = MK_INT(0LL);
            break;
          }
          case TAG_JInt: {
            V v_i_2457 = heff_field(v_it1_2455, 0);
            heff_take_n(v_it1_2455, 1ULL, 1);
            v_t_2462 = v_i_2457;
            break;
          }
          case TAG_JFloat: {
            double v_x_2458 = heff_tflat_f64(v_it1_2455, 0);
            heff_take_na(v_it1_2455, 0ULL, 1);
            v_t_2462 = heff_floor_f64(v_x_2458);
            break;
          }
          case TAG_JString: {
            heff_take_n(v_it1_2455, 0ULL, 1);
            v_t_2462 = MK_INT(0LL);
            break;
          }
          case TAG_JArray: {
            heff_take_n(v_it1_2455, 0ULL, 1);
            v_t_2462 = MK_INT(0LL);
            break;
          }
          case TAG_JObject: {
            heff_take_n(v_it1_2455, 0ULL, 1);
            v_t_2462 = MK_INT(0LL);
            break;
          }
          default: heff_nomatch(v_it1_2455);
          }
        } else {
          heff_drop(v_field_2454);
          v_t_2462 = MK_INT(0LL);
        }
      }
      V v_t_2463 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ebenchmarks_2eoutcomeOfLine_str12), NTAG(TAG_Nil)});
      HeffT2 v_t_2464 = (g_json_2eat_24cpr(v_t_2463, v_j_240));
      V v_t_2474;
      {
        V v_field_2466 = v_t_2464.f[1];
        int64_t v_tag_2465 = ((int64_t)v_t_2464.f[0]);
        if ((v_tag_2465 == ((int64_t)0ULL))) {
          V v_it1_2467 = v_field_2466;
          switch (heff_tag_of(v_it1_2467)) {
          case TAG_JNull: {
            v_t_2474 = MK_INT(0LL);
            break;
          }
          case TAG_JBool: {
            heff_take_n(v_it1_2467, 0ULL, 1);
            v_t_2474 = MK_INT(0LL);
            break;
          }
          case TAG_JInt: {
            V v_i_2469 = heff_field(v_it1_2467, 0);
            heff_take_n(v_it1_2467, 1ULL, 1);
            v_t_2474 = v_i_2469;
            break;
          }
          case TAG_JFloat: {
            double v_x_2470 = heff_tflat_f64(v_it1_2467, 0);
            heff_take_na(v_it1_2467, 0ULL, 1);
            v_t_2474 = heff_floor_f64(v_x_2470);
            break;
          }
          case TAG_JString: {
            heff_take_n(v_it1_2467, 0ULL, 1);
            v_t_2474 = MK_INT(0LL);
            break;
          }
          case TAG_JArray: {
            heff_take_n(v_it1_2467, 0ULL, 1);
            v_t_2474 = MK_INT(0LL);
            break;
          }
          case TAG_JObject: {
            heff_take_n(v_it1_2467, 0ULL, 1);
            v_t_2474 = MK_INT(0LL);
            break;
          }
          default: heff_nomatch(v_it1_2467);
          }
        } else {
          heff_drop(v_field_2466);
          v_t_2474 = MK_INT(0LL);
        }
      }
      return heff_tag_n(TAG_Measured, 4, (V[]){v_n_2438, v_t_2450, v_t_2462, v_t_2474});
    }
    default: return heff_nomatch(v_t_2412);
    }
  }
}
V g_heff_2ebuild_2ebenchmarks_2eoutcomeOfLine_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ebenchmarks_2eoutcomeOfLine(a[0]);
}
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2elistedOf_24cpr_str0, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2elistedOf_24cpr_str1, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2elistedOf_24cpr_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2elistedOf_24cpr_str3, 0, "");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2elistedOf_24cpr_str4, 32, "what it listed could not be read");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2elistedOf_24cpr_str5, 32, "what it listed could not be read");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2elistedOf_24cpr_str6, 32, "what it listed could not be read");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2elistedOf_24cpr_str7, 32, "what it listed could not be read");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2elistedOf_24cpr_str8, 32, "what it listed could not be read");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2elistedOf_24cpr_str9, 32, "what it listed could not be read");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2elistedOf_24cpr_str10, 32, "what it listed could not be read");

HeffT2 g_heff_2ebuild_2ebenchmarks_2elistedOf_24cpr(V v_r_240) {
top: ;
  V v_t_241 = heff_dup(heff_rfield(v_r_240, 0));
  switch (heff_tag_of(v_t_241)) {
  case TAG_Exited: {
    V v_n_242 = heff_field(v_t_241, 0);
    heff_take_n(v_t_241, 1ULL, 1);
    if (!heff_intEq_c_lent(v_n_242, MK_INT(0LL), 2)) {
      heff_drop(v_n_242);
      V v_f_243 = (g_heff_2ebuild_2ebenchmarks_2eendedWhy(v_r_240));
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_243}});
    } else {
      heff_drop(v_n_242);
      V v_t_244 = heff_get_n(v_r_240, 1, 3);
      V v_t_245 = ({ V b_0 = ((V)&g_heff_2ebuild_2ebenchmarks_2elistedOf_24cpr_str0); V a_1 = v_t_244; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2ebenchmarks_2elistedOf_24cpr_str1), v_t_244, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); heff_drop(v_t_244); r_; });
      V v_x1_246 = ({ V a_0 = NTAG(TAG_Nil); V b_1 = ((V)&g_heff_2ebuild_2ebenchmarks_2elistedOf_24cpr_str2); V a_2 = v_t_245; V r_ = (g_list_2efoldl_24f1221993074x1235215335(a_0, b_1, a_2)); heff_drop(b_1); r_; });
      V v_t_249;
      switch (heff_tag_of(v_x1_246)) {
      case TAG_Nil: {
        v_t_249 = ((V)&g_heff_2ebuild_2ebenchmarks_2elistedOf_24cpr_str3);
        break;
      }
      case TAG_Cons: {
        V v_x_247 = heff_field(v_x1_246, 0);
        heff_take_n(v_x1_246, 1ULL, 2);
        v_t_249 = v_x_247;
        break;
      }
      default: heff_nomatch(v_x1_246);
      }
      V v_t_2410 = heff_tag_n(TAG_Value, 2, (V[]){MK_INT(0LL), NTAG(TAG_Nil)});
      HeffT2 v_t_2411 = ({ V a_0 = v_t_249; V a_1 = v_t_2410; HeffT2 r_ = (g_json_2esteps_24cpr(a_0, a_1)); heff_drop(v_t_249); r_; });
      {
        V v_field_2413 = v_t_2411.f[1];
        int64_t v_tag_2412 = ((int64_t)v_t_2411.f[0]);
        if ((v_tag_2412 == ((int64_t)0ULL))) {
          V v_x_2414 = v_field_2413;
          heff_drop(v_x_2414);
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), ((V)&g_heff_2ebuild_2ebenchmarks_2elistedOf_24cpr_str4)}});
        } else {
          V v_it1_2415 = v_field_2413;
          switch (heff_tag_of(v_it1_2415)) {
          case TAG_JNull: {
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), ((V)&g_heff_2ebuild_2ebenchmarks_2elistedOf_24cpr_str5)}});
          }
          case TAG_JBool: {
            heff_take_n(v_it1_2415, 0ULL, 1);
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), ((V)&g_heff_2ebuild_2ebenchmarks_2elistedOf_24cpr_str6)}});
          }
          case TAG_JInt: {
            heff_take_n(v_it1_2415, 0ULL, 1);
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), ((V)&g_heff_2ebuild_2ebenchmarks_2elistedOf_24cpr_str7)}});
          }
          case TAG_JFloat: {
            heff_take_na(v_it1_2415, 0ULL, 1);
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), ((V)&g_heff_2ebuild_2ebenchmarks_2elistedOf_24cpr_str8)}});
          }
          case TAG_JString: {
            heff_take_n(v_it1_2415, 0ULL, 1);
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), ((V)&g_heff_2ebuild_2ebenchmarks_2elistedOf_24cpr_str9)}});
          }
          case TAG_JArray: {
            V v_bs_2420 = heff_field(v_it1_2415, 0);
            heff_take_n(v_it1_2415, 1ULL, 1);
            V v_f_2421 = (g_list_2emap_24s849938259x51049885(v_bs_2420));
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_f_2421}});
          }
          case TAG_JObject: {
            heff_take_n(v_it1_2415, 0ULL, 1);
            return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), ((V)&g_heff_2ebuild_2ebenchmarks_2elistedOf_24cpr_str10)}});
          }
          default: return ((HeffT2){{heff_nomatch(v_it1_2415)}});
          }
        }
      }
    }
  }
  case TAG_Signalled: {
    heff_take_n(v_t_241, 0ULL, 1);
    V v_f_2424 = (g_heff_2ebuild_2ebenchmarks_2eendedWhy(v_r_240));
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2424}});
  }
  case TAG_TimedOut: {
    V v_f_2425 = (g_heff_2ebuild_2ebenchmarks_2eendedWhy(v_r_240));
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2425}});
  }
  case TAG_NotRun: {
    V v_f_2426 = (g_heff_2ebuild_2ebenchmarks_2eendedWhy(v_r_240));
    return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2426}});
  }
  default: return ((HeffT2){{heff_nomatch(v_t_241)}});
  }
}
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2etimeGiven_24s1598223557x830608042_str0, 19, "heff bench: --time ");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2etimeGiven_24s1598223557x830608042_str1, 57, ": not a duration (1s, 1.5s, 500ms, 2m) nor a count (100x)");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2etimeGiven_24s1598223557x830608042_str2, 1, "\012");
V g_heff_2ebuild_2ebenchmarks_2etimeGiven_24s1598223557x830608042_lam0(V self, V *args); static Clo g_heff_2ebuild_2ebenchmarks_2etimeGiven_24s1598223557x830608042_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebenchmarks_2etimeGiven_24s1598223557x830608042_lam0, 2, 0};
V g_heff_2ebuild_2ebenchmarks_2etimeGiven_24s1598223557x830608042_lam1(V self, V *args);
V g_heff_2ebuild_2ebenchmarks_2etimeGiven_24s1598223557x830608042_lam4(V self, V *args);
V g_heff_2ebuild_2ebenchmarks_2etimeGiven_24s1598223557x830608042_lam3(V self, V *args);
V g_heff_2ebuild_2ebenchmarks_2etimeGiven_24s1598223557x830608042_lam2(V self, V *args);
Clo g_heff_2ebuild_2ebenchmarks_2etimeGiven_24s1598223557x830608042_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebenchmarks_2etimeGiven_24s1598223557x830608042_entry, 1, 0};

V g_heff_2ebuild_2ebenchmarks_2etimeGiven_24s1598223557x830608042(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nothing: {
    return ((V)&g_heff_2ebuild_2ebenchmarks_2etimeGiven_24s1598223557x830608042_lam0_clo);
  }
  case TAG_Just: {
    V v_s_243 = heff_field(v_x1_240, 0);
    heff_take_n(v_x1_240, 1ULL, 1);
    HeffT2 v_t_244 = (g_heff_2ebuild_2ebenchmarks_2ebenchTime_24cpr(v_s_243));
    {
      V v_field_246 = v_t_244.f[1];
      int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
      if ((v_tag_245 == ((int64_t)0ULL))) {
        heff_drop(v_s_243);
        V v_t_247 = v_field_246;
        return heff_clo_n(g_heff_2ebuild_2ebenchmarks_2etimeGiven_24s1598223557x830608042_lam1, 2, 1, (V[]){v_t_247});
      } else {
        heff_drop(v_field_246);
        return heff_clo_n(g_heff_2ebuild_2ebenchmarks_2etimeGiven_24s1598223557x830608042_lam2, 2, 1, (V[]){v_s_243});
      }
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2ebenchmarks_2etimeGiven_24s1598223557x830608042_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ebenchmarks_2etimeGiven_24s1598223557x830608042(a[0]);
}
V g_heff_2ebuild_2ebenchmarks_2etimeGiven_24s1598223557x830608042_lam0(V self, V *args) {
  V v_hd_241 = args[0];
  V v_k_242 = args[1];
  heff_drop(v_hd_241);
  V f_ = v_k_242;
  args[0] = heff_dup(g_heff_2ebuild_2ebenchmarks_2edefaultTime_get());
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ebenchmarks_2etimeGiven_24s1598223557x830608042_lam1(V self, V *args) {
  V v_hd_248 = args[0];
  V v_k_249 = args[1];
  V v_t_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_248);
  V f_ = v_k_249;
  args[0] = v_t_247;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ebenchmarks_2etimeGiven_24s1598223557x830608042_lam4(V self, V *args) {
  V v_x_2432 = args[0];
  V v_k_2411 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2432);
  V f_ = v_k_2411;
  args[0] = heff_dup(g_heff_2ebuild_2ebenchmarks_2edefaultTime_get());
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ebenchmarks_2etimeGiven_24s1598223557x830608042_lam3(V self, V *args) {
  V v_x_2423 = args[0];
  V v_malg_2413 = heff_env(self)[0];
  V v_bind_2412 = heff_env(self)[1];
  V v_k_2411 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2423);
  V v_t_2424 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(2LL), NTAG(TAG_MkUnit)});
  V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2424})});
  V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
  V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
  V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
  V v_t_2429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
  V v_t_2430 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2429})});
  V v_t_2431 = heff_tr(heff_call(v_malg_2413, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2430})}));
  V f_ = v_bind_2412;
  heff_room[0] = v_t_2431;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ebenchmarks_2etimeGiven_24s1598223557x830608042_lam4, 1, 1, (V[]){v_k_2411});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ebenchmarks_2etimeGiven_24s1598223557x830608042_lam2(V self, V *args) {
  V v_hd_2410 = args[0];
  V v_k_2411 = args[1];
  V v_s_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_bind_2412 = heff_take_field(v_hd_2410, 1);
  V v_malg_2413 = heff_get_n(v_hd_2410, 2, 3);
  V v_t_2414 = heff_strAppend(((V)&g_heff_2ebuild_2ebenchmarks_2etimeGiven_24s1598223557x830608042_str0), heff_strAppend(v_s_243, ((V)&g_heff_2ebuild_2ebenchmarks_2etimeGiven_24s1598223557x830608042_str1)));
  V v_t_2415 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_t_2414, ((V)&g_heff_2ebuild_2ebenchmarks_2etimeGiven_24s1598223557x830608042_str2)), NTAG(TAG_MkUnit)});
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
  V v_t_2421 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2420})});
  V v_t_2422 = heff_tr(heff_call(heff_dup(v_malg_2413), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2421})}));
  V f_ = heff_dup(v_bind_2412);
  args[0] = v_t_2422;
  args[1] = heff_clo_n(g_heff_2ebuild_2ebenchmarks_2etimeGiven_24s1598223557x830608042_lam3, 1, 3, (V[]){v_malg_2413, v_bind_2412, v_k_2411});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2ecountGiven_24s1787086774x1151984647_str0, 20, "heff bench: --count ");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2ecountGiven_24s1787086774x1151984647_str1, 21, ": not a count above 0");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2ecountGiven_24s1787086774x1151984647_str2, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2ecountGiven_24s1787086774x1151984647_str3, 20, "heff bench: --count ");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2ecountGiven_24s1787086774x1151984647_str4, 21, ": not a count above 0");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2ecountGiven_24s1787086774x1151984647_str5, 1, "\012");
V g_heff_2ebuild_2ebenchmarks_2ecountGiven_24s1787086774x1151984647_lam0(V self, V *args); static Clo g_heff_2ebuild_2ebenchmarks_2ecountGiven_24s1787086774x1151984647_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebenchmarks_2ecountGiven_24s1787086774x1151984647_lam0, 2, 0};
V g_heff_2ebuild_2ebenchmarks_2ecountGiven_24s1787086774x1151984647_lam3(V self, V *args);
V g_heff_2ebuild_2ebenchmarks_2ecountGiven_24s1787086774x1151984647_lam2(V self, V *args);
V g_heff_2ebuild_2ebenchmarks_2ecountGiven_24s1787086774x1151984647_lam1(V self, V *args);
V g_heff_2ebuild_2ebenchmarks_2ecountGiven_24s1787086774x1151984647_lam4(V self, V *args);
V g_heff_2ebuild_2ebenchmarks_2ecountGiven_24s1787086774x1151984647_lam7(V self, V *args);
V g_heff_2ebuild_2ebenchmarks_2ecountGiven_24s1787086774x1151984647_lam6(V self, V *args);
V g_heff_2ebuild_2ebenchmarks_2ecountGiven_24s1787086774x1151984647_lam5(V self, V *args);
Clo g_heff_2ebuild_2ebenchmarks_2ecountGiven_24s1787086774x1151984647_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebenchmarks_2ecountGiven_24s1787086774x1151984647_entry, 1, 0};

V g_heff_2ebuild_2ebenchmarks_2ecountGiven_24s1787086774x1151984647(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nothing: {
    return ((V)&g_heff_2ebuild_2ebenchmarks_2ecountGiven_24s1787086774x1151984647_lam0_clo);
  }
  case TAG_Just: {
    V v_s_243 = heff_field(v_x1_240, 0);
    heff_take_n(v_x1_240, 1ULL, 1);
    V v_t_247;
    if ((((int64_t)0ULL) < heff_unbox_word(heff_strLength_lent(v_s_243, 0)))) {
      int64_t v_t_244 = (heff_unbox_word(heff_strLength_lent(v_s_243, 0)) - ((int64_t)1ULL));
      V v_t_245 = (g_list_2erange(MK_INT(0LL), heff_box_word(v_t_244)));
      V v_t_246 = ({ V a_0 = MK_INT(48LL); V a_1 = v_s_243; V a_2 = MK_INT(57LL); V a_3 = v_t_245; V r_ = (g_list_2eall_24s2093734251x1702493483(a_0, a_1, a_2, a_3)); heff_drop(v_t_245); r_; });
      if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
        heff_drop(v_t_246);
        v_t_247 = (g_prelude_2eparseInt(v_s_243));
      } else {
        heff_drop(v_t_246);
        v_t_247 = NTAG(TAG_Nothing);
      }
    } else {
      v_t_247 = NTAG(TAG_Nothing);
    }
    switch (heff_tag_of(v_t_247)) {
    case TAG_Nothing: {
      return heff_clo_n(g_heff_2ebuild_2ebenchmarks_2ecountGiven_24s1787086774x1151984647_lam1, 2, 1, (V[]){v_s_243});
    }
    case TAG_Just: {
      V v_n_2431 = heff_field(v_t_247, 0);
      heff_take_n(v_t_247, 1ULL, 1);
      if (heff_intLt_c_lent(MK_INT(0LL), v_n_2431, 1)) {
        heff_drop(v_s_243);
        return heff_clo_n(g_heff_2ebuild_2ebenchmarks_2ecountGiven_24s1787086774x1151984647_lam4, 2, 1, (V[]){v_n_2431});
      } else {
        heff_drop(v_n_2431);
        return heff_clo_n(g_heff_2ebuild_2ebenchmarks_2ecountGiven_24s1787086774x1151984647_lam5, 2, 1, (V[]){v_s_243});
      }
    }
    default: return heff_nomatch(v_t_247);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2ebenchmarks_2ecountGiven_24s1787086774x1151984647_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ebenchmarks_2ecountGiven_24s1787086774x1151984647(a[0]);
}
V g_heff_2ebuild_2ebenchmarks_2ecountGiven_24s1787086774x1151984647_lam0(V self, V *args) {
  V v_hd_241 = args[0];
  V v_k_242 = args[1];
  heff_drop(v_hd_241);
  V f_ = v_k_242;
  args[0] = MK_INT(1LL);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ebenchmarks_2ecountGiven_24s1787086774x1151984647_lam3(V self, V *args) {
  V v_x_2430 = args[0];
  V v_k_249 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2430);
  V f_ = v_k_249;
  args[0] = MK_INT(1LL);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ebenchmarks_2ecountGiven_24s1787086774x1151984647_lam2(V self, V *args) {
  V v_x_2421 = args[0];
  V v_malg_2411 = heff_env(self)[0];
  V v_bind_2410 = heff_env(self)[1];
  V v_k_249 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2421);
  V v_t_2422 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(2LL), NTAG(TAG_MkUnit)});
  V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2422})});
  V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
  V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
  V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
  V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
  V v_t_2428 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2427})});
  V v_t_2429 = heff_tr(heff_call(v_malg_2411, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2428})}));
  V f_ = v_bind_2410;
  heff_room[0] = v_t_2429;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ebenchmarks_2ecountGiven_24s1787086774x1151984647_lam3, 1, 1, (V[]){v_k_249});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ebenchmarks_2ecountGiven_24s1787086774x1151984647_lam1(V self, V *args) {
  V v_hd_248 = args[0];
  V v_k_249 = args[1];
  V v_s_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_bind_2410 = heff_take_field(v_hd_248, 1);
  V v_malg_2411 = heff_get_n(v_hd_248, 2, 3);
  V v_t_2412 = heff_strAppend(((V)&g_heff_2ebuild_2ebenchmarks_2ecountGiven_24s1787086774x1151984647_str0), heff_strAppend(v_s_243, ((V)&g_heff_2ebuild_2ebenchmarks_2ecountGiven_24s1787086774x1151984647_str1)));
  V v_t_2413 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_t_2412, ((V)&g_heff_2ebuild_2ebenchmarks_2ecountGiven_24s1787086774x1151984647_str2)), NTAG(TAG_MkUnit)});
  V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
  V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tr(heff_call(heff_dup(v_malg_2411), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2419})}));
  V f_ = heff_dup(v_bind_2410);
  args[0] = v_t_2420;
  args[1] = heff_clo_n(g_heff_2ebuild_2ebenchmarks_2ecountGiven_24s1787086774x1151984647_lam2, 1, 3, (V[]){v_malg_2411, v_bind_2410, v_k_249});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2ebenchmarks_2ecountGiven_24s1787086774x1151984647_lam4(V self, V *args) {
  V v_hd_2432 = args[0];
  V v_k_2433 = args[1];
  V v_n_2431 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2432);
  V f_ = v_k_2433;
  args[0] = v_n_2431;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ebenchmarks_2ecountGiven_24s1787086774x1151984647_lam7(V self, V *args) {
  V v_x_2456 = args[0];
  V v_k_2435 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2456);
  V f_ = v_k_2435;
  args[0] = MK_INT(1LL);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ebenchmarks_2ecountGiven_24s1787086774x1151984647_lam6(V self, V *args) {
  V v_x_2447 = args[0];
  V v_malg_2437 = heff_env(self)[0];
  V v_bind_2436 = heff_env(self)[1];
  V v_k_2435 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2447);
  V v_t_2448 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(2LL), NTAG(TAG_MkUnit)});
  V v_t_2449 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2448})});
  V v_t_2450 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2449})});
  V v_t_2451 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2450})});
  V v_t_2452 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2451})});
  V v_t_2453 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2452})});
  V v_t_2454 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2453})});
  V v_t_2455 = heff_tr(heff_call(v_malg_2437, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2454})}));
  V f_ = v_bind_2436;
  heff_room[0] = v_t_2455;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ebenchmarks_2ecountGiven_24s1787086774x1151984647_lam7, 1, 1, (V[]){v_k_2435});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ebenchmarks_2ecountGiven_24s1787086774x1151984647_lam5(V self, V *args) {
  V v_hd_2434 = args[0];
  V v_k_2435 = args[1];
  V v_s_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_bind_2436 = heff_take_field(v_hd_2434, 1);
  V v_malg_2437 = heff_get_n(v_hd_2434, 2, 3);
  V v_t_2438 = heff_strAppend(((V)&g_heff_2ebuild_2ebenchmarks_2ecountGiven_24s1787086774x1151984647_str3), heff_strAppend(v_s_243, ((V)&g_heff_2ebuild_2ebenchmarks_2ecountGiven_24s1787086774x1151984647_str4)));
  V v_t_2439 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_t_2438, ((V)&g_heff_2ebuild_2ebenchmarks_2ecountGiven_24s1787086774x1151984647_str5)), NTAG(TAG_MkUnit)});
  V v_t_2440 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2439})});
  V v_t_2441 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2440})});
  V v_t_2442 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2441})});
  V v_t_2443 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2442})});
  V v_t_2444 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2443})});
  V v_t_2445 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2444})});
  V v_t_2446 = heff_tr(heff_call(heff_dup(v_malg_2437), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2445})}));
  V f_ = heff_dup(v_bind_2436);
  args[0] = v_t_2446;
  args[1] = heff_clo_n(g_heff_2ebuild_2ebenchmarks_2ecountGiven_24s1787086774x1151984647_lam6, 1, 3, (V[]){v_malg_2437, v_bind_2436, v_k_2435});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2esaidRun_24s832625301x247770201_str0, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2esaidRun_24s832625301x247770201_str1, 1, "\012");
Clo g_heff_2ebuild_2ebenchmarks_2esaidRun_24s832625301x247770201_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebenchmarks_2esaidRun_24s832625301x247770201_entry, 5, 0};

V g_heff_2ebuild_2ebenchmarks_2esaidRun_24s832625301x247770201(V v_opts_240, V v_f_241, V v_width_242, V v_names_243, V v_o_244) {
top: ;
  V v_t_245 = heff_get_n(v_opts_240, 3, 4);
  if ((heff_dup(v_t_245) == NTAG(TAG_True))) {
    heff_drop(v_width_242);
    heff_drop(v_t_245);
    V v_str_246 = (g_heff_2ebuild_2ebenchmarks_2eoutcomeJson(v_f_241, v_names_243, v_o_244));
    V v_t_247 = heff_tag_n(TAG_Write, 2, (V[]){heff_strAppend(v_str_246, ((V)&g_heff_2ebuild_2ebenchmarks_2esaidRun_24s832625301x247770201_str0)), NTAG(TAG_MkUnit)});
    V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
    V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
    V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
    V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
    V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
    V v_t_2413 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2412})});
    return heff_tail(((V)&g_co_2eop_24s847889387x1388281137_clo), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2413})});
  } else {
    heff_drop(v_f_241);
    heff_drop(v_t_245);
    V v_str_2414 = ({ V a_0 = v_width_242; V a_1 = v_names_243; V a_2 = v_o_244; V r_ = (g_heff_2ebuild_2ebenchmarks_2eoutcomeText(a_0, a_1, a_2)); heff_drop(v_names_243); heff_drop(v_o_244); r_; });
    V v_t_2415 = heff_tag_n(TAG_Write, 2, (V[]){heff_strAppend(v_str_2414, ((V)&g_heff_2ebuild_2ebenchmarks_2esaidRun_24s832625301x247770201_str1)), NTAG(TAG_MkUnit)});
    V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
    V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
    V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
    V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
    V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
    V v_t_2421 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2420})});
    return heff_tail(((V)&g_co_2eop_24s847889387x1388281137_clo), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2421})});
  }
}
V g_heff_2ebuild_2ebenchmarks_2esaidRun_24s832625301x247770201_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ebenchmarks_2esaidRun_24s832625301x247770201(a[0], a[1], a[2], a[3], a[4]);
}
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2erunTimes_24s650970993x1258428477_str0, 1, "0");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2erunTimes_24s650970993x1258428477_str1, 3, "run");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2erunTimes_24s650970993x1258428477_str2, 3, "run");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2erunTimes_24s650970993x1258428477_str3, 1, "0");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2erunTimes_24s650970993x1258428477_str4, 0, "");
V g_heff_2ebuild_2ebenchmarks_2erunTimes_24s650970993x1258428477_lam0(V self, V *args);
V g_heff_2ebuild_2ebenchmarks_2erunTimes_24s650970993x1258428477_lam1(V self, V *args); static Clo g_heff_2ebuild_2ebenchmarks_2erunTimes_24s650970993x1258428477_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebenchmarks_2erunTimes_24s650970993x1258428477_lam1, 1, 0};
V g_heff_2ebuild_2ebenchmarks_2erunTimes_24s650970993x1258428477_lam4(V self, V *args);
V g_heff_2ebuild_2ebenchmarks_2erunTimes_24s650970993x1258428477_lam3(V self, V *args);
V g_heff_2ebuild_2ebenchmarks_2erunTimes_24s650970993x1258428477_lam2(V self, V *args);
Clo g_heff_2ebuild_2ebenchmarks_2erunTimes_24s650970993x1258428477_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebenchmarks_2erunTimes_24s650970993x1258428477_entry, 7, 0};

V g_heff_2ebuild_2ebenchmarks_2erunTimes_24s650970993x1258428477(V v_opts_240, V v_f_241, V v_prog_242, V v_width_243, V v_names_244, V v_left_245, V v_acc_246) {
top: ;
  if (heff_intLe_c_lent(v_left_245, MK_INT(0LL), 2)) {
    heff_drop_rec(v_opts_240, 4);
    heff_drop(v_f_241);
    heff_drop(v_prog_242);
    heff_drop(v_width_243);
    heff_drop(v_names_244);
    heff_drop(v_left_245);
    return heff_clo_n(g_heff_2ebuild_2ebenchmarks_2erunTimes_24s650970993x1258428477_lam0, 2, 1, (V[]){v_acc_246});
  } else {
    V v_t_249 = heff_dup(heff_rfield(v_opts_240, 1));
    V v_t_2414;
    switch (heff_tag_of(v_t_249)) {
    case TAG_Nanos: {
      V v_ns_2410 = heff_field(v_t_249, 0);
      heff_take_n(v_t_249, 1ULL, 1);
      V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_ns_2410), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ebenchmarks_2erunTimes_24s650970993x1258428477_str0), heff_dup(v_names_244)})});
      v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ebenchmarks_2erunTimes_24s650970993x1258428477_str1), v_t_2411});
      break;
    }
    case TAG_Times: {
      V v_n_2412 = heff_field(v_t_249, 0);
      heff_take_n(v_t_249, 1ULL, 1);
      V v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){heff_intShow(v_n_2412), heff_dup(v_names_244)});
      v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ebenchmarks_2erunTimes_24s650970993x1258428477_str2), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ebenchmarks_2erunTimes_24s650970993x1258428477_str3), v_t_2413})});
      break;
    }
    default: heff_nomatch(v_t_249);
    }
    V v_t_2415 = ({ V b_0 = NTAG(TAG_Nil); V b_1 = NTAG(TAG_Nil); V r_ = (g_std_2epath_2esameSegments(b_0, b_1)); heff_drop(b_0); heff_drop(b_1); r_; });
    V v_t_2416;
    if ((heff_dup(v_t_2415) == NTAG(TAG_True))) {
      heff_drop(v_t_2415);
      v_t_2416 = ((V)&g_heff_2ebuild_2ebenchmarks_2erunTimes_24s650970993x1258428477_str4);
    } else {
      heff_drop(v_t_2415);
      v_t_2416 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V b_1 = heff_dup(g_std_2epath_2ecurrent_get()); V r_ = (g_std_2epath_2erender(b_0, b_1)); heff_drop(b_0); heff_drop(b_1); r_; });
    }
    V v_t_2417 = heff_rec_n(10, shape_command__args__dir__env__input__output__errors__timeout__keep__group, (V[]){heff_dup(v_prog_242), v_t_2414, v_t_2416, NTAG(TAG_Nil), NTAG(TAG_NoInput), NTAG(TAG_Collected), NTAG(TAG_Collected), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_False)});
    V v_a_2419 = heff_tag_n(TAG_Run, 2, (V[]){v_t_2417, ((V)&g_heff_2ebuild_2ebenchmarks_2erunTimes_24s650970993x1258428477_lam1_clo)});
    return heff_clo_n(g_heff_2ebuild_2ebenchmarks_2erunTimes_24s650970993x1258428477_lam2, 2, 8, (V[]){v_a_2419, v_opts_240, v_f_241, v_width_243, v_names_244, v_acc_246, v_prog_242, v_left_245});
  }
}
V g_heff_2ebuild_2ebenchmarks_2erunTimes_24s650970993x1258428477_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ebenchmarks_2erunTimes_24s650970993x1258428477(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
V g_heff_2ebuild_2ebenchmarks_2erunTimes_24s650970993x1258428477_lam0(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_acc_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_247);
  V f_ = v_k_248;
  args[0] = v_acc_246;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ebenchmarks_2erunTimes_24s650970993x1258428477_lam1(V self, V *args) {
  V v_r_2418 = args[0];
  return v_r_2418;
}
V g_heff_2ebuild_2ebenchmarks_2erunTimes_24s650970993x1258428477_lam4(V self, V *args) {
  V v_x_2432 = args[0];
  V v_x_2430 = heff_env(self)[0];
  V v_acc_246 = heff_env(self)[1];
  V v_opts_240 = heff_env(self)[2];
  V v_f_241 = heff_env(self)[3];
  V v_prog_242 = heff_env(self)[4];
  V v_width_243 = heff_env(self)[5];
  V v_names_244 = heff_env(self)[6];
  V v_left_245 = heff_env(self)[7];
  V v_hd_2420 = heff_env(self)[8];
  V v_k_2421 = heff_env(self)[9];
  heff_clo_take(self, 10);
  heff_drop(v_x_2432);
  switch (heff_tag_of(v_x_2430)) {
  case TAG_Measured: {
    heff_take_n(v_x_2430, 0ULL, 4);
    V v_t_2437 = heff_intAdd(heff_take_field(v_acc_246, 0), MK_INT(1LL));
    V v_t_2438 = ({ V rv_0 = v_t_2437; V rr_ = heff_rec_reuse_nf(v_acc_246, 2ULL, 2, shape_ran__failed, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
    V v_t_2439 = (g_heff_2ebuild_2ebenchmarks_2erunTimes_24s650970993x1258428477(v_opts_240, v_f_241, v_prog_242, v_width_243, v_names_244, heff_intSub(v_left_245, MK_INT(1LL)), v_t_2438));
    V f_ = v_t_2439;
    heff_room[0] = v_hd_2420;
    heff_room[1] = v_k_2421;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_FailedWith: {
    heff_drop_rec(v_opts_240, 4);
    heff_drop(v_f_241);
    heff_drop(v_prog_242);
    heff_drop(v_width_243);
    heff_drop(v_names_244);
    heff_drop(v_left_245);
    heff_drop_rec(v_hd_2420, 3);
    V v_t_2441 = heff_intAdd(heff_take_field(v_acc_246, 0), MK_INT(1LL));
    V v_t_2448;
    switch (heff_tag_of(v_x_2430)) {
    case TAG_Measured: {
      heff_take_n(v_x_2430, 0ULL, 4);
      v_t_2448 = MK_INT(0LL);
      break;
    }
    case TAG_FailedWith: {
      heff_take_n(v_x_2430, 0ULL, 1);
      v_t_2448 = MK_INT(1LL);
      break;
    }
    case TAG_SkippedWith: {
      heff_take_n(v_x_2430, 0ULL, 1);
      v_t_2448 = MK_INT(0LL);
      break;
    }
    default: heff_nomatch(v_x_2430);
    }
    V v_t_2449 = heff_intAdd(heff_get_n(v_acc_246, 1, 2), v_t_2448);
    V f_ = v_k_2421;
    args[0] = heff_rec_n(2, shape_ran__failed, (V[]){v_t_2441, v_t_2449});
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_SkippedWith: {
    heff_drop_rec(v_opts_240, 4);
    heff_drop(v_f_241);
    heff_drop(v_prog_242);
    heff_drop(v_width_243);
    heff_drop(v_names_244);
    heff_drop(v_left_245);
    heff_drop_rec(v_hd_2420, 3);
    V v_t_2451 = heff_intAdd(heff_take_field(v_acc_246, 0), MK_INT(1LL));
    V v_t_2458;
    switch (heff_tag_of(v_x_2430)) {
    case TAG_Measured: {
      heff_take_n(v_x_2430, 0ULL, 4);
      v_t_2458 = MK_INT(0LL);
      break;
    }
    case TAG_FailedWith: {
      heff_take_n(v_x_2430, 0ULL, 1);
      v_t_2458 = MK_INT(1LL);
      break;
    }
    case TAG_SkippedWith: {
      heff_take_n(v_x_2430, 0ULL, 1);
      v_t_2458 = MK_INT(0LL);
      break;
    }
    default: heff_nomatch(v_x_2430);
    }
    V v_t_2459 = heff_intAdd(heff_get_n(v_acc_246, 1, 2), v_t_2458);
    V f_ = v_k_2421;
    args[0] = heff_rec_n(2, shape_ran__failed, (V[]){v_t_2451, v_t_2459});
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_2430);
  }
}
V g_heff_2ebuild_2ebenchmarks_2erunTimes_24s650970993x1258428477_lam3(V self, V *args) {
  V v_x_2429 = args[0];
  V v_opts_240 = heff_env(self)[0];
  V v_f_241 = heff_env(self)[1];
  V v_width_243 = heff_env(self)[2];
  V v_names_244 = heff_env(self)[3];
  V v_hd_2420 = heff_env(self)[4];
  V v_acc_246 = heff_env(self)[5];
  V v_prog_242 = heff_env(self)[6];
  V v_left_245 = heff_env(self)[7];
  V v_k_2421 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_x_2430 = (g_heff_2ebuild_2ebenchmarks_2eoutcomeOfRan(v_x_2429));
  V v_c_2431 = heff_tr(g_heff_2ebuild_2ebenchmarks_2esaidRun_24s832625301x247770201(heff_dup(v_opts_240), heff_dup(v_f_241), heff_dup(v_width_243), heff_dup(v_names_244), heff_dup(v_x_2430)));
  V f_ = v_c_2431;
  heff_room[0] = heff_dup(v_hd_2420);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ebenchmarks_2erunTimes_24s650970993x1258428477_lam4, 1, 10, (V[]){v_x_2430, v_acc_246, v_opts_240, v_f_241, v_prog_242, v_width_243, v_names_244, v_left_245, v_hd_2420, v_k_2421});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ebenchmarks_2erunTimes_24s650970993x1258428477_lam2(V self, V *args) {
  V v_hd_2420 = args[0];
  V v_k_2421 = args[1];
  V v_a_2419 = heff_env(self)[0];
  V v_opts_240 = heff_env(self)[1];
  V v_f_241 = heff_env(self)[2];
  V v_width_243 = heff_env(self)[3];
  V v_names_244 = heff_env(self)[4];
  V v_acc_246 = heff_env(self)[5];
  V v_prog_242 = heff_env(self)[6];
  V v_left_245 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2419})});
  V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
  V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
  V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
  V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
  V v_t_2427 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2426})});
  V v_t_2428 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_2420, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2427})}));
  V f_ = heff_dup(heff_rfield(v_hd_2420, 1));
  args[0] = v_t_2428;
  args[1] = heff_clo_n(g_heff_2ebuild_2ebenchmarks_2erunTimes_24s650970993x1258428477_lam3, 1, 9, (V[]){v_opts_240, v_f_241, v_width_243, v_names_244, v_hd_2420, v_acc_246, v_prog_242, v_left_245, v_k_2421});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2ebenchmarks_2erunEach_24s4089150x124991981_lam0(V self, V *args);
V g_heff_2ebuild_2ebenchmarks_2erunEach_24s4089150x124991981_lam2(V self, V *args);
V g_heff_2ebuild_2ebenchmarks_2erunEach_24s4089150x124991981_lam1(V self, V *args);
Clo g_heff_2ebuild_2ebenchmarks_2erunEach_24s4089150x124991981_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebenchmarks_2erunEach_24s4089150x124991981_entry, 6, 0};

V g_heff_2ebuild_2ebenchmarks_2erunEach_24s4089150x124991981(V v_opts_240, V v_f_241, V v_prog_242, V v_width_243, V v_x5_244, V v_acc_245) {
top: ;
  switch (heff_tag_of(v_x5_244)) {
  case TAG_Nil: {
    heff_drop_rec(v_opts_240, 4);
    heff_drop(v_f_241);
    heff_drop(v_prog_242);
    heff_drop(v_width_243);
    return heff_clo_n(g_heff_2ebuild_2ebenchmarks_2erunEach_24s4089150x124991981_lam0, 2, 1, (V[]){v_acc_245});
  }
  case TAG_Cons: {
    V v_names_248 = heff_field(v_x5_244, 0);
    V v_rest_249 = heff_field(v_x5_244, 1);
    V v_c_2410 = (g_heff_2ebuild_2ebenchmarks_2erunTimes_24s650970993x1258428477(heff_dup(v_opts_240), heff_dup(v_f_241), heff_dup(v_prog_242), heff_dup(v_width_243), heff_dup(v_names_248), heff_dup(heff_rfield(v_opts_240, 2)), v_acc_245));
    return heff_clo_n(g_heff_2ebuild_2ebenchmarks_2erunEach_24s4089150x124991981_lam1, 2, 6, (V[]){v_c_2410, v_opts_240, v_f_241, v_prog_242, v_width_243, heff_dup(v_rest_249)});
  }
  default: return heff_nomatch(v_x5_244);
  }
}
V g_heff_2ebuild_2ebenchmarks_2erunEach_24s4089150x124991981_entry(V self, V *a) {
  (void)self;
  V a4 = a[4]; V r = g_heff_2ebuild_2ebenchmarks_2erunEach_24s4089150x124991981(a[0], a[1], a[2], a[3], a4, a[5]); heff_drop(a4); return r;
}
V g_heff_2ebuild_2ebenchmarks_2erunEach_24s4089150x124991981_lam0(V self, V *args) {
  V v_hd_246 = args[0];
  V v_k_247 = args[1];
  V v_acc_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_246);
  V f_ = v_k_247;
  args[0] = v_acc_245;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ebenchmarks_2erunEach_24s4089150x124991981_lam2(V self, V *args) {
  V v_x_2413 = args[0];
  V v_opts_240 = heff_env(self)[0];
  V v_f_241 = heff_env(self)[1];
  V v_prog_242 = heff_env(self)[2];
  V v_width_243 = heff_env(self)[3];
  V v_rest_249 = heff_env(self)[4];
  V v_hd_2411 = heff_env(self)[5];
  V v_k_2412 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2414 = ({ V a_0 = v_opts_240; V a_1 = v_f_241; V a_2 = v_prog_242; V a_3 = v_width_243; V a_4 = v_rest_249; V a_5 = v_x_2413; V r_ = (g_heff_2ebuild_2ebenchmarks_2erunEach_24s4089150x124991981(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_rest_249); r_; });
  V f_ = v_t_2414;
  heff_room[0] = v_hd_2411;
  heff_room[1] = v_k_2412;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ebenchmarks_2erunEach_24s4089150x124991981_lam1(V self, V *args) {
  V v_hd_2411 = args[0];
  V v_k_2412 = args[1];
  V v_c_2410 = heff_env(self)[0];
  V v_opts_240 = heff_env(self)[1];
  V v_f_241 = heff_env(self)[2];
  V v_prog_242 = heff_env(self)[3];
  V v_width_243 = heff_env(self)[4];
  V v_rest_249 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V f_ = v_c_2410;
  args[0] = heff_dup(v_hd_2411);
  args[1] = heff_clo_n(g_heff_2ebuild_2ebenchmarks_2erunEach_24s4089150x124991981_lam2, 1, 7, (V[]){v_opts_240, v_f_241, v_prog_242, v_width_243, v_rest_249, v_hd_2411, v_k_2412});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2erunListed_24s936792459x264817624_str0, 5, "pkg: ");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2erunListed_24s936792459x264817624_str1, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2erunListed_24s936792459x264817624_str2, 9, "Benchmark");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2erunListed_24s936792459x264817624_str3, 9, "Benchmark");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2erunListed_24s936792459x264817624_str4, 1, "/");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2erunListed_24s936792459x264817624_str5, 6, "FAIL  ");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2erunListed_24s936792459x264817624_str6, 6, "ok    ");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2erunListed_24s936792459x264817624_str7, 1, "\012");
V g_heff_2ebuild_2ebenchmarks_2erunListed_24s936792459x264817624_lam0(V self, V *args); static Clo g_heff_2ebuild_2ebenchmarks_2erunListed_24s936792459x264817624_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebenchmarks_2erunListed_24s936792459x264817624_lam0, 2, 0};
V g_heff_2ebuild_2ebenchmarks_2erunListed_24s936792459x264817624_lam1(V self, V *args);
V g_heff_2ebuild_2ebenchmarks_2erunListed_24s936792459x264817624_lam4(V self, V *args); static Clo g_heff_2ebuild_2ebenchmarks_2erunListed_24s936792459x264817624_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebenchmarks_2erunListed_24s936792459x264817624_lam4, 2, 0};
V g_heff_2ebuild_2ebenchmarks_2erunListed_24s936792459x264817624_lam5(V self, V *args);
V g_heff_2ebuild_2ebenchmarks_2erunListed_24s936792459x264817624_lam6(V self, V *args);
V g_heff_2ebuild_2ebenchmarks_2erunListed_24s936792459x264817624_lam3(V self, V *args);
V g_heff_2ebuild_2ebenchmarks_2erunListed_24s936792459x264817624_lam2(V self, V *args);
Clo g_heff_2ebuild_2ebenchmarks_2erunListed_24s936792459x264817624_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebenchmarks_2erunListed_24s936792459x264817624_entry, 6, 0};

V g_heff_2ebuild_2ebenchmarks_2erunListed_24s936792459x264817624(V v_opts_240, V v_f_241, V v_prog_242, V v_bs_243, V v_p_244, V v_p_245) {
top: ;
  switch (heff_tag_of(v_bs_243)) {
  case TAG_Nil: {
    heff_drop_rec(v_opts_240, 4);
    heff_drop(v_f_241);
    heff_drop(v_prog_242);
    heff_drop(v_p_244);
    return heff_tail(v_p_245, 1, (V[]){heff_rec_n(2, shape_ran__failed, (V[]){MK_INT(0LL), MK_INT(0LL)})});
  }
  case TAG_Cons: {
    V v_t_248 = heff_dup(heff_rfield(v_opts_240, 3));
    V v_t_2424;
    if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
      heff_drop(v_t_248);
      v_t_2424 = ((V)&g_heff_2ebuild_2ebenchmarks_2erunListed_24s936792459x264817624_lam0_clo);
    } else {
      heff_drop(v_t_248);
      v_t_2424 = heff_clo_n(g_heff_2ebuild_2ebenchmarks_2erunListed_24s936792459x264817624_lam1, 2, 1, (V[]){heff_dup(v_f_241)});
    }
    return heff_tail(v_t_2424, 2, (V[]){heff_dup(v_p_244), heff_clo_n(g_heff_2ebuild_2ebenchmarks_2erunListed_24s936792459x264817624_lam2, 1, 6, (V[]){v_bs_243, v_opts_240, v_f_241, v_prog_242, v_p_244, v_p_245})});
  }
  default: return heff_nomatch(v_bs_243);
  }
}
V g_heff_2ebuild_2ebenchmarks_2erunListed_24s936792459x264817624_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ebenchmarks_2erunListed_24s936792459x264817624(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2ebuild_2ebenchmarks_2erunListed_24s936792459x264817624_lam0(V self, V *args) {
  V v_hd_249 = args[0];
  V v_k_2410 = args[1];
  heff_drop(v_hd_249);
  V f_ = v_k_2410;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ebenchmarks_2erunListed_24s936792459x264817624_lam1(V self, V *args) {
  V v_hd_2411 = args[0];
  V v_k2_2412 = args[1];
  V v_f_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_bind_2413 = heff_take_field(v_hd_2411, 1);
  V v_malg_2414 = heff_get_n(v_hd_2411, 2, 3);
  V v_t_2415 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ebenchmarks_2erunListed_24s936792459x264817624_str0), v_f_241), ((V)&g_heff_2ebuild_2ebenchmarks_2erunListed_24s936792459x264817624_str1));
  V v_t_2416 = heff_tag_n(TAG_Write, 2, (V[]){v_t_2415, NTAG(TAG_MkUnit)});
  V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
  V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
  V v_t_2422 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2421})});
  V v_t_2423 = heff_tr(heff_call(v_malg_2414, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2422})}));
  V f_ = v_bind_2413;
  args[0] = v_t_2423;
  args[1] = v_k2_2412;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2ebenchmarks_2erunListed_24s936792459x264817624_lam4(V self, V *args) {
  V v_hd_2430 = args[0];
  V v_k_2431 = args[1];
  heff_drop(v_hd_2430);
  V f_ = v_k_2431;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ebenchmarks_2erunListed_24s936792459x264817624_lam5(V self, V *args) {
  V v_hd_2432 = args[0];
  V v_k2_2433 = args[1];
  V v_x_2428 = heff_env(self)[0];
  V v_f_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_bind_2434 = heff_take_field(v_hd_2432, 1);
  V v_malg_2435 = heff_get_n(v_hd_2432, 2, 3);
  V v_t_2436;
  if (heff_intLt_c(MK_INT(0LL), heff_get_n(v_x_2428, 1, 2))) {
    v_t_2436 = ((V)&g_heff_2ebuild_2ebenchmarks_2erunListed_24s936792459x264817624_str5);
  } else {
    v_t_2436 = ((V)&g_heff_2ebuild_2ebenchmarks_2erunListed_24s936792459x264817624_str6);
  }
  V v_t_2437 = heff_strAppend(heff_strAppend(v_t_2436, v_f_241), ((V)&g_heff_2ebuild_2ebenchmarks_2erunListed_24s936792459x264817624_str7));
  V v_t_2438 = heff_tag_n(TAG_Write, 2, (V[]){v_t_2437, NTAG(TAG_MkUnit)});
  V v_t_2439 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2438})});
  V v_t_2440 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2439})});
  V v_t_2441 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2440})});
  V v_t_2442 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2441})});
  V v_t_2443 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2442})});
  V v_t_2444 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2443})});
  V v_t_2445 = heff_tr(heff_call(v_malg_2435, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2444})}));
  V f_ = v_bind_2434;
  args[0] = v_t_2445;
  args[1] = v_k2_2433;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2ebenchmarks_2erunListed_24s936792459x264817624_lam6(V self, V *args) {
  V v_x_2447 = args[0];
  V v_p_245 = heff_env(self)[0];
  V v_x_2428 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2447);
  V f_ = v_p_245;
  args[0] = v_x_2428;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ebenchmarks_2erunListed_24s936792459x264817624_lam3(V self, V *args) {
  V v_x_2428 = args[0];
  V v_opts_240 = heff_env(self)[0];
  V v_f_241 = heff_env(self)[1];
  V v_p_244 = heff_env(self)[2];
  V v_p_245 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2429 = heff_get_n(v_opts_240, 3, 4);
  V v_t_2446;
  if ((heff_dup(v_t_2429) == NTAG(TAG_True))) {
    heff_drop(v_f_241);
    heff_drop(v_t_2429);
    v_t_2446 = ((V)&g_heff_2ebuild_2ebenchmarks_2erunListed_24s936792459x264817624_lam4_clo);
  } else {
    heff_drop(v_t_2429);
    v_t_2446 = heff_clo_n(g_heff_2ebuild_2ebenchmarks_2erunListed_24s936792459x264817624_lam5, 2, 2, (V[]){heff_dup(v_x_2428), v_f_241});
  }
  V f_ = v_t_2446;
  heff_room[0] = v_p_244;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ebenchmarks_2erunListed_24s936792459x264817624_lam6, 1, 2, (V[]){v_p_245, v_x_2428});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ebenchmarks_2erunListed_24s936792459x264817624_lam2(V self, V *args) {
  V v_x_2425 = args[0];
  V v_bs_243 = heff_env(self)[0];
  V v_opts_240 = heff_env(self)[1];
  V v_f_241 = heff_env(self)[2];
  V v_prog_242 = heff_env(self)[3];
  V v_p_244 = heff_env(self)[4];
  V v_p_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_2425);
  V v_t_2426 = (g_list_2efoldl_24s141260856x1366916752(((V)&g_heff_2ebuild_2ebenchmarks_2erunListed_24s936792459x264817624_str2), ((V)&g_heff_2ebuild_2ebenchmarks_2erunListed_24s936792459x264817624_str3), ((V)&g_heff_2ebuild_2ebenchmarks_2erunListed_24s936792459x264817624_str4), MK_INT(0LL), v_bs_243));
  V v_c_2427 = ({ V a_0 = heff_dup(v_opts_240); V a_1 = heff_dup(v_f_241); V a_2 = v_prog_242; V a_3 = v_t_2426; V a_4 = v_bs_243; V a_5 = heff_rec_n(2, shape_ran__failed, (V[]){MK_INT(0LL), MK_INT(0LL)}); V r_ = (g_heff_2ebuild_2ebenchmarks_2erunEach_24s4089150x124991981(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop_tag(v_bs_243, 2); r_; });
  V f_ = v_c_2427;
  heff_room[0] = heff_dup(v_p_244);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ebenchmarks_2erunListed_24s936792459x264817624_lam3, 1, 4, (V[]){v_opts_240, v_f_241, v_p_244, v_p_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s885862188x1878351915_str0, 12, ": benchmarks");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s885862188x1878351915_str1, 14, "compiling to C");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s885862188x1878351915_str2, 19, "-DHEFF_COUNT_ALLOCS");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s885862188x1878351915_str3, 4, "main");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s885862188x1878351915_str4, 8, "main.exe");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s885862188x1878351915_str5, 10, "heff bench");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s885862188x1878351915_str6, 3, "-O2");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s885862188x1878351915_str7, 4, "main");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s885862188x1878351915_str8, 8, "main.exe");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s885862188x1878351915_str9, 4, "main");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s885862188x1878351915_str10, 8, "main.exe");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s885862188x1878351915_str11, 1, "/");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s885862188x1878351915_str12, 34, "its file is not among those loaded");
V g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s885862188x1878351915_lam0(V self, V *args);
V g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s885862188x1878351915_lam1(V self, V *args); static Clo g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s885862188x1878351915_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s885862188x1878351915_lam1, 1, 0};
V g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s885862188x1878351915_lam3(V self, V *args); static Clo g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s885862188x1878351915_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s885862188x1878351915_lam3, 1, 0};
V g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s885862188x1878351915_lam7(V self, V *args);
V g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s885862188x1878351915_lam6(V self, V *args);
V g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s885862188x1878351915_lam5(V self, V *args);
V g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s885862188x1878351915_lam10(V self, V *args); static Clo g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s885862188x1878351915_lam10_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s885862188x1878351915_lam10, 1, 0};
V g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s885862188x1878351915_lam12(V self, V *args);
V g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s885862188x1878351915_lam11(V self, V *args);
V g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s885862188x1878351915_lam9(V self, V *args);
V g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s885862188x1878351915_lam8(V self, V *args);
V g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s885862188x1878351915_lam16(V self, V *args);
V g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s885862188x1878351915_lam15(V self, V *args);
V g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s885862188x1878351915_lam14(V self, V *args);
V g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s885862188x1878351915_lam13(V self, V *args);
V g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s885862188x1878351915_lam18(V self, V *args);
V g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s885862188x1878351915_lam17(V self, V *args);
V g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s885862188x1878351915_lam4(V self, V *args);
V g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s885862188x1878351915_lam2(V self, V *args);
V g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s885862188x1878351915_lam19(V self, V *args);
Clo g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s885862188x1878351915_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s885862188x1878351915_entry, 9, 0};

V g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s885862188x1878351915(V v_rep_240, V v_prog_241, V v_opts_242, V v_f_243, V v_l_244, V v_c_245, V v_k_246, V v_z_247, V v_z_248) {
top: ;
  HeffT2 v_t_249 = (g_list_2efind_24s4435330x644005164_24cpr(heff_dup(v_c_245), heff_dup(heff_rfield(v_l_244, 0))));
  {
    V v_field_2411 = v_t_249.f[1];
    int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
    if ((v_tag_2410 == ((int64_t)0ULL))) {
      V v_src_2412 = v_field_2411;
      HeffT2 v_t_2413 = (g_heff_2ebuild_2ebenchmarks_2ebenchAdded_24cpr(heff_dup(v_l_244), v_c_245, v_src_2412));
      {
        V v_field_2415 = v_t_2413.f[1];
        int64_t v_tag_2414 = ((int64_t)v_t_2413.f[0]);
        if ((v_tag_2414 == ((int64_t)0ULL))) {
          heff_drop(v_rep_240);
          heff_drop(v_prog_241);
          heff_drop_rec(v_l_244, 5);
          V v_why_2416 = v_field_2415;
          V v_c_2417 = (g_heff_2ebuild_2ebenchmarks_2enotBenched_24s1690640086x1508912593(v_opts_242, v_f_243, v_why_2416));
          return heff_tail(v_c_2417, 2, (V[]){heff_dup(v_z_247), heff_clo_n(g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s885862188x1878351915_lam0, 1, 3, (V[]){v_k_246, v_z_247, v_z_248})});
        } else {
          V v_withMain_2419 = v_field_2415;
          V v_t_2421 = heff_tag_n(TAG_Start, 4, (V[]){heff_dup(g_std_2eprogress_2eroot_get()), heff_strAppend(heff_dup(v_f_243), ((V)&g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s885862188x1878351915_str0)), MK_INT(2LL), ((V)&g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s885862188x1878351915_lam1_clo)});
          V v_t_2422 = heff_tr(heff_call(heff_dup(v_prog_241), 1, (V[]){v_t_2421}));
          return (g_co_2eop_24s615738393x1686646143(v_t_2422, heff_dup(v_z_247), heff_clo_n(g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s885862188x1878351915_lam2, 1, 9, (V[]){v_prog_241, v_z_247, v_l_244, v_f_243, v_opts_242, v_k_246, v_rep_240, v_withMain_2419, v_z_248})));
        }
      }
    } else {
      heff_drop(v_rep_240);
      heff_drop(v_prog_241);
      heff_drop_rec(v_l_244, 5);
      heff_drop(v_c_245);
      heff_drop(v_field_2411);
      V v_c_24107 = (g_heff_2ebuild_2ebenchmarks_2enotBenched_24s1690640086x1508912593(v_opts_242, v_f_243, ((V)&g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s885862188x1878351915_str12)));
      return heff_tail(v_c_24107, 2, (V[]){heff_dup(v_z_247), heff_clo_n(g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s885862188x1878351915_lam19, 1, 3, (V[]){v_k_246, v_z_247, v_z_248})});
    }
  }
}
V g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s885862188x1878351915_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s885862188x1878351915(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8]);
}
V g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s885862188x1878351915_lam0(V self, V *args) {
  V v_x_2418 = args[0];
  V v_k_246 = heff_env(self)[0];
  V v_z_247 = heff_env(self)[1];
  V v_z_248 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_k_246;
  heff_room[0] = v_x_2418;
  heff_room[1] = v_z_247;
  heff_room[2] = v_z_248;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
V g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s885862188x1878351915_lam1(V self, V *args) {
  V v_t_2420 = args[0];
  return v_t_2420;
}
V g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s885862188x1878351915_lam3(V self, V *args) {
  V v_t_2424 = args[0];
  return v_t_2424;
}
V g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s885862188x1878351915_lam7(V self, V *args) {
  V v_x_2449 = args[0];
  V v_k_246 = heff_env(self)[0];
  V v_z_2443 = heff_env(self)[1];
  V v_z_2444 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_k_246;
  heff_room[0] = v_x_2449;
  heff_room[1] = v_z_2443;
  heff_room[2] = v_z_2444;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
V g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s885862188x1878351915_lam6(V self, V *args) {
  V v_x_2447 = args[0];
  V v_opts_242 = heff_env(self)[0];
  V v_f_243 = heff_env(self)[1];
  V v_why_2442 = heff_env(self)[2];
  V v_z_2443 = heff_env(self)[3];
  V v_k_246 = heff_env(self)[4];
  V v_z_2444 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_2447);
  V v_c_2448 = (g_heff_2ebuild_2ebenchmarks_2enotBenched_24s1690640086x1508912593(v_opts_242, v_f_243, v_why_2442));
  V f_ = v_c_2448;
  heff_room[0] = heff_dup(v_z_2443);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s885862188x1878351915_lam7, 1, 3, (V[]){v_k_246, v_z_2443, v_z_2444});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s885862188x1878351915_lam5(V self, V *args) {
  V v_why_2442 = args[0];
  V v_z_2443 = args[1];
  V v_z_2444 = args[2];
  V v_x_2423 = heff_env(self)[0];
  V v_prog_241 = heff_env(self)[1];
  V v_opts_242 = heff_env(self)[2];
  V v_f_243 = heff_env(self)[3];
  V v_k_246 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2445 = heff_tag_n(TAG_End, 2, (V[]){v_x_2423, NTAG(TAG_MkUnit)});
  V v_t_2446 = heff_tr(heff_call(v_prog_241, 1, (V[]){v_t_2445}));
  return (g_co_2eop_24s615738393x1686646143(v_t_2446, heff_dup(v_z_2443), heff_clo_n(g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s885862188x1878351915_lam6, 1, 6, (V[]){v_opts_242, v_f_243, v_why_2442, v_z_2443, v_k_246, v_z_2444})));
}
V g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s885862188x1878351915_lam10(V self, V *args) {
  V v_r_2464 = args[0];
  return v_r_2464;
}
V g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s885862188x1878351915_lam12(V self, V *args) {
  V v_x_2489 = args[0];
  V v_k_246 = heff_env(self)[0];
  V v_hd_2450 = heff_env(self)[1];
  V v_k_2451 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_k_246;
  heff_room[0] = v_x_2489;
  heff_room[1] = v_hd_2450;
  heff_room[2] = v_k_2451;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
V g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s885862188x1878351915_lam11(V self, V *args) {
  V v_x_2474 = args[0];
  V v_l_244 = heff_env(self)[0];
  V v_f_243 = heff_env(self)[1];
  V v_opts_242 = heff_env(self)[2];
  V v_hd_2450 = heff_env(self)[3];
  V v_k_246 = heff_env(self)[4];
  V v_k_2451 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_paths_2475 = heff_dup(heff_rfield(v_l_244, 2));
  V v_d_2476 = (g_heff_2ebuild_2ebenchmarks_2ebenchDir(heff_dup(v_paths_2475), heff_dup(v_f_243)));
  V v_st_2477 = heff_dup(heff_rfield(v_paths_2475, 5));
  V v_t_2478 = (g_std_2epath_2eparse(v_st_2477, v_d_2476));
  V v_t_2479 = heff_get_n(v_paths_2475, 5, 6);
  V v_t_2480;
  switch (heff_tag_of(v_t_2479)) {
  case TAG_Posix: {
    v_t_2480 = ((V)&g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s885862188x1878351915_str9);
    break;
  }
  case TAG_Windows: {
    v_t_2480 = ((V)&g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s885862188x1878351915_str10);
    break;
  }
  default: heff_nomatch(v_t_2479);
  }
  V v_t_2481 = (g_std_2epath_2eparse(v_st_2477, v_t_2480));
  V v_t_2482 = (g_std_2epath_2ejoin(v_t_2478, v_t_2481));
  V v_given_2483 = ({ V a_0 = v_st_2477; V a_1 = v_t_2482; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2477); heff_drop(v_t_2482); r_; });
  V v_t_2487;
  switch (heff_tag_of(v_x_2474)) {
  case TAG_Left: {
    heff_take_n(v_x_2474, 0ULL, 1);
    heff_drop_rec(v_l_244, 5);
    v_t_2487 = v_given_2483;
    break;
  }
  case TAG_Right: {
    V v_real_2485 = heff_field(v_x_2474, 0);
    heff_take_n(v_x_2474, 1ULL, 1);
    heff_drop(v_given_2483);
    V v_t_2486 = heff_get_n(heff_get_n(v_l_244, 2, 5), 5, 6);
    v_t_2487 = ({ V a_0 = v_t_2486; V a_1 = v_real_2485; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2486); heff_drop(v_real_2485); r_; });
    break;
  }
  default: heff_nomatch(v_x_2474);
  }
  V v_c_2488 = (g_heff_2ebuild_2ebenchmarks_2erunBuilt_24s698375629x1535015491(v_opts_242, v_f_243, v_t_2487));
  V f_ = v_c_2488;
  heff_room[0] = heff_dup(v_hd_2450);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s885862188x1878351915_lam12, 1, 3, (V[]){v_k_246, v_hd_2450, v_k_2451});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s885862188x1878351915_lam9(V self, V *args) {
  V v_x_2452 = args[0];
  V v_l_244 = heff_env(self)[0];
  V v_f_243 = heff_env(self)[1];
  V v_hd_2450 = heff_env(self)[2];
  V v_opts_242 = heff_env(self)[3];
  V v_k_246 = heff_env(self)[4];
  V v_k_2451 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_2452);
  V v_paths_2453 = heff_dup(heff_rfield(v_l_244, 2));
  V v_d_2454 = (g_heff_2ebuild_2ebenchmarks_2ebenchDir(heff_dup(v_paths_2453), heff_dup(v_f_243)));
  V v_st_2455 = heff_dup(heff_rfield(v_paths_2453, 5));
  V v_t_2456 = (g_std_2epath_2eparse(v_st_2455, v_d_2454));
  V v_t_2457 = heff_get_n(v_paths_2453, 5, 6);
  V v_t_2458;
  switch (heff_tag_of(v_t_2457)) {
  case TAG_Posix: {
    v_t_2458 = ((V)&g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s885862188x1878351915_str7);
    break;
  }
  case TAG_Windows: {
    v_t_2458 = ((V)&g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s885862188x1878351915_str8);
    break;
  }
  default: heff_nomatch(v_t_2457);
  }
  V v_t_2459 = (g_std_2epath_2eparse(v_st_2455, v_t_2458));
  V v_t_2460 = (g_std_2epath_2ejoin(v_t_2456, v_t_2459));
  V v_s_2461 = ({ V a_0 = v_st_2455; V a_1 = v_t_2460; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2455); heff_drop(v_t_2460); r_; });
  V v_path_2462 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_s_2461; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
  V v_t_2463 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2462; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_2462); r_; });
  V v_p_231002_2465 = heff_tag_n(TAG_RealPath, 2, (V[]){v_t_2463, ((V)&g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s885862188x1878351915_lam10_clo)});
  V v_t_2466 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_p_231002_2465})});
  V v_t_2467 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2466})});
  V v_t_2468 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2467})});
  V v_t_2469 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2468})});
  V v_t_2470 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2469})});
  V v_t_2471 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2470})});
  V v_t_2472 = heff_tr(heff_call(((V)&g_co_2eop_24s747777320x140686263_clo), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2471})}));
  V v_c_2473 = heff_tr(g_std_2efilesystem_2efromSystem_24s1003849434x1875331781(v_t_2472));
  V f_ = v_c_2473;
  heff_room[0] = heff_dup(v_hd_2450);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s885862188x1878351915_lam11, 1, 6, (V[]){v_l_244, v_f_243, v_opts_242, v_hd_2450, v_k_246, v_k_2451});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s885862188x1878351915_lam8(V self, V *args) {
  V v_hd_2450 = args[0];
  V v_k_2451 = args[1];
  V v_t_2441 = heff_env(self)[0];
  V v_l_244 = heff_env(self)[1];
  V v_f_243 = heff_env(self)[2];
  V v_opts_242 = heff_env(self)[3];
  V v_k_246 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_co_2eop_24s615738393x1686646143(v_t_2441, heff_dup(v_hd_2450), heff_clo_n(g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s885862188x1878351915_lam9, 1, 6, (V[]){v_l_244, v_f_243, v_hd_2450, v_opts_242, v_k_246, v_k_2451})));
}
V g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s885862188x1878351915_lam16(V self, V *args) {
  V v_x_24103 = args[0];
  V v_k_246 = heff_env(self)[0];
  V v_z_2494 = heff_env(self)[1];
  V v_z_2495 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_k_246;
  heff_room[0] = v_x_24103;
  heff_room[1] = v_z_2494;
  heff_room[2] = v_z_2495;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
V g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s885862188x1878351915_lam15(V self, V *args) {
  V v_x_24101 = args[0];
  V v_opts_242 = heff_env(self)[0];
  V v_f_243 = heff_env(self)[1];
  V v_why_2493 = heff_env(self)[2];
  V v_z_2494 = heff_env(self)[3];
  V v_k_246 = heff_env(self)[4];
  V v_z_2495 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_24101);
  V v_c_24102 = (g_heff_2ebuild_2ebenchmarks_2enotBenched_24s1690640086x1508912593(v_opts_242, v_f_243, v_why_2493));
  V f_ = v_c_24102;
  heff_room[0] = heff_dup(v_z_2494);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s885862188x1878351915_lam16, 1, 3, (V[]){v_k_246, v_z_2494, v_z_2495});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s885862188x1878351915_lam14(V self, V *args) {
  V v_x_2498 = args[0];
  V v_x_2423 = heff_env(self)[0];
  V v_prog_241 = heff_env(self)[1];
  V v_z_2494 = heff_env(self)[2];
  V v_opts_242 = heff_env(self)[3];
  V v_f_243 = heff_env(self)[4];
  V v_why_2493 = heff_env(self)[5];
  V v_k_246 = heff_env(self)[6];
  V v_z_2495 = heff_env(self)[7];
  heff_clo_take(self, 8);
  heff_drop(v_x_2498);
  V v_t_2499 = heff_tag_n(TAG_End, 2, (V[]){v_x_2423, NTAG(TAG_MkUnit)});
  V v_t_24100 = heff_tr(heff_call(v_prog_241, 1, (V[]){v_t_2499}));
  return (g_co_2eop_24s615738393x1686646143(v_t_24100, heff_dup(v_z_2494), heff_clo_n(g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s885862188x1878351915_lam15, 1, 6, (V[]){v_opts_242, v_f_243, v_why_2493, v_z_2494, v_k_246, v_z_2495})));
}
V g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s885862188x1878351915_lam13(V self, V *args) {
  V v_why_2493 = args[0];
  V v_z_2494 = args[1];
  V v_z_2495 = args[2];
  V v_x_2426 = heff_env(self)[0];
  V v_prog_241 = heff_env(self)[1];
  V v_x_2423 = heff_env(self)[2];
  V v_opts_242 = heff_env(self)[3];
  V v_f_243 = heff_env(self)[4];
  V v_k_246 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2496 = heff_tag_n(TAG_End, 2, (V[]){v_x_2426, NTAG(TAG_MkUnit)});
  V v_t_2497 = heff_tr(heff_call(heff_dup(v_prog_241), 1, (V[]){v_t_2496}));
  return (g_co_2eop_24s615738393x1686646143(v_t_2497, heff_dup(v_z_2494), heff_clo_n(g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s885862188x1878351915_lam14, 1, 8, (V[]){v_x_2423, v_prog_241, v_z_2494, v_opts_242, v_f_243, v_why_2493, v_k_246, v_z_2495})));
}
V g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s885862188x1878351915_lam18(V self, V *args) {
  V v_x_24106 = args[0];
  V v_next_2490 = heff_env(self)[0];
  V v_hd_24104 = heff_env(self)[1];
  V v_k_24105 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_24106);
  V f_ = v_next_2490;
  heff_room[0] = v_hd_24104;
  heff_room[1] = v_k_24105;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s885862188x1878351915_lam17(V self, V *args) {
  V v_hd_24104 = args[0];
  V v_k_24105 = args[1];
  V v_t_2492 = heff_env(self)[0];
  V v_next_2490 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_co_2eop_24s615738393x1686646143(v_t_2492, heff_dup(v_hd_24104), heff_clo_n(g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s885862188x1878351915_lam18, 1, 3, (V[]){v_next_2490, v_hd_24104, v_k_24105})));
}
V g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s885862188x1878351915_lam4(V self, V *args) {
  V v_x_2426 = args[0];
  V v_l_244 = heff_env(self)[0];
  V v_f_243 = heff_env(self)[1];
  V v_x_2423 = heff_env(self)[2];
  V v_prog_241 = heff_env(self)[3];
  V v_opts_242 = heff_env(self)[4];
  V v_k_246 = heff_env(self)[5];
  V v_rep_240 = heff_env(self)[6];
  V v_withMain_2419 = heff_env(self)[7];
  V v_z_247 = heff_env(self)[8];
  V v_z_248 = heff_env(self)[9];
  heff_clo_take(self, 10);
  V v_t_2427 = (g_heff_2ebuild_2ebenchmarks_2ebenchDir(heff_dup(heff_rfield(v_l_244, 2)), heff_dup(v_f_243)));
  V v_t_2428 = heff_get_n(heff_dup(heff_rfield(v_l_244, 2)), 5, 6);
  V v_t_2429 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s885862188x1878351915_str2), NTAG(TAG_Nil)});
  V v_t_2430 = (g_heff_2ebuild_2ebenchmarks_2ebenchDir(heff_dup(heff_rfield(v_l_244, 2)), heff_dup(v_f_243)));
  V v_paths_2431 = heff_dup(heff_rfield(v_l_244, 2));
  V v_d_2432 = (g_heff_2ebuild_2ebenchmarks_2ebenchDir(heff_dup(v_paths_2431), heff_dup(v_f_243)));
  V v_st_2433 = heff_dup(heff_rfield(v_paths_2431, 5));
  V v_t_2434 = (g_std_2epath_2eparse(v_st_2433, v_d_2432));
  V v_t_2435 = heff_get_n(v_paths_2431, 5, 6);
  V v_t_2436;
  switch (heff_tag_of(v_t_2435)) {
  case TAG_Posix: {
    v_t_2436 = ((V)&g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s885862188x1878351915_str3);
    break;
  }
  case TAG_Windows: {
    v_t_2436 = ((V)&g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s885862188x1878351915_str4);
    break;
  }
  default: heff_nomatch(v_t_2435);
  }
  V v_t_2437 = (g_std_2epath_2eparse(v_st_2433, v_t_2436));
  V v_t_2438 = (g_std_2epath_2ejoin(v_t_2434, v_t_2437));
  V v_t_2439 = ({ V a_0 = v_st_2433; V a_1 = v_t_2438; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2433); heff_drop(v_t_2438); r_; });
  V v_t_2440 = heff_tag_n(TAG_End, 2, (V[]){heff_dup(v_x_2423), NTAG(TAG_MkUnit)});
  V v_t_2441 = heff_tr(heff_call(heff_dup(v_prog_241), 1, (V[]){v_t_2440}));
  V v_next_2490 = ({ V a_0 = heff_dup(v_prog_241); V a_1 = heff_clo_n(g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s885862188x1878351915_lam5, 3, 5, (V[]){heff_dup(v_x_2423), heff_dup(v_prog_241), heff_dup(v_opts_242), heff_dup(v_f_243), heff_dup(v_k_246)}); V a_2 = ((V)&g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s885862188x1878351915_str5); V a_3 = v_t_2428; V a_4 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s885862188x1878351915_str6), v_t_2429}); V a_5 = heff_dup(v_x_2423); V a_6 = v_t_2430; V a_7 = v_t_2439; V a_8 = heff_clo_n(g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s885862188x1878351915_lam8, 2, 5, (V[]){v_t_2441, v_l_244, heff_dup(v_f_243), heff_dup(v_opts_242), heff_dup(v_k_246)}); V r_ = (g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s554328492x651000535(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8)); heff_drop(v_t_2428); r_; });
  V v_t_2491 = heff_tag_n(TAG_End, 2, (V[]){heff_dup(v_x_2426), NTAG(TAG_MkUnit)});
  V v_t_2492 = heff_tr(heff_call(heff_dup(v_prog_241), 1, (V[]){v_t_2491}));
  return (g_heff_2ebuild_2ecommands_2ecLoadedOr_24s896753706x563678558(v_rep_240, heff_clo_n(g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s885862188x1878351915_lam13, 3, 6, (V[]){v_x_2426, v_prog_241, v_x_2423, v_opts_242, heff_dup(v_f_243), v_k_246}), v_withMain_2419, heff_tag_n(TAG_Just, 1, (V[]){heff_dup(g_heff_2ebuild_2ebenchmarks_2ebenchMainName_get())}), heff_strAppend(v_t_2427, ((V)&g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s885862188x1878351915_str11)), v_f_243, heff_clo_n(g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s885862188x1878351915_lam17, 2, 2, (V[]){v_t_2492, v_next_2490}), v_z_247, v_z_248));
}
V g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s885862188x1878351915_lam2(V self, V *args) {
  V v_x_2423 = args[0];
  V v_prog_241 = heff_env(self)[0];
  V v_z_247 = heff_env(self)[1];
  V v_l_244 = heff_env(self)[2];
  V v_f_243 = heff_env(self)[3];
  V v_opts_242 = heff_env(self)[4];
  V v_k_246 = heff_env(self)[5];
  V v_rep_240 = heff_env(self)[6];
  V v_withMain_2419 = heff_env(self)[7];
  V v_z_248 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_t_2425 = heff_tr(heff_call(heff_dup(v_prog_241), 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){heff_dup(v_x_2423), ((V)&g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s885862188x1878351915_str1), MK_INT(0LL), ((V)&g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s885862188x1878351915_lam3_clo)})}));
  return (g_co_2eop_24s615738393x1686646143(v_t_2425, heff_dup(v_z_247), heff_clo_n(g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s885862188x1878351915_lam4, 1, 10, (V[]){v_l_244, v_f_243, v_x_2423, v_prog_241, v_opts_242, v_k_246, v_rep_240, v_withMain_2419, v_z_247, v_z_248})));
}
V g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s885862188x1878351915_lam19(V self, V *args) {
  V v_x_24108 = args[0];
  V v_k_246 = heff_env(self)[0];
  V v_z_247 = heff_env(self)[1];
  V v_z_248 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_k_246;
  heff_room[0] = v_x_24108;
  heff_room[1] = v_z_247;
  heff_room[2] = v_z_248;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2ebenchFile_24s843626549x1899484728_str0, 4, "heff");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2ebenchFile_24s843626549x1899484728_str1, 13, ": not checked");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2ebenchFile_24s843626549x1899484728_str2, 4, "heff");
HEFF_LIT(g_heff_2ebuild_2ebenchmarks_2ebenchFile_24s843626549x1899484728_str3, 13, ": not checked");
V g_heff_2ebuild_2ebenchmarks_2ebenchFile_24s843626549x1899484728_lam2(V self, V *args);
V g_heff_2ebuild_2ebenchmarks_2ebenchFile_24s843626549x1899484728_lam5(V self, V *args);
V g_heff_2ebuild_2ebenchmarks_2ebenchFile_24s843626549x1899484728_lam4(V self, V *args);
V g_heff_2ebuild_2ebenchmarks_2ebenchFile_24s843626549x1899484728_lam3(V self, V *args);
V g_heff_2ebuild_2ebenchmarks_2ebenchFile_24s843626549x1899484728_lam7(V self, V *args);
V g_heff_2ebuild_2ebenchmarks_2ebenchFile_24s843626549x1899484728_lam6(V self, V *args);
V g_heff_2ebuild_2ebenchmarks_2ebenchFile_24s843626549x1899484728_lam1(V self, V *args);
V g_heff_2ebuild_2ebenchmarks_2ebenchFile_24s843626549x1899484728_lam0(V self, V *args);
Clo g_heff_2ebuild_2ebenchmarks_2ebenchFile_24s843626549x1899484728_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebenchmarks_2ebenchFile_24s843626549x1899484728_entry, 11, 0};

V g_heff_2ebuild_2ebenchmarks_2ebenchFile_24s843626549x1899484728(V v_lit_240, V v_lit_241, V v_lit_242, V v_lit_243, V v_lit_244, V v_rep_245, V v_prog_246, V v_opts_247, V v_f_248, V v_z_249, V v_z_2410) {
top: ;
  V v_ran_2411 = heff_take_field(v_lit_244, 0);
  V v_failed_2412 = heff_get_n(v_lit_244, 1, 2);
  V v_c_2413 = (g_heff_2ebuild_2ecommands_2eload_24s1410275656x228048283(heff_dup(v_f_248)));
  return heff_tail(v_c_2413, 2, (V[]){heff_dup(v_z_249), heff_clo_n(g_heff_2ebuild_2ebenchmarks_2ebenchFile_24s843626549x1899484728_lam0, 1, 12, (V[]){v_z_249, v_ran_2411, v_failed_2412, v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_z_2410, v_rep_245, v_prog_246, v_opts_247, v_f_248})});
}
V g_heff_2ebuild_2ebenchmarks_2ebenchFile_24s843626549x1899484728_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ebenchmarks_2ebenchFile_24s843626549x1899484728(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8], a[9], a[10]);
}
V g_heff_2ebuild_2ebenchmarks_2ebenchFile_24s843626549x1899484728_lam2(V self, V *args) {
  V v_a_2431 = args[0];
  V v_z_2432 = args[1];
  V v_z_2433 = args[2];
  V v_lit_240 = heff_env(self)[0];
  V v_lit_241 = heff_env(self)[1];
  V v_lit_242 = heff_env(self)[2];
  V v_lit_243 = heff_env(self)[3];
  V v_ran_2411 = heff_env(self)[4];
  V v_failed_2412 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_ran_2434 = heff_take_field(v_a_2431, 0);
  V v_failed_2435 = heff_get_n(v_a_2431, 1, 2);
  V v_rep_2436 = v_lit_240;
  V v_prog_2437 = v_lit_241;
  V v_opts_2438 = v_lit_242;
  V v_x2_2439 = v_lit_243;
  V v_acc_2440 = heff_rec_n(2, shape_ran__failed, (V[]){heff_intAdd(v_ran_2411, v_ran_2434), heff_intAdd(v_failed_2412, v_failed_2435)});
  switch (heff_tag_of(v_x2_2439)) {
  case TAG_Nil: {
    heff_drop(v_rep_2436);
    heff_drop(v_prog_2437);
    return (g_heff_2ebuild_2ebenchmarks_2ebenchSummary_24s1621298555x666587532(v_opts_2438, v_acc_2440, v_z_2432, v_z_2433));
  }
  case TAG_Cons: {
    V v_f_2441 = heff_field(v_x2_2439, 0);
    V v_rest_2442 = heff_field(v_x2_2439, 1);
    heff_take_n(v_x2_2439, 3ULL, 2);
    return (g_heff_2ebuild_2ebenchmarks_2ebenchFile_24s843626549x1899484728(heff_dup(v_rep_2436), heff_dup(v_prog_2437), heff_dup(v_opts_2438), v_rest_2442, v_acc_2440, v_rep_2436, v_prog_2437, v_opts_2438, v_f_2441, v_z_2432, v_z_2433));
  }
  default: return heff_nomatch(v_x2_2439);
  }
}
V g_heff_2ebuild_2ebenchmarks_2ebenchFile_24s843626549x1899484728_lam5(V self, V *args) {
  V v_x_2455 = args[0];
  V v_ran_2411 = heff_env(self)[0];
  V v_failed_2412 = heff_env(self)[1];
  V v_lit_240 = heff_env(self)[2];
  V v_lit_241 = heff_env(self)[3];
  V v_lit_242 = heff_env(self)[4];
  V v_lit_243 = heff_env(self)[5];
  V v_z_249 = heff_env(self)[6];
  V v_z_2410 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_ran_2456 = heff_take_field(v_x_2455, 0);
  V v_failed_2457 = heff_get_n(v_x_2455, 1, 2);
  V v_t_2458 = heff_rec_n(2, shape_ran__failed, (V[]){heff_intAdd(v_ran_2411, v_ran_2456), heff_intAdd(v_failed_2412, v_failed_2457)});
  return ({ V a_0 = v_lit_240; V a_1 = v_lit_241; V a_2 = v_lit_242; V a_3 = v_lit_243; V a_4 = v_t_2458; V a_5 = v_z_249; V a_6 = v_z_2410; V r_ = (g_heff_2ebuild_2ebenchmarks_2ebenchEach_24s569761754x1094361140(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_lit_243); r_; });
}
V g_heff_2ebuild_2ebenchmarks_2ebenchFile_24s843626549x1899484728_lam4(V self, V *args) {
  V v_x_2445 = args[0];
  V v_x_2414 = heff_env(self)[0];
  V v_cs_2417 = heff_env(self)[1];
  V v_f_248 = heff_env(self)[2];
  V v_opts_247 = heff_env(self)[3];
  V v_z_249 = heff_env(self)[4];
  V v_ran_2411 = heff_env(self)[5];
  V v_failed_2412 = heff_env(self)[6];
  V v_lit_240 = heff_env(self)[7];
  V v_lit_241 = heff_env(self)[8];
  V v_lit_242 = heff_env(self)[9];
  V v_lit_243 = heff_env(self)[10];
  V v_z_2410 = heff_env(self)[11];
  heff_clo_take(self, 12);
  heff_drop(v_x_2445);
  V v_t_2446 = heff_get_n(v_x_2414, 1, 5);
  V v_t_2453;
  switch (heff_tag_of(v_t_2446)) {
  case TAG_Nil: {
    HeffT2 v_t_2447 = (g_heff_2ebuild_2ecommands_2efirstErrorOf_24cpr(v_cs_2417));
    {
      V v_field_2449 = v_t_2447.f[1];
      int64_t v_tag_2448 = ((int64_t)v_t_2447.f[0]);
      if ((v_tag_2448 == ((int64_t)0ULL))) {
        V v_x_2450 = v_field_2449;
        v_t_2453 = v_x_2450;
      } else {
        heff_drop(v_field_2449);
        v_t_2453 = heff_strAppend(heff_dup(v_f_248), ((V)&g_heff_2ebuild_2ebenchmarks_2ebenchFile_24s843626549x1899484728_str1));
      }
    }
    break;
  }
  case TAG_Cons: {
    V v_why_2451 = heff_field(v_t_2446, 0);
    heff_take_n(v_t_2446, 1ULL, 2);
    heff_drop(v_cs_2417);
    v_t_2453 = v_why_2451;
    break;
  }
  default: heff_nomatch(v_t_2446);
  }
  V v_c_2454 = (g_heff_2ebuild_2ebenchmarks_2enotBenched_24s1690640086x1508912593(v_opts_247, v_f_248, v_t_2453));
  V f_ = v_c_2454;
  heff_room[0] = heff_dup(v_z_249);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ebenchmarks_2ebenchFile_24s843626549x1899484728_lam5, 1, 8, (V[]){v_ran_2411, v_failed_2412, v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_z_249, v_z_2410});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ebenchmarks_2ebenchFile_24s843626549x1899484728_lam3(V self, V *args) {
  V v_x_2443 = args[0];
  V v_cs_2417 = heff_env(self)[0];
  V v_z_249 = heff_env(self)[1];
  V v_x_2414 = heff_env(self)[2];
  V v_f_248 = heff_env(self)[3];
  V v_opts_247 = heff_env(self)[4];
  V v_ran_2411 = heff_env(self)[5];
  V v_failed_2412 = heff_env(self)[6];
  V v_lit_240 = heff_env(self)[7];
  V v_lit_241 = heff_env(self)[8];
  V v_lit_242 = heff_env(self)[9];
  V v_lit_243 = heff_env(self)[10];
  V v_z_2410 = heff_env(self)[11];
  heff_clo_take(self, 12);
  heff_drop(v_x_2443);
  V v_c_2444 = (g_heff_2ebuild_2ecommands_2ediagCount_24s823746706x1248851912(v_cs_2417));
  V f_ = v_c_2444;
  heff_room[0] = heff_dup(v_z_249);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ebenchmarks_2ebenchFile_24s843626549x1899484728_lam4, 1, 12, (V[]){v_x_2414, v_cs_2417, v_f_248, v_opts_247, v_z_249, v_ran_2411, v_failed_2412, v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_z_2410});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ebenchmarks_2ebenchFile_24s843626549x1899484728_lam7(V self, V *args) {
  V v_x_2469 = args[0];
  V v_ran_2411 = heff_env(self)[0];
  V v_failed_2412 = heff_env(self)[1];
  V v_lit_240 = heff_env(self)[2];
  V v_lit_241 = heff_env(self)[3];
  V v_lit_242 = heff_env(self)[4];
  V v_lit_243 = heff_env(self)[5];
  V v_z_249 = heff_env(self)[6];
  V v_z_2410 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_ran_2470 = heff_take_field(v_x_2469, 0);
  V v_failed_2471 = heff_get_n(v_x_2469, 1, 2);
  V v_t_2472 = heff_rec_n(2, shape_ran__failed, (V[]){heff_intAdd(v_ran_2411, v_ran_2470), heff_intAdd(v_failed_2412, v_failed_2471)});
  return ({ V a_0 = v_lit_240; V a_1 = v_lit_241; V a_2 = v_lit_242; V a_3 = v_lit_243; V a_4 = v_t_2472; V a_5 = v_z_249; V a_6 = v_z_2410; V r_ = (g_heff_2ebuild_2ebenchmarks_2ebenchEach_24s569761754x1094361140(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_lit_243); r_; });
}
V g_heff_2ebuild_2ebenchmarks_2ebenchFile_24s843626549x1899484728_lam6(V self, V *args) {
  V v_x_2459 = args[0];
  V v_x_2414 = heff_env(self)[0];
  V v_cs_2417 = heff_env(self)[1];
  V v_f_248 = heff_env(self)[2];
  V v_opts_247 = heff_env(self)[3];
  V v_z_249 = heff_env(self)[4];
  V v_ran_2411 = heff_env(self)[5];
  V v_failed_2412 = heff_env(self)[6];
  V v_lit_240 = heff_env(self)[7];
  V v_lit_241 = heff_env(self)[8];
  V v_lit_242 = heff_env(self)[9];
  V v_lit_243 = heff_env(self)[10];
  V v_z_2410 = heff_env(self)[11];
  heff_clo_take(self, 12);
  heff_drop(v_x_2459);
  V v_t_2460 = heff_get_n(v_x_2414, 1, 5);
  V v_t_2467;
  switch (heff_tag_of(v_t_2460)) {
  case TAG_Nil: {
    HeffT2 v_t_2461 = (g_heff_2ebuild_2ecommands_2efirstErrorOf_24cpr(v_cs_2417));
    {
      V v_field_2463 = v_t_2461.f[1];
      int64_t v_tag_2462 = ((int64_t)v_t_2461.f[0]);
      if ((v_tag_2462 == ((int64_t)0ULL))) {
        V v_x_2464 = v_field_2463;
        v_t_2467 = v_x_2464;
      } else {
        heff_drop(v_field_2463);
        v_t_2467 = heff_strAppend(heff_dup(v_f_248), ((V)&g_heff_2ebuild_2ebenchmarks_2ebenchFile_24s843626549x1899484728_str3));
      }
    }
    break;
  }
  case TAG_Cons: {
    V v_why_2465 = heff_field(v_t_2460, 0);
    heff_take_n(v_t_2460, 1ULL, 2);
    heff_drop(v_cs_2417);
    v_t_2467 = v_why_2465;
    break;
  }
  default: heff_nomatch(v_t_2460);
  }
  V v_c_2468 = (g_heff_2ebuild_2ebenchmarks_2enotBenched_24s1690640086x1508912593(v_opts_247, v_f_248, v_t_2467));
  V f_ = v_c_2468;
  heff_room[0] = heff_dup(v_z_249);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ebenchmarks_2ebenchFile_24s843626549x1899484728_lam7, 1, 8, (V[]){v_ran_2411, v_failed_2412, v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_z_249, v_z_2410});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ebenchmarks_2ebenchFile_24s843626549x1899484728_lam1(V self, V *args) {
  V v_x_2416 = args[0];
  V v_x_2414 = heff_env(self)[0];
  V v_ran_2411 = heff_env(self)[1];
  V v_failed_2412 = heff_env(self)[2];
  V v_lit_240 = heff_env(self)[3];
  V v_lit_241 = heff_env(self)[4];
  V v_lit_242 = heff_env(self)[5];
  V v_lit_243 = heff_env(self)[6];
  V v_z_249 = heff_env(self)[7];
  V v_z_2410 = heff_env(self)[8];
  V v_rep_245 = heff_env(self)[9];
  V v_prog_246 = heff_env(self)[10];
  V v_opts_247 = heff_env(self)[11];
  V v_f_248 = heff_env(self)[12];
  heff_clo_take(self, 13);
  V v_cs_2417 = heff_get_n(v_x_2416, 0, 2);
  HeffT2 v_t_2418 = (g_heff_2ebuild_2edriver_2elastChecked_24cpr(heff_dup(v_cs_2417)));
  {
    V v_field_2420 = v_t_2418.f[1];
    int64_t v_tag_2419 = ((int64_t)v_t_2418.f[0]);
    if ((v_tag_2419 == ((int64_t)0ULL))) {
      V v_c_2421 = v_field_2420;
      V v_t_2422 = heff_dup(heff_rfield(v_x_2414, 1));
      V v_t_2426;
      switch (heff_tag_of(v_t_2422)) {
      case TAG_Nil: {
        V v_x1_2423 = (g_list_2eany_24s1740858080x874135214(v_cs_2417));
        v_t_2426 = heff_bool(!(heff_dup(v_x1_2423) == NTAG(TAG_True)));
        heff_drop(v_x1_2423);
        break;
      }
      case TAG_Cons: {
        heff_take_n(v_t_2422, 0ULL, 2);
        v_t_2426 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_t_2422);
      }
      if ((heff_dup(v_t_2426) == NTAG(TAG_True))) {
        heff_drop(v_cs_2417);
        heff_drop(v_t_2426);
        V v_x1_2427 = (g_heff_2ebuild_2edriver_2ebenchesOf(heff_dup(v_c_2421)));
        switch (heff_tag_of(v_x1_2427)) {
        case TAG_Nil: {
          heff_drop_rec(v_x_2414, 5);
          heff_drop(v_rep_245);
          heff_drop(v_prog_246);
          heff_drop(v_opts_247);
          heff_drop(v_f_248);
          heff_drop(v_c_2421);
          V v_t_2428 = heff_rec_n(2, shape_ran__failed, (V[]){heff_intAdd(v_ran_2411, MK_INT(0LL)), heff_intAdd(v_failed_2412, MK_INT(0LL))});
          return ({ V a_0 = v_lit_240; V a_1 = v_lit_241; V a_2 = v_lit_242; V a_3 = v_lit_243; V a_4 = v_t_2428; V a_5 = v_z_249; V a_6 = v_z_2410; V r_ = (g_heff_2ebuild_2ebenchmarks_2ebenchEach_24s569761754x1094361140(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_lit_243); r_; });
        }
        case TAG_Cons: {
          heff_take_n(v_x1_2427, 0ULL, 2);
          return (g_heff_2ebuild_2ebenchmarks_2ebuildBenches_24s885862188x1878351915(v_rep_245, v_prog_246, v_opts_247, v_f_248, v_x_2414, v_c_2421, heff_clo_n(g_heff_2ebuild_2ebenchmarks_2ebenchFile_24s843626549x1899484728_lam2, 3, 6, (V[]){v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_ran_2411, v_failed_2412}), v_z_249, v_z_2410));
        }
        default: return heff_nomatch(v_x1_2427);
        }
      } else {
        heff_drop(v_rep_245);
        heff_drop(v_prog_246);
        heff_drop(v_c_2421);
        heff_drop(v_t_2426);
        return (g_heff_2ebuild_2ecommands_2eprintErrs_24s115117455x797094904(((V)&g_heff_2ebuild_2ebenchmarks_2ebenchFile_24s843626549x1899484728_str0), heff_dup(heff_rfield(v_x_2414, 1)), MK_INT(0LL), heff_dup(v_z_249), heff_clo_n(g_heff_2ebuild_2ebenchmarks_2ebenchFile_24s843626549x1899484728_lam3, 1, 12, (V[]){v_cs_2417, v_z_249, v_x_2414, v_f_248, v_opts_247, v_ran_2411, v_failed_2412, v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_z_2410})));
      }
    } else {
      heff_drop(v_rep_245);
      heff_drop(v_prog_246);
      heff_drop(v_field_2420);
      return (g_heff_2ebuild_2ecommands_2eprintErrs_24s115117455x797094904(((V)&g_heff_2ebuild_2ebenchmarks_2ebenchFile_24s843626549x1899484728_str2), heff_dup(heff_rfield(v_x_2414, 1)), MK_INT(0LL), heff_dup(v_z_249), heff_clo_n(g_heff_2ebuild_2ebenchmarks_2ebenchFile_24s843626549x1899484728_lam6, 1, 12, (V[]){v_x_2414, v_cs_2417, v_f_248, v_opts_247, v_z_249, v_ran_2411, v_failed_2412, v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_z_2410})));
    }
  }
}
V g_heff_2ebuild_2ebenchmarks_2ebenchFile_24s843626549x1899484728_lam0(V self, V *args) {
  V v_x_2414 = args[0];
  V v_z_249 = heff_env(self)[0];
  V v_ran_2411 = heff_env(self)[1];
  V v_failed_2412 = heff_env(self)[2];
  V v_lit_240 = heff_env(self)[3];
  V v_lit_241 = heff_env(self)[4];
  V v_lit_242 = heff_env(self)[5];
  V v_lit_243 = heff_env(self)[6];
  V v_z_2410 = heff_env(self)[7];
  V v_rep_245 = heff_env(self)[8];
  V v_prog_246 = heff_env(self)[9];
  V v_opts_247 = heff_env(self)[10];
  V v_f_248 = heff_env(self)[11];
  heff_clo_take(self, 12);
  V v_c_2415 = (g_heff_2ebuild_2esession_2ecachedAcc_24s1827793511x304312721(heff_dup(v_x_2414)));
  V f_ = v_c_2415;
  heff_room[0] = heff_dup(v_z_249);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ebenchmarks_2ebenchFile_24s843626549x1899484728_lam1, 1, 13, (V[]){v_x_2414, v_ran_2411, v_failed_2412, v_lit_240, v_lit_241, v_lit_242, v_lit_243, v_z_249, v_z_2410, v_rep_245, v_prog_246, v_opts_247, v_f_248});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
Clo g_heff_2ebuild_2ebenchmarks_2ebenchEach_24s569761754x1094361140_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ebenchmarks_2ebenchEach_24s569761754x1094361140_entry, 7, 0};

V g_heff_2ebuild_2ebenchmarks_2ebenchEach_24s569761754x1094361140(V v_rep_240, V v_prog_241, V v_opts_242, V v_x2_243, V v_acc_244, V v_z_245, V v_z_246) {
top: ;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    heff_drop(v_rep_240);
    heff_drop(v_prog_241);
    return (g_heff_2ebuild_2ebenchmarks_2ebenchSummary_24s1621298555x666587532(v_opts_242, v_acc_244, v_z_245, v_z_246));
  }
  case TAG_Cons: {
    V v_f_247 = heff_field(v_x2_243, 0);
    V v_rest_248 = heff_field(v_x2_243, 1);
    return (g_heff_2ebuild_2ebenchmarks_2ebenchFile_24s843626549x1899484728(heff_dup(v_rep_240), heff_dup(v_prog_241), heff_dup(v_opts_242), heff_dup(v_rest_248), v_acc_244, v_rep_240, v_prog_241, v_opts_242, heff_dup(v_f_247), v_z_245, v_z_246));
  }
  default: return heff_nomatch(v_x2_243);
  }
}
V g_heff_2ebuild_2ebenchmarks_2ebenchEach_24s569761754x1094361140_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2ebuild_2ebenchmarks_2ebenchEach_24s569761754x1094361140(a[0], a[1], a[2], a3, a[4], a[5], a[6]); heff_drop(a3); return r;
}