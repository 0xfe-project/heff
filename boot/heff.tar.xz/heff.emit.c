// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
Clo g_heff_2eemit_2ecatMaybesL_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemit_2ecatMaybesL_entry, 1, 0};

V g_heff_2eemit_2ecatMaybesL(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_xs_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_xs_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Just: {
      V v_x_243 = heff_field(v_x11_241, 0);
      heff_take_n(v_x11_241, 1ULL, 1);
      return heff_tag_at(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_243, (g_heff_2eemit_2ecatMaybesL(v_xs_242))});
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eemit_2ecatMaybesL_entry(V self, V *a) {
  (void)self;
  return g_heff_2eemit_2ecatMaybesL(a[0]);
}
Clo g_heff_2eemit_2enubGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemit_2enubGo_entry, 2, 0};

V g_heff_2eemit_2enubGo(V v_seen_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_seen_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_244 = heff_tr(heff_apply(((V)&prim_strEq_clo), 1, (V[]){heff_dup(v_x_242)}));
    V v_t_245 = (g_prelude_2eany(v_t_244, v_seen_240));
    switch (heff_tag_of(v_t_245)) {
    case TAG_True: {
      heff_drop(v_x_242);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_seen_240;
      V t_1 = v_xs_243;
      v_seen_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_False: {
      return heff_tag_at(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_x_242), (g_heff_2eemit_2enubGo(heff_tag(TAG_Cons, 2, (V[]){v_x_242, v_seen_240}), v_xs_243))});
    }
    default: return heff_nomatch(v_t_245);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eemit_2enubGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2eemit_2enubGo(a[0], a[1]);
}
Clo g_heff_2eemit_2eunsnocGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemit_2eunsnocGo_entry, 2, 0};

V g_heff_2eemit_2eunsnocGo(V v_x1_240, V v_y_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_tag(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_y_241});
  }
  case TAG_Cons: {
    V v_z_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_x2_244 = (g_heff_2eemit_2eunsnocGo(v_rest_243, v_z_242));
    switch (heff_tag_of(v_x2_244)) {
    case TAG_MkPair: {
      V v_ini_245 = heff_field(v_x2_244, 0);
      V v_lst_246 = heff_field(v_x2_244, 1);
      heff_take_n(v_x2_244, 3ULL, 2);
      return heff_tag_at(v_ru_24x1_240_24Cons, TAG_MkPair, 2, (V[]){heff_tag(TAG_Cons, 2, (V[]){v_y_241, v_ini_245}), v_lst_246});
    }
    default: return heff_nomatch(v_x2_244);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eemit_2eunsnocGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2eemit_2eunsnocGo(a[0], a[1]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemit_2eescAt_str0 = {{0x80000000u, K_STR, 0}, 2, 2, {92, 34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemit_2eescAt_str1 = {{0x80000000u, K_STR, 0}, 2, 2, {92, 92}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemit_2eescAt_str2 = {{0x80000000u, K_STR, 0}, 2, 2, {92, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemit_2eescAt_str3 = {{0x80000000u, K_STR, 0}, 2, 2, {92, 114}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemit_2eescAt_str4 = {{0x80000000u, K_STR, 0}, 2, 2, {92, 116}};
Clo g_heff_2eemit_2eescAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemit_2eescAt_entry, 2, 0};

V g_heff_2eemit_2eescAt(V v_s_240, V v_i_241) {
top: ;
  V v_t_242 = heff_intEq(heff_strCharCode(heff_dup(v_s_240), heff_dup(v_i_241)), MK_INT(34LL));
  switch (heff_tag_of(v_t_242)) {
  case TAG_True: {
    heff_drop(v_s_240);
    heff_drop(v_i_241);
    return ((V)&g_heff_2eemit_2eescAt_str0);
  }
  case TAG_False: {
    V v_t_243 = heff_intEq(heff_strCharCode(heff_dup(v_s_240), heff_dup(v_i_241)), MK_INT(92LL));
    switch (heff_tag_of(v_t_243)) {
    case TAG_True: {
      heff_drop(v_s_240);
      heff_drop(v_i_241);
      return ((V)&g_heff_2eemit_2eescAt_str1);
    }
    case TAG_False: {
      V v_t_244 = heff_intEq(heff_strCharCode(heff_dup(v_s_240), heff_dup(v_i_241)), MK_INT(10LL));
      switch (heff_tag_of(v_t_244)) {
      case TAG_True: {
        heff_drop(v_s_240);
        heff_drop(v_i_241);
        return ((V)&g_heff_2eemit_2eescAt_str2);
      }
      case TAG_False: {
        V v_t_245 = heff_intEq(heff_strCharCode(heff_dup(v_s_240), heff_dup(v_i_241)), MK_INT(13LL));
        switch (heff_tag_of(v_t_245)) {
        case TAG_True: {
          heff_drop(v_s_240);
          heff_drop(v_i_241);
          return ((V)&g_heff_2eemit_2eescAt_str3);
        }
        case TAG_False: {
          V v_t_246 = heff_intEq(heff_strCharCode(heff_dup(v_s_240), heff_dup(v_i_241)), MK_INT(9LL));
          switch (heff_tag_of(v_t_246)) {
          case TAG_True: {
            heff_drop(v_s_240);
            heff_drop(v_i_241);
            return ((V)&g_heff_2eemit_2eescAt_str4);
          }
          case TAG_False: {
            return heff_strSlice(v_s_240, heff_dup(v_i_241), heff_intAdd(v_i_241, MK_INT(1LL)));
          }
          default: return heff_nomatch(v_t_246);
          }
        }
        default: return heff_nomatch(v_t_245);
        }
      }
      default: return heff_nomatch(v_t_244);
      }
    }
    default: return heff_nomatch(v_t_243);
    }
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2eemit_2eescAt_entry(V self, V *a) {
  (void)self;
  return g_heff_2eemit_2eescAt(a[0], a[1]);
}
Clo g_heff_2eemit_2equoteGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemit_2equoteGo_entry, 3, 0};

V g_heff_2eemit_2equoteGo(V v_s_240, V v_i_241, V v_acc_242) {
top: ;
  V v_t_243 = heff_intLe(heff_strLength(heff_dup(v_s_240)), heff_dup(v_i_241));
  switch (heff_tag_of(v_t_243)) {
  case TAG_True: {
    heff_drop(v_s_240);
    heff_drop(v_i_241);
    return v_acc_242;
  }
  case TAG_False: {
    V v_t_244 = heff_strAppend(v_acc_242, (g_heff_2eemit_2eescAt(heff_dup(v_s_240), heff_dup(v_i_241))));
    V t_0 = v_s_240;
    V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
    V t_2 = v_t_244;
    v_s_240 = t_0;
    v_i_241 = t_1;
    v_acc_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_heff_2eemit_2equoteGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2eemit_2equoteGo(a[0], a[1], a[2]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eemit_2ewordOf_str0 = {{0x80000000u, K_STR, 0}, 4, 4, {112, 108, 117, 115}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eemit_2ewordOf_str1 = {{0x80000000u, K_STR, 0}, 5, 5, {109, 105, 110, 117, 115}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eemit_2ewordOf_str2 = {{0x80000000u, K_STR, 0}, 5, 5, {116, 105, 109, 101, 115}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eemit_2ewordOf_str3 = {{0x80000000u, K_STR, 0}, 5, 5, {115, 108, 97, 115, 104}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2eemit_2ewordOf_str4 = {{0x80000000u, K_STR, 0}, 7, 7, {112, 101, 114, 99, 101, 110, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemit_2ewordOf_str5 = {{0x80000000u, K_STR, 0}, 2, 2, {101, 113}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemit_2ewordOf_str6 = {{0x80000000u, K_STR, 0}, 2, 2, {108, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemit_2ewordOf_str7 = {{0x80000000u, K_STR, 0}, 2, 2, {103, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemit_2ewordOf_str8 = {{0x80000000u, K_STR, 0}, 3, 3, {97, 109, 112}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemit_2ewordOf_str9 = {{0x80000000u, K_STR, 0}, 3, 3, {98, 97, 114}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eemit_2ewordOf_str10 = {{0x80000000u, K_STR, 0}, 4, 4, {98, 97, 110, 103}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eemit_2ewordOf_str11 = {{0x80000000u, K_STR, 0}, 5, 5, {99, 97, 114, 101, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2ewordOf_str12 = {{0x80000000u, K_STR, 0}, 1, 1, {113}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemit_2ewordOf_str13 = {{0x80000000u, K_STR, 0}, 2, 2, {97, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eemit_2ewordOf_str14 = {{0x80000000u, K_STR, 0}, 4, 4, {104, 97, 115, 104}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2eemit_2ewordOf_str15 = {{0x80000000u, K_STR, 0}, 6, 6, {100, 111, 108, 108, 97, 114}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eemit_2ewordOf_str16 = {{0x80000000u, K_STR, 0}, 5, 5, {116, 105, 108, 100, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eemit_2ewordOf_str17 = {{0x80000000u, K_STR, 0}, 5, 5, {99, 111, 108, 111, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemit_2ewordOf_str18 = {{0x80000000u, K_STR, 0}, 3, 3, {100, 111, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2eemit_2ewordOf_str19 = {{0x80000000u, K_STR, 0}, 9, 9, {98, 97, 99, 107, 115, 108, 97, 115, 104}};
Clo g_heff_2eemit_2ewordOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemit_2ewordOf_entry, 1, 0};

V g_heff_2eemit_2ewordOf(V v_c_240) {
top: ;
  V v_t_241 = heff_intEq(heff_dup(v_c_240), MK_INT(43LL));
  switch (heff_tag_of(v_t_241)) {
  case TAG_True: {
    heff_drop(v_c_240);
    return heff_tag(TAG_Just, 1, (V[]){((V)&g_heff_2eemit_2ewordOf_str0)});
  }
  case TAG_False: {
    V v_t_242 = heff_intEq(heff_dup(v_c_240), MK_INT(45LL));
    switch (heff_tag_of(v_t_242)) {
    case TAG_True: {
      heff_drop(v_c_240);
      return heff_tag(TAG_Just, 1, (V[]){((V)&g_heff_2eemit_2ewordOf_str1)});
    }
    case TAG_False: {
      V v_t_243 = heff_intEq(heff_dup(v_c_240), MK_INT(42LL));
      switch (heff_tag_of(v_t_243)) {
      case TAG_True: {
        heff_drop(v_c_240);
        return heff_tag(TAG_Just, 1, (V[]){((V)&g_heff_2eemit_2ewordOf_str2)});
      }
      case TAG_False: {
        V v_t_244 = heff_intEq(heff_dup(v_c_240), MK_INT(47LL));
        switch (heff_tag_of(v_t_244)) {
        case TAG_True: {
          heff_drop(v_c_240);
          return heff_tag(TAG_Just, 1, (V[]){((V)&g_heff_2eemit_2ewordOf_str3)});
        }
        case TAG_False: {
          V v_t_245 = heff_intEq(heff_dup(v_c_240), MK_INT(37LL));
          switch (heff_tag_of(v_t_245)) {
          case TAG_True: {
            heff_drop(v_c_240);
            return heff_tag(TAG_Just, 1, (V[]){((V)&g_heff_2eemit_2ewordOf_str4)});
          }
          case TAG_False: {
            V v_t_246 = heff_intEq(heff_dup(v_c_240), MK_INT(61LL));
            switch (heff_tag_of(v_t_246)) {
            case TAG_True: {
              heff_drop(v_c_240);
              return heff_tag(TAG_Just, 1, (V[]){((V)&g_heff_2eemit_2ewordOf_str5)});
            }
            case TAG_False: {
              V v_t_247 = heff_intEq(heff_dup(v_c_240), MK_INT(60LL));
              switch (heff_tag_of(v_t_247)) {
              case TAG_True: {
                heff_drop(v_c_240);
                return heff_tag(TAG_Just, 1, (V[]){((V)&g_heff_2eemit_2ewordOf_str6)});
              }
              case TAG_False: {
                V v_t_248 = heff_intEq(heff_dup(v_c_240), MK_INT(62LL));
                switch (heff_tag_of(v_t_248)) {
                case TAG_True: {
                  heff_drop(v_c_240);
                  return heff_tag(TAG_Just, 1, (V[]){((V)&g_heff_2eemit_2ewordOf_str7)});
                }
                case TAG_False: {
                  V v_t_249 = heff_intEq(heff_dup(v_c_240), MK_INT(38LL));
                  switch (heff_tag_of(v_t_249)) {
                  case TAG_True: {
                    heff_drop(v_c_240);
                    return heff_tag(TAG_Just, 1, (V[]){((V)&g_heff_2eemit_2ewordOf_str8)});
                  }
                  case TAG_False: {
                    V v_t_2410 = heff_intEq(heff_dup(v_c_240), MK_INT(124LL));
                    switch (heff_tag_of(v_t_2410)) {
                    case TAG_True: {
                      heff_drop(v_c_240);
                      return heff_tag(TAG_Just, 1, (V[]){((V)&g_heff_2eemit_2ewordOf_str9)});
                    }
                    case TAG_False: {
                      V v_t_2411 = heff_intEq(heff_dup(v_c_240), MK_INT(33LL));
                      switch (heff_tag_of(v_t_2411)) {
                      case TAG_True: {
                        heff_drop(v_c_240);
                        return heff_tag(TAG_Just, 1, (V[]){((V)&g_heff_2eemit_2ewordOf_str10)});
                      }
                      case TAG_False: {
                        V v_t_2412 = heff_intEq(heff_dup(v_c_240), MK_INT(94LL));
                        switch (heff_tag_of(v_t_2412)) {
                        case TAG_True: {
                          heff_drop(v_c_240);
                          return heff_tag(TAG_Just, 1, (V[]){((V)&g_heff_2eemit_2ewordOf_str11)});
                        }
                        case TAG_False: {
                          V v_t_2413 = heff_intEq(heff_dup(v_c_240), MK_INT(63LL));
                          switch (heff_tag_of(v_t_2413)) {
                          case TAG_True: {
                            heff_drop(v_c_240);
                            return heff_tag(TAG_Just, 1, (V[]){((V)&g_heff_2eemit_2ewordOf_str12)});
                          }
                          case TAG_False: {
                            V v_t_2414 = heff_intEq(heff_dup(v_c_240), MK_INT(64LL));
                            switch (heff_tag_of(v_t_2414)) {
                            case TAG_True: {
                              heff_drop(v_c_240);
                              return heff_tag(TAG_Just, 1, (V[]){((V)&g_heff_2eemit_2ewordOf_str13)});
                            }
                            case TAG_False: {
                              V v_t_2415 = heff_intEq(heff_dup(v_c_240), MK_INT(35LL));
                              switch (heff_tag_of(v_t_2415)) {
                              case TAG_True: {
                                heff_drop(v_c_240);
                                return heff_tag(TAG_Just, 1, (V[]){((V)&g_heff_2eemit_2ewordOf_str14)});
                              }
                              case TAG_False: {
                                V v_t_2416 = heff_intEq(heff_dup(v_c_240), MK_INT(36LL));
                                switch (heff_tag_of(v_t_2416)) {
                                case TAG_True: {
                                  heff_drop(v_c_240);
                                  return heff_tag(TAG_Just, 1, (V[]){((V)&g_heff_2eemit_2ewordOf_str15)});
                                }
                                case TAG_False: {
                                  V v_t_2417 = heff_intEq(heff_dup(v_c_240), MK_INT(126LL));
                                  switch (heff_tag_of(v_t_2417)) {
                                  case TAG_True: {
                                    heff_drop(v_c_240);
                                    return heff_tag(TAG_Just, 1, (V[]){((V)&g_heff_2eemit_2ewordOf_str16)});
                                  }
                                  case TAG_False: {
                                    V v_t_2418 = heff_intEq(heff_dup(v_c_240), MK_INT(58LL));
                                    switch (heff_tag_of(v_t_2418)) {
                                    case TAG_True: {
                                      heff_drop(v_c_240);
                                      return heff_tag(TAG_Just, 1, (V[]){((V)&g_heff_2eemit_2ewordOf_str17)});
                                    }
                                    case TAG_False: {
                                      V v_t_2419 = heff_intEq(heff_dup(v_c_240), MK_INT(46LL));
                                      switch (heff_tag_of(v_t_2419)) {
                                      case TAG_True: {
                                        heff_drop(v_c_240);
                                        return heff_tag(TAG_Just, 1, (V[]){((V)&g_heff_2eemit_2ewordOf_str18)});
                                      }
                                      case TAG_False: {
                                        V v_t_2420 = heff_intEq(v_c_240, MK_INT(92LL));
                                        switch (heff_tag_of(v_t_2420)) {
                                        case TAG_True: {
                                          return heff_tag(TAG_Just, 1, (V[]){((V)&g_heff_2eemit_2ewordOf_str19)});
                                        }
                                        case TAG_False: {
                                          return NTAG(TAG_Nothing);
                                        }
                                        default: return heff_nomatch(v_t_2420);
                                        }
                                      }
                                      default: return heff_nomatch(v_t_2419);
                                      }
                                    }
                                    default: return heff_nomatch(v_t_2418);
                                    }
                                  }
                                  default: return heff_nomatch(v_t_2417);
                                  }
                                }
                                default: return heff_nomatch(v_t_2416);
                                }
                              }
                              default: return heff_nomatch(v_t_2415);
                              }
                            }
                            default: return heff_nomatch(v_t_2414);
                            }
                          }
                          default: return heff_nomatch(v_t_2413);
                          }
                        }
                        default: return heff_nomatch(v_t_2412);
                        }
                      }
                      default: return heff_nomatch(v_t_2411);
                      }
                    }
                    default: return heff_nomatch(v_t_2410);
                    }
                  }
                  default: return heff_nomatch(v_t_249);
                  }
                }
                default: return heff_nomatch(v_t_248);
                }
              }
              default: return heff_nomatch(v_t_247);
              }
            }
            default: return heff_nomatch(v_t_246);
            }
          }
          default: return heff_nomatch(v_t_245);
          }
        }
        default: return heff_nomatch(v_t_244);
        }
      }
      default: return heff_nomatch(v_t_243);
      }
    }
    default: return heff_nomatch(v_t_242);
    }
  }
  default: return heff_nomatch(v_t_241);
  }
}
V g_heff_2eemit_2ewordOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2eemit_2ewordOf(a[0]);
}
Clo g_heff_2eemit_2eoperatorGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemit_2eoperatorGo_entry, 3, 0};

V g_heff_2eemit_2eoperatorGo(V v_x_240, V v_i_241, V v_acc_242) {
top: ;
  V v_t_243 = heff_intLe(heff_strLength(heff_dup(v_x_240)), heff_dup(v_i_241));
  switch (heff_tag_of(v_t_243)) {
  case TAG_True: {
    heff_drop(v_x_240);
    heff_drop(v_i_241);
    return heff_tag(TAG_Just, 1, (V[]){(g_prelude_2efoldl_24s0(NTAG(TAG_Nil), v_acc_242))});
  }
  case TAG_False: {
    V v_t_244 = (g_heff_2eemit_2ewordOf(heff_strCharCode(heff_dup(v_x_240), heff_dup(v_i_241))));
    switch (heff_tag_of(v_t_244)) {
    case TAG_Nothing: {
      heff_drop(v_x_240);
      heff_drop(v_i_241);
      heff_drop(v_acc_242);
      return NTAG(TAG_Nothing);
    }
    case TAG_Just: {
      V v_w_245 = heff_field(v_t_244, 0);
      heff_take_n(v_t_244, 1ULL, 1);
      V t_0 = v_x_240;
      V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
      V t_2 = heff_tag(TAG_Cons, 2, (V[]){v_w_245, v_acc_242});
      v_x_240 = t_0;
      v_i_241 = t_1;
      v_acc_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_heff_2eemit_2eoperatorGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2eemit_2eoperatorGo(a[0], a[1], a[2]);
}
Clo g_heff_2eemit_2elastDotFrom_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemit_2elastDotFrom_entry, 2, 0};

V g_heff_2eemit_2elastDotFrom(V v_s_240, V v_i_241) {
top: ;
  V v_t_242 = heff_intLt(heff_dup(v_i_241), MK_INT(0LL));
  switch (heff_tag_of(v_t_242)) {
  case TAG_True: {
    heff_drop(v_s_240);
    heff_drop(v_i_241);
    return NTAG(TAG_Nothing);
  }
  case TAG_False: {
    V v_t_243 = heff_intEq(heff_strCharCode(heff_dup(v_s_240), heff_dup(v_i_241)), MK_INT(46LL));
    switch (heff_tag_of(v_t_243)) {
    case TAG_True: {
      heff_drop(v_s_240);
      return heff_tag(TAG_Just, 1, (V[]){v_i_241});
    }
    case TAG_False: {
      V t_0 = v_s_240;
      V t_1 = heff_intSub(v_i_241, MK_INT(1LL));
      v_s_240 = t_0;
      v_i_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_t_243);
    }
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2eemit_2elastDotFrom_entry(V self, V *a) {
  (void)self;
  return g_heff_2eemit_2elastDotFrom(a[0], a[1]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2espellAt_str0 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2espellAt_str1 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemit_2espellAt_str2 = {{0x80000000u, K_STR, 0}, 3, 3, {111, 112, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2espellAt_str3 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2espellAt_str4 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2espellAt_str5 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemit_2espellAt_str6 = {{0x80000000u, K_STR, 0}, 3, 3, {111, 112, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2espellAt_str7 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2espellAt_str8 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemit_2espellAt_str9 = {{0x80000000u, K_STR, 0}, 3, 3, {111, 112, 95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2espellAt_str10 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemit_2espellAt_str11 = {{0x80000000u, K_STR, 0}, 3, 3, {111, 112, 95}};
Clo g_heff_2eemit_2espellAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemit_2espellAt_entry, 2, 0};

V g_heff_2eemit_2espellAt(V v_k_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nothing: {
    V v_t_242 = heff_strEq(heff_dup(v_k_240), ((V)&g_heff_2eemit_2espellAt_str0));
    V v_x2_248;
    switch (heff_tag_of(v_t_242)) {
    case TAG_True: {
      v_x2_248 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_False: {
      V v_x1_243 = (g_heff_2eemit_2eoperatorGo(heff_dup(v_k_240), MK_INT(0LL), NTAG(TAG_Nil)));
      switch (heff_tag_of(v_x1_243)) {
      case TAG_Nothing: {
        v_x2_248 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Just: {
        V v_ws_244 = heff_field(v_x1_243, 0);
        V v_ru_24x1_243_24Just = heff_take_reuse_n(v_x1_243, 1ULL, 1);
        V v_t_247;
        switch (heff_tag_of(v_ws_244)) {
        case TAG_Nil: {
          v_t_247 = ((V)&g_heff_2eemit_2espellAt_str1);
          break;
        }
        case TAG_Cons: {
          V v_x_245 = heff_field(v_ws_244, 0);
          V v_xs_246 = heff_field(v_ws_244, 1);
          heff_take_n(v_ws_244, 3ULL, 2);
          v_t_247 = ({ V a_0 = v_x_245; V a_1 = v_xs_246; V r_ = (g_prelude_2efoldl_24s89(a_0, a_1)); heff_drop(v_xs_246); r_; });
          break;
        }
        default: heff_nomatch(v_ws_244);
        }
        v_x2_248 = heff_tag_at(v_ru_24x1_243_24Just, TAG_Just, 1, (V[]){heff_strAppend(((V)&g_heff_2eemit_2espellAt_str2), v_t_247)});
        break;
      }
      default: heff_nomatch(v_x1_243);
      }
      break;
    }
    default: heff_nomatch(v_t_242);
    }
    switch (heff_tag_of(v_x2_248)) {
    case TAG_Nothing: {
      return v_k_240;
    }
    case TAG_Just: {
      V v_x_249 = heff_field(v_x2_248, 0);
      heff_take_n(v_x2_248, 1ULL, 1);
      heff_drop(v_k_240);
      return v_x_249;
    }
    default: return heff_nomatch(v_x2_248);
    }
  }
  case TAG_Just: {
    V v_i_2410 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24Just = heff_take_reuse_n(v_x2_241, 1ULL, 1);
    V v_x_2411 = heff_strSlice(heff_dup(v_k_240), heff_intAdd(heff_dup(v_i_2410), MK_INT(1LL)), heff_strLength(heff_dup(v_k_240)));
    V v_t_2412 = heff_strEq(heff_dup(v_x_2411), ((V)&g_heff_2eemit_2espellAt_str3));
    switch (heff_tag_of(v_t_2412)) {
    case TAG_True: {
      heff_drop(v_i_2410);
      heff_drop(v_x_2411);
      V v_t_2413 = heff_strEq(heff_dup(v_k_240), ((V)&g_heff_2eemit_2espellAt_str4));
      V v_x2_2419;
      switch (heff_tag_of(v_t_2413)) {
      case TAG_True: {
        heff_drop_cell(v_ru_24x2_241_24Just, 1);
        v_x2_2419 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_False: {
        V v_x1_2414 = (g_heff_2eemit_2eoperatorGo(heff_dup(v_k_240), MK_INT(0LL), NTAG(TAG_Nil)));
        switch (heff_tag_of(v_x1_2414)) {
        case TAG_Nothing: {
          heff_drop_cell(v_ru_24x2_241_24Just, 1);
          v_x2_2419 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_Just: {
          V v_ws_2415 = heff_field(v_x1_2414, 0);
          heff_take_n(v_x1_2414, 1ULL, 1);
          V v_t_2418;
          switch (heff_tag_of(v_ws_2415)) {
          case TAG_Nil: {
            v_t_2418 = ((V)&g_heff_2eemit_2espellAt_str5);
            break;
          }
          case TAG_Cons: {
            V v_x_2416 = heff_field(v_ws_2415, 0);
            V v_xs_2417 = heff_field(v_ws_2415, 1);
            heff_take_n(v_ws_2415, 3ULL, 2);
            v_t_2418 = ({ V a_0 = v_x_2416; V a_1 = v_xs_2417; V r_ = (g_prelude_2efoldl_24s89(a_0, a_1)); heff_drop(v_xs_2417); r_; });
            break;
          }
          default: heff_nomatch(v_ws_2415);
          }
          v_x2_2419 = heff_tag_at(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){heff_strAppend(((V)&g_heff_2eemit_2espellAt_str6), v_t_2418)});
          break;
        }
        default: heff_nomatch(v_x1_2414);
        }
        break;
      }
      default: heff_nomatch(v_t_2413);
      }
      switch (heff_tag_of(v_x2_2419)) {
      case TAG_Nothing: {
        return v_k_240;
      }
      case TAG_Just: {
        V v_x_2420 = heff_field(v_x2_2419, 0);
        heff_take_n(v_x2_2419, 1ULL, 1);
        heff_drop(v_k_240);
        return v_x_2420;
      }
      default: return heff_nomatch(v_x2_2419);
      }
    }
    case TAG_False: {
      V v_x1_2421 = (g_heff_2eemit_2eoperatorGo(v_x_2411, MK_INT(0LL), NTAG(TAG_Nil)));
      switch (heff_tag_of(v_x1_2421)) {
      case TAG_Nothing: {
        heff_drop(v_i_2410);
        V v_t_2422 = heff_strEq(heff_dup(v_k_240), ((V)&g_heff_2eemit_2espellAt_str7));
        V v_x2_2428;
        switch (heff_tag_of(v_t_2422)) {
        case TAG_True: {
          heff_drop_cell(v_ru_24x2_241_24Just, 1);
          v_x2_2428 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_False: {
          V v_x1_2423 = (g_heff_2eemit_2eoperatorGo(heff_dup(v_k_240), MK_INT(0LL), NTAG(TAG_Nil)));
          switch (heff_tag_of(v_x1_2423)) {
          case TAG_Nothing: {
            heff_drop_cell(v_ru_24x2_241_24Just, 1);
            v_x2_2428 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_Just: {
            V v_ws_2424 = heff_field(v_x1_2423, 0);
            heff_take_n(v_x1_2423, 1ULL, 1);
            V v_t_2427;
            switch (heff_tag_of(v_ws_2424)) {
            case TAG_Nil: {
              v_t_2427 = ((V)&g_heff_2eemit_2espellAt_str8);
              break;
            }
            case TAG_Cons: {
              V v_x_2425 = heff_field(v_ws_2424, 0);
              V v_xs_2426 = heff_field(v_ws_2424, 1);
              heff_take_n(v_ws_2424, 3ULL, 2);
              v_t_2427 = ({ V a_0 = v_x_2425; V a_1 = v_xs_2426; V r_ = (g_prelude_2efoldl_24s89(a_0, a_1)); heff_drop(v_xs_2426); r_; });
              break;
            }
            default: heff_nomatch(v_ws_2424);
            }
            v_x2_2428 = heff_tag_at(v_ru_24x2_241_24Just, TAG_Just, 1, (V[]){heff_strAppend(((V)&g_heff_2eemit_2espellAt_str9), v_t_2427)});
            break;
          }
          default: heff_nomatch(v_x1_2423);
          }
          break;
        }
        default: heff_nomatch(v_t_2422);
        }
        switch (heff_tag_of(v_x2_2428)) {
        case TAG_Nothing: {
          return v_k_240;
        }
        case TAG_Just: {
          V v_x_2429 = heff_field(v_x2_2428, 0);
          heff_take_n(v_x2_2428, 1ULL, 1);
          heff_drop(v_k_240);
          return v_x_2429;
        }
        default: return heff_nomatch(v_x2_2428);
        }
      }
      case TAG_Just: {
        V v_ws_2430 = heff_field(v_x1_2421, 0);
        heff_take_n(v_x1_2421, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_241_24Just, 1);
        V v_t_2433;
        switch (heff_tag_of(v_ws_2430)) {
        case TAG_Nil: {
          v_t_2433 = ((V)&g_heff_2eemit_2espellAt_str10);
          break;
        }
        case TAG_Cons: {
          V v_x_2431 = heff_field(v_ws_2430, 0);
          V v_xs_2432 = heff_field(v_ws_2430, 1);
          heff_take_n(v_ws_2430, 3ULL, 2);
          v_t_2433 = ({ V a_0 = v_x_2431; V a_1 = v_xs_2432; V r_ = (g_prelude_2efoldl_24s89(a_0, a_1)); heff_drop(v_xs_2432); r_; });
          break;
        }
        default: heff_nomatch(v_ws_2430);
        }
        V v_w_2434 = heff_strAppend(((V)&g_heff_2eemit_2espellAt_str11), v_t_2433);
        V v_t_2435 = heff_strSlice(v_k_240, MK_INT(0LL), heff_intAdd(v_i_2410, MK_INT(1LL)));
        return heff_strAppend(v_t_2435, v_w_2434);
      }
      default: return heff_nomatch(v_x1_2421);
      }
    }
    default: return heff_nomatch(v_t_2412);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eemit_2espellAt_entry(V self, V *a) {
  (void)self;
  return g_heff_2eemit_2espellAt(a[0], a[1]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[11]; } g_heff_2eemit_2ereserved_str0 = {{0x80000000u, K_STR, 0}, 11, 11, {84, 101, 120, 116, 68, 101, 99, 111, 100, 101, 114}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemit_2ereserved_str1 = {{0x80000000u, K_STR, 0}, 3, 3, {85, 82, 76}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[11]; } g_heff_2eemit_2ereserved_str2 = {{0x80000000u, K_STR, 0}, 11, 11, {84, 101, 120, 116, 69, 110, 99, 111, 100, 101, 114}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[14]; } g_heff_2eemit_2ereserved_str3 = {{0x80000000u, K_STR, 0}, 14, 14, {113, 117, 101, 117, 101, 77, 105, 99, 114, 111, 116, 97, 115, 107}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[15]; } g_heff_2eemit_2ereserved_str4 = {{0x80000000u, K_STR, 0}, 15, 15, {115, 116, 114, 117, 99, 116, 117, 114, 101, 100, 67, 108, 111, 110, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2eemit_2ereserved_str5 = {{0x80000000u, K_STR, 0}, 6, 6, {66, 117, 102, 102, 101, 114}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[12]; } g_heff_2eemit_2ereserved_str6 = {{0x80000000u, K_STR, 0}, 12, 12, {115, 101, 116, 73, 109, 109, 101, 100, 105, 97, 116, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2eemit_2ereserved_str7 = {{0x80000000u, K_STR, 0}, 6, 6, {83, 121, 109, 98, 111, 108}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2eemit_2ereserved_str8 = {{0x80000000u, K_STR, 0}, 6, 6, {82, 101, 103, 69, 120, 112}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemit_2ereserved_str9 = {{0x80000000u, K_STR, 0}, 3, 3, {83, 101, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eemit_2ereserved_str10 = {{0x80000000u, K_STR, 0}, 4, 4, {68, 97, 116, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eemit_2ereserved_str11 = {{0x80000000u, K_STR, 0}, 5, 5, {65, 114, 114, 97, 121}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemit_2ereserved_str12 = {{0x80000000u, K_STR, 0}, 3, 3, {77, 97, 112}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[10]; } g_heff_2eemit_2ereserved_str13 = {{0x80000000u, K_STR, 0}, 10, 10, {103, 108, 111, 98, 97, 108, 84, 104, 105, 115}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2eemit_2ereserved_str14 = {{0x80000000u, K_STR, 0}, 7, 7, {80, 114, 111, 109, 105, 115, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2eemit_2ereserved_str15 = {{0x80000000u, K_STR, 0}, 7, 7, {112, 114, 111, 99, 101, 115, 115}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2eemit_2ereserved_str16 = {{0x80000000u, K_STR, 0}, 7, 7, {99, 111, 110, 115, 111, 108, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[10]; } g_heff_2eemit_2ereserved_str17 = {{0x80000000u, K_STR, 0}, 10, 10, {115, 101, 116, 84, 105, 109, 101, 111, 117, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eemit_2ereserved_str18 = {{0x80000000u, K_STR, 0}, 5, 5, {102, 101, 116, 99, 104}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eemit_2ereserved_str19 = {{0x80000000u, K_STR, 0}, 4, 4, {77, 97, 116, 104}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eemit_2ereserved_str20 = {{0x80000000u, K_STR, 0}, 4, 4, {74, 83, 79, 78}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2eemit_2ereserved_str21 = {{0x80000000u, K_STR, 0}, 6, 6, {79, 98, 106, 101, 99, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eemit_2ereserved_str22 = {{0x80000000u, K_STR, 0}, 5, 5, {69, 114, 114, 111, 114}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2eemit_2ereserved_str23 = {{0x80000000u, K_STR, 0}, 6, 6, {83, 116, 114, 105, 110, 103}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2eemit_2ereserved_str24 = {{0x80000000u, K_STR, 0}, 6, 6, {78, 117, 109, 98, 101, 114}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2eemit_2ereserved_str25 = {{0x80000000u, K_STR, 0}, 6, 6, {119, 105, 110, 100, 111, 119}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2eemit_2ereserved_str26 = {{0x80000000u, K_STR, 0}, 6, 6, {66, 105, 103, 73, 110, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2eemit_2ereserved_str27 = {{0x80000000u, K_STR, 0}, 8, 8, {73, 110, 102, 105, 110, 105, 116, 121}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2eemit_2ereserved_str28 = {{0x80000000u, K_STR, 0}, 8, 8, {100, 111, 99, 117, 109, 101, 110, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2eemit_2ereserved_str29 = {{0x80000000u, K_STR, 0}, 9, 9, {117, 110, 100, 101, 102, 105, 110, 101, 100}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemit_2ereserved_str30 = {{0x80000000u, K_STR, 0}, 3, 3, {78, 97, 78}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2eemit_2ereserved_str31 = {{0x80000000u, K_STR, 0}, 9, 9, {97, 114, 103, 117, 109, 101, 110, 116, 115}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eemit_2ereserved_str32 = {{0x80000000u, K_STR, 0}, 4, 4, {101, 118, 97, 108}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2eemit_2ereserved_str33 = {{0x80000000u, K_STR, 0}, 6, 6, {112, 117, 98, 108, 105, 99}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eemit_2ereserved_str34 = {{0x80000000u, K_STR, 0}, 5, 5, {97, 119, 97, 105, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2eemit_2ereserved_str35 = {{0x80000000u, K_STR, 0}, 7, 7, {112, 114, 105, 118, 97, 116, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2eemit_2ereserved_str36 = {{0x80000000u, K_STR, 0}, 9, 9, {112, 114, 111, 116, 101, 99, 116, 101, 100}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2eemit_2ereserved_str37 = {{0x80000000u, K_STR, 0}, 9, 9, {105, 110, 116, 101, 114, 102, 97, 99, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2eemit_2ereserved_str38 = {{0x80000000u, K_STR, 0}, 7, 7, {112, 97, 99, 107, 97, 103, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2eemit_2ereserved_str39 = {{0x80000000u, K_STR, 0}, 6, 6, {115, 116, 97, 116, 105, 99}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[10]; } g_heff_2eemit_2ereserved_str40 = {{0x80000000u, K_STR, 0}, 10, 10, {105, 109, 112, 108, 101, 109, 101, 110, 116, 115}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eemit_2ereserved_str41 = {{0x80000000u, K_STR, 0}, 5, 5, {121, 105, 101, 108, 100}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemit_2ereserved_str42 = {{0x80000000u, K_STR, 0}, 3, 3, {108, 101, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eemit_2ereserved_str43 = {{0x80000000u, K_STR, 0}, 5, 5, {119, 104, 105, 108, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eemit_2ereserved_str44 = {{0x80000000u, K_STR, 0}, 4, 4, {119, 105, 116, 104}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemit_2ereserved_str45 = {{0x80000000u, K_STR, 0}, 3, 3, {118, 97, 114}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eemit_2ereserved_str46 = {{0x80000000u, K_STR, 0}, 4, 4, {118, 111, 105, 100}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemit_2ereserved_str47 = {{0x80000000u, K_STR, 0}, 3, 3, {116, 114, 121}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2eemit_2ereserved_str48 = {{0x80000000u, K_STR, 0}, 6, 6, {116, 121, 112, 101, 111, 102}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eemit_2ereserved_str49 = {{0x80000000u, K_STR, 0}, 5, 5, {116, 104, 114, 111, 119}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eemit_2ereserved_str50 = {{0x80000000u, K_STR, 0}, 4, 4, {116, 114, 117, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2eemit_2ereserved_str51 = {{0x80000000u, K_STR, 0}, 6, 6, {115, 119, 105, 116, 99, 104}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eemit_2ereserved_str52 = {{0x80000000u, K_STR, 0}, 4, 4, {116, 104, 105, 115}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2eemit_2ereserved_str53 = {{0x80000000u, K_STR, 0}, 6, 6, {114, 101, 116, 117, 114, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eemit_2ereserved_str54 = {{0x80000000u, K_STR, 0}, 5, 5, {115, 117, 112, 101, 114}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemit_2ereserved_str55 = {{0x80000000u, K_STR, 0}, 3, 3, {110, 101, 119}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eemit_2ereserved_str56 = {{0x80000000u, K_STR, 0}, 4, 4, {110, 117, 108, 108}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemit_2ereserved_str57 = {{0x80000000u, K_STR, 0}, 2, 2, {105, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[10]; } g_heff_2eemit_2ereserved_str58 = {{0x80000000u, K_STR, 0}, 10, 10, {105, 110, 115, 116, 97, 110, 99, 101, 111, 102}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemit_2ereserved_str59 = {{0x80000000u, K_STR, 0}, 2, 2, {105, 102}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2eemit_2ereserved_str60 = {{0x80000000u, K_STR, 0}, 6, 6, {105, 109, 112, 111, 114, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemit_2ereserved_str61 = {{0x80000000u, K_STR, 0}, 3, 3, {102, 111, 114}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2eemit_2ereserved_str62 = {{0x80000000u, K_STR, 0}, 8, 8, {102, 117, 110, 99, 116, 105, 111, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eemit_2ereserved_str63 = {{0x80000000u, K_STR, 0}, 5, 5, {102, 97, 108, 115, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2eemit_2ereserved_str64 = {{0x80000000u, K_STR, 0}, 7, 7, {102, 105, 110, 97, 108, 108, 121}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2eemit_2ereserved_str65 = {{0x80000000u, K_STR, 0}, 6, 6, {101, 120, 112, 111, 114, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2eemit_2ereserved_str66 = {{0x80000000u, K_STR, 0}, 7, 7, {101, 120, 116, 101, 110, 100, 115}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eemit_2ereserved_str67 = {{0x80000000u, K_STR, 0}, 4, 4, {101, 108, 115, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eemit_2ereserved_str68 = {{0x80000000u, K_STR, 0}, 4, 4, {101, 110, 117, 109}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2eemit_2ereserved_str69 = {{0x80000000u, K_STR, 0}, 6, 6, {100, 101, 108, 101, 116, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemit_2ereserved_str70 = {{0x80000000u, K_STR, 0}, 2, 2, {100, 111}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2eemit_2ereserved_str71 = {{0x80000000u, K_STR, 0}, 8, 8, {100, 101, 98, 117, 103, 103, 101, 114}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2eemit_2ereserved_str72 = {{0x80000000u, K_STR, 0}, 7, 7, {100, 101, 102, 97, 117, 108, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eemit_2ereserved_str73 = {{0x80000000u, K_STR, 0}, 5, 5, {99, 111, 110, 115, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2eemit_2ereserved_str74 = {{0x80000000u, K_STR, 0}, 8, 8, {99, 111, 110, 116, 105, 110, 117, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eemit_2ereserved_str75 = {{0x80000000u, K_STR, 0}, 5, 5, {99, 97, 116, 99, 104}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eemit_2ereserved_str76 = {{0x80000000u, K_STR, 0}, 5, 5, {99, 108, 97, 115, 115}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eemit_2ereserved_str77 = {{0x80000000u, K_STR, 0}, 5, 5, {98, 114, 101, 97, 107}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eemit_2ereserved_str78 = {{0x80000000u, K_STR, 0}, 4, 4, {99, 97, 115, 101}};

static V g_heff_2eemit_2ereserved_val;
static int g_heff_2eemit_2ereserved_st;
static V g_heff_2eemit_2ereserved_init(void) {
  V v_t_240 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemit_2ereserved_str0), NTAG(TAG_Nil)});
  V v_t_241 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemit_2ereserved_str1), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemit_2ereserved_str2), v_t_240})});
  V v_t_242 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemit_2ereserved_str3), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemit_2ereserved_str4), v_t_241})});
  V v_t_243 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemit_2ereserved_str5), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemit_2ereserved_str6), v_t_242})});
  V v_t_244 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemit_2ereserved_str7), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemit_2ereserved_str8), v_t_243})});
  V v_t_245 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemit_2ereserved_str9), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemit_2ereserved_str10), v_t_244})});
  V v_t_246 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemit_2ereserved_str11), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemit_2ereserved_str12), v_t_245})});
  V v_t_247 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemit_2ereserved_str13), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemit_2ereserved_str14), v_t_246})});
  V v_t_248 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemit_2ereserved_str15), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemit_2ereserved_str16), v_t_247})});
  V v_t_249 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemit_2ereserved_str17), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemit_2ereserved_str18), v_t_248})});
  V v_t_2410 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemit_2ereserved_str19), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemit_2ereserved_str20), v_t_249})});
  V v_t_2411 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemit_2ereserved_str21), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemit_2ereserved_str22), v_t_2410})});
  V v_t_2412 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemit_2ereserved_str23), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemit_2ereserved_str24), v_t_2411})});
  V v_t_2413 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemit_2ereserved_str25), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemit_2ereserved_str26), v_t_2412})});
  V v_t_2414 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemit_2ereserved_str27), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemit_2ereserved_str28), v_t_2413})});
  V v_t_2415 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemit_2ereserved_str29), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemit_2ereserved_str30), v_t_2414})});
  V v_t_2416 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemit_2ereserved_str31), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemit_2ereserved_str32), v_t_2415})});
  V v_t_2417 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemit_2ereserved_str33), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemit_2ereserved_str34), v_t_2416})});
  V v_t_2418 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemit_2ereserved_str35), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemit_2ereserved_str36), v_t_2417})});
  V v_t_2419 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemit_2ereserved_str37), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemit_2ereserved_str38), v_t_2418})});
  V v_t_2420 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemit_2ereserved_str39), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemit_2ereserved_str40), v_t_2419})});
  V v_t_2421 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemit_2ereserved_str41), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemit_2ereserved_str42), v_t_2420})});
  V v_t_2422 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemit_2ereserved_str43), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemit_2ereserved_str44), v_t_2421})});
  V v_t_2423 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemit_2ereserved_str45), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemit_2ereserved_str46), v_t_2422})});
  V v_t_2424 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemit_2ereserved_str47), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemit_2ereserved_str48), v_t_2423})});
  V v_t_2425 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemit_2ereserved_str49), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemit_2ereserved_str50), v_t_2424})});
  V v_t_2426 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemit_2ereserved_str51), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemit_2ereserved_str52), v_t_2425})});
  V v_t_2427 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemit_2ereserved_str53), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemit_2ereserved_str54), v_t_2426})});
  V v_t_2428 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemit_2ereserved_str55), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemit_2ereserved_str56), v_t_2427})});
  V v_t_2429 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemit_2ereserved_str57), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemit_2ereserved_str58), v_t_2428})});
  V v_t_2430 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemit_2ereserved_str59), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemit_2ereserved_str60), v_t_2429})});
  V v_t_2431 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemit_2ereserved_str61), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemit_2ereserved_str62), v_t_2430})});
  V v_t_2432 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemit_2ereserved_str63), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemit_2ereserved_str64), v_t_2431})});
  V v_t_2433 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemit_2ereserved_str65), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemit_2ereserved_str66), v_t_2432})});
  V v_t_2434 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemit_2ereserved_str67), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemit_2ereserved_str68), v_t_2433})});
  V v_t_2435 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemit_2ereserved_str69), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemit_2ereserved_str70), v_t_2434})});
  V v_t_2436 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemit_2ereserved_str71), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemit_2ereserved_str72), v_t_2435})});
  V v_t_2437 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemit_2ereserved_str73), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemit_2ereserved_str74), v_t_2436})});
  V v_t_2438 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemit_2ereserved_str75), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemit_2ereserved_str76), v_t_2437})});
  return heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemit_2ereserved_str77), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemit_2ereserved_str78), v_t_2438})});
}
V g_heff_2eemit_2ereserved_get(void) {
  if (g_heff_2eemit_2ereserved_st == 2) return g_heff_2eemit_2ereserved_val;
  if (g_heff_2eemit_2ereserved_st == 1) heff_fail("defined by itself");
  g_heff_2eemit_2ereserved_st = 1;
  g_heff_2eemit_2ereserved_val = heff_tr(g_heff_2eemit_2ereserved_init());
  g_heff_2eemit_2ereserved_st = 2;
  return g_heff_2eemit_2ereserved_val;
}
Clo g_heff_2eemit_2eisWordCode_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemit_2eisWordCode_entry, 1, 0};

V g_heff_2eemit_2eisWordCode(V v_c_240) {
top: ;
  V v_t_241 = heff_intLe(MK_INT(97LL), heff_dup(v_c_240));
  V v_t_242;
  switch (heff_tag_of(v_t_241)) {
  case TAG_True: {
    v_t_242 = heff_intLe(heff_dup(v_c_240), MK_INT(122LL));
    break;
  }
  case TAG_False: {
    v_t_242 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_t_241);
  }
  switch (heff_tag_of(v_t_242)) {
  case TAG_True: {
    heff_drop(v_c_240);
    return NTAG(TAG_True);
  }
  case TAG_False: {
    V v_t_243 = heff_intLe(MK_INT(65LL), heff_dup(v_c_240));
    switch (heff_tag_of(v_t_243)) {
    case TAG_True: {
      V v_t_244 = heff_intLe(heff_dup(v_c_240), MK_INT(90LL));
      switch (heff_tag_of(v_t_244)) {
      case TAG_True: {
        heff_drop(v_c_240);
        return NTAG(TAG_True);
      }
      case TAG_False: {
        V v_t_245 = heff_intLe(MK_INT(48LL), heff_dup(v_c_240));
        switch (heff_tag_of(v_t_245)) {
        case TAG_True: {
          V v_t_246 = heff_intLe(heff_dup(v_c_240), MK_INT(57LL));
          switch (heff_tag_of(v_t_246)) {
          case TAG_True: {
            heff_drop(v_c_240);
            return NTAG(TAG_True);
          }
          case TAG_False: {
            return heff_intEq(v_c_240, MK_INT(95LL));
          }
          default: return heff_nomatch(v_t_246);
          }
        }
        case TAG_False: {
          return heff_intEq(v_c_240, MK_INT(95LL));
        }
        default: return heff_nomatch(v_t_245);
        }
      }
      default: return heff_nomatch(v_t_244);
      }
    }
    case TAG_False: {
      V v_t_247 = heff_intLe(MK_INT(48LL), heff_dup(v_c_240));
      switch (heff_tag_of(v_t_247)) {
      case TAG_True: {
        V v_t_248 = heff_intLe(heff_dup(v_c_240), MK_INT(57LL));
        switch (heff_tag_of(v_t_248)) {
        case TAG_True: {
          heff_drop(v_c_240);
          return NTAG(TAG_True);
        }
        case TAG_False: {
          return heff_intEq(v_c_240, MK_INT(95LL));
        }
        default: return heff_nomatch(v_t_248);
        }
      }
      case TAG_False: {
        return heff_intEq(v_c_240, MK_INT(95LL));
      }
      default: return heff_nomatch(v_t_247);
      }
    }
    default: return heff_nomatch(v_t_243);
    }
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2eemit_2eisWordCode_entry(V self, V *a) {
  (void)self;
  return g_heff_2eemit_2eisWordCode(a[0]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2esafeChars_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {95}};
Clo g_heff_2eemit_2esafeChars_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemit_2esafeChars_entry, 3, 0};

V g_heff_2eemit_2esafeChars(V v_x_240, V v_i_241, V v_acc_242) {
top: ;
  V v_t_243 = heff_intLe(heff_strLength(heff_dup(v_x_240)), heff_dup(v_i_241));
  switch (heff_tag_of(v_t_243)) {
  case TAG_True: {
    heff_drop(v_x_240);
    heff_drop(v_i_241);
    return v_acc_242;
  }
  case TAG_False: {
    V v_t_244 = (g_heff_2eemit_2eisWordCode(heff_strCharCode(heff_dup(v_x_240), heff_dup(v_i_241))));
    V v_t_245;
    switch (heff_tag_of(v_t_244)) {
    case TAG_True: {
      v_t_245 = heff_strSlice(heff_dup(v_x_240), heff_dup(v_i_241), heff_intAdd(heff_dup(v_i_241), MK_INT(1LL)));
      break;
    }
    case TAG_False: {
      v_t_245 = ((V)&g_heff_2eemit_2esafeChars_str0);
      break;
    }
    default: heff_nomatch(v_t_244);
    }
    V t_0 = v_x_240;
    V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
    V t_2 = heff_strAppend(v_acc_242, v_t_245);
    v_x_240 = t_0;
    v_i_241 = t_1;
    v_acc_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_heff_2eemit_2esafeChars_entry(V self, V *a) {
  (void)self;
  return g_heff_2eemit_2esafeChars(a[0], a[1], a[2]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2esafeRes_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {95}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2esafeRes_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {95}};
Clo g_heff_2eemit_2esafeRes_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemit_2esafeRes_entry, 1, 0};

V g_heff_2eemit_2esafeRes(V v_s_240) {
top: ;
  V v_t_241 = heff_tr(heff_apply(((V)&prim_strEq_clo), 1, (V[]){heff_dup(v_s_240)}));
  V v_t_242 = ({ V a_0 = v_t_241; V b_1 = heff_dup(g_heff_2eemit_2ereserved_get()); V r_ = (g_prelude_2eany(a_0, b_1)); heff_drop(b_1); r_; });
  switch (heff_tag_of(v_t_242)) {
  case TAG_True: {
    return heff_strAppend(((V)&g_heff_2eemit_2esafeRes_str0), v_s_240);
  }
  case TAG_False: {
    V v_t_243 = heff_intLe(MK_INT(48LL), heff_strCharCode(heff_dup(v_s_240), MK_INT(0LL)));
    switch (heff_tag_of(v_t_243)) {
    case TAG_True: {
      V v_t_244 = heff_intLe(heff_strCharCode(heff_dup(v_s_240), MK_INT(0LL)), MK_INT(57LL));
      switch (heff_tag_of(v_t_244)) {
      case TAG_True: {
        return heff_strAppend(((V)&g_heff_2eemit_2esafeRes_str1), v_s_240);
      }
      case TAG_False: {
        return v_s_240;
      }
      default: return heff_nomatch(v_t_244);
      }
    }
    case TAG_False: {
      return v_s_240;
    }
    default: return heff_nomatch(v_t_243);
    }
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2eemit_2esafeRes_entry(V self, V *a) {
  (void)self;
  return g_heff_2eemit_2esafeRes(a[0]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2eisIdent_str0 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2eisIdent_str1 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2eisIdent_str2 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2eisIdent_str3 = {{0x80000000u, K_STR, 0}, 1, 1, {120}};
Clo g_heff_2eemit_2eisIdent_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemit_2eisIdent_entry, 1, 0};

V g_heff_2eemit_2eisIdent(V v_x_240) {
top: ;
  V v_t_241 = heff_strEq(heff_dup(v_x_240), ((V)&g_heff_2eemit_2eisIdent_str0));
  switch (heff_tag_of(v_t_241)) {
  case TAG_True: {
    heff_drop(v_x_240);
    return NTAG(TAG_False);
  }
  case TAG_False: {
    V v_t_242 = heff_intSub(heff_strLength(heff_dup(v_x_240)), MK_INT(1LL));
    V v_t_243 = (g_heff_2eemit_2elastDotFrom(heff_dup(v_x_240), v_t_242));
    V v_t_244 = (g_heff_2eemit_2espellAt(heff_dup(v_x_240), v_t_243));
    V v_s_245 = (g_heff_2eemit_2esafeChars(v_t_244, MK_INT(0LL), ((V)&g_heff_2eemit_2eisIdent_str1)));
    V v_t_246 = heff_strEq(heff_dup(v_s_245), ((V)&g_heff_2eemit_2eisIdent_str2));
    V v_t_247;
    switch (heff_tag_of(v_t_246)) {
    case TAG_True: {
      heff_drop(v_s_245);
      v_t_247 = ((V)&g_heff_2eemit_2eisIdent_str3);
      break;
    }
    case TAG_False: {
      v_t_247 = v_s_245;
      break;
    }
    default: heff_nomatch(v_t_246);
    }
    V v_t_248 = (g_heff_2eemit_2esafeRes(v_t_247));
    return heff_strEq(v_t_248, v_x_240);
  }
  default: return heff_nomatch(v_t_241);
  }
}
V g_heff_2eemit_2eisIdent_entry(V self, V *a) {
  (void)self;
  return g_heff_2eemit_2eisIdent(a[0]);
}
Clo g_heff_2eemit_2evalueRefs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemit_2evalueRefs_entry, 1, 0};

V g_heff_2eemit_2evalueRefs(V v_e_240) {
top: ;
  switch (heff_tag_of(v_e_240)) {
  case TAG_EVar: {
    return NTAG(TAG_Nil);
  }
  case TAG_EGlobal: {
    V v_g_242 = heff_field(v_e_240, 0);
    return heff_tag(TAG_Cons, 2, (V[]){heff_dup(v_g_242), NTAG(TAG_Nil)});
  }
  case TAG_ELam: {
    V v_b_244 = heff_field(v_e_240, 1);
    V t_0 = v_b_244;
    v_e_240 = t_0;
    goto top;
  }
  case TAG_EApp: {
    V v_f_245 = heff_field(v_e_240, 0);
    V v_as_246 = heff_field(v_e_240, 1);
    V v_t_247 = (g_heff_2eemit_2evalueRefs(v_f_245));
    V v_t_248 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), heff_dup(v_as_246)));
    V v_t_249 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_248; V r_ = (g_prelude_2efoldl_24s570(a_0, a_1)); heff_drop(v_t_248); r_; });
    return (g_prelude_2econcatList(v_t_247, v_t_249));
  }
  case TAG_ELet: {
    V v_a_2411 = heff_field(v_e_240, 1);
    V v_b_2412 = heff_field(v_e_240, 2);
    V v_t_2413 = (g_heff_2eemit_2evalueRefs(v_a_2411));
    V v_t_2414 = (g_heff_2eemit_2evalueRefs(v_b_2412));
    return (g_prelude_2econcatList(v_t_2413, v_t_2414));
  }
  case TAG_ERecord: {
    V v_fs_2415 = heff_field(v_e_240, 0);
    V v_t_2416 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), heff_dup(v_fs_2415)));
    return ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2416; V r_ = (g_prelude_2efoldl_24s571(a_0, a_1)); heff_drop(v_t_2416); r_; });
  }
  case TAG_EProj: {
    V v_e2_2417 = heff_field(v_e_240, 0);
    V t_0 = v_e2_2417;
    v_e_240 = t_0;
    goto top;
  }
  case TAG_ETag: {
    V v_as_2420 = heff_field(v_e_240, 1);
    V v_t_2421 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), heff_dup(v_as_2420)));
    return ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2421; V r_ = (g_prelude_2efoldl_24s570(a_0, a_1)); heff_drop(v_t_2421); r_; });
  }
  case TAG_EMatch: {
    V v_s_2422 = heff_field(v_e_240, 0);
    V v_arms_2423 = heff_field(v_e_240, 1);
    V v_t_2424 = (g_heff_2eemit_2evalueRefs(v_s_2422));
    V v_t_2425 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), heff_dup(v_arms_2423)));
    V v_t_2426 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2425; V r_ = (g_prelude_2efoldl_24s572(a_0, a_1)); heff_drop(v_t_2425); r_; });
    return (g_prelude_2econcatList(v_t_2424, v_t_2426));
  }
  case TAG_EPrim: {
    return NTAG(TAG_Nil);
  }
  case TAG_EPrimCall: {
    V v_as_2429 = heff_field(v_e_240, 1);
    V v_t_2430 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), heff_dup(v_as_2429)));
    return ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2430; V r_ = (g_prelude_2efoldl_24s570(a_0, a_1)); heff_drop(v_t_2430); r_; });
  }
  case TAG_ECall: {
    V v_as_2432 = heff_field(v_e_240, 1);
    V v_t_2433 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), heff_dup(v_as_2432)));
    return ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2433; V r_ = (g_prelude_2efoldl_24s570(a_0, a_1)); heff_drop(v_t_2433); r_; });
  }
  case TAG_EInt: {
    return NTAG(TAG_Nil);
  }
  case TAG_EFloat: {
    return NTAG(TAG_Nil);
  }
  case TAG_EStr: {
    return NTAG(TAG_Nil);
  }
  case TAG_EAbandon: {
    return NTAG(TAG_Nil);
  }
  case TAG_EFix: {
    return NTAG(TAG_Nil);
  }
  default: return heff_nomatch(v_e_240);
  }
}
V g_heff_2eemit_2evalueRefs_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eemit_2evalueRefs(a[0]); heff_drop(a[0]); return r;
}
Clo g_heff_2eemit_2etailApp_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemit_2etailApp_entry, 1, 0};

V g_heff_2eemit_2etailApp(V v_e_240) {
top: ;
  switch (heff_tag_of(v_e_240)) {
  case TAG_EVar: {
    return NTAG(TAG_False);
  }
  case TAG_EGlobal: {
    return NTAG(TAG_False);
  }
  case TAG_ELam: {
    return NTAG(TAG_False);
  }
  case TAG_EApp: {
    return NTAG(TAG_True);
  }
  case TAG_ELet: {
    V v_b_249 = heff_field(v_e_240, 2);
    V t_0 = v_b_249;
    v_e_240 = t_0;
    goto top;
  }
  case TAG_ERecord: {
    return NTAG(TAG_False);
  }
  case TAG_EProj: {
    return NTAG(TAG_False);
  }
  case TAG_ETag: {
    return NTAG(TAG_False);
  }
  case TAG_EMatch: {
    V v_arms_2416 = heff_field(v_e_240, 1);
    HEFF_LAST return g_prelude_2eany_24s573(v_arms_2416);
  }
  case TAG_EPrim: {
    return NTAG(TAG_False);
  }
  case TAG_EPrimCall: {
    return NTAG(TAG_False);
  }
  case TAG_ECall: {
    return NTAG(TAG_False);
  }
  case TAG_EInt: {
    return NTAG(TAG_False);
  }
  case TAG_EFloat: {
    return NTAG(TAG_False);
  }
  case TAG_EStr: {
    return NTAG(TAG_False);
  }
  case TAG_EAbandon: {
    return NTAG(TAG_False);
  }
  case TAG_EFix: {
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_e_240);
  }
}
V g_heff_2eemit_2etailApp_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eemit_2etailApp(a[0]); heff_drop(a[0]); return r;
}
Clo g_heff_2eemit_2etailGlobals_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemit_2etailGlobals_entry, 1, 0};

V g_heff_2eemit_2etailGlobals(V v_e_240) {
top: ;
  switch (heff_tag_of(v_e_240)) {
  case TAG_EVar: {
    heff_take_n(v_e_240, 0ULL, 1);
    return NTAG(TAG_Nil);
  }
  case TAG_EGlobal: {
    heff_take_n(v_e_240, 0ULL, 1);
    return NTAG(TAG_Nil);
  }
  case TAG_ELam: {
    heff_take_n(v_e_240, 0ULL, 2);
    return NTAG(TAG_Nil);
  }
  case TAG_EApp: {
    heff_take_n(v_e_240, 0ULL, 2);
    return NTAG(TAG_Nil);
  }
  case TAG_ELet: {
    V v_b_249 = heff_field(v_e_240, 2);
    heff_take_n(v_e_240, 4ULL, 3);
    V t_0 = v_b_249;
    v_e_240 = t_0;
    goto top;
  }
  case TAG_ERecord: {
    heff_take_n(v_e_240, 0ULL, 1);
    return NTAG(TAG_Nil);
  }
  case TAG_EProj: {
    heff_take_n(v_e_240, 0ULL, 2);
    return NTAG(TAG_Nil);
  }
  case TAG_ETag: {
    heff_take_n(v_e_240, 0ULL, 2);
    return NTAG(TAG_Nil);
  }
  case TAG_EMatch: {
    V v_arms_2416 = heff_field(v_e_240, 1);
    heff_take_n(v_e_240, 2ULL, 2);
    V v_t_2417 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), v_arms_2416));
    return ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2417; V r_ = (g_prelude_2efoldl_24s574(a_0, a_1)); heff_drop(v_t_2417); r_; });
  }
  case TAG_EPrim: {
    heff_take_n(v_e_240, 0ULL, 1);
    return NTAG(TAG_Nil);
  }
  case TAG_EPrimCall: {
    heff_take_n(v_e_240, 0ULL, 2);
    return NTAG(TAG_Nil);
  }
  case TAG_ECall: {
    V v_g_2421 = heff_field(v_e_240, 0);
    V v_ru_24e_240_24ECall = heff_take_reuse_n(v_e_240, 1ULL, 2);
    return heff_tag_at(v_ru_24e_240_24ECall, TAG_Cons, 2, (V[]){v_g_2421, NTAG(TAG_Nil)});
  }
  case TAG_EInt: {
    heff_take_n(v_e_240, 0ULL, 1);
    return NTAG(TAG_Nil);
  }
  case TAG_EFloat: {
    heff_take_n(v_e_240, 0ULL, 1);
    return NTAG(TAG_Nil);
  }
  case TAG_EStr: {
    heff_take_n(v_e_240, 0ULL, 1);
    return NTAG(TAG_Nil);
  }
  case TAG_EAbandon: {
    return NTAG(TAG_Nil);
  }
  case TAG_EFix: {
    heff_take_n(v_e_240, 0ULL, 2);
    return NTAG(TAG_Nil);
  }
  default: return heff_nomatch(v_e_240);
  }
}
V g_heff_2eemit_2etailGlobals_entry(V self, V *a) {
  (void)self;
  return g_heff_2eemit_2etailGlobals(a[0]);
}
V g_heff_2eemit_2ebodyBounces_lam0(V self, V *args);
Clo g_heff_2eemit_2ebodyBounces_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemit_2ebodyBounces_entry, 2, 0};

V g_heff_2eemit_2ebodyBounces(V v_set_240, V v_d_241) {
top: ;
  V v_t_242 = heff_get(heff_dup(v_d_241), LBL_body);
  switch (heff_tag_of(v_t_242)) {
  case TAG_EVar: {
    heff_take_n(v_t_242, 0ULL, 1);
    heff_drop(v_d_241);
    return NTAG(TAG_False);
  }
  case TAG_EGlobal: {
    heff_take_n(v_t_242, 0ULL, 1);
    heff_drop(v_d_241);
    return NTAG(TAG_False);
  }
  case TAG_ELam: {
    V v_b_246 = heff_field(v_t_242, 1);
    heff_take_n(v_t_242, 2ULL, 2);
    V v_t_247 = (g_heff_2eemit_2etailApp(v_b_246));
    switch (heff_tag_of(v_t_247)) {
    case TAG_True: {
      heff_drop(v_d_241);
      heff_drop(v_b_246);
      return NTAG(TAG_True);
    }
    case TAG_False: {
      V v_t_248 = (g_heff_2eemit_2etailGlobals(v_b_246));
      return ({ V a_0 = heff_clo(g_heff_2eemit_2ebodyBounces_lam0, 1, 2, (V[]){v_d_241, heff_dup(v_set_240)}); V a_1 = v_t_248; V r_ = (g_prelude_2eany(a_0, a_1)); heff_drop(v_t_248); r_; });
    }
    default: return heff_nomatch(v_t_247);
    }
  }
  case TAG_EApp: {
    heff_take_n(v_t_242, 0ULL, 2);
    heff_drop(v_d_241);
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    heff_take_n(v_t_242, 0ULL, 3);
    heff_drop(v_d_241);
    return NTAG(TAG_False);
  }
  case TAG_ERecord: {
    heff_take_n(v_t_242, 0ULL, 1);
    heff_drop(v_d_241);
    return NTAG(TAG_False);
  }
  case TAG_EProj: {
    heff_take_n(v_t_242, 0ULL, 2);
    heff_drop(v_d_241);
    return NTAG(TAG_False);
  }
  case TAG_ETag: {
    heff_take_n(v_t_242, 0ULL, 2);
    heff_drop(v_d_241);
    return NTAG(TAG_False);
  }
  case TAG_EMatch: {
    heff_take_n(v_t_242, 0ULL, 2);
    heff_drop(v_d_241);
    return NTAG(TAG_False);
  }
  case TAG_EPrim: {
    heff_take_n(v_t_242, 0ULL, 1);
    heff_drop(v_d_241);
    return NTAG(TAG_False);
  }
  case TAG_EPrimCall: {
    heff_take_n(v_t_242, 0ULL, 2);
    heff_drop(v_d_241);
    return NTAG(TAG_False);
  }
  case TAG_ECall: {
    heff_take_n(v_t_242, 0ULL, 2);
    heff_drop(v_d_241);
    return NTAG(TAG_False);
  }
  case TAG_EInt: {
    heff_take_n(v_t_242, 0ULL, 1);
    heff_drop(v_d_241);
    return NTAG(TAG_False);
  }
  case TAG_EFloat: {
    heff_take_n(v_t_242, 0ULL, 1);
    heff_drop(v_d_241);
    return NTAG(TAG_False);
  }
  case TAG_EStr: {
    heff_take_n(v_t_242, 0ULL, 1);
    heff_drop(v_d_241);
    return NTAG(TAG_False);
  }
  case TAG_EAbandon: {
    heff_drop(v_d_241);
    return NTAG(TAG_False);
  }
  case TAG_EFix: {
    heff_take_n(v_t_242, 0ULL, 2);
    heff_drop(v_d_241);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2eemit_2ebodyBounces_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eemit_2ebodyBounces(a[0], a[1]); heff_drop(a[0]); return r;
}
V g_heff_2eemit_2ebodyBounces_lam0(V self, V *args) {
  V v_g_249 = args[0];
  V v_d_241 = heff_env(self)[0];
  V v_set_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2410 = heff_strEq(heff_dup(v_g_249), heff_get(v_d_241, LBL_key));
  switch (heff_tag_of(v_t_2410)) {
  case TAG_True: {
    heff_drop(v_g_249);
    heff_drop(v_set_240);
    return NTAG(TAG_False);
  }
  case TAG_False: {
    V v_x3_2411 = ({ V a_0 = v_g_249; V a_1 = v_set_240; V r_ = (g_map_2elookup_24s9(a_0, a_1)); heff_drop(v_set_240); r_; });
    switch (heff_tag_of(v_x3_2411)) {
    case TAG_Nothing: {
      return NTAG(TAG_False);
    }
    case TAG_Just: {
      heff_take_n(v_x3_2411, 0ULL, 1);
      return NTAG(TAG_True);
    }
    default: return heff_nomatch(v_x3_2411);
    }
  }
  default: return heff_nomatch(v_t_2410);
  }
}
V g_heff_2eemit_2ebounceGo_lam0(V self, V *args);
V g_heff_2eemit_2ebounceGo_lam1(V self, V *args);
Clo g_heff_2eemit_2ebounceGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemit_2ebounceGo_entry, 2, 0};

V g_heff_2eemit_2ebounceGo(V v_defs_240, V v_set_241) {
top: ;
  V v_t_245 = (g_prelude_2efoldl(heff_clo(g_heff_2eemit_2ebounceGo_lam0, 2, 1, (V[]){heff_dup(v_set_241)}), heff_dup(v_set_241), v_defs_240));
  V v_t_246 = ({ V a_0 = v_t_245; V r_ = (g_map_2esize(a_0)); heff_drop(v_t_245); r_; });
  V v_t_247 = (g_map_2esize(v_set_241));
  V v_t_248 = heff_intEq(v_t_246, v_t_247);
  switch (heff_tag_of(v_t_248)) {
  case TAG_True: {
    return v_set_241;
  }
  case TAG_False: {
    V v_t_2412 = (g_prelude_2efoldl(heff_clo(g_heff_2eemit_2ebounceGo_lam1, 2, 1, (V[]){heff_dup(v_set_241)}), v_set_241, v_defs_240));
    V t_0 = v_defs_240;
    V t_1 = v_t_2412;
    v_defs_240 = t_0;
    v_set_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_t_248);
  }
}
V g_heff_2eemit_2ebounceGo_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eemit_2ebounceGo(a[0], a[1]); heff_drop(a[0]); return r;
}
V g_heff_2eemit_2ebounceGo_lam0(V self, V *args) {
  V v_m_242 = args[0];
  V v_d_243 = args[1];
  V v_set_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_244 = ({ V a_0 = v_set_241; V a_1 = heff_dup(v_d_243); V r_ = (g_heff_2eemit_2ebodyBounces(a_0, a_1)); heff_drop(v_set_241); r_; });
  switch (heff_tag_of(v_t_244)) {
  case TAG_True: {
    return (g_map_2einsert_24s7(heff_get(v_d_243, LBL_key), NTAG(TAG_MkUnit), v_m_242));
  }
  case TAG_False: {
    heff_drop(v_d_243);
    return v_m_242;
  }
  default: return heff_nomatch(v_t_244);
  }
}
V g_heff_2eemit_2ebounceGo_lam1(V self, V *args) {
  V v_m_249 = args[0];
  V v_d_2410 = args[1];
  V v_set_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2411 = ({ V a_0 = v_set_241; V a_1 = heff_dup(v_d_2410); V r_ = (g_heff_2eemit_2ebodyBounces(a_0, a_1)); heff_drop(v_set_241); r_; });
  switch (heff_tag_of(v_t_2411)) {
  case TAG_True: {
    return (g_map_2einsert_24s7(heff_get(v_d_2410, LBL_key), NTAG(TAG_MkUnit), v_m_249));
  }
  case TAG_False: {
    heff_drop(v_d_2410);
    return v_m_249;
  }
  default: return heff_nomatch(v_t_2411);
  }
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2eemit_2eappendEnd_str0 = {{0x80000000u, K_STR, 0}, 9, 9, {115, 116, 114, 65, 112, 112, 101, 110, 100}};
Clo g_heff_2eemit_2eappendEnd_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemit_2eappendEnd_entry, 3, 0};

V g_heff_2eemit_2eappendEnd(V v_key_240, V v_n_241, V v_e_242) {
top: ;
  switch (heff_tag_of(v_e_242)) {
  case TAG_EVar: {
    heff_drop(v_key_240);
    heff_drop(v_n_241);
    return NTAG(TAG_False);
  }
  case TAG_EGlobal: {
    heff_drop(v_key_240);
    heff_drop(v_n_241);
    return NTAG(TAG_False);
  }
  case TAG_ELam: {
    heff_drop(v_key_240);
    heff_drop(v_n_241);
    return NTAG(TAG_False);
  }
  case TAG_EApp: {
    heff_drop(v_key_240);
    heff_drop(v_n_241);
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    heff_drop(v_key_240);
    heff_drop(v_n_241);
    return NTAG(TAG_False);
  }
  case TAG_ERecord: {
    heff_drop(v_key_240);
    heff_drop(v_n_241);
    return NTAG(TAG_False);
  }
  case TAG_EProj: {
    heff_drop(v_key_240);
    heff_drop(v_n_241);
    return NTAG(TAG_False);
  }
  case TAG_ETag: {
    heff_drop(v_key_240);
    heff_drop(v_n_241);
    return NTAG(TAG_False);
  }
  case TAG_EMatch: {
    heff_drop(v_key_240);
    heff_drop(v_n_241);
    return NTAG(TAG_False);
  }
  case TAG_EPrim: {
    heff_drop(v_key_240);
    heff_drop(v_n_241);
    return NTAG(TAG_False);
  }
  case TAG_EPrimCall: {
    V v_p_2420 = heff_field(v_e_242, 0);
    V v_as_2421 = heff_field(v_e_242, 1);
    switch (heff_tag_of(v_as_2421)) {
    case TAG_Nil: {
      heff_drop(v_key_240);
      heff_drop(v_n_241);
      return NTAG(TAG_False);
    }
    case TAG_Cons: {
      V v_it2_2423 = heff_field(v_as_2421, 1);
      switch (heff_tag_of(v_it2_2423)) {
      case TAG_Nil: {
        heff_drop(v_key_240);
        heff_drop(v_n_241);
        return NTAG(TAG_False);
      }
      case TAG_Cons: {
        V v_rr_2424 = heff_field(v_it2_2423, 0);
        V v_it22_2425 = heff_field(v_it2_2423, 1);
        switch (heff_tag_of(v_it22_2425)) {
        case TAG_Nil: {
          V v_t_2426 = heff_strEq(heff_dup(v_p_2420), ((V)&g_heff_2eemit_2eappendEnd_str0));
          switch (heff_tag_of(v_t_2426)) {
          case TAG_True: {
            V t_0 = v_key_240;
            V t_1 = v_n_241;
            V t_2 = v_rr_2424;
            v_key_240 = t_0;
            v_n_241 = t_1;
            v_e_242 = t_2;
            goto top;
          }
          case TAG_False: {
            heff_drop(v_key_240);
            heff_drop(v_n_241);
            return NTAG(TAG_False);
          }
          default: return heff_nomatch(v_t_2426);
          }
        }
        case TAG_Cons: {
          heff_drop(v_key_240);
          heff_drop(v_n_241);
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_it22_2425);
        }
      }
      default: return heff_nomatch(v_it2_2423);
      }
    }
    default: return heff_nomatch(v_as_2421);
    }
  }
  case TAG_ECall: {
    V v_k_2429 = heff_field(v_e_242, 0);
    V v_as_2430 = heff_field(v_e_242, 1);
    V v_t_2431 = heff_strEq(heff_dup(v_k_2429), v_key_240);
    switch (heff_tag_of(v_t_2431)) {
    case TAG_True: {
      V v_t_2432 = (g_prelude_2efoldl_24s1(MK_INT(0LL), v_as_2430));
      return heff_intEq(v_t_2432, v_n_241);
    }
    case TAG_False: {
      heff_drop(v_n_241);
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_t_2431);
    }
  }
  case TAG_EInt: {
    heff_drop(v_key_240);
    heff_drop(v_n_241);
    return NTAG(TAG_False);
  }
  case TAG_EFloat: {
    heff_drop(v_key_240);
    heff_drop(v_n_241);
    return NTAG(TAG_False);
  }
  case TAG_EStr: {
    heff_drop(v_key_240);
    heff_drop(v_n_241);
    return NTAG(TAG_False);
  }
  case TAG_EAbandon: {
    heff_drop(v_key_240);
    heff_drop(v_n_241);
    return NTAG(TAG_False);
  }
  case TAG_EFix: {
    heff_drop(v_key_240);
    heff_drop(v_n_241);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_e_242);
  }
}
V g_heff_2eemit_2eappendEnd_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eemit_2eappendEnd(a[0], a[1], a[2]); heff_drop(a[2]); return r;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2eemit_2eappendSelf_str0 = {{0x80000000u, K_STR, 0}, 9, 9, {115, 116, 114, 65, 112, 112, 101, 110, 100}};
V g_heff_2eemit_2eappendSelf_lam0(V self, V *args);
Clo g_heff_2eemit_2eappendSelf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemit_2eappendSelf_entry, 3, 0};

V g_heff_2eemit_2eappendSelf(V v_key_240, V v_n_241, V v_e_242) {
top: ;
  switch (heff_tag_of(v_e_242)) {
  case TAG_EVar: {
    heff_drop(v_key_240);
    heff_drop(v_n_241);
    return NTAG(TAG_False);
  }
  case TAG_EGlobal: {
    heff_drop(v_key_240);
    heff_drop(v_n_241);
    return NTAG(TAG_False);
  }
  case TAG_ELam: {
    heff_drop(v_key_240);
    heff_drop(v_n_241);
    return NTAG(TAG_False);
  }
  case TAG_EApp: {
    heff_drop(v_key_240);
    heff_drop(v_n_241);
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    V v_b_2411 = heff_field(v_e_242, 2);
    V t_0 = v_key_240;
    V t_1 = v_n_241;
    V t_2 = v_b_2411;
    v_key_240 = t_0;
    v_n_241 = t_1;
    v_e_242 = t_2;
    goto top;
  }
  case TAG_ERecord: {
    heff_drop(v_key_240);
    heff_drop(v_n_241);
    return NTAG(TAG_False);
  }
  case TAG_EProj: {
    heff_drop(v_key_240);
    heff_drop(v_n_241);
    return NTAG(TAG_False);
  }
  case TAG_ETag: {
    heff_drop(v_key_240);
    heff_drop(v_n_241);
    return NTAG(TAG_False);
  }
  case TAG_EMatch: {
    V v_arms_2418 = heff_field(v_e_242, 1);
    return (g_prelude_2eany(heff_clo(g_heff_2eemit_2eappendSelf_lam0, 1, 2, (V[]){v_key_240, v_n_241}), v_arms_2418));
  }
  case TAG_EPrim: {
    heff_drop(v_key_240);
    heff_drop(v_n_241);
    return NTAG(TAG_False);
  }
  case TAG_EPrimCall: {
    V v_p_2425 = heff_field(v_e_242, 0);
    V v_as_2426 = heff_field(v_e_242, 1);
    switch (heff_tag_of(v_as_2426)) {
    case TAG_Nil: {
      heff_drop(v_key_240);
      heff_drop(v_n_241);
      return NTAG(TAG_False);
    }
    case TAG_Cons: {
      V v_it2_2428 = heff_field(v_as_2426, 1);
      switch (heff_tag_of(v_it2_2428)) {
      case TAG_Nil: {
        heff_drop(v_key_240);
        heff_drop(v_n_241);
        return NTAG(TAG_False);
      }
      case TAG_Cons: {
        V v_rr_2429 = heff_field(v_it2_2428, 0);
        V v_it22_2430 = heff_field(v_it2_2428, 1);
        switch (heff_tag_of(v_it22_2430)) {
        case TAG_Nil: {
          V v_t_2431 = heff_strEq(heff_dup(v_p_2425), ((V)&g_heff_2eemit_2eappendSelf_str0));
          switch (heff_tag_of(v_t_2431)) {
          case TAG_True: {
            HEFF_LAST return g_heff_2eemit_2eappendEnd(v_key_240, v_n_241, v_rr_2429);
          }
          case TAG_False: {
            heff_drop(v_key_240);
            heff_drop(v_n_241);
            return NTAG(TAG_False);
          }
          default: return heff_nomatch(v_t_2431);
          }
        }
        case TAG_Cons: {
          heff_drop(v_key_240);
          heff_drop(v_n_241);
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_it22_2430);
        }
      }
      default: return heff_nomatch(v_it2_2428);
      }
    }
    default: return heff_nomatch(v_as_2426);
    }
  }
  case TAG_ECall: {
    heff_drop(v_key_240);
    heff_drop(v_n_241);
    return NTAG(TAG_False);
  }
  case TAG_EInt: {
    heff_drop(v_key_240);
    heff_drop(v_n_241);
    return NTAG(TAG_False);
  }
  case TAG_EFloat: {
    heff_drop(v_key_240);
    heff_drop(v_n_241);
    return NTAG(TAG_False);
  }
  case TAG_EStr: {
    heff_drop(v_key_240);
    heff_drop(v_n_241);
    return NTAG(TAG_False);
  }
  case TAG_EAbandon: {
    heff_drop(v_key_240);
    heff_drop(v_n_241);
    return NTAG(TAG_False);
  }
  case TAG_EFix: {
    heff_drop(v_key_240);
    heff_drop(v_n_241);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_e_242);
  }
}
V g_heff_2eemit_2eappendSelf_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eemit_2eappendSelf(a[0], a[1], a[2]); heff_drop(a[2]); return r;
}
V g_heff_2eemit_2eappendSelf_lam0(V self, V *args) {
  V v_a_2419 = args[0];
  V v_key_240 = heff_env(self)[0];
  V v_n_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2423;
  switch (heff_tag_of(v_a_2419)) {
  case TAG_MkArm: {
    V v_b_2422 = heff_field(v_a_2419, 2);
    heff_take_n(v_a_2419, 4ULL, 3);
    v_t_2423 = v_b_2422;
    break;
  }
  default: heff_nomatch(v_a_2419);
  }
  return ({ V a_0 = v_key_240; V a_1 = v_n_241; V a_2 = v_t_2423; V r_ = (g_heff_2eemit_2eappendSelf(a_0, a_1, a_2)); heff_drop(v_t_2423); r_; });
}
Clo g_heff_2eemit_2econsLast_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemit_2econsLast_entry, 3, 0};

V g_heff_2eemit_2econsLast(V v_key_240, V v_n_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nothing: {
    heff_drop(v_key_240);
    heff_drop(v_n_241);
    return NTAG(TAG_False);
  }
  case TAG_Just: {
    V v_x31_243 = heff_field(v_x3_242, 0);
    switch (heff_tag_of(v_x31_243)) {
    case TAG_EVar: {
      heff_drop(v_key_240);
      heff_drop(v_n_241);
      return NTAG(TAG_False);
    }
    case TAG_EGlobal: {
      heff_drop(v_key_240);
      heff_drop(v_n_241);
      return NTAG(TAG_False);
    }
    case TAG_ELam: {
      heff_drop(v_key_240);
      heff_drop(v_n_241);
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      heff_drop(v_key_240);
      heff_drop(v_n_241);
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      heff_drop(v_key_240);
      heff_drop(v_n_241);
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      heff_drop(v_key_240);
      heff_drop(v_n_241);
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      heff_drop(v_key_240);
      heff_drop(v_n_241);
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      heff_drop(v_key_240);
      heff_drop(v_n_241);
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      heff_drop(v_key_240);
      heff_drop(v_n_241);
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      heff_drop(v_key_240);
      heff_drop(v_n_241);
      return NTAG(TAG_False);
    }
    case TAG_EPrimCall: {
      heff_drop(v_key_240);
      heff_drop(v_n_241);
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      V v_k_2423 = heff_field(v_x31_243, 0);
      V v_bs_2424 = heff_field(v_x31_243, 1);
      V v_t_2425 = heff_strEq(heff_dup(v_k_2423), v_key_240);
      switch (heff_tag_of(v_t_2425)) {
      case TAG_True: {
        V v_t_2426 = (g_prelude_2efoldl_24s1(MK_INT(0LL), v_bs_2424));
        return heff_intEq(v_t_2426, v_n_241);
      }
      case TAG_False: {
        heff_drop(v_n_241);
        return NTAG(TAG_False);
      }
      default: return heff_nomatch(v_t_2425);
      }
    }
    case TAG_EInt: {
      heff_drop(v_key_240);
      heff_drop(v_n_241);
      return NTAG(TAG_False);
    }
    case TAG_EFloat: {
      heff_drop(v_key_240);
      heff_drop(v_n_241);
      return NTAG(TAG_False);
    }
    case TAG_EStr: {
      heff_drop(v_key_240);
      heff_drop(v_n_241);
      return NTAG(TAG_False);
    }
    case TAG_EAbandon: {
      heff_drop(v_key_240);
      heff_drop(v_n_241);
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      heff_drop(v_key_240);
      heff_drop(v_n_241);
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x31_243);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2eemit_2econsLast_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eemit_2econsLast(a[0], a[1], a[2]); heff_drop(a[2]); return r;
}
V g_heff_2eemit_2econsSelf_lam0(V self, V *args);
Clo g_heff_2eemit_2econsSelf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemit_2econsSelf_entry, 3, 0};

V g_heff_2eemit_2econsSelf(V v_key_240, V v_n_241, V v_e_242) {
top: ;
  switch (heff_tag_of(v_e_242)) {
  case TAG_EVar: {
    heff_drop(v_key_240);
    heff_drop(v_n_241);
    return NTAG(TAG_False);
  }
  case TAG_EGlobal: {
    heff_drop(v_key_240);
    heff_drop(v_n_241);
    return NTAG(TAG_False);
  }
  case TAG_ELam: {
    heff_drop(v_key_240);
    heff_drop(v_n_241);
    return NTAG(TAG_False);
  }
  case TAG_EApp: {
    heff_drop(v_key_240);
    heff_drop(v_n_241);
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    V v_b_2411 = heff_field(v_e_242, 2);
    V t_0 = v_key_240;
    V t_1 = v_n_241;
    V t_2 = v_b_2411;
    v_key_240 = t_0;
    v_n_241 = t_1;
    v_e_242 = t_2;
    goto top;
  }
  case TAG_ERecord: {
    heff_drop(v_key_240);
    heff_drop(v_n_241);
    return NTAG(TAG_False);
  }
  case TAG_EProj: {
    heff_drop(v_key_240);
    heff_drop(v_n_241);
    return NTAG(TAG_False);
  }
  case TAG_ETag: {
    V v_as_2416 = heff_field(v_e_242, 1);
    V v_x1_2417 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), heff_dup(v_as_2416)));
    V v_t_2420;
    switch (heff_tag_of(v_x1_2417)) {
    case TAG_Nil: {
      v_t_2420 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Cons: {
      V v_x_2418 = heff_field(v_x1_2417, 0);
      heff_take_n(v_x1_2417, 1ULL, 2);
      v_t_2420 = heff_tag(TAG_Just, 1, (V[]){v_x_2418});
      break;
    }
    default: heff_nomatch(v_x1_2417);
    }
    return ({ V a_0 = v_key_240; V a_1 = v_n_241; V a_2 = v_t_2420; V r_ = (g_heff_2eemit_2econsLast(a_0, a_1, a_2)); heff_drop(v_t_2420); r_; });
  }
  case TAG_EMatch: {
    V v_arms_2422 = heff_field(v_e_242, 1);
    return (g_prelude_2eany(heff_clo(g_heff_2eemit_2econsSelf_lam0, 1, 2, (V[]){v_key_240, v_n_241}), v_arms_2422));
  }
  case TAG_EPrim: {
    heff_drop(v_key_240);
    heff_drop(v_n_241);
    return NTAG(TAG_False);
  }
  case TAG_EPrimCall: {
    heff_drop(v_key_240);
    heff_drop(v_n_241);
    return NTAG(TAG_False);
  }
  case TAG_ECall: {
    heff_drop(v_key_240);
    heff_drop(v_n_241);
    return NTAG(TAG_False);
  }
  case TAG_EInt: {
    heff_drop(v_key_240);
    heff_drop(v_n_241);
    return NTAG(TAG_False);
  }
  case TAG_EFloat: {
    heff_drop(v_key_240);
    heff_drop(v_n_241);
    return NTAG(TAG_False);
  }
  case TAG_EStr: {
    heff_drop(v_key_240);
    heff_drop(v_n_241);
    return NTAG(TAG_False);
  }
  case TAG_EAbandon: {
    heff_drop(v_key_240);
    heff_drop(v_n_241);
    return NTAG(TAG_False);
  }
  case TAG_EFix: {
    heff_drop(v_key_240);
    heff_drop(v_n_241);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_e_242);
  }
}
V g_heff_2eemit_2econsSelf_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eemit_2econsSelf(a[0], a[1], a[2]); heff_drop(a[2]); return r;
}
V g_heff_2eemit_2econsSelf_lam0(V self, V *args) {
  V v_a_2423 = args[0];
  V v_key_240 = heff_env(self)[0];
  V v_n_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2427;
  switch (heff_tag_of(v_a_2423)) {
  case TAG_MkArm: {
    V v_b_2426 = heff_field(v_a_2423, 2);
    heff_take_n(v_a_2423, 4ULL, 3);
    v_t_2427 = v_b_2426;
    break;
  }
  default: heff_nomatch(v_a_2423);
  }
  return ({ V a_0 = v_key_240; V a_1 = v_n_241; V a_2 = v_t_2427; V r_ = (g_heff_2eemit_2econsSelf(a_0, a_1, a_2)); heff_drop(v_t_2427); r_; });
}
V g_heff_2eemit_2etailSelf_lam0(V self, V *args);
Clo g_heff_2eemit_2etailSelf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemit_2etailSelf_entry, 3, 0};

V g_heff_2eemit_2etailSelf(V v_key_240, V v_n_241, V v_e_242) {
top: ;
  switch (heff_tag_of(v_e_242)) {
  case TAG_EVar: {
    V v_t_244 = (g_heff_2eemit_2econsSelf(heff_dup(v_key_240), heff_dup(v_n_241), v_e_242));
    switch (heff_tag_of(v_t_244)) {
    case TAG_True: {
      heff_drop(v_key_240);
      heff_drop(v_n_241);
      return NTAG(TAG_True);
    }
    case TAG_False: {
      HEFF_LAST return g_heff_2eemit_2eappendSelf(v_key_240, v_n_241, v_e_242);
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  case TAG_EGlobal: {
    V v_t_246 = (g_heff_2eemit_2econsSelf(heff_dup(v_key_240), heff_dup(v_n_241), v_e_242));
    switch (heff_tag_of(v_t_246)) {
    case TAG_True: {
      heff_drop(v_key_240);
      heff_drop(v_n_241);
      return NTAG(TAG_True);
    }
    case TAG_False: {
      HEFF_LAST return g_heff_2eemit_2eappendSelf(v_key_240, v_n_241, v_e_242);
    }
    default: return heff_nomatch(v_t_246);
    }
  }
  case TAG_ELam: {
    V v_t_249 = (g_heff_2eemit_2econsSelf(heff_dup(v_key_240), heff_dup(v_n_241), v_e_242));
    switch (heff_tag_of(v_t_249)) {
    case TAG_True: {
      heff_drop(v_key_240);
      heff_drop(v_n_241);
      return NTAG(TAG_True);
    }
    case TAG_False: {
      HEFF_LAST return g_heff_2eemit_2eappendSelf(v_key_240, v_n_241, v_e_242);
    }
    default: return heff_nomatch(v_t_249);
    }
  }
  case TAG_EApp: {
    V v_t_2412 = (g_heff_2eemit_2econsSelf(heff_dup(v_key_240), heff_dup(v_n_241), v_e_242));
    switch (heff_tag_of(v_t_2412)) {
    case TAG_True: {
      heff_drop(v_key_240);
      heff_drop(v_n_241);
      return NTAG(TAG_True);
    }
    case TAG_False: {
      HEFF_LAST return g_heff_2eemit_2eappendSelf(v_key_240, v_n_241, v_e_242);
    }
    default: return heff_nomatch(v_t_2412);
    }
  }
  case TAG_ELet: {
    V v_b_2415 = heff_field(v_e_242, 2);
    V t_0 = v_key_240;
    V t_1 = v_n_241;
    V t_2 = v_b_2415;
    v_key_240 = t_0;
    v_n_241 = t_1;
    v_e_242 = t_2;
    goto top;
  }
  case TAG_ERecord: {
    V v_t_2417 = (g_heff_2eemit_2econsSelf(heff_dup(v_key_240), heff_dup(v_n_241), v_e_242));
    switch (heff_tag_of(v_t_2417)) {
    case TAG_True: {
      heff_drop(v_key_240);
      heff_drop(v_n_241);
      return NTAG(TAG_True);
    }
    case TAG_False: {
      HEFF_LAST return g_heff_2eemit_2eappendSelf(v_key_240, v_n_241, v_e_242);
    }
    default: return heff_nomatch(v_t_2417);
    }
  }
  case TAG_EProj: {
    V v_t_2420 = (g_heff_2eemit_2econsSelf(heff_dup(v_key_240), heff_dup(v_n_241), v_e_242));
    switch (heff_tag_of(v_t_2420)) {
    case TAG_True: {
      heff_drop(v_key_240);
      heff_drop(v_n_241);
      return NTAG(TAG_True);
    }
    case TAG_False: {
      HEFF_LAST return g_heff_2eemit_2eappendSelf(v_key_240, v_n_241, v_e_242);
    }
    default: return heff_nomatch(v_t_2420);
    }
  }
  case TAG_ETag: {
    V v_t_2423 = (g_heff_2eemit_2econsSelf(heff_dup(v_key_240), heff_dup(v_n_241), v_e_242));
    switch (heff_tag_of(v_t_2423)) {
    case TAG_True: {
      heff_drop(v_key_240);
      heff_drop(v_n_241);
      return NTAG(TAG_True);
    }
    case TAG_False: {
      HEFF_LAST return g_heff_2eemit_2eappendSelf(v_key_240, v_n_241, v_e_242);
    }
    default: return heff_nomatch(v_t_2423);
    }
  }
  case TAG_EMatch: {
    V v_arms_2425 = heff_field(v_e_242, 1);
    return (g_prelude_2eany(heff_clo(g_heff_2eemit_2etailSelf_lam0, 1, 2, (V[]){v_key_240, v_n_241}), v_arms_2425));
  }
  case TAG_EPrim: {
    V v_t_2432 = (g_heff_2eemit_2econsSelf(heff_dup(v_key_240), heff_dup(v_n_241), v_e_242));
    switch (heff_tag_of(v_t_2432)) {
    case TAG_True: {
      heff_drop(v_key_240);
      heff_drop(v_n_241);
      return NTAG(TAG_True);
    }
    case TAG_False: {
      HEFF_LAST return g_heff_2eemit_2eappendSelf(v_key_240, v_n_241, v_e_242);
    }
    default: return heff_nomatch(v_t_2432);
    }
  }
  case TAG_EPrimCall: {
    V v_t_2435 = (g_heff_2eemit_2econsSelf(heff_dup(v_key_240), heff_dup(v_n_241), v_e_242));
    switch (heff_tag_of(v_t_2435)) {
    case TAG_True: {
      heff_drop(v_key_240);
      heff_drop(v_n_241);
      return NTAG(TAG_True);
    }
    case TAG_False: {
      HEFF_LAST return g_heff_2eemit_2eappendSelf(v_key_240, v_n_241, v_e_242);
    }
    default: return heff_nomatch(v_t_2435);
    }
  }
  case TAG_ECall: {
    V v_k_2436 = heff_field(v_e_242, 0);
    V v_as_2437 = heff_field(v_e_242, 1);
    V v_t_2438 = heff_strEq(heff_dup(v_k_2436), v_key_240);
    switch (heff_tag_of(v_t_2438)) {
    case TAG_True: {
      V v_t_2439 = (g_prelude_2efoldl_24s1(MK_INT(0LL), v_as_2437));
      return heff_intEq(v_t_2439, v_n_241);
    }
    case TAG_False: {
      heff_drop(v_n_241);
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_t_2438);
    }
  }
  case TAG_EInt: {
    V v_t_2441 = (g_heff_2eemit_2econsSelf(heff_dup(v_key_240), heff_dup(v_n_241), v_e_242));
    switch (heff_tag_of(v_t_2441)) {
    case TAG_True: {
      heff_drop(v_key_240);
      heff_drop(v_n_241);
      return NTAG(TAG_True);
    }
    case TAG_False: {
      HEFF_LAST return g_heff_2eemit_2eappendSelf(v_key_240, v_n_241, v_e_242);
    }
    default: return heff_nomatch(v_t_2441);
    }
  }
  case TAG_EFloat: {
    V v_t_2443 = (g_heff_2eemit_2econsSelf(heff_dup(v_key_240), heff_dup(v_n_241), v_e_242));
    switch (heff_tag_of(v_t_2443)) {
    case TAG_True: {
      heff_drop(v_key_240);
      heff_drop(v_n_241);
      return NTAG(TAG_True);
    }
    case TAG_False: {
      HEFF_LAST return g_heff_2eemit_2eappendSelf(v_key_240, v_n_241, v_e_242);
    }
    default: return heff_nomatch(v_t_2443);
    }
  }
  case TAG_EStr: {
    V v_t_2445 = (g_heff_2eemit_2econsSelf(heff_dup(v_key_240), heff_dup(v_n_241), v_e_242));
    switch (heff_tag_of(v_t_2445)) {
    case TAG_True: {
      heff_drop(v_key_240);
      heff_drop(v_n_241);
      return NTAG(TAG_True);
    }
    case TAG_False: {
      HEFF_LAST return g_heff_2eemit_2eappendSelf(v_key_240, v_n_241, v_e_242);
    }
    default: return heff_nomatch(v_t_2445);
    }
  }
  case TAG_EAbandon: {
    V v_t_2446 = (g_heff_2eemit_2econsSelf(heff_dup(v_key_240), heff_dup(v_n_241), v_e_242));
    switch (heff_tag_of(v_t_2446)) {
    case TAG_True: {
      heff_drop(v_key_240);
      heff_drop(v_n_241);
      return NTAG(TAG_True);
    }
    case TAG_False: {
      HEFF_LAST return g_heff_2eemit_2eappendSelf(v_key_240, v_n_241, v_e_242);
    }
    default: return heff_nomatch(v_t_2446);
    }
  }
  case TAG_EFix: {
    V v_t_2449 = (g_heff_2eemit_2econsSelf(heff_dup(v_key_240), heff_dup(v_n_241), v_e_242));
    switch (heff_tag_of(v_t_2449)) {
    case TAG_True: {
      heff_drop(v_key_240);
      heff_drop(v_n_241);
      return NTAG(TAG_True);
    }
    case TAG_False: {
      HEFF_LAST return g_heff_2eemit_2eappendSelf(v_key_240, v_n_241, v_e_242);
    }
    default: return heff_nomatch(v_t_2449);
    }
  }
  default: return heff_nomatch(v_e_242);
  }
}
V g_heff_2eemit_2etailSelf_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eemit_2etailSelf(a[0], a[1], a[2]); heff_drop(a[2]); return r;
}
V g_heff_2eemit_2etailSelf_lam0(V self, V *args) {
  V v_a_2426 = args[0];
  V v_key_240 = heff_env(self)[0];
  V v_n_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2430;
  switch (heff_tag_of(v_a_2426)) {
  case TAG_MkArm: {
    V v_b_2429 = heff_field(v_a_2426, 2);
    heff_take_n(v_a_2426, 4ULL, 3);
    v_t_2430 = v_b_2429;
    break;
  }
  default: heff_nomatch(v_a_2426);
  }
  return ({ V a_0 = v_key_240; V a_1 = v_n_241; V a_2 = v_t_2430; V r_ = (g_heff_2eemit_2etailSelf(a_0, a_1, a_2)); heff_drop(v_t_2430); r_; });
}
Clo g_heff_2eemit_2ebindFrom_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemit_2ebindFrom_entry, 4, 0};

V g_heff_2eemit_2ebindFrom(V v_env_240, V v_x_241, V v_base_242, V v_i_243) {
top: ;
  V v_t_244 = heff_intEq(heff_dup(v_i_243), MK_INT(0LL));
  V v_k_245;
  switch (heff_tag_of(v_t_244)) {
  case TAG_True: {
    v_k_245 = heff_dup(v_base_242);
    break;
  }
  case TAG_False: {
    v_k_245 = heff_strAppend(heff_dup(v_base_242), heff_intShow(heff_dup(v_i_243)));
    break;
  }
  default: heff_nomatch(v_t_244);
  }
  V v_x3_246 = ({ V a_0 = v_k_245; V b_1 = heff_get(heff_dup(v_env_240), LBL_used); V r_ = (g_map_2elookup_24s9(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_248;
  switch (heff_tag_of(v_x3_246)) {
  case TAG_Nothing: {
    v_t_248 = NTAG(TAG_False);
    break;
  }
  case TAG_Just: {
    heff_take_n(v_x3_246, 0ULL, 1);
    v_t_248 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_x3_246);
  }
  switch (heff_tag_of(v_t_248)) {
  case TAG_True: {
    V t_0 = v_env_240;
    V t_1 = v_x_241;
    V t_2 = v_base_242;
    V t_3 = heff_intAdd(v_i_243, MK_INT(1LL));
    v_env_240 = t_0;
    v_x_241 = t_1;
    v_base_242 = t_2;
    v_i_243 = t_3;
    goto top;
  }
  case TAG_False: {
    V v_t_249 = heff_intEq(heff_dup(v_i_243), MK_INT(0LL));
    V v_t_2410;
    switch (heff_tag_of(v_t_249)) {
    case TAG_True: {
      v_t_2410 = heff_dup(v_base_242);
      break;
    }
    case TAG_False: {
      v_t_2410 = heff_strAppend(heff_dup(v_base_242), heff_intShow(heff_dup(v_i_243)));
      break;
    }
    default: heff_nomatch(v_t_249);
    }
    V v_t_2411 = heff_intEq(heff_dup(v_i_243), MK_INT(0LL));
    V v_v_2412;
    switch (heff_tag_of(v_t_2411)) {
    case TAG_True: {
      heff_drop(v_i_243);
      v_v_2412 = v_base_242;
      break;
    }
    case TAG_False: {
      v_v_2412 = heff_strAppend(v_base_242, heff_intShow(v_i_243));
      break;
    }
    default: heff_nomatch(v_t_2411);
    }
    V v_t_2413 = (g_map_2einsert_24s7(v_x_241, heff_dup(v_v_2412), heff_get(heff_dup(v_env_240), LBL_names)));
    V v_t_2414 = (g_map_2einsert_24s7(v_v_2412, NTAG(TAG_MkUnit), heff_get(heff_dup(v_env_240), LBL_used)));
    V v_t_2415 = heff_rec(4, shape_120_200_361_295, (V[]){heff_get(heff_dup(v_env_240), LBL_gs), v_t_2413, v_t_2414, heff_get(v_env_240, LBL_self)});
    return heff_rec(2, shape_150_87, (V[]){v_t_2410, v_t_2415});
  }
  default: return heff_nomatch(v_t_248);
  }
}
V g_heff_2eemit_2ebindFrom_entry(V self, V *a) {
  (void)self;
  return g_heff_2eemit_2ebindFrom(a[0], a[1], a[2], a[3]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2ebindName_str0 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2ebindName_str1 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2ebindName_str2 = {{0x80000000u, K_STR, 0}, 1, 1, {120}};
Clo g_heff_2eemit_2ebindName_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemit_2ebindName_entry, 2, 0};

V g_heff_2eemit_2ebindName(V v_env_240, V v_x_241) {
top: ;
  V v_x0_242 = (g_heff_2eir_2ebaseGo(heff_dup(v_x_241), MK_INT(0LL)));
  V v_t_243 = heff_intSub(heff_strLength(heff_dup(v_x0_242)), MK_INT(1LL));
  V v_t_244 = (g_heff_2eemit_2elastDotFrom(heff_dup(v_x0_242), v_t_243));
  V v_t_245 = (g_heff_2eemit_2espellAt(v_x0_242, v_t_244));
  V v_s_246 = (g_heff_2eemit_2esafeChars(v_t_245, MK_INT(0LL), ((V)&g_heff_2eemit_2ebindName_str0)));
  V v_t_247 = heff_strEq(heff_dup(v_s_246), ((V)&g_heff_2eemit_2ebindName_str1));
  V v_t_248;
  switch (heff_tag_of(v_t_247)) {
  case TAG_True: {
    heff_drop(v_s_246);
    v_t_248 = ((V)&g_heff_2eemit_2ebindName_str2);
    break;
  }
  case TAG_False: {
    v_t_248 = v_s_246;
    break;
  }
  default: heff_nomatch(v_t_247);
  }
  V v_t_249 = (g_heff_2eemit_2esafeRes(v_t_248));
  return (g_heff_2eemit_2ebindFrom(v_env_240, v_x_241, v_t_249, MK_INT(0LL)));
}
V g_heff_2eemit_2ebindName_entry(V self, V *a) {
  (void)self;
  return g_heff_2eemit_2ebindName(a[0], a[1]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2eprimBin_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {42}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2eprimBin_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {47}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2eprimBin_str2 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2eprimBin_str3 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2eprimBin_str4 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2eprimBin_str5 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2eprimBin_str6 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2eprimBin_str7 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2eprimBin_str8 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2eprimBin_str9 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2eprimBin_str10 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2eprimBin_str11 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2eprimBin_str12 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2eprimBin_str13 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
Clo g_heff_2eemit_2eprimBin_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemit_2eprimBin_entry, 3, 0};

V g_heff_2eemit_2eprimBin(V v_op_240, V v_a_241, V v_b_242) {
top: ;
  V v_t_243 = heff_strEq(heff_dup(v_op_240), ((V)&g_heff_2eemit_2eprimBin_str0));
  V v_t_244;
  switch (heff_tag_of(v_t_243)) {
  case TAG_True: {
    v_t_244 = NTAG(TAG_True);
    break;
  }
  case TAG_False: {
    v_t_244 = heff_strEq(heff_dup(v_op_240), ((V)&g_heff_2eemit_2eprimBin_str1));
    break;
  }
  default: heff_nomatch(v_t_243);
  }
  switch (heff_tag_of(v_t_244)) {
  case TAG_True: {
    V v_t_245 = heff_intLt(heff_get(heff_dup(v_a_241), LBL_prec), MK_INT(2LL));
    V v_t_246;
    switch (heff_tag_of(v_t_245)) {
    case TAG_True: {
      v_t_246 = heff_strAppend(((V)&g_heff_2eemit_2eprimBin_str2), heff_strAppend(heff_get(v_a_241, LBL_code), ((V)&g_heff_2eemit_2eprimBin_str3)));
      break;
    }
    case TAG_False: {
      v_t_246 = heff_get(v_a_241, LBL_code);
      break;
    }
    default: heff_nomatch(v_t_245);
    }
    V v_t_247 = heff_intLt(heff_get(heff_dup(v_b_242), LBL_prec), MK_INT(3LL));
    V v_t_248;
    switch (heff_tag_of(v_t_247)) {
    case TAG_True: {
      v_t_248 = heff_strAppend(((V)&g_heff_2eemit_2eprimBin_str4), heff_strAppend(heff_get(v_b_242, LBL_code), ((V)&g_heff_2eemit_2eprimBin_str5)));
      break;
    }
    case TAG_False: {
      v_t_248 = heff_get(v_b_242, LBL_code);
      break;
    }
    default: heff_nomatch(v_t_247);
    }
    V v_t_249 = heff_strAppend(v_t_246, heff_strAppend(((V)&g_heff_2eemit_2eprimBin_str6), heff_strAppend(v_op_240, heff_strAppend(((V)&g_heff_2eemit_2eprimBin_str7), v_t_248))));
    return heff_rec(2, shape_47_252, (V[]){v_t_249, MK_INT(2LL)});
  }
  case TAG_False: {
    V v_t_2410 = heff_intLt(heff_get(heff_dup(v_a_241), LBL_prec), MK_INT(1LL));
    V v_t_2411;
    switch (heff_tag_of(v_t_2410)) {
    case TAG_True: {
      v_t_2411 = heff_strAppend(((V)&g_heff_2eemit_2eprimBin_str8), heff_strAppend(heff_get(v_a_241, LBL_code), ((V)&g_heff_2eemit_2eprimBin_str9)));
      break;
    }
    case TAG_False: {
      v_t_2411 = heff_get(v_a_241, LBL_code);
      break;
    }
    default: heff_nomatch(v_t_2410);
    }
    V v_t_2412 = heff_intLt(heff_get(heff_dup(v_b_242), LBL_prec), MK_INT(2LL));
    V v_t_2413;
    switch (heff_tag_of(v_t_2412)) {
    case TAG_True: {
      v_t_2413 = heff_strAppend(((V)&g_heff_2eemit_2eprimBin_str10), heff_strAppend(heff_get(v_b_242, LBL_code), ((V)&g_heff_2eemit_2eprimBin_str11)));
      break;
    }
    case TAG_False: {
      v_t_2413 = heff_get(v_b_242, LBL_code);
      break;
    }
    default: heff_nomatch(v_t_2412);
    }
    V v_t_2414 = heff_strAppend(v_t_2411, heff_strAppend(((V)&g_heff_2eemit_2eprimBin_str12), heff_strAppend(v_op_240, heff_strAppend(((V)&g_heff_2eemit_2eprimBin_str13), v_t_2413))));
    return heff_rec(2, shape_47_252, (V[]){v_t_2414, MK_INT(1LL)});
  }
  default: return heff_nomatch(v_t_244);
  }
}
V g_heff_2eemit_2eprimBin_entry(V self, V *a) {
  (void)self;
  return g_heff_2eemit_2eprimBin(a[0], a[1], a[2]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2eprimTest_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2eprimTest_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2eprimTest_str2 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2eprimTest_str3 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2eprimTest_str4 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2eprimTest_str5 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[10]; } g_heff_2eemit_2eprimTest_str6 = {{0x80000000u, K_STR, 0}, 10, 10, {32, 63, 32, 36, 84, 32, 58, 32, 36, 70}};
Clo g_heff_2eemit_2eprimTest_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemit_2eprimTest_entry, 3, 0};

V g_heff_2eemit_2eprimTest(V v_op_240, V v_a_241, V v_b_242) {
top: ;
  V v_t_243 = heff_intLt(heff_get(heff_dup(v_a_241), LBL_prec), MK_INT(2LL));
  V v_t_244;
  switch (heff_tag_of(v_t_243)) {
  case TAG_True: {
    v_t_244 = heff_strAppend(((V)&g_heff_2eemit_2eprimTest_str0), heff_strAppend(heff_get(v_a_241, LBL_code), ((V)&g_heff_2eemit_2eprimTest_str1)));
    break;
  }
  case TAG_False: {
    v_t_244 = heff_get(v_a_241, LBL_code);
    break;
  }
  default: heff_nomatch(v_t_243);
  }
  V v_t_245 = heff_intLt(heff_get(heff_dup(v_b_242), LBL_prec), MK_INT(2LL));
  V v_t_246;
  switch (heff_tag_of(v_t_245)) {
  case TAG_True: {
    v_t_246 = heff_strAppend(((V)&g_heff_2eemit_2eprimTest_str2), heff_strAppend(heff_get(v_b_242, LBL_code), ((V)&g_heff_2eemit_2eprimTest_str3)));
    break;
  }
  case TAG_False: {
    v_t_246 = heff_get(v_b_242, LBL_code);
    break;
  }
  default: heff_nomatch(v_t_245);
  }
  V v_t_247 = heff_strAppend(v_t_244, heff_strAppend(((V)&g_heff_2eemit_2eprimTest_str4), heff_strAppend(v_op_240, heff_strAppend(((V)&g_heff_2eemit_2eprimTest_str5), heff_strAppend(v_t_246, ((V)&g_heff_2eemit_2eprimTest_str6))))));
  return heff_rec(2, shape_47_252, (V[]){v_t_247, MK_INT(0LL)});
}
V g_heff_2eemit_2eprimTest_entry(V self, V *a) {
  (void)self;
  return g_heff_2eemit_2eprimTest(a[0], a[1], a[2]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2eemit_2eprimOp_str0 = {{0x80000000u, K_STR, 0}, 6, 6, {105, 110, 116, 65, 100, 100}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2eprimOp_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {43}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2eemit_2eprimOp_str2 = {{0x80000000u, K_STR, 0}, 6, 6, {105, 110, 116, 83, 117, 98}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2eprimOp_str3 = {{0x80000000u, K_STR, 0}, 1, 1, {45}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2eemit_2eprimOp_str4 = {{0x80000000u, K_STR, 0}, 6, 6, {105, 110, 116, 77, 117, 108}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2eprimOp_str5 = {{0x80000000u, K_STR, 0}, 1, 1, {42}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2eemit_2eprimOp_str6 = {{0x80000000u, K_STR, 0}, 9, 9, {115, 116, 114, 65, 112, 112, 101, 110, 100}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2eprimOp_str7 = {{0x80000000u, K_STR, 0}, 1, 1, {43}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eemit_2eprimOp_str8 = {{0x80000000u, K_STR, 0}, 5, 5, {105, 110, 116, 69, 113}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemit_2eprimOp_str9 = {{0x80000000u, K_STR, 0}, 3, 3, {61, 61, 61}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eemit_2eprimOp_str10 = {{0x80000000u, K_STR, 0}, 5, 5, {115, 116, 114, 69, 113}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemit_2eprimOp_str11 = {{0x80000000u, K_STR, 0}, 3, 3, {61, 61, 61}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eemit_2eprimOp_str12 = {{0x80000000u, K_STR, 0}, 5, 5, {105, 110, 116, 76, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2eprimOp_str13 = {{0x80000000u, K_STR, 0}, 1, 1, {60}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eemit_2eprimOp_str14 = {{0x80000000u, K_STR, 0}, 5, 5, {115, 116, 114, 76, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2eprimOp_str15 = {{0x80000000u, K_STR, 0}, 1, 1, {60}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eemit_2eprimOp_str16 = {{0x80000000u, K_STR, 0}, 5, 5, {105, 110, 116, 76, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemit_2eprimOp_str17 = {{0x80000000u, K_STR, 0}, 2, 2, {60, 61}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2eemit_2eprimOp_str18 = {{0x80000000u, K_STR, 0}, 8, 8, {102, 108, 111, 97, 116, 65, 100, 100}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2eprimOp_str19 = {{0x80000000u, K_STR, 0}, 1, 1, {43}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2eemit_2eprimOp_str20 = {{0x80000000u, K_STR, 0}, 8, 8, {102, 108, 111, 97, 116, 83, 117, 98}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2eprimOp_str21 = {{0x80000000u, K_STR, 0}, 1, 1, {45}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2eemit_2eprimOp_str22 = {{0x80000000u, K_STR, 0}, 8, 8, {102, 108, 111, 97, 116, 77, 117, 108}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2eprimOp_str23 = {{0x80000000u, K_STR, 0}, 1, 1, {42}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2eemit_2eprimOp_str24 = {{0x80000000u, K_STR, 0}, 8, 8, {102, 108, 111, 97, 116, 68, 105, 118}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2eprimOp_str25 = {{0x80000000u, K_STR, 0}, 1, 1, {47}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2eemit_2eprimOp_str26 = {{0x80000000u, K_STR, 0}, 7, 7, {102, 108, 111, 97, 116, 69, 113}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemit_2eprimOp_str27 = {{0x80000000u, K_STR, 0}, 3, 3, {61, 61, 61}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2eemit_2eprimOp_str28 = {{0x80000000u, K_STR, 0}, 7, 7, {102, 108, 111, 97, 116, 76, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2eprimOp_str29 = {{0x80000000u, K_STR, 0}, 1, 1, {60}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2eemit_2eprimOp_str30 = {{0x80000000u, K_STR, 0}, 7, 7, {102, 108, 111, 97, 116, 76, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemit_2eprimOp_str31 = {{0x80000000u, K_STR, 0}, 2, 2, {60, 61}};
Clo g_heff_2eemit_2eprimOp_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemit_2eprimOp_entry, 1, 0};

V g_heff_2eemit_2eprimOp(V v_x1_240) {
top: ;
  V v_t_241 = heff_strEq(heff_dup(v_x1_240), ((V)&g_heff_2eemit_2eprimOp_str0));
  switch (heff_tag_of(v_t_241)) {
  case TAG_True: {
    heff_drop(v_x1_240);
    V v_t_242 = heff_tr(heff_apply(((V)&g_heff_2eemit_2eprimBin_clo), 1, (V[]){((V)&g_heff_2eemit_2eprimOp_str1)}));
    return heff_tag(TAG_Just, 1, (V[]){v_t_242});
  }
  case TAG_False: {
    V v_t_243 = heff_strEq(heff_dup(v_x1_240), ((V)&g_heff_2eemit_2eprimOp_str2));
    switch (heff_tag_of(v_t_243)) {
    case TAG_True: {
      heff_drop(v_x1_240);
      V v_t_244 = heff_tr(heff_apply(((V)&g_heff_2eemit_2eprimBin_clo), 1, (V[]){((V)&g_heff_2eemit_2eprimOp_str3)}));
      return heff_tag(TAG_Just, 1, (V[]){v_t_244});
    }
    case TAG_False: {
      V v_t_245 = heff_strEq(heff_dup(v_x1_240), ((V)&g_heff_2eemit_2eprimOp_str4));
      switch (heff_tag_of(v_t_245)) {
      case TAG_True: {
        heff_drop(v_x1_240);
        V v_t_246 = heff_tr(heff_apply(((V)&g_heff_2eemit_2eprimBin_clo), 1, (V[]){((V)&g_heff_2eemit_2eprimOp_str5)}));
        return heff_tag(TAG_Just, 1, (V[]){v_t_246});
      }
      case TAG_False: {
        V v_t_247 = heff_strEq(heff_dup(v_x1_240), ((V)&g_heff_2eemit_2eprimOp_str6));
        switch (heff_tag_of(v_t_247)) {
        case TAG_True: {
          heff_drop(v_x1_240);
          V v_t_248 = heff_tr(heff_apply(((V)&g_heff_2eemit_2eprimBin_clo), 1, (V[]){((V)&g_heff_2eemit_2eprimOp_str7)}));
          return heff_tag(TAG_Just, 1, (V[]){v_t_248});
        }
        case TAG_False: {
          V v_t_249 = heff_strEq(heff_dup(v_x1_240), ((V)&g_heff_2eemit_2eprimOp_str8));
          switch (heff_tag_of(v_t_249)) {
          case TAG_True: {
            heff_drop(v_x1_240);
            V v_t_2410 = heff_tr(heff_apply(((V)&g_heff_2eemit_2eprimTest_clo), 1, (V[]){((V)&g_heff_2eemit_2eprimOp_str9)}));
            return heff_tag(TAG_Just, 1, (V[]){v_t_2410});
          }
          case TAG_False: {
            V v_t_2411 = heff_strEq(heff_dup(v_x1_240), ((V)&g_heff_2eemit_2eprimOp_str10));
            switch (heff_tag_of(v_t_2411)) {
            case TAG_True: {
              heff_drop(v_x1_240);
              V v_t_2412 = heff_tr(heff_apply(((V)&g_heff_2eemit_2eprimTest_clo), 1, (V[]){((V)&g_heff_2eemit_2eprimOp_str11)}));
              return heff_tag(TAG_Just, 1, (V[]){v_t_2412});
            }
            case TAG_False: {
              V v_t_2413 = heff_strEq(heff_dup(v_x1_240), ((V)&g_heff_2eemit_2eprimOp_str12));
              switch (heff_tag_of(v_t_2413)) {
              case TAG_True: {
                heff_drop(v_x1_240);
                V v_t_2414 = heff_tr(heff_apply(((V)&g_heff_2eemit_2eprimTest_clo), 1, (V[]){((V)&g_heff_2eemit_2eprimOp_str13)}));
                return heff_tag(TAG_Just, 1, (V[]){v_t_2414});
              }
              case TAG_False: {
                V v_t_2415 = heff_strEq(heff_dup(v_x1_240), ((V)&g_heff_2eemit_2eprimOp_str14));
                switch (heff_tag_of(v_t_2415)) {
                case TAG_True: {
                  heff_drop(v_x1_240);
                  V v_t_2416 = heff_tr(heff_apply(((V)&g_heff_2eemit_2eprimTest_clo), 1, (V[]){((V)&g_heff_2eemit_2eprimOp_str15)}));
                  return heff_tag(TAG_Just, 1, (V[]){v_t_2416});
                }
                case TAG_False: {
                  V v_t_2417 = heff_strEq(heff_dup(v_x1_240), ((V)&g_heff_2eemit_2eprimOp_str16));
                  switch (heff_tag_of(v_t_2417)) {
                  case TAG_True: {
                    heff_drop(v_x1_240);
                    V v_t_2418 = heff_tr(heff_apply(((V)&g_heff_2eemit_2eprimTest_clo), 1, (V[]){((V)&g_heff_2eemit_2eprimOp_str17)}));
                    return heff_tag(TAG_Just, 1, (V[]){v_t_2418});
                  }
                  case TAG_False: {
                    V v_t_2419 = heff_strEq(heff_dup(v_x1_240), ((V)&g_heff_2eemit_2eprimOp_str18));
                    switch (heff_tag_of(v_t_2419)) {
                    case TAG_True: {
                      heff_drop(v_x1_240);
                      V v_t_2420 = heff_tr(heff_apply(((V)&g_heff_2eemit_2eprimBin_clo), 1, (V[]){((V)&g_heff_2eemit_2eprimOp_str19)}));
                      return heff_tag(TAG_Just, 1, (V[]){v_t_2420});
                    }
                    case TAG_False: {
                      V v_t_2421 = heff_strEq(heff_dup(v_x1_240), ((V)&g_heff_2eemit_2eprimOp_str20));
                      switch (heff_tag_of(v_t_2421)) {
                      case TAG_True: {
                        heff_drop(v_x1_240);
                        V v_t_2422 = heff_tr(heff_apply(((V)&g_heff_2eemit_2eprimBin_clo), 1, (V[]){((V)&g_heff_2eemit_2eprimOp_str21)}));
                        return heff_tag(TAG_Just, 1, (V[]){v_t_2422});
                      }
                      case TAG_False: {
                        V v_t_2423 = heff_strEq(heff_dup(v_x1_240), ((V)&g_heff_2eemit_2eprimOp_str22));
                        switch (heff_tag_of(v_t_2423)) {
                        case TAG_True: {
                          heff_drop(v_x1_240);
                          V v_t_2424 = heff_tr(heff_apply(((V)&g_heff_2eemit_2eprimBin_clo), 1, (V[]){((V)&g_heff_2eemit_2eprimOp_str23)}));
                          return heff_tag(TAG_Just, 1, (V[]){v_t_2424});
                        }
                        case TAG_False: {
                          V v_t_2425 = heff_strEq(heff_dup(v_x1_240), ((V)&g_heff_2eemit_2eprimOp_str24));
                          switch (heff_tag_of(v_t_2425)) {
                          case TAG_True: {
                            heff_drop(v_x1_240);
                            V v_t_2426 = heff_tr(heff_apply(((V)&g_heff_2eemit_2eprimBin_clo), 1, (V[]){((V)&g_heff_2eemit_2eprimOp_str25)}));
                            return heff_tag(TAG_Just, 1, (V[]){v_t_2426});
                          }
                          case TAG_False: {
                            V v_t_2427 = heff_strEq(heff_dup(v_x1_240), ((V)&g_heff_2eemit_2eprimOp_str26));
                            switch (heff_tag_of(v_t_2427)) {
                            case TAG_True: {
                              heff_drop(v_x1_240);
                              V v_t_2428 = heff_tr(heff_apply(((V)&g_heff_2eemit_2eprimTest_clo), 1, (V[]){((V)&g_heff_2eemit_2eprimOp_str27)}));
                              return heff_tag(TAG_Just, 1, (V[]){v_t_2428});
                            }
                            case TAG_False: {
                              V v_t_2429 = heff_strEq(heff_dup(v_x1_240), ((V)&g_heff_2eemit_2eprimOp_str28));
                              switch (heff_tag_of(v_t_2429)) {
                              case TAG_True: {
                                heff_drop(v_x1_240);
                                V v_t_2430 = heff_tr(heff_apply(((V)&g_heff_2eemit_2eprimTest_clo), 1, (V[]){((V)&g_heff_2eemit_2eprimOp_str29)}));
                                return heff_tag(TAG_Just, 1, (V[]){v_t_2430});
                              }
                              case TAG_False: {
                                V v_t_2431 = heff_strEq(v_x1_240, ((V)&g_heff_2eemit_2eprimOp_str30));
                                switch (heff_tag_of(v_t_2431)) {
                                case TAG_True: {
                                  V v_t_2432 = heff_tr(heff_apply(((V)&g_heff_2eemit_2eprimTest_clo), 1, (V[]){((V)&g_heff_2eemit_2eprimOp_str31)}));
                                  return heff_tag(TAG_Just, 1, (V[]){v_t_2432});
                                }
                                case TAG_False: {
                                  return NTAG(TAG_Nothing);
                                }
                                default: return heff_nomatch(v_t_2431);
                                }
                              }
                              default: return heff_nomatch(v_t_2429);
                              }
                            }
                            default: return heff_nomatch(v_t_2427);
                            }
                          }
                          default: return heff_nomatch(v_t_2425);
                          }
                        }
                        default: return heff_nomatch(v_t_2423);
                        }
                      }
                      default: return heff_nomatch(v_t_2421);
                      }
                    }
                    default: return heff_nomatch(v_t_2419);
                    }
                  }
                  default: return heff_nomatch(v_t_2417);
                  }
                }
                default: return heff_nomatch(v_t_2415);
                }
              }
              default: return heff_nomatch(v_t_2413);
              }
            }
            default: return heff_nomatch(v_t_2411);
            }
          }
          default: return heff_nomatch(v_t_249);
          }
        }
        default: return heff_nomatch(v_t_247);
        }
      }
      default: return heff_nomatch(v_t_245);
      }
    }
    default: return heff_nomatch(v_t_243);
    }
  }
  default: return heff_nomatch(v_t_241);
  }
}
V g_heff_2eemit_2eprimOp_entry(V self, V *a) {
  (void)self;
  return g_heff_2eemit_2eprimOp(a[0]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2eemit_2eprimUnary_str0 = {{0x80000000u, K_STR, 0}, 7, 7, {105, 110, 116, 83, 104, 111, 119}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2eprimUnary_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2eprimUnary_str2 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[11]; } g_heff_2eemit_2eprimUnary_str3 = {{0x80000000u, K_STR, 0}, 11, 11, {46, 116, 111, 83, 116, 114, 105, 110, 103, 40, 41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2eemit_2eprimUnary_str4 = {{0x80000000u, K_STR, 0}, 9, 9, {115, 116, 114, 76, 101, 110, 103, 116, 104}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2eprimUnary_str5 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2eprimUnary_str6 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2eemit_2eprimUnary_str7 = {{0x80000000u, K_STR, 0}, 7, 7, {66, 105, 103, 73, 110, 116, 40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2eemit_2eprimUnary_str8 = {{0x80000000u, K_STR, 0}, 8, 8, {46, 108, 101, 110, 103, 116, 104, 41}};
V g_heff_2eemit_2eprimUnary_lam0(V self, V *args); static Clo g_heff_2eemit_2eprimUnary_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemit_2eprimUnary_lam0, 1, 0};
V g_heff_2eemit_2eprimUnary_lam1(V self, V *args); static Clo g_heff_2eemit_2eprimUnary_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemit_2eprimUnary_lam1, 1, 0};
Clo g_heff_2eemit_2eprimUnary_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemit_2eprimUnary_entry, 1, 0};

V g_heff_2eemit_2eprimUnary(V v_x1_240) {
top: ;
  V v_t_241 = heff_strEq(heff_dup(v_x1_240), ((V)&g_heff_2eemit_2eprimUnary_str0));
  switch (heff_tag_of(v_t_241)) {
  case TAG_True: {
    heff_drop(v_x1_240);
    return heff_tag(TAG_Just, 1, (V[]){((V)&g_heff_2eemit_2eprimUnary_lam0_clo)});
  }
  case TAG_False: {
    V v_t_246 = heff_strEq(v_x1_240, ((V)&g_heff_2eemit_2eprimUnary_str4));
    switch (heff_tag_of(v_t_246)) {
    case TAG_True: {
      return heff_tag(TAG_Just, 1, (V[]){((V)&g_heff_2eemit_2eprimUnary_lam1_clo)});
    }
    case TAG_False: {
      return NTAG(TAG_Nothing);
    }
    default: return heff_nomatch(v_t_246);
    }
  }
  default: return heff_nomatch(v_t_241);
  }
}
V g_heff_2eemit_2eprimUnary_entry(V self, V *a) {
  (void)self;
  return g_heff_2eemit_2eprimUnary(a[0]);
}
V g_heff_2eemit_2eprimUnary_lam0(V self, V *args) {
  V v_a_242 = args[0];
  V v_t_243 = heff_intLt(heff_get(heff_dup(v_a_242), LBL_prec), MK_INT(3LL));
  V v_t_244;
  switch (heff_tag_of(v_t_243)) {
  case TAG_True: {
    v_t_244 = heff_strAppend(((V)&g_heff_2eemit_2eprimUnary_str1), heff_strAppend(heff_get(v_a_242, LBL_code), ((V)&g_heff_2eemit_2eprimUnary_str2)));
    break;
  }
  case TAG_False: {
    v_t_244 = heff_get(v_a_242, LBL_code);
    break;
  }
  default: heff_nomatch(v_t_243);
  }
  V v_code_245 = heff_strAppend(v_t_244, ((V)&g_heff_2eemit_2eprimUnary_str3));
  return heff_rec(2, shape_47_252, (V[]){v_code_245, MK_INT(3LL)});
}
V g_heff_2eemit_2eprimUnary_lam1(V self, V *args) {
  V v_a_247 = args[0];
  V v_t_248 = heff_intLt(heff_get(heff_dup(v_a_247), LBL_prec), MK_INT(3LL));
  V v_t_249;
  switch (heff_tag_of(v_t_248)) {
  case TAG_True: {
    v_t_249 = heff_strAppend(((V)&g_heff_2eemit_2eprimUnary_str5), heff_strAppend(heff_get(v_a_247, LBL_code), ((V)&g_heff_2eemit_2eprimUnary_str6)));
    break;
  }
  case TAG_False: {
    v_t_249 = heff_get(v_a_247, LBL_code);
    break;
  }
  default: heff_nomatch(v_t_248);
  }
  V v_code_2410 = heff_strAppend(((V)&g_heff_2eemit_2eprimUnary_str7), heff_strAppend(v_t_249, ((V)&g_heff_2eemit_2eprimUnary_str8)));
  return heff_rec(2, shape_47_252, (V[]){v_code_2410, MK_INT(3LL)});
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2eprimCall_str0 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2eprimCall_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {36}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2eprimCall_str2 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2eprimCall_str3 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2eprimCall_str4 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2eprimCall_str5 = {{0x80000000u, K_STR, 0}, 1, 1, {36}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2eprimCall_str6 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2eprimCall_str7 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2eprimCall_str8 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2eprimCall_str9 = {{0x80000000u, K_STR, 0}, 1, 1, {36}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2eprimCall_str10 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2eprimCall_str11 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2eprimCall_str12 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2eprimCall_str13 = {{0x80000000u, K_STR, 0}, 1, 1, {36}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2eprimCall_str14 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2eprimCall_str15 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
Clo g_heff_2eemit_2eprimCall_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemit_2eprimCall_entry, 2, 0};

V g_heff_2eemit_2eprimCall(V v_p_240, V v_as_241) {
top: ;
  switch (heff_tag_of(v_as_241)) {
  case TAG_Nil: {
    V v_x2_242 = (g_prelude_2emap_24s576(v_as_241));
    V v_t_245;
    switch (heff_tag_of(v_x2_242)) {
    case TAG_Nil: {
      v_t_245 = ((V)&g_heff_2eemit_2eprimCall_str0);
      break;
    }
    case TAG_Cons: {
      V v_x_243 = heff_field(v_x2_242, 0);
      V v_xs_244 = heff_field(v_x2_242, 1);
      heff_take_n(v_x2_242, 3ULL, 2);
      v_t_245 = ({ V a_0 = v_x_243; V a_1 = v_xs_244; V r_ = (g_prelude_2efoldl_24s45(a_0, a_1)); heff_drop(v_xs_244); r_; });
      break;
    }
    default: heff_nomatch(v_x2_242);
    }
    V v_code_246 = heff_strAppend(((V)&g_heff_2eemit_2eprimCall_str1), heff_strAppend(v_p_240, heff_strAppend(((V)&g_heff_2eemit_2eprimCall_str2), heff_strAppend(v_t_245, ((V)&g_heff_2eemit_2eprimCall_str3)))));
    return heff_rec(2, shape_47_252, (V[]){v_code_246, MK_INT(3LL)});
  }
  case TAG_Cons: {
    V v_a_247 = heff_dup(heff_field(v_as_241, 0));
    V v_it2_248 = heff_dup(heff_field(v_as_241, 1));
    switch (heff_tag_of(v_it2_248)) {
    case TAG_Nil: {
      V v_t_249 = (g_heff_2eemit_2eprimUnary(heff_dup(v_p_240)));
      switch (heff_tag_of(v_t_249)) {
      case TAG_Nothing: {
        heff_drop(v_a_247);
        V v_x2_2410 = (g_prelude_2emap_24s576(v_as_241));
        V v_t_2413;
        switch (heff_tag_of(v_x2_2410)) {
        case TAG_Nil: {
          v_t_2413 = ((V)&g_heff_2eemit_2eprimCall_str4);
          break;
        }
        case TAG_Cons: {
          V v_x_2411 = heff_field(v_x2_2410, 0);
          V v_xs_2412 = heff_field(v_x2_2410, 1);
          heff_take_n(v_x2_2410, 3ULL, 2);
          v_t_2413 = ({ V a_0 = v_x_2411; V a_1 = v_xs_2412; V r_ = (g_prelude_2efoldl_24s45(a_0, a_1)); heff_drop(v_xs_2412); r_; });
          break;
        }
        default: heff_nomatch(v_x2_2410);
        }
        V v_code_2414 = heff_strAppend(((V)&g_heff_2eemit_2eprimCall_str5), heff_strAppend(v_p_240, heff_strAppend(((V)&g_heff_2eemit_2eprimCall_str6), heff_strAppend(v_t_2413, ((V)&g_heff_2eemit_2eprimCall_str7)))));
        return heff_rec(2, shape_47_252, (V[]){v_code_2414, MK_INT(3LL)});
      }
      case TAG_Just: {
        V v_f_2415 = heff_field(v_t_249, 0);
        heff_take_n(v_t_249, 1ULL, 1);
        heff_drop(v_p_240);
        heff_drop_tag(v_as_241, 2);
        return heff_tail(v_f_2415, 1, (V[]){v_a_247});
      }
      default: return heff_nomatch(v_t_249);
      }
    }
    case TAG_Cons: {
      V v_b_2416 = heff_field(v_it2_248, 0);
      V v_it22_2417 = heff_field(v_it2_248, 1);
      heff_take_n(v_it2_248, 3ULL, 2);
      switch (heff_tag_of(v_it22_2417)) {
      case TAG_Nil: {
        V v_t_2418 = (g_heff_2eemit_2eprimOp(heff_dup(v_p_240)));
        switch (heff_tag_of(v_t_2418)) {
        case TAG_Nothing: {
          heff_drop(v_a_247);
          heff_drop(v_b_2416);
          V v_x2_2419 = (g_prelude_2emap_24s576(v_as_241));
          V v_t_2422;
          switch (heff_tag_of(v_x2_2419)) {
          case TAG_Nil: {
            v_t_2422 = ((V)&g_heff_2eemit_2eprimCall_str8);
            break;
          }
          case TAG_Cons: {
            V v_x_2420 = heff_field(v_x2_2419, 0);
            V v_xs_2421 = heff_field(v_x2_2419, 1);
            heff_take_n(v_x2_2419, 3ULL, 2);
            v_t_2422 = ({ V a_0 = v_x_2420; V a_1 = v_xs_2421; V r_ = (g_prelude_2efoldl_24s45(a_0, a_1)); heff_drop(v_xs_2421); r_; });
            break;
          }
          default: heff_nomatch(v_x2_2419);
          }
          V v_code_2423 = heff_strAppend(((V)&g_heff_2eemit_2eprimCall_str9), heff_strAppend(v_p_240, heff_strAppend(((V)&g_heff_2eemit_2eprimCall_str10), heff_strAppend(v_t_2422, ((V)&g_heff_2eemit_2eprimCall_str11)))));
          return heff_rec(2, shape_47_252, (V[]){v_code_2423, MK_INT(3LL)});
        }
        case TAG_Just: {
          V v_f_2424 = heff_field(v_t_2418, 0);
          heff_take_n(v_t_2418, 1ULL, 1);
          heff_drop(v_p_240);
          heff_drop_tag(v_as_241, 2);
          return heff_tail(v_f_2424, 2, (V[]){v_a_247, v_b_2416});
        }
        default: return heff_nomatch(v_t_2418);
        }
      }
      case TAG_Cons: {
        heff_take_n(v_it22_2417, 0ULL, 2);
        heff_drop(v_a_247);
        heff_drop(v_b_2416);
        V v_x2_2427 = (g_prelude_2emap_24s576(v_as_241));
        V v_t_2430;
        switch (heff_tag_of(v_x2_2427)) {
        case TAG_Nil: {
          v_t_2430 = ((V)&g_heff_2eemit_2eprimCall_str12);
          break;
        }
        case TAG_Cons: {
          V v_x_2428 = heff_field(v_x2_2427, 0);
          V v_xs_2429 = heff_field(v_x2_2427, 1);
          heff_take_n(v_x2_2427, 3ULL, 2);
          v_t_2430 = ({ V a_0 = v_x_2428; V a_1 = v_xs_2429; V r_ = (g_prelude_2efoldl_24s45(a_0, a_1)); heff_drop(v_xs_2429); r_; });
          break;
        }
        default: heff_nomatch(v_x2_2427);
        }
        V v_code_2431 = heff_strAppend(((V)&g_heff_2eemit_2eprimCall_str13), heff_strAppend(v_p_240, heff_strAppend(((V)&g_heff_2eemit_2eprimCall_str14), heff_strAppend(v_t_2430, ((V)&g_heff_2eemit_2eprimCall_str15)))));
        return heff_rec(2, shape_47_252, (V[]){v_code_2431, MK_INT(3LL)});
      }
      default: return heff_nomatch(v_it22_2417);
      }
    }
    default: return heff_nomatch(v_it2_248);
    }
  }
  default: return heff_nomatch(v_as_241);
  }
}
V g_heff_2eemit_2eprimCall_entry(V self, V *a) {
  (void)self;
  return g_heff_2eemit_2eprimCall(a[0], a[1]);
}
Clo g_heff_2eemit_2econdIf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemit_2econdIf_entry, 3, 0};

V g_heff_2eemit_2econdIf(V v_c_240, V v_t_241, V v_e_242) {
top: ;
  switch (heff_tag_of(v_c_240)) {
  case TAG_PTrue: {
    heff_drop(v_e_242);
    return v_t_241;
  }
  case TAG_PFalse: {
    heff_drop(v_t_241);
    return v_e_242;
  }
  case TAG_PRel: {
    switch (heff_tag_of(v_t_241)) {
    case TAG_PTrue: {
      switch (heff_tag_of(v_e_242)) {
      case TAG_PTrue: {
        return heff_tag(TAG_PIf, 3, (V[]){v_c_240, v_t_241, v_e_242});
      }
      case TAG_PFalse: {
        return v_c_240;
      }
      case TAG_PRel: {
        return heff_tag(TAG_PIf, 3, (V[]){v_c_240, v_t_241, v_e_242});
      }
      case TAG_PNot: {
        return heff_tag(TAG_PIf, 3, (V[]){v_c_240, v_t_241, v_e_242});
      }
      case TAG_PIf: {
        return heff_tag(TAG_PIf, 3, (V[]){v_c_240, v_t_241, v_e_242});
      }
      case TAG_PSeq: {
        return heff_tag(TAG_PIf, 3, (V[]){v_c_240, v_t_241, v_e_242});
      }
      default: return heff_nomatch(v_e_242);
      }
    }
    case TAG_PFalse: {
      switch (heff_tag_of(v_e_242)) {
      case TAG_PTrue: {
        return heff_tag(TAG_PNot, 1, (V[]){v_c_240});
      }
      case TAG_PFalse: {
        return heff_tag(TAG_PIf, 3, (V[]){v_c_240, v_t_241, v_e_242});
      }
      case TAG_PRel: {
        return heff_tag(TAG_PIf, 3, (V[]){v_c_240, v_t_241, v_e_242});
      }
      case TAG_PNot: {
        return heff_tag(TAG_PIf, 3, (V[]){v_c_240, v_t_241, v_e_242});
      }
      case TAG_PIf: {
        return heff_tag(TAG_PIf, 3, (V[]){v_c_240, v_t_241, v_e_242});
      }
      case TAG_PSeq: {
        return heff_tag(TAG_PIf, 3, (V[]){v_c_240, v_t_241, v_e_242});
      }
      default: return heff_nomatch(v_e_242);
      }
    }
    case TAG_PRel: {
      return heff_tag(TAG_PIf, 3, (V[]){v_c_240, v_t_241, v_e_242});
    }
    case TAG_PNot: {
      return heff_tag(TAG_PIf, 3, (V[]){v_c_240, v_t_241, v_e_242});
    }
    case TAG_PIf: {
      return heff_tag(TAG_PIf, 3, (V[]){v_c_240, v_t_241, v_e_242});
    }
    case TAG_PSeq: {
      return heff_tag(TAG_PIf, 3, (V[]){v_c_240, v_t_241, v_e_242});
    }
    default: return heff_nomatch(v_t_241);
    }
  }
  case TAG_PNot: {
    V v_c1_2428 = heff_field(v_c_240, 0);
    heff_take_n(v_c_240, 1ULL, 1);
    V t_0 = v_c1_2428;
    V t_1 = v_e_242;
    V t_2 = v_t_241;
    v_c_240 = t_0;
    v_t_241 = t_1;
    v_e_242 = t_2;
    goto top;
  }
  case TAG_PIf: {
    V v_a_2429 = heff_field(v_c_240, 0);
    V v_b_2430 = heff_field(v_c_240, 1);
    V v_c3_2431 = heff_field(v_c_240, 2);
    V v_ru_24c_240_24PIf = heff_take_reuse_n(v_c_240, 7ULL, 3);
    V v_t_2440;
    switch (heff_tag_of(v_t_241)) {
    case TAG_PTrue: {
      v_t_2440 = NTAG(TAG_True);
      break;
    }
    case TAG_PFalse: {
      v_t_2440 = NTAG(TAG_True);
      break;
    }
    case TAG_PRel: {
      v_t_2440 = NTAG(TAG_False);
      break;
    }
    case TAG_PNot: {
      v_t_2440 = NTAG(TAG_False);
      break;
    }
    case TAG_PIf: {
      v_t_2440 = NTAG(TAG_False);
      break;
    }
    case TAG_PSeq: {
      v_t_2440 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_t_241);
    }
    switch (heff_tag_of(v_t_2440)) {
    case TAG_True: {
      V v_t_2449;
      switch (heff_tag_of(v_e_242)) {
      case TAG_PTrue: {
        v_t_2449 = NTAG(TAG_True);
        break;
      }
      case TAG_PFalse: {
        v_t_2449 = NTAG(TAG_True);
        break;
      }
      case TAG_PRel: {
        v_t_2449 = NTAG(TAG_False);
        break;
      }
      case TAG_PNot: {
        v_t_2449 = NTAG(TAG_False);
        break;
      }
      case TAG_PIf: {
        v_t_2449 = NTAG(TAG_False);
        break;
      }
      case TAG_PSeq: {
        v_t_2449 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_e_242);
      }
      switch (heff_tag_of(v_t_2449)) {
      case TAG_True: {
        heff_drop_cell(v_ru_24c_240_24PIf, 3);
        V v_t_2450 = (g_heff_2eemit_2econdIf(v_b_2430, heff_dup(v_t_241), heff_dup(v_e_242)));
        V v_t_2451 = (g_heff_2eemit_2econdIf(v_c3_2431, v_t_241, v_e_242));
        V t_0 = v_a_2429;
        V t_1 = v_t_2450;
        V t_2 = v_t_2451;
        v_c_240 = t_0;
        v_t_241 = t_1;
        v_e_242 = t_2;
        goto top;
      }
      case TAG_False: {
        return heff_tag_at(v_ru_24c_240_24PIf, TAG_PIf, 3, (V[]){heff_tag(TAG_PIf, 3, (V[]){v_a_2429, v_b_2430, v_c3_2431}), v_t_241, v_e_242});
      }
      default: return heff_nomatch(v_t_2449);
      }
    }
    case TAG_False: {
      return heff_tag_at(v_ru_24c_240_24PIf, TAG_PIf, 3, (V[]){heff_tag(TAG_PIf, 3, (V[]){v_a_2429, v_b_2430, v_c3_2431}), v_t_241, v_e_242});
    }
    default: return heff_nomatch(v_t_2440);
    }
  }
  case TAG_PSeq: {
    V v_x_2452 = heff_field(v_c_240, 0);
    V v_a_2453 = heff_field(v_c_240, 1);
    V v_c3_2454 = heff_field(v_c_240, 2);
    V v_ru_24c_240_24PSeq = heff_take_reuse_n(v_c_240, 7ULL, 3);
    return heff_tag_at(v_ru_24c_240_24PSeq, TAG_PSeq, 3, (V[]){v_x_2452, v_a_2453, (g_heff_2eemit_2econdIf(v_c3_2454, v_t_241, v_e_242))});
  }
  default: return heff_nomatch(v_c_240);
  }
}
V g_heff_2eemit_2econdIf_entry(V self, V *a) {
  (void)self;
  return g_heff_2eemit_2econdIf(a[0], a[1], a[2]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eemit_2econdCode_str0 = {{0x80000000u, K_STR, 0}, 4, 4, {116, 114, 117, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eemit_2econdCode_str1 = {{0x80000000u, K_STR, 0}, 5, 5, {102, 97, 108, 115, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2econdCode_str2 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2econdCode_str3 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2econdCode_str4 = {{0x80000000u, K_STR, 0}, 1, 1, {33}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2econdCode_str5 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2econdCode_str6 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2econdCode_str7 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2econdCode_str8 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eemit_2econdCode_str9 = {{0x80000000u, K_STR, 0}, 4, 4, {32, 124, 124, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2econdCode_str10 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2econdCode_str11 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2econdCode_str12 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2econdCode_str13 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eemit_2econdCode_str14 = {{0x80000000u, K_STR, 0}, 4, 4, {32, 38, 38, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2econdCode_str15 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2econdCode_str16 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2econdCode_str17 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2econdCode_str18 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eemit_2econdCode_str19 = {{0x80000000u, K_STR, 0}, 4, 4, {32, 124, 124, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2econdCode_str20 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2econdCode_str21 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2econdCode_str22 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2econdCode_str23 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eemit_2econdCode_str24 = {{0x80000000u, K_STR, 0}, 4, 4, {32, 124, 124, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2econdCode_str25 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2econdCode_str26 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2econdCode_str27 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2econdCode_str28 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eemit_2econdCode_str29 = {{0x80000000u, K_STR, 0}, 4, 4, {32, 124, 124, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2econdCode_str30 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2econdCode_str31 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2econdCode_str32 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2econdCode_str33 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eemit_2econdCode_str34 = {{0x80000000u, K_STR, 0}, 4, 4, {32, 124, 124, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2econdCode_str35 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2econdCode_str36 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2econdCode_str37 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2econdCode_str38 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eemit_2econdCode_str39 = {{0x80000000u, K_STR, 0}, 4, 4, {32, 38, 38, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2econdCode_str40 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2econdCode_str41 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2econdCode_str42 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2econdCode_str43 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eemit_2econdCode_str44 = {{0x80000000u, K_STR, 0}, 4, 4, {32, 124, 124, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2econdCode_str45 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2econdCode_str46 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2econdCode_str47 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2econdCode_str48 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eemit_2econdCode_str49 = {{0x80000000u, K_STR, 0}, 4, 4, {32, 38, 38, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2econdCode_str50 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2econdCode_str51 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2econdCode_str52 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2econdCode_str53 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2econdCode_str54 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2econdCode_str55 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemit_2econdCode_str56 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 63, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemit_2econdCode_str57 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 58, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2econdCode_str58 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2econdCode_str59 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2econdCode_str60 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2econdCode_str61 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2econdCode_str62 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2econdCode_str63 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemit_2econdCode_str64 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 63, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemit_2econdCode_str65 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 58, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2econdCode_str66 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2econdCode_str67 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2econdCode_str68 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2econdCode_str69 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2econdCode_str70 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2econdCode_str71 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemit_2econdCode_str72 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 63, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemit_2econdCode_str73 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 58, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2econdCode_str74 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2econdCode_str75 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2econdCode_str76 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2econdCode_str77 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2econdCode_str78 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2econdCode_str79 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemit_2econdCode_str80 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 63, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemit_2econdCode_str81 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 58, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2econdCode_str82 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2econdCode_str83 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2econdCode_str84 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2econdCode_str85 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eemit_2econdCode_str86 = {{0x80000000u, K_STR, 0}, 4, 4, {32, 124, 124, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2econdCode_str87 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2econdCode_str88 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2econdCode_str89 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2econdCode_str90 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eemit_2econdCode_str91 = {{0x80000000u, K_STR, 0}, 4, 4, {32, 38, 38, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2econdCode_str92 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2econdCode_str93 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2econdCode_str94 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2econdCode_str95 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2econdCode_str96 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2econdCode_str97 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemit_2econdCode_str98 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 63, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemit_2econdCode_str99 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 58, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2econdCode_str100 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2econdCode_str101 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2econdCode_str102 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2econdCode_str103 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2econdCode_str104 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2econdCode_str105 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemit_2econdCode_str106 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 63, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemit_2econdCode_str107 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 58, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2econdCode_str108 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2econdCode_str109 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2econdCode_str110 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2econdCode_str111 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2econdCode_str112 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2econdCode_str113 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemit_2econdCode_str114 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 63, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemit_2econdCode_str115 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 58, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2econdCode_str116 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2econdCode_str117 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2econdCode_str118 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2econdCode_str119 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2econdCode_str120 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2econdCode_str121 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemit_2econdCode_str122 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 63, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemit_2econdCode_str123 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 58, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2econdCode_str124 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2econdCode_str125 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2econdCode_str126 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2econdCode_str127 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eemit_2econdCode_str128 = {{0x80000000u, K_STR, 0}, 4, 4, {32, 124, 124, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2econdCode_str129 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2econdCode_str130 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2econdCode_str131 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2econdCode_str132 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eemit_2econdCode_str133 = {{0x80000000u, K_STR, 0}, 4, 4, {32, 38, 38, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2econdCode_str134 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2econdCode_str135 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2econdCode_str136 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2econdCode_str137 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2econdCode_str138 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2econdCode_str139 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemit_2econdCode_str140 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 63, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemit_2econdCode_str141 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 58, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2econdCode_str142 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2econdCode_str143 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2econdCode_str144 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2econdCode_str145 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2econdCode_str146 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2econdCode_str147 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemit_2econdCode_str148 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 63, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemit_2econdCode_str149 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 58, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2econdCode_str150 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2econdCode_str151 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2econdCode_str152 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2econdCode_str153 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2econdCode_str154 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2econdCode_str155 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemit_2econdCode_str156 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 63, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemit_2econdCode_str157 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 58, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2econdCode_str158 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2econdCode_str159 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2econdCode_str160 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2econdCode_str161 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2econdCode_str162 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2econdCode_str163 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemit_2econdCode_str164 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 63, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemit_2econdCode_str165 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 58, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2econdCode_str166 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2econdCode_str167 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2econdCode_str168 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2econdCode_str169 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eemit_2econdCode_str170 = {{0x80000000u, K_STR, 0}, 4, 4, {32, 124, 124, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2econdCode_str171 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2econdCode_str172 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2econdCode_str173 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2econdCode_str174 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eemit_2econdCode_str175 = {{0x80000000u, K_STR, 0}, 4, 4, {32, 38, 38, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2econdCode_str176 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2econdCode_str177 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2econdCode_str178 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2econdCode_str179 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2econdCode_str180 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2econdCode_str181 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemit_2econdCode_str182 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 63, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemit_2econdCode_str183 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 58, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2econdCode_str184 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2econdCode_str185 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2econdCode_str186 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2econdCode_str187 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2econdCode_str188 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2econdCode_str189 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemit_2econdCode_str190 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 63, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemit_2econdCode_str191 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 58, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2econdCode_str192 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2econdCode_str193 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2econdCode_str194 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2econdCode_str195 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2econdCode_str196 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2econdCode_str197 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemit_2econdCode_str198 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 63, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemit_2econdCode_str199 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 58, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2econdCode_str200 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2econdCode_str201 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2econdCode_str202 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2econdCode_str203 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2econdCode_str204 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2econdCode_str205 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemit_2econdCode_str206 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 63, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemit_2econdCode_str207 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 58, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2econdCode_str208 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2econdCode_str209 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2econdCode_str210 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemit_2econdCode_str211 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 61, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemit_2econdCode_str212 = {{0x80000000u, K_STR, 0}, 2, 2, {44, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2econdCode_str213 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
Clo g_heff_2eemit_2econdCode_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemit_2econdCode_entry, 1, 0};

V g_heff_2eemit_2econdCode(V v_p_240) {
top: ;
  switch (heff_tag_of(v_p_240)) {
  case TAG_PTrue: {
    return heff_rec(2, shape_47_252, (V[]){((V)&g_heff_2eemit_2econdCode_str0), MK_INT(4LL)});
  }
  case TAG_PFalse: {
    return heff_rec(2, shape_47_252, (V[]){((V)&g_heff_2eemit_2econdCode_str1), MK_INT(4LL)});
  }
  case TAG_PRel: {
    V v_s_241 = heff_field(v_p_240, 0);
    heff_take_n(v_p_240, 1ULL, 1);
    return heff_rec(2, shape_47_252, (V[]){v_s_241, MK_INT(3LL)});
  }
  case TAG_PNot: {
    V v_q_242 = heff_field(v_p_240, 0);
    heff_take_n(v_p_240, 1ULL, 1);
    V v_c_243 = (g_heff_2eemit_2econdCode(v_q_242));
    V v_t_244 = heff_intLt(heff_get(heff_dup(v_c_243), LBL_prec), MK_INT(4LL));
    V v_t_245;
    switch (heff_tag_of(v_t_244)) {
    case TAG_True: {
      v_t_245 = heff_strAppend(((V)&g_heff_2eemit_2econdCode_str2), heff_strAppend(heff_get(v_c_243, LBL_code), ((V)&g_heff_2eemit_2econdCode_str3)));
      break;
    }
    case TAG_False: {
      v_t_245 = heff_get(v_c_243, LBL_code);
      break;
    }
    default: heff_nomatch(v_t_244);
    }
    return heff_rec(2, shape_47_252, (V[]){heff_strAppend(((V)&g_heff_2eemit_2econdCode_str4), v_t_245), MK_INT(4LL)});
  }
  case TAG_PIf: {
    V v_c_246 = heff_field(v_p_240, 0);
    V v_t_247 = heff_field(v_p_240, 1);
    V v_it3_248 = heff_field(v_p_240, 2);
    heff_take_n(v_p_240, 7ULL, 3);
    switch (heff_tag_of(v_it3_248)) {
    case TAG_PTrue: {
      switch (heff_tag_of(v_t_247)) {
      case TAG_PTrue: {
        V v_c_249 = (g_heff_2eemit_2econdCode(v_c_246));
        V v_t_2410 = heff_intLt(heff_get(heff_dup(v_c_249), LBL_prec), MK_INT(1LL));
        V v_t_2411;
        switch (heff_tag_of(v_t_2410)) {
        case TAG_True: {
          v_t_2411 = heff_strAppend(((V)&g_heff_2eemit_2econdCode_str5), heff_strAppend(heff_get(v_c_249, LBL_code), ((V)&g_heff_2eemit_2econdCode_str6)));
          break;
        }
        case TAG_False: {
          v_t_2411 = heff_get(v_c_249, LBL_code);
          break;
        }
        default: heff_nomatch(v_t_2410);
        }
        V v_c_2412 = (g_heff_2eemit_2econdCode(v_it3_248));
        V v_t_2413 = heff_intLt(heff_get(heff_dup(v_c_2412), LBL_prec), MK_INT(1LL));
        V v_t_2414;
        switch (heff_tag_of(v_t_2413)) {
        case TAG_True: {
          v_t_2414 = heff_strAppend(((V)&g_heff_2eemit_2econdCode_str7), heff_strAppend(heff_get(v_c_2412, LBL_code), ((V)&g_heff_2eemit_2econdCode_str8)));
          break;
        }
        case TAG_False: {
          v_t_2414 = heff_get(v_c_2412, LBL_code);
          break;
        }
        default: heff_nomatch(v_t_2413);
        }
        V v_t_2415 = heff_strAppend(v_t_2411, heff_strAppend(((V)&g_heff_2eemit_2econdCode_str9), v_t_2414));
        return heff_rec(2, shape_47_252, (V[]){v_t_2415, MK_INT(1LL)});
      }
      case TAG_PFalse: {
        V v_c_2416 = (g_heff_2eemit_2econdCode(heff_tag(TAG_PNot, 1, (V[]){v_c_246})));
        V v_t_2417 = heff_intLt(heff_get(heff_dup(v_c_2416), LBL_prec), MK_INT(2LL));
        V v_t_2418;
        switch (heff_tag_of(v_t_2417)) {
        case TAG_True: {
          v_t_2418 = heff_strAppend(((V)&g_heff_2eemit_2econdCode_str10), heff_strAppend(heff_get(v_c_2416, LBL_code), ((V)&g_heff_2eemit_2econdCode_str11)));
          break;
        }
        case TAG_False: {
          v_t_2418 = heff_get(v_c_2416, LBL_code);
          break;
        }
        default: heff_nomatch(v_t_2417);
        }
        V v_c_2419 = (g_heff_2eemit_2econdCode(v_it3_248));
        V v_t_2420 = heff_intLt(heff_get(heff_dup(v_c_2419), LBL_prec), MK_INT(2LL));
        V v_t_2421;
        switch (heff_tag_of(v_t_2420)) {
        case TAG_True: {
          v_t_2421 = heff_strAppend(((V)&g_heff_2eemit_2econdCode_str12), heff_strAppend(heff_get(v_c_2419, LBL_code), ((V)&g_heff_2eemit_2econdCode_str13)));
          break;
        }
        case TAG_False: {
          v_t_2421 = heff_get(v_c_2419, LBL_code);
          break;
        }
        default: heff_nomatch(v_t_2420);
        }
        V v_t_2422 = heff_strAppend(v_t_2418, heff_strAppend(((V)&g_heff_2eemit_2econdCode_str14), v_t_2421));
        return heff_rec(2, shape_47_252, (V[]){v_t_2422, MK_INT(2LL)});
      }
      case TAG_PRel: {
        V v_c_2424 = (g_heff_2eemit_2econdCode(heff_tag(TAG_PNot, 1, (V[]){v_c_246})));
        V v_t_2425 = heff_intLt(heff_get(heff_dup(v_c_2424), LBL_prec), MK_INT(1LL));
        V v_t_2426;
        switch (heff_tag_of(v_t_2425)) {
        case TAG_True: {
          v_t_2426 = heff_strAppend(((V)&g_heff_2eemit_2econdCode_str15), heff_strAppend(heff_get(v_c_2424, LBL_code), ((V)&g_heff_2eemit_2econdCode_str16)));
          break;
        }
        case TAG_False: {
          v_t_2426 = heff_get(v_c_2424, LBL_code);
          break;
        }
        default: heff_nomatch(v_t_2425);
        }
        V v_c_2427 = (g_heff_2eemit_2econdCode(v_t_247));
        V v_t_2428 = heff_intLt(heff_get(heff_dup(v_c_2427), LBL_prec), MK_INT(1LL));
        V v_t_2429;
        switch (heff_tag_of(v_t_2428)) {
        case TAG_True: {
          v_t_2429 = heff_strAppend(((V)&g_heff_2eemit_2econdCode_str17), heff_strAppend(heff_get(v_c_2427, LBL_code), ((V)&g_heff_2eemit_2econdCode_str18)));
          break;
        }
        case TAG_False: {
          v_t_2429 = heff_get(v_c_2427, LBL_code);
          break;
        }
        default: heff_nomatch(v_t_2428);
        }
        V v_t_2430 = heff_strAppend(v_t_2426, heff_strAppend(((V)&g_heff_2eemit_2econdCode_str19), v_t_2429));
        return heff_rec(2, shape_47_252, (V[]){v_t_2430, MK_INT(1LL)});
      }
      case TAG_PNot: {
        V v_c_2432 = (g_heff_2eemit_2econdCode(heff_tag(TAG_PNot, 1, (V[]){v_c_246})));
        V v_t_2433 = heff_intLt(heff_get(heff_dup(v_c_2432), LBL_prec), MK_INT(1LL));
        V v_t_2434;
        switch (heff_tag_of(v_t_2433)) {
        case TAG_True: {
          v_t_2434 = heff_strAppend(((V)&g_heff_2eemit_2econdCode_str20), heff_strAppend(heff_get(v_c_2432, LBL_code), ((V)&g_heff_2eemit_2econdCode_str21)));
          break;
        }
        case TAG_False: {
          v_t_2434 = heff_get(v_c_2432, LBL_code);
          break;
        }
        default: heff_nomatch(v_t_2433);
        }
        V v_c_2435 = (g_heff_2eemit_2econdCode(v_t_247));
        V v_t_2436 = heff_intLt(heff_get(heff_dup(v_c_2435), LBL_prec), MK_INT(1LL));
        V v_t_2437;
        switch (heff_tag_of(v_t_2436)) {
        case TAG_True: {
          v_t_2437 = heff_strAppend(((V)&g_heff_2eemit_2econdCode_str22), heff_strAppend(heff_get(v_c_2435, LBL_code), ((V)&g_heff_2eemit_2econdCode_str23)));
          break;
        }
        case TAG_False: {
          v_t_2437 = heff_get(v_c_2435, LBL_code);
          break;
        }
        default: heff_nomatch(v_t_2436);
        }
        V v_t_2438 = heff_strAppend(v_t_2434, heff_strAppend(((V)&g_heff_2eemit_2econdCode_str24), v_t_2437));
        return heff_rec(2, shape_47_252, (V[]){v_t_2438, MK_INT(1LL)});
      }
      case TAG_PIf: {
        V v_c_2442 = (g_heff_2eemit_2econdCode(heff_tag(TAG_PNot, 1, (V[]){v_c_246})));
        V v_t_2443 = heff_intLt(heff_get(heff_dup(v_c_2442), LBL_prec), MK_INT(1LL));
        V v_t_2444;
        switch (heff_tag_of(v_t_2443)) {
        case TAG_True: {
          v_t_2444 = heff_strAppend(((V)&g_heff_2eemit_2econdCode_str25), heff_strAppend(heff_get(v_c_2442, LBL_code), ((V)&g_heff_2eemit_2econdCode_str26)));
          break;
        }
        case TAG_False: {
          v_t_2444 = heff_get(v_c_2442, LBL_code);
          break;
        }
        default: heff_nomatch(v_t_2443);
        }
        V v_c_2445 = (g_heff_2eemit_2econdCode(v_t_247));
        V v_t_2446 = heff_intLt(heff_get(heff_dup(v_c_2445), LBL_prec), MK_INT(1LL));
        V v_t_2447;
        switch (heff_tag_of(v_t_2446)) {
        case TAG_True: {
          v_t_2447 = heff_strAppend(((V)&g_heff_2eemit_2econdCode_str27), heff_strAppend(heff_get(v_c_2445, LBL_code), ((V)&g_heff_2eemit_2econdCode_str28)));
          break;
        }
        case TAG_False: {
          v_t_2447 = heff_get(v_c_2445, LBL_code);
          break;
        }
        default: heff_nomatch(v_t_2446);
        }
        V v_t_2448 = heff_strAppend(v_t_2444, heff_strAppend(((V)&g_heff_2eemit_2econdCode_str29), v_t_2447));
        return heff_rec(2, shape_47_252, (V[]){v_t_2448, MK_INT(1LL)});
      }
      case TAG_PSeq: {
        V v_c_2452 = (g_heff_2eemit_2econdCode(heff_tag(TAG_PNot, 1, (V[]){v_c_246})));
        V v_t_2453 = heff_intLt(heff_get(heff_dup(v_c_2452), LBL_prec), MK_INT(1LL));
        V v_t_2454;
        switch (heff_tag_of(v_t_2453)) {
        case TAG_True: {
          v_t_2454 = heff_strAppend(((V)&g_heff_2eemit_2econdCode_str30), heff_strAppend(heff_get(v_c_2452, LBL_code), ((V)&g_heff_2eemit_2econdCode_str31)));
          break;
        }
        case TAG_False: {
          v_t_2454 = heff_get(v_c_2452, LBL_code);
          break;
        }
        default: heff_nomatch(v_t_2453);
        }
        V v_c_2455 = (g_heff_2eemit_2econdCode(v_t_247));
        V v_t_2456 = heff_intLt(heff_get(heff_dup(v_c_2455), LBL_prec), MK_INT(1LL));
        V v_t_2457;
        switch (heff_tag_of(v_t_2456)) {
        case TAG_True: {
          v_t_2457 = heff_strAppend(((V)&g_heff_2eemit_2econdCode_str32), heff_strAppend(heff_get(v_c_2455, LBL_code), ((V)&g_heff_2eemit_2econdCode_str33)));
          break;
        }
        case TAG_False: {
          v_t_2457 = heff_get(v_c_2455, LBL_code);
          break;
        }
        default: heff_nomatch(v_t_2456);
        }
        V v_t_2458 = heff_strAppend(v_t_2454, heff_strAppend(((V)&g_heff_2eemit_2econdCode_str34), v_t_2457));
        return heff_rec(2, shape_47_252, (V[]){v_t_2458, MK_INT(1LL)});
      }
      default: return heff_nomatch(v_t_247);
      }
    }
    case TAG_PFalse: {
      V v_c_2459 = (g_heff_2eemit_2econdCode(v_c_246));
      V v_t_2460 = heff_intLt(heff_get(heff_dup(v_c_2459), LBL_prec), MK_INT(2LL));
      V v_t_2461;
      switch (heff_tag_of(v_t_2460)) {
      case TAG_True: {
        v_t_2461 = heff_strAppend(((V)&g_heff_2eemit_2econdCode_str35), heff_strAppend(heff_get(v_c_2459, LBL_code), ((V)&g_heff_2eemit_2econdCode_str36)));
        break;
      }
      case TAG_False: {
        v_t_2461 = heff_get(v_c_2459, LBL_code);
        break;
      }
      default: heff_nomatch(v_t_2460);
      }
      V v_c_2462 = (g_heff_2eemit_2econdCode(v_t_247));
      V v_t_2463 = heff_intLt(heff_get(heff_dup(v_c_2462), LBL_prec), MK_INT(2LL));
      V v_t_2464;
      switch (heff_tag_of(v_t_2463)) {
      case TAG_True: {
        v_t_2464 = heff_strAppend(((V)&g_heff_2eemit_2econdCode_str37), heff_strAppend(heff_get(v_c_2462, LBL_code), ((V)&g_heff_2eemit_2econdCode_str38)));
        break;
      }
      case TAG_False: {
        v_t_2464 = heff_get(v_c_2462, LBL_code);
        break;
      }
      default: heff_nomatch(v_t_2463);
      }
      V v_t_2465 = heff_strAppend(v_t_2461, heff_strAppend(((V)&g_heff_2eemit_2econdCode_str39), v_t_2464));
      return heff_rec(2, shape_47_252, (V[]){v_t_2465, MK_INT(2LL)});
    }
    case TAG_PRel: {
      switch (heff_tag_of(v_t_247)) {
      case TAG_PTrue: {
        V v_c_2467 = (g_heff_2eemit_2econdCode(v_c_246));
        V v_t_2468 = heff_intLt(heff_get(heff_dup(v_c_2467), LBL_prec), MK_INT(1LL));
        V v_t_2469;
        switch (heff_tag_of(v_t_2468)) {
        case TAG_True: {
          v_t_2469 = heff_strAppend(((V)&g_heff_2eemit_2econdCode_str40), heff_strAppend(heff_get(v_c_2467, LBL_code), ((V)&g_heff_2eemit_2econdCode_str41)));
          break;
        }
        case TAG_False: {
          v_t_2469 = heff_get(v_c_2467, LBL_code);
          break;
        }
        default: heff_nomatch(v_t_2468);
        }
        V v_c_2470 = (g_heff_2eemit_2econdCode(v_it3_248));
        V v_t_2471 = heff_intLt(heff_get(heff_dup(v_c_2470), LBL_prec), MK_INT(1LL));
        V v_t_2472;
        switch (heff_tag_of(v_t_2471)) {
        case TAG_True: {
          v_t_2472 = heff_strAppend(((V)&g_heff_2eemit_2econdCode_str42), heff_strAppend(heff_get(v_c_2470, LBL_code), ((V)&g_heff_2eemit_2econdCode_str43)));
          break;
        }
        case TAG_False: {
          v_t_2472 = heff_get(v_c_2470, LBL_code);
          break;
        }
        default: heff_nomatch(v_t_2471);
        }
        V v_t_2473 = heff_strAppend(v_t_2469, heff_strAppend(((V)&g_heff_2eemit_2econdCode_str44), v_t_2472));
        return heff_rec(2, shape_47_252, (V[]){v_t_2473, MK_INT(1LL)});
      }
      case TAG_PFalse: {
        V v_c_2474 = (g_heff_2eemit_2econdCode(heff_tag(TAG_PNot, 1, (V[]){v_c_246})));
        V v_t_2475 = heff_intLt(heff_get(heff_dup(v_c_2474), LBL_prec), MK_INT(2LL));
        V v_t_2476;
        switch (heff_tag_of(v_t_2475)) {
        case TAG_True: {
          v_t_2476 = heff_strAppend(((V)&g_heff_2eemit_2econdCode_str45), heff_strAppend(heff_get(v_c_2474, LBL_code), ((V)&g_heff_2eemit_2econdCode_str46)));
          break;
        }
        case TAG_False: {
          v_t_2476 = heff_get(v_c_2474, LBL_code);
          break;
        }
        default: heff_nomatch(v_t_2475);
        }
        V v_c_2477 = (g_heff_2eemit_2econdCode(v_it3_248));
        V v_t_2478 = heff_intLt(heff_get(heff_dup(v_c_2477), LBL_prec), MK_INT(2LL));
        V v_t_2479;
        switch (heff_tag_of(v_t_2478)) {
        case TAG_True: {
          v_t_2479 = heff_strAppend(((V)&g_heff_2eemit_2econdCode_str47), heff_strAppend(heff_get(v_c_2477, LBL_code), ((V)&g_heff_2eemit_2econdCode_str48)));
          break;
        }
        case TAG_False: {
          v_t_2479 = heff_get(v_c_2477, LBL_code);
          break;
        }
        default: heff_nomatch(v_t_2478);
        }
        V v_t_2480 = heff_strAppend(v_t_2476, heff_strAppend(((V)&g_heff_2eemit_2econdCode_str49), v_t_2479));
        return heff_rec(2, shape_47_252, (V[]){v_t_2480, MK_INT(2LL)});
      }
      case TAG_PRel: {
        V v_c_2482 = (g_heff_2eemit_2econdCode(v_c_246));
        V v_t_2483 = heff_intLt(heff_get(heff_dup(v_c_2482), LBL_prec), MK_INT(1LL));
        V v_t_2484;
        switch (heff_tag_of(v_t_2483)) {
        case TAG_True: {
          v_t_2484 = heff_strAppend(((V)&g_heff_2eemit_2econdCode_str50), heff_strAppend(heff_get(v_c_2482, LBL_code), ((V)&g_heff_2eemit_2econdCode_str51)));
          break;
        }
        case TAG_False: {
          v_t_2484 = heff_get(v_c_2482, LBL_code);
          break;
        }
        default: heff_nomatch(v_t_2483);
        }
        V v_c_2485 = (g_heff_2eemit_2econdCode(v_t_247));
        V v_t_2486 = heff_intLt(heff_get(heff_dup(v_c_2485), LBL_prec), MK_INT(0LL));
        V v_t_2487;
        switch (heff_tag_of(v_t_2486)) {
        case TAG_True: {
          v_t_2487 = heff_strAppend(((V)&g_heff_2eemit_2econdCode_str52), heff_strAppend(heff_get(v_c_2485, LBL_code), ((V)&g_heff_2eemit_2econdCode_str53)));
          break;
        }
        case TAG_False: {
          v_t_2487 = heff_get(v_c_2485, LBL_code);
          break;
        }
        default: heff_nomatch(v_t_2486);
        }
        V v_c_2488 = (g_heff_2eemit_2econdCode(v_it3_248));
        V v_t_2489 = heff_intLt(heff_get(heff_dup(v_c_2488), LBL_prec), MK_INT(0LL));
        V v_t_2490;
        switch (heff_tag_of(v_t_2489)) {
        case TAG_True: {
          v_t_2490 = heff_strAppend(((V)&g_heff_2eemit_2econdCode_str54), heff_strAppend(heff_get(v_c_2488, LBL_code), ((V)&g_heff_2eemit_2econdCode_str55)));
          break;
        }
        case TAG_False: {
          v_t_2490 = heff_get(v_c_2488, LBL_code);
          break;
        }
        default: heff_nomatch(v_t_2489);
        }
        V v_t_2491 = heff_strAppend(v_t_2484, heff_strAppend(((V)&g_heff_2eemit_2econdCode_str56), heff_strAppend(v_t_2487, heff_strAppend(((V)&g_heff_2eemit_2econdCode_str57), v_t_2490))));
        return heff_rec(2, shape_47_252, (V[]){v_t_2491, MK_INT(0LL)});
      }
      case TAG_PNot: {
        V v_c_2493 = (g_heff_2eemit_2econdCode(v_c_246));
        V v_t_2494 = heff_intLt(heff_get(heff_dup(v_c_2493), LBL_prec), MK_INT(1LL));
        V v_t_2495;
        switch (heff_tag_of(v_t_2494)) {
        case TAG_True: {
          v_t_2495 = heff_strAppend(((V)&g_heff_2eemit_2econdCode_str58), heff_strAppend(heff_get(v_c_2493, LBL_code), ((V)&g_heff_2eemit_2econdCode_str59)));
          break;
        }
        case TAG_False: {
          v_t_2495 = heff_get(v_c_2493, LBL_code);
          break;
        }
        default: heff_nomatch(v_t_2494);
        }
        V v_c_2496 = (g_heff_2eemit_2econdCode(v_t_247));
        V v_t_2497 = heff_intLt(heff_get(heff_dup(v_c_2496), LBL_prec), MK_INT(0LL));
        V v_t_2498;
        switch (heff_tag_of(v_t_2497)) {
        case TAG_True: {
          v_t_2498 = heff_strAppend(((V)&g_heff_2eemit_2econdCode_str60), heff_strAppend(heff_get(v_c_2496, LBL_code), ((V)&g_heff_2eemit_2econdCode_str61)));
          break;
        }
        case TAG_False: {
          v_t_2498 = heff_get(v_c_2496, LBL_code);
          break;
        }
        default: heff_nomatch(v_t_2497);
        }
        V v_c_2499 = (g_heff_2eemit_2econdCode(v_it3_248));
        V v_t_24100 = heff_intLt(heff_get(heff_dup(v_c_2499), LBL_prec), MK_INT(0LL));
        V v_t_24101;
        switch (heff_tag_of(v_t_24100)) {
        case TAG_True: {
          v_t_24101 = heff_strAppend(((V)&g_heff_2eemit_2econdCode_str62), heff_strAppend(heff_get(v_c_2499, LBL_code), ((V)&g_heff_2eemit_2econdCode_str63)));
          break;
        }
        case TAG_False: {
          v_t_24101 = heff_get(v_c_2499, LBL_code);
          break;
        }
        default: heff_nomatch(v_t_24100);
        }
        V v_t_24102 = heff_strAppend(v_t_2495, heff_strAppend(((V)&g_heff_2eemit_2econdCode_str64), heff_strAppend(v_t_2498, heff_strAppend(((V)&g_heff_2eemit_2econdCode_str65), v_t_24101))));
        return heff_rec(2, shape_47_252, (V[]){v_t_24102, MK_INT(0LL)});
      }
      case TAG_PIf: {
        V v_c_24106 = (g_heff_2eemit_2econdCode(v_c_246));
        V v_t_24107 = heff_intLt(heff_get(heff_dup(v_c_24106), LBL_prec), MK_INT(1LL));
        V v_t_24108;
        switch (heff_tag_of(v_t_24107)) {
        case TAG_True: {
          v_t_24108 = heff_strAppend(((V)&g_heff_2eemit_2econdCode_str66), heff_strAppend(heff_get(v_c_24106, LBL_code), ((V)&g_heff_2eemit_2econdCode_str67)));
          break;
        }
        case TAG_False: {
          v_t_24108 = heff_get(v_c_24106, LBL_code);
          break;
        }
        default: heff_nomatch(v_t_24107);
        }
        V v_c_24109 = (g_heff_2eemit_2econdCode(v_t_247));
        V v_t_24110 = heff_intLt(heff_get(heff_dup(v_c_24109), LBL_prec), MK_INT(0LL));
        V v_t_24111;
        switch (heff_tag_of(v_t_24110)) {
        case TAG_True: {
          v_t_24111 = heff_strAppend(((V)&g_heff_2eemit_2econdCode_str68), heff_strAppend(heff_get(v_c_24109, LBL_code), ((V)&g_heff_2eemit_2econdCode_str69)));
          break;
        }
        case TAG_False: {
          v_t_24111 = heff_get(v_c_24109, LBL_code);
          break;
        }
        default: heff_nomatch(v_t_24110);
        }
        V v_c_24112 = (g_heff_2eemit_2econdCode(v_it3_248));
        V v_t_24113 = heff_intLt(heff_get(heff_dup(v_c_24112), LBL_prec), MK_INT(0LL));
        V v_t_24114;
        switch (heff_tag_of(v_t_24113)) {
        case TAG_True: {
          v_t_24114 = heff_strAppend(((V)&g_heff_2eemit_2econdCode_str70), heff_strAppend(heff_get(v_c_24112, LBL_code), ((V)&g_heff_2eemit_2econdCode_str71)));
          break;
        }
        case TAG_False: {
          v_t_24114 = heff_get(v_c_24112, LBL_code);
          break;
        }
        default: heff_nomatch(v_t_24113);
        }
        V v_t_24115 = heff_strAppend(v_t_24108, heff_strAppend(((V)&g_heff_2eemit_2econdCode_str72), heff_strAppend(v_t_24111, heff_strAppend(((V)&g_heff_2eemit_2econdCode_str73), v_t_24114))));
        return heff_rec(2, shape_47_252, (V[]){v_t_24115, MK_INT(0LL)});
      }
      case TAG_PSeq: {
        V v_c_24119 = (g_heff_2eemit_2econdCode(v_c_246));
        V v_t_24120 = heff_intLt(heff_get(heff_dup(v_c_24119), LBL_prec), MK_INT(1LL));
        V v_t_24121;
        switch (heff_tag_of(v_t_24120)) {
        case TAG_True: {
          v_t_24121 = heff_strAppend(((V)&g_heff_2eemit_2econdCode_str74), heff_strAppend(heff_get(v_c_24119, LBL_code), ((V)&g_heff_2eemit_2econdCode_str75)));
          break;
        }
        case TAG_False: {
          v_t_24121 = heff_get(v_c_24119, LBL_code);
          break;
        }
        default: heff_nomatch(v_t_24120);
        }
        V v_c_24122 = (g_heff_2eemit_2econdCode(v_t_247));
        V v_t_24123 = heff_intLt(heff_get(heff_dup(v_c_24122), LBL_prec), MK_INT(0LL));
        V v_t_24124;
        switch (heff_tag_of(v_t_24123)) {
        case TAG_True: {
          v_t_24124 = heff_strAppend(((V)&g_heff_2eemit_2econdCode_str76), heff_strAppend(heff_get(v_c_24122, LBL_code), ((V)&g_heff_2eemit_2econdCode_str77)));
          break;
        }
        case TAG_False: {
          v_t_24124 = heff_get(v_c_24122, LBL_code);
          break;
        }
        default: heff_nomatch(v_t_24123);
        }
        V v_c_24125 = (g_heff_2eemit_2econdCode(v_it3_248));
        V v_t_24126 = heff_intLt(heff_get(heff_dup(v_c_24125), LBL_prec), MK_INT(0LL));
        V v_t_24127;
        switch (heff_tag_of(v_t_24126)) {
        case TAG_True: {
          v_t_24127 = heff_strAppend(((V)&g_heff_2eemit_2econdCode_str78), heff_strAppend(heff_get(v_c_24125, LBL_code), ((V)&g_heff_2eemit_2econdCode_str79)));
          break;
        }
        case TAG_False: {
          v_t_24127 = heff_get(v_c_24125, LBL_code);
          break;
        }
        default: heff_nomatch(v_t_24126);
        }
        V v_t_24128 = heff_strAppend(v_t_24121, heff_strAppend(((V)&g_heff_2eemit_2econdCode_str80), heff_strAppend(v_t_24124, heff_strAppend(((V)&g_heff_2eemit_2econdCode_str81), v_t_24127))));
        return heff_rec(2, shape_47_252, (V[]){v_t_24128, MK_INT(0LL)});
      }
      default: return heff_nomatch(v_t_247);
      }
    }
    case TAG_PNot: {
      switch (heff_tag_of(v_t_247)) {
      case TAG_PTrue: {
        V v_c_24130 = (g_heff_2eemit_2econdCode(v_c_246));
        V v_t_24131 = heff_intLt(heff_get(heff_dup(v_c_24130), LBL_prec), MK_INT(1LL));
        V v_t_24132;
        switch (heff_tag_of(v_t_24131)) {
        case TAG_True: {
          v_t_24132 = heff_strAppend(((V)&g_heff_2eemit_2econdCode_str82), heff_strAppend(heff_get(v_c_24130, LBL_code), ((V)&g_heff_2eemit_2econdCode_str83)));
          break;
        }
        case TAG_False: {
          v_t_24132 = heff_get(v_c_24130, LBL_code);
          break;
        }
        default: heff_nomatch(v_t_24131);
        }
        V v_c_24133 = (g_heff_2eemit_2econdCode(v_it3_248));
        V v_t_24134 = heff_intLt(heff_get(heff_dup(v_c_24133), LBL_prec), MK_INT(1LL));
        V v_t_24135;
        switch (heff_tag_of(v_t_24134)) {
        case TAG_True: {
          v_t_24135 = heff_strAppend(((V)&g_heff_2eemit_2econdCode_str84), heff_strAppend(heff_get(v_c_24133, LBL_code), ((V)&g_heff_2eemit_2econdCode_str85)));
          break;
        }
        case TAG_False: {
          v_t_24135 = heff_get(v_c_24133, LBL_code);
          break;
        }
        default: heff_nomatch(v_t_24134);
        }
        V v_t_24136 = heff_strAppend(v_t_24132, heff_strAppend(((V)&g_heff_2eemit_2econdCode_str86), v_t_24135));
        return heff_rec(2, shape_47_252, (V[]){v_t_24136, MK_INT(1LL)});
      }
      case TAG_PFalse: {
        V v_c_24137 = (g_heff_2eemit_2econdCode(heff_tag(TAG_PNot, 1, (V[]){v_c_246})));
        V v_t_24138 = heff_intLt(heff_get(heff_dup(v_c_24137), LBL_prec), MK_INT(2LL));
        V v_t_24139;
        switch (heff_tag_of(v_t_24138)) {
        case TAG_True: {
          v_t_24139 = heff_strAppend(((V)&g_heff_2eemit_2econdCode_str87), heff_strAppend(heff_get(v_c_24137, LBL_code), ((V)&g_heff_2eemit_2econdCode_str88)));
          break;
        }
        case TAG_False: {
          v_t_24139 = heff_get(v_c_24137, LBL_code);
          break;
        }
        default: heff_nomatch(v_t_24138);
        }
        V v_c_24140 = (g_heff_2eemit_2econdCode(v_it3_248));
        V v_t_24141 = heff_intLt(heff_get(heff_dup(v_c_24140), LBL_prec), MK_INT(2LL));
        V v_t_24142;
        switch (heff_tag_of(v_t_24141)) {
        case TAG_True: {
          v_t_24142 = heff_strAppend(((V)&g_heff_2eemit_2econdCode_str89), heff_strAppend(heff_get(v_c_24140, LBL_code), ((V)&g_heff_2eemit_2econdCode_str90)));
          break;
        }
        case TAG_False: {
          v_t_24142 = heff_get(v_c_24140, LBL_code);
          break;
        }
        default: heff_nomatch(v_t_24141);
        }
        V v_t_24143 = heff_strAppend(v_t_24139, heff_strAppend(((V)&g_heff_2eemit_2econdCode_str91), v_t_24142));
        return heff_rec(2, shape_47_252, (V[]){v_t_24143, MK_INT(2LL)});
      }
      case TAG_PRel: {
        V v_c_24145 = (g_heff_2eemit_2econdCode(v_c_246));
        V v_t_24146 = heff_intLt(heff_get(heff_dup(v_c_24145), LBL_prec), MK_INT(1LL));
        V v_t_24147;
        switch (heff_tag_of(v_t_24146)) {
        case TAG_True: {
          v_t_24147 = heff_strAppend(((V)&g_heff_2eemit_2econdCode_str92), heff_strAppend(heff_get(v_c_24145, LBL_code), ((V)&g_heff_2eemit_2econdCode_str93)));
          break;
        }
        case TAG_False: {
          v_t_24147 = heff_get(v_c_24145, LBL_code);
          break;
        }
        default: heff_nomatch(v_t_24146);
        }
        V v_c_24148 = (g_heff_2eemit_2econdCode(v_t_247));
        V v_t_24149 = heff_intLt(heff_get(heff_dup(v_c_24148), LBL_prec), MK_INT(0LL));
        V v_t_24150;
        switch (heff_tag_of(v_t_24149)) {
        case TAG_True: {
          v_t_24150 = heff_strAppend(((V)&g_heff_2eemit_2econdCode_str94), heff_strAppend(heff_get(v_c_24148, LBL_code), ((V)&g_heff_2eemit_2econdCode_str95)));
          break;
        }
        case TAG_False: {
          v_t_24150 = heff_get(v_c_24148, LBL_code);
          break;
        }
        default: heff_nomatch(v_t_24149);
        }
        V v_c_24151 = (g_heff_2eemit_2econdCode(v_it3_248));
        V v_t_24152 = heff_intLt(heff_get(heff_dup(v_c_24151), LBL_prec), MK_INT(0LL));
        V v_t_24153;
        switch (heff_tag_of(v_t_24152)) {
        case TAG_True: {
          v_t_24153 = heff_strAppend(((V)&g_heff_2eemit_2econdCode_str96), heff_strAppend(heff_get(v_c_24151, LBL_code), ((V)&g_heff_2eemit_2econdCode_str97)));
          break;
        }
        case TAG_False: {
          v_t_24153 = heff_get(v_c_24151, LBL_code);
          break;
        }
        default: heff_nomatch(v_t_24152);
        }
        V v_t_24154 = heff_strAppend(v_t_24147, heff_strAppend(((V)&g_heff_2eemit_2econdCode_str98), heff_strAppend(v_t_24150, heff_strAppend(((V)&g_heff_2eemit_2econdCode_str99), v_t_24153))));
        return heff_rec(2, shape_47_252, (V[]){v_t_24154, MK_INT(0LL)});
      }
      case TAG_PNot: {
        V v_c_24156 = (g_heff_2eemit_2econdCode(v_c_246));
        V v_t_24157 = heff_intLt(heff_get(heff_dup(v_c_24156), LBL_prec), MK_INT(1LL));
        V v_t_24158;
        switch (heff_tag_of(v_t_24157)) {
        case TAG_True: {
          v_t_24158 = heff_strAppend(((V)&g_heff_2eemit_2econdCode_str100), heff_strAppend(heff_get(v_c_24156, LBL_code), ((V)&g_heff_2eemit_2econdCode_str101)));
          break;
        }
        case TAG_False: {
          v_t_24158 = heff_get(v_c_24156, LBL_code);
          break;
        }
        default: heff_nomatch(v_t_24157);
        }
        V v_c_24159 = (g_heff_2eemit_2econdCode(v_t_247));
        V v_t_24160 = heff_intLt(heff_get(heff_dup(v_c_24159), LBL_prec), MK_INT(0LL));
        V v_t_24161;
        switch (heff_tag_of(v_t_24160)) {
        case TAG_True: {
          v_t_24161 = heff_strAppend(((V)&g_heff_2eemit_2econdCode_str102), heff_strAppend(heff_get(v_c_24159, LBL_code), ((V)&g_heff_2eemit_2econdCode_str103)));
          break;
        }
        case TAG_False: {
          v_t_24161 = heff_get(v_c_24159, LBL_code);
          break;
        }
        default: heff_nomatch(v_t_24160);
        }
        V v_c_24162 = (g_heff_2eemit_2econdCode(v_it3_248));
        V v_t_24163 = heff_intLt(heff_get(heff_dup(v_c_24162), LBL_prec), MK_INT(0LL));
        V v_t_24164;
        switch (heff_tag_of(v_t_24163)) {
        case TAG_True: {
          v_t_24164 = heff_strAppend(((V)&g_heff_2eemit_2econdCode_str104), heff_strAppend(heff_get(v_c_24162, LBL_code), ((V)&g_heff_2eemit_2econdCode_str105)));
          break;
        }
        case TAG_False: {
          v_t_24164 = heff_get(v_c_24162, LBL_code);
          break;
        }
        default: heff_nomatch(v_t_24163);
        }
        V v_t_24165 = heff_strAppend(v_t_24158, heff_strAppend(((V)&g_heff_2eemit_2econdCode_str106), heff_strAppend(v_t_24161, heff_strAppend(((V)&g_heff_2eemit_2econdCode_str107), v_t_24164))));
        return heff_rec(2, shape_47_252, (V[]){v_t_24165, MK_INT(0LL)});
      }
      case TAG_PIf: {
        V v_c_24169 = (g_heff_2eemit_2econdCode(v_c_246));
        V v_t_24170 = heff_intLt(heff_get(heff_dup(v_c_24169), LBL_prec), MK_INT(1LL));
        V v_t_24171;
        switch (heff_tag_of(v_t_24170)) {
        case TAG_True: {
          v_t_24171 = heff_strAppend(((V)&g_heff_2eemit_2econdCode_str108), heff_strAppend(heff_get(v_c_24169, LBL_code), ((V)&g_heff_2eemit_2econdCode_str109)));
          break;
        }
        case TAG_False: {
          v_t_24171 = heff_get(v_c_24169, LBL_code);
          break;
        }
        default: heff_nomatch(v_t_24170);
        }
        V v_c_24172 = (g_heff_2eemit_2econdCode(v_t_247));
        V v_t_24173 = heff_intLt(heff_get(heff_dup(v_c_24172), LBL_prec), MK_INT(0LL));
        V v_t_24174;
        switch (heff_tag_of(v_t_24173)) {
        case TAG_True: {
          v_t_24174 = heff_strAppend(((V)&g_heff_2eemit_2econdCode_str110), heff_strAppend(heff_get(v_c_24172, LBL_code), ((V)&g_heff_2eemit_2econdCode_str111)));
          break;
        }
        case TAG_False: {
          v_t_24174 = heff_get(v_c_24172, LBL_code);
          break;
        }
        default: heff_nomatch(v_t_24173);
        }
        V v_c_24175 = (g_heff_2eemit_2econdCode(v_it3_248));
        V v_t_24176 = heff_intLt(heff_get(heff_dup(v_c_24175), LBL_prec), MK_INT(0LL));
        V v_t_24177;
        switch (heff_tag_of(v_t_24176)) {
        case TAG_True: {
          v_t_24177 = heff_strAppend(((V)&g_heff_2eemit_2econdCode_str112), heff_strAppend(heff_get(v_c_24175, LBL_code), ((V)&g_heff_2eemit_2econdCode_str113)));
          break;
        }
        case TAG_False: {
          v_t_24177 = heff_get(v_c_24175, LBL_code);
          break;
        }
        default: heff_nomatch(v_t_24176);
        }
        V v_t_24178 = heff_strAppend(v_t_24171, heff_strAppend(((V)&g_heff_2eemit_2econdCode_str114), heff_strAppend(v_t_24174, heff_strAppend(((V)&g_heff_2eemit_2econdCode_str115), v_t_24177))));
        return heff_rec(2, shape_47_252, (V[]){v_t_24178, MK_INT(0LL)});
      }
      case TAG_PSeq: {
        V v_c_24182 = (g_heff_2eemit_2econdCode(v_c_246));
        V v_t_24183 = heff_intLt(heff_get(heff_dup(v_c_24182), LBL_prec), MK_INT(1LL));
        V v_t_24184;
        switch (heff_tag_of(v_t_24183)) {
        case TAG_True: {
          v_t_24184 = heff_strAppend(((V)&g_heff_2eemit_2econdCode_str116), heff_strAppend(heff_get(v_c_24182, LBL_code), ((V)&g_heff_2eemit_2econdCode_str117)));
          break;
        }
        case TAG_False: {
          v_t_24184 = heff_get(v_c_24182, LBL_code);
          break;
        }
        default: heff_nomatch(v_t_24183);
        }
        V v_c_24185 = (g_heff_2eemit_2econdCode(v_t_247));
        V v_t_24186 = heff_intLt(heff_get(heff_dup(v_c_24185), LBL_prec), MK_INT(0LL));
        V v_t_24187;
        switch (heff_tag_of(v_t_24186)) {
        case TAG_True: {
          v_t_24187 = heff_strAppend(((V)&g_heff_2eemit_2econdCode_str118), heff_strAppend(heff_get(v_c_24185, LBL_code), ((V)&g_heff_2eemit_2econdCode_str119)));
          break;
        }
        case TAG_False: {
          v_t_24187 = heff_get(v_c_24185, LBL_code);
          break;
        }
        default: heff_nomatch(v_t_24186);
        }
        V v_c_24188 = (g_heff_2eemit_2econdCode(v_it3_248));
        V v_t_24189 = heff_intLt(heff_get(heff_dup(v_c_24188), LBL_prec), MK_INT(0LL));
        V v_t_24190;
        switch (heff_tag_of(v_t_24189)) {
        case TAG_True: {
          v_t_24190 = heff_strAppend(((V)&g_heff_2eemit_2econdCode_str120), heff_strAppend(heff_get(v_c_24188, LBL_code), ((V)&g_heff_2eemit_2econdCode_str121)));
          break;
        }
        case TAG_False: {
          v_t_24190 = heff_get(v_c_24188, LBL_code);
          break;
        }
        default: heff_nomatch(v_t_24189);
        }
        V v_t_24191 = heff_strAppend(v_t_24184, heff_strAppend(((V)&g_heff_2eemit_2econdCode_str122), heff_strAppend(v_t_24187, heff_strAppend(((V)&g_heff_2eemit_2econdCode_str123), v_t_24190))));
        return heff_rec(2, shape_47_252, (V[]){v_t_24191, MK_INT(0LL)});
      }
      default: return heff_nomatch(v_t_247);
      }
    }
    case TAG_PIf: {
      switch (heff_tag_of(v_t_247)) {
      case TAG_PTrue: {
        V v_c_24195 = (g_heff_2eemit_2econdCode(v_c_246));
        V v_t_24196 = heff_intLt(heff_get(heff_dup(v_c_24195), LBL_prec), MK_INT(1LL));
        V v_t_24197;
        switch (heff_tag_of(v_t_24196)) {
        case TAG_True: {
          v_t_24197 = heff_strAppend(((V)&g_heff_2eemit_2econdCode_str124), heff_strAppend(heff_get(v_c_24195, LBL_code), ((V)&g_heff_2eemit_2econdCode_str125)));
          break;
        }
        case TAG_False: {
          v_t_24197 = heff_get(v_c_24195, LBL_code);
          break;
        }
        default: heff_nomatch(v_t_24196);
        }
        V v_c_24198 = (g_heff_2eemit_2econdCode(v_it3_248));
        V v_t_24199 = heff_intLt(heff_get(heff_dup(v_c_24198), LBL_prec), MK_INT(1LL));
        V v_t_24200;
        switch (heff_tag_of(v_t_24199)) {
        case TAG_True: {
          v_t_24200 = heff_strAppend(((V)&g_heff_2eemit_2econdCode_str126), heff_strAppend(heff_get(v_c_24198, LBL_code), ((V)&g_heff_2eemit_2econdCode_str127)));
          break;
        }
        case TAG_False: {
          v_t_24200 = heff_get(v_c_24198, LBL_code);
          break;
        }
        default: heff_nomatch(v_t_24199);
        }
        V v_t_24201 = heff_strAppend(v_t_24197, heff_strAppend(((V)&g_heff_2eemit_2econdCode_str128), v_t_24200));
        return heff_rec(2, shape_47_252, (V[]){v_t_24201, MK_INT(1LL)});
      }
      case TAG_PFalse: {
        V v_c_24202 = (g_heff_2eemit_2econdCode(heff_tag(TAG_PNot, 1, (V[]){v_c_246})));
        V v_t_24203 = heff_intLt(heff_get(heff_dup(v_c_24202), LBL_prec), MK_INT(2LL));
        V v_t_24204;
        switch (heff_tag_of(v_t_24203)) {
        case TAG_True: {
          v_t_24204 = heff_strAppend(((V)&g_heff_2eemit_2econdCode_str129), heff_strAppend(heff_get(v_c_24202, LBL_code), ((V)&g_heff_2eemit_2econdCode_str130)));
          break;
        }
        case TAG_False: {
          v_t_24204 = heff_get(v_c_24202, LBL_code);
          break;
        }
        default: heff_nomatch(v_t_24203);
        }
        V v_c_24205 = (g_heff_2eemit_2econdCode(v_it3_248));
        V v_t_24206 = heff_intLt(heff_get(heff_dup(v_c_24205), LBL_prec), MK_INT(2LL));
        V v_t_24207;
        switch (heff_tag_of(v_t_24206)) {
        case TAG_True: {
          v_t_24207 = heff_strAppend(((V)&g_heff_2eemit_2econdCode_str131), heff_strAppend(heff_get(v_c_24205, LBL_code), ((V)&g_heff_2eemit_2econdCode_str132)));
          break;
        }
        case TAG_False: {
          v_t_24207 = heff_get(v_c_24205, LBL_code);
          break;
        }
        default: heff_nomatch(v_t_24206);
        }
        V v_t_24208 = heff_strAppend(v_t_24204, heff_strAppend(((V)&g_heff_2eemit_2econdCode_str133), v_t_24207));
        return heff_rec(2, shape_47_252, (V[]){v_t_24208, MK_INT(2LL)});
      }
      case TAG_PRel: {
        V v_c_24210 = (g_heff_2eemit_2econdCode(v_c_246));
        V v_t_24211 = heff_intLt(heff_get(heff_dup(v_c_24210), LBL_prec), MK_INT(1LL));
        V v_t_24212;
        switch (heff_tag_of(v_t_24211)) {
        case TAG_True: {
          v_t_24212 = heff_strAppend(((V)&g_heff_2eemit_2econdCode_str134), heff_strAppend(heff_get(v_c_24210, LBL_code), ((V)&g_heff_2eemit_2econdCode_str135)));
          break;
        }
        case TAG_False: {
          v_t_24212 = heff_get(v_c_24210, LBL_code);
          break;
        }
        default: heff_nomatch(v_t_24211);
        }
        V v_c_24213 = (g_heff_2eemit_2econdCode(v_t_247));
        V v_t_24214 = heff_intLt(heff_get(heff_dup(v_c_24213), LBL_prec), MK_INT(0LL));
        V v_t_24215;
        switch (heff_tag_of(v_t_24214)) {
        case TAG_True: {
          v_t_24215 = heff_strAppend(((V)&g_heff_2eemit_2econdCode_str136), heff_strAppend(heff_get(v_c_24213, LBL_code), ((V)&g_heff_2eemit_2econdCode_str137)));
          break;
        }
        case TAG_False: {
          v_t_24215 = heff_get(v_c_24213, LBL_code);
          break;
        }
        default: heff_nomatch(v_t_24214);
        }
        V v_c_24216 = (g_heff_2eemit_2econdCode(v_it3_248));
        V v_t_24217 = heff_intLt(heff_get(heff_dup(v_c_24216), LBL_prec), MK_INT(0LL));
        V v_t_24218;
        switch (heff_tag_of(v_t_24217)) {
        case TAG_True: {
          v_t_24218 = heff_strAppend(((V)&g_heff_2eemit_2econdCode_str138), heff_strAppend(heff_get(v_c_24216, LBL_code), ((V)&g_heff_2eemit_2econdCode_str139)));
          break;
        }
        case TAG_False: {
          v_t_24218 = heff_get(v_c_24216, LBL_code);
          break;
        }
        default: heff_nomatch(v_t_24217);
        }
        V v_t_24219 = heff_strAppend(v_t_24212, heff_strAppend(((V)&g_heff_2eemit_2econdCode_str140), heff_strAppend(v_t_24215, heff_strAppend(((V)&g_heff_2eemit_2econdCode_str141), v_t_24218))));
        return heff_rec(2, shape_47_252, (V[]){v_t_24219, MK_INT(0LL)});
      }
      case TAG_PNot: {
        V v_c_24221 = (g_heff_2eemit_2econdCode(v_c_246));
        V v_t_24222 = heff_intLt(heff_get(heff_dup(v_c_24221), LBL_prec), MK_INT(1LL));
        V v_t_24223;
        switch (heff_tag_of(v_t_24222)) {
        case TAG_True: {
          v_t_24223 = heff_strAppend(((V)&g_heff_2eemit_2econdCode_str142), heff_strAppend(heff_get(v_c_24221, LBL_code), ((V)&g_heff_2eemit_2econdCode_str143)));
          break;
        }
        case TAG_False: {
          v_t_24223 = heff_get(v_c_24221, LBL_code);
          break;
        }
        default: heff_nomatch(v_t_24222);
        }
        V v_c_24224 = (g_heff_2eemit_2econdCode(v_t_247));
        V v_t_24225 = heff_intLt(heff_get(heff_dup(v_c_24224), LBL_prec), MK_INT(0LL));
        V v_t_24226;
        switch (heff_tag_of(v_t_24225)) {
        case TAG_True: {
          v_t_24226 = heff_strAppend(((V)&g_heff_2eemit_2econdCode_str144), heff_strAppend(heff_get(v_c_24224, LBL_code), ((V)&g_heff_2eemit_2econdCode_str145)));
          break;
        }
        case TAG_False: {
          v_t_24226 = heff_get(v_c_24224, LBL_code);
          break;
        }
        default: heff_nomatch(v_t_24225);
        }
        V v_c_24227 = (g_heff_2eemit_2econdCode(v_it3_248));
        V v_t_24228 = heff_intLt(heff_get(heff_dup(v_c_24227), LBL_prec), MK_INT(0LL));
        V v_t_24229;
        switch (heff_tag_of(v_t_24228)) {
        case TAG_True: {
          v_t_24229 = heff_strAppend(((V)&g_heff_2eemit_2econdCode_str146), heff_strAppend(heff_get(v_c_24227, LBL_code), ((V)&g_heff_2eemit_2econdCode_str147)));
          break;
        }
        case TAG_False: {
          v_t_24229 = heff_get(v_c_24227, LBL_code);
          break;
        }
        default: heff_nomatch(v_t_24228);
        }
        V v_t_24230 = heff_strAppend(v_t_24223, heff_strAppend(((V)&g_heff_2eemit_2econdCode_str148), heff_strAppend(v_t_24226, heff_strAppend(((V)&g_heff_2eemit_2econdCode_str149), v_t_24229))));
        return heff_rec(2, shape_47_252, (V[]){v_t_24230, MK_INT(0LL)});
      }
      case TAG_PIf: {
        V v_c_24234 = (g_heff_2eemit_2econdCode(v_c_246));
        V v_t_24235 = heff_intLt(heff_get(heff_dup(v_c_24234), LBL_prec), MK_INT(1LL));
        V v_t_24236;
        switch (heff_tag_of(v_t_24235)) {
        case TAG_True: {
          v_t_24236 = heff_strAppend(((V)&g_heff_2eemit_2econdCode_str150), heff_strAppend(heff_get(v_c_24234, LBL_code), ((V)&g_heff_2eemit_2econdCode_str151)));
          break;
        }
        case TAG_False: {
          v_t_24236 = heff_get(v_c_24234, LBL_code);
          break;
        }
        default: heff_nomatch(v_t_24235);
        }
        V v_c_24237 = (g_heff_2eemit_2econdCode(v_t_247));
        V v_t_24238 = heff_intLt(heff_get(heff_dup(v_c_24237), LBL_prec), MK_INT(0LL));
        V v_t_24239;
        switch (heff_tag_of(v_t_24238)) {
        case TAG_True: {
          v_t_24239 = heff_strAppend(((V)&g_heff_2eemit_2econdCode_str152), heff_strAppend(heff_get(v_c_24237, LBL_code), ((V)&g_heff_2eemit_2econdCode_str153)));
          break;
        }
        case TAG_False: {
          v_t_24239 = heff_get(v_c_24237, LBL_code);
          break;
        }
        default: heff_nomatch(v_t_24238);
        }
        V v_c_24240 = (g_heff_2eemit_2econdCode(v_it3_248));
        V v_t_24241 = heff_intLt(heff_get(heff_dup(v_c_24240), LBL_prec), MK_INT(0LL));
        V v_t_24242;
        switch (heff_tag_of(v_t_24241)) {
        case TAG_True: {
          v_t_24242 = heff_strAppend(((V)&g_heff_2eemit_2econdCode_str154), heff_strAppend(heff_get(v_c_24240, LBL_code), ((V)&g_heff_2eemit_2econdCode_str155)));
          break;
        }
        case TAG_False: {
          v_t_24242 = heff_get(v_c_24240, LBL_code);
          break;
        }
        default: heff_nomatch(v_t_24241);
        }
        V v_t_24243 = heff_strAppend(v_t_24236, heff_strAppend(((V)&g_heff_2eemit_2econdCode_str156), heff_strAppend(v_t_24239, heff_strAppend(((V)&g_heff_2eemit_2econdCode_str157), v_t_24242))));
        return heff_rec(2, shape_47_252, (V[]){v_t_24243, MK_INT(0LL)});
      }
      case TAG_PSeq: {
        V v_c_24247 = (g_heff_2eemit_2econdCode(v_c_246));
        V v_t_24248 = heff_intLt(heff_get(heff_dup(v_c_24247), LBL_prec), MK_INT(1LL));
        V v_t_24249;
        switch (heff_tag_of(v_t_24248)) {
        case TAG_True: {
          v_t_24249 = heff_strAppend(((V)&g_heff_2eemit_2econdCode_str158), heff_strAppend(heff_get(v_c_24247, LBL_code), ((V)&g_heff_2eemit_2econdCode_str159)));
          break;
        }
        case TAG_False: {
          v_t_24249 = heff_get(v_c_24247, LBL_code);
          break;
        }
        default: heff_nomatch(v_t_24248);
        }
        V v_c_24250 = (g_heff_2eemit_2econdCode(v_t_247));
        V v_t_24251 = heff_intLt(heff_get(heff_dup(v_c_24250), LBL_prec), MK_INT(0LL));
        V v_t_24252;
        switch (heff_tag_of(v_t_24251)) {
        case TAG_True: {
          v_t_24252 = heff_strAppend(((V)&g_heff_2eemit_2econdCode_str160), heff_strAppend(heff_get(v_c_24250, LBL_code), ((V)&g_heff_2eemit_2econdCode_str161)));
          break;
        }
        case TAG_False: {
          v_t_24252 = heff_get(v_c_24250, LBL_code);
          break;
        }
        default: heff_nomatch(v_t_24251);
        }
        V v_c_24253 = (g_heff_2eemit_2econdCode(v_it3_248));
        V v_t_24254 = heff_intLt(heff_get(heff_dup(v_c_24253), LBL_prec), MK_INT(0LL));
        V v_t_24255;
        switch (heff_tag_of(v_t_24254)) {
        case TAG_True: {
          v_t_24255 = heff_strAppend(((V)&g_heff_2eemit_2econdCode_str162), heff_strAppend(heff_get(v_c_24253, LBL_code), ((V)&g_heff_2eemit_2econdCode_str163)));
          break;
        }
        case TAG_False: {
          v_t_24255 = heff_get(v_c_24253, LBL_code);
          break;
        }
        default: heff_nomatch(v_t_24254);
        }
        V v_t_24256 = heff_strAppend(v_t_24249, heff_strAppend(((V)&g_heff_2eemit_2econdCode_str164), heff_strAppend(v_t_24252, heff_strAppend(((V)&g_heff_2eemit_2econdCode_str165), v_t_24255))));
        return heff_rec(2, shape_47_252, (V[]){v_t_24256, MK_INT(0LL)});
      }
      default: return heff_nomatch(v_t_247);
      }
    }
    case TAG_PSeq: {
      switch (heff_tag_of(v_t_247)) {
      case TAG_PTrue: {
        V v_c_24260 = (g_heff_2eemit_2econdCode(v_c_246));
        V v_t_24261 = heff_intLt(heff_get(heff_dup(v_c_24260), LBL_prec), MK_INT(1LL));
        V v_t_24262;
        switch (heff_tag_of(v_t_24261)) {
        case TAG_True: {
          v_t_24262 = heff_strAppend(((V)&g_heff_2eemit_2econdCode_str166), heff_strAppend(heff_get(v_c_24260, LBL_code), ((V)&g_heff_2eemit_2econdCode_str167)));
          break;
        }
        case TAG_False: {
          v_t_24262 = heff_get(v_c_24260, LBL_code);
          break;
        }
        default: heff_nomatch(v_t_24261);
        }
        V v_c_24263 = (g_heff_2eemit_2econdCode(v_it3_248));
        V v_t_24264 = heff_intLt(heff_get(heff_dup(v_c_24263), LBL_prec), MK_INT(1LL));
        V v_t_24265;
        switch (heff_tag_of(v_t_24264)) {
        case TAG_True: {
          v_t_24265 = heff_strAppend(((V)&g_heff_2eemit_2econdCode_str168), heff_strAppend(heff_get(v_c_24263, LBL_code), ((V)&g_heff_2eemit_2econdCode_str169)));
          break;
        }
        case TAG_False: {
          v_t_24265 = heff_get(v_c_24263, LBL_code);
          break;
        }
        default: heff_nomatch(v_t_24264);
        }
        V v_t_24266 = heff_strAppend(v_t_24262, heff_strAppend(((V)&g_heff_2eemit_2econdCode_str170), v_t_24265));
        return heff_rec(2, shape_47_252, (V[]){v_t_24266, MK_INT(1LL)});
      }
      case TAG_PFalse: {
        V v_c_24267 = (g_heff_2eemit_2econdCode(heff_tag(TAG_PNot, 1, (V[]){v_c_246})));
        V v_t_24268 = heff_intLt(heff_get(heff_dup(v_c_24267), LBL_prec), MK_INT(2LL));
        V v_t_24269;
        switch (heff_tag_of(v_t_24268)) {
        case TAG_True: {
          v_t_24269 = heff_strAppend(((V)&g_heff_2eemit_2econdCode_str171), heff_strAppend(heff_get(v_c_24267, LBL_code), ((V)&g_heff_2eemit_2econdCode_str172)));
          break;
        }
        case TAG_False: {
          v_t_24269 = heff_get(v_c_24267, LBL_code);
          break;
        }
        default: heff_nomatch(v_t_24268);
        }
        V v_c_24270 = (g_heff_2eemit_2econdCode(v_it3_248));
        V v_t_24271 = heff_intLt(heff_get(heff_dup(v_c_24270), LBL_prec), MK_INT(2LL));
        V v_t_24272;
        switch (heff_tag_of(v_t_24271)) {
        case TAG_True: {
          v_t_24272 = heff_strAppend(((V)&g_heff_2eemit_2econdCode_str173), heff_strAppend(heff_get(v_c_24270, LBL_code), ((V)&g_heff_2eemit_2econdCode_str174)));
          break;
        }
        case TAG_False: {
          v_t_24272 = heff_get(v_c_24270, LBL_code);
          break;
        }
        default: heff_nomatch(v_t_24271);
        }
        V v_t_24273 = heff_strAppend(v_t_24269, heff_strAppend(((V)&g_heff_2eemit_2econdCode_str175), v_t_24272));
        return heff_rec(2, shape_47_252, (V[]){v_t_24273, MK_INT(2LL)});
      }
      case TAG_PRel: {
        V v_c_24275 = (g_heff_2eemit_2econdCode(v_c_246));
        V v_t_24276 = heff_intLt(heff_get(heff_dup(v_c_24275), LBL_prec), MK_INT(1LL));
        V v_t_24277;
        switch (heff_tag_of(v_t_24276)) {
        case TAG_True: {
          v_t_24277 = heff_strAppend(((V)&g_heff_2eemit_2econdCode_str176), heff_strAppend(heff_get(v_c_24275, LBL_code), ((V)&g_heff_2eemit_2econdCode_str177)));
          break;
        }
        case TAG_False: {
          v_t_24277 = heff_get(v_c_24275, LBL_code);
          break;
        }
        default: heff_nomatch(v_t_24276);
        }
        V v_c_24278 = (g_heff_2eemit_2econdCode(v_t_247));
        V v_t_24279 = heff_intLt(heff_get(heff_dup(v_c_24278), LBL_prec), MK_INT(0LL));
        V v_t_24280;
        switch (heff_tag_of(v_t_24279)) {
        case TAG_True: {
          v_t_24280 = heff_strAppend(((V)&g_heff_2eemit_2econdCode_str178), heff_strAppend(heff_get(v_c_24278, LBL_code), ((V)&g_heff_2eemit_2econdCode_str179)));
          break;
        }
        case TAG_False: {
          v_t_24280 = heff_get(v_c_24278, LBL_code);
          break;
        }
        default: heff_nomatch(v_t_24279);
        }
        V v_c_24281 = (g_heff_2eemit_2econdCode(v_it3_248));
        V v_t_24282 = heff_intLt(heff_get(heff_dup(v_c_24281), LBL_prec), MK_INT(0LL));
        V v_t_24283;
        switch (heff_tag_of(v_t_24282)) {
        case TAG_True: {
          v_t_24283 = heff_strAppend(((V)&g_heff_2eemit_2econdCode_str180), heff_strAppend(heff_get(v_c_24281, LBL_code), ((V)&g_heff_2eemit_2econdCode_str181)));
          break;
        }
        case TAG_False: {
          v_t_24283 = heff_get(v_c_24281, LBL_code);
          break;
        }
        default: heff_nomatch(v_t_24282);
        }
        V v_t_24284 = heff_strAppend(v_t_24277, heff_strAppend(((V)&g_heff_2eemit_2econdCode_str182), heff_strAppend(v_t_24280, heff_strAppend(((V)&g_heff_2eemit_2econdCode_str183), v_t_24283))));
        return heff_rec(2, shape_47_252, (V[]){v_t_24284, MK_INT(0LL)});
      }
      case TAG_PNot: {
        V v_c_24286 = (g_heff_2eemit_2econdCode(v_c_246));
        V v_t_24287 = heff_intLt(heff_get(heff_dup(v_c_24286), LBL_prec), MK_INT(1LL));
        V v_t_24288;
        switch (heff_tag_of(v_t_24287)) {
        case TAG_True: {
          v_t_24288 = heff_strAppend(((V)&g_heff_2eemit_2econdCode_str184), heff_strAppend(heff_get(v_c_24286, LBL_code), ((V)&g_heff_2eemit_2econdCode_str185)));
          break;
        }
        case TAG_False: {
          v_t_24288 = heff_get(v_c_24286, LBL_code);
          break;
        }
        default: heff_nomatch(v_t_24287);
        }
        V v_c_24289 = (g_heff_2eemit_2econdCode(v_t_247));
        V v_t_24290 = heff_intLt(heff_get(heff_dup(v_c_24289), LBL_prec), MK_INT(0LL));
        V v_t_24291;
        switch (heff_tag_of(v_t_24290)) {
        case TAG_True: {
          v_t_24291 = heff_strAppend(((V)&g_heff_2eemit_2econdCode_str186), heff_strAppend(heff_get(v_c_24289, LBL_code), ((V)&g_heff_2eemit_2econdCode_str187)));
          break;
        }
        case TAG_False: {
          v_t_24291 = heff_get(v_c_24289, LBL_code);
          break;
        }
        default: heff_nomatch(v_t_24290);
        }
        V v_c_24292 = (g_heff_2eemit_2econdCode(v_it3_248));
        V v_t_24293 = heff_intLt(heff_get(heff_dup(v_c_24292), LBL_prec), MK_INT(0LL));
        V v_t_24294;
        switch (heff_tag_of(v_t_24293)) {
        case TAG_True: {
          v_t_24294 = heff_strAppend(((V)&g_heff_2eemit_2econdCode_str188), heff_strAppend(heff_get(v_c_24292, LBL_code), ((V)&g_heff_2eemit_2econdCode_str189)));
          break;
        }
        case TAG_False: {
          v_t_24294 = heff_get(v_c_24292, LBL_code);
          break;
        }
        default: heff_nomatch(v_t_24293);
        }
        V v_t_24295 = heff_strAppend(v_t_24288, heff_strAppend(((V)&g_heff_2eemit_2econdCode_str190), heff_strAppend(v_t_24291, heff_strAppend(((V)&g_heff_2eemit_2econdCode_str191), v_t_24294))));
        return heff_rec(2, shape_47_252, (V[]){v_t_24295, MK_INT(0LL)});
      }
      case TAG_PIf: {
        V v_c_24299 = (g_heff_2eemit_2econdCode(v_c_246));
        V v_t_24300 = heff_intLt(heff_get(heff_dup(v_c_24299), LBL_prec), MK_INT(1LL));
        V v_t_24301;
        switch (heff_tag_of(v_t_24300)) {
        case TAG_True: {
          v_t_24301 = heff_strAppend(((V)&g_heff_2eemit_2econdCode_str192), heff_strAppend(heff_get(v_c_24299, LBL_code), ((V)&g_heff_2eemit_2econdCode_str193)));
          break;
        }
        case TAG_False: {
          v_t_24301 = heff_get(v_c_24299, LBL_code);
          break;
        }
        default: heff_nomatch(v_t_24300);
        }
        V v_c_24302 = (g_heff_2eemit_2econdCode(v_t_247));
        V v_t_24303 = heff_intLt(heff_get(heff_dup(v_c_24302), LBL_prec), MK_INT(0LL));
        V v_t_24304;
        switch (heff_tag_of(v_t_24303)) {
        case TAG_True: {
          v_t_24304 = heff_strAppend(((V)&g_heff_2eemit_2econdCode_str194), heff_strAppend(heff_get(v_c_24302, LBL_code), ((V)&g_heff_2eemit_2econdCode_str195)));
          break;
        }
        case TAG_False: {
          v_t_24304 = heff_get(v_c_24302, LBL_code);
          break;
        }
        default: heff_nomatch(v_t_24303);
        }
        V v_c_24305 = (g_heff_2eemit_2econdCode(v_it3_248));
        V v_t_24306 = heff_intLt(heff_get(heff_dup(v_c_24305), LBL_prec), MK_INT(0LL));
        V v_t_24307;
        switch (heff_tag_of(v_t_24306)) {
        case TAG_True: {
          v_t_24307 = heff_strAppend(((V)&g_heff_2eemit_2econdCode_str196), heff_strAppend(heff_get(v_c_24305, LBL_code), ((V)&g_heff_2eemit_2econdCode_str197)));
          break;
        }
        case TAG_False: {
          v_t_24307 = heff_get(v_c_24305, LBL_code);
          break;
        }
        default: heff_nomatch(v_t_24306);
        }
        V v_t_24308 = heff_strAppend(v_t_24301, heff_strAppend(((V)&g_heff_2eemit_2econdCode_str198), heff_strAppend(v_t_24304, heff_strAppend(((V)&g_heff_2eemit_2econdCode_str199), v_t_24307))));
        return heff_rec(2, shape_47_252, (V[]){v_t_24308, MK_INT(0LL)});
      }
      case TAG_PSeq: {
        V v_c_24312 = (g_heff_2eemit_2econdCode(v_c_246));
        V v_t_24313 = heff_intLt(heff_get(heff_dup(v_c_24312), LBL_prec), MK_INT(1LL));
        V v_t_24314;
        switch (heff_tag_of(v_t_24313)) {
        case TAG_True: {
          v_t_24314 = heff_strAppend(((V)&g_heff_2eemit_2econdCode_str200), heff_strAppend(heff_get(v_c_24312, LBL_code), ((V)&g_heff_2eemit_2econdCode_str201)));
          break;
        }
        case TAG_False: {
          v_t_24314 = heff_get(v_c_24312, LBL_code);
          break;
        }
        default: heff_nomatch(v_t_24313);
        }
        V v_c_24315 = (g_heff_2eemit_2econdCode(v_t_247));
        V v_t_24316 = heff_intLt(heff_get(heff_dup(v_c_24315), LBL_prec), MK_INT(0LL));
        V v_t_24317;
        switch (heff_tag_of(v_t_24316)) {
        case TAG_True: {
          v_t_24317 = heff_strAppend(((V)&g_heff_2eemit_2econdCode_str202), heff_strAppend(heff_get(v_c_24315, LBL_code), ((V)&g_heff_2eemit_2econdCode_str203)));
          break;
        }
        case TAG_False: {
          v_t_24317 = heff_get(v_c_24315, LBL_code);
          break;
        }
        default: heff_nomatch(v_t_24316);
        }
        V v_c_24318 = (g_heff_2eemit_2econdCode(v_it3_248));
        V v_t_24319 = heff_intLt(heff_get(heff_dup(v_c_24318), LBL_prec), MK_INT(0LL));
        V v_t_24320;
        switch (heff_tag_of(v_t_24319)) {
        case TAG_True: {
          v_t_24320 = heff_strAppend(((V)&g_heff_2eemit_2econdCode_str204), heff_strAppend(heff_get(v_c_24318, LBL_code), ((V)&g_heff_2eemit_2econdCode_str205)));
          break;
        }
        case TAG_False: {
          v_t_24320 = heff_get(v_c_24318, LBL_code);
          break;
        }
        default: heff_nomatch(v_t_24319);
        }
        V v_t_24321 = heff_strAppend(v_t_24314, heff_strAppend(((V)&g_heff_2eemit_2econdCode_str206), heff_strAppend(v_t_24317, heff_strAppend(((V)&g_heff_2eemit_2econdCode_str207), v_t_24320))));
        return heff_rec(2, shape_47_252, (V[]){v_t_24321, MK_INT(0LL)});
      }
      default: return heff_nomatch(v_t_247);
      }
    }
    default: return heff_nomatch(v_it3_248);
    }
  }
  case TAG_PSeq: {
    V v_x_24322 = heff_field(v_p_240, 0);
    V v_a_24323 = heff_field(v_p_240, 1);
    V v_q_24324 = heff_field(v_p_240, 2);
    heff_take_n(v_p_240, 7ULL, 3);
    V v_c_24325 = (g_heff_2eemit_2econdCode(v_q_24324));
    V v_t_24326 = heff_intLt(heff_get(heff_dup(v_c_24325), LBL_prec), MK_INT(1LL));
    V v_t_24327;
    switch (heff_tag_of(v_t_24326)) {
    case TAG_True: {
      v_t_24327 = heff_strAppend(((V)&g_heff_2eemit_2econdCode_str208), heff_strAppend(heff_get(v_c_24325, LBL_code), ((V)&g_heff_2eemit_2econdCode_str209)));
      break;
    }
    case TAG_False: {
      v_t_24327 = heff_get(v_c_24325, LBL_code);
      break;
    }
    default: heff_nomatch(v_t_24326);
    }
    V v_t_24328 = heff_strAppend(((V)&g_heff_2eemit_2econdCode_str210), heff_strAppend(v_x_24322, heff_strAppend(((V)&g_heff_2eemit_2econdCode_str211), heff_strAppend(v_a_24323, heff_strAppend(((V)&g_heff_2eemit_2econdCode_str212), heff_strAppend(v_t_24327, ((V)&g_heff_2eemit_2econdCode_str213)))))));
    return heff_rec(2, shape_47_252, (V[]){v_t_24328, MK_INT(4LL)});
  }
  default: return heff_nomatch(v_p_240);
  }
}
V g_heff_2eemit_2econdCode_entry(V self, V *a) {
  (void)self;
  return g_heff_2eemit_2econdCode(a[0]);
}
Clo g_heff_2eemit_2eseqsOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemit_2eseqsOf_entry, 1, 0};

V g_heff_2eemit_2eseqsOf(V v_p_240) {
top: ;
  switch (heff_tag_of(v_p_240)) {
  case TAG_PTrue: {
    return NTAG(TAG_Nil);
  }
  case TAG_PFalse: {
    return NTAG(TAG_Nil);
  }
  case TAG_PRel: {
    return NTAG(TAG_Nil);
  }
  case TAG_PNot: {
    V v_q_242 = heff_field(v_p_240, 0);
    V t_0 = v_q_242;
    v_p_240 = t_0;
    goto top;
  }
  case TAG_PIf: {
    V v_c_243 = heff_field(v_p_240, 0);
    V v_t_244 = heff_field(v_p_240, 1);
    V v_e_245 = heff_field(v_p_240, 2);
    V v_t_246 = (g_heff_2eemit_2eseqsOf(v_c_243));
    V v_t_247 = (g_heff_2eemit_2eseqsOf(v_t_244));
    V v_t_248 = (g_heff_2eemit_2eseqsOf(v_e_245));
    V v_t_249 = (g_prelude_2econcatList(v_t_247, v_t_248));
    return (g_prelude_2econcatList(v_t_246, v_t_249));
  }
  case TAG_PSeq: {
    V v_x_2410 = heff_field(v_p_240, 0);
    V v_q_2412 = heff_field(v_p_240, 2);
    return heff_tag(TAG_Cons, 2, (V[]){heff_dup(v_x_2410), (g_heff_2eemit_2eseqsOf(v_q_2412))});
  }
  default: return heff_nomatch(v_p_240);
  }
}
V g_heff_2eemit_2eseqsOf_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eemit_2eseqsOf(a[0]); heff_drop(a[0]); return r;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemit_2eletDeclarations_str0 = {{0x80000000u, K_STR, 0}, 2, 2, {32, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2eletDeclarations_str1 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2eletDeclarations_str2 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eemit_2eletDeclarations_str3 = {{0x80000000u, K_STR, 0}, 4, 4, {108, 101, 116, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2eletDeclarations_str4 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
Clo g_heff_2eemit_2eletDeclarations_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemit_2eletDeclarations_entry, 2, 0};

V g_heff_2eemit_2eletDeclarations(V v_ind_240, V v_xs_241) {
top: ;
  switch (heff_tag_of(v_xs_241)) {
  case TAG_Nil: {
    heff_drop(v_ind_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x2_244 = (g_prelude_2ereplicate(v_ind_240, ((V)&g_heff_2eemit_2eletDeclarations_str0)));
    V v_t_247;
    switch (heff_tag_of(v_x2_244)) {
    case TAG_Nil: {
      v_t_247 = ((V)&g_heff_2eemit_2eletDeclarations_str1);
      break;
    }
    case TAG_Cons: {
      V v_x_245 = heff_field(v_x2_244, 0);
      V v_xs_246 = heff_field(v_x2_244, 1);
      heff_take_n(v_x2_244, 3ULL, 2);
      v_t_247 = ({ V a_0 = v_x_245; V a_1 = v_xs_246; V r_ = (g_prelude_2efoldl_24s46(a_0, a_1)); heff_drop(v_xs_246); r_; });
      break;
    }
    default: heff_nomatch(v_x2_244);
    }
    V v_x2_248 = (g_heff_2eemit_2enubGo(NTAG(TAG_Nil), v_xs_241));
    V v_t_2411;
    switch (heff_tag_of(v_x2_248)) {
    case TAG_Nil: {
      v_t_2411 = ((V)&g_heff_2eemit_2eletDeclarations_str2);
      break;
    }
    case TAG_Cons: {
      V v_x_249 = heff_field(v_x2_248, 0);
      V v_xs_2410 = heff_field(v_x2_248, 1);
      heff_take_n(v_x2_248, 3ULL, 2);
      v_t_2411 = ({ V a_0 = v_x_249; V a_1 = v_xs_2410; V r_ = (g_prelude_2efoldl_24s45(a_0, a_1)); heff_drop(v_xs_2410); r_; });
      break;
    }
    default: heff_nomatch(v_x2_248);
    }
    V v_t_2412 = heff_strAppend(v_t_247, heff_strAppend(((V)&g_heff_2eemit_2eletDeclarations_str3), heff_strAppend(v_t_2411, ((V)&g_heff_2eemit_2eletDeclarations_str4))));
    return heff_tag(TAG_Cons, 2, (V[]){v_t_2412, NTAG(TAG_Nil)});
  }
  default: return heff_nomatch(v_xs_241);
  }
}
V g_heff_2eemit_2eletDeclarations_entry(V self, V *a) {
  (void)self;
  return g_heff_2eemit_2eletDeclarations(a[0], a[1]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eemit_2eprimRel_str0 = {{0x80000000u, K_STR, 0}, 5, 5, {105, 110, 116, 69, 113}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemit_2eprimRel_str1 = {{0x80000000u, K_STR, 0}, 3, 3, {61, 61, 61}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eemit_2eprimRel_str2 = {{0x80000000u, K_STR, 0}, 5, 5, {115, 116, 114, 69, 113}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemit_2eprimRel_str3 = {{0x80000000u, K_STR, 0}, 3, 3, {61, 61, 61}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eemit_2eprimRel_str4 = {{0x80000000u, K_STR, 0}, 5, 5, {105, 110, 116, 76, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2eprimRel_str5 = {{0x80000000u, K_STR, 0}, 1, 1, {60}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eemit_2eprimRel_str6 = {{0x80000000u, K_STR, 0}, 5, 5, {115, 116, 114, 76, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2eprimRel_str7 = {{0x80000000u, K_STR, 0}, 1, 1, {60}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eemit_2eprimRel_str8 = {{0x80000000u, K_STR, 0}, 5, 5, {105, 110, 116, 76, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemit_2eprimRel_str9 = {{0x80000000u, K_STR, 0}, 2, 2, {60, 61}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2eemit_2eprimRel_str10 = {{0x80000000u, K_STR, 0}, 7, 7, {102, 108, 111, 97, 116, 69, 113}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemit_2eprimRel_str11 = {{0x80000000u, K_STR, 0}, 3, 3, {61, 61, 61}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2eemit_2eprimRel_str12 = {{0x80000000u, K_STR, 0}, 7, 7, {102, 108, 111, 97, 116, 76, 116}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2eprimRel_str13 = {{0x80000000u, K_STR, 0}, 1, 1, {60}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2eemit_2eprimRel_str14 = {{0x80000000u, K_STR, 0}, 7, 7, {102, 108, 111, 97, 116, 76, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemit_2eprimRel_str15 = {{0x80000000u, K_STR, 0}, 2, 2, {60, 61}};
Clo g_heff_2eemit_2eprimRel_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemit_2eprimRel_entry, 1, 0};

V g_heff_2eemit_2eprimRel(V v_x1_240) {
top: ;
  V v_t_241 = heff_strEq(heff_dup(v_x1_240), ((V)&g_heff_2eemit_2eprimRel_str0));
  switch (heff_tag_of(v_t_241)) {
  case TAG_True: {
    heff_drop(v_x1_240);
    return heff_tag(TAG_Just, 1, (V[]){((V)&g_heff_2eemit_2eprimRel_str1)});
  }
  case TAG_False: {
    V v_t_242 = heff_strEq(heff_dup(v_x1_240), ((V)&g_heff_2eemit_2eprimRel_str2));
    switch (heff_tag_of(v_t_242)) {
    case TAG_True: {
      heff_drop(v_x1_240);
      return heff_tag(TAG_Just, 1, (V[]){((V)&g_heff_2eemit_2eprimRel_str3)});
    }
    case TAG_False: {
      V v_t_243 = heff_strEq(heff_dup(v_x1_240), ((V)&g_heff_2eemit_2eprimRel_str4));
      switch (heff_tag_of(v_t_243)) {
      case TAG_True: {
        heff_drop(v_x1_240);
        return heff_tag(TAG_Just, 1, (V[]){((V)&g_heff_2eemit_2eprimRel_str5)});
      }
      case TAG_False: {
        V v_t_244 = heff_strEq(heff_dup(v_x1_240), ((V)&g_heff_2eemit_2eprimRel_str6));
        switch (heff_tag_of(v_t_244)) {
        case TAG_True: {
          heff_drop(v_x1_240);
          return heff_tag(TAG_Just, 1, (V[]){((V)&g_heff_2eemit_2eprimRel_str7)});
        }
        case TAG_False: {
          V v_t_245 = heff_strEq(heff_dup(v_x1_240), ((V)&g_heff_2eemit_2eprimRel_str8));
          switch (heff_tag_of(v_t_245)) {
          case TAG_True: {
            heff_drop(v_x1_240);
            return heff_tag(TAG_Just, 1, (V[]){((V)&g_heff_2eemit_2eprimRel_str9)});
          }
          case TAG_False: {
            V v_t_246 = heff_strEq(heff_dup(v_x1_240), ((V)&g_heff_2eemit_2eprimRel_str10));
            switch (heff_tag_of(v_t_246)) {
            case TAG_True: {
              heff_drop(v_x1_240);
              return heff_tag(TAG_Just, 1, (V[]){((V)&g_heff_2eemit_2eprimRel_str11)});
            }
            case TAG_False: {
              V v_t_247 = heff_strEq(heff_dup(v_x1_240), ((V)&g_heff_2eemit_2eprimRel_str12));
              switch (heff_tag_of(v_t_247)) {
              case TAG_True: {
                heff_drop(v_x1_240);
                return heff_tag(TAG_Just, 1, (V[]){((V)&g_heff_2eemit_2eprimRel_str13)});
              }
              case TAG_False: {
                V v_t_248 = heff_strEq(v_x1_240, ((V)&g_heff_2eemit_2eprimRel_str14));
                switch (heff_tag_of(v_t_248)) {
                case TAG_True: {
                  return heff_tag(TAG_Just, 1, (V[]){((V)&g_heff_2eemit_2eprimRel_str15)});
                }
                case TAG_False: {
                  return NTAG(TAG_Nothing);
                }
                default: return heff_nomatch(v_t_248);
                }
              }
              default: return heff_nomatch(v_t_247);
              }
            }
            default: return heff_nomatch(v_t_246);
            }
          }
          default: return heff_nomatch(v_t_245);
          }
        }
        default: return heff_nomatch(v_t_244);
        }
      }
      default: return heff_nomatch(v_t_243);
      }
    }
    default: return heff_nomatch(v_t_242);
    }
  }
  default: return heff_nomatch(v_t_241);
  }
}
V g_heff_2eemit_2eprimRel_entry(V self, V *a) {
  (void)self;
  return g_heff_2eemit_2eprimRel(a[0]);
}
Clo g_heff_2eemit_2earmNamed_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemit_2earmNamed_entry, 2, 0};

V g_heff_2eemit_2earmNamed(V v_t_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_t_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_MkArm: {
      V v_t2_244 = heff_field(v_x21_242, 0);
      V v_vs_245 = heff_field(v_x21_242, 1);
      V v_b_246 = heff_field(v_x21_242, 2);
      V v_t_247 = heff_strEq(heff_dup(v_t2_244), heff_dup(v_t_240));
      switch (heff_tag_of(v_t_247)) {
      case TAG_True: {
        switch (heff_tag_of(v_vs_245)) {
        case TAG_Nil: {
          heff_drop(v_t_240);
          return heff_tag(TAG_Just, 1, (V[]){heff_dup(v_b_246)});
        }
        case TAG_Cons: {
          V t_0 = v_t_240;
          V t_1 = v_rest_243;
          v_t_240 = t_0;
          v_x2_241 = t_1;
          goto top;
        }
        default: return heff_nomatch(v_vs_245);
        }
      }
      case TAG_False: {
        V t_0 = v_t_240;
        V t_1 = v_rest_243;
        v_t_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      }
      default: return heff_nomatch(v_t_247);
      }
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eemit_2earmNamed_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eemit_2earmNamed(a[0], a[1]); heff_drop(a[1]); return r;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eemit_2econdShaped_str0 = {{0x80000000u, K_STR, 0}, 4, 4, {84, 114, 117, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eemit_2econdShaped_str1 = {{0x80000000u, K_STR, 0}, 5, 5, {70, 97, 108, 115, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eemit_2econdShaped_str2 = {{0x80000000u, K_STR, 0}, 4, 4, {84, 114, 117, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eemit_2econdShaped_str3 = {{0x80000000u, K_STR, 0}, 5, 5, {70, 97, 108, 115, 101}};
Clo g_heff_2eemit_2econdShaped_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemit_2econdShaped_entry, 1, 0};

V g_heff_2eemit_2econdShaped(V v_e_240) {
top: ;
  switch (heff_tag_of(v_e_240)) {
  case TAG_EVar: {
    heff_take_n(v_e_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EGlobal: {
    heff_take_n(v_e_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_ELam: {
    heff_take_n(v_e_240, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_EApp: {
    heff_take_n(v_e_240, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    V v_b_249 = heff_field(v_e_240, 2);
    heff_take_n(v_e_240, 4ULL, 3);
    V t_0 = v_b_249;
    v_e_240 = t_0;
    goto top;
  }
  case TAG_ERecord: {
    heff_take_n(v_e_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EProj: {
    heff_take_n(v_e_240, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_ETag: {
    V v_t_2413 = heff_field(v_e_240, 0);
    V v_it2_2414 = heff_field(v_e_240, 1);
    heff_take_n(v_e_240, 3ULL, 2);
    switch (heff_tag_of(v_it2_2414)) {
    case TAG_Nil: {
      V v_t_2415 = heff_strEq(heff_dup(v_t_2413), ((V)&g_heff_2eemit_2econdShaped_str0));
      switch (heff_tag_of(v_t_2415)) {
      case TAG_True: {
        heff_drop(v_t_2413);
        return NTAG(TAG_True);
      }
      case TAG_False: {
        return heff_strEq(v_t_2413, ((V)&g_heff_2eemit_2econdShaped_str1));
      }
      default: return heff_nomatch(v_t_2415);
      }
    }
    case TAG_Cons: {
      heff_take_n(v_it2_2414, 0ULL, 2);
      heff_drop(v_t_2413);
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_it2_2414);
    }
  }
  case TAG_EMatch: {
    V v_arms_2419 = heff_field(v_e_240, 1);
    V v_ru_24e_240_24EMatch = heff_take_reuse_n(v_e_240, 2ULL, 2);
    V v_t_2420 = (g_prelude_2efoldl_24s1(MK_INT(0LL), v_arms_2419));
    V v_t_2421 = heff_intEq(v_t_2420, MK_INT(2LL));
    V v_it_2426;
    switch (heff_tag_of(v_t_2421)) {
    case TAG_True: {
      V v_t_2422 = (g_heff_2eemit_2earmNamed(((V)&g_heff_2eemit_2econdShaped_str2), v_arms_2419));
      switch (heff_tag_of(v_t_2422)) {
      case TAG_Nothing: {
        heff_drop(v_arms_2419);
        heff_drop_cell(v_ru_24e_240_24EMatch, 2);
        v_it_2426 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Just: {
        V v_t_2423 = heff_field(v_t_2422, 0);
        V v_ru_24t_2422_24Just = heff_take_reuse_n(v_t_2422, 1ULL, 1);
        V v_t_2424 = ({ V a_0 = ((V)&g_heff_2eemit_2econdShaped_str3); V a_1 = v_arms_2419; V r_ = (g_heff_2eemit_2earmNamed(a_0, a_1)); heff_drop(v_arms_2419); r_; });
        switch (heff_tag_of(v_t_2424)) {
        case TAG_Nothing: {
          heff_drop_cell(v_ru_24e_240_24EMatch, 2);
          heff_drop(v_t_2423);
          heff_drop_cell(v_ru_24t_2422_24Just, 1);
          v_it_2426 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_Just: {
          V v_f_2425 = heff_field(v_t_2424, 0);
          heff_take_n(v_t_2424, 1ULL, 1);
          v_it_2426 = heff_tag_at(v_ru_24t_2422_24Just, TAG_Just, 1, (V[]){heff_tag_at(v_ru_24e_240_24EMatch, TAG_MkPair, 2, (V[]){v_t_2423, v_f_2425})});
          break;
        }
        default: heff_nomatch(v_t_2424);
        }
        break;
      }
      default: heff_nomatch(v_t_2422);
      }
      break;
    }
    case TAG_False: {
      heff_drop(v_arms_2419);
      heff_drop_cell(v_ru_24e_240_24EMatch, 2);
      v_it_2426 = NTAG(TAG_Nothing);
      break;
    }
    default: heff_nomatch(v_t_2421);
    }
    switch (heff_tag_of(v_it_2426)) {
    case TAG_Nothing: {
      return NTAG(TAG_False);
    }
    case TAG_Just: {
      V v_it1_2427 = heff_field(v_it_2426, 0);
      heff_take_n(v_it_2426, 1ULL, 1);
      switch (heff_tag_of(v_it1_2427)) {
      case TAG_MkPair: {
        V v_t_2428 = heff_field(v_it1_2427, 0);
        V v_f_2429 = heff_field(v_it1_2427, 1);
        heff_take_n(v_it1_2427, 3ULL, 2);
        V v_t_2430 = (g_heff_2eemit_2econdShaped(v_t_2428));
        switch (heff_tag_of(v_t_2430)) {
        case TAG_True: {
          V t_0 = v_f_2429;
          v_e_240 = t_0;
          goto top;
        }
        case TAG_False: {
          heff_drop(v_f_2429);
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_t_2430);
        }
      }
      default: return heff_nomatch(v_it1_2427);
      }
    }
    default: return heff_nomatch(v_it_2426);
    }
  }
  case TAG_EPrim: {
    heff_take_n(v_e_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EPrimCall: {
    V v_p_2432 = heff_field(v_e_240, 0);
    V v_it2_2433 = heff_field(v_e_240, 1);
    heff_take_n(v_e_240, 3ULL, 2);
    switch (heff_tag_of(v_it2_2433)) {
    case TAG_Nil: {
      heff_drop(v_p_2432);
      return NTAG(TAG_False);
    }
    case TAG_Cons: {
      V v_it22_2435 = heff_field(v_it2_2433, 1);
      heff_take_n(v_it2_2433, 2ULL, 2);
      switch (heff_tag_of(v_it22_2435)) {
      case TAG_Nil: {
        heff_drop(v_p_2432);
        return NTAG(TAG_False);
      }
      case TAG_Cons: {
        V v_it222_2437 = heff_field(v_it22_2435, 1);
        heff_take_n(v_it22_2435, 2ULL, 2);
        switch (heff_tag_of(v_it222_2437)) {
        case TAG_Nil: {
          V v_x3_2438 = (g_heff_2eemit_2eprimRel(v_p_2432));
          switch (heff_tag_of(v_x3_2438)) {
          case TAG_Nothing: {
            return NTAG(TAG_False);
          }
          case TAG_Just: {
            heff_take_n(v_x3_2438, 0ULL, 1);
            return NTAG(TAG_True);
          }
          default: return heff_nomatch(v_x3_2438);
          }
        }
        case TAG_Cons: {
          heff_take_n(v_it222_2437, 0ULL, 2);
          heff_drop(v_p_2432);
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_it222_2437);
        }
      }
      default: return heff_nomatch(v_it22_2435);
      }
    }
    default: return heff_nomatch(v_it2_2433);
    }
  }
  case TAG_ECall: {
    heff_take_n(v_e_240, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_EInt: {
    heff_take_n(v_e_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EFloat: {
    heff_take_n(v_e_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EStr: {
    heff_take_n(v_e_240, 0ULL, 1);
    return NTAG(TAG_False);
  }
  case TAG_EAbandon: {
    return NTAG(TAG_False);
  }
  case TAG_EFix: {
    heff_take_n(v_e_240, 0ULL, 2);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_e_240);
  }
}
V g_heff_2eemit_2econdShaped_entry(V self, V *a) {
  (void)self;
  return g_heff_2eemit_2econdShaped(a[0]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2ecallName_str0 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2ecallName_str1 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2ecallName_str2 = {{0x80000000u, K_STR, 0}, 1, 1, {120}};
Clo g_heff_2eemit_2ecallName_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemit_2ecallName_entry, 2, 0};

V g_heff_2eemit_2ecallName(V v_env_240, V v_g_241) {
top: ;
  V v_t_242 = ({ V a_0 = heff_dup(v_g_241); V b_1 = heff_get(v_env_240, LBL_gs); V r_ = (g_map_2elookup_24s8(a_0, b_1)); heff_drop(b_1); r_; });
  switch (heff_tag_of(v_t_242)) {
  case TAG_Nothing: {
    V v_t_243 = heff_intSub(heff_strLength(heff_dup(v_g_241)), MK_INT(1LL));
    V v_t_244 = (g_heff_2eemit_2elastDotFrom(heff_dup(v_g_241), v_t_243));
    V v_t_245 = (g_heff_2eemit_2espellAt(v_g_241, v_t_244));
    V v_s_246 = (g_heff_2eemit_2esafeChars(v_t_245, MK_INT(0LL), ((V)&g_heff_2eemit_2ecallName_str0)));
    V v_t_247 = heff_strEq(heff_dup(v_s_246), ((V)&g_heff_2eemit_2ecallName_str1));
    V v_t_248;
    switch (heff_tag_of(v_t_247)) {
    case TAG_True: {
      heff_drop(v_s_246);
      v_t_248 = ((V)&g_heff_2eemit_2ecallName_str2);
      break;
    }
    case TAG_False: {
      v_t_248 = v_s_246;
      break;
    }
    default: heff_nomatch(v_t_247);
    }
    return (g_heff_2eemit_2esafeRes(v_t_248));
  }
  case TAG_Just: {
    V v_i_249 = heff_field(v_t_242, 0);
    heff_take_n(v_t_242, 1ULL, 1);
    heff_drop(v_g_241);
    return heff_get(v_i_249, LBL_js);
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2eemit_2ecallName_entry(V self, V *a) {
  (void)self;
  return g_heff_2eemit_2ecallName(a[0], a[1]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2eemit_2eisUnitArgs_str0 = {{0x80000000u, K_STR, 0}, 6, 6, {77, 107, 85, 110, 105, 116}};
Clo g_heff_2eemit_2eisUnitArgs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemit_2eisUnitArgs_entry, 1, 0};

V g_heff_2eemit_2eisUnitArgs(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_x12_242 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_EVar: {
      return NTAG(TAG_False);
    }
    case TAG_EGlobal: {
      return NTAG(TAG_False);
    }
    case TAG_ELam: {
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      V v_t_2415 = heff_field(v_x11_241, 0);
      V v_x112_2416 = heff_field(v_x11_241, 1);
      switch (heff_tag_of(v_x112_2416)) {
      case TAG_Nil: {
        switch (heff_tag_of(v_x12_242)) {
        case TAG_Nil: {
          return heff_strEq(heff_dup(v_t_2415), ((V)&g_heff_2eemit_2eisUnitArgs_str0));
        }
        case TAG_Cons: {
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_x12_242);
        }
      }
      case TAG_Cons: {
        return NTAG(TAG_False);
      }
      default: return heff_nomatch(v_x112_2416);
      }
    }
    case TAG_EMatch: {
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      return NTAG(TAG_False);
    }
    case TAG_EPrimCall: {
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      return NTAG(TAG_False);
    }
    case TAG_EFloat: {
      return NTAG(TAG_False);
    }
    case TAG_EStr: {
      return NTAG(TAG_False);
    }
    case TAG_EAbandon: {
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eemit_2eisUnitArgs_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eemit_2eisUnitArgs(a[0]); heff_drop(a[0]); return r;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemit_2edeclsOf_str0 = {{0x80000000u, K_STR, 0}, 2, 2, {32, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2edeclsOf_str1 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2eemit_2edeclsOf_str2 = {{0x80000000u, K_STR, 0}, 6, 6, {99, 111, 110, 115, 116, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemit_2edeclsOf_str3 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 61, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemit_2edeclsOf_str4 = {{0x80000000u, K_STR, 0}, 3, 3, {46, 97, 91}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemit_2edeclsOf_str5 = {{0x80000000u, K_STR, 0}, 2, 2, {93, 59}};
Clo g_heff_2eemit_2edeclsOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemit_2edeclsOf_entry, 4, 0};

V g_heff_2eemit_2edeclsOf(V v_js_240, V v_ind_241, V v_x3_242, V v_i_243) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_js_240);
    heff_drop(v_ind_241);
    heff_drop(v_i_243);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_v_244 = heff_field(v_x3_242, 0);
    V v_rest_245 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_x2_246 = (g_prelude_2ereplicate(heff_dup(v_ind_241), ((V)&g_heff_2eemit_2edeclsOf_str0)));
    V v_t_249;
    switch (heff_tag_of(v_x2_246)) {
    case TAG_Nil: {
      v_t_249 = ((V)&g_heff_2eemit_2edeclsOf_str1);
      break;
    }
    case TAG_Cons: {
      V v_x_247 = heff_field(v_x2_246, 0);
      V v_xs_248 = heff_field(v_x2_246, 1);
      heff_take_n(v_x2_246, 3ULL, 2);
      v_t_249 = ({ V a_0 = v_x_247; V a_1 = v_xs_248; V r_ = (g_prelude_2efoldl_24s46(a_0, a_1)); heff_drop(v_xs_248); r_; });
      break;
    }
    default: heff_nomatch(v_x2_246);
    }
    V v_t_2410 = heff_strAppend(v_t_249, heff_strAppend(((V)&g_heff_2eemit_2edeclsOf_str2), heff_strAppend(v_v_244, heff_strAppend(((V)&g_heff_2eemit_2edeclsOf_str3), heff_strAppend(heff_dup(v_js_240), heff_strAppend(((V)&g_heff_2eemit_2edeclsOf_str4), heff_strAppend(heff_intShow(heff_dup(v_i_243)), ((V)&g_heff_2eemit_2edeclsOf_str5))))))));
    return heff_tag_at(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_t_2410, (g_heff_2eemit_2edeclsOf(v_js_240, v_ind_241, v_rest_245, heff_intAdd(v_i_243, MK_INT(1LL))))});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2eemit_2edeclsOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2eemit_2edeclsOf(a[0], a[1], a[2], a[3]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2esharedGo_str0 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2esharedGo_str1 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2esharedGo_str2 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2esharedGo_str3 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemit_2esharedGo_str4 = {{0x80000000u, K_STR, 0}, 2, 2, {32, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2esharedGo_str5 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2esharedGo_str6 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2esharedGo_str7 = {{0x80000000u, K_STR, 0}, 1, 1, {34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2esharedGo_str8 = {{0x80000000u, K_STR, 0}, 1, 1, {34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eemit_2esharedGo_str9 = {{0x80000000u, K_STR, 0}, 5, 5, {99, 97, 115, 101, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2esharedGo_str10 = {{0x80000000u, K_STR, 0}, 1, 1, {58}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemit_2esharedGo_str11 = {{0x80000000u, K_STR, 0}, 2, 2, {32, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2esharedGo_str12 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2esharedGo_str13 = {{0x80000000u, K_STR, 0}, 1, 1, {123}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemit_2esharedGo_str14 = {{0x80000000u, K_STR, 0}, 2, 2, {32, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2esharedGo_str15 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2esharedGo_str16 = {{0x80000000u, K_STR, 0}, 1, 1, {125}};
V g_heff_2eemit_2esharedGo_lam0(V self, V *args);
V g_heff_2eemit_2esharedGo_lam1(V self, V *args);
V g_heff_2eemit_2esharedGo_lam2(V self, V *args);
Clo g_heff_2eemit_2esharedGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemit_2esharedGo_entry, 3, 0};

V g_heff_2eemit_2esharedGo(V v_ind_240, V v_before_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_ind_240);
    heff_drop(v_before_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_a_243 = heff_field(v_x3_242, 0);
    V v_rest_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    switch (heff_tag_of(v_a_243)) {
    case TAG_MkArmJs: {
      V v_it2_246 = heff_dup(heff_field(v_a_243, 1));
      V v_ls_247 = heff_dup(heff_field(v_a_243, 2));
      switch (heff_tag_of(v_it2_246)) {
      case TAG_True: {
        V v_t_2425 = (g_prelude_2eany(heff_clo(g_heff_2eemit_2esharedGo_lam0, 1, 1, (V[]){heff_dup(v_a_243)}), v_before_241));
        switch (heff_tag_of(v_t_2425)) {
        case TAG_True: {
          heff_drop(v_ls_247);
          V t_0 = v_ind_240;
          V t_1 = heff_tag_at(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_a_243, v_before_241});
          V t_2 = v_rest_244;
          v_ind_240 = t_0;
          v_before_241 = t_1;
          v_x3_242 = t_2;
          goto top;
        }
        case TAG_False: {
          V v_t_2443 = heff_tag_at(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_a_243), (g_prelude_2efilter(heff_clo(g_heff_2eemit_2esharedGo_lam1, 1, 1, (V[]){heff_dup(v_a_243)}), heff_dup(v_rest_244)))});
          V v_t_2455 = (g_prelude_2emap(heff_clo(g_heff_2eemit_2esharedGo_lam2, 1, 1, (V[]){heff_dup(v_ind_240)}), v_t_2443));
          V v_x2_2456 = (g_prelude_2ereplicate(heff_intAdd(heff_dup(v_ind_240), MK_INT(1LL)), ((V)&g_heff_2eemit_2esharedGo_str11)));
          V v_t_2459;
          switch (heff_tag_of(v_x2_2456)) {
          case TAG_Nil: {
            v_t_2459 = ((V)&g_heff_2eemit_2esharedGo_str12);
            break;
          }
          case TAG_Cons: {
            V v_x_2457 = heff_field(v_x2_2456, 0);
            V v_xs_2458 = heff_field(v_x2_2456, 1);
            heff_take_n(v_x2_2456, 3ULL, 2);
            v_t_2459 = ({ V a_0 = v_x_2457; V a_1 = v_xs_2458; V r_ = (g_prelude_2efoldl_24s46(a_0, a_1)); heff_drop(v_xs_2458); r_; });
            break;
          }
          default: heff_nomatch(v_x2_2456);
          }
          V v_t_2460 = heff_tag(TAG_Cons, 2, (V[]){heff_strAppend(v_t_2459, ((V)&g_heff_2eemit_2esharedGo_str13)), NTAG(TAG_Nil)});
          V v_x2_2461 = (g_prelude_2ereplicate(heff_intAdd(heff_dup(v_ind_240), MK_INT(1LL)), ((V)&g_heff_2eemit_2esharedGo_str14)));
          V v_t_2464;
          switch (heff_tag_of(v_x2_2461)) {
          case TAG_Nil: {
            v_t_2464 = ((V)&g_heff_2eemit_2esharedGo_str15);
            break;
          }
          case TAG_Cons: {
            V v_x_2462 = heff_field(v_x2_2461, 0);
            V v_xs_2463 = heff_field(v_x2_2461, 1);
            heff_take_n(v_x2_2461, 3ULL, 2);
            v_t_2464 = ({ V a_0 = v_x_2462; V a_1 = v_xs_2463; V r_ = (g_prelude_2efoldl_24s46(a_0, a_1)); heff_drop(v_xs_2463); r_; });
            break;
          }
          default: heff_nomatch(v_x2_2461);
          }
          V v_t_2465 = heff_tag(TAG_Cons, 2, (V[]){heff_strAppend(v_t_2464, ((V)&g_heff_2eemit_2esharedGo_str16)), NTAG(TAG_Nil)});
          V v_t_2466 = (g_heff_2eemit_2esharedGo(v_ind_240, heff_tag(TAG_Cons, 2, (V[]){v_a_243, v_before_241}), v_rest_244));
          V v_t_2467 = (g_prelude_2econcatList(v_t_2465, v_t_2466));
          V v_t_2468 = (g_prelude_2econcatList(v_ls_247, v_t_2467));
          V v_t_2469 = (g_prelude_2econcatList(v_t_2460, v_t_2468));
          return (g_prelude_2econcatList(v_t_2455, v_t_2469));
        }
        default: return heff_nomatch(v_t_2425);
        }
      }
      case TAG_False: {
        V v_t_2470 = (g_heff_2eemit_2esharedGo(v_ind_240, heff_tag_at(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_a_243, v_before_241}), v_rest_244));
        return (g_prelude_2econcatList(v_ls_247, v_t_2470));
      }
      default: return heff_nomatch(v_it2_246);
      }
    }
    default: return heff_nomatch(v_a_243);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2eemit_2esharedGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2eemit_2esharedGo(a[0], a[1], a[2]);
}
V g_heff_2eemit_2esharedGo_lam0(V self, V *args) {
  V v_b_248 = args[0];
  V v_a_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2415;
  switch (heff_tag_of(v_a_243)) {
  case TAG_MkArmJs: {
    V v_x12_2410 = heff_field(v_a_243, 1);
    V v_ls_2411 = heff_field(v_a_243, 2);
    heff_take_n(v_a_243, 6ULL, 3);
    switch (heff_tag_of(v_x12_2410)) {
    case TAG_True: {
      V v_t_2414;
      switch (heff_tag_of(v_ls_2411)) {
      case TAG_Nil: {
        v_t_2414 = ((V)&g_heff_2eemit_2esharedGo_str0);
        break;
      }
      case TAG_Cons: {
        V v_x_2412 = heff_field(v_ls_2411, 0);
        V v_xs_2413 = heff_field(v_ls_2411, 1);
        heff_take_n(v_ls_2411, 3ULL, 2);
        v_t_2414 = ({ V a_0 = v_x_2412; V a_1 = v_xs_2413; V r_ = (g_prelude_2efoldl_24s3(a_0, a_1)); heff_drop(v_xs_2413); r_; });
        break;
      }
      default: heff_nomatch(v_ls_2411);
      }
      v_x1_2415 = heff_tag(TAG_Just, 1, (V[]){v_t_2414});
      break;
    }
    case TAG_False: {
      heff_drop(v_ls_2411);
      v_x1_2415 = NTAG(TAG_Nothing);
      break;
    }
    default: heff_nomatch(v_x12_2410);
    }
    break;
  }
  default: heff_nomatch(v_a_243);
  }
  switch (heff_tag_of(v_x1_2415)) {
  case TAG_Nothing: {
    heff_drop(v_b_248);
    return NTAG(TAG_False);
  }
  case TAG_Just: {
    V v_k_2416 = heff_field(v_x1_2415, 0);
    V v_ru_24x1_2415_24Just = heff_take_reuse_n(v_x1_2415, 1ULL, 1);
    V v_t_2423;
    switch (heff_tag_of(v_b_248)) {
    case TAG_MkArmJs: {
      V v_x12_2418 = heff_field(v_b_248, 1);
      V v_ls_2419 = heff_field(v_b_248, 2);
      heff_take_n(v_b_248, 6ULL, 3);
      switch (heff_tag_of(v_x12_2418)) {
      case TAG_True: {
        V v_t_2422;
        switch (heff_tag_of(v_ls_2419)) {
        case TAG_Nil: {
          v_t_2422 = ((V)&g_heff_2eemit_2esharedGo_str1);
          break;
        }
        case TAG_Cons: {
          V v_x_2420 = heff_field(v_ls_2419, 0);
          V v_xs_2421 = heff_field(v_ls_2419, 1);
          heff_take_n(v_ls_2419, 3ULL, 2);
          v_t_2422 = ({ V a_0 = v_x_2420; V a_1 = v_xs_2421; V r_ = (g_prelude_2efoldl_24s3(a_0, a_1)); heff_drop(v_xs_2421); r_; });
          break;
        }
        default: heff_nomatch(v_ls_2419);
        }
        v_t_2423 = heff_tag_at(v_ru_24x1_2415_24Just, TAG_Just, 1, (V[]){v_t_2422});
        break;
      }
      case TAG_False: {
        heff_drop_cell(v_ru_24x1_2415_24Just, 1);
        heff_drop(v_ls_2419);
        v_t_2423 = NTAG(TAG_Nothing);
        break;
      }
      default: heff_nomatch(v_x12_2418);
      }
      break;
    }
    default: heff_nomatch(v_b_248);
    }
    switch (heff_tag_of(v_t_2423)) {
    case TAG_Nothing: {
      heff_drop(v_k_2416);
      return NTAG(TAG_False);
    }
    case TAG_Just: {
      V v_k2_2424 = heff_field(v_t_2423, 0);
      heff_take_n(v_t_2423, 1ULL, 1);
      return heff_strEq(v_k_2416, v_k2_2424);
    }
    default: return heff_nomatch(v_t_2423);
    }
  }
  default: return heff_nomatch(v_x1_2415);
  }
}
V g_heff_2eemit_2esharedGo_lam1(V self, V *args) {
  V v_b_2426 = args[0];
  V v_a_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x1_2433;
  switch (heff_tag_of(v_a_243)) {
  case TAG_MkArmJs: {
    V v_x12_2428 = heff_field(v_a_243, 1);
    V v_ls_2429 = heff_field(v_a_243, 2);
    heff_take_n(v_a_243, 6ULL, 3);
    switch (heff_tag_of(v_x12_2428)) {
    case TAG_True: {
      V v_t_2432;
      switch (heff_tag_of(v_ls_2429)) {
      case TAG_Nil: {
        v_t_2432 = ((V)&g_heff_2eemit_2esharedGo_str2);
        break;
      }
      case TAG_Cons: {
        V v_x_2430 = heff_field(v_ls_2429, 0);
        V v_xs_2431 = heff_field(v_ls_2429, 1);
        heff_take_n(v_ls_2429, 3ULL, 2);
        v_t_2432 = ({ V a_0 = v_x_2430; V a_1 = v_xs_2431; V r_ = (g_prelude_2efoldl_24s3(a_0, a_1)); heff_drop(v_xs_2431); r_; });
        break;
      }
      default: heff_nomatch(v_ls_2429);
      }
      v_x1_2433 = heff_tag(TAG_Just, 1, (V[]){v_t_2432});
      break;
    }
    case TAG_False: {
      heff_drop(v_ls_2429);
      v_x1_2433 = NTAG(TAG_Nothing);
      break;
    }
    default: heff_nomatch(v_x12_2428);
    }
    break;
  }
  default: heff_nomatch(v_a_243);
  }
  switch (heff_tag_of(v_x1_2433)) {
  case TAG_Nothing: {
    heff_drop(v_b_2426);
    return NTAG(TAG_False);
  }
  case TAG_Just: {
    V v_k_2434 = heff_field(v_x1_2433, 0);
    V v_ru_24x1_2433_24Just = heff_take_reuse_n(v_x1_2433, 1ULL, 1);
    V v_t_2441;
    switch (heff_tag_of(v_b_2426)) {
    case TAG_MkArmJs: {
      V v_x12_2436 = heff_field(v_b_2426, 1);
      V v_ls_2437 = heff_field(v_b_2426, 2);
      heff_take_n(v_b_2426, 6ULL, 3);
      switch (heff_tag_of(v_x12_2436)) {
      case TAG_True: {
        V v_t_2440;
        switch (heff_tag_of(v_ls_2437)) {
        case TAG_Nil: {
          v_t_2440 = ((V)&g_heff_2eemit_2esharedGo_str3);
          break;
        }
        case TAG_Cons: {
          V v_x_2438 = heff_field(v_ls_2437, 0);
          V v_xs_2439 = heff_field(v_ls_2437, 1);
          heff_take_n(v_ls_2437, 3ULL, 2);
          v_t_2440 = ({ V a_0 = v_x_2438; V a_1 = v_xs_2439; V r_ = (g_prelude_2efoldl_24s3(a_0, a_1)); heff_drop(v_xs_2439); r_; });
          break;
        }
        default: heff_nomatch(v_ls_2437);
        }
        v_t_2441 = heff_tag_at(v_ru_24x1_2433_24Just, TAG_Just, 1, (V[]){v_t_2440});
        break;
      }
      case TAG_False: {
        heff_drop_cell(v_ru_24x1_2433_24Just, 1);
        heff_drop(v_ls_2437);
        v_t_2441 = NTAG(TAG_Nothing);
        break;
      }
      default: heff_nomatch(v_x12_2436);
      }
      break;
    }
    default: heff_nomatch(v_b_2426);
    }
    switch (heff_tag_of(v_t_2441)) {
    case TAG_Nothing: {
      heff_drop(v_k_2434);
      return NTAG(TAG_False);
    }
    case TAG_Just: {
      V v_k2_2442 = heff_field(v_t_2441, 0);
      heff_take_n(v_t_2441, 1ULL, 1);
      return heff_strEq(v_k_2434, v_k2_2442);
    }
    default: return heff_nomatch(v_t_2441);
    }
  }
  default: return heff_nomatch(v_x1_2433);
  }
}
V g_heff_2eemit_2esharedGo_lam2(V self, V *args) {
  V v_b_2444 = args[0];
  V v_ind_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x2_2445 = (g_prelude_2ereplicate(heff_intAdd(v_ind_240, MK_INT(1LL)), ((V)&g_heff_2eemit_2esharedGo_str4)));
  V v_t_2448;
  switch (heff_tag_of(v_x2_2445)) {
  case TAG_Nil: {
    v_t_2448 = ((V)&g_heff_2eemit_2esharedGo_str5);
    break;
  }
  case TAG_Cons: {
    V v_x_2446 = heff_field(v_x2_2445, 0);
    V v_xs_2447 = heff_field(v_x2_2445, 1);
    heff_take_n(v_x2_2445, 3ULL, 2);
    v_t_2448 = ({ V a_0 = v_x_2446; V a_1 = v_xs_2447; V r_ = (g_prelude_2efoldl_24s46(a_0, a_1)); heff_drop(v_xs_2447); r_; });
    break;
  }
  default: heff_nomatch(v_x2_2445);
  }
  V v_s_2452;
  switch (heff_tag_of(v_b_2444)) {
  case TAG_MkArmJs: {
    V v_t_2449 = heff_field(v_b_2444, 0);
    heff_take_n(v_b_2444, 1ULL, 3);
    v_s_2452 = v_t_2449;
    break;
  }
  default: heff_nomatch(v_b_2444);
  }
  V v_t_2453 = (g_heff_2eemit_2equoteGo(v_s_2452, MK_INT(0LL), ((V)&g_heff_2eemit_2esharedGo_str6)));
  V v_t_2454 = heff_strAppend(((V)&g_heff_2eemit_2esharedGo_str7), heff_strAppend(v_t_2453, ((V)&g_heff_2eemit_2esharedGo_str8)));
  return heff_strAppend(v_t_2448, heff_strAppend(((V)&g_heff_2eemit_2esharedGo_str9), heff_strAppend(v_t_2454, ((V)&g_heff_2eemit_2esharedGo_str10))));
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemit_2estmtsReturnCond_str0 = {{0x80000000u, K_STR, 0}, 2, 2, {32, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2estmtsReturnCond_str1 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[10]; } g_heff_2eemit_2estmtsReturnCond_str2 = {{0x80000000u, K_STR, 0}, 10, 10, {114, 101, 116, 117, 114, 110, 32, 36, 84, 59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemit_2estmtsReturnCond_str3 = {{0x80000000u, K_STR, 0}, 2, 2, {32, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2estmtsReturnCond_str4 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[10]; } g_heff_2eemit_2estmtsReturnCond_str5 = {{0x80000000u, K_STR, 0}, 10, 10, {114, 101, 116, 117, 114, 110, 32, 36, 70, 59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemit_2estmtsReturnCond_str6 = {{0x80000000u, K_STR, 0}, 2, 2, {32, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2estmtsReturnCond_str7 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2estmtsReturnCond_str8 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2estmtsReturnCond_str9 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2eemit_2estmtsReturnCond_str10 = {{0x80000000u, K_STR, 0}, 7, 7, {114, 101, 116, 117, 114, 110, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[11]; } g_heff_2eemit_2estmtsReturnCond_str11 = {{0x80000000u, K_STR, 0}, 11, 11, {32, 63, 32, 36, 84, 32, 58, 32, 36, 70, 59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemit_2estmtsReturnCond_str12 = {{0x80000000u, K_STR, 0}, 2, 2, {32, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2estmtsReturnCond_str13 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2estmtsReturnCond_str14 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2estmtsReturnCond_str15 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2eemit_2estmtsReturnCond_str16 = {{0x80000000u, K_STR, 0}, 7, 7, {114, 101, 116, 117, 114, 110, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[11]; } g_heff_2eemit_2estmtsReturnCond_str17 = {{0x80000000u, K_STR, 0}, 11, 11, {32, 63, 32, 36, 84, 32, 58, 32, 36, 70, 59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemit_2estmtsReturnCond_str18 = {{0x80000000u, K_STR, 0}, 2, 2, {32, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2estmtsReturnCond_str19 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2estmtsReturnCond_str20 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2estmtsReturnCond_str21 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2eemit_2estmtsReturnCond_str22 = {{0x80000000u, K_STR, 0}, 7, 7, {114, 101, 116, 117, 114, 110, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[11]; } g_heff_2eemit_2estmtsReturnCond_str23 = {{0x80000000u, K_STR, 0}, 11, 11, {32, 63, 32, 36, 84, 32, 58, 32, 36, 70, 59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemit_2estmtsReturnCond_str24 = {{0x80000000u, K_STR, 0}, 2, 2, {32, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2estmtsReturnCond_str25 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2estmtsReturnCond_str26 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2estmtsReturnCond_str27 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2eemit_2estmtsReturnCond_str28 = {{0x80000000u, K_STR, 0}, 7, 7, {114, 101, 116, 117, 114, 110, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[11]; } g_heff_2eemit_2estmtsReturnCond_str29 = {{0x80000000u, K_STR, 0}, 11, 11, {32, 63, 32, 36, 84, 32, 58, 32, 36, 70, 59}};
Clo g_heff_2eemit_2estmtsReturnCond_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemit_2estmtsReturnCond_entry, 2, 0};

V g_heff_2eemit_2estmtsReturnCond(V v_ind_240, V v_c_241) {
top: ;
  switch (heff_tag_of(v_c_241)) {
  case TAG_PTrue: {
    V v_x2_242 = (g_prelude_2ereplicate(v_ind_240, ((V)&g_heff_2eemit_2estmtsReturnCond_str0)));
    V v_t_245;
    switch (heff_tag_of(v_x2_242)) {
    case TAG_Nil: {
      v_t_245 = ((V)&g_heff_2eemit_2estmtsReturnCond_str1);
      break;
    }
    case TAG_Cons: {
      V v_x_243 = heff_field(v_x2_242, 0);
      V v_xs_244 = heff_field(v_x2_242, 1);
      heff_take_n(v_x2_242, 3ULL, 2);
      v_t_245 = ({ V a_0 = v_x_243; V a_1 = v_xs_244; V r_ = (g_prelude_2efoldl_24s46(a_0, a_1)); heff_drop(v_xs_244); r_; });
      break;
    }
    default: heff_nomatch(v_x2_242);
    }
    return heff_tag(TAG_Cons, 2, (V[]){heff_strAppend(v_t_245, ((V)&g_heff_2eemit_2estmtsReturnCond_str2)), NTAG(TAG_Nil)});
  }
  case TAG_PFalse: {
    V v_x2_246 = (g_prelude_2ereplicate(v_ind_240, ((V)&g_heff_2eemit_2estmtsReturnCond_str3)));
    V v_t_249;
    switch (heff_tag_of(v_x2_246)) {
    case TAG_Nil: {
      v_t_249 = ((V)&g_heff_2eemit_2estmtsReturnCond_str4);
      break;
    }
    case TAG_Cons: {
      V v_x_247 = heff_field(v_x2_246, 0);
      V v_xs_248 = heff_field(v_x2_246, 1);
      heff_take_n(v_x2_246, 3ULL, 2);
      v_t_249 = ({ V a_0 = v_x_247; V a_1 = v_xs_248; V r_ = (g_prelude_2efoldl_24s46(a_0, a_1)); heff_drop(v_xs_248); r_; });
      break;
    }
    default: heff_nomatch(v_x2_246);
    }
    return heff_tag(TAG_Cons, 2, (V[]){heff_strAppend(v_t_249, ((V)&g_heff_2eemit_2estmtsReturnCond_str5)), NTAG(TAG_Nil)});
  }
  case TAG_PRel: {
    V v_t_2411 = (g_heff_2eemit_2eseqsOf(v_c_241));
    V v_t_2412 = (g_heff_2eemit_2eletDeclarations(heff_dup(v_ind_240), v_t_2411));
    V v_x2_2413 = (g_prelude_2ereplicate(v_ind_240, ((V)&g_heff_2eemit_2estmtsReturnCond_str6)));
    V v_t_2416;
    switch (heff_tag_of(v_x2_2413)) {
    case TAG_Nil: {
      v_t_2416 = ((V)&g_heff_2eemit_2estmtsReturnCond_str7);
      break;
    }
    case TAG_Cons: {
      V v_x_2414 = heff_field(v_x2_2413, 0);
      V v_xs_2415 = heff_field(v_x2_2413, 1);
      heff_take_n(v_x2_2413, 3ULL, 2);
      v_t_2416 = ({ V a_0 = v_x_2414; V a_1 = v_xs_2415; V r_ = (g_prelude_2efoldl_24s46(a_0, a_1)); heff_drop(v_xs_2415); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2413);
    }
    V v_c_2417 = (g_heff_2eemit_2econdCode(v_c_241));
    V v_t_2418 = heff_intLt(heff_get(heff_dup(v_c_2417), LBL_prec), MK_INT(1LL));
    V v_t_2419;
    switch (heff_tag_of(v_t_2418)) {
    case TAG_True: {
      v_t_2419 = heff_strAppend(((V)&g_heff_2eemit_2estmtsReturnCond_str8), heff_strAppend(heff_get(v_c_2417, LBL_code), ((V)&g_heff_2eemit_2estmtsReturnCond_str9)));
      break;
    }
    case TAG_False: {
      v_t_2419 = heff_get(v_c_2417, LBL_code);
      break;
    }
    default: heff_nomatch(v_t_2418);
    }
    V v_t_2420 = heff_strAppend(v_t_2416, heff_strAppend(((V)&g_heff_2eemit_2estmtsReturnCond_str10), heff_strAppend(v_t_2419, ((V)&g_heff_2eemit_2estmtsReturnCond_str11))));
    V v_t_2421 = heff_tag(TAG_Cons, 2, (V[]){v_t_2420, NTAG(TAG_Nil)});
    HEFF_LAST return g_prelude_2econcatList(v_t_2412, v_t_2421);
  }
  case TAG_PNot: {
    V v_t_2423 = (g_heff_2eemit_2eseqsOf(v_c_241));
    V v_t_2424 = (g_heff_2eemit_2eletDeclarations(heff_dup(v_ind_240), v_t_2423));
    V v_x2_2425 = (g_prelude_2ereplicate(v_ind_240, ((V)&g_heff_2eemit_2estmtsReturnCond_str12)));
    V v_t_2428;
    switch (heff_tag_of(v_x2_2425)) {
    case TAG_Nil: {
      v_t_2428 = ((V)&g_heff_2eemit_2estmtsReturnCond_str13);
      break;
    }
    case TAG_Cons: {
      V v_x_2426 = heff_field(v_x2_2425, 0);
      V v_xs_2427 = heff_field(v_x2_2425, 1);
      heff_take_n(v_x2_2425, 3ULL, 2);
      v_t_2428 = ({ V a_0 = v_x_2426; V a_1 = v_xs_2427; V r_ = (g_prelude_2efoldl_24s46(a_0, a_1)); heff_drop(v_xs_2427); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2425);
    }
    V v_c_2429 = (g_heff_2eemit_2econdCode(v_c_241));
    V v_t_2430 = heff_intLt(heff_get(heff_dup(v_c_2429), LBL_prec), MK_INT(1LL));
    V v_t_2431;
    switch (heff_tag_of(v_t_2430)) {
    case TAG_True: {
      v_t_2431 = heff_strAppend(((V)&g_heff_2eemit_2estmtsReturnCond_str14), heff_strAppend(heff_get(v_c_2429, LBL_code), ((V)&g_heff_2eemit_2estmtsReturnCond_str15)));
      break;
    }
    case TAG_False: {
      v_t_2431 = heff_get(v_c_2429, LBL_code);
      break;
    }
    default: heff_nomatch(v_t_2430);
    }
    V v_t_2432 = heff_strAppend(v_t_2428, heff_strAppend(((V)&g_heff_2eemit_2estmtsReturnCond_str16), heff_strAppend(v_t_2431, ((V)&g_heff_2eemit_2estmtsReturnCond_str17))));
    V v_t_2433 = heff_tag(TAG_Cons, 2, (V[]){v_t_2432, NTAG(TAG_Nil)});
    HEFF_LAST return g_prelude_2econcatList(v_t_2424, v_t_2433);
  }
  case TAG_PIf: {
    V v_t_2437 = (g_heff_2eemit_2eseqsOf(v_c_241));
    V v_t_2438 = (g_heff_2eemit_2eletDeclarations(heff_dup(v_ind_240), v_t_2437));
    V v_x2_2439 = (g_prelude_2ereplicate(v_ind_240, ((V)&g_heff_2eemit_2estmtsReturnCond_str18)));
    V v_t_2442;
    switch (heff_tag_of(v_x2_2439)) {
    case TAG_Nil: {
      v_t_2442 = ((V)&g_heff_2eemit_2estmtsReturnCond_str19);
      break;
    }
    case TAG_Cons: {
      V v_x_2440 = heff_field(v_x2_2439, 0);
      V v_xs_2441 = heff_field(v_x2_2439, 1);
      heff_take_n(v_x2_2439, 3ULL, 2);
      v_t_2442 = ({ V a_0 = v_x_2440; V a_1 = v_xs_2441; V r_ = (g_prelude_2efoldl_24s46(a_0, a_1)); heff_drop(v_xs_2441); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2439);
    }
    V v_c_2443 = (g_heff_2eemit_2econdCode(v_c_241));
    V v_t_2444 = heff_intLt(heff_get(heff_dup(v_c_2443), LBL_prec), MK_INT(1LL));
    V v_t_2445;
    switch (heff_tag_of(v_t_2444)) {
    case TAG_True: {
      v_t_2445 = heff_strAppend(((V)&g_heff_2eemit_2estmtsReturnCond_str20), heff_strAppend(heff_get(v_c_2443, LBL_code), ((V)&g_heff_2eemit_2estmtsReturnCond_str21)));
      break;
    }
    case TAG_False: {
      v_t_2445 = heff_get(v_c_2443, LBL_code);
      break;
    }
    default: heff_nomatch(v_t_2444);
    }
    V v_t_2446 = heff_strAppend(v_t_2442, heff_strAppend(((V)&g_heff_2eemit_2estmtsReturnCond_str22), heff_strAppend(v_t_2445, ((V)&g_heff_2eemit_2estmtsReturnCond_str23))));
    V v_t_2447 = heff_tag(TAG_Cons, 2, (V[]){v_t_2446, NTAG(TAG_Nil)});
    HEFF_LAST return g_prelude_2econcatList(v_t_2438, v_t_2447);
  }
  case TAG_PSeq: {
    V v_t_2451 = (g_heff_2eemit_2eseqsOf(v_c_241));
    V v_t_2452 = (g_heff_2eemit_2eletDeclarations(heff_dup(v_ind_240), v_t_2451));
    V v_x2_2453 = (g_prelude_2ereplicate(v_ind_240, ((V)&g_heff_2eemit_2estmtsReturnCond_str24)));
    V v_t_2456;
    switch (heff_tag_of(v_x2_2453)) {
    case TAG_Nil: {
      v_t_2456 = ((V)&g_heff_2eemit_2estmtsReturnCond_str25);
      break;
    }
    case TAG_Cons: {
      V v_x_2454 = heff_field(v_x2_2453, 0);
      V v_xs_2455 = heff_field(v_x2_2453, 1);
      heff_take_n(v_x2_2453, 3ULL, 2);
      v_t_2456 = ({ V a_0 = v_x_2454; V a_1 = v_xs_2455; V r_ = (g_prelude_2efoldl_24s46(a_0, a_1)); heff_drop(v_xs_2455); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2453);
    }
    V v_c_2457 = (g_heff_2eemit_2econdCode(v_c_241));
    V v_t_2458 = heff_intLt(heff_get(heff_dup(v_c_2457), LBL_prec), MK_INT(1LL));
    V v_t_2459;
    switch (heff_tag_of(v_t_2458)) {
    case TAG_True: {
      v_t_2459 = heff_strAppend(((V)&g_heff_2eemit_2estmtsReturnCond_str26), heff_strAppend(heff_get(v_c_2457, LBL_code), ((V)&g_heff_2eemit_2estmtsReturnCond_str27)));
      break;
    }
    case TAG_False: {
      v_t_2459 = heff_get(v_c_2457, LBL_code);
      break;
    }
    default: heff_nomatch(v_t_2458);
    }
    V v_t_2460 = heff_strAppend(v_t_2456, heff_strAppend(((V)&g_heff_2eemit_2estmtsReturnCond_str28), heff_strAppend(v_t_2459, ((V)&g_heff_2eemit_2estmtsReturnCond_str29))));
    V v_t_2461 = heff_tag(TAG_Cons, 2, (V[]){v_t_2460, NTAG(TAG_Nil)});
    HEFF_LAST return g_prelude_2econcatList(v_t_2452, v_t_2461);
  }
  default: return heff_nomatch(v_c_241);
  }
}
V g_heff_2eemit_2estmtsReturnCond_entry(V self, V *a) {
  (void)self;
  return g_heff_2eemit_2estmtsReturnCond(a[0], a[1]);
}

static V g_heff_2eemit_2ebounceDepth_val;
static int g_heff_2eemit_2ebounceDepth_st;
static V g_heff_2eemit_2ebounceDepth_init(void) {
  return MK_INT(500LL);
}
V g_heff_2eemit_2ebounceDepth_get(void) {
  if (g_heff_2eemit_2ebounceDepth_st == 2) return g_heff_2eemit_2ebounceDepth_val;
  if (g_heff_2eemit_2ebounceDepth_st == 1) heff_fail("defined by itself");
  g_heff_2eemit_2ebounceDepth_st = 1;
  g_heff_2eemit_2ebounceDepth_val = heff_tr(g_heff_2eemit_2ebounceDepth_init());
  g_heff_2eemit_2ebounceDepth_st = 2;
  return g_heff_2eemit_2ebounceDepth_val;
}
Clo g_heff_2eemit_2eatomGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemit_2eatomGo_entry, 2, 0};

V g_heff_2eemit_2eatomGo(V v_c_240, V v_i_241) {
top: ;
  V v_t_242 = heff_intLe(heff_strLength(heff_dup(v_c_240)), heff_dup(v_i_241));
  switch (heff_tag_of(v_t_242)) {
  case TAG_True: {
    heff_drop(v_c_240);
    heff_drop(v_i_241);
    return NTAG(TAG_True);
  }
  case TAG_False: {
    V v_t_243 = (g_heff_2eemit_2eisWordCode(heff_strCharCode(heff_dup(v_c_240), heff_dup(v_i_241))));
    switch (heff_tag_of(v_t_243)) {
    case TAG_True: {
      V t_0 = v_c_240;
      V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
      v_c_240 = t_0;
      v_i_241 = t_1;
      goto top;
    }
    case TAG_False: {
      V v_t_244 = heff_intEq(heff_strCharCode(heff_dup(v_c_240), heff_dup(v_i_241)), MK_INT(36LL));
      switch (heff_tag_of(v_t_244)) {
      case TAG_True: {
        V t_0 = v_c_240;
        V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
        v_c_240 = t_0;
        v_i_241 = t_1;
        goto top;
      }
      case TAG_False: {
        heff_drop(v_c_240);
        heff_drop(v_i_241);
        return NTAG(TAG_False);
      }
      default: return heff_nomatch(v_t_244);
      }
    }
    default: return heff_nomatch(v_t_243);
    }
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2eemit_2eatomGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2eemit_2eatomGo(a[0], a[1]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemit_2enamedAs_str0 = {{0x80000000u, K_STR, 0}, 2, 2, {32, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2enamedAs_str1 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2eemit_2enamedAs_str2 = {{0x80000000u, K_STR, 0}, 6, 6, {99, 111, 110, 115, 116, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemit_2enamedAs_str3 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 61, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2enamedAs_str4 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
Clo g_heff_2eemit_2enamedAs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemit_2enamedAs_entry, 3, 0};

V g_heff_2eemit_2enamedAs(V v_ind_240, V v_c_241, V v_nb_242) {
top: ;
  V v_x2_243 = (g_prelude_2ereplicate(v_ind_240, ((V)&g_heff_2eemit_2enamedAs_str0)));
  V v_t_246;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    v_t_246 = ((V)&g_heff_2eemit_2enamedAs_str1);
    break;
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_xs_245 = heff_field(v_x2_243, 1);
    heff_take_n(v_x2_243, 3ULL, 2);
    v_t_246 = ({ V a_0 = v_x_244; V a_1 = v_xs_245; V r_ = (g_prelude_2efoldl_24s46(a_0, a_1)); heff_drop(v_xs_245); r_; });
    break;
  }
  default: heff_nomatch(v_x2_243);
  }
  V v_t_247 = heff_strAppend(v_t_246, heff_strAppend(((V)&g_heff_2eemit_2enamedAs_str2), heff_strAppend(heff_get(heff_dup(v_nb_242), LBL_js), heff_strAppend(((V)&g_heff_2eemit_2enamedAs_str3), heff_strAppend(heff_get(v_c_241, LBL_code), ((V)&g_heff_2eemit_2enamedAs_str4))))));
  V v_t_248 = heff_tag(TAG_Cons, 2, (V[]){v_t_247, NTAG(TAG_Nil)});
  return heff_rec(3, shape_150_251_87, (V[]){heff_get(heff_dup(v_nb_242), LBL_js), v_t_248, heff_get(v_nb_242, LBL_env)});
}
V g_heff_2eemit_2enamedAs_entry(V self, V *a) {
  (void)self;
  return g_heff_2eemit_2enamedAs(a[0], a[1], a[2]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2enamed_str0 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
Clo g_heff_2eemit_2enamed_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemit_2enamed_entry, 4, 0};

V g_heff_2eemit_2enamed(V v_env_240, V v_ind_241, V v_base_242, V v_c_243) {
top: ;
  V v_c_244 = heff_get(heff_dup(v_c_243), LBL_code);
  V v_t_245 = heff_strEq(heff_dup(v_c_244), ((V)&g_heff_2eemit_2enamed_str0));
  switch (heff_tag_of(v_t_245)) {
  case TAG_True: {
    heff_drop(v_c_244);
    V v_t_246 = (g_heff_2eemit_2ebindName(v_env_240, v_base_242));
    return (g_heff_2eemit_2enamedAs(v_ind_241, v_c_243, v_t_246));
  }
  case TAG_False: {
    V v_t_247 = (g_heff_2eemit_2eatomGo(v_c_244, MK_INT(0LL)));
    switch (heff_tag_of(v_t_247)) {
    case TAG_True: {
      heff_drop(v_ind_241);
      heff_drop(v_base_242);
      return heff_rec(3, shape_150_251_87, (V[]){heff_get(v_c_243, LBL_code), NTAG(TAG_Nil), v_env_240});
    }
    case TAG_False: {
      V v_t_248 = (g_heff_2eemit_2ebindName(v_env_240, v_base_242));
      return (g_heff_2eemit_2enamedAs(v_ind_241, v_c_243, v_t_248));
    }
    default: return heff_nomatch(v_t_247);
    }
  }
  default: return heff_nomatch(v_t_245);
  }
}
V g_heff_2eemit_2enamed_entry(V self, V *a) {
  (void)self;
  return g_heff_2eemit_2enamed(a[0], a[1], a[2], a[3]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemit_2ebounceGive_str0 = {{0x80000000u, K_STR, 0}, 2, 2, {32, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2ebounceGive_str1 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[16]; } g_heff_2eemit_2ebounceGive_str2 = {{0x80000000u, K_STR, 0}, 16, 16, {114, 101, 116, 117, 114, 110, 32, 43, 43, 36, 100, 101, 112, 32, 62, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[12]; } g_heff_2eemit_2ebounceGive_str3 = {{0x80000000u, K_STR, 0}, 12, 12, {32, 63, 32, 110, 101, 119, 32, 36, 66, 110, 99, 40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemit_2ebounceGive_str4 = {{0x80000000u, K_STR, 0}, 2, 2, {44, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eemit_2ebounceGive_str5 = {{0x80000000u, K_STR, 0}, 4, 4, {41, 32, 58, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2ebounceGive_str6 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemit_2ebounceGive_str7 = {{0x80000000u, K_STR, 0}, 2, 2, {41, 59}};
Clo g_heff_2eemit_2ebounceGive_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemit_2ebounceGive_entry, 3, 0};

V g_heff_2eemit_2ebounceGive(V v_ind_240, V v_f_241, V v_a_242) {
top: ;
  V v_x2_243 = (g_prelude_2ereplicate(v_ind_240, ((V)&g_heff_2eemit_2ebounceGive_str0)));
  V v_t_246;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    v_t_246 = ((V)&g_heff_2eemit_2ebounceGive_str1);
    break;
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_xs_245 = heff_field(v_x2_243, 1);
    heff_take_n(v_x2_243, 3ULL, 2);
    v_t_246 = ({ V a_0 = v_x_244; V a_1 = v_xs_245; V r_ = (g_prelude_2efoldl_24s46(a_0, a_1)); heff_drop(v_xs_245); r_; });
    break;
  }
  default: heff_nomatch(v_x2_243);
  }
  V v_t_247 = heff_strAppend(v_t_246, heff_strAppend(((V)&g_heff_2eemit_2ebounceGive_str2), heff_strAppend(heff_intShow(heff_dup(g_heff_2eemit_2ebounceDepth_get())), heff_strAppend(((V)&g_heff_2eemit_2ebounceGive_str3), heff_strAppend(heff_get(heff_dup(v_f_241), LBL_js), heff_strAppend(((V)&g_heff_2eemit_2ebounceGive_str4), heff_strAppend(heff_get(heff_dup(v_a_242), LBL_js), heff_strAppend(((V)&g_heff_2eemit_2ebounceGive_str5), heff_strAppend(heff_get(heff_dup(v_f_241), LBL_js), heff_strAppend(((V)&g_heff_2eemit_2ebounceGive_str6), heff_strAppend(heff_get(heff_dup(v_a_242), LBL_js), ((V)&g_heff_2eemit_2ebounceGive_str7))))))))))));
  V v_t_248 = heff_tag(TAG_Cons, 2, (V[]){v_t_247, NTAG(TAG_Nil)});
  V v_t_249 = (g_prelude_2econcatList(heff_get(v_a_242, LBL_pre), v_t_248));
  return (g_prelude_2econcatList(heff_get(v_f_241, LBL_pre), v_t_249));
}
V g_heff_2eemit_2ebounceGive_entry(V self, V *a) {
  (void)self;
  return g_heff_2eemit_2ebounceGive(a[0], a[1], a[2]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2eemit_2enamed_24s578_str0 = {{0x80000000u, K_STR, 0}, 6, 6, {36, 102, 111, 114, 99, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2eemit_2enamed_24s578_str1 = {{0x80000000u, K_STR, 0}, 6, 6, {36, 102, 111, 114, 99, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemit_2enamed_24s578_str2 = {{0x80000000u, K_STR, 0}, 2, 2, {32, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2enamed_24s578_str3 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2eemit_2enamed_24s578_str4 = {{0x80000000u, K_STR, 0}, 6, 6, {99, 111, 110, 115, 116, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[10]; } g_heff_2eemit_2enamed_24s578_str5 = {{0x80000000u, K_STR, 0}, 10, 10, {32, 61, 32, 36, 102, 111, 114, 99, 101, 59}};
Clo g_heff_2eemit_2enamed_24s578_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemit_2enamed_24s578_entry, 3, 0};

V g_heff_2eemit_2enamed_24s578(V v_env_240, V v_ind_241, V v_base_242) {
top: ;
  V v_t_243 = (g_heff_2eemit_2eatomGo(((V)&g_heff_2eemit_2enamed_24s578_str0), MK_INT(0LL)));
  switch (heff_tag_of(v_t_243)) {
  case TAG_True: {
    heff_drop(v_ind_241);
    heff_drop(v_base_242);
    return heff_rec(3, shape_150_251_87, (V[]){((V)&g_heff_2eemit_2enamed_24s578_str1), NTAG(TAG_Nil), v_env_240});
  }
  case TAG_False: {
    V v_nb_244 = (g_heff_2eemit_2ebindName(v_env_240, v_base_242));
    V v_x2_245 = (g_prelude_2ereplicate(v_ind_241, ((V)&g_heff_2eemit_2enamed_24s578_str2)));
    V v_t_248;
    switch (heff_tag_of(v_x2_245)) {
    case TAG_Nil: {
      v_t_248 = ((V)&g_heff_2eemit_2enamed_24s578_str3);
      break;
    }
    case TAG_Cons: {
      V v_x_246 = heff_field(v_x2_245, 0);
      V v_xs_247 = heff_field(v_x2_245, 1);
      heff_take_n(v_x2_245, 3ULL, 2);
      v_t_248 = ({ V a_0 = v_x_246; V a_1 = v_xs_247; V r_ = (g_prelude_2efoldl_24s46(a_0, a_1)); heff_drop(v_xs_247); r_; });
      break;
    }
    default: heff_nomatch(v_x2_245);
    }
    V v_t_249 = heff_strAppend(v_t_248, heff_strAppend(((V)&g_heff_2eemit_2enamed_24s578_str4), heff_strAppend(heff_get(heff_dup(v_nb_244), LBL_js), ((V)&g_heff_2eemit_2enamed_24s578_str5))));
    V v_t_2410 = heff_tag(TAG_Cons, 2, (V[]){v_t_249, NTAG(TAG_Nil)});
    return heff_rec(3, shape_150_251_87, (V[]){heff_get(heff_dup(v_nb_244), LBL_js), v_t_2410, heff_get(v_nb_244, LBL_env)});
  }
  default: return heff_nomatch(v_t_243);
  }
}
V g_heff_2eemit_2enamed_24s578_entry(V self, V *a) {
  (void)self;
  return g_heff_2eemit_2enamed_24s578(a[0], a[1], a[2]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2ewrapper_str0 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2ewrapper_str1 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2eemit_2ewrapper_str2 = {{0x80000000u, K_STR, 0}, 6, 6, {99, 111, 110, 115, 116, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eemit_2ewrapper_str3 = {{0x80000000u, K_STR, 0}, 5, 5, {36, 99, 32, 61, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2ewrapper_str4 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemit_2ewrapper_str5 = {{0x80000000u, K_STR, 0}, 2, 2, {41, 59}};
Clo g_heff_2eemit_2ewrapper_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemit_2ewrapper_entry, 4, 0};

V g_heff_2eemit_2ewrapper(V v_curried_240, V v_key_241, V v_i_242, V v_js_243) {
top: ;
  V v_t_244 = heff_intLe(MK_INT(2LL), heff_get(heff_dup(v_i_242), LBL_arity));
  switch (heff_tag_of(v_t_244)) {
  case TAG_True: {
    V v_x3_245 = (g_map_2elookup_24s9(v_key_241, v_curried_240));
    switch (heff_tag_of(v_x3_245)) {
    case TAG_Nothing: {
      heff_drop(v_i_242);
      heff_drop(v_js_243);
      return NTAG(TAG_Nil);
    }
    case TAG_Just: {
      heff_take_n(v_x3_245, 0ULL, 1);
      V v_x2_247 = (g_prelude_2emap_24s577(heff_dup(v_js_243)));
      V v_t_2410;
      switch (heff_tag_of(v_x2_247)) {
      case TAG_Nil: {
        v_t_2410 = ((V)&g_heff_2eemit_2ewrapper_str0);
        break;
      }
      case TAG_Cons: {
        V v_x_248 = heff_field(v_x2_247, 0);
        V v_xs_249 = heff_field(v_x2_247, 1);
        heff_take_n(v_x2_247, 3ULL, 2);
        v_t_2410 = ({ V a_0 = v_x_248; V a_1 = v_xs_249; V r_ = (g_prelude_2efoldl_24s46(a_0, a_1)); heff_drop(v_xs_249); r_; });
        break;
      }
      default: heff_nomatch(v_x2_247);
      }
      V v_t_2413;
      switch (heff_tag_of(v_js_243)) {
      case TAG_Nil: {
        v_t_2413 = ((V)&g_heff_2eemit_2ewrapper_str1);
        break;
      }
      case TAG_Cons: {
        V v_x_2411 = heff_field(v_js_243, 0);
        V v_xs_2412 = heff_field(v_js_243, 1);
        heff_take_n(v_js_243, 3ULL, 2);
        v_t_2413 = ({ V a_0 = v_x_2411; V a_1 = v_xs_2412; V r_ = (g_prelude_2efoldl_24s45(a_0, a_1)); heff_drop(v_xs_2412); r_; });
        break;
      }
      default: heff_nomatch(v_js_243);
      }
      V v_t_2414 = heff_strAppend(((V)&g_heff_2eemit_2ewrapper_str2), heff_strAppend(heff_get(heff_dup(v_i_242), LBL_js), heff_strAppend(((V)&g_heff_2eemit_2ewrapper_str3), heff_strAppend(v_t_2410, heff_strAppend(heff_get(v_i_242, LBL_js), heff_strAppend(((V)&g_heff_2eemit_2ewrapper_str4), heff_strAppend(v_t_2413, ((V)&g_heff_2eemit_2ewrapper_str5))))))));
      return heff_tag(TAG_Cons, 2, (V[]){v_t_2414, NTAG(TAG_Nil)});
    }
    default: return heff_nomatch(v_x3_245);
    }
  }
  case TAG_False: {
    heff_drop(v_key_241);
    heff_drop(v_i_242);
    heff_drop(v_js_243);
    return NTAG(TAG_Nil);
  }
  default: return heff_nomatch(v_t_244);
  }
}
V g_heff_2eemit_2ewrapper_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eemit_2ewrapper(a[0], a[1], a[2], a[3]); heff_drop(a[0]); return r;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemit_2estmtsLet2_24s582_str0 = {{0x80000000u, K_STR, 0}, 2, 2, {32, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2estmtsLet2_24s582_str1 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2eemit_2estmtsLet2_24s582_str2 = {{0x80000000u, K_STR, 0}, 6, 6, {99, 111, 110, 115, 116, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemit_2estmtsLet2_24s582_str3 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 61, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2estmtsLet2_24s582_str4 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
Clo g_heff_2eemit_2estmtsLet2_24s582_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemit_2estmtsLet2_24s582_entry, 4, 0};

V g_heff_2eemit_2estmtsLet2_24s582(V v_ind_240, V v_b_241, V v_ac_242, V v_nb_243) {
top: ;
  V v_x2_244 = (g_prelude_2ereplicate(heff_dup(v_ind_240), ((V)&g_heff_2eemit_2estmtsLet2_24s582_str0)));
  V v_t_247;
  switch (heff_tag_of(v_x2_244)) {
  case TAG_Nil: {
    v_t_247 = ((V)&g_heff_2eemit_2estmtsLet2_24s582_str1);
    break;
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x2_244, 0);
    V v_xs_246 = heff_field(v_x2_244, 1);
    heff_take_n(v_x2_244, 3ULL, 2);
    v_t_247 = ({ V a_0 = v_x_245; V a_1 = v_xs_246; V r_ = (g_prelude_2efoldl_24s46(a_0, a_1)); heff_drop(v_xs_246); r_; });
    break;
  }
  default: heff_nomatch(v_x2_244);
  }
  V v_t_248 = heff_strAppend(v_t_247, heff_strAppend(((V)&g_heff_2eemit_2estmtsLet2_24s582_str2), heff_strAppend(heff_get(heff_dup(v_nb_243), LBL_js), heff_strAppend(((V)&g_heff_2eemit_2estmtsLet2_24s582_str3), heff_strAppend(heff_get(v_ac_242, LBL_code), ((V)&g_heff_2eemit_2estmtsLet2_24s582_str4))))));
  return heff_tag(TAG_Cons, 2, (V[]){v_t_248, (g_heff_2eemit_2estmtsF_24s581(heff_get(v_nb_243, LBL_env), v_ind_240, v_b_241))});
}
V g_heff_2eemit_2estmtsLet2_24s582_entry(V self, V *a) {
  (void)self;
  return g_heff_2eemit_2estmtsLet2_24s582(a[0], a[1], a[2], a[3]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2epredOfPrim_24s588_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2epredOfPrim_24s588_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[13]; } g_heff_2eemit_2epredOfPrim_24s588_str2 = {{0x80000000u, K_STR, 0}, 13, 13, {46, 36, 32, 61, 61, 61, 32, 34, 84, 114, 117, 101, 34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2epredOfPrim_24s588_str3 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2epredOfPrim_24s588_str4 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[13]; } g_heff_2eemit_2epredOfPrim_24s588_str5 = {{0x80000000u, K_STR, 0}, 13, 13, {46, 36, 32, 61, 61, 61, 32, 34, 84, 114, 117, 101, 34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2epredOfPrim_24s588_str6 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2epredOfPrim_24s588_str7 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[13]; } g_heff_2eemit_2epredOfPrim_24s588_str8 = {{0x80000000u, K_STR, 0}, 13, 13, {46, 36, 32, 61, 61, 61, 32, 34, 84, 114, 117, 101, 34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2epredOfPrim_24s588_str9 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2epredOfPrim_24s588_str10 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2epredOfPrim_24s588_str11 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2epredOfPrim_24s588_str12 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2epredOfPrim_24s588_str13 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2epredOfPrim_24s588_str14 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2epredOfPrim_24s588_str15 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2epredOfPrim_24s588_str16 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[13]; } g_heff_2eemit_2epredOfPrim_24s588_str17 = {{0x80000000u, K_STR, 0}, 13, 13, {46, 36, 32, 61, 61, 61, 32, 34, 84, 114, 117, 101, 34}};
Clo g_heff_2eemit_2epredOfPrim_24s588_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemit_2epredOfPrim_24s588_entry, 5, 0};

V g_heff_2eemit_2epredOfPrim_24s588(V v_env_240, V v_ind_241, V v_e_242, V v_p_243, V v_as_244) {
top: ;
  V v_t_245 = (g_heff_2eemit_2eprimRel(v_p_243));
  switch (heff_tag_of(v_t_245)) {
  case TAG_Nothing: {
    V v_t_246 = heff_rec(4, shape_120_200_361_295, (V[]){heff_get(heff_dup(v_env_240), LBL_gs), heff_get(heff_dup(v_env_240), LBL_names), heff_get(v_env_240, LBL_used), NTAG(TAG_Nothing)});
    V v_c_247 = heff_tr(g_heff_2eemit_2eexprGo_24s585(v_t_246, v_ind_241, v_e_242));
    V v_t_248 = heff_intLt(heff_get(heff_dup(v_c_247), LBL_prec), MK_INT(3LL));
    V v_t_249;
    switch (heff_tag_of(v_t_248)) {
    case TAG_True: {
      v_t_249 = heff_strAppend(((V)&g_heff_2eemit_2epredOfPrim_24s588_str0), heff_strAppend(heff_get(v_c_247, LBL_code), ((V)&g_heff_2eemit_2epredOfPrim_24s588_str1)));
      break;
    }
    case TAG_False: {
      v_t_249 = heff_get(v_c_247, LBL_code);
      break;
    }
    default: heff_nomatch(v_t_248);
    }
    return heff_tag(TAG_PRel, 1, (V[]){heff_strAppend(v_t_249, ((V)&g_heff_2eemit_2epredOfPrim_24s588_str2))});
  }
  case TAG_Just: {
    V v_op_2410 = heff_field(v_t_245, 0);
    V v_ru_24t_245_24Just = heff_take_reuse_n(v_t_245, 1ULL, 1);
    switch (heff_tag_of(v_as_244)) {
    case TAG_Nil: {
      heff_drop(v_op_2410);
      V v_t_2411 = heff_rec(4, shape_120_200_361_295, (V[]){heff_get(heff_dup(v_env_240), LBL_gs), heff_get(heff_dup(v_env_240), LBL_names), heff_get(v_env_240, LBL_used), NTAG(TAG_Nothing)});
      V v_c_2412 = heff_tr(g_heff_2eemit_2eexprGo_24s585(v_t_2411, v_ind_241, v_e_242));
      V v_t_2413 = heff_intLt(heff_get(heff_dup(v_c_2412), LBL_prec), MK_INT(3LL));
      V v_t_2414;
      switch (heff_tag_of(v_t_2413)) {
      case TAG_True: {
        v_t_2414 = heff_strAppend(((V)&g_heff_2eemit_2epredOfPrim_24s588_str3), heff_strAppend(heff_get(v_c_2412, LBL_code), ((V)&g_heff_2eemit_2epredOfPrim_24s588_str4)));
        break;
      }
      case TAG_False: {
        v_t_2414 = heff_get(v_c_2412, LBL_code);
        break;
      }
      default: heff_nomatch(v_t_2413);
      }
      return heff_tag_at(v_ru_24t_245_24Just, TAG_PRel, 1, (V[]){heff_strAppend(v_t_2414, ((V)&g_heff_2eemit_2epredOfPrim_24s588_str5))});
    }
    case TAG_Cons: {
      V v_a_2415 = heff_field(v_as_244, 0);
      V v_it2_2416 = heff_field(v_as_244, 1);
      switch (heff_tag_of(v_it2_2416)) {
      case TAG_Nil: {
        heff_drop(v_op_2410);
        V v_t_2417 = heff_rec(4, shape_120_200_361_295, (V[]){heff_get(heff_dup(v_env_240), LBL_gs), heff_get(heff_dup(v_env_240), LBL_names), heff_get(v_env_240, LBL_used), NTAG(TAG_Nothing)});
        V v_c_2418 = heff_tr(g_heff_2eemit_2eexprGo_24s585(v_t_2417, v_ind_241, v_e_242));
        V v_t_2419 = heff_intLt(heff_get(heff_dup(v_c_2418), LBL_prec), MK_INT(3LL));
        V v_t_2420;
        switch (heff_tag_of(v_t_2419)) {
        case TAG_True: {
          v_t_2420 = heff_strAppend(((V)&g_heff_2eemit_2epredOfPrim_24s588_str6), heff_strAppend(heff_get(v_c_2418, LBL_code), ((V)&g_heff_2eemit_2epredOfPrim_24s588_str7)));
          break;
        }
        case TAG_False: {
          v_t_2420 = heff_get(v_c_2418, LBL_code);
          break;
        }
        default: heff_nomatch(v_t_2419);
        }
        return heff_tag_at(v_ru_24t_245_24Just, TAG_PRel, 1, (V[]){heff_strAppend(v_t_2420, ((V)&g_heff_2eemit_2epredOfPrim_24s588_str8))});
      }
      case TAG_Cons: {
        V v_b_2421 = heff_field(v_it2_2416, 0);
        V v_it22_2422 = heff_field(v_it2_2416, 1);
        switch (heff_tag_of(v_it22_2422)) {
        case TAG_Nil: {
          heff_drop(v_e_242);
          V v_t_2423 = heff_rec(4, shape_120_200_361_295, (V[]){heff_get(heff_dup(v_env_240), LBL_gs), heff_get(heff_dup(v_env_240), LBL_names), heff_get(heff_dup(v_env_240), LBL_used), NTAG(TAG_Nothing)});
          V v_c_2424 = heff_tr(g_heff_2eemit_2eexprGo_24s585(v_t_2423, heff_dup(v_ind_241), heff_dup(v_a_2415)));
          V v_t_2425 = heff_intLt(heff_get(heff_dup(v_c_2424), LBL_prec), MK_INT(2LL));
          V v_t_2426;
          switch (heff_tag_of(v_t_2425)) {
          case TAG_True: {
            v_t_2426 = heff_strAppend(((V)&g_heff_2eemit_2epredOfPrim_24s588_str9), heff_strAppend(heff_get(v_c_2424, LBL_code), ((V)&g_heff_2eemit_2epredOfPrim_24s588_str10)));
            break;
          }
          case TAG_False: {
            v_t_2426 = heff_get(v_c_2424, LBL_code);
            break;
          }
          default: heff_nomatch(v_t_2425);
          }
          V v_t_2427 = heff_rec(4, shape_120_200_361_295, (V[]){heff_get(heff_dup(v_env_240), LBL_gs), heff_get(heff_dup(v_env_240), LBL_names), heff_get(v_env_240, LBL_used), NTAG(TAG_Nothing)});
          V v_c_2428 = heff_tr(g_heff_2eemit_2eexprGo_24s585(v_t_2427, v_ind_241, heff_dup(v_b_2421)));
          V v_t_2429 = heff_intLt(heff_get(heff_dup(v_c_2428), LBL_prec), MK_INT(2LL));
          V v_t_2430;
          switch (heff_tag_of(v_t_2429)) {
          case TAG_True: {
            v_t_2430 = heff_strAppend(((V)&g_heff_2eemit_2epredOfPrim_24s588_str11), heff_strAppend(heff_get(v_c_2428, LBL_code), ((V)&g_heff_2eemit_2epredOfPrim_24s588_str12)));
            break;
          }
          case TAG_False: {
            v_t_2430 = heff_get(v_c_2428, LBL_code);
            break;
          }
          default: heff_nomatch(v_t_2429);
          }
          V v_t_2431 = heff_strAppend(v_t_2426, heff_strAppend(((V)&g_heff_2eemit_2epredOfPrim_24s588_str13), heff_strAppend(v_op_2410, heff_strAppend(((V)&g_heff_2eemit_2epredOfPrim_24s588_str14), v_t_2430))));
          return heff_tag_at(v_ru_24t_245_24Just, TAG_PRel, 1, (V[]){v_t_2431});
        }
        case TAG_Cons: {
          heff_drop(v_op_2410);
          V v_t_2434 = heff_rec(4, shape_120_200_361_295, (V[]){heff_get(heff_dup(v_env_240), LBL_gs), heff_get(heff_dup(v_env_240), LBL_names), heff_get(v_env_240, LBL_used), NTAG(TAG_Nothing)});
          V v_c_2435 = heff_tr(g_heff_2eemit_2eexprGo_24s585(v_t_2434, v_ind_241, v_e_242));
          V v_t_2436 = heff_intLt(heff_get(heff_dup(v_c_2435), LBL_prec), MK_INT(3LL));
          V v_t_2437;
          switch (heff_tag_of(v_t_2436)) {
          case TAG_True: {
            v_t_2437 = heff_strAppend(((V)&g_heff_2eemit_2epredOfPrim_24s588_str15), heff_strAppend(heff_get(v_c_2435, LBL_code), ((V)&g_heff_2eemit_2epredOfPrim_24s588_str16)));
            break;
          }
          case TAG_False: {
            v_t_2437 = heff_get(v_c_2435, LBL_code);
            break;
          }
          default: heff_nomatch(v_t_2436);
          }
          return heff_tag_at(v_ru_24t_245_24Just, TAG_PRel, 1, (V[]){heff_strAppend(v_t_2437, ((V)&g_heff_2eemit_2epredOfPrim_24s588_str17))});
        }
        default: return heff_nomatch(v_it22_2422);
        }
      }
      default: return heff_nomatch(v_it2_2416);
      }
    }
    default: return heff_nomatch(v_as_244);
    }
  }
  default: return heff_nomatch(v_t_245);
  }
}
V g_heff_2eemit_2epredOfPrim_24s588_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eemit_2epredOfPrim_24s588(a[0], a[1], a[2], a[3], a[4]); heff_drop(a[4]); return r;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2epredOf_24s587_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2epredOf_24s587_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[13]; } g_heff_2eemit_2epredOf_24s587_str2 = {{0x80000000u, K_STR, 0}, 13, 13, {46, 36, 32, 61, 61, 61, 32, 34, 84, 114, 117, 101, 34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2epredOf_24s587_str3 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2epredOf_24s587_str4 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[13]; } g_heff_2eemit_2epredOf_24s587_str5 = {{0x80000000u, K_STR, 0}, 13, 13, {46, 36, 32, 61, 61, 61, 32, 34, 84, 114, 117, 101, 34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2epredOf_24s587_str6 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2epredOf_24s587_str7 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[13]; } g_heff_2eemit_2epredOf_24s587_str8 = {{0x80000000u, K_STR, 0}, 13, 13, {46, 36, 32, 61, 61, 61, 32, 34, 84, 114, 117, 101, 34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2epredOf_24s587_str9 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2epredOf_24s587_str10 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[13]; } g_heff_2eemit_2epredOf_24s587_str11 = {{0x80000000u, K_STR, 0}, 13, 13, {46, 36, 32, 61, 61, 61, 32, 34, 84, 114, 117, 101, 34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2epredOf_24s587_str12 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2epredOf_24s587_str13 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[13]; } g_heff_2eemit_2epredOf_24s587_str14 = {{0x80000000u, K_STR, 0}, 13, 13, {46, 36, 32, 61, 61, 61, 32, 34, 84, 114, 117, 101, 34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2epredOf_24s587_str15 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2epredOf_24s587_str16 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[13]; } g_heff_2eemit_2epredOf_24s587_str17 = {{0x80000000u, K_STR, 0}, 13, 13, {46, 36, 32, 61, 61, 61, 32, 34, 84, 114, 117, 101, 34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eemit_2epredOf_24s587_str18 = {{0x80000000u, K_STR, 0}, 4, 4, {84, 114, 117, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eemit_2epredOf_24s587_str19 = {{0x80000000u, K_STR, 0}, 5, 5, {70, 97, 108, 115, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2epredOf_24s587_str20 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2epredOf_24s587_str21 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[13]; } g_heff_2eemit_2epredOf_24s587_str22 = {{0x80000000u, K_STR, 0}, 13, 13, {46, 36, 32, 61, 61, 61, 32, 34, 84, 114, 117, 101, 34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2epredOf_24s587_str23 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2epredOf_24s587_str24 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[13]; } g_heff_2eemit_2epredOf_24s587_str25 = {{0x80000000u, K_STR, 0}, 13, 13, {46, 36, 32, 61, 61, 61, 32, 34, 84, 114, 117, 101, 34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eemit_2epredOf_24s587_str26 = {{0x80000000u, K_STR, 0}, 4, 4, {84, 114, 117, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eemit_2epredOf_24s587_str27 = {{0x80000000u, K_STR, 0}, 5, 5, {70, 97, 108, 115, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2epredOf_24s587_str28 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2epredOf_24s587_str29 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[13]; } g_heff_2eemit_2epredOf_24s587_str30 = {{0x80000000u, K_STR, 0}, 13, 13, {46, 36, 32, 61, 61, 61, 32, 34, 84, 114, 117, 101, 34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2epredOf_24s587_str31 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2epredOf_24s587_str32 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[13]; } g_heff_2eemit_2epredOf_24s587_str33 = {{0x80000000u, K_STR, 0}, 13, 13, {46, 36, 32, 61, 61, 61, 32, 34, 84, 114, 117, 101, 34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2epredOf_24s587_str34 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2epredOf_24s587_str35 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[13]; } g_heff_2eemit_2epredOf_24s587_str36 = {{0x80000000u, K_STR, 0}, 13, 13, {46, 36, 32, 61, 61, 61, 32, 34, 84, 114, 117, 101, 34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2epredOf_24s587_str37 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2epredOf_24s587_str38 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[13]; } g_heff_2eemit_2epredOf_24s587_str39 = {{0x80000000u, K_STR, 0}, 13, 13, {46, 36, 32, 61, 61, 61, 32, 34, 84, 114, 117, 101, 34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2epredOf_24s587_str40 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2epredOf_24s587_str41 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[13]; } g_heff_2eemit_2epredOf_24s587_str42 = {{0x80000000u, K_STR, 0}, 13, 13, {46, 36, 32, 61, 61, 61, 32, 34, 84, 114, 117, 101, 34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2epredOf_24s587_str43 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2epredOf_24s587_str44 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[13]; } g_heff_2eemit_2epredOf_24s587_str45 = {{0x80000000u, K_STR, 0}, 13, 13, {46, 36, 32, 61, 61, 61, 32, 34, 84, 114, 117, 101, 34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2epredOf_24s587_str46 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2epredOf_24s587_str47 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[13]; } g_heff_2eemit_2epredOf_24s587_str48 = {{0x80000000u, K_STR, 0}, 13, 13, {46, 36, 32, 61, 61, 61, 32, 34, 84, 114, 117, 101, 34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2epredOf_24s587_str49 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2epredOf_24s587_str50 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[13]; } g_heff_2eemit_2epredOf_24s587_str51 = {{0x80000000u, K_STR, 0}, 13, 13, {46, 36, 32, 61, 61, 61, 32, 34, 84, 114, 117, 101, 34}};
Clo g_heff_2eemit_2epredOf_24s587_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemit_2epredOf_24s587_entry, 3, 0};

V g_heff_2eemit_2epredOf_24s587(V v_env_240, V v_ind_241, V v_e_242) {
top: ;
  switch (heff_tag_of(v_e_242)) {
  case TAG_EVar: {
    V v_t_244 = heff_rec(4, shape_120_200_361_295, (V[]){heff_get(heff_dup(v_env_240), LBL_gs), heff_get(heff_dup(v_env_240), LBL_names), heff_get(v_env_240, LBL_used), NTAG(TAG_Nothing)});
    V v_c_245 = heff_tr(g_heff_2eemit_2eexprGo_24s585(v_t_244, v_ind_241, v_e_242));
    V v_t_246 = heff_intLt(heff_get(heff_dup(v_c_245), LBL_prec), MK_INT(3LL));
    V v_t_247;
    switch (heff_tag_of(v_t_246)) {
    case TAG_True: {
      v_t_247 = heff_strAppend(((V)&g_heff_2eemit_2epredOf_24s587_str0), heff_strAppend(heff_get(v_c_245, LBL_code), ((V)&g_heff_2eemit_2epredOf_24s587_str1)));
      break;
    }
    case TAG_False: {
      v_t_247 = heff_get(v_c_245, LBL_code);
      break;
    }
    default: heff_nomatch(v_t_246);
    }
    return heff_tag(TAG_PRel, 1, (V[]){heff_strAppend(v_t_247, ((V)&g_heff_2eemit_2epredOf_24s587_str2))});
  }
  case TAG_EGlobal: {
    V v_t_249 = heff_rec(4, shape_120_200_361_295, (V[]){heff_get(heff_dup(v_env_240), LBL_gs), heff_get(heff_dup(v_env_240), LBL_names), heff_get(v_env_240, LBL_used), NTAG(TAG_Nothing)});
    V v_c_2410 = heff_tr(g_heff_2eemit_2eexprGo_24s585(v_t_249, v_ind_241, v_e_242));
    V v_t_2411 = heff_intLt(heff_get(heff_dup(v_c_2410), LBL_prec), MK_INT(3LL));
    V v_t_2412;
    switch (heff_tag_of(v_t_2411)) {
    case TAG_True: {
      v_t_2412 = heff_strAppend(((V)&g_heff_2eemit_2epredOf_24s587_str3), heff_strAppend(heff_get(v_c_2410, LBL_code), ((V)&g_heff_2eemit_2epredOf_24s587_str4)));
      break;
    }
    case TAG_False: {
      v_t_2412 = heff_get(v_c_2410, LBL_code);
      break;
    }
    default: heff_nomatch(v_t_2411);
    }
    return heff_tag(TAG_PRel, 1, (V[]){heff_strAppend(v_t_2412, ((V)&g_heff_2eemit_2epredOf_24s587_str5))});
  }
  case TAG_ELam: {
    V v_t_2415 = heff_rec(4, shape_120_200_361_295, (V[]){heff_get(heff_dup(v_env_240), LBL_gs), heff_get(heff_dup(v_env_240), LBL_names), heff_get(v_env_240, LBL_used), NTAG(TAG_Nothing)});
    V v_c_2416 = heff_tr(g_heff_2eemit_2eexprGo_24s585(v_t_2415, v_ind_241, v_e_242));
    V v_t_2417 = heff_intLt(heff_get(heff_dup(v_c_2416), LBL_prec), MK_INT(3LL));
    V v_t_2418;
    switch (heff_tag_of(v_t_2417)) {
    case TAG_True: {
      v_t_2418 = heff_strAppend(((V)&g_heff_2eemit_2epredOf_24s587_str6), heff_strAppend(heff_get(v_c_2416, LBL_code), ((V)&g_heff_2eemit_2epredOf_24s587_str7)));
      break;
    }
    case TAG_False: {
      v_t_2418 = heff_get(v_c_2416, LBL_code);
      break;
    }
    default: heff_nomatch(v_t_2417);
    }
    return heff_tag(TAG_PRel, 1, (V[]){heff_strAppend(v_t_2418, ((V)&g_heff_2eemit_2epredOf_24s587_str8))});
  }
  case TAG_EApp: {
    V v_t_2421 = heff_rec(4, shape_120_200_361_295, (V[]){heff_get(heff_dup(v_env_240), LBL_gs), heff_get(heff_dup(v_env_240), LBL_names), heff_get(v_env_240, LBL_used), NTAG(TAG_Nothing)});
    V v_c_2422 = heff_tr(g_heff_2eemit_2eexprGo_24s585(v_t_2421, v_ind_241, v_e_242));
    V v_t_2423 = heff_intLt(heff_get(heff_dup(v_c_2422), LBL_prec), MK_INT(3LL));
    V v_t_2424;
    switch (heff_tag_of(v_t_2423)) {
    case TAG_True: {
      v_t_2424 = heff_strAppend(((V)&g_heff_2eemit_2epredOf_24s587_str9), heff_strAppend(heff_get(v_c_2422, LBL_code), ((V)&g_heff_2eemit_2epredOf_24s587_str10)));
      break;
    }
    case TAG_False: {
      v_t_2424 = heff_get(v_c_2422, LBL_code);
      break;
    }
    default: heff_nomatch(v_t_2423);
    }
    return heff_tag(TAG_PRel, 1, (V[]){heff_strAppend(v_t_2424, ((V)&g_heff_2eemit_2epredOf_24s587_str11))});
  }
  case TAG_ELet: {
    V v_x_2425 = heff_field(v_e_242, 0);
    V v_a_2426 = heff_field(v_e_242, 1);
    V v_b_2427 = heff_field(v_e_242, 2);
    V v_ru_24e_242_24ELet = heff_take_reuse_n(v_e_242, 7ULL, 3);
    V v_t_2428 = heff_rec(4, shape_120_200_361_295, (V[]){heff_get(heff_dup(v_env_240), LBL_gs), heff_get(heff_dup(v_env_240), LBL_names), heff_get(heff_dup(v_env_240), LBL_used), NTAG(TAG_Nothing)});
    V v_t_2429 = heff_tr(g_heff_2eemit_2eexprGo_24s585(v_t_2428, heff_dup(v_ind_241), v_a_2426));
    V v_a_2430 = heff_get(v_t_2429, LBL_code);
    V v_nb_2431 = (g_heff_2eemit_2ebindName(v_env_240, v_x_2425));
    return heff_tag_at(v_ru_24e_242_24ELet, TAG_PSeq, 3, (V[]){heff_get(heff_dup(v_nb_2431), LBL_js), v_a_2430, (g_heff_2eemit_2epredOf_24s587(heff_get(v_nb_2431, LBL_env), v_ind_241, v_b_2427))});
  }
  case TAG_ERecord: {
    V v_t_2433 = heff_rec(4, shape_120_200_361_295, (V[]){heff_get(heff_dup(v_env_240), LBL_gs), heff_get(heff_dup(v_env_240), LBL_names), heff_get(v_env_240, LBL_used), NTAG(TAG_Nothing)});
    V v_c_2434 = heff_tr(g_heff_2eemit_2eexprGo_24s585(v_t_2433, v_ind_241, v_e_242));
    V v_t_2435 = heff_intLt(heff_get(heff_dup(v_c_2434), LBL_prec), MK_INT(3LL));
    V v_t_2436;
    switch (heff_tag_of(v_t_2435)) {
    case TAG_True: {
      v_t_2436 = heff_strAppend(((V)&g_heff_2eemit_2epredOf_24s587_str12), heff_strAppend(heff_get(v_c_2434, LBL_code), ((V)&g_heff_2eemit_2epredOf_24s587_str13)));
      break;
    }
    case TAG_False: {
      v_t_2436 = heff_get(v_c_2434, LBL_code);
      break;
    }
    default: heff_nomatch(v_t_2435);
    }
    return heff_tag(TAG_PRel, 1, (V[]){heff_strAppend(v_t_2436, ((V)&g_heff_2eemit_2epredOf_24s587_str14))});
  }
  case TAG_EProj: {
    V v_t_2439 = heff_rec(4, shape_120_200_361_295, (V[]){heff_get(heff_dup(v_env_240), LBL_gs), heff_get(heff_dup(v_env_240), LBL_names), heff_get(v_env_240, LBL_used), NTAG(TAG_Nothing)});
    V v_c_2440 = heff_tr(g_heff_2eemit_2eexprGo_24s585(v_t_2439, v_ind_241, v_e_242));
    V v_t_2441 = heff_intLt(heff_get(heff_dup(v_c_2440), LBL_prec), MK_INT(3LL));
    V v_t_2442;
    switch (heff_tag_of(v_t_2441)) {
    case TAG_True: {
      v_t_2442 = heff_strAppend(((V)&g_heff_2eemit_2epredOf_24s587_str15), heff_strAppend(heff_get(v_c_2440, LBL_code), ((V)&g_heff_2eemit_2epredOf_24s587_str16)));
      break;
    }
    case TAG_False: {
      v_t_2442 = heff_get(v_c_2440, LBL_code);
      break;
    }
    default: heff_nomatch(v_t_2441);
    }
    return heff_tag(TAG_PRel, 1, (V[]){heff_strAppend(v_t_2442, ((V)&g_heff_2eemit_2epredOf_24s587_str17))});
  }
  case TAG_ETag: {
    V v_t_2443 = heff_dup(heff_field(v_e_242, 0));
    V v_it2_2444 = heff_dup(heff_field(v_e_242, 1));
    switch (heff_tag_of(v_it2_2444)) {
    case TAG_Nil: {
      V v_t_2445 = heff_strEq(heff_dup(v_t_2443), ((V)&g_heff_2eemit_2epredOf_24s587_str18));
      switch (heff_tag_of(v_t_2445)) {
      case TAG_True: {
        heff_drop(v_env_240);
        heff_drop(v_ind_241);
        heff_drop_tag(v_e_242, 2);
        heff_drop(v_t_2443);
        return NTAG(TAG_PTrue);
      }
      case TAG_False: {
        V v_t_2446 = heff_strEq(v_t_2443, ((V)&g_heff_2eemit_2epredOf_24s587_str19));
        switch (heff_tag_of(v_t_2446)) {
        case TAG_True: {
          heff_drop(v_env_240);
          heff_drop(v_ind_241);
          heff_drop_tag(v_e_242, 2);
          return NTAG(TAG_PFalse);
        }
        case TAG_False: {
          V v_t_2447 = heff_rec(4, shape_120_200_361_295, (V[]){heff_get(heff_dup(v_env_240), LBL_gs), heff_get(heff_dup(v_env_240), LBL_names), heff_get(v_env_240, LBL_used), NTAG(TAG_Nothing)});
          V v_c_2448 = heff_tr(g_heff_2eemit_2eexprGo_24s585(v_t_2447, v_ind_241, v_e_242));
          V v_t_2449 = heff_intLt(heff_get(heff_dup(v_c_2448), LBL_prec), MK_INT(3LL));
          V v_t_2450;
          switch (heff_tag_of(v_t_2449)) {
          case TAG_True: {
            v_t_2450 = heff_strAppend(((V)&g_heff_2eemit_2epredOf_24s587_str20), heff_strAppend(heff_get(v_c_2448, LBL_code), ((V)&g_heff_2eemit_2epredOf_24s587_str21)));
            break;
          }
          case TAG_False: {
            v_t_2450 = heff_get(v_c_2448, LBL_code);
            break;
          }
          default: heff_nomatch(v_t_2449);
          }
          return heff_tag(TAG_PRel, 1, (V[]){heff_strAppend(v_t_2450, ((V)&g_heff_2eemit_2epredOf_24s587_str22))});
        }
        default: return heff_nomatch(v_t_2446);
        }
      }
      default: return heff_nomatch(v_t_2445);
      }
    }
    case TAG_Cons: {
      heff_take_n(v_it2_2444, 0ULL, 2);
      heff_drop(v_t_2443);
      V v_t_2453 = heff_rec(4, shape_120_200_361_295, (V[]){heff_get(heff_dup(v_env_240), LBL_gs), heff_get(heff_dup(v_env_240), LBL_names), heff_get(v_env_240, LBL_used), NTAG(TAG_Nothing)});
      V v_c_2454 = heff_tr(g_heff_2eemit_2eexprGo_24s585(v_t_2453, v_ind_241, v_e_242));
      V v_t_2455 = heff_intLt(heff_get(heff_dup(v_c_2454), LBL_prec), MK_INT(3LL));
      V v_t_2456;
      switch (heff_tag_of(v_t_2455)) {
      case TAG_True: {
        v_t_2456 = heff_strAppend(((V)&g_heff_2eemit_2epredOf_24s587_str23), heff_strAppend(heff_get(v_c_2454, LBL_code), ((V)&g_heff_2eemit_2epredOf_24s587_str24)));
        break;
      }
      case TAG_False: {
        v_t_2456 = heff_get(v_c_2454, LBL_code);
        break;
      }
      default: heff_nomatch(v_t_2455);
      }
      return heff_tag(TAG_PRel, 1, (V[]){heff_strAppend(v_t_2456, ((V)&g_heff_2eemit_2epredOf_24s587_str25))});
    }
    default: return heff_nomatch(v_it2_2444);
    }
  }
  case TAG_EMatch: {
    V v_s_2457 = heff_dup(heff_field(v_e_242, 0));
    V v_arms_2458 = heff_dup(heff_field(v_e_242, 1));
    V v_t_2459 = (g_prelude_2efoldl_24s1(MK_INT(0LL), v_arms_2458));
    V v_t_2460 = heff_intEq(v_t_2459, MK_INT(2LL));
    V v_it_2465;
    switch (heff_tag_of(v_t_2460)) {
    case TAG_True: {
      V v_t_2461 = (g_heff_2eemit_2earmNamed(((V)&g_heff_2eemit_2epredOf_24s587_str26), v_arms_2458));
      switch (heff_tag_of(v_t_2461)) {
      case TAG_Nothing: {
        heff_drop(v_arms_2458);
        v_it_2465 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Just: {
        V v_t_2462 = heff_field(v_t_2461, 0);
        V v_ru_24t_2461_24Just = heff_take_reuse_n(v_t_2461, 1ULL, 1);
        V v_t_2463 = ({ V a_0 = ((V)&g_heff_2eemit_2epredOf_24s587_str27); V a_1 = v_arms_2458; V r_ = (g_heff_2eemit_2earmNamed(a_0, a_1)); heff_drop(v_arms_2458); r_; });
        switch (heff_tag_of(v_t_2463)) {
        case TAG_Nothing: {
          heff_drop(v_t_2462);
          heff_drop_cell(v_ru_24t_2461_24Just, 1);
          v_it_2465 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_Just: {
          V v_f_2464 = heff_field(v_t_2463, 0);
          heff_take_n(v_t_2463, 1ULL, 1);
          v_it_2465 = heff_tag_at(v_ru_24t_2461_24Just, TAG_Just, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_t_2462, v_f_2464})});
          break;
        }
        default: heff_nomatch(v_t_2463);
        }
        break;
      }
      default: heff_nomatch(v_t_2461);
      }
      break;
    }
    case TAG_False: {
      heff_drop(v_arms_2458);
      v_it_2465 = NTAG(TAG_Nothing);
      break;
    }
    default: heff_nomatch(v_t_2460);
    }
    switch (heff_tag_of(v_it_2465)) {
    case TAG_Nothing: {
      heff_drop(v_s_2457);
      V v_t_2466 = heff_rec(4, shape_120_200_361_295, (V[]){heff_get(heff_dup(v_env_240), LBL_gs), heff_get(heff_dup(v_env_240), LBL_names), heff_get(v_env_240, LBL_used), NTAG(TAG_Nothing)});
      V v_c_2467 = heff_tr(g_heff_2eemit_2eexprGo_24s585(v_t_2466, v_ind_241, v_e_242));
      V v_t_2468 = heff_intLt(heff_get(heff_dup(v_c_2467), LBL_prec), MK_INT(3LL));
      V v_t_2469;
      switch (heff_tag_of(v_t_2468)) {
      case TAG_True: {
        v_t_2469 = heff_strAppend(((V)&g_heff_2eemit_2epredOf_24s587_str28), heff_strAppend(heff_get(v_c_2467, LBL_code), ((V)&g_heff_2eemit_2epredOf_24s587_str29)));
        break;
      }
      case TAG_False: {
        v_t_2469 = heff_get(v_c_2467, LBL_code);
        break;
      }
      default: heff_nomatch(v_t_2468);
      }
      return heff_tag(TAG_PRel, 1, (V[]){heff_strAppend(v_t_2469, ((V)&g_heff_2eemit_2epredOf_24s587_str30))});
    }
    case TAG_Just: {
      V v_it1_2470 = heff_field(v_it_2465, 0);
      heff_take_n(v_it_2465, 1ULL, 1);
      heff_drop_tag(v_e_242, 2);
      switch (heff_tag_of(v_it1_2470)) {
      case TAG_MkPair: {
        V v_t_2471 = heff_field(v_it1_2470, 0);
        V v_f_2472 = heff_field(v_it1_2470, 1);
        heff_take_n(v_it1_2470, 3ULL, 2);
        V v_t_2473 = (g_heff_2eemit_2epredOf_24s587(heff_dup(v_env_240), heff_dup(v_ind_241), v_s_2457));
        V v_t_2474 = (g_heff_2eemit_2epredOf_24s587(heff_dup(v_env_240), heff_dup(v_ind_241), v_t_2471));
        V v_t_2475 = (g_heff_2eemit_2epredOf_24s587(v_env_240, v_ind_241, v_f_2472));
        HEFF_LAST return g_heff_2eemit_2econdIf(v_t_2473, v_t_2474, v_t_2475);
      }
      default: return heff_nomatch(v_it1_2470);
      }
    }
    default: return heff_nomatch(v_it_2465);
    }
  }
  case TAG_EPrim: {
    V v_t_2477 = heff_rec(4, shape_120_200_361_295, (V[]){heff_get(heff_dup(v_env_240), LBL_gs), heff_get(heff_dup(v_env_240), LBL_names), heff_get(v_env_240, LBL_used), NTAG(TAG_Nothing)});
    V v_c_2478 = heff_tr(g_heff_2eemit_2eexprGo_24s585(v_t_2477, v_ind_241, v_e_242));
    V v_t_2479 = heff_intLt(heff_get(heff_dup(v_c_2478), LBL_prec), MK_INT(3LL));
    V v_t_2480;
    switch (heff_tag_of(v_t_2479)) {
    case TAG_True: {
      v_t_2480 = heff_strAppend(((V)&g_heff_2eemit_2epredOf_24s587_str31), heff_strAppend(heff_get(v_c_2478, LBL_code), ((V)&g_heff_2eemit_2epredOf_24s587_str32)));
      break;
    }
    case TAG_False: {
      v_t_2480 = heff_get(v_c_2478, LBL_code);
      break;
    }
    default: heff_nomatch(v_t_2479);
    }
    return heff_tag(TAG_PRel, 1, (V[]){heff_strAppend(v_t_2480, ((V)&g_heff_2eemit_2epredOf_24s587_str33))});
  }
  case TAG_EPrimCall: {
    V v_p_2481 = heff_dup(heff_field(v_e_242, 0));
    V v_as_2482 = heff_dup(heff_field(v_e_242, 1));
    return ({ V a_0 = v_env_240; V a_1 = v_ind_241; V a_2 = v_e_242; V a_3 = v_p_2481; V a_4 = v_as_2482; V r_ = (g_heff_2eemit_2epredOfPrim_24s588(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_as_2482); r_; });
  }
  case TAG_ECall: {
    V v_t_2485 = heff_rec(4, shape_120_200_361_295, (V[]){heff_get(heff_dup(v_env_240), LBL_gs), heff_get(heff_dup(v_env_240), LBL_names), heff_get(v_env_240, LBL_used), NTAG(TAG_Nothing)});
    V v_c_2486 = heff_tr(g_heff_2eemit_2eexprGo_24s585(v_t_2485, v_ind_241, v_e_242));
    V v_t_2487 = heff_intLt(heff_get(heff_dup(v_c_2486), LBL_prec), MK_INT(3LL));
    V v_t_2488;
    switch (heff_tag_of(v_t_2487)) {
    case TAG_True: {
      v_t_2488 = heff_strAppend(((V)&g_heff_2eemit_2epredOf_24s587_str34), heff_strAppend(heff_get(v_c_2486, LBL_code), ((V)&g_heff_2eemit_2epredOf_24s587_str35)));
      break;
    }
    case TAG_False: {
      v_t_2488 = heff_get(v_c_2486, LBL_code);
      break;
    }
    default: heff_nomatch(v_t_2487);
    }
    return heff_tag(TAG_PRel, 1, (V[]){heff_strAppend(v_t_2488, ((V)&g_heff_2eemit_2epredOf_24s587_str36))});
  }
  case TAG_EInt: {
    V v_t_2490 = heff_rec(4, shape_120_200_361_295, (V[]){heff_get(heff_dup(v_env_240), LBL_gs), heff_get(heff_dup(v_env_240), LBL_names), heff_get(v_env_240, LBL_used), NTAG(TAG_Nothing)});
    V v_c_2491 = heff_tr(g_heff_2eemit_2eexprGo_24s585(v_t_2490, v_ind_241, v_e_242));
    V v_t_2492 = heff_intLt(heff_get(heff_dup(v_c_2491), LBL_prec), MK_INT(3LL));
    V v_t_2493;
    switch (heff_tag_of(v_t_2492)) {
    case TAG_True: {
      v_t_2493 = heff_strAppend(((V)&g_heff_2eemit_2epredOf_24s587_str37), heff_strAppend(heff_get(v_c_2491, LBL_code), ((V)&g_heff_2eemit_2epredOf_24s587_str38)));
      break;
    }
    case TAG_False: {
      v_t_2493 = heff_get(v_c_2491, LBL_code);
      break;
    }
    default: heff_nomatch(v_t_2492);
    }
    return heff_tag(TAG_PRel, 1, (V[]){heff_strAppend(v_t_2493, ((V)&g_heff_2eemit_2epredOf_24s587_str39))});
  }
  case TAG_EFloat: {
    V v_t_2495 = heff_rec(4, shape_120_200_361_295, (V[]){heff_get(heff_dup(v_env_240), LBL_gs), heff_get(heff_dup(v_env_240), LBL_names), heff_get(v_env_240, LBL_used), NTAG(TAG_Nothing)});
    V v_c_2496 = heff_tr(g_heff_2eemit_2eexprGo_24s585(v_t_2495, v_ind_241, v_e_242));
    V v_t_2497 = heff_intLt(heff_get(heff_dup(v_c_2496), LBL_prec), MK_INT(3LL));
    V v_t_2498;
    switch (heff_tag_of(v_t_2497)) {
    case TAG_True: {
      v_t_2498 = heff_strAppend(((V)&g_heff_2eemit_2epredOf_24s587_str40), heff_strAppend(heff_get(v_c_2496, LBL_code), ((V)&g_heff_2eemit_2epredOf_24s587_str41)));
      break;
    }
    case TAG_False: {
      v_t_2498 = heff_get(v_c_2496, LBL_code);
      break;
    }
    default: heff_nomatch(v_t_2497);
    }
    return heff_tag(TAG_PRel, 1, (V[]){heff_strAppend(v_t_2498, ((V)&g_heff_2eemit_2epredOf_24s587_str42))});
  }
  case TAG_EStr: {
    V v_t_24100 = heff_rec(4, shape_120_200_361_295, (V[]){heff_get(heff_dup(v_env_240), LBL_gs), heff_get(heff_dup(v_env_240), LBL_names), heff_get(v_env_240, LBL_used), NTAG(TAG_Nothing)});
    V v_c_24101 = heff_tr(g_heff_2eemit_2eexprGo_24s585(v_t_24100, v_ind_241, v_e_242));
    V v_t_24102 = heff_intLt(heff_get(heff_dup(v_c_24101), LBL_prec), MK_INT(3LL));
    V v_t_24103;
    switch (heff_tag_of(v_t_24102)) {
    case TAG_True: {
      v_t_24103 = heff_strAppend(((V)&g_heff_2eemit_2epredOf_24s587_str43), heff_strAppend(heff_get(v_c_24101, LBL_code), ((V)&g_heff_2eemit_2epredOf_24s587_str44)));
      break;
    }
    case TAG_False: {
      v_t_24103 = heff_get(v_c_24101, LBL_code);
      break;
    }
    default: heff_nomatch(v_t_24102);
    }
    return heff_tag(TAG_PRel, 1, (V[]){heff_strAppend(v_t_24103, ((V)&g_heff_2eemit_2epredOf_24s587_str45))});
  }
  case TAG_EAbandon: {
    V v_t_24104 = heff_rec(4, shape_120_200_361_295, (V[]){heff_get(heff_dup(v_env_240), LBL_gs), heff_get(heff_dup(v_env_240), LBL_names), heff_get(v_env_240, LBL_used), NTAG(TAG_Nothing)});
    V v_c_24105 = heff_tr(g_heff_2eemit_2eexprGo_24s585(v_t_24104, v_ind_241, v_e_242));
    V v_t_24106 = heff_intLt(heff_get(heff_dup(v_c_24105), LBL_prec), MK_INT(3LL));
    V v_t_24107;
    switch (heff_tag_of(v_t_24106)) {
    case TAG_True: {
      v_t_24107 = heff_strAppend(((V)&g_heff_2eemit_2epredOf_24s587_str46), heff_strAppend(heff_get(v_c_24105, LBL_code), ((V)&g_heff_2eemit_2epredOf_24s587_str47)));
      break;
    }
    case TAG_False: {
      v_t_24107 = heff_get(v_c_24105, LBL_code);
      break;
    }
    default: heff_nomatch(v_t_24106);
    }
    return heff_tag(TAG_PRel, 1, (V[]){heff_strAppend(v_t_24107, ((V)&g_heff_2eemit_2epredOf_24s587_str48))});
  }
  case TAG_EFix: {
    V v_t_24110 = heff_rec(4, shape_120_200_361_295, (V[]){heff_get(heff_dup(v_env_240), LBL_gs), heff_get(heff_dup(v_env_240), LBL_names), heff_get(v_env_240, LBL_used), NTAG(TAG_Nothing)});
    V v_c_24111 = heff_tr(g_heff_2eemit_2eexprGo_24s585(v_t_24110, v_ind_241, v_e_242));
    V v_t_24112 = heff_intLt(heff_get(heff_dup(v_c_24111), LBL_prec), MK_INT(3LL));
    V v_t_24113;
    switch (heff_tag_of(v_t_24112)) {
    case TAG_True: {
      v_t_24113 = heff_strAppend(((V)&g_heff_2eemit_2epredOf_24s587_str49), heff_strAppend(heff_get(v_c_24111, LBL_code), ((V)&g_heff_2eemit_2epredOf_24s587_str50)));
      break;
    }
    case TAG_False: {
      v_t_24113 = heff_get(v_c_24111, LBL_code);
      break;
    }
    default: heff_nomatch(v_t_24112);
    }
    return heff_tag(TAG_PRel, 1, (V[]){heff_strAppend(v_t_24113, ((V)&g_heff_2eemit_2epredOf_24s587_str51))});
  }
  default: return heff_nomatch(v_e_242);
  }
}
V g_heff_2eemit_2epredOf_24s587_entry(V self, V *a) {
  (void)self;
  return g_heff_2eemit_2epredOf_24s587(a[0], a[1], a[2]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2eblockF_24s589_str0 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemit_2eblockF_24s589_str1 = {{0x80000000u, K_STR, 0}, 2, 2, {32, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2eblockF_24s589_str2 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemit_2eblockF_24s589_str3 = {{0x80000000u, K_STR, 0}, 2, 2, {123, 10}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2eblockF_24s589_str4 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2eblockF_24s589_str5 = {{0x80000000u, K_STR, 0}, 1, 1, {125}};
Clo g_heff_2eemit_2eblockF_24s589_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemit_2eblockF_24s589_entry, 3, 0};

V g_heff_2eemit_2eblockF_24s589(V v_env_240, V v_ind_241, V v_e_242) {
top: ;
  V v_x2_243 = (g_heff_2eemit_2estmtsF_24s581(v_env_240, heff_intAdd(heff_dup(v_ind_241), MK_INT(1LL)), v_e_242));
  V v_t_246;
  switch (heff_tag_of(v_x2_243)) {
  case TAG_Nil: {
    v_t_246 = ((V)&g_heff_2eemit_2eblockF_24s589_str0);
    break;
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_243, 0);
    V v_xs_245 = heff_field(v_x2_243, 1);
    heff_take_n(v_x2_243, 3ULL, 2);
    v_t_246 = ({ V a_0 = v_x_244; V a_1 = v_xs_245; V r_ = (g_prelude_2efoldl_24s3(a_0, a_1)); heff_drop(v_xs_245); r_; });
    break;
  }
  default: heff_nomatch(v_x2_243);
  }
  V v_x2_247 = (g_prelude_2ereplicate(v_ind_241, ((V)&g_heff_2eemit_2eblockF_24s589_str1)));
  V v_t_2410;
  switch (heff_tag_of(v_x2_247)) {
  case TAG_Nil: {
    v_t_2410 = ((V)&g_heff_2eemit_2eblockF_24s589_str2);
    break;
  }
  case TAG_Cons: {
    V v_x_248 = heff_field(v_x2_247, 0);
    V v_xs_249 = heff_field(v_x2_247, 1);
    heff_take_n(v_x2_247, 3ULL, 2);
    v_t_2410 = ({ V a_0 = v_x_248; V a_1 = v_xs_249; V r_ = (g_prelude_2efoldl_24s46(a_0, a_1)); heff_drop(v_xs_249); r_; });
    break;
  }
  default: heff_nomatch(v_x2_247);
  }
  return heff_strAppend(((V)&g_heff_2eemit_2eblockF_24s589_str3), heff_strAppend(v_t_246, heff_strAppend(((V)&g_heff_2eemit_2eblockF_24s589_str4), heff_strAppend(v_t_2410, ((V)&g_heff_2eemit_2eblockF_24s589_str5)))));
}
V g_heff_2eemit_2eblockF_24s589_entry(V self, V *a) {
  (void)self;
  return g_heff_2eemit_2eblockF_24s589(a[0], a[1], a[2]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2eexprTest_24s586_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2eexprTest_24s586_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[10]; } g_heff_2eemit_2eexprTest_24s586_str2 = {{0x80000000u, K_STR, 0}, 10, 10, {32, 63, 32, 36, 84, 32, 58, 32, 36, 70}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2eemit_2eexprTest_24s586_str3 = {{0x80000000u, K_STR, 0}, 7, 7, {40, 40, 41, 32, 61, 62, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemit_2eexprTest_24s586_str4 = {{0x80000000u, K_STR, 0}, 3, 3, {41, 40, 41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2eexprTest_24s586_str5 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2eexprTest_24s586_str6 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2eexprTest_24s586_str7 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2eexprTest_24s586_str8 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2eexprTest_24s586_str9 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2eexprTest_24s586_str10 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemit_2eexprTest_24s586_str11 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 63, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemit_2eexprTest_24s586_str12 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 58, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2eemit_2eexprTest_24s586_str13 = {{0x80000000u, K_STR, 0}, 7, 7, {40, 40, 41, 32, 61, 62, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemit_2eexprTest_24s586_str14 = {{0x80000000u, K_STR, 0}, 3, 3, {41, 40, 41}};
Clo g_heff_2eemit_2eexprTest_24s586_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemit_2eexprTest_24s586_entry, 6, 0};

V g_heff_2eemit_2eexprTest_24s586(V v_env_240, V v_ind_241, V v_e_242, V v_s_243, V v_t_244, V v_f_245) {
top: ;
  V v_t_246 = (g_heff_2eemit_2econdShaped(heff_dup(v_t_244)));
  V v_t_247;
  switch (heff_tag_of(v_t_246)) {
  case TAG_True: {
    v_t_247 = (g_heff_2eemit_2econdShaped(heff_dup(v_f_245)));
    break;
  }
  case TAG_False: {
    v_t_247 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_t_246);
  }
  switch (heff_tag_of(v_t_247)) {
  case TAG_True: {
    heff_drop(v_s_243);
    heff_drop(v_t_244);
    heff_drop(v_f_245);
    V v_c_248 = (g_heff_2eemit_2epredOf_24s587(heff_dup(v_env_240), heff_dup(v_ind_241), heff_dup(v_e_242)));
    V v_x1_249 = (g_heff_2eemit_2eseqsOf(v_c_248));
    switch (heff_tag_of(v_x1_249)) {
    case TAG_Nil: {
      heff_drop(v_env_240);
      heff_drop(v_ind_241);
      heff_drop(v_e_242);
      V v_c_2410 = (g_heff_2eemit_2econdCode(v_c_248));
      V v_t_2411 = heff_intLt(heff_get(heff_dup(v_c_2410), LBL_prec), MK_INT(1LL));
      V v_t_2412;
      switch (heff_tag_of(v_t_2411)) {
      case TAG_True: {
        v_t_2412 = heff_strAppend(((V)&g_heff_2eemit_2eexprTest_24s586_str0), heff_strAppend(heff_get(v_c_2410, LBL_code), ((V)&g_heff_2eemit_2eexprTest_24s586_str1)));
        break;
      }
      case TAG_False: {
        v_t_2412 = heff_get(v_c_2410, LBL_code);
        break;
      }
      default: heff_nomatch(v_t_2411);
      }
      return heff_rec(2, shape_47_252, (V[]){heff_strAppend(v_t_2412, ((V)&g_heff_2eemit_2eexprTest_24s586_str2)), MK_INT(0LL)});
    }
    case TAG_Cons: {
      heff_take_n(v_x1_249, 0ULL, 2);
      heff_drop(v_c_248);
      V v_t_2415 = (g_heff_2eemit_2eblockF_24s589(v_env_240, v_ind_241, v_e_242));
      V v_code_2416 = heff_strAppend(((V)&g_heff_2eemit_2eexprTest_24s586_str3), heff_strAppend(v_t_2415, ((V)&g_heff_2eemit_2eexprTest_24s586_str4)));
      return heff_rec(2, shape_47_252, (V[]){v_code_2416, MK_INT(3LL)});
    }
    default: return heff_nomatch(v_x1_249);
    }
  }
  case TAG_False: {
    V v_c_2417 = (g_heff_2eemit_2epredOf_24s587(heff_dup(v_env_240), heff_dup(v_ind_241), v_s_243));
    V v_x1_2418 = (g_heff_2eemit_2eseqsOf(v_c_2417));
    switch (heff_tag_of(v_x1_2418)) {
    case TAG_Nil: {
      heff_drop(v_e_242);
      V v_c_2419 = (g_heff_2eemit_2econdCode(v_c_2417));
      V v_t_2420 = heff_intLt(heff_get(heff_dup(v_c_2419), LBL_prec), MK_INT(1LL));
      V v_t_2421;
      switch (heff_tag_of(v_t_2420)) {
      case TAG_True: {
        v_t_2421 = heff_strAppend(((V)&g_heff_2eemit_2eexprTest_24s586_str5), heff_strAppend(heff_get(v_c_2419, LBL_code), ((V)&g_heff_2eemit_2eexprTest_24s586_str6)));
        break;
      }
      case TAG_False: {
        v_t_2421 = heff_get(v_c_2419, LBL_code);
        break;
      }
      default: heff_nomatch(v_t_2420);
      }
      V v_t_2422 = heff_rec(4, shape_120_200_361_295, (V[]){heff_get(heff_dup(v_env_240), LBL_gs), heff_get(heff_dup(v_env_240), LBL_names), heff_get(heff_dup(v_env_240), LBL_used), NTAG(TAG_Nothing)});
      V v_c_2423 = heff_tr(g_heff_2eemit_2eexprGo_24s585(v_t_2422, heff_dup(v_ind_241), v_t_244));
      V v_t_2424 = heff_intLt(heff_get(heff_dup(v_c_2423), LBL_prec), MK_INT(1LL));
      V v_t_2425;
      switch (heff_tag_of(v_t_2424)) {
      case TAG_True: {
        v_t_2425 = heff_strAppend(((V)&g_heff_2eemit_2eexprTest_24s586_str7), heff_strAppend(heff_get(v_c_2423, LBL_code), ((V)&g_heff_2eemit_2eexprTest_24s586_str8)));
        break;
      }
      case TAG_False: {
        v_t_2425 = heff_get(v_c_2423, LBL_code);
        break;
      }
      default: heff_nomatch(v_t_2424);
      }
      V v_t_2426 = heff_rec(4, shape_120_200_361_295, (V[]){heff_get(heff_dup(v_env_240), LBL_gs), heff_get(heff_dup(v_env_240), LBL_names), heff_get(v_env_240, LBL_used), NTAG(TAG_Nothing)});
      V v_c_2427 = heff_tr(g_heff_2eemit_2eexprGo_24s585(v_t_2426, v_ind_241, v_f_245));
      V v_t_2428 = heff_intLt(heff_get(heff_dup(v_c_2427), LBL_prec), MK_INT(1LL));
      V v_t_2429;
      switch (heff_tag_of(v_t_2428)) {
      case TAG_True: {
        v_t_2429 = heff_strAppend(((V)&g_heff_2eemit_2eexprTest_24s586_str9), heff_strAppend(heff_get(v_c_2427, LBL_code), ((V)&g_heff_2eemit_2eexprTest_24s586_str10)));
        break;
      }
      case TAG_False: {
        v_t_2429 = heff_get(v_c_2427, LBL_code);
        break;
      }
      default: heff_nomatch(v_t_2428);
      }
      V v_t_2430 = heff_strAppend(v_t_2421, heff_strAppend(((V)&g_heff_2eemit_2eexprTest_24s586_str11), heff_strAppend(v_t_2425, heff_strAppend(((V)&g_heff_2eemit_2eexprTest_24s586_str12), v_t_2429))));
      return heff_rec(2, shape_47_252, (V[]){v_t_2430, MK_INT(0LL)});
    }
    case TAG_Cons: {
      heff_take_n(v_x1_2418, 0ULL, 2);
      heff_drop(v_t_244);
      heff_drop(v_f_245);
      heff_drop(v_c_2417);
      V v_t_2433 = (g_heff_2eemit_2eblockF_24s589(v_env_240, v_ind_241, v_e_242));
      V v_code_2434 = heff_strAppend(((V)&g_heff_2eemit_2eexprTest_24s586_str13), heff_strAppend(v_t_2433, ((V)&g_heff_2eemit_2eexprTest_24s586_str14)));
      return heff_rec(2, shape_47_252, (V[]){v_code_2434, MK_INT(3LL)});
    }
    default: return heff_nomatch(v_x1_2418);
    }
  }
  default: return heff_nomatch(v_t_247);
  }
}
V g_heff_2eemit_2eexprTest_24s586_entry(V self, V *a) {
  (void)self;
  return g_heff_2eemit_2eexprTest_24s586(a[0], a[1], a[2], a[3], a[4], a[5]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2ebodyF_24s590_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {123}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2ebodyF_24s590_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2ebodyF_24s590_str2 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2ebodyF_24s590_str3 = {{0x80000000u, K_STR, 0}, 1, 1, {123}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2ebodyF_24s590_str4 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2ebodyF_24s590_str5 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2ebodyF_24s590_str6 = {{0x80000000u, K_STR, 0}, 1, 1, {123}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2ebodyF_24s590_str7 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2ebodyF_24s590_str8 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2ebodyF_24s590_str9 = {{0x80000000u, K_STR, 0}, 1, 1, {123}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2ebodyF_24s590_str10 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2ebodyF_24s590_str11 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2ebodyF_24s590_str12 = {{0x80000000u, K_STR, 0}, 1, 1, {123}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2ebodyF_24s590_str13 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2ebodyF_24s590_str14 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2ebodyF_24s590_str15 = {{0x80000000u, K_STR, 0}, 1, 1, {123}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2ebodyF_24s590_str16 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2ebodyF_24s590_str17 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2ebodyF_24s590_str18 = {{0x80000000u, K_STR, 0}, 1, 1, {123}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2ebodyF_24s590_str19 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2ebodyF_24s590_str20 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2ebodyF_24s590_str21 = {{0x80000000u, K_STR, 0}, 1, 1, {123}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2ebodyF_24s590_str22 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2ebodyF_24s590_str23 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2ebodyF_24s590_str24 = {{0x80000000u, K_STR, 0}, 1, 1, {123}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2ebodyF_24s590_str25 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2ebodyF_24s590_str26 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2ebodyF_24s590_str27 = {{0x80000000u, K_STR, 0}, 1, 1, {123}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2ebodyF_24s590_str28 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2ebodyF_24s590_str29 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2ebodyF_24s590_str30 = {{0x80000000u, K_STR, 0}, 1, 1, {123}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2ebodyF_24s590_str31 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2ebodyF_24s590_str32 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2ebodyF_24s590_str33 = {{0x80000000u, K_STR, 0}, 1, 1, {123}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2ebodyF_24s590_str34 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2ebodyF_24s590_str35 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2ebodyF_24s590_str36 = {{0x80000000u, K_STR, 0}, 1, 1, {123}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2ebodyF_24s590_str37 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2ebodyF_24s590_str38 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2ebodyF_24s590_str39 = {{0x80000000u, K_STR, 0}, 1, 1, {123}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2ebodyF_24s590_str40 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2ebodyF_24s590_str41 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2ebodyF_24s590_str42 = {{0x80000000u, K_STR, 0}, 1, 1, {123}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2ebodyF_24s590_str43 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2ebodyF_24s590_str44 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
Clo g_heff_2eemit_2ebodyF_24s590_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemit_2ebodyF_24s590_entry, 3, 0};

V g_heff_2eemit_2ebodyF_24s590(V v_env_240, V v_ind_241, V v_e_242) {
top: ;
  switch (heff_tag_of(v_e_242)) {
  case TAG_EVar: {
    V v_t_244 = heff_rec(4, shape_120_200_361_295, (V[]){heff_get(heff_dup(v_env_240), LBL_gs), heff_get(heff_dup(v_env_240), LBL_names), heff_get(v_env_240, LBL_used), NTAG(TAG_Nothing)});
    V v_t_245 = heff_tr(g_heff_2eemit_2eexprGo_24s585(v_t_244, v_ind_241, v_e_242));
    V v_c_246 = heff_get(v_t_245, LBL_code);
    V v_t_247 = heff_strEq(heff_strSlice(heff_dup(v_c_246), MK_INT(0LL), MK_INT(1LL)), ((V)&g_heff_2eemit_2ebodyF_24s590_str0));
    switch (heff_tag_of(v_t_247)) {
    case TAG_True: {
      return heff_strAppend(((V)&g_heff_2eemit_2ebodyF_24s590_str1), heff_strAppend(v_c_246, ((V)&g_heff_2eemit_2ebodyF_24s590_str2)));
    }
    case TAG_False: {
      return v_c_246;
    }
    default: return heff_nomatch(v_t_247);
    }
  }
  case TAG_EGlobal: {
    V v_t_249 = heff_rec(4, shape_120_200_361_295, (V[]){heff_get(heff_dup(v_env_240), LBL_gs), heff_get(heff_dup(v_env_240), LBL_names), heff_get(v_env_240, LBL_used), NTAG(TAG_Nothing)});
    V v_t_2410 = heff_tr(g_heff_2eemit_2eexprGo_24s585(v_t_249, v_ind_241, v_e_242));
    V v_c_2411 = heff_get(v_t_2410, LBL_code);
    V v_t_2412 = heff_strEq(heff_strSlice(heff_dup(v_c_2411), MK_INT(0LL), MK_INT(1LL)), ((V)&g_heff_2eemit_2ebodyF_24s590_str3));
    switch (heff_tag_of(v_t_2412)) {
    case TAG_True: {
      return heff_strAppend(((V)&g_heff_2eemit_2ebodyF_24s590_str4), heff_strAppend(v_c_2411, ((V)&g_heff_2eemit_2ebodyF_24s590_str5)));
    }
    case TAG_False: {
      return v_c_2411;
    }
    default: return heff_nomatch(v_t_2412);
    }
  }
  case TAG_ELam: {
    V v_t_2415 = heff_rec(4, shape_120_200_361_295, (V[]){heff_get(heff_dup(v_env_240), LBL_gs), heff_get(heff_dup(v_env_240), LBL_names), heff_get(v_env_240, LBL_used), NTAG(TAG_Nothing)});
    V v_t_2416 = heff_tr(g_heff_2eemit_2eexprGo_24s585(v_t_2415, v_ind_241, v_e_242));
    V v_c_2417 = heff_get(v_t_2416, LBL_code);
    V v_t_2418 = heff_strEq(heff_strSlice(heff_dup(v_c_2417), MK_INT(0LL), MK_INT(1LL)), ((V)&g_heff_2eemit_2ebodyF_24s590_str6));
    switch (heff_tag_of(v_t_2418)) {
    case TAG_True: {
      return heff_strAppend(((V)&g_heff_2eemit_2ebodyF_24s590_str7), heff_strAppend(v_c_2417, ((V)&g_heff_2eemit_2ebodyF_24s590_str8)));
    }
    case TAG_False: {
      return v_c_2417;
    }
    default: return heff_nomatch(v_t_2418);
    }
  }
  case TAG_EApp: {
    V v_f_2419 = heff_field(v_e_242, 0);
    V v_as_2420 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24EApp = heff_take_reuse_n(v_e_242, 3ULL, 2);
    HEFF_LAST return g_heff_2eemit_2eblockF_24s589(v_env_240, v_ind_241, heff_tag_at(v_ru_24e_242_24EApp, TAG_EApp, 2, (V[]){v_f_2419, v_as_2420}));
  }
  case TAG_ELet: {
    V v_x_2421 = heff_field(v_e_242, 0);
    V v_a_2422 = heff_field(v_e_242, 1);
    V v_b_2423 = heff_field(v_e_242, 2);
    V v_ru_24e_242_24ELet = heff_take_reuse_n(v_e_242, 7ULL, 3);
    HEFF_LAST return g_heff_2eemit_2eblockF_24s589(v_env_240, v_ind_241, heff_tag_at(v_ru_24e_242_24ELet, TAG_ELet, 3, (V[]){v_x_2421, v_a_2422, v_b_2423}));
  }
  case TAG_ERecord: {
    V v_t_2425 = heff_rec(4, shape_120_200_361_295, (V[]){heff_get(heff_dup(v_env_240), LBL_gs), heff_get(heff_dup(v_env_240), LBL_names), heff_get(v_env_240, LBL_used), NTAG(TAG_Nothing)});
    V v_t_2426 = heff_tr(g_heff_2eemit_2eexprGo_24s585(v_t_2425, v_ind_241, v_e_242));
    V v_c_2427 = heff_get(v_t_2426, LBL_code);
    V v_t_2428 = heff_strEq(heff_strSlice(heff_dup(v_c_2427), MK_INT(0LL), MK_INT(1LL)), ((V)&g_heff_2eemit_2ebodyF_24s590_str9));
    switch (heff_tag_of(v_t_2428)) {
    case TAG_True: {
      return heff_strAppend(((V)&g_heff_2eemit_2ebodyF_24s590_str10), heff_strAppend(v_c_2427, ((V)&g_heff_2eemit_2ebodyF_24s590_str11)));
    }
    case TAG_False: {
      return v_c_2427;
    }
    default: return heff_nomatch(v_t_2428);
    }
  }
  case TAG_EProj: {
    V v_t_2431 = heff_rec(4, shape_120_200_361_295, (V[]){heff_get(heff_dup(v_env_240), LBL_gs), heff_get(heff_dup(v_env_240), LBL_names), heff_get(v_env_240, LBL_used), NTAG(TAG_Nothing)});
    V v_t_2432 = heff_tr(g_heff_2eemit_2eexprGo_24s585(v_t_2431, v_ind_241, v_e_242));
    V v_c_2433 = heff_get(v_t_2432, LBL_code);
    V v_t_2434 = heff_strEq(heff_strSlice(heff_dup(v_c_2433), MK_INT(0LL), MK_INT(1LL)), ((V)&g_heff_2eemit_2ebodyF_24s590_str12));
    switch (heff_tag_of(v_t_2434)) {
    case TAG_True: {
      return heff_strAppend(((V)&g_heff_2eemit_2ebodyF_24s590_str13), heff_strAppend(v_c_2433, ((V)&g_heff_2eemit_2ebodyF_24s590_str14)));
    }
    case TAG_False: {
      return v_c_2433;
    }
    default: return heff_nomatch(v_t_2434);
    }
  }
  case TAG_ETag: {
    V v_t_2437 = heff_rec(4, shape_120_200_361_295, (V[]){heff_get(heff_dup(v_env_240), LBL_gs), heff_get(heff_dup(v_env_240), LBL_names), heff_get(v_env_240, LBL_used), NTAG(TAG_Nothing)});
    V v_t_2438 = heff_tr(g_heff_2eemit_2eexprGo_24s585(v_t_2437, v_ind_241, v_e_242));
    V v_c_2439 = heff_get(v_t_2438, LBL_code);
    V v_t_2440 = heff_strEq(heff_strSlice(heff_dup(v_c_2439), MK_INT(0LL), MK_INT(1LL)), ((V)&g_heff_2eemit_2ebodyF_24s590_str15));
    switch (heff_tag_of(v_t_2440)) {
    case TAG_True: {
      return heff_strAppend(((V)&g_heff_2eemit_2ebodyF_24s590_str16), heff_strAppend(v_c_2439, ((V)&g_heff_2eemit_2ebodyF_24s590_str17)));
    }
    case TAG_False: {
      return v_c_2439;
    }
    default: return heff_nomatch(v_t_2440);
    }
  }
  case TAG_EMatch: {
    V v_s_2441 = heff_field(v_e_242, 0);
    V v_arms_2442 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24EMatch = heff_take_reuse_n(v_e_242, 3ULL, 2);
    HEFF_LAST return g_heff_2eemit_2eblockF_24s589(v_env_240, v_ind_241, heff_tag_at(v_ru_24e_242_24EMatch, TAG_EMatch, 2, (V[]){v_s_2441, v_arms_2442}));
  }
  case TAG_EPrim: {
    V v_t_2444 = heff_rec(4, shape_120_200_361_295, (V[]){heff_get(heff_dup(v_env_240), LBL_gs), heff_get(heff_dup(v_env_240), LBL_names), heff_get(v_env_240, LBL_used), NTAG(TAG_Nothing)});
    V v_t_2445 = heff_tr(g_heff_2eemit_2eexprGo_24s585(v_t_2444, v_ind_241, v_e_242));
    V v_c_2446 = heff_get(v_t_2445, LBL_code);
    V v_t_2447 = heff_strEq(heff_strSlice(heff_dup(v_c_2446), MK_INT(0LL), MK_INT(1LL)), ((V)&g_heff_2eemit_2ebodyF_24s590_str18));
    switch (heff_tag_of(v_t_2447)) {
    case TAG_True: {
      return heff_strAppend(((V)&g_heff_2eemit_2ebodyF_24s590_str19), heff_strAppend(v_c_2446, ((V)&g_heff_2eemit_2ebodyF_24s590_str20)));
    }
    case TAG_False: {
      return v_c_2446;
    }
    default: return heff_nomatch(v_t_2447);
    }
  }
  case TAG_EPrimCall: {
    V v_t_2450 = heff_rec(4, shape_120_200_361_295, (V[]){heff_get(heff_dup(v_env_240), LBL_gs), heff_get(heff_dup(v_env_240), LBL_names), heff_get(v_env_240, LBL_used), NTAG(TAG_Nothing)});
    V v_t_2451 = heff_tr(g_heff_2eemit_2eexprGo_24s585(v_t_2450, v_ind_241, v_e_242));
    V v_c_2452 = heff_get(v_t_2451, LBL_code);
    V v_t_2453 = heff_strEq(heff_strSlice(heff_dup(v_c_2452), MK_INT(0LL), MK_INT(1LL)), ((V)&g_heff_2eemit_2ebodyF_24s590_str21));
    switch (heff_tag_of(v_t_2453)) {
    case TAG_True: {
      return heff_strAppend(((V)&g_heff_2eemit_2ebodyF_24s590_str22), heff_strAppend(v_c_2452, ((V)&g_heff_2eemit_2ebodyF_24s590_str23)));
    }
    case TAG_False: {
      return v_c_2452;
    }
    default: return heff_nomatch(v_t_2453);
    }
  }
  case TAG_ECall: {
    V v_g_2454 = heff_dup(heff_field(v_e_242, 0));
    V v_as_2455 = heff_dup(heff_field(v_e_242, 1));
    V v_t_2456 = ({ V a_0 = heff_dup(v_g_2454); V b_1 = heff_get(heff_dup(v_env_240), LBL_gs); V r_ = (g_map_2elookup_24s8(a_0, b_1)); heff_drop(b_1); r_; });
    switch (heff_tag_of(v_t_2456)) {
    case TAG_Nothing: {
      heff_drop(v_g_2454);
      heff_drop(v_as_2455);
      V v_t_2457 = heff_rec(4, shape_120_200_361_295, (V[]){heff_get(heff_dup(v_env_240), LBL_gs), heff_get(heff_dup(v_env_240), LBL_names), heff_get(v_env_240, LBL_used), NTAG(TAG_Nothing)});
      V v_t_2458 = heff_tr(g_heff_2eemit_2eexprGo_24s585(v_t_2457, v_ind_241, v_e_242));
      V v_c_2459 = heff_get(v_t_2458, LBL_code);
      V v_t_2460 = heff_strEq(heff_strSlice(heff_dup(v_c_2459), MK_INT(0LL), MK_INT(1LL)), ((V)&g_heff_2eemit_2ebodyF_24s590_str24));
      switch (heff_tag_of(v_t_2460)) {
      case TAG_True: {
        return heff_strAppend(((V)&g_heff_2eemit_2ebodyF_24s590_str25), heff_strAppend(v_c_2459, ((V)&g_heff_2eemit_2ebodyF_24s590_str26)));
      }
      case TAG_False: {
        return v_c_2459;
      }
      default: return heff_nomatch(v_t_2460);
      }
    }
    case TAG_Just: {
      V v_i_2461 = heff_field(v_t_2456, 0);
      heff_take_n(v_t_2456, 1ULL, 1);
      V v_t_2462 = heff_get(v_i_2461, LBL_bounce);
      switch (heff_tag_of(v_t_2462)) {
      case TAG_True: {
        heff_drop_tag(v_e_242, 2);
        HEFF_LAST return g_heff_2eemit_2eblockF_24s589(v_env_240, v_ind_241, heff_tag(TAG_ECall, 2, (V[]){v_g_2454, v_as_2455}));
      }
      case TAG_False: {
        heff_drop(v_g_2454);
        heff_drop(v_as_2455);
        V v_t_2463 = heff_rec(4, shape_120_200_361_295, (V[]){heff_get(heff_dup(v_env_240), LBL_gs), heff_get(heff_dup(v_env_240), LBL_names), heff_get(v_env_240, LBL_used), NTAG(TAG_Nothing)});
        V v_t_2464 = heff_tr(g_heff_2eemit_2eexprGo_24s585(v_t_2463, v_ind_241, v_e_242));
        V v_c_2465 = heff_get(v_t_2464, LBL_code);
        V v_t_2466 = heff_strEq(heff_strSlice(heff_dup(v_c_2465), MK_INT(0LL), MK_INT(1LL)), ((V)&g_heff_2eemit_2ebodyF_24s590_str27));
        switch (heff_tag_of(v_t_2466)) {
        case TAG_True: {
          return heff_strAppend(((V)&g_heff_2eemit_2ebodyF_24s590_str28), heff_strAppend(v_c_2465, ((V)&g_heff_2eemit_2ebodyF_24s590_str29)));
        }
        case TAG_False: {
          return v_c_2465;
        }
        default: return heff_nomatch(v_t_2466);
        }
      }
      default: return heff_nomatch(v_t_2462);
      }
    }
    default: return heff_nomatch(v_t_2456);
    }
  }
  case TAG_EInt: {
    V v_t_2468 = heff_rec(4, shape_120_200_361_295, (V[]){heff_get(heff_dup(v_env_240), LBL_gs), heff_get(heff_dup(v_env_240), LBL_names), heff_get(v_env_240, LBL_used), NTAG(TAG_Nothing)});
    V v_t_2469 = heff_tr(g_heff_2eemit_2eexprGo_24s585(v_t_2468, v_ind_241, v_e_242));
    V v_c_2470 = heff_get(v_t_2469, LBL_code);
    V v_t_2471 = heff_strEq(heff_strSlice(heff_dup(v_c_2470), MK_INT(0LL), MK_INT(1LL)), ((V)&g_heff_2eemit_2ebodyF_24s590_str30));
    switch (heff_tag_of(v_t_2471)) {
    case TAG_True: {
      return heff_strAppend(((V)&g_heff_2eemit_2ebodyF_24s590_str31), heff_strAppend(v_c_2470, ((V)&g_heff_2eemit_2ebodyF_24s590_str32)));
    }
    case TAG_False: {
      return v_c_2470;
    }
    default: return heff_nomatch(v_t_2471);
    }
  }
  case TAG_EFloat: {
    V v_t_2473 = heff_rec(4, shape_120_200_361_295, (V[]){heff_get(heff_dup(v_env_240), LBL_gs), heff_get(heff_dup(v_env_240), LBL_names), heff_get(v_env_240, LBL_used), NTAG(TAG_Nothing)});
    V v_t_2474 = heff_tr(g_heff_2eemit_2eexprGo_24s585(v_t_2473, v_ind_241, v_e_242));
    V v_c_2475 = heff_get(v_t_2474, LBL_code);
    V v_t_2476 = heff_strEq(heff_strSlice(heff_dup(v_c_2475), MK_INT(0LL), MK_INT(1LL)), ((V)&g_heff_2eemit_2ebodyF_24s590_str33));
    switch (heff_tag_of(v_t_2476)) {
    case TAG_True: {
      return heff_strAppend(((V)&g_heff_2eemit_2ebodyF_24s590_str34), heff_strAppend(v_c_2475, ((V)&g_heff_2eemit_2ebodyF_24s590_str35)));
    }
    case TAG_False: {
      return v_c_2475;
    }
    default: return heff_nomatch(v_t_2476);
    }
  }
  case TAG_EStr: {
    V v_t_2478 = heff_rec(4, shape_120_200_361_295, (V[]){heff_get(heff_dup(v_env_240), LBL_gs), heff_get(heff_dup(v_env_240), LBL_names), heff_get(v_env_240, LBL_used), NTAG(TAG_Nothing)});
    V v_t_2479 = heff_tr(g_heff_2eemit_2eexprGo_24s585(v_t_2478, v_ind_241, v_e_242));
    V v_c_2480 = heff_get(v_t_2479, LBL_code);
    V v_t_2481 = heff_strEq(heff_strSlice(heff_dup(v_c_2480), MK_INT(0LL), MK_INT(1LL)), ((V)&g_heff_2eemit_2ebodyF_24s590_str36));
    switch (heff_tag_of(v_t_2481)) {
    case TAG_True: {
      return heff_strAppend(((V)&g_heff_2eemit_2ebodyF_24s590_str37), heff_strAppend(v_c_2480, ((V)&g_heff_2eemit_2ebodyF_24s590_str38)));
    }
    case TAG_False: {
      return v_c_2480;
    }
    default: return heff_nomatch(v_t_2481);
    }
  }
  case TAG_EAbandon: {
    V v_t_2482 = heff_rec(4, shape_120_200_361_295, (V[]){heff_get(heff_dup(v_env_240), LBL_gs), heff_get(heff_dup(v_env_240), LBL_names), heff_get(v_env_240, LBL_used), NTAG(TAG_Nothing)});
    V v_t_2483 = heff_tr(g_heff_2eemit_2eexprGo_24s585(v_t_2482, v_ind_241, v_e_242));
    V v_c_2484 = heff_get(v_t_2483, LBL_code);
    V v_t_2485 = heff_strEq(heff_strSlice(heff_dup(v_c_2484), MK_INT(0LL), MK_INT(1LL)), ((V)&g_heff_2eemit_2ebodyF_24s590_str39));
    switch (heff_tag_of(v_t_2485)) {
    case TAG_True: {
      return heff_strAppend(((V)&g_heff_2eemit_2ebodyF_24s590_str40), heff_strAppend(v_c_2484, ((V)&g_heff_2eemit_2ebodyF_24s590_str41)));
    }
    case TAG_False: {
      return v_c_2484;
    }
    default: return heff_nomatch(v_t_2485);
    }
  }
  case TAG_EFix: {
    V v_t_2488 = heff_rec(4, shape_120_200_361_295, (V[]){heff_get(heff_dup(v_env_240), LBL_gs), heff_get(heff_dup(v_env_240), LBL_names), heff_get(v_env_240, LBL_used), NTAG(TAG_Nothing)});
    V v_t_2489 = heff_tr(g_heff_2eemit_2eexprGo_24s585(v_t_2488, v_ind_241, v_e_242));
    V v_c_2490 = heff_get(v_t_2489, LBL_code);
    V v_t_2491 = heff_strEq(heff_strSlice(heff_dup(v_c_2490), MK_INT(0LL), MK_INT(1LL)), ((V)&g_heff_2eemit_2ebodyF_24s590_str42));
    switch (heff_tag_of(v_t_2491)) {
    case TAG_True: {
      return heff_strAppend(((V)&g_heff_2eemit_2ebodyF_24s590_str43), heff_strAppend(v_c_2490, ((V)&g_heff_2eemit_2ebodyF_24s590_str44)));
    }
    case TAG_False: {
      return v_c_2490;
    }
    default: return heff_nomatch(v_t_2491);
    }
  }
  default: return heff_nomatch(v_e_242);
  }
}
V g_heff_2eemit_2ebodyF_24s590_entry(V self, V *a) {
  (void)self;
  return g_heff_2eemit_2ebodyF_24s590(a[0], a[1], a[2]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2eexprGo_24s585_str0 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2eexprGo_24s585_str1 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2eexprGo_24s585_str2 = {{0x80000000u, K_STR, 0}, 1, 1, {120}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2eemit_2eexprGo_24s585_str3 = {{0x80000000u, K_STR, 0}, 9, 9, {117, 110, 100, 101, 102, 105, 110, 101, 100}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemit_2eexprGo_24s585_str4 = {{0x80000000u, K_STR, 0}, 2, 2, {36, 99}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemit_2eexprGo_24s585_str5 = {{0x80000000u, K_STR, 0}, 2, 2, {40, 41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2eexprGo_24s585_str6 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2eemit_2eexprGo_24s585_str7 = {{0x80000000u, K_STR, 0}, 7, 7, {36, 102, 111, 114, 99, 101, 40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2eexprGo_24s585_str8 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2eexprGo_24s585_str9 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2eexprGo_24s585_str10 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2eexprGo_24s585_str11 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2eexprGo_24s585_str12 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eemit_2eexprGo_24s585_str13 = {{0x80000000u, K_STR, 0}, 4, 4, {36, 116, 114, 40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2eexprGo_24s585_str14 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2eemit_2eexprGo_24s585_str15 = {{0x80000000u, K_STR, 0}, 7, 7, {40, 40, 41, 32, 61, 62, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemit_2eexprGo_24s585_str16 = {{0x80000000u, K_STR, 0}, 3, 3, {41, 40, 41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eemit_2eexprGo_24s585_str17 = {{0x80000000u, K_STR, 0}, 4, 4, {36, 116, 114, 40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2eexprGo_24s585_str18 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2eexprGo_24s585_str19 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2eexprGo_24s585_str20 = {{0x80000000u, K_STR, 0}, 1, 1, {34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2eexprGo_24s585_str21 = {{0x80000000u, K_STR, 0}, 1, 1, {34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemit_2eexprGo_24s585_str22 = {{0x80000000u, K_STR, 0}, 2, 2, {58, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2eexprGo_24s585_str23 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemit_2eexprGo_24s585_str24 = {{0x80000000u, K_STR, 0}, 2, 2, {123, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemit_2eexprGo_24s585_str25 = {{0x80000000u, K_STR, 0}, 2, 2, {32, 125}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2eexprGo_24s585_str26 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2eexprGo_24s585_str27 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2eexprGo_24s585_str28 = {{0x80000000u, K_STR, 0}, 1, 1, {46}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2eexprGo_24s585_str29 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2eexprGo_24s585_str30 = {{0x80000000u, K_STR, 0}, 1, 1, {34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2eexprGo_24s585_str31 = {{0x80000000u, K_STR, 0}, 1, 1, {34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2eexprGo_24s585_str32 = {{0x80000000u, K_STR, 0}, 1, 1, {91}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2eexprGo_24s585_str33 = {{0x80000000u, K_STR, 0}, 1, 1, {93}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eemit_2eexprGo_24s585_str34 = {{0x80000000u, K_STR, 0}, 4, 4, {84, 114, 117, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemit_2eexprGo_24s585_str35 = {{0x80000000u, K_STR, 0}, 2, 2, {36, 84}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eemit_2eexprGo_24s585_str36 = {{0x80000000u, K_STR, 0}, 5, 5, {70, 97, 108, 115, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemit_2eexprGo_24s585_str37 = {{0x80000000u, K_STR, 0}, 2, 2, {36, 70}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2eexprGo_24s585_str38 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2eexprGo_24s585_str39 = {{0x80000000u, K_STR, 0}, 1, 1, {34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2eexprGo_24s585_str40 = {{0x80000000u, K_STR, 0}, 1, 1, {34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eemit_2eexprGo_24s585_str41 = {{0x80000000u, K_STR, 0}, 5, 5, {123, 32, 36, 58, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2eemit_2eexprGo_24s585_str42 = {{0x80000000u, K_STR, 0}, 9, 9, {44, 32, 97, 58, 32, 91, 93, 32, 125}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2eexprGo_24s585_str43 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2eexprGo_24s585_str44 = {{0x80000000u, K_STR, 0}, 1, 1, {34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2eexprGo_24s585_str45 = {{0x80000000u, K_STR, 0}, 1, 1, {34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2eexprGo_24s585_str46 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eemit_2eexprGo_24s585_str47 = {{0x80000000u, K_STR, 0}, 5, 5, {123, 32, 36, 58, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2eemit_2eexprGo_24s585_str48 = {{0x80000000u, K_STR, 0}, 6, 6, {44, 32, 97, 58, 32, 91}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemit_2eexprGo_24s585_str49 = {{0x80000000u, K_STR, 0}, 3, 3, {93, 32, 125}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eemit_2eexprGo_24s585_str50 = {{0x80000000u, K_STR, 0}, 4, 4, {84, 114, 117, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eemit_2eexprGo_24s585_str51 = {{0x80000000u, K_STR, 0}, 5, 5, {70, 97, 108, 115, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2eemit_2eexprGo_24s585_str52 = {{0x80000000u, K_STR, 0}, 7, 7, {40, 40, 41, 32, 61, 62, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemit_2eexprGo_24s585_str53 = {{0x80000000u, K_STR, 0}, 3, 3, {41, 40, 41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eemit_2eexprGo_24s585_str54 = {{0x80000000u, K_STR, 0}, 4, 4, {36, 116, 114, 40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2eexprGo_24s585_str55 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2eexprGo_24s585_str56 = {{0x80000000u, K_STR, 0}, 1, 1, {36}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemit_2eexprGo_24s585_str57 = {{0x80000000u, K_STR, 0}, 2, 2, {36, 99}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2eemit_2eexprGo_24s585_str58 = {{0x80000000u, K_STR, 0}, 7, 7, {36, 102, 111, 114, 99, 101, 40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2eexprGo_24s585_str59 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2eexprGo_24s585_str60 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2eexprGo_24s585_str61 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2eexprGo_24s585_str62 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eemit_2eexprGo_24s585_str63 = {{0x80000000u, K_STR, 0}, 4, 4, {36, 116, 114, 40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2eexprGo_24s585_str64 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2eexprGo_24s585_str65 = {{0x80000000u, K_STR, 0}, 1, 1, {45}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2eexprGo_24s585_str66 = {{0x80000000u, K_STR, 0}, 1, 1, {110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2eexprGo_24s585_str67 = {{0x80000000u, K_STR, 0}, 1, 1, {110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2eexprGo_24s585_str68 = {{0x80000000u, K_STR, 0}, 1, 1, {45}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2eexprGo_24s585_str69 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2eexprGo_24s585_str70 = {{0x80000000u, K_STR, 0}, 1, 1, {34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2eexprGo_24s585_str71 = {{0x80000000u, K_STR, 0}, 1, 1, {34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[10]; } g_heff_2eemit_2eexprGo_24s585_str72 = {{0x80000000u, K_STR, 0}, 10, 10, {36, 97, 98, 97, 110, 100, 111, 110, 40, 41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[10]; } g_heff_2eemit_2eexprGo_24s585_str73 = {{0x80000000u, K_STR, 0}, 10, 10, {36, 97, 98, 97, 110, 100, 111, 110, 40, 41}};
V g_heff_2eemit_2eexprGo_24s585_lam0(V self, V *args);
V g_heff_2eemit_2eexprGo_24s585_lam1(V self, V *args);
V g_heff_2eemit_2eexprGo_24s585_lam2(V self, V *args);
V g_heff_2eemit_2eexprGo_24s585_lam3(V self, V *args);
V g_heff_2eemit_2eexprGo_24s585_lam4(V self, V *args);
V g_heff_2eemit_2eexprGo_24s585_lam5(V self, V *args);
V g_heff_2eemit_2eexprGo_24s585_lam6(V self, V *args);
Clo g_heff_2eemit_2eexprGo_24s585_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemit_2eexprGo_24s585_entry, 3, 0};

V g_heff_2eemit_2eexprGo_24s585(V v_env_240, V v_ind_241, V v_e_242) {
top: ;
  switch (heff_tag_of(v_e_242)) {
  case TAG_EVar: {
    V v_x_243 = heff_field(v_e_242, 0);
    heff_take_n(v_e_242, 1ULL, 1);
    heff_drop(v_ind_241);
    V v_t_244 = heff_intSub(heff_strLength(heff_dup(v_x_243)), MK_INT(1LL));
    V v_t_245 = (g_heff_2eemit_2elastDotFrom(heff_dup(v_x_243), v_t_244));
    V v_t_246 = (g_heff_2eemit_2espellAt(heff_dup(v_x_243), v_t_245));
    V v_s_247 = (g_heff_2eemit_2esafeChars(v_t_246, MK_INT(0LL), ((V)&g_heff_2eemit_2eexprGo_24s585_str0)));
    V v_t_248 = heff_strEq(heff_dup(v_s_247), ((V)&g_heff_2eemit_2eexprGo_24s585_str1));
    V v_t_249;
    switch (heff_tag_of(v_t_248)) {
    case TAG_True: {
      heff_drop(v_s_247);
      v_t_249 = ((V)&g_heff_2eemit_2eexprGo_24s585_str2);
      break;
    }
    case TAG_False: {
      v_t_249 = v_s_247;
      break;
    }
    default: heff_nomatch(v_t_248);
    }
    V v_d_2410 = (g_heff_2eemit_2esafeRes(v_t_249));
    V v_x2_2411 = ({ V a_0 = v_x_243; V b_1 = heff_get(v_env_240, LBL_names); V r_ = (g_map_2elookup_24s8(a_0, b_1)); heff_drop(b_1); r_; });
    V v_code_2413;
    switch (heff_tag_of(v_x2_2411)) {
    case TAG_Nothing: {
      v_code_2413 = v_d_2410;
      break;
    }
    case TAG_Just: {
      V v_x_2412 = heff_field(v_x2_2411, 0);
      heff_take_n(v_x2_2411, 1ULL, 1);
      heff_drop(v_d_2410);
      v_code_2413 = v_x_2412;
      break;
    }
    default: heff_nomatch(v_x2_2411);
    }
    return heff_rec(2, shape_47_252, (V[]){v_code_2413, MK_INT(3LL)});
  }
  case TAG_EGlobal: {
    V v_g_2414 = heff_field(v_e_242, 0);
    heff_take_n(v_e_242, 1ULL, 1);
    heff_drop(v_ind_241);
    V v_t_2415 = ({ V a_0 = v_g_2414; V b_1 = heff_get(v_env_240, LBL_gs); V r_ = (g_map_2elookup_24s8(a_0, b_1)); heff_drop(b_1); r_; });
    V v_code_2419;
    switch (heff_tag_of(v_t_2415)) {
    case TAG_Nothing: {
      v_code_2419 = ((V)&g_heff_2eemit_2eexprGo_24s585_str3);
      break;
    }
    case TAG_Just: {
      V v_i_2416 = heff_field(v_t_2415, 0);
      heff_take_n(v_t_2415, 1ULL, 1);
      V v_t_2417 = heff_intLe(MK_INT(2LL), heff_get(heff_dup(v_i_2416), LBL_arity));
      switch (heff_tag_of(v_t_2417)) {
      case TAG_True: {
        v_code_2419 = heff_strAppend(heff_get(v_i_2416, LBL_js), ((V)&g_heff_2eemit_2eexprGo_24s585_str4));
        break;
      }
      case TAG_False: {
        V v_t_2418 = heff_get(heff_dup(v_i_2416), LBL_lazy);
        switch (heff_tag_of(v_t_2418)) {
        case TAG_True: {
          v_code_2419 = heff_strAppend(heff_get(v_i_2416, LBL_js), ((V)&g_heff_2eemit_2eexprGo_24s585_str5));
          break;
        }
        case TAG_False: {
          v_code_2419 = heff_get(v_i_2416, LBL_js);
          break;
        }
        default: heff_nomatch(v_t_2418);
        }
        break;
      }
      default: heff_nomatch(v_t_2417);
      }
      break;
    }
    default: heff_nomatch(v_t_2415);
    }
    return heff_rec(2, shape_47_252, (V[]){v_code_2419, MK_INT(3LL)});
  }
  case TAG_ELam: {
    V v_xs_2420 = heff_field(v_e_242, 0);
    V v_b_2421 = heff_field(v_e_242, 1);
    heff_take_n(v_e_242, 3ULL, 2);
    V v_t_2422 = heff_rec(2, shape_150_87, (V[]){NTAG(TAG_Nil), v_env_240});
    V v_rb_2423 = (g_prelude_2efoldl_24s575(v_t_2422, v_xs_2420));
    V v_x2_2424 = (g_prelude_2emap_24s577(heff_get(heff_dup(v_rb_2423), LBL_js)));
    V v_t_2427;
    switch (heff_tag_of(v_x2_2424)) {
    case TAG_Nil: {
      v_t_2427 = ((V)&g_heff_2eemit_2eexprGo_24s585_str6);
      break;
    }
    case TAG_Cons: {
      V v_x_2425 = heff_field(v_x2_2424, 0);
      V v_xs_2426 = heff_field(v_x2_2424, 1);
      heff_take_n(v_x2_2424, 3ULL, 2);
      v_t_2427 = ({ V a_0 = v_x_2425; V a_1 = v_xs_2426; V r_ = (g_prelude_2efoldl_24s46(a_0, a_1)); heff_drop(v_xs_2426); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2424);
    }
    V v_t_2428 = heff_strAppend(v_t_2427, (g_heff_2eemit_2ebodyF_24s590(heff_get(v_rb_2423, LBL_env), v_ind_241, v_b_2421)));
    return heff_rec(2, shape_47_252, (V[]){v_t_2428, MK_INT(0LL)});
  }
  case TAG_EApp: {
    V v_f_2429 = heff_field(v_e_242, 0);
    V v_as_2430 = heff_field(v_e_242, 1);
    heff_take_n(v_e_242, 3ULL, 2);
    V v_t_2431 = (g_heff_2eemit_2eisUnitArgs(v_as_2430));
    switch (heff_tag_of(v_t_2431)) {
    case TAG_True: {
      heff_drop(v_as_2430);
      V v_t_2432 = heff_rec(4, shape_120_200_361_295, (V[]){heff_get(heff_dup(v_env_240), LBL_gs), heff_get(heff_dup(v_env_240), LBL_names), heff_get(v_env_240, LBL_used), NTAG(TAG_Nothing)});
      V v_t_2433 = heff_tr(g_heff_2eemit_2eexprGo_24s585(v_t_2432, v_ind_241, v_f_2429));
      V v_code_2434 = heff_strAppend(((V)&g_heff_2eemit_2eexprGo_24s585_str7), heff_strAppend(heff_get(v_t_2433, LBL_code), ((V)&g_heff_2eemit_2eexprGo_24s585_str8)));
      return heff_rec(2, shape_47_252, (V[]){v_code_2434, MK_INT(3LL)});
    }
    case TAG_False: {
      V v_t_2435 = heff_rec(4, shape_120_200_361_295, (V[]){heff_get(heff_dup(v_env_240), LBL_gs), heff_get(heff_dup(v_env_240), LBL_names), heff_get(heff_dup(v_env_240), LBL_used), NTAG(TAG_Nothing)});
      V v_t_2436 = heff_tr(g_heff_2eemit_2eexprGo_24s585(v_t_2435, heff_dup(v_ind_241), v_f_2429));
      return ({ V a_0 = heff_clo(g_heff_2eemit_2eexprGo_24s585_lam0, 2, 2, (V[]){v_env_240, v_ind_241}); V a_1 = v_t_2436; V a_2 = v_as_2430; V r_ = (g_prelude_2efoldl(a_0, a_1, a_2)); heff_drop(v_as_2430); r_; });
    }
    default: return heff_nomatch(v_t_2431);
    }
  }
  case TAG_ELet: {
    V v_x_2445 = heff_dup(heff_field(v_e_242, 0));
    V v_a_2446 = heff_dup(heff_field(v_e_242, 1));
    V v_b_2447 = heff_dup(heff_field(v_e_242, 2));
    V v_t_2448 = (g_heff_2eemit_2etailApp(v_e_242));
    V v_b_2453;
    switch (heff_tag_of(v_t_2448)) {
    case TAG_True: {
      heff_drop_tag(v_e_242, 3);
      v_b_2453 = NTAG(TAG_True);
      break;
    }
    case TAG_False: {
      V v_t_2449 = (g_heff_2eemit_2etailGlobals(v_e_242));
      v_b_2453 = ({ V a_0 = heff_clo(g_heff_2eemit_2eexprGo_24s585_lam1, 1, 1, (V[]){heff_dup(v_env_240)}); V a_1 = v_t_2449; V r_ = (g_prelude_2eany(a_0, a_1)); heff_drop(v_t_2449); r_; });
      break;
    }
    default: heff_nomatch(v_t_2448);
    }
    V v_t_2454 = (g_heff_2eemit_2eblockF_24s589(v_env_240, v_ind_241, heff_tag(TAG_ELet, 3, (V[]){v_x_2445, v_a_2446, v_b_2447})));
    V v_c_2455 = heff_strAppend(((V)&g_heff_2eemit_2eexprGo_24s585_str15), heff_strAppend(v_t_2454, ((V)&g_heff_2eemit_2eexprGo_24s585_str16)));
    V v_code_2456;
    switch (heff_tag_of(v_b_2453)) {
    case TAG_True: {
      v_code_2456 = heff_strAppend(((V)&g_heff_2eemit_2eexprGo_24s585_str17), heff_strAppend(v_c_2455, ((V)&g_heff_2eemit_2eexprGo_24s585_str18)));
      break;
    }
    case TAG_False: {
      v_code_2456 = v_c_2455;
      break;
    }
    default: heff_nomatch(v_b_2453);
    }
    return heff_rec(2, shape_47_252, (V[]){v_code_2456, MK_INT(3LL)});
  }
  case TAG_ERecord: {
    V v_fs_2457 = heff_field(v_e_242, 0);
    heff_take_n(v_e_242, 1ULL, 1);
    V v_x2_2466 = (g_prelude_2emap(heff_clo(g_heff_2eemit_2eexprGo_24s585_lam2, 1, 2, (V[]){v_env_240, v_ind_241}), v_fs_2457));
    V v_t_2469;
    switch (heff_tag_of(v_x2_2466)) {
    case TAG_Nil: {
      v_t_2469 = ((V)&g_heff_2eemit_2eexprGo_24s585_str23);
      break;
    }
    case TAG_Cons: {
      V v_x_2467 = heff_field(v_x2_2466, 0);
      V v_xs_2468 = heff_field(v_x2_2466, 1);
      heff_take_n(v_x2_2466, 3ULL, 2);
      v_t_2469 = ({ V a_0 = v_x_2467; V a_1 = v_xs_2468; V r_ = (g_prelude_2efoldl_24s45(a_0, a_1)); heff_drop(v_xs_2468); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2466);
    }
    V v_code_2470 = heff_strAppend(((V)&g_heff_2eemit_2eexprGo_24s585_str24), heff_strAppend(v_t_2469, ((V)&g_heff_2eemit_2eexprGo_24s585_str25)));
    return heff_rec(2, shape_47_252, (V[]){v_code_2470, MK_INT(3LL)});
  }
  case TAG_EProj: {
    V v_e2_2471 = heff_field(v_e_242, 0);
    V v_l_2472 = heff_field(v_e_242, 1);
    heff_take_n(v_e_242, 3ULL, 2);
    V v_t_2473 = heff_rec(4, shape_120_200_361_295, (V[]){heff_get(heff_dup(v_env_240), LBL_gs), heff_get(heff_dup(v_env_240), LBL_names), heff_get(v_env_240, LBL_used), NTAG(TAG_Nothing)});
    V v_c_2474 = heff_tr(g_heff_2eemit_2eexprGo_24s585(v_t_2473, v_ind_241, v_e2_2471));
    V v_t_2475 = heff_intLt(heff_get(heff_dup(v_c_2474), LBL_prec), MK_INT(3LL));
    V v_t_2476;
    switch (heff_tag_of(v_t_2475)) {
    case TAG_True: {
      v_t_2476 = heff_strAppend(((V)&g_heff_2eemit_2eexprGo_24s585_str26), heff_strAppend(heff_get(v_c_2474, LBL_code), ((V)&g_heff_2eemit_2eexprGo_24s585_str27)));
      break;
    }
    case TAG_False: {
      v_t_2476 = heff_get(v_c_2474, LBL_code);
      break;
    }
    default: heff_nomatch(v_t_2475);
    }
    V v_t_2477 = (g_heff_2eemit_2eisIdent(heff_dup(v_l_2472)));
    V v_t_2480;
    switch (heff_tag_of(v_t_2477)) {
    case TAG_True: {
      v_t_2480 = heff_strAppend(((V)&g_heff_2eemit_2eexprGo_24s585_str28), v_l_2472);
      break;
    }
    case TAG_False: {
      V v_t_2478 = (g_heff_2eemit_2equoteGo(v_l_2472, MK_INT(0LL), ((V)&g_heff_2eemit_2eexprGo_24s585_str29)));
      V v_t_2479 = heff_strAppend(((V)&g_heff_2eemit_2eexprGo_24s585_str30), heff_strAppend(v_t_2478, ((V)&g_heff_2eemit_2eexprGo_24s585_str31)));
      v_t_2480 = heff_strAppend(((V)&g_heff_2eemit_2eexprGo_24s585_str32), heff_strAppend(v_t_2479, ((V)&g_heff_2eemit_2eexprGo_24s585_str33)));
      break;
    }
    default: heff_nomatch(v_t_2477);
    }
    V v_code_2481 = heff_strAppend(v_t_2476, v_t_2480);
    return heff_rec(2, shape_47_252, (V[]){v_code_2481, MK_INT(3LL)});
  }
  case TAG_ETag: {
    V v_t_2482 = heff_field(v_e_242, 0);
    V v_it2_2483 = heff_field(v_e_242, 1);
    heff_take_n(v_e_242, 3ULL, 2);
    switch (heff_tag_of(v_it2_2483)) {
    case TAG_Nil: {
      heff_drop(v_env_240);
      heff_drop(v_ind_241);
      V v_t_2484 = heff_strEq(heff_dup(v_t_2482), ((V)&g_heff_2eemit_2eexprGo_24s585_str34));
      switch (heff_tag_of(v_t_2484)) {
      case TAG_True: {
        heff_drop(v_t_2482);
        return heff_rec(2, shape_47_252, (V[]){((V)&g_heff_2eemit_2eexprGo_24s585_str35), MK_INT(3LL)});
      }
      case TAG_False: {
        V v_t_2485 = heff_strEq(heff_dup(v_t_2482), ((V)&g_heff_2eemit_2eexprGo_24s585_str36));
        switch (heff_tag_of(v_t_2485)) {
        case TAG_True: {
          heff_drop(v_t_2482);
          return heff_rec(2, shape_47_252, (V[]){((V)&g_heff_2eemit_2eexprGo_24s585_str37), MK_INT(3LL)});
        }
        case TAG_False: {
          V v_t_2486 = (g_heff_2eemit_2equoteGo(v_t_2482, MK_INT(0LL), ((V)&g_heff_2eemit_2eexprGo_24s585_str38)));
          V v_t_2487 = heff_strAppend(((V)&g_heff_2eemit_2eexprGo_24s585_str39), heff_strAppend(v_t_2486, ((V)&g_heff_2eemit_2eexprGo_24s585_str40)));
          V v_code_2488 = heff_strAppend(((V)&g_heff_2eemit_2eexprGo_24s585_str41), heff_strAppend(v_t_2487, ((V)&g_heff_2eemit_2eexprGo_24s585_str42)));
          return heff_rec(2, shape_47_252, (V[]){v_code_2488, MK_INT(3LL)});
        }
        default: return heff_nomatch(v_t_2485);
        }
      }
      default: return heff_nomatch(v_t_2484);
      }
    }
    case TAG_Cons: {
      V v_t_2491 = (g_heff_2eemit_2equoteGo(v_t_2482, MK_INT(0LL), ((V)&g_heff_2eemit_2eexprGo_24s585_str43)));
      V v_t_2492 = heff_strAppend(((V)&g_heff_2eemit_2eexprGo_24s585_str44), heff_strAppend(v_t_2491, ((V)&g_heff_2eemit_2eexprGo_24s585_str45)));
      V v_x2_2496 = (g_prelude_2emap(heff_clo(g_heff_2eemit_2eexprGo_24s585_lam3, 1, 2, (V[]){v_env_240, v_ind_241}), v_it2_2483));
      V v_t_2499;
      switch (heff_tag_of(v_x2_2496)) {
      case TAG_Nil: {
        v_t_2499 = ((V)&g_heff_2eemit_2eexprGo_24s585_str46);
        break;
      }
      case TAG_Cons: {
        V v_x_2497 = heff_field(v_x2_2496, 0);
        V v_xs_2498 = heff_field(v_x2_2496, 1);
        heff_take_n(v_x2_2496, 3ULL, 2);
        v_t_2499 = ({ V a_0 = v_x_2497; V a_1 = v_xs_2498; V r_ = (g_prelude_2efoldl_24s45(a_0, a_1)); heff_drop(v_xs_2498); r_; });
        break;
      }
      default: heff_nomatch(v_x2_2496);
      }
      V v_code_24100 = heff_strAppend(((V)&g_heff_2eemit_2eexprGo_24s585_str47), heff_strAppend(v_t_2492, heff_strAppend(((V)&g_heff_2eemit_2eexprGo_24s585_str48), heff_strAppend(v_t_2499, ((V)&g_heff_2eemit_2eexprGo_24s585_str49)))));
      return heff_rec(2, shape_47_252, (V[]){v_code_24100, MK_INT(3LL)});
    }
    default: return heff_nomatch(v_it2_2483);
    }
  }
  case TAG_EMatch: {
    V v_s_24101 = heff_dup(heff_field(v_e_242, 0));
    V v_arms_24102 = heff_dup(heff_field(v_e_242, 1));
    V v_t_24103 = (g_prelude_2efoldl_24s1(MK_INT(0LL), v_arms_24102));
    V v_t_24104 = heff_intEq(v_t_24103, MK_INT(2LL));
    V v_it_24109;
    switch (heff_tag_of(v_t_24104)) {
    case TAG_True: {
      V v_t_24105 = (g_heff_2eemit_2earmNamed(((V)&g_heff_2eemit_2eexprGo_24s585_str50), v_arms_24102));
      switch (heff_tag_of(v_t_24105)) {
      case TAG_Nothing: {
        v_it_24109 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Just: {
        V v_t_24106 = heff_field(v_t_24105, 0);
        V v_ru_24t_24105_24Just = heff_take_reuse_n(v_t_24105, 1ULL, 1);
        V v_t_24107 = (g_heff_2eemit_2earmNamed(((V)&g_heff_2eemit_2eexprGo_24s585_str51), v_arms_24102));
        switch (heff_tag_of(v_t_24107)) {
        case TAG_Nothing: {
          heff_drop(v_t_24106);
          heff_drop_cell(v_ru_24t_24105_24Just, 1);
          v_it_24109 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_Just: {
          V v_f_24108 = heff_field(v_t_24107, 0);
          heff_take_n(v_t_24107, 1ULL, 1);
          v_it_24109 = heff_tag_at(v_ru_24t_24105_24Just, TAG_Just, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_t_24106, v_f_24108})});
          break;
        }
        default: heff_nomatch(v_t_24107);
        }
        break;
      }
      default: heff_nomatch(v_t_24105);
      }
      break;
    }
    case TAG_False: {
      v_it_24109 = NTAG(TAG_Nothing);
      break;
    }
    default: heff_nomatch(v_t_24104);
    }
    switch (heff_tag_of(v_it_24109)) {
    case TAG_Nothing: {
      V v_t_24110 = (g_heff_2eemit_2etailApp(v_e_242));
      V v_b_24115;
      switch (heff_tag_of(v_t_24110)) {
      case TAG_True: {
        heff_drop_tag(v_e_242, 2);
        v_b_24115 = NTAG(TAG_True);
        break;
      }
      case TAG_False: {
        V v_t_24111 = (g_heff_2eemit_2etailGlobals(v_e_242));
        v_b_24115 = ({ V a_0 = heff_clo(g_heff_2eemit_2eexprGo_24s585_lam4, 1, 1, (V[]){heff_dup(v_env_240)}); V a_1 = v_t_24111; V r_ = (g_prelude_2eany(a_0, a_1)); heff_drop(v_t_24111); r_; });
        break;
      }
      default: heff_nomatch(v_t_24110);
      }
      V v_t_24116 = (g_heff_2eemit_2eblockF_24s589(v_env_240, v_ind_241, heff_tag(TAG_EMatch, 2, (V[]){v_s_24101, v_arms_24102})));
      V v_c_24117 = heff_strAppend(((V)&g_heff_2eemit_2eexprGo_24s585_str52), heff_strAppend(v_t_24116, ((V)&g_heff_2eemit_2eexprGo_24s585_str53)));
      V v_code_24118;
      switch (heff_tag_of(v_b_24115)) {
      case TAG_True: {
        v_code_24118 = heff_strAppend(((V)&g_heff_2eemit_2eexprGo_24s585_str54), heff_strAppend(v_c_24117, ((V)&g_heff_2eemit_2eexprGo_24s585_str55)));
        break;
      }
      case TAG_False: {
        v_code_24118 = v_c_24117;
        break;
      }
      default: heff_nomatch(v_b_24115);
      }
      return heff_rec(2, shape_47_252, (V[]){v_code_24118, MK_INT(3LL)});
    }
    case TAG_Just: {
      V v_it1_24119 = heff_field(v_it_24109, 0);
      heff_take_n(v_it_24109, 1ULL, 1);
      heff_drop(v_arms_24102);
      switch (heff_tag_of(v_it1_24119)) {
      case TAG_MkPair: {
        V v_t_24120 = heff_field(v_it1_24119, 0);
        V v_f_24121 = heff_field(v_it1_24119, 1);
        heff_take_n(v_it1_24119, 3ULL, 2);
        return (g_heff_2eemit_2eexprTest_24s586(v_env_240, v_ind_241, v_e_242, v_s_24101, v_t_24120, v_f_24121));
      }
      default: return heff_nomatch(v_it1_24119);
      }
    }
    default: return heff_nomatch(v_it_24109);
    }
  }
  case TAG_EPrim: {
    V v_p_24122 = heff_field(v_e_242, 0);
    heff_take_n(v_e_242, 1ULL, 1);
    heff_drop(v_env_240);
    heff_drop(v_ind_241);
    V v_t_24123 = heff_strAppend(((V)&g_heff_2eemit_2eexprGo_24s585_str56), heff_strAppend(v_p_24122, ((V)&g_heff_2eemit_2eexprGo_24s585_str57)));
    return heff_rec(2, shape_47_252, (V[]){v_t_24123, MK_INT(3LL)});
  }
  case TAG_EPrimCall: {
    V v_p_24124 = heff_field(v_e_242, 0);
    V v_as_24125 = heff_field(v_e_242, 1);
    heff_take_n(v_e_242, 3ULL, 2);
    V v_t_24128 = (g_prelude_2emap(heff_clo(g_heff_2eemit_2eexprGo_24s585_lam5, 1, 2, (V[]){v_env_240, v_ind_241}), v_as_24125));
    return (g_heff_2eemit_2eprimCall(v_p_24124, v_t_24128));
  }
  case TAG_ECall: {
    V v_g_24129 = heff_field(v_e_242, 0);
    V v_as_24130 = heff_field(v_e_242, 1);
    heff_take_n(v_e_242, 3ULL, 2);
    V v_t_24131 = (g_heff_2eemit_2eisUnitArgs(v_as_24130));
    switch (heff_tag_of(v_t_24131)) {
    case TAG_True: {
      heff_drop(v_ind_241);
      heff_drop(v_as_24130);
      V v_t_24132 = (g_heff_2eemit_2ecallName(v_env_240, v_g_24129));
      V v_code_24133 = heff_strAppend(((V)&g_heff_2eemit_2eexprGo_24s585_str58), heff_strAppend(v_t_24132, ((V)&g_heff_2eemit_2eexprGo_24s585_str59)));
      return heff_rec(2, shape_47_252, (V[]){v_code_24133, MK_INT(3LL)});
    }
    case TAG_False: {
      V v_t_24134 = ({ V a_0 = heff_dup(v_g_24129); V b_1 = heff_get(heff_dup(v_env_240), LBL_gs); V r_ = (g_map_2elookup_24s8(a_0, b_1)); heff_drop(b_1); r_; });
      V v_b_24136;
      switch (heff_tag_of(v_t_24134)) {
      case TAG_Nothing: {
        v_b_24136 = NTAG(TAG_False);
        break;
      }
      case TAG_Just: {
        V v_i_24135 = heff_field(v_t_24134, 0);
        heff_take_n(v_t_24134, 1ULL, 1);
        v_b_24136 = heff_get(v_i_24135, LBL_bounce);
        break;
      }
      default: heff_nomatch(v_t_24134);
      }
      V v_t_24137 = (g_heff_2eemit_2ecallName(heff_dup(v_env_240), v_g_24129));
      V v_x2_24141 = (g_prelude_2emap(heff_clo(g_heff_2eemit_2eexprGo_24s585_lam6, 1, 2, (V[]){v_env_240, v_ind_241}), v_as_24130));
      V v_t_24144;
      switch (heff_tag_of(v_x2_24141)) {
      case TAG_Nil: {
        v_t_24144 = ((V)&g_heff_2eemit_2eexprGo_24s585_str60);
        break;
      }
      case TAG_Cons: {
        V v_x_24142 = heff_field(v_x2_24141, 0);
        V v_xs_24143 = heff_field(v_x2_24141, 1);
        heff_take_n(v_x2_24141, 3ULL, 2);
        v_t_24144 = ({ V a_0 = v_x_24142; V a_1 = v_xs_24143; V r_ = (g_prelude_2efoldl_24s45(a_0, a_1)); heff_drop(v_xs_24143); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24141);
      }
      V v_c_24145 = heff_strAppend(v_t_24137, heff_strAppend(((V)&g_heff_2eemit_2eexprGo_24s585_str61), heff_strAppend(v_t_24144, ((V)&g_heff_2eemit_2eexprGo_24s585_str62))));
      V v_code_24146;
      switch (heff_tag_of(v_b_24136)) {
      case TAG_True: {
        v_code_24146 = heff_strAppend(((V)&g_heff_2eemit_2eexprGo_24s585_str63), heff_strAppend(v_c_24145, ((V)&g_heff_2eemit_2eexprGo_24s585_str64)));
        break;
      }
      case TAG_False: {
        v_code_24146 = v_c_24145;
        break;
      }
      default: heff_nomatch(v_b_24136);
      }
      return heff_rec(2, shape_47_252, (V[]){v_code_24146, MK_INT(3LL)});
    }
    default: return heff_nomatch(v_t_24131);
    }
  }
  case TAG_EInt: {
    V v_i_24147 = heff_field(v_e_242, 0);
    heff_take_n(v_e_242, 1ULL, 1);
    heff_drop(v_env_240);
    heff_drop(v_ind_241);
    V v_s_24148 = heff_intShow(v_i_24147);
    V v_t_24149 = heff_strEq(heff_strSlice(heff_dup(v_s_24148), MK_INT(0LL), MK_INT(1LL)), ((V)&g_heff_2eemit_2eexprGo_24s585_str65));
    switch (heff_tag_of(v_t_24149)) {
    case TAG_True: {
      return heff_rec(2, shape_47_252, (V[]){heff_strAppend(v_s_24148, ((V)&g_heff_2eemit_2eexprGo_24s585_str66)), MK_INT(2LL)});
    }
    case TAG_False: {
      return heff_rec(2, shape_47_252, (V[]){heff_strAppend(v_s_24148, ((V)&g_heff_2eemit_2eexprGo_24s585_str67)), MK_INT(3LL)});
    }
    default: return heff_nomatch(v_t_24149);
    }
  }
  case TAG_EFloat: {
    V v_x_24150 = heff_field(v_e_242, 0);
    heff_take_n(v_e_242, 1ULL, 1);
    heff_drop(v_env_240);
    heff_drop(v_ind_241);
    V v_s_24151 = heff_floatShow(v_x_24150);
    V v_t_24152 = heff_strEq(heff_strSlice(heff_dup(v_s_24151), MK_INT(0LL), MK_INT(1LL)), ((V)&g_heff_2eemit_2eexprGo_24s585_str68));
    switch (heff_tag_of(v_t_24152)) {
    case TAG_True: {
      return heff_rec(2, shape_47_252, (V[]){v_s_24151, MK_INT(2LL)});
    }
    case TAG_False: {
      return heff_rec(2, shape_47_252, (V[]){v_s_24151, MK_INT(3LL)});
    }
    default: return heff_nomatch(v_t_24152);
    }
  }
  case TAG_EStr: {
    V v_s_24153 = heff_field(v_e_242, 0);
    heff_take_n(v_e_242, 1ULL, 1);
    heff_drop(v_env_240);
    heff_drop(v_ind_241);
    V v_t_24154 = (g_heff_2eemit_2equoteGo(v_s_24153, MK_INT(0LL), ((V)&g_heff_2eemit_2eexprGo_24s585_str69)));
    V v_code_24155 = heff_strAppend(((V)&g_heff_2eemit_2eexprGo_24s585_str70), heff_strAppend(v_t_24154, ((V)&g_heff_2eemit_2eexprGo_24s585_str71)));
    return heff_rec(2, shape_47_252, (V[]){v_code_24155, MK_INT(3LL)});
  }
  case TAG_EAbandon: {
    heff_drop(v_env_240);
    heff_drop(v_ind_241);
    return heff_rec(2, shape_47_252, (V[]){((V)&g_heff_2eemit_2eexprGo_24s585_str72), MK_INT(3LL)});
  }
  case TAG_EFix: {
    heff_take_n(v_e_242, 0ULL, 2);
    heff_drop(v_env_240);
    heff_drop(v_ind_241);
    return heff_rec(2, shape_47_252, (V[]){((V)&g_heff_2eemit_2eexprGo_24s585_str73), MK_INT(3LL)});
  }
  default: return heff_nomatch(v_e_242);
  }
}
V g_heff_2eemit_2eexprGo_24s585_entry(V self, V *a) {
  (void)self;
  return g_heff_2eemit_2eexprGo_24s585(a[0], a[1], a[2]);
}
V g_heff_2eemit_2eexprGo_24s585_lam0(V self, V *args) {
  V v_c_2437 = args[0];
  V v_a_2438 = args[1];
  V v_env_240 = heff_env(self)[0];
  V v_ind_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2439 = heff_intLt(heff_get(heff_dup(v_c_2437), LBL_prec), MK_INT(3LL));
  V v_t_2440;
  switch (heff_tag_of(v_t_2439)) {
  case TAG_True: {
    v_t_2440 = heff_strAppend(((V)&g_heff_2eemit_2eexprGo_24s585_str9), heff_strAppend(heff_get(v_c_2437, LBL_code), ((V)&g_heff_2eemit_2eexprGo_24s585_str10)));
    break;
  }
  case TAG_False: {
    v_t_2440 = heff_get(v_c_2437, LBL_code);
    break;
  }
  default: heff_nomatch(v_t_2439);
  }
  V v_t_2441 = heff_rec(4, shape_120_200_361_295, (V[]){heff_get(heff_dup(v_env_240), LBL_gs), heff_get(heff_dup(v_env_240), LBL_names), heff_get(v_env_240, LBL_used), NTAG(TAG_Nothing)});
  V v_t_2442 = heff_tr(g_heff_2eemit_2eexprGo_24s585(v_t_2441, v_ind_241, v_a_2438));
  V v_c_2443 = heff_strAppend(v_t_2440, heff_strAppend(((V)&g_heff_2eemit_2eexprGo_24s585_str11), heff_strAppend(heff_get(v_t_2442, LBL_code), ((V)&g_heff_2eemit_2eexprGo_24s585_str12))));
  V v_code_2444 = heff_strAppend(((V)&g_heff_2eemit_2eexprGo_24s585_str13), heff_strAppend(v_c_2443, ((V)&g_heff_2eemit_2eexprGo_24s585_str14)));
  return heff_rec(2, shape_47_252, (V[]){v_code_2444, MK_INT(3LL)});
}
V g_heff_2eemit_2eexprGo_24s585_lam1(V self, V *args) {
  V v_g_2450 = args[0];
  V v_env_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2451 = ({ V a_0 = v_g_2450; V b_1 = heff_get(v_env_240, LBL_gs); V r_ = (g_map_2elookup_24s8(a_0, b_1)); heff_drop(b_1); r_; });
  switch (heff_tag_of(v_t_2451)) {
  case TAG_Nothing: {
    return NTAG(TAG_False);
  }
  case TAG_Just: {
    V v_i_2452 = heff_field(v_t_2451, 0);
    heff_take_n(v_t_2451, 1ULL, 1);
    return heff_get(v_i_2452, LBL_bounce);
  }
  default: return heff_nomatch(v_t_2451);
  }
}
V g_heff_2eemit_2eexprGo_24s585_lam2(V self, V *args) {
  V v_p_2458 = args[0];
  V v_env_240 = heff_env(self)[0];
  V v_ind_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_p_2458)) {
  case TAG_MkPair: {
    V v_l_2459 = heff_field(v_p_2458, 0);
    V v_e2_2460 = heff_field(v_p_2458, 1);
    heff_take_n(v_p_2458, 3ULL, 2);
    V v_t_2461 = (g_heff_2eemit_2eisIdent(heff_dup(v_l_2459)));
    V v_t_2463;
    switch (heff_tag_of(v_t_2461)) {
    case TAG_True: {
      v_t_2463 = v_l_2459;
      break;
    }
    case TAG_False: {
      V v_t_2462 = (g_heff_2eemit_2equoteGo(v_l_2459, MK_INT(0LL), ((V)&g_heff_2eemit_2eexprGo_24s585_str19)));
      v_t_2463 = heff_strAppend(((V)&g_heff_2eemit_2eexprGo_24s585_str20), heff_strAppend(v_t_2462, ((V)&g_heff_2eemit_2eexprGo_24s585_str21)));
      break;
    }
    default: heff_nomatch(v_t_2461);
    }
    V v_t_2464 = heff_rec(4, shape_120_200_361_295, (V[]){heff_get(heff_dup(v_env_240), LBL_gs), heff_get(heff_dup(v_env_240), LBL_names), heff_get(v_env_240, LBL_used), NTAG(TAG_Nothing)});
    V v_t_2465 = heff_tr(g_heff_2eemit_2eexprGo_24s585(v_t_2464, v_ind_241, v_e2_2460));
    return heff_strAppend(v_t_2463, heff_strAppend(((V)&g_heff_2eemit_2eexprGo_24s585_str22), heff_get(v_t_2465, LBL_code)));
  }
  default: return heff_nomatch(v_p_2458);
  }
}
V g_heff_2eemit_2eexprGo_24s585_lam3(V self, V *args) {
  V v_a_2493 = args[0];
  V v_env_240 = heff_env(self)[0];
  V v_ind_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2494 = heff_rec(4, shape_120_200_361_295, (V[]){heff_get(heff_dup(v_env_240), LBL_gs), heff_get(heff_dup(v_env_240), LBL_names), heff_get(v_env_240, LBL_used), NTAG(TAG_Nothing)});
  V v_t_2495 = heff_tr(g_heff_2eemit_2eexprGo_24s585(v_t_2494, v_ind_241, v_a_2493));
  return heff_get(v_t_2495, LBL_code);
}
V g_heff_2eemit_2eexprGo_24s585_lam4(V self, V *args) {
  V v_g_24112 = args[0];
  V v_env_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24113 = ({ V a_0 = v_g_24112; V b_1 = heff_get(v_env_240, LBL_gs); V r_ = (g_map_2elookup_24s8(a_0, b_1)); heff_drop(b_1); r_; });
  switch (heff_tag_of(v_t_24113)) {
  case TAG_Nothing: {
    return NTAG(TAG_False);
  }
  case TAG_Just: {
    V v_i_24114 = heff_field(v_t_24113, 0);
    heff_take_n(v_t_24113, 1ULL, 1);
    return heff_get(v_i_24114, LBL_bounce);
  }
  default: return heff_nomatch(v_t_24113);
  }
}
V g_heff_2eemit_2eexprGo_24s585_lam5(V self, V *args) {
  V v_a_24126 = args[0];
  V v_env_240 = heff_env(self)[0];
  V v_ind_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24127 = heff_rec(4, shape_120_200_361_295, (V[]){heff_get(heff_dup(v_env_240), LBL_gs), heff_get(heff_dup(v_env_240), LBL_names), heff_get(v_env_240, LBL_used), NTAG(TAG_Nothing)});
  return (g_heff_2eemit_2eexprGo_24s585(v_t_24127, v_ind_241, v_a_24126));
}
V g_heff_2eemit_2eexprGo_24s585_lam6(V self, V *args) {
  V v_a_24138 = args[0];
  V v_env_240 = heff_env(self)[0];
  V v_ind_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24139 = heff_rec(4, shape_120_200_361_295, (V[]){heff_get(heff_dup(v_env_240), LBL_gs), heff_get(heff_dup(v_env_240), LBL_names), heff_get(v_env_240, LBL_used), NTAG(TAG_Nothing)});
  V v_t_24140 = heff_tr(g_heff_2eemit_2eexprGo_24s585(v_t_24139, v_ind_241, v_a_24138));
  return heff_get(v_t_24140, LBL_code);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemit_2escrutBound_24s584_str0 = {{0x80000000u, K_STR, 0}, 2, 2, {32, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2escrutBound_24s584_str1 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2eemit_2escrutBound_24s584_str2 = {{0x80000000u, K_STR, 0}, 6, 6, {99, 111, 110, 115, 116, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemit_2escrutBound_24s584_str3 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 61, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2escrutBound_24s584_str4 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
Clo g_heff_2eemit_2escrutBound_24s584_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemit_2escrutBound_24s584_entry, 4, 0};

V g_heff_2eemit_2escrutBound_24s584(V v_env_240, V v_ind_241, V v_s_242, V v_b_243) {
top: ;
  V v_x2_244 = (g_prelude_2ereplicate(heff_dup(v_ind_241), ((V)&g_heff_2eemit_2escrutBound_24s584_str0)));
  V v_t_247;
  switch (heff_tag_of(v_x2_244)) {
  case TAG_Nil: {
    v_t_247 = ((V)&g_heff_2eemit_2escrutBound_24s584_str1);
    break;
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x2_244, 0);
    V v_xs_246 = heff_field(v_x2_244, 1);
    heff_take_n(v_x2_244, 3ULL, 2);
    v_t_247 = ({ V a_0 = v_x_245; V a_1 = v_xs_246; V r_ = (g_prelude_2efoldl_24s46(a_0, a_1)); heff_drop(v_xs_246); r_; });
    break;
  }
  default: heff_nomatch(v_x2_244);
  }
  V v_t_248 = heff_rec(4, shape_120_200_361_295, (V[]){heff_get(heff_dup(v_env_240), LBL_gs), heff_get(heff_dup(v_env_240), LBL_names), heff_get(v_env_240, LBL_used), NTAG(TAG_Nothing)});
  V v_t_249 = heff_tr(g_heff_2eemit_2eexprGo_24s585(v_t_248, v_ind_241, v_s_242));
  V v_t_2410 = heff_strAppend(v_t_247, heff_strAppend(((V)&g_heff_2eemit_2escrutBound_24s584_str2), heff_strAppend(heff_get(heff_dup(v_b_243), LBL_js), heff_strAppend(((V)&g_heff_2eemit_2escrutBound_24s584_str3), heff_strAppend(heff_get(v_t_249, LBL_code), ((V)&g_heff_2eemit_2escrutBound_24s584_str4))))));
  V v_t_2411 = heff_tag(TAG_Cons, 2, (V[]){v_t_2410, NTAG(TAG_Nil)});
  return heff_rec(3, shape_150_87_251, (V[]){heff_get(heff_dup(v_b_243), LBL_js), heff_get(v_b_243, LBL_env), v_t_2411});
}
V g_heff_2eemit_2escrutBound_24s584_entry(V self, V *a) {
  (void)self;
  return g_heff_2eemit_2escrutBound_24s584(a[0], a[1], a[2], a[3]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2escrutOf_24s583_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {115}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2escrutOf_24s583_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {115}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2escrutOf_24s583_str2 = {{0x80000000u, K_STR, 0}, 1, 1, {115}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2escrutOf_24s583_str3 = {{0x80000000u, K_STR, 0}, 1, 1, {115}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2escrutOf_24s583_str4 = {{0x80000000u, K_STR, 0}, 1, 1, {115}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2escrutOf_24s583_str5 = {{0x80000000u, K_STR, 0}, 1, 1, {115}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2escrutOf_24s583_str6 = {{0x80000000u, K_STR, 0}, 1, 1, {115}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2escrutOf_24s583_str7 = {{0x80000000u, K_STR, 0}, 1, 1, {115}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2escrutOf_24s583_str8 = {{0x80000000u, K_STR, 0}, 1, 1, {115}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2escrutOf_24s583_str9 = {{0x80000000u, K_STR, 0}, 1, 1, {115}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2escrutOf_24s583_str10 = {{0x80000000u, K_STR, 0}, 1, 1, {115}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2escrutOf_24s583_str11 = {{0x80000000u, K_STR, 0}, 1, 1, {115}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2escrutOf_24s583_str12 = {{0x80000000u, K_STR, 0}, 1, 1, {115}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2escrutOf_24s583_str13 = {{0x80000000u, K_STR, 0}, 1, 1, {115}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2escrutOf_24s583_str14 = {{0x80000000u, K_STR, 0}, 1, 1, {115}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2escrutOf_24s583_str15 = {{0x80000000u, K_STR, 0}, 1, 1, {115}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2escrutOf_24s583_str16 = {{0x80000000u, K_STR, 0}, 1, 1, {115}};
Clo g_heff_2eemit_2escrutOf_24s583_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemit_2escrutOf_24s583_entry, 3, 0};

V g_heff_2eemit_2escrutOf_24s583(V v_env_240, V v_ind_241, V v_s_242) {
top: ;
  switch (heff_tag_of(v_s_242)) {
  case TAG_EVar: {
    V v_x_243 = heff_field(v_s_242, 0);
    V v_ru_24s_242_24EVar = heff_take_reuse_n(v_s_242, 1ULL, 1);
    V v_t_244 = ({ V a_0 = heff_dup(v_x_243); V b_1 = heff_get(heff_dup(v_env_240), LBL_names); V r_ = (g_map_2elookup_24s8(a_0, b_1)); heff_drop(b_1); r_; });
    switch (heff_tag_of(v_t_244)) {
    case TAG_Nothing: {
      V v_t_245 = (g_heff_2eemit_2ebindName(heff_dup(v_env_240), ((V)&g_heff_2eemit_2escrutOf_24s583_str0)));
      return (g_heff_2eemit_2escrutBound_24s584(v_env_240, v_ind_241, heff_tag_at(v_ru_24s_242_24EVar, TAG_EVar, 1, (V[]){v_x_243}), v_t_245));
    }
    case TAG_Just: {
      V v_js_246 = heff_field(v_t_244, 0);
      heff_take_n(v_t_244, 1ULL, 1);
      heff_drop(v_ind_241);
      heff_drop(v_x_243);
      heff_drop_cell(v_ru_24s_242_24EVar, 1);
      return heff_rec(3, shape_150_87_251, (V[]){v_js_246, v_env_240, NTAG(TAG_Nil)});
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  case TAG_EGlobal: {
    V v_t_248 = (g_heff_2eemit_2ebindName(heff_dup(v_env_240), ((V)&g_heff_2eemit_2escrutOf_24s583_str1)));
    return (g_heff_2eemit_2escrutBound_24s584(v_env_240, v_ind_241, v_s_242, v_t_248));
  }
  case TAG_ELam: {
    V v_t_2411 = (g_heff_2eemit_2ebindName(heff_dup(v_env_240), ((V)&g_heff_2eemit_2escrutOf_24s583_str2)));
    return (g_heff_2eemit_2escrutBound_24s584(v_env_240, v_ind_241, v_s_242, v_t_2411));
  }
  case TAG_EApp: {
    V v_t_2414 = (g_heff_2eemit_2ebindName(heff_dup(v_env_240), ((V)&g_heff_2eemit_2escrutOf_24s583_str3)));
    return (g_heff_2eemit_2escrutBound_24s584(v_env_240, v_ind_241, v_s_242, v_t_2414));
  }
  case TAG_ELet: {
    V v_t_2418 = (g_heff_2eemit_2ebindName(heff_dup(v_env_240), ((V)&g_heff_2eemit_2escrutOf_24s583_str4)));
    return (g_heff_2eemit_2escrutBound_24s584(v_env_240, v_ind_241, v_s_242, v_t_2418));
  }
  case TAG_ERecord: {
    V v_t_2420 = (g_heff_2eemit_2ebindName(heff_dup(v_env_240), ((V)&g_heff_2eemit_2escrutOf_24s583_str5)));
    return (g_heff_2eemit_2escrutBound_24s584(v_env_240, v_ind_241, v_s_242, v_t_2420));
  }
  case TAG_EProj: {
    V v_t_2423 = (g_heff_2eemit_2ebindName(heff_dup(v_env_240), ((V)&g_heff_2eemit_2escrutOf_24s583_str6)));
    return (g_heff_2eemit_2escrutBound_24s584(v_env_240, v_ind_241, v_s_242, v_t_2423));
  }
  case TAG_ETag: {
    V v_t_2426 = (g_heff_2eemit_2ebindName(heff_dup(v_env_240), ((V)&g_heff_2eemit_2escrutOf_24s583_str7)));
    return (g_heff_2eemit_2escrutBound_24s584(v_env_240, v_ind_241, v_s_242, v_t_2426));
  }
  case TAG_EMatch: {
    V v_t_2429 = (g_heff_2eemit_2ebindName(heff_dup(v_env_240), ((V)&g_heff_2eemit_2escrutOf_24s583_str8)));
    return (g_heff_2eemit_2escrutBound_24s584(v_env_240, v_ind_241, v_s_242, v_t_2429));
  }
  case TAG_EPrim: {
    V v_t_2431 = (g_heff_2eemit_2ebindName(heff_dup(v_env_240), ((V)&g_heff_2eemit_2escrutOf_24s583_str9)));
    return (g_heff_2eemit_2escrutBound_24s584(v_env_240, v_ind_241, v_s_242, v_t_2431));
  }
  case TAG_EPrimCall: {
    V v_t_2434 = (g_heff_2eemit_2ebindName(heff_dup(v_env_240), ((V)&g_heff_2eemit_2escrutOf_24s583_str10)));
    return (g_heff_2eemit_2escrutBound_24s584(v_env_240, v_ind_241, v_s_242, v_t_2434));
  }
  case TAG_ECall: {
    V v_t_2437 = (g_heff_2eemit_2ebindName(heff_dup(v_env_240), ((V)&g_heff_2eemit_2escrutOf_24s583_str11)));
    return (g_heff_2eemit_2escrutBound_24s584(v_env_240, v_ind_241, v_s_242, v_t_2437));
  }
  case TAG_EInt: {
    V v_t_2439 = (g_heff_2eemit_2ebindName(heff_dup(v_env_240), ((V)&g_heff_2eemit_2escrutOf_24s583_str12)));
    return (g_heff_2eemit_2escrutBound_24s584(v_env_240, v_ind_241, v_s_242, v_t_2439));
  }
  case TAG_EFloat: {
    V v_t_2441 = (g_heff_2eemit_2ebindName(heff_dup(v_env_240), ((V)&g_heff_2eemit_2escrutOf_24s583_str13)));
    return (g_heff_2eemit_2escrutBound_24s584(v_env_240, v_ind_241, v_s_242, v_t_2441));
  }
  case TAG_EStr: {
    V v_t_2443 = (g_heff_2eemit_2ebindName(heff_dup(v_env_240), ((V)&g_heff_2eemit_2escrutOf_24s583_str14)));
    return (g_heff_2eemit_2escrutBound_24s584(v_env_240, v_ind_241, v_s_242, v_t_2443));
  }
  case TAG_EAbandon: {
    V v_t_2444 = (g_heff_2eemit_2ebindName(heff_dup(v_env_240), ((V)&g_heff_2eemit_2escrutOf_24s583_str15)));
    return (g_heff_2eemit_2escrutBound_24s584(v_env_240, v_ind_241, v_s_242, v_t_2444));
  }
  case TAG_EFix: {
    V v_t_2447 = (g_heff_2eemit_2ebindName(heff_dup(v_env_240), ((V)&g_heff_2eemit_2escrutOf_24s583_str16)));
    return (g_heff_2eemit_2escrutBound_24s584(v_env_240, v_ind_241, v_s_242, v_t_2447));
  }
  default: return heff_nomatch(v_s_242);
  }
}
V g_heff_2eemit_2escrutOf_24s583_entry(V self, V *a) {
  (void)self;
  return g_heff_2eemit_2escrutOf_24s583(a[0], a[1], a[2]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemit_2earmBound_24s593_str0 = {{0x80000000u, K_STR, 0}, 2, 2, {32, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2earmBound_24s593_str1 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2earmBound_24s593_str2 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2earmBound_24s593_str3 = {{0x80000000u, K_STR, 0}, 1, 1, {34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2earmBound_24s593_str4 = {{0x80000000u, K_STR, 0}, 1, 1, {34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eemit_2earmBound_24s593_str5 = {{0x80000000u, K_STR, 0}, 5, 5, {99, 97, 115, 101, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemit_2earmBound_24s593_str6 = {{0x80000000u, K_STR, 0}, 3, 3, {58, 32, 123}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemit_2earmBound_24s593_str7 = {{0x80000000u, K_STR, 0}, 2, 2, {32, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2earmBound_24s593_str8 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2earmBound_24s593_str9 = {{0x80000000u, K_STR, 0}, 1, 1, {125}};
Clo g_heff_2eemit_2earmBound_24s593_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemit_2earmBound_24s593_entry, 5, 0};

V g_heff_2eemit_2earmBound_24s593(V v_sc_240, V v_ind_241, V v_tag_242, V v_bdy_243, V v_rb_244) {
top: ;
  V v_x2_245 = (g_prelude_2ereplicate(heff_intAdd(heff_dup(v_ind_241), MK_INT(1LL)), ((V)&g_heff_2eemit_2earmBound_24s593_str0)));
  V v_t_248;
  switch (heff_tag_of(v_x2_245)) {
  case TAG_Nil: {
    v_t_248 = ((V)&g_heff_2eemit_2earmBound_24s593_str1);
    break;
  }
  case TAG_Cons: {
    V v_x_246 = heff_field(v_x2_245, 0);
    V v_xs_247 = heff_field(v_x2_245, 1);
    heff_take_n(v_x2_245, 3ULL, 2);
    v_t_248 = ({ V a_0 = v_x_246; V a_1 = v_xs_247; V r_ = (g_prelude_2efoldl_24s46(a_0, a_1)); heff_drop(v_xs_247); r_; });
    break;
  }
  default: heff_nomatch(v_x2_245);
  }
  V v_t_249 = (g_heff_2eemit_2equoteGo(v_tag_242, MK_INT(0LL), ((V)&g_heff_2eemit_2earmBound_24s593_str2)));
  V v_t_2410 = heff_strAppend(((V)&g_heff_2eemit_2earmBound_24s593_str3), heff_strAppend(v_t_249, ((V)&g_heff_2eemit_2earmBound_24s593_str4)));
  V v_t_2411 = heff_strAppend(v_t_248, heff_strAppend(((V)&g_heff_2eemit_2earmBound_24s593_str5), heff_strAppend(v_t_2410, ((V)&g_heff_2eemit_2earmBound_24s593_str6))));
  V v_t_2412 = heff_tag(TAG_Cons, 2, (V[]){v_t_2411, NTAG(TAG_Nil)});
  V v_t_2413 = (g_heff_2eemit_2edeclsOf(heff_get(v_sc_240, LBL_js), heff_intAdd(heff_dup(v_ind_241), MK_INT(2LL)), heff_get(heff_dup(v_rb_244), LBL_js), MK_INT(0LL)));
  V v_t_2414 = (g_heff_2eemit_2estmtsF_24s581(heff_get(v_rb_244, LBL_env), heff_intAdd(heff_dup(v_ind_241), MK_INT(2LL)), v_bdy_243));
  V v_x2_2415 = (g_prelude_2ereplicate(heff_intAdd(v_ind_241, MK_INT(1LL)), ((V)&g_heff_2eemit_2earmBound_24s593_str7)));
  V v_t_2418;
  switch (heff_tag_of(v_x2_2415)) {
  case TAG_Nil: {
    v_t_2418 = ((V)&g_heff_2eemit_2earmBound_24s593_str8);
    break;
  }
  case TAG_Cons: {
    V v_x_2416 = heff_field(v_x2_2415, 0);
    V v_xs_2417 = heff_field(v_x2_2415, 1);
    heff_take_n(v_x2_2415, 3ULL, 2);
    v_t_2418 = ({ V a_0 = v_x_2416; V a_1 = v_xs_2417; V r_ = (g_prelude_2efoldl_24s46(a_0, a_1)); heff_drop(v_xs_2417); r_; });
    break;
  }
  default: heff_nomatch(v_x2_2415);
  }
  V v_t_2419 = heff_tag(TAG_Cons, 2, (V[]){heff_strAppend(v_t_2418, ((V)&g_heff_2eemit_2earmBound_24s593_str9)), NTAG(TAG_Nil)});
  V v_t_2420 = (g_prelude_2econcatList(v_t_2414, v_t_2419));
  V v_t_2421 = (g_prelude_2econcatList(v_t_2413, v_t_2420));
  return (g_prelude_2econcatList(v_t_2412, v_t_2421));
}
V g_heff_2eemit_2earmBound_24s593_entry(V self, V *a) {
  (void)self;
  return g_heff_2eemit_2earmBound_24s593(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2eemit_2earmJs_24s592_lam0(V self, V *args);
Clo g_heff_2eemit_2earmJs_24s592_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemit_2earmJs_24s592_entry, 3, 0};

V g_heff_2eemit_2earmJs_24s592(V v_sc_240, V v_ind_241, V v_x4_242) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_MkArm: {
    V v_tag_243 = heff_field(v_x4_242, 0);
    V v_vs_244 = heff_field(v_x4_242, 1);
    V v_bdy_245 = heff_field(v_x4_242, 2);
    V v_ru_24x4_242_24MkArm = heff_take_reuse_n(v_x4_242, 7ULL, 3);
    V v_t_2412 = (g_prelude_2eall(heff_clo(g_heff_2eemit_2earmJs_24s592_lam0, 1, 1, (V[]){heff_dup(v_bdy_245)}), v_vs_244));
    switch (heff_tag_of(v_t_2412)) {
    case TAG_True: {
      heff_drop(v_vs_244);
      return heff_tag_at(v_ru_24x4_242_24MkArm, TAG_MkArmJs, 3, (V[]){v_tag_243, NTAG(TAG_True), (g_heff_2eemit_2estmtsF_24s581(heff_get(v_sc_240, LBL_env), heff_intAdd(v_ind_241, MK_INT(2LL)), v_bdy_245))});
    }
    case TAG_False: {
      V v_t_2413 = heff_rec(2, shape_150_87, (V[]){NTAG(TAG_Nil), heff_get(heff_dup(v_sc_240), LBL_env)});
      V v_t_2414 = (g_prelude_2efoldl_24s575(v_t_2413, v_vs_244));
      return heff_tag_at(v_ru_24x4_242_24MkArm, TAG_MkArmJs, 3, (V[]){heff_dup(v_tag_243), NTAG(TAG_False), (g_heff_2eemit_2earmBound_24s593(v_sc_240, v_ind_241, v_tag_243, v_bdy_245, v_t_2414))});
    }
    default: return heff_nomatch(v_t_2412);
    }
  }
  default: return heff_nomatch(v_x4_242);
  }
}
V g_heff_2eemit_2earmJs_24s592_entry(V self, V *a) {
  (void)self;
  return g_heff_2eemit_2earmJs_24s592(a[0], a[1], a[2]);
}
V g_heff_2eemit_2earmJs_24s592_lam0(V self, V *args) {
  V v_v_246 = args[0];
  V v_bdy_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_247 = heff_tag(TAG_Cons, 2, (V[]){heff_dup(v_bdy_245), NTAG(TAG_Nil)});
  V v_t_248 = (g_heff_2eir_2ecountW(heff_dup(v_v_246), MK_INT(0LL), v_t_247));
  V v_t_249 = heff_tag(TAG_Cons, 2, (V[]){v_bdy_245, NTAG(TAG_Nil)});
  V v_t_2410 = (g_heff_2eir_2elamW(v_v_246, v_t_249));
  V v_t_2411 = heff_get(heff_rec(2, shape_52_358, (V[]){v_t_248, v_t_2410}), LBL_count);
  return heff_intEq(v_t_2411, MK_INT(0LL));
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemit_2estmtsMatch2_24s591_str0 = {{0x80000000u, K_STR, 0}, 2, 2, {32, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2estmtsMatch2_24s591_str1 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[16]; } g_heff_2eemit_2estmtsMatch2_24s591_str2 = {{0x80000000u, K_STR, 0}, 16, 16, {114, 101, 116, 117, 114, 110, 32, 36, 110, 111, 109, 97, 116, 99, 104, 40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemit_2estmtsMatch2_24s591_str3 = {{0x80000000u, K_STR, 0}, 2, 2, {41, 59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemit_2estmtsMatch2_24s591_str4 = {{0x80000000u, K_STR, 0}, 2, 2, {32, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2estmtsMatch2_24s591_str5 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2eemit_2estmtsMatch2_24s591_str6 = {{0x80000000u, K_STR, 0}, 8, 8, {115, 119, 105, 116, 99, 104, 32, 40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eemit_2estmtsMatch2_24s591_str7 = {{0x80000000u, K_STR, 0}, 5, 5, {46, 36, 41, 32, 123}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemit_2estmtsMatch2_24s591_str8 = {{0x80000000u, K_STR, 0}, 2, 2, {32, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2estmtsMatch2_24s591_str9 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemit_2estmtsMatch2_24s591_str10 = {{0x80000000u, K_STR, 0}, 2, 2, {32, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2estmtsMatch2_24s591_str11 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[16]; } g_heff_2eemit_2estmtsMatch2_24s591_str12 = {{0x80000000u, K_STR, 0}, 16, 16, {114, 101, 116, 117, 114, 110, 32, 36, 110, 111, 109, 97, 116, 99, 104, 40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemit_2estmtsMatch2_24s591_str13 = {{0x80000000u, K_STR, 0}, 2, 2, {41, 59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2estmtsMatch2_24s591_str14 = {{0x80000000u, K_STR, 0}, 1, 1, {125}};
V g_heff_2eemit_2estmtsMatch2_24s591_lam0(V self, V *args);
Clo g_heff_2eemit_2estmtsMatch2_24s591_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemit_2estmtsMatch2_24s591_entry, 3, 0};

V g_heff_2eemit_2estmtsMatch2_24s591(V v_ind_240, V v_arms_241, V v_sc_242) {
top: ;
  V v_t_245;
  switch (heff_tag_of(v_arms_241)) {
  case TAG_Nil: {
    v_t_245 = NTAG(TAG_True);
    break;
  }
  case TAG_Cons: {
    v_t_245 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_arms_241);
  }
  switch (heff_tag_of(v_t_245)) {
  case TAG_True: {
    heff_drop(v_arms_241);
    V v_x2_246 = (g_prelude_2ereplicate(v_ind_240, ((V)&g_heff_2eemit_2estmtsMatch2_24s591_str0)));
    V v_t_249;
    switch (heff_tag_of(v_x2_246)) {
    case TAG_Nil: {
      v_t_249 = ((V)&g_heff_2eemit_2estmtsMatch2_24s591_str1);
      break;
    }
    case TAG_Cons: {
      V v_x_247 = heff_field(v_x2_246, 0);
      V v_xs_248 = heff_field(v_x2_246, 1);
      heff_take_n(v_x2_246, 3ULL, 2);
      v_t_249 = ({ V a_0 = v_x_247; V a_1 = v_xs_248; V r_ = (g_prelude_2efoldl_24s46(a_0, a_1)); heff_drop(v_xs_248); r_; });
      break;
    }
    default: heff_nomatch(v_x2_246);
    }
    V v_t_2410 = heff_strAppend(v_t_249, heff_strAppend(((V)&g_heff_2eemit_2estmtsMatch2_24s591_str2), heff_strAppend(heff_get(heff_dup(v_sc_242), LBL_js), ((V)&g_heff_2eemit_2estmtsMatch2_24s591_str3))));
    V v_t_2411 = heff_tag(TAG_Cons, 2, (V[]){v_t_2410, NTAG(TAG_Nil)});
    return (g_prelude_2econcatList(heff_get(v_sc_242, LBL_pre), v_t_2411));
  }
  case TAG_False: {
    V v_x2_2412 = (g_prelude_2ereplicate(heff_dup(v_ind_240), ((V)&g_heff_2eemit_2estmtsMatch2_24s591_str4)));
    V v_t_2415;
    switch (heff_tag_of(v_x2_2412)) {
    case TAG_Nil: {
      v_t_2415 = ((V)&g_heff_2eemit_2estmtsMatch2_24s591_str5);
      break;
    }
    case TAG_Cons: {
      V v_x_2413 = heff_field(v_x2_2412, 0);
      V v_xs_2414 = heff_field(v_x2_2412, 1);
      heff_take_n(v_x2_2412, 3ULL, 2);
      v_t_2415 = ({ V a_0 = v_x_2413; V a_1 = v_xs_2414; V r_ = (g_prelude_2efoldl_24s46(a_0, a_1)); heff_drop(v_xs_2414); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2412);
    }
    V v_t_2416 = heff_strAppend(v_t_2415, heff_strAppend(((V)&g_heff_2eemit_2estmtsMatch2_24s591_str6), heff_strAppend(heff_get(heff_dup(v_sc_242), LBL_js), ((V)&g_heff_2eemit_2estmtsMatch2_24s591_str7))));
    V v_t_2417 = heff_tag(TAG_Cons, 2, (V[]){v_t_2416, NTAG(TAG_Nil)});
    V v_t_2419 = (g_prelude_2emap(heff_clo(g_heff_2eemit_2estmtsMatch2_24s591_lam0, 1, 2, (V[]){heff_dup(v_sc_242), heff_dup(v_ind_240)}), v_arms_241));
    V v_t_2420 = (g_heff_2eemit_2esharedGo(heff_dup(v_ind_240), NTAG(TAG_Nil), v_t_2419));
    V v_x2_2421 = (g_prelude_2ereplicate(heff_dup(v_ind_240), ((V)&g_heff_2eemit_2estmtsMatch2_24s591_str8)));
    V v_t_2424;
    switch (heff_tag_of(v_x2_2421)) {
    case TAG_Nil: {
      v_t_2424 = ((V)&g_heff_2eemit_2estmtsMatch2_24s591_str9);
      break;
    }
    case TAG_Cons: {
      V v_x_2422 = heff_field(v_x2_2421, 0);
      V v_xs_2423 = heff_field(v_x2_2421, 1);
      heff_take_n(v_x2_2421, 3ULL, 2);
      v_t_2424 = ({ V a_0 = v_x_2422; V a_1 = v_xs_2423; V r_ = (g_prelude_2efoldl_24s46(a_0, a_1)); heff_drop(v_xs_2423); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2421);
    }
    V v_x2_2425 = (g_prelude_2ereplicate(v_ind_240, ((V)&g_heff_2eemit_2estmtsMatch2_24s591_str10)));
    V v_t_2428;
    switch (heff_tag_of(v_x2_2425)) {
    case TAG_Nil: {
      v_t_2428 = ((V)&g_heff_2eemit_2estmtsMatch2_24s591_str11);
      break;
    }
    case TAG_Cons: {
      V v_x_2426 = heff_field(v_x2_2425, 0);
      V v_xs_2427 = heff_field(v_x2_2425, 1);
      heff_take_n(v_x2_2425, 3ULL, 2);
      v_t_2428 = ({ V a_0 = v_x_2426; V a_1 = v_xs_2427; V r_ = (g_prelude_2efoldl_24s46(a_0, a_1)); heff_drop(v_xs_2427); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2425);
    }
    V v_t_2429 = heff_strAppend(v_t_2428, heff_strAppend(((V)&g_heff_2eemit_2estmtsMatch2_24s591_str12), heff_strAppend(heff_get(heff_dup(v_sc_242), LBL_js), ((V)&g_heff_2eemit_2estmtsMatch2_24s591_str13))));
    V v_t_2430 = heff_tag(TAG_Cons, 2, (V[]){v_t_2429, NTAG(TAG_Nil)});
    V v_t_2431 = heff_tag(TAG_Cons, 2, (V[]){heff_strAppend(v_t_2424, ((V)&g_heff_2eemit_2estmtsMatch2_24s591_str14)), v_t_2430});
    V v_t_2432 = (g_prelude_2econcatList(v_t_2420, v_t_2431));
    V v_t_2433 = (g_prelude_2econcatList(v_t_2417, v_t_2432));
    return (g_prelude_2econcatList(heff_get(v_sc_242, LBL_pre), v_t_2433));
  }
  default: return heff_nomatch(v_t_245);
  }
}
V g_heff_2eemit_2estmtsMatch2_24s591_entry(V self, V *a) {
  (void)self;
  return g_heff_2eemit_2estmtsMatch2_24s591(a[0], a[1], a[2]);
}
V g_heff_2eemit_2estmtsMatch2_24s591_lam0(V self, V *args) {
  V v_a_2418 = args[0];
  V v_sc_242 = heff_env(self)[0];
  V v_ind_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_heff_2eemit_2earmJs_24s592(v_sc_242, v_ind_240, v_a_2418));
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemit_2estmtsIf_24s594_str0 = {{0x80000000u, K_STR, 0}, 2, 2, {32, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2estmtsIf_24s594_str1 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eemit_2estmtsIf_24s594_str2 = {{0x80000000u, K_STR, 0}, 4, 4, {105, 102, 32, 40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemit_2estmtsIf_24s594_str3 = {{0x80000000u, K_STR, 0}, 3, 3, {41, 32, 123}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemit_2estmtsIf_24s594_str4 = {{0x80000000u, K_STR, 0}, 2, 2, {32, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2estmtsIf_24s594_str5 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemit_2estmtsIf_24s594_str6 = {{0x80000000u, K_STR, 0}, 2, 2, {32, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2estmtsIf_24s594_str7 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2estmtsIf_24s594_str8 = {{0x80000000u, K_STR, 0}, 1, 1, {125}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2eemit_2estmtsIf_24s594_str9 = {{0x80000000u, K_STR, 0}, 8, 8, {125, 32, 101, 108, 115, 101, 32, 123}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemit_2estmtsIf_24s594_str10 = {{0x80000000u, K_STR, 0}, 2, 2, {32, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2estmtsIf_24s594_str11 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eemit_2estmtsIf_24s594_str12 = {{0x80000000u, K_STR, 0}, 4, 4, {105, 102, 32, 40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemit_2estmtsIf_24s594_str13 = {{0x80000000u, K_STR, 0}, 3, 3, {41, 32, 123}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemit_2estmtsIf_24s594_str14 = {{0x80000000u, K_STR, 0}, 2, 2, {32, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2estmtsIf_24s594_str15 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemit_2estmtsIf_24s594_str16 = {{0x80000000u, K_STR, 0}, 2, 2, {32, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2estmtsIf_24s594_str17 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2estmtsIf_24s594_str18 = {{0x80000000u, K_STR, 0}, 1, 1, {125}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2eemit_2estmtsIf_24s594_str19 = {{0x80000000u, K_STR, 0}, 8, 8, {125, 32, 101, 108, 115, 101, 32, 123}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemit_2estmtsIf_24s594_str20 = {{0x80000000u, K_STR, 0}, 2, 2, {32, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2estmtsIf_24s594_str21 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eemit_2estmtsIf_24s594_str22 = {{0x80000000u, K_STR, 0}, 4, 4, {105, 102, 32, 40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemit_2estmtsIf_24s594_str23 = {{0x80000000u, K_STR, 0}, 3, 3, {41, 32, 123}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemit_2estmtsIf_24s594_str24 = {{0x80000000u, K_STR, 0}, 2, 2, {32, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2estmtsIf_24s594_str25 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemit_2estmtsIf_24s594_str26 = {{0x80000000u, K_STR, 0}, 2, 2, {32, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2estmtsIf_24s594_str27 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2estmtsIf_24s594_str28 = {{0x80000000u, K_STR, 0}, 1, 1, {125}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2eemit_2estmtsIf_24s594_str29 = {{0x80000000u, K_STR, 0}, 8, 8, {125, 32, 101, 108, 115, 101, 32, 123}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemit_2estmtsIf_24s594_str30 = {{0x80000000u, K_STR, 0}, 2, 2, {32, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2estmtsIf_24s594_str31 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eemit_2estmtsIf_24s594_str32 = {{0x80000000u, K_STR, 0}, 4, 4, {105, 102, 32, 40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemit_2estmtsIf_24s594_str33 = {{0x80000000u, K_STR, 0}, 3, 3, {41, 32, 123}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemit_2estmtsIf_24s594_str34 = {{0x80000000u, K_STR, 0}, 2, 2, {32, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2estmtsIf_24s594_str35 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemit_2estmtsIf_24s594_str36 = {{0x80000000u, K_STR, 0}, 2, 2, {32, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2estmtsIf_24s594_str37 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2estmtsIf_24s594_str38 = {{0x80000000u, K_STR, 0}, 1, 1, {125}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2eemit_2estmtsIf_24s594_str39 = {{0x80000000u, K_STR, 0}, 8, 8, {125, 32, 101, 108, 115, 101, 32, 123}};
Clo g_heff_2eemit_2estmtsIf_24s594_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemit_2estmtsIf_24s594_entry, 5, 0};

V g_heff_2eemit_2estmtsIf_24s594(V v_env_240, V v_ind_241, V v_c_242, V v_t_243, V v_f_244) {
top: ;
  switch (heff_tag_of(v_c_242)) {
  case TAG_PTrue: {
    heff_drop(v_f_244);
    return (g_heff_2eemit_2estmtsF_24s581(v_env_240, v_ind_241, v_t_243));
  }
  case TAG_PFalse: {
    heff_drop(v_t_243);
    return (g_heff_2eemit_2estmtsF_24s581(v_env_240, v_ind_241, v_f_244));
  }
  case TAG_PRel: {
    V v_t_246 = (g_heff_2eemit_2eseqsOf(v_c_242));
    V v_t_247 = (g_heff_2eemit_2eletDeclarations(heff_dup(v_ind_241), v_t_246));
    V v_x2_248 = (g_prelude_2ereplicate(heff_dup(v_ind_241), ((V)&g_heff_2eemit_2estmtsIf_24s594_str0)));
    V v_t_2411;
    switch (heff_tag_of(v_x2_248)) {
    case TAG_Nil: {
      v_t_2411 = ((V)&g_heff_2eemit_2estmtsIf_24s594_str1);
      break;
    }
    case TAG_Cons: {
      V v_x_249 = heff_field(v_x2_248, 0);
      V v_xs_2410 = heff_field(v_x2_248, 1);
      heff_take_n(v_x2_248, 3ULL, 2);
      v_t_2411 = ({ V a_0 = v_x_249; V a_1 = v_xs_2410; V r_ = (g_prelude_2efoldl_24s46(a_0, a_1)); heff_drop(v_xs_2410); r_; });
      break;
    }
    default: heff_nomatch(v_x2_248);
    }
    V v_t_2412 = (g_heff_2eemit_2econdCode(v_c_242));
    V v_t_2413 = heff_strAppend(v_t_2411, heff_strAppend(((V)&g_heff_2eemit_2estmtsIf_24s594_str2), heff_strAppend(heff_get(v_t_2412, LBL_code), ((V)&g_heff_2eemit_2estmtsIf_24s594_str3))));
    V v_t_2414 = heff_tag(TAG_Cons, 2, (V[]){v_t_2413, NTAG(TAG_Nil)});
    V v_t_2415 = (g_heff_2eemit_2estmtsF_24s581(heff_dup(v_env_240), heff_intAdd(heff_dup(v_ind_241), MK_INT(1LL)), v_t_243));
    V v_x2_2416 = (g_prelude_2ereplicate(heff_dup(v_ind_241), ((V)&g_heff_2eemit_2estmtsIf_24s594_str4)));
    V v_t_2419;
    switch (heff_tag_of(v_x2_2416)) {
    case TAG_Nil: {
      v_t_2419 = ((V)&g_heff_2eemit_2estmtsIf_24s594_str5);
      break;
    }
    case TAG_Cons: {
      V v_x_2417 = heff_field(v_x2_2416, 0);
      V v_xs_2418 = heff_field(v_x2_2416, 1);
      heff_take_n(v_x2_2416, 3ULL, 2);
      v_t_2419 = ({ V a_0 = v_x_2417; V a_1 = v_xs_2418; V r_ = (g_prelude_2efoldl_24s46(a_0, a_1)); heff_drop(v_xs_2418); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2416);
    }
    V v_t_2420 = (g_heff_2eemit_2estmtsF_24s581(v_env_240, heff_intAdd(heff_dup(v_ind_241), MK_INT(1LL)), v_f_244));
    V v_x2_2421 = (g_prelude_2ereplicate(v_ind_241, ((V)&g_heff_2eemit_2estmtsIf_24s594_str6)));
    V v_t_2424;
    switch (heff_tag_of(v_x2_2421)) {
    case TAG_Nil: {
      v_t_2424 = ((V)&g_heff_2eemit_2estmtsIf_24s594_str7);
      break;
    }
    case TAG_Cons: {
      V v_x_2422 = heff_field(v_x2_2421, 0);
      V v_xs_2423 = heff_field(v_x2_2421, 1);
      heff_take_n(v_x2_2421, 3ULL, 2);
      v_t_2424 = ({ V a_0 = v_x_2422; V a_1 = v_xs_2423; V r_ = (g_prelude_2efoldl_24s46(a_0, a_1)); heff_drop(v_xs_2423); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2421);
    }
    V v_t_2425 = heff_tag(TAG_Cons, 2, (V[]){heff_strAppend(v_t_2424, ((V)&g_heff_2eemit_2estmtsIf_24s594_str8)), NTAG(TAG_Nil)});
    V v_t_2426 = heff_tag(TAG_Cons, 2, (V[]){heff_strAppend(v_t_2419, ((V)&g_heff_2eemit_2estmtsIf_24s594_str9)), (g_prelude_2econcatList(v_t_2420, v_t_2425))});
    V v_t_2427 = (g_prelude_2econcatList(v_t_2415, v_t_2426));
    V v_t_2428 = (g_prelude_2econcatList(v_t_2414, v_t_2427));
    return (g_prelude_2econcatList(v_t_247, v_t_2428));
  }
  case TAG_PNot: {
    V v_t_2430 = (g_heff_2eemit_2eseqsOf(v_c_242));
    V v_t_2431 = (g_heff_2eemit_2eletDeclarations(heff_dup(v_ind_241), v_t_2430));
    V v_x2_2432 = (g_prelude_2ereplicate(heff_dup(v_ind_241), ((V)&g_heff_2eemit_2estmtsIf_24s594_str10)));
    V v_t_2435;
    switch (heff_tag_of(v_x2_2432)) {
    case TAG_Nil: {
      v_t_2435 = ((V)&g_heff_2eemit_2estmtsIf_24s594_str11);
      break;
    }
    case TAG_Cons: {
      V v_x_2433 = heff_field(v_x2_2432, 0);
      V v_xs_2434 = heff_field(v_x2_2432, 1);
      heff_take_n(v_x2_2432, 3ULL, 2);
      v_t_2435 = ({ V a_0 = v_x_2433; V a_1 = v_xs_2434; V r_ = (g_prelude_2efoldl_24s46(a_0, a_1)); heff_drop(v_xs_2434); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2432);
    }
    V v_t_2436 = (g_heff_2eemit_2econdCode(v_c_242));
    V v_t_2437 = heff_strAppend(v_t_2435, heff_strAppend(((V)&g_heff_2eemit_2estmtsIf_24s594_str12), heff_strAppend(heff_get(v_t_2436, LBL_code), ((V)&g_heff_2eemit_2estmtsIf_24s594_str13))));
    V v_t_2438 = heff_tag(TAG_Cons, 2, (V[]){v_t_2437, NTAG(TAG_Nil)});
    V v_t_2439 = (g_heff_2eemit_2estmtsF_24s581(heff_dup(v_env_240), heff_intAdd(heff_dup(v_ind_241), MK_INT(1LL)), v_t_243));
    V v_x2_2440 = (g_prelude_2ereplicate(heff_dup(v_ind_241), ((V)&g_heff_2eemit_2estmtsIf_24s594_str14)));
    V v_t_2443;
    switch (heff_tag_of(v_x2_2440)) {
    case TAG_Nil: {
      v_t_2443 = ((V)&g_heff_2eemit_2estmtsIf_24s594_str15);
      break;
    }
    case TAG_Cons: {
      V v_x_2441 = heff_field(v_x2_2440, 0);
      V v_xs_2442 = heff_field(v_x2_2440, 1);
      heff_take_n(v_x2_2440, 3ULL, 2);
      v_t_2443 = ({ V a_0 = v_x_2441; V a_1 = v_xs_2442; V r_ = (g_prelude_2efoldl_24s46(a_0, a_1)); heff_drop(v_xs_2442); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2440);
    }
    V v_t_2444 = (g_heff_2eemit_2estmtsF_24s581(v_env_240, heff_intAdd(heff_dup(v_ind_241), MK_INT(1LL)), v_f_244));
    V v_x2_2445 = (g_prelude_2ereplicate(v_ind_241, ((V)&g_heff_2eemit_2estmtsIf_24s594_str16)));
    V v_t_2448;
    switch (heff_tag_of(v_x2_2445)) {
    case TAG_Nil: {
      v_t_2448 = ((V)&g_heff_2eemit_2estmtsIf_24s594_str17);
      break;
    }
    case TAG_Cons: {
      V v_x_2446 = heff_field(v_x2_2445, 0);
      V v_xs_2447 = heff_field(v_x2_2445, 1);
      heff_take_n(v_x2_2445, 3ULL, 2);
      v_t_2448 = ({ V a_0 = v_x_2446; V a_1 = v_xs_2447; V r_ = (g_prelude_2efoldl_24s46(a_0, a_1)); heff_drop(v_xs_2447); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2445);
    }
    V v_t_2449 = heff_tag(TAG_Cons, 2, (V[]){heff_strAppend(v_t_2448, ((V)&g_heff_2eemit_2estmtsIf_24s594_str18)), NTAG(TAG_Nil)});
    V v_t_2450 = heff_tag(TAG_Cons, 2, (V[]){heff_strAppend(v_t_2443, ((V)&g_heff_2eemit_2estmtsIf_24s594_str19)), (g_prelude_2econcatList(v_t_2444, v_t_2449))});
    V v_t_2451 = (g_prelude_2econcatList(v_t_2439, v_t_2450));
    V v_t_2452 = (g_prelude_2econcatList(v_t_2438, v_t_2451));
    return (g_prelude_2econcatList(v_t_2431, v_t_2452));
  }
  case TAG_PIf: {
    V v_t_2456 = (g_heff_2eemit_2eseqsOf(v_c_242));
    V v_t_2457 = (g_heff_2eemit_2eletDeclarations(heff_dup(v_ind_241), v_t_2456));
    V v_x2_2458 = (g_prelude_2ereplicate(heff_dup(v_ind_241), ((V)&g_heff_2eemit_2estmtsIf_24s594_str20)));
    V v_t_2461;
    switch (heff_tag_of(v_x2_2458)) {
    case TAG_Nil: {
      v_t_2461 = ((V)&g_heff_2eemit_2estmtsIf_24s594_str21);
      break;
    }
    case TAG_Cons: {
      V v_x_2459 = heff_field(v_x2_2458, 0);
      V v_xs_2460 = heff_field(v_x2_2458, 1);
      heff_take_n(v_x2_2458, 3ULL, 2);
      v_t_2461 = ({ V a_0 = v_x_2459; V a_1 = v_xs_2460; V r_ = (g_prelude_2efoldl_24s46(a_0, a_1)); heff_drop(v_xs_2460); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2458);
    }
    V v_t_2462 = (g_heff_2eemit_2econdCode(v_c_242));
    V v_t_2463 = heff_strAppend(v_t_2461, heff_strAppend(((V)&g_heff_2eemit_2estmtsIf_24s594_str22), heff_strAppend(heff_get(v_t_2462, LBL_code), ((V)&g_heff_2eemit_2estmtsIf_24s594_str23))));
    V v_t_2464 = heff_tag(TAG_Cons, 2, (V[]){v_t_2463, NTAG(TAG_Nil)});
    V v_t_2465 = (g_heff_2eemit_2estmtsF_24s581(heff_dup(v_env_240), heff_intAdd(heff_dup(v_ind_241), MK_INT(1LL)), v_t_243));
    V v_x2_2466 = (g_prelude_2ereplicate(heff_dup(v_ind_241), ((V)&g_heff_2eemit_2estmtsIf_24s594_str24)));
    V v_t_2469;
    switch (heff_tag_of(v_x2_2466)) {
    case TAG_Nil: {
      v_t_2469 = ((V)&g_heff_2eemit_2estmtsIf_24s594_str25);
      break;
    }
    case TAG_Cons: {
      V v_x_2467 = heff_field(v_x2_2466, 0);
      V v_xs_2468 = heff_field(v_x2_2466, 1);
      heff_take_n(v_x2_2466, 3ULL, 2);
      v_t_2469 = ({ V a_0 = v_x_2467; V a_1 = v_xs_2468; V r_ = (g_prelude_2efoldl_24s46(a_0, a_1)); heff_drop(v_xs_2468); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2466);
    }
    V v_t_2470 = (g_heff_2eemit_2estmtsF_24s581(v_env_240, heff_intAdd(heff_dup(v_ind_241), MK_INT(1LL)), v_f_244));
    V v_x2_2471 = (g_prelude_2ereplicate(v_ind_241, ((V)&g_heff_2eemit_2estmtsIf_24s594_str26)));
    V v_t_2474;
    switch (heff_tag_of(v_x2_2471)) {
    case TAG_Nil: {
      v_t_2474 = ((V)&g_heff_2eemit_2estmtsIf_24s594_str27);
      break;
    }
    case TAG_Cons: {
      V v_x_2472 = heff_field(v_x2_2471, 0);
      V v_xs_2473 = heff_field(v_x2_2471, 1);
      heff_take_n(v_x2_2471, 3ULL, 2);
      v_t_2474 = ({ V a_0 = v_x_2472; V a_1 = v_xs_2473; V r_ = (g_prelude_2efoldl_24s46(a_0, a_1)); heff_drop(v_xs_2473); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2471);
    }
    V v_t_2475 = heff_tag(TAG_Cons, 2, (V[]){heff_strAppend(v_t_2474, ((V)&g_heff_2eemit_2estmtsIf_24s594_str28)), NTAG(TAG_Nil)});
    V v_t_2476 = heff_tag(TAG_Cons, 2, (V[]){heff_strAppend(v_t_2469, ((V)&g_heff_2eemit_2estmtsIf_24s594_str29)), (g_prelude_2econcatList(v_t_2470, v_t_2475))});
    V v_t_2477 = (g_prelude_2econcatList(v_t_2465, v_t_2476));
    V v_t_2478 = (g_prelude_2econcatList(v_t_2464, v_t_2477));
    return (g_prelude_2econcatList(v_t_2457, v_t_2478));
  }
  case TAG_PSeq: {
    V v_t_2482 = (g_heff_2eemit_2eseqsOf(v_c_242));
    V v_t_2483 = (g_heff_2eemit_2eletDeclarations(heff_dup(v_ind_241), v_t_2482));
    V v_x2_2484 = (g_prelude_2ereplicate(heff_dup(v_ind_241), ((V)&g_heff_2eemit_2estmtsIf_24s594_str30)));
    V v_t_2487;
    switch (heff_tag_of(v_x2_2484)) {
    case TAG_Nil: {
      v_t_2487 = ((V)&g_heff_2eemit_2estmtsIf_24s594_str31);
      break;
    }
    case TAG_Cons: {
      V v_x_2485 = heff_field(v_x2_2484, 0);
      V v_xs_2486 = heff_field(v_x2_2484, 1);
      heff_take_n(v_x2_2484, 3ULL, 2);
      v_t_2487 = ({ V a_0 = v_x_2485; V a_1 = v_xs_2486; V r_ = (g_prelude_2efoldl_24s46(a_0, a_1)); heff_drop(v_xs_2486); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2484);
    }
    V v_t_2488 = (g_heff_2eemit_2econdCode(v_c_242));
    V v_t_2489 = heff_strAppend(v_t_2487, heff_strAppend(((V)&g_heff_2eemit_2estmtsIf_24s594_str32), heff_strAppend(heff_get(v_t_2488, LBL_code), ((V)&g_heff_2eemit_2estmtsIf_24s594_str33))));
    V v_t_2490 = heff_tag(TAG_Cons, 2, (V[]){v_t_2489, NTAG(TAG_Nil)});
    V v_t_2491 = (g_heff_2eemit_2estmtsF_24s581(heff_dup(v_env_240), heff_intAdd(heff_dup(v_ind_241), MK_INT(1LL)), v_t_243));
    V v_x2_2492 = (g_prelude_2ereplicate(heff_dup(v_ind_241), ((V)&g_heff_2eemit_2estmtsIf_24s594_str34)));
    V v_t_2495;
    switch (heff_tag_of(v_x2_2492)) {
    case TAG_Nil: {
      v_t_2495 = ((V)&g_heff_2eemit_2estmtsIf_24s594_str35);
      break;
    }
    case TAG_Cons: {
      V v_x_2493 = heff_field(v_x2_2492, 0);
      V v_xs_2494 = heff_field(v_x2_2492, 1);
      heff_take_n(v_x2_2492, 3ULL, 2);
      v_t_2495 = ({ V a_0 = v_x_2493; V a_1 = v_xs_2494; V r_ = (g_prelude_2efoldl_24s46(a_0, a_1)); heff_drop(v_xs_2494); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2492);
    }
    V v_t_2496 = (g_heff_2eemit_2estmtsF_24s581(v_env_240, heff_intAdd(heff_dup(v_ind_241), MK_INT(1LL)), v_f_244));
    V v_x2_2497 = (g_prelude_2ereplicate(v_ind_241, ((V)&g_heff_2eemit_2estmtsIf_24s594_str36)));
    V v_t_24100;
    switch (heff_tag_of(v_x2_2497)) {
    case TAG_Nil: {
      v_t_24100 = ((V)&g_heff_2eemit_2estmtsIf_24s594_str37);
      break;
    }
    case TAG_Cons: {
      V v_x_2498 = heff_field(v_x2_2497, 0);
      V v_xs_2499 = heff_field(v_x2_2497, 1);
      heff_take_n(v_x2_2497, 3ULL, 2);
      v_t_24100 = ({ V a_0 = v_x_2498; V a_1 = v_xs_2499; V r_ = (g_prelude_2efoldl_24s46(a_0, a_1)); heff_drop(v_xs_2499); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2497);
    }
    V v_t_24101 = heff_tag(TAG_Cons, 2, (V[]){heff_strAppend(v_t_24100, ((V)&g_heff_2eemit_2estmtsIf_24s594_str38)), NTAG(TAG_Nil)});
    V v_t_24102 = heff_tag(TAG_Cons, 2, (V[]){heff_strAppend(v_t_2495, ((V)&g_heff_2eemit_2estmtsIf_24s594_str39)), (g_prelude_2econcatList(v_t_2496, v_t_24101))});
    V v_t_24103 = (g_prelude_2econcatList(v_t_2491, v_t_24102));
    V v_t_24104 = (g_prelude_2econcatList(v_t_2490, v_t_24103));
    return (g_prelude_2econcatList(v_t_2483, v_t_24104));
  }
  default: return heff_nomatch(v_c_242);
  }
}
V g_heff_2eemit_2estmtsIf_24s594_entry(V self, V *a) {
  (void)self;
  return g_heff_2eemit_2estmtsIf_24s594(a[0], a[1], a[2], a[3], a[4]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemit_2ereturnLines_24s595_str0 = {{0x80000000u, K_STR, 0}, 2, 2, {32, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2ereturnLines_24s595_str1 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2eemit_2ereturnLines_24s595_str2 = {{0x80000000u, K_STR, 0}, 7, 7, {114, 101, 116, 117, 114, 110, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2ereturnLines_24s595_str3 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemit_2ereturnLines_24s595_str4 = {{0x80000000u, K_STR, 0}, 2, 2, {32, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2ereturnLines_24s595_str5 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2eemit_2ereturnLines_24s595_str6 = {{0x80000000u, K_STR, 0}, 7, 7, {114, 101, 116, 117, 114, 110, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2ereturnLines_24s595_str7 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemit_2ereturnLines_24s595_str8 = {{0x80000000u, K_STR, 0}, 2, 2, {32, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2ereturnLines_24s595_str9 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2eemit_2ereturnLines_24s595_str10 = {{0x80000000u, K_STR, 0}, 7, 7, {114, 101, 116, 117, 114, 110, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2ereturnLines_24s595_str11 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2ereturnLines_24s595_str12 = {{0x80000000u, K_STR, 0}, 1, 1, {102}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2ereturnLines_24s595_str13 = {{0x80000000u, K_STR, 0}, 1, 1, {97}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemit_2ereturnLines_24s595_str14 = {{0x80000000u, K_STR, 0}, 2, 2, {32, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2ereturnLines_24s595_str15 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2eemit_2ereturnLines_24s595_str16 = {{0x80000000u, K_STR, 0}, 7, 7, {114, 101, 116, 117, 114, 110, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2ereturnLines_24s595_str17 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2ereturnLines_24s595_str18 = {{0x80000000u, K_STR, 0}, 1, 1, {102}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2ereturnLines_24s595_str19 = {{0x80000000u, K_STR, 0}, 1, 1, {97}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemit_2ereturnLines_24s595_str20 = {{0x80000000u, K_STR, 0}, 2, 2, {32, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2ereturnLines_24s595_str21 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2eemit_2ereturnLines_24s595_str22 = {{0x80000000u, K_STR, 0}, 7, 7, {114, 101, 116, 117, 114, 110, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2ereturnLines_24s595_str23 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemit_2ereturnLines_24s595_str24 = {{0x80000000u, K_STR, 0}, 2, 2, {32, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2ereturnLines_24s595_str25 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2eemit_2ereturnLines_24s595_str26 = {{0x80000000u, K_STR, 0}, 7, 7, {114, 101, 116, 117, 114, 110, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2ereturnLines_24s595_str27 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemit_2ereturnLines_24s595_str28 = {{0x80000000u, K_STR, 0}, 2, 2, {32, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2ereturnLines_24s595_str29 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2eemit_2ereturnLines_24s595_str30 = {{0x80000000u, K_STR, 0}, 7, 7, {114, 101, 116, 117, 114, 110, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2ereturnLines_24s595_str31 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemit_2ereturnLines_24s595_str32 = {{0x80000000u, K_STR, 0}, 2, 2, {32, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2ereturnLines_24s595_str33 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2eemit_2ereturnLines_24s595_str34 = {{0x80000000u, K_STR, 0}, 7, 7, {114, 101, 116, 117, 114, 110, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2ereturnLines_24s595_str35 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemit_2ereturnLines_24s595_str36 = {{0x80000000u, K_STR, 0}, 2, 2, {32, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2ereturnLines_24s595_str37 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2eemit_2ereturnLines_24s595_str38 = {{0x80000000u, K_STR, 0}, 7, 7, {114, 101, 116, 117, 114, 110, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2ereturnLines_24s595_str39 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemit_2ereturnLines_24s595_str40 = {{0x80000000u, K_STR, 0}, 2, 2, {32, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2ereturnLines_24s595_str41 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2eemit_2ereturnLines_24s595_str42 = {{0x80000000u, K_STR, 0}, 7, 7, {114, 101, 116, 117, 114, 110, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2ereturnLines_24s595_str43 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemit_2ereturnLines_24s595_str44 = {{0x80000000u, K_STR, 0}, 2, 2, {32, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2ereturnLines_24s595_str45 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2eemit_2ereturnLines_24s595_str46 = {{0x80000000u, K_STR, 0}, 7, 7, {114, 101, 116, 117, 114, 110, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2ereturnLines_24s595_str47 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemit_2ereturnLines_24s595_str48 = {{0x80000000u, K_STR, 0}, 2, 2, {32, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2ereturnLines_24s595_str49 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2eemit_2ereturnLines_24s595_str50 = {{0x80000000u, K_STR, 0}, 7, 7, {114, 101, 116, 117, 114, 110, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2ereturnLines_24s595_str51 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemit_2ereturnLines_24s595_str52 = {{0x80000000u, K_STR, 0}, 2, 2, {32, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2ereturnLines_24s595_str53 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2ereturnLines_24s595_str54 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2ereturnLines_24s595_str55 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2ereturnLines_24s595_str56 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2eemit_2ereturnLines_24s595_str57 = {{0x80000000u, K_STR, 0}, 7, 7, {114, 101, 116, 117, 114, 110, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2ereturnLines_24s595_str58 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemit_2ereturnLines_24s595_str59 = {{0x80000000u, K_STR, 0}, 2, 2, {32, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2ereturnLines_24s595_str60 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2eemit_2ereturnLines_24s595_str61 = {{0x80000000u, K_STR, 0}, 7, 7, {114, 101, 116, 117, 114, 110, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2ereturnLines_24s595_str62 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemit_2ereturnLines_24s595_str63 = {{0x80000000u, K_STR, 0}, 2, 2, {32, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2ereturnLines_24s595_str64 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2eemit_2ereturnLines_24s595_str65 = {{0x80000000u, K_STR, 0}, 7, 7, {114, 101, 116, 117, 114, 110, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2ereturnLines_24s595_str66 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemit_2ereturnLines_24s595_str67 = {{0x80000000u, K_STR, 0}, 2, 2, {32, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2ereturnLines_24s595_str68 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2eemit_2ereturnLines_24s595_str69 = {{0x80000000u, K_STR, 0}, 7, 7, {114, 101, 116, 117, 114, 110, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2ereturnLines_24s595_str70 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemit_2ereturnLines_24s595_str71 = {{0x80000000u, K_STR, 0}, 2, 2, {32, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2ereturnLines_24s595_str72 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2eemit_2ereturnLines_24s595_str73 = {{0x80000000u, K_STR, 0}, 7, 7, {114, 101, 116, 117, 114, 110, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2ereturnLines_24s595_str74 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemit_2ereturnLines_24s595_str75 = {{0x80000000u, K_STR, 0}, 2, 2, {32, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2ereturnLines_24s595_str76 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2eemit_2ereturnLines_24s595_str77 = {{0x80000000u, K_STR, 0}, 7, 7, {114, 101, 116, 117, 114, 110, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2ereturnLines_24s595_str78 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
V g_heff_2eemit_2ereturnLines_24s595_lam0(V self, V *args);
Clo g_heff_2eemit_2ereturnLines_24s595_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemit_2ereturnLines_24s595_entry, 3, 0};

V g_heff_2eemit_2ereturnLines_24s595(V v_env_240, V v_ind_241, V v_e_242) {
top: ;
  switch (heff_tag_of(v_e_242)) {
  case TAG_EVar: {
    V v_x2_244 = (g_prelude_2ereplicate(heff_dup(v_ind_241), ((V)&g_heff_2eemit_2ereturnLines_24s595_str0)));
    V v_t_247;
    switch (heff_tag_of(v_x2_244)) {
    case TAG_Nil: {
      v_t_247 = ((V)&g_heff_2eemit_2ereturnLines_24s595_str1);
      break;
    }
    case TAG_Cons: {
      V v_x_245 = heff_field(v_x2_244, 0);
      V v_xs_246 = heff_field(v_x2_244, 1);
      heff_take_n(v_x2_244, 3ULL, 2);
      v_t_247 = ({ V a_0 = v_x_245; V a_1 = v_xs_246; V r_ = (g_prelude_2efoldl_24s46(a_0, a_1)); heff_drop(v_xs_246); r_; });
      break;
    }
    default: heff_nomatch(v_x2_244);
    }
    V v_t_248 = heff_rec(4, shape_120_200_361_295, (V[]){heff_get(heff_dup(v_env_240), LBL_gs), heff_get(heff_dup(v_env_240), LBL_names), heff_get(v_env_240, LBL_used), NTAG(TAG_Nothing)});
    V v_t_249 = heff_tr(g_heff_2eemit_2eexprGo_24s585(v_t_248, v_ind_241, v_e_242));
    V v_t_2410 = heff_strAppend(v_t_247, heff_strAppend(((V)&g_heff_2eemit_2ereturnLines_24s595_str2), heff_strAppend(heff_get(v_t_249, LBL_code), ((V)&g_heff_2eemit_2ereturnLines_24s595_str3))));
    return heff_tag(TAG_Cons, 2, (V[]){v_t_2410, NTAG(TAG_Nil)});
  }
  case TAG_EGlobal: {
    V v_x2_2412 = (g_prelude_2ereplicate(heff_dup(v_ind_241), ((V)&g_heff_2eemit_2ereturnLines_24s595_str4)));
    V v_t_2415;
    switch (heff_tag_of(v_x2_2412)) {
    case TAG_Nil: {
      v_t_2415 = ((V)&g_heff_2eemit_2ereturnLines_24s595_str5);
      break;
    }
    case TAG_Cons: {
      V v_x_2413 = heff_field(v_x2_2412, 0);
      V v_xs_2414 = heff_field(v_x2_2412, 1);
      heff_take_n(v_x2_2412, 3ULL, 2);
      v_t_2415 = ({ V a_0 = v_x_2413; V a_1 = v_xs_2414; V r_ = (g_prelude_2efoldl_24s46(a_0, a_1)); heff_drop(v_xs_2414); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2412);
    }
    V v_t_2416 = heff_rec(4, shape_120_200_361_295, (V[]){heff_get(heff_dup(v_env_240), LBL_gs), heff_get(heff_dup(v_env_240), LBL_names), heff_get(v_env_240, LBL_used), NTAG(TAG_Nothing)});
    V v_t_2417 = heff_tr(g_heff_2eemit_2eexprGo_24s585(v_t_2416, v_ind_241, v_e_242));
    V v_t_2418 = heff_strAppend(v_t_2415, heff_strAppend(((V)&g_heff_2eemit_2ereturnLines_24s595_str6), heff_strAppend(heff_get(v_t_2417, LBL_code), ((V)&g_heff_2eemit_2ereturnLines_24s595_str7))));
    return heff_tag(TAG_Cons, 2, (V[]){v_t_2418, NTAG(TAG_Nil)});
  }
  case TAG_ELam: {
    V v_x2_2421 = (g_prelude_2ereplicate(heff_dup(v_ind_241), ((V)&g_heff_2eemit_2ereturnLines_24s595_str8)));
    V v_t_2424;
    switch (heff_tag_of(v_x2_2421)) {
    case TAG_Nil: {
      v_t_2424 = ((V)&g_heff_2eemit_2ereturnLines_24s595_str9);
      break;
    }
    case TAG_Cons: {
      V v_x_2422 = heff_field(v_x2_2421, 0);
      V v_xs_2423 = heff_field(v_x2_2421, 1);
      heff_take_n(v_x2_2421, 3ULL, 2);
      v_t_2424 = ({ V a_0 = v_x_2422; V a_1 = v_xs_2423; V r_ = (g_prelude_2efoldl_24s46(a_0, a_1)); heff_drop(v_xs_2423); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2421);
    }
    V v_t_2425 = heff_rec(4, shape_120_200_361_295, (V[]){heff_get(heff_dup(v_env_240), LBL_gs), heff_get(heff_dup(v_env_240), LBL_names), heff_get(v_env_240, LBL_used), NTAG(TAG_Nothing)});
    V v_t_2426 = heff_tr(g_heff_2eemit_2eexprGo_24s585(v_t_2425, v_ind_241, v_e_242));
    V v_t_2427 = heff_strAppend(v_t_2424, heff_strAppend(((V)&g_heff_2eemit_2ereturnLines_24s595_str10), heff_strAppend(heff_get(v_t_2426, LBL_code), ((V)&g_heff_2eemit_2ereturnLines_24s595_str11))));
    return heff_tag(TAG_Cons, 2, (V[]){v_t_2427, NTAG(TAG_Nil)});
  }
  case TAG_EApp: {
    V v_f_2428 = heff_dup(heff_field(v_e_242, 0));
    V v_as_2429 = heff_dup(heff_field(v_e_242, 1));
    V v_t_2430 = (g_heff_2eemit_2eisUnitArgs(v_as_2429));
    switch (heff_tag_of(v_t_2430)) {
    case TAG_True: {
      heff_drop_tag(v_e_242, 2);
      heff_drop(v_as_2429);
      V v_t_2431 = heff_rec(4, shape_120_200_361_295, (V[]){heff_get(heff_dup(v_env_240), LBL_gs), heff_get(heff_dup(v_env_240), LBL_names), heff_get(heff_dup(v_env_240), LBL_used), NTAG(TAG_Nothing)});
      V v_ac_2432 = heff_tr(g_heff_2eemit_2eexprGo_24s585(v_t_2431, heff_dup(v_ind_241), v_f_2428));
      V v_f_2433 = (g_heff_2eemit_2enamed_24s578(v_env_240, heff_dup(v_ind_241), ((V)&g_heff_2eemit_2ereturnLines_24s595_str12)));
      V v_t_2434 = (g_heff_2eemit_2enamed(heff_get(heff_dup(v_f_2433), LBL_env), heff_dup(v_ind_241), ((V)&g_heff_2eemit_2ereturnLines_24s595_str13), v_ac_2432));
      HEFF_LAST return g_heff_2eemit_2ebounceGive(v_ind_241, v_f_2433, v_t_2434);
    }
    case TAG_False: {
      V v_it_2437;
      switch (heff_tag_of(v_as_2429)) {
      case TAG_Nil: {
        v_it_2437 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Cons: {
        V v_x_2435 = heff_field(v_as_2429, 0);
        V v_rest_2436 = heff_field(v_as_2429, 1);
        heff_take_n(v_as_2429, 3ULL, 2);
        v_it_2437 = heff_tag(TAG_Just, 1, (V[]){(g_heff_2eemit_2eunsnocGo(v_rest_2436, v_x_2435))});
        break;
      }
      default: heff_nomatch(v_as_2429);
      }
      switch (heff_tag_of(v_it_2437)) {
      case TAG_Nothing: {
        heff_drop(v_f_2428);
        V v_x2_2438 = (g_prelude_2ereplicate(heff_dup(v_ind_241), ((V)&g_heff_2eemit_2ereturnLines_24s595_str14)));
        V v_t_2441;
        switch (heff_tag_of(v_x2_2438)) {
        case TAG_Nil: {
          v_t_2441 = ((V)&g_heff_2eemit_2ereturnLines_24s595_str15);
          break;
        }
        case TAG_Cons: {
          V v_x_2439 = heff_field(v_x2_2438, 0);
          V v_xs_2440 = heff_field(v_x2_2438, 1);
          heff_take_n(v_x2_2438, 3ULL, 2);
          v_t_2441 = ({ V a_0 = v_x_2439; V a_1 = v_xs_2440; V r_ = (g_prelude_2efoldl_24s46(a_0, a_1)); heff_drop(v_xs_2440); r_; });
          break;
        }
        default: heff_nomatch(v_x2_2438);
        }
        V v_t_2442 = heff_rec(4, shape_120_200_361_295, (V[]){heff_get(heff_dup(v_env_240), LBL_gs), heff_get(heff_dup(v_env_240), LBL_names), heff_get(v_env_240, LBL_used), NTAG(TAG_Nothing)});
        V v_t_2443 = heff_tr(g_heff_2eemit_2eexprGo_24s585(v_t_2442, v_ind_241, v_e_242));
        V v_t_2444 = heff_strAppend(v_t_2441, heff_strAppend(((V)&g_heff_2eemit_2ereturnLines_24s595_str16), heff_strAppend(heff_get(v_t_2443, LBL_code), ((V)&g_heff_2eemit_2ereturnLines_24s595_str17))));
        return heff_tag(TAG_Cons, 2, (V[]){v_t_2444, NTAG(TAG_Nil)});
      }
      case TAG_Just: {
        V v_it1_2445 = heff_field(v_it_2437, 0);
        heff_take_n(v_it_2437, 1ULL, 1);
        heff_drop_tag(v_e_242, 2);
        switch (heff_tag_of(v_it1_2445)) {
        case TAG_MkPair: {
          V v_ini_2446 = heff_field(v_it1_2445, 0);
          V v_a_2447 = heff_field(v_it1_2445, 1);
          V v_ru_24it1_2445_24MkPair = heff_take_reuse_n(v_it1_2445, 3ULL, 2);
          V v_fc_2452;
          switch (heff_tag_of(v_ini_2446)) {
          case TAG_Nil: {
            heff_drop_cell(v_ru_24it1_2445_24MkPair, 2);
            V v_t_2448 = heff_rec(4, shape_120_200_361_295, (V[]){heff_get(heff_dup(v_env_240), LBL_gs), heff_get(heff_dup(v_env_240), LBL_names), heff_get(heff_dup(v_env_240), LBL_used), NTAG(TAG_Nothing)});
            v_fc_2452 = heff_tr(g_heff_2eemit_2eexprGo_24s585(v_t_2448, heff_dup(v_ind_241), v_f_2428));
            break;
          }
          case TAG_Cons: {
            V v_t_2451 = heff_rec(4, shape_120_200_361_295, (V[]){heff_get(heff_dup(v_env_240), LBL_gs), heff_get(heff_dup(v_env_240), LBL_names), heff_get(heff_dup(v_env_240), LBL_used), NTAG(TAG_Nothing)});
            v_fc_2452 = heff_tr(g_heff_2eemit_2eexprGo_24s585(v_t_2451, heff_dup(v_ind_241), heff_tag_at(v_ru_24it1_2445_24MkPair, TAG_EApp, 2, (V[]){v_f_2428, v_ini_2446})));
            break;
          }
          default: heff_nomatch(v_ini_2446);
          }
          V v_t_2453 = heff_rec(4, shape_120_200_361_295, (V[]){heff_get(heff_dup(v_env_240), LBL_gs), heff_get(heff_dup(v_env_240), LBL_names), heff_get(heff_dup(v_env_240), LBL_used), NTAG(TAG_Nothing)});
          V v_ac_2454 = heff_tr(g_heff_2eemit_2eexprGo_24s585(v_t_2453, heff_dup(v_ind_241), v_a_2447));
          V v_f_2455 = (g_heff_2eemit_2enamed(v_env_240, heff_dup(v_ind_241), ((V)&g_heff_2eemit_2ereturnLines_24s595_str18), v_fc_2452));
          V v_t_2456 = (g_heff_2eemit_2enamed(heff_get(heff_dup(v_f_2455), LBL_env), heff_dup(v_ind_241), ((V)&g_heff_2eemit_2ereturnLines_24s595_str19), v_ac_2454));
          HEFF_LAST return g_heff_2eemit_2ebounceGive(v_ind_241, v_f_2455, v_t_2456);
        }
        default: return heff_nomatch(v_it1_2445);
        }
      }
      default: return heff_nomatch(v_it_2437);
      }
    }
    default: return heff_nomatch(v_t_2430);
    }
  }
  case TAG_ELet: {
    V v_x2_2460 = (g_prelude_2ereplicate(heff_dup(v_ind_241), ((V)&g_heff_2eemit_2ereturnLines_24s595_str20)));
    V v_t_2463;
    switch (heff_tag_of(v_x2_2460)) {
    case TAG_Nil: {
      v_t_2463 = ((V)&g_heff_2eemit_2ereturnLines_24s595_str21);
      break;
    }
    case TAG_Cons: {
      V v_x_2461 = heff_field(v_x2_2460, 0);
      V v_xs_2462 = heff_field(v_x2_2460, 1);
      heff_take_n(v_x2_2460, 3ULL, 2);
      v_t_2463 = ({ V a_0 = v_x_2461; V a_1 = v_xs_2462; V r_ = (g_prelude_2efoldl_24s46(a_0, a_1)); heff_drop(v_xs_2462); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2460);
    }
    V v_t_2464 = heff_rec(4, shape_120_200_361_295, (V[]){heff_get(heff_dup(v_env_240), LBL_gs), heff_get(heff_dup(v_env_240), LBL_names), heff_get(v_env_240, LBL_used), NTAG(TAG_Nothing)});
    V v_t_2465 = heff_tr(g_heff_2eemit_2eexprGo_24s585(v_t_2464, v_ind_241, v_e_242));
    V v_t_2466 = heff_strAppend(v_t_2463, heff_strAppend(((V)&g_heff_2eemit_2ereturnLines_24s595_str22), heff_strAppend(heff_get(v_t_2465, LBL_code), ((V)&g_heff_2eemit_2ereturnLines_24s595_str23))));
    return heff_tag(TAG_Cons, 2, (V[]){v_t_2466, NTAG(TAG_Nil)});
  }
  case TAG_ERecord: {
    V v_x2_2468 = (g_prelude_2ereplicate(heff_dup(v_ind_241), ((V)&g_heff_2eemit_2ereturnLines_24s595_str24)));
    V v_t_2471;
    switch (heff_tag_of(v_x2_2468)) {
    case TAG_Nil: {
      v_t_2471 = ((V)&g_heff_2eemit_2ereturnLines_24s595_str25);
      break;
    }
    case TAG_Cons: {
      V v_x_2469 = heff_field(v_x2_2468, 0);
      V v_xs_2470 = heff_field(v_x2_2468, 1);
      heff_take_n(v_x2_2468, 3ULL, 2);
      v_t_2471 = ({ V a_0 = v_x_2469; V a_1 = v_xs_2470; V r_ = (g_prelude_2efoldl_24s46(a_0, a_1)); heff_drop(v_xs_2470); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2468);
    }
    V v_t_2472 = heff_rec(4, shape_120_200_361_295, (V[]){heff_get(heff_dup(v_env_240), LBL_gs), heff_get(heff_dup(v_env_240), LBL_names), heff_get(v_env_240, LBL_used), NTAG(TAG_Nothing)});
    V v_t_2473 = heff_tr(g_heff_2eemit_2eexprGo_24s585(v_t_2472, v_ind_241, v_e_242));
    V v_t_2474 = heff_strAppend(v_t_2471, heff_strAppend(((V)&g_heff_2eemit_2ereturnLines_24s595_str26), heff_strAppend(heff_get(v_t_2473, LBL_code), ((V)&g_heff_2eemit_2ereturnLines_24s595_str27))));
    return heff_tag(TAG_Cons, 2, (V[]){v_t_2474, NTAG(TAG_Nil)});
  }
  case TAG_EProj: {
    V v_x2_2477 = (g_prelude_2ereplicate(heff_dup(v_ind_241), ((V)&g_heff_2eemit_2ereturnLines_24s595_str28)));
    V v_t_2480;
    switch (heff_tag_of(v_x2_2477)) {
    case TAG_Nil: {
      v_t_2480 = ((V)&g_heff_2eemit_2ereturnLines_24s595_str29);
      break;
    }
    case TAG_Cons: {
      V v_x_2478 = heff_field(v_x2_2477, 0);
      V v_xs_2479 = heff_field(v_x2_2477, 1);
      heff_take_n(v_x2_2477, 3ULL, 2);
      v_t_2480 = ({ V a_0 = v_x_2478; V a_1 = v_xs_2479; V r_ = (g_prelude_2efoldl_24s46(a_0, a_1)); heff_drop(v_xs_2479); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2477);
    }
    V v_t_2481 = heff_rec(4, shape_120_200_361_295, (V[]){heff_get(heff_dup(v_env_240), LBL_gs), heff_get(heff_dup(v_env_240), LBL_names), heff_get(v_env_240, LBL_used), NTAG(TAG_Nothing)});
    V v_t_2482 = heff_tr(g_heff_2eemit_2eexprGo_24s585(v_t_2481, v_ind_241, v_e_242));
    V v_t_2483 = heff_strAppend(v_t_2480, heff_strAppend(((V)&g_heff_2eemit_2ereturnLines_24s595_str30), heff_strAppend(heff_get(v_t_2482, LBL_code), ((V)&g_heff_2eemit_2ereturnLines_24s595_str31))));
    return heff_tag(TAG_Cons, 2, (V[]){v_t_2483, NTAG(TAG_Nil)});
  }
  case TAG_ETag: {
    V v_x2_2486 = (g_prelude_2ereplicate(heff_dup(v_ind_241), ((V)&g_heff_2eemit_2ereturnLines_24s595_str32)));
    V v_t_2489;
    switch (heff_tag_of(v_x2_2486)) {
    case TAG_Nil: {
      v_t_2489 = ((V)&g_heff_2eemit_2ereturnLines_24s595_str33);
      break;
    }
    case TAG_Cons: {
      V v_x_2487 = heff_field(v_x2_2486, 0);
      V v_xs_2488 = heff_field(v_x2_2486, 1);
      heff_take_n(v_x2_2486, 3ULL, 2);
      v_t_2489 = ({ V a_0 = v_x_2487; V a_1 = v_xs_2488; V r_ = (g_prelude_2efoldl_24s46(a_0, a_1)); heff_drop(v_xs_2488); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2486);
    }
    V v_t_2490 = heff_rec(4, shape_120_200_361_295, (V[]){heff_get(heff_dup(v_env_240), LBL_gs), heff_get(heff_dup(v_env_240), LBL_names), heff_get(v_env_240, LBL_used), NTAG(TAG_Nothing)});
    V v_t_2491 = heff_tr(g_heff_2eemit_2eexprGo_24s585(v_t_2490, v_ind_241, v_e_242));
    V v_t_2492 = heff_strAppend(v_t_2489, heff_strAppend(((V)&g_heff_2eemit_2ereturnLines_24s595_str34), heff_strAppend(heff_get(v_t_2491, LBL_code), ((V)&g_heff_2eemit_2ereturnLines_24s595_str35))));
    return heff_tag(TAG_Cons, 2, (V[]){v_t_2492, NTAG(TAG_Nil)});
  }
  case TAG_EMatch: {
    V v_x2_2495 = (g_prelude_2ereplicate(heff_dup(v_ind_241), ((V)&g_heff_2eemit_2ereturnLines_24s595_str36)));
    V v_t_2498;
    switch (heff_tag_of(v_x2_2495)) {
    case TAG_Nil: {
      v_t_2498 = ((V)&g_heff_2eemit_2ereturnLines_24s595_str37);
      break;
    }
    case TAG_Cons: {
      V v_x_2496 = heff_field(v_x2_2495, 0);
      V v_xs_2497 = heff_field(v_x2_2495, 1);
      heff_take_n(v_x2_2495, 3ULL, 2);
      v_t_2498 = ({ V a_0 = v_x_2496; V a_1 = v_xs_2497; V r_ = (g_prelude_2efoldl_24s46(a_0, a_1)); heff_drop(v_xs_2497); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2495);
    }
    V v_t_2499 = heff_rec(4, shape_120_200_361_295, (V[]){heff_get(heff_dup(v_env_240), LBL_gs), heff_get(heff_dup(v_env_240), LBL_names), heff_get(v_env_240, LBL_used), NTAG(TAG_Nothing)});
    V v_t_24100 = heff_tr(g_heff_2eemit_2eexprGo_24s585(v_t_2499, v_ind_241, v_e_242));
    V v_t_24101 = heff_strAppend(v_t_2498, heff_strAppend(((V)&g_heff_2eemit_2ereturnLines_24s595_str38), heff_strAppend(heff_get(v_t_24100, LBL_code), ((V)&g_heff_2eemit_2ereturnLines_24s595_str39))));
    return heff_tag(TAG_Cons, 2, (V[]){v_t_24101, NTAG(TAG_Nil)});
  }
  case TAG_EPrim: {
    V v_x2_24103 = (g_prelude_2ereplicate(heff_dup(v_ind_241), ((V)&g_heff_2eemit_2ereturnLines_24s595_str40)));
    V v_t_24106;
    switch (heff_tag_of(v_x2_24103)) {
    case TAG_Nil: {
      v_t_24106 = ((V)&g_heff_2eemit_2ereturnLines_24s595_str41);
      break;
    }
    case TAG_Cons: {
      V v_x_24104 = heff_field(v_x2_24103, 0);
      V v_xs_24105 = heff_field(v_x2_24103, 1);
      heff_take_n(v_x2_24103, 3ULL, 2);
      v_t_24106 = ({ V a_0 = v_x_24104; V a_1 = v_xs_24105; V r_ = (g_prelude_2efoldl_24s46(a_0, a_1)); heff_drop(v_xs_24105); r_; });
      break;
    }
    default: heff_nomatch(v_x2_24103);
    }
    V v_t_24107 = heff_rec(4, shape_120_200_361_295, (V[]){heff_get(heff_dup(v_env_240), LBL_gs), heff_get(heff_dup(v_env_240), LBL_names), heff_get(v_env_240, LBL_used), NTAG(TAG_Nothing)});
    V v_t_24108 = heff_tr(g_heff_2eemit_2eexprGo_24s585(v_t_24107, v_ind_241, v_e_242));
    V v_t_24109 = heff_strAppend(v_t_24106, heff_strAppend(((V)&g_heff_2eemit_2ereturnLines_24s595_str42), heff_strAppend(heff_get(v_t_24108, LBL_code), ((V)&g_heff_2eemit_2ereturnLines_24s595_str43))));
    return heff_tag(TAG_Cons, 2, (V[]){v_t_24109, NTAG(TAG_Nil)});
  }
  case TAG_EPrimCall: {
    V v_x2_24112 = (g_prelude_2ereplicate(heff_dup(v_ind_241), ((V)&g_heff_2eemit_2ereturnLines_24s595_str44)));
    V v_t_24115;
    switch (heff_tag_of(v_x2_24112)) {
    case TAG_Nil: {
      v_t_24115 = ((V)&g_heff_2eemit_2ereturnLines_24s595_str45);
      break;
    }
    case TAG_Cons: {
      V v_x_24113 = heff_field(v_x2_24112, 0);
      V v_xs_24114 = heff_field(v_x2_24112, 1);
      heff_take_n(v_x2_24112, 3ULL, 2);
      v_t_24115 = ({ V a_0 = v_x_24113; V a_1 = v_xs_24114; V r_ = (g_prelude_2efoldl_24s46(a_0, a_1)); heff_drop(v_xs_24114); r_; });
      break;
    }
    default: heff_nomatch(v_x2_24112);
    }
    V v_t_24116 = heff_rec(4, shape_120_200_361_295, (V[]){heff_get(heff_dup(v_env_240), LBL_gs), heff_get(heff_dup(v_env_240), LBL_names), heff_get(v_env_240, LBL_used), NTAG(TAG_Nothing)});
    V v_t_24117 = heff_tr(g_heff_2eemit_2eexprGo_24s585(v_t_24116, v_ind_241, v_e_242));
    V v_t_24118 = heff_strAppend(v_t_24115, heff_strAppend(((V)&g_heff_2eemit_2ereturnLines_24s595_str46), heff_strAppend(heff_get(v_t_24117, LBL_code), ((V)&g_heff_2eemit_2ereturnLines_24s595_str47))));
    return heff_tag(TAG_Cons, 2, (V[]){v_t_24118, NTAG(TAG_Nil)});
  }
  case TAG_ECall: {
    V v_g_24119 = heff_dup(heff_field(v_e_242, 0));
    V v_as_24120 = heff_dup(heff_field(v_e_242, 1));
    V v_t_24121 = (g_heff_2eemit_2eisUnitArgs(v_as_24120));
    switch (heff_tag_of(v_t_24121)) {
    case TAG_True: {
      heff_drop(v_g_24119);
      heff_drop(v_as_24120);
      V v_x2_24122 = (g_prelude_2ereplicate(heff_dup(v_ind_241), ((V)&g_heff_2eemit_2ereturnLines_24s595_str48)));
      V v_t_24125;
      switch (heff_tag_of(v_x2_24122)) {
      case TAG_Nil: {
        v_t_24125 = ((V)&g_heff_2eemit_2ereturnLines_24s595_str49);
        break;
      }
      case TAG_Cons: {
        V v_x_24123 = heff_field(v_x2_24122, 0);
        V v_xs_24124 = heff_field(v_x2_24122, 1);
        heff_take_n(v_x2_24122, 3ULL, 2);
        v_t_24125 = ({ V a_0 = v_x_24123; V a_1 = v_xs_24124; V r_ = (g_prelude_2efoldl_24s46(a_0, a_1)); heff_drop(v_xs_24124); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24122);
      }
      V v_t_24126 = heff_rec(4, shape_120_200_361_295, (V[]){heff_get(heff_dup(v_env_240), LBL_gs), heff_get(heff_dup(v_env_240), LBL_names), heff_get(v_env_240, LBL_used), NTAG(TAG_Nothing)});
      V v_t_24127 = heff_tr(g_heff_2eemit_2eexprGo_24s585(v_t_24126, v_ind_241, v_e_242));
      V v_t_24128 = heff_strAppend(v_t_24125, heff_strAppend(((V)&g_heff_2eemit_2ereturnLines_24s595_str50), heff_strAppend(heff_get(v_t_24127, LBL_code), ((V)&g_heff_2eemit_2ereturnLines_24s595_str51))));
      return heff_tag(TAG_Cons, 2, (V[]){v_t_24128, NTAG(TAG_Nil)});
    }
    case TAG_False: {
      heff_drop_tag(v_e_242, 2);
      V v_x2_24129 = (g_prelude_2ereplicate(heff_dup(v_ind_241), ((V)&g_heff_2eemit_2ereturnLines_24s595_str52)));
      V v_t_24132;
      switch (heff_tag_of(v_x2_24129)) {
      case TAG_Nil: {
        v_t_24132 = ((V)&g_heff_2eemit_2ereturnLines_24s595_str53);
        break;
      }
      case TAG_Cons: {
        V v_x_24130 = heff_field(v_x2_24129, 0);
        V v_xs_24131 = heff_field(v_x2_24129, 1);
        heff_take_n(v_x2_24129, 3ULL, 2);
        v_t_24132 = ({ V a_0 = v_x_24130; V a_1 = v_xs_24131; V r_ = (g_prelude_2efoldl_24s46(a_0, a_1)); heff_drop(v_xs_24131); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24129);
      }
      V v_t_24133 = (g_heff_2eemit_2ecallName(heff_dup(v_env_240), v_g_24119));
      V v_x2_24137 = (g_prelude_2emap(heff_clo(g_heff_2eemit_2ereturnLines_24s595_lam0, 1, 2, (V[]){v_env_240, v_ind_241}), v_as_24120));
      V v_t_24140;
      switch (heff_tag_of(v_x2_24137)) {
      case TAG_Nil: {
        v_t_24140 = ((V)&g_heff_2eemit_2ereturnLines_24s595_str54);
        break;
      }
      case TAG_Cons: {
        V v_x_24138 = heff_field(v_x2_24137, 0);
        V v_xs_24139 = heff_field(v_x2_24137, 1);
        heff_take_n(v_x2_24137, 3ULL, 2);
        v_t_24140 = ({ V a_0 = v_x_24138; V a_1 = v_xs_24139; V r_ = (g_prelude_2efoldl_24s45(a_0, a_1)); heff_drop(v_xs_24139); r_; });
        break;
      }
      default: heff_nomatch(v_x2_24137);
      }
      V v_t_24141 = heff_strAppend(v_t_24133, heff_strAppend(((V)&g_heff_2eemit_2ereturnLines_24s595_str55), heff_strAppend(v_t_24140, ((V)&g_heff_2eemit_2ereturnLines_24s595_str56))));
      V v_t_24142 = heff_strAppend(v_t_24132, heff_strAppend(((V)&g_heff_2eemit_2ereturnLines_24s595_str57), heff_strAppend(v_t_24141, ((V)&g_heff_2eemit_2ereturnLines_24s595_str58))));
      return heff_tag(TAG_Cons, 2, (V[]){v_t_24142, NTAG(TAG_Nil)});
    }
    default: return heff_nomatch(v_t_24121);
    }
  }
  case TAG_EInt: {
    V v_x2_24144 = (g_prelude_2ereplicate(heff_dup(v_ind_241), ((V)&g_heff_2eemit_2ereturnLines_24s595_str59)));
    V v_t_24147;
    switch (heff_tag_of(v_x2_24144)) {
    case TAG_Nil: {
      v_t_24147 = ((V)&g_heff_2eemit_2ereturnLines_24s595_str60);
      break;
    }
    case TAG_Cons: {
      V v_x_24145 = heff_field(v_x2_24144, 0);
      V v_xs_24146 = heff_field(v_x2_24144, 1);
      heff_take_n(v_x2_24144, 3ULL, 2);
      v_t_24147 = ({ V a_0 = v_x_24145; V a_1 = v_xs_24146; V r_ = (g_prelude_2efoldl_24s46(a_0, a_1)); heff_drop(v_xs_24146); r_; });
      break;
    }
    default: heff_nomatch(v_x2_24144);
    }
    V v_t_24148 = heff_rec(4, shape_120_200_361_295, (V[]){heff_get(heff_dup(v_env_240), LBL_gs), heff_get(heff_dup(v_env_240), LBL_names), heff_get(v_env_240, LBL_used), NTAG(TAG_Nothing)});
    V v_t_24149 = heff_tr(g_heff_2eemit_2eexprGo_24s585(v_t_24148, v_ind_241, v_e_242));
    V v_t_24150 = heff_strAppend(v_t_24147, heff_strAppend(((V)&g_heff_2eemit_2ereturnLines_24s595_str61), heff_strAppend(heff_get(v_t_24149, LBL_code), ((V)&g_heff_2eemit_2ereturnLines_24s595_str62))));
    return heff_tag(TAG_Cons, 2, (V[]){v_t_24150, NTAG(TAG_Nil)});
  }
  case TAG_EFloat: {
    V v_x2_24152 = (g_prelude_2ereplicate(heff_dup(v_ind_241), ((V)&g_heff_2eemit_2ereturnLines_24s595_str63)));
    V v_t_24155;
    switch (heff_tag_of(v_x2_24152)) {
    case TAG_Nil: {
      v_t_24155 = ((V)&g_heff_2eemit_2ereturnLines_24s595_str64);
      break;
    }
    case TAG_Cons: {
      V v_x_24153 = heff_field(v_x2_24152, 0);
      V v_xs_24154 = heff_field(v_x2_24152, 1);
      heff_take_n(v_x2_24152, 3ULL, 2);
      v_t_24155 = ({ V a_0 = v_x_24153; V a_1 = v_xs_24154; V r_ = (g_prelude_2efoldl_24s46(a_0, a_1)); heff_drop(v_xs_24154); r_; });
      break;
    }
    default: heff_nomatch(v_x2_24152);
    }
    V v_t_24156 = heff_rec(4, shape_120_200_361_295, (V[]){heff_get(heff_dup(v_env_240), LBL_gs), heff_get(heff_dup(v_env_240), LBL_names), heff_get(v_env_240, LBL_used), NTAG(TAG_Nothing)});
    V v_t_24157 = heff_tr(g_heff_2eemit_2eexprGo_24s585(v_t_24156, v_ind_241, v_e_242));
    V v_t_24158 = heff_strAppend(v_t_24155, heff_strAppend(((V)&g_heff_2eemit_2ereturnLines_24s595_str65), heff_strAppend(heff_get(v_t_24157, LBL_code), ((V)&g_heff_2eemit_2ereturnLines_24s595_str66))));
    return heff_tag(TAG_Cons, 2, (V[]){v_t_24158, NTAG(TAG_Nil)});
  }
  case TAG_EStr: {
    V v_x2_24160 = (g_prelude_2ereplicate(heff_dup(v_ind_241), ((V)&g_heff_2eemit_2ereturnLines_24s595_str67)));
    V v_t_24163;
    switch (heff_tag_of(v_x2_24160)) {
    case TAG_Nil: {
      v_t_24163 = ((V)&g_heff_2eemit_2ereturnLines_24s595_str68);
      break;
    }
    case TAG_Cons: {
      V v_x_24161 = heff_field(v_x2_24160, 0);
      V v_xs_24162 = heff_field(v_x2_24160, 1);
      heff_take_n(v_x2_24160, 3ULL, 2);
      v_t_24163 = ({ V a_0 = v_x_24161; V a_1 = v_xs_24162; V r_ = (g_prelude_2efoldl_24s46(a_0, a_1)); heff_drop(v_xs_24162); r_; });
      break;
    }
    default: heff_nomatch(v_x2_24160);
    }
    V v_t_24164 = heff_rec(4, shape_120_200_361_295, (V[]){heff_get(heff_dup(v_env_240), LBL_gs), heff_get(heff_dup(v_env_240), LBL_names), heff_get(v_env_240, LBL_used), NTAG(TAG_Nothing)});
    V v_t_24165 = heff_tr(g_heff_2eemit_2eexprGo_24s585(v_t_24164, v_ind_241, v_e_242));
    V v_t_24166 = heff_strAppend(v_t_24163, heff_strAppend(((V)&g_heff_2eemit_2ereturnLines_24s595_str69), heff_strAppend(heff_get(v_t_24165, LBL_code), ((V)&g_heff_2eemit_2ereturnLines_24s595_str70))));
    return heff_tag(TAG_Cons, 2, (V[]){v_t_24166, NTAG(TAG_Nil)});
  }
  case TAG_EAbandon: {
    V v_x2_24167 = (g_prelude_2ereplicate(heff_dup(v_ind_241), ((V)&g_heff_2eemit_2ereturnLines_24s595_str71)));
    V v_t_24170;
    switch (heff_tag_of(v_x2_24167)) {
    case TAG_Nil: {
      v_t_24170 = ((V)&g_heff_2eemit_2ereturnLines_24s595_str72);
      break;
    }
    case TAG_Cons: {
      V v_x_24168 = heff_field(v_x2_24167, 0);
      V v_xs_24169 = heff_field(v_x2_24167, 1);
      heff_take_n(v_x2_24167, 3ULL, 2);
      v_t_24170 = ({ V a_0 = v_x_24168; V a_1 = v_xs_24169; V r_ = (g_prelude_2efoldl_24s46(a_0, a_1)); heff_drop(v_xs_24169); r_; });
      break;
    }
    default: heff_nomatch(v_x2_24167);
    }
    V v_t_24171 = heff_rec(4, shape_120_200_361_295, (V[]){heff_get(heff_dup(v_env_240), LBL_gs), heff_get(heff_dup(v_env_240), LBL_names), heff_get(v_env_240, LBL_used), NTAG(TAG_Nothing)});
    V v_t_24172 = heff_tr(g_heff_2eemit_2eexprGo_24s585(v_t_24171, v_ind_241, v_e_242));
    V v_t_24173 = heff_strAppend(v_t_24170, heff_strAppend(((V)&g_heff_2eemit_2ereturnLines_24s595_str73), heff_strAppend(heff_get(v_t_24172, LBL_code), ((V)&g_heff_2eemit_2ereturnLines_24s595_str74))));
    return heff_tag(TAG_Cons, 2, (V[]){v_t_24173, NTAG(TAG_Nil)});
  }
  case TAG_EFix: {
    V v_x2_24176 = (g_prelude_2ereplicate(heff_dup(v_ind_241), ((V)&g_heff_2eemit_2ereturnLines_24s595_str75)));
    V v_t_24179;
    switch (heff_tag_of(v_x2_24176)) {
    case TAG_Nil: {
      v_t_24179 = ((V)&g_heff_2eemit_2ereturnLines_24s595_str76);
      break;
    }
    case TAG_Cons: {
      V v_x_24177 = heff_field(v_x2_24176, 0);
      V v_xs_24178 = heff_field(v_x2_24176, 1);
      heff_take_n(v_x2_24176, 3ULL, 2);
      v_t_24179 = ({ V a_0 = v_x_24177; V a_1 = v_xs_24178; V r_ = (g_prelude_2efoldl_24s46(a_0, a_1)); heff_drop(v_xs_24178); r_; });
      break;
    }
    default: heff_nomatch(v_x2_24176);
    }
    V v_t_24180 = heff_rec(4, shape_120_200_361_295, (V[]){heff_get(heff_dup(v_env_240), LBL_gs), heff_get(heff_dup(v_env_240), LBL_names), heff_get(v_env_240, LBL_used), NTAG(TAG_Nothing)});
    V v_t_24181 = heff_tr(g_heff_2eemit_2eexprGo_24s585(v_t_24180, v_ind_241, v_e_242));
    V v_t_24182 = heff_strAppend(v_t_24179, heff_strAppend(((V)&g_heff_2eemit_2ereturnLines_24s595_str77), heff_strAppend(heff_get(v_t_24181, LBL_code), ((V)&g_heff_2eemit_2ereturnLines_24s595_str78))));
    return heff_tag(TAG_Cons, 2, (V[]){v_t_24182, NTAG(TAG_Nil)});
  }
  default: return heff_nomatch(v_e_242);
  }
}
V g_heff_2eemit_2ereturnLines_24s595_entry(V self, V *a) {
  (void)self;
  return g_heff_2eemit_2ereturnLines_24s595(a[0], a[1], a[2]);
}
V g_heff_2eemit_2ereturnLines_24s595_lam0(V self, V *args) {
  V v_a_24134 = args[0];
  V v_env_240 = heff_env(self)[0];
  V v_ind_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_24135 = heff_rec(4, shape_120_200_361_295, (V[]){heff_get(heff_dup(v_env_240), LBL_gs), heff_get(heff_dup(v_env_240), LBL_names), heff_get(v_env_240, LBL_used), NTAG(TAG_Nothing)});
  V v_t_24136 = heff_tr(g_heff_2eemit_2eexprGo_24s585(v_t_24135, v_ind_241, v_a_24134));
  return heff_get(v_t_24136, LBL_code);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemit_2elastTrmc_24s598_str0 = {{0x80000000u, K_STR, 0}, 2, 2, {32, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2elastTrmc_24s598_str1 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2eemit_2elastTrmc_24s598_str2 = {{0x80000000u, K_STR, 0}, 6, 6, {99, 111, 110, 115, 116, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemit_2elastTrmc_24s598_str3 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 61, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2elastTrmc_24s598_str4 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemit_2elastTrmc_24s598_str5 = {{0x80000000u, K_STR, 0}, 2, 2, {32, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2elastTrmc_24s598_str6 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[28]; } g_heff_2eemit_2elastTrmc_24s598_str7 = {{0x80000000u, K_STR, 0}, 28, 28, {105, 102, 32, 40, 36, 104, 111, 108, 101, 41, 32, 123, 32, 36, 104, 111, 108, 101, 46, 97, 91, 36, 97, 116, 93, 32, 61, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[17]; } g_heff_2eemit_2elastTrmc_24s598_str8 = {{0x80000000u, K_STR, 0}, 17, 17, {59, 32, 114, 101, 116, 117, 114, 110, 32, 36, 114, 111, 111, 116, 59, 32, 125}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemit_2elastTrmc_24s598_str9 = {{0x80000000u, K_STR, 0}, 2, 2, {32, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2elastTrmc_24s598_str10 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2eemit_2elastTrmc_24s598_str11 = {{0x80000000u, K_STR, 0}, 7, 7, {114, 101, 116, 117, 114, 110, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2elastTrmc_24s598_str12 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
Clo g_heff_2eemit_2elastTrmc_24s598_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemit_2elastTrmc_24s598_entry, 4, 0};

V g_heff_2eemit_2elastTrmc_24s598(V v_env_240, V v_ind_241, V v_e_242, V v_rr_243) {
top: ;
  V v_x2_244 = (g_prelude_2ereplicate(heff_dup(v_ind_241), ((V)&g_heff_2eemit_2elastTrmc_24s598_str0)));
  V v_t_247;
  switch (heff_tag_of(v_x2_244)) {
  case TAG_Nil: {
    v_t_247 = ((V)&g_heff_2eemit_2elastTrmc_24s598_str1);
    break;
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x2_244, 0);
    V v_xs_246 = heff_field(v_x2_244, 1);
    heff_take_n(v_x2_244, 3ULL, 2);
    v_t_247 = ({ V a_0 = v_x_245; V a_1 = v_xs_246; V r_ = (g_prelude_2efoldl_24s46(a_0, a_1)); heff_drop(v_xs_246); r_; });
    break;
  }
  default: heff_nomatch(v_x2_244);
  }
  V v_t_248 = heff_rec(4, shape_120_200_361_295, (V[]){heff_get(heff_dup(v_env_240), LBL_gs), heff_get(heff_dup(v_env_240), LBL_names), heff_get(v_env_240, LBL_used), NTAG(TAG_Nothing)});
  V v_t_249 = heff_tr(g_heff_2eemit_2eexprGo_24s585(v_t_248, heff_dup(v_ind_241), v_e_242));
  V v_t_2410 = heff_strAppend(v_t_247, heff_strAppend(((V)&g_heff_2eemit_2elastTrmc_24s598_str2), heff_strAppend(heff_get(heff_dup(v_rr_243), LBL_js), heff_strAppend(((V)&g_heff_2eemit_2elastTrmc_24s598_str3), heff_strAppend(heff_get(v_t_249, LBL_code), ((V)&g_heff_2eemit_2elastTrmc_24s598_str4))))));
  V v_x2_2411 = (g_prelude_2ereplicate(heff_dup(v_ind_241), ((V)&g_heff_2eemit_2elastTrmc_24s598_str5)));
  V v_t_2414;
  switch (heff_tag_of(v_x2_2411)) {
  case TAG_Nil: {
    v_t_2414 = ((V)&g_heff_2eemit_2elastTrmc_24s598_str6);
    break;
  }
  case TAG_Cons: {
    V v_x_2412 = heff_field(v_x2_2411, 0);
    V v_xs_2413 = heff_field(v_x2_2411, 1);
    heff_take_n(v_x2_2411, 3ULL, 2);
    v_t_2414 = ({ V a_0 = v_x_2412; V a_1 = v_xs_2413; V r_ = (g_prelude_2efoldl_24s46(a_0, a_1)); heff_drop(v_xs_2413); r_; });
    break;
  }
  default: heff_nomatch(v_x2_2411);
  }
  V v_t_2415 = heff_strAppend(v_t_2414, heff_strAppend(((V)&g_heff_2eemit_2elastTrmc_24s598_str7), heff_strAppend(heff_get(heff_dup(v_rr_243), LBL_js), ((V)&g_heff_2eemit_2elastTrmc_24s598_str8))));
  V v_x2_2416 = (g_prelude_2ereplicate(v_ind_241, ((V)&g_heff_2eemit_2elastTrmc_24s598_str9)));
  V v_t_2419;
  switch (heff_tag_of(v_x2_2416)) {
  case TAG_Nil: {
    v_t_2419 = ((V)&g_heff_2eemit_2elastTrmc_24s598_str10);
    break;
  }
  case TAG_Cons: {
    V v_x_2417 = heff_field(v_x2_2416, 0);
    V v_xs_2418 = heff_field(v_x2_2416, 1);
    heff_take_n(v_x2_2416, 3ULL, 2);
    v_t_2419 = ({ V a_0 = v_x_2417; V a_1 = v_xs_2418; V r_ = (g_prelude_2efoldl_24s46(a_0, a_1)); heff_drop(v_xs_2418); r_; });
    break;
  }
  default: heff_nomatch(v_x2_2416);
  }
  V v_t_2420 = heff_strAppend(v_t_2419, heff_strAppend(((V)&g_heff_2eemit_2elastTrmc_24s598_str11), heff_strAppend(heff_get(v_rr_243, LBL_js), ((V)&g_heff_2eemit_2elastTrmc_24s598_str12))));
  V v_t_2421 = heff_tag(TAG_Cons, 2, (V[]){v_t_2420, NTAG(TAG_Nil)});
  return heff_tag(TAG_Cons, 2, (V[]){v_t_2410, heff_tag(TAG_Cons, 2, (V[]){v_t_2415, v_t_2421})});
}
V g_heff_2eemit_2elastTrmc_24s598_entry(V self, V *a) {
  (void)self;
  return g_heff_2eemit_2elastTrmc_24s598(a[0], a[1], a[2], a[3]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2elastOther_24s597_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {114}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemit_2elastOther_24s597_str1 = {{0x80000000u, K_STR, 0}, 2, 2, {32, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2elastOther_24s597_str2 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2elastOther_24s597_str3 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2elastOther_24s597_str4 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[12]; } g_heff_2eemit_2elastOther_24s597_str5 = {{0x80000000u, K_STR, 0}, 12, 12, {114, 101, 116, 117, 114, 110, 32, 36, 115, 32, 43, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2elastOther_24s597_str6 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
Clo g_heff_2eemit_2elastOther_24s597_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemit_2elastOther_24s597_entry, 4, 0};

V g_heff_2eemit_2elastOther_24s597(V v_env_240, V v_s_241, V v_ind_242, V v_e_243) {
top: ;
  V v_t_244 = heff_get(heff_dup(v_s_241), LBL_trmc);
  switch (heff_tag_of(v_t_244)) {
  case TAG_True: {
    heff_drop(v_s_241);
    V v_t_245 = (g_heff_2eemit_2ebindName(heff_dup(v_env_240), ((V)&g_heff_2eemit_2elastOther_24s597_str0)));
    HEFF_LAST return g_heff_2eemit_2elastTrmc_24s598(v_env_240, v_ind_242, v_e_243, v_t_245);
  }
  case TAG_False: {
    V v_t_246 = heff_get(v_s_241, LBL_sapp);
    switch (heff_tag_of(v_t_246)) {
    case TAG_True: {
      V v_x2_247 = (g_prelude_2ereplicate(heff_dup(v_ind_242), ((V)&g_heff_2eemit_2elastOther_24s597_str1)));
      V v_t_2410;
      switch (heff_tag_of(v_x2_247)) {
      case TAG_Nil: {
        v_t_2410 = ((V)&g_heff_2eemit_2elastOther_24s597_str2);
        break;
      }
      case TAG_Cons: {
        V v_x_248 = heff_field(v_x2_247, 0);
        V v_xs_249 = heff_field(v_x2_247, 1);
        heff_take_n(v_x2_247, 3ULL, 2);
        v_t_2410 = ({ V a_0 = v_x_248; V a_1 = v_xs_249; V r_ = (g_prelude_2efoldl_24s46(a_0, a_1)); heff_drop(v_xs_249); r_; });
        break;
      }
      default: heff_nomatch(v_x2_247);
      }
      V v_t_2411 = heff_rec(4, shape_120_200_361_295, (V[]){heff_get(heff_dup(v_env_240), LBL_gs), heff_get(heff_dup(v_env_240), LBL_names), heff_get(v_env_240, LBL_used), NTAG(TAG_Nothing)});
      V v_c_2412 = heff_tr(g_heff_2eemit_2eexprGo_24s585(v_t_2411, v_ind_242, v_e_243));
      V v_t_2413 = heff_intLt(heff_get(heff_dup(v_c_2412), LBL_prec), MK_INT(2LL));
      V v_t_2414;
      switch (heff_tag_of(v_t_2413)) {
      case TAG_True: {
        v_t_2414 = heff_strAppend(((V)&g_heff_2eemit_2elastOther_24s597_str3), heff_strAppend(heff_get(v_c_2412, LBL_code), ((V)&g_heff_2eemit_2elastOther_24s597_str4)));
        break;
      }
      case TAG_False: {
        v_t_2414 = heff_get(v_c_2412, LBL_code);
        break;
      }
      default: heff_nomatch(v_t_2413);
      }
      V v_t_2415 = heff_strAppend(v_t_2410, heff_strAppend(((V)&g_heff_2eemit_2elastOther_24s597_str5), heff_strAppend(v_t_2414, ((V)&g_heff_2eemit_2elastOther_24s597_str6))));
      return heff_tag(TAG_Cons, 2, (V[]){v_t_2415, NTAG(TAG_Nil)});
    }
    case TAG_False: {
      return (g_heff_2eemit_2ereturnLines_24s595(v_env_240, v_ind_242, v_e_243));
    }
    default: return heff_nomatch(v_t_246);
    }
  }
  default: return heff_nomatch(v_t_244);
  }
}
V g_heff_2eemit_2elastOther_24s597_entry(V self, V *a) {
  (void)self;
  return g_heff_2eemit_2elastOther_24s597(a[0], a[1], a[2], a[3]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemit_2eagain_24s601_str0 = {{0x80000000u, K_STR, 0}, 2, 2, {32, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2eagain_24s601_str1 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemit_2eagain_24s601_str2 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 61, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2eagain_24s601_str3 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2eagain_24s601_str4 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[10]; } g_heff_2eemit_2eagain_24s601_str5 = {{0x80000000u, K_STR, 0}, 10, 10, {32, 99, 111, 110, 116, 105, 110, 117, 101, 59}};
V g_heff_2eemit_2eagain_24s601_lam0(V self, V *args);
Clo g_heff_2eemit_2eagain_24s601_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemit_2eagain_24s601_entry, 4, 0};

V g_heff_2eemit_2eagain_24s601(V v_env_240, V v_s_241, V v_ind_242, V v_as_243) {
top: ;
  V v_x2_244 = (g_prelude_2ereplicate(heff_dup(v_ind_242), ((V)&g_heff_2eemit_2eagain_24s601_str0)));
  V v_t_247;
  switch (heff_tag_of(v_x2_244)) {
  case TAG_Nil: {
    v_t_247 = ((V)&g_heff_2eemit_2eagain_24s601_str1);
    break;
  }
  case TAG_Cons: {
    V v_x_245 = heff_field(v_x2_244, 0);
    V v_xs_246 = heff_field(v_x2_244, 1);
    heff_take_n(v_x2_244, 3ULL, 2);
    v_t_247 = ({ V a_0 = v_x_245; V a_1 = v_xs_246; V r_ = (g_prelude_2efoldl_24s46(a_0, a_1)); heff_drop(v_xs_246); r_; });
    break;
  }
  default: heff_nomatch(v_x2_244);
  }
  V v_x2_2412 = (g_prelude_2ezipWith(heff_clo(g_heff_2eemit_2eagain_24s601_lam0, 2, 2, (V[]){v_env_240, v_ind_242}), heff_get(v_s_241, LBL_params), v_as_243));
  V v_t_2415;
  switch (heff_tag_of(v_x2_2412)) {
  case TAG_Nil: {
    v_t_2415 = ((V)&g_heff_2eemit_2eagain_24s601_str4);
    break;
  }
  case TAG_Cons: {
    V v_x_2413 = heff_field(v_x2_2412, 0);
    V v_xs_2414 = heff_field(v_x2_2412, 1);
    heff_take_n(v_x2_2412, 3ULL, 2);
    v_t_2415 = ({ V a_0 = v_x_2413; V a_1 = v_xs_2414; V r_ = (g_prelude_2efoldl_24s4(a_0, a_1)); heff_drop(v_xs_2414); r_; });
    break;
  }
  default: heff_nomatch(v_x2_2412);
  }
  V v_t_2416 = heff_strAppend(v_t_247, heff_strAppend(v_t_2415, ((V)&g_heff_2eemit_2eagain_24s601_str5)));
  return heff_tag(TAG_Cons, 2, (V[]){v_t_2416, NTAG(TAG_Nil)});
}
V g_heff_2eemit_2eagain_24s601_entry(V self, V *a) {
  (void)self;
  return g_heff_2eemit_2eagain_24s601(a[0], a[1], a[2], a[3]);
}
V g_heff_2eemit_2eagain_24s601_lam0(V self, V *args) {
  V v_p_248 = args[0];
  V v_a_249 = args[1];
  V v_env_240 = heff_env(self)[0];
  V v_ind_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2410 = heff_rec(4, shape_120_200_361_295, (V[]){heff_get(heff_dup(v_env_240), LBL_gs), heff_get(heff_dup(v_env_240), LBL_names), heff_get(v_env_240, LBL_used), NTAG(TAG_Nothing)});
  V v_t_2411 = heff_tr(g_heff_2eemit_2eexprGo_24s585(v_t_2410, v_ind_242, v_a_249));
  return heff_strAppend(v_p_248, heff_strAppend(((V)&g_heff_2eemit_2eagain_24s601_str2), heff_strAppend(heff_get(v_t_2411, LBL_code), ((V)&g_heff_2eemit_2eagain_24s601_str3))));
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemit_2elastCell_24s600_str0 = {{0x80000000u, K_STR, 0}, 2, 2, {32, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2elastCell_24s600_str1 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2elastCell_24s600_str2 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2elastCell_24s600_str3 = {{0x80000000u, K_STR, 0}, 1, 1, {34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2elastCell_24s600_str4 = {{0x80000000u, K_STR, 0}, 1, 1, {34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2eemit_2elastCell_24s600_str5 = {{0x80000000u, K_STR, 0}, 9, 9, {117, 110, 100, 101, 102, 105, 110, 101, 100}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2elastCell_24s600_str6 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2eemit_2elastCell_24s600_str7 = {{0x80000000u, K_STR, 0}, 6, 6, {99, 111, 110, 115, 116, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2eemit_2elastCell_24s600_str8 = {{0x80000000u, K_STR, 0}, 8, 8, {32, 61, 32, 123, 32, 36, 58, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2eemit_2elastCell_24s600_str9 = {{0x80000000u, K_STR, 0}, 6, 6, {44, 32, 97, 58, 32, 91}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eemit_2elastCell_24s600_str10 = {{0x80000000u, K_STR, 0}, 4, 4, {93, 32, 125, 59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemit_2elastCell_24s600_str11 = {{0x80000000u, K_STR, 0}, 2, 2, {32, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2elastCell_24s600_str12 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[26]; } g_heff_2eemit_2elastCell_24s600_str13 = {{0x80000000u, K_STR, 0}, 26, 26, {105, 102, 32, 40, 36, 104, 111, 108, 101, 41, 32, 36, 104, 111, 108, 101, 46, 97, 91, 36, 97, 116, 93, 32, 61, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[15]; } g_heff_2eemit_2elastCell_24s600_str14 = {{0x80000000u, K_STR, 0}, 15, 15, {59, 32, 101, 108, 115, 101, 32, 36, 114, 111, 111, 116, 32, 61, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2elastCell_24s600_str15 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemit_2elastCell_24s600_str16 = {{0x80000000u, K_STR, 0}, 2, 2, {32, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2elastCell_24s600_str17 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2eemit_2elastCell_24s600_str18 = {{0x80000000u, K_STR, 0}, 8, 8, {36, 104, 111, 108, 101, 32, 61, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2eemit_2elastCell_24s600_str19 = {{0x80000000u, K_STR, 0}, 8, 8, {59, 32, 36, 97, 116, 32, 61, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2elastCell_24s600_str20 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
V g_heff_2eemit_2elastCell_24s600_lam0(V self, V *args);
Clo g_heff_2eemit_2elastCell_24s600_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemit_2elastCell_24s600_entry, 7, 0};

V g_heff_2eemit_2elastCell_24s600(V v_env_240, V v_s_241, V v_ind_242, V v_t_243, V v_ini_244, V v_bs_245, V v_rr_246) {
top: ;
  V v_x2_247 = (g_prelude_2ereplicate(heff_dup(v_ind_242), ((V)&g_heff_2eemit_2elastCell_24s600_str0)));
  V v_t_2410;
  switch (heff_tag_of(v_x2_247)) {
  case TAG_Nil: {
    v_t_2410 = ((V)&g_heff_2eemit_2elastCell_24s600_str1);
    break;
  }
  case TAG_Cons: {
    V v_x_248 = heff_field(v_x2_247, 0);
    V v_xs_249 = heff_field(v_x2_247, 1);
    heff_take_n(v_x2_247, 3ULL, 2);
    v_t_2410 = ({ V a_0 = v_x_248; V a_1 = v_xs_249; V r_ = (g_prelude_2efoldl_24s46(a_0, a_1)); heff_drop(v_xs_249); r_; });
    break;
  }
  default: heff_nomatch(v_x2_247);
  }
  V v_t_2411 = (g_heff_2eemit_2equoteGo(v_t_243, MK_INT(0LL), ((V)&g_heff_2eemit_2elastCell_24s600_str2)));
  V v_t_2412 = heff_strAppend(((V)&g_heff_2eemit_2elastCell_24s600_str3), heff_strAppend(v_t_2411, ((V)&g_heff_2eemit_2elastCell_24s600_str4)));
  V v_t_2416 = (g_prelude_2emap(heff_clo(g_heff_2eemit_2elastCell_24s600_lam0, 1, 2, (V[]){heff_dup(v_env_240), heff_dup(v_ind_242)}), heff_dup(v_ini_244)));
  V v_t_2417 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemit_2elastCell_24s600_str5), NTAG(TAG_Nil)});
  V v_x2_2418 = (g_prelude_2econcatList(v_t_2416, v_t_2417));
  V v_t_2421;
  switch (heff_tag_of(v_x2_2418)) {
  case TAG_Nil: {
    v_t_2421 = ((V)&g_heff_2eemit_2elastCell_24s600_str6);
    break;
  }
  case TAG_Cons: {
    V v_x_2419 = heff_field(v_x2_2418, 0);
    V v_xs_2420 = heff_field(v_x2_2418, 1);
    heff_take_n(v_x2_2418, 3ULL, 2);
    v_t_2421 = ({ V a_0 = v_x_2419; V a_1 = v_xs_2420; V r_ = (g_prelude_2efoldl_24s45(a_0, a_1)); heff_drop(v_xs_2420); r_; });
    break;
  }
  default: heff_nomatch(v_x2_2418);
  }
  V v_t_2422 = heff_strAppend(v_t_2410, heff_strAppend(((V)&g_heff_2eemit_2elastCell_24s600_str7), heff_strAppend(heff_get(heff_dup(v_rr_246), LBL_js), heff_strAppend(((V)&g_heff_2eemit_2elastCell_24s600_str8), heff_strAppend(v_t_2412, heff_strAppend(((V)&g_heff_2eemit_2elastCell_24s600_str9), heff_strAppend(v_t_2421, ((V)&g_heff_2eemit_2elastCell_24s600_str10))))))));
  V v_x2_2423 = (g_prelude_2ereplicate(heff_dup(v_ind_242), ((V)&g_heff_2eemit_2elastCell_24s600_str11)));
  V v_t_2426;
  switch (heff_tag_of(v_x2_2423)) {
  case TAG_Nil: {
    v_t_2426 = ((V)&g_heff_2eemit_2elastCell_24s600_str12);
    break;
  }
  case TAG_Cons: {
    V v_x_2424 = heff_field(v_x2_2423, 0);
    V v_xs_2425 = heff_field(v_x2_2423, 1);
    heff_take_n(v_x2_2423, 3ULL, 2);
    v_t_2426 = ({ V a_0 = v_x_2424; V a_1 = v_xs_2425; V r_ = (g_prelude_2efoldl_24s46(a_0, a_1)); heff_drop(v_xs_2425); r_; });
    break;
  }
  default: heff_nomatch(v_x2_2423);
  }
  V v_t_2427 = heff_strAppend(v_t_2426, heff_strAppend(((V)&g_heff_2eemit_2elastCell_24s600_str13), heff_strAppend(heff_get(heff_dup(v_rr_246), LBL_js), heff_strAppend(((V)&g_heff_2eemit_2elastCell_24s600_str14), heff_strAppend(heff_get(heff_dup(v_rr_246), LBL_js), ((V)&g_heff_2eemit_2elastCell_24s600_str15))))));
  V v_x2_2428 = (g_prelude_2ereplicate(heff_dup(v_ind_242), ((V)&g_heff_2eemit_2elastCell_24s600_str16)));
  V v_t_2431;
  switch (heff_tag_of(v_x2_2428)) {
  case TAG_Nil: {
    v_t_2431 = ((V)&g_heff_2eemit_2elastCell_24s600_str17);
    break;
  }
  case TAG_Cons: {
    V v_x_2429 = heff_field(v_x2_2428, 0);
    V v_xs_2430 = heff_field(v_x2_2428, 1);
    heff_take_n(v_x2_2428, 3ULL, 2);
    v_t_2431 = ({ V a_0 = v_x_2429; V a_1 = v_xs_2430; V r_ = (g_prelude_2efoldl_24s46(a_0, a_1)); heff_drop(v_xs_2430); r_; });
    break;
  }
  default: heff_nomatch(v_x2_2428);
  }
  V v_t_2432 = ({ V a_0 = MK_INT(0LL); V a_1 = v_ini_244; V r_ = (g_prelude_2efoldl_24s1(a_0, a_1)); heff_drop(v_ini_244); r_; });
  V v_t_2433 = heff_strAppend(v_t_2431, heff_strAppend(((V)&g_heff_2eemit_2elastCell_24s600_str18), heff_strAppend(heff_get(v_rr_246, LBL_js), heff_strAppend(((V)&g_heff_2eemit_2elastCell_24s600_str19), heff_strAppend(heff_intShow(v_t_2432), ((V)&g_heff_2eemit_2elastCell_24s600_str20))))));
  V v_t_2434 = heff_tag(TAG_Cons, 2, (V[]){v_t_2433, NTAG(TAG_Nil)});
  V v_t_2435 = heff_tag(TAG_Cons, 2, (V[]){v_t_2422, heff_tag(TAG_Cons, 2, (V[]){v_t_2427, v_t_2434})});
  V v_t_2436 = (g_heff_2eemit_2eagain_24s601(v_env_240, v_s_241, v_ind_242, v_bs_245));
  return (g_prelude_2econcatList(v_t_2435, v_t_2436));
}
V g_heff_2eemit_2elastCell_24s600_entry(V self, V *a) {
  (void)self;
  return g_heff_2eemit_2elastCell_24s600(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
V g_heff_2eemit_2elastCell_24s600_lam0(V self, V *args) {
  V v_a_2413 = args[0];
  V v_env_240 = heff_env(self)[0];
  V v_ind_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2414 = heff_rec(4, shape_120_200_361_295, (V[]){heff_get(heff_dup(v_env_240), LBL_gs), heff_get(heff_dup(v_env_240), LBL_names), heff_get(v_env_240, LBL_used), NTAG(TAG_Nothing)});
  V v_t_2415 = heff_tr(g_heff_2eemit_2eexprGo_24s585(v_t_2414, v_ind_242, v_a_2413));
  return heff_get(v_t_2415, LBL_code);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eemit_2elastTag_24s599_str0 = {{0x80000000u, K_STR, 0}, 4, 4, {99, 101, 108, 108}};
Clo g_heff_2eemit_2elastTag_24s599_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemit_2elastTag_24s599_entry, 6, 0};

V g_heff_2eemit_2elastTag_24s599(V v_env_240, V v_s_241, V v_ind_242, V v_t_243, V v_as_244, V v_x7_245) {
top: ;
  switch (heff_tag_of(v_x7_245)) {
  case TAG_Nothing: {
    return (g_heff_2eemit_2elastOther_24s597(v_env_240, v_s_241, v_ind_242, heff_tag(TAG_ETag, 2, (V[]){v_t_243, v_as_244})));
  }
  case TAG_Just: {
    V v_x71_246 = heff_field(v_x7_245, 0);
    switch (heff_tag_of(v_x71_246)) {
    case TAG_MkPair: {
      V v_ini_247 = heff_field(v_x71_246, 0);
      V v_x712_248 = heff_field(v_x71_246, 1);
      switch (heff_tag_of(v_x712_248)) {
      case TAG_EVar: {
        return (g_heff_2eemit_2elastOther_24s597(v_env_240, v_s_241, v_ind_242, heff_tag(TAG_ETag, 2, (V[]){v_t_243, v_as_244})));
      }
      case TAG_EGlobal: {
        return (g_heff_2eemit_2elastOther_24s597(v_env_240, v_s_241, v_ind_242, heff_tag(TAG_ETag, 2, (V[]){v_t_243, v_as_244})));
      }
      case TAG_ELam: {
        return (g_heff_2eemit_2elastOther_24s597(v_env_240, v_s_241, v_ind_242, heff_tag(TAG_ETag, 2, (V[]){v_t_243, v_as_244})));
      }
      case TAG_EApp: {
        return (g_heff_2eemit_2elastOther_24s597(v_env_240, v_s_241, v_ind_242, heff_tag(TAG_ETag, 2, (V[]){v_t_243, v_as_244})));
      }
      case TAG_ELet: {
        return (g_heff_2eemit_2elastOther_24s597(v_env_240, v_s_241, v_ind_242, heff_tag(TAG_ETag, 2, (V[]){v_t_243, v_as_244})));
      }
      case TAG_ERecord: {
        return (g_heff_2eemit_2elastOther_24s597(v_env_240, v_s_241, v_ind_242, heff_tag(TAG_ETag, 2, (V[]){v_t_243, v_as_244})));
      }
      case TAG_EProj: {
        return (g_heff_2eemit_2elastOther_24s597(v_env_240, v_s_241, v_ind_242, heff_tag(TAG_ETag, 2, (V[]){v_t_243, v_as_244})));
      }
      case TAG_ETag: {
        return (g_heff_2eemit_2elastOther_24s597(v_env_240, v_s_241, v_ind_242, heff_tag(TAG_ETag, 2, (V[]){v_t_243, v_as_244})));
      }
      case TAG_EMatch: {
        return (g_heff_2eemit_2elastOther_24s597(v_env_240, v_s_241, v_ind_242, heff_tag(TAG_ETag, 2, (V[]){v_t_243, v_as_244})));
      }
      case TAG_EPrim: {
        return (g_heff_2eemit_2elastOther_24s597(v_env_240, v_s_241, v_ind_242, heff_tag(TAG_ETag, 2, (V[]){v_t_243, v_as_244})));
      }
      case TAG_EPrimCall: {
        return (g_heff_2eemit_2elastOther_24s597(v_env_240, v_s_241, v_ind_242, heff_tag(TAG_ETag, 2, (V[]){v_t_243, v_as_244})));
      }
      case TAG_ECall: {
        V v_k_2428 = heff_field(v_x712_248, 0);
        V v_bs_2429 = heff_field(v_x712_248, 1);
        V v_t_2430 = heff_get(heff_dup(v_s_241), LBL_trmc);
        switch (heff_tag_of(v_t_2430)) {
        case TAG_True: {
          V v_t_2431 = heff_strEq(heff_dup(v_k_2428), heff_get(heff_dup(v_s_241), LBL_key));
          switch (heff_tag_of(v_t_2431)) {
          case TAG_True: {
            V v_t_2432 = (g_prelude_2efoldl_24s1(MK_INT(0LL), v_bs_2429));
            V v_t_2433 = ({ V a_0 = MK_INT(0LL); V b_1 = heff_get(heff_dup(v_s_241), LBL_params); V r_ = (g_prelude_2efoldl_24s1(a_0, b_1)); heff_drop(b_1); r_; });
            V v_t_2434 = heff_intEq(v_t_2432, v_t_2433);
            switch (heff_tag_of(v_t_2434)) {
            case TAG_True: {
              heff_drop(v_as_244);
              V v_t_2435 = (g_heff_2eemit_2ebindName(heff_dup(v_env_240), ((V)&g_heff_2eemit_2elastTag_24s599_str0)));
              return (g_heff_2eemit_2elastCell_24s600(v_env_240, v_s_241, v_ind_242, v_t_243, heff_dup(v_ini_247), heff_dup(v_bs_2429), v_t_2435));
            }
            case TAG_False: {
              return (g_heff_2eemit_2elastOther_24s597(v_env_240, v_s_241, v_ind_242, heff_tag(TAG_ETag, 2, (V[]){v_t_243, v_as_244})));
            }
            default: return heff_nomatch(v_t_2434);
            }
          }
          case TAG_False: {
            return (g_heff_2eemit_2elastOther_24s597(v_env_240, v_s_241, v_ind_242, heff_tag(TAG_ETag, 2, (V[]){v_t_243, v_as_244})));
          }
          default: return heff_nomatch(v_t_2431);
          }
        }
        case TAG_False: {
          return (g_heff_2eemit_2elastOther_24s597(v_env_240, v_s_241, v_ind_242, heff_tag(TAG_ETag, 2, (V[]){v_t_243, v_as_244})));
        }
        default: return heff_nomatch(v_t_2430);
        }
      }
      case TAG_EInt: {
        return (g_heff_2eemit_2elastOther_24s597(v_env_240, v_s_241, v_ind_242, heff_tag(TAG_ETag, 2, (V[]){v_t_243, v_as_244})));
      }
      case TAG_EFloat: {
        return (g_heff_2eemit_2elastOther_24s597(v_env_240, v_s_241, v_ind_242, heff_tag(TAG_ETag, 2, (V[]){v_t_243, v_as_244})));
      }
      case TAG_EStr: {
        return (g_heff_2eemit_2elastOther_24s597(v_env_240, v_s_241, v_ind_242, heff_tag(TAG_ETag, 2, (V[]){v_t_243, v_as_244})));
      }
      case TAG_EAbandon: {
        return (g_heff_2eemit_2elastOther_24s597(v_env_240, v_s_241, v_ind_242, heff_tag(TAG_ETag, 2, (V[]){v_t_243, v_as_244})));
      }
      case TAG_EFix: {
        return (g_heff_2eemit_2elastOther_24s597(v_env_240, v_s_241, v_ind_242, heff_tag(TAG_ETag, 2, (V[]){v_t_243, v_as_244})));
      }
      default: return heff_nomatch(v_x712_248);
      }
    }
    default: return heff_nomatch(v_x71_246);
    }
  }
  default: return heff_nomatch(v_x7_245);
  }
}
V g_heff_2eemit_2elastTag_24s599_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eemit_2elastTag_24s599(a[0], a[1], a[2], a[3], a[4], a[5]); heff_drop(a[5]); return r;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2eemit_2elastSelf_24s596_str0 = {{0x80000000u, K_STR, 0}, 9, 9, {115, 116, 114, 65, 112, 112, 101, 110, 100}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemit_2elastSelf_24s596_str1 = {{0x80000000u, K_STR, 0}, 2, 2, {32, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2elastSelf_24s596_str2 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2eemit_2elastSelf_24s596_str3 = {{0x80000000u, K_STR, 0}, 6, 6, {36, 115, 32, 43, 61, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2elastSelf_24s596_str4 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
Clo g_heff_2eemit_2elastSelf_24s596_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemit_2elastSelf_24s596_entry, 4, 0};

V g_heff_2eemit_2elastSelf_24s596(V v_env_240, V v_s_241, V v_ind_242, V v_e_243) {
top: ;
  switch (heff_tag_of(v_e_243)) {
  case TAG_EVar: {
    HEFF_LAST return g_heff_2eemit_2elastOther_24s597(v_env_240, v_s_241, v_ind_242, v_e_243);
  }
  case TAG_EGlobal: {
    HEFF_LAST return g_heff_2eemit_2elastOther_24s597(v_env_240, v_s_241, v_ind_242, v_e_243);
  }
  case TAG_ELam: {
    HEFF_LAST return g_heff_2eemit_2elastOther_24s597(v_env_240, v_s_241, v_ind_242, v_e_243);
  }
  case TAG_EApp: {
    HEFF_LAST return g_heff_2eemit_2elastOther_24s597(v_env_240, v_s_241, v_ind_242, v_e_243);
  }
  case TAG_ELet: {
    HEFF_LAST return g_heff_2eemit_2elastOther_24s597(v_env_240, v_s_241, v_ind_242, v_e_243);
  }
  case TAG_ERecord: {
    HEFF_LAST return g_heff_2eemit_2elastOther_24s597(v_env_240, v_s_241, v_ind_242, v_e_243);
  }
  case TAG_EProj: {
    HEFF_LAST return g_heff_2eemit_2elastOther_24s597(v_env_240, v_s_241, v_ind_242, v_e_243);
  }
  case TAG_ETag: {
    V v_t_2416 = heff_field(v_e_243, 0);
    V v_as_2417 = heff_field(v_e_243, 1);
    heff_take_n(v_e_243, 3ULL, 2);
    V v_t_2420;
    switch (heff_tag_of(v_as_2417)) {
    case TAG_Nil: {
      v_t_2420 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Cons: {
      V v_x_2418 = heff_dup(heff_field(v_as_2417, 0));
      V v_rest_2419 = heff_dup(heff_field(v_as_2417, 1));
      v_t_2420 = heff_tag(TAG_Just, 1, (V[]){(g_heff_2eemit_2eunsnocGo(v_rest_2419, v_x_2418))});
      break;
    }
    default: heff_nomatch(v_as_2417);
    }
    return ({ V a_0 = v_env_240; V a_1 = v_s_241; V a_2 = v_ind_242; V a_3 = v_t_2416; V a_4 = v_as_2417; V a_5 = v_t_2420; V r_ = (g_heff_2eemit_2elastTag_24s599(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_t_2420); r_; });
  }
  case TAG_EMatch: {
    HEFF_LAST return g_heff_2eemit_2elastOther_24s597(v_env_240, v_s_241, v_ind_242, v_e_243);
  }
  case TAG_EPrim: {
    HEFF_LAST return g_heff_2eemit_2elastOther_24s597(v_env_240, v_s_241, v_ind_242, v_e_243);
  }
  case TAG_EPrimCall: {
    V v_p_2424 = heff_field(v_e_243, 0);
    V v_args_2425 = heff_field(v_e_243, 1);
    V v_ru_24e_243_24EPrimCall = heff_take_reuse_n(v_e_243, 3ULL, 2);
    switch (heff_tag_of(v_args_2425)) {
    case TAG_Nil: {
      HEFF_LAST return g_heff_2eemit_2elastOther_24s597(v_env_240, v_s_241, v_ind_242, heff_tag_at(v_ru_24e_243_24EPrimCall, TAG_EPrimCall, 2, (V[]){v_p_2424, v_args_2425}));
    }
    case TAG_Cons: {
      V v_a_2426 = heff_dup(heff_field(v_args_2425, 0));
      V v_it2_2427 = heff_dup(heff_field(v_args_2425, 1));
      switch (heff_tag_of(v_it2_2427)) {
      case TAG_Nil: {
        heff_drop(v_a_2426);
        HEFF_LAST return g_heff_2eemit_2elastOther_24s597(v_env_240, v_s_241, v_ind_242, heff_tag_at(v_ru_24e_243_24EPrimCall, TAG_EPrimCall, 2, (V[]){v_p_2424, v_args_2425}));
      }
      case TAG_Cons: {
        V v_rr_2428 = heff_field(v_it2_2427, 0);
        V v_it22_2429 = heff_field(v_it2_2427, 1);
        heff_take_n(v_it2_2427, 3ULL, 2);
        switch (heff_tag_of(v_it22_2429)) {
        case TAG_Nil: {
          V v_t_2430 = heff_strEq(heff_dup(v_p_2424), ((V)&g_heff_2eemit_2elastSelf_24s596_str0));
          V v_t_2433;
          switch (heff_tag_of(v_t_2430)) {
          case TAG_True: {
            V v_t_2431 = heff_get(heff_dup(v_s_241), LBL_sapp);
            switch (heff_tag_of(v_t_2431)) {
            case TAG_True: {
              V v_t_2432 = ({ V a_0 = MK_INT(0LL); V b_1 = heff_get(heff_dup(v_s_241), LBL_params); V r_ = (g_prelude_2efoldl_24s1(a_0, b_1)); heff_drop(b_1); r_; });
              v_t_2433 = (g_heff_2eemit_2eappendEnd(heff_get(heff_dup(v_s_241), LBL_key), v_t_2432, v_rr_2428));
              break;
            }
            case TAG_False: {
              v_t_2433 = NTAG(TAG_False);
              break;
            }
            default: heff_nomatch(v_t_2431);
            }
            break;
          }
          case TAG_False: {
            v_t_2433 = NTAG(TAG_False);
            break;
          }
          default: heff_nomatch(v_t_2430);
          }
          switch (heff_tag_of(v_t_2433)) {
          case TAG_True: {
            heff_drop(v_s_241);
            heff_drop(v_p_2424);
            heff_drop_tag(v_args_2425, 2);
            V v_x2_2434 = (g_prelude_2ereplicate(heff_dup(v_ind_242), ((V)&g_heff_2eemit_2elastSelf_24s596_str1)));
            V v_t_2437;
            switch (heff_tag_of(v_x2_2434)) {
            case TAG_Nil: {
              v_t_2437 = ((V)&g_heff_2eemit_2elastSelf_24s596_str2);
              break;
            }
            case TAG_Cons: {
              V v_x_2435 = heff_field(v_x2_2434, 0);
              V v_xs_2436 = heff_field(v_x2_2434, 1);
              heff_take_n(v_x2_2434, 3ULL, 2);
              v_t_2437 = ({ V a_0 = v_x_2435; V a_1 = v_xs_2436; V r_ = (g_prelude_2efoldl_24s46(a_0, a_1)); heff_drop(v_xs_2436); r_; });
              break;
            }
            default: heff_nomatch(v_x2_2434);
            }
            V v_t_2438 = heff_rec(4, shape_120_200_361_295, (V[]){heff_get(heff_dup(v_env_240), LBL_gs), heff_get(heff_dup(v_env_240), LBL_names), heff_get(heff_dup(v_env_240), LBL_used), NTAG(TAG_Nothing)});
            V v_t_2439 = heff_tr(g_heff_2eemit_2eexprGo_24s585(v_t_2438, heff_dup(v_ind_242), v_a_2426));
            V v_t_2440 = heff_strAppend(v_t_2437, heff_strAppend(((V)&g_heff_2eemit_2elastSelf_24s596_str3), heff_strAppend(heff_get(v_t_2439, LBL_code), ((V)&g_heff_2eemit_2elastSelf_24s596_str4))));
            V v_t_2441 = heff_get(heff_dup(v_env_240), LBL_self);
            V v_t_2443;
            switch (heff_tag_of(v_t_2441)) {
            case TAG_Nothing: {
              v_t_2443 = (g_heff_2eemit_2ereturnLines_24s595(v_env_240, v_ind_242, v_rr_2428));
              break;
            }
            case TAG_Just: {
              V v_s_2442 = heff_field(v_t_2441, 0);
              heff_take_n(v_t_2441, 1ULL, 1);
              v_t_2443 = (g_heff_2eemit_2elastSelf_24s596(v_env_240, v_s_2442, v_ind_242, v_rr_2428));
              break;
            }
            default: heff_nomatch(v_t_2441);
            }
            return heff_tag_at(v_ru_24e_243_24EPrimCall, TAG_Cons, 2, (V[]){v_t_2440, v_t_2443});
          }
          case TAG_False: {
            heff_drop(v_a_2426);
            heff_drop(v_rr_2428);
            HEFF_LAST return g_heff_2eemit_2elastOther_24s597(v_env_240, v_s_241, v_ind_242, heff_tag_at(v_ru_24e_243_24EPrimCall, TAG_EPrimCall, 2, (V[]){v_p_2424, v_args_2425}));
          }
          default: return heff_nomatch(v_t_2433);
          }
        }
        case TAG_Cons: {
          heff_take_n(v_it22_2429, 0ULL, 2);
          heff_drop(v_a_2426);
          heff_drop(v_rr_2428);
          HEFF_LAST return g_heff_2eemit_2elastOther_24s597(v_env_240, v_s_241, v_ind_242, heff_tag_at(v_ru_24e_243_24EPrimCall, TAG_EPrimCall, 2, (V[]){v_p_2424, v_args_2425}));
        }
        default: return heff_nomatch(v_it22_2429);
        }
      }
      default: return heff_nomatch(v_it2_2427);
      }
    }
    default: return heff_nomatch(v_args_2425);
    }
  }
  case TAG_ECall: {
    V v_k_2446 = heff_field(v_e_243, 0);
    V v_as_2447 = heff_field(v_e_243, 1);
    V v_ru_24e_243_24ECall = heff_take_reuse_n(v_e_243, 3ULL, 2);
    V v_t_2448 = heff_strEq(heff_dup(v_k_2446), heff_get(heff_dup(v_s_241), LBL_key));
    switch (heff_tag_of(v_t_2448)) {
    case TAG_True: {
      V v_t_2449 = (g_prelude_2efoldl_24s1(MK_INT(0LL), v_as_2447));
      V v_t_2450 = ({ V a_0 = MK_INT(0LL); V b_1 = heff_get(heff_dup(v_s_241), LBL_params); V r_ = (g_prelude_2efoldl_24s1(a_0, b_1)); heff_drop(b_1); r_; });
      V v_t_2451 = heff_intEq(v_t_2449, v_t_2450);
      switch (heff_tag_of(v_t_2451)) {
      case TAG_True: {
        heff_drop(v_k_2446);
        heff_drop_cell(v_ru_24e_243_24ECall, 2);
        HEFF_LAST return g_heff_2eemit_2eagain_24s601(v_env_240, v_s_241, v_ind_242, v_as_2447);
      }
      case TAG_False: {
        HEFF_LAST return g_heff_2eemit_2elastOther_24s597(v_env_240, v_s_241, v_ind_242, heff_tag_at(v_ru_24e_243_24ECall, TAG_ECall, 2, (V[]){v_k_2446, v_as_2447}));
      }
      default: return heff_nomatch(v_t_2451);
      }
    }
    case TAG_False: {
      HEFF_LAST return g_heff_2eemit_2elastOther_24s597(v_env_240, v_s_241, v_ind_242, heff_tag_at(v_ru_24e_243_24ECall, TAG_ECall, 2, (V[]){v_k_2446, v_as_2447}));
    }
    default: return heff_nomatch(v_t_2448);
    }
  }
  case TAG_EInt: {
    HEFF_LAST return g_heff_2eemit_2elastOther_24s597(v_env_240, v_s_241, v_ind_242, v_e_243);
  }
  case TAG_EFloat: {
    HEFF_LAST return g_heff_2eemit_2elastOther_24s597(v_env_240, v_s_241, v_ind_242, v_e_243);
  }
  case TAG_EStr: {
    HEFF_LAST return g_heff_2eemit_2elastOther_24s597(v_env_240, v_s_241, v_ind_242, v_e_243);
  }
  case TAG_EAbandon: {
    HEFF_LAST return g_heff_2eemit_2elastOther_24s597(v_env_240, v_s_241, v_ind_242, v_e_243);
  }
  case TAG_EFix: {
    HEFF_LAST return g_heff_2eemit_2elastOther_24s597(v_env_240, v_s_241, v_ind_242, v_e_243);
  }
  default: return heff_nomatch(v_e_243);
  }
}
V g_heff_2eemit_2elastSelf_24s596_entry(V self, V *a) {
  (void)self;
  return g_heff_2eemit_2elastSelf_24s596(a[0], a[1], a[2], a[3]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eemit_2estmtsF_24s581_str0 = {{0x80000000u, K_STR, 0}, 4, 4, {84, 114, 117, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eemit_2estmtsF_24s581_str1 = {{0x80000000u, K_STR, 0}, 5, 5, {70, 97, 108, 115, 101}};
Clo g_heff_2eemit_2estmtsF_24s581_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemit_2estmtsF_24s581_entry, 3, 0};

V g_heff_2eemit_2estmtsF_24s581(V v_env_240, V v_ind_241, V v_e_242) {
top: ;
  switch (heff_tag_of(v_e_242)) {
  case TAG_EVar: {
    V v_t_244 = heff_get(heff_dup(v_env_240), LBL_self);
    switch (heff_tag_of(v_t_244)) {
    case TAG_Nothing: {
      HEFF_LAST return g_heff_2eemit_2ereturnLines_24s595(v_env_240, v_ind_241, v_e_242);
    }
    case TAG_Just: {
      V v_s_245 = heff_field(v_t_244, 0);
      heff_take_n(v_t_244, 1ULL, 1);
      return (g_heff_2eemit_2elastSelf_24s596(v_env_240, v_s_245, v_ind_241, v_e_242));
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  case TAG_EGlobal: {
    V v_t_247 = heff_get(heff_dup(v_env_240), LBL_self);
    switch (heff_tag_of(v_t_247)) {
    case TAG_Nothing: {
      HEFF_LAST return g_heff_2eemit_2ereturnLines_24s595(v_env_240, v_ind_241, v_e_242);
    }
    case TAG_Just: {
      V v_s_248 = heff_field(v_t_247, 0);
      heff_take_n(v_t_247, 1ULL, 1);
      return (g_heff_2eemit_2elastSelf_24s596(v_env_240, v_s_248, v_ind_241, v_e_242));
    }
    default: return heff_nomatch(v_t_247);
    }
  }
  case TAG_ELam: {
    V v_t_2411 = heff_get(heff_dup(v_env_240), LBL_self);
    switch (heff_tag_of(v_t_2411)) {
    case TAG_Nothing: {
      HEFF_LAST return g_heff_2eemit_2ereturnLines_24s595(v_env_240, v_ind_241, v_e_242);
    }
    case TAG_Just: {
      V v_s_2412 = heff_field(v_t_2411, 0);
      heff_take_n(v_t_2411, 1ULL, 1);
      return (g_heff_2eemit_2elastSelf_24s596(v_env_240, v_s_2412, v_ind_241, v_e_242));
    }
    default: return heff_nomatch(v_t_2411);
    }
  }
  case TAG_EApp: {
    V v_t_2415 = heff_get(heff_dup(v_env_240), LBL_self);
    switch (heff_tag_of(v_t_2415)) {
    case TAG_Nothing: {
      HEFF_LAST return g_heff_2eemit_2ereturnLines_24s595(v_env_240, v_ind_241, v_e_242);
    }
    case TAG_Just: {
      V v_s_2416 = heff_field(v_t_2415, 0);
      heff_take_n(v_t_2415, 1ULL, 1);
      return (g_heff_2eemit_2elastSelf_24s596(v_env_240, v_s_2416, v_ind_241, v_e_242));
    }
    default: return heff_nomatch(v_t_2415);
    }
  }
  case TAG_ELet: {
    V v_x_2417 = heff_field(v_e_242, 0);
    V v_a_2418 = heff_field(v_e_242, 1);
    V v_b_2419 = heff_field(v_e_242, 2);
    heff_take_n(v_e_242, 7ULL, 3);
    V v_t_2420 = heff_rec(4, shape_120_200_361_295, (V[]){heff_get(heff_dup(v_env_240), LBL_gs), heff_get(heff_dup(v_env_240), LBL_names), heff_get(heff_dup(v_env_240), LBL_used), NTAG(TAG_Nothing)});
    V v_t_2421 = heff_tr(g_heff_2eemit_2eexprGo_24s585(v_t_2420, heff_dup(v_ind_241), v_a_2418));
    V v_t_2422 = (g_heff_2eemit_2ebindName(v_env_240, v_x_2417));
    return (g_heff_2eemit_2estmtsLet2_24s582(v_ind_241, v_b_2419, v_t_2421, v_t_2422));
  }
  case TAG_ERecord: {
    V v_t_2424 = heff_get(heff_dup(v_env_240), LBL_self);
    switch (heff_tag_of(v_t_2424)) {
    case TAG_Nothing: {
      HEFF_LAST return g_heff_2eemit_2ereturnLines_24s595(v_env_240, v_ind_241, v_e_242);
    }
    case TAG_Just: {
      V v_s_2425 = heff_field(v_t_2424, 0);
      heff_take_n(v_t_2424, 1ULL, 1);
      return (g_heff_2eemit_2elastSelf_24s596(v_env_240, v_s_2425, v_ind_241, v_e_242));
    }
    default: return heff_nomatch(v_t_2424);
    }
  }
  case TAG_EProj: {
    V v_t_2428 = heff_get(heff_dup(v_env_240), LBL_self);
    switch (heff_tag_of(v_t_2428)) {
    case TAG_Nothing: {
      HEFF_LAST return g_heff_2eemit_2ereturnLines_24s595(v_env_240, v_ind_241, v_e_242);
    }
    case TAG_Just: {
      V v_s_2429 = heff_field(v_t_2428, 0);
      heff_take_n(v_t_2428, 1ULL, 1);
      return (g_heff_2eemit_2elastSelf_24s596(v_env_240, v_s_2429, v_ind_241, v_e_242));
    }
    default: return heff_nomatch(v_t_2428);
    }
  }
  case TAG_ETag: {
    V v_t_2432 = heff_get(heff_dup(v_env_240), LBL_self);
    switch (heff_tag_of(v_t_2432)) {
    case TAG_Nothing: {
      HEFF_LAST return g_heff_2eemit_2ereturnLines_24s595(v_env_240, v_ind_241, v_e_242);
    }
    case TAG_Just: {
      V v_s_2433 = heff_field(v_t_2432, 0);
      heff_take_n(v_t_2432, 1ULL, 1);
      return (g_heff_2eemit_2elastSelf_24s596(v_env_240, v_s_2433, v_ind_241, v_e_242));
    }
    default: return heff_nomatch(v_t_2432);
    }
  }
  case TAG_EMatch: {
    V v_s_2434 = heff_dup(heff_field(v_e_242, 0));
    V v_arms_2435 = heff_dup(heff_field(v_e_242, 1));
    V v_t_2436 = (g_prelude_2efoldl_24s1(MK_INT(0LL), v_arms_2435));
    V v_t_2437 = heff_intEq(v_t_2436, MK_INT(2LL));
    V v_it_2442;
    switch (heff_tag_of(v_t_2437)) {
    case TAG_True: {
      V v_t_2438 = (g_heff_2eemit_2earmNamed(((V)&g_heff_2eemit_2estmtsF_24s581_str0), v_arms_2435));
      switch (heff_tag_of(v_t_2438)) {
      case TAG_Nothing: {
        v_it_2442 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_Just: {
        V v_t_2439 = heff_field(v_t_2438, 0);
        V v_ru_24t_2438_24Just = heff_take_reuse_n(v_t_2438, 1ULL, 1);
        V v_t_2440 = (g_heff_2eemit_2earmNamed(((V)&g_heff_2eemit_2estmtsF_24s581_str1), v_arms_2435));
        switch (heff_tag_of(v_t_2440)) {
        case TAG_Nothing: {
          heff_drop(v_t_2439);
          heff_drop_cell(v_ru_24t_2438_24Just, 1);
          v_it_2442 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_Just: {
          V v_f_2441 = heff_field(v_t_2440, 0);
          heff_take_n(v_t_2440, 1ULL, 1);
          v_it_2442 = heff_tag_at(v_ru_24t_2438_24Just, TAG_Just, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_t_2439, v_f_2441})});
          break;
        }
        default: heff_nomatch(v_t_2440);
        }
        break;
      }
      default: heff_nomatch(v_t_2438);
      }
      break;
    }
    case TAG_False: {
      v_it_2442 = NTAG(TAG_Nothing);
      break;
    }
    default: heff_nomatch(v_t_2437);
    }
    switch (heff_tag_of(v_it_2442)) {
    case TAG_Nothing: {
      heff_drop_tag(v_e_242, 2);
      V v_t_2443 = (g_heff_2eemit_2escrutOf_24s583(v_env_240, heff_dup(v_ind_241), v_s_2434));
      HEFF_LAST return g_heff_2eemit_2estmtsMatch2_24s591(v_ind_241, v_arms_2435, v_t_2443);
    }
    case TAG_Just: {
      V v_it1_2444 = heff_field(v_it_2442, 0);
      heff_take_n(v_it_2442, 1ULL, 1);
      heff_drop(v_arms_2435);
      switch (heff_tag_of(v_it1_2444)) {
      case TAG_MkPair: {
        V v_t_2445 = heff_field(v_it1_2444, 0);
        V v_f_2446 = heff_field(v_it1_2444, 1);
        heff_take_n(v_it1_2444, 3ULL, 2);
        V v_t_2447 = heff_get(heff_dup(v_env_240), LBL_self);
        switch (heff_tag_of(v_t_2447)) {
        case TAG_Nothing: {
          V v_t_2448 = (g_heff_2eemit_2econdShaped(heff_dup(v_t_2445)));
          switch (heff_tag_of(v_t_2448)) {
          case TAG_True: {
            V v_t_2449 = (g_heff_2eemit_2econdShaped(heff_dup(v_f_2446)));
            switch (heff_tag_of(v_t_2449)) {
            case TAG_True: {
              heff_drop(v_s_2434);
              heff_drop(v_t_2445);
              heff_drop(v_f_2446);
              V v_t_2450 = (g_heff_2eemit_2epredOf_24s587(v_env_240, heff_dup(v_ind_241), v_e_242));
              return (g_heff_2eemit_2estmtsReturnCond(v_ind_241, v_t_2450));
            }
            case TAG_False: {
              heff_drop_tag(v_e_242, 2);
              V v_t_2451 = (g_heff_2eemit_2epredOf_24s587(heff_dup(v_env_240), heff_dup(v_ind_241), v_s_2434));
              return (g_heff_2eemit_2estmtsIf_24s594(v_env_240, v_ind_241, v_t_2451, v_t_2445, v_f_2446));
            }
            default: return heff_nomatch(v_t_2449);
            }
          }
          case TAG_False: {
            heff_drop_tag(v_e_242, 2);
            V v_t_2452 = (g_heff_2eemit_2epredOf_24s587(heff_dup(v_env_240), heff_dup(v_ind_241), v_s_2434));
            return (g_heff_2eemit_2estmtsIf_24s594(v_env_240, v_ind_241, v_t_2452, v_t_2445, v_f_2446));
          }
          default: return heff_nomatch(v_t_2448);
          }
        }
        case TAG_Just: {
          heff_take_n(v_t_2447, 0ULL, 1);
          heff_drop_tag(v_e_242, 2);
          V v_t_2454 = (g_heff_2eemit_2epredOf_24s587(heff_dup(v_env_240), heff_dup(v_ind_241), v_s_2434));
          return (g_heff_2eemit_2estmtsIf_24s594(v_env_240, v_ind_241, v_t_2454, v_t_2445, v_f_2446));
        }
        default: return heff_nomatch(v_t_2447);
        }
      }
      default: return heff_nomatch(v_it1_2444);
      }
    }
    default: return heff_nomatch(v_it_2442);
    }
  }
  case TAG_EPrim: {
    V v_t_2456 = heff_get(heff_dup(v_env_240), LBL_self);
    switch (heff_tag_of(v_t_2456)) {
    case TAG_Nothing: {
      HEFF_LAST return g_heff_2eemit_2ereturnLines_24s595(v_env_240, v_ind_241, v_e_242);
    }
    case TAG_Just: {
      V v_s_2457 = heff_field(v_t_2456, 0);
      heff_take_n(v_t_2456, 1ULL, 1);
      return (g_heff_2eemit_2elastSelf_24s596(v_env_240, v_s_2457, v_ind_241, v_e_242));
    }
    default: return heff_nomatch(v_t_2456);
    }
  }
  case TAG_EPrimCall: {
    V v_t_2460 = heff_get(heff_dup(v_env_240), LBL_self);
    switch (heff_tag_of(v_t_2460)) {
    case TAG_Nothing: {
      HEFF_LAST return g_heff_2eemit_2ereturnLines_24s595(v_env_240, v_ind_241, v_e_242);
    }
    case TAG_Just: {
      V v_s_2461 = heff_field(v_t_2460, 0);
      heff_take_n(v_t_2460, 1ULL, 1);
      return (g_heff_2eemit_2elastSelf_24s596(v_env_240, v_s_2461, v_ind_241, v_e_242));
    }
    default: return heff_nomatch(v_t_2460);
    }
  }
  case TAG_ECall: {
    V v_t_2464 = heff_get(heff_dup(v_env_240), LBL_self);
    switch (heff_tag_of(v_t_2464)) {
    case TAG_Nothing: {
      HEFF_LAST return g_heff_2eemit_2ereturnLines_24s595(v_env_240, v_ind_241, v_e_242);
    }
    case TAG_Just: {
      V v_s_2465 = heff_field(v_t_2464, 0);
      heff_take_n(v_t_2464, 1ULL, 1);
      return (g_heff_2eemit_2elastSelf_24s596(v_env_240, v_s_2465, v_ind_241, v_e_242));
    }
    default: return heff_nomatch(v_t_2464);
    }
  }
  case TAG_EInt: {
    V v_t_2467 = heff_get(heff_dup(v_env_240), LBL_self);
    switch (heff_tag_of(v_t_2467)) {
    case TAG_Nothing: {
      HEFF_LAST return g_heff_2eemit_2ereturnLines_24s595(v_env_240, v_ind_241, v_e_242);
    }
    case TAG_Just: {
      V v_s_2468 = heff_field(v_t_2467, 0);
      heff_take_n(v_t_2467, 1ULL, 1);
      return (g_heff_2eemit_2elastSelf_24s596(v_env_240, v_s_2468, v_ind_241, v_e_242));
    }
    default: return heff_nomatch(v_t_2467);
    }
  }
  case TAG_EFloat: {
    V v_t_2470 = heff_get(heff_dup(v_env_240), LBL_self);
    switch (heff_tag_of(v_t_2470)) {
    case TAG_Nothing: {
      HEFF_LAST return g_heff_2eemit_2ereturnLines_24s595(v_env_240, v_ind_241, v_e_242);
    }
    case TAG_Just: {
      V v_s_2471 = heff_field(v_t_2470, 0);
      heff_take_n(v_t_2470, 1ULL, 1);
      return (g_heff_2eemit_2elastSelf_24s596(v_env_240, v_s_2471, v_ind_241, v_e_242));
    }
    default: return heff_nomatch(v_t_2470);
    }
  }
  case TAG_EStr: {
    V v_t_2473 = heff_get(heff_dup(v_env_240), LBL_self);
    switch (heff_tag_of(v_t_2473)) {
    case TAG_Nothing: {
      HEFF_LAST return g_heff_2eemit_2ereturnLines_24s595(v_env_240, v_ind_241, v_e_242);
    }
    case TAG_Just: {
      V v_s_2474 = heff_field(v_t_2473, 0);
      heff_take_n(v_t_2473, 1ULL, 1);
      return (g_heff_2eemit_2elastSelf_24s596(v_env_240, v_s_2474, v_ind_241, v_e_242));
    }
    default: return heff_nomatch(v_t_2473);
    }
  }
  case TAG_EAbandon: {
    V v_t_2475 = heff_get(heff_dup(v_env_240), LBL_self);
    switch (heff_tag_of(v_t_2475)) {
    case TAG_Nothing: {
      HEFF_LAST return g_heff_2eemit_2ereturnLines_24s595(v_env_240, v_ind_241, v_e_242);
    }
    case TAG_Just: {
      V v_s_2476 = heff_field(v_t_2475, 0);
      heff_take_n(v_t_2475, 1ULL, 1);
      return (g_heff_2eemit_2elastSelf_24s596(v_env_240, v_s_2476, v_ind_241, v_e_242));
    }
    default: return heff_nomatch(v_t_2475);
    }
  }
  case TAG_EFix: {
    V v_t_2479 = heff_get(heff_dup(v_env_240), LBL_self);
    switch (heff_tag_of(v_t_2479)) {
    case TAG_Nothing: {
      HEFF_LAST return g_heff_2eemit_2ereturnLines_24s595(v_env_240, v_ind_241, v_e_242);
    }
    case TAG_Just: {
      V v_s_2480 = heff_field(v_t_2479, 0);
      heff_take_n(v_t_2479, 1ULL, 1);
      return (g_heff_2eemit_2elastSelf_24s596(v_env_240, v_s_2480, v_ind_241, v_e_242));
    }
    default: return heff_nomatch(v_t_2479);
    }
  }
  default: return heff_nomatch(v_e_242);
  }
}
V g_heff_2eemit_2estmtsF_24s581_entry(V self, V *a) {
  (void)self;
  return g_heff_2eemit_2estmtsF_24s581(a[0], a[1], a[2]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2elooped_str0 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2eemit_2elooped_str1 = {{0x80000000u, K_STR, 0}, 6, 6, {99, 111, 110, 115, 116, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eemit_2elooped_str2 = {{0x80000000u, K_STR, 0}, 4, 4, {32, 61, 32, 40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2eemit_2elooped_str3 = {{0x80000000u, K_STR, 0}, 6, 6, {41, 32, 61, 62, 32, 123}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[35]; } g_heff_2eemit_2elooped_str4 = {{0x80000000u, K_STR, 0}, 35, 35, {32, 32, 108, 101, 116, 32, 36, 114, 111, 111, 116, 44, 32, 36, 104, 111, 108, 101, 32, 61, 32, 110, 117, 108, 108, 44, 32, 36, 97, 116, 32, 61, 32, 48, 59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[14]; } g_heff_2eemit_2elooped_str5 = {{0x80000000u, K_STR, 0}, 14, 14, {32, 32, 108, 101, 116, 32, 36, 115, 32, 61, 32, 34, 34, 59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2elooped_str6 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[10]; } g_heff_2eemit_2elooped_str7 = {{0x80000000u, K_STR, 0}, 10, 10, {32, 32, 32, 32, 99, 111, 110, 115, 116, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2elooped_str8 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemit_2elooped_str9 = {{0x80000000u, K_STR, 0}, 2, 2, {125, 59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemit_2elooped_str10 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 32, 125}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[12]; } g_heff_2eemit_2elooped_str11 = {{0x80000000u, K_STR, 0}, 12, 12, {32, 32, 102, 111, 114, 32, 40, 59, 59, 41, 32, 123}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2elooped_str12 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
Clo g_heff_2eemit_2elooped_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemit_2elooped_entry, 6, 0};

V g_heff_2eemit_2elooped(V v_key_240, V v_i_241, V v_b_242, V v_r_243, V v_trmc_244, V v_sapp_245) {
top: ;
  V v_x2_246 = (g_prelude_2emap_24s579(heff_get(heff_dup(v_r_243), LBL_js)));
  V v_t_249;
  switch (heff_tag_of(v_x2_246)) {
  case TAG_Nil: {
    v_t_249 = ((V)&g_heff_2eemit_2elooped_str0);
    break;
  }
  case TAG_Cons: {
    V v_x_247 = heff_field(v_x2_246, 0);
    V v_xs_248 = heff_field(v_x2_246, 1);
    heff_take_n(v_x2_246, 3ULL, 2);
    v_t_249 = ({ V a_0 = v_x_247; V a_1 = v_xs_248; V r_ = (g_prelude_2efoldl_24s45(a_0, a_1)); heff_drop(v_xs_248); r_; });
    break;
  }
  default: heff_nomatch(v_x2_246);
  }
  V v_t_2410 = heff_strAppend(((V)&g_heff_2eemit_2elooped_str1), heff_strAppend(heff_get(v_i_241, LBL_js), heff_strAppend(((V)&g_heff_2eemit_2elooped_str2), heff_strAppend(v_t_249, ((V)&g_heff_2eemit_2elooped_str3)))));
  V v_t_2411 = heff_tag(TAG_Cons, 2, (V[]){v_t_2410, NTAG(TAG_Nil)});
  V v_t_2412;
  switch (heff_tag_of(v_trmc_244)) {
  case TAG_True: {
    v_t_2412 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemit_2elooped_str4), NTAG(TAG_Nil)});
    break;
  }
  case TAG_False: {
    v_t_2412 = NTAG(TAG_Nil);
    break;
  }
  default: heff_nomatch(v_trmc_244);
  }
  V v_t_2413;
  switch (heff_tag_of(v_sapp_245)) {
  case TAG_True: {
    v_t_2413 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemit_2elooped_str5), NTAG(TAG_Nil)});
    break;
  }
  case TAG_False: {
    v_t_2413 = NTAG(TAG_Nil);
    break;
  }
  default: heff_nomatch(v_sapp_245);
  }
  V v_t_2414 = (g_prelude_2emap_24s579(heff_get(heff_dup(v_r_243), LBL_js)));
  V v_x2_2415 = (g_prelude_2ezipWith_24s580(heff_get(heff_dup(v_r_243), LBL_js), v_t_2414));
  V v_t_2418;
  switch (heff_tag_of(v_x2_2415)) {
  case TAG_Nil: {
    v_t_2418 = ((V)&g_heff_2eemit_2elooped_str6);
    break;
  }
  case TAG_Cons: {
    V v_x_2416 = heff_field(v_x2_2415, 0);
    V v_xs_2417 = heff_field(v_x2_2415, 1);
    heff_take_n(v_x2_2415, 3ULL, 2);
    v_t_2418 = ({ V a_0 = v_x_2416; V a_1 = v_xs_2417; V r_ = (g_prelude_2efoldl_24s45(a_0, a_1)); heff_drop(v_xs_2417); r_; });
    break;
  }
  default: heff_nomatch(v_x2_2415);
  }
  V v_t_2419 = heff_strAppend(((V)&g_heff_2eemit_2elooped_str7), heff_strAppend(v_t_2418, ((V)&g_heff_2eemit_2elooped_str8)));
  V v_t_2420 = heff_tag(TAG_Cons, 2, (V[]){v_t_2419, NTAG(TAG_Nil)});
  V v_t_2421 = (g_prelude_2emap_24s579(heff_get(heff_dup(v_r_243), LBL_js)));
  V v_s_2422 = heff_tag(TAG_Just, 1, (V[]){heff_rec(4, shape_152_232_349_288, (V[]){v_key_240, v_t_2421, v_trmc_244, v_sapp_245})});
  V v_env_2423 = heff_get(v_r_243, LBL_env);
  V v_env_2424 = heff_rec(4, shape_120_200_361_295, (V[]){heff_get(heff_dup(v_env_2423), LBL_gs), heff_get(heff_dup(v_env_2423), LBL_names), heff_get(v_env_2423, LBL_used), v_s_2422});
  V v_t_2425 = (g_heff_2eemit_2estmtsF_24s581(v_env_2424, MK_INT(2LL), v_b_242));
  V v_t_2426 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemit_2elooped_str9), NTAG(TAG_Nil)});
  V v_t_2427 = (g_prelude_2econcatList(v_t_2425, heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemit_2elooped_str10), v_t_2426})));
  V v_t_2428 = (g_prelude_2econcatList(heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemit_2elooped_str11), v_t_2420}), v_t_2427));
  V v_t_2429 = (g_prelude_2econcatList(v_t_2413, v_t_2428));
  V v_t_2430 = (g_prelude_2econcatList(v_t_2412, v_t_2429));
  return (g_prelude_2econcatList(heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemit_2elooped_str12), v_t_2411}), v_t_2430));
}
V g_heff_2eemit_2elooped_entry(V self, V *a) {
  (void)self;
  return g_heff_2eemit_2elooped(a[0], a[1], a[2], a[3], a[4], a[5]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2edefFun_str0 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2eemit_2edefFun_str1 = {{0x80000000u, K_STR, 0}, 6, 6, {99, 111, 110, 115, 116, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eemit_2edefFun_str2 = {{0x80000000u, K_STR, 0}, 4, 4, {32, 61, 32, 40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eemit_2edefFun_str3 = {{0x80000000u, K_STR, 0}, 5, 5, {41, 32, 61, 62, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2edefFun_str4 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2edefFun_str5 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
Clo g_heff_2eemit_2edefFun_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemit_2edefFun_entry, 6, 0};

V g_heff_2eemit_2edefFun(V v_curried_240, V v_key_241, V v_i_242, V v_xs_243, V v_b_244, V v_r_245) {
top: ;
  V v_t_246 = (g_prelude_2efoldl_24s1(MK_INT(0LL), v_xs_243));
  V v_t_247 = (g_heff_2eemit_2etailSelf(heff_dup(v_key_241), v_t_246, v_b_244));
  V v_t_2419;
  switch (heff_tag_of(v_t_247)) {
  case TAG_True: {
    V v_t_248 = (g_prelude_2efoldl_24s1(MK_INT(0LL), v_xs_243));
    V v_t_249 = (g_heff_2eemit_2econsSelf(heff_dup(v_key_241), v_t_248, v_b_244));
    V v_t_2410 = (g_prelude_2efoldl_24s1(MK_INT(0LL), v_xs_243));
    V v_t_2411 = (g_heff_2eemit_2eappendSelf(heff_dup(v_key_241), v_t_2410, v_b_244));
    v_t_2419 = (g_heff_2eemit_2elooped(heff_dup(v_key_241), heff_dup(v_i_242), v_b_244, heff_dup(v_r_245), v_t_249, v_t_2411));
    break;
  }
  case TAG_False: {
    V v_t_2412 = heff_get(heff_dup(v_r_245), LBL_js);
    V v_t_2415;
    switch (heff_tag_of(v_t_2412)) {
    case TAG_Nil: {
      v_t_2415 = ((V)&g_heff_2eemit_2edefFun_str0);
      break;
    }
    case TAG_Cons: {
      V v_x_2413 = heff_field(v_t_2412, 0);
      V v_xs_2414 = heff_field(v_t_2412, 1);
      heff_take_n(v_t_2412, 3ULL, 2);
      v_t_2415 = ({ V a_0 = v_x_2413; V a_1 = v_xs_2414; V r_ = (g_prelude_2efoldl_24s45(a_0, a_1)); heff_drop(v_xs_2414); r_; });
      break;
    }
    default: heff_nomatch(v_t_2412);
    }
    V v_t_2416 = (g_heff_2eemit_2ebodyF_24s590(heff_get(heff_dup(v_r_245), LBL_env), MK_INT(0LL), v_b_244));
    V v_t_2417 = heff_strAppend(((V)&g_heff_2eemit_2edefFun_str1), heff_strAppend(heff_get(heff_dup(v_i_242), LBL_js), heff_strAppend(((V)&g_heff_2eemit_2edefFun_str2), heff_strAppend(v_t_2415, heff_strAppend(((V)&g_heff_2eemit_2edefFun_str3), heff_strAppend(v_t_2416, ((V)&g_heff_2eemit_2edefFun_str4)))))));
    V v_t_2418 = heff_tag(TAG_Cons, 2, (V[]){v_t_2417, NTAG(TAG_Nil)});
    v_t_2419 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemit_2edefFun_str5), v_t_2418});
    break;
  }
  default: heff_nomatch(v_t_247);
  }
  V v_t_2420 = (g_heff_2eemit_2ewrapper(v_curried_240, v_key_241, v_i_242, heff_get(v_r_245, LBL_js)));
  return (g_prelude_2econcatList(v_t_2419, v_t_2420));
}
V g_heff_2eemit_2edefFun_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eemit_2edefFun(a[0], a[1], a[2], a[3], a[4], a[5]); heff_drop(a[0]); heff_drop(a[3]); return r;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2eemit_2edefBody_str0 = {{0x80000000u, K_STR, 0}, 6, 6, {99, 111, 110, 115, 116, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[15]; } g_heff_2eemit_2edefBody_str1 = {{0x80000000u, K_STR, 0}, 15, 15, {32, 61, 32, 36, 108, 97, 122, 121, 40, 40, 41, 32, 61, 62, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemit_2edefBody_str2 = {{0x80000000u, K_STR, 0}, 2, 2, {41, 59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2edefBody_str3 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2eemit_2edefBody_str4 = {{0x80000000u, K_STR, 0}, 6, 6, {99, 111, 110, 115, 116, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemit_2edefBody_str5 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 61, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2edefBody_str6 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2edefBody_str7 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2eemit_2edefBody_str8 = {{0x80000000u, K_STR, 0}, 6, 6, {99, 111, 110, 115, 116, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[15]; } g_heff_2eemit_2edefBody_str9 = {{0x80000000u, K_STR, 0}, 15, 15, {32, 61, 32, 36, 108, 97, 122, 121, 40, 40, 41, 32, 61, 62, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemit_2edefBody_str10 = {{0x80000000u, K_STR, 0}, 2, 2, {41, 59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2edefBody_str11 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2eemit_2edefBody_str12 = {{0x80000000u, K_STR, 0}, 6, 6, {99, 111, 110, 115, 116, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemit_2edefBody_str13 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 61, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2edefBody_str14 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2edefBody_str15 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2eemit_2edefBody_str16 = {{0x80000000u, K_STR, 0}, 6, 6, {99, 111, 110, 115, 116, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[15]; } g_heff_2eemit_2edefBody_str17 = {{0x80000000u, K_STR, 0}, 15, 15, {32, 61, 32, 36, 108, 97, 122, 121, 40, 40, 41, 32, 61, 62, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemit_2edefBody_str18 = {{0x80000000u, K_STR, 0}, 2, 2, {41, 59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2edefBody_str19 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2eemit_2edefBody_str20 = {{0x80000000u, K_STR, 0}, 6, 6, {99, 111, 110, 115, 116, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemit_2edefBody_str21 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 61, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2edefBody_str22 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2edefBody_str23 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2eemit_2edefBody_str24 = {{0x80000000u, K_STR, 0}, 6, 6, {99, 111, 110, 115, 116, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[15]; } g_heff_2eemit_2edefBody_str25 = {{0x80000000u, K_STR, 0}, 15, 15, {32, 61, 32, 36, 108, 97, 122, 121, 40, 40, 41, 32, 61, 62, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemit_2edefBody_str26 = {{0x80000000u, K_STR, 0}, 2, 2, {41, 59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2edefBody_str27 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2eemit_2edefBody_str28 = {{0x80000000u, K_STR, 0}, 6, 6, {99, 111, 110, 115, 116, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemit_2edefBody_str29 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 61, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2edefBody_str30 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2edefBody_str31 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2eemit_2edefBody_str32 = {{0x80000000u, K_STR, 0}, 6, 6, {99, 111, 110, 115, 116, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[15]; } g_heff_2eemit_2edefBody_str33 = {{0x80000000u, K_STR, 0}, 15, 15, {32, 61, 32, 36, 108, 97, 122, 121, 40, 40, 41, 32, 61, 62, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemit_2edefBody_str34 = {{0x80000000u, K_STR, 0}, 2, 2, {41, 59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2edefBody_str35 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2eemit_2edefBody_str36 = {{0x80000000u, K_STR, 0}, 6, 6, {99, 111, 110, 115, 116, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemit_2edefBody_str37 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 61, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2edefBody_str38 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2edefBody_str39 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2eemit_2edefBody_str40 = {{0x80000000u, K_STR, 0}, 6, 6, {99, 111, 110, 115, 116, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[15]; } g_heff_2eemit_2edefBody_str41 = {{0x80000000u, K_STR, 0}, 15, 15, {32, 61, 32, 36, 108, 97, 122, 121, 40, 40, 41, 32, 61, 62, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemit_2edefBody_str42 = {{0x80000000u, K_STR, 0}, 2, 2, {41, 59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2edefBody_str43 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2eemit_2edefBody_str44 = {{0x80000000u, K_STR, 0}, 6, 6, {99, 111, 110, 115, 116, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemit_2edefBody_str45 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 61, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2edefBody_str46 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2edefBody_str47 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2eemit_2edefBody_str48 = {{0x80000000u, K_STR, 0}, 6, 6, {99, 111, 110, 115, 116, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[15]; } g_heff_2eemit_2edefBody_str49 = {{0x80000000u, K_STR, 0}, 15, 15, {32, 61, 32, 36, 108, 97, 122, 121, 40, 40, 41, 32, 61, 62, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemit_2edefBody_str50 = {{0x80000000u, K_STR, 0}, 2, 2, {41, 59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2edefBody_str51 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2eemit_2edefBody_str52 = {{0x80000000u, K_STR, 0}, 6, 6, {99, 111, 110, 115, 116, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemit_2edefBody_str53 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 61, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2edefBody_str54 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2edefBody_str55 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2eemit_2edefBody_str56 = {{0x80000000u, K_STR, 0}, 6, 6, {99, 111, 110, 115, 116, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[15]; } g_heff_2eemit_2edefBody_str57 = {{0x80000000u, K_STR, 0}, 15, 15, {32, 61, 32, 36, 108, 97, 122, 121, 40, 40, 41, 32, 61, 62, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemit_2edefBody_str58 = {{0x80000000u, K_STR, 0}, 2, 2, {41, 59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2edefBody_str59 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2eemit_2edefBody_str60 = {{0x80000000u, K_STR, 0}, 6, 6, {99, 111, 110, 115, 116, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemit_2edefBody_str61 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 61, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2edefBody_str62 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2edefBody_str63 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2eemit_2edefBody_str64 = {{0x80000000u, K_STR, 0}, 6, 6, {99, 111, 110, 115, 116, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[15]; } g_heff_2eemit_2edefBody_str65 = {{0x80000000u, K_STR, 0}, 15, 15, {32, 61, 32, 36, 108, 97, 122, 121, 40, 40, 41, 32, 61, 62, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemit_2edefBody_str66 = {{0x80000000u, K_STR, 0}, 2, 2, {41, 59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2edefBody_str67 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2eemit_2edefBody_str68 = {{0x80000000u, K_STR, 0}, 6, 6, {99, 111, 110, 115, 116, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemit_2edefBody_str69 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 61, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2edefBody_str70 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2edefBody_str71 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2eemit_2edefBody_str72 = {{0x80000000u, K_STR, 0}, 6, 6, {99, 111, 110, 115, 116, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[15]; } g_heff_2eemit_2edefBody_str73 = {{0x80000000u, K_STR, 0}, 15, 15, {32, 61, 32, 36, 108, 97, 122, 121, 40, 40, 41, 32, 61, 62, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemit_2edefBody_str74 = {{0x80000000u, K_STR, 0}, 2, 2, {41, 59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2edefBody_str75 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2eemit_2edefBody_str76 = {{0x80000000u, K_STR, 0}, 6, 6, {99, 111, 110, 115, 116, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemit_2edefBody_str77 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 61, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2edefBody_str78 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2edefBody_str79 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2eemit_2edefBody_str80 = {{0x80000000u, K_STR, 0}, 6, 6, {99, 111, 110, 115, 116, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[15]; } g_heff_2eemit_2edefBody_str81 = {{0x80000000u, K_STR, 0}, 15, 15, {32, 61, 32, 36, 108, 97, 122, 121, 40, 40, 41, 32, 61, 62, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemit_2edefBody_str82 = {{0x80000000u, K_STR, 0}, 2, 2, {41, 59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2edefBody_str83 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2eemit_2edefBody_str84 = {{0x80000000u, K_STR, 0}, 6, 6, {99, 111, 110, 115, 116, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemit_2edefBody_str85 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 61, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2edefBody_str86 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2edefBody_str87 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2eemit_2edefBody_str88 = {{0x80000000u, K_STR, 0}, 6, 6, {99, 111, 110, 115, 116, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[15]; } g_heff_2eemit_2edefBody_str89 = {{0x80000000u, K_STR, 0}, 15, 15, {32, 61, 32, 36, 108, 97, 122, 121, 40, 40, 41, 32, 61, 62, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemit_2edefBody_str90 = {{0x80000000u, K_STR, 0}, 2, 2, {41, 59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2edefBody_str91 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2eemit_2edefBody_str92 = {{0x80000000u, K_STR, 0}, 6, 6, {99, 111, 110, 115, 116, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemit_2edefBody_str93 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 61, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2edefBody_str94 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2edefBody_str95 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2eemit_2edefBody_str96 = {{0x80000000u, K_STR, 0}, 6, 6, {99, 111, 110, 115, 116, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[15]; } g_heff_2eemit_2edefBody_str97 = {{0x80000000u, K_STR, 0}, 15, 15, {32, 61, 32, 36, 108, 97, 122, 121, 40, 40, 41, 32, 61, 62, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemit_2edefBody_str98 = {{0x80000000u, K_STR, 0}, 2, 2, {41, 59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2edefBody_str99 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2eemit_2edefBody_str100 = {{0x80000000u, K_STR, 0}, 6, 6, {99, 111, 110, 115, 116, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemit_2edefBody_str101 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 61, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2edefBody_str102 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2edefBody_str103 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2eemit_2edefBody_str104 = {{0x80000000u, K_STR, 0}, 6, 6, {99, 111, 110, 115, 116, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[15]; } g_heff_2eemit_2edefBody_str105 = {{0x80000000u, K_STR, 0}, 15, 15, {32, 61, 32, 36, 108, 97, 122, 121, 40, 40, 41, 32, 61, 62, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemit_2edefBody_str106 = {{0x80000000u, K_STR, 0}, 2, 2, {41, 59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2edefBody_str107 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2eemit_2edefBody_str108 = {{0x80000000u, K_STR, 0}, 6, 6, {99, 111, 110, 115, 116, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemit_2edefBody_str109 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 61, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2edefBody_str110 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2edefBody_str111 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2eemit_2edefBody_str112 = {{0x80000000u, K_STR, 0}, 6, 6, {99, 111, 110, 115, 116, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[15]; } g_heff_2eemit_2edefBody_str113 = {{0x80000000u, K_STR, 0}, 15, 15, {32, 61, 32, 36, 108, 97, 122, 121, 40, 40, 41, 32, 61, 62, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemit_2edefBody_str114 = {{0x80000000u, K_STR, 0}, 2, 2, {41, 59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2edefBody_str115 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2eemit_2edefBody_str116 = {{0x80000000u, K_STR, 0}, 6, 6, {99, 111, 110, 115, 116, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemit_2edefBody_str117 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 61, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2edefBody_str118 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2edefBody_str119 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2eemit_2edefBody_str120 = {{0x80000000u, K_STR, 0}, 6, 6, {99, 111, 110, 115, 116, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[15]; } g_heff_2eemit_2edefBody_str121 = {{0x80000000u, K_STR, 0}, 15, 15, {32, 61, 32, 36, 108, 97, 122, 121, 40, 40, 41, 32, 61, 62, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemit_2edefBody_str122 = {{0x80000000u, K_STR, 0}, 2, 2, {41, 59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2edefBody_str123 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2eemit_2edefBody_str124 = {{0x80000000u, K_STR, 0}, 6, 6, {99, 111, 110, 115, 116, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemit_2edefBody_str125 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 61, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2edefBody_str126 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2edefBody_str127 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
Clo g_heff_2eemit_2edefBody_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemit_2edefBody_entry, 5, 0};

V g_heff_2eemit_2edefBody(V v_gs_240, V v_curried_241, V v_globalNames_242, V v_d_243, V v_i_244) {
top: ;
  V v_t_245 = heff_get(heff_dup(v_d_243), LBL_body);
  switch (heff_tag_of(v_t_245)) {
  case TAG_EVar: {
    heff_take_n(v_t_245, 0ULL, 1);
    V v_t_247 = heff_get(heff_dup(v_i_244), LBL_lazy);
    switch (heff_tag_of(v_t_247)) {
    case TAG_True: {
      V v_t_248 = heff_rec(4, shape_120_200_361_295, (V[]){v_gs_240, heff_dup(g_map_2eempty_get()), v_globalNames_242, NTAG(TAG_Nothing)});
      V v_t_249 = (g_heff_2eemit_2ebodyF_24s590(v_t_248, MK_INT(0LL), heff_get(v_d_243, LBL_body)));
      V v_t_2410 = heff_strAppend(((V)&g_heff_2eemit_2edefBody_str0), heff_strAppend(heff_get(v_i_244, LBL_js), heff_strAppend(((V)&g_heff_2eemit_2edefBody_str1), heff_strAppend(v_t_249, ((V)&g_heff_2eemit_2edefBody_str2)))));
      V v_t_2411 = heff_tag(TAG_Cons, 2, (V[]){v_t_2410, NTAG(TAG_Nil)});
      return heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemit_2edefBody_str3), v_t_2411});
    }
    case TAG_False: {
      V v_t_2412 = heff_rec(4, shape_120_200_361_295, (V[]){v_gs_240, heff_dup(g_map_2eempty_get()), v_globalNames_242, NTAG(TAG_Nothing)});
      V v_t_2413 = heff_tr(g_heff_2eemit_2eexprGo_24s585(v_t_2412, MK_INT(0LL), heff_get(v_d_243, LBL_body)));
      V v_t_2414 = heff_strAppend(((V)&g_heff_2eemit_2edefBody_str4), heff_strAppend(heff_get(v_i_244, LBL_js), heff_strAppend(((V)&g_heff_2eemit_2edefBody_str5), heff_strAppend(heff_get(v_t_2413, LBL_code), ((V)&g_heff_2eemit_2edefBody_str6)))));
      V v_t_2415 = heff_tag(TAG_Cons, 2, (V[]){v_t_2414, NTAG(TAG_Nil)});
      return heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemit_2edefBody_str7), v_t_2415});
    }
    default: return heff_nomatch(v_t_247);
    }
  }
  case TAG_EGlobal: {
    heff_take_n(v_t_245, 0ULL, 1);
    V v_t_2417 = heff_get(heff_dup(v_i_244), LBL_lazy);
    switch (heff_tag_of(v_t_2417)) {
    case TAG_True: {
      V v_t_2418 = heff_rec(4, shape_120_200_361_295, (V[]){v_gs_240, heff_dup(g_map_2eempty_get()), v_globalNames_242, NTAG(TAG_Nothing)});
      V v_t_2419 = (g_heff_2eemit_2ebodyF_24s590(v_t_2418, MK_INT(0LL), heff_get(v_d_243, LBL_body)));
      V v_t_2420 = heff_strAppend(((V)&g_heff_2eemit_2edefBody_str8), heff_strAppend(heff_get(v_i_244, LBL_js), heff_strAppend(((V)&g_heff_2eemit_2edefBody_str9), heff_strAppend(v_t_2419, ((V)&g_heff_2eemit_2edefBody_str10)))));
      V v_t_2421 = heff_tag(TAG_Cons, 2, (V[]){v_t_2420, NTAG(TAG_Nil)});
      return heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemit_2edefBody_str11), v_t_2421});
    }
    case TAG_False: {
      V v_t_2422 = heff_rec(4, shape_120_200_361_295, (V[]){v_gs_240, heff_dup(g_map_2eempty_get()), v_globalNames_242, NTAG(TAG_Nothing)});
      V v_t_2423 = heff_tr(g_heff_2eemit_2eexprGo_24s585(v_t_2422, MK_INT(0LL), heff_get(v_d_243, LBL_body)));
      V v_t_2424 = heff_strAppend(((V)&g_heff_2eemit_2edefBody_str12), heff_strAppend(heff_get(v_i_244, LBL_js), heff_strAppend(((V)&g_heff_2eemit_2edefBody_str13), heff_strAppend(heff_get(v_t_2423, LBL_code), ((V)&g_heff_2eemit_2edefBody_str14)))));
      V v_t_2425 = heff_tag(TAG_Cons, 2, (V[]){v_t_2424, NTAG(TAG_Nil)});
      return heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemit_2edefBody_str15), v_t_2425});
    }
    default: return heff_nomatch(v_t_2417);
    }
  }
  case TAG_ELam: {
    V v_xs_2426 = heff_field(v_t_245, 0);
    V v_b_2427 = heff_field(v_t_245, 1);
    heff_take_n(v_t_245, 3ULL, 2);
    V v_t_2428 = heff_rec(4, shape_120_200_361_295, (V[]){v_gs_240, heff_dup(g_map_2eempty_get()), v_globalNames_242, NTAG(TAG_Nothing)});
    V v_t_2429 = heff_rec(2, shape_150_87, (V[]){NTAG(TAG_Nil), v_t_2428});
    V v_t_2430 = (g_prelude_2efoldl_24s575(v_t_2429, heff_dup(v_xs_2426)));
    return ({ V a_0 = v_curried_241; V a_1 = heff_get(v_d_243, LBL_key); V a_2 = v_i_244; V a_3 = v_xs_2426; V a_4 = v_b_2427; V a_5 = v_t_2430; V r_ = (g_heff_2eemit_2edefFun(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_xs_2426); r_; });
  }
  case TAG_EApp: {
    V v_ru_24t_245_24EApp = heff_take_reuse_n(v_t_245, 0ULL, 2);
    V v_t_2433 = heff_get(heff_dup(v_i_244), LBL_lazy);
    switch (heff_tag_of(v_t_2433)) {
    case TAG_True: {
      V v_t_2434 = heff_rec(4, shape_120_200_361_295, (V[]){v_gs_240, heff_dup(g_map_2eempty_get()), v_globalNames_242, NTAG(TAG_Nothing)});
      V v_t_2435 = (g_heff_2eemit_2ebodyF_24s590(v_t_2434, MK_INT(0LL), heff_get(v_d_243, LBL_body)));
      V v_t_2436 = heff_strAppend(((V)&g_heff_2eemit_2edefBody_str16), heff_strAppend(heff_get(v_i_244, LBL_js), heff_strAppend(((V)&g_heff_2eemit_2edefBody_str17), heff_strAppend(v_t_2435, ((V)&g_heff_2eemit_2edefBody_str18)))));
      V v_t_2437 = heff_tag_at(v_ru_24t_245_24EApp, TAG_Cons, 2, (V[]){v_t_2436, NTAG(TAG_Nil)});
      return heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemit_2edefBody_str19), v_t_2437});
    }
    case TAG_False: {
      V v_t_2438 = heff_rec(4, shape_120_200_361_295, (V[]){v_gs_240, heff_dup(g_map_2eempty_get()), v_globalNames_242, NTAG(TAG_Nothing)});
      V v_t_2439 = heff_tr(g_heff_2eemit_2eexprGo_24s585(v_t_2438, MK_INT(0LL), heff_get(v_d_243, LBL_body)));
      V v_t_2440 = heff_strAppend(((V)&g_heff_2eemit_2edefBody_str20), heff_strAppend(heff_get(v_i_244, LBL_js), heff_strAppend(((V)&g_heff_2eemit_2edefBody_str21), heff_strAppend(heff_get(v_t_2439, LBL_code), ((V)&g_heff_2eemit_2edefBody_str22)))));
      V v_t_2441 = heff_tag_at(v_ru_24t_245_24EApp, TAG_Cons, 2, (V[]){v_t_2440, NTAG(TAG_Nil)});
      return heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemit_2edefBody_str23), v_t_2441});
    }
    default: return heff_nomatch(v_t_2433);
    }
  }
  case TAG_ELet: {
    heff_take_n(v_t_245, 0ULL, 3);
    V v_t_2445 = heff_get(heff_dup(v_i_244), LBL_lazy);
    switch (heff_tag_of(v_t_2445)) {
    case TAG_True: {
      V v_t_2446 = heff_rec(4, shape_120_200_361_295, (V[]){v_gs_240, heff_dup(g_map_2eempty_get()), v_globalNames_242, NTAG(TAG_Nothing)});
      V v_t_2447 = (g_heff_2eemit_2ebodyF_24s590(v_t_2446, MK_INT(0LL), heff_get(v_d_243, LBL_body)));
      V v_t_2448 = heff_strAppend(((V)&g_heff_2eemit_2edefBody_str24), heff_strAppend(heff_get(v_i_244, LBL_js), heff_strAppend(((V)&g_heff_2eemit_2edefBody_str25), heff_strAppend(v_t_2447, ((V)&g_heff_2eemit_2edefBody_str26)))));
      V v_t_2449 = heff_tag(TAG_Cons, 2, (V[]){v_t_2448, NTAG(TAG_Nil)});
      return heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemit_2edefBody_str27), v_t_2449});
    }
    case TAG_False: {
      V v_t_2450 = heff_rec(4, shape_120_200_361_295, (V[]){v_gs_240, heff_dup(g_map_2eempty_get()), v_globalNames_242, NTAG(TAG_Nothing)});
      V v_t_2451 = heff_tr(g_heff_2eemit_2eexprGo_24s585(v_t_2450, MK_INT(0LL), heff_get(v_d_243, LBL_body)));
      V v_t_2452 = heff_strAppend(((V)&g_heff_2eemit_2edefBody_str28), heff_strAppend(heff_get(v_i_244, LBL_js), heff_strAppend(((V)&g_heff_2eemit_2edefBody_str29), heff_strAppend(heff_get(v_t_2451, LBL_code), ((V)&g_heff_2eemit_2edefBody_str30)))));
      V v_t_2453 = heff_tag(TAG_Cons, 2, (V[]){v_t_2452, NTAG(TAG_Nil)});
      return heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemit_2edefBody_str31), v_t_2453});
    }
    default: return heff_nomatch(v_t_2445);
    }
  }
  case TAG_ERecord: {
    heff_take_n(v_t_245, 0ULL, 1);
    V v_t_2455 = heff_get(heff_dup(v_i_244), LBL_lazy);
    switch (heff_tag_of(v_t_2455)) {
    case TAG_True: {
      V v_t_2456 = heff_rec(4, shape_120_200_361_295, (V[]){v_gs_240, heff_dup(g_map_2eempty_get()), v_globalNames_242, NTAG(TAG_Nothing)});
      V v_t_2457 = (g_heff_2eemit_2ebodyF_24s590(v_t_2456, MK_INT(0LL), heff_get(v_d_243, LBL_body)));
      V v_t_2458 = heff_strAppend(((V)&g_heff_2eemit_2edefBody_str32), heff_strAppend(heff_get(v_i_244, LBL_js), heff_strAppend(((V)&g_heff_2eemit_2edefBody_str33), heff_strAppend(v_t_2457, ((V)&g_heff_2eemit_2edefBody_str34)))));
      V v_t_2459 = heff_tag(TAG_Cons, 2, (V[]){v_t_2458, NTAG(TAG_Nil)});
      return heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemit_2edefBody_str35), v_t_2459});
    }
    case TAG_False: {
      V v_t_2460 = heff_rec(4, shape_120_200_361_295, (V[]){v_gs_240, heff_dup(g_map_2eempty_get()), v_globalNames_242, NTAG(TAG_Nothing)});
      V v_t_2461 = heff_tr(g_heff_2eemit_2eexprGo_24s585(v_t_2460, MK_INT(0LL), heff_get(v_d_243, LBL_body)));
      V v_t_2462 = heff_strAppend(((V)&g_heff_2eemit_2edefBody_str36), heff_strAppend(heff_get(v_i_244, LBL_js), heff_strAppend(((V)&g_heff_2eemit_2edefBody_str37), heff_strAppend(heff_get(v_t_2461, LBL_code), ((V)&g_heff_2eemit_2edefBody_str38)))));
      V v_t_2463 = heff_tag(TAG_Cons, 2, (V[]){v_t_2462, NTAG(TAG_Nil)});
      return heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemit_2edefBody_str39), v_t_2463});
    }
    default: return heff_nomatch(v_t_2455);
    }
  }
  case TAG_EProj: {
    V v_ru_24t_245_24EProj = heff_take_reuse_n(v_t_245, 0ULL, 2);
    V v_t_2466 = heff_get(heff_dup(v_i_244), LBL_lazy);
    switch (heff_tag_of(v_t_2466)) {
    case TAG_True: {
      V v_t_2467 = heff_rec(4, shape_120_200_361_295, (V[]){v_gs_240, heff_dup(g_map_2eempty_get()), v_globalNames_242, NTAG(TAG_Nothing)});
      V v_t_2468 = (g_heff_2eemit_2ebodyF_24s590(v_t_2467, MK_INT(0LL), heff_get(v_d_243, LBL_body)));
      V v_t_2469 = heff_strAppend(((V)&g_heff_2eemit_2edefBody_str40), heff_strAppend(heff_get(v_i_244, LBL_js), heff_strAppend(((V)&g_heff_2eemit_2edefBody_str41), heff_strAppend(v_t_2468, ((V)&g_heff_2eemit_2edefBody_str42)))));
      V v_t_2470 = heff_tag_at(v_ru_24t_245_24EProj, TAG_Cons, 2, (V[]){v_t_2469, NTAG(TAG_Nil)});
      return heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemit_2edefBody_str43), v_t_2470});
    }
    case TAG_False: {
      V v_t_2471 = heff_rec(4, shape_120_200_361_295, (V[]){v_gs_240, heff_dup(g_map_2eempty_get()), v_globalNames_242, NTAG(TAG_Nothing)});
      V v_t_2472 = heff_tr(g_heff_2eemit_2eexprGo_24s585(v_t_2471, MK_INT(0LL), heff_get(v_d_243, LBL_body)));
      V v_t_2473 = heff_strAppend(((V)&g_heff_2eemit_2edefBody_str44), heff_strAppend(heff_get(v_i_244, LBL_js), heff_strAppend(((V)&g_heff_2eemit_2edefBody_str45), heff_strAppend(heff_get(v_t_2472, LBL_code), ((V)&g_heff_2eemit_2edefBody_str46)))));
      V v_t_2474 = heff_tag_at(v_ru_24t_245_24EProj, TAG_Cons, 2, (V[]){v_t_2473, NTAG(TAG_Nil)});
      return heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemit_2edefBody_str47), v_t_2474});
    }
    default: return heff_nomatch(v_t_2466);
    }
  }
  case TAG_ETag: {
    V v_ru_24t_245_24ETag = heff_take_reuse_n(v_t_245, 0ULL, 2);
    V v_t_2477 = heff_get(heff_dup(v_i_244), LBL_lazy);
    switch (heff_tag_of(v_t_2477)) {
    case TAG_True: {
      V v_t_2478 = heff_rec(4, shape_120_200_361_295, (V[]){v_gs_240, heff_dup(g_map_2eempty_get()), v_globalNames_242, NTAG(TAG_Nothing)});
      V v_t_2479 = (g_heff_2eemit_2ebodyF_24s590(v_t_2478, MK_INT(0LL), heff_get(v_d_243, LBL_body)));
      V v_t_2480 = heff_strAppend(((V)&g_heff_2eemit_2edefBody_str48), heff_strAppend(heff_get(v_i_244, LBL_js), heff_strAppend(((V)&g_heff_2eemit_2edefBody_str49), heff_strAppend(v_t_2479, ((V)&g_heff_2eemit_2edefBody_str50)))));
      V v_t_2481 = heff_tag_at(v_ru_24t_245_24ETag, TAG_Cons, 2, (V[]){v_t_2480, NTAG(TAG_Nil)});
      return heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemit_2edefBody_str51), v_t_2481});
    }
    case TAG_False: {
      V v_t_2482 = heff_rec(4, shape_120_200_361_295, (V[]){v_gs_240, heff_dup(g_map_2eempty_get()), v_globalNames_242, NTAG(TAG_Nothing)});
      V v_t_2483 = heff_tr(g_heff_2eemit_2eexprGo_24s585(v_t_2482, MK_INT(0LL), heff_get(v_d_243, LBL_body)));
      V v_t_2484 = heff_strAppend(((V)&g_heff_2eemit_2edefBody_str52), heff_strAppend(heff_get(v_i_244, LBL_js), heff_strAppend(((V)&g_heff_2eemit_2edefBody_str53), heff_strAppend(heff_get(v_t_2483, LBL_code), ((V)&g_heff_2eemit_2edefBody_str54)))));
      V v_t_2485 = heff_tag_at(v_ru_24t_245_24ETag, TAG_Cons, 2, (V[]){v_t_2484, NTAG(TAG_Nil)});
      return heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemit_2edefBody_str55), v_t_2485});
    }
    default: return heff_nomatch(v_t_2477);
    }
  }
  case TAG_EMatch: {
    V v_ru_24t_245_24EMatch = heff_take_reuse_n(v_t_245, 0ULL, 2);
    V v_t_2488 = heff_get(heff_dup(v_i_244), LBL_lazy);
    switch (heff_tag_of(v_t_2488)) {
    case TAG_True: {
      V v_t_2489 = heff_rec(4, shape_120_200_361_295, (V[]){v_gs_240, heff_dup(g_map_2eempty_get()), v_globalNames_242, NTAG(TAG_Nothing)});
      V v_t_2490 = (g_heff_2eemit_2ebodyF_24s590(v_t_2489, MK_INT(0LL), heff_get(v_d_243, LBL_body)));
      V v_t_2491 = heff_strAppend(((V)&g_heff_2eemit_2edefBody_str56), heff_strAppend(heff_get(v_i_244, LBL_js), heff_strAppend(((V)&g_heff_2eemit_2edefBody_str57), heff_strAppend(v_t_2490, ((V)&g_heff_2eemit_2edefBody_str58)))));
      V v_t_2492 = heff_tag_at(v_ru_24t_245_24EMatch, TAG_Cons, 2, (V[]){v_t_2491, NTAG(TAG_Nil)});
      return heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemit_2edefBody_str59), v_t_2492});
    }
    case TAG_False: {
      V v_t_2493 = heff_rec(4, shape_120_200_361_295, (V[]){v_gs_240, heff_dup(g_map_2eempty_get()), v_globalNames_242, NTAG(TAG_Nothing)});
      V v_t_2494 = heff_tr(g_heff_2eemit_2eexprGo_24s585(v_t_2493, MK_INT(0LL), heff_get(v_d_243, LBL_body)));
      V v_t_2495 = heff_strAppend(((V)&g_heff_2eemit_2edefBody_str60), heff_strAppend(heff_get(v_i_244, LBL_js), heff_strAppend(((V)&g_heff_2eemit_2edefBody_str61), heff_strAppend(heff_get(v_t_2494, LBL_code), ((V)&g_heff_2eemit_2edefBody_str62)))));
      V v_t_2496 = heff_tag_at(v_ru_24t_245_24EMatch, TAG_Cons, 2, (V[]){v_t_2495, NTAG(TAG_Nil)});
      return heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemit_2edefBody_str63), v_t_2496});
    }
    default: return heff_nomatch(v_t_2488);
    }
  }
  case TAG_EPrim: {
    heff_take_n(v_t_245, 0ULL, 1);
    V v_t_2498 = heff_get(heff_dup(v_i_244), LBL_lazy);
    switch (heff_tag_of(v_t_2498)) {
    case TAG_True: {
      V v_t_2499 = heff_rec(4, shape_120_200_361_295, (V[]){v_gs_240, heff_dup(g_map_2eempty_get()), v_globalNames_242, NTAG(TAG_Nothing)});
      V v_t_24100 = (g_heff_2eemit_2ebodyF_24s590(v_t_2499, MK_INT(0LL), heff_get(v_d_243, LBL_body)));
      V v_t_24101 = heff_strAppend(((V)&g_heff_2eemit_2edefBody_str64), heff_strAppend(heff_get(v_i_244, LBL_js), heff_strAppend(((V)&g_heff_2eemit_2edefBody_str65), heff_strAppend(v_t_24100, ((V)&g_heff_2eemit_2edefBody_str66)))));
      V v_t_24102 = heff_tag(TAG_Cons, 2, (V[]){v_t_24101, NTAG(TAG_Nil)});
      return heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemit_2edefBody_str67), v_t_24102});
    }
    case TAG_False: {
      V v_t_24103 = heff_rec(4, shape_120_200_361_295, (V[]){v_gs_240, heff_dup(g_map_2eempty_get()), v_globalNames_242, NTAG(TAG_Nothing)});
      V v_t_24104 = heff_tr(g_heff_2eemit_2eexprGo_24s585(v_t_24103, MK_INT(0LL), heff_get(v_d_243, LBL_body)));
      V v_t_24105 = heff_strAppend(((V)&g_heff_2eemit_2edefBody_str68), heff_strAppend(heff_get(v_i_244, LBL_js), heff_strAppend(((V)&g_heff_2eemit_2edefBody_str69), heff_strAppend(heff_get(v_t_24104, LBL_code), ((V)&g_heff_2eemit_2edefBody_str70)))));
      V v_t_24106 = heff_tag(TAG_Cons, 2, (V[]){v_t_24105, NTAG(TAG_Nil)});
      return heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemit_2edefBody_str71), v_t_24106});
    }
    default: return heff_nomatch(v_t_2498);
    }
  }
  case TAG_EPrimCall: {
    V v_ru_24t_245_24EPrimCall = heff_take_reuse_n(v_t_245, 0ULL, 2);
    V v_t_24109 = heff_get(heff_dup(v_i_244), LBL_lazy);
    switch (heff_tag_of(v_t_24109)) {
    case TAG_True: {
      V v_t_24110 = heff_rec(4, shape_120_200_361_295, (V[]){v_gs_240, heff_dup(g_map_2eempty_get()), v_globalNames_242, NTAG(TAG_Nothing)});
      V v_t_24111 = (g_heff_2eemit_2ebodyF_24s590(v_t_24110, MK_INT(0LL), heff_get(v_d_243, LBL_body)));
      V v_t_24112 = heff_strAppend(((V)&g_heff_2eemit_2edefBody_str72), heff_strAppend(heff_get(v_i_244, LBL_js), heff_strAppend(((V)&g_heff_2eemit_2edefBody_str73), heff_strAppend(v_t_24111, ((V)&g_heff_2eemit_2edefBody_str74)))));
      V v_t_24113 = heff_tag_at(v_ru_24t_245_24EPrimCall, TAG_Cons, 2, (V[]){v_t_24112, NTAG(TAG_Nil)});
      return heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemit_2edefBody_str75), v_t_24113});
    }
    case TAG_False: {
      V v_t_24114 = heff_rec(4, shape_120_200_361_295, (V[]){v_gs_240, heff_dup(g_map_2eempty_get()), v_globalNames_242, NTAG(TAG_Nothing)});
      V v_t_24115 = heff_tr(g_heff_2eemit_2eexprGo_24s585(v_t_24114, MK_INT(0LL), heff_get(v_d_243, LBL_body)));
      V v_t_24116 = heff_strAppend(((V)&g_heff_2eemit_2edefBody_str76), heff_strAppend(heff_get(v_i_244, LBL_js), heff_strAppend(((V)&g_heff_2eemit_2edefBody_str77), heff_strAppend(heff_get(v_t_24115, LBL_code), ((V)&g_heff_2eemit_2edefBody_str78)))));
      V v_t_24117 = heff_tag_at(v_ru_24t_245_24EPrimCall, TAG_Cons, 2, (V[]){v_t_24116, NTAG(TAG_Nil)});
      return heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemit_2edefBody_str79), v_t_24117});
    }
    default: return heff_nomatch(v_t_24109);
    }
  }
  case TAG_ECall: {
    V v_ru_24t_245_24ECall = heff_take_reuse_n(v_t_245, 0ULL, 2);
    V v_t_24120 = heff_get(heff_dup(v_i_244), LBL_lazy);
    switch (heff_tag_of(v_t_24120)) {
    case TAG_True: {
      V v_t_24121 = heff_rec(4, shape_120_200_361_295, (V[]){v_gs_240, heff_dup(g_map_2eempty_get()), v_globalNames_242, NTAG(TAG_Nothing)});
      V v_t_24122 = (g_heff_2eemit_2ebodyF_24s590(v_t_24121, MK_INT(0LL), heff_get(v_d_243, LBL_body)));
      V v_t_24123 = heff_strAppend(((V)&g_heff_2eemit_2edefBody_str80), heff_strAppend(heff_get(v_i_244, LBL_js), heff_strAppend(((V)&g_heff_2eemit_2edefBody_str81), heff_strAppend(v_t_24122, ((V)&g_heff_2eemit_2edefBody_str82)))));
      V v_t_24124 = heff_tag_at(v_ru_24t_245_24ECall, TAG_Cons, 2, (V[]){v_t_24123, NTAG(TAG_Nil)});
      return heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemit_2edefBody_str83), v_t_24124});
    }
    case TAG_False: {
      V v_t_24125 = heff_rec(4, shape_120_200_361_295, (V[]){v_gs_240, heff_dup(g_map_2eempty_get()), v_globalNames_242, NTAG(TAG_Nothing)});
      V v_t_24126 = heff_tr(g_heff_2eemit_2eexprGo_24s585(v_t_24125, MK_INT(0LL), heff_get(v_d_243, LBL_body)));
      V v_t_24127 = heff_strAppend(((V)&g_heff_2eemit_2edefBody_str84), heff_strAppend(heff_get(v_i_244, LBL_js), heff_strAppend(((V)&g_heff_2eemit_2edefBody_str85), heff_strAppend(heff_get(v_t_24126, LBL_code), ((V)&g_heff_2eemit_2edefBody_str86)))));
      V v_t_24128 = heff_tag_at(v_ru_24t_245_24ECall, TAG_Cons, 2, (V[]){v_t_24127, NTAG(TAG_Nil)});
      return heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemit_2edefBody_str87), v_t_24128});
    }
    default: return heff_nomatch(v_t_24120);
    }
  }
  case TAG_EInt: {
    heff_take_n(v_t_245, 0ULL, 1);
    V v_t_24130 = heff_get(heff_dup(v_i_244), LBL_lazy);
    switch (heff_tag_of(v_t_24130)) {
    case TAG_True: {
      V v_t_24131 = heff_rec(4, shape_120_200_361_295, (V[]){v_gs_240, heff_dup(g_map_2eempty_get()), v_globalNames_242, NTAG(TAG_Nothing)});
      V v_t_24132 = (g_heff_2eemit_2ebodyF_24s590(v_t_24131, MK_INT(0LL), heff_get(v_d_243, LBL_body)));
      V v_t_24133 = heff_strAppend(((V)&g_heff_2eemit_2edefBody_str88), heff_strAppend(heff_get(v_i_244, LBL_js), heff_strAppend(((V)&g_heff_2eemit_2edefBody_str89), heff_strAppend(v_t_24132, ((V)&g_heff_2eemit_2edefBody_str90)))));
      V v_t_24134 = heff_tag(TAG_Cons, 2, (V[]){v_t_24133, NTAG(TAG_Nil)});
      return heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemit_2edefBody_str91), v_t_24134});
    }
    case TAG_False: {
      V v_t_24135 = heff_rec(4, shape_120_200_361_295, (V[]){v_gs_240, heff_dup(g_map_2eempty_get()), v_globalNames_242, NTAG(TAG_Nothing)});
      V v_t_24136 = heff_tr(g_heff_2eemit_2eexprGo_24s585(v_t_24135, MK_INT(0LL), heff_get(v_d_243, LBL_body)));
      V v_t_24137 = heff_strAppend(((V)&g_heff_2eemit_2edefBody_str92), heff_strAppend(heff_get(v_i_244, LBL_js), heff_strAppend(((V)&g_heff_2eemit_2edefBody_str93), heff_strAppend(heff_get(v_t_24136, LBL_code), ((V)&g_heff_2eemit_2edefBody_str94)))));
      V v_t_24138 = heff_tag(TAG_Cons, 2, (V[]){v_t_24137, NTAG(TAG_Nil)});
      return heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemit_2edefBody_str95), v_t_24138});
    }
    default: return heff_nomatch(v_t_24130);
    }
  }
  case TAG_EFloat: {
    heff_take_n(v_t_245, 0ULL, 1);
    V v_t_24140 = heff_get(heff_dup(v_i_244), LBL_lazy);
    switch (heff_tag_of(v_t_24140)) {
    case TAG_True: {
      V v_t_24141 = heff_rec(4, shape_120_200_361_295, (V[]){v_gs_240, heff_dup(g_map_2eempty_get()), v_globalNames_242, NTAG(TAG_Nothing)});
      V v_t_24142 = (g_heff_2eemit_2ebodyF_24s590(v_t_24141, MK_INT(0LL), heff_get(v_d_243, LBL_body)));
      V v_t_24143 = heff_strAppend(((V)&g_heff_2eemit_2edefBody_str96), heff_strAppend(heff_get(v_i_244, LBL_js), heff_strAppend(((V)&g_heff_2eemit_2edefBody_str97), heff_strAppend(v_t_24142, ((V)&g_heff_2eemit_2edefBody_str98)))));
      V v_t_24144 = heff_tag(TAG_Cons, 2, (V[]){v_t_24143, NTAG(TAG_Nil)});
      return heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemit_2edefBody_str99), v_t_24144});
    }
    case TAG_False: {
      V v_t_24145 = heff_rec(4, shape_120_200_361_295, (V[]){v_gs_240, heff_dup(g_map_2eempty_get()), v_globalNames_242, NTAG(TAG_Nothing)});
      V v_t_24146 = heff_tr(g_heff_2eemit_2eexprGo_24s585(v_t_24145, MK_INT(0LL), heff_get(v_d_243, LBL_body)));
      V v_t_24147 = heff_strAppend(((V)&g_heff_2eemit_2edefBody_str100), heff_strAppend(heff_get(v_i_244, LBL_js), heff_strAppend(((V)&g_heff_2eemit_2edefBody_str101), heff_strAppend(heff_get(v_t_24146, LBL_code), ((V)&g_heff_2eemit_2edefBody_str102)))));
      V v_t_24148 = heff_tag(TAG_Cons, 2, (V[]){v_t_24147, NTAG(TAG_Nil)});
      return heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemit_2edefBody_str103), v_t_24148});
    }
    default: return heff_nomatch(v_t_24140);
    }
  }
  case TAG_EStr: {
    heff_take_n(v_t_245, 0ULL, 1);
    V v_t_24150 = heff_get(heff_dup(v_i_244), LBL_lazy);
    switch (heff_tag_of(v_t_24150)) {
    case TAG_True: {
      V v_t_24151 = heff_rec(4, shape_120_200_361_295, (V[]){v_gs_240, heff_dup(g_map_2eempty_get()), v_globalNames_242, NTAG(TAG_Nothing)});
      V v_t_24152 = (g_heff_2eemit_2ebodyF_24s590(v_t_24151, MK_INT(0LL), heff_get(v_d_243, LBL_body)));
      V v_t_24153 = heff_strAppend(((V)&g_heff_2eemit_2edefBody_str104), heff_strAppend(heff_get(v_i_244, LBL_js), heff_strAppend(((V)&g_heff_2eemit_2edefBody_str105), heff_strAppend(v_t_24152, ((V)&g_heff_2eemit_2edefBody_str106)))));
      V v_t_24154 = heff_tag(TAG_Cons, 2, (V[]){v_t_24153, NTAG(TAG_Nil)});
      return heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemit_2edefBody_str107), v_t_24154});
    }
    case TAG_False: {
      V v_t_24155 = heff_rec(4, shape_120_200_361_295, (V[]){v_gs_240, heff_dup(g_map_2eempty_get()), v_globalNames_242, NTAG(TAG_Nothing)});
      V v_t_24156 = heff_tr(g_heff_2eemit_2eexprGo_24s585(v_t_24155, MK_INT(0LL), heff_get(v_d_243, LBL_body)));
      V v_t_24157 = heff_strAppend(((V)&g_heff_2eemit_2edefBody_str108), heff_strAppend(heff_get(v_i_244, LBL_js), heff_strAppend(((V)&g_heff_2eemit_2edefBody_str109), heff_strAppend(heff_get(v_t_24156, LBL_code), ((V)&g_heff_2eemit_2edefBody_str110)))));
      V v_t_24158 = heff_tag(TAG_Cons, 2, (V[]){v_t_24157, NTAG(TAG_Nil)});
      return heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemit_2edefBody_str111), v_t_24158});
    }
    default: return heff_nomatch(v_t_24150);
    }
  }
  case TAG_EAbandon: {
    V v_t_24159 = heff_get(heff_dup(v_i_244), LBL_lazy);
    switch (heff_tag_of(v_t_24159)) {
    case TAG_True: {
      V v_t_24160 = heff_rec(4, shape_120_200_361_295, (V[]){v_gs_240, heff_dup(g_map_2eempty_get()), v_globalNames_242, NTAG(TAG_Nothing)});
      V v_t_24161 = (g_heff_2eemit_2ebodyF_24s590(v_t_24160, MK_INT(0LL), heff_get(v_d_243, LBL_body)));
      V v_t_24162 = heff_strAppend(((V)&g_heff_2eemit_2edefBody_str112), heff_strAppend(heff_get(v_i_244, LBL_js), heff_strAppend(((V)&g_heff_2eemit_2edefBody_str113), heff_strAppend(v_t_24161, ((V)&g_heff_2eemit_2edefBody_str114)))));
      V v_t_24163 = heff_tag(TAG_Cons, 2, (V[]){v_t_24162, NTAG(TAG_Nil)});
      return heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemit_2edefBody_str115), v_t_24163});
    }
    case TAG_False: {
      V v_t_24164 = heff_rec(4, shape_120_200_361_295, (V[]){v_gs_240, heff_dup(g_map_2eempty_get()), v_globalNames_242, NTAG(TAG_Nothing)});
      V v_t_24165 = heff_tr(g_heff_2eemit_2eexprGo_24s585(v_t_24164, MK_INT(0LL), heff_get(v_d_243, LBL_body)));
      V v_t_24166 = heff_strAppend(((V)&g_heff_2eemit_2edefBody_str116), heff_strAppend(heff_get(v_i_244, LBL_js), heff_strAppend(((V)&g_heff_2eemit_2edefBody_str117), heff_strAppend(heff_get(v_t_24165, LBL_code), ((V)&g_heff_2eemit_2edefBody_str118)))));
      V v_t_24167 = heff_tag(TAG_Cons, 2, (V[]){v_t_24166, NTAG(TAG_Nil)});
      return heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemit_2edefBody_str119), v_t_24167});
    }
    default: return heff_nomatch(v_t_24159);
    }
  }
  case TAG_EFix: {
    V v_ru_24t_245_24EFix = heff_take_reuse_n(v_t_245, 0ULL, 2);
    V v_t_24170 = heff_get(heff_dup(v_i_244), LBL_lazy);
    switch (heff_tag_of(v_t_24170)) {
    case TAG_True: {
      V v_t_24171 = heff_rec(4, shape_120_200_361_295, (V[]){v_gs_240, heff_dup(g_map_2eempty_get()), v_globalNames_242, NTAG(TAG_Nothing)});
      V v_t_24172 = (g_heff_2eemit_2ebodyF_24s590(v_t_24171, MK_INT(0LL), heff_get(v_d_243, LBL_body)));
      V v_t_24173 = heff_strAppend(((V)&g_heff_2eemit_2edefBody_str120), heff_strAppend(heff_get(v_i_244, LBL_js), heff_strAppend(((V)&g_heff_2eemit_2edefBody_str121), heff_strAppend(v_t_24172, ((V)&g_heff_2eemit_2edefBody_str122)))));
      V v_t_24174 = heff_tag_at(v_ru_24t_245_24EFix, TAG_Cons, 2, (V[]){v_t_24173, NTAG(TAG_Nil)});
      return heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemit_2edefBody_str123), v_t_24174});
    }
    case TAG_False: {
      V v_t_24175 = heff_rec(4, shape_120_200_361_295, (V[]){v_gs_240, heff_dup(g_map_2eempty_get()), v_globalNames_242, NTAG(TAG_Nothing)});
      V v_t_24176 = heff_tr(g_heff_2eemit_2eexprGo_24s585(v_t_24175, MK_INT(0LL), heff_get(v_d_243, LBL_body)));
      V v_t_24177 = heff_strAppend(((V)&g_heff_2eemit_2edefBody_str124), heff_strAppend(heff_get(v_i_244, LBL_js), heff_strAppend(((V)&g_heff_2eemit_2edefBody_str125), heff_strAppend(heff_get(v_t_24176, LBL_code), ((V)&g_heff_2eemit_2edefBody_str126)))));
      V v_t_24178 = heff_tag_at(v_ru_24t_245_24EFix, TAG_Cons, 2, (V[]){v_t_24177, NTAG(TAG_Nil)});
      return heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemit_2edefBody_str127), v_t_24178});
    }
    default: return heff_nomatch(v_t_24170);
    }
  }
  default: return heff_nomatch(v_t_245);
  }
}
V g_heff_2eemit_2edefBody_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eemit_2edefBody(a[0], a[1], a[2], a[3], a[4]); heff_drop(a[1]); return r;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[206]; } g_heff_2eemit_2etrampolineStr_str0 = {{0x80000000u, K_STR, 0}, 206, 206, {108, 101, 116, 32, 36, 100, 101, 112, 32, 61, 32, 48, 59, 32, 102, 117, 110, 99, 116, 105, 111, 110, 32, 36, 66, 110, 99, 40, 102, 44, 32, 97, 41, 32, 123, 32, 116, 104, 105, 115, 46, 102, 32, 61, 32, 102, 59, 32, 116, 104, 105, 115, 46, 97, 32, 61, 32, 97, 59, 32, 125, 32, 99, 111, 110, 115, 116, 32, 36, 116, 114, 115, 32, 61, 32, 40, 114, 41, 32, 61, 62, 32, 123, 32, 100, 111, 32, 123, 32, 36, 100, 101, 112, 32, 61, 32, 48, 59, 32, 114, 32, 61, 32, 114, 46, 102, 40, 114, 46, 97, 41, 59, 32, 125, 32, 119, 104, 105, 108, 101, 32, 40, 114, 32, 105, 110, 115, 116, 97, 110, 99, 101, 111, 102, 32, 36, 66, 110, 99, 41, 59, 32, 114, 101, 116, 117, 114, 110, 32, 114, 59, 32, 125, 59, 32, 99, 111, 110, 115, 116, 32, 36, 116, 114, 32, 61, 32, 40, 114, 41, 32, 61, 62, 32, 114, 32, 105, 110, 115, 116, 97, 110, 99, 101, 111, 102, 32, 36, 66, 110, 99, 32, 63, 32, 36, 116, 114, 115, 40, 114, 41, 32, 58, 32, 114, 59}};

static V g_heff_2eemit_2etrampolineStr_val;
static int g_heff_2eemit_2etrampolineStr_st;
static V g_heff_2eemit_2etrampolineStr_init(void) {
  return ((V)&g_heff_2eemit_2etrampolineStr_str0);
}
V g_heff_2eemit_2etrampolineStr_get(void) {
  if (g_heff_2eemit_2etrampolineStr_st == 2) return g_heff_2eemit_2etrampolineStr_val;
  if (g_heff_2eemit_2etrampolineStr_st == 1) heff_fail("defined by itself");
  g_heff_2eemit_2etrampolineStr_st = 1;
  g_heff_2eemit_2etrampolineStr_val = heff_tr(g_heff_2eemit_2etrampolineStr_init());
  g_heff_2eemit_2etrampolineStr_st = 2;
  return g_heff_2eemit_2etrampolineStr_val;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[217]; } g_heff_2eemit_2eextStr_str0 = {{0x80000000u, K_STR, 0}, 217, 217, {99, 111, 110, 115, 116, 32, 36, 101, 120, 116, 32, 61, 32, 40, 118, 41, 32, 61, 62, 32, 116, 121, 112, 101, 111, 102, 32, 118, 32, 61, 61, 61, 32, 34, 102, 117, 110, 99, 116, 105, 111, 110, 34, 32, 63, 32, 40, 120, 41, 32, 61, 62, 32, 36, 101, 120, 116, 40, 36, 116, 114, 40, 118, 40, 120, 41, 41, 41, 32, 58, 32, 118, 32, 33, 61, 61, 32, 110, 117, 108, 108, 32, 38, 38, 32, 116, 121, 112, 101, 111, 102, 32, 118, 32, 61, 61, 61, 32, 34, 111, 98, 106, 101, 99, 116, 34, 32, 38, 38, 32, 33, 65, 114, 114, 97, 121, 46, 105, 115, 65, 114, 114, 97, 121, 40, 118, 41, 32, 38, 38, 32, 33, 40, 34, 36, 34, 32, 105, 110, 32, 118, 41, 32, 63, 32, 79, 98, 106, 101, 99, 116, 46, 102, 114, 111, 109, 69, 110, 116, 114, 105, 101, 115, 40, 79, 98, 106, 101, 99, 116, 46, 101, 110, 116, 114, 105, 101, 115, 40, 118, 41, 46, 109, 97, 112, 40, 40, 91, 108, 44, 32, 120, 93, 41, 32, 61, 62, 32, 91, 108, 44, 32, 36, 101, 120, 116, 40, 120, 41, 93, 41, 41, 32, 58, 32, 118, 59}};

static V g_heff_2eemit_2eextStr_val;
static int g_heff_2eemit_2eextStr_st;
static V g_heff_2eemit_2eextStr_init(void) {
  return ((V)&g_heff_2eemit_2eextStr_str0);
}
V g_heff_2eemit_2eextStr_get(void) {
  if (g_heff_2eemit_2eextStr_st == 2) return g_heff_2eemit_2eextStr_val;
  if (g_heff_2eemit_2eextStr_st == 1) heff_fail("defined by itself");
  g_heff_2eemit_2eextStr_st = 1;
  g_heff_2eemit_2eextStr_val = heff_tr(g_heff_2eemit_2eextStr_init());
  g_heff_2eemit_2eextStr_st = 2;
  return g_heff_2eemit_2eextStr_val;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eemit_2eruntime_str0 = {{0x80000000u, K_STR, 0}, 5, 5, {36, 108, 97, 122, 121}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eemit_2eruntime_str1 = {{0x80000000u, K_STR, 0}, 4, 4, {36, 66, 110, 99}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2eemit_2eruntime_str2 = {{0x80000000u, K_STR, 0}, 6, 6, {36, 102, 111, 114, 99, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eemit_2eruntime_str3 = {{0x80000000u, K_STR, 0}, 4, 4, {36, 116, 114, 40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemit_2eruntime_str4 = {{0x80000000u, K_STR, 0}, 2, 2, {36, 84}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemit_2eruntime_str5 = {{0x80000000u, K_STR, 0}, 2, 2, {36, 70}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[60]; } g_heff_2eemit_2eruntime_str6 = {{0x80000000u, K_STR, 0}, 60, 60, {99, 111, 110, 115, 116, 32, 36, 84, 32, 61, 32, 123, 32, 36, 58, 32, 34, 84, 114, 117, 101, 34, 44, 32, 97, 58, 32, 91, 93, 32, 125, 44, 32, 36, 70, 32, 61, 32, 123, 32, 36, 58, 32, 34, 70, 97, 108, 115, 101, 34, 44, 32, 97, 58, 32, 91, 93, 32, 125, 59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[60]; } g_heff_2eemit_2eruntime_str7 = {{0x80000000u, K_STR, 0}, 60, 60, {99, 111, 110, 115, 116, 32, 36, 84, 32, 61, 32, 123, 32, 36, 58, 32, 34, 84, 114, 117, 101, 34, 44, 32, 97, 58, 32, 91, 93, 32, 125, 44, 32, 36, 70, 32, 61, 32, 123, 32, 36, 58, 32, 34, 70, 97, 108, 115, 101, 34, 44, 32, 97, 58, 32, 91, 93, 32, 125, 59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2eemit_2eruntime_str8 = {{0x80000000u, K_STR, 0}, 8, 8, {36, 97, 98, 97, 110, 100, 111, 110}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[60]; } g_heff_2eemit_2eruntime_str9 = {{0x80000000u, K_STR, 0}, 60, 60, {99, 111, 110, 115, 116, 32, 36, 97, 98, 97, 110, 100, 111, 110, 32, 61, 32, 40, 41, 32, 61, 62, 32, 123, 32, 116, 104, 114, 111, 119, 32, 110, 101, 119, 32, 69, 114, 114, 111, 114, 40, 34, 104, 101, 102, 102, 58, 97, 98, 97, 110, 100, 111, 110, 34, 41, 59, 32, 125, 59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2eemit_2eruntime_str10 = {{0x80000000u, K_STR, 0}, 8, 8, {36, 110, 111, 109, 97, 116, 99, 104}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[87]; } g_heff_2eemit_2eruntime_str11 = {{0x80000000u, K_STR, 0}, 87, 87, {99, 111, 110, 115, 116, 32, 36, 110, 111, 109, 97, 116, 99, 104, 32, 61, 32, 40, 115, 41, 32, 61, 62, 32, 123, 32, 116, 104, 114, 111, 119, 32, 110, 101, 119, 32, 69, 114, 114, 111, 114, 40, 34, 104, 101, 102, 102, 58, 32, 110, 111, 32, 99, 97, 115, 101, 32, 102, 111, 114, 32, 39, 34, 32, 43, 32, 40, 115, 32, 38, 38, 32, 115, 46, 36, 41, 32, 43, 32, 34, 39, 34, 41, 59, 32, 125, 59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2eemit_2eruntime_str12 = {{0x80000000u, K_STR, 0}, 6, 6, {36, 102, 111, 114, 99, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[125]; } g_heff_2eemit_2eruntime_str13 = {{0x80000000u, K_STR, 0}, 125, 125, {99, 111, 110, 115, 116, 32, 36, 102, 111, 114, 99, 101, 32, 61, 32, 40, 102, 41, 32, 61, 62, 32, 123, 32, 105, 102, 32, 40, 102, 46, 36, 109, 32, 33, 61, 61, 32, 117, 110, 100, 101, 102, 105, 110, 101, 100, 41, 32, 114, 101, 116, 117, 114, 110, 32, 102, 46, 36, 109, 59, 32, 99, 111, 110, 115, 116, 32, 118, 32, 61, 32, 36, 116, 114, 40, 102, 40, 123, 32, 36, 58, 32, 34, 77, 107, 85, 110, 105, 116, 34, 44, 32, 97, 58, 32, 91, 93, 32, 125, 41, 41, 59, 32, 102, 46, 36, 109, 32, 61, 32, 118, 59, 32, 114, 101, 116, 117, 114, 110, 32, 118, 59, 32, 125, 59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eemit_2eruntime_str14 = {{0x80000000u, K_STR, 0}, 5, 5, {36, 108, 97, 122, 121}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[243]; } g_heff_2eemit_2eruntime_str15 = {{0x80000000u, K_STR, 0}, 243, 243, {99, 111, 110, 115, 116, 32, 36, 108, 97, 122, 121, 32, 61, 32, 40, 102, 41, 32, 61, 62, 32, 123, 32, 108, 101, 116, 32, 115, 116, 97, 116, 101, 32, 61, 32, 48, 44, 32, 118, 59, 32, 114, 101, 116, 117, 114, 110, 32, 40, 41, 32, 61, 62, 32, 123, 32, 105, 102, 32, 40, 115, 116, 97, 116, 101, 32, 61, 61, 61, 32, 50, 41, 32, 114, 101, 116, 117, 114, 110, 32, 118, 59, 32, 105, 102, 32, 40, 115, 116, 97, 116, 101, 32, 61, 61, 61, 32, 49, 41, 32, 116, 104, 114, 111, 119, 32, 110, 101, 119, 32, 69, 114, 114, 111, 114, 40, 34, 104, 101, 102, 102, 58, 32, 100, 101, 102, 105, 110, 101, 100, 32, 98, 121, 32, 105, 116, 115, 101, 108, 102, 34, 41, 59, 32, 115, 116, 97, 116, 101, 32, 61, 32, 49, 59, 32, 116, 114, 121, 32, 123, 32, 118, 32, 61, 32, 36, 116, 114, 40, 102, 40, 41, 41, 59, 32, 115, 116, 97, 116, 101, 32, 61, 32, 50, 59, 32, 114, 101, 116, 117, 114, 110, 32, 118, 59, 32, 125, 32, 102, 105, 110, 97, 108, 108, 121, 32, 123, 32, 105, 102, 32, 40, 115, 116, 97, 116, 101, 32, 61, 61, 61, 32, 49, 41, 32, 115, 116, 97, 116, 101, 32, 61, 32, 48, 59, 32, 125, 32, 125, 59, 32, 125, 59}};
V g_heff_2eemit_2eruntime_lam0(V self, V *args);
Clo g_heff_2eemit_2eruntime_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemit_2eruntime_entry, 1, 0};

V g_heff_2eemit_2eruntime(V v_code_240) {
top: ;
  V v_t_241 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemit_2eruntime_str0), NTAG(TAG_Nil)});
  V v_t_242 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemit_2eruntime_str1), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemit_2eruntime_str2), v_t_241})});
  V v_t_246 = ({ V a_0 = heff_clo(g_heff_2eemit_2eruntime_lam0, 1, 1, (V[]){heff_dup(v_code_240)}); V b_1 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemit_2eruntime_str3), v_t_242}); V r_ = (g_prelude_2eany(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_247;
  switch (heff_tag_of(v_t_246)) {
  case TAG_True: {
    v_t_247 = heff_tag(TAG_Just, 1, (V[]){heff_dup(g_heff_2eemit_2etrampolineStr_get())});
    break;
  }
  case TAG_False: {
    v_t_247 = NTAG(TAG_Nothing);
    break;
  }
  default: heff_nomatch(v_t_246);
  }
  V v_x3_248 = (g_prelude_2eindexFrom(((V)&g_heff_2eemit_2eruntime_str4), heff_dup(v_code_240), MK_INT(0LL)));
  V v_t_2412;
  switch (heff_tag_of(v_x3_248)) {
  case TAG_Nothing: {
    V v_x3_249 = (g_prelude_2eindexFrom(((V)&g_heff_2eemit_2eruntime_str5), heff_dup(v_code_240), MK_INT(0LL)));
    switch (heff_tag_of(v_x3_249)) {
    case TAG_Nothing: {
      v_t_2412 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Just: {
      V v_ru_24x3_249_24Just = heff_take_reuse_n(v_x3_249, 0ULL, 1);
      v_t_2412 = heff_tag_at(v_ru_24x3_249_24Just, TAG_Just, 1, (V[]){((V)&g_heff_2eemit_2eruntime_str6)});
      break;
    }
    default: heff_nomatch(v_x3_249);
    }
    break;
  }
  case TAG_Just: {
    V v_ru_24x3_248_24Just = heff_take_reuse_n(v_x3_248, 0ULL, 1);
    v_t_2412 = heff_tag_at(v_ru_24x3_248_24Just, TAG_Just, 1, (V[]){((V)&g_heff_2eemit_2eruntime_str7)});
    break;
  }
  default: heff_nomatch(v_x3_248);
  }
  V v_x3_2413 = (g_prelude_2eindexFrom(((V)&g_heff_2eemit_2eruntime_str8), heff_dup(v_code_240), MK_INT(0LL)));
  V v_t_2415;
  switch (heff_tag_of(v_x3_2413)) {
  case TAG_Nothing: {
    v_t_2415 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Just: {
    V v_ru_24x3_2413_24Just = heff_take_reuse_n(v_x3_2413, 0ULL, 1);
    v_t_2415 = heff_tag_at(v_ru_24x3_2413_24Just, TAG_Just, 1, (V[]){((V)&g_heff_2eemit_2eruntime_str9)});
    break;
  }
  default: heff_nomatch(v_x3_2413);
  }
  V v_x3_2416 = (g_prelude_2eindexFrom(((V)&g_heff_2eemit_2eruntime_str10), heff_dup(v_code_240), MK_INT(0LL)));
  V v_t_2418;
  switch (heff_tag_of(v_x3_2416)) {
  case TAG_Nothing: {
    v_t_2418 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Just: {
    V v_ru_24x3_2416_24Just = heff_take_reuse_n(v_x3_2416, 0ULL, 1);
    v_t_2418 = heff_tag_at(v_ru_24x3_2416_24Just, TAG_Just, 1, (V[]){((V)&g_heff_2eemit_2eruntime_str11)});
    break;
  }
  default: heff_nomatch(v_x3_2416);
  }
  V v_x3_2419 = (g_prelude_2eindexFrom(((V)&g_heff_2eemit_2eruntime_str12), heff_dup(v_code_240), MK_INT(0LL)));
  V v_t_2421;
  switch (heff_tag_of(v_x3_2419)) {
  case TAG_Nothing: {
    v_t_2421 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Just: {
    V v_ru_24x3_2419_24Just = heff_take_reuse_n(v_x3_2419, 0ULL, 1);
    v_t_2421 = heff_tag_at(v_ru_24x3_2419_24Just, TAG_Just, 1, (V[]){((V)&g_heff_2eemit_2eruntime_str13)});
    break;
  }
  default: heff_nomatch(v_x3_2419);
  }
  V v_x3_2422 = (g_prelude_2eindexFrom(((V)&g_heff_2eemit_2eruntime_str14), v_code_240, MK_INT(0LL)));
  V v_t_2424;
  switch (heff_tag_of(v_x3_2422)) {
  case TAG_Nothing: {
    v_t_2424 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Just: {
    V v_ru_24x3_2422_24Just = heff_take_reuse_n(v_x3_2422, 0ULL, 1);
    v_t_2424 = heff_tag_at(v_ru_24x3_2422_24Just, TAG_Just, 1, (V[]){((V)&g_heff_2eemit_2eruntime_str15)});
    break;
  }
  default: heff_nomatch(v_x3_2422);
  }
  V v_t_2425 = heff_tag(TAG_Cons, 2, (V[]){v_t_2424, NTAG(TAG_Nil)});
  V v_t_2426 = heff_tag(TAG_Cons, 2, (V[]){v_t_2418, heff_tag(TAG_Cons, 2, (V[]){v_t_2421, v_t_2425})});
  V v_t_2427 = heff_tag(TAG_Cons, 2, (V[]){v_t_2412, heff_tag(TAG_Cons, 2, (V[]){v_t_2415, v_t_2426})});
  HEFF_LAST return g_heff_2eemit_2ecatMaybesL(heff_tag(TAG_Cons, 2, (V[]){v_t_247, v_t_2427}));
}
V g_heff_2eemit_2eruntime_entry(V self, V *a) {
  (void)self;
  return g_heff_2eemit_2eruntime(a[0]);
}
V g_heff_2eemit_2eruntime_lam0(V self, V *args) {
  V v_k_243 = args[0];
  V v_code_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x3_244 = (g_prelude_2eindexFrom(v_k_243, v_code_240, MK_INT(0LL)));
  switch (heff_tag_of(v_x3_244)) {
  case TAG_Nothing: {
    return NTAG(TAG_False);
  }
  case TAG_Just: {
    heff_take_n(v_x3_244, 0ULL, 1);
    return NTAG(TAG_True);
  }
  default: return heff_nomatch(v_x3_244);
  }
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2euncurryGo_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eemit_2euncurryGo_str1 = {{0x80000000u, K_STR, 0}, 5, 5, {41, 32, 61, 62, 32}};
Clo g_heff_2eemit_2euncurryGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemit_2euncurryGo_entry, 2, 0};

V g_heff_2eemit_2euncurryGo(V v_ps_240, V v_s_241) {
top: ;
  V v_t_242 = heff_strEq(heff_strSlice(heff_dup(v_s_241), MK_INT(0LL), MK_INT(1LL)), ((V)&g_heff_2eemit_2euncurryGo_str0));
  switch (heff_tag_of(v_t_242)) {
  case TAG_True: {
    V v_t_243 = heff_strSlice(heff_dup(v_s_241), MK_INT(1LL), heff_strLength(heff_dup(v_s_241)));
    V v_t_244 = (g_prelude_2eindexFrom(((V)&g_heff_2eemit_2euncurryGo_str1), v_t_243, MK_INT(0LL)));
    switch (heff_tag_of(v_t_244)) {
    case TAG_Nothing: {
      V v_t_245 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), v_ps_240));
      return heff_rec(2, shape_232_28, (V[]){v_t_245, v_s_241});
    }
    case TAG_Just: {
      V v_i_246 = heff_field(v_t_244, 0);
      heff_take_n(v_t_244, 1ULL, 1);
      V v_t_247 = heff_strSlice(heff_dup(v_s_241), MK_INT(1LL), heff_strLength(heff_dup(v_s_241)));
      V v_t_248 = (g_heff_2eemit_2eisIdent(heff_strSlice(v_t_247, MK_INT(0LL), heff_dup(v_i_246))));
      switch (heff_tag_of(v_t_248)) {
      case TAG_True: {
        V v_t_249 = heff_strSlice(heff_dup(v_s_241), MK_INT(1LL), heff_strLength(heff_dup(v_s_241)));
        V v_t_2410 = heff_tag(TAG_Cons, 2, (V[]){heff_strSlice(v_t_249, MK_INT(0LL), heff_dup(v_i_246)), v_ps_240});
        V v_t_2411 = heff_strSlice(heff_dup(v_s_241), MK_INT(1LL), heff_strLength(heff_dup(v_s_241)));
        V v_t_2412 = heff_intSub(heff_strLength(v_s_241), MK_INT(1LL));
        V v_t_2413 = heff_strSlice(v_t_2411, heff_intAdd(v_i_246, MK_INT(5LL)), v_t_2412);
        V t_0 = v_t_2410;
        V t_1 = v_t_2413;
        v_ps_240 = t_0;
        v_s_241 = t_1;
        goto top;
      }
      case TAG_False: {
        heff_drop(v_i_246);
        V v_t_2414 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), v_ps_240));
        return heff_rec(2, shape_232_28, (V[]){v_t_2414, v_s_241});
      }
      default: return heff_nomatch(v_t_248);
      }
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  case TAG_False: {
    V v_t_2415 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), v_ps_240));
    return heff_rec(2, shape_232_28, (V[]){v_t_2415, v_s_241});
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2eemit_2euncurryGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2eemit_2euncurryGo(a[0], a[1]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2eprimUses_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {36}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemit_2eprimUses_str1 = {{0x80000000u, K_STR, 0}, 2, 2, {36, 99}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2eprimUses_str2 = {{0x80000000u, K_STR, 0}, 1, 1, {36}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2eprimUses_str3 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2eprimUses_str4 = {{0x80000000u, K_STR, 0}, 1, 1, {36}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2eprimUses_str5 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
Clo g_heff_2eemit_2eprimUses_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemit_2eprimUses_entry, 2, 0};

V g_heff_2eemit_2eprimUses(V v_m_240, V v_e_241) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_EVar: {
    return v_m_240;
  }
  case TAG_EGlobal: {
    return v_m_240;
  }
  case TAG_ELam: {
    V v_b_245 = heff_field(v_e_241, 1);
    V t_0 = v_m_240;
    V t_1 = v_b_245;
    v_m_240 = t_0;
    v_e_241 = t_1;
    goto top;
  }
  case TAG_EApp: {
    V v_f_246 = heff_field(v_e_241, 0);
    V v_as_247 = heff_field(v_e_241, 1);
    V v_t_248 = (g_heff_2eemit_2eprimUses(v_m_240, v_f_246));
    return (g_prelude_2efoldl(((V)&g_heff_2eemit_2eprimUses_clo), v_t_248, v_as_247));
  }
  case TAG_ELet: {
    V v_e1_2410 = heff_field(v_e_241, 1);
    V v_b_2411 = heff_field(v_e_241, 2);
    V v_t_2412 = (g_heff_2eemit_2eprimUses(v_m_240, v_e1_2410));
    V t_0 = v_t_2412;
    V t_1 = v_b_2411;
    v_m_240 = t_0;
    v_e_241 = t_1;
    goto top;
  }
  case TAG_ERecord: {
    V v_fs_2413 = heff_field(v_e_241, 0);
    HEFF_LAST return g_prelude_2efoldl_24s602(v_m_240, v_fs_2413);
  }
  case TAG_EProj: {
    V v_e2_2414 = heff_field(v_e_241, 0);
    V t_0 = v_m_240;
    V t_1 = v_e2_2414;
    v_m_240 = t_0;
    v_e_241 = t_1;
    goto top;
  }
  case TAG_ETag: {
    V v_as_2417 = heff_field(v_e_241, 1);
    return (g_prelude_2efoldl(((V)&g_heff_2eemit_2eprimUses_clo), v_m_240, v_as_2417));
  }
  case TAG_EMatch: {
    V v_s_2418 = heff_field(v_e_241, 0);
    V v_arms_2419 = heff_field(v_e_241, 1);
    V v_t_2420 = (g_heff_2eemit_2eprimUses(v_m_240, v_s_2418));
    HEFF_LAST return g_prelude_2efoldl_24s603(v_t_2420, v_arms_2419);
  }
  case TAG_EPrim: {
    V v_p_2421 = heff_field(v_e_241, 0);
    V v_t_2422 = heff_strAppend(((V)&g_heff_2eemit_2eprimUses_str0), heff_strAppend(heff_dup(v_p_2421), ((V)&g_heff_2eemit_2eprimUses_str1)));
    return (g_map_2einsert_24s7(v_t_2422, NTAG(TAG_MkUnit), v_m_240));
  }
  case TAG_EPrimCall: {
    V v_p_2423 = heff_field(v_e_241, 0);
    V v_as_2424 = heff_field(v_e_241, 1);
    V v_t_2438;
    switch (heff_tag_of(v_as_2424)) {
    case TAG_Nil: {
      V v_t_2425 = heff_strAppend(((V)&g_heff_2eemit_2eprimUses_str2), heff_strAppend(heff_dup(v_p_2423), ((V)&g_heff_2eemit_2eprimUses_str3)));
      v_t_2438 = (g_map_2einsert_24s7(v_t_2425, NTAG(TAG_MkUnit), v_m_240));
      break;
    }
    case TAG_Cons: {
      V v_it2_2427 = heff_field(v_as_2424, 1);
      V v_t_2436;
      switch (heff_tag_of(v_it2_2427)) {
      case TAG_Nil: {
        V v_x3_2428 = (g_heff_2eemit_2eprimUnary(heff_dup(v_p_2423)));
        switch (heff_tag_of(v_x3_2428)) {
        case TAG_Nothing: {
          v_t_2436 = NTAG(TAG_True);
          break;
        }
        case TAG_Just: {
          heff_take_n(v_x3_2428, 0ULL, 1);
          v_t_2436 = NTAG(TAG_False);
          break;
        }
        default: heff_nomatch(v_x3_2428);
        }
        break;
      }
      case TAG_Cons: {
        V v_it22_2431 = heff_field(v_it2_2427, 1);
        switch (heff_tag_of(v_it22_2431)) {
        case TAG_Nil: {
          V v_x3_2432 = (g_heff_2eemit_2eprimOp(heff_dup(v_p_2423)));
          switch (heff_tag_of(v_x3_2432)) {
          case TAG_Nothing: {
            v_t_2436 = NTAG(TAG_True);
            break;
          }
          case TAG_Just: {
            heff_take_n(v_x3_2432, 0ULL, 1);
            v_t_2436 = NTAG(TAG_False);
            break;
          }
          default: heff_nomatch(v_x3_2432);
          }
          break;
        }
        case TAG_Cons: {
          v_t_2436 = NTAG(TAG_True);
          break;
        }
        default: heff_nomatch(v_it22_2431);
        }
        break;
      }
      default: heff_nomatch(v_it2_2427);
      }
      switch (heff_tag_of(v_t_2436)) {
      case TAG_True: {
        V v_t_2437 = heff_strAppend(((V)&g_heff_2eemit_2eprimUses_str4), heff_strAppend(heff_dup(v_p_2423), ((V)&g_heff_2eemit_2eprimUses_str5)));
        v_t_2438 = (g_map_2einsert_24s7(v_t_2437, NTAG(TAG_MkUnit), v_m_240));
        break;
      }
      case TAG_False: {
        v_t_2438 = v_m_240;
        break;
      }
      default: heff_nomatch(v_t_2436);
      }
      break;
    }
    default: heff_nomatch(v_as_2424);
    }
    return (g_prelude_2efoldl(((V)&g_heff_2eemit_2eprimUses_clo), v_t_2438, v_as_2424));
  }
  case TAG_ECall: {
    V v_as_2440 = heff_field(v_e_241, 1);
    return (g_prelude_2efoldl(((V)&g_heff_2eemit_2eprimUses_clo), v_m_240, v_as_2440));
  }
  case TAG_EInt: {
    return v_m_240;
  }
  case TAG_EFloat: {
    return v_m_240;
  }
  case TAG_EStr: {
    return v_m_240;
  }
  case TAG_EAbandon: {
    return v_m_240;
  }
  case TAG_EFix: {
    return v_m_240;
  }
  default: return heff_nomatch(v_e_241);
  }
}
V g_heff_2eemit_2eprimUses_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eemit_2eprimUses(a[0], a[1]); heff_drop(a[1]); return r;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2eprimHelperU_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {36}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2eprimHelperU_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2eprimHelperU_str2 = {{0x80000000u, K_STR, 0}, 1, 1, {36}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemit_2eprimHelperU_str3 = {{0x80000000u, K_STR, 0}, 2, 2, {36, 99}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2eprimHelperU_str4 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2eemit_2eprimHelperU_str5 = {{0x80000000u, K_STR, 0}, 7, 7, {99, 111, 110, 115, 116, 32, 36}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eemit_2eprimHelperU_str6 = {{0x80000000u, K_STR, 0}, 4, 4, {32, 61, 32, 40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eemit_2eprimHelperU_str7 = {{0x80000000u, K_STR, 0}, 5, 5, {41, 32, 61, 62, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2eprimHelperU_str8 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2eprimHelperU_str9 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2eemit_2eprimHelperU_str10 = {{0x80000000u, K_STR, 0}, 7, 7, {99, 111, 110, 115, 116, 32, 36}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eemit_2eprimHelperU_str11 = {{0x80000000u, K_STR, 0}, 4, 4, {32, 61, 32, 40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eemit_2eprimHelperU_str12 = {{0x80000000u, K_STR, 0}, 5, 5, {41, 32, 61, 62, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2eprimHelperU_str13 = {{0x80000000u, K_STR, 0}, 1, 1, {59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2eprimHelperU_str14 = {{0x80000000u, K_STR, 0}, 1, 1, {36}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemit_2eprimHelperU_str15 = {{0x80000000u, K_STR, 0}, 2, 2, {36, 99}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2eprimHelperU_str16 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2eprimHelperU_str17 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[7]; } g_heff_2eemit_2eprimHelperU_str18 = {{0x80000000u, K_STR, 0}, 7, 7, {99, 111, 110, 115, 116, 32, 36}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eemit_2eprimHelperU_str19 = {{0x80000000u, K_STR, 0}, 5, 5, {36, 99, 32, 61, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2eprimHelperU_str20 = {{0x80000000u, K_STR, 0}, 1, 1, {36}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2eprimHelperU_str21 = {{0x80000000u, K_STR, 0}, 1, 1, {40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemit_2eprimHelperU_str22 = {{0x80000000u, K_STR, 0}, 2, 2, {41, 59}};
Clo g_heff_2eemit_2eprimHelperU_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemit_2eprimHelperU_entry, 3, 0};

V g_heff_2eemit_2eprimHelperU(V v_uses_240, V v_p_241, V v_u_242) {
top: ;
  V v_t_243 = heff_strAppend(((V)&g_heff_2eemit_2eprimHelperU_str0), heff_strAppend(heff_dup(v_p_241), ((V)&g_heff_2eemit_2eprimHelperU_str1)));
  V v_x3_244 = (g_map_2elookup_24s9(v_t_243, v_uses_240));
  V v_t_2419;
  switch (heff_tag_of(v_x3_244)) {
  case TAG_Nothing: {
    V v_t_245 = heff_strAppend(((V)&g_heff_2eemit_2eprimHelperU_str2), heff_strAppend(heff_dup(v_p_241), ((V)&g_heff_2eemit_2eprimHelperU_str3)));
    V v_x3_246 = (g_map_2elookup_24s9(v_t_245, v_uses_240));
    switch (heff_tag_of(v_x3_246)) {
    case TAG_Nothing: {
      v_t_2419 = NTAG(TAG_Nil);
      break;
    }
    case TAG_Just: {
      heff_take_n(v_x3_246, 0ULL, 1);
      V v_t_248 = heff_get(heff_dup(v_u_242), LBL_params);
      V v_t_2411;
      switch (heff_tag_of(v_t_248)) {
      case TAG_Nil: {
        v_t_2411 = ((V)&g_heff_2eemit_2eprimHelperU_str4);
        break;
      }
      case TAG_Cons: {
        V v_x_249 = heff_field(v_t_248, 0);
        V v_xs_2410 = heff_field(v_t_248, 1);
        heff_take_n(v_t_248, 3ULL, 2);
        v_t_2411 = ({ V a_0 = v_x_249; V a_1 = v_xs_2410; V r_ = (g_prelude_2efoldl_24s45(a_0, a_1)); heff_drop(v_xs_2410); r_; });
        break;
      }
      default: heff_nomatch(v_t_248);
      }
      V v_t_2412 = heff_strAppend(((V)&g_heff_2eemit_2eprimHelperU_str5), heff_strAppend(heff_dup(v_p_241), heff_strAppend(((V)&g_heff_2eemit_2eprimHelperU_str6), heff_strAppend(v_t_2411, heff_strAppend(((V)&g_heff_2eemit_2eprimHelperU_str7), heff_strAppend(heff_get(heff_dup(v_u_242), LBL_body), ((V)&g_heff_2eemit_2eprimHelperU_str8)))))));
      v_t_2419 = heff_tag(TAG_Cons, 2, (V[]){v_t_2412, NTAG(TAG_Nil)});
      break;
    }
    default: heff_nomatch(v_x3_246);
    }
    break;
  }
  case TAG_Just: {
    heff_take_n(v_x3_244, 0ULL, 1);
    V v_t_2414 = heff_get(heff_dup(v_u_242), LBL_params);
    V v_t_2417;
    switch (heff_tag_of(v_t_2414)) {
    case TAG_Nil: {
      v_t_2417 = ((V)&g_heff_2eemit_2eprimHelperU_str9);
      break;
    }
    case TAG_Cons: {
      V v_x_2415 = heff_field(v_t_2414, 0);
      V v_xs_2416 = heff_field(v_t_2414, 1);
      heff_take_n(v_t_2414, 3ULL, 2);
      v_t_2417 = ({ V a_0 = v_x_2415; V a_1 = v_xs_2416; V r_ = (g_prelude_2efoldl_24s45(a_0, a_1)); heff_drop(v_xs_2416); r_; });
      break;
    }
    default: heff_nomatch(v_t_2414);
    }
    V v_t_2418 = heff_strAppend(((V)&g_heff_2eemit_2eprimHelperU_str10), heff_strAppend(heff_dup(v_p_241), heff_strAppend(((V)&g_heff_2eemit_2eprimHelperU_str11), heff_strAppend(v_t_2417, heff_strAppend(((V)&g_heff_2eemit_2eprimHelperU_str12), heff_strAppend(heff_get(heff_dup(v_u_242), LBL_body), ((V)&g_heff_2eemit_2eprimHelperU_str13)))))));
    v_t_2419 = heff_tag(TAG_Cons, 2, (V[]){v_t_2418, NTAG(TAG_Nil)});
    break;
  }
  default: heff_nomatch(v_x3_244);
  }
  V v_t_2420 = heff_strAppend(((V)&g_heff_2eemit_2eprimHelperU_str14), heff_strAppend(heff_dup(v_p_241), ((V)&g_heff_2eemit_2eprimHelperU_str15)));
  V v_x3_2421 = (g_map_2elookup_24s9(v_t_2420, v_uses_240));
  V v_t_2432;
  switch (heff_tag_of(v_x3_2421)) {
  case TAG_Nothing: {
    heff_drop(v_p_241);
    heff_drop(v_u_242);
    v_t_2432 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    heff_take_n(v_x3_2421, 0ULL, 1);
    V v_x2_2423 = (g_prelude_2emap_24s577(heff_get(heff_dup(v_u_242), LBL_params)));
    V v_t_2426;
    switch (heff_tag_of(v_x2_2423)) {
    case TAG_Nil: {
      v_t_2426 = ((V)&g_heff_2eemit_2eprimHelperU_str16);
      break;
    }
    case TAG_Cons: {
      V v_x_2424 = heff_field(v_x2_2423, 0);
      V v_xs_2425 = heff_field(v_x2_2423, 1);
      heff_take_n(v_x2_2423, 3ULL, 2);
      v_t_2426 = ({ V a_0 = v_x_2424; V a_1 = v_xs_2425; V r_ = (g_prelude_2efoldl_24s46(a_0, a_1)); heff_drop(v_xs_2425); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2423);
    }
    V v_t_2427 = heff_get(v_u_242, LBL_params);
    V v_t_2430;
    switch (heff_tag_of(v_t_2427)) {
    case TAG_Nil: {
      v_t_2430 = ((V)&g_heff_2eemit_2eprimHelperU_str17);
      break;
    }
    case TAG_Cons: {
      V v_x_2428 = heff_field(v_t_2427, 0);
      V v_xs_2429 = heff_field(v_t_2427, 1);
      heff_take_n(v_t_2427, 3ULL, 2);
      v_t_2430 = ({ V a_0 = v_x_2428; V a_1 = v_xs_2429; V r_ = (g_prelude_2efoldl_24s45(a_0, a_1)); heff_drop(v_xs_2429); r_; });
      break;
    }
    default: heff_nomatch(v_t_2427);
    }
    V v_t_2431 = heff_strAppend(((V)&g_heff_2eemit_2eprimHelperU_str18), heff_strAppend(heff_dup(v_p_241), heff_strAppend(((V)&g_heff_2eemit_2eprimHelperU_str19), heff_strAppend(v_t_2426, heff_strAppend(((V)&g_heff_2eemit_2eprimHelperU_str20), heff_strAppend(v_p_241, heff_strAppend(((V)&g_heff_2eemit_2eprimHelperU_str21), heff_strAppend(v_t_2430, ((V)&g_heff_2eemit_2eprimHelperU_str22)))))))));
    v_t_2432 = heff_tag(TAG_Cons, 2, (V[]){v_t_2431, NTAG(TAG_Nil)});
    break;
  }
  default: heff_nomatch(v_x3_2421);
  }
  return (g_prelude_2econcatList(v_t_2419, v_t_2432));
}
V g_heff_2eemit_2eprimHelperU_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eemit_2eprimHelperU(a[0], a[1], a[2]); heff_drop(a[0]); return r;
}
V g_heff_2eemit_2eprimHelpers_lam0(V self, V *args);
Clo g_heff_2eemit_2eprimHelpers_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemit_2eprimHelpers_entry, 1, 0};

V g_heff_2eemit_2eprimHelpers(V v_defs_240) {
top: ;
  V v_xs_241 = heff_dup(g_heff_2eprims_2eallPrims_get());
  V v_t_242 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), v_xs_241));
  return ({ V a_0 = heff_clo(g_heff_2eemit_2eprimHelpers_lam0, 2, 1, (V[]){heff_dup(v_defs_240)}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_242; V r_ = (g_prelude_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_242); r_; });
}
V g_heff_2eemit_2eprimHelpers_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eemit_2eprimHelpers(a[0]); heff_drop(a[0]); return r;
}
V g_heff_2eemit_2eprimHelpers_lam0(V self, V *args) {
  V v_acc_243 = args[0];
  V v_x_244 = args[1];
  V v_defs_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_uses_245 = ({ V a_0 = heff_dup(g_map_2eempty_get()); V a_1 = v_defs_240; V r_ = (g_prelude_2efoldl_24s604(a_0, a_1)); heff_drop(v_defs_240); r_; });
  V v_t_249;
  switch (heff_tag_of(v_x_244)) {
  case TAG_MkPair: {
    V v_p_246 = heff_field(v_x_244, 0);
    V v_i_247 = heff_field(v_x_244, 1);
    heff_take_n(v_x_244, 3ULL, 2);
    V v_t_248 = (g_heff_2eemit_2euncurryGo(NTAG(TAG_Nil), heff_get(v_i_247, LBL_js)));
    v_t_249 = ({ V a_0 = v_uses_245; V a_1 = v_p_246; V a_2 = v_t_248; V r_ = (g_heff_2eemit_2eprimHelperU(a_0, a_1, a_2)); heff_drop(v_uses_245); r_; });
    break;
  }
  default: heff_nomatch(v_x_244);
  }
  return (g_prelude_2econcatList(v_t_249, v_acc_243));
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2ejsPick_str0 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2ejsPick_str1 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2ejsPick_str2 = {{0x80000000u, K_STR, 0}, 1, 1, {120}};
V g_heff_2eemit_2ejsPick_lam0(V self, V *args);
Clo g_heff_2eemit_2ejsPick_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemit_2ejsPick_entry, 3, 0};

V g_heff_2eemit_2ejsPick(V v_shorts_240, V v_key_241, V v_s_242) {
top: ;
  V v_xs_244 = (g_prelude_2efilter(heff_clo(g_heff_2eemit_2ejsPick_lam0, 1, 1, (V[]){heff_dup(v_s_242)}), v_shorts_240));
  V v_a_245 = ({ V a_0 = MK_INT(0LL); V a_1 = v_xs_244; V r_ = (g_prelude_2efoldl_24s1(a_0, a_1)); heff_drop(v_xs_244); r_; });
  V v_t_246 = heff_intLt(MK_INT(1LL), v_a_245);
  switch (heff_tag_of(v_t_246)) {
  case TAG_True: {
    heff_drop(v_s_242);
    V v_t_247 = heff_intSub(heff_strLength(heff_dup(v_key_241)), MK_INT(1LL));
    V v_t_248 = (g_heff_2eemit_2elastDotFrom(heff_dup(v_key_241), v_t_247));
    V v_t_249 = (g_heff_2eemit_2espellAt(v_key_241, v_t_248));
    V v_s_2410 = (g_heff_2eemit_2esafeChars(v_t_249, MK_INT(0LL), ((V)&g_heff_2eemit_2ejsPick_str0)));
    V v_t_2411 = heff_strEq(heff_dup(v_s_2410), ((V)&g_heff_2eemit_2ejsPick_str1));
    V v_t_2412;
    switch (heff_tag_of(v_t_2411)) {
    case TAG_True: {
      heff_drop(v_s_2410);
      v_t_2412 = ((V)&g_heff_2eemit_2ejsPick_str2);
      break;
    }
    case TAG_False: {
      v_t_2412 = v_s_2410;
      break;
    }
    default: heff_nomatch(v_t_2411);
    }
    return (g_heff_2eemit_2esafeRes(v_t_2412));
  }
  case TAG_False: {
    heff_drop(v_key_241);
    return v_s_242;
  }
  default: return heff_nomatch(v_t_246);
  }
}
V g_heff_2eemit_2ejsPick_entry(V self, V *a) {
  (void)self;
  return g_heff_2eemit_2ejsPick(a[0], a[1], a[2]);
}
V g_heff_2eemit_2ejsPick_lam0(V self, V *args) {
  V v_t_243 = args[0];
  V v_s_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return heff_strEq(v_t_243, v_s_242);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2ejsNameOf_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {46}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2ejsNameOf_str1 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2ejsNameOf_str2 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2ejsNameOf_str3 = {{0x80000000u, K_STR, 0}, 1, 1, {120}};
Clo g_heff_2eemit_2ejsNameOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemit_2ejsNameOf_entry, 2, 0};

V g_heff_2eemit_2ejsNameOf(V v_shorts_240, V v_key_241) {
top: ;
  V v_xs_242 = (g_prelude_2esplitFrom(((V)&g_heff_2eemit_2ejsNameOf_str0), heff_dup(v_key_241), MK_INT(0LL), NTAG(TAG_Nil)));
  V v_x1_243 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), v_xs_242));
  V v_x2_246;
  switch (heff_tag_of(v_x1_243)) {
  case TAG_Nil: {
    v_x2_246 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x1_243, 0);
    heff_take_n(v_x1_243, 1ULL, 2);
    v_x2_246 = heff_tag(TAG_Just, 1, (V[]){v_x_244});
    break;
  }
  default: heff_nomatch(v_x1_243);
  }
  V v_x0_248;
  switch (heff_tag_of(v_x2_246)) {
  case TAG_Nothing: {
    v_x0_248 = heff_dup(v_key_241);
    break;
  }
  case TAG_Just: {
    V v_x_247 = heff_field(v_x2_246, 0);
    heff_take_n(v_x2_246, 1ULL, 1);
    v_x0_248 = v_x_247;
    break;
  }
  default: heff_nomatch(v_x2_246);
  }
  V v_t_249 = heff_intSub(heff_strLength(heff_dup(v_x0_248)), MK_INT(1LL));
  V v_t_2410 = (g_heff_2eemit_2elastDotFrom(heff_dup(v_x0_248), v_t_249));
  V v_t_2411 = (g_heff_2eemit_2espellAt(v_x0_248, v_t_2410));
  V v_s_2412 = (g_heff_2eemit_2esafeChars(v_t_2411, MK_INT(0LL), ((V)&g_heff_2eemit_2ejsNameOf_str1)));
  V v_t_2413 = heff_strEq(heff_dup(v_s_2412), ((V)&g_heff_2eemit_2ejsNameOf_str2));
  V v_t_2414;
  switch (heff_tag_of(v_t_2413)) {
  case TAG_True: {
    heff_drop(v_s_2412);
    v_t_2414 = ((V)&g_heff_2eemit_2ejsNameOf_str3);
    break;
  }
  case TAG_False: {
    v_t_2414 = v_s_2412;
    break;
  }
  default: heff_nomatch(v_t_2413);
  }
  V v_t_2415 = (g_heff_2eemit_2esafeRes(v_t_2414));
  return (g_heff_2eemit_2ejsPick(v_shorts_240, v_key_241, v_t_2415));
}
V g_heff_2eemit_2ejsNameOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2eemit_2ejsNameOf(a[0], a[1]);
}
V g_heff_2eemit_2elazyOf_lam0(V self, V *args);
Clo g_heff_2eemit_2elazyOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemit_2elazyOf_entry, 4, 0};

V g_heff_2eemit_2elazyOf(V v_acc_240, V v_key_241, V v_b_242, V v_ar_243) {
top: ;
  V v_t_244 = heff_intEq(v_ar_243, MK_INT(0LL));
  switch (heff_tag_of(v_t_244)) {
  case TAG_True: {
    V v_t_2433;
    switch (heff_tag_of(v_b_242)) {
    case TAG_EVar: {
      v_t_2433 = NTAG(TAG_True);
      break;
    }
    case TAG_EGlobal: {
      v_t_2433 = NTAG(TAG_True);
      break;
    }
    case TAG_ELam: {
      v_t_2433 = NTAG(TAG_True);
      break;
    }
    case TAG_EApp: {
      v_t_2433 = NTAG(TAG_False);
      break;
    }
    case TAG_ELet: {
      v_t_2433 = NTAG(TAG_False);
      break;
    }
    case TAG_ERecord: {
      V v_fs_2414 = heff_dup(heff_field(v_b_242, 0));
      V v_t_2415 = (g_prelude_2emap_24s511(v_fs_2414));
      v_t_2433 = ({ V a_0 = v_t_2415; V r_ = (g_heff_2eir_2eallI(a_0)); heff_drop(v_t_2415); r_; });
      break;
    }
    case TAG_EProj: {
      v_t_2433 = NTAG(TAG_False);
      break;
    }
    case TAG_ETag: {
      V v_as_2419 = heff_dup(heff_field(v_b_242, 1));
      V v_t_2420 = (g_prelude_2emap_24s512(v_as_2419));
      v_t_2433 = ({ V a_0 = v_t_2420; V r_ = (g_heff_2eir_2eallI(a_0)); heff_drop(v_t_2420); r_; });
      break;
    }
    case TAG_EMatch: {
      v_t_2433 = NTAG(TAG_False);
      break;
    }
    case TAG_EPrim: {
      v_t_2433 = NTAG(TAG_True);
      break;
    }
    case TAG_EPrimCall: {
      v_t_2433 = NTAG(TAG_False);
      break;
    }
    case TAG_ECall: {
      v_t_2433 = NTAG(TAG_False);
      break;
    }
    case TAG_EInt: {
      v_t_2433 = NTAG(TAG_True);
      break;
    }
    case TAG_EFloat: {
      v_t_2433 = NTAG(TAG_True);
      break;
    }
    case TAG_EStr: {
      v_t_2433 = NTAG(TAG_True);
      break;
    }
    case TAG_EAbandon: {
      v_t_2433 = NTAG(TAG_False);
      break;
    }
    case TAG_EFix: {
      v_t_2433 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_b_242);
    }
    V v_x1_2441;
    switch (heff_tag_of(v_t_2433)) {
    case TAG_True: {
      V v_t_2434 = (g_heff_2eir_2eglobalsGo(v_b_242));
      V v_t_2435 = (g_heff_2eir_2enubI(v_t_2434));
      v_x1_2441 = ({ V a_0 = heff_clo(g_heff_2eemit_2elazyOf_lam0, 1, 2, (V[]){v_key_241, heff_dup(v_acc_240)}); V a_1 = v_t_2435; V r_ = (g_prelude_2eall(a_0, a_1)); heff_drop(v_t_2435); r_; });
      break;
    }
    case TAG_False: {
      heff_drop(v_key_241);
      heff_drop(v_b_242);
      v_x1_2441 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_t_2433);
    }
    switch (heff_tag_of(v_x1_2441)) {
    case TAG_True: {
      return NTAG(TAG_False);
    }
    case TAG_False: {
      return NTAG(TAG_True);
    }
    default: return heff_nomatch(v_x1_2441);
    }
  }
  case TAG_False: {
    heff_drop(v_key_241);
    heff_drop(v_b_242);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_t_244);
  }
}
V g_heff_2eemit_2elazyOf_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eemit_2elazyOf(a[0], a[1], a[2], a[3]); heff_drop(a[0]); return r;
}
V g_heff_2eemit_2elazyOf_lam0(V self, V *args) {
  V v_k_2436 = args[0];
  V v_key_241 = heff_env(self)[0];
  V v_acc_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2437 = heff_strEq(heff_dup(v_k_2436), v_key_241);
  switch (heff_tag_of(v_t_2437)) {
  case TAG_True: {
    heff_drop(v_k_2436);
    heff_drop(v_acc_240);
    return NTAG(TAG_False);
  }
  case TAG_False: {
    V v_t_2438 = ({ V a_0 = v_k_2436; V a_1 = v_acc_240; V r_ = (g_map_2elookup_24s8(a_0, a_1)); heff_drop(v_acc_240); r_; });
    switch (heff_tag_of(v_t_2438)) {
    case TAG_Nothing: {
      return NTAG(TAG_False);
    }
    case TAG_Just: {
      V v_i_2439 = heff_field(v_t_2438, 0);
      heff_take_n(v_t_2438, 1ULL, 1);
      V v_t_2440 = heff_get(v_i_2439, LBL_lazy);
      switch (heff_tag_of(v_t_2440)) {
      case TAG_True: {
        return NTAG(TAG_False);
      }
      case TAG_False: {
        return NTAG(TAG_True);
      }
      default: return heff_nomatch(v_t_2440);
      }
    }
    default: return heff_nomatch(v_t_2438);
    }
  }
  default: return heff_nomatch(v_t_2437);
  }
}
Clo g_heff_2eemit_2einfoOne_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemit_2einfoOne_entry, 4, 0};

V g_heff_2eemit_2einfoOne(V v_shorts_240, V v_bnc_241, V v_acc_242, V v_d_243) {
top: ;
  V v_t_244 = (g_heff_2eemit_2ejsNameOf(v_shorts_240, heff_get(heff_dup(v_d_243), LBL_key)));
  V v_t_245 = heff_get(heff_dup(v_d_243), LBL_body);
  V v_t_2432;
  switch (heff_tag_of(v_t_245)) {
  case TAG_EVar: {
    heff_take_n(v_t_245, 0ULL, 1);
    v_t_2432 = MK_INT(0LL);
    break;
  }
  case TAG_EGlobal: {
    heff_take_n(v_t_245, 0ULL, 1);
    v_t_2432 = MK_INT(0LL);
    break;
  }
  case TAG_ELam: {
    V v_xs_248 = heff_field(v_t_245, 0);
    heff_take_n(v_t_245, 1ULL, 2);
    v_t_2432 = ({ V a_0 = MK_INT(0LL); V a_1 = v_xs_248; V r_ = (g_prelude_2efoldl_24s1(a_0, a_1)); heff_drop(v_xs_248); r_; });
    break;
  }
  case TAG_EApp: {
    heff_take_n(v_t_245, 0ULL, 2);
    v_t_2432 = MK_INT(0LL);
    break;
  }
  case TAG_ELet: {
    heff_take_n(v_t_245, 0ULL, 3);
    v_t_2432 = MK_INT(0LL);
    break;
  }
  case TAG_ERecord: {
    heff_take_n(v_t_245, 0ULL, 1);
    v_t_2432 = MK_INT(0LL);
    break;
  }
  case TAG_EProj: {
    heff_take_n(v_t_245, 0ULL, 2);
    v_t_2432 = MK_INT(0LL);
    break;
  }
  case TAG_ETag: {
    heff_take_n(v_t_245, 0ULL, 2);
    v_t_2432 = MK_INT(0LL);
    break;
  }
  case TAG_EMatch: {
    heff_take_n(v_t_245, 0ULL, 2);
    v_t_2432 = MK_INT(0LL);
    break;
  }
  case TAG_EPrim: {
    heff_take_n(v_t_245, 0ULL, 1);
    v_t_2432 = MK_INT(0LL);
    break;
  }
  case TAG_EPrimCall: {
    heff_take_n(v_t_245, 0ULL, 2);
    v_t_2432 = MK_INT(0LL);
    break;
  }
  case TAG_ECall: {
    heff_take_n(v_t_245, 0ULL, 2);
    v_t_2432 = MK_INT(0LL);
    break;
  }
  case TAG_EInt: {
    heff_take_n(v_t_245, 0ULL, 1);
    v_t_2432 = MK_INT(0LL);
    break;
  }
  case TAG_EFloat: {
    heff_take_n(v_t_245, 0ULL, 1);
    v_t_2432 = MK_INT(0LL);
    break;
  }
  case TAG_EStr: {
    heff_take_n(v_t_245, 0ULL, 1);
    v_t_2432 = MK_INT(0LL);
    break;
  }
  case TAG_EAbandon: {
    v_t_2432 = MK_INT(0LL);
    break;
  }
  case TAG_EFix: {
    heff_take_n(v_t_245, 0ULL, 2);
    v_t_2432 = MK_INT(0LL);
    break;
  }
  default: heff_nomatch(v_t_245);
  }
  V v_t_2433 = heff_get(heff_dup(v_d_243), LBL_body);
  V v_t_2460;
  switch (heff_tag_of(v_t_2433)) {
  case TAG_EVar: {
    heff_take_n(v_t_2433, 0ULL, 1);
    v_t_2460 = MK_INT(0LL);
    break;
  }
  case TAG_EGlobal: {
    heff_take_n(v_t_2433, 0ULL, 1);
    v_t_2460 = MK_INT(0LL);
    break;
  }
  case TAG_ELam: {
    V v_xs_2436 = heff_field(v_t_2433, 0);
    heff_take_n(v_t_2433, 1ULL, 2);
    v_t_2460 = ({ V a_0 = MK_INT(0LL); V a_1 = v_xs_2436; V r_ = (g_prelude_2efoldl_24s1(a_0, a_1)); heff_drop(v_xs_2436); r_; });
    break;
  }
  case TAG_EApp: {
    heff_take_n(v_t_2433, 0ULL, 2);
    v_t_2460 = MK_INT(0LL);
    break;
  }
  case TAG_ELet: {
    heff_take_n(v_t_2433, 0ULL, 3);
    v_t_2460 = MK_INT(0LL);
    break;
  }
  case TAG_ERecord: {
    heff_take_n(v_t_2433, 0ULL, 1);
    v_t_2460 = MK_INT(0LL);
    break;
  }
  case TAG_EProj: {
    heff_take_n(v_t_2433, 0ULL, 2);
    v_t_2460 = MK_INT(0LL);
    break;
  }
  case TAG_ETag: {
    heff_take_n(v_t_2433, 0ULL, 2);
    v_t_2460 = MK_INT(0LL);
    break;
  }
  case TAG_EMatch: {
    heff_take_n(v_t_2433, 0ULL, 2);
    v_t_2460 = MK_INT(0LL);
    break;
  }
  case TAG_EPrim: {
    heff_take_n(v_t_2433, 0ULL, 1);
    v_t_2460 = MK_INT(0LL);
    break;
  }
  case TAG_EPrimCall: {
    heff_take_n(v_t_2433, 0ULL, 2);
    v_t_2460 = MK_INT(0LL);
    break;
  }
  case TAG_ECall: {
    heff_take_n(v_t_2433, 0ULL, 2);
    v_t_2460 = MK_INT(0LL);
    break;
  }
  case TAG_EInt: {
    heff_take_n(v_t_2433, 0ULL, 1);
    v_t_2460 = MK_INT(0LL);
    break;
  }
  case TAG_EFloat: {
    heff_take_n(v_t_2433, 0ULL, 1);
    v_t_2460 = MK_INT(0LL);
    break;
  }
  case TAG_EStr: {
    heff_take_n(v_t_2433, 0ULL, 1);
    v_t_2460 = MK_INT(0LL);
    break;
  }
  case TAG_EAbandon: {
    v_t_2460 = MK_INT(0LL);
    break;
  }
  case TAG_EFix: {
    heff_take_n(v_t_2433, 0ULL, 2);
    v_t_2460 = MK_INT(0LL);
    break;
  }
  default: heff_nomatch(v_t_2433);
  }
  V v_t_2461 = (g_heff_2eemit_2elazyOf(v_acc_242, heff_get(heff_dup(v_d_243), LBL_key), heff_get(heff_dup(v_d_243), LBL_body), v_t_2460));
  V v_x3_2462 = (g_map_2elookup_24s9(heff_get(heff_dup(v_d_243), LBL_key), v_bnc_241));
  V v_t_2464;
  switch (heff_tag_of(v_x3_2462)) {
  case TAG_Nothing: {
    v_t_2464 = NTAG(TAG_False);
    break;
  }
  case TAG_Just: {
    heff_take_n(v_x3_2462, 0ULL, 1);
    v_t_2464 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_x3_2462);
  }
  return (g_map_2einsert_24s7(heff_get(v_d_243, LBL_key), heff_rec(4, shape_150_14_164_31, (V[]){v_t_244, v_t_2432, v_t_2461, v_t_2464}), v_acc_242));
}
V g_heff_2eemit_2einfoOne_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eemit_2einfoOne(a[0], a[1], a[2], a[3]); heff_drop(a[1]); return r;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2eemitCode_str0 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
V g_heff_2eemit_2eemitCode_lam0(V self, V *args);
Clo g_heff_2eemit_2eemitCode_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemit_2eemitCode_entry, 4, 0};

V g_heff_2eemit_2eemitCode(V v_defs_240, V v_info_241, V v_curried_242, V v_globalNames_243) {
top: ;
  V v_t_244 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), heff_dup(v_defs_240)));
  V v_code_2410 = ({ V a_0 = heff_clo(g_heff_2eemit_2eemitCode_lam0, 2, 3, (V[]){heff_dup(v_info_241), heff_dup(v_curried_242), v_globalNames_243}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_244; V r_ = (g_prelude_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_244); r_; });
  V v_helpers_2411 = ({ V a_0 = v_defs_240; V r_ = (g_heff_2eemit_2eprimHelpers(a_0)); heff_drop(v_defs_240); r_; });
  V v_x2_2412 = (g_prelude_2econcatList(heff_dup(v_helpers_2411), heff_dup(v_code_2410)));
  V v_t_2415;
  switch (heff_tag_of(v_x2_2412)) {
  case TAG_Nil: {
    v_t_2415 = ((V)&g_heff_2eemit_2eemitCode_str0);
    break;
  }
  case TAG_Cons: {
    V v_x_2413 = heff_field(v_x2_2412, 0);
    V v_xs_2414 = heff_field(v_x2_2412, 1);
    heff_take_n(v_x2_2412, 3ULL, 2);
    v_t_2415 = ({ V a_0 = v_x_2413; V a_1 = v_xs_2414; V r_ = (g_prelude_2efoldl_24s3(a_0, a_1)); heff_drop(v_xs_2414); r_; });
    break;
  }
  default: heff_nomatch(v_x2_2412);
  }
  V v_t_2416 = (g_heff_2eemit_2eruntime(v_t_2415));
  V v_t_2417 = (g_prelude_2econcatList(v_helpers_2411, v_code_2410));
  V v_t_2418 = (g_prelude_2econcatList(v_t_2416, v_t_2417));
  return heff_rec(2, shape_177_115, (V[]){v_t_2418, v_info_241});
}
V g_heff_2eemit_2eemitCode_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eemit_2eemitCode(a[0], a[1], a[2], a[3]); heff_drop(a[2]); return r;
}
V g_heff_2eemit_2eemitCode_lam0(V self, V *args) {
  V v_acc_245 = args[0];
  V v_x_246 = args[1];
  V v_info_241 = heff_env(self)[0];
  V v_curried_242 = heff_env(self)[1];
  V v_globalNames_243 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_247 = (g_map_2elookup_24s8(heff_get(heff_dup(v_x_246), LBL_key), v_info_241));
  V v_t_249;
  switch (heff_tag_of(v_t_247)) {
  case TAG_Nothing: {
    heff_drop(v_x_246);
    heff_drop(v_info_241);
    heff_drop(v_curried_242);
    heff_drop(v_globalNames_243);
    v_t_249 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_i_248 = heff_field(v_t_247, 0);
    heff_take_n(v_t_247, 1ULL, 1);
    v_t_249 = ({ V a_0 = v_info_241; V a_1 = v_curried_242; V a_2 = v_globalNames_243; V a_3 = v_x_246; V a_4 = v_i_248; V r_ = (g_heff_2eemit_2edefBody(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_curried_242); r_; });
    break;
  }
  default: heff_nomatch(v_t_247);
  }
  return (g_prelude_2econcatList(v_t_249, v_acc_245));
}
V g_heff_2eemit_2eemitWithShorts_lam0(V self, V *args);
V g_heff_2eemit_2eemitWithShorts_lam1(V self, V *args);
Clo g_heff_2eemit_2eemitWithShorts_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemit_2eemitWithShorts_entry, 3, 0};

V g_heff_2eemit_2eemitWithShorts(V v_defs_240, V v_roots_241, V v_shorts_242) {
top: ;
  V v_bnc_243 = (g_heff_2eemit_2ebounceGo(v_defs_240, heff_dup(g_map_2eempty_get())));
  V v_t_246 = (g_prelude_2efoldl(heff_clo(g_heff_2eemit_2eemitWithShorts_lam0, 2, 2, (V[]){heff_dup(v_shorts_242), v_bnc_243}), heff_dup(g_map_2eempty_get()), v_defs_240));
  V v_t_247 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), heff_dup(v_defs_240)));
  V v_t_248 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_247; V r_ = (g_prelude_2efoldl_24s607(a_0, a_1)); heff_drop(v_t_247); r_; });
  V v_xs_249 = (g_prelude_2econcatList(v_t_248, v_roots_241));
  V v_t_2410 = ({ V a_0 = heff_dup(g_map_2eempty_get()); V a_1 = v_xs_249; V r_ = (g_prelude_2efoldl_24s606(a_0, a_1)); heff_drop(v_xs_249); r_; });
  V v_xs_2412 = (g_prelude_2emap(heff_clo(g_heff_2eemit_2eemitWithShorts_lam1, 1, 1, (V[]){v_shorts_242}), heff_dup(v_defs_240)));
  V v_t_2413 = ({ V a_0 = heff_dup(g_map_2eempty_get()); V a_1 = v_xs_2412; V r_ = (g_prelude_2efoldl_24s606(a_0, a_1)); heff_drop(v_xs_2412); r_; });
  return ({ V a_0 = v_defs_240; V a_1 = v_t_246; V a_2 = v_t_2410; V a_3 = v_t_2413; V r_ = (g_heff_2eemit_2eemitCode(a_0, a_1, a_2, a_3)); heff_drop(v_t_2410); r_; });
}
V g_heff_2eemit_2eemitWithShorts_entry(V self, V *a) {
  (void)self;
  return g_heff_2eemit_2eemitWithShorts(a[0], a[1], a[2]);
}
V g_heff_2eemit_2eemitWithShorts_lam0(V self, V *args) {
  V v_acc_244 = args[0];
  V v_d_245 = args[1];
  V v_shorts_242 = heff_env(self)[0];
  V v_bnc_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return ({ V a_0 = v_shorts_242; V a_1 = v_bnc_243; V a_2 = v_acc_244; V a_3 = v_d_245; V r_ = (g_heff_2eemit_2einfoOne(a_0, a_1, a_2, a_3)); heff_drop(v_bnc_243); r_; });
}
V g_heff_2eemit_2eemitWithShorts_lam1(V self, V *args) {
  V v_d_2411 = args[0];
  V v_shorts_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2eemit_2ejsNameOf(v_shorts_242, heff_get(v_d_2411, LBL_key)));
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemit_2erunStr_str0 = {{0x80000000u, K_STR, 0}, 2, 2, {125, 59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[44]; } g_heff_2eemit_2erunStr_str1 = {{0x80000000u, K_STR, 0}, 44, 44, {32, 32, 36, 112, 101, 114, 102, 111, 114, 109, 101, 114, 32, 61, 32, 40, 112, 44, 32, 107, 41, 32, 61, 62, 32, 112, 101, 114, 102, 111, 114, 109, 40, 112, 44, 32, 110, 111, 119, 40, 107, 41, 41, 59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[22]; } g_heff_2eemit_2erunStr_str2 = {{0x80000000u, K_STR, 0}, 22, 22, {32, 32, 114, 101, 116, 117, 114, 110, 32, 36, 116, 114, 40, 101, 110, 116, 114, 121, 40, 41, 41, 59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[16]; } g_heff_2eemit_2erunStr_str3 = {{0x80000000u, K_STR, 0}, 16, 16, {32, 32, 108, 101, 116, 32, 100, 101, 112, 116, 104, 32, 61, 32, 48, 59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[129]; } g_heff_2eemit_2erunStr_str4 = {{0x80000000u, K_STR, 0}, 129, 129, {32, 32, 99, 111, 110, 115, 116, 32, 110, 111, 119, 32, 61, 32, 40, 107, 41, 32, 61, 62, 32, 40, 120, 41, 32, 61, 62, 32, 123, 32, 120, 32, 61, 32, 36, 116, 114, 40, 120, 41, 59, 32, 105, 102, 32, 40, 100, 101, 112, 116, 104, 32, 62, 32, 49, 48, 48, 48, 41, 32, 123, 32, 100, 101, 112, 116, 104, 32, 61, 32, 48, 59, 32, 108, 97, 116, 101, 114, 40, 40, 41, 32, 61, 62, 32, 36, 116, 114, 40, 107, 40, 120, 41, 41, 41, 59, 32, 114, 101, 116, 117, 114, 110, 59, 32, 125, 32, 100, 101, 112, 116, 104, 43, 43, 59, 32, 36, 116, 114, 40, 107, 40, 120, 41, 41, 59, 32, 125, 59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[34]; } g_heff_2eemit_2erunStr_str5 = {{0x80000000u, K_STR, 0}, 34, 34, {99, 111, 110, 115, 116, 32, 36, 114, 117, 110, 32, 61, 32, 40, 101, 110, 116, 114, 121, 44, 32, 112, 101, 114, 102, 111, 114, 109, 41, 32, 61, 62, 32, 123}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[92]; } g_heff_2eemit_2erunStr_str6 = {{0x80000000u, K_STR, 0}, 92, 92, {32, 32, 99, 111, 110, 115, 116, 32, 108, 97, 116, 101, 114, 32, 61, 32, 116, 121, 112, 101, 111, 102, 32, 115, 101, 116, 73, 109, 109, 101, 100, 105, 97, 116, 101, 32, 61, 61, 61, 32, 34, 102, 117, 110, 99, 116, 105, 111, 110, 34, 32, 63, 32, 115, 101, 116, 73, 109, 109, 101, 100, 105, 97, 116, 101, 32, 58, 32, 40, 102, 41, 32, 61, 62, 32, 115, 101, 116, 84, 105, 109, 101, 111, 117, 116, 40, 102, 44, 32, 48, 41, 59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[15]; } g_heff_2eemit_2erunStr_str7 = {{0x80000000u, K_STR, 0}, 15, 15, {108, 101, 116, 32, 36, 112, 101, 114, 102, 111, 114, 109, 101, 114, 59}};

static V g_heff_2eemit_2erunStr_val;
static int g_heff_2eemit_2erunStr_st;
static V g_heff_2eemit_2erunStr_init(void) {
  V v_t_240 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemit_2erunStr_str0), NTAG(TAG_Nil)});
  V v_t_241 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemit_2erunStr_str1), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemit_2erunStr_str2), v_t_240})});
  V v_t_242 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemit_2erunStr_str3), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemit_2erunStr_str4), v_t_241})});
  V v_t_243 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemit_2erunStr_str5), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemit_2erunStr_str6), v_t_242})});
  return ({ V a_0 = ((V)&g_heff_2eemit_2erunStr_str7); V a_1 = v_t_243; V r_ = (g_prelude_2efoldl_24s3(a_0, a_1)); heff_drop_tag(v_t_243, 2); r_; });
}
V g_heff_2eemit_2erunStr_get(void) {
  if (g_heff_2eemit_2erunStr_st == 2) return g_heff_2eemit_2erunStr_val;
  if (g_heff_2eemit_2erunStr_st == 1) heff_fail("defined by itself");
  g_heff_2eemit_2erunStr_st = 1;
  g_heff_2eemit_2erunStr_val = heff_tr(g_heff_2eemit_2erunStr_init());
  g_heff_2eemit_2erunStr_st = 2;
  return g_heff_2eemit_2erunStr_val;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[77]; } g_heff_2eemit_2esumStr_str0 = {{0x80000000u, K_STR, 0}, 77, 77, {99, 111, 110, 115, 116, 32, 36, 115, 117, 109, 32, 61, 32, 40, 108, 44, 32, 114, 41, 32, 61, 62, 32, 40, 112, 44, 32, 107, 41, 32, 61, 62, 32, 112, 46, 36, 32, 61, 61, 61, 32, 34, 73, 110, 76, 34, 32, 63, 32, 108, 40, 112, 46, 97, 91, 48, 93, 44, 32, 107, 41, 32, 58, 32, 114, 40, 112, 46, 97, 91, 48, 93, 44, 32, 107, 41, 59}};

static V g_heff_2eemit_2esumStr_val;
static int g_heff_2eemit_2esumStr_st;
static V g_heff_2eemit_2esumStr_init(void) {
  return ((V)&g_heff_2eemit_2esumStr_str0);
}
V g_heff_2eemit_2esumStr_get(void) {
  if (g_heff_2eemit_2esumStr_st == 2) return g_heff_2eemit_2esumStr_val;
  if (g_heff_2eemit_2esumStr_st == 1) heff_fail("defined by itself");
  g_heff_2eemit_2esumStr_st = 1;
  g_heff_2eemit_2esumStr_val = heff_tr(g_heff_2eemit_2esumStr_init());
  g_heff_2eemit_2esumStr_st = 2;
  return g_heff_2eemit_2esumStr_val;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eemit_2eworldStr_str0 = {{0x80000000u, K_STR, 0}, 5, 5, {125, 41, 40, 41, 59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[105]; } g_heff_2eemit_2eworldStr_str1 = {{0x80000000u, K_STR, 0}, 105, 105, {32, 32, 32, 32, 114, 101, 108, 101, 97, 115, 101, 58, 32, 40, 105, 41, 32, 61, 62, 32, 123, 32, 99, 111, 110, 115, 116, 32, 116, 32, 61, 32, 97, 116, 40, 105, 41, 59, 32, 116, 104, 105, 110, 103, 115, 46, 100, 101, 108, 101, 116, 101, 40, 105, 41, 59, 32, 110, 117, 109, 98, 101, 114, 115, 46, 100, 101, 108, 101, 116, 101, 40, 116, 46, 120, 41, 59, 32, 105, 102, 32, 40, 116, 46, 102, 114, 101, 101, 41, 32, 116, 46, 102, 114, 101, 101, 40, 116, 46, 120, 41, 59, 32, 125, 44}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eemit_2eworldStr_str2 = {{0x80000000u, K_STR, 0}, 4, 4, {32, 32, 125, 59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[145]; } g_heff_2eemit_2eworldStr_str3 = {{0x80000000u, K_STR, 0}, 145, 145, {32, 32, 32, 32, 104, 111, 108, 100, 58, 32, 40, 120, 44, 32, 102, 114, 101, 101, 41, 32, 61, 62, 32, 123, 32, 108, 101, 116, 32, 105, 32, 61, 32, 110, 117, 109, 98, 101, 114, 115, 46, 103, 101, 116, 40, 120, 41, 59, 32, 105, 102, 32, 40, 105, 32, 61, 61, 61, 32, 117, 110, 100, 101, 102, 105, 110, 101, 100, 41, 32, 123, 32, 105, 32, 61, 32, 110, 101, 120, 116, 43, 43, 59, 32, 110, 117, 109, 98, 101, 114, 115, 46, 115, 101, 116, 40, 120, 44, 32, 105, 41, 59, 32, 116, 104, 105, 110, 103, 115, 46, 115, 101, 116, 40, 105, 44, 32, 123, 32, 120, 44, 32, 102, 114, 101, 101, 32, 125, 41, 59, 32, 125, 32, 114, 101, 116, 117, 114, 110, 32, 105, 59, 32, 125, 44}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[24]; } g_heff_2eemit_2eworldStr_str4 = {{0x80000000u, K_STR, 0}, 24, 24, {32, 32, 32, 32, 103, 101, 116, 58, 32, 40, 105, 41, 32, 61, 62, 32, 97, 116, 40, 105, 41, 46, 120, 44}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[131]; } g_heff_2eemit_2eworldStr_str5 = {{0x80000000u, K_STR, 0}, 131, 131, {32, 32, 99, 111, 110, 115, 116, 32, 97, 116, 32, 61, 32, 40, 105, 41, 32, 61, 62, 32, 123, 32, 99, 111, 110, 115, 116, 32, 116, 32, 61, 32, 116, 104, 105, 110, 103, 115, 46, 103, 101, 116, 40, 105, 41, 59, 32, 105, 102, 32, 40, 33, 116, 41, 32, 116, 104, 114, 111, 119, 32, 110, 101, 119, 32, 69, 114, 114, 111, 114, 40, 34, 104, 101, 102, 102, 58, 32, 116, 104, 101, 32, 119, 111, 114, 108, 100, 32, 104, 111, 108, 100, 115, 32, 110, 111, 116, 104, 105, 110, 103, 32, 110, 117, 109, 98, 101, 114, 101, 100, 32, 34, 32, 43, 32, 105, 41, 59, 32, 114, 101, 116, 117, 114, 110, 32, 116, 59, 32, 125, 59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[10]; } g_heff_2eemit_2eworldStr_str6 = {{0x80000000u, K_STR, 0}, 10, 10, {32, 32, 114, 101, 116, 117, 114, 110, 32, 123}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[48]; } g_heff_2eemit_2eworldStr_str7 = {{0x80000000u, K_STR, 0}, 48, 48, {32, 32, 99, 111, 110, 115, 116, 32, 116, 104, 105, 110, 103, 115, 32, 61, 32, 110, 101, 119, 32, 77, 97, 112, 40, 41, 44, 32, 110, 117, 109, 98, 101, 114, 115, 32, 61, 32, 110, 101, 119, 32, 77, 97, 112, 40, 41, 59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[16]; } g_heff_2eemit_2eworldStr_str8 = {{0x80000000u, K_STR, 0}, 16, 16, {32, 32, 108, 101, 116, 32, 110, 101, 120, 116, 32, 61, 32, 48, 110, 59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[23]; } g_heff_2eemit_2eworldStr_str9 = {{0x80000000u, K_STR, 0}, 23, 23, {99, 111, 110, 115, 116, 32, 36, 119, 111, 114, 108, 100, 32, 61, 32, 40, 40, 41, 32, 61, 62, 32, 123}};

static V g_heff_2eemit_2eworldStr_val;
static int g_heff_2eemit_2eworldStr_st;
static V g_heff_2eemit_2eworldStr_init(void) {
  V v_t_240 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemit_2eworldStr_str0), NTAG(TAG_Nil)});
  V v_t_241 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemit_2eworldStr_str1), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemit_2eworldStr_str2), v_t_240})});
  V v_t_242 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemit_2eworldStr_str3), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemit_2eworldStr_str4), v_t_241})});
  V v_t_243 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemit_2eworldStr_str5), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemit_2eworldStr_str6), v_t_242})});
  V v_t_244 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemit_2eworldStr_str7), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemit_2eworldStr_str8), v_t_243})});
  return ({ V a_0 = ((V)&g_heff_2eemit_2eworldStr_str9); V a_1 = v_t_244; V r_ = (g_prelude_2efoldl_24s3(a_0, a_1)); heff_drop_tag(v_t_244, 2); r_; });
}
V g_heff_2eemit_2eworldStr_get(void) {
  if (g_heff_2eemit_2eworldStr_st == 2) return g_heff_2eemit_2eworldStr_val;
  if (g_heff_2eemit_2eworldStr_st == 1) heff_fail("defined by itself");
  g_heff_2eemit_2eworldStr_st = 1;
  g_heff_2eemit_2eworldStr_val = heff_tr(g_heff_2eemit_2eworldStr_init());
  g_heff_2eemit_2eworldStr_st = 2;
  return g_heff_2eemit_2eworldStr_val;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[13]; } g_heff_2eemit_2eexportNameOf_str0 = {{0x80000000u, K_STR, 0}, 13, 13, {101, 120, 112, 111, 114, 116, 32, 99, 111, 110, 115, 116, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2eexportNameOf_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {32}};
Clo g_heff_2eemit_2eexportNameOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemit_2eexportNameOf_entry, 1, 0};

V g_heff_2eemit_2eexportNameOf(V v_l_240) {
top: ;
  V v_t_241 = heff_strEq(heff_strSlice(heff_dup(v_l_240), MK_INT(0LL), MK_INT(13LL)), ((V)&g_heff_2eemit_2eexportNameOf_str0));
  switch (heff_tag_of(v_t_241)) {
  case TAG_True: {
    V v_t_242 = heff_strSlice(heff_dup(v_l_240), MK_INT(13LL), heff_strLength(heff_dup(v_l_240)));
    V v_t_243 = (g_prelude_2eindexFrom(((V)&g_heff_2eemit_2eexportNameOf_str1), v_t_242, MK_INT(0LL)));
    switch (heff_tag_of(v_t_243)) {
    case TAG_Nothing: {
      V v_t_244 = heff_strSlice(heff_dup(v_l_240), MK_INT(13LL), heff_strLength(v_l_240));
      return heff_tag(TAG_Just, 1, (V[]){v_t_244});
    }
    case TAG_Just: {
      V v_i_245 = heff_field(v_t_243, 0);
      V v_ru_24t_243_24Just = heff_take_reuse_n(v_t_243, 1ULL, 1);
      V v_t_246 = heff_strSlice(v_l_240, MK_INT(13LL), heff_intAdd(MK_INT(13LL), v_i_245));
      return heff_tag_at(v_ru_24t_243_24Just, TAG_Just, 1, (V[]){v_t_246});
    }
    default: return heff_nomatch(v_t_243);
    }
  }
  case TAG_False: {
    heff_drop(v_l_240);
    return NTAG(TAG_Nothing);
  }
  default: return heff_nomatch(v_t_241);
  }
}
V g_heff_2eemit_2eexportNameOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2eemit_2eexportNameOf(a[0]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[22]; } g_heff_2eemit_2ehostLineOf_str0 = {{0x80000000u, K_STR, 0}, 22, 22, {101, 120, 112, 111, 114, 116, 32, 99, 111, 110, 115, 116, 32, 36, 104, 111, 115, 116, 32, 61, 32, 34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2ehostLineOf_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {34}};
Clo g_heff_2eemit_2ehostLineOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemit_2ehostLineOf_entry, 1, 0};

V g_heff_2eemit_2ehostLineOf(V v_l_240) {
top: ;
  V v_t_241 = heff_strEq(heff_strSlice(heff_dup(v_l_240), MK_INT(0LL), MK_INT(22LL)), ((V)&g_heff_2eemit_2ehostLineOf_str0));
  switch (heff_tag_of(v_t_241)) {
  case TAG_True: {
    V v_t_242 = heff_strSlice(heff_dup(v_l_240), MK_INT(22LL), heff_strLength(heff_dup(v_l_240)));
    V v_t_243 = (g_prelude_2eindexFrom(((V)&g_heff_2eemit_2ehostLineOf_str1), v_t_242, MK_INT(0LL)));
    switch (heff_tag_of(v_t_243)) {
    case TAG_Nothing: {
      V v_t_244 = heff_strSlice(heff_dup(v_l_240), MK_INT(22LL), heff_strLength(v_l_240));
      return heff_tag(TAG_Just, 1, (V[]){v_t_244});
    }
    case TAG_Just: {
      V v_i_245 = heff_field(v_t_243, 0);
      V v_ru_24t_243_24Just = heff_take_reuse_n(v_t_243, 1ULL, 1);
      V v_t_246 = heff_strSlice(v_l_240, MK_INT(22LL), heff_intAdd(MK_INT(22LL), v_i_245));
      return heff_tag_at(v_ru_24t_243_24Just, TAG_Just, 1, (V[]){v_t_246});
    }
    default: return heff_nomatch(v_t_243);
    }
  }
  case TAG_False: {
    heff_drop(v_l_240);
    return NTAG(TAG_Nothing);
  }
  default: return heff_nomatch(v_t_241);
  }
}
V g_heff_2eemit_2ehostLineOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2eemit_2ehostLineOf(a[0]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemit_2ebundleProvider_str0 = {{0x80000000u, K_STR, 0}, 3, 3, {47, 47, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[12]; } g_heff_2eemit_2ebundleProvider_str1 = {{0x80000000u, K_STR, 0}, 12, 12, {46, 112, 114, 111, 118, 105, 100, 101, 114, 46, 106, 115}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2eemit_2ebundleProvider_str2 = {{0x80000000u, K_STR, 0}, 8, 8, {99, 111, 110, 115, 116, 32, 36, 112}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[11]; } g_heff_2eemit_2ebundleProvider_str3 = {{0x80000000u, K_STR, 0}, 11, 11, {32, 61, 32, 40, 40, 41, 32, 61, 62, 32, 123}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2ebundleProvider_str4 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2ebundleProvider_str5 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2ebundleProvider_str6 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2eemit_2ebundleProvider_str7 = {{0x80000000u, K_STR, 0}, 9, 9, {114, 101, 116, 117, 114, 110, 32, 123, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[3]; } g_heff_2eemit_2ebundleProvider_str8 = {{0x80000000u, K_STR, 0}, 3, 3, {32, 125, 59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eemit_2ebundleProvider_str9 = {{0x80000000u, K_STR, 0}, 5, 5, {125, 41, 40, 41, 59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2ebundleProvider_str10 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
Clo g_heff_2eemit_2ebundleProvider_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemit_2ebundleProvider_entry, 2, 0};

V g_heff_2eemit_2ebundleProvider(V v_i_240, V v_p_241) {
top: ;
  V v_t_242 = heff_strAppend(((V)&g_heff_2eemit_2ebundleProvider_str0), heff_strAppend(heff_get(heff_dup(v_p_241), LBL_module), ((V)&g_heff_2eemit_2ebundleProvider_str1)));
  V v_t_243 = heff_strAppend(((V)&g_heff_2eemit_2ebundleProvider_str2), heff_strAppend(heff_intShow(v_i_240), ((V)&g_heff_2eemit_2ebundleProvider_str3)));
  V v_t_244 = heff_tag(TAG_Cons, 2, (V[]){v_t_243, NTAG(TAG_Nil)});
  V v_t_245 = (g_prelude_2esplitFrom(((V)&g_heff_2eemit_2ebundleProvider_str4), heff_get(heff_dup(v_p_241), LBL_text), MK_INT(0LL), NTAG(TAG_Nil)));
  V v_t_246 = (g_prelude_2efilter_24s612(v_t_245));
  V v_t_247 = (g_prelude_2emap_24s611(v_t_246));
  V v_t_248 = (g_prelude_2esplitFrom(((V)&g_heff_2eemit_2ebundleProvider_str5), heff_get(v_p_241, LBL_text), MK_INT(0LL), NTAG(TAG_Nil)));
  V v_t_249 = (g_prelude_2emap_24s609(v_t_248));
  V v_t_2410 = (g_heff_2eemit_2ecatMaybesL(v_t_249));
  V v_x2_2411 = (g_prelude_2efilter_24s608(v_t_2410));
  V v_t_2414;
  switch (heff_tag_of(v_x2_2411)) {
  case TAG_Nil: {
    v_t_2414 = ((V)&g_heff_2eemit_2ebundleProvider_str6);
    break;
  }
  case TAG_Cons: {
    V v_x_2412 = heff_field(v_x2_2411, 0);
    V v_xs_2413 = heff_field(v_x2_2411, 1);
    heff_take_n(v_x2_2411, 3ULL, 2);
    v_t_2414 = ({ V a_0 = v_x_2412; V a_1 = v_xs_2413; V r_ = (g_prelude_2efoldl_24s45(a_0, a_1)); heff_drop(v_xs_2413); r_; });
    break;
  }
  default: heff_nomatch(v_x2_2411);
  }
  V v_t_2415 = heff_strAppend(((V)&g_heff_2eemit_2ebundleProvider_str7), heff_strAppend(v_t_2414, ((V)&g_heff_2eemit_2ebundleProvider_str8)));
  V v_t_2416 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemit_2ebundleProvider_str9), NTAG(TAG_Nil)});
  V v_t_2417 = (g_prelude_2econcatList(v_t_247, heff_tag(TAG_Cons, 2, (V[]){v_t_2415, v_t_2416})));
  V v_x2_2418 = (g_prelude_2econcatList(heff_tag(TAG_Cons, 2, (V[]){v_t_242, v_t_244}), v_t_2417));
  switch (heff_tag_of(v_x2_2418)) {
  case TAG_Nil: {
    return ((V)&g_heff_2eemit_2ebundleProvider_str10);
  }
  case TAG_Cons: {
    V v_x_2419 = heff_field(v_x2_2418, 0);
    V v_xs_2420 = heff_field(v_x2_2418, 1);
    heff_take_n(v_x2_2418, 3ULL, 2);
    return ({ V a_0 = v_x_2419; V a_1 = v_xs_2420; V r_ = (g_prelude_2efoldl_24s3(a_0, a_1)); heff_drop(v_xs_2420); r_; });
  }
  default: return heff_nomatch(v_x2_2418);
  }
}
V g_heff_2eemit_2ebundleProvider_entry(V self, V *a) {
  (void)self;
  return g_heff_2eemit_2ebundleProvider(a[0], a[1]);
}
Clo g_heff_2eemit_2ebundleAll_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemit_2ebundleAll_entry, 2, 0};

V g_heff_2eemit_2ebundleAll(V v_i_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_i_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_p_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_244 = (g_heff_2eemit_2ebundleProvider(heff_dup(v_i_240), v_p_242));
    return heff_tag_at(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_244, (g_heff_2eemit_2ebundleAll(heff_intAdd(v_i_240, MK_INT(1LL)), v_rest_243))});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eemit_2ebundleAll_entry(V self, V *a) {
  (void)self;
  return g_heff_2eemit_2ebundleAll(a[0], a[1]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2eruntimeFor_str0 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
Clo g_heff_2eemit_2eruntimeFor_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemit_2eruntimeFor_entry, 3, 0};

V g_heff_2eemit_2eruntimeFor(V v_hasTr_240, V v_provs_241, V v_eff_242) {
top: ;
  V v_t_243;
  switch (heff_tag_of(v_hasTr_240)) {
  case TAG_True: {
    v_t_243 = NTAG(TAG_Nil);
    break;
  }
  case TAG_False: {
    v_t_243 = heff_tag(TAG_Cons, 2, (V[]){heff_dup(g_heff_2eemit_2etrampolineStr_get()), NTAG(TAG_Nil)});
    break;
  }
  default: heff_nomatch(v_hasTr_240);
  }
  V v_t_244 = heff_tag(TAG_Cons, 2, (V[]){heff_dup(g_heff_2eemit_2eworldStr_get()), NTAG(TAG_Nil)});
  V v_t_245 = (g_prelude_2econcatList(v_t_243, heff_tag(TAG_Cons, 2, (V[]){heff_dup(g_heff_2eemit_2erunStr_get()), v_t_244})));
  V v_t_249;
  switch (heff_tag_of(v_eff_242)) {
  case TAG_Leaf: {
    heff_take_n(v_eff_242, 0ULL, 1);
    v_t_249 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Plus: {
    V v_ru_24eff_242_24Plus = heff_take_reuse_n(v_eff_242, 0ULL, 2);
    v_t_249 = heff_tag_at(v_ru_24eff_242_24Plus, TAG_Cons, 2, (V[]){heff_dup(g_heff_2eemit_2esumStr_get()), NTAG(TAG_Nil)});
    break;
  }
  default: heff_nomatch(v_eff_242);
  }
  V v_t_2410 = (g_heff_2eemit_2ebundleAll(MK_INT(0LL), v_provs_241));
  V v_t_2411 = (g_prelude_2econcatList(v_t_249, v_t_2410));
  V v_x2_2412 = (g_prelude_2econcatList(v_t_245, v_t_2411));
  switch (heff_tag_of(v_x2_2412)) {
  case TAG_Nil: {
    return ((V)&g_heff_2eemit_2eruntimeFor_str0);
  }
  case TAG_Cons: {
    V v_x_2413 = heff_field(v_x2_2412, 0);
    V v_xs_2414 = heff_field(v_x2_2412, 1);
    heff_take_n(v_x2_2412, 3ULL, 2);
    return ({ V a_0 = v_x_2413; V a_1 = v_xs_2414; V r_ = (g_prelude_2efoldl_24s3(a_0, a_1)); heff_drop(v_xs_2414); r_; });
  }
  default: return heff_nomatch(v_x2_2412);
  }
}
V g_heff_2eemit_2eruntimeFor_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eemit_2eruntimeFor(a[0], a[1], a[2]); heff_drop(a[0]); return r;
}
Clo g_heff_2eemit_2eprovIndexGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemit_2eprovIndexGo_entry, 3, 0};

V g_heff_2eemit_2eprovIndexGo(V v_i_240, V v_md_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_i_240);
    heff_drop(v_md_241);
    return MK_INT(0LL);
  }
  case TAG_Cons: {
    V v_p_243 = heff_field(v_x3_242, 0);
    V v_rest_244 = heff_field(v_x3_242, 1);
    V v_t_245 = heff_strEq(heff_get(heff_dup(v_p_243), LBL_module), heff_dup(v_md_241));
    switch (heff_tag_of(v_t_245)) {
    case TAG_True: {
      heff_drop(v_md_241);
      return v_i_240;
    }
    case TAG_False: {
      V t_0 = heff_intAdd(v_i_240, MK_INT(1LL));
      V t_1 = v_md_241;
      V t_2 = v_rest_244;
      v_i_240 = t_0;
      v_md_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_t_245);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2eemit_2eprovIndexGo_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eemit_2eprovIndexGo(a[0], a[1], a[2]); heff_drop(a[2]); return r;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2ehandlerOf_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {46}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2ehandlerOf_str1 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2ehandlerOf_str2 = {{0x80000000u, K_STR, 0}, 1, 1, {46}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemit_2ehandlerOf_str3 = {{0x80000000u, K_STR, 0}, 2, 2, {36, 112}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2ehandlerOf_str4 = {{0x80000000u, K_STR, 0}, 1, 1, {46}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2eemit_2ehandlerOf_str5 = {{0x80000000u, K_STR, 0}, 8, 8, {40, 36, 119, 111, 114, 108, 100, 41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eemit_2ehandlerOf_str6 = {{0x80000000u, K_STR, 0}, 5, 5, {36, 115, 117, 109, 40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemit_2ehandlerOf_str7 = {{0x80000000u, K_STR, 0}, 2, 2, {44, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2ehandlerOf_str8 = {{0x80000000u, K_STR, 0}, 1, 1, {41}};
Clo g_heff_2eemit_2ehandlerOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemit_2ehandlerOf_entry, 2, 0};

V g_heff_2eemit_2ehandlerOf(V v_provs_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Leaf: {
    V v_k_242 = heff_field(v_x2_241, 0);
    V v_t_243 = (g_prelude_2esplitFrom(((V)&g_heff_2eemit_2ehandlerOf_str0), heff_dup(v_k_242), MK_INT(0LL), NTAG(TAG_Nil)));
    V v_x2_244 = (g_heff_2eeffect_2edropLastD(v_t_243));
    V v_t_247;
    switch (heff_tag_of(v_x2_244)) {
    case TAG_Nil: {
      v_t_247 = ((V)&g_heff_2eemit_2ehandlerOf_str1);
      break;
    }
    case TAG_Cons: {
      V v_x_245 = heff_field(v_x2_244, 0);
      V v_xs_246 = heff_field(v_x2_244, 1);
      heff_take_n(v_x2_244, 3ULL, 2);
      v_t_247 = ({ V a_0 = v_x_245; V a_1 = v_xs_246; V r_ = (g_prelude_2efoldl_24s13(a_0, a_1)); heff_drop(v_xs_246); r_; });
      break;
    }
    default: heff_nomatch(v_x2_244);
    }
    V v_t_248 = (g_heff_2eemit_2eprovIndexGo(MK_INT(0LL), v_t_247, v_provs_240));
    V v_t_249 = (g_prelude_2esplitFrom(((V)&g_heff_2eemit_2ehandlerOf_str2), heff_dup(v_k_242), MK_INT(0LL), NTAG(TAG_Nil)));
    V v_t_2410 = ({ V a_0 = heff_dup(v_k_242); V a_1 = v_t_249; V r_ = (g_heff_2eeffect_2elastOr(a_0, a_1)); heff_drop(v_t_249); r_; });
    return heff_strAppend(((V)&g_heff_2eemit_2ehandlerOf_str3), heff_strAppend(heff_intShow(v_t_248), heff_strAppend(((V)&g_heff_2eemit_2ehandlerOf_str4), heff_strAppend(v_t_2410, ((V)&g_heff_2eemit_2ehandlerOf_str5)))));
  }
  case TAG_Plus: {
    V v_a_2411 = heff_field(v_x2_241, 0);
    V v_b_2412 = heff_field(v_x2_241, 1);
    V v_t_2413 = (g_heff_2eemit_2ehandlerOf(v_provs_240, v_a_2411));
    V v_t_2414 = (g_heff_2eemit_2ehandlerOf(v_provs_240, v_b_2412));
    return heff_strAppend(((V)&g_heff_2eemit_2ehandlerOf_str6), heff_strAppend(v_t_2413, heff_strAppend(((V)&g_heff_2eemit_2ehandlerOf_str7), heff_strAppend(v_t_2414, ((V)&g_heff_2eemit_2ehandlerOf_str8)))));
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eemit_2ehandlerOf_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eemit_2ehandlerOf(a[0], a[1]); heff_drop(a[0]); heff_drop(a[1]); return r;
}
Clo g_heff_2eemit_2efindProv_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemit_2efindProv_entry, 2, 0};

V g_heff_2eemit_2efindProv(V v_md_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_md_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_p_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    V v_t_244 = heff_strEq(heff_get(heff_dup(v_p_242), LBL_module), heff_dup(v_md_240));
    switch (heff_tag_of(v_t_244)) {
    case TAG_True: {
      heff_drop(v_md_240);
      return heff_tag(TAG_Just, 1, (V[]){heff_dup(v_p_242)});
    }
    case TAG_False: {
      V t_0 = v_md_240;
      V t_1 = v_rest_243;
      v_md_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eemit_2efindProv_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eemit_2efindProv(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_heff_2eemit_2eprovsForGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemit_2eprovsForGo_entry, 2, 0};

V g_heff_2eemit_2eprovsForGo(V v_available_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_md_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_244 = (g_heff_2eemit_2efindProv(v_md_242, v_available_240));
    switch (heff_tag_of(v_t_244)) {
    case TAG_Nothing: {
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      V t_0 = v_available_240;
      V t_1 = v_rest_243;
      v_available_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_Just: {
      V v_p_245 = heff_field(v_t_244, 0);
      heff_take_n(v_t_244, 1ULL, 1);
      return heff_tag_at(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_p_245, (g_heff_2eemit_2eprovsForGo(v_available_240, v_rest_243))});
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eemit_2eprovsForGo_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eemit_2eprovsForGo(a[0], a[1]); heff_drop(a[0]); return r;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2eimportLinesOf_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {10}};
Clo g_heff_2eemit_2eimportLinesOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemit_2eimportLinesOf_entry, 1, 0};

V g_heff_2eemit_2eimportLinesOf(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_p_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    V v_t_243 = (g_prelude_2esplitFrom(((V)&g_heff_2eemit_2eimportLinesOf_str0), heff_get(heff_dup(v_p_241), LBL_text), MK_INT(0LL), NTAG(TAG_Nil)));
    V v_t_244 = (g_prelude_2efilter_24s614(v_t_243));
    V v_t_245 = (g_heff_2eemit_2eimportLinesOf(v_rest_242));
    return (g_prelude_2econcatList(v_t_244, v_t_245));
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eemit_2eimportLinesOf_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eemit_2eimportLinesOf(a[0]); heff_drop(a[0]); return r;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[53]; } g_heff_2eemit_2enodeHead_str0 = {{0x80000000u, K_STR, 0}, 53, 53, {105, 109, 112, 111, 114, 116, 32, 123, 32, 115, 112, 97, 119, 110, 32, 97, 115, 32, 36, 115, 112, 97, 119, 110, 32, 125, 32, 102, 114, 111, 109, 32, 34, 110, 111, 100, 101, 58, 99, 104, 105, 108, 100, 95, 112, 114, 111, 99, 101, 115, 115, 34, 59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[42]; } g_heff_2eemit_2enodeHead_str1 = {{0x80000000u, K_STR, 0}, 42, 42, {47, 47, 32, 71, 101, 110, 101, 114, 97, 116, 101, 100, 32, 102, 114, 111, 109, 32, 72, 105, 112, 112, 111, 103, 114, 105, 102, 102, 59, 32, 100, 111, 32, 110, 111, 116, 32, 101, 100, 105, 116, 46}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[114]; } g_heff_2eemit_2enodeHead_str2 = {{0x80000000u, K_STR, 0}, 114, 114, {105, 109, 112, 111, 114, 116, 32, 123, 32, 87, 111, 114, 107, 101, 114, 32, 97, 115, 32, 36, 87, 111, 114, 107, 101, 114, 44, 32, 105, 115, 77, 97, 105, 110, 84, 104, 114, 101, 97, 100, 32, 97, 115, 32, 36, 105, 115, 77, 97, 105, 110, 84, 104, 114, 101, 97, 100, 44, 32, 112, 97, 114, 101, 110, 116, 80, 111, 114, 116, 32, 97, 115, 32, 36, 112, 97, 114, 101, 110, 116, 80, 111, 114, 116, 32, 125, 32, 102, 114, 111, 109, 32, 34, 110, 111, 100, 101, 58, 119, 111, 114, 107, 101, 114, 95, 116, 104, 114, 101, 97, 100, 115, 34, 59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[19]; } g_heff_2eemit_2enodeHead_str3 = {{0x80000000u, K_STR, 0}, 19, 19, {35, 33, 47, 117, 115, 114, 47, 98, 105, 110, 47, 101, 110, 118, 32, 110, 111, 100, 101}};

static V g_heff_2eemit_2enodeHead_val;
static int g_heff_2eemit_2enodeHead_st;
static V g_heff_2eemit_2enodeHead_init(void) {
  V v_t_240 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemit_2enodeHead_str0), NTAG(TAG_Nil)});
  V v_t_241 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemit_2enodeHead_str1), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemit_2enodeHead_str2), v_t_240})});
  return heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemit_2enodeHead_str3), v_t_241});
}
V g_heff_2eemit_2enodeHead_get(void) {
  if (g_heff_2eemit_2enodeHead_st == 2) return g_heff_2eemit_2enodeHead_val;
  if (g_heff_2eemit_2enodeHead_st == 1) heff_fail("defined by itself");
  g_heff_2eemit_2enodeHead_st = 1;
  g_heff_2eemit_2enodeHead_val = heff_tr(g_heff_2eemit_2enodeHead_init());
  g_heff_2eemit_2enodeHead_st = 2;
  return g_heff_2eemit_2enodeHead_val;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2enodeRun_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {125}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemit_2enodeRun_str1 = {{0x80000000u, K_STR, 0}, 2, 2, {32, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2eemit_2enodeRun_str2 = {{0x80000000u, K_STR, 0}, 8, 8, {125, 32, 101, 108, 115, 101, 32, 123}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[79]; } g_heff_2eemit_2enodeRun_str3 = {{0x80000000u, K_STR, 0}, 79, 79, {32, 32, 112, 114, 111, 99, 101, 115, 115, 46, 115, 116, 100, 105, 110, 46, 111, 110, 99, 101, 40, 34, 114, 101, 115, 117, 109, 101, 34, 44, 32, 40, 41, 32, 61, 62, 32, 36, 112, 97, 114, 101, 110, 116, 80, 111, 114, 116, 46, 112, 111, 115, 116, 77, 101, 115, 115, 97, 103, 101, 40, 123, 32, 115, 116, 100, 105, 110, 58, 32, 116, 114, 117, 101, 32, 125, 41, 41, 59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[70]; } g_heff_2eemit_2enodeRun_str4 = {{0x80000000u, K_STR, 0}, 70, 70, {32, 32, 32, 32, 99, 104, 105, 108, 100, 46, 111, 110, 40, 34, 101, 120, 105, 116, 34, 44, 32, 40, 115, 116, 97, 116, 117, 115, 41, 32, 61, 62, 32, 123, 32, 112, 114, 111, 99, 101, 115, 115, 46, 101, 120, 105, 116, 67, 111, 100, 101, 32, 61, 32, 115, 116, 97, 116, 117, 115, 32, 63, 63, 32, 49, 59, 32, 125, 41, 59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eemit_2enodeRun_str5 = {{0x80000000u, K_STR, 0}, 5, 5, {32, 32, 125, 41, 59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[65]; } g_heff_2eemit_2enodeRun_str6 = {{0x80000000u, K_STR, 0}, 65, 65, {32, 32, 32, 32, 99, 111, 110, 115, 116, 32, 99, 104, 105, 108, 100, 32, 61, 32, 36, 115, 112, 97, 119, 110, 40, 101, 120, 101, 99, 91, 48, 93, 44, 32, 101, 120, 101, 99, 91, 49, 93, 44, 32, 123, 32, 115, 116, 100, 105, 111, 58, 32, 34, 105, 110, 104, 101, 114, 105, 116, 34, 32, 125, 41, 59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[82]; } g_heff_2eemit_2enodeRun_str7 = {{0x80000000u, K_STR, 0}, 82, 82, {32, 32, 32, 32, 99, 104, 105, 108, 100, 46, 111, 110, 40, 34, 101, 114, 114, 111, 114, 34, 44, 32, 40, 101, 41, 32, 61, 62, 32, 123, 32, 99, 111, 110, 115, 111, 108, 101, 46, 101, 114, 114, 111, 114, 40, 101, 46, 109, 101, 115, 115, 97, 103, 101, 41, 59, 32, 112, 114, 111, 99, 101, 115, 115, 46, 101, 120, 105, 116, 67, 111, 100, 101, 32, 61, 32, 49, 59, 32, 125, 41, 59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[79]; } g_heff_2eemit_2enodeRun_str8 = {{0x80000000u, K_STR, 0}, 79, 79, {32, 32, 32, 32, 105, 102, 32, 40, 112, 105, 112, 101, 100, 41, 32, 123, 32, 112, 114, 111, 99, 101, 115, 115, 46, 115, 116, 100, 105, 110, 46, 117, 110, 112, 105, 112, 101, 40, 119, 111, 114, 107, 101, 114, 46, 115, 116, 100, 105, 110, 41, 59, 32, 112, 114, 111, 99, 101, 115, 115, 46, 115, 116, 100, 105, 110, 46, 100, 101, 115, 116, 114, 111, 121, 40, 41, 59, 32, 125}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[51]; } g_heff_2eemit_2enodeRun_str9 = {{0x80000000u, K_STR, 0}, 51, 51, {32, 32, 32, 32, 105, 102, 32, 40, 33, 101, 120, 101, 99, 41, 32, 123, 32, 112, 114, 111, 99, 101, 115, 115, 46, 101, 120, 105, 116, 67, 111, 100, 101, 32, 61, 32, 99, 111, 100, 101, 59, 32, 114, 101, 116, 117, 114, 110, 59, 32, 125}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[73]; } g_heff_2eemit_2enodeRun_str10 = {{0x80000000u, K_STR, 0}, 73, 73, {32, 32, 119, 111, 114, 107, 101, 114, 46, 111, 110, 40, 34, 101, 114, 114, 111, 114, 34, 44, 32, 40, 101, 41, 32, 61, 62, 32, 123, 32, 99, 111, 110, 115, 111, 108, 101, 46, 101, 114, 114, 111, 114, 40, 101, 41, 59, 32, 112, 114, 111, 99, 101, 115, 115, 46, 101, 120, 105, 116, 67, 111, 100, 101, 32, 61, 32, 49, 59, 32, 125, 41, 59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[31]; } g_heff_2eemit_2enodeRun_str11 = {{0x80000000u, K_STR, 0}, 31, 31, {32, 32, 119, 111, 114, 107, 101, 114, 46, 111, 110, 40, 34, 101, 120, 105, 116, 34, 44, 32, 40, 99, 111, 100, 101, 41, 32, 61, 62, 32, 123}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[35]; } g_heff_2eemit_2enodeRun_str12 = {{0x80000000u, K_STR, 0}, 35, 35, {32, 32, 32, 32, 105, 102, 32, 40, 109, 32, 38, 38, 32, 109, 46, 101, 120, 101, 99, 41, 32, 101, 120, 101, 99, 32, 61, 32, 109, 46, 101, 120, 101, 99, 59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eemit_2enodeRun_str13 = {{0x80000000u, K_STR, 0}, 5, 5, {32, 32, 125, 41, 59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[31]; } g_heff_2eemit_2enodeRun_str14 = {{0x80000000u, K_STR, 0}, 31, 31, {32, 32, 119, 111, 114, 107, 101, 114, 46, 111, 110, 40, 34, 109, 101, 115, 115, 97, 103, 101, 34, 44, 32, 40, 109, 41, 32, 61, 62, 32, 123}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[83]; } g_heff_2eemit_2enodeRun_str15 = {{0x80000000u, K_STR, 0}, 83, 83, {32, 32, 32, 32, 105, 102, 32, 40, 109, 32, 38, 38, 32, 109, 46, 115, 116, 100, 105, 110, 32, 38, 38, 32, 33, 112, 105, 112, 101, 100, 41, 32, 123, 32, 112, 105, 112, 101, 100, 32, 61, 32, 116, 114, 117, 101, 59, 32, 112, 114, 111, 99, 101, 115, 115, 46, 115, 116, 100, 105, 110, 46, 112, 105, 112, 101, 40, 119, 111, 114, 107, 101, 114, 46, 115, 116, 100, 105, 110, 41, 59, 32, 125}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[125]; } g_heff_2eemit_2enodeRun_str16 = {{0x80000000u, K_STR, 0}, 125, 125, {32, 32, 99, 111, 110, 115, 116, 32, 119, 111, 114, 107, 101, 114, 32, 61, 32, 110, 101, 119, 32, 36, 87, 111, 114, 107, 101, 114, 40, 110, 101, 119, 32, 85, 82, 76, 40, 105, 109, 112, 111, 114, 116, 46, 109, 101, 116, 97, 46, 117, 114, 108, 41, 44, 32, 123, 32, 97, 114, 103, 118, 58, 32, 112, 114, 111, 99, 101, 115, 115, 46, 97, 114, 103, 118, 46, 115, 108, 105, 99, 101, 40, 50, 41, 44, 32, 114, 101, 115, 111, 117, 114, 99, 101, 76, 105, 109, 105, 116, 115, 58, 32, 108, 105, 109, 105, 116, 115, 44, 32, 115, 116, 100, 105, 110, 58, 32, 116, 114, 117, 101, 32, 125, 41, 59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[33]; } g_heff_2eemit_2enodeRun_str17 = {{0x80000000u, K_STR, 0}, 33, 33, {32, 32, 108, 101, 116, 32, 112, 105, 112, 101, 100, 32, 61, 32, 102, 97, 108, 115, 101, 44, 32, 101, 120, 101, 99, 32, 61, 32, 110, 117, 108, 108, 59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[55]; } g_heff_2eemit_2enodeRun_str18 = {{0x80000000u, K_STR, 0}, 55, 55, {32, 32, 105, 102, 32, 40, 112, 114, 111, 99, 101, 115, 115, 46, 115, 116, 100, 111, 117, 116, 46, 105, 115, 84, 84, 89, 41, 32, 112, 114, 111, 99, 101, 115, 115, 46, 101, 110, 118, 46, 72, 69, 70, 70, 95, 84, 84, 89, 32, 61, 32, 34, 49, 34, 59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[109]; } g_heff_2eemit_2enodeRun_str19 = {{0x80000000u, K_STR, 0}, 109, 109, {32, 32, 99, 111, 110, 115, 116, 32, 108, 105, 109, 105, 116, 115, 32, 61, 32, 123, 32, 115, 116, 97, 99, 107, 83, 105, 122, 101, 77, 98, 58, 32, 53, 49, 50, 44, 32, 109, 97, 120, 79, 108, 100, 71, 101, 110, 101, 114, 97, 116, 105, 111, 110, 83, 105, 122, 101, 77, 98, 58, 32, 78, 117, 109, 98, 101, 114, 40, 112, 114, 111, 99, 101, 115, 115, 46, 101, 110, 118, 46, 72, 69, 70, 70, 95, 72, 69, 65, 80, 95, 77, 66, 41, 32, 124, 124, 32, 117, 110, 100, 101, 102, 105, 110, 101, 100, 32, 125, 59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[20]; } g_heff_2eemit_2enodeRun_str20 = {{0x80000000u, K_STR, 0}, 20, 20, {105, 102, 32, 40, 36, 105, 115, 77, 97, 105, 110, 84, 104, 114, 101, 97, 100, 41, 32, 123}};
Clo g_heff_2eemit_2enodeRun_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemit_2enodeRun_entry, 1, 0};

V g_heff_2eemit_2enodeRun(V v_run_240) {
top: ;
  V v_t_241 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemit_2enodeRun_str0), NTAG(TAG_Nil)});
  V v_t_242 = heff_tag(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2eemit_2enodeRun_str1), v_run_240), v_t_241});
  V v_t_243 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemit_2enodeRun_str2), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemit_2enodeRun_str3), v_t_242})});
  V v_t_244 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemit_2enodeRun_str4), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemit_2enodeRun_str5), v_t_243})});
  V v_t_245 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemit_2enodeRun_str6), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemit_2enodeRun_str7), v_t_244})});
  V v_t_246 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemit_2enodeRun_str8), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemit_2enodeRun_str9), v_t_245})});
  V v_t_247 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemit_2enodeRun_str10), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemit_2enodeRun_str11), v_t_246})});
  V v_t_248 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemit_2enodeRun_str12), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemit_2enodeRun_str13), v_t_247})});
  V v_t_249 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemit_2enodeRun_str14), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemit_2enodeRun_str15), v_t_248})});
  V v_t_2410 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemit_2enodeRun_str16), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemit_2enodeRun_str17), v_t_249})});
  V v_t_2411 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemit_2enodeRun_str18), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemit_2enodeRun_str19), v_t_2410})});
  return ({ V a_0 = ((V)&g_heff_2eemit_2enodeRun_str20); V a_1 = v_t_2411; V r_ = (g_prelude_2efoldl_24s3(a_0, a_1)); heff_drop_tag(v_t_2411, 2); r_; });
}
V g_heff_2eemit_2enodeRun_entry(V self, V *a) {
  (void)self;
  return g_heff_2eemit_2enodeRun(a[0]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eemit_2erunSource_str0 = {{0x80000000u, K_STR, 0}, 4, 4, {110, 111, 100, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[42]; } g_heff_2eemit_2erunSource_str1 = {{0x80000000u, K_STR, 0}, 42, 42, {47, 47, 32, 71, 101, 110, 101, 114, 97, 116, 101, 100, 32, 102, 114, 111, 109, 32, 72, 105, 112, 112, 111, 103, 114, 105, 102, 102, 59, 32, 100, 111, 32, 110, 111, 116, 32, 101, 100, 105, 116, 46}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2eemit_2erunSource_str2 = {{0x80000000u, K_STR, 0}, 9, 9, {117, 110, 100, 101, 102, 105, 110, 101, 100}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemit_2erunSource_str3 = {{0x80000000u, K_STR, 0}, 2, 2, {36, 99}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemit_2erunSource_str4 = {{0x80000000u, K_STR, 0}, 2, 2, {40, 41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[11]; } g_heff_2eemit_2erunSource_str5 = {{0x80000000u, K_STR, 0}, 11, 11, {36, 114, 117, 110, 40, 40, 41, 32, 61, 62, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemit_2erunSource_str6 = {{0x80000000u, K_STR, 0}, 2, 2, {44, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemit_2erunSource_str7 = {{0x80000000u, K_STR, 0}, 2, 2, {41, 59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eemit_2erunSource_str8 = {{0x80000000u, K_STR, 0}, 4, 4, {110, 111, 100, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2erunSource_str9 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2erunSource_str10 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[4]; } g_heff_2eemit_2erunSource_str11 = {{0x80000000u, K_STR, 0}, 4, 4, {112, 97, 103, 101}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2erunSource_str12 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[13]; } g_heff_2eemit_2erunSource_str13 = {{0x80000000u, K_STR, 0}, 13, 13, {34, 117, 115, 101, 32, 115, 116, 114, 105, 99, 116, 34, 59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eemit_2erunSource_str14 = {{0x80000000u, K_STR, 0}, 5, 5, {125, 41, 40, 41, 59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[8]; } g_heff_2eemit_2erunSource_str15 = {{0x80000000u, K_STR, 0}, 8, 8, {40, 40, 41, 32, 61, 62, 32, 123}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2erunSource_str16 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2erunSource_str17 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
Clo g_heff_2eemit_2erunSource_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemit_2erunSource_entry, 5, 0};

V g_heff_2eemit_2erunSource(V v_host_240, V v_provs_241, V v_eff_242, V v_key_243, V v_m_244) {
top: ;
  V v_t_245 = heff_strEq(heff_dup(v_host_240), ((V)&g_heff_2eemit_2erunSource_str0));
  V v_t_246;
  switch (heff_tag_of(v_t_245)) {
  case TAG_True: {
    v_t_246 = heff_dup(g_heff_2eemit_2enodeHead_get());
    break;
  }
  case TAG_False: {
    v_t_246 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemit_2erunSource_str1), NTAG(TAG_Nil)});
    break;
  }
  default: heff_nomatch(v_t_245);
  }
  V v_xs_247 = (g_heff_2eemit_2eimportLinesOf(v_provs_241));
  V v_t_248 = (g_heff_2eemit_2enubGo(NTAG(TAG_Nil), v_xs_247));
  V v_t_249 = ({ V b_0 = heff_get(heff_dup(v_m_244), LBL_lines); V r_ = (g_prelude_2eany_24s615(b_0)); heff_drop(b_0); r_; });
  V v_t_2410 = ({ V a_0 = v_t_249; V a_1 = heff_dup(v_provs_241); V a_2 = heff_dup(v_eff_242); V r_ = (g_heff_2eemit_2eruntimeFor(a_0, a_1, a_2)); heff_drop(v_t_249); r_; });
  V v_t_2411 = ({ V a_0 = heff_dup(g_heff_2elower_2eentryKey_get()); V b_1 = heff_get(heff_dup(v_m_244), LBL_globals); V r_ = (g_map_2elookup_24s8(a_0, b_1)); heff_drop(b_1); r_; });
  V v_t_2415;
  switch (heff_tag_of(v_t_2411)) {
  case TAG_Nothing: {
    v_t_2415 = ((V)&g_heff_2eemit_2erunSource_str2);
    break;
  }
  case TAG_Just: {
    V v_i_2412 = heff_field(v_t_2411, 0);
    heff_take_n(v_t_2411, 1ULL, 1);
    V v_t_2413 = heff_intLe(MK_INT(2LL), heff_get(heff_dup(v_i_2412), LBL_arity));
    switch (heff_tag_of(v_t_2413)) {
    case TAG_True: {
      v_t_2415 = heff_strAppend(heff_get(v_i_2412, LBL_js), ((V)&g_heff_2eemit_2erunSource_str3));
      break;
    }
    case TAG_False: {
      V v_t_2414 = heff_get(heff_dup(v_i_2412), LBL_lazy);
      switch (heff_tag_of(v_t_2414)) {
      case TAG_True: {
        v_t_2415 = heff_strAppend(heff_get(v_i_2412, LBL_js), ((V)&g_heff_2eemit_2erunSource_str4));
        break;
      }
      case TAG_False: {
        v_t_2415 = heff_get(v_i_2412, LBL_js);
        break;
      }
      default: heff_nomatch(v_t_2414);
      }
      break;
    }
    default: heff_nomatch(v_t_2413);
    }
    break;
  }
  default: heff_nomatch(v_t_2411);
  }
  V v_t_2416 = ({ V a_0 = v_provs_241; V a_1 = v_eff_242; V r_ = (g_heff_2eemit_2ehandlerOf(a_0, a_1)); heff_drop(v_provs_241); heff_drop(v_eff_242); r_; });
  V v_run_2417 = heff_strAppend(((V)&g_heff_2eemit_2erunSource_str5), heff_strAppend(v_t_2415, heff_strAppend(((V)&g_heff_2eemit_2erunSource_str6), heff_strAppend(v_t_2416, ((V)&g_heff_2eemit_2erunSource_str7)))));
  V v_t_2418 = heff_strEq(heff_dup(v_host_240), ((V)&g_heff_2eemit_2erunSource_str8));
  V v_t_2419;
  switch (heff_tag_of(v_t_2418)) {
  case TAG_True: {
    v_t_2419 = (g_heff_2eemit_2enodeRun(v_run_2417));
    break;
  }
  case TAG_False: {
    v_t_2419 = v_run_2417;
    break;
  }
  default: heff_nomatch(v_t_2418);
  }
  V v_t_2420 = heff_tag(TAG_Cons, 2, (V[]){v_t_2419, NTAG(TAG_Nil)});
  V v_t_2421 = heff_tag(TAG_Cons, 2, (V[]){v_t_2410, heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemit_2erunSource_str9), v_t_2420})});
  V v_body_2422 = (g_prelude_2econcatList(heff_get(v_m_244, LBL_lines), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemit_2erunSource_str10), v_t_2421})));
  V v_t_2423 = heff_strEq(v_host_240, ((V)&g_heff_2eemit_2erunSource_str11));
  V v_t_2427;
  switch (heff_tag_of(v_t_2423)) {
  case TAG_True: {
    V v_t_2424 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemit_2erunSource_str12), NTAG(TAG_Nil)});
    V v_t_2425 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemit_2erunSource_str13), (g_prelude_2econcatList(v_body_2422, heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemit_2erunSource_str14), v_t_2424})))});
    v_t_2427 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemit_2erunSource_str15), v_t_2425});
    break;
  }
  case TAG_False: {
    V v_t_2426 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemit_2erunSource_str16), NTAG(TAG_Nil)});
    v_t_2427 = (g_prelude_2econcatList(v_body_2422, v_t_2426));
    break;
  }
  default: heff_nomatch(v_t_2423);
  }
  V v_t_2428 = (g_prelude_2econcatList(v_t_248, v_t_2427));
  V v_x2_2429 = (g_prelude_2econcatList(v_t_246, v_t_2428));
  switch (heff_tag_of(v_x2_2429)) {
  case TAG_Nil: {
    return ((V)&g_heff_2eemit_2erunSource_str17);
  }
  case TAG_Cons: {
    V v_x_2430 = heff_field(v_x2_2429, 0);
    V v_xs_2431 = heff_field(v_x2_2429, 1);
    heff_take_n(v_x2_2429, 3ULL, 2);
    return ({ V a_0 = v_x_2430; V a_1 = v_xs_2431; V r_ = (g_prelude_2efoldl_24s3(a_0, a_1)); heff_drop(v_xs_2431); r_; });
  }
  default: return heff_nomatch(v_x2_2429);
  }
}
V g_heff_2eemit_2erunSource_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eemit_2erunSource(a[0], a[1], a[2], a[3], a[4]); heff_drop(a[3]); return r;
}
Clo g_heff_2eemit_2ecompileProgram_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemit_2ecompileProgram_entry, 5, 0};

V g_heff_2eemit_2ecompileProgram(V v_host_240, V v_available_241, V v_g_242, V v_key_243, V v_eff_244) {
top: ;
  V v_t_245 = (g_heff_2eeffect_2eleaves(v_eff_244));
  V v_xs_246 = (g_prelude_2emap_24s613(v_t_245));
  V v_t_247 = (g_heff_2eemit_2enubGo(NTAG(TAG_Nil), v_xs_246));
  V v_provs_248 = (g_heff_2eemit_2eprovsForGo(v_available_241, v_t_247));
  V v_l_249 = (g_heff_2elower_2elowerProgram(v_g_242, heff_dup(v_key_243)));
  V v_defs_2410 = heff_get(heff_dup(v_l_249), LBL_defs);
  V v_t_2411 = heff_tag(TAG_Cons, 2, (V[]){heff_dup(g_heff_2elower_2eentryKey_get()), NTAG(TAG_Nil)});
  V v_t_2412 = (g_prelude_2emap_24s605(heff_dup(v_defs_2410)));
  V v_t_2413 = (g_heff_2eemit_2eemitWithShorts(v_defs_2410, v_t_2411, v_t_2412));
  V v_t_2414 = ({ V a_0 = v_host_240; V a_1 = v_provs_248; V a_2 = v_eff_244; V a_3 = v_key_243; V a_4 = v_t_2413; V r_ = (g_heff_2eemit_2erunSource(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_key_243); r_; });
  return heff_rec(2, shape_311_89, (V[]){v_t_2414, heff_get(v_l_249, LBL_errors)});
}
V g_heff_2eemit_2ecompileProgram_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eemit_2ecompileProgram(a[0], a[1], a[2], a[3], a[4]); heff_drop(a[1]); return r;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2egetterOf_str0 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2egetterOf_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2egetterOf_str2 = {{0x80000000u, K_STR, 0}, 1, 1, {34}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[9]; } g_heff_2eemit_2egetterOf_str3 = {{0x80000000u, K_STR, 0}, 9, 9, {117, 110, 100, 101, 102, 105, 110, 101, 100}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemit_2egetterOf_str4 = {{0x80000000u, K_STR, 0}, 2, 2, {36, 99}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemit_2egetterOf_str5 = {{0x80000000u, K_STR, 0}, 2, 2, {40, 41}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[6]; } g_heff_2eemit_2egetterOf_str6 = {{0x80000000u, K_STR, 0}, 6, 6, {32, 32, 103, 101, 116, 32}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[17]; } g_heff_2eemit_2egetterOf_str7 = {{0x80000000u, K_STR, 0}, 17, 17, {40, 41, 32, 123, 32, 114, 101, 116, 117, 114, 110, 32, 36, 101, 120, 116, 40}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[5]; } g_heff_2eemit_2egetterOf_str8 = {{0x80000000u, K_STR, 0}, 5, 5, {41, 59, 32, 125, 44}};
Clo g_heff_2eemit_2egetterOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemit_2egetterOf_entry, 2, 0};

V g_heff_2eemit_2egetterOf(V v_gs_240, V v_o_241) {
top: ;
  V v_x_242 = heff_get(heff_dup(v_o_241), LBL_name);
  V v_t_243 = (g_heff_2eemit_2eisIdent(heff_dup(v_x_242)));
  V v_t_245;
  switch (heff_tag_of(v_t_243)) {
  case TAG_True: {
    v_t_245 = v_x_242;
    break;
  }
  case TAG_False: {
    V v_t_244 = (g_heff_2eemit_2equoteGo(v_x_242, MK_INT(0LL), ((V)&g_heff_2eemit_2egetterOf_str0)));
    v_t_245 = heff_strAppend(((V)&g_heff_2eemit_2egetterOf_str1), heff_strAppend(v_t_244, ((V)&g_heff_2eemit_2egetterOf_str2)));
    break;
  }
  default: heff_nomatch(v_t_243);
  }
  V v_t_246 = (g_map_2elookup_24s8(heff_get(v_o_241, LBL_key), v_gs_240));
  V v_t_2410;
  switch (heff_tag_of(v_t_246)) {
  case TAG_Nothing: {
    v_t_2410 = ((V)&g_heff_2eemit_2egetterOf_str3);
    break;
  }
  case TAG_Just: {
    V v_i_247 = heff_field(v_t_246, 0);
    heff_take_n(v_t_246, 1ULL, 1);
    V v_t_248 = heff_intLe(MK_INT(2LL), heff_get(heff_dup(v_i_247), LBL_arity));
    switch (heff_tag_of(v_t_248)) {
    case TAG_True: {
      v_t_2410 = heff_strAppend(heff_get(v_i_247, LBL_js), ((V)&g_heff_2eemit_2egetterOf_str4));
      break;
    }
    case TAG_False: {
      V v_t_249 = heff_get(heff_dup(v_i_247), LBL_lazy);
      switch (heff_tag_of(v_t_249)) {
      case TAG_True: {
        v_t_2410 = heff_strAppend(heff_get(v_i_247, LBL_js), ((V)&g_heff_2eemit_2egetterOf_str5));
        break;
      }
      case TAG_False: {
        v_t_2410 = heff_get(v_i_247, LBL_js);
        break;
      }
      default: heff_nomatch(v_t_249);
      }
      break;
    }
    default: heff_nomatch(v_t_248);
    }
    break;
  }
  default: heff_nomatch(v_t_246);
  }
  return heff_strAppend(((V)&g_heff_2eemit_2egetterOf_str6), heff_strAppend(v_t_245, heff_strAppend(((V)&g_heff_2eemit_2egetterOf_str7), heff_strAppend(v_t_2410, ((V)&g_heff_2eemit_2egetterOf_str8)))));
}
V g_heff_2eemit_2egetterOf_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2eemit_2egetterOf(a[0], a[1]); heff_drop(a[0]); return r;
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[42]; } g_heff_2eemit_2ejsSource_str0 = {{0x80000000u, K_STR, 0}, 42, 42, {47, 47, 32, 71, 101, 110, 101, 114, 97, 116, 101, 100, 32, 102, 114, 111, 109, 32, 72, 105, 112, 112, 111, 103, 114, 105, 102, 102, 59, 32, 100, 111, 32, 110, 111, 116, 32, 101, 100, 105, 116, 46}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[16]; } g_heff_2eemit_2ejsSource_str1 = {{0x80000000u, K_STR, 0}, 16, 16, {101, 120, 112, 111, 114, 116, 32, 100, 101, 102, 97, 117, 108, 116, 32, 123}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2ejsSource_str2 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2ejsSource_str3 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2ejsSource_str4 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[2]; } g_heff_2eemit_2ejsSource_str5 = {{0x80000000u, K_STR, 0}, 2, 2, {125, 59}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2eemit_2ejsSource_str6 = {{0x80000000u, K_STR, 0}, 0, 0, {0}};
V g_heff_2eemit_2ejsSource_lam0(V self, V *args);
V g_heff_2eemit_2ejsSource_lam1(V self, V *args);
Clo g_heff_2eemit_2ejsSource_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemit_2ejsSource_entry, 2, 0};

V g_heff_2eemit_2ejsSource(V v_exports_240, V v_m_241) {
top: ;
  V v_t_242 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemit_2ejsSource_str0), NTAG(TAG_Nil)});
  V v_t_243 = ({ V b_0 = heff_get(heff_dup(v_m_241), LBL_lines); V r_ = (g_prelude_2eany_24s615(b_0)); heff_drop(b_0); r_; });
  V v_t_244;
  switch (heff_tag_of(v_t_243)) {
  case TAG_True: {
    v_t_244 = NTAG(TAG_Nil);
    break;
  }
  case TAG_False: {
    v_t_244 = heff_tag(TAG_Cons, 2, (V[]){heff_dup(g_heff_2eemit_2etrampolineStr_get()), NTAG(TAG_Nil)});
    break;
  }
  default: heff_nomatch(v_t_243);
  }
  V v_t_245 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemit_2ejsSource_str1), NTAG(TAG_Nil)});
  V v_t_246 = heff_tag(TAG_Cons, 2, (V[]){heff_dup(g_heff_2eemit_2eextStr_get()), heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemit_2ejsSource_str2), v_t_245})});
  V v_t_247 = (g_prelude_2econcatList(v_t_244, heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemit_2ejsSource_str3), v_t_246})));
  V v_t_2411 = (g_prelude_2efilter(heff_clo(g_heff_2eemit_2ejsSource_lam0, 1, 1, (V[]){heff_dup(v_m_241)}), v_exports_240));
  V v_t_2413 = (g_prelude_2emap(heff_clo(g_heff_2eemit_2ejsSource_lam1, 1, 1, (V[]){heff_dup(v_m_241)}), v_t_2411));
  V v_t_2414 = heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemit_2ejsSource_str4), NTAG(TAG_Nil)});
  V v_t_2415 = (g_prelude_2econcatList(v_t_2413, heff_tag(TAG_Cons, 2, (V[]){((V)&g_heff_2eemit_2ejsSource_str5), v_t_2414})));
  V v_t_2416 = (g_prelude_2econcatList(v_t_247, v_t_2415));
  V v_t_2417 = (g_prelude_2econcatList(heff_get(v_m_241, LBL_lines), v_t_2416));
  V v_x2_2418 = (g_prelude_2econcatList(v_t_242, v_t_2417));
  switch (heff_tag_of(v_x2_2418)) {
  case TAG_Nil: {
    return ((V)&g_heff_2eemit_2ejsSource_str6);
  }
  case TAG_Cons: {
    V v_x_2419 = heff_field(v_x2_2418, 0);
    V v_xs_2420 = heff_field(v_x2_2418, 1);
    heff_take_n(v_x2_2418, 3ULL, 2);
    return ({ V a_0 = v_x_2419; V a_1 = v_xs_2420; V r_ = (g_prelude_2efoldl_24s3(a_0, a_1)); heff_drop(v_xs_2420); r_; });
  }
  default: return heff_nomatch(v_x2_2418);
  }
}
V g_heff_2eemit_2ejsSource_entry(V self, V *a) {
  (void)self;
  return g_heff_2eemit_2ejsSource(a[0], a[1]);
}
V g_heff_2eemit_2ejsSource_lam0(V self, V *args) {
  V v_o_248 = args[0];
  V v_m_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_x3_249 = ({ V a_0 = heff_get(v_o_248, LBL_key); V b_1 = heff_get(v_m_241, LBL_globals); V r_ = (g_map_2elookup_24s9(a_0, b_1)); heff_drop(b_1); r_; });
  switch (heff_tag_of(v_x3_249)) {
  case TAG_Nothing: {
    return NTAG(TAG_False);
  }
  case TAG_Just: {
    heff_take_n(v_x3_249, 0ULL, 1);
    return NTAG(TAG_True);
  }
  default: return heff_nomatch(v_x3_249);
  }
}
V g_heff_2eemit_2ejsSource_lam1(V self, V *args) {
  V v_o_2412 = args[0];
  V v_m_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get(v_m_241, LBL_globals); V a_1 = v_o_2412; V r_ = (g_heff_2eemit_2egetterOf(b_0, a_1)); heff_drop(b_0); r_; });
}
Clo g_heff_2eemit_2ecompileJsWith_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemit_2ecompileJsWith_entry, 2, 0};

V g_heff_2eemit_2ecompileJsWith(V v_g_240, V v_exports_241) {
top: ;
  V v_roots_242 = (g_prelude_2emap_24s484(heff_dup(v_exports_241)));
  V v_t_243 = (g_heff_2eerase_2eeraseProgram(v_g_240));
  V v_l_244 = (g_heff_2elower_2elowerErased(v_roots_242, v_t_243));
  V v_defs_245 = heff_get(heff_dup(v_l_244), LBL_defs);
  V v_roots_246 = (g_prelude_2emap_24s484(heff_dup(v_exports_241)));
  V v_t_247 = (g_prelude_2emap_24s605(heff_dup(v_defs_245)));
  V v_t_248 = (g_heff_2eemit_2eemitWithShorts(v_defs_245, v_roots_246, v_t_247));
  V v_t_249 = (g_heff_2eemit_2ejsSource(v_exports_241, v_t_248));
  return heff_rec(2, shape_311_89, (V[]){v_t_249, heff_get(v_l_244, LBL_errors)});
}
V g_heff_2eemit_2ecompileJsWith_entry(V self, V *a) {
  (void)self;
  return g_heff_2eemit_2ecompileJsWith(a[0], a[1]);
}
V g_heff_2eemit_2ecompileJs_lam0(V self, V *args);
Clo g_heff_2eemit_2ecompileJs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eemit_2ecompileJs_entry, 2, 0};

V g_heff_2eemit_2ecompileJs(V v_g_240, V v_exports0_241) {
top: ;
  V v_t_249;
  switch (heff_tag_of(v_exports0_241)) {
  case TAG_Nil: {
    V v_t_246 = ({ V a_0 = heff_clo(g_heff_2eemit_2ecompileJs_lam0, 2, 1, (V[]){heff_dup(v_g_240)}); V a_1 = NTAG(TAG_Nil); V b_2 = heff_get(heff_dup(v_g_240), LBL_order); V r_ = (g_prelude_2efoldl(a_0, a_1, b_2)); heff_drop(b_2); r_; });
    v_t_249 = (g_prelude_2emap_24s616(v_t_246));
    break;
  }
  case TAG_Cons: {
    v_t_249 = v_exports0_241;
    break;
  }
  default: heff_nomatch(v_exports0_241);
  }
  HEFF_LAST return g_heff_2eemit_2ecompileJsWith(v_g_240, v_t_249);
}
V g_heff_2eemit_2ecompileJs_entry(V self, V *a) {
  (void)self;
  return g_heff_2eemit_2ecompileJs(a[0], a[1]);
}
V g_heff_2eemit_2ecompileJs_lam0(V self, V *args) {
  V v_acc_242 = args[0];
  V v_k_243 = args[1];
  V v_g_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_244 = ({ V a_0 = heff_dup(v_k_243); V b_1 = heff_get(v_g_240, LBL_entries); V r_ = (g_map_2elookup_24s8(a_0, b_1)); heff_drop(b_1); r_; });
  switch (heff_tag_of(v_t_244)) {
  case TAG_Nothing: {
    heff_drop(v_k_243);
    return v_acc_242;
  }
  case TAG_Just: {
    V v_e_245 = heff_field(v_t_244, 0);
    heff_take_n(v_t_244, 1ULL, 1);
    return heff_tag(TAG_Cons, 2, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_k_243, v_e_245}), v_acc_242});
  }
  default: return heff_nomatch(v_t_244);
  }
}