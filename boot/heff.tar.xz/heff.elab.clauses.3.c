// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_ArgExplicit 50404
#define TAG_ArgNamed 38772
#define TAG_ArgProject 7906
#define TAG_At 8900
#define TAG_BadFieldDecl 11244
#define TAG_BadFieldSet 46507
#define TAG_CAbandon 30933
#define TAG_CAnnLam 19336
#define TAG_CImplicitLam 42557
#define TAG_CInf 46723
#define TAG_CLam 49210
#define TAG_CLetIn 34208
#define TAG_CLocal 54419
#define TAG_CMatch 53053
#define TAG_CNominal 13722
#define TAG_CStruct 46588
#define TAG_CTag 56892
#define TAG_CType 17595
#define TAG_DeclDefine 5286
#define TAG_DeclEquations 25755
#define TAG_DeclPrimitive 46335
#define TAG_DeclTest 38719
#define TAG_DeclTheory 39552
#define TAG_DeclWatch 51419
#define TAG_DeclareField 57313
#define TAG_IApp 21275
#define TAG_IVar 40993
#define TAG_Left 13886
#define TAG_MkAlt 55173
#define TAG_MkFieldPat 14710
#define TAG_PAs 26446
#define TAG_PLit 43592
#define TAG_PRec 49217
#define TAG_PTag 51019
#define TAG_PVar 52952
#define TAG_PatAs 19989
#define TAG_PatBytes 60255
#define TAG_PatFloat 20302
#define TAG_PatInt 37275
#define TAG_PatOp 20420
#define TAG_PatRecord 42380
#define TAG_PatRune 53941
#define TAG_PatString 45794
#define TAG_PatTag 47430
#define TAG_PatVar 49363
#define TAG_PatWord 675
#define TAG_Right 62770
#define TAG_SetField 47531
#define TAG_TArray 58932
#define TAG_TChk 23015
#define TAG_TFixed 24045
#define TAG_TFloat 39135
#define TAG_TInf 28962
#define TAG_TInt 28976
#define TAG_TNominal 22139
#define TAG_TPi 30745
#define TAG_TRune 58776
#define TAG_TSig 38418
#define TAG_TString 39883
#define TAG_TSum 38796
#define TAG_TType 56738
#define LBL_chk 308000
#define LBL_decl 9574769
#define LBL_end 310101
#define LBL_inf 313947
#define LBL_msg 317947
#define LBL_pats 9928951
#define LBL_rhs 322423
#define LBL_span 10032145
#define LBL_start 311115900
#define LBL_typ 324869
#define LBL_v 336
#define LBL_x 338
static uint32_t shape_pats__rhs[] = {LBL_pats, LBL_rhs};
static uint32_t shape_span__msg[] = {LBL_span, LBL_msg};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
static uint32_t shape_x__v__inf__chk__typ[] = {LBL_x, LBL_v, LBL_inf, LBL_chk, LBL_typ};
static V prim_strEq_entry(V self, V *a) { (void)self; return heff_strEq(a[0], a[1]); }
static Clo prim_strEq_clo = {{0x80000000u, K_CLO, 0}, prim_strEq_entry, 2, 0};
V g_heff_2eelab_2eclauses_2eanyC(V, V);
V g_heff_2eelab_2eclauses_2eanyC_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2eanyC_clo;
V g_heff_2eelab_2eclauses_2eappendC(V, V);
V g_heff_2eelab_2eclauses_2eappendC_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2eappendC_clo;
V g_heff_2eelab_2eclauses_2eappendC_24f668644975x857714735(V, V);
V g_heff_2eelab_2eclauses_2eappendC_24f668644975x857714735_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2eappendC_24f668644975x857714735_clo;
V g_heff_2eelab_2eclauses_2eappendC_24f668644975x857714735_24dps(V, V, V);
V g_heff_2eelab_2eclauses_2eappendC_24f668644975x857714735_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2eappendC_24f668644975x857714735_24dps_clo;
V g_heff_2eelab_2eclauses_2earmSubName(V, V, V, V, V);
V g_heff_2eelab_2eclauses_2earmSubName_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2earmSubName_clo;
V g_heff_2eelab_2eclauses_2ecatMaybesC(V);
V g_heff_2eelab_2eclauses_2ecatMaybesC_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2ecatMaybesC_clo;
V g_heff_2eelab_2eclauses_2ecolPick(V, V, V);
V g_heff_2eelab_2eclauses_2ecolPick_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2ecolPick_clo;
V g_heff_2eelab_2eclauses_2ecompilePeeled_24s1600111562x907923193(V, V, V, V, V);
V g_heff_2eelab_2eclauses_2ecompilePeeled_24s1600111562x907923193_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2ecompilePeeled_24s1600111562x907923193_clo;
V g_heff_2eelab_2eclauses_2econcatMapC_24s1253148850x1225196638(V);
V g_heff_2eelab_2eclauses_2econcatMapC_24s1253148850x1225196638_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2econcatMapC_24s1253148850x1225196638_clo;
V g_heff_2eelab_2eclauses_2econcatMapC_24s357394064x1182638230(V);
V g_heff_2eelab_2eclauses_2econcatMapC_24s357394064x1182638230_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2econcatMapC_24s357394064x1182638230_clo;
V g_heff_2eelab_2eclauses_2econcatMapC_24s497393573x331502823(V);
V g_heff_2eelab_2eclauses_2econcatMapC_24s497393573x331502823_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2econcatMapC_24s497393573x331502823_clo;
V g_heff_2eelab_2eclauses_2edropAt(V, V);
V g_heff_2eelab_2eclauses_2edropAt_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2edropAt_clo;
V g_heff_2eelab_2eclauses_2edropAt_24dps(V, V, V);
V g_heff_2eelab_2eclauses_2edropAt_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2edropAt_24dps_clo;
V g_heff_2eelab_2eclauses_2edropC(V, V);
V g_heff_2eelab_2eclauses_2edropC_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2edropC_clo;
V g_heff_2eelab_2eclauses_2eforC(V, V);
V g_heff_2eelab_2eclauses_2eforC_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2eforC_clo;
V g_heff_2eelab_2eclauses_2efresh(V, V);
V g_heff_2eelab_2eclauses_2efresh_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2efresh_clo;
V g_heff_2eelab_2eclauses_2efreshIn(V, V, V);
V g_heff_2eelab_2eclauses_2efreshIn_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2efreshIn_clo;
V g_heff_2eelab_2eclauses_2eidents_get(void);
V g_heff_2eelab_2eclauses_2eidentsChkF(V, V, V);
V g_heff_2eelab_2eclauses_2eidentsChkF_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2eidentsChkF_clo;
V g_heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291(V, V);
V g_heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291_clo;
V g_heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291_24dps(V, V, V);
V g_heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291_24dps_clo;
V g_heff_2eelab_2eclauses_2eidentsInfF_24s869152224x1503528648(V, V);
V g_heff_2eelab_2eclauses_2eidentsInfF_24s869152224x1503528648_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2eidentsInfF_24s869152224x1503528648_clo;
V g_heff_2eelab_2eclauses_2eidentsTypF_24s506476740x533987156(V, V);
V g_heff_2eelab_2eclauses_2eidentsTypF_24s506476740x533987156_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2eidentsTypF_24s506476740x533987156_clo;
V g_heff_2eelab_2eclauses_2eletFields(V, V, V, V);
V g_heff_2eelab_2eclauses_2eletFields_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2eletFields_clo;
V g_heff_2eelab_2eclauses_2elitYesOne(V, V, V, V, V);
V g_heff_2eelab_2eclauses_2elitYesOne_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2elitYesOne_clo;
V g_heff_2eelab_2eclauses_2elookupField(V, V);
V g_heff_2eelab_2eclauses_2elookupField_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2elookupField_clo;
V g_heff_2eelab_2eclauses_2enamesOfAll(V, V, V);
V g_heff_2eelab_2eclauses_2enamesOfAll_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2enamesOfAll_clo;
V g_heff_2eelab_2eclauses_2enamesOfAll_24s1471250105x438377350(V, V);
V g_heff_2eelab_2eclauses_2enamesOfAll_24s1471250105x438377350_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2enamesOfAll_24s1471250105x438377350_clo;
V g_heff_2eelab_2eclauses_2enamesOfAll_24s2067092643x645415179(V, V);
V g_heff_2eelab_2eclauses_2enamesOfAll_24s2067092643x645415179_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2enamesOfAll_24s2067092643x645415179_clo;
V g_heff_2eelab_2eclauses_2enamesOfAll_24s2127598839x230588173(V, V);
V g_heff_2eelab_2eclauses_2enamesOfAll_24s2127598839x230588173_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2enamesOfAll_24s2127598839x230588173_clo;
V g_heff_2eelab_2eclauses_2enamesOfAll_24s291844836x707424588(V, V);
V g_heff_2eelab_2eclauses_2enamesOfAll_24s291844836x707424588_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2enamesOfAll_24s291844836x707424588_clo;
V g_heff_2eelab_2eclauses_2enamesOfAll_24s613549782x1232950246(V, V);
V g_heff_2eelab_2eclauses_2enamesOfAll_24s613549782x1232950246_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2enamesOfAll_24s613549782x1232950246_clo;
V g_heff_2eelab_2eclauses_2enamesOfAll_24s638847411x1828905680(V, V);
V g_heff_2eelab_2eclauses_2enamesOfAll_24s638847411x1828905680_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2enamesOfAll_24s638847411x1828905680_clo;
V g_heff_2eelab_2eclauses_2enamesOfAll_24s880313170x30977071(V, V);
V g_heff_2eelab_2eclauses_2enamesOfAll_24s880313170x30977071_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2enamesOfAll_24s880313170x30977071_clo;
V g_heff_2eelab_2eclauses_2enoLitHere(V, V, V);
V g_heff_2eelab_2eclauses_2enoLitHere_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2enoLitHere_clo;
V g_heff_2eelab_2eclauses_2enoRecMix(V, V);
V g_heff_2eelab_2eclauses_2enoRecMix_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2enoRecMix_clo;
V g_heff_2eelab_2eclauses_2enthC(V, V);
V g_heff_2eelab_2eclauses_2enthC_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2enthC_clo;
V g_heff_2eelab_2eclauses_2enubStr(V);
V g_heff_2eelab_2eclauses_2enubStr_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2enubStr_clo;
V g_heff_2eelab_2eclauses_2enubStr_24dps(V, V);
V g_heff_2eelab_2eclauses_2enubStr_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2enubStr_24dps_clo;
V g_heff_2eelab_2eclauses_2epatBinds(V);
V g_heff_2eelab_2eclauses_2epatBinds_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2epatBinds_clo;
V g_heff_2eelab_2eclauses_2epatIdents(V, V);
V g_heff_2eelab_2eclauses_2epatIdents_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2epatIdents_clo;
V g_heff_2eelab_2eclauses_2epatIdents_24dps(V, V, V);
V g_heff_2eelab_2eclauses_2epatIdents_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2epatIdents_24dps_clo;
V g_heff_2eelab_2eclauses_2epatVars(V);
V g_heff_2eelab_2eclauses_2epatVars_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2epatVars_clo;
V g_heff_2eelab_2eclauses_2epeelAs(V, V, V);
V g_heff_2eelab_2eclauses_2epeelAs_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2epeelAs_clo;
V g_heff_2eelab_2eclauses_2epeelCols(V, V, V);
V g_heff_2eelab_2eclauses_2epeelCols_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2epeelCols_clo;
V g_heff_2eelab_2eclauses_2epiIdents_24s20744116x2053008297(V, V);
V g_heff_2eelab_2eclauses_2epiIdents_24s20744116x2053008297_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2epiIdents_24s20744116x2053008297_clo;
V g_heff_2eelab_2eclauses_2erecFieldVar(V, V, V);
V g_heff_2eelab_2eclauses_2erecFieldVar_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2erecFieldVar_clo;
V g_heff_2eelab_2eclauses_2erecSpecialize(V, V, V, V);
V g_heff_2eelab_2eclauses_2erecSpecialize_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2erecSpecialize_clo;
V g_heff_2eelab_2eclauses_2erecordWith_24s1263675322x1241970456(V, V, V, V, V, V, V, V);
V g_heff_2eelab_2eclauses_2erecordWith_24s1263675322x1241970456_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2erecordWith_24s1263675322x1241970456_clo;
V g_heff_2eelab_2eclauses_2erenameAlt(V, V);
V g_heff_2eelab_2eclauses_2erenameAlt_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2erenameAlt_clo;
V g_heff_2eelab_2eclauses_2erenameChkF(V, V);
V g_heff_2eelab_2eclauses_2erenameChkF_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2erenameChkF_clo;
V g_heff_2eelab_2eclauses_2erenameDecl(V, V);
V g_heff_2eelab_2eclauses_2erenameDecl_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2erenameDecl_clo;
V g_heff_2eelab_2eclauses_2erenameInfF(V, V);
V g_heff_2eelab_2eclauses_2erenameInfF_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2erenameInfF_clo;
V g_heff_2eelab_2eclauses_2erenameSeq(V, V, V);
V g_heff_2eelab_2eclauses_2erenameSeq_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2erenameSeq_clo;
V g_heff_2eelab_2eclauses_2erenameTypF(V, V);
V g_heff_2eelab_2eclauses_2erenameTypF_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2erenameTypF_clo;
V g_heff_2eelab_2eclauses_2erenamer(V, V);
V g_heff_2eelab_2eclauses_2erenamer_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2erenamer_clo;
V g_heff_2eelab_2eclauses_2esameLit(V, V);
V g_heff_2eelab_2eclauses_2esameLit_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2esameLit_clo;
V g_heff_2eelab_2eclauses_2etakeC(V, V);
V g_heff_2eelab_2eclauses_2etakeC_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2etakeC_clo;
V g_heff_2eelab_2eclauses_2etakeC_24dps(V, V, V);
V g_heff_2eelab_2eclauses_2etakeC_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2etakeC_24dps_clo;
V g_heff_2eelab_2eclauses_2eupToGo(V, V);
V g_heff_2eelab_2eclauses_2eupToGo_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2eupToGo_clo;
V g_heff_2eelab_2eclauses_2eupToGo_24dps(V, V, V);
V g_heff_2eelab_2eclauses_2eupToGo_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2eupToGo_24dps_clo;
V g_heff_2eelab_2eclauses_2ezipC(V, V);
V g_heff_2eelab_2eclauses_2ezipC_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2ezipC_clo;
V g_heff_2esyntax_2epresyntax_2elastOr(V, V);
V g_heff_2esyntax_2epresyntax_2elastOr_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2elastOr_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2efilter(V, V);
V g_list_2efilter_entry(V self, V *a);
extern Clo g_list_2efilter_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
Clo g_heff_2eelab_2eclauses_2eanyC_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2eanyC_entry, 2, 0};

V g_heff_2eelab_2eclauses_2eanyC(V v_p_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_p_240);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_t_244 = heff_tr(heff_call(heff_dup(v_p_240), 1, (V[]){heff_dup(v_x_242)}));
    if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
      heff_drop(v_p_240);
      heff_drop(v_t_244);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_244);
      V t_0 = v_p_240;
      V t_1 = v_xs_243;
      v_p_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eelab_2eclauses_2eanyC_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2eclauses_2eanyC(a[0], a1); heff_drop(a1); return r;
}
V g_heff_2eelab_2eclauses_2enubStr_lam0(V self, V *args);
Clo g_heff_2eelab_2eclauses_2enubStr_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2enubStr_entry, 1, 0};

V g_heff_2eelab_2eclauses_2enubStr(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x1_240, 0);
    V v_xs_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_cell_243 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_x_241), heff_hole()});
    V v_t_246 = (g_list_2efilter(heff_clo_n(g_heff_2eelab_2eclauses_2enubStr_lam0, 1, 1, (V[]){v_x_241}), v_xs_242));
    V v_u_247 = (g_heff_2eelab_2eclauses_2enubStr_24dps(v_t_246, heff_dup(v_cell_243)));
    heff_drop(v_u_247);
    return v_cell_243;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2eclauses_2enubStr_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2enubStr(a[0]);
}
V g_heff_2eelab_2eclauses_2enubStr_lam0(V self, V *args) {
  V v_y_244 = args[0];
  V v_x_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_ret_24bool = heff_bool(!heff_strEq_c(heff_dup(v_y_244), heff_dup(v_x_241)));
  heff_drop(v_y_244);
  heff_drop(v_x_241);
  return v_ret_24bool;
}
Clo g_heff_2eelab_2eclauses_2eupToGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2eupToGo_entry, 2, 0};

V g_heff_2eelab_2eclauses_2eupToGo(V v_i_240, V v_n_241) {
top: ;
  if (heff_intLe_c(heff_dup(v_n_241), heff_dup(v_i_240))) {
    heff_drop(v_i_240);
    heff_drop(v_n_241);
    return NTAG(TAG_Nil);
  } else {
    V v_cell_243 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_i_240), heff_hole()});
    V v_u_244 = (g_heff_2eelab_2eclauses_2eupToGo_24dps(heff_intAdd(v_i_240, MK_INT(1LL)), v_n_241, heff_dup(v_cell_243)));
    heff_drop(v_u_244);
    return v_cell_243;
  }
}
V g_heff_2eelab_2eclauses_2eupToGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2eupToGo(a[0], a[1]);
}
Clo g_heff_2eelab_2eclauses_2eupToGo_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2eupToGo_24dps_entry, 3, 0};

V g_heff_2eelab_2eclauses_2eupToGo_24dps(V v_i_240, V v_n_241, V v_d_242) {
top: ;
  if (heff_intLe_c(heff_dup(v_n_241), heff_dup(v_i_240))) {
    heff_drop(v_i_240);
    heff_drop(v_n_241);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  } else {
    V v_cell_244 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_i_240), heff_hole()});
    V v_u_245 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_244));
    heff_drop(v_u_245);
    V t_0 = heff_intAdd(v_i_240, MK_INT(1LL));
    V t_1 = v_n_241;
    V t_2 = v_cell_244;
    v_i_240 = t_0;
    v_n_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
}
V g_heff_2eelab_2eclauses_2eupToGo_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2eupToGo_24dps(a[0], a[1], a[2]);
}
Clo g_heff_2eelab_2eclauses_2edropAt_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2edropAt_24dps_entry, 3, 0};

V g_heff_2eelab_2eclauses_2edropAt_24dps(V v_i_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_i_240);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (heff_intEq_c(heff_dup(v_i_240), MK_INT(0LL))) {
      heff_drop(v_i_240);
      heff_drop(v_x_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return heff_setField(v_d_242, MK_INT(1LL), v_xs_244);
    } else {
      V v_cell_246 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
      V v_u_247 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_246));
      heff_drop(v_u_247);
      V t_0 = heff_intSub(v_i_240, MK_INT(1LL));
      V t_1 = v_xs_244;
      V t_2 = v_cell_246;
      v_i_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eelab_2eclauses_2edropAt_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2edropAt_24dps(a[0], a[1], a[2]);
}
Clo g_heff_2eelab_2eclauses_2etakeC_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2etakeC_24dps_entry, 3, 0};

V g_heff_2eelab_2eclauses_2etakeC_24dps(V v_n_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_n_240);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (heff_intLe_c(heff_dup(v_n_240), MK_INT(0LL))) {
      heff_drop(v_n_240);
      heff_drop(v_x_243);
      heff_drop(v_xs_244);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
    } else {
      V v_cell_246 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
      V v_u_247 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_246));
      heff_drop(v_u_247);
      V t_0 = heff_intSub(v_n_240, MK_INT(1LL));
      V t_1 = v_xs_244;
      V t_2 = v_cell_246;
      v_n_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eelab_2eclauses_2etakeC_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2etakeC_24dps(a[0], a[1], a[2]);
}
Clo g_heff_2eelab_2eclauses_2econcatMapC_24s1253148850x1225196638_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2econcatMapC_24s1253148850x1225196638_entry, 1, 0};

V g_heff_2eelab_2eclauses_2econcatMapC_24s1253148850x1225196638(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_243 = (g_heff_2eelab_2eclauses_2epatVars(heff_dup(v_x_241)));
    V v_t_244 = (g_heff_2eelab_2eclauses_2econcatMapC_24s1253148850x1225196638(v_xs_242));
    return (g_heff_2eelab_2eclauses_2eappendC(v_t_243, v_t_244));
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eelab_2eclauses_2econcatMapC_24s1253148850x1225196638_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2eclauses_2econcatMapC_24s1253148850x1225196638(a0); heff_drop(a0); return r;
}
Clo g_heff_2eelab_2eclauses_2enamesOfAll_24s613549782x1232950246_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2enamesOfAll_24s613549782x1232950246_entry, 2, 0};

V g_heff_2eelab_2eclauses_2enamesOfAll_24s613549782x1232950246(V v_x2_240, V v_acc_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return v_acc_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_247;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkFieldPat: {
      V v_a_244 = heff_field(v_x_242, 0);
      V v_a_245 = heff_field(v_x_242, 1);
      heff_take_n(v_x_242, 3ULL, 2);
      V v_t_246 = (g_heff_2eelab_2eclauses_2epatIdents(v_a_245, v_acc_241));
      v_t_247 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_a_244, v_t_246});
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V t_0 = v_xs_243;
    V t_1 = v_t_247;
    v_x2_240 = t_0;
    v_acc_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eelab_2eclauses_2enamesOfAll_24s613549782x1232950246_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2enamesOfAll_24s613549782x1232950246(a[0], a[1]);
}
Clo g_heff_2eelab_2eclauses_2epatIdents_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2epatIdents_24dps_entry, 3, 0};

V g_heff_2eelab_2eclauses_2epatIdents_24dps(V v_p_240, V v_acc_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_p_240)) {
  case TAG_At: {
    V v_p1_243 = heff_field(v_p_240, 0);
    V v_ru_24p_240_24At = heff_take_reuse_n(v_p_240, 1ULL, 2);
    switch (heff_tag_of(v_p1_243)) {
    case TAG_PatVar: {
      V v_x_245 = heff_field(v_p1_243, 0);
      heff_take_n(v_p1_243, 1ULL, 1);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      return heff_setField(v_d_242, MK_INT(1LL), heff_tag_n(TAG_Cons, 2, (V[]){v_x_245, v_acc_241}));
    }
    case TAG_PatTag: {
      V v_ps_248 = heff_field(v_p1_243, 2);
      heff_take_n(v_p1_243, 4ULL, 3);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      V v_t_249 = ({ V a_0 = v_ps_248; V a_1 = v_acc_241; V r_ = (g_heff_2eelab_2eclauses_2enamesOfAll_24s291844836x707424588(a_0, a_1)); heff_drop(v_ps_248); r_; });
      return heff_setField(v_d_242, MK_INT(1LL), v_t_249);
    }
    case TAG_PatOp: {
      V v_x_2410 = heff_field(v_p1_243, 0);
      V v_ps_2412 = heff_field(v_p1_243, 2);
      heff_take_n(v_p1_243, 5ULL, 3);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      V v_t_2413 = ({ V a_0 = v_ps_2412; V a_1 = v_acc_241; V r_ = (g_heff_2eelab_2eclauses_2enamesOfAll_24s291844836x707424588(a_0, a_1)); heff_drop(v_ps_2412); r_; });
      return heff_setField(v_d_242, MK_INT(1LL), heff_tag_n(TAG_Cons, 2, (V[]){v_x_2410, v_t_2413}));
    }
    case TAG_PatInt: {
      heff_take_n(v_p1_243, 0ULL, 1);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      return heff_setField(v_d_242, MK_INT(1LL), v_acc_241);
    }
    case TAG_PatFloat: {
      heff_take_n(v_p1_243, 0ULL, 1);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      return heff_setField(v_d_242, MK_INT(1LL), v_acc_241);
    }
    case TAG_PatString: {
      heff_take_n(v_p1_243, 0ULL, 1);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      return heff_setField(v_d_242, MK_INT(1LL), v_acc_241);
    }
    case TAG_PatBytes: {
      heff_take_n(v_p1_243, 0ULL, 1);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      return heff_setField(v_d_242, MK_INT(1LL), v_acc_241);
    }
    case TAG_PatRune: {
      heff_take_n(v_p1_243, 0ULL, 1);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      return heff_setField(v_d_242, MK_INT(1LL), v_acc_241);
    }
    case TAG_PatRecord: {
      V v_fs_2419 = heff_field(v_p1_243, 0);
      heff_take_n(v_p1_243, 1ULL, 1);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      V v_t_2420 = (g_heff_2eelab_2eclauses_2enamesOfAll_24s613549782x1232950246(v_fs_2419, v_acc_241));
      return heff_setField(v_d_242, MK_INT(1LL), v_t_2420);
    }
    case TAG_PatWord: {
      heff_take_n(v_p1_243, 0ULL, 1);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      return heff_setField(v_d_242, MK_INT(1LL), v_acc_241);
    }
    case TAG_PatAs: {
      V v_x_2422 = heff_field(v_p1_243, 0);
      V v_q_2424 = heff_field(v_p1_243, 2);
      heff_take_n(v_p1_243, 5ULL, 3);
      V v_cell_2425 = heff_tag_at_n(v_ru_24p_240_24At, TAG_Cons, 2, (V[]){v_x_2422, heff_hole()});
      V v_u_2426 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_2425));
      heff_drop(v_u_2426);
      V t_0 = v_q_2424;
      V t_1 = v_acc_241;
      V t_2 = v_cell_2425;
      v_p_240 = t_0;
      v_acc_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_p1_243);
    }
  }
  default: return heff_nomatch(v_p_240);
  }
}
V g_heff_2eelab_2eclauses_2epatIdents_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2epatIdents_24dps(a[0], a[1], a[2]);
}
V g_heff_2eelab_2eclauses_2eidentsChkF_lam0(V self, V *args);
V g_heff_2eelab_2eclauses_2eidentsChkF_lam1(V self, V *args);
Clo g_heff_2eelab_2eclauses_2eidentsChkF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2eidentsChkF_entry, 3, 0};

V g_heff_2eelab_2eclauses_2eidentsChkF(V v_r_240, V v_x2_241, V v_acc_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_At: {
    V v_x21_243 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24At = heff_take_reuse_n(v_x2_241, 1ULL, 2);
    switch (heff_tag_of(v_x21_243)) {
    case TAG_CInf: {
      V v_i_245 = heff_field(v_x21_243, 0);
      heff_take_n(v_x21_243, 1ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24At, 2);
      return heff_tail(heff_get_n(v_r_240, 0, 4), 2, (V[]){v_i_245, v_acc_242});
    }
    case TAG_CType: {
      V v_t_246 = heff_field(v_x21_243, 0);
      heff_take_n(v_x21_243, 1ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24At, 2);
      return heff_tail(heff_get_n(v_r_240, 2, 4), 2, (V[]){v_t_246, v_acc_242});
    }
    case TAG_CLam: {
      V v_x_247 = heff_field(v_x21_243, 0);
      V v_b_249 = heff_field(v_x21_243, 2);
      heff_take_n(v_x21_243, 5ULL, 3);
      V v_t_2410 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 4), 2, (V[]){v_b_249, v_acc_242}));
      return heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_x_247, v_t_2410});
    }
    case TAG_CImplicitLam: {
      V v_x_2411 = heff_field(v_x21_243, 0);
      V v_b_2413 = heff_field(v_x21_243, 2);
      heff_take_n(v_x21_243, 5ULL, 3);
      V v_t_2414 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 4), 2, (V[]){v_b_2413, v_acc_242}));
      return heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_x_2411, v_t_2414});
    }
    case TAG_CAnnLam: {
      V v_x_2415 = heff_field(v_x21_243, 0);
      V v_t_2417 = heff_field(v_x21_243, 2);
      V v_b_2418 = heff_field(v_x21_243, 3);
      heff_take_n(v_x21_243, 13ULL, 4);
      V v_t_2419 = heff_tr(heff_call(heff_take_field(v_r_240, 1), 2, (V[]){v_b_2418, v_acc_242}));
      V v_t_2420 = heff_tr(heff_call(heff_get_n(v_r_240, 2, 4), 2, (V[]){v_t_2417, v_t_2419}));
      return heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_x_2415, v_t_2420});
    }
    case TAG_CTag: {
      V v_args_2423 = heff_field(v_x21_243, 2);
      heff_take_n(v_x21_243, 4ULL, 3);
      heff_drop_cell(v_ru_24x2_241_24At, 2);
      return ({ V a_0 = heff_get_n(v_r_240, 1, 4); V a_1 = v_args_2423; V a_2 = v_acc_242; V r_ = (g_heff_2eelab_2eclauses_2enamesOfAll(a_0, a_1, a_2)); heff_drop(v_args_2423); r_; });
    }
    case TAG_CStruct: {
      V v_fs_2424 = heff_field(v_x21_243, 0);
      heff_take_n(v_x21_243, 1ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24At, 2);
      return ({ V a_0 = heff_clo_n(g_heff_2eelab_2eclauses_2eidentsChkF_lam0, 2, 1, (V[]){v_r_240}); V a_1 = v_fs_2424; V a_2 = v_acc_242; V r_ = (g_heff_2eelab_2eclauses_2enamesOfAll(a_0, a_1, a_2)); heff_drop(v_fs_2424); r_; });
    }
    case TAG_CMatch: {
      V v_s_2434 = heff_field(v_x21_243, 0);
      V v_alts_2435 = heff_field(v_x21_243, 1);
      heff_take_n(v_x21_243, 3ULL, 2);
      heff_drop_cell(v_ru_24x2_241_24At, 2);
      V v_t_2443 = ({ V a_0 = heff_clo_n(g_heff_2eelab_2eclauses_2eidentsChkF_lam1, 2, 1, (V[]){heff_dup(v_r_240)}); V a_1 = v_alts_2435; V a_2 = v_acc_242; V r_ = (g_heff_2eelab_2eclauses_2enamesOfAll(a_0, a_1, a_2)); heff_drop(v_alts_2435); r_; });
      return heff_tail(heff_get_n(v_r_240, 0, 4), 2, (V[]){v_s_2434, v_t_2443});
    }
    case TAG_CLetIn: {
      V v_rhs_2444 = heff_field(v_x21_243, 0);
      V v_a_2445 = heff_field(v_x21_243, 1);
      heff_take_n(v_x21_243, 3ULL, 2);
      heff_drop_cell(v_ru_24x2_241_24At, 2);
      V v_t_2451;
      switch (heff_tag_of(v_a_2445)) {
      case TAG_At: {
        V v_x21_2446 = heff_field(v_a_2445, 0);
        heff_take_n(v_a_2445, 1ULL, 2);
        switch (heff_tag_of(v_x21_2446)) {
        case TAG_MkAlt: {
          V v_p_2448 = heff_field(v_x21_2446, 0);
          V v_b_2449 = heff_field(v_x21_2446, 1);
          heff_take_n(v_x21_2446, 3ULL, 2);
          V v_t_2450 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 1)), 2, (V[]){v_b_2449, v_acc_242}));
          v_t_2451 = (g_heff_2eelab_2eclauses_2epatIdents(v_p_2448, v_t_2450));
          break;
        }
        default: heff_nomatch(v_x21_2446);
        }
        break;
      }
      default: heff_nomatch(v_a_2445);
      }
      return heff_tail(heff_get_n(v_r_240, 0, 4), 2, (V[]){v_rhs_2444, v_t_2451});
    }
    case TAG_CLocal: {
      V v_body_2452 = heff_field(v_x21_243, 0);
      V v_ds_2453 = heff_field(v_x21_243, 1);
      heff_take_n(v_x21_243, 3ULL, 2);
      heff_drop_cell(v_ru_24x2_241_24At, 2);
      V v_t_2454 = ({ V a_0 = heff_take_field(v_r_240, 3); V a_1 = v_ds_2453; V a_2 = v_acc_242; V r_ = (g_heff_2eelab_2eclauses_2enamesOfAll(a_0, a_1, a_2)); heff_drop(v_ds_2453); r_; });
      return heff_tail(heff_get_n(v_r_240, 1, 4), 2, (V[]){v_body_2452, v_t_2454});
    }
    case TAG_CAbandon: {
      heff_drop_rec(v_r_240, 4);
      heff_drop_cell(v_ru_24x2_241_24At, 2);
      return v_acc_242;
    }
    case TAG_CNominal: {
      V v_c_2455 = heff_field(v_x21_243, 0);
      heff_take_n(v_x21_243, 1ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24At, 2);
      return heff_tail(heff_get_n(v_r_240, 1, 4), 2, (V[]){v_c_2455, v_acc_242});
    }
    default: return heff_nomatch(v_x21_243);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eelab_2eclauses_2eidentsChkF_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2eidentsChkF(a[0], a[1], a[2]);
}
V g_heff_2eelab_2eclauses_2eidentsChkF_lam0(V self, V *args) {
  V v_x2_2425 = args[0];
  V v_acc_2426 = args[1];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x2_2425)) {
  case TAG_At: {
    V v_x21_2427 = heff_field(v_x2_2425, 0);
    V v_ru_24x2_2425_24At = heff_take_reuse_n(v_x2_2425, 1ULL, 2);
    switch (heff_tag_of(v_x21_2427)) {
    case TAG_SetField: {
      V v_x_2429 = heff_field(v_x21_2427, 0);
      V v_e_2431 = heff_field(v_x21_2427, 2);
      heff_take_n(v_x21_2427, 5ULL, 3);
      V v_t_2432 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 4), 2, (V[]){v_e_2431, v_acc_2426}));
      return heff_tag_at_n(v_ru_24x2_2425_24At, TAG_Cons, 2, (V[]){v_x_2429, v_t_2432});
    }
    case TAG_BadFieldSet: {
      V v_e_2433 = heff_field(v_x21_2427, 0);
      heff_take_n(v_x21_2427, 1ULL, 1);
      heff_drop_cell(v_ru_24x2_2425_24At, 2);
      V f_ = heff_get_n(v_r_240, 1, 4);
      args[0] = v_e_2433;
      args[1] = v_acc_2426;
      if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 2, args);
    }
    default: return heff_nomatch(v_x21_2427);
    }
  }
  default: return heff_nomatch(v_x2_2425);
  }
}
V g_heff_2eelab_2eclauses_2eidentsChkF_lam1(V self, V *args) {
  V v_a_2436 = args[0];
  V v_b_2437 = args[1];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_a_2436)) {
  case TAG_At: {
    V v_x21_2438 = heff_field(v_a_2436, 0);
    heff_take_n(v_a_2436, 1ULL, 2);
    switch (heff_tag_of(v_x21_2438)) {
    case TAG_MkAlt: {
      V v_p_2440 = heff_field(v_x21_2438, 0);
      V v_b_2441 = heff_field(v_x21_2438, 1);
      heff_take_n(v_x21_2438, 3ULL, 2);
      V v_t_2442 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 4), 2, (V[]){v_b_2441, v_b_2437}));
      return (g_heff_2eelab_2eclauses_2epatIdents(v_p_2440, v_t_2442));
    }
    default: return heff_nomatch(v_x21_2438);
    }
  }
  default: return heff_nomatch(v_a_2436);
  }
}
Clo g_heff_2eelab_2eclauses_2enamesOfAll_24s2067092643x645415179_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2enamesOfAll_24s2067092643x645415179_entry, 2, 0};

V g_heff_2eelab_2eclauses_2enamesOfAll_24s2067092643x645415179(V v_x2_240, V v_acc_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return v_acc_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2411;
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_a_244 = heff_field(v_x_242, 0);
      heff_take_n(v_x_242, 1ULL, 2);
      switch (heff_tag_of(v_a_244)) {
      case TAG_ArgExplicit: {
        V v_a_246 = heff_field(v_a_244, 0);
        heff_take_n(v_a_244, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_240_24Cons, 2);
        v_t_2411 = (g_heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291(v_a_246, v_acc_241));
        break;
      }
      case TAG_ArgProject: {
        heff_take_n(v_a_244, 0ULL, 1);
        heff_drop_cell(v_ru_24x2_240_24Cons, 2);
        v_t_2411 = v_acc_241;
        break;
      }
      case TAG_ArgNamed: {
        V v_a_248 = heff_field(v_a_244, 0);
        V v_a_249 = heff_field(v_a_244, 1);
        heff_take_n(v_a_244, 3ULL, 2);
        V v_t_2410 = (g_heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291(v_a_249, v_acc_241));
        v_t_2411 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_a_248, v_t_2410});
        break;
      }
      default: heff_nomatch(v_a_244);
      }
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V t_0 = v_xs_243;
    V t_1 = v_t_2411;
    v_x2_240 = t_0;
    v_acc_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eelab_2eclauses_2enamesOfAll_24s2067092643x645415179_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2enamesOfAll_24s2067092643x645415179(a[0], a[1]);
}
Clo g_heff_2eelab_2eclauses_2enamesOfAll_24s880313170x30977071_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2enamesOfAll_24s880313170x30977071_entry, 2, 0};

V g_heff_2eelab_2eclauses_2enamesOfAll_24s880313170x30977071(V v_x2_240, V v_acc_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return v_acc_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2414;
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_a_244 = heff_field(v_x_242, 0);
      heff_take_n(v_x_242, 1ULL, 2);
      switch (heff_tag_of(v_a_244)) {
      case TAG_DeclareField: {
        V v_a_246 = heff_field(v_a_244, 0);
        V v_a_248 = heff_field(v_a_244, 2);
        V v_a_249 = heff_field(v_a_244, 3);
        heff_take_n(v_a_244, 13ULL, 4);
        V v_a_2411;
        switch (heff_tag_of(v_a_249)) {
        case TAG_Nothing: {
          v_a_2411 = v_acc_241;
          break;
        }
        case TAG_Just: {
          V v_a_2410 = heff_field(v_a_249, 0);
          heff_take_n(v_a_249, 1ULL, 1);
          v_a_2411 = (g_heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291(v_a_2410, v_acc_241));
          break;
        }
        default: heff_nomatch(v_a_249);
        }
        V v_t_2412 = ({ V a_0 = v_a_248; V a_1 = v_a_2411; V r_ = (g_heff_2eelab_2eclauses_2eidentsTypF_24s506476740x533987156(a_0, a_1)); heff_drop(v_a_248); r_; });
        v_t_2414 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_a_246, v_t_2412});
        break;
      }
      case TAG_BadFieldDecl: {
        V v_a_2413 = heff_field(v_a_244, 0);
        heff_take_n(v_a_244, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_240_24Cons, 2);
        v_t_2414 = ({ V a_0 = v_a_2413; V a_1 = v_acc_241; V r_ = (g_heff_2eelab_2eclauses_2eidentsTypF_24s506476740x533987156(a_0, a_1)); heff_drop(v_a_2413); r_; });
        break;
      }
      default: heff_nomatch(v_a_244);
      }
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V t_0 = v_xs_243;
    V t_1 = v_t_2414;
    v_x2_240 = t_0;
    v_acc_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eelab_2eclauses_2enamesOfAll_24s880313170x30977071_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2enamesOfAll_24s880313170x30977071(a[0], a[1]);
}
Clo g_heff_2eelab_2eclauses_2eidentsTypF_24s506476740x533987156_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2eidentsTypF_24s506476740x533987156_entry, 2, 0};

V g_heff_2eelab_2eclauses_2eidentsTypF_24s506476740x533987156(V v_n_240, V v_acc_241) {
top: ;
  switch (heff_tag_of(v_n_240)) {
  case TAG_At: {
    V v_n1_242 = heff_field(v_n_240, 0);
    switch (heff_tag_of(v_n1_242)) {
    case TAG_TPi: {
      V v_b_244 = heff_field(v_n1_242, 0);
      V v_cod_245 = heff_field(v_n1_242, 1);
      V v_t_246 = (g_heff_2eelab_2eclauses_2eidentsTypF_24s506476740x533987156(v_cod_245, v_acc_241));
      HEFF_LAST return g_heff_2eelab_2eclauses_2epiIdents_24s20744116x2053008297(v_b_244, v_t_246);
    }
    case TAG_TSig: {
      V v_fs_247 = heff_field(v_n1_242, 0);
      HEFF_LAST return g_heff_2eelab_2eclauses_2enamesOfAll_24s880313170x30977071(heff_dup(v_fs_247), v_acc_241);
    }
    case TAG_TSum: {
      V v_vs_248 = heff_field(v_n1_242, 0);
      HEFF_LAST return g_heff_2eelab_2eclauses_2enamesOfAll_24s638847411x1828905680(v_vs_248, v_acc_241);
    }
    case TAG_TType: {
      return v_acc_241;
    }
    case TAG_TInt: {
      return v_acc_241;
    }
    case TAG_TFloat: {
      return v_acc_241;
    }
    case TAG_TString: {
      return v_acc_241;
    }
    case TAG_TRune: {
      return v_acc_241;
    }
    case TAG_TArray: {
      V v_a_249 = heff_field(v_n1_242, 0);
      V t_0 = v_a_249;
      V t_1 = v_acc_241;
      v_n_240 = t_0;
      v_acc_241 = t_1;
      goto top;
    }
    case TAG_TFixed: {
      return v_acc_241;
    }
    case TAG_TInf: {
      V v_i_2411 = heff_field(v_n1_242, 0);
      HEFF_LAST return g_heff_2eelab_2eclauses_2eidentsInfF_24s869152224x1503528648(heff_dup(v_i_2411), v_acc_241);
    }
    case TAG_TChk: {
      V v_c_2412 = heff_field(v_n1_242, 0);
      HEFF_LAST return g_heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291(heff_dup(v_c_2412), v_acc_241);
    }
    case TAG_TNominal: {
      V v_t_2413 = heff_field(v_n1_242, 0);
      V t_0 = v_t_2413;
      V t_1 = v_acc_241;
      v_n_240 = t_0;
      v_acc_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_n1_242);
    }
  }
  default: return heff_nomatch(v_n_240);
  }
}
V g_heff_2eelab_2eclauses_2eidentsTypF_24s506476740x533987156_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2eclauses_2eidentsTypF_24s506476740x533987156(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291_entry, 2, 0};

V g_heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291(V v_x2_240, V v_acc_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_At: {
    V v_x21_242 = heff_field(v_x2_240, 0);
    V v_ru_24x2_240_24At = heff_take_reuse_n(v_x2_240, 1ULL, 2);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_CInf: {
      V v_i_244 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 1);
      heff_drop_cell(v_ru_24x2_240_24At, 2);
      HEFF_LAST return g_heff_2eelab_2eclauses_2eidentsInfF_24s869152224x1503528648(v_i_244, v_acc_241);
    }
    case TAG_CType: {
      V v_t_245 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 1);
      heff_drop_cell(v_ru_24x2_240_24At, 2);
      return ({ V a_0 = v_t_245; V a_1 = v_acc_241; V r_ = (g_heff_2eelab_2eclauses_2eidentsTypF_24s506476740x533987156(a_0, a_1)); heff_drop(v_t_245); r_; });
    }
    case TAG_CLam: {
      V v_x_246 = heff_field(v_x21_242, 0);
      V v_b_248 = heff_field(v_x21_242, 2);
      heff_take_n(v_x21_242, 5ULL, 3);
      V v_cell_249 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_Cons, 2, (V[]){v_x_246, heff_hole()});
      V v_u_2410 = (g_heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291_24dps(v_b_248, v_acc_241, heff_dup(v_cell_249)));
      heff_drop(v_u_2410);
      return v_cell_249;
    }
    case TAG_CImplicitLam: {
      V v_x_2411 = heff_field(v_x21_242, 0);
      V v_b_2413 = heff_field(v_x21_242, 2);
      heff_take_n(v_x21_242, 5ULL, 3);
      V v_cell_2414 = heff_tag_at_n(v_ru_24x2_240_24At, TAG_Cons, 2, (V[]){v_x_2411, heff_hole()});
      V v_u_2415 = (g_heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291_24dps(v_b_2413, v_acc_241, heff_dup(v_cell_2414)));
      heff_drop(v_u_2415);
      return v_cell_2414;
    }
    case TAG_CAnnLam: {
      V v_x_2416 = heff_field(v_x21_242, 0);
      V v_t_2418 = heff_field(v_x21_242, 2);
      V v_b_2419 = heff_field(v_x21_242, 3);
      heff_take_n(v_x21_242, 13ULL, 4);
      V v_acc_2420 = (g_heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291(v_b_2419, v_acc_241));
      V v_t_2421 = ({ V a_0 = v_t_2418; V a_1 = v_acc_2420; V r_ = (g_heff_2eelab_2eclauses_2eidentsTypF_24s506476740x533987156(a_0, a_1)); heff_drop(v_t_2418); r_; });
      return heff_tag_at_n(v_ru_24x2_240_24At, TAG_Cons, 2, (V[]){v_x_2416, v_t_2421});
    }
    case TAG_CTag: {
      V v_args_2424 = heff_field(v_x21_242, 2);
      heff_take_n(v_x21_242, 4ULL, 3);
      heff_drop_cell(v_ru_24x2_240_24At, 2);
      return ({ V a_0 = heff_dup(heff_rfield(g_heff_2eelab_2eclauses_2eidents_get(), 1)); V a_1 = v_args_2424; V a_2 = v_acc_241; V r_ = (g_heff_2eelab_2eclauses_2enamesOfAll(a_0, a_1, a_2)); heff_drop(v_args_2424); r_; });
    }
    case TAG_CStruct: {
      V v_fs_2425 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 1);
      heff_drop_cell(v_ru_24x2_240_24At, 2);
      HEFF_LAST return g_heff_2eelab_2eclauses_2enamesOfAll_24s1471250105x438377350(v_fs_2425, v_acc_241);
    }
    case TAG_CMatch: {
      V v_s_2426 = heff_field(v_x21_242, 0);
      V v_alts_2427 = heff_field(v_x21_242, 1);
      heff_take_n(v_x21_242, 3ULL, 2);
      heff_drop_cell(v_ru_24x2_240_24At, 2);
      V v_acc_2428 = ({ V a_0 = v_alts_2427; V a_1 = v_acc_241; V r_ = (g_heff_2eelab_2eclauses_2enamesOfAll_24s2127598839x230588173(a_0, a_1)); heff_drop(v_alts_2427); r_; });
      HEFF_LAST return g_heff_2eelab_2eclauses_2eidentsInfF_24s869152224x1503528648(v_s_2426, v_acc_2428);
    }
    case TAG_CLetIn: {
      V v_rhs_2429 = heff_field(v_x21_242, 0);
      V v_a_2430 = heff_field(v_x21_242, 1);
      heff_take_n(v_x21_242, 3ULL, 2);
      heff_drop_cell(v_ru_24x2_240_24At, 2);
      V v_acc_2436;
      switch (heff_tag_of(v_a_2430)) {
      case TAG_At: {
        V v_x21_2431 = heff_field(v_a_2430, 0);
        heff_take_n(v_a_2430, 1ULL, 2);
        switch (heff_tag_of(v_x21_2431)) {
        case TAG_MkAlt: {
          V v_p_2433 = heff_field(v_x21_2431, 0);
          V v_b_2434 = heff_field(v_x21_2431, 1);
          heff_take_n(v_x21_2431, 3ULL, 2);
          V v_t_2435 = (g_heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291(v_b_2434, v_acc_241));
          v_acc_2436 = (g_heff_2eelab_2eclauses_2epatIdents(v_p_2433, v_t_2435));
          break;
        }
        default: heff_nomatch(v_x21_2431);
        }
        break;
      }
      default: heff_nomatch(v_a_2430);
      }
      HEFF_LAST return g_heff_2eelab_2eclauses_2eidentsInfF_24s869152224x1503528648(v_rhs_2429, v_acc_2436);
    }
    case TAG_CLocal: {
      V v_body_2437 = heff_field(v_x21_242, 0);
      V v_ds_2438 = heff_field(v_x21_242, 1);
      heff_take_n(v_x21_242, 3ULL, 2);
      heff_drop_cell(v_ru_24x2_240_24At, 2);
      V v_acc_2439 = ({ V a_0 = heff_dup(heff_rfield(g_heff_2eelab_2eclauses_2eidents_get(), 3)); V a_1 = v_ds_2438; V a_2 = v_acc_241; V r_ = (g_heff_2eelab_2eclauses_2enamesOfAll(a_0, a_1, a_2)); heff_drop(v_ds_2438); r_; });
      V t_0 = v_body_2437;
      V t_1 = v_acc_2439;
      v_x2_240 = t_0;
      v_acc_241 = t_1;
      goto top;
    }
    case TAG_CAbandon: {
      heff_drop_cell(v_ru_24x2_240_24At, 2);
      return v_acc_241;
    }
    case TAG_CNominal: {
      V v_c_2440 = heff_field(v_x21_242, 0);
      heff_take_n(v_x21_242, 1ULL, 1);
      heff_drop_cell(v_ru_24x2_240_24At, 2);
      V t_0 = v_c_2440;
      V t_1 = v_acc_241;
      v_x2_240 = t_0;
      v_acc_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291(a[0], a[1]);
}
HEFF_LIT(g_heff_2eelab_2eclauses_2efresh_str0, 1, "'");
Clo g_heff_2eelab_2eclauses_2efresh_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2efresh_entry, 2, 0};

V g_heff_2eelab_2eclauses_2efresh(V v_used_240, V v_x_241) {
top: ;
  V v_t_242 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(v_x_241)}));
  V v_t_243 = (g_list_2eany(v_t_242, v_used_240));
  if ((heff_dup(v_t_243) == NTAG(TAG_True))) {
    heff_drop(v_t_243);
    V t_0 = v_used_240;
    V t_1 = heff_strAppend(v_x_241, ((V)&g_heff_2eelab_2eclauses_2efresh_str0));
    v_used_240 = t_0;
    v_x_241 = t_1;
    goto top;
  } else {
    heff_drop(v_t_243);
    return v_x_241;
  }
}
V g_heff_2eelab_2eclauses_2efresh_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2eclauses_2efresh(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2eelab_2eclauses_2econcatMapC_24s497393573x331502823_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2econcatMapC_24s497393573x331502823_entry, 1, 0};

V g_heff_2eelab_2eclauses_2econcatMapC_24s497393573x331502823(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_245;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkFieldPat: {
      V v_a_244 = heff_field(v_x_241, 1);
      v_t_245 = (g_heff_2eelab_2eclauses_2epatBinds(heff_dup(v_a_244)));
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_t_246 = (g_heff_2eelab_2eclauses_2econcatMapC_24s497393573x331502823(v_xs_242));
    return (g_heff_2eelab_2eclauses_2eappendC(v_t_245, v_t_246));
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eelab_2eclauses_2econcatMapC_24s497393573x331502823_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2eclauses_2econcatMapC_24s497393573x331502823(a0); heff_drop(a0); return r;
}
V g_heff_2eelab_2eclauses_2erenameChkF_lam0(V self, V *args);
V g_heff_2eelab_2eclauses_2erenameChkF_lam1(V self, V *args);
V g_heff_2eelab_2eclauses_2erenameChkF_lam2(V self, V *args);
Clo g_heff_2eelab_2eclauses_2erenameChkF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2erenameChkF_entry, 2, 0};

V g_heff_2eelab_2eclauses_2erenameChkF(V v_r_240, V v_n_241) {
top: ;
  switch (heff_tag_of(v_n_241)) {
  case TAG_At: {
    V v_n1_242 = heff_dup(heff_field(v_n_241, 0));
    V v_sp_243 = heff_dup(heff_field(v_n_241, 1));
    switch (heff_tag_of(v_n1_242)) {
    case TAG_CInf: {
      V v_i_244 = heff_field(v_n1_242, 0);
      V v_ru_24n1_242_24CInf = heff_take_reuse_n(v_n1_242, 1ULL, 1);
      heff_drop_tag(v_n_241, 2);
      V v_t_245 = heff_tr(heff_call(heff_get_n(v_r_240, 2, 5), 1, (V[]){v_i_244}));
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24n1_242_24CInf, TAG_CInf, 1, (V[]){v_t_245}), v_sp_243});
    }
    case TAG_CType: {
      V v_t_246 = heff_field(v_n1_242, 0);
      V v_ru_24n1_242_24CType = heff_take_reuse_n(v_n1_242, 1ULL, 1);
      heff_drop_tag(v_n_241, 2);
      V v_t_247 = heff_tr(heff_call(heff_get_n(v_r_240, 4, 5), 1, (V[]){v_t_246}));
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24n1_242_24CType, TAG_CType, 1, (V[]){v_t_247}), v_sp_243});
    }
    case TAG_CLam: {
      V v_y_248 = heff_field(v_n1_242, 0);
      V v_ysp_249 = heff_field(v_n1_242, 1);
      V v_b_2410 = heff_field(v_n1_242, 2);
      V v_ru_24n1_242_24CLam = heff_take_reuse_n(v_n1_242, 7ULL, 3);
      if (heff_strEq_c(heff_dup(v_y_248), heff_dup(heff_rfield(v_r_240, 0)))) {
        heff_drop_rec(v_r_240, 5);
        heff_drop(v_sp_243);
        heff_drop(v_y_248);
        heff_drop(v_ysp_249);
        heff_drop(v_b_2410);
        heff_drop_cell(v_ru_24n1_242_24CLam, 3);
        return v_n_241;
      } else {
        heff_drop_tag(v_n_241, 2);
        V v_t_2412 = heff_tr(heff_call(heff_get_n(v_r_240, 3, 5), 1, (V[]){v_b_2410}));
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24n1_242_24CLam, TAG_CLam, 3, (V[]){v_y_248, v_ysp_249, v_t_2412}), v_sp_243});
      }
    }
    case TAG_CImplicitLam: {
      V v_y_2413 = heff_field(v_n1_242, 0);
      V v_ysp_2414 = heff_field(v_n1_242, 1);
      V v_b_2415 = heff_field(v_n1_242, 2);
      V v_ru_24n1_242_24CImplicitLam = heff_take_reuse_n(v_n1_242, 7ULL, 3);
      if (heff_strEq_c(heff_dup(v_y_2413), heff_dup(heff_rfield(v_r_240, 0)))) {
        heff_drop_rec(v_r_240, 5);
        heff_drop(v_sp_243);
        heff_drop(v_y_2413);
        heff_drop(v_ysp_2414);
        heff_drop(v_b_2415);
        heff_drop_cell(v_ru_24n1_242_24CImplicitLam, 3);
        return v_n_241;
      } else {
        heff_drop_tag(v_n_241, 2);
        V v_t_2417 = heff_tr(heff_call(heff_get_n(v_r_240, 3, 5), 1, (V[]){v_b_2415}));
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24n1_242_24CImplicitLam, TAG_CImplicitLam, 3, (V[]){v_y_2413, v_ysp_2414, v_t_2417}), v_sp_243});
      }
    }
    case TAG_CAnnLam: {
      V v_y_2418 = heff_field(v_n1_242, 0);
      V v_ysp_2419 = heff_field(v_n1_242, 1);
      V v_t_2420 = heff_field(v_n1_242, 2);
      V v_b_2421 = heff_field(v_n1_242, 3);
      V v_ru_24n1_242_24CAnnLam = heff_take_reuse_n(v_n1_242, 15ULL, 4);
      heff_drop_tag(v_n_241, 2);
      V v_t_2422 = heff_tr(heff_call(heff_take_field(v_r_240, 4), 1, (V[]){v_t_2420}));
      V v_t_2424;
      if (heff_strEq_c(heff_dup(v_y_2418), heff_dup(heff_rfield(v_r_240, 0)))) {
        heff_drop_rec(v_r_240, 5);
        v_t_2424 = v_b_2421;
      } else {
        v_t_2424 = heff_tr(heff_call(heff_get_n(v_r_240, 3, 5), 1, (V[]){v_b_2421}));
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24n1_242_24CAnnLam, TAG_CAnnLam, 4, (V[]){v_y_2418, v_ysp_2419, v_t_2422, v_t_2424}), v_sp_243});
    }
    case TAG_CTag: {
      V v_t_2425 = heff_field(v_n1_242, 0);
      V v_tsp_2426 = heff_field(v_n1_242, 1);
      V v_args_2427 = heff_field(v_n1_242, 2);
      V v_ru_24n1_242_24CTag = heff_take_reuse_n(v_n1_242, 7ULL, 3);
      heff_drop_tag(v_n_241, 2);
      V v_t_2428 = (g_list_2emap(heff_get_n(v_r_240, 3, 5), v_args_2427));
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24n1_242_24CTag, TAG_CTag, 3, (V[]){v_t_2425, v_tsp_2426, v_t_2428}), v_sp_243});
    }
    case TAG_CStruct: {
      V v_fs_2429 = heff_field(v_n1_242, 0);
      V v_ru_24n1_242_24CStruct = heff_take_reuse_n(v_n1_242, 1ULL, 1);
      heff_drop_tag(v_n_241, 2);
      V v_t_2439 = (g_list_2emap(heff_clo_n(g_heff_2eelab_2eclauses_2erenameChkF_lam0, 1, 1, (V[]){v_r_240}), v_fs_2429));
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24n1_242_24CStruct, TAG_CStruct, 1, (V[]){v_t_2439}), v_sp_243});
    }
    case TAG_CMatch: {
      V v_s_2440 = heff_field(v_n1_242, 0);
      V v_alts_2441 = heff_field(v_n1_242, 1);
      V v_ru_24n1_242_24CMatch = heff_take_reuse_n(v_n1_242, 3ULL, 2);
      heff_drop_tag(v_n_241, 2);
      V v_t_2442 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 2)), 1, (V[]){v_s_2440}));
      V v_t_2443 = heff_tr(heff_call(((V)&g_heff_2eelab_2eclauses_2erenameAlt_clo), 1, (V[]){v_r_240}));
      V v_t_2444 = (g_list_2emap(v_t_2443, v_alts_2441));
      return heff_tag_at_n(v_ru_24n1_242_24CMatch, TAG_At, 2, (V[]){heff_tag_n(TAG_CMatch, 2, (V[]){v_t_2442, v_t_2444}), v_sp_243});
    }
    case TAG_CLetIn: {
      V v_rhs_2445 = heff_field(v_n1_242, 0);
      V v_a_2446 = heff_field(v_n1_242, 1);
      V v_ru_24n1_242_24CLetIn = heff_take_reuse_n(v_n1_242, 3ULL, 2);
      heff_drop_tag(v_n_241, 2);
      V v_t_2447 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 2)), 1, (V[]){v_rhs_2445}));
      V v_t_2448 = (g_heff_2eelab_2eclauses_2erenameAlt(v_r_240, v_a_2446));
      return heff_tag_at_n(v_ru_24n1_242_24CLetIn, TAG_At, 2, (V[]){heff_tag_n(TAG_CLetIn, 2, (V[]){v_t_2447, v_t_2448}), v_sp_243});
    }
    case TAG_CLocal: {
      V v_body_2449 = heff_field(v_n1_242, 0);
      V v_ds_2450 = heff_field(v_n1_242, 1);
      V v_ru_24n1_242_24CLocal = heff_take_reuse_n(v_n1_242, 3ULL, 2);
      heff_drop_tag(v_n_241, 2);
      V v_t_2476 = (g_heff_2eelab_2eclauses_2eanyC(heff_clo_n(g_heff_2eelab_2eclauses_2erenameChkF_lam1, 1, 1, (V[]){heff_dup(v_r_240)}), v_ds_2450));
      V v_t_2477;
      if ((heff_dup(v_t_2476) == NTAG(TAG_True))) {
        heff_drop(v_t_2476);
        v_t_2477 = v_body_2449;
      } else {
        heff_drop(v_t_2476);
        v_t_2477 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 3)), 1, (V[]){v_body_2449}));
      }
      V v_t_2478 = heff_tr(heff_call(((V)&g_heff_2eelab_2eclauses_2erenameDecl_clo), 1, (V[]){heff_dup(v_r_240)}));
      V v_t_24104 = (g_heff_2eelab_2eclauses_2erenameSeq(v_t_2478, heff_clo_n(g_heff_2eelab_2eclauses_2erenameChkF_lam2, 1, 1, (V[]){v_r_240}), v_ds_2450));
      return heff_tag_at_n(v_ru_24n1_242_24CLocal, TAG_At, 2, (V[]){heff_tag_n(TAG_CLocal, 2, (V[]){v_t_2477, v_t_24104}), v_sp_243});
    }
    case TAG_CAbandon: {
      heff_drop_rec(v_r_240, 5);
      heff_drop(v_sp_243);
      return v_n_241;
    }
    case TAG_CNominal: {
      V v_c_24105 = heff_field(v_n1_242, 0);
      V v_ru_24n1_242_24CNominal = heff_take_reuse_n(v_n1_242, 1ULL, 1);
      heff_drop_tag(v_n_241, 2);
      V v_t_24106 = heff_tr(heff_call(heff_get_n(v_r_240, 3, 5), 1, (V[]){v_c_24105}));
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24n1_242_24CNominal, TAG_CNominal, 1, (V[]){v_t_24106}), v_sp_243});
    }
    default: return heff_nomatch(v_n1_242);
    }
  }
  default: return heff_nomatch(v_n_241);
  }
}
V g_heff_2eelab_2eclauses_2erenameChkF_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2erenameChkF(a[0], a[1]);
}
V g_heff_2eelab_2eclauses_2erenameChkF_lam0(V self, V *args) {
  V v_x2_2430 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x2_2430)) {
  case TAG_At: {
    V v_x21_2431 = heff_field(v_x2_2430, 0);
    V v_sp_2432 = heff_field(v_x2_2430, 1);
    V v_ru_24x2_2430_24At = heff_take_reuse_n(v_x2_2430, 3ULL, 2);
    switch (heff_tag_of(v_x21_2431)) {
    case TAG_SetField: {
      V v_y_2433 = heff_field(v_x21_2431, 0);
      V v_ysp_2434 = heff_field(v_x21_2431, 1);
      V v_e_2435 = heff_field(v_x21_2431, 2);
      heff_take_n(v_x21_2431, 7ULL, 3);
      V v_t_2436 = heff_tr(heff_call(heff_get_n(v_r_240, 3, 5), 1, (V[]){v_e_2435}));
      return heff_tag_at_n(v_ru_24x2_2430_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_SetField, 3, (V[]){v_y_2433, v_ysp_2434, v_t_2436}), v_sp_2432});
    }
    case TAG_BadFieldSet: {
      V v_e_2437 = heff_field(v_x21_2431, 0);
      heff_take_n(v_x21_2431, 1ULL, 1);
      V v_t_2438 = heff_tr(heff_call(heff_get_n(v_r_240, 3, 5), 1, (V[]){v_e_2437}));
      return heff_tag_at_n(v_ru_24x2_2430_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_BadFieldSet, 1, (V[]){v_t_2438}), v_sp_2432});
    }
    default: return heff_nomatch(v_x21_2431);
    }
  }
  default: return heff_nomatch(v_x2_2430);
  }
}
V g_heff_2eelab_2eclauses_2erenameChkF_lam1(V self, V *args) {
  V v_d_2451 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2474;
  switch (heff_tag_of(v_d_2451)) {
  case TAG_At: {
    V v_x11_2452 = heff_field(v_d_2451, 0);
    heff_take_n(v_d_2451, 1ULL, 2);
    switch (heff_tag_of(v_x11_2452)) {
    case TAG_DeclEquations: {
      V v_f_2454 = heff_field(v_x11_2452, 0);
      heff_take_n(v_x11_2452, 1ULL, 5);
      v_t_2474 = heff_tag_n(TAG_Just, 1, (V[]){v_f_2454});
      break;
    }
    case TAG_DeclDefine: {
      V v_x_2459 = heff_field(v_x11_2452, 0);
      heff_take_n(v_x11_2452, 1ULL, 5);
      v_t_2474 = heff_tag_n(TAG_Just, 1, (V[]){v_x_2459});
      break;
    }
    case TAG_DeclTheory: {
      V v_x_2464 = heff_field(v_x11_2452, 0);
      heff_take_n(v_x11_2452, 1ULL, 4);
      v_t_2474 = heff_tag_n(TAG_Just, 1, (V[]){v_x_2464});
      break;
    }
    case TAG_DeclPrimitive: {
      V v_x_2468 = heff_field(v_x11_2452, 0);
      heff_take_n(v_x11_2452, 1ULL, 3);
      v_t_2474 = heff_tag_n(TAG_Just, 1, (V[]){v_x_2468});
      break;
    }
    case TAG_DeclTest: {
      V v_x_2471 = heff_field(v_x11_2452, 0);
      heff_take_n(v_x11_2452, 1ULL, 2);
      v_t_2474 = heff_tag_n(TAG_Just, 1, (V[]){v_x_2471});
      break;
    }
    case TAG_DeclWatch: {
      heff_take_n(v_x11_2452, 0ULL, 1);
      v_t_2474 = NTAG(TAG_Nothing);
      break;
    }
    default: heff_nomatch(v_x11_2452);
    }
    break;
  }
  default: heff_nomatch(v_d_2451);
  }
  switch (heff_tag_of(v_t_2474)) {
  case TAG_Nothing: {
    heff_drop_rec(v_r_240, 5);
    return NTAG(TAG_False);
  }
  case TAG_Just: {
    V v_y_2475 = heff_field(v_t_2474, 0);
    heff_take_n(v_t_2474, 1ULL, 1);
    return heff_strEq(heff_get_n(v_r_240, 0, 5), v_y_2475);
  }
  default: return heff_nomatch(v_t_2474);
  }
}
V g_heff_2eelab_2eclauses_2erenameChkF_lam2(V self, V *args) {
  V v_d_2479 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24102;
  switch (heff_tag_of(v_d_2479)) {
  case TAG_At: {
    V v_x11_2480 = heff_field(v_d_2479, 0);
    heff_take_n(v_d_2479, 1ULL, 2);
    switch (heff_tag_of(v_x11_2480)) {
    case TAG_DeclEquations: {
      V v_f_2482 = heff_field(v_x11_2480, 0);
      heff_take_n(v_x11_2480, 1ULL, 5);
      v_t_24102 = heff_tag_n(TAG_Just, 1, (V[]){v_f_2482});
      break;
    }
    case TAG_DeclDefine: {
      V v_x_2487 = heff_field(v_x11_2480, 0);
      heff_take_n(v_x11_2480, 1ULL, 5);
      v_t_24102 = heff_tag_n(TAG_Just, 1, (V[]){v_x_2487});
      break;
    }
    case TAG_DeclTheory: {
      V v_x_2492 = heff_field(v_x11_2480, 0);
      heff_take_n(v_x11_2480, 1ULL, 4);
      v_t_24102 = heff_tag_n(TAG_Just, 1, (V[]){v_x_2492});
      break;
    }
    case TAG_DeclPrimitive: {
      V v_x_2496 = heff_field(v_x11_2480, 0);
      heff_take_n(v_x11_2480, 1ULL, 3);
      v_t_24102 = heff_tag_n(TAG_Just, 1, (V[]){v_x_2496});
      break;
    }
    case TAG_DeclTest: {
      V v_x_2499 = heff_field(v_x11_2480, 0);
      heff_take_n(v_x11_2480, 1ULL, 2);
      v_t_24102 = heff_tag_n(TAG_Just, 1, (V[]){v_x_2499});
      break;
    }
    case TAG_DeclWatch: {
      heff_take_n(v_x11_2480, 0ULL, 1);
      v_t_24102 = NTAG(TAG_Nothing);
      break;
    }
    default: heff_nomatch(v_x11_2480);
    }
    break;
  }
  default: heff_nomatch(v_d_2479);
  }
  switch (heff_tag_of(v_t_24102)) {
  case TAG_Nothing: {
    heff_drop_rec(v_r_240, 5);
    return NTAG(TAG_False);
  }
  case TAG_Just: {
    V v_y_24103 = heff_field(v_t_24102, 0);
    heff_take_n(v_t_24102, 1ULL, 1);
    return heff_strEq(heff_get_n(v_r_240, 0, 5), v_y_24103);
  }
  default: return heff_nomatch(v_t_24102);
  }
}
V g_heff_2eelab_2eclauses_2erenamer_lam0(V self, V *args);
V g_heff_2eelab_2eclauses_2erenamer_lam1(V self, V *args);
V g_heff_2eelab_2eclauses_2erenamer_lam2(V self, V *args);
Clo g_heff_2eelab_2eclauses_2erenamer_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2erenamer_entry, 2, 0};

V g_heff_2eelab_2eclauses_2erenamer(V v_x_240, V v_v_241) {
top: ;
  return heff_rec_n(5, shape_x__v__inf__chk__typ, (V[]){heff_dup(v_x_240), heff_dup(v_v_241), heff_clo_n(g_heff_2eelab_2eclauses_2erenamer_lam0, 1, 2, (V[]){heff_dup(v_x_240), heff_dup(v_v_241)}), heff_clo_n(g_heff_2eelab_2eclauses_2erenamer_lam1, 1, 2, (V[]){heff_dup(v_x_240), heff_dup(v_v_241)}), heff_clo_n(g_heff_2eelab_2eclauses_2erenamer_lam2, 1, 2, (V[]){v_x_240, v_v_241})});
}
V g_heff_2eelab_2eclauses_2erenamer_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2erenamer(a[0], a[1]);
}
V g_heff_2eelab_2eclauses_2erenamer_lam0(V self, V *args) {
  V v_n_242 = args[0];
  V v_x_240 = heff_env(self)[0];
  V v_v_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_243 = (g_heff_2eelab_2eclauses_2erenamer(v_x_240, v_v_241));
  return (g_heff_2eelab_2eclauses_2erenameInfF(v_t_243, v_n_242));
}
V g_heff_2eelab_2eclauses_2erenamer_lam1(V self, V *args) {
  V v_n_244 = args[0];
  V v_x_240 = heff_env(self)[0];
  V v_v_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_245 = (g_heff_2eelab_2eclauses_2erenamer(v_x_240, v_v_241));
  return (g_heff_2eelab_2eclauses_2erenameChkF(v_t_245, v_n_244));
}
V g_heff_2eelab_2eclauses_2erenamer_lam2(V self, V *args) {
  V v_n_246 = args[0];
  V v_x_240 = heff_env(self)[0];
  V v_v_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_247 = (g_heff_2eelab_2eclauses_2erenamer(v_x_240, v_v_241));
  return (g_heff_2eelab_2eclauses_2erenameTypF(v_t_247, v_n_246));
}
HEFF_LIT(g_heff_2eelab_2eclauses_2earmSubName_str0, 1, "_");
Clo g_heff_2eelab_2eclauses_2earmSubName_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2earmSubName_entry, 5, 0};

V g_heff_2eelab_2eclauses_2earmSubName(V v_used_240, V v_bound_241, V v_v_242, V v_i_243, V v_x5_244) {
top: ;
  switch (heff_tag_of(v_x5_244)) {
  case TAG_Nothing: {
    V v_t_245 = heff_intShow(heff_intAdd(v_i_243, MK_INT(1LL)));
    return (g_heff_2eelab_2eclauses_2efreshIn(v_used_240, v_bound_241, heff_strAppend(v_v_242, v_t_245)));
  }
  case TAG_Just: {
    V v_x_246 = heff_field(v_x5_244, 0);
    if (heff_strEq_c(heff_dup(v_x_246), ((V)&g_heff_2eelab_2eclauses_2earmSubName_str0))) {
      V v_t_248 = heff_intShow(heff_intAdd(v_i_243, MK_INT(1LL)));
      return (g_heff_2eelab_2eclauses_2efreshIn(v_used_240, v_bound_241, heff_strAppend(v_v_242, v_t_248)));
    } else {
      V v_t_249 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(v_x_246)}));
      V v_x1_2410 = (g_list_2eany(v_t_249, v_bound_241));
      if ((heff_dup(v_x1_2410) == NTAG(TAG_True))) {
        heff_drop(v_x1_2410);
        V v_t_2411 = heff_intShow(heff_intAdd(v_i_243, MK_INT(1LL)));
        return (g_heff_2eelab_2eclauses_2efreshIn(v_used_240, v_bound_241, heff_strAppend(v_v_242, v_t_2411)));
      } else {
        heff_drop(v_v_242);
        heff_drop(v_i_243);
        heff_drop(v_x1_2410);
        return heff_dup(v_x_246);
      }
    }
  }
  default: return heff_nomatch(v_x5_244);
  }
}
V g_heff_2eelab_2eclauses_2earmSubName_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a4 = a[4]; V r = g_heff_2eelab_2eclauses_2earmSubName(a0, a1, a[2], a[3], a4); heff_drop(a0); heff_drop(a1); heff_drop(a4); return r;
}
HEFF_LIT(g_heff_2eelab_2eclauses_2elitYesOne_str0, 1, "_");
HEFF_LIT(g_heff_2eelab_2eclauses_2elitYesOne_str1, 1, "_");
Clo g_heff_2eelab_2eclauses_2elitYesOne_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2elitYesOne_entry, 5, 0};

V g_heff_2eelab_2eclauses_2elitYesOne(V v_c_240, V v_l_241, V v_v_242, V v_r_243, V v_acc_244) {
top: ;
  V v_t_245 = (g_heff_2eelab_2eclauses_2enthC(heff_rfield(v_r_243, 0), heff_dup(v_c_240)));
  V v_t_247;
  switch (heff_tag_of(v_t_245)) {
  case TAG_Nothing: {
    v_t_247 = heff_tag_n(TAG_PVar, 1, (V[]){((V)&g_heff_2eelab_2eclauses_2elitYesOne_str0)});
    break;
  }
  case TAG_Just: {
    V v_p_246 = heff_field(v_t_245, 0);
    heff_take_n(v_t_245, 1ULL, 1);
    v_t_247 = v_p_246;
    break;
  }
  default: heff_nomatch(v_t_245);
  }
  switch (heff_tag_of(v_t_247)) {
  case TAG_PVar: {
    V v_x_248 = heff_field(v_t_247, 0);
    heff_take_n(v_t_247, 1ULL, 1);
    V v_pats_249 = (g_heff_2eelab_2eclauses_2edropAt(v_c_240, heff_take_field(v_r_243, 0)));
    V v_e_2410 = heff_get_n(v_r_243, 1, 2);
    V v_rhs_2414;
    if (heff_strEq_c(heff_dup(v_x_248), ((V)&g_heff_2eelab_2eclauses_2elitYesOne_str1))) {
      heff_drop(v_v_242);
      heff_drop(v_x_248);
      v_rhs_2414 = v_e_2410;
    } else {
      if (heff_strEq_c(heff_dup(v_x_248), heff_dup(v_v_242))) {
        heff_drop(v_v_242);
        heff_drop(v_x_248);
        v_rhs_2414 = v_e_2410;
      } else {
        V v_t_2413 = (g_heff_2eelab_2eclauses_2erenamer(v_x_248, v_v_242));
        v_rhs_2414 = heff_tr(heff_call(heff_get_n(v_t_2413, 3, 5), 1, (V[]){v_e_2410}));
      }
    }
    return heff_tag_n(TAG_Cons, 2, (V[]){heff_rec_n(2, shape_pats__rhs, (V[]){v_pats_249, v_rhs_2414}), v_acc_244});
  }
  case TAG_PTag: {
    heff_take_n(v_t_247, 0ULL, 3);
    heff_drop(v_c_240);
    heff_drop(v_v_242);
    heff_drop_rec(v_r_243, 2);
    return v_acc_244;
  }
  case TAG_PLit: {
    V v_l_27_2418 = heff_field(v_t_247, 0);
    heff_take_n(v_t_247, 1ULL, 1);
    heff_drop(v_v_242);
    V v_t_2419 = ({ V a_0 = v_l_241; V a_1 = v_l_27_2418; V r_ = (g_heff_2eelab_2eclauses_2esameLit(a_0, a_1)); heff_drop(v_l_27_2418); r_; });
    if ((heff_dup(v_t_2419) == NTAG(TAG_True))) {
      heff_drop(v_t_2419);
      V v_pats_2420 = (g_heff_2eelab_2eclauses_2edropAt(v_c_240, heff_take_field(v_r_243, 0)));
      V v_t_2421 = ({ V rv_0 = v_pats_2420; V rr_ = heff_rec_reuse_nf(v_r_243, 2ULL, 2, shape_pats__rhs, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
      return heff_tag_n(TAG_Cons, 2, (V[]){v_t_2421, v_acc_244});
    } else {
      heff_drop(v_c_240);
      heff_drop_rec(v_r_243, 2);
      heff_drop(v_t_2419);
      return v_acc_244;
    }
  }
  case TAG_PRec: {
    heff_take_n(v_t_247, 0ULL, 2);
    heff_drop(v_c_240);
    heff_drop(v_v_242);
    heff_drop_rec(v_r_243, 2);
    return v_acc_244;
  }
  case TAG_PAs: {
    heff_take_n(v_t_247, 0ULL, 2);
    heff_drop(v_c_240);
    heff_drop(v_v_242);
    heff_drop_rec(v_r_243, 2);
    return v_acc_244;
  }
  default: return heff_nomatch(v_t_247);
  }
}
V g_heff_2eelab_2eclauses_2elitYesOne_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2eclauses_2elitYesOne(a[0], a1, a[2], a[3], a[4]); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2eelab_2eclauses_2enoLitHere_str0, 43, "a literal and a tag match the same argument");
V g_heff_2eelab_2eclauses_2enoLitHere_lam0(V self, V *args);
Clo g_heff_2eelab_2eclauses_2enoLitHere_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2enoLitHere_entry, 3, 0};

V g_heff_2eelab_2eclauses_2enoLitHere(V v_sp_240, V v_c_241, V v_rows_242) {
top: ;
  return (g_heff_2eelab_2eclauses_2eforC(v_rows_242, heff_clo_n(g_heff_2eelab_2eclauses_2enoLitHere_lam0, 1, 1, (V[]){v_c_241})));
}
V g_heff_2eelab_2eclauses_2enoLitHere_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a2 = a[2]; V r = g_heff_2eelab_2eclauses_2enoLitHere(a0, a[1], a2); heff_drop(a0); heff_drop(a2); return r;
}
V g_heff_2eelab_2eclauses_2enoLitHere_lam0(V self, V *args) {
  V v_row_243 = args[0];
  V v_c_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_244 = ({ V b_0 = heff_get_n(v_row_243, 0, 2); V a_1 = v_c_241; V r_ = (g_heff_2eelab_2eclauses_2enthC(b_0, a_1)); heff_drop(b_0); r_; });
  switch (heff_tag_of(v_t_244)) {
  case TAG_Nothing: {
    return heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
  }
  case TAG_Just: {
    V v_p_245 = heff_field(v_t_244, 0);
    V v_ru_24t_244_24Just = heff_take_reuse_n(v_t_244, 1ULL, 1);
    switch (heff_tag_of(v_p_245)) {
    case TAG_PVar: {
      heff_take_n(v_p_245, 0ULL, 1);
      return heff_tag_at_n(v_ru_24t_244_24Just, TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
    }
    case TAG_PTag: {
      heff_take_n(v_p_245, 0ULL, 3);
      return heff_tag_at_n(v_ru_24t_244_24Just, TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
    }
    case TAG_PLit: {
      V v_l_2410 = heff_field(v_p_245, 0);
      heff_take_n(v_p_245, 1ULL, 1);
      V v_span_2413;
      switch (heff_tag_of(v_l_2410)) {
      case TAG_At: {
        V v_s_2412 = heff_field(v_l_2410, 1);
        heff_take_n(v_l_2410, 2ULL, 2);
        v_span_2413 = v_s_2412;
        break;
      }
      default: heff_nomatch(v_l_2410);
      }
      return heff_tag_at_n(v_ru_24t_244_24Just, TAG_Left, 1, (V[]){heff_rec_n(2, shape_span__msg, (V[]){v_span_2413, ((V)&g_heff_2eelab_2eclauses_2enoLitHere_str0)})});
    }
    case TAG_PRec: {
      heff_take_n(v_p_245, 0ULL, 2);
      return heff_tag_at_n(v_ru_24t_244_24Just, TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
    }
    case TAG_PAs: {
      heff_take_n(v_p_245, 0ULL, 2);
      return heff_tag_at_n(v_ru_24t_244_24Just, TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
    }
    default: return heff_nomatch(v_p_245);
    }
  }
  default: return heff_nomatch(v_t_244);
  }
}
HEFF_LIT(g_heff_2eelab_2eclauses_2erecFieldVar_str0, 1, "_");
V g_heff_2eelab_2eclauses_2erecFieldVar_lam0(V self, V *args);
Clo g_heff_2eelab_2eclauses_2erecFieldVar_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2erecFieldVar_entry, 3, 0};

V g_heff_2eelab_2eclauses_2erecFieldVar(V v_c_240, V v_rows_241, V v_f_242) {
top: ;
  V v_t_2417 = (g_list_2emap(heff_clo_n(g_heff_2eelab_2eclauses_2erecFieldVar_lam0, 1, 2, (V[]){v_c_240, v_f_242}), v_rows_241));
  V v_t_2418 = (g_heff_2eelab_2eclauses_2ecatMaybesC(v_t_2417));
  switch (heff_tag_of(v_t_2418)) {
  case TAG_Nil: {
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_p_2419 = heff_field(v_t_2418, 0);
    heff_take_n(v_t_2418, 1ULL, 2);
    switch (heff_tag_of(v_p_2419)) {
    case TAG_PVar: {
      V v_x_2421 = heff_field(v_p_2419, 0);
      V v_ru_24p_2419_24PVar = heff_take_reuse_n(v_p_2419, 1ULL, 1);
      return heff_tag_at_n(v_ru_24p_2419_24PVar, TAG_Just, 1, (V[]){v_x_2421});
    }
    case TAG_PTag: {
      heff_take_n(v_p_2419, 0ULL, 3);
      return NTAG(TAG_Nothing);
    }
    case TAG_PLit: {
      heff_take_n(v_p_2419, 0ULL, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_PRec: {
      heff_take_n(v_p_2419, 0ULL, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_PAs: {
      V v_x_2428 = heff_field(v_p_2419, 0);
      heff_take_n(v_p_2419, 1ULL, 2);
      return heff_tag_n(TAG_Just, 1, (V[]){v_x_2428});
    }
    default: return heff_nomatch(v_p_2419);
    }
  }
  default: return heff_nomatch(v_t_2418);
  }
}
V g_heff_2eelab_2eclauses_2erecFieldVar_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2erecFieldVar(a[0], a[1], a[2]);
}
V g_heff_2eelab_2eclauses_2erecFieldVar_lam0(V self, V *args) {
  V v_row_243 = args[0];
  V v_c_240 = heff_env(self)[0];
  V v_f_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_244 = ({ V b_0 = heff_get_n(v_row_243, 0, 2); V a_1 = v_c_240; V r_ = (g_heff_2eelab_2eclauses_2enthC(b_0, a_1)); heff_drop(b_0); r_; });
  V v_x1_246;
  switch (heff_tag_of(v_t_244)) {
  case TAG_Nothing: {
    v_x1_246 = heff_tag_n(TAG_PVar, 1, (V[]){((V)&g_heff_2eelab_2eclauses_2erecFieldVar_str0)});
    break;
  }
  case TAG_Just: {
    V v_p_245 = heff_field(v_t_244, 0);
    heff_take_n(v_t_244, 1ULL, 1);
    v_x1_246 = v_p_245;
    break;
  }
  default: heff_nomatch(v_t_244);
  }
  V v_t_2416;
  switch (heff_tag_of(v_x1_246)) {
  case TAG_PVar: {
    heff_take_n(v_x1_246, 0ULL, 1);
    v_t_2416 = NTAG(TAG_Nil);
    break;
  }
  case TAG_PTag: {
    heff_take_n(v_x1_246, 0ULL, 3);
    v_t_2416 = NTAG(TAG_Nil);
    break;
  }
  case TAG_PLit: {
    heff_take_n(v_x1_246, 0ULL, 1);
    v_t_2416 = NTAG(TAG_Nil);
    break;
  }
  case TAG_PRec: {
    V v_fps_2412 = heff_field(v_x1_246, 0);
    heff_take_n(v_x1_246, 1ULL, 2);
    v_t_2416 = v_fps_2412;
    break;
  }
  case TAG_PAs: {
    heff_take_n(v_x1_246, 0ULL, 2);
    v_t_2416 = NTAG(TAG_Nil);
    break;
  }
  default: heff_nomatch(v_x1_246);
  }
  return ({ V a_0 = v_f_242; V a_1 = v_t_2416; V r_ = (g_heff_2eelab_2eclauses_2elookupField(a_0, a_1)); heff_drop(v_t_2416); r_; });
}
HEFF_LIT(g_heff_2eelab_2eclauses_2eletFields_str0, 0, "");
Clo g_heff_2eelab_2eclauses_2eletFields_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2eletFields_entry, 4, 0};

V g_heff_2eelab_2eclauses_2eletFields(V v_sp_240, V v_v_241, V v_x3_242, V v_body_243) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop_rec(v_sp_240, 2);
    heff_drop(v_v_241);
    return v_body_243;
  }
  case TAG_Cons: {
    V v_x31_244 = heff_field(v_x3_242, 0);
    V v_rest_245 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    switch (heff_tag_of(v_x31_244)) {
    case TAG_MkPair: {
      V v_f_246 = heff_field(v_x31_244, 0);
      V v_y_247 = heff_field(v_x31_244, 1);
      V v_ru_24x31_244_24MkPair = heff_take_reuse_n(v_x31_244, 3ULL, 2);
      V v_t_248 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_At, 2, (V[]){heff_tag_n(TAG_IVar, 1, (V[]){heff_dup(v_v_241)}), heff_dup(v_sp_240)});
      V v_t_249 = heff_tag_at_n(v_ru_24x31_244_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_ArgProject, 1, (V[]){heff_dup(v_f_246)}), heff_dup(v_sp_240)});
      V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_249, NTAG(TAG_Nil)});
      V v_t_2411 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgProject, 1, (V[]){((V)&g_heff_2eelab_2eclauses_2eletFields_str0)}), heff_dup(v_sp_240)});
      V v_t_2412 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgProject, 1, (V[]){v_f_246}), heff_dup(v_sp_240)});
      V v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2412, NTAG(TAG_Nil)});
      V v_x1_2414 = ({ V a_0 = v_t_2411; V a_1 = v_t_2413; V r_ = (g_heff_2esyntax_2epresyntax_2elastOr(a_0, a_1)); heff_drop_tag(v_t_2413, 2); r_; });
      V v_b_2417;
      switch (heff_tag_of(v_x1_2414)) {
      case TAG_At: {
        V v_s_2416 = heff_field(v_x1_2414, 1);
        heff_take_n(v_x1_2414, 2ULL, 2);
        v_b_2417 = v_s_2416;
        break;
      }
      default: heff_nomatch(v_x1_2414);
      }
      V v_t_2418 = ({ V rv_0 = heff_dup(heff_rfield(v_sp_240, 0)); V rr_ = heff_rec_reuse_nf(v_b_2417, 2ULL, 2, shape_start__end, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
      V v_t_2419 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_248, v_t_2410}), v_t_2418});
      V v_e_2420 = (g_heff_2eelab_2eclauses_2eletFields(heff_dup(v_sp_240), v_v_241, v_rest_245, v_body_243));
      V v_t_2421 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_PatVar, 1, (V[]){v_y_247}), heff_dup(v_sp_240)});
      V v_b_2424;
      switch (heff_tag_of(v_e_2420)) {
      case TAG_At: {
        V v_s_2423 = heff_dup(heff_field(v_e_2420, 1));
        v_b_2424 = v_s_2423;
        break;
      }
      default: heff_nomatch(v_e_2420);
      }
      V v_t_2425 = ({ V rv_0 = heff_dup(heff_rfield(v_sp_240, 0)); V rr_ = heff_rec_reuse_nf(v_b_2424, 2ULL, 2, shape_start__end, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
      V v_t_2426 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_t_2421, v_e_2420}), v_t_2425});
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CLetIn, 2, (V[]){v_t_2419, v_t_2426}), v_sp_240});
    }
    default: return heff_nomatch(v_x31_244);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2eelab_2eclauses_2eletFields_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2eletFields(a[0], a[1], a[2], a[3]);
}
HEFF_LIT(g_heff_2eelab_2eclauses_2epeelAs_str0, 1, "_");
Clo g_heff_2eelab_2eclauses_2epeelAs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2epeelAs_entry, 3, 0};

V g_heff_2eelab_2eclauses_2epeelAs(V v_v_240, V v_p_241, V v_e_242) {
top: ;
  switch (heff_tag_of(v_p_241)) {
  case TAG_PVar: {
    heff_drop(v_v_240);
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_p_241, v_e_242});
  }
  case TAG_PTag: {
    heff_drop(v_v_240);
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_p_241, v_e_242});
  }
  case TAG_PLit: {
    heff_drop(v_v_240);
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_p_241, v_e_242});
  }
  case TAG_PRec: {
    heff_drop(v_v_240);
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_p_241, v_e_242});
  }
  case TAG_PAs: {
    V v_x_2410 = heff_field(v_p_241, 0);
    V v_p2_2411 = heff_field(v_p_241, 1);
    heff_take_n(v_p_241, 3ULL, 2);
    V v_t_2415;
    if (heff_strEq_c(heff_dup(v_x_2410), ((V)&g_heff_2eelab_2eclauses_2epeelAs_str0))) {
      heff_drop(v_x_2410);
      v_t_2415 = v_e_242;
    } else {
      if (heff_strEq_c(heff_dup(v_x_2410), heff_dup(v_v_240))) {
        heff_drop(v_x_2410);
        v_t_2415 = v_e_242;
      } else {
        V v_t_2414 = (g_heff_2eelab_2eclauses_2erenamer(v_x_2410, heff_dup(v_v_240)));
        v_t_2415 = heff_tr(heff_call(heff_get_n(v_t_2414, 3, 5), 1, (V[]){v_e_242}));
      }
    }
    V t_0 = v_v_240;
    V t_1 = v_p2_2411;
    V t_2 = v_t_2415;
    v_v_240 = t_0;
    v_p_241 = t_1;
    v_e_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_p_241);
  }
}
V g_heff_2eelab_2eclauses_2epeelAs_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2epeelAs(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2eelab_2eclauses_2ecolPick_str0, 1, "x");
HEFF_LIT(g_heff_2eelab_2eclauses_2ecolPick_str1, 1, "_");
HEFF_LIT(g_heff_2eelab_2eclauses_2ecolPick_str2, 1, "x");
HEFF_LIT(g_heff_2eelab_2eclauses_2ecolPick_str3, 1, "x");
Clo g_heff_2eelab_2eclauses_2ecolPick_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2ecolPick_entry, 3, 0};

V g_heff_2eelab_2eclauses_2ecolPick(V v_used_240, V v_i_241, V v_xs_242) {
top: ;
  switch (heff_tag_of(v_xs_242)) {
  case TAG_Nil: {
    V v_t_243 = heff_intShow(heff_intAdd(v_i_241, MK_INT(1LL)));
    return (g_heff_2eelab_2eclauses_2efresh(v_used_240, heff_strAppend(((V)&g_heff_2eelab_2eclauses_2ecolPick_str0), v_t_243)));
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_xs_242, 0);
    V v_xs2_245 = heff_field(v_xs_242, 1);
    switch (heff_tag_of(v_xs2_245)) {
    case TAG_Nil: {
      if (heff_strEq_c(heff_dup(v_x_244), ((V)&g_heff_2eelab_2eclauses_2ecolPick_str1))) {
        V v_t_247 = heff_intShow(heff_intAdd(v_i_241, MK_INT(1LL)));
        return (g_heff_2eelab_2eclauses_2efresh(v_used_240, heff_strAppend(((V)&g_heff_2eelab_2eclauses_2ecolPick_str2), v_t_247)));
      } else {
        heff_drop(v_i_241);
        return heff_dup(v_x_244);
      }
    }
    case TAG_Cons: {
      V v_t_2410 = heff_intShow(heff_intAdd(v_i_241, MK_INT(1LL)));
      return (g_heff_2eelab_2eclauses_2efresh(v_used_240, heff_strAppend(((V)&g_heff_2eelab_2eclauses_2ecolPick_str3), v_t_2410)));
    }
    default: return heff_nomatch(v_xs2_245);
    }
  }
  default: return heff_nomatch(v_xs_242);
  }
}
V g_heff_2eelab_2eclauses_2ecolPick_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a2 = a[2]; V r = g_heff_2eelab_2eclauses_2ecolPick(a0, a[1], a2); heff_drop(a0); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2eelab_2eclauses_2erecordWith_24s1263675322x1241970456_str0, 1, "_");
HEFF_LIT(g_heff_2eelab_2eclauses_2erecordWith_24s1263675322x1241970456_str1, 1, "_");
V g_heff_2eelab_2eclauses_2erecordWith_24s1263675322x1241970456_lam0(V self, V *args);
V g_heff_2eelab_2eclauses_2erecordWith_24s1263675322x1241970456_lam1(V self, V *args);
Clo g_heff_2eelab_2eclauses_2erecordWith_24s1263675322x1241970456_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2erecordWith_24s1263675322x1241970456_entry, 8, 0};

V g_heff_2eelab_2eclauses_2erecordWith_24s1263675322x1241970456(V v_used_240, V v_bound_241, V v_sp_242, V v_vars_243, V v_rows_244, V v_c_245, V v_fs_246, V v_ys_247) {
top: ;
  V v_x1_248 = (g_heff_2eelab_2eclauses_2enoRecMix(v_rows_244, heff_dup(v_c_245)));
  switch (heff_tag_of(v_x1_248)) {
  case TAG_Left: {
    V v_e_249 = heff_field(v_x1_248, 0);
    V v_ru_24x1_248_24Left = heff_take_reuse_n(v_x1_248, 1ULL, 1);
    heff_drop(v_bound_241);
    heff_drop(v_sp_242);
    heff_drop(v_vars_243);
    heff_drop(v_rows_244);
    heff_drop(v_c_245);
    heff_drop(v_fs_246);
    heff_drop(v_ys_247);
    return heff_tag_at_n(v_ru_24x1_248_24Left, TAG_Left, 1, (V[]){v_e_249});
  }
  case TAG_Right: {
    V v_ru_24x1_248_24Right = heff_take_reuse_n(v_x1_248, 0ULL, 1);
    V v_bound_2411 = (g_heff_2eelab_2eclauses_2eappendC(heff_dup(v_ys_247), v_bound_241));
    V v_t_2412 = (g_heff_2eelab_2eclauses_2etakeC(heff_dup(v_c_245), heff_dup(v_vars_243)));
    V v_t_2413 = (g_heff_2eelab_2eclauses_2edropC(heff_intAdd(heff_dup(v_c_245), MK_INT(1LL)), heff_dup(v_vars_243)));
    V v_t_2414 = (g_heff_2eelab_2eclauses_2eappendC(heff_dup(v_ys_247), v_t_2413));
    V v_vars_2415 = (g_heff_2eelab_2eclauses_2eappendC(v_t_2412, v_t_2414));
    V v_rows_2420 = (g_list_2emap(heff_clo_n(g_heff_2eelab_2eclauses_2erecordWith_24s1263675322x1241970456_lam0, 1, 3, (V[]){heff_dup(v_vars_243), heff_dup(v_c_245), heff_dup(v_fs_246)}), v_rows_244));
    V v_t_2422 = (g_list_2emap(heff_clo_n(g_heff_2eelab_2eclauses_2erecordWith_24s1263675322x1241970456_lam1, 1, 1, (V[]){heff_dup(v_vars_2415)}), v_rows_2420));
    V v_x1_2423 = (g_heff_2eelab_2eclauses_2ecompilePeeled_24s1600111562x907923193(v_used_240, v_bound_2411, heff_dup(v_sp_242), v_vars_2415, v_t_2422));
    switch (heff_tag_of(v_x1_2423)) {
    case TAG_Left: {
      V v_e_2424 = heff_field(v_x1_2423, 0);
      heff_take_n(v_x1_2423, 1ULL, 1);
      heff_drop(v_sp_242);
      heff_drop(v_vars_243);
      heff_drop(v_c_245);
      heff_drop(v_fs_246);
      heff_drop(v_ys_247);
      return heff_tag_at_n(v_ru_24x1_248_24Right, TAG_Left, 1, (V[]){v_e_2424});
    }
    case TAG_Right: {
      V v_x_2425 = heff_field(v_x1_2423, 0);
      heff_take_n(v_x1_2423, 1ULL, 1);
      V v_t_2426 = ({ V a_0 = v_vars_243; V a_1 = v_c_245; V r_ = (g_heff_2eelab_2eclauses_2enthC(a_0, a_1)); heff_drop(v_vars_243); r_; });
      V v_t_2428;
      switch (heff_tag_of(v_t_2426)) {
      case TAG_Nothing: {
        v_t_2428 = ((V)&g_heff_2eelab_2eclauses_2erecordWith_24s1263675322x1241970456_str1);
        break;
      }
      case TAG_Just: {
        V v_v_2427 = heff_field(v_t_2426, 0);
        heff_take_n(v_t_2426, 1ULL, 1);
        v_t_2428 = v_v_2427;
        break;
      }
      default: heff_nomatch(v_t_2426);
      }
      V v_t_2429 = (g_heff_2eelab_2eclauses_2ezipC(v_fs_246, v_ys_247));
      V v_t_2430 = (g_heff_2eelab_2eclauses_2eletFields(v_sp_242, v_t_2428, v_t_2429, v_x_2425));
      return heff_tag_at_n(v_ru_24x1_248_24Right, TAG_Right, 1, (V[]){v_t_2430});
    }
    default: return heff_nomatch(v_x1_2423);
    }
  }
  default: return heff_nomatch(v_x1_248);
  }
}
V g_heff_2eelab_2eclauses_2erecordWith_24s1263675322x1241970456_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2eclauses_2erecordWith_24s1263675322x1241970456(a0, a[1], a[2], a[3], a[4], a[5], a[6], a[7]); heff_drop(a0); return r;
}
V g_heff_2eelab_2eclauses_2erecordWith_24s1263675322x1241970456_lam0(V self, V *args) {
  V v_row_2416 = args[0];
  V v_vars_243 = heff_env(self)[0];
  V v_c_245 = heff_env(self)[1];
  V v_fs_246 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2417 = ({ V a_0 = v_vars_243; V a_1 = heff_dup(v_c_245); V r_ = (g_heff_2eelab_2eclauses_2enthC(a_0, a_1)); heff_drop(v_vars_243); r_; });
  V v_t_2419;
  switch (heff_tag_of(v_t_2417)) {
  case TAG_Nothing: {
    v_t_2419 = ((V)&g_heff_2eelab_2eclauses_2erecordWith_24s1263675322x1241970456_str0);
    break;
  }
  case TAG_Just: {
    V v_v_2418 = heff_field(v_t_2417, 0);
    heff_take_n(v_t_2417, 1ULL, 1);
    v_t_2419 = v_v_2418;
    break;
  }
  default: heff_nomatch(v_t_2417);
  }
  return (g_heff_2eelab_2eclauses_2erecSpecialize(v_c_245, v_fs_246, v_t_2419, v_row_2416));
}
V g_heff_2eelab_2eclauses_2erecordWith_24s1263675322x1241970456_lam1(V self, V *args) {
  V v_row_2421 = args[0];
  V v_vars_2415 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2eelab_2eclauses_2epeelCols(v_vars_2415, heff_dup(heff_rfield(v_row_2421, 0)), heff_get_n(v_row_2421, 1, 2)));
}
Clo g_heff_2eelab_2eclauses_2eappendC_24f668644975x857714735_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2eappendC_24f668644975x857714735_entry, 2, 0};

V g_heff_2eelab_2eclauses_2eappendC_24f668644975x857714735(V v_ys_240, V v_x1_241) {
top: ;
  switch (heff_tag_of(v_x1_241)) {
  case TAG_PVar: {
    V v_x_242 = heff_field(v_x1_241, 0);
    heff_take_n(v_x1_241, 1ULL, 1);
    V v_t_243 = (g_heff_2eelab_2eclauses_2eappendC(NTAG(TAG_Nil), v_ys_240));
    return heff_tag_n(TAG_Cons, 2, (V[]){v_x_242, v_t_243});
  }
  case TAG_PTag: {
    V v_ps_245 = heff_field(v_x1_241, 1);
    heff_take_n(v_x1_241, 2ULL, 3);
    V v_t_247 = ({ V a_0 = v_ps_245; V r_ = (g_heff_2eelab_2eclauses_2econcatMapC_24s1253148850x1225196638(a_0)); heff_drop(v_ps_245); r_; });
    HEFF_LAST return g_heff_2eelab_2eclauses_2eappendC(v_t_247, v_ys_240);
  }
  case TAG_PLit: {
    heff_take_n(v_x1_241, 0ULL, 1);
    return v_ys_240;
  }
  case TAG_PRec: {
    V v_fps_249 = heff_field(v_x1_241, 0);
    heff_take_n(v_x1_241, 1ULL, 2);
    V v_t_2411 = ({ V a_0 = v_fps_249; V r_ = (g_heff_2eelab_2eclauses_2econcatMapC_24s357394064x1182638230(a_0)); heff_drop(v_fps_249); r_; });
    HEFF_LAST return g_heff_2eelab_2eclauses_2eappendC(v_t_2411, v_ys_240);
  }
  case TAG_PAs: {
    V v_x_2412 = heff_field(v_x1_241, 0);
    V v_p_2413 = heff_field(v_x1_241, 1);
    V v_ru_24x1_241_24PAs = heff_take_reuse_n(v_x1_241, 3ULL, 2);
    V v_cell_2414 = heff_tag_at_n(v_ru_24x1_241_24PAs, TAG_Cons, 2, (V[]){v_x_2412, heff_hole()});
    V v_u_2415 = (g_heff_2eelab_2eclauses_2eappendC_24f668644975x857714735_24dps(v_ys_240, v_p_2413, heff_dup(v_cell_2414)));
    heff_drop(v_u_2415);
    return v_cell_2414;
  }
  default: return heff_nomatch(v_x1_241);
  }
}
V g_heff_2eelab_2eclauses_2eappendC_24f668644975x857714735_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2eappendC_24f668644975x857714735(a[0], a[1]);
}
Clo g_heff_2eelab_2eclauses_2eappendC_24f668644975x857714735_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2eappendC_24f668644975x857714735_24dps_entry, 3, 0};

V g_heff_2eelab_2eclauses_2eappendC_24f668644975x857714735_24dps(V v_ys_240, V v_x1_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x1_241)) {
  case TAG_PVar: {
    V v_x_243 = heff_field(v_x1_241, 0);
    heff_take_n(v_x1_241, 1ULL, 1);
    V v_t_244 = (g_heff_2eelab_2eclauses_2eappendC(NTAG(TAG_Nil), v_ys_240));
    return heff_setField(v_d_242, MK_INT(1LL), heff_tag_n(TAG_Cons, 2, (V[]){v_x_243, v_t_244}));
  }
  case TAG_PTag: {
    V v_ps_246 = heff_field(v_x1_241, 1);
    heff_take_n(v_x1_241, 2ULL, 3);
    V v_t_248 = ({ V a_0 = v_ps_246; V r_ = (g_heff_2eelab_2eclauses_2econcatMapC_24s1253148850x1225196638(a_0)); heff_drop(v_ps_246); r_; });
    V v_t_249 = (g_heff_2eelab_2eclauses_2eappendC(v_t_248, v_ys_240));
    return heff_setField(v_d_242, MK_INT(1LL), v_t_249);
  }
  case TAG_PLit: {
    heff_take_n(v_x1_241, 0ULL, 1);
    return heff_setField(v_d_242, MK_INT(1LL), v_ys_240);
  }
  case TAG_PRec: {
    V v_fps_2411 = heff_field(v_x1_241, 0);
    heff_take_n(v_x1_241, 1ULL, 2);
    V v_t_2413 = ({ V a_0 = v_fps_2411; V r_ = (g_heff_2eelab_2eclauses_2econcatMapC_24s357394064x1182638230(a_0)); heff_drop(v_fps_2411); r_; });
    V v_t_2414 = (g_heff_2eelab_2eclauses_2eappendC(v_t_2413, v_ys_240));
    return heff_setField(v_d_242, MK_INT(1LL), v_t_2414);
  }
  case TAG_PAs: {
    V v_x_2415 = heff_field(v_x1_241, 0);
    V v_p_2416 = heff_field(v_x1_241, 1);
    V v_ru_24x1_241_24PAs = heff_take_reuse_n(v_x1_241, 3ULL, 2);
    V v_cell_2417 = heff_tag_at_n(v_ru_24x1_241_24PAs, TAG_Cons, 2, (V[]){v_x_2415, heff_hole()});
    V v_u_2418 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_2417));
    heff_drop(v_u_2418);
    V t_0 = v_ys_240;
    V t_1 = v_p_2416;
    V t_2 = v_cell_2417;
    v_ys_240 = t_0;
    v_x1_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x1_241);
  }
}
V g_heff_2eelab_2eclauses_2eappendC_24f668644975x857714735_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2eappendC_24f668644975x857714735_24dps(a[0], a[1], a[2]);
}