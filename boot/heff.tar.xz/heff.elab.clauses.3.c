// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_ArgExplicit 50404
#define TAG_ArgNamed 38772
#define TAG_ArgProject 7906
#define TAG_At 8900
#define TAG_BadFieldDecl 11244
#define TAG_BadFieldSet 46507
#define TAG_CAbandon 30933
#define TAG_CAnnLam 19336
#define TAG_CImplicitLam 42557
#define TAG_CInf 46723
#define TAG_CLam 49210
#define TAG_CLetIn 34208
#define TAG_CLocal 54419
#define TAG_CMatch 53053
#define TAG_CNominal 13722
#define TAG_CStruct 46588
#define TAG_CTag 56892
#define TAG_CType 17595
#define TAG_DeclDefine 5286
#define TAG_DeclEquations 25755
#define TAG_DeclPrimitive 46335
#define TAG_DeclTest 38719
#define TAG_DeclTheory 39552
#define TAG_DeclWatch 51419
#define TAG_DeclareField 57313
#define TAG_Enter_24heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291 3888
#define TAG_Enter_24heff_2eelab_2eclauses_2eidentsTypF_24s506476740x533987156 11512
#define TAG_ExplicitParam 63083
#define TAG_IApp 21275
#define TAG_IBytes 10857
#define TAG_IInt 28905
#define TAG_IPrim 59489
#define TAG_IVar 40993
#define TAG_ImplicitParam 51130
#define TAG_Left 13886
#define TAG_MkAlt 55173
#define TAG_MkFieldPat 14710
#define TAG_PAs 26446
#define TAG_PBin 33976
#define TAG_PLit 43592
#define TAG_PRec 49217
#define TAG_PTag 51019
#define TAG_PVar 52952
#define TAG_PatAs 19989
#define TAG_PatBinary 13970
#define TAG_PatFloat 20302
#define TAG_PatInt 37275
#define TAG_PatOp 20420
#define TAG_PatRecord 42380
#define TAG_PatRune 53941
#define TAG_PatString 45794
#define TAG_PatTag 47430
#define TAG_PatVar 49363
#define TAG_PatWord 675
#define TAG_Right 62770
#define TAG_SegmentBinary 41188
#define TAG_SegmentBits 43687
#define TAG_SegmentFloat 21180
#define TAG_SegmentInteger 22664
#define TAG_SegmentUtf 5205
#define TAG_SetField 47531
#define TAG_SizeDefault 11444
#define TAG_SizeName 63845
#define TAG_SizeNumber 5591
#define LBL_anys 9494734
#define LBL_arms 9498206
#define LBL_bits 9519565
#define LBL_bound 295286168
#define LBL_chk 308000
#define LBL_decl 9574769
#define LBL_end 310101
#define LBL_flags 298871457
#define LBL_go 10063
#define LBL_inf 313947
#define LBL_len 316559
#define LBL_msg 317947
#define LBL_order 307364712
#define LBL_pats 9928951
#define LBL_rhs 322423
#define LBL_size 10026184
#define LBL_span 10032145
#define LBL_start 311115900
#define LBL_terms 311608737
#define LBL_ty 10476
#define LBL_typ 324869
#define LBL_used 10094724
#define LBL_v 336
#define LBL_value 313331083
#define LBL_x 338
static uint32_t shape_arms__order__anys[] = {LBL_arms, LBL_order, LBL_anys};
static uint32_t shape_bits__terms[] = {LBL_bits, LBL_terms};
static uint32_t shape_pats__rhs[] = {LBL_pats, LBL_rhs};
static uint32_t shape_span__msg[] = {LBL_span, LBL_msg};
static uint32_t shape_start__end[] = {LBL_start, LBL_end};
static uint32_t shape_x__v__inf__chk__typ[] = {LBL_x, LBL_v, LBL_inf, LBL_chk, LBL_typ};
static V prim_strEq_entry(V self, V *a) { (void)self; return heff_strEq(a[0], a[1]); }
static Clo prim_strEq_clo = {{0x80000000u, K_CLO, 0}, prim_strEq_entry, 2, 0};
V g_heff_2eelab_2eclauses_2eandC(V, V, V);
V g_heff_2eelab_2eclauses_2eandC_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2eandC_clo;
V g_heff_2eelab_2eclauses_2eanyC(V, V);
V g_heff_2eelab_2eclauses_2eanyC_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2eanyC_clo;
V g_heff_2eelab_2eclauses_2eanyC_24s1724875606x1273504888(V, V);
V g_heff_2eelab_2eclauses_2eanyC_24s1724875606x1273504888_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2eanyC_24s1724875606x1273504888_clo;
V g_heff_2eelab_2eclauses_2eanyC_24s44140518x185484176(V, V);
V g_heff_2eelab_2eclauses_2eanyC_24s44140518x185484176_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2eanyC_24s44140518x185484176_clo;
V g_heff_2eelab_2eclauses_2eappendC(V, V);
V g_heff_2eelab_2eclauses_2eappendC_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2eappendC_clo;
V g_heff_2eelab_2eclauses_2eappendC_24f668644975x857714735(V, V);
V g_heff_2eelab_2eclauses_2eappendC_24f668644975x857714735_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2eappendC_24f668644975x857714735_clo;
V g_heff_2eelab_2eclauses_2eappendC_24f668644975x857714735_24dps(V, V, V);
V g_heff_2eelab_2eclauses_2eappendC_24f668644975x857714735_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2eappendC_24f668644975x857714735_24dps_clo;
V g_heff_2eelab_2eclauses_2earmSubName(V, V, V, V, V, V, V);
V g_heff_2eelab_2eclauses_2earmSubName_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2earmSubName_clo;
V g_heff_2eelab_2eclauses_2ebinTest(V);
V g_heff_2eelab_2eclauses_2ebinTest_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2ebinTest_clo;
V g_heff_2eelab_2eclauses_2ebinTestOf(V, V, V);
V g_heff_2eelab_2eclauses_2ebinTestOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2ebinTestOf_clo;
HeffT2 g_heff_2eelab_2eclauses_2ebinaryOf_24s1676894398x132520022_24cpr(V, V, V, V, V, V, V, V);
V g_heff_2eelab_2eclauses_2ecatMaybesC(V);
V g_heff_2eelab_2eclauses_2ecatMaybesC_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2ecatMaybesC_clo;
V g_heff_2eelab_2eclauses_2ecodeTest(V, V, V, V);
V g_heff_2eelab_2eclauses_2ecodeTest_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2ecodeTest_clo;
V g_heff_2eelab_2eclauses_2ecolPick(V, V, V, V, V);
V g_heff_2eelab_2eclauses_2ecolPick_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2ecolPick_clo;
HeffT2 g_heff_2eelab_2eclauses_2ecompileAt_24s924891070x2102972655_24cpr(V, V, V, V, V, V, V);
V g_heff_2eelab_2eclauses_2econcatMapC(V, V);
V g_heff_2eelab_2eclauses_2econcatMapC_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2econcatMapC_clo;
V g_heff_2eelab_2eclauses_2econcatMapC_24s1253148850x1225196638(V);
V g_heff_2eelab_2eclauses_2econcatMapC_24s1253148850x1225196638_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2econcatMapC_24s1253148850x1225196638_clo;
V g_heff_2eelab_2eclauses_2econcatMapC_24s357394064x1182638230(V);
V g_heff_2eelab_2eclauses_2econcatMapC_24s357394064x1182638230_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2econcatMapC_24s357394064x1182638230_clo;
V g_heff_2eelab_2eclauses_2econcatMapC_24s497393573x331502823(V);
V g_heff_2eelab_2eclauses_2econcatMapC_24s497393573x331502823_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2econcatMapC_24s497393573x331502823_clo;
V g_heff_2eelab_2eclauses_2edropAt(V, V);
V g_heff_2eelab_2eclauses_2edropAt_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2edropAt_clo;
V g_heff_2eelab_2eclauses_2edropAt_24dps(V, V, V);
V g_heff_2eelab_2eclauses_2edropAt_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2edropAt_24dps_clo;
V g_heff_2eelab_2eclauses_2efits(V, V, V, V);
V g_heff_2eelab_2eclauses_2efits_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2efits_clo;
V g_heff_2eelab_2eclauses_2efloatRead(V, V, V, V);
V g_heff_2eelab_2eclauses_2efloatRead_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2efloatRead_clo;
V g_heff_2eelab_2eclauses_2efloatTest(V, V, V, V, V);
V g_heff_2eelab_2eclauses_2efloatTest_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2efloatTest_clo;
V g_heff_2eelab_2eclauses_2efoldr2_24s748482467x1603483005(V, V, V);
V g_heff_2eelab_2eclauses_2efoldr2_24s748482467x1603483005_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2efoldr2_24s748482467x1603483005_clo;
HeffT2 g_heff_2eelab_2eclauses_2eforC_24cpr(V, V);
V g_heff_2eelab_2eclauses_2efresh(V, V);
V g_heff_2eelab_2eclauses_2efresh_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2efresh_clo;
V g_heff_2eelab_2eclauses_2efreshIn(V, V, V);
V g_heff_2eelab_2eclauses_2efreshIn_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2efreshIn_clo;
V g_heff_2eelab_2eclauses_2eidentsChkF(V, V, V);
V g_heff_2eelab_2eclauses_2eidentsChkF_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2eidentsChkF_clo;
V g_heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291(V, V);
V g_heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291_clo;
V g_heff_2eelab_2eclauses_2eidentsTypF_24s506476740x533987156(V, V);
V g_heff_2eelab_2eclauses_2eidentsTypF_24s506476740x533987156_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2eidentsTypF_24s506476740x533987156_clo;
V g_heff_2eelab_2eclauses_2eintRead(V, V, V, V);
V g_heff_2eelab_2eclauses_2eintRead_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2eintRead_clo;
V g_heff_2eelab_2eclauses_2eintRead_24s1663986196x980850164(V, V, V, V);
V g_heff_2eelab_2eclauses_2eintRead_24s1663986196x980850164_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2eintRead_24s1663986196x980850164_clo;
V g_heff_2eelab_2eclauses_2eintTest(V, V, V, V, V, V, V, V, V);
V g_heff_2eelab_2eclauses_2eintTest_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2eintTest_clo;
V g_heff_2eelab_2eclauses_2eletFields(V, V, V, V);
V g_heff_2eelab_2eclauses_2eletFields_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2eletFields_clo;
V g_heff_2eelab_2eclauses_2elitYesOne(V, V, V, V, V);
V g_heff_2eelab_2eclauses_2elitYesOne_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2elitYesOne_clo;
HeffT2 g_heff_2eelab_2eclauses_2eliteralOf_24s1384803683x829952018_24cpr(V, V, V, V, V, V, V);
V g_heff_2eelab_2eclauses_2elookupField(V, V);
V g_heff_2eelab_2eclauses_2elookupField_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2elookupField_clo;
V g_heff_2eelab_2eclauses_2enameFits(V, V, V);
V g_heff_2eelab_2eclauses_2enameFits_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2enameFits_clo;
V g_heff_2eelab_2eclauses_2enamesOfAll(V, V, V);
V g_heff_2eelab_2eclauses_2enamesOfAll_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2enamesOfAll_clo;
V g_heff_2eelab_2eclauses_2enamesOfAll_24s2067092643x645415179(V, V);
V g_heff_2eelab_2eclauses_2enamesOfAll_24s2067092643x645415179_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2enamesOfAll_24s2067092643x645415179_clo;
V g_heff_2eelab_2eclauses_2enamesOfAll_24s291844836x707424588(V, V);
V g_heff_2eelab_2eclauses_2enamesOfAll_24s291844836x707424588_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2enamesOfAll_24s291844836x707424588_clo;
V g_heff_2eelab_2eclauses_2enamesOfAll_24s613549782x1232950246(V, V);
V g_heff_2eelab_2eclauses_2enamesOfAll_24s613549782x1232950246_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2enamesOfAll_24s613549782x1232950246_clo;
V g_heff_2eelab_2eclauses_2enamesOfAll_24s696343517x344434749(V, V);
V g_heff_2eelab_2eclauses_2enamesOfAll_24s696343517x344434749_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2enamesOfAll_24s696343517x344434749_clo;
V g_heff_2eelab_2eclauses_2enamesOfAll_24s880313170x30977071(V, V);
V g_heff_2eelab_2eclauses_2enamesOfAll_24s880313170x30977071_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2enamesOfAll_24s880313170x30977071_clo;
HeffT2 g_heff_2eelab_2eclauses_2enoLitHere_24cpr(V, V, V);
HeffT2 g_heff_2eelab_2eclauses_2enoRecMix_24cpr(V, V);
HeffT2 g_heff_2eelab_2eclauses_2enthC_24cpr(V, V);
V g_heff_2eelab_2eclauses_2enubStr(V);
V g_heff_2eelab_2eclauses_2enubStr_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2enubStr_clo;
V g_heff_2eelab_2eclauses_2enubStr_24dps(V, V);
V g_heff_2eelab_2eclauses_2enubStr_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2enubStr_24dps_clo;
V g_heff_2eelab_2eclauses_2eoffBytesC(V, V);
V g_heff_2eelab_2eclauses_2eoffBytesC_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2eoffBytesC_clo;
V g_heff_2eelab_2eclauses_2eoffC(V, V);
V g_heff_2eelab_2eclauses_2eoffC_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2eoffC_clo;
V g_heff_2eelab_2eclauses_2epartTest(V, V, V, V, V, V, V, V, V, V, V);
V g_heff_2eelab_2eclauses_2epartTest_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2epartTest_clo;
V g_heff_2eelab_2eclauses_2epatBinds(V);
V g_heff_2eelab_2eclauses_2epatBinds_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2epatBinds_clo;
V g_heff_2eelab_2eclauses_2epatIdents(V, V);
V g_heff_2eelab_2eclauses_2epatIdents_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2epatIdents_clo;
V g_heff_2eelab_2eclauses_2epatIdents_24dps(V, V, V);
V g_heff_2eelab_2eclauses_2epatIdents_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2epatIdents_24dps_clo;
V g_heff_2eelab_2eclauses_2epatVars(V);
V g_heff_2eelab_2eclauses_2epatVars_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2epatVars_clo;
V g_heff_2eelab_2eclauses_2epiIdents_24s20744116x2053008297_24cycle(V, V, V, V, V, V, V, V, V);
V g_heff_2eelab_2eclauses_2epiIdents_24s20744116x2053008297_24cycle_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2epiIdents_24s20744116x2053008297_24cycle_clo;
V g_heff_2eelab_2eclauses_2erecFieldVar(V, V, V);
V g_heff_2eelab_2eclauses_2erecFieldVar_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2erecFieldVar_clo;
HeffT2 g_heff_2eelab_2eclauses_2erecordNamed_24s570125606x1378596115_24cpr(V, V, V, V, V, V, V);
V g_heff_2eelab_2eclauses_2erenameAlt(V, V);
V g_heff_2eelab_2eclauses_2erenameAlt_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2erenameAlt_clo;
V g_heff_2eelab_2eclauses_2erenameChkF(V, V);
V g_heff_2eelab_2eclauses_2erenameChkF_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2erenameChkF_clo;
V g_heff_2eelab_2eclauses_2erenameDecl(V, V);
V g_heff_2eelab_2eclauses_2erenameDecl_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2erenameDecl_clo;
V g_heff_2eelab_2eclauses_2erenameInfF(V, V);
V g_heff_2eelab_2eclauses_2erenameInfF_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2erenameInfF_clo;
V g_heff_2eelab_2eclauses_2erenameSeq_24s1752939203x458176414(V, V, V);
V g_heff_2eelab_2eclauses_2erenameSeq_24s1752939203x458176414_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2erenameSeq_24s1752939203x458176414_clo;
V g_heff_2eelab_2eclauses_2erenameTypF(V, V);
V g_heff_2eelab_2eclauses_2erenameTypF_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2erenameTypF_clo;
V g_heff_2eelab_2eclauses_2erenamer(V, V);
V g_heff_2eelab_2eclauses_2erenamer_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2erenamer_clo;
V g_heff_2eelab_2eclauses_2eresolve(V, V);
V g_heff_2eelab_2eclauses_2eresolve_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2eresolve_clo;
V g_heff_2eelab_2eclauses_2erestC(V, V);
V g_heff_2eelab_2eclauses_2erestC_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2erestC_clo;
V g_heff_2eelab_2eclauses_2esameLit(V, V);
V g_heff_2eelab_2eclauses_2esameLit_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2esameLit_clo;
V g_heff_2eelab_2eclauses_2esegRead(V, V, V, V, V, V);
V g_heff_2eelab_2eclauses_2esegRead_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2esegRead_clo;
V g_heff_2eelab_2eclauses_2esegTest(V, V, V, V, V, V, V, V, V);
V g_heff_2eelab_2eclauses_2esegTest_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2esegTest_clo;
V g_heff_2eelab_2eclauses_2esizeOk(V, V, V, V, V);
V g_heff_2eelab_2eclauses_2esizeOk_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2esizeOk_clo;
V g_heff_2eelab_2eclauses_2etagColGo(V, V, V, V);
V g_heff_2eelab_2eclauses_2etagColGo_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2etagColGo_clo;
HeffT2 g_heff_2eelab_2eclauses_2etagsAt_24s2145414218x819308742_24cpr(V, V, V, V, V, V, V);
V g_heff_2eelab_2eclauses_2etakeC_24dps(V, V, V);
V g_heff_2eelab_2eclauses_2etakeC_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2etakeC_24dps_clo;
V g_heff_2eelab_2eclauses_2eupToGo(V, V);
V g_heff_2eelab_2eclauses_2eupToGo_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2eupToGo_clo;
V g_heff_2eelab_2eclauses_2eupToGo_24dps(V, V, V);
V g_heff_2eelab_2eclauses_2eupToGo_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2eupToGo_24dps_clo;
V g_heff_2eelab_2eclauses_2eutfRead(V, V, V, V);
V g_heff_2eelab_2eclauses_2eutfRead_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2eutfRead_clo;
V g_heff_2eelab_2eclauses_2eutfWidth(V, V, V, V);
V g_heff_2eelab_2eclauses_2eutfWidth_entry(V self, V *a);
extern Clo g_heff_2eelab_2eclauses_2eutfWidth_clo;
V g_heff_2esyntax_2epresyntax_2elastOr(V, V);
V g_heff_2esyntax_2epresyntax_2elastOr_entry(V self, V *a);
extern Clo g_heff_2esyntax_2epresyntax_2elastOr_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2ekeepIf_24s677751599x1843430141(V, V);
V g_list_2ekeepIf_24s677751599x1843430141_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s677751599x1843430141_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1243189782x897571843(V, V);
V g_list_2emap_24s1243189782x897571843_entry(V self, V *a);
extern Clo g_list_2emap_24s1243189782x897571843_clo;
V g_list_2emap_24s1386495485x1391533176(V, V);
V g_list_2emap_24s1386495485x1391533176_entry(V self, V *a);
extern Clo g_list_2emap_24s1386495485x1391533176_clo;
V g_list_2emap_24s1415906091x1371825187(V);
V g_list_2emap_24s1415906091x1371825187_entry(V self, V *a);
extern Clo g_list_2emap_24s1415906091x1371825187_clo;
V g_list_2emap_24s502656580x1955732096(V);
V g_list_2emap_24s502656580x1955732096_entry(V self, V *a);
extern Clo g_list_2emap_24s502656580x1955732096_clo;
V g_list_2emap_24s939813003x1383013550(V);
V g_list_2emap_24s939813003x1383013550_entry(V self, V *a);
extern Clo g_list_2emap_24s939813003x1383013550_clo;
V g_std_2emap_2eempty_get(void);
Clo g_heff_2eelab_2eclauses_2eanyC_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2eanyC_entry, 2, 0};

V g_heff_2eelab_2eclauses_2eanyC(V v_p_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_p_240);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_t_244 = heff_tr(heff_call(heff_dup(v_p_240), 1, (V[]){heff_dup(v_x_242)}));
    if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
      heff_drop(v_p_240);
      heff_drop(v_t_244);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_244);
      V t_0 = v_p_240;
      V t_1 = v_xs_243;
      v_p_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eelab_2eclauses_2eanyC_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2eclauses_2eanyC(a[0], a1); heff_drop(a1); return r;
}
Clo g_heff_2eelab_2eclauses_2enubStr_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2enubStr_entry, 1, 0};

V g_heff_2eelab_2eclauses_2enubStr(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x1_240, 0);
    V v_xs_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_cell_243 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_x_241), heff_hole()});
    V v_t_244 = ({ V a_0 = v_x_241; V a_1 = v_xs_242; V r_ = (g_list_2ekeepIf_24s677751599x1843430141(a_0, a_1)); heff_drop(v_x_241); r_; });
    V v_u_245 = (g_heff_2eelab_2eclauses_2enubStr_24dps(v_t_244, heff_dup(v_cell_243)));
    heff_drop(v_u_245);
    return v_cell_243;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2eclauses_2enubStr_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2enubStr(a[0]);
}
Clo g_heff_2eelab_2eclauses_2eupToGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2eupToGo_entry, 2, 0};

V g_heff_2eelab_2eclauses_2eupToGo(V v_i_240, V v_n_241) {
top: ;
  if (heff_intLe_c_lent(v_n_241, v_i_240, 0)) {
    heff_drop(v_i_240);
    heff_drop(v_n_241);
    return NTAG(TAG_Nil);
  } else {
    V v_cell_243 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_i_240), heff_hole()});
    V v_u_244 = (g_heff_2eelab_2eclauses_2eupToGo_24dps(heff_box_word((heff_unbox_word(v_i_240) + ((int64_t)1ULL))), v_n_241, heff_dup(v_cell_243)));
    heff_drop(v_u_244);
    return v_cell_243;
  }
}
V g_heff_2eelab_2eclauses_2eupToGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2eupToGo(a[0], a[1]);
}
Clo g_heff_2eelab_2eclauses_2eupToGo_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2eupToGo_24dps_entry, 3, 0};

V g_heff_2eelab_2eclauses_2eupToGo_24dps(V v_i_240, V v_n_241, V v_d_242) {
top: ;
  if (heff_intLe_c_lent(v_n_241, v_i_240, 0)) {
    heff_drop(v_i_240);
    heff_drop(v_n_241);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  } else {
    V v_cell_244 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_i_240), heff_hole()});
    V v_u_245 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_244));
    heff_drop(v_u_245);
    V t_0 = heff_intAdd(v_i_240, MK_INT(1LL));
    V t_1 = v_n_241;
    V t_2 = v_cell_244;
    v_i_240 = t_0;
    v_n_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
}
V g_heff_2eelab_2eclauses_2eupToGo_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2eupToGo_24dps(a[0], a[1], a[2]);
}
Clo g_heff_2eelab_2eclauses_2edropAt_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2edropAt_24dps_entry, 3, 0};

V g_heff_2eelab_2eclauses_2edropAt_24dps(V v_i_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_i_240);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (heff_intEq_c_lent(v_i_240, MK_INT(0LL), 2)) {
      heff_drop(v_i_240);
      heff_drop(v_x_243);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return heff_setField(v_d_242, MK_INT(1LL), v_xs_244);
    } else {
      V v_cell_246 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
      V v_u_247 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_246));
      heff_drop(v_u_247);
      V t_0 = heff_intSub(v_i_240, MK_INT(1LL));
      V t_1 = v_xs_244;
      V t_2 = v_cell_246;
      v_i_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eelab_2eclauses_2edropAt_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2edropAt_24dps(a[0], a[1], a[2]);
}
Clo g_heff_2eelab_2eclauses_2etakeC_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2etakeC_24dps_entry, 3, 0};

V g_heff_2eelab_2eclauses_2etakeC_24dps(V v_n_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_n_240);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    if (heff_intLe_c_lent(v_n_240, MK_INT(0LL), 2)) {
      heff_drop(v_n_240);
      heff_drop(v_x_243);
      heff_drop(v_xs_244);
      heff_drop_cell(v_ru_24x2_241_24Cons, 2);
      return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
    } else {
      V v_cell_246 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
      V v_u_247 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_246));
      heff_drop(v_u_247);
      V t_0 = heff_intSub(v_n_240, MK_INT(1LL));
      V t_1 = v_xs_244;
      V t_2 = v_cell_246;
      v_n_240 = t_0;
      v_x2_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eelab_2eclauses_2etakeC_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2etakeC_24dps(a[0], a[1], a[2]);
}
Clo g_heff_2eelab_2eclauses_2econcatMapC_24s1253148850x1225196638_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2econcatMapC_24s1253148850x1225196638_entry, 1, 0};

V g_heff_2eelab_2eclauses_2econcatMapC_24s1253148850x1225196638(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_243 = (g_heff_2eelab_2eclauses_2epatVars(heff_dup(v_x_241)));
    V v_t_244 = (g_heff_2eelab_2eclauses_2econcatMapC_24s1253148850x1225196638(v_xs_242));
    return (g_heff_2eelab_2eclauses_2eappendC(v_t_243, v_t_244));
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eelab_2eclauses_2econcatMapC_24s1253148850x1225196638_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2eclauses_2econcatMapC_24s1253148850x1225196638(a0); heff_drop(a0); return r;
}
Clo g_heff_2eelab_2eclauses_2enamesOfAll_24s613549782x1232950246_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2enamesOfAll_24s613549782x1232950246_entry, 2, 0};

V g_heff_2eelab_2eclauses_2enamesOfAll_24s613549782x1232950246(V v_x2_240, V v_acc_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return v_acc_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_247;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkFieldPat: {
      V v_a_244 = heff_field(v_x_242, 0);
      V v_a_245 = heff_field(v_x_242, 1);
      heff_take_n(v_x_242, 3ULL, 2);
      V v_t_246 = (g_heff_2eelab_2eclauses_2epatIdents(v_a_245, v_acc_241));
      v_t_247 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_a_244, v_t_246});
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V t_0 = v_xs_243;
    V t_1 = v_t_247;
    v_x2_240 = t_0;
    v_acc_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eelab_2eclauses_2enamesOfAll_24s613549782x1232950246_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2enamesOfAll_24s613549782x1232950246(a[0], a[1]);
}
Clo g_heff_2eelab_2eclauses_2epatIdents_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2epatIdents_24dps_entry, 3, 0};

V g_heff_2eelab_2eclauses_2epatIdents_24dps(V v_p_240, V v_acc_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_p_240)) {
  case TAG_At: {
    V v_p1_243 = heff_field(v_p_240, 0);
    V v_ru_24p_240_24At = heff_take_reuse_n(v_p_240, 1ULL, 2);
    switch (heff_tag_of(v_p1_243)) {
    case TAG_PatVar: {
      V v_x_245 = heff_field(v_p1_243, 0);
      heff_take_n(v_p1_243, 1ULL, 1);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      return heff_setField(v_d_242, MK_INT(1LL), heff_tag_n(TAG_Cons, 2, (V[]){v_x_245, v_acc_241}));
    }
    case TAG_PatTag: {
      V v_ps_248 = heff_field(v_p1_243, 2);
      heff_take_n(v_p1_243, 4ULL, 3);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      V v_t_249 = ({ V a_0 = v_ps_248; V a_1 = v_acc_241; V r_ = (g_heff_2eelab_2eclauses_2enamesOfAll_24s291844836x707424588(a_0, a_1)); heff_drop(v_ps_248); r_; });
      return heff_setField(v_d_242, MK_INT(1LL), v_t_249);
    }
    case TAG_PatOp: {
      V v_x_2410 = heff_field(v_p1_243, 0);
      V v_ps_2412 = heff_field(v_p1_243, 2);
      heff_take_n(v_p1_243, 5ULL, 3);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      V v_t_2413 = ({ V a_0 = v_ps_2412; V a_1 = v_acc_241; V r_ = (g_heff_2eelab_2eclauses_2enamesOfAll_24s291844836x707424588(a_0, a_1)); heff_drop(v_ps_2412); r_; });
      return heff_setField(v_d_242, MK_INT(1LL), heff_tag_n(TAG_Cons, 2, (V[]){v_x_2410, v_t_2413}));
    }
    case TAG_PatInt: {
      heff_take_n(v_p1_243, 0ULL, 1);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      return heff_setField(v_d_242, MK_INT(1LL), v_acc_241);
    }
    case TAG_PatFloat: {
      heff_take_na(v_p1_243, 0ULL, 1);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      return heff_setField(v_d_242, MK_INT(1LL), v_acc_241);
    }
    case TAG_PatString: {
      heff_take_n(v_p1_243, 0ULL, 1);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      return heff_setField(v_d_242, MK_INT(1LL), v_acc_241);
    }
    case TAG_PatBinary: {
      V v_segs_2417 = heff_field(v_p1_243, 0);
      heff_take_n(v_p1_243, 1ULL, 1);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      V v_t_2418 = (g_heff_2eelab_2eclauses_2enamesOfAll_24s696343517x344434749(v_segs_2417, v_acc_241));
      return heff_setField(v_d_242, MK_INT(1LL), v_t_2418);
    }
    case TAG_PatRune: {
      heff_take_n(v_p1_243, 0ULL, 1);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      return heff_setField(v_d_242, MK_INT(1LL), v_acc_241);
    }
    case TAG_PatRecord: {
      V v_fs_2420 = heff_field(v_p1_243, 0);
      heff_take_n(v_p1_243, 1ULL, 1);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      V v_t_2421 = (g_heff_2eelab_2eclauses_2enamesOfAll_24s613549782x1232950246(v_fs_2420, v_acc_241));
      return heff_setField(v_d_242, MK_INT(1LL), v_t_2421);
    }
    case TAG_PatWord: {
      heff_take_n(v_p1_243, 0ULL, 1);
      heff_drop_cell(v_ru_24p_240_24At, 2);
      return heff_setField(v_d_242, MK_INT(1LL), v_acc_241);
    }
    case TAG_PatAs: {
      V v_x_2423 = heff_field(v_p1_243, 0);
      V v_q_2425 = heff_field(v_p1_243, 2);
      heff_take_n(v_p1_243, 5ULL, 3);
      V v_cell_2426 = heff_tag_at_n(v_ru_24p_240_24At, TAG_Cons, 2, (V[]){v_x_2423, heff_hole()});
      V v_u_2427 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_2426));
      heff_drop(v_u_2427);
      V t_0 = v_q_2425;
      V t_1 = v_acc_241;
      V t_2 = v_cell_2426;
      v_p_240 = t_0;
      v_acc_241 = t_1;
      v_d_242 = t_2;
      goto top;
    }
    default: return heff_nomatch(v_p1_243);
    }
  }
  default: return heff_nomatch(v_p_240);
  }
}
V g_heff_2eelab_2eclauses_2epatIdents_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2epatIdents_24dps(a[0], a[1], a[2]);
}
V g_heff_2eelab_2eclauses_2eidentsChkF_lam0(V self, V *args);
V g_heff_2eelab_2eclauses_2eidentsChkF_lam1(V self, V *args);
Clo g_heff_2eelab_2eclauses_2eidentsChkF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2eidentsChkF_entry, 3, 0};

V g_heff_2eelab_2eclauses_2eidentsChkF(V v_r_240, V v_x2_241, V v_acc_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_At: {
    V v_x21_243 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24At = heff_take_reuse_n(v_x2_241, 1ULL, 2);
    switch (heff_tag_of(v_x21_243)) {
    case TAG_CInf: {
      V v_i_245 = heff_field(v_x21_243, 0);
      heff_take_n(v_x21_243, 1ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24At, 2);
      return heff_tail(heff_get_n(v_r_240, 0, 4), 2, (V[]){v_i_245, v_acc_242});
    }
    case TAG_CType: {
      V v_t_246 = heff_field(v_x21_243, 0);
      heff_take_n(v_x21_243, 1ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24At, 2);
      return heff_tail(heff_get_n(v_r_240, 2, 4), 2, (V[]){v_t_246, v_acc_242});
    }
    case TAG_CLam: {
      V v_x_247 = heff_field(v_x21_243, 0);
      V v_b_249 = heff_field(v_x21_243, 2);
      heff_take_n(v_x21_243, 5ULL, 3);
      V v_t_2410 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 4), 2, (V[]){v_b_249, v_acc_242}));
      return heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_x_247, v_t_2410});
    }
    case TAG_CImplicitLam: {
      V v_x_2411 = heff_field(v_x21_243, 0);
      V v_b_2413 = heff_field(v_x21_243, 2);
      heff_take_n(v_x21_243, 5ULL, 3);
      V v_t_2414 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 4), 2, (V[]){v_b_2413, v_acc_242}));
      return heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_x_2411, v_t_2414});
    }
    case TAG_CAnnLam: {
      V v_x_2415 = heff_field(v_x21_243, 0);
      V v_t_2417 = heff_field(v_x21_243, 2);
      V v_b_2418 = heff_field(v_x21_243, 3);
      heff_take_n(v_x21_243, 13ULL, 4);
      V v_t_2419 = heff_tr(heff_call(heff_take_field(v_r_240, 1), 2, (V[]){v_b_2418, v_acc_242}));
      V v_t_2420 = heff_tr(heff_call(heff_get_n(v_r_240, 2, 4), 2, (V[]){v_t_2417, v_t_2419}));
      return heff_tag_at_n(v_ru_24x2_241_24At, TAG_Cons, 2, (V[]){v_x_2415, v_t_2420});
    }
    case TAG_CTag: {
      V v_args_2423 = heff_field(v_x21_243, 2);
      heff_take_n(v_x21_243, 4ULL, 3);
      heff_drop_cell(v_ru_24x2_241_24At, 2);
      return ({ V a_0 = heff_get_n(v_r_240, 1, 4); V a_1 = v_args_2423; V a_2 = v_acc_242; V r_ = (g_heff_2eelab_2eclauses_2enamesOfAll(a_0, a_1, a_2)); heff_drop(v_args_2423); r_; });
    }
    case TAG_CStruct: {
      V v_fs_2424 = heff_field(v_x21_243, 0);
      heff_take_n(v_x21_243, 1ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24At, 2);
      return ({ V a_0 = heff_clo_n(g_heff_2eelab_2eclauses_2eidentsChkF_lam0, 2, 1, (V[]){v_r_240}); V a_1 = v_fs_2424; V a_2 = v_acc_242; V r_ = (g_heff_2eelab_2eclauses_2enamesOfAll(a_0, a_1, a_2)); heff_drop(v_fs_2424); r_; });
    }
    case TAG_CMatch: {
      V v_s_2434 = heff_field(v_x21_243, 0);
      V v_alts_2435 = heff_field(v_x21_243, 1);
      heff_take_n(v_x21_243, 3ULL, 2);
      heff_drop_cell(v_ru_24x2_241_24At, 2);
      V v_t_2443 = ({ V a_0 = heff_clo_n(g_heff_2eelab_2eclauses_2eidentsChkF_lam1, 2, 1, (V[]){heff_dup(v_r_240)}); V a_1 = v_alts_2435; V a_2 = v_acc_242; V r_ = (g_heff_2eelab_2eclauses_2enamesOfAll(a_0, a_1, a_2)); heff_drop(v_alts_2435); r_; });
      return heff_tail(heff_get_n(v_r_240, 0, 4), 2, (V[]){v_s_2434, v_t_2443});
    }
    case TAG_CLetIn: {
      V v_rhs_2444 = heff_field(v_x21_243, 0);
      V v_a_2445 = heff_field(v_x21_243, 1);
      heff_take_n(v_x21_243, 3ULL, 2);
      heff_drop_cell(v_ru_24x2_241_24At, 2);
      V v_t_2451;
      switch (heff_tag_of(v_a_2445)) {
      case TAG_At: {
        V v_x21_2446 = heff_field(v_a_2445, 0);
        heff_take_n(v_a_2445, 1ULL, 2);
        switch (heff_tag_of(v_x21_2446)) {
        case TAG_MkAlt: {
          V v_p_2448 = heff_field(v_x21_2446, 0);
          V v_b_2449 = heff_field(v_x21_2446, 1);
          heff_take_n(v_x21_2446, 3ULL, 2);
          V v_t_2450 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 1)), 2, (V[]){v_b_2449, v_acc_242}));
          v_t_2451 = (g_heff_2eelab_2eclauses_2epatIdents(v_p_2448, v_t_2450));
          break;
        }
        default: heff_nomatch(v_x21_2446);
        }
        break;
      }
      default: heff_nomatch(v_a_2445);
      }
      return heff_tail(heff_get_n(v_r_240, 0, 4), 2, (V[]){v_rhs_2444, v_t_2451});
    }
    case TAG_CLocal: {
      V v_body_2452 = heff_field(v_x21_243, 0);
      V v_ds_2453 = heff_field(v_x21_243, 1);
      heff_take_n(v_x21_243, 3ULL, 2);
      heff_drop_cell(v_ru_24x2_241_24At, 2);
      V v_t_2454 = ({ V a_0 = heff_take_field(v_r_240, 3); V a_1 = v_ds_2453; V a_2 = v_acc_242; V r_ = (g_heff_2eelab_2eclauses_2enamesOfAll(a_0, a_1, a_2)); heff_drop(v_ds_2453); r_; });
      return heff_tail(heff_get_n(v_r_240, 1, 4), 2, (V[]){v_body_2452, v_t_2454});
    }
    case TAG_CAbandon: {
      heff_drop_rec(v_r_240, 4);
      heff_drop_cell(v_ru_24x2_241_24At, 2);
      return v_acc_242;
    }
    case TAG_CNominal: {
      V v_c_2455 = heff_field(v_x21_243, 0);
      heff_take_n(v_x21_243, 1ULL, 1);
      heff_drop_cell(v_ru_24x2_241_24At, 2);
      return heff_tail(heff_get_n(v_r_240, 1, 4), 2, (V[]){v_c_2455, v_acc_242});
    }
    default: return heff_nomatch(v_x21_243);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eelab_2eclauses_2eidentsChkF_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2eidentsChkF(a[0], a[1], a[2]);
}
V g_heff_2eelab_2eclauses_2eidentsChkF_lam0(V self, V *args) {
  V v_x2_2425 = args[0];
  V v_acc_2426 = args[1];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x2_2425)) {
  case TAG_At: {
    V v_x21_2427 = heff_field(v_x2_2425, 0);
    V v_ru_24x2_2425_24At = heff_take_reuse_n(v_x2_2425, 1ULL, 2);
    switch (heff_tag_of(v_x21_2427)) {
    case TAG_SetField: {
      V v_x_2429 = heff_field(v_x21_2427, 0);
      V v_e_2431 = heff_field(v_x21_2427, 2);
      heff_take_n(v_x21_2427, 5ULL, 3);
      V v_t_2432 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 4), 2, (V[]){v_e_2431, v_acc_2426}));
      return heff_tag_at_n(v_ru_24x2_2425_24At, TAG_Cons, 2, (V[]){v_x_2429, v_t_2432});
    }
    case TAG_BadFieldSet: {
      V v_e_2433 = heff_field(v_x21_2427, 0);
      heff_take_n(v_x21_2427, 1ULL, 1);
      heff_drop_cell(v_ru_24x2_2425_24At, 2);
      V f_ = heff_get_n(v_r_240, 1, 4);
      args[0] = v_e_2433;
      args[1] = v_acc_2426;
      if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 2, args);
    }
    default: return heff_nomatch(v_x21_2427);
    }
  }
  default: return heff_nomatch(v_x2_2425);
  }
}
V g_heff_2eelab_2eclauses_2eidentsChkF_lam1(V self, V *args) {
  V v_a_2436 = args[0];
  V v_b_2437 = args[1];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_a_2436)) {
  case TAG_At: {
    V v_x21_2438 = heff_field(v_a_2436, 0);
    heff_take_n(v_a_2436, 1ULL, 2);
    switch (heff_tag_of(v_x21_2438)) {
    case TAG_MkAlt: {
      V v_p_2440 = heff_field(v_x21_2438, 0);
      V v_b_2441 = heff_field(v_x21_2438, 1);
      heff_take_n(v_x21_2438, 3ULL, 2);
      V v_t_2442 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 4), 2, (V[]){v_b_2441, v_b_2437}));
      return (g_heff_2eelab_2eclauses_2epatIdents(v_p_2440, v_t_2442));
    }
    default: return heff_nomatch(v_x21_2438);
    }
  }
  default: return heff_nomatch(v_a_2436);
  }
}
Clo g_heff_2eelab_2eclauses_2enamesOfAll_24s2067092643x645415179_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2enamesOfAll_24s2067092643x645415179_entry, 2, 0};

V g_heff_2eelab_2eclauses_2enamesOfAll_24s2067092643x645415179(V v_x2_240, V v_acc_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return v_acc_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2411;
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_a_244 = heff_field(v_x_242, 0);
      heff_take_n(v_x_242, 1ULL, 2);
      switch (heff_tag_of(v_a_244)) {
      case TAG_ArgExplicit: {
        V v_a_246 = heff_field(v_a_244, 0);
        heff_take_n(v_a_244, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_240_24Cons, 2);
        v_t_2411 = (g_heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291(v_a_246, v_acc_241));
        break;
      }
      case TAG_ArgProject: {
        heff_take_n(v_a_244, 0ULL, 1);
        heff_drop_cell(v_ru_24x2_240_24Cons, 2);
        v_t_2411 = v_acc_241;
        break;
      }
      case TAG_ArgNamed: {
        V v_a_248 = heff_field(v_a_244, 0);
        V v_a_249 = heff_field(v_a_244, 1);
        heff_take_n(v_a_244, 3ULL, 2);
        V v_t_2410 = (g_heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291(v_a_249, v_acc_241));
        v_t_2411 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_a_248, v_t_2410});
        break;
      }
      default: heff_nomatch(v_a_244);
      }
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V t_0 = v_xs_243;
    V t_1 = v_t_2411;
    v_x2_240 = t_0;
    v_acc_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eelab_2eclauses_2enamesOfAll_24s2067092643x645415179_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2enamesOfAll_24s2067092643x645415179(a[0], a[1]);
}
Clo g_heff_2eelab_2eclauses_2enamesOfAll_24s880313170x30977071_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2enamesOfAll_24s880313170x30977071_entry, 2, 0};

V g_heff_2eelab_2eclauses_2enamesOfAll_24s880313170x30977071(V v_x2_240, V v_acc_241) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return v_acc_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_240, 0);
    V v_xs_243 = heff_field(v_x2_240, 1);
    V v_ru_24x2_240_24Cons = heff_take_reuse_n(v_x2_240, 3ULL, 2);
    V v_t_2414;
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_a_244 = heff_field(v_x_242, 0);
      heff_take_n(v_x_242, 1ULL, 2);
      switch (heff_tag_of(v_a_244)) {
      case TAG_DeclareField: {
        V v_a_246 = heff_field(v_a_244, 0);
        V v_a_248 = heff_field(v_a_244, 2);
        V v_a_249 = heff_field(v_a_244, 3);
        heff_take_n(v_a_244, 13ULL, 4);
        V v_a_2411;
        switch (heff_tag_of(v_a_249)) {
        case TAG_Nothing: {
          v_a_2411 = v_acc_241;
          break;
        }
        case TAG_Just: {
          V v_a_2410 = heff_field(v_a_249, 0);
          heff_take_n(v_a_249, 1ULL, 1);
          v_a_2411 = (g_heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291(v_a_2410, v_acc_241));
          break;
        }
        default: heff_nomatch(v_a_249);
        }
        V v_t_2412 = (g_heff_2eelab_2eclauses_2eidentsTypF_24s506476740x533987156(v_a_248, v_a_2411));
        v_t_2414 = heff_tag_at_n(v_ru_24x2_240_24Cons, TAG_Cons, 2, (V[]){v_a_246, v_t_2412});
        break;
      }
      case TAG_BadFieldDecl: {
        V v_a_2413 = heff_field(v_a_244, 0);
        heff_take_n(v_a_244, 1ULL, 1);
        heff_drop_cell(v_ru_24x2_240_24Cons, 2);
        v_t_2414 = (g_heff_2eelab_2eclauses_2eidentsTypF_24s506476740x533987156(v_a_2413, v_acc_241));
        break;
      }
      default: heff_nomatch(v_a_244);
      }
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V t_0 = v_xs_243;
    V t_1 = v_t_2414;
    v_x2_240 = t_0;
    v_acc_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eelab_2eclauses_2enamesOfAll_24s880313170x30977071_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2enamesOfAll_24s880313170x30977071(a[0], a[1]);
}
HEFF_LIT(g_heff_2eelab_2eclauses_2eidentsTypF_24s506476740x533987156_str0, 0, "");
HEFF_LIT(g_heff_2eelab_2eclauses_2eidentsTypF_24s506476740x533987156_str1, 0, "");
HEFF_LIT(g_heff_2eelab_2eclauses_2eidentsTypF_24s506476740x533987156_str2, 0, "");
HEFF_LIT(g_heff_2eelab_2eclauses_2eidentsTypF_24s506476740x533987156_str3, 0, "");
HEFF_LIT(g_heff_2eelab_2eclauses_2eidentsTypF_24s506476740x533987156_str4, 0, "");
HEFF_LIT(g_heff_2eelab_2eclauses_2eidentsTypF_24s506476740x533987156_str5, 0, "");
Clo g_heff_2eelab_2eclauses_2eidentsTypF_24s506476740x533987156_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2eidentsTypF_24s506476740x533987156_entry, 2, 0};

V g_heff_2eelab_2eclauses_2eidentsTypF_24s506476740x533987156(V v_n_240, V v_acc_241) {
top: ;
  return (g_heff_2eelab_2eclauses_2epiIdents_24s20744116x2053008297_24cycle(NTAG(TAG_Enter_24heff_2eelab_2eclauses_2eidentsTypF_24s506476740x533987156), ((V)&g_heff_2eelab_2eclauses_2eidentsTypF_24s506476740x533987156_str0), ((V)&g_heff_2eelab_2eclauses_2eidentsTypF_24s506476740x533987156_str1), v_n_240, v_acc_241, ((V)&g_heff_2eelab_2eclauses_2eidentsTypF_24s506476740x533987156_str2), ((V)&g_heff_2eelab_2eclauses_2eidentsTypF_24s506476740x533987156_str3), ((V)&g_heff_2eelab_2eclauses_2eidentsTypF_24s506476740x533987156_str4), ((V)&g_heff_2eelab_2eclauses_2eidentsTypF_24s506476740x533987156_str5)));
}
V g_heff_2eelab_2eclauses_2eidentsTypF_24s506476740x533987156_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2eidentsTypF_24s506476740x533987156(a[0], a[1]);
}
HEFF_LIT(g_heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291_str0, 0, "");
HEFF_LIT(g_heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291_str1, 0, "");
HEFF_LIT(g_heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291_str2, 0, "");
HEFF_LIT(g_heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291_str3, 0, "");
HEFF_LIT(g_heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291_str4, 0, "");
HEFF_LIT(g_heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291_str5, 0, "");
Clo g_heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291_entry, 2, 0};

V g_heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291(V v_x2_240, V v_acc_241) {
top: ;
  return (g_heff_2eelab_2eclauses_2epiIdents_24s20744116x2053008297_24cycle(NTAG(TAG_Enter_24heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291), ((V)&g_heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291_str0), ((V)&g_heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291_str1), ((V)&g_heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291_str2), ((V)&g_heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291_str3), ((V)&g_heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291_str4), ((V)&g_heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291_str5), v_x2_240, v_acc_241));
}
V g_heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2eidentsChkF_24s1606597861x261947291(a[0], a[1]);
}
HEFF_LIT(g_heff_2eelab_2eclauses_2efresh_str0, 1, "'");
Clo g_heff_2eelab_2eclauses_2efresh_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2efresh_entry, 2, 0};

V g_heff_2eelab_2eclauses_2efresh(V v_used_240, V v_x_241) {
top: ;
  V v_t_242 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(v_x_241)}));
  V v_t_243 = (g_list_2eany(v_t_242, v_used_240));
  if ((heff_dup(v_t_243) == NTAG(TAG_True))) {
    heff_drop(v_t_243);
    V t_0 = v_used_240;
    V t_1 = heff_strAppend(v_x_241, ((V)&g_heff_2eelab_2eclauses_2efresh_str0));
    v_used_240 = t_0;
    v_x_241 = t_1;
    goto top;
  } else {
    heff_drop(v_t_243);
    return v_x_241;
  }
}
V g_heff_2eelab_2eclauses_2efresh_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2eclauses_2efresh(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2eelab_2eclauses_2econcatMapC_24s497393573x331502823_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2econcatMapC_24s497393573x331502823_entry, 1, 0};

V g_heff_2eelab_2eclauses_2econcatMapC_24s497393573x331502823(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_245;
    switch (heff_tag_of(v_x_241)) {
    case TAG_MkFieldPat: {
      V v_a_244 = heff_field(v_x_241, 1);
      v_t_245 = (g_heff_2eelab_2eclauses_2epatBinds(heff_dup(v_a_244)));
      break;
    }
    default: heff_nomatch(v_x_241);
    }
    V v_t_246 = (g_heff_2eelab_2eclauses_2econcatMapC_24s497393573x331502823(v_xs_242));
    return (g_heff_2eelab_2eclauses_2eappendC(v_t_245, v_t_246));
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2eelab_2eclauses_2econcatMapC_24s497393573x331502823_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2eclauses_2econcatMapC_24s497393573x331502823(a0); heff_drop(a0); return r;
}
Clo g_heff_2eelab_2eclauses_2eanyC_24s1724875606x1273504888_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2eanyC_24s1724875606x1273504888_entry, 2, 0};

V g_heff_2eelab_2eclauses_2eanyC_24s1724875606x1273504888(V v_lit_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_t_2412;
    switch (heff_tag_of(v_x_242)) {
    case TAG_At: {
      V v_a_244 = heff_field(v_x_242, 0);
      switch (heff_tag_of(v_a_244)) {
      case TAG_ExplicitParam: {
        V v_a_246 = heff_field(v_a_244, 0);
        v_t_2412 = heff_strEq_lent(v_lit_240, v_a_246, 0);
        break;
      }
      case TAG_ImplicitParam: {
        V v_a_249 = heff_field(v_a_244, 0);
        v_t_2412 = heff_strEq_lent(v_lit_240, v_a_249, 0);
        break;
      }
      default: heff_nomatch(v_a_244);
      }
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    if ((heff_dup(v_t_2412) == NTAG(TAG_True))) {
      heff_drop(v_t_2412);
      return NTAG(TAG_True);
    } else {
      heff_drop(v_t_2412);
      V t_0 = v_lit_240;
      V t_1 = v_xs_243;
      v_lit_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eelab_2eclauses_2eanyC_24s1724875606x1273504888_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2eelab_2eclauses_2eanyC_24s1724875606x1273504888(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_heff_2eelab_2eclauses_2erenameSeq_24s1752939203x458176414_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2erenameSeq_24s1752939203x458176414_entry, 3, 0};

V g_heff_2eelab_2eclauses_2erenameSeq_24s1752939203x458176414(V v_lit_240, V v_lit_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_lit_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_m_243 = heff_field(v_x3_242, 0);
    V v_rest_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_t_245 = (g_heff_2eelab_2eclauses_2erenameDecl(heff_dup(v_lit_241), heff_dup(v_m_243)));
    V v_t_2433;
    switch (heff_tag_of(v_m_243)) {
    case TAG_At: {
      V v_a_246 = heff_field(v_m_243, 0);
      heff_take_n(v_m_243, 1ULL, 2);
      switch (heff_tag_of(v_a_246)) {
      case TAG_DeclEquations: {
        V v_a_248 = heff_field(v_a_246, 0);
        heff_take_n(v_a_246, 1ULL, 5);
        if (heff_strEq_c_lent(v_lit_240, v_a_248, 2)) {
          heff_drop(v_lit_241);
          v_t_2433 = v_rest_244;
        } else {
          v_t_2433 = (g_heff_2eelab_2eclauses_2erenameSeq_24s1752939203x458176414(v_lit_240, v_lit_241, v_rest_244));
        }
        break;
      }
      case TAG_DeclDefine: {
        V v_a_2414 = heff_field(v_a_246, 0);
        heff_take_n(v_a_246, 1ULL, 5);
        if (heff_strEq_c_lent(v_lit_240, v_a_2414, 2)) {
          heff_drop(v_lit_241);
          v_t_2433 = v_rest_244;
        } else {
          v_t_2433 = (g_heff_2eelab_2eclauses_2erenameSeq_24s1752939203x458176414(v_lit_240, v_lit_241, v_rest_244));
        }
        break;
      }
      case TAG_DeclTheory: {
        V v_a_2420 = heff_field(v_a_246, 0);
        heff_take_n(v_a_246, 1ULL, 4);
        if (heff_strEq_c_lent(v_lit_240, v_a_2420, 2)) {
          heff_drop(v_lit_241);
          v_t_2433 = v_rest_244;
        } else {
          v_t_2433 = (g_heff_2eelab_2eclauses_2erenameSeq_24s1752939203x458176414(v_lit_240, v_lit_241, v_rest_244));
        }
        break;
      }
      case TAG_DeclPrimitive: {
        V v_a_2425 = heff_field(v_a_246, 0);
        heff_take_n(v_a_246, 1ULL, 3);
        if (heff_strEq_c_lent(v_lit_240, v_a_2425, 2)) {
          heff_drop(v_lit_241);
          v_t_2433 = v_rest_244;
        } else {
          v_t_2433 = (g_heff_2eelab_2eclauses_2erenameSeq_24s1752939203x458176414(v_lit_240, v_lit_241, v_rest_244));
        }
        break;
      }
      case TAG_DeclTest: {
        V v_a_2429 = heff_field(v_a_246, 0);
        heff_take_n(v_a_246, 1ULL, 2);
        if (heff_strEq_c_lent(v_lit_240, v_a_2429, 2)) {
          heff_drop(v_lit_241);
          v_t_2433 = v_rest_244;
        } else {
          v_t_2433 = (g_heff_2eelab_2eclauses_2erenameSeq_24s1752939203x458176414(v_lit_240, v_lit_241, v_rest_244));
        }
        break;
      }
      case TAG_DeclWatch: {
        heff_take_n(v_a_246, 0ULL, 1);
        v_t_2433 = (g_heff_2eelab_2eclauses_2erenameSeq_24s1752939203x458176414(v_lit_240, v_lit_241, v_rest_244));
        break;
      }
      default: heff_nomatch(v_a_246);
      }
      break;
    }
    default: heff_nomatch(v_m_243);
    }
    return heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_t_245, v_t_2433});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2eelab_2eclauses_2erenameSeq_24s1752939203x458176414_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2eclauses_2erenameSeq_24s1752939203x458176414(a0, a[1], a[2]); heff_drop(a0); return r;
}
V g_heff_2eelab_2eclauses_2erenameChkF_lam0(V self, V *args);
Clo g_heff_2eelab_2eclauses_2erenameChkF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2erenameChkF_entry, 2, 0};

V g_heff_2eelab_2eclauses_2erenameChkF(V v_r_240, V v_n_241) {
top: ;
  switch (heff_tag_of(v_n_241)) {
  case TAG_At: {
    V v_n1_242 = heff_dup(heff_field(v_n_241, 0));
    V v_sp_243 = heff_dup(heff_field(v_n_241, 1));
    switch (heff_tag_of(v_n1_242)) {
    case TAG_CInf: {
      V v_i_244 = heff_field(v_n1_242, 0);
      V v_ru_24n1_242_24CInf = heff_take_reuse_n(v_n1_242, 1ULL, 1);
      heff_drop_tag(v_n_241, 2);
      V v_t_245 = heff_tr(heff_call(heff_get_n(v_r_240, 2, 5), 1, (V[]){v_i_244}));
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24n1_242_24CInf, TAG_CInf, 1, (V[]){v_t_245}), v_sp_243});
    }
    case TAG_CType: {
      V v_t_246 = heff_field(v_n1_242, 0);
      V v_ru_24n1_242_24CType = heff_take_reuse_n(v_n1_242, 1ULL, 1);
      heff_drop_tag(v_n_241, 2);
      V v_t_247 = heff_tr(heff_call(heff_get_n(v_r_240, 4, 5), 1, (V[]){v_t_246}));
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24n1_242_24CType, TAG_CType, 1, (V[]){v_t_247}), v_sp_243});
    }
    case TAG_CLam: {
      V v_y_248 = heff_field(v_n1_242, 0);
      V v_ysp_249 = heff_field(v_n1_242, 1);
      V v_b_2410 = heff_field(v_n1_242, 2);
      V v_ru_24n1_242_24CLam = heff_take_reuse_n(v_n1_242, 7ULL, 3);
      if (heff_strEq_c(heff_dup(v_y_248), heff_dup(heff_rfield(v_r_240, 0)))) {
        heff_drop_rec(v_r_240, 5);
        heff_drop(v_sp_243);
        heff_drop(v_y_248);
        heff_drop(v_ysp_249);
        heff_drop(v_b_2410);
        heff_drop_cell(v_ru_24n1_242_24CLam, 3);
        return v_n_241;
      } else {
        heff_drop_tag(v_n_241, 2);
        V v_t_2412 = heff_tr(heff_call(heff_get_n(v_r_240, 3, 5), 1, (V[]){v_b_2410}));
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24n1_242_24CLam, TAG_CLam, 3, (V[]){v_y_248, v_ysp_249, v_t_2412}), v_sp_243});
      }
    }
    case TAG_CImplicitLam: {
      V v_y_2413 = heff_field(v_n1_242, 0);
      V v_ysp_2414 = heff_field(v_n1_242, 1);
      V v_b_2415 = heff_field(v_n1_242, 2);
      V v_ru_24n1_242_24CImplicitLam = heff_take_reuse_n(v_n1_242, 7ULL, 3);
      if (heff_strEq_c(heff_dup(v_y_2413), heff_dup(heff_rfield(v_r_240, 0)))) {
        heff_drop_rec(v_r_240, 5);
        heff_drop(v_sp_243);
        heff_drop(v_y_2413);
        heff_drop(v_ysp_2414);
        heff_drop(v_b_2415);
        heff_drop_cell(v_ru_24n1_242_24CImplicitLam, 3);
        return v_n_241;
      } else {
        heff_drop_tag(v_n_241, 2);
        V v_t_2417 = heff_tr(heff_call(heff_get_n(v_r_240, 3, 5), 1, (V[]){v_b_2415}));
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24n1_242_24CImplicitLam, TAG_CImplicitLam, 3, (V[]){v_y_2413, v_ysp_2414, v_t_2417}), v_sp_243});
      }
    }
    case TAG_CAnnLam: {
      V v_y_2418 = heff_field(v_n1_242, 0);
      V v_ysp_2419 = heff_field(v_n1_242, 1);
      V v_t_2420 = heff_field(v_n1_242, 2);
      V v_b_2421 = heff_field(v_n1_242, 3);
      V v_ru_24n1_242_24CAnnLam = heff_take_reuse_n(v_n1_242, 15ULL, 4);
      heff_drop_tag(v_n_241, 2);
      V v_t_2422 = heff_tr(heff_call(heff_take_field(v_r_240, 4), 1, (V[]){v_t_2420}));
      V v_t_2424;
      if (heff_strEq_c(heff_dup(v_y_2418), heff_dup(heff_rfield(v_r_240, 0)))) {
        heff_drop_rec(v_r_240, 5);
        v_t_2424 = v_b_2421;
      } else {
        v_t_2424 = heff_tr(heff_call(heff_get_n(v_r_240, 3, 5), 1, (V[]){v_b_2421}));
      }
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24n1_242_24CAnnLam, TAG_CAnnLam, 4, (V[]){v_y_2418, v_ysp_2419, v_t_2422, v_t_2424}), v_sp_243});
    }
    case TAG_CTag: {
      V v_t_2425 = heff_field(v_n1_242, 0);
      V v_tsp_2426 = heff_field(v_n1_242, 1);
      V v_args_2427 = heff_field(v_n1_242, 2);
      V v_ru_24n1_242_24CTag = heff_take_reuse_n(v_n1_242, 7ULL, 3);
      heff_drop_tag(v_n_241, 2);
      V v_t_2428 = (g_list_2emap(heff_get_n(v_r_240, 3, 5), v_args_2427));
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24n1_242_24CTag, TAG_CTag, 3, (V[]){v_t_2425, v_tsp_2426, v_t_2428}), v_sp_243});
    }
    case TAG_CStruct: {
      V v_fs_2429 = heff_field(v_n1_242, 0);
      V v_ru_24n1_242_24CStruct = heff_take_reuse_n(v_n1_242, 1ULL, 1);
      heff_drop_tag(v_n_241, 2);
      V v_t_2439 = (g_list_2emap(heff_clo_n(g_heff_2eelab_2eclauses_2erenameChkF_lam0, 1, 1, (V[]){v_r_240}), v_fs_2429));
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24n1_242_24CStruct, TAG_CStruct, 1, (V[]){v_t_2439}), v_sp_243});
    }
    case TAG_CMatch: {
      V v_s_2440 = heff_field(v_n1_242, 0);
      V v_alts_2441 = heff_field(v_n1_242, 1);
      V v_ru_24n1_242_24CMatch = heff_take_reuse_n(v_n1_242, 3ULL, 2);
      heff_drop_tag(v_n_241, 2);
      V v_t_2442 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 2)), 1, (V[]){v_s_2440}));
      V v_t_2443 = (g_list_2emap_24s1386495485x1391533176(v_r_240, v_alts_2441));
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24n1_242_24CMatch, TAG_CMatch, 2, (V[]){v_t_2442, v_t_2443}), v_sp_243});
    }
    case TAG_CLetIn: {
      V v_rhs_2444 = heff_field(v_n1_242, 0);
      V v_a_2445 = heff_field(v_n1_242, 1);
      V v_ru_24n1_242_24CLetIn = heff_take_reuse_n(v_n1_242, 3ULL, 2);
      heff_drop_tag(v_n_241, 2);
      V v_t_2446 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 2)), 1, (V[]){v_rhs_2444}));
      V v_t_2447 = (g_heff_2eelab_2eclauses_2erenameAlt(v_r_240, v_a_2445));
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24n1_242_24CLetIn, TAG_CLetIn, 2, (V[]){v_t_2446, v_t_2447}), v_sp_243});
    }
    case TAG_CLocal: {
      V v_body_2448 = heff_field(v_n1_242, 0);
      V v_ds_2449 = heff_field(v_n1_242, 1);
      V v_ru_24n1_242_24CLocal = heff_take_reuse_n(v_n1_242, 3ULL, 2);
      heff_drop_tag(v_n_241, 2);
      V v_t_2450 = (g_heff_2eelab_2eclauses_2eanyC_24s44140518x185484176(heff_rfield(v_r_240, 0), v_ds_2449));
      V v_t_2451;
      if ((heff_dup(v_t_2450) == NTAG(TAG_True))) {
        heff_drop(v_t_2450);
        v_t_2451 = v_body_2448;
      } else {
        heff_drop(v_t_2450);
        v_t_2451 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 3)), 1, (V[]){v_body_2448}));
      }
      V v_t_2452 = ({ V b_0 = heff_dup(heff_rfield(v_r_240, 0)); V a_1 = v_r_240; V a_2 = v_ds_2449; V r_ = (g_heff_2eelab_2eclauses_2erenameSeq_24s1752939203x458176414(b_0, a_1, a_2)); heff_drop(b_0); r_; });
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24n1_242_24CLocal, TAG_CLocal, 2, (V[]){v_t_2451, v_t_2452}), v_sp_243});
    }
    case TAG_CAbandon: {
      heff_drop_rec(v_r_240, 5);
      heff_drop(v_sp_243);
      return v_n_241;
    }
    case TAG_CNominal: {
      V v_c_2453 = heff_field(v_n1_242, 0);
      V v_ru_24n1_242_24CNominal = heff_take_reuse_n(v_n1_242, 1ULL, 1);
      heff_drop_tag(v_n_241, 2);
      V v_t_2454 = heff_tr(heff_call(heff_get_n(v_r_240, 3, 5), 1, (V[]){v_c_2453}));
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24n1_242_24CNominal, TAG_CNominal, 1, (V[]){v_t_2454}), v_sp_243});
    }
    default: return heff_nomatch(v_n1_242);
    }
  }
  default: return heff_nomatch(v_n_241);
  }
}
V g_heff_2eelab_2eclauses_2erenameChkF_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2erenameChkF(a[0], a[1]);
}
V g_heff_2eelab_2eclauses_2erenameChkF_lam0(V self, V *args) {
  V v_x2_2430 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x2_2430)) {
  case TAG_At: {
    V v_x21_2431 = heff_field(v_x2_2430, 0);
    V v_sp_2432 = heff_field(v_x2_2430, 1);
    V v_ru_24x2_2430_24At = heff_take_reuse_n(v_x2_2430, 3ULL, 2);
    switch (heff_tag_of(v_x21_2431)) {
    case TAG_SetField: {
      V v_y_2433 = heff_field(v_x21_2431, 0);
      V v_ysp_2434 = heff_field(v_x21_2431, 1);
      V v_e_2435 = heff_field(v_x21_2431, 2);
      heff_take_n(v_x21_2431, 7ULL, 3);
      V v_t_2436 = heff_tr(heff_call(heff_get_n(v_r_240, 3, 5), 1, (V[]){v_e_2435}));
      return heff_tag_at_n(v_ru_24x2_2430_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_SetField, 3, (V[]){v_y_2433, v_ysp_2434, v_t_2436}), v_sp_2432});
    }
    case TAG_BadFieldSet: {
      V v_e_2437 = heff_field(v_x21_2431, 0);
      heff_take_n(v_x21_2431, 1ULL, 1);
      V v_t_2438 = heff_tr(heff_call(heff_get_n(v_r_240, 3, 5), 1, (V[]){v_e_2437}));
      return heff_tag_at_n(v_ru_24x2_2430_24At, TAG_At, 2, (V[]){heff_tag_n(TAG_BadFieldSet, 1, (V[]){v_t_2438}), v_sp_2432});
    }
    default: return heff_nomatch(v_x21_2431);
    }
  }
  default: return heff_nomatch(v_x2_2430);
  }
}
V g_heff_2eelab_2eclauses_2erenamer_lam0(V self, V *args);
V g_heff_2eelab_2eclauses_2erenamer_lam1(V self, V *args);
V g_heff_2eelab_2eclauses_2erenamer_lam2(V self, V *args);
Clo g_heff_2eelab_2eclauses_2erenamer_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2erenamer_entry, 2, 0};

V g_heff_2eelab_2eclauses_2erenamer(V v_x_240, V v_v_241) {
top: ;
  return heff_rec_n(5, shape_x__v__inf__chk__typ, (V[]){heff_dup(v_x_240), heff_dup(v_v_241), heff_clo_n(g_heff_2eelab_2eclauses_2erenamer_lam0, 1, 2, (V[]){heff_dup(v_x_240), heff_dup(v_v_241)}), heff_clo_n(g_heff_2eelab_2eclauses_2erenamer_lam1, 1, 2, (V[]){heff_dup(v_x_240), heff_dup(v_v_241)}), heff_clo_n(g_heff_2eelab_2eclauses_2erenamer_lam2, 1, 2, (V[]){v_x_240, v_v_241})});
}
V g_heff_2eelab_2eclauses_2erenamer_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2erenamer(a[0], a[1]);
}
V g_heff_2eelab_2eclauses_2erenamer_lam0(V self, V *args) {
  V v_n_242 = args[0];
  V v_x_240 = heff_env(self)[0];
  V v_v_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_243 = (g_heff_2eelab_2eclauses_2erenamer(v_x_240, v_v_241));
  return (g_heff_2eelab_2eclauses_2erenameInfF(v_t_243, v_n_242));
}
V g_heff_2eelab_2eclauses_2erenamer_lam1(V self, V *args) {
  V v_n_244 = args[0];
  V v_x_240 = heff_env(self)[0];
  V v_v_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_245 = (g_heff_2eelab_2eclauses_2erenamer(v_x_240, v_v_241));
  return (g_heff_2eelab_2eclauses_2erenameChkF(v_t_245, v_n_244));
}
V g_heff_2eelab_2eclauses_2erenamer_lam2(V self, V *args) {
  V v_n_246 = args[0];
  V v_x_240 = heff_env(self)[0];
  V v_v_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_247 = (g_heff_2eelab_2eclauses_2erenamer(v_x_240, v_v_241));
  return (g_heff_2eelab_2eclauses_2erenameTypF(v_t_247, v_n_246));
}
HEFF_LIT(g_heff_2eelab_2eclauses_2earmSubName_str0, 1, "_");
Clo g_heff_2eelab_2eclauses_2earmSubName_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2earmSubName_entry, 7, 0};

V g_heff_2eelab_2eclauses_2earmSubName(V v_used_240, V v_bound_241, V v_rows_242, V v_c_243, V v_v_244, V v_i_245, V v_x7_246) {
top: ;
  switch (heff_tag_of(v_x7_246)) {
  case TAG_Nothing: {
    heff_drop(v_c_243);
    V v_t_247 = heff_intShow(heff_intAdd(v_i_245, MK_INT(1LL)));
    return (g_heff_2eelab_2eclauses_2efreshIn(v_used_240, v_bound_241, heff_strAppend(v_v_244, v_t_247)));
  }
  case TAG_Just: {
    V v_x_248 = heff_field(v_x7_246, 0);
    if (heff_strEq_c_lent(v_x_248, ((V)&g_heff_2eelab_2eclauses_2earmSubName_str0), 2)) {
      heff_drop(v_c_243);
      V v_t_2410 = heff_intShow(heff_intAdd(v_i_245, MK_INT(1LL)));
      return (g_heff_2eelab_2eclauses_2efreshIn(v_used_240, v_bound_241, heff_strAppend(v_v_244, v_t_2410)));
    } else {
      V v_t_2411 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(v_x_248)}));
      V v_x1_2412 = (g_list_2eany(v_t_2411, v_bound_241));
      if ((heff_dup(v_x1_2412) == NTAG(TAG_True))) {
        heff_drop(v_c_243);
        heff_drop(v_x1_2412);
        V v_t_2413 = heff_intShow(heff_intAdd(v_i_245, MK_INT(1LL)));
        return (g_heff_2eelab_2eclauses_2efreshIn(v_used_240, v_bound_241, heff_strAppend(v_v_244, v_t_2413)));
      } else {
        heff_drop(v_x1_2412);
        V v_t_2414 = (g_heff_2eelab_2eclauses_2enameFits(heff_dup(v_x_248), heff_intAdd(v_c_243, heff_dup(v_i_245)), v_rows_242));
        if ((heff_dup(v_t_2414) == NTAG(TAG_True))) {
          heff_drop(v_v_244);
          heff_drop(v_i_245);
          heff_drop(v_t_2414);
          return heff_dup(v_x_248);
        } else {
          heff_drop(v_t_2414);
          V v_t_2415 = heff_intShow(heff_intAdd(v_i_245, MK_INT(1LL)));
          return (g_heff_2eelab_2eclauses_2efreshIn(v_used_240, v_bound_241, heff_strAppend(v_v_244, v_t_2415)));
        }
      }
    }
  }
  default: return heff_nomatch(v_x7_246);
  }
}
V g_heff_2eelab_2eclauses_2earmSubName_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V a6 = a[6]; V r = g_heff_2eelab_2eclauses_2earmSubName(a0, a1, a2, a[3], a[4], a[5], a6); heff_drop(a0); heff_drop(a1); heff_drop(a2); heff_drop(a6); return r;
}
HEFF_LIT(g_heff_2eelab_2eclauses_2elitYesOne_str0, 1, "_");
Clo g_heff_2eelab_2eclauses_2elitYesOne_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2elitYesOne_entry, 5, 0};

V g_heff_2eelab_2eclauses_2elitYesOne(V v_c_240, V v_l_241, V v_v_242, V v_r_243, V v_acc_244) {
top: ;
  HeffT2 v_t_245 = (g_heff_2eelab_2eclauses_2enthC_24cpr(heff_dup(heff_rfield(v_r_243, 0)), heff_dup(v_c_240)));
  {
    V v_field_247 = v_t_245.f[1];
    int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
    if ((v_tag_246 == ((int64_t)0ULL))) {
      V v_p_249 = v_field_247;
      switch (heff_tag_of(v_p_249)) {
      case TAG_PVar: {
        V v_x_2410 = heff_field(v_p_249, 0);
        heff_take_n(v_p_249, 1ULL, 1);
        V v_pats_2411 = (g_heff_2eelab_2eclauses_2edropAt(v_c_240, heff_take_field(v_r_243, 0)));
        V v_e_2412 = heff_get_n(v_r_243, 1, 2);
        V v_rhs_2416;
        if (heff_strEq_c_lent(v_x_2410, ((V)&g_heff_2eelab_2eclauses_2elitYesOne_str0), 2)) {
          heff_drop(v_v_242);
          heff_drop(v_x_2410);
          v_rhs_2416 = v_e_2412;
        } else {
          if (heff_strEq_c_lent(v_x_2410, v_v_242, 0)) {
            heff_drop(v_v_242);
            heff_drop(v_x_2410);
            v_rhs_2416 = v_e_2412;
          } else {
            V v_t_2415 = (g_heff_2eelab_2eclauses_2erenamer(v_x_2410, v_v_242));
            v_rhs_2416 = heff_tr(heff_call(heff_get_n(v_t_2415, 3, 5), 1, (V[]){v_e_2412}));
          }
        }
        return heff_tag_n(TAG_Cons, 2, (V[]){heff_rec_n(2, shape_pats__rhs, (V[]){v_pats_2411, v_rhs_2416}), v_acc_244});
      }
      case TAG_PTag: {
        heff_take_n(v_p_249, 0ULL, 3);
        heff_drop(v_c_240);
        heff_drop(v_v_242);
        heff_drop_rec(v_r_243, 2);
        return v_acc_244;
      }
      case TAG_PLit: {
        V v_l_27_2420 = heff_field(v_p_249, 0);
        heff_take_n(v_p_249, 1ULL, 1);
        heff_drop(v_v_242);
        V v_t_2421 = ({ V a_0 = v_l_241; V a_1 = v_l_27_2420; V r_ = (g_heff_2eelab_2eclauses_2esameLit(a_0, a_1)); heff_drop(v_l_27_2420); r_; });
        if ((heff_dup(v_t_2421) == NTAG(TAG_True))) {
          heff_drop(v_t_2421);
          V v_pats_2422 = (g_heff_2eelab_2eclauses_2edropAt(v_c_240, heff_take_field(v_r_243, 0)));
          V v_t_2423 = ({ V rv_0 = v_pats_2422; V rr_ = heff_rec_reuse_nf(v_r_243, 2ULL, 2, shape_pats__rhs, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
          return heff_tag_n(TAG_Cons, 2, (V[]){v_t_2423, v_acc_244});
        } else {
          heff_drop(v_c_240);
          heff_drop_rec(v_r_243, 2);
          heff_drop(v_t_2421);
          return v_acc_244;
        }
      }
      case TAG_PRec: {
        heff_take_n(v_p_249, 0ULL, 2);
        heff_drop(v_c_240);
        heff_drop(v_v_242);
        heff_drop_rec(v_r_243, 2);
        return v_acc_244;
      }
      case TAG_PAs: {
        heff_take_n(v_p_249, 0ULL, 2);
        heff_drop(v_c_240);
        heff_drop(v_v_242);
        heff_drop_rec(v_r_243, 2);
        return v_acc_244;
      }
      case TAG_PBin: {
        heff_take_n(v_p_249, 0ULL, 2);
        heff_drop(v_c_240);
        heff_drop(v_v_242);
        heff_drop_rec(v_r_243, 2);
        return v_acc_244;
      }
      default: return heff_nomatch(v_p_249);
      }
    } else {
      heff_drop(v_v_242);
      heff_drop(v_field_247);
      V v_pats_2430 = (g_heff_2eelab_2eclauses_2edropAt(v_c_240, heff_take_field(v_r_243, 0)));
      V v_t_2431 = ({ V rv_0 = v_pats_2430; V rr_ = heff_rec_reuse_nf(v_r_243, 2ULL, 2, shape_pats__rhs, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
      return heff_tag_n(TAG_Cons, 2, (V[]){v_t_2431, v_acc_244});
    }
  }
}
V g_heff_2eelab_2eclauses_2elitYesOne_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2eclauses_2elitYesOne(a[0], a1, a[2], a[3], a[4]); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2eelab_2eclauses_2enoLitHere_24cpr_str0, 43, "a literal and a tag match the same argument");
HEFF_LIT(g_heff_2eelab_2eclauses_2enoLitHere_24cpr_str1, 42, "a binary and a tag match the same argument");
V g_heff_2eelab_2eclauses_2enoLitHere_24cpr_lam0(V self, V *args);

HeffT2 g_heff_2eelab_2eclauses_2enoLitHere_24cpr(V v_sp_240, V v_c_241, V v_rows_242) {
top: ;
  return (g_heff_2eelab_2eclauses_2eforC_24cpr(v_rows_242, heff_clo_n(g_heff_2eelab_2eclauses_2enoLitHere_24cpr_lam0, 1, 1, (V[]){v_c_241})));
}
V g_heff_2eelab_2eclauses_2enoLitHere_24cpr_lam0(V self, V *args) {
  V v_row_243 = args[0];
  V v_c_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_244 = (g_heff_2eelab_2eclauses_2enthC_24cpr(heff_get_n(v_row_243, 0, 2), v_c_241));
  {
    V v_field_246 = v_t_244.f[1];
    int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
    if ((v_tag_245 == ((int64_t)0ULL))) {
      V v_p_248 = v_field_246;
      switch (heff_tag_of(v_p_248)) {
      case TAG_PVar: {
        V v_ru_24p_248_24PVar = heff_take_reuse_n(v_p_248, 0ULL, 1);
        return heff_tag_at_n(v_ru_24p_248_24PVar, TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
      }
      case TAG_PTag: {
        heff_take_n(v_p_248, 0ULL, 3);
        return heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
      }
      case TAG_PLit: {
        V v_l_2413 = heff_field(v_p_248, 0);
        V v_ru_24p_248_24PLit = heff_take_reuse_n(v_p_248, 1ULL, 1);
        V v_t_2416;
        switch (heff_tag_of(v_l_2413)) {
        case TAG_At: {
          V v_s_2415 = heff_field(v_l_2413, 1);
          heff_take_n(v_l_2413, 2ULL, 2);
          v_t_2416 = v_s_2415;
          break;
        }
        default: heff_nomatch(v_l_2413);
        }
        return heff_tag_at_n(v_ru_24p_248_24PLit, TAG_Left, 1, (V[]){heff_rec_n(2, shape_span__msg, (V[]){v_t_2416, ((V)&g_heff_2eelab_2eclauses_2enoLitHere_24cpr_str0)})});
      }
      case TAG_PRec: {
        heff_take_n(v_p_248, 0ULL, 2);
        return heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
      }
      case TAG_PAs: {
        heff_take_n(v_p_248, 0ULL, 2);
        return heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
      }
      case TAG_PBin: {
        V v_bsp_2422 = heff_field(v_p_248, 1);
        heff_take_n(v_p_248, 2ULL, 2);
        return heff_tag_n(TAG_Left, 1, (V[]){heff_rec_n(2, shape_span__msg, (V[]){v_bsp_2422, ((V)&g_heff_2eelab_2eclauses_2enoLitHere_24cpr_str1)})});
      }
      default: return heff_nomatch(v_p_248);
      }
    } else {
      heff_drop(v_field_246);
      return heff_tag_n(TAG_Right, 1, (V[]){NTAG(TAG_MkUnit)});
    }
  }
}
V g_heff_2eelab_2eclauses_2erecFieldVar_lam0(V self, V *args);
Clo g_heff_2eelab_2eclauses_2erecFieldVar_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2erecFieldVar_entry, 3, 0};

V g_heff_2eelab_2eclauses_2erecFieldVar(V v_c_240, V v_rows_241, V v_f_242) {
top: ;
  V v_t_2421 = (g_list_2emap(heff_clo_n(g_heff_2eelab_2eclauses_2erecFieldVar_lam0, 1, 2, (V[]){v_c_240, heff_dup(v_f_242)}), v_rows_241));
  V v_t_2422 = (g_heff_2eelab_2eclauses_2ecatMaybesC(v_t_2421));
  switch (heff_tag_of(v_t_2422)) {
  case TAG_Nil: {
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_p_2423 = heff_field(v_t_2422, 0);
    heff_take_n(v_t_2422, 1ULL, 2);
    switch (heff_tag_of(v_p_2423)) {
    case TAG_PVar: {
      V v_x_2425 = heff_field(v_p_2423, 0);
      V v_ru_24p_2423_24PVar = heff_take_reuse_n(v_p_2423, 1ULL, 1);
      return heff_tag_at_n(v_ru_24p_2423_24PVar, TAG_Just, 1, (V[]){v_x_2425});
    }
    case TAG_PTag: {
      heff_take_n(v_p_2423, 0ULL, 3);
      return NTAG(TAG_Nothing);
    }
    case TAG_PLit: {
      heff_take_n(v_p_2423, 0ULL, 1);
      return NTAG(TAG_Nothing);
    }
    case TAG_PRec: {
      heff_take_n(v_p_2423, 0ULL, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_PAs: {
      V v_x_2432 = heff_field(v_p_2423, 0);
      heff_take_n(v_p_2423, 1ULL, 2);
      return heff_tag_n(TAG_Just, 1, (V[]){v_x_2432});
    }
    case TAG_PBin: {
      heff_take_n(v_p_2423, 0ULL, 2);
      return NTAG(TAG_Nothing);
    }
    default: return heff_nomatch(v_p_2423);
    }
  }
  default: return heff_nomatch(v_t_2422);
  }
}
V g_heff_2eelab_2eclauses_2erecFieldVar_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2eelab_2eclauses_2erecFieldVar(a[0], a[1], a2); heff_drop(a2); return r;
}
V g_heff_2eelab_2eclauses_2erecFieldVar_lam0(V self, V *args) {
  V v_row_243 = args[0];
  V v_c_240 = heff_env(self)[0];
  V v_f_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  HeffT2 v_t_244 = (g_heff_2eelab_2eclauses_2enthC_24cpr(heff_get_n(v_row_243, 0, 2), v_c_240));
  V v_t_2420;
  {
    V v_field_246 = v_t_244.f[1];
    int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
    if ((v_tag_245 == ((int64_t)0ULL))) {
      V v_p_248 = v_field_246;
      switch (heff_tag_of(v_p_248)) {
      case TAG_PVar: {
        heff_take_n(v_p_248, 0ULL, 1);
        v_t_2420 = NTAG(TAG_Nil);
        break;
      }
      case TAG_PTag: {
        heff_take_n(v_p_248, 0ULL, 3);
        v_t_2420 = NTAG(TAG_Nil);
        break;
      }
      case TAG_PLit: {
        heff_take_n(v_p_248, 0ULL, 1);
        v_t_2420 = NTAG(TAG_Nil);
        break;
      }
      case TAG_PRec: {
        V v_fps_2414 = heff_field(v_p_248, 0);
        heff_take_n(v_p_248, 1ULL, 2);
        v_t_2420 = v_fps_2414;
        break;
      }
      case TAG_PAs: {
        heff_take_n(v_p_248, 0ULL, 2);
        v_t_2420 = NTAG(TAG_Nil);
        break;
      }
      case TAG_PBin: {
        heff_take_n(v_p_248, 0ULL, 2);
        v_t_2420 = NTAG(TAG_Nil);
        break;
      }
      default: heff_nomatch(v_p_248);
      }
    } else {
      heff_drop(v_field_246);
      v_t_2420 = NTAG(TAG_Nil);
    }
  }
  return ({ V a_0 = v_f_242; V a_1 = v_t_2420; V r_ = (g_heff_2eelab_2eclauses_2elookupField(a_0, a_1)); heff_drop(v_f_242); r_; });
}
HEFF_LIT(g_heff_2eelab_2eclauses_2eletFields_str0, 0, "");
Clo g_heff_2eelab_2eclauses_2eletFields_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2eletFields_entry, 4, 0};

V g_heff_2eelab_2eclauses_2eletFields(V v_sp_240, V v_v_241, V v_x3_242, V v_body_243) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop_rec(v_sp_240, 2);
    heff_drop(v_v_241);
    return v_body_243;
  }
  case TAG_Cons: {
    V v_x31_244 = heff_field(v_x3_242, 0);
    V v_rest_245 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    switch (heff_tag_of(v_x31_244)) {
    case TAG_MkPair: {
      V v_f_246 = heff_field(v_x31_244, 0);
      V v_y_247 = heff_field(v_x31_244, 1);
      V v_ru_24x31_244_24MkPair = heff_take_reuse_n(v_x31_244, 3ULL, 2);
      V v_t_248 = heff_tag_at_n(v_ru_24x31_244_24MkPair, TAG_At, 2, (V[]){heff_tag_n(TAG_IVar, 1, (V[]){heff_dup(v_v_241)}), heff_dup(v_sp_240)});
      V v_t_249 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgProject, 1, (V[]){heff_dup(v_f_246)}), heff_dup(v_sp_240)});
      V v_t_2410 = heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_Cons, 2, (V[]){v_t_249, NTAG(TAG_Nil)});
      V v_t_2411 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgProject, 1, (V[]){((V)&g_heff_2eelab_2eclauses_2eletFields_str0)}), heff_dup(v_sp_240)});
      V v_t_2412 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_ArgProject, 1, (V[]){v_f_246}), heff_dup(v_sp_240)});
      V v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2412, NTAG(TAG_Nil)});
      V v_x1_2414 = ({ V a_0 = v_t_2411; V a_1 = v_t_2413; V r_ = (g_heff_2esyntax_2epresyntax_2elastOr(a_0, a_1)); heff_drop_tag(v_t_2413, 2); r_; });
      V v_t_2417;
      switch (heff_tag_of(v_x1_2414)) {
      case TAG_At: {
        V v_s_2416 = heff_field(v_x1_2414, 1);
        heff_take_n(v_x1_2414, 2ULL, 2);
        v_t_2417 = v_s_2416;
        break;
      }
      default: heff_nomatch(v_x1_2414);
      }
      V v_t_2418 = ({ V rv_0 = heff_dup(heff_rfield(v_sp_240, 0)); V rr_ = heff_rec_reuse_nf(v_t_2417, 2ULL, 2, shape_start__end, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
      V v_t_2419 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_248, v_t_2410}), v_t_2418});
      V v_e_2420 = (g_heff_2eelab_2eclauses_2eletFields(heff_dup(v_sp_240), v_v_241, v_rest_245, v_body_243));
      V v_t_2421 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_PatVar, 1, (V[]){v_y_247}), heff_dup(v_sp_240)});
      V v_t_2424;
      switch (heff_tag_of(v_e_2420)) {
      case TAG_At: {
        V v_s_2423 = heff_dup(heff_field(v_e_2420, 1));
        v_t_2424 = v_s_2423;
        break;
      }
      default: heff_nomatch(v_e_2420);
      }
      V v_t_2425 = ({ V rv_0 = heff_dup(heff_rfield(v_sp_240, 0)); V rr_ = heff_rec_reuse_nf(v_t_2424, 2ULL, 2, shape_start__end, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
      V v_t_2426 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_t_2421, v_e_2420}), v_t_2425});
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CLetIn, 2, (V[]){v_t_2419, v_t_2426}), v_sp_240});
    }
    default: return heff_nomatch(v_x31_244);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2eelab_2eclauses_2eletFields_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2eletFields(a[0], a[1], a[2], a[3]);
}
HEFF_LIT(g_heff_2eelab_2eclauses_2eoffBytesC_str0, 6, "intDiv");
Clo g_heff_2eelab_2eclauses_2eoffBytesC_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2eoffBytesC_entry, 2, 0};

V g_heff_2eelab_2eclauses_2eoffBytesC(V v_o_240, V v_sp_241) {
top: ;
  V v_t_242 = heff_dup(heff_rfield(v_o_240, 1));
  switch (heff_tag_of(v_t_242)) {
  case TAG_Nil: {
    V v_t_243 = heff_intDiv(heff_get_n(v_o_240, 0, 2), MK_INT(8LL));
    V v_t_244 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IInt, 1, (V[]){v_t_243}), heff_dup(v_sp_241)});
    return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_244}), v_sp_241});
  }
  case TAG_Cons: {
    V v_ru_24t_242_24Cons = heff_take_reuse_n(v_t_242, 0ULL, 2);
    V v_t_247 = (g_heff_2eelab_2eclauses_2eoffC(v_o_240, heff_dup(v_sp_241)));
    V v_t_248 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IInt, 1, (V[]){MK_INT(8LL)}), heff_dup(v_sp_241)});
    V v_t_249 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_248}), heff_dup(v_sp_241)});
    V v_t_2410 = heff_tag_at_n(v_ru_24t_242_24Cons, TAG_Cons, 2, (V[]){v_t_249, NTAG(TAG_Nil)});
    V v_args_2411 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_247, v_t_2410});
    V v_t_2412 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_241), v_args_2411));
    V v_t_2413 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2eelab_2eclauses_2eoffBytesC_str0)}), heff_dup(v_sp_241)});
    V v_t_2414 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2413, v_t_2412}), heff_dup(v_sp_241)});
    return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2414}), v_sp_241});
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2eelab_2eclauses_2eoffBytesC_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2eoffBytesC(a[0], a[1]);
}
Clo g_heff_2eelab_2eclauses_2eresolve_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2eresolve_entry, 2, 0};

V g_heff_2eelab_2eclauses_2eresolve(V v_x1_240, V v_x_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return v_x_241;
  }
  case TAG_Cons: {
    V v_x11_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_MkPair: {
      V v_y_244 = heff_field(v_x11_242, 0);
      V v_t_245 = heff_field(v_x11_242, 1);
      if (heff_strEq_c_lent(v_x_241, v_y_244, 0)) {
        heff_drop(v_x_241);
        return heff_dup(v_t_245);
      } else {
        V t_0 = v_rest_243;
        V t_1 = v_x_241;
        v_x1_240 = t_0;
        v_x_241 = t_1;
        goto top;
      }
    }
    default: return heff_nomatch(v_x11_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2eclauses_2eresolve_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2eclauses_2eresolve(a0, a[1]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2eelab_2eclauses_2eutfWidth_str0, 22, "prelude.bitsUtf16Width");
HEFF_LIT(g_heff_2eelab_2eclauses_2eutfWidth_str1, 23, "prelude.bytesUtf16Width");
HEFF_LIT(g_heff_2eelab_2eclauses_2eutfWidth_str2, 22, "prelude.bitsUtf16Width");
HEFF_LIT(g_heff_2eelab_2eclauses_2eutfWidth_str3, 23, "prelude.bytesUtf16Width");
HEFF_LIT(g_heff_2eelab_2eclauses_2eutfWidth_str4, 22, "prelude.bitsUtf16Width");
HEFF_LIT(g_heff_2eelab_2eclauses_2eutfWidth_str5, 23, "prelude.bytesUtf16Width");
HEFF_LIT(g_heff_2eelab_2eclauses_2eutfWidth_str6, 22, "prelude.bitsUtf16Width");
HEFF_LIT(g_heff_2eelab_2eclauses_2eutfWidth_str7, 23, "prelude.bytesUtf16Width");
HEFF_LIT(g_heff_2eelab_2eclauses_2eutfWidth_str8, 21, "prelude.bitsUtf8Width");
HEFF_LIT(g_heff_2eelab_2eclauses_2eutfWidth_str9, 22, "prelude.bytesUtf8Width");
HEFF_LIT(g_heff_2eelab_2eclauses_2eutfWidth_str10, 22, "prelude.bitsUtf16Width");
HEFF_LIT(g_heff_2eelab_2eclauses_2eutfWidth_str11, 23, "prelude.bytesUtf16Width");
Clo g_heff_2eelab_2eclauses_2eutfWidth_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2eutfWidth_entry, 4, 0};

V g_heff_2eelab_2eclauses_2eutfWidth(V v_k_240, V v_off_241, V v_s_242, V v_ty_243) {
top: ;
  switch (heff_tag_of(v_ty_243)) {
  case TAG_SegmentInteger: {
    V v_sp_244 = heff_dup(heff_rfield(v_k_240, 6));
    V v_t_245 = heff_tag_n(TAG_IVar, 1, (V[]){heff_take_field(v_k_240, 0)});
    V v_t_246 = heff_tag_n(TAG_CInf, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_245, heff_dup(v_sp_244)})});
    V v_t_247 = (g_heff_2eelab_2eclauses_2eoffC(v_off_241, heff_dup(heff_rfield(v_k_240, 6))));
    V v_sp_248 = heff_dup(heff_rfield(v_k_240, 6));
    V v_t_249 = heff_tag_n(TAG_IInt, 1, (V[]){heff_get_n(v_s_242, 3, 5)});
    V v_t_2410 = heff_tag_n(TAG_CInf, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_249, heff_dup(v_sp_248)})});
    V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2410, v_sp_248}), NTAG(TAG_Nil)});
    V v_args_2412 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_246, v_sp_244}), heff_tag_n(TAG_Cons, 2, (V[]){v_t_247, v_t_2411})});
    V v_sp_2413 = heff_take_field(v_k_240, 6);
    V v_t_2414 = heff_get_n(v_k_240, 1, 7);
    V v_t_2415;
    if ((heff_dup(v_t_2414) == NTAG(TAG_True))) {
      heff_drop(v_t_2414);
      v_t_2415 = ((V)&g_heff_2eelab_2eclauses_2eutfWidth_str0);
    } else {
      heff_drop(v_t_2414);
      v_t_2415 = ((V)&g_heff_2eelab_2eclauses_2eutfWidth_str1);
    }
    V v_t_2416 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){v_t_2415}), heff_dup(v_sp_2413)});
    V v_t_2417 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_2413), v_args_2412));
    return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2416, v_t_2417}), v_sp_2413});
  }
  case TAG_SegmentBinary: {
    V v_sp_2418 = heff_dup(heff_rfield(v_k_240, 6));
    V v_t_2419 = heff_tag_n(TAG_IVar, 1, (V[]){heff_take_field(v_k_240, 0)});
    V v_t_2420 = heff_tag_n(TAG_CInf, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2419, heff_dup(v_sp_2418)})});
    V v_t_2421 = (g_heff_2eelab_2eclauses_2eoffC(v_off_241, heff_dup(heff_rfield(v_k_240, 6))));
    V v_sp_2422 = heff_dup(heff_rfield(v_k_240, 6));
    V v_t_2423 = heff_tag_n(TAG_IInt, 1, (V[]){heff_get_n(v_s_242, 3, 5)});
    V v_t_2424 = heff_tag_n(TAG_CInf, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2423, heff_dup(v_sp_2422)})});
    V v_t_2425 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2424, v_sp_2422}), NTAG(TAG_Nil)});
    V v_args_2426 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2420, v_sp_2418}), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2421, v_t_2425})});
    V v_sp_2427 = heff_take_field(v_k_240, 6);
    V v_t_2428 = heff_get_n(v_k_240, 1, 7);
    V v_t_2429;
    if ((heff_dup(v_t_2428) == NTAG(TAG_True))) {
      heff_drop(v_t_2428);
      v_t_2429 = ((V)&g_heff_2eelab_2eclauses_2eutfWidth_str2);
    } else {
      heff_drop(v_t_2428);
      v_t_2429 = ((V)&g_heff_2eelab_2eclauses_2eutfWidth_str3);
    }
    V v_t_2430 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){v_t_2429}), heff_dup(v_sp_2427)});
    V v_t_2431 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_2427), v_args_2426));
    return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2430, v_t_2431}), v_sp_2427});
  }
  case TAG_SegmentBits: {
    V v_sp_2432 = heff_dup(heff_rfield(v_k_240, 6));
    V v_t_2433 = heff_tag_n(TAG_IVar, 1, (V[]){heff_take_field(v_k_240, 0)});
    V v_t_2434 = heff_tag_n(TAG_CInf, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2433, heff_dup(v_sp_2432)})});
    V v_t_2435 = (g_heff_2eelab_2eclauses_2eoffC(v_off_241, heff_dup(heff_rfield(v_k_240, 6))));
    V v_sp_2436 = heff_dup(heff_rfield(v_k_240, 6));
    V v_t_2437 = heff_tag_n(TAG_IInt, 1, (V[]){heff_get_n(v_s_242, 3, 5)});
    V v_t_2438 = heff_tag_n(TAG_CInf, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2437, heff_dup(v_sp_2436)})});
    V v_t_2439 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2438, v_sp_2436}), NTAG(TAG_Nil)});
    V v_args_2440 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2434, v_sp_2432}), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2435, v_t_2439})});
    V v_sp_2441 = heff_take_field(v_k_240, 6);
    V v_t_2442 = heff_get_n(v_k_240, 1, 7);
    V v_t_2443;
    if ((heff_dup(v_t_2442) == NTAG(TAG_True))) {
      heff_drop(v_t_2442);
      v_t_2443 = ((V)&g_heff_2eelab_2eclauses_2eutfWidth_str4);
    } else {
      heff_drop(v_t_2442);
      v_t_2443 = ((V)&g_heff_2eelab_2eclauses_2eutfWidth_str5);
    }
    V v_t_2444 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){v_t_2443}), heff_dup(v_sp_2441)});
    V v_t_2445 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_2441), v_args_2440));
    return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2444, v_t_2445}), v_sp_2441});
  }
  case TAG_SegmentFloat: {
    V v_sp_2446 = heff_dup(heff_rfield(v_k_240, 6));
    V v_t_2447 = heff_tag_n(TAG_IVar, 1, (V[]){heff_take_field(v_k_240, 0)});
    V v_t_2448 = heff_tag_n(TAG_CInf, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2447, heff_dup(v_sp_2446)})});
    V v_t_2449 = (g_heff_2eelab_2eclauses_2eoffC(v_off_241, heff_dup(heff_rfield(v_k_240, 6))));
    V v_sp_2450 = heff_dup(heff_rfield(v_k_240, 6));
    V v_t_2451 = heff_tag_n(TAG_IInt, 1, (V[]){heff_get_n(v_s_242, 3, 5)});
    V v_t_2452 = heff_tag_n(TAG_CInf, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2451, heff_dup(v_sp_2450)})});
    V v_t_2453 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2452, v_sp_2450}), NTAG(TAG_Nil)});
    V v_args_2454 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2448, v_sp_2446}), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2449, v_t_2453})});
    V v_sp_2455 = heff_take_field(v_k_240, 6);
    V v_t_2456 = heff_get_n(v_k_240, 1, 7);
    V v_t_2457;
    if ((heff_dup(v_t_2456) == NTAG(TAG_True))) {
      heff_drop(v_t_2456);
      v_t_2457 = ((V)&g_heff_2eelab_2eclauses_2eutfWidth_str6);
    } else {
      heff_drop(v_t_2456);
      v_t_2457 = ((V)&g_heff_2eelab_2eclauses_2eutfWidth_str7);
    }
    V v_t_2458 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){v_t_2457}), heff_dup(v_sp_2455)});
    V v_t_2459 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_2455), v_args_2454));
    return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2458, v_t_2459}), v_sp_2455});
  }
  case TAG_SegmentUtf: {
    V v_ty1_2460 = heff_field(v_ty_243, 0);
    V v_ru_24ty_243_24SegmentUtf = heff_take_reuse_n(v_ty_243, 1ULL, 1);
    if (heff_intEq_c(v_ty1_2460, MK_INT(8LL))) {
      heff_drop_rec(v_s_242, 5);
      V v_sp_2462 = heff_dup(heff_rfield(v_k_240, 6));
      V v_t_2463 = heff_tag_at_n(v_ru_24ty_243_24SegmentUtf, TAG_IVar, 1, (V[]){heff_dup(heff_rfield(v_k_240, 0))});
      V v_t_2464 = heff_tag_n(TAG_CInf, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2463, heff_dup(v_sp_2462)})});
      V v_t_2465 = (g_heff_2eelab_2eclauses_2eoffC(v_off_241, heff_dup(heff_rfield(v_k_240, 6))));
      V v_t_2466 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2465, NTAG(TAG_Nil)});
      V v_args_2467 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2464, v_sp_2462}), v_t_2466});
      V v_sp_2468 = heff_take_field(v_k_240, 6);
      V v_t_2469 = heff_get_n(v_k_240, 1, 7);
      V v_t_2470;
      if ((heff_dup(v_t_2469) == NTAG(TAG_True))) {
        heff_drop(v_t_2469);
        v_t_2470 = ((V)&g_heff_2eelab_2eclauses_2eutfWidth_str8);
      } else {
        heff_drop(v_t_2469);
        v_t_2470 = ((V)&g_heff_2eelab_2eclauses_2eutfWidth_str9);
      }
      V v_t_2471 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){v_t_2470}), heff_dup(v_sp_2468)});
      V v_t_2472 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_2468), v_args_2467));
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2471, v_t_2472}), v_sp_2468});
    } else {
      V v_sp_2473 = heff_dup(heff_rfield(v_k_240, 6));
      V v_t_2474 = heff_tag_at_n(v_ru_24ty_243_24SegmentUtf, TAG_IVar, 1, (V[]){heff_dup(heff_rfield(v_k_240, 0))});
      V v_t_2475 = heff_tag_n(TAG_CInf, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2474, heff_dup(v_sp_2473)})});
      V v_t_2476 = (g_heff_2eelab_2eclauses_2eoffC(v_off_241, heff_dup(heff_rfield(v_k_240, 6))));
      V v_sp_2477 = heff_dup(heff_rfield(v_k_240, 6));
      V v_t_2478 = heff_tag_n(TAG_IInt, 1, (V[]){heff_get_n(v_s_242, 3, 5)});
      V v_t_2479 = heff_tag_n(TAG_CInf, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2478, heff_dup(v_sp_2477)})});
      V v_t_2480 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2479, v_sp_2477}), NTAG(TAG_Nil)});
      V v_args_2481 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2475, v_sp_2473}), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2476, v_t_2480})});
      V v_sp_2482 = heff_take_field(v_k_240, 6);
      V v_t_2483 = heff_get_n(v_k_240, 1, 7);
      V v_t_2484;
      if ((heff_dup(v_t_2483) == NTAG(TAG_True))) {
        heff_drop(v_t_2483);
        v_t_2484 = ((V)&g_heff_2eelab_2eclauses_2eutfWidth_str10);
      } else {
        heff_drop(v_t_2483);
        v_t_2484 = ((V)&g_heff_2eelab_2eclauses_2eutfWidth_str11);
      }
      V v_t_2485 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){v_t_2484}), heff_dup(v_sp_2482)});
      V v_t_2486 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_2482), v_args_2481));
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2485, v_t_2486}), v_sp_2482});
    }
  }
  default: return heff_nomatch(v_ty_243);
  }
}
V g_heff_2eelab_2eclauses_2eutfWidth_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2eutfWidth(a[0], a[1], a[2], a[3]);
}
HEFF_LIT(g_heff_2eelab_2eclauses_2eutfRead_str0, 11, "runeFromInt");
HEFF_LIT(g_heff_2eelab_2eclauses_2eutfRead_str1, 11, "runeFromInt");
HEFF_LIT(g_heff_2eelab_2eclauses_2eutfRead_str2, 11, "runeFromInt");
HEFF_LIT(g_heff_2eelab_2eclauses_2eutfRead_str3, 11, "runeFromInt");
HEFF_LIT(g_heff_2eelab_2eclauses_2eutfRead_str4, 18, "prelude.bitsUtf8At");
HEFF_LIT(g_heff_2eelab_2eclauses_2eutfRead_str5, 19, "prelude.bytesUtf8At");
HEFF_LIT(g_heff_2eelab_2eclauses_2eutfRead_str6, 19, "prelude.bitsUtf16At");
HEFF_LIT(g_heff_2eelab_2eclauses_2eutfRead_str7, 20, "prelude.bytesUtf16At");
HEFF_LIT(g_heff_2eelab_2eclauses_2eutfRead_str8, 11, "runeFromInt");
Clo g_heff_2eelab_2eclauses_2eutfRead_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2eutfRead_entry, 4, 0};

V g_heff_2eelab_2eclauses_2eutfRead(V v_k_240, V v_off_241, V v_s_242, V v_ty_243) {
top: ;
  switch (heff_tag_of(v_ty_243)) {
  case TAG_SegmentInteger: {
    V v_i_244 = (g_heff_2eelab_2eclauses_2eintRead_24s1663986196x980850164(MK_INT(32LL), heff_dup(v_k_240), v_off_241, heff_get_n(v_s_242, 3, 5)));
    V v_t_247;
    switch (heff_tag_of(v_i_244)) {
    case TAG_At: {
      V v_s_246 = heff_dup(heff_field(v_i_244, 1));
      v_t_247 = v_s_246;
      break;
    }
    default: heff_nomatch(v_i_244);
    }
    V v_t_248 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_244}), v_t_247});
    V v_args_249 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_248, NTAG(TAG_Nil)});
    V v_sp_2410 = heff_get_n(v_k_240, 6, 7);
    V v_t_2411 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2eelab_2eclauses_2eutfRead_str0)}), heff_dup(v_sp_2410)});
    V v_t_2412 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_2410), v_args_249));
    return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2411, v_t_2412}), v_sp_2410});
  }
  case TAG_SegmentBinary: {
    V v_i_2413 = (g_heff_2eelab_2eclauses_2eintRead_24s1663986196x980850164(MK_INT(32LL), heff_dup(v_k_240), v_off_241, heff_get_n(v_s_242, 3, 5)));
    V v_t_2416;
    switch (heff_tag_of(v_i_2413)) {
    case TAG_At: {
      V v_s_2415 = heff_dup(heff_field(v_i_2413, 1));
      v_t_2416 = v_s_2415;
      break;
    }
    default: heff_nomatch(v_i_2413);
    }
    V v_t_2417 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_2413}), v_t_2416});
    V v_args_2418 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2417, NTAG(TAG_Nil)});
    V v_sp_2419 = heff_get_n(v_k_240, 6, 7);
    V v_t_2420 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2eelab_2eclauses_2eutfRead_str1)}), heff_dup(v_sp_2419)});
    V v_t_2421 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_2419), v_args_2418));
    return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2420, v_t_2421}), v_sp_2419});
  }
  case TAG_SegmentBits: {
    V v_i_2422 = (g_heff_2eelab_2eclauses_2eintRead_24s1663986196x980850164(MK_INT(32LL), heff_dup(v_k_240), v_off_241, heff_get_n(v_s_242, 3, 5)));
    V v_t_2425;
    switch (heff_tag_of(v_i_2422)) {
    case TAG_At: {
      V v_s_2424 = heff_dup(heff_field(v_i_2422, 1));
      v_t_2425 = v_s_2424;
      break;
    }
    default: heff_nomatch(v_i_2422);
    }
    V v_t_2426 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_2422}), v_t_2425});
    V v_args_2427 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2426, NTAG(TAG_Nil)});
    V v_sp_2428 = heff_get_n(v_k_240, 6, 7);
    V v_t_2429 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2eelab_2eclauses_2eutfRead_str2)}), heff_dup(v_sp_2428)});
    V v_t_2430 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_2428), v_args_2427));
    return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2429, v_t_2430}), v_sp_2428});
  }
  case TAG_SegmentFloat: {
    V v_i_2431 = (g_heff_2eelab_2eclauses_2eintRead_24s1663986196x980850164(MK_INT(32LL), heff_dup(v_k_240), v_off_241, heff_get_n(v_s_242, 3, 5)));
    V v_t_2434;
    switch (heff_tag_of(v_i_2431)) {
    case TAG_At: {
      V v_s_2433 = heff_dup(heff_field(v_i_2431, 1));
      v_t_2434 = v_s_2433;
      break;
    }
    default: heff_nomatch(v_i_2431);
    }
    V v_t_2435 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_2431}), v_t_2434});
    V v_args_2436 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2435, NTAG(TAG_Nil)});
    V v_sp_2437 = heff_get_n(v_k_240, 6, 7);
    V v_t_2438 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2eelab_2eclauses_2eutfRead_str3)}), heff_dup(v_sp_2437)});
    V v_t_2439 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_2437), v_args_2436));
    return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2438, v_t_2439}), v_sp_2437});
  }
  case TAG_SegmentUtf: {
    V v_ty1_2440 = heff_field(v_ty_243, 0);
    V v_ru_24ty_243_24SegmentUtf = heff_take_reuse_n(v_ty_243, 1ULL, 1);
    if (heff_intEq_c_lent(v_ty1_2440, MK_INT(8LL), 2)) {
      heff_drop_rec(v_s_242, 5);
      heff_drop(v_ty1_2440);
      V v_sp_2442 = heff_dup(heff_rfield(v_k_240, 6));
      V v_t_2443 = heff_tag_at_n(v_ru_24ty_243_24SegmentUtf, TAG_IVar, 1, (V[]){heff_dup(heff_rfield(v_k_240, 0))});
      V v_t_2444 = heff_tag_n(TAG_CInf, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2443, heff_dup(v_sp_2442)})});
      V v_t_2445 = (g_heff_2eelab_2eclauses_2eoffC(v_off_241, heff_dup(heff_rfield(v_k_240, 6))));
      V v_t_2446 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2445, NTAG(TAG_Nil)});
      V v_args_2447 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2444, v_sp_2442}), v_t_2446});
      V v_sp_2448 = heff_take_field(v_k_240, 6);
      V v_t_2449 = heff_get_n(v_k_240, 1, 7);
      V v_t_2450;
      if ((heff_dup(v_t_2449) == NTAG(TAG_True))) {
        heff_drop(v_t_2449);
        v_t_2450 = ((V)&g_heff_2eelab_2eclauses_2eutfRead_str4);
      } else {
        heff_drop(v_t_2449);
        v_t_2450 = ((V)&g_heff_2eelab_2eclauses_2eutfRead_str5);
      }
      V v_t_2451 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){v_t_2450}), heff_dup(v_sp_2448)});
      V v_t_2452 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_2448), v_args_2447));
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2451, v_t_2452}), v_sp_2448});
    } else {
      if (heff_intEq_c(v_ty1_2440, MK_INT(16LL))) {
        V v_sp_2454 = heff_dup(heff_rfield(v_k_240, 6));
        V v_t_2455 = heff_tag_at_n(v_ru_24ty_243_24SegmentUtf, TAG_IVar, 1, (V[]){heff_dup(heff_rfield(v_k_240, 0))});
        V v_t_2456 = heff_tag_n(TAG_CInf, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2455, heff_dup(v_sp_2454)})});
        V v_t_2457 = (g_heff_2eelab_2eclauses_2eoffC(v_off_241, heff_dup(heff_rfield(v_k_240, 6))));
        V v_sp_2458 = heff_dup(heff_rfield(v_k_240, 6));
        V v_t_2459 = heff_tag_n(TAG_IInt, 1, (V[]){heff_get_n(v_s_242, 3, 5)});
        V v_t_2460 = heff_tag_n(TAG_CInf, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2459, heff_dup(v_sp_2458)})});
        V v_t_2461 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2460, v_sp_2458}), NTAG(TAG_Nil)});
        V v_args_2462 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2456, v_sp_2454}), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2457, v_t_2461})});
        V v_sp_2463 = heff_take_field(v_k_240, 6);
        V v_t_2464 = heff_get_n(v_k_240, 1, 7);
        V v_t_2465;
        if ((heff_dup(v_t_2464) == NTAG(TAG_True))) {
          heff_drop(v_t_2464);
          v_t_2465 = ((V)&g_heff_2eelab_2eclauses_2eutfRead_str6);
        } else {
          heff_drop(v_t_2464);
          v_t_2465 = ((V)&g_heff_2eelab_2eclauses_2eutfRead_str7);
        }
        V v_t_2466 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){v_t_2465}), heff_dup(v_sp_2463)});
        V v_t_2467 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_2463), v_args_2462));
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2466, v_t_2467}), v_sp_2463});
      } else {
        V v_i_2468 = (g_heff_2eelab_2eclauses_2eintRead_24s1663986196x980850164(MK_INT(32LL), heff_dup(v_k_240), v_off_241, heff_get_n(v_s_242, 3, 5)));
        V v_t_2471;
        switch (heff_tag_of(v_i_2468)) {
        case TAG_At: {
          V v_s_2470 = heff_dup(heff_field(v_i_2468, 1));
          v_t_2471 = v_s_2470;
          break;
        }
        default: heff_nomatch(v_i_2468);
        }
        V v_t_2472 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24ty_243_24SegmentUtf, TAG_CInf, 1, (V[]){v_i_2468}), v_t_2471});
        V v_args_2473 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2472, NTAG(TAG_Nil)});
        V v_sp_2474 = heff_get_n(v_k_240, 6, 7);
        V v_t_2475 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2eelab_2eclauses_2eutfRead_str8)}), heff_dup(v_sp_2474)});
        V v_t_2476 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_2474), v_args_2473));
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2475, v_t_2476}), v_sp_2474});
      }
    }
  }
  default: return heff_nomatch(v_ty_243);
  }
}
V g_heff_2eelab_2eclauses_2eutfRead_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2eutfRead(a[0], a[1], a[2], a[3]);
}
HEFF_LIT(g_heff_2eelab_2eclauses_2epartTest_str0, 6, "intSub");
HEFF_LIT(g_heff_2eelab_2eclauses_2epartTest_str1, 6, "intMod");
HEFF_LIT(g_heff_2eelab_2eclauses_2epartTest_str2, 5, "intEq");
HEFF_LIT(g_heff_2eelab_2eclauses_2epartTest_str3, 4, "True");
HEFF_LIT(g_heff_2eelab_2eclauses_2epartTest_str4, 22, "prelude.bitsHasBytesAt");
HEFF_LIT(g_heff_2eelab_2eclauses_2epartTest_str5, 10, "bytesHasAt");
HEFF_LIT(g_heff_2eelab_2eclauses_2epartTest_str6, 4, "True");
Clo g_heff_2eelab_2eclauses_2epartTest_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2epartTest_entry, 11, 0};

V g_heff_2eelab_2eclauses_2epartTest(V v_t_240, V v_k_241, V v_env_242, V v_i_243, V v_off_244, V v_s_245, V v_rest_246, V v_w_247, V v_ty_248, V v_size_249, V v_x11_2410) {
top: ;
  switch (heff_tag_of(v_ty_248)) {
  case TAG_SegmentInteger: {
    heff_drop(v_x11_2410);
    V v_t_2411 = heff_intAdd(heff_dup(heff_rfield(v_off_244, 0)), heff_dup(heff_rfield(v_w_247, 0)));
    V v_t_2412 = (g_heff_2eelab_2eclauses_2eappendC(heff_dup(heff_rfield(v_off_244, 1)), heff_dup(heff_rfield(v_w_247, 1))));
    V v_t_2413 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 4, (V[]){v_env_242, heff_intAdd(v_i_243, MK_INT(1LL)), heff_rec_n(2, shape_bits__terms, (V[]){v_t_2411, v_t_2412}), v_rest_246}));
    V v_t_2414 = (g_heff_2eelab_2eclauses_2efits(heff_dup(v_k_241), v_off_244, heff_dup(v_w_247), v_t_2413));
    return (g_heff_2eelab_2eclauses_2esizeOk(v_k_241, v_ty_248, v_size_249, v_w_247, v_t_2414));
  }
  case TAG_SegmentBinary: {
    switch (heff_tag_of(v_size_249)) {
    case TAG_SizeDefault: {
      switch (heff_tag_of(v_x11_2410)) {
      case TAG_Nothing: {
        heff_drop_rec(v_t_240, 1);
        heff_drop(v_env_242);
        heff_drop(v_i_243);
        heff_drop(v_rest_246);
        heff_drop_rec(v_w_247, 2);
        V v_t_2415 = heff_take_field(v_k_241, 1);
        if ((heff_dup(v_t_2415) == NTAG(TAG_True))) {
          heff_drop(v_t_2415);
          V v_sp_2416 = heff_dup(heff_rfield(v_k_241, 6));
          V v_t_2417 = heff_tag_n(TAG_IVar, 1, (V[]){heff_take_field(v_k_241, 2)});
          V v_t_2418 = heff_tag_n(TAG_CInf, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2417, heff_dup(v_sp_2416)})});
          V v_t_2419 = (g_heff_2eelab_2eclauses_2eoffC(v_off_244, heff_dup(heff_rfield(v_k_241, 6))));
          V v_t_2420 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2419, NTAG(TAG_Nil)});
          V v_args_2421 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2418, v_sp_2416}), v_t_2420});
          V v_sp_2422 = heff_dup(heff_rfield(v_k_241, 6));
          V v_t_2423 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_2422), v_args_2421));
          V v_t_2424 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2eelab_2eclauses_2epartTest_str0)}), heff_dup(v_sp_2422)});
          V v_t_2425 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2424, v_t_2423}), heff_dup(v_sp_2422)});
          V v_t_2426 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2425}), v_sp_2422});
          V v_sp_2427 = heff_dup(heff_rfield(v_k_241, 6));
          V v_t_2428 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IInt, 1, (V[]){MK_INT(8LL)}), heff_dup(v_sp_2427)});
          V v_t_2429 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2428}), v_sp_2427});
          V v_t_2430 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2429, NTAG(TAG_Nil)});
          V v_args_2431 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2426, v_t_2430});
          V v_sp_2432 = heff_dup(heff_rfield(v_k_241, 6));
          V v_t_2433 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_2432), v_args_2431));
          V v_t_2434 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2eelab_2eclauses_2epartTest_str1)}), heff_dup(v_sp_2432)});
          V v_t_2435 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2434, v_t_2433}), heff_dup(v_sp_2432)});
          V v_t_2436 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2435}), v_sp_2432});
          V v_sp_2437 = heff_dup(heff_rfield(v_k_241, 6));
          V v_t_2438 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IInt, 1, (V[]){MK_INT(0LL)}), heff_dup(v_sp_2437)});
          V v_t_2439 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2438}), v_sp_2437});
          V v_t_2440 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2439, NTAG(TAG_Nil)});
          V v_args_2441 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2436, v_t_2440});
          V v_sp_2442 = heff_get_n(v_k_241, 6, 7);
          V v_t_2443 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_2442), v_args_2441));
          V v_t_2444 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2eelab_2eclauses_2epartTest_str2)}), heff_dup(v_sp_2442)});
          V v_t_2445 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2444, v_t_2443}), heff_dup(v_sp_2442)});
          return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2445}), v_sp_2442});
        } else {
          heff_drop_rec(v_off_244, 2);
          heff_drop(v_t_2415);
          V v_sp_2446 = heff_get_n(v_k_241, 6, 7);
          V v_t_2447 = heff_tag_n(TAG_CTag, 3, (V[]){((V)&g_heff_2eelab_2eclauses_2epartTest_str3), heff_dup(v_sp_2446), NTAG(TAG_Nil)});
          return heff_tag_n(TAG_At, 2, (V[]){v_t_2447, v_sp_2446});
        }
      }
      case TAG_Just: {
        V v_str_2448 = heff_field(v_x11_2410, 0);
        V v_ru_24x11_2410_24Just = heff_take_reuse_n(v_x11_2410, 1ULL, 1);
        V v_t_2449 = heff_take_field(v_k_241, 1);
        V v_t_2474;
        if ((heff_dup(v_t_2449) == NTAG(TAG_True))) {
          heff_drop(v_t_2449);
          V v_sp_2450 = heff_dup(heff_rfield(v_k_241, 6));
          V v_t_2451 = heff_tag_at_n(v_ru_24x11_2410_24Just, TAG_IVar, 1, (V[]){heff_dup(heff_rfield(v_k_241, 0))});
          V v_t_2452 = heff_tag_n(TAG_CInf, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2451, heff_dup(v_sp_2450)})});
          V v_t_2453 = (g_heff_2eelab_2eclauses_2eoffC(heff_dup(v_off_244), heff_dup(heff_rfield(v_k_241, 6))));
          V v_t_2454 = heff_dup(heff_rfield(v_k_241, 6));
          V v_t_2455 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IBytes, 1, (V[]){v_str_2448}), heff_dup(v_t_2454)});
          V v_t_2456 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2455}), v_t_2454});
          V v_t_2457 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2456, NTAG(TAG_Nil)});
          V v_args_2458 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2452, v_sp_2450}), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2453, v_t_2457})});
          V v_sp_2459 = heff_dup(heff_rfield(v_k_241, 6));
          V v_t_2460 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2eelab_2eclauses_2epartTest_str4)}), heff_dup(v_sp_2459)});
          V v_t_2461 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_2459), v_args_2458));
          v_t_2474 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2460, v_t_2461}), v_sp_2459});
        } else {
          heff_drop(v_t_2449);
          V v_sp_2462 = heff_dup(heff_rfield(v_k_241, 6));
          V v_t_2463 = heff_tag_at_n(v_ru_24x11_2410_24Just, TAG_IVar, 1, (V[]){heff_dup(heff_rfield(v_k_241, 0))});
          V v_t_2464 = heff_tag_n(TAG_CInf, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2463, heff_dup(v_sp_2462)})});
          V v_t_2465 = (g_heff_2eelab_2eclauses_2eoffBytesC(heff_dup(v_off_244), heff_dup(heff_rfield(v_k_241, 6))));
          V v_t_2466 = heff_dup(heff_rfield(v_k_241, 6));
          V v_t_2467 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IBytes, 1, (V[]){v_str_2448}), heff_dup(v_t_2466)});
          V v_t_2468 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2467}), v_t_2466});
          V v_t_2469 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2468, NTAG(TAG_Nil)});
          V v_args_2470 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2464, v_sp_2462}), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2465, v_t_2469})});
          V v_sp_2471 = heff_dup(heff_rfield(v_k_241, 6));
          V v_t_2472 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2eelab_2eclauses_2epartTest_str5)}), heff_dup(v_sp_2471)});
          V v_t_2473 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_2471), v_args_2470));
          v_t_2474 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2472, v_t_2473}), v_sp_2471});
        }
        V v_t_2475 = heff_intAdd(heff_take_field(v_off_244, 0), heff_take_field(v_w_247, 0));
        V v_t_2476 = (g_heff_2eelab_2eclauses_2eappendC(heff_get_n(v_off_244, 1, 2), heff_get_n(v_w_247, 1, 2)));
        V v_t_2477 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 4, (V[]){v_env_242, heff_intAdd(v_i_243, MK_INT(1LL)), heff_rec_n(2, shape_bits__terms, (V[]){v_t_2475, v_t_2476}), v_rest_246}));
        return (g_heff_2eelab_2eclauses_2eandC(v_t_2474, v_t_2477, heff_get_n(v_k_241, 6, 7)));
      }
      default: return heff_nomatch(v_x11_2410);
      }
    }
    case TAG_SizeNumber: {
      heff_drop(v_x11_2410);
      V v_t_2479 = heff_intAdd(heff_dup(heff_rfield(v_off_244, 0)), heff_dup(heff_rfield(v_w_247, 0)));
      V v_t_2480 = (g_heff_2eelab_2eclauses_2eappendC(heff_dup(heff_rfield(v_off_244, 1)), heff_dup(heff_rfield(v_w_247, 1))));
      V v_t_2481 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 4, (V[]){v_env_242, heff_intAdd(v_i_243, MK_INT(1LL)), heff_rec_n(2, shape_bits__terms, (V[]){v_t_2479, v_t_2480}), v_rest_246}));
      V v_t_2482 = (g_heff_2eelab_2eclauses_2efits(heff_dup(v_k_241), v_off_244, heff_dup(v_w_247), v_t_2481));
      return (g_heff_2eelab_2eclauses_2esizeOk(v_k_241, v_ty_248, v_size_249, v_w_247, v_t_2482));
    }
    case TAG_SizeName: {
      heff_drop(v_x11_2410);
      V v_t_2486 = heff_intAdd(heff_dup(heff_rfield(v_off_244, 0)), heff_dup(heff_rfield(v_w_247, 0)));
      V v_t_2487 = (g_heff_2eelab_2eclauses_2eappendC(heff_dup(heff_rfield(v_off_244, 1)), heff_dup(heff_rfield(v_w_247, 1))));
      V v_t_2488 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 4, (V[]){v_env_242, heff_intAdd(v_i_243, MK_INT(1LL)), heff_rec_n(2, shape_bits__terms, (V[]){v_t_2486, v_t_2487}), v_rest_246}));
      V v_t_2489 = (g_heff_2eelab_2eclauses_2efits(heff_dup(v_k_241), v_off_244, heff_dup(v_w_247), v_t_2488));
      return (g_heff_2eelab_2eclauses_2esizeOk(v_k_241, v_ty_248, v_size_249, v_w_247, v_t_2489));
    }
    default: return heff_nomatch(v_size_249);
    }
  }
  case TAG_SegmentBits: {
    heff_drop(v_x11_2410);
    switch (heff_tag_of(v_size_249)) {
    case TAG_SizeDefault: {
      heff_drop_rec(v_t_240, 1);
      heff_drop(v_env_242);
      heff_drop(v_i_243);
      heff_drop_rec(v_off_244, 2);
      heff_drop(v_rest_246);
      heff_drop_rec(v_w_247, 2);
      V v_sp_2490 = heff_get_n(v_k_241, 6, 7);
      V v_t_2491 = heff_tag_n(TAG_CTag, 3, (V[]){((V)&g_heff_2eelab_2eclauses_2epartTest_str6), heff_dup(v_sp_2490), NTAG(TAG_Nil)});
      return heff_tag_n(TAG_At, 2, (V[]){v_t_2491, v_sp_2490});
    }
    case TAG_SizeNumber: {
      V v_t_2493 = heff_intAdd(heff_dup(heff_rfield(v_off_244, 0)), heff_dup(heff_rfield(v_w_247, 0)));
      V v_t_2494 = (g_heff_2eelab_2eclauses_2eappendC(heff_dup(heff_rfield(v_off_244, 1)), heff_dup(heff_rfield(v_w_247, 1))));
      V v_t_2495 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 4, (V[]){v_env_242, heff_intAdd(v_i_243, MK_INT(1LL)), heff_rec_n(2, shape_bits__terms, (V[]){v_t_2493, v_t_2494}), v_rest_246}));
      V v_t_2496 = (g_heff_2eelab_2eclauses_2efits(heff_dup(v_k_241), v_off_244, heff_dup(v_w_247), v_t_2495));
      return (g_heff_2eelab_2eclauses_2esizeOk(v_k_241, v_ty_248, v_size_249, v_w_247, v_t_2496));
    }
    case TAG_SizeName: {
      V v_t_24100 = heff_intAdd(heff_dup(heff_rfield(v_off_244, 0)), heff_dup(heff_rfield(v_w_247, 0)));
      V v_t_24101 = (g_heff_2eelab_2eclauses_2eappendC(heff_dup(heff_rfield(v_off_244, 1)), heff_dup(heff_rfield(v_w_247, 1))));
      V v_t_24102 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 4, (V[]){v_env_242, heff_intAdd(v_i_243, MK_INT(1LL)), heff_rec_n(2, shape_bits__terms, (V[]){v_t_24100, v_t_24101}), v_rest_246}));
      V v_t_24103 = (g_heff_2eelab_2eclauses_2efits(heff_dup(v_k_241), v_off_244, heff_dup(v_w_247), v_t_24102));
      return (g_heff_2eelab_2eclauses_2esizeOk(v_k_241, v_ty_248, v_size_249, v_w_247, v_t_24103));
    }
    default: return heff_nomatch(v_size_249);
    }
  }
  case TAG_SegmentFloat: {
    heff_drop(v_x11_2410);
    V v_t_24104 = heff_intAdd(heff_dup(heff_rfield(v_off_244, 0)), heff_dup(heff_rfield(v_w_247, 0)));
    V v_t_24105 = (g_heff_2eelab_2eclauses_2eappendC(heff_dup(heff_rfield(v_off_244, 1)), heff_dup(heff_rfield(v_w_247, 1))));
    V v_t_24106 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 4, (V[]){v_env_242, heff_intAdd(v_i_243, MK_INT(1LL)), heff_rec_n(2, shape_bits__terms, (V[]){v_t_24104, v_t_24105}), v_rest_246}));
    V v_t_24107 = (g_heff_2eelab_2eclauses_2efits(heff_dup(v_k_241), v_off_244, heff_dup(v_w_247), v_t_24106));
    return (g_heff_2eelab_2eclauses_2esizeOk(v_k_241, v_ty_248, v_size_249, v_w_247, v_t_24107));
  }
  case TAG_SegmentUtf: {
    heff_drop(v_x11_2410);
    V v_t_24109 = heff_intAdd(heff_dup(heff_rfield(v_off_244, 0)), heff_dup(heff_rfield(v_w_247, 0)));
    V v_t_24110 = (g_heff_2eelab_2eclauses_2eappendC(heff_dup(heff_rfield(v_off_244, 1)), heff_dup(heff_rfield(v_w_247, 1))));
    V v_t_24111 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 4, (V[]){v_env_242, heff_intAdd(v_i_243, MK_INT(1LL)), heff_rec_n(2, shape_bits__terms, (V[]){v_t_24109, v_t_24110}), v_rest_246}));
    V v_t_24112 = (g_heff_2eelab_2eclauses_2efits(heff_dup(v_k_241), v_off_244, heff_dup(v_w_247), v_t_24111));
    return (g_heff_2eelab_2eclauses_2esizeOk(v_k_241, v_ty_248, v_size_249, v_w_247, v_t_24112));
  }
  default: return heff_nomatch(v_ty_248);
  }
}
V g_heff_2eelab_2eclauses_2epartTest_entry(V self, V *a) {
  (void)self;
  V a5 = a[5]; V a9 = a[9]; V r = g_heff_2eelab_2eclauses_2epartTest(a[0], a[1], a[2], a[3], a[4], a5, a[6], a[7], a[8], a9, a[10]); heff_drop(a5); heff_drop(a9); return r;
}
HEFF_LIT(g_heff_2eelab_2eclauses_2esegTest_str0, 5, "Width");
HEFF_LIT(g_heff_2eelab_2eclauses_2esegTest_str1, 5, "Width");
HEFF_LIT(g_heff_2eelab_2eclauses_2esegTest_str2, 21, "prelude.isScalarValue");
HEFF_LIT(g_heff_2eelab_2eclauses_2esegTest_str3, 5, "Width");
HEFF_LIT(g_heff_2eelab_2eclauses_2esegTest_str4, 5, "Width");
HEFF_LIT(g_heff_2eelab_2eclauses_2esegTest_str5, 5, "Width");
HEFF_LIT(g_heff_2eelab_2eclauses_2esegTest_str6, 5, "intLt");
HEFF_LIT(g_heff_2eelab_2eclauses_2esegTest_str7, 9, "runeToInt");
HEFF_LIT(g_heff_2eelab_2eclauses_2esegTest_str8, 5, "Width");
Clo g_heff_2eelab_2eclauses_2esegTest_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2esegTest_entry, 9, 0};

V g_heff_2eelab_2eclauses_2esegTest(V v_t_240, V v_k_241, V v_env_242, V v_i_243, V v_off_244, V v_s_245, V v_rest_246, V v_w_247, V v_ty_248) {
top: ;
  switch (heff_tag_of(v_ty_248)) {
  case TAG_SegmentInteger: {
    V v_t_249 = heff_tr(g_heff_2eelab_2eclauses_2eintTest(v_t_240, heff_dup(v_k_241), v_env_242, v_i_243, heff_dup(v_off_244), heff_dup(v_s_245), v_rest_246, heff_dup(v_w_247), heff_dup(heff_rfield(v_s_245, 0))));
    V v_t_2410 = (g_heff_2eelab_2eclauses_2efits(heff_dup(v_k_241), v_off_244, heff_dup(v_w_247), v_t_249));
    return ({ V a_0 = v_k_241; V a_1 = NTAG(TAG_SegmentInteger); V b_2 = heff_get_n(v_s_245, 2, 5); V a_3 = v_w_247; V a_4 = v_t_2410; V r_ = (g_heff_2eelab_2eclauses_2esizeOk(a_0, a_1, b_2, a_3, a_4)); heff_drop(b_2); r_; });
  }
  case TAG_SegmentBinary: {
    V v_t_2411 = heff_dup(heff_rfield(v_s_245, 0));
    V v_t_2431;
    switch (heff_tag_of(v_t_2411)) {
    case TAG_At: {
      V v_x11_2412 = heff_field(v_t_2411, 0);
      heff_take_n(v_t_2411, 1ULL, 2);
      switch (heff_tag_of(v_x11_2412)) {
      case TAG_PatVar: {
        heff_take_n(v_x11_2412, 0ULL, 1);
        v_t_2431 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_PatTag: {
        heff_take_n(v_x11_2412, 0ULL, 3);
        v_t_2431 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_PatOp: {
        heff_take_n(v_x11_2412, 0ULL, 3);
        v_t_2431 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_PatInt: {
        heff_take_n(v_x11_2412, 0ULL, 1);
        v_t_2431 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_PatFloat: {
        heff_take_na(v_x11_2412, 0ULL, 1);
        v_t_2431 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_PatString: {
        V v_str_2423 = heff_field(v_x11_2412, 0);
        V v_ru_24x11_2412_24PatString = heff_take_reuse_n(v_x11_2412, 1ULL, 1);
        v_t_2431 = heff_tag_at_n(v_ru_24x11_2412_24PatString, TAG_Just, 1, (V[]){v_str_2423});
        break;
      }
      case TAG_PatBinary: {
        heff_take_n(v_x11_2412, 0ULL, 1);
        v_t_2431 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_PatRune: {
        heff_take_n(v_x11_2412, 0ULL, 1);
        v_t_2431 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_PatRecord: {
        heff_take_n(v_x11_2412, 0ULL, 1);
        v_t_2431 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_PatWord: {
        heff_take_n(v_x11_2412, 0ULL, 1);
        v_t_2431 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_PatAs: {
        heff_take_n(v_x11_2412, 0ULL, 3);
        v_t_2431 = NTAG(TAG_Nothing);
        break;
      }
      default: heff_nomatch(v_x11_2412);
      }
      break;
    }
    default: heff_nomatch(v_t_2411);
    }
    return ({ V a_0 = v_t_240; V a_1 = v_k_241; V a_2 = v_env_242; V a_3 = v_i_243; V a_4 = v_off_244; V a_5 = v_s_245; V a_6 = v_rest_246; V a_7 = v_w_247; V a_8 = v_ty_248; V b_9 = heff_dup(heff_rfield(v_s_245, 2)); V a_10 = v_t_2431; V r_ = (g_heff_2eelab_2eclauses_2epartTest(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, b_9, a_10)); heff_drop_rec(v_s_245, 5); heff_drop(b_9); r_; });
  }
  case TAG_SegmentBits: {
    V v_t_2432 = heff_dup(heff_rfield(v_s_245, 0));
    V v_t_2452;
    switch (heff_tag_of(v_t_2432)) {
    case TAG_At: {
      V v_x11_2433 = heff_field(v_t_2432, 0);
      heff_take_n(v_t_2432, 1ULL, 2);
      switch (heff_tag_of(v_x11_2433)) {
      case TAG_PatVar: {
        heff_take_n(v_x11_2433, 0ULL, 1);
        v_t_2452 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_PatTag: {
        heff_take_n(v_x11_2433, 0ULL, 3);
        v_t_2452 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_PatOp: {
        heff_take_n(v_x11_2433, 0ULL, 3);
        v_t_2452 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_PatInt: {
        heff_take_n(v_x11_2433, 0ULL, 1);
        v_t_2452 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_PatFloat: {
        heff_take_na(v_x11_2433, 0ULL, 1);
        v_t_2452 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_PatString: {
        V v_str_2444 = heff_field(v_x11_2433, 0);
        V v_ru_24x11_2433_24PatString = heff_take_reuse_n(v_x11_2433, 1ULL, 1);
        v_t_2452 = heff_tag_at_n(v_ru_24x11_2433_24PatString, TAG_Just, 1, (V[]){v_str_2444});
        break;
      }
      case TAG_PatBinary: {
        heff_take_n(v_x11_2433, 0ULL, 1);
        v_t_2452 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_PatRune: {
        heff_take_n(v_x11_2433, 0ULL, 1);
        v_t_2452 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_PatRecord: {
        heff_take_n(v_x11_2433, 0ULL, 1);
        v_t_2452 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_PatWord: {
        heff_take_n(v_x11_2433, 0ULL, 1);
        v_t_2452 = NTAG(TAG_Nothing);
        break;
      }
      case TAG_PatAs: {
        heff_take_n(v_x11_2433, 0ULL, 3);
        v_t_2452 = NTAG(TAG_Nothing);
        break;
      }
      default: heff_nomatch(v_x11_2433);
      }
      break;
    }
    default: heff_nomatch(v_t_2432);
    }
    return ({ V a_0 = v_t_240; V a_1 = v_k_241; V a_2 = v_env_242; V a_3 = v_i_243; V a_4 = v_off_244; V a_5 = v_s_245; V a_6 = v_rest_246; V a_7 = v_w_247; V a_8 = v_ty_248; V b_9 = heff_dup(heff_rfield(v_s_245, 2)); V a_10 = v_t_2452; V r_ = (g_heff_2eelab_2eclauses_2epartTest(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, b_9, a_10)); heff_drop_rec(v_s_245, 5); heff_drop(b_9); r_; });
  }
  case TAG_SegmentFloat: {
    V v_t_2453 = heff_intAdd(heff_dup(heff_rfield(v_off_244, 0)), heff_dup(heff_rfield(v_w_247, 0)));
    V v_t_2454 = (g_heff_2eelab_2eclauses_2eappendC(heff_dup(heff_rfield(v_off_244, 1)), heff_dup(heff_rfield(v_w_247, 1))));
    V v_t_2455 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 4, (V[]){v_env_242, heff_intAdd(v_i_243, MK_INT(1LL)), heff_rec_n(2, shape_bits__terms, (V[]){v_t_2453, v_t_2454}), v_rest_246}));
    V v_t_2456 = (g_heff_2eelab_2eclauses_2efloatTest(heff_dup(v_k_241), heff_dup(v_off_244), heff_dup(v_s_245), heff_get_n(v_s_245, 0, 5), v_t_2455));
    return (g_heff_2eelab_2eclauses_2efits(v_k_241, v_off_244, v_w_247, v_t_2456));
  }
  case TAG_SegmentUtf: {
    V v_ty1_2457 = heff_field(v_ty_248, 0);
    V v_ru_24ty_248_24SegmentUtf = heff_take_reuse_n(v_ty_248, 1ULL, 1);
    if (heff_intEq_c(v_ty1_2457, MK_INT(32LL))) {
      V v_t_2459 = heff_intShow(heff_intAdd(heff_dup(v_i_243), MK_INT(1LL)));
      V v_t_2460 = heff_strAppend(heff_dup(heff_rfield(v_k_241, 0)), heff_strAppend(((V)&g_heff_2eelab_2eclauses_2esegTest_str0), v_t_2459));
      V v_x_2461 = (g_heff_2eelab_2eclauses_2efreshIn(heff_rfield(v_k_241, 4), heff_rfield(v_k_241, 5), v_t_2460));
      V v_rhs_2462 = (g_heff_2eelab_2eclauses_2eintRead(heff_dup(v_k_241), heff_dup(v_off_244), heff_dup(v_w_247), heff_take_field(v_s_245, 3)));
      V v_t_2463 = heff_intShow(heff_intAdd(heff_dup(v_i_243), MK_INT(1LL)));
      V v_t_2464 = heff_strAppend(heff_dup(heff_rfield(v_k_241, 0)), heff_strAppend(((V)&g_heff_2eelab_2eclauses_2esegTest_str1), v_t_2463));
      V v_x_2465 = (g_heff_2eelab_2eclauses_2efreshIn(heff_rfield(v_k_241, 4), heff_rfield(v_k_241, 5), v_t_2464));
      V v_sp_2466 = heff_dup(heff_rfield(v_k_241, 6));
      V v_t_2467 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24ty_248_24SegmentUtf, TAG_IVar, 1, (V[]){v_x_2465}), heff_dup(v_sp_2466)});
      V v_t_2468 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2467}), v_sp_2466});
      V v_args_2469 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2468, NTAG(TAG_Nil)});
      V v_sp_2470 = heff_dup(heff_rfield(v_k_241, 6));
      V v_t_2471 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2eelab_2eclauses_2esegTest_str2)}), heff_dup(v_sp_2470)});
      V v_t_2472 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_2470), v_args_2469));
      V v_t_2473 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2471, v_t_2472}), v_sp_2470});
      V v_t_2474 = heff_intShow(heff_intAdd(heff_dup(v_i_243), MK_INT(1LL)));
      V v_t_2475 = heff_strAppend(heff_dup(heff_rfield(v_k_241, 0)), heff_strAppend(((V)&g_heff_2eelab_2eclauses_2esegTest_str3), v_t_2474));
      V v_t_2476 = (g_heff_2eelab_2eclauses_2efreshIn(heff_rfield(v_k_241, 4), heff_rfield(v_k_241, 5), v_t_2475));
      V v_t_2477 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IVar, 1, (V[]){v_t_2476}), heff_dup(heff_rfield(v_k_241, 6))});
      V v_t_2478 = heff_intAdd(heff_dup(heff_rfield(v_off_244, 0)), heff_dup(heff_rfield(v_w_247, 0)));
      V v_t_2479 = (g_heff_2eelab_2eclauses_2eappendC(heff_dup(heff_rfield(v_off_244, 1)), heff_dup(heff_rfield(v_w_247, 1))));
      V v_t_2480 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 4, (V[]){v_env_242, heff_intAdd(v_i_243, MK_INT(1LL)), heff_rec_n(2, shape_bits__terms, (V[]){v_t_2478, v_t_2479}), v_rest_246}));
      V v_t_2481 = (g_heff_2eelab_2eclauses_2ecodeTest(heff_dup(v_k_241), v_t_2477, heff_get_n(v_s_245, 0, 5), v_t_2480));
      V v_body_2482 = (g_heff_2eelab_2eclauses_2eandC(v_t_2473, v_t_2481, heff_dup(heff_rfield(v_k_241, 6))));
      V v_sp_2483 = heff_dup(heff_rfield(v_k_241, 6));
      V v_t_2484 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_PatVar, 1, (V[]){v_x_2461}), heff_dup(v_sp_2483)});
      V v_t_2487;
      switch (heff_tag_of(v_body_2482)) {
      case TAG_At: {
        V v_s_2486 = heff_dup(heff_field(v_body_2482, 1));
        v_t_2487 = v_s_2486;
        break;
      }
      default: heff_nomatch(v_body_2482);
      }
      V v_t_2488 = ({ V rv_0 = heff_dup(heff_rfield(v_sp_2483, 0)); V rr_ = heff_rec_reuse_nf(v_t_2487, 2ULL, 2, shape_start__end, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
      V v_t_2489 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_t_2484, v_body_2482}), v_t_2488});
      V v_t_2490 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CLetIn, 2, (V[]){v_rhs_2462, v_t_2489}), v_sp_2483});
      return (g_heff_2eelab_2eclauses_2efits(v_k_241, v_off_244, v_w_247, v_t_2490));
    } else {
      heff_drop_rec(v_w_247, 2);
      V v_t_2491 = heff_intShow(heff_intAdd(heff_dup(v_i_243), MK_INT(1LL)));
      V v_t_2492 = heff_strAppend(heff_dup(heff_rfield(v_k_241, 0)), heff_strAppend(((V)&g_heff_2eelab_2eclauses_2esegTest_str4), v_t_2491));
      V v_x_2493 = (g_heff_2eelab_2eclauses_2efreshIn(heff_rfield(v_k_241, 4), heff_rfield(v_k_241, 5), v_t_2492));
      V v_rhs_2494 = (g_heff_2eelab_2eclauses_2eutfWidth(heff_dup(v_k_241), heff_dup(v_off_244), heff_dup(v_s_245), heff_dup(heff_rfield(v_s_245, 1))));
      V v_sp_2495 = heff_dup(heff_rfield(v_k_241, 6));
      V v_t_2496 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_at_n(v_ru_24ty_248_24SegmentUtf, TAG_IInt, 1, (V[]){MK_INT(0LL)}), heff_dup(v_sp_2495)});
      V v_t_2497 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2496}), v_sp_2495});
      V v_t_2498 = heff_intShow(heff_intAdd(heff_dup(v_i_243), MK_INT(1LL)));
      V v_t_2499 = heff_strAppend(heff_dup(heff_rfield(v_k_241, 0)), heff_strAppend(((V)&g_heff_2eelab_2eclauses_2esegTest_str5), v_t_2498));
      V v_x_24100 = (g_heff_2eelab_2eclauses_2efreshIn(heff_rfield(v_k_241, 4), heff_rfield(v_k_241, 5), v_t_2499));
      V v_sp_24101 = heff_dup(heff_rfield(v_k_241, 6));
      V v_t_24102 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IVar, 1, (V[]){v_x_24100}), heff_dup(v_sp_24101)});
      V v_t_24103 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_24102}), v_sp_24101});
      V v_t_24104 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24103, NTAG(TAG_Nil)});
      V v_args_24105 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2497, v_t_24104});
      V v_sp_24106 = heff_dup(heff_rfield(v_k_241, 6));
      V v_t_24107 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2eelab_2eclauses_2esegTest_str6)}), heff_dup(v_sp_24106)});
      V v_t_24108 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_24106), v_args_24105));
      V v_t_24109 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24107, v_t_24108}), v_sp_24106});
      V v_i_24110 = (g_heff_2eelab_2eclauses_2eutfRead(heff_dup(v_k_241), heff_dup(v_off_244), heff_dup(v_s_245), heff_dup(heff_rfield(v_s_245, 1))));
      V v_t_24113;
      switch (heff_tag_of(v_i_24110)) {
      case TAG_At: {
        V v_s_24112 = heff_dup(heff_field(v_i_24110, 1));
        v_t_24113 = v_s_24112;
        break;
      }
      default: heff_nomatch(v_i_24110);
      }
      V v_t_24114 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_i_24110}), v_t_24113});
      V v_args_24115 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24114, NTAG(TAG_Nil)});
      V v_sp_24116 = heff_dup(heff_rfield(v_k_241, 6));
      V v_t_24117 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2eelab_2eclauses_2esegTest_str7)}), heff_dup(v_sp_24116)});
      V v_t_24118 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_24116), v_args_24115));
      V v_t_24119 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24117, v_t_24118}), v_sp_24116});
      V v_t_24120 = heff_intShow(heff_intAdd(heff_dup(v_i_243), MK_INT(1LL)));
      V v_t_24121 = heff_strAppend(heff_dup(heff_rfield(v_k_241, 0)), heff_strAppend(((V)&g_heff_2eelab_2eclauses_2esegTest_str8), v_t_24120));
      V v_x_24122 = (g_heff_2eelab_2eclauses_2efreshIn(heff_rfield(v_k_241, 4), heff_rfield(v_k_241, 5), v_t_24121));
      V v_sp_24123 = heff_dup(heff_rfield(v_k_241, 6));
      V v_t_24124 = heff_intAdd(heff_take_field(v_off_244, 0), MK_INT(0LL));
      V v_t_24125 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IVar, 1, (V[]){v_x_24122}), heff_dup(v_sp_24123)});
      V v_t_24126 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_24125}), v_sp_24123});
      V v_t_24127 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24126, NTAG(TAG_Nil)});
      V v_t_24128 = (g_heff_2eelab_2eclauses_2eappendC(heff_get_n(v_off_244, 1, 2), v_t_24127));
      V v_t_24129 = heff_tr(heff_call(heff_get_n(v_t_240, 0, 1), 4, (V[]){v_env_242, heff_intAdd(v_i_243, MK_INT(1LL)), heff_rec_n(2, shape_bits__terms, (V[]){v_t_24124, v_t_24128}), v_rest_246}));
      V v_t_24130 = (g_heff_2eelab_2eclauses_2ecodeTest(heff_dup(v_k_241), v_t_24119, heff_get_n(v_s_245, 0, 5), v_t_24129));
      V v_body_24131 = (g_heff_2eelab_2eclauses_2eandC(v_t_24109, v_t_24130, heff_dup(heff_rfield(v_k_241, 6))));
      V v_sp_24132 = heff_get_n(v_k_241, 6, 7);
      V v_t_24133 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_PatVar, 1, (V[]){v_x_2493}), heff_dup(v_sp_24132)});
      V v_t_24136;
      switch (heff_tag_of(v_body_24131)) {
      case TAG_At: {
        V v_s_24135 = heff_dup(heff_field(v_body_24131, 1));
        v_t_24136 = v_s_24135;
        break;
      }
      default: heff_nomatch(v_body_24131);
      }
      V v_t_24137 = ({ V rv_0 = heff_dup(heff_rfield(v_sp_24132, 0)); V rr_ = heff_rec_reuse_nf(v_t_24136, 2ULL, 2, shape_start__end, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
      V v_t_24138 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_MkAlt, 2, (V[]){v_t_24133, v_body_24131}), v_t_24137});
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CLetIn, 2, (V[]){v_rhs_2494, v_t_24138}), v_sp_24132});
    }
  }
  default: return heff_nomatch(v_ty_248);
  }
}
V g_heff_2eelab_2eclauses_2esegTest_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2esegTest(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8]);
}
HEFF_LIT(g_heff_2eelab_2eclauses_2ebinTestOf_str0, 10, "bitsLength");
HEFF_LIT(g_heff_2eelab_2eclauses_2ebinTestOf_str1, 11, "bytesLength");
HEFF_LIT(g_heff_2eelab_2eclauses_2ebinTestOf_str2, 6, "intMul");
HEFF_LIT(g_heff_2eelab_2eclauses_2ebinTestOf_str3, 7, "bytesEq");
Clo g_heff_2eelab_2eclauses_2ebinTestOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2ebinTestOf_entry, 3, 0};

V g_heff_2eelab_2eclauses_2ebinTestOf(V v_k_240, V v_segs_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nothing: {
    V v_t_243 = heff_dup(heff_rfield(v_k_240, 1));
    V v_rhs_2428;
    if ((heff_dup(v_t_243) == NTAG(TAG_True))) {
      heff_drop(v_t_243);
      V v_sp_244 = heff_dup(heff_rfield(v_k_240, 6));
      V v_t_245 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2eelab_2eclauses_2ebinTestOf_str0)}), heff_dup(v_sp_244)});
      V v_sp_246 = heff_dup(heff_rfield(v_k_240, 6));
      V v_t_247 = heff_tag_n(TAG_IVar, 1, (V[]){heff_dup(heff_rfield(v_k_240, 0))});
      V v_t_248 = heff_tag_n(TAG_CInf, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_247, heff_dup(v_sp_246)})});
      V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_248, v_sp_246}), NTAG(TAG_Nil)});
      V v_t_2410 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_244), v_t_249));
      v_rhs_2428 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_245, v_t_2410}), v_sp_244});
    } else {
      heff_drop(v_t_243);
      V v_sp_2411 = heff_dup(heff_rfield(v_k_240, 6));
      V v_sp_2412 = heff_dup(heff_rfield(v_k_240, 6));
      V v_t_2413 = heff_tag_n(TAG_IVar, 1, (V[]){heff_dup(heff_rfield(v_k_240, 0))});
      V v_t_2414 = heff_tag_n(TAG_CInf, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2413, heff_dup(v_sp_2412)})});
      V v_t_2415 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2414, v_sp_2412}), NTAG(TAG_Nil)});
      V v_t_2416 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_2411), v_t_2415));
      V v_t_2417 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2eelab_2eclauses_2ebinTestOf_str1)}), heff_dup(v_sp_2411)});
      V v_t_2418 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2417, v_t_2416}), heff_dup(v_sp_2411)});
      V v_t_2419 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2418}), v_sp_2411});
      V v_sp_2420 = heff_dup(heff_rfield(v_k_240, 6));
      V v_t_2421 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IInt, 1, (V[]){MK_INT(8LL)}), heff_dup(v_sp_2420)});
      V v_t_2422 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2421}), v_sp_2420});
      V v_t_2423 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2422, NTAG(TAG_Nil)});
      V v_args_2424 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2419, v_t_2423});
      V v_sp_2425 = heff_dup(heff_rfield(v_k_240, 6));
      V v_t_2426 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2eelab_2eclauses_2ebinTestOf_str2)}), heff_dup(v_sp_2425)});
      V v_t_2427 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_2425), v_args_2424));
      v_rhs_2428 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2426, v_t_2427}), v_sp_2425});
    }
    V v_t_2429 = (g_heff_2eelab_2eclauses_2ebinTest(heff_dup(v_k_240)));
    V v_t_2430 = heff_rec_n(2, shape_bits__terms, (V[]){MK_INT(0LL), NTAG(TAG_Nil)});
    V v_body_2431 = heff_tr(heff_call(heff_get_n(v_t_2429, 0, 1), 4, (V[]){NTAG(TAG_Nil), MK_INT(0LL), v_t_2430, v_segs_241}));
    V v_sp_2432 = heff_take_field(v_k_240, 6);
    V v_t_2433 = heff_tag_n(TAG_PatVar, 1, (V[]){heff_get_n(v_k_240, 2, 7)});
    V v_t_2434 = heff_tag_n(TAG_MkAlt, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2433, heff_dup(v_sp_2432)}), heff_dup(v_body_2431)});
    V v_t_2437;
    switch (heff_tag_of(v_body_2431)) {
    case TAG_At: {
      V v_s_2436 = heff_field(v_body_2431, 1);
      heff_take_n(v_body_2431, 2ULL, 2);
      v_t_2437 = v_s_2436;
      break;
    }
    default: heff_nomatch(v_body_2431);
    }
    V v_t_2438 = ({ V rv_0 = heff_dup(heff_rfield(v_sp_2432, 0)); V rr_ = heff_rec_reuse_nf(v_t_2437, 2ULL, 2, shape_start__end, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
    V v_t_2439 = heff_tag_n(TAG_CLetIn, 2, (V[]){v_rhs_2428, heff_tag_n(TAG_At, 2, (V[]){v_t_2434, v_t_2438})});
    return heff_tag_n(TAG_At, 2, (V[]){v_t_2439, v_sp_2432});
  }
  case TAG_Just: {
    V v_b_2440 = heff_field(v_x3_242, 0);
    V v_ru_24x3_242_24Just = heff_take_reuse_n(v_x3_242, 1ULL, 1);
    heff_drop(v_segs_241);
    V v_sp_2441 = heff_dup(heff_rfield(v_k_240, 6));
    V v_sp_2442 = heff_dup(heff_rfield(v_k_240, 6));
    V v_t_2443 = heff_tag_at_n(v_ru_24x3_242_24Just, TAG_IVar, 1, (V[]){heff_dup(heff_rfield(v_k_240, 0))});
    V v_t_2444 = heff_tag_n(TAG_CInf, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2443, heff_dup(v_sp_2442)})});
    V v_t_2445 = heff_get_n(v_k_240, 6, 7);
    V v_t_2446 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IBytes, 1, (V[]){v_b_2440}), heff_dup(v_t_2445)});
    V v_t_2447 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2446}), v_t_2445});
    V v_t_2448 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2447, NTAG(TAG_Nil)});
    V v_t_2449 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2444, v_sp_2442}), v_t_2448});
    V v_t_2450 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_2441), v_t_2449));
    V v_t_2451 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2eelab_2eclauses_2ebinTestOf_str3)}), heff_dup(v_sp_2441)});
    V v_t_2452 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2451, v_t_2450}), heff_dup(v_sp_2441)});
    return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2452}), v_sp_2441});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2eelab_2eclauses_2ebinTestOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2ebinTestOf(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2eelab_2eclauses_2esegRead_str0, 9, "bitsSlice");
HEFF_LIT(g_heff_2eelab_2eclauses_2esegRead_str1, 9, "bitsBytes");
HEFF_LIT(g_heff_2eelab_2eclauses_2esegRead_str2, 11, "bytesLength");
HEFF_LIT(g_heff_2eelab_2eclauses_2esegRead_str3, 10, "bytesSlice");
HEFF_LIT(g_heff_2eelab_2eclauses_2esegRead_str4, 9, "bitsSlice");
HEFF_LIT(g_heff_2eelab_2eclauses_2esegRead_str5, 9, "bitsBytes");
HEFF_LIT(g_heff_2eelab_2eclauses_2esegRead_str6, 10, "bytesSlice");
HEFF_LIT(g_heff_2eelab_2eclauses_2esegRead_str7, 9, "bitsSlice");
HEFF_LIT(g_heff_2eelab_2eclauses_2esegRead_str8, 9, "bitsBytes");
HEFF_LIT(g_heff_2eelab_2eclauses_2esegRead_str9, 10, "bytesSlice");
HEFF_LIT(g_heff_2eelab_2eclauses_2esegRead_str10, 9, "bitsSlice");
HEFF_LIT(g_heff_2eelab_2eclauses_2esegRead_str11, 9, "bitsSlice");
HEFF_LIT(g_heff_2eelab_2eclauses_2esegRead_str12, 9, "bitsSlice");
Clo g_heff_2eelab_2eclauses_2esegRead_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2esegRead_entry, 6, 0};

V g_heff_2eelab_2eclauses_2esegRead(V v_k_240, V v_off_241, V v_w_242, V v_s_243, V v_x5_244, V v_size_245) {
top: ;
  switch (heff_tag_of(v_x5_244)) {
  case TAG_SegmentInteger: {
    heff_drop(v_size_245);
    return (g_heff_2eelab_2eclauses_2eintRead(v_k_240, v_off_241, v_w_242, heff_get_n(v_s_243, 3, 5)));
  }
  case TAG_SegmentBinary: {
    heff_drop_rec(v_s_243, 5);
    switch (heff_tag_of(v_size_245)) {
    case TAG_SizeDefault: {
      heff_drop_rec(v_w_242, 2);
      V v_t_246 = heff_dup(heff_rfield(v_k_240, 1));
      if ((heff_dup(v_t_246) == NTAG(TAG_True))) {
        heff_drop(v_t_246);
        V v_sp_247 = heff_dup(heff_rfield(v_k_240, 6));
        V v_t_248 = heff_tag_n(TAG_IVar, 1, (V[]){heff_dup(heff_rfield(v_k_240, 0))});
        V v_t_249 = heff_tag_n(TAG_CInf, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_248, heff_dup(v_sp_247)})});
        V v_t_2410 = (g_heff_2eelab_2eclauses_2eoffC(heff_dup(v_off_241), heff_dup(heff_rfield(v_k_240, 6))));
        V v_t_2411 = (g_heff_2eelab_2eclauses_2erestC(heff_dup(v_k_240), v_off_241));
        V v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2411, NTAG(TAG_Nil)});
        V v_args_2413 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_249, v_sp_247}), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2410, v_t_2412})});
        V v_sp_2414 = heff_dup(heff_rfield(v_k_240, 6));
        V v_t_2415 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_2414), v_args_2413));
        V v_t_2416 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2eelab_2eclauses_2esegRead_str0)}), heff_dup(v_sp_2414)});
        V v_t_2417 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2416, v_t_2415}), heff_dup(v_sp_2414)});
        V v_t_2418 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2417}), v_sp_2414});
        V v_args_2419 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2418, NTAG(TAG_Nil)});
        V v_sp_2420 = heff_get_n(v_k_240, 6, 7);
        V v_t_2421 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2eelab_2eclauses_2esegRead_str1)}), heff_dup(v_sp_2420)});
        V v_t_2422 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_2420), v_args_2419));
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2421, v_t_2422}), v_sp_2420});
      } else {
        heff_drop(v_t_246);
        V v_sp_2423 = heff_dup(heff_rfield(v_k_240, 6));
        V v_t_2424 = heff_tag_n(TAG_IVar, 1, (V[]){heff_dup(heff_rfield(v_k_240, 0))});
        V v_t_2425 = heff_tag_n(TAG_CInf, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2424, heff_dup(v_sp_2423)})});
        V v_t_2426 = (g_heff_2eelab_2eclauses_2eoffBytesC(v_off_241, heff_dup(heff_rfield(v_k_240, 6))));
        V v_sp_2427 = heff_dup(heff_rfield(v_k_240, 6));
        V v_sp_2428 = heff_dup(heff_rfield(v_k_240, 6));
        V v_t_2429 = heff_tag_n(TAG_IVar, 1, (V[]){heff_take_field(v_k_240, 0)});
        V v_t_2430 = heff_tag_n(TAG_CInf, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2429, heff_dup(v_sp_2428)})});
        V v_t_2431 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2430, v_sp_2428}), NTAG(TAG_Nil)});
        V v_t_2432 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_2427), v_t_2431));
        V v_t_2433 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2eelab_2eclauses_2esegRead_str2)}), heff_dup(v_sp_2427)});
        V v_t_2434 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2433, v_t_2432}), heff_dup(v_sp_2427)});
        V v_t_2435 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2434}), v_sp_2427});
        V v_t_2436 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2435, NTAG(TAG_Nil)});
        V v_args_2437 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2425, v_sp_2423}), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2426, v_t_2436})});
        V v_sp_2438 = heff_get_n(v_k_240, 6, 7);
        V v_t_2439 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2eelab_2eclauses_2esegRead_str3)}), heff_dup(v_sp_2438)});
        V v_t_2440 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_2438), v_args_2437));
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2439, v_t_2440}), v_sp_2438});
      }
    }
    case TAG_SizeNumber: {
      V v_ru_24size_245_24SizeNumber = heff_take_reuse_n(v_size_245, 0ULL, 1);
      V v_t_2442 = heff_take_field(v_k_240, 1);
      if ((heff_dup(v_t_2442) == NTAG(TAG_True))) {
        heff_drop(v_t_2442);
        V v_sp_2443 = heff_dup(heff_rfield(v_k_240, 6));
        V v_t_2444 = heff_tag_at_n(v_ru_24size_245_24SizeNumber, TAG_IVar, 1, (V[]){heff_dup(heff_rfield(v_k_240, 0))});
        V v_t_2445 = heff_tag_n(TAG_CInf, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2444, heff_dup(v_sp_2443)})});
        V v_t_2446 = (g_heff_2eelab_2eclauses_2eoffC(v_off_241, heff_dup(heff_rfield(v_k_240, 6))));
        V v_t_2447 = (g_heff_2eelab_2eclauses_2eoffC(v_w_242, heff_dup(heff_rfield(v_k_240, 6))));
        V v_t_2448 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2447, NTAG(TAG_Nil)});
        V v_args_2449 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2445, v_sp_2443}), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2446, v_t_2448})});
        V v_sp_2450 = heff_dup(heff_rfield(v_k_240, 6));
        V v_t_2451 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_2450), v_args_2449));
        V v_t_2452 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2eelab_2eclauses_2esegRead_str4)}), heff_dup(v_sp_2450)});
        V v_t_2453 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2452, v_t_2451}), heff_dup(v_sp_2450)});
        V v_t_2454 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2453}), v_sp_2450});
        V v_args_2455 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2454, NTAG(TAG_Nil)});
        V v_sp_2456 = heff_get_n(v_k_240, 6, 7);
        V v_t_2457 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2eelab_2eclauses_2esegRead_str5)}), heff_dup(v_sp_2456)});
        V v_t_2458 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_2456), v_args_2455));
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2457, v_t_2458}), v_sp_2456});
      } else {
        heff_drop(v_t_2442);
        V v_sp_2459 = heff_dup(heff_rfield(v_k_240, 6));
        V v_t_2460 = heff_tag_at_n(v_ru_24size_245_24SizeNumber, TAG_IVar, 1, (V[]){heff_dup(heff_rfield(v_k_240, 0))});
        V v_t_2461 = heff_tag_n(TAG_CInf, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2460, heff_dup(v_sp_2459)})});
        V v_t_2462 = (g_heff_2eelab_2eclauses_2eoffBytesC(heff_dup(v_off_241), heff_dup(heff_rfield(v_k_240, 6))));
        V v_t_2463 = heff_intAdd(heff_take_field(v_off_241, 0), heff_take_field(v_w_242, 0));
        V v_t_2464 = (g_heff_2eelab_2eclauses_2eappendC(heff_get_n(v_off_241, 1, 2), heff_get_n(v_w_242, 1, 2)));
        V v_t_2465 = (g_heff_2eelab_2eclauses_2eoffBytesC(heff_rec_n(2, shape_bits__terms, (V[]){v_t_2463, v_t_2464}), heff_dup(heff_rfield(v_k_240, 6))));
        V v_t_2466 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2465, NTAG(TAG_Nil)});
        V v_args_2467 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2461, v_sp_2459}), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2462, v_t_2466})});
        V v_sp_2468 = heff_get_n(v_k_240, 6, 7);
        V v_t_2469 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2eelab_2eclauses_2esegRead_str6)}), heff_dup(v_sp_2468)});
        V v_t_2470 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_2468), v_args_2467));
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2469, v_t_2470}), v_sp_2468});
      }
    }
    case TAG_SizeName: {
      heff_take_n(v_size_245, 0ULL, 3);
      V v_t_2474 = heff_take_field(v_k_240, 1);
      if ((heff_dup(v_t_2474) == NTAG(TAG_True))) {
        heff_drop(v_t_2474);
        V v_sp_2475 = heff_dup(heff_rfield(v_k_240, 6));
        V v_t_2476 = heff_tag_n(TAG_IVar, 1, (V[]){heff_take_field(v_k_240, 0)});
        V v_t_2477 = heff_tag_n(TAG_CInf, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2476, heff_dup(v_sp_2475)})});
        V v_t_2478 = (g_heff_2eelab_2eclauses_2eoffC(v_off_241, heff_dup(heff_rfield(v_k_240, 6))));
        V v_t_2479 = (g_heff_2eelab_2eclauses_2eoffC(v_w_242, heff_dup(heff_rfield(v_k_240, 6))));
        V v_t_2480 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2479, NTAG(TAG_Nil)});
        V v_args_2481 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2477, v_sp_2475}), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2478, v_t_2480})});
        V v_sp_2482 = heff_dup(heff_rfield(v_k_240, 6));
        V v_t_2483 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_2482), v_args_2481));
        V v_t_2484 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2eelab_2eclauses_2esegRead_str7)}), heff_dup(v_sp_2482)});
        V v_t_2485 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2484, v_t_2483}), heff_dup(v_sp_2482)});
        V v_t_2486 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_CInf, 1, (V[]){v_t_2485}), v_sp_2482});
        V v_args_2487 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2486, NTAG(TAG_Nil)});
        V v_sp_2488 = heff_get_n(v_k_240, 6, 7);
        V v_t_2489 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2eelab_2eclauses_2esegRead_str8)}), heff_dup(v_sp_2488)});
        V v_t_2490 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_2488), v_args_2487));
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_2489, v_t_2490}), v_sp_2488});
      } else {
        heff_drop(v_t_2474);
        V v_sp_2491 = heff_dup(heff_rfield(v_k_240, 6));
        V v_t_2492 = heff_tag_n(TAG_IVar, 1, (V[]){heff_take_field(v_k_240, 0)});
        V v_t_2493 = heff_tag_n(TAG_CInf, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2492, heff_dup(v_sp_2491)})});
        V v_t_2494 = (g_heff_2eelab_2eclauses_2eoffBytesC(heff_dup(v_off_241), heff_dup(heff_rfield(v_k_240, 6))));
        V v_t_2495 = heff_intAdd(heff_take_field(v_off_241, 0), heff_take_field(v_w_242, 0));
        V v_t_2496 = (g_heff_2eelab_2eclauses_2eappendC(heff_get_n(v_off_241, 1, 2), heff_get_n(v_w_242, 1, 2)));
        V v_t_2497 = (g_heff_2eelab_2eclauses_2eoffBytesC(heff_rec_n(2, shape_bits__terms, (V[]){v_t_2495, v_t_2496}), heff_dup(heff_rfield(v_k_240, 6))));
        V v_t_2498 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2497, NTAG(TAG_Nil)});
        V v_args_2499 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_2493, v_sp_2491}), heff_tag_n(TAG_Cons, 2, (V[]){v_t_2494, v_t_2498})});
        V v_sp_24100 = heff_get_n(v_k_240, 6, 7);
        V v_t_24101 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2eelab_2eclauses_2esegRead_str9)}), heff_dup(v_sp_24100)});
        V v_t_24102 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_24100), v_args_2499));
        return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24101, v_t_24102}), v_sp_24100});
      }
    }
    default: return heff_nomatch(v_size_245);
    }
  }
  case TAG_SegmentBits: {
    heff_drop_rec(v_s_243, 5);
    switch (heff_tag_of(v_size_245)) {
    case TAG_SizeDefault: {
      heff_drop_rec(v_w_242, 2);
      V v_sp_24103 = heff_dup(heff_rfield(v_k_240, 6));
      V v_t_24104 = heff_tag_n(TAG_IVar, 1, (V[]){heff_dup(heff_rfield(v_k_240, 0))});
      V v_t_24105 = heff_tag_n(TAG_CInf, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24104, heff_dup(v_sp_24103)})});
      V v_t_24106 = (g_heff_2eelab_2eclauses_2eoffC(heff_dup(v_off_241), heff_dup(heff_rfield(v_k_240, 6))));
      V v_t_24107 = (g_heff_2eelab_2eclauses_2erestC(heff_dup(v_k_240), v_off_241));
      V v_t_24108 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24107, NTAG(TAG_Nil)});
      V v_args_24109 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24105, v_sp_24103}), heff_tag_n(TAG_Cons, 2, (V[]){v_t_24106, v_t_24108})});
      V v_sp_24110 = heff_get_n(v_k_240, 6, 7);
      V v_t_24111 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2eelab_2eclauses_2esegRead_str10)}), heff_dup(v_sp_24110)});
      V v_t_24112 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_24110), v_args_24109));
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24111, v_t_24112}), v_sp_24110});
    }
    case TAG_SizeNumber: {
      V v_ru_24size_245_24SizeNumber = heff_take_reuse_n(v_size_245, 0ULL, 1);
      V v_sp_24114 = heff_dup(heff_rfield(v_k_240, 6));
      V v_t_24115 = heff_tag_at_n(v_ru_24size_245_24SizeNumber, TAG_IVar, 1, (V[]){heff_dup(heff_rfield(v_k_240, 0))});
      V v_t_24116 = heff_tag_n(TAG_CInf, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24115, heff_dup(v_sp_24114)})});
      V v_t_24117 = (g_heff_2eelab_2eclauses_2eoffC(v_off_241, heff_dup(heff_rfield(v_k_240, 6))));
      V v_t_24118 = (g_heff_2eelab_2eclauses_2eoffC(v_w_242, heff_dup(heff_rfield(v_k_240, 6))));
      V v_t_24119 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24118, NTAG(TAG_Nil)});
      V v_args_24120 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24116, v_sp_24114}), heff_tag_n(TAG_Cons, 2, (V[]){v_t_24117, v_t_24119})});
      V v_sp_24121 = heff_get_n(v_k_240, 6, 7);
      V v_t_24122 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2eelab_2eclauses_2esegRead_str11)}), heff_dup(v_sp_24121)});
      V v_t_24123 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_24121), v_args_24120));
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24122, v_t_24123}), v_sp_24121});
    }
    case TAG_SizeName: {
      heff_take_n(v_size_245, 0ULL, 3);
      V v_sp_24127 = heff_dup(heff_rfield(v_k_240, 6));
      V v_t_24128 = heff_tag_n(TAG_IVar, 1, (V[]){heff_take_field(v_k_240, 0)});
      V v_t_24129 = heff_tag_n(TAG_CInf, 1, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24128, heff_dup(v_sp_24127)})});
      V v_t_24130 = (g_heff_2eelab_2eclauses_2eoffC(v_off_241, heff_dup(heff_rfield(v_k_240, 6))));
      V v_t_24131 = (g_heff_2eelab_2eclauses_2eoffC(v_w_242, heff_dup(heff_rfield(v_k_240, 6))));
      V v_t_24132 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24131, NTAG(TAG_Nil)});
      V v_args_24133 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_At, 2, (V[]){v_t_24129, v_sp_24127}), heff_tag_n(TAG_Cons, 2, (V[]){v_t_24130, v_t_24132})});
      V v_sp_24134 = heff_get_n(v_k_240, 6, 7);
      V v_t_24135 = heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IPrim, 1, (V[]){((V)&g_heff_2eelab_2eclauses_2esegRead_str12)}), heff_dup(v_sp_24134)});
      V v_t_24136 = (g_list_2emap_24s1243189782x897571843(heff_dup(v_sp_24134), v_args_24133));
      return heff_tag_n(TAG_At, 2, (V[]){heff_tag_n(TAG_IApp, 2, (V[]){v_t_24135, v_t_24136}), v_sp_24134});
    }
    default: return heff_nomatch(v_size_245);
    }
  }
  case TAG_SegmentFloat: {
    heff_drop_rec(v_w_242, 2);
    V v_t_24141;
    switch (heff_tag_of(v_size_245)) {
    case TAG_SizeDefault: {
      v_t_24141 = MK_INT(64LL);
      break;
    }
    case TAG_SizeNumber: {
      V v_n_24137 = heff_field(v_size_245, 0);
      heff_take_n(v_size_245, 1ULL, 1);
      v_t_24141 = v_n_24137;
      break;
    }
    case TAG_SizeName: {
      heff_take_n(v_size_245, 0ULL, 3);
      v_t_24141 = MK_INT(64LL);
      break;
    }
    default: heff_nomatch(v_size_245);
    }
    return (g_heff_2eelab_2eclauses_2efloatRead(v_k_240, v_off_241, v_t_24141, heff_get_n(v_s_243, 3, 5)));
  }
  case TAG_SegmentUtf: {
    V v_n_24142 = heff_field(v_x5_244, 0);
    V v_ru_24x5_244_24SegmentUtf = heff_take_reuse_n(v_x5_244, 1ULL, 1);
    heff_drop_rec(v_w_242, 2);
    heff_drop(v_size_245);
    return (g_heff_2eelab_2eclauses_2eutfRead(v_k_240, v_off_241, v_s_243, heff_tag_at_n(v_ru_24x5_244_24SegmentUtf, TAG_SegmentUtf, 1, (V[]){v_n_24142})));
  }
  default: return heff_nomatch(v_x5_244);
  }
}
V g_heff_2eelab_2eclauses_2esegRead_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2esegRead(a[0], a[1], a[2], a[3], a[4], a[5]);
}
HEFF_LIT(g_heff_2eelab_2eclauses_2ecolPick_str0, 1, "x");
HEFF_LIT(g_heff_2eelab_2eclauses_2ecolPick_str1, 1, "_");
HEFF_LIT(g_heff_2eelab_2eclauses_2ecolPick_str2, 1, "x");
HEFF_LIT(g_heff_2eelab_2eclauses_2ecolPick_str3, 1, "x");
HEFF_LIT(g_heff_2eelab_2eclauses_2ecolPick_str4, 1, "x");
HEFF_LIT(g_heff_2eelab_2eclauses_2ecolPick_str5, 1, "x");
Clo g_heff_2eelab_2eclauses_2ecolPick_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2ecolPick_entry, 5, 0};

V g_heff_2eelab_2eclauses_2ecolPick(V v_used_240, V v_taken_241, V v_rows_242, V v_i_243, V v_xs_244) {
top: ;
  switch (heff_tag_of(v_xs_244)) {
  case TAG_Nil: {
    V v_t_245 = heff_intShow(heff_intAdd(v_i_243, MK_INT(1LL)));
    return (g_heff_2eelab_2eclauses_2efreshIn(v_used_240, v_taken_241, heff_strAppend(((V)&g_heff_2eelab_2eclauses_2ecolPick_str0), v_t_245)));
  }
  case TAG_Cons: {
    V v_x_246 = heff_field(v_xs_244, 0);
    V v_xs2_247 = heff_field(v_xs_244, 1);
    switch (heff_tag_of(v_xs2_247)) {
    case TAG_Nil: {
      if (heff_strEq_c_lent(v_x_246, ((V)&g_heff_2eelab_2eclauses_2ecolPick_str1), 2)) {
        V v_t_249 = heff_intShow(heff_intAdd(v_i_243, MK_INT(1LL)));
        return (g_heff_2eelab_2eclauses_2efreshIn(v_used_240, v_taken_241, heff_strAppend(((V)&g_heff_2eelab_2eclauses_2ecolPick_str2), v_t_249)));
      } else {
        V v_t_2410 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){heff_dup(v_x_246)}));
        V v_x1_2411 = (g_list_2eany(v_t_2410, v_taken_241));
        if ((heff_dup(v_x1_2411) == NTAG(TAG_True))) {
          heff_drop(v_x1_2411);
          V v_t_2412 = heff_intShow(heff_intAdd(v_i_243, MK_INT(1LL)));
          return (g_heff_2eelab_2eclauses_2efreshIn(v_used_240, v_taken_241, heff_strAppend(((V)&g_heff_2eelab_2eclauses_2ecolPick_str3), v_t_2412)));
        } else {
          heff_drop(v_x1_2411);
          V v_t_2413 = (g_heff_2eelab_2eclauses_2enameFits(heff_dup(v_x_246), heff_dup(v_i_243), v_rows_242));
          if ((heff_dup(v_t_2413) == NTAG(TAG_True))) {
            heff_drop(v_i_243);
            heff_drop(v_t_2413);
            return heff_dup(v_x_246);
          } else {
            heff_drop(v_t_2413);
            V v_t_2414 = heff_intShow(heff_intAdd(v_i_243, MK_INT(1LL)));
            return (g_heff_2eelab_2eclauses_2efreshIn(v_used_240, v_taken_241, heff_strAppend(((V)&g_heff_2eelab_2eclauses_2ecolPick_str4), v_t_2414)));
          }
        }
      }
    }
    case TAG_Cons: {
      V v_t_2417 = heff_intShow(heff_intAdd(v_i_243, MK_INT(1LL)));
      return (g_heff_2eelab_2eclauses_2efreshIn(v_used_240, v_taken_241, heff_strAppend(((V)&g_heff_2eelab_2eclauses_2ecolPick_str5), v_t_2417)));
    }
    default: return heff_nomatch(v_xs2_247);
    }
  }
  default: return heff_nomatch(v_xs_244);
  }
}
V g_heff_2eelab_2eclauses_2ecolPick_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V a4 = a[4]; V r = g_heff_2eelab_2eclauses_2ecolPick(a0, a1, a2, a[3], a4); heff_drop(a0); heff_drop(a1); heff_drop(a2); heff_drop(a4); return r;
}
HEFF_LIT(g_heff_2eelab_2eclauses_2ecompileAt_24s924891070x2102972655_24cpr_str0, 1, "_");
HEFF_LIT(g_heff_2eelab_2eclauses_2ecompileAt_24s924891070x2102972655_24cpr_str1, 1, "_");
HEFF_LIT(g_heff_2eelab_2eclauses_2ecompileAt_24s924891070x2102972655_24cpr_str2, 1, "_");
V g_heff_2eelab_2eclauses_2ecompileAt_24s924891070x2102972655_24cpr_lam0(V self, V *args);

HeffT2 g_heff_2eelab_2eclauses_2ecompileAt_24s924891070x2102972655_24cpr(V v_used_240, V v_bound_241, V v_sp_242, V v_vars_243, V v_rows_244, V v_c_245, V v_p_246) {
top: ;
  switch (heff_tag_of(v_p_246)) {
  case TAG_PVar: {
    HeffT2 v_t_248 = (g_heff_2eelab_2eclauses_2enthC_24cpr(heff_dup(v_vars_243), heff_dup(v_c_245)));
    V v_v_2413;
    {
      V v_field_2410 = v_t_248.f[1];
      int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
      if ((v_tag_249 == ((int64_t)0ULL))) {
        V v_v_2412 = v_field_2410;
        v_v_2413 = v_v_2412;
      } else {
        heff_drop(v_field_2410);
        v_v_2413 = ((V)&g_heff_2eelab_2eclauses_2ecompileAt_24s924891070x2102972655_24cpr_str0);
      }
    }
    V v_t_2414 = heff_rec_n(3, shape_arms__order__anys, (V[]){heff_dup(g_std_2emap_2eempty_get()), NTAG(TAG_Nil), NTAG(TAG_Nil)});
    V v_t_2415 = (g_heff_2eelab_2eclauses_2etagColGo(heff_dup(v_c_245), v_v_2413, v_t_2414, v_rows_244));
    HEFF_LAST return g_heff_2eelab_2eclauses_2etagsAt_24s2145414218x819308742_24cpr(v_used_240, v_bound_241, v_sp_242, v_vars_243, v_rows_244, v_c_245, v_t_2415);
  }
  case TAG_PTag: {
    HeffT2 v_t_2419 = (g_heff_2eelab_2eclauses_2enthC_24cpr(heff_dup(v_vars_243), heff_dup(v_c_245)));
    V v_v_2424;
    {
      V v_field_2421 = v_t_2419.f[1];
      int64_t v_tag_2420 = ((int64_t)v_t_2419.f[0]);
      if ((v_tag_2420 == ((int64_t)0ULL))) {
        V v_v_2423 = v_field_2421;
        v_v_2424 = v_v_2423;
      } else {
        heff_drop(v_field_2421);
        v_v_2424 = ((V)&g_heff_2eelab_2eclauses_2ecompileAt_24s924891070x2102972655_24cpr_str1);
      }
    }
    V v_t_2425 = heff_rec_n(3, shape_arms__order__anys, (V[]){heff_dup(g_std_2emap_2eempty_get()), NTAG(TAG_Nil), NTAG(TAG_Nil)});
    V v_t_2426 = (g_heff_2eelab_2eclauses_2etagColGo(heff_dup(v_c_245), v_v_2424, v_t_2425, v_rows_244));
    HEFF_LAST return g_heff_2eelab_2eclauses_2etagsAt_24s2145414218x819308742_24cpr(v_used_240, v_bound_241, v_sp_242, v_vars_243, v_rows_244, v_c_245, v_t_2426);
  }
  case TAG_PLit: {
    V v_l_2427 = heff_field(v_p_246, 0);
    HeffT2 v_t_2428 = (g_heff_2eelab_2eclauses_2enoRecMix_24cpr(heff_dup(v_rows_244), heff_dup(v_c_245)));
    {
      V v_field_2430 = v_t_2428.f[1];
      int64_t v_tag_2429 = ((int64_t)v_t_2428.f[0]);
      if ((v_tag_2429 == ((int64_t)0ULL))) {
        heff_drop(v_used_240);
        heff_drop(v_bound_241);
        heff_drop(v_sp_242);
        heff_drop(v_vars_243);
        heff_drop(v_rows_244);
        heff_drop(v_c_245);
        V v_e_2432 = v_field_2430;
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_e_2432}});
      } else {
        V v_x_2433 = v_field_2430;
        heff_drop(v_x_2433);
        return ({ V a_0 = v_used_240; V a_1 = v_bound_241; V a_2 = v_sp_242; V a_3 = v_vars_243; V a_4 = v_rows_244; V a_5 = v_c_245; V a_6 = heff_dup(v_l_2427); HeffT2 r_ = (g_heff_2eelab_2eclauses_2eliteralOf_24s1384803683x829952018_24cpr(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_rows_244); r_; });
      }
    }
  }
  case TAG_PRec: {
    V v_t_2454 = (g_heff_2eelab_2eclauses_2econcatMapC(heff_clo_n(g_heff_2eelab_2eclauses_2ecompileAt_24s924891070x2102972655_24cpr_lam0, 1, 1, (V[]){heff_dup(v_c_245)}), v_rows_244));
    V v_t_2455 = (g_heff_2eelab_2eclauses_2enubStr(v_t_2454));
    HEFF_LAST return g_heff_2eelab_2eclauses_2erecordNamed_24s570125606x1378596115_24cpr(v_used_240, v_bound_241, v_sp_242, v_vars_243, v_rows_244, v_c_245, v_t_2455);
  }
  case TAG_PAs: {
    HeffT2 v_t_2458 = (g_heff_2eelab_2eclauses_2enthC_24cpr(heff_dup(v_vars_243), heff_dup(v_c_245)));
    V v_v_2463;
    {
      V v_field_2460 = v_t_2458.f[1];
      int64_t v_tag_2459 = ((int64_t)v_t_2458.f[0]);
      if ((v_tag_2459 == ((int64_t)0ULL))) {
        V v_v_2462 = v_field_2460;
        v_v_2463 = v_v_2462;
      } else {
        heff_drop(v_field_2460);
        v_v_2463 = ((V)&g_heff_2eelab_2eclauses_2ecompileAt_24s924891070x2102972655_24cpr_str2);
      }
    }
    V v_t_2464 = heff_rec_n(3, shape_arms__order__anys, (V[]){heff_dup(g_std_2emap_2eempty_get()), NTAG(TAG_Nil), NTAG(TAG_Nil)});
    V v_t_2465 = (g_heff_2eelab_2eclauses_2etagColGo(heff_dup(v_c_245), v_v_2463, v_t_2464, v_rows_244));
    HEFF_LAST return g_heff_2eelab_2eclauses_2etagsAt_24s2145414218x819308742_24cpr(v_used_240, v_bound_241, v_sp_242, v_vars_243, v_rows_244, v_c_245, v_t_2465);
  }
  case TAG_PBin: {
    V v_segs_2466 = heff_field(v_p_246, 0);
    V v_bsp_2467 = heff_field(v_p_246, 1);
    return (g_heff_2eelab_2eclauses_2ebinaryOf_24s1676894398x132520022_24cpr(v_used_240, v_bound_241, v_sp_242, v_vars_243, v_rows_244, v_c_245, heff_dup(v_segs_2466), heff_dup(v_bsp_2467)));
  }
  default: return ((HeffT2){{heff_nomatch(v_p_246)}});
  }
}
V g_heff_2eelab_2eclauses_2ecompileAt_24s924891070x2102972655_24cpr_lam0(V self, V *args) {
  V v_row_2436 = args[0];
  V v_c_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2437 = (g_heff_2eelab_2eclauses_2enthC_24cpr(heff_get_n(v_row_2436, 0, 2), v_c_245));
  V v_t_2453;
  {
    V v_field_2439 = v_t_2437.f[1];
    int64_t v_tag_2438 = ((int64_t)v_t_2437.f[0]);
    if ((v_tag_2438 == ((int64_t)0ULL))) {
      V v_p_2441 = v_field_2439;
      switch (heff_tag_of(v_p_2441)) {
      case TAG_PVar: {
        heff_take_n(v_p_2441, 0ULL, 1);
        v_t_2453 = NTAG(TAG_Nil);
        break;
      }
      case TAG_PTag: {
        heff_take_n(v_p_2441, 0ULL, 3);
        v_t_2453 = NTAG(TAG_Nil);
        break;
      }
      case TAG_PLit: {
        heff_take_n(v_p_2441, 0ULL, 1);
        v_t_2453 = NTAG(TAG_Nil);
        break;
      }
      case TAG_PRec: {
        V v_fps_2447 = heff_field(v_p_2441, 0);
        heff_take_n(v_p_2441, 1ULL, 2);
        v_t_2453 = v_fps_2447;
        break;
      }
      case TAG_PAs: {
        heff_take_n(v_p_2441, 0ULL, 2);
        v_t_2453 = NTAG(TAG_Nil);
        break;
      }
      case TAG_PBin: {
        heff_take_n(v_p_2441, 0ULL, 2);
        v_t_2453 = NTAG(TAG_Nil);
        break;
      }
      default: heff_nomatch(v_p_2441);
      }
    } else {
      heff_drop(v_field_2439);
      v_t_2453 = NTAG(TAG_Nil);
    }
  }
  return (g_list_2emap_24s1415906091x1371825187(v_t_2453));
}
Clo g_heff_2eelab_2eclauses_2efoldr2_24s748482467x1603483005_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2efoldr2_24s748482467x1603483005_entry, 3, 0};

V g_heff_2eelab_2eclauses_2efoldr2_24s748482467x1603483005(V v_lit_240, V v_z_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop_rec(v_lit_240, 2);
    return v_z_241;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x3_242, 0);
    V v_xs_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24Cons = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_a_245 = (g_heff_2eelab_2eclauses_2efoldr2_24s748482467x1603483005(heff_dup(v_lit_240), v_z_241, v_xs_244));
    V v_t_248;
    switch (heff_tag_of(v_a_245)) {
    case TAG_At: {
      V v_a_247 = heff_dup(heff_field(v_a_245, 1));
      v_t_248 = v_a_247;
      break;
    }
    default: heff_nomatch(v_a_245);
    }
    V v_t_249 = ({ V rv_0 = heff_dup(heff_rfield(v_lit_240, 0)); V rr_ = heff_rec_reuse_nf(v_t_248, 2ULL, 2, shape_start__end, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
    return heff_tag_at_n(v_ru_24x3_242_24Cons, TAG_At, 2, (V[]){heff_tag_n(TAG_CLam, 3, (V[]){v_x_243, v_lit_240, v_a_245}), v_t_249});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2eelab_2eclauses_2efoldr2_24s748482467x1603483005_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2efoldr2_24s748482467x1603483005(a[0], a[1], a[2]);
}
Clo g_heff_2eelab_2eclauses_2eappendC_24f668644975x857714735_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2eappendC_24f668644975x857714735_entry, 2, 0};

V g_heff_2eelab_2eclauses_2eappendC_24f668644975x857714735(V v_ys_240, V v_x1_241) {
top: ;
  switch (heff_tag_of(v_x1_241)) {
  case TAG_PVar: {
    V v_x_242 = heff_field(v_x1_241, 0);
    heff_take_n(v_x1_241, 1ULL, 1);
    V v_t_243 = (g_heff_2eelab_2eclauses_2eappendC(NTAG(TAG_Nil), v_ys_240));
    return heff_tag_n(TAG_Cons, 2, (V[]){v_x_242, v_t_243});
  }
  case TAG_PTag: {
    V v_ps_245 = heff_field(v_x1_241, 1);
    heff_take_n(v_x1_241, 2ULL, 3);
    V v_t_247 = ({ V a_0 = v_ps_245; V r_ = (g_heff_2eelab_2eclauses_2econcatMapC_24s1253148850x1225196638(a_0)); heff_drop(v_ps_245); r_; });
    HEFF_LAST return g_heff_2eelab_2eclauses_2eappendC(v_t_247, v_ys_240);
  }
  case TAG_PLit: {
    heff_take_n(v_x1_241, 0ULL, 1);
    return v_ys_240;
  }
  case TAG_PRec: {
    V v_fps_249 = heff_field(v_x1_241, 0);
    heff_take_n(v_x1_241, 1ULL, 2);
    V v_t_2411 = ({ V a_0 = v_fps_249; V r_ = (g_heff_2eelab_2eclauses_2econcatMapC_24s357394064x1182638230(a_0)); heff_drop(v_fps_249); r_; });
    HEFF_LAST return g_heff_2eelab_2eclauses_2eappendC(v_t_2411, v_ys_240);
  }
  case TAG_PAs: {
    V v_x_2412 = heff_field(v_x1_241, 0);
    V v_p_2413 = heff_field(v_x1_241, 1);
    V v_ru_24x1_241_24PAs = heff_take_reuse_n(v_x1_241, 3ULL, 2);
    V v_cell_2414 = heff_tag_at_n(v_ru_24x1_241_24PAs, TAG_Cons, 2, (V[]){v_x_2412, heff_hole()});
    V v_u_2415 = (g_heff_2eelab_2eclauses_2eappendC_24f668644975x857714735_24dps(v_ys_240, v_p_2413, heff_dup(v_cell_2414)));
    heff_drop(v_u_2415);
    return v_cell_2414;
  }
  case TAG_PBin: {
    V v_segs_2416 = heff_field(v_x1_241, 0);
    heff_take_n(v_x1_241, 1ULL, 2);
    V v_t_2418 = (g_list_2emap_24s502656580x1955732096(heff_dup(v_segs_2416)));
    V v_t_2419 = (g_heff_2eelab_2eclauses_2ecatMaybesC(v_t_2418));
    V v_t_2420 = (g_list_2emap_24s939813003x1383013550(v_segs_2416));
    V v_t_2421 = (g_heff_2eelab_2eclauses_2ecatMaybesC(v_t_2420));
    V v_t_2422 = (g_heff_2eelab_2eclauses_2eappendC(v_t_2419, v_t_2421));
    HEFF_LAST return g_heff_2eelab_2eclauses_2eappendC(v_t_2422, v_ys_240);
  }
  default: return heff_nomatch(v_x1_241);
  }
}
V g_heff_2eelab_2eclauses_2eappendC_24f668644975x857714735_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2eappendC_24f668644975x857714735(a[0], a[1]);
}
Clo g_heff_2eelab_2eclauses_2eappendC_24f668644975x857714735_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eclauses_2eappendC_24f668644975x857714735_24dps_entry, 3, 0};

V g_heff_2eelab_2eclauses_2eappendC_24f668644975x857714735_24dps(V v_ys_240, V v_x1_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x1_241)) {
  case TAG_PVar: {
    V v_x_243 = heff_field(v_x1_241, 0);
    heff_take_n(v_x1_241, 1ULL, 1);
    V v_t_244 = (g_heff_2eelab_2eclauses_2eappendC(NTAG(TAG_Nil), v_ys_240));
    return heff_setField(v_d_242, MK_INT(1LL), heff_tag_n(TAG_Cons, 2, (V[]){v_x_243, v_t_244}));
  }
  case TAG_PTag: {
    V v_ps_246 = heff_field(v_x1_241, 1);
    heff_take_n(v_x1_241, 2ULL, 3);
    V v_t_248 = ({ V a_0 = v_ps_246; V r_ = (g_heff_2eelab_2eclauses_2econcatMapC_24s1253148850x1225196638(a_0)); heff_drop(v_ps_246); r_; });
    V v_t_249 = (g_heff_2eelab_2eclauses_2eappendC(v_t_248, v_ys_240));
    return heff_setField(v_d_242, MK_INT(1LL), v_t_249);
  }
  case TAG_PLit: {
    heff_take_n(v_x1_241, 0ULL, 1);
    return heff_setField(v_d_242, MK_INT(1LL), v_ys_240);
  }
  case TAG_PRec: {
    V v_fps_2411 = heff_field(v_x1_241, 0);
    heff_take_n(v_x1_241, 1ULL, 2);
    V v_t_2413 = ({ V a_0 = v_fps_2411; V r_ = (g_heff_2eelab_2eclauses_2econcatMapC_24s357394064x1182638230(a_0)); heff_drop(v_fps_2411); r_; });
    V v_t_2414 = (g_heff_2eelab_2eclauses_2eappendC(v_t_2413, v_ys_240));
    return heff_setField(v_d_242, MK_INT(1LL), v_t_2414);
  }
  case TAG_PAs: {
    V v_x_2415 = heff_field(v_x1_241, 0);
    V v_p_2416 = heff_field(v_x1_241, 1);
    V v_ru_24x1_241_24PAs = heff_take_reuse_n(v_x1_241, 3ULL, 2);
    V v_cell_2417 = heff_tag_at_n(v_ru_24x1_241_24PAs, TAG_Cons, 2, (V[]){v_x_2415, heff_hole()});
    V v_u_2418 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_2417));
    heff_drop(v_u_2418);
    V t_0 = v_ys_240;
    V t_1 = v_p_2416;
    V t_2 = v_cell_2417;
    v_ys_240 = t_0;
    v_x1_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  case TAG_PBin: {
    V v_segs_2419 = heff_field(v_x1_241, 0);
    heff_take_n(v_x1_241, 1ULL, 2);
    V v_t_2421 = (g_list_2emap_24s502656580x1955732096(heff_dup(v_segs_2419)));
    V v_t_2422 = (g_heff_2eelab_2eclauses_2ecatMaybesC(v_t_2421));
    V v_t_2423 = (g_list_2emap_24s939813003x1383013550(v_segs_2419));
    V v_t_2424 = (g_heff_2eelab_2eclauses_2ecatMaybesC(v_t_2423));
    V v_t_2425 = (g_heff_2eelab_2eclauses_2eappendC(v_t_2422, v_t_2424));
    V v_t_2426 = (g_heff_2eelab_2eclauses_2eappendC(v_t_2425, v_ys_240));
    return heff_setField(v_d_242, MK_INT(1LL), v_t_2426);
  }
  default: return heff_nomatch(v_x1_241);
  }
}
V g_heff_2eelab_2eclauses_2eappendC_24f668644975x857714735_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eclauses_2eappendC_24f668644975x857714735_24dps(a[0], a[1], a[2]);
}