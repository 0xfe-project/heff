// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Added 2732
#define TAG_Bin 14227
#define TAG_Removed 39854
#define TAG_Same 22203
#define TAG_Tip 31527
#define LBL_edits 297717699
#define LBL_x 338
static uint32_t shape_x__edits[] = {LBL_x, LBL_edits};
HeffT2 g_heff_2eutil_2ediff_2ediagonals_24cpr(V, V, V, V, V, V, V);
V g_heff_2eutil_2ediff_2ediffBy(V, V, V);
V g_heff_2eutil_2ediff_2ediffBy_entry(V self, V *a);
extern Clo g_heff_2eutil_2ediff_2ediffBy_clo;
V g_heff_2eutil_2ediff_2eisBlankCode(V);
V g_heff_2eutil_2ediff_2eisBlankCode_entry(V self, V *a);
extern Clo g_heff_2eutil_2ediff_2eisBlankCode_clo;
V g_heff_2eutil_2ediff_2eisWordCode(V);
V g_heff_2eutil_2ediff_2eisWordCode_entry(V self, V *a);
extern Clo g_heff_2eutil_2ediff_2eisWordCode_clo;
HeffT2 g_heff_2eutil_2ediff_2ejoinEdit_24cpr(V, V);
V g_heff_2eutil_2ediff_2ejoinRunsGo(V, V);
V g_heff_2eutil_2ediff_2ejoinRunsGo_entry(V self, V *a);
extern Clo g_heff_2eutil_2ediff_2ejoinRunsGo_clo;
V g_heff_2eutil_2ediff_2ejoinRunsGo_24dps(V, V, V);
V g_heff_2eutil_2ediff_2ejoinRunsGo_24dps_entry(V self, V *a);
extern Clo g_heff_2eutil_2ediff_2ejoinRunsGo_24dps_clo;
V g_heff_2eutil_2ediff_2erounds(V, V, V, V, V);
V g_heff_2eutil_2ediff_2erounds_entry(V self, V *a);
extern Clo g_heff_2eutil_2ediff_2erounds_clo;
V g_heff_2eutil_2ediff_2erunEnd_24s1582427139x2055052310(V, V);
V g_heff_2eutil_2ediff_2erunEnd_24s1582427139x2055052310_entry(V self, V *a);
extern Clo g_heff_2eutil_2ediff_2erunEnd_24s1582427139x2055052310_clo;
V g_heff_2eutil_2ediff_2erunEnd_24s1672156029x1681264085(V, V);
V g_heff_2eutil_2ediff_2erunEnd_24s1672156029x1681264085_entry(V self, V *a);
extern Clo g_heff_2eutil_2ediff_2erunEnd_24s1672156029x1681264085_clo;
V g_heff_2eutil_2ediff_2esnake(V, V, V, V, V, V);
V g_heff_2eutil_2ediff_2esnake_entry(V self, V *a);
extern Clo g_heff_2eutil_2ediff_2esnake_clo;
HeffT2 g_heff_2eutil_2ediff_2estepOnto_24cpr(V, V, V, V, V);
V g_heff_2eutil_2ediff_2etokenEnd(V, V);
V g_heff_2eutil_2ediff_2etokenEnd_entry(V self, V *a);
extern Clo g_heff_2eutil_2ediff_2etokenEnd_clo;
V g_heff_2eutil_2ediff_2ewordsFrom(V, V, V);
V g_heff_2eutil_2ediff_2ewordsFrom_entry(V self, V *a);
extern Clo g_heff_2eutil_2ediff_2ewordsFrom_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_std_2emap_2eempty_get(void);
V g_std_2emap_2einsert_24s170109517x1206653089(V, V, V);
V g_std_2emap_2einsert_24s170109517x1206653089_entry(V self, V *a);
extern Clo g_std_2emap_2einsert_24s170109517x1206653089_clo;
HeffT2 g_std_2emap_2elookup_24s1702756637x1169753568_24cpr(V, V);
Clo g_heff_2eutil_2ediff_2esnake_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eutil_2ediff_2esnake_entry, 6, 0};

V g_heff_2eutil_2ediff_2esnake(V v_eq_240, V v_xs_241, V v_ys_242, V v_x_243, V v_y_244, V v_acc_245) {
top: ;
  if ((heff_intLe_c_lent(MK_INT(0LL), v_x_243, 1) && heff_intLt_c(heff_dup(v_x_243), heff_arrayLength_lent(v_xs_241, 0)))) {
    V v_a_246 = heff_arrayIndex_lent(v_xs_241, v_x_243, 0);
    if ((heff_intLe_c_lent(MK_INT(0LL), v_y_244, 1) && heff_intLt_c(heff_dup(v_y_244), heff_arrayLength_lent(v_ys_242, 0)))) {
      V v_b_247 = heff_arrayIndex_lent(v_ys_242, v_y_244, 0);
      V v_t_248 = heff_tr(heff_call(heff_dup(v_eq_240), 2, (V[]){heff_dup(v_a_246), v_b_247}));
      if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
        heff_drop(v_t_248);
        V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_Same, 1, (V[]){v_a_246}), v_acc_245});
        V t_0 = v_eq_240;
        V t_1 = v_xs_241;
        V t_2 = v_ys_242;
        V t_3 = heff_box_word((heff_unbox_word(v_x_243) + ((int64_t)1ULL)));
        V t_4 = heff_box_word((heff_unbox_word(v_y_244) + ((int64_t)1ULL)));
        V t_5 = v_t_249;
        v_eq_240 = t_0;
        v_xs_241 = t_1;
        v_ys_242 = t_2;
        v_x_243 = t_3;
        v_y_244 = t_4;
        v_acc_245 = t_5;
        goto top;
      } else {
        heff_drop(v_eq_240);
        heff_drop(v_y_244);
        heff_drop(v_a_246);
        heff_drop(v_t_248);
        return heff_rec_n(2, shape_x__edits, (V[]){v_x_243, v_acc_245});
      }
    } else {
      heff_drop(v_eq_240);
      heff_drop(v_y_244);
      heff_drop(v_a_246);
      return heff_rec_n(2, shape_x__edits, (V[]){v_x_243, v_acc_245});
    }
  } else {
    heff_drop(v_eq_240);
    heff_drop(v_y_244);
    return heff_rec_n(2, shape_x__edits, (V[]){v_x_243, v_acc_245});
  }
}
V g_heff_2eutil_2ediff_2esnake_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a2 = a[2]; V r = g_heff_2eutil_2ediff_2esnake(a[0], a1, a2, a[3], a[4], a[5]); heff_drop(a1); heff_drop(a2); return r;
}

HeffT2 g_heff_2eutil_2ediff_2estepOnto_24cpr(V v_eq_240, V v_xs_241, V v_ys_242, V v_k_243, V v_v_244) {
top: ;
  HeffT2 v_t_245 = (g_std_2emap_2elookup_24s1702756637x1169753568_24cpr(v_v_244, heff_intAdd(heff_dup(v_k_243), MK_INT(1LL))));
  {
    V v_field_247 = v_t_245.f[1];
    int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
    HeffT2 v_t_248 = (g_std_2emap_2elookup_24s1702756637x1169753568_24cpr(v_v_244, heff_intSub(heff_dup(v_k_243), MK_INT(1LL))));
    {
      V v_field_2410 = v_t_248.f[1];
      int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
      V v_canAdd_2413;
      if ((v_tag_246 == ((int64_t)0ULL))) {
        V v_p_2411 = heff_dup(v_field_247);
        V v_t_2412 = heff_intSub(heff_get_n(v_p_2411, 0, 2), heff_intAdd(heff_dup(v_k_243), MK_INT(1LL)));
        v_canAdd_2413 = heff_bool(heff_intLt_c(heff_dup(v_t_2412), heff_arrayLength_lent(v_ys_242, 0)));
        heff_drop(v_t_2412);
      } else {
        v_canAdd_2413 = NTAG(TAG_False);
      }
      if ((v_tag_249 == ((int64_t)0ULL))) {
        V v_p_2414 = heff_dup(v_field_2410);
        V v_canRemove_2415 = heff_bool(heff_intLt_c(heff_dup(heff_rfield(v_p_2414, 0)), heff_arrayLength_lent(v_xs_241, 0)));
        heff_drop_rec(v_p_2414, 2);
        if (((heff_dup(v_canAdd_2413) == NTAG(TAG_True)) ? 0 : !(heff_dup(v_canRemove_2415) == NTAG(TAG_True)))) {
          heff_drop(v_eq_240);
          heff_drop(v_k_243);
          heff_drop(v_field_247);
          heff_drop(v_field_2410);
          heff_drop(v_canAdd_2413);
          heff_drop(v_canRemove_2415);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        } else {
          V v_t_2442;
          if ((heff_dup(v_canRemove_2415) == NTAG(TAG_True))) {
            heff_drop(v_canRemove_2415);
            if ((heff_dup(v_canAdd_2413) == NTAG(TAG_True))) {
              heff_drop(v_canAdd_2413);
              V v_t_2449;
              if ((v_tag_249 == ((int64_t)0ULL))) {
                V v_p_2416 = heff_dup(v_field_2410);
                v_t_2449 = heff_get_n(v_p_2416, 0, 2);
              } else {
                v_t_2449 = MK_INT(-1LL);
              }
              V v_t_2450;
              if ((v_tag_246 == ((int64_t)0ULL))) {
                V v_p_2417 = heff_dup(v_field_247);
                v_t_2450 = heff_get_n(v_p_2417, 0, 2);
              } else {
                v_t_2450 = MK_INT(-1LL);
              }
              v_t_2442 = heff_intLt(v_t_2449, v_t_2450);
            } else {
              heff_drop(v_canAdd_2413);
              v_t_2442 = NTAG(TAG_False);
            }
          } else {
            heff_drop(v_canAdd_2413);
            heff_drop(v_canRemove_2415);
            v_t_2442 = NTAG(TAG_True);
          }
          switch (heff_tag_of(v_t_2442)) {
          case TAG_True: {
            heff_drop(v_field_2410);
            if ((v_tag_246 == ((int64_t)0ULL))) {
              V v_p_2418 = v_field_247;
              V v_x_2419 = heff_take_field(v_p_2418, 0);
              V v_edits_2420 = heff_get_n(v_p_2418, 1, 2);
              V v_i_2421 = heff_intSub(heff_dup(v_x_2419), heff_intAdd(heff_dup(v_k_243), MK_INT(1LL)));
              if ((heff_intLe_c_lent(MK_INT(0LL), v_i_2421, 1) && heff_intLt_c(heff_dup(v_i_2421), heff_arrayLength_lent(v_ys_242, 0)))) {
                V v_y_2422 = heff_arrayIndex_lent(v_ys_242, v_i_2421, 2);
                V v_t_2423 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_Added, 1, (V[]){v_y_2422}), v_edits_2420});
                V v_f_2424 = (g_heff_2eutil_2ediff_2esnake(v_eq_240, v_xs_241, v_ys_242, heff_dup(v_x_2419), heff_intSub(v_x_2419, v_k_243), v_t_2423));
                return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2424}});
              } else {
                heff_drop(v_eq_240);
                heff_drop(v_k_243);
                heff_drop(v_x_2419);
                heff_drop(v_edits_2420);
                heff_drop(v_i_2421);
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
              }
            } else {
              heff_drop(v_eq_240);
              heff_drop(v_k_243);
              heff_drop(v_field_247);
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
            }
          }
          case TAG_False: {
            heff_drop(v_field_247);
            if ((v_tag_249 == ((int64_t)0ULL))) {
              V v_p_2425 = v_field_2410;
              V v_x_2426 = heff_take_field(v_p_2425, 0);
              V v_edits_2427 = heff_get_n(v_p_2425, 1, 2);
              V v_i_2428 = heff_dup(v_x_2426);
              if ((heff_intLe_c_lent(MK_INT(0LL), v_i_2428, 1) && heff_intLt_c(heff_dup(v_i_2428), heff_arrayLength_lent(v_xs_241, 0)))) {
                V v_x_2429 = heff_arrayIndex_lent(v_xs_241, v_i_2428, 2);
                V v_t_2430 = heff_intSub(heff_intAdd(heff_dup(v_x_2426), MK_INT(1LL)), v_k_243);
                V v_t_2431 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_Removed, 1, (V[]){v_x_2429}), v_edits_2427});
                V v_f_2432 = (g_heff_2eutil_2ediff_2esnake(v_eq_240, v_xs_241, v_ys_242, heff_intAdd(v_x_2426, MK_INT(1LL)), v_t_2430, v_t_2431));
                return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2432}});
              } else {
                heff_drop(v_eq_240);
                heff_drop(v_k_243);
                heff_drop(v_x_2426);
                heff_drop(v_edits_2427);
                heff_drop(v_i_2428);
                return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
              }
            } else {
              heff_drop(v_eq_240);
              heff_drop(v_k_243);
              heff_drop(v_field_2410);
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
            }
          }
          default: return ((HeffT2){{heff_nomatch(v_t_2442)}});
          }
        }
      } else {
        heff_drop(v_field_2410);
        if (!(heff_dup(v_canAdd_2413) == NTAG(TAG_True))) {
          heff_drop(v_eq_240);
          heff_drop(v_k_243);
          heff_drop(v_field_247);
          heff_drop(v_canAdd_2413);
          return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
        } else {
          heff_drop(v_canAdd_2413);
          if ((v_tag_246 == ((int64_t)0ULL))) {
            V v_p_2433 = v_field_247;
            V v_x_2434 = heff_take_field(v_p_2433, 0);
            V v_edits_2435 = heff_get_n(v_p_2433, 1, 2);
            V v_i_2436 = heff_intSub(heff_dup(v_x_2434), heff_intAdd(heff_dup(v_k_243), MK_INT(1LL)));
            if ((heff_intLe_c_lent(MK_INT(0LL), v_i_2436, 1) && heff_intLt_c(heff_dup(v_i_2436), heff_arrayLength_lent(v_ys_242, 0)))) {
              V v_y_2437 = heff_arrayIndex_lent(v_ys_242, v_i_2436, 2);
              V v_t_2438 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_Added, 1, (V[]){v_y_2437}), v_edits_2435});
              V v_f_2439 = (g_heff_2eutil_2ediff_2esnake(v_eq_240, v_xs_241, v_ys_242, heff_dup(v_x_2434), heff_intSub(v_x_2434, v_k_243), v_t_2438));
              return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2439}});
            } else {
              heff_drop(v_eq_240);
              heff_drop(v_k_243);
              heff_drop(v_x_2434);
              heff_drop(v_edits_2435);
              heff_drop(v_i_2436);
              return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
            }
          } else {
            heff_drop(v_eq_240);
            heff_drop(v_k_243);
            heff_drop(v_field_247);
            return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
          }
        }
      }
    }
  }
}

HeffT2 g_heff_2eutil_2ediff_2ediagonals_24cpr(V v_eq_240, V v_xs_241, V v_ys_242, V v_d_243, V v_k_244, V v_v_245, V v_acc_246) {
top: ;
  if (heff_intLt_c_lent(v_d_243, v_k_244, 0)) {
    heff_drop(v_eq_240);
    heff_drop(v_d_243);
    heff_drop(v_k_244);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), v_acc_246}});
  } else {
    HeffT2 v_t_247 = (g_heff_2eutil_2ediff_2estepOnto_24cpr(heff_dup(v_eq_240), v_xs_241, v_ys_242, heff_dup(v_k_244), v_v_245));
    {
      V v_field_249 = v_t_247.f[1];
      int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
      if ((v_tag_248 == ((int64_t)0ULL))) {
        V v_p_2410 = v_field_249;
        if ((heff_intLe_c(heff_arrayLength_lent(v_xs_241, 0), heff_dup(heff_rfield(v_p_2410, 0))) && heff_intLe_c(heff_arrayLength_lent(v_ys_242, 0), heff_intSub(heff_dup(heff_rfield(v_p_2410, 0)), heff_dup(v_k_244))))) {
          heff_drop(v_eq_240);
          heff_drop(v_d_243);
          heff_drop(v_k_244);
          heff_drop(v_acc_246);
          V v_f_2411 = heff_get_n(v_p_2410, 1, 2);
          return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2411}});
        } else {
          V v_t_2412 = (g_std_2emap_2einsert_24s170109517x1206653089(v_acc_246, heff_dup(v_k_244), v_p_2410));
          V t_0 = v_eq_240;
          V t_1 = v_xs_241;
          V t_2 = v_ys_242;
          V t_3 = v_d_243;
          V t_4 = heff_intAdd(v_k_244, MK_INT(2LL));
          V t_5 = v_v_245;
          V t_6 = v_t_2412;
          v_eq_240 = t_0;
          v_xs_241 = t_1;
          v_ys_242 = t_2;
          v_d_243 = t_3;
          v_k_244 = t_4;
          v_v_245 = t_5;
          v_acc_246 = t_6;
          goto top;
        }
      } else {
        heff_drop(v_field_249);
        V t_0 = v_eq_240;
        V t_1 = v_xs_241;
        V t_2 = v_ys_242;
        V t_3 = v_d_243;
        V t_4 = heff_intAdd(v_k_244, MK_INT(2LL));
        V t_5 = v_v_245;
        V t_6 = v_acc_246;
        v_eq_240 = t_0;
        v_xs_241 = t_1;
        v_ys_242 = t_2;
        v_d_243 = t_3;
        v_k_244 = t_4;
        v_v_245 = t_5;
        v_acc_246 = t_6;
        goto top;
      }
    }
  }
}
Clo g_heff_2eutil_2ediff_2erounds_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eutil_2ediff_2erounds_entry, 5, 0};

V g_heff_2eutil_2ediff_2erounds(V v_eq_240, V v_xs_241, V v_ys_242, V v_d_243, V v_v_244) {
top: ;
  HeffT2 v_t_245 = ({ V a_0 = heff_dup(v_eq_240); V a_1 = v_xs_241; V a_2 = v_ys_242; V a_3 = heff_dup(v_d_243); V a_4 = heff_intSub(MK_INT(0LL), heff_dup(v_d_243)); V a_5 = v_v_244; V a_6 = heff_dup(g_std_2emap_2eempty_get()); HeffT2 r_ = (g_heff_2eutil_2ediff_2ediagonals_24cpr(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_v_244); r_; });
  {
    V v_field_247 = v_t_245.f[1];
    int64_t v_tag_246 = ((int64_t)v_t_245.f[0]);
    if ((v_tag_246 == ((int64_t)0ULL))) {
      heff_drop(v_eq_240);
      heff_drop(v_d_243);
      V v_edits_248 = v_field_247;
      return (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_edits_248));
    } else {
      V v_v_27_249 = v_field_247;
      V t_0 = v_eq_240;
      V t_1 = v_xs_241;
      V t_2 = v_ys_242;
      V t_3 = heff_intAdd(v_d_243, MK_INT(1LL));
      V t_4 = v_v_27_249;
      v_eq_240 = t_0;
      v_xs_241 = t_1;
      v_ys_242 = t_2;
      v_d_243 = t_3;
      v_v_244 = t_4;
      goto top;
    }
  }
}
V g_heff_2eutil_2ediff_2erounds_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a2 = a[2]; V r = g_heff_2eutil_2ediff_2erounds(a[0], a1, a2, a[3], a[4]); heff_drop(a1); heff_drop(a2); return r;
}
Clo g_heff_2eutil_2ediff_2ediffBy_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eutil_2ediff_2ediffBy_entry, 3, 0};

V g_heff_2eutil_2ediff_2ediffBy(V v_eq_240, V v_args_241, V v_bs_242) {
top: ;
  V v_xs_243 = heff_arrayFromList(v_args_241);
  V v_ys_244 = heff_arrayFromList(v_bs_242);
  V v_start_245 = (g_heff_2eutil_2ediff_2esnake(heff_dup(v_eq_240), v_xs_243, v_ys_244, MK_INT(0LL), MK_INT(0LL), NTAG(TAG_Nil)));
  if ((heff_intLe_c(heff_arrayLength_lent(v_xs_243, 0), heff_dup(heff_rfield(v_start_245, 0))) && heff_intLe_c(heff_arrayLength_lent(v_ys_244, 0), heff_intSub(heff_dup(heff_rfield(v_start_245, 0)), MK_INT(0LL))))) {
    heff_drop(v_eq_240);
    heff_drop(v_xs_243);
    heff_drop(v_ys_244);
    return (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_get_n(v_start_245, 1, 2)));
  } else {
    V v_t_246 = heff_tag_n(TAG_Bin, 5, (V[]){MK_INT(1LL), MK_INT(0LL), v_start_245, NTAG(TAG_Tip), NTAG(TAG_Tip)});
    return ({ V a_0 = v_eq_240; V a_1 = v_xs_243; V a_2 = v_ys_244; V a_3 = MK_INT(1LL); V a_4 = v_t_246; V r_ = (g_heff_2eutil_2ediff_2erounds(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_xs_243); heff_drop(v_ys_244); r_; });
  }
}
V g_heff_2eutil_2ediff_2ediffBy_entry(V self, V *a) {
  (void)self;
  return g_heff_2eutil_2ediff_2ediffBy(a[0], a[1], a[2]);
}
Clo g_heff_2eutil_2ediff_2eisWordCode_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eutil_2ediff_2eisWordCode_entry, 1, 0};

V g_heff_2eutil_2ediff_2eisWordCode(V v_box_24c_240) {
  int64_t v_c_240 = heff_unbox_word(v_box_24c_240);
top: ;
  V v_ret_24bool = heff_bool((((((int64_t)97ULL) <= v_c_240) && (v_c_240 <= ((int64_t)122ULL))) || (((((int64_t)65ULL) <= v_c_240) && (v_c_240 <= ((int64_t)90ULL))) || (((((int64_t)48ULL) <= v_c_240) && (v_c_240 <= ((int64_t)57ULL))) || ((v_c_240 == ((int64_t)95ULL)) || ((v_c_240 == ((int64_t)173ULL)) || (((((int64_t)192ULL) <= v_c_240) && (v_c_240 <= ((int64_t)214ULL))) || (((((int64_t)216ULL) <= v_c_240) && (v_c_240 <= ((int64_t)246ULL))) || (((((int64_t)248ULL) <= v_c_240) && (v_c_240 <= ((int64_t)710ULL))) || (((((int64_t)712ULL) <= v_c_240) && heff_intLe_c(heff_box_word(v_c_240), MK_INT(727LL))) || (((((int64_t)734ULL) <= v_c_240) && heff_intLe_c(heff_box_word(v_c_240), MK_INT(767LL))) || ((((int64_t)7680ULL) <= v_c_240) && heff_intLe_c(heff_box_word(v_c_240), MK_INT(7935LL))))))))))))));
  return v_ret_24bool;
}
V g_heff_2eutil_2ediff_2eisWordCode_entry(V self, V *a) {
  (void)self;
  return g_heff_2eutil_2ediff_2eisWordCode(a[0]);
}
Clo g_heff_2eutil_2ediff_2eisBlankCode_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eutil_2ediff_2eisBlankCode_entry, 1, 0};

V g_heff_2eutil_2ediff_2eisBlankCode(V v_box_24c_240) {
  int64_t v_c_240 = heff_unbox_word(v_box_24c_240);
top: ;
  V v_ret_24bool = heff_bool(((v_c_240 == ((int64_t)32ULL)) || ((v_c_240 == ((int64_t)9ULL)) || ((v_c_240 == ((int64_t)11ULL)) || ((v_c_240 == ((int64_t)12ULL)) || ((v_c_240 == ((int64_t)160ULL)) || ((v_c_240 == ((int64_t)5760ULL)) || (((((int64_t)8192ULL) <= v_c_240) && heff_intLe_c(heff_box_word(v_c_240), MK_INT(8202LL))) || ((v_c_240 == ((int64_t)8232ULL)) || ((v_c_240 == ((int64_t)8233ULL)) || ((v_c_240 == ((int64_t)8239ULL)) || ((v_c_240 == ((int64_t)8287ULL)) || ((v_c_240 == ((int64_t)12288ULL)) || (v_c_240 == ((int64_t)65279ULL)))))))))))))));
  return v_ret_24bool;
}
V g_heff_2eutil_2ediff_2eisBlankCode_entry(V self, V *a) {
  (void)self;
  return g_heff_2eutil_2ediff_2eisBlankCode(a[0]);
}
Clo g_heff_2eutil_2ediff_2erunEnd_24s1672156029x1681264085_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eutil_2ediff_2erunEnd_24s1672156029x1681264085_entry, 2, 0};

V g_heff_2eutil_2ediff_2erunEnd_24s1672156029x1681264085(V v_s_240, V v_i_241) {
top: ;
  if (heff_intLt_c(heff_dup(v_i_241), heff_strLength_lent(v_s_240, 0))) {
    V v_t_242 = (g_heff_2eutil_2ediff_2eisWordCode(heff_strByteAt_lent(v_s_240, v_i_241, 0)));
    if ((heff_dup(v_t_242) == NTAG(TAG_True))) {
      heff_drop(v_t_242);
      V t_0 = v_s_240;
      V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
      v_s_240 = t_0;
      v_i_241 = t_1;
      goto top;
    } else {
      heff_drop(v_t_242);
      return v_i_241;
    }
  } else {
    return v_i_241;
  }
}
V g_heff_2eutil_2ediff_2erunEnd_24s1672156029x1681264085_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eutil_2ediff_2erunEnd_24s1672156029x1681264085(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2eutil_2ediff_2erunEnd_24s1582427139x2055052310_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eutil_2ediff_2erunEnd_24s1582427139x2055052310_entry, 2, 0};

V g_heff_2eutil_2ediff_2erunEnd_24s1582427139x2055052310(V v_s_240, V v_i_241) {
top: ;
  if (heff_intLt_c(heff_dup(v_i_241), heff_strLength_lent(v_s_240, 0))) {
    V v_t_242 = (g_heff_2eutil_2ediff_2eisBlankCode(heff_strByteAt_lent(v_s_240, v_i_241, 0)));
    if ((heff_dup(v_t_242) == NTAG(TAG_True))) {
      heff_drop(v_t_242);
      V t_0 = v_s_240;
      V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
      v_s_240 = t_0;
      v_i_241 = t_1;
      goto top;
    } else {
      heff_drop(v_t_242);
      return v_i_241;
    }
  } else {
    return v_i_241;
  }
}
V g_heff_2eutil_2ediff_2erunEnd_24s1582427139x2055052310_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eutil_2ediff_2erunEnd_24s1582427139x2055052310(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2eutil_2ediff_2etokenEnd_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eutil_2ediff_2etokenEnd_entry, 2, 0};

V g_heff_2eutil_2ediff_2etokenEnd(V v_s_240, V v_i_241) {
top: ;
  if ((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_i_241, 0)) == ((int64_t)10ULL))) {
    return heff_intAdd(v_i_241, MK_INT(1LL));
  } else {
    if (((heff_unbox_word(heff_strByteAt_lent(v_s_240, v_i_241, 0)) == ((int64_t)13ULL)) && (heff_intLt_c(heff_intAdd(heff_dup(v_i_241), MK_INT(1LL)), heff_strLength_lent(v_s_240, 0)) && (heff_unbox_word(heff_strByteAt(heff_dup(v_s_240), heff_intAdd(heff_dup(v_i_241), MK_INT(1LL)))) == ((int64_t)10ULL))))) {
      return heff_intAdd(v_i_241, MK_INT(2LL));
    } else {
      V v_t_242 = (g_heff_2eutil_2ediff_2eisWordCode(heff_strByteAt_lent(v_s_240, v_i_241, 0)));
      if ((heff_dup(v_t_242) == NTAG(TAG_True))) {
        heff_drop(v_t_242);
        HEFF_LAST return g_heff_2eutil_2ediff_2erunEnd_24s1672156029x1681264085(v_s_240, v_i_241);
      } else {
        heff_drop(v_t_242);
        V v_t_243 = (g_heff_2eutil_2ediff_2eisBlankCode(heff_strByteAt_lent(v_s_240, v_i_241, 0)));
        if ((heff_dup(v_t_243) == NTAG(TAG_True))) {
          heff_drop(v_t_243);
          HEFF_LAST return g_heff_2eutil_2ediff_2erunEnd_24s1582427139x2055052310(v_s_240, v_i_241);
        } else {
          heff_drop(v_t_243);
          return heff_intAdd(v_i_241, MK_INT(1LL));
        }
      }
    }
  }
}
V g_heff_2eutil_2ediff_2etokenEnd_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eutil_2ediff_2etokenEnd(a0, a[1]); heff_drop(a0); return r;
}
Clo g_heff_2eutil_2ediff_2ewordsFrom_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eutil_2ediff_2ewordsFrom_entry, 3, 0};

V g_heff_2eutil_2ediff_2ewordsFrom(V v_s_240, V v_i_241, V v_acc_242) {
top: ;
  if (heff_intLe_c(heff_strLength_lent(v_s_240, 0), heff_dup(v_i_241))) {
    heff_drop(v_i_241);
    return (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_242));
  } else {
    V v_t_243 = (g_heff_2eutil_2ediff_2etokenEnd(v_s_240, heff_dup(v_i_241)));
    V v_t_244 = (g_heff_2eutil_2ediff_2etokenEnd(v_s_240, heff_dup(v_i_241)));
    V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strSlice_lent(v_s_240, v_i_241, v_t_244, 6), v_acc_242});
    V t_0 = v_s_240;
    V t_1 = v_t_243;
    V t_2 = v_t_245;
    v_s_240 = t_0;
    v_i_241 = t_1;
    v_acc_242 = t_2;
    goto top;
  }
}
V g_heff_2eutil_2ediff_2ewordsFrom_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eutil_2ediff_2ewordsFrom(a0, a[1], a[2]); heff_drop(a0); return r;
}

HeffT2 g_heff_2eutil_2ediff_2ejoinEdit_24cpr(V v_x1_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Same: {
    V v_a_242 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24Same = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Same: {
      V v_b_243 = heff_field(v_x2_241, 0);
      heff_take_n(v_x2_241, 1ULL, 1);
      V v_f_244 = heff_tag_at_n(v_ru_24x1_240_24Same, TAG_Same, 1, (V[]){heff_strAppend(v_a_242, v_b_243)});
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_244}});
    }
    case TAG_Removed: {
      heff_take_n(v_x2_241, 0ULL, 1);
      heff_drop(v_a_242);
      heff_drop_cell(v_ru_24x1_240_24Same, 1);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_Added: {
      heff_take_n(v_x2_241, 0ULL, 1);
      heff_drop(v_a_242);
      heff_drop_cell(v_ru_24x1_240_24Same, 1);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
    }
  }
  case TAG_Removed: {
    V v_a_247 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24Removed = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Same: {
      heff_take_n(v_x2_241, 0ULL, 1);
      heff_drop(v_a_247);
      heff_drop_cell(v_ru_24x1_240_24Removed, 1);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_Removed: {
      V v_b_249 = heff_field(v_x2_241, 0);
      heff_take_n(v_x2_241, 1ULL, 1);
      V v_f_2410 = heff_tag_at_n(v_ru_24x1_240_24Removed, TAG_Removed, 1, (V[]){heff_strAppend(v_a_247, v_b_249)});
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2410}});
    }
    case TAG_Added: {
      heff_take_n(v_x2_241, 0ULL, 1);
      heff_drop(v_a_247);
      heff_drop_cell(v_ru_24x1_240_24Removed, 1);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
    }
  }
  case TAG_Added: {
    V v_a_2412 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24Added = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Same: {
      heff_take_n(v_x2_241, 0ULL, 1);
      heff_drop(v_a_2412);
      heff_drop_cell(v_ru_24x1_240_24Added, 1);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_Removed: {
      heff_take_n(v_x2_241, 0ULL, 1);
      heff_drop(v_a_2412);
      heff_drop_cell(v_ru_24x1_240_24Added, 1);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_Added: {
      V v_b_2415 = heff_field(v_x2_241, 0);
      heff_take_n(v_x2_241, 1ULL, 1);
      V v_f_2416 = heff_tag_at_n(v_ru_24x1_240_24Added, TAG_Added, 1, (V[]){heff_strAppend(v_a_2412, v_b_2415)});
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2416}});
    }
    default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
Clo g_heff_2eutil_2ediff_2ejoinRunsGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eutil_2ediff_2ejoinRunsGo_entry, 2, 0};

V g_heff_2eutil_2ediff_2ejoinRunsGo(V v_e_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return heff_tag_n(TAG_Cons, 2, (V[]){v_e_240, NTAG(TAG_Nil)});
  }
  case TAG_Cons: {
    V v_f_242 = heff_field(v_x2_241, 0);
    V v_rest_243 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    HeffT2 v_t_244 = (g_heff_2eutil_2ediff_2ejoinEdit_24cpr(heff_dup(v_e_240), heff_dup(v_f_242)));
    {
      V v_field_246 = v_t_244.f[1];
      int64_t v_tag_245 = ((int64_t)v_t_244.f[0]);
      if ((v_tag_245 == ((int64_t)0ULL))) {
        heff_drop(v_e_240);
        heff_drop(v_f_242);
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        V v_g_247 = v_field_246;
        V t_0 = v_g_247;
        V t_1 = v_rest_243;
        v_e_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      } else {
        heff_drop(v_field_246);
        V v_cell_248 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_e_240, heff_hole()});
        V v_u_249 = (g_heff_2eutil_2ediff_2ejoinRunsGo_24dps(v_f_242, v_rest_243, heff_dup(v_cell_248)));
        heff_drop(v_u_249);
        return v_cell_248;
      }
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eutil_2ediff_2ejoinRunsGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2eutil_2ediff_2ejoinRunsGo(a[0], a[1]);
}
Clo g_heff_2eutil_2ediff_2ejoinRunsGo_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eutil_2ediff_2ejoinRunsGo_24dps_entry, 3, 0};

V g_heff_2eutil_2ediff_2ejoinRunsGo_24dps(V v_e_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    V v_t_243 = heff_tag_n(TAG_Cons, 2, (V[]){v_e_240, NTAG(TAG_Nil)});
    return heff_setField(v_d_242, MK_INT(1LL), v_t_243);
  }
  case TAG_Cons: {
    V v_f_244 = heff_field(v_x2_241, 0);
    V v_rest_245 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    HeffT2 v_t_246 = (g_heff_2eutil_2ediff_2ejoinEdit_24cpr(heff_dup(v_e_240), heff_dup(v_f_244)));
    {
      V v_field_248 = v_t_246.f[1];
      int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
      if ((v_tag_247 == ((int64_t)0ULL))) {
        heff_drop(v_e_240);
        heff_drop(v_f_244);
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        V v_g_249 = v_field_248;
        V t_0 = v_g_249;
        V t_1 = v_rest_245;
        V t_2 = v_d_242;
        v_e_240 = t_0;
        v_x2_241 = t_1;
        v_d_242 = t_2;
        goto top;
      } else {
        heff_drop(v_field_248);
        V v_cell_2410 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_e_240, heff_hole()});
        V v_u_2411 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_2410));
        heff_drop(v_u_2411);
        V t_0 = v_f_244;
        V t_1 = v_rest_245;
        V t_2 = v_cell_2410;
        v_e_240 = t_0;
        v_x2_241 = t_1;
        v_d_242 = t_2;
        goto top;
      }
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eutil_2ediff_2ejoinRunsGo_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2eutil_2ediff_2ejoinRunsGo_24dps(a[0], a[1], a[2]);
}