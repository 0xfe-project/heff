// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_AbsConst 8406
#define TAG_Enter_24heff_2eelab_2erename_2eglobalsTermF_24s304344999x537615372 12157
#define TAG_Enter_24heff_2eelab_2erename_2eglobalsTypeF_24s916342050x850586824 10659
#define TAG_MkAbs 54862
#define TAG_SAbandon 23437
#define TAG_SApp 57081
#define TAG_SCode 58360
#define TAG_SCons 58684
#define TAG_SDecode 30927
#define TAG_SFix 61677
#define TAG_SFixed 29756
#define TAG_SFunction 64505
#define TAG_SGlobal 8650
#define TAG_SImplicit 59448
#define TAG_SIs 29577
#define TAG_SIsTy 43896
#define TAG_SLam 1658
#define TAG_SLitBytes 43891
#define TAG_SLitFixed 54374
#define TAG_SLitFloat 3938
#define TAG_SLitFloat32 41499
#define TAG_SLitInt 21439
#define TAG_SLitRune 21707
#define TAG_SLitString 62718
#define TAG_SLocal 28569
#define TAG_SMatch 27203
#define TAG_SMetaApp 2372
#define TAG_SOpaque 44226
#define TAG_SPrim 55533
#define TAG_SPrimArray 2913
#define TAG_SPrimFloat 48642
#define TAG_SPrimInt 22031
#define TAG_SPrimRune 40059
#define TAG_SPrimString 6970
#define TAG_SProj 55716
#define TAG_SRec 7538
#define TAG_SRecord 16932
#define TAG_SSpecialize 52996
#define TAG_SSum 9006
#define TAG_STag 9340
#define TAG_SU 9427
#define LBL_byName 571997869
#define LBL_el 9998
#define LBL_keys 9783995
#define LBL_ty 10476
#define LBL_values 1123329101
static uint32_t shape_el__ty[] = {LBL_el, LBL_ty};
static uint32_t shape_keys__byName__values[] = {LBL_keys, LBL_byName, LBL_values};
V g_heff_2eelab_2erename_2edescribeKey(V);
V g_heff_2eelab_2erename_2edescribeKey_entry(V self, V *a);
extern Clo g_heff_2eelab_2erename_2edescribeKey_clo;
HeffT2 g_heff_2eelab_2erename_2efirstAliasOf_24cpr(V, V);
V g_heff_2eelab_2erename_2eglobalsTermF_24s304344999x537615372(V);
V g_heff_2eelab_2erename_2eglobalsTermF_24s304344999x537615372_entry(V self, V *a);
extern Clo g_heff_2eelab_2erename_2eglobalsTermF_24s304344999x537615372_clo;
V g_heff_2eelab_2erename_2eglobalsTypeF_24s916342050x850586824(V);
V g_heff_2eelab_2erename_2eglobalsTypeF_24s916342050x850586824_entry(V self, V *a);
extern Clo g_heff_2eelab_2erename_2eglobalsTypeF_24s916342050x850586824_clo;
V g_heff_2eelab_2erename_2eglobalsTypeF_24s916342050x850586824_24cycle(V, V, V);
V g_heff_2eelab_2erename_2eglobalsTypeF_24s916342050x850586824_24cycle_entry(V self, V *a);
extern Clo g_heff_2eelab_2erename_2eglobalsTypeF_24s916342050x850586824_24cycle_clo;
V g_heff_2eelab_2erename_2enubFirst(V);
V g_heff_2eelab_2erename_2enubFirst_entry(V self, V *a);
extern Clo g_heff_2eelab_2erename_2enubFirst_clo;
V g_heff_2eelab_2erename_2enubFirst_24dps(V, V);
V g_heff_2eelab_2erename_2enubFirst_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2erename_2enubFirst_24dps_clo;
V g_heff_2eelab_2erename_2erenameTermF(V, V, V);
V g_heff_2eelab_2erename_2erenameTermF_entry(V self, V *a);
extern Clo g_heff_2eelab_2erename_2erenameTermF_clo;
V g_heff_2eelab_2erename_2erenameTermF_24generate0(V, V, V, V);
V g_heff_2eelab_2erename_2erenameTermF_24generate0_entry(V self, V *a);
extern Clo g_heff_2eelab_2erename_2erenameTermF_24generate0_clo;
V g_heff_2eelab_2erename_2erenameTermF_24generate1(V, V, V, V);
V g_heff_2eelab_2erename_2erenameTermF_24generate1_entry(V self, V *a);
extern Clo g_heff_2eelab_2erename_2erenameTermF_24generate1_clo;
V g_heff_2eelab_2erename_2erenameTermF_24map0(V, V, V);
V g_heff_2eelab_2erename_2erenameTermF_24map0_entry(V self, V *a);
extern Clo g_heff_2eelab_2erename_2erenameTermF_24map0_clo;
V g_heff_2eelab_2erename_2erenameTermF_24map1(V, V, V);
V g_heff_2eelab_2erename_2erenameTermF_24map1_entry(V self, V *a);
extern Clo g_heff_2eelab_2erename_2erenameTermF_24map1_clo;
V g_heff_2eelab_2erename_2erenameTypeF(V, V, V);
V g_heff_2eelab_2erename_2erenameTypeF_entry(V self, V *a);
extern Clo g_heff_2eelab_2erename_2erenameTypeF_clo;
V g_heff_2eelab_2erename_2erenameTypeF_24generate0(V, V, V, V);
V g_heff_2eelab_2erename_2erenameTypeF_24generate0_entry(V self, V *a);
extern Clo g_heff_2eelab_2erename_2erenameTypeF_24generate0_clo;
V g_heff_2eelab_2erename_2erenameTypeF_24generate1(V, V, V, V);
V g_heff_2eelab_2erename_2erenameTypeF_24generate1_entry(V self, V *a);
extern Clo g_heff_2eelab_2erename_2erenameTypeF_24generate1_clo;
V g_heff_2eelab_2erename_2erenameTypeF_24generate2(V, V, V, V);
V g_heff_2eelab_2erename_2erenameTypeF_24generate2_entry(V self, V *a);
extern Clo g_heff_2eelab_2erename_2erenameTypeF_24generate2_clo;
V g_heff_2eelab_2erename_2erenameTypeF_24generate3(V, V, V, V);
V g_heff_2eelab_2erename_2erenameTypeF_24generate3_entry(V self, V *a);
extern Clo g_heff_2eelab_2erename_2erenameTypeF_24generate3_clo;
V g_heff_2eelab_2erename_2erenameTypeF_24map0(V, V, V);
V g_heff_2eelab_2erename_2erenameTypeF_24map0_entry(V self, V *a);
extern Clo g_heff_2eelab_2erename_2erenameTypeF_24map0_clo;
V g_heff_2eelab_2erename_2erenameTypeF_24map1(V, V, V);
V g_heff_2eelab_2erename_2erenameTypeF_24map1_entry(V self, V *a);
extern Clo g_heff_2eelab_2erename_2erenameTypeF_24map1_clo;
V g_heff_2eelab_2erename_2erenameTypeF_24map2(V, V, V);
V g_heff_2eelab_2erename_2erenameTypeF_24map2_entry(V self, V *a);
extern Clo g_heff_2eelab_2erename_2erenameTypeF_24map2_clo;
V g_heff_2eelab_2erename_2erenameTypeF_24map3(V, V, V);
V g_heff_2eelab_2erename_2erenameTypeF_24map3_entry(V self, V *a);
extern Clo g_heff_2eelab_2erename_2erenameTypeF_24map3_clo;
V g_heff_2eelab_2erename_2erkOf(V);
V g_heff_2eelab_2erename_2erkOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2erename_2erkOf_clo;
HeffT2 g_heff_2eelab_2erename_2erkOf_24cpr(V);
V g_list_2efoldl_24f1625738412x188935108(V, V, V);
V g_list_2efoldl_24f1625738412x188935108_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1625738412x188935108_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1606891938x229778616(V, V);
V g_list_2efoldl_24s1606891938x229778616_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1606891938x229778616_clo;
V g_list_2efoldl_24s522807745x1556762248(V, V);
V g_list_2efoldl_24s522807745x1556762248_entry(V self, V *a);
extern Clo g_list_2efoldl_24s522807745x1556762248_clo;
V g_list_2efoldl_24s797527640x986490519(V, V);
V g_list_2efoldl_24s797527640x986490519_entry(V self, V *a);
extern Clo g_list_2efoldl_24s797527640x986490519_clo;
V g_list_2efoldl_24s865198748x12535471(V, V);
V g_list_2efoldl_24s865198748x12535471_entry(V self, V *a);
extern Clo g_list_2efoldl_24s865198748x12535471_clo;
V g_list_2efoldl_24s978059622x523571930(V, V);
V g_list_2efoldl_24s978059622x523571930_entry(V self, V *a);
extern Clo g_list_2efoldl_24s978059622x523571930_clo;
V g_list_2ekeepIf_24s930188071x496633547(V, V);
V g_list_2ekeepIf_24s930188071x496633547_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s930188071x496633547_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
HEFF_LIT(g_heff_2eelab_2erename_2erenameTermF_str0, 12, "builtin.Lazy");
HEFF_LIT(g_heff_2eelab_2erename_2erenameTermF_str1, 12, "prelude.Pair");
V g_heff_2eelab_2erename_2erenameTermF_lam0(V self, V *args); static Clo g_heff_2eelab_2erename_2erenameTermF_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erename_2erenameTermF_lam0, 1, 0};
V g_heff_2eelab_2erename_2erenameTermF_lam1(V self, V *args);
V g_heff_2eelab_2erename_2erenameTermF_lam2(V self, V *args); static Clo g_heff_2eelab_2erename_2erenameTermF_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erename_2erenameTermF_lam2, 1, 0};
Clo g_heff_2eelab_2erename_2erenameTermF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erename_2erenameTermF_entry, 3, 0};

V g_heff_2eelab_2erename_2erenameTermF(V v_k_240, V v_r_241, V v_e_242) {
top: ;
  switch (heff_tag_of(v_e_242)) {
  case TAG_SLocal: {
    heff_drop_rec(v_k_240, 2);
    heff_drop(v_r_241);
    return v_e_242;
  }
  case TAG_SGlobal: {
    V v_x_244 = heff_field(v_e_242, 0);
    V v_ru_24e_242_24SGlobal = heff_take_reuse_n(v_e_242, 1ULL, 1);
    heff_drop_rec(v_k_240, 2);
    V v_t_245 = heff_tr(heff_call(v_r_241, 1, (V[]){v_x_244}));
    return heff_tag_at_n(v_ru_24e_242_24SGlobal, TAG_SGlobal, 1, (V[]){v_t_245});
  }
  case TAG_SCode: {
    V v_t_246 = heff_field(v_e_242, 0);
    V v_ru_24e_242_24SCode = heff_take_reuse_n(v_e_242, 1ULL, 1);
    heff_drop(v_r_241);
    V v_t_247 = heff_tr(heff_call(heff_get_n(v_k_240, 1, 2), 1, (V[]){v_t_246}));
    return heff_tag_at_n(v_ru_24e_242_24SCode, TAG_SCode, 1, (V[]){v_t_247});
  }
  case TAG_SApp: {
    V v_f_248 = heff_field(v_e_242, 0);
    V v_a_249 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24SApp = heff_take_reuse_n(v_e_242, 3ULL, 2);
    V v_k_2410 = v_k_240;
    V v_r_2411 = v_r_241;
    V v_f_2412 = v_f_248;
    V v_a_2413 = v_a_249;
    switch (heff_tag_of(v_f_2412)) {
    case TAG_SGlobal: {
      V v_x_2414 = heff_field(v_f_2412, 0);
      V v_ru_24f_2412_24SGlobal = heff_take_reuse_n(v_f_2412, 1ULL, 1);
      V v_t_2415;
      if (heff_strEq_c_lent(v_x_2414, ((V)&g_heff_2eelab_2erename_2erenameTermF_str0), 2)) {
        heff_drop(v_r_2411);
        v_t_2415 = v_x_2414;
      } else {
        v_t_2415 = heff_tr(heff_call(v_r_2411, 1, (V[]){v_x_2414}));
      }
      V v_t_2416 = heff_tr(heff_call(heff_get_n(v_k_2410, 0, 2), 1, (V[]){v_a_2413}));
      return heff_tag_at_n(v_ru_24e_242_24SApp, TAG_SApp, 2, (V[]){heff_tag_at_n(v_ru_24f_2412_24SGlobal, TAG_SGlobal, 1, (V[]){v_t_2415}), v_t_2416});
    }
    case TAG_SApp: {
      V v_f1_2417 = heff_dup(heff_field(v_f_2412, 0));
      heff_drop(v_r_2411);
      switch (heff_tag_of(v_f1_2417)) {
      case TAG_SGlobal: {
        V v_x_2419 = heff_field(v_f1_2417, 0);
        V v_ru_24f1_2417_24SGlobal = heff_take_reuse_n(v_f1_2417, 1ULL, 1);
        switch (heff_tag_of(v_f_2412)) {
        case TAG_SApp: {
          V v_a1_2421 = heff_field(v_f_2412, 1);
          V v_ru_24f_2412_24SApp = heff_take_reuse_n(v_f_2412, 2ULL, 2);
          if (heff_strEq_c_lent(v_x_2419, ((V)&g_heff_2eelab_2erename_2erenameTermF_str1), 2)) {
            V v_t_2422 = heff_tr(heff_call(heff_dup(heff_rfield(v_k_2410, 0)), 1, (V[]){v_a1_2421}));
            V v_t_2423 = heff_tr(heff_call(heff_get_n(v_k_2410, 0, 2), 1, (V[]){v_a_2413}));
            V v_t_2424 = heff_tag_at_n(v_ru_24e_242_24SApp, TAG_SApp, 2, (V[]){heff_tag_re_n(v_ru_24f1_2417_24SGlobal, TAG_SGlobal, 1, 1ULL, (V[]){v_x_2419}), v_t_2422});
            return heff_tag_at_n(v_ru_24f_2412_24SApp, TAG_SApp, 2, (V[]){v_t_2424, v_t_2423});
          } else {
            V v_t_2425 = heff_tag_at_n(v_ru_24e_242_24SApp, TAG_SApp, 2, (V[]){heff_tag_re_n(v_ru_24f1_2417_24SGlobal, TAG_SGlobal, 1, 1ULL, (V[]){v_x_2419}), v_a1_2421});
            V v_t_2426 = heff_tr(heff_call(heff_dup(heff_rfield(v_k_2410, 0)), 1, (V[]){v_t_2425}));
            V v_t_2427 = heff_tr(heff_call(heff_get_n(v_k_2410, 0, 2), 1, (V[]){v_a_2413}));
            return heff_tag_at_n(v_ru_24f_2412_24SApp, TAG_SApp, 2, (V[]){v_t_2426, v_t_2427});
          }
        }
        default: return heff_nomatch(v_f_2412);
        }
      }
      default: {
        heff_drop(v_f1_2417);
        V v_t_2428 = heff_tr(heff_call(heff_dup(heff_rfield(v_k_2410, 0)), 1, (V[]){v_f_2412}));
        V v_t_2429 = heff_tr(heff_call(heff_get_n(v_k_2410, 0, 2), 1, (V[]){v_a_2413}));
        return heff_tag_at_n(v_ru_24e_242_24SApp, TAG_SApp, 2, (V[]){v_t_2428, v_t_2429});
      }
      }
    }
    default: {
      heff_drop(v_r_2411);
      V v_t_2430 = heff_tr(heff_call(heff_dup(heff_rfield(v_k_2410, 0)), 1, (V[]){v_f_2412}));
      V v_t_2431 = heff_tr(heff_call(heff_get_n(v_k_2410, 0, 2), 1, (V[]){v_a_2413}));
      return heff_tag_at_n(v_ru_24e_242_24SApp, TAG_SApp, 2, (V[]){v_t_2430, v_t_2431});
    }
    }
  }
  case TAG_SLam: {
    V v_d_2432 = heff_field(v_e_242, 0);
    V v_b_2433 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24SLam = heff_take_reuse_n(v_e_242, 3ULL, 2);
    heff_drop(v_r_241);
    V v_t_2434 = heff_tr(heff_call(heff_take_field(v_k_240, 1), 1, (V[]){v_d_2432}));
    V v_t_2440;
    switch (heff_tag_of(v_b_2433)) {
    case TAG_MkAbs: {
      V v_x_2435 = heff_field(v_b_2433, 0);
      V v_t_2436 = heff_field(v_b_2433, 1);
      V v_ru_24b_2433_24MkAbs = heff_take_reuse_n(v_b_2433, 3ULL, 2);
      V v_t_2437 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 2), 1, (V[]){v_t_2436}));
      v_t_2440 = heff_tag_re_n(v_ru_24b_2433_24MkAbs, TAG_MkAbs, 2, 1ULL, (V[]){v_x_2435, v_t_2437});
      break;
    }
    case TAG_AbsConst: {
      V v_t_2438 = heff_field(v_b_2433, 0);
      V v_ru_24b_2433_24AbsConst = heff_take_reuse_n(v_b_2433, 1ULL, 1);
      V v_t_2439 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 2), 1, (V[]){v_t_2438}));
      v_t_2440 = heff_tag_at_n(v_ru_24b_2433_24AbsConst, TAG_AbsConst, 1, (V[]){v_t_2439});
      break;
    }
    default: heff_nomatch(v_b_2433);
    }
    return heff_tag_at_n(v_ru_24e_242_24SLam, TAG_SLam, 2, (V[]){v_t_2434, v_t_2440});
  }
  case TAG_SCons: {
    V v_d_2441 = heff_field(v_e_242, 0);
    V v_ru_24e_242_24SCons = heff_take_reuse_n(v_e_242, 1ULL, 1);
    heff_drop(v_r_241);
    V v_xs_2442 = heff_take_field(v_d_2441, 2);
    V v_m_2443 = heff_arrayLength_lent(v_xs_2442, 0);
    V v_t_2448;
    if ((heff_peek_word(v_m_2443) <= ((int64_t)0ULL))) {
      heff_drop_rec(v_k_240, 2);
      heff_drop(v_xs_2442);
      v_t_2448 = heff_arrayGenerate(v_m_2443, ((V)&g_heff_2eelab_2erename_2erenameTermF_lam0_clo));
    } else {
      V v_e2_2445 = heff_arrayIndex_lent(v_xs_2442, MK_INT(0LL), 2);
      V v_y_2446 = heff_tr(heff_call(heff_dup(heff_rfield(v_k_240, 0)), 1, (V[]){v_e2_2445}));
      V v_t_2447 = heff_arrayKeepsAs_lent(v_xs_2442, v_y_2446, 0);
      if ((heff_dup(v_t_2447) == NTAG(TAG_True))) {
        heff_drop(v_m_2443);
        heff_drop(v_t_2447);
        v_t_2448 = ({ V a_0 = v_k_240; V a_1 = MK_INT(1LL); V a_2 = heff_arraySet(v_xs_2442, MK_INT(0LL), v_y_2446); V r_ = (g_heff_2eelab_2erename_2erenameTermF_24map0(a_0, a_1, a_2)); heff_drop_rec(v_k_240, 2); r_; });
      } else {
        heff_drop(v_t_2447);
        v_t_2448 = ({ V a_0 = v_xs_2442; V a_1 = v_k_240; V a_2 = MK_INT(1LL); V a_3 = heff_arrayReplicate(v_m_2443, v_y_2446); V r_ = (g_heff_2eelab_2erename_2erenameTermF_24generate0(a_0, a_1, a_2, a_3)); heff_drop(v_xs_2442); heff_drop_rec(v_k_240, 2); r_; });
      }
    }
    V v_t_2449 = ({ V rv_2 = v_t_2448; V rr_ = heff_rec_reuse_nf(v_d_2441, 3ULL, 3, shape_keys__byName__values, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    return heff_tag_at_n(v_ru_24e_242_24SCons, TAG_SCons, 1, (V[]){v_t_2449});
  }
  case TAG_SProj: {
    V v_e2_2450 = heff_field(v_e_242, 0);
    V v_l_2451 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24SProj = heff_take_reuse_n(v_e_242, 3ULL, 2);
    heff_drop(v_r_241);
    V v_t_2452 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 2), 1, (V[]){v_e2_2450}));
    return heff_tag_re_n(v_ru_24e_242_24SProj, TAG_SProj, 2, 2ULL, (V[]){v_t_2452, v_l_2451});
  }
  case TAG_STag: {
    V v_t_2453 = heff_field(v_e_242, 0);
    V v_args_2454 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24STag = heff_take_reuse_n(v_e_242, 3ULL, 2);
    heff_drop(v_r_241);
    V v_t_2456 = (g_list_2emap(heff_clo_n(g_heff_2eelab_2erename_2erenameTermF_lam1, 1, 1, (V[]){v_k_240}), heff_arrayToList(v_args_2454)));
    return heff_tag_re_n(v_ru_24e_242_24STag, TAG_STag, 2, 1ULL, (V[]){v_t_2453, heff_arrayFromList(v_t_2456)});
  }
  case TAG_SMatch: {
    V v_e2_2457 = heff_field(v_e_242, 0);
    V v_cs_2458 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24SMatch = heff_take_reuse_n(v_e_242, 3ULL, 2);
    heff_drop(v_r_241);
    V v_t_2459 = heff_tr(heff_call(heff_dup(heff_rfield(v_k_240, 0)), 1, (V[]){v_e2_2457}));
    V v_xs_2460 = heff_take_field(v_cs_2458, 2);
    V v_m_2461 = heff_arrayLength_lent(v_xs_2460, 0);
    V v_t_2469;
    if ((heff_peek_word(v_m_2461) <= ((int64_t)0ULL))) {
      heff_drop_rec(v_k_240, 2);
      heff_drop(v_xs_2460);
      v_t_2469 = heff_arrayGenerate(v_m_2461, ((V)&g_heff_2eelab_2erename_2erenameTermF_lam2_clo));
    } else {
      V v_p_2463 = heff_arrayIndex_lent(v_xs_2460, MK_INT(0LL), 2);
      V v_y_2467;
      switch (heff_tag_of(v_p_2463)) {
      case TAG_MkPair: {
        V v_xs_2464 = heff_field(v_p_2463, 0);
        V v_b_2465 = heff_field(v_p_2463, 1);
        V v_ru_24p_2463_24MkPair = heff_take_reuse_n(v_p_2463, 3ULL, 2);
        V v_t_2466 = heff_tr(heff_call(heff_dup(heff_rfield(v_k_240, 0)), 1, (V[]){v_b_2465}));
        v_y_2467 = heff_tag_re_n(v_ru_24p_2463_24MkPair, TAG_MkPair, 2, 1ULL, (V[]){v_xs_2464, v_t_2466});
        break;
      }
      default: heff_nomatch(v_p_2463);
      }
      V v_t_2468 = heff_arrayKeepsAs_lent(v_xs_2460, v_y_2467, 0);
      if ((heff_dup(v_t_2468) == NTAG(TAG_True))) {
        heff_drop(v_m_2461);
        heff_drop(v_t_2468);
        v_t_2469 = ({ V a_0 = v_k_240; V a_1 = MK_INT(1LL); V a_2 = heff_arraySet(v_xs_2460, MK_INT(0LL), v_y_2467); V r_ = (g_heff_2eelab_2erename_2erenameTermF_24map1(a_0, a_1, a_2)); heff_drop_rec(v_k_240, 2); r_; });
      } else {
        heff_drop(v_t_2468);
        v_t_2469 = ({ V a_0 = v_xs_2460; V a_1 = v_k_240; V a_2 = MK_INT(1LL); V a_3 = heff_arrayReplicate(v_m_2461, v_y_2467); V r_ = (g_heff_2eelab_2erename_2erenameTermF_24generate1(a_0, a_1, a_2, a_3)); heff_drop(v_xs_2460); heff_drop_rec(v_k_240, 2); r_; });
      }
    }
    V v_t_2470 = ({ V rv_2 = v_t_2469; V rr_ = heff_rec_reuse_nf(v_cs_2458, 3ULL, 3, shape_keys__byName__values, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    return heff_tag_at_n(v_ru_24e_242_24SMatch, TAG_SMatch, 2, (V[]){v_t_2459, v_t_2470});
  }
  case TAG_SSpecialize: {
    V v_e2_2471 = heff_field(v_e_242, 0);
    V v_l_2472 = heff_field(v_e_242, 1);
    V v_v_2473 = heff_field(v_e_242, 2);
    V v_ru_24e_242_24SSpecialize = heff_take_reuse_n(v_e_242, 7ULL, 3);
    heff_drop(v_r_241);
    V v_t_2474 = heff_tr(heff_call(heff_dup(heff_rfield(v_k_240, 0)), 1, (V[]){v_e2_2471}));
    V v_t_2475 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 2), 1, (V[]){v_v_2473}));
    return heff_tag_re_n(v_ru_24e_242_24SSpecialize, TAG_SSpecialize, 3, 2ULL, (V[]){v_t_2474, v_l_2472, v_t_2475});
  }
  case TAG_SIs: {
    V v_e2_2476 = heff_field(v_e_242, 0);
    V v_ru_24e_242_24SIs = heff_take_reuse_n(v_e_242, 1ULL, 1);
    heff_drop(v_r_241);
    V v_t_2477 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 2), 1, (V[]){v_e2_2476}));
    return heff_tag_at_n(v_ru_24e_242_24SIs, TAG_SIs, 1, (V[]){v_t_2477});
  }
  case TAG_SOpaque: {
    heff_drop_rec(v_k_240, 2);
    heff_drop(v_r_241);
    return v_e_242;
  }
  case TAG_SAbandon: {
    heff_drop_rec(v_k_240, 2);
    heff_drop(v_r_241);
    return v_e_242;
  }
  case TAG_SRec: {
    V v_e2_2478 = heff_field(v_e_242, 0);
    V v_ru_24e_242_24SRec = heff_take_reuse_n(v_e_242, 1ULL, 1);
    heff_drop(v_r_241);
    V v_t_2479 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 2), 1, (V[]){v_e2_2478}));
    return heff_tag_at_n(v_ru_24e_242_24SRec, TAG_SRec, 1, (V[]){v_t_2479});
  }
  case TAG_SFix: {
    V v_d_2480 = heff_field(v_e_242, 0);
    V v_b_2481 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24SFix = heff_take_reuse_n(v_e_242, 3ULL, 2);
    heff_drop(v_r_241);
    V v_t_2482 = heff_tr(heff_call(heff_take_field(v_k_240, 1), 1, (V[]){v_d_2480}));
    V v_t_2488;
    switch (heff_tag_of(v_b_2481)) {
    case TAG_MkAbs: {
      V v_x_2483 = heff_field(v_b_2481, 0);
      V v_t_2484 = heff_field(v_b_2481, 1);
      V v_ru_24b_2481_24MkAbs = heff_take_reuse_n(v_b_2481, 3ULL, 2);
      V v_t_2485 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 2), 1, (V[]){v_t_2484}));
      v_t_2488 = heff_tag_re_n(v_ru_24b_2481_24MkAbs, TAG_MkAbs, 2, 1ULL, (V[]){v_x_2483, v_t_2485});
      break;
    }
    case TAG_AbsConst: {
      V v_t_2486 = heff_field(v_b_2481, 0);
      V v_ru_24b_2481_24AbsConst = heff_take_reuse_n(v_b_2481, 1ULL, 1);
      V v_t_2487 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 2), 1, (V[]){v_t_2486}));
      v_t_2488 = heff_tag_at_n(v_ru_24b_2481_24AbsConst, TAG_AbsConst, 1, (V[]){v_t_2487});
      break;
    }
    default: heff_nomatch(v_b_2481);
    }
    return heff_tag_at_n(v_ru_24e_242_24SFix, TAG_SFix, 2, (V[]){v_t_2482, v_t_2488});
  }
  case TAG_SImplicit: {
    V v_x_2489 = heff_field(v_e_242, 0);
    V v_e2_2490 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24SImplicit = heff_take_reuse_n(v_e_242, 3ULL, 2);
    heff_drop(v_r_241);
    V v_t_2491 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 2), 1, (V[]){v_e2_2490}));
    return heff_tag_re_n(v_ru_24e_242_24SImplicit, TAG_SImplicit, 2, 1ULL, (V[]){v_x_2489, v_t_2491});
  }
  case TAG_SPrim: {
    heff_drop_rec(v_k_240, 2);
    heff_drop(v_r_241);
    return v_e_242;
  }
  case TAG_SMetaApp: {
    V v_m_2493 = heff_field(v_e_242, 0);
    V v_xs_2494 = heff_field(v_e_242, 1);
    V v_t_2495 = heff_field(v_e_242, 2);
    V v_ru_24e_242_24SMetaApp = heff_take_reuse_n(v_e_242, 7ULL, 3);
    heff_drop(v_r_241);
    V v_t_2496 = heff_tr(heff_call(heff_get_n(v_k_240, 1, 2), 1, (V[]){v_t_2495}));
    return heff_tag_re_n(v_ru_24e_242_24SMetaApp, TAG_SMetaApp, 3, 3ULL, (V[]){v_m_2493, v_xs_2494, v_t_2496});
  }
  case TAG_SLitInt: {
    heff_drop_rec(v_k_240, 2);
    heff_drop(v_r_241);
    return v_e_242;
  }
  case TAG_SLitFloat: {
    heff_drop_rec(v_k_240, 2);
    heff_drop(v_r_241);
    return v_e_242;
  }
  case TAG_SLitString: {
    heff_drop_rec(v_k_240, 2);
    heff_drop(v_r_241);
    return v_e_242;
  }
  case TAG_SLitBytes: {
    heff_drop_rec(v_k_240, 2);
    heff_drop(v_r_241);
    return v_e_242;
  }
  case TAG_SLitRune: {
    heff_drop_rec(v_k_240, 2);
    heff_drop(v_r_241);
    return v_e_242;
  }
  case TAG_SLitFixed: {
    heff_drop_rec(v_k_240, 2);
    heff_drop(v_r_241);
    return v_e_242;
  }
  case TAG_SLitFloat32: {
    heff_drop_rec(v_k_240, 2);
    heff_drop(v_r_241);
    return v_e_242;
  }
  default: return heff_nomatch(v_e_242);
  }
}
V g_heff_2eelab_2erename_2erenameTermF_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erename_2erenameTermF(a[0], a[1], a[2]);
}
V g_heff_2eelab_2erename_2erenameTermF_lam0(V self, V *args) {
  V v_u_2444 = args[0];
  heff_drop(v_u_2444);
  return heff_abandon();
}
V g_heff_2eelab_2erename_2erenameTermF_lam1(V self, V *args) {
  V v_e2_2455 = args[0];
  V v_k_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_k_240, 0, 2);
  args[0] = v_e2_2455;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erename_2erenameTermF_lam2(V self, V *args) {
  V v_u_2462 = args[0];
  heff_drop(v_u_2462);
  return heff_abandon();
}
Clo g_heff_2eelab_2erename_2erenameTermF_24generate0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erename_2erenameTermF_24generate0_entry, 4, 0};

V g_heff_2eelab_2erename_2erenameTermF_24generate0(V v_xs_240, V v_k_241, V v_box_24i_242, V v_a_243) {
  int64_t v_i_242 = heff_unbox_word(v_box_24i_242);
  v_a_243 = heff_arrayOwn(v_a_243);
  if (((((int64_t)0ULL) <= v_i_242) && (heff_unbox_word(heff_arrayLength_lent(v_a_243, 0)) <= heff_unbox_word(heff_arrayLength_lent(v_xs_240, 0))))) {
    top_TAG_InRange: ;
    if ((v_i_242 < heff_unbox_word(heff_arrayLength_lent(v_a_243, 0)))) {
      V v_e2_244 = heff_arrayIndexIn_lent(v_xs_240, heff_box_word(v_i_242), 2);
      V v_t_245 = heff_tr(heff_call(heff_dup(heff_rfield(v_k_241, 0)), 1, (V[]){v_e2_244}));
      V t_0 = v_xs_240;
      V t_1 = v_k_241;
      int64_t t_2 = (v_i_242 + ((int64_t)1ULL));
      V t_3 = heff_arraySetOwnedIn(v_a_243, heff_box_word(v_i_242), v_t_245);
      v_xs_240 = t_0;
      v_k_241 = t_1;
      v_i_242 = t_2;
      v_a_243 = t_3;
      goto top_TAG_InRange;
    } else {
      return v_a_243;
    }
  } else {
  }
top: ;
  if ((v_i_242 < heff_unbox_word(heff_arrayLength_lent(v_a_243, 0)))) {
    V v_e2_244 = heff_arrayIndex_lent(v_xs_240, heff_box_word(v_i_242), 2);
    V v_t_245 = heff_tr(heff_call(heff_dup(heff_rfield(v_k_241, 0)), 1, (V[]){v_e2_244}));
    V t_0 = v_xs_240;
    V t_1 = v_k_241;
    int64_t t_2 = (v_i_242 + ((int64_t)1ULL));
    V t_3 = heff_arraySetOwned(v_a_243, heff_box_word(v_i_242), v_t_245);
    v_xs_240 = t_0;
    v_k_241 = t_1;
    v_i_242 = t_2;
    v_a_243 = t_3;
    goto top;
  } else {
    return v_a_243;
  }
}
V g_heff_2eelab_2erename_2erenameTermF_24generate0_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2eelab_2erename_2erenameTermF_24generate0(a0, a1, a[2], a[3]); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_heff_2eelab_2erename_2erenameTermF_24map0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erename_2erenameTermF_24map0_entry, 3, 0};

V g_heff_2eelab_2erename_2erenameTermF_24map0(V v_k_240, V v_box_24i_241, V v_a_242) {
  int64_t v_i_241 = heff_unbox_word(v_box_24i_241);
  v_a_242 = heff_arrayOwn(v_a_242);
  if ((((int64_t)0ULL) <= v_i_241)) {
    top_TAG_InRange: ;
    if ((v_i_241 < heff_unbox_word(heff_arrayLength_lent(v_a_242, 0)))) {
      V v_e2_243 = heff_arrayIndexIn_lent(v_a_242, heff_box_word(v_i_241), 2);
      V v_t_244 = heff_tr(heff_call(heff_dup(heff_rfield(v_k_240, 0)), 1, (V[]){v_e2_243}));
      V t_0 = v_k_240;
      int64_t t_1 = (v_i_241 + ((int64_t)1ULL));
      V t_2 = heff_arraySetOwnedIn(v_a_242, heff_box_word(v_i_241), v_t_244);
      v_k_240 = t_0;
      v_i_241 = t_1;
      v_a_242 = t_2;
      goto top_TAG_InRange;
    } else {
      return v_a_242;
    }
  } else {
  }
top: ;
  if ((v_i_241 < heff_unbox_word(heff_arrayLength_lent(v_a_242, 0)))) {
    V v_e2_243 = heff_arrayIndex_lent(v_a_242, heff_box_word(v_i_241), 2);
    V v_t_244 = heff_tr(heff_call(heff_dup(heff_rfield(v_k_240, 0)), 1, (V[]){v_e2_243}));
    V t_0 = v_k_240;
    int64_t t_1 = (v_i_241 + ((int64_t)1ULL));
    V t_2 = heff_arraySetOwned(v_a_242, heff_box_word(v_i_241), v_t_244);
    v_k_240 = t_0;
    v_i_241 = t_1;
    v_a_242 = t_2;
    goto top;
  } else {
    return v_a_242;
  }
}
V g_heff_2eelab_2erename_2erenameTermF_24map0_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2erename_2erenameTermF_24map0(a0, a[1], a[2]); heff_drop(a0); return r;
}
Clo g_heff_2eelab_2erename_2erenameTermF_24generate1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erename_2erenameTermF_24generate1_entry, 4, 0};

V g_heff_2eelab_2erename_2erenameTermF_24generate1(V v_xs_240, V v_k_241, V v_box_24i_242, V v_a_243) {
  int64_t v_i_242 = heff_unbox_word(v_box_24i_242);
  v_a_243 = heff_arrayOwn(v_a_243);
  if (((((int64_t)0ULL) <= v_i_242) && (heff_unbox_word(heff_arrayLength_lent(v_a_243, 0)) <= heff_unbox_word(heff_arrayLength_lent(v_xs_240, 0))))) {
    top_TAG_InRange: ;
    if ((v_i_242 < heff_unbox_word(heff_arrayLength_lent(v_a_243, 0)))) {
      V v_p_244 = heff_arrayPeekIn(v_xs_240, heff_box_word(v_i_242));
      V v_t_248;
      switch (heff_tag_of(v_p_244)) {
      case TAG_MkPair: {
        V v_xs_245 = heff_field(v_p_244, 0);
        V v_b_246 = heff_field(v_p_244, 1);
        V v_t_247 = heff_tr(heff_call(heff_dup(heff_rfield(v_k_241, 0)), 1, (V[]){heff_dup(v_b_246)}));
        v_t_248 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_dup(v_xs_245), v_t_247});
        break;
      }
      default: heff_nomatch(v_p_244);
      }
      V t_0 = v_xs_240;
      V t_1 = v_k_241;
      int64_t t_2 = (v_i_242 + ((int64_t)1ULL));
      V t_3 = heff_arraySetOwnedIn(v_a_243, heff_box_word(v_i_242), v_t_248);
      v_xs_240 = t_0;
      v_k_241 = t_1;
      v_i_242 = t_2;
      v_a_243 = t_3;
      goto top_TAG_InRange;
    } else {
      return v_a_243;
    }
  } else {
  }
top: ;
  if ((v_i_242 < heff_unbox_word(heff_arrayLength_lent(v_a_243, 0)))) {
    V v_p_244 = heff_arrayPeek(v_xs_240, heff_box_word(v_i_242));
    V v_t_248;
    switch (heff_tag_of(v_p_244)) {
    case TAG_MkPair: {
      V v_xs_245 = heff_field(v_p_244, 0);
      V v_b_246 = heff_field(v_p_244, 1);
      V v_t_247 = heff_tr(heff_call(heff_dup(heff_rfield(v_k_241, 0)), 1, (V[]){heff_dup(v_b_246)}));
      v_t_248 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_dup(v_xs_245), v_t_247});
      break;
    }
    default: heff_nomatch(v_p_244);
    }
    V t_0 = v_xs_240;
    V t_1 = v_k_241;
    int64_t t_2 = (v_i_242 + ((int64_t)1ULL));
    V t_3 = heff_arraySetOwned(v_a_243, heff_box_word(v_i_242), v_t_248);
    v_xs_240 = t_0;
    v_k_241 = t_1;
    v_i_242 = t_2;
    v_a_243 = t_3;
    goto top;
  } else {
    return v_a_243;
  }
}
V g_heff_2eelab_2erename_2erenameTermF_24generate1_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2eelab_2erename_2erenameTermF_24generate1(a0, a1, a[2], a[3]); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_heff_2eelab_2erename_2erenameTermF_24map1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erename_2erenameTermF_24map1_entry, 3, 0};

V g_heff_2eelab_2erename_2erenameTermF_24map1(V v_k_240, V v_box_24i_241, V v_a_242) {
  int64_t v_i_241 = heff_unbox_word(v_box_24i_241);
  v_a_242 = heff_arrayOwn(v_a_242);
  if ((((int64_t)0ULL) <= v_i_241)) {
    top_TAG_InRange: ;
    if ((v_i_241 < heff_unbox_word(heff_arrayLength_lent(v_a_242, 0)))) {
      V v_p_243 = heff_arrayIndexIn_lent(v_a_242, heff_box_word(v_i_241), 2);
      V v_t_247;
      switch (heff_tag_of(v_p_243)) {
      case TAG_MkPair: {
        V v_xs_244 = heff_field(v_p_243, 0);
        V v_b_245 = heff_field(v_p_243, 1);
        V v_ru_24p_243_24MkPair = heff_take_reuse_n(v_p_243, 3ULL, 2);
        V v_t_246 = heff_tr(heff_call(heff_dup(heff_rfield(v_k_240, 0)), 1, (V[]){v_b_245}));
        v_t_247 = heff_tag_re_n(v_ru_24p_243_24MkPair, TAG_MkPair, 2, 1ULL, (V[]){v_xs_244, v_t_246});
        break;
      }
      default: heff_nomatch(v_p_243);
      }
      V t_0 = v_k_240;
      int64_t t_1 = (v_i_241 + ((int64_t)1ULL));
      V t_2 = heff_arraySetOwnedIn(v_a_242, heff_box_word(v_i_241), v_t_247);
      v_k_240 = t_0;
      v_i_241 = t_1;
      v_a_242 = t_2;
      goto top_TAG_InRange;
    } else {
      return v_a_242;
    }
  } else {
  }
top: ;
  if ((v_i_241 < heff_unbox_word(heff_arrayLength_lent(v_a_242, 0)))) {
    V v_p_243 = heff_arrayIndex_lent(v_a_242, heff_box_word(v_i_241), 2);
    V v_t_247;
    switch (heff_tag_of(v_p_243)) {
    case TAG_MkPair: {
      V v_xs_244 = heff_field(v_p_243, 0);
      V v_b_245 = heff_field(v_p_243, 1);
      V v_ru_24p_243_24MkPair = heff_take_reuse_n(v_p_243, 3ULL, 2);
      V v_t_246 = heff_tr(heff_call(heff_dup(heff_rfield(v_k_240, 0)), 1, (V[]){v_b_245}));
      v_t_247 = heff_tag_re_n(v_ru_24p_243_24MkPair, TAG_MkPair, 2, 1ULL, (V[]){v_xs_244, v_t_246});
      break;
    }
    default: heff_nomatch(v_p_243);
    }
    V t_0 = v_k_240;
    int64_t t_1 = (v_i_241 + ((int64_t)1ULL));
    V t_2 = heff_arraySetOwned(v_a_242, heff_box_word(v_i_241), v_t_247);
    v_k_240 = t_0;
    v_i_241 = t_1;
    v_a_242 = t_2;
    goto top;
  } else {
    return v_a_242;
  }
}
V g_heff_2eelab_2erename_2erenameTermF_24map1_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2erename_2erenameTermF_24map1(a0, a[1], a[2]); heff_drop(a0); return r;
}
V g_heff_2eelab_2erename_2erenameTypeF_lam0(V self, V *args); static Clo g_heff_2eelab_2erename_2erenameTypeF_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erename_2erenameTypeF_lam0, 1, 0};
V g_heff_2eelab_2erename_2erenameTypeF_lam1(V self, V *args); static Clo g_heff_2eelab_2erename_2erenameTypeF_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erename_2erenameTypeF_lam1, 1, 0};
V g_heff_2eelab_2erename_2erenameTypeF_lam2(V self, V *args); static Clo g_heff_2eelab_2erename_2erenameTypeF_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erename_2erenameTypeF_lam2, 1, 0};
V g_heff_2eelab_2erename_2erenameTypeF_lam3(V self, V *args); static Clo g_heff_2eelab_2erename_2erenameTypeF_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erename_2erenameTypeF_lam3, 1, 0};
Clo g_heff_2eelab_2erename_2erenameTypeF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erename_2erenameTypeF_entry, 3, 0};

V g_heff_2eelab_2erename_2erenameTypeF(V v_k_240, V v_r_241, V v_t_242) {
top: ;
  switch (heff_tag_of(v_t_242)) {
  case TAG_SU: {
    heff_drop_rec(v_k_240, 2);
    return v_t_242;
  }
  case TAG_SDecode: {
    V v_e_244 = heff_field(v_t_242, 0);
    V v_ru_24t_242_24SDecode = heff_take_reuse_n(v_t_242, 1ULL, 1);
    V v_t_245 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 2), 1, (V[]){v_e_244}));
    return heff_tag_at_n(v_ru_24t_242_24SDecode, TAG_SDecode, 1, (V[]){v_t_245});
  }
  case TAG_SFunction: {
    V v_level_246 = heff_field(v_t_242, 0);
    V v_dom_247 = heff_field(v_t_242, 1);
    V v_cod_248 = heff_field(v_t_242, 2);
    V v_implicit_249 = heff_field(v_t_242, 3);
    V v_dflt_2410 = heff_field(v_t_242, 4);
    V v_ru_24t_242_24SFunction = heff_take_reuse_n(v_t_242, 31ULL, 5);
    V v_t_2411 = heff_tr(heff_call(heff_dup(heff_rfield(v_k_240, 1)), 1, (V[]){v_dom_247}));
    V v_t_2417;
    switch (heff_tag_of(v_cod_248)) {
    case TAG_MkAbs: {
      V v_x_2412 = heff_field(v_cod_248, 0);
      V v_t_2413 = heff_field(v_cod_248, 1);
      V v_ru_24cod_248_24MkAbs = heff_take_reuse_n(v_cod_248, 3ULL, 2);
      V v_t_2414 = heff_tr(heff_call(heff_dup(heff_rfield(v_k_240, 1)), 1, (V[]){v_t_2413}));
      v_t_2417 = heff_tag_re_n(v_ru_24cod_248_24MkAbs, TAG_MkAbs, 2, 1ULL, (V[]){v_x_2412, v_t_2414});
      break;
    }
    case TAG_AbsConst: {
      V v_t_2415 = heff_field(v_cod_248, 0);
      V v_ru_24cod_248_24AbsConst = heff_take_reuse_n(v_cod_248, 1ULL, 1);
      V v_t_2416 = heff_tr(heff_call(heff_dup(heff_rfield(v_k_240, 1)), 1, (V[]){v_t_2415}));
      v_t_2417 = heff_tag_at_n(v_ru_24cod_248_24AbsConst, TAG_AbsConst, 1, (V[]){v_t_2416});
      break;
    }
    default: heff_nomatch(v_cod_248);
    }
    V v_t_2420;
    switch (heff_tag_of(v_dflt_2410)) {
    case TAG_Nothing: {
      heff_drop_rec(v_k_240, 2);
      v_t_2420 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Just: {
      V v_d_2418 = heff_field(v_dflt_2410, 0);
      V v_ru_24dflt_2410_24Just = heff_take_reuse_n(v_dflt_2410, 1ULL, 1);
      V v_t_2419 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 2), 1, (V[]){v_d_2418}));
      v_t_2420 = heff_tag_at_n(v_ru_24dflt_2410_24Just, TAG_Just, 1, (V[]){v_t_2419});
      break;
    }
    default: heff_nomatch(v_dflt_2410);
    }
    return heff_tag_re_n(v_ru_24t_242_24SFunction, TAG_SFunction, 5, 9ULL, (V[]){v_level_246, v_t_2411, v_t_2417, v_implicit_249, v_t_2420});
  }
  case TAG_SRecord: {
    V v_level_2421 = heff_field(v_t_242, 0);
    V v_fs_2422 = heff_field(v_t_242, 1);
    V v_ds_2423 = heff_field(v_t_242, 2);
    V v_ru_24t_242_24SRecord = heff_take_reuse_n(v_t_242, 7ULL, 3);
    V v_xs_2424 = heff_take_field(v_fs_2422, 2);
    V v_m_2425 = heff_arrayLength_lent(v_xs_2424, 0);
    V v_t_2430;
    if ((heff_peek_word(v_m_2425) <= ((int64_t)0ULL))) {
      heff_drop(v_xs_2424);
      v_t_2430 = heff_arrayGenerate(v_m_2425, ((V)&g_heff_2eelab_2erename_2erenameTypeF_lam0_clo));
    } else {
      V v_t2_2427 = heff_arrayIndex_lent(v_xs_2424, MK_INT(0LL), 2);
      V v_y_2428 = heff_tr(heff_call(heff_dup(heff_rfield(v_k_240, 1)), 1, (V[]){v_t2_2427}));
      V v_t_2429 = heff_arrayKeepsAs_lent(v_xs_2424, v_y_2428, 0);
      if ((heff_dup(v_t_2429) == NTAG(TAG_True))) {
        heff_drop(v_m_2425);
        heff_drop(v_t_2429);
        v_t_2430 = (g_heff_2eelab_2erename_2erenameTypeF_24map0(v_k_240, MK_INT(1LL), heff_arraySet(v_xs_2424, MK_INT(0LL), v_y_2428)));
      } else {
        heff_drop(v_t_2429);
        v_t_2430 = ({ V a_0 = v_xs_2424; V a_1 = v_k_240; V a_2 = MK_INT(1LL); V a_3 = heff_arrayReplicate(v_m_2425, v_y_2428); V r_ = (g_heff_2eelab_2erename_2erenameTypeF_24generate0(a_0, a_1, a_2, a_3)); heff_drop(v_xs_2424); r_; });
      }
    }
    V v_xs_2431 = heff_take_field(v_ds_2423, 2);
    V v_m_2432 = heff_arrayLength_lent(v_xs_2431, 0);
    V v_t_2437;
    if ((heff_peek_word(v_m_2432) <= ((int64_t)0ULL))) {
      heff_drop_rec(v_k_240, 2);
      heff_drop(v_xs_2431);
      v_t_2437 = heff_arrayGenerate(v_m_2432, ((V)&g_heff_2eelab_2erename_2erenameTypeF_lam1_clo));
    } else {
      V v_e2_2434 = heff_arrayIndex_lent(v_xs_2431, MK_INT(0LL), 2);
      V v_y_2435 = heff_tr(heff_call(heff_dup(heff_rfield(v_k_240, 0)), 1, (V[]){v_e2_2434}));
      V v_t_2436 = heff_arrayKeepsAs_lent(v_xs_2431, v_y_2435, 0);
      if ((heff_dup(v_t_2436) == NTAG(TAG_True))) {
        heff_drop(v_m_2432);
        heff_drop(v_t_2436);
        v_t_2437 = ({ V a_0 = v_k_240; V a_1 = MK_INT(1LL); V a_2 = heff_arraySet(v_xs_2431, MK_INT(0LL), v_y_2435); V r_ = (g_heff_2eelab_2erename_2erenameTypeF_24map1(a_0, a_1, a_2)); heff_drop_rec(v_k_240, 2); r_; });
      } else {
        heff_drop(v_t_2436);
        v_t_2437 = ({ V a_0 = v_xs_2431; V a_1 = v_k_240; V a_2 = MK_INT(1LL); V a_3 = heff_arrayReplicate(v_m_2432, v_y_2435); V r_ = (g_heff_2eelab_2erename_2erenameTypeF_24generate1(a_0, a_1, a_2, a_3)); heff_drop(v_xs_2431); heff_drop_rec(v_k_240, 2); r_; });
      }
    }
    V v_t_2438 = ({ V rv_2 = v_t_2430; V rr_ = heff_rec_reuse_nf(v_fs_2422, 3ULL, 3, shape_keys__byName__values, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    V v_t_2439 = ({ V rv_2 = v_t_2437; V rr_ = heff_rec_reuse_nf(v_ds_2423, 3ULL, 3, shape_keys__byName__values, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    return heff_tag_re_n(v_ru_24t_242_24SRecord, TAG_SRecord, 3, 1ULL, (V[]){v_level_2421, v_t_2438, v_t_2439});
  }
  case TAG_SSum: {
    V v_vs_2440 = heff_field(v_t_242, 0);
    V v_ru_24t_242_24SSum = heff_take_reuse_n(v_t_242, 1ULL, 1);
    V v_xs_2441 = heff_take_field(v_vs_2440, 2);
    V v_m_2442 = heff_arrayLength_lent(v_xs_2441, 0);
    V v_t_2452;
    if ((heff_peek_word(v_m_2442) <= ((int64_t)0ULL))) {
      heff_drop_rec(v_k_240, 2);
      heff_drop(v_xs_2441);
      v_t_2452 = heff_arrayGenerate(v_m_2442, ((V)&g_heff_2eelab_2erename_2erenameTypeF_lam2_clo));
    } else {
      V v_xs_2444 = heff_arrayIndex_lent(v_xs_2441, MK_INT(0LL), 2);
      V v_m_2445 = heff_arrayLength_lent(v_xs_2444, 0);
      V v_y_2450;
      if ((heff_peek_word(v_m_2445) <= ((int64_t)0ULL))) {
        heff_drop(v_xs_2444);
        v_y_2450 = heff_arrayGenerate(v_m_2445, ((V)&g_heff_2eelab_2erename_2erenameTypeF_lam3_clo));
      } else {
        V v_t2_2447 = heff_arrayIndex_lent(v_xs_2444, MK_INT(0LL), 2);
        V v_y_2448 = heff_tr(heff_call(heff_dup(heff_rfield(v_k_240, 1)), 1, (V[]){v_t2_2447}));
        V v_t_2449 = heff_arrayKeepsAs_lent(v_xs_2444, v_y_2448, 0);
        if ((heff_dup(v_t_2449) == NTAG(TAG_True))) {
          heff_drop(v_m_2445);
          heff_drop(v_t_2449);
          v_y_2450 = (g_heff_2eelab_2erename_2erenameTypeF_24map2(v_k_240, MK_INT(1LL), heff_arraySet(v_xs_2444, MK_INT(0LL), v_y_2448)));
        } else {
          heff_drop(v_t_2449);
          v_y_2450 = ({ V a_0 = v_xs_2444; V a_1 = v_k_240; V a_2 = MK_INT(1LL); V a_3 = heff_arrayReplicate(v_m_2445, v_y_2448); V r_ = (g_heff_2eelab_2erename_2erenameTypeF_24generate2(a_0, a_1, a_2, a_3)); heff_drop(v_xs_2444); r_; });
        }
      }
      V v_t_2451 = heff_arrayKeepsAs_lent(v_xs_2441, v_y_2450, 0);
      if ((heff_dup(v_t_2451) == NTAG(TAG_True))) {
        heff_drop(v_m_2442);
        heff_drop(v_t_2451);
        v_t_2452 = ({ V a_0 = v_k_240; V a_1 = MK_INT(1LL); V a_2 = heff_arraySet(v_xs_2441, MK_INT(0LL), v_y_2450); V r_ = (g_heff_2eelab_2erename_2erenameTypeF_24map3(a_0, a_1, a_2)); heff_drop_rec(v_k_240, 2); r_; });
      } else {
        heff_drop(v_t_2451);
        v_t_2452 = ({ V a_0 = v_xs_2441; V a_1 = v_k_240; V a_2 = MK_INT(1LL); V a_3 = heff_arrayReplicate(v_m_2442, v_y_2450); V r_ = (g_heff_2eelab_2erename_2erenameTypeF_24generate3(a_0, a_1, a_2, a_3)); heff_drop(v_xs_2441); heff_drop_rec(v_k_240, 2); r_; });
      }
    }
    V v_t_2453 = ({ V rv_2 = v_t_2452; V rr_ = heff_rec_reuse_nf(v_vs_2440, 3ULL, 3, shape_keys__byName__values, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    return heff_tag_at_n(v_ru_24t_242_24SSum, TAG_SSum, 1, (V[]){v_t_2453});
  }
  case TAG_SIsTy: {
    V v_t2_2454 = heff_field(v_t_242, 0);
    V v_ru_24t_242_24SIsTy = heff_take_reuse_n(v_t_242, 1ULL, 1);
    V v_t_2455 = heff_tr(heff_call(heff_get_n(v_k_240, 1, 2), 1, (V[]){v_t2_2454}));
    return heff_tag_at_n(v_ru_24t_242_24SIsTy, TAG_SIsTy, 1, (V[]){v_t_2455});
  }
  case TAG_SPrimInt: {
    heff_drop_rec(v_k_240, 2);
    return v_t_242;
  }
  case TAG_SPrimFloat: {
    heff_drop_rec(v_k_240, 2);
    return v_t_242;
  }
  case TAG_SPrimString: {
    heff_drop_rec(v_k_240, 2);
    return v_t_242;
  }
  case TAG_SPrimRune: {
    heff_drop_rec(v_k_240, 2);
    return v_t_242;
  }
  case TAG_SPrimArray: {
    V v_t2_2456 = heff_field(v_t_242, 0);
    V v_ru_24t_242_24SPrimArray = heff_take_reuse_n(v_t_242, 1ULL, 1);
    V v_t_2457 = heff_tr(heff_call(heff_get_n(v_k_240, 1, 2), 1, (V[]){v_t2_2456}));
    return heff_tag_at_n(v_ru_24t_242_24SPrimArray, TAG_SPrimArray, 1, (V[]){v_t_2457});
  }
  case TAG_SFixed: {
    heff_drop_rec(v_k_240, 2);
    return v_t_242;
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2eelab_2erename_2erenameTypeF_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2erename_2erenameTypeF(a[0], a1, a[2]); heff_drop(a1); return r;
}
V g_heff_2eelab_2erename_2erenameTypeF_lam0(V self, V *args) {
  V v_u_2426 = args[0];
  heff_drop(v_u_2426);
  return heff_abandon();
}
V g_heff_2eelab_2erename_2erenameTypeF_lam1(V self, V *args) {
  V v_u_2433 = args[0];
  heff_drop(v_u_2433);
  return heff_abandon();
}
V g_heff_2eelab_2erename_2erenameTypeF_lam2(V self, V *args) {
  V v_u_2443 = args[0];
  heff_drop(v_u_2443);
  return heff_abandon();
}
V g_heff_2eelab_2erename_2erenameTypeF_lam3(V self, V *args) {
  V v_u_2446 = args[0];
  heff_drop(v_u_2446);
  return heff_abandon();
}
Clo g_heff_2eelab_2erename_2erenameTypeF_24generate0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erename_2erenameTypeF_24generate0_entry, 4, 0};

V g_heff_2eelab_2erename_2erenameTypeF_24generate0(V v_xs_240, V v_k_241, V v_box_24i_242, V v_a_243) {
  int64_t v_i_242 = heff_unbox_word(v_box_24i_242);
  v_a_243 = heff_arrayOwn(v_a_243);
  if (((((int64_t)0ULL) <= v_i_242) && (heff_unbox_word(heff_arrayLength_lent(v_a_243, 0)) <= heff_unbox_word(heff_arrayLength_lent(v_xs_240, 0))))) {
    top_TAG_InRange: ;
    if ((v_i_242 < heff_unbox_word(heff_arrayLength_lent(v_a_243, 0)))) {
      V v_t2_244 = heff_arrayIndexIn_lent(v_xs_240, heff_box_word(v_i_242), 2);
      V v_t_245 = heff_tr(heff_call(heff_dup(heff_rfield(v_k_241, 1)), 1, (V[]){v_t2_244}));
      V t_0 = v_xs_240;
      V t_1 = v_k_241;
      int64_t t_2 = (v_i_242 + ((int64_t)1ULL));
      V t_3 = heff_arraySetOwnedIn(v_a_243, heff_box_word(v_i_242), v_t_245);
      v_xs_240 = t_0;
      v_k_241 = t_1;
      v_i_242 = t_2;
      v_a_243 = t_3;
      goto top_TAG_InRange;
    } else {
      return v_a_243;
    }
  } else {
  }
top: ;
  if ((v_i_242 < heff_unbox_word(heff_arrayLength_lent(v_a_243, 0)))) {
    V v_t2_244 = heff_arrayIndex_lent(v_xs_240, heff_box_word(v_i_242), 2);
    V v_t_245 = heff_tr(heff_call(heff_dup(heff_rfield(v_k_241, 1)), 1, (V[]){v_t2_244}));
    V t_0 = v_xs_240;
    V t_1 = v_k_241;
    int64_t t_2 = (v_i_242 + ((int64_t)1ULL));
    V t_3 = heff_arraySetOwned(v_a_243, heff_box_word(v_i_242), v_t_245);
    v_xs_240 = t_0;
    v_k_241 = t_1;
    v_i_242 = t_2;
    v_a_243 = t_3;
    goto top;
  } else {
    return v_a_243;
  }
}
V g_heff_2eelab_2erename_2erenameTypeF_24generate0_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2eelab_2erename_2erenameTypeF_24generate0(a0, a1, a[2], a[3]); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_heff_2eelab_2erename_2erenameTypeF_24map0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erename_2erenameTypeF_24map0_entry, 3, 0};

V g_heff_2eelab_2erename_2erenameTypeF_24map0(V v_k_240, V v_box_24i_241, V v_a_242) {
  int64_t v_i_241 = heff_unbox_word(v_box_24i_241);
  v_a_242 = heff_arrayOwn(v_a_242);
  if ((((int64_t)0ULL) <= v_i_241)) {
    top_TAG_InRange: ;
    if ((v_i_241 < heff_unbox_word(heff_arrayLength_lent(v_a_242, 0)))) {
      V v_t2_243 = heff_arrayIndexIn_lent(v_a_242, heff_box_word(v_i_241), 2);
      V v_t_244 = heff_tr(heff_call(heff_dup(heff_rfield(v_k_240, 1)), 1, (V[]){v_t2_243}));
      V t_0 = v_k_240;
      int64_t t_1 = (v_i_241 + ((int64_t)1ULL));
      V t_2 = heff_arraySetOwnedIn(v_a_242, heff_box_word(v_i_241), v_t_244);
      v_k_240 = t_0;
      v_i_241 = t_1;
      v_a_242 = t_2;
      goto top_TAG_InRange;
    } else {
      return v_a_242;
    }
  } else {
  }
top: ;
  if ((v_i_241 < heff_unbox_word(heff_arrayLength_lent(v_a_242, 0)))) {
    V v_t2_243 = heff_arrayIndex_lent(v_a_242, heff_box_word(v_i_241), 2);
    V v_t_244 = heff_tr(heff_call(heff_dup(heff_rfield(v_k_240, 1)), 1, (V[]){v_t2_243}));
    V t_0 = v_k_240;
    int64_t t_1 = (v_i_241 + ((int64_t)1ULL));
    V t_2 = heff_arraySetOwned(v_a_242, heff_box_word(v_i_241), v_t_244);
    v_k_240 = t_0;
    v_i_241 = t_1;
    v_a_242 = t_2;
    goto top;
  } else {
    return v_a_242;
  }
}
V g_heff_2eelab_2erename_2erenameTypeF_24map0_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2erename_2erenameTypeF_24map0(a0, a[1], a[2]); heff_drop(a0); return r;
}
Clo g_heff_2eelab_2erename_2erenameTypeF_24generate1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erename_2erenameTypeF_24generate1_entry, 4, 0};

V g_heff_2eelab_2erename_2erenameTypeF_24generate1(V v_xs_240, V v_k_241, V v_box_24i_242, V v_a_243) {
  int64_t v_i_242 = heff_unbox_word(v_box_24i_242);
  v_a_243 = heff_arrayOwn(v_a_243);
  if (((((int64_t)0ULL) <= v_i_242) && (heff_unbox_word(heff_arrayLength_lent(v_a_243, 0)) <= heff_unbox_word(heff_arrayLength_lent(v_xs_240, 0))))) {
    top_TAG_InRange: ;
    if ((v_i_242 < heff_unbox_word(heff_arrayLength_lent(v_a_243, 0)))) {
      V v_e2_244 = heff_arrayIndexIn_lent(v_xs_240, heff_box_word(v_i_242), 2);
      V v_t_245 = heff_tr(heff_call(heff_dup(heff_rfield(v_k_241, 0)), 1, (V[]){v_e2_244}));
      V t_0 = v_xs_240;
      V t_1 = v_k_241;
      int64_t t_2 = (v_i_242 + ((int64_t)1ULL));
      V t_3 = heff_arraySetOwnedIn(v_a_243, heff_box_word(v_i_242), v_t_245);
      v_xs_240 = t_0;
      v_k_241 = t_1;
      v_i_242 = t_2;
      v_a_243 = t_3;
      goto top_TAG_InRange;
    } else {
      return v_a_243;
    }
  } else {
  }
top: ;
  if ((v_i_242 < heff_unbox_word(heff_arrayLength_lent(v_a_243, 0)))) {
    V v_e2_244 = heff_arrayIndex_lent(v_xs_240, heff_box_word(v_i_242), 2);
    V v_t_245 = heff_tr(heff_call(heff_dup(heff_rfield(v_k_241, 0)), 1, (V[]){v_e2_244}));
    V t_0 = v_xs_240;
    V t_1 = v_k_241;
    int64_t t_2 = (v_i_242 + ((int64_t)1ULL));
    V t_3 = heff_arraySetOwned(v_a_243, heff_box_word(v_i_242), v_t_245);
    v_xs_240 = t_0;
    v_k_241 = t_1;
    v_i_242 = t_2;
    v_a_243 = t_3;
    goto top;
  } else {
    return v_a_243;
  }
}
V g_heff_2eelab_2erename_2erenameTypeF_24generate1_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2eelab_2erename_2erenameTypeF_24generate1(a0, a1, a[2], a[3]); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_heff_2eelab_2erename_2erenameTypeF_24map1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erename_2erenameTypeF_24map1_entry, 3, 0};

V g_heff_2eelab_2erename_2erenameTypeF_24map1(V v_k_240, V v_box_24i_241, V v_a_242) {
  int64_t v_i_241 = heff_unbox_word(v_box_24i_241);
  v_a_242 = heff_arrayOwn(v_a_242);
  if ((((int64_t)0ULL) <= v_i_241)) {
    top_TAG_InRange: ;
    if ((v_i_241 < heff_unbox_word(heff_arrayLength_lent(v_a_242, 0)))) {
      V v_e2_243 = heff_arrayIndexIn_lent(v_a_242, heff_box_word(v_i_241), 2);
      V v_t_244 = heff_tr(heff_call(heff_dup(heff_rfield(v_k_240, 0)), 1, (V[]){v_e2_243}));
      V t_0 = v_k_240;
      int64_t t_1 = (v_i_241 + ((int64_t)1ULL));
      V t_2 = heff_arraySetOwnedIn(v_a_242, heff_box_word(v_i_241), v_t_244);
      v_k_240 = t_0;
      v_i_241 = t_1;
      v_a_242 = t_2;
      goto top_TAG_InRange;
    } else {
      return v_a_242;
    }
  } else {
  }
top: ;
  if ((v_i_241 < heff_unbox_word(heff_arrayLength_lent(v_a_242, 0)))) {
    V v_e2_243 = heff_arrayIndex_lent(v_a_242, heff_box_word(v_i_241), 2);
    V v_t_244 = heff_tr(heff_call(heff_dup(heff_rfield(v_k_240, 0)), 1, (V[]){v_e2_243}));
    V t_0 = v_k_240;
    int64_t t_1 = (v_i_241 + ((int64_t)1ULL));
    V t_2 = heff_arraySetOwned(v_a_242, heff_box_word(v_i_241), v_t_244);
    v_k_240 = t_0;
    v_i_241 = t_1;
    v_a_242 = t_2;
    goto top;
  } else {
    return v_a_242;
  }
}
V g_heff_2eelab_2erename_2erenameTypeF_24map1_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2erename_2erenameTypeF_24map1(a0, a[1], a[2]); heff_drop(a0); return r;
}
Clo g_heff_2eelab_2erename_2erenameTypeF_24generate2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erename_2erenameTypeF_24generate2_entry, 4, 0};

V g_heff_2eelab_2erename_2erenameTypeF_24generate2(V v_xs_240, V v_k_241, V v_box_24i_242, V v_a_243) {
  int64_t v_i_242 = heff_unbox_word(v_box_24i_242);
  v_a_243 = heff_arrayOwn(v_a_243);
  if (((((int64_t)0ULL) <= v_i_242) && (heff_unbox_word(heff_arrayLength_lent(v_a_243, 0)) <= heff_unbox_word(heff_arrayLength_lent(v_xs_240, 0))))) {
    top_TAG_InRange: ;
    if ((v_i_242 < heff_unbox_word(heff_arrayLength_lent(v_a_243, 0)))) {
      V v_t2_244 = heff_arrayIndexIn_lent(v_xs_240, heff_box_word(v_i_242), 2);
      V v_t_245 = heff_tr(heff_call(heff_dup(heff_rfield(v_k_241, 1)), 1, (V[]){v_t2_244}));
      V t_0 = v_xs_240;
      V t_1 = v_k_241;
      int64_t t_2 = (v_i_242 + ((int64_t)1ULL));
      V t_3 = heff_arraySetOwnedIn(v_a_243, heff_box_word(v_i_242), v_t_245);
      v_xs_240 = t_0;
      v_k_241 = t_1;
      v_i_242 = t_2;
      v_a_243 = t_3;
      goto top_TAG_InRange;
    } else {
      return v_a_243;
    }
  } else {
  }
top: ;
  if ((v_i_242 < heff_unbox_word(heff_arrayLength_lent(v_a_243, 0)))) {
    V v_t2_244 = heff_arrayIndex_lent(v_xs_240, heff_box_word(v_i_242), 2);
    V v_t_245 = heff_tr(heff_call(heff_dup(heff_rfield(v_k_241, 1)), 1, (V[]){v_t2_244}));
    V t_0 = v_xs_240;
    V t_1 = v_k_241;
    int64_t t_2 = (v_i_242 + ((int64_t)1ULL));
    V t_3 = heff_arraySetOwned(v_a_243, heff_box_word(v_i_242), v_t_245);
    v_xs_240 = t_0;
    v_k_241 = t_1;
    v_i_242 = t_2;
    v_a_243 = t_3;
    goto top;
  } else {
    return v_a_243;
  }
}
V g_heff_2eelab_2erename_2erenameTypeF_24generate2_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2eelab_2erename_2erenameTypeF_24generate2(a0, a1, a[2], a[3]); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_heff_2eelab_2erename_2erenameTypeF_24map2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erename_2erenameTypeF_24map2_entry, 3, 0};

V g_heff_2eelab_2erename_2erenameTypeF_24map2(V v_k_240, V v_box_24i_241, V v_a_242) {
  int64_t v_i_241 = heff_unbox_word(v_box_24i_241);
  v_a_242 = heff_arrayOwn(v_a_242);
  if ((((int64_t)0ULL) <= v_i_241)) {
    top_TAG_InRange: ;
    if ((v_i_241 < heff_unbox_word(heff_arrayLength_lent(v_a_242, 0)))) {
      V v_t2_243 = heff_arrayIndexIn_lent(v_a_242, heff_box_word(v_i_241), 2);
      V v_t_244 = heff_tr(heff_call(heff_dup(heff_rfield(v_k_240, 1)), 1, (V[]){v_t2_243}));
      V t_0 = v_k_240;
      int64_t t_1 = (v_i_241 + ((int64_t)1ULL));
      V t_2 = heff_arraySetOwnedIn(v_a_242, heff_box_word(v_i_241), v_t_244);
      v_k_240 = t_0;
      v_i_241 = t_1;
      v_a_242 = t_2;
      goto top_TAG_InRange;
    } else {
      return v_a_242;
    }
  } else {
  }
top: ;
  if ((v_i_241 < heff_unbox_word(heff_arrayLength_lent(v_a_242, 0)))) {
    V v_t2_243 = heff_arrayIndex_lent(v_a_242, heff_box_word(v_i_241), 2);
    V v_t_244 = heff_tr(heff_call(heff_dup(heff_rfield(v_k_240, 1)), 1, (V[]){v_t2_243}));
    V t_0 = v_k_240;
    int64_t t_1 = (v_i_241 + ((int64_t)1ULL));
    V t_2 = heff_arraySetOwned(v_a_242, heff_box_word(v_i_241), v_t_244);
    v_k_240 = t_0;
    v_i_241 = t_1;
    v_a_242 = t_2;
    goto top;
  } else {
    return v_a_242;
  }
}
V g_heff_2eelab_2erename_2erenameTypeF_24map2_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2erename_2erenameTypeF_24map2(a0, a[1], a[2]); heff_drop(a0); return r;
}
V g_heff_2eelab_2erename_2erenameTypeF_24generate3_lam0(V self, V *args); static Clo g_heff_2eelab_2erename_2erenameTypeF_24generate3_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erename_2erenameTypeF_24generate3_lam0, 1, 0};
V g_heff_2eelab_2erename_2erenameTypeF_24generate3_lam1(V self, V *args); static Clo g_heff_2eelab_2erename_2erenameTypeF_24generate3_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erename_2erenameTypeF_24generate3_lam1, 1, 0};
Clo g_heff_2eelab_2erename_2erenameTypeF_24generate3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erename_2erenameTypeF_24generate3_entry, 4, 0};

V g_heff_2eelab_2erename_2erenameTypeF_24generate3(V v_xs_240, V v_k_241, V v_box_24i_242, V v_a_243) {
  int64_t v_i_242 = heff_unbox_word(v_box_24i_242);
  v_a_243 = heff_arrayOwn(v_a_243);
  if (((((int64_t)0ULL) <= v_i_242) && (heff_unbox_word(heff_arrayLength_lent(v_a_243, 0)) <= heff_unbox_word(heff_arrayLength_lent(v_xs_240, 0))))) {
    top_TAG_InRange: ;
    if ((v_i_242 < heff_unbox_word(heff_arrayLength_lent(v_a_243, 0)))) {
      V v_xs_244 = heff_arrayIndexIn_lent(v_xs_240, heff_box_word(v_i_242), 2);
      V v_m_245 = heff_arrayLength_lent(v_xs_244, 0);
      V v_t_2410;
      if ((heff_peek_word(v_m_245) <= ((int64_t)0ULL))) {
        heff_drop(v_xs_244);
        v_t_2410 = heff_arrayGenerate(v_m_245, ((V)&g_heff_2eelab_2erename_2erenameTypeF_24generate3_lam0_clo));
      } else {
        V v_t2_247 = heff_arrayIndex_lent(v_xs_244, MK_INT(0LL), 2);
        V v_y_248 = heff_tr(heff_call(heff_dup(heff_rfield(v_k_241, 1)), 1, (V[]){v_t2_247}));
        V v_t_249 = heff_arrayKeepsAs_lent(v_xs_244, v_y_248, 0);
        if ((heff_dup(v_t_249) == NTAG(TAG_True))) {
          heff_drop(v_m_245);
          heff_drop(v_t_249);
          v_t_2410 = (g_heff_2eelab_2erename_2erenameTypeF_24map2(v_k_241, MK_INT(1LL), heff_arraySet(v_xs_244, MK_INT(0LL), v_y_248)));
        } else {
          heff_drop(v_t_249);
          v_t_2410 = ({ V a_0 = v_xs_244; V a_1 = v_k_241; V a_2 = MK_INT(1LL); V a_3 = heff_arrayReplicate(v_m_245, v_y_248); V r_ = (g_heff_2eelab_2erename_2erenameTypeF_24generate2(a_0, a_1, a_2, a_3)); heff_drop(v_xs_244); r_; });
        }
      }
      V t_0 = v_xs_240;
      V t_1 = v_k_241;
      int64_t t_2 = (v_i_242 + ((int64_t)1ULL));
      V t_3 = heff_arraySetOwnedIn(v_a_243, heff_box_word(v_i_242), v_t_2410);
      v_xs_240 = t_0;
      v_k_241 = t_1;
      v_i_242 = t_2;
      v_a_243 = t_3;
      goto top_TAG_InRange;
    } else {
      return v_a_243;
    }
  } else {
  }
top: ;
  if ((v_i_242 < heff_unbox_word(heff_arrayLength_lent(v_a_243, 0)))) {
    V v_xs_244 = heff_arrayIndex_lent(v_xs_240, heff_box_word(v_i_242), 2);
    V v_m_245 = heff_arrayLength_lent(v_xs_244, 0);
    V v_t_2410;
    if ((heff_peek_word(v_m_245) <= ((int64_t)0ULL))) {
      heff_drop(v_xs_244);
      v_t_2410 = heff_arrayGenerate(v_m_245, ((V)&g_heff_2eelab_2erename_2erenameTypeF_24generate3_lam1_clo));
    } else {
      V v_t2_247 = heff_arrayIndex_lent(v_xs_244, MK_INT(0LL), 2);
      V v_y_248 = heff_tr(heff_call(heff_dup(heff_rfield(v_k_241, 1)), 1, (V[]){v_t2_247}));
      V v_t_249 = heff_arrayKeepsAs_lent(v_xs_244, v_y_248, 0);
      if ((heff_dup(v_t_249) == NTAG(TAG_True))) {
        heff_drop(v_m_245);
        heff_drop(v_t_249);
        v_t_2410 = (g_heff_2eelab_2erename_2erenameTypeF_24map2(v_k_241, MK_INT(1LL), heff_arraySet(v_xs_244, MK_INT(0LL), v_y_248)));
      } else {
        heff_drop(v_t_249);
        v_t_2410 = ({ V a_0 = v_xs_244; V a_1 = v_k_241; V a_2 = MK_INT(1LL); V a_3 = heff_arrayReplicate(v_m_245, v_y_248); V r_ = (g_heff_2eelab_2erename_2erenameTypeF_24generate2(a_0, a_1, a_2, a_3)); heff_drop(v_xs_244); r_; });
      }
    }
    V t_0 = v_xs_240;
    V t_1 = v_k_241;
    int64_t t_2 = (v_i_242 + ((int64_t)1ULL));
    V t_3 = heff_arraySetOwned(v_a_243, heff_box_word(v_i_242), v_t_2410);
    v_xs_240 = t_0;
    v_k_241 = t_1;
    v_i_242 = t_2;
    v_a_243 = t_3;
    goto top;
  } else {
    return v_a_243;
  }
}
V g_heff_2eelab_2erename_2erenameTypeF_24generate3_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2eelab_2erename_2erenameTypeF_24generate3(a0, a1, a[2], a[3]); heff_drop(a0); heff_drop(a1); return r;
}
V g_heff_2eelab_2erename_2erenameTypeF_24generate3_lam0(V self, V *args) {
  V v_u_246 = args[0];
  heff_drop(v_u_246);
  return heff_abandon();
}
V g_heff_2eelab_2erename_2erenameTypeF_24generate3_lam1(V self, V *args) {
  V v_u_246 = args[0];
  heff_drop(v_u_246);
  return heff_abandon();
}
V g_heff_2eelab_2erename_2erenameTypeF_24map3_lam0(V self, V *args); static Clo g_heff_2eelab_2erename_2erenameTypeF_24map3_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erename_2erenameTypeF_24map3_lam0, 1, 0};
V g_heff_2eelab_2erename_2erenameTypeF_24map3_lam1(V self, V *args); static Clo g_heff_2eelab_2erename_2erenameTypeF_24map3_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erename_2erenameTypeF_24map3_lam1, 1, 0};
Clo g_heff_2eelab_2erename_2erenameTypeF_24map3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erename_2erenameTypeF_24map3_entry, 3, 0};

V g_heff_2eelab_2erename_2erenameTypeF_24map3(V v_k_240, V v_box_24i_241, V v_a_242) {
  int64_t v_i_241 = heff_unbox_word(v_box_24i_241);
  v_a_242 = heff_arrayOwn(v_a_242);
  if ((((int64_t)0ULL) <= v_i_241)) {
    top_TAG_InRange: ;
    if ((v_i_241 < heff_unbox_word(heff_arrayLength_lent(v_a_242, 0)))) {
      V v_xs_243 = heff_arrayIndexIn_lent(v_a_242, heff_box_word(v_i_241), 2);
      V v_m_244 = heff_arrayLength_lent(v_xs_243, 0);
      V v_t_249;
      if ((heff_peek_word(v_m_244) <= ((int64_t)0ULL))) {
        heff_drop(v_xs_243);
        v_t_249 = heff_arrayGenerate(v_m_244, ((V)&g_heff_2eelab_2erename_2erenameTypeF_24map3_lam0_clo));
      } else {
        V v_t2_246 = heff_arrayIndex_lent(v_xs_243, MK_INT(0LL), 2);
        V v_y_247 = heff_tr(heff_call(heff_dup(heff_rfield(v_k_240, 1)), 1, (V[]){v_t2_246}));
        V v_t_248 = heff_arrayKeepsAs_lent(v_xs_243, v_y_247, 0);
        if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
          heff_drop(v_m_244);
          heff_drop(v_t_248);
          v_t_249 = (g_heff_2eelab_2erename_2erenameTypeF_24map2(v_k_240, MK_INT(1LL), heff_arraySet(v_xs_243, MK_INT(0LL), v_y_247)));
        } else {
          heff_drop(v_t_248);
          v_t_249 = ({ V a_0 = v_xs_243; V a_1 = v_k_240; V a_2 = MK_INT(1LL); V a_3 = heff_arrayReplicate(v_m_244, v_y_247); V r_ = (g_heff_2eelab_2erename_2erenameTypeF_24generate2(a_0, a_1, a_2, a_3)); heff_drop(v_xs_243); r_; });
        }
      }
      V t_0 = v_k_240;
      int64_t t_1 = (v_i_241 + ((int64_t)1ULL));
      V t_2 = heff_arraySetOwnedIn(v_a_242, heff_box_word(v_i_241), v_t_249);
      v_k_240 = t_0;
      v_i_241 = t_1;
      v_a_242 = t_2;
      goto top_TAG_InRange;
    } else {
      return v_a_242;
    }
  } else {
  }
top: ;
  if ((v_i_241 < heff_unbox_word(heff_arrayLength_lent(v_a_242, 0)))) {
    V v_xs_243 = heff_arrayIndex_lent(v_a_242, heff_box_word(v_i_241), 2);
    V v_m_244 = heff_arrayLength_lent(v_xs_243, 0);
    V v_t_249;
    if ((heff_peek_word(v_m_244) <= ((int64_t)0ULL))) {
      heff_drop(v_xs_243);
      v_t_249 = heff_arrayGenerate(v_m_244, ((V)&g_heff_2eelab_2erename_2erenameTypeF_24map3_lam1_clo));
    } else {
      V v_t2_246 = heff_arrayIndex_lent(v_xs_243, MK_INT(0LL), 2);
      V v_y_247 = heff_tr(heff_call(heff_dup(heff_rfield(v_k_240, 1)), 1, (V[]){v_t2_246}));
      V v_t_248 = heff_arrayKeepsAs_lent(v_xs_243, v_y_247, 0);
      if ((heff_dup(v_t_248) == NTAG(TAG_True))) {
        heff_drop(v_m_244);
        heff_drop(v_t_248);
        v_t_249 = (g_heff_2eelab_2erename_2erenameTypeF_24map2(v_k_240, MK_INT(1LL), heff_arraySet(v_xs_243, MK_INT(0LL), v_y_247)));
      } else {
        heff_drop(v_t_248);
        v_t_249 = ({ V a_0 = v_xs_243; V a_1 = v_k_240; V a_2 = MK_INT(1LL); V a_3 = heff_arrayReplicate(v_m_244, v_y_247); V r_ = (g_heff_2eelab_2erename_2erenameTypeF_24generate2(a_0, a_1, a_2, a_3)); heff_drop(v_xs_243); r_; });
      }
    }
    V t_0 = v_k_240;
    int64_t t_1 = (v_i_241 + ((int64_t)1ULL));
    V t_2 = heff_arraySetOwned(v_a_242, heff_box_word(v_i_241), v_t_249);
    v_k_240 = t_0;
    v_i_241 = t_1;
    v_a_242 = t_2;
    goto top;
  } else {
    return v_a_242;
  }
}
V g_heff_2eelab_2erename_2erenameTypeF_24map3_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2erename_2erenameTypeF_24map3(a0, a[1], a[2]); heff_drop(a0); return r;
}
V g_heff_2eelab_2erename_2erenameTypeF_24map3_lam0(V self, V *args) {
  V v_u_245 = args[0];
  heff_drop(v_u_245);
  return heff_abandon();
}
V g_heff_2eelab_2erename_2erenameTypeF_24map3_lam1(V self, V *args) {
  V v_u_245 = args[0];
  heff_drop(v_u_245);
  return heff_abandon();
}
V g_heff_2eelab_2erename_2erkOf_24cpr_lam0(V self, V *args);
V g_heff_2eelab_2erename_2erkOf_24cpr_lam1(V self, V *args);

HeffT2 g_heff_2eelab_2erename_2erkOf_24cpr(V v_r_240) {
top: ;
  return ((HeffT2){{heff_clo_n(g_heff_2eelab_2erename_2erkOf_24cpr_lam0, 1, 1, (V[]){heff_dup(v_r_240)}), heff_clo_n(g_heff_2eelab_2erename_2erkOf_24cpr_lam1, 1, 1, (V[]){v_r_240})}});
}
V g_heff_2eelab_2erename_2erkOf_24cpr_lam0(V self, V *args) {
  V v_e_241 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_t_242 = (g_heff_2eelab_2erename_2erkOf(heff_dup(v_r_240)));
  heff_clo_take(self, 1);
  return (g_heff_2eelab_2erename_2erenameTermF(v_t_242, v_r_240, v_e_241));
}
V g_heff_2eelab_2erename_2erkOf_24cpr_lam1(V self, V *args) {
  V v_t_243 = args[0];
  V v_r_240 = heff_env(self)[0];
  V v_t_244 = (g_heff_2eelab_2erename_2erkOf(heff_dup(v_r_240)));
  heff_clo_take(self, 1);
  return ({ V a_0 = v_t_244; V a_1 = v_r_240; V a_2 = v_t_243; V r_ = (g_heff_2eelab_2erename_2erenameTypeF(a_0, a_1, a_2)); heff_drop(v_r_240); r_; });
}
Clo g_heff_2eelab_2erename_2erkOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erename_2erkOf_entry, 1, 0};

V g_heff_2eelab_2erename_2erkOf(V v_r_240) {
top: ;
  HeffT2 v_t_241 = (g_heff_2eelab_2erename_2erkOf_24cpr(v_r_240));
  {
    V v_field_242 = v_t_241.f[0];
    V v_field_243 = v_t_241.f[1];
    return heff_rec_n(2, shape_el__ty, (V[]){v_field_242, v_field_243});
  }
}
V g_heff_2eelab_2erename_2erkOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erename_2erkOf(a[0]);
}
HEFF_LIT(g_heff_2eelab_2erename_2edescribeKey_str0, 2, "#T");
HEFF_LIT(g_heff_2eelab_2erename_2edescribeKey_str1, 14, "the theory of ");
HEFF_LIT(g_heff_2eelab_2erename_2edescribeKey_str2, 1, "#");
HEFF_LIT(g_heff_2eelab_2erename_2edescribeKey_str3, 11, "the module ");
Clo g_heff_2eelab_2erename_2edescribeKey_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erename_2edescribeKey_entry, 1, 0};

V g_heff_2eelab_2erename_2edescribeKey(V v_x_240) {
top: ;
  int64_t v_t_241 = (heff_unbox_word(heff_strLength_lent(v_x_240, 0)) - ((int64_t)2ULL));
  V v_t_242 = heff_strSlice_lent(v_x_240, heff_box_word(v_t_241), heff_strLength_lent(v_x_240, 0), 6);
  if (heff_strEq_c(v_t_242, ((V)&g_heff_2eelab_2erename_2edescribeKey_str0))) {
    int64_t v_t_243 = (heff_unbox_word(heff_strLength_lent(v_x_240, 0)) - ((int64_t)2ULL));
    return heff_strAppend(((V)&g_heff_2eelab_2erename_2edescribeKey_str1), heff_strSlice(v_x_240, MK_INT(0LL), heff_box_word(v_t_243)));
  } else {
    int64_t v_t_244 = (heff_unbox_word(heff_strLength_lent(v_x_240, 0)) - ((int64_t)1ULL));
    V v_t_245 = heff_strSlice_lent(v_x_240, heff_box_word(v_t_244), heff_strLength_lent(v_x_240, 0), 6);
    if (heff_strEq_c(v_t_245, ((V)&g_heff_2eelab_2erename_2edescribeKey_str2))) {
      int64_t v_t_246 = (heff_unbox_word(heff_strLength_lent(v_x_240, 0)) - ((int64_t)1ULL));
      return heff_strAppend(((V)&g_heff_2eelab_2erename_2edescribeKey_str3), heff_strSlice(v_x_240, MK_INT(0LL), heff_box_word(v_t_246)));
    } else {
      return v_x_240;
    }
  }
}
V g_heff_2eelab_2erename_2edescribeKey_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erename_2edescribeKey(a[0]);
}
Clo g_heff_2eelab_2erename_2enubFirst_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erename_2enubFirst_entry, 1, 0};

V g_heff_2eelab_2erename_2enubFirst(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x1_240, 0);
    V v_xs_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_243 = (g_list_2ekeepIf_24s930188071x496633547(v_x_241, v_xs_242));
    V v_cell_244 = heff_tag_re_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_x_241, heff_hole()});
    V v_u_245 = (g_heff_2eelab_2erename_2enubFirst_24dps(v_t_243, v_cell_244));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2erename_2enubFirst_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erename_2enubFirst(a[0]);
}
Clo g_heff_2eelab_2erename_2enubFirst_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erename_2enubFirst_24dps_entry, 2, 0};

V g_heff_2eelab_2erename_2enubFirst_24dps(V v_x1_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(heff_dup(v_d_241), MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_244 = (g_list_2ekeepIf_24s930188071x496633547(v_x_242, v_xs_243));
    V v_cell_245 = heff_tag_re_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, 1ULL, (V[]){v_x_242, heff_hole()});
    V v_u_246 = heff_setFieldPeek(v_d_241, MK_INT(1LL), v_cell_245);
    V t_0 = v_t_244;
    V t_1 = v_u_246;
    v_x1_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2erename_2enubFirst_24dps_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2erename_2enubFirst_24dps(a[0], a1); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2eelab_2erename_2eglobalsTypeF_24s916342050x850586824_24cycle_str0, 0, "");
HEFF_LIT(g_heff_2eelab_2erename_2eglobalsTypeF_24s916342050x850586824_24cycle_str1, 0, "");
HEFF_LIT(g_heff_2eelab_2erename_2eglobalsTypeF_24s916342050x850586824_24cycle_str2, 0, "");
Clo g_heff_2eelab_2erename_2eglobalsTypeF_24s916342050x850586824_24cycle_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erename_2eglobalsTypeF_24s916342050x850586824_24cycle_entry, 3, 0};

V g_heff_2eelab_2erename_2eglobalsTypeF_24s916342050x850586824_24cycle(V v_tag_240, V v_t_241, V v_e_242) {
top: ;
  switch (heff_tag_of(v_tag_240)) {
  case TAG_Enter_24heff_2eelab_2erename_2eglobalsTypeF_24s916342050x850586824: {
    top_TAG_Enter_24heff_2eelab_2erename_2eglobalsTypeF_24s916342050x850586824: ;
    switch (heff_tag_of(v_t_241)) {
    case TAG_SU: {
      return NTAG(TAG_Nil);
    }
    case TAG_SDecode: {
      V v_e_244 = heff_field(v_t_241, 0);
      V t_0 = NTAG(TAG_Enter_24heff_2eelab_2erename_2eglobalsTermF_24s304344999x537615372);
      V t_1 = ((V)&g_heff_2eelab_2erename_2eglobalsTypeF_24s916342050x850586824_24cycle_str0);
      V t_2 = v_e_244;
      v_tag_240 = t_0;
      v_t_241 = t_1;
      v_e_242 = t_2;
      goto top_TAG_Enter_24heff_2eelab_2erename_2eglobalsTermF_24s304344999x537615372;
    }
    case TAG_SFunction: {
      V v_dom_246 = heff_field(v_t_241, 1);
      V v_cod_247 = heff_field(v_t_241, 2);
      V v_dflt_249 = heff_field(v_t_241, 4);
      V v_t_2410 = (g_heff_2eelab_2erename_2eglobalsTypeF_24s916342050x850586824(v_dom_246));
      V v_t_2414;
      switch (heff_tag_of(v_cod_247)) {
      case TAG_MkAbs: {
        V v_t_2412 = heff_field(v_cod_247, 1);
        v_t_2414 = (g_heff_2eelab_2erename_2eglobalsTypeF_24s916342050x850586824(v_t_2412));
        break;
      }
      case TAG_AbsConst: {
        V v_t_2413 = heff_field(v_cod_247, 0);
        v_t_2414 = (g_heff_2eelab_2erename_2eglobalsTypeF_24s916342050x850586824(v_t_2413));
        break;
      }
      default: heff_nomatch(v_cod_247);
      }
      V v_t_2416;
      switch (heff_tag_of(v_dflt_249)) {
      case TAG_Nothing: {
        v_t_2416 = NTAG(TAG_Nil);
        break;
      }
      case TAG_Just: {
        V v_d_2415 = heff_field(v_dflt_249, 0);
        v_t_2416 = (g_heff_2eelab_2erename_2eglobalsTermF_24s304344999x537615372(v_d_2415));
        break;
      }
      default: heff_nomatch(v_dflt_249);
      }
      V v_t_2417 = (g_prelude_2e_2b_2b(v_t_2414, v_t_2416));
      return (g_prelude_2e_2b_2b(v_t_2410, v_t_2417));
    }
    case TAG_SRecord: {
      V v_fs_2419 = heff_field(v_t_241, 1);
      V v_ds_2420 = heff_field(v_t_241, 2);
      V v_keys_2421 = heff_dup(heff_rfield(v_ds_2420, 0));
      V v_values_2422 = heff_dup(heff_rfield(v_ds_2420, 2));
      V v_keys_2423 = heff_dup(heff_rfield(v_fs_2419, 0));
      V v_values_2424 = heff_dup(heff_rfield(v_fs_2419, 2));
      V v_t_2425 = (g_list_2efoldl_24f1625738412x188935108(NTAG(TAG_Nil), heff_arrayToList(v_keys_2423), heff_arrayToList(v_values_2424)));
      V v_t_2426 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2425; V r_ = (g_list_2efoldl_24s978059622x523571930(a_0, a_1)); heff_drop(v_t_2425); r_; });
      V v_t_2427 = (g_list_2efoldl_24f1625738412x188935108(NTAG(TAG_Nil), heff_arrayToList(v_keys_2421), heff_arrayToList(v_values_2422)));
      V v_t_2428 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2427; V r_ = (g_list_2efoldl_24s1606891938x229778616(a_0, a_1)); heff_drop(v_t_2427); r_; });
      return (g_prelude_2e_2b_2b(v_t_2426, v_t_2428));
    }
    case TAG_SSum: {
      V v_vs_2429 = heff_field(v_t_241, 0);
      V v_keys_2430 = heff_dup(heff_rfield(v_vs_2429, 0));
      V v_values_2431 = heff_dup(heff_rfield(v_vs_2429, 2));
      V v_t_2432 = (g_list_2efoldl_24f1625738412x188935108(NTAG(TAG_Nil), heff_arrayToList(v_keys_2430), heff_arrayToList(v_values_2431)));
      return ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2432; V r_ = (g_list_2efoldl_24s797527640x986490519(a_0, a_1)); heff_drop(v_t_2432); r_; });
    }
    case TAG_SIsTy: {
      V v_t2_2433 = heff_field(v_t_241, 0);
      V t_0 = NTAG(TAG_Enter_24heff_2eelab_2erename_2eglobalsTypeF_24s916342050x850586824);
      V t_1 = v_t2_2433;
      V t_2 = v_e_242;
      v_tag_240 = t_0;
      v_t_241 = t_1;
      v_e_242 = t_2;
      goto top_TAG_Enter_24heff_2eelab_2erename_2eglobalsTypeF_24s916342050x850586824;
    }
    case TAG_SPrimInt: {
      return NTAG(TAG_Nil);
    }
    case TAG_SPrimFloat: {
      return NTAG(TAG_Nil);
    }
    case TAG_SPrimString: {
      return NTAG(TAG_Nil);
    }
    case TAG_SPrimRune: {
      return NTAG(TAG_Nil);
    }
    case TAG_SPrimArray: {
      V v_t2_2434 = heff_field(v_t_241, 0);
      V t_0 = NTAG(TAG_Enter_24heff_2eelab_2erename_2eglobalsTypeF_24s916342050x850586824);
      V t_1 = v_t2_2434;
      V t_2 = v_e_242;
      v_tag_240 = t_0;
      v_t_241 = t_1;
      v_e_242 = t_2;
      goto top_TAG_Enter_24heff_2eelab_2erename_2eglobalsTypeF_24s916342050x850586824;
    }
    case TAG_SFixed: {
      return NTAG(TAG_Nil);
    }
    default: return heff_nomatch(v_t_241);
    }
  }
  case TAG_Enter_24heff_2eelab_2erename_2eglobalsTermF_24s304344999x537615372: {
    top_TAG_Enter_24heff_2eelab_2erename_2eglobalsTermF_24s304344999x537615372: ;
    switch (heff_tag_of(v_e_242)) {
    case TAG_SLocal: {
      return NTAG(TAG_Nil);
    }
    case TAG_SGlobal: {
      V v_x_2437 = heff_field(v_e_242, 0);
      return heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_x_2437), NTAG(TAG_Nil)});
    }
    case TAG_SCode: {
      V v_t_2438 = heff_field(v_e_242, 0);
      V t_0 = NTAG(TAG_Enter_24heff_2eelab_2erename_2eglobalsTypeF_24s916342050x850586824);
      V t_1 = v_t_2438;
      V t_2 = ((V)&g_heff_2eelab_2erename_2eglobalsTypeF_24s916342050x850586824_24cycle_str1);
      v_tag_240 = t_0;
      v_t_241 = t_1;
      v_e_242 = t_2;
      goto top_TAG_Enter_24heff_2eelab_2erename_2eglobalsTypeF_24s916342050x850586824;
    }
    case TAG_SApp: {
      V v_f_2439 = heff_field(v_e_242, 0);
      V v_a_2440 = heff_field(v_e_242, 1);
      V v_t_2441 = (g_heff_2eelab_2erename_2eglobalsTermF_24s304344999x537615372(v_f_2439));
      V v_t_2442 = (g_heff_2eelab_2erename_2eglobalsTermF_24s304344999x537615372(v_a_2440));
      return (g_prelude_2e_2b_2b(v_t_2441, v_t_2442));
    }
    case TAG_SLam: {
      V v_d_2443 = heff_field(v_e_242, 0);
      V v_b_2444 = heff_field(v_e_242, 1);
      V v_t_2445 = (g_heff_2eelab_2erename_2eglobalsTypeF_24s916342050x850586824(v_d_2443));
      V v_t_2449;
      switch (heff_tag_of(v_b_2444)) {
      case TAG_MkAbs: {
        V v_t_2447 = heff_field(v_b_2444, 1);
        v_t_2449 = (g_heff_2eelab_2erename_2eglobalsTermF_24s304344999x537615372(v_t_2447));
        break;
      }
      case TAG_AbsConst: {
        V v_t_2448 = heff_field(v_b_2444, 0);
        v_t_2449 = (g_heff_2eelab_2erename_2eglobalsTermF_24s304344999x537615372(v_t_2448));
        break;
      }
      default: heff_nomatch(v_b_2444);
      }
      return (g_prelude_2e_2b_2b(v_t_2445, v_t_2449));
    }
    case TAG_SCons: {
      V v_d_2450 = heff_field(v_e_242, 0);
      V v_keys_2451 = heff_dup(heff_rfield(v_d_2450, 0));
      V v_values_2452 = heff_dup(heff_rfield(v_d_2450, 2));
      V v_t_2453 = (g_list_2efoldl_24f1625738412x188935108(NTAG(TAG_Nil), heff_arrayToList(v_keys_2451), heff_arrayToList(v_values_2452)));
      return ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2453; V r_ = (g_list_2efoldl_24s1606891938x229778616(a_0, a_1)); heff_drop(v_t_2453); r_; });
    }
    case TAG_SProj: {
      V v_e2_2454 = heff_field(v_e_242, 0);
      V t_0 = NTAG(TAG_Enter_24heff_2eelab_2erename_2eglobalsTermF_24s304344999x537615372);
      V t_1 = v_t_241;
      V t_2 = v_e2_2454;
      v_tag_240 = t_0;
      v_t_241 = t_1;
      v_e_242 = t_2;
      goto top_TAG_Enter_24heff_2eelab_2erename_2eglobalsTermF_24s304344999x537615372;
    }
    case TAG_STag: {
      V v_args_2457 = heff_field(v_e_242, 1);
      V v_t_2458 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_arrayToList(heff_dup(v_args_2457))));
      return ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2458; V r_ = (g_list_2efoldl_24s865198748x12535471(a_0, a_1)); heff_drop(v_t_2458); r_; });
    }
    case TAG_SMatch: {
      V v_e2_2459 = heff_field(v_e_242, 0);
      V v_cs_2460 = heff_field(v_e_242, 1);
      V v_keys_2461 = heff_dup(heff_rfield(v_cs_2460, 0));
      V v_values_2462 = heff_dup(heff_rfield(v_cs_2460, 2));
      V v_t_2463 = (g_heff_2eelab_2erename_2eglobalsTermF_24s304344999x537615372(v_e2_2459));
      V v_t_2464 = (g_list_2efoldl_24f1625738412x188935108(NTAG(TAG_Nil), heff_arrayToList(v_keys_2461), heff_arrayToList(v_values_2462)));
      V v_t_2465 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2464; V r_ = (g_list_2efoldl_24s522807745x1556762248(a_0, a_1)); heff_drop(v_t_2464); r_; });
      return (g_prelude_2e_2b_2b(v_t_2463, v_t_2465));
    }
    case TAG_SSpecialize: {
      V v_e2_2466 = heff_field(v_e_242, 0);
      V v_v_2468 = heff_field(v_e_242, 2);
      V v_t_2469 = (g_heff_2eelab_2erename_2eglobalsTermF_24s304344999x537615372(v_e2_2466));
      V v_t_2470 = (g_heff_2eelab_2erename_2eglobalsTermF_24s304344999x537615372(v_v_2468));
      return (g_prelude_2e_2b_2b(v_t_2469, v_t_2470));
    }
    case TAG_SIs: {
      V v_e2_2471 = heff_field(v_e_242, 0);
      V t_0 = NTAG(TAG_Enter_24heff_2eelab_2erename_2eglobalsTermF_24s304344999x537615372);
      V t_1 = v_t_241;
      V t_2 = v_e2_2471;
      v_tag_240 = t_0;
      v_t_241 = t_1;
      v_e_242 = t_2;
      goto top_TAG_Enter_24heff_2eelab_2erename_2eglobalsTermF_24s304344999x537615372;
    }
    case TAG_SOpaque: {
      return NTAG(TAG_Nil);
    }
    case TAG_SAbandon: {
      return NTAG(TAG_Nil);
    }
    case TAG_SRec: {
      V v_e2_2472 = heff_field(v_e_242, 0);
      V t_0 = NTAG(TAG_Enter_24heff_2eelab_2erename_2eglobalsTermF_24s304344999x537615372);
      V t_1 = v_t_241;
      V t_2 = v_e2_2472;
      v_tag_240 = t_0;
      v_t_241 = t_1;
      v_e_242 = t_2;
      goto top_TAG_Enter_24heff_2eelab_2erename_2eglobalsTermF_24s304344999x537615372;
    }
    case TAG_SFix: {
      V v_d_2473 = heff_field(v_e_242, 0);
      V v_b_2474 = heff_field(v_e_242, 1);
      V v_t_2475 = (g_heff_2eelab_2erename_2eglobalsTypeF_24s916342050x850586824(v_d_2473));
      V v_t_2479;
      switch (heff_tag_of(v_b_2474)) {
      case TAG_MkAbs: {
        V v_t_2477 = heff_field(v_b_2474, 1);
        v_t_2479 = (g_heff_2eelab_2erename_2eglobalsTermF_24s304344999x537615372(v_t_2477));
        break;
      }
      case TAG_AbsConst: {
        V v_t_2478 = heff_field(v_b_2474, 0);
        v_t_2479 = (g_heff_2eelab_2erename_2eglobalsTermF_24s304344999x537615372(v_t_2478));
        break;
      }
      default: heff_nomatch(v_b_2474);
      }
      return (g_prelude_2e_2b_2b(v_t_2475, v_t_2479));
    }
    case TAG_SImplicit: {
      V v_e2_2481 = heff_field(v_e_242, 1);
      V t_0 = NTAG(TAG_Enter_24heff_2eelab_2erename_2eglobalsTermF_24s304344999x537615372);
      V t_1 = v_t_241;
      V t_2 = v_e2_2481;
      v_tag_240 = t_0;
      v_t_241 = t_1;
      v_e_242 = t_2;
      goto top_TAG_Enter_24heff_2eelab_2erename_2eglobalsTermF_24s304344999x537615372;
    }
    case TAG_SPrim: {
      return NTAG(TAG_Nil);
    }
    case TAG_SMetaApp: {
      V v_t_2485 = heff_field(v_e_242, 2);
      V t_0 = NTAG(TAG_Enter_24heff_2eelab_2erename_2eglobalsTypeF_24s916342050x850586824);
      V t_1 = v_t_2485;
      V t_2 = ((V)&g_heff_2eelab_2erename_2eglobalsTypeF_24s916342050x850586824_24cycle_str2);
      v_tag_240 = t_0;
      v_t_241 = t_1;
      v_e_242 = t_2;
      goto top_TAG_Enter_24heff_2eelab_2erename_2eglobalsTypeF_24s916342050x850586824;
    }
    case TAG_SLitInt: {
      return NTAG(TAG_Nil);
    }
    case TAG_SLitFloat: {
      return NTAG(TAG_Nil);
    }
    case TAG_SLitString: {
      return NTAG(TAG_Nil);
    }
    case TAG_SLitBytes: {
      return NTAG(TAG_Nil);
    }
    case TAG_SLitRune: {
      return NTAG(TAG_Nil);
    }
    case TAG_SLitFixed: {
      return NTAG(TAG_Nil);
    }
    case TAG_SLitFloat32: {
      return NTAG(TAG_Nil);
    }
    default: return heff_nomatch(v_e_242);
    }
  }
  default: return heff_nomatch(v_tag_240);
  }
}
V g_heff_2eelab_2erename_2eglobalsTypeF_24s916342050x850586824_24cycle_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V a2 = a[2]; V r = g_heff_2eelab_2erename_2eglobalsTypeF_24s916342050x850586824_24cycle(a0, a1, a2); heff_drop(a0); heff_drop(a1); heff_drop(a2); return r;
}
HEFF_LIT(g_heff_2eelab_2erename_2eglobalsTypeF_24s916342050x850586824_str0, 0, "");
Clo g_heff_2eelab_2erename_2eglobalsTypeF_24s916342050x850586824_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erename_2eglobalsTypeF_24s916342050x850586824_entry, 1, 0};

V g_heff_2eelab_2erename_2eglobalsTypeF_24s916342050x850586824(V v_t_240) {
top: ;
  return (g_heff_2eelab_2erename_2eglobalsTypeF_24s916342050x850586824_24cycle(NTAG(TAG_Enter_24heff_2eelab_2erename_2eglobalsTypeF_24s916342050x850586824), v_t_240, ((V)&g_heff_2eelab_2erename_2eglobalsTypeF_24s916342050x850586824_str0)));
}
V g_heff_2eelab_2erename_2eglobalsTypeF_24s916342050x850586824_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2erename_2eglobalsTypeF_24s916342050x850586824(a0); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2eelab_2erename_2eglobalsTermF_24s304344999x537615372_str0, 0, "");
Clo g_heff_2eelab_2erename_2eglobalsTermF_24s304344999x537615372_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erename_2eglobalsTermF_24s304344999x537615372_entry, 1, 0};

V g_heff_2eelab_2erename_2eglobalsTermF_24s304344999x537615372(V v_e_240) {
top: ;
  return (g_heff_2eelab_2erename_2eglobalsTypeF_24s916342050x850586824_24cycle(NTAG(TAG_Enter_24heff_2eelab_2erename_2eglobalsTermF_24s304344999x537615372), ((V)&g_heff_2eelab_2erename_2eglobalsTermF_24s304344999x537615372_str0), v_e_240));
}
V g_heff_2eelab_2erename_2eglobalsTermF_24s304344999x537615372_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2eelab_2erename_2eglobalsTermF_24s304344999x537615372(a0); heff_drop(a0); return r;
}

HeffT2 g_heff_2eelab_2erename_2efirstAliasOf_24cpr(V v_x1_240, V v_x_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_x11_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_MkPair: {
      V v_n_244 = heff_field(v_x11_242, 0);
      V v_k_245 = heff_field(v_x11_242, 1);
      if (heff_strEq_c_lent(v_k_245, v_x_241, 0)) {
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_n_244)}});
      } else {
        V t_0 = v_rest_243;
        V t_1 = v_x_241;
        v_x1_240 = t_0;
        v_x_241 = t_1;
        goto top;
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x11_242)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}