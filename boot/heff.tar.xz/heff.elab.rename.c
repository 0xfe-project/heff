// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_AbsConst 8406
#define TAG_Enter_24heff_2eelab_2erename_2eglobalsTermF_24s304344999x537615372 12157
#define TAG_Enter_24heff_2eelab_2erename_2eglobalsTypeF_24s916342050x850586824 10659
#define TAG_MkAbs 54862
#define TAG_SAbandon 23437
#define TAG_SApp 57081
#define TAG_SCode 58360
#define TAG_SCons 58684
#define TAG_SDecode 30927
#define TAG_SFix 61677
#define TAG_SFixed 29756
#define TAG_SFunction 64505
#define TAG_SGlobal 8650
#define TAG_SImplicit 59448
#define TAG_SIs 29577
#define TAG_SIsTy 43896
#define TAG_SLam 1658
#define TAG_SLitBytes 43891
#define TAG_SLitFixed 54374
#define TAG_SLitFloat 3938
#define TAG_SLitFloat32 41499
#define TAG_SLitInt 21439
#define TAG_SLitRune 21707
#define TAG_SLitString 62718
#define TAG_SLocal 28569
#define TAG_SMatch 27203
#define TAG_SMetaApp 2372
#define TAG_SOpaque 44226
#define TAG_SPrim 55533
#define TAG_SPrimArray 2913
#define TAG_SPrimFloat 48642
#define TAG_SPrimInt 22031
#define TAG_SPrimRune 40059
#define TAG_SPrimString 6970
#define TAG_SProj 55716
#define TAG_SRec 7538
#define TAG_SRecord 16932
#define TAG_SSpecialize 52996
#define TAG_SSum 9005
#define TAG_STag 9340
#define TAG_SU 9427
#define LBL_byName 571997869
#define LBL_el 9998
#define LBL_keys 9783995
#define LBL_ty 10476
#define LBL_values 1123329101
static uint32_t shape_el__ty[] = {LBL_el, LBL_ty};
static uint32_t shape_keys__byName__values[] = {LBL_keys, LBL_byName, LBL_values};
V g_heff_2eelab_2erename_2edescribeKey(V);
V g_heff_2eelab_2erename_2edescribeKey_entry(V self, V *a);
extern Clo g_heff_2eelab_2erename_2edescribeKey_clo;
HeffT2 g_heff_2eelab_2erename_2efirstAliasOf_24cpr(V, V);
V g_heff_2eelab_2erename_2eglobalsTermF_24s304344999x537615372(V);
V g_heff_2eelab_2erename_2eglobalsTermF_24s304344999x537615372_entry(V self, V *a);
extern Clo g_heff_2eelab_2erename_2eglobalsTermF_24s304344999x537615372_clo;
V g_heff_2eelab_2erename_2eglobalsTypeF_24s916342050x850586824(V);
V g_heff_2eelab_2erename_2eglobalsTypeF_24s916342050x850586824_entry(V self, V *a);
extern Clo g_heff_2eelab_2erename_2eglobalsTypeF_24s916342050x850586824_clo;
V g_heff_2eelab_2erename_2eglobalsTypeF_24s916342050x850586824_24cycle(V, V, V);
V g_heff_2eelab_2erename_2eglobalsTypeF_24s916342050x850586824_24cycle_entry(V self, V *a);
extern Clo g_heff_2eelab_2erename_2eglobalsTypeF_24s916342050x850586824_24cycle_clo;
V g_heff_2eelab_2erename_2enubFirst(V);
V g_heff_2eelab_2erename_2enubFirst_entry(V self, V *a);
extern Clo g_heff_2eelab_2erename_2enubFirst_clo;
V g_heff_2eelab_2erename_2enubFirst_24dps(V, V);
V g_heff_2eelab_2erename_2enubFirst_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2erename_2enubFirst_24dps_clo;
V g_heff_2eelab_2erename_2erenameTermF(V, V, V);
V g_heff_2eelab_2erename_2erenameTermF_entry(V self, V *a);
extern Clo g_heff_2eelab_2erename_2erenameTermF_clo;
V g_heff_2eelab_2erename_2erenameTypeF(V, V, V);
V g_heff_2eelab_2erename_2erenameTypeF_entry(V self, V *a);
extern Clo g_heff_2eelab_2erename_2erenameTypeF_clo;
V g_heff_2eelab_2erename_2erkOf(V);
V g_heff_2eelab_2erename_2erkOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2erename_2erkOf_clo;
V g_list_2efilter_24s727803713x1346936525(V, V);
V g_list_2efilter_24s727803713x1346936525_entry(V self, V *a);
extern Clo g_list_2efilter_24s727803713x1346936525_clo;
V g_list_2efoldl_24f1625738412x188935108(V, V, V);
V g_list_2efoldl_24f1625738412x188935108_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1625738412x188935108_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1606891938x229778616(V, V);
V g_list_2efoldl_24s1606891938x229778616_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1606891938x229778616_clo;
V g_list_2efoldl_24s522807745x1556762248(V, V);
V g_list_2efoldl_24s522807745x1556762248_entry(V self, V *a);
extern Clo g_list_2efoldl_24s522807745x1556762248_clo;
V g_list_2efoldl_24s797527640x986490519(V, V);
V g_list_2efoldl_24s797527640x986490519_entry(V self, V *a);
extern Clo g_list_2efoldl_24s797527640x986490519_clo;
V g_list_2efoldl_24s865198748x12535471(V, V);
V g_list_2efoldl_24s865198748x12535471_entry(V self, V *a);
extern Clo g_list_2efoldl_24s865198748x12535471_clo;
V g_list_2efoldl_24s978059622x523571930(V, V);
V g_list_2efoldl_24s978059622x523571930_entry(V self, V *a);
extern Clo g_list_2efoldl_24s978059622x523571930_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_heff_2eelab_2erename_2erenameTermF_lam0(V self, V *args);
V g_heff_2eelab_2erename_2erenameTermF_lam1(V self, V *args);
V g_heff_2eelab_2erename_2erenameTermF_lam2(V self, V *args);
Clo g_heff_2eelab_2erename_2erenameTermF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erename_2erenameTermF_entry, 3, 0};

V g_heff_2eelab_2erename_2erenameTermF(V v_k_240, V v_r_241, V v_e_242) {
top: ;
  switch (heff_tag_of(v_e_242)) {
  case TAG_SLocal: {
    heff_drop_rec(v_k_240, 2);
    heff_drop(v_r_241);
    return v_e_242;
  }
  case TAG_SGlobal: {
    V v_x_244 = heff_field(v_e_242, 0);
    V v_ru_24e_242_24SGlobal = heff_take_reuse_n(v_e_242, 1ULL, 1);
    heff_drop_rec(v_k_240, 2);
    V v_t_245 = heff_tr(heff_call(v_r_241, 1, (V[]){v_x_244}));
    return heff_tag_at_n(v_ru_24e_242_24SGlobal, TAG_SGlobal, 1, (V[]){v_t_245});
  }
  case TAG_SCode: {
    V v_t_246 = heff_field(v_e_242, 0);
    V v_ru_24e_242_24SCode = heff_take_reuse_n(v_e_242, 1ULL, 1);
    heff_drop(v_r_241);
    V v_t_247 = heff_tr(heff_call(heff_get_n(v_k_240, 1, 2), 1, (V[]){v_t_246}));
    return heff_tag_at_n(v_ru_24e_242_24SCode, TAG_SCode, 1, (V[]){v_t_247});
  }
  case TAG_SApp: {
    V v_f_248 = heff_field(v_e_242, 0);
    V v_a_249 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24SApp = heff_take_reuse_n(v_e_242, 3ULL, 2);
    heff_drop(v_r_241);
    V v_t_2410 = heff_tr(heff_call(heff_dup(heff_rfield(v_k_240, 0)), 1, (V[]){v_f_248}));
    V v_t_2411 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 2), 1, (V[]){v_a_249}));
    return heff_tag_at_n(v_ru_24e_242_24SApp, TAG_SApp, 2, (V[]){v_t_2410, v_t_2411});
  }
  case TAG_SLam: {
    V v_d_2412 = heff_field(v_e_242, 0);
    V v_b_2413 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24SLam = heff_take_reuse_n(v_e_242, 3ULL, 2);
    heff_drop(v_r_241);
    V v_t_2414 = heff_tr(heff_call(heff_take_field(v_k_240, 1), 1, (V[]){v_d_2412}));
    V v_t_2420;
    switch (heff_tag_of(v_b_2413)) {
    case TAG_MkAbs: {
      V v_x_2415 = heff_field(v_b_2413, 0);
      V v_t_2416 = heff_field(v_b_2413, 1);
      V v_ru_24b_2413_24MkAbs = heff_take_reuse_n(v_b_2413, 3ULL, 2);
      V v_t_2417 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 2), 1, (V[]){v_t_2416}));
      v_t_2420 = heff_tag_at_n(v_ru_24b_2413_24MkAbs, TAG_MkAbs, 2, (V[]){v_x_2415, v_t_2417});
      break;
    }
    case TAG_AbsConst: {
      V v_t_2418 = heff_field(v_b_2413, 0);
      V v_ru_24b_2413_24AbsConst = heff_take_reuse_n(v_b_2413, 1ULL, 1);
      V v_t_2419 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 2), 1, (V[]){v_t_2418}));
      v_t_2420 = heff_tag_at_n(v_ru_24b_2413_24AbsConst, TAG_AbsConst, 1, (V[]){v_t_2419});
      break;
    }
    default: heff_nomatch(v_b_2413);
    }
    return heff_tag_at_n(v_ru_24e_242_24SLam, TAG_SLam, 2, (V[]){v_t_2414, v_t_2420});
  }
  case TAG_SCons: {
    V v_d_2421 = heff_field(v_e_242, 0);
    V v_ru_24e_242_24SCons = heff_take_reuse_n(v_e_242, 1ULL, 1);
    heff_drop(v_r_241);
    V v_xs_2422 = heff_take_field(v_d_2421, 2);
    V v_t_2425 = heff_arrayGenerate(heff_arrayLength_lent(v_xs_2422, 0), heff_clo_n(g_heff_2eelab_2erename_2erenameTermF_lam0, 1, 2, (V[]){v_xs_2422, v_k_240}));
    V v_t_2426 = ({ V rv_2 = v_t_2425; V rr_ = heff_rec_reuse_nf(v_d_2421, 3ULL, 3, shape_keys__byName__values, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    return heff_tag_at_n(v_ru_24e_242_24SCons, TAG_SCons, 1, (V[]){v_t_2426});
  }
  case TAG_SProj: {
    V v_e2_2427 = heff_field(v_e_242, 0);
    V v_l_2428 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24SProj = heff_take_reuse_n(v_e_242, 3ULL, 2);
    heff_drop(v_r_241);
    V v_t_2429 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 2), 1, (V[]){v_e2_2427}));
    return heff_tag_at_n(v_ru_24e_242_24SProj, TAG_SProj, 2, (V[]){v_t_2429, v_l_2428});
  }
  case TAG_STag: {
    V v_t_2430 = heff_field(v_e_242, 0);
    V v_as_2431 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24STag = heff_take_reuse_n(v_e_242, 3ULL, 2);
    heff_drop(v_r_241);
    V v_t_2433 = (g_list_2emap(heff_clo_n(g_heff_2eelab_2erename_2erenameTermF_lam1, 1, 1, (V[]){v_k_240}), heff_arrayToList(v_as_2431)));
    return heff_tag_at_n(v_ru_24e_242_24STag, TAG_STag, 2, (V[]){v_t_2430, heff_arrayFromList(v_t_2433)});
  }
  case TAG_SMatch: {
    V v_e2_2434 = heff_field(v_e_242, 0);
    V v_cs_2435 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24SMatch = heff_take_reuse_n(v_e_242, 3ULL, 2);
    heff_drop(v_r_241);
    V v_t_2436 = heff_tr(heff_call(heff_dup(heff_rfield(v_k_240, 0)), 1, (V[]){v_e2_2434}));
    V v_xs_2437 = heff_take_field(v_cs_2435, 2);
    V v_t_2443 = heff_arrayGenerate(heff_arrayLength_lent(v_xs_2437, 0), heff_clo_n(g_heff_2eelab_2erename_2erenameTermF_lam2, 1, 2, (V[]){v_xs_2437, v_k_240}));
    V v_t_2444 = ({ V rv_2 = v_t_2443; V rr_ = heff_rec_reuse_nf(v_cs_2435, 3ULL, 3, shape_keys__byName__values, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    return heff_tag_at_n(v_ru_24e_242_24SMatch, TAG_SMatch, 2, (V[]){v_t_2436, v_t_2444});
  }
  case TAG_SSpecialize: {
    V v_e2_2445 = heff_field(v_e_242, 0);
    V v_l_2446 = heff_field(v_e_242, 1);
    V v_v_2447 = heff_field(v_e_242, 2);
    V v_ru_24e_242_24SSpecialize = heff_take_reuse_n(v_e_242, 7ULL, 3);
    heff_drop(v_r_241);
    V v_t_2448 = heff_tr(heff_call(heff_dup(heff_rfield(v_k_240, 0)), 1, (V[]){v_e2_2445}));
    V v_t_2449 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 2), 1, (V[]){v_v_2447}));
    return heff_tag_at_n(v_ru_24e_242_24SSpecialize, TAG_SSpecialize, 3, (V[]){v_t_2448, v_l_2446, v_t_2449});
  }
  case TAG_SIs: {
    V v_e2_2450 = heff_field(v_e_242, 0);
    V v_ru_24e_242_24SIs = heff_take_reuse_n(v_e_242, 1ULL, 1);
    heff_drop(v_r_241);
    V v_t_2451 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 2), 1, (V[]){v_e2_2450}));
    return heff_tag_at_n(v_ru_24e_242_24SIs, TAG_SIs, 1, (V[]){v_t_2451});
  }
  case TAG_SOpaque: {
    heff_drop_rec(v_k_240, 2);
    heff_drop(v_r_241);
    return v_e_242;
  }
  case TAG_SAbandon: {
    heff_drop_rec(v_k_240, 2);
    heff_drop(v_r_241);
    return v_e_242;
  }
  case TAG_SRec: {
    V v_e2_2452 = heff_field(v_e_242, 0);
    V v_ru_24e_242_24SRec = heff_take_reuse_n(v_e_242, 1ULL, 1);
    heff_drop(v_r_241);
    V v_t_2453 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 2), 1, (V[]){v_e2_2452}));
    return heff_tag_at_n(v_ru_24e_242_24SRec, TAG_SRec, 1, (V[]){v_t_2453});
  }
  case TAG_SFix: {
    V v_d_2454 = heff_field(v_e_242, 0);
    V v_b_2455 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24SFix = heff_take_reuse_n(v_e_242, 3ULL, 2);
    heff_drop(v_r_241);
    V v_t_2456 = heff_tr(heff_call(heff_take_field(v_k_240, 1), 1, (V[]){v_d_2454}));
    V v_t_2462;
    switch (heff_tag_of(v_b_2455)) {
    case TAG_MkAbs: {
      V v_x_2457 = heff_field(v_b_2455, 0);
      V v_t_2458 = heff_field(v_b_2455, 1);
      V v_ru_24b_2455_24MkAbs = heff_take_reuse_n(v_b_2455, 3ULL, 2);
      V v_t_2459 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 2), 1, (V[]){v_t_2458}));
      v_t_2462 = heff_tag_at_n(v_ru_24b_2455_24MkAbs, TAG_MkAbs, 2, (V[]){v_x_2457, v_t_2459});
      break;
    }
    case TAG_AbsConst: {
      V v_t_2460 = heff_field(v_b_2455, 0);
      V v_ru_24b_2455_24AbsConst = heff_take_reuse_n(v_b_2455, 1ULL, 1);
      V v_t_2461 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 2), 1, (V[]){v_t_2460}));
      v_t_2462 = heff_tag_at_n(v_ru_24b_2455_24AbsConst, TAG_AbsConst, 1, (V[]){v_t_2461});
      break;
    }
    default: heff_nomatch(v_b_2455);
    }
    return heff_tag_at_n(v_ru_24e_242_24SFix, TAG_SFix, 2, (V[]){v_t_2456, v_t_2462});
  }
  case TAG_SImplicit: {
    V v_x_2463 = heff_field(v_e_242, 0);
    V v_e2_2464 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24SImplicit = heff_take_reuse_n(v_e_242, 3ULL, 2);
    heff_drop(v_r_241);
    V v_t_2465 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 2), 1, (V[]){v_e2_2464}));
    return heff_tag_at_n(v_ru_24e_242_24SImplicit, TAG_SImplicit, 2, (V[]){v_x_2463, v_t_2465});
  }
  case TAG_SPrim: {
    heff_drop_rec(v_k_240, 2);
    heff_drop(v_r_241);
    return v_e_242;
  }
  case TAG_SMetaApp: {
    V v_m_2467 = heff_field(v_e_242, 0);
    V v_xs_2468 = heff_field(v_e_242, 1);
    V v_t_2469 = heff_field(v_e_242, 2);
    V v_ru_24e_242_24SMetaApp = heff_take_reuse_n(v_e_242, 7ULL, 3);
    heff_drop(v_r_241);
    V v_t_2470 = heff_tr(heff_call(heff_get_n(v_k_240, 1, 2), 1, (V[]){v_t_2469}));
    return heff_tag_at_n(v_ru_24e_242_24SMetaApp, TAG_SMetaApp, 3, (V[]){v_m_2467, v_xs_2468, v_t_2470});
  }
  case TAG_SLitInt: {
    heff_drop_rec(v_k_240, 2);
    heff_drop(v_r_241);
    return v_e_242;
  }
  case TAG_SLitFloat: {
    heff_drop_rec(v_k_240, 2);
    heff_drop(v_r_241);
    return v_e_242;
  }
  case TAG_SLitString: {
    heff_drop_rec(v_k_240, 2);
    heff_drop(v_r_241);
    return v_e_242;
  }
  case TAG_SLitBytes: {
    heff_drop_rec(v_k_240, 2);
    heff_drop(v_r_241);
    return v_e_242;
  }
  case TAG_SLitRune: {
    heff_drop_rec(v_k_240, 2);
    heff_drop(v_r_241);
    return v_e_242;
  }
  case TAG_SLitFixed: {
    heff_drop_rec(v_k_240, 2);
    heff_drop(v_r_241);
    return v_e_242;
  }
  case TAG_SLitFloat32: {
    heff_drop_rec(v_k_240, 2);
    heff_drop(v_r_241);
    return v_e_242;
  }
  default: return heff_nomatch(v_e_242);
  }
}
V g_heff_2eelab_2erename_2erenameTermF_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erename_2erenameTermF(a[0], a[1], a[2]);
}
V g_heff_2eelab_2erename_2erenameTermF_lam0(V self, V *args) {
  V v_i_2423 = args[0];
  V v_xs_2422 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_e2_2424 = heff_arrayIndex(v_xs_2422, v_i_2423);
  V f_ = heff_get_n(v_k_240, 0, 2);
  args[0] = v_e2_2424;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erename_2erenameTermF_lam1(V self, V *args) {
  V v_e2_2432 = args[0];
  V v_k_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_k_240, 0, 2);
  args[0] = v_e2_2432;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erename_2erenameTermF_lam2(V self, V *args) {
  V v_i_2438 = args[0];
  V v_xs_2437 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_p_2439 = heff_arrayIndex(v_xs_2437, v_i_2438);
  switch (heff_tag_of(v_p_2439)) {
  case TAG_MkPair: {
    V v_xs_2440 = heff_field(v_p_2439, 0);
    V v_b_2441 = heff_field(v_p_2439, 1);
    V v_ru_24p_2439_24MkPair = heff_take_reuse_n(v_p_2439, 3ULL, 2);
    V v_t_2442 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 2), 1, (V[]){v_b_2441}));
    return heff_tag_at_n(v_ru_24p_2439_24MkPair, TAG_MkPair, 2, (V[]){v_xs_2440, v_t_2442});
  }
  default: return heff_nomatch(v_p_2439);
  }
}
V g_heff_2eelab_2erename_2erenameTypeF_lam0(V self, V *args);
V g_heff_2eelab_2erename_2erenameTypeF_lam1(V self, V *args);
V g_heff_2eelab_2erename_2erenameTypeF_lam3(V self, V *args);
V g_heff_2eelab_2erename_2erenameTypeF_lam2(V self, V *args);
Clo g_heff_2eelab_2erename_2erenameTypeF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erename_2erenameTypeF_entry, 3, 0};

V g_heff_2eelab_2erename_2erenameTypeF(V v_k_240, V v_r_241, V v_t_242) {
top: ;
  switch (heff_tag_of(v_t_242)) {
  case TAG_SU: {
    heff_drop_rec(v_k_240, 2);
    return v_t_242;
  }
  case TAG_SDecode: {
    V v_e_244 = heff_field(v_t_242, 0);
    V v_ru_24t_242_24SDecode = heff_take_reuse_n(v_t_242, 1ULL, 1);
    V v_t_245 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 2), 1, (V[]){v_e_244}));
    return heff_tag_at_n(v_ru_24t_242_24SDecode, TAG_SDecode, 1, (V[]){v_t_245});
  }
  case TAG_SFunction: {
    V v_level_246 = heff_field(v_t_242, 0);
    V v_dom_247 = heff_field(v_t_242, 1);
    V v_cod_248 = heff_field(v_t_242, 2);
    V v_implicit_249 = heff_field(v_t_242, 3);
    V v_dflt_2410 = heff_field(v_t_242, 4);
    V v_ru_24t_242_24SFunction = heff_take_reuse_n(v_t_242, 31ULL, 5);
    V v_t_2411 = heff_tr(heff_call(heff_dup(heff_rfield(v_k_240, 1)), 1, (V[]){v_dom_247}));
    V v_t_2417;
    switch (heff_tag_of(v_cod_248)) {
    case TAG_MkAbs: {
      V v_x_2412 = heff_field(v_cod_248, 0);
      V v_t_2413 = heff_field(v_cod_248, 1);
      V v_ru_24cod_248_24MkAbs = heff_take_reuse_n(v_cod_248, 3ULL, 2);
      V v_t_2414 = heff_tr(heff_call(heff_dup(heff_rfield(v_k_240, 1)), 1, (V[]){v_t_2413}));
      v_t_2417 = heff_tag_at_n(v_ru_24cod_248_24MkAbs, TAG_MkAbs, 2, (V[]){v_x_2412, v_t_2414});
      break;
    }
    case TAG_AbsConst: {
      V v_t_2415 = heff_field(v_cod_248, 0);
      V v_ru_24cod_248_24AbsConst = heff_take_reuse_n(v_cod_248, 1ULL, 1);
      V v_t_2416 = heff_tr(heff_call(heff_dup(heff_rfield(v_k_240, 1)), 1, (V[]){v_t_2415}));
      v_t_2417 = heff_tag_at_n(v_ru_24cod_248_24AbsConst, TAG_AbsConst, 1, (V[]){v_t_2416});
      break;
    }
    default: heff_nomatch(v_cod_248);
    }
    V v_t_2420;
    switch (heff_tag_of(v_dflt_2410)) {
    case TAG_Nothing: {
      heff_drop_rec(v_k_240, 2);
      v_t_2420 = NTAG(TAG_Nothing);
      break;
    }
    case TAG_Just: {
      V v_d_2418 = heff_field(v_dflt_2410, 0);
      V v_ru_24dflt_2410_24Just = heff_take_reuse_n(v_dflt_2410, 1ULL, 1);
      V v_t_2419 = heff_tr(heff_call(heff_get_n(v_k_240, 0, 2), 1, (V[]){v_d_2418}));
      v_t_2420 = heff_tag_at_n(v_ru_24dflt_2410_24Just, TAG_Just, 1, (V[]){v_t_2419});
      break;
    }
    default: heff_nomatch(v_dflt_2410);
    }
    return heff_tag_at_n(v_ru_24t_242_24SFunction, TAG_SFunction, 5, (V[]){v_level_246, v_t_2411, v_t_2417, v_implicit_249, v_t_2420});
  }
  case TAG_SRecord: {
    V v_level_2421 = heff_field(v_t_242, 0);
    V v_fs_2422 = heff_field(v_t_242, 1);
    V v_ds_2423 = heff_field(v_t_242, 2);
    V v_ru_24t_242_24SRecord = heff_take_reuse_n(v_t_242, 7ULL, 3);
    V v_xs_2424 = heff_take_field(v_fs_2422, 2);
    V v_t_2427 = heff_arrayGenerate(heff_arrayLength_lent(v_xs_2424, 0), heff_clo_n(g_heff_2eelab_2erename_2erenameTypeF_lam0, 1, 2, (V[]){v_xs_2424, heff_dup(v_k_240)}));
    V v_t_2428 = ({ V rv_2 = v_t_2427; V rr_ = heff_rec_reuse_nf(v_fs_2422, 3ULL, 3, shape_keys__byName__values, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    V v_xs_2429 = heff_take_field(v_ds_2423, 2);
    V v_t_2432 = heff_arrayGenerate(heff_arrayLength_lent(v_xs_2429, 0), heff_clo_n(g_heff_2eelab_2erename_2erenameTypeF_lam1, 1, 2, (V[]){v_xs_2429, v_k_240}));
    V v_t_2433 = ({ V rv_2 = v_t_2432; V rr_ = heff_rec_reuse_nf(v_ds_2423, 3ULL, 3, shape_keys__byName__values, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    return heff_tag_at_n(v_ru_24t_242_24SRecord, TAG_SRecord, 3, (V[]){v_level_2421, v_t_2428, v_t_2433});
  }
  case TAG_SSum: {
    V v_vs_2434 = heff_field(v_t_242, 0);
    V v_ru_24t_242_24SSum = heff_take_reuse_n(v_t_242, 1ULL, 1);
    V v_xs_2435 = heff_take_field(v_vs_2434, 2);
    V v_t_2440 = heff_arrayGenerate(heff_arrayLength_lent(v_xs_2435, 0), heff_clo_n(g_heff_2eelab_2erename_2erenameTypeF_lam2, 1, 2, (V[]){v_xs_2435, v_k_240}));
    V v_t_2441 = ({ V rv_2 = v_t_2440; V rr_ = heff_rec_reuse_nf(v_vs_2434, 3ULL, 3, shape_keys__byName__values, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    return heff_tag_at_n(v_ru_24t_242_24SSum, TAG_SSum, 1, (V[]){v_t_2441});
  }
  case TAG_SIsTy: {
    V v_t2_2442 = heff_field(v_t_242, 0);
    V v_ru_24t_242_24SIsTy = heff_take_reuse_n(v_t_242, 1ULL, 1);
    V v_t_2443 = heff_tr(heff_call(heff_get_n(v_k_240, 1, 2), 1, (V[]){v_t2_2442}));
    return heff_tag_at_n(v_ru_24t_242_24SIsTy, TAG_SIsTy, 1, (V[]){v_t_2443});
  }
  case TAG_SPrimInt: {
    heff_drop_rec(v_k_240, 2);
    return v_t_242;
  }
  case TAG_SPrimFloat: {
    heff_drop_rec(v_k_240, 2);
    return v_t_242;
  }
  case TAG_SPrimString: {
    heff_drop_rec(v_k_240, 2);
    return v_t_242;
  }
  case TAG_SPrimRune: {
    heff_drop_rec(v_k_240, 2);
    return v_t_242;
  }
  case TAG_SPrimArray: {
    V v_t2_2444 = heff_field(v_t_242, 0);
    V v_ru_24t_242_24SPrimArray = heff_take_reuse_n(v_t_242, 1ULL, 1);
    V v_t_2445 = heff_tr(heff_call(heff_get_n(v_k_240, 1, 2), 1, (V[]){v_t2_2444}));
    return heff_tag_at_n(v_ru_24t_242_24SPrimArray, TAG_SPrimArray, 1, (V[]){v_t_2445});
  }
  case TAG_SFixed: {
    heff_drop_rec(v_k_240, 2);
    return v_t_242;
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2eelab_2erename_2erenameTypeF_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2erename_2erenameTypeF(a[0], a1, a[2]); heff_drop(a1); return r;
}
V g_heff_2eelab_2erename_2erenameTypeF_lam0(V self, V *args) {
  V v_i_2425 = args[0];
  V v_xs_2424 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t2_2426 = heff_arrayIndex(v_xs_2424, v_i_2425);
  V f_ = heff_get_n(v_k_240, 1, 2);
  args[0] = v_t2_2426;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erename_2erenameTypeF_lam1(V self, V *args) {
  V v_i_2430 = args[0];
  V v_xs_2429 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_e2_2431 = heff_arrayIndex(v_xs_2429, v_i_2430);
  V f_ = heff_get_n(v_k_240, 0, 2);
  args[0] = v_e2_2431;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erename_2erenameTypeF_lam3(V self, V *args) {
  V v_i_2438 = args[0];
  V v_xs_2437 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t2_2439 = heff_arrayIndex(v_xs_2437, v_i_2438);
  V f_ = heff_get_n(v_k_240, 1, 2);
  args[0] = v_t2_2439;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2erename_2erenameTypeF_lam2(V self, V *args) {
  V v_i_2436 = args[0];
  V v_xs_2435 = heff_env(self)[0];
  V v_k_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_xs_2437 = heff_arrayIndex(v_xs_2435, v_i_2436);
  return heff_arrayGenerate(heff_arrayLength_lent(v_xs_2437, 0), heff_clo_n(g_heff_2eelab_2erename_2erenameTypeF_lam3, 1, 2, (V[]){v_xs_2437, v_k_240}));
}
V g_heff_2eelab_2erename_2erkOf_lam0(V self, V *args);
V g_heff_2eelab_2erename_2erkOf_lam1(V self, V *args);
Clo g_heff_2eelab_2erename_2erkOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erename_2erkOf_entry, 1, 0};

V g_heff_2eelab_2erename_2erkOf(V v_r_240) {
top: ;
  return heff_rec_n(2, shape_el__ty, (V[]){heff_clo_n(g_heff_2eelab_2erename_2erkOf_lam0, 1, 1, (V[]){heff_dup(v_r_240)}), heff_clo_n(g_heff_2eelab_2erename_2erkOf_lam1, 1, 1, (V[]){v_r_240})});
}
V g_heff_2eelab_2erename_2erkOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erename_2erkOf(a[0]);
}
V g_heff_2eelab_2erename_2erkOf_lam0(V self, V *args) {
  V v_e_241 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_242 = (g_heff_2eelab_2erename_2erkOf(heff_dup(v_r_240)));
  return (g_heff_2eelab_2erename_2erenameTermF(v_t_242, v_r_240, v_e_241));
}
V g_heff_2eelab_2erename_2erkOf_lam1(V self, V *args) {
  V v_t_243 = args[0];
  V v_r_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_244 = (g_heff_2eelab_2erename_2erkOf(heff_dup(v_r_240)));
  return ({ V a_0 = v_t_244; V a_1 = v_r_240; V a_2 = v_t_243; V r_ = (g_heff_2eelab_2erename_2erenameTypeF(a_0, a_1, a_2)); heff_drop(v_r_240); r_; });
}
HEFF_LIT(g_heff_2eelab_2erename_2edescribeKey_str0, 2, "#T");
HEFF_LIT(g_heff_2eelab_2erename_2edescribeKey_str1, 14, "the theory of ");
HEFF_LIT(g_heff_2eelab_2erename_2edescribeKey_str2, 1, "#");
HEFF_LIT(g_heff_2eelab_2erename_2edescribeKey_str3, 11, "the module ");
Clo g_heff_2eelab_2erename_2edescribeKey_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erename_2edescribeKey_entry, 1, 0};

V g_heff_2eelab_2erename_2edescribeKey(V v_x_240) {
top: ;
  int64_t v_t_241 = (heff_unbox_word(heff_strLength_lent(v_x_240, 0)) - ((int64_t)2ULL));
  V v_t_242 = heff_strSlice(heff_dup(v_x_240), heff_box_word(v_t_241), heff_strLength_lent(v_x_240, 0));
  if (heff_strEq_c(v_t_242, ((V)&g_heff_2eelab_2erename_2edescribeKey_str0))) {
    int64_t v_t_244 = (heff_unbox_word(heff_strLength_lent(v_x_240, 0)) - ((int64_t)2ULL));
    return heff_strAppend(((V)&g_heff_2eelab_2erename_2edescribeKey_str1), heff_strSlice(v_x_240, MK_INT(0LL), heff_box_word(v_t_244)));
  } else {
    int64_t v_t_245 = (heff_unbox_word(heff_strLength_lent(v_x_240, 0)) - ((int64_t)1ULL));
    V v_t_246 = heff_strSlice(heff_dup(v_x_240), heff_box_word(v_t_245), heff_strLength_lent(v_x_240, 0));
    if (heff_strEq_c(v_t_246, ((V)&g_heff_2eelab_2erename_2edescribeKey_str2))) {
      int64_t v_t_248 = (heff_unbox_word(heff_strLength_lent(v_x_240, 0)) - ((int64_t)1ULL));
      return heff_strAppend(((V)&g_heff_2eelab_2erename_2edescribeKey_str3), heff_strSlice(v_x_240, MK_INT(0LL), heff_box_word(v_t_248)));
    } else {
      return v_x_240;
    }
  }
}
V g_heff_2eelab_2erename_2edescribeKey_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erename_2edescribeKey(a[0]);
}
Clo g_heff_2eelab_2erename_2enubFirst_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erename_2enubFirst_entry, 1, 0};

V g_heff_2eelab_2erename_2enubFirst(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x1_240, 0);
    V v_xs_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_cell_243 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_x_241), heff_hole()});
    V v_t_244 = ({ V a_0 = v_x_241; V a_1 = v_xs_242; V r_ = (g_list_2efilter_24s727803713x1346936525(a_0, a_1)); heff_drop(v_x_241); r_; });
    V v_u_245 = (g_heff_2eelab_2erename_2enubFirst_24dps(v_t_244, heff_dup(v_cell_243)));
    heff_drop(v_u_245);
    return v_cell_243;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2erename_2enubFirst_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erename_2enubFirst(a[0]);
}
Clo g_heff_2eelab_2erename_2enubFirst_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erename_2enubFirst_24dps_entry, 2, 0};

V g_heff_2eelab_2erename_2enubFirst_24dps(V v_x1_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_dup(v_x_242), heff_hole()});
    V v_u_245 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_244));
    heff_drop(v_u_245);
    V v_t_246 = ({ V a_0 = v_x_242; V a_1 = v_xs_243; V r_ = (g_list_2efilter_24s727803713x1346936525(a_0, a_1)); heff_drop(v_x_242); r_; });
    V t_0 = v_t_246;
    V t_1 = v_cell_244;
    v_x1_240 = t_0;
    v_d_241 = t_1;
    goto top;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2erename_2enubFirst_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erename_2enubFirst_24dps(a[0], a[1]);
}
HEFF_LIT(g_heff_2eelab_2erename_2eglobalsTypeF_24s916342050x850586824_24cycle_str0, 0, "");
HEFF_LIT(g_heff_2eelab_2erename_2eglobalsTypeF_24s916342050x850586824_24cycle_str1, 0, "");
HEFF_LIT(g_heff_2eelab_2erename_2eglobalsTypeF_24s916342050x850586824_24cycle_str2, 0, "");
HEFF_LIT(g_heff_2eelab_2erename_2eglobalsTypeF_24s916342050x850586824_24cycle_str3, 0, "");
HEFF_LIT(g_heff_2eelab_2erename_2eglobalsTypeF_24s916342050x850586824_24cycle_str4, 0, "");
HEFF_LIT(g_heff_2eelab_2erename_2eglobalsTypeF_24s916342050x850586824_24cycle_str5, 0, "");
HEFF_LIT(g_heff_2eelab_2erename_2eglobalsTypeF_24s916342050x850586824_24cycle_str6, 0, "");
HEFF_LIT(g_heff_2eelab_2erename_2eglobalsTypeF_24s916342050x850586824_24cycle_str7, 0, "");
HEFF_LIT(g_heff_2eelab_2erename_2eglobalsTypeF_24s916342050x850586824_24cycle_str8, 0, "");
Clo g_heff_2eelab_2erename_2eglobalsTypeF_24s916342050x850586824_24cycle_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erename_2eglobalsTypeF_24s916342050x850586824_24cycle_entry, 3, 0};

V g_heff_2eelab_2erename_2eglobalsTypeF_24s916342050x850586824_24cycle(V v_tag_240, V v_t_241, V v_e_242) {
top: ;
  switch (heff_tag_of(v_tag_240)) {
  case TAG_Enter_24heff_2eelab_2erename_2eglobalsTypeF_24s916342050x850586824: {
    top_TAG_Enter_24heff_2eelab_2erename_2eglobalsTypeF_24s916342050x850586824: ;
    heff_drop(v_e_242);
    switch (heff_tag_of(v_t_241)) {
    case TAG_SU: {
      heff_take_n(v_t_241, 0ULL, 1);
      return NTAG(TAG_Nil);
    }
    case TAG_SDecode: {
      V v_e_244 = heff_field(v_t_241, 0);
      heff_take_n(v_t_241, 1ULL, 1);
      V t_0 = NTAG(TAG_Enter_24heff_2eelab_2erename_2eglobalsTermF_24s304344999x537615372);
      V t_1 = ((V)&g_heff_2eelab_2erename_2eglobalsTypeF_24s916342050x850586824_24cycle_str0);
      V t_2 = v_e_244;
      v_tag_240 = t_0;
      v_t_241 = t_1;
      v_e_242 = t_2;
      goto top_TAG_Enter_24heff_2eelab_2erename_2eglobalsTermF_24s304344999x537615372;
    }
    case TAG_SFunction: {
      V v_dom_246 = heff_field(v_t_241, 1);
      V v_cod_247 = heff_field(v_t_241, 2);
      V v_dflt_249 = heff_field(v_t_241, 4);
      heff_take_n(v_t_241, 22ULL, 5);
      V v_t_2410 = (g_heff_2eelab_2erename_2eglobalsTypeF_24s916342050x850586824(v_dom_246));
      V v_t_2414;
      switch (heff_tag_of(v_cod_247)) {
      case TAG_MkAbs: {
        V v_t_2412 = heff_field(v_cod_247, 1);
        heff_take_n(v_cod_247, 2ULL, 2);
        v_t_2414 = (g_heff_2eelab_2erename_2eglobalsTypeF_24s916342050x850586824(v_t_2412));
        break;
      }
      case TAG_AbsConst: {
        V v_t_2413 = heff_field(v_cod_247, 0);
        heff_take_n(v_cod_247, 1ULL, 1);
        v_t_2414 = (g_heff_2eelab_2erename_2eglobalsTypeF_24s916342050x850586824(v_t_2413));
        break;
      }
      default: heff_nomatch(v_cod_247);
      }
      V v_t_2416;
      switch (heff_tag_of(v_dflt_249)) {
      case TAG_Nothing: {
        v_t_2416 = NTAG(TAG_Nil);
        break;
      }
      case TAG_Just: {
        V v_d_2415 = heff_field(v_dflt_249, 0);
        heff_take_n(v_dflt_249, 1ULL, 1);
        v_t_2416 = (g_heff_2eelab_2erename_2eglobalsTermF_24s304344999x537615372(v_d_2415));
        break;
      }
      default: heff_nomatch(v_dflt_249);
      }
      V v_t_2417 = (g_prelude_2e_2b_2b(v_t_2414, v_t_2416));
      return (g_prelude_2e_2b_2b(v_t_2410, v_t_2417));
    }
    case TAG_SRecord: {
      V v_fs_2419 = heff_field(v_t_241, 1);
      V v_ds_2420 = heff_field(v_t_241, 2);
      heff_take_n(v_t_241, 6ULL, 3);
      V v_t_2421 = heff_arrayToList(heff_take_field(v_fs_2419, 0));
      V v_t_2422 = heff_arrayToList(heff_get_n(v_fs_2419, 2, 3));
      V v_t_2423 = (g_list_2efoldl_24f1625738412x188935108(NTAG(TAG_Nil), v_t_2421, v_t_2422));
      V v_t_2424 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2423; V r_ = (g_list_2efoldl_24s978059622x523571930(a_0, a_1)); heff_drop(v_t_2423); r_; });
      V v_t_2425 = heff_arrayToList(heff_take_field(v_ds_2420, 0));
      V v_t_2426 = heff_arrayToList(heff_get_n(v_ds_2420, 2, 3));
      V v_t_2427 = (g_list_2efoldl_24f1625738412x188935108(NTAG(TAG_Nil), v_t_2425, v_t_2426));
      V v_t_2428 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2427; V r_ = (g_list_2efoldl_24s1606891938x229778616(a_0, a_1)); heff_drop(v_t_2427); r_; });
      return (g_prelude_2e_2b_2b(v_t_2424, v_t_2428));
    }
    case TAG_SSum: {
      V v_vs_2429 = heff_field(v_t_241, 0);
      heff_take_n(v_t_241, 1ULL, 1);
      V v_t_2430 = heff_arrayToList(heff_take_field(v_vs_2429, 0));
      V v_t_2431 = heff_arrayToList(heff_get_n(v_vs_2429, 2, 3));
      V v_t_2432 = (g_list_2efoldl_24f1625738412x188935108(NTAG(TAG_Nil), v_t_2430, v_t_2431));
      return ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2432; V r_ = (g_list_2efoldl_24s797527640x986490519(a_0, a_1)); heff_drop(v_t_2432); r_; });
    }
    case TAG_SIsTy: {
      V v_t2_2433 = heff_field(v_t_241, 0);
      heff_take_n(v_t_241, 1ULL, 1);
      V t_0 = NTAG(TAG_Enter_24heff_2eelab_2erename_2eglobalsTypeF_24s916342050x850586824);
      V t_1 = v_t2_2433;
      V t_2 = ((V)&g_heff_2eelab_2erename_2eglobalsTypeF_24s916342050x850586824_24cycle_str1);
      v_tag_240 = t_0;
      v_t_241 = t_1;
      v_e_242 = t_2;
      goto top_TAG_Enter_24heff_2eelab_2erename_2eglobalsTypeF_24s916342050x850586824;
    }
    case TAG_SPrimInt: {
      return NTAG(TAG_Nil);
    }
    case TAG_SPrimFloat: {
      return NTAG(TAG_Nil);
    }
    case TAG_SPrimString: {
      return NTAG(TAG_Nil);
    }
    case TAG_SPrimRune: {
      return NTAG(TAG_Nil);
    }
    case TAG_SPrimArray: {
      V v_t2_2434 = heff_field(v_t_241, 0);
      heff_take_n(v_t_241, 1ULL, 1);
      V t_0 = NTAG(TAG_Enter_24heff_2eelab_2erename_2eglobalsTypeF_24s916342050x850586824);
      V t_1 = v_t2_2434;
      V t_2 = ((V)&g_heff_2eelab_2erename_2eglobalsTypeF_24s916342050x850586824_24cycle_str2);
      v_tag_240 = t_0;
      v_t_241 = t_1;
      v_e_242 = t_2;
      goto top_TAG_Enter_24heff_2eelab_2erename_2eglobalsTypeF_24s916342050x850586824;
    }
    case TAG_SFixed: {
      heff_take_n(v_t_241, 0ULL, 1);
      return NTAG(TAG_Nil);
    }
    default: return heff_nomatch(v_t_241);
    }
  }
  case TAG_Enter_24heff_2eelab_2erename_2eglobalsTermF_24s304344999x537615372: {
    top_TAG_Enter_24heff_2eelab_2erename_2eglobalsTermF_24s304344999x537615372: ;
    heff_drop(v_t_241);
    switch (heff_tag_of(v_e_242)) {
    case TAG_SLocal: {
      heff_take_n(v_e_242, 0ULL, 1);
      return NTAG(TAG_Nil);
    }
    case TAG_SGlobal: {
      V v_x_2437 = heff_field(v_e_242, 0);
      heff_take_n(v_e_242, 1ULL, 1);
      return heff_tag_n(TAG_Cons, 2, (V[]){v_x_2437, NTAG(TAG_Nil)});
    }
    case TAG_SCode: {
      V v_t_2438 = heff_field(v_e_242, 0);
      heff_take_n(v_e_242, 1ULL, 1);
      V t_0 = NTAG(TAG_Enter_24heff_2eelab_2erename_2eglobalsTypeF_24s916342050x850586824);
      V t_1 = v_t_2438;
      V t_2 = ((V)&g_heff_2eelab_2erename_2eglobalsTypeF_24s916342050x850586824_24cycle_str3);
      v_tag_240 = t_0;
      v_t_241 = t_1;
      v_e_242 = t_2;
      goto top_TAG_Enter_24heff_2eelab_2erename_2eglobalsTypeF_24s916342050x850586824;
    }
    case TAG_SApp: {
      V v_f_2439 = heff_field(v_e_242, 0);
      V v_a_2440 = heff_field(v_e_242, 1);
      heff_take_n(v_e_242, 3ULL, 2);
      V v_t_2441 = (g_heff_2eelab_2erename_2eglobalsTermF_24s304344999x537615372(v_f_2439));
      V v_t_2442 = (g_heff_2eelab_2erename_2eglobalsTermF_24s304344999x537615372(v_a_2440));
      return (g_prelude_2e_2b_2b(v_t_2441, v_t_2442));
    }
    case TAG_SLam: {
      V v_d_2443 = heff_field(v_e_242, 0);
      V v_b_2444 = heff_field(v_e_242, 1);
      heff_take_n(v_e_242, 3ULL, 2);
      V v_t_2445 = (g_heff_2eelab_2erename_2eglobalsTypeF_24s916342050x850586824(v_d_2443));
      V v_t_2449;
      switch (heff_tag_of(v_b_2444)) {
      case TAG_MkAbs: {
        V v_t_2447 = heff_field(v_b_2444, 1);
        heff_take_n(v_b_2444, 2ULL, 2);
        v_t_2449 = (g_heff_2eelab_2erename_2eglobalsTermF_24s304344999x537615372(v_t_2447));
        break;
      }
      case TAG_AbsConst: {
        V v_t_2448 = heff_field(v_b_2444, 0);
        heff_take_n(v_b_2444, 1ULL, 1);
        v_t_2449 = (g_heff_2eelab_2erename_2eglobalsTermF_24s304344999x537615372(v_t_2448));
        break;
      }
      default: heff_nomatch(v_b_2444);
      }
      return (g_prelude_2e_2b_2b(v_t_2445, v_t_2449));
    }
    case TAG_SCons: {
      V v_d_2450 = heff_field(v_e_242, 0);
      heff_take_n(v_e_242, 1ULL, 1);
      V v_t_2451 = heff_arrayToList(heff_take_field(v_d_2450, 0));
      V v_t_2452 = heff_arrayToList(heff_get_n(v_d_2450, 2, 3));
      V v_t_2453 = (g_list_2efoldl_24f1625738412x188935108(NTAG(TAG_Nil), v_t_2451, v_t_2452));
      return ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2453; V r_ = (g_list_2efoldl_24s1606891938x229778616(a_0, a_1)); heff_drop(v_t_2453); r_; });
    }
    case TAG_SProj: {
      V v_e2_2454 = heff_field(v_e_242, 0);
      heff_take_n(v_e_242, 1ULL, 2);
      V t_0 = NTAG(TAG_Enter_24heff_2eelab_2erename_2eglobalsTermF_24s304344999x537615372);
      V t_1 = ((V)&g_heff_2eelab_2erename_2eglobalsTypeF_24s916342050x850586824_24cycle_str4);
      V t_2 = v_e2_2454;
      v_tag_240 = t_0;
      v_t_241 = t_1;
      v_e_242 = t_2;
      goto top_TAG_Enter_24heff_2eelab_2erename_2eglobalsTermF_24s304344999x537615372;
    }
    case TAG_STag: {
      V v_as_2457 = heff_field(v_e_242, 1);
      heff_take_n(v_e_242, 2ULL, 2);
      V v_t_2458 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_arrayToList(v_as_2457)));
      return ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2458; V r_ = (g_list_2efoldl_24s865198748x12535471(a_0, a_1)); heff_drop(v_t_2458); r_; });
    }
    case TAG_SMatch: {
      V v_e2_2459 = heff_field(v_e_242, 0);
      V v_cs_2460 = heff_field(v_e_242, 1);
      heff_take_n(v_e_242, 3ULL, 2);
      V v_t_2461 = (g_heff_2eelab_2erename_2eglobalsTermF_24s304344999x537615372(v_e2_2459));
      V v_t_2462 = heff_arrayToList(heff_take_field(v_cs_2460, 0));
      V v_t_2463 = heff_arrayToList(heff_get_n(v_cs_2460, 2, 3));
      V v_t_2464 = (g_list_2efoldl_24f1625738412x188935108(NTAG(TAG_Nil), v_t_2462, v_t_2463));
      V v_t_2465 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2464; V r_ = (g_list_2efoldl_24s522807745x1556762248(a_0, a_1)); heff_drop(v_t_2464); r_; });
      return (g_prelude_2e_2b_2b(v_t_2461, v_t_2465));
    }
    case TAG_SSpecialize: {
      V v_e2_2466 = heff_field(v_e_242, 0);
      V v_v_2468 = heff_field(v_e_242, 2);
      heff_take_n(v_e_242, 5ULL, 3);
      V v_t_2469 = (g_heff_2eelab_2erename_2eglobalsTermF_24s304344999x537615372(v_e2_2466));
      V v_t_2470 = (g_heff_2eelab_2erename_2eglobalsTermF_24s304344999x537615372(v_v_2468));
      return (g_prelude_2e_2b_2b(v_t_2469, v_t_2470));
    }
    case TAG_SIs: {
      V v_e2_2471 = heff_field(v_e_242, 0);
      heff_take_n(v_e_242, 1ULL, 1);
      V t_0 = NTAG(TAG_Enter_24heff_2eelab_2erename_2eglobalsTermF_24s304344999x537615372);
      V t_1 = ((V)&g_heff_2eelab_2erename_2eglobalsTypeF_24s916342050x850586824_24cycle_str5);
      V t_2 = v_e2_2471;
      v_tag_240 = t_0;
      v_t_241 = t_1;
      v_e_242 = t_2;
      goto top_TAG_Enter_24heff_2eelab_2erename_2eglobalsTermF_24s304344999x537615372;
    }
    case TAG_SOpaque: {
      return NTAG(TAG_Nil);
    }
    case TAG_SAbandon: {
      return NTAG(TAG_Nil);
    }
    case TAG_SRec: {
      V v_e2_2472 = heff_field(v_e_242, 0);
      heff_take_n(v_e_242, 1ULL, 1);
      V t_0 = NTAG(TAG_Enter_24heff_2eelab_2erename_2eglobalsTermF_24s304344999x537615372);
      V t_1 = ((V)&g_heff_2eelab_2erename_2eglobalsTypeF_24s916342050x850586824_24cycle_str6);
      V t_2 = v_e2_2472;
      v_tag_240 = t_0;
      v_t_241 = t_1;
      v_e_242 = t_2;
      goto top_TAG_Enter_24heff_2eelab_2erename_2eglobalsTermF_24s304344999x537615372;
    }
    case TAG_SFix: {
      V v_d_2473 = heff_field(v_e_242, 0);
      V v_b_2474 = heff_field(v_e_242, 1);
      heff_take_n(v_e_242, 3ULL, 2);
      V v_t_2475 = (g_heff_2eelab_2erename_2eglobalsTypeF_24s916342050x850586824(v_d_2473));
      V v_t_2479;
      switch (heff_tag_of(v_b_2474)) {
      case TAG_MkAbs: {
        V v_t_2477 = heff_field(v_b_2474, 1);
        heff_take_n(v_b_2474, 2ULL, 2);
        v_t_2479 = (g_heff_2eelab_2erename_2eglobalsTermF_24s304344999x537615372(v_t_2477));
        break;
      }
      case TAG_AbsConst: {
        V v_t_2478 = heff_field(v_b_2474, 0);
        heff_take_n(v_b_2474, 1ULL, 1);
        v_t_2479 = (g_heff_2eelab_2erename_2eglobalsTermF_24s304344999x537615372(v_t_2478));
        break;
      }
      default: heff_nomatch(v_b_2474);
      }
      return (g_prelude_2e_2b_2b(v_t_2475, v_t_2479));
    }
    case TAG_SImplicit: {
      V v_e2_2481 = heff_field(v_e_242, 1);
      heff_take_n(v_e_242, 2ULL, 2);
      V t_0 = NTAG(TAG_Enter_24heff_2eelab_2erename_2eglobalsTermF_24s304344999x537615372);
      V t_1 = ((V)&g_heff_2eelab_2erename_2eglobalsTypeF_24s916342050x850586824_24cycle_str7);
      V t_2 = v_e2_2481;
      v_tag_240 = t_0;
      v_t_241 = t_1;
      v_e_242 = t_2;
      goto top_TAG_Enter_24heff_2eelab_2erename_2eglobalsTermF_24s304344999x537615372;
    }
    case TAG_SPrim: {
      heff_take_n(v_e_242, 0ULL, 1);
      return NTAG(TAG_Nil);
    }
    case TAG_SMetaApp: {
      V v_t_2485 = heff_field(v_e_242, 2);
      heff_take_n(v_e_242, 4ULL, 3);
      V t_0 = NTAG(TAG_Enter_24heff_2eelab_2erename_2eglobalsTypeF_24s916342050x850586824);
      V t_1 = v_t_2485;
      V t_2 = ((V)&g_heff_2eelab_2erename_2eglobalsTypeF_24s916342050x850586824_24cycle_str8);
      v_tag_240 = t_0;
      v_t_241 = t_1;
      v_e_242 = t_2;
      goto top_TAG_Enter_24heff_2eelab_2erename_2eglobalsTypeF_24s916342050x850586824;
    }
    case TAG_SLitInt: {
      heff_take_n(v_e_242, 0ULL, 1);
      return NTAG(TAG_Nil);
    }
    case TAG_SLitFloat: {
      heff_take_na(v_e_242, 0ULL, 1);
      return NTAG(TAG_Nil);
    }
    case TAG_SLitString: {
      heff_take_n(v_e_242, 0ULL, 1);
      return NTAG(TAG_Nil);
    }
    case TAG_SLitBytes: {
      heff_take_n(v_e_242, 0ULL, 1);
      return NTAG(TAG_Nil);
    }
    case TAG_SLitRune: {
      heff_take_n(v_e_242, 0ULL, 1);
      return NTAG(TAG_Nil);
    }
    case TAG_SLitFixed: {
      heff_take_n(v_e_242, 0ULL, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_SLitFloat32: {
      heff_take_na(v_e_242, 0ULL, 1);
      return NTAG(TAG_Nil);
    }
    default: return heff_nomatch(v_e_242);
    }
  }
  default: return heff_nomatch(v_tag_240);
  }
}
V g_heff_2eelab_2erename_2eglobalsTypeF_24s916342050x850586824_24cycle_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erename_2eglobalsTypeF_24s916342050x850586824_24cycle(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2eelab_2erename_2eglobalsTypeF_24s916342050x850586824_str0, 0, "");
Clo g_heff_2eelab_2erename_2eglobalsTypeF_24s916342050x850586824_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erename_2eglobalsTypeF_24s916342050x850586824_entry, 1, 0};

V g_heff_2eelab_2erename_2eglobalsTypeF_24s916342050x850586824(V v_t_240) {
top: ;
  return (g_heff_2eelab_2erename_2eglobalsTypeF_24s916342050x850586824_24cycle(NTAG(TAG_Enter_24heff_2eelab_2erename_2eglobalsTypeF_24s916342050x850586824), v_t_240, ((V)&g_heff_2eelab_2erename_2eglobalsTypeF_24s916342050x850586824_str0)));
}
V g_heff_2eelab_2erename_2eglobalsTypeF_24s916342050x850586824_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erename_2eglobalsTypeF_24s916342050x850586824(a[0]);
}
HEFF_LIT(g_heff_2eelab_2erename_2eglobalsTermF_24s304344999x537615372_str0, 0, "");
Clo g_heff_2eelab_2erename_2eglobalsTermF_24s304344999x537615372_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2erename_2eglobalsTermF_24s304344999x537615372_entry, 1, 0};

V g_heff_2eelab_2erename_2eglobalsTermF_24s304344999x537615372(V v_e_240) {
top: ;
  return (g_heff_2eelab_2erename_2eglobalsTypeF_24s916342050x850586824_24cycle(NTAG(TAG_Enter_24heff_2eelab_2erename_2eglobalsTermF_24s304344999x537615372), ((V)&g_heff_2eelab_2erename_2eglobalsTermF_24s304344999x537615372_str0), v_e_240));
}
V g_heff_2eelab_2erename_2eglobalsTermF_24s304344999x537615372_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2erename_2eglobalsTermF_24s304344999x537615372(a[0]);
}

HeffT2 g_heff_2eelab_2erename_2efirstAliasOf_24cpr(V v_x1_240, V v_x_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_x11_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_MkPair: {
      V v_n_244 = heff_field(v_x11_242, 0);
      V v_k_245 = heff_field(v_x11_242, 1);
      heff_take_n(v_x11_242, 3ULL, 2);
      if (heff_strEq_c_lent(v_k_245, v_x_241, 1)) {
        heff_drop(v_rest_243);
        return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_n_244}});
      } else {
        heff_drop(v_n_244);
        V t_0 = v_rest_243;
        V t_1 = v_x_241;
        v_x1_240 = t_0;
        v_x_241 = t_1;
        goto top;
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x11_242)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}