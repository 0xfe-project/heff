// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Exit 20279
#define TAG_GetEnv 43934
#define TAG_Left 13886
#define TAG_Platform 55558
#define TAG_Posix 44191
#define TAG_Right 62770
#define TAG_Windows 49101
#define TAG_Write 36323
#define TAG_WriteErr 37283
#define LBL_bug 307438
#define LBL_c 317
#define LBL_diags 296935042
#define LBL_done 9584713
#define LBL_effect 641056956
#define LBL_errors 652506774
#define LBL_globals 352931696
#define LBL_key 315609
#define LBL_modules 1459291593
#define LBL_msg 317947
#define LBL_name 9869138
#define LBL_path 9928940
#define LBL_paths 307797256
#define LBL_root 10001833
#define LBL_said 10017968
#define LBL_source 1050636102
#define LBL_top 324559
#define LBL_value 313331083
#define LBL_zig 330130
V g_co_2eop_24s310169282x2049378029(V, V, V, V);
V g_co_2eop_24s310169282x2049378029_entry(V self, V *a);
extern Clo g_co_2eop_24s310169282x2049378029_clo;
V g_exception_2eattempted(V);
V g_exception_2eattempted_entry(V self, V *a);
extern Clo g_exception_2eattempted_clo;
V g_heff_2ebuild_2ecommands_2ebacksOf(V, V);
V g_heff_2ebuild_2ecommands_2ebacksOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ebacksOf_clo;
V g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1609818333x944097652(V, V, V, V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1609818333x944097652_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1609818333x944097652_clo;
HeffT2 g_heff_2ebuild_2ecommands_2efirstErrorOf_24cpr(V);
V g_heff_2ebuild_2ecommands_2efmtSrc_24s211467399x186137324(V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2efmtSrc_24s211467399x186137324_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2efmtSrc_24s211467399x186137324_clo;
V g_heff_2ebuild_2ecommands_2eheffHome_24s310823312x832347879(V, V, V);
V g_heff_2ebuild_2ecommands_2eheffHome_24s310823312x832347879_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eheffHome_24s310823312x832347879_clo;
V g_heff_2ebuild_2ecommands_2eimportsOn_24acc(V, V);
V g_heff_2ebuild_2ecommands_2eimportsOn_24acc_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eimportsOn_24acc_clo;
V g_heff_2ebuild_2ecommands_2ekeptParts_24s683971978x1312876275(V, V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ekeptParts_24s683971978x1312876275_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ekeptParts_24s683971978x1312876275_clo;
V g_heff_2ebuild_2ecommands_2ekeptWith_24s1814069843x1801086089(V, V, V, V, V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ekeptWith_24s1814069843x1801086089_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ekeptWith_24s1814069843x1801086089_clo;
V g_heff_2ebuild_2ecommands_2eload_24s2043842606x1315457906(V, V, V, V);
V g_heff_2ebuild_2ecommands_2eload_24s2043842606x1315457906_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eload_24s2043842606x1315457906_clo;
V g_heff_2ebuild_2ecommands_2enotInProject_24s1239925928x1402397320(V, V, V, V);
V g_heff_2ebuild_2ecommands_2enotInProject_24s1239925928x1402397320_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2enotInProject_24s1239925928x1402397320_clo;
V g_heff_2ebuild_2ecommands_2epartsDir(V, V, V);
V g_heff_2ebuild_2ecommands_2epartsDir_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2epartsDir_clo;
V g_heff_2ebuild_2ecommands_2eprintErrs_24s1758719709x679644559(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eprintErrs_24s1758719709x679644559_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprintErrs_24s1758719709x679644559_clo;
V g_heff_2ebuild_2ecommands_2eprintEvals_24s546697161x1900854479(V, V, V, V);
V g_heff_2ebuild_2ecommands_2eprintEvals_24s546697161x1900854479_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprintEvals_24s546697161x1900854479_clo;
V g_heff_2ebuild_2ecommands_2epromoteCmd_24s704215115x133853853(V, V, V, V);
V g_heff_2ebuild_2ecommands_2epromoteCmd_24s704215115x133853853_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2epromoteCmd_24s704215115x133853853_clo;
V g_heff_2ebuild_2ecommands_2epromoteDiags_24s1922111359x1834555732(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2epromoteDiags_24s1922111359x1834555732_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2epromoteDiags_24s1922111359x1834555732_clo;
V g_heff_2ebuild_2ecommands_2eprovidesLeafC(V, V);
V g_heff_2ebuild_2ecommands_2eprovidesLeafC_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprovidesLeafC_clo;
V g_heff_2ebuild_2ecommands_2ereadBacks_24s960701544x1414957442(V, V, V);
V g_heff_2ebuild_2ecommands_2ereadBacks_24s960701544x1414957442_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ereadBacks_24s960701544x1414957442_clo;
V g_heff_2ebuild_2ecommands_2eselfHash_24s1263115327x65083815(V, V, V, V);
V g_heff_2ebuild_2ecommands_2eselfHash_24s1263115327x65083815_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eselfHash_24s1263115327x65083815_clo;
V g_heff_2ebuild_2ecommands_2eshipMoved_24s713012492x1635447620(V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eshipMoved_24s713012492x1635447620_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eshipMoved_24s713012492x1635447620_clo;
V g_heff_2ebuild_2ecommands_2ewriteOutC_24s196946078x469800039(V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ewriteOutC_24s196946078x469800039_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ewriteOutC_24s196946078x469800039_clo;
V g_heff_2ebuild_2edriver_2ecandLeaves(V);
V g_heff_2ebuild_2edriver_2ecandLeaves_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ecandLeaves_clo;
V g_heff_2ebuild_2edriver_2ecandidatesOf(V);
V g_heff_2ebuild_2edriver_2ecandidatesOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ecandidatesOf_clo;
HeffT2 g_heff_2ebuild_2edriver_2efindRunnable_24cpr(V, V, V);
V g_heff_2ebuild_2edriver_2enubStrD(V);
V g_heff_2ebuild_2edriver_2enubStrD_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2enubStrD_clo;
V g_heff_2ebuild_2esession_2ecachedAcc_24s1465745022x907203497(V, V);
V g_heff_2ebuild_2esession_2ecachedAcc_24s1465745022x907203497_entry(V self, V *a);
extern Clo g_heff_2ebuild_2esession_2ecachedAcc_24s1465745022x907203497_clo;
V g_heff_2ecompile_2eemitc_2ecompileProgramC(V, V, V, V, V);
V g_heff_2ecompile_2eemitc_2ecompileProgramC_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2ecompileProgramC_clo;
V g_heff_2elsp_2erender_2ediagWhere(V, V, V);
V g_heff_2elsp_2erender_2ediagWhere_entry(V self, V *a);
extern Clo g_heff_2elsp_2erender_2ediagWhere_clo;
V g_heff_2elsp_2erender_2eprtCode(V);
V g_heff_2elsp_2erender_2eprtCode_entry(V self, V *a);
extern Clo g_heff_2elsp_2erender_2eprtCode_clo;
HeffT2 g_heff_2esyntax_2eformat_2eformatIn_24cpr(V, V);
V g_list_2ekeepIf(V, V);
V g_list_2ekeepIf_entry(V self, V *a);
extern Clo g_list_2ekeepIf_clo;
V g_list_2ekeepIf_24s1161549307x1906011635(V);
V g_list_2ekeepIf_24s1161549307x1906011635_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1161549307x1906011635_clo;
V g_list_2emap_24s219049803x1458391381(V);
V g_list_2emap_24s219049803x1458391381_entry(V self, V *a);
extern Clo g_list_2emap_24s219049803x1458391381_clo;
V g_std_2efilesystem_2emove_24s1592691554x274375227(V, V, V);
V g_std_2efilesystem_2emove_24s1592691554x274375227_entry(V self, V *a);
extern Clo g_std_2efilesystem_2emove_24s1592691554x274375227_clo;
V g_std_2efilesystem_2ereadDirectory_24s1485822734x1304823189(V, V);
V g_std_2efilesystem_2ereadDirectory_24s1485822734x1304823189_entry(V self, V *a);
extern Clo g_std_2efilesystem_2ereadDirectory_24s1485822734x1304823189_clo;
V g_std_2efilesystem_2ereadFile_24s1206250698x830238241(V, V);
V g_std_2efilesystem_2ereadFile_24s1206250698x830238241_entry(V self, V *a);
extern Clo g_std_2efilesystem_2ereadFile_24s1206250698x830238241_clo;
V g_std_2efilesystem_2eremove_24s450846999x1798011492(V, V);
V g_std_2efilesystem_2eremove_24s450846999x1798011492_entry(V self, V *a);
extern Clo g_std_2efilesystem_2eremove_24s450846999x1798011492_clo;
V g_std_2efilesystem_2ewriteFile_24s1279893433x291681682(V, V, V);
V g_std_2efilesystem_2ewriteFile_24s1279893433x291681682_entry(V self, V *a);
extern Clo g_std_2efilesystem_2ewriteFile_24s1279893433x291681682_clo;
V g_std_2epath_2ejoin(V, V);
V g_std_2epath_2ejoin_entry(V self, V *a);
extern Clo g_std_2epath_2ejoin_clo;
V g_std_2epath_2enative_get(void);
V g_std_2epath_2eparse(V, V);
V g_std_2epath_2eparse_entry(V self, V *a);
extern Clo g_std_2epath_2eparse_clo;
V g_std_2epath_2erender(V, V);
V g_std_2epath_2erender_entry(V self, V *a);
extern Clo g_std_2epath_2erender_clo;
HEFF_LIT(g_heff_2ebuild_2ecommands_2eimportsOn_24acc_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eimportsOn_24acc_str1, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eimportsOn_24acc_str2, 10, "imports it");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eimportsOn_24acc_str3, 9, "imports `");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eimportsOn_24acc_str4, 9, "`, which ");
Clo g_heff_2ebuild_2ecommands_2eimportsOn_24acc_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eimportsOn_24acc_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2eimportsOn_24acc(V v_x1_240, V v_acc_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_strAppend(v_acc_241, ((V)&g_heff_2ebuild_2ecommands_2eimportsOn_24acc_str0));
  }
  case TAG_Cons: {
    V v_x12_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 2ULL, 2);
    switch (heff_tag_of(v_x12_243)) {
    case TAG_Nil: {
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      return heff_strAppend(v_acc_241, ((V)&g_heff_2ebuild_2ecommands_2eimportsOn_24acc_str1));
    }
    case TAG_Cons: {
      V v_b_244 = heff_field(v_x12_243, 0);
      V v_x122_245 = heff_field(v_x12_243, 1);
      heff_take_n(v_x12_243, 3ULL, 2);
      switch (heff_tag_of(v_x122_245)) {
      case TAG_Nil: {
        heff_drop_cell(v_ru_24x1_240_24Cons, 2);
        heff_drop(v_b_244);
        return heff_strAppend(v_acc_241, ((V)&g_heff_2ebuild_2ecommands_2eimportsOn_24acc_str2));
      }
      case TAG_Cons: {
        V v_t_248 = heff_strAppend(heff_strAppend(v_acc_241, ((V)&g_heff_2ebuild_2ecommands_2eimportsOn_24acc_str3)), heff_dup(v_b_244));
        V v_s_249 = heff_strAppend(v_t_248, ((V)&g_heff_2ebuild_2ecommands_2eimportsOn_24acc_str4));
        V t_0 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_b_244, v_x122_245});
        V t_1 = v_s_249;
        v_x1_240 = t_0;
        v_acc_241 = t_1;
        goto top;
      }
      default: return heff_nomatch(v_x122_245);
      }
    }
    default: return heff_nomatch(v_x12_243);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2ecommands_2eimportsOn_24acc_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eimportsOn_24acc(a[0], a[1]);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2efirstErrorOf_24cpr_str0, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efirstErrorOf_24cpr_str1, 2, ": ");

HeffT2 g_heff_2ebuild_2ecommands_2efirstErrorOf_24cpr(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_c_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    V v_diags_243 = heff_dup(heff_rfield(v_c_241, 6));
    V v_path_244 = heff_dup(heff_rfield(v_c_241, 1));
    V v_source_245 = heff_dup(heff_rfield(v_c_241, 3));
    V v_x2_246 = (g_list_2ekeepIf_24s1161549307x1906011635(v_diags_243));
    switch (heff_tag_of(v_x2_246)) {
    case TAG_Nil: {
      heff_drop(v_path_244);
      heff_drop(v_source_245);
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Cons: {
      V v_d_247 = heff_field(v_x2_246, 0);
      heff_take_n(v_x2_246, 1ULL, 2);
      V v_t_249 = ({ V a_0 = v_path_244; V a_1 = v_source_245; V a_2 = heff_dup(v_d_247); V r_ = (g_heff_2elsp_2erender_2ediagWhere(a_0, a_1, a_2)); heff_drop(v_source_245); r_; });
      V v_t_2410 = (g_heff_2elsp_2erender_2eprtCode(heff_dup(v_d_247)));
      V v_t_2411 = heff_strAppend(heff_strAppend(v_t_2410, ((V)&g_heff_2ebuild_2ecommands_2efirstErrorOf_24cpr_str0)), heff_get_n(v_d_247, 2, 5));
      V v_why_2412 = heff_strAppend(heff_strAppend(v_t_249, ((V)&g_heff_2ebuild_2ecommands_2efirstErrorOf_24cpr_str1)), v_t_2411);
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_why_2412}});
    }
    default: return ((HeffT2){{heff_nomatch(v_x2_246)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2epartsDir_str0, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epartsDir_str1, 5, "build");
Clo g_heff_2ebuild_2ecommands_2epartsDir_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2epartsDir_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2epartsDir(V v_st_240, V v_t_241, V v_x_242) {
top: ;
  V v_t_243 = (g_std_2epath_2eparse(heff_dup(v_st_240), ((V)&g_heff_2ebuild_2ecommands_2epartsDir_str0)));
  V v_t_244 = (g_std_2epath_2eparse(heff_dup(v_st_240), ((V)&g_heff_2ebuild_2ecommands_2epartsDir_str1)));
  V v_t_245 = (g_std_2epath_2ejoin(v_t_243, v_t_244));
  V v_a_246 = ({ V a_0 = v_st_240; V a_1 = v_t_245; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_245); r_; });
  V v_t_247 = (g_std_2epath_2eparse(heff_dup(v_st_240), v_a_246));
  V v_t_248 = (g_std_2epath_2eparse(heff_dup(v_st_240), v_x_242));
  V v_t_249 = (g_std_2epath_2ejoin(v_t_247, v_t_248));
  V v_p_2410 = ({ V a_0 = v_st_240; V a_1 = v_t_249; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_249); r_; });
  V v_t_2411 = (g_std_2epath_2eparse(heff_dup(v_st_240), heff_get_n(v_t_241, 0, 6)));
  V v_t_2412 = (g_std_2epath_2eparse(heff_dup(v_st_240), v_p_2410));
  V v_t_2413 = (g_std_2epath_2ejoin(v_t_2411, v_t_2412));
  return ({ V a_0 = v_st_240; V a_1 = v_t_2413; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_240); heff_drop(v_t_2413); r_; });
}
V g_heff_2ebuild_2ecommands_2epartsDir_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2epartsDir(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eheffHome_24s310823312x832347879_str0, 9, "HEFF_HOME");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eheffHome_24s310823312x832347879_str1, 4, "HOME");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eheffHome_24s310823312x832347879_str2, 11, "USERPROFILE");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eheffHome_24s310823312x832347879_str3, 5, "win32");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eheffHome_24s310823312x832347879_str4, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eheffHome_24s310823312x832347879_str5, 5, ".heff");
V g_heff_2ebuild_2ecommands_2eheffHome_24s310823312x832347879_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eheffHome_24s310823312x832347879_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eheffHome_24s310823312x832347879_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2eheffHome_24s310823312x832347879_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eheffHome_24s310823312x832347879_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eheffHome_24s310823312x832347879_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2eheffHome_24s310823312x832347879_lam4(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eheffHome_24s310823312x832347879_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eheffHome_24s310823312x832347879_lam4, 1, 0};
V g_heff_2ebuild_2ecommands_2eheffHome_24s310823312x832347879_lam6(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eheffHome_24s310823312x832347879_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eheffHome_24s310823312x832347879_lam6, 1, 0};
V g_heff_2ebuild_2ecommands_2eheffHome_24s310823312x832347879_lam7(V self, V *args);
V g_heff_2ebuild_2ecommands_2eheffHome_24s310823312x832347879_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2eheffHome_24s310823312x832347879_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2eheffHome_24s310823312x832347879_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eheffHome_24s310823312x832347879_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eheffHome_24s310823312x832347879_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2eheffHome_24s310823312x832347879(V v_e_240, V v_hd_241, V v_k_242) {
top: ;
  V v_t_244 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_GetEnv, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eheffHome_24s310823312x832347879_str0), ((V)&g_heff_2ebuild_2ecommands_2eheffHome_24s310823312x832347879_lam0_clo)})});
  V v_t_245 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_244})});
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_245})});
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_249})});
  return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), v_t_2410, heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2ecommands_2eheffHome_24s310823312x832347879_lam1, 1, 3, (V[]){v_e_240, v_hd_241, v_k_242})));
}
V g_heff_2ebuild_2ecommands_2eheffHome_24s310823312x832347879_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eheffHome_24s310823312x832347879(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2ecommands_2eheffHome_24s310823312x832347879_lam0(V self, V *args) {
  V v_v_243 = args[0];
  return v_v_243;
}
V g_heff_2ebuild_2ecommands_2eheffHome_24s310823312x832347879_lam2(V self, V *args) {
  V v_v_2412 = args[0];
  return v_v_2412;
}
V g_heff_2ebuild_2ecommands_2eheffHome_24s310823312x832347879_lam4(V self, V *args) {
  V v_v_2421 = args[0];
  return v_v_2421;
}
V g_heff_2ebuild_2ecommands_2eheffHome_24s310823312x832347879_lam6(V self, V *args) {
  V v_s_2430 = args[0];
  return v_s_2430;
}
V g_heff_2ebuild_2ecommands_2eheffHome_24s310823312x832347879_lam7(V self, V *args) {
  V v_x_2438 = args[0];
  V v_x_2411 = heff_env(self)[0];
  V v_x_2420 = heff_env(self)[1];
  V v_x_2429 = heff_env(self)[2];
  V v_k_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_st_2439;
  if (heff_strEq_c(v_x_2438, ((V)&g_heff_2ebuild_2ecommands_2eheffHome_24s310823312x832347879_str3))) {
    v_st_2439 = NTAG(TAG_Windows);
  } else {
    v_st_2439 = NTAG(TAG_Posix);
  }
  V v_x_2447;
  switch (heff_tag_of(v_x_2411)) {
  case TAG_Nothing: {
    V v_t_2442;
    switch (heff_tag_of(v_x_2420)) {
    case TAG_Nothing: {
      switch (heff_tag_of(v_x_2429)) {
      case TAG_Nothing: {
        v_t_2442 = ((V)&g_heff_2ebuild_2ecommands_2eheffHome_24s310823312x832347879_str4);
        break;
      }
      case TAG_Just: {
        V v_x_2440 = heff_field(v_x_2429, 0);
        heff_take_n(v_x_2429, 1ULL, 1);
        v_t_2442 = v_x_2440;
        break;
      }
      default: heff_nomatch(v_x_2429);
      }
      break;
    }
    case TAG_Just: {
      V v_x_2441 = heff_field(v_x_2420, 0);
      heff_take_n(v_x_2420, 1ULL, 1);
      heff_drop(v_x_2429);
      v_t_2442 = v_x_2441;
      break;
    }
    default: heff_nomatch(v_x_2420);
    }
    V v_t_2443 = (g_std_2epath_2eparse(heff_dup(v_st_2439), v_t_2442));
    V v_t_2444 = (g_std_2epath_2eparse(heff_dup(v_st_2439), ((V)&g_heff_2ebuild_2ecommands_2eheffHome_24s310823312x832347879_str5)));
    V v_t_2445 = (g_std_2epath_2ejoin(v_t_2443, v_t_2444));
    v_x_2447 = ({ V a_0 = v_st_2439; V a_1 = v_t_2445; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2439); heff_drop(v_t_2445); r_; });
    break;
  }
  case TAG_Just: {
    V v_d_2446 = heff_field(v_x_2411, 0);
    heff_take_n(v_x_2411, 1ULL, 1);
    heff_drop(v_x_2420);
    heff_drop(v_x_2429);
    heff_drop(v_st_2439);
    v_x_2447 = v_d_2446;
    break;
  }
  default: heff_nomatch(v_x_2411);
  }
  V f_ = v_k_242;
  args[0] = v_x_2447;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eheffHome_24s310823312x832347879_lam5(V self, V *args) {
  V v_x_2429 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_x_2411 = heff_env(self)[2];
  V v_x_2420 = heff_env(self)[3];
  V v_k_242 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2431 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2eheffHome_24s310823312x832347879_lam6_clo)})});
  V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
  V v_t_2433 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2432})});
  V v_t_2434 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2433})});
  V v_t_2435 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2434})});
  V v_t_2436 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2435})});
  V v_t_2437 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2436})});
  return (g_co_2eop_24s310169282x2049378029(v_e_240, v_t_2437, v_hd_241, heff_clo_n(g_heff_2ebuild_2ecommands_2eheffHome_24s310823312x832347879_lam7, 1, 4, (V[]){v_x_2411, v_x_2420, v_x_2429, v_k_242})));
}
V g_heff_2ebuild_2ecommands_2eheffHome_24s310823312x832347879_lam3(V self, V *args) {
  V v_x_2420 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_x_2411 = heff_env(self)[2];
  V v_k_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2422 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_GetEnv, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eheffHome_24s310823312x832347879_str2), ((V)&g_heff_2ebuild_2ecommands_2eheffHome_24s310823312x832347879_lam4_clo)})});
  V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
  V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
  V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
  V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
  V v_t_2427 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
  V v_t_2428 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2427})});
  return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), v_t_2428, heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2ecommands_2eheffHome_24s310823312x832347879_lam5, 1, 5, (V[]){v_e_240, v_hd_241, v_x_2411, v_x_2420, v_k_242})));
}
V g_heff_2ebuild_2ecommands_2eheffHome_24s310823312x832347879_lam1(V self, V *args) {
  V v_x_2411 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2413 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_GetEnv, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eheffHome_24s310823312x832347879_str1), ((V)&g_heff_2ebuild_2ecommands_2eheffHome_24s310823312x832347879_lam2_clo)})});
  V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
  V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2418})});
  return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), v_t_2419, heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2ecommands_2eheffHome_24s310823312x832347879_lam3, 1, 4, (V[]){v_e_240, v_hd_241, v_x_2411, v_k_242})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ekeptParts_24s683971978x1312876275_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ekeptParts_24s683971978x1312876275_str1, 1, "_");
V g_heff_2ebuild_2ecommands_2ekeptParts_24s683971978x1312876275_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ekeptParts_24s683971978x1312876275_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ekeptParts_24s683971978x1312876275_lam1, 2, 0};
V g_heff_2ebuild_2ecommands_2ekeptParts_24s683971978x1312876275_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ekeptParts_24s683971978x1312876275_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ekeptParts_24s683971978x1312876275_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ekeptParts_24s683971978x1312876275_entry, 10, 0};

V g_heff_2ebuild_2ecommands_2ekeptParts_24s683971978x1312876275(V v_e_240, V v_bi_241, V v_dir_242, V v_rt_243, V v_done_244, V v_c_245, V v_available_246, V v_r_247, V v_hd_248, V v_k_249) {
top: ;
  return (g_heff_2ebuild_2ecommands_2eselfHash_24s1263115327x65083815(heff_dup(v_e_240), heff_dup(heff_rfield(v_bi_241, 0)), heff_dup(v_hd_248), heff_clo_n(g_heff_2ebuild_2ecommands_2ekeptParts_24s683971978x1312876275_lam0, 1, 10, (V[]){v_bi_241, v_e_240, v_hd_248, v_dir_242, v_rt_243, v_done_244, v_c_245, v_available_246, v_r_247, v_k_249})));
}
V g_heff_2ebuild_2ecommands_2ekeptParts_24s683971978x1312876275_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ekeptParts_24s683971978x1312876275(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8], a[9]);
}
V g_heff_2ebuild_2ecommands_2ekeptParts_24s683971978x1312876275_lam1(V self, V *args) {
  V v_hd_2411 = args[0];
  V v_k_2412 = args[1];
  heff_drop(v_hd_2411);
  V f_ = v_k_2412;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ekeptParts_24s683971978x1312876275_lam2(V self, V *args) {
  V v_x_2415 = args[0];
  V v_x_2410 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_bi_241 = heff_env(self)[2];
  V v_dir_242 = heff_env(self)[3];
  V v_rt_243 = heff_env(self)[4];
  V v_done_244 = heff_env(self)[5];
  V v_c_245 = heff_env(self)[6];
  V v_available_246 = heff_env(self)[7];
  V v_r_247 = heff_env(self)[8];
  V v_hd_248 = heff_env(self)[9];
  V v_k_249 = heff_env(self)[10];
  heff_clo_take(self, 11);
  V v_t_2416 = (g_heff_2ebuild_2ecommands_2ebacksOf(v_x_2410, v_x_2415));
  return ({ V a_0 = v_e_240; V a_1 = v_bi_241; V a_2 = v_dir_242; V a_3 = v_rt_243; V a_4 = v_done_244; V a_5 = v_c_245; V a_6 = v_available_246; V a_7 = v_r_247; V a_8 = v_x_2410; V a_9 = v_x_2415; V a_10 = v_t_2416; V a_11 = v_hd_248; V a_12 = v_k_249; V r_ = (g_heff_2ebuild_2ecommands_2ekeptWith_24s1814069843x1801086089(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9, a_10, a_11, a_12)); heff_drop(v_x_2415); r_; });
}
V g_heff_2ebuild_2ecommands_2ekeptParts_24s683971978x1312876275_lam0(V self, V *args) {
  V v_x_2410 = args[0];
  V v_bi_241 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_hd_248 = heff_env(self)[2];
  V v_dir_242 = heff_env(self)[3];
  V v_rt_243 = heff_env(self)[4];
  V v_done_244 = heff_env(self)[5];
  V v_c_245 = heff_env(self)[6];
  V v_available_246 = heff_env(self)[7];
  V v_r_247 = heff_env(self)[8];
  V v_k_249 = heff_env(self)[9];
  heff_clo_take(self, 10);
  V v_c_2414;
  if (heff_strEq_c_lent(v_x_2410, ((V)&g_heff_2ebuild_2ecommands_2ekeptParts_24s683971978x1312876275_str0), 2)) {
    v_c_2414 = ((V)&g_heff_2ebuild_2ecommands_2ekeptParts_24s683971978x1312876275_lam1_clo);
  } else {
    V v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ekeptParts_24s683971978x1312876275_str1), heff_dup(heff_rfield(v_bi_241, 2))});
    v_c_2414 = (g_heff_2ebuild_2ecommands_2ereadBacks_24s960701544x1414957442(heff_dup(v_e_240), heff_dup(heff_rfield(v_bi_241, 0)), v_t_2413));
  }
  V f_ = v_c_2414;
  heff_room[0] = heff_dup(v_hd_248);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ekeptParts_24s683971978x1312876275_lam2, 1, 11, (V[]){v_x_2410, v_e_240, v_bi_241, v_dir_242, v_rt_243, v_done_244, v_c_245, v_available_246, v_r_247, v_hd_248, v_k_249});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1609818333x944097652_str0, 6, "heff: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1609818333x944097652_str1, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1609818333x944097652_str2, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1609818333x944097652_str3, 6, "heff: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1609818333x944097652_str4, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1609818333x944097652_str5, 1, "/");
V g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1609818333x944097652_lam0(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1609818333x944097652_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1609818333x944097652_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1609818333x944097652_entry, 12, 0};

V g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1609818333x944097652(V v_e_240, V v_bi_241, V v_file_242, V v_name_243, V v_outPath_244, V v_rt_245, V v_failed_246, V v_done_247, V v_c_248, V v_available_249, V v_z_2410, V v_z_2411) {
top: ;
  V v_t_2412 = (g_heff_2ebuild_2edriver_2ecandidatesOf(heff_dup(v_c_248)));
  V v_t_2413 = ({ V a_0 = v_t_2412; V r_ = (g_heff_2ebuild_2edriver_2ecandLeaves(a_0)); heff_drop(v_t_2412); r_; });
  V v_t_2414 = (g_heff_2ebuild_2edriver_2enubStrD(v_t_2413));
  V v_t_2416 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1609818333x944097652_lam0, 1, 1, (V[]){heff_dup(v_available_249)}), v_t_2414));
  HeffT2 v_t_2417 = (g_heff_2ebuild_2edriver_2efindRunnable_24cpr(v_t_2416, heff_dup(v_c_248), v_name_243));
  {
    V v_field_2419 = v_t_2417.f[1];
    int64_t v_tag_2418 = ((int64_t)v_t_2417.f[0]);
    if ((v_tag_2418 == ((int64_t)0ULL))) {
      heff_drop(v_bi_241);
      heff_drop(v_outPath_244);
      heff_drop_rec(v_rt_245, 2);
      heff_drop(v_done_247);
      heff_drop_rec(v_c_248, 14);
      heff_drop(v_available_249);
      V v_why_2420 = v_field_2419;
      V v_t_2421 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1609818333x944097652_str0), heff_dup(v_file_242)), ((V)&g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1609818333x944097652_str1));
      V v_t_2422 = heff_strAppend(heff_strAppend(v_t_2421, heff_dup(v_why_2420)), ((V)&g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1609818333x944097652_str2));
      V v_t_2423 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2422, NTAG(TAG_MkUnit)});
      V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
      V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
      V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
      V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
      V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
      V v_t_2429 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2428})});
      return (g_co_2eop_24s310169282x2049378029(v_e_240, heff_tag_n(TAG_InR, 1, (V[]){v_t_2429}), heff_dup(v_z_2410), heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1609818333x944097652_lam1, 1, 5, (V[]){v_file_242, v_failed_246, v_why_2420, v_z_2410, v_z_2411})));
    } else {
      heff_drop(v_file_242);
      heff_drop(v_failed_246);
      V v_r_2432 = v_field_2419;
      int64_t v_t_2433 = (heff_unbox_word(heff_strLength_lent(v_outPath_244, 0)) - ((int64_t)1ULL));
      V v_t_2434 = heff_strSlice(heff_dup(v_outPath_244), heff_box_word(v_t_2433), heff_strLength_lent(v_outPath_244, 0));
      if (heff_strEq_c(v_t_2434, ((V)&g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1609818333x944097652_str5))) {
        int64_t v_t_2435 = (heff_unbox_word(heff_strLength_lent(v_outPath_244, 0)) - ((int64_t)1ULL));
        return (g_heff_2ebuild_2ecommands_2ekeptParts_24s683971978x1312876275(v_e_240, v_bi_241, heff_strSlice(v_outPath_244, MK_INT(0LL), heff_box_word(v_t_2435)), v_rt_245, v_done_247, v_c_248, v_available_249, v_r_2432, v_z_2410, v_z_2411));
      } else {
        heff_drop(v_bi_241);
        V v_t_2436 = heff_get_n(heff_get_n(v_c_248, 5, 14), 0, 10);
        V v_t_2437 = (g_heff_2ecompile_2eemitc_2ecompileProgramC(heff_take_field(v_rt_245, 0), v_available_249, v_t_2436, heff_take_field(v_r_2432, 0), heff_get_n(v_r_2432, 1, 2)));
        return (g_heff_2ebuild_2ecommands_2ewriteOutC_24s196946078x469800039(v_e_240, v_outPath_244, heff_get_n(v_rt_245, 1, 2), v_done_247, v_t_2437, v_z_2410, v_z_2411));
      }
    }
  }
}
V g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1609818333x944097652_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1609818333x944097652(a[0], a[1], a[2], a3, a[4], a[5], a[6], a[7], a[8], a[9], a[10], a[11]); heff_drop(a3); return r;
}
V g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1609818333x944097652_lam0(V self, V *args) {
  V v_k_2415 = args[0];
  V v_available_249 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_available_249; V a_1 = v_k_2415; V r_ = (g_heff_2ebuild_2ecommands_2eprovidesLeafC(a_0, a_1)); heff_drop(v_available_249); r_; });
}
V g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1609818333x944097652_lam1(V self, V *args) {
  V v_x_2430 = args[0];
  V v_file_242 = heff_env(self)[0];
  V v_failed_246 = heff_env(self)[1];
  V v_why_2420 = heff_env(self)[2];
  V v_z_2410 = heff_env(self)[3];
  V v_z_2411 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2430);
  V v_t_2431 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1609818333x944097652_str3), v_file_242), ((V)&g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1609818333x944097652_str4));
  V f_ = v_failed_246;
  heff_room[0] = heff_strAppend(v_t_2431, v_why_2420);
  heff_room[1] = v_z_2410;
  heff_room[2] = v_z_2411;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2epromoteCmd_24s704215115x133853853_str0, 4, "heff");
V g_heff_2ebuild_2ecommands_2epromoteCmd_24s704215115x133853853_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2epromoteCmd_24s704215115x133853853_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2epromoteCmd_24s704215115x133853853_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2epromoteCmd_24s704215115x133853853_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2epromoteCmd_24s704215115x133853853_entry, 4, 0};

V g_heff_2ebuild_2ecommands_2epromoteCmd_24s704215115x133853853(V v_e_240, V v_file_241, V v_hd_242, V v_k_243) {
top: ;
  HEFF_LAST return g_heff_2ebuild_2ecommands_2eload_24s2043842606x1315457906(heff_dup(v_e_240), heff_dup(v_file_241), heff_dup(v_hd_242), heff_clo_n(g_heff_2ebuild_2ecommands_2epromoteCmd_24s704215115x133853853_lam0, 1, 4, (V[]){v_e_240, v_hd_242, v_file_241, v_k_243}));
}
V g_heff_2ebuild_2ecommands_2epromoteCmd_24s704215115x133853853_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2epromoteCmd_24s704215115x133853853(a[0], a[1], a[2], a[3]);
}
V g_heff_2ebuild_2ecommands_2epromoteCmd_24s704215115x133853853_lam2(V self, V *args) {
  V v_x_247 = args[0];
  V v_x_245 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_file_241 = heff_env(self)[2];
  V v_hd_242 = heff_env(self)[3];
  V v_k_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_248 = heff_bool(heff_intLt_c_lent(MK_INT(0LL), v_x_245, 1));
  heff_drop(v_x_245);
  return ({ V a_0 = v_e_240; V a_1 = v_file_241; V a_2 = v_t_248; V a_3 = heff_get_n(v_x_247, 0, 2); V a_4 = v_hd_242; V a_5 = v_k_243; V r_ = (g_heff_2ebuild_2ecommands_2epromoteDiags_24s1922111359x1834555732(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_t_248); r_; });
}
V g_heff_2ebuild_2ecommands_2epromoteCmd_24s704215115x133853853_lam1(V self, V *args) {
  V v_x_245 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_x_244 = heff_env(self)[1];
  V v_hd_242 = heff_env(self)[2];
  V v_file_241 = heff_env(self)[3];
  V v_k_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_c_246 = (g_heff_2ebuild_2esession_2ecachedAcc_24s1465745022x907203497(heff_dup(v_e_240), v_x_244));
  V f_ = v_c_246;
  heff_room[0] = heff_dup(v_hd_242);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2epromoteCmd_24s704215115x133853853_lam2, 1, 5, (V[]){v_x_245, v_e_240, v_file_241, v_hd_242, v_k_243});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2epromoteCmd_24s704215115x133853853_lam0(V self, V *args) {
  V v_x_244 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_hd_242 = heff_env(self)[1];
  V v_file_241 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2ebuild_2ecommands_2eprintErrs_24s1758719709x679644559(heff_dup(v_e_240), ((V)&g_heff_2ebuild_2ecommands_2epromoteCmd_24s704215115x133853853_str0), heff_dup(heff_rfield(v_x_244, 1)), MK_INT(0LL), heff_dup(v_hd_242), heff_clo_n(g_heff_2ebuild_2ecommands_2epromoteCmd_24s704215115x133853853_lam1, 1, 5, (V[]){v_e_240, v_x_244, v_hd_242, v_file_241, v_k_243})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2efmtSrc_24s211467399x186137324_str0, 6, "heff: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efmtSrc_24s211467399x186137324_str1, 16, " not formatted: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efmtSrc_24s211467399x186137324_str2, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efmtSrc_24s211467399x186137324_str3, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efmtSrc_24s211467399x186137324_str4, 23, "heff fmt: cannot write ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efmtSrc_24s211467399x186137324_str5, 1, "\012");
V g_heff_2ebuild_2ecommands_2efmtSrc_24s211467399x186137324_lam0(V self, V *args);
V g_heff_2ebuild_2ecommands_2efmtSrc_24s211467399x186137324_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2efmtSrc_24s211467399x186137324_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2efmtSrc_24s211467399x186137324_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2efmtSrc_24s211467399x186137324_lam2, 3, 0};
V g_heff_2ebuild_2ecommands_2efmtSrc_24s211467399x186137324_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2efmtSrc_24s211467399x186137324_lam3(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2efmtSrc_24s211467399x186137324_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2efmtSrc_24s211467399x186137324_entry, 7, 0};

V g_heff_2ebuild_2ecommands_2efmtSrc_24s211467399x186137324(V v_e_240, V v_checkOnly_241, V v_f_242, V v_src_243, V v_fix_244, V v_z_245, V v_z_246) {
top: ;
  HeffT2 v_t_247 = (g_heff_2esyntax_2eformat_2eformatIn_24cpr(v_fix_244, heff_dup(v_src_243)));
  {
    V v_field_249 = v_t_247.f[1];
    int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
    if ((v_tag_248 == ((int64_t)0ULL))) {
      heff_drop(v_src_243);
      V v_why_2410 = v_field_249;
      V v_t_2411 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efmtSrc_24s211467399x186137324_str0), v_f_242), ((V)&g_heff_2ebuild_2ecommands_2efmtSrc_24s211467399x186137324_str1));
      V v_t_2412 = heff_strAppend(heff_strAppend(v_t_2411, v_why_2410), ((V)&g_heff_2ebuild_2ecommands_2efmtSrc_24s211467399x186137324_str2));
      V v_t_2413 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2412, NTAG(TAG_MkUnit)});
      V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
      V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
      V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
      V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
      V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
      V v_t_2419 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2418})});
      return (g_co_2eop_24s310169282x2049378029(v_e_240, heff_tag_n(TAG_InR, 1, (V[]){v_t_2419}), v_z_245, heff_clo_n(g_heff_2ebuild_2ecommands_2efmtSrc_24s211467399x186137324_lam0, 1, 1, (V[]){v_z_246})));
    } else {
      V v_out_2421 = v_field_249;
      if (heff_strEq_c_lent(v_out_2421, v_src_243, 2)) {
        heff_drop(v_e_240);
        heff_drop(v_f_242);
        heff_drop(v_z_245);
        heff_drop(v_out_2421);
        return heff_tail(v_z_246, 1, (V[]){MK_INT(0LL)});
      } else {
        if ((heff_dup(v_checkOnly_241) == NTAG(TAG_True))) {
          heff_drop(v_out_2421);
          V v_t_2422 = heff_tag_n(TAG_Write, 2, (V[]){heff_strAppend(v_f_242, ((V)&g_heff_2ebuild_2ecommands_2efmtSrc_24s211467399x186137324_str3)), NTAG(TAG_MkUnit)});
          V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
          V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
          V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
          V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
          V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
          V v_t_2428 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2427})});
          return (g_co_2eop_24s310169282x2049378029(v_e_240, heff_tag_n(TAG_InR, 1, (V[]){v_t_2428}), v_z_245, heff_clo_n(g_heff_2ebuild_2ecommands_2efmtSrc_24s211467399x186137324_lam1, 1, 1, (V[]){v_z_246})));
        } else {
          V v_path_2430 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), heff_dup(v_f_242)));
          V v_c_2431 = ({ V a_0 = heff_dup(v_e_240); V a_1 = v_path_2430; V a_2 = v_out_2421; V r_ = (g_std_2efilesystem_2ewriteFile_24s1279893433x291681682(a_0, a_1, a_2)); heff_drop(v_path_2430); r_; });
          V v_t_2432 = (g_exception_2eattempted(heff_dup(v_e_240)));
          V v_c_2436 = heff_tr(heff_call(v_c_2431, 2, (V[]){v_t_2432, ((V)&g_heff_2ebuild_2ecommands_2efmtSrc_24s211467399x186137324_lam2_clo)}));
          return heff_tail(v_c_2436, 2, (V[]){heff_dup(v_z_245), heff_clo_n(g_heff_2ebuild_2ecommands_2efmtSrc_24s211467399x186137324_lam3, 1, 4, (V[]){v_f_242, v_e_240, v_z_245, v_z_246})});
        }
      }
    }
  }
}
V g_heff_2ebuild_2ecommands_2efmtSrc_24s211467399x186137324_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2ecommands_2efmtSrc_24s211467399x186137324(a[0], a1, a[2], a[3], a[4], a[5], a[6]); heff_drop(a1); return r;
}
V g_heff_2ebuild_2ecommands_2efmtSrc_24s211467399x186137324_lam0(V self, V *args) {
  V v_x_2420 = args[0];
  V v_z_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2420);
  V f_ = v_z_246;
  args[0] = MK_INT(1LL);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2efmtSrc_24s211467399x186137324_lam1(V self, V *args) {
  V v_x_2429 = args[0];
  V v_z_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2429);
  V f_ = v_z_246;
  args[0] = MK_INT(1LL);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2efmtSrc_24s211467399x186137324_lam2(V self, V *args) {
  V v_x_2433 = args[0];
  V v_hd_2434 = args[1];
  V v_k_2435 = args[2];
  heff_drop(v_hd_2434);
  V f_ = v_k_2435;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2433});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2efmtSrc_24s211467399x186137324_lam4(V self, V *args) {
  V v_x_2447 = args[0];
  V v_z_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2447);
  V f_ = v_z_246;
  args[0] = MK_INT(1LL);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2efmtSrc_24s211467399x186137324_lam3(V self, V *args) {
  V v_x_2437 = args[0];
  V v_f_242 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_z_245 = heff_env(self)[2];
  V v_z_246 = heff_env(self)[3];
  heff_clo_take(self, 4);
  switch (heff_tag_of(v_x_2437)) {
  case TAG_Left: {
    V v_ru_24x_2437_24Left = heff_take_reuse_n(v_x_2437, 0ULL, 1);
    V v_t_2439 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efmtSrc_24s211467399x186137324_str4), v_f_242), ((V)&g_heff_2ebuild_2ecommands_2efmtSrc_24s211467399x186137324_str5));
    V v_t_2440 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2439, NTAG(TAG_MkUnit)});
    V v_t_2441 = heff_tag_at_n(v_ru_24x_2437_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2440})});
    V v_t_2442 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2441})});
    V v_t_2443 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2442})});
    V v_t_2444 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2443})});
    V v_t_2445 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2444})});
    V v_t_2446 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2445})});
    return (g_co_2eop_24s310169282x2049378029(v_e_240, heff_tag_n(TAG_InR, 1, (V[]){v_t_2446}), v_z_245, heff_clo_n(g_heff_2ebuild_2ecommands_2efmtSrc_24s211467399x186137324_lam4, 1, 1, (V[]){v_z_246})));
  }
  case TAG_Right: {
    heff_take_n(v_x_2437, 0ULL, 1);
    heff_drop(v_f_242);
    heff_drop(v_e_240);
    heff_drop(v_z_245);
    V f_ = v_z_246;
    args[0] = MK_INT(0LL);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_2437);
  }
}
V g_heff_2ebuild_2ecommands_2enotInProject_24s1239925928x1402397320_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2enotInProject_24s1239925928x1402397320_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2enotInProject_24s1239925928x1402397320_lam0, 2, 0};
V g_heff_2ebuild_2ecommands_2enotInProject_24s1239925928x1402397320_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2enotInProject_24s1239925928x1402397320_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2enotInProject_24s1239925928x1402397320_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2enotInProject_24s1239925928x1402397320_lam1, 1, 0};
V g_heff_2ebuild_2ecommands_2enotInProject_24s1239925928x1402397320_lam5(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2enotInProject_24s1239925928x1402397320_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2enotInProject_24s1239925928x1402397320_lam5, 3, 0};
V g_heff_2ebuild_2ecommands_2enotInProject_24s1239925928x1402397320_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2enotInProject_24s1239925928x1402397320_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2enotInProject_24s1239925928x1402397320_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2enotInProject_24s1239925928x1402397320_lam9(V self, V *args);
V g_heff_2ebuild_2ecommands_2enotInProject_24s1239925928x1402397320_lam8(V self, V *args);
V g_heff_2ebuild_2ecommands_2enotInProject_24s1239925928x1402397320_lam7(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2enotInProject_24s1239925928x1402397320_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2enotInProject_24s1239925928x1402397320_entry, 4, 0};

V g_heff_2ebuild_2ecommands_2enotInProject_24s1239925928x1402397320(V v_e_240, V v_st_241, V v_t_242, V v_x3_243) {
top: ;
  switch (heff_tag_of(v_x3_243)) {
  case TAG_Nil: {
    heff_drop(v_e_240);
    heff_drop(v_st_241);
    heff_drop_rec(v_t_242, 6);
    return ((V)&g_heff_2ebuild_2ecommands_2enotInProject_24s1239925928x1402397320_lam0_clo);
  }
  case TAG_Cons: {
    V v_n_246 = heff_field(v_x3_243, 0);
    V v_rest_247 = heff_field(v_x3_243, 1);
    heff_take_n(v_x3_243, 3ULL, 2);
    V v_e_248 = heff_dup(v_e_240);
    V v_t_249 = (g_std_2epath_2eparse(heff_dup(v_st_241), heff_dup(heff_rfield(v_t_242, 0))));
    V v_t_2410 = (g_std_2epath_2eparse(heff_dup(v_st_241), heff_dup(v_n_246)));
    V v_t_2411 = (g_std_2epath_2ejoin(v_t_249, v_t_2410));
    V v_path_2412 = ({ V a_0 = v_st_241; V a_1 = v_t_2411; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2411); r_; });
    V v_path_2413 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), heff_dup(v_path_2412)));
    V v_c_2414 = (g_std_2efilesystem_2ereadDirectory_24s1485822734x1304823189(heff_dup(v_e_248), v_path_2413));
    V v_t_2415 = (g_exception_2eattempted(heff_dup(v_e_248)));
    V v_c_2420 = heff_tr(heff_call(v_c_2414, 2, (V[]){v_t_2415, ((V)&g_heff_2ebuild_2ecommands_2enotInProject_24s1239925928x1402397320_lam1_clo)}));
    V v_c_2436 = heff_clo_n(g_heff_2ebuild_2ecommands_2enotInProject_24s1239925928x1402397320_lam3, 2, 3, (V[]){v_c_2420, v_path_2412, v_e_248});
    return heff_clo_n(g_heff_2ebuild_2ecommands_2enotInProject_24s1239925928x1402397320_lam7, 2, 6, (V[]){v_c_2436, v_e_240, v_st_241, v_t_242, v_rest_247, v_n_246});
  }
  default: return heff_nomatch(v_x3_243);
  }
}
V g_heff_2ebuild_2ecommands_2enotInProject_24s1239925928x1402397320_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2enotInProject_24s1239925928x1402397320(a[0], a[1], a[2], a[3]);
}
V g_heff_2ebuild_2ecommands_2enotInProject_24s1239925928x1402397320_lam0(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k_245 = args[1];
  heff_drop(v_hd_244);
  V f_ = v_k_245;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2enotInProject_24s1239925928x1402397320_lam2(V self, V *args) {
  V v_hd_2418 = args[0];
  V v_k_2419 = args[1];
  V v_x_2417 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2418);
  V f_ = v_k_2419;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2417});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2enotInProject_24s1239925928x1402397320_lam1(V self, V *args) {
  V v_x_2416 = args[0];
  V v_x_2417 = (g_list_2emap_24s219049803x1458391381(v_x_2416));
  return heff_clo_n(g_heff_2ebuild_2ecommands_2enotInProject_24s1239925928x1402397320_lam2, 2, 1, (V[]){v_x_2417});
}
V g_heff_2ebuild_2ecommands_2enotInProject_24s1239925928x1402397320_lam5(V self, V *args) {
  V v_x_2428 = args[0];
  V v_hd_2429 = args[1];
  V v_k_2430 = args[2];
  heff_drop(v_hd_2429);
  V f_ = v_k_2430;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2428});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2enotInProject_24s1239925928x1402397320_lam6(V self, V *args) {
  V v_x_2432 = args[0];
  V v_k_2422 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x_2432)) {
  case TAG_Left: {
    heff_take_n(v_x_2432, 0ULL, 1);
    V f_ = v_k_2422;
    args[0] = NTAG(TAG_False);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Right: {
    heff_take_n(v_x_2432, 0ULL, 1);
    V f_ = v_k_2422;
    args[0] = NTAG(TAG_True);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_2432);
  }
}
V g_heff_2ebuild_2ecommands_2enotInProject_24s1239925928x1402397320_lam4(V self, V *args) {
  V v_x_2423 = args[0];
  V v_path_2412 = heff_env(self)[0];
  V v_e_248 = heff_env(self)[1];
  V v_hd_2421 = heff_env(self)[2];
  V v_k_2422 = heff_env(self)[3];
  heff_clo_take(self, 4);
  switch (heff_tag_of(v_x_2423)) {
  case TAG_Left: {
    heff_take_n(v_x_2423, 0ULL, 1);
    V v_path_2425 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_path_2412));
    V v_c_2426 = ({ V a_0 = heff_dup(v_e_248); V a_1 = v_path_2425; V r_ = (g_std_2efilesystem_2ereadFile_24s1206250698x830238241(a_0, a_1)); heff_drop(v_path_2425); r_; });
    V v_t_2427 = (g_exception_2eattempted(v_e_248));
    V v_c_2431 = heff_tr(heff_call(v_c_2426, 2, (V[]){v_t_2427, ((V)&g_heff_2ebuild_2ecommands_2enotInProject_24s1239925928x1402397320_lam5_clo)}));
    V f_ = v_c_2431;
    heff_room[0] = v_hd_2421;
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2enotInProject_24s1239925928x1402397320_lam6, 1, 1, (V[]){v_k_2422});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_Right: {
    heff_take_n(v_x_2423, 0ULL, 1);
    heff_drop(v_path_2412);
    heff_drop(v_e_248);
    heff_drop(v_hd_2421);
    V f_ = v_k_2422;
    args[0] = NTAG(TAG_True);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_2423);
  }
}
V g_heff_2ebuild_2ecommands_2enotInProject_24s1239925928x1402397320_lam3(V self, V *args) {
  V v_hd_2421 = args[0];
  V v_k_2422 = args[1];
  V v_c_2420 = heff_env(self)[0];
  V v_path_2412 = heff_env(self)[1];
  V v_e_248 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_2420;
  args[0] = heff_dup(v_hd_2421);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2enotInProject_24s1239925928x1402397320_lam4, 1, 4, (V[]){v_path_2412, v_e_248, v_hd_2421, v_k_2422});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2ecommands_2enotInProject_24s1239925928x1402397320_lam9(V self, V *args) {
  V v_x_2441 = args[0];
  V v_x_2439 = heff_env(self)[0];
  V v_n_246 = heff_env(self)[1];
  V v_k_2438 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2442;
  if ((heff_dup(v_x_2439) == NTAG(TAG_True))) {
    heff_drop(v_x_2439);
    heff_drop(v_n_246);
    v_t_2442 = v_x_2441;
  } else {
    heff_drop(v_x_2439);
    v_t_2442 = heff_tag_n(TAG_Cons, 2, (V[]){v_n_246, v_x_2441});
  }
  V f_ = v_k_2438;
  args[0] = v_t_2442;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2enotInProject_24s1239925928x1402397320_lam8(V self, V *args) {
  V v_x_2439 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_st_241 = heff_env(self)[1];
  V v_t_242 = heff_env(self)[2];
  V v_rest_247 = heff_env(self)[3];
  V v_hd_2437 = heff_env(self)[4];
  V v_n_246 = heff_env(self)[5];
  V v_k_2438 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_c_2440 = (g_heff_2ebuild_2ecommands_2enotInProject_24s1239925928x1402397320(v_e_240, v_st_241, v_t_242, v_rest_247));
  V f_ = v_c_2440;
  heff_room[0] = v_hd_2437;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2enotInProject_24s1239925928x1402397320_lam9, 1, 3, (V[]){v_x_2439, v_n_246, v_k_2438});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2enotInProject_24s1239925928x1402397320_lam7(V self, V *args) {
  V v_hd_2437 = args[0];
  V v_k_2438 = args[1];
  V v_c_2436 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_st_241 = heff_env(self)[2];
  V v_t_242 = heff_env(self)[3];
  V v_rest_247 = heff_env(self)[4];
  V v_n_246 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V f_ = v_c_2436;
  args[0] = heff_dup(v_hd_2437);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2enotInProject_24s1239925928x1402397320_lam8, 1, 7, (V[]){v_e_240, v_st_241, v_t_242, v_rest_247, v_hd_2437, v_n_246, v_k_2438});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eshipMoved_24s713012492x1635447620_str0, 1, " ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eshipMoved_24s713012492x1635447620_str1, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eshipMoved_24s713012492x1635447620_str2, 11, "cannot put ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eshipMoved_24s713012492x1635447620_str3, 13, " in place of ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eshipMoved_24s713012492x1635447620_str4, 6, "heff: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eshipMoved_24s713012492x1635447620_str5, 1, "\012");
V g_heff_2ebuild_2ecommands_2eshipMoved_24s713012492x1635447620_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eshipMoved_24s713012492x1635447620_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eshipMoved_24s713012492x1635447620_lam0, 3, 0};
V g_heff_2ebuild_2ecommands_2eshipMoved_24s713012492x1635447620_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2eshipMoved_24s713012492x1635447620_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2eshipMoved_24s713012492x1635447620_lam3(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eshipMoved_24s713012492x1635447620_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eshipMoved_24s713012492x1635447620_lam3, 3, 0};
V g_heff_2ebuild_2ecommands_2eshipMoved_24s713012492x1635447620_lam5(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eshipMoved_24s713012492x1635447620_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eshipMoved_24s713012492x1635447620_lam5, 3, 0};
V g_heff_2ebuild_2ecommands_2eshipMoved_24s713012492x1635447620_lam7(V self, V *args);
V g_heff_2ebuild_2ecommands_2eshipMoved_24s713012492x1635447620_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2eshipMoved_24s713012492x1635447620_lam4(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eshipMoved_24s713012492x1635447620_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eshipMoved_24s713012492x1635447620_entry, 9, 0};

V g_heff_2ebuild_2ecommands_2eshipMoved_24s713012492x1635447620(V v_e_240, V v_t_241, V v_fresh_242, V v_old_243, V v_to_244, V v_next_245, V v_x6_246, V v_z_247, V v_z_248) {
top: ;
  if ((heff_dup(v_x6_246) == NTAG(TAG_True))) {
    heff_drop(v_fresh_242);
    V v_path_249 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_old_243));
    V v_c_2410 = ({ V a_0 = heff_dup(v_e_240); V a_1 = v_path_249; V r_ = (g_std_2efilesystem_2eremove_24s450846999x1798011492(a_0, a_1)); heff_drop(v_path_249); r_; });
    V v_t_2411 = (g_exception_2eattempted(heff_dup(v_e_240)));
    V v_c_2415 = heff_tr(heff_call(v_c_2410, 2, (V[]){v_t_2411, ((V)&g_heff_2ebuild_2ecommands_2eshipMoved_24s713012492x1635447620_lam0_clo)}));
    return heff_tail(v_c_2415, 2, (V[]){heff_dup(v_z_247), heff_clo_n(g_heff_2ebuild_2ecommands_2eshipMoved_24s713012492x1635447620_lam1, 1, 6, (V[]){v_t_241, v_to_244, v_e_240, v_z_247, v_next_245, v_z_248})});
  } else {
    heff_drop_rec(v_t_241, 6);
    heff_drop(v_next_245);
    V v_path_2427 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_old_243));
    V v_to_2428 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), heff_dup(v_to_244)));
    V v_c_2429 = ({ V a_0 = heff_dup(v_e_240); V a_1 = v_path_2427; V a_2 = v_to_2428; V r_ = (g_std_2efilesystem_2emove_24s1592691554x274375227(a_0, a_1, a_2)); heff_drop(v_path_2427); heff_drop(v_to_2428); r_; });
    V v_t_2430 = (g_exception_2eattempted(heff_dup(v_e_240)));
    V v_c_2434 = heff_tr(heff_call(v_c_2429, 2, (V[]){v_t_2430, ((V)&g_heff_2ebuild_2ecommands_2eshipMoved_24s713012492x1635447620_lam3_clo)}));
    return heff_tail(v_c_2434, 2, (V[]){heff_dup(v_z_247), heff_clo_n(g_heff_2ebuild_2ecommands_2eshipMoved_24s713012492x1635447620_lam4, 1, 5, (V[]){v_fresh_242, v_e_240, v_z_247, v_to_244, v_z_248})});
  }
}
V g_heff_2ebuild_2ecommands_2eshipMoved_24s713012492x1635447620_entry(V self, V *a) {
  (void)self;
  V a6 = a[6]; V r = g_heff_2ebuild_2ecommands_2eshipMoved_24s713012492x1635447620(a[0], a[1], a[2], a[3], a[4], a[5], a6, a[7], a[8]); heff_drop(a6); return r;
}
V g_heff_2ebuild_2ecommands_2eshipMoved_24s713012492x1635447620_lam0(V self, V *args) {
  V v_x_2412 = args[0];
  V v_hd_2413 = args[1];
  V v_k_2414 = args[2];
  heff_drop(v_hd_2413);
  V f_ = v_k_2414;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2412});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eshipMoved_24s713012492x1635447620_lam2(V self, V *args) {
  V v_x_2426 = args[0];
  V v_next_245 = heff_env(self)[0];
  V v_z_247 = heff_env(self)[1];
  V v_z_248 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2426);
  V f_ = v_next_245;
  heff_room[0] = v_z_247;
  heff_room[1] = v_z_248;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2eshipMoved_24s713012492x1635447620_lam1(V self, V *args) {
  V v_x_2416 = args[0];
  V v_t_241 = heff_env(self)[0];
  V v_to_244 = heff_env(self)[1];
  V v_e_240 = heff_env(self)[2];
  V v_z_247 = heff_env(self)[3];
  V v_next_245 = heff_env(self)[4];
  V v_z_248 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_2416);
  V v_t_2417 = heff_strAppend(heff_get_n(v_t_241, 2, 6), ((V)&g_heff_2ebuild_2ecommands_2eshipMoved_24s713012492x1635447620_str0));
  V v_t_2418 = heff_strAppend(heff_strAppend(v_t_2417, v_to_244), ((V)&g_heff_2ebuild_2ecommands_2eshipMoved_24s713012492x1635447620_str1));
  V v_t_2419 = heff_tag_n(TAG_Write, 2, (V[]){v_t_2418, NTAG(TAG_MkUnit)});
  V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
  V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
  V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
  V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
  V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
  V v_t_2425 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2424})});
  return (g_co_2eop_24s310169282x2049378029(v_e_240, heff_tag_n(TAG_InR, 1, (V[]){v_t_2425}), heff_dup(v_z_247), heff_clo_n(g_heff_2ebuild_2ecommands_2eshipMoved_24s713012492x1635447620_lam2, 1, 3, (V[]){v_next_245, v_z_247, v_z_248})));
}
V g_heff_2ebuild_2ecommands_2eshipMoved_24s713012492x1635447620_lam3(V self, V *args) {
  V v_x_2431 = args[0];
  V v_hd_2432 = args[1];
  V v_k_2433 = args[2];
  heff_drop(v_hd_2432);
  V f_ = v_k_2433;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2431});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eshipMoved_24s713012492x1635447620_lam5(V self, V *args) {
  V v_x_2439 = args[0];
  V v_hd_2440 = args[1];
  V v_k_2441 = args[2];
  heff_drop(v_hd_2440);
  V f_ = v_k_2441;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2439});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eshipMoved_24s713012492x1635447620_lam7(V self, V *args) {
  V v_x_2453 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_z_247 = heff_env(self)[1];
  V v_z_248 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2453);
  V v_t_2454 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2455 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2454})});
  V v_t_2456 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2455})});
  V v_t_2457 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2456})});
  V v_t_2458 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2457})});
  V v_t_2459 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2458})});
  V v_t_2460 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2459})});
  return (g_co_2eop_24s310169282x2049378029(v_e_240, heff_tag_n(TAG_InR, 1, (V[]){v_t_2460}), v_z_247, v_z_248));
}
V g_heff_2ebuild_2ecommands_2eshipMoved_24s713012492x1635447620_lam6(V self, V *args) {
  V v_x_2443 = args[0];
  V v_fresh_242 = heff_env(self)[0];
  V v_to_244 = heff_env(self)[1];
  V v_e_240 = heff_env(self)[2];
  V v_z_247 = heff_env(self)[3];
  V v_z_248 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2443);
  V v_t_2444 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eshipMoved_24s713012492x1635447620_str2), v_fresh_242), ((V)&g_heff_2ebuild_2ecommands_2eshipMoved_24s713012492x1635447620_str3));
  V v_t_2445 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eshipMoved_24s713012492x1635447620_str4), heff_strAppend(v_t_2444, v_to_244));
  V v_t_2446 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_t_2445, ((V)&g_heff_2ebuild_2ecommands_2eshipMoved_24s713012492x1635447620_str5)), NTAG(TAG_MkUnit)});
  V v_t_2447 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2446})});
  V v_t_2448 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2447})});
  V v_t_2449 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2448})});
  V v_t_2450 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2449})});
  V v_t_2451 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2450})});
  V v_t_2452 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2451})});
  return (g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), heff_tag_n(TAG_InR, 1, (V[]){v_t_2452}), heff_dup(v_z_247), heff_clo_n(g_heff_2ebuild_2ecommands_2eshipMoved_24s713012492x1635447620_lam7, 1, 3, (V[]){v_e_240, v_z_247, v_z_248})));
}
V g_heff_2ebuild_2ecommands_2eshipMoved_24s713012492x1635447620_lam4(V self, V *args) {
  V v_x_2435 = args[0];
  V v_fresh_242 = heff_env(self)[0];
  V v_e_240 = heff_env(self)[1];
  V v_z_247 = heff_env(self)[2];
  V v_to_244 = heff_env(self)[3];
  V v_z_248 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2435);
  V v_path_2436 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), heff_dup(v_fresh_242)));
  V v_c_2437 = ({ V a_0 = heff_dup(v_e_240); V a_1 = v_path_2436; V r_ = (g_std_2efilesystem_2eremove_24s450846999x1798011492(a_0, a_1)); heff_drop(v_path_2436); r_; });
  V v_t_2438 = (g_exception_2eattempted(heff_dup(v_e_240)));
  V v_c_2442 = heff_tr(heff_call(v_c_2437, 2, (V[]){v_t_2438, ((V)&g_heff_2ebuild_2ecommands_2eshipMoved_24s713012492x1635447620_lam5_clo)}));
  V f_ = v_c_2442;
  heff_room[0] = heff_dup(v_z_247);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2eshipMoved_24s713012492x1635447620_lam6, 1, 5, (V[]){v_fresh_242, v_to_244, v_e_240, v_z_247, v_z_248});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprintEvals_24s546697161x1900854479_str0, 3, " = ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprintEvals_24s546697161x1900854479_str1, 1, "\012");
V g_heff_2ebuild_2ecommands_2eprintEvals_24s546697161x1900854479_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2eprintEvals_24s546697161x1900854479_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eprintEvals_24s546697161x1900854479_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eprintEvals_24s546697161x1900854479_entry, 4, 0};

V g_heff_2ebuild_2ecommands_2eprintEvals_24s546697161x1900854479(V v_e_240, V v_x1_241, V v_p_242, V v_p_243) {
top: ;
  switch (heff_tag_of(v_x1_241)) {
  case TAG_Nil: {
    heff_drop(v_e_240);
    heff_drop(v_p_242);
    return heff_tail(v_p_243, 1, (V[]){NTAG(TAG_False)});
  }
  case TAG_Cons: {
    V v_d_244 = heff_field(v_x1_241, 0);
    V v_rest_245 = heff_field(v_x1_241, 1);
    V v_ru_24x1_241_24Cons = heff_take_reuse_n(v_x1_241, 3ULL, 2);
    V v_name_246 = heff_take_field(v_d_244, 0);
    V v_value_247 = heff_take_field(v_d_244, 1);
    V v_bug_248 = heff_get_n(v_d_244, 2, 3);
    V v_t_249 = heff_strAppend(heff_strAppend(v_name_246, ((V)&g_heff_2ebuild_2ecommands_2eprintEvals_24s546697161x1900854479_str0)), v_value_247);
    V v_t_2410 = heff_tag_at_n(v_ru_24x1_241_24Cons, TAG_Write, 2, (V[]){heff_strAppend(v_t_249, ((V)&g_heff_2ebuild_2ecommands_2eprintEvals_24s546697161x1900854479_str1)), NTAG(TAG_MkUnit)});
    V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
    V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
    V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
    V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
    V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
    V v_t_2416 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2415})});
    HEFF_LAST return g_co_2eop_24s310169282x2049378029(heff_dup(v_e_240), heff_tag_n(TAG_InR, 1, (V[]){v_t_2416}), heff_dup(v_p_242), heff_clo_n(g_heff_2ebuild_2ecommands_2eprintEvals_24s546697161x1900854479_lam0, 1, 5, (V[]){v_e_240, v_rest_245, v_p_242, v_bug_248, v_p_243}));
  }
  default: return heff_nomatch(v_x1_241);
  }
}
V g_heff_2ebuild_2ecommands_2eprintEvals_24s546697161x1900854479_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eprintEvals_24s546697161x1900854479(a[0], a[1], a[2], a[3]);
}
V g_heff_2ebuild_2ecommands_2eprintEvals_24s546697161x1900854479_lam1(V self, V *args) {
  V v_x_2418 = args[0];
  V v_bug_248 = heff_env(self)[0];
  V v_p_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2419 = heff_bool(((heff_dup(v_bug_248) == NTAG(TAG_True)) || (heff_dup(v_x_2418) == NTAG(TAG_True))));
  heff_drop(v_x_2418);
  heff_drop(v_bug_248);
  V f_ = v_p_243;
  args[0] = v_t_2419;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eprintEvals_24s546697161x1900854479_lam0(V self, V *args) {
  V v_x_2417 = args[0];
  V v_e_240 = heff_env(self)[0];
  V v_rest_245 = heff_env(self)[1];
  V v_p_242 = heff_env(self)[2];
  V v_bug_248 = heff_env(self)[3];
  V v_p_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2417);
  return (g_heff_2ebuild_2ecommands_2eprintEvals_24s546697161x1900854479(v_e_240, v_rest_245, v_p_242, heff_clo_n(g_heff_2ebuild_2ecommands_2eprintEvals_24s546697161x1900854479_lam1, 1, 2, (V[]){v_bug_248, v_p_243})));
}