// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Close 2276
#define TAG_Done 47505
#define TAG_End 17255
#define TAG_Exit 20279
#define TAG_GetEnv 43934
#define TAG_Later 62002
#define TAG_Left 13886
#define TAG_MkGroup 19195
#define TAG_Open 48267
#define TAG_Platform 55558
#define TAG_Posix 44191
#define TAG_ProgramPath 46819
#define TAG_ReadFile 6783
#define TAG_RealPath 18882
#define TAG_Right 62770
#define TAG_Start 63542
#define TAG_Windows 49101
#define TAG_Write 36323
#define TAG_WriteErr 37283
#define TAG_WriteFile 62589
#define LBL_at 9882
#define LBL_backend 2032133329
#define LBL_build 295453320
#define LBL_diags 296935042
#define LBL_done 9584713
#define LBL_env 310119
#define LBL_errors 652506774
#define LBL_file 9638467
#define LBL_globals 352931696
#define LBL_heff 9694020
#define LBL_integrations 139286697
#define LBL_jobs 9763101
#define LBL_launch 837298910
#define LBL_loaded 849622832
#define LBL_module 878357911
#define LBL_msg 317947
#define LBL_name 9869138
#define LBL_outcomes 803130769
#define LBL_own 320000
#define LBL_package 1572278921
#define LBL_pages 307784670
#define LBL_path 9928940
#define LBL_paths 307797256
#define LBL_pattern 1588251091
#define LBL_pending 1696753626
#define LBL_program 2069953735
#define LBL_replace 1326354680
#define LBL_reports 1326460931
#define LBL_require 1327554473
#define LBL_root 10001833
#define LBL_source 1050636102
#define LBL_sources 357464573
#define LBL_style 311138763
#define LBL_top 324559
#define LBL_update 1108295668
#define LBL_version 583465758
#define LBL_wrong 314763719
static uint32_t shape_at__pending__launch[] = {LBL_at, LBL_pending, LBL_launch};
static uint32_t shape_module__heff__require__replace[] = {LBL_module, LBL_heff, LBL_require, LBL_replace};
static uint32_t shape_name__path__version[] = {LBL_name, LBL_path, LBL_version};
static uint32_t shape_program__env[] = {LBL_program, LBL_env};
V g_co_2eop_24s903439140x919002362(V, V, V);
V g_co_2eop_24s903439140x919002362_entry(V self, V *a);
extern Clo g_co_2eop_24s903439140x919002362_clo;
V g_co_2eop_24s94900133x232571340(V, V, V);
V g_co_2eop_24s94900133x232571340_entry(V self, V *a);
extern Clo g_co_2eop_24s94900133x232571340_clo;
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1567142318x1862190202(V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1567142318x1862190202_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1567142318x1862190202_clo;
V g_heff_2ebuild_2ecommands_2ecCmd_24s99213171x760810846(V, V, V);
V g_heff_2ebuild_2ecommands_2ecCmd_24s99213171x760810846_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecCmd_24s99213171x760810846_clo;
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s396496052x1044438622(V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s396496052x1044438622_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecLoadedOr_24s396496052x1044438622_clo;
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s832092935x437177150(V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s832092935x437177150_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecLoadedOr_24s832092935x437177150_clo;
V g_heff_2ebuild_2ecommands_2ecompileJsDiags_24s559977312x1067987643(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecompileJsDiags_24s559977312x1067987643_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecompileJsDiags_24s559977312x1067987643_clo;
V g_heff_2ebuild_2ecommands_2ecompileJsOut_24s253825103x859442878(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecompileJsOut_24s253825103x859442878_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecompileJsOut_24s253825103x859442878_clo;
V g_heff_2ebuild_2ecommands_2efetched_24s906028843x297767049(V, V, V, V);
V g_heff_2ebuild_2ecommands_2efetched_24s906028843x297767049_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2efetched_24s906028843x297767049_clo;
HeffT2 g_heff_2ebuild_2ecommands_2efirstErrorOf_24cpr(V);
V g_heff_2ebuild_2ecommands_2egetRequire_24s705774581x1881397247(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2egetRequire_24s705774581x1881397247_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2egetRequire_24s705774581x1881397247_clo;
V g_heff_2ebuild_2ecommands_2egoldenByte(V);
V g_heff_2ebuild_2ecommands_2egoldenByte_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2egoldenByte_clo;
V g_heff_2ebuild_2ecommands_2eintegrationMainName_get(void);
V g_heff_2ebuild_2ecommands_2eload_24s1185299161x1866120155(V);
V g_heff_2ebuild_2ecommands_2eload_24s1185299161x1866120155_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eload_24s1185299161x1866120155_clo;
V g_heff_2ebuild_2ecommands_2enoRes_get(void);
V g_heff_2ebuild_2ecommands_2eonPathHint_24s949169181x1811404266(V, V, V, V);
V g_heff_2ebuild_2ecommands_2eonPathHint_24s949169181x1811404266_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eonPathHint_24s949169181x1811404266_clo;
V g_heff_2ebuild_2ecommands_2epassedOver(V, V);
V g_heff_2ebuild_2ecommands_2epassedOver_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2epassedOver_clo;
V g_heff_2ebuild_2ecommands_2eplaceAll_24s97124616x701649523(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eplaceAll_24s97124616x701649523_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eplaceAll_24s97124616x701649523_clo;
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1874300823x1153072813(V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eplaceMade_24s1874300823x1153072813_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eplaceMade_24s1874300823x1153072813_clo;
V g_heff_2ebuild_2ecommands_2eprintDefs_24s1027896891x952770906(V, V);
V g_heff_2ebuild_2ecommands_2eprintDefs_24s1027896891x952770906_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprintDefs_24s1027896891x952770906_clo;
V g_heff_2ebuild_2ecommands_2eprintErrs_24s1245252666x1045981980(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eprintErrs_24s1245252666x1045981980_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprintErrs_24s1245252666x1045981980_clo;
V g_heff_2ebuild_2ecommands_2eprintLines_24s1721756835x860488624(V, V, V);
V g_heff_2ebuild_2ecommands_2eprintLines_24s1721756835x860488624_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprintLines_24s1721756835x860488624_clo;
HeffT2 g_heff_2ebuild_2ecommands_2eprogramAdded_24cpr(V, V);
V g_heff_2ebuild_2ecommands_2epublishChecked_24s2081489637x2129619610(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2epublishChecked_24s2081489637x2129619610_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2epublishChecked_24s2081489637x2129619610_clo;
V g_heff_2ebuild_2ecommands_2epublishCmd_24s850069330x784937902(V);
V g_heff_2ebuild_2ecommands_2epublishCmd_24s850069330x784937902_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2epublishCmd_24s850069330x784937902_clo;
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s1001351446x35627320(V, V, V);
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s1001351446x35627320_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eputFileDiags_24s1001351446x35627320_clo;
V g_heff_2ebuild_2ecommands_2ereadProviderC_24s859091714x1044898637(V, V);
V g_heff_2ebuild_2ecommands_2ereadProviderC_24s859091714x1044898637_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ereadProviderC_24s859091714x1044898637_clo;
V g_heff_2ebuild_2ecommands_2ereadProvidersC_24s271839773x1296157040(V, V);
V g_heff_2ebuild_2ecommands_2ereadProvidersC_24s271839773x1296157040_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ereadProvidersC_24s271839773x1296157040_clo;
V g_heff_2ebuild_2ecommands_2ereportReady_24s352125668x226880925(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ereportReady_24s352125668x226880925_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ereportReady_24s352125668x226880925_clo;
V g_heff_2ebuild_2ecommands_2erunJobs_24s432780367x1673496710(V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2erunJobs_24s432780367x1673496710_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2erunJobs_24s432780367x1673496710_clo;
V g_heff_2ebuild_2ecommands_2erunReady_24s1917816683x422720027(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2erunReady_24s1917816683x422720027_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2erunReady_24s1917816683x422720027_clo;
HeffT2 g_heff_2ebuild_2ecommands_2especOf_24cpr(V);
V g_heff_2ebuild_2ecommands_2etestDir(V, V);
V g_heff_2ebuild_2ecommands_2etestDir_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2etestDir_clo;
V g_heff_2ebuild_2ecommands_2etestReport_24s1197250805x667886372(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2etestReport_24s1197250805x667886372_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2etestReport_24s1197250805x667886372_clo;
V g_heff_2ebuild_2ecommands_2ewithGoldens_24s1156604030x1965065690(V, V, V);
V g_heff_2ebuild_2ecommands_2ewithGoldens_24s1156604030x1965065690_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ewithGoldens_24s1156604030x1965065690_clo;
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s345929733x1659071665(V, V, V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s345929733x1659071665_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s345929733x1659071665_clo;
V g_heff_2ebuild_2ecommands_2ezigOf(V);
V g_heff_2ebuild_2ecommands_2ezigOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ezigOf_clo;
V g_heff_2ebuild_2edriver_2edefKind(V, V);
V g_heff_2ebuild_2edriver_2edefKind_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2edefKind_clo;
HeffT2 g_heff_2ebuild_2edriver_2elastChecked_24cpr(V);
V g_heff_2ebuild_2eload_2ecachedDir(V, V, V);
V g_heff_2ebuild_2eload_2ecachedDir_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2ecachedDir_clo;
V g_heff_2ebuild_2eload_2eownDir_24s1338691877x240810656(V, V, V, V);
V g_heff_2ebuild_2eload_2eownDir_24s1338691877x240810656_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eownDir_24s1338691877x240810656_clo;
HeffT2 g_heff_2ebuild_2eproject_2emajorMismatch_24cpr(V, V);
HeffT2 g_heff_2ebuild_2eproject_2eversion_24cpr(V);
V g_heff_2ebuild_2eproject_2ewithPackage(V, V);
V g_heff_2ebuild_2eproject_2ewithPackage_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2ewithPackage_clo;
V g_heff_2ebuild_2esession_2ecachedAcc_24s52573320x1968432593(V);
V g_heff_2ebuild_2esession_2ecachedAcc_24s52573320x1968432593_entry(V self, V *a);
extern Clo g_heff_2ebuild_2esession_2ecachedAcc_24s52573320x1968432593_clo;
V g_heff_2ecompile_2eemit_2ecompileJs(V, V);
V g_heff_2ecompile_2eemit_2ecompileJs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ecompileJs_clo;
V g_heff_2eelab_2etoplevel_2ebodyDump(V, V);
V g_heff_2eelab_2etoplevel_2ebodyDump_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2ebodyDump_clo;
V g_heff_2eelab_2etoplevel_2etyDump(V, V);
V g_heff_2eelab_2etoplevel_2etyDump_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etyDump_clo;
V g_heff_2elsp_2erender_2ediagWhere(V, V, V);
V g_heff_2elsp_2erender_2ediagWhere_entry(V self, V *a);
extern Clo g_heff_2elsp_2erender_2ediagWhere_clo;
V g_heff_2elsp_2erender_2eprtCode(V);
V g_heff_2elsp_2erender_2eprtCode_entry(V self, V *a);
extern Clo g_heff_2elsp_2erender_2eprtCode_clo;
HeffT2 g_heff_2esyntax_2eformat_2eformat_24cpr(V);
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2eany_24s1875112453x1656618700(V, V);
V g_list_2eany_24s1875112453x1656618700_entry(V self, V *a);
extern Clo g_list_2eany_24s1875112453x1656618700_clo;
V g_list_2eany_24s332527547x6651279(V, V);
V g_list_2eany_24s332527547x6651279_entry(V self, V *a);
extern Clo g_list_2eany_24s332527547x6651279_clo;
V g_list_2eany_24s469495312x865582084(V);
V g_list_2eany_24s469495312x865582084_entry(V self, V *a);
extern Clo g_list_2eany_24s469495312x865582084_clo;
V g_list_2efilter_24s1064353769x1815078842(V);
V g_list_2efilter_24s1064353769x1815078842_entry(V self, V *a);
extern Clo g_list_2efilter_24s1064353769x1815078842_clo;
HeffT2 g_list_2efind_24s1601574865x737866729_24cpr(V, V);
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s192900907x155689445(V, V, V);
V g_list_2efoldl_24s192900907x155689445_entry(V self, V *a);
extern Clo g_list_2efoldl_24s192900907x155689445_clo;
V g_list_2emap_24s1007499915x73800978(V);
V g_list_2emap_24s1007499915x73800978_entry(V self, V *a);
extern Clo g_list_2emap_24s1007499915x73800978_clo;
V g_list_2emap_24s1234524601x742515152(V);
V g_list_2emap_24s1234524601x742515152_entry(V self, V *a);
extern Clo g_list_2emap_24s1234524601x742515152_clo;
V g_list_2emap_24s1814289659x520383890(V, V, V);
V g_list_2emap_24s1814289659x520383890_entry(V self, V *a);
extern Clo g_list_2emap_24s1814289659x520383890_clo;
V g_list_2emap_24s2015709068x2065046486(V, V, V, V, V, V, V);
V g_list_2emap_24s2015709068x2065046486_entry(V self, V *a);
extern Clo g_list_2emap_24s2015709068x2065046486_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2esplitFrom(V, V, V, V, V);
V g_prelude_2esplitFrom_entry(V self, V *a);
extern Clo g_prelude_2esplitFrom_clo;
HeffT2 g_regex_2eallRead_24cpr(V);
V g_regex_2esplitGo(V, V, V, V, V, V);
V g_regex_2esplitGo_entry(V self, V *a);
extern Clo g_regex_2esplitGo_clo;
V g_std_2epath_2ejoin(V, V, V);
V g_std_2epath_2ejoin_entry(V self, V *a);
extern Clo g_std_2epath_2ejoin_clo;
V g_std_2eprogress_2eroot_get(void);
HEFF_LIT(g_heff_2ebuild_2ecommands_2efirstErrorOf_24cpr_str0, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efirstErrorOf_24cpr_str1, 2, ": ");

HeffT2 g_heff_2ebuild_2ecommands_2efirstErrorOf_24cpr(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_c_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 3ULL, 2);
    V v_x2_243 = (g_list_2efilter_24s1064353769x1815078842(heff_take_field(v_c_241, 6)));
    switch (heff_tag_of(v_x2_243)) {
    case TAG_Nil: {
      heff_drop_rec(v_c_241, 14);
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Cons: {
      V v_d_244 = heff_field(v_x2_243, 0);
      heff_take_n(v_x2_243, 1ULL, 2);
      heff_drop(v_rest_242);
      V v_t_246 = ({ V a_0 = heff_take_field(v_c_241, 1); V b_1 = heff_get_n(v_c_241, 3, 14); V a_2 = heff_dup(v_d_244); V r_ = (g_heff_2elsp_2erender_2ediagWhere(a_0, b_1, a_2)); heff_drop(b_1); r_; });
      V v_t_247 = (g_heff_2elsp_2erender_2eprtCode(heff_dup(v_d_244)));
      V v_t_248 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efirstErrorOf_24cpr_str0), heff_get_n(v_d_244, 2, 5));
      V v_t_249 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efirstErrorOf_24cpr_str1), heff_strAppend(v_t_247, v_t_248));
      V v_why_2410 = heff_strAppend(v_t_246, v_t_249);
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_why_2410}});
    }
    default: return ((HeffT2){{heff_nomatch(v_x2_243)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
Clo g_heff_2ebuild_2ecommands_2egoldenByte_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2egoldenByte_entry, 1, 0};

V g_heff_2ebuild_2ecommands_2egoldenByte(V v_box_24c_240) {
  int64_t v_c_240 = heff_unbox_word(v_box_24c_240);
top: ;
  V v_t_242 = heff_bool(((((int64_t)48ULL) <= v_c_240) && (v_c_240 <= ((int64_t)57ULL))));
  V v_ret_24bool = heff_bool(((heff_dup(v_t_242) == NTAG(TAG_True)) || ((((int64_t)65ULL) <= v_c_240) ? ((v_c_240 <= ((int64_t)90ULL)) || ((((int64_t)97ULL) <= v_c_240) ? ((v_c_240 <= ((int64_t)122ULL)) || ((v_c_240 == ((int64_t)45ULL)) || ((v_c_240 == ((int64_t)95ULL)) || (v_c_240 == ((int64_t)46ULL))))) : ((v_c_240 == ((int64_t)45ULL)) || ((v_c_240 == ((int64_t)95ULL)) || (v_c_240 == ((int64_t)46ULL)))))) : ((((int64_t)97ULL) <= v_c_240) ? (heff_intLe_c(heff_box_word(v_c_240), MK_INT(122LL)) || (heff_intEq_c(heff_box_word(v_c_240), MK_INT(45LL)) || (heff_intEq_c(heff_box_word(v_c_240), MK_INT(95LL)) || heff_intEq_c(heff_box_word(v_c_240), MK_INT(46LL))))) : ((v_c_240 == ((int64_t)45ULL)) || ((v_c_240 == ((int64_t)95ULL)) || (v_c_240 == ((int64_t)46ULL))))))));
  heff_drop(v_t_242);
  return v_ret_24bool;
}
V g_heff_2ebuild_2ecommands_2egoldenByte_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2egoldenByte(a[0]);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2especOf_24cpr_str0, 1, "@");
HEFF_LIT(g_heff_2ebuild_2ecommands_2especOf_24cpr_str1, 1, "@");

HeffT2 g_heff_2ebuild_2ecommands_2especOf_24cpr(V v_spec_240) {
top: ;
  V v_it_241 = ({ V b_0 = ((V)&g_heff_2ebuild_2ecommands_2especOf_24cpr_str0); V a_1 = v_spec_240; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2ecommands_2especOf_24cpr_str1), v_spec_240, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
  switch (heff_tag_of(v_it_241)) {
  case TAG_Nil: {
    return ((HeffT2){{v_spec_240, NTAG(TAG_Nothing)}});
  }
  case TAG_Cons: {
    V v_path_242 = heff_field(v_it_241, 0);
    V v_it2_243 = heff_field(v_it_241, 1);
    heff_take_n(v_it_241, 3ULL, 2);
    switch (heff_tag_of(v_it2_243)) {
    case TAG_Nil: {
      heff_drop(v_path_242);
      return ((HeffT2){{v_spec_240, NTAG(TAG_Nothing)}});
    }
    case TAG_Cons: {
      V v_v_244 = heff_field(v_it2_243, 0);
      V v_it22_245 = heff_field(v_it2_243, 1);
      heff_take_n(v_it2_243, 3ULL, 2);
      switch (heff_tag_of(v_it22_245)) {
      case TAG_Nil: {
        heff_drop(v_spec_240);
        return ((HeffT2){{v_path_242, heff_tag_n(TAG_Just, 1, (V[]){v_v_244})}});
      }
      case TAG_Cons: {
        heff_take_n(v_it22_245, 0ULL, 2);
        heff_drop(v_path_242);
        heff_drop(v_v_244);
        return ((HeffT2){{v_spec_240, NTAG(TAG_Nothing)}});
      }
      default: return ((HeffT2){{heff_nomatch(v_it22_245)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_it2_243)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_it_241)}});
  }
}
V g_heff_2ebuild_2ecommands_2ereadProvidersC_24s271839773x1296157040_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ereadProvidersC_24s271839773x1296157040_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ereadProvidersC_24s271839773x1296157040_lam0, 2, 0};
V g_heff_2ebuild_2ecommands_2ereadProvidersC_24s271839773x1296157040_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ereadProvidersC_24s271839773x1296157040_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ereadProvidersC_24s271839773x1296157040_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ereadProvidersC_24s271839773x1296157040_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ereadProvidersC_24s271839773x1296157040_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2ereadProvidersC_24s271839773x1296157040(V v_sources_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_sources_240);
    return ((V)&g_heff_2ebuild_2ecommands_2ereadProvidersC_24s271839773x1296157040_lam0_clo);
  }
  case TAG_Cons: {
    V v_m_244 = heff_field(v_x2_241, 0);
    V v_rest_245 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_c_246 = (g_heff_2ebuild_2ecommands_2ereadProviderC_24s859091714x1044898637(heff_dup(v_sources_240), v_m_244));
    return heff_clo_n(g_heff_2ebuild_2ecommands_2ereadProvidersC_24s271839773x1296157040_lam1, 2, 3, (V[]){v_c_246, v_sources_240, v_rest_245});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2ecommands_2ereadProvidersC_24s271839773x1296157040_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ereadProvidersC_24s271839773x1296157040(a[0], a[1]);
}
V g_heff_2ebuild_2ecommands_2ereadProvidersC_24s271839773x1296157040_lam0(V self, V *args) {
  V v_hd_242 = args[0];
  V v_k_243 = args[1];
  heff_drop(v_hd_242);
  V f_ = v_k_243;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ereadProvidersC_24s271839773x1296157040_lam3(V self, V *args) {
  V v_x_2411 = args[0];
  V v_x_249 = heff_env(self)[0];
  V v_k_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2413;
  switch (heff_tag_of(v_x_249)) {
  case TAG_Nothing: {
    v_t_2413 = v_x_2411;
    break;
  }
  case TAG_Just: {
    V v_pr_2412 = heff_field(v_x_249, 0);
    heff_take_n(v_x_249, 1ULL, 1);
    v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){v_pr_2412, v_x_2411});
    break;
  }
  default: heff_nomatch(v_x_249);
  }
  V f_ = v_k_248;
  args[0] = v_t_2413;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ereadProvidersC_24s271839773x1296157040_lam2(V self, V *args) {
  V v_x_249 = args[0];
  V v_sources_240 = heff_env(self)[0];
  V v_rest_245 = heff_env(self)[1];
  V v_hd_247 = heff_env(self)[2];
  V v_k_248 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_c_2410 = (g_heff_2ebuild_2ecommands_2ereadProvidersC_24s271839773x1296157040(v_sources_240, v_rest_245));
  V f_ = v_c_2410;
  heff_room[0] = v_hd_247;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ereadProvidersC_24s271839773x1296157040_lam3, 1, 2, (V[]){v_x_249, v_k_248});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ereadProvidersC_24s271839773x1296157040_lam1(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_c_246 = heff_env(self)[0];
  V v_sources_240 = heff_env(self)[1];
  V v_rest_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_246;
  args[0] = heff_dup(v_hd_247);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ereadProvidersC_24s271839773x1296157040_lam2, 1, 4, (V[]){v_sources_240, v_rest_245, v_hd_247, v_k_248});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2erunReady_24s1917816683x422720027_str0, 17, "integration tests");
HEFF_LIT(g_heff_2ebuild_2ecommands_2erunReady_24s1917816683x422720027_str1, 0, "");
V g_heff_2ebuild_2ecommands_2erunReady_24s1917816683x422720027_lam0(V self, V *args);
V g_heff_2ebuild_2ecommands_2erunReady_24s1917816683x422720027_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2erunReady_24s1917816683x422720027_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2erunReady_24s1917816683x422720027_lam1, 1, 0};
V g_heff_2ebuild_2ecommands_2erunReady_24s1917816683x422720027_lam4(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2erunReady_24s1917816683x422720027_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2erunReady_24s1917816683x422720027_lam4, 1, 0};
V g_heff_2ebuild_2ecommands_2erunReady_24s1917816683x422720027_lam8(V self, V *args);
V g_heff_2ebuild_2ecommands_2erunReady_24s1917816683x422720027_lam7(V self, V *args);
V g_heff_2ebuild_2ecommands_2erunReady_24s1917816683x422720027_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2erunReady_24s1917816683x422720027_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2erunReady_24s1917816683x422720027_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2erunReady_24s1917816683x422720027_lam2(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2erunReady_24s1917816683x422720027_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2erunReady_24s1917816683x422720027_entry, 5, 0};

V g_heff_2ebuild_2ecommands_2erunReady_24s1917816683x422720027(V v_prog_240, V v_rx_241, V v_opts_242, V v_ready_243, V v_acc_244) {
top: ;
  switch (heff_tag_of(v_ready_243)) {
  case TAG_Nil: {
    heff_drop(v_prog_240);
    heff_drop(v_rx_241);
    heff_drop_rec(v_opts_242, 4);
    return heff_clo_n(g_heff_2ebuild_2ecommands_2erunReady_24s1917816683x422720027_lam0, 2, 1, (V[]){v_acc_244});
  }
  case TAG_Cons: {
    V v_t_2410 = heff_tr(heff_call(heff_dup(v_prog_240), 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){heff_dup(g_std_2eprogress_2eroot_get()), ((V)&g_heff_2ebuild_2ecommands_2erunReady_24s1917816683x422720027_str0), MK_INT(0LL), ((V)&g_heff_2ebuild_2ecommands_2erunReady_24s1917816683x422720027_lam1_clo)})}));
    return heff_clo_n(g_heff_2ebuild_2ecommands_2erunReady_24s1917816683x422720027_lam2, 2, 6, (V[]){v_t_2410, v_rx_241, v_opts_242, v_ready_243, v_prog_240, v_acc_244});
  }
  default: return heff_nomatch(v_ready_243);
  }
}
V g_heff_2ebuild_2ecommands_2erunReady_24s1917816683x422720027_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2erunReady_24s1917816683x422720027(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ebuild_2ecommands_2erunReady_24s1917816683x422720027_lam0(V self, V *args) {
  V v_hd_245 = args[0];
  V v_k_246 = args[1];
  V v_acc_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_245);
  V f_ = v_k_246;
  args[0] = v_acc_244;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2erunReady_24s1917816683x422720027_lam1(V self, V *args) {
  V v_t_249 = args[0];
  return v_t_249;
}
V g_heff_2ebuild_2ecommands_2erunReady_24s1917816683x422720027_lam4(V self, V *args) {
  V v_i_2414 = args[0];
  return v_i_2414;
}
V g_heff_2ebuild_2ecommands_2erunReady_24s1917816683x422720027_lam8(V self, V *args) {
  V v_x_2437 = args[0];
  V v_opts_242 = heff_env(self)[0];
  V v_x_2431 = heff_env(self)[1];
  V v_ready_243 = heff_env(self)[2];
  V v_acc_244 = heff_env(self)[3];
  V v_hd_2411 = heff_env(self)[4];
  V v_k_2412 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_2437);
  return ({ V a_0 = v_opts_242; V a_1 = v_x_2431; V a_2 = v_ready_243; V a_3 = v_acc_244; V a_4 = v_hd_2411; V a_5 = v_k_2412; V r_ = (g_heff_2ebuild_2ecommands_2ereportReady_24s352125668x226880925(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop_tag(v_ready_243, 2); r_; });
}
V g_heff_2ebuild_2ecommands_2erunReady_24s1917816683x422720027_lam7(V self, V *args) {
  V v_x_2434 = args[0];
  V v_x_2413 = heff_env(self)[0];
  V v_prog_240 = heff_env(self)[1];
  V v_hd_2411 = heff_env(self)[2];
  V v_opts_242 = heff_env(self)[3];
  V v_x_2431 = heff_env(self)[4];
  V v_ready_243 = heff_env(self)[5];
  V v_acc_244 = heff_env(self)[6];
  V v_k_2412 = heff_env(self)[7];
  heff_clo_take(self, 8);
  heff_drop(v_x_2434);
  V v_t_2435 = heff_tag_n(TAG_End, 2, (V[]){v_x_2413, NTAG(TAG_MkUnit)});
  V v_t_2436 = heff_tr(heff_call(v_prog_240, 1, (V[]){v_t_2435}));
  return (g_co_2eop_24s94900133x232571340(v_t_2436, heff_dup(v_hd_2411), heff_clo_n(g_heff_2ebuild_2ecommands_2erunReady_24s1917816683x422720027_lam8, 1, 6, (V[]){v_opts_242, v_x_2431, v_ready_243, v_acc_244, v_hd_2411, v_k_2412})));
}
V g_heff_2ebuild_2ecommands_2erunReady_24s1917816683x422720027_lam6(V self, V *args) {
  V v_x_2431 = args[0];
  V v_x_2416 = heff_env(self)[0];
  V v_rx_241 = heff_env(self)[1];
  V v_hd_2411 = heff_env(self)[2];
  V v_x_2413 = heff_env(self)[3];
  V v_prog_240 = heff_env(self)[4];
  V v_opts_242 = heff_env(self)[5];
  V v_ready_243 = heff_env(self)[6];
  V v_acc_244 = heff_env(self)[7];
  V v_k_2412 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_t_2432 = heff_tag_n(TAG_Close, 2, (V[]){v_x_2416, NTAG(TAG_MkUnit)});
  V v_t_2433 = heff_tr(heff_call(v_rx_241, 1, (V[]){v_t_2432}));
  return (g_co_2eop_24s94900133x232571340(v_t_2433, heff_dup(v_hd_2411), heff_clo_n(g_heff_2ebuild_2ecommands_2erunReady_24s1917816683x422720027_lam7, 1, 8, (V[]){v_x_2413, v_prog_240, v_hd_2411, v_opts_242, v_x_2431, v_ready_243, v_acc_244, v_k_2412})));
}
V g_heff_2ebuild_2ecommands_2erunReady_24s1917816683x422720027_lam5(V self, V *args) {
  V v_x_2416 = args[0];
  V v_opts_242 = heff_env(self)[0];
  V v_ready_243 = heff_env(self)[1];
  V v_rx_241 = heff_env(self)[2];
  V v_hd_2411 = heff_env(self)[3];
  V v_x_2413 = heff_env(self)[4];
  V v_prog_240 = heff_env(self)[5];
  V v_acc_244 = heff_env(self)[6];
  V v_k_2412 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_p_2417 = heff_dup(heff_rfield(v_opts_242, 1));
  V v_t_2427;
  if (heff_strEq_c_lent(v_p_2417, ((V)&g_heff_2ebuild_2ecommands_2erunReady_24s1917816683x422720027_str1), 2)) {
    heff_drop(v_p_2417);
    v_t_2427 = NTAG(TAG_Nil);
  } else {
    V v_t_2419 = ({ V a_0 = MK_INT(47LL); V a_1 = v_p_2417; V a_2 = MK_INT(0LL); V a_3 = MK_INT(0LL); V a_4 = NTAG(TAG_False); V a_5 = NTAG(TAG_Nil); V r_ = (g_regex_2esplitGo(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_p_2417); r_; });
    V v_t_2420 = (g_list_2emap_24s1007499915x73800978(v_t_2419));
    HeffT2 v_t_2421 = (g_regex_2eallRead_24cpr(v_t_2420));
    {
      V v_field_2423 = v_t_2421.f[1];
      int64_t v_tag_2422 = ((int64_t)v_t_2421.f[0]);
      if ((v_tag_2422 == ((int64_t)0ULL))) {
        V v_why_2425 = v_field_2423;
        heff_drop(v_why_2425);
        v_t_2427 = NTAG(TAG_Nil);
      } else {
        V v_sel_2426 = v_field_2423;
        v_t_2427 = v_sel_2426;
      }
    }
  }
  V v_t_2428 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_ready_243)));
  V v_t_2429 = ({ V a_0 = MK_INT(0LL); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_2428; V r_ = (g_list_2efoldl_24s192900907x155689445(a_0, a_1, a_2)); heff_drop(v_t_2428); r_; });
  V v_c_2430 = (g_heff_2ebuild_2ecommands_2erunJobs_24s432780367x1673496710(heff_dup(v_rx_241), v_t_2427, heff_dup(heff_rfield(v_opts_242, 2)), heff_tag_n(TAG_MkGroup, 1, (V[]){heff_dup(v_x_2416)}), v_t_2429, MK_INT(0LL), NTAG(TAG_Nil)));
  V f_ = v_c_2430;
  heff_room[0] = heff_dup(v_hd_2411);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2erunReady_24s1917816683x422720027_lam6, 1, 9, (V[]){v_x_2416, v_rx_241, v_hd_2411, v_x_2413, v_prog_240, v_opts_242, v_ready_243, v_acc_244, v_k_2412});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2erunReady_24s1917816683x422720027_lam3(V self, V *args) {
  V v_x_2413 = args[0];
  V v_rx_241 = heff_env(self)[0];
  V v_hd_2411 = heff_env(self)[1];
  V v_opts_242 = heff_env(self)[2];
  V v_ready_243 = heff_env(self)[3];
  V v_prog_240 = heff_env(self)[4];
  V v_acc_244 = heff_env(self)[5];
  V v_k_2412 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2415 = heff_tr(heff_call(heff_dup(v_rx_241), 1, (V[]){heff_tag_n(TAG_Open, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2erunReady_24s1917816683x422720027_lam4_clo)})}));
  return (g_co_2eop_24s94900133x232571340(v_t_2415, heff_dup(v_hd_2411), heff_clo_n(g_heff_2ebuild_2ecommands_2erunReady_24s1917816683x422720027_lam5, 1, 8, (V[]){v_opts_242, v_ready_243, v_rx_241, v_hd_2411, v_x_2413, v_prog_240, v_acc_244, v_k_2412})));
}
V g_heff_2ebuild_2ecommands_2erunReady_24s1917816683x422720027_lam2(V self, V *args) {
  V v_hd_2411 = args[0];
  V v_k_2412 = args[1];
  V v_t_2410 = heff_env(self)[0];
  V v_rx_241 = heff_env(self)[1];
  V v_opts_242 = heff_env(self)[2];
  V v_ready_243 = heff_env(self)[3];
  V v_prog_240 = heff_env(self)[4];
  V v_acc_244 = heff_env(self)[5];
  heff_clo_take(self, 6);
  return (g_co_2eop_24s94900133x232571340(v_t_2410, heff_dup(v_hd_2411), heff_clo_n(g_heff_2ebuild_2ecommands_2erunReady_24s1917816683x422720027_lam3, 1, 7, (V[]){v_rx_241, v_hd_2411, v_opts_242, v_ready_243, v_prog_240, v_acc_244, v_k_2412})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1567142318x1862190202_str0, 32, "its program could not be built: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1567142318x1862190202_str1, 19, ": integration tests");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1567142318x1862190202_str2, 14, "compiling to C");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1567142318x1862190202_str3, 4, "main");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1567142318x1862190202_str4, 8, "main.exe");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1567142318x1862190202_str5, 4, "main");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1567142318x1862190202_str6, 8, "main.exe");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1567142318x1862190202_str7, 32, "its program could not be built: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1567142318x1862190202_str8, 1, "/");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1567142318x1862190202_str9, 3, "-O1");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1567142318x1862190202_str10, 32, "its program could not be built: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1567142318x1862190202_str11, 9, "heff test");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1567142318x1862190202_str12, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1567142318x1862190202_str13, 14, "HEFF_TEST_JOBS");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1567142318x1862190202_str14, 1, "1");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1567142318x1862190202_str15, 14, "HEFF_TEST_ROOT");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1567142318x1862190202_str16, 4, "HEFF");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1567142318x1862190202_str17, 32, "its program could not be built: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1567142318x1862190202_str18, 34, "its file is not among those loaded");
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1567142318x1862190202_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1567142318x1862190202_lam0(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1567142318x1862190202_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1567142318x1862190202_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1567142318x1862190202_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1567142318x1862190202_lam4(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1567142318x1862190202_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1567142318x1862190202_lam4, 1, 0};
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1567142318x1862190202_lam10(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1567142318x1862190202_lam9(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1567142318x1862190202_lam8(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1567142318x1862190202_lam7(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1567142318x1862190202_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1567142318x1862190202_lam16(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1567142318x1862190202_lam15(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1567142318x1862190202_lam14(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1567142318x1862190202_lam13(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1567142318x1862190202_lam18(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1567142318x1862190202_lam18_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1567142318x1862190202_lam18, 1, 0};
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1567142318x1862190202_lam20(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1567142318x1862190202_lam20_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1567142318x1862190202_lam20, 1, 0};
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1567142318x1862190202_lam22(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1567142318x1862190202_lam22_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1567142318x1862190202_lam22, 1, 0};
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1567142318x1862190202_lam24(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1567142318x1862190202_lam24_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1567142318x1862190202_lam24, 1, 0};
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1567142318x1862190202_lam26(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1567142318x1862190202_lam25(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1567142318x1862190202_lam23(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1567142318x1862190202_lam21(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1567142318x1862190202_lam19(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1567142318x1862190202_lam17(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1567142318x1862190202_lam12(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1567142318x1862190202_lam11(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1567142318x1862190202_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1567142318x1862190202_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1567142318x1862190202_lam28(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1567142318x1862190202_lam27(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1567142318x1862190202_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1567142318x1862190202_entry, 7, 0};

V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1567142318x1862190202(V v_prog_240, V v_opts_241, V v_at_242, V v_p_243, V v_k_244, V v_z_245, V v_z_246) {
top: ;
  V v_t_247 = heff_get_n(heff_dup(heff_rfield(v_p_243, 5)), 0, 5);
  HeffT2 v_t_248 = (g_list_2efind_24s1601574865x737866729_24cpr(heff_dup(v_p_243), v_t_247));
  {
    V v_field_2410 = v_t_248.f[1];
    int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
    if ((v_tag_249 == ((int64_t)0ULL))) {
      V v_src_2412 = v_field_2410;
      HeffT2 v_t_2413 = (g_heff_2ebuild_2ecommands_2eprogramAdded_24cpr(heff_dup(v_p_243), v_src_2412));
      {
        V v_field_2415 = v_t_2413.f[1];
        int64_t v_tag_2414 = ((int64_t)v_t_2413.f[0]);
        if ((v_tag_2414 == ((int64_t)0ULL))) {
          heff_drop(v_prog_240);
          heff_drop(v_at_242);
          V v_why_2417 = v_field_2415;
          V v_more_2418 = (g_list_2emap_24s2015709068x2065046486(MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1567142318x1862190202_str0), v_why_2417, MK_INT(0LL), heff_dup(heff_rfield(v_p_243, 4))));
          V v_t_2419 = (g_prelude_2e_2b_2b(heff_dup(heff_rfield(v_p_243, 3)), v_more_2418));
          V v_c_2420 = (g_heff_2ebuild_2ecommands_2ewithGoldens_24s1156604030x1965065690(heff_rfield(v_opts_241, 3), heff_dup(heff_rfield(v_p_243, 0)), v_t_2419));
          return heff_tail(v_c_2420, 2, (V[]){heff_dup(v_z_245), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1567142318x1862190202_lam0, 1, 5, (V[]){v_opts_241, v_k_244, v_z_245, v_z_246, v_p_243})});
        } else {
          V v_l_2424 = v_field_2415;
          V v_t_2425 = heff_strAppend(heff_dup(heff_rfield(v_p_243, 0)), ((V)&g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1567142318x1862190202_str1));
          V v_t_2427 = heff_tr(heff_call(heff_dup(v_prog_240), 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){heff_dup(g_std_2eprogress_2eroot_get()), v_t_2425, MK_INT(2LL), ((V)&g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1567142318x1862190202_lam2_clo)})}));
          return (g_co_2eop_24s94900133x232571340(v_t_2427, heff_dup(v_z_245), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1567142318x1862190202_lam3, 1, 8, (V[]){v_prog_240, v_z_245, v_l_2424, v_p_243, v_opts_241, v_k_244, v_at_242, v_z_246})));
        }
      }
    } else {
      heff_drop(v_prog_240);
      heff_drop(v_at_242);
      heff_drop(v_field_2410);
      V v_more_24126 = (g_list_2emap_24s2015709068x2065046486(MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1567142318x1862190202_str17), ((V)&g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1567142318x1862190202_str18), MK_INT(0LL), heff_dup(heff_rfield(v_p_243, 4))));
      V v_t_24127 = (g_prelude_2e_2b_2b(heff_dup(heff_rfield(v_p_243, 3)), v_more_24126));
      V v_c_24128 = (g_heff_2ebuild_2ecommands_2ewithGoldens_24s1156604030x1965065690(heff_rfield(v_opts_241, 3), heff_dup(heff_rfield(v_p_243, 0)), v_t_24127));
      return heff_tail(v_c_24128, 2, (V[]){heff_dup(v_z_245), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1567142318x1862190202_lam27, 1, 5, (V[]){v_opts_241, v_k_244, v_z_245, v_z_246, v_p_243})});
    }
  }
}
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1567142318x1862190202_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1567142318x1862190202(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1567142318x1862190202_lam1(V self, V *args) {
  V v_x_2423 = args[0];
  V v_k_244 = heff_env(self)[0];
  V v_z_245 = heff_env(self)[1];
  V v_z_246 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_k_244;
  heff_room[0] = heff_tag_n(TAG_Done, 1, (V[]){v_x_2423});
  heff_room[1] = v_z_245;
  heff_room[2] = v_z_246;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1567142318x1862190202_lam0(V self, V *args) {
  V v_x_2421 = args[0];
  V v_opts_241 = heff_env(self)[0];
  V v_k_244 = heff_env(self)[1];
  V v_z_245 = heff_env(self)[2];
  V v_z_246 = heff_env(self)[3];
  V v_p_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2422 = (g_heff_2ebuild_2ecommands_2epassedOver(v_opts_241, heff_dup(v_x_2421)));
  if ((heff_dup(v_t_2422) == NTAG(TAG_True))) {
    heff_drop(v_x_2421);
    heff_drop_rec(v_p_243, 7);
    heff_drop(v_t_2422);
    V f_ = v_k_244;
    heff_room[0] = heff_tag_n(TAG_Done, 1, (V[]){heff_dup(g_heff_2ebuild_2ecommands_2enoRes_get())});
    heff_room[1] = v_z_245;
    heff_room[2] = v_z_246;
    if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
  } else {
    heff_drop(v_t_2422);
    return (g_heff_2ebuild_2ecommands_2etestReport_24s1197250805x667886372(heff_dup(heff_rfield(v_p_243, 0)), heff_dup(heff_rfield(v_p_243, 1)), heff_get_n(v_p_243, 2, 7), v_x_2421, heff_dup(v_z_245), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1567142318x1862190202_lam1, 1, 3, (V[]){v_k_244, v_z_245, v_z_246})));
  }
}
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1567142318x1862190202_lam2(V self, V *args) {
  V v_t_2426 = args[0];
  return v_t_2426;
}
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1567142318x1862190202_lam4(V self, V *args) {
  V v_t_2429 = args[0];
  return v_t_2429;
}
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1567142318x1862190202_lam10(V self, V *args) {
  V v_x_2460 = args[0];
  V v_k_244 = heff_env(self)[0];
  V v_z_2447 = heff_env(self)[1];
  V v_z_2448 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_k_244;
  heff_room[0] = heff_tag_n(TAG_Done, 1, (V[]){v_x_2460});
  heff_room[1] = v_z_2447;
  heff_room[2] = v_z_2448;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1567142318x1862190202_lam9(V self, V *args) {
  V v_x_2458 = args[0];
  V v_opts_241 = heff_env(self)[0];
  V v_k_244 = heff_env(self)[1];
  V v_z_2447 = heff_env(self)[2];
  V v_z_2448 = heff_env(self)[3];
  V v_p_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2459 = (g_heff_2ebuild_2ecommands_2epassedOver(v_opts_241, heff_dup(v_x_2458)));
  if ((heff_dup(v_t_2459) == NTAG(TAG_True))) {
    heff_drop(v_x_2458);
    heff_drop_rec(v_p_243, 7);
    heff_drop(v_t_2459);
    V f_ = v_k_244;
    heff_room[0] = heff_tag_n(TAG_Done, 1, (V[]){heff_dup(g_heff_2ebuild_2ecommands_2enoRes_get())});
    heff_room[1] = v_z_2447;
    heff_room[2] = v_z_2448;
    if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
  } else {
    heff_drop(v_t_2459);
    return (g_heff_2ebuild_2ecommands_2etestReport_24s1197250805x667886372(heff_dup(heff_rfield(v_p_243, 0)), heff_dup(heff_rfield(v_p_243, 1)), heff_get_n(v_p_243, 2, 7), v_x_2458, heff_dup(v_z_2447), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1567142318x1862190202_lam10, 1, 3, (V[]){v_k_244, v_z_2447, v_z_2448})));
  }
}
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1567142318x1862190202_lam8(V self, V *args) {
  V v_x_2454 = args[0];
  V v_why_2446 = heff_env(self)[0];
  V v_p_243 = heff_env(self)[1];
  V v_opts_241 = heff_env(self)[2];
  V v_z_2447 = heff_env(self)[3];
  V v_k_244 = heff_env(self)[4];
  V v_z_2448 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_2454);
  V v_more_2455 = (g_list_2emap_24s2015709068x2065046486(MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1567142318x1862190202_str7), v_why_2446, MK_INT(0LL), heff_dup(heff_rfield(v_p_243, 4))));
  V v_t_2456 = (g_prelude_2e_2b_2b(heff_dup(heff_rfield(v_p_243, 3)), v_more_2455));
  V v_c_2457 = (g_heff_2ebuild_2ecommands_2ewithGoldens_24s1156604030x1965065690(heff_rfield(v_opts_241, 3), heff_dup(heff_rfield(v_p_243, 0)), v_t_2456));
  V f_ = v_c_2457;
  heff_room[0] = heff_dup(v_z_2447);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1567142318x1862190202_lam9, 1, 5, (V[]){v_opts_241, v_k_244, v_z_2447, v_z_2448, v_p_243});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1567142318x1862190202_lam7(V self, V *args) {
  V v_x_2451 = args[0];
  V v_x_2428 = heff_env(self)[0];
  V v_prog_240 = heff_env(self)[1];
  V v_z_2447 = heff_env(self)[2];
  V v_why_2446 = heff_env(self)[3];
  V v_p_243 = heff_env(self)[4];
  V v_opts_241 = heff_env(self)[5];
  V v_k_244 = heff_env(self)[6];
  V v_z_2448 = heff_env(self)[7];
  heff_clo_take(self, 8);
  heff_drop(v_x_2451);
  V v_t_2452 = heff_tag_n(TAG_End, 2, (V[]){v_x_2428, NTAG(TAG_MkUnit)});
  V v_t_2453 = heff_tr(heff_call(v_prog_240, 1, (V[]){v_t_2452}));
  return (g_co_2eop_24s94900133x232571340(v_t_2453, heff_dup(v_z_2447), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1567142318x1862190202_lam8, 1, 6, (V[]){v_why_2446, v_p_243, v_opts_241, v_z_2447, v_k_244, v_z_2448})));
}
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1567142318x1862190202_lam6(V self, V *args) {
  V v_why_2446 = args[0];
  V v_z_2447 = args[1];
  V v_z_2448 = args[2];
  V v_x_2431 = heff_env(self)[0];
  V v_prog_240 = heff_env(self)[1];
  V v_x_2428 = heff_env(self)[2];
  V v_p_243 = heff_env(self)[3];
  V v_opts_241 = heff_env(self)[4];
  V v_k_244 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2449 = heff_tag_n(TAG_End, 2, (V[]){v_x_2431, NTAG(TAG_MkUnit)});
  V v_t_2450 = heff_tr(heff_call(heff_dup(v_prog_240), 1, (V[]){v_t_2449}));
  return (g_co_2eop_24s94900133x232571340(v_t_2450, heff_dup(v_z_2447), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1567142318x1862190202_lam7, 1, 8, (V[]){v_x_2428, v_prog_240, v_z_2447, v_why_2446, v_p_243, v_opts_241, v_k_244, v_z_2448})));
}
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1567142318x1862190202_lam16(V self, V *args) {
  V v_x_2477 = args[0];
  V v_k_244 = heff_env(self)[0];
  V v_z_2467 = heff_env(self)[1];
  V v_z_2468 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_k_244;
  heff_room[0] = heff_tag_n(TAG_Done, 1, (V[]){v_x_2477});
  heff_room[1] = v_z_2467;
  heff_room[2] = v_z_2468;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1567142318x1862190202_lam15(V self, V *args) {
  V v_x_2475 = args[0];
  V v_opts_241 = heff_env(self)[0];
  V v_k_244 = heff_env(self)[1];
  V v_z_2467 = heff_env(self)[2];
  V v_z_2468 = heff_env(self)[3];
  V v_p_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2476 = (g_heff_2ebuild_2ecommands_2epassedOver(v_opts_241, heff_dup(v_x_2475)));
  if ((heff_dup(v_t_2476) == NTAG(TAG_True))) {
    heff_drop(v_x_2475);
    heff_drop_rec(v_p_243, 7);
    heff_drop(v_t_2476);
    V f_ = v_k_244;
    heff_room[0] = heff_tag_n(TAG_Done, 1, (V[]){heff_dup(g_heff_2ebuild_2ecommands_2enoRes_get())});
    heff_room[1] = v_z_2467;
    heff_room[2] = v_z_2468;
    if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
  } else {
    heff_drop(v_t_2476);
    return (g_heff_2ebuild_2ecommands_2etestReport_24s1197250805x667886372(heff_dup(heff_rfield(v_p_243, 0)), heff_dup(heff_rfield(v_p_243, 1)), heff_get_n(v_p_243, 2, 7), v_x_2475, heff_dup(v_z_2467), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1567142318x1862190202_lam16, 1, 3, (V[]){v_k_244, v_z_2467, v_z_2468})));
  }
}
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1567142318x1862190202_lam14(V self, V *args) {
  V v_x_2471 = args[0];
  V v_why_2466 = heff_env(self)[0];
  V v_p_243 = heff_env(self)[1];
  V v_opts_241 = heff_env(self)[2];
  V v_z_2467 = heff_env(self)[3];
  V v_k_244 = heff_env(self)[4];
  V v_z_2468 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_2471);
  V v_more_2472 = (g_list_2emap_24s2015709068x2065046486(MK_INT(0LL), MK_INT(0LL), MK_INT(0LL), ((V)&g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1567142318x1862190202_str10), v_why_2466, MK_INT(0LL), heff_dup(heff_rfield(v_p_243, 4))));
  V v_t_2473 = (g_prelude_2e_2b_2b(heff_dup(heff_rfield(v_p_243, 3)), v_more_2472));
  V v_c_2474 = (g_heff_2ebuild_2ecommands_2ewithGoldens_24s1156604030x1965065690(heff_rfield(v_opts_241, 3), heff_dup(heff_rfield(v_p_243, 0)), v_t_2473));
  V f_ = v_c_2474;
  heff_room[0] = heff_dup(v_z_2467);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1567142318x1862190202_lam15, 1, 5, (V[]){v_opts_241, v_k_244, v_z_2467, v_z_2468, v_p_243});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1567142318x1862190202_lam13(V self, V *args) {
  V v_why_2466 = args[0];
  V v_z_2467 = args[1];
  V v_z_2468 = args[2];
  V v_x_2428 = heff_env(self)[0];
  V v_prog_240 = heff_env(self)[1];
  V v_p_243 = heff_env(self)[2];
  V v_opts_241 = heff_env(self)[3];
  V v_k_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2469 = heff_tag_n(TAG_End, 2, (V[]){v_x_2428, NTAG(TAG_MkUnit)});
  V v_t_2470 = heff_tr(heff_call(v_prog_240, 1, (V[]){v_t_2469}));
  return (g_co_2eop_24s94900133x232571340(v_t_2470, heff_dup(v_z_2467), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1567142318x1862190202_lam14, 1, 6, (V[]){v_why_2466, v_p_243, v_opts_241, v_z_2467, v_k_244, v_z_2468})));
}
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1567142318x1862190202_lam18(V self, V *args) {
  V v_r_2480 = args[0];
  return v_r_2480;
}
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1567142318x1862190202_lam20(V self, V *args) {
  V v_s_2487 = args[0];
  return v_s_2487;
}
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1567142318x1862190202_lam22(V self, V *args) {
  V v_r_2495 = args[0];
  return v_r_2495;
}
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1567142318x1862190202_lam24(V self, V *args) {
  V v_r_24103 = args[0];
  return v_r_24103;
}
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1567142318x1862190202_lam26(V self, V *args) {
  V v_x_24112 = args[0];
  V v_x_2486 = heff_env(self)[0];
  V v_x_24101 = heff_env(self)[1];
  V v_x_2494 = heff_env(self)[2];
  V v_x_24109 = heff_env(self)[3];
  V v_l_2424 = heff_env(self)[4];
  V v_at_242 = heff_env(self)[5];
  V v_p_243 = heff_env(self)[6];
  V v_k_244 = heff_env(self)[7];
  V v_hd_2478 = heff_env(self)[8];
  V v_k_2479 = heff_env(self)[9];
  heff_clo_take(self, 10);
  heff_drop(v_x_24112);
  V v_t_24115;
  switch (heff_tag_of(v_x_2486)) {
  case TAG_Left: {
    heff_take_n(v_x_2486, 0ULL, 1);
    v_t_24115 = ((V)&g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1567142318x1862190202_str12);
    break;
  }
  case TAG_Right: {
    V v_real_24114 = heff_field(v_x_2486, 0);
    heff_take_n(v_x_2486, 1ULL, 1);
    v_t_24115 = v_real_24114;
    break;
  }
  default: heff_nomatch(v_x_2486);
  }
  V v_t_24118;
  switch (heff_tag_of(v_x_24101)) {
  case TAG_Left: {
    heff_take_n(v_x_24101, 0ULL, 1);
    v_t_24118 = v_x_2494;
    break;
  }
  case TAG_Right: {
    V v_real_24117 = heff_field(v_x_24101, 0);
    heff_take_n(v_x_24101, 1ULL, 1);
    heff_drop(v_x_2494);
    v_t_24118 = v_real_24117;
    break;
  }
  default: heff_nomatch(v_x_24101);
  }
  V v_t_24121;
  switch (heff_tag_of(v_x_24109)) {
  case TAG_Left: {
    heff_take_n(v_x_24109, 0ULL, 1);
    v_t_24121 = heff_get_n(heff_get_n(v_l_2424, 2, 5), 0, 6);
    break;
  }
  case TAG_Right: {
    V v_real_24120 = heff_field(v_x_24109, 0);
    heff_take_n(v_x_24109, 1ULL, 1);
    heff_drop_rec(v_l_2424, 5);
    v_t_24121 = v_real_24120;
    break;
  }
  default: heff_nomatch(v_x_24109);
  }
  V v_t_24122 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1567142318x1862190202_str13), ((V)&g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1567142318x1862190202_str14)}), NTAG(TAG_Nil)});
  V v_t_24123 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1567142318x1862190202_str15), v_t_24121}), v_t_24122});
  V v_t_24124 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1567142318x1862190202_str16), v_t_24118}), v_t_24123});
  V v_t_24125 = heff_rec_n(3, shape_at__pending__launch, (V[]){v_at_242, v_p_243, heff_rec_n(2, shape_program__env, (V[]){v_t_24115, v_t_24124})});
  V f_ = v_k_244;
  heff_room[0] = heff_tag_n(TAG_Later, 1, (V[]){v_t_24125});
  heff_room[1] = v_hd_2478;
  heff_room[2] = v_k_2479;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1567142318x1862190202_lam25(V self, V *args) {
  V v_x_24109 = args[0];
  V v_x_2428 = heff_env(self)[0];
  V v_prog_240 = heff_env(self)[1];
  V v_hd_2478 = heff_env(self)[2];
  V v_x_2486 = heff_env(self)[3];
  V v_x_24101 = heff_env(self)[4];
  V v_x_2494 = heff_env(self)[5];
  V v_l_2424 = heff_env(self)[6];
  V v_at_242 = heff_env(self)[7];
  V v_p_243 = heff_env(self)[8];
  V v_k_244 = heff_env(self)[9];
  V v_k_2479 = heff_env(self)[10];
  heff_clo_take(self, 11);
  V v_t_24110 = heff_tag_n(TAG_End, 2, (V[]){v_x_2428, NTAG(TAG_MkUnit)});
  V v_t_24111 = heff_tr(heff_call(v_prog_240, 1, (V[]){v_t_24110}));
  return (g_co_2eop_24s94900133x232571340(v_t_24111, heff_dup(v_hd_2478), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1567142318x1862190202_lam26, 1, 10, (V[]){v_x_2486, v_x_24101, v_x_2494, v_x_24109, v_l_2424, v_at_242, v_p_243, v_k_244, v_hd_2478, v_k_2479})));
}
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1567142318x1862190202_lam23(V self, V *args) {
  V v_x_24101 = args[0];
  V v_l_2424 = heff_env(self)[0];
  V v_hd_2478 = heff_env(self)[1];
  V v_x_2428 = heff_env(self)[2];
  V v_prog_240 = heff_env(self)[3];
  V v_x_2486 = heff_env(self)[4];
  V v_x_2494 = heff_env(self)[5];
  V v_at_242 = heff_env(self)[6];
  V v_p_243 = heff_env(self)[7];
  V v_k_244 = heff_env(self)[8];
  V v_k_2479 = heff_env(self)[9];
  heff_clo_take(self, 10);
  V v_t_24102 = heff_get_n(heff_dup(heff_rfield(v_l_2424, 2)), 0, 6);
  V v_t_24104 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_RealPath, 2, (V[]){v_t_24102, ((V)&g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1567142318x1862190202_lam24_clo)})});
  V v_t_24105 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24104})});
  V v_t_24106 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24105})});
  V v_t_24107 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24106})});
  V v_t_24108 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24107})});
  return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_24108}), heff_dup(v_hd_2478), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1567142318x1862190202_lam25, 1, 11, (V[]){v_x_2428, v_prog_240, v_hd_2478, v_x_2486, v_x_24101, v_x_2494, v_l_2424, v_at_242, v_p_243, v_k_244, v_k_2479})));
}
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1567142318x1862190202_lam21(V self, V *args) {
  V v_x_2494 = args[0];
  V v_hd_2478 = heff_env(self)[0];
  V v_l_2424 = heff_env(self)[1];
  V v_x_2428 = heff_env(self)[2];
  V v_prog_240 = heff_env(self)[3];
  V v_x_2486 = heff_env(self)[4];
  V v_at_242 = heff_env(self)[5];
  V v_p_243 = heff_env(self)[6];
  V v_k_244 = heff_env(self)[7];
  V v_k_2479 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_t_2496 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_RealPath, 2, (V[]){heff_dup(v_x_2494), ((V)&g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1567142318x1862190202_lam22_clo)})});
  V v_t_2497 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2496})});
  V v_t_2498 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2497})});
  V v_t_2499 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2498})});
  V v_t_24100 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2499})});
  return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_24100}), heff_dup(v_hd_2478), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1567142318x1862190202_lam23, 1, 10, (V[]){v_l_2424, v_hd_2478, v_x_2428, v_prog_240, v_x_2486, v_x_2494, v_at_242, v_p_243, v_k_244, v_k_2479})));
}
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1567142318x1862190202_lam19(V self, V *args) {
  V v_x_2486 = args[0];
  V v_hd_2478 = heff_env(self)[0];
  V v_l_2424 = heff_env(self)[1];
  V v_x_2428 = heff_env(self)[2];
  V v_prog_240 = heff_env(self)[3];
  V v_at_242 = heff_env(self)[4];
  V v_p_243 = heff_env(self)[5];
  V v_k_244 = heff_env(self)[6];
  V v_k_2479 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2488 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ProgramPath, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1567142318x1862190202_lam20_clo)})});
  V v_t_2489 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2488})});
  V v_t_2490 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2489})});
  V v_t_2491 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2490})});
  V v_t_2492 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2491})});
  V v_t_2493 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2492})});
  return (g_co_2eop_24s94900133x232571340(v_t_2493, heff_dup(v_hd_2478), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1567142318x1862190202_lam21, 1, 9, (V[]){v_hd_2478, v_l_2424, v_x_2428, v_prog_240, v_x_2486, v_at_242, v_p_243, v_k_244, v_k_2479})));
}
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1567142318x1862190202_lam17(V self, V *args) {
  V v_hd_2478 = args[0];
  V v_k_2479 = args[1];
  V v_path_2443 = heff_env(self)[0];
  V v_l_2424 = heff_env(self)[1];
  V v_x_2428 = heff_env(self)[2];
  V v_prog_240 = heff_env(self)[3];
  V v_at_242 = heff_env(self)[4];
  V v_p_243 = heff_env(self)[5];
  V v_k_244 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2481 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_RealPath, 2, (V[]){v_path_2443, ((V)&g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1567142318x1862190202_lam18_clo)})});
  V v_t_2482 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2481})});
  V v_t_2483 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2482})});
  V v_t_2484 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2483})});
  V v_t_2485 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2484})});
  return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2485}), heff_dup(v_hd_2478), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1567142318x1862190202_lam19, 1, 8, (V[]){v_hd_2478, v_l_2424, v_x_2428, v_prog_240, v_at_242, v_p_243, v_k_244, v_k_2479})));
}
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1567142318x1862190202_lam12(V self, V *args) {
  V v_x_2463 = args[0];
  V v_l_2424 = heff_env(self)[0];
  V v_prog_240 = heff_env(self)[1];
  V v_x_2428 = heff_env(self)[2];
  V v_p_243 = heff_env(self)[3];
  V v_opts_241 = heff_env(self)[4];
  V v_k_244 = heff_env(self)[5];
  V v_dir_2433 = heff_env(self)[6];
  V v_out_2438 = heff_env(self)[7];
  V v_path_2443 = heff_env(self)[8];
  V v_at_242 = heff_env(self)[9];
  V v_hd_2461 = heff_env(self)[10];
  V v_k_2462 = heff_env(self)[11];
  heff_clo_take(self, 12);
  heff_drop(v_x_2463);
  V v_t_2464 = heff_get_n(heff_dup(heff_rfield(v_l_2424, 2)), 5, 6);
  V v_t_2465 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1567142318x1862190202_str9), NTAG(TAG_Nil)});
  return ({ V a_0 = heff_dup(v_prog_240); V a_1 = heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1567142318x1862190202_lam13, 3, 5, (V[]){heff_dup(v_x_2428), heff_dup(v_prog_240), heff_dup(v_p_243), v_opts_241, heff_dup(v_k_244)}); V a_2 = ((V)&g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1567142318x1862190202_str11); V a_3 = v_t_2464; V a_4 = v_t_2465; V a_5 = heff_dup(v_x_2428); V a_6 = v_dir_2433; V a_7 = v_out_2438; V a_8 = heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1567142318x1862190202_lam17, 2, 7, (V[]){v_path_2443, v_l_2424, v_x_2428, v_prog_240, v_at_242, v_p_243, v_k_244}); V a_9 = v_hd_2461; V a_10 = v_k_2462; V r_ = (g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s345929733x1659071665(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9, a_10)); heff_drop(v_t_2464); r_; });
}
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1567142318x1862190202_lam11(V self, V *args) {
  V v_hd_2461 = args[0];
  V v_k_2462 = args[1];
  V v_t_2445 = heff_env(self)[0];
  V v_l_2424 = heff_env(self)[1];
  V v_prog_240 = heff_env(self)[2];
  V v_x_2428 = heff_env(self)[3];
  V v_p_243 = heff_env(self)[4];
  V v_opts_241 = heff_env(self)[5];
  V v_k_244 = heff_env(self)[6];
  V v_dir_2433 = heff_env(self)[7];
  V v_out_2438 = heff_env(self)[8];
  V v_path_2443 = heff_env(self)[9];
  V v_at_242 = heff_env(self)[10];
  heff_clo_take(self, 11);
  return (g_co_2eop_24s94900133x232571340(v_t_2445, heff_dup(v_hd_2461), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1567142318x1862190202_lam12, 1, 12, (V[]){v_l_2424, v_prog_240, v_x_2428, v_p_243, v_opts_241, v_k_244, v_dir_2433, v_out_2438, v_path_2443, v_at_242, v_hd_2461, v_k_2462})));
}
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1567142318x1862190202_lam5(V self, V *args) {
  V v_x_2431 = args[0];
  V v_l_2424 = heff_env(self)[0];
  V v_p_243 = heff_env(self)[1];
  V v_prog_240 = heff_env(self)[2];
  V v_x_2428 = heff_env(self)[3];
  V v_opts_241 = heff_env(self)[4];
  V v_k_244 = heff_env(self)[5];
  V v_at_242 = heff_env(self)[6];
  V v_z_245 = heff_env(self)[7];
  V v_z_246 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_t_2432 = (g_heff_2ebuild_2ecommands_2etestDir(heff_dup(heff_rfield(v_l_2424, 2)), heff_dup(heff_rfield(v_p_243, 0))));
  V v_dir_2433 = (g_heff_2ebuild_2ecommands_2etestDir(heff_dup(heff_rfield(v_l_2424, 2)), heff_dup(heff_rfield(v_p_243, 0))));
  V v_d_2434 = (g_heff_2ebuild_2ecommands_2etestDir(heff_dup(heff_rfield(v_l_2424, 2)), heff_dup(heff_rfield(v_p_243, 0))));
  V v_t_2435 = heff_get_n(heff_dup(heff_rfield(v_l_2424, 2)), 5, 6);
  V v_t_2436 = heff_get_n(heff_dup(heff_rfield(v_l_2424, 2)), 5, 6);
  V v_t_2437;
  switch (heff_tag_of(v_t_2436)) {
  case TAG_Posix: {
    v_t_2437 = ((V)&g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1567142318x1862190202_str3);
    break;
  }
  case TAG_Windows: {
    v_t_2437 = ((V)&g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1567142318x1862190202_str4);
    break;
  }
  default: heff_nomatch(v_t_2436);
  }
  V v_out_2438 = ({ V a_0 = v_t_2435; V a_1 = v_d_2434; V a_2 = v_t_2437; V r_ = (g_std_2epath_2ejoin(a_0, a_1, a_2)); heff_drop(v_t_2435); r_; });
  V v_d_2439 = (g_heff_2ebuild_2ecommands_2etestDir(heff_dup(heff_rfield(v_l_2424, 2)), heff_dup(heff_rfield(v_p_243, 0))));
  V v_t_2440 = heff_get_n(heff_dup(heff_rfield(v_l_2424, 2)), 5, 6);
  V v_t_2441 = heff_get_n(heff_dup(heff_rfield(v_l_2424, 2)), 5, 6);
  V v_t_2442;
  switch (heff_tag_of(v_t_2441)) {
  case TAG_Posix: {
    v_t_2442 = ((V)&g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1567142318x1862190202_str5);
    break;
  }
  case TAG_Windows: {
    v_t_2442 = ((V)&g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1567142318x1862190202_str6);
    break;
  }
  default: heff_nomatch(v_t_2441);
  }
  V v_path_2443 = ({ V a_0 = v_t_2440; V a_1 = v_d_2439; V a_2 = v_t_2442; V r_ = (g_std_2epath_2ejoin(a_0, a_1, a_2)); heff_drop(v_t_2440); r_; });
  V v_t_2444 = heff_tag_n(TAG_End, 2, (V[]){heff_dup(v_x_2431), NTAG(TAG_MkUnit)});
  V v_t_2445 = heff_tr(heff_call(heff_dup(v_prog_240), 1, (V[]){v_t_2444}));
  return (g_heff_2ebuild_2ecommands_2ecLoadedOr_24s832092935x437177150(heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1567142318x1862190202_lam6, 3, 6, (V[]){v_x_2431, heff_dup(v_prog_240), heff_dup(v_x_2428), heff_dup(v_p_243), heff_dup(v_opts_241), heff_dup(v_k_244)}), heff_dup(v_l_2424), heff_tag_n(TAG_Just, 1, (V[]){heff_dup(g_heff_2ebuild_2ecommands_2eintegrationMainName_get())}), heff_strAppend(v_t_2432, ((V)&g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1567142318x1862190202_str8)), heff_dup(heff_rfield(v_p_243, 0)), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1567142318x1862190202_lam11, 2, 11, (V[]){v_t_2445, v_l_2424, v_prog_240, v_x_2428, v_p_243, v_opts_241, v_k_244, v_dir_2433, v_out_2438, v_path_2443, v_at_242}), v_z_245, v_z_246));
}
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1567142318x1862190202_lam3(V self, V *args) {
  V v_x_2428 = args[0];
  V v_prog_240 = heff_env(self)[0];
  V v_z_245 = heff_env(self)[1];
  V v_l_2424 = heff_env(self)[2];
  V v_p_243 = heff_env(self)[3];
  V v_opts_241 = heff_env(self)[4];
  V v_k_244 = heff_env(self)[5];
  V v_at_242 = heff_env(self)[6];
  V v_z_246 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2430 = heff_tr(heff_call(heff_dup(v_prog_240), 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){heff_dup(v_x_2428), ((V)&g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1567142318x1862190202_str2), MK_INT(0LL), ((V)&g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1567142318x1862190202_lam4_clo)})}));
  return (g_co_2eop_24s94900133x232571340(v_t_2430, heff_dup(v_z_245), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1567142318x1862190202_lam5, 1, 9, (V[]){v_l_2424, v_p_243, v_prog_240, v_x_2428, v_opts_241, v_k_244, v_at_242, v_z_245, v_z_246})));
}
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1567142318x1862190202_lam28(V self, V *args) {
  V v_x_24131 = args[0];
  V v_k_244 = heff_env(self)[0];
  V v_z_245 = heff_env(self)[1];
  V v_z_246 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_k_244;
  heff_room[0] = heff_tag_n(TAG_Done, 1, (V[]){v_x_24131});
  heff_room[1] = v_z_245;
  heff_room[2] = v_z_246;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
V g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1567142318x1862190202_lam27(V self, V *args) {
  V v_x_24129 = args[0];
  V v_opts_241 = heff_env(self)[0];
  V v_k_244 = heff_env(self)[1];
  V v_z_245 = heff_env(self)[2];
  V v_z_246 = heff_env(self)[3];
  V v_p_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_24130 = (g_heff_2ebuild_2ecommands_2epassedOver(v_opts_241, heff_dup(v_x_24129)));
  if ((heff_dup(v_t_24130) == NTAG(TAG_True))) {
    heff_drop(v_x_24129);
    heff_drop_rec(v_p_243, 7);
    heff_drop(v_t_24130);
    V f_ = v_k_244;
    heff_room[0] = heff_tag_n(TAG_Done, 1, (V[]){heff_dup(g_heff_2ebuild_2ecommands_2enoRes_get())});
    heff_room[1] = v_z_245;
    heff_room[2] = v_z_246;
    if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
  } else {
    heff_drop(v_t_24130);
    return (g_heff_2ebuild_2ecommands_2etestReport_24s1197250805x667886372(heff_dup(heff_rfield(v_p_243, 0)), heff_dup(heff_rfield(v_p_243, 1)), heff_get_n(v_p_243, 2, 7), v_x_24129, heff_dup(v_z_245), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildIntegrations_24s1567142318x1862190202_lam28, 1, 3, (V[]){v_k_244, v_z_245, v_z_246})));
  }
}
V g_heff_2ebuild_2ecommands_2ecompileJsDiags_24s559977312x1067987643_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ecompileJsDiags_24s559977312x1067987643_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecompileJsDiags_24s559977312x1067987643_entry, 6, 0};

V g_heff_2ebuild_2ecommands_2ecompileJsDiags_24s559977312x1067987643(V v_file_240, V v_outPath_241, V v_badL_242, V v_cs_243, V v_hd_244, V v_k_245) {
top: ;
  return (g_heff_2ebuild_2ecommands_2eputFileDiags_24s1001351446x35627320(heff_dup(v_cs_243), heff_dup(v_hd_244), heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileJsDiags_24s559977312x1067987643_lam0, 1, 5, (V[]){v_cs_243, heff_dup(v_badL_242), v_outPath_241, v_hd_244, v_k_245})));
}
V g_heff_2ebuild_2ecommands_2ecompileJsDiags_24s559977312x1067987643_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a2 = a[2]; V r = g_heff_2ebuild_2ecommands_2ecompileJsDiags_24s559977312x1067987643(a0, a[1], a2, a[3], a[4], a[5]); heff_drop(a0); heff_drop(a2); return r;
}
V g_heff_2ebuild_2ecommands_2ecompileJsDiags_24s559977312x1067987643_lam0(V self, V *args) {
  V v_x_246 = args[0];
  V v_cs_243 = heff_env(self)[0];
  V v_badL_242 = heff_env(self)[1];
  V v_outPath_241 = heff_env(self)[2];
  V v_hd_244 = heff_env(self)[3];
  V v_k_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_246);
  HeffT2 v_t_247 = (g_heff_2ebuild_2edriver_2elastChecked_24cpr(heff_dup(v_cs_243)));
  {
    V v_field_249 = v_t_247.f[1];
    int64_t v_tag_248 = ((int64_t)v_t_247.f[0]);
    if ((v_tag_248 == ((int64_t)0ULL))) {
      V v_c_2411 = v_field_249;
      V v_t_2412;
      if ((heff_dup(v_badL_242) == NTAG(TAG_True))) {
        heff_drop(v_cs_243);
        heff_drop(v_badL_242);
        v_t_2412 = NTAG(TAG_True);
      } else {
        heff_drop(v_badL_242);
        v_t_2412 = ({ V a_0 = v_cs_243; V r_ = (g_list_2eany_24s469495312x865582084(a_0)); heff_drop(v_cs_243); r_; });
      }
      V v_t_2413 = heff_get_n(heff_dup(heff_rfield(v_c_2411, 5)), 0, 9);
      V v_t_2414 = (g_list_2emap_24s1234524601x742515152(heff_get_n(v_c_2411, 7, 14)));
      V v_t_2415 = (g_heff_2ecompile_2eemit_2ecompileJs(v_t_2413, v_t_2414));
      return ({ V a_0 = v_outPath_241; V a_1 = v_t_2412; V a_2 = v_t_2415; V a_3 = v_hd_244; V a_4 = v_k_245; V r_ = (g_heff_2ebuild_2ecommands_2ecompileJsOut_24s253825103x859442878(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_t_2412); r_; });
    } else {
      heff_drop(v_cs_243);
      heff_drop(v_badL_242);
      heff_drop(v_outPath_241);
      heff_drop(v_field_249);
      V v_t_2416 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
      V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2416})});
      V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
      V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
      V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
      V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
      return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2421}), v_hd_244, v_k_245));
    }
  }
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecCmd_24s99213171x760810846_str0, 1, "/");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecCmd_24s99213171x760810846_str1, 3, "*.c");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecCmd_24s99213171x760810846_str2, 39, " -femit-bin=runtime.o` and `zig cc -O2 ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecCmd_24s99213171x760810846_str3, 26, " runtime.o -o PROGRAM -lm`");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecCmd_24s99213171x760810846_str4, 46, ": build it with `zig build-obj -O ReleaseFast ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecCmd_24s99213171x760810846_str5, 6, "wrote ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecCmd_24s99213171x760810846_str6, 1, "\012");
V g_heff_2ebuild_2ecommands_2ecCmd_24s99213171x760810846_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecCmd_24s99213171x760810846_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ecCmd_24s99213171x760810846_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecCmd_24s99213171x760810846_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2ecCmd_24s99213171x760810846(V v_name_240, V v_outPath_241, V v_file_242) {
top: ;
  V v_t_243 = (g_heff_2ebuild_2ecommands_2ezigOf(heff_dup(v_outPath_241)));
  int64_t v_t_244 = (heff_unbox_word(heff_strLength_lent(v_outPath_241, 0)) - ((int64_t)1ULL));
  V v_t_245 = heff_strSlice(heff_dup(v_outPath_241), heff_box_word(v_t_244), heff_strLength_lent(v_outPath_241, 0));
  V v_t_247;
  if (heff_strEq_c(v_t_245, ((V)&g_heff_2ebuild_2ecommands_2ecCmd_24s99213171x760810846_str0))) {
    v_t_247 = heff_strAppend(heff_dup(v_outPath_241), ((V)&g_heff_2ebuild_2ecommands_2ecCmd_24s99213171x760810846_str1));
  } else {
    v_t_247 = heff_dup(v_outPath_241);
  }
  V v_t_248 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ecCmd_24s99213171x760810846_str2), heff_strAppend(v_t_247, ((V)&g_heff_2ebuild_2ecommands_2ecCmd_24s99213171x760810846_str3)));
  V v_t_249 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ecCmd_24s99213171x760810846_str4), heff_strAppend(v_t_243, v_t_248));
  V v_str_2410 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ecCmd_24s99213171x760810846_str5), heff_strAppend(heff_dup(v_outPath_241), v_t_249));
  V v_c_2411 = (g_heff_2ebuild_2ecommands_2eload_24s1185299161x1866120155(heff_dup(v_file_242)));
  return heff_clo_n(g_heff_2ebuild_2ecommands_2ecCmd_24s99213171x760810846_lam0, 2, 5, (V[]){v_c_2411, v_str_2410, v_name_240, v_outPath_241, v_file_242});
}
V g_heff_2ebuild_2ecommands_2ecCmd_24s99213171x760810846_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ecCmd_24s99213171x760810846(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2ecommands_2ecCmd_24s99213171x760810846_lam1(V self, V *args) {
  V v_x_2414 = args[0];
  V v_str_2410 = heff_env(self)[0];
  V v_name_240 = heff_env(self)[1];
  V v_outPath_241 = heff_env(self)[2];
  V v_file_242 = heff_env(self)[3];
  V v_hd_2412 = heff_env(self)[4];
  V v_k_2413 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2415 = heff_tag_n(TAG_Write, 2, (V[]){heff_strAppend(v_str_2410, ((V)&g_heff_2ebuild_2ecommands_2ecCmd_24s99213171x760810846_str6)), NTAG(TAG_MkUnit)});
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
  V v_t_2421 = heff_tr(heff_call(((V)&g_co_2eop_24s903439140x919002362_clo), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2420})}));
  return (g_heff_2ebuild_2ecommands_2ecLoadedOr_24s396496052x1044438622(MK_INT(1LL), v_x_2414, v_name_240, v_outPath_241, v_file_242, v_t_2421, v_hd_2412, v_k_2413));
}
V g_heff_2ebuild_2ecommands_2ecCmd_24s99213171x760810846_lam0(V self, V *args) {
  V v_hd_2412 = args[0];
  V v_k_2413 = args[1];
  V v_c_2411 = heff_env(self)[0];
  V v_str_2410 = heff_env(self)[1];
  V v_name_240 = heff_env(self)[2];
  V v_outPath_241 = heff_env(self)[3];
  V v_file_242 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_2411;
  args[0] = heff_dup(v_hd_2412);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ecCmd_24s99213171x760810846_lam1, 1, 6, (V[]){v_str_2410, v_name_240, v_outPath_241, v_file_242, v_hd_2412, v_k_2413});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetRequire_24s705774581x1881397247_str0, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetRequire_24s705774581x1881397247_str1, 10, "heff get: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetRequire_24s705774581x1881397247_str2, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetRequire_24s705774581x1881397247_str3, 10, "heff get: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetRequire_24s705774581x1881397247_str4, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetRequire_24s705774581x1881397247_str5, 3, "src");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetRequire_24s705774581x1881397247_str6, 10, "heff get: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetRequire_24s705774581x1881397247_str7, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetRequire_24s705774581x1881397247_str8, 27, "` is required already: add ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetRequire_24s705774581x1881397247_str9, 30, " to package.hf by another name");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetRequire_24s705774581x1881397247_str10, 1, "`");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetRequire_24s705774581x1881397247_str11, 10, "heff get: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetRequire_24s705774581x1881397247_str12, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetRequire_24s705774581x1881397247_str13, 10, "package.hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetRequire_24s705774581x1881397247_str14, 3, ".hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetRequire_24s705774581x1881397247_str15, 10, "package.hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetRequire_24s705774581x1881397247_str16, 1, " ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetRequire_24s705774581x1881397247_str17, 30, "heff get: package.hf requires ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetRequire_24s705774581x1881397247_str18, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egetRequire_24s705774581x1881397247_str19, 34, "heff get: cannot write package.hf\012");
V g_heff_2ebuild_2ecommands_2egetRequire_24s705774581x1881397247_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetRequire_24s705774581x1881397247_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetRequire_24s705774581x1881397247_lam0(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetRequire_24s705774581x1881397247_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetRequire_24s705774581x1881397247_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetRequire_24s705774581x1881397247_lam9(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetRequire_24s705774581x1881397247_lam8(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetRequire_24s705774581x1881397247_lam11(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetRequire_24s705774581x1881397247_lam10(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetRequire_24s705774581x1881397247_lam12(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2egetRequire_24s705774581x1881397247_lam12_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2egetRequire_24s705774581x1881397247_lam12, 1, 0};
V g_heff_2ebuild_2ecommands_2egetRequire_24s705774581x1881397247_lam14(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetRequire_24s705774581x1881397247_lam16(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetRequire_24s705774581x1881397247_lam15(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetRequire_24s705774581x1881397247_lam13(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetRequire_24s705774581x1881397247_lam7(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetRequire_24s705774581x1881397247_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2egetRequire_24s705774581x1881397247_lam3(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2egetRequire_24s705774581x1881397247_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2egetRequire_24s705774581x1881397247_entry, 6, 0};

V g_heff_2ebuild_2ecommands_2egetRequire_24s705774581x1881397247(V v_prog_240, V v_ps_241, V v_text_242, V v_pk_243, V v_path_244, V v_v_245) {
top: ;
  HeffT2 v_t_246 = (g_heff_2ebuild_2eproject_2emajorMismatch_24cpr(heff_dup(v_path_244), heff_dup(v_v_245)));
  {
    V v_field_248 = v_t_246.f[1];
    int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
    if ((v_tag_247 == ((int64_t)0ULL))) {
      heff_drop(v_prog_240);
      heff_drop_rec(v_ps_241, 6);
      heff_drop(v_text_242);
      heff_drop_rec(v_pk_243, 4);
      heff_drop(v_v_245);
      V v_why_2410 = v_field_248;
      return heff_clo_n(g_heff_2ebuild_2ecommands_2egetRequire_24s705774581x1881397247_lam0, 2, 2, (V[]){v_path_244, v_why_2410});
    } else {
      heff_drop(v_field_248);
      V v_c_2429 = (g_heff_2ebuild_2ecommands_2efetched_24s906028843x297767049(v_prog_240, heff_dup(v_ps_241), heff_dup(v_path_244), heff_dup(v_v_245)));
      return heff_clo_n(g_heff_2ebuild_2ecommands_2egetRequire_24s705774581x1881397247_lam3, 2, 6, (V[]){v_c_2429, v_ps_241, v_path_244, v_v_245, v_pk_243, v_text_242});
    }
  }
}
V g_heff_2ebuild_2ecommands_2egetRequire_24s705774581x1881397247_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2egetRequire_24s705774581x1881397247(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2ebuild_2ecommands_2egetRequire_24s705774581x1881397247_lam2(V self, V *args) {
  V v_x_2428 = args[0];
  V v_k_2412 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2428);
  V f_ = v_k_2412;
  args[0] = NTAG(TAG_False);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2egetRequire_24s705774581x1881397247_lam1(V self, V *args) {
  V v_x_2421 = args[0];
  V v_hd_2411 = heff_env(self)[0];
  V v_k_2412 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2421);
  V v_t_2422 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2422})});
  V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
  V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
  V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
  V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
  return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2427}), v_hd_2411, heff_clo_n(g_heff_2ebuild_2ecommands_2egetRequire_24s705774581x1881397247_lam2, 1, 1, (V[]){v_k_2412})));
}
V g_heff_2ebuild_2ecommands_2egetRequire_24s705774581x1881397247_lam0(V self, V *args) {
  V v_hd_2411 = args[0];
  V v_k_2412 = args[1];
  V v_path_244 = heff_env(self)[0];
  V v_why_2410 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2413 = heff_strAppend(v_path_244, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2egetRequire_24s705774581x1881397247_str0), v_why_2410));
  V v_t_2414 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2egetRequire_24s705774581x1881397247_str1), v_t_2413), ((V)&g_heff_2ebuild_2ecommands_2egetRequire_24s705774581x1881397247_str2));
  V v_t_2415 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2414, NTAG(TAG_MkUnit)});
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
  return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2420}), heff_dup(v_hd_2411), heff_clo_n(g_heff_2ebuild_2ecommands_2egetRequire_24s705774581x1881397247_lam1, 1, 2, (V[]){v_hd_2411, v_k_2412})));
}
V g_heff_2ebuild_2ecommands_2egetRequire_24s705774581x1881397247_lam6(V self, V *args) {
  V v_x_2448 = args[0];
  V v_k_2431 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2448);
  V f_ = v_k_2431;
  args[0] = NTAG(TAG_False);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2egetRequire_24s705774581x1881397247_lam5(V self, V *args) {
  V v_x_2441 = args[0];
  V v_hd_2430 = heff_env(self)[0];
  V v_k_2431 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2441);
  V v_t_2442 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2443 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2442})});
  V v_t_2444 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2443})});
  V v_t_2445 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2444})});
  V v_t_2446 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2445})});
  V v_t_2447 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2446})});
  return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2447}), v_hd_2430, heff_clo_n(g_heff_2ebuild_2ecommands_2egetRequire_24s705774581x1881397247_lam6, 1, 1, (V[]){v_k_2431})));
}
V g_heff_2ebuild_2ecommands_2egetRequire_24s705774581x1881397247_lam9(V self, V *args) {
  V v_x_2468 = args[0];
  V v_k_2431 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2468);
  V f_ = v_k_2431;
  args[0] = NTAG(TAG_False);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2egetRequire_24s705774581x1881397247_lam8(V self, V *args) {
  V v_x_2461 = args[0];
  V v_hd_2430 = heff_env(self)[0];
  V v_k_2431 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2461);
  V v_t_2462 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2463 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2462})});
  V v_t_2464 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2463})});
  V v_t_2465 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2464})});
  V v_t_2466 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2465})});
  V v_t_2467 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2466})});
  return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2467}), v_hd_2430, heff_clo_n(g_heff_2ebuild_2ecommands_2egetRequire_24s705774581x1881397247_lam9, 1, 1, (V[]){v_k_2431})));
}
V g_heff_2ebuild_2ecommands_2egetRequire_24s705774581x1881397247_lam11(V self, V *args) {
  V v_x_2488 = args[0];
  V v_k_2431 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2488);
  V f_ = v_k_2431;
  args[0] = NTAG(TAG_False);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2egetRequire_24s705774581x1881397247_lam10(V self, V *args) {
  V v_x_2481 = args[0];
  V v_hd_2430 = heff_env(self)[0];
  V v_k_2431 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2481);
  V v_t_2482 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2483 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2482})});
  V v_t_2484 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2483})});
  V v_t_2485 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2484})});
  V v_t_2486 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2485})});
  V v_t_2487 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2486})});
  return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2487}), v_hd_2430, heff_clo_n(g_heff_2ebuild_2ecommands_2egetRequire_24s705774581x1881397247_lam11, 1, 1, (V[]){v_k_2431})));
}
V g_heff_2ebuild_2ecommands_2egetRequire_24s705774581x1881397247_lam12(V self, V *args) {
  V v_ok_24102 = args[0];
  return v_ok_24102;
}
V g_heff_2ebuild_2ecommands_2egetRequire_24s705774581x1881397247_lam14(V self, V *args) {
  V v_x_24117 = args[0];
  V v_k_2431 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_24117);
  V f_ = v_k_2431;
  args[0] = NTAG(TAG_True);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2egetRequire_24s705774581x1881397247_lam16(V self, V *args) {
  V v_x_24131 = args[0];
  V v_k_2431 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_24131);
  V f_ = v_k_2431;
  args[0] = NTAG(TAG_False);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2egetRequire_24s705774581x1881397247_lam15(V self, V *args) {
  V v_x_24124 = args[0];
  V v_hd_2430 = heff_env(self)[0];
  V v_k_2431 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_24124);
  V v_t_24125 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_24126 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24125})});
  V v_t_24127 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24126})});
  V v_t_24128 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24127})});
  V v_t_24129 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24128})});
  V v_t_24130 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24129})});
  return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_24130}), v_hd_2430, heff_clo_n(g_heff_2ebuild_2ecommands_2egetRequire_24s705774581x1881397247_lam16, 1, 1, (V[]){v_k_2431})));
}
V g_heff_2ebuild_2ecommands_2egetRequire_24s705774581x1881397247_lam13(V self, V *args) {
  V v_x_24108 = args[0];
  V v_path_244 = heff_env(self)[0];
  V v_v_245 = heff_env(self)[1];
  V v_hd_2430 = heff_env(self)[2];
  V v_k_2431 = heff_env(self)[3];
  heff_clo_take(self, 4);
  if ((heff_dup(v_x_24108) == NTAG(TAG_True))) {
    heff_drop(v_x_24108);
    V v_t_24109 = heff_strAppend(v_path_244, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2egetRequire_24s705774581x1881397247_str16), v_v_245));
    V v_t_24110 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2egetRequire_24s705774581x1881397247_str17), v_t_24109), ((V)&g_heff_2ebuild_2ecommands_2egetRequire_24s705774581x1881397247_str18));
    V v_t_24111 = heff_tag_n(TAG_Write, 2, (V[]){v_t_24110, NTAG(TAG_MkUnit)});
    V v_t_24112 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24111})});
    V v_t_24113 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24112})});
    V v_t_24114 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24113})});
    V v_t_24115 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24114})});
    V v_t_24116 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24115})});
    return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_24116}), v_hd_2430, heff_clo_n(g_heff_2ebuild_2ecommands_2egetRequire_24s705774581x1881397247_lam14, 1, 1, (V[]){v_k_2431})));
  } else {
    heff_drop(v_x_24108);
    heff_drop(v_path_244);
    heff_drop(v_v_245);
    V v_t_24118 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2egetRequire_24s705774581x1881397247_str19), NTAG(TAG_MkUnit)});
    V v_t_24119 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24118})});
    V v_t_24120 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24119})});
    V v_t_24121 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24120})});
    V v_t_24122 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24121})});
    V v_t_24123 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24122})});
    return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_24123}), heff_dup(v_hd_2430), heff_clo_n(g_heff_2ebuild_2ecommands_2egetRequire_24s705774581x1881397247_lam15, 1, 2, (V[]){v_hd_2430, v_k_2431})));
  }
}
V g_heff_2ebuild_2ecommands_2egetRequire_24s705774581x1881397247_lam7(V self, V *args) {
  V v_x_2452 = args[0];
  V v_hd_2430 = heff_env(self)[0];
  V v_k_2431 = heff_env(self)[1];
  V v_path_244 = heff_env(self)[2];
  V v_pk_243 = heff_env(self)[3];
  V v_v_245 = heff_env(self)[4];
  V v_text_242 = heff_env(self)[5];
  heff_clo_take(self, 6);
  switch (heff_tag_of(v_x_2452)) {
  case TAG_Left: {
    V v_why_2453 = heff_field(v_x_2452, 0);
    V v_ru_24x_2452_24Left = heff_take_reuse_n(v_x_2452, 1ULL, 1);
    heff_drop(v_path_244);
    heff_drop_rec(v_pk_243, 4);
    heff_drop(v_v_245);
    heff_drop(v_text_242);
    V v_t_2454 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2egetRequire_24s705774581x1881397247_str6), v_why_2453), ((V)&g_heff_2ebuild_2ecommands_2egetRequire_24s705774581x1881397247_str7));
    V v_t_2455 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2454, NTAG(TAG_MkUnit)});
    V v_t_2456 = heff_tag_at_n(v_ru_24x_2452_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2455})});
    V v_t_2457 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2456})});
    V v_t_2458 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2457})});
    V v_t_2459 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2458})});
    V v_t_2460 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2459})});
    return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2460}), heff_dup(v_hd_2430), heff_clo_n(g_heff_2ebuild_2ecommands_2egetRequire_24s705774581x1881397247_lam8, 1, 2, (V[]){v_hd_2430, v_k_2431})));
  }
  case TAG_Right: {
    V v_name_2469 = heff_field(v_x_2452, 0);
    V v_ru_24x_2452_24Right = heff_take_reuse_n(v_x_2452, 1ULL, 1);
    V v_x1_2470 = (g_list_2eany_24s1875112453x1656618700(v_path_244, heff_rfield(v_pk_243, 2)));
    V v_t_2471;
    if ((heff_dup(v_x1_2470) == NTAG(TAG_True))) {
      heff_drop(v_x1_2470);
      v_t_2471 = NTAG(TAG_False);
    } else {
      heff_drop(v_x1_2470);
      v_t_2471 = (g_list_2eany_24s332527547x6651279(v_name_2469, heff_rfield(v_pk_243, 2)));
    }
    if ((heff_dup(v_t_2471) == NTAG(TAG_True))) {
      heff_drop_rec(v_pk_243, 4);
      heff_drop(v_v_245);
      heff_drop(v_text_242);
      heff_drop(v_t_2471);
      V v_t_2472 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2egetRequire_24s705774581x1881397247_str8), heff_strAppend(v_path_244, ((V)&g_heff_2ebuild_2ecommands_2egetRequire_24s705774581x1881397247_str9)));
      V v_t_2473 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2egetRequire_24s705774581x1881397247_str10), heff_strAppend(v_name_2469, v_t_2472));
      V v_t_2474 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2egetRequire_24s705774581x1881397247_str11), v_t_2473), ((V)&g_heff_2ebuild_2ecommands_2egetRequire_24s705774581x1881397247_str12));
      V v_t_2475 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2474, NTAG(TAG_MkUnit)});
      V v_t_2476 = heff_tag_at_n(v_ru_24x_2452_24Right, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2475})});
      V v_t_2477 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2476})});
      V v_t_2478 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2477})});
      V v_t_2479 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2478})});
      V v_t_2480 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2479})});
      return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2480}), heff_dup(v_hd_2430), heff_clo_n(g_heff_2ebuild_2ecommands_2egetRequire_24s705774581x1881397247_lam10, 1, 2, (V[]){v_hd_2430, v_k_2431})));
    } else {
      heff_drop(v_t_2471);
      V v_t_2489 = (g_list_2eany_24s1875112453x1656618700(v_path_244, heff_rfield(v_pk_243, 2)));
      V v_t_2491;
      if ((heff_dup(v_t_2489) == NTAG(TAG_True))) {
        heff_drop(v_name_2469);
        heff_drop(v_t_2489);
        v_t_2491 = (g_list_2emap_24s1814289659x520383890(heff_dup(v_path_244), heff_dup(v_v_245), heff_dup(heff_rfield(v_pk_243, 2))));
      } else {
        heff_drop(v_t_2489);
        V v_t_2490 = heff_tag_n(TAG_Cons, 2, (V[]){heff_rec_n(3, shape_name__path__version, (V[]){v_name_2469, heff_dup(v_path_244), heff_dup(v_v_245)}), NTAG(TAG_Nil)});
        v_t_2491 = (g_prelude_2e_2b_2b(heff_dup(heff_rfield(v_pk_243, 2)), v_t_2490));
      }
      V v_t_2492 = ({ V rv_2 = v_t_2491; V rr_ = heff_rec_reuse_nf(v_pk_243, 11ULL, 4, shape_module__heff__require__replace, 207u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
      V v_text_2493 = (g_heff_2ebuild_2eproject_2ewithPackage(v_text_242, v_t_2492));
      V v_str_24101;
      if (heff_strEq_c(heff_strSlice(((V)&g_heff_2ebuild_2ecommands_2egetRequire_24s705774581x1881397247_str13), MK_INT(7LL), MK_INT(10LL)), ((V)&g_heff_2ebuild_2ecommands_2egetRequire_24s705774581x1881397247_str14))) {
        HeffT2 v_t_2495 = (g_heff_2esyntax_2eformat_2eformat_24cpr(heff_dup(v_text_2493)));
        {
          V v_field_2497 = v_t_2495.f[1];
          int64_t v_tag_2496 = ((int64_t)v_t_2495.f[0]);
          if ((v_tag_2496 == ((int64_t)0ULL))) {
            V v_x_2499 = v_field_2497;
            heff_drop(v_x_2499);
            v_str_24101 = v_text_2493;
          } else {
            heff_drop(v_text_2493);
            V v_out_24100 = v_field_2497;
            v_str_24101 = v_out_24100;
          }
        }
      } else {
        v_str_24101 = v_text_2493;
      }
      V v_t_24103 = heff_tag_at_n(v_ru_24x_2452_24Right, TAG_InR, 1, (V[]){heff_tag_n(TAG_WriteFile, 3, (V[]){((V)&g_heff_2ebuild_2ecommands_2egetRequire_24s705774581x1881397247_str15), v_str_24101, ((V)&g_heff_2ebuild_2ecommands_2egetRequire_24s705774581x1881397247_lam12_clo)})});
      V v_t_24104 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24103})});
      V v_t_24105 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24104})});
      V v_t_24106 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24105})});
      V v_t_24107 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24106})});
      return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_24107}), heff_dup(v_hd_2430), heff_clo_n(g_heff_2ebuild_2ecommands_2egetRequire_24s705774581x1881397247_lam13, 1, 4, (V[]){v_path_244, v_v_245, v_hd_2430, v_k_2431})));
    }
  }
  default: return heff_nomatch(v_x_2452);
  }
}
V g_heff_2ebuild_2ecommands_2egetRequire_24s705774581x1881397247_lam4(V self, V *args) {
  V v_x_2432 = args[0];
  V v_hd_2430 = heff_env(self)[0];
  V v_k_2431 = heff_env(self)[1];
  V v_ps_241 = heff_env(self)[2];
  V v_path_244 = heff_env(self)[3];
  V v_v_245 = heff_env(self)[4];
  V v_pk_243 = heff_env(self)[5];
  V v_text_242 = heff_env(self)[6];
  heff_clo_take(self, 7);
  switch (heff_tag_of(v_x_2432)) {
  case TAG_Left: {
    V v_why_2433 = heff_field(v_x_2432, 0);
    V v_ru_24x_2432_24Left = heff_take_reuse_n(v_x_2432, 1ULL, 1);
    heff_drop_rec(v_ps_241, 6);
    heff_drop(v_path_244);
    heff_drop(v_v_245);
    heff_drop_rec(v_pk_243, 4);
    heff_drop(v_text_242);
    V v_t_2434 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2egetRequire_24s705774581x1881397247_str3), v_why_2433), ((V)&g_heff_2ebuild_2ecommands_2egetRequire_24s705774581x1881397247_str4));
    V v_t_2435 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2434, NTAG(TAG_MkUnit)});
    V v_t_2436 = heff_tag_at_n(v_ru_24x_2432_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2435})});
    V v_t_2437 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2436})});
    V v_t_2438 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2437})});
    V v_t_2439 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2438})});
    V v_t_2440 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2439})});
    return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2440}), heff_dup(v_hd_2430), heff_clo_n(g_heff_2ebuild_2ecommands_2egetRequire_24s705774581x1881397247_lam5, 1, 2, (V[]){v_hd_2430, v_k_2431})));
  }
  case TAG_Right: {
    heff_take_n(v_x_2432, 0ULL, 1);
    V v_t_2450 = (g_heff_2ebuild_2eload_2ecachedDir(heff_dup(v_ps_241), heff_dup(v_path_244), heff_dup(v_v_245)));
    V v_t_2451 = (g_std_2epath_2ejoin(heff_rfield(v_ps_241, 5), v_t_2450, ((V)&g_heff_2ebuild_2ecommands_2egetRequire_24s705774581x1881397247_str5)));
    return (g_heff_2ebuild_2eload_2eownDir_24s1338691877x240810656(v_ps_241, v_t_2451, heff_dup(v_hd_2430), heff_clo_n(g_heff_2ebuild_2ecommands_2egetRequire_24s705774581x1881397247_lam7, 1, 6, (V[]){v_hd_2430, v_k_2431, v_path_244, v_pk_243, v_v_245, v_text_242})));
  }
  default: return heff_nomatch(v_x_2432);
  }
}
V g_heff_2ebuild_2ecommands_2egetRequire_24s705774581x1881397247_lam3(V self, V *args) {
  V v_hd_2430 = args[0];
  V v_k_2431 = args[1];
  V v_c_2429 = heff_env(self)[0];
  V v_ps_241 = heff_env(self)[1];
  V v_path_244 = heff_env(self)[2];
  V v_v_245 = heff_env(self)[3];
  V v_pk_243 = heff_env(self)[4];
  V v_text_242 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V f_ = v_c_2429;
  args[0] = heff_dup(v_hd_2430);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2egetRequire_24s705774581x1881397247_lam4, 1, 7, (V[]){v_hd_2430, v_k_2431, v_ps_241, v_path_244, v_v_245, v_pk_243, v_text_242});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eplaceAll_24s97124616x701649523_str0, 1, "c");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eplaceAll_24s97124616x701649523_str1, 3, ".js");
Clo g_heff_2ebuild_2ecommands_2eplaceAll_24s97124616x701649523_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eplaceAll_24s97124616x701649523_entry, 6, 0};

V g_heff_2ebuild_2ecommands_2eplaceAll_24s97124616x701649523(V v_prog_240, V v_st_241, V v_t_242, V v_pl_243, V v_next_244, V v_x5_245) {
top: ;
  switch (heff_tag_of(v_x5_245)) {
  case TAG_Nil: {
    heff_drop(v_prog_240);
    heff_drop_rec(v_t_242, 6);
    heff_drop(v_pl_243);
    return v_next_244;
  }
  case TAG_Cons: {
    V v_a_246 = heff_field(v_x5_245, 0);
    V v_rest_247 = heff_field(v_x5_245, 1);
    V v_t_248 = (g_heff_2ebuild_2ecommands_2eplaceAll_24s97124616x701649523(heff_dup(v_prog_240), v_st_241, heff_dup(v_t_242), heff_dup(v_pl_243), v_next_244, v_rest_247));
    V v_t_249 = heff_get_n(heff_dup(heff_rfield(v_a_246, 1)), 0, 3);
    V v_t_2413;
    if (heff_strEq_c(v_t_249, ((V)&g_heff_2ebuild_2ecommands_2eplaceAll_24s97124616x701649523_str0))) {
      v_t_2413 = heff_tag_n(TAG_Just, 1, (V[]){heff_dup(heff_rfield(v_a_246, 0))});
    } else {
      V v_t_2411 = heff_dup(heff_rfield(v_t_242, 3));
      if ((heff_dup(v_t_2411) == NTAG(TAG_True))) {
        heff_drop(v_t_2411);
        V v_t_2412 = heff_strAppend(heff_dup(heff_rfield(v_a_246, 0)), ((V)&g_heff_2ebuild_2ecommands_2eplaceAll_24s97124616x701649523_str1));
        v_t_2413 = heff_tag_n(TAG_Just, 1, (V[]){v_t_2412});
      } else {
        heff_drop(v_t_2411);
        v_t_2413 = NTAG(TAG_Nothing);
      }
    }
    return (g_heff_2ebuild_2ecommands_2eplaceMade_24s1874300823x1153072813(v_prog_240, v_st_241, v_t_242, v_pl_243, v_t_248, heff_dup(heff_rfield(v_a_246, 0)), v_t_2413));
  }
  default: return heff_nomatch(v_x5_245);
  }
}
V g_heff_2ebuild_2ecommands_2eplaceAll_24s97124616x701649523_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a5 = a[5]; V r = g_heff_2ebuild_2ecommands_2eplaceAll_24s97124616x701649523(a[0], a1, a[2], a[3], a[4], a5); heff_drop(a1); heff_drop(a5); return r;
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eonPathHint_24s949169181x1811404266_str0, 4, "PATH");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eonPathHint_24s949169181x1811404266_str1, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eonPathHint_24s949169181x1811404266_str2, 5, "win32");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eonPathHint_24s949169181x1811404266_str3, 1, ";");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eonPathHint_24s949169181x1811404266_str4, 1, ":");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eonPathHint_24s949169181x1811404266_str5, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eonPathHint_24s949169181x1811404266_str6, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eonPathHint_24s949169181x1811404266_str7, 14, "heff install: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eonPathHint_24s949169181x1811404266_str8, 60, " is not on the PATH: add it there to run them by their names");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eonPathHint_24s949169181x1811404266_str9, 1, "\012");
V g_heff_2ebuild_2ecommands_2eonPathHint_24s949169181x1811404266_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eonPathHint_24s949169181x1811404266_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eonPathHint_24s949169181x1811404266_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2eonPathHint_24s949169181x1811404266_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eonPathHint_24s949169181x1811404266_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eonPathHint_24s949169181x1811404266_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2eonPathHint_24s949169181x1811404266_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2eonPathHint_24s949169181x1811404266_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2eonPathHint_24s949169181x1811404266_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eonPathHint_24s949169181x1811404266_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eonPathHint_24s949169181x1811404266_entry, 4, 0};

V g_heff_2ebuild_2ecommands_2eonPathHint_24s949169181x1811404266(V v_st_240, V v_bin_241, V v_hd_242, V v_k_243) {
top: ;
  V v_t_245 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2eonPathHint_24s949169181x1811404266_lam0_clo)})});
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_245})});
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  return (g_co_2eop_24s94900133x232571340(v_t_2410, heff_dup(v_hd_242), heff_clo_n(g_heff_2ebuild_2ecommands_2eonPathHint_24s949169181x1811404266_lam1, 1, 4, (V[]){v_hd_242, heff_dup(v_st_240), v_bin_241, v_k_243})));
}
V g_heff_2ebuild_2ecommands_2eonPathHint_24s949169181x1811404266_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2eonPathHint_24s949169181x1811404266(a0, a[1], a[2], a[3]); heff_drop(a0); return r;
}
V g_heff_2ebuild_2ecommands_2eonPathHint_24s949169181x1811404266_lam0(V self, V *args) {
  V v_s_244 = args[0];
  return v_s_244;
}
V g_heff_2ebuild_2ecommands_2eonPathHint_24s949169181x1811404266_lam2(V self, V *args) {
  V v_v_2412 = args[0];
  return v_v_2412;
}
V g_heff_2ebuild_2ecommands_2eonPathHint_24s949169181x1811404266_lam4(V self, V *args) {
  V v_d_2426 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_bin_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2427 = (g_std_2epath_2ejoin(v_st_240, v_d_2426, ((V)&g_heff_2ebuild_2ecommands_2eonPathHint_24s949169181x1811404266_str5)));
  V v_t_2428 = ({ V a_0 = v_st_240; V a_1 = v_bin_241; V a_2 = ((V)&g_heff_2ebuild_2ecommands_2eonPathHint_24s949169181x1811404266_str6); V r_ = (g_std_2epath_2ejoin(a_0, a_1, a_2)); heff_drop(v_st_240); r_; });
  return heff_strEq(v_t_2427, v_t_2428);
}
V g_heff_2ebuild_2ecommands_2eonPathHint_24s949169181x1811404266_lam3(V self, V *args) {
  V v_x_2419 = args[0];
  V v_x_2411 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_bin_241 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  V v_hd_242 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_path_2421;
  switch (heff_tag_of(v_x_2419)) {
  case TAG_Nothing: {
    v_path_2421 = ((V)&g_heff_2ebuild_2ecommands_2eonPathHint_24s949169181x1811404266_str1);
    break;
  }
  case TAG_Just: {
    V v_x_2420 = heff_field(v_x_2419, 0);
    heff_take_n(v_x_2419, 1ULL, 1);
    v_path_2421 = v_x_2420;
    break;
  }
  default: heff_nomatch(v_x_2419);
  }
  V v_sep_2423;
  if (heff_strEq_c(v_x_2411, ((V)&g_heff_2ebuild_2ecommands_2eonPathHint_24s949169181x1811404266_str2))) {
    v_sep_2423 = ((V)&g_heff_2ebuild_2ecommands_2eonPathHint_24s949169181x1811404266_str3);
  } else {
    v_sep_2423 = ((V)&g_heff_2ebuild_2ecommands_2eonPathHint_24s949169181x1811404266_str4);
  }
  V v_t_2425;
  if ((heff_unbox_word(heff_strLength_lent(v_sep_2423, 0)) == ((int64_t)0ULL))) {
    heff_drop(v_sep_2423);
    v_t_2425 = heff_tag_n(TAG_Cons, 2, (V[]){v_path_2421, NTAG(TAG_Nil)});
  } else {
    v_t_2425 = ({ V a_0 = v_sep_2423; V a_1 = v_path_2421; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(v_sep_2423, v_path_2421, MK_INT(0LL), 4); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_sep_2423); heff_drop(v_path_2421); r_; });
  }
  V v_t_2429 = ({ V a_0 = heff_clo_n(g_heff_2ebuild_2ecommands_2eonPathHint_24s949169181x1811404266_lam4, 1, 2, (V[]){v_st_240, heff_dup(v_bin_241)}); V a_1 = v_t_2425; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_t_2425); r_; });
  if ((heff_dup(v_t_2429) == NTAG(TAG_True))) {
    heff_drop(v_bin_241);
    heff_drop(v_hd_242);
    heff_drop(v_t_2429);
    V f_ = v_k_243;
    args[0] = NTAG(TAG_MkUnit);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  } else {
    heff_drop(v_t_2429);
    V v_t_2430 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eonPathHint_24s949169181x1811404266_str7), heff_strAppend(v_bin_241, ((V)&g_heff_2ebuild_2ecommands_2eonPathHint_24s949169181x1811404266_str8)));
    V v_t_2431 = heff_tag_n(TAG_Write, 2, (V[]){heff_strAppend(v_t_2430, ((V)&g_heff_2ebuild_2ecommands_2eonPathHint_24s949169181x1811404266_str9)), NTAG(TAG_MkUnit)});
    V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
    V v_t_2433 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2432})});
    V v_t_2434 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2433})});
    V v_t_2435 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2434})});
    V v_t_2436 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2435})});
    return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2436}), v_hd_242, v_k_243));
  }
}
V g_heff_2ebuild_2ecommands_2eonPathHint_24s949169181x1811404266_lam1(V self, V *args) {
  V v_x_2411 = args[0];
  V v_hd_242 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_bin_241 = heff_env(self)[2];
  V v_k_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2413 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_GetEnv, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2eonPathHint_24s949169181x1811404266_str0), ((V)&g_heff_2ebuild_2ecommands_2eonPathHint_24s949169181x1811404266_lam2_clo)})});
  V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
  V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
  return (g_co_2eop_24s94900133x232571340(v_t_2418, heff_dup(v_hd_242), heff_clo_n(g_heff_2ebuild_2ecommands_2eonPathHint_24s949169181x1811404266_lam3, 1, 5, (V[]){v_x_2411, v_st_240, v_bin_241, v_k_243, v_hd_242})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishCmd_24s850069330x784937902_str0, 10, "package.hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishCmd_24s850069330x784937902_str1, 64, "heff publish: no package.hf here: publish at the project's root\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishCmd_24s850069330x784937902_str2, 10, "package.hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishCmd_24s850069330x784937902_str3, 4, "heff");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishCmd_24s850069330x784937902_str4, 39, "heff publish: package.hf does not read\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishCmd_24s850069330x784937902_str5, 57, "heff publish: package.hf is no Package (lib/manifest.hf)\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishCmd_24s850069330x784937902_str6, 57, "heff publish: package.hf is no Package (lib/manifest.hf)\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishCmd_24s850069330x784937902_str7, 1, "`");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishCmd_24s850069330x784937902_str8, 22, "` is no version: a.b.c");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishCmd_24s850069330x784937902_str9, 14, "heff publish: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishCmd_24s850069330x784937902_str10, 1, "\012");
V g_heff_2ebuild_2ecommands_2epublishCmd_24s850069330x784937902_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2epublishCmd_24s850069330x784937902_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2epublishCmd_24s850069330x784937902_lam1, 1, 0};
V g_heff_2ebuild_2ecommands_2epublishCmd_24s850069330x784937902_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2epublishCmd_24s850069330x784937902_lam8(V self, V *args);
V g_heff_2ebuild_2ecommands_2epublishCmd_24s850069330x784937902_lam9(V self, V *args);
V g_heff_2ebuild_2ecommands_2epublishCmd_24s850069330x784937902_lam10(V self, V *args);
V g_heff_2ebuild_2ecommands_2epublishCmd_24s850069330x784937902_lam7(V self, V *args);
V g_heff_2ebuild_2ecommands_2epublishCmd_24s850069330x784937902_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2epublishCmd_24s850069330x784937902_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2epublishCmd_24s850069330x784937902_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2epublishCmd_24s850069330x784937902_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2epublishCmd_24s850069330x784937902_lam0(V self, V *args);
V g_heff_2ebuild_2ecommands_2epublishCmd_24s850069330x784937902_lam12(V self, V *args);
V g_heff_2ebuild_2ecommands_2epublishCmd_24s850069330x784937902_lam11(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2epublishCmd_24s850069330x784937902_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2epublishCmd_24s850069330x784937902_entry, 1, 0};

V g_heff_2ebuild_2ecommands_2epublishCmd_24s850069330x784937902(V v_v_240) {
top: ;
  HeffT2 v_t_241 = (g_heff_2ebuild_2eproject_2eversion_24cpr(v_v_240));
  {
    V v_field_243 = v_t_241.f[1];
    int64_t v_tag_242 = ((int64_t)v_t_241.f[0]);
    if ((v_tag_242 == ((int64_t)0ULL))) {
      V v_x_245 = v_field_243;
      heff_drop(v_x_245);
      return heff_clo_n(g_heff_2ebuild_2ecommands_2epublishCmd_24s850069330x784937902_lam0, 2, 1, (V[]){v_v_240});
    } else {
      heff_drop(v_field_243);
      return heff_clo_n(g_heff_2ebuild_2ecommands_2epublishCmd_24s850069330x784937902_lam11, 2, 1, (V[]){v_v_240});
    }
  }
}
V g_heff_2ebuild_2ecommands_2epublishCmd_24s850069330x784937902_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2epublishCmd_24s850069330x784937902(a[0]);
}
V g_heff_2ebuild_2ecommands_2epublishCmd_24s850069330x784937902_lam1(V self, V *args) {
  V v_t_248 = args[0];
  return v_t_248;
}
V g_heff_2ebuild_2ecommands_2epublishCmd_24s850069330x784937902_lam3(V self, V *args) {
  V v_x_2421 = args[0];
  V v_hd_246 = heff_env(self)[0];
  V v_k_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2421);
  V v_t_2422 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2422})});
  V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
  V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
  V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
  V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
  return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2427}), v_hd_246, v_k_247));
}
V g_heff_2ebuild_2ecommands_2epublishCmd_24s850069330x784937902_lam8(V self, V *args) {
  V v_x_2443 = args[0];
  V v_hd_246 = heff_env(self)[0];
  V v_k_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2443);
  V v_t_2444 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2445 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2444})});
  V v_t_2446 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2445})});
  V v_t_2447 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2446})});
  V v_t_2448 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2447})});
  V v_t_2449 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2448})});
  return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2449}), v_hd_246, v_k_247));
}
V g_heff_2ebuild_2ecommands_2epublishCmd_24s850069330x784937902_lam9(V self, V *args) {
  V v_x_2458 = args[0];
  V v_hd_246 = heff_env(self)[0];
  V v_k_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2458);
  V v_t_2459 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2460 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2459})});
  V v_t_2461 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2460})});
  V v_t_2462 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2461})});
  V v_t_2463 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2462})});
  V v_t_2464 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2463})});
  return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2464}), v_hd_246, v_k_247));
}
V g_heff_2ebuild_2ecommands_2epublishCmd_24s850069330x784937902_lam10(V self, V *args) {
  V v_x_2472 = args[0];
  V v_hd_246 = heff_env(self)[0];
  V v_k_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2472);
  V v_t_2473 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2474 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2473})});
  V v_t_2475 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2474})});
  V v_t_2476 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2475})});
  V v_t_2477 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2476})});
  V v_t_2478 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2477})});
  return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2478}), v_hd_246, v_k_247));
}
V g_heff_2ebuild_2ecommands_2epublishCmd_24s850069330x784937902_lam7(V self, V *args) {
  V v_x_2435 = args[0];
  V v_x_2430 = heff_env(self)[0];
  V v_hd_246 = heff_env(self)[1];
  V v_k_247 = heff_env(self)[2];
  V v_x_2431 = heff_env(self)[3];
  V v_cs_2434 = heff_env(self)[4];
  V v_v_240 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_2435);
  V v_t_2436 = heff_dup(heff_rfield(v_x_2430, 3));
  switch (heff_tag_of(v_t_2436)) {
  case TAG_Nothing: {
    heff_drop_rec(v_x_2430, 5);
    heff_drop(v_x_2431);
    heff_drop(v_cs_2434);
    heff_drop(v_v_240);
    V v_t_2437 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2epublishCmd_24s850069330x784937902_str4), NTAG(TAG_MkUnit)});
    V v_t_2438 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2437})});
    V v_t_2439 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2438})});
    V v_t_2440 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2439})});
    V v_t_2441 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2440})});
    V v_t_2442 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2441})});
    return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2442}), heff_dup(v_hd_246), heff_clo_n(g_heff_2ebuild_2ecommands_2epublishCmd_24s850069330x784937902_lam8, 1, 2, (V[]){v_hd_246, v_k_247})));
  }
  case TAG_Just: {
    V v_pk_2450 = heff_field(v_t_2436, 0);
    V v_ru_24t_2436_24Just = heff_take_reuse_n(v_t_2436, 1ULL, 1);
    if (heff_intLt_c(MK_INT(0LL), v_x_2431)) {
      heff_drop_rec(v_x_2430, 5);
      heff_drop(v_cs_2434);
      heff_drop(v_v_240);
      heff_drop(v_pk_2450);
      V v_t_2452 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2epublishCmd_24s850069330x784937902_str5), NTAG(TAG_MkUnit)});
      V v_t_2453 = heff_tag_at_n(v_ru_24t_2436_24Just, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2452})});
      V v_t_2454 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2453})});
      V v_t_2455 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2454})});
      V v_t_2456 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2455})});
      V v_t_2457 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2456})});
      return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2457}), heff_dup(v_hd_246), heff_clo_n(g_heff_2ebuild_2ecommands_2epublishCmd_24s850069330x784937902_lam9, 1, 2, (V[]){v_hd_246, v_k_247})));
    } else {
      V v_t_2465 = ({ V a_0 = v_cs_2434; V r_ = (g_list_2eany_24s469495312x865582084(a_0)); heff_drop(v_cs_2434); r_; });
      if ((heff_dup(v_t_2465) == NTAG(TAG_True))) {
        heff_drop_rec(v_x_2430, 5);
        heff_drop(v_v_240);
        heff_drop(v_pk_2450);
        heff_drop(v_t_2465);
        V v_t_2466 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2epublishCmd_24s850069330x784937902_str6), NTAG(TAG_MkUnit)});
        V v_t_2467 = heff_tag_at_n(v_ru_24t_2436_24Just, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2466})});
        V v_t_2468 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2467})});
        V v_t_2469 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2468})});
        V v_t_2470 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2469})});
        V v_t_2471 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2470})});
        return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2471}), heff_dup(v_hd_246), heff_clo_n(g_heff_2ebuild_2ecommands_2epublishCmd_24s850069330x784937902_lam10, 1, 2, (V[]){v_hd_246, v_k_247})));
      } else {
        heff_drop_cell(v_ru_24t_2436_24Just, 1);
        heff_drop(v_t_2465);
        return (g_heff_2ebuild_2ecommands_2epublishChecked_24s2081489637x2129619610(v_v_240, v_x_2430, v_pk_2450, v_hd_246, v_k_247));
      }
    }
  }
  default: return heff_nomatch(v_t_2436);
  }
}
V g_heff_2ebuild_2ecommands_2epublishCmd_24s850069330x784937902_lam6(V self, V *args) {
  V v_x_2433 = args[0];
  V v_hd_246 = heff_env(self)[0];
  V v_x_2430 = heff_env(self)[1];
  V v_k_247 = heff_env(self)[2];
  V v_x_2431 = heff_env(self)[3];
  V v_v_240 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_cs_2434 = heff_get_n(v_x_2433, 0, 2);
  return (g_heff_2ebuild_2ecommands_2eputFileDiags_24s1001351446x35627320(heff_dup(v_cs_2434), heff_dup(v_hd_246), heff_clo_n(g_heff_2ebuild_2ecommands_2epublishCmd_24s850069330x784937902_lam7, 1, 6, (V[]){v_x_2430, v_hd_246, v_k_247, v_x_2431, v_cs_2434, v_v_240})));
}
V g_heff_2ebuild_2ecommands_2epublishCmd_24s850069330x784937902_lam5(V self, V *args) {
  V v_x_2431 = args[0];
  V v_x_2430 = heff_env(self)[0];
  V v_hd_246 = heff_env(self)[1];
  V v_k_247 = heff_env(self)[2];
  V v_v_240 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_c_2432 = (g_heff_2ebuild_2esession_2ecachedAcc_24s52573320x1968432593(heff_dup(v_x_2430)));
  V f_ = v_c_2432;
  heff_room[0] = heff_dup(v_hd_246);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2epublishCmd_24s850069330x784937902_lam6, 1, 5, (V[]){v_hd_246, v_x_2430, v_k_247, v_x_2431, v_v_240});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2epublishCmd_24s850069330x784937902_lam4(V self, V *args) {
  V v_x_2430 = args[0];
  V v_hd_246 = heff_env(self)[0];
  V v_k_247 = heff_env(self)[1];
  V v_v_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2ebuild_2ecommands_2eprintErrs_24s1245252666x1045981980(((V)&g_heff_2ebuild_2ecommands_2epublishCmd_24s850069330x784937902_str3), heff_dup(heff_rfield(v_x_2430, 1)), MK_INT(0LL), heff_dup(v_hd_246), heff_clo_n(g_heff_2ebuild_2ecommands_2epublishCmd_24s850069330x784937902_lam5, 1, 4, (V[]){v_x_2430, v_hd_246, v_k_247, v_v_240})));
}
V g_heff_2ebuild_2ecommands_2epublishCmd_24s850069330x784937902_lam2(V self, V *args) {
  V v_x_2414 = args[0];
  V v_hd_246 = heff_env(self)[0];
  V v_k_247 = heff_env(self)[1];
  V v_v_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_x_2414)) {
  case TAG_Nothing: {
    heff_drop(v_v_240);
    V v_t_2415 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2epublishCmd_24s850069330x784937902_str1), NTAG(TAG_MkUnit)});
    V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
    V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
    V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
    V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
    V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
    return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2420}), heff_dup(v_hd_246), heff_clo_n(g_heff_2ebuild_2ecommands_2epublishCmd_24s850069330x784937902_lam3, 1, 2, (V[]){v_hd_246, v_k_247})));
  }
  case TAG_Just: {
    heff_take_n(v_x_2414, 0ULL, 1);
    V v_c_2429 = (g_heff_2ebuild_2ecommands_2eload_24s1185299161x1866120155(((V)&g_heff_2ebuild_2ecommands_2epublishCmd_24s850069330x784937902_str2)));
    V f_ = v_c_2429;
    heff_room[0] = heff_dup(v_hd_246);
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2epublishCmd_24s850069330x784937902_lam4, 1, 3, (V[]){v_hd_246, v_k_247, v_v_240});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_x_2414);
  }
}
V g_heff_2ebuild_2ecommands_2epublishCmd_24s850069330x784937902_lam0(V self, V *args) {
  V v_hd_246 = args[0];
  V v_k_247 = args[1];
  V v_v_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_249 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2epublishCmd_24s850069330x784937902_str0), ((V)&g_heff_2ebuild_2ecommands_2epublishCmd_24s850069330x784937902_lam1_clo)})});
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
  return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2413}), heff_dup(v_hd_246), heff_clo_n(g_heff_2ebuild_2ecommands_2epublishCmd_24s850069330x784937902_lam2, 1, 3, (V[]){v_hd_246, v_k_247, v_v_240})));
}
V g_heff_2ebuild_2ecommands_2epublishCmd_24s850069330x784937902_lam12(V self, V *args) {
  V v_x_2489 = args[0];
  V v_hd_2479 = heff_env(self)[0];
  V v_k_2480 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2489);
  V v_t_2490 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2491 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2490})});
  V v_t_2492 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2491})});
  V v_t_2493 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2492})});
  V v_t_2494 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2493})});
  V v_t_2495 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2494})});
  return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2495}), v_hd_2479, v_k_2480));
}
V g_heff_2ebuild_2ecommands_2epublishCmd_24s850069330x784937902_lam11(V self, V *args) {
  V v_hd_2479 = args[0];
  V v_k_2480 = args[1];
  V v_v_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2481 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2epublishCmd_24s850069330x784937902_str7), heff_strAppend(v_v_240, ((V)&g_heff_2ebuild_2ecommands_2epublishCmd_24s850069330x784937902_str8)));
  V v_t_2482 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2epublishCmd_24s850069330x784937902_str9), v_t_2481), ((V)&g_heff_2ebuild_2ecommands_2epublishCmd_24s850069330x784937902_str10));
  V v_t_2483 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2482, NTAG(TAG_MkUnit)});
  V v_t_2484 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2483})});
  V v_t_2485 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2484})});
  V v_t_2486 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2485})});
  V v_t_2487 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2486})});
  V v_t_2488 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2487})});
  return (g_co_2eop_24s94900133x232571340(heff_tag_n(TAG_InR, 1, (V[]){v_t_2488}), heff_dup(v_hd_2479), heff_clo_n(g_heff_2ebuild_2ecommands_2epublishCmd_24s850069330x784937902_lam12, 1, 2, (V[]){v_hd_2479, v_k_2480})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprintDefs_24s1027896891x952770906_str0, 1, " ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprintDefs_24s1027896891x952770906_str1, 6, "=body ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprintDefs_24s1027896891x952770906_str2, 4, "=ty ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprintDefs_24s1027896891x952770906_str3, 5, "=def ");
V g_heff_2ebuild_2ecommands_2eprintDefs_24s1027896891x952770906_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eprintDefs_24s1027896891x952770906_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eprintDefs_24s1027896891x952770906_lam0, 2, 0};
V g_heff_2ebuild_2ecommands_2eprintDefs_24s1027896891x952770906_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2eprintDefs_24s1027896891x952770906_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eprintDefs_24s1027896891x952770906_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eprintDefs_24s1027896891x952770906_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2eprintDefs_24s1027896891x952770906(V v_c_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop_rec(v_c_240, 14);
    return ((V)&g_heff_2ebuild_2ecommands_2eprintDefs_24s1027896891x952770906_lam0_clo);
  }
  case TAG_Cons: {
    V v_k_244 = heff_field(v_x2_241, 0);
    V v_rest_245 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_246 = (g_heff_2ebuild_2edriver_2edefKind(heff_dup(v_c_240), v_k_244));
    V v_t_247 = heff_strAppend(heff_dup(v_k_244), heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eprintDefs_24s1027896891x952770906_str0), v_t_246));
    V v_t_248 = (g_heff_2eelab_2etoplevel_2etyDump(heff_dup(heff_rfield(v_c_240, 5)), v_k_244));
    V v_t_249 = ({ V a_0 = heff_dup(heff_rfield(v_c_240, 5)); V a_1 = v_k_244; V r_ = (g_heff_2eelab_2etoplevel_2ebodyDump(a_0, a_1)); heff_drop(v_k_244); r_; });
    V v_t_2410 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eprintDefs_24s1027896891x952770906_str1), v_t_249), NTAG(TAG_Nil)});
    V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eprintDefs_24s1027896891x952770906_str2), v_t_248), v_t_2410});
    V v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eprintDefs_24s1027896891x952770906_str3), v_t_247), v_t_2411});
    return heff_clo_n(g_heff_2ebuild_2ecommands_2eprintDefs_24s1027896891x952770906_lam1, 2, 3, (V[]){v_t_2412, v_c_240, v_rest_245});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2ecommands_2eprintDefs_24s1027896891x952770906_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eprintDefs_24s1027896891x952770906(a[0], a[1]);
}
V g_heff_2ebuild_2ecommands_2eprintDefs_24s1027896891x952770906_lam0(V self, V *args) {
  V v_hd_242 = args[0];
  V v_k_243 = args[1];
  heff_drop(v_hd_242);
  V f_ = v_k_243;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eprintDefs_24s1027896891x952770906_lam2(V self, V *args) {
  V v_x_2415 = args[0];
  V v_c_240 = heff_env(self)[0];
  V v_rest_245 = heff_env(self)[1];
  V v_hd_2413 = heff_env(self)[2];
  V v_k_2414 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2415);
  V v_t_2416 = (g_heff_2ebuild_2ecommands_2eprintDefs_24s1027896891x952770906(v_c_240, v_rest_245));
  V f_ = v_t_2416;
  heff_room[0] = v_hd_2413;
  heff_room[1] = v_k_2414;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2eprintDefs_24s1027896891x952770906_lam1(V self, V *args) {
  V v_hd_2413 = args[0];
  V v_k_2414 = args[1];
  V v_t_2412 = heff_env(self)[0];
  V v_c_240 = heff_env(self)[1];
  V v_rest_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2ebuild_2ecommands_2eprintLines_24s1721756835x860488624(v_t_2412, heff_dup(v_hd_2413), heff_clo_n(g_heff_2ebuild_2ecommands_2eprintDefs_24s1027896891x952770906_lam2, 1, 4, (V[]){v_c_240, v_rest_245, v_hd_2413, v_k_2414})));
}