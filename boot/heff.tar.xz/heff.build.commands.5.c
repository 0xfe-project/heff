// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Catch 6517
#define TAG_Collected 38917
#define TAG_Exit 20279
#define TAG_Exited 20560
#define TAG_MakeDirectory 16793
#define TAG_NoInput 41055
#define TAG_NotRun 12703
#define TAG_ReadFile 6783
#define TAG_Remove 9747
#define TAG_Run 29975
#define TAG_Signalled 34337
#define TAG_TimedOut 6056
#define TAG_Write 36323
#define TAG_WriteErr 37283
#define TAG_WriteFile 62589
#define LBL_args 9498020
#define LBL_backend 2032133329
#define LBL_command 1182252425
#define LBL_diags 296935042
#define LBL_dir 308999
#define LBL_ended 298010324
#define LBL_env 310119
#define LBL_err 310239
#define LBL_errors 652506774
#define LBL_file 9638467
#define LBL_group 299987609
#define LBL_input 301716452
#define LBL_keep 9783372
#define LBL_launch 837298910
#define LBL_limit 304334805
#define LBL_message 1186782793
#define LBL_msg 317947
#define LBL_name 9869138
#define LBL_outPath 1272254166
#define LBL_output 941629484
#define LBL_path 9928940
#define LBL_program 2069953735
#define LBL_source 1050636102
#define LBL_style 311138763
#define LBL_timeout 1065429926
#define LBL_top 324559
static uint32_t shape_command__args__dir__env__input__output__errors__timeout__keep__group[] = {LBL_command, LBL_args, LBL_dir, LBL_env, LBL_input, LBL_output, LBL_errors, LBL_timeout, LBL_keep, LBL_group};
V g_co_2eop_24s22628809x1035315751(V, V, V);
V g_co_2eop_24s22628809x1035315751_entry(V self, V *a);
extern Clo g_co_2eop_24s22628809x1035315751_clo;
V g_co_2eop_24s495635622x733177935(V, V, V);
V g_co_2eop_24s495635622x733177935_entry(V self, V *a);
extern Clo g_co_2eop_24s495635622x733177935_clo;
V g_heff_2ebuild_2ecommands_2ebackDirOf(V);
V g_heff_2ebuild_2ecommands_2ebackDirOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ebackDirOf_clo;
V g_heff_2ebuild_2ecommands_2ebrokenJob(V, V);
V g_heff_2ebuild_2ecommands_2ebrokenJob_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ebrokenJob_clo;
V g_heff_2ebuild_2ecommands_2ecCmd_24s1380603959x1786853260(V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecCmd_24s1380603959x1786853260_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecCmd_24s1380603959x1786853260_clo;
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s973409408x145459240(V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s973409408x145459240_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecLoadedOr_24s973409408x145459240_clo;
V g_heff_2ebuild_2ecommands_2ecompileJsCmd_24s384209754x1519830833(V, V, V);
V g_heff_2ebuild_2ecommands_2ecompileJsCmd_24s384209754x1519830833_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecompileJsCmd_24s384209754x1519830833_clo;
V g_heff_2ebuild_2ecommands_2ecompileThen_24s1650899649x955695485(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecompileThen_24s1650899649x955695485_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecompileThen_24s1650899649x955695485_clo;
V g_heff_2ebuild_2ecommands_2ecompileTo_24s1473691404x176248689(V, V);
V g_heff_2ebuild_2ecommands_2ecompileTo_24s1473691404x176248689_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecompileTo_24s1473691404x176248689_clo;
V g_heff_2ebuild_2ecommands_2eemitErrs_24s490470139x1613762483(V, V, V);
V g_heff_2ebuild_2ecommands_2eemitErrs_24s490470139x1613762483_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eemitErrs_24s490470139x1613762483_clo;
V g_heff_2ebuild_2ecommands_2eendedJob_24s463009106x949099021(V, V, V, V);
V g_heff_2ebuild_2ecommands_2eendedJob_24s463009106x949099021_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eendedJob_24s463009106x949099021_clo;
V g_heff_2ebuild_2ecommands_2eexpectErrorsLine_get(void);
HeffT2 g_heff_2ebuild_2ecommands_2efirstErrorOf_24cpr(V);
V g_heff_2ebuild_2ecommands_2egoldenByte(V);
V g_heff_2ebuild_2ecommands_2egoldenByte_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2egoldenByte_clo;
V g_heff_2ebuild_2ecommands_2eload_24s81450283x65507788(V);
V g_heff_2ebuild_2ecommands_2eload_24s81450283x65507788_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eload_24s81450283x65507788_clo;
V g_heff_2ebuild_2ecommands_2eoutcomeVariable_get(void);
V g_heff_2ebuild_2ecommands_2eprintDefs_24s1608636047x342860471(V, V);
V g_heff_2ebuild_2ecommands_2eprintDefs_24s1608636047x342860471_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprintDefs_24s1608636047x342860471_clo;
V g_heff_2ebuild_2ecommands_2eprintLines_24s1090954299x687958379(V, V, V);
V g_heff_2ebuild_2ecommands_2eprintLines_24s1090954299x687958379_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprintLines_24s1090954299x687958379_clo;
V g_heff_2ebuild_2ecommands_2eranJob_24s2120574948x1389646626(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eranJob_24s2120574948x1389646626_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eranJob_24s2120574948x1389646626_clo;
V g_heff_2ebuild_2ecommands_2eselfKept_24s126803802x1878561567(V, V, V);
V g_heff_2ebuild_2ecommands_2eselfKept_24s126803802x1878561567_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eselfKept_24s126803802x1878561567_clo;
HeffT2 g_heff_2ebuild_2ecommands_2especOf_24cpr(V);
V g_heff_2ebuild_2ecommands_2etagCloned_24s1645425458x565956513(V, V, V);
V g_heff_2ebuild_2ecommands_2etagCloned_24s1645425458x565956513_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2etagCloned_24s1645425458x565956513_clo;
V g_heff_2ebuild_2ecommands_2etestLoaded_24s1989817941x949950035(V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2etestLoaded_24s1989817941x949950035_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2etestLoaded_24s1989817941x949950035_clo;
V g_heff_2ebuild_2ecommands_2etestOneF_24s1086098612x175366387(V, V, V);
V g_heff_2ebuild_2ecommands_2etestOneF_24s1086098612x175366387_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2etestOneF_24s1086098612x175366387_clo;
V g_heff_2ebuild_2ecommands_2ewriteOut_24s984604337x632550343(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ewriteOut_24s984604337x632550343_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ewriteOut_24s984604337x632550343_clo;
V g_heff_2ebuild_2ecommands_2ewriteWhole_24s312410197x1422325592(V, V);
V g_heff_2ebuild_2ecommands_2ewriteWhole_24s312410197x1422325592_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ewriteWhole_24s312410197x1422325592_clo;
V g_heff_2ebuild_2ecommands_2ezigOf(V);
V g_heff_2ebuild_2ecommands_2ezigOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ezigOf_clo;
V g_heff_2ebuild_2edriver_2edefKind(V, V);
V g_heff_2ebuild_2edriver_2edefKind_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2edefKind_clo;
V g_heff_2ebuild_2eproject_2erepoOf(V);
V g_heff_2ebuild_2eproject_2erepoOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2erepoOf_clo;
V g_heff_2eelab_2etoplevel_2ebodyDump(V, V);
V g_heff_2eelab_2etoplevel_2ebodyDump_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2ebodyDump_clo;
V g_heff_2eelab_2etoplevel_2etyDump(V, V);
V g_heff_2eelab_2etoplevel_2etyDump_entry(V self, V *a);
extern Clo g_heff_2eelab_2etoplevel_2etyDump_clo;
V g_heff_2elsp_2erender_2ediagWhere(V, V, V);
V g_heff_2elsp_2erender_2ediagWhere_entry(V self, V *a);
extern Clo g_heff_2elsp_2erender_2ediagWhere_clo;
V g_heff_2elsp_2erender_2eprtCode(V);
V g_heff_2elsp_2erender_2eprtCode_entry(V self, V *a);
extern Clo g_heff_2elsp_2erender_2eprtCode_clo;
V g_list_2ekeepIf_24s1161549307x1906011635(V);
V g_list_2ekeepIf_24s1161549307x1906011635_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1161549307x1906011635_clo;
V g_prelude_2eskipSpaces(V, V, V);
V g_prelude_2eskipSpaces_entry(V self, V *a);
extern Clo g_prelude_2eskipSpaces_clo;
V g_prelude_2esplitFrom(V, V, V, V, V);
V g_prelude_2esplitFrom_entry(V self, V *a);
extern Clo g_prelude_2esplitFrom_clo;
V g_std_2epath_2ecurrent_get(void);
V g_std_2epath_2ejoin(V, V);
V g_std_2epath_2ejoin_entry(V self, V *a);
extern Clo g_std_2epath_2ejoin_clo;
V g_std_2epath_2enative_get(void);
V g_std_2epath_2eparse(V, V);
V g_std_2epath_2eparse_entry(V self, V *a);
extern Clo g_std_2epath_2eparse_clo;
V g_std_2epath_2erender(V, V);
V g_std_2epath_2erender_entry(V self, V *a);
extern Clo g_std_2epath_2erender_clo;
V g_std_2epath_2esameSegments(V, V);
V g_std_2epath_2esameSegments_entry(V self, V *a);
extern Clo g_std_2epath_2esameSegments_clo;
V g_std_2eprocess_2ewithProcess_24s461807610x1567722616(V, V);
V g_std_2eprocess_2ewithProcess_24s461807610x1567722616_entry(V self, V *a);
extern Clo g_std_2eprocess_2ewithProcess_24s461807610x1567722616_clo;
HEFF_LIT(g_heff_2ebuild_2ecommands_2efirstErrorOf_24cpr_str0, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efirstErrorOf_24cpr_str1, 2, ": ");

HeffT2 g_heff_2ebuild_2ecommands_2efirstErrorOf_24cpr(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_c_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 3ULL, 2);
    V v_x2_243 = (g_list_2ekeepIf_24s1161549307x1906011635(heff_take_field(v_c_241, 6)));
    switch (heff_tag_of(v_x2_243)) {
    case TAG_Nil: {
      heff_drop_rec(v_c_241, 14);
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Cons: {
      V v_d_244 = heff_field(v_x2_243, 0);
      heff_take_n(v_x2_243, 1ULL, 2);
      heff_drop(v_rest_242);
      V v_t_246 = ({ V a_0 = heff_take_field(v_c_241, 1); V b_1 = heff_get_n(v_c_241, 3, 14); V a_2 = heff_dup(v_d_244); V r_ = (g_heff_2elsp_2erender_2ediagWhere(a_0, b_1, a_2)); heff_drop(b_1); r_; });
      V v_t_247 = (g_heff_2elsp_2erender_2eprtCode(heff_dup(v_d_244)));
      V v_t_248 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efirstErrorOf_24cpr_str0), heff_get_n(v_d_244, 2, 5));
      V v_t_249 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efirstErrorOf_24cpr_str1), heff_strAppend(v_t_247, v_t_248));
      V v_why_2410 = heff_strAppend(v_t_246, v_t_249);
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_why_2410}});
    }
    default: return ((HeffT2){{heff_nomatch(v_x2_243)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
Clo g_heff_2ebuild_2ecommands_2egoldenByte_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2egoldenByte_entry, 1, 0};

V g_heff_2ebuild_2ecommands_2egoldenByte(V v_box_24c_240) {
  int64_t v_c_240 = heff_unbox_word(v_box_24c_240);
top: ;
  V v_t_242 = heff_bool(((((int64_t)48ULL) <= v_c_240) && (v_c_240 <= ((int64_t)57ULL))));
  V v_ret_24bool = heff_bool(((heff_dup(v_t_242) == NTAG(TAG_True)) || ((((int64_t)65ULL) <= v_c_240) ? ((v_c_240 <= ((int64_t)90ULL)) || ((((int64_t)97ULL) <= v_c_240) ? ((v_c_240 <= ((int64_t)122ULL)) || ((v_c_240 == ((int64_t)45ULL)) || ((v_c_240 == ((int64_t)95ULL)) || (v_c_240 == ((int64_t)46ULL))))) : ((v_c_240 == ((int64_t)45ULL)) || ((v_c_240 == ((int64_t)95ULL)) || (v_c_240 == ((int64_t)46ULL)))))) : ((((int64_t)97ULL) <= v_c_240) ? (heff_intLe_c(heff_box_word(v_c_240), MK_INT(122LL)) || (heff_intEq_c(heff_box_word(v_c_240), MK_INT(45LL)) || (heff_intEq_c(heff_box_word(v_c_240), MK_INT(95LL)) || heff_intEq_c(heff_box_word(v_c_240), MK_INT(46LL))))) : ((v_c_240 == ((int64_t)45ULL)) || ((v_c_240 == ((int64_t)95ULL)) || (v_c_240 == ((int64_t)46ULL))))))));
  heff_drop(v_t_242);
  return v_ret_24bool;
}
V g_heff_2ebuild_2ecommands_2egoldenByte_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2egoldenByte(a[0]);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2especOf_24cpr_str0, 1, "@");
HEFF_LIT(g_heff_2ebuild_2ecommands_2especOf_24cpr_str1, 1, "@");

HeffT2 g_heff_2ebuild_2ecommands_2especOf_24cpr(V v_spec_240) {
top: ;
  V v_it_241 = ({ V b_0 = ((V)&g_heff_2ebuild_2ecommands_2especOf_24cpr_str0); V a_1 = v_spec_240; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2ecommands_2especOf_24cpr_str1), v_spec_240, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
  switch (heff_tag_of(v_it_241)) {
  case TAG_Nil: {
    return ((HeffT2){{v_spec_240, NTAG(TAG_Nothing)}});
  }
  case TAG_Cons: {
    V v_path_242 = heff_field(v_it_241, 0);
    V v_it2_243 = heff_field(v_it_241, 1);
    heff_take_n(v_it_241, 3ULL, 2);
    switch (heff_tag_of(v_it2_243)) {
    case TAG_Nil: {
      heff_drop(v_path_242);
      return ((HeffT2){{v_spec_240, NTAG(TAG_Nothing)}});
    }
    case TAG_Cons: {
      V v_v_244 = heff_field(v_it2_243, 0);
      V v_it22_245 = heff_field(v_it2_243, 1);
      heff_take_n(v_it2_243, 3ULL, 2);
      switch (heff_tag_of(v_it22_245)) {
      case TAG_Nil: {
        heff_drop(v_spec_240);
        return ((HeffT2){{v_path_242, heff_tag_n(TAG_Just, 1, (V[]){v_v_244})}});
      }
      case TAG_Cons: {
        heff_take_n(v_it22_245, 0ULL, 2);
        heff_drop(v_path_242);
        heff_drop(v_v_244);
        return ((HeffT2){{v_spec_240, NTAG(TAG_Nothing)}});
      }
      default: return ((HeffT2){{heff_nomatch(v_it22_245)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_it2_243)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_it_241)}});
  }
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eselfKept_24s126803802x1878561567_str0, 8, "compiler");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eselfKept_24s126803802x1878561567_str1, 1, "\012");
V g_heff_2ebuild_2ecommands_2eselfKept_24s126803802x1878561567_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eselfKept_24s126803802x1878561567_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eselfKept_24s126803802x1878561567_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2eselfKept_24s126803802x1878561567_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2eselfKept_24s126803802x1878561567_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2eselfKept_24s126803802x1878561567_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eselfKept_24s126803802x1878561567_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eselfKept_24s126803802x1878561567_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2eselfKept_24s126803802x1878561567(V v_ps_240, V v_b_241, V v_id_242) {
top: ;
  V v_s_243 = (g_heff_2ebuild_2ecommands_2ebackDirOf(heff_dup(v_ps_240)));
  V v_path_244 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_s_243; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
  V v_t_245 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_244; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_244); r_; });
  V v_a_247 = heff_tag_n(TAG_MakeDirectory, 2, (V[]){v_t_245, ((V)&g_heff_2ebuild_2ecommands_2eselfKept_24s126803802x1878561567_lam0_clo)});
  return heff_clo_n(g_heff_2ebuild_2ecommands_2eselfKept_24s126803802x1878561567_lam1, 2, 4, (V[]){v_a_247, v_ps_240, v_id_242, v_b_241});
}
V g_heff_2ebuild_2ecommands_2eselfKept_24s126803802x1878561567_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eselfKept_24s126803802x1878561567(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2ecommands_2eselfKept_24s126803802x1878561567_lam0(V self, V *args) {
  V v_ok_246 = args[0];
  return v_ok_246;
}
V g_heff_2ebuild_2ecommands_2eselfKept_24s126803802x1878561567_lam3(V self, V *args) {
  V v_x_2425 = args[0];
  V v_k_249 = heff_env(self)[0];
  V v_id_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2425);
  V f_ = v_k_249;
  args[0] = v_id_242;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eselfKept_24s126803802x1878561567_lam2(V self, V *args) {
  V v_x_2416 = args[0];
  V v_ps_240 = heff_env(self)[0];
  V v_id_242 = heff_env(self)[1];
  V v_b_241 = heff_env(self)[2];
  V v_hd_248 = heff_env(self)[3];
  V v_k_249 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2416);
  V v_d_2417 = (g_heff_2ebuild_2ecommands_2ebackDirOf(heff_dup(v_ps_240)));
  V v_st_2418 = heff_get_n(v_ps_240, 5, 6);
  V v_t_2419 = (g_std_2epath_2eparse(v_st_2418, v_d_2417));
  V v_t_2420 = (g_std_2epath_2eparse(v_st_2418, ((V)&g_heff_2ebuild_2ecommands_2eselfKept_24s126803802x1878561567_str0)));
  V v_t_2421 = (g_std_2epath_2ejoin(v_t_2419, v_t_2420));
  V v_t_2422 = ({ V a_0 = v_st_2418; V a_1 = v_t_2421; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2418); heff_drop(v_t_2421); r_; });
  V v_t_2423 = heff_strAppend(heff_dup(v_id_242), heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eselfKept_24s126803802x1878561567_str1), v_b_241));
  V v_c_2424 = (g_heff_2ebuild_2ecommands_2ewriteWhole_24s312410197x1422325592(v_t_2422, v_t_2423));
  V f_ = v_c_2424;
  heff_room[0] = v_hd_248;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2eselfKept_24s126803802x1878561567_lam3, 1, 2, (V[]){v_k_249, v_id_242});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2eselfKept_24s126803802x1878561567_lam1(V self, V *args) {
  V v_hd_248 = args[0];
  V v_k_249 = args[1];
  V v_a_247 = heff_env(self)[0];
  V v_ps_240 = heff_env(self)[1];
  V v_id_242 = heff_env(self)[2];
  V v_b_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_247})});
  V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
  V v_t_2414 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
  V v_t_2415 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2414})});
  return (g_co_2eop_24s495635622x733177935(v_t_2415, heff_dup(v_hd_248), heff_clo_n(g_heff_2ebuild_2ecommands_2eselfKept_24s126803802x1878561567_lam2, 1, 5, (V[]){v_ps_240, v_id_242, v_b_241, v_hd_248, v_k_249})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ewriteOut_24s984604337x632550343_str0, 13, "cannot write ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ewriteOut_24s984604337x632550343_str1, 1, "\012");
V g_heff_2ebuild_2ecommands_2ewriteOut_24s984604337x632550343_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ewriteOut_24s984604337x632550343_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewriteOut_24s984604337x632550343_lam1, 1, 0};
V g_heff_2ebuild_2ecommands_2ewriteOut_24s984604337x632550343_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ewriteOut_24s984604337x632550343_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ewriteOut_24s984604337x632550343_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ewriteOut_24s984604337x632550343_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewriteOut_24s984604337x632550343_entry, 5, 0};

V g_heff_2ebuild_2ecommands_2ewriteOut_24s984604337x632550343(V v_outPath_240, V v_done_241, V v_o_242, V v_hd_243, V v_k_244) {
top: ;
  return (g_heff_2ebuild_2ecommands_2eemitErrs_24s490470139x1613762483(heff_dup(heff_rfield(v_o_242, 1)), heff_dup(v_hd_243), heff_clo_n(g_heff_2ebuild_2ecommands_2ewriteOut_24s984604337x632550343_lam0, 1, 5, (V[]){v_o_242, v_outPath_240, v_hd_243, v_done_241, v_k_244})));
}
V g_heff_2ebuild_2ecommands_2ewriteOut_24s984604337x632550343_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ewriteOut_24s984604337x632550343(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ebuild_2ecommands_2ewriteOut_24s984604337x632550343_lam1(V self, V *args) {
  V v_ok_249 = args[0];
  return v_ok_249;
}
V g_heff_2ebuild_2ecommands_2ewriteOut_24s984604337x632550343_lam3(V self, V *args) {
  V v_x_2426 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_k_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2426);
  V v_t_2427 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2427})});
  V v_t_2429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
  V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
  V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
  V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
  V v_t_2433 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2432})});
  return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2433}), v_hd_243, v_k_244));
}
V g_heff_2ebuild_2ecommands_2ewriteOut_24s984604337x632550343_lam2(V self, V *args) {
  V v_x_2417 = args[0];
  V v_done_241 = heff_env(self)[0];
  V v_hd_243 = heff_env(self)[1];
  V v_k_244 = heff_env(self)[2];
  V v_outPath_240 = heff_env(self)[3];
  heff_clo_take(self, 4);
  if ((heff_dup(v_x_2417) == NTAG(TAG_True))) {
    heff_drop(v_x_2417);
    heff_drop(v_outPath_240);
    V f_ = v_done_241;
    heff_room[0] = v_hd_243;
    heff_room[1] = v_k_244;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    heff_drop(v_x_2417);
    heff_drop(v_done_241);
    V v_t_2418 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ewriteOut_24s984604337x632550343_str0), v_outPath_240), ((V)&g_heff_2ebuild_2ecommands_2ewriteOut_24s984604337x632550343_str1));
    V v_t_2419 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2418, NTAG(TAG_MkUnit)});
    V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
    V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
    V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
    V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
    V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
    V v_t_2425 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2424})});
    return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2425}), heff_dup(v_hd_243), heff_clo_n(g_heff_2ebuild_2ecommands_2ewriteOut_24s984604337x632550343_lam3, 1, 2, (V[]){v_hd_243, v_k_244})));
  }
}
V g_heff_2ebuild_2ecommands_2ewriteOut_24s984604337x632550343_lam0(V self, V *args) {
  V v_x_245 = args[0];
  V v_o_242 = heff_env(self)[0];
  V v_outPath_240 = heff_env(self)[1];
  V v_hd_243 = heff_env(self)[2];
  V v_done_241 = heff_env(self)[3];
  V v_k_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_245);
  V v_t_246 = heff_take_field(v_o_242, 1);
  switch (heff_tag_of(v_t_246)) {
  case TAG_Nil: {
    V v_path_247 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = heff_dup(v_outPath_240); V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
    V v_t_248 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_247; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_247); r_; });
    V v_a_2410 = heff_tag_n(TAG_WriteFile, 3, (V[]){v_t_248, heff_get_n(v_o_242, 0, 2), ((V)&g_heff_2ebuild_2ecommands_2ewriteOut_24s984604337x632550343_lam1_clo)});
    V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2410})});
    V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
    V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
    V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
    V v_t_2415 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
    V v_t_2416 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2415})});
    return (g_co_2eop_24s495635622x733177935(v_t_2416, heff_dup(v_hd_243), heff_clo_n(g_heff_2ebuild_2ecommands_2ewriteOut_24s984604337x632550343_lam2, 1, 4, (V[]){v_done_241, v_hd_243, v_k_244, v_outPath_240})));
  }
  case TAG_Cons: {
    V v_ru_24t_246_24Cons = heff_take_reuse_n(v_t_246, 0ULL, 2);
    heff_drop_rec(v_o_242, 2);
    heff_drop(v_outPath_240);
    heff_drop(v_done_241);
    V v_t_2436 = heff_tag_at_n(v_ru_24t_246_24Cons, TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
    V v_t_2437 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2436})});
    V v_t_2438 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2437})});
    V v_t_2439 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2438})});
    V v_t_2440 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2439})});
    V v_t_2441 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2440})});
    V v_t_2442 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2441})});
    return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2442}), v_hd_243, v_k_244));
  }
  default: return heff_nomatch(v_t_246);
  }
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eranJob_24s2120574948x1389646626_str0, 8, ".outcome");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eranJob_24s2120574948x1389646626_str1, 30, "its program could not be run: ");
V g_heff_2ebuild_2ecommands_2eranJob_24s2120574948x1389646626_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2eranJob_24s2120574948x1389646626_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2eranJob_24s2120574948x1389646626_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2eranJob_24s2120574948x1389646626_lam0(V self, V *args);
V g_heff_2ebuild_2ecommands_2eranJob_24s2120574948x1389646626_lam5(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eranJob_24s2120574948x1389646626_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eranJob_24s2120574948x1389646626_lam5, 1, 0};
V g_heff_2ebuild_2ecommands_2eranJob_24s2120574948x1389646626_lam8(V self, V *args);
V g_heff_2ebuild_2ecommands_2eranJob_24s2120574948x1389646626_lam7(V self, V *args);
V g_heff_2ebuild_2ecommands_2eranJob_24s2120574948x1389646626_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2eranJob_24s2120574948x1389646626_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2eranJob_24s2120574948x1389646626_lam9(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eranJob_24s2120574948x1389646626_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eranJob_24s2120574948x1389646626_entry, 6, 0};

V g_heff_2ebuild_2ecommands_2eranJob_24s2120574948x1389646626(V v_ex_240, V v_sel_241, V v_j_242, V v_dir_243, V v_z_244, V v_z_245) {
top: ;
  V v_t_246 = heff_get_n(heff_dup(heff_rfield(v_j_242, 1)), 0, 2);
  V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(heff_rfield(v_j_242, 3)), heff_dup(heff_rfield(v_j_242, 4))});
  V v_t_248 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = heff_dup(v_dir_243); V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
  V v_t_249 = heff_tag_n(TAG_MkPair, 2, (V[]){heff_dup(g_heff_2ebuild_2ecommands_2eoutcomeVariable_get()), heff_strAppend(heff_dup(v_dir_243), ((V)&g_heff_2ebuild_2ecommands_2eranJob_24s2120574948x1389646626_str0))});
  V v_t_2410 = heff_get_n(heff_dup(heff_rfield(v_j_242, 1)), 1, 2);
  V v_t_2411 = heff_rec_n(10, shape_command__args__dir__env__input__output__errors__timeout__keep__group, (V[]){v_t_246, v_t_247, v_t_248, heff_tag_n(TAG_Cons, 2, (V[]){v_t_249, v_t_2410}), NTAG(TAG_NoInput), NTAG(TAG_Collected), NTAG(TAG_Collected), heff_dup(heff_rfield(v_j_242, 5)), MK_INT(0LL), NTAG(TAG_True)});
  V v_c_2412 = (g_std_2eprocess_2ewithProcess_24s461807610x1567722616(heff_dup(v_ex_240), v_t_2411));
  V v_t_2440 = heff_tr(heff_call(v_ex_240, 1, (V[]){heff_tag_n(TAG_Catch, 2, (V[]){heff_clo_n(g_heff_2ebuild_2ecommands_2eranJob_24s2120574948x1389646626_lam0, 2, 4, (V[]){v_c_2412, heff_dup(v_sel_241), heff_dup(v_j_242), heff_dup(v_dir_243)}), heff_clo_n(g_heff_2ebuild_2ecommands_2eranJob_24s2120574948x1389646626_lam4, 1, 2, (V[]){v_dir_243, v_j_242})})}));
  return (g_co_2eop_24s495635622x733177935(v_t_2440, heff_dup(v_z_244), heff_clo_n(g_heff_2ebuild_2ecommands_2eranJob_24s2120574948x1389646626_lam9, 1, 2, (V[]){v_z_244, v_z_245})));
}
V g_heff_2ebuild_2ecommands_2eranJob_24s2120574948x1389646626_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2ecommands_2eranJob_24s2120574948x1389646626(a[0], a1, a[2], a[3], a[4], a[5]); heff_drop(a1); return r;
}
V g_heff_2ebuild_2ecommands_2eranJob_24s2120574948x1389646626_lam3(V self, V *args) {
  V v_x_2418 = args[0];
  V v_hd_2419 = args[1];
  V v_k_2420 = args[2];
  V v_x_2417 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2418);
  heff_drop(v_hd_2419);
  V f_ = v_k_2420;
  args[0] = v_x_2417;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eranJob_24s2120574948x1389646626_lam2(V self, V *args) {
  V v_x_2417 = args[0];
  V v_k_2414 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_2414;
  args[0] = heff_clo_n(g_heff_2ebuild_2ecommands_2eranJob_24s2120574948x1389646626_lam3, 3, 1, (V[]){v_x_2417});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eranJob_24s2120574948x1389646626_lam1(V self, V *args) {
  V v_x_2415 = args[0];
  V v_sel_241 = heff_env(self)[0];
  V v_j_242 = heff_env(self)[1];
  V v_dir_243 = heff_env(self)[2];
  V v_hd_2413 = heff_env(self)[3];
  V v_k_2414 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_c_2416 = ({ V a_0 = v_sel_241; V a_1 = v_j_242; V a_2 = v_dir_243; V a_3 = v_x_2415; V r_ = (g_heff_2ebuild_2ecommands_2eendedJob_24s463009106x949099021(a_0, a_1, a_2, a_3)); heff_drop(v_sel_241); r_; });
  V f_ = v_c_2416;
  heff_room[0] = v_hd_2413;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2eranJob_24s2120574948x1389646626_lam2, 1, 1, (V[]){v_k_2414});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2eranJob_24s2120574948x1389646626_lam0(V self, V *args) {
  V v_hd_2413 = args[0];
  V v_k_2414 = args[1];
  V v_c_2412 = heff_env(self)[0];
  V v_sel_241 = heff_env(self)[1];
  V v_j_242 = heff_env(self)[2];
  V v_dir_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_2412;
  args[0] = heff_dup(v_hd_2413);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2eranJob_24s2120574948x1389646626_lam1, 1, 5, (V[]){v_sel_241, v_j_242, v_dir_243, v_hd_2413, v_k_2414});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2ecommands_2eranJob_24s2120574948x1389646626_lam5(V self, V *args) {
  V v_ok_2424 = args[0];
  return v_ok_2424;
}
V g_heff_2ebuild_2ecommands_2eranJob_24s2120574948x1389646626_lam8(V self, V *args) {
  V v_x_2437 = args[0];
  V v_hd_2438 = args[1];
  V v_k_2439 = args[2];
  V v_x_2436 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2437);
  heff_drop(v_hd_2438);
  V f_ = v_k_2439;
  args[0] = v_x_2436;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eranJob_24s2120574948x1389646626_lam7(V self, V *args) {
  V v_x_2434 = args[0];
  V v_err_2421 = heff_env(self)[0];
  V v_j_242 = heff_env(self)[1];
  V v_k_2427 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2434);
  V v_t_2435 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eranJob_24s2120574948x1389646626_str1), heff_get_n(v_err_2421, 2, 3));
  V v_x_2436 = (g_heff_2ebuild_2ecommands_2ebrokenJob(v_j_242, v_t_2435));
  V f_ = v_k_2427;
  args[0] = heff_clo_n(g_heff_2ebuild_2ecommands_2eranJob_24s2120574948x1389646626_lam8, 3, 1, (V[]){v_x_2436});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eranJob_24s2120574948x1389646626_lam6(V self, V *args) {
  V v_hd_2426 = args[0];
  V v_k_2427 = args[1];
  V v_a_2425 = heff_env(self)[0];
  V v_err_2421 = heff_env(self)[1];
  V v_j_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2425})});
  V v_t_2429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
  V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
  V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
  V v_t_2432 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
  V v_t_2433 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2432})});
  return (g_co_2eop_24s495635622x733177935(v_t_2433, v_hd_2426, heff_clo_n(g_heff_2ebuild_2ecommands_2eranJob_24s2120574948x1389646626_lam7, 1, 3, (V[]){v_err_2421, v_j_242, v_k_2427})));
}
V g_heff_2ebuild_2ecommands_2eranJob_24s2120574948x1389646626_lam4(V self, V *args) {
  V v_err_2421 = args[0];
  V v_dir_243 = heff_env(self)[0];
  V v_j_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_path_2422 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_dir_243; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
  V v_t_2423 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2422; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_2422); r_; });
  V v_a_2425 = heff_tag_n(TAG_Remove, 2, (V[]){v_t_2423, ((V)&g_heff_2ebuild_2ecommands_2eranJob_24s2120574948x1389646626_lam5_clo)});
  return heff_clo_n(g_heff_2ebuild_2ecommands_2eranJob_24s2120574948x1389646626_lam6, 2, 3, (V[]){v_a_2425, v_err_2421, v_j_242});
}
V g_heff_2ebuild_2ecommands_2eranJob_24s2120574948x1389646626_lam9(V self, V *args) {
  V v_x_2441 = args[0];
  V v_z_244 = heff_env(self)[0];
  V v_z_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_x_2441;
  heff_room[0] = NTAG(TAG_MkUnit);
  heff_room[1] = v_z_244;
  heff_room[2] = v_z_245;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestOneF_24s1086098612x175366387_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestOneF_24s1086098612x175366387_str1, 1, "\012");
V g_heff_2ebuild_2ecommands_2etestOneF_24s1086098612x175366387_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2etestOneF_24s1086098612x175366387_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2etestOneF_24s1086098612x175366387_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2etestOneF_24s1086098612x175366387_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestOneF_24s1086098612x175366387_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestOneF_24s1086098612x175366387_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2etestOneF_24s1086098612x175366387_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2etestOneF_24s1086098612x175366387_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2etestOneF_24s1086098612x175366387(V v_rep_240, V v_opts_241, V v_f_242) {
top: ;
  V v_path_243 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = heff_dup(v_f_242); V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
  V v_t_244 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_243; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_243); r_; });
  V v_a_246 = heff_tag_n(TAG_ReadFile, 2, (V[]){v_t_244, ((V)&g_heff_2ebuild_2ecommands_2etestOneF_24s1086098612x175366387_lam0_clo)});
  return heff_clo_n(g_heff_2ebuild_2ecommands_2etestOneF_24s1086098612x175366387_lam1, 2, 4, (V[]){v_a_246, v_f_242, heff_dup(v_rep_240), v_opts_241});
}
V g_heff_2ebuild_2ecommands_2etestOneF_24s1086098612x175366387_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2etestOneF_24s1086098612x175366387(a0, a[1], a[2]); heff_drop(a0); return r;
}
V g_heff_2ebuild_2ecommands_2etestOneF_24s1086098612x175366387_lam0(V self, V *args) {
  V v_t_245 = args[0];
  return v_t_245;
}
V g_heff_2ebuild_2ecommands_2etestOneF_24s1086098612x175366387_lam3(V self, V *args) {
  V v_x_2417 = args[0];
  V v_x_2415 = heff_env(self)[0];
  V v_rep_240 = heff_env(self)[1];
  V v_opts_241 = heff_env(self)[2];
  V v_f_242 = heff_env(self)[3];
  V v_hd_247 = heff_env(self)[4];
  V v_k_248 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_src_2419;
  switch (heff_tag_of(v_x_2415)) {
  case TAG_Nothing: {
    v_src_2419 = ((V)&g_heff_2ebuild_2ecommands_2etestOneF_24s1086098612x175366387_str0);
    break;
  }
  case TAG_Just: {
    V v_x_2418 = heff_field(v_x_2415, 0);
    heff_take_n(v_x_2415, 1ULL, 1);
    v_src_2419 = v_x_2418;
    break;
  }
  default: heff_nomatch(v_x_2415);
  }
  V v_j_2420 = heff_strFind_lent(((V)&g_heff_2ebuild_2ecommands_2etestOneF_24s1086098612x175366387_str1), v_src_2419, MK_INT(0LL), 5);
  V v_t_2422;
  if (heff_intLt_c_lent(v_j_2420, MK_INT(0LL), 2)) {
    heff_drop(v_j_2420);
    v_t_2422 = heff_strLength_lent(v_src_2419, 0);
  } else {
    v_t_2422 = v_j_2420;
  }
  V v_t_2423 = heff_strEq(heff_strSlice(v_src_2419, MK_INT(0LL), v_t_2422), heff_dup(g_heff_2ebuild_2ecommands_2eexpectErrorsLine_get()));
  return ({ V a_0 = v_rep_240; V a_1 = v_opts_241; V a_2 = v_f_242; V a_3 = v_t_2423; V a_4 = v_x_2417; V a_5 = v_hd_247; V a_6 = v_k_248; V r_ = (g_heff_2ebuild_2ecommands_2etestLoaded_24s1989817941x949950035(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_rep_240); heff_drop(v_t_2423); r_; });
}
V g_heff_2ebuild_2ecommands_2etestOneF_24s1086098612x175366387_lam2(V self, V *args) {
  V v_x_2415 = args[0];
  V v_f_242 = heff_env(self)[0];
  V v_hd_247 = heff_env(self)[1];
  V v_rep_240 = heff_env(self)[2];
  V v_opts_241 = heff_env(self)[3];
  V v_k_248 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_c_2416 = (g_heff_2ebuild_2ecommands_2eload_24s81450283x65507788(heff_dup(v_f_242)));
  V f_ = v_c_2416;
  heff_room[0] = heff_dup(v_hd_247);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2etestOneF_24s1086098612x175366387_lam3, 1, 6, (V[]){v_x_2415, v_rep_240, v_opts_241, v_f_242, v_hd_247, v_k_248});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2etestOneF_24s1086098612x175366387_lam1(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_a_246 = heff_env(self)[0];
  V v_f_242 = heff_env(self)[1];
  V v_rep_240 = heff_env(self)[2];
  V v_opts_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_246})});
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
  V v_t_2414 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2413})});
  return (g_co_2eop_24s495635622x733177935(v_t_2414, heff_dup(v_hd_247), heff_clo_n(g_heff_2ebuild_2ecommands_2etestOneF_24s1086098612x175366387_lam2, 1, 5, (V[]){v_f_242, v_hd_247, v_rep_240, v_opts_241, v_k_248})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecCmd_24s1380603959x1786853260_str0, 1, "/");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecCmd_24s1380603959x1786853260_str1, 3, "*.c");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecCmd_24s1380603959x1786853260_str2, 39, " -femit-bin=runtime.o` and `zig cc -O2 ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecCmd_24s1380603959x1786853260_str3, 26, " runtime.o -o PROGRAM -lm`");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecCmd_24s1380603959x1786853260_str4, 46, ": build it with `zig build-obj -O ReleaseFast ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecCmd_24s1380603959x1786853260_str5, 6, "wrote ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecCmd_24s1380603959x1786853260_str6, 1, "\012");
V g_heff_2ebuild_2ecommands_2ecCmd_24s1380603959x1786853260_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecCmd_24s1380603959x1786853260_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ecCmd_24s1380603959x1786853260_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecCmd_24s1380603959x1786853260_entry, 4, 0};

V g_heff_2ebuild_2ecommands_2ecCmd_24s1380603959x1786853260(V v_rep_240, V v_name_241, V v_outPath_242, V v_file_243) {
top: ;
  V v_t_244 = (g_heff_2ebuild_2ecommands_2ezigOf(heff_dup(v_outPath_242)));
  int64_t v_t_245 = (heff_unbox_word(heff_strLength_lent(v_outPath_242, 0)) - ((int64_t)1ULL));
  V v_t_246 = heff_strSlice(heff_dup(v_outPath_242), heff_box_word(v_t_245), heff_strLength_lent(v_outPath_242, 0));
  V v_t_248;
  if (heff_strEq_c(v_t_246, ((V)&g_heff_2ebuild_2ecommands_2ecCmd_24s1380603959x1786853260_str0))) {
    v_t_248 = heff_strAppend(heff_dup(v_outPath_242), ((V)&g_heff_2ebuild_2ecommands_2ecCmd_24s1380603959x1786853260_str1));
  } else {
    v_t_248 = heff_dup(v_outPath_242);
  }
  V v_t_249 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ecCmd_24s1380603959x1786853260_str2), heff_strAppend(v_t_248, ((V)&g_heff_2ebuild_2ecommands_2ecCmd_24s1380603959x1786853260_str3)));
  V v_t_2410 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ecCmd_24s1380603959x1786853260_str4), heff_strAppend(v_t_244, v_t_249));
  V v_str_2411 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ecCmd_24s1380603959x1786853260_str5), heff_strAppend(heff_dup(v_outPath_242), v_t_2410));
  V v_c_2412 = (g_heff_2ebuild_2ecommands_2eload_24s81450283x65507788(heff_dup(v_file_243)));
  return heff_clo_n(g_heff_2ebuild_2ecommands_2ecCmd_24s1380603959x1786853260_lam0, 2, 6, (V[]){v_c_2412, v_str_2411, v_rep_240, v_name_241, v_outPath_242, v_file_243});
}
V g_heff_2ebuild_2ecommands_2ecCmd_24s1380603959x1786853260_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ecCmd_24s1380603959x1786853260(a[0], a[1], a[2], a[3]);
}
V g_heff_2ebuild_2ecommands_2ecCmd_24s1380603959x1786853260_lam1(V self, V *args) {
  V v_x_2415 = args[0];
  V v_str_2411 = heff_env(self)[0];
  V v_rep_240 = heff_env(self)[1];
  V v_name_241 = heff_env(self)[2];
  V v_outPath_242 = heff_env(self)[3];
  V v_file_243 = heff_env(self)[4];
  V v_hd_2413 = heff_env(self)[5];
  V v_k_2414 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2416 = heff_tag_n(TAG_Write, 2, (V[]){heff_strAppend(v_str_2411, ((V)&g_heff_2ebuild_2ecommands_2ecCmd_24s1380603959x1786853260_str6)), NTAG(TAG_MkUnit)});
  V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
  V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
  V v_t_2422 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2421})});
  V v_t_2423 = heff_tr(heff_call(((V)&g_co_2eop_24s22628809x1035315751_clo), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2422})}));
  return (g_heff_2ebuild_2ecommands_2ecLoadedOr_24s973409408x145459240(MK_INT(1LL), v_rep_240, v_x_2415, v_name_241, v_outPath_242, v_file_243, v_t_2423, v_hd_2413, v_k_2414));
}
V g_heff_2ebuild_2ecommands_2ecCmd_24s1380603959x1786853260_lam0(V self, V *args) {
  V v_hd_2413 = args[0];
  V v_k_2414 = args[1];
  V v_c_2412 = heff_env(self)[0];
  V v_str_2411 = heff_env(self)[1];
  V v_rep_240 = heff_env(self)[2];
  V v_name_241 = heff_env(self)[3];
  V v_outPath_242 = heff_env(self)[4];
  V v_file_243 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V f_ = v_c_2412;
  args[0] = heff_dup(v_hd_2413);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ecCmd_24s1380603959x1786853260_lam1, 1, 7, (V[]){v_str_2411, v_rep_240, v_name_241, v_outPath_242, v_file_243, v_hd_2413, v_k_2414});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileTo_24s1473691404x176248689_str0, 4, "page");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileTo_24s1473691404x176248689_str1, 6, "wrote ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileTo_24s1473691404x176248689_str2, 91, ": load it in a page with <script src=\"...\"> (it imports nothing: it opens from file:// too)");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileTo_24s1473691404x176248689_str3, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileTo_24s1473691404x176248689_str4, 3, "esm");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileTo_24s1473691404x176248689_str5, 70, "heff compile: an ES module runs nothing: no --name with --backend=esm\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileTo_24s1473691404x176248689_str6, 1, "c");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileTo_24s1473691404x176248689_str7, 16, ": esm, page or c");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileTo_24s1473691404x176248689_str8, 25, "heff compile: no backend ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileTo_24s1473691404x176248689_str9, 1, "\012");
V g_heff_2ebuild_2ecommands_2ecompileTo_24s1473691404x176248689_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileTo_24s1473691404x176248689_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ecompileTo_24s1473691404x176248689_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecompileTo_24s1473691404x176248689_lam0, 2, 0};
V g_heff_2ebuild_2ecommands_2ecompileTo_24s1473691404x176248689_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileTo_24s1473691404x176248689_lam2(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ecompileTo_24s1473691404x176248689_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecompileTo_24s1473691404x176248689_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2ecompileTo_24s1473691404x176248689(V v_rep_240, V v_o_241) {
top: ;
  if (heff_strEq_c(heff_dup(heff_rfield(v_o_241, 3)), ((V)&g_heff_2ebuild_2ecommands_2ecompileTo_24s1473691404x176248689_str0))) {
    V v_outPath_243 = heff_take_field(v_o_241, 1);
    V v_t_244 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ecompileTo_24s1473691404x176248689_str1), heff_strAppend(heff_dup(v_outPath_243), ((V)&g_heff_2ebuild_2ecommands_2ecompileTo_24s1473691404x176248689_str2)));
    V v_t_245 = heff_tag_n(TAG_Write, 2, (V[]){heff_strAppend(v_t_244, ((V)&g_heff_2ebuild_2ecommands_2ecompileTo_24s1473691404x176248689_str3)), NTAG(TAG_MkUnit)});
    V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_245})});
    V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
    V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
    V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
    V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
    V v_t_2411 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2410})});
    V v_t_2412 = heff_tr(heff_call(((V)&g_co_2eop_24s22628809x1035315751_clo), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2411})}));
    return ({ V a_0 = v_rep_240; V b_1 = heff_dup(heff_rfield(v_o_241, 2)); V a_2 = v_outPath_243; V a_3 = heff_get_n(v_o_241, 0, 4); V a_4 = v_t_2412; V r_ = (g_heff_2ebuild_2ecommands_2ecompileThen_24s1650899649x955695485(a_0, b_1, a_2, a_3, a_4)); heff_drop(b_1); r_; });
  } else {
    if (heff_strEq_c(heff_dup(heff_rfield(v_o_241, 3)), ((V)&g_heff_2ebuild_2ecommands_2ecompileTo_24s1473691404x176248689_str4))) {
      V v_t_2414 = heff_take_field(v_o_241, 2);
      switch (heff_tag_of(v_t_2414)) {
      case TAG_Nothing: {
        return (g_heff_2ebuild_2ecommands_2ecompileJsCmd_24s384209754x1519830833(v_rep_240, heff_dup(heff_rfield(v_o_241, 0)), heff_get_n(v_o_241, 1, 4)));
      }
      case TAG_Just: {
        heff_take_n(v_t_2414, 0ULL, 1);
        heff_drop(v_rep_240);
        heff_drop_rec(v_o_241, 4);
        return ((V)&g_heff_2ebuild_2ecommands_2ecompileTo_24s1473691404x176248689_lam0_clo);
      }
      default: return heff_nomatch(v_t_2414);
      }
    } else {
      if (heff_strEq_c(heff_dup(heff_rfield(v_o_241, 3)), ((V)&g_heff_2ebuild_2ecommands_2ecompileTo_24s1473691404x176248689_str6))) {
        return (g_heff_2ebuild_2ecommands_2ecCmd_24s1380603959x1786853260(v_rep_240, heff_dup(heff_rfield(v_o_241, 2)), heff_dup(heff_rfield(v_o_241, 1)), heff_get_n(v_o_241, 0, 4)));
      } else {
        heff_drop(v_rep_240);
        return heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileTo_24s1473691404x176248689_lam2, 2, 1, (V[]){v_o_241});
      }
    }
  }
}
V g_heff_2ebuild_2ecommands_2ecompileTo_24s1473691404x176248689_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ecompileTo_24s1473691404x176248689(a[0], a[1]);
}
V g_heff_2ebuild_2ecommands_2ecompileTo_24s1473691404x176248689_lam1(V self, V *args) {
  V v_x_2425 = args[0];
  V v_hd_2416 = heff_env(self)[0];
  V v_k_2417 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2425);
  V v_t_2426 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2426})});
  V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
  V v_t_2429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
  V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
  V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
  V v_t_2432 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2431})});
  return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2432}), v_hd_2416, v_k_2417));
}
V g_heff_2ebuild_2ecommands_2ecompileTo_24s1473691404x176248689_lam0(V self, V *args) {
  V v_hd_2416 = args[0];
  V v_k_2417 = args[1];
  V v_t_2418 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ecompileTo_24s1473691404x176248689_str5), NTAG(TAG_MkUnit)});
  V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
  V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
  V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
  V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
  V v_t_2424 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2423})});
  return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2424}), heff_dup(v_hd_2416), heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileTo_24s1473691404x176248689_lam1, 1, 2, (V[]){v_hd_2416, v_k_2417})));
}
V g_heff_2ebuild_2ecommands_2ecompileTo_24s1473691404x176248689_lam3(V self, V *args) {
  V v_x_2445 = args[0];
  V v_hd_2434 = heff_env(self)[0];
  V v_k_2435 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2445);
  V v_t_2446 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2447 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2446})});
  V v_t_2448 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2447})});
  V v_t_2449 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2448})});
  V v_t_2450 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2449})});
  V v_t_2451 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2450})});
  V v_t_2452 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2451})});
  return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2452}), v_hd_2434, v_k_2435));
}
V g_heff_2ebuild_2ecommands_2ecompileTo_24s1473691404x176248689_lam2(V self, V *args) {
  V v_hd_2434 = args[0];
  V v_k_2435 = args[1];
  V v_o_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2436 = heff_strAppend(heff_get_n(v_o_241, 3, 4), ((V)&g_heff_2ebuild_2ecommands_2ecompileTo_24s1473691404x176248689_str7));
  V v_t_2437 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ecompileTo_24s1473691404x176248689_str8), v_t_2436), ((V)&g_heff_2ebuild_2ecommands_2ecompileTo_24s1473691404x176248689_str9));
  V v_t_2438 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2437, NTAG(TAG_MkUnit)});
  V v_t_2439 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2438})});
  V v_t_2440 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2439})});
  V v_t_2441 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2440})});
  V v_t_2442 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2441})});
  V v_t_2443 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2442})});
  V v_t_2444 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2443})});
  return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2444}), heff_dup(v_hd_2434), heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileTo_24s1473691404x176248689_lam3, 1, 2, (V[]){v_hd_2434, v_k_2435})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2etagCloned_24s1645425458x565956513_str0, 8, "https://");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etagCloned_24s1645425458x565956513_str1, 1, "v");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etagCloned_24s1645425458x565956513_str2, 1, "1");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etagCloned_24s1645425458x565956513_str3, 8, "--branch");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etagCloned_24s1645425458x565956513_str4, 7, "--quiet");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etagCloned_24s1645425458x565956513_str5, 7, "--depth");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etagCloned_24s1645425458x565956513_str6, 25, "advice.detachedHead=false");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etagCloned_24s1645425458x565956513_str7, 5, "clone");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etagCloned_24s1645425458x565956513_str8, 2, "-c");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etagCloned_24s1645425458x565956513_str9, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etagCloned_24s1645425458x565956513_str10, 3, "git");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etagCloned_24s1645425458x565956513_str11, 8, "https://");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etagCloned_24s1645425458x565956513_str12, 3, "): ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etagCloned_24s1645425458x565956513_str13, 4, " of ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etagCloned_24s1645425458x565956513_str14, 7, " (tag v");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etagCloned_24s1645425458x565956513_str15, 1, " ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2etagCloned_24s1645425458x565956513_str16, 13, "cannot fetch ");
V g_heff_2ebuild_2ecommands_2etagCloned_24s1645425458x565956513_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2etagCloned_24s1645425458x565956513_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2etagCloned_24s1645425458x565956513_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2etagCloned_24s1645425458x565956513_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2etagCloned_24s1645425458x565956513_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2etagCloned_24s1645425458x565956513_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2etagCloned_24s1645425458x565956513_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2etagCloned_24s1645425458x565956513(V v_path_240, V v_v_241, V v_dir_242) {
top: ;
  V v_t_243 = (g_heff_2ebuild_2eproject_2erepoOf(heff_dup(v_path_240)));
  V v_t_244 = heff_tag_n(TAG_Cons, 2, (V[]){v_dir_242, NTAG(TAG_Nil)});
  V v_t_245 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2etagCloned_24s1645425458x565956513_str0), v_t_243), v_t_244});
  V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2etagCloned_24s1645425458x565956513_str1), heff_dup(v_v_241)), v_t_245});
  V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2etagCloned_24s1645425458x565956513_str2), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2etagCloned_24s1645425458x565956513_str3), v_t_246})});
  V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2etagCloned_24s1645425458x565956513_str4), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2etagCloned_24s1645425458x565956513_str5), v_t_247})});
  V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2etagCloned_24s1645425458x565956513_str6), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2etagCloned_24s1645425458x565956513_str7), v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2etagCloned_24s1645425458x565956513_str8), v_t_249});
  V v_t_2411 = ({ V b_0 = NTAG(TAG_Nil); V b_1 = NTAG(TAG_Nil); V r_ = (g_std_2epath_2esameSegments(b_0, b_1)); heff_drop(b_0); heff_drop(b_1); r_; });
  V v_t_2412;
  if ((heff_dup(v_t_2411) == NTAG(TAG_True))) {
    heff_drop(v_t_2411);
    v_t_2412 = ((V)&g_heff_2ebuild_2ecommands_2etagCloned_24s1645425458x565956513_str9);
  } else {
    heff_drop(v_t_2411);
    v_t_2412 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V b_1 = heff_dup(g_std_2epath_2ecurrent_get()); V r_ = (g_std_2epath_2erender(b_0, b_1)); heff_drop(b_0); heff_drop(b_1); r_; });
  }
  V v_t_2413 = heff_rec_n(10, shape_command__args__dir__env__input__output__errors__timeout__keep__group, (V[]){((V)&g_heff_2ebuild_2ecommands_2etagCloned_24s1645425458x565956513_str10), v_t_2410, v_t_2412, NTAG(TAG_Nil), NTAG(TAG_NoInput), NTAG(TAG_Collected), NTAG(TAG_Collected), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_False)});
  V v_a_2415 = heff_tag_n(TAG_Run, 2, (V[]){v_t_2413, ((V)&g_heff_2ebuild_2ecommands_2etagCloned_24s1645425458x565956513_lam0_clo)});
  return heff_clo_n(g_heff_2ebuild_2ecommands_2etagCloned_24s1645425458x565956513_lam1, 2, 3, (V[]){v_a_2415, v_path_240, v_v_241});
}
V g_heff_2ebuild_2ecommands_2etagCloned_24s1645425458x565956513_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2etagCloned_24s1645425458x565956513(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2ecommands_2etagCloned_24s1645425458x565956513_lam0(V self, V *args) {
  V v_r_2414 = args[0];
  return v_r_2414;
}
V g_heff_2ebuild_2ecommands_2etagCloned_24s1645425458x565956513_lam2(V self, V *args) {
  V v_x_2424 = args[0];
  V v_path_240 = heff_env(self)[0];
  V v_v_241 = heff_env(self)[1];
  V v_k_2417 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2425 = heff_take_field(v_x_2424, 0);
  V v_t_2428;
  switch (heff_tag_of(v_t_2425)) {
  case TAG_Exited: {
    V v_n_2426 = heff_field(v_t_2425, 0);
    heff_take_n(v_t_2425, 1ULL, 1);
    v_t_2428 = heff_intEq(v_n_2426, MK_INT(0LL));
    break;
  }
  case TAG_Signalled: {
    heff_take_n(v_t_2425, 0ULL, 1);
    v_t_2428 = NTAG(TAG_False);
    break;
  }
  case TAG_TimedOut: {
    v_t_2428 = NTAG(TAG_False);
    break;
  }
  case TAG_NotRun: {
    v_t_2428 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_t_2425);
  }
  V v_x_2439;
  if ((heff_dup(v_t_2428) == NTAG(TAG_True))) {
    heff_drop_rec(v_x_2424, 3);
    heff_drop(v_path_240);
    heff_drop(v_v_241);
    heff_drop(v_t_2428);
    v_x_2439 = NTAG(TAG_Nothing);
  } else {
    heff_drop(v_t_2428);
    V v_t_2429 = (g_heff_2ebuild_2eproject_2erepoOf(heff_dup(v_path_240)));
    V v_s_2430 = heff_get_n(v_x_2424, 2, 3);
    V v_t_2431 = (g_prelude_2eskipSpaces(v_s_2430, MK_INT(0LL), MK_INT(1LL)));
    int64_t v_t_2432 = (heff_unbox_word(heff_strLength_lent(v_s_2430, 0)) - ((int64_t)1ULL));
    V v_t_2433 = (g_prelude_2eskipSpaces(v_s_2430, heff_box_word(v_t_2432), MK_INT(-1LL)));
    V v_t_2434 = heff_strSlice(v_s_2430, v_t_2431, heff_intAdd(v_t_2433, MK_INT(1LL)));
    V v_t_2435 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2etagCloned_24s1645425458x565956513_str11), v_t_2429), heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2etagCloned_24s1645425458x565956513_str12), v_t_2434));
    V v_t_2436 = heff_strAppend(heff_dup(v_v_241), heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2etagCloned_24s1645425458x565956513_str13), v_t_2435));
    V v_t_2437 = heff_strAppend(v_v_241, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2etagCloned_24s1645425458x565956513_str14), v_t_2436));
    V v_t_2438 = heff_strAppend(v_path_240, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2etagCloned_24s1645425458x565956513_str15), v_t_2437));
    v_x_2439 = heff_tag_n(TAG_Just, 1, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2etagCloned_24s1645425458x565956513_str16), v_t_2438)});
  }
  V f_ = v_k_2417;
  args[0] = v_x_2439;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2etagCloned_24s1645425458x565956513_lam1(V self, V *args) {
  V v_hd_2416 = args[0];
  V v_k_2417 = args[1];
  V v_a_2415 = heff_env(self)[0];
  V v_path_240 = heff_env(self)[1];
  V v_v_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2415})});
  V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
  V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
  V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
  V v_t_2423 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2422})});
  return (g_co_2eop_24s495635622x733177935(heff_tag_n(TAG_InR, 1, (V[]){v_t_2423}), v_hd_2416, heff_clo_n(g_heff_2ebuild_2ecommands_2etagCloned_24s1645425458x565956513_lam2, 1, 3, (V[]){v_path_240, v_v_241, v_k_2417})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprintDefs_24s1608636047x342860471_str0, 1, " ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprintDefs_24s1608636047x342860471_str1, 6, "=body ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprintDefs_24s1608636047x342860471_str2, 4, "=ty ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprintDefs_24s1608636047x342860471_str3, 5, "=def ");
V g_heff_2ebuild_2ecommands_2eprintDefs_24s1608636047x342860471_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eprintDefs_24s1608636047x342860471_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eprintDefs_24s1608636047x342860471_lam0, 2, 0};
V g_heff_2ebuild_2ecommands_2eprintDefs_24s1608636047x342860471_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2eprintDefs_24s1608636047x342860471_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eprintDefs_24s1608636047x342860471_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eprintDefs_24s1608636047x342860471_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2eprintDefs_24s1608636047x342860471(V v_c_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop_rec(v_c_240, 14);
    return ((V)&g_heff_2ebuild_2ecommands_2eprintDefs_24s1608636047x342860471_lam0_clo);
  }
  case TAG_Cons: {
    V v_k_244 = heff_field(v_x2_241, 0);
    V v_rest_245 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_246 = (g_heff_2ebuild_2edriver_2edefKind(heff_dup(v_c_240), v_k_244));
    V v_t_247 = heff_strAppend(heff_dup(v_k_244), heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eprintDefs_24s1608636047x342860471_str0), v_t_246));
    V v_t_248 = (g_heff_2eelab_2etoplevel_2etyDump(heff_dup(heff_rfield(v_c_240, 5)), v_k_244));
    V v_t_249 = ({ V a_0 = heff_dup(heff_rfield(v_c_240, 5)); V a_1 = v_k_244; V r_ = (g_heff_2eelab_2etoplevel_2ebodyDump(a_0, a_1)); heff_drop(v_k_244); r_; });
    V v_t_2410 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eprintDefs_24s1608636047x342860471_str1), v_t_249), NTAG(TAG_Nil)});
    V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eprintDefs_24s1608636047x342860471_str2), v_t_248), v_t_2410});
    V v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eprintDefs_24s1608636047x342860471_str3), v_t_247), v_t_2411});
    return heff_clo_n(g_heff_2ebuild_2ecommands_2eprintDefs_24s1608636047x342860471_lam1, 2, 3, (V[]){v_t_2412, v_c_240, v_rest_245});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2ecommands_2eprintDefs_24s1608636047x342860471_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eprintDefs_24s1608636047x342860471(a[0], a[1]);
}
V g_heff_2ebuild_2ecommands_2eprintDefs_24s1608636047x342860471_lam0(V self, V *args) {
  V v_hd_242 = args[0];
  V v_k_243 = args[1];
  heff_drop(v_hd_242);
  V f_ = v_k_243;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eprintDefs_24s1608636047x342860471_lam2(V self, V *args) {
  V v_x_2415 = args[0];
  V v_c_240 = heff_env(self)[0];
  V v_rest_245 = heff_env(self)[1];
  V v_hd_2413 = heff_env(self)[2];
  V v_k_2414 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2415);
  V v_t_2416 = (g_heff_2ebuild_2ecommands_2eprintDefs_24s1608636047x342860471(v_c_240, v_rest_245));
  V f_ = v_t_2416;
  heff_room[0] = v_hd_2413;
  heff_room[1] = v_k_2414;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2eprintDefs_24s1608636047x342860471_lam1(V self, V *args) {
  V v_hd_2413 = args[0];
  V v_k_2414 = args[1];
  V v_t_2412 = heff_env(self)[0];
  V v_c_240 = heff_env(self)[1];
  V v_rest_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2ebuild_2ecommands_2eprintLines_24s1090954299x687958379(v_t_2412, heff_dup(v_hd_2413), heff_clo_n(g_heff_2ebuild_2ecommands_2eprintDefs_24s1608636047x342860471_lam2, 1, 4, (V[]){v_c_240, v_rest_245, v_hd_2413, v_k_2414})));
}