// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Collected 38917
#define TAG_Complete 48856
#define TAG_End 17255
#define TAG_Exit 20279
#define TAG_Exited 20560
#define TAG_FailBecause 16014
#define TAG_Left 13886
#define TAG_MkPath 49630
#define TAG_NoInput 41055
#define TAG_NotRun 12703
#define TAG_Platform 55558
#define TAG_Posix 44191
#define TAG_ProgramPath 46819
#define TAG_Right 62770
#define TAG_Run 29975
#define TAG_Signalled 34337
#define TAG_Start 63542
#define TAG_TimedOut 6056
#define TAG_Windows 49101
#define TAG_Write 36323
#define TAG_WriteErr 37283
#define TAG_Wrong 41905
#define LBL_args 9498020
#define LBL_bug 307438
#define LBL_command 1182252425
#define LBL_diags 296935042
#define LBL_dir 308999
#define LBL_done 9584713
#define LBL_ended 298010324
#define LBL_env 310119
#define LBL_err 310239
#define LBL_errors 652506774
#define LBL_expected 956903529
#define LBL_goldens 436112074
#define LBL_group 299987609
#define LBL_heff 9694020
#define LBL_input 301716452
#define LBL_keep 9783372
#define LBL_module 878357911
#define LBL_msg 317947
#define LBL_name 9869138
#define LBL_ok 10307
#define LBL_out 319944
#define LBL_output 941629484
#define LBL_package 1572278921
#define LBL_path 9928940
#define LBL_source 1050636102
#define LBL_style 311138763
#define LBL_timeout 1065429926
#define LBL_value 313331083
#define LBL_watch 314261737
static uint32_t shape_command__args__dir__env__input__output__errors__timeout__keep__group[] = {LBL_command, LBL_args, LBL_dir, LBL_env, LBL_input, LBL_output, LBL_errors, LBL_timeout, LBL_keep, LBL_group};
V g_co_2eop_24s1204515794x2100690815(V, V, V, V, V, V, V, V);
V g_co_2eop_24s1204515794x2100690815_entry(V self, V *a);
extern Clo g_co_2eop_24s1204515794x2100690815_clo;
V g_co_2eop_24s615738393x1686646143(V, V, V);
V g_co_2eop_24s615738393x1686646143_entry(V self, V *a);
extern Clo g_co_2eop_24s615738393x1686646143_clo;
V g_co_2eop_24s710864882x261522381(V, V, V, V, V, V, V);
V g_co_2eop_24s710864882x261522381_entry(V self, V *a);
extern Clo g_co_2eop_24s710864882x261522381_clo;
V g_heff_2ebuild_2ecommands_2ebackDirOf(V);
V g_heff_2ebuild_2ecommands_2ebackDirOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ebackDirOf_clo;
V g_heff_2ebuild_2ecommands_2ecommitAt_24s1687144202x1882378819(V, V);
V g_heff_2ebuild_2ecommands_2ecommitAt_24s1687144202x1882378819_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecommitAt_24s1687144202x1882378819_clo;
V g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941(V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941_clo;
V g_heff_2ebuild_2ecommands_2ecwdNow_24s507786937x461532604(V, V);
V g_heff_2ebuild_2ecommands_2ecwdNow_24s507786937x461532604_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecwdNow_24s507786937x461532604_clo;
V g_heff_2ebuild_2ecommands_2ediagCount_24s823746706x1248851912(V);
V g_heff_2ebuild_2ecommands_2ediagCount_24s823746706x1248851912_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ediagCount_24s823746706x1248851912_clo;
V g_heff_2ebuild_2ecommands_2edocPageWritten_24s1466416307x1099964288(V, V, V, V);
V g_heff_2ebuild_2ecommands_2edocPageWritten_24s1466416307x1099964288_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2edocPageWritten_24s1466416307x1099964288_clo;
V g_heff_2ebuild_2ecommands_2edocPagesWritten_24s186486549x585078911(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2edocPagesWritten_24s186486549x585078911_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2edocPagesWritten_24s186486549x585078911_clo;
V g_heff_2ebuild_2ecommands_2eemitErrs_24s394189364x2134712221(V, V, V);
V g_heff_2ebuild_2ecommands_2eemitErrs_24s394189364x2134712221_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eemitErrs_24s394189364x2134712221_clo;
V g_heff_2ebuild_2ecommands_2eexisting_24s783863025x1958439471(V, V, V, V);
V g_heff_2ebuild_2ecommands_2eexisting_24s783863025x1958439471_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eexisting_24s783863025x1958439471_clo;
V g_heff_2ebuild_2ecommands_2efailLine(V, V, V);
V g_heff_2ebuild_2ecommands_2efailLine_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2efailLine_clo;
HeffT2 g_heff_2ebuild_2ecommands_2efirstErrorOf_24cpr(V);
V g_heff_2ebuild_2ecommands_2egoldenAgainst_24s992520432x896454450(V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2egoldenAgainst_24s992520432x896454450_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2egoldenAgainst_24s992520432x896454450_clo;
V g_heff_2ebuild_2ecommands_2egoldenByte(V);
V g_heff_2ebuild_2ecommands_2egoldenByte_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2egoldenByte_clo;
V g_heff_2ebuild_2ecommands_2egoldenPath(V, V, V);
V g_heff_2ebuild_2ecommands_2egoldenPath_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2egoldenPath_clo;
V g_heff_2ebuild_2ecommands_2egoldenSaid_24s1045388766x363711794(V, V, V);
V g_heff_2ebuild_2ecommands_2egoldenSaid_24s1045388766x363711794_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2egoldenSaid_24s1045388766x363711794_clo;
V g_heff_2ebuild_2ecommands_2egoldensGo_24s1881795521x39532647(V, V, V, V);
V g_heff_2ebuild_2ecommands_2egoldensGo_24s1881795521x39532647_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2egoldensGo_24s1881795521x39532647_clo;
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1606122519x1439074770(V, V);
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1606122519x1439074770_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1606122519x1439074770_clo;
V g_heff_2ebuild_2ecommands_2einitCmd_24s795893522x1842903301(V, V, V);
V g_heff_2ebuild_2ecommands_2einitCmd_24s795893522x1842903301_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2einitCmd_24s795893522x1842903301_clo;
HeffT2 g_heff_2ebuild_2ecommands_2einitProblem_24cpr(V, V);
V g_heff_2ebuild_2ecommands_2eload_24s1410275656x228048283(V);
V g_heff_2ebuild_2ecommands_2eload_24s1410275656x228048283_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eload_24s1410275656x228048283_clo;
V g_heff_2ebuild_2ecommands_2enoRes_get(void);
V g_heff_2ebuild_2ecommands_2eownPackage_24s693628669x534541312(V, V);
V g_heff_2ebuild_2ecommands_2eownPackage_24s693628669x534541312_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eownPackage_24s693628669x534541312_clo;
V g_heff_2ebuild_2ecommands_2eprintErrs_24s115117455x797094904(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eprintErrs_24s115117455x797094904_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprintErrs_24s115117455x797094904_clo;
V g_heff_2ebuild_2ecommands_2eprintEvals_24s906160764x145037181(V, V, V);
V g_heff_2ebuild_2ecommands_2eprintEvals_24s906160764x145037181_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprintEvals_24s906160764x145037181_clo;
V g_heff_2ebuild_2ecommands_2eprintFails_24s1263841563x776765553(V, V, V);
V g_heff_2ebuild_2ecommands_2eprintFails_24s1263841563x776765553_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprintFails_24s1263841563x776765553_clo;
V g_heff_2ebuild_2ecommands_2eprojectFiles(V, V);
V g_heff_2ebuild_2ecommands_2eprojectFiles_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprojectFiles_clo;
V g_heff_2ebuild_2ecommands_2eprojectName(V, V, V);
V g_heff_2ebuild_2ecommands_2eprojectName_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprojectName_clo;
V g_heff_2ebuild_2ecommands_2epublishChecked_24s922680055x1348891372(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2epublishChecked_24s922680055x1348891372_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2epublishChecked_24s922680055x1348891372_clo;
V g_heff_2ebuild_2ecommands_2epublishCmd_24s581473772x1366906885(V, V);
V g_heff_2ebuild_2ecommands_2epublishCmd_24s581473772x1366906885_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2epublishCmd_24s581473772x1366906885_clo;
V g_heff_2ebuild_2ecommands_2epublishGit_24s211231607x115039889(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2epublishGit_24s211231607x115039889_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2epublishGit_24s211231607x115039889_clo;
V g_heff_2ebuild_2ecommands_2epublishTested_24s563627996x2090231580(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2epublishTested_24s563627996x2090231580_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2epublishTested_24s563627996x2090231580_clo;
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s415097226x198460927(V, V);
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s415097226x198460927_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eputFileDiags_24s415097226x198460927_clo;
V g_heff_2ebuild_2ecommands_2eremoveStale_24s1076505188x1773366585(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eremoveStale_24s1076505188x1773366585_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eremoveStale_24s1076505188x1773366585_clo;
V g_heff_2ebuild_2ecommands_2erevNamed(V);
V g_heff_2ebuild_2ecommands_2erevNamed_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2erevNamed_clo;
V g_heff_2ebuild_2ecommands_2erevSaid(V);
V g_heff_2ebuild_2ecommands_2erevSaid_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2erevSaid_clo;
V g_heff_2ebuild_2ecommands_2eselfFrom_24s176185486x602532917(V, V, V);
V g_heff_2ebuild_2ecommands_2eselfFrom_24s176185486x602532917_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eselfFrom_24s176185486x602532917_clo;
V g_heff_2ebuild_2ecommands_2eselfHash_24s2023922332x1057539294(V, V, V);
V g_heff_2ebuild_2ecommands_2eselfHash_24s2023922332x1057539294_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eselfHash_24s2023922332x1057539294_clo;
V g_heff_2ebuild_2ecommands_2eselfPath_24s1432537356x1686629462(V, V);
V g_heff_2ebuild_2ecommands_2eselfPath_24s1432537356x1686629462_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eselfPath_24s1432537356x1686629462_clo;
HeffT2 g_heff_2ebuild_2ecommands_2especOf_24cpr(V);
V g_heff_2ebuild_2ecommands_2etestAll_24s749792949x1328449028(V, V, V);
V g_heff_2ebuild_2ecommands_2etestAll_24s749792949x1328449028_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2etestAll_24s749792949x1328449028_clo;
V g_heff_2ebuild_2ecommands_2ewithGoldens_24s1327649047x255568769(V, V, V);
V g_heff_2ebuild_2ecommands_2ewithGoldens_24s1327649047x255568769_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ewithGoldens_24s1327649047x255568769_clo;
V g_heff_2ebuild_2ecommands_2ewriteAll_24s302415776x955929641(V, V, V, V);
V g_heff_2ebuild_2ecommands_2ewriteAll_24s302415776x955929641_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ewriteAll_24s302415776x955929641_clo;
V g_heff_2ebuild_2ecommands_2ewriteOut_24s1442511881x314947241(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ewriteOut_24s1442511881x314947241_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ewriteOut_24s1442511881x314947241_clo;
V g_heff_2ebuild_2ecommands_2ewriteOutC_24s1877451407x355012956(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ewriteOutC_24s1877451407x355012956_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ewriteOutC_24s1877451407x355012956_clo;
V g_heff_2ebuild_2ecommands_2ewriteParts_24s1069210723x719436499(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ewriteParts_24s1069210723x719436499_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ewriteParts_24s1069210723x719436499_clo;
V g_heff_2ebuild_2ecommands_2ewritePartsGo_24s2124042284x1735199047(V, V, V, V);
V g_heff_2ebuild_2ecommands_2ewritePartsGo_24s2124042284x1735199047_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ewritePartsGo_24s2124042284x1735199047_clo;
V g_heff_2ebuild_2edocpages_2epage(V);
V g_heff_2ebuild_2edocpages_2epage_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edocpages_2epage_clo;
V g_heff_2ebuild_2eload_2ecachedDir(V, V, V);
V g_heff_2ebuild_2eload_2ecachedDir_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2ecachedDir_clo;
HeffT2 g_heff_2ebuild_2eproject_2epackageLit_24cpr(V);
HeffT2 g_heff_2ebuild_2eproject_2epackageOf_24cpr(V);
V g_heff_2ebuild_2eproject_2epseudoVersion(V, V, V);
V g_heff_2ebuild_2eproject_2epseudoVersion_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2epseudoVersion_clo;
V g_heff_2ebuild_2eproject_2erepoOf(V);
V g_heff_2ebuild_2eproject_2erepoOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2erepoOf_clo;
HeffT2 g_heff_2ebuild_2eproject_2eversion_24cpr(V);
V g_heff_2ebuild_2esession_2ecachedAcc_24s1827793511x304312721(V);
V g_heff_2ebuild_2esession_2ecachedAcc_24s1827793511x304312721_entry(V self, V *a);
extern Clo g_heff_2ebuild_2esession_2ecachedAcc_24s1827793511x304312721_clo;
V g_heff_2elsp_2erender_2ediagWhere(V, V, V);
V g_heff_2elsp_2erender_2ediagWhere_entry(V self, V *a);
extern Clo g_heff_2elsp_2erender_2ediagWhere_clo;
V g_heff_2elsp_2erender_2eprtCode(V);
V g_heff_2elsp_2erender_2eprtCode_entry(V self, V *a);
extern Clo g_heff_2elsp_2erender_2eprtCode_clo;
V g_heff_2elsp_2ereport_2emismatch(V, V, V);
V g_heff_2elsp_2ereport_2emismatch_entry(V self, V *a);
extern Clo g_heff_2elsp_2ereport_2emismatch_clo;
V g_heff_2eutil_2efiles_2emakeDirectory_24s1667989245x984665292(V);
V g_heff_2eutil_2efiles_2emakeDirectory_24s1667989245x984665292_entry(V self, V *a);
extern Clo g_heff_2eutil_2efiles_2emakeDirectory_24s1667989245x984665292_clo;
V g_heff_2eutil_2efiles_2ereadDirectory_24s297726609x1532867392(V);
V g_heff_2eutil_2efiles_2ereadDirectory_24s297726609x1532867392_entry(V self, V *a);
extern Clo g_heff_2eutil_2efiles_2ereadDirectory_24s297726609x1532867392_clo;
V g_heff_2eutil_2efiles_2ereadFile_24s1303888535x886302188(V);
V g_heff_2eutil_2efiles_2ereadFile_24s1303888535x886302188_entry(V self, V *a);
extern Clo g_heff_2eutil_2efiles_2ereadFile_24s1303888535x886302188_clo;
V g_heff_2eutil_2efiles_2eremove_24s889287061x300693304(V);
V g_heff_2eutil_2efiles_2eremove_24s889287061x300693304_entry(V self, V *a);
extern Clo g_heff_2eutil_2efiles_2eremove_24s889287061x300693304_clo;
V g_heff_2eutil_2efiles_2ewriteFile_24s2113411595x1300955264(V, V);
V g_heff_2eutil_2efiles_2ewriteFile_24s2113411595x1300955264_entry(V self, V *a);
extern Clo g_heff_2eutil_2efiles_2ewriteFile_24s2113411595x1300955264_clo;
V g_list_2eall_24s523006110x1088755562(V);
V g_list_2eall_24s523006110x1088755562_entry(V self, V *a);
extern Clo g_list_2eall_24s523006110x1088755562_clo;
V g_list_2eany_24s1740858080x874135214(V);
V g_list_2eany_24s1740858080x874135214_entry(V self, V *a);
extern Clo g_list_2eany_24s1740858080x874135214_clo;
V g_list_2edrop(V, V);
V g_list_2edrop_entry(V self, V *a);
extern Clo g_list_2edrop_clo;
V g_list_2efoldl_24f2094160282x1876485468(V, V, V);
V g_list_2efoldl_24f2094160282x1876485468_entry(V self, V *a);
extern Clo g_list_2efoldl_24f2094160282x1876485468_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2ekeepIf_24s1161549307x1906011635(V);
V g_list_2ekeepIf_24s1161549307x1906011635_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1161549307x1906011635_clo;
V g_list_2emap_24s370939663x1496042695(V, V);
V g_list_2emap_24s370939663x1496042695_entry(V self, V *a);
extern Clo g_list_2emap_24s370939663x1496042695_clo;
V g_prelude_2einstanceShowString_2eescapedFrom_241(V, V, V);
V g_prelude_2einstanceShowString_2eescapedFrom_241_entry(V self, V *a);
extern Clo g_prelude_2einstanceShowString_2eescapedFrom_241_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2eskipSpaces(V, V, V);
V g_prelude_2eskipSpaces_entry(V self, V *a);
extern Clo g_prelude_2eskipSpaces_clo;
V g_prelude_2esplitFrom(V, V, V, V, V);
V g_prelude_2esplitFrom_entry(V self, V *a);
extern Clo g_prelude_2esplitFrom_clo;
V g_std_2epath_2ecurrent_get(void);
V g_std_2epath_2ejoin(V, V);
V g_std_2epath_2ejoin_entry(V self, V *a);
extern Clo g_std_2epath_2ejoin_clo;
V g_std_2epath_2enative_get(void);
V g_std_2epath_2eparse(V, V);
V g_std_2epath_2eparse_entry(V self, V *a);
extern Clo g_std_2epath_2eparse_clo;
HeffT3 g_std_2epath_2eparse_24cpr(V, V);
V g_std_2epath_2erender(V, V);
V g_std_2epath_2erender_entry(V self, V *a);
extern Clo g_std_2epath_2erender_clo;
V g_std_2epath_2esameSegments(V, V);
V g_std_2epath_2esameSegments_entry(V self, V *a);
extern Clo g_std_2epath_2esameSegments_clo;
V g_std_2eprocess_2erun_24s1262677465x1574883892(V, V, V, V, V);
V g_std_2eprocess_2erun_24s1262677465x1574883892_entry(V self, V *a);
extern Clo g_std_2eprocess_2erun_24s1262677465x1574883892_clo;
V g_std_2eprogress_2eroot_get(void);
HEFF_LIT(g_heff_2ebuild_2ecommands_2efirstErrorOf_24cpr_str0, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efirstErrorOf_24cpr_str1, 2, ": ");

HeffT2 g_heff_2ebuild_2ecommands_2efirstErrorOf_24cpr(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_c_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 3ULL, 2);
    V v_x2_243 = (g_list_2ekeepIf_24s1161549307x1906011635(heff_take_field(v_c_241, 6)));
    switch (heff_tag_of(v_x2_243)) {
    case TAG_Nil: {
      heff_drop_rec(v_c_241, 14);
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Cons: {
      V v_d_244 = heff_field(v_x2_243, 0);
      heff_take_n(v_x2_243, 1ULL, 2);
      heff_drop(v_rest_242);
      V v_t_246 = ({ V a_0 = heff_take_field(v_c_241, 1); V b_1 = heff_get_n(v_c_241, 3, 14); V a_2 = heff_dup(v_d_244); V r_ = (g_heff_2elsp_2erender_2ediagWhere(a_0, b_1, a_2)); heff_drop(b_1); r_; });
      V v_t_247 = (g_heff_2elsp_2erender_2eprtCode(heff_dup(v_d_244)));
      V v_t_248 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efirstErrorOf_24cpr_str0), heff_get_n(v_d_244, 2, 5));
      V v_t_249 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efirstErrorOf_24cpr_str1), heff_strAppend(v_t_247, v_t_248));
      V v_why_2410 = heff_strAppend(v_t_246, v_t_249);
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_why_2410}});
    }
    default: return ((HeffT2){{heff_nomatch(v_x2_243)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
Clo g_heff_2ebuild_2ecommands_2egoldenByte_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2egoldenByte_entry, 1, 0};

V g_heff_2ebuild_2ecommands_2egoldenByte(V v_box_24c_240) {
  int64_t v_c_240 = heff_unbox_word(v_box_24c_240);
top: ;
  V v_t_242 = heff_bool(((((int64_t)48ULL) <= v_c_240) && (v_c_240 <= ((int64_t)57ULL))));
  V v_ret_24bool = heff_bool(((heff_dup(v_t_242) == NTAG(TAG_True)) || ((((int64_t)65ULL) <= v_c_240) ? ((v_c_240 <= ((int64_t)90ULL)) || ((((int64_t)97ULL) <= v_c_240) ? ((v_c_240 <= ((int64_t)122ULL)) || ((v_c_240 == ((int64_t)45ULL)) || ((v_c_240 == ((int64_t)95ULL)) || (v_c_240 == ((int64_t)46ULL))))) : ((v_c_240 == ((int64_t)45ULL)) || ((v_c_240 == ((int64_t)95ULL)) || (v_c_240 == ((int64_t)46ULL)))))) : ((((int64_t)97ULL) <= v_c_240) ? (heff_intLe_c(heff_box_word(v_c_240), MK_INT(122LL)) || (heff_intEq_c(heff_box_word(v_c_240), MK_INT(45LL)) || (heff_intEq_c(heff_box_word(v_c_240), MK_INT(95LL)) || heff_intEq_c(heff_box_word(v_c_240), MK_INT(46LL))))) : ((v_c_240 == ((int64_t)45ULL)) || ((v_c_240 == ((int64_t)95ULL)) || (v_c_240 == ((int64_t)46ULL))))))));
  heff_drop(v_t_242);
  return v_ret_24bool;
}
V g_heff_2ebuild_2ecommands_2egoldenByte_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2egoldenByte(a[0]);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2especOf_24cpr_str0, 1, "@");
HEFF_LIT(g_heff_2ebuild_2ecommands_2especOf_24cpr_str1, 1, "@");

HeffT2 g_heff_2ebuild_2ecommands_2especOf_24cpr(V v_spec_240) {
top: ;
  V v_it_241 = ({ V b_0 = ((V)&g_heff_2ebuild_2ecommands_2especOf_24cpr_str0); V a_1 = v_spec_240; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2ecommands_2especOf_24cpr_str1), v_spec_240, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
  switch (heff_tag_of(v_it_241)) {
  case TAG_Nil: {
    return ((HeffT2){{v_spec_240, NTAG(TAG_Nothing)}});
  }
  case TAG_Cons: {
    V v_path_242 = heff_field(v_it_241, 0);
    V v_it2_243 = heff_field(v_it_241, 1);
    heff_take_n(v_it_241, 3ULL, 2);
    switch (heff_tag_of(v_it2_243)) {
    case TAG_Nil: {
      heff_drop(v_path_242);
      return ((HeffT2){{v_spec_240, NTAG(TAG_Nothing)}});
    }
    case TAG_Cons: {
      V v_v_244 = heff_field(v_it2_243, 0);
      V v_it22_245 = heff_field(v_it2_243, 1);
      heff_take_n(v_it2_243, 3ULL, 2);
      switch (heff_tag_of(v_it22_245)) {
      case TAG_Nil: {
        heff_drop(v_spec_240);
        return ((HeffT2){{v_path_242, heff_tag_n(TAG_Just, 1, (V[]){v_v_244})}});
      }
      case TAG_Cons: {
        heff_take_n(v_it22_245, 0ULL, 2);
        heff_drop(v_path_242);
        heff_drop(v_v_244);
        return ((HeffT2){{v_spec_240, NTAG(TAG_Nothing)}});
      }
      default: return ((HeffT2){{heff_nomatch(v_it22_245)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_it2_243)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_it_241)}});
  }
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eselfPath_24s1432537356x1686629462_str0, 5, "win32");
V g_heff_2ebuild_2ecommands_2eselfPath_24s1432537356x1686629462_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eselfPath_24s1432537356x1686629462_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eselfPath_24s1432537356x1686629462_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2eselfPath_24s1432537356x1686629462_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eselfPath_24s1432537356x1686629462_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eselfPath_24s1432537356x1686629462_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2eselfPath_24s1432537356x1686629462_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2eselfPath_24s1432537356x1686629462_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eselfPath_24s1432537356x1686629462_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eselfPath_24s1432537356x1686629462_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2eselfPath_24s1432537356x1686629462(V v_hd_240, V v_k_241) {
top: ;
  V v_t_243 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2eselfPath_24s1432537356x1686629462_lam0_clo)})});
  V v_t_244 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_243})});
  V v_t_245 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_244})});
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_245})});
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_248})});
  return (g_co_2eop_24s615738393x1686646143(v_t_249, heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2ecommands_2eselfPath_24s1432537356x1686629462_lam1, 1, 2, (V[]){v_hd_240, v_k_241})));
}
V g_heff_2ebuild_2ecommands_2eselfPath_24s1432537356x1686629462_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eselfPath_24s1432537356x1686629462(a[0], a[1]);
}
V g_heff_2ebuild_2ecommands_2eselfPath_24s1432537356x1686629462_lam0(V self, V *args) {
  V v_s_242 = args[0];
  return v_s_242;
}
V g_heff_2ebuild_2ecommands_2eselfPath_24s1432537356x1686629462_lam2(V self, V *args) {
  V v_s_2411 = args[0];
  return v_s_2411;
}
V g_heff_2ebuild_2ecommands_2eselfPath_24s1432537356x1686629462_lam3(V self, V *args) {
  V v_x_2419 = args[0];
  V v_x_2410 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2420 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_x_2419; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
  V v_t_2422;
  if (heff_strEq_c(v_x_2410, ((V)&g_heff_2ebuild_2ecommands_2eselfPath_24s1432537356x1686629462_str0))) {
    v_t_2422 = NTAG(TAG_Windows);
  } else {
    v_t_2422 = NTAG(TAG_Posix);
  }
  V v_x_2423 = ({ V a_0 = v_t_2422; V a_1 = v_x_2420; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2422); heff_drop(v_x_2420); r_; });
  V f_ = v_k_241;
  args[0] = v_x_2423;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eselfPath_24s1432537356x1686629462_lam1(V self, V *args) {
  V v_x_2410 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2412 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ProgramPath, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2eselfPath_24s1432537356x1686629462_lam2_clo)})});
  V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
  V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
  V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2417})});
  return (g_co_2eop_24s615738393x1686646143(v_t_2418, v_hd_240, heff_clo_n(g_heff_2ebuild_2ecommands_2eselfPath_24s1432537356x1686629462_lam3, 1, 2, (V[]){v_x_2410, v_k_241})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eselfHash_24s2023922332x1057539294_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eselfHash_24s2023922332x1057539294_str1, 8, "compiler");
V g_heff_2ebuild_2ecommands_2eselfHash_24s2023922332x1057539294_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2eselfHash_24s2023922332x1057539294_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2eselfHash_24s2023922332x1057539294_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eselfHash_24s2023922332x1057539294_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eselfHash_24s2023922332x1057539294_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2eselfHash_24s2023922332x1057539294(V v_ps_240, V v_hd_241, V v_k_242) {
top: ;
  return (g_heff_2ebuild_2ecommands_2eselfPath_24s1432537356x1686629462(heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2ecommands_2eselfHash_24s2023922332x1057539294_lam0, 1, 3, (V[]){v_hd_241, v_k_242, v_ps_240})));
}
V g_heff_2ebuild_2ecommands_2eselfHash_24s2023922332x1057539294_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eselfHash_24s2023922332x1057539294(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2ecommands_2eselfHash_24s2023922332x1057539294_lam2(V self, V *args) {
  V v_x_2416 = args[0];
  V v_ps_240 = heff_env(self)[0];
  V v_b_247 = heff_env(self)[1];
  V v_hd_241 = heff_env(self)[2];
  V v_k_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2417 = (g_heff_2ebuild_2ecommands_2eselfFrom_24s176185486x602532917(v_ps_240, v_b_247, v_x_2416));
  V f_ = v_t_2417;
  heff_room[0] = v_hd_241;
  heff_room[1] = v_k_242;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2eselfHash_24s2023922332x1057539294_lam1(V self, V *args) {
  V v_x_246 = args[0];
  V v_k_242 = heff_env(self)[0];
  V v_ps_240 = heff_env(self)[1];
  V v_hd_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_x_246)) {
  case TAG_Nothing: {
    heff_drop_rec(v_ps_240, 6);
    heff_drop(v_hd_241);
    V f_ = v_k_242;
    args[0] = ((V)&g_heff_2ebuild_2ecommands_2eselfHash_24s2023922332x1057539294_str0);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Just: {
    V v_b_247 = heff_field(v_x_246, 0);
    heff_take_n(v_x_246, 1ULL, 1);
    V v_d_248 = (g_heff_2ebuild_2ecommands_2ebackDirOf(heff_dup(v_ps_240)));
    V v_st_249 = heff_dup(heff_rfield(v_ps_240, 5));
    V v_t_2410 = (g_std_2epath_2eparse(v_st_249, v_d_248));
    V v_t_2411 = (g_std_2epath_2eparse(v_st_249, ((V)&g_heff_2ebuild_2ecommands_2eselfHash_24s2023922332x1057539294_str1)));
    V v_t_2412 = (g_std_2epath_2ejoin(v_t_2410, v_t_2411));
    V v_s_2413 = ({ V a_0 = v_st_249; V a_1 = v_t_2412; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_249); heff_drop(v_t_2412); r_; });
    V v_t_2414 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_s_2413; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
    V v_c_2415 = ({ V a_0 = v_t_2414; V r_ = (g_heff_2eutil_2efiles_2ereadFile_24s1303888535x886302188(a_0)); heff_drop(v_t_2414); r_; });
    V f_ = v_c_2415;
    heff_room[0] = heff_dup(v_hd_241);
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2eselfHash_24s2023922332x1057539294_lam2, 1, 4, (V[]){v_ps_240, v_b_247, v_hd_241, v_k_242});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_x_246);
  }
}
V g_heff_2ebuild_2ecommands_2eselfHash_24s2023922332x1057539294_lam0(V self, V *args) {
  V v_x_243 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  V v_ps_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_244 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_x_243; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
  V v_c_245 = ({ V a_0 = v_t_244; V r_ = (g_heff_2eutil_2efiles_2ereadFile_24s1303888535x886302188(a_0)); heff_drop(v_t_244); r_; });
  V f_ = v_c_245;
  heff_room[0] = heff_dup(v_hd_241);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2eselfHash_24s2023922332x1057539294_lam1, 1, 3, (V[]){v_k_242, v_ps_240, v_hd_241});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ewriteParts_24s1069210723x719436499_str0, 13, "cannot write ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ewriteParts_24s1069210723x719436499_str1, 1, "\012");
V g_heff_2ebuild_2ecommands_2ewriteParts_24s1069210723x719436499_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2ewriteParts_24s1069210723x719436499_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2ewriteParts_24s1069210723x719436499_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ewriteParts_24s1069210723x719436499_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ewriteParts_24s1069210723x719436499_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2ewriteParts_24s1069210723x719436499_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ewriteParts_24s1069210723x719436499_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewriteParts_24s1069210723x719436499_entry, 5, 0};

V g_heff_2ebuild_2ecommands_2ewriteParts_24s1069210723x719436499(V v_dir_240, V v_done_241, V v_x3_242, V v_p_243, V v_p_244) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_MkPair: {
    V v_parts_245 = heff_field(v_x3_242, 0);
    V v_errors_246 = heff_field(v_x3_242, 1);
    heff_take_n(v_x3_242, 3ULL, 2);
    return (g_heff_2ebuild_2ecommands_2eemitErrs_24s394189364x2134712221(heff_dup(v_errors_246), heff_dup(v_p_243), heff_clo_n(g_heff_2ebuild_2ecommands_2ewriteParts_24s1069210723x719436499_lam0, 1, 6, (V[]){v_errors_246, v_dir_240, v_p_243, v_parts_245, v_done_241, v_p_244})));
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2ecommands_2ewriteParts_24s1069210723x719436499_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ewriteParts_24s1069210723x719436499(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ebuild_2ecommands_2ewriteParts_24s1069210723x719436499_lam5(V self, V *args) {
  V v_x_2426 = args[0];
  V v_p_243 = heff_env(self)[0];
  V v_p_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2426);
  V v_t_2427 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2427})});
  V v_t_2429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
  V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
  V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
  V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
  V v_t_2433 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2432})});
  return (g_co_2eop_24s615738393x1686646143(heff_tag_n(TAG_InR, 1, (V[]){v_t_2433}), v_p_243, v_p_244));
}
V g_heff_2ebuild_2ecommands_2ewriteParts_24s1069210723x719436499_lam4(V self, V *args) {
  V v_x_2417 = args[0];
  V v_done_241 = heff_env(self)[0];
  V v_p_243 = heff_env(self)[1];
  V v_p_244 = heff_env(self)[2];
  V v_dir_240 = heff_env(self)[3];
  heff_clo_take(self, 4);
  if ((heff_dup(v_x_2417) == NTAG(TAG_True))) {
    heff_drop(v_x_2417);
    heff_drop(v_dir_240);
    V f_ = v_done_241;
    heff_room[0] = v_p_243;
    heff_room[1] = v_p_244;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    heff_drop(v_x_2417);
    heff_drop(v_done_241);
    V v_t_2418 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ewriteParts_24s1069210723x719436499_str0), v_dir_240), ((V)&g_heff_2ebuild_2ecommands_2ewriteParts_24s1069210723x719436499_str1));
    V v_t_2419 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2418, NTAG(TAG_MkUnit)});
    V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
    V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
    V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
    V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
    V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
    V v_t_2425 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2424})});
    return (g_co_2eop_24s615738393x1686646143(heff_tag_n(TAG_InR, 1, (V[]){v_t_2425}), heff_dup(v_p_243), heff_clo_n(g_heff_2ebuild_2ecommands_2ewriteParts_24s1069210723x719436499_lam5, 1, 2, (V[]){v_p_243, v_p_244})));
  }
}
V g_heff_2ebuild_2ecommands_2ewriteParts_24s1069210723x719436499_lam3(V self, V *args) {
  V v_x_2416 = args[0];
  V v_dir_240 = heff_env(self)[0];
  V v_parts_245 = heff_env(self)[1];
  V v_p_243 = heff_env(self)[2];
  V v_done_241 = heff_env(self)[3];
  V v_p_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2416);
  return ({ V a_0 = heff_dup(v_dir_240); V a_1 = v_parts_245; V a_2 = heff_dup(v_p_243); V a_3 = heff_clo_n(g_heff_2ebuild_2ecommands_2ewriteParts_24s1069210723x719436499_lam4, 1, 4, (V[]){v_done_241, v_p_243, v_p_244, v_dir_240}); V r_ = (g_heff_2ebuild_2ecommands_2ewritePartsGo_24s2124042284x1735199047(a_0, a_1, a_2, a_3)); heff_drop(v_parts_245); r_; });
}
V g_heff_2ebuild_2ecommands_2ewriteParts_24s1069210723x719436499_lam2(V self, V *args) {
  V v_x_2413 = args[0];
  V v_dir_240 = heff_env(self)[0];
  V v_parts_245 = heff_env(self)[1];
  V v_p_243 = heff_env(self)[2];
  V v_done_241 = heff_env(self)[3];
  V v_p_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2415;
  switch (heff_tag_of(v_x_2413)) {
  case TAG_Nothing: {
    v_t_2415 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_x_2414 = heff_field(v_x_2413, 0);
    heff_take_n(v_x_2413, 1ULL, 1);
    v_t_2415 = v_x_2414;
    break;
  }
  default: heff_nomatch(v_x_2413);
  }
  return ({ V a_0 = heff_dup(v_dir_240); V a_1 = v_parts_245; V a_2 = v_t_2415; V a_3 = heff_dup(v_p_243); V a_4 = heff_clo_n(g_heff_2ebuild_2ecommands_2ewriteParts_24s1069210723x719436499_lam3, 1, 5, (V[]){v_dir_240, heff_dup(v_parts_245), v_p_243, v_done_241, v_p_244}); V r_ = (g_heff_2ebuild_2ecommands_2eremoveStale_24s1076505188x1773366585(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_parts_245); heff_drop(v_t_2415); r_; });
}
V g_heff_2ebuild_2ecommands_2ewriteParts_24s1069210723x719436499_lam1(V self, V *args) {
  V v_x_2410 = args[0];
  V v_dir_240 = heff_env(self)[0];
  V v_p_243 = heff_env(self)[1];
  V v_parts_245 = heff_env(self)[2];
  V v_done_241 = heff_env(self)[3];
  V v_p_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2410);
  V v_t_2411 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = heff_dup(v_dir_240); V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
  V v_c_2412 = (g_heff_2eutil_2efiles_2ereadDirectory_24s297726609x1532867392(v_t_2411));
  V f_ = v_c_2412;
  heff_room[0] = heff_dup(v_p_243);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ewriteParts_24s1069210723x719436499_lam2, 1, 5, (V[]){v_dir_240, v_parts_245, v_p_243, v_done_241, v_p_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ewriteParts_24s1069210723x719436499_lam0(V self, V *args) {
  V v_x_247 = args[0];
  V v_errors_246 = heff_env(self)[0];
  V v_dir_240 = heff_env(self)[1];
  V v_p_243 = heff_env(self)[2];
  V v_parts_245 = heff_env(self)[3];
  V v_done_241 = heff_env(self)[4];
  V v_p_244 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_247);
  switch (heff_tag_of(v_errors_246)) {
  case TAG_Nil: {
    V v_t_248 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = heff_dup(v_dir_240); V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
    V v_c_249 = ({ V a_0 = v_t_248; V r_ = (g_heff_2eutil_2efiles_2emakeDirectory_24s1667989245x984665292(a_0)); heff_drop(v_t_248); r_; });
    V f_ = v_c_249;
    heff_room[0] = heff_dup(v_p_243);
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ewriteParts_24s1069210723x719436499_lam1, 1, 5, (V[]){v_dir_240, v_p_243, v_parts_245, v_done_241, v_p_244});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_Cons: {
    V v_ru_24errors_246_24Cons = heff_take_reuse_n(v_errors_246, 0ULL, 2);
    heff_drop(v_dir_240);
    heff_drop(v_parts_245);
    heff_drop(v_done_241);
    V v_t_2436 = heff_tag_at_n(v_ru_24errors_246_24Cons, TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
    V v_t_2437 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2436})});
    V v_t_2438 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2437})});
    V v_t_2439 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2438})});
    V v_t_2440 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2439})});
    V v_t_2441 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2440})});
    V v_t_2442 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2441})});
    return (g_co_2eop_24s615738393x1686646143(heff_tag_n(TAG_InR, 1, (V[]){v_t_2442}), v_p_243, v_p_244));
  }
  default: return heff_nomatch(v_errors_246);
  }
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ewriteOutC_24s1877451407x355012956_str0, 2, ".c");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ewriteOutC_24s1877451407x355012956_str1, 4, ".zig");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ewriteOutC_24s1877451407x355012956_str2, 2, ".c");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ewriteOutC_24s1877451407x355012956_str3, 13, "cannot write ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ewriteOutC_24s1877451407x355012956_str4, 4, ".zig");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ewriteOutC_24s1877451407x355012956_str5, 1, "\012");
V g_heff_2ebuild_2ecommands_2ewriteOutC_24s1877451407x355012956_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ewriteOutC_24s1877451407x355012956_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2ewriteOutC_24s1877451407x355012956_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ewriteOutC_24s1877451407x355012956_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewriteOutC_24s1877451407x355012956_entry, 6, 0};

V g_heff_2ebuild_2ecommands_2ewriteOutC_24s1877451407x355012956(V v_outPath_240, V v_zig_241, V v_done_242, V v_o_243, V v_z_244, V v_z_245) {
top: ;
  int64_t v_t_246 = (heff_unbox_word(heff_strLength_lent(v_outPath_240, 0)) - ((int64_t)2ULL));
  V v_t_247 = heff_strSlice(heff_dup(v_outPath_240), heff_box_word(v_t_246), heff_strLength_lent(v_outPath_240, 0));
  V v_t_2410;
  if (heff_strEq_c(v_t_247, ((V)&g_heff_2ebuild_2ecommands_2ewriteOutC_24s1877451407x355012956_str0))) {
    int64_t v_t_249 = (heff_unbox_word(heff_strLength_lent(v_outPath_240, 0)) - ((int64_t)2ULL));
    v_t_2410 = heff_strSlice_lent(v_outPath_240, MK_INT(0LL), heff_box_word(v_t_249), 6);
  } else {
    v_t_2410 = heff_dup(v_outPath_240);
  }
  V v_t_2411 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = heff_strAppend(v_t_2410, ((V)&g_heff_2ebuild_2ecommands_2ewriteOutC_24s1877451407x355012956_str1)); V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
  V v_c_2412 = ({ V a_0 = v_t_2411; V a_1 = v_zig_241; V r_ = (g_heff_2eutil_2efiles_2ewriteFile_24s2113411595x1300955264(a_0, a_1)); heff_drop(v_t_2411); r_; });
  return (g_heff_2ebuild_2ecommands_2ewriteOut_24s1442511881x314947241(heff_dup(v_outPath_240), heff_clo_n(g_heff_2ebuild_2ecommands_2ewriteOutC_24s1877451407x355012956_lam0, 2, 3, (V[]){v_c_2412, v_done_242, v_outPath_240}), v_o_243, v_z_244, v_z_245));
}
V g_heff_2ebuild_2ecommands_2ewriteOutC_24s1877451407x355012956_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ewriteOutC_24s1877451407x355012956(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2ebuild_2ecommands_2ewriteOutC_24s1877451407x355012956_lam2(V self, V *args) {
  V v_x_2429 = args[0];
  V v_hd_2413 = heff_env(self)[0];
  V v_k_2414 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2429);
  V v_t_2430 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2430})});
  V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
  V v_t_2433 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2432})});
  V v_t_2434 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2433})});
  V v_t_2435 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2434})});
  V v_t_2436 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2435})});
  return (g_co_2eop_24s615738393x1686646143(heff_tag_n(TAG_InR, 1, (V[]){v_t_2436}), v_hd_2413, v_k_2414));
}
V g_heff_2ebuild_2ecommands_2ewriteOutC_24s1877451407x355012956_lam1(V self, V *args) {
  V v_x_2415 = args[0];
  V v_done_242 = heff_env(self)[0];
  V v_hd_2413 = heff_env(self)[1];
  V v_k_2414 = heff_env(self)[2];
  V v_outPath_240 = heff_env(self)[3];
  heff_clo_take(self, 4);
  if ((heff_dup(v_x_2415) == NTAG(TAG_True))) {
    heff_drop(v_x_2415);
    heff_drop(v_outPath_240);
    V f_ = v_done_242;
    heff_room[0] = v_hd_2413;
    heff_room[1] = v_k_2414;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    heff_drop(v_x_2415);
    heff_drop(v_done_242);
    int64_t v_t_2416 = (heff_unbox_word(heff_strLength_lent(v_outPath_240, 0)) - ((int64_t)2ULL));
    V v_t_2417 = heff_strSlice(heff_dup(v_outPath_240), heff_box_word(v_t_2416), heff_strLength_lent(v_outPath_240, 0));
    V v_t_2420;
    if (heff_strEq_c(v_t_2417, ((V)&g_heff_2ebuild_2ecommands_2ewriteOutC_24s1877451407x355012956_str2))) {
      int64_t v_t_2419 = (heff_unbox_word(heff_strLength_lent(v_outPath_240, 0)) - ((int64_t)2ULL));
      v_t_2420 = heff_strSlice(v_outPath_240, MK_INT(0LL), heff_box_word(v_t_2419));
    } else {
      v_t_2420 = v_outPath_240;
    }
    V v_t_2421 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ewriteOutC_24s1877451407x355012956_str3), heff_strAppend(v_t_2420, ((V)&g_heff_2ebuild_2ecommands_2ewriteOutC_24s1877451407x355012956_str4)));
    V v_t_2422 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_t_2421, ((V)&g_heff_2ebuild_2ecommands_2ewriteOutC_24s1877451407x355012956_str5)), NTAG(TAG_MkUnit)});
    V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
    V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
    V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
    V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
    V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
    V v_t_2428 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2427})});
    return (g_co_2eop_24s615738393x1686646143(heff_tag_n(TAG_InR, 1, (V[]){v_t_2428}), heff_dup(v_hd_2413), heff_clo_n(g_heff_2ebuild_2ecommands_2ewriteOutC_24s1877451407x355012956_lam2, 1, 2, (V[]){v_hd_2413, v_k_2414})));
  }
}
V g_heff_2ebuild_2ecommands_2ewriteOutC_24s1877451407x355012956_lam0(V self, V *args) {
  V v_hd_2413 = args[0];
  V v_k_2414 = args[1];
  V v_c_2412 = heff_env(self)[0];
  V v_done_242 = heff_env(self)[1];
  V v_outPath_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_2412;
  args[0] = heff_dup(v_hd_2413);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ewriteOutC_24s1877451407x355012956_lam1, 1, 4, (V[]){v_done_242, v_hd_2413, v_k_2414, v_outPath_240});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2egoldenSaid_24s1045388766x363711794_str0, 1, "/");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egoldenSaid_24s1045388766x363711794_str1, 1, "/");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egoldenSaid_24s1045388766x363711794_str2, 5, "win32");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egoldenSaid_24s1045388766x363711794_str3, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egoldenSaid_24s1045388766x363711794_str4, 1, "\"");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egoldenSaid_24s1045388766x363711794_str5, 1, "\"");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egoldenSaid_24s1045388766x363711794_str6, 7, "golden ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egoldenSaid_24s1045388766x363711794_str7, 112, "a golden text's name is a file's under the directory: letters, digits, `-`, `_` and `.`, not first, between `/`s");
V g_heff_2ebuild_2ecommands_2egoldenSaid_24s1045388766x363711794_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2egoldenSaid_24s1045388766x363711794_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2egoldenSaid_24s1045388766x363711794_lam1, 1, 0};
V g_heff_2ebuild_2ecommands_2egoldenSaid_24s1045388766x363711794_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2egoldenSaid_24s1045388766x363711794_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2egoldenSaid_24s1045388766x363711794_lam0(V self, V *args);
V g_heff_2ebuild_2ecommands_2egoldenSaid_24s1045388766x363711794_lam4(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2egoldenSaid_24s1045388766x363711794_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2egoldenSaid_24s1045388766x363711794_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2egoldenSaid_24s1045388766x363711794(V v_update_240, V v_f_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_MkPair: {
    V v_name_243 = heff_field(v_x3_242, 0);
    V v_text_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24MkPair = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_t_245 = ({ V b_0 = ((V)&g_heff_2ebuild_2ecommands_2egoldenSaid_24s1045388766x363711794_str0); V a_1 = v_name_243; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2ecommands_2egoldenSaid_24s1045388766x363711794_str1), v_name_243, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
    V v_x1_246 = ({ V a_0 = v_t_245; V r_ = (g_list_2eall_24s523006110x1088755562(a_0)); heff_drop(v_t_245); r_; });
    if ((heff_dup(v_x1_246) == NTAG(TAG_True))) {
      heff_drop_cell(v_ru_24x3_242_24MkPair, 2);
      heff_drop(v_x1_246);
      return heff_clo_n(g_heff_2ebuild_2ecommands_2egoldenSaid_24s1045388766x363711794_lam0, 2, 4, (V[]){v_f_241, v_name_243, heff_dup(v_update_240), v_text_244});
    } else {
      heff_drop(v_f_241);
      heff_drop(v_text_244);
      heff_drop(v_x1_246);
      V v_t_2438 = ({ V a_0 = v_name_243; V a_1 = MK_INT(0LL); V a_2 = ((V)&g_heff_2ebuild_2ecommands_2egoldenSaid_24s1045388766x363711794_str3); V r_ = (g_prelude_2einstanceShowString_2eescapedFrom_241(a_0, a_1, a_2)); heff_drop(v_name_243); r_; });
      V v_t_2439 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2egoldenSaid_24s1045388766x363711794_str4), heff_strAppend(v_t_2438, ((V)&g_heff_2ebuild_2ecommands_2egoldenSaid_24s1045388766x363711794_str5)));
      V v_x_2440 = heff_tag_at_n(v_ru_24x3_242_24MkPair, TAG_Wrong, 2, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2egoldenSaid_24s1045388766x363711794_str6), v_t_2439), heff_tag_n(TAG_FailBecause, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2egoldenSaid_24s1045388766x363711794_str7)})});
      return heff_clo_n(g_heff_2ebuild_2ecommands_2egoldenSaid_24s1045388766x363711794_lam4, 2, 1, (V[]){v_x_2440});
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2ecommands_2egoldenSaid_24s1045388766x363711794_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2egoldenSaid_24s1045388766x363711794(a0, a[1], a[2]); heff_drop(a0); return r;
}
V g_heff_2ebuild_2ecommands_2egoldenSaid_24s1045388766x363711794_lam1(V self, V *args) {
  V v_s_249 = args[0];
  return v_s_249;
}
V g_heff_2ebuild_2ecommands_2egoldenSaid_24s1045388766x363711794_lam3(V self, V *args) {
  V v_x_2423 = args[0];
  V v_st_2419 = heff_env(self)[0];
  V v_f_241 = heff_env(self)[1];
  V v_name_243 = heff_env(self)[2];
  V v_update_240 = heff_env(self)[3];
  V v_text_244 = heff_env(self)[4];
  V v_hd_247 = heff_env(self)[5];
  V v_k_248 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_s_2424 = (g_heff_2ebuild_2ecommands_2egoldenPath(v_st_2419, heff_dup(v_f_241), heff_dup(v_name_243)));
  HeffT3 v_t_2425 = (g_std_2epath_2eparse_24cpr(v_st_2419, v_s_2424));
  V v_t_2435;
  {
    V v_field_2426 = v_t_2425.f[0];
    V v_field_2427 = v_t_2425.f[1];
    V v_field_2428 = v_t_2425.f[2];
    V v_d_2429 = v_field_2426;
    V v_a_2430 = v_field_2427;
    V v_xs_2431 = v_field_2428;
    V v_t_2432 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2431));
    V v_xs_2433 = ({ V a_0 = MK_INT(1LL); V a_1 = v_t_2432; V r_ = (g_list_2edrop(a_0, a_1)); heff_drop(v_t_2432); r_; });
    V v_t_2434 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2433));
    v_t_2435 = heff_tag_n(TAG_MkPath, 3, (V[]){v_d_2429, v_a_2430, v_t_2434});
  }
  V v_t_2436 = ({ V a_0 = v_st_2419; V a_1 = v_t_2435; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2435); r_; });
  V v_t_2437 = ({ V a_0 = v_st_2419; V a_1 = v_f_241; V a_2 = v_name_243; V r_ = (g_heff_2ebuild_2ecommands_2egoldenPath(a_0, a_1, a_2)); heff_drop(v_st_2419); r_; });
  return ({ V a_0 = v_update_240; V a_1 = v_t_2436; V a_2 = v_t_2437; V a_3 = v_text_244; V a_4 = v_x_2423; V a_5 = v_hd_247; V a_6 = v_k_248; V r_ = (g_heff_2ebuild_2ecommands_2egoldenAgainst_24s992520432x896454450(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_update_240); r_; });
}
V g_heff_2ebuild_2ecommands_2egoldenSaid_24s1045388766x363711794_lam2(V self, V *args) {
  V v_x_2417 = args[0];
  V v_f_241 = heff_env(self)[0];
  V v_name_243 = heff_env(self)[1];
  V v_hd_247 = heff_env(self)[2];
  V v_update_240 = heff_env(self)[3];
  V v_text_244 = heff_env(self)[4];
  V v_k_248 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_st_2419;
  if (heff_strEq_c(v_x_2417, ((V)&g_heff_2ebuild_2ecommands_2egoldenSaid_24s1045388766x363711794_str2))) {
    v_st_2419 = NTAG(TAG_Windows);
  } else {
    v_st_2419 = NTAG(TAG_Posix);
  }
  V v_s_2420 = (g_heff_2ebuild_2ecommands_2egoldenPath(v_st_2419, heff_dup(v_f_241), heff_dup(v_name_243)));
  V v_t_2421 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_s_2420; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
  V v_c_2422 = ({ V a_0 = v_t_2421; V r_ = (g_heff_2eutil_2efiles_2ereadFile_24s1303888535x886302188(a_0)); heff_drop(v_t_2421); r_; });
  V f_ = v_c_2422;
  heff_room[0] = heff_dup(v_hd_247);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2egoldenSaid_24s1045388766x363711794_lam3, 1, 7, (V[]){v_st_2419, v_f_241, v_name_243, v_update_240, v_text_244, v_hd_247, v_k_248});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2egoldenSaid_24s1045388766x363711794_lam0(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_f_241 = heff_env(self)[0];
  V v_name_243 = heff_env(self)[1];
  V v_update_240 = heff_env(self)[2];
  V v_text_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2410 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2egoldenSaid_24s1045388766x363711794_lam1_clo)})});
  V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
  V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
  V v_t_2415 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
  V v_t_2416 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2415})});
  return (g_co_2eop_24s615738393x1686646143(v_t_2416, heff_dup(v_hd_247), heff_clo_n(g_heff_2ebuild_2ecommands_2egoldenSaid_24s1045388766x363711794_lam2, 1, 6, (V[]){v_f_241, v_name_243, v_hd_247, v_update_240, v_text_244, v_k_248})));
}
V g_heff_2ebuild_2ecommands_2egoldenSaid_24s1045388766x363711794_lam4(V self, V *args) {
  V v_hd_2441 = args[0];
  V v_k_2442 = args[1];
  V v_x_2440 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2441);
  V f_ = v_k_2442;
  args[0] = v_x_2440;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ewithGoldens_24s1327649047x255568769_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ewithGoldens_24s1327649047x255568769_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewithGoldens_24s1327649047x255568769_lam0, 2, 0};
V g_heff_2ebuild_2ecommands_2ewithGoldens_24s1327649047x255568769_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2ewithGoldens_24s1327649047x255568769_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2ewithGoldens_24s1327649047x255568769_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ewithGoldens_24s1327649047x255568769_lam2(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ewithGoldens_24s1327649047x255568769_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewithGoldens_24s1327649047x255568769_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2ewithGoldens_24s1327649047x255568769(V v_update_240, V v_f_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_f_241);
    return ((V)&g_heff_2ebuild_2ecommands_2ewithGoldens_24s1327649047x255568769_lam0_clo);
  }
  case TAG_Cons: {
    V v_o_245 = heff_field(v_x3_242, 0);
    V v_rest_246 = heff_field(v_x3_242, 1);
    heff_take_n(v_x3_242, 3ULL, 2);
    V v_t_247 = heff_dup(heff_rfield(v_o_245, 1));
    V v_c_2410;
    if ((heff_dup(v_t_247) == NTAG(TAG_True))) {
      heff_drop(v_t_247);
      v_c_2410 = (g_heff_2ebuild_2ecommands_2egoldensGo_24s1881795521x39532647(v_update_240, heff_dup(v_f_241), heff_dup(v_o_245), heff_get_n(v_o_245, 11, 12)));
    } else {
      heff_drop(v_t_247);
      v_c_2410 = heff_clo_n(g_heff_2ebuild_2ecommands_2ewithGoldens_24s1327649047x255568769_lam1, 2, 1, (V[]){v_o_245});
    }
    return heff_clo_n(g_heff_2ebuild_2ecommands_2ewithGoldens_24s1327649047x255568769_lam2, 2, 4, (V[]){v_c_2410, heff_dup(v_update_240), v_f_241, v_rest_246});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2ecommands_2ewithGoldens_24s1327649047x255568769_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2ewithGoldens_24s1327649047x255568769(a0, a[1], a[2]); heff_drop(a0); return r;
}
V g_heff_2ebuild_2ecommands_2ewithGoldens_24s1327649047x255568769_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  heff_drop(v_hd_243);
  V f_ = v_k_244;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ewithGoldens_24s1327649047x255568769_lam1(V self, V *args) {
  V v_hd_248 = args[0];
  V v_k_249 = args[1];
  V v_o_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_248);
  V f_ = v_k_249;
  args[0] = v_o_245;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ewithGoldens_24s1327649047x255568769_lam4(V self, V *args) {
  V v_x_2415 = args[0];
  V v_k_2412 = heff_env(self)[0];
  V v_x_2413 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_2412;
  args[0] = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2413, v_x_2415});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ewithGoldens_24s1327649047x255568769_lam3(V self, V *args) {
  V v_x_2413 = args[0];
  V v_update_240 = heff_env(self)[0];
  V v_f_241 = heff_env(self)[1];
  V v_rest_246 = heff_env(self)[2];
  V v_hd_2411 = heff_env(self)[3];
  V v_k_2412 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_c_2414 = ({ V a_0 = v_update_240; V a_1 = v_f_241; V a_2 = v_rest_246; V r_ = (g_heff_2ebuild_2ecommands_2ewithGoldens_24s1327649047x255568769(a_0, a_1, a_2)); heff_drop(v_update_240); r_; });
  V f_ = v_c_2414;
  heff_room[0] = v_hd_2411;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ewithGoldens_24s1327649047x255568769_lam4, 1, 2, (V[]){v_k_2412, v_x_2413});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ewithGoldens_24s1327649047x255568769_lam2(V self, V *args) {
  V v_hd_2411 = args[0];
  V v_k_2412 = args[1];
  V v_c_2410 = heff_env(self)[0];
  V v_update_240 = heff_env(self)[1];
  V v_f_241 = heff_env(self)[2];
  V v_rest_246 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_2410;
  args[0] = heff_dup(v_hd_2411);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ewithGoldens_24s1327649047x255568769_lam3, 1, 5, (V[]){v_update_240, v_f_241, v_rest_246, v_hd_2411, v_k_2412});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprintFails_24s1263841563x776765553_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprintFails_24s1263841563x776765553_str1, 1, "\012");
V g_heff_2ebuild_2ecommands_2eprintFails_24s1263841563x776765553_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eprintFails_24s1263841563x776765553_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eprintFails_24s1263841563x776765553_lam0, 2, 0};
V g_heff_2ebuild_2ecommands_2eprintFails_24s1263841563x776765553_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eprintFails_24s1263841563x776765553_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eprintFails_24s1263841563x776765553_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2eprintFails_24s1263841563x776765553(V v_f_240, V v_color_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_f_240);
    return ((V)&g_heff_2ebuild_2ecommands_2eprintFails_24s1263841563x776765553_lam0_clo);
  }
  case TAG_Cons: {
    V v_r_245 = heff_field(v_x3_242, 0);
    V v_rest_246 = heff_field(v_x3_242, 1);
    heff_take_n(v_x3_242, 3ULL, 2);
    V v_t_247 = heff_get_n(heff_dup(heff_rfield(v_r_245, 2)), 5, 10);
    V v_t_249;
    switch (heff_tag_of(v_t_247)) {
    case TAG_Nothing: {
      v_t_249 = ((V)&g_heff_2ebuild_2ecommands_2eprintFails_24s1263841563x776765553_str0);
      break;
    }
    case TAG_Just: {
      V v_x_248 = heff_field(v_t_247, 0);
      heff_take_n(v_t_247, 1ULL, 1);
      v_t_249 = v_x_248;
      break;
    }
    default: heff_nomatch(v_t_247);
    }
    V v_t_2410 = heff_get_n(heff_dup(heff_rfield(v_r_245, 2)), 4, 10);
    V v_t_2411 = ({ V a_0 = v_color_241; V a_1 = v_t_249; V a_2 = v_t_2410; V r_ = (g_heff_2elsp_2ereport_2emismatch(a_0, a_1, a_2)); heff_drop(v_t_249); heff_drop(v_t_2410); r_; });
    V v_str_2412 = (g_heff_2ebuild_2ecommands_2efailLine(heff_dup(v_f_240), v_r_245, v_t_2411));
    return heff_clo_n(g_heff_2ebuild_2ecommands_2eprintFails_24s1263841563x776765553_lam1, 2, 4, (V[]){v_str_2412, v_f_240, heff_dup(v_color_241), v_rest_246});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2ecommands_2eprintFails_24s1263841563x776765553_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2ecommands_2eprintFails_24s1263841563x776765553(a[0], a1, a[2]); heff_drop(a1); return r;
}
V g_heff_2ebuild_2ecommands_2eprintFails_24s1263841563x776765553_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  heff_drop(v_hd_243);
  V f_ = v_k_244;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eprintFails_24s1263841563x776765553_lam1(V self, V *args) {
  V v_hd_2413 = args[0];
  V v_k_2414 = args[1];
  V v_str_2412 = heff_env(self)[0];
  V v_f_240 = heff_env(self)[1];
  V v_color_241 = heff_env(self)[2];
  V v_rest_246 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2415 = heff_tag_n(TAG_Write, 2, (V[]){heff_strAppend(v_str_2412, ((V)&g_heff_2ebuild_2ecommands_2eprintFails_24s1263841563x776765553_str1)), NTAG(TAG_MkUnit)});
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
  V v_t_2421 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2420})});
  return ({ V a_0 = v_f_240; V a_1 = v_color_241; V a_2 = v_rest_246; V a_3 = heff_dup(v_hd_2413); V a_4 = v_k_2414; V a_5 = heff_tag_n(TAG_InR, 1, (V[]){v_t_2421}); V a_6 = v_hd_2413; V r_ = (g_co_2eop_24s710864882x261522381(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_color_241); r_; });
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ediagCount_24s823746706x1248851912_str0, 2, ": ");
V g_heff_2ebuild_2ecommands_2ediagCount_24s823746706x1248851912_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ediagCount_24s823746706x1248851912_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ediagCount_24s823746706x1248851912_lam0, 2, 0};
V g_heff_2ebuild_2ecommands_2ediagCount_24s823746706x1248851912_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ediagCount_24s823746706x1248851912_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ediagCount_24s823746706x1248851912_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ediagCount_24s823746706x1248851912_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ediagCount_24s823746706x1248851912_entry, 1, 0};

V g_heff_2ebuild_2ecommands_2ediagCount_24s823746706x1248851912(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return ((V)&g_heff_2ebuild_2ecommands_2ediagCount_24s823746706x1248851912_lam0_clo);
  }
  case TAG_Cons: {
    V v_c_243 = heff_field(v_x1_240, 0);
    V v_rest_244 = heff_field(v_x1_240, 1);
    V v_t_245 = (g_list_2emap_24s370939663x1496042695(((V)&g_heff_2ebuild_2ecommands_2ediagCount_24s823746706x1248851912_str0), heff_dup(heff_rfield(v_c_243, 6))));
    return heff_clo_n(g_heff_2ebuild_2ecommands_2ediagCount_24s823746706x1248851912_lam1, 2, 3, (V[]){heff_dup(v_c_243), v_t_245, heff_dup(v_rest_244)});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2ecommands_2ediagCount_24s823746706x1248851912_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2ediagCount_24s823746706x1248851912(a0); heff_drop(a0); return r;
}
V g_heff_2ebuild_2ecommands_2ediagCount_24s823746706x1248851912_lam0(V self, V *args) {
  V v_hd_241 = args[0];
  V v_k_242 = args[1];
  heff_drop(v_hd_241);
  V f_ = v_k_242;
  args[0] = MK_INT(0LL);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ediagCount_24s823746706x1248851912_lam3(V self, V *args) {
  V v_x_2410 = args[0];
  V v_c_243 = heff_env(self)[0];
  V v_k_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2411 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V b_2 = heff_get_n(v_c_243, 6, 14); V r_ = (g_list_2efoldl_24f2094160282x1876485468(a_0, a_1, b_2)); heff_drop(b_2); r_; });
  V v_x_2412 = heff_intAdd(v_t_2411, v_x_2410);
  V f_ = v_k_247;
  args[0] = v_x_2412;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ediagCount_24s823746706x1248851912_lam2(V self, V *args) {
  V v_x_248 = args[0];
  V v_rest_244 = heff_env(self)[0];
  V v_hd_246 = heff_env(self)[1];
  V v_c_243 = heff_env(self)[2];
  V v_k_247 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_248);
  V v_c_249 = ({ V a_0 = v_rest_244; V r_ = (g_heff_2ebuild_2ecommands_2ediagCount_24s823746706x1248851912(a_0)); heff_drop(v_rest_244); r_; });
  V f_ = v_c_249;
  heff_room[0] = v_hd_246;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ediagCount_24s823746706x1248851912_lam3, 1, 2, (V[]){v_c_243, v_k_247});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ediagCount_24s823746706x1248851912_lam1(V self, V *args) {
  V v_hd_246 = args[0];
  V v_k_247 = args[1];
  V v_c_243 = heff_env(self)[0];
  V v_t_245 = heff_env(self)[1];
  V v_rest_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2ebuild_2ecommands_2eprintErrs_24s115117455x797094904(heff_dup(heff_rfield(v_c_243, 0)), v_t_245, MK_INT(0LL), heff_dup(v_hd_246), heff_clo_n(g_heff_2ebuild_2ecommands_2ediagCount_24s823746706x1248851912_lam2, 1, 4, (V[]){v_rest_244, v_hd_246, v_c_243, v_k_247})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2edocPagesWritten_24s186486549x585078911_str0, 5, "win32");
HEFF_LIT(g_heff_2ebuild_2ecommands_2edocPagesWritten_24s186486549x585078911_str1, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2edocPagesWritten_24s186486549x585078911_str2, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2edocPagesWritten_24s186486549x585078911_str3, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2edocPagesWritten_24s186486549x585078911_str4, 1, "/");
HEFF_LIT(g_heff_2ebuild_2ecommands_2edocPagesWritten_24s186486549x585078911_str5, 3, ".md");
V g_heff_2ebuild_2ecommands_2edocPagesWritten_24s186486549x585078911_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2edocPagesWritten_24s186486549x585078911_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2edocPagesWritten_24s186486549x585078911_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2edocPagesWritten_24s186486549x585078911_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2edocPagesWritten_24s186486549x585078911_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2edocPagesWritten_24s186486549x585078911_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2edocPagesWritten_24s186486549x585078911_entry, 6, 0};

V g_heff_2ebuild_2ecommands_2edocPagesWritten_24s186486549x585078911(V v_prog_240, V v_w_241, V v_dir_242, V v_x3_243, V v_p_244, V v_p_245) {
top: ;
  switch (heff_tag_of(v_x3_243)) {
  case TAG_Nil: {
    heff_drop(v_prog_240);
    heff_drop(v_w_241);
    heff_drop(v_dir_242);
    heff_drop(v_p_244);
    return heff_tail(v_p_245, 1, (V[]){NTAG(TAG_MkUnit)});
  }
  case TAG_Cons: {
    V v_c_246 = heff_field(v_x3_243, 0);
    V v_rest_247 = heff_field(v_x3_243, 1);
    heff_take_n(v_x3_243, 3ULL, 2);
    V v_t_249 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2edocPagesWritten_24s186486549x585078911_lam0_clo)})});
    V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
    V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
    V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
    V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
    V v_t_2414 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
    V v_t_2415 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2414})});
    return (g_co_2eop_24s615738393x1686646143(v_t_2415, heff_dup(v_p_244), heff_clo_n(g_heff_2ebuild_2ecommands_2edocPagesWritten_24s186486549x585078911_lam1, 1, 7, (V[]){v_c_246, v_dir_242, v_p_244, v_w_241, v_prog_240, v_rest_247, v_p_245})));
  }
  default: return heff_nomatch(v_x3_243);
  }
}
V g_heff_2ebuild_2ecommands_2edocPagesWritten_24s186486549x585078911_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2edocPagesWritten_24s186486549x585078911(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2ebuild_2ecommands_2edocPagesWritten_24s186486549x585078911_lam0(V self, V *args) {
  V v_s_248 = args[0];
  return v_s_248;
}
V g_heff_2ebuild_2ecommands_2edocPagesWritten_24s186486549x585078911_lam2(V self, V *args) {
  V v_x_2430 = args[0];
  V v_w_241 = heff_env(self)[0];
  V v_prog_240 = heff_env(self)[1];
  V v_dir_242 = heff_env(self)[2];
  V v_rest_247 = heff_env(self)[3];
  V v_p_244 = heff_env(self)[4];
  V v_p_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_2430);
  V v_t_2431 = heff_tag_n(TAG_Complete, 2, (V[]){heff_dup(v_w_241), NTAG(TAG_MkUnit)});
  V v_t_2432 = heff_tr(heff_call(heff_dup(v_prog_240), 1, (V[]){v_t_2431}));
  return (g_co_2eop_24s1204515794x2100690815(v_prog_240, v_w_241, v_dir_242, v_rest_247, heff_dup(v_p_244), v_p_245, v_t_2432, v_p_244));
}
V g_heff_2ebuild_2ecommands_2edocPagesWritten_24s186486549x585078911_lam1(V self, V *args) {
  V v_x_2416 = args[0];
  V v_c_246 = heff_env(self)[0];
  V v_dir_242 = heff_env(self)[1];
  V v_p_244 = heff_env(self)[2];
  V v_w_241 = heff_env(self)[3];
  V v_prog_240 = heff_env(self)[4];
  V v_rest_247 = heff_env(self)[5];
  V v_p_245 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_st_2418;
  if (heff_strEq_c(v_x_2416, ((V)&g_heff_2ebuild_2ecommands_2edocPagesWritten_24s186486549x585078911_str0))) {
    v_st_2418 = NTAG(TAG_Windows);
  } else {
    v_st_2418 = NTAG(TAG_Posix);
  }
  V v_m_2419 = heff_dup(heff_rfield(v_c_246, 0));
  V v_x2_2420 = ({ V b_0 = ((V)&g_heff_2ebuild_2ecommands_2edocPagesWritten_24s186486549x585078911_str1); V a_1 = v_m_2419; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2ecommands_2edocPagesWritten_24s186486549x585078911_str2), v_m_2419, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); heff_drop(v_m_2419); r_; });
  V v_t_2423;
  switch (heff_tag_of(v_x2_2420)) {
  case TAG_Nil: {
    v_t_2423 = ((V)&g_heff_2ebuild_2ecommands_2edocPagesWritten_24s186486549x585078911_str3);
    break;
  }
  case TAG_Cons: {
    V v_x_2421 = heff_field(v_x2_2420, 0);
    V v_xs_2422 = heff_field(v_x2_2420, 1);
    heff_take_n(v_x2_2420, 3ULL, 2);
    v_t_2423 = ({ V a_0 = ((V)&g_heff_2ebuild_2ecommands_2edocPagesWritten_24s186486549x585078911_str4); V a_1 = v_x_2421; V a_2 = v_xs_2422; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2422); r_; });
    break;
  }
  default: heff_nomatch(v_x2_2420);
  }
  V v_b_2424 = heff_strAppend(v_t_2423, ((V)&g_heff_2ebuild_2ecommands_2edocPagesWritten_24s186486549x585078911_str5));
  V v_t_2425 = (g_std_2epath_2eparse(v_st_2418, heff_dup(v_dir_242)));
  V v_t_2426 = (g_std_2epath_2eparse(v_st_2418, v_b_2424));
  V v_t_2427 = (g_std_2epath_2ejoin(v_t_2425, v_t_2426));
  V v_t_2428 = ({ V a_0 = v_st_2418; V a_1 = v_t_2427; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2418); heff_drop(v_t_2427); r_; });
  V v_t_2429 = (g_heff_2ebuild_2edocpages_2epage(v_c_246));
  return (g_heff_2ebuild_2ecommands_2edocPageWritten_24s1466416307x1099964288(v_t_2428, v_t_2429, heff_dup(v_p_244), heff_clo_n(g_heff_2ebuild_2ecommands_2edocPagesWritten_24s186486549x585078911_lam2, 1, 6, (V[]){v_w_241, v_prog_240, v_dir_242, v_rest_247, v_p_244, v_p_245})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eexisting_24s783863025x1958439471_str0, 5, "win32");
V g_heff_2ebuild_2ecommands_2eexisting_24s783863025x1958439471_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eexisting_24s783863025x1958439471_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eexisting_24s783863025x1958439471_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2eexisting_24s783863025x1958439471_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2eexisting_24s783863025x1958439471_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2eexisting_24s783863025x1958439471_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eexisting_24s783863025x1958439471_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eexisting_24s783863025x1958439471_entry, 4, 0};

V g_heff_2ebuild_2ecommands_2eexisting_24s783863025x1958439471(V v_dir_240, V v_x2_241, V v_p_242, V v_p_243) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_dir_240);
    heff_drop(v_p_242);
    return heff_tail(v_p_243, 1, (V[]){NTAG(TAG_Nil)});
  }
  case TAG_Cons: {
    V v_x21_244 = heff_field(v_x2_241, 0);
    V v_rest_245 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_244)) {
    case TAG_MkPair: {
      V v_f_246 = heff_field(v_x21_244, 0);
      heff_take_n(v_x21_244, 1ULL, 2);
      V v_t_249 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2eexisting_24s783863025x1958439471_lam0_clo)})});
      V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
      V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
      V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
      V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
      V v_t_2414 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
      V v_t_2415 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2414})});
      return (g_co_2eop_24s615738393x1686646143(v_t_2415, heff_dup(v_p_242), heff_clo_n(g_heff_2ebuild_2ecommands_2eexisting_24s783863025x1958439471_lam1, 1, 5, (V[]){v_dir_240, v_f_246, v_p_242, v_rest_245, v_p_243})));
    }
    default: return heff_nomatch(v_x21_244);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2ecommands_2eexisting_24s783863025x1958439471_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eexisting_24s783863025x1958439471(a[0], a[1], a[2], a[3]);
}
V g_heff_2ebuild_2ecommands_2eexisting_24s783863025x1958439471_lam0(V self, V *args) {
  V v_s_248 = args[0];
  return v_s_248;
}
V g_heff_2ebuild_2ecommands_2eexisting_24s783863025x1958439471_lam3(V self, V *args) {
  V v_x_2426 = args[0];
  V v_x_2425 = heff_env(self)[0];
  V v_p_243 = heff_env(self)[1];
  V v_f_246 = heff_env(self)[2];
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_x_2425)) {
  case TAG_Nothing: {
    heff_drop(v_f_246);
    V f_ = v_p_243;
    args[0] = v_x_2426;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Just: {
    heff_take_n(v_x_2425, 0ULL, 1);
    V f_ = v_p_243;
    args[0] = heff_tag_n(TAG_Cons, 2, (V[]){v_f_246, v_x_2426});
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_2425);
  }
}
V g_heff_2ebuild_2ecommands_2eexisting_24s783863025x1958439471_lam2(V self, V *args) {
  V v_x_2425 = args[0];
  V v_dir_240 = heff_env(self)[0];
  V v_rest_245 = heff_env(self)[1];
  V v_p_242 = heff_env(self)[2];
  V v_p_243 = heff_env(self)[3];
  V v_f_246 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2ebuild_2ecommands_2eexisting_24s783863025x1958439471(v_dir_240, v_rest_245, v_p_242, heff_clo_n(g_heff_2ebuild_2ecommands_2eexisting_24s783863025x1958439471_lam3, 1, 3, (V[]){v_x_2425, v_p_243, v_f_246})));
}
V g_heff_2ebuild_2ecommands_2eexisting_24s783863025x1958439471_lam1(V self, V *args) {
  V v_x_2416 = args[0];
  V v_dir_240 = heff_env(self)[0];
  V v_f_246 = heff_env(self)[1];
  V v_p_242 = heff_env(self)[2];
  V v_rest_245 = heff_env(self)[3];
  V v_p_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_st_2418;
  if (heff_strEq_c(v_x_2416, ((V)&g_heff_2ebuild_2ecommands_2eexisting_24s783863025x1958439471_str0))) {
    v_st_2418 = NTAG(TAG_Windows);
  } else {
    v_st_2418 = NTAG(TAG_Posix);
  }
  V v_t_2419 = (g_std_2epath_2eparse(v_st_2418, heff_dup(v_dir_240)));
  V v_t_2420 = (g_std_2epath_2eparse(v_st_2418, heff_dup(v_f_246)));
  V v_t_2421 = (g_std_2epath_2ejoin(v_t_2419, v_t_2420));
  V v_s_2422 = ({ V a_0 = v_st_2418; V a_1 = v_t_2421; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2418); heff_drop(v_t_2421); r_; });
  V v_t_2423 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_s_2422; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
  V v_c_2424 = ({ V a_0 = v_t_2423; V r_ = (g_heff_2eutil_2efiles_2ereadFile_24s1303888535x886302188(a_0)); heff_drop(v_t_2423); r_; });
  V f_ = v_c_2424;
  heff_room[0] = heff_dup(v_p_242);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2eexisting_24s783863025x1958439471_lam2, 1, 5, (V[]){v_dir_240, v_rest_245, v_p_242, v_p_243, v_f_246});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2einitCmd_24s795893522x1842903301_str0, 5, "win32");
HEFF_LIT(g_heff_2ebuild_2ecommands_2einitCmd_24s795893522x1842903301_str1, 5, "0.1.0");
HEFF_LIT(g_heff_2ebuild_2ecommands_2einitCmd_24s795893522x1842903301_str2, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2einitCmd_24s795893522x1842903301_str3, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2einitCmd_24s795893522x1842903301_str4, 23, "heff: a new project in ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2einitCmd_24s795893522x1842903301_str5, 56, "; there, `heff build` builds it and `heff test` tests it");
HEFF_LIT(g_heff_2ebuild_2ecommands_2einitCmd_24s795893522x1842903301_str6, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2einitCmd_24s795893522x1842903301_str7, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2einitCmd_24s795893522x1842903301_str8, 2, ", ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2einitCmd_24s795893522x1842903301_str9, 5, " has ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2einitCmd_24s795893522x1842903301_str10, 25, " already; nothing written");
HEFF_LIT(g_heff_2ebuild_2ecommands_2einitCmd_24s795893522x1842903301_str11, 6, "heff: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2einitCmd_24s795893522x1842903301_str12, 1, "\012");
V g_heff_2ebuild_2ecommands_2einitCmd_24s795893522x1842903301_lam3(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2einitCmd_24s795893522x1842903301_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2einitCmd_24s795893522x1842903301_lam3, 1, 0};
V g_heff_2ebuild_2ecommands_2einitCmd_24s795893522x1842903301_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2einitCmd_24s795893522x1842903301_lam7(V self, V *args);
V g_heff_2ebuild_2ecommands_2einitCmd_24s795893522x1842903301_lam8(V self, V *args);
V g_heff_2ebuild_2ecommands_2einitCmd_24s795893522x1842903301_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2einitCmd_24s795893522x1842903301_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2einitCmd_24s795893522x1842903301_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2einitCmd_24s795893522x1842903301_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2einitCmd_24s795893522x1842903301_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2einitCmd_24s795893522x1842903301_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2einitCmd_24s795893522x1842903301_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2einitCmd_24s795893522x1842903301(V v_dir_240, V v_hd_241, V v_k_242) {
top: ;
  return (g_heff_2ebuild_2ecommands_2ecwdNow_24s507786937x461532604(heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2ecommands_2einitCmd_24s795893522x1842903301_lam0, 1, 3, (V[]){v_hd_241, v_dir_240, v_k_242})));
}
V g_heff_2ebuild_2ecommands_2einitCmd_24s795893522x1842903301_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2einitCmd_24s795893522x1842903301(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2ecommands_2einitCmd_24s795893522x1842903301_lam3(V self, V *args) {
  V v_s_2422 = args[0];
  return v_s_2422;
}
V g_heff_2ebuild_2ecommands_2einitCmd_24s795893522x1842903301_lam6(V self, V *args) {
  V v_x_2452 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2452);
  V v_t_2453 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2454 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2453})});
  V v_t_2455 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2454})});
  V v_t_2456 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2455})});
  V v_t_2457 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2456})});
  V v_t_2458 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2457})});
  V v_t_2459 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2458})});
  return (g_co_2eop_24s615738393x1686646143(heff_tag_n(TAG_InR, 1, (V[]){v_t_2459}), v_hd_241, v_k_242));
}
V g_heff_2ebuild_2ecommands_2einitCmd_24s795893522x1842903301_lam7(V self, V *args) {
  V v_x_2460 = args[0];
  V v_dir_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  if ((heff_dup(v_x_2460) == NTAG(TAG_True))) {
    heff_drop(v_x_2460);
    V v_t_2461 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2einitCmd_24s795893522x1842903301_str4), heff_strAppend(v_dir_240, ((V)&g_heff_2ebuild_2ecommands_2einitCmd_24s795893522x1842903301_str5)));
    V v_t_2462 = heff_tag_n(TAG_Write, 2, (V[]){heff_strAppend(v_t_2461, ((V)&g_heff_2ebuild_2ecommands_2einitCmd_24s795893522x1842903301_str6)), NTAG(TAG_MkUnit)});
    V v_t_2463 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2462})});
    V v_t_2464 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2463})});
    V v_t_2465 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2464})});
    V v_t_2466 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2465})});
    V v_t_2467 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2466})});
    V v_t_2468 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2467})});
    return (g_co_2eop_24s615738393x1686646143(heff_tag_n(TAG_InR, 1, (V[]){v_t_2468}), v_hd_241, v_k_242));
  } else {
    heff_drop(v_x_2460);
    heff_drop(v_dir_240);
    V v_t_2469 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
    V v_t_2470 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2469})});
    V v_t_2471 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2470})});
    V v_t_2472 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2471})});
    V v_t_2473 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2472})});
    V v_t_2474 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2473})});
    V v_t_2475 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2474})});
    return (g_co_2eop_24s615738393x1686646143(heff_tag_n(TAG_InR, 1, (V[]){v_t_2475}), v_hd_241, v_k_242));
  }
}
V g_heff_2ebuild_2ecommands_2einitCmd_24s795893522x1842903301_lam8(V self, V *args) {
  V v_x_2490 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2490);
  V v_t_2491 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2492 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2491})});
  V v_t_2493 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2492})});
  V v_t_2494 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2493})});
  V v_t_2495 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2494})});
  V v_t_2496 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2495})});
  V v_t_2497 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2496})});
  return (g_co_2eop_24s615738393x1686646143(heff_tag_n(TAG_InR, 1, (V[]){v_t_2497}), v_hd_241, v_k_242));
}
V g_heff_2ebuild_2ecommands_2einitCmd_24s795893522x1842903301_lam5(V self, V *args) {
  V v_x_2437 = args[0];
  V v_dir_240 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  V v_x_2433 = heff_env(self)[2];
  V v_hd_241 = heff_env(self)[3];
  V v_k_242 = heff_env(self)[4];
  V v_x_2436 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2439;
  if (heff_strEq_c_lent(v_dir_240, ((V)&g_heff_2ebuild_2ecommands_2einitCmd_24s795893522x1842903301_str2), 2)) {
    v_t_2439 = v_x_243;
  } else {
    heff_drop(v_x_243);
    v_t_2439 = heff_dup(v_dir_240);
  }
  HeffT2 v_t_2440 = (g_heff_2ebuild_2ecommands_2einitProblem_24cpr(v_t_2439, v_x_2433));
  {
    V v_field_2442 = v_t_2440.f[1];
    int64_t v_tag_2441 = ((int64_t)v_t_2440.f[0]);
    if ((v_tag_2441 == ((int64_t)0ULL))) {
      heff_drop(v_x_2437);
      heff_drop(v_dir_240);
      heff_drop(v_x_2436);
      V v_why_2444 = v_field_2442;
      V v_t_2445 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_why_2444, ((V)&g_heff_2ebuild_2ecommands_2einitCmd_24s795893522x1842903301_str3)), NTAG(TAG_MkUnit)});
      V v_t_2446 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2445})});
      V v_t_2447 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2446})});
      V v_t_2448 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2447})});
      V v_t_2449 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2448})});
      V v_t_2450 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2449})});
      V v_t_2451 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2450})});
      return (g_co_2eop_24s615738393x1686646143(heff_tag_n(TAG_InR, 1, (V[]){v_t_2451}), heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2ecommands_2einitCmd_24s795893522x1842903301_lam6, 1, 2, (V[]){v_hd_241, v_k_242})));
    } else {
      heff_drop(v_field_2442);
      switch (heff_tag_of(v_x_2437)) {
      case TAG_Nil: {
        return (g_heff_2ebuild_2ecommands_2ewriteAll_24s302415776x955929641(heff_dup(v_dir_240), v_x_2436, heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2ecommands_2einitCmd_24s795893522x1842903301_lam7, 1, 3, (V[]){v_dir_240, v_hd_241, v_k_242})));
      }
      case TAG_Cons: {
        heff_drop(v_x_2436);
        V v_t_2480;
        switch (heff_tag_of(v_x_2437)) {
        case TAG_Nil: {
          v_t_2480 = ((V)&g_heff_2ebuild_2ecommands_2einitCmd_24s795893522x1842903301_str7);
          break;
        }
        case TAG_Cons: {
          V v_x_2478 = heff_field(v_x_2437, 0);
          V v_xs_2479 = heff_field(v_x_2437, 1);
          heff_take_n(v_x_2437, 3ULL, 2);
          v_t_2480 = ({ V a_0 = ((V)&g_heff_2ebuild_2ecommands_2einitCmd_24s795893522x1842903301_str8); V a_1 = v_x_2478; V a_2 = v_xs_2479; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2479); r_; });
          break;
        }
        default: heff_nomatch(v_x_2437);
        }
        V v_t_2481 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2einitCmd_24s795893522x1842903301_str9), heff_strAppend(v_t_2480, ((V)&g_heff_2ebuild_2ecommands_2einitCmd_24s795893522x1842903301_str10)));
        V v_str_2482 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2einitCmd_24s795893522x1842903301_str11), heff_strAppend(v_dir_240, v_t_2481));
        V v_t_2483 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_str_2482, ((V)&g_heff_2ebuild_2ecommands_2einitCmd_24s795893522x1842903301_str12)), NTAG(TAG_MkUnit)});
        V v_t_2484 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2483})});
        V v_t_2485 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2484})});
        V v_t_2486 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2485})});
        V v_t_2487 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2486})});
        V v_t_2488 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2487})});
        V v_t_2489 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2488})});
        return (g_co_2eop_24s615738393x1686646143(heff_tag_n(TAG_InR, 1, (V[]){v_t_2489}), heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2ecommands_2einitCmd_24s795893522x1842903301_lam8, 1, 2, (V[]){v_hd_241, v_k_242})));
      }
      default: return heff_nomatch(v_x_2437);
      }
    }
  }
}
V g_heff_2ebuild_2ecommands_2einitCmd_24s795893522x1842903301_lam4(V self, V *args) {
  V v_x_2430 = args[0];
  V v_dir_240 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  V v_x_2421 = heff_env(self)[2];
  V v_hd_241 = heff_env(self)[3];
  V v_k_242 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2432;
  if (heff_strEq_c(v_x_2430, ((V)&g_heff_2ebuild_2ecommands_2einitCmd_24s795893522x1842903301_str0))) {
    v_t_2432 = NTAG(TAG_Windows);
  } else {
    v_t_2432 = NTAG(TAG_Posix);
  }
  V v_x_2433 = ({ V a_0 = v_t_2432; V a_1 = heff_dup(v_dir_240); V a_2 = heff_dup(v_x_243); V r_ = (g_heff_2ebuild_2ecommands_2eprojectName(a_0, a_1, a_2)); heff_drop(v_t_2432); r_; });
  V v_t_2435;
  switch (heff_tag_of(v_x_2421)) {
  case TAG_Nothing: {
    v_t_2435 = ((V)&g_heff_2ebuild_2ecommands_2einitCmd_24s795893522x1842903301_str1);
    break;
  }
  case TAG_Just: {
    V v_x_2434 = heff_field(v_x_2421, 0);
    heff_take_n(v_x_2421, 1ULL, 1);
    v_t_2435 = v_x_2434;
    break;
  }
  default: heff_nomatch(v_x_2421);
  }
  V v_x_2436 = (g_heff_2ebuild_2ecommands_2eprojectFiles(heff_dup(v_x_2433), v_t_2435));
  return (g_heff_2ebuild_2ecommands_2eexisting_24s783863025x1958439471(heff_dup(v_dir_240), heff_dup(v_x_2436), heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2ecommands_2einitCmd_24s795893522x1842903301_lam5, 1, 6, (V[]){v_dir_240, v_x_243, v_x_2433, v_hd_241, v_k_242, v_x_2436})));
}
V g_heff_2ebuild_2ecommands_2einitCmd_24s795893522x1842903301_lam2(V self, V *args) {
  V v_x_247 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_dir_240 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  V v_k_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x_2421;
  switch (heff_tag_of(v_x_247)) {
  case TAG_Nothing: {
    v_x_2421 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Just: {
    V v_src_248 = heff_field(v_x_247, 0);
    V v_ru_24x_247_24Just = heff_take_reuse_n(v_x_247, 1ULL, 1);
    HeffT2 v_t_249 = ({ V a_0 = v_src_248; HeffT2 r_ = (g_heff_2ebuild_2eproject_2epackageLit_24cpr(a_0)); heff_drop(v_src_248); r_; });
    {
      V v_field_2411 = v_t_249.f[1];
      int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
      if ((v_tag_2410 == ((int64_t)0ULL))) {
        heff_drop_cell(v_ru_24x_247_24Just, 1);
        V v_p_2413 = v_field_2411;
        heff_drop(v_p_2413);
        v_x_2421 = NTAG(TAG_Nothing);
      } else {
        V v_x_2414 = v_field_2411;
        HeffT2 v_t_2415 = (g_heff_2ebuild_2eproject_2epackageOf_24cpr(v_x_2414));
        {
          V v_field_2417 = v_t_2415.f[1];
          int64_t v_tag_2416 = ((int64_t)v_t_2415.f[0]);
          if ((v_tag_2416 == ((int64_t)0ULL))) {
            heff_drop_cell(v_ru_24x_247_24Just, 1);
            V v_x_2419 = v_field_2417;
            heff_drop(v_x_2419);
            v_x_2421 = NTAG(TAG_Nothing);
          } else {
            V v_p_2420 = v_field_2417;
            v_x_2421 = heff_tag_at_n(v_ru_24x_247_24Just, TAG_Just, 1, (V[]){heff_get_n(v_p_2420, 1, 4)});
          }
        }
      }
    }
    break;
  }
  default: heff_nomatch(v_x_247);
  }
  V v_t_2423 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2einitCmd_24s795893522x1842903301_lam3_clo)})});
  V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
  V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
  V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
  V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
  V v_t_2428 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
  V v_t_2429 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2428})});
  return (g_co_2eop_24s615738393x1686646143(v_t_2429, heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2ecommands_2einitCmd_24s795893522x1842903301_lam4, 1, 5, (V[]){v_dir_240, v_x_243, v_x_2421, v_hd_241, v_k_242})));
}
V g_heff_2ebuild_2ecommands_2einitCmd_24s795893522x1842903301_lam1(V self, V *args) {
  V v_x_244 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_dir_240 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  V v_k_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_245 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_x_244; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
  V v_c_246 = ({ V a_0 = v_t_245; V r_ = (g_heff_2eutil_2efiles_2ereadFile_24s1303888535x886302188(a_0)); heff_drop(v_t_245); r_; });
  V f_ = v_c_246;
  heff_room[0] = heff_dup(v_hd_241);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2einitCmd_24s795893522x1842903301_lam2, 1, 4, (V[]){v_hd_241, v_dir_240, v_x_243, v_k_242});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2einitCmd_24s795893522x1842903301_lam0(V self, V *args) {
  V v_x_243 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_dir_240 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2ebuild_2ecommands_2eownPackage_24s693628669x534541312(heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2ecommands_2einitCmd_24s795893522x1842903301_lam1, 1, 4, (V[]){v_hd_241, v_dir_240, v_x_243, v_k_242})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941_str0, 7, "commits");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941_str1, 4, " of ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941_str2, 12, "finding the ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941_str3, 8, "https://");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941_str4, 6, "--bare");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941_str5, 15, "--filter=tree:0");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941_str6, 5, "clone");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941_str7, 7, "--quiet");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941_str8, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941_str9, 3, "git");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941_str10, 8, "https://");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941_str11, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941_str12, 27, "cannot list the commits of ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941_str13, 4, " of ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941_str14, 8, "https://");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941_str15, 3, "no ");
V g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941_lam3(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941_lam3, 1, 0};
V g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941_lam5(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941_lam5, 1, 0};
V g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941_lam7(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941_lam7, 2, 0};
V g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941_lam8(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941_lam8_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941_lam8, 2, 0};
V g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941_lam9(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941_lam9_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941_lam9, 2, 0};
V g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941_lam10(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941_lam10_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941_lam10, 2, 0};
V g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941_lam13(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941_lam12(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941_lam11(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941_entry, 4, 0};

V g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941(V v_prog_240, V v_ps_241, V v_path_242, V v_rev_243) {
top: ;
  V v_x_244 = (g_heff_2ebuild_2eload_2ecachedDir(heff_dup(v_ps_241), heff_dup(v_path_242), ((V)&g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941_str0)));
  return heff_clo_n(g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941_lam0, 2, 5, (V[]){v_x_244, v_ps_241, v_rev_243, v_path_242, v_prog_240});
}
V g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941(a[0], a[1], a[2], a[3]);
}
V g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941_lam3(V self, V *args) {
  V v_t_2429 = args[0];
  return v_t_2429;
}
V g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941_lam5(V self, V *args) {
  V v_r_2440 = args[0];
  return v_r_2440;
}
V g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941_lam7(V self, V *args) {
  V v_hd_2453 = args[0];
  V v_k_2454 = args[1];
  heff_drop(v_hd_2453);
  V f_ = v_k_2454;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941_lam8(V self, V *args) {
  V v_hd_2456 = args[0];
  V v_k_2457 = args[1];
  heff_drop(v_hd_2456);
  V f_ = v_k_2457;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941_lam9(V self, V *args) {
  V v_hd_2458 = args[0];
  V v_k_2459 = args[1];
  heff_drop(v_hd_2458);
  V f_ = v_k_2459;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941_lam10(V self, V *args) {
  V v_hd_2460 = args[0];
  V v_k_2461 = args[1];
  heff_drop(v_hd_2460);
  V f_ = v_k_2461;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941_lam13(V self, V *args) {
  V v_x_2469 = args[0];
  V v_x_2448 = heff_env(self)[0];
  V v_path_242 = heff_env(self)[1];
  V v_x_2463 = heff_env(self)[2];
  V v_rev_243 = heff_env(self)[3];
  V v_k_246 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2469);
  V v_t_2470 = heff_take_field(v_x_2448, 0);
  V v_t_2474;
  switch (heff_tag_of(v_t_2470)) {
  case TAG_Exited: {
    V v_n_2471 = heff_field(v_t_2470, 0);
    heff_take_n(v_t_2470, 1ULL, 1);
    v_t_2474 = heff_bool(!heff_intEq_c_lent(v_n_2471, MK_INT(0LL), 2));
    heff_drop(v_n_2471);
    break;
  }
  case TAG_Signalled: {
    heff_take_n(v_t_2470, 0ULL, 1);
    v_t_2474 = NTAG(TAG_True);
    break;
  }
  case TAG_TimedOut: {
    v_t_2474 = NTAG(TAG_True);
    break;
  }
  case TAG_NotRun: {
    v_t_2474 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_t_2470);
  }
  V v_x_2490;
  if ((heff_dup(v_t_2474) == NTAG(TAG_True))) {
    heff_drop(v_x_2463);
    heff_drop(v_rev_243);
    heff_drop(v_t_2474);
    V v_t_2475 = (g_heff_2ebuild_2eproject_2erepoOf(v_path_242));
    V v_s_2476 = heff_get_n(v_x_2448, 2, 3);
    V v_t_2477 = (g_prelude_2eskipSpaces(v_s_2476, MK_INT(0LL), MK_INT(1LL)));
    int64_t v_t_2478 = (heff_unbox_word(heff_strLength_lent(v_s_2476, 0)) - ((int64_t)1ULL));
    V v_t_2479 = (g_prelude_2eskipSpaces(v_s_2476, heff_box_word(v_t_2478), MK_INT(-1LL)));
    V v_t_2480 = heff_strSlice(v_s_2476, v_t_2477, heff_intAdd(v_t_2479, MK_INT(1LL)));
    V v_t_2481 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941_str10), v_t_2475), heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941_str11), v_t_2480));
    v_x_2490 = heff_tag_n(TAG_Left, 1, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941_str12), v_t_2481)});
  } else {
    heff_drop_rec(v_x_2448, 3);
    heff_drop(v_t_2474);
    switch (heff_tag_of(v_x_2463)) {
    case TAG_Nothing: {
      V v_t_2482 = (g_heff_2ebuild_2ecommands_2erevSaid(v_rev_243));
      V v_t_2483 = (g_heff_2ebuild_2eproject_2erepoOf(v_path_242));
      V v_t_2484 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941_str13), heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941_str14), v_t_2483));
      V v_t_2485 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941_str15), heff_strAppend(v_t_2482, v_t_2484));
      v_x_2490 = heff_tag_n(TAG_Left, 1, (V[]){v_t_2485});
      break;
    }
    case TAG_Just: {
      V v_it1_2486 = heff_field(v_x_2463, 0);
      V v_ru_24x_2463_24Just = heff_take_reuse_n(v_x_2463, 1ULL, 1);
      heff_drop(v_rev_243);
      switch (heff_tag_of(v_it1_2486)) {
      case TAG_MkPair: {
        V v_time_2487 = heff_field(v_it1_2486, 0);
        V v_hash_2488 = heff_field(v_it1_2486, 1);
        heff_take_n(v_it1_2486, 3ULL, 2);
        V v_t_2489 = ({ V a_0 = v_path_242; V a_1 = v_time_2487; V a_2 = v_hash_2488; V r_ = (g_heff_2ebuild_2eproject_2epseudoVersion(a_0, a_1, a_2)); heff_drop(v_hash_2488); r_; });
        v_x_2490 = heff_tag_at_n(v_ru_24x_2463_24Just, TAG_Right, 1, (V[]){v_t_2489});
        break;
      }
      default: heff_nomatch(v_it1_2486);
      }
      break;
    }
    default: heff_nomatch(v_x_2463);
    }
  }
  V f_ = v_k_246;
  args[0] = v_x_2490;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941_lam12(V self, V *args) {
  V v_x_2466 = args[0];
  V v_x_2431 = heff_env(self)[0];
  V v_prog_240 = heff_env(self)[1];
  V v_hd_245 = heff_env(self)[2];
  V v_x_2448 = heff_env(self)[3];
  V v_path_242 = heff_env(self)[4];
  V v_x_2463 = heff_env(self)[5];
  V v_rev_243 = heff_env(self)[6];
  V v_k_246 = heff_env(self)[7];
  heff_clo_take(self, 8);
  heff_drop(v_x_2466);
  V v_t_2467 = heff_tag_n(TAG_End, 2, (V[]){v_x_2431, NTAG(TAG_MkUnit)});
  V v_t_2468 = heff_tr(heff_call(v_prog_240, 1, (V[]){v_t_2467}));
  return (g_co_2eop_24s615738393x1686646143(v_t_2468, v_hd_245, heff_clo_n(g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941_lam13, 1, 5, (V[]){v_x_2448, v_path_242, v_x_2463, v_rev_243, v_k_246})));
}
V g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941_lam11(V self, V *args) {
  V v_x_2463 = args[0];
  V v_x_244 = heff_env(self)[0];
  V v_hd_245 = heff_env(self)[1];
  V v_x_2431 = heff_env(self)[2];
  V v_prog_240 = heff_env(self)[3];
  V v_x_2448 = heff_env(self)[4];
  V v_path_242 = heff_env(self)[5];
  V v_rev_243 = heff_env(self)[6];
  V v_k_246 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2464 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_x_244; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
  V v_c_2465 = ({ V a_0 = v_t_2464; V r_ = (g_heff_2eutil_2efiles_2eremove_24s889287061x300693304(a_0)); heff_drop(v_t_2464); r_; });
  V f_ = v_c_2465;
  heff_room[0] = heff_dup(v_hd_245);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941_lam12, 1, 8, (V[]){v_x_2431, v_prog_240, v_hd_245, v_x_2448, v_path_242, v_x_2463, v_rev_243, v_k_246});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941_lam6(V self, V *args) {
  V v_x_2448 = args[0];
  V v_rev_243 = heff_env(self)[0];
  V v_x_244 = heff_env(self)[1];
  V v_hd_245 = heff_env(self)[2];
  V v_x_2431 = heff_env(self)[3];
  V v_prog_240 = heff_env(self)[4];
  V v_path_242 = heff_env(self)[5];
  V v_k_246 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2449 = heff_dup(heff_rfield(v_x_2448, 0));
  V v_c_2462;
  switch (heff_tag_of(v_t_2449)) {
  case TAG_Exited: {
    V v_n_2450 = heff_field(v_t_2449, 0);
    heff_take_n(v_t_2449, 1ULL, 1);
    if (heff_intEq_c(v_n_2450, MK_INT(0LL))) {
      V v_t_2452 = (g_heff_2ebuild_2ecommands_2erevNamed(heff_dup(v_rev_243)));
      v_c_2462 = (g_heff_2ebuild_2ecommands_2ecommitAt_24s1687144202x1882378819(heff_dup(v_x_244), v_t_2452));
    } else {
      v_c_2462 = ((V)&g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941_lam7_clo);
    }
    break;
  }
  case TAG_Signalled: {
    heff_take_n(v_t_2449, 0ULL, 1);
    v_c_2462 = ((V)&g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941_lam8_clo);
    break;
  }
  case TAG_TimedOut: {
    v_c_2462 = ((V)&g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941_lam9_clo);
    break;
  }
  case TAG_NotRun: {
    v_c_2462 = ((V)&g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941_lam10_clo);
    break;
  }
  default: heff_nomatch(v_t_2449);
  }
  V f_ = v_c_2462;
  heff_room[0] = heff_dup(v_hd_245);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941_lam11, 1, 8, (V[]){v_x_244, v_hd_245, v_x_2431, v_prog_240, v_x_2448, v_path_242, v_rev_243, v_k_246});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941_lam4(V self, V *args) {
  V v_x_2431 = args[0];
  V v_path_242 = heff_env(self)[0];
  V v_x_244 = heff_env(self)[1];
  V v_hd_245 = heff_env(self)[2];
  V v_rev_243 = heff_env(self)[3];
  V v_prog_240 = heff_env(self)[4];
  V v_k_246 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2432 = (g_heff_2ebuild_2eproject_2erepoOf(heff_dup(v_path_242)));
  V v_t_2433 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_x_244), NTAG(TAG_Nil)});
  V v_t_2434 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941_str3), v_t_2432), v_t_2433});
  V v_t_2435 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941_str4), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941_str5), v_t_2434})});
  V v_t_2436 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941_str6), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941_str7), v_t_2435})});
  V v_t_2437 = ({ V b_0 = NTAG(TAG_Nil); V b_1 = NTAG(TAG_Nil); V r_ = (g_std_2epath_2esameSegments(b_0, b_1)); heff_drop(b_0); heff_drop(b_1); r_; });
  V v_t_2438;
  if ((heff_dup(v_t_2437) == NTAG(TAG_True))) {
    heff_drop(v_t_2437);
    v_t_2438 = ((V)&g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941_str8);
  } else {
    heff_drop(v_t_2437);
    v_t_2438 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V b_1 = heff_dup(g_std_2epath_2ecurrent_get()); V r_ = (g_std_2epath_2erender(b_0, b_1)); heff_drop(b_0); heff_drop(b_1); r_; });
  }
  V v_t_2439 = heff_rec_n(10, shape_command__args__dir__env__input__output__errors__timeout__keep__group, (V[]){((V)&g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941_str9), v_t_2436, v_t_2438, NTAG(TAG_Nil), NTAG(TAG_NoInput), NTAG(TAG_Collected), NTAG(TAG_Collected), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_False)});
  V v_a_2441 = heff_tag_n(TAG_Run, 2, (V[]){v_t_2439, ((V)&g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941_lam5_clo)});
  V v_t_2442 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2441})});
  V v_t_2443 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2442})});
  V v_t_2444 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2443})});
  V v_t_2445 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2444})});
  V v_t_2446 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2445})});
  V v_t_2447 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2446})});
  return (g_co_2eop_24s615738393x1686646143(heff_tag_n(TAG_InR, 1, (V[]){v_t_2447}), heff_dup(v_hd_245), heff_clo_n(g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941_lam6, 1, 7, (V[]){v_rev_243, v_x_244, v_hd_245, v_x_2431, v_prog_240, v_path_242, v_k_246})));
}
V g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941_lam2(V self, V *args) {
  V v_x_2425 = args[0];
  V v_rev_243 = heff_env(self)[0];
  V v_path_242 = heff_env(self)[1];
  V v_prog_240 = heff_env(self)[2];
  V v_hd_245 = heff_env(self)[3];
  V v_x_244 = heff_env(self)[4];
  V v_k_246 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_2425);
  V v_t_2426 = (g_heff_2ebuild_2ecommands_2erevSaid(heff_dup(v_rev_243)));
  V v_t_2427 = heff_strAppend(v_t_2426, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941_str1), heff_dup(v_path_242)));
  V v_name_2428 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941_str2), v_t_2427);
  V v_t_2430 = heff_tr(heff_call(heff_dup(v_prog_240), 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){heff_dup(g_std_2eprogress_2eroot_get()), v_name_2428, MK_INT(0LL), ((V)&g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941_lam3_clo)})}));
  return (g_co_2eop_24s615738393x1686646143(v_t_2430, heff_dup(v_hd_245), heff_clo_n(g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941_lam4, 1, 6, (V[]){v_path_242, v_x_244, v_hd_245, v_rev_243, v_prog_240, v_k_246})));
}
V g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941_lam1(V self, V *args) {
  V v_x_249 = args[0];
  V v_ps_241 = heff_env(self)[0];
  V v_x_244 = heff_env(self)[1];
  V v_hd_245 = heff_env(self)[2];
  V v_rev_243 = heff_env(self)[3];
  V v_path_242 = heff_env(self)[4];
  V v_prog_240 = heff_env(self)[5];
  V v_k_246 = heff_env(self)[6];
  heff_clo_take(self, 7);
  heff_drop(v_x_249);
  V v_st_2410 = heff_get_n(v_ps_241, 5, 6);
  HeffT3 v_t_2411 = (g_std_2epath_2eparse_24cpr(v_st_2410, heff_dup(v_x_244)));
  V v_t_2421;
  {
    V v_field_2412 = v_t_2411.f[0];
    V v_field_2413 = v_t_2411.f[1];
    V v_field_2414 = v_t_2411.f[2];
    V v_d_2415 = v_field_2412;
    V v_a_2416 = v_field_2413;
    V v_xs_2417 = v_field_2414;
    V v_t_2418 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2417));
    V v_xs_2419 = ({ V a_0 = MK_INT(1LL); V a_1 = v_t_2418; V r_ = (g_list_2edrop(a_0, a_1)); heff_drop(v_t_2418); r_; });
    V v_t_2420 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2419));
    v_t_2421 = heff_tag_n(TAG_MkPath, 3, (V[]){v_d_2415, v_a_2416, v_t_2420});
  }
  V v_s_2422 = ({ V a_0 = v_st_2410; V a_1 = v_t_2421; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2410); heff_drop(v_t_2421); r_; });
  V v_t_2423 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_s_2422; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
  V v_c_2424 = ({ V a_0 = v_t_2423; V r_ = (g_heff_2eutil_2efiles_2emakeDirectory_24s1667989245x984665292(a_0)); heff_drop(v_t_2423); r_; });
  V f_ = v_c_2424;
  heff_room[0] = heff_dup(v_hd_245);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941_lam2, 1, 6, (V[]){v_rev_243, v_path_242, v_prog_240, v_hd_245, v_x_244, v_k_246});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941_lam0(V self, V *args) {
  V v_hd_245 = args[0];
  V v_k_246 = args[1];
  V v_x_244 = heff_env(self)[0];
  V v_ps_241 = heff_env(self)[1];
  V v_rev_243 = heff_env(self)[2];
  V v_path_242 = heff_env(self)[3];
  V v_prog_240 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_247 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = heff_dup(v_x_244); V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
  V v_c_248 = ({ V a_0 = v_t_247; V r_ = (g_heff_2eutil_2efiles_2eremove_24s889287061x300693304(a_0)); heff_drop(v_t_247); r_; });
  V f_ = v_c_248;
  args[0] = heff_dup(v_hd_245);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941_lam1, 1, 7, (V[]){v_ps_241, v_x_244, v_hd_245, v_rev_243, v_path_242, v_prog_240, v_k_246});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishGit_24s211231607x115039889_str0, 3, "git");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishGit_24s211231607x115039889_str1, 6, "status");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishGit_24s211231607x115039889_str2, 11, "--porcelain");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishGit_24s211231607x115039889_str3, 11, "refs/tags/v");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishGit_24s211231607x115039889_str4, 2, "-q");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishGit_24s211231607x115039889_str5, 8, "--verify");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishGit_24s211231607x115039889_str6, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishGit_24s211231607x115039889_str7, 3, "git");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishGit_24s211231607x115039889_str8, 9, "rev-parse");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishGit_24s211231607x115039889_str9, 25, "not in a git repository: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishGit_24s211231607x115039889_str10, 14, "heff publish: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishGit_24s211231607x115039889_str11, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishGit_24s211231607x115039889_str12, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishGit_24s211231607x115039889_str13, 1, "v");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishGit_24s211231607x115039889_str14, 18, " is tagged already");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishGit_24s211231607x115039889_str15, 14, "heff publish: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishGit_24s211231607x115039889_str16, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishGit_24s211231607x115039889_str17, 67, "heff publish: what is published is what is committed: commit first\012");
V g_heff_2ebuild_2ecommands_2epublishGit_24s211231607x115039889_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2epublishGit_24s211231607x115039889_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2epublishGit_24s211231607x115039889_lam1, 1, 0};
V g_heff_2ebuild_2ecommands_2epublishGit_24s211231607x115039889_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2epublishGit_24s211231607x115039889_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2epublishGit_24s211231607x115039889_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2epublishGit_24s211231607x115039889_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2epublishGit_24s211231607x115039889_lam7(V self, V *args);
V g_heff_2ebuild_2ecommands_2epublishGit_24s211231607x115039889_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2epublishGit_24s211231607x115039889_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2epublishGit_24s211231607x115039889_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2epublishGit_24s211231607x115039889_entry, 6, 0};

V g_heff_2ebuild_2ecommands_2epublishGit_24s211231607x115039889(V v_rep_240, V v_v_241, V v_pk_242, V v_src_243, V v_z_244, V v_z_245) {
top: ;
  V v_c_246 = heff_tr(g_std_2eprocess_2erun_24s1262677465x1574883892(((V)&g_heff_2ebuild_2ecommands_2epublishGit_24s211231607x115039889_str0), ((V)&g_heff_2ebuild_2ecommands_2epublishGit_24s211231607x115039889_str1), ((V)&g_heff_2ebuild_2ecommands_2epublishGit_24s211231607x115039889_str2), MK_INT(0LL), MK_INT(0LL)));
  return heff_tail(v_c_246, 2, (V[]){heff_dup(v_z_244), heff_clo_n(g_heff_2ebuild_2ecommands_2epublishGit_24s211231607x115039889_lam0, 1, 6, (V[]){v_v_241, v_z_244, v_z_245, v_src_243, v_rep_240, v_pk_242})});
}
V g_heff_2ebuild_2ecommands_2epublishGit_24s211231607x115039889_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2epublishGit_24s211231607x115039889(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2ebuild_2ecommands_2epublishGit_24s211231607x115039889_lam1(V self, V *args) {
  V v_r_2413 = args[0];
  return v_r_2413;
}
V g_heff_2ebuild_2ecommands_2epublishGit_24s211231607x115039889_lam3(V self, V *args) {
  V v_x_2441 = args[0];
  V v_z_244 = heff_env(self)[0];
  V v_z_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2441);
  V v_t_2442 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2443 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2442})});
  V v_t_2444 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2443})});
  V v_t_2445 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2444})});
  V v_t_2446 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2445})});
  V v_t_2447 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2446})});
  V v_t_2448 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2447})});
  return (g_co_2eop_24s615738393x1686646143(heff_tag_n(TAG_InR, 1, (V[]){v_t_2448}), v_z_244, v_z_245));
}
V g_heff_2ebuild_2ecommands_2epublishGit_24s211231607x115039889_lam4(V self, V *args) {
  V v_x_2468 = args[0];
  V v_z_244 = heff_env(self)[0];
  V v_z_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2468);
  V v_t_2469 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2470 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2469})});
  V v_t_2471 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2470})});
  V v_t_2472 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2471})});
  V v_t_2473 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2472})});
  V v_t_2474 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2473})});
  V v_t_2475 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2474})});
  return (g_co_2eop_24s615738393x1686646143(heff_tag_n(TAG_InR, 1, (V[]){v_t_2475}), v_z_244, v_z_245));
}
V g_heff_2ebuild_2ecommands_2epublishGit_24s211231607x115039889_lam6(V self, V *args) {
  V v_x_2480 = args[0];
  V v_v_241 = heff_env(self)[0];
  V v_pk_242 = heff_env(self)[1];
  V v_z_244 = heff_env(self)[2];
  V v_z_245 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2ebuild_2ecommands_2epublishTested_24s563627996x2090231580(v_v_241, v_pk_242, v_x_2480, v_z_244, v_z_245));
}
V g_heff_2ebuild_2ecommands_2epublishGit_24s211231607x115039889_lam5(V self, V *args) {
  V v_x_2478 = args[0];
  V v_rep_240 = heff_env(self)[0];
  V v_z_244 = heff_env(self)[1];
  V v_v_241 = heff_env(self)[2];
  V v_pk_242 = heff_env(self)[3];
  V v_z_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_c_2479 = ({ V a_0 = v_rep_240; V a_1 = v_x_2478; V a_2 = heff_dup(g_heff_2ebuild_2ecommands_2enoRes_get()); V r_ = (g_heff_2ebuild_2ecommands_2etestAll_24s749792949x1328449028(a_0, a_1, a_2)); heff_drop(v_x_2478); r_; });
  V f_ = v_c_2479;
  heff_room[0] = heff_dup(v_z_244);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2epublishGit_24s211231607x115039889_lam6, 1, 4, (V[]){v_v_241, v_pk_242, v_z_244, v_z_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2epublishGit_24s211231607x115039889_lam7(V self, V *args) {
  V v_x_2488 = args[0];
  V v_z_244 = heff_env(self)[0];
  V v_z_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2488);
  V v_t_2489 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2490 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2489})});
  V v_t_2491 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2490})});
  V v_t_2492 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2491})});
  V v_t_2493 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2492})});
  V v_t_2494 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2493})});
  V v_t_2495 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2494})});
  return (g_co_2eop_24s615738393x1686646143(heff_tag_n(TAG_InR, 1, (V[]){v_t_2495}), v_z_244, v_z_245));
}
V g_heff_2ebuild_2ecommands_2epublishGit_24s211231607x115039889_lam2(V self, V *args) {
  V v_x_2421 = args[0];
  V v_x_247 = heff_env(self)[0];
  V v_z_244 = heff_env(self)[1];
  V v_z_245 = heff_env(self)[2];
  V v_v_241 = heff_env(self)[3];
  V v_src_243 = heff_env(self)[4];
  V v_rep_240 = heff_env(self)[5];
  V v_pk_242 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2422 = heff_take_field(v_x_247, 0);
  V v_t_2426;
  switch (heff_tag_of(v_t_2422)) {
  case TAG_Exited: {
    V v_n_2423 = heff_field(v_t_2422, 0);
    heff_take_n(v_t_2422, 1ULL, 1);
    v_t_2426 = heff_bool(!heff_intEq_c_lent(v_n_2423, MK_INT(0LL), 2));
    heff_drop(v_n_2423);
    break;
  }
  case TAG_Signalled: {
    heff_take_n(v_t_2422, 0ULL, 1);
    v_t_2426 = NTAG(TAG_True);
    break;
  }
  case TAG_TimedOut: {
    v_t_2426 = NTAG(TAG_True);
    break;
  }
  case TAG_NotRun: {
    v_t_2426 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_t_2422);
  }
  if ((heff_dup(v_t_2426) == NTAG(TAG_True))) {
    heff_drop_rec(v_x_2421, 3);
    heff_drop(v_v_241);
    heff_drop(v_src_243);
    heff_drop(v_rep_240);
    heff_drop(v_pk_242);
    heff_drop(v_t_2426);
    V v_s_2427 = heff_get_n(v_x_247, 2, 3);
    V v_t_2428 = (g_prelude_2eskipSpaces(v_s_2427, MK_INT(0LL), MK_INT(1LL)));
    int64_t v_t_2429 = (heff_unbox_word(heff_strLength_lent(v_s_2427, 0)) - ((int64_t)1ULL));
    V v_t_2430 = (g_prelude_2eskipSpaces(v_s_2427, heff_box_word(v_t_2429), MK_INT(-1LL)));
    V v_t_2431 = heff_strSlice(v_s_2427, v_t_2428, heff_intAdd(v_t_2430, MK_INT(1LL)));
    V v_why_2432 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2epublishGit_24s211231607x115039889_str9), v_t_2431);
    V v_t_2433 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2epublishGit_24s211231607x115039889_str10), v_why_2432), ((V)&g_heff_2ebuild_2ecommands_2epublishGit_24s211231607x115039889_str11));
    V v_t_2434 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2433, NTAG(TAG_MkUnit)});
    V v_t_2435 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2434})});
    V v_t_2436 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2435})});
    V v_t_2437 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2436})});
    V v_t_2438 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2437})});
    V v_t_2439 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2438})});
    V v_t_2440 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2439})});
    return (g_co_2eop_24s615738393x1686646143(heff_tag_n(TAG_InR, 1, (V[]){v_t_2440}), heff_dup(v_z_244), heff_clo_n(g_heff_2ebuild_2ecommands_2epublishGit_24s211231607x115039889_lam3, 1, 2, (V[]){v_z_244, v_z_245})));
  } else {
    heff_drop(v_t_2426);
    V v_s_2449 = heff_get_n(v_x_247, 1, 3);
    V v_t_2450 = (g_prelude_2eskipSpaces(v_s_2449, MK_INT(0LL), MK_INT(1LL)));
    int64_t v_t_2451 = (heff_unbox_word(heff_strLength_lent(v_s_2449, 0)) - ((int64_t)1ULL));
    V v_t_2452 = (g_prelude_2eskipSpaces(v_s_2449, heff_box_word(v_t_2451), MK_INT(-1LL)));
    V v_t_2453 = heff_strSlice(v_s_2449, v_t_2450, heff_intAdd(v_t_2452, MK_INT(1LL)));
    if (heff_strEq_c(v_t_2453, ((V)&g_heff_2ebuild_2ecommands_2epublishGit_24s211231607x115039889_str12))) {
      V v_t_2455 = heff_get_n(v_x_2421, 0, 3);
      V v_t_2458;
      switch (heff_tag_of(v_t_2455)) {
      case TAG_Exited: {
        V v_n_2456 = heff_field(v_t_2455, 0);
        heff_take_n(v_t_2455, 1ULL, 1);
        v_t_2458 = heff_intEq(v_n_2456, MK_INT(0LL));
        break;
      }
      case TAG_Signalled: {
        heff_take_n(v_t_2455, 0ULL, 1);
        v_t_2458 = NTAG(TAG_False);
        break;
      }
      case TAG_TimedOut: {
        v_t_2458 = NTAG(TAG_False);
        break;
      }
      case TAG_NotRun: {
        v_t_2458 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_t_2455);
      }
      if ((heff_dup(v_t_2458) == NTAG(TAG_True))) {
        heff_drop(v_src_243);
        heff_drop(v_rep_240);
        heff_drop(v_pk_242);
        heff_drop(v_t_2458);
        V v_t_2459 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2epublishGit_24s211231607x115039889_str13), heff_strAppend(v_v_241, ((V)&g_heff_2ebuild_2ecommands_2epublishGit_24s211231607x115039889_str14)));
        V v_t_2460 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2epublishGit_24s211231607x115039889_str15), v_t_2459), ((V)&g_heff_2ebuild_2ecommands_2epublishGit_24s211231607x115039889_str16));
        V v_t_2461 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2460, NTAG(TAG_MkUnit)});
        V v_t_2462 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2461})});
        V v_t_2463 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2462})});
        V v_t_2464 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2463})});
        V v_t_2465 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2464})});
        V v_t_2466 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2465})});
        V v_t_2467 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2466})});
        return (g_co_2eop_24s615738393x1686646143(heff_tag_n(TAG_InR, 1, (V[]){v_t_2467}), heff_dup(v_z_244), heff_clo_n(g_heff_2ebuild_2ecommands_2epublishGit_24s211231607x115039889_lam4, 1, 2, (V[]){v_z_244, v_z_245})));
      } else {
        heff_drop(v_t_2458);
        V v_t_2476 = heff_tag_n(TAG_Cons, 2, (V[]){v_src_243, NTAG(TAG_Nil)});
        V v_c_2477 = (g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1606122519x1439074770(v_t_2476, NTAG(TAG_Nil)));
        V f_ = v_c_2477;
        heff_room[0] = heff_dup(v_z_244);
        heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2epublishGit_24s211231607x115039889_lam5, 1, 5, (V[]){v_rep_240, v_z_244, v_v_241, v_pk_242, v_z_245});
        if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
      }
    } else {
      heff_drop_rec(v_x_2421, 3);
      heff_drop(v_v_241);
      heff_drop(v_src_243);
      heff_drop(v_rep_240);
      heff_drop(v_pk_242);
      V v_t_2481 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2epublishGit_24s211231607x115039889_str17), NTAG(TAG_MkUnit)});
      V v_t_2482 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2481})});
      V v_t_2483 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2482})});
      V v_t_2484 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2483})});
      V v_t_2485 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2484})});
      V v_t_2486 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2485})});
      V v_t_2487 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2486})});
      return (g_co_2eop_24s615738393x1686646143(heff_tag_n(TAG_InR, 1, (V[]){v_t_2487}), heff_dup(v_z_244), heff_clo_n(g_heff_2ebuild_2ecommands_2epublishGit_24s211231607x115039889_lam7, 1, 2, (V[]){v_z_244, v_z_245})));
    }
  }
}
V g_heff_2ebuild_2ecommands_2epublishGit_24s211231607x115039889_lam0(V self, V *args) {
  V v_x_247 = args[0];
  V v_v_241 = heff_env(self)[0];
  V v_z_244 = heff_env(self)[1];
  V v_z_245 = heff_env(self)[2];
  V v_src_243 = heff_env(self)[3];
  V v_rep_240 = heff_env(self)[4];
  V v_pk_242 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2epublishGit_24s211231607x115039889_str3), heff_dup(v_v_241)), NTAG(TAG_Nil)});
  V v_t_249 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2epublishGit_24s211231607x115039889_str4), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2epublishGit_24s211231607x115039889_str5), v_t_248})});
  V v_t_2410 = ({ V b_0 = NTAG(TAG_Nil); V b_1 = NTAG(TAG_Nil); V r_ = (g_std_2epath_2esameSegments(b_0, b_1)); heff_drop(b_0); heff_drop(b_1); r_; });
  V v_t_2411;
  if ((heff_dup(v_t_2410) == NTAG(TAG_True))) {
    heff_drop(v_t_2410);
    v_t_2411 = ((V)&g_heff_2ebuild_2ecommands_2epublishGit_24s211231607x115039889_str6);
  } else {
    heff_drop(v_t_2410);
    v_t_2411 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V b_1 = heff_dup(g_std_2epath_2ecurrent_get()); V r_ = (g_std_2epath_2erender(b_0, b_1)); heff_drop(b_0); heff_drop(b_1); r_; });
  }
  V v_t_2412 = heff_rec_n(10, shape_command__args__dir__env__input__output__errors__timeout__keep__group, (V[]){((V)&g_heff_2ebuild_2ecommands_2epublishGit_24s211231607x115039889_str7), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2epublishGit_24s211231607x115039889_str8), v_t_249}), v_t_2411, NTAG(TAG_Nil), NTAG(TAG_NoInput), NTAG(TAG_Collected), NTAG(TAG_Collected), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_False)});
  V v_a_2414 = heff_tag_n(TAG_Run, 2, (V[]){v_t_2412, ((V)&g_heff_2ebuild_2ecommands_2epublishGit_24s211231607x115039889_lam1_clo)});
  V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2414})});
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2419})});
  return (g_co_2eop_24s615738393x1686646143(heff_tag_n(TAG_InR, 1, (V[]){v_t_2420}), heff_dup(v_z_244), heff_clo_n(g_heff_2ebuild_2ecommands_2epublishGit_24s211231607x115039889_lam2, 1, 7, (V[]){v_x_247, v_z_244, v_z_245, v_v_241, v_src_243, v_rep_240, v_pk_242})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishCmd_24s581473772x1366906885_str0, 10, "package.hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishCmd_24s581473772x1366906885_str1, 64, "heff publish: no package.hf here: publish at the project's root\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishCmd_24s581473772x1366906885_str2, 10, "package.hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishCmd_24s581473772x1366906885_str3, 4, "heff");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishCmd_24s581473772x1366906885_str4, 39, "heff publish: package.hf does not read\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishCmd_24s581473772x1366906885_str5, 57, "heff publish: package.hf is no Package (lib/manifest.hf)\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishCmd_24s581473772x1366906885_str6, 57, "heff publish: package.hf is no Package (lib/manifest.hf)\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishCmd_24s581473772x1366906885_str7, 1, "`");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishCmd_24s581473772x1366906885_str8, 22, "` is no version: a.b.c");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishCmd_24s581473772x1366906885_str9, 14, "heff publish: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishCmd_24s581473772x1366906885_str10, 1, "\012");
V g_heff_2ebuild_2ecommands_2epublishCmd_24s581473772x1366906885_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2epublishCmd_24s581473772x1366906885_lam7(V self, V *args);
V g_heff_2ebuild_2ecommands_2epublishCmd_24s581473772x1366906885_lam8(V self, V *args);
V g_heff_2ebuild_2ecommands_2epublishCmd_24s581473772x1366906885_lam9(V self, V *args);
V g_heff_2ebuild_2ecommands_2epublishCmd_24s581473772x1366906885_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2epublishCmd_24s581473772x1366906885_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2epublishCmd_24s581473772x1366906885_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2epublishCmd_24s581473772x1366906885_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2epublishCmd_24s581473772x1366906885_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2epublishCmd_24s581473772x1366906885_lam0(V self, V *args);
V g_heff_2ebuild_2ecommands_2epublishCmd_24s581473772x1366906885_lam11(V self, V *args);
V g_heff_2ebuild_2ecommands_2epublishCmd_24s581473772x1366906885_lam10(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2epublishCmd_24s581473772x1366906885_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2epublishCmd_24s581473772x1366906885_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2epublishCmd_24s581473772x1366906885(V v_rep_240, V v_v_241) {
top: ;
  HeffT2 v_t_242 = (g_heff_2ebuild_2eproject_2eversion_24cpr(v_v_241));
  {
    V v_field_244 = v_t_242.f[1];
    int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
    if ((v_tag_243 == ((int64_t)0ULL))) {
      V v_x_246 = v_field_244;
      heff_drop(v_x_246);
      V v_t_247 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = ((V)&g_heff_2ebuild_2ecommands_2epublishCmd_24s581473772x1366906885_str0); V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
      V v_c_248 = ({ V a_0 = v_t_247; V r_ = (g_heff_2eutil_2efiles_2ereadFile_24s1303888535x886302188(a_0)); heff_drop(v_t_247); r_; });
      return heff_clo_n(g_heff_2ebuild_2ecommands_2epublishCmd_24s581473772x1366906885_lam0, 2, 3, (V[]){v_c_248, v_rep_240, v_v_241});
    } else {
      heff_drop(v_rep_240);
      heff_drop(v_field_244);
      return heff_clo_n(g_heff_2ebuild_2ecommands_2epublishCmd_24s581473772x1366906885_lam10, 2, 1, (V[]){v_v_241});
    }
  }
}
V g_heff_2ebuild_2ecommands_2epublishCmd_24s581473772x1366906885_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2epublishCmd_24s581473772x1366906885(a[0], a[1]);
}
V g_heff_2ebuild_2ecommands_2epublishCmd_24s581473772x1366906885_lam2(V self, V *args) {
  V v_x_2419 = args[0];
  V v_hd_249 = heff_env(self)[0];
  V v_k_2410 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2419);
  V v_t_2420 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2420})});
  V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
  V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
  V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
  V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
  V v_t_2426 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2425})});
  return (g_co_2eop_24s615738393x1686646143(heff_tag_n(TAG_InR, 1, (V[]){v_t_2426}), v_hd_249, v_k_2410));
}
V g_heff_2ebuild_2ecommands_2epublishCmd_24s581473772x1366906885_lam7(V self, V *args) {
  V v_x_2444 = args[0];
  V v_hd_249 = heff_env(self)[0];
  V v_k_2410 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2444);
  V v_t_2445 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2446 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2445})});
  V v_t_2447 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2446})});
  V v_t_2448 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2447})});
  V v_t_2449 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2448})});
  V v_t_2450 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2449})});
  V v_t_2451 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2450})});
  return (g_co_2eop_24s615738393x1686646143(heff_tag_n(TAG_InR, 1, (V[]){v_t_2451}), v_hd_249, v_k_2410));
}
V g_heff_2ebuild_2ecommands_2epublishCmd_24s581473772x1366906885_lam8(V self, V *args) {
  V v_x_2461 = args[0];
  V v_hd_249 = heff_env(self)[0];
  V v_k_2410 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2461);
  V v_t_2462 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2463 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2462})});
  V v_t_2464 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2463})});
  V v_t_2465 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2464})});
  V v_t_2466 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2465})});
  V v_t_2467 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2466})});
  V v_t_2468 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2467})});
  return (g_co_2eop_24s615738393x1686646143(heff_tag_n(TAG_InR, 1, (V[]){v_t_2468}), v_hd_249, v_k_2410));
}
V g_heff_2ebuild_2ecommands_2epublishCmd_24s581473772x1366906885_lam9(V self, V *args) {
  V v_x_2477 = args[0];
  V v_hd_249 = heff_env(self)[0];
  V v_k_2410 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2477);
  V v_t_2478 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2479 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2478})});
  V v_t_2480 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2479})});
  V v_t_2481 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2480})});
  V v_t_2482 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2481})});
  V v_t_2483 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2482})});
  V v_t_2484 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2483})});
  return (g_co_2eop_24s615738393x1686646143(heff_tag_n(TAG_InR, 1, (V[]){v_t_2484}), v_hd_249, v_k_2410));
}
V g_heff_2ebuild_2ecommands_2epublishCmd_24s581473772x1366906885_lam6(V self, V *args) {
  V v_x_2435 = args[0];
  V v_x_2429 = heff_env(self)[0];
  V v_hd_249 = heff_env(self)[1];
  V v_k_2410 = heff_env(self)[2];
  V v_x_2430 = heff_env(self)[3];
  V v_cs_2433 = heff_env(self)[4];
  V v_rep_240 = heff_env(self)[5];
  V v_v_241 = heff_env(self)[6];
  heff_clo_take(self, 7);
  heff_drop(v_x_2435);
  V v_t_2436 = heff_dup(heff_rfield(v_x_2429, 3));
  switch (heff_tag_of(v_t_2436)) {
  case TAG_Nothing: {
    heff_drop_rec(v_x_2429, 5);
    heff_drop(v_x_2430);
    heff_drop(v_cs_2433);
    heff_drop(v_rep_240);
    heff_drop(v_v_241);
    V v_t_2437 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2epublishCmd_24s581473772x1366906885_str4), NTAG(TAG_MkUnit)});
    V v_t_2438 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2437})});
    V v_t_2439 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2438})});
    V v_t_2440 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2439})});
    V v_t_2441 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2440})});
    V v_t_2442 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2441})});
    V v_t_2443 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2442})});
    return (g_co_2eop_24s615738393x1686646143(heff_tag_n(TAG_InR, 1, (V[]){v_t_2443}), heff_dup(v_hd_249), heff_clo_n(g_heff_2ebuild_2ecommands_2epublishCmd_24s581473772x1366906885_lam7, 1, 2, (V[]){v_hd_249, v_k_2410})));
  }
  case TAG_Just: {
    V v_pk_2452 = heff_field(v_t_2436, 0);
    V v_ru_24t_2436_24Just = heff_take_reuse_n(v_t_2436, 1ULL, 1);
    if (heff_intLt_c(MK_INT(0LL), v_x_2430)) {
      heff_drop_rec(v_x_2429, 5);
      heff_drop(v_cs_2433);
      heff_drop(v_rep_240);
      heff_drop(v_v_241);
      heff_drop(v_pk_2452);
      V v_t_2454 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2epublishCmd_24s581473772x1366906885_str5), NTAG(TAG_MkUnit)});
      V v_t_2455 = heff_tag_at_n(v_ru_24t_2436_24Just, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2454})});
      V v_t_2456 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2455})});
      V v_t_2457 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2456})});
      V v_t_2458 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2457})});
      V v_t_2459 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2458})});
      V v_t_2460 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2459})});
      return (g_co_2eop_24s615738393x1686646143(heff_tag_n(TAG_InR, 1, (V[]){v_t_2460}), heff_dup(v_hd_249), heff_clo_n(g_heff_2ebuild_2ecommands_2epublishCmd_24s581473772x1366906885_lam8, 1, 2, (V[]){v_hd_249, v_k_2410})));
    } else {
      V v_t_2469 = ({ V a_0 = v_cs_2433; V r_ = (g_list_2eany_24s1740858080x874135214(a_0)); heff_drop(v_cs_2433); r_; });
      if ((heff_dup(v_t_2469) == NTAG(TAG_True))) {
        heff_drop_rec(v_x_2429, 5);
        heff_drop(v_rep_240);
        heff_drop(v_v_241);
        heff_drop(v_pk_2452);
        heff_drop(v_t_2469);
        V v_t_2470 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2epublishCmd_24s581473772x1366906885_str6), NTAG(TAG_MkUnit)});
        V v_t_2471 = heff_tag_at_n(v_ru_24t_2436_24Just, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2470})});
        V v_t_2472 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2471})});
        V v_t_2473 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2472})});
        V v_t_2474 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2473})});
        V v_t_2475 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2474})});
        V v_t_2476 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2475})});
        return (g_co_2eop_24s615738393x1686646143(heff_tag_n(TAG_InR, 1, (V[]){v_t_2476}), heff_dup(v_hd_249), heff_clo_n(g_heff_2ebuild_2ecommands_2epublishCmd_24s581473772x1366906885_lam9, 1, 2, (V[]){v_hd_249, v_k_2410})));
      } else {
        heff_drop_cell(v_ru_24t_2436_24Just, 1);
        heff_drop(v_t_2469);
        return (g_heff_2ebuild_2ecommands_2epublishChecked_24s922680055x1348891372(v_rep_240, v_v_241, v_x_2429, v_pk_2452, v_hd_249, v_k_2410));
      }
    }
  }
  default: return heff_nomatch(v_t_2436);
  }
}
V g_heff_2ebuild_2ecommands_2epublishCmd_24s581473772x1366906885_lam5(V self, V *args) {
  V v_x_2432 = args[0];
  V v_rep_240 = heff_env(self)[0];
  V v_hd_249 = heff_env(self)[1];
  V v_x_2429 = heff_env(self)[2];
  V v_k_2410 = heff_env(self)[3];
  V v_x_2430 = heff_env(self)[4];
  V v_v_241 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_cs_2433 = heff_get_n(v_x_2432, 0, 2);
  V v_c_2434 = (g_heff_2ebuild_2ecommands_2eputFileDiags_24s415097226x198460927(heff_dup(v_rep_240), heff_dup(v_cs_2433)));
  V f_ = v_c_2434;
  heff_room[0] = heff_dup(v_hd_249);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2epublishCmd_24s581473772x1366906885_lam6, 1, 7, (V[]){v_x_2429, v_hd_249, v_k_2410, v_x_2430, v_cs_2433, v_rep_240, v_v_241});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2epublishCmd_24s581473772x1366906885_lam4(V self, V *args) {
  V v_x_2430 = args[0];
  V v_x_2429 = heff_env(self)[0];
  V v_hd_249 = heff_env(self)[1];
  V v_rep_240 = heff_env(self)[2];
  V v_k_2410 = heff_env(self)[3];
  V v_v_241 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_c_2431 = (g_heff_2ebuild_2esession_2ecachedAcc_24s1827793511x304312721(heff_dup(v_x_2429)));
  V f_ = v_c_2431;
  heff_room[0] = heff_dup(v_hd_249);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2epublishCmd_24s581473772x1366906885_lam5, 1, 6, (V[]){v_rep_240, v_hd_249, v_x_2429, v_k_2410, v_x_2430, v_v_241});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2epublishCmd_24s581473772x1366906885_lam3(V self, V *args) {
  V v_x_2429 = args[0];
  V v_hd_249 = heff_env(self)[0];
  V v_rep_240 = heff_env(self)[1];
  V v_k_2410 = heff_env(self)[2];
  V v_v_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2ebuild_2ecommands_2eprintErrs_24s115117455x797094904(((V)&g_heff_2ebuild_2ecommands_2epublishCmd_24s581473772x1366906885_str3), heff_dup(heff_rfield(v_x_2429, 1)), MK_INT(0LL), heff_dup(v_hd_249), heff_clo_n(g_heff_2ebuild_2ecommands_2epublishCmd_24s581473772x1366906885_lam4, 1, 5, (V[]){v_x_2429, v_hd_249, v_rep_240, v_k_2410, v_v_241})));
}
V g_heff_2ebuild_2ecommands_2epublishCmd_24s581473772x1366906885_lam1(V self, V *args) {
  V v_x_2411 = args[0];
  V v_hd_249 = heff_env(self)[0];
  V v_k_2410 = heff_env(self)[1];
  V v_rep_240 = heff_env(self)[2];
  V v_v_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  switch (heff_tag_of(v_x_2411)) {
  case TAG_Nothing: {
    heff_drop(v_rep_240);
    heff_drop(v_v_241);
    V v_t_2412 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2epublishCmd_24s581473772x1366906885_str1), NTAG(TAG_MkUnit)});
    V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
    V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
    V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
    V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
    V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
    V v_t_2418 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2417})});
    return (g_co_2eop_24s615738393x1686646143(heff_tag_n(TAG_InR, 1, (V[]){v_t_2418}), heff_dup(v_hd_249), heff_clo_n(g_heff_2ebuild_2ecommands_2epublishCmd_24s581473772x1366906885_lam2, 1, 2, (V[]){v_hd_249, v_k_2410})));
  }
  case TAG_Just: {
    heff_take_n(v_x_2411, 0ULL, 1);
    V v_c_2428 = (g_heff_2ebuild_2ecommands_2eload_24s1410275656x228048283(((V)&g_heff_2ebuild_2ecommands_2epublishCmd_24s581473772x1366906885_str2)));
    V f_ = v_c_2428;
    heff_room[0] = heff_dup(v_hd_249);
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2epublishCmd_24s581473772x1366906885_lam3, 1, 4, (V[]){v_hd_249, v_rep_240, v_k_2410, v_v_241});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_x_2411);
  }
}
V g_heff_2ebuild_2ecommands_2epublishCmd_24s581473772x1366906885_lam0(V self, V *args) {
  V v_hd_249 = args[0];
  V v_k_2410 = args[1];
  V v_c_248 = heff_env(self)[0];
  V v_rep_240 = heff_env(self)[1];
  V v_v_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_248;
  args[0] = heff_dup(v_hd_249);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2epublishCmd_24s581473772x1366906885_lam1, 1, 4, (V[]){v_hd_249, v_k_2410, v_rep_240, v_v_241});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2ecommands_2epublishCmd_24s581473772x1366906885_lam11(V self, V *args) {
  V v_x_2496 = args[0];
  V v_hd_2485 = heff_env(self)[0];
  V v_k_2486 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2496);
  V v_t_2497 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2498 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2497})});
  V v_t_2499 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2498})});
  V v_t_24100 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2499})});
  V v_t_24101 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24100})});
  V v_t_24102 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24101})});
  V v_t_24103 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24102})});
  return (g_co_2eop_24s615738393x1686646143(heff_tag_n(TAG_InR, 1, (V[]){v_t_24103}), v_hd_2485, v_k_2486));
}
V g_heff_2ebuild_2ecommands_2epublishCmd_24s581473772x1366906885_lam10(V self, V *args) {
  V v_hd_2485 = args[0];
  V v_k_2486 = args[1];
  V v_v_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2487 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2epublishCmd_24s581473772x1366906885_str7), heff_strAppend(v_v_241, ((V)&g_heff_2ebuild_2ecommands_2epublishCmd_24s581473772x1366906885_str8)));
  V v_t_2488 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2epublishCmd_24s581473772x1366906885_str9), v_t_2487), ((V)&g_heff_2ebuild_2ecommands_2epublishCmd_24s581473772x1366906885_str10));
  V v_t_2489 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2488, NTAG(TAG_MkUnit)});
  V v_t_2490 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2489})});
  V v_t_2491 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2490})});
  V v_t_2492 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2491})});
  V v_t_2493 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2492})});
  V v_t_2494 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2493})});
  V v_t_2495 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2494})});
  return (g_co_2eop_24s615738393x1686646143(heff_tag_n(TAG_InR, 1, (V[]){v_t_2495}), heff_dup(v_hd_2485), heff_clo_n(g_heff_2ebuild_2ecommands_2epublishCmd_24s581473772x1366906885_lam11, 1, 2, (V[]){v_hd_2485, v_k_2486})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprintEvals_24s906160764x145037181_str0, 3, " = ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprintEvals_24s906160764x145037181_str1, 1, "\012");
V g_heff_2ebuild_2ecommands_2eprintEvals_24s906160764x145037181_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2eprintEvals_24s906160764x145037181_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eprintEvals_24s906160764x145037181_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eprintEvals_24s906160764x145037181_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2eprintEvals_24s906160764x145037181(V v_x1_240, V v_p_241, V v_p_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_p_241);
    return heff_tail(v_p_242, 1, (V[]){NTAG(TAG_False)});
  }
  case TAG_Cons: {
    V v_d_243 = heff_field(v_x1_240, 0);
    V v_rest_244 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_245 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eprintEvals_24s906160764x145037181_str0), heff_dup(heff_rfield(v_d_243, 1)));
    V v_t_246 = heff_strAppend(heff_dup(heff_rfield(v_d_243, 0)), v_t_245);
    V v_t_247 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Write, 2, (V[]){heff_strAppend(v_t_246, ((V)&g_heff_2ebuild_2ecommands_2eprintEvals_24s906160764x145037181_str1)), NTAG(TAG_MkUnit)});
    V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
    V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
    V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
    V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
    V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
    V v_t_2413 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2412})});
    HEFF_LAST return g_co_2eop_24s615738393x1686646143(heff_tag_n(TAG_InR, 1, (V[]){v_t_2413}), heff_dup(v_p_241), heff_clo_n(g_heff_2ebuild_2ecommands_2eprintEvals_24s906160764x145037181_lam0, 1, 4, (V[]){v_rest_244, v_p_241, v_d_243, v_p_242}));
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2ecommands_2eprintEvals_24s906160764x145037181_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eprintEvals_24s906160764x145037181(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2ecommands_2eprintEvals_24s906160764x145037181_lam1(V self, V *args) {
  V v_x_2415 = args[0];
  V v_d_243 = heff_env(self)[0];
  V v_p_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2416 = heff_get_n(v_d_243, 2, 3);
  V v_t_2417;
  if ((heff_dup(v_t_2416) == NTAG(TAG_True))) {
    heff_drop(v_x_2415);
    heff_drop(v_t_2416);
    v_t_2417 = NTAG(TAG_True);
  } else {
    heff_drop(v_t_2416);
    v_t_2417 = v_x_2415;
  }
  V f_ = v_p_242;
  args[0] = v_t_2417;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eprintEvals_24s906160764x145037181_lam0(V self, V *args) {
  V v_x_2414 = args[0];
  V v_rest_244 = heff_env(self)[0];
  V v_p_241 = heff_env(self)[1];
  V v_d_243 = heff_env(self)[2];
  V v_p_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2414);
  return (g_heff_2ebuild_2ecommands_2eprintEvals_24s906160764x145037181(v_rest_244, v_p_241, heff_clo_n(g_heff_2ebuild_2ecommands_2eprintEvals_24s906160764x145037181_lam1, 1, 2, (V[]){v_d_243, v_p_242})));
}