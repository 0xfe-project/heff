// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Collected 38917
#define TAG_Complete 48856
#define TAG_End 17255
#define TAG_Exit 20279
#define TAG_Exited 20560
#define TAG_FailBecause 16014
#define TAG_Left 13886
#define TAG_MkPath 49630
#define TAG_NoInput 41055
#define TAG_NotRun 12703
#define TAG_Platform 55558
#define TAG_Posix 44191
#define TAG_ProgramPath 46819
#define TAG_Right 62770
#define TAG_Run 29975
#define TAG_Signalled 34337
#define TAG_Start 63542
#define TAG_TimedOut 6056
#define TAG_Windows 49101
#define TAG_Write 36323
#define TAG_WriteErr 37283
#define TAG_Wrong 41905
#define LBL_args 9498020
#define LBL_bind 9519364
#define LBL_bug 307438
#define LBL_command 1182252425
#define LBL_diags 296935042
#define LBL_dir 308999
#define LBL_done 9584713
#define LBL_ended 298010324
#define LBL_env 310119
#define LBL_err 310239
#define LBL_errors 652506774
#define LBL_expected 956903529
#define LBL_goldens 436112074
#define LBL_group 299987609
#define LBL_heff 9694020
#define LBL_input 301716452
#define LBL_keep 9783372
#define LBL_malg 9839318
#define LBL_module 878357911
#define LBL_msg 317947
#define LBL_name 9869138
#define LBL_ok 10307
#define LBL_out 319944
#define LBL_output 941629484
#define LBL_package 1572278921
#define LBL_path 9928940
#define LBL_source 1050636102
#define LBL_style 311138763
#define LBL_timeout 1065429926
#define LBL_value 313331083
#define LBL_watch 314261737
static uint32_t shape_command__args__dir__env__input__output__errors__timeout__keep__group[] = {LBL_command, LBL_args, LBL_dir, LBL_env, LBL_input, LBL_output, LBL_errors, LBL_timeout, LBL_keep, LBL_group};
V g_co_2eop_24s1204515794x2100690815(V, V, V, V, V, V, V, V);
V g_co_2eop_24s1204515794x2100690815_entry(V self, V *a);
extern Clo g_co_2eop_24s1204515794x2100690815_clo;
V g_co_2eop_24s615738393x1686646143(V, V, V);
V g_co_2eop_24s615738393x1686646143_entry(V self, V *a);
extern Clo g_co_2eop_24s615738393x1686646143_clo;
V g_co_2eop_24s615738393x1686646143_24tok1(V, V, V, V);
V g_co_2eop_24s615738393x1686646143_24tok1_entry(V self, V *a);
extern Clo g_co_2eop_24s615738393x1686646143_24tok1_clo;
V g_co_2eop_24s615738393x1686646143_24tok2(V, V, V, V);
V g_co_2eop_24s615738393x1686646143_24tok2_entry(V self, V *a);
extern Clo g_co_2eop_24s615738393x1686646143_24tok2_clo;
V g_co_2eop_24s710864882x261522381(V, V, V, V, V, V, V);
V g_co_2eop_24s710864882x261522381_entry(V self, V *a);
extern Clo g_co_2eop_24s710864882x261522381_clo;
V g_exception_2eattempted_24s85350750x49672201_get(void);
V g_heff_2ebuild_2ecommands_2ebackDirOf(V);
V g_heff_2ebuild_2ecommands_2ebackDirOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ebackDirOf_clo;
V g_heff_2ebuild_2ecommands_2ecommitAt_24s1687144202x1882378819(V, V);
V g_heff_2ebuild_2ecommands_2ecommitAt_24s1687144202x1882378819_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecommitAt_24s1687144202x1882378819_clo;
V g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941(V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941_clo;
V g_heff_2ebuild_2ecommands_2ecwdNow_24s507786937x461532604(V, V);
V g_heff_2ebuild_2ecommands_2ecwdNow_24s507786937x461532604_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecwdNow_24s507786937x461532604_clo;
V g_heff_2ebuild_2ecommands_2ediagCount_24s823746706x1248851912(V);
V g_heff_2ebuild_2ecommands_2ediagCount_24s823746706x1248851912_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ediagCount_24s823746706x1248851912_clo;
V g_heff_2ebuild_2ecommands_2edocPageWritten_24s1466416307x1099964288(V, V, V, V);
V g_heff_2ebuild_2ecommands_2edocPageWritten_24s1466416307x1099964288_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2edocPageWritten_24s1466416307x1099964288_clo;
V g_heff_2ebuild_2ecommands_2edocPagesWritten_24s186486549x585078911(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2edocPagesWritten_24s186486549x585078911_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2edocPagesWritten_24s186486549x585078911_clo;
V g_heff_2ebuild_2ecommands_2eemitErrs_24s394189364x2134712221(V, V, V);
V g_heff_2ebuild_2ecommands_2eemitErrs_24s394189364x2134712221_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eemitErrs_24s394189364x2134712221_clo;
V g_heff_2ebuild_2ecommands_2eemitErrs_24s394189364x2134712221_24tok1(V, V, V, V);
V g_heff_2ebuild_2ecommands_2eemitErrs_24s394189364x2134712221_24tok1_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eemitErrs_24s394189364x2134712221_24tok1_clo;
V g_heff_2ebuild_2ecommands_2eemitErrs_24s394189364x2134712221_24tok2(V, V, V, V);
V g_heff_2ebuild_2ecommands_2eemitErrs_24s394189364x2134712221_24tok2_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eemitErrs_24s394189364x2134712221_24tok2_clo;
V g_heff_2ebuild_2ecommands_2eexisting_24s783863025x1958439471(V, V, V, V);
V g_heff_2ebuild_2ecommands_2eexisting_24s783863025x1958439471_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eexisting_24s783863025x1958439471_clo;
V g_heff_2ebuild_2ecommands_2efailLine(V, V, V);
V g_heff_2ebuild_2ecommands_2efailLine_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2efailLine_clo;
HeffT2 g_heff_2ebuild_2ecommands_2efirstErrorOf_24cpr(V);
V g_heff_2ebuild_2ecommands_2egoldenAgainst_24s992520432x896454450(V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2egoldenAgainst_24s992520432x896454450_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2egoldenAgainst_24s992520432x896454450_clo;
V g_heff_2ebuild_2ecommands_2egoldenPath(V, V, V);
V g_heff_2ebuild_2ecommands_2egoldenPath_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2egoldenPath_clo;
V g_heff_2ebuild_2ecommands_2egoldenSaid_24s1045388766x363711794(V, V, V);
V g_heff_2ebuild_2ecommands_2egoldenSaid_24s1045388766x363711794_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2egoldenSaid_24s1045388766x363711794_clo;
V g_heff_2ebuild_2ecommands_2egoldensGo_24s1881795521x39532647(V, V, V, V);
V g_heff_2ebuild_2ecommands_2egoldensGo_24s1881795521x39532647_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2egoldensGo_24s1881795521x39532647_clo;
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1606122519x1439074770(V, V);
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1606122519x1439074770_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1606122519x1439074770_clo;
V g_heff_2ebuild_2ecommands_2einitCmd_24s795893522x1842903301(V, V, V);
V g_heff_2ebuild_2ecommands_2einitCmd_24s795893522x1842903301_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2einitCmd_24s795893522x1842903301_clo;
HeffT2 g_heff_2ebuild_2ecommands_2einitProblem_24cpr(V, V);
V g_heff_2ebuild_2ecommands_2eload_24s1410275656x228048283(V);
V g_heff_2ebuild_2ecommands_2eload_24s1410275656x228048283_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eload_24s1410275656x228048283_clo;
V g_heff_2ebuild_2ecommands_2enoRes_get(void);
V g_heff_2ebuild_2ecommands_2eownPackage_24s693628669x534541312(V, V);
V g_heff_2ebuild_2ecommands_2eownPackage_24s693628669x534541312_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eownPackage_24s693628669x534541312_clo;
V g_heff_2ebuild_2ecommands_2eprintErrs_24s115117455x797094904(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eprintErrs_24s115117455x797094904_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprintErrs_24s115117455x797094904_clo;
V g_heff_2ebuild_2ecommands_2eprintEvals_24s906160764x145037181(V, V, V);
V g_heff_2ebuild_2ecommands_2eprintEvals_24s906160764x145037181_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprintEvals_24s906160764x145037181_clo;
V g_heff_2ebuild_2ecommands_2eprintFails_24s1263841563x776765553(V, V, V);
V g_heff_2ebuild_2ecommands_2eprintFails_24s1263841563x776765553_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprintFails_24s1263841563x776765553_clo;
V g_heff_2ebuild_2ecommands_2eprojectFiles(V, V);
V g_heff_2ebuild_2ecommands_2eprojectFiles_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprojectFiles_clo;
V g_heff_2ebuild_2ecommands_2eprojectName(V, V, V);
V g_heff_2ebuild_2ecommands_2eprojectName_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprojectName_clo;
V g_heff_2ebuild_2ecommands_2epublishChecked_24s922680055x1348891372(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2epublishChecked_24s922680055x1348891372_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2epublishChecked_24s922680055x1348891372_clo;
V g_heff_2ebuild_2ecommands_2epublishCmd_24s581473772x1366906885(V, V);
V g_heff_2ebuild_2ecommands_2epublishCmd_24s581473772x1366906885_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2epublishCmd_24s581473772x1366906885_clo;
V g_heff_2ebuild_2ecommands_2epublishGit_24s211231607x115039889(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2epublishGit_24s211231607x115039889_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2epublishGit_24s211231607x115039889_clo;
V g_heff_2ebuild_2ecommands_2epublishTested_24s563627996x2090231580(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2epublishTested_24s563627996x2090231580_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2epublishTested_24s563627996x2090231580_clo;
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s415097226x198460927(V, V);
V g_heff_2ebuild_2ecommands_2eputFileDiags_24s415097226x198460927_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eputFileDiags_24s415097226x198460927_clo;
V g_heff_2ebuild_2ecommands_2eremoveStale_24s1076505188x1773366585(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eremoveStale_24s1076505188x1773366585_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eremoveStale_24s1076505188x1773366585_clo;
V g_heff_2ebuild_2ecommands_2erevNamed(V);
V g_heff_2ebuild_2ecommands_2erevNamed_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2erevNamed_clo;
V g_heff_2ebuild_2ecommands_2erevSaid(V);
V g_heff_2ebuild_2ecommands_2erevSaid_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2erevSaid_clo;
V g_heff_2ebuild_2ecommands_2eselfFrom_24s176185486x602532917(V, V, V);
V g_heff_2ebuild_2ecommands_2eselfFrom_24s176185486x602532917_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eselfFrom_24s176185486x602532917_clo;
V g_heff_2ebuild_2ecommands_2eselfHash_24s2023922332x1057539294(V, V, V);
V g_heff_2ebuild_2ecommands_2eselfHash_24s2023922332x1057539294_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eselfHash_24s2023922332x1057539294_clo;
V g_heff_2ebuild_2ecommands_2eselfPath_24s1432537356x1686629462(V, V);
V g_heff_2ebuild_2ecommands_2eselfPath_24s1432537356x1686629462_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eselfPath_24s1432537356x1686629462_clo;
HeffT2 g_heff_2ebuild_2ecommands_2especOf_24cpr(V);
V g_heff_2ebuild_2ecommands_2etestAll_24s749792949x1328449028(V, V, V);
V g_heff_2ebuild_2ecommands_2etestAll_24s749792949x1328449028_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2etestAll_24s749792949x1328449028_clo;
V g_heff_2ebuild_2ecommands_2ewithGoldens_24s1327649047x255568769(V, V, V);
V g_heff_2ebuild_2ecommands_2ewithGoldens_24s1327649047x255568769_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ewithGoldens_24s1327649047x255568769_clo;
V g_heff_2ebuild_2ecommands_2ewriteAll_24s302415776x955929641(V, V, V, V);
V g_heff_2ebuild_2ecommands_2ewriteAll_24s302415776x955929641_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ewriteAll_24s302415776x955929641_clo;
V g_heff_2ebuild_2ecommands_2ewriteOut_24s1442511881x314947241(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ewriteOut_24s1442511881x314947241_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ewriteOut_24s1442511881x314947241_clo;
V g_heff_2ebuild_2ecommands_2ewriteOutC_24s1877451407x355012956(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ewriteOutC_24s1877451407x355012956_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ewriteOutC_24s1877451407x355012956_clo;
V g_heff_2ebuild_2ecommands_2ewriteParts_24s1069210723x719436499(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ewriteParts_24s1069210723x719436499_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ewriteParts_24s1069210723x719436499_clo;
V g_heff_2ebuild_2ecommands_2ewritePartsGo_24s2124042284x1735199047(V, V, V, V);
V g_heff_2ebuild_2ecommands_2ewritePartsGo_24s2124042284x1735199047_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ewritePartsGo_24s2124042284x1735199047_clo;
V g_heff_2ebuild_2edocpages_2epage(V);
V g_heff_2ebuild_2edocpages_2epage_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edocpages_2epage_clo;
V g_heff_2ebuild_2eload_2ecachedDir(V, V, V);
V g_heff_2ebuild_2eload_2ecachedDir_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2ecachedDir_clo;
HeffT2 g_heff_2ebuild_2eproject_2epackageLit_24cpr(V);
HeffT2 g_heff_2ebuild_2eproject_2epackageOf_24cpr(V);
V g_heff_2ebuild_2eproject_2epseudoVersion(V, V, V);
V g_heff_2ebuild_2eproject_2epseudoVersion_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2epseudoVersion_clo;
V g_heff_2ebuild_2eproject_2erepoOf(V);
V g_heff_2ebuild_2eproject_2erepoOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2erepoOf_clo;
HeffT2 g_heff_2ebuild_2eproject_2eversion_24cpr(V);
V g_heff_2ebuild_2esession_2ecachedAcc_24s1827793511x304312721(V);
V g_heff_2ebuild_2esession_2ecachedAcc_24s1827793511x304312721_entry(V self, V *a);
extern Clo g_heff_2ebuild_2esession_2ecachedAcc_24s1827793511x304312721_clo;
V g_heff_2elsp_2erender_2ediagWhere(V, V, V);
V g_heff_2elsp_2erender_2ediagWhere_entry(V self, V *a);
extern Clo g_heff_2elsp_2erender_2ediagWhere_clo;
V g_heff_2elsp_2erender_2eprtCode(V);
V g_heff_2elsp_2erender_2eprtCode_entry(V self, V *a);
extern Clo g_heff_2elsp_2erender_2eprtCode_clo;
V g_heff_2elsp_2ereport_2emismatch(V, V, V);
V g_heff_2elsp_2ereport_2emismatch_entry(V self, V *a);
extern Clo g_heff_2elsp_2ereport_2emismatch_clo;
V g_list_2eall_24s523006110x1088755562(V);
V g_list_2eall_24s523006110x1088755562_entry(V self, V *a);
extern Clo g_list_2eall_24s523006110x1088755562_clo;
V g_list_2eany_24s1740858080x874135214(V);
V g_list_2eany_24s1740858080x874135214_entry(V self, V *a);
extern Clo g_list_2eany_24s1740858080x874135214_clo;
V g_list_2edrop(V, V);
V g_list_2edrop_entry(V self, V *a);
extern Clo g_list_2edrop_clo;
V g_list_2efoldl_24f2094160282x1876485468(V, V, V);
V g_list_2efoldl_24f2094160282x1876485468_entry(V self, V *a);
extern Clo g_list_2efoldl_24f2094160282x1876485468_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2ekeepIf_24s1161549307x1906011635(V);
V g_list_2ekeepIf_24s1161549307x1906011635_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1161549307x1906011635_clo;
V g_list_2emap_24s219049803x1458391381(V);
V g_list_2emap_24s219049803x1458391381_entry(V self, V *a);
extern Clo g_list_2emap_24s219049803x1458391381_clo;
V g_list_2emap_24s370939663x1496042695(V, V);
V g_list_2emap_24s370939663x1496042695_entry(V self, V *a);
extern Clo g_list_2emap_24s370939663x1496042695_clo;
V g_prelude_2einstanceShowString_2eescapedFrom_241(V, V, V);
V g_prelude_2einstanceShowString_2eescapedFrom_241_entry(V self, V *a);
extern Clo g_prelude_2einstanceShowString_2eescapedFrom_241_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_prelude_2eskipSpaces(V, V, V);
V g_prelude_2eskipSpaces_entry(V self, V *a);
extern Clo g_prelude_2eskipSpaces_clo;
V g_prelude_2esplitFrom(V, V, V, V, V);
V g_prelude_2esplitFrom_entry(V self, V *a);
extern Clo g_prelude_2esplitFrom_clo;
V g_std_2efilesystem_2emakeDirectory_24s1800594932x1926120429(V);
V g_std_2efilesystem_2emakeDirectory_24s1800594932x1926120429_entry(V self, V *a);
extern Clo g_std_2efilesystem_2emakeDirectory_24s1800594932x1926120429_clo;
V g_std_2efilesystem_2ereadDirectory_24s2065195248x940975556(V);
V g_std_2efilesystem_2ereadDirectory_24s2065195248x940975556_entry(V self, V *a);
extern Clo g_std_2efilesystem_2ereadDirectory_24s2065195248x940975556_clo;
V g_std_2efilesystem_2ereadFile_24s2092922012x215966209(V);
V g_std_2efilesystem_2ereadFile_24s2092922012x215966209_entry(V self, V *a);
extern Clo g_std_2efilesystem_2ereadFile_24s2092922012x215966209_clo;
V g_std_2efilesystem_2eremove_24s1441356369x419789784(V);
V g_std_2efilesystem_2eremove_24s1441356369x419789784_entry(V self, V *a);
extern Clo g_std_2efilesystem_2eremove_24s1441356369x419789784_clo;
V g_std_2efilesystem_2ewriteFile_24s1441161512x485333423(V, V);
V g_std_2efilesystem_2ewriteFile_24s1441161512x485333423_entry(V self, V *a);
extern Clo g_std_2efilesystem_2ewriteFile_24s1441161512x485333423_clo;
V g_std_2epath_2ecurrent_get(void);
V g_std_2epath_2ejoin(V, V);
V g_std_2epath_2ejoin_entry(V self, V *a);
extern Clo g_std_2epath_2ejoin_clo;
V g_std_2epath_2enative_get(void);
V g_std_2epath_2eparse(V, V);
V g_std_2epath_2eparse_entry(V self, V *a);
extern Clo g_std_2epath_2eparse_clo;
HeffT3 g_std_2epath_2eparse_24cpr(V, V);
V g_std_2epath_2erender(V, V);
V g_std_2epath_2erender_entry(V self, V *a);
extern Clo g_std_2epath_2erender_clo;
V g_std_2epath_2esameSegments(V, V);
V g_std_2epath_2esameSegments_entry(V self, V *a);
extern Clo g_std_2epath_2esameSegments_clo;
V g_std_2eprocess_2erun_24s1262677465x1574883892(V, V, V, V, V);
V g_std_2eprocess_2erun_24s1262677465x1574883892_entry(V self, V *a);
extern Clo g_std_2eprocess_2erun_24s1262677465x1574883892_clo;
V g_std_2eprogress_2eroot_get(void);
HEFF_LIT(g_heff_2ebuild_2ecommands_2efirstErrorOf_24cpr_str0, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efirstErrorOf_24cpr_str1, 2, ": ");

HeffT2 g_heff_2ebuild_2ecommands_2efirstErrorOf_24cpr(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_c_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    heff_take_n(v_x1_240, 3ULL, 2);
    V v_diags_243 = heff_take_field(v_c_241, 6);
    V v_path_244 = heff_take_field(v_c_241, 1);
    V v_source_245 = heff_get_n(v_c_241, 3, 14);
    V v_x2_246 = (g_list_2ekeepIf_24s1161549307x1906011635(v_diags_243));
    switch (heff_tag_of(v_x2_246)) {
    case TAG_Nil: {
      heff_drop(v_path_244);
      heff_drop(v_source_245);
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Cons: {
      V v_d_247 = heff_field(v_x2_246, 0);
      heff_take_n(v_x2_246, 1ULL, 2);
      heff_drop(v_rest_242);
      V v_t_249 = ({ V a_0 = v_path_244; V a_1 = v_source_245; V a_2 = heff_dup(v_d_247); V r_ = (g_heff_2elsp_2erender_2ediagWhere(a_0, a_1, a_2)); heff_drop(v_source_245); r_; });
      V v_t_2410 = (g_heff_2elsp_2erender_2eprtCode(heff_dup(v_d_247)));
      V v_t_2411 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efirstErrorOf_24cpr_str0), heff_get_n(v_d_247, 2, 5));
      V v_t_2412 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2efirstErrorOf_24cpr_str1), heff_strAppend(v_t_2410, v_t_2411));
      V v_why_2413 = heff_strAppend(v_t_249, v_t_2412);
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_why_2413}});
    }
    default: return ((HeffT2){{heff_nomatch(v_x2_246)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2especOf_24cpr_str0, 1, "@");
HEFF_LIT(g_heff_2ebuild_2ecommands_2especOf_24cpr_str1, 1, "@");

HeffT2 g_heff_2ebuild_2ecommands_2especOf_24cpr(V v_spec_240) {
top: ;
  V v_it_241 = ({ V b_0 = ((V)&g_heff_2ebuild_2ecommands_2especOf_24cpr_str0); V a_1 = v_spec_240; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2ecommands_2especOf_24cpr_str1), v_spec_240, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
  switch (heff_tag_of(v_it_241)) {
  case TAG_Nil: {
    return ((HeffT2){{v_spec_240, NTAG(TAG_Nothing)}});
  }
  case TAG_Cons: {
    V v_path_242 = heff_field(v_it_241, 0);
    V v_it2_243 = heff_field(v_it_241, 1);
    heff_take_n(v_it_241, 3ULL, 2);
    switch (heff_tag_of(v_it2_243)) {
    case TAG_Nil: {
      heff_drop(v_path_242);
      return ((HeffT2){{v_spec_240, NTAG(TAG_Nothing)}});
    }
    case TAG_Cons: {
      V v_v_244 = heff_field(v_it2_243, 0);
      V v_it22_245 = heff_field(v_it2_243, 1);
      heff_take_n(v_it2_243, 3ULL, 2);
      switch (heff_tag_of(v_it22_245)) {
      case TAG_Nil: {
        heff_drop(v_spec_240);
        return ((HeffT2){{v_path_242, heff_tag_n(TAG_Just, 1, (V[]){v_v_244})}});
      }
      case TAG_Cons: {
        heff_take_n(v_it22_245, 0ULL, 2);
        heff_drop(v_path_242);
        heff_drop(v_v_244);
        return ((HeffT2){{v_spec_240, NTAG(TAG_Nothing)}});
      }
      default: return ((HeffT2){{heff_nomatch(v_it22_245)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_it2_243)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_it_241)}});
  }
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eselfPath_24s1432537356x1686629462_str0, 5, "win32");
V g_heff_2ebuild_2ecommands_2eselfPath_24s1432537356x1686629462_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eselfPath_24s1432537356x1686629462_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eselfPath_24s1432537356x1686629462_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2eselfPath_24s1432537356x1686629462_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eselfPath_24s1432537356x1686629462_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eselfPath_24s1432537356x1686629462_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2eselfPath_24s1432537356x1686629462_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2eselfPath_24s1432537356x1686629462_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eselfPath_24s1432537356x1686629462_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eselfPath_24s1432537356x1686629462_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2eselfPath_24s1432537356x1686629462(V v_hd_240, V v_k_241) {
top: ;
  V v_bind_242 = heff_take_field(v_hd_240, 1);
  V v_malg_243 = heff_get_n(v_hd_240, 2, 3);
  V v_t_245 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2eselfPath_24s1432537356x1686629462_lam0_clo)})});
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_245})});
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tr(heff_call(heff_dup(v_malg_243), 1, (V[]){v_t_2411}));
  return heff_tail(heff_dup(v_bind_242), 2, (V[]){v_t_2412, heff_clo_n(g_heff_2ebuild_2ecommands_2eselfPath_24s1432537356x1686629462_lam1, 1, 3, (V[]){v_malg_243, v_bind_242, v_k_241})});
}
V g_heff_2ebuild_2ecommands_2eselfPath_24s1432537356x1686629462_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eselfPath_24s1432537356x1686629462(a[0], a[1]);
}
V g_heff_2ebuild_2ecommands_2eselfPath_24s1432537356x1686629462_lam0(V self, V *args) {
  V v_s_244 = args[0];
  return v_s_244;
}
V g_heff_2ebuild_2ecommands_2eselfPath_24s1432537356x1686629462_lam2(V self, V *args) {
  V v_s_2414 = args[0];
  return v_s_2414;
}
V g_heff_2ebuild_2ecommands_2eselfPath_24s1432537356x1686629462_lam3(V self, V *args) {
  V v_x_2423 = args[0];
  V v_x_2413 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2424 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_x_2423; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
  V v_t_2425;
  if (heff_strEq_c(v_x_2413, ((V)&g_heff_2ebuild_2ecommands_2eselfPath_24s1432537356x1686629462_str0))) {
    v_t_2425 = NTAG(TAG_Windows);
  } else {
    v_t_2425 = NTAG(TAG_Posix);
  }
  V v_x_2426 = ({ V a_0 = v_t_2425; V a_1 = v_x_2424; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2425); heff_drop(v_x_2424); r_; });
  V f_ = v_k_241;
  args[0] = v_x_2426;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eselfPath_24s1432537356x1686629462_lam1(V self, V *args) {
  V v_x_2413 = args[0];
  V v_malg_243 = heff_env(self)[0];
  V v_bind_242 = heff_env(self)[1];
  V v_k_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2415 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ProgramPath, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2eselfPath_24s1432537356x1686629462_lam2_clo)})});
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
  V v_t_2421 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2420})});
  V v_t_2422 = heff_tr(heff_call(v_malg_243, 1, (V[]){v_t_2421}));
  V f_ = v_bind_242;
  heff_room[0] = v_t_2422;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2eselfPath_24s1432537356x1686629462_lam3, 1, 2, (V[]){v_x_2413, v_k_241});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eselfHash_24s2023922332x1057539294_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eselfHash_24s2023922332x1057539294_str1, 8, "compiler");
V g_heff_2ebuild_2ecommands_2eselfHash_24s2023922332x1057539294_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eselfHash_24s2023922332x1057539294_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eselfHash_24s2023922332x1057539294_lam1, 3, 0};
V g_heff_2ebuild_2ecommands_2eselfHash_24s2023922332x1057539294_lam3(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eselfHash_24s2023922332x1057539294_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eselfHash_24s2023922332x1057539294_lam3, 3, 0};
V g_heff_2ebuild_2ecommands_2eselfHash_24s2023922332x1057539294_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2eselfHash_24s2023922332x1057539294_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2eselfHash_24s2023922332x1057539294_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eselfHash_24s2023922332x1057539294_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eselfHash_24s2023922332x1057539294_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2eselfHash_24s2023922332x1057539294(V v_ps_240, V v_hd_241, V v_k_242) {
top: ;
  return (g_heff_2ebuild_2ecommands_2eselfPath_24s1432537356x1686629462(heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2ecommands_2eselfHash_24s2023922332x1057539294_lam0, 1, 3, (V[]){v_hd_241, v_k_242, v_ps_240})));
}
V g_heff_2ebuild_2ecommands_2eselfHash_24s2023922332x1057539294_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eselfHash_24s2023922332x1057539294(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2ecommands_2eselfHash_24s2023922332x1057539294_lam1(V self, V *args) {
  V v_x_246 = args[0];
  V v_hd_247 = args[1];
  V v_k_248 = args[2];
  heff_drop(v_hd_247);
  V f_ = v_k_248;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_246});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eselfHash_24s2023922332x1057539294_lam3(V self, V *args) {
  V v_x_2421 = args[0];
  V v_hd_2422 = args[1];
  V v_k_2423 = args[2];
  heff_drop(v_hd_2422);
  V f_ = v_k_2423;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2421});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eselfHash_24s2023922332x1057539294_lam4(V self, V *args) {
  V v_x_2425 = args[0];
  V v_ps_240 = heff_env(self)[0];
  V v_y_2412 = heff_env(self)[1];
  V v_hd_241 = heff_env(self)[2];
  V v_k_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2428;
  switch (heff_tag_of(v_x_2425)) {
  case TAG_Left: {
    heff_take_n(v_x_2425, 0ULL, 1);
    v_t_2428 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Right: {
    V v_y_2427 = heff_field(v_x_2425, 0);
    V v_ru_24x_2425_24Right = heff_take_reuse_n(v_x_2425, 1ULL, 1);
    v_t_2428 = heff_tag_at_n(v_ru_24x_2425_24Right, TAG_Just, 1, (V[]){v_y_2427});
    break;
  }
  default: heff_nomatch(v_x_2425);
  }
  V v_t_2429 = (g_heff_2ebuild_2ecommands_2eselfFrom_24s176185486x602532917(v_ps_240, v_y_2412, v_t_2428));
  V f_ = v_t_2429;
  heff_room[0] = v_hd_241;
  heff_room[1] = v_k_242;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2eselfHash_24s2023922332x1057539294_lam2(V self, V *args) {
  V v_x_2410 = args[0];
  V v_k_242 = heff_env(self)[0];
  V v_ps_240 = heff_env(self)[1];
  V v_hd_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_x_2410)) {
  case TAG_Left: {
    heff_take_n(v_x_2410, 0ULL, 1);
    heff_drop_rec(v_ps_240, 6);
    heff_drop(v_hd_241);
    V f_ = v_k_242;
    args[0] = ((V)&g_heff_2ebuild_2ecommands_2eselfHash_24s2023922332x1057539294_str0);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Right: {
    V v_y_2412 = heff_field(v_x_2410, 0);
    heff_take_n(v_x_2410, 1ULL, 1);
    V v_d_2413 = (g_heff_2ebuild_2ecommands_2ebackDirOf(heff_dup(v_ps_240)));
    V v_st_2414 = heff_dup(heff_rfield(v_ps_240, 5));
    V v_t_2415 = (g_std_2epath_2eparse(v_st_2414, v_d_2413));
    V v_t_2416 = (g_std_2epath_2eparse(v_st_2414, ((V)&g_heff_2ebuild_2ecommands_2eselfHash_24s2023922332x1057539294_str1)));
    V v_t_2417 = (g_std_2epath_2ejoin(v_t_2415, v_t_2416));
    V v_s_2418 = ({ V a_0 = v_st_2414; V a_1 = v_t_2417; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2414); heff_drop(v_t_2417); r_; });
    V v_path_2419 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_s_2418; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
    V v_c_2420 = ({ V a_0 = v_path_2419; V r_ = (g_std_2efilesystem_2ereadFile_24s2092922012x215966209(a_0)); heff_drop(v_path_2419); r_; });
    V v_c_2424 = heff_tr(heff_call(v_c_2420, 2, (V[]){heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), ((V)&g_heff_2ebuild_2ecommands_2eselfHash_24s2023922332x1057539294_lam3_clo)}));
    V f_ = v_c_2424;
    heff_room[0] = heff_dup(v_hd_241);
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2eselfHash_24s2023922332x1057539294_lam4, 1, 4, (V[]){v_ps_240, v_y_2412, v_hd_241, v_k_242});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_x_2410);
  }
}
V g_heff_2ebuild_2ecommands_2eselfHash_24s2023922332x1057539294_lam0(V self, V *args) {
  V v_x_243 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  V v_ps_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_path_244 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_x_243; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
  V v_c_245 = ({ V a_0 = v_path_244; V r_ = (g_std_2efilesystem_2ereadFile_24s2092922012x215966209(a_0)); heff_drop(v_path_244); r_; });
  V v_c_249 = heff_tr(heff_call(v_c_245, 2, (V[]){heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), ((V)&g_heff_2ebuild_2ecommands_2eselfHash_24s2023922332x1057539294_lam1_clo)}));
  V f_ = v_c_249;
  heff_room[0] = heff_dup(v_hd_241);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2eselfHash_24s2023922332x1057539294_lam2, 1, 3, (V[]){v_k_242, v_ps_240, v_hd_241});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ewriteParts_24s1069210723x719436499_str0, 13, "cannot write ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ewriteParts_24s1069210723x719436499_str1, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ewriteParts_24s1069210723x719436499_str2, 13, "cannot write ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ewriteParts_24s1069210723x719436499_str3, 1, "\012");
V g_heff_2ebuild_2ecommands_2ewriteParts_24s1069210723x719436499_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ewriteParts_24s1069210723x719436499_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewriteParts_24s1069210723x719436499_lam1, 3, 0};
V g_heff_2ebuild_2ecommands_2ewriteParts_24s1069210723x719436499_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2ewriteParts_24s1069210723x719436499_lam3(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ewriteParts_24s1069210723x719436499_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewriteParts_24s1069210723x719436499_lam3, 1, 0};
V g_heff_2ebuild_2ecommands_2ewriteParts_24s1069210723x719436499_lam8(V self, V *args);
V g_heff_2ebuild_2ecommands_2ewriteParts_24s1069210723x719436499_lam7(V self, V *args);
V g_heff_2ebuild_2ecommands_2ewriteParts_24s1069210723x719436499_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2ewriteParts_24s1069210723x719436499_lam11(V self, V *args);
V g_heff_2ebuild_2ecommands_2ewriteParts_24s1069210723x719436499_lam10(V self, V *args);
V g_heff_2ebuild_2ecommands_2ewriteParts_24s1069210723x719436499_lam9(V self, V *args);
V g_heff_2ebuild_2ecommands_2ewriteParts_24s1069210723x719436499_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2ewriteParts_24s1069210723x719436499_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ewriteParts_24s1069210723x719436499_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ewriteParts_24s1069210723x719436499_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewriteParts_24s1069210723x719436499_entry, 5, 0};

V g_heff_2ebuild_2ecommands_2ewriteParts_24s1069210723x719436499(V v_dir_240, V v_done_241, V v_x3_242, V v_p_243, V v_p_244) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_MkPair: {
    V v_parts_245 = heff_field(v_x3_242, 0);
    V v_errors_246 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24MkPair = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    return (g_heff_2ebuild_2ecommands_2eemitErrs_24s394189364x2134712221_24tok2(v_ru_24x3_242_24MkPair, heff_dup(v_errors_246), heff_dup(v_p_243), heff_clo_n(g_heff_2ebuild_2ecommands_2ewriteParts_24s1069210723x719436499_lam0, 1, 6, (V[]){v_errors_246, v_dir_240, v_p_243, v_parts_245, v_done_241, v_p_244})));
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2ecommands_2ewriteParts_24s1069210723x719436499_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ewriteParts_24s1069210723x719436499(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ebuild_2ecommands_2ewriteParts_24s1069210723x719436499_lam1(V self, V *args) {
  V v_x_2410 = args[0];
  V v_hd_2411 = args[1];
  V v_k_2412 = args[2];
  heff_drop(v_hd_2411);
  V f_ = v_k_2412;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2410});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ewriteParts_24s1069210723x719436499_lam4(V self, V *args) {
  V v_hd_2419 = args[0];
  V v_k_2420 = args[1];
  V v_x_2418 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2419);
  V f_ = v_k_2420;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2418});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ewriteParts_24s1069210723x719436499_lam3(V self, V *args) {
  V v_x_2417 = args[0];
  V v_x_2418 = (g_list_2emap_24s219049803x1458391381(v_x_2417));
  return heff_clo_n(g_heff_2ebuild_2ecommands_2ewriteParts_24s1069210723x719436499_lam4, 2, 1, (V[]){v_x_2418});
}
V g_heff_2ebuild_2ecommands_2ewriteParts_24s1069210723x719436499_lam8(V self, V *args) {
  V v_x_2435 = args[0];
  V v_p_243 = heff_env(self)[0];
  V v_p_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2435);
  V v_t_2436 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2437 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2436})});
  V v_t_2438 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2437})});
  V v_t_2439 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2438})});
  V v_t_2440 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2439})});
  V v_t_2441 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2440})});
  V v_t_2442 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2441})});
  return (g_co_2eop_24s615738393x1686646143(heff_tag_n(TAG_InR, 1, (V[]){v_t_2442}), v_p_243, v_p_244));
}
V g_heff_2ebuild_2ecommands_2ewriteParts_24s1069210723x719436499_lam7(V self, V *args) {
  V v_x_2425 = args[0];
  V v_done_241 = heff_env(self)[0];
  V v_p_243 = heff_env(self)[1];
  V v_p_244 = heff_env(self)[2];
  V v_dir_240 = heff_env(self)[3];
  heff_clo_take(self, 4);
  if ((heff_dup(v_x_2425) == NTAG(TAG_True))) {
    heff_drop(v_x_2425);
    heff_drop(v_dir_240);
    V f_ = v_done_241;
    heff_room[0] = v_p_243;
    heff_room[1] = v_p_244;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    heff_drop(v_x_2425);
    heff_drop(v_done_241);
    V v_t_2426 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ewriteParts_24s1069210723x719436499_str0), v_dir_240), ((V)&g_heff_2ebuild_2ecommands_2ewriteParts_24s1069210723x719436499_str1));
    V v_t_2427 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2426, NTAG(TAG_MkUnit)});
    V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
    V v_t_2429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
    V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
    V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
    V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
    V v_t_2433 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2432})});
    V v_t_2434 = heff_tr(heff_call(heff_dup(heff_rfield(v_p_243, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2433})}));
    V f_ = heff_dup(heff_rfield(v_p_243, 1));
    heff_room[0] = v_t_2434;
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ewriteParts_24s1069210723x719436499_lam8, 1, 2, (V[]){v_p_243, v_p_244});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2ebuild_2ecommands_2ewriteParts_24s1069210723x719436499_lam6(V self, V *args) {
  V v_x_2424 = args[0];
  V v_dir_240 = heff_env(self)[0];
  V v_parts_245 = heff_env(self)[1];
  V v_p_243 = heff_env(self)[2];
  V v_done_241 = heff_env(self)[3];
  V v_p_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2424);
  return ({ V a_0 = heff_dup(v_dir_240); V a_1 = v_parts_245; V a_2 = heff_dup(v_p_243); V a_3 = heff_clo_n(g_heff_2ebuild_2ecommands_2ewriteParts_24s1069210723x719436499_lam7, 1, 4, (V[]){v_done_241, v_p_243, v_p_244, v_dir_240}); V r_ = (g_heff_2ebuild_2ecommands_2ewritePartsGo_24s2124042284x1735199047(a_0, a_1, a_2, a_3)); heff_drop(v_parts_245); r_; });
}
V g_heff_2ebuild_2ecommands_2ewriteParts_24s1069210723x719436499_lam11(V self, V *args) {
  V v_x_2455 = args[0];
  V v_p_243 = heff_env(self)[0];
  V v_p_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2455);
  V v_t_2456 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2457 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2456})});
  V v_t_2458 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2457})});
  V v_t_2459 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2458})});
  V v_t_2460 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2459})});
  V v_t_2461 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2460})});
  V v_t_2462 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2461})});
  return (g_co_2eop_24s615738393x1686646143(heff_tag_n(TAG_InR, 1, (V[]){v_t_2462}), v_p_243, v_p_244));
}
V g_heff_2ebuild_2ecommands_2ewriteParts_24s1069210723x719436499_lam10(V self, V *args) {
  V v_x_2445 = args[0];
  V v_done_241 = heff_env(self)[0];
  V v_p_243 = heff_env(self)[1];
  V v_p_244 = heff_env(self)[2];
  V v_dir_240 = heff_env(self)[3];
  heff_clo_take(self, 4);
  if ((heff_dup(v_x_2445) == NTAG(TAG_True))) {
    heff_drop(v_x_2445);
    heff_drop(v_dir_240);
    V f_ = v_done_241;
    heff_room[0] = v_p_243;
    heff_room[1] = v_p_244;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    heff_drop(v_x_2445);
    heff_drop(v_done_241);
    V v_t_2446 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ewriteParts_24s1069210723x719436499_str2), v_dir_240), ((V)&g_heff_2ebuild_2ecommands_2ewriteParts_24s1069210723x719436499_str3));
    V v_t_2447 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2446, NTAG(TAG_MkUnit)});
    V v_t_2448 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2447})});
    V v_t_2449 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2448})});
    V v_t_2450 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2449})});
    V v_t_2451 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2450})});
    V v_t_2452 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2451})});
    V v_t_2453 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2452})});
    V v_t_2454 = heff_tr(heff_call(heff_dup(heff_rfield(v_p_243, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2453})}));
    V f_ = heff_dup(heff_rfield(v_p_243, 1));
    heff_room[0] = v_t_2454;
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ewriteParts_24s1069210723x719436499_lam11, 1, 2, (V[]){v_p_243, v_p_244});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2ebuild_2ecommands_2ewriteParts_24s1069210723x719436499_lam9(V self, V *args) {
  V v_x_2444 = args[0];
  V v_dir_240 = heff_env(self)[0];
  V v_parts_245 = heff_env(self)[1];
  V v_p_243 = heff_env(self)[2];
  V v_done_241 = heff_env(self)[3];
  V v_p_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2444);
  return ({ V a_0 = heff_dup(v_dir_240); V a_1 = v_parts_245; V a_2 = heff_dup(v_p_243); V a_3 = heff_clo_n(g_heff_2ebuild_2ecommands_2ewriteParts_24s1069210723x719436499_lam10, 1, 4, (V[]){v_done_241, v_p_243, v_p_244, v_dir_240}); V r_ = (g_heff_2ebuild_2ecommands_2ewritePartsGo_24s2124042284x1735199047(a_0, a_1, a_2, a_3)); heff_drop(v_parts_245); r_; });
}
V g_heff_2ebuild_2ecommands_2ewriteParts_24s1069210723x719436499_lam5(V self, V *args) {
  V v_x_2422 = args[0];
  V v_dir_240 = heff_env(self)[0];
  V v_parts_245 = heff_env(self)[1];
  V v_p_243 = heff_env(self)[2];
  V v_done_241 = heff_env(self)[3];
  V v_p_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  switch (heff_tag_of(v_x_2422)) {
  case TAG_Left: {
    heff_take_n(v_x_2422, 0ULL, 1);
    return ({ V a_0 = heff_dup(v_dir_240); V a_1 = v_parts_245; V b_2 = NTAG(TAG_Nil); V a_3 = heff_dup(v_p_243); V a_4 = heff_clo_n(g_heff_2ebuild_2ecommands_2ewriteParts_24s1069210723x719436499_lam6, 1, 5, (V[]){v_dir_240, heff_dup(v_parts_245), v_p_243, v_done_241, v_p_244}); V r_ = (g_heff_2ebuild_2ecommands_2eremoveStale_24s1076505188x1773366585(a_0, a_1, b_2, a_3, a_4)); heff_drop(v_parts_245); heff_drop(b_2); r_; });
  }
  case TAG_Right: {
    V v_y_2443 = heff_field(v_x_2422, 0);
    heff_take_n(v_x_2422, 1ULL, 1);
    return ({ V a_0 = heff_dup(v_dir_240); V a_1 = v_parts_245; V a_2 = v_y_2443; V a_3 = heff_dup(v_p_243); V a_4 = heff_clo_n(g_heff_2ebuild_2ecommands_2ewriteParts_24s1069210723x719436499_lam9, 1, 5, (V[]){v_dir_240, heff_dup(v_parts_245), v_p_243, v_done_241, v_p_244}); V r_ = (g_heff_2ebuild_2ecommands_2eremoveStale_24s1076505188x1773366585(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_parts_245); heff_drop(v_y_2443); r_; });
  }
  default: return heff_nomatch(v_x_2422);
  }
}
V g_heff_2ebuild_2ecommands_2ewriteParts_24s1069210723x719436499_lam2(V self, V *args) {
  V v_x_2414 = args[0];
  V v_dir_240 = heff_env(self)[0];
  V v_p_243 = heff_env(self)[1];
  V v_parts_245 = heff_env(self)[2];
  V v_done_241 = heff_env(self)[3];
  V v_p_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2414);
  V v_path_2415 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = heff_dup(v_dir_240); V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
  V v_c_2416 = (g_std_2efilesystem_2ereadDirectory_24s2065195248x940975556(v_path_2415));
  V v_c_2421 = heff_tr(heff_call(v_c_2416, 2, (V[]){heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), ((V)&g_heff_2ebuild_2ecommands_2ewriteParts_24s1069210723x719436499_lam3_clo)}));
  V f_ = v_c_2421;
  heff_room[0] = heff_dup(v_p_243);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ewriteParts_24s1069210723x719436499_lam5, 1, 5, (V[]){v_dir_240, v_parts_245, v_p_243, v_done_241, v_p_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ewriteParts_24s1069210723x719436499_lam0(V self, V *args) {
  V v_x_247 = args[0];
  V v_errors_246 = heff_env(self)[0];
  V v_dir_240 = heff_env(self)[1];
  V v_p_243 = heff_env(self)[2];
  V v_parts_245 = heff_env(self)[3];
  V v_done_241 = heff_env(self)[4];
  V v_p_244 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_247);
  switch (heff_tag_of(v_errors_246)) {
  case TAG_Nil: {
    V v_path_248 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = heff_dup(v_dir_240); V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
    V v_c_249 = ({ V a_0 = v_path_248; V r_ = (g_std_2efilesystem_2emakeDirectory_24s1800594932x1926120429(a_0)); heff_drop(v_path_248); r_; });
    V v_c_2413 = heff_tr(heff_call(v_c_249, 2, (V[]){heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), ((V)&g_heff_2ebuild_2ecommands_2ewriteParts_24s1069210723x719436499_lam1_clo)}));
    V f_ = v_c_2413;
    heff_room[0] = heff_dup(v_p_243);
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ewriteParts_24s1069210723x719436499_lam2, 1, 5, (V[]){v_dir_240, v_p_243, v_parts_245, v_done_241, v_p_244});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_Cons: {
    V v_ru_24errors_246_24Cons = heff_take_reuse_n(v_errors_246, 0ULL, 2);
    heff_drop(v_dir_240);
    heff_drop(v_parts_245);
    heff_drop(v_done_241);
    V v_t_2465 = heff_tag_at_n(v_ru_24errors_246_24Cons, TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
    V v_t_2466 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2465})});
    V v_t_2467 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2466})});
    V v_t_2468 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2467})});
    V v_t_2469 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2468})});
    V v_t_2470 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2469})});
    V v_t_2471 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2470})});
    return (g_co_2eop_24s615738393x1686646143(heff_tag_n(TAG_InR, 1, (V[]){v_t_2471}), v_p_243, v_p_244));
  }
  default: return heff_nomatch(v_errors_246);
  }
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ewriteOutC_24s1877451407x355012956_str0, 2, ".c");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ewriteOutC_24s1877451407x355012956_str1, 4, ".zig");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ewriteOutC_24s1877451407x355012956_str2, 2, ".c");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ewriteOutC_24s1877451407x355012956_str3, 13, "cannot write ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ewriteOutC_24s1877451407x355012956_str4, 4, ".zig");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ewriteOutC_24s1877451407x355012956_str5, 1, "\012");
V g_heff_2ebuild_2ecommands_2ewriteOutC_24s1877451407x355012956_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ewriteOutC_24s1877451407x355012956_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewriteOutC_24s1877451407x355012956_lam0, 3, 0};
V g_heff_2ebuild_2ecommands_2ewriteOutC_24s1877451407x355012956_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ewriteOutC_24s1877451407x355012956_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ewriteOutC_24s1877451407x355012956_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ewriteOutC_24s1877451407x355012956_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewriteOutC_24s1877451407x355012956_entry, 6, 0};

V g_heff_2ebuild_2ecommands_2ewriteOutC_24s1877451407x355012956(V v_outPath_240, V v_zig_241, V v_done_242, V v_o_243, V v_z_244, V v_z_245) {
top: ;
  int64_t v_t_246 = (heff_unbox_word(heff_strLength_lent(v_outPath_240, 0)) - ((int64_t)2ULL));
  V v_t_247 = heff_strSlice(heff_dup(v_outPath_240), heff_box_word(v_t_246), heff_strLength_lent(v_outPath_240, 0));
  V v_t_249;
  if (heff_strEq_c(v_t_247, ((V)&g_heff_2ebuild_2ecommands_2ewriteOutC_24s1877451407x355012956_str0))) {
    int64_t v_t_248 = (heff_unbox_word(heff_strLength_lent(v_outPath_240, 0)) - ((int64_t)2ULL));
    v_t_249 = heff_strSlice_lent(v_outPath_240, MK_INT(0LL), heff_box_word(v_t_248), 6);
  } else {
    v_t_249 = heff_dup(v_outPath_240);
  }
  V v_path_2410 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = heff_strAppend(v_t_249, ((V)&g_heff_2ebuild_2ecommands_2ewriteOutC_24s1877451407x355012956_str1)); V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
  V v_c_2411 = ({ V a_0 = v_path_2410; V a_1 = v_zig_241; V r_ = (g_std_2efilesystem_2ewriteFile_24s1441161512x485333423(a_0, a_1)); heff_drop(v_path_2410); r_; });
  V v_c_2415 = heff_tr(heff_call(v_c_2411, 2, (V[]){heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), ((V)&g_heff_2ebuild_2ecommands_2ewriteOutC_24s1877451407x355012956_lam0_clo)}));
  return (g_heff_2ebuild_2ecommands_2ewriteOut_24s1442511881x314947241(heff_dup(v_outPath_240), heff_clo_n(g_heff_2ebuild_2ecommands_2ewriteOutC_24s1877451407x355012956_lam1, 2, 3, (V[]){v_c_2415, v_outPath_240, v_done_242}), v_o_243, v_z_244, v_z_245));
}
V g_heff_2ebuild_2ecommands_2ewriteOutC_24s1877451407x355012956_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ewriteOutC_24s1877451407x355012956(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2ebuild_2ecommands_2ewriteOutC_24s1877451407x355012956_lam0(V self, V *args) {
  V v_x_2412 = args[0];
  V v_hd_2413 = args[1];
  V v_k_2414 = args[2];
  heff_drop(v_hd_2413);
  V f_ = v_k_2414;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2412});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ewriteOutC_24s1877451407x355012956_lam3(V self, V *args) {
  V v_x_2433 = args[0];
  V v_hd_2416 = heff_env(self)[0];
  V v_k_2417 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2433);
  V v_t_2434 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2435 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2434})});
  V v_t_2436 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2435})});
  V v_t_2437 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2436})});
  V v_t_2438 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2437})});
  V v_t_2439 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2438})});
  V v_t_2440 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2439})});
  return (g_co_2eop_24s615738393x1686646143(heff_tag_n(TAG_InR, 1, (V[]){v_t_2440}), v_hd_2416, v_k_2417));
}
V g_heff_2ebuild_2ecommands_2ewriteOutC_24s1877451407x355012956_lam2(V self, V *args) {
  V v_x_2418 = args[0];
  V v_outPath_240 = heff_env(self)[0];
  V v_hd_2416 = heff_env(self)[1];
  V v_k_2417 = heff_env(self)[2];
  V v_done_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  switch (heff_tag_of(v_x_2418)) {
  case TAG_Left: {
    V v_ru_24x_2418_24Left = heff_take_reuse_n(v_x_2418, 0ULL, 1);
    heff_drop(v_done_242);
    int64_t v_t_2420 = (heff_unbox_word(heff_strLength_lent(v_outPath_240, 0)) - ((int64_t)2ULL));
    V v_t_2421 = heff_strSlice(heff_dup(v_outPath_240), heff_box_word(v_t_2420), heff_strLength_lent(v_outPath_240, 0));
    V v_t_2423;
    if (heff_strEq_c(v_t_2421, ((V)&g_heff_2ebuild_2ecommands_2ewriteOutC_24s1877451407x355012956_str2))) {
      int64_t v_t_2422 = (heff_unbox_word(heff_strLength_lent(v_outPath_240, 0)) - ((int64_t)2ULL));
      v_t_2423 = heff_strSlice(v_outPath_240, MK_INT(0LL), heff_box_word(v_t_2422));
    } else {
      v_t_2423 = v_outPath_240;
    }
    V v_t_2424 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ewriteOutC_24s1877451407x355012956_str3), heff_strAppend(v_t_2423, ((V)&g_heff_2ebuild_2ecommands_2ewriteOutC_24s1877451407x355012956_str4)));
    V v_t_2425 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_t_2424, ((V)&g_heff_2ebuild_2ecommands_2ewriteOutC_24s1877451407x355012956_str5)), NTAG(TAG_MkUnit)});
    V v_t_2426 = heff_tag_at_n(v_ru_24x_2418_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
    V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
    V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
    V v_t_2429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
    V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
    V v_t_2431 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2430})});
    V v_t_2432 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_2416, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2431})}));
    V f_ = heff_dup(heff_rfield(v_hd_2416, 1));
    heff_room[0] = v_t_2432;
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ewriteOutC_24s1877451407x355012956_lam3, 1, 2, (V[]){v_hd_2416, v_k_2417});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_Right: {
    heff_take_n(v_x_2418, 0ULL, 1);
    heff_drop(v_outPath_240);
    V f_ = v_done_242;
    heff_room[0] = v_hd_2416;
    heff_room[1] = v_k_2417;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_x_2418);
  }
}
V g_heff_2ebuild_2ecommands_2ewriteOutC_24s1877451407x355012956_lam1(V self, V *args) {
  V v_hd_2416 = args[0];
  V v_k_2417 = args[1];
  V v_c_2415 = heff_env(self)[0];
  V v_outPath_240 = heff_env(self)[1];
  V v_done_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_2415;
  args[0] = heff_dup(v_hd_2416);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ewriteOutC_24s1877451407x355012956_lam2, 1, 4, (V[]){v_outPath_240, v_hd_2416, v_k_2417, v_done_242});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2egoldenSaid_24s1045388766x363711794_str0, 1, "/");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egoldenSaid_24s1045388766x363711794_str1, 1, "/");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egoldenSaid_24s1045388766x363711794_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egoldenSaid_24s1045388766x363711794_str3, 1, "\"");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egoldenSaid_24s1045388766x363711794_str4, 1, "\"");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egoldenSaid_24s1045388766x363711794_str5, 7, "golden ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egoldenSaid_24s1045388766x363711794_str6, 112, "a golden text's name is a file's under the directory: letters, digits, `-`, `_` and `.`, not first, between `/`s");
HEFF_LIT(g_heff_2ebuild_2ecommands_2egoldenSaid_24s1045388766x363711794_str7, 5, "win32");
V g_heff_2ebuild_2ecommands_2egoldenSaid_24s1045388766x363711794_lam0(V self, V *args);
V g_heff_2ebuild_2ecommands_2egoldenSaid_24s1045388766x363711794_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2egoldenSaid_24s1045388766x363711794_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2egoldenSaid_24s1045388766x363711794_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2egoldenSaid_24s1045388766x363711794_lam4(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2egoldenSaid_24s1045388766x363711794_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2egoldenSaid_24s1045388766x363711794_lam4, 3, 0};
V g_heff_2ebuild_2ecommands_2egoldenSaid_24s1045388766x363711794_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2egoldenSaid_24s1045388766x363711794_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2egoldenSaid_24s1045388766x363711794_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2egoldenSaid_24s1045388766x363711794_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2egoldenSaid_24s1045388766x363711794_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2egoldenSaid_24s1045388766x363711794(V v_update_240, V v_f_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_MkPair: {
    V v_name_243 = heff_field(v_x3_242, 0);
    V v_text_244 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24MkPair = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    V v_t_245 = ({ V b_0 = ((V)&g_heff_2ebuild_2ecommands_2egoldenSaid_24s1045388766x363711794_str0); V a_1 = v_name_243; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2ecommands_2egoldenSaid_24s1045388766x363711794_str1), v_name_243, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); r_; });
    V v_x1_246 = ({ V a_0 = v_t_245; V r_ = (g_list_2eall_24s523006110x1088755562(a_0)); heff_drop(v_t_245); r_; });
    if (!(heff_dup(v_x1_246) == NTAG(TAG_True))) {
      heff_drop(v_f_241);
      heff_drop(v_text_244);
      heff_drop(v_x1_246);
      V v_t_247 = ({ V a_0 = v_name_243; V a_1 = MK_INT(0LL); V a_2 = ((V)&g_heff_2ebuild_2ecommands_2egoldenSaid_24s1045388766x363711794_str2); V r_ = (g_prelude_2einstanceShowString_2eescapedFrom_241(a_0, a_1, a_2)); heff_drop(v_name_243); r_; });
      V v_t_248 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2egoldenSaid_24s1045388766x363711794_str3), heff_strAppend(v_t_247, ((V)&g_heff_2ebuild_2ecommands_2egoldenSaid_24s1045388766x363711794_str4)));
      V v_x_249 = heff_tag_at_n(v_ru_24x3_242_24MkPair, TAG_Wrong, 2, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2egoldenSaid_24s1045388766x363711794_str5), v_t_248), heff_tag_n(TAG_FailBecause, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2egoldenSaid_24s1045388766x363711794_str6)})});
      return heff_clo_n(g_heff_2ebuild_2ecommands_2egoldenSaid_24s1045388766x363711794_lam0, 2, 1, (V[]){v_x_249});
    } else {
      heff_drop_cell(v_ru_24x3_242_24MkPair, 2);
      heff_drop(v_x1_246);
      return heff_clo_n(g_heff_2ebuild_2ecommands_2egoldenSaid_24s1045388766x363711794_lam1, 2, 4, (V[]){v_f_241, v_name_243, heff_dup(v_update_240), v_text_244});
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2ecommands_2egoldenSaid_24s1045388766x363711794_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2egoldenSaid_24s1045388766x363711794(a0, a[1], a[2]); heff_drop(a0); return r;
}
V g_heff_2ebuild_2ecommands_2egoldenSaid_24s1045388766x363711794_lam0(V self, V *args) {
  V v_hd_2410 = args[0];
  V v_k_2411 = args[1];
  V v_x_249 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2410);
  V f_ = v_k_2411;
  args[0] = v_x_249;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2egoldenSaid_24s1045388766x363711794_lam2(V self, V *args) {
  V v_s_2414 = args[0];
  return v_s_2414;
}
V g_heff_2ebuild_2ecommands_2egoldenSaid_24s1045388766x363711794_lam4(V self, V *args) {
  V v_x_2428 = args[0];
  V v_hd_2429 = args[1];
  V v_k_2430 = args[2];
  heff_drop(v_hd_2429);
  V f_ = v_k_2430;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2428});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2egoldenSaid_24s1045388766x363711794_lam5(V self, V *args) {
  V v_x_2432 = args[0];
  V v_st_2424 = heff_env(self)[0];
  V v_f_241 = heff_env(self)[1];
  V v_name_243 = heff_env(self)[2];
  V v_update_240 = heff_env(self)[3];
  V v_text_244 = heff_env(self)[4];
  V v_hd_2412 = heff_env(self)[5];
  V v_k_2413 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_s_2433 = (g_heff_2ebuild_2ecommands_2egoldenPath(v_st_2424, heff_dup(v_f_241), heff_dup(v_name_243)));
  HeffT3 v_t_2434 = (g_std_2epath_2eparse_24cpr(v_st_2424, v_s_2433));
  V v_t_2444;
  {
    V v_field_2435 = v_t_2434.f[0];
    V v_field_2436 = v_t_2434.f[1];
    V v_field_2437 = v_t_2434.f[2];
    V v_d_2438 = v_field_2435;
    V v_a_2439 = v_field_2436;
    V v_xs_2440 = v_field_2437;
    V v_t_2441 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2440));
    V v_xs_2442 = ({ V a_0 = MK_INT(1LL); V a_1 = v_t_2441; V r_ = (g_list_2edrop(a_0, a_1)); heff_drop(v_t_2441); r_; });
    V v_t_2443 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2442));
    v_t_2444 = heff_tag_n(TAG_MkPath, 3, (V[]){v_d_2438, v_a_2439, v_t_2443});
  }
  V v_t_2445 = ({ V a_0 = v_st_2424; V a_1 = v_t_2444; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2444); r_; });
  V v_t_2446 = ({ V a_0 = v_st_2424; V a_1 = v_f_241; V a_2 = v_name_243; V r_ = (g_heff_2ebuild_2ecommands_2egoldenPath(a_0, a_1, a_2)); heff_drop(v_st_2424); r_; });
  V v_t_2449;
  switch (heff_tag_of(v_x_2432)) {
  case TAG_Left: {
    heff_take_n(v_x_2432, 0ULL, 1);
    v_t_2449 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Right: {
    V v_y_2448 = heff_field(v_x_2432, 0);
    V v_ru_24x_2432_24Right = heff_take_reuse_n(v_x_2432, 1ULL, 1);
    v_t_2449 = heff_tag_at_n(v_ru_24x_2432_24Right, TAG_Just, 1, (V[]){v_y_2448});
    break;
  }
  default: heff_nomatch(v_x_2432);
  }
  return ({ V a_0 = v_update_240; V a_1 = v_t_2445; V a_2 = v_t_2446; V a_3 = v_text_244; V a_4 = v_t_2449; V a_5 = v_hd_2412; V a_6 = v_k_2413; V r_ = (g_heff_2ebuild_2ecommands_2egoldenAgainst_24s992520432x896454450(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_update_240); r_; });
}
V g_heff_2ebuild_2ecommands_2egoldenSaid_24s1045388766x363711794_lam3(V self, V *args) {
  V v_x_2423 = args[0];
  V v_f_241 = heff_env(self)[0];
  V v_name_243 = heff_env(self)[1];
  V v_hd_2412 = heff_env(self)[2];
  V v_update_240 = heff_env(self)[3];
  V v_text_244 = heff_env(self)[4];
  V v_k_2413 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_st_2424;
  if (heff_strEq_c(v_x_2423, ((V)&g_heff_2ebuild_2ecommands_2egoldenSaid_24s1045388766x363711794_str7))) {
    v_st_2424 = NTAG(TAG_Windows);
  } else {
    v_st_2424 = NTAG(TAG_Posix);
  }
  V v_s_2425 = (g_heff_2ebuild_2ecommands_2egoldenPath(v_st_2424, heff_dup(v_f_241), heff_dup(v_name_243)));
  V v_path_2426 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_s_2425; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
  V v_c_2427 = ({ V a_0 = v_path_2426; V r_ = (g_std_2efilesystem_2ereadFile_24s2092922012x215966209(a_0)); heff_drop(v_path_2426); r_; });
  V v_c_2431 = heff_tr(heff_call(v_c_2427, 2, (V[]){heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), ((V)&g_heff_2ebuild_2ecommands_2egoldenSaid_24s1045388766x363711794_lam4_clo)}));
  V f_ = v_c_2431;
  heff_room[0] = heff_dup(v_hd_2412);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2egoldenSaid_24s1045388766x363711794_lam5, 1, 7, (V[]){v_st_2424, v_f_241, v_name_243, v_update_240, v_text_244, v_hd_2412, v_k_2413});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2egoldenSaid_24s1045388766x363711794_lam1(V self, V *args) {
  V v_hd_2412 = args[0];
  V v_k_2413 = args[1];
  V v_f_241 = heff_env(self)[0];
  V v_name_243 = heff_env(self)[1];
  V v_update_240 = heff_env(self)[2];
  V v_text_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2415 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2egoldenSaid_24s1045388766x363711794_lam2_clo)})});
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
  V v_t_2421 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2420})});
  V v_t_2422 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_2412, 2)), 1, (V[]){v_t_2421}));
  V f_ = heff_dup(heff_rfield(v_hd_2412, 1));
  args[0] = v_t_2422;
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2egoldenSaid_24s1045388766x363711794_lam3, 1, 6, (V[]){v_f_241, v_name_243, v_hd_2412, v_update_240, v_text_244, v_k_2413});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2ecommands_2ewithGoldens_24s1327649047x255568769_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ewithGoldens_24s1327649047x255568769_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewithGoldens_24s1327649047x255568769_lam0, 2, 0};
V g_heff_2ebuild_2ecommands_2ewithGoldens_24s1327649047x255568769_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2ewithGoldens_24s1327649047x255568769_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2ewithGoldens_24s1327649047x255568769_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ewithGoldens_24s1327649047x255568769_lam2(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ewithGoldens_24s1327649047x255568769_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewithGoldens_24s1327649047x255568769_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2ewithGoldens_24s1327649047x255568769(V v_update_240, V v_f_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_f_241);
    return ((V)&g_heff_2ebuild_2ecommands_2ewithGoldens_24s1327649047x255568769_lam0_clo);
  }
  case TAG_Cons: {
    V v_o_245 = heff_field(v_x3_242, 0);
    V v_rest_246 = heff_field(v_x3_242, 1);
    heff_take_n(v_x3_242, 3ULL, 2);
    V v_t_247 = heff_dup(heff_rfield(v_o_245, 1));
    V v_c_2410;
    if ((heff_dup(v_t_247) == NTAG(TAG_True))) {
      heff_drop(v_t_247);
      v_c_2410 = (g_heff_2ebuild_2ecommands_2egoldensGo_24s1881795521x39532647(v_update_240, heff_dup(v_f_241), heff_dup(v_o_245), heff_get_n(v_o_245, 11, 12)));
    } else {
      heff_drop(v_t_247);
      v_c_2410 = heff_clo_n(g_heff_2ebuild_2ecommands_2ewithGoldens_24s1327649047x255568769_lam1, 2, 1, (V[]){v_o_245});
    }
    return heff_clo_n(g_heff_2ebuild_2ecommands_2ewithGoldens_24s1327649047x255568769_lam2, 2, 4, (V[]){v_c_2410, heff_dup(v_update_240), v_f_241, v_rest_246});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2ecommands_2ewithGoldens_24s1327649047x255568769_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2ewithGoldens_24s1327649047x255568769(a0, a[1], a[2]); heff_drop(a0); return r;
}
V g_heff_2ebuild_2ecommands_2ewithGoldens_24s1327649047x255568769_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  heff_drop(v_hd_243);
  V f_ = v_k_244;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ewithGoldens_24s1327649047x255568769_lam1(V self, V *args) {
  V v_hd_248 = args[0];
  V v_k_249 = args[1];
  V v_o_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_248);
  V f_ = v_k_249;
  args[0] = v_o_245;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ewithGoldens_24s1327649047x255568769_lam4(V self, V *args) {
  V v_x_2415 = args[0];
  V v_k_2412 = heff_env(self)[0];
  V v_x_2413 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_2412;
  args[0] = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2413, v_x_2415});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ewithGoldens_24s1327649047x255568769_lam3(V self, V *args) {
  V v_x_2413 = args[0];
  V v_update_240 = heff_env(self)[0];
  V v_f_241 = heff_env(self)[1];
  V v_rest_246 = heff_env(self)[2];
  V v_hd_2411 = heff_env(self)[3];
  V v_k_2412 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_c_2414 = ({ V a_0 = v_update_240; V a_1 = v_f_241; V a_2 = v_rest_246; V r_ = (g_heff_2ebuild_2ecommands_2ewithGoldens_24s1327649047x255568769(a_0, a_1, a_2)); heff_drop(v_update_240); r_; });
  V f_ = v_c_2414;
  heff_room[0] = v_hd_2411;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ewithGoldens_24s1327649047x255568769_lam4, 1, 2, (V[]){v_k_2412, v_x_2413});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ewithGoldens_24s1327649047x255568769_lam2(V self, V *args) {
  V v_hd_2411 = args[0];
  V v_k_2412 = args[1];
  V v_c_2410 = heff_env(self)[0];
  V v_update_240 = heff_env(self)[1];
  V v_f_241 = heff_env(self)[2];
  V v_rest_246 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_2410;
  args[0] = heff_dup(v_hd_2411);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ewithGoldens_24s1327649047x255568769_lam3, 1, 5, (V[]){v_update_240, v_f_241, v_rest_246, v_hd_2411, v_k_2412});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprintFails_24s1263841563x776765553_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprintFails_24s1263841563x776765553_str1, 1, "\012");
V g_heff_2ebuild_2ecommands_2eprintFails_24s1263841563x776765553_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eprintFails_24s1263841563x776765553_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eprintFails_24s1263841563x776765553_lam0, 2, 0};
V g_heff_2ebuild_2ecommands_2eprintFails_24s1263841563x776765553_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eprintFails_24s1263841563x776765553_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eprintFails_24s1263841563x776765553_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2eprintFails_24s1263841563x776765553(V v_f_240, V v_color_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_f_240);
    return ((V)&g_heff_2ebuild_2ecommands_2eprintFails_24s1263841563x776765553_lam0_clo);
  }
  case TAG_Cons: {
    V v_r_245 = heff_field(v_x3_242, 0);
    V v_rest_246 = heff_field(v_x3_242, 1);
    heff_take_n(v_x3_242, 3ULL, 2);
    V v_t_247 = heff_get_n(heff_dup(heff_rfield(v_r_245, 2)), 5, 10);
    V v_t_249;
    switch (heff_tag_of(v_t_247)) {
    case TAG_Nothing: {
      v_t_249 = ((V)&g_heff_2ebuild_2ecommands_2eprintFails_24s1263841563x776765553_str0);
      break;
    }
    case TAG_Just: {
      V v_x_248 = heff_field(v_t_247, 0);
      heff_take_n(v_t_247, 1ULL, 1);
      v_t_249 = v_x_248;
      break;
    }
    default: heff_nomatch(v_t_247);
    }
    V v_t_2410 = heff_get_n(heff_dup(heff_rfield(v_r_245, 2)), 4, 10);
    V v_t_2411 = ({ V a_0 = v_color_241; V a_1 = v_t_249; V a_2 = v_t_2410; V r_ = (g_heff_2elsp_2ereport_2emismatch(a_0, a_1, a_2)); heff_drop(v_t_249); heff_drop(v_t_2410); r_; });
    V v_str_2412 = (g_heff_2ebuild_2ecommands_2efailLine(heff_dup(v_f_240), v_r_245, v_t_2411));
    return heff_clo_n(g_heff_2ebuild_2ecommands_2eprintFails_24s1263841563x776765553_lam1, 2, 4, (V[]){v_str_2412, v_f_240, heff_dup(v_color_241), v_rest_246});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2ecommands_2eprintFails_24s1263841563x776765553_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2ecommands_2eprintFails_24s1263841563x776765553(a[0], a1, a[2]); heff_drop(a1); return r;
}
V g_heff_2ebuild_2ecommands_2eprintFails_24s1263841563x776765553_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  heff_drop(v_hd_243);
  V f_ = v_k_244;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eprintFails_24s1263841563x776765553_lam1(V self, V *args) {
  V v_hd_2413 = args[0];
  V v_k_2414 = args[1];
  V v_str_2412 = heff_env(self)[0];
  V v_f_240 = heff_env(self)[1];
  V v_color_241 = heff_env(self)[2];
  V v_rest_246 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2415 = heff_tag_n(TAG_Write, 2, (V[]){heff_strAppend(v_str_2412, ((V)&g_heff_2ebuild_2ecommands_2eprintFails_24s1263841563x776765553_str1)), NTAG(TAG_MkUnit)});
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
  V v_t_2421 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2420})});
  return ({ V a_0 = v_f_240; V a_1 = v_color_241; V a_2 = v_rest_246; V a_3 = heff_dup(v_hd_2413); V a_4 = v_k_2414; V a_5 = heff_tag_n(TAG_InR, 1, (V[]){v_t_2421}); V a_6 = v_hd_2413; V r_ = (g_co_2eop_24s710864882x261522381(a_0, a_1, a_2, a_3, a_4, a_5, a_6)); heff_drop(v_color_241); r_; });
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ediagCount_24s823746706x1248851912_str0, 2, ": ");
V g_heff_2ebuild_2ecommands_2ediagCount_24s823746706x1248851912_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ediagCount_24s823746706x1248851912_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ediagCount_24s823746706x1248851912_lam0, 2, 0};
V g_heff_2ebuild_2ecommands_2ediagCount_24s823746706x1248851912_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ediagCount_24s823746706x1248851912_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ediagCount_24s823746706x1248851912_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ediagCount_24s823746706x1248851912_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ediagCount_24s823746706x1248851912_entry, 1, 0};

V g_heff_2ebuild_2ecommands_2ediagCount_24s823746706x1248851912(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return ((V)&g_heff_2ebuild_2ecommands_2ediagCount_24s823746706x1248851912_lam0_clo);
  }
  case TAG_Cons: {
    V v_c_243 = heff_field(v_x1_240, 0);
    V v_rest_244 = heff_field(v_x1_240, 1);
    V v_diags_245 = heff_dup(heff_rfield(v_c_243, 6));
    V v_module_246 = heff_dup(heff_rfield(v_c_243, 0));
    V v_t_247 = (g_list_2emap_24s370939663x1496042695(((V)&g_heff_2ebuild_2ecommands_2ediagCount_24s823746706x1248851912_str0), heff_dup(v_diags_245)));
    return heff_clo_n(g_heff_2ebuild_2ecommands_2ediagCount_24s823746706x1248851912_lam1, 2, 4, (V[]){v_module_246, v_t_247, heff_dup(v_rest_244), v_diags_245});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2ecommands_2ediagCount_24s823746706x1248851912_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2ediagCount_24s823746706x1248851912(a0); heff_drop(a0); return r;
}
V g_heff_2ebuild_2ecommands_2ediagCount_24s823746706x1248851912_lam0(V self, V *args) {
  V v_hd_241 = args[0];
  V v_k_242 = args[1];
  heff_drop(v_hd_241);
  V f_ = v_k_242;
  args[0] = MK_INT(0LL);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ediagCount_24s823746706x1248851912_lam3(V self, V *args) {
  V v_x_2412 = args[0];
  V v_diags_245 = heff_env(self)[0];
  V v_k_249 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2413 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_diags_245; V r_ = (g_list_2efoldl_24f2094160282x1876485468(a_0, a_1, a_2)); heff_drop(v_diags_245); r_; });
  V v_x_2414 = heff_intAdd(v_t_2413, v_x_2412);
  V f_ = v_k_249;
  args[0] = v_x_2414;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ediagCount_24s823746706x1248851912_lam2(V self, V *args) {
  V v_x_2410 = args[0];
  V v_rest_244 = heff_env(self)[0];
  V v_hd_248 = heff_env(self)[1];
  V v_diags_245 = heff_env(self)[2];
  V v_k_249 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2410);
  V v_c_2411 = ({ V a_0 = v_rest_244; V r_ = (g_heff_2ebuild_2ecommands_2ediagCount_24s823746706x1248851912(a_0)); heff_drop(v_rest_244); r_; });
  V f_ = v_c_2411;
  heff_room[0] = v_hd_248;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ediagCount_24s823746706x1248851912_lam3, 1, 2, (V[]){v_diags_245, v_k_249});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ediagCount_24s823746706x1248851912_lam1(V self, V *args) {
  V v_hd_248 = args[0];
  V v_k_249 = args[1];
  V v_module_246 = heff_env(self)[0];
  V v_t_247 = heff_env(self)[1];
  V v_rest_244 = heff_env(self)[2];
  V v_diags_245 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2ebuild_2ecommands_2eprintErrs_24s115117455x797094904(v_module_246, v_t_247, MK_INT(0LL), heff_dup(v_hd_248), heff_clo_n(g_heff_2ebuild_2ecommands_2ediagCount_24s823746706x1248851912_lam2, 1, 4, (V[]){v_rest_244, v_hd_248, v_diags_245, v_k_249})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2edocPagesWritten_24s186486549x585078911_str0, 5, "win32");
HEFF_LIT(g_heff_2ebuild_2ecommands_2edocPagesWritten_24s186486549x585078911_str1, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2edocPagesWritten_24s186486549x585078911_str2, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2edocPagesWritten_24s186486549x585078911_str3, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2edocPagesWritten_24s186486549x585078911_str4, 1, "/");
HEFF_LIT(g_heff_2ebuild_2ecommands_2edocPagesWritten_24s186486549x585078911_str5, 3, ".md");
V g_heff_2ebuild_2ecommands_2edocPagesWritten_24s186486549x585078911_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2edocPagesWritten_24s186486549x585078911_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2edocPagesWritten_24s186486549x585078911_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2edocPagesWritten_24s186486549x585078911_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2edocPagesWritten_24s186486549x585078911_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2edocPagesWritten_24s186486549x585078911_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2edocPagesWritten_24s186486549x585078911_entry, 6, 0};

V g_heff_2ebuild_2ecommands_2edocPagesWritten_24s186486549x585078911(V v_prog_240, V v_w_241, V v_dir_242, V v_x3_243, V v_p_244, V v_p_245) {
top: ;
  switch (heff_tag_of(v_x3_243)) {
  case TAG_Nil: {
    heff_drop(v_prog_240);
    heff_drop(v_w_241);
    heff_drop(v_dir_242);
    heff_drop_rec(v_p_244, 3);
    return heff_tail(v_p_245, 1, (V[]){NTAG(TAG_MkUnit)});
  }
  case TAG_Cons: {
    V v_c_246 = heff_field(v_x3_243, 0);
    V v_rest_247 = heff_field(v_x3_243, 1);
    heff_take_n(v_x3_243, 3ULL, 2);
    V v_t_249 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2edocPagesWritten_24s186486549x585078911_lam0_clo)})});
    V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
    V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
    V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
    V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
    V v_t_2414 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
    V v_t_2415 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2414})});
    V v_t_2416 = heff_tr(heff_call(heff_dup(heff_rfield(v_p_244, 2)), 1, (V[]){v_t_2415}));
    return heff_tail(heff_dup(heff_rfield(v_p_244, 1)), 2, (V[]){v_t_2416, heff_clo_n(g_heff_2ebuild_2ecommands_2edocPagesWritten_24s186486549x585078911_lam1, 1, 7, (V[]){v_c_246, v_dir_242, v_p_244, v_w_241, v_prog_240, v_rest_247, v_p_245})});
  }
  default: return heff_nomatch(v_x3_243);
  }
}
V g_heff_2ebuild_2ecommands_2edocPagesWritten_24s186486549x585078911_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2edocPagesWritten_24s186486549x585078911(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2ebuild_2ecommands_2edocPagesWritten_24s186486549x585078911_lam0(V self, V *args) {
  V v_s_248 = args[0];
  return v_s_248;
}
V g_heff_2ebuild_2ecommands_2edocPagesWritten_24s186486549x585078911_lam2(V self, V *args) {
  V v_x_2430 = args[0];
  V v_w_241 = heff_env(self)[0];
  V v_prog_240 = heff_env(self)[1];
  V v_dir_242 = heff_env(self)[2];
  V v_rest_247 = heff_env(self)[3];
  V v_p_244 = heff_env(self)[4];
  V v_p_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_2430);
  V v_t_2431 = heff_tag_n(TAG_Complete, 2, (V[]){heff_dup(v_w_241), NTAG(TAG_MkUnit)});
  V v_t_2432 = heff_tr(heff_call(heff_dup(v_prog_240), 1, (V[]){v_t_2431}));
  return (g_co_2eop_24s1204515794x2100690815(v_prog_240, v_w_241, v_dir_242, v_rest_247, heff_dup(v_p_244), v_p_245, v_t_2432, v_p_244));
}
V g_heff_2ebuild_2ecommands_2edocPagesWritten_24s186486549x585078911_lam1(V self, V *args) {
  V v_x_2417 = args[0];
  V v_c_246 = heff_env(self)[0];
  V v_dir_242 = heff_env(self)[1];
  V v_p_244 = heff_env(self)[2];
  V v_w_241 = heff_env(self)[3];
  V v_prog_240 = heff_env(self)[4];
  V v_rest_247 = heff_env(self)[5];
  V v_p_245 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_st_2418;
  if (heff_strEq_c(v_x_2417, ((V)&g_heff_2ebuild_2ecommands_2edocPagesWritten_24s186486549x585078911_str0))) {
    v_st_2418 = NTAG(TAG_Windows);
  } else {
    v_st_2418 = NTAG(TAG_Posix);
  }
  V v_m_2419 = heff_dup(heff_rfield(v_c_246, 0));
  V v_x2_2420 = ({ V b_0 = ((V)&g_heff_2ebuild_2ecommands_2edocPagesWritten_24s186486549x585078911_str1); V a_1 = v_m_2419; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2ecommands_2edocPagesWritten_24s186486549x585078911_str2), v_m_2419, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); heff_drop(v_m_2419); r_; });
  V v_t_2423;
  switch (heff_tag_of(v_x2_2420)) {
  case TAG_Nil: {
    v_t_2423 = ((V)&g_heff_2ebuild_2ecommands_2edocPagesWritten_24s186486549x585078911_str3);
    break;
  }
  case TAG_Cons: {
    V v_x_2421 = heff_field(v_x2_2420, 0);
    V v_xs_2422 = heff_field(v_x2_2420, 1);
    heff_take_n(v_x2_2420, 3ULL, 2);
    v_t_2423 = ({ V a_0 = ((V)&g_heff_2ebuild_2ecommands_2edocPagesWritten_24s186486549x585078911_str4); V a_1 = v_x_2421; V a_2 = v_xs_2422; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2422); r_; });
    break;
  }
  default: heff_nomatch(v_x2_2420);
  }
  V v_b_2424 = heff_strAppend(v_t_2423, ((V)&g_heff_2ebuild_2ecommands_2edocPagesWritten_24s186486549x585078911_str5));
  V v_t_2425 = (g_std_2epath_2eparse(v_st_2418, heff_dup(v_dir_242)));
  V v_t_2426 = (g_std_2epath_2eparse(v_st_2418, v_b_2424));
  V v_t_2427 = (g_std_2epath_2ejoin(v_t_2425, v_t_2426));
  V v_t_2428 = ({ V a_0 = v_st_2418; V a_1 = v_t_2427; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2418); heff_drop(v_t_2427); r_; });
  V v_t_2429 = (g_heff_2ebuild_2edocpages_2epage(v_c_246));
  return (g_heff_2ebuild_2ecommands_2edocPageWritten_24s1466416307x1099964288(v_t_2428, v_t_2429, heff_dup(v_p_244), heff_clo_n(g_heff_2ebuild_2ecommands_2edocPagesWritten_24s186486549x585078911_lam2, 1, 6, (V[]){v_w_241, v_prog_240, v_dir_242, v_rest_247, v_p_244, v_p_245})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eexisting_24s783863025x1958439471_str0, 5, "win32");
V g_heff_2ebuild_2ecommands_2eexisting_24s783863025x1958439471_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eexisting_24s783863025x1958439471_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eexisting_24s783863025x1958439471_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2eexisting_24s783863025x1958439471_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eexisting_24s783863025x1958439471_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eexisting_24s783863025x1958439471_lam2, 3, 0};
V g_heff_2ebuild_2ecommands_2eexisting_24s783863025x1958439471_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2eexisting_24s783863025x1958439471_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2eexisting_24s783863025x1958439471_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eexisting_24s783863025x1958439471_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eexisting_24s783863025x1958439471_entry, 4, 0};

V g_heff_2ebuild_2ecommands_2eexisting_24s783863025x1958439471(V v_dir_240, V v_x2_241, V v_p_242, V v_p_243) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_dir_240);
    heff_drop_rec(v_p_242, 3);
    return heff_tail(v_p_243, 1, (V[]){NTAG(TAG_Nil)});
  }
  case TAG_Cons: {
    V v_x21_244 = heff_field(v_x2_241, 0);
    V v_rest_245 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_244)) {
    case TAG_MkPair: {
      V v_f_246 = heff_field(v_x21_244, 0);
      heff_take_n(v_x21_244, 1ULL, 2);
      V v_t_249 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2eexisting_24s783863025x1958439471_lam0_clo)})});
      V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
      V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
      V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
      V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
      V v_t_2414 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
      V v_t_2415 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2414})});
      V v_t_2416 = heff_tr(heff_call(heff_dup(heff_rfield(v_p_242, 2)), 1, (V[]){v_t_2415}));
      return heff_tail(heff_dup(heff_rfield(v_p_242, 1)), 2, (V[]){v_t_2416, heff_clo_n(g_heff_2ebuild_2ecommands_2eexisting_24s783863025x1958439471_lam1, 1, 5, (V[]){v_dir_240, v_f_246, v_p_242, v_rest_245, v_p_243})});
    }
    default: return heff_nomatch(v_x21_244);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2ecommands_2eexisting_24s783863025x1958439471_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eexisting_24s783863025x1958439471(a[0], a[1], a[2], a[3]);
}
V g_heff_2ebuild_2ecommands_2eexisting_24s783863025x1958439471_lam0(V self, V *args) {
  V v_s_248 = args[0];
  return v_s_248;
}
V g_heff_2ebuild_2ecommands_2eexisting_24s783863025x1958439471_lam2(V self, V *args) {
  V v_x_2425 = args[0];
  V v_hd_2426 = args[1];
  V v_k_2427 = args[2];
  heff_drop(v_hd_2426);
  V f_ = v_k_2427;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2425});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eexisting_24s783863025x1958439471_lam4(V self, V *args) {
  V v_x_2432 = args[0];
  V v_p_243 = heff_env(self)[0];
  V v_f_246 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_p_243;
  args[0] = heff_tag_n(TAG_Cons, 2, (V[]){v_f_246, v_x_2432});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eexisting_24s783863025x1958439471_lam3(V self, V *args) {
  V v_x_2429 = args[0];
  V v_dir_240 = heff_env(self)[0];
  V v_rest_245 = heff_env(self)[1];
  V v_p_242 = heff_env(self)[2];
  V v_p_243 = heff_env(self)[3];
  V v_f_246 = heff_env(self)[4];
  heff_clo_take(self, 5);
  switch (heff_tag_of(v_x_2429)) {
  case TAG_Left: {
    heff_take_n(v_x_2429, 0ULL, 1);
    heff_drop(v_f_246);
    return (g_heff_2ebuild_2ecommands_2eexisting_24s783863025x1958439471(v_dir_240, v_rest_245, v_p_242, v_p_243));
  }
  case TAG_Right: {
    heff_take_n(v_x_2429, 0ULL, 1);
    return (g_heff_2ebuild_2ecommands_2eexisting_24s783863025x1958439471(v_dir_240, v_rest_245, v_p_242, heff_clo_n(g_heff_2ebuild_2ecommands_2eexisting_24s783863025x1958439471_lam4, 1, 2, (V[]){v_p_243, v_f_246})));
  }
  default: return heff_nomatch(v_x_2429);
  }
}
V g_heff_2ebuild_2ecommands_2eexisting_24s783863025x1958439471_lam1(V self, V *args) {
  V v_x_2417 = args[0];
  V v_dir_240 = heff_env(self)[0];
  V v_f_246 = heff_env(self)[1];
  V v_p_242 = heff_env(self)[2];
  V v_rest_245 = heff_env(self)[3];
  V v_p_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_st_2418;
  if (heff_strEq_c(v_x_2417, ((V)&g_heff_2ebuild_2ecommands_2eexisting_24s783863025x1958439471_str0))) {
    v_st_2418 = NTAG(TAG_Windows);
  } else {
    v_st_2418 = NTAG(TAG_Posix);
  }
  V v_t_2419 = (g_std_2epath_2eparse(v_st_2418, heff_dup(v_dir_240)));
  V v_t_2420 = (g_std_2epath_2eparse(v_st_2418, heff_dup(v_f_246)));
  V v_t_2421 = (g_std_2epath_2ejoin(v_t_2419, v_t_2420));
  V v_s_2422 = ({ V a_0 = v_st_2418; V a_1 = v_t_2421; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2418); heff_drop(v_t_2421); r_; });
  V v_path_2423 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_s_2422; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
  V v_c_2424 = ({ V a_0 = v_path_2423; V r_ = (g_std_2efilesystem_2ereadFile_24s2092922012x215966209(a_0)); heff_drop(v_path_2423); r_; });
  V v_c_2428 = heff_tr(heff_call(v_c_2424, 2, (V[]){heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), ((V)&g_heff_2ebuild_2ecommands_2eexisting_24s783863025x1958439471_lam2_clo)}));
  V f_ = v_c_2428;
  heff_room[0] = heff_dup(v_p_242);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2eexisting_24s783863025x1958439471_lam3, 1, 5, (V[]){v_dir_240, v_rest_245, v_p_242, v_p_243, v_f_246});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2einitCmd_24s795893522x1842903301_str0, 5, "win32");
HEFF_LIT(g_heff_2ebuild_2ecommands_2einitCmd_24s795893522x1842903301_str1, 5, "0.1.0");
HEFF_LIT(g_heff_2ebuild_2ecommands_2einitCmd_24s795893522x1842903301_str2, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2einitCmd_24s795893522x1842903301_str3, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2einitCmd_24s795893522x1842903301_str4, 23, "heff: a new project in ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2einitCmd_24s795893522x1842903301_str5, 56, "; there, `heff build` builds it and `heff test` tests it");
HEFF_LIT(g_heff_2ebuild_2ecommands_2einitCmd_24s795893522x1842903301_str6, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2einitCmd_24s795893522x1842903301_str7, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2einitCmd_24s795893522x1842903301_str8, 2, ", ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2einitCmd_24s795893522x1842903301_str9, 5, " has ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2einitCmd_24s795893522x1842903301_str10, 25, " already; nothing written");
HEFF_LIT(g_heff_2ebuild_2ecommands_2einitCmd_24s795893522x1842903301_str11, 6, "heff: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2einitCmd_24s795893522x1842903301_str12, 1, "\012");
V g_heff_2ebuild_2ecommands_2einitCmd_24s795893522x1842903301_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2einitCmd_24s795893522x1842903301_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2einitCmd_24s795893522x1842903301_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2einitCmd_24s795893522x1842903301_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2einitCmd_24s795893522x1842903301_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2einitCmd_24s795893522x1842903301_lam7(V self, V *args);
V g_heff_2ebuild_2ecommands_2einitCmd_24s795893522x1842903301_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2einitCmd_24s795893522x1842903301_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2einitCmd_24s795893522x1842903301_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2einitCmd_24s795893522x1842903301_lam9(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2einitCmd_24s795893522x1842903301_lam9_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2einitCmd_24s795893522x1842903301_lam9, 3, 0};
V g_heff_2ebuild_2ecommands_2einitCmd_24s795893522x1842903301_lam10(V self, V *args);
V g_heff_2ebuild_2ecommands_2einitCmd_24s795893522x1842903301_lam8(V self, V *args);
V g_heff_2ebuild_2ecommands_2einitCmd_24s795893522x1842903301_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2einitCmd_24s795893522x1842903301_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2einitCmd_24s795893522x1842903301_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2einitCmd_24s795893522x1842903301(V v_dir_240, V v_hd_241, V v_k_242) {
top: ;
  return (g_heff_2ebuild_2ecommands_2ecwdNow_24s507786937x461532604(heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2ecommands_2einitCmd_24s795893522x1842903301_lam0, 1, 3, (V[]){v_hd_241, v_dir_240, v_k_242})));
}
V g_heff_2ebuild_2ecommands_2einitCmd_24s795893522x1842903301_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2einitCmd_24s795893522x1842903301(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2ecommands_2einitCmd_24s795893522x1842903301_lam2(V self, V *args) {
  V v_s_245 = args[0];
  return v_s_245;
}
V g_heff_2ebuild_2ecommands_2einitCmd_24s795893522x1842903301_lam5(V self, V *args) {
  V v_x_2434 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2434);
  V v_t_2435 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2436 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2435})});
  V v_t_2437 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2436})});
  V v_t_2438 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2437})});
  V v_t_2439 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2438})});
  V v_t_2440 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2439})});
  V v_t_2441 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2440})});
  return (g_co_2eop_24s615738393x1686646143(heff_tag_n(TAG_InR, 1, (V[]){v_t_2441}), v_hd_241, v_k_242));
}
V g_heff_2ebuild_2ecommands_2einitCmd_24s795893522x1842903301_lam6(V self, V *args) {
  V v_x_2442 = args[0];
  V v_dir_240 = heff_env(self)[0];
  V v_hd_241 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  if ((heff_dup(v_x_2442) == NTAG(TAG_True))) {
    heff_drop(v_x_2442);
    V v_t_2443 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2einitCmd_24s795893522x1842903301_str4), heff_strAppend(v_dir_240, ((V)&g_heff_2ebuild_2ecommands_2einitCmd_24s795893522x1842903301_str5)));
    V v_t_2444 = heff_tag_n(TAG_Write, 2, (V[]){heff_strAppend(v_t_2443, ((V)&g_heff_2ebuild_2ecommands_2einitCmd_24s795893522x1842903301_str6)), NTAG(TAG_MkUnit)});
    V v_t_2445 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2444})});
    V v_t_2446 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2445})});
    V v_t_2447 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2446})});
    V v_t_2448 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2447})});
    V v_t_2449 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2448})});
    V v_t_2450 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2449})});
    V v_t_2451 = heff_tr(heff_call(heff_take_field(v_hd_241, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2450})}));
    V f_ = heff_get_n(v_hd_241, 1, 3);
    heff_room[0] = v_t_2451;
    heff_room[1] = v_k_242;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    heff_drop(v_x_2442);
    heff_drop(v_dir_240);
    V v_t_2452 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
    V v_t_2453 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2452})});
    V v_t_2454 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2453})});
    V v_t_2455 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2454})});
    V v_t_2456 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2455})});
    V v_t_2457 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2456})});
    V v_t_2458 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2457})});
    return (g_co_2eop_24s615738393x1686646143(heff_tag_n(TAG_InR, 1, (V[]){v_t_2458}), v_hd_241, v_k_242));
  }
}
V g_heff_2ebuild_2ecommands_2einitCmd_24s795893522x1842903301_lam7(V self, V *args) {
  V v_x_2474 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2474);
  V v_t_2475 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2476 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2475})});
  V v_t_2477 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2476})});
  V v_t_2478 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2477})});
  V v_t_2479 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2478})});
  V v_t_2480 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2479})});
  V v_t_2481 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2480})});
  return (g_co_2eop_24s615738393x1686646143(heff_tag_n(TAG_InR, 1, (V[]){v_t_2481}), v_hd_241, v_k_242));
}
V g_heff_2ebuild_2ecommands_2einitCmd_24s795893522x1842903301_lam4(V self, V *args) {
  V v_x_2420 = args[0];
  V v_dir_240 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  V v_x_2416 = heff_env(self)[2];
  V v_hd_241 = heff_env(self)[3];
  V v_k_242 = heff_env(self)[4];
  V v_x_2419 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2421;
  if (heff_strEq_c_lent(v_dir_240, ((V)&g_heff_2ebuild_2ecommands_2einitCmd_24s795893522x1842903301_str2), 2)) {
    v_t_2421 = v_x_243;
  } else {
    heff_drop(v_x_243);
    v_t_2421 = heff_dup(v_dir_240);
  }
  HeffT2 v_t_2422 = (g_heff_2ebuild_2ecommands_2einitProblem_24cpr(v_t_2421, v_x_2416));
  {
    V v_field_2424 = v_t_2422.f[1];
    int64_t v_tag_2423 = ((int64_t)v_t_2422.f[0]);
    if ((v_tag_2423 == ((int64_t)0ULL))) {
      heff_drop(v_x_2420);
      heff_drop(v_dir_240);
      heff_drop(v_x_2419);
      V v_why_2425 = v_field_2424;
      V v_t_2426 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_why_2425, ((V)&g_heff_2ebuild_2ecommands_2einitCmd_24s795893522x1842903301_str3)), NTAG(TAG_MkUnit)});
      V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
      V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
      V v_t_2429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
      V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
      V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
      V v_t_2432 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2431})});
      V v_t_2433 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_241, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2432})}));
      V f_ = heff_dup(heff_rfield(v_hd_241, 1));
      heff_room[0] = v_t_2433;
      heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2einitCmd_24s795893522x1842903301_lam5, 1, 2, (V[]){v_hd_241, v_k_242});
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    } else {
      heff_drop(v_field_2424);
      switch (heff_tag_of(v_x_2420)) {
      case TAG_Nil: {
        return (g_heff_2ebuild_2ecommands_2ewriteAll_24s302415776x955929641(heff_dup(v_dir_240), v_x_2419, heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2ecommands_2einitCmd_24s795893522x1842903301_lam6, 1, 3, (V[]){v_dir_240, v_hd_241, v_k_242})));
      }
      case TAG_Cons: {
        heff_drop(v_x_2419);
        V v_t_2463;
        switch (heff_tag_of(v_x_2420)) {
        case TAG_Nil: {
          v_t_2463 = ((V)&g_heff_2ebuild_2ecommands_2einitCmd_24s795893522x1842903301_str7);
          break;
        }
        case TAG_Cons: {
          V v_x_2461 = heff_field(v_x_2420, 0);
          V v_xs_2462 = heff_field(v_x_2420, 1);
          heff_take_n(v_x_2420, 3ULL, 2);
          v_t_2463 = ({ V a_0 = ((V)&g_heff_2ebuild_2ecommands_2einitCmd_24s795893522x1842903301_str8); V a_1 = v_x_2461; V a_2 = v_xs_2462; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2462); r_; });
          break;
        }
        default: heff_nomatch(v_x_2420);
        }
        V v_t_2464 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2einitCmd_24s795893522x1842903301_str9), heff_strAppend(v_t_2463, ((V)&g_heff_2ebuild_2ecommands_2einitCmd_24s795893522x1842903301_str10)));
        V v_str_2465 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2einitCmd_24s795893522x1842903301_str11), heff_strAppend(v_dir_240, v_t_2464));
        V v_t_2466 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_str_2465, ((V)&g_heff_2ebuild_2ecommands_2einitCmd_24s795893522x1842903301_str12)), NTAG(TAG_MkUnit)});
        V v_t_2467 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2466})});
        V v_t_2468 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2467})});
        V v_t_2469 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2468})});
        V v_t_2470 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2469})});
        V v_t_2471 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2470})});
        V v_t_2472 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2471})});
        V v_t_2473 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_241, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2472})}));
        V f_ = heff_dup(heff_rfield(v_hd_241, 1));
        heff_room[0] = v_t_2473;
        heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2einitCmd_24s795893522x1842903301_lam7, 1, 2, (V[]){v_hd_241, v_k_242});
        if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
      }
      default: return heff_nomatch(v_x_2420);
      }
    }
  }
}
V g_heff_2ebuild_2ecommands_2einitCmd_24s795893522x1842903301_lam3(V self, V *args) {
  V v_x_2414 = args[0];
  V v_dir_240 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  V v_x_244 = heff_env(self)[2];
  V v_hd_241 = heff_env(self)[3];
  V v_k_242 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2415;
  if (heff_strEq_c(v_x_2414, ((V)&g_heff_2ebuild_2ecommands_2einitCmd_24s795893522x1842903301_str0))) {
    v_t_2415 = NTAG(TAG_Windows);
  } else {
    v_t_2415 = NTAG(TAG_Posix);
  }
  V v_x_2416 = ({ V a_0 = v_t_2415; V a_1 = heff_dup(v_dir_240); V a_2 = heff_dup(v_x_243); V r_ = (g_heff_2ebuild_2ecommands_2eprojectName(a_0, a_1, a_2)); heff_drop(v_t_2415); r_; });
  V v_t_2418;
  switch (heff_tag_of(v_x_244)) {
  case TAG_Nothing: {
    v_t_2418 = ((V)&g_heff_2ebuild_2ecommands_2einitCmd_24s795893522x1842903301_str1);
    break;
  }
  case TAG_Just: {
    V v_x_2417 = heff_field(v_x_244, 0);
    heff_take_n(v_x_244, 1ULL, 1);
    v_t_2418 = v_x_2417;
    break;
  }
  default: heff_nomatch(v_x_244);
  }
  V v_x_2419 = (g_heff_2ebuild_2ecommands_2eprojectFiles(heff_dup(v_x_2416), v_t_2418));
  return (g_heff_2ebuild_2ecommands_2eexisting_24s783863025x1958439471(heff_dup(v_dir_240), heff_dup(v_x_2419), heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2ecommands_2einitCmd_24s795893522x1842903301_lam4, 1, 6, (V[]){v_dir_240, v_x_243, v_x_2416, v_hd_241, v_k_242, v_x_2419})));
}
V g_heff_2ebuild_2ecommands_2einitCmd_24s795893522x1842903301_lam1(V self, V *args) {
  V v_x_244 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_dir_240 = heff_env(self)[1];
  V v_x_243 = heff_env(self)[2];
  V v_k_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_246 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2einitCmd_24s795893522x1842903301_lam2_clo)})});
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_241, 2)), 1, (V[]){v_t_2412}));
  V f_ = heff_dup(heff_rfield(v_hd_241, 1));
  heff_room[0] = v_t_2413;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2einitCmd_24s795893522x1842903301_lam3, 1, 5, (V[]){v_dir_240, v_x_243, v_x_244, v_hd_241, v_k_242});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2einitCmd_24s795893522x1842903301_lam9(V self, V *args) {
  V v_x_2486 = args[0];
  V v_hd_2487 = args[1];
  V v_k_2488 = args[2];
  heff_drop(v_hd_2487);
  V f_ = v_k_2488;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2486});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2einitCmd_24s795893522x1842903301_lam10(V self, V *args) {
  V v_x_2490 = args[0];
  V v_k_2482 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x_2490)) {
  case TAG_Left: {
    heff_take_n(v_x_2490, 0ULL, 1);
    V f_ = v_k_2482;
    args[0] = NTAG(TAG_Nothing);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Right: {
    V v_y_2492 = heff_field(v_x_2490, 0);
    V v_ru_24x_2490_24Right = heff_take_reuse_n(v_x_2490, 1ULL, 1);
    HeffT2 v_t_2493 = ({ V a_0 = v_y_2492; HeffT2 r_ = (g_heff_2ebuild_2eproject_2epackageLit_24cpr(a_0)); heff_drop(v_y_2492); r_; });
    {
      V v_field_2495 = v_t_2493.f[1];
      int64_t v_tag_2494 = ((int64_t)v_t_2493.f[0]);
      V v_x_24103;
      if ((v_tag_2494 == ((int64_t)0ULL))) {
        heff_drop_cell(v_ru_24x_2490_24Right, 1);
        V v_p_2496 = v_field_2495;
        heff_drop(v_p_2496);
        v_x_24103 = NTAG(TAG_Nothing);
      } else {
        V v_x_2497 = v_field_2495;
        HeffT2 v_t_2498 = (g_heff_2ebuild_2eproject_2epackageOf_24cpr(v_x_2497));
        {
          V v_field_24100 = v_t_2498.f[1];
          int64_t v_tag_2499 = ((int64_t)v_t_2498.f[0]);
          if ((v_tag_2499 == ((int64_t)0ULL))) {
            heff_drop_cell(v_ru_24x_2490_24Right, 1);
            V v_x_24101 = v_field_24100;
            heff_drop(v_x_24101);
            v_x_24103 = NTAG(TAG_Nothing);
          } else {
            V v_p_24102 = v_field_24100;
            v_x_24103 = heff_tag_at_n(v_ru_24x_2490_24Right, TAG_Just, 1, (V[]){heff_get_n(v_p_24102, 1, 4)});
          }
        }
      }
      V f_ = v_k_2482;
      args[0] = v_x_24103;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
  }
  default: return heff_nomatch(v_x_2490);
  }
}
V g_heff_2ebuild_2ecommands_2einitCmd_24s795893522x1842903301_lam8(V self, V *args) {
  V v_x_2483 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_2482 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_path_2484 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_x_2483; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
  V v_c_2485 = ({ V a_0 = v_path_2484; V r_ = (g_std_2efilesystem_2ereadFile_24s2092922012x215966209(a_0)); heff_drop(v_path_2484); r_; });
  V v_c_2489 = heff_tr(heff_call(v_c_2485, 2, (V[]){heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), ((V)&g_heff_2ebuild_2ecommands_2einitCmd_24s795893522x1842903301_lam9_clo)}));
  V f_ = v_c_2489;
  heff_room[0] = v_hd_241;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2einitCmd_24s795893522x1842903301_lam10, 1, 1, (V[]){v_k_2482});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2einitCmd_24s795893522x1842903301_lam0(V self, V *args) {
  V v_x_243 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_dir_240 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_k_2482 = heff_clo_n(g_heff_2ebuild_2ecommands_2einitCmd_24s795893522x1842903301_lam1, 1, 4, (V[]){heff_dup(v_hd_241), v_dir_240, v_x_243, v_k_242});
  return (g_heff_2ebuild_2ecommands_2eownPackage_24s693628669x534541312(heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2ecommands_2einitCmd_24s795893522x1842903301_lam8, 1, 2, (V[]){v_hd_241, v_k_2482})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941_str0, 7, "commits");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941_str1, 4, " of ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941_str2, 12, "finding the ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941_str3, 8, "https://");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941_str4, 6, "--bare");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941_str5, 15, "--filter=tree:0");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941_str6, 5, "clone");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941_str7, 7, "--quiet");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941_str8, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941_str9, 3, "git");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941_str10, 8, "https://");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941_str11, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941_str12, 27, "cannot list the commits of ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941_str13, 4, " of ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941_str14, 8, "https://");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941_str15, 3, "no ");
V g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941_lam1, 3, 0};
V g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941_lam3(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941_lam3, 3, 0};
V g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941_lam5(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941_lam5, 1, 0};
V g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941_lam7(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941_lam7, 1, 0};
V g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941_lam9(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941_lam9_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941_lam9, 2, 0};
V g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941_lam10(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941_lam10_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941_lam10, 2, 0};
V g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941_lam11(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941_lam11_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941_lam11, 2, 0};
V g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941_lam12(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941_lam12_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941_lam12, 2, 0};
V g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941_lam14(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941_lam14_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941_lam14, 3, 0};
V g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941_lam16(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941_lam15(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941_lam13(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941_lam8(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941_entry, 4, 0};

V g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941(V v_prog_240, V v_ps_241, V v_path_242, V v_rev_243) {
top: ;
  V v_x_244 = (g_heff_2ebuild_2eload_2ecachedDir(heff_dup(v_ps_241), heff_dup(v_path_242), ((V)&g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941_str0)));
  return heff_clo_n(g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941_lam0, 2, 5, (V[]){v_x_244, v_ps_241, v_rev_243, v_path_242, v_prog_240});
}
V g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941(a[0], a[1], a[2], a[3]);
}
V g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941_lam1(V self, V *args) {
  V v_x_249 = args[0];
  V v_hd_2410 = args[1];
  V v_k_2411 = args[2];
  heff_drop(v_hd_2410);
  V f_ = v_k_2411;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_249});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941_lam3(V self, V *args) {
  V v_x_2429 = args[0];
  V v_hd_2430 = args[1];
  V v_k_2431 = args[2];
  heff_drop(v_hd_2430);
  V f_ = v_k_2431;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2429});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941_lam5(V self, V *args) {
  V v_t_2437 = args[0];
  return v_t_2437;
}
V g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941_lam7(V self, V *args) {
  V v_r_2448 = args[0];
  return v_r_2448;
}
V g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941_lam9(V self, V *args) {
  V v_hd_2462 = args[0];
  V v_k_2463 = args[1];
  heff_drop(v_hd_2462);
  V f_ = v_k_2463;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941_lam10(V self, V *args) {
  V v_hd_2465 = args[0];
  V v_k_2466 = args[1];
  heff_drop(v_hd_2465);
  V f_ = v_k_2466;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941_lam11(V self, V *args) {
  V v_hd_2467 = args[0];
  V v_k_2468 = args[1];
  heff_drop(v_hd_2467);
  V f_ = v_k_2468;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941_lam12(V self, V *args) {
  V v_hd_2469 = args[0];
  V v_k_2470 = args[1];
  heff_drop(v_hd_2469);
  V f_ = v_k_2470;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941_lam14(V self, V *args) {
  V v_x_2475 = args[0];
  V v_hd_2476 = args[1];
  V v_k_2477 = args[2];
  heff_drop(v_hd_2476);
  V f_ = v_k_2477;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2475});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941_lam16(V self, V *args) {
  V v_x_2482 = args[0];
  V v_ended_2458 = heff_env(self)[0];
  V v_path_242 = heff_env(self)[1];
  V v_err_2459 = heff_env(self)[2];
  V v_x_2472 = heff_env(self)[3];
  V v_rev_243 = heff_env(self)[4];
  V v_k_246 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_2482);
  V v_t_2485;
  switch (heff_tag_of(v_ended_2458)) {
  case TAG_Exited: {
    V v_n_2483 = heff_field(v_ended_2458, 0);
    heff_take_n(v_ended_2458, 1ULL, 1);
    v_t_2485 = heff_bool(!heff_intEq_c_lent(v_n_2483, MK_INT(0LL), 2));
    heff_drop(v_n_2483);
    break;
  }
  case TAG_Signalled: {
    heff_take_n(v_ended_2458, 0ULL, 1);
    v_t_2485 = NTAG(TAG_True);
    break;
  }
  case TAG_TimedOut: {
    v_t_2485 = NTAG(TAG_True);
    break;
  }
  case TAG_NotRun: {
    v_t_2485 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_ended_2458);
  }
  V v_x_24101;
  if ((heff_dup(v_t_2485) == NTAG(TAG_True))) {
    heff_drop(v_x_2472);
    heff_drop(v_rev_243);
    heff_drop(v_t_2485);
    V v_t_2486 = (g_heff_2ebuild_2eproject_2erepoOf(v_path_242));
    V v_s_2487 = v_err_2459;
    V v_t_2488 = (g_prelude_2eskipSpaces(v_s_2487, MK_INT(0LL), MK_INT(1LL)));
    int64_t v_t_2489 = (heff_unbox_word(heff_strLength_lent(v_s_2487, 0)) - ((int64_t)1ULL));
    V v_t_2490 = (g_prelude_2eskipSpaces(v_s_2487, heff_box_word(v_t_2489), MK_INT(-1LL)));
    V v_t_2491 = heff_strSlice(v_s_2487, v_t_2488, heff_intAdd(v_t_2490, MK_INT(1LL)));
    V v_t_2492 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941_str10), v_t_2486), heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941_str11), v_t_2491));
    v_x_24101 = heff_tag_n(TAG_Left, 1, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941_str12), v_t_2492)});
  } else {
    heff_drop(v_err_2459);
    heff_drop(v_t_2485);
    switch (heff_tag_of(v_x_2472)) {
    case TAG_Nothing: {
      V v_t_2493 = (g_heff_2ebuild_2ecommands_2erevSaid(v_rev_243));
      V v_t_2494 = (g_heff_2ebuild_2eproject_2erepoOf(v_path_242));
      V v_t_2495 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941_str13), heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941_str14), v_t_2494));
      V v_t_2496 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941_str15), heff_strAppend(v_t_2493, v_t_2495));
      v_x_24101 = heff_tag_n(TAG_Left, 1, (V[]){v_t_2496});
      break;
    }
    case TAG_Just: {
      V v_it1_2497 = heff_field(v_x_2472, 0);
      V v_ru_24x_2472_24Just = heff_take_reuse_n(v_x_2472, 1ULL, 1);
      heff_drop(v_rev_243);
      switch (heff_tag_of(v_it1_2497)) {
      case TAG_MkPair: {
        V v_time_2498 = heff_field(v_it1_2497, 0);
        V v_hash_2499 = heff_field(v_it1_2497, 1);
        heff_take_n(v_it1_2497, 3ULL, 2);
        V v_t_24100 = ({ V a_0 = v_path_242; V a_1 = v_time_2498; V a_2 = v_hash_2499; V r_ = (g_heff_2ebuild_2eproject_2epseudoVersion(a_0, a_1, a_2)); heff_drop(v_hash_2499); r_; });
        v_x_24101 = heff_tag_at_n(v_ru_24x_2472_24Just, TAG_Right, 1, (V[]){v_t_24100});
        break;
      }
      default: heff_nomatch(v_it1_2497);
      }
      break;
    }
    default: heff_nomatch(v_x_2472);
    }
  }
  V f_ = v_k_246;
  args[0] = v_x_24101;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941_lam15(V self, V *args) {
  V v_x_2479 = args[0];
  V v_x_2439 = heff_env(self)[0];
  V v_prog_240 = heff_env(self)[1];
  V v_hd_245 = heff_env(self)[2];
  V v_ended_2458 = heff_env(self)[3];
  V v_path_242 = heff_env(self)[4];
  V v_err_2459 = heff_env(self)[5];
  V v_x_2472 = heff_env(self)[6];
  V v_rev_243 = heff_env(self)[7];
  V v_k_246 = heff_env(self)[8];
  heff_clo_take(self, 9);
  heff_drop(v_x_2479);
  V v_t_2480 = heff_tag_n(TAG_End, 2, (V[]){v_x_2439, NTAG(TAG_MkUnit)});
  V v_t_2481 = heff_tr(heff_call(v_prog_240, 1, (V[]){v_t_2480}));
  return (g_co_2eop_24s615738393x1686646143(v_t_2481, v_hd_245, heff_clo_n(g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941_lam16, 1, 6, (V[]){v_ended_2458, v_path_242, v_err_2459, v_x_2472, v_rev_243, v_k_246})));
}
V g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941_lam13(V self, V *args) {
  V v_x_2472 = args[0];
  V v_x_244 = heff_env(self)[0];
  V v_hd_245 = heff_env(self)[1];
  V v_x_2439 = heff_env(self)[2];
  V v_prog_240 = heff_env(self)[3];
  V v_ended_2458 = heff_env(self)[4];
  V v_path_242 = heff_env(self)[5];
  V v_err_2459 = heff_env(self)[6];
  V v_rev_243 = heff_env(self)[7];
  V v_k_246 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_path_2473 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_x_244; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
  V v_c_2474 = ({ V a_0 = v_path_2473; V r_ = (g_std_2efilesystem_2eremove_24s1441356369x419789784(a_0)); heff_drop(v_path_2473); r_; });
  V v_c_2478 = heff_tr(heff_call(v_c_2474, 2, (V[]){heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), ((V)&g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941_lam14_clo)}));
  V f_ = v_c_2478;
  heff_room[0] = heff_dup(v_hd_245);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941_lam15, 1, 9, (V[]){v_x_2439, v_prog_240, v_hd_245, v_ended_2458, v_path_242, v_err_2459, v_x_2472, v_rev_243, v_k_246});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941_lam8(V self, V *args) {
  V v_x_2457 = args[0];
  V v_rev_243 = heff_env(self)[0];
  V v_x_244 = heff_env(self)[1];
  V v_hd_245 = heff_env(self)[2];
  V v_x_2439 = heff_env(self)[3];
  V v_prog_240 = heff_env(self)[4];
  V v_path_242 = heff_env(self)[5];
  V v_k_246 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_ended_2458 = heff_take_field(v_x_2457, 0);
  V v_err_2459 = heff_get_n(v_x_2457, 2, 3);
  V v_c_2471;
  switch (heff_tag_of(v_ended_2458)) {
  case TAG_Exited: {
    V v_n_2460 = heff_dup(heff_field(v_ended_2458, 0));
    if (heff_intEq_c(v_n_2460, MK_INT(0LL))) {
      V v_t_2461 = (g_heff_2ebuild_2ecommands_2erevNamed(heff_dup(v_rev_243)));
      v_c_2471 = (g_heff_2ebuild_2ecommands_2ecommitAt_24s1687144202x1882378819(heff_dup(v_x_244), v_t_2461));
    } else {
      v_c_2471 = ((V)&g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941_lam9_clo);
    }
    break;
  }
  case TAG_Signalled: {
    v_c_2471 = ((V)&g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941_lam10_clo);
    break;
  }
  case TAG_TimedOut: {
    v_c_2471 = ((V)&g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941_lam11_clo);
    break;
  }
  case TAG_NotRun: {
    v_c_2471 = ((V)&g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941_lam12_clo);
    break;
  }
  default: heff_nomatch(v_ended_2458);
  }
  V f_ = v_c_2471;
  heff_room[0] = heff_dup(v_hd_245);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941_lam13, 1, 9, (V[]){v_x_244, v_hd_245, v_x_2439, v_prog_240, v_ended_2458, v_path_242, v_err_2459, v_rev_243, v_k_246});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941_lam6(V self, V *args) {
  V v_x_2439 = args[0];
  V v_path_242 = heff_env(self)[0];
  V v_x_244 = heff_env(self)[1];
  V v_hd_245 = heff_env(self)[2];
  V v_rev_243 = heff_env(self)[3];
  V v_prog_240 = heff_env(self)[4];
  V v_k_246 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2440 = (g_heff_2ebuild_2eproject_2erepoOf(heff_dup(v_path_242)));
  V v_t_2441 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_x_244), NTAG(TAG_Nil)});
  V v_t_2442 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941_str3), v_t_2440), v_t_2441});
  V v_t_2443 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941_str4), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941_str5), v_t_2442})});
  V v_t_2444 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941_str6), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941_str7), v_t_2443})});
  V v_t_2445 = ({ V b_0 = NTAG(TAG_Nil); V b_1 = NTAG(TAG_Nil); V r_ = (g_std_2epath_2esameSegments(b_0, b_1)); heff_drop(b_0); heff_drop(b_1); r_; });
  V v_t_2446;
  if ((heff_dup(v_t_2445) == NTAG(TAG_True))) {
    heff_drop(v_t_2445);
    v_t_2446 = ((V)&g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941_str8);
  } else {
    heff_drop(v_t_2445);
    v_t_2446 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V b_1 = heff_dup(g_std_2epath_2ecurrent_get()); V r_ = (g_std_2epath_2erender(b_0, b_1)); heff_drop(b_0); heff_drop(b_1); r_; });
  }
  V v_t_2447 = heff_rec_n(10, shape_command__args__dir__env__input__output__errors__timeout__keep__group, (V[]){((V)&g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941_str9), v_t_2444, v_t_2446, NTAG(TAG_Nil), NTAG(TAG_NoInput), NTAG(TAG_Collected), NTAG(TAG_Collected), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_False)});
  V v_a_2449 = heff_tag_n(TAG_Run, 2, (V[]){v_t_2447, ((V)&g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941_lam7_clo)});
  V v_t_2450 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2449})});
  V v_t_2451 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2450})});
  V v_t_2452 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2451})});
  V v_t_2453 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2452})});
  V v_t_2454 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2453})});
  V v_t_2455 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2454})});
  V v_t_2456 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_245, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2455})}));
  V f_ = heff_dup(heff_rfield(v_hd_245, 1));
  heff_room[0] = v_t_2456;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941_lam8, 1, 7, (V[]){v_rev_243, v_x_244, v_hd_245, v_x_2439, v_prog_240, v_path_242, v_k_246});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941_lam4(V self, V *args) {
  V v_x_2433 = args[0];
  V v_rev_243 = heff_env(self)[0];
  V v_path_242 = heff_env(self)[1];
  V v_prog_240 = heff_env(self)[2];
  V v_hd_245 = heff_env(self)[3];
  V v_x_244 = heff_env(self)[4];
  V v_k_246 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_2433);
  V v_t_2434 = (g_heff_2ebuild_2ecommands_2erevSaid(heff_dup(v_rev_243)));
  V v_t_2435 = heff_strAppend(v_t_2434, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941_str1), heff_dup(v_path_242)));
  V v_name_2436 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941_str2), v_t_2435);
  V v_t_2438 = heff_tr(heff_call(heff_dup(v_prog_240), 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){heff_dup(g_std_2eprogress_2eroot_get()), v_name_2436, MK_INT(0LL), ((V)&g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941_lam5_clo)})}));
  return (g_co_2eop_24s615738393x1686646143(v_t_2438, heff_dup(v_hd_245), heff_clo_n(g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941_lam6, 1, 6, (V[]){v_path_242, v_x_244, v_hd_245, v_rev_243, v_prog_240, v_k_246})));
}
V g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941_lam2(V self, V *args) {
  V v_x_2413 = args[0];
  V v_ps_241 = heff_env(self)[0];
  V v_x_244 = heff_env(self)[1];
  V v_hd_245 = heff_env(self)[2];
  V v_rev_243 = heff_env(self)[3];
  V v_path_242 = heff_env(self)[4];
  V v_prog_240 = heff_env(self)[5];
  V v_k_246 = heff_env(self)[6];
  heff_clo_take(self, 7);
  heff_drop(v_x_2413);
  V v_st_2414 = heff_get_n(v_ps_241, 5, 6);
  HeffT3 v_t_2415 = (g_std_2epath_2eparse_24cpr(v_st_2414, heff_dup(v_x_244)));
  V v_t_2425;
  {
    V v_field_2416 = v_t_2415.f[0];
    V v_field_2417 = v_t_2415.f[1];
    V v_field_2418 = v_t_2415.f[2];
    V v_d_2419 = v_field_2416;
    V v_a_2420 = v_field_2417;
    V v_xs_2421 = v_field_2418;
    V v_t_2422 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2421));
    V v_xs_2423 = ({ V a_0 = MK_INT(1LL); V a_1 = v_t_2422; V r_ = (g_list_2edrop(a_0, a_1)); heff_drop(v_t_2422); r_; });
    V v_t_2424 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2423));
    v_t_2425 = heff_tag_n(TAG_MkPath, 3, (V[]){v_d_2419, v_a_2420, v_t_2424});
  }
  V v_s_2426 = ({ V a_0 = v_st_2414; V a_1 = v_t_2425; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2414); heff_drop(v_t_2425); r_; });
  V v_path_2427 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_s_2426; V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
  V v_c_2428 = ({ V a_0 = v_path_2427; V r_ = (g_std_2efilesystem_2emakeDirectory_24s1800594932x1926120429(a_0)); heff_drop(v_path_2427); r_; });
  V v_c_2432 = heff_tr(heff_call(v_c_2428, 2, (V[]){heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), ((V)&g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941_lam3_clo)}));
  V f_ = v_c_2432;
  heff_room[0] = heff_dup(v_hd_245);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941_lam4, 1, 6, (V[]){v_rev_243, v_path_242, v_prog_240, v_hd_245, v_x_244, v_k_246});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941_lam0(V self, V *args) {
  V v_hd_245 = args[0];
  V v_k_246 = args[1];
  V v_x_244 = heff_env(self)[0];
  V v_ps_241 = heff_env(self)[1];
  V v_rev_243 = heff_env(self)[2];
  V v_path_242 = heff_env(self)[3];
  V v_prog_240 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_path_247 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = heff_dup(v_x_244); V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
  V v_c_248 = ({ V a_0 = v_path_247; V r_ = (g_std_2efilesystem_2eremove_24s1441356369x419789784(a_0)); heff_drop(v_path_247); r_; });
  V v_c_2412 = heff_tr(heff_call(v_c_248, 2, (V[]){heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), ((V)&g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941_lam1_clo)}));
  V f_ = v_c_2412;
  args[0] = heff_dup(v_hd_245);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ecommitVersion_24s1485985929x1053074941_lam2, 1, 7, (V[]){v_ps_241, v_x_244, v_hd_245, v_rev_243, v_path_242, v_prog_240, v_k_246});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishGit_24s211231607x115039889_str0, 3, "git");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishGit_24s211231607x115039889_str1, 6, "status");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishGit_24s211231607x115039889_str2, 11, "--porcelain");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishGit_24s211231607x115039889_str3, 11, "refs/tags/v");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishGit_24s211231607x115039889_str4, 2, "-q");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishGit_24s211231607x115039889_str5, 8, "--verify");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishGit_24s211231607x115039889_str6, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishGit_24s211231607x115039889_str7, 3, "git");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishGit_24s211231607x115039889_str8, 9, "rev-parse");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishGit_24s211231607x115039889_str9, 25, "not in a git repository: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishGit_24s211231607x115039889_str10, 14, "heff publish: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishGit_24s211231607x115039889_str11, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishGit_24s211231607x115039889_str12, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishGit_24s211231607x115039889_str13, 67, "heff publish: what is published is what is committed: commit first\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishGit_24s211231607x115039889_str14, 1, "v");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishGit_24s211231607x115039889_str15, 18, " is tagged already");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishGit_24s211231607x115039889_str16, 14, "heff publish: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishGit_24s211231607x115039889_str17, 1, "\012");
V g_heff_2ebuild_2ecommands_2epublishGit_24s211231607x115039889_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2epublishGit_24s211231607x115039889_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2epublishGit_24s211231607x115039889_lam1, 1, 0};
V g_heff_2ebuild_2ecommands_2epublishGit_24s211231607x115039889_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2epublishGit_24s211231607x115039889_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2epublishGit_24s211231607x115039889_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2epublishGit_24s211231607x115039889_lam7(V self, V *args);
V g_heff_2ebuild_2ecommands_2epublishGit_24s211231607x115039889_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2epublishGit_24s211231607x115039889_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2epublishGit_24s211231607x115039889_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2epublishGit_24s211231607x115039889_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2epublishGit_24s211231607x115039889_entry, 6, 0};

V g_heff_2ebuild_2ecommands_2epublishGit_24s211231607x115039889(V v_rep_240, V v_v_241, V v_pk_242, V v_src_243, V v_z_244, V v_z_245) {
top: ;
  V v_c_246 = heff_tr(g_std_2eprocess_2erun_24s1262677465x1574883892(((V)&g_heff_2ebuild_2ecommands_2epublishGit_24s211231607x115039889_str0), ((V)&g_heff_2ebuild_2ecommands_2epublishGit_24s211231607x115039889_str1), ((V)&g_heff_2ebuild_2ecommands_2epublishGit_24s211231607x115039889_str2), MK_INT(0LL), MK_INT(0LL)));
  return heff_tail(v_c_246, 2, (V[]){heff_dup(v_z_244), heff_clo_n(g_heff_2ebuild_2ecommands_2epublishGit_24s211231607x115039889_lam0, 1, 6, (V[]){v_v_241, v_z_244, v_z_245, v_src_243, v_rep_240, v_pk_242})});
}
V g_heff_2ebuild_2ecommands_2epublishGit_24s211231607x115039889_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2epublishGit_24s211231607x115039889(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2ebuild_2ecommands_2epublishGit_24s211231607x115039889_lam1(V self, V *args) {
  V v_r_2416 = args[0];
  return v_r_2416;
}
V g_heff_2ebuild_2ecommands_2epublishGit_24s211231607x115039889_lam3(V self, V *args) {
  V v_x_2444 = args[0];
  V v_z_244 = heff_env(self)[0];
  V v_z_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2444);
  V v_t_2445 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2446 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2445})});
  V v_t_2447 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2446})});
  V v_t_2448 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2447})});
  V v_t_2449 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2448})});
  V v_t_2450 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2449})});
  V v_t_2451 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2450})});
  return (g_co_2eop_24s615738393x1686646143(heff_tag_n(TAG_InR, 1, (V[]){v_t_2451}), v_z_244, v_z_245));
}
V g_heff_2ebuild_2ecommands_2epublishGit_24s211231607x115039889_lam4(V self, V *args) {
  V v_x_2466 = args[0];
  V v_z_244 = heff_env(self)[0];
  V v_z_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2466);
  V v_t_2467 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2468 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2467})});
  V v_t_2469 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2468})});
  V v_t_2470 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2469})});
  V v_t_2471 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2470})});
  V v_t_2472 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2471})});
  V v_t_2473 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2472})});
  return (g_co_2eop_24s615738393x1686646143(heff_tag_n(TAG_InR, 1, (V[]){v_t_2473}), v_z_244, v_z_245));
}
V g_heff_2ebuild_2ecommands_2epublishGit_24s211231607x115039889_lam5(V self, V *args) {
  V v_x_2488 = args[0];
  V v_z_244 = heff_env(self)[0];
  V v_z_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2488);
  V v_t_2489 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2490 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2489})});
  V v_t_2491 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2490})});
  V v_t_2492 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2491})});
  V v_t_2493 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2492})});
  V v_t_2494 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2493})});
  V v_t_2495 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2494})});
  return (g_co_2eop_24s615738393x1686646143(heff_tag_n(TAG_InR, 1, (V[]){v_t_2495}), v_z_244, v_z_245));
}
V g_heff_2ebuild_2ecommands_2epublishGit_24s211231607x115039889_lam7(V self, V *args) {
  V v_x_24100 = args[0];
  V v_v_241 = heff_env(self)[0];
  V v_pk_242 = heff_env(self)[1];
  V v_z_244 = heff_env(self)[2];
  V v_z_245 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2ebuild_2ecommands_2epublishTested_24s563627996x2090231580(v_v_241, v_pk_242, v_x_24100, v_z_244, v_z_245));
}
V g_heff_2ebuild_2ecommands_2epublishGit_24s211231607x115039889_lam6(V self, V *args) {
  V v_x_2498 = args[0];
  V v_rep_240 = heff_env(self)[0];
  V v_z_244 = heff_env(self)[1];
  V v_v_241 = heff_env(self)[2];
  V v_pk_242 = heff_env(self)[3];
  V v_z_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_c_2499 = ({ V a_0 = v_rep_240; V a_1 = v_x_2498; V a_2 = heff_dup(g_heff_2ebuild_2ecommands_2enoRes_get()); V r_ = (g_heff_2ebuild_2ecommands_2etestAll_24s749792949x1328449028(a_0, a_1, a_2)); heff_drop(v_x_2498); r_; });
  V f_ = v_c_2499;
  heff_room[0] = heff_dup(v_z_244);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2epublishGit_24s211231607x115039889_lam7, 1, 4, (V[]){v_v_241, v_pk_242, v_z_244, v_z_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2epublishGit_24s211231607x115039889_lam2(V self, V *args) {
  V v_x_2425 = args[0];
  V v_ended_248 = heff_env(self)[0];
  V v_err_249 = heff_env(self)[1];
  V v_z_244 = heff_env(self)[2];
  V v_z_245 = heff_env(self)[3];
  V v_out_2410 = heff_env(self)[4];
  V v_v_241 = heff_env(self)[5];
  V v_src_243 = heff_env(self)[6];
  V v_rep_240 = heff_env(self)[7];
  V v_pk_242 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_t_2428;
  switch (heff_tag_of(v_ended_248)) {
  case TAG_Exited: {
    V v_n_2426 = heff_field(v_ended_248, 0);
    heff_take_n(v_ended_248, 1ULL, 1);
    v_t_2428 = heff_bool(!heff_intEq_c_lent(v_n_2426, MK_INT(0LL), 2));
    heff_drop(v_n_2426);
    break;
  }
  case TAG_Signalled: {
    heff_take_n(v_ended_248, 0ULL, 1);
    v_t_2428 = NTAG(TAG_True);
    break;
  }
  case TAG_TimedOut: {
    v_t_2428 = NTAG(TAG_True);
    break;
  }
  case TAG_NotRun: {
    v_t_2428 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_ended_248);
  }
  if ((heff_dup(v_t_2428) == NTAG(TAG_True))) {
    heff_drop_rec(v_x_2425, 3);
    heff_drop(v_out_2410);
    heff_drop(v_v_241);
    heff_drop(v_src_243);
    heff_drop(v_rep_240);
    heff_drop(v_pk_242);
    heff_drop(v_t_2428);
    V v_s_2429 = v_err_249;
    V v_t_2430 = (g_prelude_2eskipSpaces(v_s_2429, MK_INT(0LL), MK_INT(1LL)));
    int64_t v_t_2431 = (heff_unbox_word(heff_strLength_lent(v_s_2429, 0)) - ((int64_t)1ULL));
    V v_t_2432 = (g_prelude_2eskipSpaces(v_s_2429, heff_box_word(v_t_2431), MK_INT(-1LL)));
    V v_t_2433 = heff_strSlice(v_s_2429, v_t_2430, heff_intAdd(v_t_2432, MK_INT(1LL)));
    V v_why_2434 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2epublishGit_24s211231607x115039889_str9), v_t_2433);
    V v_t_2435 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2epublishGit_24s211231607x115039889_str10), v_why_2434), ((V)&g_heff_2ebuild_2ecommands_2epublishGit_24s211231607x115039889_str11));
    V v_t_2436 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2435, NTAG(TAG_MkUnit)});
    V v_t_2437 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2436})});
    V v_t_2438 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2437})});
    V v_t_2439 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2438})});
    V v_t_2440 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2439})});
    V v_t_2441 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2440})});
    V v_t_2442 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2441})});
    V v_t_2443 = heff_tr(heff_call(heff_dup(heff_rfield(v_z_244, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2442})}));
    V f_ = heff_dup(heff_rfield(v_z_244, 1));
    heff_room[0] = v_t_2443;
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2epublishGit_24s211231607x115039889_lam3, 1, 2, (V[]){v_z_244, v_z_245});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    heff_drop(v_err_249);
    heff_drop(v_t_2428);
    V v_s_2452 = v_out_2410;
    V v_t_2453 = (g_prelude_2eskipSpaces(v_s_2452, MK_INT(0LL), MK_INT(1LL)));
    int64_t v_t_2454 = (heff_unbox_word(heff_strLength_lent(v_s_2452, 0)) - ((int64_t)1ULL));
    V v_t_2455 = (g_prelude_2eskipSpaces(v_s_2452, heff_box_word(v_t_2454), MK_INT(-1LL)));
    V v_t_2456 = heff_strSlice(v_s_2452, v_t_2453, heff_intAdd(v_t_2455, MK_INT(1LL)));
    V v_x1_2457 = heff_bool(heff_strEq_c_lent(v_t_2456, ((V)&g_heff_2ebuild_2ecommands_2epublishGit_24s211231607x115039889_str12), 2));
    heff_drop(v_t_2456);
    if (!(heff_dup(v_x1_2457) == NTAG(TAG_True))) {
      heff_drop_rec(v_x_2425, 3);
      heff_drop(v_v_241);
      heff_drop(v_src_243);
      heff_drop(v_rep_240);
      heff_drop(v_pk_242);
      heff_drop(v_x1_2457);
      V v_t_2458 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2epublishGit_24s211231607x115039889_str13), NTAG(TAG_MkUnit)});
      V v_t_2459 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2458})});
      V v_t_2460 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2459})});
      V v_t_2461 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2460})});
      V v_t_2462 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2461})});
      V v_t_2463 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2462})});
      V v_t_2464 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2463})});
      V v_t_2465 = heff_tr(heff_call(heff_dup(heff_rfield(v_z_244, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2464})}));
      V f_ = heff_dup(heff_rfield(v_z_244, 1));
      heff_room[0] = v_t_2465;
      heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2epublishGit_24s211231607x115039889_lam4, 1, 2, (V[]){v_z_244, v_z_245});
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    } else {
      heff_drop(v_x1_2457);
      V v_t_2474 = heff_get_n(v_x_2425, 0, 3);
      V v_t_2477;
      switch (heff_tag_of(v_t_2474)) {
      case TAG_Exited: {
        V v_n_2475 = heff_field(v_t_2474, 0);
        heff_take_n(v_t_2474, 1ULL, 1);
        v_t_2477 = heff_bool(heff_intEq_c_lent(v_n_2475, MK_INT(0LL), 2));
        heff_drop(v_n_2475);
        break;
      }
      case TAG_Signalled: {
        heff_take_n(v_t_2474, 0ULL, 1);
        v_t_2477 = NTAG(TAG_False);
        break;
      }
      case TAG_TimedOut: {
        v_t_2477 = NTAG(TAG_False);
        break;
      }
      case TAG_NotRun: {
        v_t_2477 = NTAG(TAG_False);
        break;
      }
      default: heff_nomatch(v_t_2474);
      }
      if ((heff_dup(v_t_2477) == NTAG(TAG_True))) {
        heff_drop(v_src_243);
        heff_drop(v_rep_240);
        heff_drop(v_pk_242);
        heff_drop(v_t_2477);
        V v_t_2478 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2epublishGit_24s211231607x115039889_str14), heff_strAppend(v_v_241, ((V)&g_heff_2ebuild_2ecommands_2epublishGit_24s211231607x115039889_str15)));
        V v_t_2479 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2epublishGit_24s211231607x115039889_str16), v_t_2478), ((V)&g_heff_2ebuild_2ecommands_2epublishGit_24s211231607x115039889_str17));
        V v_t_2480 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2479, NTAG(TAG_MkUnit)});
        V v_t_2481 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2480})});
        V v_t_2482 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2481})});
        V v_t_2483 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2482})});
        V v_t_2484 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2483})});
        V v_t_2485 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2484})});
        V v_t_2486 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2485})});
        V v_t_2487 = heff_tr(heff_call(heff_dup(heff_rfield(v_z_244, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2486})}));
        V f_ = heff_dup(heff_rfield(v_z_244, 1));
        heff_room[0] = v_t_2487;
        heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2epublishGit_24s211231607x115039889_lam5, 1, 2, (V[]){v_z_244, v_z_245});
        if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
      } else {
        heff_drop(v_t_2477);
        V v_t_2496 = heff_tag_n(TAG_Cons, 2, (V[]){v_src_243, NTAG(TAG_Nil)});
        V v_c_2497 = (g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1606122519x1439074770(v_t_2496, NTAG(TAG_Nil)));
        V f_ = v_c_2497;
        heff_room[0] = heff_dup(v_z_244);
        heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2epublishGit_24s211231607x115039889_lam6, 1, 5, (V[]){v_rep_240, v_z_244, v_v_241, v_pk_242, v_z_245});
        if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
      }
    }
  }
}
V g_heff_2ebuild_2ecommands_2epublishGit_24s211231607x115039889_lam0(V self, V *args) {
  V v_x_247 = args[0];
  V v_v_241 = heff_env(self)[0];
  V v_z_244 = heff_env(self)[1];
  V v_z_245 = heff_env(self)[2];
  V v_src_243 = heff_env(self)[3];
  V v_rep_240 = heff_env(self)[4];
  V v_pk_242 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_ended_248 = heff_take_field(v_x_247, 0);
  V v_err_249 = heff_take_field(v_x_247, 2);
  V v_out_2410 = heff_get_n(v_x_247, 1, 3);
  V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2epublishGit_24s211231607x115039889_str3), heff_dup(v_v_241)), NTAG(TAG_Nil)});
  V v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2epublishGit_24s211231607x115039889_str4), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2epublishGit_24s211231607x115039889_str5), v_t_2411})});
  V v_t_2413 = ({ V b_0 = NTAG(TAG_Nil); V b_1 = NTAG(TAG_Nil); V r_ = (g_std_2epath_2esameSegments(b_0, b_1)); heff_drop(b_0); heff_drop(b_1); r_; });
  V v_t_2414;
  if ((heff_dup(v_t_2413) == NTAG(TAG_True))) {
    heff_drop(v_t_2413);
    v_t_2414 = ((V)&g_heff_2ebuild_2ecommands_2epublishGit_24s211231607x115039889_str6);
  } else {
    heff_drop(v_t_2413);
    v_t_2414 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V b_1 = heff_dup(g_std_2epath_2ecurrent_get()); V r_ = (g_std_2epath_2erender(b_0, b_1)); heff_drop(b_0); heff_drop(b_1); r_; });
  }
  V v_t_2415 = heff_rec_n(10, shape_command__args__dir__env__input__output__errors__timeout__keep__group, (V[]){((V)&g_heff_2ebuild_2ecommands_2epublishGit_24s211231607x115039889_str7), heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2epublishGit_24s211231607x115039889_str8), v_t_2412}), v_t_2414, NTAG(TAG_Nil), NTAG(TAG_NoInput), NTAG(TAG_Collected), NTAG(TAG_Collected), MK_INT(0LL), MK_INT(0LL), NTAG(TAG_False)});
  V v_a_2417 = heff_tag_n(TAG_Run, 2, (V[]){v_t_2415, ((V)&g_heff_2ebuild_2ecommands_2epublishGit_24s211231607x115039889_lam1_clo)});
  V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2417})});
  V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
  V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
  V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
  V v_t_2423 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2422})});
  V v_t_2424 = heff_tr(heff_call(heff_dup(heff_rfield(v_z_244, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2423})}));
  V f_ = heff_dup(heff_rfield(v_z_244, 1));
  heff_room[0] = v_t_2424;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2epublishGit_24s211231607x115039889_lam2, 1, 9, (V[]){v_ended_248, v_err_249, v_z_244, v_z_245, v_out_2410, v_v_241, v_src_243, v_rep_240, v_pk_242});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishCmd_24s581473772x1366906885_str0, 10, "package.hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishCmd_24s581473772x1366906885_str1, 64, "heff publish: no package.hf here: publish at the project's root\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishCmd_24s581473772x1366906885_str2, 10, "package.hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishCmd_24s581473772x1366906885_str3, 4, "heff");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishCmd_24s581473772x1366906885_str4, 39, "heff publish: package.hf does not read\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishCmd_24s581473772x1366906885_str5, 57, "heff publish: package.hf is no Package (lib/manifest.hf)\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishCmd_24s581473772x1366906885_str6, 57, "heff publish: package.hf is no Package (lib/manifest.hf)\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishCmd_24s581473772x1366906885_str7, 1, "`");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishCmd_24s581473772x1366906885_str8, 22, "` is no version: a.b.c");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishCmd_24s581473772x1366906885_str9, 14, "heff publish: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epublishCmd_24s581473772x1366906885_str10, 1, "\012");
V g_heff_2ebuild_2ecommands_2epublishCmd_24s581473772x1366906885_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2epublishCmd_24s581473772x1366906885_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2epublishCmd_24s581473772x1366906885_lam0, 3, 0};
V g_heff_2ebuild_2ecommands_2epublishCmd_24s581473772x1366906885_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2epublishCmd_24s581473772x1366906885_lam8(V self, V *args);
V g_heff_2ebuild_2ecommands_2epublishCmd_24s581473772x1366906885_lam9(V self, V *args);
V g_heff_2ebuild_2ecommands_2epublishCmd_24s581473772x1366906885_lam10(V self, V *args);
V g_heff_2ebuild_2ecommands_2epublishCmd_24s581473772x1366906885_lam7(V self, V *args);
V g_heff_2ebuild_2ecommands_2epublishCmd_24s581473772x1366906885_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2epublishCmd_24s581473772x1366906885_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2epublishCmd_24s581473772x1366906885_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2epublishCmd_24s581473772x1366906885_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2epublishCmd_24s581473772x1366906885_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2epublishCmd_24s581473772x1366906885_lam12(V self, V *args);
V g_heff_2ebuild_2ecommands_2epublishCmd_24s581473772x1366906885_lam11(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2epublishCmd_24s581473772x1366906885_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2epublishCmd_24s581473772x1366906885_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2epublishCmd_24s581473772x1366906885(V v_rep_240, V v_v_241) {
top: ;
  HeffT2 v_t_242 = (g_heff_2ebuild_2eproject_2eversion_24cpr(v_v_241));
  {
    V v_field_244 = v_t_242.f[1];
    int64_t v_tag_243 = ((int64_t)v_t_242.f[0]);
    if ((v_tag_243 == ((int64_t)0ULL))) {
      V v_x_245 = v_field_244;
      heff_drop(v_x_245);
      V v_path_246 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = ((V)&g_heff_2ebuild_2ecommands_2epublishCmd_24s581473772x1366906885_str0); V r_ = (g_std_2epath_2eparse(b_0, a_1)); heff_drop(b_0); r_; });
      V v_c_247 = ({ V a_0 = v_path_246; V r_ = (g_std_2efilesystem_2ereadFile_24s2092922012x215966209(a_0)); heff_drop(v_path_246); r_; });
      V v_c_2411 = heff_tr(heff_call(v_c_247, 2, (V[]){heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), ((V)&g_heff_2ebuild_2ecommands_2epublishCmd_24s581473772x1366906885_lam0_clo)}));
      return heff_clo_n(g_heff_2ebuild_2ecommands_2epublishCmd_24s581473772x1366906885_lam1, 2, 3, (V[]){v_c_2411, v_rep_240, v_v_241});
    } else {
      heff_drop(v_rep_240);
      heff_drop(v_field_244);
      return heff_clo_n(g_heff_2ebuild_2ecommands_2epublishCmd_24s581473772x1366906885_lam11, 2, 1, (V[]){v_v_241});
    }
  }
}
V g_heff_2ebuild_2ecommands_2epublishCmd_24s581473772x1366906885_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2epublishCmd_24s581473772x1366906885(a[0], a[1]);
}
V g_heff_2ebuild_2ecommands_2epublishCmd_24s581473772x1366906885_lam0(V self, V *args) {
  V v_x_248 = args[0];
  V v_hd_249 = args[1];
  V v_k_2410 = args[2];
  heff_drop(v_hd_249);
  V f_ = v_k_2410;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_248});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2epublishCmd_24s581473772x1366906885_lam3(V self, V *args) {
  V v_x_2424 = args[0];
  V v_hd_2412 = heff_env(self)[0];
  V v_k_2413 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2424);
  V v_t_2425 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2425})});
  V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
  V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
  V v_t_2429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
  V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
  V v_t_2431 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2430})});
  return (g_co_2eop_24s615738393x1686646143(heff_tag_n(TAG_InR, 1, (V[]){v_t_2431}), v_hd_2412, v_k_2413));
}
V g_heff_2ebuild_2ecommands_2epublishCmd_24s581473772x1366906885_lam8(V self, V *args) {
  V v_x_2450 = args[0];
  V v_hd_2412 = heff_env(self)[0];
  V v_k_2413 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2450);
  V v_t_2451 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2452 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2451})});
  V v_t_2453 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2452})});
  V v_t_2454 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2453})});
  V v_t_2455 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2454})});
  V v_t_2456 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2455})});
  V v_t_2457 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2456})});
  return (g_co_2eop_24s615738393x1686646143(heff_tag_n(TAG_InR, 1, (V[]){v_t_2457}), v_hd_2412, v_k_2413));
}
V g_heff_2ebuild_2ecommands_2epublishCmd_24s581473772x1366906885_lam9(V self, V *args) {
  V v_x_2467 = args[0];
  V v_hd_2412 = heff_env(self)[0];
  V v_k_2413 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2467);
  V v_t_2468 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2469 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2468})});
  V v_t_2470 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2469})});
  V v_t_2471 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2470})});
  V v_t_2472 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2471})});
  V v_t_2473 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2472})});
  V v_t_2474 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2473})});
  return (g_co_2eop_24s615738393x1686646143(heff_tag_n(TAG_InR, 1, (V[]){v_t_2474}), v_hd_2412, v_k_2413));
}
V g_heff_2ebuild_2ecommands_2epublishCmd_24s581473772x1366906885_lam10(V self, V *args) {
  V v_x_2484 = args[0];
  V v_hd_2412 = heff_env(self)[0];
  V v_k_2413 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2484);
  V v_t_2485 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2486 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2485})});
  V v_t_2487 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2486})});
  V v_t_2488 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2487})});
  V v_t_2489 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2488})});
  V v_t_2490 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2489})});
  V v_t_2491 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2490})});
  return (g_co_2eop_24s615738393x1686646143(heff_tag_n(TAG_InR, 1, (V[]){v_t_2491}), v_hd_2412, v_k_2413));
}
V g_heff_2ebuild_2ecommands_2epublishCmd_24s581473772x1366906885_lam7(V self, V *args) {
  V v_x_2440 = args[0];
  V v_x_2434 = heff_env(self)[0];
  V v_hd_2412 = heff_env(self)[1];
  V v_k_2413 = heff_env(self)[2];
  V v_x_2435 = heff_env(self)[3];
  V v_cs_2438 = heff_env(self)[4];
  V v_rep_240 = heff_env(self)[5];
  V v_v_241 = heff_env(self)[6];
  heff_clo_take(self, 7);
  heff_drop(v_x_2440);
  V v_t_2441 = heff_dup(heff_rfield(v_x_2434, 3));
  switch (heff_tag_of(v_t_2441)) {
  case TAG_Nothing: {
    heff_drop_rec(v_x_2434, 5);
    heff_drop(v_x_2435);
    heff_drop(v_cs_2438);
    heff_drop(v_rep_240);
    heff_drop(v_v_241);
    V v_t_2442 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2epublishCmd_24s581473772x1366906885_str4), NTAG(TAG_MkUnit)});
    V v_t_2443 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2442})});
    V v_t_2444 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2443})});
    V v_t_2445 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2444})});
    V v_t_2446 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2445})});
    V v_t_2447 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2446})});
    V v_t_2448 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2447})});
    V v_t_2449 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_2412, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2448})}));
    V f_ = heff_dup(heff_rfield(v_hd_2412, 1));
    heff_room[0] = v_t_2449;
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2epublishCmd_24s581473772x1366906885_lam8, 1, 2, (V[]){v_hd_2412, v_k_2413});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_Just: {
    V v_pk_2458 = heff_field(v_t_2441, 0);
    V v_ru_24t_2441_24Just = heff_take_reuse_n(v_t_2441, 1ULL, 1);
    if (heff_intLt_c(MK_INT(0LL), v_x_2435)) {
      heff_drop_rec(v_x_2434, 5);
      heff_drop(v_cs_2438);
      heff_drop(v_rep_240);
      heff_drop(v_v_241);
      heff_drop(v_pk_2458);
      V v_t_2459 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2epublishCmd_24s581473772x1366906885_str5), NTAG(TAG_MkUnit)});
      V v_t_2460 = heff_tag_at_n(v_ru_24t_2441_24Just, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2459})});
      V v_t_2461 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2460})});
      V v_t_2462 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2461})});
      V v_t_2463 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2462})});
      V v_t_2464 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2463})});
      V v_t_2465 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2464})});
      V v_t_2466 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_2412, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2465})}));
      V f_ = heff_dup(heff_rfield(v_hd_2412, 1));
      heff_room[0] = v_t_2466;
      heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2epublishCmd_24s581473772x1366906885_lam9, 1, 2, (V[]){v_hd_2412, v_k_2413});
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    } else {
      V v_t_2475 = ({ V a_0 = v_cs_2438; V r_ = (g_list_2eany_24s1740858080x874135214(a_0)); heff_drop(v_cs_2438); r_; });
      if ((heff_dup(v_t_2475) == NTAG(TAG_True))) {
        heff_drop_rec(v_x_2434, 5);
        heff_drop(v_rep_240);
        heff_drop(v_v_241);
        heff_drop(v_pk_2458);
        heff_drop(v_t_2475);
        V v_t_2476 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2epublishCmd_24s581473772x1366906885_str6), NTAG(TAG_MkUnit)});
        V v_t_2477 = heff_tag_at_n(v_ru_24t_2441_24Just, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2476})});
        V v_t_2478 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2477})});
        V v_t_2479 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2478})});
        V v_t_2480 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2479})});
        V v_t_2481 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2480})});
        V v_t_2482 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2481})});
        V v_t_2483 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_2412, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2482})}));
        V f_ = heff_dup(heff_rfield(v_hd_2412, 1));
        heff_room[0] = v_t_2483;
        heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2epublishCmd_24s581473772x1366906885_lam10, 1, 2, (V[]){v_hd_2412, v_k_2413});
        if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
      } else {
        heff_drop_cell(v_ru_24t_2441_24Just, 1);
        heff_drop(v_t_2475);
        return (g_heff_2ebuild_2ecommands_2epublishChecked_24s922680055x1348891372(v_rep_240, v_v_241, v_x_2434, v_pk_2458, v_hd_2412, v_k_2413));
      }
    }
  }
  default: return heff_nomatch(v_t_2441);
  }
}
V g_heff_2ebuild_2ecommands_2epublishCmd_24s581473772x1366906885_lam6(V self, V *args) {
  V v_x_2437 = args[0];
  V v_rep_240 = heff_env(self)[0];
  V v_hd_2412 = heff_env(self)[1];
  V v_x_2434 = heff_env(self)[2];
  V v_k_2413 = heff_env(self)[3];
  V v_x_2435 = heff_env(self)[4];
  V v_v_241 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_cs_2438 = heff_get_n(v_x_2437, 0, 2);
  V v_c_2439 = (g_heff_2ebuild_2ecommands_2eputFileDiags_24s415097226x198460927(heff_dup(v_rep_240), heff_dup(v_cs_2438)));
  V f_ = v_c_2439;
  heff_room[0] = heff_dup(v_hd_2412);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2epublishCmd_24s581473772x1366906885_lam7, 1, 7, (V[]){v_x_2434, v_hd_2412, v_k_2413, v_x_2435, v_cs_2438, v_rep_240, v_v_241});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2epublishCmd_24s581473772x1366906885_lam5(V self, V *args) {
  V v_x_2435 = args[0];
  V v_x_2434 = heff_env(self)[0];
  V v_hd_2412 = heff_env(self)[1];
  V v_rep_240 = heff_env(self)[2];
  V v_k_2413 = heff_env(self)[3];
  V v_v_241 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_c_2436 = (g_heff_2ebuild_2esession_2ecachedAcc_24s1827793511x304312721(heff_dup(v_x_2434)));
  V f_ = v_c_2436;
  heff_room[0] = heff_dup(v_hd_2412);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2epublishCmd_24s581473772x1366906885_lam6, 1, 6, (V[]){v_rep_240, v_hd_2412, v_x_2434, v_k_2413, v_x_2435, v_v_241});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2epublishCmd_24s581473772x1366906885_lam4(V self, V *args) {
  V v_x_2434 = args[0];
  V v_hd_2412 = heff_env(self)[0];
  V v_rep_240 = heff_env(self)[1];
  V v_k_2413 = heff_env(self)[2];
  V v_v_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2ebuild_2ecommands_2eprintErrs_24s115117455x797094904(((V)&g_heff_2ebuild_2ecommands_2epublishCmd_24s581473772x1366906885_str3), heff_dup(heff_rfield(v_x_2434, 1)), MK_INT(0LL), heff_dup(v_hd_2412), heff_clo_n(g_heff_2ebuild_2ecommands_2epublishCmd_24s581473772x1366906885_lam5, 1, 5, (V[]){v_x_2434, v_hd_2412, v_rep_240, v_k_2413, v_v_241})));
}
V g_heff_2ebuild_2ecommands_2epublishCmd_24s581473772x1366906885_lam2(V self, V *args) {
  V v_x_2414 = args[0];
  V v_hd_2412 = heff_env(self)[0];
  V v_k_2413 = heff_env(self)[1];
  V v_rep_240 = heff_env(self)[2];
  V v_v_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  switch (heff_tag_of(v_x_2414)) {
  case TAG_Left: {
    V v_ru_24x_2414_24Left = heff_take_reuse_n(v_x_2414, 0ULL, 1);
    heff_drop(v_rep_240);
    heff_drop(v_v_241);
    V v_t_2416 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2epublishCmd_24s581473772x1366906885_str1), NTAG(TAG_MkUnit)});
    V v_t_2417 = heff_tag_at_n(v_ru_24x_2414_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
    V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
    V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
    V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
    V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
    V v_t_2422 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2421})});
    V v_t_2423 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_2412, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2422})}));
    V f_ = heff_dup(heff_rfield(v_hd_2412, 1));
    heff_room[0] = v_t_2423;
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2epublishCmd_24s581473772x1366906885_lam3, 1, 2, (V[]){v_hd_2412, v_k_2413});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_Right: {
    heff_take_n(v_x_2414, 0ULL, 1);
    V v_c_2433 = (g_heff_2ebuild_2ecommands_2eload_24s1410275656x228048283(((V)&g_heff_2ebuild_2ecommands_2epublishCmd_24s581473772x1366906885_str2)));
    V f_ = v_c_2433;
    heff_room[0] = heff_dup(v_hd_2412);
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2epublishCmd_24s581473772x1366906885_lam4, 1, 4, (V[]){v_hd_2412, v_rep_240, v_k_2413, v_v_241});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_x_2414);
  }
}
V g_heff_2ebuild_2ecommands_2epublishCmd_24s581473772x1366906885_lam1(V self, V *args) {
  V v_hd_2412 = args[0];
  V v_k_2413 = args[1];
  V v_c_2411 = heff_env(self)[0];
  V v_rep_240 = heff_env(self)[1];
  V v_v_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_2411;
  args[0] = heff_dup(v_hd_2412);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2epublishCmd_24s581473772x1366906885_lam2, 1, 4, (V[]){v_hd_2412, v_k_2413, v_rep_240, v_v_241});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2ecommands_2epublishCmd_24s581473772x1366906885_lam12(V self, V *args) {
  V v_x_24104 = args[0];
  V v_hd_2492 = heff_env(self)[0];
  V v_k_2493 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_24104);
  V v_t_24105 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_24106 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24105})});
  V v_t_24107 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24106})});
  V v_t_24108 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24107})});
  V v_t_24109 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24108})});
  V v_t_24110 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24109})});
  V v_t_24111 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24110})});
  return (g_co_2eop_24s615738393x1686646143(heff_tag_n(TAG_InR, 1, (V[]){v_t_24111}), v_hd_2492, v_k_2493));
}
V g_heff_2ebuild_2ecommands_2epublishCmd_24s581473772x1366906885_lam11(V self, V *args) {
  V v_hd_2492 = args[0];
  V v_k_2493 = args[1];
  V v_v_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2494 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2epublishCmd_24s581473772x1366906885_str7), heff_strAppend(v_v_241, ((V)&g_heff_2ebuild_2ecommands_2epublishCmd_24s581473772x1366906885_str8)));
  V v_t_2495 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2epublishCmd_24s581473772x1366906885_str9), v_t_2494), ((V)&g_heff_2ebuild_2ecommands_2epublishCmd_24s581473772x1366906885_str10));
  V v_t_2496 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2495, NTAG(TAG_MkUnit)});
  V v_t_2497 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2496})});
  V v_t_2498 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2497})});
  V v_t_2499 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2498})});
  V v_t_24100 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2499})});
  V v_t_24101 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_24100})});
  V v_t_24102 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24101})});
  V v_t_24103 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_2492, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24102})}));
  V f_ = heff_dup(heff_rfield(v_hd_2492, 1));
  args[0] = v_t_24103;
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2epublishCmd_24s581473772x1366906885_lam12, 1, 2, (V[]){v_hd_2492, v_k_2493});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprintEvals_24s906160764x145037181_str0, 3, " = ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprintEvals_24s906160764x145037181_str1, 1, "\012");
V g_heff_2ebuild_2ecommands_2eprintEvals_24s906160764x145037181_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2eprintEvals_24s906160764x145037181_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eprintEvals_24s906160764x145037181_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eprintEvals_24s906160764x145037181_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2eprintEvals_24s906160764x145037181(V v_x1_240, V v_p_241, V v_p_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop_rec(v_p_241, 3);
    return heff_tail(v_p_242, 1, (V[]){NTAG(TAG_False)});
  }
  case TAG_Cons: {
    V v_d_243 = heff_field(v_x1_240, 0);
    V v_rest_244 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_name_245 = heff_take_field(v_d_243, 0);
    V v_value_246 = heff_take_field(v_d_243, 1);
    V v_bug_247 = heff_get_n(v_d_243, 2, 3);
    V v_t_248 = heff_strAppend(v_name_245, heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eprintEvals_24s906160764x145037181_str0), v_value_246));
    V v_t_249 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Write, 2, (V[]){heff_strAppend(v_t_248, ((V)&g_heff_2ebuild_2ecommands_2eprintEvals_24s906160764x145037181_str1)), NTAG(TAG_MkUnit)});
    V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
    V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
    V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
    V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
    V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
    V v_t_2415 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2414})});
    V v_t_2416 = heff_tr(heff_call(heff_dup(heff_rfield(v_p_241, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2415})}));
    return heff_tail(heff_dup(heff_rfield(v_p_241, 1)), 2, (V[]){v_t_2416, heff_clo_n(g_heff_2ebuild_2ecommands_2eprintEvals_24s906160764x145037181_lam0, 1, 4, (V[]){v_rest_244, v_p_241, v_bug_247, v_p_242})});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2ecommands_2eprintEvals_24s906160764x145037181_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eprintEvals_24s906160764x145037181(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2ecommands_2eprintEvals_24s906160764x145037181_lam1(V self, V *args) {
  V v_x_2418 = args[0];
  V v_bug_247 = heff_env(self)[0];
  V v_p_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2419 = heff_bool(((heff_dup(v_bug_247) == NTAG(TAG_True)) || (heff_dup(v_x_2418) == NTAG(TAG_True))));
  heff_drop(v_x_2418);
  heff_drop(v_bug_247);
  V f_ = v_p_242;
  args[0] = v_t_2419;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eprintEvals_24s906160764x145037181_lam0(V self, V *args) {
  V v_x_2417 = args[0];
  V v_rest_244 = heff_env(self)[0];
  V v_p_241 = heff_env(self)[1];
  V v_bug_247 = heff_env(self)[2];
  V v_p_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2417);
  return (g_heff_2ebuild_2ecommands_2eprintEvals_24s906160764x145037181(v_rest_244, v_p_241, heff_clo_n(g_heff_2ebuild_2ecommands_2eprintEvals_24s906160764x145037181_lam1, 1, 2, (V[]){v_bug_247, v_p_242})));
}