// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_Exited 20560
#define TAG_Left 13886
#define TAG_MakeDirectory 16793
#define TAG_NotRun 12703
#define TAG_Platform 55558
#define TAG_Posix 44191
#define TAG_ProgramPath 46819
#define TAG_ReadDirectory 46629
#define TAG_ReadFile 6783
#define TAG_Right 62770
#define TAG_RunUnder 28888
#define TAG_Signalled 34337
#define TAG_Start 63542
#define TAG_Throw 56084
#define TAG_TimedOut 6056
#define TAG_Windows 49101
#define TAG_Write 36323
#define TAG_WriteErr 37283
#define TAG_WriteFile 62589
#define LBL_bind 9519364
#define LBL_bug 307438
#define LBL_c 317
#define LBL_copies 592412158
#define LBL_diags 296935042
#define LBL_emits 297985818
#define LBL_ended 298010324
#define LBL_err 310239
#define LBL_errors 652506774
#define LBL_globals 352931696
#define LBL_groups 709681407
#define LBL_jss 315076
#define LBL_malg 9839318
#define LBL_mods 9852536
#define LBL_module 878357911
#define LBL_modules 1459291593
#define LBL_msg 317947
#define LBL_name 9869138
#define LBL_olds 9909235
#define LBL_parts 307795706
#define LBL_path 9928940
#define LBL_paths 307797256
#define LBL_root 10001833
#define LBL_shipTo 1043811586
#define LBL_source 1050636102
#define LBL_style 311138763
#define LBL_top 324559
#define LBL_value 313331083
#define LBL_zig 330130
static uint32_t shape_c__zig[] = {LBL_c, LBL_zig};
static uint32_t shape_groups__copies__emits__jss[] = {LBL_groups, LBL_copies, LBL_emits, LBL_jss};
static uint32_t shape_mods__olds[] = {LBL_mods, LBL_olds};
V g_co_2eop_24s1178127530x1610393171(V, V, V, V, V, V, V, V);
V g_co_2eop_24s1178127530x1610393171_entry(V self, V *a);
extern Clo g_co_2eop_24s1178127530x1610393171_clo;
V g_co_2eop_24s1398690846x1918384825(V, V, V);
V g_co_2eop_24s1398690846x1918384825_entry(V self, V *a);
extern Clo g_co_2eop_24s1398690846x1918384825_clo;
V g_co_2eop_24s1531911654x724325922(V, V, V);
V g_co_2eop_24s1531911654x724325922_entry(V self, V *a);
extern Clo g_co_2eop_24s1531911654x724325922_clo;
V g_co_2eop_24s1998166633x1971890408(V);
V g_co_2eop_24s1998166633x1971890408_entry(V self, V *a);
extern Clo g_co_2eop_24s1998166633x1971890408_clo;
V g_co_2eop_24s40508559x1835373952(V, V, V);
V g_co_2eop_24s40508559x1835373952_entry(V self, V *a);
extern Clo g_co_2eop_24s40508559x1835373952_clo;
V g_co_2eop_24s40508559x1835373952_24tok1(V, V, V, V);
V g_co_2eop_24s40508559x1835373952_24tok1_entry(V self, V *a);
extern Clo g_co_2eop_24s40508559x1835373952_24tok1_clo;
V g_co_2eop_24s40508559x1835373952_24tok2(V, V, V, V);
V g_co_2eop_24s40508559x1835373952_24tok2_entry(V self, V *a);
extern Clo g_co_2eop_24s40508559x1835373952_24tok2_clo;
V g_co_2eop_24s907744994x1234676051(V, V);
V g_co_2eop_24s907744994x1234676051_entry(V self, V *a);
extern Clo g_co_2eop_24s907744994x1234676051_clo;
V g_co_2eop_24s91617614x2132230022(V, V, V, V);
V g_co_2eop_24s91617614x2132230022_entry(V self, V *a);
extern Clo g_co_2eop_24s91617614x2132230022_clo;
V g_exception_2eattempted_24s85350750x49672201_get(void);
V g_heff_2ebuild_2ebackcache_2ebackTexts(V, V, V);
V g_heff_2ebuild_2ebackcache_2ebackTexts_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ebackcache_2ebackTexts_clo;
V g_heff_2ebuild_2ecommands_2ebackDirOf(V);
V g_heff_2ebuild_2ecommands_2ebackDirOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ebackDirOf_clo;
V g_heff_2ebuild_2ecommands_2ebuildEach_24s424977173x2143394812(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ebuildEach_24s424977173x2143394812_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ebuildEach_24s424977173x2143394812_clo;
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s218921097x875862419(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s218921097x875862419_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ebuildPrograms_24s218921097x875862419_clo;
V g_heff_2ebuild_2ecommands_2ecompileFoundC_24s635295480x634262112(V, V, V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecompileFoundC_24s635295480x634262112_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecompileFoundC_24s635295480x634262112_clo;
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s411846885x505187560(V, V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s411846885x505187560_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecompileLastC_24s411846885x505187560_clo;
V g_heff_2ebuild_2ecommands_2ediagCount_24s823746706x1248851912(V);
V g_heff_2ebuild_2ecommands_2ediagCount_24s823746706x1248851912_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ediagCount_24s823746706x1248851912_clo;
V g_heff_2ebuild_2ecommands_2eemitErrs_24s394189364x2134712221(V, V, V);
V g_heff_2ebuild_2ecommands_2eemitErrs_24s394189364x2134712221_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eemitErrs_24s394189364x2134712221_clo;
V g_heff_2ebuild_2ecommands_2eemitErrs_24s394189364x2134712221_24tok1(V, V, V, V);
V g_heff_2ebuild_2ecommands_2eemitErrs_24s394189364x2134712221_24tok1_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eemitErrs_24s394189364x2134712221_24tok1_clo;
V g_heff_2ebuild_2ecommands_2eemitErrs_24s394189364x2134712221_24tok2(V, V, V, V);
V g_heff_2ebuild_2ecommands_2eemitErrs_24s394189364x2134712221_24tok2_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eemitErrs_24s394189364x2134712221_24tok2_clo;
HeffT2 g_heff_2ebuild_2ecommands_2efirstErrorOf_24cpr(V);
V g_heff_2ebuild_2ecommands_2eimportsOn_24acc(V, V);
V g_heff_2ebuild_2ecommands_2eimportsOn_24acc_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eimportsOn_24acc_clo;
V g_heff_2ebuild_2ecommands_2ekeptWritten_24s1204008192x1571756415(V, V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ekeptWritten_24s1204008192x1571756415_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ekeptWritten_24s1204008192x1571756415_clo;
V g_heff_2ebuild_2ecommands_2enubStrGo(V, V);
V g_heff_2ebuild_2ecommands_2enubStrGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2enubStrGo_clo;
V g_heff_2ebuild_2ecommands_2epartsDir(V, V, V);
V g_heff_2ebuild_2ecommands_2epartsDir_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2epartsDir_clo;
V g_heff_2ebuild_2ecommands_2eplaceIn_24s883176411x318999417(V, V, V, V);
V g_heff_2ebuild_2ecommands_2eplaceIn_24s883176411x318999417_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eplaceIn_24s883176411x318999417_clo;
V g_heff_2ebuild_2ecommands_2eprintErrs_24s115117455x797094904(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eprintErrs_24s115117455x797094904_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprintErrs_24s115117455x797094904_clo;
V g_heff_2ebuild_2ecommands_2eprintEvals_24s906160764x145037181(V, V, V);
V g_heff_2ebuild_2ecommands_2eprintEvals_24s906160764x145037181_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprintEvals_24s906160764x145037181_clo;
V g_heff_2ebuild_2ecommands_2eprovidesLeafC(V, V);
V g_heff_2ebuild_2ecommands_2eprovidesLeafC_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprovidesLeafC_clo;
V g_heff_2ebuild_2ecommands_2ereadProvidersC_24s1269697684x380235586(V, V);
V g_heff_2ebuild_2ecommands_2ereadProvidersC_24s1269697684x380235586_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ereadProvidersC_24s1269697684x380235586_clo;
V g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s1290075703x1224649709(V, V, V);
V g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s1290075703x1224649709_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s1290075703x1224649709_clo;
V g_heff_2ebuild_2ecommands_2eremoveStale_24s1076505188x1773366585(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eremoveStale_24s1076505188x1773366585_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eremoveStale_24s1076505188x1773366585_clo;
V g_heff_2ebuild_2ecommands_2eselfFrom_24s176185486x602532917(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eselfFrom_24s176185486x602532917_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eselfFrom_24s176185486x602532917_clo;
V g_heff_2ebuild_2ecommands_2eselfHash_24s2023922332x1057539294(V, V, V);
V g_heff_2ebuild_2ecommands_2eselfHash_24s2023922332x1057539294_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eselfHash_24s2023922332x1057539294_clo;
V g_heff_2ebuild_2ecommands_2eselfPath_24s1432537356x1686629462(V, V);
V g_heff_2ebuild_2ecommands_2eselfPath_24s1432537356x1686629462_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eselfPath_24s1432537356x1686629462_clo;
V g_heff_2ebuild_2ecommands_2eshipAll_24s1159606914x1992617477(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eshipAll_24s1159606914x1992617477_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eshipAll_24s1159606914x1992617477_clo;
V g_heff_2ebuild_2ecommands_2esystemOnly_24s454269400x904232931(V, V);
V g_heff_2ebuild_2ecommands_2esystemOnly_24s454269400x904232931_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2esystemOnly_24s454269400x904232931_clo;
V g_heff_2ebuild_2ecommands_2ewriteBacks_24s1039561216x639698839(V, V, V);
V g_heff_2ebuild_2ecommands_2ewriteBacks_24s1039561216x639698839_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ewriteBacks_24s1039561216x639698839_clo;
V g_heff_2ebuild_2ecommands_2ewriteOut_24s1442511881x314947241(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ewriteOut_24s1442511881x314947241_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ewriteOut_24s1442511881x314947241_clo;
V g_heff_2ebuild_2ecommands_2ewriteOutC_24s1877451407x355012956(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ewriteOutC_24s1877451407x355012956_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ewriteOutC_24s1877451407x355012956_clo;
V g_heff_2ebuild_2ecommands_2ewriteParts_24s1069210723x719436499(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ewriteParts_24s1069210723x719436499_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ewriteParts_24s1069210723x719436499_clo;
V g_heff_2ebuild_2ecommands_2ewritePartsGo_24s2124042284x1735199047(V, V, V, V);
V g_heff_2ebuild_2ecommands_2ewritePartsGo_24s2124042284x1735199047_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ewritePartsGo_24s2124042284x1735199047_clo;
V g_heff_2ebuild_2ecommands_2ezigObjects_24s1218369498x1750867255(V, V, V, V);
V g_heff_2ebuild_2ecommands_2ezigObjects_24s1218369498x1750867255_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ezigObjects_24s1218369498x1750867255_clo;
V g_heff_2ebuild_2edriver_2ecandLeaves(V);
V g_heff_2ebuild_2edriver_2ecandLeaves_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ecandLeaves_clo;
V g_heff_2ebuild_2edriver_2ecandidatesOf(V);
V g_heff_2ebuild_2edriver_2ecandidatesOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ecandidatesOf_clo;
HeffT2 g_heff_2ebuild_2edriver_2elastChecked_24cpr(V);
V g_heff_2ebuild_2edriver_2enubStrD(V);
V g_heff_2ebuild_2edriver_2enubStrD_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2enubStrD_clo;
V g_heff_2ecompile_2eemit_2ecatMaybesL(V);
V g_heff_2ecompile_2eemit_2ecatMaybesL_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemit_2ecatMaybesL_clo;
HeffT2 g_heff_2ecompile_2eglue_2eeithers_24cpr(V);
V g_heff_2ecompile_2eglue_2ejusts(V);
V g_heff_2ecompile_2eglue_2ejusts_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eglue_2ejusts_clo;
V g_heff_2elsp_2erender_2ediagWhere(V, V, V);
V g_heff_2elsp_2erender_2ediagWhere_entry(V self, V *a);
extern Clo g_heff_2elsp_2erender_2ediagWhere_clo;
V g_heff_2elsp_2erender_2eprtCode(V);
V g_heff_2elsp_2erender_2eprtCode_entry(V self, V *a);
extern Clo g_heff_2elsp_2erender_2eprtCode_clo;
V g_list_2efoldl_24f1425140065x1254143828(V, V, V, V);
V g_list_2efoldl_24f1425140065x1254143828_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1425140065x1254143828_clo;
V g_list_2efoldl_24f2094160282x1876485468(V, V, V);
V g_list_2efoldl_24f2094160282x1876485468_entry(V self, V *a);
extern Clo g_list_2efoldl_24f2094160282x1876485468_clo;
V g_list_2efoldl_24s1325969685x576913065(V, V);
V g_list_2efoldl_24s1325969685x576913065_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1325969685x576913065_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1614667250x430274379(V, V);
V g_list_2efoldl_24s1614667250x430274379_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1614667250x430274379_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2efoldl_24s744304057x1932700078(V, V);
V g_list_2efoldl_24s744304057x1932700078_entry(V self, V *a);
extern Clo g_list_2efoldl_24s744304057x1932700078_clo;
V g_list_2ekeepIf_24s1161549307x1906011635(V);
V g_list_2ekeepIf_24s1161549307x1906011635_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1161549307x1906011635_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1435185561x202019164(V);
V g_list_2emap_24s1435185561x202019164_entry(V self, V *a);
extern Clo g_list_2emap_24s1435185561x202019164_clo;
V g_list_2emap_24s164225955x66209884(V, V, V);
V g_list_2emap_24s164225955x66209884_entry(V self, V *a);
extern Clo g_list_2emap_24s164225955x66209884_clo;
V g_list_2emap_24s219049803x1458391381(V);
V g_list_2emap_24s219049803x1458391381_entry(V self, V *a);
extern Clo g_list_2emap_24s219049803x1458391381_clo;
V g_list_2emap_24s328934344x1728860012(V, V);
V g_list_2emap_24s328934344x1728860012_entry(V self, V *a);
extern Clo g_list_2emap_24s328934344x1728860012_clo;
V g_list_2emap_24s649333309x1802289391(V);
V g_list_2emap_24s649333309x1802289391_entry(V self, V *a);
extern Clo g_list_2emap_24s649333309x1802289391_clo;
V g_list_2emap_24s803586165x1676441765(V, V, V, V, V, V, V);
V g_list_2emap_24s803586165x1676441765_entry(V self, V *a);
extern Clo g_list_2emap_24s803586165x1676441765_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_prelude_2esplitFrom(V, V, V, V, V);
V g_prelude_2esplitFrom_entry(V self, V *a);
extern Clo g_prelude_2esplitFrom_clo;
V g_std_2eordmap_2eempty_get(void);
V g_std_2eordmap_2einsert_24s615484302x989744458(V, V, V);
V g_std_2eordmap_2einsert_24s615484302x989744458_entry(V self, V *a);
extern Clo g_std_2eordmap_2einsert_24s615484302x989744458_clo;
V g_std_2epath_2ejoin(V, V);
V g_std_2epath_2ejoin_entry(V self, V *a);
extern Clo g_std_2epath_2ejoin_clo;
V g_std_2epath_2enative_get(void);
V g_std_2epath_2eparse(V, V);
V g_std_2epath_2eparse_entry(V self, V *a);
extern Clo g_std_2epath_2eparse_clo;
V g_std_2epath_2erender(V, V);
V g_std_2epath_2erender_entry(V self, V *a);
extern Clo g_std_2epath_2erender_clo;
V g_std_2eprogress_2eroot_get(void);
HEFF_LIT(g_heff_2ebuild_2ecommands_2eimportsOn_24acc_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eimportsOn_24acc_str1, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eimportsOn_24acc_str2, 10, "imports it");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eimportsOn_24acc_str3, 9, "imports `");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eimportsOn_24acc_str4, 9, "`, which ");
Clo g_heff_2ebuild_2ecommands_2eimportsOn_24acc_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eimportsOn_24acc_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2eimportsOn_24acc(V v_x1_240, V v_acc_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_strAppend(v_acc_241, ((V)&g_heff_2ebuild_2ecommands_2eimportsOn_24acc_str0));
  }
  case TAG_Cons: {
    V v_x12_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 2ULL, 2);
    switch (heff_tag_of(v_x12_243)) {
    case TAG_Nil: {
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      return heff_strAppend(v_acc_241, ((V)&g_heff_2ebuild_2ecommands_2eimportsOn_24acc_str1));
    }
    case TAG_Cons: {
      V v_b_244 = heff_field(v_x12_243, 0);
      V v_x122_245 = heff_field(v_x12_243, 1);
      heff_take_n(v_x12_243, 3ULL, 2);
      switch (heff_tag_of(v_x122_245)) {
      case TAG_Nil: {
        heff_drop_cell(v_ru_24x1_240_24Cons, 2);
        heff_drop(v_b_244);
        return heff_strAppend(v_acc_241, ((V)&g_heff_2ebuild_2ecommands_2eimportsOn_24acc_str2));
      }
      case TAG_Cons: {
        V v_t_248 = heff_strAppend(heff_strAppend(v_acc_241, ((V)&g_heff_2ebuild_2ecommands_2eimportsOn_24acc_str3)), heff_dup(v_b_244));
        V v_s_249 = heff_strAppend(v_t_248, ((V)&g_heff_2ebuild_2ecommands_2eimportsOn_24acc_str4));
        V t_0 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_b_244, v_x122_245});
        V t_1 = v_s_249;
        v_x1_240 = t_0;
        v_acc_241 = t_1;
        goto top;
      }
      default: return heff_nomatch(v_x122_245);
      }
    }
    default: return heff_nomatch(v_x12_243);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2ecommands_2eimportsOn_24acc_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eimportsOn_24acc(a[0], a[1]);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2efirstErrorOf_24cpr_str0, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efirstErrorOf_24cpr_str1, 2, ": ");

HeffT2 g_heff_2ebuild_2ecommands_2efirstErrorOf_24cpr(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_c_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    V v_diags_243 = heff_dup(heff_rfield(v_c_241, 6));
    V v_path_244 = heff_dup(heff_rfield(v_c_241, 1));
    V v_source_245 = heff_dup(heff_rfield(v_c_241, 3));
    V v_x2_246 = (g_list_2ekeepIf_24s1161549307x1906011635(v_diags_243));
    switch (heff_tag_of(v_x2_246)) {
    case TAG_Nil: {
      heff_drop(v_path_244);
      heff_drop(v_source_245);
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Cons: {
      V v_d_247 = heff_field(v_x2_246, 0);
      heff_take_n(v_x2_246, 1ULL, 2);
      V v_t_249 = ({ V a_0 = v_path_244; V a_1 = v_source_245; V a_2 = heff_dup(v_d_247); V r_ = (g_heff_2elsp_2erender_2ediagWhere(a_0, a_1, a_2)); heff_drop(v_source_245); r_; });
      V v_t_2410 = (g_heff_2elsp_2erender_2eprtCode(heff_dup(v_d_247)));
      V v_t_2411 = heff_strAppend(heff_strAppend(v_t_2410, ((V)&g_heff_2ebuild_2ecommands_2efirstErrorOf_24cpr_str0)), heff_get_n(v_d_247, 2, 5));
      V v_why_2412 = heff_strAppend(heff_strAppend(v_t_249, ((V)&g_heff_2ebuild_2ecommands_2efirstErrorOf_24cpr_str1)), v_t_2411);
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_why_2412}});
    }
    default: return ((HeffT2){{heff_nomatch(v_x2_246)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2epartsDir_str0, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epartsDir_str1, 5, "build");
Clo g_heff_2ebuild_2ecommands_2epartsDir_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2epartsDir_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2epartsDir(V v_st_240, V v_t_241, V v_x_242) {
top: ;
  V v_t_243 = (g_std_2epath_2eparse(heff_dup(v_st_240), ((V)&g_heff_2ebuild_2ecommands_2epartsDir_str0)));
  V v_t_244 = (g_std_2epath_2eparse(heff_dup(v_st_240), ((V)&g_heff_2ebuild_2ecommands_2epartsDir_str1)));
  V v_t_245 = (g_std_2epath_2ejoin(v_t_243, v_t_244));
  V v_a_246 = ({ V a_0 = v_st_240; V a_1 = v_t_245; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_245); r_; });
  V v_t_247 = (g_std_2epath_2eparse(heff_dup(v_st_240), v_a_246));
  V v_t_248 = (g_std_2epath_2eparse(heff_dup(v_st_240), v_x_242));
  V v_t_249 = (g_std_2epath_2ejoin(v_t_247, v_t_248));
  V v_p_2410 = ({ V a_0 = v_st_240; V a_1 = v_t_249; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_249); r_; });
  V v_t_2411 = (g_std_2epath_2eparse(heff_dup(v_st_240), heff_get_n(v_t_241, 0, 6)));
  V v_t_2412 = (g_std_2epath_2eparse(heff_dup(v_st_240), v_p_2410));
  V v_t_2413 = (g_std_2epath_2ejoin(v_t_2411, v_t_2412));
  return ({ V a_0 = v_st_240; V a_1 = v_t_2413; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_240); heff_drop(v_t_2413); r_; });
}
V g_heff_2ebuild_2ecommands_2epartsDir_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2epartsDir(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eselfPath_24s1432537356x1686629462_str0, 5, "win32");
V g_heff_2ebuild_2ecommands_2eselfPath_24s1432537356x1686629462_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eselfPath_24s1432537356x1686629462_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eselfPath_24s1432537356x1686629462_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2eselfPath_24s1432537356x1686629462_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eselfPath_24s1432537356x1686629462_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eselfPath_24s1432537356x1686629462_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2eselfPath_24s1432537356x1686629462_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2eselfPath_24s1432537356x1686629462_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eselfPath_24s1432537356x1686629462_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eselfPath_24s1432537356x1686629462_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2eselfPath_24s1432537356x1686629462(V v_hd_240, V v_k_241) {
top: ;
  V v_bind_242 = heff_take_field(v_hd_240, 1);
  V v_malg_243 = heff_get_n(v_hd_240, 2, 3);
  V v_t_245 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2eselfPath_24s1432537356x1686629462_lam0_clo)})});
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_245})});
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tr(heff_call(heff_dup(v_malg_243), 1, (V[]){v_t_2411}));
  return heff_tail(heff_dup(v_bind_242), 2, (V[]){v_t_2412, heff_clo_n(g_heff_2ebuild_2ecommands_2eselfPath_24s1432537356x1686629462_lam1, 1, 3, (V[]){v_malg_243, v_bind_242, v_k_241})});
}
V g_heff_2ebuild_2ecommands_2eselfPath_24s1432537356x1686629462_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eselfPath_24s1432537356x1686629462(a[0], a[1]);
}
V g_heff_2ebuild_2ecommands_2eselfPath_24s1432537356x1686629462_lam0(V self, V *args) {
  V v_s_244 = args[0];
  return v_s_244;
}
V g_heff_2ebuild_2ecommands_2eselfPath_24s1432537356x1686629462_lam2(V self, V *args) {
  V v_s_2414 = args[0];
  return v_s_2414;
}
V g_heff_2ebuild_2ecommands_2eselfPath_24s1432537356x1686629462_lam3(V self, V *args) {
  V v_x_2423 = args[0];
  V v_x_2413 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_x_2424 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_x_2423));
  V v_t_2425;
  if (heff_strEq_c(v_x_2413, ((V)&g_heff_2ebuild_2ecommands_2eselfPath_24s1432537356x1686629462_str0))) {
    v_t_2425 = NTAG(TAG_Windows);
  } else {
    v_t_2425 = NTAG(TAG_Posix);
  }
  V v_x_2426 = ({ V a_0 = v_t_2425; V a_1 = v_x_2424; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2425); heff_drop(v_x_2424); r_; });
  V f_ = v_k_241;
  args[0] = v_x_2426;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eselfPath_24s1432537356x1686629462_lam1(V self, V *args) {
  V v_x_2413 = args[0];
  V v_malg_243 = heff_env(self)[0];
  V v_bind_242 = heff_env(self)[1];
  V v_k_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2415 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ProgramPath, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2eselfPath_24s1432537356x1686629462_lam2_clo)})});
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
  V v_t_2421 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2420})});
  V v_t_2422 = heff_tr(heff_call(v_malg_243, 1, (V[]){v_t_2421}));
  V f_ = v_bind_242;
  heff_room[0] = v_t_2422;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2eselfPath_24s1432537356x1686629462_lam3, 1, 2, (V[]){v_x_2413, v_k_241});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprintErrs_24s115117455x797094904_str0, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprintErrs_24s115117455x797094904_str1, 1, "\012");
Clo g_heff_2ebuild_2ecommands_2eprintErrs_24s115117455x797094904_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eprintErrs_24s115117455x797094904_entry, 5, 0};

V g_heff_2ebuild_2ecommands_2eprintErrs_24s115117455x797094904(V v_m_240, V v_x2_241, V v_n_242, V v_p_243, V v_p_244) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_m_240);
    heff_drop(v_p_243);
    return heff_tail(v_p_244, 1, (V[]){v_n_242});
  }
  case TAG_Cons: {
    V v_l_245 = heff_field(v_x2_241, 0);
    V v_rest_246 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_247 = heff_strAppend(heff_strAppend(heff_dup(v_m_240), ((V)&g_heff_2ebuild_2ecommands_2eprintErrs_24s115117455x797094904_str0)), v_l_245);
    V v_t_248 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_WriteErr, 2, (V[]){heff_strAppend(v_t_247, ((V)&g_heff_2ebuild_2ecommands_2eprintErrs_24s115117455x797094904_str1)), NTAG(TAG_MkUnit)});
    V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
    V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
    V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
    V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
    V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
    V v_t_2414 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2413})});
    return (g_co_2eop_24s1178127530x1610393171(v_m_240, v_rest_246, v_n_242, MK_INT(1LL), heff_dup(v_p_243), v_p_244, heff_tag_n(TAG_InR, 1, (V[]){v_t_2414}), v_p_243));
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2ecommands_2eprintErrs_24s115117455x797094904_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eprintErrs_24s115117455x797094904(a[0], a[1], a[2], a[3], a[4]);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigObjects_24s1218369498x1750867255_str0, 2, ".o");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigObjects_24s1218369498x1750867255_str1, 11, "-femit-bin=");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigObjects_24s1218369498x1750867255_str2, 2, "-O");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigObjects_24s1218369498x1750867255_str3, 9, "build-obj");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigObjects_24s1218369498x1750867255_str4, 3, "zig");
V g_heff_2ebuild_2ecommands_2ezigObjects_24s1218369498x1750867255_lam0(V self, V *args);
V g_heff_2ebuild_2ecommands_2ezigObjects_24s1218369498x1750867255_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ezigObjects_24s1218369498x1750867255_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ezigObjects_24s1218369498x1750867255_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2ezigObjects_24s1218369498x1750867255_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2ezigObjects_24s1218369498x1750867255_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ezigObjects_24s1218369498x1750867255_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ezigObjects_24s1218369498x1750867255_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ezigObjects_24s1218369498x1750867255_entry, 4, 0};

V g_heff_2ebuild_2ecommands_2ezigObjects_24s1218369498x1750867255(V v_z_240, V v_mode_241, V v_x3_242, V v_made_243) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nil: {
    heff_drop(v_z_240);
    heff_drop(v_mode_241);
    V v_t_244 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_made_243));
    V v_x_245 = heff_tag_n(TAG_Just, 1, (V[]){v_t_244});
    return heff_clo_n(g_heff_2ebuild_2ecommands_2ezigObjects_24s1218369498x1750867255_lam0, 2, 1, (V[]){v_x_245});
  }
  case TAG_Cons: {
    V v_f_248 = heff_field(v_x3_242, 0);
    V v_rest_249 = heff_field(v_x3_242, 1);
    heff_take_n(v_x3_242, 3ULL, 2);
    return heff_clo_n(g_heff_2ebuild_2ecommands_2ezigObjects_24s1218369498x1750867255_lam1, 2, 5, (V[]){v_f_248, v_mode_241, v_z_240, v_rest_249, v_made_243});
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2ecommands_2ezigObjects_24s1218369498x1750867255_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ezigObjects_24s1218369498x1750867255(a[0], a[1], a[2], a[3]);
}
V g_heff_2ebuild_2ecommands_2ezigObjects_24s1218369498x1750867255_lam0(V self, V *args) {
  V v_hd_246 = args[0];
  V v_k_247 = args[1];
  V v_x_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_246);
  V f_ = v_k_247;
  args[0] = v_x_245;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ezigObjects_24s1218369498x1750867255_lam2(V self, V *args) {
  V v_r_2417 = args[0];
  return v_r_2417;
}
V g_heff_2ebuild_2ecommands_2ezigObjects_24s1218369498x1750867255_lam4(V self, V *args) {
  V v_x_2436 = args[0];
  V v_k_2411 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2436);
  V f_ = v_k_2411;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ezigObjects_24s1218369498x1750867255_lam3(V self, V *args) {
  V v_x_2421 = args[0];
  V v_z_240 = heff_env(self)[0];
  V v_mode_241 = heff_env(self)[1];
  V v_rest_249 = heff_env(self)[2];
  V v_o_2413 = heff_env(self)[3];
  V v_made_243 = heff_env(self)[4];
  V v_hd_2410 = heff_env(self)[5];
  V v_k_2411 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_ended_2422 = heff_take_field(v_x_2421, 0);
  V v_err_2423 = heff_get_n(v_x_2421, 2, 3);
  V v_t_2426;
  switch (heff_tag_of(v_ended_2422)) {
  case TAG_Exited: {
    V v_n_2424 = heff_field(v_ended_2422, 0);
    heff_take_n(v_ended_2422, 1ULL, 1);
    v_t_2426 = heff_bool(heff_intEq_c_lent(v_n_2424, MK_INT(0LL), 2));
    heff_drop(v_n_2424);
    break;
  }
  case TAG_Signalled: {
    heff_take_n(v_ended_2422, 0ULL, 1);
    v_t_2426 = NTAG(TAG_False);
    break;
  }
  case TAG_TimedOut: {
    v_t_2426 = NTAG(TAG_False);
    break;
  }
  case TAG_NotRun: {
    v_t_2426 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_ended_2422);
  }
  if ((heff_dup(v_t_2426) == NTAG(TAG_True))) {
    heff_drop(v_err_2423);
    heff_drop(v_t_2426);
    V v_t_2427 = (g_heff_2ebuild_2ecommands_2ezigObjects_24s1218369498x1750867255(v_z_240, v_mode_241, v_rest_249, heff_tag_n(TAG_Cons, 2, (V[]){v_o_2413, v_made_243})));
    V f_ = v_t_2427;
    heff_room[0] = v_hd_2410;
    heff_room[1] = v_k_2411;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    heff_drop(v_z_240);
    heff_drop(v_mode_241);
    heff_drop(v_rest_249);
    heff_drop(v_o_2413);
    heff_drop(v_made_243);
    heff_drop(v_t_2426);
    V v_t_2428 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_err_2423, NTAG(TAG_MkUnit)});
    V v_t_2429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
    V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
    V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
    V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
    V v_t_2433 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2432})});
    V v_t_2434 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2433})});
    V v_t_2435 = heff_tr(heff_call(heff_take_field(v_hd_2410, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2434})}));
    V f_ = heff_get_n(v_hd_2410, 1, 3);
    heff_room[0] = v_t_2435;
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ezigObjects_24s1218369498x1750867255_lam4, 1, 1, (V[]){v_k_2411});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2ebuild_2ecommands_2ezigObjects_24s1218369498x1750867255_lam1(V self, V *args) {
  V v_hd_2410 = args[0];
  V v_k_2411 = args[1];
  V v_f_248 = heff_env(self)[0];
  V v_mode_241 = heff_env(self)[1];
  V v_z_240 = heff_env(self)[2];
  V v_rest_249 = heff_env(self)[3];
  V v_made_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  int64_t v_t_2412 = (heff_unbox_word(heff_strLength_lent(v_f_248, 0)) - ((int64_t)4ULL));
  V v_o_2413 = heff_strAppend(heff_strSlice_lent(v_f_248, MK_INT(0LL), heff_box_word(v_t_2412), 6), ((V)&g_heff_2ebuild_2ecommands_2ezigObjects_24s1218369498x1750867255_str0));
  V v_t_2414 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ezigObjects_24s1218369498x1750867255_str1), heff_dup(v_o_2413)), NTAG(TAG_Nil)});
  V v_t_2415 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ezigObjects_24s1218369498x1750867255_str2), heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_mode_241), v_t_2414})});
  V v_t_2416 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ezigObjects_24s1218369498x1750867255_str3), heff_tag_n(TAG_Cons, 2, (V[]){v_f_248, v_t_2415})});
  V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_RunUnder, 4, (V[]){heff_dup(v_z_240), ((V)&g_heff_2ebuild_2ecommands_2ezigObjects_24s1218369498x1750867255_str4), v_t_2416, ((V)&g_heff_2ebuild_2ecommands_2ezigObjects_24s1218369498x1750867255_lam2_clo)})});
  V v_t_2419 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_2410, 2)), 1, (V[]){v_t_2419}));
  V f_ = heff_dup(heff_rfield(v_hd_2410, 1));
  args[0] = v_t_2420;
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ezigObjects_24s1218369498x1750867255_lam3, 1, 7, (V[]){v_z_240, v_mode_241, v_rest_249, v_o_2413, v_made_243, v_hd_2410, v_k_2411});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eselfHash_24s2023922332x1057539294_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eselfHash_24s2023922332x1057539294_str1, 8, "compiler");
V g_heff_2ebuild_2ecommands_2eselfHash_24s2023922332x1057539294_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eselfHash_24s2023922332x1057539294_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eselfHash_24s2023922332x1057539294_lam1, 1, 0};
V g_heff_2ebuild_2ecommands_2eselfHash_24s2023922332x1057539294_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2eselfHash_24s2023922332x1057539294_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eselfHash_24s2023922332x1057539294_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eselfHash_24s2023922332x1057539294_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2eselfHash_24s2023922332x1057539294_lam5(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eselfHash_24s2023922332x1057539294_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eselfHash_24s2023922332x1057539294_lam5, 1, 0};
V g_heff_2ebuild_2ecommands_2eselfHash_24s2023922332x1057539294_lam7(V self, V *args);
V g_heff_2ebuild_2ecommands_2eselfHash_24s2023922332x1057539294_lam6(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eselfHash_24s2023922332x1057539294_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eselfHash_24s2023922332x1057539294_lam6, 1, 0};
V g_heff_2ebuild_2ecommands_2eselfHash_24s2023922332x1057539294_lam8(V self, V *args);
V g_heff_2ebuild_2ecommands_2eselfHash_24s2023922332x1057539294_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2eselfHash_24s2023922332x1057539294_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eselfHash_24s2023922332x1057539294_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eselfHash_24s2023922332x1057539294_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2eselfHash_24s2023922332x1057539294(V v_ps_240, V v_hd_241, V v_k_242) {
top: ;
  return (g_heff_2ebuild_2ecommands_2eselfPath_24s1432537356x1686629462(heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2ecommands_2eselfHash_24s2023922332x1057539294_lam0, 1, 3, (V[]){v_hd_241, v_k_242, v_ps_240})));
}
V g_heff_2ebuild_2ecommands_2eselfHash_24s2023922332x1057539294_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eselfHash_24s2023922332x1057539294(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2ecommands_2eselfHash_24s2023922332x1057539294_lam1(V self, V *args) {
  V v_r_246 = args[0];
  return v_r_246;
}
V g_heff_2ebuild_2ecommands_2eselfHash_24s2023922332x1057539294_lam3(V self, V *args) {
  V v_hd_2418 = args[0];
  V v_k_2419 = args[1];
  V v_x_2417 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2418);
  V f_ = v_k_2419;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2417});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eselfHash_24s2023922332x1057539294_lam2(V self, V *args) {
  V v_x_2414 = args[0];
  switch (heff_tag_of(v_x_2414)) {
  case TAG_Left: {
    V v_err_2415 = heff_field(v_x_2414, 0);
    V v_ru_24x_2414_24Left = heff_take_reuse_n(v_x_2414, 1ULL, 1);
    V v_t_2416 = heff_tag_at_n(v_ru_24x_2414_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_err_2415})});
    return (g_co_2eop_24s1998166633x1971890408(v_t_2416));
  }
  case TAG_Right: {
    V v_x_2417 = heff_field(v_x_2414, 0);
    heff_take_n(v_x_2414, 1ULL, 1);
    return heff_clo_n(g_heff_2ebuild_2ecommands_2eselfHash_24s2023922332x1057539294_lam3, 2, 1, (V[]){v_x_2417});
  }
  default: return heff_nomatch(v_x_2414);
  }
}
V g_heff_2ebuild_2ecommands_2eselfHash_24s2023922332x1057539294_lam5(V self, V *args) {
  V v_r_2432 = args[0];
  return v_r_2432;
}
V g_heff_2ebuild_2ecommands_2eselfHash_24s2023922332x1057539294_lam7(V self, V *args) {
  V v_hd_2444 = args[0];
  V v_k_2445 = args[1];
  V v_x_2443 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2444);
  V f_ = v_k_2445;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2443});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eselfHash_24s2023922332x1057539294_lam6(V self, V *args) {
  V v_x_2440 = args[0];
  switch (heff_tag_of(v_x_2440)) {
  case TAG_Left: {
    V v_err_2441 = heff_field(v_x_2440, 0);
    V v_ru_24x_2440_24Left = heff_take_reuse_n(v_x_2440, 1ULL, 1);
    V v_t_2442 = heff_tag_at_n(v_ru_24x_2440_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_err_2441})});
    return (g_co_2eop_24s1998166633x1971890408(v_t_2442));
  }
  case TAG_Right: {
    V v_x_2443 = heff_field(v_x_2440, 0);
    heff_take_n(v_x_2440, 1ULL, 1);
    return heff_clo_n(g_heff_2ebuild_2ecommands_2eselfHash_24s2023922332x1057539294_lam7, 2, 1, (V[]){v_x_2443});
  }
  default: return heff_nomatch(v_x_2440);
  }
}
V g_heff_2ebuild_2ecommands_2eselfHash_24s2023922332x1057539294_lam8(V self, V *args) {
  V v_x_2447 = args[0];
  V v_ps_240 = heff_env(self)[0];
  V v_y_2423 = heff_env(self)[1];
  V v_hd_241 = heff_env(self)[2];
  V v_k_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2450;
  switch (heff_tag_of(v_x_2447)) {
  case TAG_Left: {
    heff_take_n(v_x_2447, 0ULL, 1);
    v_t_2450 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Right: {
    V v_y_2449 = heff_field(v_x_2447, 0);
    V v_ru_24x_2447_24Right = heff_take_reuse_n(v_x_2447, 1ULL, 1);
    v_t_2450 = heff_tag_at_n(v_ru_24x_2447_24Right, TAG_Just, 1, (V[]){v_y_2449});
    break;
  }
  default: heff_nomatch(v_x_2447);
  }
  return ({ V a_0 = v_ps_240; V a_1 = v_y_2423; V a_2 = v_t_2450; V a_3 = v_hd_241; V a_4 = v_k_242; V r_ = (g_heff_2ebuild_2ecommands_2eselfFrom_24s176185486x602532917(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_t_2450); r_; });
}
V g_heff_2ebuild_2ecommands_2eselfHash_24s2023922332x1057539294_lam4(V self, V *args) {
  V v_x_2421 = args[0];
  V v_k_242 = heff_env(self)[0];
  V v_ps_240 = heff_env(self)[1];
  V v_hd_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_x_2421)) {
  case TAG_Left: {
    heff_take_n(v_x_2421, 0ULL, 1);
    heff_drop_rec(v_ps_240, 6);
    heff_drop(v_hd_241);
    V f_ = v_k_242;
    args[0] = ((V)&g_heff_2ebuild_2ecommands_2eselfHash_24s2023922332x1057539294_str0);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Right: {
    V v_y_2423 = heff_field(v_x_2421, 0);
    V v_ru_24x_2421_24Right = heff_take_reuse_n(v_x_2421, 1ULL, 1);
    V v_d_2424 = (g_heff_2ebuild_2ecommands_2ebackDirOf(heff_dup(v_ps_240)));
    V v_st_2425 = heff_dup(heff_rfield(v_ps_240, 5));
    V v_t_2426 = (g_std_2epath_2eparse(heff_dup(v_st_2425), v_d_2424));
    V v_t_2427 = (g_std_2epath_2eparse(heff_dup(v_st_2425), ((V)&g_heff_2ebuild_2ecommands_2eselfHash_24s2023922332x1057539294_str1)));
    V v_t_2428 = (g_std_2epath_2ejoin(v_t_2426, v_t_2427));
    V v_s_2429 = ({ V a_0 = v_st_2425; V a_1 = v_t_2428; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2425); heff_drop(v_t_2428); r_; });
    V v_path_2430 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_s_2429));
    V v_t_2431 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2430; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_2430); r_; });
    V v_a_2433 = heff_tag_n(TAG_ReadFile, 2, (V[]){v_t_2431, ((V)&g_heff_2ebuild_2ecommands_2eselfHash_24s2023922332x1057539294_lam5_clo)});
    V v_t_2434 = heff_tag_at_n(v_ru_24x_2421_24Right, TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2433})});
    V v_t_2435 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2434})});
    V v_t_2436 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2435})});
    V v_t_2437 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2436})});
    V v_t_2438 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2437})});
    V v_t_2439 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2438})});
    V v_c_2446 = heff_tr(g_co_2eop_24s1398690846x1918384825(heff_tag_n(TAG_InR, 1, (V[]){v_t_2439}), heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), ((V)&g_heff_2ebuild_2ecommands_2eselfHash_24s2023922332x1057539294_lam6_clo)));
    V f_ = v_c_2446;
    heff_room[0] = heff_dup(v_hd_241);
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2eselfHash_24s2023922332x1057539294_lam8, 1, 4, (V[]){v_ps_240, v_y_2423, v_hd_241, v_k_242});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_x_2421);
  }
}
V g_heff_2ebuild_2ecommands_2eselfHash_24s2023922332x1057539294_lam0(V self, V *args) {
  V v_x_243 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  V v_ps_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_path_244 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_x_243));
  V v_t_245 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_244; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_244); r_; });
  V v_a_247 = heff_tag_n(TAG_ReadFile, 2, (V[]){v_t_245, ((V)&g_heff_2ebuild_2ecommands_2eselfHash_24s2023922332x1057539294_lam1_clo)});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_247})});
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
  V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2412})});
  V v_c_2420 = heff_tr(g_co_2eop_24s1398690846x1918384825(heff_tag_n(TAG_InR, 1, (V[]){v_t_2413}), heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), ((V)&g_heff_2ebuild_2ecommands_2eselfHash_24s2023922332x1057539294_lam2_clo)));
  V f_ = v_c_2420;
  heff_room[0] = heff_dup(v_hd_241);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2eselfHash_24s2023922332x1057539294_lam4, 1, 3, (V[]){v_k_242, v_ps_240, v_hd_241});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ewriteParts_24s1069210723x719436499_str0, 13, "cannot write ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ewriteParts_24s1069210723x719436499_str1, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ewriteParts_24s1069210723x719436499_str2, 13, "cannot write ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ewriteParts_24s1069210723x719436499_str3, 1, "\012");
V g_heff_2ebuild_2ecommands_2ewriteParts_24s1069210723x719436499_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ewriteParts_24s1069210723x719436499_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewriteParts_24s1069210723x719436499_lam1, 1, 0};
V g_heff_2ebuild_2ecommands_2ewriteParts_24s1069210723x719436499_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ewriteParts_24s1069210723x719436499_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ewriteParts_24s1069210723x719436499_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewriteParts_24s1069210723x719436499_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2ewriteParts_24s1069210723x719436499_lam5(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ewriteParts_24s1069210723x719436499_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewriteParts_24s1069210723x719436499_lam5, 1, 0};
V g_heff_2ebuild_2ecommands_2ewriteParts_24s1069210723x719436499_lam8(V self, V *args);
V g_heff_2ebuild_2ecommands_2ewriteParts_24s1069210723x719436499_lam7(V self, V *args);
V g_heff_2ebuild_2ecommands_2ewriteParts_24s1069210723x719436499_lam9(V self, V *args);
V g_heff_2ebuild_2ecommands_2ewriteParts_24s1069210723x719436499_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2ewriteParts_24s1069210723x719436499_lam12(V self, V *args);
V g_heff_2ebuild_2ecommands_2ewriteParts_24s1069210723x719436499_lam11(V self, V *args);
V g_heff_2ebuild_2ecommands_2ewriteParts_24s1069210723x719436499_lam15(V self, V *args);
V g_heff_2ebuild_2ecommands_2ewriteParts_24s1069210723x719436499_lam14(V self, V *args);
V g_heff_2ebuild_2ecommands_2ewriteParts_24s1069210723x719436499_lam13(V self, V *args);
V g_heff_2ebuild_2ecommands_2ewriteParts_24s1069210723x719436499_lam10(V self, V *args);
V g_heff_2ebuild_2ecommands_2ewriteParts_24s1069210723x719436499_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2ewriteParts_24s1069210723x719436499_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ewriteParts_24s1069210723x719436499_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewriteParts_24s1069210723x719436499_entry, 5, 0};

V g_heff_2ebuild_2ecommands_2ewriteParts_24s1069210723x719436499(V v_dir_240, V v_done_241, V v_x3_242, V v_p_243, V v_p_244) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_MkPair: {
    V v_parts_245 = heff_field(v_x3_242, 0);
    V v_errors_246 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24MkPair = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    return (g_heff_2ebuild_2ecommands_2eemitErrs_24s394189364x2134712221_24tok2(v_ru_24x3_242_24MkPair, heff_dup(v_errors_246), heff_dup(v_p_243), heff_clo_n(g_heff_2ebuild_2ecommands_2ewriteParts_24s1069210723x719436499_lam0, 1, 6, (V[]){v_errors_246, v_dir_240, v_p_243, v_parts_245, v_done_241, v_p_244})));
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2ecommands_2ewriteParts_24s1069210723x719436499_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ewriteParts_24s1069210723x719436499(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ebuild_2ecommands_2ewriteParts_24s1069210723x719436499_lam1(V self, V *args) {
  V v_r_2410 = args[0];
  return v_r_2410;
}
V g_heff_2ebuild_2ecommands_2ewriteParts_24s1069210723x719436499_lam3(V self, V *args) {
  V v_hd_2422 = args[0];
  V v_k_2423 = args[1];
  V v_x_2421 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2422);
  V f_ = v_k_2423;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2421});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ewriteParts_24s1069210723x719436499_lam2(V self, V *args) {
  V v_x_2418 = args[0];
  switch (heff_tag_of(v_x_2418)) {
  case TAG_Left: {
    V v_err_2419 = heff_field(v_x_2418, 0);
    V v_ru_24x_2418_24Left = heff_take_reuse_n(v_x_2418, 1ULL, 1);
    V v_t_2420 = heff_tag_at_n(v_ru_24x_2418_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_err_2419})});
    return (g_co_2eop_24s1998166633x1971890408(v_t_2420));
  }
  case TAG_Right: {
    V v_x_2421 = heff_field(v_x_2418, 0);
    heff_take_n(v_x_2418, 1ULL, 1);
    return heff_clo_n(g_heff_2ebuild_2ecommands_2ewriteParts_24s1069210723x719436499_lam3, 2, 1, (V[]){v_x_2421});
  }
  default: return heff_nomatch(v_x_2418);
  }
}
V g_heff_2ebuild_2ecommands_2ewriteParts_24s1069210723x719436499_lam5(V self, V *args) {
  V v_r_2428 = args[0];
  return v_r_2428;
}
V g_heff_2ebuild_2ecommands_2ewriteParts_24s1069210723x719436499_lam8(V self, V *args) {
  V v_n_2444 = args[0];
  V v_path_2426 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2445 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_n_2444));
  return (g_std_2epath_2ejoin(v_path_2426, v_t_2445));
}
V g_heff_2ebuild_2ecommands_2ewriteParts_24s1069210723x719436499_lam7(V self, V *args) {
  V v_x_2441 = args[0];
  V v_z_2442 = args[1];
  V v_z_2443 = args[2];
  V v_path_2426 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_z_2442);
  V v_x_2446 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2ecommands_2ewriteParts_24s1069210723x719436499_lam8, 1, 1, (V[]){v_path_2426}), v_x_2441));
  V v_x_2447 = (g_list_2emap_24s219049803x1458391381(v_x_2446));
  V f_ = v_z_2443;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2447});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ewriteParts_24s1069210723x719436499_lam9(V self, V *args) {
  V v_n_2449 = args[0];
  V v_path_2426 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2450 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_n_2449));
  return (g_std_2epath_2ejoin(v_path_2426, v_t_2450));
}
V g_heff_2ebuild_2ecommands_2ewriteParts_24s1069210723x719436499_lam6(V self, V *args) {
  V v_x_2436 = args[0];
  V v_z_2437 = args[1];
  V v_z_2438 = args[2];
  V v_path_2426 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x_2436)) {
  case TAG_Left: {
    V v_err_2439 = heff_field(v_x_2436, 0);
    V v_ru_24x_2436_24Left = heff_take_reuse_n(v_x_2436, 1ULL, 1);
    V v_t_2440 = heff_tag_at_n(v_ru_24x_2436_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_err_2439})});
    return (g_co_2eop_24s91617614x2132230022(v_t_2440, heff_clo_n(g_heff_2ebuild_2ecommands_2ewriteParts_24s1069210723x719436499_lam7, 3, 1, (V[]){v_path_2426}), v_z_2437, v_z_2438));
  }
  case TAG_Right: {
    V v_x_2448 = heff_field(v_x_2436, 0);
    heff_take_n(v_x_2436, 1ULL, 1);
    heff_drop(v_z_2437);
    V v_x_2451 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2ecommands_2ewriteParts_24s1069210723x719436499_lam9, 1, 1, (V[]){v_path_2426}), v_x_2448));
    V v_x_2452 = (g_list_2emap_24s219049803x1458391381(v_x_2451));
    V f_ = v_z_2438;
    args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2452});
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_2436);
  }
}
V g_heff_2ebuild_2ecommands_2ewriteParts_24s1069210723x719436499_lam12(V self, V *args) {
  V v_x_2466 = args[0];
  V v_p_243 = heff_env(self)[0];
  V v_p_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2466);
  return (g_co_2eop_24s40508559x1835373952(MK_INT(1LL), v_p_243, v_p_244));
}
V g_heff_2ebuild_2ecommands_2ewriteParts_24s1069210723x719436499_lam11(V self, V *args) {
  V v_x_2456 = args[0];
  V v_done_241 = heff_env(self)[0];
  V v_p_243 = heff_env(self)[1];
  V v_p_244 = heff_env(self)[2];
  V v_dir_240 = heff_env(self)[3];
  heff_clo_take(self, 4);
  if ((heff_dup(v_x_2456) == NTAG(TAG_True))) {
    heff_drop(v_x_2456);
    heff_drop(v_dir_240);
    V f_ = v_done_241;
    heff_room[0] = v_p_243;
    heff_room[1] = v_p_244;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    heff_drop(v_x_2456);
    heff_drop(v_done_241);
    V v_t_2457 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ewriteParts_24s1069210723x719436499_str0), v_dir_240), ((V)&g_heff_2ebuild_2ecommands_2ewriteParts_24s1069210723x719436499_str1));
    V v_t_2458 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2457, NTAG(TAG_MkUnit)});
    V v_t_2459 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2458})});
    V v_t_2460 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2459})});
    V v_t_2461 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2460})});
    V v_t_2462 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2461})});
    V v_t_2463 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2462})});
    V v_t_2464 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2463})});
    V v_t_2465 = heff_tr(heff_call(heff_dup(heff_rfield(v_p_243, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2464})}));
    V f_ = heff_dup(heff_rfield(v_p_243, 1));
    heff_room[0] = v_t_2465;
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ewriteParts_24s1069210723x719436499_lam12, 1, 2, (V[]){v_p_243, v_p_244});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2ebuild_2ecommands_2ewriteParts_24s1069210723x719436499_lam15(V self, V *args) {
  V v_x_2479 = args[0];
  V v_p_243 = heff_env(self)[0];
  V v_p_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2479);
  return (g_co_2eop_24s40508559x1835373952(MK_INT(1LL), v_p_243, v_p_244));
}
V g_heff_2ebuild_2ecommands_2ewriteParts_24s1069210723x719436499_lam14(V self, V *args) {
  V v_x_2469 = args[0];
  V v_done_241 = heff_env(self)[0];
  V v_p_243 = heff_env(self)[1];
  V v_p_244 = heff_env(self)[2];
  V v_dir_240 = heff_env(self)[3];
  heff_clo_take(self, 4);
  if ((heff_dup(v_x_2469) == NTAG(TAG_True))) {
    heff_drop(v_x_2469);
    heff_drop(v_dir_240);
    V f_ = v_done_241;
    heff_room[0] = v_p_243;
    heff_room[1] = v_p_244;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    heff_drop(v_x_2469);
    heff_drop(v_done_241);
    V v_t_2470 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ewriteParts_24s1069210723x719436499_str2), v_dir_240), ((V)&g_heff_2ebuild_2ecommands_2ewriteParts_24s1069210723x719436499_str3));
    V v_t_2471 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2470, NTAG(TAG_MkUnit)});
    V v_t_2472 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2471})});
    V v_t_2473 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2472})});
    V v_t_2474 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2473})});
    V v_t_2475 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2474})});
    V v_t_2476 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2475})});
    V v_t_2477 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2476})});
    V v_t_2478 = heff_tr(heff_call(heff_dup(heff_rfield(v_p_243, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2477})}));
    V f_ = heff_dup(heff_rfield(v_p_243, 1));
    heff_room[0] = v_t_2478;
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ewriteParts_24s1069210723x719436499_lam15, 1, 2, (V[]){v_p_243, v_p_244});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2ebuild_2ecommands_2ewriteParts_24s1069210723x719436499_lam13(V self, V *args) {
  V v_x_2468 = args[0];
  V v_dir_240 = heff_env(self)[0];
  V v_parts_245 = heff_env(self)[1];
  V v_p_243 = heff_env(self)[2];
  V v_done_241 = heff_env(self)[3];
  V v_p_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2468);
  return (g_heff_2ebuild_2ecommands_2ewritePartsGo_24s2124042284x1735199047(heff_dup(v_dir_240), v_parts_245, heff_dup(v_p_243), heff_clo_n(g_heff_2ebuild_2ecommands_2ewriteParts_24s1069210723x719436499_lam14, 1, 4, (V[]){v_done_241, v_p_243, v_p_244, v_dir_240})));
}
V g_heff_2ebuild_2ecommands_2ewriteParts_24s1069210723x719436499_lam10(V self, V *args) {
  V v_x_2454 = args[0];
  V v_dir_240 = heff_env(self)[0];
  V v_parts_245 = heff_env(self)[1];
  V v_p_243 = heff_env(self)[2];
  V v_done_241 = heff_env(self)[3];
  V v_p_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  switch (heff_tag_of(v_x_2454)) {
  case TAG_Left: {
    heff_take_n(v_x_2454, 0ULL, 1);
    return (g_heff_2ebuild_2ecommands_2ewritePartsGo_24s2124042284x1735199047(heff_dup(v_dir_240), v_parts_245, heff_dup(v_p_243), heff_clo_n(g_heff_2ebuild_2ecommands_2ewriteParts_24s1069210723x719436499_lam11, 1, 4, (V[]){v_done_241, v_p_243, v_p_244, v_dir_240})));
  }
  case TAG_Right: {
    V v_y_2467 = heff_field(v_x_2454, 0);
    heff_take_n(v_x_2454, 1ULL, 1);
    return ({ V a_0 = heff_dup(v_dir_240); V a_1 = v_parts_245; V a_2 = v_y_2467; V a_3 = heff_dup(v_p_243); V a_4 = heff_clo_n(g_heff_2ebuild_2ecommands_2ewriteParts_24s1069210723x719436499_lam13, 1, 5, (V[]){v_dir_240, heff_dup(v_parts_245), v_p_243, v_done_241, v_p_244}); V r_ = (g_heff_2ebuild_2ecommands_2eremoveStale_24s1076505188x1773366585(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_parts_245); r_; });
  }
  default: return heff_nomatch(v_x_2454);
  }
}
V g_heff_2ebuild_2ecommands_2ewriteParts_24s1069210723x719436499_lam4(V self, V *args) {
  V v_x_2425 = args[0];
  V v_dir_240 = heff_env(self)[0];
  V v_p_243 = heff_env(self)[1];
  V v_parts_245 = heff_env(self)[2];
  V v_done_241 = heff_env(self)[3];
  V v_p_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2425);
  V v_path_2426 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), heff_dup(v_dir_240)));
  V v_t_2427 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2426; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); r_; });
  V v_a_2429 = heff_tag_n(TAG_ReadDirectory, 2, (V[]){v_t_2427, ((V)&g_heff_2ebuild_2ecommands_2ewriteParts_24s1069210723x719436499_lam5_clo)});
  V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2429})});
  V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
  V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
  V v_t_2433 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2432})});
  V v_t_2434 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2433})});
  V v_t_2435 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2434})});
  V v_c_2453 = (g_co_2eop_24s907744994x1234676051(heff_tag_n(TAG_InR, 1, (V[]){v_t_2435}), heff_clo_n(g_heff_2ebuild_2ecommands_2ewriteParts_24s1069210723x719436499_lam6, 3, 1, (V[]){v_path_2426})));
  V f_ = v_c_2453;
  heff_room[0] = heff_dup(v_p_243);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ewriteParts_24s1069210723x719436499_lam10, 1, 5, (V[]){v_dir_240, v_parts_245, v_p_243, v_done_241, v_p_244});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ewriteParts_24s1069210723x719436499_lam0(V self, V *args) {
  V v_x_247 = args[0];
  V v_errors_246 = heff_env(self)[0];
  V v_dir_240 = heff_env(self)[1];
  V v_p_243 = heff_env(self)[2];
  V v_parts_245 = heff_env(self)[3];
  V v_done_241 = heff_env(self)[4];
  V v_p_244 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_247);
  switch (heff_tag_of(v_errors_246)) {
  case TAG_Nil: {
    V v_path_248 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), heff_dup(v_dir_240)));
    V v_t_249 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_248; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_248); r_; });
    V v_a_2411 = heff_tag_n(TAG_MakeDirectory, 2, (V[]){v_t_249, ((V)&g_heff_2ebuild_2ecommands_2ewriteParts_24s1069210723x719436499_lam1_clo)});
    V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2411})});
    V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
    V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
    V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
    V v_t_2416 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
    V v_t_2417 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2416})});
    V v_c_2424 = heff_tr(g_co_2eop_24s1398690846x1918384825(heff_tag_n(TAG_InR, 1, (V[]){v_t_2417}), heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), ((V)&g_heff_2ebuild_2ecommands_2ewriteParts_24s1069210723x719436499_lam2_clo)));
    V f_ = v_c_2424;
    heff_room[0] = heff_dup(v_p_243);
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ewriteParts_24s1069210723x719436499_lam4, 1, 5, (V[]){v_dir_240, v_p_243, v_parts_245, v_done_241, v_p_244});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_Cons: {
    V v_ru_24errors_246_24Cons = heff_take_reuse_n(v_errors_246, 0ULL, 2);
    heff_drop(v_dir_240);
    heff_drop(v_parts_245);
    heff_drop(v_done_241);
    return (g_co_2eop_24s40508559x1835373952_24tok2(v_ru_24errors_246_24Cons, MK_INT(1LL), v_p_243, v_p_244));
  }
  default: return heff_nomatch(v_errors_246);
  }
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ekeptWritten_24s1204008192x1571756415_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ekeptWritten_24s1204008192x1571756415_str1, 1, "_");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ekeptWritten_24s1204008192x1571756415_str2, 8, "heff.zig");
V g_heff_2ebuild_2ecommands_2ekeptWritten_24s1204008192x1571756415_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ekeptWritten_24s1204008192x1571756415_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ekeptWritten_24s1204008192x1571756415_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2ekeptWritten_24s1204008192x1571756415_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ekeptWritten_24s1204008192x1571756415_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ekeptWritten_24s1204008192x1571756415_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ekeptWritten_24s1204008192x1571756415_lam1, 1, 0};
V g_heff_2ebuild_2ecommands_2ekeptWritten_24s1204008192x1571756415_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2ekeptWritten_24s1204008192x1571756415_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2ekeptWritten_24s1204008192x1571756415_lam3(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ekeptWritten_24s1204008192x1571756415_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ekeptWritten_24s1204008192x1571756415_entry, 10, 0};

V g_heff_2ebuild_2ecommands_2ekeptWritten_24s1204008192x1571756415(V v_bi_240, V v_dir_241, V v_zig_242, V v_id_243, V v_texts_244, V v_backs_245, V v_done_246, V v_out_247, V v_z_248, V v_z_249) {
top: ;
  V v_groups_2410 = heff_take_field(v_out_247, 2);
  V v_copies_2411 = heff_take_field(v_out_247, 3);
  V v_emits_2412 = heff_take_field(v_out_247, 4);
  V v_parts_2413 = heff_take_field(v_out_247, 0);
  V v_errors_2414 = heff_get_n(v_out_247, 1, 5);
  V v_paths_2415 = heff_take_field(v_bi_240, 0);
  V v_modules_2416 = heff_get_n(v_bi_240, 2, 3);
  V v_t_2445;
  if (heff_strEq_c_lent(v_id_243, ((V)&g_heff_2ebuild_2ecommands_2ekeptWritten_24s1204008192x1571756415_str0), 2)) {
    heff_drop(v_id_243);
    heff_drop(v_backs_245);
    heff_drop(v_groups_2410);
    heff_drop(v_copies_2411);
    heff_drop(v_emits_2412);
    heff_drop(v_paths_2415);
    heff_drop(v_modules_2416);
    v_t_2445 = v_done_246;
  } else {
    V v_s_2417 = (g_heff_2ebuild_2ecommands_2ebackDirOf(heff_dup(v_paths_2415)));
    V v_path_2418 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_s_2417));
    V v_t_2419 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2418; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_2418); r_; });
    V v_a_2421 = heff_tag_n(TAG_MakeDirectory, 2, (V[]){v_t_2419, ((V)&g_heff_2ebuild_2ecommands_2ekeptWritten_24s1204008192x1571756415_lam0_clo)});
    V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2421})});
    V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
    V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
    V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
    V v_t_2426 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
    V v_t_2427 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2426})});
    V v_c_2434 = heff_tr(g_co_2eop_24s1398690846x1918384825(heff_tag_n(TAG_InR, 1, (V[]){v_t_2427}), heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), ((V)&g_heff_2ebuild_2ecommands_2ekeptWritten_24s1204008192x1571756415_lam1_clo)));
    v_t_2445 = heff_clo_n(g_heff_2ebuild_2ecommands_2ekeptWritten_24s1204008192x1571756415_lam3, 2, 10, (V[]){v_c_2434, heff_dup(v_texts_244), v_modules_2416, v_groups_2410, v_copies_2411, v_emits_2412, v_id_243, v_backs_245, v_paths_2415, v_done_246});
  }
  V v_t_2446 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ekeptWritten_24s1204008192x1571756415_str2), v_zig_242}), v_parts_2413});
  return (g_heff_2ebuild_2ecommands_2ewriteParts_24s1069210723x719436499(v_dir_241, v_t_2445, heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2446, v_errors_2414}), v_z_248, v_z_249));
}
V g_heff_2ebuild_2ecommands_2ekeptWritten_24s1204008192x1571756415_entry(V self, V *a) {
  (void)self;
  V a4 = a[4]; V r = g_heff_2ebuild_2ecommands_2ekeptWritten_24s1204008192x1571756415(a[0], a[1], a[2], a[3], a4, a[5], a[6], a[7], a[8], a[9]); heff_drop(a4); return r;
}
V g_heff_2ebuild_2ecommands_2ekeptWritten_24s1204008192x1571756415_lam0(V self, V *args) {
  V v_r_2420 = args[0];
  return v_r_2420;
}
V g_heff_2ebuild_2ecommands_2ekeptWritten_24s1204008192x1571756415_lam2(V self, V *args) {
  V v_hd_2432 = args[0];
  V v_k_2433 = args[1];
  V v_x_2431 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2432);
  V f_ = v_k_2433;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2431});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ekeptWritten_24s1204008192x1571756415_lam1(V self, V *args) {
  V v_x_2428 = args[0];
  switch (heff_tag_of(v_x_2428)) {
  case TAG_Left: {
    V v_err_2429 = heff_field(v_x_2428, 0);
    V v_ru_24x_2428_24Left = heff_take_reuse_n(v_x_2428, 1ULL, 1);
    V v_t_2430 = heff_tag_at_n(v_ru_24x_2428_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_err_2429})});
    return (g_co_2eop_24s1998166633x1971890408(v_t_2430));
  }
  case TAG_Right: {
    V v_x_2431 = heff_field(v_x_2428, 0);
    heff_take_n(v_x_2428, 1ULL, 1);
    return heff_clo_n(g_heff_2ebuild_2ecommands_2ekeptWritten_24s1204008192x1571756415_lam2, 2, 1, (V[]){v_x_2431});
  }
  default: return heff_nomatch(v_x_2428);
  }
}
V g_heff_2ebuild_2ecommands_2ekeptWritten_24s1204008192x1571756415_lam5(V self, V *args) {
  V v_x_2444 = args[0];
  V v_done_246 = heff_env(self)[0];
  V v_hd_2435 = heff_env(self)[1];
  V v_k_2436 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2444);
  V f_ = v_done_246;
  heff_room[0] = v_hd_2435;
  heff_room[1] = v_k_2436;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ekeptWritten_24s1204008192x1571756415_lam4(V self, V *args) {
  V v_x_2437 = args[0];
  V v_texts_244 = heff_env(self)[0];
  V v_modules_2416 = heff_env(self)[1];
  V v_groups_2410 = heff_env(self)[2];
  V v_copies_2411 = heff_env(self)[3];
  V v_emits_2412 = heff_env(self)[4];
  V v_id_243 = heff_env(self)[5];
  V v_backs_245 = heff_env(self)[6];
  V v_paths_2415 = heff_env(self)[7];
  V v_hd_2435 = heff_env(self)[8];
  V v_done_246 = heff_env(self)[9];
  V v_k_2436 = heff_env(self)[10];
  heff_clo_take(self, 11);
  heff_drop(v_x_2437);
  V v_t_2438 = ({ V a_0 = heff_dup(g_std_2eordmap_2eempty_get()); V a_1 = v_texts_244; V r_ = (g_list_2efoldl_24s744304057x1932700078(a_0, a_1)); heff_drop(v_texts_244); r_; });
  V v_t_2439 = (g_std_2eordmap_2einsert_24s615484302x989744458(heff_dup(g_std_2eordmap_2eempty_get()), ((V)&g_heff_2ebuild_2ecommands_2ekeptWritten_24s1204008192x1571756415_str1), NTAG(TAG_MkUnit)));
  V v_t_2440 = ({ V a_0 = v_t_2439; V a_1 = v_modules_2416; V r_ = (g_list_2efoldl_24s1614667250x430274379(a_0, a_1)); heff_drop(v_modules_2416); r_; });
  V v_t_2441 = heff_rec_n(4, shape_groups__copies__emits__jss, (V[]){v_groups_2410, v_copies_2411, v_emits_2412, NTAG(TAG_Nil)});
  V v_t_2442 = (g_heff_2ebuild_2ebackcache_2ebackTexts(v_id_243, heff_rec_n(2, shape_mods__olds, (V[]){v_t_2440, v_backs_245}), v_t_2441));
  V v_c_2443 = ({ V a_0 = v_paths_2415; V a_1 = v_t_2438; V a_2 = v_t_2442; V r_ = (g_heff_2ebuild_2ecommands_2ewriteBacks_24s1039561216x639698839(a_0, a_1, a_2)); heff_drop(v_t_2438); heff_drop(v_t_2442); r_; });
  V f_ = v_c_2443;
  heff_room[0] = heff_dup(v_hd_2435);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ekeptWritten_24s1204008192x1571756415_lam5, 1, 3, (V[]){v_done_246, v_hd_2435, v_k_2436});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ekeptWritten_24s1204008192x1571756415_lam3(V self, V *args) {
  V v_hd_2435 = args[0];
  V v_k_2436 = args[1];
  V v_c_2434 = heff_env(self)[0];
  V v_texts_244 = heff_env(self)[1];
  V v_modules_2416 = heff_env(self)[2];
  V v_groups_2410 = heff_env(self)[3];
  V v_copies_2411 = heff_env(self)[4];
  V v_emits_2412 = heff_env(self)[5];
  V v_id_243 = heff_env(self)[6];
  V v_backs_245 = heff_env(self)[7];
  V v_paths_2415 = heff_env(self)[8];
  V v_done_246 = heff_env(self)[9];
  heff_clo_take(self, 10);
  V f_ = v_c_2434;
  args[0] = heff_dup(v_hd_2435);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ekeptWritten_24s1204008192x1571756415_lam4, 1, 11, (V[]){v_texts_244, v_modules_2416, v_groups_2410, v_copies_2411, v_emits_2412, v_id_243, v_backs_245, v_paths_2415, v_hd_2435, v_done_246, v_k_2436});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ewriteOutC_24s1877451407x355012956_str0, 2, ".c");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ewriteOutC_24s1877451407x355012956_str1, 4, ".zig");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ewriteOutC_24s1877451407x355012956_str2, 2, ".c");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ewriteOutC_24s1877451407x355012956_str3, 13, "cannot write ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ewriteOutC_24s1877451407x355012956_str4, 4, ".zig");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ewriteOutC_24s1877451407x355012956_str5, 1, "\012");
V g_heff_2ebuild_2ecommands_2ewriteOutC_24s1877451407x355012956_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ewriteOutC_24s1877451407x355012956_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewriteOutC_24s1877451407x355012956_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2ewriteOutC_24s1877451407x355012956_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ewriteOutC_24s1877451407x355012956_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ewriteOutC_24s1877451407x355012956_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewriteOutC_24s1877451407x355012956_lam1, 1, 0};
V g_heff_2ebuild_2ecommands_2ewriteOutC_24s1877451407x355012956_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2ewriteOutC_24s1877451407x355012956_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2ewriteOutC_24s1877451407x355012956_lam3(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ewriteOutC_24s1877451407x355012956_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewriteOutC_24s1877451407x355012956_entry, 6, 0};

V g_heff_2ebuild_2ecommands_2ewriteOutC_24s1877451407x355012956(V v_outPath_240, V v_zig_241, V v_done_242, V v_o_243, V v_z_244, V v_z_245) {
top: ;
  int64_t v_t_246 = (heff_unbox_word(heff_strLength_lent(v_outPath_240, 0)) - ((int64_t)2ULL));
  V v_t_247 = heff_strSlice(heff_dup(v_outPath_240), heff_box_word(v_t_246), heff_strLength_lent(v_outPath_240, 0));
  V v_t_249;
  if (heff_strEq_c(v_t_247, ((V)&g_heff_2ebuild_2ecommands_2ewriteOutC_24s1877451407x355012956_str0))) {
    int64_t v_t_248 = (heff_unbox_word(heff_strLength_lent(v_outPath_240, 0)) - ((int64_t)2ULL));
    v_t_249 = heff_strSlice_lent(v_outPath_240, MK_INT(0LL), heff_box_word(v_t_248), 6);
  } else {
    v_t_249 = heff_dup(v_outPath_240);
  }
  V v_path_2410 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), heff_strAppend(v_t_249, ((V)&g_heff_2ebuild_2ecommands_2ewriteOutC_24s1877451407x355012956_str1))));
  V v_t_2411 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2410; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_2410); r_; });
  V v_a_2413 = heff_tag_n(TAG_WriteFile, 3, (V[]){v_t_2411, v_zig_241, ((V)&g_heff_2ebuild_2ecommands_2ewriteOutC_24s1877451407x355012956_lam0_clo)});
  V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2413})});
  V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2418})});
  V v_c_2426 = heff_tr(g_co_2eop_24s1398690846x1918384825(heff_tag_n(TAG_InR, 1, (V[]){v_t_2419}), heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), ((V)&g_heff_2ebuild_2ecommands_2ewriteOutC_24s1877451407x355012956_lam1_clo)));
  return (g_heff_2ebuild_2ecommands_2ewriteOut_24s1442511881x314947241(heff_dup(v_outPath_240), heff_clo_n(g_heff_2ebuild_2ecommands_2ewriteOutC_24s1877451407x355012956_lam3, 2, 3, (V[]){v_c_2426, v_outPath_240, v_done_242}), v_o_243, v_z_244, v_z_245));
}
V g_heff_2ebuild_2ecommands_2ewriteOutC_24s1877451407x355012956_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ewriteOutC_24s1877451407x355012956(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2ebuild_2ecommands_2ewriteOutC_24s1877451407x355012956_lam0(V self, V *args) {
  V v_r_2412 = args[0];
  return v_r_2412;
}
V g_heff_2ebuild_2ecommands_2ewriteOutC_24s1877451407x355012956_lam2(V self, V *args) {
  V v_hd_2424 = args[0];
  V v_k_2425 = args[1];
  V v_x_2423 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2424);
  V f_ = v_k_2425;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2423});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ewriteOutC_24s1877451407x355012956_lam1(V self, V *args) {
  V v_x_2420 = args[0];
  switch (heff_tag_of(v_x_2420)) {
  case TAG_Left: {
    V v_err_2421 = heff_field(v_x_2420, 0);
    V v_ru_24x_2420_24Left = heff_take_reuse_n(v_x_2420, 1ULL, 1);
    V v_t_2422 = heff_tag_at_n(v_ru_24x_2420_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_err_2421})});
    return (g_co_2eop_24s1998166633x1971890408(v_t_2422));
  }
  case TAG_Right: {
    V v_x_2423 = heff_field(v_x_2420, 0);
    heff_take_n(v_x_2420, 1ULL, 1);
    return heff_clo_n(g_heff_2ebuild_2ecommands_2ewriteOutC_24s1877451407x355012956_lam2, 2, 1, (V[]){v_x_2423});
  }
  default: return heff_nomatch(v_x_2420);
  }
}
V g_heff_2ebuild_2ecommands_2ewriteOutC_24s1877451407x355012956_lam5(V self, V *args) {
  V v_x_2444 = args[0];
  V v_hd_2427 = heff_env(self)[0];
  V v_k_2428 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2444);
  return (g_co_2eop_24s40508559x1835373952(MK_INT(1LL), v_hd_2427, v_k_2428));
}
V g_heff_2ebuild_2ecommands_2ewriteOutC_24s1877451407x355012956_lam4(V self, V *args) {
  V v_x_2429 = args[0];
  V v_outPath_240 = heff_env(self)[0];
  V v_hd_2427 = heff_env(self)[1];
  V v_k_2428 = heff_env(self)[2];
  V v_done_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  switch (heff_tag_of(v_x_2429)) {
  case TAG_Left: {
    V v_ru_24x_2429_24Left = heff_take_reuse_n(v_x_2429, 0ULL, 1);
    heff_drop(v_done_242);
    int64_t v_t_2431 = (heff_unbox_word(heff_strLength_lent(v_outPath_240, 0)) - ((int64_t)2ULL));
    V v_t_2432 = heff_strSlice(heff_dup(v_outPath_240), heff_box_word(v_t_2431), heff_strLength_lent(v_outPath_240, 0));
    V v_t_2434;
    if (heff_strEq_c(v_t_2432, ((V)&g_heff_2ebuild_2ecommands_2ewriteOutC_24s1877451407x355012956_str2))) {
      int64_t v_t_2433 = (heff_unbox_word(heff_strLength_lent(v_outPath_240, 0)) - ((int64_t)2ULL));
      v_t_2434 = heff_strSlice(v_outPath_240, MK_INT(0LL), heff_box_word(v_t_2433));
    } else {
      v_t_2434 = v_outPath_240;
    }
    V v_t_2435 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ewriteOutC_24s1877451407x355012956_str3), heff_strAppend(v_t_2434, ((V)&g_heff_2ebuild_2ecommands_2ewriteOutC_24s1877451407x355012956_str4)));
    V v_t_2436 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_t_2435, ((V)&g_heff_2ebuild_2ecommands_2ewriteOutC_24s1877451407x355012956_str5)), NTAG(TAG_MkUnit)});
    V v_t_2437 = heff_tag_at_n(v_ru_24x_2429_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2436})});
    V v_t_2438 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2437})});
    V v_t_2439 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2438})});
    V v_t_2440 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2439})});
    V v_t_2441 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2440})});
    V v_t_2442 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2441})});
    V v_t_2443 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_2427, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2442})}));
    V f_ = heff_dup(heff_rfield(v_hd_2427, 1));
    heff_room[0] = v_t_2443;
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ewriteOutC_24s1877451407x355012956_lam5, 1, 2, (V[]){v_hd_2427, v_k_2428});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_Right: {
    heff_take_n(v_x_2429, 0ULL, 1);
    heff_drop(v_outPath_240);
    V f_ = v_done_242;
    heff_room[0] = v_hd_2427;
    heff_room[1] = v_k_2428;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  default: return heff_nomatch(v_x_2429);
  }
}
V g_heff_2ebuild_2ecommands_2ewriteOutC_24s1877451407x355012956_lam3(V self, V *args) {
  V v_hd_2427 = args[0];
  V v_k_2428 = args[1];
  V v_c_2426 = heff_env(self)[0];
  V v_outPath_240 = heff_env(self)[1];
  V v_done_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_2426;
  args[0] = heff_dup(v_hd_2427);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ewriteOutC_24s1877451407x355012956_lam4, 1, 4, (V[]){v_outPath_240, v_hd_2427, v_k_2428, v_done_242});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s411846885x505187560_str0, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s411846885x505187560_str1, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s411846885x505187560_str2, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s411846885x505187560_str3, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s411846885x505187560_str4, 9, "runtime.c");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s411846885x505187560_str5, 11, "runtime.zig");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s411846885x505187560_str6, 6, "heff: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s411846885x505187560_str7, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s411846885x505187560_str8, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s411846885x505187560_str9, 6, "heff: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s411846885x505187560_str10, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s411846885x505187560_str11, 15, "no files given\012");
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s411846885x505187560_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s411846885x505187560_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s411846885x505187560_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s411846885x505187560_lam0(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s411846885x505187560_lam4(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ecompileLastC_24s411846885x505187560_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecompileLastC_24s411846885x505187560_entry, 10, 0};

V g_heff_2ebuild_2ecommands_2ecompileLastC_24s411846885x505187560(V v_lit_240, V v_bi_241, V v_sources_242, V v_file_243, V v_outPath_244, V v_failed_245, V v_done_246, V v_cs_247, V v_z_248, V v_z_249) {
top: ;
  HeffT2 v_t_2410 = (g_heff_2ebuild_2edriver_2elastChecked_24cpr(v_cs_247));
  {
    V v_field_2412 = v_t_2410.f[1];
    int64_t v_tag_2411 = ((int64_t)v_t_2410.f[0]);
    if ((v_tag_2411 == ((int64_t)0ULL))) {
      V v_c_2413 = v_field_2412;
      V v_t_2414 = (g_heff_2ebuild_2edriver_2ecandidatesOf(heff_dup(v_c_2413)));
      V v_t_2415 = ({ V a_0 = v_t_2414; V r_ = (g_heff_2ebuild_2edriver_2ecandLeaves(a_0)); heff_drop(v_t_2414); r_; });
      V v_t_2416 = (g_heff_2ebuild_2edriver_2enubStrD(v_t_2415));
      V v_xs_2417 = ({ V b_0 = ((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s411846885x505187560_str0); V a_1 = MK_INT(0LL); V b_2 = ((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s411846885x505187560_str1); V b_3 = MK_INT(0LL); V a_4 = ((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s411846885x505187560_str2); V a_5 = ((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s411846885x505187560_str3); V a_6 = v_t_2416; V r_ = (g_list_2emap_24s803586165x1676441765(b_0, a_1, b_2, b_3, a_4, a_5, a_6)); heff_drop(b_0); heff_drop(b_2); heff_drop(b_3); r_; });
      V v_t_2418 = (g_heff_2ebuild_2ecommands_2enubStrGo(NTAG(TAG_Nil), v_xs_2417));
      V v_c_2419 = (g_heff_2ebuild_2ecommands_2ereadProvidersC_24s1269697684x380235586(v_sources_242, v_t_2418));
      return heff_tail(v_c_2419, 2, (V[]){heff_dup(v_z_248), heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileLastC_24s411846885x505187560_lam0, 1, 9, (V[]){v_z_248, v_c_2413, v_file_243, v_failed_245, v_z_249, v_lit_240, v_bi_241, v_outPath_244, v_done_246})});
    } else {
      heff_drop(v_lit_240);
      heff_drop(v_bi_241);
      heff_drop(v_file_243);
      heff_drop(v_outPath_244);
      heff_drop(v_failed_245);
      heff_drop(v_done_246);
      heff_drop(v_field_2412);
      V v_t_2449 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s411846885x505187560_str11), NTAG(TAG_MkUnit)});
      V v_t_2450 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2449})});
      V v_t_2451 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2450})});
      V v_t_2452 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2451})});
      V v_t_2453 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2452})});
      V v_t_2454 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2453})});
      V v_t_2455 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2454})});
      V v_t_2456 = heff_tr(heff_call(heff_dup(heff_rfield(v_z_248, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2455})}));
      return heff_tail(heff_dup(heff_rfield(v_z_248, 1)), 2, (V[]){v_t_2456, heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileLastC_24s411846885x505187560_lam4, 1, 2, (V[]){v_z_248, v_z_249})});
    }
  }
}
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s411846885x505187560_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V a7 = a[7]; V r = g_heff_2ebuild_2ecommands_2ecompileLastC_24s411846885x505187560(a[0], a[1], a2, a[3], a[4], a[5], a[6], a7, a[8], a[9]); heff_drop(a2); heff_drop(a7); return r;
}
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s411846885x505187560_lam3(V self, V *args) {
  V v_x_2443 = args[0];
  V v_file_243 = heff_env(self)[0];
  V v_failed_245 = heff_env(self)[1];
  V v_why_2432 = heff_env(self)[2];
  V v_z_248 = heff_env(self)[3];
  V v_z_249 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2443);
  V v_t_2444 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s411846885x505187560_str9), v_file_243), ((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s411846885x505187560_str10));
  V f_ = v_failed_245;
  heff_room[0] = heff_strAppend(v_t_2444, v_why_2432);
  heff_room[1] = v_z_248;
  heff_room[2] = v_z_249;
  if (heff_exact(f_, 3, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 3, (V[]){heff_room[0], heff_room[1], heff_room[2]});
}
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s411846885x505187560_lam2(V self, V *args) {
  V v_x_2422 = args[0];
  V v_c_2413 = heff_env(self)[0];
  V v_x_2420 = heff_env(self)[1];
  V v_file_243 = heff_env(self)[2];
  V v_z_248 = heff_env(self)[3];
  V v_failed_245 = heff_env(self)[4];
  V v_z_249 = heff_env(self)[5];
  V v_lit_240 = heff_env(self)[6];
  V v_bi_241 = heff_env(self)[7];
  V v_outPath_244 = heff_env(self)[8];
  V v_x_2421 = heff_env(self)[9];
  V v_done_246 = heff_env(self)[10];
  heff_clo_take(self, 11);
  V v_t_2423 = (g_heff_2ebuild_2edriver_2ecandidatesOf(heff_dup(v_c_2413)));
  V v_t_2424 = ({ V a_0 = v_t_2423; V r_ = (g_heff_2ebuild_2edriver_2ecandLeaves(a_0)); heff_drop(v_t_2423); r_; });
  V v_leaves_2425 = (g_heff_2ebuild_2edriver_2enubStrD(v_t_2424));
  V v_t_2426 = heff_get_n(heff_dup(heff_rfield(v_c_2413, 5)), 0, 10);
  V v_t_2427 = heff_tr(heff_call(((V)&g_heff_2ebuild_2ecommands_2eprovidesLeafC_clo), 1, (V[]){heff_dup(v_x_2420)}));
  V v_t_2428 = (g_list_2emap_24s164225955x66209884(v_t_2426, v_t_2427, v_leaves_2425));
  HeffT2 v_t_2429 = (g_heff_2ecompile_2eglue_2eeithers_24cpr(v_t_2428));
  {
    V v_field_2431 = v_t_2429.f[1];
    int64_t v_tag_2430 = ((int64_t)v_t_2429.f[0]);
    if ((v_tag_2430 == ((int64_t)0ULL))) {
      heff_drop(v_x_2422);
      heff_drop_rec(v_c_2413, 14);
      heff_drop(v_x_2420);
      heff_drop(v_lit_240);
      heff_drop(v_bi_241);
      heff_drop(v_outPath_244);
      heff_drop(v_x_2421);
      heff_drop(v_done_246);
      V v_why_2432 = v_field_2431;
      V v_t_2433 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s411846885x505187560_str6), heff_dup(v_file_243)), ((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s411846885x505187560_str7));
      V v_t_2434 = heff_strAppend(heff_strAppend(v_t_2433, heff_dup(v_why_2432)), ((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s411846885x505187560_str8));
      V v_t_2435 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2434, NTAG(TAG_MkUnit)});
      V v_t_2436 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2435})});
      V v_t_2437 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2436})});
      V v_t_2438 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2437})});
      V v_t_2439 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2438})});
      V v_t_2440 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2439})});
      V v_t_2441 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2440})});
      V v_t_2442 = heff_tr(heff_call(heff_dup(heff_rfield(v_z_248, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2441})}));
      V f_ = heff_dup(heff_rfield(v_z_248, 1));
      heff_room[0] = v_t_2442;
      heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileLastC_24s411846885x505187560_lam3, 1, 5, (V[]){v_file_243, v_failed_245, v_why_2432, v_z_248, v_z_249});
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    } else {
      V v_ms_2445 = v_field_2431;
      V v_glues_2446 = (g_heff_2ecompile_2eglue_2ejusts(v_ms_2445));
      V v_t_2447 = (g_list_2emap_24s1435185561x202019164(v_glues_2446));
      V v_t_2448 = (g_prelude_2e_2b_2b(v_x_2420, v_t_2447));
      return (g_heff_2ebuild_2ecommands_2ecompileFoundC_24s635295480x634262112(v_lit_240, v_bi_241, v_file_243, v_outPath_244, heff_rec_n(2, shape_c__zig, (V[]){v_x_2421, v_x_2422}), v_failed_245, v_done_246, v_c_2413, v_t_2448, v_z_248, v_z_249));
    }
  }
}
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s411846885x505187560_lam1(V self, V *args) {
  V v_x_2421 = args[0];
  V v_z_248 = heff_env(self)[0];
  V v_c_2413 = heff_env(self)[1];
  V v_x_2420 = heff_env(self)[2];
  V v_file_243 = heff_env(self)[3];
  V v_failed_245 = heff_env(self)[4];
  V v_z_249 = heff_env(self)[5];
  V v_lit_240 = heff_env(self)[6];
  V v_bi_241 = heff_env(self)[7];
  V v_outPath_244 = heff_env(self)[8];
  V v_done_246 = heff_env(self)[9];
  heff_clo_take(self, 10);
  return (g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s1290075703x1224649709(((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s411846885x505187560_str5), heff_dup(v_z_248), heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileLastC_24s411846885x505187560_lam2, 1, 11, (V[]){v_c_2413, v_x_2420, v_file_243, v_z_248, v_failed_245, v_z_249, v_lit_240, v_bi_241, v_outPath_244, v_x_2421, v_done_246})));
}
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s411846885x505187560_lam0(V self, V *args) {
  V v_x_2420 = args[0];
  V v_z_248 = heff_env(self)[0];
  V v_c_2413 = heff_env(self)[1];
  V v_file_243 = heff_env(self)[2];
  V v_failed_245 = heff_env(self)[3];
  V v_z_249 = heff_env(self)[4];
  V v_lit_240 = heff_env(self)[5];
  V v_bi_241 = heff_env(self)[6];
  V v_outPath_244 = heff_env(self)[7];
  V v_done_246 = heff_env(self)[8];
  heff_clo_take(self, 9);
  return (g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s1290075703x1224649709(((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s411846885x505187560_str4), heff_dup(v_z_248), heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileLastC_24s411846885x505187560_lam1, 1, 10, (V[]){v_z_248, v_c_2413, v_x_2420, v_file_243, v_failed_245, v_z_249, v_lit_240, v_bi_241, v_outPath_244, v_done_246})));
}
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s411846885x505187560_lam4(V self, V *args) {
  V v_x_2457 = args[0];
  V v_z_248 = heff_env(self)[0];
  V v_z_249 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2457);
  return (g_co_2eop_24s40508559x1835373952(MK_INT(1LL), v_z_248, v_z_249));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ediagCount_24s823746706x1248851912_str0, 2, ": ");
V g_heff_2ebuild_2ecommands_2ediagCount_24s823746706x1248851912_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ediagCount_24s823746706x1248851912_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ediagCount_24s823746706x1248851912_lam0, 2, 0};
V g_heff_2ebuild_2ecommands_2ediagCount_24s823746706x1248851912_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ediagCount_24s823746706x1248851912_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ediagCount_24s823746706x1248851912_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ediagCount_24s823746706x1248851912_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ediagCount_24s823746706x1248851912_entry, 1, 0};

V g_heff_2ebuild_2ecommands_2ediagCount_24s823746706x1248851912(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return ((V)&g_heff_2ebuild_2ecommands_2ediagCount_24s823746706x1248851912_lam0_clo);
  }
  case TAG_Cons: {
    V v_c_243 = heff_field(v_x1_240, 0);
    V v_rest_244 = heff_field(v_x1_240, 1);
    V v_diags_245 = heff_dup(heff_rfield(v_c_243, 6));
    V v_module_246 = heff_dup(heff_rfield(v_c_243, 0));
    V v_t_247 = (g_list_2emap_24s328934344x1728860012(((V)&g_heff_2ebuild_2ecommands_2ediagCount_24s823746706x1248851912_str0), heff_dup(v_diags_245)));
    return heff_clo_n(g_heff_2ebuild_2ecommands_2ediagCount_24s823746706x1248851912_lam1, 2, 4, (V[]){v_module_246, v_t_247, heff_dup(v_rest_244), v_diags_245});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2ecommands_2ediagCount_24s823746706x1248851912_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2ediagCount_24s823746706x1248851912(a0); heff_drop(a0); return r;
}
V g_heff_2ebuild_2ecommands_2ediagCount_24s823746706x1248851912_lam0(V self, V *args) {
  V v_hd_241 = args[0];
  V v_k_242 = args[1];
  heff_drop(v_hd_241);
  V f_ = v_k_242;
  args[0] = MK_INT(0LL);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ediagCount_24s823746706x1248851912_lam3(V self, V *args) {
  V v_x_2412 = args[0];
  V v_diags_245 = heff_env(self)[0];
  V v_k_249 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2413 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_diags_245; V r_ = (g_list_2efoldl_24f2094160282x1876485468(a_0, a_1, a_2)); heff_drop(v_diags_245); r_; });
  V v_x_2414 = heff_intAdd(v_t_2413, v_x_2412);
  V f_ = v_k_249;
  args[0] = v_x_2414;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ediagCount_24s823746706x1248851912_lam2(V self, V *args) {
  V v_x_2410 = args[0];
  V v_rest_244 = heff_env(self)[0];
  V v_hd_248 = heff_env(self)[1];
  V v_diags_245 = heff_env(self)[2];
  V v_k_249 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2410);
  V v_c_2411 = ({ V a_0 = v_rest_244; V r_ = (g_heff_2ebuild_2ecommands_2ediagCount_24s823746706x1248851912(a_0)); heff_drop(v_rest_244); r_; });
  V f_ = v_c_2411;
  heff_room[0] = v_hd_248;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ediagCount_24s823746706x1248851912_lam3, 1, 2, (V[]){v_diags_245, v_k_249});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ediagCount_24s823746706x1248851912_lam1(V self, V *args) {
  V v_hd_248 = args[0];
  V v_k_249 = args[1];
  V v_module_246 = heff_env(self)[0];
  V v_t_247 = heff_env(self)[1];
  V v_rest_244 = heff_env(self)[2];
  V v_diags_245 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2ebuild_2ecommands_2eprintErrs_24s115117455x797094904(v_module_246, v_t_247, MK_INT(0LL), heff_dup(v_hd_248), heff_clo_n(g_heff_2ebuild_2ecommands_2ediagCount_24s823746706x1248851912_lam2, 1, 4, (V[]){v_rest_244, v_hd_248, v_diags_245, v_k_249})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2esystemOnly_24s454269400x904232931_str0, 3, ".hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2esystemOnly_24s454269400x904232931_str1, 11, ".provider.c");
HEFF_LIT(g_heff_2ebuild_2ecommands_2esystemOnly_24s454269400x904232931_str2, 3, ".hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2esystemOnly_24s454269400x904232931_str3, 12, ".provider.js");
HEFF_LIT(g_heff_2ebuild_2ecommands_2esystemOnly_24s454269400x904232931_str4, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2esystemOnly_24s454269400x904232931_str5, 1, "\012");
V g_heff_2ebuild_2ecommands_2esystemOnly_24s454269400x904232931_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2esystemOnly_24s454269400x904232931_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2esystemOnly_24s454269400x904232931_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2esystemOnly_24s454269400x904232931_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2esystemOnly_24s454269400x904232931_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2esystemOnly_24s454269400x904232931_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2esystemOnly_24s454269400x904232931_lam1, 1, 0};
V g_heff_2ebuild_2ecommands_2esystemOnly_24s454269400x904232931_lam5(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2esystemOnly_24s454269400x904232931_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2esystemOnly_24s454269400x904232931_lam5, 1, 0};
V g_heff_2ebuild_2ecommands_2esystemOnly_24s454269400x904232931_lam7(V self, V *args);
V g_heff_2ebuild_2ecommands_2esystemOnly_24s454269400x904232931_lam6(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2esystemOnly_24s454269400x904232931_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2esystemOnly_24s454269400x904232931_lam6, 1, 0};
V g_heff_2ebuild_2ecommands_2esystemOnly_24s454269400x904232931_lam8(V self, V *args);
V g_heff_2ebuild_2ecommands_2esystemOnly_24s454269400x904232931_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2esystemOnly_24s454269400x904232931_lam3(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2esystemOnly_24s454269400x904232931_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2esystemOnly_24s454269400x904232931_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2esystemOnly_24s454269400x904232931(V v_host_240, V v_s_241) {
top: ;
  V v_p_242 = heff_dup(heff_rfield(v_s_241, 2));
  int64_t v_t_243 = (heff_unbox_word(heff_strLength_lent(v_p_242, 0)) - ((int64_t)3ULL));
  V v_t_244 = heff_strSlice(heff_dup(v_p_242), heff_box_word(v_t_243), heff_strLength_lent(v_p_242, 0));
  V v_t_246;
  if (heff_strEq_c(v_t_244, ((V)&g_heff_2ebuild_2ecommands_2esystemOnly_24s454269400x904232931_str0))) {
    int64_t v_t_245 = (heff_unbox_word(heff_strLength_lent(v_p_242, 0)) - ((int64_t)3ULL));
    v_t_246 = heff_strSlice(v_p_242, MK_INT(0LL), heff_box_word(v_t_245));
  } else {
    v_t_246 = v_p_242;
  }
  V v_s_247 = heff_strAppend(v_t_246, ((V)&g_heff_2ebuild_2ecommands_2esystemOnly_24s454269400x904232931_str1));
  V v_path_248 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_s_247));
  V v_t_249 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_248; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_248); r_; });
  V v_a_2411 = heff_tag_n(TAG_ReadFile, 2, (V[]){v_t_249, ((V)&g_heff_2ebuild_2ecommands_2esystemOnly_24s454269400x904232931_lam0_clo)});
  V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2411})});
  V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
  V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
  V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
  V v_t_2416 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2416})});
  V v_c_2424 = heff_tr(g_co_2eop_24s1398690846x1918384825(heff_tag_n(TAG_InR, 1, (V[]){v_t_2417}), heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), ((V)&g_heff_2ebuild_2ecommands_2esystemOnly_24s454269400x904232931_lam1_clo)));
  return heff_clo_n(g_heff_2ebuild_2ecommands_2esystemOnly_24s454269400x904232931_lam3, 2, 3, (V[]){v_c_2424, v_s_241, heff_dup(v_host_240)});
}
V g_heff_2ebuild_2ecommands_2esystemOnly_24s454269400x904232931_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2esystemOnly_24s454269400x904232931(a0, a[1]); heff_drop(a0); return r;
}
V g_heff_2ebuild_2ecommands_2esystemOnly_24s454269400x904232931_lam0(V self, V *args) {
  V v_r_2410 = args[0];
  return v_r_2410;
}
V g_heff_2ebuild_2ecommands_2esystemOnly_24s454269400x904232931_lam2(V self, V *args) {
  V v_hd_2422 = args[0];
  V v_k_2423 = args[1];
  V v_x_2421 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2422);
  V f_ = v_k_2423;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2421});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2esystemOnly_24s454269400x904232931_lam1(V self, V *args) {
  V v_x_2418 = args[0];
  switch (heff_tag_of(v_x_2418)) {
  case TAG_Left: {
    V v_err_2419 = heff_field(v_x_2418, 0);
    V v_ru_24x_2418_24Left = heff_take_reuse_n(v_x_2418, 1ULL, 1);
    V v_t_2420 = heff_tag_at_n(v_ru_24x_2418_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_err_2419})});
    return (g_co_2eop_24s1998166633x1971890408(v_t_2420));
  }
  case TAG_Right: {
    V v_x_2421 = heff_field(v_x_2418, 0);
    heff_take_n(v_x_2418, 1ULL, 1);
    return heff_clo_n(g_heff_2ebuild_2ecommands_2esystemOnly_24s454269400x904232931_lam2, 2, 1, (V[]){v_x_2421});
  }
  default: return heff_nomatch(v_x_2418);
  }
}
V g_heff_2ebuild_2ecommands_2esystemOnly_24s454269400x904232931_lam5(V self, V *args) {
  V v_r_2439 = args[0];
  return v_r_2439;
}
V g_heff_2ebuild_2ecommands_2esystemOnly_24s454269400x904232931_lam7(V self, V *args) {
  V v_hd_2451 = args[0];
  V v_k_2452 = args[1];
  V v_x_2450 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2451);
  V f_ = v_k_2452;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2450});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2esystemOnly_24s454269400x904232931_lam6(V self, V *args) {
  V v_x_2447 = args[0];
  switch (heff_tag_of(v_x_2447)) {
  case TAG_Left: {
    V v_err_2448 = heff_field(v_x_2447, 0);
    V v_ru_24x_2447_24Left = heff_take_reuse_n(v_x_2447, 1ULL, 1);
    V v_t_2449 = heff_tag_at_n(v_ru_24x_2447_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_err_2448})});
    return (g_co_2eop_24s1998166633x1971890408(v_t_2449));
  }
  case TAG_Right: {
    V v_x_2450 = heff_field(v_x_2447, 0);
    heff_take_n(v_x_2447, 1ULL, 1);
    return heff_clo_n(g_heff_2ebuild_2ecommands_2esystemOnly_24s454269400x904232931_lam7, 2, 1, (V[]){v_x_2450});
  }
  default: return heff_nomatch(v_x_2447);
  }
}
V g_heff_2ebuild_2ecommands_2esystemOnly_24s454269400x904232931_lam8(V self, V *args) {
  V v_x_2454 = args[0];
  V v_x_2430 = heff_env(self)[0];
  V v_k_2426 = heff_env(self)[1];
  V v_host_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_x_2454)) {
  case TAG_Left: {
    heff_take_n(v_x_2454, 0ULL, 1);
    heff_drop(v_host_240);
    V v_t_2457;
    switch (heff_tag_of(v_x_2430)) {
    case TAG_Nothing: {
      v_t_2457 = NTAG(TAG_False);
      break;
    }
    case TAG_Just: {
      heff_take_n(v_x_2430, 0ULL, 1);
      v_t_2457 = NTAG(TAG_True);
      break;
    }
    default: heff_nomatch(v_x_2430);
    }
    V f_ = v_k_2426;
    args[0] = v_t_2457;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Right: {
    V v_y_2458 = heff_field(v_x_2454, 0);
    heff_take_n(v_x_2454, 1ULL, 1);
    V v_x_2465;
    switch (heff_tag_of(v_x_2430)) {
    case TAG_Nothing: {
      heff_drop(v_host_240);
      heff_drop(v_y_2458);
      v_x_2465 = NTAG(TAG_False);
      break;
    }
    case TAG_Just: {
      heff_take_n(v_x_2430, 0ULL, 1);
      V v_t_2460 = ({ V b_0 = ((V)&g_heff_2ebuild_2ecommands_2esystemOnly_24s454269400x904232931_str4); V a_1 = v_y_2458; V a_2 = MK_INT(0LL); V a_3 = heff_strFind_lent(((V)&g_heff_2ebuild_2ecommands_2esystemOnly_24s454269400x904232931_str5), v_y_2458, MK_INT(0LL), 5); V a_4 = NTAG(TAG_Nil); V r_ = (g_prelude_2esplitFrom(b_0, a_1, a_2, a_3, a_4)); heff_drop(b_0); heff_drop(v_y_2458); r_; });
      V v_t_2461 = (g_list_2emap_24s649333309x1802289391(v_t_2460));
      V v_x1_2462 = (g_heff_2ecompile_2eemit_2ecatMaybesL(v_t_2461));
      switch (heff_tag_of(v_x1_2462)) {
      case TAG_Nil: {
        heff_drop(v_host_240);
        v_x_2465 = NTAG(TAG_False);
        break;
      }
      case TAG_Cons: {
        V v_x_2463 = heff_field(v_x1_2462, 0);
        heff_take_n(v_x1_2462, 1ULL, 2);
        v_x_2465 = heff_bool(!heff_strEq_c_lent(v_x_2463, v_host_240, 0));
        heff_drop(v_host_240);
        heff_drop(v_x_2463);
        break;
      }
      default: heff_nomatch(v_x1_2462);
      }
      break;
    }
    default: heff_nomatch(v_x_2430);
    }
    V f_ = v_k_2426;
    args[0] = v_x_2465;
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_2454);
  }
}
V g_heff_2ebuild_2ecommands_2esystemOnly_24s454269400x904232931_lam4(V self, V *args) {
  V v_x_2427 = args[0];
  V v_s_241 = heff_env(self)[0];
  V v_hd_2425 = heff_env(self)[1];
  V v_k_2426 = heff_env(self)[2];
  V v_host_240 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_x_2430;
  switch (heff_tag_of(v_x_2427)) {
  case TAG_Left: {
    heff_take_n(v_x_2427, 0ULL, 1);
    v_x_2430 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_Right: {
    V v_y_2429 = heff_field(v_x_2427, 0);
    V v_ru_24x_2427_24Right = heff_take_reuse_n(v_x_2427, 1ULL, 1);
    v_x_2430 = heff_tag_at_n(v_ru_24x_2427_24Right, TAG_Just, 1, (V[]){v_y_2429});
    break;
  }
  default: heff_nomatch(v_x_2427);
  }
  V v_p_2431 = heff_get_n(v_s_241, 2, 8);
  int64_t v_t_2432 = (heff_unbox_word(heff_strLength_lent(v_p_2431, 0)) - ((int64_t)3ULL));
  V v_t_2433 = heff_strSlice(heff_dup(v_p_2431), heff_box_word(v_t_2432), heff_strLength_lent(v_p_2431, 0));
  V v_t_2435;
  if (heff_strEq_c(v_t_2433, ((V)&g_heff_2ebuild_2ecommands_2esystemOnly_24s454269400x904232931_str2))) {
    int64_t v_t_2434 = (heff_unbox_word(heff_strLength_lent(v_p_2431, 0)) - ((int64_t)3ULL));
    v_t_2435 = heff_strSlice(v_p_2431, MK_INT(0LL), heff_box_word(v_t_2434));
  } else {
    v_t_2435 = v_p_2431;
  }
  V v_s_2436 = heff_strAppend(v_t_2435, ((V)&g_heff_2ebuild_2ecommands_2esystemOnly_24s454269400x904232931_str3));
  V v_path_2437 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_s_2436));
  V v_t_2438 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2437; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_2437); r_; });
  V v_a_2440 = heff_tag_n(TAG_ReadFile, 2, (V[]){v_t_2438, ((V)&g_heff_2ebuild_2ecommands_2esystemOnly_24s454269400x904232931_lam5_clo)});
  V v_t_2441 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2440})});
  V v_t_2442 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2441})});
  V v_t_2443 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2442})});
  V v_t_2444 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2443})});
  V v_t_2445 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2444})});
  V v_t_2446 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2445})});
  V v_c_2453 = heff_tr(g_co_2eop_24s1398690846x1918384825(heff_tag_n(TAG_InR, 1, (V[]){v_t_2446}), heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), ((V)&g_heff_2ebuild_2ecommands_2esystemOnly_24s454269400x904232931_lam6_clo)));
  V f_ = v_c_2453;
  heff_room[0] = v_hd_2425;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2esystemOnly_24s454269400x904232931_lam8, 1, 3, (V[]){v_x_2430, v_k_2426, v_host_240});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2esystemOnly_24s454269400x904232931_lam3(V self, V *args) {
  V v_hd_2425 = args[0];
  V v_k_2426 = args[1];
  V v_c_2424 = heff_env(self)[0];
  V v_s_241 = heff_env(self)[1];
  V v_host_240 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_2424;
  args[0] = heff_dup(v_hd_2425);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2esystemOnly_24s454269400x904232931_lam4, 1, 4, (V[]){v_s_241, v_hd_2425, v_k_2426, v_host_240});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildPrograms_24s218921097x875862419_str0, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildPrograms_24s218921097x875862419_str1, 5, "build");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildPrograms_24s218921097x875862419_str2, 17, "building programs");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildPrograms_24s218921097x875862419_str3, 14, "installing in ");
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s218921097x875862419_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ebuildPrograms_24s218921097x875862419_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildPrograms_24s218921097x875862419_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s218921097x875862419_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s218921097x875862419_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ebuildPrograms_24s218921097x875862419_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildPrograms_24s218921097x875862419_lam1, 1, 0};
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s218921097x875862419_lam4(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ebuildPrograms_24s218921097x875862419_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildPrograms_24s218921097x875862419_lam4, 1, 0};
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s218921097x875862419_lam7(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ebuildPrograms_24s218921097x875862419_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildPrograms_24s218921097x875862419_lam7, 1, 0};
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s218921097x875862419_lam10(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s218921097x875862419_lam9(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s218921097x875862419_lam8(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s218921097x875862419_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s218921097x875862419_lam12(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s218921097x875862419_lam11(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s218921097x875862419_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s218921097x875862419_lam3(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ebuildPrograms_24s218921097x875862419_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildPrograms_24s218921097x875862419_entry, 6, 0};

V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s218921097x875862419(V v_st_240, V v_t_241, V v_done_242, V v_progs_243, V v_z_244, V v_z_245) {
top: ;
  V v_t_246 = (g_std_2epath_2eparse(heff_dup(v_st_240), ((V)&g_heff_2ebuild_2ecommands_2ebuildPrograms_24s218921097x875862419_str0)));
  V v_t_247 = (g_std_2epath_2eparse(heff_dup(v_st_240), ((V)&g_heff_2ebuild_2ecommands_2ebuildPrograms_24s218921097x875862419_str1)));
  V v_t_248 = (g_std_2epath_2ejoin(v_t_246, v_t_247));
  V v_p_249 = ({ V a_0 = v_st_240; V a_1 = v_t_248; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_248); r_; });
  V v_t_2410 = (g_std_2epath_2eparse(heff_dup(v_st_240), heff_dup(heff_rfield(v_t_241, 0))));
  V v_t_2411 = (g_std_2epath_2eparse(heff_dup(v_st_240), v_p_249));
  V v_t_2412 = (g_std_2epath_2ejoin(v_t_2410, v_t_2411));
  V v_s_2413 = ({ V a_0 = v_st_240; V a_1 = v_t_2412; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2412); r_; });
  V v_path_2414 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_s_2413));
  V v_t_2415 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2414; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_2414); r_; });
  V v_a_2417 = heff_tag_n(TAG_MakeDirectory, 2, (V[]){v_t_2415, ((V)&g_heff_2ebuild_2ecommands_2ebuildPrograms_24s218921097x875862419_lam0_clo)});
  V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2417})});
  V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
  V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
  V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
  V v_t_2422 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
  V v_t_2423 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2422})});
  V v_c_2430 = heff_tr(g_co_2eop_24s1398690846x1918384825(heff_tag_n(TAG_InR, 1, (V[]){v_t_2423}), heff_dup(g_exception_2eattempted_24s85350750x49672201_get()), ((V)&g_heff_2ebuild_2ecommands_2ebuildPrograms_24s218921097x875862419_lam1_clo)));
  return heff_tail(v_c_2430, 2, (V[]){heff_dup(v_z_244), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildPrograms_24s218921097x875862419_lam3, 1, 6, (V[]){v_progs_243, v_z_244, v_st_240, v_t_241, v_done_242, v_z_245})});
}
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s218921097x875862419_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ebuildPrograms_24s218921097x875862419(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s218921097x875862419_lam0(V self, V *args) {
  V v_r_2416 = args[0];
  return v_r_2416;
}
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s218921097x875862419_lam2(V self, V *args) {
  V v_hd_2428 = args[0];
  V v_k_2429 = args[1];
  V v_x_2427 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2428);
  V f_ = v_k_2429;
  args[0] = heff_tag_n(TAG_Right, 1, (V[]){v_x_2427});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s218921097x875862419_lam1(V self, V *args) {
  V v_x_2424 = args[0];
  switch (heff_tag_of(v_x_2424)) {
  case TAG_Left: {
    V v_err_2425 = heff_field(v_x_2424, 0);
    V v_ru_24x_2424_24Left = heff_take_reuse_n(v_x_2424, 1ULL, 1);
    V v_t_2426 = heff_tag_at_n(v_ru_24x_2424_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_err_2425})});
    return (g_co_2eop_24s1998166633x1971890408(v_t_2426));
  }
  case TAG_Right: {
    V v_x_2427 = heff_field(v_x_2424, 0);
    heff_take_n(v_x_2424, 1ULL, 1);
    return heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildPrograms_24s218921097x875862419_lam2, 2, 1, (V[]){v_x_2427});
  }
  default: return heff_nomatch(v_x_2424);
  }
}
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s218921097x875862419_lam4(V self, V *args) {
  V v_t_2433 = args[0];
  return v_t_2433;
}
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s218921097x875862419_lam7(V self, V *args) {
  V v_t_2450 = args[0];
  return v_t_2450;
}
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s218921097x875862419_lam10(V self, V *args) {
  V v_x_2460 = args[0];
  V v_done_2440 = heff_env(self)[0];
  V v_hd_2458 = heff_env(self)[1];
  V v_k_2459 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2460);
  V f_ = v_done_2440;
  heff_room[0] = v_hd_2458;
  heff_room[1] = v_k_2459;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s218921097x875862419_lam9(V self, V *args) {
  V v_hd_2458 = args[0];
  V v_k_2459 = args[1];
  V v_x_2454 = heff_env(self)[0];
  V v_done_2440 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_co_2eop_24s1531911654x724325922(v_x_2454, heff_dup(v_hd_2458), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildPrograms_24s218921097x875862419_lam10, 1, 3, (V[]){v_done_2440, v_hd_2458, v_k_2459})));
}
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s218921097x875862419_lam8(V self, V *args) {
  V v_x_2454 = args[0];
  V v_progs_2441 = heff_env(self)[0];
  V v_st_2438 = heff_env(self)[1];
  V v_t_2439 = heff_env(self)[2];
  V v_home_2443 = heff_env(self)[3];
  V v_done_2440 = heff_env(self)[4];
  V v_hd_2448 = heff_env(self)[5];
  V v_k_2449 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2455 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_progs_2441));
  V v_xs_2456 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2455; V r_ = (g_list_2efoldl_24s1325969685x576913065(a_0, a_1)); heff_drop(v_t_2455); r_; });
  V v_t_2457 = (g_heff_2ebuild_2ecommands_2enubStrGo(NTAG(TAG_Nil), v_xs_2456));
  V v_t_2461 = ({ V a_0 = v_st_2438; V a_1 = v_t_2439; V a_2 = v_home_2443; V a_3 = heff_dup(v_x_2454); V a_4 = heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildPrograms_24s218921097x875862419_lam9, 2, 2, (V[]){v_x_2454, v_done_2440}); V a_5 = v_t_2457; V r_ = heff_tr(g_heff_2ebuild_2ecommands_2eshipAll_24s1159606914x1992617477(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_t_2457); r_; });
  V f_ = v_t_2461;
  heff_room[0] = v_hd_2448;
  heff_room[1] = v_k_2449;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s218921097x875862419_lam6(V self, V *args) {
  V v_hd_2448 = args[0];
  V v_k_2449 = args[1];
  V v_t_2447 = heff_env(self)[0];
  V v_total_2446 = heff_env(self)[1];
  V v_progs_2441 = heff_env(self)[2];
  V v_st_2438 = heff_env(self)[3];
  V v_t_2439 = heff_env(self)[4];
  V v_home_2443 = heff_env(self)[5];
  V v_done_2440 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2451 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){heff_dup(g_std_2eprogress_2eroot_get()), v_t_2447, v_total_2446, ((V)&g_heff_2ebuild_2ecommands_2ebuildPrograms_24s218921097x875862419_lam7_clo)})});
  V v_t_2452 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2451})});
  V v_t_2453 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_2448, 2)), 1, (V[]){v_t_2452}));
  V f_ = heff_dup(heff_rfield(v_hd_2448, 1));
  args[0] = v_t_2453;
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildPrograms_24s218921097x875862419_lam8, 1, 7, (V[]){v_progs_2441, v_st_2438, v_t_2439, v_home_2443, v_done_2440, v_hd_2448, v_k_2449});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s218921097x875862419_lam12(V self, V *args) {
  V v_x_2466 = args[0];
  V v_next_2463 = heff_env(self)[0];
  V v_hd_2464 = heff_env(self)[1];
  V v_k_2465 = heff_env(self)[2];
  heff_clo_take(self, 3);
  heff_drop(v_x_2466);
  V f_ = v_next_2463;
  heff_room[0] = v_hd_2464;
  heff_room[1] = v_k_2465;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s218921097x875862419_lam11(V self, V *args) {
  V v_hd_2464 = args[0];
  V v_k_2465 = args[1];
  V v_x_2437 = heff_env(self)[0];
  V v_next_2463 = heff_env(self)[1];
  heff_clo_take(self, 2);
  return (g_co_2eop_24s1531911654x724325922(v_x_2437, heff_dup(v_hd_2464), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildPrograms_24s218921097x875862419_lam12, 1, 3, (V[]){v_next_2463, v_hd_2464, v_k_2465})));
}
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s218921097x875862419_lam5(V self, V *args) {
  V v_x_2437 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_t_241 = heff_env(self)[1];
  V v_done_242 = heff_env(self)[2];
  V v_progs_243 = heff_env(self)[3];
  V v_z_244 = heff_env(self)[4];
  V v_z_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_st_2438 = heff_dup(v_st_240);
  V v_t_2439 = heff_dup(v_t_241);
  V v_done_2440 = v_done_242;
  V v_progs_2441 = heff_dup(v_progs_243);
  V v_x5_2442 = heff_dup(heff_rfield(v_t_241, 4));
  V v_t_2462;
  switch (heff_tag_of(v_x5_2442)) {
  case TAG_Nothing: {
    heff_drop(v_st_2438);
    heff_drop(v_t_2439);
    heff_drop(v_progs_2441);
    v_t_2462 = v_done_2440;
    break;
  }
  case TAG_Just: {
    V v_home_2443 = heff_field(v_x5_2442, 0);
    heff_take_n(v_x5_2442, 1ULL, 1);
    V v_t_2444 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_progs_2441)));
    V v_xs_2445 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2444; V r_ = (g_list_2efoldl_24s1325969685x576913065(a_0, a_1)); heff_drop(v_t_2444); r_; });
    V v_total_2446 = (g_list_2efoldl_24f1425140065x1254143828(MK_INT(1LL), MK_INT(0LL), NTAG(TAG_Nil), v_xs_2445));
    V v_t_2447 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ebuildPrograms_24s218921097x875862419_str3), heff_dup(v_home_2443));
    v_t_2462 = heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildPrograms_24s218921097x875862419_lam6, 2, 7, (V[]){v_t_2447, v_total_2446, v_progs_2441, v_st_2438, v_t_2439, v_home_2443, v_done_2440});
    break;
  }
  default: heff_nomatch(v_x5_2442);
  }
  V v_next_2463 = (g_heff_2ebuild_2ecommands_2eplaceIn_24s883176411x318999417(heff_dup(v_st_240), heff_dup(v_t_241), v_t_2462, v_progs_243));
  V v_t_2467 = ({ V a_0 = v_st_240; V a_1 = v_t_241; V a_2 = heff_dup(v_x_2437); V a_3 = heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildPrograms_24s218921097x875862419_lam11, 2, 2, (V[]){v_x_2437, v_next_2463}); V a_4 = v_progs_243; V r_ = heff_tr(g_heff_2ebuild_2ecommands_2ebuildEach_24s424977173x2143394812(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_progs_243); r_; });
  V f_ = v_t_2467;
  heff_room[0] = v_z_244;
  heff_room[1] = v_z_245;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s218921097x875862419_lam3(V self, V *args) {
  V v_x_2431 = args[0];
  V v_progs_243 = heff_env(self)[0];
  V v_z_244 = heff_env(self)[1];
  V v_st_240 = heff_env(self)[2];
  V v_t_241 = heff_env(self)[3];
  V v_done_242 = heff_env(self)[4];
  V v_z_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_2431);
  V v_total_2432 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_progs_243));
  V v_t_2434 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){heff_dup(g_std_2eprogress_2eroot_get()), ((V)&g_heff_2ebuild_2ecommands_2ebuildPrograms_24s218921097x875862419_str2), v_total_2432, ((V)&g_heff_2ebuild_2ecommands_2ebuildPrograms_24s218921097x875862419_lam4_clo)})});
  V v_t_2435 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2434})});
  V v_t_2436 = heff_tr(heff_call(heff_dup(heff_rfield(v_z_244, 2)), 1, (V[]){v_t_2435}));
  V f_ = heff_dup(heff_rfield(v_z_244, 1));
  heff_room[0] = v_t_2436;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildPrograms_24s218921097x875862419_lam5, 1, 6, (V[]){v_st_240, v_t_241, v_done_242, v_progs_243, v_z_244, v_z_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprintEvals_24s906160764x145037181_str0, 3, " = ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprintEvals_24s906160764x145037181_str1, 1, "\012");
V g_heff_2ebuild_2ecommands_2eprintEvals_24s906160764x145037181_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2eprintEvals_24s906160764x145037181_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eprintEvals_24s906160764x145037181_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eprintEvals_24s906160764x145037181_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2eprintEvals_24s906160764x145037181(V v_x1_240, V v_p_241, V v_p_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop_rec(v_p_241, 3);
    return heff_tail(v_p_242, 1, (V[]){NTAG(TAG_False)});
  }
  case TAG_Cons: {
    V v_d_243 = heff_field(v_x1_240, 0);
    V v_rest_244 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_name_245 = heff_take_field(v_d_243, 0);
    V v_value_246 = heff_take_field(v_d_243, 1);
    V v_bug_247 = heff_get_n(v_d_243, 2, 3);
    V v_t_248 = heff_strAppend(heff_strAppend(v_name_245, ((V)&g_heff_2ebuild_2ecommands_2eprintEvals_24s906160764x145037181_str0)), v_value_246);
    V v_t_249 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Write, 2, (V[]){heff_strAppend(v_t_248, ((V)&g_heff_2ebuild_2ecommands_2eprintEvals_24s906160764x145037181_str1)), NTAG(TAG_MkUnit)});
    V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
    V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
    V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
    V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
    V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
    V v_t_2415 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2414})});
    V v_t_2416 = heff_tr(heff_call(heff_dup(heff_rfield(v_p_241, 2)), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2415})}));
    return heff_tail(heff_dup(heff_rfield(v_p_241, 1)), 2, (V[]){v_t_2416, heff_clo_n(g_heff_2ebuild_2ecommands_2eprintEvals_24s906160764x145037181_lam0, 1, 4, (V[]){v_rest_244, v_p_241, v_bug_247, v_p_242})});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2ecommands_2eprintEvals_24s906160764x145037181_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eprintEvals_24s906160764x145037181(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2ecommands_2eprintEvals_24s906160764x145037181_lam1(V self, V *args) {
  V v_x_2418 = args[0];
  V v_bug_247 = heff_env(self)[0];
  V v_p_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2419 = heff_bool(((heff_dup(v_bug_247) == NTAG(TAG_True)) || (heff_dup(v_x_2418) == NTAG(TAG_True))));
  heff_drop(v_x_2418);
  heff_drop(v_bug_247);
  V f_ = v_p_242;
  args[0] = v_t_2419;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eprintEvals_24s906160764x145037181_lam0(V self, V *args) {
  V v_x_2417 = args[0];
  V v_rest_244 = heff_env(self)[0];
  V v_p_241 = heff_env(self)[1];
  V v_bug_247 = heff_env(self)[2];
  V v_p_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2417);
  return (g_heff_2ebuild_2ecommands_2eprintEvals_24s906160764x145037181(v_rest_244, v_p_241, heff_clo_n(g_heff_2ebuild_2ecommands_2eprintEvals_24s906160764x145037181_lam1, 1, 2, (V[]){v_bug_247, v_p_242})));
}