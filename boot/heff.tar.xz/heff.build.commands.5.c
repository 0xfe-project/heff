// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_End 17255
#define TAG_Exec 20138
#define TAG_Exit 20279
#define TAG_GetEnv 43934
#define TAG_Left 13886
#define TAG_MakeDirectory 16793
#define TAG_Move 53768
#define TAG_Platform 55558
#define TAG_Posix 44191
#define TAG_ReadDirectory 46629
#define TAG_ReadFile 6783
#define TAG_Remove 9747
#define TAG_Right 62770
#define TAG_RunUnder 28888
#define TAG_Start 63542
#define TAG_Windows 49101
#define TAG_Write 36323
#define TAG_WriteErr 37283
#define TAG_WriteFile 62589
#define LBL_apps 9496377
#define LBL_bad 306815
#define LBL_build 295453320
#define LBL_diags 296935042
#define LBL_done 9584713
#define LBL_ems 310085
#define LBL_errors 652506774
#define LBL_fresh 299054408
#define LBL_fuel 9649789
#define LBL_hashes 722717031
#define LBL_module 878357911
#define LBL_modules 1459291593
#define LBL_msg 317947
#define LBL_name 9869138
#define LBL_packages 1496006433
#define LBL_path 9928940
#define LBL_paths 307797256
#define LBL_root 10001833
#define LBL_s 333
#define LBL_said 10017968
#define LBL_source 1050636102
#define LBL_sources 357464573
#define LBL_style 311138763
#define LBL_text 10052084
static uint32_t shape_apps__bad[] = {LBL_apps, LBL_bad};
static uint32_t shape_ems__s__fresh[] = {LBL_ems, LBL_s, LBL_fresh};
static uint32_t shape_module__text[] = {LBL_module, LBL_text};
static uint32_t shape_name__build[] = {LBL_name, LBL_build};
static uint32_t shape_paths__hashes__modules__fuel[] = {LBL_paths, LBL_hashes, LBL_modules, LBL_fuel};
V g_co_2eop_24s1896221640x2141527803(V, V, V);
V g_co_2eop_24s1896221640x2141527803_entry(V self, V *a);
extern Clo g_co_2eop_24s1896221640x2141527803_clo;
V g_co_2eop_24s297957795x1045074450(V, V, V);
V g_co_2eop_24s297957795x1045074450_entry(V self, V *a);
extern Clo g_co_2eop_24s297957795x1045074450_clo;
V g_co_2eop_24s535099379x685970669(V, V, V);
V g_co_2eop_24s535099379x685970669_entry(V self, V *a);
extern Clo g_co_2eop_24s535099379x685970669_clo;
V g_heff_2ebuild_2ecache_2ehashGo(V, V, V, V);
V g_heff_2ebuild_2ecache_2ehashGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecache_2ehashGo_clo;
V g_heff_2ebuild_2ecommands_2eappFile(V, V, V, V);
V g_heff_2ebuild_2ecommands_2eappFile_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eappFile_clo;
V g_heff_2ebuild_2ecommands_2eappShips_24s230600905x194600621(V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eappShips_24s230600905x194600621_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eappShips_24s230600905x194600621_clo;
V g_heff_2ebuild_2ecommands_2ebackDirOf(V);
V g_heff_2ebuild_2ecommands_2ebackDirOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ebackDirOf_clo;
V g_heff_2ebuild_2ecommands_2ecCmd_24s2011829969x1168825100(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecCmd_24s2011829969x1168825100_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecCmd_24s2011829969x1168825100_clo;
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s1236085063x444027205(V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s1236085063x444027205_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecLoadedOr_24s1236085063x444027205_clo;
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s1841553671x896002290(V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecLoadedOr_24s1841553671x896002290_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecLoadedOr_24s1841553671x896002290_clo;
V g_heff_2ebuild_2ecommands_2ecompileDiags_24s373786925x1761510953(V, V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecompileDiags_24s373786925x1761510953_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecompileDiags_24s373786925x1761510953_clo;
V g_heff_2ebuild_2ecommands_2ecompileFound_24s773429454x742097977(V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecompileFound_24s773429454x742097977_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecompileFound_24s773429454x742097977_clo;
V g_heff_2ebuild_2ecommands_2ecompileJsOut_24s286675332x2033384300_24tok1(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecompileJsOut_24s286675332x2033384300_24tok1_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecompileJsOut_24s286675332x2033384300_24tok1_clo;
V g_heff_2ebuild_2ecommands_2ecompileJsOut_24s286675332x2033384300_2ek_24l0(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecompileJsOut_24s286675332x2033384300_2ek_24l0_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecompileJsOut_24s286675332x2033384300_2ek_24l0_clo;
V g_heff_2ebuild_2ecommands_2ecompileThen_24s1554913905x1093172886(V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecompileThen_24s1554913905x1093172886_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecompileThen_24s1554913905x1093172886_clo;
V g_heff_2ebuild_2ecommands_2ediagCount_24s804020149x363911067(V);
V g_heff_2ebuild_2ecommands_2ediagCount_24s804020149x363911067_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ediagCount_24s804020149x363911067_clo;
HeffT2 g_heff_2ebuild_2ecommands_2efirstErrorOf_24cpr(V);
V g_heff_2ebuild_2ecommands_2eheffErrors(V, V);
V g_heff_2ebuild_2ecommands_2eheffErrors_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eheffErrors_clo;
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s2064791442x239876729(V, V);
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s2064791442x239876729_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ehfFilesGo_24s2064791442x239876729_clo;
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s2064791442x239876729_2ek_24l0(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s2064791442x239876729_2ek_24l0_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ehfFilesGo_24s2064791442x239876729_2ek_24l0_clo;
V g_heff_2ebuild_2ecommands_2ehostNow_24s621918226x590971294(V, V);
V g_heff_2ebuild_2ecommands_2ehostNow_24s621918226x590971294_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ehostNow_24s621918226x590971294_clo;
V g_heff_2ebuild_2ecommands_2eimportsOn_24acc(V, V);
V g_heff_2ebuild_2ecommands_2eimportsOn_24acc_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eimportsOn_24acc_clo;
V g_heff_2ebuild_2ecommands_2ejsKept_24s465101055x1867051052(V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ejsKept_24s465101055x1867051052_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ejsKept_24s465101055x1867051052_clo;
V g_heff_2ebuild_2ecommands_2ekeptWith_24s328357922x1794949094_24rec0_get(void);
V g_heff_2ebuild_2ecommands_2elibDir_24s574622362x1897493272(V, V);
V g_heff_2ebuild_2ecommands_2elibDir_24s574622362x1897493272_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2elibDir_24s574622362x1897493272_clo;
V g_heff_2ebuild_2ecommands_2elinkFlags_24s1339126493x1033859153(V, V, V, V);
V g_heff_2ebuild_2ecommands_2elinkFlags_24s1339126493x1033859153_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2elinkFlags_24s1339126493x1033859153_clo;
V g_heff_2ebuild_2ecommands_2elinkOf(V);
V g_heff_2ebuild_2ecommands_2elinkOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2elinkOf_clo;
V g_heff_2ebuild_2ecommands_2emodDir_24s273255425x1733219620(V, V);
V g_heff_2ebuild_2ecommands_2emodDir_24s273255425x1733219620_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2emodDir_24s273255425x1733219620_clo;
V g_heff_2ebuild_2ecommands_2enubStrGo(V, V);
V g_heff_2ebuild_2ecommands_2enubStrGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2enubStrGo_clo;
V g_heff_2ebuild_2ecommands_2eownVersion_24s2092229395x529638551(V, V);
V g_heff_2ebuild_2ecommands_2eownVersion_24s2092229395x529638551_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eownVersion_24s2092229395x529638551_clo;
V g_heff_2ebuild_2ecommands_2epartsDir(V, V, V);
V g_heff_2ebuild_2ecommands_2epartsDir_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2epartsDir_clo;
HeffT2 g_heff_2ebuild_2ecommands_2epathOfModule_24cpr(V, V);
V g_heff_2ebuild_2ecommands_2epkgConfigFlags_24s126508420x808955771(V, V, V, V);
V g_heff_2ebuild_2ecommands_2epkgConfigFlags_24s126508420x808955771_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2epkgConfigFlags_24s126508420x808955771_clo;
V g_heff_2ebuild_2ecommands_2eprintErrs_24s1767649266x747632805(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eprintErrs_24s1767649266x747632805_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprintErrs_24s1767649266x747632805_clo;
V g_heff_2ebuild_2ecommands_2eprovidesLeaf(V, V);
V g_heff_2ebuild_2ecommands_2eprovidesLeaf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprovidesLeaf_clo;
V g_heff_2ebuild_2ecommands_2ereadProviders_24s491885588x407035296(V, V);
V g_heff_2ebuild_2ecommands_2ereadProviders_24s491885588x407035296_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ereadProviders_24s491885588x407035296_clo;
V g_heff_2ebuild_2ecommands_2ereadProvidersC_24s1527902393x1903258547(V, V);
V g_heff_2ebuild_2ecommands_2ereadProvidersC_24s1527902393x1903258547_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ereadProvidersC_24s1527902393x1903258547_clo;
V g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s903030267x1749449818(V, V, V);
V g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s903030267x1749449818_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s903030267x1749449818_clo;
V g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s903030267x1749449818_2ek_24l0(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s903030267x1749449818_2ek_24l0_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s903030267x1749449818_2ek_24l0_clo;
V g_heff_2ebuild_2ecommands_2erunCmd_24s1098214412x100466386(V, V, V);
V g_heff_2ebuild_2ecommands_2erunCmd_24s1098214412x100466386_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2erunCmd_24s1098214412x100466386_clo;
V g_heff_2ebuild_2ecommands_2erunDir(V, V);
V g_heff_2ebuild_2ecommands_2erunDir_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2erunDir_clo;
V g_heff_2ebuild_2ecommands_2erunProgram(V, V);
V g_heff_2ebuild_2ecommands_2erunProgram_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2erunProgram_clo;
V g_heff_2ebuild_2ecommands_2eselfFrom_24s1101093425x2049115263(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eselfFrom_24s1101093425x2049115263_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eselfFrom_24s1101093425x2049115263_clo;
V g_heff_2ebuild_2ecommands_2eselfKept_24s877584026x861180084(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eselfKept_24s877584026x861180084_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eselfKept_24s877584026x861180084_clo;
V g_heff_2ebuild_2ecommands_2eselfKept_24s877584026x861180084_24tok1(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eselfKept_24s877584026x861180084_24tok1_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eselfKept_24s877584026x861180084_24tok1_clo;
V g_heff_2ebuild_2ecommands_2eshipMoved_24s1077118630x1295426809(V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eshipMoved_24s1077118630x1295426809_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eshipMoved_24s1077118630x1295426809_clo;
V g_heff_2ebuild_2ecommands_2eshipMoved_24s1077118630x1295426809_2ek_24l0(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eshipMoved_24s1077118630x1295426809_2ek_24l0_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eshipMoved_24s1077118630x1295426809_2ek_24l0_clo;
V g_heff_2ebuild_2ecommands_2eshipOne_24s1526802457x609672645(V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eshipOne_24s1526802457x609672645_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eshipOne_24s1526802457x609672645_clo;
V g_heff_2ebuild_2ecommands_2eshipOne_24s1526802457x609672645_2ek_24l4(V, V, V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eshipOne_24s1526802457x609672645_2ek_24l4_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eshipOne_24s1526802457x609672645_2ek_24l4_clo;
V g_heff_2ebuild_2ecommands_2ewriteWhole_24s1075045965x79585410(V, V);
V g_heff_2ebuild_2ecommands_2ewriteWhole_24s1075045965x79585410_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ewriteWhole_24s1075045965x79585410_clo;
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1277531008x1788456998(V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1277531008x1788456998_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1277531008x1788456998_clo;
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1277531008x1788456998_2ek_24l1(V, V, V, V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1277531008x1788456998_2ek_24l1_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1277531008x1788456998_2ek_24l1_clo;
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2118406423x605242268(V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2118406423x605242268_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2118406423x605242268_clo;
V g_heff_2ebuild_2ecommands_2ezigLinked_24s604520448x37455075(V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ezigLinked_24s604520448x37455075_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ezigLinked_24s604520448x37455075_clo;
V g_heff_2ebuild_2edriver_2ecandLeaves(V);
V g_heff_2ebuild_2edriver_2ecandLeaves_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ecandLeaves_clo;
V g_heff_2ebuild_2edriver_2ecandidatesOf(V);
V g_heff_2ebuild_2edriver_2ecandidatesOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ecandidatesOf_clo;
HeffT2 g_heff_2ebuild_2edriver_2efindRunnable_24cpr(V, V, V);
V g_heff_2ebuild_2edriver_2enubStrD(V);
V g_heff_2ebuild_2edriver_2enubStrD_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2enubStrD_clo;
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1839248718x121761575(V, V, V, V);
V g_heff_2ebuild_2eload_2eloadProgramWith_24s1839248718x121761575_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eload_2eloadProgramWith_24s1839248718x121761575_clo;
V g_heff_2ebuild_2esession_2ecachedAcc_24s1189406870x118640775(V);
V g_heff_2ebuild_2esession_2ecachedAcc_24s1189406870x118640775_entry(V self, V *a);
extern Clo g_heff_2ebuild_2esession_2ecachedAcc_24s1189406870x118640775_clo;
V g_heff_2ecompile_2eemitc_2eemptyCS_get(void);
V g_heff_2elsp_2erender_2ediagWhere(V, V, V);
V g_heff_2elsp_2erender_2ediagWhere_entry(V self, V *a);
extern Clo g_heff_2elsp_2erender_2ediagWhere_clo;
V g_heff_2elsp_2erender_2eprtCode(V);
V g_heff_2elsp_2erender_2eprtCode_entry(V self, V *a);
extern Clo g_heff_2elsp_2erender_2eprtCode_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24f1047446376x6295489(V, V, V);
V g_list_2efoldl_24f1047446376x6295489_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1047446376x6295489_clo;
V g_list_2efoldl_24f2094160282x1876485468(V, V, V);
V g_list_2efoldl_24f2094160282x1876485468_entry(V self, V *a);
extern Clo g_list_2efoldl_24f2094160282x1876485468_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s1673889684x228869038(V, V);
V g_list_2efoldl_24s1673889684x228869038_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1673889684x228869038_clo;
V g_list_2efoldl_24s467938309x1106414629(V, V);
V g_list_2efoldl_24s467938309x1106414629_entry(V self, V *a);
extern Clo g_list_2efoldl_24s467938309x1106414629_clo;
V g_list_2efoldl_24s571074576x1179600767(V, V);
V g_list_2efoldl_24s571074576x1179600767_entry(V self, V *a);
extern Clo g_list_2efoldl_24s571074576x1179600767_clo;
V g_list_2efoldl_24s586092072x139578797(V, V);
V g_list_2efoldl_24s586092072x139578797_entry(V self, V *a);
extern Clo g_list_2efoldl_24s586092072x139578797_clo;
V g_list_2ekeepIf(V, V);
V g_list_2ekeepIf_entry(V self, V *a);
extern Clo g_list_2ekeepIf_clo;
V g_list_2ekeepIf_24s1161549307x1906011635(V);
V g_list_2ekeepIf_24s1161549307x1906011635_entry(V self, V *a);
extern Clo g_list_2ekeepIf_24s1161549307x1906011635_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1325317589x1506218481(V, V, V);
V g_list_2emap_24s1325317589x1506218481_entry(V self, V *a);
extern Clo g_list_2emap_24s1325317589x1506218481_clo;
V g_list_2emap_24s1698496827x1884878103(V);
V g_list_2emap_24s1698496827x1884878103_entry(V self, V *a);
extern Clo g_list_2emap_24s1698496827x1884878103_clo;
V g_list_2emap_24s219049803x1458391381(V);
V g_list_2emap_24s219049803x1458391381_entry(V self, V *a);
extern Clo g_list_2emap_24s219049803x1458391381_clo;
V g_list_2emap_24s231073986x752637537(V, V);
V g_list_2emap_24s231073986x752637537_entry(V self, V *a);
extern Clo g_list_2emap_24s231073986x752637537_clo;
V g_list_2emap_24s328934344x1728860012(V, V);
V g_list_2emap_24s328934344x1728860012_entry(V self, V *a);
extern Clo g_list_2emap_24s328934344x1728860012_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_std_2epath_2ejoin(V, V);
V g_std_2epath_2ejoin_entry(V self, V *a);
extern Clo g_std_2epath_2ejoin_clo;
V g_std_2epath_2enative_get(void);
V g_std_2epath_2eparse(V, V);
V g_std_2epath_2eparse_entry(V self, V *a);
extern Clo g_std_2epath_2eparse_clo;
V g_std_2epath_2erender(V, V);
V g_std_2epath_2erender_entry(V self, V *a);
extern Clo g_std_2epath_2erender_clo;
V g_std_2eprogress_2eroot_get(void);
HEFF_LIT(g_heff_2ebuild_2ecommands_2eimportsOn_24acc_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eimportsOn_24acc_str1, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eimportsOn_24acc_str2, 10, "imports it");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eimportsOn_24acc_str3, 9, "imports `");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eimportsOn_24acc_str4, 9, "`, which ");
Clo g_heff_2ebuild_2ecommands_2eimportsOn_24acc_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eimportsOn_24acc_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2eimportsOn_24acc(V v_x1_240, V v_acc_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_strAppend(v_acc_241, ((V)&g_heff_2ebuild_2ecommands_2eimportsOn_24acc_str0));
  }
  case TAG_Cons: {
    V v_x12_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 2ULL, 2);
    switch (heff_tag_of(v_x12_243)) {
    case TAG_Nil: {
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      return heff_strAppend(v_acc_241, ((V)&g_heff_2ebuild_2ecommands_2eimportsOn_24acc_str1));
    }
    case TAG_Cons: {
      V v_b_244 = heff_field(v_x12_243, 0);
      V v_x122_245 = heff_field(v_x12_243, 1);
      heff_take_n(v_x12_243, 3ULL, 2);
      switch (heff_tag_of(v_x122_245)) {
      case TAG_Nil: {
        heff_drop_cell(v_ru_24x1_240_24Cons, 2);
        heff_drop(v_b_244);
        return heff_strAppend(v_acc_241, ((V)&g_heff_2ebuild_2ecommands_2eimportsOn_24acc_str2));
      }
      case TAG_Cons: {
        V v_t_248 = heff_strAppend(heff_strAppend(v_acc_241, ((V)&g_heff_2ebuild_2ecommands_2eimportsOn_24acc_str3)), heff_dup(v_b_244));
        V v_s_249 = heff_strAppend(v_t_248, ((V)&g_heff_2ebuild_2ecommands_2eimportsOn_24acc_str4));
        V t_0 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_b_244, v_x122_245});
        V t_1 = v_s_249;
        v_x1_240 = t_0;
        v_acc_241 = t_1;
        goto top;
      }
      default: return heff_nomatch(v_x122_245);
      }
    }
    default: return heff_nomatch(v_x12_243);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2ecommands_2eimportsOn_24acc_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eimportsOn_24acc(a[0], a[1]);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2efirstErrorOf_24cpr_str0, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2efirstErrorOf_24cpr_str1, 2, ": ");

HeffT2 g_heff_2ebuild_2ecommands_2efirstErrorOf_24cpr(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_c_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    V v_diags_243 = heff_dup(heff_rfield(v_c_241, 6));
    V v_path_244 = heff_dup(heff_rfield(v_c_241, 1));
    V v_source_245 = heff_dup(heff_rfield(v_c_241, 3));
    V v_x2_246 = (g_list_2ekeepIf_24s1161549307x1906011635(v_diags_243));
    switch (heff_tag_of(v_x2_246)) {
    case TAG_Nil: {
      heff_drop(v_path_244);
      heff_drop(v_source_245);
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    case TAG_Cons: {
      V v_d_247 = heff_field(v_x2_246, 0);
      heff_take_n(v_x2_246, 1ULL, 2);
      V v_t_249 = ({ V a_0 = v_path_244; V a_1 = v_source_245; V a_2 = heff_dup(v_d_247); V r_ = (g_heff_2elsp_2erender_2ediagWhere(a_0, a_1, a_2)); heff_drop(v_source_245); r_; });
      V v_t_2410 = (g_heff_2elsp_2erender_2eprtCode(heff_dup(v_d_247)));
      V v_t_2411 = heff_strAppend(heff_strAppend(v_t_2410, ((V)&g_heff_2ebuild_2ecommands_2efirstErrorOf_24cpr_str0)), heff_get_n(v_d_247, 2, 5));
      V v_why_2412 = heff_strAppend(heff_strAppend(v_t_249, ((V)&g_heff_2ebuild_2ecommands_2efirstErrorOf_24cpr_str1)), v_t_2411);
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_why_2412}});
    }
    default: return ((HeffT2){{heff_nomatch(v_x2_246)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2epartsDir_str0, 5, ".heff");
HEFF_LIT(g_heff_2ebuild_2ecommands_2epartsDir_str1, 5, "build");
Clo g_heff_2ebuild_2ecommands_2epartsDir_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2epartsDir_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2epartsDir(V v_st_240, V v_t_241, V v_x_242) {
top: ;
  V v_t_243 = (g_std_2epath_2eparse(heff_dup(v_st_240), ((V)&g_heff_2ebuild_2ecommands_2epartsDir_str0)));
  V v_t_244 = (g_std_2epath_2eparse(heff_dup(v_st_240), ((V)&g_heff_2ebuild_2ecommands_2epartsDir_str1)));
  V v_t_245 = (g_std_2epath_2ejoin(v_t_243, v_t_244));
  V v_a_246 = ({ V a_0 = v_st_240; V a_1 = v_t_245; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_245); r_; });
  V v_t_247 = (g_std_2epath_2eparse(heff_dup(v_st_240), v_a_246));
  V v_t_248 = (g_std_2epath_2eparse(heff_dup(v_st_240), v_x_242));
  V v_t_249 = (g_std_2epath_2ejoin(v_t_247, v_t_248));
  V v_p_2410 = ({ V a_0 = v_st_240; V a_1 = v_t_249; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_249); r_; });
  V v_t_2411 = (g_std_2epath_2eparse(heff_dup(v_st_240), heff_get_n(v_t_241, 0, 6)));
  V v_t_2412 = (g_std_2epath_2eparse(heff_dup(v_st_240), v_p_2410));
  V v_t_2413 = (g_std_2epath_2ejoin(v_t_2411, v_t_2412));
  return ({ V a_0 = v_st_240; V a_1 = v_t_2413; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_240); heff_drop(v_t_2413); r_; });
}
V g_heff_2ebuild_2ecommands_2epartsDir_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2epartsDir(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2emodDir_24s273255425x1733219620_str0, 13, "HEFF_MODCACHE");
HEFF_LIT(g_heff_2ebuild_2ecommands_2emodDir_24s273255425x1733219620_str1, 4, "HOME");
HEFF_LIT(g_heff_2ebuild_2ecommands_2emodDir_24s273255425x1733219620_str2, 11, "USERPROFILE");
HEFF_LIT(g_heff_2ebuild_2ecommands_2emodDir_24s273255425x1733219620_str3, 5, "win32");
HEFF_LIT(g_heff_2ebuild_2ecommands_2emodDir_24s273255425x1733219620_str4, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2emodDir_24s273255425x1733219620_str5, 6, ".cache");
HEFF_LIT(g_heff_2ebuild_2ecommands_2emodDir_24s273255425x1733219620_str6, 4, "heff");
HEFF_LIT(g_heff_2ebuild_2ecommands_2emodDir_24s273255425x1733219620_str7, 3, "mod");
V g_heff_2ebuild_2ecommands_2emodDir_24s273255425x1733219620_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2emodDir_24s273255425x1733219620_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2emodDir_24s273255425x1733219620_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2emodDir_24s273255425x1733219620_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2emodDir_24s273255425x1733219620_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2emodDir_24s273255425x1733219620_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2emodDir_24s273255425x1733219620_lam4(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2emodDir_24s273255425x1733219620_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2emodDir_24s273255425x1733219620_lam4, 1, 0};
V g_heff_2ebuild_2ecommands_2emodDir_24s273255425x1733219620_lam6(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2emodDir_24s273255425x1733219620_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2emodDir_24s273255425x1733219620_lam6, 1, 0};
V g_heff_2ebuild_2ecommands_2emodDir_24s273255425x1733219620_lam7(V self, V *args);
V g_heff_2ebuild_2ecommands_2emodDir_24s273255425x1733219620_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2emodDir_24s273255425x1733219620_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2emodDir_24s273255425x1733219620_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2emodDir_24s273255425x1733219620_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2emodDir_24s273255425x1733219620_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2emodDir_24s273255425x1733219620(V v_hd_240, V v_k_241) {
top: ;
  V v_t_243 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_GetEnv, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2emodDir_24s273255425x1733219620_str0), ((V)&g_heff_2ebuild_2ecommands_2emodDir_24s273255425x1733219620_lam0_clo)})});
  V v_t_244 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_243})});
  V v_t_245 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_244})});
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_245})});
  V v_t_247 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_247})});
  return (g_co_2eop_24s535099379x685970669(v_t_248, heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2ecommands_2emodDir_24s273255425x1733219620_lam1, 1, 2, (V[]){v_hd_240, v_k_241})));
}
V g_heff_2ebuild_2ecommands_2emodDir_24s273255425x1733219620_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2emodDir_24s273255425x1733219620(a[0], a[1]);
}
V g_heff_2ebuild_2ecommands_2emodDir_24s273255425x1733219620_lam0(V self, V *args) {
  V v_v_242 = args[0];
  return v_v_242;
}
V g_heff_2ebuild_2ecommands_2emodDir_24s273255425x1733219620_lam2(V self, V *args) {
  V v_v_2410 = args[0];
  return v_v_2410;
}
V g_heff_2ebuild_2ecommands_2emodDir_24s273255425x1733219620_lam4(V self, V *args) {
  V v_v_2418 = args[0];
  return v_v_2418;
}
V g_heff_2ebuild_2ecommands_2emodDir_24s273255425x1733219620_lam6(V self, V *args) {
  V v_s_2426 = args[0];
  return v_s_2426;
}
V g_heff_2ebuild_2ecommands_2emodDir_24s273255425x1733219620_lam7(V self, V *args) {
  V v_x_2433 = args[0];
  V v_x_249 = heff_env(self)[0];
  V v_x_2417 = heff_env(self)[1];
  V v_x_2425 = heff_env(self)[2];
  V v_k_241 = heff_env(self)[3];
  V v_st_2434;
  if (heff_strEq_c(v_x_2433, ((V)&g_heff_2ebuild_2ecommands_2emodDir_24s273255425x1733219620_str3))) {
    v_st_2434 = NTAG(TAG_Windows);
  } else {
    v_st_2434 = NTAG(TAG_Posix);
  }
  V v_x_2450;
  heff_clo_take(self, 4);
  switch (heff_tag_of(v_x_249)) {
  case TAG_Nothing: {
    V v_t_2437;
    switch (heff_tag_of(v_x_2417)) {
    case TAG_Nothing: {
      switch (heff_tag_of(v_x_2425)) {
      case TAG_Nothing: {
        v_t_2437 = ((V)&g_heff_2ebuild_2ecommands_2emodDir_24s273255425x1733219620_str4);
        break;
      }
      case TAG_Just: {
        V v_x_2435 = heff_field(v_x_2425, 0);
        heff_take_n(v_x_2425, 1ULL, 1);
        v_t_2437 = v_x_2435;
        break;
      }
      default: heff_nomatch(v_x_2425);
      }
      break;
    }
    case TAG_Just: {
      V v_x_2436 = heff_field(v_x_2417, 0);
      heff_take_n(v_x_2417, 1ULL, 1);
      heff_drop(v_x_2425);
      v_t_2437 = v_x_2436;
      break;
    }
    default: heff_nomatch(v_x_2417);
    }
    V v_t_2438 = (g_std_2epath_2eparse(heff_dup(v_st_2434), v_t_2437));
    V v_t_2439 = (g_std_2epath_2eparse(heff_dup(v_st_2434), ((V)&g_heff_2ebuild_2ecommands_2emodDir_24s273255425x1733219620_str5)));
    V v_t_2440 = (g_std_2epath_2ejoin(v_t_2438, v_t_2439));
    V v_a_2441 = ({ V a_0 = v_st_2434; V a_1 = v_t_2440; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2440); r_; });
    V v_t_2442 = (g_std_2epath_2eparse(heff_dup(v_st_2434), ((V)&g_heff_2ebuild_2ecommands_2emodDir_24s273255425x1733219620_str6)));
    V v_t_2443 = (g_std_2epath_2eparse(heff_dup(v_st_2434), ((V)&g_heff_2ebuild_2ecommands_2emodDir_24s273255425x1733219620_str7)));
    V v_t_2444 = (g_std_2epath_2ejoin(v_t_2442, v_t_2443));
    V v_b_2445 = ({ V a_0 = v_st_2434; V a_1 = v_t_2444; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2444); r_; });
    V v_t_2446 = (g_std_2epath_2eparse(heff_dup(v_st_2434), v_a_2441));
    V v_t_2447 = (g_std_2epath_2eparse(heff_dup(v_st_2434), v_b_2445));
    V v_t_2448 = (g_std_2epath_2ejoin(v_t_2446, v_t_2447));
    v_x_2450 = ({ V a_0 = v_st_2434; V a_1 = v_t_2448; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2434); heff_drop(v_t_2448); r_; });
    break;
  }
  case TAG_Just: {
    V v_d_2449 = heff_field(v_x_249, 0);
    heff_take_n(v_x_249, 1ULL, 1);
    heff_drop(v_x_2417);
    heff_drop(v_x_2425);
    heff_drop(v_st_2434);
    v_x_2450 = v_d_2449;
    break;
  }
  default: heff_nomatch(v_x_249);
  }
  V f_ = v_k_241;
  args[0] = v_x_2450;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2emodDir_24s273255425x1733219620_lam5(V self, V *args) {
  V v_x_2425 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_x_249 = heff_env(self)[1];
  V v_x_2417 = heff_env(self)[2];
  V v_k_241 = heff_env(self)[3];
  V v_t_2427 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2emodDir_24s273255425x1733219620_lam6_clo)})});
  V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
  V v_t_2429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
  V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
  V v_t_2431 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
  V v_t_2432 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2431})});
  heff_clo_take(self, 4);
  return (g_co_2eop_24s535099379x685970669(v_t_2432, v_hd_240, heff_clo_n(g_heff_2ebuild_2ecommands_2emodDir_24s273255425x1733219620_lam7, 1, 4, (V[]){v_x_249, v_x_2417, v_x_2425, v_k_241})));
}
V g_heff_2ebuild_2ecommands_2emodDir_24s273255425x1733219620_lam3(V self, V *args) {
  V v_x_2417 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_x_249 = heff_env(self)[1];
  V v_k_241 = heff_env(self)[2];
  V v_t_2419 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_GetEnv, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2emodDir_24s273255425x1733219620_str2), ((V)&g_heff_2ebuild_2ecommands_2emodDir_24s273255425x1733219620_lam4_clo)})});
  V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
  V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
  V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
  V v_t_2423 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
  V v_t_2424 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2423})});
  heff_clo_take(self, 3);
  return (g_co_2eop_24s535099379x685970669(v_t_2424, heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2ecommands_2emodDir_24s273255425x1733219620_lam5, 1, 4, (V[]){v_hd_240, v_x_249, v_x_2417, v_k_241})));
}
V g_heff_2ebuild_2ecommands_2emodDir_24s273255425x1733219620_lam1(V self, V *args) {
  V v_x_249 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  V v_t_2411 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_GetEnv, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2emodDir_24s273255425x1733219620_str1), ((V)&g_heff_2ebuild_2ecommands_2emodDir_24s273255425x1733219620_lam2_clo)})});
  V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
  V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
  V v_t_2415 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
  V v_t_2416 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2415})});
  heff_clo_take(self, 2);
  return (g_co_2eop_24s535099379x685970669(v_t_2416, heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2ecommands_2emodDir_24s273255425x1733219620_lam3, 1, 3, (V[]){v_hd_240, v_x_249, v_k_241})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadProvidersC_24s1527902393x1903258547_str0, 3, ".hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadProvidersC_24s1527902393x1903258547_str1, 11, ".provider.c");
V g_heff_2ebuild_2ecommands_2ereadProvidersC_24s1527902393x1903258547_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ereadProvidersC_24s1527902393x1903258547_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ereadProvidersC_24s1527902393x1903258547_lam0, 2, 0};
V g_heff_2ebuild_2ecommands_2ereadProvidersC_24s1527902393x1903258547_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ereadProvidersC_24s1527902393x1903258547_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ereadProvidersC_24s1527902393x1903258547_lam1, 1, 0};
V g_heff_2ebuild_2ecommands_2ereadProvidersC_24s1527902393x1903258547_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ereadProvidersC_24s1527902393x1903258547_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ereadProvidersC_24s1527902393x1903258547_lam4(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ereadProvidersC_24s1527902393x1903258547_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ereadProvidersC_24s1527902393x1903258547_lam4, 2, 0};
V g_heff_2ebuild_2ecommands_2ereadProvidersC_24s1527902393x1903258547_lam7(V self, V *args);
V g_heff_2ebuild_2ecommands_2ereadProvidersC_24s1527902393x1903258547_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2ereadProvidersC_24s1527902393x1903258547_lam5(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ereadProvidersC_24s1527902393x1903258547_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ereadProvidersC_24s1527902393x1903258547_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2ereadProvidersC_24s1527902393x1903258547(V v_sources_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_sources_240);
    return ((V)&g_heff_2ebuild_2ecommands_2ereadProvidersC_24s1527902393x1903258547_lam0_clo);
  }
  case TAG_Cons: {
    V v_m_244 = heff_field(v_x2_241, 0);
    V v_rest_245 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_sources_246 = heff_dup(v_sources_240);
    V v_m_247 = v_m_244;
    HeffT2 v_t_248 = ({ V a_0 = v_sources_246; V a_1 = v_m_247; HeffT2 r_ = (g_heff_2ebuild_2ecommands_2epathOfModule_24cpr(a_0, a_1)); heff_drop(v_sources_246); r_; });
    {
      V v_field_2410 = v_t_248.f[1];
      int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
      V v_c_2435;
      if ((v_tag_249 == ((int64_t)0ULL))) {
        V v_path_2411 = v_field_2410;
        int64_t v_t_2412 = (heff_unbox_word(heff_strLength_lent(v_path_2411, 0)) - ((int64_t)3ULL));
        V v_t_2413 = heff_strSlice_lent(v_path_2411, heff_box_word(v_t_2412), heff_strLength_lent(v_path_2411, 0), 6);
        V v_t_2415;
        if (heff_strEq_c(v_t_2413, ((V)&g_heff_2ebuild_2ecommands_2ereadProvidersC_24s1527902393x1903258547_str0))) {
          int64_t v_t_2414 = (heff_unbox_word(heff_strLength_lent(v_path_2411, 0)) - ((int64_t)3ULL));
          v_t_2415 = heff_strSlice(v_path_2411, MK_INT(0LL), heff_box_word(v_t_2414));
        } else {
          v_t_2415 = v_path_2411;
        }
        V v_path_2416 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), heff_strAppend(v_t_2415, ((V)&g_heff_2ebuild_2ecommands_2ereadProvidersC_24s1527902393x1903258547_str1))));
        V v_t_2417 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2416; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_2416); r_; });
        V v_a_2419 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_ReadFile, 2, (V[]){v_t_2417, ((V)&g_heff_2ebuild_2ecommands_2ereadProvidersC_24s1527902393x1903258547_lam1_clo)});
        v_c_2435 = heff_clo_n(g_heff_2ebuild_2ecommands_2ereadProvidersC_24s1527902393x1903258547_lam2, 2, 2, (V[]){v_a_2419, v_m_247});
      } else {
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        heff_drop(v_m_247);
        heff_drop(v_field_2410);
        v_c_2435 = ((V)&g_heff_2ebuild_2ecommands_2ereadProvidersC_24s1527902393x1903258547_lam4_clo);
      }
      return heff_clo_n(g_heff_2ebuild_2ecommands_2ereadProvidersC_24s1527902393x1903258547_lam5, 2, 3, (V[]){v_c_2435, v_sources_240, v_rest_245});
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2ecommands_2ereadProvidersC_24s1527902393x1903258547_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ereadProvidersC_24s1527902393x1903258547(a[0], a[1]);
}
V g_heff_2ebuild_2ecommands_2ereadProvidersC_24s1527902393x1903258547_lam0(V self, V *args) {
  V v_hd_242 = args[0];
  V v_k_243 = args[1];
  heff_drop(v_hd_242);
  V f_ = v_k_243;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ereadProvidersC_24s1527902393x1903258547_lam1(V self, V *args) {
  V v_r_2418 = args[0];
  return v_r_2418;
}
V g_heff_2ebuild_2ecommands_2ereadProvidersC_24s1527902393x1903258547_lam3(V self, V *args) {
  V v_x_2427 = args[0];
  V v_k_2421 = heff_env(self)[0];
  V v_m_247 = heff_env(self)[1];
  switch (heff_tag_of(v_x_2427)) {
  case TAG_Left: {
    heff_take_n(v_x_2427, 0ULL, 1);
    heff_clo_take(self, 2);
    heff_drop(v_m_247);
    V f_ = v_k_2421;
    args[0] = NTAG(TAG_Nothing);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Right: {
    V v_y_2429 = heff_field(v_x_2427, 0);
    V v_ru_24x_2427_24Right = heff_take_reuse_n(v_x_2427, 1ULL, 1);
    switch (heff_tag_of(v_y_2429)) {
    case TAG_Left: {
      heff_take_n(v_y_2429, 0ULL, 1);
      heff_clo_take(self, 2);
      heff_drop(v_m_247);
      heff_drop_cell(v_ru_24x_2427_24Right, 1);
      V f_ = v_k_2421;
      args[0] = NTAG(TAG_Nothing);
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    case TAG_Right: {
      V v_x_2431 = heff_field(v_y_2429, 0);
      heff_take_n(v_y_2429, 1ULL, 1);
      heff_clo_take(self, 2);
      V v_t_2432 = heff_tag_at_n(v_ru_24x_2427_24Right, TAG_Just, 1, (V[]){heff_rec_n(2, shape_module__text, (V[]){v_m_247, v_x_2431})});
      V f_ = v_k_2421;
      args[0] = v_t_2432;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    default: return heff_nomatch(v_y_2429);
    }
  }
  default: return heff_nomatch(v_x_2427);
  }
}
V g_heff_2ebuild_2ecommands_2ereadProvidersC_24s1527902393x1903258547_lam2(V self, V *args) {
  V v_hd_2420 = args[0];
  V v_k_2421 = args[1];
  V v_a_2419 = heff_env(self)[0];
  V v_m_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2419})});
  V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
  V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
  V v_t_2425 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
  V v_t_2426 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2425})});
  return (g_co_2eop_24s1896221640x2141527803(v_t_2426, v_hd_2420, heff_clo_n(g_heff_2ebuild_2ecommands_2ereadProvidersC_24s1527902393x1903258547_lam3, 1, 2, (V[]){v_k_2421, v_m_247})));
}
V g_heff_2ebuild_2ecommands_2ereadProvidersC_24s1527902393x1903258547_lam4(V self, V *args) {
  V v_hd_2433 = args[0];
  V v_k_2434 = args[1];
  heff_drop(v_hd_2433);
  V f_ = v_k_2434;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ereadProvidersC_24s1527902393x1903258547_lam7(V self, V *args) {
  V v_x_2440 = args[0];
  V v_x_2438 = heff_env(self)[0];
  V v_k_2437 = heff_env(self)[1];
  V v_t_2442;
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_x_2438)) {
  case TAG_Nothing: {
    v_t_2442 = v_x_2440;
    break;
  }
  case TAG_Just: {
    V v_pr_2441 = heff_field(v_x_2438, 0);
    heff_take_n(v_x_2438, 1ULL, 1);
    v_t_2442 = heff_tag_n(TAG_Cons, 2, (V[]){v_pr_2441, v_x_2440});
    break;
  }
  default: heff_nomatch(v_x_2438);
  }
  V f_ = v_k_2437;
  args[0] = v_t_2442;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ereadProvidersC_24s1527902393x1903258547_lam6(V self, V *args) {
  V v_x_2438 = args[0];
  V v_sources_240 = heff_env(self)[0];
  V v_rest_245 = heff_env(self)[1];
  V v_hd_2436 = heff_env(self)[2];
  V v_k_2437 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2439 = (g_heff_2ebuild_2ecommands_2ereadProvidersC_24s1527902393x1903258547(v_sources_240, v_rest_245));
  V f_ = v_t_2439;
  heff_room[0] = v_hd_2436;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ereadProvidersC_24s1527902393x1903258547_lam7, 1, 2, (V[]){v_x_2438, v_k_2437});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ereadProvidersC_24s1527902393x1903258547_lam5(V self, V *args) {
  V v_hd_2436 = args[0];
  V v_k_2437 = args[1];
  V v_c_2435 = heff_env(self)[0];
  V v_sources_240 = heff_env(self)[1];
  V v_rest_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_2435;
  args[0] = heff_dup(v_hd_2436);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ereadProvidersC_24s1527902393x1903258547_lam6, 1, 4, (V[]){v_sources_240, v_rest_245, v_hd_2436, v_k_2437});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s903030267x1749449818_str0, 5, "win32");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s903030267x1749449818_str1, 1, "c");
V g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s903030267x1749449818_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s903030267x1749449818_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s903030267x1749449818_lam1, 1, 0};
V g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s903030267x1749449818_lam3(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s903030267x1749449818_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s903030267x1749449818_lam3, 1, 0};
V g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s903030267x1749449818_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s903030267x1749449818_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s903030267x1749449818_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s903030267x1749449818_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s903030267x1749449818_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s903030267x1749449818(V v_name_240, V v_hd_241, V v_k_242) {
top: ;
  return (g_heff_2ebuild_2ecommands_2elibDir_24s574622362x1897493272(heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s903030267x1749449818_lam0, 1, 3, (V[]){v_hd_241, v_name_240, v_k_242})));
}
V g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s903030267x1749449818_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s903030267x1749449818(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s903030267x1749449818_lam1(V self, V *args) {
  V v_s_244 = args[0];
  return v_s_244;
}
V g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s903030267x1749449818_lam3(V self, V *args) {
  V v_r_2423 = args[0];
  return v_r_2423;
}
V g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s903030267x1749449818_lam4(V self, V *args) {
  V v_x_2430 = args[0];
  V v_st_2412 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  V v_name_240 = heff_env(self)[2];
  V v_hd_241 = heff_env(self)[3];
  V v_k_242 = heff_env(self)[4];
  switch (heff_tag_of(v_x_2430)) {
  case TAG_Left: {
    V v_x_2431 = heff_field(v_x_2430, 0);
    V v_ru_24x_2430_24Left = heff_take_reuse_n(v_x_2430, 1ULL, 1);
    heff_clo_take(self, 5);
    return (g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s903030267x1749449818_2ek_24l0(v_st_2412, v_x_243, v_name_240, v_hd_241, v_k_242, heff_tag_re_n(v_ru_24x_2430_24Left, TAG_Left, 1, 1ULL, (V[]){v_x_2431})));
  }
  case TAG_Right: {
    V v_y_2432 = heff_field(v_x_2430, 0);
    V v_ru_24x_2430_24Right = heff_take_reuse_n(v_x_2430, 1ULL, 1);
    switch (heff_tag_of(v_y_2432)) {
    case TAG_Left: {
      V v_err_2433 = heff_field(v_y_2432, 0);
      V v_ru_24y_2432_24Left = heff_take_reuse_n(v_y_2432, 1ULL, 1);
      heff_drop_cell(v_ru_24x_2430_24Right, 1);
      heff_clo_take(self, 5);
      return (g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s903030267x1749449818_2ek_24l0(v_st_2412, v_x_243, v_name_240, v_hd_241, v_k_242, heff_tag_re_n(v_ru_24y_2432_24Left, TAG_Left, 1, 1ULL, (V[]){v_err_2433})));
    }
    case TAG_Right: {
      V v_x_2434 = heff_field(v_y_2432, 0);
      heff_take_n(v_y_2432, 1ULL, 1);
      heff_clo_take(self, 5);
      return (g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s903030267x1749449818_2ek_24l0(v_st_2412, v_x_243, v_name_240, v_hd_241, v_k_242, heff_tag_at_n(v_ru_24x_2430_24Right, TAG_Right, 1, (V[]){v_x_2434})));
    }
    default: return heff_nomatch(v_y_2432);
    }
  }
  default: return heff_nomatch(v_x_2430);
  }
}
V g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s903030267x1749449818_lam2(V self, V *args) {
  V v_x_2411 = args[0];
  V v_x_243 = heff_env(self)[0];
  V v_name_240 = heff_env(self)[1];
  V v_hd_241 = heff_env(self)[2];
  V v_k_242 = heff_env(self)[3];
  V v_st_2412;
  if (heff_strEq_c(v_x_2411, ((V)&g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s903030267x1749449818_str0))) {
    v_st_2412 = NTAG(TAG_Windows);
  } else {
    v_st_2412 = NTAG(TAG_Posix);
  }
  V v_t_2413 = (g_std_2epath_2eparse(heff_dup(v_st_2412), heff_dup(v_x_243)));
  V v_t_2414 = (g_std_2epath_2eparse(heff_dup(v_st_2412), ((V)&g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s903030267x1749449818_str1)));
  V v_t_2415 = (g_std_2epath_2ejoin(v_t_2413, v_t_2414));
  V v_a_2416 = ({ V a_0 = v_st_2412; V a_1 = v_t_2415; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2415); r_; });
  V v_t_2417 = (g_std_2epath_2eparse(heff_dup(v_st_2412), v_a_2416));
  V v_t_2418 = (g_std_2epath_2eparse(heff_dup(v_st_2412), heff_dup(v_name_240)));
  V v_t_2419 = (g_std_2epath_2ejoin(v_t_2417, v_t_2418));
  V v_s_2420 = ({ V a_0 = v_st_2412; V a_1 = v_t_2419; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2419); r_; });
  V v_path_2421 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_s_2420));
  V v_t_2422 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2421; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_2421); r_; });
  V v_a_2424 = heff_tag_n(TAG_ReadFile, 2, (V[]){v_t_2422, ((V)&g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s903030267x1749449818_lam3_clo)});
  V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2424})});
  V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
  V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
  V v_t_2428 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
  V v_t_2429 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2428})});
  heff_clo_take(self, 4);
  return (g_co_2eop_24s1896221640x2141527803(v_t_2429, heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s903030267x1749449818_lam4, 1, 5, (V[]){v_st_2412, v_x_243, v_name_240, v_hd_241, v_k_242})));
}
V g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s903030267x1749449818_lam0(V self, V *args) {
  V v_x_243 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_name_240 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  V v_t_245 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s903030267x1749449818_lam1_clo)})});
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_245})});
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  V v_t_249 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
  V v_t_2410 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_249})});
  heff_clo_take(self, 3);
  return (g_co_2eop_24s535099379x685970669(v_t_2410, heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2ecommands_2ereadRuntimeFile_24s903030267x1749449818_lam2, 1, 4, (V[]){v_x_243, v_name_240, v_hd_241, v_k_242})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2elinkFlags_24s1339126493x1033859153_str0, 8, "--cflags");
HEFF_LIT(g_heff_2ebuild_2ecommands_2elinkFlags_24s1339126493x1033859153_str1, 6, "--libs");
HEFF_LIT(g_heff_2ebuild_2ecommands_2elinkFlags_24s1339126493x1033859153_str2, 2, "-l");
HEFF_LIT(g_heff_2ebuild_2ecommands_2elinkFlags_24s1339126493x1033859153_str3, 6, "darwin");
HEFF_LIT(g_heff_2ebuild_2ecommands_2elinkFlags_24s1339126493x1033859153_str4, 10, "-framework");
V g_heff_2ebuild_2ecommands_2elinkFlags_24s1339126493x1033859153_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2elinkFlags_24s1339126493x1033859153_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2elinkFlags_24s1339126493x1033859153_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2elinkFlags_24s1339126493x1033859153_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2elinkFlags_24s1339126493x1033859153_entry, 4, 0};

V g_heff_2ebuild_2ecommands_2elinkFlags_24s1339126493x1033859153(V v_os_240, V v_ls_241, V v_z_242, V v_z_243) {
top: ;
  V v_t_244 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_ls_241)));
  V v_xs_245 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_244; V r_ = (g_list_2efoldl_24s467938309x1106414629(a_0, a_1)); heff_drop(v_t_244); r_; });
  V v_x_246 = (g_heff_2ebuild_2ecommands_2enubStrGo(NTAG(TAG_Nil), v_xs_245));
  HEFF_LAST return g_heff_2ebuild_2ecommands_2epkgConfigFlags_24s126508420x808955771(((V)&g_heff_2ebuild_2ecommands_2elinkFlags_24s1339126493x1033859153_str0), heff_dup(v_x_246), heff_dup(v_z_242), heff_clo_n(g_heff_2ebuild_2ecommands_2elinkFlags_24s1339126493x1033859153_lam0, 1, 5, (V[]){v_x_246, v_z_242, v_ls_241, heff_dup(v_os_240), v_z_243}));
}
V g_heff_2ebuild_2ecommands_2elinkFlags_24s1339126493x1033859153_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2elinkFlags_24s1339126493x1033859153(a0, a[1], a[2], a[3]); heff_drop(a0); return r;
}
V g_heff_2ebuild_2ecommands_2elinkFlags_24s1339126493x1033859153_lam2(V self, V *args) {
  V v_acc_2422 = args[0];
  V v_x_2423 = args[1];
  V v_os_240 = heff_env(self)[0];
  V v_t_2425;
  heff_clo_take(self, 1);
  if (heff_strEq_c(v_os_240, ((V)&g_heff_2ebuild_2ecommands_2elinkFlags_24s1339126493x1033859153_str3))) {
    V v_t_2424 = heff_tag_n(TAG_Cons, 2, (V[]){v_x_2423, NTAG(TAG_Nil)});
    v_t_2425 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2elinkFlags_24s1339126493x1033859153_str4), v_t_2424});
  } else {
    heff_drop(v_x_2423);
    v_t_2425 = NTAG(TAG_Nil);
  }
  return (g_prelude_2e_2b_2b(v_t_2425, v_acc_2422));
}
V g_heff_2ebuild_2ecommands_2elinkFlags_24s1339126493x1033859153_lam1(V self, V *args) {
  V v_x_248 = args[0];
  V v_x_247 = heff_env(self)[0];
  V v_ls_241 = heff_env(self)[1];
  V v_os_240 = heff_env(self)[2];
  V v_z_243 = heff_env(self)[3];
  V v_x_2429;
  heff_clo_take(self, 4);
  switch (heff_tag_of(v_x_247)) {
  case TAG_Left: {
    V v_why_249 = heff_field(v_x_247, 0);
    V v_ru_24x_247_24Left = heff_take_reuse_n(v_x_247, 1ULL, 1);
    heff_drop(v_x_248);
    heff_drop(v_ls_241);
    heff_drop(v_os_240);
    v_x_2429 = heff_tag_re_n(v_ru_24x_247_24Left, TAG_Left, 1, 1ULL, (V[]){v_why_249});
    break;
  }
  case TAG_Right: {
    V v_cs_2410 = heff_field(v_x_247, 0);
    V v_ru_24x_247_24Right = heff_take_reuse_n(v_x_247, 1ULL, 1);
    switch (heff_tag_of(v_x_248)) {
    case TAG_Left: {
      V v_why_2411 = heff_field(v_x_248, 0);
      V v_ru_24x_248_24Left = heff_take_reuse_n(v_x_248, 1ULL, 1);
      heff_drop(v_ls_241);
      heff_drop(v_os_240);
      heff_drop(v_cs_2410);
      heff_drop_cell(v_ru_24x_247_24Right, 1);
      v_x_2429 = heff_tag_re_n(v_ru_24x_248_24Left, TAG_Left, 1, 1ULL, (V[]){v_why_2411});
      break;
    }
    case TAG_Right: {
      V v_lfs_2412 = heff_field(v_x_248, 0);
      heff_take_n(v_x_248, 1ULL, 1);
      V v_xs_2413 = (g_prelude_2e_2b_2b(v_cs_2410, v_lfs_2412));
      V v_t_2414 = (g_heff_2ebuild_2ecommands_2enubStrGo(NTAG(TAG_Nil), v_xs_2413));
      V v_t_2415 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_ls_241)));
      V v_xs_2416 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2415; V r_ = (g_list_2efoldl_24s1673889684x228869038(a_0, a_1)); heff_drop(v_t_2415); r_; });
      V v_t_2417 = (g_heff_2ebuild_2ecommands_2enubStrGo(NTAG(TAG_Nil), v_xs_2416));
      V v_t_2418 = (g_list_2emap_24s231073986x752637537(((V)&g_heff_2ebuild_2ecommands_2elinkFlags_24s1339126493x1033859153_str2), v_t_2417));
      V v_t_2419 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ls_241));
      V v_xs_2420 = ({ V a_0 = NTAG(TAG_Nil); V a_1 = v_t_2419; V r_ = (g_list_2efoldl_24s586092072x139578797(a_0, a_1)); heff_drop(v_t_2419); r_; });
      V v_t_2421 = (g_list_2efoldl_24f1047446376x6295489(NTAG(TAG_Nil), NTAG(TAG_Nil), v_xs_2420));
      V v_t_2426 = ({ V a_0 = heff_clo_n(g_heff_2ebuild_2ecommands_2elinkFlags_24s1339126493x1033859153_lam2, 2, 1, (V[]){v_os_240}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_2421; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2421); r_; });
      V v_t_2427 = (g_prelude_2e_2b_2b(v_t_2418, v_t_2426));
      V v_t_2428 = (g_prelude_2e_2b_2b(v_t_2414, v_t_2427));
      v_x_2429 = heff_tag_at_n(v_ru_24x_247_24Right, TAG_Right, 1, (V[]){v_t_2428});
      break;
    }
    default: heff_nomatch(v_x_248);
    }
    break;
  }
  default: heff_nomatch(v_x_247);
  }
  V f_ = v_z_243;
  args[0] = v_x_2429;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2elinkFlags_24s1339126493x1033859153_lam0(V self, V *args) {
  V v_x_247 = args[0];
  V v_x_246 = heff_env(self)[0];
  V v_z_242 = heff_env(self)[1];
  V v_ls_241 = heff_env(self)[2];
  V v_os_240 = heff_env(self)[3];
  V v_z_243 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2ebuild_2ecommands_2epkgConfigFlags_24s126508420x808955771(((V)&g_heff_2ebuild_2ecommands_2elinkFlags_24s1339126493x1033859153_str1), v_x_246, v_z_242, heff_clo_n(g_heff_2ebuild_2ecommands_2elinkFlags_24s1339126493x1033859153_lam1, 1, 4, (V[]){v_x_247, v_ls_241, v_os_240, v_z_243})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eselfFrom_24s1101093425x2049115263_str0, 1, "\012");
Clo g_heff_2ebuild_2ecommands_2eselfFrom_24s1101093425x2049115263_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eselfFrom_24s1101093425x2049115263_entry, 5, 0};

V g_heff_2ebuild_2ecommands_2eselfFrom_24s1101093425x2049115263(V v_ps_240, V v_b_241, V v_x3_242, V v_z_243, V v_z_244) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nothing: {
    V v_t_245 = (g_heff_2ebuild_2ecache_2ehashGo(v_b_241, MK_INT(0LL), MK_INT(5381LL), MK_INT(7919LL)));
    HEFF_LAST return g_heff_2ebuild_2ecommands_2eselfKept_24s877584026x861180084(v_ps_240, v_b_241, v_t_245, v_z_243, v_z_244);
  }
  case TAG_Just: {
    V v_kept_246 = heff_field(v_x3_242, 0);
    V v_j_247 = heff_strFind_lent(((V)&g_heff_2ebuild_2ecommands_2eselfFrom_24s1101093425x2049115263_str0), v_kept_246, MK_INT(0LL), 5);
    if (heff_intLt_c_lent(v_j_247, MK_INT(0LL), 2)) {
      heff_drop(v_j_247);
      V v_t_248 = (g_heff_2ebuild_2ecache_2ehashGo(v_b_241, MK_INT(0LL), MK_INT(5381LL), MK_INT(7919LL)));
      HEFF_LAST return g_heff_2ebuild_2ecommands_2eselfKept_24s877584026x861180084(v_ps_240, v_b_241, v_t_248, v_z_243, v_z_244);
    } else {
      V v_t_249 = heff_intSub_lent(heff_strLength_lent(v_kept_246, 0), v_j_247, 1);
      if ((heff_intEq_c(heff_intSub_lent(v_t_249, MK_INT(1LL), 2), heff_strLength_lent(v_b_241, 0)) && heff_strEq_c_lent(heff_strSlice_lent(v_kept_246, heff_intAdd_lent(v_j_247, MK_INT(1LL), 2), heff_strLength_lent(v_kept_246, 0), 6), v_b_241, 1))) {
        heff_drop(v_ps_240);
        heff_drop(v_b_241);
        heff_drop(v_z_243);
        heff_drop(v_t_249);
        return heff_tail(v_z_244, 1, (V[]){heff_strSlice_lent(v_kept_246, MK_INT(0LL), v_j_247, 6)});
      } else {
        heff_drop(v_j_247);
        heff_drop(v_t_249);
        V v_t_2410 = (g_heff_2ebuild_2ecache_2ehashGo(v_b_241, MK_INT(0LL), MK_INT(5381LL), MK_INT(7919LL)));
        HEFF_LAST return g_heff_2ebuild_2ecommands_2eselfKept_24s877584026x861180084(v_ps_240, v_b_241, v_t_2410, v_z_243, v_z_244);
      }
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ebuild_2ecommands_2eselfFrom_24s1101093425x2049115263_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ebuild_2ecommands_2eselfFrom_24s1101093425x2049115263(a[0], a[1], a2, a[3], a[4]); heff_drop(a2); return r;
}

static V g_heff_2ebuild_2ecommands_2ekeptWith_24s328357922x1794949094_24rec0_val;
static HEFF_ONCE g_heff_2ebuild_2ecommands_2ekeptWith_24s328357922x1794949094_24rec0_st;
static V g_heff_2ebuild_2ecommands_2ekeptWith_24s328357922x1794949094_24rec0_init(void) {
  return heff_rec_n(3, shape_ems__s__fresh, (V[]){NTAG(TAG_Nil), heff_dup(g_heff_2ecompile_2eemitc_2eemptyCS_get()), NTAG(TAG_Nil)});
}
V g_heff_2ebuild_2ecommands_2ekeptWith_24s328357922x1794949094_24rec0_get(void) {
  if (HEFF_DONE(g_heff_2ebuild_2ecommands_2ekeptWith_24s328357922x1794949094_24rec0_st)) return g_heff_2ebuild_2ecommands_2ekeptWith_24s328357922x1794949094_24rec0_val;
  return heff_global(&g_heff_2ebuild_2ecommands_2ekeptWith_24s328357922x1794949094_24rec0_val, &g_heff_2ebuild_2ecommands_2ekeptWith_24s328357922x1794949094_24rec0_st, g_heff_2ebuild_2ecommands_2ekeptWith_24s328357922x1794949094_24rec0_init);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2erunCmd_24s1098214412x100466386_str0, 14, "compiling to C");
HEFF_LIT(g_heff_2ebuild_2ecommands_2erunCmd_24s1098214412x100466386_str1, 1, "/");
HEFF_LIT(g_heff_2ebuild_2ecommands_2erunCmd_24s1098214412x100466386_str2, 3, "-O1");
HEFF_LIT(g_heff_2ebuild_2ecommands_2erunCmd_24s1098214412x100466386_str3, 8, "heff run");
HEFF_LIT(g_heff_2ebuild_2ecommands_2erunCmd_24s1098214412x100466386_str4, 4, "main");
V g_heff_2ebuild_2ecommands_2erunCmd_24s1098214412x100466386_lam4(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2erunCmd_24s1098214412x100466386_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2erunCmd_24s1098214412x100466386_lam4, 1, 0};
V g_heff_2ebuild_2ecommands_2erunCmd_24s1098214412x100466386_lam6(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2erunCmd_24s1098214412x100466386_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2erunCmd_24s1098214412x100466386_lam6, 1, 0};
V g_heff_2ebuild_2ecommands_2erunCmd_24s1098214412x100466386_lam9(V self, V *args);
V g_heff_2ebuild_2ecommands_2erunCmd_24s1098214412x100466386_lam8(V self, V *args);
V g_heff_2ebuild_2ecommands_2erunCmd_24s1098214412x100466386_lam11(V self, V *args);
V g_heff_2ebuild_2ecommands_2erunCmd_24s1098214412x100466386_lam10(V self, V *args);
V g_heff_2ebuild_2ecommands_2erunCmd_24s1098214412x100466386_lam7(V self, V *args);
V g_heff_2ebuild_2ecommands_2erunCmd_24s1098214412x100466386_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2erunCmd_24s1098214412x100466386_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2erunCmd_24s1098214412x100466386_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2erunCmd_24s1098214412x100466386_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2erunCmd_24s1098214412x100466386_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2erunCmd_24s1098214412x100466386_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2erunCmd_24s1098214412x100466386_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2erunCmd_24s1098214412x100466386(V v_file_240, V v_fuel_241, V v_progArgs_242) {
top: ;
  V v_c_243 = ((V)&g_heff_2ebuild_2ecommands_2ehostNow_24s621918226x590971294_clo);
  return heff_clo_n(g_heff_2ebuild_2ecommands_2erunCmd_24s1098214412x100466386_lam0, 2, 4, (V[]){v_c_243, v_file_240, v_progArgs_242, v_fuel_241});
}
V g_heff_2ebuild_2ecommands_2erunCmd_24s1098214412x100466386_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2erunCmd_24s1098214412x100466386(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2ecommands_2erunCmd_24s1098214412x100466386_lam4(V self, V *args) {
  V v_t_2411 = args[0];
  return v_t_2411;
}
V g_heff_2ebuild_2ecommands_2erunCmd_24s1098214412x100466386_lam6(V self, V *args) {
  V v_t_2415 = args[0];
  return v_t_2415;
}
V g_heff_2ebuild_2ecommands_2erunCmd_24s1098214412x100466386_lam9(V self, V *args) {
  V v_x_2429 = args[0];
  V v_cmd_2423 = heff_env(self)[0];
  V v_progArgs_242 = heff_env(self)[1];
  V v_hd_2425 = heff_env(self)[2];
  V v_k_2426 = heff_env(self)[3];
  heff_drop(v_x_2429);
  heff_clo_take(self, 4);
  V v_t_2430 = heff_tag_n(TAG_Exec, 3, (V[]){v_cmd_2423, v_progArgs_242, NTAG(TAG_MkUnit)});
  V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2430})});
  V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
  V v_t_2433 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2432})});
  V v_t_2434 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2433})});
  V v_t_2435 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2434})});
  return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2435}), v_hd_2425, v_k_2426));
}
V g_heff_2ebuild_2ecommands_2erunCmd_24s1098214412x100466386_lam8(V self, V *args) {
  V v_hd_2425 = args[0];
  V v_k_2426 = args[1];
  V v_x_2414 = heff_env(self)[0];
  V v_cmd_2423 = heff_env(self)[1];
  V v_progArgs_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2427 = heff_tag_n(TAG_End, 2, (V[]){v_x_2414, NTAG(TAG_MkUnit)});
  V v_t_2428 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
  return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2428}), heff_dup(v_hd_2425), heff_clo_n(g_heff_2ebuild_2ecommands_2erunCmd_24s1098214412x100466386_lam9, 1, 4, (V[]){v_cmd_2423, v_progArgs_242, v_hd_2425, v_k_2426})));
}
V g_heff_2ebuild_2ecommands_2erunCmd_24s1098214412x100466386_lam11(V self, V *args) {
  V v_x_2441 = args[0];
  V v_next_2436 = heff_env(self)[0];
  V v_hd_2437 = heff_env(self)[1];
  V v_k_2438 = heff_env(self)[2];
  heff_drop(v_x_2441);
  heff_clo_take(self, 3);
  V f_ = v_next_2436;
  heff_room[0] = v_hd_2437;
  heff_room[1] = v_k_2438;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2erunCmd_24s1098214412x100466386_lam10(V self, V *args) {
  V v_hd_2437 = args[0];
  V v_k_2438 = args[1];
  V v_x_2418 = heff_env(self)[0];
  V v_next_2436 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2439 = heff_tag_n(TAG_End, 2, (V[]){v_x_2418, NTAG(TAG_MkUnit)});
  V v_t_2440 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2439})});
  return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2440}), heff_dup(v_hd_2437), heff_clo_n(g_heff_2ebuild_2ecommands_2erunCmd_24s1098214412x100466386_lam11, 1, 3, (V[]){v_next_2436, v_hd_2437, v_k_2438})));
}
V g_heff_2ebuild_2ecommands_2erunCmd_24s1098214412x100466386_lam7(V self, V *args) {
  V v_x_2418 = args[0];
  V v_x_2410 = heff_env(self)[0];
  V v_file_240 = heff_env(self)[1];
  V v_x_2414 = heff_env(self)[2];
  V v_progArgs_242 = heff_env(self)[3];
  V v_fuel_241 = heff_env(self)[4];
  V v_hd_244 = heff_env(self)[5];
  V v_k_245 = heff_env(self)[6];
  V v_t_2419 = (g_heff_2ebuild_2ecommands_2erunDir(heff_dup(heff_rfield(v_x_2410, 2)), heff_dup(v_file_240)));
  V v_outPath_2420 = heff_strAppend(v_t_2419, ((V)&g_heff_2ebuild_2ecommands_2erunCmd_24s1098214412x100466386_str1));
  V v_dir_2421 = (g_heff_2ebuild_2ecommands_2erunDir(heff_dup(heff_rfield(v_x_2410, 2)), heff_dup(v_file_240)));
  V v_out_2422 = (g_heff_2ebuild_2ecommands_2erunProgram(heff_dup(heff_rfield(v_x_2410, 2)), heff_dup(v_file_240)));
  V v_cmd_2423 = (g_heff_2ebuild_2ecommands_2erunProgram(heff_dup(heff_rfield(v_x_2410, 2)), heff_dup(v_file_240)));
  V v_t_2424 = heff_get_n(heff_dup(heff_rfield(v_x_2410, 2)), 5, 6);
  heff_clo_take(self, 7);
  V v_next_2436 = (g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s2118406423x605242268(MK_INT(1LL), ((V)&g_heff_2ebuild_2ecommands_2erunCmd_24s1098214412x100466386_str2), ((V)&g_heff_2ebuild_2ecommands_2erunCmd_24s1098214412x100466386_str3), v_t_2424, heff_dup(v_x_2414), v_dir_2421, v_out_2422, heff_clo_n(g_heff_2ebuild_2ecommands_2erunCmd_24s1098214412x100466386_lam8, 2, 3, (V[]){v_x_2414, v_cmd_2423, v_progArgs_242})));
  return (g_heff_2ebuild_2ecommands_2ecLoadedOr_24s1841553671x896002290(MK_INT(1LL), ((V)&g_heff_2ebuild_2ecommands_2erunCmd_24s1098214412x100466386_str4), v_fuel_241, v_x_2410, v_outPath_2420, v_file_240, heff_clo_n(g_heff_2ebuild_2ecommands_2erunCmd_24s1098214412x100466386_lam10, 2, 2, (V[]){v_x_2418, v_next_2436}), v_hd_244, v_k_245));
}
V g_heff_2ebuild_2ecommands_2erunCmd_24s1098214412x100466386_lam5(V self, V *args) {
  V v_x_2414 = args[0];
  V v_hd_244 = heff_env(self)[0];
  V v_x_2410 = heff_env(self)[1];
  V v_file_240 = heff_env(self)[2];
  V v_progArgs_242 = heff_env(self)[3];
  V v_fuel_241 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){heff_dup(v_x_2414), ((V)&g_heff_2ebuild_2ecommands_2erunCmd_24s1098214412x100466386_str0), MK_INT(0LL), ((V)&g_heff_2ebuild_2ecommands_2erunCmd_24s1098214412x100466386_lam6_clo)})});
  V v_t_2417 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2416})});
  heff_clo_take(self, 6);
  return (g_co_2eop_24s535099379x685970669(v_t_2417, heff_dup(v_hd_244), heff_clo_n(g_heff_2ebuild_2ecommands_2erunCmd_24s1098214412x100466386_lam7, 1, 7, (V[]){v_x_2410, v_file_240, v_x_2414, v_progArgs_242, v_fuel_241, v_hd_244, v_k_245})));
}
V g_heff_2ebuild_2ecommands_2erunCmd_24s1098214412x100466386_lam3(V self, V *args) {
  V v_x_248 = args[0];
  V v_x_247 = heff_env(self)[0];
  V v_file_240 = heff_env(self)[1];
  V v_hd_244 = heff_env(self)[2];
  V v_progArgs_242 = heff_env(self)[3];
  V v_fuel_241 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  V v_t_249 = (g_heff_2ebuild_2ecommands_2eheffErrors(v_x_248, heff_dup(heff_rfield(v_x_247, 4))));
  heff_clo_take(self, 6);
  V v_x_2410 = (g_list_2efoldl_24s571074576x1179600767(v_x_247, v_t_249));
  V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){heff_dup(g_std_2eprogress_2eroot_get()), heff_dup(v_file_240), MK_INT(2LL), ((V)&g_heff_2ebuild_2ecommands_2erunCmd_24s1098214412x100466386_lam4_clo)})});
  V v_t_2413 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2412})});
  return (g_co_2eop_24s535099379x685970669(v_t_2413, heff_dup(v_hd_244), heff_clo_n(g_heff_2ebuild_2ecommands_2erunCmd_24s1098214412x100466386_lam5, 1, 6, (V[]){v_hd_244, v_x_2410, v_file_240, v_progArgs_242, v_fuel_241, v_k_245})));
}
V g_heff_2ebuild_2ecommands_2erunCmd_24s1098214412x100466386_lam2(V self, V *args) {
  V v_x_247 = args[0];
  V v_hd_244 = heff_env(self)[0];
  V v_file_240 = heff_env(self)[1];
  V v_progArgs_242 = heff_env(self)[2];
  V v_fuel_241 = heff_env(self)[3];
  V v_k_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2ebuild_2ecommands_2eownVersion_24s2092229395x529638551(heff_dup(v_hd_244), heff_clo_n(g_heff_2ebuild_2ecommands_2erunCmd_24s1098214412x100466386_lam3, 1, 6, (V[]){v_x_247, v_file_240, v_hd_244, v_progArgs_242, v_fuel_241, v_k_245})));
}
V g_heff_2ebuild_2ecommands_2erunCmd_24s1098214412x100466386_lam1(V self, V *args) {
  V v_x_246 = args[0];
  V v_file_240 = heff_env(self)[0];
  V v_hd_244 = heff_env(self)[1];
  V v_progArgs_242 = heff_env(self)[2];
  V v_fuel_241 = heff_env(self)[3];
  V v_k_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return (g_heff_2ebuild_2eload_2eloadProgramWith_24s1839248718x121761575(v_x_246, heff_dup(v_file_240), heff_dup(v_hd_244), heff_clo_n(g_heff_2ebuild_2ecommands_2erunCmd_24s1098214412x100466386_lam2, 1, 5, (V[]){v_hd_244, v_file_240, v_progArgs_242, v_fuel_241, v_k_245})));
}
V g_heff_2ebuild_2ecommands_2erunCmd_24s1098214412x100466386_lam0(V self, V *args) {
  V v_hd_244 = args[0];
  V v_k_245 = args[1];
  V v_c_243 = heff_env(self)[0];
  V v_file_240 = heff_env(self)[1];
  V v_progArgs_242 = heff_env(self)[2];
  V v_fuel_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_243;
  args[0] = heff_dup(v_hd_244);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2erunCmd_24s1098214412x100466386_lam1, 1, 5, (V[]){v_file_240, v_hd_244, v_progArgs_242, v_fuel_241, v_k_245});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ediagCount_24s804020149x363911067_str0, 2, ": ");
V g_heff_2ebuild_2ecommands_2ediagCount_24s804020149x363911067_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ediagCount_24s804020149x363911067_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ediagCount_24s804020149x363911067_lam0, 2, 0};
V g_heff_2ebuild_2ecommands_2ediagCount_24s804020149x363911067_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ediagCount_24s804020149x363911067_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ediagCount_24s804020149x363911067_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ediagCount_24s804020149x363911067_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ediagCount_24s804020149x363911067_entry, 1, 0};

V g_heff_2ebuild_2ecommands_2ediagCount_24s804020149x363911067(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return ((V)&g_heff_2ebuild_2ecommands_2ediagCount_24s804020149x363911067_lam0_clo);
  }
  case TAG_Cons: {
    V v_c_243 = heff_field(v_x1_240, 0);
    V v_rest_244 = heff_field(v_x1_240, 1);
    V v_diags_245 = heff_dup(heff_rfield(v_c_243, 6));
    V v_module_246 = heff_dup(heff_rfield(v_c_243, 0));
    V v_t_247 = (g_list_2emap_24s328934344x1728860012(((V)&g_heff_2ebuild_2ecommands_2ediagCount_24s804020149x363911067_str0), heff_dup(v_diags_245)));
    return heff_clo_n(g_heff_2ebuild_2ecommands_2ediagCount_24s804020149x363911067_lam1, 2, 4, (V[]){v_module_246, v_t_247, heff_dup(v_rest_244), v_diags_245});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2ecommands_2ediagCount_24s804020149x363911067_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2ediagCount_24s804020149x363911067(a0); heff_drop(a0); return r;
}
V g_heff_2ebuild_2ecommands_2ediagCount_24s804020149x363911067_lam0(V self, V *args) {
  V v_hd_241 = args[0];
  V v_k_242 = args[1];
  heff_drop(v_hd_241);
  V f_ = v_k_242;
  args[0] = MK_INT(0LL);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ediagCount_24s804020149x363911067_lam3(V self, V *args) {
  V v_x_2412 = args[0];
  V v_diags_245 = heff_env(self)[0];
  V v_k_249 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2413 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_diags_245; V r_ = (g_list_2efoldl_24f2094160282x1876485468(a_0, a_1, a_2)); heff_drop(v_diags_245); r_; });
  V v_x_2414 = heff_intAdd(v_t_2413, v_x_2412);
  V f_ = v_k_249;
  args[0] = v_x_2414;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ediagCount_24s804020149x363911067_lam2(V self, V *args) {
  V v_x_2410 = args[0];
  V v_rest_244 = heff_env(self)[0];
  V v_hd_248 = heff_env(self)[1];
  V v_diags_245 = heff_env(self)[2];
  V v_k_249 = heff_env(self)[3];
  heff_drop(v_x_2410);
  heff_clo_take(self, 4);
  V v_t_2411 = ({ V a_0 = v_rest_244; V r_ = (g_heff_2ebuild_2ecommands_2ediagCount_24s804020149x363911067(a_0)); heff_drop(v_rest_244); r_; });
  V f_ = v_t_2411;
  heff_room[0] = v_hd_248;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ediagCount_24s804020149x363911067_lam3, 1, 2, (V[]){v_diags_245, v_k_249});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ediagCount_24s804020149x363911067_lam1(V self, V *args) {
  V v_hd_248 = args[0];
  V v_k_249 = args[1];
  V v_module_246 = heff_env(self)[0];
  V v_t_247 = heff_env(self)[1];
  V v_rest_244 = heff_env(self)[2];
  V v_diags_245 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2ebuild_2ecommands_2eprintErrs_24s1767649266x747632805(v_module_246, v_t_247, MK_INT(0LL), heff_dup(v_hd_248), heff_clo_n(g_heff_2ebuild_2ecommands_2ediagCount_24s804020149x363911067_lam2, 1, 4, (V[]){v_rest_244, v_hd_248, v_diags_245, v_k_249})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigLinked_24s604520448x37455075_str0, 3, "-lm");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigLinked_24s604520448x37455075_str1, 2, "-o");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigLinked_24s604520448x37455075_str2, 2, "-w");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigLinked_24s604520448x37455075_str3, 2, "cc");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ezigLinked_24s604520448x37455075_str4, 3, "zig");
V g_heff_2ebuild_2ecommands_2ezigLinked_24s604520448x37455075_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ezigLinked_24s604520448x37455075_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ezigLinked_24s604520448x37455075_lam0, 1, 0};
Clo g_heff_2ebuild_2ecommands_2ezigLinked_24s604520448x37455075_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ezigLinked_24s604520448x37455075_entry, 9, 0};

V g_heff_2ebuild_2ecommands_2ezigLinked_24s604520448x37455075(V v_lit_240, V v_lit_241, V v_z_242, V v_links_243, V v_files_244, V v_out_245, V v_x6_246, V v_z_247, V v_z_248) {
top: ;
  switch (heff_tag_of(v_x6_246)) {
  case TAG_Left: {
    V v_r_249 = heff_field(v_x6_246, 0);
    heff_take_n(v_x6_246, 1ULL, 1);
    heff_drop(v_lit_240);
    heff_drop(v_lit_241);
    heff_drop(v_z_242);
    heff_drop(v_links_243);
    heff_drop(v_files_244);
    heff_drop(v_out_245);
    heff_drop(v_z_247);
    return heff_tail(v_z_248, 1, (V[]){v_r_249});
  }
  case TAG_Right: {
    V v_os_2410 = heff_field(v_x6_246, 0);
    V v_ru_24x6_246_24Right = heff_take_reuse_n(v_x6_246, 1ULL, 1);
    V v_t_2411 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ezigLinked_24s604520448x37455075_str0), NTAG(TAG_Nil)});
    V v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ezigLinked_24s604520448x37455075_str1), heff_tag_n(TAG_Cons, 2, (V[]){v_out_245, v_t_2411})});
    V v_t_2413 = (g_prelude_2e_2b_2b(v_links_243, v_t_2412));
    V v_t_2414 = (g_prelude_2e_2b_2b(v_os_2410, v_t_2413));
    V v_t_2415 = (g_prelude_2e_2b_2b(v_files_244, v_t_2414));
    V v_ys_2416 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ezigLinked_24s604520448x37455075_str2), v_t_2415});
    V v_t_2417 = heff_tag_n(TAG_Cons, 2, (V[]){v_lit_240, heff_tag_n(TAG_Cons, 2, (V[]){v_lit_241, v_ys_2416})});
    V v_argv_2418 = heff_tag_n(TAG_Cons, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ezigLinked_24s604520448x37455075_str3), v_t_2417});
    V v_t_2420 = heff_tag_at_n(v_ru_24x6_246_24Right, TAG_InL, 1, (V[]){heff_tag_n(TAG_RunUnder, 4, (V[]){v_z_242, ((V)&g_heff_2ebuild_2ecommands_2ezigLinked_24s604520448x37455075_str4), v_argv_2418, ((V)&g_heff_2ebuild_2ecommands_2ezigLinked_24s604520448x37455075_lam0_clo)})});
    V v_t_2421 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2420})});
    return (g_co_2eop_24s297957795x1045074450(v_t_2421, v_z_247, v_z_248));
  }
  default: return heff_nomatch(v_x6_246);
  }
}
V g_heff_2ebuild_2ecommands_2ezigLinked_24s604520448x37455075_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ezigLinked_24s604520448x37455075(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8]);
}
V g_heff_2ebuild_2ecommands_2ezigLinked_24s604520448x37455075_lam0(V self, V *args) {
  V v_r_2419 = args[0];
  return v_r_2419;
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1277531008x1788456998_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1277531008x1788456998_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1277531008x1788456998_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1277531008x1788456998_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1277531008x1788456998_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1277531008x1788456998_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1277531008x1788456998_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1277531008x1788456998_entry, 9, 0};

V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1277531008x1788456998(V v_lit_240, V v_lit_241, V v_failed_242, V v_who_243, V v_st_244, V v_p_245, V v_dir_246, V v_out_247, V v_next_248) {
top: ;
  V v_path_249 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), heff_dup(v_dir_246)));
  V v_t_2410 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_249; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); r_; });
  V v_a_2412 = heff_tag_n(TAG_ReadDirectory, 2, (V[]){v_t_2410, ((V)&g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1277531008x1788456998_lam0_clo)});
  return heff_clo_n(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1277531008x1788456998_lam1, 2, 11, (V[]){v_a_2412, v_st_244, v_dir_246, v_p_245, v_lit_240, v_lit_241, v_out_247, v_next_248, v_who_243, v_failed_242, v_path_249});
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1277531008x1788456998_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1277531008x1788456998(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8]);
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1277531008x1788456998_lam0(V self, V *args) {
  V v_r_2411 = args[0];
  return v_r_2411;
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1277531008x1788456998_lam3(V self, V *args) {
  V v_n_2425 = args[0];
  V v_path_249 = heff_env(self)[0];
  V v_t_2426 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_n_2425));
  heff_clo_take(self, 1);
  return (g_std_2epath_2ejoin(v_path_249, v_t_2426));
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1277531008x1788456998_lam2(V self, V *args) {
  V v_x_2420 = args[0];
  V v_st_244 = heff_env(self)[0];
  V v_dir_246 = heff_env(self)[1];
  V v_p_245 = heff_env(self)[2];
  V v_hd_2413 = heff_env(self)[3];
  V v_lit_240 = heff_env(self)[4];
  V v_lit_241 = heff_env(self)[5];
  V v_out_247 = heff_env(self)[6];
  V v_next_248 = heff_env(self)[7];
  V v_k_2414 = heff_env(self)[8];
  V v_who_243 = heff_env(self)[9];
  V v_failed_242 = heff_env(self)[10];
  V v_path_249 = heff_env(self)[11];
  switch (heff_tag_of(v_x_2420)) {
  case TAG_Left: {
    V v_x_2421 = heff_field(v_x_2420, 0);
    V v_ru_24x_2420_24Left = heff_take_reuse_n(v_x_2420, 1ULL, 1);
    heff_clo_take(self, 12);
    heff_drop(v_path_249);
    return (g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1277531008x1788456998_2ek_24l1(v_st_244, v_dir_246, v_p_245, v_hd_2413, v_lit_240, v_lit_241, v_out_247, v_next_248, v_k_2414, v_who_243, v_failed_242, heff_tag_re_n(v_ru_24x_2420_24Left, TAG_Left, 1, 1ULL, (V[]){v_x_2421})));
  }
  case TAG_Right: {
    V v_y_2422 = heff_field(v_x_2420, 0);
    V v_ru_24x_2420_24Right = heff_take_reuse_n(v_x_2420, 1ULL, 1);
    switch (heff_tag_of(v_y_2422)) {
    case TAG_Left: {
      V v_err_2423 = heff_field(v_y_2422, 0);
      V v_ru_24y_2422_24Left = heff_take_reuse_n(v_y_2422, 1ULL, 1);
      heff_clo_take(self, 12);
      heff_drop(v_path_249);
      heff_drop_cell(v_ru_24x_2420_24Right, 1);
      return (g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1277531008x1788456998_2ek_24l1(v_st_244, v_dir_246, v_p_245, v_hd_2413, v_lit_240, v_lit_241, v_out_247, v_next_248, v_k_2414, v_who_243, v_failed_242, heff_tag_re_n(v_ru_24y_2422_24Left, TAG_Left, 1, 1ULL, (V[]){v_err_2423})));
    }
    case TAG_Right: {
      V v_x_2424 = heff_field(v_y_2422, 0);
      heff_take_n(v_y_2422, 1ULL, 1);
      heff_clo_take(self, 12);
      V v_x_2427 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1277531008x1788456998_lam3, 1, 1, (V[]){v_path_249}), v_x_2424));
      V v_x_2428 = (g_list_2emap_24s219049803x1458391381(v_x_2427));
      return (g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1277531008x1788456998_2ek_24l1(v_st_244, v_dir_246, v_p_245, v_hd_2413, v_lit_240, v_lit_241, v_out_247, v_next_248, v_k_2414, v_who_243, v_failed_242, heff_tag_at_n(v_ru_24x_2420_24Right, TAG_Right, 1, (V[]){v_x_2428})));
    }
    default: return heff_nomatch(v_y_2422);
    }
  }
  default: return heff_nomatch(v_x_2420);
  }
}
V g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1277531008x1788456998_lam1(V self, V *args) {
  V v_hd_2413 = args[0];
  V v_k_2414 = args[1];
  V v_a_2412 = heff_env(self)[0];
  V v_st_244 = heff_env(self)[1];
  V v_dir_246 = heff_env(self)[2];
  V v_p_245 = heff_env(self)[3];
  V v_lit_240 = heff_env(self)[4];
  V v_lit_241 = heff_env(self)[5];
  V v_out_247 = heff_env(self)[6];
  V v_next_248 = heff_env(self)[7];
  V v_who_243 = heff_env(self)[8];
  V v_failed_242 = heff_env(self)[9];
  V v_path_249 = heff_env(self)[10];
  heff_clo_take(self, 11);
  V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2412})});
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2418})});
  return (g_co_2eop_24s1896221640x2141527803(v_t_2419, heff_dup(v_hd_2413), heff_clo_n(g_heff_2ebuild_2ecommands_2ezigBuildFlagsOr_24s1277531008x1788456998_lam2, 1, 12, (V[]){v_st_244, v_dir_246, v_p_245, v_hd_2413, v_lit_240, v_lit_241, v_out_247, v_next_248, v_k_2414, v_who_243, v_failed_242, v_path_249})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadProviders_24s491885588x407035296_str0, 3, ".hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ereadProviders_24s491885588x407035296_str1, 12, ".provider.js");
V g_heff_2ebuild_2ecommands_2ereadProviders_24s491885588x407035296_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ereadProviders_24s491885588x407035296_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ereadProviders_24s491885588x407035296_lam0, 2, 0};
V g_heff_2ebuild_2ecommands_2ereadProviders_24s491885588x407035296_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ereadProviders_24s491885588x407035296_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ereadProviders_24s491885588x407035296_lam1, 1, 0};
V g_heff_2ebuild_2ecommands_2ereadProviders_24s491885588x407035296_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ereadProviders_24s491885588x407035296_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ereadProviders_24s491885588x407035296_lam4(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ereadProviders_24s491885588x407035296_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ereadProviders_24s491885588x407035296_lam4, 2, 0};
V g_heff_2ebuild_2ecommands_2ereadProviders_24s491885588x407035296_lam7(V self, V *args);
V g_heff_2ebuild_2ecommands_2ereadProviders_24s491885588x407035296_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2ereadProviders_24s491885588x407035296_lam5(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ereadProviders_24s491885588x407035296_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ereadProviders_24s491885588x407035296_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2ereadProviders_24s491885588x407035296(V v_sources_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_sources_240);
    return ((V)&g_heff_2ebuild_2ecommands_2ereadProviders_24s491885588x407035296_lam0_clo);
  }
  case TAG_Cons: {
    V v_m_244 = heff_field(v_x2_241, 0);
    V v_rest_245 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_sources_246 = heff_dup(v_sources_240);
    V v_m_247 = v_m_244;
    HeffT2 v_t_248 = ({ V a_0 = v_sources_246; V a_1 = v_m_247; HeffT2 r_ = (g_heff_2ebuild_2ecommands_2epathOfModule_24cpr(a_0, a_1)); heff_drop(v_sources_246); r_; });
    {
      V v_field_2410 = v_t_248.f[1];
      int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
      V v_c_2435;
      if ((v_tag_249 == ((int64_t)0ULL))) {
        V v_path_2411 = v_field_2410;
        int64_t v_t_2412 = (heff_unbox_word(heff_strLength_lent(v_path_2411, 0)) - ((int64_t)3ULL));
        V v_t_2413 = heff_strSlice_lent(v_path_2411, heff_box_word(v_t_2412), heff_strLength_lent(v_path_2411, 0), 6);
        V v_t_2415;
        if (heff_strEq_c(v_t_2413, ((V)&g_heff_2ebuild_2ecommands_2ereadProviders_24s491885588x407035296_str0))) {
          int64_t v_t_2414 = (heff_unbox_word(heff_strLength_lent(v_path_2411, 0)) - ((int64_t)3ULL));
          v_t_2415 = heff_strSlice(v_path_2411, MK_INT(0LL), heff_box_word(v_t_2414));
        } else {
          v_t_2415 = v_path_2411;
        }
        V v_path_2416 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), heff_strAppend(v_t_2415, ((V)&g_heff_2ebuild_2ecommands_2ereadProviders_24s491885588x407035296_str1))));
        V v_t_2417 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2416; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_2416); r_; });
        V v_a_2419 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_ReadFile, 2, (V[]){v_t_2417, ((V)&g_heff_2ebuild_2ecommands_2ereadProviders_24s491885588x407035296_lam1_clo)});
        v_c_2435 = heff_clo_n(g_heff_2ebuild_2ecommands_2ereadProviders_24s491885588x407035296_lam2, 2, 2, (V[]){v_a_2419, v_m_247});
      } else {
        heff_drop_cell(v_ru_24x2_241_24Cons, 2);
        heff_drop(v_m_247);
        heff_drop(v_field_2410);
        v_c_2435 = ((V)&g_heff_2ebuild_2ecommands_2ereadProviders_24s491885588x407035296_lam4_clo);
      }
      return heff_clo_n(g_heff_2ebuild_2ecommands_2ereadProviders_24s491885588x407035296_lam5, 2, 3, (V[]){v_c_2435, v_sources_240, v_rest_245});
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2ecommands_2ereadProviders_24s491885588x407035296_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ereadProviders_24s491885588x407035296(a[0], a[1]);
}
V g_heff_2ebuild_2ecommands_2ereadProviders_24s491885588x407035296_lam0(V self, V *args) {
  V v_hd_242 = args[0];
  V v_k_243 = args[1];
  heff_drop(v_hd_242);
  V f_ = v_k_243;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ereadProviders_24s491885588x407035296_lam1(V self, V *args) {
  V v_r_2418 = args[0];
  return v_r_2418;
}
V g_heff_2ebuild_2ecommands_2ereadProviders_24s491885588x407035296_lam3(V self, V *args) {
  V v_x_2427 = args[0];
  V v_k_2421 = heff_env(self)[0];
  V v_m_247 = heff_env(self)[1];
  switch (heff_tag_of(v_x_2427)) {
  case TAG_Left: {
    heff_take_n(v_x_2427, 0ULL, 1);
    heff_clo_take(self, 2);
    heff_drop(v_m_247);
    V f_ = v_k_2421;
    args[0] = NTAG(TAG_Nothing);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Right: {
    V v_y_2429 = heff_field(v_x_2427, 0);
    V v_ru_24x_2427_24Right = heff_take_reuse_n(v_x_2427, 1ULL, 1);
    switch (heff_tag_of(v_y_2429)) {
    case TAG_Left: {
      heff_take_n(v_y_2429, 0ULL, 1);
      heff_clo_take(self, 2);
      heff_drop(v_m_247);
      heff_drop_cell(v_ru_24x_2427_24Right, 1);
      V f_ = v_k_2421;
      args[0] = NTAG(TAG_Nothing);
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    case TAG_Right: {
      V v_x_2431 = heff_field(v_y_2429, 0);
      heff_take_n(v_y_2429, 1ULL, 1);
      heff_clo_take(self, 2);
      V v_t_2432 = heff_tag_at_n(v_ru_24x_2427_24Right, TAG_Just, 1, (V[]){heff_rec_n(2, shape_module__text, (V[]){v_m_247, v_x_2431})});
      V f_ = v_k_2421;
      args[0] = v_t_2432;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    default: return heff_nomatch(v_y_2429);
    }
  }
  default: return heff_nomatch(v_x_2427);
  }
}
V g_heff_2ebuild_2ecommands_2ereadProviders_24s491885588x407035296_lam2(V self, V *args) {
  V v_hd_2420 = args[0];
  V v_k_2421 = args[1];
  V v_a_2419 = heff_env(self)[0];
  V v_m_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2419})});
  V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
  V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
  V v_t_2425 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
  V v_t_2426 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2425})});
  return (g_co_2eop_24s1896221640x2141527803(v_t_2426, v_hd_2420, heff_clo_n(g_heff_2ebuild_2ecommands_2ereadProviders_24s491885588x407035296_lam3, 1, 2, (V[]){v_k_2421, v_m_247})));
}
V g_heff_2ebuild_2ecommands_2ereadProviders_24s491885588x407035296_lam4(V self, V *args) {
  V v_hd_2433 = args[0];
  V v_k_2434 = args[1];
  heff_drop(v_hd_2433);
  V f_ = v_k_2434;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ereadProviders_24s491885588x407035296_lam7(V self, V *args) {
  V v_x_2440 = args[0];
  V v_x_2438 = heff_env(self)[0];
  V v_k_2437 = heff_env(self)[1];
  V v_t_2442;
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_x_2438)) {
  case TAG_Nothing: {
    v_t_2442 = v_x_2440;
    break;
  }
  case TAG_Just: {
    V v_pr_2441 = heff_field(v_x_2438, 0);
    heff_take_n(v_x_2438, 1ULL, 1);
    v_t_2442 = heff_tag_n(TAG_Cons, 2, (V[]){v_pr_2441, v_x_2440});
    break;
  }
  default: heff_nomatch(v_x_2438);
  }
  V f_ = v_k_2437;
  args[0] = v_t_2442;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ereadProviders_24s491885588x407035296_lam6(V self, V *args) {
  V v_x_2438 = args[0];
  V v_sources_240 = heff_env(self)[0];
  V v_rest_245 = heff_env(self)[1];
  V v_hd_2436 = heff_env(self)[2];
  V v_k_2437 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2439 = (g_heff_2ebuild_2ecommands_2ereadProviders_24s491885588x407035296(v_sources_240, v_rest_245));
  V f_ = v_t_2439;
  heff_room[0] = v_hd_2436;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ereadProviders_24s491885588x407035296_lam7, 1, 2, (V[]){v_x_2438, v_k_2437});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ereadProviders_24s491885588x407035296_lam5(V self, V *args) {
  V v_hd_2436 = args[0];
  V v_k_2437 = args[1];
  V v_c_2435 = heff_env(self)[0];
  V v_sources_240 = heff_env(self)[1];
  V v_rest_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_2435;
  args[0] = heff_dup(v_hd_2436);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ereadProviders_24s491885588x407035296_lam6, 1, 4, (V[]){v_sources_240, v_rest_245, v_hd_2436, v_k_2437});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileFound_24s773429454x742097977_str0, 6, "heff: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileFound_24s773429454x742097977_str1, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileFound_24s773429454x742097977_str2, 1, "\012");
V g_heff_2ebuild_2ecommands_2ecompileFound_24s773429454x742097977_lam0(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileFound_24s773429454x742097977_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ecompileFound_24s773429454x742097977_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecompileFound_24s773429454x742097977_entry, 9, 0};

V g_heff_2ebuild_2ecommands_2ecompileFound_24s773429454x742097977(V v_bi_240, V v_file_241, V v_name_242, V v_outPath_243, V v_done_244, V v_c_245, V v_available_246, V v_z_247, V v_z_248) {
top: ;
  V v_t_249 = (g_heff_2ebuild_2edriver_2ecandidatesOf(heff_dup(v_c_245)));
  V v_t_2410 = ({ V a_0 = v_t_249; V r_ = (g_heff_2ebuild_2edriver_2ecandLeaves(a_0)); heff_drop(v_t_249); r_; });
  V v_t_2411 = (g_heff_2ebuild_2edriver_2enubStrD(v_t_2410));
  V v_t_2413 = (g_list_2ekeepIf(heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileFound_24s773429454x742097977_lam0, 1, 1, (V[]){heff_dup(v_available_246)}), v_t_2411));
  HeffT2 v_t_2414 = (g_heff_2ebuild_2edriver_2efindRunnable_24cpr(v_t_2413, heff_dup(v_c_245), v_name_242));
  {
    V v_field_2416 = v_t_2414.f[1];
    int64_t v_tag_2415 = ((int64_t)v_t_2414.f[0]);
    if ((v_tag_2415 == ((int64_t)0ULL))) {
      heff_drop(v_bi_240);
      heff_drop(v_outPath_243);
      heff_drop(v_done_244);
      heff_drop(v_c_245);
      heff_drop(v_available_246);
      V v_why_2417 = v_field_2416;
      V v_t_2418 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ecompileFound_24s773429454x742097977_str0), v_file_241), ((V)&g_heff_2ebuild_2ecommands_2ecompileFound_24s773429454x742097977_str1));
      V v_t_2419 = heff_strAppend(heff_strAppend(v_t_2418, v_why_2417), ((V)&g_heff_2ebuild_2ecommands_2ecompileFound_24s773429454x742097977_str2));
      V v_t_2420 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2419, NTAG(TAG_MkUnit)});
      V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
      V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
      V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
      V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
      V v_t_2425 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2424})});
      return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2425}), heff_dup(v_z_247), heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileFound_24s773429454x742097977_lam1, 1, 2, (V[]){v_z_247, v_z_248})));
    } else {
      heff_drop(v_file_241);
      V v_r_2433 = v_field_2416;
      return (g_heff_2ebuild_2ecommands_2ejsKept_24s465101055x1867051052(v_bi_240, v_outPath_243, v_done_244, v_c_245, v_available_246, v_r_2433, v_z_247, v_z_248));
    }
  }
}
V g_heff_2ebuild_2ecommands_2ecompileFound_24s773429454x742097977_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ebuild_2ecommands_2ecompileFound_24s773429454x742097977(a[0], a[1], a2, a[3], a[4], a[5], a[6], a[7], a[8]); heff_drop(a2); return r;
}
V g_heff_2ebuild_2ecommands_2ecompileFound_24s773429454x742097977_lam0(V self, V *args) {
  V v_k_2412 = args[0];
  V v_available_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V a_0 = v_available_246; V a_1 = v_k_2412; V r_ = (g_heff_2ebuild_2ecommands_2eprovidesLeaf(a_0, a_1)); heff_drop(v_available_246); r_; });
}
V g_heff_2ebuild_2ecommands_2ecompileFound_24s773429454x742097977_lam1(V self, V *args) {
  V v_x_2426 = args[0];
  V v_z_247 = heff_env(self)[0];
  V v_z_248 = heff_env(self)[1];
  heff_drop(v_x_2426);
  V v_t_2427 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2427})});
  V v_t_2429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
  V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
  V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
  V v_t_2432 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2431})});
  heff_clo_take(self, 2);
  return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2432}), v_z_247, v_z_248));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileThen_24s1554913905x1093172886_str0, 4, "heff");
V g_heff_2ebuild_2ecommands_2ecompileThen_24s1554913905x1093172886_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileThen_24s1554913905x1093172886_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileThen_24s1554913905x1093172886_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileThen_24s1554913905x1093172886_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileThen_24s1554913905x1093172886_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ecompileThen_24s1554913905x1093172886_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecompileThen_24s1554913905x1093172886_entry, 7, 0};

V g_heff_2ebuild_2ecommands_2ecompileThen_24s1554913905x1093172886(V v_fuel_240, V v_name_241, V v_outPath_242, V v_file_243, V v_done_244, V v_z_245, V v_z_246) {
top: ;
  V v_c_247 = ((V)&g_heff_2ebuild_2ecommands_2ehostNow_24s621918226x590971294_clo);
  return heff_tail(v_c_247, 2, (V[]){heff_dup(v_z_245), heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileThen_24s1554913905x1093172886_lam0, 1, 7, (V[]){v_file_243, v_z_245, v_fuel_240, heff_dup(v_name_241), v_outPath_242, v_done_244, v_z_246})});
}
V g_heff_2ebuild_2ecommands_2ecompileThen_24s1554913905x1093172886_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2ecommands_2ecompileThen_24s1554913905x1093172886(a[0], a1, a[2], a[3], a[4], a[5], a[6]); heff_drop(a1); return r;
}
V g_heff_2ebuild_2ecommands_2ecompileThen_24s1554913905x1093172886_lam4(V self, V *args) {
  V v_x_2415 = args[0];
  V v_x_2412 = heff_env(self)[0];
  V v_fuel_240 = heff_env(self)[1];
  V v_x_2413 = heff_env(self)[2];
  V v_file_243 = heff_env(self)[3];
  V v_name_241 = heff_env(self)[4];
  V v_outPath_242 = heff_env(self)[5];
  V v_done_244 = heff_env(self)[6];
  V v_z_245 = heff_env(self)[7];
  V v_z_246 = heff_env(self)[8];
  V v_done_2416 = heff_take_field(v_x_2415, 0);
  V v_hashes_2417 = heff_get_n(v_x_2415, 1, 2);
  V v_t_2418 = (g_list_2emap_24s1698496827x1884878103(heff_dup(v_done_2416)));
  heff_clo_take(self, 9);
  V v_t_2419 = heff_rec_n(4, shape_paths__hashes__modules__fuel, (V[]){heff_take_field(v_x_2412, 2), v_hashes_2417, v_t_2418, v_fuel_240});
  V v_t_2420 = heff_bool(heff_intLt_c_lent(MK_INT(0LL), v_x_2413, 1));
  heff_drop(v_x_2413);
  return ({ V a_0 = v_t_2419; V a_1 = heff_get_n(v_x_2412, 0, 5); V a_2 = v_file_243; V a_3 = v_name_241; V a_4 = v_outPath_242; V a_5 = v_done_244; V a_6 = v_t_2420; V a_7 = v_done_2416; V a_8 = v_z_245; V a_9 = v_z_246; V r_ = (g_heff_2ebuild_2ecommands_2ecompileDiags_24s373786925x1761510953(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9)); heff_drop(v_name_241); heff_drop(v_t_2420); r_; });
}
V g_heff_2ebuild_2ecommands_2ecompileThen_24s1554913905x1093172886_lam3(V self, V *args) {
  V v_x_2413 = args[0];
  V v_x_2412 = heff_env(self)[0];
  V v_z_245 = heff_env(self)[1];
  V v_fuel_240 = heff_env(self)[2];
  V v_file_243 = heff_env(self)[3];
  V v_name_241 = heff_env(self)[4];
  V v_outPath_242 = heff_env(self)[5];
  V v_done_244 = heff_env(self)[6];
  V v_z_246 = heff_env(self)[7];
  V v_t_2414 = (g_heff_2ebuild_2esession_2ecachedAcc_24s1189406870x118640775(heff_dup(v_x_2412)));
  heff_clo_take(self, 8);
  V f_ = v_t_2414;
  heff_room[0] = heff_dup(v_z_245);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileThen_24s1554913905x1093172886_lam4, 1, 9, (V[]){v_x_2412, v_fuel_240, v_x_2413, v_file_243, v_name_241, v_outPath_242, v_done_244, v_z_245, v_z_246});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ecompileThen_24s1554913905x1093172886_lam2(V self, V *args) {
  V v_x_2410 = args[0];
  V v_x_249 = heff_env(self)[0];
  V v_z_245 = heff_env(self)[1];
  V v_fuel_240 = heff_env(self)[2];
  V v_file_243 = heff_env(self)[3];
  V v_name_241 = heff_env(self)[4];
  V v_outPath_242 = heff_env(self)[5];
  V v_done_244 = heff_env(self)[6];
  V v_z_246 = heff_env(self)[7];
  V v_t_2411 = (g_heff_2ebuild_2ecommands_2eheffErrors(v_x_2410, heff_dup(heff_rfield(v_x_249, 4))));
  heff_clo_take(self, 8);
  V v_x_2412 = (g_list_2efoldl_24s571074576x1179600767(v_x_249, v_t_2411));
  return (g_heff_2ebuild_2ecommands_2eprintErrs_24s1767649266x747632805(((V)&g_heff_2ebuild_2ecommands_2ecompileThen_24s1554913905x1093172886_str0), heff_dup(heff_rfield(v_x_2412, 1)), MK_INT(0LL), heff_dup(v_z_245), heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileThen_24s1554913905x1093172886_lam3, 1, 8, (V[]){v_x_2412, v_z_245, v_fuel_240, v_file_243, v_name_241, v_outPath_242, v_done_244, v_z_246})));
}
V g_heff_2ebuild_2ecommands_2ecompileThen_24s1554913905x1093172886_lam1(V self, V *args) {
  V v_x_249 = args[0];
  V v_z_245 = heff_env(self)[0];
  V v_fuel_240 = heff_env(self)[1];
  V v_file_243 = heff_env(self)[2];
  V v_name_241 = heff_env(self)[3];
  V v_outPath_242 = heff_env(self)[4];
  V v_done_244 = heff_env(self)[5];
  V v_z_246 = heff_env(self)[6];
  heff_clo_take(self, 7);
  return (g_heff_2ebuild_2ecommands_2eownVersion_24s2092229395x529638551(heff_dup(v_z_245), heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileThen_24s1554913905x1093172886_lam2, 1, 8, (V[]){v_x_249, v_z_245, v_fuel_240, v_file_243, v_name_241, v_outPath_242, v_done_244, v_z_246})));
}
V g_heff_2ebuild_2ecommands_2ecompileThen_24s1554913905x1093172886_lam0(V self, V *args) {
  V v_x_248 = args[0];
  V v_file_243 = heff_env(self)[0];
  V v_z_245 = heff_env(self)[1];
  V v_fuel_240 = heff_env(self)[2];
  V v_name_241 = heff_env(self)[3];
  V v_outPath_242 = heff_env(self)[4];
  V v_done_244 = heff_env(self)[5];
  V v_z_246 = heff_env(self)[6];
  heff_clo_take(self, 7);
  return (g_heff_2ebuild_2eload_2eloadProgramWith_24s1839248718x121761575(v_x_248, heff_dup(v_file_243), heff_dup(v_z_245), heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileThen_24s1554913905x1093172886_lam1, 1, 7, (V[]){v_z_245, v_fuel_240, v_file_243, v_name_241, v_outPath_242, v_done_244, v_z_246})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecCmd_24s2011829969x1168825100_str0, 1, "/");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecCmd_24s2011829969x1168825100_str1, 8, "heff.zig");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecCmd_24s2011829969x1168825100_str2, 2, ".c");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecCmd_24s2011829969x1168825100_str3, 4, ".zig");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecCmd_24s2011829969x1168825100_str4, 1, "/");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecCmd_24s2011829969x1168825100_str5, 3, "*.c");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecCmd_24s2011829969x1168825100_str6, 6, "wrote ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecCmd_24s2011829969x1168825100_str7, 46, ": build it with `zig build-obj -O ReleaseFast ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecCmd_24s2011829969x1168825100_str8, 39, " -femit-bin=runtime.o` and `zig cc -O2 ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecCmd_24s2011829969x1168825100_str9, 46, " runtime.o -o PROGRAM -lm`, with the flags in ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecCmd_24s2011829969x1168825100_str10, 32, " where its modules' C needs more");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecCmd_24s2011829969x1168825100_str11, 1, "\012");
V g_heff_2ebuild_2ecommands_2ecCmd_24s2011829969x1168825100_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecCmd_24s2011829969x1168825100_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecCmd_24s2011829969x1168825100_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ecCmd_24s2011829969x1168825100_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecCmd_24s2011829969x1168825100_entry, 6, 0};

V g_heff_2ebuild_2ecommands_2ecCmd_24s2011829969x1168825100(V v_fuel_240, V v_name_241, V v_outPath_242, V v_file_243, V v_z_244, V v_z_245) {
top: ;
  V v_outPath_246 = heff_dup(v_outPath_242);
  int64_t v_t_247 = (heff_unbox_word(heff_strLength_lent(v_outPath_246, 0)) - ((int64_t)1ULL));
  V v_t_248 = heff_strSlice_lent(v_outPath_246, heff_box_word(v_t_247), heff_strLength_lent(v_outPath_246, 0), 6);
  V v_t_2413;
  if (heff_strEq_c(v_t_248, ((V)&g_heff_2ebuild_2ecommands_2ecCmd_24s2011829969x1168825100_str0))) {
    v_t_2413 = heff_strAppend(v_outPath_246, ((V)&g_heff_2ebuild_2ecommands_2ecCmd_24s2011829969x1168825100_str1));
  } else {
    int64_t v_t_249 = (heff_unbox_word(heff_strLength_lent(v_outPath_246, 0)) - ((int64_t)2ULL));
    V v_t_2410 = heff_strSlice_lent(v_outPath_246, heff_box_word(v_t_249), heff_strLength_lent(v_outPath_246, 0), 6);
    V v_t_2412;
    if (heff_strEq_c(v_t_2410, ((V)&g_heff_2ebuild_2ecommands_2ecCmd_24s2011829969x1168825100_str2))) {
      int64_t v_t_2411 = (heff_unbox_word(heff_strLength_lent(v_outPath_246, 0)) - ((int64_t)2ULL));
      v_t_2412 = heff_strSlice(v_outPath_246, MK_INT(0LL), heff_box_word(v_t_2411));
    } else {
      v_t_2412 = v_outPath_246;
    }
    v_t_2413 = heff_strAppend(v_t_2412, ((V)&g_heff_2ebuild_2ecommands_2ecCmd_24s2011829969x1168825100_str3));
  }
  int64_t v_t_2414 = (heff_unbox_word(heff_strLength_lent(v_outPath_242, 0)) - ((int64_t)1ULL));
  V v_t_2415 = heff_strSlice_lent(v_outPath_242, heff_box_word(v_t_2414), heff_strLength_lent(v_outPath_242, 0), 6);
  V v_t_2416;
  if (heff_strEq_c(v_t_2415, ((V)&g_heff_2ebuild_2ecommands_2ecCmd_24s2011829969x1168825100_str4))) {
    v_t_2416 = heff_strAppend(heff_dup(v_outPath_242), ((V)&g_heff_2ebuild_2ecommands_2ecCmd_24s2011829969x1168825100_str5));
  } else {
    v_t_2416 = heff_dup(v_outPath_242);
  }
  V v_t_2417 = (g_heff_2ebuild_2ecommands_2elinkOf(heff_dup(v_outPath_242)));
  V v_t_2418 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ecCmd_24s2011829969x1168825100_str6), heff_dup(v_outPath_242)), ((V)&g_heff_2ebuild_2ecommands_2ecCmd_24s2011829969x1168825100_str7));
  V v_t_2419 = heff_strAppend(heff_strAppend(v_t_2418, v_t_2413), ((V)&g_heff_2ebuild_2ecommands_2ecCmd_24s2011829969x1168825100_str8));
  V v_t_2420 = heff_strAppend(heff_strAppend(v_t_2419, v_t_2416), ((V)&g_heff_2ebuild_2ecommands_2ecCmd_24s2011829969x1168825100_str9));
  V v_str_2421 = heff_strAppend(heff_strAppend(v_t_2420, v_t_2417), ((V)&g_heff_2ebuild_2ecommands_2ecCmd_24s2011829969x1168825100_str10));
  V v_c_2422 = ((V)&g_heff_2ebuild_2ecommands_2ehostNow_24s621918226x590971294_clo);
  return heff_tail(v_c_2422, 2, (V[]){heff_dup(v_z_244), heff_clo_n(g_heff_2ebuild_2ecommands_2ecCmd_24s2011829969x1168825100_lam0, 1, 7, (V[]){v_file_243, v_z_244, v_str_2421, v_fuel_240, v_name_241, v_outPath_242, v_z_245})});
}
V g_heff_2ebuild_2ecommands_2ecCmd_24s2011829969x1168825100_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ecCmd_24s2011829969x1168825100(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2ebuild_2ecommands_2ecCmd_24s2011829969x1168825100_lam2(V self, V *args) {
  V v_x_2425 = args[0];
  V v_x_2424 = heff_env(self)[0];
  V v_str_2421 = heff_env(self)[1];
  V v_fuel_240 = heff_env(self)[2];
  V v_name_241 = heff_env(self)[3];
  V v_outPath_242 = heff_env(self)[4];
  V v_file_243 = heff_env(self)[5];
  V v_z_244 = heff_env(self)[6];
  V v_z_245 = heff_env(self)[7];
  V v_t_2426 = (g_heff_2ebuild_2ecommands_2eheffErrors(v_x_2425, heff_dup(heff_rfield(v_x_2424, 4))));
  heff_clo_take(self, 8);
  V v_x_2427 = (g_list_2efoldl_24s571074576x1179600767(v_x_2424, v_t_2426));
  V v_t_2428 = heff_tag_n(TAG_Write, 2, (V[]){heff_strAppend(v_str_2421, ((V)&g_heff_2ebuild_2ecommands_2ecCmd_24s2011829969x1168825100_str11)), NTAG(TAG_MkUnit)});
  V v_t_2429 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
  V v_t_2430 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2429})});
  V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2430})});
  V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
  V v_t_2433 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2432})});
  V v_t_2434 = heff_tr(heff_call(((V)&g_co_2eop_24s297957795x1045074450_clo), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2433})}));
  return (g_heff_2ebuild_2ecommands_2ecLoadedOr_24s1236085063x444027205(MK_INT(1LL), v_fuel_240, v_x_2427, v_name_241, v_outPath_242, v_file_243, v_t_2434, v_z_244, v_z_245));
}
V g_heff_2ebuild_2ecommands_2ecCmd_24s2011829969x1168825100_lam1(V self, V *args) {
  V v_x_2424 = args[0];
  V v_z_244 = heff_env(self)[0];
  V v_str_2421 = heff_env(self)[1];
  V v_fuel_240 = heff_env(self)[2];
  V v_name_241 = heff_env(self)[3];
  V v_outPath_242 = heff_env(self)[4];
  V v_file_243 = heff_env(self)[5];
  V v_z_245 = heff_env(self)[6];
  heff_clo_take(self, 7);
  return (g_heff_2ebuild_2ecommands_2eownVersion_24s2092229395x529638551(heff_dup(v_z_244), heff_clo_n(g_heff_2ebuild_2ecommands_2ecCmd_24s2011829969x1168825100_lam2, 1, 8, (V[]){v_x_2424, v_str_2421, v_fuel_240, v_name_241, v_outPath_242, v_file_243, v_z_244, v_z_245})));
}
V g_heff_2ebuild_2ecommands_2ecCmd_24s2011829969x1168825100_lam0(V self, V *args) {
  V v_x_2423 = args[0];
  V v_file_243 = heff_env(self)[0];
  V v_z_244 = heff_env(self)[1];
  V v_str_2421 = heff_env(self)[2];
  V v_fuel_240 = heff_env(self)[3];
  V v_name_241 = heff_env(self)[4];
  V v_outPath_242 = heff_env(self)[5];
  V v_z_245 = heff_env(self)[6];
  heff_clo_take(self, 7);
  return (g_heff_2ebuild_2eload_2eloadProgramWith_24s1839248718x121761575(v_x_2423, heff_dup(v_file_243), heff_dup(v_z_244), heff_clo_n(g_heff_2ebuild_2ecommands_2ecCmd_24s2011829969x1168825100_lam1, 1, 7, (V[]){v_z_244, v_str_2421, v_fuel_240, v_name_241, v_outPath_242, v_file_243, v_z_245})));
}
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s2064791442x239876729_lam0(V self, V *args);
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s2064791442x239876729_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ehfFilesGo_24s2064791442x239876729_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ehfFilesGo_24s2064791442x239876729_lam1, 1, 0};
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s2064791442x239876729_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s2064791442x239876729_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s2064791442x239876729_lam2(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ehfFilesGo_24s2064791442x239876729_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ehfFilesGo_24s2064791442x239876729_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s2064791442x239876729(V v_x1_240, V v_acc_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    V v_x_242 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_acc_241));
    return heff_clo_n(g_heff_2ebuild_2ecommands_2ehfFilesGo_24s2064791442x239876729_lam0, 2, 1, (V[]){v_x_242});
  }
  case TAG_Cons: {
    V v_p_245 = heff_field(v_x1_240, 0);
    V v_rest_246 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_path_247 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), heff_dup(v_p_245)));
    V v_t_248 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_247; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); r_; });
    V v_a_2410 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_ReadDirectory, 2, (V[]){v_t_248, ((V)&g_heff_2ebuild_2ecommands_2ehfFilesGo_24s2064791442x239876729_lam1_clo)});
    return heff_clo_n(g_heff_2ebuild_2ecommands_2ehfFilesGo_24s2064791442x239876729_lam2, 2, 5, (V[]){v_a_2410, v_p_245, v_rest_246, v_acc_241, v_path_247});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s2064791442x239876729_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ehfFilesGo_24s2064791442x239876729(a[0], a[1]);
}
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s2064791442x239876729_lam0(V self, V *args) {
  V v_hd_243 = args[0];
  V v_k_244 = args[1];
  V v_x_242 = heff_env(self)[0];
  heff_drop(v_hd_243);
  heff_clo_take(self, 1);
  V f_ = v_k_244;
  args[0] = v_x_242;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s2064791442x239876729_lam1(V self, V *args) {
  V v_r_249 = args[0];
  return v_r_249;
}
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s2064791442x239876729_lam4(V self, V *args) {
  V v_n_2423 = args[0];
  V v_path_247 = heff_env(self)[0];
  V v_t_2424 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_n_2423));
  heff_clo_take(self, 1);
  return (g_std_2epath_2ejoin(v_path_247, v_t_2424));
}
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s2064791442x239876729_lam3(V self, V *args) {
  V v_x_2418 = args[0];
  V v_p_245 = heff_env(self)[0];
  V v_rest_246 = heff_env(self)[1];
  V v_acc_241 = heff_env(self)[2];
  V v_hd_2411 = heff_env(self)[3];
  V v_k_2412 = heff_env(self)[4];
  V v_path_247 = heff_env(self)[5];
  switch (heff_tag_of(v_x_2418)) {
  case TAG_Left: {
    V v_x_2419 = heff_field(v_x_2418, 0);
    V v_ru_24x_2418_24Left = heff_take_reuse_n(v_x_2418, 1ULL, 1);
    heff_clo_take(self, 6);
    heff_drop(v_path_247);
    return (g_heff_2ebuild_2ecommands_2ehfFilesGo_24s2064791442x239876729_2ek_24l0(v_p_245, v_rest_246, v_acc_241, v_hd_2411, v_k_2412, heff_tag_re_n(v_ru_24x_2418_24Left, TAG_Left, 1, 1ULL, (V[]){v_x_2419})));
  }
  case TAG_Right: {
    V v_y_2420 = heff_field(v_x_2418, 0);
    V v_ru_24x_2418_24Right = heff_take_reuse_n(v_x_2418, 1ULL, 1);
    switch (heff_tag_of(v_y_2420)) {
    case TAG_Left: {
      V v_err_2421 = heff_field(v_y_2420, 0);
      V v_ru_24y_2420_24Left = heff_take_reuse_n(v_y_2420, 1ULL, 1);
      heff_clo_take(self, 6);
      heff_drop(v_path_247);
      heff_drop_cell(v_ru_24x_2418_24Right, 1);
      return (g_heff_2ebuild_2ecommands_2ehfFilesGo_24s2064791442x239876729_2ek_24l0(v_p_245, v_rest_246, v_acc_241, v_hd_2411, v_k_2412, heff_tag_re_n(v_ru_24y_2420_24Left, TAG_Left, 1, 1ULL, (V[]){v_err_2421})));
    }
    case TAG_Right: {
      V v_x_2422 = heff_field(v_y_2420, 0);
      heff_take_n(v_y_2420, 1ULL, 1);
      heff_clo_take(self, 6);
      V v_x_2425 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2ecommands_2ehfFilesGo_24s2064791442x239876729_lam4, 1, 1, (V[]){v_path_247}), v_x_2422));
      V v_x_2426 = (g_list_2emap_24s219049803x1458391381(v_x_2425));
      return (g_heff_2ebuild_2ecommands_2ehfFilesGo_24s2064791442x239876729_2ek_24l0(v_p_245, v_rest_246, v_acc_241, v_hd_2411, v_k_2412, heff_tag_at_n(v_ru_24x_2418_24Right, TAG_Right, 1, (V[]){v_x_2426})));
    }
    default: return heff_nomatch(v_y_2420);
    }
  }
  default: return heff_nomatch(v_x_2418);
  }
}
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s2064791442x239876729_lam2(V self, V *args) {
  V v_hd_2411 = args[0];
  V v_k_2412 = args[1];
  V v_a_2410 = heff_env(self)[0];
  V v_p_245 = heff_env(self)[1];
  V v_rest_246 = heff_env(self)[2];
  V v_acc_241 = heff_env(self)[3];
  V v_path_247 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2410})});
  V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
  V v_t_2415 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
  V v_t_2416 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2416})});
  return (g_co_2eop_24s1896221640x2141527803(v_t_2417, heff_dup(v_hd_2411), heff_clo_n(g_heff_2ebuild_2ecommands_2ehfFilesGo_24s2064791442x239876729_lam3, 1, 6, (V[]){v_p_245, v_rest_246, v_acc_241, v_hd_2411, v_k_2412, v_path_247})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eappShips_24s230600905x194600621_str0, 8, "build.hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eappShips_24s230600905x194600621_str1, 1, "`");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eappShips_24s230600905x194600621_str2, 1, "`");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eappShips_24s230600905x194600621_str3, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eappShips_24s230600905x194600621_str4, 2, ", ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eappShips_24s230600905x194600621_str5, 11, ": it ships ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eappShips_24s230600905x194600621_str6, 33, ", which the project does not have");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eappShips_24s230600905x194600621_str7, 1, "\012");
V g_heff_2ebuild_2ecommands_2eappShips_24s230600905x194600621_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eappShips_24s230600905x194600621_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eappShips_24s230600905x194600621_entry, 8, 0};

V g_heff_2ebuild_2ecommands_2eappShips_24s230600905x194600621(V v_st_240, V v_t_241, V v_acc_242, V v_x_243, V v_a_244, V v_missing_245, V v_z_246, V v_z_247) {
top: ;
  switch (heff_tag_of(v_missing_245)) {
  case TAG_Nil: {
    heff_drop(v_st_240);
    heff_drop(v_t_241);
    heff_drop(v_z_246);
    V v_t_248 = heff_tag_n(TAG_Cons, 2, (V[]){heff_rec_n(2, shape_name__build, (V[]){v_x_243, v_a_244}), heff_take_field(v_acc_242, 0)});
    V v_t_249 = ({ V rv_0 = v_t_248; V rr_ = heff_rec_reuse_nf(v_acc_242, 2ULL, 2, shape_apps__bad, 12u, 0u); heff_rfield(rr_, 0) = rv_0; rr_; });
    return heff_tail(v_z_247, 1, (V[]){v_t_249});
  }
  case TAG_Cons: {
    heff_drop(v_a_244);
    V v_t_2412 = (g_heff_2ebuild_2ecommands_2eappFile(v_st_240, v_t_241, v_x_243, ((V)&g_heff_2ebuild_2ecommands_2eappShips_24s230600905x194600621_str0)));
    V v_x2_2413 = (g_list_2emap_24s1325317589x1506218481(((V)&g_heff_2ebuild_2ecommands_2eappShips_24s230600905x194600621_str1), ((V)&g_heff_2ebuild_2ecommands_2eappShips_24s230600905x194600621_str2), v_missing_245));
    V v_t_2416;
    switch (heff_tag_of(v_x2_2413)) {
    case TAG_Nil: {
      v_t_2416 = ((V)&g_heff_2ebuild_2ecommands_2eappShips_24s230600905x194600621_str3);
      break;
    }
    case TAG_Cons: {
      V v_x_2414 = heff_field(v_x2_2413, 0);
      V v_xs_2415 = heff_field(v_x2_2413, 1);
      heff_take_n(v_x2_2413, 3ULL, 2);
      v_t_2416 = ({ V a_0 = ((V)&g_heff_2ebuild_2ecommands_2eappShips_24s230600905x194600621_str4); V a_1 = v_x_2414; V a_2 = v_xs_2415; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2415); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2413);
    }
    V v_t_2417 = heff_strAppend(heff_strAppend(v_t_2412, ((V)&g_heff_2ebuild_2ecommands_2eappShips_24s230600905x194600621_str5)), v_t_2416);
    V v_str_2418 = heff_strAppend(v_t_2417, ((V)&g_heff_2ebuild_2ecommands_2eappShips_24s230600905x194600621_str6));
    V v_t_2419 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_str_2418, ((V)&g_heff_2ebuild_2ecommands_2eappShips_24s230600905x194600621_str7)), NTAG(TAG_MkUnit)});
    V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
    V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
    V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
    V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
    V v_t_2424 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2423})});
    return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2424}), v_z_246, heff_clo_n(g_heff_2ebuild_2ecommands_2eappShips_24s230600905x194600621_lam0, 1, 2, (V[]){v_acc_242, v_z_247})));
  }
  default: return heff_nomatch(v_missing_245);
  }
}
V g_heff_2ebuild_2ecommands_2eappShips_24s230600905x194600621_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eappShips_24s230600905x194600621(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
}
V g_heff_2ebuild_2ecommands_2eappShips_24s230600905x194600621_lam0(V self, V *args) {
  V v_x_2425 = args[0];
  V v_acc_242 = heff_env(self)[0];
  V v_z_247 = heff_env(self)[1];
  heff_drop(v_x_2425);
  heff_clo_take(self, 2);
  V v_t_2426 = heff_intAdd(heff_take_field(v_acc_242, 1), MK_INT(1LL));
  V v_t_2427 = ({ V rv_1 = v_t_2426; V rr_ = heff_rec_reuse_nf(v_acc_242, 1ULL, 2, shape_apps__bad, 3u, 0u); heff_rfield(rr_, 1) = rv_1; rr_; });
  V f_ = v_z_247;
  args[0] = v_t_2427;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eshipMoved_24s1077118630x1295426809_str0, 1, " ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eshipMoved_24s1077118630x1295426809_str1, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eshipMoved_24s1077118630x1295426809_str2, 1, " ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eshipMoved_24s1077118630x1295426809_str3, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eshipMoved_24s1077118630x1295426809_str4, 1, " ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eshipMoved_24s1077118630x1295426809_str5, 1, "\012");
V g_heff_2ebuild_2ecommands_2eshipMoved_24s1077118630x1295426809_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eshipMoved_24s1077118630x1295426809_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eshipMoved_24s1077118630x1295426809_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2eshipMoved_24s1077118630x1295426809_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2eshipMoved_24s1077118630x1295426809_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2eshipMoved_24s1077118630x1295426809_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2eshipMoved_24s1077118630x1295426809_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2eshipMoved_24s1077118630x1295426809_lam5(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eshipMoved_24s1077118630x1295426809_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eshipMoved_24s1077118630x1295426809_lam5, 1, 0};
V g_heff_2ebuild_2ecommands_2eshipMoved_24s1077118630x1295426809_lam6(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eshipMoved_24s1077118630x1295426809_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eshipMoved_24s1077118630x1295426809_entry, 8, 0};

V g_heff_2ebuild_2ecommands_2eshipMoved_24s1077118630x1295426809(V v_t_240, V v_fresh_241, V v_old_242, V v_to_243, V v_next_244, V v_x6_245, V v_z_246, V v_z_247) {
top: ;
  if ((heff_dup(v_x6_245) == NTAG(TAG_True))) {
    heff_drop(v_fresh_241);
    V v_path_248 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_old_242));
    V v_t_249 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_248; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_248); r_; });
    V v_a_2411 = heff_tag_n(TAG_Remove, 2, (V[]){v_t_249, ((V)&g_heff_2ebuild_2ecommands_2eshipMoved_24s1077118630x1295426809_lam0_clo)});
    V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2411})});
    V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
    V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
    V v_t_2415 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
    V v_t_2416 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2415})});
    return (g_co_2eop_24s1896221640x2141527803(v_t_2416, heff_dup(v_z_246), heff_clo_n(g_heff_2ebuild_2ecommands_2eshipMoved_24s1077118630x1295426809_lam1, 1, 5, (V[]){v_t_240, v_to_243, v_z_246, v_next_244, v_z_247})));
  } else {
    heff_drop_rec(v_t_240, 6);
    heff_drop(v_next_244);
    V v_path_2449 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_old_242));
    V v_to_2450 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), heff_dup(v_to_243)));
    V v_t_2451 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2449; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_2449); r_; });
    V v_t_2452 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_to_2450; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_to_2450); r_; });
    V v_a_2454 = heff_tag_n(TAG_Move, 3, (V[]){v_t_2451, v_t_2452, ((V)&g_heff_2ebuild_2ecommands_2eshipMoved_24s1077118630x1295426809_lam5_clo)});
    V v_t_2455 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2454})});
    V v_t_2456 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2455})});
    V v_t_2457 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2456})});
    V v_t_2458 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2457})});
    V v_t_2459 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2458})});
    return (g_co_2eop_24s1896221640x2141527803(v_t_2459, heff_dup(v_z_246), heff_clo_n(g_heff_2ebuild_2ecommands_2eshipMoved_24s1077118630x1295426809_lam6, 1, 4, (V[]){v_fresh_241, v_z_246, v_to_243, v_z_247})));
  }
}
V g_heff_2ebuild_2ecommands_2eshipMoved_24s1077118630x1295426809_entry(V self, V *a) {
  (void)self;
  V a5 = a[5]; V r = g_heff_2ebuild_2ecommands_2eshipMoved_24s1077118630x1295426809(a[0], a[1], a[2], a[3], a[4], a5, a[6], a[7]); heff_drop(a5); return r;
}
V g_heff_2ebuild_2ecommands_2eshipMoved_24s1077118630x1295426809_lam0(V self, V *args) {
  V v_r_2410 = args[0];
  return v_r_2410;
}
V g_heff_2ebuild_2ecommands_2eshipMoved_24s1077118630x1295426809_lam2(V self, V *args) {
  V v_x_2427 = args[0];
  V v_next_244 = heff_env(self)[0];
  V v_z_246 = heff_env(self)[1];
  V v_z_247 = heff_env(self)[2];
  heff_drop(v_x_2427);
  heff_clo_take(self, 3);
  V f_ = v_next_244;
  heff_room[0] = v_z_246;
  heff_room[1] = v_z_247;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2eshipMoved_24s1077118630x1295426809_lam3(V self, V *args) {
  V v_x_2438 = args[0];
  V v_next_244 = heff_env(self)[0];
  V v_z_246 = heff_env(self)[1];
  V v_z_247 = heff_env(self)[2];
  heff_drop(v_x_2438);
  heff_clo_take(self, 3);
  V f_ = v_next_244;
  heff_room[0] = v_z_246;
  heff_room[1] = v_z_247;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2eshipMoved_24s1077118630x1295426809_lam4(V self, V *args) {
  V v_x_2448 = args[0];
  V v_next_244 = heff_env(self)[0];
  V v_z_246 = heff_env(self)[1];
  V v_z_247 = heff_env(self)[2];
  heff_drop(v_x_2448);
  heff_clo_take(self, 3);
  V f_ = v_next_244;
  heff_room[0] = v_z_246;
  heff_room[1] = v_z_247;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2eshipMoved_24s1077118630x1295426809_lam1(V self, V *args) {
  V v_x_2417 = args[0];
  V v_t_240 = heff_env(self)[0];
  V v_to_243 = heff_env(self)[1];
  V v_z_246 = heff_env(self)[2];
  V v_next_244 = heff_env(self)[3];
  V v_z_247 = heff_env(self)[4];
  switch (heff_tag_of(v_x_2417)) {
  case TAG_Left: {
    V v_ru_24x_2417_24Left = heff_take_reuse_n(v_x_2417, 0ULL, 1);
    heff_clo_take(self, 5);
    V v_t_2419 = heff_strAppend(heff_get_n(v_t_240, 2, 6), ((V)&g_heff_2ebuild_2ecommands_2eshipMoved_24s1077118630x1295426809_str0));
    V v_t_2420 = heff_strAppend(heff_strAppend(v_t_2419, v_to_243), ((V)&g_heff_2ebuild_2ecommands_2eshipMoved_24s1077118630x1295426809_str1));
    V v_t_2421 = heff_tag_n(TAG_Write, 2, (V[]){v_t_2420, NTAG(TAG_MkUnit)});
    V v_t_2422 = heff_tag_at_n(v_ru_24x_2417_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
    V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
    V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
    V v_t_2425 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
    V v_t_2426 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2425})});
    return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2426}), heff_dup(v_z_246), heff_clo_n(g_heff_2ebuild_2ecommands_2eshipMoved_24s1077118630x1295426809_lam2, 1, 3, (V[]){v_next_244, v_z_246, v_z_247})));
  }
  case TAG_Right: {
    V v_y_2428 = heff_field(v_x_2417, 0);
    V v_ru_24x_2417_24Right = heff_take_reuse_n(v_x_2417, 1ULL, 1);
    switch (heff_tag_of(v_y_2428)) {
    case TAG_Left: {
      V v_ru_24y_2428_24Left = heff_take_reuse_n(v_y_2428, 0ULL, 1);
      heff_clo_take(self, 5);
      V v_t_2430 = heff_strAppend(heff_get_n(v_t_240, 2, 6), ((V)&g_heff_2ebuild_2ecommands_2eshipMoved_24s1077118630x1295426809_str2));
      V v_t_2431 = heff_strAppend(heff_strAppend(v_t_2430, v_to_243), ((V)&g_heff_2ebuild_2ecommands_2eshipMoved_24s1077118630x1295426809_str3));
      V v_t_2432 = heff_tag_n(TAG_Write, 2, (V[]){v_t_2431, NTAG(TAG_MkUnit)});
      V v_t_2433 = heff_tag_at_n(v_ru_24x_2417_24Right, TAG_InL, 1, (V[]){heff_tag_at_n(v_ru_24y_2428_24Left, TAG_InL, 1, (V[]){v_t_2432})});
      V v_t_2434 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2433})});
      V v_t_2435 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2434})});
      V v_t_2436 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2435})});
      V v_t_2437 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2436})});
      return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2437}), heff_dup(v_z_246), heff_clo_n(g_heff_2ebuild_2ecommands_2eshipMoved_24s1077118630x1295426809_lam3, 1, 3, (V[]){v_next_244, v_z_246, v_z_247})));
    }
    case TAG_Right: {
      V v_ru_24y_2428_24Right = heff_take_reuse_n(v_y_2428, 0ULL, 1);
      heff_clo_take(self, 5);
      V v_t_2440 = heff_strAppend(heff_get_n(v_t_240, 2, 6), ((V)&g_heff_2ebuild_2ecommands_2eshipMoved_24s1077118630x1295426809_str4));
      V v_t_2441 = heff_strAppend(heff_strAppend(v_t_2440, v_to_243), ((V)&g_heff_2ebuild_2ecommands_2eshipMoved_24s1077118630x1295426809_str5));
      V v_t_2442 = heff_tag_n(TAG_Write, 2, (V[]){v_t_2441, NTAG(TAG_MkUnit)});
      V v_t_2443 = heff_tag_at_n(v_ru_24x_2417_24Right, TAG_InL, 1, (V[]){heff_tag_at_n(v_ru_24y_2428_24Right, TAG_InL, 1, (V[]){v_t_2442})});
      V v_t_2444 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2443})});
      V v_t_2445 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2444})});
      V v_t_2446 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2445})});
      V v_t_2447 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2446})});
      return (g_co_2eop_24s535099379x685970669(heff_tag_n(TAG_InR, 1, (V[]){v_t_2447}), heff_dup(v_z_246), heff_clo_n(g_heff_2ebuild_2ecommands_2eshipMoved_24s1077118630x1295426809_lam4, 1, 3, (V[]){v_next_244, v_z_246, v_z_247})));
    }
    default: return heff_nomatch(v_y_2428);
    }
  }
  default: return heff_nomatch(v_x_2417);
  }
}
V g_heff_2ebuild_2ecommands_2eshipMoved_24s1077118630x1295426809_lam5(V self, V *args) {
  V v_r_2453 = args[0];
  return v_r_2453;
}
V g_heff_2ebuild_2ecommands_2eshipMoved_24s1077118630x1295426809_lam6(V self, V *args) {
  V v_x_2460 = args[0];
  V v_fresh_241 = heff_env(self)[0];
  V v_z_246 = heff_env(self)[1];
  V v_to_243 = heff_env(self)[2];
  V v_z_247 = heff_env(self)[3];
  switch (heff_tag_of(v_x_2460)) {
  case TAG_Left: {
    V v_x_2461 = heff_field(v_x_2460, 0);
    V v_ru_24x_2460_24Left = heff_take_reuse_n(v_x_2460, 1ULL, 1);
    heff_clo_take(self, 4);
    return ({ V a_0 = v_fresh_241; V a_1 = v_z_246; V a_2 = v_to_243; V a_3 = v_z_247; V b_4 = heff_tag_re_n(v_ru_24x_2460_24Left, TAG_Left, 1, 1ULL, (V[]){v_x_2461}); V r_ = (g_heff_2ebuild_2ecommands_2eshipMoved_24s1077118630x1295426809_2ek_24l0(a_0, a_1, a_2, a_3, b_4)); heff_drop(b_4); r_; });
  }
  case TAG_Right: {
    V v_y_2462 = heff_field(v_x_2460, 0);
    V v_ru_24x_2460_24Right = heff_take_reuse_n(v_x_2460, 1ULL, 1);
    switch (heff_tag_of(v_y_2462)) {
    case TAG_Left: {
      V v_err_2463 = heff_field(v_y_2462, 0);
      V v_ru_24y_2462_24Left = heff_take_reuse_n(v_y_2462, 1ULL, 1);
      heff_drop_cell(v_ru_24x_2460_24Right, 1);
      heff_clo_take(self, 4);
      return ({ V a_0 = v_fresh_241; V a_1 = v_z_246; V a_2 = v_to_243; V a_3 = v_z_247; V b_4 = heff_tag_re_n(v_ru_24y_2462_24Left, TAG_Left, 1, 1ULL, (V[]){v_err_2463}); V r_ = (g_heff_2ebuild_2ecommands_2eshipMoved_24s1077118630x1295426809_2ek_24l0(a_0, a_1, a_2, a_3, b_4)); heff_drop(b_4); r_; });
    }
    case TAG_Right: {
      V v_x_2464 = heff_field(v_y_2462, 0);
      heff_take_n(v_y_2462, 1ULL, 1);
      heff_clo_take(self, 4);
      return ({ V a_0 = v_fresh_241; V a_1 = v_z_246; V a_2 = v_to_243; V a_3 = v_z_247; V b_4 = heff_tag_at_n(v_ru_24x_2460_24Right, TAG_Right, 1, (V[]){v_x_2464}); V r_ = (g_heff_2ebuild_2ecommands_2eshipMoved_24s1077118630x1295426809_2ek_24l0(a_0, a_1, a_2, a_3, b_4)); heff_drop(b_4); r_; });
    }
    default: return heff_nomatch(v_y_2462);
    }
  }
  default: return heff_nomatch(v_x_2460);
  }
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eshipOne_24s1526802457x609672645_str0, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eshipOne_24s1526802457x609672645_str1, 4, ".new");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eshipOne_24s1526802457x609672645_str2, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eshipOne_24s1526802457x609672645_str3, 4, ".old");
V g_heff_2ebuild_2ecommands_2eshipOne_24s1526802457x609672645_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eshipOne_24s1526802457x609672645_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eshipOne_24s1526802457x609672645_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2eshipOne_24s1526802457x609672645_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eshipOne_24s1526802457x609672645_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eshipOne_24s1526802457x609672645_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2eshipOne_24s1526802457x609672645_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2eshipOne_24s1526802457x609672645_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eshipOne_24s1526802457x609672645_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eshipOne_24s1526802457x609672645_entry, 8, 0};

V g_heff_2ebuild_2ecommands_2eshipOne_24s1526802457x609672645(V v_st_240, V v_t_241, V v_home_242, V v_sh_243, V v_next_244, V v_n_245, V v_hd_246, V v_k_247) {
top: ;
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){v_sh_243, heff_dup(v_n_245), MK_INT(0LL), ((V)&g_heff_2ebuild_2ecommands_2eshipOne_24s1526802457x609672645_lam0_clo)})});
  V v_t_2410 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_249})});
  return (g_co_2eop_24s535099379x685970669(v_t_2410, heff_dup(v_hd_246), heff_clo_n(g_heff_2ebuild_2ecommands_2eshipOne_24s1526802457x609672645_lam1, 1, 7, (V[]){v_st_240, v_home_242, v_n_245, v_hd_246, v_t_241, v_k_247, v_next_244})));
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s1526802457x609672645_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eshipOne_24s1526802457x609672645(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s1526802457x609672645_lam0(V self, V *args) {
  V v_t_248 = args[0];
  return v_t_248;
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s1526802457x609672645_lam2(V self, V *args) {
  V v_r_2424 = args[0];
  return v_r_2424;
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s1526802457x609672645_lam3(V self, V *args) {
  V v_x_2431 = args[0];
  V v_x_2421 = heff_env(self)[0];
  V v_hd_246 = heff_env(self)[1];
  V v_st_240 = heff_env(self)[2];
  V v_t_241 = heff_env(self)[3];
  V v_n_245 = heff_env(self)[4];
  V v_x_2416 = heff_env(self)[5];
  V v_k_247 = heff_env(self)[6];
  V v_home_242 = heff_env(self)[7];
  V v_x_2411 = heff_env(self)[8];
  V v_next_244 = heff_env(self)[9];
  switch (heff_tag_of(v_x_2431)) {
  case TAG_Left: {
    V v_x_2432 = heff_field(v_x_2431, 0);
    V v_ru_24x_2431_24Left = heff_take_reuse_n(v_x_2431, 1ULL, 1);
    heff_clo_take(self, 10);
    return ({ V a_0 = v_x_2421; V a_1 = v_hd_246; V a_2 = v_st_240; V a_3 = v_t_241; V a_4 = v_n_245; V a_5 = v_x_2416; V a_6 = v_k_247; V a_7 = v_home_242; V a_8 = v_x_2411; V a_9 = v_next_244; V b_10 = heff_tag_re_n(v_ru_24x_2431_24Left, TAG_Left, 1, 1ULL, (V[]){v_x_2432}); V r_ = (g_heff_2ebuild_2ecommands_2eshipOne_24s1526802457x609672645_2ek_24l4(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9, b_10)); heff_drop(b_10); r_; });
  }
  case TAG_Right: {
    V v_y_2433 = heff_field(v_x_2431, 0);
    V v_ru_24x_2431_24Right = heff_take_reuse_n(v_x_2431, 1ULL, 1);
    switch (heff_tag_of(v_y_2433)) {
    case TAG_Left: {
      V v_err_2434 = heff_field(v_y_2433, 0);
      V v_ru_24y_2433_24Left = heff_take_reuse_n(v_y_2433, 1ULL, 1);
      heff_drop_cell(v_ru_24x_2431_24Right, 1);
      heff_clo_take(self, 10);
      return ({ V a_0 = v_x_2421; V a_1 = v_hd_246; V a_2 = v_st_240; V a_3 = v_t_241; V a_4 = v_n_245; V a_5 = v_x_2416; V a_6 = v_k_247; V a_7 = v_home_242; V a_8 = v_x_2411; V a_9 = v_next_244; V b_10 = heff_tag_re_n(v_ru_24y_2433_24Left, TAG_Left, 1, 1ULL, (V[]){v_err_2434}); V r_ = (g_heff_2ebuild_2ecommands_2eshipOne_24s1526802457x609672645_2ek_24l4(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9, b_10)); heff_drop(b_10); r_; });
    }
    case TAG_Right: {
      V v_x_2435 = heff_field(v_y_2433, 0);
      heff_take_n(v_y_2433, 1ULL, 1);
      heff_clo_take(self, 10);
      return ({ V a_0 = v_x_2421; V a_1 = v_hd_246; V a_2 = v_st_240; V a_3 = v_t_241; V a_4 = v_n_245; V a_5 = v_x_2416; V a_6 = v_k_247; V a_7 = v_home_242; V a_8 = v_x_2411; V a_9 = v_next_244; V b_10 = heff_tag_at_n(v_ru_24x_2431_24Right, TAG_Right, 1, (V[]){v_x_2435}); V r_ = (g_heff_2ebuild_2ecommands_2eshipOne_24s1526802457x609672645_2ek_24l4(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9, b_10)); heff_drop(b_10); r_; });
    }
    default: return heff_nomatch(v_y_2433);
    }
  }
  default: return heff_nomatch(v_x_2431);
  }
}
V g_heff_2ebuild_2ecommands_2eshipOne_24s1526802457x609672645_lam1(V self, V *args) {
  V v_x_2411 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_home_242 = heff_env(self)[1];
  V v_n_245 = heff_env(self)[2];
  V v_hd_246 = heff_env(self)[3];
  V v_t_241 = heff_env(self)[4];
  V v_k_247 = heff_env(self)[5];
  V v_next_244 = heff_env(self)[6];
  V v_t_2412 = (g_std_2epath_2eparse(heff_dup(v_st_240), heff_dup(v_home_242)));
  V v_t_2413 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eshipOne_24s1526802457x609672645_str0), heff_dup(v_n_245)), ((V)&g_heff_2ebuild_2ecommands_2eshipOne_24s1526802457x609672645_str1));
  V v_t_2414 = (g_std_2epath_2eparse(heff_dup(v_st_240), v_t_2413));
  V v_t_2415 = (g_std_2epath_2ejoin(v_t_2412, v_t_2414));
  V v_x_2416 = ({ V a_0 = v_st_240; V a_1 = v_t_2415; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2415); r_; });
  V v_t_2417 = (g_std_2epath_2eparse(heff_dup(v_st_240), heff_dup(v_home_242)));
  V v_t_2418 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eshipOne_24s1526802457x609672645_str2), heff_dup(v_n_245)), ((V)&g_heff_2ebuild_2ecommands_2eshipOne_24s1526802457x609672645_str3));
  V v_t_2419 = (g_std_2epath_2eparse(heff_dup(v_st_240), v_t_2418));
  V v_t_2420 = (g_std_2epath_2ejoin(v_t_2417, v_t_2419));
  V v_x_2421 = ({ V a_0 = v_st_240; V a_1 = v_t_2420; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_t_2420); r_; });
  V v_path_2422 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), heff_dup(v_x_2416)));
  V v_t_2423 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_2422; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_2422); r_; });
  V v_a_2425 = heff_tag_n(TAG_Remove, 2, (V[]){v_t_2423, ((V)&g_heff_2ebuild_2ecommands_2eshipOne_24s1526802457x609672645_lam2_clo)});
  V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2425})});
  V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
  V v_t_2428 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
  V v_t_2429 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2428})});
  V v_t_2430 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2429})});
  heff_clo_take(self, 7);
  return (g_co_2eop_24s1896221640x2141527803(v_t_2430, heff_dup(v_hd_246), heff_clo_n(g_heff_2ebuild_2ecommands_2eshipOne_24s1526802457x609672645_lam3, 1, 10, (V[]){v_x_2421, v_hd_246, v_st_240, v_t_241, v_n_245, v_x_2416, v_k_247, v_home_242, v_x_2411, v_next_244})));
}
V g_heff_2ebuild_2ecommands_2ecompileJsOut_24s286675332x2033384300_24tok1_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ecompileJsOut_24s286675332x2033384300_24tok1_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecompileJsOut_24s286675332x2033384300_24tok1_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2ecompileJsOut_24s286675332x2033384300_24tok1_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ecompileJsOut_24s286675332x2033384300_24tok1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecompileJsOut_24s286675332x2033384300_24tok1_entry, 6, 0};

V g_heff_2ebuild_2ecommands_2ecompileJsOut_24s286675332x2033384300_24tok1(V v_tok_240, V v_outPath_241, V v_bad_242, V v_o_243, V v_z_244, V v_z_245) {
top: ;
  V v_path_246 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), heff_dup(v_outPath_241)));
  V v_t_247 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_246; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_246); r_; });
  V v_a_249 = heff_tag_n(TAG_WriteFile, 3, (V[]){v_t_247, heff_dup(heff_rfield(v_o_243, 0)), ((V)&g_heff_2ebuild_2ecommands_2ecompileJsOut_24s286675332x2033384300_24tok1_lam0_clo)});
  V v_t_2410 = heff_tag_at_n(v_tok_240, TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_249})});
  V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
  V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
  V v_t_2414 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2413})});
  return (g_co_2eop_24s1896221640x2141527803(v_t_2414, heff_dup(v_z_244), heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileJsOut_24s286675332x2033384300_24tok1_lam1, 1, 5, (V[]){v_o_243, v_z_244, v_outPath_241, v_z_245, heff_dup(v_bad_242)})));
}
V g_heff_2ebuild_2ecommands_2ecompileJsOut_24s286675332x2033384300_24tok1_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ebuild_2ecommands_2ecompileJsOut_24s286675332x2033384300_24tok1(a[0], a[1], a2, a[3], a[4], a[5]); heff_drop(a2); return r;
}
V g_heff_2ebuild_2ecommands_2ecompileJsOut_24s286675332x2033384300_24tok1_lam0(V self, V *args) {
  V v_r_248 = args[0];
  return v_r_248;
}
V g_heff_2ebuild_2ecommands_2ecompileJsOut_24s286675332x2033384300_24tok1_lam1(V self, V *args) {
  V v_x_2415 = args[0];
  V v_o_243 = heff_env(self)[0];
  V v_z_244 = heff_env(self)[1];
  V v_outPath_241 = heff_env(self)[2];
  V v_z_245 = heff_env(self)[3];
  V v_bad_242 = heff_env(self)[4];
  switch (heff_tag_of(v_x_2415)) {
  case TAG_Left: {
    V v_x_2416 = heff_field(v_x_2415, 0);
    V v_ru_24x_2415_24Left = heff_take_reuse_n(v_x_2415, 1ULL, 1);
    heff_clo_take(self, 5);
    return ({ V a_0 = v_o_243; V a_1 = v_z_244; V a_2 = v_outPath_241; V a_3 = v_z_245; V a_4 = v_bad_242; V a_5 = heff_tag_re_n(v_ru_24x_2415_24Left, TAG_Left, 1, 1ULL, (V[]){v_x_2416}); V r_ = (g_heff_2ebuild_2ecommands_2ecompileJsOut_24s286675332x2033384300_2ek_24l0(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_bad_242); r_; });
  }
  case TAG_Right: {
    V v_y_2417 = heff_field(v_x_2415, 0);
    V v_ru_24x_2415_24Right = heff_take_reuse_n(v_x_2415, 1ULL, 1);
    switch (heff_tag_of(v_y_2417)) {
    case TAG_Left: {
      V v_err_2418 = heff_field(v_y_2417, 0);
      V v_ru_24y_2417_24Left = heff_take_reuse_n(v_y_2417, 1ULL, 1);
      heff_drop_cell(v_ru_24x_2415_24Right, 1);
      heff_clo_take(self, 5);
      return ({ V a_0 = v_o_243; V a_1 = v_z_244; V a_2 = v_outPath_241; V a_3 = v_z_245; V a_4 = v_bad_242; V a_5 = heff_tag_re_n(v_ru_24y_2417_24Left, TAG_Left, 1, 1ULL, (V[]){v_err_2418}); V r_ = (g_heff_2ebuild_2ecommands_2ecompileJsOut_24s286675332x2033384300_2ek_24l0(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_bad_242); r_; });
    }
    case TAG_Right: {
      V v_x_2419 = heff_field(v_y_2417, 0);
      heff_take_n(v_y_2417, 1ULL, 1);
      heff_clo_take(self, 5);
      return ({ V a_0 = v_o_243; V a_1 = v_z_244; V a_2 = v_outPath_241; V a_3 = v_z_245; V a_4 = v_bad_242; V a_5 = heff_tag_at_n(v_ru_24x_2415_24Right, TAG_Right, 1, (V[]){v_x_2419}); V r_ = (g_heff_2ebuild_2ecommands_2ecompileJsOut_24s286675332x2033384300_2ek_24l0(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_bad_242); r_; });
    }
    default: return heff_nomatch(v_y_2417);
    }
  }
  default: return heff_nomatch(v_x_2415);
  }
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eselfKept_24s877584026x861180084_24tok1_str0, 8, "compiler");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eselfKept_24s877584026x861180084_24tok1_str1, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eselfKept_24s877584026x861180084_24tok1_str2, 8, "compiler");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eselfKept_24s877584026x861180084_24tok1_str3, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eselfKept_24s877584026x861180084_24tok1_str4, 8, "compiler");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eselfKept_24s877584026x861180084_24tok1_str5, 1, "\012");
V g_heff_2ebuild_2ecommands_2eselfKept_24s877584026x861180084_24tok1_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eselfKept_24s877584026x861180084_24tok1_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eselfKept_24s877584026x861180084_24tok1_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2eselfKept_24s877584026x861180084_24tok1_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2eselfKept_24s877584026x861180084_24tok1_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2eselfKept_24s877584026x861180084_24tok1_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2eselfKept_24s877584026x861180084_24tok1_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eselfKept_24s877584026x861180084_24tok1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eselfKept_24s877584026x861180084_24tok1_entry, 6, 0};

V g_heff_2ebuild_2ecommands_2eselfKept_24s877584026x861180084_24tok1(V v_tok_240, V v_ps_241, V v_b_242, V v_id_243, V v_z_244, V v_z_245) {
top: ;
  V v_s_246 = (g_heff_2ebuild_2ecommands_2ebackDirOf(heff_dup(v_ps_241)));
  V v_path_247 = (g_std_2epath_2eparse(heff_dup(g_std_2epath_2enative_get()), v_s_246));
  V v_t_248 = ({ V b_0 = heff_dup(g_std_2epath_2enative_get()); V a_1 = v_path_247; V r_ = (g_std_2epath_2erender(b_0, a_1)); heff_drop(b_0); heff_drop(v_path_247); r_; });
  V v_a_2410 = heff_tag_n(TAG_MakeDirectory, 2, (V[]){v_t_248, ((V)&g_heff_2ebuild_2ecommands_2eselfKept_24s877584026x861180084_24tok1_lam0_clo)});
  V v_t_2411 = heff_tag_at_n(v_tok_240, TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_a_2410})});
  V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
  V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
  V v_t_2414 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
  V v_t_2415 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2414})});
  return (g_co_2eop_24s1896221640x2141527803(v_t_2415, heff_dup(v_z_244), heff_clo_n(g_heff_2ebuild_2ecommands_2eselfKept_24s877584026x861180084_24tok1_lam1, 1, 5, (V[]){v_ps_241, v_id_243, v_b_242, v_z_244, v_z_245})));
}
V g_heff_2ebuild_2ecommands_2eselfKept_24s877584026x861180084_24tok1_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eselfKept_24s877584026x861180084_24tok1(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2ebuild_2ecommands_2eselfKept_24s877584026x861180084_24tok1_lam0(V self, V *args) {
  V v_r_249 = args[0];
  return v_r_249;
}
V g_heff_2ebuild_2ecommands_2eselfKept_24s877584026x861180084_24tok1_lam2(V self, V *args) {
  V v_x_2426 = args[0];
  V v_z_245 = heff_env(self)[0];
  V v_id_243 = heff_env(self)[1];
  heff_drop(v_x_2426);
  heff_clo_take(self, 2);
  V f_ = v_z_245;
  args[0] = v_id_243;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eselfKept_24s877584026x861180084_24tok1_lam3(V self, V *args) {
  V v_x_2437 = args[0];
  V v_z_245 = heff_env(self)[0];
  V v_id_243 = heff_env(self)[1];
  heff_drop(v_x_2437);
  heff_clo_take(self, 2);
  V f_ = v_z_245;
  args[0] = v_id_243;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eselfKept_24s877584026x861180084_24tok1_lam4(V self, V *args) {
  V v_x_2447 = args[0];
  V v_z_245 = heff_env(self)[0];
  V v_id_243 = heff_env(self)[1];
  heff_drop(v_x_2447);
  heff_clo_take(self, 2);
  V f_ = v_z_245;
  args[0] = v_id_243;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eselfKept_24s877584026x861180084_24tok1_lam1(V self, V *args) {
  V v_x_2416 = args[0];
  V v_ps_241 = heff_env(self)[0];
  V v_id_243 = heff_env(self)[1];
  V v_b_242 = heff_env(self)[2];
  V v_z_244 = heff_env(self)[3];
  V v_z_245 = heff_env(self)[4];
  switch (heff_tag_of(v_x_2416)) {
  case TAG_Left: {
    heff_take_n(v_x_2416, 0ULL, 1);
    V v_d_2418 = (g_heff_2ebuild_2ecommands_2ebackDirOf(heff_dup(v_ps_241)));
    heff_clo_take(self, 5);
    V v_st_2419 = heff_get_n(v_ps_241, 5, 6);
    V v_t_2420 = (g_std_2epath_2eparse(heff_dup(v_st_2419), v_d_2418));
    V v_t_2421 = (g_std_2epath_2eparse(heff_dup(v_st_2419), ((V)&g_heff_2ebuild_2ecommands_2eselfKept_24s877584026x861180084_24tok1_str0)));
    V v_t_2422 = (g_std_2epath_2ejoin(v_t_2420, v_t_2421));
    V v_t_2423 = ({ V a_0 = v_st_2419; V a_1 = v_t_2422; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2419); heff_drop(v_t_2422); r_; });
    V v_t_2424 = heff_strAppend(heff_strAppend(heff_dup(v_id_243), ((V)&g_heff_2ebuild_2ecommands_2eselfKept_24s877584026x861180084_24tok1_str1)), v_b_242);
    V v_t_2425 = (g_heff_2ebuild_2ecommands_2ewriteWhole_24s1075045965x79585410(v_t_2423, v_t_2424));
    V f_ = v_t_2425;
    heff_room[0] = v_z_244;
    heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2eselfKept_24s877584026x861180084_24tok1_lam2, 1, 2, (V[]){v_z_245, v_id_243});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_Right: {
    V v_y_2427 = heff_field(v_x_2416, 0);
    heff_take_n(v_x_2416, 1ULL, 1);
    switch (heff_tag_of(v_y_2427)) {
    case TAG_Left: {
      heff_take_n(v_y_2427, 0ULL, 1);
      V v_d_2429 = (g_heff_2ebuild_2ecommands_2ebackDirOf(heff_dup(v_ps_241)));
      heff_clo_take(self, 5);
      V v_st_2430 = heff_get_n(v_ps_241, 5, 6);
      V v_t_2431 = (g_std_2epath_2eparse(heff_dup(v_st_2430), v_d_2429));
      V v_t_2432 = (g_std_2epath_2eparse(heff_dup(v_st_2430), ((V)&g_heff_2ebuild_2ecommands_2eselfKept_24s877584026x861180084_24tok1_str2)));
      V v_t_2433 = (g_std_2epath_2ejoin(v_t_2431, v_t_2432));
      V v_t_2434 = ({ V a_0 = v_st_2430; V a_1 = v_t_2433; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2430); heff_drop(v_t_2433); r_; });
      V v_t_2435 = heff_strAppend(heff_strAppend(heff_dup(v_id_243), ((V)&g_heff_2ebuild_2ecommands_2eselfKept_24s877584026x861180084_24tok1_str3)), v_b_242);
      V v_t_2436 = (g_heff_2ebuild_2ecommands_2ewriteWhole_24s1075045965x79585410(v_t_2434, v_t_2435));
      V f_ = v_t_2436;
      heff_room[0] = v_z_244;
      heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2eselfKept_24s877584026x861180084_24tok1_lam3, 1, 2, (V[]){v_z_245, v_id_243});
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
    case TAG_Right: {
      heff_take_n(v_y_2427, 0ULL, 1);
      V v_d_2439 = (g_heff_2ebuild_2ecommands_2ebackDirOf(heff_dup(v_ps_241)));
      heff_clo_take(self, 5);
      V v_st_2440 = heff_get_n(v_ps_241, 5, 6);
      V v_t_2441 = (g_std_2epath_2eparse(heff_dup(v_st_2440), v_d_2439));
      V v_t_2442 = (g_std_2epath_2eparse(heff_dup(v_st_2440), ((V)&g_heff_2ebuild_2ecommands_2eselfKept_24s877584026x861180084_24tok1_str4)));
      V v_t_2443 = (g_std_2epath_2ejoin(v_t_2441, v_t_2442));
      V v_t_2444 = ({ V a_0 = v_st_2440; V a_1 = v_t_2443; V r_ = (g_std_2epath_2erender(a_0, a_1)); heff_drop(v_st_2440); heff_drop(v_t_2443); r_; });
      V v_t_2445 = heff_strAppend(heff_strAppend(heff_dup(v_id_243), ((V)&g_heff_2ebuild_2ecommands_2eselfKept_24s877584026x861180084_24tok1_str5)), v_b_242);
      V v_t_2446 = (g_heff_2ebuild_2ecommands_2ewriteWhole_24s1075045965x79585410(v_t_2444, v_t_2445));
      V f_ = v_t_2446;
      heff_room[0] = v_z_244;
      heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2eselfKept_24s877584026x861180084_24tok1_lam4, 1, 2, (V[]){v_z_245, v_id_243});
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
    default: return heff_nomatch(v_y_2427);
    }
  }
  default: return heff_nomatch(v_x_2416);
  }
}