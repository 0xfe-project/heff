// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_End 17255
#define TAG_Exit 20279
#define TAG_Left 13886
#define TAG_Platform 55558
#define TAG_Posix 44191
#define TAG_ReadDir 49039
#define TAG_ReadFile 6783
#define TAG_Right 62770
#define TAG_Start 63542
#define TAG_Windows 49101
#define TAG_Write 36323
#define TAG_WriteErr 37283
#define TAG_WriteFile 62589
#define LBL_apps 9496377
#define LBL_bad 306815
#define LBL_bin 307073
#define LBL_bug 307438
#define LBL_diags 296935042
#define LBL_done 9584713
#define LBL_effect 641056956
#define LBL_errors 652506774
#define LBL_expectErrors 18827791
#define LBL_failed 665164648
#define LBL_files 298792593
#define LBL_globals 352931696
#define LBL_key 315609
#define LBL_module 878357911
#define LBL_name 9869138
#define LBL_opt 319789
#define LBL_own 320000
#define LBL_pages 307784670
#define LBL_root 10001833
#define LBL_said 10017968
#define LBL_seen 10021698
#define LBL_shipTo 1043811586
#define LBL_source 1050636102
#define LBL_tests 311609915
#define LBL_testsFailed 1062135101
#define LBL_top 324559
#define LBL_total 311908190
#define LBL_unchecked 1931098040
#define LBL_value 313331083
static uint32_t shape_apps__bad[] = {LBL_apps, LBL_bad};
static uint32_t shape_files__expectErrors__total__failed__unchecked__tests__testsFailed[] = {LBL_files, LBL_expectErrors, LBL_total, LBL_failed, LBL_unchecked, LBL_tests, LBL_testsFailed};
static uint32_t shape_name__key__effect[] = {LBL_name, LBL_key, LBL_effect};
static uint32_t shape_root__bin__said__pages__shipTo__opt[] = {LBL_root, LBL_bin, LBL_said, LBL_pages, LBL_shipTo, LBL_opt};
static uint32_t shape_seen__errors[] = {LBL_seen, LBL_errors};
V g_co_2eop_24s1084803226x1249263831(V, V, V);
V g_co_2eop_24s1084803226x1249263831_entry(V self, V *a);
extern Clo g_co_2eop_24s1084803226x1249263831_clo;
V g_co_2eop_24s954557541x749476273(V, V, V);
V g_co_2eop_24s954557541x749476273_entry(V self, V *a);
extern Clo g_co_2eop_24s954557541x749476273_clo;
V g_heff_2ebuild_2ecommands_2eaddRes(V, V);
V g_heff_2ebuild_2ecommands_2eaddRes_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eaddRes_clo;
V g_heff_2ebuild_2ecommands_2eappsIn_24s1533067604x1981180975(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eappsIn_24s1533067604x1981180975_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eappsIn_24s1533067604x1981180975_clo;
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1028981633x1628017123(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1028981633x1628017123_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1028981633x1628017123_clo;
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319(V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319_clo;
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_clo;
V g_heff_2ebuild_2ecommands_2echeckModules_24s1149060863x1991365033(V, V, V);
V g_heff_2ebuild_2ecommands_2echeckModules_24s1149060863x1991365033_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2echeckModules_24s1149060863x1991365033_clo;
V g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1111014622x266173959(V, V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1111014622x266173959_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1111014622x266173959_clo;
V g_heff_2ebuild_2ecommands_2ecompileJsOut_24s1088149016x1550968084(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecompileJsOut_24s1088149016x1550968084_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecompileJsOut_24s1088149016x1550968084_clo;
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s1631811027x526216914(V, V, V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s1631811027x526216914_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ecompileLastC_24s1631811027x526216914_clo;
V g_heff_2ebuild_2ecommands_2ediagCount_24s1170581875x2081974925(V);
V g_heff_2ebuild_2ecommands_2ediagCount_24s1170581875x2081974925_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ediagCount_24s1170581875x2081974925_clo;
V g_heff_2ebuild_2ecommands_2eemitErrs_24s1520432158x997405890(V, V, V);
V g_heff_2ebuild_2ecommands_2eemitErrs_24s1520432158x997405890_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eemitErrs_24s1520432158x997405890_clo;
V g_heff_2ebuild_2ecommands_2eheffHome_24s1023006878x6127580(V, V);
V g_heff_2ebuild_2ecommands_2eheffHome_24s1023006878x6127580_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eheffHome_24s1023006878x6127580_clo;
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1962784645x2035712448(V, V);
V g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1962784645x2035712448_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1962784645x2035712448_clo;
V g_heff_2ebuild_2ecommands_2eimportsOn_24acc(V, V);
V g_heff_2ebuild_2ecommands_2eimportsOn_24acc_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eimportsOn_24acc_clo;
V g_heff_2ebuild_2ecommands_2einstallCmd_24s659320162x1710670004(V, V, V);
V g_heff_2ebuild_2ecommands_2einstallCmd_24s659320162x1710670004_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2einstallCmd_24s659320162x1710670004_clo;
V g_heff_2ebuild_2ecommands_2enubStrGo(V, V);
V g_heff_2ebuild_2ecommands_2enubStrGo_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2enubStrGo_clo;
V g_heff_2ebuild_2ecommands_2eonPathHint_24s397492699x957798544(V, V, V, V);
V g_heff_2ebuild_2ecommands_2eonPathHint_24s397492699x957798544_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eonPathHint_24s397492699x957798544_clo;
V g_heff_2ebuild_2ecommands_2eownPackage_24s759818713x2101508697(V, V);
V g_heff_2ebuild_2ecommands_2eownPackage_24s759818713x2101508697_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eownPackage_24s759818713x2101508697_clo;
V g_heff_2ebuild_2ecommands_2eprintAll_24s661059568x2144438338(V, V);
V g_heff_2ebuild_2ecommands_2eprintAll_24s661059568x2144438338_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprintAll_24s661059568x2144438338_clo;
V g_heff_2ebuild_2ecommands_2eprintDefs_24s2084586815x771131724(V, V);
V g_heff_2ebuild_2ecommands_2eprintDefs_24s2084586815x771131724_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprintDefs_24s2084586815x771131724_clo;
V g_heff_2ebuild_2ecommands_2eprintErrs_24s1290182366x1682594351(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2eprintErrs_24s1290182366x1682594351_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprintErrs_24s1290182366x1682594351_clo;
V g_heff_2ebuild_2ecommands_2eprintEvals_24s2126685520x1186208326(V, V, V);
V g_heff_2ebuild_2ecommands_2eprintEvals_24s2126685520x1186208326_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eprintEvals_24s2126685520x1186208326_clo;
V g_heff_2ebuild_2ecommands_2ereadProviderAt_24s78037021x1150470520(V, V);
V g_heff_2ebuild_2ecommands_2ereadProviderAt_24s78037021x1150470520_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ereadProviderAt_24s78037021x1150470520_clo;
V g_heff_2ebuild_2ecommands_2ereadProviders_24s1903513967x586334405(V, V);
V g_heff_2ebuild_2ecommands_2ereadProviders_24s1903513967x586334405_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ereadProviders_24s1903513967x586334405_clo;
V g_heff_2ebuild_2ecommands_2ereadProvidersC_24s2010556288x1036896176(V, V);
V g_heff_2ebuild_2ecommands_2ereadProvidersC_24s2010556288x1036896176_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ereadProvidersC_24s2010556288x1036896176_clo;
V g_heff_2ebuild_2ecommands_2ereadRuntimeC_24s2075524515x1767608914(V, V);
V g_heff_2ebuild_2ecommands_2ereadRuntimeC_24s2075524515x1767608914_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ereadRuntimeC_24s2075524515x1767608914_clo;
V g_heff_2ebuild_2ecommands_2esourceSaved_24s1653971658x1305473599(V, V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2esourceSaved_24s1653971658x1305473599_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2esourceSaved_24s1653971658x1305473599_clo;
V g_heff_2ebuild_2ecommands_2etestExpecting_24s1422729883x52088269(V, V, V, V);
V g_heff_2ebuild_2ecommands_2etestExpecting_24s1422729883x52088269_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2etestExpecting_24s1422729883x52088269_clo;
V g_heff_2ebuild_2ecommands_2etestLoaded_24s600885671x1807731663(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2etestLoaded_24s600885671x1807731663_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2etestLoaded_24s600885671x1807731663_clo;
V g_heff_2ebuild_2ecommands_2etestOneC_24s779417995x2124390546(V, V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2etestOneC_24s779417995x2124390546_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2etestOneC_24s779417995x2124390546_clo;
V g_heff_2ebuild_2ecommands_2eversionCmd_24s1875053145x1484821650(V, V);
V g_heff_2ebuild_2ecommands_2eversionCmd_24s1875053145x1484821650_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eversionCmd_24s1875053145x1484821650_clo;
V g_heff_2ebuild_2ecommands_2eversionSaid(V, V);
V g_heff_2ebuild_2ecommands_2eversionSaid_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2eversionSaid_clo;
V g_heff_2ebuild_2ecommands_2ewriteOut_24s502758308x422607463(V, V, V, V, V);
V g_heff_2ebuild_2ecommands_2ewriteOut_24s502758308x422607463_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ewriteOut_24s502758308x422607463_clo;
V g_heff_2ebuild_2ecommands_2ewritePartsGo_24s1984871218x120517796(V, V, V, V);
V g_heff_2ebuild_2ecommands_2ewritePartsGo_24s1984871218x120517796_entry(V self, V *a);
extern Clo g_heff_2ebuild_2ecommands_2ewritePartsGo_24s1984871218x120517796_clo;
V g_heff_2ebuild_2edriver_2ecandLeaves(V);
V g_heff_2ebuild_2edriver_2ecandLeaves_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ecandLeaves_clo;
V g_heff_2ebuild_2edriver_2ecatMaybesD(V);
V g_heff_2ebuild_2edriver_2ecatMaybesD_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2ecatMaybesD_clo;
V g_heff_2ebuild_2edriver_2eeffectOfKey(V, V);
V g_heff_2ebuild_2edriver_2eeffectOfKey_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2eeffectOfKey_clo;
V g_heff_2ebuild_2edriver_2elastChecked(V);
V g_heff_2ebuild_2edriver_2elastChecked_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2elastChecked_clo;
V g_heff_2ebuild_2edriver_2enubStrD(V);
V g_heff_2ebuild_2edriver_2enubStrD_entry(V self, V *a);
extern Clo g_heff_2ebuild_2edriver_2enubStrD_clo;
V g_heff_2ebuild_2eproject_2eheffModule_get(void);
V g_heff_2ebuild_2eproject_2epackageLit(V);
V g_heff_2ebuild_2eproject_2epackageLit_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2epackageLit_clo;
V g_heff_2ebuild_2eproject_2epackageOf(V);
V g_heff_2ebuild_2eproject_2epackageOf_entry(V self, V *a);
extern Clo g_heff_2ebuild_2eproject_2epackageOf_clo;
V g_heff_2ebuild_2esession_2ecachedAcc_24s1731440598x239873598(V);
V g_heff_2ebuild_2esession_2ecachedAcc_24s1731440598x239873598_entry(V self, V *a);
extern Clo g_heff_2ebuild_2esession_2ecachedAcc_24s1731440598x239873598_clo;
V g_heff_2ecompile_2eemitc_2echeckOut(V, V, V);
V g_heff_2ecompile_2eemitc_2echeckOut_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eemitc_2echeckOut_clo;
V g_heff_2ecompile_2eerase_2eeraseProgram(V);
V g_heff_2ecompile_2eerase_2eeraseProgram_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eerase_2eeraseProgram_clo;
V g_heff_2ecompile_2elower_2ecErased(V, V);
V g_heff_2ecompile_2elower_2ecErased_entry(V self, V *a);
extern Clo g_heff_2ecompile_2elower_2ecErased_clo;
V g_list_2eany_24s1996724342x1838336560(V);
V g_list_2eany_24s1996724342x1838336560_entry(V self, V *a);
extern Clo g_list_2eany_24s1996724342x1838336560_clo;
V g_list_2efoldl_24f1046331721x1909432377(V, V, V);
V g_list_2efoldl_24f1046331721x1909432377_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1046331721x1909432377_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1173914895x100384474(V);
V g_list_2emap_24s1173914895x100384474_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_clo;
V g_list_2emap_24s152505078x225062837(V);
V g_list_2emap_24s152505078x225062837_entry(V self, V *a);
extern Clo g_list_2emap_24s152505078x225062837_clo;
V g_list_2emap_24s370939663x1496042695(V, V);
V g_list_2emap_24s370939663x1496042695_entry(V self, V *a);
extern Clo g_list_2emap_24s370939663x1496042695_clo;
V g_list_2emap_24s764064723x821001015(V);
V g_list_2emap_24s764064723x821001015_entry(V self, V *a);
extern Clo g_list_2emap_24s764064723x821001015_clo;
V g_list_2emap_24s803586165x1676441765(V, V, V, V, V, V, V);
V g_list_2emap_24s803586165x1676441765_entry(V self, V *a);
extern Clo g_list_2emap_24s803586165x1676441765_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_std_2epath_2ejoin(V, V, V);
V g_std_2epath_2ejoin_entry(V self, V *a);
extern Clo g_std_2epath_2ejoin_clo;
V g_std_2eprogress_2eroot_get(void);
HEFF_LIT(g_heff_2ebuild_2ecommands_2eimportsOn_24acc_str0, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eimportsOn_24acc_str1, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eimportsOn_24acc_str2, 10, "imports it");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eimportsOn_24acc_str3, 9, "imports `");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eimportsOn_24acc_str4, 9, "`, which ");
Clo g_heff_2ebuild_2ecommands_2eimportsOn_24acc_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eimportsOn_24acc_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2eimportsOn_24acc(V v_x1_240, V v_acc_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_strAppend(v_acc_241, ((V)&g_heff_2ebuild_2ecommands_2eimportsOn_24acc_str0));
  }
  case TAG_Cons: {
    V v_x12_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 2ULL, 2);
    switch (heff_tag_of(v_x12_243)) {
    case TAG_Nil: {
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      return heff_strAppend(v_acc_241, ((V)&g_heff_2ebuild_2ecommands_2eimportsOn_24acc_str1));
    }
    case TAG_Cons: {
      V v_b_244 = heff_field(v_x12_243, 0);
      V v_x122_245 = heff_field(v_x12_243, 1);
      heff_take_n(v_x12_243, 3ULL, 2);
      switch (heff_tag_of(v_x122_245)) {
      case TAG_Nil: {
        heff_drop_cell(v_ru_24x1_240_24Cons, 2);
        heff_drop(v_b_244);
        return heff_strAppend(v_acc_241, ((V)&g_heff_2ebuild_2ecommands_2eimportsOn_24acc_str2));
      }
      case TAG_Cons: {
        V v_s_248 = heff_strAppend(v_acc_241, ((V)&g_heff_2ebuild_2ecommands_2eimportsOn_24acc_str3));
        V v_s_249 = heff_strAppend(v_s_248, heff_dup(v_b_244));
        V v_s_2410 = heff_strAppend(v_s_249, ((V)&g_heff_2ebuild_2ecommands_2eimportsOn_24acc_str4));
        V t_0 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_b_244, v_x122_245});
        V t_1 = v_s_2410;
        v_x1_240 = t_0;
        v_acc_241 = t_1;
        goto top;
      }
      default: return heff_nomatch(v_x122_245);
      }
    }
    default: return heff_nomatch(v_x12_243);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2ecommands_2eimportsOn_24acc_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eimportsOn_24acc(a[0], a[1]);
}
Clo g_heff_2ebuild_2ecommands_2eaddRes_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eaddRes_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2eaddRes(V v_a_240, V v_b_241) {
top: ;
  V v_t_242 = heff_intAdd(heff_take_field(v_a_240, 0), heff_take_field(v_b_241, 0));
  V v_t_243 = heff_intAdd(heff_take_field(v_a_240, 1), heff_take_field(v_b_241, 1));
  V v_t_244 = heff_intAdd(heff_take_field(v_a_240, 2), heff_take_field(v_b_241, 2));
  V v_t_245 = heff_intAdd(heff_take_field(v_a_240, 3), heff_take_field(v_b_241, 3));
  V v_t_246 = (g_prelude_2e_2b_2b(heff_take_field(v_a_240, 4), heff_take_field(v_b_241, 4)));
  V v_t_247 = heff_intAdd(heff_take_field(v_a_240, 5), heff_take_field(v_b_241, 5));
  V v_t_248 = heff_intAdd(heff_get_n(v_a_240, 6, 7), heff_get_n(v_b_241, 6, 7));
  return heff_rec_n(7, shape_files__expectErrors__total__failed__unchecked__tests__testsFailed, (V[]){v_t_242, v_t_243, v_t_244, v_t_245, v_t_246, v_t_247, v_t_248});
}
V g_heff_2ebuild_2ecommands_2eaddRes_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eaddRes(a[0], a[1]);
}
V g_heff_2ebuild_2ecommands_2ecompileJsOut_24s1088149016x1550968084_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ecompileJsOut_24s1088149016x1550968084_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecompileJsOut_24s1088149016x1550968084_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2ecompileJsOut_24s1088149016x1550968084_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileJsOut_24s1088149016x1550968084_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ecompileJsOut_24s1088149016x1550968084_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecompileJsOut_24s1088149016x1550968084_entry, 5, 0};

V g_heff_2ebuild_2ecommands_2ecompileJsOut_24s1088149016x1550968084(V v_outPath_240, V v_bad_241, V v_o_242, V v_hd_243, V v_k_244) {
top: ;
  V v_t_246 = heff_tag_n(TAG_WriteFile, 3, (V[]){v_outPath_240, heff_dup(heff_rfield(v_o_242, 0)), ((V)&g_heff_2ebuild_2ecommands_2ecompileJsOut_24s1088149016x1550968084_lam0_clo)});
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_246})});
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
  return (g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InR, 1, (V[]){v_t_248}), heff_dup(v_hd_243), heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileJsOut_24s1088149016x1550968084_lam1, 1, 4, (V[]){v_o_242, v_hd_243, heff_dup(v_bad_241), v_k_244})));
}
V g_heff_2ebuild_2ecommands_2ecompileJsOut_24s1088149016x1550968084_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ebuild_2ecommands_2ecompileJsOut_24s1088149016x1550968084(a[0], a1, a[2], a[3], a[4]); heff_drop(a1); return r;
}
V g_heff_2ebuild_2ecommands_2ecompileJsOut_24s1088149016x1550968084_lam0(V self, V *args) {
  V v_ok_245 = args[0];
  return v_ok_245;
}
V g_heff_2ebuild_2ecommands_2ecompileJsOut_24s1088149016x1550968084_lam2(V self, V *args) {
  V v_x_2410 = args[0];
  V v_x_249 = heff_env(self)[0];
  V v_bad_241 = heff_env(self)[1];
  V v_hd_243 = heff_env(self)[2];
  V v_k_244 = heff_env(self)[3];
  V v_o_242 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2410);
  if ((heff_dup(v_x_249) == NTAG(TAG_True))) {
    heff_drop(v_x_249);
    if ((heff_dup(v_bad_241) == NTAG(TAG_True))) {
      heff_drop(v_bad_241);
      heff_drop_rec(v_o_242, 2);
      V v_t_2411 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
      V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2411})});
      V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
      V v_t_2414 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
      return (g_co_2eop_24s954557541x749476273(v_t_2414, v_hd_243, v_k_244));
    } else {
      heff_drop(v_bad_241);
      V v_t_2415 = heff_get_n(v_o_242, 1, 2);
      switch (heff_tag_of(v_t_2415)) {
      case TAG_Nil: {
        heff_drop(v_hd_243);
        V f_ = v_k_244;
        args[0] = NTAG(TAG_MkUnit);
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      }
      case TAG_Cons: {
        V v_ru_24t_2415_24Cons = heff_take_reuse_n(v_t_2415, 0ULL, 2);
        V v_t_2418 = heff_tag_at_n(v_ru_24t_2415_24Cons, TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
        V v_t_2419 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2418})});
        V v_t_2420 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2419})});
        V v_t_2421 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
        return (g_co_2eop_24s954557541x749476273(v_t_2421, v_hd_243, v_k_244));
      }
      default: return heff_nomatch(v_t_2415);
      }
    }
  } else {
    heff_drop(v_x_249);
    heff_drop(v_bad_241);
    heff_drop_rec(v_o_242, 2);
    V v_t_2422 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
    V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2422})});
    V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
    V v_t_2425 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
    return (g_co_2eop_24s954557541x749476273(v_t_2425, v_hd_243, v_k_244));
  }
}
V g_heff_2ebuild_2ecommands_2ecompileJsOut_24s1088149016x1550968084_lam1(V self, V *args) {
  V v_x_249 = args[0];
  V v_o_242 = heff_env(self)[0];
  V v_hd_243 = heff_env(self)[1];
  V v_bad_241 = heff_env(self)[2];
  V v_k_244 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2ebuild_2ecommands_2eemitErrs_24s1520432158x997405890(heff_dup(heff_rfield(v_o_242, 1)), heff_dup(v_hd_243), heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileJsOut_24s1088149016x1550968084_lam2, 1, 5, (V[]){v_x_249, v_bad_241, v_hd_243, v_k_244, v_o_242})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ewritePartsGo_24s1984871218x120517796_str0, 5, "win32");
V g_heff_2ebuild_2ecommands_2ewritePartsGo_24s1984871218x120517796_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ewritePartsGo_24s1984871218x120517796_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewritePartsGo_24s1984871218x120517796_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2ewritePartsGo_24s1984871218x120517796_lam2(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ewritePartsGo_24s1984871218x120517796_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewritePartsGo_24s1984871218x120517796_lam2, 1, 0};
V g_heff_2ebuild_2ecommands_2ewritePartsGo_24s1984871218x120517796_lam4(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ewritePartsGo_24s1984871218x120517796_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewritePartsGo_24s1984871218x120517796_lam4, 1, 0};
V g_heff_2ebuild_2ecommands_2ewritePartsGo_24s1984871218x120517796_lam5(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ewritePartsGo_24s1984871218x120517796_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewritePartsGo_24s1984871218x120517796_lam5, 2, 0};
V g_heff_2ebuild_2ecommands_2ewritePartsGo_24s1984871218x120517796_lam6(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ewritePartsGo_24s1984871218x120517796_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewritePartsGo_24s1984871218x120517796_lam6, 1, 0};
V g_heff_2ebuild_2ecommands_2ewritePartsGo_24s1984871218x120517796_lam7(V self, V *args);
V g_heff_2ebuild_2ecommands_2ewritePartsGo_24s1984871218x120517796_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ewritePartsGo_24s1984871218x120517796_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ewritePartsGo_24s1984871218x120517796_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewritePartsGo_24s1984871218x120517796_entry, 4, 0};

V g_heff_2ebuild_2ecommands_2ewritePartsGo_24s1984871218x120517796(V v_dir_240, V v_x2_241, V v_p_242, V v_p_243) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_dir_240);
    heff_drop(v_p_242);
    return heff_tail(v_p_243, 1, (V[]){NTAG(TAG_True)});
  }
  case TAG_Cons: {
    V v_x21_244 = heff_field(v_x2_241, 0);
    V v_rest_245 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_244)) {
    case TAG_MkPair: {
      V v_name_246 = heff_field(v_x21_244, 0);
      V v_text_247 = heff_field(v_x21_244, 1);
      heff_take_n(v_x21_244, 3ULL, 2);
      V v_t_249 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2ewritePartsGo_24s1984871218x120517796_lam0_clo)})});
      V v_t_2410 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
      V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
      return (g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InR, 1, (V[]){v_t_2411}), heff_dup(v_p_242), heff_clo_n(g_heff_2ebuild_2ecommands_2ewritePartsGo_24s1984871218x120517796_lam1, 1, 6, (V[]){v_dir_240, v_name_246, v_p_242, v_text_247, v_rest_245, v_p_243})));
    }
    default: return heff_nomatch(v_x21_244);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2ecommands_2ewritePartsGo_24s1984871218x120517796_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ewritePartsGo_24s1984871218x120517796(a[0], a[1], a[2], a[3]);
}
V g_heff_2ebuild_2ecommands_2ewritePartsGo_24s1984871218x120517796_lam0(V self, V *args) {
  V v_s_248 = args[0];
  return v_s_248;
}
V g_heff_2ebuild_2ecommands_2ewritePartsGo_24s1984871218x120517796_lam2(V self, V *args) {
  V v_t_2416 = args[0];
  return v_t_2416;
}
V g_heff_2ebuild_2ecommands_2ewritePartsGo_24s1984871218x120517796_lam4(V self, V *args) {
  V v_ok_2422 = args[0];
  return v_ok_2422;
}
V g_heff_2ebuild_2ecommands_2ewritePartsGo_24s1984871218x120517796_lam5(V self, V *args) {
  V v_hd_2428 = args[0];
  V v_k_2429 = args[1];
  heff_drop(v_hd_2428);
  V f_ = v_k_2429;
  args[0] = NTAG(TAG_True);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ewritePartsGo_24s1984871218x120517796_lam6(V self, V *args) {
  V v_ok_2430 = args[0];
  return v_ok_2430;
}
V g_heff_2ebuild_2ecommands_2ewritePartsGo_24s1984871218x120517796_lam7(V self, V *args) {
  V v_x_2435 = args[0];
  V v_dir_240 = heff_env(self)[0];
  V v_rest_245 = heff_env(self)[1];
  V v_p_242 = heff_env(self)[2];
  V v_p_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  if ((heff_dup(v_x_2435) == NTAG(TAG_True))) {
    heff_drop(v_x_2435);
    return (g_heff_2ebuild_2ecommands_2ewritePartsGo_24s1984871218x120517796(v_dir_240, v_rest_245, v_p_242, v_p_243));
  } else {
    heff_drop(v_x_2435);
    heff_drop(v_dir_240);
    heff_drop(v_rest_245);
    heff_drop(v_p_242);
    V f_ = v_p_243;
    args[0] = NTAG(TAG_False);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
}
V g_heff_2ebuild_2ecommands_2ewritePartsGo_24s1984871218x120517796_lam3(V self, V *args) {
  V v_x_2420 = args[0];
  V v_st_2414 = heff_env(self)[0];
  V v_dir_240 = heff_env(self)[1];
  V v_name_246 = heff_env(self)[2];
  V v_text_247 = heff_env(self)[3];
  V v_p_242 = heff_env(self)[4];
  V v_rest_245 = heff_env(self)[5];
  V v_p_243 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_path_2421 = ({ V a_0 = v_st_2414; V a_1 = heff_dup(v_dir_240); V a_2 = v_name_246; V r_ = (g_std_2epath_2ejoin(a_0, a_1, a_2)); heff_drop(v_st_2414); r_; });
  V v_c_2434;
  switch (heff_tag_of(v_x_2420)) {
  case TAG_Nothing: {
    V v_t_2423 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_WriteFile, 3, (V[]){v_path_2421, v_text_247, ((V)&g_heff_2ebuild_2ecommands_2ewritePartsGo_24s1984871218x120517796_lam4_clo)})});
    V v_t_2424 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
    V v_t_2425 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2424})});
    v_c_2434 = heff_tr(heff_call(((V)&g_co_2eop_24s1084803226x1249263831_clo), 1, (V[]){v_t_2425}));
    break;
  }
  case TAG_Just: {
    V v_was_2426 = heff_field(v_x_2420, 0);
    V v_ru_24x_2420_24Just = heff_take_reuse_n(v_x_2420, 1ULL, 1);
    if (heff_strEq_c_lent(v_was_2426, v_text_247, 1)) {
      heff_drop(v_text_247);
      heff_drop(v_path_2421);
      heff_drop_cell(v_ru_24x_2420_24Just, 1);
      v_c_2434 = ((V)&g_heff_2ebuild_2ecommands_2ewritePartsGo_24s1984871218x120517796_lam5_clo);
    } else {
      V v_t_2431 = heff_tag_at_n(v_ru_24x_2420_24Just, TAG_InR, 1, (V[]){heff_tag_n(TAG_WriteFile, 3, (V[]){v_path_2421, v_text_247, ((V)&g_heff_2ebuild_2ecommands_2ewritePartsGo_24s1984871218x120517796_lam6_clo)})});
      V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
      V v_t_2433 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2432})});
      v_c_2434 = heff_tr(heff_call(((V)&g_co_2eop_24s1084803226x1249263831_clo), 1, (V[]){v_t_2433}));
    }
    break;
  }
  default: heff_nomatch(v_x_2420);
  }
  V f_ = v_c_2434;
  heff_room[0] = heff_dup(v_p_242);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ewritePartsGo_24s1984871218x120517796_lam7, 1, 4, (V[]){v_dir_240, v_rest_245, v_p_242, v_p_243});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ewritePartsGo_24s1984871218x120517796_lam1(V self, V *args) {
  V v_x_2412 = args[0];
  V v_dir_240 = heff_env(self)[0];
  V v_name_246 = heff_env(self)[1];
  V v_p_242 = heff_env(self)[2];
  V v_text_247 = heff_env(self)[3];
  V v_rest_245 = heff_env(self)[4];
  V v_p_243 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_st_2414;
  if (heff_strEq_c(v_x_2412, ((V)&g_heff_2ebuild_2ecommands_2ewritePartsGo_24s1984871218x120517796_str0))) {
    v_st_2414 = NTAG(TAG_Windows);
  } else {
    v_st_2414 = NTAG(TAG_Posix);
  }
  V v_path_2415 = (g_std_2epath_2ejoin(v_st_2414, heff_dup(v_dir_240), heff_dup(v_name_246)));
  V v_t_2417 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){v_path_2415, ((V)&g_heff_2ebuild_2ecommands_2ewritePartsGo_24s1984871218x120517796_lam2_clo)})});
  V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
  return (g_co_2eop_24s954557541x749476273(v_t_2419, heff_dup(v_p_242), heff_clo_n(g_heff_2ebuild_2ecommands_2ewritePartsGo_24s1984871218x120517796_lam3, 1, 7, (V[]){v_st_2414, v_dir_240, v_name_246, v_text_247, v_p_242, v_rest_245, v_p_243})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ewriteOut_24s502758308x422607463_str0, 13, "cannot write ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ewriteOut_24s502758308x422607463_str1, 1, "\012");
V g_heff_2ebuild_2ecommands_2ewriteOut_24s502758308x422607463_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ewriteOut_24s502758308x422607463_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewriteOut_24s502758308x422607463_lam1, 1, 0};
V g_heff_2ebuild_2ecommands_2ewriteOut_24s502758308x422607463_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ewriteOut_24s502758308x422607463_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ewriteOut_24s502758308x422607463_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ewriteOut_24s502758308x422607463_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ewriteOut_24s502758308x422607463_entry, 5, 0};

V g_heff_2ebuild_2ecommands_2ewriteOut_24s502758308x422607463(V v_outPath_240, V v_done_241, V v_o_242, V v_hd_243, V v_k_244) {
top: ;
  return (g_heff_2ebuild_2ecommands_2eemitErrs_24s1520432158x997405890(heff_dup(heff_rfield(v_o_242, 1)), heff_dup(v_hd_243), heff_clo_n(g_heff_2ebuild_2ecommands_2ewriteOut_24s502758308x422607463_lam0, 1, 5, (V[]){v_o_242, v_outPath_240, v_hd_243, v_done_241, v_k_244})));
}
V g_heff_2ebuild_2ecommands_2ewriteOut_24s502758308x422607463_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ewriteOut_24s502758308x422607463(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ebuild_2ecommands_2ewriteOut_24s502758308x422607463_lam1(V self, V *args) {
  V v_ok_2410 = args[0];
  return v_ok_2410;
}
V g_heff_2ebuild_2ecommands_2ewriteOut_24s502758308x422607463_lam3(V self, V *args) {
  V v_x_2420 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_k_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2420);
  V v_t_2421 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2421})});
  V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
  V v_t_2424 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
  return (g_co_2eop_24s954557541x749476273(v_t_2424, v_hd_243, v_k_244));
}
V g_heff_2ebuild_2ecommands_2ewriteOut_24s502758308x422607463_lam2(V self, V *args) {
  V v_x_2414 = args[0];
  V v_done_241 = heff_env(self)[0];
  V v_hd_243 = heff_env(self)[1];
  V v_k_244 = heff_env(self)[2];
  V v_outPath_240 = heff_env(self)[3];
  heff_clo_take(self, 4);
  if ((heff_dup(v_x_2414) == NTAG(TAG_True))) {
    heff_drop(v_x_2414);
    heff_drop(v_outPath_240);
    V f_ = v_done_241;
    heff_room[0] = v_hd_243;
    heff_room[1] = v_k_244;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  } else {
    heff_drop(v_x_2414);
    heff_drop(v_done_241);
    V v_t_2415 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ewriteOut_24s502758308x422607463_str0), v_outPath_240), ((V)&g_heff_2ebuild_2ecommands_2ewriteOut_24s502758308x422607463_str1));
    V v_t_2416 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2415, NTAG(TAG_MkUnit)});
    V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
    V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
    V v_t_2419 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
    return (g_co_2eop_24s954557541x749476273(v_t_2419, heff_dup(v_hd_243), heff_clo_n(g_heff_2ebuild_2ecommands_2ewriteOut_24s502758308x422607463_lam3, 1, 2, (V[]){v_hd_243, v_k_244})));
  }
}
V g_heff_2ebuild_2ecommands_2ewriteOut_24s502758308x422607463_lam0(V self, V *args) {
  V v_x_245 = args[0];
  V v_o_242 = heff_env(self)[0];
  V v_outPath_240 = heff_env(self)[1];
  V v_hd_243 = heff_env(self)[2];
  V v_done_241 = heff_env(self)[3];
  V v_k_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_245);
  V v_t_246 = heff_take_field(v_o_242, 1);
  V v_t_249;
  switch (heff_tag_of(v_t_246)) {
  case TAG_Nil: {
    v_t_249 = NTAG(TAG_True);
    break;
  }
  case TAG_Cons: {
    heff_take_n(v_t_246, 0ULL, 2);
    v_t_249 = NTAG(TAG_False);
    break;
  }
  default: heff_nomatch(v_t_246);
  }
  if ((heff_dup(v_t_249) == NTAG(TAG_True))) {
    heff_drop(v_t_249);
    V v_t_2411 = heff_tag_n(TAG_WriteFile, 3, (V[]){heff_dup(v_outPath_240), heff_get_n(v_o_242, 0, 2), ((V)&g_heff_2ebuild_2ecommands_2ewriteOut_24s502758308x422607463_lam1_clo)});
    V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2411})});
    V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
    return (g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InR, 1, (V[]){v_t_2413}), heff_dup(v_hd_243), heff_clo_n(g_heff_2ebuild_2ecommands_2ewriteOut_24s502758308x422607463_lam2, 1, 4, (V[]){v_done_241, v_hd_243, v_k_244, v_outPath_240})));
  } else {
    heff_drop_rec(v_o_242, 2);
    heff_drop(v_outPath_240);
    heff_drop(v_done_241);
    heff_drop(v_t_249);
    V v_t_2425 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
    V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2425})});
    V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
    V v_t_2428 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
    return (g_co_2eop_24s954557541x749476273(v_t_2428, v_hd_243, v_k_244));
  }
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s1631811027x526216914_str0, 15, "no files given\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s1631811027x526216914_str1, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s1631811027x526216914_str2, 1, ".");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s1631811027x526216914_str3, 0, "");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ecompileLastC_24s1631811027x526216914_str4, 1, ".");
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s1631811027x526216914_lam0(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s1631811027x526216914_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s1631811027x526216914_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s1631811027x526216914_lam2(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ecompileLastC_24s1631811027x526216914_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ecompileLastC_24s1631811027x526216914_entry, 9, 0};

V g_heff_2ebuild_2ecommands_2ecompileLastC_24s1631811027x526216914(V v_bi_240, V v_sources_241, V v_file_242, V v_name_243, V v_outPath_244, V v_done_245, V v_cs_246, V v_z_247, V v_z_248) {
top: ;
  V v_t_249 = (g_heff_2ebuild_2edriver_2elastChecked(v_cs_246));
  switch (heff_tag_of(v_t_249)) {
  case TAG_Nothing: {
    heff_drop(v_bi_240);
    heff_drop(v_file_242);
    heff_drop(v_name_243);
    heff_drop(v_outPath_244);
    heff_drop(v_done_245);
    V v_t_2410 = heff_tag_n(TAG_WriteErr, 2, (V[]){((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s1631811027x526216914_str0), NTAG(TAG_MkUnit)});
    V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2410})});
    V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
    V v_t_2413 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
    return (g_co_2eop_24s954557541x749476273(v_t_2413, heff_dup(v_z_247), heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileLastC_24s1631811027x526216914_lam0, 1, 2, (V[]){v_z_247, v_z_248})));
  }
  case TAG_Just: {
    V v_c_2419 = heff_field(v_t_249, 0);
    heff_take_n(v_t_249, 1ULL, 1);
    V v_t_2424 = (g_list_2emap(heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileLastC_24s1631811027x526216914_lam1, 1, 1, (V[]){heff_dup(v_c_2419)}), heff_dup(heff_rfield(v_c_2419, 7))));
    V v_t_2425 = (g_heff_2ebuild_2edriver_2ecatMaybesD(v_t_2424));
    V v_t_2426 = ({ V a_0 = v_t_2425; V r_ = (g_heff_2ebuild_2edriver_2ecandLeaves(a_0)); heff_drop(v_t_2425); r_; });
    V v_t_2427 = (g_heff_2ebuild_2edriver_2enubStrD(v_t_2426));
    V v_xs_2428 = (g_list_2emap_24s803586165x1676441765(((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s1631811027x526216914_str1), MK_INT(0LL), ((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s1631811027x526216914_str2), MK_INT(0LL), ((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s1631811027x526216914_str3), ((V)&g_heff_2ebuild_2ecommands_2ecompileLastC_24s1631811027x526216914_str4), v_t_2427));
    V v_t_2429 = (g_heff_2ebuild_2ecommands_2enubStrGo(NTAG(TAG_Nil), v_xs_2428));
    V v_c_2430 = (g_heff_2ebuild_2ecommands_2ereadProvidersC_24s2010556288x1036896176(v_sources_241, v_t_2429));
    return heff_tail(v_c_2430, 2, (V[]){heff_dup(v_z_247), heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileLastC_24s1631811027x526216914_lam2, 1, 8, (V[]){v_z_247, v_name_243, v_c_2419, v_outPath_244, v_z_248, v_bi_240, v_file_242, v_done_245})});
  }
  default: return heff_nomatch(v_t_249);
  }
}
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s1631811027x526216914_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V a6 = a[6]; V r = g_heff_2ebuild_2ecommands_2ecompileLastC_24s1631811027x526216914(a[0], a1, a[2], a[3], a[4], a[5], a6, a[7], a[8]); heff_drop(a1); heff_drop(a6); return r;
}
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s1631811027x526216914_lam0(V self, V *args) {
  V v_x_2414 = args[0];
  V v_z_247 = heff_env(self)[0];
  V v_z_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2414);
  V v_t_2415 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2416 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2415})});
  V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
  return (g_co_2eop_24s954557541x749476273(v_t_2418, v_z_247, v_z_248));
}
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s1631811027x526216914_lam1(V self, V *args) {
  V v_o_2420 = args[0];
  V v_c_2419 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2421 = (g_heff_2ebuild_2edriver_2eeffectOfKey(v_c_2419, heff_dup(heff_rfield(v_o_2420, 1))));
  switch (heff_tag_of(v_t_2421)) {
  case TAG_Nothing: {
    heff_drop_rec(v_o_2420, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_Just: {
    V v_eff_2422 = heff_field(v_t_2421, 0);
    V v_ru_24t_2421_24Just = heff_take_reuse_n(v_t_2421, 1ULL, 1);
    V v_t_2423 = heff_rec_n(3, shape_name__key__effect, (V[]){heff_take_field(v_o_2420, 0), heff_get_n(v_o_2420, 1, 2), v_eff_2422});
    return heff_tag_at_n(v_ru_24t_2421_24Just, TAG_Just, 1, (V[]){v_t_2423});
  }
  default: return heff_nomatch(v_t_2421);
  }
}
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s1631811027x526216914_lam3(V self, V *args) {
  V v_x_2433 = args[0];
  V v_name_243 = heff_env(self)[0];
  V v_c_2419 = heff_env(self)[1];
  V v_outPath_244 = heff_env(self)[2];
  V v_z_247 = heff_env(self)[3];
  V v_z_248 = heff_env(self)[4];
  V v_bi_240 = heff_env(self)[5];
  V v_file_242 = heff_env(self)[6];
  V v_done_245 = heff_env(self)[7];
  V v_x_2431 = heff_env(self)[8];
  heff_clo_take(self, 9);
  switch (heff_tag_of(v_name_243)) {
  case TAG_Nothing: {
    heff_drop(v_bi_240);
    heff_drop(v_file_242);
    heff_drop(v_done_245);
    heff_drop(v_x_2431);
    V v_exports_2434 = (g_list_2emap_24s764064723x821001015(heff_take_field(v_c_2419, 7)));
    V v_roots_2435 = (g_list_2emap_24s1173914895x100384474(heff_dup(v_exports_2434)));
    V v_t_2436 = heff_get_n(heff_get_n(v_c_2419, 5, 13), 0, 9);
    V v_t_2437 = (g_heff_2ecompile_2eerase_2eeraseProgram(v_t_2436));
    V v_t_2438 = (g_heff_2ecompile_2elower_2ecErased(v_roots_2435, v_t_2437));
    V v_t_2439 = (g_heff_2ecompile_2eemitc_2echeckOut(v_x_2433, v_exports_2434, v_t_2438));
    return ({ V a_0 = v_outPath_244; V b_1 = NTAG(TAG_False); V a_2 = v_t_2439; V a_3 = v_z_247; V a_4 = v_z_248; V r_ = (g_heff_2ebuild_2ecommands_2ecompileJsOut_24s1088149016x1550968084(a_0, b_1, a_2, a_3, a_4)); heff_drop(b_1); r_; });
  }
  case TAG_Just: {
    return (g_heff_2ebuild_2ecommands_2ecompileFoundC_24s1111014622x266173959(v_bi_240, v_file_242, v_name_243, v_outPath_244, v_x_2433, v_done_245, v_c_2419, v_x_2431, v_z_247, v_z_248));
  }
  default: return heff_nomatch(v_name_243);
  }
}
V g_heff_2ebuild_2ecommands_2ecompileLastC_24s1631811027x526216914_lam2(V self, V *args) {
  V v_x_2431 = args[0];
  V v_z_247 = heff_env(self)[0];
  V v_name_243 = heff_env(self)[1];
  V v_c_2419 = heff_env(self)[2];
  V v_outPath_244 = heff_env(self)[3];
  V v_z_248 = heff_env(self)[4];
  V v_bi_240 = heff_env(self)[5];
  V v_file_242 = heff_env(self)[6];
  V v_done_245 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_c_2432 = ((V)&g_heff_2ebuild_2ecommands_2ereadRuntimeC_24s2075524515x1767608914_clo);
  V f_ = v_c_2432;
  heff_room[0] = heff_dup(v_z_247);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ecompileLastC_24s1631811027x526216914_lam3, 1, 9, (V[]){v_name_243, v_c_2419, v_outPath_244, v_z_247, v_z_248, v_bi_240, v_file_242, v_done_245, v_x_2431});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ediagCount_24s1170581875x2081974925_str0, 2, ": ");
V g_heff_2ebuild_2ecommands_2ediagCount_24s1170581875x2081974925_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ediagCount_24s1170581875x2081974925_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ediagCount_24s1170581875x2081974925_lam0, 2, 0};
V g_heff_2ebuild_2ecommands_2ediagCount_24s1170581875x2081974925_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ediagCount_24s1170581875x2081974925_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ediagCount_24s1170581875x2081974925_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ediagCount_24s1170581875x2081974925_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ediagCount_24s1170581875x2081974925_entry, 1, 0};

V g_heff_2ebuild_2ecommands_2ediagCount_24s1170581875x2081974925(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return ((V)&g_heff_2ebuild_2ecommands_2ediagCount_24s1170581875x2081974925_lam0_clo);
  }
  case TAG_Cons: {
    V v_c_243 = heff_field(v_x1_240, 0);
    V v_rest_244 = heff_field(v_x1_240, 1);
    V v_t_245 = (g_list_2emap_24s370939663x1496042695(((V)&g_heff_2ebuild_2ecommands_2ediagCount_24s1170581875x2081974925_str0), heff_dup(heff_rfield(v_c_243, 6))));
    return heff_clo_n(g_heff_2ebuild_2ecommands_2ediagCount_24s1170581875x2081974925_lam1, 2, 3, (V[]){heff_dup(v_c_243), v_t_245, heff_dup(v_rest_244)});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2ecommands_2ediagCount_24s1170581875x2081974925_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2ediagCount_24s1170581875x2081974925(a0); heff_drop(a0); return r;
}
V g_heff_2ebuild_2ecommands_2ediagCount_24s1170581875x2081974925_lam0(V self, V *args) {
  V v_hd_241 = args[0];
  V v_k_242 = args[1];
  heff_drop(v_hd_241);
  V f_ = v_k_242;
  args[0] = MK_INT(0LL);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ediagCount_24s1170581875x2081974925_lam3(V self, V *args) {
  V v_x_2410 = args[0];
  V v_c_243 = heff_env(self)[0];
  V v_k_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2411 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V b_2 = heff_get_n(v_c_243, 6, 13); V r_ = (g_list_2efoldl_24f1046331721x1909432377(a_0, a_1, b_2)); heff_drop(b_2); r_; });
  V v_x_2412 = heff_intAdd(v_t_2411, v_x_2410);
  V f_ = v_k_247;
  args[0] = v_x_2412;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ediagCount_24s1170581875x2081974925_lam2(V self, V *args) {
  V v_x_248 = args[0];
  V v_rest_244 = heff_env(self)[0];
  V v_hd_246 = heff_env(self)[1];
  V v_c_243 = heff_env(self)[2];
  V v_k_247 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_248);
  V v_c_249 = ({ V a_0 = v_rest_244; V r_ = (g_heff_2ebuild_2ecommands_2ediagCount_24s1170581875x2081974925(a_0)); heff_drop(v_rest_244); r_; });
  V f_ = v_c_249;
  heff_room[0] = v_hd_246;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ediagCount_24s1170581875x2081974925_lam3, 1, 2, (V[]){v_c_243, v_k_247});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ediagCount_24s1170581875x2081974925_lam1(V self, V *args) {
  V v_hd_246 = args[0];
  V v_k_247 = args[1];
  V v_c_243 = heff_env(self)[0];
  V v_t_245 = heff_env(self)[1];
  V v_rest_244 = heff_env(self)[2];
  heff_clo_take(self, 3);
  return (g_heff_2ebuild_2ecommands_2eprintErrs_24s1290182366x1682594351(heff_dup(heff_rfield(v_c_243, 0)), v_t_245, MK_INT(0LL), heff_dup(v_hd_246), heff_clo_n(g_heff_2ebuild_2ecommands_2ediagCount_24s1170581875x2081974925_lam2, 1, 4, (V[]){v_rest_244, v_hd_246, v_c_243, v_k_247})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2etestLoaded_24s600885671x1807731663_str0, 4, "heff");
V g_heff_2ebuild_2ecommands_2etestLoaded_24s600885671x1807731663_lam0(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestLoaded_24s600885671x1807731663_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2etestLoaded_24s600885671x1807731663_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2etestLoaded_24s600885671x1807731663_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2etestLoaded_24s600885671x1807731663_entry, 6, 0};

V g_heff_2ebuild_2ecommands_2etestLoaded_24s600885671x1807731663(V v_seed_240, V v_f_241, V v_x3_242, V v_l_243, V v_z_244, V v_z_245) {
top: ;
  if ((heff_dup(v_x3_242) == NTAG(TAG_True))) {
    heff_drop(v_seed_240);
    V v_c_246 = (g_heff_2ebuild_2esession_2ecachedAcc_24s1731440598x239873598(heff_dup(v_l_243)));
    return heff_tail(v_c_246, 2, (V[]){heff_dup(v_z_244), heff_clo_n(g_heff_2ebuild_2ecommands_2etestLoaded_24s600885671x1807731663_lam0, 1, 4, (V[]){v_l_243, v_f_241, v_z_244, v_z_245})});
  } else {
    return (g_heff_2ebuild_2ecommands_2eprintErrs_24s1290182366x1682594351(((V)&g_heff_2ebuild_2ecommands_2etestLoaded_24s600885671x1807731663_str0), heff_dup(heff_rfield(v_l_243, 1)), MK_INT(0LL), heff_dup(v_z_244), heff_clo_n(g_heff_2ebuild_2ecommands_2etestLoaded_24s600885671x1807731663_lam1, 1, 5, (V[]){v_l_243, v_z_244, v_seed_240, v_f_241, v_z_245})));
  }
}
V g_heff_2ebuild_2ecommands_2etestLoaded_24s600885671x1807731663_entry(V self, V *a) {
  (void)self;
  V a2 = a[2]; V r = g_heff_2ebuild_2ecommands_2etestLoaded_24s600885671x1807731663(a[0], a[1], a2, a[3], a[4], a[5]); heff_drop(a2); return r;
}
V g_heff_2ebuild_2ecommands_2etestLoaded_24s600885671x1807731663_lam0(V self, V *args) {
  V v_x_247 = args[0];
  V v_l_243 = heff_env(self)[0];
  V v_f_241 = heff_env(self)[1];
  V v_z_244 = heff_env(self)[2];
  V v_z_245 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_248 = heff_get_n(v_l_243, 1, 5);
  V v_t_2411;
  switch (heff_tag_of(v_t_248)) {
  case TAG_Nil: {
    v_t_2411 = ({ V b_0 = heff_get_n(v_x_247, 0, 2); V r_ = (g_list_2eany_24s1996724342x1838336560(b_0)); heff_drop(b_0); r_; });
    break;
  }
  case TAG_Cons: {
    heff_take_n(v_t_248, 0ULL, 2);
    heff_drop_rec(v_x_247, 2);
    v_t_2411 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_t_248);
  }
  return ({ V a_0 = v_f_241; V a_1 = v_t_2411; V a_2 = v_z_244; V a_3 = v_z_245; V r_ = (g_heff_2ebuild_2ecommands_2etestExpecting_24s1422729883x52088269(a_0, a_1, a_2, a_3)); heff_drop(v_t_2411); r_; });
}
V g_heff_2ebuild_2ecommands_2etestLoaded_24s600885671x1807731663_lam2(V self, V *args) {
  V v_x_2414 = args[0];
  V v_seed_240 = heff_env(self)[0];
  V v_f_241 = heff_env(self)[1];
  V v_l_243 = heff_env(self)[2];
  V v_z_244 = heff_env(self)[3];
  V v_z_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  return ({ V a_0 = v_seed_240; V a_1 = v_f_241; V a_2 = heff_get_n(v_l_243, 1, 5); V b_3 = heff_get_n(v_x_2414, 0, 2); V a_4 = v_z_244; V a_5 = v_z_245; V r_ = (g_heff_2ebuild_2ecommands_2etestOneC_24s779417995x2124390546(a_0, a_1, a_2, b_3, a_4, a_5)); heff_drop(b_3); r_; });
}
V g_heff_2ebuild_2ecommands_2etestLoaded_24s600885671x1807731663_lam1(V self, V *args) {
  V v_x_2412 = args[0];
  V v_l_243 = heff_env(self)[0];
  V v_z_244 = heff_env(self)[1];
  V v_seed_240 = heff_env(self)[2];
  V v_f_241 = heff_env(self)[3];
  V v_z_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2412);
  V v_c_2413 = (g_heff_2ebuild_2esession_2ecachedAcc_24s1731440598x239873598(heff_dup(v_l_243)));
  V f_ = v_c_2413;
  heff_room[0] = heff_dup(v_z_244);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2etestLoaded_24s600885671x1807731663_lam2, 1, 5, (V[]){v_seed_240, v_f_241, v_l_243, v_z_244, v_z_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ereadProviders_24s1903513967x586334405_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ereadProviders_24s1903513967x586334405_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ereadProviders_24s1903513967x586334405_lam0, 2, 0};
V g_heff_2ebuild_2ecommands_2ereadProviders_24s1903513967x586334405_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ereadProviders_24s1903513967x586334405_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ereadProviders_24s1903513967x586334405_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ereadProviders_24s1903513967x586334405_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ereadProviders_24s1903513967x586334405_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2ereadProviders_24s1903513967x586334405(V v_sources_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return ((V)&g_heff_2ebuild_2ecommands_2ereadProviders_24s1903513967x586334405_lam0_clo);
  }
  case TAG_Cons: {
    V v_m_244 = heff_field(v_x2_241, 0);
    V v_rest_245 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_c_246 = (g_heff_2ebuild_2ecommands_2ereadProviderAt_24s78037021x1150470520(v_sources_240, v_m_244));
    return heff_clo_n(g_heff_2ebuild_2ecommands_2ereadProviders_24s1903513967x586334405_lam1, 2, 3, (V[]){v_c_246, heff_dup(v_sources_240), v_rest_245});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ebuild_2ecommands_2ereadProviders_24s1903513967x586334405_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2ereadProviders_24s1903513967x586334405(a0, a[1]); heff_drop(a0); return r;
}
V g_heff_2ebuild_2ecommands_2ereadProviders_24s1903513967x586334405_lam0(V self, V *args) {
  V v_hd_242 = args[0];
  V v_k_243 = args[1];
  heff_drop(v_hd_242);
  V f_ = v_k_243;
  args[0] = NTAG(TAG_Nil);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ereadProviders_24s1903513967x586334405_lam3(V self, V *args) {
  V v_x_2411 = args[0];
  V v_x_249 = heff_env(self)[0];
  V v_k_248 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2413;
  switch (heff_tag_of(v_x_249)) {
  case TAG_Nothing: {
    v_t_2413 = v_x_2411;
    break;
  }
  case TAG_Just: {
    V v_pr_2412 = heff_field(v_x_249, 0);
    heff_take_n(v_x_249, 1ULL, 1);
    v_t_2413 = heff_tag_n(TAG_Cons, 2, (V[]){v_pr_2412, v_x_2411});
    break;
  }
  default: heff_nomatch(v_x_249);
  }
  V f_ = v_k_248;
  args[0] = v_t_2413;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2ereadProviders_24s1903513967x586334405_lam2(V self, V *args) {
  V v_x_249 = args[0];
  V v_sources_240 = heff_env(self)[0];
  V v_rest_245 = heff_env(self)[1];
  V v_hd_247 = heff_env(self)[2];
  V v_k_248 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_c_2410 = ({ V a_0 = v_sources_240; V a_1 = v_rest_245; V r_ = (g_heff_2ebuild_2ecommands_2ereadProviders_24s1903513967x586334405(a_0, a_1)); heff_drop(v_sources_240); r_; });
  V f_ = v_c_2410;
  heff_room[0] = v_hd_247;
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ereadProviders_24s1903513967x586334405_lam3, 1, 2, (V[]){v_x_249, v_k_248});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ereadProviders_24s1903513967x586334405_lam1(V self, V *args) {
  V v_hd_247 = args[0];
  V v_k_248 = args[1];
  V v_c_246 = heff_env(self)[0];
  V v_sources_240 = heff_env(self)[1];
  V v_rest_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_c_246;
  args[0] = heff_dup(v_hd_247);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ereadProviders_24s1903513967x586334405_lam2, 1, 4, (V[]){v_sources_240, v_rest_245, v_hd_247, v_k_248});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_str0, 3, "src");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_str1, 16, "checking modules");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_str2, 7, "1 error");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_str3, 7, " errors");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_str4, 25, " in the project's modules");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_str5, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_str6, 15, ": nothing built");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_str7, 5, "heff ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_str8, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_str9, 8, "1 module");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_str10, 8, " modules");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_str11, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_str12, 8, " checked");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_str13, 5, "heff ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_str14, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_str15, 3, "app");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_str16, 30, "reading the programs' build.hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_str17, 7, "1 error");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_str18, 7, " errors");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_str19, 26, " in the programs' build.hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_str20, 2, ": ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_str21, 15, ": nothing built");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_str22, 5, "heff ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_str23, 1, "\012");
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_lam1, 1, 0};
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_lam7(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_lam7_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_lam7, 1, 0};
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_lam9(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_lam9_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_lam9, 1, 0};
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_lam13(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_lam12(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_lam11(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_lam10(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_lam8(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_entry, 5, 0};

V g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056(V v_st_240, V v_cmd_241, V v_t_242, V v_z_243, V v_z_244) {
top: ;
  V v_t_245 = (g_std_2epath_2ejoin(v_st_240, heff_dup(heff_rfield(v_t_242, 0)), ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_str0)));
  V v_t_246 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_245, NTAG(TAG_Nil)});
  V v_c_247 = (g_heff_2ebuild_2ecommands_2ehfFilesGo_24s1962784645x2035712448(v_t_246, NTAG(TAG_Nil)));
  return heff_tail(v_c_247, 2, (V[]){heff_dup(v_z_243), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_lam0, 1, 5, (V[]){v_z_243, v_cmd_241, v_z_244, v_st_240, v_t_242})});
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_lam1(V self, V *args) {
  V v_t_2410 = args[0];
  return v_t_2410;
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_lam5(V self, V *args) {
  V v_x_2429 = args[0];
  V v_z_243 = heff_env(self)[0];
  V v_z_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2429);
  V v_t_2430 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2431 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2430})});
  V v_t_2432 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2431})});
  V v_t_2433 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2432})});
  return (g_co_2eop_24s954557541x749476273(v_t_2433, v_z_243, v_z_244));
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_lam7(V self, V *args) {
  V v_ns_2445 = args[0];
  return v_ns_2445;
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_lam9(V self, V *args) {
  V v_t_2453 = args[0];
  return v_t_2453;
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_lam13(V self, V *args) {
  V v_x_2474 = args[0];
  V v_z_243 = heff_env(self)[0];
  V v_z_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2474);
  V v_t_2475 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2476 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2475})});
  V v_t_2477 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2476})});
  V v_t_2478 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2477})});
  return (g_co_2eop_24s954557541x749476273(v_t_2478, v_z_243, v_z_244));
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_lam12(V self, V *args) {
  V v_x_2462 = args[0];
  V v_x_2460 = heff_env(self)[0];
  V v_cmd_241 = heff_env(self)[1];
  V v_z_243 = heff_env(self)[2];
  V v_z_244 = heff_env(self)[3];
  V v_st_240 = heff_env(self)[4];
  V v_t_242 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_2462);
  if (heff_intLt_c(MK_INT(0LL), heff_dup(heff_rfield(v_x_2460, 1)))) {
    heff_drop(v_st_240);
    heff_drop_rec(v_t_242, 6);
    V v_n_2464 = heff_get_n(v_x_2460, 1, 2);
    V v_t_2466;
    if (heff_intEq_c(heff_dup(v_n_2464), MK_INT(1LL))) {
      heff_drop(v_n_2464);
      v_t_2466 = ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_str17);
    } else {
      v_t_2466 = heff_strAppend(heff_intShow(v_n_2464), ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_str18));
    }
    V v_what_2467 = heff_strAppend(v_t_2466, ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_str19));
    V v_t_2468 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_str20), heff_strAppend(v_what_2467, ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_str21)));
    V v_t_2469 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_str22), heff_strAppend(v_cmd_241, v_t_2468));
    V v_t_2470 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_t_2469, ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_str23)), NTAG(TAG_MkUnit)});
    V v_t_2471 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2470})});
    V v_t_2472 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2471})});
    V v_t_2473 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2472})});
    return (g_co_2eop_24s954557541x749476273(v_t_2473, heff_dup(v_z_243), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_lam13, 1, 2, (V[]){v_z_243, v_z_244})));
  } else {
    heff_drop(v_cmd_241);
    V v_t_2479 = heff_dup(heff_rfield(v_x_2460, 0));
    switch (heff_tag_of(v_t_2479)) {
    case TAG_Nil: {
      heff_drop_rec(v_x_2460, 2);
      heff_drop(v_z_243);
      heff_drop(v_st_240);
      heff_drop_rec(v_t_242, 6);
      V f_ = v_z_244;
      args[0] = NTAG(TAG_MkUnit);
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    case TAG_Cons: {
      heff_take_n(v_t_2479, 0ULL, 2);
      return (g_heff_2ebuild_2ecommands_2ebuildPrograms_24s1028981633x1628017123(v_st_240, v_t_242, heff_get_n(v_x_2460, 0, 2), v_z_243, v_z_244));
    }
    default: return heff_nomatch(v_t_2479);
    }
  }
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_lam11(V self, V *args) {
  V v_x_2460 = args[0];
  V v_x_2455 = heff_env(self)[0];
  V v_z_243 = heff_env(self)[1];
  V v_cmd_241 = heff_env(self)[2];
  V v_z_244 = heff_env(self)[3];
  V v_st_240 = heff_env(self)[4];
  V v_t_242 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2461 = heff_tag_n(TAG_End, 2, (V[]){v_x_2455, NTAG(TAG_MkUnit)});
  return (g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InL, 1, (V[]){v_t_2461}), heff_dup(v_z_243), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_lam12, 1, 6, (V[]){v_x_2460, v_cmd_241, v_z_243, v_z_244, v_st_240, v_t_242})));
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_lam10(V self, V *args) {
  V v_x_2455 = args[0];
  V v_x_2449 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_t_242 = heff_env(self)[2];
  V v_z_243 = heff_env(self)[3];
  V v_cmd_241 = heff_env(self)[4];
  V v_z_244 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2456 = heff_rec_n(2, shape_apps__bad, (V[]){NTAG(TAG_Nil), MK_INT(0LL)});
  V v_t_2458;
  switch (heff_tag_of(v_x_2449)) {
  case TAG_Nothing: {
    v_t_2458 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_x_2457 = heff_field(v_x_2449, 0);
    heff_take_n(v_x_2449, 1ULL, 1);
    v_t_2458 = v_x_2457;
    break;
  }
  default: heff_nomatch(v_x_2449);
  }
  V v_c_2459 = (g_heff_2ebuild_2ecommands_2eappsIn_24s1533067604x1981180975(v_st_240, heff_dup(v_t_242), heff_dup(v_x_2455), v_t_2456, v_t_2458));
  V f_ = v_c_2459;
  heff_room[0] = heff_dup(v_z_243);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_lam11, 1, 6, (V[]){v_x_2455, v_z_243, v_cmd_241, v_z_244, v_st_240, v_t_242});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_lam8(V self, V *args) {
  V v_x_2449 = args[0];
  V v_z_243 = heff_env(self)[0];
  V v_st_240 = heff_env(self)[1];
  V v_t_242 = heff_env(self)[2];
  V v_cmd_241 = heff_env(self)[3];
  V v_z_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2451;
  switch (heff_tag_of(v_x_2449)) {
  case TAG_Nothing: {
    v_t_2451 = NTAG(TAG_Nil);
    break;
  }
  case TAG_Just: {
    V v_x_2450 = heff_dup(heff_field(v_x_2449, 0));
    v_t_2451 = v_x_2450;
    break;
  }
  default: heff_nomatch(v_x_2449);
  }
  V v_total_2452 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_t_2451; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_t_2451); r_; });
  V v_t_2454 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){heff_dup(g_std_2eprogress_2eroot_get()), ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_str16), v_total_2452, ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_lam9_clo)})});
  return (g_co_2eop_24s954557541x749476273(v_t_2454, heff_dup(v_z_243), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_lam10, 1, 6, (V[]){v_x_2449, v_st_240, v_t_242, v_z_243, v_cmd_241, v_z_244})));
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_lam6(V self, V *args) {
  V v_x_2443 = args[0];
  V v_st_240 = heff_env(self)[0];
  V v_t_242 = heff_env(self)[1];
  V v_z_243 = heff_env(self)[2];
  V v_cmd_241 = heff_env(self)[3];
  V v_z_244 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2443);
  V v_path_2444 = (g_std_2epath_2ejoin(v_st_240, heff_dup(heff_rfield(v_t_242, 0)), ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_str15)));
  V v_t_2446 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadDir, 2, (V[]){v_path_2444, ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_lam7_clo)})});
  V v_t_2447 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2446})});
  V v_t_2448 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2447})});
  return (g_co_2eop_24s954557541x749476273(v_t_2448, heff_dup(v_z_243), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_lam8, 1, 5, (V[]){v_z_243, v_st_240, v_t_242, v_cmd_241, v_z_244})));
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_lam4(V self, V *args) {
  V v_x_2417 = args[0];
  V v_x_2415 = heff_env(self)[0];
  V v_cmd_241 = heff_env(self)[1];
  V v_z_243 = heff_env(self)[2];
  V v_z_244 = heff_env(self)[3];
  V v_st_240 = heff_env(self)[4];
  V v_t_242 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_2417);
  if (heff_intLt_c(MK_INT(0LL), heff_dup(heff_rfield(v_x_2415, 1)))) {
    heff_drop(v_st_240);
    heff_drop_rec(v_t_242, 6);
    V v_n_2419 = heff_get_n(v_x_2415, 1, 2);
    V v_t_2421;
    if (heff_intEq_c(heff_dup(v_n_2419), MK_INT(1LL))) {
      heff_drop(v_n_2419);
      v_t_2421 = ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_str2);
    } else {
      v_t_2421 = heff_strAppend(heff_intShow(v_n_2419), ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_str3));
    }
    V v_what_2422 = heff_strAppend(v_t_2421, ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_str4));
    V v_t_2423 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_str5), heff_strAppend(v_what_2422, ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_str6)));
    V v_t_2424 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_str7), heff_strAppend(v_cmd_241, v_t_2423));
    V v_t_2425 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_t_2424, ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_str8)), NTAG(TAG_MkUnit)});
    V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2425})});
    V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
    V v_t_2428 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
    return (g_co_2eop_24s954557541x749476273(v_t_2428, heff_dup(v_z_243), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_lam5, 1, 2, (V[]){v_z_243, v_z_244})));
  } else {
    V v_n_2434 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V b_2 = heff_get_n(v_x_2415, 0, 2); V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, b_2)); heff_drop(b_2); r_; });
    V v_t_2436;
    if (heff_intEq_c(heff_dup(v_n_2434), MK_INT(1LL))) {
      heff_drop(v_n_2434);
      v_t_2436 = ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_str9);
    } else {
      v_t_2436 = heff_strAppend(heff_intShow(v_n_2434), ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_str10));
    }
    V v_t_2437 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_str11), heff_strAppend(v_t_2436, ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_str12)));
    V v_str_2438 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_str13), heff_strAppend(heff_dup(v_cmd_241), v_t_2437));
    V v_t_2439 = heff_tag_n(TAG_Write, 2, (V[]){heff_strAppend(v_str_2438, ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_str14)), NTAG(TAG_MkUnit)});
    V v_t_2440 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2439})});
    V v_t_2441 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2440})});
    V v_t_2442 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2441})});
    return (g_co_2eop_24s954557541x749476273(v_t_2442, heff_dup(v_z_243), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_lam6, 1, 5, (V[]){v_st_240, v_t_242, v_z_243, v_cmd_241, v_z_244})));
  }
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_lam3(V self, V *args) {
  V v_x_2415 = args[0];
  V v_x_2412 = heff_env(self)[0];
  V v_z_243 = heff_env(self)[1];
  V v_cmd_241 = heff_env(self)[2];
  V v_z_244 = heff_env(self)[3];
  V v_st_240 = heff_env(self)[4];
  V v_t_242 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2416 = heff_tag_n(TAG_End, 2, (V[]){v_x_2412, NTAG(TAG_MkUnit)});
  return (g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InL, 1, (V[]){v_t_2416}), heff_dup(v_z_243), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_lam4, 1, 6, (V[]){v_x_2415, v_cmd_241, v_z_243, v_z_244, v_st_240, v_t_242})));
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_lam2(V self, V *args) {
  V v_x_2412 = args[0];
  V v_x_248 = heff_env(self)[0];
  V v_z_243 = heff_env(self)[1];
  V v_cmd_241 = heff_env(self)[2];
  V v_z_244 = heff_env(self)[3];
  V v_st_240 = heff_env(self)[4];
  V v_t_242 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2413 = heff_rec_n(2, shape_seen__errors, (V[]){NTAG(TAG_Nil), MK_INT(0LL)});
  V v_c_2414 = ({ V a_0 = heff_dup(v_x_2412); V a_1 = v_t_2413; V a_2 = v_x_248; V r_ = (g_heff_2ebuild_2ecommands_2echeckModules_24s1149060863x1991365033(a_0, a_1, a_2)); heff_drop(v_x_248); r_; });
  V f_ = v_c_2414;
  heff_room[0] = heff_dup(v_z_243);
  heff_room[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_lam3, 1, 6, (V[]){v_x_2412, v_z_243, v_cmd_241, v_z_244, v_st_240, v_t_242});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_lam0(V self, V *args) {
  V v_x_248 = args[0];
  V v_z_243 = heff_env(self)[0];
  V v_cmd_241 = heff_env(self)[1];
  V v_z_244 = heff_env(self)[2];
  V v_st_240 = heff_env(self)[3];
  V v_t_242 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_total_249 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_x_248));
  V v_t_2411 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Start, 4, (V[]){heff_dup(g_std_2eprogress_2eroot_get()), ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_str1), v_total_249, ((V)&g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_lam1_clo)})});
  return (g_co_2eop_24s954557541x749476273(v_t_2411, heff_dup(v_z_243), heff_clo_n(g_heff_2ebuild_2ecommands_2ebuildProject_24s1694156958x1223400056_lam2, 1, 6, (V[]){v_x_248, v_z_243, v_cmd_241, v_z_244, v_st_240, v_t_242})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2einstallCmd_24s659320162x1710670004_str0, 5, "win32");
HEFF_LIT(g_heff_2ebuild_2ecommands_2einstallCmd_24s659320162x1710670004_str1, 10, "package.hf");
HEFF_LIT(g_heff_2ebuild_2ecommands_2einstallCmd_24s659320162x1710670004_str2, 3, "bin");
HEFF_LIT(g_heff_2ebuild_2ecommands_2einstallCmd_24s659320162x1710670004_str3, 9, "installed");
HEFF_LIT(g_heff_2ebuild_2ecommands_2einstallCmd_24s659320162x1710670004_str4, 3, "-O2");
HEFF_LIT(g_heff_2ebuild_2ecommands_2einstallCmd_24s659320162x1710670004_str5, 31, "heff install: no package.hf in ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2einstallCmd_24s659320162x1710670004_str6, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2einstallCmd_24s659320162x1710670004_str7, 7, "install");
HEFF_LIT(g_heff_2ebuild_2ecommands_2einstallCmd_24s659320162x1710670004_str8, 29, "heff install: no programs in ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2einstallCmd_24s659320162x1710670004_str9, 41, ": app/X/ with a build.hf is the program X");
HEFF_LIT(g_heff_2ebuild_2ecommands_2einstallCmd_24s659320162x1710670004_str10, 1, "\012");
V g_heff_2ebuild_2ecommands_2einstallCmd_24s659320162x1710670004_lam0(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2einstallCmd_24s659320162x1710670004_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2einstallCmd_24s659320162x1710670004_lam0, 1, 0};
V g_heff_2ebuild_2ecommands_2einstallCmd_24s659320162x1710670004_lam3(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2einstallCmd_24s659320162x1710670004_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2einstallCmd_24s659320162x1710670004_lam3, 1, 0};
V g_heff_2ebuild_2ecommands_2einstallCmd_24s659320162x1710670004_lam5(V self, V *args);
V g_heff_2ebuild_2ecommands_2einstallCmd_24s659320162x1710670004_lam7(V self, V *args);
V g_heff_2ebuild_2ecommands_2einstallCmd_24s659320162x1710670004_lam6(V self, V *args);
V g_heff_2ebuild_2ecommands_2einstallCmd_24s659320162x1710670004_lam4(V self, V *args);
V g_heff_2ebuild_2ecommands_2einstallCmd_24s659320162x1710670004_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2einstallCmd_24s659320162x1710670004_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2einstallCmd_24s659320162x1710670004_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2einstallCmd_24s659320162x1710670004_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2einstallCmd_24s659320162x1710670004(V v_dir_240, V v_hd_241, V v_k_242) {
top: ;
  V v_t_244 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Platform, 1, (V[]){((V)&g_heff_2ebuild_2ecommands_2einstallCmd_24s659320162x1710670004_lam0_clo)})});
  V v_t_245 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_244})});
  V v_t_246 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_245})});
  HEFF_LAST return g_co_2eop_24s954557541x749476273(heff_tag_n(TAG_InR, 1, (V[]){v_t_246}), heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2ecommands_2einstallCmd_24s659320162x1710670004_lam1, 1, 3, (V[]){v_hd_241, v_dir_240, v_k_242}));
}
V g_heff_2ebuild_2ecommands_2einstallCmd_24s659320162x1710670004_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2einstallCmd_24s659320162x1710670004(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2ecommands_2einstallCmd_24s659320162x1710670004_lam0(V self, V *args) {
  V v_s_243 = args[0];
  return v_s_243;
}
V g_heff_2ebuild_2ecommands_2einstallCmd_24s659320162x1710670004_lam3(V self, V *args) {
  V v_t_2412 = args[0];
  return v_t_2412;
}
V g_heff_2ebuild_2ecommands_2einstallCmd_24s659320162x1710670004_lam5(V self, V *args) {
  V v_x_2424 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_k_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2424);
  V v_t_2425 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2426 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2425})});
  V v_t_2427 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2426})});
  V v_t_2428 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2427})});
  return (g_co_2eop_24s954557541x749476273(v_t_2428, v_hd_241, v_k_242));
}
V g_heff_2ebuild_2ecommands_2einstallCmd_24s659320162x1710670004_lam7(V self, V *args) {
  V v_x_2447 = args[0];
  V v_hd_2440 = heff_env(self)[0];
  V v_k_2441 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2447);
  V v_t_2448 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2449 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2448})});
  V v_t_2450 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2449})});
  V v_t_2451 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2450})});
  return (g_co_2eop_24s954557541x749476273(v_t_2451, v_hd_2440, v_k_2441));
}
V g_heff_2ebuild_2ecommands_2einstallCmd_24s659320162x1710670004_lam6(V self, V *args) {
  V v_hd_2440 = args[0];
  V v_k_2441 = args[1];
  V v_dir_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2442 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2einstallCmd_24s659320162x1710670004_str8), heff_strAppend(v_dir_240, ((V)&g_heff_2ebuild_2ecommands_2einstallCmd_24s659320162x1710670004_str9)));
  V v_t_2443 = heff_tag_n(TAG_WriteErr, 2, (V[]){heff_strAppend(v_t_2442, ((V)&g_heff_2ebuild_2ecommands_2einstallCmd_24s659320162x1710670004_str10)), NTAG(TAG_MkUnit)});
  V v_t_2444 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2443})});
  V v_t_2445 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2444})});
  V v_t_2446 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2445})});
  return (g_co_2eop_24s954557541x749476273(v_t_2446, heff_dup(v_hd_2440), heff_clo_n(g_heff_2ebuild_2ecommands_2einstallCmd_24s659320162x1710670004_lam7, 1, 2, (V[]){v_hd_2440, v_k_2441})));
}
V g_heff_2ebuild_2ecommands_2einstallCmd_24s659320162x1710670004_lam4(V self, V *args) {
  V v_x_2416 = args[0];
  V v_st_249 = heff_env(self)[0];
  V v_x_2410 = heff_env(self)[1];
  V v_dir_240 = heff_env(self)[2];
  V v_hd_241 = heff_env(self)[3];
  V v_k_242 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2417 = (g_std_2epath_2ejoin(v_st_249, heff_dup(v_x_2410), ((V)&g_heff_2ebuild_2ecommands_2einstallCmd_24s659320162x1710670004_str2)));
  V v_x_2418 = heff_rec_n(6, shape_root__bin__said__pages__shipTo__opt, (V[]){heff_dup(v_dir_240), v_t_2417, ((V)&g_heff_2ebuild_2ecommands_2einstallCmd_24s659320162x1710670004_str3), NTAG(TAG_False), heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_x_2410)}), ((V)&g_heff_2ebuild_2ecommands_2einstallCmd_24s659320162x1710670004_str4)});
  switch (heff_tag_of(v_x_2416)) {
  case TAG_Nothing: {
    heff_drop(v_st_249);
    heff_drop(v_x_2410);
    heff_drop_rec(v_x_2418, 6);
    V v_t_2419 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2einstallCmd_24s659320162x1710670004_str5), v_dir_240), ((V)&g_heff_2ebuild_2ecommands_2einstallCmd_24s659320162x1710670004_str6));
    V v_t_2420 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2419, NTAG(TAG_MkUnit)});
    V v_t_2421 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2420})});
    V v_t_2422 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
    V v_t_2423 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
    return (g_co_2eop_24s954557541x749476273(v_t_2423, heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2ecommands_2einstallCmd_24s659320162x1710670004_lam5, 1, 2, (V[]){v_hd_241, v_k_242})));
  }
  case TAG_Just: {
    V v_t_2439;
    switch (heff_tag_of(v_x_2416)) {
    case TAG_Nothing: {
      heff_drop(v_x_2410);
      v_t_2439 = heff_tr(heff_call(((V)&g_heff_2ebuild_2ecommands_2eonPathHint_24s397492699x957798544_clo), 2, (V[]){heff_dup(v_st_249), heff_dup(heff_rfield(v_x_2418, 1))}));
      break;
    }
    case TAG_Just: {
      V v_text_2430 = heff_field(v_x_2416, 0);
      V v_ru_24x_2416_24Just = heff_take_reuse_n(v_x_2416, 1ULL, 1);
      V v_x1_2431 = (g_heff_2ebuild_2eproject_2epackageLit(v_text_2430));
      V v_x1_2434;
      switch (heff_tag_of(v_x1_2431)) {
      case TAG_Left: {
        V v_p_2432 = heff_field(v_x1_2431, 0);
        heff_take_n(v_x1_2431, 1ULL, 1);
        v_x1_2434 = heff_tag_at_n(v_ru_24x_2416_24Just, TAG_Left, 1, (V[]){v_p_2432});
        break;
      }
      case TAG_Right: {
        V v_x_2433 = heff_field(v_x1_2431, 0);
        heff_take_n(v_x1_2431, 1ULL, 1);
        heff_drop_cell(v_ru_24x_2416_24Just, 1);
        v_x1_2434 = ({ V a_0 = v_x_2433; V r_ = (g_heff_2ebuild_2eproject_2epackageOf(a_0)); heff_drop(v_x_2433); r_; });
        break;
      }
      default: heff_nomatch(v_x1_2431);
      }
      switch (heff_tag_of(v_x1_2434)) {
      case TAG_Left: {
        heff_take_n(v_x1_2434, 0ULL, 1);
        heff_drop(v_x_2410);
        v_t_2439 = heff_tr(heff_call(((V)&g_heff_2ebuild_2ecommands_2eonPathHint_24s397492699x957798544_clo), 2, (V[]){heff_dup(v_st_249), heff_dup(heff_rfield(v_x_2418, 1))}));
        break;
      }
      case TAG_Right: {
        V v_pk_2436 = heff_field(v_x1_2434, 0);
        heff_take_n(v_x1_2434, 1ULL, 1);
        if (heff_strEq_c(heff_get_n(v_pk_2436, 0, 4), heff_dup(g_heff_2ebuild_2eproject_2eheffModule_get()))) {
          V v_t_2438 = heff_tr(heff_call(((V)&g_heff_2ebuild_2ecommands_2eonPathHint_24s397492699x957798544_clo), 2, (V[]){heff_dup(v_st_249), heff_dup(heff_rfield(v_x_2418, 1))}));
          v_t_2439 = heff_tr(heff_call(((V)&g_heff_2ebuild_2ecommands_2esourceSaved_24s1653971658x1305473599_clo), 5, (V[]){heff_dup(v_st_249), heff_dup(v_x_2418), v_x_2410, heff_dup(v_dir_240), v_t_2438}));
        } else {
          heff_drop(v_x_2410);
          v_t_2439 = heff_tr(heff_call(((V)&g_heff_2ebuild_2ecommands_2eonPathHint_24s397492699x957798544_clo), 2, (V[]){heff_dup(v_st_249), heff_dup(heff_rfield(v_x_2418, 1))}));
        }
        break;
      }
      default: heff_nomatch(v_x1_2434);
      }
      break;
    }
    default: heff_nomatch(v_x_2416);
    }
    return (g_heff_2ebuild_2ecommands_2ebuildProject_24s1554083097x960565319(v_st_249, ((V)&g_heff_2ebuild_2ecommands_2einstallCmd_24s659320162x1710670004_str7), v_x_2418, heff_clo_n(g_heff_2ebuild_2ecommands_2einstallCmd_24s659320162x1710670004_lam6, 2, 1, (V[]){v_dir_240}), v_t_2439, v_hd_241, v_k_242));
  }
  default: return heff_nomatch(v_x_2416);
  }
}
V g_heff_2ebuild_2ecommands_2einstallCmd_24s659320162x1710670004_lam2(V self, V *args) {
  V v_x_2410 = args[0];
  V v_st_249 = heff_env(self)[0];
  V v_dir_240 = heff_env(self)[1];
  V v_hd_241 = heff_env(self)[2];
  V v_k_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_path_2411 = (g_std_2epath_2ejoin(v_st_249, heff_dup(v_dir_240), ((V)&g_heff_2ebuild_2ecommands_2einstallCmd_24s659320162x1710670004_str1)));
  V v_t_2413 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){v_path_2411, ((V)&g_heff_2ebuild_2ecommands_2einstallCmd_24s659320162x1710670004_lam3_clo)})});
  V v_t_2414 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
  V v_t_2415 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2414})});
  return (g_co_2eop_24s954557541x749476273(v_t_2415, heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2ecommands_2einstallCmd_24s659320162x1710670004_lam4, 1, 5, (V[]){v_st_249, v_x_2410, v_dir_240, v_hd_241, v_k_242})));
}
V g_heff_2ebuild_2ecommands_2einstallCmd_24s659320162x1710670004_lam1(V self, V *args) {
  V v_x_247 = args[0];
  V v_hd_241 = heff_env(self)[0];
  V v_dir_240 = heff_env(self)[1];
  V v_k_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_st_249;
  if (heff_strEq_c(v_x_247, ((V)&g_heff_2ebuild_2ecommands_2einstallCmd_24s659320162x1710670004_str0))) {
    v_st_249 = NTAG(TAG_Windows);
  } else {
    v_st_249 = NTAG(TAG_Posix);
  }
  return (g_heff_2ebuild_2ecommands_2eheffHome_24s1023006878x6127580(heff_dup(v_hd_241), heff_clo_n(g_heff_2ebuild_2ecommands_2einstallCmd_24s659320162x1710670004_lam2, 1, 4, (V[]){v_st_249, v_dir_240, v_hd_241, v_k_242})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eversionCmd_24s1875053145x1484821650_str0, 14, "heff version: ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eversionCmd_24s1875053145x1484821650_str1, 1, "\012");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eversionCmd_24s1875053145x1484821650_str2, 1, "\012");
V g_heff_2ebuild_2ecommands_2eversionCmd_24s1875053145x1484821650_lam1(V self, V *args); static Clo g_heff_2ebuild_2ecommands_2eversionCmd_24s1875053145x1484821650_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eversionCmd_24s1875053145x1484821650_lam1, 1, 0};
V g_heff_2ebuild_2ecommands_2eversionCmd_24s1875053145x1484821650_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2eversionCmd_24s1875053145x1484821650_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2eversionCmd_24s1875053145x1484821650_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eversionCmd_24s1875053145x1484821650_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eversionCmd_24s1875053145x1484821650_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2eversionCmd_24s1875053145x1484821650(V v_hd_240, V v_k_241) {
top: ;
  HEFF_LAST return g_heff_2ebuild_2ecommands_2eownPackage_24s759818713x2101508697(heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2ecommands_2eversionCmd_24s1875053145x1484821650_lam0, 1, 2, (V[]){v_hd_240, v_k_241}));
}
V g_heff_2ebuild_2ecommands_2eversionCmd_24s1875053145x1484821650_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eversionCmd_24s1875053145x1484821650(a[0], a[1]);
}
V g_heff_2ebuild_2ecommands_2eversionCmd_24s1875053145x1484821650_lam1(V self, V *args) {
  V v_t_243 = args[0];
  return v_t_243;
}
V g_heff_2ebuild_2ecommands_2eversionCmd_24s1875053145x1484821650_lam3(V self, V *args) {
  V v_x_2415 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2415);
  V v_t_2416 = heff_tag_n(TAG_Exit, 2, (V[]){MK_INT(1LL), NTAG(TAG_MkUnit)});
  V v_t_2417 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2416})});
  V v_t_2418 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2417})});
  V v_t_2419 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2418})});
  return (g_co_2eop_24s954557541x749476273(v_t_2419, v_hd_240, v_k_241));
}
V g_heff_2ebuild_2ecommands_2eversionCmd_24s1875053145x1484821650_lam2(V self, V *args) {
  V v_x_247 = args[0];
  V v_x_242 = heff_env(self)[0];
  V v_hd_240 = heff_env(self)[1];
  V v_k_241 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_248 = (g_heff_2ebuild_2ecommands_2eversionSaid(v_x_242, v_x_247));
  switch (heff_tag_of(v_t_248)) {
  case TAG_Left: {
    V v_why_249 = heff_field(v_t_248, 0);
    V v_ru_24t_248_24Left = heff_take_reuse_n(v_t_248, 1ULL, 1);
    V v_t_2410 = heff_strAppend(heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eversionCmd_24s1875053145x1484821650_str0), v_why_249), ((V)&g_heff_2ebuild_2ecommands_2eversionCmd_24s1875053145x1484821650_str1));
    V v_t_2411 = heff_tag_n(TAG_WriteErr, 2, (V[]){v_t_2410, NTAG(TAG_MkUnit)});
    V v_t_2412 = heff_tag_at_n(v_ru_24t_248_24Left, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})});
    V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2412})});
    V v_t_2414 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2413})});
    return (g_co_2eop_24s954557541x749476273(v_t_2414, heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2ecommands_2eversionCmd_24s1875053145x1484821650_lam3, 1, 2, (V[]){v_hd_240, v_k_241})));
  }
  case TAG_Right: {
    V v_line_2420 = heff_field(v_t_248, 0);
    V v_ru_24t_248_24Right = heff_take_reuse_n(v_t_248, 1ULL, 1);
    V v_t_2421 = heff_tag_n(TAG_Write, 2, (V[]){heff_strAppend(v_line_2420, ((V)&g_heff_2ebuild_2ecommands_2eversionCmd_24s1875053145x1484821650_str2)), NTAG(TAG_MkUnit)});
    V v_t_2422 = heff_tag_at_n(v_ru_24t_248_24Right, TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2421})});
    V v_t_2423 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2422})});
    V v_t_2424 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2423})});
    return (g_co_2eop_24s954557541x749476273(v_t_2424, v_hd_240, v_k_241));
  }
  default: return heff_nomatch(v_t_248);
  }
}
V g_heff_2ebuild_2ecommands_2eversionCmd_24s1875053145x1484821650_lam0(V self, V *args) {
  V v_x_242 = args[0];
  V v_hd_240 = heff_env(self)[0];
  V v_k_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_244 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_ReadFile, 2, (V[]){heff_dup(v_x_242), ((V)&g_heff_2ebuild_2ecommands_2eversionCmd_24s1875053145x1484821650_lam1_clo)})});
  V v_t_245 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_244})});
  V v_t_246 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_245})});
  return (g_co_2eop_24s954557541x749476273(v_t_246, heff_dup(v_hd_240), heff_clo_n(g_heff_2ebuild_2ecommands_2eversionCmd_24s1875053145x1484821650_lam2, 1, 3, (V[]){v_x_242, v_hd_240, v_k_241})));
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprintAll_24s661059568x2144438338_str0, 2, ": ");
V g_heff_2ebuild_2ecommands_2eprintAll_24s661059568x2144438338_lam0(V self, V *args);
V g_heff_2ebuild_2ecommands_2eprintAll_24s661059568x2144438338_lam3(V self, V *args);
V g_heff_2ebuild_2ecommands_2eprintAll_24s661059568x2144438338_lam2(V self, V *args);
V g_heff_2ebuild_2ecommands_2eprintAll_24s661059568x2144438338_lam1(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eprintAll_24s661059568x2144438338_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eprintAll_24s661059568x2144438338_entry, 2, 0};

V g_heff_2ebuild_2ecommands_2eprintAll_24s661059568x2144438338(V v_x1_240, V v_bad_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_clo_n(g_heff_2ebuild_2ecommands_2eprintAll_24s661059568x2144438338_lam0, 2, 1, (V[]){v_bad_241});
  }
  case TAG_Cons: {
    V v_c_244 = heff_field(v_x1_240, 0);
    V v_rest_245 = heff_field(v_x1_240, 1);
    V v_t_246 = (g_list_2emap_24s152505078x225062837(heff_dup(heff_rfield(v_c_244, 7))));
    V v_c_247 = (g_heff_2ebuild_2ecommands_2eprintDefs_24s2084586815x771131724(heff_dup(v_c_244), v_t_246));
    return heff_clo_n(g_heff_2ebuild_2ecommands_2eprintAll_24s661059568x2144438338_lam1, 2, 4, (V[]){v_c_247, heff_dup(v_c_244), heff_dup(v_rest_245), v_bad_241});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2ecommands_2eprintAll_24s661059568x2144438338_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ebuild_2ecommands_2eprintAll_24s661059568x2144438338(a0, a[1]); heff_drop(a0); return r;
}
V g_heff_2ebuild_2ecommands_2eprintAll_24s661059568x2144438338_lam0(V self, V *args) {
  V v_hd_242 = args[0];
  V v_k_243 = args[1];
  V v_bad_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_242);
  V f_ = v_k_243;
  args[0] = v_bad_241;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eprintAll_24s661059568x2144438338_lam3(V self, V *args) {
  V v_x_2412 = args[0];
  V v_rest_245 = heff_env(self)[0];
  V v_bad_241 = heff_env(self)[1];
  V v_hd_248 = heff_env(self)[2];
  V v_k_249 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2413 = ({ V a_0 = v_rest_245; V a_1 = heff_intAdd(v_bad_241, v_x_2412); V r_ = (g_heff_2ebuild_2ecommands_2eprintAll_24s661059568x2144438338(a_0, a_1)); heff_drop(v_rest_245); r_; });
  V f_ = v_t_2413;
  heff_room[0] = v_hd_248;
  heff_room[1] = v_k_249;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2ebuild_2ecommands_2eprintAll_24s661059568x2144438338_lam2(V self, V *args) {
  V v_x_2410 = args[0];
  V v_c_244 = heff_env(self)[0];
  V v_hd_248 = heff_env(self)[1];
  V v_rest_245 = heff_env(self)[2];
  V v_bad_241 = heff_env(self)[3];
  V v_k_249 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2410);
  V v_t_2411 = (g_list_2emap_24s370939663x1496042695(((V)&g_heff_2ebuild_2ecommands_2eprintAll_24s661059568x2144438338_str0), heff_take_field(v_c_244, 6)));
  return (g_heff_2ebuild_2ecommands_2eprintErrs_24s1290182366x1682594351(heff_get_n(v_c_244, 0, 13), v_t_2411, MK_INT(0LL), heff_dup(v_hd_248), heff_clo_n(g_heff_2ebuild_2ecommands_2eprintAll_24s661059568x2144438338_lam3, 1, 4, (V[]){v_rest_245, v_bad_241, v_hd_248, v_k_249})));
}
V g_heff_2ebuild_2ecommands_2eprintAll_24s661059568x2144438338_lam1(V self, V *args) {
  V v_hd_248 = args[0];
  V v_k_249 = args[1];
  V v_c_247 = heff_env(self)[0];
  V v_c_244 = heff_env(self)[1];
  V v_rest_245 = heff_env(self)[2];
  V v_bad_241 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V f_ = v_c_247;
  args[0] = heff_dup(v_hd_248);
  args[1] = heff_clo_n(g_heff_2ebuild_2ecommands_2eprintAll_24s661059568x2144438338_lam2, 1, 5, (V[]){v_c_244, v_hd_248, v_rest_245, v_bad_241, v_k_249});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprintEvals_24s2126685520x1186208326_str0, 3, " = ");
HEFF_LIT(g_heff_2ebuild_2ecommands_2eprintEvals_24s2126685520x1186208326_str1, 1, "\012");
V g_heff_2ebuild_2ecommands_2eprintEvals_24s2126685520x1186208326_lam1(V self, V *args);
V g_heff_2ebuild_2ecommands_2eprintEvals_24s2126685520x1186208326_lam0(V self, V *args);
Clo g_heff_2ebuild_2ecommands_2eprintEvals_24s2126685520x1186208326_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ebuild_2ecommands_2eprintEvals_24s2126685520x1186208326_entry, 3, 0};

V g_heff_2ebuild_2ecommands_2eprintEvals_24s2126685520x1186208326(V v_x1_240, V v_p_241, V v_p_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_p_241);
    return heff_tail(v_p_242, 1, (V[]){NTAG(TAG_False)});
  }
  case TAG_Cons: {
    V v_d_243 = heff_field(v_x1_240, 0);
    V v_rest_244 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_245 = heff_strAppend(((V)&g_heff_2ebuild_2ecommands_2eprintEvals_24s2126685520x1186208326_str0), heff_dup(heff_rfield(v_d_243, 1)));
    V v_t_246 = heff_strAppend(heff_dup(heff_rfield(v_d_243, 0)), v_t_245);
    V v_t_247 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Write, 2, (V[]){heff_strAppend(v_t_246, ((V)&g_heff_2ebuild_2ecommands_2eprintEvals_24s2126685520x1186208326_str1)), NTAG(TAG_MkUnit)});
    V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_247})});
    V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_248})});
    V v_t_2410 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_249})});
    HEFF_LAST return g_co_2eop_24s954557541x749476273(v_t_2410, heff_dup(v_p_241), heff_clo_n(g_heff_2ebuild_2ecommands_2eprintEvals_24s2126685520x1186208326_lam0, 1, 4, (V[]){v_rest_244, v_p_241, v_d_243, v_p_242}));
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ebuild_2ecommands_2eprintEvals_24s2126685520x1186208326_entry(V self, V *a) {
  (void)self;
  return g_heff_2ebuild_2ecommands_2eprintEvals_24s2126685520x1186208326(a[0], a[1], a[2]);
}
V g_heff_2ebuild_2ecommands_2eprintEvals_24s2126685520x1186208326_lam1(V self, V *args) {
  V v_x_2412 = args[0];
  V v_d_243 = heff_env(self)[0];
  V v_p_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2413 = heff_get_n(v_d_243, 2, 3);
  V v_t_2414;
  if ((heff_dup(v_t_2413) == NTAG(TAG_True))) {
    heff_drop(v_x_2412);
    heff_drop(v_t_2413);
    v_t_2414 = NTAG(TAG_True);
  } else {
    heff_drop(v_t_2413);
    v_t_2414 = v_x_2412;
  }
  V f_ = v_p_242;
  args[0] = v_t_2414;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2ebuild_2ecommands_2eprintEvals_24s2126685520x1186208326_lam0(V self, V *args) {
  V v_x_2411 = args[0];
  V v_rest_244 = heff_env(self)[0];
  V v_p_241 = heff_env(self)[1];
  V v_d_243 = heff_env(self)[2];
  V v_p_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2411);
  return (g_heff_2ebuild_2ecommands_2eprintEvals_24s2126685520x1186208326(v_rest_244, v_p_241, heff_clo_n(g_heff_2ebuild_2ecommands_2eprintEvals_24s2126685520x1186208326_lam1, 1, 2, (V[]){v_d_243, v_p_242})));
}