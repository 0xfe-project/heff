// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_AbsConst 8406
#define TAG_Become 65038
#define TAG_Catch 6517
#define TAG_CloConst 61868
#define TAG_Describe 2650
#define TAG_Escapes 7836
#define TAG_Get 18914
#define TAG_HError 21467
#define TAG_HGlobal 55847
#define TAG_HLocal 25864
#define TAG_HMeta 17321
#define TAG_LNil 57394
#define TAG_LSnoc 32613
#define TAG_MentionsError 719
#define TAG_MkAbs 54862
#define TAG_MkClo 57090
#define TAG_N 306
#define TAG_Nom 25944
#define TAG_PSelf 48502
#define TAG_PVar 52952
#define TAG_Put 28059
#define TAG_SAbandon 23437
#define TAG_SApp 57081
#define TAG_SCode 58360
#define TAG_SCons 58684
#define TAG_SDecode 30927
#define TAG_SFix 61677
#define TAG_SFixed 29756
#define TAG_SFunction 64505
#define TAG_SGlobal 8650
#define TAG_SImplicit 59448
#define TAG_SIs 29577
#define TAG_SLam 1658
#define TAG_SLitBytes 43891
#define TAG_SLitFixed 54374
#define TAG_SLitFloat 3938
#define TAG_SLitFloat32 41499
#define TAG_SLitInt 21439
#define TAG_SLitRune 21707
#define TAG_SLitString 62718
#define TAG_SLocal 28569
#define TAG_SMatch 27203
#define TAG_SMetaApp 2372
#define TAG_SOpaque 44226
#define TAG_SPrim 55533
#define TAG_SPrimArray 2913
#define TAG_SPrimFloat 48642
#define TAG_SPrimInt 22031
#define TAG_SPrimRune 40059
#define TAG_SPrimString 6970
#define TAG_SProj 55716
#define TAG_SRec 7538
#define TAG_SRecord 16932
#define TAG_SSpecialize 52996
#define TAG_SSum 9005
#define TAG_STag 9340
#define TAG_SU 9427
#define TAG_SpApp 44612
#define TAG_SpId 35501
#define TAG_SpProj 62333
#define TAG_SpSpec 18415
#define TAG_Throw 56084
#define TAG_UnequalEls 52956
#define TAG_UnequalNeus 2652
#define TAG_UnequalTys 2248
#define TAG_VCode 11305
#define TAG_VCons 11629
#define TAG_VDecode 24012
#define TAG_VFixed 12623
#define TAG_VFunction 37316
#define TAG_VLam 25505
#define TAG_VNeu 27559
#define TAG_VOpaque 37311
#define TAG_VPrimArray 11892
#define TAG_VPrimFloat 57621
#define TAG_VPrimInt 4244
#define TAG_VPrimRune 12870
#define TAG_VPrimString 23215
#define TAG_VRecord 10017
#define TAG_VSum 32852
#define TAG_VU 9520
#define LBL_bind 9519364
#define LBL_byName 571997869
#define LBL_cod 308210
#define LBL_dom 309180
#define LBL_el 9998
#define LBL_failed 665164648
#define LBL_infos 301706655
#define LBL_keys 9783995
#define LBL_left 9813198
#define LBL_len 316559
#define LBL_malg 9839318
#define LBL_mel 317518
#define LBL_metas 305145640
#define LBL_nextMeta 21843381
#define LBL_poisoned 1215742945
#define LBL_postponed 1495502762
#define LBL_recovered 474271923
#define LBL_ren 322325
#define LBL_ret 322331
#define LBL_right 309870134
#define LBL_selfKey 62480824
#define LBL_shape 310758331
#define LBL_solStx 1050338738
#define LBL_solve 310977625
#define LBL_trace 311979359
#define LBL_ty 10476
#define LBL_values 1123329101
static uint32_t shape_dom__cod__ren[] = {LBL_dom, LBL_cod, LBL_ren};
static uint32_t shape_infos__recovered__poisoned__metas__nextMeta__postponed__trace__selfKey[] = {LBL_infos, LBL_recovered, LBL_poisoned, LBL_metas, LBL_nextMeta, LBL_postponed, LBL_trace, LBL_selfKey};
static uint32_t shape_keys__byName__values[] = {LBL_keys, LBL_byName, LBL_values};
static uint32_t shape_shape__left__right__failed[] = {LBL_shape, LBL_left, LBL_right, LBL_failed};
V g_co_2eop_24s310169282x2049378029(V, V, V, V);
V g_co_2eop_24s310169282x2049378029_entry(V self, V *a);
extern Clo g_co_2eop_24s310169282x2049378029_clo;
V g_co_2eplus_24s973240257x441859337_get(void);
V g_heff_2eelab_2econversion_2ecanon(V);
V g_heff_2eelab_2econversion_2ecanon_entry(V self, V *a);
extern Clo g_heff_2eelab_2econversion_2ecanon_clo;
V g_heff_2eelab_2econversion_2eeqHead(V, V);
V g_heff_2eelab_2econversion_2eeqHead_entry(V self, V *a);
extern Clo g_heff_2eelab_2econversion_2eeqHead_clo;
V g_heff_2eelab_2eeval_2eevalTermF(V, V, V, V, V);
V g_heff_2eelab_2eeval_2eevalTermF_entry(V self, V *a);
extern Clo g_heff_2eelab_2eeval_2eevalTermF_clo;
V g_heff_2eelab_2eeval_2eevaluator_get(void);
V g_heff_2eelab_2eparams_2eemptyShape_get(void);
V g_heff_2eelab_2eunify_2eanyL(V, V);
V g_heff_2eelab_2eunify_2eanyL_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2eanyL_clo;
V g_heff_2eelab_2eunify_2ecatMaybes(V);
V g_heff_2eelab_2eunify_2ecatMaybes_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2ecatMaybes_clo;
V g_heff_2eelab_2eunify_2edistinct(V);
V g_heff_2eelab_2eunify_2edistinct_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2edistinct_clo;
V g_heff_2eelab_2eunify_2eeqPatArgs(V, V);
V g_heff_2eelab_2eunify_2eeqPatArgs_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2eeqPatArgs_clo;
V g_heff_2eelab_2eunify_2elamsU(V, V);
V g_heff_2eelab_2eunify_2elamsU_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2elamsU_clo;
V g_heff_2eelab_2eunify_2emapWithIndexL(V, V, V);
V g_heff_2eelab_2eunify_2emapWithIndexL_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2emapWithIndexL_clo;
V g_heff_2eelab_2eunify_2emapWithIndexL_24s1606268187x1223772876(V, V);
V g_heff_2eelab_2eunify_2emapWithIndexL_24s1606268187x1223772876_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2emapWithIndexL_24s1606268187x1223772876_clo;
V g_heff_2eelab_2eunify_2emapWithIndexL_24s1606268187x1223772876_24dps(V, V, V);
V g_heff_2eelab_2eunify_2emapWithIndexL_24s1606268187x1223772876_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2emapWithIndexL_24s1606268187x1223772876_24dps_clo;
V g_heff_2eelab_2eunify_2emapWithIndexL_24s919594025x2081681853(V, V);
V g_heff_2eelab_2eunify_2emapWithIndexL_24s919594025x2081681853_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2emapWithIndexL_24s919594025x2081681853_clo;
V g_heff_2eelab_2eunify_2emetasK(V);
V g_heff_2eelab_2eunify_2emetasK_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2emetasK_clo;
V g_heff_2eelab_2eunify_2emsEv(V);
V g_heff_2eelab_2eunify_2emsEv_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2emsEv_clo;
HeffT2 g_heff_2eelab_2eunify_2epatSpine_24cpr(V, V, V);
V g_heff_2eelab_2eunify_2epatVarsOf(V);
V g_heff_2eelab_2eunify_2epatVarsOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2epatVarsOf_clo;
V g_heff_2eelab_2eunify_2epatVarsOf_24dps(V, V);
V g_heff_2eelab_2eunify_2epatVarsOf_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2epatVarsOf_24dps_clo;
V g_heff_2eelab_2eunify_2epoisonMany(V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2epoisonMany_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2epoisonMany_clo;
V g_heff_2eelab_2eunify_2epoisonMany_24s936578932x1254028474(V, V, V);
V g_heff_2eelab_2eunify_2epoisonMany_24s936578932x1254028474_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2epoisonMany_24s936578932x1254028474_clo;
V g_heff_2eelab_2eunify_2epostponeU_24s1873620235x793075195(V, V, V, V, V);
V g_heff_2eelab_2eunify_2epostponeU_24s1873620235x793075195_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2epostponeU_24s1873620235x793075195_clo;
V g_heff_2eelab_2eunify_2erenameClo_24s1533138512x710427120(V, V, V, V, V);
V g_heff_2eelab_2eunify_2erenameClo_24s1533138512x710427120_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2erenameClo_24s1533138512x710427120_clo;
V g_heff_2eelab_2eunify_2erenameCloTy_24s530841725x165541968(V, V, V, V, V);
V g_heff_2eelab_2eunify_2erenameCloTy_24s530841725x165541968_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2erenameCloTy_24s530841725x165541968_clo;
V g_heff_2eelab_2eunify_2erenameF_24s1520005319x327185445(V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2erenameF_24s1520005319x327185445_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2erenameF_24s1520005319x327185445_clo;
V g_heff_2eelab_2eunify_2erenameF_24s729918997x629913808(V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2erenameF_24s729918997x629913808_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2erenameF_24s729918997x629913808_clo;
V g_heff_2eelab_2eunify_2erenameFlexF_24s1543574616x1092368858(V, V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2erenameFlexF_24s1543574616x1092368858_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2erenameFlexF_24s1543574616x1092368858_clo;
V g_heff_2eelab_2eunify_2erenameFlexF_24s1839973402x1588750198(V, V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2erenameFlexF_24s1839973402x1588750198_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2erenameFlexF_24s1839973402x1588750198_clo;
V g_heff_2eelab_2eunify_2erenameHead_24s977237252x483540286(V, V);
V g_heff_2eelab_2eunify_2erenameHead_24s977237252x483540286_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2erenameHead_24s977237252x483540286_clo;
V g_heff_2eelab_2eunify_2erenameRecordFields_24s1394367931x1007778614(V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2erenameRecordFields_24s1394367931x1007778614_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2erenameRecordFields_24s1394367931x1007778614_clo;
V g_heff_2eelab_2eunify_2erenameSpine_24s318780409x760487451(V, V, V, V, V);
V g_heff_2eelab_2eunify_2erenameSpine_24s318780409x760487451_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2erenameSpine_24s318780409x760487451_clo;
V g_heff_2eelab_2eunify_2erenameTypeF_24s1867739536x151311522(V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2erenameTypeF_24s1867739536x151311522_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2erenameTypeF_24s1867739536x151311522_clo;
V g_heff_2eelab_2eunify_2erenameTypeF_24s2127245123x1551710640(V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2erenameTypeF_24s2127245123x1551710640_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2erenameTypeF_24s2127245123x1551710640_clo;
V g_heff_2eelab_2eunify_2esolveF_24s863089x19463346(V, V, V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2esolveF_24s863089x19463346_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2esolveF_24s863089x19463346_clo;
V g_heff_2eelab_2eunify_2esolveRhs_24s425854279x1932184403(V, V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2esolveRhs_24s425854279x1932184403_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2esolveRhs_24s425854279x1932184403_clo;
V g_heff_2eelab_2eunify_2esolveRhs_24s630558595x2041110653(V, V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2esolveRhs_24s630558595x2041110653_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2esolveRhs_24s630558595x2041110653_clo;
V g_heff_2eelab_2eunify_2esolveWithPruned_24s1068778609x578646792(V, V, V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2esolveWithPruned_24s1068778609x578646792_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2esolveWithPruned_24s1068778609x578646792_clo;
V g_heff_2eelab_2eunify_2esolveWithPruned_24s179009019x1439592890(V, V, V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2esolveWithPruned_24s179009019x1439592890_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2esolveWithPruned_24s179009019x1439592890_clo;
V g_heff_2eelab_2eunify_2estoreSol_24s657133741x1839249102(V, V, V, V, V);
V g_heff_2eelab_2eunify_2estoreSol_24s657133741x1839249102_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2estoreSol_24s657133741x1839249102_clo;
V g_heff_2eelab_2eunify_2estripLams(V, V);
V g_heff_2eelab_2eunify_2estripLams_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2estripLams_clo;
V g_heff_2eelab_2eunify_2esubstOf(V);
V g_heff_2eelab_2eunify_2esubstOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2esubstOf_clo;
V g_heff_2eelab_2eunify_2etraceSolve_24s814446277x267296740(V, V, V, V);
V g_heff_2eelab_2eunify_2etraceSolve_24s814446277x267296740_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2etraceSolve_24s814446277x267296740_clo;
V g_heff_2eelab_2eunify_2euBareF_24s1918624290x273142086(V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2euBareF_24s1918624290x273142086_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2euBareF_24s1918624290x273142086_clo;
V g_heff_2eelab_2eunify_2euElRigid(V, V, V, V, V, V, V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2euElRigid_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2euElRigid_clo;
V g_heff_2eelab_2eunify_2euTermF(V, V, V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2euTermF_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2euTermF_clo;
V g_heff_2eelab_2eunify_2eufEv(V);
V g_heff_2eelab_2eunify_2eufEv_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2eufEv_clo;
V g_heff_2eelab_2eunify_2euk_24s506988832x820849616_get(void);
V g_heff_2eelab_2eunify_2ezipL(V, V);
V g_heff_2eelab_2eunify_2ezipL_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2ezipL_clo;
V g_heff_2eelab_2eunify_2ezonkTermF(V, V, V);
V g_heff_2eelab_2eunify_2ezonkTermF_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2ezonkTermF_clo;
V g_heff_2eelab_2evalue_2eforceEl(V, V);
V g_heff_2eelab_2evalue_2eforceEl_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eforceEl_clo;
V g_heff_2eelab_2evalue_2eforceTy(V, V);
V g_heff_2eelab_2evalue_2eforceTy_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eforceTy_clo;
V g_heff_2eelab_2evalue_2eisError(V);
V g_heff_2eelab_2evalue_2eisError_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eisError_clo;
V g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(V, V, V, V);
V g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190_clo;
V g_heff_2eelab_2evalue_2ereplay(V, V);
V g_heff_2eelab_2evalue_2ereplay_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2ereplay_clo;
V g_heff_2eutil_2edict_2eindexed(V, V);
V g_heff_2eutil_2edict_2eindexed_entry(V self, V *a);
extern Clo g_heff_2eutil_2edict_2eindexed_clo;
V g_heff_2eutil_2edict_2ezipKV(V, V);
V g_heff_2eutil_2edict_2ezipKV_entry(V self, V *a);
extern Clo g_heff_2eutil_2edict_2ezipKV_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2efoldl_24s868530262x539343671(V, V);
V g_list_2efoldl_24s868530262x539343671_entry(V self, V *a);
extern Clo g_list_2efoldl_24s868530262x539343671_clo;
V g_list_2emap_24s1173914895x100384474(V);
V g_list_2emap_24s1173914895x100384474_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_clo;
V g_list_2emap_24s1937570095x2110149801(V);
V g_list_2emap_24s1937570095x2110149801_entry(V self, V *a);
extern Clo g_list_2emap_24s1937570095x2110149801_clo;
V g_prelude_2etraverse_24s1934076392x614790049(V, V);
V g_prelude_2etraverse_24s1934076392x614790049_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s1934076392x614790049_clo;
V g_std_2emap_2eempty_get(void);
V g_std_2emap_2einsert_24s170109517x1206653089(V, V, V);
V g_std_2emap_2einsert_24s170109517x1206653089_entry(V self, V *a);
extern Clo g_std_2emap_2einsert_24s170109517x1206653089_clo;
HeffT2 g_std_2emap_2elookup_24s1576363199x1121931492_24cpr(V, V);
HeffT2 g_std_2emap_2elookup_24s1702756637x1169753568_24cpr(V, V);
Clo g_heff_2eelab_2eunify_2epatVarsOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2epatVarsOf_entry, 1, 0};

V g_heff_2eelab_2eunify_2epatVarsOf(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_PVar: {
      V v_l_243 = heff_field(v_x11_241, 0);
      heff_take_n(v_x11_241, 1ULL, 1);
      V v_cell_244 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_l_243, heff_hole()});
      V v_u_245 = (g_heff_2eelab_2eunify_2epatVarsOf_24dps(v_rest_242, heff_dup(v_cell_244)));
      heff_drop(v_u_245);
      return v_cell_244;
    }
    case TAG_PSelf: {
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2eunify_2epatVarsOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2epatVarsOf(a[0]);
}
Clo g_heff_2eelab_2eunify_2epatVarsOf_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2epatVarsOf_24dps_entry, 2, 0};

V g_heff_2eelab_2eunify_2epatVarsOf_24dps(V v_x1_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x11_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_PVar: {
      V v_l_244 = heff_field(v_x11_242, 0);
      heff_take_n(v_x11_242, 1ULL, 1);
      V v_cell_245 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_l_244, heff_hole()});
      V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
      heff_drop(v_u_246);
      V t_0 = v_rest_243;
      V t_1 = v_cell_245;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_PSelf: {
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_243;
      V t_1 = v_d_241;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_x11_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2eunify_2epatVarsOf_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2epatVarsOf_24dps(a[0], a[1]);
}
V g_heff_2eelab_2eunify_2ezonkTermF_lam0(V self, V *args);
V g_heff_2eelab_2eunify_2ezonkTermF_lam1(V self, V *args);
V g_heff_2eelab_2eunify_2ezonkTermF_lam2(V self, V *args);
Clo g_heff_2eelab_2eunify_2ezonkTermF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2ezonkTermF_entry, 3, 0};

V g_heff_2eelab_2eunify_2ezonkTermF(V v_r_240, V v_mc_241, V v_t_242) {
top: ;
  switch (heff_tag_of(v_t_242)) {
  case TAG_SLocal: {
    heff_drop_rec(v_r_240, 2);
    return v_t_242;
  }
  case TAG_SGlobal: {
    heff_drop_rec(v_r_240, 2);
    return v_t_242;
  }
  case TAG_SCode: {
    V v_ty_245 = heff_field(v_t_242, 0);
    V v_ru_24t_242_24SCode = heff_take_reuse_n(v_t_242, 1ULL, 1);
    V v_t_246 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 2), 1, (V[]){v_ty_245}));
    return heff_tag_at_n(v_ru_24t_242_24SCode, TAG_SCode, 1, (V[]){v_t_246});
  }
  case TAG_SApp: {
    V v_f_247 = heff_field(v_t_242, 0);
    V v_a_248 = heff_field(v_t_242, 1);
    V v_ru_24t_242_24SApp = heff_take_reuse_n(v_t_242, 3ULL, 2);
    V v_t_249 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_f_247}));
    V v_t_2410 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_a_248}));
    return heff_tag_at_n(v_ru_24t_242_24SApp, TAG_SApp, 2, (V[]){v_t_249, v_t_2410});
  }
  case TAG_SLam: {
    V v_d_2411 = heff_field(v_t_242, 0);
    V v_b_2412 = heff_field(v_t_242, 1);
    V v_ru_24t_242_24SLam = heff_take_reuse_n(v_t_242, 3ULL, 2);
    V v_t_2413 = heff_tr(heff_call(heff_take_field(v_r_240, 1), 1, (V[]){v_d_2411}));
    V v_f_2414 = heff_get_n(v_r_240, 0, 2);
    V v_t_2420;
    switch (heff_tag_of(v_b_2412)) {
    case TAG_MkAbs: {
      V v_x_2415 = heff_field(v_b_2412, 0);
      V v_b_2416 = heff_field(v_b_2412, 1);
      V v_ru_24b_2412_24MkAbs = heff_take_reuse_n(v_b_2412, 3ULL, 2);
      V v_t_2417 = heff_tr(heff_call(v_f_2414, 1, (V[]){v_b_2416}));
      v_t_2420 = heff_tag_at_n(v_ru_24b_2412_24MkAbs, TAG_MkAbs, 2, (V[]){v_x_2415, v_t_2417});
      break;
    }
    case TAG_AbsConst: {
      V v_b_2418 = heff_field(v_b_2412, 0);
      V v_ru_24b_2412_24AbsConst = heff_take_reuse_n(v_b_2412, 1ULL, 1);
      V v_t_2419 = heff_tr(heff_call(v_f_2414, 1, (V[]){v_b_2418}));
      v_t_2420 = heff_tag_at_n(v_ru_24b_2412_24AbsConst, TAG_AbsConst, 1, (V[]){v_t_2419});
      break;
    }
    default: heff_nomatch(v_b_2412);
    }
    return heff_tag_at_n(v_ru_24t_242_24SLam, TAG_SLam, 2, (V[]){v_t_2413, v_t_2420});
  }
  case TAG_SCons: {
    V v_d_2421 = heff_field(v_t_242, 0);
    V v_ru_24t_242_24SCons = heff_take_reuse_n(v_t_242, 1ULL, 1);
    V v_xs_2422 = heff_take_field(v_d_2421, 2);
    V v_t_2425 = heff_arrayGenerate(heff_arrayLength_lent(v_xs_2422, 0), heff_clo_n(g_heff_2eelab_2eunify_2ezonkTermF_lam0, 1, 2, (V[]){v_xs_2422, v_r_240}));
    V v_t_2426 = ({ V rv_2 = v_t_2425; V rr_ = heff_rec_reuse_nf(v_d_2421, 3ULL, 3, shape_keys__byName__values, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    return heff_tag_at_n(v_ru_24t_242_24SCons, TAG_SCons, 1, (V[]){v_t_2426});
  }
  case TAG_SProj: {
    V v_e_2427 = heff_field(v_t_242, 0);
    V v_l_2428 = heff_field(v_t_242, 1);
    V v_ru_24t_242_24SProj = heff_take_reuse_n(v_t_242, 3ULL, 2);
    V v_t_2429 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_e_2427}));
    return heff_tag_at_n(v_ru_24t_242_24SProj, TAG_SProj, 2, (V[]){v_t_2429, v_l_2428});
  }
  case TAG_STag: {
    V v_x_2430 = heff_field(v_t_242, 0);
    V v_as_2431 = heff_field(v_t_242, 1);
    V v_ru_24t_242_24STag = heff_take_reuse_n(v_t_242, 3ULL, 2);
    V v_t_2434 = heff_arrayGenerate(heff_arrayLength_lent(v_as_2431, 0), heff_clo_n(g_heff_2eelab_2eunify_2ezonkTermF_lam1, 1, 2, (V[]){v_as_2431, v_r_240}));
    return heff_tag_at_n(v_ru_24t_242_24STag, TAG_STag, 2, (V[]){v_x_2430, v_t_2434});
  }
  case TAG_SMatch: {
    V v_e_2435 = heff_field(v_t_242, 0);
    V v_cs_2436 = heff_field(v_t_242, 1);
    V v_ru_24t_242_24SMatch = heff_take_reuse_n(v_t_242, 3ULL, 2);
    V v_t_2437 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e_2435}));
    V v_xs_2438 = heff_take_field(v_cs_2436, 2);
    V v_t_2444 = heff_arrayGenerate(heff_arrayLength_lent(v_xs_2438, 0), heff_clo_n(g_heff_2eelab_2eunify_2ezonkTermF_lam2, 1, 2, (V[]){v_xs_2438, v_r_240}));
    V v_t_2445 = ({ V rv_2 = v_t_2444; V rr_ = heff_rec_reuse_nf(v_cs_2436, 3ULL, 3, shape_keys__byName__values, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
    return heff_tag_at_n(v_ru_24t_242_24SMatch, TAG_SMatch, 2, (V[]){v_t_2437, v_t_2445});
  }
  case TAG_SSpecialize: {
    V v_e_2446 = heff_field(v_t_242, 0);
    V v_l_2447 = heff_field(v_t_242, 1);
    V v_v_2448 = heff_field(v_t_242, 2);
    V v_ru_24t_242_24SSpecialize = heff_take_reuse_n(v_t_242, 7ULL, 3);
    V v_t_2449 = heff_tr(heff_call(heff_dup(heff_rfield(v_r_240, 0)), 1, (V[]){v_e_2446}));
    V v_t_2450 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_v_2448}));
    return heff_tag_at_n(v_ru_24t_242_24SSpecialize, TAG_SSpecialize, 3, (V[]){v_t_2449, v_l_2447, v_t_2450});
  }
  case TAG_SIs: {
    V v_e_2451 = heff_field(v_t_242, 0);
    V v_ru_24t_242_24SIs = heff_take_reuse_n(v_t_242, 1ULL, 1);
    V v_t_2452 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_e_2451}));
    return heff_tag_at_n(v_ru_24t_242_24SIs, TAG_SIs, 1, (V[]){v_t_2452});
  }
  case TAG_SOpaque: {
    heff_drop_rec(v_r_240, 2);
    return v_t_242;
  }
  case TAG_SAbandon: {
    heff_drop_rec(v_r_240, 2);
    return v_t_242;
  }
  case TAG_SRec: {
    V v_e_2453 = heff_field(v_t_242, 0);
    V v_ru_24t_242_24SRec = heff_take_reuse_n(v_t_242, 1ULL, 1);
    V v_t_2454 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_e_2453}));
    return heff_tag_at_n(v_ru_24t_242_24SRec, TAG_SRec, 1, (V[]){v_t_2454});
  }
  case TAG_SFix: {
    V v_d_2455 = heff_field(v_t_242, 0);
    V v_b_2456 = heff_field(v_t_242, 1);
    V v_ru_24t_242_24SFix = heff_take_reuse_n(v_t_242, 3ULL, 2);
    V v_t_2457 = heff_tr(heff_call(heff_take_field(v_r_240, 1), 1, (V[]){v_d_2455}));
    V v_f_2458 = heff_get_n(v_r_240, 0, 2);
    V v_t_2464;
    switch (heff_tag_of(v_b_2456)) {
    case TAG_MkAbs: {
      V v_x_2459 = heff_field(v_b_2456, 0);
      V v_b_2460 = heff_field(v_b_2456, 1);
      V v_ru_24b_2456_24MkAbs = heff_take_reuse_n(v_b_2456, 3ULL, 2);
      V v_t_2461 = heff_tr(heff_call(v_f_2458, 1, (V[]){v_b_2460}));
      v_t_2464 = heff_tag_at_n(v_ru_24b_2456_24MkAbs, TAG_MkAbs, 2, (V[]){v_x_2459, v_t_2461});
      break;
    }
    case TAG_AbsConst: {
      V v_b_2462 = heff_field(v_b_2456, 0);
      V v_ru_24b_2456_24AbsConst = heff_take_reuse_n(v_b_2456, 1ULL, 1);
      V v_t_2463 = heff_tr(heff_call(v_f_2458, 1, (V[]){v_b_2462}));
      v_t_2464 = heff_tag_at_n(v_ru_24b_2456_24AbsConst, TAG_AbsConst, 1, (V[]){v_t_2463});
      break;
    }
    default: heff_nomatch(v_b_2456);
    }
    return heff_tag_at_n(v_ru_24t_242_24SFix, TAG_SFix, 2, (V[]){v_t_2457, v_t_2464});
  }
  case TAG_SImplicit: {
    V v_x_2465 = heff_field(v_t_242, 0);
    V v_e_2466 = heff_field(v_t_242, 1);
    V v_ru_24t_242_24SImplicit = heff_take_reuse_n(v_t_242, 3ULL, 2);
    V v_t_2467 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_e_2466}));
    return heff_tag_at_n(v_ru_24t_242_24SImplicit, TAG_SImplicit, 2, (V[]){v_x_2465, v_t_2467});
  }
  case TAG_SPrim: {
    heff_drop_rec(v_r_240, 2);
    return v_t_242;
  }
  case TAG_SMetaApp: {
    V v_m_2469 = heff_field(v_t_242, 0);
    V v_idxs_2470 = heff_field(v_t_242, 1);
    V v_ty_2471 = heff_field(v_t_242, 2);
    V v_ru_24t_242_24SMetaApp = heff_take_reuse_n(v_t_242, 7ULL, 3);
    HeffT2 v_t_2472 = (g_std_2emap_2elookup_24s1702756637x1169753568_24cpr(v_mc_241, heff_dup(v_m_2469)));
    {
      V v_field_2474 = v_t_2472.f[1];
      int64_t v_tag_2473 = ((int64_t)v_t_2472.f[0]);
      if ((v_tag_2473 == ((int64_t)0ULL))) {
        V v_e_2476 = v_field_2474;
        V v_t_2477 = heff_get_n(v_e_2476, 2, 6);
        switch (heff_tag_of(v_t_2477)) {
        case TAG_Nothing: {
          V v_t_2478 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 2), 1, (V[]){v_ty_2471}));
          return heff_tag_at_n(v_ru_24t_242_24SMetaApp, TAG_SMetaApp, 3, (V[]){v_m_2469, v_idxs_2470, v_t_2478});
        }
        case TAG_Just: {
          V v_sol_2479 = heff_field(v_t_2477, 0);
          heff_take_n(v_t_2477, 1ULL, 1);
          heff_drop(v_m_2469);
          heff_drop(v_ty_2471);
          heff_drop_cell(v_ru_24t_242_24SMetaApp, 3);
          V v_idxs_2480 = heff_arrayToList(v_idxs_2470);
          V v_t_2481 = (g_heff_2eelab_2eunify_2esubstOf(heff_dup(v_idxs_2480)));
          V v_t_2482 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_idxs_2480; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_idxs_2480); r_; });
          V v_t_2483 = (g_heff_2eelab_2eunify_2estripLams(v_t_2482, v_sol_2479));
          V v_t_2484 = heff_tr(heff_call(heff_get_n(v_t_2481, 0, 2), 2, (V[]){MK_INT(0LL), v_t_2483}));
          return heff_tail(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_t_2484});
        }
        default: return heff_nomatch(v_t_2477);
        }
      } else {
        heff_drop(v_field_2474);
        V v_t_2485 = heff_tr(heff_call(heff_get_n(v_r_240, 1, 2), 1, (V[]){v_ty_2471}));
        return heff_tag_at_n(v_ru_24t_242_24SMetaApp, TAG_SMetaApp, 3, (V[]){v_m_2469, v_idxs_2470, v_t_2485});
      }
    }
  }
  case TAG_SLitInt: {
    heff_drop_rec(v_r_240, 2);
    return v_t_242;
  }
  case TAG_SLitFloat: {
    heff_drop_rec(v_r_240, 2);
    return v_t_242;
  }
  case TAG_SLitString: {
    heff_drop_rec(v_r_240, 2);
    return v_t_242;
  }
  case TAG_SLitBytes: {
    heff_drop_rec(v_r_240, 2);
    return v_t_242;
  }
  case TAG_SLitRune: {
    heff_drop_rec(v_r_240, 2);
    return v_t_242;
  }
  case TAG_SLitFixed: {
    heff_drop_rec(v_r_240, 2);
    return v_t_242;
  }
  case TAG_SLitFloat32: {
    heff_drop_rec(v_r_240, 2);
    return v_t_242;
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2eelab_2eunify_2ezonkTermF_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2eunify_2ezonkTermF(a[0], a1, a[2]); heff_drop(a1); return r;
}
V g_heff_2eelab_2eunify_2ezonkTermF_lam0(V self, V *args) {
  V v_i_2423 = args[0];
  V v_xs_2422 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2424 = heff_arrayIndex(v_xs_2422, v_i_2423);
  V f_ = heff_get_n(v_r_240, 0, 2);
  args[0] = v_t_2424;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2ezonkTermF_lam1(V self, V *args) {
  V v_i_2432 = args[0];
  V v_as_2431 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2433 = heff_arrayIndex(v_as_2431, v_i_2432);
  V f_ = heff_get_n(v_r_240, 0, 2);
  args[0] = v_t_2433;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2ezonkTermF_lam2(V self, V *args) {
  V v_i_2439 = args[0];
  V v_xs_2438 = heff_env(self)[0];
  V v_r_240 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_p_2440 = heff_arrayIndex(v_xs_2438, v_i_2439);
  switch (heff_tag_of(v_p_2440)) {
  case TAG_MkPair: {
    V v_xs_2441 = heff_field(v_p_2440, 0);
    V v_b_2442 = heff_field(v_p_2440, 1);
    V v_ru_24p_2440_24MkPair = heff_take_reuse_n(v_p_2440, 3ULL, 2);
    V v_t_2443 = heff_tr(heff_call(heff_get_n(v_r_240, 0, 2), 1, (V[]){v_b_2442}));
    return heff_tag_at_n(v_ru_24p_2440_24MkPair, TAG_MkPair, 2, (V[]){v_xs_2441, v_t_2443});
  }
  default: return heff_nomatch(v_p_2440);
  }
}
Clo g_heff_2eelab_2eunify_2emapWithIndexL_24s1606268187x1223772876_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2emapWithIndexL_24s1606268187x1223772876_entry, 2, 0};

V g_heff_2eelab_2eunify_2emapWithIndexL_24s1606268187x1223772876(V v_i_240, V v_x3_241) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    heff_drop(v_i_240);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x3_241, 0);
    V v_xs_243 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_t_2410;
    switch (heff_tag_of(v_x_242)) {
    case TAG_MkPair: {
      V v_a_244 = heff_field(v_x_242, 0);
      V v_a_245 = heff_field(v_x_242, 1);
      heff_take_n(v_x_242, 3ULL, 2);
      switch (heff_tag_of(v_a_244)) {
      case TAG_PVar: {
        V v_a_246 = heff_field(v_a_244, 0);
        V v_ru_24a_244_24PVar = heff_take_reuse_n(v_a_244, 1ULL, 1);
        switch (heff_tag_of(v_a_245)) {
        case TAG_PVar: {
          V v_a_247 = heff_field(v_a_245, 0);
          heff_take_n(v_a_245, 1ULL, 1);
          if (heff_intEq_c(v_a_246, v_a_247)) {
            v_t_2410 = heff_tag_at_n(v_ru_24a_244_24PVar, TAG_Just, 1, (V[]){heff_dup(v_i_240)});
          } else {
            heff_drop_cell(v_ru_24a_244_24PVar, 1);
            v_t_2410 = NTAG(TAG_Nothing);
          }
          break;
        }
        case TAG_PSelf: {
          heff_drop(v_a_246);
          heff_drop_cell(v_ru_24a_244_24PVar, 1);
          v_t_2410 = NTAG(TAG_Nothing);
          break;
        }
        default: heff_nomatch(v_a_245);
        }
        break;
      }
      case TAG_PSelf: {
        switch (heff_tag_of(v_a_245)) {
        case TAG_PVar: {
          heff_take_n(v_a_245, 0ULL, 1);
          v_t_2410 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_PSelf: {
          v_t_2410 = heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_i_240)});
          break;
        }
        default: heff_nomatch(v_a_245);
        }
        break;
      }
      default: heff_nomatch(v_a_244);
      }
      break;
    }
    default: heff_nomatch(v_x_242);
    }
    V v_cell_2411 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_t_2410, heff_hole()});
    V v_u_2412 = (g_heff_2eelab_2eunify_2emapWithIndexL_24s1606268187x1223772876_24dps(heff_box_word((heff_unbox_word(v_i_240) + ((int64_t)1ULL))), v_xs_243, heff_dup(v_cell_2411)));
    heff_drop(v_u_2412);
    return v_cell_2411;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_heff_2eelab_2eunify_2emapWithIndexL_24s1606268187x1223772876_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2emapWithIndexL_24s1606268187x1223772876(a[0], a[1]);
}
V g_heff_2eelab_2eunify_2euTermF_lam0(V self, V *args);
V g_heff_2eelab_2eunify_2euTermF_lam3(V self, V *args);
V g_heff_2eelab_2eunify_2euTermF_lam5(V self, V *args); static Clo g_heff_2eelab_2eunify_2euTermF_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2euTermF_lam5, 1, 0};
V g_heff_2eelab_2eunify_2euTermF_lam8(V self, V *args); static Clo g_heff_2eelab_2eunify_2euTermF_lam8_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2euTermF_lam8, 1, 0};
V g_heff_2eelab_2eunify_2euTermF_lam9(V self, V *args);
V g_heff_2eelab_2eunify_2euTermF_lam7(V self, V *args);
V g_heff_2eelab_2eunify_2euTermF_lam6(V self, V *args);
V g_heff_2eelab_2eunify_2euTermF_lam4(V self, V *args);
V g_heff_2eelab_2eunify_2euTermF_lam2(V self, V *args);
V g_heff_2eelab_2eunify_2euTermF_lam1(V self, V *args);
Clo g_heff_2eelab_2eunify_2euTermF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2euTermF_entry, 8, 0};

V g_heff_2eelab_2eunify_2euTermF(V v_w_240, V v_ms_241, V v_uf_242, V v_r_243, V v_g_244, V v_cs_245, V v_a0_246, V v_b0_247) {
top: ;
  V v_t_249 = heff_tr(heff_call(heff_dup(v_ms_241), 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2eunify_2euTermF_lam0, 1, 1, (V[]){v_a0_246})})}));
  return heff_clo_n(g_heff_2eelab_2eunify_2euTermF_lam1, 2, 8, (V[]){v_w_240, v_t_249, v_ms_241, v_b0_247, v_cs_245, v_uf_242, v_r_243, v_g_244});
}
V g_heff_2eelab_2eunify_2euTermF_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2euTermF(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
}
V g_heff_2eelab_2eunify_2euTermF_lam0(V self, V *args) {
  V v_c_248 = args[0];
  V v_a0_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_c_248, 3, 8); V a_1 = v_a0_246; V r_ = (g_heff_2eelab_2evalue_2eforceEl(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2eelab_2eunify_2euTermF_lam3(V self, V *args) {
  V v_c_2413 = args[0];
  V v_b0_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_c_2413, 3, 8); V a_1 = v_b0_247; V r_ = (g_heff_2eelab_2evalue_2eforceEl(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2eelab_2eunify_2euTermF_lam5(V self, V *args) {
  V v_c_2418 = args[0];
  return heff_get_n(v_c_2418, 3, 8);
}
V g_heff_2eelab_2eunify_2euTermF_lam8(V self, V *args) {
  V v_c_2424 = args[0];
  return heff_get_n(v_c_2424, 3, 8);
}
V g_heff_2eelab_2eunify_2euTermF_lam9(V self, V *args) {
  V v_x_2426 = args[0];
  V v_cs_245 = heff_env(self)[0];
  V v_x_2415 = heff_env(self)[1];
  V v_w_240 = heff_env(self)[2];
  V v_ms_241 = heff_env(self)[3];
  V v_uf_242 = heff_env(self)[4];
  V v_hd_2410 = heff_env(self)[5];
  V v_k_2411 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2427 = ({ V a_0 = v_x_2426; V r_ = (g_heff_2eelab_2eunify_2emetasK(a_0)); heff_drop(v_x_2426); r_; });
  V v_t_2428 = heff_tr(heff_call(heff_get_n(v_t_2427, 0, 3), 3, (V[]){MK_INT(20LL), heff_get_n(v_cs_245, 0, 2), v_x_2415}));
  return ({ V a_0 = v_w_240; V a_1 = v_ms_241; V a_2 = v_uf_242; V a_3 = v_t_2428; V a_4 = v_hd_2410; V a_5 = v_k_2411; V r_ = (g_heff_2eelab_2eunify_2epoisonMany(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_uf_242); heff_drop(v_t_2428); r_; });
}
V g_heff_2eelab_2eunify_2euTermF_lam7(V self, V *args) {
  V v_x_2423 = args[0];
  V v_ms_241 = heff_env(self)[0];
  V v_w_240 = heff_env(self)[1];
  V v_hd_2410 = heff_env(self)[2];
  V v_cs_245 = heff_env(self)[3];
  V v_x_2415 = heff_env(self)[4];
  V v_uf_242 = heff_env(self)[5];
  V v_k_2411 = heff_env(self)[6];
  heff_clo_take(self, 7);
  heff_drop(v_x_2423);
  V v_t_2425 = heff_tr(heff_call(heff_dup(v_ms_241), 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2eunify_2euTermF_lam8_clo)})}));
  return (g_co_2eop_24s310169282x2049378029(heff_dup(v_w_240), v_t_2425, heff_dup(v_hd_2410), heff_clo_n(g_heff_2eelab_2eunify_2euTermF_lam9, 1, 7, (V[]){v_cs_245, v_x_2415, v_w_240, v_ms_241, v_uf_242, v_hd_2410, v_k_2411})));
}
V g_heff_2eelab_2eunify_2euTermF_lam6(V self, V *args) {
  V v_x_2420 = args[0];
  V v_cs_245 = heff_env(self)[0];
  V v_x_2412 = heff_env(self)[1];
  V v_w_240 = heff_env(self)[2];
  V v_ms_241 = heff_env(self)[3];
  V v_uf_242 = heff_env(self)[4];
  V v_hd_2410 = heff_env(self)[5];
  V v_x_2415 = heff_env(self)[6];
  V v_k_2411 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2421 = ({ V a_0 = v_x_2420; V r_ = (g_heff_2eelab_2eunify_2emetasK(a_0)); heff_drop(v_x_2420); r_; });
  V v_t_2422 = heff_tr(heff_call(heff_get_n(v_t_2421, 0, 3), 3, (V[]){MK_INT(20LL), heff_dup(heff_rfield(v_cs_245, 0)), v_x_2412}));
  return ({ V a_0 = heff_dup(v_w_240); V a_1 = heff_dup(v_ms_241); V a_2 = v_uf_242; V a_3 = v_t_2422; V a_4 = heff_dup(v_hd_2410); V a_5 = heff_clo_n(g_heff_2eelab_2eunify_2euTermF_lam7, 1, 7, (V[]){v_ms_241, v_w_240, v_hd_2410, v_cs_245, v_x_2415, heff_dup(v_uf_242), v_k_2411}); V r_ = (g_heff_2eelab_2eunify_2epoisonMany(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_uf_242); heff_drop(v_t_2422); r_; });
}
V g_heff_2eelab_2eunify_2euTermF_lam4(V self, V *args) {
  V v_x_2415 = args[0];
  V v_x_2412 = heff_env(self)[0];
  V v_ms_241 = heff_env(self)[1];
  V v_w_240 = heff_env(self)[2];
  V v_hd_2410 = heff_env(self)[3];
  V v_cs_245 = heff_env(self)[4];
  V v_uf_242 = heff_env(self)[5];
  V v_k_2411 = heff_env(self)[6];
  V v_r_243 = heff_env(self)[7];
  V v_g_244 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_t_2416 = (g_heff_2eelab_2evalue_2eisError(v_x_2412));
  V v_t_2417;
  if ((heff_dup(v_t_2416) == NTAG(TAG_True))) {
    heff_drop(v_t_2416);
    v_t_2417 = NTAG(TAG_True);
  } else {
    heff_drop(v_t_2416);
    v_t_2417 = (g_heff_2eelab_2evalue_2eisError(v_x_2415));
  }
  if ((heff_dup(v_t_2417) == NTAG(TAG_True))) {
    heff_drop_rec(v_r_243, 9);
    heff_drop(v_g_244);
    heff_drop(v_t_2417);
    V v_t_2419 = heff_tr(heff_call(heff_dup(v_ms_241), 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2eunify_2euTermF_lam5_clo)})}));
    return (g_co_2eop_24s310169282x2049378029(heff_dup(v_w_240), v_t_2419, heff_dup(v_hd_2410), heff_clo_n(g_heff_2eelab_2eunify_2euTermF_lam6, 1, 8, (V[]){v_cs_245, v_x_2412, v_w_240, v_ms_241, v_uf_242, v_hd_2410, v_x_2415, v_k_2411})));
  } else {
    heff_drop(v_t_2417);
    switch (heff_tag_of(v_x_2412)) {
    case TAG_VNeu: {
      switch (heff_tag_of(v_x_2415)) {
      case TAG_VNeu: {
        V v_t_2451;
        switch (heff_tag_of(v_x_2412)) {
        case TAG_VNeu: {
          V v_v1_2439 = heff_dup(heff_field(v_x_2412, 0));
          V v_sp_2440 = heff_dup(heff_field(v_x_2412, 1));
          switch (heff_tag_of(v_v1_2439)) {
          case TAG_HLocal: {
            heff_take_n(v_v1_2439, 0ULL, 1);
            heff_drop(v_sp_2440);
            v_t_2451 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HGlobal: {
            heff_take_n(v_v1_2439, 0ULL, 1);
            heff_drop(v_sp_2440);
            v_t_2451 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HMeta: {
            V v_m_2446 = heff_field(v_v1_2439, 0);
            V v_ru_24v1_2439_24HMeta = heff_take_reuse_n(v_v1_2439, 1ULL, 1);
            v_t_2451 = heff_tag_at_n(v_ru_24v1_2439_24HMeta, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_m_2446, v_sp_2440})});
            break;
          }
          case TAG_HError: {
            heff_drop(v_sp_2440);
            v_t_2451 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_v1_2439);
          }
          break;
        }
        case TAG_VCode: {
          v_t_2451 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VLam: {
          v_t_2451 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VCons: {
          v_t_2451 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VOpaque: {
          v_t_2451 = NTAG(TAG_Nothing);
          break;
        }
        default: heff_nomatch(v_x_2412);
        }
        switch (heff_tag_of(v_t_2451)) {
        case TAG_Nothing: {
          V v_t_2464;
          switch (heff_tag_of(v_x_2415)) {
          case TAG_VNeu: {
            V v_v1_2452 = heff_dup(heff_field(v_x_2415, 0));
            V v_sp_2453 = heff_dup(heff_field(v_x_2415, 1));
            switch (heff_tag_of(v_v1_2452)) {
            case TAG_HLocal: {
              heff_take_n(v_v1_2452, 0ULL, 1);
              heff_drop(v_sp_2453);
              v_t_2464 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HGlobal: {
              heff_take_n(v_v1_2452, 0ULL, 1);
              heff_drop(v_sp_2453);
              v_t_2464 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HMeta: {
              V v_m_2459 = heff_field(v_v1_2452, 0);
              V v_ru_24v1_2452_24HMeta = heff_take_reuse_n(v_v1_2452, 1ULL, 1);
              v_t_2464 = heff_tag_at_n(v_ru_24v1_2452_24HMeta, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_m_2459, v_sp_2453})});
              break;
            }
            case TAG_HError: {
              heff_drop(v_sp_2453);
              v_t_2464 = NTAG(TAG_Nothing);
              break;
            }
            default: heff_nomatch(v_v1_2452);
            }
            break;
          }
          case TAG_VCode: {
            v_t_2464 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VLam: {
            v_t_2464 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VCons: {
            v_t_2464 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VOpaque: {
            v_t_2464 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_x_2415);
          }
          switch (heff_tag_of(v_t_2464)) {
          case TAG_Nothing: {
            V v_t_2477;
            switch (heff_tag_of(v_x_2412)) {
            case TAG_VNeu: {
              V v_v1_2465 = heff_dup(heff_field(v_x_2412, 0));
              switch (heff_tag_of(v_v1_2465)) {
              case TAG_HLocal: {
                heff_take_n(v_v1_2465, 0ULL, 1);
                v_t_2477 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
                break;
              }
              case TAG_HGlobal: {
                heff_take_n(v_v1_2465, 0ULL, 1);
                v_t_2477 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
                break;
              }
              case TAG_HMeta: {
                heff_take_n(v_v1_2465, 0ULL, 1);
                v_t_2477 = heff_dup(v_x_2412);
                break;
              }
              case TAG_HError: {
                v_t_2477 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
                break;
              }
              default: heff_nomatch(v_v1_2465);
              }
              break;
            }
            case TAG_VCode: {
              v_t_2477 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
              break;
            }
            case TAG_VLam: {
              v_t_2477 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
              break;
            }
            case TAG_VCons: {
              v_t_2477 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
              break;
            }
            case TAG_VOpaque: {
              v_t_2477 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
              break;
            }
            default: heff_nomatch(v_x_2412);
            }
            V v_t_2490;
            switch (heff_tag_of(v_x_2415)) {
            case TAG_VNeu: {
              V v_v1_2478 = heff_dup(heff_field(v_x_2415, 0));
              switch (heff_tag_of(v_v1_2478)) {
              case TAG_HLocal: {
                heff_take_n(v_v1_2478, 0ULL, 1);
                v_t_2490 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
                break;
              }
              case TAG_HGlobal: {
                heff_take_n(v_v1_2478, 0ULL, 1);
                v_t_2490 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
                break;
              }
              case TAG_HMeta: {
                heff_take_n(v_v1_2478, 0ULL, 1);
                v_t_2490 = heff_dup(v_x_2415);
                break;
              }
              case TAG_HError: {
                v_t_2490 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
                break;
              }
              default: heff_nomatch(v_v1_2478);
              }
              break;
            }
            case TAG_VCode: {
              v_t_2490 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
              break;
            }
            case TAG_VLam: {
              v_t_2490 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
              break;
            }
            case TAG_VCons: {
              v_t_2490 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
              break;
            }
            case TAG_VOpaque: {
              v_t_2490 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
              break;
            }
            default: heff_nomatch(v_x_2415);
            }
            return ({ V a_0 = v_w_240; V a_1 = v_ms_241; V a_2 = v_uf_242; V a_3 = v_r_243; V a_4 = v_g_244; V a_5 = v_cs_245; V a_6 = v_t_2477; V a_7 = v_t_2490; V a_8 = v_x_2412; V a_9 = v_x_2415; V a_10 = v_hd_2410; V a_11 = v_k_2411; V r_ = (g_heff_2eelab_2eunify_2euElRigid(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9, a_10, a_11)); heff_drop(v_ms_241); r_; });
          }
          case TAG_Just: {
            V v_it1_2491 = heff_field(v_t_2464, 0);
            heff_take_n(v_t_2464, 1ULL, 1);
            heff_drop(v_ms_241);
            heff_drop(v_w_240);
            heff_drop(v_uf_242);
            switch (heff_tag_of(v_it1_2491)) {
            case TAG_MkPair: {
              V v_m_2492 = heff_field(v_it1_2491, 0);
              V v_sp_2493 = heff_field(v_it1_2491, 1);
              heff_take_n(v_it1_2491, 3ULL, 2);
              return heff_tail(heff_get_n(v_r_243, 3, 9), 8, (V[]){v_g_244, v_cs_245, v_m_2492, v_sp_2493, v_x_2412, v_x_2415, v_hd_2410, v_k_2411});
            }
            default: return heff_nomatch(v_it1_2491);
            }
          }
          default: return heff_nomatch(v_t_2464);
          }
        }
        case TAG_Just: {
          V v_it1_2494 = heff_field(v_t_2451, 0);
          heff_take_n(v_t_2451, 1ULL, 1);
          heff_drop(v_ms_241);
          heff_drop(v_w_240);
          heff_drop(v_uf_242);
          switch (heff_tag_of(v_it1_2494)) {
          case TAG_MkPair: {
            V v_m_2495 = heff_field(v_it1_2494, 0);
            V v_sp_2496 = heff_field(v_it1_2494, 1);
            heff_take_n(v_it1_2494, 3ULL, 2);
            return heff_tail(heff_get_n(v_r_243, 3, 9), 8, (V[]){v_g_244, v_cs_245, v_m_2495, v_sp_2496, v_x_2415, v_x_2412, v_hd_2410, v_k_2411});
          }
          default: return heff_nomatch(v_it1_2494);
          }
        }
        default: return heff_nomatch(v_t_2451);
        }
      }
      case TAG_VCode: {
        V v_t_24110;
        switch (heff_tag_of(v_x_2412)) {
        case TAG_VNeu: {
          V v_v1_2498 = heff_dup(heff_field(v_x_2412, 0));
          V v_sp_2499 = heff_dup(heff_field(v_x_2412, 1));
          switch (heff_tag_of(v_v1_2498)) {
          case TAG_HLocal: {
            heff_take_n(v_v1_2498, 0ULL, 1);
            heff_drop(v_sp_2499);
            v_t_24110 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HGlobal: {
            heff_take_n(v_v1_2498, 0ULL, 1);
            heff_drop(v_sp_2499);
            v_t_24110 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HMeta: {
            V v_m_24105 = heff_field(v_v1_2498, 0);
            V v_ru_24v1_2498_24HMeta = heff_take_reuse_n(v_v1_2498, 1ULL, 1);
            v_t_24110 = heff_tag_at_n(v_ru_24v1_2498_24HMeta, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_m_24105, v_sp_2499})});
            break;
          }
          case TAG_HError: {
            heff_drop(v_sp_2499);
            v_t_24110 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_v1_2498);
          }
          break;
        }
        case TAG_VCode: {
          v_t_24110 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VLam: {
          v_t_24110 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VCons: {
          v_t_24110 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VOpaque: {
          v_t_24110 = NTAG(TAG_Nothing);
          break;
        }
        default: heff_nomatch(v_x_2412);
        }
        switch (heff_tag_of(v_t_24110)) {
        case TAG_Nothing: {
          V v_t_24123;
          switch (heff_tag_of(v_x_2415)) {
          case TAG_VNeu: {
            V v_v1_24111 = heff_dup(heff_field(v_x_2415, 0));
            V v_sp_24112 = heff_dup(heff_field(v_x_2415, 1));
            switch (heff_tag_of(v_v1_24111)) {
            case TAG_HLocal: {
              heff_take_n(v_v1_24111, 0ULL, 1);
              heff_drop(v_sp_24112);
              v_t_24123 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HGlobal: {
              heff_take_n(v_v1_24111, 0ULL, 1);
              heff_drop(v_sp_24112);
              v_t_24123 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HMeta: {
              V v_m_24118 = heff_field(v_v1_24111, 0);
              V v_ru_24v1_24111_24HMeta = heff_take_reuse_n(v_v1_24111, 1ULL, 1);
              v_t_24123 = heff_tag_at_n(v_ru_24v1_24111_24HMeta, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_m_24118, v_sp_24112})});
              break;
            }
            case TAG_HError: {
              heff_drop(v_sp_24112);
              v_t_24123 = NTAG(TAG_Nothing);
              break;
            }
            default: heff_nomatch(v_v1_24111);
            }
            break;
          }
          case TAG_VCode: {
            v_t_24123 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VLam: {
            v_t_24123 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VCons: {
            v_t_24123 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VOpaque: {
            v_t_24123 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_x_2415);
          }
          switch (heff_tag_of(v_t_24123)) {
          case TAG_Nothing: {
            V v_t_24136;
            switch (heff_tag_of(v_x_2412)) {
            case TAG_VNeu: {
              V v_v1_24124 = heff_dup(heff_field(v_x_2412, 0));
              switch (heff_tag_of(v_v1_24124)) {
              case TAG_HLocal: {
                heff_take_n(v_v1_24124, 0ULL, 1);
                v_t_24136 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
                break;
              }
              case TAG_HGlobal: {
                heff_take_n(v_v1_24124, 0ULL, 1);
                v_t_24136 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
                break;
              }
              case TAG_HMeta: {
                heff_take_n(v_v1_24124, 0ULL, 1);
                v_t_24136 = heff_dup(v_x_2412);
                break;
              }
              case TAG_HError: {
                v_t_24136 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
                break;
              }
              default: heff_nomatch(v_v1_24124);
              }
              break;
            }
            case TAG_VCode: {
              v_t_24136 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
              break;
            }
            case TAG_VLam: {
              v_t_24136 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
              break;
            }
            case TAG_VCons: {
              v_t_24136 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
              break;
            }
            case TAG_VOpaque: {
              v_t_24136 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
              break;
            }
            default: heff_nomatch(v_x_2412);
            }
            V v_t_24149;
            switch (heff_tag_of(v_x_2415)) {
            case TAG_VNeu: {
              V v_v1_24137 = heff_dup(heff_field(v_x_2415, 0));
              switch (heff_tag_of(v_v1_24137)) {
              case TAG_HLocal: {
                heff_take_n(v_v1_24137, 0ULL, 1);
                v_t_24149 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
                break;
              }
              case TAG_HGlobal: {
                heff_take_n(v_v1_24137, 0ULL, 1);
                v_t_24149 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
                break;
              }
              case TAG_HMeta: {
                heff_take_n(v_v1_24137, 0ULL, 1);
                v_t_24149 = heff_dup(v_x_2415);
                break;
              }
              case TAG_HError: {
                v_t_24149 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
                break;
              }
              default: heff_nomatch(v_v1_24137);
              }
              break;
            }
            case TAG_VCode: {
              v_t_24149 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
              break;
            }
            case TAG_VLam: {
              v_t_24149 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
              break;
            }
            case TAG_VCons: {
              v_t_24149 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
              break;
            }
            case TAG_VOpaque: {
              v_t_24149 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
              break;
            }
            default: heff_nomatch(v_x_2415);
            }
            return ({ V a_0 = v_w_240; V a_1 = v_ms_241; V a_2 = v_uf_242; V a_3 = v_r_243; V a_4 = v_g_244; V a_5 = v_cs_245; V a_6 = v_t_24136; V a_7 = v_t_24149; V a_8 = v_x_2412; V a_9 = v_x_2415; V a_10 = v_hd_2410; V a_11 = v_k_2411; V r_ = (g_heff_2eelab_2eunify_2euElRigid(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9, a_10, a_11)); heff_drop(v_ms_241); r_; });
          }
          case TAG_Just: {
            V v_it1_24150 = heff_field(v_t_24123, 0);
            heff_take_n(v_t_24123, 1ULL, 1);
            heff_drop(v_ms_241);
            heff_drop(v_w_240);
            heff_drop(v_uf_242);
            switch (heff_tag_of(v_it1_24150)) {
            case TAG_MkPair: {
              V v_m_24151 = heff_field(v_it1_24150, 0);
              V v_sp_24152 = heff_field(v_it1_24150, 1);
              heff_take_n(v_it1_24150, 3ULL, 2);
              return heff_tail(heff_get_n(v_r_243, 3, 9), 8, (V[]){v_g_244, v_cs_245, v_m_24151, v_sp_24152, v_x_2412, v_x_2415, v_hd_2410, v_k_2411});
            }
            default: return heff_nomatch(v_it1_24150);
            }
          }
          default: return heff_nomatch(v_t_24123);
          }
        }
        case TAG_Just: {
          V v_it1_24153 = heff_field(v_t_24110, 0);
          heff_take_n(v_t_24110, 1ULL, 1);
          heff_drop(v_ms_241);
          heff_drop(v_w_240);
          heff_drop(v_uf_242);
          switch (heff_tag_of(v_it1_24153)) {
          case TAG_MkPair: {
            V v_m_24154 = heff_field(v_it1_24153, 0);
            V v_sp_24155 = heff_field(v_it1_24153, 1);
            heff_take_n(v_it1_24153, 3ULL, 2);
            return heff_tail(heff_get_n(v_r_243, 3, 9), 8, (V[]){v_g_244, v_cs_245, v_m_24154, v_sp_24155, v_x_2415, v_x_2412, v_hd_2410, v_k_2411});
          }
          default: return heff_nomatch(v_it1_24153);
          }
        }
        default: return heff_nomatch(v_t_24110);
        }
      }
      case TAG_VLam: {
        V v_t_24170;
        switch (heff_tag_of(v_x_2412)) {
        case TAG_VNeu: {
          V v_v1_24158 = heff_dup(heff_field(v_x_2412, 0));
          V v_sp_24159 = heff_dup(heff_field(v_x_2412, 1));
          switch (heff_tag_of(v_v1_24158)) {
          case TAG_HLocal: {
            heff_take_n(v_v1_24158, 0ULL, 1);
            heff_drop(v_sp_24159);
            v_t_24170 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HGlobal: {
            heff_take_n(v_v1_24158, 0ULL, 1);
            heff_drop(v_sp_24159);
            v_t_24170 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HMeta: {
            V v_m_24165 = heff_field(v_v1_24158, 0);
            V v_ru_24v1_24158_24HMeta = heff_take_reuse_n(v_v1_24158, 1ULL, 1);
            v_t_24170 = heff_tag_at_n(v_ru_24v1_24158_24HMeta, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_m_24165, v_sp_24159})});
            break;
          }
          case TAG_HError: {
            heff_drop(v_sp_24159);
            v_t_24170 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_v1_24158);
          }
          break;
        }
        case TAG_VCode: {
          v_t_24170 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VLam: {
          v_t_24170 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VCons: {
          v_t_24170 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VOpaque: {
          v_t_24170 = NTAG(TAG_Nothing);
          break;
        }
        default: heff_nomatch(v_x_2412);
        }
        switch (heff_tag_of(v_t_24170)) {
        case TAG_Nothing: {
          V v_t_24183;
          switch (heff_tag_of(v_x_2415)) {
          case TAG_VNeu: {
            V v_v1_24171 = heff_dup(heff_field(v_x_2415, 0));
            V v_sp_24172 = heff_dup(heff_field(v_x_2415, 1));
            switch (heff_tag_of(v_v1_24171)) {
            case TAG_HLocal: {
              heff_take_n(v_v1_24171, 0ULL, 1);
              heff_drop(v_sp_24172);
              v_t_24183 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HGlobal: {
              heff_take_n(v_v1_24171, 0ULL, 1);
              heff_drop(v_sp_24172);
              v_t_24183 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HMeta: {
              V v_m_24178 = heff_field(v_v1_24171, 0);
              V v_ru_24v1_24171_24HMeta = heff_take_reuse_n(v_v1_24171, 1ULL, 1);
              v_t_24183 = heff_tag_at_n(v_ru_24v1_24171_24HMeta, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_m_24178, v_sp_24172})});
              break;
            }
            case TAG_HError: {
              heff_drop(v_sp_24172);
              v_t_24183 = NTAG(TAG_Nothing);
              break;
            }
            default: heff_nomatch(v_v1_24171);
            }
            break;
          }
          case TAG_VCode: {
            v_t_24183 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VLam: {
            v_t_24183 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VCons: {
            v_t_24183 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VOpaque: {
            v_t_24183 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_x_2415);
          }
          switch (heff_tag_of(v_t_24183)) {
          case TAG_Nothing: {
            V v_t_24196;
            switch (heff_tag_of(v_x_2412)) {
            case TAG_VNeu: {
              V v_v1_24184 = heff_dup(heff_field(v_x_2412, 0));
              switch (heff_tag_of(v_v1_24184)) {
              case TAG_HLocal: {
                heff_take_n(v_v1_24184, 0ULL, 1);
                v_t_24196 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
                break;
              }
              case TAG_HGlobal: {
                heff_take_n(v_v1_24184, 0ULL, 1);
                v_t_24196 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
                break;
              }
              case TAG_HMeta: {
                heff_take_n(v_v1_24184, 0ULL, 1);
                v_t_24196 = heff_dup(v_x_2412);
                break;
              }
              case TAG_HError: {
                v_t_24196 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
                break;
              }
              default: heff_nomatch(v_v1_24184);
              }
              break;
            }
            case TAG_VCode: {
              v_t_24196 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
              break;
            }
            case TAG_VLam: {
              v_t_24196 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
              break;
            }
            case TAG_VCons: {
              v_t_24196 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
              break;
            }
            case TAG_VOpaque: {
              v_t_24196 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
              break;
            }
            default: heff_nomatch(v_x_2412);
            }
            V v_t_24209;
            switch (heff_tag_of(v_x_2415)) {
            case TAG_VNeu: {
              V v_v1_24197 = heff_dup(heff_field(v_x_2415, 0));
              switch (heff_tag_of(v_v1_24197)) {
              case TAG_HLocal: {
                heff_take_n(v_v1_24197, 0ULL, 1);
                v_t_24209 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
                break;
              }
              case TAG_HGlobal: {
                heff_take_n(v_v1_24197, 0ULL, 1);
                v_t_24209 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
                break;
              }
              case TAG_HMeta: {
                heff_take_n(v_v1_24197, 0ULL, 1);
                v_t_24209 = heff_dup(v_x_2415);
                break;
              }
              case TAG_HError: {
                v_t_24209 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
                break;
              }
              default: heff_nomatch(v_v1_24197);
              }
              break;
            }
            case TAG_VCode: {
              v_t_24209 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
              break;
            }
            case TAG_VLam: {
              v_t_24209 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
              break;
            }
            case TAG_VCons: {
              v_t_24209 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
              break;
            }
            case TAG_VOpaque: {
              v_t_24209 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
              break;
            }
            default: heff_nomatch(v_x_2415);
            }
            return ({ V a_0 = v_w_240; V a_1 = v_ms_241; V a_2 = v_uf_242; V a_3 = v_r_243; V a_4 = v_g_244; V a_5 = v_cs_245; V a_6 = v_t_24196; V a_7 = v_t_24209; V a_8 = v_x_2412; V a_9 = v_x_2415; V a_10 = v_hd_2410; V a_11 = v_k_2411; V r_ = (g_heff_2eelab_2eunify_2euElRigid(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9, a_10, a_11)); heff_drop(v_ms_241); r_; });
          }
          case TAG_Just: {
            V v_it1_24210 = heff_field(v_t_24183, 0);
            heff_take_n(v_t_24183, 1ULL, 1);
            heff_drop(v_ms_241);
            heff_drop(v_w_240);
            heff_drop(v_uf_242);
            switch (heff_tag_of(v_it1_24210)) {
            case TAG_MkPair: {
              V v_m_24211 = heff_field(v_it1_24210, 0);
              V v_sp_24212 = heff_field(v_it1_24210, 1);
              heff_take_n(v_it1_24210, 3ULL, 2);
              return heff_tail(heff_get_n(v_r_243, 3, 9), 8, (V[]){v_g_244, v_cs_245, v_m_24211, v_sp_24212, v_x_2412, v_x_2415, v_hd_2410, v_k_2411});
            }
            default: return heff_nomatch(v_it1_24210);
            }
          }
          default: return heff_nomatch(v_t_24183);
          }
        }
        case TAG_Just: {
          V v_it1_24213 = heff_field(v_t_24170, 0);
          heff_take_n(v_t_24170, 1ULL, 1);
          heff_drop(v_ms_241);
          heff_drop(v_w_240);
          heff_drop(v_uf_242);
          switch (heff_tag_of(v_it1_24213)) {
          case TAG_MkPair: {
            V v_m_24214 = heff_field(v_it1_24213, 0);
            V v_sp_24215 = heff_field(v_it1_24213, 1);
            heff_take_n(v_it1_24213, 3ULL, 2);
            return heff_tail(heff_get_n(v_r_243, 3, 9), 8, (V[]){v_g_244, v_cs_245, v_m_24214, v_sp_24215, v_x_2415, v_x_2412, v_hd_2410, v_k_2411});
          }
          default: return heff_nomatch(v_it1_24213);
          }
        }
        default: return heff_nomatch(v_t_24170);
        }
      }
      case TAG_VCons: {
        V v_t_24229;
        switch (heff_tag_of(v_x_2412)) {
        case TAG_VNeu: {
          V v_v1_24217 = heff_dup(heff_field(v_x_2412, 0));
          V v_sp_24218 = heff_dup(heff_field(v_x_2412, 1));
          switch (heff_tag_of(v_v1_24217)) {
          case TAG_HLocal: {
            heff_take_n(v_v1_24217, 0ULL, 1);
            heff_drop(v_sp_24218);
            v_t_24229 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HGlobal: {
            heff_take_n(v_v1_24217, 0ULL, 1);
            heff_drop(v_sp_24218);
            v_t_24229 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HMeta: {
            V v_m_24224 = heff_field(v_v1_24217, 0);
            V v_ru_24v1_24217_24HMeta = heff_take_reuse_n(v_v1_24217, 1ULL, 1);
            v_t_24229 = heff_tag_at_n(v_ru_24v1_24217_24HMeta, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_m_24224, v_sp_24218})});
            break;
          }
          case TAG_HError: {
            heff_drop(v_sp_24218);
            v_t_24229 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_v1_24217);
          }
          break;
        }
        case TAG_VCode: {
          v_t_24229 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VLam: {
          v_t_24229 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VCons: {
          v_t_24229 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VOpaque: {
          v_t_24229 = NTAG(TAG_Nothing);
          break;
        }
        default: heff_nomatch(v_x_2412);
        }
        switch (heff_tag_of(v_t_24229)) {
        case TAG_Nothing: {
          V v_t_24242;
          switch (heff_tag_of(v_x_2415)) {
          case TAG_VNeu: {
            V v_v1_24230 = heff_dup(heff_field(v_x_2415, 0));
            V v_sp_24231 = heff_dup(heff_field(v_x_2415, 1));
            switch (heff_tag_of(v_v1_24230)) {
            case TAG_HLocal: {
              heff_take_n(v_v1_24230, 0ULL, 1);
              heff_drop(v_sp_24231);
              v_t_24242 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HGlobal: {
              heff_take_n(v_v1_24230, 0ULL, 1);
              heff_drop(v_sp_24231);
              v_t_24242 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HMeta: {
              V v_m_24237 = heff_field(v_v1_24230, 0);
              V v_ru_24v1_24230_24HMeta = heff_take_reuse_n(v_v1_24230, 1ULL, 1);
              v_t_24242 = heff_tag_at_n(v_ru_24v1_24230_24HMeta, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_m_24237, v_sp_24231})});
              break;
            }
            case TAG_HError: {
              heff_drop(v_sp_24231);
              v_t_24242 = NTAG(TAG_Nothing);
              break;
            }
            default: heff_nomatch(v_v1_24230);
            }
            break;
          }
          case TAG_VCode: {
            v_t_24242 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VLam: {
            v_t_24242 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VCons: {
            v_t_24242 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VOpaque: {
            v_t_24242 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_x_2415);
          }
          switch (heff_tag_of(v_t_24242)) {
          case TAG_Nothing: {
            V v_t_24255;
            switch (heff_tag_of(v_x_2412)) {
            case TAG_VNeu: {
              V v_v1_24243 = heff_dup(heff_field(v_x_2412, 0));
              switch (heff_tag_of(v_v1_24243)) {
              case TAG_HLocal: {
                heff_take_n(v_v1_24243, 0ULL, 1);
                v_t_24255 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
                break;
              }
              case TAG_HGlobal: {
                heff_take_n(v_v1_24243, 0ULL, 1);
                v_t_24255 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
                break;
              }
              case TAG_HMeta: {
                heff_take_n(v_v1_24243, 0ULL, 1);
                v_t_24255 = heff_dup(v_x_2412);
                break;
              }
              case TAG_HError: {
                v_t_24255 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
                break;
              }
              default: heff_nomatch(v_v1_24243);
              }
              break;
            }
            case TAG_VCode: {
              v_t_24255 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
              break;
            }
            case TAG_VLam: {
              v_t_24255 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
              break;
            }
            case TAG_VCons: {
              v_t_24255 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
              break;
            }
            case TAG_VOpaque: {
              v_t_24255 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
              break;
            }
            default: heff_nomatch(v_x_2412);
            }
            V v_t_24268;
            switch (heff_tag_of(v_x_2415)) {
            case TAG_VNeu: {
              V v_v1_24256 = heff_dup(heff_field(v_x_2415, 0));
              switch (heff_tag_of(v_v1_24256)) {
              case TAG_HLocal: {
                heff_take_n(v_v1_24256, 0ULL, 1);
                v_t_24268 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
                break;
              }
              case TAG_HGlobal: {
                heff_take_n(v_v1_24256, 0ULL, 1);
                v_t_24268 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
                break;
              }
              case TAG_HMeta: {
                heff_take_n(v_v1_24256, 0ULL, 1);
                v_t_24268 = heff_dup(v_x_2415);
                break;
              }
              case TAG_HError: {
                v_t_24268 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
                break;
              }
              default: heff_nomatch(v_v1_24256);
              }
              break;
            }
            case TAG_VCode: {
              v_t_24268 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
              break;
            }
            case TAG_VLam: {
              v_t_24268 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
              break;
            }
            case TAG_VCons: {
              v_t_24268 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
              break;
            }
            case TAG_VOpaque: {
              v_t_24268 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
              break;
            }
            default: heff_nomatch(v_x_2415);
            }
            return ({ V a_0 = v_w_240; V a_1 = v_ms_241; V a_2 = v_uf_242; V a_3 = v_r_243; V a_4 = v_g_244; V a_5 = v_cs_245; V a_6 = v_t_24255; V a_7 = v_t_24268; V a_8 = v_x_2412; V a_9 = v_x_2415; V a_10 = v_hd_2410; V a_11 = v_k_2411; V r_ = (g_heff_2eelab_2eunify_2euElRigid(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9, a_10, a_11)); heff_drop(v_ms_241); r_; });
          }
          case TAG_Just: {
            V v_it1_24269 = heff_field(v_t_24242, 0);
            heff_take_n(v_t_24242, 1ULL, 1);
            heff_drop(v_ms_241);
            heff_drop(v_w_240);
            heff_drop(v_uf_242);
            switch (heff_tag_of(v_it1_24269)) {
            case TAG_MkPair: {
              V v_m_24270 = heff_field(v_it1_24269, 0);
              V v_sp_24271 = heff_field(v_it1_24269, 1);
              heff_take_n(v_it1_24269, 3ULL, 2);
              return heff_tail(heff_get_n(v_r_243, 3, 9), 8, (V[]){v_g_244, v_cs_245, v_m_24270, v_sp_24271, v_x_2412, v_x_2415, v_hd_2410, v_k_2411});
            }
            default: return heff_nomatch(v_it1_24269);
            }
          }
          default: return heff_nomatch(v_t_24242);
          }
        }
        case TAG_Just: {
          V v_it1_24272 = heff_field(v_t_24229, 0);
          heff_take_n(v_t_24229, 1ULL, 1);
          heff_drop(v_ms_241);
          heff_drop(v_w_240);
          heff_drop(v_uf_242);
          switch (heff_tag_of(v_it1_24272)) {
          case TAG_MkPair: {
            V v_m_24273 = heff_field(v_it1_24272, 0);
            V v_sp_24274 = heff_field(v_it1_24272, 1);
            heff_take_n(v_it1_24272, 3ULL, 2);
            return heff_tail(heff_get_n(v_r_243, 3, 9), 8, (V[]){v_g_244, v_cs_245, v_m_24273, v_sp_24274, v_x_2415, v_x_2412, v_hd_2410, v_k_2411});
          }
          default: return heff_nomatch(v_it1_24272);
          }
        }
        default: return heff_nomatch(v_t_24229);
        }
      }
      case TAG_VOpaque: {
        heff_drop_tag(v_x_2412, 5);
        heff_drop(v_ms_241);
        heff_drop(v_w_240);
        heff_drop(v_hd_2410);
        heff_drop_rec(v_cs_245, 2);
        heff_drop(v_uf_242);
        heff_drop_rec(v_r_243, 9);
        heff_drop(v_g_244);
        V f_ = v_k_2411;
        args[0] = NTAG(TAG_MkUnit);
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      }
      default: return heff_nomatch(v_x_2415);
      }
    }
    case TAG_VCode: {
      switch (heff_tag_of(v_x_2415)) {
      case TAG_VNeu: {
        V v_t_24293;
        switch (heff_tag_of(v_x_2412)) {
        case TAG_VNeu: {
          V v_v1_24281 = heff_dup(heff_field(v_x_2412, 0));
          V v_sp_24282 = heff_dup(heff_field(v_x_2412, 1));
          switch (heff_tag_of(v_v1_24281)) {
          case TAG_HLocal: {
            heff_take_n(v_v1_24281, 0ULL, 1);
            heff_drop(v_sp_24282);
            v_t_24293 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HGlobal: {
            heff_take_n(v_v1_24281, 0ULL, 1);
            heff_drop(v_sp_24282);
            v_t_24293 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HMeta: {
            V v_m_24288 = heff_field(v_v1_24281, 0);
            V v_ru_24v1_24281_24HMeta = heff_take_reuse_n(v_v1_24281, 1ULL, 1);
            v_t_24293 = heff_tag_at_n(v_ru_24v1_24281_24HMeta, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_m_24288, v_sp_24282})});
            break;
          }
          case TAG_HError: {
            heff_drop(v_sp_24282);
            v_t_24293 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_v1_24281);
          }
          break;
        }
        case TAG_VCode: {
          v_t_24293 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VLam: {
          v_t_24293 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VCons: {
          v_t_24293 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VOpaque: {
          v_t_24293 = NTAG(TAG_Nothing);
          break;
        }
        default: heff_nomatch(v_x_2412);
        }
        switch (heff_tag_of(v_t_24293)) {
        case TAG_Nothing: {
          V v_t_24306;
          switch (heff_tag_of(v_x_2415)) {
          case TAG_VNeu: {
            V v_v1_24294 = heff_dup(heff_field(v_x_2415, 0));
            V v_sp_24295 = heff_dup(heff_field(v_x_2415, 1));
            switch (heff_tag_of(v_v1_24294)) {
            case TAG_HLocal: {
              heff_take_n(v_v1_24294, 0ULL, 1);
              heff_drop(v_sp_24295);
              v_t_24306 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HGlobal: {
              heff_take_n(v_v1_24294, 0ULL, 1);
              heff_drop(v_sp_24295);
              v_t_24306 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HMeta: {
              V v_m_24301 = heff_field(v_v1_24294, 0);
              V v_ru_24v1_24294_24HMeta = heff_take_reuse_n(v_v1_24294, 1ULL, 1);
              v_t_24306 = heff_tag_at_n(v_ru_24v1_24294_24HMeta, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_m_24301, v_sp_24295})});
              break;
            }
            case TAG_HError: {
              heff_drop(v_sp_24295);
              v_t_24306 = NTAG(TAG_Nothing);
              break;
            }
            default: heff_nomatch(v_v1_24294);
            }
            break;
          }
          case TAG_VCode: {
            v_t_24306 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VLam: {
            v_t_24306 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VCons: {
            v_t_24306 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VOpaque: {
            v_t_24306 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_x_2415);
          }
          switch (heff_tag_of(v_t_24306)) {
          case TAG_Nothing: {
            V v_t_24319;
            switch (heff_tag_of(v_x_2412)) {
            case TAG_VNeu: {
              V v_v1_24307 = heff_dup(heff_field(v_x_2412, 0));
              switch (heff_tag_of(v_v1_24307)) {
              case TAG_HLocal: {
                heff_take_n(v_v1_24307, 0ULL, 1);
                v_t_24319 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
                break;
              }
              case TAG_HGlobal: {
                heff_take_n(v_v1_24307, 0ULL, 1);
                v_t_24319 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
                break;
              }
              case TAG_HMeta: {
                heff_take_n(v_v1_24307, 0ULL, 1);
                v_t_24319 = heff_dup(v_x_2412);
                break;
              }
              case TAG_HError: {
                v_t_24319 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
                break;
              }
              default: heff_nomatch(v_v1_24307);
              }
              break;
            }
            case TAG_VCode: {
              v_t_24319 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
              break;
            }
            case TAG_VLam: {
              v_t_24319 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
              break;
            }
            case TAG_VCons: {
              v_t_24319 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
              break;
            }
            case TAG_VOpaque: {
              v_t_24319 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
              break;
            }
            default: heff_nomatch(v_x_2412);
            }
            V v_t_24332;
            switch (heff_tag_of(v_x_2415)) {
            case TAG_VNeu: {
              V v_v1_24320 = heff_dup(heff_field(v_x_2415, 0));
              switch (heff_tag_of(v_v1_24320)) {
              case TAG_HLocal: {
                heff_take_n(v_v1_24320, 0ULL, 1);
                v_t_24332 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
                break;
              }
              case TAG_HGlobal: {
                heff_take_n(v_v1_24320, 0ULL, 1);
                v_t_24332 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
                break;
              }
              case TAG_HMeta: {
                heff_take_n(v_v1_24320, 0ULL, 1);
                v_t_24332 = heff_dup(v_x_2415);
                break;
              }
              case TAG_HError: {
                v_t_24332 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
                break;
              }
              default: heff_nomatch(v_v1_24320);
              }
              break;
            }
            case TAG_VCode: {
              v_t_24332 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
              break;
            }
            case TAG_VLam: {
              v_t_24332 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
              break;
            }
            case TAG_VCons: {
              v_t_24332 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
              break;
            }
            case TAG_VOpaque: {
              v_t_24332 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
              break;
            }
            default: heff_nomatch(v_x_2415);
            }
            return ({ V a_0 = v_w_240; V a_1 = v_ms_241; V a_2 = v_uf_242; V a_3 = v_r_243; V a_4 = v_g_244; V a_5 = v_cs_245; V a_6 = v_t_24319; V a_7 = v_t_24332; V a_8 = v_x_2412; V a_9 = v_x_2415; V a_10 = v_hd_2410; V a_11 = v_k_2411; V r_ = (g_heff_2eelab_2eunify_2euElRigid(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9, a_10, a_11)); heff_drop(v_ms_241); r_; });
          }
          case TAG_Just: {
            V v_it1_24333 = heff_field(v_t_24306, 0);
            heff_take_n(v_t_24306, 1ULL, 1);
            heff_drop(v_ms_241);
            heff_drop(v_w_240);
            heff_drop(v_uf_242);
            switch (heff_tag_of(v_it1_24333)) {
            case TAG_MkPair: {
              V v_m_24334 = heff_field(v_it1_24333, 0);
              V v_sp_24335 = heff_field(v_it1_24333, 1);
              heff_take_n(v_it1_24333, 3ULL, 2);
              return heff_tail(heff_get_n(v_r_243, 3, 9), 8, (V[]){v_g_244, v_cs_245, v_m_24334, v_sp_24335, v_x_2412, v_x_2415, v_hd_2410, v_k_2411});
            }
            default: return heff_nomatch(v_it1_24333);
            }
          }
          default: return heff_nomatch(v_t_24306);
          }
        }
        case TAG_Just: {
          V v_it1_24336 = heff_field(v_t_24293, 0);
          heff_take_n(v_t_24293, 1ULL, 1);
          heff_drop(v_ms_241);
          heff_drop(v_w_240);
          heff_drop(v_uf_242);
          switch (heff_tag_of(v_it1_24336)) {
          case TAG_MkPair: {
            V v_m_24337 = heff_field(v_it1_24336, 0);
            V v_sp_24338 = heff_field(v_it1_24336, 1);
            heff_take_n(v_it1_24336, 3ULL, 2);
            return heff_tail(heff_get_n(v_r_243, 3, 9), 8, (V[]){v_g_244, v_cs_245, v_m_24337, v_sp_24338, v_x_2415, v_x_2412, v_hd_2410, v_k_2411});
          }
          default: return heff_nomatch(v_it1_24336);
          }
        }
        default: return heff_nomatch(v_t_24293);
        }
      }
      case TAG_VCode: {
        V v_t_24352;
        switch (heff_tag_of(v_x_2412)) {
        case TAG_VNeu: {
          V v_v1_24340 = heff_dup(heff_field(v_x_2412, 0));
          V v_sp_24341 = heff_dup(heff_field(v_x_2412, 1));
          switch (heff_tag_of(v_v1_24340)) {
          case TAG_HLocal: {
            heff_take_n(v_v1_24340, 0ULL, 1);
            heff_drop(v_sp_24341);
            v_t_24352 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HGlobal: {
            heff_take_n(v_v1_24340, 0ULL, 1);
            heff_drop(v_sp_24341);
            v_t_24352 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HMeta: {
            V v_m_24347 = heff_field(v_v1_24340, 0);
            V v_ru_24v1_24340_24HMeta = heff_take_reuse_n(v_v1_24340, 1ULL, 1);
            v_t_24352 = heff_tag_at_n(v_ru_24v1_24340_24HMeta, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_m_24347, v_sp_24341})});
            break;
          }
          case TAG_HError: {
            heff_drop(v_sp_24341);
            v_t_24352 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_v1_24340);
          }
          break;
        }
        case TAG_VCode: {
          v_t_24352 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VLam: {
          v_t_24352 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VCons: {
          v_t_24352 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VOpaque: {
          v_t_24352 = NTAG(TAG_Nothing);
          break;
        }
        default: heff_nomatch(v_x_2412);
        }
        switch (heff_tag_of(v_t_24352)) {
        case TAG_Nothing: {
          V v_t_24365;
          switch (heff_tag_of(v_x_2415)) {
          case TAG_VNeu: {
            V v_v1_24353 = heff_dup(heff_field(v_x_2415, 0));
            V v_sp_24354 = heff_dup(heff_field(v_x_2415, 1));
            switch (heff_tag_of(v_v1_24353)) {
            case TAG_HLocal: {
              heff_take_n(v_v1_24353, 0ULL, 1);
              heff_drop(v_sp_24354);
              v_t_24365 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HGlobal: {
              heff_take_n(v_v1_24353, 0ULL, 1);
              heff_drop(v_sp_24354);
              v_t_24365 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HMeta: {
              V v_m_24360 = heff_field(v_v1_24353, 0);
              V v_ru_24v1_24353_24HMeta = heff_take_reuse_n(v_v1_24353, 1ULL, 1);
              v_t_24365 = heff_tag_at_n(v_ru_24v1_24353_24HMeta, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_m_24360, v_sp_24354})});
              break;
            }
            case TAG_HError: {
              heff_drop(v_sp_24354);
              v_t_24365 = NTAG(TAG_Nothing);
              break;
            }
            default: heff_nomatch(v_v1_24353);
            }
            break;
          }
          case TAG_VCode: {
            v_t_24365 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VLam: {
            v_t_24365 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VCons: {
            v_t_24365 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VOpaque: {
            v_t_24365 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_x_2415);
          }
          switch (heff_tag_of(v_t_24365)) {
          case TAG_Nothing: {
            V v_t_24378;
            switch (heff_tag_of(v_x_2412)) {
            case TAG_VNeu: {
              V v_v1_24366 = heff_dup(heff_field(v_x_2412, 0));
              switch (heff_tag_of(v_v1_24366)) {
              case TAG_HLocal: {
                heff_take_n(v_v1_24366, 0ULL, 1);
                v_t_24378 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
                break;
              }
              case TAG_HGlobal: {
                heff_take_n(v_v1_24366, 0ULL, 1);
                v_t_24378 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
                break;
              }
              case TAG_HMeta: {
                heff_take_n(v_v1_24366, 0ULL, 1);
                v_t_24378 = heff_dup(v_x_2412);
                break;
              }
              case TAG_HError: {
                v_t_24378 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
                break;
              }
              default: heff_nomatch(v_v1_24366);
              }
              break;
            }
            case TAG_VCode: {
              v_t_24378 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
              break;
            }
            case TAG_VLam: {
              v_t_24378 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
              break;
            }
            case TAG_VCons: {
              v_t_24378 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
              break;
            }
            case TAG_VOpaque: {
              v_t_24378 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
              break;
            }
            default: heff_nomatch(v_x_2412);
            }
            V v_t_24391;
            switch (heff_tag_of(v_x_2415)) {
            case TAG_VNeu: {
              V v_v1_24379 = heff_dup(heff_field(v_x_2415, 0));
              switch (heff_tag_of(v_v1_24379)) {
              case TAG_HLocal: {
                heff_take_n(v_v1_24379, 0ULL, 1);
                v_t_24391 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
                break;
              }
              case TAG_HGlobal: {
                heff_take_n(v_v1_24379, 0ULL, 1);
                v_t_24391 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
                break;
              }
              case TAG_HMeta: {
                heff_take_n(v_v1_24379, 0ULL, 1);
                v_t_24391 = heff_dup(v_x_2415);
                break;
              }
              case TAG_HError: {
                v_t_24391 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
                break;
              }
              default: heff_nomatch(v_v1_24379);
              }
              break;
            }
            case TAG_VCode: {
              v_t_24391 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
              break;
            }
            case TAG_VLam: {
              v_t_24391 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
              break;
            }
            case TAG_VCons: {
              v_t_24391 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
              break;
            }
            case TAG_VOpaque: {
              v_t_24391 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
              break;
            }
            default: heff_nomatch(v_x_2415);
            }
            return ({ V a_0 = v_w_240; V a_1 = v_ms_241; V a_2 = v_uf_242; V a_3 = v_r_243; V a_4 = v_g_244; V a_5 = v_cs_245; V a_6 = v_t_24378; V a_7 = v_t_24391; V a_8 = v_x_2412; V a_9 = v_x_2415; V a_10 = v_hd_2410; V a_11 = v_k_2411; V r_ = (g_heff_2eelab_2eunify_2euElRigid(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9, a_10, a_11)); heff_drop(v_ms_241); r_; });
          }
          case TAG_Just: {
            V v_it1_24392 = heff_field(v_t_24365, 0);
            heff_take_n(v_t_24365, 1ULL, 1);
            heff_drop(v_ms_241);
            heff_drop(v_w_240);
            heff_drop(v_uf_242);
            switch (heff_tag_of(v_it1_24392)) {
            case TAG_MkPair: {
              V v_m_24393 = heff_field(v_it1_24392, 0);
              V v_sp_24394 = heff_field(v_it1_24392, 1);
              heff_take_n(v_it1_24392, 3ULL, 2);
              return heff_tail(heff_get_n(v_r_243, 3, 9), 8, (V[]){v_g_244, v_cs_245, v_m_24393, v_sp_24394, v_x_2412, v_x_2415, v_hd_2410, v_k_2411});
            }
            default: return heff_nomatch(v_it1_24392);
            }
          }
          default: return heff_nomatch(v_t_24365);
          }
        }
        case TAG_Just: {
          V v_it1_24395 = heff_field(v_t_24352, 0);
          heff_take_n(v_t_24352, 1ULL, 1);
          heff_drop(v_ms_241);
          heff_drop(v_w_240);
          heff_drop(v_uf_242);
          switch (heff_tag_of(v_it1_24395)) {
          case TAG_MkPair: {
            V v_m_24396 = heff_field(v_it1_24395, 0);
            V v_sp_24397 = heff_field(v_it1_24395, 1);
            heff_take_n(v_it1_24395, 3ULL, 2);
            return heff_tail(heff_get_n(v_r_243, 3, 9), 8, (V[]){v_g_244, v_cs_245, v_m_24396, v_sp_24397, v_x_2415, v_x_2412, v_hd_2410, v_k_2411});
          }
          default: return heff_nomatch(v_it1_24395);
          }
        }
        default: return heff_nomatch(v_t_24352);
        }
      }
      case TAG_VLam: {
        V v_t_24412;
        switch (heff_tag_of(v_x_2412)) {
        case TAG_VNeu: {
          V v_v1_24400 = heff_dup(heff_field(v_x_2412, 0));
          V v_sp_24401 = heff_dup(heff_field(v_x_2412, 1));
          switch (heff_tag_of(v_v1_24400)) {
          case TAG_HLocal: {
            heff_take_n(v_v1_24400, 0ULL, 1);
            heff_drop(v_sp_24401);
            v_t_24412 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HGlobal: {
            heff_take_n(v_v1_24400, 0ULL, 1);
            heff_drop(v_sp_24401);
            v_t_24412 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HMeta: {
            V v_m_24407 = heff_field(v_v1_24400, 0);
            V v_ru_24v1_24400_24HMeta = heff_take_reuse_n(v_v1_24400, 1ULL, 1);
            v_t_24412 = heff_tag_at_n(v_ru_24v1_24400_24HMeta, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_m_24407, v_sp_24401})});
            break;
          }
          case TAG_HError: {
            heff_drop(v_sp_24401);
            v_t_24412 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_v1_24400);
          }
          break;
        }
        case TAG_VCode: {
          v_t_24412 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VLam: {
          v_t_24412 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VCons: {
          v_t_24412 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VOpaque: {
          v_t_24412 = NTAG(TAG_Nothing);
          break;
        }
        default: heff_nomatch(v_x_2412);
        }
        switch (heff_tag_of(v_t_24412)) {
        case TAG_Nothing: {
          V v_t_24425;
          switch (heff_tag_of(v_x_2415)) {
          case TAG_VNeu: {
            V v_v1_24413 = heff_dup(heff_field(v_x_2415, 0));
            V v_sp_24414 = heff_dup(heff_field(v_x_2415, 1));
            switch (heff_tag_of(v_v1_24413)) {
            case TAG_HLocal: {
              heff_take_n(v_v1_24413, 0ULL, 1);
              heff_drop(v_sp_24414);
              v_t_24425 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HGlobal: {
              heff_take_n(v_v1_24413, 0ULL, 1);
              heff_drop(v_sp_24414);
              v_t_24425 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HMeta: {
              V v_m_24420 = heff_field(v_v1_24413, 0);
              V v_ru_24v1_24413_24HMeta = heff_take_reuse_n(v_v1_24413, 1ULL, 1);
              v_t_24425 = heff_tag_at_n(v_ru_24v1_24413_24HMeta, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_m_24420, v_sp_24414})});
              break;
            }
            case TAG_HError: {
              heff_drop(v_sp_24414);
              v_t_24425 = NTAG(TAG_Nothing);
              break;
            }
            default: heff_nomatch(v_v1_24413);
            }
            break;
          }
          case TAG_VCode: {
            v_t_24425 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VLam: {
            v_t_24425 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VCons: {
            v_t_24425 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VOpaque: {
            v_t_24425 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_x_2415);
          }
          switch (heff_tag_of(v_t_24425)) {
          case TAG_Nothing: {
            V v_t_24438;
            switch (heff_tag_of(v_x_2412)) {
            case TAG_VNeu: {
              V v_v1_24426 = heff_dup(heff_field(v_x_2412, 0));
              switch (heff_tag_of(v_v1_24426)) {
              case TAG_HLocal: {
                heff_take_n(v_v1_24426, 0ULL, 1);
                v_t_24438 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
                break;
              }
              case TAG_HGlobal: {
                heff_take_n(v_v1_24426, 0ULL, 1);
                v_t_24438 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
                break;
              }
              case TAG_HMeta: {
                heff_take_n(v_v1_24426, 0ULL, 1);
                v_t_24438 = heff_dup(v_x_2412);
                break;
              }
              case TAG_HError: {
                v_t_24438 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
                break;
              }
              default: heff_nomatch(v_v1_24426);
              }
              break;
            }
            case TAG_VCode: {
              v_t_24438 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
              break;
            }
            case TAG_VLam: {
              v_t_24438 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
              break;
            }
            case TAG_VCons: {
              v_t_24438 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
              break;
            }
            case TAG_VOpaque: {
              v_t_24438 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
              break;
            }
            default: heff_nomatch(v_x_2412);
            }
            V v_t_24451;
            switch (heff_tag_of(v_x_2415)) {
            case TAG_VNeu: {
              V v_v1_24439 = heff_dup(heff_field(v_x_2415, 0));
              switch (heff_tag_of(v_v1_24439)) {
              case TAG_HLocal: {
                heff_take_n(v_v1_24439, 0ULL, 1);
                v_t_24451 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
                break;
              }
              case TAG_HGlobal: {
                heff_take_n(v_v1_24439, 0ULL, 1);
                v_t_24451 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
                break;
              }
              case TAG_HMeta: {
                heff_take_n(v_v1_24439, 0ULL, 1);
                v_t_24451 = heff_dup(v_x_2415);
                break;
              }
              case TAG_HError: {
                v_t_24451 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
                break;
              }
              default: heff_nomatch(v_v1_24439);
              }
              break;
            }
            case TAG_VCode: {
              v_t_24451 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
              break;
            }
            case TAG_VLam: {
              v_t_24451 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
              break;
            }
            case TAG_VCons: {
              v_t_24451 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
              break;
            }
            case TAG_VOpaque: {
              v_t_24451 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
              break;
            }
            default: heff_nomatch(v_x_2415);
            }
            return ({ V a_0 = v_w_240; V a_1 = v_ms_241; V a_2 = v_uf_242; V a_3 = v_r_243; V a_4 = v_g_244; V a_5 = v_cs_245; V a_6 = v_t_24438; V a_7 = v_t_24451; V a_8 = v_x_2412; V a_9 = v_x_2415; V a_10 = v_hd_2410; V a_11 = v_k_2411; V r_ = (g_heff_2eelab_2eunify_2euElRigid(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9, a_10, a_11)); heff_drop(v_ms_241); r_; });
          }
          case TAG_Just: {
            V v_it1_24452 = heff_field(v_t_24425, 0);
            heff_take_n(v_t_24425, 1ULL, 1);
            heff_drop(v_ms_241);
            heff_drop(v_w_240);
            heff_drop(v_uf_242);
            switch (heff_tag_of(v_it1_24452)) {
            case TAG_MkPair: {
              V v_m_24453 = heff_field(v_it1_24452, 0);
              V v_sp_24454 = heff_field(v_it1_24452, 1);
              heff_take_n(v_it1_24452, 3ULL, 2);
              return heff_tail(heff_get_n(v_r_243, 3, 9), 8, (V[]){v_g_244, v_cs_245, v_m_24453, v_sp_24454, v_x_2412, v_x_2415, v_hd_2410, v_k_2411});
            }
            default: return heff_nomatch(v_it1_24452);
            }
          }
          default: return heff_nomatch(v_t_24425);
          }
        }
        case TAG_Just: {
          V v_it1_24455 = heff_field(v_t_24412, 0);
          heff_take_n(v_t_24412, 1ULL, 1);
          heff_drop(v_ms_241);
          heff_drop(v_w_240);
          heff_drop(v_uf_242);
          switch (heff_tag_of(v_it1_24455)) {
          case TAG_MkPair: {
            V v_m_24456 = heff_field(v_it1_24455, 0);
            V v_sp_24457 = heff_field(v_it1_24455, 1);
            heff_take_n(v_it1_24455, 3ULL, 2);
            return heff_tail(heff_get_n(v_r_243, 3, 9), 8, (V[]){v_g_244, v_cs_245, v_m_24456, v_sp_24457, v_x_2415, v_x_2412, v_hd_2410, v_k_2411});
          }
          default: return heff_nomatch(v_it1_24455);
          }
        }
        default: return heff_nomatch(v_t_24412);
        }
      }
      case TAG_VCons: {
        V v_t_24471;
        switch (heff_tag_of(v_x_2412)) {
        case TAG_VNeu: {
          V v_v1_24459 = heff_dup(heff_field(v_x_2412, 0));
          V v_sp_24460 = heff_dup(heff_field(v_x_2412, 1));
          switch (heff_tag_of(v_v1_24459)) {
          case TAG_HLocal: {
            heff_take_n(v_v1_24459, 0ULL, 1);
            heff_drop(v_sp_24460);
            v_t_24471 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HGlobal: {
            heff_take_n(v_v1_24459, 0ULL, 1);
            heff_drop(v_sp_24460);
            v_t_24471 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HMeta: {
            V v_m_24466 = heff_field(v_v1_24459, 0);
            V v_ru_24v1_24459_24HMeta = heff_take_reuse_n(v_v1_24459, 1ULL, 1);
            v_t_24471 = heff_tag_at_n(v_ru_24v1_24459_24HMeta, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_m_24466, v_sp_24460})});
            break;
          }
          case TAG_HError: {
            heff_drop(v_sp_24460);
            v_t_24471 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_v1_24459);
          }
          break;
        }
        case TAG_VCode: {
          v_t_24471 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VLam: {
          v_t_24471 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VCons: {
          v_t_24471 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VOpaque: {
          v_t_24471 = NTAG(TAG_Nothing);
          break;
        }
        default: heff_nomatch(v_x_2412);
        }
        switch (heff_tag_of(v_t_24471)) {
        case TAG_Nothing: {
          V v_t_24484;
          switch (heff_tag_of(v_x_2415)) {
          case TAG_VNeu: {
            V v_v1_24472 = heff_dup(heff_field(v_x_2415, 0));
            V v_sp_24473 = heff_dup(heff_field(v_x_2415, 1));
            switch (heff_tag_of(v_v1_24472)) {
            case TAG_HLocal: {
              heff_take_n(v_v1_24472, 0ULL, 1);
              heff_drop(v_sp_24473);
              v_t_24484 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HGlobal: {
              heff_take_n(v_v1_24472, 0ULL, 1);
              heff_drop(v_sp_24473);
              v_t_24484 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HMeta: {
              V v_m_24479 = heff_field(v_v1_24472, 0);
              V v_ru_24v1_24472_24HMeta = heff_take_reuse_n(v_v1_24472, 1ULL, 1);
              v_t_24484 = heff_tag_at_n(v_ru_24v1_24472_24HMeta, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_m_24479, v_sp_24473})});
              break;
            }
            case TAG_HError: {
              heff_drop(v_sp_24473);
              v_t_24484 = NTAG(TAG_Nothing);
              break;
            }
            default: heff_nomatch(v_v1_24472);
            }
            break;
          }
          case TAG_VCode: {
            v_t_24484 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VLam: {
            v_t_24484 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VCons: {
            v_t_24484 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VOpaque: {
            v_t_24484 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_x_2415);
          }
          switch (heff_tag_of(v_t_24484)) {
          case TAG_Nothing: {
            V v_t_24497;
            switch (heff_tag_of(v_x_2412)) {
            case TAG_VNeu: {
              V v_v1_24485 = heff_dup(heff_field(v_x_2412, 0));
              switch (heff_tag_of(v_v1_24485)) {
              case TAG_HLocal: {
                heff_take_n(v_v1_24485, 0ULL, 1);
                v_t_24497 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
                break;
              }
              case TAG_HGlobal: {
                heff_take_n(v_v1_24485, 0ULL, 1);
                v_t_24497 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
                break;
              }
              case TAG_HMeta: {
                heff_take_n(v_v1_24485, 0ULL, 1);
                v_t_24497 = heff_dup(v_x_2412);
                break;
              }
              case TAG_HError: {
                v_t_24497 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
                break;
              }
              default: heff_nomatch(v_v1_24485);
              }
              break;
            }
            case TAG_VCode: {
              v_t_24497 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
              break;
            }
            case TAG_VLam: {
              v_t_24497 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
              break;
            }
            case TAG_VCons: {
              v_t_24497 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
              break;
            }
            case TAG_VOpaque: {
              v_t_24497 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
              break;
            }
            default: heff_nomatch(v_x_2412);
            }
            V v_t_24510;
            switch (heff_tag_of(v_x_2415)) {
            case TAG_VNeu: {
              V v_v1_24498 = heff_dup(heff_field(v_x_2415, 0));
              switch (heff_tag_of(v_v1_24498)) {
              case TAG_HLocal: {
                heff_take_n(v_v1_24498, 0ULL, 1);
                v_t_24510 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
                break;
              }
              case TAG_HGlobal: {
                heff_take_n(v_v1_24498, 0ULL, 1);
                v_t_24510 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
                break;
              }
              case TAG_HMeta: {
                heff_take_n(v_v1_24498, 0ULL, 1);
                v_t_24510 = heff_dup(v_x_2415);
                break;
              }
              case TAG_HError: {
                v_t_24510 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
                break;
              }
              default: heff_nomatch(v_v1_24498);
              }
              break;
            }
            case TAG_VCode: {
              v_t_24510 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
              break;
            }
            case TAG_VLam: {
              v_t_24510 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
              break;
            }
            case TAG_VCons: {
              v_t_24510 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
              break;
            }
            case TAG_VOpaque: {
              v_t_24510 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
              break;
            }
            default: heff_nomatch(v_x_2415);
            }
            return ({ V a_0 = v_w_240; V a_1 = v_ms_241; V a_2 = v_uf_242; V a_3 = v_r_243; V a_4 = v_g_244; V a_5 = v_cs_245; V a_6 = v_t_24497; V a_7 = v_t_24510; V a_8 = v_x_2412; V a_9 = v_x_2415; V a_10 = v_hd_2410; V a_11 = v_k_2411; V r_ = (g_heff_2eelab_2eunify_2euElRigid(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9, a_10, a_11)); heff_drop(v_ms_241); r_; });
          }
          case TAG_Just: {
            V v_it1_24511 = heff_field(v_t_24484, 0);
            heff_take_n(v_t_24484, 1ULL, 1);
            heff_drop(v_ms_241);
            heff_drop(v_w_240);
            heff_drop(v_uf_242);
            switch (heff_tag_of(v_it1_24511)) {
            case TAG_MkPair: {
              V v_m_24512 = heff_field(v_it1_24511, 0);
              V v_sp_24513 = heff_field(v_it1_24511, 1);
              heff_take_n(v_it1_24511, 3ULL, 2);
              return heff_tail(heff_get_n(v_r_243, 3, 9), 8, (V[]){v_g_244, v_cs_245, v_m_24512, v_sp_24513, v_x_2412, v_x_2415, v_hd_2410, v_k_2411});
            }
            default: return heff_nomatch(v_it1_24511);
            }
          }
          default: return heff_nomatch(v_t_24484);
          }
        }
        case TAG_Just: {
          V v_it1_24514 = heff_field(v_t_24471, 0);
          heff_take_n(v_t_24471, 1ULL, 1);
          heff_drop(v_ms_241);
          heff_drop(v_w_240);
          heff_drop(v_uf_242);
          switch (heff_tag_of(v_it1_24514)) {
          case TAG_MkPair: {
            V v_m_24515 = heff_field(v_it1_24514, 0);
            V v_sp_24516 = heff_field(v_it1_24514, 1);
            heff_take_n(v_it1_24514, 3ULL, 2);
            return heff_tail(heff_get_n(v_r_243, 3, 9), 8, (V[]){v_g_244, v_cs_245, v_m_24515, v_sp_24516, v_x_2415, v_x_2412, v_hd_2410, v_k_2411});
          }
          default: return heff_nomatch(v_it1_24514);
          }
        }
        default: return heff_nomatch(v_t_24471);
        }
      }
      case TAG_VOpaque: {
        heff_drop_tag(v_x_2412, 1);
        heff_drop(v_ms_241);
        heff_drop(v_w_240);
        heff_drop(v_hd_2410);
        heff_drop_rec(v_cs_245, 2);
        heff_drop(v_uf_242);
        heff_drop_rec(v_r_243, 9);
        heff_drop(v_g_244);
        V f_ = v_k_2411;
        args[0] = NTAG(TAG_MkUnit);
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      }
      default: return heff_nomatch(v_x_2415);
      }
    }
    case TAG_VLam: {
      switch (heff_tag_of(v_x_2415)) {
      case TAG_VNeu: {
        V v_t_24536;
        switch (heff_tag_of(v_x_2412)) {
        case TAG_VNeu: {
          V v_v1_24524 = heff_dup(heff_field(v_x_2412, 0));
          V v_sp_24525 = heff_dup(heff_field(v_x_2412, 1));
          switch (heff_tag_of(v_v1_24524)) {
          case TAG_HLocal: {
            heff_take_n(v_v1_24524, 0ULL, 1);
            heff_drop(v_sp_24525);
            v_t_24536 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HGlobal: {
            heff_take_n(v_v1_24524, 0ULL, 1);
            heff_drop(v_sp_24525);
            v_t_24536 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HMeta: {
            V v_m_24531 = heff_field(v_v1_24524, 0);
            V v_ru_24v1_24524_24HMeta = heff_take_reuse_n(v_v1_24524, 1ULL, 1);
            v_t_24536 = heff_tag_at_n(v_ru_24v1_24524_24HMeta, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_m_24531, v_sp_24525})});
            break;
          }
          case TAG_HError: {
            heff_drop(v_sp_24525);
            v_t_24536 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_v1_24524);
          }
          break;
        }
        case TAG_VCode: {
          v_t_24536 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VLam: {
          v_t_24536 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VCons: {
          v_t_24536 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VOpaque: {
          v_t_24536 = NTAG(TAG_Nothing);
          break;
        }
        default: heff_nomatch(v_x_2412);
        }
        switch (heff_tag_of(v_t_24536)) {
        case TAG_Nothing: {
          V v_t_24549;
          switch (heff_tag_of(v_x_2415)) {
          case TAG_VNeu: {
            V v_v1_24537 = heff_dup(heff_field(v_x_2415, 0));
            V v_sp_24538 = heff_dup(heff_field(v_x_2415, 1));
            switch (heff_tag_of(v_v1_24537)) {
            case TAG_HLocal: {
              heff_take_n(v_v1_24537, 0ULL, 1);
              heff_drop(v_sp_24538);
              v_t_24549 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HGlobal: {
              heff_take_n(v_v1_24537, 0ULL, 1);
              heff_drop(v_sp_24538);
              v_t_24549 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HMeta: {
              V v_m_24544 = heff_field(v_v1_24537, 0);
              V v_ru_24v1_24537_24HMeta = heff_take_reuse_n(v_v1_24537, 1ULL, 1);
              v_t_24549 = heff_tag_at_n(v_ru_24v1_24537_24HMeta, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_m_24544, v_sp_24538})});
              break;
            }
            case TAG_HError: {
              heff_drop(v_sp_24538);
              v_t_24549 = NTAG(TAG_Nothing);
              break;
            }
            default: heff_nomatch(v_v1_24537);
            }
            break;
          }
          case TAG_VCode: {
            v_t_24549 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VLam: {
            v_t_24549 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VCons: {
            v_t_24549 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VOpaque: {
            v_t_24549 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_x_2415);
          }
          switch (heff_tag_of(v_t_24549)) {
          case TAG_Nothing: {
            V v_t_24562;
            switch (heff_tag_of(v_x_2412)) {
            case TAG_VNeu: {
              V v_v1_24550 = heff_dup(heff_field(v_x_2412, 0));
              switch (heff_tag_of(v_v1_24550)) {
              case TAG_HLocal: {
                heff_take_n(v_v1_24550, 0ULL, 1);
                v_t_24562 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
                break;
              }
              case TAG_HGlobal: {
                heff_take_n(v_v1_24550, 0ULL, 1);
                v_t_24562 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
                break;
              }
              case TAG_HMeta: {
                heff_take_n(v_v1_24550, 0ULL, 1);
                v_t_24562 = heff_dup(v_x_2412);
                break;
              }
              case TAG_HError: {
                v_t_24562 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
                break;
              }
              default: heff_nomatch(v_v1_24550);
              }
              break;
            }
            case TAG_VCode: {
              v_t_24562 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
              break;
            }
            case TAG_VLam: {
              v_t_24562 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
              break;
            }
            case TAG_VCons: {
              v_t_24562 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
              break;
            }
            case TAG_VOpaque: {
              v_t_24562 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
              break;
            }
            default: heff_nomatch(v_x_2412);
            }
            V v_t_24575;
            switch (heff_tag_of(v_x_2415)) {
            case TAG_VNeu: {
              V v_v1_24563 = heff_dup(heff_field(v_x_2415, 0));
              switch (heff_tag_of(v_v1_24563)) {
              case TAG_HLocal: {
                heff_take_n(v_v1_24563, 0ULL, 1);
                v_t_24575 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
                break;
              }
              case TAG_HGlobal: {
                heff_take_n(v_v1_24563, 0ULL, 1);
                v_t_24575 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
                break;
              }
              case TAG_HMeta: {
                heff_take_n(v_v1_24563, 0ULL, 1);
                v_t_24575 = heff_dup(v_x_2415);
                break;
              }
              case TAG_HError: {
                v_t_24575 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
                break;
              }
              default: heff_nomatch(v_v1_24563);
              }
              break;
            }
            case TAG_VCode: {
              v_t_24575 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
              break;
            }
            case TAG_VLam: {
              v_t_24575 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
              break;
            }
            case TAG_VCons: {
              v_t_24575 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
              break;
            }
            case TAG_VOpaque: {
              v_t_24575 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
              break;
            }
            default: heff_nomatch(v_x_2415);
            }
            return ({ V a_0 = v_w_240; V a_1 = v_ms_241; V a_2 = v_uf_242; V a_3 = v_r_243; V a_4 = v_g_244; V a_5 = v_cs_245; V a_6 = v_t_24562; V a_7 = v_t_24575; V a_8 = v_x_2412; V a_9 = v_x_2415; V a_10 = v_hd_2410; V a_11 = v_k_2411; V r_ = (g_heff_2eelab_2eunify_2euElRigid(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9, a_10, a_11)); heff_drop(v_ms_241); r_; });
          }
          case TAG_Just: {
            V v_it1_24576 = heff_field(v_t_24549, 0);
            heff_take_n(v_t_24549, 1ULL, 1);
            heff_drop(v_ms_241);
            heff_drop(v_w_240);
            heff_drop(v_uf_242);
            switch (heff_tag_of(v_it1_24576)) {
            case TAG_MkPair: {
              V v_m_24577 = heff_field(v_it1_24576, 0);
              V v_sp_24578 = heff_field(v_it1_24576, 1);
              heff_take_n(v_it1_24576, 3ULL, 2);
              return heff_tail(heff_get_n(v_r_243, 3, 9), 8, (V[]){v_g_244, v_cs_245, v_m_24577, v_sp_24578, v_x_2412, v_x_2415, v_hd_2410, v_k_2411});
            }
            default: return heff_nomatch(v_it1_24576);
            }
          }
          default: return heff_nomatch(v_t_24549);
          }
        }
        case TAG_Just: {
          V v_it1_24579 = heff_field(v_t_24536, 0);
          heff_take_n(v_t_24536, 1ULL, 1);
          heff_drop(v_ms_241);
          heff_drop(v_w_240);
          heff_drop(v_uf_242);
          switch (heff_tag_of(v_it1_24579)) {
          case TAG_MkPair: {
            V v_m_24580 = heff_field(v_it1_24579, 0);
            V v_sp_24581 = heff_field(v_it1_24579, 1);
            heff_take_n(v_it1_24579, 3ULL, 2);
            return heff_tail(heff_get_n(v_r_243, 3, 9), 8, (V[]){v_g_244, v_cs_245, v_m_24580, v_sp_24581, v_x_2415, v_x_2412, v_hd_2410, v_k_2411});
          }
          default: return heff_nomatch(v_it1_24579);
          }
        }
        default: return heff_nomatch(v_t_24536);
        }
      }
      case TAG_VCode: {
        V v_t_24595;
        switch (heff_tag_of(v_x_2412)) {
        case TAG_VNeu: {
          V v_v1_24583 = heff_dup(heff_field(v_x_2412, 0));
          V v_sp_24584 = heff_dup(heff_field(v_x_2412, 1));
          switch (heff_tag_of(v_v1_24583)) {
          case TAG_HLocal: {
            heff_take_n(v_v1_24583, 0ULL, 1);
            heff_drop(v_sp_24584);
            v_t_24595 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HGlobal: {
            heff_take_n(v_v1_24583, 0ULL, 1);
            heff_drop(v_sp_24584);
            v_t_24595 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HMeta: {
            V v_m_24590 = heff_field(v_v1_24583, 0);
            V v_ru_24v1_24583_24HMeta = heff_take_reuse_n(v_v1_24583, 1ULL, 1);
            v_t_24595 = heff_tag_at_n(v_ru_24v1_24583_24HMeta, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_m_24590, v_sp_24584})});
            break;
          }
          case TAG_HError: {
            heff_drop(v_sp_24584);
            v_t_24595 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_v1_24583);
          }
          break;
        }
        case TAG_VCode: {
          v_t_24595 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VLam: {
          v_t_24595 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VCons: {
          v_t_24595 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VOpaque: {
          v_t_24595 = NTAG(TAG_Nothing);
          break;
        }
        default: heff_nomatch(v_x_2412);
        }
        switch (heff_tag_of(v_t_24595)) {
        case TAG_Nothing: {
          V v_t_24608;
          switch (heff_tag_of(v_x_2415)) {
          case TAG_VNeu: {
            V v_v1_24596 = heff_dup(heff_field(v_x_2415, 0));
            V v_sp_24597 = heff_dup(heff_field(v_x_2415, 1));
            switch (heff_tag_of(v_v1_24596)) {
            case TAG_HLocal: {
              heff_take_n(v_v1_24596, 0ULL, 1);
              heff_drop(v_sp_24597);
              v_t_24608 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HGlobal: {
              heff_take_n(v_v1_24596, 0ULL, 1);
              heff_drop(v_sp_24597);
              v_t_24608 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HMeta: {
              V v_m_24603 = heff_field(v_v1_24596, 0);
              V v_ru_24v1_24596_24HMeta = heff_take_reuse_n(v_v1_24596, 1ULL, 1);
              v_t_24608 = heff_tag_at_n(v_ru_24v1_24596_24HMeta, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_m_24603, v_sp_24597})});
              break;
            }
            case TAG_HError: {
              heff_drop(v_sp_24597);
              v_t_24608 = NTAG(TAG_Nothing);
              break;
            }
            default: heff_nomatch(v_v1_24596);
            }
            break;
          }
          case TAG_VCode: {
            v_t_24608 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VLam: {
            v_t_24608 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VCons: {
            v_t_24608 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VOpaque: {
            v_t_24608 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_x_2415);
          }
          switch (heff_tag_of(v_t_24608)) {
          case TAG_Nothing: {
            V v_t_24621;
            switch (heff_tag_of(v_x_2412)) {
            case TAG_VNeu: {
              V v_v1_24609 = heff_dup(heff_field(v_x_2412, 0));
              switch (heff_tag_of(v_v1_24609)) {
              case TAG_HLocal: {
                heff_take_n(v_v1_24609, 0ULL, 1);
                v_t_24621 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
                break;
              }
              case TAG_HGlobal: {
                heff_take_n(v_v1_24609, 0ULL, 1);
                v_t_24621 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
                break;
              }
              case TAG_HMeta: {
                heff_take_n(v_v1_24609, 0ULL, 1);
                v_t_24621 = heff_dup(v_x_2412);
                break;
              }
              case TAG_HError: {
                v_t_24621 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
                break;
              }
              default: heff_nomatch(v_v1_24609);
              }
              break;
            }
            case TAG_VCode: {
              v_t_24621 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
              break;
            }
            case TAG_VLam: {
              v_t_24621 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
              break;
            }
            case TAG_VCons: {
              v_t_24621 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
              break;
            }
            case TAG_VOpaque: {
              v_t_24621 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
              break;
            }
            default: heff_nomatch(v_x_2412);
            }
            V v_t_24634;
            switch (heff_tag_of(v_x_2415)) {
            case TAG_VNeu: {
              V v_v1_24622 = heff_dup(heff_field(v_x_2415, 0));
              switch (heff_tag_of(v_v1_24622)) {
              case TAG_HLocal: {
                heff_take_n(v_v1_24622, 0ULL, 1);
                v_t_24634 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
                break;
              }
              case TAG_HGlobal: {
                heff_take_n(v_v1_24622, 0ULL, 1);
                v_t_24634 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
                break;
              }
              case TAG_HMeta: {
                heff_take_n(v_v1_24622, 0ULL, 1);
                v_t_24634 = heff_dup(v_x_2415);
                break;
              }
              case TAG_HError: {
                v_t_24634 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
                break;
              }
              default: heff_nomatch(v_v1_24622);
              }
              break;
            }
            case TAG_VCode: {
              v_t_24634 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
              break;
            }
            case TAG_VLam: {
              v_t_24634 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
              break;
            }
            case TAG_VCons: {
              v_t_24634 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
              break;
            }
            case TAG_VOpaque: {
              v_t_24634 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
              break;
            }
            default: heff_nomatch(v_x_2415);
            }
            return ({ V a_0 = v_w_240; V a_1 = v_ms_241; V a_2 = v_uf_242; V a_3 = v_r_243; V a_4 = v_g_244; V a_5 = v_cs_245; V a_6 = v_t_24621; V a_7 = v_t_24634; V a_8 = v_x_2412; V a_9 = v_x_2415; V a_10 = v_hd_2410; V a_11 = v_k_2411; V r_ = (g_heff_2eelab_2eunify_2euElRigid(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9, a_10, a_11)); heff_drop(v_ms_241); r_; });
          }
          case TAG_Just: {
            V v_it1_24635 = heff_field(v_t_24608, 0);
            heff_take_n(v_t_24608, 1ULL, 1);
            heff_drop(v_ms_241);
            heff_drop(v_w_240);
            heff_drop(v_uf_242);
            switch (heff_tag_of(v_it1_24635)) {
            case TAG_MkPair: {
              V v_m_24636 = heff_field(v_it1_24635, 0);
              V v_sp_24637 = heff_field(v_it1_24635, 1);
              heff_take_n(v_it1_24635, 3ULL, 2);
              return heff_tail(heff_get_n(v_r_243, 3, 9), 8, (V[]){v_g_244, v_cs_245, v_m_24636, v_sp_24637, v_x_2412, v_x_2415, v_hd_2410, v_k_2411});
            }
            default: return heff_nomatch(v_it1_24635);
            }
          }
          default: return heff_nomatch(v_t_24608);
          }
        }
        case TAG_Just: {
          V v_it1_24638 = heff_field(v_t_24595, 0);
          heff_take_n(v_t_24595, 1ULL, 1);
          heff_drop(v_ms_241);
          heff_drop(v_w_240);
          heff_drop(v_uf_242);
          switch (heff_tag_of(v_it1_24638)) {
          case TAG_MkPair: {
            V v_m_24639 = heff_field(v_it1_24638, 0);
            V v_sp_24640 = heff_field(v_it1_24638, 1);
            heff_take_n(v_it1_24638, 3ULL, 2);
            return heff_tail(heff_get_n(v_r_243, 3, 9), 8, (V[]){v_g_244, v_cs_245, v_m_24639, v_sp_24640, v_x_2415, v_x_2412, v_hd_2410, v_k_2411});
          }
          default: return heff_nomatch(v_it1_24638);
          }
        }
        default: return heff_nomatch(v_t_24595);
        }
      }
      case TAG_VLam: {
        V v_t_24655;
        switch (heff_tag_of(v_x_2412)) {
        case TAG_VNeu: {
          V v_v1_24643 = heff_dup(heff_field(v_x_2412, 0));
          V v_sp_24644 = heff_dup(heff_field(v_x_2412, 1));
          switch (heff_tag_of(v_v1_24643)) {
          case TAG_HLocal: {
            heff_take_n(v_v1_24643, 0ULL, 1);
            heff_drop(v_sp_24644);
            v_t_24655 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HGlobal: {
            heff_take_n(v_v1_24643, 0ULL, 1);
            heff_drop(v_sp_24644);
            v_t_24655 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HMeta: {
            V v_m_24650 = heff_field(v_v1_24643, 0);
            V v_ru_24v1_24643_24HMeta = heff_take_reuse_n(v_v1_24643, 1ULL, 1);
            v_t_24655 = heff_tag_at_n(v_ru_24v1_24643_24HMeta, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_m_24650, v_sp_24644})});
            break;
          }
          case TAG_HError: {
            heff_drop(v_sp_24644);
            v_t_24655 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_v1_24643);
          }
          break;
        }
        case TAG_VCode: {
          v_t_24655 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VLam: {
          v_t_24655 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VCons: {
          v_t_24655 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VOpaque: {
          v_t_24655 = NTAG(TAG_Nothing);
          break;
        }
        default: heff_nomatch(v_x_2412);
        }
        switch (heff_tag_of(v_t_24655)) {
        case TAG_Nothing: {
          V v_t_24668;
          switch (heff_tag_of(v_x_2415)) {
          case TAG_VNeu: {
            V v_v1_24656 = heff_dup(heff_field(v_x_2415, 0));
            V v_sp_24657 = heff_dup(heff_field(v_x_2415, 1));
            switch (heff_tag_of(v_v1_24656)) {
            case TAG_HLocal: {
              heff_take_n(v_v1_24656, 0ULL, 1);
              heff_drop(v_sp_24657);
              v_t_24668 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HGlobal: {
              heff_take_n(v_v1_24656, 0ULL, 1);
              heff_drop(v_sp_24657);
              v_t_24668 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HMeta: {
              V v_m_24663 = heff_field(v_v1_24656, 0);
              V v_ru_24v1_24656_24HMeta = heff_take_reuse_n(v_v1_24656, 1ULL, 1);
              v_t_24668 = heff_tag_at_n(v_ru_24v1_24656_24HMeta, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_m_24663, v_sp_24657})});
              break;
            }
            case TAG_HError: {
              heff_drop(v_sp_24657);
              v_t_24668 = NTAG(TAG_Nothing);
              break;
            }
            default: heff_nomatch(v_v1_24656);
            }
            break;
          }
          case TAG_VCode: {
            v_t_24668 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VLam: {
            v_t_24668 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VCons: {
            v_t_24668 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VOpaque: {
            v_t_24668 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_x_2415);
          }
          switch (heff_tag_of(v_t_24668)) {
          case TAG_Nothing: {
            V v_t_24681;
            switch (heff_tag_of(v_x_2412)) {
            case TAG_VNeu: {
              V v_v1_24669 = heff_dup(heff_field(v_x_2412, 0));
              switch (heff_tag_of(v_v1_24669)) {
              case TAG_HLocal: {
                heff_take_n(v_v1_24669, 0ULL, 1);
                v_t_24681 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
                break;
              }
              case TAG_HGlobal: {
                heff_take_n(v_v1_24669, 0ULL, 1);
                v_t_24681 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
                break;
              }
              case TAG_HMeta: {
                heff_take_n(v_v1_24669, 0ULL, 1);
                v_t_24681 = heff_dup(v_x_2412);
                break;
              }
              case TAG_HError: {
                v_t_24681 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
                break;
              }
              default: heff_nomatch(v_v1_24669);
              }
              break;
            }
            case TAG_VCode: {
              v_t_24681 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
              break;
            }
            case TAG_VLam: {
              v_t_24681 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
              break;
            }
            case TAG_VCons: {
              v_t_24681 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
              break;
            }
            case TAG_VOpaque: {
              v_t_24681 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
              break;
            }
            default: heff_nomatch(v_x_2412);
            }
            V v_t_24694;
            switch (heff_tag_of(v_x_2415)) {
            case TAG_VNeu: {
              V v_v1_24682 = heff_dup(heff_field(v_x_2415, 0));
              switch (heff_tag_of(v_v1_24682)) {
              case TAG_HLocal: {
                heff_take_n(v_v1_24682, 0ULL, 1);
                v_t_24694 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
                break;
              }
              case TAG_HGlobal: {
                heff_take_n(v_v1_24682, 0ULL, 1);
                v_t_24694 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
                break;
              }
              case TAG_HMeta: {
                heff_take_n(v_v1_24682, 0ULL, 1);
                v_t_24694 = heff_dup(v_x_2415);
                break;
              }
              case TAG_HError: {
                v_t_24694 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
                break;
              }
              default: heff_nomatch(v_v1_24682);
              }
              break;
            }
            case TAG_VCode: {
              v_t_24694 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
              break;
            }
            case TAG_VLam: {
              v_t_24694 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
              break;
            }
            case TAG_VCons: {
              v_t_24694 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
              break;
            }
            case TAG_VOpaque: {
              v_t_24694 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
              break;
            }
            default: heff_nomatch(v_x_2415);
            }
            return ({ V a_0 = v_w_240; V a_1 = v_ms_241; V a_2 = v_uf_242; V a_3 = v_r_243; V a_4 = v_g_244; V a_5 = v_cs_245; V a_6 = v_t_24681; V a_7 = v_t_24694; V a_8 = v_x_2412; V a_9 = v_x_2415; V a_10 = v_hd_2410; V a_11 = v_k_2411; V r_ = (g_heff_2eelab_2eunify_2euElRigid(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9, a_10, a_11)); heff_drop(v_ms_241); r_; });
          }
          case TAG_Just: {
            V v_it1_24695 = heff_field(v_t_24668, 0);
            heff_take_n(v_t_24668, 1ULL, 1);
            heff_drop(v_ms_241);
            heff_drop(v_w_240);
            heff_drop(v_uf_242);
            switch (heff_tag_of(v_it1_24695)) {
            case TAG_MkPair: {
              V v_m_24696 = heff_field(v_it1_24695, 0);
              V v_sp_24697 = heff_field(v_it1_24695, 1);
              heff_take_n(v_it1_24695, 3ULL, 2);
              return heff_tail(heff_get_n(v_r_243, 3, 9), 8, (V[]){v_g_244, v_cs_245, v_m_24696, v_sp_24697, v_x_2412, v_x_2415, v_hd_2410, v_k_2411});
            }
            default: return heff_nomatch(v_it1_24695);
            }
          }
          default: return heff_nomatch(v_t_24668);
          }
        }
        case TAG_Just: {
          V v_it1_24698 = heff_field(v_t_24655, 0);
          heff_take_n(v_t_24655, 1ULL, 1);
          heff_drop(v_ms_241);
          heff_drop(v_w_240);
          heff_drop(v_uf_242);
          switch (heff_tag_of(v_it1_24698)) {
          case TAG_MkPair: {
            V v_m_24699 = heff_field(v_it1_24698, 0);
            V v_sp_24700 = heff_field(v_it1_24698, 1);
            heff_take_n(v_it1_24698, 3ULL, 2);
            return heff_tail(heff_get_n(v_r_243, 3, 9), 8, (V[]){v_g_244, v_cs_245, v_m_24699, v_sp_24700, v_x_2415, v_x_2412, v_hd_2410, v_k_2411});
          }
          default: return heff_nomatch(v_it1_24698);
          }
        }
        default: return heff_nomatch(v_t_24655);
        }
      }
      case TAG_VCons: {
        V v_t_24714;
        switch (heff_tag_of(v_x_2412)) {
        case TAG_VNeu: {
          V v_v1_24702 = heff_dup(heff_field(v_x_2412, 0));
          V v_sp_24703 = heff_dup(heff_field(v_x_2412, 1));
          switch (heff_tag_of(v_v1_24702)) {
          case TAG_HLocal: {
            heff_take_n(v_v1_24702, 0ULL, 1);
            heff_drop(v_sp_24703);
            v_t_24714 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HGlobal: {
            heff_take_n(v_v1_24702, 0ULL, 1);
            heff_drop(v_sp_24703);
            v_t_24714 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HMeta: {
            V v_m_24709 = heff_field(v_v1_24702, 0);
            V v_ru_24v1_24702_24HMeta = heff_take_reuse_n(v_v1_24702, 1ULL, 1);
            v_t_24714 = heff_tag_at_n(v_ru_24v1_24702_24HMeta, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_m_24709, v_sp_24703})});
            break;
          }
          case TAG_HError: {
            heff_drop(v_sp_24703);
            v_t_24714 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_v1_24702);
          }
          break;
        }
        case TAG_VCode: {
          v_t_24714 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VLam: {
          v_t_24714 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VCons: {
          v_t_24714 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VOpaque: {
          v_t_24714 = NTAG(TAG_Nothing);
          break;
        }
        default: heff_nomatch(v_x_2412);
        }
        switch (heff_tag_of(v_t_24714)) {
        case TAG_Nothing: {
          V v_t_24727;
          switch (heff_tag_of(v_x_2415)) {
          case TAG_VNeu: {
            V v_v1_24715 = heff_dup(heff_field(v_x_2415, 0));
            V v_sp_24716 = heff_dup(heff_field(v_x_2415, 1));
            switch (heff_tag_of(v_v1_24715)) {
            case TAG_HLocal: {
              heff_take_n(v_v1_24715, 0ULL, 1);
              heff_drop(v_sp_24716);
              v_t_24727 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HGlobal: {
              heff_take_n(v_v1_24715, 0ULL, 1);
              heff_drop(v_sp_24716);
              v_t_24727 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HMeta: {
              V v_m_24722 = heff_field(v_v1_24715, 0);
              V v_ru_24v1_24715_24HMeta = heff_take_reuse_n(v_v1_24715, 1ULL, 1);
              v_t_24727 = heff_tag_at_n(v_ru_24v1_24715_24HMeta, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_m_24722, v_sp_24716})});
              break;
            }
            case TAG_HError: {
              heff_drop(v_sp_24716);
              v_t_24727 = NTAG(TAG_Nothing);
              break;
            }
            default: heff_nomatch(v_v1_24715);
            }
            break;
          }
          case TAG_VCode: {
            v_t_24727 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VLam: {
            v_t_24727 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VCons: {
            v_t_24727 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VOpaque: {
            v_t_24727 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_x_2415);
          }
          switch (heff_tag_of(v_t_24727)) {
          case TAG_Nothing: {
            V v_t_24740;
            switch (heff_tag_of(v_x_2412)) {
            case TAG_VNeu: {
              V v_v1_24728 = heff_dup(heff_field(v_x_2412, 0));
              switch (heff_tag_of(v_v1_24728)) {
              case TAG_HLocal: {
                heff_take_n(v_v1_24728, 0ULL, 1);
                v_t_24740 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
                break;
              }
              case TAG_HGlobal: {
                heff_take_n(v_v1_24728, 0ULL, 1);
                v_t_24740 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
                break;
              }
              case TAG_HMeta: {
                heff_take_n(v_v1_24728, 0ULL, 1);
                v_t_24740 = heff_dup(v_x_2412);
                break;
              }
              case TAG_HError: {
                v_t_24740 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
                break;
              }
              default: heff_nomatch(v_v1_24728);
              }
              break;
            }
            case TAG_VCode: {
              v_t_24740 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
              break;
            }
            case TAG_VLam: {
              v_t_24740 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
              break;
            }
            case TAG_VCons: {
              v_t_24740 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
              break;
            }
            case TAG_VOpaque: {
              v_t_24740 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
              break;
            }
            default: heff_nomatch(v_x_2412);
            }
            V v_t_24753;
            switch (heff_tag_of(v_x_2415)) {
            case TAG_VNeu: {
              V v_v1_24741 = heff_dup(heff_field(v_x_2415, 0));
              switch (heff_tag_of(v_v1_24741)) {
              case TAG_HLocal: {
                heff_take_n(v_v1_24741, 0ULL, 1);
                v_t_24753 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
                break;
              }
              case TAG_HGlobal: {
                heff_take_n(v_v1_24741, 0ULL, 1);
                v_t_24753 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
                break;
              }
              case TAG_HMeta: {
                heff_take_n(v_v1_24741, 0ULL, 1);
                v_t_24753 = heff_dup(v_x_2415);
                break;
              }
              case TAG_HError: {
                v_t_24753 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
                break;
              }
              default: heff_nomatch(v_v1_24741);
              }
              break;
            }
            case TAG_VCode: {
              v_t_24753 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
              break;
            }
            case TAG_VLam: {
              v_t_24753 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
              break;
            }
            case TAG_VCons: {
              v_t_24753 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
              break;
            }
            case TAG_VOpaque: {
              v_t_24753 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
              break;
            }
            default: heff_nomatch(v_x_2415);
            }
            return ({ V a_0 = v_w_240; V a_1 = v_ms_241; V a_2 = v_uf_242; V a_3 = v_r_243; V a_4 = v_g_244; V a_5 = v_cs_245; V a_6 = v_t_24740; V a_7 = v_t_24753; V a_8 = v_x_2412; V a_9 = v_x_2415; V a_10 = v_hd_2410; V a_11 = v_k_2411; V r_ = (g_heff_2eelab_2eunify_2euElRigid(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9, a_10, a_11)); heff_drop(v_ms_241); r_; });
          }
          case TAG_Just: {
            V v_it1_24754 = heff_field(v_t_24727, 0);
            heff_take_n(v_t_24727, 1ULL, 1);
            heff_drop(v_ms_241);
            heff_drop(v_w_240);
            heff_drop(v_uf_242);
            switch (heff_tag_of(v_it1_24754)) {
            case TAG_MkPair: {
              V v_m_24755 = heff_field(v_it1_24754, 0);
              V v_sp_24756 = heff_field(v_it1_24754, 1);
              heff_take_n(v_it1_24754, 3ULL, 2);
              return heff_tail(heff_get_n(v_r_243, 3, 9), 8, (V[]){v_g_244, v_cs_245, v_m_24755, v_sp_24756, v_x_2412, v_x_2415, v_hd_2410, v_k_2411});
            }
            default: return heff_nomatch(v_it1_24754);
            }
          }
          default: return heff_nomatch(v_t_24727);
          }
        }
        case TAG_Just: {
          V v_it1_24757 = heff_field(v_t_24714, 0);
          heff_take_n(v_t_24714, 1ULL, 1);
          heff_drop(v_ms_241);
          heff_drop(v_w_240);
          heff_drop(v_uf_242);
          switch (heff_tag_of(v_it1_24757)) {
          case TAG_MkPair: {
            V v_m_24758 = heff_field(v_it1_24757, 0);
            V v_sp_24759 = heff_field(v_it1_24757, 1);
            heff_take_n(v_it1_24757, 3ULL, 2);
            return heff_tail(heff_get_n(v_r_243, 3, 9), 8, (V[]){v_g_244, v_cs_245, v_m_24758, v_sp_24759, v_x_2415, v_x_2412, v_hd_2410, v_k_2411});
          }
          default: return heff_nomatch(v_it1_24757);
          }
        }
        default: return heff_nomatch(v_t_24714);
        }
      }
      case TAG_VOpaque: {
        heff_drop_tag(v_x_2412, 2);
        heff_drop(v_ms_241);
        heff_drop(v_w_240);
        heff_drop(v_hd_2410);
        heff_drop_rec(v_cs_245, 2);
        heff_drop(v_uf_242);
        heff_drop_rec(v_r_243, 9);
        heff_drop(v_g_244);
        V f_ = v_k_2411;
        args[0] = NTAG(TAG_MkUnit);
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      }
      default: return heff_nomatch(v_x_2415);
      }
    }
    case TAG_VCons: {
      switch (heff_tag_of(v_x_2415)) {
      case TAG_VNeu: {
        V v_t_24778;
        switch (heff_tag_of(v_x_2412)) {
        case TAG_VNeu: {
          V v_v1_24766 = heff_dup(heff_field(v_x_2412, 0));
          V v_sp_24767 = heff_dup(heff_field(v_x_2412, 1));
          switch (heff_tag_of(v_v1_24766)) {
          case TAG_HLocal: {
            heff_take_n(v_v1_24766, 0ULL, 1);
            heff_drop(v_sp_24767);
            v_t_24778 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HGlobal: {
            heff_take_n(v_v1_24766, 0ULL, 1);
            heff_drop(v_sp_24767);
            v_t_24778 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HMeta: {
            V v_m_24773 = heff_field(v_v1_24766, 0);
            V v_ru_24v1_24766_24HMeta = heff_take_reuse_n(v_v1_24766, 1ULL, 1);
            v_t_24778 = heff_tag_at_n(v_ru_24v1_24766_24HMeta, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_m_24773, v_sp_24767})});
            break;
          }
          case TAG_HError: {
            heff_drop(v_sp_24767);
            v_t_24778 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_v1_24766);
          }
          break;
        }
        case TAG_VCode: {
          v_t_24778 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VLam: {
          v_t_24778 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VCons: {
          v_t_24778 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VOpaque: {
          v_t_24778 = NTAG(TAG_Nothing);
          break;
        }
        default: heff_nomatch(v_x_2412);
        }
        switch (heff_tag_of(v_t_24778)) {
        case TAG_Nothing: {
          V v_t_24791;
          switch (heff_tag_of(v_x_2415)) {
          case TAG_VNeu: {
            V v_v1_24779 = heff_dup(heff_field(v_x_2415, 0));
            V v_sp_24780 = heff_dup(heff_field(v_x_2415, 1));
            switch (heff_tag_of(v_v1_24779)) {
            case TAG_HLocal: {
              heff_take_n(v_v1_24779, 0ULL, 1);
              heff_drop(v_sp_24780);
              v_t_24791 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HGlobal: {
              heff_take_n(v_v1_24779, 0ULL, 1);
              heff_drop(v_sp_24780);
              v_t_24791 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HMeta: {
              V v_m_24786 = heff_field(v_v1_24779, 0);
              V v_ru_24v1_24779_24HMeta = heff_take_reuse_n(v_v1_24779, 1ULL, 1);
              v_t_24791 = heff_tag_at_n(v_ru_24v1_24779_24HMeta, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_m_24786, v_sp_24780})});
              break;
            }
            case TAG_HError: {
              heff_drop(v_sp_24780);
              v_t_24791 = NTAG(TAG_Nothing);
              break;
            }
            default: heff_nomatch(v_v1_24779);
            }
            break;
          }
          case TAG_VCode: {
            v_t_24791 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VLam: {
            v_t_24791 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VCons: {
            v_t_24791 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VOpaque: {
            v_t_24791 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_x_2415);
          }
          switch (heff_tag_of(v_t_24791)) {
          case TAG_Nothing: {
            V v_t_24804;
            switch (heff_tag_of(v_x_2412)) {
            case TAG_VNeu: {
              V v_v1_24792 = heff_dup(heff_field(v_x_2412, 0));
              switch (heff_tag_of(v_v1_24792)) {
              case TAG_HLocal: {
                heff_take_n(v_v1_24792, 0ULL, 1);
                v_t_24804 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
                break;
              }
              case TAG_HGlobal: {
                heff_take_n(v_v1_24792, 0ULL, 1);
                v_t_24804 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
                break;
              }
              case TAG_HMeta: {
                heff_take_n(v_v1_24792, 0ULL, 1);
                v_t_24804 = heff_dup(v_x_2412);
                break;
              }
              case TAG_HError: {
                v_t_24804 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
                break;
              }
              default: heff_nomatch(v_v1_24792);
              }
              break;
            }
            case TAG_VCode: {
              v_t_24804 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
              break;
            }
            case TAG_VLam: {
              v_t_24804 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
              break;
            }
            case TAG_VCons: {
              v_t_24804 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
              break;
            }
            case TAG_VOpaque: {
              v_t_24804 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
              break;
            }
            default: heff_nomatch(v_x_2412);
            }
            V v_t_24817;
            switch (heff_tag_of(v_x_2415)) {
            case TAG_VNeu: {
              V v_v1_24805 = heff_dup(heff_field(v_x_2415, 0));
              switch (heff_tag_of(v_v1_24805)) {
              case TAG_HLocal: {
                heff_take_n(v_v1_24805, 0ULL, 1);
                v_t_24817 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
                break;
              }
              case TAG_HGlobal: {
                heff_take_n(v_v1_24805, 0ULL, 1);
                v_t_24817 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
                break;
              }
              case TAG_HMeta: {
                heff_take_n(v_v1_24805, 0ULL, 1);
                v_t_24817 = heff_dup(v_x_2415);
                break;
              }
              case TAG_HError: {
                v_t_24817 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
                break;
              }
              default: heff_nomatch(v_v1_24805);
              }
              break;
            }
            case TAG_VCode: {
              v_t_24817 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
              break;
            }
            case TAG_VLam: {
              v_t_24817 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
              break;
            }
            case TAG_VCons: {
              v_t_24817 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
              break;
            }
            case TAG_VOpaque: {
              v_t_24817 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
              break;
            }
            default: heff_nomatch(v_x_2415);
            }
            return ({ V a_0 = v_w_240; V a_1 = v_ms_241; V a_2 = v_uf_242; V a_3 = v_r_243; V a_4 = v_g_244; V a_5 = v_cs_245; V a_6 = v_t_24804; V a_7 = v_t_24817; V a_8 = v_x_2412; V a_9 = v_x_2415; V a_10 = v_hd_2410; V a_11 = v_k_2411; V r_ = (g_heff_2eelab_2eunify_2euElRigid(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9, a_10, a_11)); heff_drop(v_ms_241); r_; });
          }
          case TAG_Just: {
            V v_it1_24818 = heff_field(v_t_24791, 0);
            heff_take_n(v_t_24791, 1ULL, 1);
            heff_drop(v_ms_241);
            heff_drop(v_w_240);
            heff_drop(v_uf_242);
            switch (heff_tag_of(v_it1_24818)) {
            case TAG_MkPair: {
              V v_m_24819 = heff_field(v_it1_24818, 0);
              V v_sp_24820 = heff_field(v_it1_24818, 1);
              heff_take_n(v_it1_24818, 3ULL, 2);
              return heff_tail(heff_get_n(v_r_243, 3, 9), 8, (V[]){v_g_244, v_cs_245, v_m_24819, v_sp_24820, v_x_2412, v_x_2415, v_hd_2410, v_k_2411});
            }
            default: return heff_nomatch(v_it1_24818);
            }
          }
          default: return heff_nomatch(v_t_24791);
          }
        }
        case TAG_Just: {
          V v_it1_24821 = heff_field(v_t_24778, 0);
          heff_take_n(v_t_24778, 1ULL, 1);
          heff_drop(v_ms_241);
          heff_drop(v_w_240);
          heff_drop(v_uf_242);
          switch (heff_tag_of(v_it1_24821)) {
          case TAG_MkPair: {
            V v_m_24822 = heff_field(v_it1_24821, 0);
            V v_sp_24823 = heff_field(v_it1_24821, 1);
            heff_take_n(v_it1_24821, 3ULL, 2);
            return heff_tail(heff_get_n(v_r_243, 3, 9), 8, (V[]){v_g_244, v_cs_245, v_m_24822, v_sp_24823, v_x_2415, v_x_2412, v_hd_2410, v_k_2411});
          }
          default: return heff_nomatch(v_it1_24821);
          }
        }
        default: return heff_nomatch(v_t_24778);
        }
      }
      case TAG_VCode: {
        V v_t_24837;
        switch (heff_tag_of(v_x_2412)) {
        case TAG_VNeu: {
          V v_v1_24825 = heff_dup(heff_field(v_x_2412, 0));
          V v_sp_24826 = heff_dup(heff_field(v_x_2412, 1));
          switch (heff_tag_of(v_v1_24825)) {
          case TAG_HLocal: {
            heff_take_n(v_v1_24825, 0ULL, 1);
            heff_drop(v_sp_24826);
            v_t_24837 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HGlobal: {
            heff_take_n(v_v1_24825, 0ULL, 1);
            heff_drop(v_sp_24826);
            v_t_24837 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HMeta: {
            V v_m_24832 = heff_field(v_v1_24825, 0);
            V v_ru_24v1_24825_24HMeta = heff_take_reuse_n(v_v1_24825, 1ULL, 1);
            v_t_24837 = heff_tag_at_n(v_ru_24v1_24825_24HMeta, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_m_24832, v_sp_24826})});
            break;
          }
          case TAG_HError: {
            heff_drop(v_sp_24826);
            v_t_24837 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_v1_24825);
          }
          break;
        }
        case TAG_VCode: {
          v_t_24837 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VLam: {
          v_t_24837 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VCons: {
          v_t_24837 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VOpaque: {
          v_t_24837 = NTAG(TAG_Nothing);
          break;
        }
        default: heff_nomatch(v_x_2412);
        }
        switch (heff_tag_of(v_t_24837)) {
        case TAG_Nothing: {
          V v_t_24850;
          switch (heff_tag_of(v_x_2415)) {
          case TAG_VNeu: {
            V v_v1_24838 = heff_dup(heff_field(v_x_2415, 0));
            V v_sp_24839 = heff_dup(heff_field(v_x_2415, 1));
            switch (heff_tag_of(v_v1_24838)) {
            case TAG_HLocal: {
              heff_take_n(v_v1_24838, 0ULL, 1);
              heff_drop(v_sp_24839);
              v_t_24850 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HGlobal: {
              heff_take_n(v_v1_24838, 0ULL, 1);
              heff_drop(v_sp_24839);
              v_t_24850 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HMeta: {
              V v_m_24845 = heff_field(v_v1_24838, 0);
              V v_ru_24v1_24838_24HMeta = heff_take_reuse_n(v_v1_24838, 1ULL, 1);
              v_t_24850 = heff_tag_at_n(v_ru_24v1_24838_24HMeta, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_m_24845, v_sp_24839})});
              break;
            }
            case TAG_HError: {
              heff_drop(v_sp_24839);
              v_t_24850 = NTAG(TAG_Nothing);
              break;
            }
            default: heff_nomatch(v_v1_24838);
            }
            break;
          }
          case TAG_VCode: {
            v_t_24850 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VLam: {
            v_t_24850 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VCons: {
            v_t_24850 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VOpaque: {
            v_t_24850 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_x_2415);
          }
          switch (heff_tag_of(v_t_24850)) {
          case TAG_Nothing: {
            V v_t_24863;
            switch (heff_tag_of(v_x_2412)) {
            case TAG_VNeu: {
              V v_v1_24851 = heff_dup(heff_field(v_x_2412, 0));
              switch (heff_tag_of(v_v1_24851)) {
              case TAG_HLocal: {
                heff_take_n(v_v1_24851, 0ULL, 1);
                v_t_24863 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
                break;
              }
              case TAG_HGlobal: {
                heff_take_n(v_v1_24851, 0ULL, 1);
                v_t_24863 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
                break;
              }
              case TAG_HMeta: {
                heff_take_n(v_v1_24851, 0ULL, 1);
                v_t_24863 = heff_dup(v_x_2412);
                break;
              }
              case TAG_HError: {
                v_t_24863 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
                break;
              }
              default: heff_nomatch(v_v1_24851);
              }
              break;
            }
            case TAG_VCode: {
              v_t_24863 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
              break;
            }
            case TAG_VLam: {
              v_t_24863 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
              break;
            }
            case TAG_VCons: {
              v_t_24863 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
              break;
            }
            case TAG_VOpaque: {
              v_t_24863 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
              break;
            }
            default: heff_nomatch(v_x_2412);
            }
            V v_t_24876;
            switch (heff_tag_of(v_x_2415)) {
            case TAG_VNeu: {
              V v_v1_24864 = heff_dup(heff_field(v_x_2415, 0));
              switch (heff_tag_of(v_v1_24864)) {
              case TAG_HLocal: {
                heff_take_n(v_v1_24864, 0ULL, 1);
                v_t_24876 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
                break;
              }
              case TAG_HGlobal: {
                heff_take_n(v_v1_24864, 0ULL, 1);
                v_t_24876 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
                break;
              }
              case TAG_HMeta: {
                heff_take_n(v_v1_24864, 0ULL, 1);
                v_t_24876 = heff_dup(v_x_2415);
                break;
              }
              case TAG_HError: {
                v_t_24876 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
                break;
              }
              default: heff_nomatch(v_v1_24864);
              }
              break;
            }
            case TAG_VCode: {
              v_t_24876 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
              break;
            }
            case TAG_VLam: {
              v_t_24876 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
              break;
            }
            case TAG_VCons: {
              v_t_24876 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
              break;
            }
            case TAG_VOpaque: {
              v_t_24876 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
              break;
            }
            default: heff_nomatch(v_x_2415);
            }
            return ({ V a_0 = v_w_240; V a_1 = v_ms_241; V a_2 = v_uf_242; V a_3 = v_r_243; V a_4 = v_g_244; V a_5 = v_cs_245; V a_6 = v_t_24863; V a_7 = v_t_24876; V a_8 = v_x_2412; V a_9 = v_x_2415; V a_10 = v_hd_2410; V a_11 = v_k_2411; V r_ = (g_heff_2eelab_2eunify_2euElRigid(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9, a_10, a_11)); heff_drop(v_ms_241); r_; });
          }
          case TAG_Just: {
            V v_it1_24877 = heff_field(v_t_24850, 0);
            heff_take_n(v_t_24850, 1ULL, 1);
            heff_drop(v_ms_241);
            heff_drop(v_w_240);
            heff_drop(v_uf_242);
            switch (heff_tag_of(v_it1_24877)) {
            case TAG_MkPair: {
              V v_m_24878 = heff_field(v_it1_24877, 0);
              V v_sp_24879 = heff_field(v_it1_24877, 1);
              heff_take_n(v_it1_24877, 3ULL, 2);
              return heff_tail(heff_get_n(v_r_243, 3, 9), 8, (V[]){v_g_244, v_cs_245, v_m_24878, v_sp_24879, v_x_2412, v_x_2415, v_hd_2410, v_k_2411});
            }
            default: return heff_nomatch(v_it1_24877);
            }
          }
          default: return heff_nomatch(v_t_24850);
          }
        }
        case TAG_Just: {
          V v_it1_24880 = heff_field(v_t_24837, 0);
          heff_take_n(v_t_24837, 1ULL, 1);
          heff_drop(v_ms_241);
          heff_drop(v_w_240);
          heff_drop(v_uf_242);
          switch (heff_tag_of(v_it1_24880)) {
          case TAG_MkPair: {
            V v_m_24881 = heff_field(v_it1_24880, 0);
            V v_sp_24882 = heff_field(v_it1_24880, 1);
            heff_take_n(v_it1_24880, 3ULL, 2);
            return heff_tail(heff_get_n(v_r_243, 3, 9), 8, (V[]){v_g_244, v_cs_245, v_m_24881, v_sp_24882, v_x_2415, v_x_2412, v_hd_2410, v_k_2411});
          }
          default: return heff_nomatch(v_it1_24880);
          }
        }
        default: return heff_nomatch(v_t_24837);
        }
      }
      case TAG_VLam: {
        V v_t_24897;
        switch (heff_tag_of(v_x_2412)) {
        case TAG_VNeu: {
          V v_v1_24885 = heff_dup(heff_field(v_x_2412, 0));
          V v_sp_24886 = heff_dup(heff_field(v_x_2412, 1));
          switch (heff_tag_of(v_v1_24885)) {
          case TAG_HLocal: {
            heff_take_n(v_v1_24885, 0ULL, 1);
            heff_drop(v_sp_24886);
            v_t_24897 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HGlobal: {
            heff_take_n(v_v1_24885, 0ULL, 1);
            heff_drop(v_sp_24886);
            v_t_24897 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HMeta: {
            V v_m_24892 = heff_field(v_v1_24885, 0);
            V v_ru_24v1_24885_24HMeta = heff_take_reuse_n(v_v1_24885, 1ULL, 1);
            v_t_24897 = heff_tag_at_n(v_ru_24v1_24885_24HMeta, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_m_24892, v_sp_24886})});
            break;
          }
          case TAG_HError: {
            heff_drop(v_sp_24886);
            v_t_24897 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_v1_24885);
          }
          break;
        }
        case TAG_VCode: {
          v_t_24897 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VLam: {
          v_t_24897 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VCons: {
          v_t_24897 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VOpaque: {
          v_t_24897 = NTAG(TAG_Nothing);
          break;
        }
        default: heff_nomatch(v_x_2412);
        }
        switch (heff_tag_of(v_t_24897)) {
        case TAG_Nothing: {
          V v_t_24910;
          switch (heff_tag_of(v_x_2415)) {
          case TAG_VNeu: {
            V v_v1_24898 = heff_dup(heff_field(v_x_2415, 0));
            V v_sp_24899 = heff_dup(heff_field(v_x_2415, 1));
            switch (heff_tag_of(v_v1_24898)) {
            case TAG_HLocal: {
              heff_take_n(v_v1_24898, 0ULL, 1);
              heff_drop(v_sp_24899);
              v_t_24910 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HGlobal: {
              heff_take_n(v_v1_24898, 0ULL, 1);
              heff_drop(v_sp_24899);
              v_t_24910 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HMeta: {
              V v_m_24905 = heff_field(v_v1_24898, 0);
              V v_ru_24v1_24898_24HMeta = heff_take_reuse_n(v_v1_24898, 1ULL, 1);
              v_t_24910 = heff_tag_at_n(v_ru_24v1_24898_24HMeta, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_m_24905, v_sp_24899})});
              break;
            }
            case TAG_HError: {
              heff_drop(v_sp_24899);
              v_t_24910 = NTAG(TAG_Nothing);
              break;
            }
            default: heff_nomatch(v_v1_24898);
            }
            break;
          }
          case TAG_VCode: {
            v_t_24910 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VLam: {
            v_t_24910 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VCons: {
            v_t_24910 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VOpaque: {
            v_t_24910 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_x_2415);
          }
          switch (heff_tag_of(v_t_24910)) {
          case TAG_Nothing: {
            V v_t_24923;
            switch (heff_tag_of(v_x_2412)) {
            case TAG_VNeu: {
              V v_v1_24911 = heff_dup(heff_field(v_x_2412, 0));
              switch (heff_tag_of(v_v1_24911)) {
              case TAG_HLocal: {
                heff_take_n(v_v1_24911, 0ULL, 1);
                v_t_24923 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
                break;
              }
              case TAG_HGlobal: {
                heff_take_n(v_v1_24911, 0ULL, 1);
                v_t_24923 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
                break;
              }
              case TAG_HMeta: {
                heff_take_n(v_v1_24911, 0ULL, 1);
                v_t_24923 = heff_dup(v_x_2412);
                break;
              }
              case TAG_HError: {
                v_t_24923 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
                break;
              }
              default: heff_nomatch(v_v1_24911);
              }
              break;
            }
            case TAG_VCode: {
              v_t_24923 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
              break;
            }
            case TAG_VLam: {
              v_t_24923 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
              break;
            }
            case TAG_VCons: {
              v_t_24923 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
              break;
            }
            case TAG_VOpaque: {
              v_t_24923 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
              break;
            }
            default: heff_nomatch(v_x_2412);
            }
            V v_t_24936;
            switch (heff_tag_of(v_x_2415)) {
            case TAG_VNeu: {
              V v_v1_24924 = heff_dup(heff_field(v_x_2415, 0));
              switch (heff_tag_of(v_v1_24924)) {
              case TAG_HLocal: {
                heff_take_n(v_v1_24924, 0ULL, 1);
                v_t_24936 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
                break;
              }
              case TAG_HGlobal: {
                heff_take_n(v_v1_24924, 0ULL, 1);
                v_t_24936 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
                break;
              }
              case TAG_HMeta: {
                heff_take_n(v_v1_24924, 0ULL, 1);
                v_t_24936 = heff_dup(v_x_2415);
                break;
              }
              case TAG_HError: {
                v_t_24936 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
                break;
              }
              default: heff_nomatch(v_v1_24924);
              }
              break;
            }
            case TAG_VCode: {
              v_t_24936 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
              break;
            }
            case TAG_VLam: {
              v_t_24936 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
              break;
            }
            case TAG_VCons: {
              v_t_24936 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
              break;
            }
            case TAG_VOpaque: {
              v_t_24936 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
              break;
            }
            default: heff_nomatch(v_x_2415);
            }
            return ({ V a_0 = v_w_240; V a_1 = v_ms_241; V a_2 = v_uf_242; V a_3 = v_r_243; V a_4 = v_g_244; V a_5 = v_cs_245; V a_6 = v_t_24923; V a_7 = v_t_24936; V a_8 = v_x_2412; V a_9 = v_x_2415; V a_10 = v_hd_2410; V a_11 = v_k_2411; V r_ = (g_heff_2eelab_2eunify_2euElRigid(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9, a_10, a_11)); heff_drop(v_ms_241); r_; });
          }
          case TAG_Just: {
            V v_it1_24937 = heff_field(v_t_24910, 0);
            heff_take_n(v_t_24910, 1ULL, 1);
            heff_drop(v_ms_241);
            heff_drop(v_w_240);
            heff_drop(v_uf_242);
            switch (heff_tag_of(v_it1_24937)) {
            case TAG_MkPair: {
              V v_m_24938 = heff_field(v_it1_24937, 0);
              V v_sp_24939 = heff_field(v_it1_24937, 1);
              heff_take_n(v_it1_24937, 3ULL, 2);
              return heff_tail(heff_get_n(v_r_243, 3, 9), 8, (V[]){v_g_244, v_cs_245, v_m_24938, v_sp_24939, v_x_2412, v_x_2415, v_hd_2410, v_k_2411});
            }
            default: return heff_nomatch(v_it1_24937);
            }
          }
          default: return heff_nomatch(v_t_24910);
          }
        }
        case TAG_Just: {
          V v_it1_24940 = heff_field(v_t_24897, 0);
          heff_take_n(v_t_24897, 1ULL, 1);
          heff_drop(v_ms_241);
          heff_drop(v_w_240);
          heff_drop(v_uf_242);
          switch (heff_tag_of(v_it1_24940)) {
          case TAG_MkPair: {
            V v_m_24941 = heff_field(v_it1_24940, 0);
            V v_sp_24942 = heff_field(v_it1_24940, 1);
            heff_take_n(v_it1_24940, 3ULL, 2);
            return heff_tail(heff_get_n(v_r_243, 3, 9), 8, (V[]){v_g_244, v_cs_245, v_m_24941, v_sp_24942, v_x_2415, v_x_2412, v_hd_2410, v_k_2411});
          }
          default: return heff_nomatch(v_it1_24940);
          }
        }
        default: return heff_nomatch(v_t_24897);
        }
      }
      case TAG_VCons: {
        V v_t_24956;
        switch (heff_tag_of(v_x_2412)) {
        case TAG_VNeu: {
          V v_v1_24944 = heff_dup(heff_field(v_x_2412, 0));
          V v_sp_24945 = heff_dup(heff_field(v_x_2412, 1));
          switch (heff_tag_of(v_v1_24944)) {
          case TAG_HLocal: {
            heff_take_n(v_v1_24944, 0ULL, 1);
            heff_drop(v_sp_24945);
            v_t_24956 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HGlobal: {
            heff_take_n(v_v1_24944, 0ULL, 1);
            heff_drop(v_sp_24945);
            v_t_24956 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HMeta: {
            V v_m_24951 = heff_field(v_v1_24944, 0);
            V v_ru_24v1_24944_24HMeta = heff_take_reuse_n(v_v1_24944, 1ULL, 1);
            v_t_24956 = heff_tag_at_n(v_ru_24v1_24944_24HMeta, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_m_24951, v_sp_24945})});
            break;
          }
          case TAG_HError: {
            heff_drop(v_sp_24945);
            v_t_24956 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_v1_24944);
          }
          break;
        }
        case TAG_VCode: {
          v_t_24956 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VLam: {
          v_t_24956 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VCons: {
          v_t_24956 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VOpaque: {
          v_t_24956 = NTAG(TAG_Nothing);
          break;
        }
        default: heff_nomatch(v_x_2412);
        }
        switch (heff_tag_of(v_t_24956)) {
        case TAG_Nothing: {
          V v_t_24969;
          switch (heff_tag_of(v_x_2415)) {
          case TAG_VNeu: {
            V v_v1_24957 = heff_dup(heff_field(v_x_2415, 0));
            V v_sp_24958 = heff_dup(heff_field(v_x_2415, 1));
            switch (heff_tag_of(v_v1_24957)) {
            case TAG_HLocal: {
              heff_take_n(v_v1_24957, 0ULL, 1);
              heff_drop(v_sp_24958);
              v_t_24969 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HGlobal: {
              heff_take_n(v_v1_24957, 0ULL, 1);
              heff_drop(v_sp_24958);
              v_t_24969 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HMeta: {
              V v_m_24964 = heff_field(v_v1_24957, 0);
              V v_ru_24v1_24957_24HMeta = heff_take_reuse_n(v_v1_24957, 1ULL, 1);
              v_t_24969 = heff_tag_at_n(v_ru_24v1_24957_24HMeta, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_m_24964, v_sp_24958})});
              break;
            }
            case TAG_HError: {
              heff_drop(v_sp_24958);
              v_t_24969 = NTAG(TAG_Nothing);
              break;
            }
            default: heff_nomatch(v_v1_24957);
            }
            break;
          }
          case TAG_VCode: {
            v_t_24969 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VLam: {
            v_t_24969 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VCons: {
            v_t_24969 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VOpaque: {
            v_t_24969 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_x_2415);
          }
          switch (heff_tag_of(v_t_24969)) {
          case TAG_Nothing: {
            V v_t_24982;
            switch (heff_tag_of(v_x_2412)) {
            case TAG_VNeu: {
              V v_v1_24970 = heff_dup(heff_field(v_x_2412, 0));
              switch (heff_tag_of(v_v1_24970)) {
              case TAG_HLocal: {
                heff_take_n(v_v1_24970, 0ULL, 1);
                v_t_24982 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
                break;
              }
              case TAG_HGlobal: {
                heff_take_n(v_v1_24970, 0ULL, 1);
                v_t_24982 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
                break;
              }
              case TAG_HMeta: {
                heff_take_n(v_v1_24970, 0ULL, 1);
                v_t_24982 = heff_dup(v_x_2412);
                break;
              }
              case TAG_HError: {
                v_t_24982 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
                break;
              }
              default: heff_nomatch(v_v1_24970);
              }
              break;
            }
            case TAG_VCode: {
              v_t_24982 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
              break;
            }
            case TAG_VLam: {
              v_t_24982 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
              break;
            }
            case TAG_VCons: {
              v_t_24982 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
              break;
            }
            case TAG_VOpaque: {
              v_t_24982 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
              break;
            }
            default: heff_nomatch(v_x_2412);
            }
            V v_t_24995;
            switch (heff_tag_of(v_x_2415)) {
            case TAG_VNeu: {
              V v_v1_24983 = heff_dup(heff_field(v_x_2415, 0));
              switch (heff_tag_of(v_v1_24983)) {
              case TAG_HLocal: {
                heff_take_n(v_v1_24983, 0ULL, 1);
                v_t_24995 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
                break;
              }
              case TAG_HGlobal: {
                heff_take_n(v_v1_24983, 0ULL, 1);
                v_t_24995 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
                break;
              }
              case TAG_HMeta: {
                heff_take_n(v_v1_24983, 0ULL, 1);
                v_t_24995 = heff_dup(v_x_2415);
                break;
              }
              case TAG_HError: {
                v_t_24995 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
                break;
              }
              default: heff_nomatch(v_v1_24983);
              }
              break;
            }
            case TAG_VCode: {
              v_t_24995 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
              break;
            }
            case TAG_VLam: {
              v_t_24995 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
              break;
            }
            case TAG_VCons: {
              v_t_24995 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
              break;
            }
            case TAG_VOpaque: {
              v_t_24995 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
              break;
            }
            default: heff_nomatch(v_x_2415);
            }
            return ({ V a_0 = v_w_240; V a_1 = v_ms_241; V a_2 = v_uf_242; V a_3 = v_r_243; V a_4 = v_g_244; V a_5 = v_cs_245; V a_6 = v_t_24982; V a_7 = v_t_24995; V a_8 = v_x_2412; V a_9 = v_x_2415; V a_10 = v_hd_2410; V a_11 = v_k_2411; V r_ = (g_heff_2eelab_2eunify_2euElRigid(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9, a_10, a_11)); heff_drop(v_ms_241); r_; });
          }
          case TAG_Just: {
            V v_it1_24996 = heff_field(v_t_24969, 0);
            heff_take_n(v_t_24969, 1ULL, 1);
            heff_drop(v_ms_241);
            heff_drop(v_w_240);
            heff_drop(v_uf_242);
            switch (heff_tag_of(v_it1_24996)) {
            case TAG_MkPair: {
              V v_m_24997 = heff_field(v_it1_24996, 0);
              V v_sp_24998 = heff_field(v_it1_24996, 1);
              heff_take_n(v_it1_24996, 3ULL, 2);
              return heff_tail(heff_get_n(v_r_243, 3, 9), 8, (V[]){v_g_244, v_cs_245, v_m_24997, v_sp_24998, v_x_2412, v_x_2415, v_hd_2410, v_k_2411});
            }
            default: return heff_nomatch(v_it1_24996);
            }
          }
          default: return heff_nomatch(v_t_24969);
          }
        }
        case TAG_Just: {
          V v_it1_24999 = heff_field(v_t_24956, 0);
          heff_take_n(v_t_24956, 1ULL, 1);
          heff_drop(v_ms_241);
          heff_drop(v_w_240);
          heff_drop(v_uf_242);
          switch (heff_tag_of(v_it1_24999)) {
          case TAG_MkPair: {
            V v_m_241000 = heff_field(v_it1_24999, 0);
            V v_sp_241001 = heff_field(v_it1_24999, 1);
            heff_take_n(v_it1_24999, 3ULL, 2);
            return heff_tail(heff_get_n(v_r_243, 3, 9), 8, (V[]){v_g_244, v_cs_245, v_m_241000, v_sp_241001, v_x_2415, v_x_2412, v_hd_2410, v_k_2411});
          }
          default: return heff_nomatch(v_it1_24999);
          }
        }
        default: return heff_nomatch(v_t_24956);
        }
      }
      case TAG_VOpaque: {
        heff_drop_tag(v_x_2412, 1);
        heff_drop(v_ms_241);
        heff_drop(v_w_240);
        heff_drop(v_hd_2410);
        heff_drop_rec(v_cs_245, 2);
        heff_drop(v_uf_242);
        heff_drop_rec(v_r_243, 9);
        heff_drop(v_g_244);
        V f_ = v_k_2411;
        args[0] = NTAG(TAG_MkUnit);
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      }
      default: return heff_nomatch(v_x_2415);
      }
    }
    case TAG_VOpaque: {
      heff_drop(v_x_2415);
      heff_drop(v_ms_241);
      heff_drop(v_w_240);
      heff_drop(v_hd_2410);
      heff_drop_rec(v_cs_245, 2);
      heff_drop(v_uf_242);
      heff_drop_rec(v_r_243, 9);
      heff_drop(v_g_244);
      V f_ = v_k_2411;
      args[0] = NTAG(TAG_MkUnit);
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    default: return heff_nomatch(v_x_2412);
    }
  }
}
V g_heff_2eelab_2eunify_2euTermF_lam2(V self, V *args) {
  V v_x_2412 = args[0];
  V v_ms_241 = heff_env(self)[0];
  V v_b0_247 = heff_env(self)[1];
  V v_w_240 = heff_env(self)[2];
  V v_hd_2410 = heff_env(self)[3];
  V v_cs_245 = heff_env(self)[4];
  V v_uf_242 = heff_env(self)[5];
  V v_k_2411 = heff_env(self)[6];
  V v_r_243 = heff_env(self)[7];
  V v_g_244 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_t_2414 = heff_tr(heff_call(heff_dup(v_ms_241), 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2eunify_2euTermF_lam3, 1, 1, (V[]){v_b0_247})})}));
  return (g_co_2eop_24s310169282x2049378029(heff_dup(v_w_240), v_t_2414, heff_dup(v_hd_2410), heff_clo_n(g_heff_2eelab_2eunify_2euTermF_lam4, 1, 9, (V[]){v_x_2412, v_ms_241, v_w_240, v_hd_2410, v_cs_245, v_uf_242, v_k_2411, v_r_243, v_g_244})));
}
V g_heff_2eelab_2eunify_2euTermF_lam1(V self, V *args) {
  V v_hd_2410 = args[0];
  V v_k_2411 = args[1];
  V v_w_240 = heff_env(self)[0];
  V v_t_249 = heff_env(self)[1];
  V v_ms_241 = heff_env(self)[2];
  V v_b0_247 = heff_env(self)[3];
  V v_cs_245 = heff_env(self)[4];
  V v_uf_242 = heff_env(self)[5];
  V v_r_243 = heff_env(self)[6];
  V v_g_244 = heff_env(self)[7];
  heff_clo_take(self, 8);
  return (g_co_2eop_24s310169282x2049378029(heff_dup(v_w_240), v_t_249, heff_dup(v_hd_2410), heff_clo_n(g_heff_2eelab_2eunify_2euTermF_lam2, 1, 9, (V[]){v_ms_241, v_b0_247, v_w_240, v_hd_2410, v_cs_245, v_uf_242, v_k_2411, v_r_243, v_g_244})));
}
Clo g_heff_2eelab_2eunify_2eufEv_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2eufEv_entry, 1, 0};

V g_heff_2eelab_2eunify_2eufEv(V v_p_240) {
top: ;
  return heff_tag_n(TAG_InR, 1, (V[]){v_p_240});
}
V g_heff_2eelab_2eunify_2eufEv_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2eufEv(a[0]);
}
V g_heff_2eelab_2eunify_2epostponeU_24s1873620235x793075195_lam0(V self, V *args);
V g_heff_2eelab_2eunify_2epostponeU_24s1873620235x793075195_lam1(V self, V *args);
Clo g_heff_2eelab_2eunify_2epostponeU_24s1873620235x793075195_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2epostponeU_24s1873620235x793075195_entry, 5, 0};

V g_heff_2eelab_2eunify_2epostponeU_24s1873620235x793075195(V v_cs_240, V v_l_241, V v_r_242, V v_hd_243, V v_k_244) {
top: ;
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2eunify_2epostponeU_24s1873620235x793075195_lam0, 1, 3, (V[]){v_cs_240, v_l_241, v_r_242})})});
  V v_t_249 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_243, 2)), 1, (V[]){v_t_248}));
  return heff_tail(heff_dup(heff_rfield(v_hd_243, 1)), 2, (V[]){v_t_249, heff_clo_n(g_heff_2eelab_2eunify_2epostponeU_24s1873620235x793075195_lam1, 1, 2, (V[]){v_hd_243, v_k_244})});
}
V g_heff_2eelab_2eunify_2epostponeU_24s1873620235x793075195_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2epostponeU_24s1873620235x793075195(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2eelab_2eunify_2epostponeU_24s1873620235x793075195_lam0(V self, V *args) {
  V v_c_245 = args[0];
  V v_cs_240 = heff_env(self)[0];
  V v_l_241 = heff_env(self)[1];
  V v_r_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_246 = heff_rec_n(4, shape_shape__left__right__failed, (V[]){v_cs_240, v_l_241, v_r_242, NTAG(TAG_False)});
  V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_246, heff_take_field(v_c_245, 5)});
  return ({ V rv_5 = v_t_247; V rr_ = heff_rec_reuse_nf(v_c_245, 223ULL, 8, shape_infos__recovered__poisoned__metas__nextMeta__postponed__trace__selfKey, 62463u, 0u); heff_rfield(rr_, 5) = rv_5; rr_; });
}
V g_heff_2eelab_2eunify_2epostponeU_24s1873620235x793075195_lam1(V self, V *args) {
  V v_x_2410 = args[0];
  V v_hd_243 = heff_env(self)[0];
  V v_k_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2411 = heff_tag_n(TAG_Put, 2, (V[]){v_x_2410, NTAG(TAG_MkUnit)});
  V v_t_2412 = heff_tr(heff_call(heff_take_field(v_hd_243, 2), 1, (V[]){heff_tag_n(TAG_InL, 1, (V[]){v_t_2411})}));
  V f_ = heff_get_n(v_hd_243, 1, 3);
  heff_room[0] = v_t_2412;
  heff_room[1] = v_k_244;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2eunify_2erenameHead_24s977237252x483540286_lam0(V self, V *args);
V g_heff_2eelab_2eunify_2erenameHead_24s977237252x483540286_lam1(V self, V *args);
V g_heff_2eelab_2eunify_2erenameHead_24s977237252x483540286_lam2(V self, V *args);
V g_heff_2eelab_2eunify_2erenameHead_24s977237252x483540286_lam3(V self, V *args); static Clo g_heff_2eelab_2eunify_2erenameHead_24s977237252x483540286_lam3_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2erenameHead_24s977237252x483540286_lam3, 2, 0};
V g_heff_2eelab_2eunify_2erenameHead_24s977237252x483540286_lam4(V self, V *args); static Clo g_heff_2eelab_2eunify_2erenameHead_24s977237252x483540286_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2erenameHead_24s977237252x483540286_lam4, 2, 0};
Clo g_heff_2eelab_2eunify_2erenameHead_24s977237252x483540286_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2erenameHead_24s977237252x483540286_entry, 2, 0};

V g_heff_2eelab_2eunify_2erenameHead_24s977237252x483540286(V v_r_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_HLocal: {
    V v_l_242 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    HeffT2 v_t_243 = (g_std_2emap_2elookup_24s1702756637x1169753568_24cpr(heff_rfield(v_r_240, 2), heff_dup(v_l_242)));
    {
      V v_field_245 = v_t_243.f[1];
      int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
      if ((v_tag_244 == ((int64_t)0ULL))) {
        heff_drop(v_l_242);
        V v_l_27_247 = v_field_245;
        return heff_clo_n(g_heff_2eelab_2eunify_2erenameHead_24s977237252x483540286_lam0, 2, 2, (V[]){v_r_240, v_l_27_247});
      } else {
        heff_drop_rec(v_r_240, 3);
        heff_drop(v_field_245);
        return heff_clo_n(g_heff_2eelab_2eunify_2erenameHead_24s977237252x483540286_lam1, 2, 1, (V[]){v_l_242});
      }
    }
  }
  case TAG_HGlobal: {
    V v_x_2416 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    heff_drop_rec(v_r_240, 3);
    return heff_clo_n(g_heff_2eelab_2eunify_2erenameHead_24s977237252x483540286_lam2, 2, 1, (V[]){v_x_2416});
  }
  case TAG_HMeta: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop_rec(v_r_240, 3);
    return ((V)&g_heff_2eelab_2eunify_2erenameHead_24s977237252x483540286_lam3_clo);
  }
  case TAG_HError: {
    heff_drop_rec(v_r_240, 3);
    return ((V)&g_heff_2eelab_2eunify_2erenameHead_24s977237252x483540286_lam4_clo);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2eelab_2eunify_2erenameHead_24s977237252x483540286_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2erenameHead_24s977237252x483540286(a[0], a[1]);
}
V g_heff_2eelab_2eunify_2erenameHead_24s977237252x483540286_lam0(V self, V *args) {
  V v_hd_248 = args[0];
  V v_k_249 = args[1];
  V v_r_240 = heff_env(self)[0];
  V v_l_27_247 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_hd_248);
  V v_t_2410 = heff_intSub(heff_get_n(v_r_240, 1, 3), v_l_27_247);
  V v_t_2411 = heff_tag_n(TAG_SLocal, 1, (V[]){heff_intSub(v_t_2410, MK_INT(1LL))});
  V f_ = v_k_249;
  args[0] = v_t_2411;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameHead_24s977237252x483540286_lam1(V self, V *args) {
  V v_hd_2412 = args[0];
  V v_k2_2413 = args[1];
  V v_l_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2414 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_Escapes, 1, (V[]){v_l_242})});
  V v_t_2415 = heff_tr(heff_call(heff_take_field(v_hd_2412, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2414})}));
  V f_ = heff_get_n(v_hd_2412, 1, 3);
  args[0] = v_t_2415;
  args[1] = v_k2_2413;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2erenameHead_24s977237252x483540286_lam2(V self, V *args) {
  V v_hd_2417 = args[0];
  V v_k_2418 = args[1];
  V v_x_2416 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_2417);
  V f_ = v_k_2418;
  args[0] = heff_tag_n(TAG_SGlobal, 1, (V[]){v_x_2416});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameHead_24s977237252x483540286_lam3(V self, V *args) {
  V v_hd_2420 = args[0];
  V v_k2_2421 = args[1];
  V v_t_2422 = heff_tag_n(TAG_UnequalEls, 3, (V[]){heff_dup(g_heff_2eelab_2eparams_2eemptyShape_get()), NTAG(TAG_VOpaque), NTAG(TAG_VOpaque)});
  V v_t_2423 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2422})});
  V v_t_2424 = heff_tr(heff_call(heff_take_field(v_hd_2420, 2), 1, (V[]){v_t_2423}));
  V f_ = heff_get_n(v_hd_2420, 1, 3);
  args[0] = v_t_2424;
  args[1] = v_k2_2421;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2erenameHead_24s977237252x483540286_lam4(V self, V *args) {
  V v_hd_2425 = args[0];
  V v_k2_2426 = args[1];
  V v_t_2427 = heff_tag_n(TAG_Throw, 1, (V[]){NTAG(TAG_MentionsError)});
  V v_t_2428 = heff_tr(heff_call(heff_take_field(v_hd_2425, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2427})}));
  V f_ = heff_get_n(v_hd_2425, 1, 3);
  args[0] = v_t_2428;
  args[1] = v_k2_2426;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2erenameTypeF_24s1867739536x151311522_lam0(V self, V *args);
V g_heff_2eelab_2eunify_2erenameTypeF_24s1867739536x151311522_lam3(V self, V *args);
V g_heff_2eelab_2eunify_2erenameTypeF_24s1867739536x151311522_lam2(V self, V *args);
V g_heff_2eelab_2eunify_2erenameTypeF_24s1867739536x151311522_lam5(V self, V *args);
V g_heff_2eelab_2eunify_2erenameTypeF_24s1867739536x151311522_lam4(V self, V *args);
V g_heff_2eelab_2eunify_2erenameTypeF_24s1867739536x151311522_lam6(V self, V *args);
V g_heff_2eelab_2eunify_2erenameTypeF_24s1867739536x151311522_lam8(V self, V *args);
V g_heff_2eelab_2eunify_2erenameTypeF_24s1867739536x151311522_lam7(V self, V *args);
V g_heff_2eelab_2eunify_2erenameTypeF_24s1867739536x151311522_lam10(V self, V *args);
V g_heff_2eelab_2eunify_2erenameTypeF_24s1867739536x151311522_lam9(V self, V *args);
V g_heff_2eelab_2eunify_2erenameTypeF_24s1867739536x151311522_lam11(V self, V *args);
V g_heff_2eelab_2eunify_2erenameTypeF_24s1867739536x151311522_lam13(V self, V *args);
V g_heff_2eelab_2eunify_2erenameTypeF_24s1867739536x151311522_lam15(V self, V *args);
V g_heff_2eelab_2eunify_2erenameTypeF_24s1867739536x151311522_lam14(V self, V *args);
V g_heff_2eelab_2eunify_2erenameTypeF_24s1867739536x151311522_lam12(V self, V *args);
V g_heff_2eelab_2eunify_2erenameTypeF_24s1867739536x151311522_lam16(V self, V *args);
V g_heff_2eelab_2eunify_2erenameTypeF_24s1867739536x151311522_lam17(V self, V *args);
V g_heff_2eelab_2eunify_2erenameTypeF_24s1867739536x151311522_lam1(V self, V *args);
Clo g_heff_2eelab_2eunify_2erenameTypeF_24s1867739536x151311522_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2erenameTypeF_24s1867739536x151311522_entry, 6, 0};

V g_heff_2eelab_2eunify_2erenameTypeF_24s1867739536x151311522(V v_g_240, V v_m_241, V v_pr_242, V v_t0_243, V v_hd_244, V v_k_245) {
top: ;
  V v_t_247 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2eunify_2erenameTypeF_24s1867739536x151311522_lam0, 1, 1, (V[]){v_t0_243})})});
  V v_t_248 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_244, 2)), 1, (V[]){v_t_247}));
  return heff_tail(heff_dup(heff_rfield(v_hd_244, 1)), 2, (V[]){v_t_248, heff_clo_n(g_heff_2eelab_2eunify_2erenameTypeF_24s1867739536x151311522_lam1, 1, 5, (V[]){v_k_245, v_pr_242, v_hd_244, v_g_240, v_m_241})});
}
V g_heff_2eelab_2eunify_2erenameTypeF_24s1867739536x151311522_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2erenameTypeF_24s1867739536x151311522(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2eelab_2eunify_2erenameTypeF_24s1867739536x151311522_lam0(V self, V *args) {
  V v_c_246 = args[0];
  V v_t0_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_c_246, 3, 8); V a_1 = v_t0_243; V r_ = (g_heff_2eelab_2evalue_2eforceTy(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2eelab_2eunify_2erenameTypeF_24s1867739536x151311522_lam3(V self, V *args) {
  V v_x_2420 = args[0];
  V v_k_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_245;
  args[0] = heff_tag_n(TAG_SDecode, 1, (V[]){v_x_2420});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameTypeF_24s1867739536x151311522_lam2(V self, V *args) {
  V v_x_2418 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  V v_pr_242 = heff_env(self)[2];
  V v_sp_2412 = heff_env(self)[3];
  V v_hd_244 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_c_2419 = (g_heff_2eelab_2eunify_2erenameSpine_24s318780409x760487451(v_g_240, v_m_241, v_pr_242, v_sp_2412, v_x_2418));
  V f_ = v_c_2419;
  heff_room[0] = v_hd_244;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2eunify_2erenameTypeF_24s1867739536x151311522_lam3, 1, 1, (V[]){v_k_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2eunify_2erenameTypeF_24s1867739536x151311522_lam5(V self, V *args) {
  V v_x_2425 = args[0];
  V v_k_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_245;
  args[0] = heff_tag_n(TAG_SDecode, 1, (V[]){v_x_2425});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameTypeF_24s1867739536x151311522_lam4(V self, V *args) {
  V v_x_2423 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  V v_pr_242 = heff_env(self)[2];
  V v_sp_2412 = heff_env(self)[3];
  V v_hd_244 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_c_2424 = (g_heff_2eelab_2eunify_2erenameSpine_24s318780409x760487451(v_g_240, v_m_241, v_pr_242, v_sp_2412, v_x_2423));
  V f_ = v_c_2424;
  heff_room[0] = v_hd_244;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2eunify_2erenameTypeF_24s1867739536x151311522_lam5, 1, 1, (V[]){v_k_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2eunify_2erenameTypeF_24s1867739536x151311522_lam6(V self, V *args) {
  V v_x_2431 = args[0];
  V v_k_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_245;
  args[0] = heff_tag_n(TAG_SDecode, 1, (V[]){v_x_2431});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameTypeF_24s1867739536x151311522_lam8(V self, V *args) {
  V v_x_2435 = args[0];
  V v_k_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_245;
  args[0] = heff_tag_n(TAG_SDecode, 1, (V[]){v_x_2435});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameTypeF_24s1867739536x151311522_lam7(V self, V *args) {
  V v_x_2433 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  V v_pr_242 = heff_env(self)[2];
  V v_sp_2412 = heff_env(self)[3];
  V v_hd_244 = heff_env(self)[4];
  V v_k_245 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_c_2434 = (g_heff_2eelab_2eunify_2erenameSpine_24s318780409x760487451(v_g_240, v_m_241, v_pr_242, v_sp_2412, v_x_2433));
  V f_ = v_c_2434;
  heff_room[0] = v_hd_244;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2eunify_2erenameTypeF_24s1867739536x151311522_lam8, 1, 1, (V[]){v_k_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2eunify_2erenameTypeF_24s1867739536x151311522_lam10(V self, V *args) {
  V v_x_2443 = args[0];
  V v_k_245 = heff_env(self)[0];
  V v_level_2436 = heff_env(self)[1];
  V v_x_2441 = heff_env(self)[2];
  V v_implicit_2439 = heff_env(self)[3];
  V v_dflt_2440 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_k_245;
  args[0] = heff_tag_n(TAG_SFunction, 5, (V[]){v_level_2436, v_x_2441, v_x_2443, v_implicit_2439, v_dflt_2440});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameTypeF_24s1867739536x151311522_lam9(V self, V *args) {
  V v_x_2441 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  V v_pr_242 = heff_env(self)[2];
  V v_dom_2437 = heff_env(self)[3];
  V v_cod_2438 = heff_env(self)[4];
  V v_hd_244 = heff_env(self)[5];
  V v_k_245 = heff_env(self)[6];
  V v_level_2436 = heff_env(self)[7];
  V v_implicit_2439 = heff_env(self)[8];
  V v_dflt_2440 = heff_env(self)[9];
  heff_clo_take(self, 10);
  V v_c_2442 = (g_heff_2eelab_2eunify_2erenameCloTy_24s530841725x165541968(v_g_240, v_m_241, v_pr_242, v_dom_2437, v_cod_2438));
  V f_ = v_c_2442;
  heff_room[0] = v_hd_244;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2eunify_2erenameTypeF_24s1867739536x151311522_lam10, 1, 5, (V[]){v_k_245, v_level_2436, v_x_2441, v_implicit_2439, v_dflt_2440});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2eunify_2erenameTypeF_24s1867739536x151311522_lam11(V self, V *args) {
  V v_x_2450 = args[0];
  V v_fieldTypes_2446 = heff_env(self)[0];
  V v_k_245 = heff_env(self)[1];
  V v_level_2444 = heff_env(self)[2];
  V v_defaults_2447 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2451 = ({ V rv_2 = heff_arrayFromList(v_x_2450); V rr_ = heff_rec_reuse_nf(v_fieldTypes_2446, 3ULL, 3, shape_keys__byName__values, 15u, 0u); heff_rfield(rr_, 2) = rv_2; rr_; });
  V f_ = v_k_245;
  args[0] = heff_tag_n(TAG_SRecord, 3, (V[]){v_level_2444, v_t_2451, v_defaults_2447});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameTypeF_24s1867739536x151311522_lam13(V self, V *args) {
  V v_a_2459 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  V v_pr_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2460 = heff_tr(heff_call(v_a_2459, 1, (V[]){NTAG(TAG_MkUnit)}));
  V f_ = ((V)&g_heff_2eelab_2eunify_2erenameTypeF_24s1867739536x151311522_clo);
  heff_room[0] = v_g_240;
  heff_room[1] = v_m_241;
  heff_room[2] = v_pr_242;
  heff_room[3] = v_t_2460;
  if (heff_exact(f_, 4, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 4, (V[]){heff_room[0], heff_room[1], heff_room[2], heff_room[3]});
}
V g_heff_2eelab_2eunify_2erenameTypeF_24s1867739536x151311522_lam15(V self, V *args) {
  V v_x_2464 = args[0];
  V v_k_2457 = heff_env(self)[0];
  V v_k_2463 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2465 = heff_tag_n(TAG_MkPair, 2, (V[]){v_k_2457, heff_arrayFromList(v_x_2464)});
  V f_ = v_k_2463;
  args[0] = v_t_2465;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameTypeF_24s1867739536x151311522_lam14(V self, V *args) {
  V v_hd_2462 = args[0];
  V v_k_2463 = args[1];
  V v_c_2461 = heff_env(self)[0];
  V v_k_2457 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2461;
  args[0] = v_hd_2462;
  args[1] = heff_clo_n(g_heff_2eelab_2eunify_2erenameTypeF_24s1867739536x151311522_lam15, 1, 2, (V[]){v_k_2457, v_k_2463});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2erenameTypeF_24s1867739536x151311522_lam12(V self, V *args) {
  V v_p_2456 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  V v_pr_242 = heff_env(self)[2];
  heff_clo_take(self, 3);
  switch (heff_tag_of(v_p_2456)) {
  case TAG_MkPair: {
    V v_k_2457 = heff_field(v_p_2456, 0);
    V v_args_2458 = heff_field(v_p_2456, 1);
    heff_take_n(v_p_2456, 3ULL, 2);
    V v_c_2461 = (g_prelude_2etraverse_24s1934076392x614790049(heff_clo_n(g_heff_2eelab_2eunify_2erenameTypeF_24s1867739536x151311522_lam13, 1, 3, (V[]){v_g_240, v_m_241, v_pr_242}), heff_arrayToList(v_args_2458)));
    return heff_clo_n(g_heff_2eelab_2eunify_2erenameTypeF_24s1867739536x151311522_lam14, 2, 2, (V[]){v_c_2461, v_k_2457});
  }
  default: return heff_nomatch(v_p_2456);
  }
}
V g_heff_2eelab_2eunify_2erenameTypeF_24s1867739536x151311522_lam16(V self, V *args) {
  V v_x_2467 = args[0];
  V v_k_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2468 = (g_list_2emap_24s1937570095x2110149801(heff_dup(v_x_2467)));
  V v_t_2469 = (g_heff_2eutil_2edict_2eindexed(MK_INT(0LL), v_x_2467));
  V v_t_2470 = (g_list_2emap_24s1173914895x100384474(v_x_2467));
  V v_t_2471 = heff_rec_n(3, shape_keys__byName__values, (V[]){heff_arrayFromList(v_t_2468), v_t_2469, heff_arrayFromList(v_t_2470)});
  V v_x_2472 = heff_tag_n(TAG_SSum, 1, (V[]){v_t_2471});
  V f_ = v_k_245;
  args[0] = v_x_2472;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameTypeF_24s1867739536x151311522_lam17(V self, V *args) {
  V v_x_2474 = args[0];
  V v_k_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_245;
  args[0] = heff_tag_n(TAG_SPrimArray, 1, (V[]){v_x_2474});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameTypeF_24s1867739536x151311522_lam1(V self, V *args) {
  V v_x_249 = args[0];
  V v_k_245 = heff_env(self)[0];
  V v_pr_242 = heff_env(self)[1];
  V v_hd_244 = heff_env(self)[2];
  V v_g_240 = heff_env(self)[3];
  V v_m_241 = heff_env(self)[4];
  heff_clo_take(self, 5);
  switch (heff_tag_of(v_x_249)) {
  case TAG_VU: {
    V v_u_2410 = heff_field(v_x_249, 0);
    heff_take_n(v_x_249, 1ULL, 1);
    heff_drop(v_pr_242);
    heff_drop_rec(v_hd_244, 3);
    heff_drop(v_g_240);
    heff_drop(v_m_241);
    V f_ = v_k_245;
    args[0] = heff_tag_n(TAG_SU, 1, (V[]){v_u_2410});
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_VDecode: {
    V v_it1_2411 = heff_field(v_x_249, 0);
    V v_sp_2412 = heff_field(v_x_249, 1);
    heff_take_n(v_x_249, 3ULL, 5);
    switch (heff_tag_of(v_it1_2411)) {
    case TAG_HLocal: {
      V v_c_2417 = (g_heff_2eelab_2eunify_2erenameHead_24s977237252x483540286(heff_dup(v_pr_242), v_it1_2411));
      V f_ = v_c_2417;
      heff_room[0] = heff_dup(v_hd_244);
      heff_room[1] = heff_clo_n(g_heff_2eelab_2eunify_2erenameTypeF_24s1867739536x151311522_lam2, 1, 6, (V[]){v_g_240, v_m_241, v_pr_242, v_sp_2412, v_hd_244, v_k_245});
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
    case TAG_HGlobal: {
      V v_c_2422 = (g_heff_2eelab_2eunify_2erenameHead_24s977237252x483540286(heff_dup(v_pr_242), v_it1_2411));
      V f_ = v_c_2422;
      heff_room[0] = heff_dup(v_hd_244);
      heff_room[1] = heff_clo_n(g_heff_2eelab_2eunify_2erenameTypeF_24s1867739536x151311522_lam4, 1, 6, (V[]){v_g_240, v_m_241, v_pr_242, v_sp_2412, v_hd_244, v_k_245});
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
    case TAG_HMeta: {
      V v_m_27_2426 = heff_field(v_it1_2411, 0);
      V v_ru_24it1_2411_24HMeta = heff_take_reuse_n(v_it1_2411, 1ULL, 1);
      if (heff_intEq_c_lent(v_m_27_2426, v_m_241, 0)) {
        heff_drop(v_pr_242);
        heff_drop(v_g_240);
        heff_drop(v_m_241);
        heff_drop(v_sp_2412);
        heff_drop(v_m_27_2426);
        V v_t_2428 = heff_tag_n(TAG_UnequalEls, 3, (V[]){heff_dup(g_heff_2eelab_2eparams_2eemptyShape_get()), NTAG(TAG_VOpaque), NTAG(TAG_VOpaque)});
        V v_t_2429 = heff_tag_at_n(v_ru_24it1_2411_24HMeta, TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2428})});
        V v_t_2430 = heff_tr(heff_call(heff_take_field(v_hd_244, 2), 1, (V[]){v_t_2429}));
        V f_ = heff_get_n(v_hd_244, 1, 3);
        heff_room[0] = v_t_2430;
        heff_room[1] = v_k_245;
        if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
      } else {
        heff_drop_cell(v_ru_24it1_2411_24HMeta, 1);
        return (g_heff_2eelab_2eunify_2erenameFlexF_24s1839973402x1588750198(v_g_240, v_m_241, v_pr_242, v_m_27_2426, v_sp_2412, v_hd_244, heff_clo_n(g_heff_2eelab_2eunify_2erenameTypeF_24s1867739536x151311522_lam6, 1, 1, (V[]){v_k_245})));
      }
    }
    case TAG_HError: {
      V v_c_2432 = (g_heff_2eelab_2eunify_2erenameHead_24s977237252x483540286(heff_dup(v_pr_242), v_it1_2411));
      V f_ = v_c_2432;
      heff_room[0] = heff_dup(v_hd_244);
      heff_room[1] = heff_clo_n(g_heff_2eelab_2eunify_2erenameTypeF_24s1867739536x151311522_lam7, 1, 6, (V[]){v_g_240, v_m_241, v_pr_242, v_sp_2412, v_hd_244, v_k_245});
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
    default: return heff_nomatch(v_it1_2411);
    }
  }
  case TAG_VFunction: {
    V v_level_2436 = heff_field(v_x_249, 0);
    V v_dom_2437 = heff_field(v_x_249, 1);
    V v_cod_2438 = heff_field(v_x_249, 2);
    V v_implicit_2439 = heff_field(v_x_249, 3);
    V v_dflt_2440 = heff_field(v_x_249, 4);
    heff_take_n(v_x_249, 31ULL, 5);
    return (g_heff_2eelab_2eunify_2erenameTypeF_24s1867739536x151311522(heff_dup(v_g_240), heff_dup(v_m_241), heff_dup(v_pr_242), heff_dup(v_dom_2437), heff_dup(v_hd_244), heff_clo_n(g_heff_2eelab_2eunify_2erenameTypeF_24s1867739536x151311522_lam9, 1, 10, (V[]){v_g_240, v_m_241, v_pr_242, v_dom_2437, v_cod_2438, v_hd_244, v_k_245, v_level_2436, v_implicit_2439, v_dflt_2440})));
  }
  case TAG_VRecord: {
    V v_level_2444 = heff_field(v_x_249, 0);
    V v_capture_2445 = heff_field(v_x_249, 1);
    V v_fieldTypes_2446 = heff_field(v_x_249, 2);
    V v_defaults_2447 = heff_field(v_x_249, 3);
    heff_take_n(v_x_249, 15ULL, 4);
    V v_t_2448 = heff_arrayToList(heff_dup(heff_rfield(v_fieldTypes_2446, 2)));
    V v_c_2449 = (g_heff_2eelab_2eunify_2erenameRecordFields_24s1394367931x1007778614(v_g_240, v_m_241, v_pr_242, MK_INT(0LL), v_capture_2445, v_t_2448));
    V f_ = v_c_2449;
    heff_room[0] = v_hd_244;
    heff_room[1] = heff_clo_n(g_heff_2eelab_2eunify_2erenameTypeF_24s1867739536x151311522_lam11, 1, 4, (V[]){v_fieldTypes_2446, v_k_245, v_level_2444, v_defaults_2447});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_VSum: {
    V v_vs_2452 = heff_field(v_x_249, 0);
    heff_take_n(v_x_249, 1ULL, 1);
    V v_t_2453 = heff_arrayToList(heff_take_field(v_vs_2452, 0));
    V v_t_2454 = heff_arrayToList(heff_get_n(v_vs_2452, 2, 3));
    V v_t_2455 = (g_heff_2eutil_2edict_2ezipKV(v_t_2453, v_t_2454));
    V v_c_2466 = (g_prelude_2etraverse_24s1934076392x614790049(heff_clo_n(g_heff_2eelab_2eunify_2erenameTypeF_24s1867739536x151311522_lam12, 1, 3, (V[]){v_g_240, v_m_241, v_pr_242}), v_t_2455));
    V f_ = v_c_2466;
    heff_room[0] = v_hd_244;
    heff_room[1] = heff_clo_n(g_heff_2eelab_2eunify_2erenameTypeF_24s1867739536x151311522_lam16, 1, 1, (V[]){v_k_245});
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
  case TAG_VPrimInt: {
    heff_drop(v_pr_242);
    heff_drop_rec(v_hd_244, 3);
    heff_drop(v_g_240);
    heff_drop(v_m_241);
    V f_ = v_k_245;
    args[0] = NTAG(TAG_SPrimInt);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_VPrimFloat: {
    heff_drop(v_pr_242);
    heff_drop_rec(v_hd_244, 3);
    heff_drop(v_g_240);
    heff_drop(v_m_241);
    V f_ = v_k_245;
    args[0] = NTAG(TAG_SPrimFloat);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_VPrimString: {
    heff_drop(v_pr_242);
    heff_drop_rec(v_hd_244, 3);
    heff_drop(v_g_240);
    heff_drop(v_m_241);
    V f_ = v_k_245;
    args[0] = NTAG(TAG_SPrimString);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_VPrimRune: {
    heff_drop(v_pr_242);
    heff_drop_rec(v_hd_244, 3);
    heff_drop(v_g_240);
    heff_drop(v_m_241);
    V f_ = v_k_245;
    args[0] = NTAG(TAG_SPrimRune);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_VPrimArray: {
    V v_a_2473 = heff_field(v_x_249, 0);
    heff_take_n(v_x_249, 1ULL, 1);
    return (g_heff_2eelab_2eunify_2erenameTypeF_24s1867739536x151311522(v_g_240, v_m_241, v_pr_242, v_a_2473, v_hd_244, heff_clo_n(g_heff_2eelab_2eunify_2erenameTypeF_24s1867739536x151311522_lam17, 1, 1, (V[]){v_k_245})));
  }
  case TAG_VFixed: {
    V v_w_2475 = heff_field(v_x_249, 0);
    heff_take_n(v_x_249, 1ULL, 1);
    heff_drop(v_pr_242);
    heff_drop_rec(v_hd_244, 3);
    heff_drop(v_g_240);
    heff_drop(v_m_241);
    V f_ = v_k_245;
    args[0] = heff_tag_n(TAG_SFixed, 1, (V[]){v_w_2475});
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  default: return heff_nomatch(v_x_249);
  }
}
V g_heff_2eelab_2eunify_2erenameClo_24s1533138512x710427120_lam0(V self, V *args);
V g_heff_2eelab_2eunify_2erenameClo_24s1533138512x710427120_lam1(V self, V *args);
V g_heff_2eelab_2eunify_2erenameClo_24s1533138512x710427120_lam4(V self, V *args);
V g_heff_2eelab_2eunify_2erenameClo_24s1533138512x710427120_lam3(V self, V *args);
V g_heff_2eelab_2eunify_2erenameClo_24s1533138512x710427120_lam5(V self, V *args);
V g_heff_2eelab_2eunify_2erenameClo_24s1533138512x710427120_lam2(V self, V *args);
V g_heff_2eelab_2eunify_2erenameClo_24s1533138512x710427120_lam8(V self, V *args);
V g_heff_2eelab_2eunify_2erenameClo_24s1533138512x710427120_lam7(V self, V *args);
V g_heff_2eelab_2eunify_2erenameClo_24s1533138512x710427120_lam9(V self, V *args);
V g_heff_2eelab_2eunify_2erenameClo_24s1533138512x710427120_lam6(V self, V *args);
Clo g_heff_2eelab_2eunify_2erenameClo_24s1533138512x710427120_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2erenameClo_24s1533138512x710427120_entry, 5, 0};

V g_heff_2eelab_2eunify_2erenameClo_24s1533138512x710427120(V v_g_240, V v_m_241, V v_pr_242, V v_dom_243, V v_x6_244) {
top: ;
  switch (heff_tag_of(v_x6_244)) {
  case TAG_MkClo: {
    V v_x_245 = heff_field(v_x6_244, 0);
    V v_l_246 = heff_field(v_x6_244, 1);
    V v_f_247 = heff_field(v_x6_244, 2);
    heff_take_n(v_x6_244, 7ULL, 3);
    V v_t_248 = heff_intAdd(heff_dup(heff_rfield(v_pr_242, 0)), MK_INT(1LL));
    V v_t_249 = heff_intAdd(heff_dup(heff_rfield(v_pr_242, 1)), MK_INT(1LL));
    V v_t_2410 = (g_std_2emap_2einsert_24s170109517x1206653089(heff_take_field(v_pr_242, 2), heff_dup(heff_rfield(v_pr_242, 0)), heff_take_field(v_pr_242, 1)));
    V v_pr_2411 = heff_rec_n(3, shape_dom__cod__ren, (V[]){v_t_248, v_t_249, v_t_2410});
    V v_t_2412 = heff_tag_n(TAG_HLocal, 1, (V[]){heff_get_n(v_pr_242, 0, 3)});
    V v_v_2414 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(v_t_2412, NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2eunify_2erenameClo_24s1533138512x710427120_lam0, 1, 1, (V[]){v_dom_243}), NTAG(TAG_Nothing)));
    V v_v_2416 = heff_tr(heff_call(v_f_247, 1, (V[]){heff_tag_n(TAG_LSnoc, 2, (V[]){v_l_246, heff_clo_n(g_heff_2eelab_2eunify_2erenameClo_24s1533138512x710427120_lam1, 1, 1, (V[]){v_v_2414})})}));
    return heff_clo_n(g_heff_2eelab_2eunify_2erenameClo_24s1533138512x710427120_lam2, 2, 5, (V[]){v_v_2416, v_g_240, v_m_241, v_pr_2411, v_x_245});
  }
  case TAG_CloConst: {
    V v_t_2427 = heff_field(v_x6_244, 0);
    heff_take_n(v_x6_244, 1ULL, 1);
    heff_drop(v_dom_243);
    return heff_clo_n(g_heff_2eelab_2eunify_2erenameClo_24s1533138512x710427120_lam6, 2, 4, (V[]){v_t_2427, v_g_240, v_m_241, v_pr_242});
  }
  default: return heff_nomatch(v_x6_244);
  }
}
V g_heff_2eelab_2eunify_2erenameClo_24s1533138512x710427120_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2erenameClo_24s1533138512x710427120(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2eelab_2eunify_2erenameClo_24s1533138512x710427120_lam0(V self, V *args) {
  V v_u_2413 = args[0];
  V v_dom_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2413);
  return v_dom_243;
}
V g_heff_2eelab_2eunify_2erenameClo_24s1533138512x710427120_lam1(V self, V *args) {
  V v_u_2415 = args[0];
  V v_v_2414 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2415);
  return v_v_2414;
}
V g_heff_2eelab_2eunify_2erenameClo_24s1533138512x710427120_lam4(V self, V *args) {
  V v_x_2424 = args[0];
  V v_k_2423 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_2423;
  args[0] = heff_tag_n(TAG_SIs, 1, (V[]){v_x_2424});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameClo_24s1533138512x710427120_lam3(V self, V *args) {
  V v_hd_2422 = args[0];
  V v_k_2423 = args[1];
  V v_g_240 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  V v_pr_2411 = heff_env(self)[2];
  V v_v_2421 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2eelab_2eunify_2erenameF_24s729918997x629913808(v_g_240, v_m_241, v_pr_2411, v_v_2421, v_hd_2422, heff_clo_n(g_heff_2eelab_2eunify_2erenameClo_24s1533138512x710427120_lam4, 1, 1, (V[]){v_k_2423})));
}
V g_heff_2eelab_2eunify_2erenameClo_24s1533138512x710427120_lam5(V self, V *args) {
  V v_x_2426 = args[0];
  V v_k_2418 = heff_env(self)[0];
  V v_x_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_2418;
  args[0] = heff_tag_n(TAG_MkAbs, 2, (V[]){v_x_245, v_x_2426});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameClo_24s1533138512x710427120_lam2(V self, V *args) {
  V v_hd_2417 = args[0];
  V v_k_2418 = args[1];
  V v_v_2416 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_m_241 = heff_env(self)[2];
  V v_pr_2411 = heff_env(self)[3];
  V v_x_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2425;
  switch (heff_tag_of(v_v_2416)) {
  case TAG_Nom: {
    V v_v_2419 = heff_field(v_v_2416, 0);
    heff_take_n(v_v_2416, 1ULL, 1);
    v_t_2425 = heff_tr(heff_call(((V)&g_heff_2eelab_2eunify_2erenameF_24s729918997x629913808_clo), 4, (V[]){v_g_240, v_m_241, v_pr_2411, v_v_2419}));
    break;
  }
  case TAG_Describe: {
    V v_v_2420 = heff_field(v_v_2416, 0);
    heff_take_n(v_v_2416, 1ULL, 1);
    v_t_2425 = heff_tr(heff_call(((V)&g_heff_2eelab_2eunify_2erenameF_24s729918997x629913808_clo), 4, (V[]){v_g_240, v_m_241, v_pr_2411, v_v_2420}));
    break;
  }
  case TAG_Become: {
    V v_v_2421 = heff_field(v_v_2416, 0);
    heff_take_n(v_v_2416, 1ULL, 1);
    v_t_2425 = heff_clo_n(g_heff_2eelab_2eunify_2erenameClo_24s1533138512x710427120_lam3, 2, 4, (V[]){v_g_240, v_m_241, v_pr_2411, v_v_2421});
    break;
  }
  default: heff_nomatch(v_v_2416);
  }
  V f_ = v_t_2425;
  args[0] = v_hd_2417;
  args[1] = heff_clo_n(g_heff_2eelab_2eunify_2erenameClo_24s1533138512x710427120_lam5, 1, 2, (V[]){v_k_2418, v_x_245});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2erenameClo_24s1533138512x710427120_lam8(V self, V *args) {
  V v_x_2435 = args[0];
  V v_k_2434 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_2434;
  args[0] = heff_tag_n(TAG_SIs, 1, (V[]){v_x_2435});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameClo_24s1533138512x710427120_lam7(V self, V *args) {
  V v_hd_2433 = args[0];
  V v_k_2434 = args[1];
  V v_g_240 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  V v_pr_242 = heff_env(self)[2];
  V v_v_2432 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2eelab_2eunify_2erenameF_24s729918997x629913808(v_g_240, v_m_241, v_pr_242, v_v_2432, v_hd_2433, heff_clo_n(g_heff_2eelab_2eunify_2erenameClo_24s1533138512x710427120_lam8, 1, 1, (V[]){v_k_2434})));
}
V g_heff_2eelab_2eunify_2erenameClo_24s1533138512x710427120_lam9(V self, V *args) {
  V v_x_2437 = args[0];
  V v_k_2429 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_2429;
  args[0] = heff_tag_n(TAG_AbsConst, 1, (V[]){v_x_2437});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameClo_24s1533138512x710427120_lam6(V self, V *args) {
  V v_hd_2428 = args[0];
  V v_k_2429 = args[1];
  V v_t_2427 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_m_241 = heff_env(self)[2];
  V v_pr_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2436;
  switch (heff_tag_of(v_t_2427)) {
  case TAG_Nom: {
    V v_v_2430 = heff_field(v_t_2427, 0);
    heff_take_n(v_t_2427, 1ULL, 1);
    v_t_2436 = heff_tr(heff_call(((V)&g_heff_2eelab_2eunify_2erenameF_24s729918997x629913808_clo), 4, (V[]){v_g_240, v_m_241, v_pr_242, v_v_2430}));
    break;
  }
  case TAG_Describe: {
    V v_v_2431 = heff_field(v_t_2427, 0);
    heff_take_n(v_t_2427, 1ULL, 1);
    v_t_2436 = heff_tr(heff_call(((V)&g_heff_2eelab_2eunify_2erenameF_24s729918997x629913808_clo), 4, (V[]){v_g_240, v_m_241, v_pr_242, v_v_2431}));
    break;
  }
  case TAG_Become: {
    V v_v_2432 = heff_field(v_t_2427, 0);
    heff_take_n(v_t_2427, 1ULL, 1);
    v_t_2436 = heff_clo_n(g_heff_2eelab_2eunify_2erenameClo_24s1533138512x710427120_lam7, 2, 4, (V[]){v_g_240, v_m_241, v_pr_242, v_v_2432});
    break;
  }
  default: heff_nomatch(v_t_2427);
  }
  V f_ = v_t_2436;
  args[0] = v_hd_2428;
  args[1] = heff_clo_n(g_heff_2eelab_2eunify_2erenameClo_24s1533138512x710427120_lam9, 1, 1, (V[]){v_k_2429});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2esolveRhs_24s425854279x1932184403_lam0(V self, V *args);
V g_heff_2eelab_2eunify_2esolveRhs_24s425854279x1932184403_lam2(V self, V *args);
V g_heff_2eelab_2eunify_2esolveRhs_24s425854279x1932184403_lam3(V self, V *args);
V g_heff_2eelab_2eunify_2esolveRhs_24s425854279x1932184403_lam4(V self, V *args);
V g_heff_2eelab_2eunify_2esolveRhs_24s425854279x1932184403_lam5(V self, V *args); static Clo g_heff_2eelab_2eunify_2esolveRhs_24s425854279x1932184403_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2esolveRhs_24s425854279x1932184403_lam5, 2, 0};
V g_heff_2eelab_2eunify_2esolveRhs_24s425854279x1932184403_lam6(V self, V *args);
V g_heff_2eelab_2eunify_2esolveRhs_24s425854279x1932184403_lam1(V self, V *args);
V g_heff_2eelab_2eunify_2esolveRhs_24s425854279x1932184403_lam9(V self, V *args);
V g_heff_2eelab_2eunify_2esolveRhs_24s425854279x1932184403_lam12(V self, V *args); static Clo g_heff_2eelab_2eunify_2esolveRhs_24s425854279x1932184403_lam12_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2esolveRhs_24s425854279x1932184403_lam12, 1, 0};
V g_heff_2eelab_2eunify_2esolveRhs_24s425854279x1932184403_lam13(V self, V *args);
V g_heff_2eelab_2eunify_2esolveRhs_24s425854279x1932184403_lam11(V self, V *args);
V g_heff_2eelab_2eunify_2esolveRhs_24s425854279x1932184403_lam14(V self, V *args); static Clo g_heff_2eelab_2eunify_2esolveRhs_24s425854279x1932184403_lam14_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2esolveRhs_24s425854279x1932184403_lam14, 2, 0};
V g_heff_2eelab_2eunify_2esolveRhs_24s425854279x1932184403_lam15(V self, V *args);
V g_heff_2eelab_2eunify_2esolveRhs_24s425854279x1932184403_lam10(V self, V *args);
V g_heff_2eelab_2eunify_2esolveRhs_24s425854279x1932184403_lam8(V self, V *args);
V g_heff_2eelab_2eunify_2esolveRhs_24s425854279x1932184403_lam7(V self, V *args);
Clo g_heff_2eelab_2eunify_2esolveRhs_24s425854279x1932184403_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2esolveRhs_24s425854279x1932184403_entry, 7, 0};

V g_heff_2eelab_2eunify_2esolveRhs_24s425854279x1932184403(V v_g_240, V v_cs_241, V v_m_242, V v_args_243, V v_rhs_244, V v_z_245, V v_z_246) {
top: ;
  V v_t_247 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_args_243));
  V v_t_248 = (g_heff_2eelab_2eunify_2emapWithIndexL_24s919594025x2081681853(MK_INT(0LL), heff_dup(v_args_243)));
  V v_t_249 = ({ V a_0 = heff_dup(g_std_2emap_2eempty_get()); V a_1 = v_t_248; V r_ = (g_list_2efoldl_24s868530262x539343671(a_0, a_1)); heff_drop(v_t_248); r_; });
  V v_pr_2410 = heff_rec_n(3, shape_dom__cod__ren, (V[]){heff_get_n(v_cs_241, 0, 2), v_t_247, v_t_249});
  V v_t_2412 = heff_tr(g_heff_2eelab_2eunify_2erenameF_24s729918997x629913808(heff_dup(v_g_240), heff_dup(v_m_242), v_pr_2410, v_rhs_244, heff_dup(v_z_245), heff_clo_n(g_heff_2eelab_2eunify_2esolveRhs_24s425854279x1932184403_lam0, 1, 1, (V[]){heff_dup(v_z_245)})));
  V v_t_2445 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Catch, 2, (V[]){v_t_2412, heff_clo_n(g_heff_2eelab_2eunify_2esolveRhs_24s425854279x1932184403_lam1, 1, 1, (V[]){heff_dup(v_z_245)})})});
  V v_t_2446 = heff_tr(heff_call(heff_dup(heff_rfield(v_z_245, 2)), 1, (V[]){v_t_2445}));
  return heff_tail(heff_dup(heff_rfield(v_z_245, 1)), 2, (V[]){v_t_2446, heff_clo_n(g_heff_2eelab_2eunify_2esolveRhs_24s425854279x1932184403_lam7, 1, 5, (V[]){v_z_246, v_args_243, v_g_240, v_m_242, v_z_245})});
}
V g_heff_2eelab_2eunify_2esolveRhs_24s425854279x1932184403_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2esolveRhs_24s425854279x1932184403(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
V g_heff_2eelab_2eunify_2esolveRhs_24s425854279x1932184403_lam0(V self, V *args) {
  V v_x_2411 = args[0];
  V v_z_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_z_245, 0, 3);
  args[0] = heff_tag_n(TAG_Just, 1, (V[]){v_x_2411});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2esolveRhs_24s425854279x1932184403_lam2(V self, V *args) {
  V v_hd_2417 = args[0];
  V v_k2_2418 = args[1];
  V v_s_2413 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2419 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_s_2413})});
  V v_t_2420 = heff_tr(heff_call(heff_take_field(v_hd_2417, 2), 1, (V[]){v_t_2419}));
  V f_ = heff_get_n(v_hd_2417, 1, 3);
  args[0] = v_t_2420;
  args[1] = v_k2_2418;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2esolveRhs_24s425854279x1932184403_lam3(V self, V *args) {
  V v_hd_2424 = args[0];
  V v_k2_2425 = args[1];
  V v_s_2413 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2426 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_s_2413})});
  V v_t_2427 = heff_tr(heff_call(heff_take_field(v_hd_2424, 2), 1, (V[]){v_t_2426}));
  V f_ = heff_get_n(v_hd_2424, 1, 3);
  args[0] = v_t_2427;
  args[1] = v_k2_2425;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2esolveRhs_24s425854279x1932184403_lam4(V self, V *args) {
  V v_hd_2433 = args[0];
  V v_k2_2434 = args[1];
  V v_s_2413 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2435 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_s_2413})});
  V v_t_2436 = heff_tr(heff_call(heff_take_field(v_hd_2433, 2), 1, (V[]){v_t_2435}));
  V f_ = heff_get_n(v_hd_2433, 1, 3);
  args[0] = v_t_2436;
  args[1] = v_k2_2434;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2esolveRhs_24s425854279x1932184403_lam5(V self, V *args) {
  V v_hd_2437 = args[0];
  V v_k_2438 = args[1];
  heff_drop(v_hd_2437);
  V f_ = v_k_2438;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2esolveRhs_24s425854279x1932184403_lam6(V self, V *args) {
  V v_hd_2440 = args[0];
  V v_k2_2441 = args[1];
  V v_s_2413 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2442 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_s_2413})});
  V v_t_2443 = heff_tr(heff_call(heff_take_field(v_hd_2440, 2), 1, (V[]){v_t_2442}));
  V f_ = heff_get_n(v_hd_2440, 1, 3);
  args[0] = v_t_2443;
  args[1] = v_k2_2441;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2esolveRhs_24s425854279x1932184403_lam1(V self, V *args) {
  V v_s_2413 = args[0];
  V v_z_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2444;
  switch (heff_tag_of(v_s_2413)) {
  case TAG_UnequalTys: {
    v_t_2444 = heff_clo_n(g_heff_2eelab_2eunify_2esolveRhs_24s425854279x1932184403_lam2, 2, 1, (V[]){v_s_2413});
    break;
  }
  case TAG_UnequalEls: {
    v_t_2444 = heff_clo_n(g_heff_2eelab_2eunify_2esolveRhs_24s425854279x1932184403_lam3, 2, 1, (V[]){v_s_2413});
    break;
  }
  case TAG_UnequalNeus: {
    v_t_2444 = heff_clo_n(g_heff_2eelab_2eunify_2esolveRhs_24s425854279x1932184403_lam4, 2, 1, (V[]){v_s_2413});
    break;
  }
  case TAG_MentionsError: {
    v_t_2444 = ((V)&g_heff_2eelab_2eunify_2esolveRhs_24s425854279x1932184403_lam5_clo);
    break;
  }
  case TAG_Escapes: {
    v_t_2444 = heff_clo_n(g_heff_2eelab_2eunify_2esolveRhs_24s425854279x1932184403_lam6, 2, 1, (V[]){v_s_2413});
    break;
  }
  default: heff_nomatch(v_s_2413);
  }
  V f_ = v_t_2444;
  heff_room[0] = heff_dup(v_z_245);
  heff_room[1] = heff_get_n(v_z_245, 0, 3);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2eunify_2esolveRhs_24s425854279x1932184403_lam9(V self, V *args) {
  V v_c_2457 = args[0];
  V v_m_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2458 = ({ V b_0 = heff_get_n(v_c_2457, 2, 8); V a_1 = v_m_242; HeffT2 r_ = (g_std_2emap_2elookup_24s1576363199x1121931492_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
  {
    V v_field_2460 = v_t_2458.f[1];
    int64_t v_tag_2459 = ((int64_t)v_t_2458.f[0]);
    V v_ret_24bool = heff_bool(((v_tag_2459 == ((int64_t)0ULL)) && ({ V v_x_2462 = heff_dup(v_field_2460); int c_ = 1; heff_drop(v_x_2462); c_; })));
    heff_drop(v_field_2460);
    return v_ret_24bool;
  }
}
V g_heff_2eelab_2eunify_2esolveRhs_24s425854279x1932184403_lam12(V self, V *args) {
  V v_c_2468 = args[0];
  return heff_get_n(v_c_2468, 3, 8);
}
V g_heff_2eelab_2eunify_2esolveRhs_24s425854279x1932184403_lam13(V self, V *args) {
  V v_x_2471 = args[0];
  V v_v_2455 = heff_env(self)[0];
  V v_hd_2466 = heff_env(self)[1];
  V v_k_2467 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2472 = ({ V a_0 = v_x_2471; V r_ = (g_heff_2eelab_2eunify_2emetasK(a_0)); heff_drop(v_x_2471); r_; });
  V v_t_2473 = heff_tr(heff_call(heff_get_n(v_t_2472, 0, 3), 3, (V[]){MK_INT(20LL), MK_INT(0LL), v_v_2455}));
  return ({ V a_0 = v_t_2473; V a_1 = v_hd_2466; V a_2 = v_k_2467; V r_ = (g_heff_2eelab_2eunify_2epoisonMany_24s936578932x1254028474(a_0, a_1, a_2)); heff_drop(v_t_2473); r_; });
}
V g_heff_2eelab_2eunify_2esolveRhs_24s425854279x1932184403_lam11(V self, V *args) {
  V v_hd_2466 = args[0];
  V v_k_2467 = args[1];
  V v_v_2455 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2469 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2eunify_2esolveRhs_24s425854279x1932184403_lam12_clo)})});
  V v_t_2470 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_2466, 2)), 1, (V[]){v_t_2469}));
  V f_ = heff_dup(heff_rfield(v_hd_2466, 1));
  args[0] = v_t_2470;
  args[1] = heff_clo_n(g_heff_2eelab_2eunify_2esolveRhs_24s425854279x1932184403_lam13, 1, 3, (V[]){v_v_2455, v_hd_2466, v_k_2467});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2esolveRhs_24s425854279x1932184403_lam14(V self, V *args) {
  V v_hd_2474 = args[0];
  V v_k_2475 = args[1];
  heff_drop(v_hd_2474);
  V f_ = v_k_2475;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2esolveRhs_24s425854279x1932184403_lam15(V self, V *args) {
  V v_x_2477 = args[0];
  V v_m_242 = heff_env(self)[0];
  V v_t_2450 = heff_env(self)[1];
  V v_z_245 = heff_env(self)[2];
  V v_z_246 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2477);
  return (g_heff_2eelab_2eunify_2etraceSolve_24s814446277x267296740(v_m_242, v_t_2450, v_z_245, v_z_246));
}
V g_heff_2eelab_2eunify_2esolveRhs_24s425854279x1932184403_lam10(V self, V *args) {
  V v_x_2465 = args[0];
  V v_v_2455 = heff_env(self)[0];
  V v_z_245 = heff_env(self)[1];
  V v_m_242 = heff_env(self)[2];
  V v_t_2450 = heff_env(self)[3];
  V v_z_246 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2476;
  if ((heff_dup(v_x_2465) == NTAG(TAG_True))) {
    heff_drop(v_x_2465);
    v_t_2476 = heff_clo_n(g_heff_2eelab_2eunify_2esolveRhs_24s425854279x1932184403_lam11, 2, 1, (V[]){v_v_2455});
  } else {
    heff_drop(v_x_2465);
    heff_drop(v_v_2455);
    v_t_2476 = ((V)&g_heff_2eelab_2eunify_2esolveRhs_24s425854279x1932184403_lam14_clo);
  }
  V f_ = v_t_2476;
  heff_room[0] = heff_dup(v_z_245);
  heff_room[1] = heff_clo_n(g_heff_2eelab_2eunify_2esolveRhs_24s425854279x1932184403_lam15, 1, 4, (V[]){v_m_242, v_t_2450, v_z_245, v_z_246});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2eunify_2esolveRhs_24s425854279x1932184403_lam8(V self, V *args) {
  V v_x_2456 = args[0];
  V v_m_242 = heff_env(self)[0];
  V v_z_245 = heff_env(self)[1];
  V v_v_2455 = heff_env(self)[2];
  V v_t_2450 = heff_env(self)[3];
  V v_z_246 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2456);
  V v_t_2463 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2eunify_2esolveRhs_24s425854279x1932184403_lam9, 1, 1, (V[]){heff_dup(v_m_242)})})});
  V v_t_2464 = heff_tr(heff_call(heff_dup(heff_rfield(v_z_245, 2)), 1, (V[]){v_t_2463}));
  V f_ = heff_dup(heff_rfield(v_z_245, 1));
  heff_room[0] = v_t_2464;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2eunify_2esolveRhs_24s425854279x1932184403_lam10, 1, 5, (V[]){v_v_2455, v_z_245, v_m_242, v_t_2450, v_z_246});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2eunify_2esolveRhs_24s425854279x1932184403_lam7(V self, V *args) {
  V v_x_2447 = args[0];
  V v_z_246 = heff_env(self)[0];
  V v_args_243 = heff_env(self)[1];
  V v_g_240 = heff_env(self)[2];
  V v_m_242 = heff_env(self)[3];
  V v_z_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  switch (heff_tag_of(v_x_2447)) {
  case TAG_Nothing: {
    heff_drop(v_args_243);
    heff_drop(v_g_240);
    heff_drop(v_m_242);
    heff_drop_rec(v_z_245, 3);
    V f_ = v_z_246;
    args[0] = NTAG(TAG_MkUnit);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Just: {
    V v_body_2448 = heff_field(v_x_2447, 0);
    heff_take_n(v_x_2447, 1ULL, 1);
    V v_t_2449 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_args_243; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_args_243); r_; });
    V v_t_2450 = (g_heff_2eelab_2eunify_2elamsU(v_t_2449, v_body_2448));
    V v_x1_2451 = heff_tr(g_heff_2eelab_2eeval_2eevalTermF(heff_dup(g_heff_2eelab_2eeval_2eevaluator_get()), v_g_240, NTAG(TAG_N), heff_dup(v_t_2450), NTAG(TAG_LNil)));
    V v_v_2455;
    switch (heff_tag_of(v_x1_2451)) {
    case TAG_Nom: {
      V v_x_2452 = heff_field(v_x1_2451, 0);
      heff_take_n(v_x1_2451, 1ULL, 1);
      v_v_2455 = v_x_2452;
      break;
    }
    case TAG_Describe: {
      heff_take_n(v_x1_2451, 0ULL, 1);
      v_v_2455 = heff_abandon();
      break;
    }
    case TAG_Become: {
      V v_x_2454 = heff_field(v_x1_2451, 0);
      heff_take_n(v_x1_2451, 1ULL, 1);
      v_v_2455 = v_x_2454;
      break;
    }
    default: heff_nomatch(v_x1_2451);
    }
    return (g_heff_2eelab_2eunify_2estoreSol_24s657133741x1839249102(heff_dup(v_m_242), heff_dup(v_v_2455), heff_dup(v_t_2450), heff_dup(v_z_245), heff_clo_n(g_heff_2eelab_2eunify_2esolveRhs_24s425854279x1932184403_lam8, 1, 5, (V[]){v_m_242, v_z_245, v_v_2455, v_t_2450, v_z_246})));
  }
  default: return heff_nomatch(v_x_2447);
  }
}
V g_heff_2eelab_2eunify_2esolveF_24s863089x19463346_lam0(V self, V *args); static Clo g_heff_2eelab_2eunify_2esolveF_24s863089x19463346_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2esolveF_24s863089x19463346_lam0, 1, 0};
V g_heff_2eelab_2eunify_2esolveF_24s863089x19463346_lam2(V self, V *args); static Clo g_heff_2eelab_2eunify_2esolveF_24s863089x19463346_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2esolveF_24s863089x19463346_lam2, 1, 0};
V g_heff_2eelab_2eunify_2esolveF_24s863089x19463346_lam5(V self, V *args);
V g_heff_2eelab_2eunify_2esolveF_24s863089x19463346_lam4(V self, V *args);
V g_heff_2eelab_2eunify_2esolveF_24s863089x19463346_lam6(V self, V *args); static Clo g_heff_2eelab_2eunify_2esolveF_24s863089x19463346_lam6_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2esolveF_24s863089x19463346_lam6, 1, 0};
V g_heff_2eelab_2eunify_2esolveF_24s863089x19463346_lam7(V self, V *args);
V g_heff_2eelab_2eunify_2esolveF_24s863089x19463346_lam3(V self, V *args);
V g_heff_2eelab_2eunify_2esolveF_24s863089x19463346_lam1(V self, V *args);
Clo g_heff_2eelab_2eunify_2esolveF_24s863089x19463346_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2esolveF_24s863089x19463346_entry, 8, 0};

V g_heff_2eelab_2eunify_2esolveF_24s863089x19463346(V v_g_240, V v_cs_241, V v_m_242, V v_sp_243, V v_rhs_244, V v_self_245, V v_hd_246, V v_k_247) {
top: ;
  V v_t_249 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2eunify_2esolveF_24s863089x19463346_lam0_clo)})});
  V v_t_2410 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_246, 2)), 1, (V[]){v_t_249}));
  return heff_tail(heff_dup(heff_rfield(v_hd_246, 1)), 2, (V[]){v_t_2410, heff_clo_n(g_heff_2eelab_2eunify_2esolveF_24s863089x19463346_lam1, 1, 8, (V[]){v_hd_246, v_sp_243, v_rhs_244, v_g_240, v_cs_241, v_m_242, v_k_247, v_self_245})});
}
V g_heff_2eelab_2eunify_2esolveF_24s863089x19463346_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2esolveF_24s863089x19463346(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
}
V g_heff_2eelab_2eunify_2esolveF_24s863089x19463346_lam0(V self, V *args) {
  V v_c_248 = args[0];
  return heff_get_n(v_c_248, 3, 8);
}
V g_heff_2eelab_2eunify_2esolveF_24s863089x19463346_lam2(V self, V *args) {
  V v_c_2412 = args[0];
  return heff_get_n(v_c_2412, 7, 8);
}
V g_heff_2eelab_2eunify_2esolveF_24s863089x19463346_lam5(V self, V *args) {
  V v_x_2450 = args[0];
  V v_k_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_x_2450);
  V f_ = v_k_247;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2esolveF_24s863089x19463346_lam4(V self, V *args) {
  V v_x_2445 = args[0];
  V v_args_2423 = heff_env(self)[0];
  V v_args_27_2440 = heff_env(self)[1];
  V v_g_240 = heff_env(self)[2];
  V v_m_242 = heff_env(self)[3];
  V v_hd_246 = heff_env(self)[4];
  V v_k_247 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_t_2446 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_args_2423));
  V v_t_2447 = (g_heff_2eelab_2eunify_2ezipL(v_args_2423, v_args_27_2440));
  V v_t_2448 = (g_heff_2eelab_2eunify_2emapWithIndexL_24s1606268187x1223772876(MK_INT(0LL), v_t_2447));
  V v_t_2449 = (g_heff_2eelab_2eunify_2ecatMaybes(v_t_2448));
  return (g_heff_2eelab_2eunify_2esolveWithPruned_24s179009019x1439592890(v_g_240, heff_dup(v_m_242), v_m_242, v_x_2445, v_t_2446, v_t_2449, v_hd_246, heff_clo_n(g_heff_2eelab_2eunify_2esolveF_24s863089x19463346_lam5, 1, 1, (V[]){v_k_247})));
}
V g_heff_2eelab_2eunify_2esolveF_24s863089x19463346_lam6(V self, V *args) {
  V v_c_2452 = args[0];
  return heff_get_n(v_c_2452, 3, 8);
}
V g_heff_2eelab_2eunify_2esolveF_24s863089x19463346_lam7(V self, V *args) {
  V v_x_2455 = args[0];
  V v_m_242 = heff_env(self)[0];
  V v_k_2451 = heff_env(self)[1];
  V v_hd_246 = heff_env(self)[2];
  heff_clo_take(self, 3);
  HeffT2 v_t_2456 = ({ V a_0 = v_x_2455; V a_1 = v_m_242; HeffT2 r_ = (g_std_2emap_2elookup_24s1702756637x1169753568_24cpr(a_0, a_1)); heff_drop(v_x_2455); r_; });
  {
    V v_field_2458 = v_t_2456.f[1];
    int64_t v_tag_2457 = ((int64_t)v_t_2456.f[0]);
    if ((v_tag_2457 == ((int64_t)0ULL))) {
      heff_drop_rec(v_hd_246, 3);
      V v_e_2460 = v_field_2458;
      V f_ = v_k_2451;
      args[0] = v_e_2460;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    } else {
      heff_drop(v_field_2458);
      V v_t_2461 = heff_tag_n(TAG_UnequalEls, 3, (V[]){heff_dup(g_heff_2eelab_2eparams_2eemptyShape_get()), NTAG(TAG_VOpaque), NTAG(TAG_VOpaque)});
      V v_t_2462 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2461})});
      V v_t_2463 = heff_tr(heff_call(heff_take_field(v_hd_246, 2), 1, (V[]){v_t_2462}));
      V f_ = heff_get_n(v_hd_246, 1, 3);
      heff_room[0] = v_t_2463;
      heff_room[1] = v_k_2451;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
  }
}
V g_heff_2eelab_2eunify_2esolveF_24s863089x19463346_lam3(V self, V *args) {
  V v_x_2415 = args[0];
  V v_x_2411 = heff_env(self)[0];
  V v_sp_243 = heff_env(self)[1];
  V v_rhs_244 = heff_env(self)[2];
  V v_g_240 = heff_env(self)[3];
  V v_cs_241 = heff_env(self)[4];
  V v_m_242 = heff_env(self)[5];
  V v_hd_246 = heff_env(self)[6];
  V v_k_247 = heff_env(self)[7];
  V v_self_245 = heff_env(self)[8];
  heff_clo_take(self, 9);
  HeffT2 v_t_2416 = (g_heff_2eelab_2eunify_2epatSpine_24cpr(v_x_2415, v_x_2411, v_sp_243));
  {
    V v_field_2418 = v_t_2416.f[1];
    int64_t v_tag_2417 = ((int64_t)v_t_2416.f[0]);
    if ((v_tag_2417 == ((int64_t)0ULL))) {
      V v_items_2420 = v_field_2418;
      V v_t_2421 = (g_heff_2eelab_2eunify_2epatVarsOf(heff_dup(v_items_2420)));
      V v_t_2422 = ({ V a_0 = v_t_2421; V r_ = (g_heff_2eelab_2eunify_2edistinct(a_0)); heff_drop(v_t_2421); r_; });
      if ((heff_dup(v_t_2422) == NTAG(TAG_True))) {
        heff_drop(v_t_2422);
        V v_args_2423 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_items_2420));
        switch (heff_tag_of(v_rhs_244)) {
        case TAG_VNeu: {
          V v_v1_2424 = heff_dup(heff_field(v_rhs_244, 0));
          V v_sp_2425 = heff_dup(heff_field(v_rhs_244, 1));
          switch (heff_tag_of(v_v1_2424)) {
          case TAG_HLocal: {
            heff_take_n(v_v1_2424, 0ULL, 1);
            heff_drop(v_x_2415);
            heff_drop(v_x_2411);
            heff_drop(v_self_245);
            heff_drop(v_sp_2425);
            return (g_heff_2eelab_2eunify_2esolveRhs_24s425854279x1932184403(v_g_240, v_cs_241, v_m_242, v_args_2423, v_rhs_244, v_hd_246, v_k_247));
          }
          case TAG_HGlobal: {
            heff_take_n(v_v1_2424, 0ULL, 1);
            heff_drop(v_x_2415);
            heff_drop(v_x_2411);
            heff_drop(v_self_245);
            heff_drop(v_sp_2425);
            return (g_heff_2eelab_2eunify_2esolveRhs_24s425854279x1932184403(v_g_240, v_cs_241, v_m_242, v_args_2423, v_rhs_244, v_hd_246, v_k_247));
          }
          case TAG_HMeta: {
            V v_m_2431 = heff_field(v_v1_2424, 0);
            V v_ru_24v1_2424_24HMeta = heff_take_reuse_n(v_v1_2424, 1ULL, 1);
            if (heff_intEq_c_lent(v_m_2431, v_m_242, 1)) {
              HeffT2 v_t_2433 = ({ V a_0 = v_x_2415; V a_1 = v_x_2411; V a_2 = v_sp_2425; HeffT2 r_ = (g_heff_2eelab_2eunify_2epatSpine_24cpr(a_0, a_1, a_2)); heff_drop(v_x_2415); heff_drop(v_x_2411); r_; });
              {
                V v_field_2435 = v_t_2433.f[1];
                int64_t v_tag_2434 = ((int64_t)v_t_2433.f[0]);
                if ((v_tag_2434 == ((int64_t)0ULL))) {
                  V v_items_2437 = v_field_2435;
                  V v_t_2438 = (g_heff_2eelab_2eunify_2epatVarsOf(heff_dup(v_items_2437)));
                  V v_t_2439 = ({ V a_0 = v_t_2438; V r_ = (g_heff_2eelab_2eunify_2edistinct(a_0)); heff_drop(v_t_2438); r_; });
                  if ((heff_dup(v_t_2439) == NTAG(TAG_True))) {
                    heff_drop(v_t_2439);
                    V v_args_27_2440 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_items_2437));
                    V v_t_2441 = (g_heff_2eelab_2eunify_2eeqPatArgs(v_args_27_2440, v_args_2423));
                    if ((heff_dup(v_t_2441) == NTAG(TAG_True))) {
                      heff_drop_tag(v_rhs_244, 5);
                      heff_drop(v_g_240);
                      heff_drop(v_cs_241);
                      heff_drop(v_m_242);
                      heff_drop_rec(v_hd_246, 3);
                      heff_drop(v_self_245);
                      heff_drop(v_args_2423);
                      heff_drop_cell(v_ru_24v1_2424_24HMeta, 1);
                      heff_drop(v_args_27_2440);
                      heff_drop(v_t_2441);
                      V f_ = v_k_247;
                      args[0] = NTAG(TAG_MkUnit);
                      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
                      return heff_tail(f_, 1, args);
                    } else {
                      heff_drop(v_t_2441);
                      V v_t_2442 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_args_27_2440));
                      V v_t_2443 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_args_2423));
                      if (heff_intEq_c(v_t_2442, v_t_2443)) {
                        heff_drop_tag(v_rhs_244, 5);
                        heff_drop(v_cs_241);
                        heff_drop(v_self_245);
                        V v_k_2451 = heff_clo_n(g_heff_2eelab_2eunify_2esolveF_24s863089x19463346_lam4, 1, 6, (V[]){v_args_2423, v_args_27_2440, v_g_240, heff_dup(v_m_242), heff_dup(v_hd_246), v_k_247});
                        V v_t_2453 = heff_tag_at_n(v_ru_24v1_2424_24HMeta, TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2eunify_2esolveF_24s863089x19463346_lam6_clo)})});
                        V v_t_2454 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_246, 2)), 1, (V[]){v_t_2453}));
                        V f_ = heff_dup(heff_rfield(v_hd_246, 1));
                        heff_room[0] = v_t_2454;
                        heff_room[1] = heff_clo_n(g_heff_2eelab_2eunify_2esolveF_24s863089x19463346_lam7, 1, 3, (V[]){v_m_242, v_k_2451, v_hd_246});
                        if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
                        return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
                      } else {
                        heff_drop(v_g_240);
                        heff_drop(v_m_242);
                        heff_drop(v_args_2423);
                        heff_drop_cell(v_ru_24v1_2424_24HMeta, 1);
                        heff_drop(v_args_27_2440);
                        return (g_heff_2eelab_2eunify_2epostponeU_24s1873620235x793075195(v_cs_241, v_self_245, v_rhs_244, v_hd_246, v_k_247));
                      }
                    }
                  } else {
                    heff_drop(v_g_240);
                    heff_drop(v_m_242);
                    heff_drop(v_args_2423);
                    heff_drop_cell(v_ru_24v1_2424_24HMeta, 1);
                    heff_drop(v_items_2437);
                    heff_drop(v_t_2439);
                    return (g_heff_2eelab_2eunify_2epostponeU_24s1873620235x793075195(v_cs_241, v_self_245, v_rhs_244, v_hd_246, v_k_247));
                  }
                } else {
                  heff_drop(v_g_240);
                  heff_drop(v_m_242);
                  heff_drop(v_args_2423);
                  heff_drop_cell(v_ru_24v1_2424_24HMeta, 1);
                  heff_drop(v_field_2435);
                  return (g_heff_2eelab_2eunify_2epostponeU_24s1873620235x793075195(v_cs_241, v_self_245, v_rhs_244, v_hd_246, v_k_247));
                }
              }
            } else {
              heff_drop(v_x_2415);
              heff_drop(v_x_2411);
              heff_drop(v_self_245);
              heff_drop(v_sp_2425);
              heff_drop_cell(v_ru_24v1_2424_24HMeta, 1);
              return (g_heff_2eelab_2eunify_2esolveRhs_24s425854279x1932184403(v_g_240, v_cs_241, v_m_242, v_args_2423, v_rhs_244, v_hd_246, v_k_247));
            }
          }
          case TAG_HError: {
            heff_drop(v_x_2415);
            heff_drop(v_x_2411);
            heff_drop(v_self_245);
            heff_drop(v_sp_2425);
            return (g_heff_2eelab_2eunify_2esolveRhs_24s425854279x1932184403(v_g_240, v_cs_241, v_m_242, v_args_2423, v_rhs_244, v_hd_246, v_k_247));
          }
          default: return heff_nomatch(v_v1_2424);
          }
        }
        case TAG_VCode: {
          heff_drop(v_x_2415);
          heff_drop(v_x_2411);
          heff_drop(v_self_245);
          return (g_heff_2eelab_2eunify_2esolveRhs_24s425854279x1932184403(v_g_240, v_cs_241, v_m_242, v_args_2423, v_rhs_244, v_hd_246, v_k_247));
        }
        case TAG_VLam: {
          heff_drop(v_x_2415);
          heff_drop(v_x_2411);
          heff_drop(v_self_245);
          return (g_heff_2eelab_2eunify_2esolveRhs_24s425854279x1932184403(v_g_240, v_cs_241, v_m_242, v_args_2423, v_rhs_244, v_hd_246, v_k_247));
        }
        case TAG_VCons: {
          heff_drop(v_x_2415);
          heff_drop(v_x_2411);
          heff_drop(v_self_245);
          return (g_heff_2eelab_2eunify_2esolveRhs_24s425854279x1932184403(v_g_240, v_cs_241, v_m_242, v_args_2423, v_rhs_244, v_hd_246, v_k_247));
        }
        case TAG_VOpaque: {
          heff_drop(v_x_2415);
          heff_drop(v_x_2411);
          heff_drop(v_self_245);
          return (g_heff_2eelab_2eunify_2esolveRhs_24s425854279x1932184403(v_g_240, v_cs_241, v_m_242, v_args_2423, v_rhs_244, v_hd_246, v_k_247));
        }
        default: return heff_nomatch(v_rhs_244);
        }
      } else {
        heff_drop(v_x_2415);
        heff_drop(v_x_2411);
        heff_drop(v_g_240);
        heff_drop(v_m_242);
        heff_drop(v_items_2420);
        heff_drop(v_t_2422);
        return (g_heff_2eelab_2eunify_2epostponeU_24s1873620235x793075195(v_cs_241, v_self_245, v_rhs_244, v_hd_246, v_k_247));
      }
    } else {
      heff_drop(v_x_2415);
      heff_drop(v_x_2411);
      heff_drop(v_g_240);
      heff_drop(v_m_242);
      heff_drop(v_field_2418);
      return (g_heff_2eelab_2eunify_2epostponeU_24s1873620235x793075195(v_cs_241, v_self_245, v_rhs_244, v_hd_246, v_k_247));
    }
  }
}
V g_heff_2eelab_2eunify_2esolveF_24s863089x19463346_lam1(V self, V *args) {
  V v_x_2411 = args[0];
  V v_hd_246 = heff_env(self)[0];
  V v_sp_243 = heff_env(self)[1];
  V v_rhs_244 = heff_env(self)[2];
  V v_g_240 = heff_env(self)[3];
  V v_cs_241 = heff_env(self)[4];
  V v_m_242 = heff_env(self)[5];
  V v_k_247 = heff_env(self)[6];
  V v_self_245 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2413 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2eunify_2esolveF_24s863089x19463346_lam2_clo)})});
  V v_t_2414 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_246, 2)), 1, (V[]){v_t_2413}));
  V f_ = heff_dup(heff_rfield(v_hd_246, 1));
  heff_room[0] = v_t_2414;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2eunify_2esolveF_24s863089x19463346_lam3, 1, 9, (V[]){v_x_2411, v_sp_243, v_rhs_244, v_g_240, v_cs_241, v_m_242, v_hd_246, v_k_247, v_self_245});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2eunify_2euBareF_24s1918624290x273142086_lam0(V self, V *args); static Clo g_heff_2eelab_2eunify_2euBareF_24s1918624290x273142086_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2euBareF_24s1918624290x273142086_lam0, 2, 0};
V g_heff_2eelab_2eunify_2euBareF_24s1918624290x273142086_lam1(V self, V *args); static Clo g_heff_2eelab_2eunify_2euBareF_24s1918624290x273142086_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2euBareF_24s1918624290x273142086_lam1, 2, 0};
V g_heff_2eelab_2eunify_2euBareF_24s1918624290x273142086_lam2(V self, V *args);
V g_heff_2eelab_2eunify_2euBareF_24s1918624290x273142086_lam3(V self, V *args);
V g_heff_2eelab_2eunify_2euBareF_24s1918624290x273142086_lam4(V self, V *args);
V g_heff_2eelab_2eunify_2euBareF_24s1918624290x273142086_lam5(V self, V *args);
V g_heff_2eelab_2eunify_2euBareF_24s1918624290x273142086_lam6(V self, V *args);
V g_heff_2eelab_2eunify_2euBareF_24s1918624290x273142086_lam8(V self, V *args);
V g_heff_2eelab_2eunify_2euBareF_24s1918624290x273142086_lam7(V self, V *args);
V g_heff_2eelab_2eunify_2euBareF_24s1918624290x273142086_lam9(V self, V *args);
V g_heff_2eelab_2eunify_2euBareF_24s1918624290x273142086_lam10(V self, V *args);
V g_heff_2eelab_2eunify_2euBareF_24s1918624290x273142086_lam11(V self, V *args);
V g_heff_2eelab_2eunify_2euBareF_24s1918624290x273142086_lam12(V self, V *args);
V g_heff_2eelab_2eunify_2euBareF_24s1918624290x273142086_lam14(V self, V *args);
V g_heff_2eelab_2eunify_2euBareF_24s1918624290x273142086_lam13(V self, V *args);
V g_heff_2eelab_2eunify_2euBareF_24s1918624290x273142086_lam15(V self, V *args);
V g_heff_2eelab_2eunify_2euBareF_24s1918624290x273142086_lam16(V self, V *args);
V g_heff_2eelab_2eunify_2euBareF_24s1918624290x273142086_lam17(V self, V *args);
V g_heff_2eelab_2eunify_2euBareF_24s1918624290x273142086_lam18(V self, V *args);
V g_heff_2eelab_2eunify_2euBareF_24s1918624290x273142086_lam21(V self, V *args); static Clo g_heff_2eelab_2eunify_2euBareF_24s1918624290x273142086_lam21_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2euBareF_24s1918624290x273142086_lam21, 2, 0};
V g_heff_2eelab_2eunify_2euBareF_24s1918624290x273142086_lam22(V self, V *args);
V g_heff_2eelab_2eunify_2euBareF_24s1918624290x273142086_lam23(V self, V *args);
V g_heff_2eelab_2eunify_2euBareF_24s1918624290x273142086_lam20(V self, V *args);
V g_heff_2eelab_2eunify_2euBareF_24s1918624290x273142086_lam19(V self, V *args);
Clo g_heff_2eelab_2eunify_2euBareF_24s1918624290x273142086_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2euBareF_24s1918624290x273142086_entry, 6, 0};

V g_heff_2eelab_2eunify_2euBareF_24s1918624290x273142086(V v_g_240, V v_cs_241, V v_h_242, V v_sp_243, V v_h_27_244, V v_sp_27_245) {
top: ;
  V v_t_2418;
  switch (heff_tag_of(v_h_242)) {
  case TAG_HLocal: {
    switch (heff_tag_of(v_h_27_244)) {
    case TAG_HLocal: {
      v_t_2418 = NTAG(TAG_False);
      break;
    }
    case TAG_HGlobal: {
      v_t_2418 = NTAG(TAG_False);
      break;
    }
    case TAG_HMeta: {
      v_t_2418 = NTAG(TAG_False);
      break;
    }
    case TAG_HError: {
      v_t_2418 = NTAG(TAG_True);
      break;
    }
    default: heff_nomatch(v_h_27_244);
    }
    break;
  }
  case TAG_HGlobal: {
    switch (heff_tag_of(v_h_27_244)) {
    case TAG_HLocal: {
      v_t_2418 = NTAG(TAG_False);
      break;
    }
    case TAG_HGlobal: {
      v_t_2418 = NTAG(TAG_False);
      break;
    }
    case TAG_HMeta: {
      v_t_2418 = NTAG(TAG_False);
      break;
    }
    case TAG_HError: {
      v_t_2418 = NTAG(TAG_True);
      break;
    }
    default: heff_nomatch(v_h_27_244);
    }
    break;
  }
  case TAG_HMeta: {
    switch (heff_tag_of(v_h_27_244)) {
    case TAG_HLocal: {
      v_t_2418 = NTAG(TAG_False);
      break;
    }
    case TAG_HGlobal: {
      v_t_2418 = NTAG(TAG_False);
      break;
    }
    case TAG_HMeta: {
      v_t_2418 = NTAG(TAG_False);
      break;
    }
    case TAG_HError: {
      v_t_2418 = NTAG(TAG_True);
      break;
    }
    default: heff_nomatch(v_h_27_244);
    }
    break;
  }
  case TAG_HError: {
    v_t_2418 = NTAG(TAG_True);
    break;
  }
  default: heff_nomatch(v_h_242);
  }
  if ((heff_dup(v_t_2418) == NTAG(TAG_True))) {
    heff_drop(v_g_240);
    heff_drop(v_cs_241);
    heff_drop(v_h_242);
    heff_drop(v_sp_243);
    heff_drop(v_h_27_244);
    heff_drop(v_sp_27_245);
    heff_drop(v_t_2418);
    return ((V)&g_heff_2eelab_2eunify_2euBareF_24s1918624290x273142086_lam0_clo);
  } else {
    heff_drop(v_t_2418);
    switch (heff_tag_of(v_sp_243)) {
    case TAG_SpId: {
      heff_drop(v_g_240);
      switch (heff_tag_of(v_sp_27_245)) {
      case TAG_SpId: {
        V v_t_2421 = (g_heff_2eelab_2econversion_2eeqHead(v_h_242, v_h_27_244));
        if ((heff_dup(v_t_2421) == NTAG(TAG_True))) {
          heff_drop(v_cs_241);
          heff_drop(v_h_242);
          heff_drop(v_h_27_244);
          heff_drop(v_t_2421);
          return ((V)&g_heff_2eelab_2eunify_2euBareF_24s1918624290x273142086_lam1_clo);
        } else {
          heff_drop(v_t_2421);
          return heff_clo_n(g_heff_2eelab_2eunify_2euBareF_24s1918624290x273142086_lam2, 2, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245});
        }
      }
      case TAG_SpApp: {
        return heff_clo_n(g_heff_2eelab_2eunify_2euBareF_24s1918624290x273142086_lam3, 2, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245});
      }
      case TAG_SpProj: {
        return heff_clo_n(g_heff_2eelab_2eunify_2euBareF_24s1918624290x273142086_lam4, 2, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245});
      }
      case TAG_SpSpec: {
        return heff_clo_n(g_heff_2eelab_2eunify_2euBareF_24s1918624290x273142086_lam5, 2, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245});
      }
      default: return heff_nomatch(v_sp_27_245);
      }
    }
    case TAG_SpApp: {
      V v_sq_2447 = heff_dup(heff_field(v_sp_243, 0));
      V v_v_2448 = heff_dup(heff_field(v_sp_243, 1));
      switch (heff_tag_of(v_sp_27_245)) {
      case TAG_SpId: {
        heff_drop(v_g_240);
        heff_drop(v_sq_2447);
        heff_drop(v_v_2448);
        return heff_clo_n(g_heff_2eelab_2eunify_2euBareF_24s1918624290x273142086_lam6, 2, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245});
      }
      case TAG_SpApp: {
        V v_sq_27_2453 = heff_field(v_sp_27_245, 0);
        V v_v_27_2454 = heff_field(v_sp_27_245, 1);
        heff_take_n(v_sp_27_245, 3ULL, 2);
        heff_drop_tag(v_sp_243, 2);
        V v_c_2455 = (g_heff_2eelab_2eunify_2euBareF_24s1918624290x273142086(heff_dup(v_g_240), heff_dup(v_cs_241), v_h_242, v_sq_2447, v_h_27_244, v_sq_27_2453));
        return heff_clo_n(g_heff_2eelab_2eunify_2euBareF_24s1918624290x273142086_lam7, 2, 5, (V[]){v_c_2455, v_g_240, v_cs_241, v_v_2448, v_v_27_2454});
      }
      case TAG_SpProj: {
        heff_drop(v_g_240);
        heff_drop(v_sq_2447);
        heff_drop(v_v_2448);
        return heff_clo_n(g_heff_2eelab_2eunify_2euBareF_24s1918624290x273142086_lam9, 2, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245});
      }
      case TAG_SpSpec: {
        heff_drop(v_g_240);
        heff_drop(v_sq_2447);
        heff_drop(v_v_2448);
        return heff_clo_n(g_heff_2eelab_2eunify_2euBareF_24s1918624290x273142086_lam10, 2, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245});
      }
      default: return heff_nomatch(v_sp_27_245);
      }
    }
    case TAG_SpProj: {
      V v_sq_2473 = heff_dup(heff_field(v_sp_243, 0));
      V v_x_2474 = heff_dup(heff_field(v_sp_243, 1));
      switch (heff_tag_of(v_sp_27_245)) {
      case TAG_SpId: {
        heff_drop(v_g_240);
        heff_drop(v_sq_2473);
        heff_drop(v_x_2474);
        return heff_clo_n(g_heff_2eelab_2eunify_2euBareF_24s1918624290x273142086_lam11, 2, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245});
      }
      case TAG_SpApp: {
        heff_drop(v_g_240);
        heff_drop(v_sq_2473);
        heff_drop(v_x_2474);
        return heff_clo_n(g_heff_2eelab_2eunify_2euBareF_24s1918624290x273142086_lam12, 2, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245});
      }
      case TAG_SpProj: {
        V v_sq_27_2485 = heff_dup(heff_field(v_sp_27_245, 0));
        V v_x_27_2486 = heff_dup(heff_field(v_sp_27_245, 1));
        V v_c_2487 = (g_heff_2eelab_2eunify_2euBareF_24s1918624290x273142086(v_g_240, heff_dup(v_cs_241), heff_dup(v_h_242), v_sq_2473, heff_dup(v_h_27_244), v_sq_27_2485));
        return heff_clo_n(g_heff_2eelab_2eunify_2euBareF_24s1918624290x273142086_lam13, 2, 8, (V[]){v_c_2487, v_x_2474, v_x_27_2486, v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245});
      }
      case TAG_SpSpec: {
        heff_drop(v_g_240);
        heff_drop(v_sq_2473);
        heff_drop(v_x_2474);
        return heff_clo_n(g_heff_2eelab_2eunify_2euBareF_24s1918624290x273142086_lam15, 2, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245});
      }
      default: return heff_nomatch(v_sp_27_245);
      }
    }
    case TAG_SpSpec: {
      V v_sq_24101 = heff_dup(heff_field(v_sp_243, 0));
      V v_x_24102 = heff_dup(heff_field(v_sp_243, 1));
      V v_v_24103 = heff_dup(heff_field(v_sp_243, 2));
      switch (heff_tag_of(v_sp_27_245)) {
      case TAG_SpId: {
        heff_drop(v_g_240);
        heff_drop(v_sq_24101);
        heff_drop(v_x_24102);
        heff_drop(v_v_24103);
        return heff_clo_n(g_heff_2eelab_2eunify_2euBareF_24s1918624290x273142086_lam16, 2, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245});
      }
      case TAG_SpApp: {
        heff_drop(v_g_240);
        heff_drop(v_sq_24101);
        heff_drop(v_x_24102);
        heff_drop(v_v_24103);
        return heff_clo_n(g_heff_2eelab_2eunify_2euBareF_24s1918624290x273142086_lam17, 2, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245});
      }
      case TAG_SpProj: {
        heff_drop(v_g_240);
        heff_drop(v_sq_24101);
        heff_drop(v_x_24102);
        heff_drop(v_v_24103);
        return heff_clo_n(g_heff_2eelab_2eunify_2euBareF_24s1918624290x273142086_lam18, 2, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245});
      }
      case TAG_SpSpec: {
        V v_sq_27_24120 = heff_dup(heff_field(v_sp_27_245, 0));
        V v_x_27_24121 = heff_dup(heff_field(v_sp_27_245, 1));
        V v_v_27_24122 = heff_dup(heff_field(v_sp_27_245, 2));
        V v_c_24123 = (g_heff_2eelab_2eunify_2euBareF_24s1918624290x273142086(heff_dup(v_g_240), heff_dup(v_cs_241), heff_dup(v_h_242), v_sq_24101, heff_dup(v_h_27_244), v_sq_27_24120));
        return heff_clo_n(g_heff_2eelab_2eunify_2euBareF_24s1918624290x273142086_lam19, 2, 11, (V[]){v_c_24123, v_x_24102, v_x_27_24121, v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245, v_g_240, v_v_24103, v_v_27_24122});
      }
      default: return heff_nomatch(v_sp_27_245);
      }
    }
    default: return heff_nomatch(v_sp_243);
    }
  }
}
V g_heff_2eelab_2eunify_2euBareF_24s1918624290x273142086_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2euBareF_24s1918624290x273142086(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2eelab_2eunify_2euBareF_24s1918624290x273142086_lam0(V self, V *args) {
  V v_hd_2419 = args[0];
  V v_k_2420 = args[1];
  heff_drop(v_hd_2419);
  V f_ = v_k_2420;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2euBareF_24s1918624290x273142086_lam1(V self, V *args) {
  V v_hd_2422 = args[0];
  V v_k_2423 = args[1];
  heff_drop(v_hd_2422);
  V f_ = v_k_2423;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2euBareF_24s1918624290x273142086_lam2(V self, V *args) {
  V v_hd_2424 = args[0];
  V v_k2_2425 = args[1];
  V v_cs_241 = heff_env(self)[0];
  V v_h_242 = heff_env(self)[1];
  V v_sp_243 = heff_env(self)[2];
  V v_h_27_244 = heff_env(self)[3];
  V v_sp_27_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2426 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalNeus, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245})});
  V v_t_2427 = heff_tr(heff_call(heff_take_field(v_hd_2424, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2426})}));
  V f_ = heff_get_n(v_hd_2424, 1, 3);
  args[0] = v_t_2427;
  args[1] = v_k2_2425;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2euBareF_24s1918624290x273142086_lam3(V self, V *args) {
  V v_hd_2430 = args[0];
  V v_k2_2431 = args[1];
  V v_cs_241 = heff_env(self)[0];
  V v_h_242 = heff_env(self)[1];
  V v_sp_243 = heff_env(self)[2];
  V v_h_27_244 = heff_env(self)[3];
  V v_sp_27_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2432 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalNeus, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245})});
  V v_t_2433 = heff_tr(heff_call(heff_take_field(v_hd_2430, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2432})}));
  V f_ = heff_get_n(v_hd_2430, 1, 3);
  args[0] = v_t_2433;
  args[1] = v_k2_2431;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2euBareF_24s1918624290x273142086_lam4(V self, V *args) {
  V v_hd_2436 = args[0];
  V v_k2_2437 = args[1];
  V v_cs_241 = heff_env(self)[0];
  V v_h_242 = heff_env(self)[1];
  V v_sp_243 = heff_env(self)[2];
  V v_h_27_244 = heff_env(self)[3];
  V v_sp_27_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2438 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalNeus, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245})});
  V v_t_2439 = heff_tr(heff_call(heff_take_field(v_hd_2436, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2438})}));
  V f_ = heff_get_n(v_hd_2436, 1, 3);
  args[0] = v_t_2439;
  args[1] = v_k2_2437;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2euBareF_24s1918624290x273142086_lam5(V self, V *args) {
  V v_hd_2443 = args[0];
  V v_k2_2444 = args[1];
  V v_cs_241 = heff_env(self)[0];
  V v_h_242 = heff_env(self)[1];
  V v_sp_243 = heff_env(self)[2];
  V v_h_27_244 = heff_env(self)[3];
  V v_sp_27_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2445 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalNeus, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245})});
  V v_t_2446 = heff_tr(heff_call(heff_take_field(v_hd_2443, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2445})}));
  V f_ = heff_get_n(v_hd_2443, 1, 3);
  args[0] = v_t_2446;
  args[1] = v_k2_2444;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2euBareF_24s1918624290x273142086_lam6(V self, V *args) {
  V v_hd_2449 = args[0];
  V v_k2_2450 = args[1];
  V v_cs_241 = heff_env(self)[0];
  V v_h_242 = heff_env(self)[1];
  V v_sp_243 = heff_env(self)[2];
  V v_h_27_244 = heff_env(self)[3];
  V v_sp_27_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2451 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalNeus, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245})});
  V v_t_2452 = heff_tr(heff_call(heff_take_field(v_hd_2449, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2451})}));
  V f_ = heff_get_n(v_hd_2449, 1, 3);
  args[0] = v_t_2452;
  args[1] = v_k2_2450;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2euBareF_24s1918624290x273142086_lam8(V self, V *args) {
  V v_x_2458 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_cs_241 = heff_env(self)[1];
  V v_v_2448 = heff_env(self)[2];
  V v_v_27_2454 = heff_env(self)[3];
  V v_hd_2456 = heff_env(self)[4];
  V v_k_2457 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_2458);
  V v_t_2459 = (g_heff_2eelab_2eunify_2euTermF(heff_dup(g_co_2eplus_24s973240257x441859337_get()), ((V)&g_heff_2eelab_2eunify_2emsEv_clo), ((V)&g_heff_2eelab_2eunify_2eufEv_clo), heff_dup(g_heff_2eelab_2eunify_2euk_24s506988832x820849616_get()), v_g_240, v_cs_241, v_v_2448, v_v_27_2454));
  V f_ = v_t_2459;
  heff_room[0] = v_hd_2456;
  heff_room[1] = v_k_2457;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2eunify_2euBareF_24s1918624290x273142086_lam7(V self, V *args) {
  V v_hd_2456 = args[0];
  V v_k_2457 = args[1];
  V v_c_2455 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_cs_241 = heff_env(self)[2];
  V v_v_2448 = heff_env(self)[3];
  V v_v_27_2454 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_2455;
  args[0] = heff_dup(v_hd_2456);
  args[1] = heff_clo_n(g_heff_2eelab_2eunify_2euBareF_24s1918624290x273142086_lam8, 1, 6, (V[]){v_g_240, v_cs_241, v_v_2448, v_v_27_2454, v_hd_2456, v_k_2457});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2euBareF_24s1918624290x273142086_lam9(V self, V *args) {
  V v_hd_2462 = args[0];
  V v_k2_2463 = args[1];
  V v_cs_241 = heff_env(self)[0];
  V v_h_242 = heff_env(self)[1];
  V v_sp_243 = heff_env(self)[2];
  V v_h_27_244 = heff_env(self)[3];
  V v_sp_27_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2464 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalNeus, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245})});
  V v_t_2465 = heff_tr(heff_call(heff_take_field(v_hd_2462, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2464})}));
  V f_ = heff_get_n(v_hd_2462, 1, 3);
  args[0] = v_t_2465;
  args[1] = v_k2_2463;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2euBareF_24s1918624290x273142086_lam10(V self, V *args) {
  V v_hd_2469 = args[0];
  V v_k2_2470 = args[1];
  V v_cs_241 = heff_env(self)[0];
  V v_h_242 = heff_env(self)[1];
  V v_sp_243 = heff_env(self)[2];
  V v_h_27_244 = heff_env(self)[3];
  V v_sp_27_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2471 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalNeus, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245})});
  V v_t_2472 = heff_tr(heff_call(heff_take_field(v_hd_2469, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2471})}));
  V f_ = heff_get_n(v_hd_2469, 1, 3);
  args[0] = v_t_2472;
  args[1] = v_k2_2470;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2euBareF_24s1918624290x273142086_lam11(V self, V *args) {
  V v_hd_2475 = args[0];
  V v_k2_2476 = args[1];
  V v_cs_241 = heff_env(self)[0];
  V v_h_242 = heff_env(self)[1];
  V v_sp_243 = heff_env(self)[2];
  V v_h_27_244 = heff_env(self)[3];
  V v_sp_27_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2477 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalNeus, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245})});
  V v_t_2478 = heff_tr(heff_call(heff_take_field(v_hd_2475, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2477})}));
  V f_ = heff_get_n(v_hd_2475, 1, 3);
  args[0] = v_t_2478;
  args[1] = v_k2_2476;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2euBareF_24s1918624290x273142086_lam12(V self, V *args) {
  V v_hd_2481 = args[0];
  V v_k2_2482 = args[1];
  V v_cs_241 = heff_env(self)[0];
  V v_h_242 = heff_env(self)[1];
  V v_sp_243 = heff_env(self)[2];
  V v_h_27_244 = heff_env(self)[3];
  V v_sp_27_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2483 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalNeus, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245})});
  V v_t_2484 = heff_tr(heff_call(heff_take_field(v_hd_2481, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2483})}));
  V f_ = heff_get_n(v_hd_2481, 1, 3);
  args[0] = v_t_2484;
  args[1] = v_k2_2482;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2euBareF_24s1918624290x273142086_lam14(V self, V *args) {
  V v_x_2490 = args[0];
  V v_x_2474 = heff_env(self)[0];
  V v_x_27_2486 = heff_env(self)[1];
  V v_k_2489 = heff_env(self)[2];
  V v_cs_241 = heff_env(self)[3];
  V v_h_242 = heff_env(self)[4];
  V v_sp_243 = heff_env(self)[5];
  V v_h_27_244 = heff_env(self)[6];
  V v_sp_27_245 = heff_env(self)[7];
  V v_hd_2488 = heff_env(self)[8];
  heff_clo_take(self, 9);
  heff_drop(v_x_2490);
  if (heff_strEq_c(v_x_2474, v_x_27_2486)) {
    heff_drop(v_cs_241);
    heff_drop(v_h_242);
    heff_drop_tag(v_sp_243, 2);
    heff_drop(v_h_27_244);
    heff_drop_tag(v_sp_27_245, 2);
    heff_drop_rec(v_hd_2488, 3);
    V f_ = v_k_2489;
    args[0] = NTAG(TAG_MkUnit);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  } else {
    V v_t_2492 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalNeus, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245})});
    V v_t_2493 = heff_tr(heff_call(heff_take_field(v_hd_2488, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2492})}));
    V f_ = heff_get_n(v_hd_2488, 1, 3);
    heff_room[0] = v_t_2493;
    heff_room[1] = v_k_2489;
    if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
    return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
  }
}
V g_heff_2eelab_2eunify_2euBareF_24s1918624290x273142086_lam13(V self, V *args) {
  V v_hd_2488 = args[0];
  V v_k_2489 = args[1];
  V v_c_2487 = heff_env(self)[0];
  V v_x_2474 = heff_env(self)[1];
  V v_x_27_2486 = heff_env(self)[2];
  V v_cs_241 = heff_env(self)[3];
  V v_h_242 = heff_env(self)[4];
  V v_sp_243 = heff_env(self)[5];
  V v_h_27_244 = heff_env(self)[6];
  V v_sp_27_245 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V f_ = v_c_2487;
  args[0] = heff_dup(v_hd_2488);
  args[1] = heff_clo_n(g_heff_2eelab_2eunify_2euBareF_24s1918624290x273142086_lam14, 1, 9, (V[]){v_x_2474, v_x_27_2486, v_k_2489, v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245, v_hd_2488});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2euBareF_24s1918624290x273142086_lam15(V self, V *args) {
  V v_hd_2497 = args[0];
  V v_k2_2498 = args[1];
  V v_cs_241 = heff_env(self)[0];
  V v_h_242 = heff_env(self)[1];
  V v_sp_243 = heff_env(self)[2];
  V v_h_27_244 = heff_env(self)[3];
  V v_sp_27_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2499 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalNeus, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245})});
  V v_t_24100 = heff_tr(heff_call(heff_take_field(v_hd_2497, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2499})}));
  V f_ = heff_get_n(v_hd_2497, 1, 3);
  args[0] = v_t_24100;
  args[1] = v_k2_2498;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2euBareF_24s1918624290x273142086_lam16(V self, V *args) {
  V v_hd_24104 = args[0];
  V v_k2_24105 = args[1];
  V v_cs_241 = heff_env(self)[0];
  V v_h_242 = heff_env(self)[1];
  V v_sp_243 = heff_env(self)[2];
  V v_h_27_244 = heff_env(self)[3];
  V v_sp_27_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_24106 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalNeus, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245})});
  V v_t_24107 = heff_tr(heff_call(heff_take_field(v_hd_24104, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24106})}));
  V f_ = heff_get_n(v_hd_24104, 1, 3);
  args[0] = v_t_24107;
  args[1] = v_k2_24105;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2euBareF_24s1918624290x273142086_lam17(V self, V *args) {
  V v_hd_24110 = args[0];
  V v_k2_24111 = args[1];
  V v_cs_241 = heff_env(self)[0];
  V v_h_242 = heff_env(self)[1];
  V v_sp_243 = heff_env(self)[2];
  V v_h_27_244 = heff_env(self)[3];
  V v_sp_27_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_24112 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalNeus, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245})});
  V v_t_24113 = heff_tr(heff_call(heff_take_field(v_hd_24110, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24112})}));
  V f_ = heff_get_n(v_hd_24110, 1, 3);
  args[0] = v_t_24113;
  args[1] = v_k2_24111;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2euBareF_24s1918624290x273142086_lam18(V self, V *args) {
  V v_hd_24116 = args[0];
  V v_k2_24117 = args[1];
  V v_cs_241 = heff_env(self)[0];
  V v_h_242 = heff_env(self)[1];
  V v_sp_243 = heff_env(self)[2];
  V v_h_27_244 = heff_env(self)[3];
  V v_sp_27_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_24118 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalNeus, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245})});
  V v_t_24119 = heff_tr(heff_call(heff_take_field(v_hd_24116, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24118})}));
  V f_ = heff_get_n(v_hd_24116, 1, 3);
  args[0] = v_t_24119;
  args[1] = v_k2_24117;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2euBareF_24s1918624290x273142086_lam21(V self, V *args) {
  V v_hd_24128 = args[0];
  V v_k_24129 = args[1];
  heff_drop(v_hd_24128);
  V f_ = v_k_24129;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2euBareF_24s1918624290x273142086_lam22(V self, V *args) {
  V v_hd_24130 = args[0];
  V v_k2_24131 = args[1];
  V v_cs_241 = heff_env(self)[0];
  V v_h_242 = heff_env(self)[1];
  V v_sp_243 = heff_env(self)[2];
  V v_h_27_244 = heff_env(self)[3];
  V v_sp_27_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_24132 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalNeus, 5, (V[]){v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245})});
  V v_t_24133 = heff_tr(heff_call(heff_take_field(v_hd_24130, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24132})}));
  V f_ = heff_get_n(v_hd_24130, 1, 3);
  args[0] = v_t_24133;
  args[1] = v_k2_24131;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2euBareF_24s1918624290x273142086_lam23(V self, V *args) {
  V v_x_24135 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_cs_241 = heff_env(self)[1];
  V v_v_24103 = heff_env(self)[2];
  V v_v_27_24122 = heff_env(self)[3];
  V v_hd_24124 = heff_env(self)[4];
  V v_k_24125 = heff_env(self)[5];
  heff_clo_take(self, 6);
  heff_drop(v_x_24135);
  V v_t_24136 = (g_heff_2eelab_2eunify_2euTermF(heff_dup(g_co_2eplus_24s973240257x441859337_get()), ((V)&g_heff_2eelab_2eunify_2emsEv_clo), ((V)&g_heff_2eelab_2eunify_2eufEv_clo), heff_dup(g_heff_2eelab_2eunify_2euk_24s506988832x820849616_get()), v_g_240, v_cs_241, v_v_24103, v_v_27_24122));
  V f_ = v_t_24136;
  heff_room[0] = v_hd_24124;
  heff_room[1] = v_k_24125;
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2eunify_2euBareF_24s1918624290x273142086_lam20(V self, V *args) {
  V v_x_24126 = args[0];
  V v_x_24102 = heff_env(self)[0];
  V v_x_27_24121 = heff_env(self)[1];
  V v_cs_241 = heff_env(self)[2];
  V v_h_242 = heff_env(self)[3];
  V v_sp_243 = heff_env(self)[4];
  V v_h_27_244 = heff_env(self)[5];
  V v_sp_27_245 = heff_env(self)[6];
  V v_hd_24124 = heff_env(self)[7];
  V v_g_240 = heff_env(self)[8];
  V v_v_24103 = heff_env(self)[9];
  V v_v_27_24122 = heff_env(self)[10];
  V v_k_24125 = heff_env(self)[11];
  heff_clo_take(self, 12);
  heff_drop(v_x_24126);
  V v_t_24134;
  if (heff_strEq_c(v_x_24102, v_x_27_24121)) {
    heff_drop(v_h_242);
    heff_drop_tag(v_sp_243, 3);
    heff_drop(v_h_27_244);
    heff_drop_tag(v_sp_27_245, 3);
    v_t_24134 = ((V)&g_heff_2eelab_2eunify_2euBareF_24s1918624290x273142086_lam21_clo);
  } else {
    v_t_24134 = heff_clo_n(g_heff_2eelab_2eunify_2euBareF_24s1918624290x273142086_lam22, 2, 5, (V[]){heff_dup(v_cs_241), v_h_242, v_sp_243, v_h_27_244, v_sp_27_245});
  }
  V f_ = v_t_24134;
  heff_room[0] = heff_dup(v_hd_24124);
  heff_room[1] = heff_clo_n(g_heff_2eelab_2eunify_2euBareF_24s1918624290x273142086_lam23, 1, 6, (V[]){v_g_240, v_cs_241, v_v_24103, v_v_27_24122, v_hd_24124, v_k_24125});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2eunify_2euBareF_24s1918624290x273142086_lam19(V self, V *args) {
  V v_hd_24124 = args[0];
  V v_k_24125 = args[1];
  V v_c_24123 = heff_env(self)[0];
  V v_x_24102 = heff_env(self)[1];
  V v_x_27_24121 = heff_env(self)[2];
  V v_cs_241 = heff_env(self)[3];
  V v_h_242 = heff_env(self)[4];
  V v_sp_243 = heff_env(self)[5];
  V v_h_27_244 = heff_env(self)[6];
  V v_sp_27_245 = heff_env(self)[7];
  V v_g_240 = heff_env(self)[8];
  V v_v_24103 = heff_env(self)[9];
  V v_v_27_24122 = heff_env(self)[10];
  heff_clo_take(self, 11);
  V f_ = v_c_24123;
  args[0] = heff_dup(v_hd_24124);
  args[1] = heff_clo_n(g_heff_2eelab_2eunify_2euBareF_24s1918624290x273142086_lam20, 1, 12, (V[]){v_x_24102, v_x_27_24121, v_cs_241, v_h_242, v_sp_243, v_h_27_244, v_sp_27_245, v_hd_24124, v_g_240, v_v_24103, v_v_27_24122, v_k_24125});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2erenameFlexF_24s1543574616x1092368858_lam0(V self, V *args); static Clo g_heff_2eelab_2eunify_2erenameFlexF_24s1543574616x1092368858_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2erenameFlexF_24s1543574616x1092368858_lam0, 1, 0};
V g_heff_2eelab_2eunify_2erenameFlexF_24s1543574616x1092368858_lam2(V self, V *args); static Clo g_heff_2eelab_2eunify_2erenameFlexF_24s1543574616x1092368858_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2erenameFlexF_24s1543574616x1092368858_lam2, 1, 0};
V g_heff_2eelab_2eunify_2erenameFlexF_24s1543574616x1092368858_lam4(V self, V *args);
V g_heff_2eelab_2eunify_2erenameFlexF_24s1543574616x1092368858_lam6(V self, V *args);
V g_heff_2eelab_2eunify_2erenameFlexF_24s1543574616x1092368858_lam7(V self, V *args);
V g_heff_2eelab_2eunify_2erenameFlexF_24s1543574616x1092368858_lam5(V self, V *args);
V g_heff_2eelab_2eunify_2erenameFlexF_24s1543574616x1092368858_lam8(V self, V *args); static Clo g_heff_2eelab_2eunify_2erenameFlexF_24s1543574616x1092368858_lam8_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2erenameFlexF_24s1543574616x1092368858_lam8, 1, 0};
V g_heff_2eelab_2eunify_2erenameFlexF_24s1543574616x1092368858_lam9(V self, V *args);
V g_heff_2eelab_2eunify_2erenameFlexF_24s1543574616x1092368858_lam13(V self, V *args);
V g_heff_2eelab_2eunify_2erenameFlexF_24s1543574616x1092368858_lam14(V self, V *args); static Clo g_heff_2eelab_2eunify_2erenameFlexF_24s1543574616x1092368858_lam14_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2erenameFlexF_24s1543574616x1092368858_lam14, 2, 0};
V g_heff_2eelab_2eunify_2erenameFlexF_24s1543574616x1092368858_lam15(V self, V *args); static Clo g_heff_2eelab_2eunify_2erenameFlexF_24s1543574616x1092368858_lam15_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2erenameFlexF_24s1543574616x1092368858_lam15, 2, 0};
V g_heff_2eelab_2eunify_2erenameFlexF_24s1543574616x1092368858_lam12(V self, V *args);
V g_heff_2eelab_2eunify_2erenameFlexF_24s1543574616x1092368858_lam16(V self, V *args);
V g_heff_2eelab_2eunify_2erenameFlexF_24s1543574616x1092368858_lam11(V self, V *args);
V g_heff_2eelab_2eunify_2erenameFlexF_24s1543574616x1092368858_lam10(V self, V *args);
V g_heff_2eelab_2eunify_2erenameFlexF_24s1543574616x1092368858_lam17(V self, V *args); static Clo g_heff_2eelab_2eunify_2erenameFlexF_24s1543574616x1092368858_lam17_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2erenameFlexF_24s1543574616x1092368858_lam17, 1, 0};
V g_heff_2eelab_2eunify_2erenameFlexF_24s1543574616x1092368858_lam18(V self, V *args);
V g_heff_2eelab_2eunify_2erenameFlexF_24s1543574616x1092368858_lam3(V self, V *args);
V g_heff_2eelab_2eunify_2erenameFlexF_24s1543574616x1092368858_lam1(V self, V *args);
Clo g_heff_2eelab_2eunify_2erenameFlexF_24s1543574616x1092368858_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2erenameFlexF_24s1543574616x1092368858_entry, 7, 0};

V g_heff_2eelab_2eunify_2erenameFlexF_24s1543574616x1092368858(V v_g_240, V v_m_241, V v_pr_242, V v_m_27_243, V v_sp_244, V v_hd_245, V v_k_246) {
top: ;
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2eunify_2erenameFlexF_24s1543574616x1092368858_lam0_clo)})});
  V v_t_249 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_245, 2)), 1, (V[]){v_t_248}));
  return heff_tail(heff_dup(heff_rfield(v_hd_245, 1)), 2, (V[]){v_t_249, heff_clo_n(g_heff_2eelab_2eunify_2erenameFlexF_24s1543574616x1092368858_lam1, 1, 7, (V[]){v_hd_245, v_sp_244, v_pr_242, v_g_240, v_m_241, v_m_27_243, v_k_246})});
}
V g_heff_2eelab_2eunify_2erenameFlexF_24s1543574616x1092368858_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2erenameFlexF_24s1543574616x1092368858(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
V g_heff_2eelab_2eunify_2erenameFlexF_24s1543574616x1092368858_lam0(V self, V *args) {
  V v_c_247 = args[0];
  return heff_get_n(v_c_247, 3, 8);
}
V g_heff_2eelab_2eunify_2erenameFlexF_24s1543574616x1092368858_lam2(V self, V *args) {
  V v_c_2411 = args[0];
  return heff_get_n(v_c_2411, 7, 8);
}
V g_heff_2eelab_2eunify_2erenameFlexF_24s1543574616x1092368858_lam4(V self, V *args) {
  V v_a_2423 = args[0];
  V v_pr_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_a_2423)) {
  case TAG_PVar: {
    V v_l_2424 = heff_field(v_a_2423, 0);
    heff_take_n(v_a_2423, 1ULL, 1);
    HeffT2 v_t_2425 = ({ V b_0 = heff_get_n(v_pr_242, 2, 3); V a_1 = v_l_2424; HeffT2 r_ = (g_std_2emap_2elookup_24s1576363199x1121931492_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
    {
      V v_field_2427 = v_t_2425.f[1];
      int64_t v_tag_2426 = ((int64_t)v_t_2425.f[0]);
      V v_ret_24bool = heff_bool(((v_tag_2426 == ((int64_t)0ULL)) ? ({ V v_x_2429 = heff_dup(v_field_2427); int c_ = 0; heff_drop(v_x_2429); c_; }) : 1));
      heff_drop(v_field_2427);
      return v_ret_24bool;
    }
  }
  case TAG_PSelf: {
    heff_drop_rec(v_pr_242, 3);
    return NTAG(TAG_True);
  }
  default: return heff_nomatch(v_a_2423);
  }
}
V g_heff_2eelab_2eunify_2erenameFlexF_24s1543574616x1092368858_lam6(V self, V *args) {
  V v_i_2433 = args[0];
  V v_a_2434 = args[1];
  V v_pr_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_a_2434)) {
  case TAG_PVar: {
    V v_l_2435 = heff_field(v_a_2434, 0);
    V v_ru_24a_2434_24PVar = heff_take_reuse_n(v_a_2434, 1ULL, 1);
    HeffT2 v_t_2436 = ({ V b_0 = heff_get_n(v_pr_242, 2, 3); V a_1 = v_l_2435; HeffT2 r_ = (g_std_2emap_2elookup_24s1576363199x1121931492_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
    {
      V v_field_2438 = v_t_2436.f[1];
      int64_t v_tag_2437 = ((int64_t)v_t_2436.f[0]);
      if ((v_tag_2437 == ((int64_t)0ULL))) {
        V v_x_2440 = v_field_2438;
        heff_drop(v_x_2440);
        return heff_tag_at_n(v_ru_24a_2434_24PVar, TAG_Just, 1, (V[]){v_i_2433});
      } else {
        heff_drop(v_i_2433);
        heff_drop_cell(v_ru_24a_2434_24PVar, 1);
        heff_drop(v_field_2438);
        return NTAG(TAG_Nothing);
      }
    }
  }
  case TAG_PSelf: {
    heff_drop(v_i_2433);
    heff_drop_rec(v_pr_242, 3);
    return NTAG(TAG_Nothing);
  }
  default: return heff_nomatch(v_a_2434);
  }
}
V g_heff_2eelab_2eunify_2erenameFlexF_24s1543574616x1092368858_lam7(V self, V *args) {
  V v_x_2443 = args[0];
  V v_sp_244 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_m_241 = heff_env(self)[2];
  V v_pr_242 = heff_env(self)[3];
  V v_hd_245 = heff_env(self)[4];
  V v_k_246 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_v_2444 = ({ V a_0 = v_x_2443; V a_1 = v_sp_244; V r_ = (g_heff_2eelab_2evalue_2ereplay(a_0, a_1)); heff_drop(v_sp_244); r_; });
  return (g_heff_2eelab_2eunify_2erenameF_24s1520005319x327185445(v_g_240, v_m_241, v_pr_242, v_v_2444, v_hd_245, v_k_246));
}
V g_heff_2eelab_2eunify_2erenameFlexF_24s1543574616x1092368858_lam5(V self, V *args) {
  V v_x_2431 = args[0];
  V v_args_2422 = heff_env(self)[0];
  V v_pr_242 = heff_env(self)[1];
  V v_g_240 = heff_env(self)[2];
  V v_m_241 = heff_env(self)[3];
  V v_m_27_243 = heff_env(self)[4];
  V v_hd_245 = heff_env(self)[5];
  V v_sp_244 = heff_env(self)[6];
  V v_k_246 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2432 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_args_2422));
  V v_t_2441 = (g_heff_2eelab_2eunify_2emapWithIndexL(MK_INT(0LL), heff_clo_n(g_heff_2eelab_2eunify_2erenameFlexF_24s1543574616x1092368858_lam6, 2, 1, (V[]){heff_dup(v_pr_242)}), v_args_2422));
  V v_t_2442 = (g_heff_2eelab_2eunify_2ecatMaybes(v_t_2441));
  return (g_heff_2eelab_2eunify_2esolveWithPruned_24s1068778609x578646792(heff_dup(v_g_240), heff_dup(v_m_241), v_m_27_243, v_x_2431, v_t_2432, v_t_2442, heff_dup(v_hd_245), heff_clo_n(g_heff_2eelab_2eunify_2erenameFlexF_24s1543574616x1092368858_lam7, 1, 6, (V[]){v_sp_244, v_g_240, v_m_241, v_pr_242, v_hd_245, v_k_246})));
}
V g_heff_2eelab_2eunify_2erenameFlexF_24s1543574616x1092368858_lam8(V self, V *args) {
  V v_c_2446 = args[0];
  return heff_get_n(v_c_2446, 3, 8);
}
V g_heff_2eelab_2eunify_2erenameFlexF_24s1543574616x1092368858_lam9(V self, V *args) {
  V v_x_2449 = args[0];
  V v_m_27_243 = heff_env(self)[0];
  V v_k_2445 = heff_env(self)[1];
  V v_hd_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  HeffT2 v_t_2450 = ({ V a_0 = v_x_2449; V a_1 = v_m_27_243; HeffT2 r_ = (g_std_2emap_2elookup_24s1702756637x1169753568_24cpr(a_0, a_1)); heff_drop(v_x_2449); r_; });
  {
    V v_field_2452 = v_t_2450.f[1];
    int64_t v_tag_2451 = ((int64_t)v_t_2450.f[0]);
    if ((v_tag_2451 == ((int64_t)0ULL))) {
      heff_drop_rec(v_hd_245, 3);
      V v_e_2454 = v_field_2452;
      V f_ = v_k_2445;
      args[0] = v_e_2454;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    } else {
      heff_drop(v_field_2452);
      V v_t_2455 = heff_tag_n(TAG_UnequalEls, 3, (V[]){heff_dup(g_heff_2eelab_2eparams_2eemptyShape_get()), NTAG(TAG_VOpaque), NTAG(TAG_VOpaque)});
      V v_t_2456 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2455})});
      V v_t_2457 = heff_tr(heff_call(heff_take_field(v_hd_245, 2), 1, (V[]){v_t_2456}));
      V f_ = heff_get_n(v_hd_245, 1, 3);
      heff_room[0] = v_t_2457;
      heff_room[1] = v_k_2445;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
  }
}
V g_heff_2eelab_2eunify_2erenameFlexF_24s1543574616x1092368858_lam13(V self, V *args) {
  V v_hd_2467 = args[0];
  V v_k_2468 = args[1];
  V v_pr_242 = heff_env(self)[0];
  V v_l_27_2466 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_hd_2467);
  V v_t_2469 = heff_intSub(heff_get_n(v_pr_242, 1, 3), v_l_27_2466);
  V f_ = v_k_2468;
  args[0] = heff_intSub(v_t_2469, MK_INT(1LL));
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameFlexF_24s1543574616x1092368858_lam14(V self, V *args) {
  V v_hd_2470 = args[0];
  V v_k2_2471 = args[1];
  V v_t_2472 = heff_tag_n(TAG_UnequalEls, 3, (V[]){heff_dup(g_heff_2eelab_2eparams_2eemptyShape_get()), NTAG(TAG_VOpaque), NTAG(TAG_VOpaque)});
  V v_t_2473 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2472})});
  V v_t_2474 = heff_tr(heff_call(heff_take_field(v_hd_2470, 2), 1, (V[]){v_t_2473}));
  V f_ = heff_get_n(v_hd_2470, 1, 3);
  args[0] = v_t_2474;
  args[1] = v_k2_2471;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2erenameFlexF_24s1543574616x1092368858_lam15(V self, V *args) {
  V v_hd_2475 = args[0];
  V v_k2_2476 = args[1];
  V v_t_2477 = heff_tag_n(TAG_UnequalEls, 3, (V[]){heff_dup(g_heff_2eelab_2eparams_2eemptyShape_get()), NTAG(TAG_VOpaque), NTAG(TAG_VOpaque)});
  V v_t_2478 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2477})});
  V v_t_2479 = heff_tr(heff_call(heff_take_field(v_hd_2475, 2), 1, (V[]){v_t_2478}));
  V f_ = heff_get_n(v_hd_2475, 1, 3);
  args[0] = v_t_2479;
  args[1] = v_k2_2476;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2erenameFlexF_24s1543574616x1092368858_lam12(V self, V *args) {
  V v_a_2460 = args[0];
  V v_pr_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_a_2460)) {
  case TAG_PVar: {
    V v_l_2461 = heff_field(v_a_2460, 0);
    heff_take_n(v_a_2460, 1ULL, 1);
    HeffT2 v_t_2462 = (g_std_2emap_2elookup_24s1702756637x1169753568_24cpr(heff_rfield(v_pr_242, 2), v_l_2461));
    {
      V v_field_2464 = v_t_2462.f[1];
      int64_t v_tag_2463 = ((int64_t)v_t_2462.f[0]);
      if ((v_tag_2463 == ((int64_t)0ULL))) {
        V v_l_27_2466 = v_field_2464;
        return heff_clo_n(g_heff_2eelab_2eunify_2erenameFlexF_24s1543574616x1092368858_lam13, 2, 2, (V[]){v_pr_242, v_l_27_2466});
      } else {
        heff_drop_rec(v_pr_242, 3);
        heff_drop(v_field_2464);
        return ((V)&g_heff_2eelab_2eunify_2erenameFlexF_24s1543574616x1092368858_lam14_clo);
      }
    }
  }
  case TAG_PSelf: {
    heff_drop_rec(v_pr_242, 3);
    return ((V)&g_heff_2eelab_2eunify_2erenameFlexF_24s1543574616x1092368858_lam15_clo);
  }
  default: return heff_nomatch(v_a_2460);
  }
}
V g_heff_2eelab_2eunify_2erenameFlexF_24s1543574616x1092368858_lam16(V self, V *args) {
  V v_x_2481 = args[0];
  V v_m_27_243 = heff_env(self)[0];
  V v_x_2459 = heff_env(self)[1];
  V v_k_246 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2482 = heff_tag_n(TAG_SMetaApp, 3, (V[]){v_m_27_243, heff_arrayFromList(v_x_2481), v_x_2459});
  V f_ = v_k_246;
  args[0] = v_t_2482;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameFlexF_24s1543574616x1092368858_lam11(V self, V *args) {
  V v_x_2459 = args[0];
  V v_pr_242 = heff_env(self)[0];
  V v_args_2422 = heff_env(self)[1];
  V v_hd_245 = heff_env(self)[2];
  V v_m_27_243 = heff_env(self)[3];
  V v_k_246 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_c_2480 = (g_prelude_2etraverse_24s1934076392x614790049(heff_clo_n(g_heff_2eelab_2eunify_2erenameFlexF_24s1543574616x1092368858_lam12, 1, 1, (V[]){v_pr_242}), v_args_2422));
  V f_ = v_c_2480;
  heff_room[0] = v_hd_245;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2eunify_2erenameFlexF_24s1543574616x1092368858_lam16, 1, 3, (V[]){v_m_27_243, v_x_2459, v_k_246});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2eunify_2erenameFlexF_24s1543574616x1092368858_lam10(V self, V *args) {
  V v_x_2458 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  V v_pr_242 = heff_env(self)[2];
  V v_hd_245 = heff_env(self)[3];
  V v_args_2422 = heff_env(self)[4];
  V v_m_27_243 = heff_env(self)[5];
  V v_k_246 = heff_env(self)[6];
  heff_clo_take(self, 7);
  return (g_heff_2eelab_2eunify_2erenameTypeF_24s2127245123x1551710640(v_g_240, v_m_241, heff_dup(v_pr_242), heff_get_n(v_x_2458, 0, 6), heff_dup(v_hd_245), heff_clo_n(g_heff_2eelab_2eunify_2erenameFlexF_24s1543574616x1092368858_lam11, 1, 5, (V[]){v_pr_242, v_args_2422, v_hd_245, v_m_27_243, v_k_246})));
}
V g_heff_2eelab_2eunify_2erenameFlexF_24s1543574616x1092368858_lam17(V self, V *args) {
  V v_c_2484 = args[0];
  return heff_get_n(v_c_2484, 3, 8);
}
V g_heff_2eelab_2eunify_2erenameFlexF_24s1543574616x1092368858_lam18(V self, V *args) {
  V v_x_2487 = args[0];
  V v_m_27_243 = heff_env(self)[0];
  V v_k_2483 = heff_env(self)[1];
  V v_hd_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  HeffT2 v_t_2488 = ({ V a_0 = v_x_2487; V a_1 = v_m_27_243; HeffT2 r_ = (g_std_2emap_2elookup_24s1702756637x1169753568_24cpr(a_0, a_1)); heff_drop(v_x_2487); r_; });
  {
    V v_field_2490 = v_t_2488.f[1];
    int64_t v_tag_2489 = ((int64_t)v_t_2488.f[0]);
    if ((v_tag_2489 == ((int64_t)0ULL))) {
      heff_drop_rec(v_hd_245, 3);
      V v_e_2492 = v_field_2490;
      V f_ = v_k_2483;
      args[0] = v_e_2492;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    } else {
      heff_drop(v_field_2490);
      V v_t_2493 = heff_tag_n(TAG_UnequalEls, 3, (V[]){heff_dup(g_heff_2eelab_2eparams_2eemptyShape_get()), NTAG(TAG_VOpaque), NTAG(TAG_VOpaque)});
      V v_t_2494 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2493})});
      V v_t_2495 = heff_tr(heff_call(heff_take_field(v_hd_245, 2), 1, (V[]){v_t_2494}));
      V f_ = heff_get_n(v_hd_245, 1, 3);
      heff_room[0] = v_t_2495;
      heff_room[1] = v_k_2483;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
  }
}
V g_heff_2eelab_2eunify_2erenameFlexF_24s1543574616x1092368858_lam3(V self, V *args) {
  V v_x_2414 = args[0];
  V v_x_2410 = heff_env(self)[0];
  V v_sp_244 = heff_env(self)[1];
  V v_pr_242 = heff_env(self)[2];
  V v_g_240 = heff_env(self)[3];
  V v_m_241 = heff_env(self)[4];
  V v_m_27_243 = heff_env(self)[5];
  V v_hd_245 = heff_env(self)[6];
  V v_k_246 = heff_env(self)[7];
  heff_clo_take(self, 8);
  HeffT2 v_t_2415 = ({ V a_0 = v_x_2414; V a_1 = v_x_2410; V a_2 = heff_dup(v_sp_244); HeffT2 r_ = (g_heff_2eelab_2eunify_2epatSpine_24cpr(a_0, a_1, a_2)); heff_drop(v_x_2414); heff_drop(v_x_2410); r_; });
  {
    V v_field_2417 = v_t_2415.f[1];
    int64_t v_tag_2416 = ((int64_t)v_t_2415.f[0]);
    if ((v_tag_2416 == ((int64_t)0ULL))) {
      V v_items_2419 = v_field_2417;
      V v_t_2420 = (g_heff_2eelab_2eunify_2epatVarsOf(heff_dup(v_items_2419)));
      V v_t_2421 = ({ V a_0 = v_t_2420; V r_ = (g_heff_2eelab_2eunify_2edistinct(a_0)); heff_drop(v_t_2420); r_; });
      if ((heff_dup(v_t_2421) == NTAG(TAG_True))) {
        heff_drop(v_t_2421);
        V v_args_2422 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_items_2419));
        V v_t_2430 = (g_heff_2eelab_2eunify_2eanyL(heff_clo_n(g_heff_2eelab_2eunify_2erenameFlexF_24s1543574616x1092368858_lam4, 1, 1, (V[]){heff_dup(v_pr_242)}), v_args_2422));
        if ((heff_dup(v_t_2430) == NTAG(TAG_True))) {
          heff_drop(v_t_2430);
          V v_k_2445 = heff_clo_n(g_heff_2eelab_2eunify_2erenameFlexF_24s1543574616x1092368858_lam5, 1, 8, (V[]){v_args_2422, v_pr_242, v_g_240, v_m_241, heff_dup(v_m_27_243), heff_dup(v_hd_245), v_sp_244, v_k_246});
          V v_t_2447 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2eunify_2erenameFlexF_24s1543574616x1092368858_lam8_clo)})});
          V v_t_2448 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_245, 2)), 1, (V[]){v_t_2447}));
          V f_ = heff_dup(heff_rfield(v_hd_245, 1));
          heff_room[0] = v_t_2448;
          heff_room[1] = heff_clo_n(g_heff_2eelab_2eunify_2erenameFlexF_24s1543574616x1092368858_lam9, 1, 3, (V[]){v_m_27_243, v_k_2445, v_hd_245});
          if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
          return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
        } else {
          heff_drop(v_sp_244);
          heff_drop(v_t_2430);
          V v_k_2483 = heff_clo_n(g_heff_2eelab_2eunify_2erenameFlexF_24s1543574616x1092368858_lam10, 1, 7, (V[]){v_g_240, v_m_241, v_pr_242, heff_dup(v_hd_245), v_args_2422, heff_dup(v_m_27_243), v_k_246});
          V v_t_2485 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2eunify_2erenameFlexF_24s1543574616x1092368858_lam17_clo)})});
          V v_t_2486 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_245, 2)), 1, (V[]){v_t_2485}));
          V f_ = heff_dup(heff_rfield(v_hd_245, 1));
          heff_room[0] = v_t_2486;
          heff_room[1] = heff_clo_n(g_heff_2eelab_2eunify_2erenameFlexF_24s1543574616x1092368858_lam18, 1, 3, (V[]){v_m_27_243, v_k_2483, v_hd_245});
          if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
          return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
        }
      } else {
        heff_drop(v_sp_244);
        heff_drop_rec(v_pr_242, 3);
        heff_drop(v_g_240);
        heff_drop(v_m_241);
        heff_drop(v_m_27_243);
        heff_drop(v_items_2419);
        heff_drop(v_t_2421);
        V v_t_2496 = heff_tag_n(TAG_UnequalEls, 3, (V[]){heff_dup(g_heff_2eelab_2eparams_2eemptyShape_get()), NTAG(TAG_VOpaque), NTAG(TAG_VOpaque)});
        V v_t_2497 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2496})});
        V v_t_2498 = heff_tr(heff_call(heff_take_field(v_hd_245, 2), 1, (V[]){v_t_2497}));
        V f_ = heff_get_n(v_hd_245, 1, 3);
        heff_room[0] = v_t_2498;
        heff_room[1] = v_k_246;
        if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
      }
    } else {
      heff_drop(v_sp_244);
      heff_drop_rec(v_pr_242, 3);
      heff_drop(v_g_240);
      heff_drop(v_m_241);
      heff_drop(v_m_27_243);
      heff_drop(v_field_2417);
      V v_t_2499 = heff_tag_n(TAG_UnequalEls, 3, (V[]){heff_dup(g_heff_2eelab_2eparams_2eemptyShape_get()), NTAG(TAG_VOpaque), NTAG(TAG_VOpaque)});
      V v_t_24100 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2499})});
      V v_t_24101 = heff_tr(heff_call(heff_take_field(v_hd_245, 2), 1, (V[]){v_t_24100}));
      V f_ = heff_get_n(v_hd_245, 1, 3);
      heff_room[0] = v_t_24101;
      heff_room[1] = v_k_246;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
  }
}
V g_heff_2eelab_2eunify_2erenameFlexF_24s1543574616x1092368858_lam1(V self, V *args) {
  V v_x_2410 = args[0];
  V v_hd_245 = heff_env(self)[0];
  V v_sp_244 = heff_env(self)[1];
  V v_pr_242 = heff_env(self)[2];
  V v_g_240 = heff_env(self)[3];
  V v_m_241 = heff_env(self)[4];
  V v_m_27_243 = heff_env(self)[5];
  V v_k_246 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2eunify_2erenameFlexF_24s1543574616x1092368858_lam2_clo)})});
  V v_t_2413 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_245, 2)), 1, (V[]){v_t_2412}));
  V f_ = heff_dup(heff_rfield(v_hd_245, 1));
  heff_room[0] = v_t_2413;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2eunify_2erenameFlexF_24s1543574616x1092368858_lam3, 1, 8, (V[]){v_x_2410, v_sp_244, v_pr_242, v_g_240, v_m_241, v_m_27_243, v_hd_245, v_k_246});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2eunify_2esolveRhs_24s630558595x2041110653_lam0(V self, V *args);
V g_heff_2eelab_2eunify_2esolveRhs_24s630558595x2041110653_lam2(V self, V *args);
V g_heff_2eelab_2eunify_2esolveRhs_24s630558595x2041110653_lam3(V self, V *args);
V g_heff_2eelab_2eunify_2esolveRhs_24s630558595x2041110653_lam4(V self, V *args);
V g_heff_2eelab_2eunify_2esolveRhs_24s630558595x2041110653_lam5(V self, V *args); static Clo g_heff_2eelab_2eunify_2esolveRhs_24s630558595x2041110653_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2esolveRhs_24s630558595x2041110653_lam5, 2, 0};
V g_heff_2eelab_2eunify_2esolveRhs_24s630558595x2041110653_lam6(V self, V *args);
V g_heff_2eelab_2eunify_2esolveRhs_24s630558595x2041110653_lam1(V self, V *args);
V g_heff_2eelab_2eunify_2esolveRhs_24s630558595x2041110653_lam9(V self, V *args);
V g_heff_2eelab_2eunify_2esolveRhs_24s630558595x2041110653_lam12(V self, V *args); static Clo g_heff_2eelab_2eunify_2esolveRhs_24s630558595x2041110653_lam12_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2esolveRhs_24s630558595x2041110653_lam12, 1, 0};
V g_heff_2eelab_2eunify_2esolveRhs_24s630558595x2041110653_lam13(V self, V *args);
V g_heff_2eelab_2eunify_2esolveRhs_24s630558595x2041110653_lam11(V self, V *args);
V g_heff_2eelab_2eunify_2esolveRhs_24s630558595x2041110653_lam14(V self, V *args); static Clo g_heff_2eelab_2eunify_2esolveRhs_24s630558595x2041110653_lam14_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2esolveRhs_24s630558595x2041110653_lam14, 2, 0};
V g_heff_2eelab_2eunify_2esolveRhs_24s630558595x2041110653_lam15(V self, V *args);
V g_heff_2eelab_2eunify_2esolveRhs_24s630558595x2041110653_lam10(V self, V *args);
V g_heff_2eelab_2eunify_2esolveRhs_24s630558595x2041110653_lam8(V self, V *args);
V g_heff_2eelab_2eunify_2esolveRhs_24s630558595x2041110653_lam7(V self, V *args);
Clo g_heff_2eelab_2eunify_2esolveRhs_24s630558595x2041110653_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2esolveRhs_24s630558595x2041110653_entry, 7, 0};

V g_heff_2eelab_2eunify_2esolveRhs_24s630558595x2041110653(V v_g_240, V v_cs_241, V v_m_242, V v_args_243, V v_rhs_244, V v_z_245, V v_z_246) {
top: ;
  V v_t_247 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_args_243));
  V v_t_248 = (g_heff_2eelab_2eunify_2emapWithIndexL_24s919594025x2081681853(MK_INT(0LL), heff_dup(v_args_243)));
  V v_t_249 = ({ V a_0 = heff_dup(g_std_2emap_2eempty_get()); V a_1 = v_t_248; V r_ = (g_list_2efoldl_24s868530262x539343671(a_0, a_1)); heff_drop(v_t_248); r_; });
  V v_pr_2410 = heff_rec_n(3, shape_dom__cod__ren, (V[]){heff_get_n(v_cs_241, 0, 2), v_t_247, v_t_249});
  V v_t_2412 = heff_tr(g_heff_2eelab_2eunify_2erenameF_24s1520005319x327185445(heff_dup(v_g_240), heff_dup(v_m_242), v_pr_2410, v_rhs_244, heff_dup(v_z_245), heff_clo_n(g_heff_2eelab_2eunify_2esolveRhs_24s630558595x2041110653_lam0, 1, 1, (V[]){heff_dup(v_z_245)})));
  V v_t_2445 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Catch, 2, (V[]){v_t_2412, heff_clo_n(g_heff_2eelab_2eunify_2esolveRhs_24s630558595x2041110653_lam1, 1, 1, (V[]){heff_dup(v_z_245)})})});
  V v_t_2446 = heff_tr(heff_call(heff_dup(heff_rfield(v_z_245, 2)), 1, (V[]){v_t_2445}));
  return heff_tail(heff_dup(heff_rfield(v_z_245, 1)), 2, (V[]){v_t_2446, heff_clo_n(g_heff_2eelab_2eunify_2esolveRhs_24s630558595x2041110653_lam7, 1, 5, (V[]){v_z_246, v_args_243, v_g_240, v_m_242, v_z_245})});
}
V g_heff_2eelab_2eunify_2esolveRhs_24s630558595x2041110653_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2esolveRhs_24s630558595x2041110653(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
V g_heff_2eelab_2eunify_2esolveRhs_24s630558595x2041110653_lam0(V self, V *args) {
  V v_x_2411 = args[0];
  V v_z_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = heff_get_n(v_z_245, 0, 3);
  args[0] = heff_tag_n(TAG_Just, 1, (V[]){v_x_2411});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2esolveRhs_24s630558595x2041110653_lam2(V self, V *args) {
  V v_hd_2417 = args[0];
  V v_k2_2418 = args[1];
  V v_s_2413 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2419 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_s_2413})});
  V v_t_2420 = heff_tr(heff_call(heff_take_field(v_hd_2417, 2), 1, (V[]){v_t_2419}));
  V f_ = heff_get_n(v_hd_2417, 1, 3);
  args[0] = v_t_2420;
  args[1] = v_k2_2418;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2esolveRhs_24s630558595x2041110653_lam3(V self, V *args) {
  V v_hd_2424 = args[0];
  V v_k2_2425 = args[1];
  V v_s_2413 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2426 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_s_2413})});
  V v_t_2427 = heff_tr(heff_call(heff_take_field(v_hd_2424, 2), 1, (V[]){v_t_2426}));
  V f_ = heff_get_n(v_hd_2424, 1, 3);
  args[0] = v_t_2427;
  args[1] = v_k2_2425;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2esolveRhs_24s630558595x2041110653_lam4(V self, V *args) {
  V v_hd_2433 = args[0];
  V v_k2_2434 = args[1];
  V v_s_2413 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2435 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_s_2413})});
  V v_t_2436 = heff_tr(heff_call(heff_take_field(v_hd_2433, 2), 1, (V[]){v_t_2435}));
  V f_ = heff_get_n(v_hd_2433, 1, 3);
  args[0] = v_t_2436;
  args[1] = v_k2_2434;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2esolveRhs_24s630558595x2041110653_lam5(V self, V *args) {
  V v_hd_2437 = args[0];
  V v_k_2438 = args[1];
  heff_drop(v_hd_2437);
  V f_ = v_k_2438;
  args[0] = NTAG(TAG_Nothing);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2esolveRhs_24s630558595x2041110653_lam6(V self, V *args) {
  V v_hd_2440 = args[0];
  V v_k2_2441 = args[1];
  V v_s_2413 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2442 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_s_2413})});
  V v_t_2443 = heff_tr(heff_call(heff_take_field(v_hd_2440, 2), 1, (V[]){v_t_2442}));
  V f_ = heff_get_n(v_hd_2440, 1, 3);
  args[0] = v_t_2443;
  args[1] = v_k2_2441;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2esolveRhs_24s630558595x2041110653_lam1(V self, V *args) {
  V v_s_2413 = args[0];
  V v_z_245 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2444;
  switch (heff_tag_of(v_s_2413)) {
  case TAG_UnequalTys: {
    v_t_2444 = heff_clo_n(g_heff_2eelab_2eunify_2esolveRhs_24s630558595x2041110653_lam2, 2, 1, (V[]){v_s_2413});
    break;
  }
  case TAG_UnequalEls: {
    v_t_2444 = heff_clo_n(g_heff_2eelab_2eunify_2esolveRhs_24s630558595x2041110653_lam3, 2, 1, (V[]){v_s_2413});
    break;
  }
  case TAG_UnequalNeus: {
    v_t_2444 = heff_clo_n(g_heff_2eelab_2eunify_2esolveRhs_24s630558595x2041110653_lam4, 2, 1, (V[]){v_s_2413});
    break;
  }
  case TAG_MentionsError: {
    v_t_2444 = ((V)&g_heff_2eelab_2eunify_2esolveRhs_24s630558595x2041110653_lam5_clo);
    break;
  }
  case TAG_Escapes: {
    v_t_2444 = heff_clo_n(g_heff_2eelab_2eunify_2esolveRhs_24s630558595x2041110653_lam6, 2, 1, (V[]){v_s_2413});
    break;
  }
  default: heff_nomatch(v_s_2413);
  }
  V f_ = v_t_2444;
  heff_room[0] = heff_dup(v_z_245);
  heff_room[1] = heff_get_n(v_z_245, 0, 3);
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2eunify_2esolveRhs_24s630558595x2041110653_lam9(V self, V *args) {
  V v_c_2457 = args[0];
  V v_m_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  HeffT2 v_t_2458 = ({ V b_0 = heff_get_n(v_c_2457, 2, 8); V a_1 = v_m_242; HeffT2 r_ = (g_std_2emap_2elookup_24s1576363199x1121931492_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
  {
    V v_field_2460 = v_t_2458.f[1];
    int64_t v_tag_2459 = ((int64_t)v_t_2458.f[0]);
    V v_ret_24bool = heff_bool(((v_tag_2459 == ((int64_t)0ULL)) && ({ V v_x_2462 = heff_dup(v_field_2460); int c_ = 1; heff_drop(v_x_2462); c_; })));
    heff_drop(v_field_2460);
    return v_ret_24bool;
  }
}
V g_heff_2eelab_2eunify_2esolveRhs_24s630558595x2041110653_lam12(V self, V *args) {
  V v_c_2468 = args[0];
  return heff_get_n(v_c_2468, 3, 8);
}
V g_heff_2eelab_2eunify_2esolveRhs_24s630558595x2041110653_lam13(V self, V *args) {
  V v_x_2471 = args[0];
  V v_v_2455 = heff_env(self)[0];
  V v_hd_2466 = heff_env(self)[1];
  V v_k_2467 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2472 = ({ V a_0 = v_x_2471; V r_ = (g_heff_2eelab_2eunify_2emetasK(a_0)); heff_drop(v_x_2471); r_; });
  V v_t_2473 = heff_tr(heff_call(heff_get_n(v_t_2472, 0, 3), 3, (V[]){MK_INT(20LL), MK_INT(0LL), v_v_2455}));
  return ({ V a_0 = v_t_2473; V a_1 = v_hd_2466; V a_2 = v_k_2467; V r_ = (g_heff_2eelab_2eunify_2epoisonMany_24s936578932x1254028474(a_0, a_1, a_2)); heff_drop(v_t_2473); r_; });
}
V g_heff_2eelab_2eunify_2esolveRhs_24s630558595x2041110653_lam11(V self, V *args) {
  V v_hd_2466 = args[0];
  V v_k_2467 = args[1];
  V v_v_2455 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2469 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2eunify_2esolveRhs_24s630558595x2041110653_lam12_clo)})});
  V v_t_2470 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_2466, 2)), 1, (V[]){v_t_2469}));
  V f_ = heff_dup(heff_rfield(v_hd_2466, 1));
  args[0] = v_t_2470;
  args[1] = heff_clo_n(g_heff_2eelab_2eunify_2esolveRhs_24s630558595x2041110653_lam13, 1, 3, (V[]){v_v_2455, v_hd_2466, v_k_2467});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2esolveRhs_24s630558595x2041110653_lam14(V self, V *args) {
  V v_hd_2474 = args[0];
  V v_k_2475 = args[1];
  heff_drop(v_hd_2474);
  V f_ = v_k_2475;
  args[0] = NTAG(TAG_MkUnit);
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2esolveRhs_24s630558595x2041110653_lam15(V self, V *args) {
  V v_x_2477 = args[0];
  V v_m_242 = heff_env(self)[0];
  V v_t_2450 = heff_env(self)[1];
  V v_z_245 = heff_env(self)[2];
  V v_z_246 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_2477);
  return (g_heff_2eelab_2eunify_2etraceSolve_24s814446277x267296740(v_m_242, v_t_2450, v_z_245, v_z_246));
}
V g_heff_2eelab_2eunify_2esolveRhs_24s630558595x2041110653_lam10(V self, V *args) {
  V v_x_2465 = args[0];
  V v_v_2455 = heff_env(self)[0];
  V v_z_245 = heff_env(self)[1];
  V v_m_242 = heff_env(self)[2];
  V v_t_2450 = heff_env(self)[3];
  V v_z_246 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2476;
  if ((heff_dup(v_x_2465) == NTAG(TAG_True))) {
    heff_drop(v_x_2465);
    v_t_2476 = heff_clo_n(g_heff_2eelab_2eunify_2esolveRhs_24s630558595x2041110653_lam11, 2, 1, (V[]){v_v_2455});
  } else {
    heff_drop(v_x_2465);
    heff_drop(v_v_2455);
    v_t_2476 = ((V)&g_heff_2eelab_2eunify_2esolveRhs_24s630558595x2041110653_lam14_clo);
  }
  V f_ = v_t_2476;
  heff_room[0] = heff_dup(v_z_245);
  heff_room[1] = heff_clo_n(g_heff_2eelab_2eunify_2esolveRhs_24s630558595x2041110653_lam15, 1, 4, (V[]){v_m_242, v_t_2450, v_z_245, v_z_246});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2eunify_2esolveRhs_24s630558595x2041110653_lam8(V self, V *args) {
  V v_x_2456 = args[0];
  V v_m_242 = heff_env(self)[0];
  V v_z_245 = heff_env(self)[1];
  V v_v_2455 = heff_env(self)[2];
  V v_t_2450 = heff_env(self)[3];
  V v_z_246 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2456);
  V v_t_2463 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2eunify_2esolveRhs_24s630558595x2041110653_lam9, 1, 1, (V[]){heff_dup(v_m_242)})})});
  V v_t_2464 = heff_tr(heff_call(heff_dup(heff_rfield(v_z_245, 2)), 1, (V[]){v_t_2463}));
  V f_ = heff_dup(heff_rfield(v_z_245, 1));
  heff_room[0] = v_t_2464;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2eunify_2esolveRhs_24s630558595x2041110653_lam10, 1, 5, (V[]){v_v_2455, v_z_245, v_m_242, v_t_2450, v_z_246});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2eunify_2esolveRhs_24s630558595x2041110653_lam7(V self, V *args) {
  V v_x_2447 = args[0];
  V v_z_246 = heff_env(self)[0];
  V v_args_243 = heff_env(self)[1];
  V v_g_240 = heff_env(self)[2];
  V v_m_242 = heff_env(self)[3];
  V v_z_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  switch (heff_tag_of(v_x_2447)) {
  case TAG_Nothing: {
    heff_drop(v_args_243);
    heff_drop(v_g_240);
    heff_drop(v_m_242);
    heff_drop_rec(v_z_245, 3);
    V f_ = v_z_246;
    args[0] = NTAG(TAG_MkUnit);
    if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 1, args);
  }
  case TAG_Just: {
    V v_body_2448 = heff_field(v_x_2447, 0);
    heff_take_n(v_x_2447, 1ULL, 1);
    V v_t_2449 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_args_243; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_args_243); r_; });
    V v_t_2450 = (g_heff_2eelab_2eunify_2elamsU(v_t_2449, v_body_2448));
    V v_x1_2451 = heff_tr(g_heff_2eelab_2eeval_2eevalTermF(heff_dup(g_heff_2eelab_2eeval_2eevaluator_get()), v_g_240, NTAG(TAG_N), heff_dup(v_t_2450), NTAG(TAG_LNil)));
    V v_v_2455;
    switch (heff_tag_of(v_x1_2451)) {
    case TAG_Nom: {
      V v_x_2452 = heff_field(v_x1_2451, 0);
      heff_take_n(v_x1_2451, 1ULL, 1);
      v_v_2455 = v_x_2452;
      break;
    }
    case TAG_Describe: {
      heff_take_n(v_x1_2451, 0ULL, 1);
      v_v_2455 = heff_abandon();
      break;
    }
    case TAG_Become: {
      V v_x_2454 = heff_field(v_x1_2451, 0);
      heff_take_n(v_x1_2451, 1ULL, 1);
      v_v_2455 = v_x_2454;
      break;
    }
    default: heff_nomatch(v_x1_2451);
    }
    return (g_heff_2eelab_2eunify_2estoreSol_24s657133741x1839249102(heff_dup(v_m_242), heff_dup(v_v_2455), heff_dup(v_t_2450), heff_dup(v_z_245), heff_clo_n(g_heff_2eelab_2eunify_2esolveRhs_24s630558595x2041110653_lam8, 1, 5, (V[]){v_m_242, v_z_245, v_v_2455, v_t_2450, v_z_246})));
  }
  default: return heff_nomatch(v_x_2447);
  }
}