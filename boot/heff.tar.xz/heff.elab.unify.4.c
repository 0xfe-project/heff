// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_AbsConst 8406
#define TAG_Become 65038
#define TAG_CloConst 61868
#define TAG_Describe 2650
#define TAG_Expl 20488
#define TAG_Get 18914
#define TAG_HError 21467
#define TAG_HGlobal 55847
#define TAG_HLocal 25864
#define TAG_HMeta 17321
#define TAG_Impl 63555
#define TAG_Inst 64617
#define TAG_LNil 57394
#define TAG_LSnoc 32613
#define TAG_LargeU 29057
#define TAG_MkAbs 54862
#define TAG_MkClo 57090
#define TAG_N 306
#define TAG_Nom 25944
#define TAG_PSelf 48502
#define TAG_PVar 52952
#define TAG_SAbandon 23437
#define TAG_SApp 57081
#define TAG_SCode 58360
#define TAG_SCons 58684
#define TAG_SFix 61677
#define TAG_SGlobal 8650
#define TAG_SImplicit 59448
#define TAG_SIs 29577
#define TAG_SIsTy 43896
#define TAG_SLam 1658
#define TAG_SLitBytes 43891
#define TAG_SLitFixed 54374
#define TAG_SLitFloat 3938
#define TAG_SLitFloat32 41499
#define TAG_SLitInt 21439
#define TAG_SLitRune 21707
#define TAG_SLitString 62718
#define TAG_SLocal 28569
#define TAG_SMatch 27203
#define TAG_SMetaApp 2372
#define TAG_SOpaque 44226
#define TAG_SPrim 55533
#define TAG_SProj 55716
#define TAG_SRec 7538
#define TAG_SSpecialize 52996
#define TAG_STag 9340
#define TAG_SmallU 20221
#define TAG_SpApp 44612
#define TAG_SpId 35501
#define TAG_SpProj 62333
#define TAG_SpSpec 18415
#define TAG_Throw 56084
#define TAG_UnequalEls 52956
#define TAG_UnequalTys 2248
#define TAG_VCode 11305
#define TAG_VCons 11629
#define TAG_VDecode 24012
#define TAG_VFixed 12623
#define TAG_VFunction 37316
#define TAG_VLam 25505
#define TAG_VNeu 27559
#define TAG_VOpaque 37311
#define TAG_VPrimArray 11892
#define TAG_VPrimFloat 57621
#define TAG_VPrimInt 4244
#define TAG_VPrimRune 12870
#define TAG_VPrimString 23215
#define TAG_VRecord 10017
#define TAG_VSum 32852
#define TAG_VU 9520
#define LBL_arity 294440695
#define LBL_bind 9519364
#define LBL_byName 571997869
#define LBL_cod 308210
#define LBL_dom 309180
#define LBL_el 9998
#define LBL_keys 9783995
#define LBL_len 316559
#define LBL_malg 9839318
#define LBL_mel 317518
#define LBL_metas 305145640
#define LBL_names 305943394
#define LBL_ren 322325
#define LBL_renEv 309756614
#define LBL_renEvTy 1323365525
#define LBL_renFlex 1323386232
#define LBL_renTy 309757082
#define LBL_selfKey 62480824
#define LBL_solStx 1050338738
#define LBL_solve 310977625
#define LBL_ty 10476
#define LBL_ubare 312426689
#define LBL_uel 325206
#define LBL_uty 325684
#define LBL_values 1123329101
static uint32_t shape_dom__cod__ren[] = {LBL_dom, LBL_cod, LBL_ren};
static uint32_t shape_keys__byName__values[] = {LBL_keys, LBL_byName, LBL_values};
static uint32_t shape_len__names[] = {LBL_len, LBL_names};
static uint32_t shape_uty__uel__ubare__solve__ren__renEv__renTy__renEvTy__renFlex[] = {LBL_uty, LBL_uel, LBL_ubare, LBL_solve, LBL_ren, LBL_renEv, LBL_renTy, LBL_renEvTy, LBL_renFlex};
V g_co_2e_3c_2b_3e_24s419270740x1449981722_get(void);
V g_co_2eop_24s310169282x2049378029(V, V, V, V);
V g_co_2eop_24s310169282x2049378029_entry(V self, V *a);
extern Clo g_co_2eop_24s310169282x2049378029_clo;
V g_heff_2eelab_2econversion_2ecanon(V);
V g_heff_2eelab_2econversion_2ecanon_entry(V self, V *a);
extern Clo g_heff_2eelab_2econversion_2ecanon_clo;
V g_heff_2eelab_2econversion_2ecanon_24tok1(V, V);
V g_heff_2eelab_2econversion_2ecanon_24tok1_entry(V self, V *a);
extern Clo g_heff_2eelab_2econversion_2ecanon_24tok1_clo;
V g_heff_2eelab_2eeval_2eevalTermF(V, V, V, V, V);
V g_heff_2eelab_2eeval_2eevalTermF_entry(V self, V *a);
extern Clo g_heff_2eelab_2eeval_2eevalTermF_clo;
HeffT2 g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr(V, V, V, V);
V g_heff_2eelab_2eeval_2eevaluator_get(void);
V g_heff_2eelab_2eparams_2eemptyShape_get(void);
V g_heff_2eelab_2eparams_2eeqLevel(V, V);
V g_heff_2eelab_2eparams_2eeqLevel_entry(V self, V *a);
extern Clo g_heff_2eelab_2eparams_2eeqLevel_clo;
V g_heff_2eelab_2eunify_2eanyL(V, V);
V g_heff_2eelab_2eunify_2eanyL_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2eanyL_clo;
V g_heff_2eelab_2eunify_2ecatMaybes(V);
V g_heff_2eelab_2eunify_2ecatMaybes_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2ecatMaybes_clo;
V g_heff_2eelab_2eunify_2edistinct(V);
V g_heff_2eelab_2eunify_2edistinct_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2edistinct_clo;
V g_heff_2eelab_2eunify_2elamsU(V, V);
V g_heff_2eelab_2eunify_2elamsU_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2elamsU_clo;
V g_heff_2eelab_2eunify_2emapWithIndexL(V, V, V);
V g_heff_2eelab_2eunify_2emapWithIndexL_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2emapWithIndexL_clo;
V g_heff_2eelab_2eunify_2emapWithIndexL_24s1126906484x889490214_24dps(V, V, V);
V g_heff_2eelab_2eunify_2emapWithIndexL_24s1126906484x889490214_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2emapWithIndexL_24s1126906484x889490214_24dps_clo;
V g_heff_2eelab_2eunify_2emetasK(V);
V g_heff_2eelab_2eunify_2emetasK_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2emetasK_clo;
V g_heff_2eelab_2eunify_2emsEv(V);
V g_heff_2eelab_2eunify_2emsEv_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2emsEv_clo;
V g_heff_2eelab_2eunify_2enewMetaFrom_24s2099433266x859676608(V, V, V, V, V);
V g_heff_2eelab_2eunify_2enewMetaFrom_24s2099433266x859676608_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2enewMetaFrom_24s2099433266x859676608_clo;
HeffT2 g_heff_2eelab_2eunify_2epatSpine_24cpr(V, V, V);
V g_heff_2eelab_2eunify_2epatVarsOf(V);
V g_heff_2eelab_2eunify_2epatVarsOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2epatVarsOf_clo;
V g_heff_2eelab_2eunify_2epatVarsOf_24dps(V, V);
V g_heff_2eelab_2eunify_2epatVarsOf_24dps_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2epatVarsOf_24dps_clo;
V g_heff_2eelab_2eunify_2epoisonMany(V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2epoisonMany_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2epoisonMany_clo;
V g_heff_2eelab_2eunify_2erenameCloTy_24s319279822x1150937735(V, V, V, V, V);
V g_heff_2eelab_2eunify_2erenameCloTy_24s319279822x1150937735_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2erenameCloTy_24s319279822x1150937735_clo;
V g_heff_2eelab_2eunify_2erenameF_24s1267840119x771576902(V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2erenameF_24s1267840119x771576902_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2erenameF_24s1267840119x771576902_clo;
V g_heff_2eelab_2eunify_2erenameFlexF_24s1334562537x508738869(V, V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2erenameFlexF_24s1334562537x508738869_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2erenameFlexF_24s1334562537x508738869_clo;
V g_heff_2eelab_2eunify_2erenameSpine_24s1736623419x1918172804(V, V, V, V, V);
V g_heff_2eelab_2eunify_2erenameSpine_24s1736623419x1918172804_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2erenameSpine_24s1736623419x1918172804_clo;
V g_heff_2eelab_2eunify_2erenameTypeF_24s1456990367x163293889(V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2erenameTypeF_24s1456990367x163293889_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2erenameTypeF_24s1456990367x163293889_clo;
V g_heff_2eelab_2eunify_2erenameTypeF_24s337291609x1265825591(V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2erenameTypeF_24s337291609x1265825591_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2erenameTypeF_24s337291609x1265825591_clo;
V g_heff_2eelab_2eunify_2esolveF_24s2118323613x521151929(V, V, V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2esolveF_24s2118323613x521151929_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2esolveF_24s2118323613x521151929_clo;
V g_heff_2eelab_2eunify_2esolveWithPruned_24s1929340871x768895529(V, V, V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2esolveWithPruned_24s1929340871x768895529_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2esolveWithPruned_24s1929340871x768895529_clo;
V g_heff_2eelab_2eunify_2esolveWithPruned_24s223240292x504960050(V, V, V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2esolveWithPruned_24s223240292x504960050_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2esolveWithPruned_24s223240292x504960050_clo;
V g_heff_2eelab_2eunify_2estoreSol_24s491818833x937743531(V, V, V, V, V);
V g_heff_2eelab_2eunify_2estoreSol_24s491818833x937743531_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2estoreSol_24s491818833x937743531_clo;
V g_heff_2eelab_2eunify_2estoreSol_24s491818833x937743531_24tok1(V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2estoreSol_24s491818833x937743531_24tok1_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2estoreSol_24s491818833x937743531_24tok1_clo;
V g_heff_2eelab_2eunify_2estripLams(V, V);
V g_heff_2eelab_2eunify_2estripLams_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2estripLams_clo;
V g_heff_2eelab_2eunify_2esubstOf(V);
V g_heff_2eelab_2eunify_2esubstOf_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2esubstOf_clo;
V g_heff_2eelab_2eunify_2etraceSolve_24s1295917126x1338807046(V, V, V, V);
V g_heff_2eelab_2eunify_2etraceSolve_24s1295917126x1338807046_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2etraceSolve_24s1295917126x1338807046_clo;
V g_heff_2eelab_2eunify_2euBareF_24s1281116162x677276803(V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2euBareF_24s1281116162x677276803_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2euBareF_24s1281116162x677276803_clo;
V g_heff_2eelab_2eunify_2euBareF_24s1751326806x1297454095(V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2euBareF_24s1751326806x1297454095_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2euBareF_24s1751326806x1297454095_clo;
V g_heff_2eelab_2eunify_2euElRigid(V, V, V, V, V, V, V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2euElRigid_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2euElRigid_clo;
V g_heff_2eelab_2eunify_2euTermF(V, V, V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2euTermF_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2euTermF_clo;
V g_heff_2eelab_2eunify_2euTyRigid_24s1811274681x437693457(V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2euTyRigid_24s1811274681x437693457_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2euTyRigid_24s1811274681x437693457_clo;
V g_heff_2eelab_2eunify_2euTypeF_24s446543853x1048233883(V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2euTypeF_24s446543853x1048233883_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2euTypeF_24s446543853x1048233883_clo;
V g_heff_2eelab_2eunify_2euTypeF_24s584682120x2121508022(V, V, V, V, V, V);
V g_heff_2eelab_2eunify_2euTypeF_24s584682120x2121508022_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2euTypeF_24s584682120x2121508022_clo;
V g_heff_2eelab_2eunify_2eufEv(V);
V g_heff_2eelab_2eunify_2eufEv_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2eufEv_clo;
V g_heff_2eelab_2eunify_2euk_24s212540630x1708219650_get(void);
V g_heff_2eelab_2eunify_2ezonkTermF(V, V, V);
V g_heff_2eelab_2eunify_2ezonkTermF_entry(V self, V *a);
extern Clo g_heff_2eelab_2eunify_2ezonkTermF_clo;
V g_heff_2eelab_2evalue_2eforceEl(V, V);
V g_heff_2eelab_2evalue_2eforceEl_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eforceEl_clo;
V g_heff_2eelab_2evalue_2eisError(V);
V g_heff_2eelab_2evalue_2eisError_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eisError_clo;
V g_heff_2eelab_2evalue_2eisFixed(V, V);
V g_heff_2eelab_2evalue_2eisFixed_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2eisFixed_clo;
V g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(V, V, V, V);
V g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190_clo;
V g_heff_2eelab_2evalue_2ereplay(V, V);
V g_heff_2eelab_2evalue_2ereplay_entry(V self, V *a);
extern Clo g_heff_2eelab_2evalue_2ereplay_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2emap_24s1947501783x1475115781(V, V, V);
V g_list_2emap_24s1947501783x1475115781_entry(V self, V *a);
extern Clo g_list_2emap_24s1947501783x1475115781_clo;
V g_prelude_2etraverse_24s1934076392x614790049(V, V);
V g_prelude_2etraverse_24s1934076392x614790049_entry(V self, V *a);
extern Clo g_prelude_2etraverse_24s1934076392x614790049_clo;
V g_std_2emap_2eempty_get(void);
V g_std_2emap_2einsert_24s170109517x1206653089(V, V, V);
V g_std_2emap_2einsert_24s170109517x1206653089_entry(V self, V *a);
extern Clo g_std_2emap_2einsert_24s170109517x1206653089_clo;
HeffT2 g_std_2emap_2elookup_24s1576363199x1121931492_24cpr(V, V);
HeffT2 g_std_2emap_2elookup_24s1702756637x1169753568_24cpr(V, V);
Clo g_heff_2eelab_2eunify_2epatVarsOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2epatVarsOf_entry, 1, 0};

V g_heff_2eelab_2eunify_2epatVarsOf(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x11_241 = heff_field(v_x1_240, 0);
    V v_rest_242 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_241)) {
    case TAG_PVar: {
      V v_l_243 = heff_field(v_x11_241, 0);
      heff_take_n(v_x11_241, 1ULL, 1);
      V v_cell_244 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_l_243, heff_hole()});
      V v_u_245 = (g_heff_2eelab_2eunify_2epatVarsOf_24dps(v_rest_242, heff_dup(v_cell_244)));
      heff_drop(v_u_245);
      return v_cell_244;
    }
    case TAG_PSelf: {
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_242;
      v_x1_240 = t_0;
      goto top;
    }
    default: return heff_nomatch(v_x11_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2eunify_2epatVarsOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2epatVarsOf(a[0]);
}
Clo g_heff_2eelab_2eunify_2epatVarsOf_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2epatVarsOf_24dps_entry, 2, 0};

V g_heff_2eelab_2eunify_2epatVarsOf_24dps(V v_x1_240, V v_d_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_241, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x11_242 = heff_field(v_x1_240, 0);
    V v_rest_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_PVar: {
      V v_l_244 = heff_field(v_x11_242, 0);
      heff_take_n(v_x11_242, 1ULL, 1);
      V v_cell_245 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_l_244, heff_hole()});
      V v_u_246 = heff_setField(v_d_241, MK_INT(1LL), heff_dup(v_cell_245));
      heff_drop(v_u_246);
      V t_0 = v_rest_243;
      V t_1 = v_cell_245;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    case TAG_PSelf: {
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      V t_0 = v_rest_243;
      V t_1 = v_d_241;
      v_x1_240 = t_0;
      v_d_241 = t_1;
      goto top;
    }
    default: return heff_nomatch(v_x11_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2eelab_2eunify_2epatVarsOf_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2epatVarsOf_24dps(a[0], a[1]);
}
V g_heff_2eelab_2eunify_2ezonkTermF_lam0(V self, V *args);
V g_heff_2eelab_2eunify_2ezonkTermF_lam1(V self, V *args);
V g_heff_2eelab_2eunify_2ezonkTermF_lam2(V self, V *args);
Clo g_heff_2eelab_2eunify_2ezonkTermF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2ezonkTermF_entry, 3, 0};

V g_heff_2eelab_2eunify_2ezonkTermF(V v_r_240, V v_mc_241, V v_t_242) {
top: ;
  V v_ty_243 = heff_take_field(v_r_240, 1);
  V v_el_244 = heff_get_n(v_r_240, 0, 2);
  switch (heff_tag_of(v_t_242)) {
  case TAG_SLocal: {
    heff_drop(v_ty_243);
    heff_drop(v_el_244);
    return v_t_242;
  }
  case TAG_SGlobal: {
    heff_drop(v_ty_243);
    heff_drop(v_el_244);
    return v_t_242;
  }
  case TAG_SCode: {
    V v_ty_247 = heff_field(v_t_242, 0);
    V v_ru_24t_242_24SCode = heff_take_reuse_n(v_t_242, 1ULL, 1);
    heff_drop(v_el_244);
    V v_t_248 = heff_tr(heff_call(v_ty_243, 1, (V[]){v_ty_247}));
    return heff_tag_at_n(v_ru_24t_242_24SCode, TAG_SCode, 1, (V[]){v_t_248});
  }
  case TAG_SApp: {
    V v_f_249 = heff_field(v_t_242, 0);
    V v_a_2410 = heff_field(v_t_242, 1);
    V v_ru_24t_242_24SApp = heff_take_reuse_n(v_t_242, 3ULL, 2);
    heff_drop(v_ty_243);
    V v_t_2411 = heff_tr(heff_call(heff_dup(v_el_244), 1, (V[]){v_f_249}));
    V v_t_2412 = heff_tr(heff_call(v_el_244, 1, (V[]){v_a_2410}));
    return heff_tag_at_n(v_ru_24t_242_24SApp, TAG_SApp, 2, (V[]){v_t_2411, v_t_2412});
  }
  case TAG_SLam: {
    V v_d_2413 = heff_field(v_t_242, 0);
    V v_b_2414 = heff_field(v_t_242, 1);
    V v_ru_24t_242_24SLam = heff_take_reuse_n(v_t_242, 3ULL, 2);
    V v_t_2415 = heff_tr(heff_call(v_ty_243, 1, (V[]){v_d_2413}));
    V v_f_2416 = v_el_244;
    V v_t_2422;
    switch (heff_tag_of(v_b_2414)) {
    case TAG_MkAbs: {
      V v_x_2417 = heff_field(v_b_2414, 0);
      V v_b_2418 = heff_field(v_b_2414, 1);
      V v_ru_24b_2414_24MkAbs = heff_take_reuse_n(v_b_2414, 3ULL, 2);
      V v_t_2419 = heff_tr(heff_call(v_f_2416, 1, (V[]){v_b_2418}));
      v_t_2422 = heff_tag_at_n(v_ru_24b_2414_24MkAbs, TAG_MkAbs, 2, (V[]){v_x_2417, v_t_2419});
      break;
    }
    case TAG_AbsConst: {
      V v_b_2420 = heff_field(v_b_2414, 0);
      V v_ru_24b_2414_24AbsConst = heff_take_reuse_n(v_b_2414, 1ULL, 1);
      V v_t_2421 = heff_tr(heff_call(v_f_2416, 1, (V[]){v_b_2420}));
      v_t_2422 = heff_tag_at_n(v_ru_24b_2414_24AbsConst, TAG_AbsConst, 1, (V[]){v_t_2421});
      break;
    }
    default: heff_nomatch(v_b_2414);
    }
    return heff_tag_at_n(v_ru_24t_242_24SLam, TAG_SLam, 2, (V[]){v_t_2415, v_t_2422});
  }
  case TAG_SCons: {
    V v_d_2423 = heff_field(v_t_242, 0);
    V v_ru_24t_242_24SCons = heff_take_reuse_n(v_t_242, 1ULL, 1);
    heff_drop(v_ty_243);
    V v_keys_2424 = heff_take_field(v_d_2423, 0);
    V v_byName_2425 = heff_take_field(v_d_2423, 1);
    V v_values_2426 = heff_get_n(v_d_2423, 2, 3);
    V v_xs_2427 = v_values_2426;
    V v_t_2430 = heff_arrayGenerate(heff_arrayLength_lent(v_xs_2427, 0), heff_clo_n(g_heff_2eelab_2eunify_2ezonkTermF_lam0, 1, 2, (V[]){v_xs_2427, v_el_244}));
    return heff_tag_at_n(v_ru_24t_242_24SCons, TAG_SCons, 1, (V[]){heff_rec_n(3, shape_keys__byName__values, (V[]){v_keys_2424, v_byName_2425, v_t_2430})});
  }
  case TAG_SProj: {
    V v_e_2431 = heff_field(v_t_242, 0);
    V v_l_2432 = heff_field(v_t_242, 1);
    V v_ru_24t_242_24SProj = heff_take_reuse_n(v_t_242, 3ULL, 2);
    heff_drop(v_ty_243);
    V v_t_2433 = heff_tr(heff_call(v_el_244, 1, (V[]){v_e_2431}));
    return heff_tag_at_n(v_ru_24t_242_24SProj, TAG_SProj, 2, (V[]){v_t_2433, v_l_2432});
  }
  case TAG_STag: {
    V v_x_2434 = heff_field(v_t_242, 0);
    V v_argv_2435 = heff_field(v_t_242, 1);
    V v_ru_24t_242_24STag = heff_take_reuse_n(v_t_242, 3ULL, 2);
    heff_drop(v_ty_243);
    V v_t_2438 = heff_arrayGenerate(heff_arrayLength_lent(v_argv_2435, 0), heff_clo_n(g_heff_2eelab_2eunify_2ezonkTermF_lam1, 1, 2, (V[]){v_argv_2435, v_el_244}));
    return heff_tag_at_n(v_ru_24t_242_24STag, TAG_STag, 2, (V[]){v_x_2434, v_t_2438});
  }
  case TAG_SMatch: {
    V v_e_2439 = heff_field(v_t_242, 0);
    V v_cs_2440 = heff_field(v_t_242, 1);
    V v_ru_24t_242_24SMatch = heff_take_reuse_n(v_t_242, 3ULL, 2);
    heff_drop(v_ty_243);
    V v_keys_2441 = heff_take_field(v_cs_2440, 0);
    V v_byName_2442 = heff_take_field(v_cs_2440, 1);
    V v_values_2443 = heff_get_n(v_cs_2440, 2, 3);
    V v_t_2444 = heff_tr(heff_call(heff_dup(v_el_244), 1, (V[]){v_e_2439}));
    V v_xs_2445 = v_values_2443;
    V v_t_2451 = heff_arrayGenerate(heff_arrayLength_lent(v_xs_2445, 0), heff_clo_n(g_heff_2eelab_2eunify_2ezonkTermF_lam2, 1, 2, (V[]){v_xs_2445, v_el_244}));
    return heff_tag_at_n(v_ru_24t_242_24SMatch, TAG_SMatch, 2, (V[]){v_t_2444, heff_rec_n(3, shape_keys__byName__values, (V[]){v_keys_2441, v_byName_2442, v_t_2451})});
  }
  case TAG_SSpecialize: {
    V v_e_2452 = heff_field(v_t_242, 0);
    V v_l_2453 = heff_field(v_t_242, 1);
    V v_v_2454 = heff_field(v_t_242, 2);
    V v_ru_24t_242_24SSpecialize = heff_take_reuse_n(v_t_242, 7ULL, 3);
    heff_drop(v_ty_243);
    V v_t_2455 = heff_tr(heff_call(heff_dup(v_el_244), 1, (V[]){v_e_2452}));
    V v_t_2456 = heff_tr(heff_call(v_el_244, 1, (V[]){v_v_2454}));
    return heff_tag_at_n(v_ru_24t_242_24SSpecialize, TAG_SSpecialize, 3, (V[]){v_t_2455, v_l_2453, v_t_2456});
  }
  case TAG_SIs: {
    V v_e_2457 = heff_field(v_t_242, 0);
    V v_ru_24t_242_24SIs = heff_take_reuse_n(v_t_242, 1ULL, 1);
    heff_drop(v_ty_243);
    V v_t_2458 = heff_tr(heff_call(v_el_244, 1, (V[]){v_e_2457}));
    return heff_tag_at_n(v_ru_24t_242_24SIs, TAG_SIs, 1, (V[]){v_t_2458});
  }
  case TAG_SOpaque: {
    heff_drop(v_ty_243);
    heff_drop(v_el_244);
    return v_t_242;
  }
  case TAG_SAbandon: {
    heff_drop(v_ty_243);
    heff_drop(v_el_244);
    return v_t_242;
  }
  case TAG_SRec: {
    V v_e_2459 = heff_field(v_t_242, 0);
    V v_ru_24t_242_24SRec = heff_take_reuse_n(v_t_242, 1ULL, 1);
    heff_drop(v_ty_243);
    V v_t_2460 = heff_tr(heff_call(v_el_244, 1, (V[]){v_e_2459}));
    return heff_tag_at_n(v_ru_24t_242_24SRec, TAG_SRec, 1, (V[]){v_t_2460});
  }
  case TAG_SFix: {
    V v_d_2461 = heff_field(v_t_242, 0);
    V v_b_2462 = heff_field(v_t_242, 1);
    V v_ru_24t_242_24SFix = heff_take_reuse_n(v_t_242, 3ULL, 2);
    V v_t_2463 = heff_tr(heff_call(v_ty_243, 1, (V[]){v_d_2461}));
    V v_f_2464 = v_el_244;
    V v_t_2470;
    switch (heff_tag_of(v_b_2462)) {
    case TAG_MkAbs: {
      V v_x_2465 = heff_field(v_b_2462, 0);
      V v_b_2466 = heff_field(v_b_2462, 1);
      V v_ru_24b_2462_24MkAbs = heff_take_reuse_n(v_b_2462, 3ULL, 2);
      V v_t_2467 = heff_tr(heff_call(v_f_2464, 1, (V[]){v_b_2466}));
      v_t_2470 = heff_tag_at_n(v_ru_24b_2462_24MkAbs, TAG_MkAbs, 2, (V[]){v_x_2465, v_t_2467});
      break;
    }
    case TAG_AbsConst: {
      V v_b_2468 = heff_field(v_b_2462, 0);
      V v_ru_24b_2462_24AbsConst = heff_take_reuse_n(v_b_2462, 1ULL, 1);
      V v_t_2469 = heff_tr(heff_call(v_f_2464, 1, (V[]){v_b_2468}));
      v_t_2470 = heff_tag_at_n(v_ru_24b_2462_24AbsConst, TAG_AbsConst, 1, (V[]){v_t_2469});
      break;
    }
    default: heff_nomatch(v_b_2462);
    }
    return heff_tag_at_n(v_ru_24t_242_24SFix, TAG_SFix, 2, (V[]){v_t_2463, v_t_2470});
  }
  case TAG_SImplicit: {
    V v_x_2471 = heff_field(v_t_242, 0);
    V v_e_2472 = heff_field(v_t_242, 1);
    V v_ru_24t_242_24SImplicit = heff_take_reuse_n(v_t_242, 3ULL, 2);
    heff_drop(v_ty_243);
    V v_t_2473 = heff_tr(heff_call(v_el_244, 1, (V[]){v_e_2472}));
    return heff_tag_at_n(v_ru_24t_242_24SImplicit, TAG_SImplicit, 2, (V[]){v_x_2471, v_t_2473});
  }
  case TAG_SPrim: {
    heff_drop(v_ty_243);
    heff_drop(v_el_244);
    return v_t_242;
  }
  case TAG_SMetaApp: {
    V v_m_2475 = heff_field(v_t_242, 0);
    V v_idxs_2476 = heff_field(v_t_242, 1);
    V v_ty_2477 = heff_field(v_t_242, 2);
    V v_ru_24t_242_24SMetaApp = heff_take_reuse_n(v_t_242, 7ULL, 3);
    HeffT2 v_t_2478 = (g_std_2emap_2elookup_24s1702756637x1169753568_24cpr(v_mc_241, heff_dup(v_m_2475)));
    {
      V v_field_2480 = v_t_2478.f[1];
      int64_t v_tag_2479 = ((int64_t)v_t_2478.f[0]);
      if ((v_tag_2479 == ((int64_t)0ULL))) {
        V v_e_2481 = v_field_2480;
        V v_t_2482 = heff_get_n(v_e_2481, 2, 6);
        switch (heff_tag_of(v_t_2482)) {
        case TAG_Nothing: {
          heff_drop(v_el_244);
          V v_t_2483 = heff_tr(heff_call(v_ty_243, 1, (V[]){v_ty_2477}));
          return heff_tag_at_n(v_ru_24t_242_24SMetaApp, TAG_SMetaApp, 3, (V[]){v_m_2475, v_idxs_2476, v_t_2483});
        }
        case TAG_Just: {
          V v_sol_2484 = heff_field(v_t_2482, 0);
          heff_take_n(v_t_2482, 1ULL, 1);
          heff_drop(v_ty_243);
          heff_drop(v_m_2475);
          heff_drop(v_ty_2477);
          heff_drop_cell(v_ru_24t_242_24SMetaApp, 3);
          V v_idxs_2485 = heff_arrayToList(v_idxs_2476);
          V v_t_2486 = (g_heff_2eelab_2eunify_2esubstOf(heff_dup(v_idxs_2485)));
          V v_t_2487 = ({ V a_0 = MK_INT(1LL); V a_1 = MK_INT(0LL); V a_2 = v_idxs_2485; V r_ = (g_list_2efoldl_24s65689923x209800052(a_0, a_1, a_2)); heff_drop(v_idxs_2485); r_; });
          V v_t_2488 = (g_heff_2eelab_2eunify_2estripLams(v_t_2487, v_sol_2484));
          V v_t_2489 = heff_tr(heff_call(heff_get_n(v_t_2486, 0, 2), 2, (V[]){MK_INT(0LL), v_t_2488}));
          return heff_tail(v_el_244, 1, (V[]){v_t_2489});
        }
        default: return heff_nomatch(v_t_2482);
        }
      } else {
        heff_drop(v_el_244);
        heff_drop(v_field_2480);
        V v_t_2490 = heff_tr(heff_call(v_ty_243, 1, (V[]){v_ty_2477}));
        return heff_tag_at_n(v_ru_24t_242_24SMetaApp, TAG_SMetaApp, 3, (V[]){v_m_2475, v_idxs_2476, v_t_2490});
      }
    }
  }
  case TAG_SLitInt: {
    heff_drop(v_ty_243);
    heff_drop(v_el_244);
    return v_t_242;
  }
  case TAG_SLitFloat: {
    heff_drop(v_ty_243);
    heff_drop(v_el_244);
    return v_t_242;
  }
  case TAG_SLitString: {
    heff_drop(v_ty_243);
    heff_drop(v_el_244);
    return v_t_242;
  }
  case TAG_SLitBytes: {
    heff_drop(v_ty_243);
    heff_drop(v_el_244);
    return v_t_242;
  }
  case TAG_SLitRune: {
    heff_drop(v_ty_243);
    heff_drop(v_el_244);
    return v_t_242;
  }
  case TAG_SLitFixed: {
    heff_drop(v_ty_243);
    heff_drop(v_el_244);
    return v_t_242;
  }
  case TAG_SLitFloat32: {
    heff_drop(v_ty_243);
    heff_drop(v_el_244);
    return v_t_242;
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2eelab_2eunify_2ezonkTermF_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2eelab_2eunify_2ezonkTermF(a[0], a1, a[2]); heff_drop(a1); return r;
}
V g_heff_2eelab_2eunify_2ezonkTermF_lam0(V self, V *args) {
  V v_i_2428 = args[0];
  V v_xs_2427 = heff_env(self)[0];
  V v_el_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2429 = heff_arrayIndex(v_xs_2427, v_i_2428);
  V f_ = v_el_244;
  args[0] = v_t_2429;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2ezonkTermF_lam1(V self, V *args) {
  V v_i_2436 = args[0];
  V v_argv_2435 = heff_env(self)[0];
  V v_el_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2437 = heff_arrayIndex(v_argv_2435, v_i_2436);
  V f_ = v_el_244;
  args[0] = v_t_2437;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2ezonkTermF_lam2(V self, V *args) {
  V v_i_2446 = args[0];
  V v_xs_2445 = heff_env(self)[0];
  V v_el_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_p_2447 = heff_arrayIndex(v_xs_2445, v_i_2446);
  switch (heff_tag_of(v_p_2447)) {
  case TAG_MkPair: {
    V v_xs_2448 = heff_field(v_p_2447, 0);
    V v_b_2449 = heff_field(v_p_2447, 1);
    V v_ru_24p_2447_24MkPair = heff_take_reuse_n(v_p_2447, 3ULL, 2);
    V v_t_2450 = heff_tr(heff_call(v_el_244, 1, (V[]){v_b_2449}));
    return heff_tag_at_n(v_ru_24p_2447_24MkPair, TAG_MkPair, 2, (V[]){v_xs_2448, v_t_2450});
  }
  default: return heff_nomatch(v_p_2447);
  }
}
Clo g_heff_2eelab_2eunify_2emapWithIndexL_24s1126906484x889490214_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2emapWithIndexL_24s1126906484x889490214_24dps_entry, 3, 0};

V g_heff_2eelab_2eunify_2emapWithIndexL_24s1126906484x889490214_24dps(V v_i_240, V v_x3_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x3_241)) {
  case TAG_Nil: {
    heff_drop(v_i_240);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x3_241, 0);
    V v_xs_244 = heff_field(v_x3_241, 1);
    V v_ru_24x3_241_24Cons = heff_take_reuse_n(v_x3_241, 3ULL, 2);
    V v_t_2410;
    switch (heff_tag_of(v_x_243)) {
    case TAG_MkPair: {
      V v_a_245 = heff_field(v_x_243, 0);
      V v_a_246 = heff_field(v_x_243, 1);
      heff_take_n(v_x_243, 3ULL, 2);
      switch (heff_tag_of(v_a_245)) {
      case TAG_PVar: {
        V v_a_247 = heff_field(v_a_245, 0);
        V v_ru_24a_245_24PVar = heff_take_reuse_n(v_a_245, 1ULL, 1);
        switch (heff_tag_of(v_a_246)) {
        case TAG_PVar: {
          V v_a_248 = heff_field(v_a_246, 0);
          heff_take_n(v_a_246, 1ULL, 1);
          if (heff_intEq_c(v_a_247, v_a_248)) {
            v_t_2410 = heff_tag_at_n(v_ru_24a_245_24PVar, TAG_Just, 1, (V[]){heff_dup(v_i_240)});
          } else {
            heff_drop_cell(v_ru_24a_245_24PVar, 1);
            v_t_2410 = NTAG(TAG_Nothing);
          }
          break;
        }
        case TAG_PSelf: {
          heff_drop(v_a_247);
          heff_drop_cell(v_ru_24a_245_24PVar, 1);
          v_t_2410 = NTAG(TAG_Nothing);
          break;
        }
        default: heff_nomatch(v_a_246);
        }
        break;
      }
      case TAG_PSelf: {
        switch (heff_tag_of(v_a_246)) {
        case TAG_PVar: {
          heff_take_n(v_a_246, 0ULL, 1);
          v_t_2410 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_PSelf: {
          v_t_2410 = heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_i_240)});
          break;
        }
        default: heff_nomatch(v_a_246);
        }
        break;
      }
      default: heff_nomatch(v_a_245);
      }
      break;
    }
    default: heff_nomatch(v_x_243);
    }
    V v_cell_2411 = heff_tag_at_n(v_ru_24x3_241_24Cons, TAG_Cons, 2, (V[]){v_t_2410, heff_hole()});
    V v_u_2412 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_2411));
    heff_drop(v_u_2412);
    V t_0 = heff_intAdd(v_i_240, MK_INT(1LL));
    V t_1 = v_xs_244;
    V t_2 = v_cell_2411;
    v_i_240 = t_0;
    v_x3_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x3_241);
  }
}
V g_heff_2eelab_2eunify_2emapWithIndexL_24s1126906484x889490214_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2emapWithIndexL_24s1126906484x889490214_24dps(a[0], a[1], a[2]);
}
V g_heff_2eelab_2eunify_2euTermF_lam0(V self, V *args);
V g_heff_2eelab_2eunify_2euTermF_lam3(V self, V *args);
V g_heff_2eelab_2eunify_2euTermF_lam5(V self, V *args); static Clo g_heff_2eelab_2eunify_2euTermF_lam5_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2euTermF_lam5, 1, 0};
V g_heff_2eelab_2eunify_2euTermF_lam8(V self, V *args); static Clo g_heff_2eelab_2eunify_2euTermF_lam8_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2euTermF_lam8, 1, 0};
V g_heff_2eelab_2eunify_2euTermF_lam9(V self, V *args);
V g_heff_2eelab_2eunify_2euTermF_lam7(V self, V *args);
V g_heff_2eelab_2eunify_2euTermF_lam6(V self, V *args);
V g_heff_2eelab_2eunify_2euTermF_lam4(V self, V *args);
V g_heff_2eelab_2eunify_2euTermF_lam2(V self, V *args);
V g_heff_2eelab_2eunify_2euTermF_lam1(V self, V *args);
Clo g_heff_2eelab_2eunify_2euTermF_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2euTermF_entry, 8, 0};

V g_heff_2eelab_2eunify_2euTermF(V v_w_240, V v_ms_241, V v_uf_242, V v_r_243, V v_g_244, V v_cs_245, V v_a0_246, V v_b0_247) {
top: ;
  V v_t_249 = heff_tr(heff_call(heff_dup(v_ms_241), 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2eunify_2euTermF_lam0, 1, 1, (V[]){v_a0_246})})}));
  return heff_clo_n(g_heff_2eelab_2eunify_2euTermF_lam1, 2, 8, (V[]){v_w_240, v_t_249, v_ms_241, v_b0_247, v_cs_245, v_uf_242, v_r_243, v_g_244});
}
V g_heff_2eelab_2eunify_2euTermF_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2euTermF(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
}
V g_heff_2eelab_2eunify_2euTermF_lam0(V self, V *args) {
  V v_c_248 = args[0];
  V v_a0_246 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_c_248, 3, 8); V a_1 = v_a0_246; V r_ = (g_heff_2eelab_2evalue_2eforceEl(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2eelab_2eunify_2euTermF_lam3(V self, V *args) {
  V v_c_2413 = args[0];
  V v_b0_247 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return ({ V b_0 = heff_get_n(v_c_2413, 3, 8); V a_1 = v_b0_247; V r_ = (g_heff_2eelab_2evalue_2eforceEl(b_0, a_1)); heff_drop(b_0); r_; });
}
V g_heff_2eelab_2eunify_2euTermF_lam5(V self, V *args) {
  V v_c_2418 = args[0];
  return heff_get_n(v_c_2418, 3, 8);
}
V g_heff_2eelab_2eunify_2euTermF_lam8(V self, V *args) {
  V v_c_2424 = args[0];
  return heff_get_n(v_c_2424, 3, 8);
}
V g_heff_2eelab_2eunify_2euTermF_lam9(V self, V *args) {
  V v_x_2426 = args[0];
  V v_cs_245 = heff_env(self)[0];
  V v_x_2415 = heff_env(self)[1];
  V v_w_240 = heff_env(self)[2];
  V v_ms_241 = heff_env(self)[3];
  V v_uf_242 = heff_env(self)[4];
  V v_hd_2410 = heff_env(self)[5];
  V v_k_2411 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2427 = ({ V a_0 = v_x_2426; V r_ = (g_heff_2eelab_2eunify_2emetasK(a_0)); heff_drop(v_x_2426); r_; });
  V v_t_2428 = heff_tr(heff_call(heff_get_n(v_t_2427, 0, 3), 3, (V[]){MK_INT(20LL), heff_get_n(v_cs_245, 0, 2), v_x_2415}));
  return ({ V a_0 = v_w_240; V a_1 = v_ms_241; V a_2 = v_uf_242; V a_3 = v_t_2428; V a_4 = v_hd_2410; V a_5 = v_k_2411; V r_ = (g_heff_2eelab_2eunify_2epoisonMany(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_uf_242); heff_drop(v_t_2428); r_; });
}
V g_heff_2eelab_2eunify_2euTermF_lam7(V self, V *args) {
  V v_x_2423 = args[0];
  V v_ms_241 = heff_env(self)[0];
  V v_w_240 = heff_env(self)[1];
  V v_hd_2410 = heff_env(self)[2];
  V v_cs_245 = heff_env(self)[3];
  V v_x_2415 = heff_env(self)[4];
  V v_uf_242 = heff_env(self)[5];
  V v_k_2411 = heff_env(self)[6];
  heff_clo_take(self, 7);
  heff_drop(v_x_2423);
  V v_t_2425 = heff_tr(heff_call(heff_dup(v_ms_241), 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2eunify_2euTermF_lam8_clo)})}));
  return (g_co_2eop_24s310169282x2049378029(heff_dup(v_w_240), v_t_2425, heff_dup(v_hd_2410), heff_clo_n(g_heff_2eelab_2eunify_2euTermF_lam9, 1, 7, (V[]){v_cs_245, v_x_2415, v_w_240, v_ms_241, v_uf_242, v_hd_2410, v_k_2411})));
}
V g_heff_2eelab_2eunify_2euTermF_lam6(V self, V *args) {
  V v_x_2420 = args[0];
  V v_cs_245 = heff_env(self)[0];
  V v_x_2412 = heff_env(self)[1];
  V v_w_240 = heff_env(self)[2];
  V v_ms_241 = heff_env(self)[3];
  V v_uf_242 = heff_env(self)[4];
  V v_hd_2410 = heff_env(self)[5];
  V v_x_2415 = heff_env(self)[6];
  V v_k_2411 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2421 = ({ V a_0 = v_x_2420; V r_ = (g_heff_2eelab_2eunify_2emetasK(a_0)); heff_drop(v_x_2420); r_; });
  V v_t_2422 = heff_tr(heff_call(heff_get_n(v_t_2421, 0, 3), 3, (V[]){MK_INT(20LL), heff_dup(heff_rfield(v_cs_245, 0)), v_x_2412}));
  return ({ V a_0 = heff_dup(v_w_240); V a_1 = heff_dup(v_ms_241); V a_2 = v_uf_242; V a_3 = v_t_2422; V a_4 = heff_dup(v_hd_2410); V a_5 = heff_clo_n(g_heff_2eelab_2eunify_2euTermF_lam7, 1, 7, (V[]){v_ms_241, v_w_240, v_hd_2410, v_cs_245, v_x_2415, heff_dup(v_uf_242), v_k_2411}); V r_ = (g_heff_2eelab_2eunify_2epoisonMany(a_0, a_1, a_2, a_3, a_4, a_5)); heff_drop(v_uf_242); heff_drop(v_t_2422); r_; });
}
V g_heff_2eelab_2eunify_2euTermF_lam4(V self, V *args) {
  V v_x_2415 = args[0];
  V v_x_2412 = heff_env(self)[0];
  V v_ms_241 = heff_env(self)[1];
  V v_w_240 = heff_env(self)[2];
  V v_hd_2410 = heff_env(self)[3];
  V v_cs_245 = heff_env(self)[4];
  V v_uf_242 = heff_env(self)[5];
  V v_k_2411 = heff_env(self)[6];
  V v_r_243 = heff_env(self)[7];
  V v_g_244 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_t_2416 = (g_heff_2eelab_2evalue_2eisError(v_x_2412));
  V v_t_2417;
  if ((heff_dup(v_t_2416) == NTAG(TAG_True))) {
    heff_drop(v_t_2416);
    v_t_2417 = NTAG(TAG_True);
  } else {
    heff_drop(v_t_2416);
    v_t_2417 = (g_heff_2eelab_2evalue_2eisError(v_x_2415));
  }
  if ((heff_dup(v_t_2417) == NTAG(TAG_True))) {
    heff_drop_rec(v_r_243, 9);
    heff_drop(v_g_244);
    heff_drop(v_t_2417);
    V v_t_2419 = heff_tr(heff_call(heff_dup(v_ms_241), 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2eunify_2euTermF_lam5_clo)})}));
    return (g_co_2eop_24s310169282x2049378029(heff_dup(v_w_240), v_t_2419, heff_dup(v_hd_2410), heff_clo_n(g_heff_2eelab_2eunify_2euTermF_lam6, 1, 8, (V[]){v_cs_245, v_x_2412, v_w_240, v_ms_241, v_uf_242, v_hd_2410, v_x_2415, v_k_2411})));
  } else {
    heff_drop(v_t_2417);
    switch (heff_tag_of(v_x_2412)) {
    case TAG_VNeu: {
      switch (heff_tag_of(v_x_2415)) {
      case TAG_VNeu: {
        V v_t_2451;
        switch (heff_tag_of(v_x_2412)) {
        case TAG_VNeu: {
          V v_v1_2439 = heff_dup(heff_field(v_x_2412, 0));
          V v_sp_2440 = heff_dup(heff_field(v_x_2412, 1));
          switch (heff_tag_of(v_v1_2439)) {
          case TAG_HLocal: {
            heff_take_n(v_v1_2439, 0ULL, 1);
            heff_drop(v_sp_2440);
            v_t_2451 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HGlobal: {
            heff_take_n(v_v1_2439, 0ULL, 1);
            heff_drop(v_sp_2440);
            v_t_2451 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HMeta: {
            V v_m_2446 = heff_field(v_v1_2439, 0);
            V v_ru_24v1_2439_24HMeta = heff_take_reuse_n(v_v1_2439, 1ULL, 1);
            v_t_2451 = heff_tag_at_n(v_ru_24v1_2439_24HMeta, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_m_2446, v_sp_2440})});
            break;
          }
          case TAG_HError: {
            heff_drop(v_sp_2440);
            v_t_2451 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_v1_2439);
          }
          break;
        }
        case TAG_VCode: {
          v_t_2451 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VLam: {
          v_t_2451 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VCons: {
          v_t_2451 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VOpaque: {
          v_t_2451 = NTAG(TAG_Nothing);
          break;
        }
        default: heff_nomatch(v_x_2412);
        }
        switch (heff_tag_of(v_t_2451)) {
        case TAG_Nothing: {
          V v_t_2464;
          switch (heff_tag_of(v_x_2415)) {
          case TAG_VNeu: {
            V v_v1_2452 = heff_dup(heff_field(v_x_2415, 0));
            V v_sp_2453 = heff_dup(heff_field(v_x_2415, 1));
            switch (heff_tag_of(v_v1_2452)) {
            case TAG_HLocal: {
              heff_take_n(v_v1_2452, 0ULL, 1);
              heff_drop(v_sp_2453);
              v_t_2464 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HGlobal: {
              heff_take_n(v_v1_2452, 0ULL, 1);
              heff_drop(v_sp_2453);
              v_t_2464 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HMeta: {
              V v_m_2459 = heff_field(v_v1_2452, 0);
              V v_ru_24v1_2452_24HMeta = heff_take_reuse_n(v_v1_2452, 1ULL, 1);
              v_t_2464 = heff_tag_at_n(v_ru_24v1_2452_24HMeta, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_m_2459, v_sp_2453})});
              break;
            }
            case TAG_HError: {
              heff_drop(v_sp_2453);
              v_t_2464 = NTAG(TAG_Nothing);
              break;
            }
            default: heff_nomatch(v_v1_2452);
            }
            break;
          }
          case TAG_VCode: {
            v_t_2464 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VLam: {
            v_t_2464 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VCons: {
            v_t_2464 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VOpaque: {
            v_t_2464 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_x_2415);
          }
          switch (heff_tag_of(v_t_2464)) {
          case TAG_Nothing: {
            V v_t_2477;
            switch (heff_tag_of(v_x_2412)) {
            case TAG_VNeu: {
              V v_v1_2465 = heff_dup(heff_field(v_x_2412, 0));
              switch (heff_tag_of(v_v1_2465)) {
              case TAG_HLocal: {
                V v_ru_24v1_2465_24HLocal = heff_take_reuse_n(v_v1_2465, 0ULL, 1);
                v_t_2477 = (g_heff_2eelab_2econversion_2ecanon_24tok1(v_ru_24v1_2465_24HLocal, heff_dup(v_x_2412)));
                break;
              }
              case TAG_HGlobal: {
                V v_ru_24v1_2465_24HGlobal = heff_take_reuse_n(v_v1_2465, 0ULL, 1);
                v_t_2477 = (g_heff_2eelab_2econversion_2ecanon_24tok1(v_ru_24v1_2465_24HGlobal, heff_dup(v_x_2412)));
                break;
              }
              case TAG_HMeta: {
                heff_take_n(v_v1_2465, 0ULL, 1);
                v_t_2477 = heff_dup(v_x_2412);
                break;
              }
              case TAG_HError: {
                v_t_2477 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
                break;
              }
              default: heff_nomatch(v_v1_2465);
              }
              break;
            }
            case TAG_VCode: {
              v_t_2477 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
              break;
            }
            case TAG_VLam: {
              v_t_2477 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
              break;
            }
            case TAG_VCons: {
              v_t_2477 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
              break;
            }
            case TAG_VOpaque: {
              v_t_2477 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
              break;
            }
            default: heff_nomatch(v_x_2412);
            }
            V v_t_2490;
            switch (heff_tag_of(v_x_2415)) {
            case TAG_VNeu: {
              V v_v1_2478 = heff_dup(heff_field(v_x_2415, 0));
              switch (heff_tag_of(v_v1_2478)) {
              case TAG_HLocal: {
                V v_ru_24v1_2478_24HLocal = heff_take_reuse_n(v_v1_2478, 0ULL, 1);
                v_t_2490 = (g_heff_2eelab_2econversion_2ecanon_24tok1(v_ru_24v1_2478_24HLocal, heff_dup(v_x_2415)));
                break;
              }
              case TAG_HGlobal: {
                V v_ru_24v1_2478_24HGlobal = heff_take_reuse_n(v_v1_2478, 0ULL, 1);
                v_t_2490 = (g_heff_2eelab_2econversion_2ecanon_24tok1(v_ru_24v1_2478_24HGlobal, heff_dup(v_x_2415)));
                break;
              }
              case TAG_HMeta: {
                heff_take_n(v_v1_2478, 0ULL, 1);
                v_t_2490 = heff_dup(v_x_2415);
                break;
              }
              case TAG_HError: {
                v_t_2490 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
                break;
              }
              default: heff_nomatch(v_v1_2478);
              }
              break;
            }
            case TAG_VCode: {
              v_t_2490 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
              break;
            }
            case TAG_VLam: {
              v_t_2490 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
              break;
            }
            case TAG_VCons: {
              v_t_2490 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
              break;
            }
            case TAG_VOpaque: {
              v_t_2490 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
              break;
            }
            default: heff_nomatch(v_x_2415);
            }
            return ({ V a_0 = v_w_240; V a_1 = v_ms_241; V a_2 = v_uf_242; V a_3 = v_r_243; V a_4 = v_g_244; V a_5 = v_cs_245; V a_6 = v_t_2477; V a_7 = v_t_2490; V a_8 = v_x_2412; V a_9 = v_x_2415; V a_10 = v_hd_2410; V a_11 = v_k_2411; V r_ = (g_heff_2eelab_2eunify_2euElRigid(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9, a_10, a_11)); heff_drop(v_ms_241); r_; });
          }
          case TAG_Just: {
            V v_it1_2491 = heff_field(v_t_2464, 0);
            heff_take_n(v_t_2464, 1ULL, 1);
            heff_drop(v_ms_241);
            heff_drop(v_w_240);
            heff_drop(v_uf_242);
            switch (heff_tag_of(v_it1_2491)) {
            case TAG_MkPair: {
              V v_m_2492 = heff_field(v_it1_2491, 0);
              V v_sp_2493 = heff_field(v_it1_2491, 1);
              heff_take_n(v_it1_2491, 3ULL, 2);
              return heff_tail(heff_get_n(v_r_243, 3, 9), 8, (V[]){v_g_244, v_cs_245, v_m_2492, v_sp_2493, v_x_2412, v_x_2415, v_hd_2410, v_k_2411});
            }
            default: return heff_nomatch(v_it1_2491);
            }
          }
          default: return heff_nomatch(v_t_2464);
          }
        }
        case TAG_Just: {
          V v_it1_2494 = heff_field(v_t_2451, 0);
          heff_take_n(v_t_2451, 1ULL, 1);
          heff_drop(v_ms_241);
          heff_drop(v_w_240);
          heff_drop(v_uf_242);
          switch (heff_tag_of(v_it1_2494)) {
          case TAG_MkPair: {
            V v_m_2495 = heff_field(v_it1_2494, 0);
            V v_sp_2496 = heff_field(v_it1_2494, 1);
            heff_take_n(v_it1_2494, 3ULL, 2);
            return heff_tail(heff_get_n(v_r_243, 3, 9), 8, (V[]){v_g_244, v_cs_245, v_m_2495, v_sp_2496, v_x_2415, v_x_2412, v_hd_2410, v_k_2411});
          }
          default: return heff_nomatch(v_it1_2494);
          }
        }
        default: return heff_nomatch(v_t_2451);
        }
      }
      case TAG_VCode: {
        V v_t_24110;
        switch (heff_tag_of(v_x_2412)) {
        case TAG_VNeu: {
          V v_v1_2498 = heff_dup(heff_field(v_x_2412, 0));
          V v_sp_2499 = heff_dup(heff_field(v_x_2412, 1));
          switch (heff_tag_of(v_v1_2498)) {
          case TAG_HLocal: {
            heff_take_n(v_v1_2498, 0ULL, 1);
            heff_drop(v_sp_2499);
            v_t_24110 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HGlobal: {
            heff_take_n(v_v1_2498, 0ULL, 1);
            heff_drop(v_sp_2499);
            v_t_24110 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HMeta: {
            V v_m_24105 = heff_field(v_v1_2498, 0);
            V v_ru_24v1_2498_24HMeta = heff_take_reuse_n(v_v1_2498, 1ULL, 1);
            v_t_24110 = heff_tag_at_n(v_ru_24v1_2498_24HMeta, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_m_24105, v_sp_2499})});
            break;
          }
          case TAG_HError: {
            heff_drop(v_sp_2499);
            v_t_24110 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_v1_2498);
          }
          break;
        }
        case TAG_VCode: {
          v_t_24110 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VLam: {
          v_t_24110 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VCons: {
          v_t_24110 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VOpaque: {
          v_t_24110 = NTAG(TAG_Nothing);
          break;
        }
        default: heff_nomatch(v_x_2412);
        }
        switch (heff_tag_of(v_t_24110)) {
        case TAG_Nothing: {
          V v_t_24123;
          switch (heff_tag_of(v_x_2415)) {
          case TAG_VNeu: {
            V v_v1_24111 = heff_dup(heff_field(v_x_2415, 0));
            V v_sp_24112 = heff_dup(heff_field(v_x_2415, 1));
            switch (heff_tag_of(v_v1_24111)) {
            case TAG_HLocal: {
              heff_take_n(v_v1_24111, 0ULL, 1);
              heff_drop(v_sp_24112);
              v_t_24123 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HGlobal: {
              heff_take_n(v_v1_24111, 0ULL, 1);
              heff_drop(v_sp_24112);
              v_t_24123 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HMeta: {
              V v_m_24118 = heff_field(v_v1_24111, 0);
              V v_ru_24v1_24111_24HMeta = heff_take_reuse_n(v_v1_24111, 1ULL, 1);
              v_t_24123 = heff_tag_at_n(v_ru_24v1_24111_24HMeta, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_m_24118, v_sp_24112})});
              break;
            }
            case TAG_HError: {
              heff_drop(v_sp_24112);
              v_t_24123 = NTAG(TAG_Nothing);
              break;
            }
            default: heff_nomatch(v_v1_24111);
            }
            break;
          }
          case TAG_VCode: {
            v_t_24123 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VLam: {
            v_t_24123 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VCons: {
            v_t_24123 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VOpaque: {
            v_t_24123 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_x_2415);
          }
          switch (heff_tag_of(v_t_24123)) {
          case TAG_Nothing: {
            V v_t_24136;
            switch (heff_tag_of(v_x_2412)) {
            case TAG_VNeu: {
              V v_v1_24124 = heff_dup(heff_field(v_x_2412, 0));
              switch (heff_tag_of(v_v1_24124)) {
              case TAG_HLocal: {
                V v_ru_24v1_24124_24HLocal = heff_take_reuse_n(v_v1_24124, 0ULL, 1);
                v_t_24136 = (g_heff_2eelab_2econversion_2ecanon_24tok1(v_ru_24v1_24124_24HLocal, heff_dup(v_x_2412)));
                break;
              }
              case TAG_HGlobal: {
                V v_ru_24v1_24124_24HGlobal = heff_take_reuse_n(v_v1_24124, 0ULL, 1);
                v_t_24136 = (g_heff_2eelab_2econversion_2ecanon_24tok1(v_ru_24v1_24124_24HGlobal, heff_dup(v_x_2412)));
                break;
              }
              case TAG_HMeta: {
                heff_take_n(v_v1_24124, 0ULL, 1);
                v_t_24136 = heff_dup(v_x_2412);
                break;
              }
              case TAG_HError: {
                v_t_24136 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
                break;
              }
              default: heff_nomatch(v_v1_24124);
              }
              break;
            }
            case TAG_VCode: {
              v_t_24136 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
              break;
            }
            case TAG_VLam: {
              v_t_24136 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
              break;
            }
            case TAG_VCons: {
              v_t_24136 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
              break;
            }
            case TAG_VOpaque: {
              v_t_24136 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
              break;
            }
            default: heff_nomatch(v_x_2412);
            }
            V v_t_24149;
            switch (heff_tag_of(v_x_2415)) {
            case TAG_VNeu: {
              V v_v1_24137 = heff_dup(heff_field(v_x_2415, 0));
              switch (heff_tag_of(v_v1_24137)) {
              case TAG_HLocal: {
                V v_ru_24v1_24137_24HLocal = heff_take_reuse_n(v_v1_24137, 0ULL, 1);
                v_t_24149 = (g_heff_2eelab_2econversion_2ecanon_24tok1(v_ru_24v1_24137_24HLocal, heff_dup(v_x_2415)));
                break;
              }
              case TAG_HGlobal: {
                V v_ru_24v1_24137_24HGlobal = heff_take_reuse_n(v_v1_24137, 0ULL, 1);
                v_t_24149 = (g_heff_2eelab_2econversion_2ecanon_24tok1(v_ru_24v1_24137_24HGlobal, heff_dup(v_x_2415)));
                break;
              }
              case TAG_HMeta: {
                heff_take_n(v_v1_24137, 0ULL, 1);
                v_t_24149 = heff_dup(v_x_2415);
                break;
              }
              case TAG_HError: {
                v_t_24149 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
                break;
              }
              default: heff_nomatch(v_v1_24137);
              }
              break;
            }
            case TAG_VCode: {
              v_t_24149 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
              break;
            }
            case TAG_VLam: {
              v_t_24149 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
              break;
            }
            case TAG_VCons: {
              v_t_24149 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
              break;
            }
            case TAG_VOpaque: {
              v_t_24149 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
              break;
            }
            default: heff_nomatch(v_x_2415);
            }
            return ({ V a_0 = v_w_240; V a_1 = v_ms_241; V a_2 = v_uf_242; V a_3 = v_r_243; V a_4 = v_g_244; V a_5 = v_cs_245; V a_6 = v_t_24136; V a_7 = v_t_24149; V a_8 = v_x_2412; V a_9 = v_x_2415; V a_10 = v_hd_2410; V a_11 = v_k_2411; V r_ = (g_heff_2eelab_2eunify_2euElRigid(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9, a_10, a_11)); heff_drop(v_ms_241); r_; });
          }
          case TAG_Just: {
            V v_it1_24150 = heff_field(v_t_24123, 0);
            heff_take_n(v_t_24123, 1ULL, 1);
            heff_drop(v_ms_241);
            heff_drop(v_w_240);
            heff_drop(v_uf_242);
            switch (heff_tag_of(v_it1_24150)) {
            case TAG_MkPair: {
              V v_m_24151 = heff_field(v_it1_24150, 0);
              V v_sp_24152 = heff_field(v_it1_24150, 1);
              heff_take_n(v_it1_24150, 3ULL, 2);
              return heff_tail(heff_get_n(v_r_243, 3, 9), 8, (V[]){v_g_244, v_cs_245, v_m_24151, v_sp_24152, v_x_2412, v_x_2415, v_hd_2410, v_k_2411});
            }
            default: return heff_nomatch(v_it1_24150);
            }
          }
          default: return heff_nomatch(v_t_24123);
          }
        }
        case TAG_Just: {
          V v_it1_24153 = heff_field(v_t_24110, 0);
          heff_take_n(v_t_24110, 1ULL, 1);
          heff_drop(v_ms_241);
          heff_drop(v_w_240);
          heff_drop(v_uf_242);
          switch (heff_tag_of(v_it1_24153)) {
          case TAG_MkPair: {
            V v_m_24154 = heff_field(v_it1_24153, 0);
            V v_sp_24155 = heff_field(v_it1_24153, 1);
            heff_take_n(v_it1_24153, 3ULL, 2);
            return heff_tail(heff_get_n(v_r_243, 3, 9), 8, (V[]){v_g_244, v_cs_245, v_m_24154, v_sp_24155, v_x_2415, v_x_2412, v_hd_2410, v_k_2411});
          }
          default: return heff_nomatch(v_it1_24153);
          }
        }
        default: return heff_nomatch(v_t_24110);
        }
      }
      case TAG_VLam: {
        V v_t_24170;
        switch (heff_tag_of(v_x_2412)) {
        case TAG_VNeu: {
          V v_v1_24158 = heff_dup(heff_field(v_x_2412, 0));
          V v_sp_24159 = heff_dup(heff_field(v_x_2412, 1));
          switch (heff_tag_of(v_v1_24158)) {
          case TAG_HLocal: {
            heff_take_n(v_v1_24158, 0ULL, 1);
            heff_drop(v_sp_24159);
            v_t_24170 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HGlobal: {
            heff_take_n(v_v1_24158, 0ULL, 1);
            heff_drop(v_sp_24159);
            v_t_24170 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HMeta: {
            V v_m_24165 = heff_field(v_v1_24158, 0);
            V v_ru_24v1_24158_24HMeta = heff_take_reuse_n(v_v1_24158, 1ULL, 1);
            v_t_24170 = heff_tag_at_n(v_ru_24v1_24158_24HMeta, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_m_24165, v_sp_24159})});
            break;
          }
          case TAG_HError: {
            heff_drop(v_sp_24159);
            v_t_24170 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_v1_24158);
          }
          break;
        }
        case TAG_VCode: {
          v_t_24170 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VLam: {
          v_t_24170 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VCons: {
          v_t_24170 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VOpaque: {
          v_t_24170 = NTAG(TAG_Nothing);
          break;
        }
        default: heff_nomatch(v_x_2412);
        }
        switch (heff_tag_of(v_t_24170)) {
        case TAG_Nothing: {
          V v_t_24183;
          switch (heff_tag_of(v_x_2415)) {
          case TAG_VNeu: {
            V v_v1_24171 = heff_dup(heff_field(v_x_2415, 0));
            V v_sp_24172 = heff_dup(heff_field(v_x_2415, 1));
            switch (heff_tag_of(v_v1_24171)) {
            case TAG_HLocal: {
              heff_take_n(v_v1_24171, 0ULL, 1);
              heff_drop(v_sp_24172);
              v_t_24183 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HGlobal: {
              heff_take_n(v_v1_24171, 0ULL, 1);
              heff_drop(v_sp_24172);
              v_t_24183 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HMeta: {
              V v_m_24178 = heff_field(v_v1_24171, 0);
              V v_ru_24v1_24171_24HMeta = heff_take_reuse_n(v_v1_24171, 1ULL, 1);
              v_t_24183 = heff_tag_at_n(v_ru_24v1_24171_24HMeta, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_m_24178, v_sp_24172})});
              break;
            }
            case TAG_HError: {
              heff_drop(v_sp_24172);
              v_t_24183 = NTAG(TAG_Nothing);
              break;
            }
            default: heff_nomatch(v_v1_24171);
            }
            break;
          }
          case TAG_VCode: {
            v_t_24183 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VLam: {
            v_t_24183 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VCons: {
            v_t_24183 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VOpaque: {
            v_t_24183 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_x_2415);
          }
          switch (heff_tag_of(v_t_24183)) {
          case TAG_Nothing: {
            V v_t_24196;
            switch (heff_tag_of(v_x_2412)) {
            case TAG_VNeu: {
              V v_v1_24184 = heff_dup(heff_field(v_x_2412, 0));
              switch (heff_tag_of(v_v1_24184)) {
              case TAG_HLocal: {
                V v_ru_24v1_24184_24HLocal = heff_take_reuse_n(v_v1_24184, 0ULL, 1);
                v_t_24196 = (g_heff_2eelab_2econversion_2ecanon_24tok1(v_ru_24v1_24184_24HLocal, heff_dup(v_x_2412)));
                break;
              }
              case TAG_HGlobal: {
                V v_ru_24v1_24184_24HGlobal = heff_take_reuse_n(v_v1_24184, 0ULL, 1);
                v_t_24196 = (g_heff_2eelab_2econversion_2ecanon_24tok1(v_ru_24v1_24184_24HGlobal, heff_dup(v_x_2412)));
                break;
              }
              case TAG_HMeta: {
                heff_take_n(v_v1_24184, 0ULL, 1);
                v_t_24196 = heff_dup(v_x_2412);
                break;
              }
              case TAG_HError: {
                v_t_24196 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
                break;
              }
              default: heff_nomatch(v_v1_24184);
              }
              break;
            }
            case TAG_VCode: {
              v_t_24196 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
              break;
            }
            case TAG_VLam: {
              v_t_24196 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
              break;
            }
            case TAG_VCons: {
              v_t_24196 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
              break;
            }
            case TAG_VOpaque: {
              v_t_24196 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
              break;
            }
            default: heff_nomatch(v_x_2412);
            }
            V v_t_24209;
            switch (heff_tag_of(v_x_2415)) {
            case TAG_VNeu: {
              V v_v1_24197 = heff_dup(heff_field(v_x_2415, 0));
              switch (heff_tag_of(v_v1_24197)) {
              case TAG_HLocal: {
                V v_ru_24v1_24197_24HLocal = heff_take_reuse_n(v_v1_24197, 0ULL, 1);
                v_t_24209 = (g_heff_2eelab_2econversion_2ecanon_24tok1(v_ru_24v1_24197_24HLocal, heff_dup(v_x_2415)));
                break;
              }
              case TAG_HGlobal: {
                V v_ru_24v1_24197_24HGlobal = heff_take_reuse_n(v_v1_24197, 0ULL, 1);
                v_t_24209 = (g_heff_2eelab_2econversion_2ecanon_24tok1(v_ru_24v1_24197_24HGlobal, heff_dup(v_x_2415)));
                break;
              }
              case TAG_HMeta: {
                heff_take_n(v_v1_24197, 0ULL, 1);
                v_t_24209 = heff_dup(v_x_2415);
                break;
              }
              case TAG_HError: {
                v_t_24209 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
                break;
              }
              default: heff_nomatch(v_v1_24197);
              }
              break;
            }
            case TAG_VCode: {
              v_t_24209 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
              break;
            }
            case TAG_VLam: {
              v_t_24209 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
              break;
            }
            case TAG_VCons: {
              v_t_24209 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
              break;
            }
            case TAG_VOpaque: {
              v_t_24209 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
              break;
            }
            default: heff_nomatch(v_x_2415);
            }
            return ({ V a_0 = v_w_240; V a_1 = v_ms_241; V a_2 = v_uf_242; V a_3 = v_r_243; V a_4 = v_g_244; V a_5 = v_cs_245; V a_6 = v_t_24196; V a_7 = v_t_24209; V a_8 = v_x_2412; V a_9 = v_x_2415; V a_10 = v_hd_2410; V a_11 = v_k_2411; V r_ = (g_heff_2eelab_2eunify_2euElRigid(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9, a_10, a_11)); heff_drop(v_ms_241); r_; });
          }
          case TAG_Just: {
            V v_it1_24210 = heff_field(v_t_24183, 0);
            heff_take_n(v_t_24183, 1ULL, 1);
            heff_drop(v_ms_241);
            heff_drop(v_w_240);
            heff_drop(v_uf_242);
            switch (heff_tag_of(v_it1_24210)) {
            case TAG_MkPair: {
              V v_m_24211 = heff_field(v_it1_24210, 0);
              V v_sp_24212 = heff_field(v_it1_24210, 1);
              heff_take_n(v_it1_24210, 3ULL, 2);
              return heff_tail(heff_get_n(v_r_243, 3, 9), 8, (V[]){v_g_244, v_cs_245, v_m_24211, v_sp_24212, v_x_2412, v_x_2415, v_hd_2410, v_k_2411});
            }
            default: return heff_nomatch(v_it1_24210);
            }
          }
          default: return heff_nomatch(v_t_24183);
          }
        }
        case TAG_Just: {
          V v_it1_24213 = heff_field(v_t_24170, 0);
          heff_take_n(v_t_24170, 1ULL, 1);
          heff_drop(v_ms_241);
          heff_drop(v_w_240);
          heff_drop(v_uf_242);
          switch (heff_tag_of(v_it1_24213)) {
          case TAG_MkPair: {
            V v_m_24214 = heff_field(v_it1_24213, 0);
            V v_sp_24215 = heff_field(v_it1_24213, 1);
            heff_take_n(v_it1_24213, 3ULL, 2);
            return heff_tail(heff_get_n(v_r_243, 3, 9), 8, (V[]){v_g_244, v_cs_245, v_m_24214, v_sp_24215, v_x_2415, v_x_2412, v_hd_2410, v_k_2411});
          }
          default: return heff_nomatch(v_it1_24213);
          }
        }
        default: return heff_nomatch(v_t_24170);
        }
      }
      case TAG_VCons: {
        V v_t_24229;
        switch (heff_tag_of(v_x_2412)) {
        case TAG_VNeu: {
          V v_v1_24217 = heff_dup(heff_field(v_x_2412, 0));
          V v_sp_24218 = heff_dup(heff_field(v_x_2412, 1));
          switch (heff_tag_of(v_v1_24217)) {
          case TAG_HLocal: {
            heff_take_n(v_v1_24217, 0ULL, 1);
            heff_drop(v_sp_24218);
            v_t_24229 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HGlobal: {
            heff_take_n(v_v1_24217, 0ULL, 1);
            heff_drop(v_sp_24218);
            v_t_24229 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HMeta: {
            V v_m_24224 = heff_field(v_v1_24217, 0);
            V v_ru_24v1_24217_24HMeta = heff_take_reuse_n(v_v1_24217, 1ULL, 1);
            v_t_24229 = heff_tag_at_n(v_ru_24v1_24217_24HMeta, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_m_24224, v_sp_24218})});
            break;
          }
          case TAG_HError: {
            heff_drop(v_sp_24218);
            v_t_24229 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_v1_24217);
          }
          break;
        }
        case TAG_VCode: {
          v_t_24229 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VLam: {
          v_t_24229 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VCons: {
          v_t_24229 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VOpaque: {
          v_t_24229 = NTAG(TAG_Nothing);
          break;
        }
        default: heff_nomatch(v_x_2412);
        }
        switch (heff_tag_of(v_t_24229)) {
        case TAG_Nothing: {
          V v_t_24242;
          switch (heff_tag_of(v_x_2415)) {
          case TAG_VNeu: {
            V v_v1_24230 = heff_dup(heff_field(v_x_2415, 0));
            V v_sp_24231 = heff_dup(heff_field(v_x_2415, 1));
            switch (heff_tag_of(v_v1_24230)) {
            case TAG_HLocal: {
              heff_take_n(v_v1_24230, 0ULL, 1);
              heff_drop(v_sp_24231);
              v_t_24242 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HGlobal: {
              heff_take_n(v_v1_24230, 0ULL, 1);
              heff_drop(v_sp_24231);
              v_t_24242 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HMeta: {
              V v_m_24237 = heff_field(v_v1_24230, 0);
              V v_ru_24v1_24230_24HMeta = heff_take_reuse_n(v_v1_24230, 1ULL, 1);
              v_t_24242 = heff_tag_at_n(v_ru_24v1_24230_24HMeta, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_m_24237, v_sp_24231})});
              break;
            }
            case TAG_HError: {
              heff_drop(v_sp_24231);
              v_t_24242 = NTAG(TAG_Nothing);
              break;
            }
            default: heff_nomatch(v_v1_24230);
            }
            break;
          }
          case TAG_VCode: {
            v_t_24242 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VLam: {
            v_t_24242 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VCons: {
            v_t_24242 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VOpaque: {
            v_t_24242 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_x_2415);
          }
          switch (heff_tag_of(v_t_24242)) {
          case TAG_Nothing: {
            V v_t_24255;
            switch (heff_tag_of(v_x_2412)) {
            case TAG_VNeu: {
              V v_v1_24243 = heff_dup(heff_field(v_x_2412, 0));
              switch (heff_tag_of(v_v1_24243)) {
              case TAG_HLocal: {
                V v_ru_24v1_24243_24HLocal = heff_take_reuse_n(v_v1_24243, 0ULL, 1);
                v_t_24255 = (g_heff_2eelab_2econversion_2ecanon_24tok1(v_ru_24v1_24243_24HLocal, heff_dup(v_x_2412)));
                break;
              }
              case TAG_HGlobal: {
                V v_ru_24v1_24243_24HGlobal = heff_take_reuse_n(v_v1_24243, 0ULL, 1);
                v_t_24255 = (g_heff_2eelab_2econversion_2ecanon_24tok1(v_ru_24v1_24243_24HGlobal, heff_dup(v_x_2412)));
                break;
              }
              case TAG_HMeta: {
                heff_take_n(v_v1_24243, 0ULL, 1);
                v_t_24255 = heff_dup(v_x_2412);
                break;
              }
              case TAG_HError: {
                v_t_24255 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
                break;
              }
              default: heff_nomatch(v_v1_24243);
              }
              break;
            }
            case TAG_VCode: {
              v_t_24255 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
              break;
            }
            case TAG_VLam: {
              v_t_24255 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
              break;
            }
            case TAG_VCons: {
              v_t_24255 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
              break;
            }
            case TAG_VOpaque: {
              v_t_24255 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
              break;
            }
            default: heff_nomatch(v_x_2412);
            }
            V v_t_24268;
            switch (heff_tag_of(v_x_2415)) {
            case TAG_VNeu: {
              V v_v1_24256 = heff_dup(heff_field(v_x_2415, 0));
              switch (heff_tag_of(v_v1_24256)) {
              case TAG_HLocal: {
                V v_ru_24v1_24256_24HLocal = heff_take_reuse_n(v_v1_24256, 0ULL, 1);
                v_t_24268 = (g_heff_2eelab_2econversion_2ecanon_24tok1(v_ru_24v1_24256_24HLocal, heff_dup(v_x_2415)));
                break;
              }
              case TAG_HGlobal: {
                V v_ru_24v1_24256_24HGlobal = heff_take_reuse_n(v_v1_24256, 0ULL, 1);
                v_t_24268 = (g_heff_2eelab_2econversion_2ecanon_24tok1(v_ru_24v1_24256_24HGlobal, heff_dup(v_x_2415)));
                break;
              }
              case TAG_HMeta: {
                heff_take_n(v_v1_24256, 0ULL, 1);
                v_t_24268 = heff_dup(v_x_2415);
                break;
              }
              case TAG_HError: {
                v_t_24268 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
                break;
              }
              default: heff_nomatch(v_v1_24256);
              }
              break;
            }
            case TAG_VCode: {
              v_t_24268 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
              break;
            }
            case TAG_VLam: {
              v_t_24268 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
              break;
            }
            case TAG_VCons: {
              v_t_24268 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
              break;
            }
            case TAG_VOpaque: {
              v_t_24268 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
              break;
            }
            default: heff_nomatch(v_x_2415);
            }
            return ({ V a_0 = v_w_240; V a_1 = v_ms_241; V a_2 = v_uf_242; V a_3 = v_r_243; V a_4 = v_g_244; V a_5 = v_cs_245; V a_6 = v_t_24255; V a_7 = v_t_24268; V a_8 = v_x_2412; V a_9 = v_x_2415; V a_10 = v_hd_2410; V a_11 = v_k_2411; V r_ = (g_heff_2eelab_2eunify_2euElRigid(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9, a_10, a_11)); heff_drop(v_ms_241); r_; });
          }
          case TAG_Just: {
            V v_it1_24269 = heff_field(v_t_24242, 0);
            heff_take_n(v_t_24242, 1ULL, 1);
            heff_drop(v_ms_241);
            heff_drop(v_w_240);
            heff_drop(v_uf_242);
            switch (heff_tag_of(v_it1_24269)) {
            case TAG_MkPair: {
              V v_m_24270 = heff_field(v_it1_24269, 0);
              V v_sp_24271 = heff_field(v_it1_24269, 1);
              heff_take_n(v_it1_24269, 3ULL, 2);
              return heff_tail(heff_get_n(v_r_243, 3, 9), 8, (V[]){v_g_244, v_cs_245, v_m_24270, v_sp_24271, v_x_2412, v_x_2415, v_hd_2410, v_k_2411});
            }
            default: return heff_nomatch(v_it1_24269);
            }
          }
          default: return heff_nomatch(v_t_24242);
          }
        }
        case TAG_Just: {
          V v_it1_24272 = heff_field(v_t_24229, 0);
          heff_take_n(v_t_24229, 1ULL, 1);
          heff_drop(v_ms_241);
          heff_drop(v_w_240);
          heff_drop(v_uf_242);
          switch (heff_tag_of(v_it1_24272)) {
          case TAG_MkPair: {
            V v_m_24273 = heff_field(v_it1_24272, 0);
            V v_sp_24274 = heff_field(v_it1_24272, 1);
            heff_take_n(v_it1_24272, 3ULL, 2);
            return heff_tail(heff_get_n(v_r_243, 3, 9), 8, (V[]){v_g_244, v_cs_245, v_m_24273, v_sp_24274, v_x_2415, v_x_2412, v_hd_2410, v_k_2411});
          }
          default: return heff_nomatch(v_it1_24272);
          }
        }
        default: return heff_nomatch(v_t_24229);
        }
      }
      case TAG_VOpaque: {
        heff_drop_tag(v_x_2412, 5);
        heff_drop(v_ms_241);
        heff_drop(v_w_240);
        heff_drop(v_hd_2410);
        heff_drop_rec(v_cs_245, 2);
        heff_drop(v_uf_242);
        heff_drop_rec(v_r_243, 9);
        heff_drop(v_g_244);
        V f_ = v_k_2411;
        args[0] = NTAG(TAG_MkUnit);
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      }
      default: return heff_nomatch(v_x_2415);
      }
    }
    case TAG_VCode: {
      switch (heff_tag_of(v_x_2415)) {
      case TAG_VNeu: {
        V v_t_24293;
        switch (heff_tag_of(v_x_2412)) {
        case TAG_VNeu: {
          V v_v1_24281 = heff_dup(heff_field(v_x_2412, 0));
          V v_sp_24282 = heff_dup(heff_field(v_x_2412, 1));
          switch (heff_tag_of(v_v1_24281)) {
          case TAG_HLocal: {
            heff_take_n(v_v1_24281, 0ULL, 1);
            heff_drop(v_sp_24282);
            v_t_24293 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HGlobal: {
            heff_take_n(v_v1_24281, 0ULL, 1);
            heff_drop(v_sp_24282);
            v_t_24293 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HMeta: {
            V v_m_24288 = heff_field(v_v1_24281, 0);
            V v_ru_24v1_24281_24HMeta = heff_take_reuse_n(v_v1_24281, 1ULL, 1);
            v_t_24293 = heff_tag_at_n(v_ru_24v1_24281_24HMeta, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_m_24288, v_sp_24282})});
            break;
          }
          case TAG_HError: {
            heff_drop(v_sp_24282);
            v_t_24293 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_v1_24281);
          }
          break;
        }
        case TAG_VCode: {
          v_t_24293 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VLam: {
          v_t_24293 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VCons: {
          v_t_24293 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VOpaque: {
          v_t_24293 = NTAG(TAG_Nothing);
          break;
        }
        default: heff_nomatch(v_x_2412);
        }
        switch (heff_tag_of(v_t_24293)) {
        case TAG_Nothing: {
          V v_t_24306;
          switch (heff_tag_of(v_x_2415)) {
          case TAG_VNeu: {
            V v_v1_24294 = heff_dup(heff_field(v_x_2415, 0));
            V v_sp_24295 = heff_dup(heff_field(v_x_2415, 1));
            switch (heff_tag_of(v_v1_24294)) {
            case TAG_HLocal: {
              heff_take_n(v_v1_24294, 0ULL, 1);
              heff_drop(v_sp_24295);
              v_t_24306 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HGlobal: {
              heff_take_n(v_v1_24294, 0ULL, 1);
              heff_drop(v_sp_24295);
              v_t_24306 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HMeta: {
              V v_m_24301 = heff_field(v_v1_24294, 0);
              V v_ru_24v1_24294_24HMeta = heff_take_reuse_n(v_v1_24294, 1ULL, 1);
              v_t_24306 = heff_tag_at_n(v_ru_24v1_24294_24HMeta, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_m_24301, v_sp_24295})});
              break;
            }
            case TAG_HError: {
              heff_drop(v_sp_24295);
              v_t_24306 = NTAG(TAG_Nothing);
              break;
            }
            default: heff_nomatch(v_v1_24294);
            }
            break;
          }
          case TAG_VCode: {
            v_t_24306 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VLam: {
            v_t_24306 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VCons: {
            v_t_24306 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VOpaque: {
            v_t_24306 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_x_2415);
          }
          switch (heff_tag_of(v_t_24306)) {
          case TAG_Nothing: {
            V v_t_24319;
            switch (heff_tag_of(v_x_2412)) {
            case TAG_VNeu: {
              V v_v1_24307 = heff_dup(heff_field(v_x_2412, 0));
              switch (heff_tag_of(v_v1_24307)) {
              case TAG_HLocal: {
                V v_ru_24v1_24307_24HLocal = heff_take_reuse_n(v_v1_24307, 0ULL, 1);
                v_t_24319 = (g_heff_2eelab_2econversion_2ecanon_24tok1(v_ru_24v1_24307_24HLocal, heff_dup(v_x_2412)));
                break;
              }
              case TAG_HGlobal: {
                V v_ru_24v1_24307_24HGlobal = heff_take_reuse_n(v_v1_24307, 0ULL, 1);
                v_t_24319 = (g_heff_2eelab_2econversion_2ecanon_24tok1(v_ru_24v1_24307_24HGlobal, heff_dup(v_x_2412)));
                break;
              }
              case TAG_HMeta: {
                heff_take_n(v_v1_24307, 0ULL, 1);
                v_t_24319 = heff_dup(v_x_2412);
                break;
              }
              case TAG_HError: {
                v_t_24319 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
                break;
              }
              default: heff_nomatch(v_v1_24307);
              }
              break;
            }
            case TAG_VCode: {
              v_t_24319 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
              break;
            }
            case TAG_VLam: {
              v_t_24319 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
              break;
            }
            case TAG_VCons: {
              v_t_24319 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
              break;
            }
            case TAG_VOpaque: {
              v_t_24319 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
              break;
            }
            default: heff_nomatch(v_x_2412);
            }
            V v_t_24332;
            switch (heff_tag_of(v_x_2415)) {
            case TAG_VNeu: {
              V v_v1_24320 = heff_dup(heff_field(v_x_2415, 0));
              switch (heff_tag_of(v_v1_24320)) {
              case TAG_HLocal: {
                V v_ru_24v1_24320_24HLocal = heff_take_reuse_n(v_v1_24320, 0ULL, 1);
                v_t_24332 = (g_heff_2eelab_2econversion_2ecanon_24tok1(v_ru_24v1_24320_24HLocal, heff_dup(v_x_2415)));
                break;
              }
              case TAG_HGlobal: {
                V v_ru_24v1_24320_24HGlobal = heff_take_reuse_n(v_v1_24320, 0ULL, 1);
                v_t_24332 = (g_heff_2eelab_2econversion_2ecanon_24tok1(v_ru_24v1_24320_24HGlobal, heff_dup(v_x_2415)));
                break;
              }
              case TAG_HMeta: {
                heff_take_n(v_v1_24320, 0ULL, 1);
                v_t_24332 = heff_dup(v_x_2415);
                break;
              }
              case TAG_HError: {
                v_t_24332 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
                break;
              }
              default: heff_nomatch(v_v1_24320);
              }
              break;
            }
            case TAG_VCode: {
              v_t_24332 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
              break;
            }
            case TAG_VLam: {
              v_t_24332 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
              break;
            }
            case TAG_VCons: {
              v_t_24332 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
              break;
            }
            case TAG_VOpaque: {
              v_t_24332 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
              break;
            }
            default: heff_nomatch(v_x_2415);
            }
            return ({ V a_0 = v_w_240; V a_1 = v_ms_241; V a_2 = v_uf_242; V a_3 = v_r_243; V a_4 = v_g_244; V a_5 = v_cs_245; V a_6 = v_t_24319; V a_7 = v_t_24332; V a_8 = v_x_2412; V a_9 = v_x_2415; V a_10 = v_hd_2410; V a_11 = v_k_2411; V r_ = (g_heff_2eelab_2eunify_2euElRigid(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9, a_10, a_11)); heff_drop(v_ms_241); r_; });
          }
          case TAG_Just: {
            V v_it1_24333 = heff_field(v_t_24306, 0);
            heff_take_n(v_t_24306, 1ULL, 1);
            heff_drop(v_ms_241);
            heff_drop(v_w_240);
            heff_drop(v_uf_242);
            switch (heff_tag_of(v_it1_24333)) {
            case TAG_MkPair: {
              V v_m_24334 = heff_field(v_it1_24333, 0);
              V v_sp_24335 = heff_field(v_it1_24333, 1);
              heff_take_n(v_it1_24333, 3ULL, 2);
              return heff_tail(heff_get_n(v_r_243, 3, 9), 8, (V[]){v_g_244, v_cs_245, v_m_24334, v_sp_24335, v_x_2412, v_x_2415, v_hd_2410, v_k_2411});
            }
            default: return heff_nomatch(v_it1_24333);
            }
          }
          default: return heff_nomatch(v_t_24306);
          }
        }
        case TAG_Just: {
          V v_it1_24336 = heff_field(v_t_24293, 0);
          heff_take_n(v_t_24293, 1ULL, 1);
          heff_drop(v_ms_241);
          heff_drop(v_w_240);
          heff_drop(v_uf_242);
          switch (heff_tag_of(v_it1_24336)) {
          case TAG_MkPair: {
            V v_m_24337 = heff_field(v_it1_24336, 0);
            V v_sp_24338 = heff_field(v_it1_24336, 1);
            heff_take_n(v_it1_24336, 3ULL, 2);
            return heff_tail(heff_get_n(v_r_243, 3, 9), 8, (V[]){v_g_244, v_cs_245, v_m_24337, v_sp_24338, v_x_2415, v_x_2412, v_hd_2410, v_k_2411});
          }
          default: return heff_nomatch(v_it1_24336);
          }
        }
        default: return heff_nomatch(v_t_24293);
        }
      }
      case TAG_VCode: {
        V v_t_24352;
        switch (heff_tag_of(v_x_2412)) {
        case TAG_VNeu: {
          V v_v1_24340 = heff_dup(heff_field(v_x_2412, 0));
          V v_sp_24341 = heff_dup(heff_field(v_x_2412, 1));
          switch (heff_tag_of(v_v1_24340)) {
          case TAG_HLocal: {
            heff_take_n(v_v1_24340, 0ULL, 1);
            heff_drop(v_sp_24341);
            v_t_24352 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HGlobal: {
            heff_take_n(v_v1_24340, 0ULL, 1);
            heff_drop(v_sp_24341);
            v_t_24352 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HMeta: {
            V v_m_24347 = heff_field(v_v1_24340, 0);
            V v_ru_24v1_24340_24HMeta = heff_take_reuse_n(v_v1_24340, 1ULL, 1);
            v_t_24352 = heff_tag_at_n(v_ru_24v1_24340_24HMeta, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_m_24347, v_sp_24341})});
            break;
          }
          case TAG_HError: {
            heff_drop(v_sp_24341);
            v_t_24352 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_v1_24340);
          }
          break;
        }
        case TAG_VCode: {
          v_t_24352 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VLam: {
          v_t_24352 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VCons: {
          v_t_24352 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VOpaque: {
          v_t_24352 = NTAG(TAG_Nothing);
          break;
        }
        default: heff_nomatch(v_x_2412);
        }
        switch (heff_tag_of(v_t_24352)) {
        case TAG_Nothing: {
          V v_t_24365;
          switch (heff_tag_of(v_x_2415)) {
          case TAG_VNeu: {
            V v_v1_24353 = heff_dup(heff_field(v_x_2415, 0));
            V v_sp_24354 = heff_dup(heff_field(v_x_2415, 1));
            switch (heff_tag_of(v_v1_24353)) {
            case TAG_HLocal: {
              heff_take_n(v_v1_24353, 0ULL, 1);
              heff_drop(v_sp_24354);
              v_t_24365 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HGlobal: {
              heff_take_n(v_v1_24353, 0ULL, 1);
              heff_drop(v_sp_24354);
              v_t_24365 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HMeta: {
              V v_m_24360 = heff_field(v_v1_24353, 0);
              V v_ru_24v1_24353_24HMeta = heff_take_reuse_n(v_v1_24353, 1ULL, 1);
              v_t_24365 = heff_tag_at_n(v_ru_24v1_24353_24HMeta, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_m_24360, v_sp_24354})});
              break;
            }
            case TAG_HError: {
              heff_drop(v_sp_24354);
              v_t_24365 = NTAG(TAG_Nothing);
              break;
            }
            default: heff_nomatch(v_v1_24353);
            }
            break;
          }
          case TAG_VCode: {
            v_t_24365 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VLam: {
            v_t_24365 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VCons: {
            v_t_24365 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VOpaque: {
            v_t_24365 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_x_2415);
          }
          switch (heff_tag_of(v_t_24365)) {
          case TAG_Nothing: {
            V v_t_24378;
            switch (heff_tag_of(v_x_2412)) {
            case TAG_VNeu: {
              V v_v1_24366 = heff_dup(heff_field(v_x_2412, 0));
              switch (heff_tag_of(v_v1_24366)) {
              case TAG_HLocal: {
                V v_ru_24v1_24366_24HLocal = heff_take_reuse_n(v_v1_24366, 0ULL, 1);
                v_t_24378 = (g_heff_2eelab_2econversion_2ecanon_24tok1(v_ru_24v1_24366_24HLocal, heff_dup(v_x_2412)));
                break;
              }
              case TAG_HGlobal: {
                V v_ru_24v1_24366_24HGlobal = heff_take_reuse_n(v_v1_24366, 0ULL, 1);
                v_t_24378 = (g_heff_2eelab_2econversion_2ecanon_24tok1(v_ru_24v1_24366_24HGlobal, heff_dup(v_x_2412)));
                break;
              }
              case TAG_HMeta: {
                heff_take_n(v_v1_24366, 0ULL, 1);
                v_t_24378 = heff_dup(v_x_2412);
                break;
              }
              case TAG_HError: {
                v_t_24378 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
                break;
              }
              default: heff_nomatch(v_v1_24366);
              }
              break;
            }
            case TAG_VCode: {
              v_t_24378 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
              break;
            }
            case TAG_VLam: {
              v_t_24378 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
              break;
            }
            case TAG_VCons: {
              v_t_24378 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
              break;
            }
            case TAG_VOpaque: {
              v_t_24378 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
              break;
            }
            default: heff_nomatch(v_x_2412);
            }
            V v_t_24391;
            switch (heff_tag_of(v_x_2415)) {
            case TAG_VNeu: {
              V v_v1_24379 = heff_dup(heff_field(v_x_2415, 0));
              switch (heff_tag_of(v_v1_24379)) {
              case TAG_HLocal: {
                V v_ru_24v1_24379_24HLocal = heff_take_reuse_n(v_v1_24379, 0ULL, 1);
                v_t_24391 = (g_heff_2eelab_2econversion_2ecanon_24tok1(v_ru_24v1_24379_24HLocal, heff_dup(v_x_2415)));
                break;
              }
              case TAG_HGlobal: {
                V v_ru_24v1_24379_24HGlobal = heff_take_reuse_n(v_v1_24379, 0ULL, 1);
                v_t_24391 = (g_heff_2eelab_2econversion_2ecanon_24tok1(v_ru_24v1_24379_24HGlobal, heff_dup(v_x_2415)));
                break;
              }
              case TAG_HMeta: {
                heff_take_n(v_v1_24379, 0ULL, 1);
                v_t_24391 = heff_dup(v_x_2415);
                break;
              }
              case TAG_HError: {
                v_t_24391 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
                break;
              }
              default: heff_nomatch(v_v1_24379);
              }
              break;
            }
            case TAG_VCode: {
              v_t_24391 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
              break;
            }
            case TAG_VLam: {
              v_t_24391 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
              break;
            }
            case TAG_VCons: {
              v_t_24391 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
              break;
            }
            case TAG_VOpaque: {
              v_t_24391 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
              break;
            }
            default: heff_nomatch(v_x_2415);
            }
            return ({ V a_0 = v_w_240; V a_1 = v_ms_241; V a_2 = v_uf_242; V a_3 = v_r_243; V a_4 = v_g_244; V a_5 = v_cs_245; V a_6 = v_t_24378; V a_7 = v_t_24391; V a_8 = v_x_2412; V a_9 = v_x_2415; V a_10 = v_hd_2410; V a_11 = v_k_2411; V r_ = (g_heff_2eelab_2eunify_2euElRigid(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9, a_10, a_11)); heff_drop(v_ms_241); r_; });
          }
          case TAG_Just: {
            V v_it1_24392 = heff_field(v_t_24365, 0);
            heff_take_n(v_t_24365, 1ULL, 1);
            heff_drop(v_ms_241);
            heff_drop(v_w_240);
            heff_drop(v_uf_242);
            switch (heff_tag_of(v_it1_24392)) {
            case TAG_MkPair: {
              V v_m_24393 = heff_field(v_it1_24392, 0);
              V v_sp_24394 = heff_field(v_it1_24392, 1);
              heff_take_n(v_it1_24392, 3ULL, 2);
              return heff_tail(heff_get_n(v_r_243, 3, 9), 8, (V[]){v_g_244, v_cs_245, v_m_24393, v_sp_24394, v_x_2412, v_x_2415, v_hd_2410, v_k_2411});
            }
            default: return heff_nomatch(v_it1_24392);
            }
          }
          default: return heff_nomatch(v_t_24365);
          }
        }
        case TAG_Just: {
          V v_it1_24395 = heff_field(v_t_24352, 0);
          heff_take_n(v_t_24352, 1ULL, 1);
          heff_drop(v_ms_241);
          heff_drop(v_w_240);
          heff_drop(v_uf_242);
          switch (heff_tag_of(v_it1_24395)) {
          case TAG_MkPair: {
            V v_m_24396 = heff_field(v_it1_24395, 0);
            V v_sp_24397 = heff_field(v_it1_24395, 1);
            heff_take_n(v_it1_24395, 3ULL, 2);
            return heff_tail(heff_get_n(v_r_243, 3, 9), 8, (V[]){v_g_244, v_cs_245, v_m_24396, v_sp_24397, v_x_2415, v_x_2412, v_hd_2410, v_k_2411});
          }
          default: return heff_nomatch(v_it1_24395);
          }
        }
        default: return heff_nomatch(v_t_24352);
        }
      }
      case TAG_VLam: {
        V v_t_24412;
        switch (heff_tag_of(v_x_2412)) {
        case TAG_VNeu: {
          V v_v1_24400 = heff_dup(heff_field(v_x_2412, 0));
          V v_sp_24401 = heff_dup(heff_field(v_x_2412, 1));
          switch (heff_tag_of(v_v1_24400)) {
          case TAG_HLocal: {
            heff_take_n(v_v1_24400, 0ULL, 1);
            heff_drop(v_sp_24401);
            v_t_24412 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HGlobal: {
            heff_take_n(v_v1_24400, 0ULL, 1);
            heff_drop(v_sp_24401);
            v_t_24412 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HMeta: {
            V v_m_24407 = heff_field(v_v1_24400, 0);
            V v_ru_24v1_24400_24HMeta = heff_take_reuse_n(v_v1_24400, 1ULL, 1);
            v_t_24412 = heff_tag_at_n(v_ru_24v1_24400_24HMeta, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_m_24407, v_sp_24401})});
            break;
          }
          case TAG_HError: {
            heff_drop(v_sp_24401);
            v_t_24412 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_v1_24400);
          }
          break;
        }
        case TAG_VCode: {
          v_t_24412 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VLam: {
          v_t_24412 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VCons: {
          v_t_24412 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VOpaque: {
          v_t_24412 = NTAG(TAG_Nothing);
          break;
        }
        default: heff_nomatch(v_x_2412);
        }
        switch (heff_tag_of(v_t_24412)) {
        case TAG_Nothing: {
          V v_t_24425;
          switch (heff_tag_of(v_x_2415)) {
          case TAG_VNeu: {
            V v_v1_24413 = heff_dup(heff_field(v_x_2415, 0));
            V v_sp_24414 = heff_dup(heff_field(v_x_2415, 1));
            switch (heff_tag_of(v_v1_24413)) {
            case TAG_HLocal: {
              heff_take_n(v_v1_24413, 0ULL, 1);
              heff_drop(v_sp_24414);
              v_t_24425 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HGlobal: {
              heff_take_n(v_v1_24413, 0ULL, 1);
              heff_drop(v_sp_24414);
              v_t_24425 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HMeta: {
              V v_m_24420 = heff_field(v_v1_24413, 0);
              V v_ru_24v1_24413_24HMeta = heff_take_reuse_n(v_v1_24413, 1ULL, 1);
              v_t_24425 = heff_tag_at_n(v_ru_24v1_24413_24HMeta, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_m_24420, v_sp_24414})});
              break;
            }
            case TAG_HError: {
              heff_drop(v_sp_24414);
              v_t_24425 = NTAG(TAG_Nothing);
              break;
            }
            default: heff_nomatch(v_v1_24413);
            }
            break;
          }
          case TAG_VCode: {
            v_t_24425 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VLam: {
            v_t_24425 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VCons: {
            v_t_24425 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VOpaque: {
            v_t_24425 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_x_2415);
          }
          switch (heff_tag_of(v_t_24425)) {
          case TAG_Nothing: {
            V v_t_24438;
            switch (heff_tag_of(v_x_2412)) {
            case TAG_VNeu: {
              V v_v1_24426 = heff_dup(heff_field(v_x_2412, 0));
              switch (heff_tag_of(v_v1_24426)) {
              case TAG_HLocal: {
                V v_ru_24v1_24426_24HLocal = heff_take_reuse_n(v_v1_24426, 0ULL, 1);
                v_t_24438 = (g_heff_2eelab_2econversion_2ecanon_24tok1(v_ru_24v1_24426_24HLocal, heff_dup(v_x_2412)));
                break;
              }
              case TAG_HGlobal: {
                V v_ru_24v1_24426_24HGlobal = heff_take_reuse_n(v_v1_24426, 0ULL, 1);
                v_t_24438 = (g_heff_2eelab_2econversion_2ecanon_24tok1(v_ru_24v1_24426_24HGlobal, heff_dup(v_x_2412)));
                break;
              }
              case TAG_HMeta: {
                heff_take_n(v_v1_24426, 0ULL, 1);
                v_t_24438 = heff_dup(v_x_2412);
                break;
              }
              case TAG_HError: {
                v_t_24438 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
                break;
              }
              default: heff_nomatch(v_v1_24426);
              }
              break;
            }
            case TAG_VCode: {
              v_t_24438 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
              break;
            }
            case TAG_VLam: {
              v_t_24438 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
              break;
            }
            case TAG_VCons: {
              v_t_24438 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
              break;
            }
            case TAG_VOpaque: {
              v_t_24438 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
              break;
            }
            default: heff_nomatch(v_x_2412);
            }
            V v_t_24451;
            switch (heff_tag_of(v_x_2415)) {
            case TAG_VNeu: {
              V v_v1_24439 = heff_dup(heff_field(v_x_2415, 0));
              switch (heff_tag_of(v_v1_24439)) {
              case TAG_HLocal: {
                V v_ru_24v1_24439_24HLocal = heff_take_reuse_n(v_v1_24439, 0ULL, 1);
                v_t_24451 = (g_heff_2eelab_2econversion_2ecanon_24tok1(v_ru_24v1_24439_24HLocal, heff_dup(v_x_2415)));
                break;
              }
              case TAG_HGlobal: {
                V v_ru_24v1_24439_24HGlobal = heff_take_reuse_n(v_v1_24439, 0ULL, 1);
                v_t_24451 = (g_heff_2eelab_2econversion_2ecanon_24tok1(v_ru_24v1_24439_24HGlobal, heff_dup(v_x_2415)));
                break;
              }
              case TAG_HMeta: {
                heff_take_n(v_v1_24439, 0ULL, 1);
                v_t_24451 = heff_dup(v_x_2415);
                break;
              }
              case TAG_HError: {
                v_t_24451 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
                break;
              }
              default: heff_nomatch(v_v1_24439);
              }
              break;
            }
            case TAG_VCode: {
              v_t_24451 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
              break;
            }
            case TAG_VLam: {
              v_t_24451 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
              break;
            }
            case TAG_VCons: {
              v_t_24451 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
              break;
            }
            case TAG_VOpaque: {
              v_t_24451 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
              break;
            }
            default: heff_nomatch(v_x_2415);
            }
            return ({ V a_0 = v_w_240; V a_1 = v_ms_241; V a_2 = v_uf_242; V a_3 = v_r_243; V a_4 = v_g_244; V a_5 = v_cs_245; V a_6 = v_t_24438; V a_7 = v_t_24451; V a_8 = v_x_2412; V a_9 = v_x_2415; V a_10 = v_hd_2410; V a_11 = v_k_2411; V r_ = (g_heff_2eelab_2eunify_2euElRigid(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9, a_10, a_11)); heff_drop(v_ms_241); r_; });
          }
          case TAG_Just: {
            V v_it1_24452 = heff_field(v_t_24425, 0);
            heff_take_n(v_t_24425, 1ULL, 1);
            heff_drop(v_ms_241);
            heff_drop(v_w_240);
            heff_drop(v_uf_242);
            switch (heff_tag_of(v_it1_24452)) {
            case TAG_MkPair: {
              V v_m_24453 = heff_field(v_it1_24452, 0);
              V v_sp_24454 = heff_field(v_it1_24452, 1);
              heff_take_n(v_it1_24452, 3ULL, 2);
              return heff_tail(heff_get_n(v_r_243, 3, 9), 8, (V[]){v_g_244, v_cs_245, v_m_24453, v_sp_24454, v_x_2412, v_x_2415, v_hd_2410, v_k_2411});
            }
            default: return heff_nomatch(v_it1_24452);
            }
          }
          default: return heff_nomatch(v_t_24425);
          }
        }
        case TAG_Just: {
          V v_it1_24455 = heff_field(v_t_24412, 0);
          heff_take_n(v_t_24412, 1ULL, 1);
          heff_drop(v_ms_241);
          heff_drop(v_w_240);
          heff_drop(v_uf_242);
          switch (heff_tag_of(v_it1_24455)) {
          case TAG_MkPair: {
            V v_m_24456 = heff_field(v_it1_24455, 0);
            V v_sp_24457 = heff_field(v_it1_24455, 1);
            heff_take_n(v_it1_24455, 3ULL, 2);
            return heff_tail(heff_get_n(v_r_243, 3, 9), 8, (V[]){v_g_244, v_cs_245, v_m_24456, v_sp_24457, v_x_2415, v_x_2412, v_hd_2410, v_k_2411});
          }
          default: return heff_nomatch(v_it1_24455);
          }
        }
        default: return heff_nomatch(v_t_24412);
        }
      }
      case TAG_VCons: {
        V v_t_24471;
        switch (heff_tag_of(v_x_2412)) {
        case TAG_VNeu: {
          V v_v1_24459 = heff_dup(heff_field(v_x_2412, 0));
          V v_sp_24460 = heff_dup(heff_field(v_x_2412, 1));
          switch (heff_tag_of(v_v1_24459)) {
          case TAG_HLocal: {
            heff_take_n(v_v1_24459, 0ULL, 1);
            heff_drop(v_sp_24460);
            v_t_24471 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HGlobal: {
            heff_take_n(v_v1_24459, 0ULL, 1);
            heff_drop(v_sp_24460);
            v_t_24471 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HMeta: {
            V v_m_24466 = heff_field(v_v1_24459, 0);
            V v_ru_24v1_24459_24HMeta = heff_take_reuse_n(v_v1_24459, 1ULL, 1);
            v_t_24471 = heff_tag_at_n(v_ru_24v1_24459_24HMeta, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_m_24466, v_sp_24460})});
            break;
          }
          case TAG_HError: {
            heff_drop(v_sp_24460);
            v_t_24471 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_v1_24459);
          }
          break;
        }
        case TAG_VCode: {
          v_t_24471 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VLam: {
          v_t_24471 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VCons: {
          v_t_24471 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VOpaque: {
          v_t_24471 = NTAG(TAG_Nothing);
          break;
        }
        default: heff_nomatch(v_x_2412);
        }
        switch (heff_tag_of(v_t_24471)) {
        case TAG_Nothing: {
          V v_t_24484;
          switch (heff_tag_of(v_x_2415)) {
          case TAG_VNeu: {
            V v_v1_24472 = heff_dup(heff_field(v_x_2415, 0));
            V v_sp_24473 = heff_dup(heff_field(v_x_2415, 1));
            switch (heff_tag_of(v_v1_24472)) {
            case TAG_HLocal: {
              heff_take_n(v_v1_24472, 0ULL, 1);
              heff_drop(v_sp_24473);
              v_t_24484 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HGlobal: {
              heff_take_n(v_v1_24472, 0ULL, 1);
              heff_drop(v_sp_24473);
              v_t_24484 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HMeta: {
              V v_m_24479 = heff_field(v_v1_24472, 0);
              V v_ru_24v1_24472_24HMeta = heff_take_reuse_n(v_v1_24472, 1ULL, 1);
              v_t_24484 = heff_tag_at_n(v_ru_24v1_24472_24HMeta, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_m_24479, v_sp_24473})});
              break;
            }
            case TAG_HError: {
              heff_drop(v_sp_24473);
              v_t_24484 = NTAG(TAG_Nothing);
              break;
            }
            default: heff_nomatch(v_v1_24472);
            }
            break;
          }
          case TAG_VCode: {
            v_t_24484 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VLam: {
            v_t_24484 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VCons: {
            v_t_24484 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VOpaque: {
            v_t_24484 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_x_2415);
          }
          switch (heff_tag_of(v_t_24484)) {
          case TAG_Nothing: {
            V v_t_24497;
            switch (heff_tag_of(v_x_2412)) {
            case TAG_VNeu: {
              V v_v1_24485 = heff_dup(heff_field(v_x_2412, 0));
              switch (heff_tag_of(v_v1_24485)) {
              case TAG_HLocal: {
                V v_ru_24v1_24485_24HLocal = heff_take_reuse_n(v_v1_24485, 0ULL, 1);
                v_t_24497 = (g_heff_2eelab_2econversion_2ecanon_24tok1(v_ru_24v1_24485_24HLocal, heff_dup(v_x_2412)));
                break;
              }
              case TAG_HGlobal: {
                V v_ru_24v1_24485_24HGlobal = heff_take_reuse_n(v_v1_24485, 0ULL, 1);
                v_t_24497 = (g_heff_2eelab_2econversion_2ecanon_24tok1(v_ru_24v1_24485_24HGlobal, heff_dup(v_x_2412)));
                break;
              }
              case TAG_HMeta: {
                heff_take_n(v_v1_24485, 0ULL, 1);
                v_t_24497 = heff_dup(v_x_2412);
                break;
              }
              case TAG_HError: {
                v_t_24497 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
                break;
              }
              default: heff_nomatch(v_v1_24485);
              }
              break;
            }
            case TAG_VCode: {
              v_t_24497 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
              break;
            }
            case TAG_VLam: {
              v_t_24497 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
              break;
            }
            case TAG_VCons: {
              v_t_24497 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
              break;
            }
            case TAG_VOpaque: {
              v_t_24497 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
              break;
            }
            default: heff_nomatch(v_x_2412);
            }
            V v_t_24510;
            switch (heff_tag_of(v_x_2415)) {
            case TAG_VNeu: {
              V v_v1_24498 = heff_dup(heff_field(v_x_2415, 0));
              switch (heff_tag_of(v_v1_24498)) {
              case TAG_HLocal: {
                V v_ru_24v1_24498_24HLocal = heff_take_reuse_n(v_v1_24498, 0ULL, 1);
                v_t_24510 = (g_heff_2eelab_2econversion_2ecanon_24tok1(v_ru_24v1_24498_24HLocal, heff_dup(v_x_2415)));
                break;
              }
              case TAG_HGlobal: {
                V v_ru_24v1_24498_24HGlobal = heff_take_reuse_n(v_v1_24498, 0ULL, 1);
                v_t_24510 = (g_heff_2eelab_2econversion_2ecanon_24tok1(v_ru_24v1_24498_24HGlobal, heff_dup(v_x_2415)));
                break;
              }
              case TAG_HMeta: {
                heff_take_n(v_v1_24498, 0ULL, 1);
                v_t_24510 = heff_dup(v_x_2415);
                break;
              }
              case TAG_HError: {
                v_t_24510 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
                break;
              }
              default: heff_nomatch(v_v1_24498);
              }
              break;
            }
            case TAG_VCode: {
              v_t_24510 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
              break;
            }
            case TAG_VLam: {
              v_t_24510 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
              break;
            }
            case TAG_VCons: {
              v_t_24510 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
              break;
            }
            case TAG_VOpaque: {
              v_t_24510 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
              break;
            }
            default: heff_nomatch(v_x_2415);
            }
            return ({ V a_0 = v_w_240; V a_1 = v_ms_241; V a_2 = v_uf_242; V a_3 = v_r_243; V a_4 = v_g_244; V a_5 = v_cs_245; V a_6 = v_t_24497; V a_7 = v_t_24510; V a_8 = v_x_2412; V a_9 = v_x_2415; V a_10 = v_hd_2410; V a_11 = v_k_2411; V r_ = (g_heff_2eelab_2eunify_2euElRigid(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9, a_10, a_11)); heff_drop(v_ms_241); r_; });
          }
          case TAG_Just: {
            V v_it1_24511 = heff_field(v_t_24484, 0);
            heff_take_n(v_t_24484, 1ULL, 1);
            heff_drop(v_ms_241);
            heff_drop(v_w_240);
            heff_drop(v_uf_242);
            switch (heff_tag_of(v_it1_24511)) {
            case TAG_MkPair: {
              V v_m_24512 = heff_field(v_it1_24511, 0);
              V v_sp_24513 = heff_field(v_it1_24511, 1);
              heff_take_n(v_it1_24511, 3ULL, 2);
              return heff_tail(heff_get_n(v_r_243, 3, 9), 8, (V[]){v_g_244, v_cs_245, v_m_24512, v_sp_24513, v_x_2412, v_x_2415, v_hd_2410, v_k_2411});
            }
            default: return heff_nomatch(v_it1_24511);
            }
          }
          default: return heff_nomatch(v_t_24484);
          }
        }
        case TAG_Just: {
          V v_it1_24514 = heff_field(v_t_24471, 0);
          heff_take_n(v_t_24471, 1ULL, 1);
          heff_drop(v_ms_241);
          heff_drop(v_w_240);
          heff_drop(v_uf_242);
          switch (heff_tag_of(v_it1_24514)) {
          case TAG_MkPair: {
            V v_m_24515 = heff_field(v_it1_24514, 0);
            V v_sp_24516 = heff_field(v_it1_24514, 1);
            heff_take_n(v_it1_24514, 3ULL, 2);
            return heff_tail(heff_get_n(v_r_243, 3, 9), 8, (V[]){v_g_244, v_cs_245, v_m_24515, v_sp_24516, v_x_2415, v_x_2412, v_hd_2410, v_k_2411});
          }
          default: return heff_nomatch(v_it1_24514);
          }
        }
        default: return heff_nomatch(v_t_24471);
        }
      }
      case TAG_VOpaque: {
        heff_drop_tag(v_x_2412, 1);
        heff_drop(v_ms_241);
        heff_drop(v_w_240);
        heff_drop(v_hd_2410);
        heff_drop_rec(v_cs_245, 2);
        heff_drop(v_uf_242);
        heff_drop_rec(v_r_243, 9);
        heff_drop(v_g_244);
        V f_ = v_k_2411;
        args[0] = NTAG(TAG_MkUnit);
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      }
      default: return heff_nomatch(v_x_2415);
      }
    }
    case TAG_VLam: {
      switch (heff_tag_of(v_x_2415)) {
      case TAG_VNeu: {
        V v_t_24536;
        switch (heff_tag_of(v_x_2412)) {
        case TAG_VNeu: {
          V v_v1_24524 = heff_dup(heff_field(v_x_2412, 0));
          V v_sp_24525 = heff_dup(heff_field(v_x_2412, 1));
          switch (heff_tag_of(v_v1_24524)) {
          case TAG_HLocal: {
            heff_take_n(v_v1_24524, 0ULL, 1);
            heff_drop(v_sp_24525);
            v_t_24536 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HGlobal: {
            heff_take_n(v_v1_24524, 0ULL, 1);
            heff_drop(v_sp_24525);
            v_t_24536 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HMeta: {
            V v_m_24531 = heff_field(v_v1_24524, 0);
            V v_ru_24v1_24524_24HMeta = heff_take_reuse_n(v_v1_24524, 1ULL, 1);
            v_t_24536 = heff_tag_at_n(v_ru_24v1_24524_24HMeta, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_m_24531, v_sp_24525})});
            break;
          }
          case TAG_HError: {
            heff_drop(v_sp_24525);
            v_t_24536 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_v1_24524);
          }
          break;
        }
        case TAG_VCode: {
          v_t_24536 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VLam: {
          v_t_24536 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VCons: {
          v_t_24536 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VOpaque: {
          v_t_24536 = NTAG(TAG_Nothing);
          break;
        }
        default: heff_nomatch(v_x_2412);
        }
        switch (heff_tag_of(v_t_24536)) {
        case TAG_Nothing: {
          V v_t_24549;
          switch (heff_tag_of(v_x_2415)) {
          case TAG_VNeu: {
            V v_v1_24537 = heff_dup(heff_field(v_x_2415, 0));
            V v_sp_24538 = heff_dup(heff_field(v_x_2415, 1));
            switch (heff_tag_of(v_v1_24537)) {
            case TAG_HLocal: {
              heff_take_n(v_v1_24537, 0ULL, 1);
              heff_drop(v_sp_24538);
              v_t_24549 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HGlobal: {
              heff_take_n(v_v1_24537, 0ULL, 1);
              heff_drop(v_sp_24538);
              v_t_24549 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HMeta: {
              V v_m_24544 = heff_field(v_v1_24537, 0);
              V v_ru_24v1_24537_24HMeta = heff_take_reuse_n(v_v1_24537, 1ULL, 1);
              v_t_24549 = heff_tag_at_n(v_ru_24v1_24537_24HMeta, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_m_24544, v_sp_24538})});
              break;
            }
            case TAG_HError: {
              heff_drop(v_sp_24538);
              v_t_24549 = NTAG(TAG_Nothing);
              break;
            }
            default: heff_nomatch(v_v1_24537);
            }
            break;
          }
          case TAG_VCode: {
            v_t_24549 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VLam: {
            v_t_24549 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VCons: {
            v_t_24549 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VOpaque: {
            v_t_24549 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_x_2415);
          }
          switch (heff_tag_of(v_t_24549)) {
          case TAG_Nothing: {
            V v_t_24562;
            switch (heff_tag_of(v_x_2412)) {
            case TAG_VNeu: {
              V v_v1_24550 = heff_dup(heff_field(v_x_2412, 0));
              switch (heff_tag_of(v_v1_24550)) {
              case TAG_HLocal: {
                V v_ru_24v1_24550_24HLocal = heff_take_reuse_n(v_v1_24550, 0ULL, 1);
                v_t_24562 = (g_heff_2eelab_2econversion_2ecanon_24tok1(v_ru_24v1_24550_24HLocal, heff_dup(v_x_2412)));
                break;
              }
              case TAG_HGlobal: {
                V v_ru_24v1_24550_24HGlobal = heff_take_reuse_n(v_v1_24550, 0ULL, 1);
                v_t_24562 = (g_heff_2eelab_2econversion_2ecanon_24tok1(v_ru_24v1_24550_24HGlobal, heff_dup(v_x_2412)));
                break;
              }
              case TAG_HMeta: {
                heff_take_n(v_v1_24550, 0ULL, 1);
                v_t_24562 = heff_dup(v_x_2412);
                break;
              }
              case TAG_HError: {
                v_t_24562 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
                break;
              }
              default: heff_nomatch(v_v1_24550);
              }
              break;
            }
            case TAG_VCode: {
              v_t_24562 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
              break;
            }
            case TAG_VLam: {
              v_t_24562 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
              break;
            }
            case TAG_VCons: {
              v_t_24562 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
              break;
            }
            case TAG_VOpaque: {
              v_t_24562 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
              break;
            }
            default: heff_nomatch(v_x_2412);
            }
            V v_t_24575;
            switch (heff_tag_of(v_x_2415)) {
            case TAG_VNeu: {
              V v_v1_24563 = heff_dup(heff_field(v_x_2415, 0));
              switch (heff_tag_of(v_v1_24563)) {
              case TAG_HLocal: {
                V v_ru_24v1_24563_24HLocal = heff_take_reuse_n(v_v1_24563, 0ULL, 1);
                v_t_24575 = (g_heff_2eelab_2econversion_2ecanon_24tok1(v_ru_24v1_24563_24HLocal, heff_dup(v_x_2415)));
                break;
              }
              case TAG_HGlobal: {
                V v_ru_24v1_24563_24HGlobal = heff_take_reuse_n(v_v1_24563, 0ULL, 1);
                v_t_24575 = (g_heff_2eelab_2econversion_2ecanon_24tok1(v_ru_24v1_24563_24HGlobal, heff_dup(v_x_2415)));
                break;
              }
              case TAG_HMeta: {
                heff_take_n(v_v1_24563, 0ULL, 1);
                v_t_24575 = heff_dup(v_x_2415);
                break;
              }
              case TAG_HError: {
                v_t_24575 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
                break;
              }
              default: heff_nomatch(v_v1_24563);
              }
              break;
            }
            case TAG_VCode: {
              v_t_24575 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
              break;
            }
            case TAG_VLam: {
              v_t_24575 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
              break;
            }
            case TAG_VCons: {
              v_t_24575 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
              break;
            }
            case TAG_VOpaque: {
              v_t_24575 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
              break;
            }
            default: heff_nomatch(v_x_2415);
            }
            return ({ V a_0 = v_w_240; V a_1 = v_ms_241; V a_2 = v_uf_242; V a_3 = v_r_243; V a_4 = v_g_244; V a_5 = v_cs_245; V a_6 = v_t_24562; V a_7 = v_t_24575; V a_8 = v_x_2412; V a_9 = v_x_2415; V a_10 = v_hd_2410; V a_11 = v_k_2411; V r_ = (g_heff_2eelab_2eunify_2euElRigid(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9, a_10, a_11)); heff_drop(v_ms_241); r_; });
          }
          case TAG_Just: {
            V v_it1_24576 = heff_field(v_t_24549, 0);
            heff_take_n(v_t_24549, 1ULL, 1);
            heff_drop(v_ms_241);
            heff_drop(v_w_240);
            heff_drop(v_uf_242);
            switch (heff_tag_of(v_it1_24576)) {
            case TAG_MkPair: {
              V v_m_24577 = heff_field(v_it1_24576, 0);
              V v_sp_24578 = heff_field(v_it1_24576, 1);
              heff_take_n(v_it1_24576, 3ULL, 2);
              return heff_tail(heff_get_n(v_r_243, 3, 9), 8, (V[]){v_g_244, v_cs_245, v_m_24577, v_sp_24578, v_x_2412, v_x_2415, v_hd_2410, v_k_2411});
            }
            default: return heff_nomatch(v_it1_24576);
            }
          }
          default: return heff_nomatch(v_t_24549);
          }
        }
        case TAG_Just: {
          V v_it1_24579 = heff_field(v_t_24536, 0);
          heff_take_n(v_t_24536, 1ULL, 1);
          heff_drop(v_ms_241);
          heff_drop(v_w_240);
          heff_drop(v_uf_242);
          switch (heff_tag_of(v_it1_24579)) {
          case TAG_MkPair: {
            V v_m_24580 = heff_field(v_it1_24579, 0);
            V v_sp_24581 = heff_field(v_it1_24579, 1);
            heff_take_n(v_it1_24579, 3ULL, 2);
            return heff_tail(heff_get_n(v_r_243, 3, 9), 8, (V[]){v_g_244, v_cs_245, v_m_24580, v_sp_24581, v_x_2415, v_x_2412, v_hd_2410, v_k_2411});
          }
          default: return heff_nomatch(v_it1_24579);
          }
        }
        default: return heff_nomatch(v_t_24536);
        }
      }
      case TAG_VCode: {
        V v_t_24595;
        switch (heff_tag_of(v_x_2412)) {
        case TAG_VNeu: {
          V v_v1_24583 = heff_dup(heff_field(v_x_2412, 0));
          V v_sp_24584 = heff_dup(heff_field(v_x_2412, 1));
          switch (heff_tag_of(v_v1_24583)) {
          case TAG_HLocal: {
            heff_take_n(v_v1_24583, 0ULL, 1);
            heff_drop(v_sp_24584);
            v_t_24595 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HGlobal: {
            heff_take_n(v_v1_24583, 0ULL, 1);
            heff_drop(v_sp_24584);
            v_t_24595 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HMeta: {
            V v_m_24590 = heff_field(v_v1_24583, 0);
            V v_ru_24v1_24583_24HMeta = heff_take_reuse_n(v_v1_24583, 1ULL, 1);
            v_t_24595 = heff_tag_at_n(v_ru_24v1_24583_24HMeta, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_m_24590, v_sp_24584})});
            break;
          }
          case TAG_HError: {
            heff_drop(v_sp_24584);
            v_t_24595 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_v1_24583);
          }
          break;
        }
        case TAG_VCode: {
          v_t_24595 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VLam: {
          v_t_24595 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VCons: {
          v_t_24595 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VOpaque: {
          v_t_24595 = NTAG(TAG_Nothing);
          break;
        }
        default: heff_nomatch(v_x_2412);
        }
        switch (heff_tag_of(v_t_24595)) {
        case TAG_Nothing: {
          V v_t_24608;
          switch (heff_tag_of(v_x_2415)) {
          case TAG_VNeu: {
            V v_v1_24596 = heff_dup(heff_field(v_x_2415, 0));
            V v_sp_24597 = heff_dup(heff_field(v_x_2415, 1));
            switch (heff_tag_of(v_v1_24596)) {
            case TAG_HLocal: {
              heff_take_n(v_v1_24596, 0ULL, 1);
              heff_drop(v_sp_24597);
              v_t_24608 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HGlobal: {
              heff_take_n(v_v1_24596, 0ULL, 1);
              heff_drop(v_sp_24597);
              v_t_24608 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HMeta: {
              V v_m_24603 = heff_field(v_v1_24596, 0);
              V v_ru_24v1_24596_24HMeta = heff_take_reuse_n(v_v1_24596, 1ULL, 1);
              v_t_24608 = heff_tag_at_n(v_ru_24v1_24596_24HMeta, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_m_24603, v_sp_24597})});
              break;
            }
            case TAG_HError: {
              heff_drop(v_sp_24597);
              v_t_24608 = NTAG(TAG_Nothing);
              break;
            }
            default: heff_nomatch(v_v1_24596);
            }
            break;
          }
          case TAG_VCode: {
            v_t_24608 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VLam: {
            v_t_24608 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VCons: {
            v_t_24608 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VOpaque: {
            v_t_24608 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_x_2415);
          }
          switch (heff_tag_of(v_t_24608)) {
          case TAG_Nothing: {
            V v_t_24621;
            switch (heff_tag_of(v_x_2412)) {
            case TAG_VNeu: {
              V v_v1_24609 = heff_dup(heff_field(v_x_2412, 0));
              switch (heff_tag_of(v_v1_24609)) {
              case TAG_HLocal: {
                V v_ru_24v1_24609_24HLocal = heff_take_reuse_n(v_v1_24609, 0ULL, 1);
                v_t_24621 = (g_heff_2eelab_2econversion_2ecanon_24tok1(v_ru_24v1_24609_24HLocal, heff_dup(v_x_2412)));
                break;
              }
              case TAG_HGlobal: {
                V v_ru_24v1_24609_24HGlobal = heff_take_reuse_n(v_v1_24609, 0ULL, 1);
                v_t_24621 = (g_heff_2eelab_2econversion_2ecanon_24tok1(v_ru_24v1_24609_24HGlobal, heff_dup(v_x_2412)));
                break;
              }
              case TAG_HMeta: {
                heff_take_n(v_v1_24609, 0ULL, 1);
                v_t_24621 = heff_dup(v_x_2412);
                break;
              }
              case TAG_HError: {
                v_t_24621 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
                break;
              }
              default: heff_nomatch(v_v1_24609);
              }
              break;
            }
            case TAG_VCode: {
              v_t_24621 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
              break;
            }
            case TAG_VLam: {
              v_t_24621 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
              break;
            }
            case TAG_VCons: {
              v_t_24621 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
              break;
            }
            case TAG_VOpaque: {
              v_t_24621 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
              break;
            }
            default: heff_nomatch(v_x_2412);
            }
            V v_t_24634;
            switch (heff_tag_of(v_x_2415)) {
            case TAG_VNeu: {
              V v_v1_24622 = heff_dup(heff_field(v_x_2415, 0));
              switch (heff_tag_of(v_v1_24622)) {
              case TAG_HLocal: {
                V v_ru_24v1_24622_24HLocal = heff_take_reuse_n(v_v1_24622, 0ULL, 1);
                v_t_24634 = (g_heff_2eelab_2econversion_2ecanon_24tok1(v_ru_24v1_24622_24HLocal, heff_dup(v_x_2415)));
                break;
              }
              case TAG_HGlobal: {
                V v_ru_24v1_24622_24HGlobal = heff_take_reuse_n(v_v1_24622, 0ULL, 1);
                v_t_24634 = (g_heff_2eelab_2econversion_2ecanon_24tok1(v_ru_24v1_24622_24HGlobal, heff_dup(v_x_2415)));
                break;
              }
              case TAG_HMeta: {
                heff_take_n(v_v1_24622, 0ULL, 1);
                v_t_24634 = heff_dup(v_x_2415);
                break;
              }
              case TAG_HError: {
                v_t_24634 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
                break;
              }
              default: heff_nomatch(v_v1_24622);
              }
              break;
            }
            case TAG_VCode: {
              v_t_24634 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
              break;
            }
            case TAG_VLam: {
              v_t_24634 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
              break;
            }
            case TAG_VCons: {
              v_t_24634 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
              break;
            }
            case TAG_VOpaque: {
              v_t_24634 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
              break;
            }
            default: heff_nomatch(v_x_2415);
            }
            return ({ V a_0 = v_w_240; V a_1 = v_ms_241; V a_2 = v_uf_242; V a_3 = v_r_243; V a_4 = v_g_244; V a_5 = v_cs_245; V a_6 = v_t_24621; V a_7 = v_t_24634; V a_8 = v_x_2412; V a_9 = v_x_2415; V a_10 = v_hd_2410; V a_11 = v_k_2411; V r_ = (g_heff_2eelab_2eunify_2euElRigid(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9, a_10, a_11)); heff_drop(v_ms_241); r_; });
          }
          case TAG_Just: {
            V v_it1_24635 = heff_field(v_t_24608, 0);
            heff_take_n(v_t_24608, 1ULL, 1);
            heff_drop(v_ms_241);
            heff_drop(v_w_240);
            heff_drop(v_uf_242);
            switch (heff_tag_of(v_it1_24635)) {
            case TAG_MkPair: {
              V v_m_24636 = heff_field(v_it1_24635, 0);
              V v_sp_24637 = heff_field(v_it1_24635, 1);
              heff_take_n(v_it1_24635, 3ULL, 2);
              return heff_tail(heff_get_n(v_r_243, 3, 9), 8, (V[]){v_g_244, v_cs_245, v_m_24636, v_sp_24637, v_x_2412, v_x_2415, v_hd_2410, v_k_2411});
            }
            default: return heff_nomatch(v_it1_24635);
            }
          }
          default: return heff_nomatch(v_t_24608);
          }
        }
        case TAG_Just: {
          V v_it1_24638 = heff_field(v_t_24595, 0);
          heff_take_n(v_t_24595, 1ULL, 1);
          heff_drop(v_ms_241);
          heff_drop(v_w_240);
          heff_drop(v_uf_242);
          switch (heff_tag_of(v_it1_24638)) {
          case TAG_MkPair: {
            V v_m_24639 = heff_field(v_it1_24638, 0);
            V v_sp_24640 = heff_field(v_it1_24638, 1);
            heff_take_n(v_it1_24638, 3ULL, 2);
            return heff_tail(heff_get_n(v_r_243, 3, 9), 8, (V[]){v_g_244, v_cs_245, v_m_24639, v_sp_24640, v_x_2415, v_x_2412, v_hd_2410, v_k_2411});
          }
          default: return heff_nomatch(v_it1_24638);
          }
        }
        default: return heff_nomatch(v_t_24595);
        }
      }
      case TAG_VLam: {
        V v_t_24655;
        switch (heff_tag_of(v_x_2412)) {
        case TAG_VNeu: {
          V v_v1_24643 = heff_dup(heff_field(v_x_2412, 0));
          V v_sp_24644 = heff_dup(heff_field(v_x_2412, 1));
          switch (heff_tag_of(v_v1_24643)) {
          case TAG_HLocal: {
            heff_take_n(v_v1_24643, 0ULL, 1);
            heff_drop(v_sp_24644);
            v_t_24655 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HGlobal: {
            heff_take_n(v_v1_24643, 0ULL, 1);
            heff_drop(v_sp_24644);
            v_t_24655 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HMeta: {
            V v_m_24650 = heff_field(v_v1_24643, 0);
            V v_ru_24v1_24643_24HMeta = heff_take_reuse_n(v_v1_24643, 1ULL, 1);
            v_t_24655 = heff_tag_at_n(v_ru_24v1_24643_24HMeta, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_m_24650, v_sp_24644})});
            break;
          }
          case TAG_HError: {
            heff_drop(v_sp_24644);
            v_t_24655 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_v1_24643);
          }
          break;
        }
        case TAG_VCode: {
          v_t_24655 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VLam: {
          v_t_24655 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VCons: {
          v_t_24655 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VOpaque: {
          v_t_24655 = NTAG(TAG_Nothing);
          break;
        }
        default: heff_nomatch(v_x_2412);
        }
        switch (heff_tag_of(v_t_24655)) {
        case TAG_Nothing: {
          V v_t_24668;
          switch (heff_tag_of(v_x_2415)) {
          case TAG_VNeu: {
            V v_v1_24656 = heff_dup(heff_field(v_x_2415, 0));
            V v_sp_24657 = heff_dup(heff_field(v_x_2415, 1));
            switch (heff_tag_of(v_v1_24656)) {
            case TAG_HLocal: {
              heff_take_n(v_v1_24656, 0ULL, 1);
              heff_drop(v_sp_24657);
              v_t_24668 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HGlobal: {
              heff_take_n(v_v1_24656, 0ULL, 1);
              heff_drop(v_sp_24657);
              v_t_24668 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HMeta: {
              V v_m_24663 = heff_field(v_v1_24656, 0);
              V v_ru_24v1_24656_24HMeta = heff_take_reuse_n(v_v1_24656, 1ULL, 1);
              v_t_24668 = heff_tag_at_n(v_ru_24v1_24656_24HMeta, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_m_24663, v_sp_24657})});
              break;
            }
            case TAG_HError: {
              heff_drop(v_sp_24657);
              v_t_24668 = NTAG(TAG_Nothing);
              break;
            }
            default: heff_nomatch(v_v1_24656);
            }
            break;
          }
          case TAG_VCode: {
            v_t_24668 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VLam: {
            v_t_24668 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VCons: {
            v_t_24668 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VOpaque: {
            v_t_24668 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_x_2415);
          }
          switch (heff_tag_of(v_t_24668)) {
          case TAG_Nothing: {
            V v_t_24681;
            switch (heff_tag_of(v_x_2412)) {
            case TAG_VNeu: {
              V v_v1_24669 = heff_dup(heff_field(v_x_2412, 0));
              switch (heff_tag_of(v_v1_24669)) {
              case TAG_HLocal: {
                V v_ru_24v1_24669_24HLocal = heff_take_reuse_n(v_v1_24669, 0ULL, 1);
                v_t_24681 = (g_heff_2eelab_2econversion_2ecanon_24tok1(v_ru_24v1_24669_24HLocal, heff_dup(v_x_2412)));
                break;
              }
              case TAG_HGlobal: {
                V v_ru_24v1_24669_24HGlobal = heff_take_reuse_n(v_v1_24669, 0ULL, 1);
                v_t_24681 = (g_heff_2eelab_2econversion_2ecanon_24tok1(v_ru_24v1_24669_24HGlobal, heff_dup(v_x_2412)));
                break;
              }
              case TAG_HMeta: {
                heff_take_n(v_v1_24669, 0ULL, 1);
                v_t_24681 = heff_dup(v_x_2412);
                break;
              }
              case TAG_HError: {
                v_t_24681 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
                break;
              }
              default: heff_nomatch(v_v1_24669);
              }
              break;
            }
            case TAG_VCode: {
              v_t_24681 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
              break;
            }
            case TAG_VLam: {
              v_t_24681 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
              break;
            }
            case TAG_VCons: {
              v_t_24681 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
              break;
            }
            case TAG_VOpaque: {
              v_t_24681 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
              break;
            }
            default: heff_nomatch(v_x_2412);
            }
            V v_t_24694;
            switch (heff_tag_of(v_x_2415)) {
            case TAG_VNeu: {
              V v_v1_24682 = heff_dup(heff_field(v_x_2415, 0));
              switch (heff_tag_of(v_v1_24682)) {
              case TAG_HLocal: {
                V v_ru_24v1_24682_24HLocal = heff_take_reuse_n(v_v1_24682, 0ULL, 1);
                v_t_24694 = (g_heff_2eelab_2econversion_2ecanon_24tok1(v_ru_24v1_24682_24HLocal, heff_dup(v_x_2415)));
                break;
              }
              case TAG_HGlobal: {
                V v_ru_24v1_24682_24HGlobal = heff_take_reuse_n(v_v1_24682, 0ULL, 1);
                v_t_24694 = (g_heff_2eelab_2econversion_2ecanon_24tok1(v_ru_24v1_24682_24HGlobal, heff_dup(v_x_2415)));
                break;
              }
              case TAG_HMeta: {
                heff_take_n(v_v1_24682, 0ULL, 1);
                v_t_24694 = heff_dup(v_x_2415);
                break;
              }
              case TAG_HError: {
                v_t_24694 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
                break;
              }
              default: heff_nomatch(v_v1_24682);
              }
              break;
            }
            case TAG_VCode: {
              v_t_24694 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
              break;
            }
            case TAG_VLam: {
              v_t_24694 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
              break;
            }
            case TAG_VCons: {
              v_t_24694 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
              break;
            }
            case TAG_VOpaque: {
              v_t_24694 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
              break;
            }
            default: heff_nomatch(v_x_2415);
            }
            return ({ V a_0 = v_w_240; V a_1 = v_ms_241; V a_2 = v_uf_242; V a_3 = v_r_243; V a_4 = v_g_244; V a_5 = v_cs_245; V a_6 = v_t_24681; V a_7 = v_t_24694; V a_8 = v_x_2412; V a_9 = v_x_2415; V a_10 = v_hd_2410; V a_11 = v_k_2411; V r_ = (g_heff_2eelab_2eunify_2euElRigid(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9, a_10, a_11)); heff_drop(v_ms_241); r_; });
          }
          case TAG_Just: {
            V v_it1_24695 = heff_field(v_t_24668, 0);
            heff_take_n(v_t_24668, 1ULL, 1);
            heff_drop(v_ms_241);
            heff_drop(v_w_240);
            heff_drop(v_uf_242);
            switch (heff_tag_of(v_it1_24695)) {
            case TAG_MkPair: {
              V v_m_24696 = heff_field(v_it1_24695, 0);
              V v_sp_24697 = heff_field(v_it1_24695, 1);
              heff_take_n(v_it1_24695, 3ULL, 2);
              return heff_tail(heff_get_n(v_r_243, 3, 9), 8, (V[]){v_g_244, v_cs_245, v_m_24696, v_sp_24697, v_x_2412, v_x_2415, v_hd_2410, v_k_2411});
            }
            default: return heff_nomatch(v_it1_24695);
            }
          }
          default: return heff_nomatch(v_t_24668);
          }
        }
        case TAG_Just: {
          V v_it1_24698 = heff_field(v_t_24655, 0);
          heff_take_n(v_t_24655, 1ULL, 1);
          heff_drop(v_ms_241);
          heff_drop(v_w_240);
          heff_drop(v_uf_242);
          switch (heff_tag_of(v_it1_24698)) {
          case TAG_MkPair: {
            V v_m_24699 = heff_field(v_it1_24698, 0);
            V v_sp_24700 = heff_field(v_it1_24698, 1);
            heff_take_n(v_it1_24698, 3ULL, 2);
            return heff_tail(heff_get_n(v_r_243, 3, 9), 8, (V[]){v_g_244, v_cs_245, v_m_24699, v_sp_24700, v_x_2415, v_x_2412, v_hd_2410, v_k_2411});
          }
          default: return heff_nomatch(v_it1_24698);
          }
        }
        default: return heff_nomatch(v_t_24655);
        }
      }
      case TAG_VCons: {
        V v_t_24714;
        switch (heff_tag_of(v_x_2412)) {
        case TAG_VNeu: {
          V v_v1_24702 = heff_dup(heff_field(v_x_2412, 0));
          V v_sp_24703 = heff_dup(heff_field(v_x_2412, 1));
          switch (heff_tag_of(v_v1_24702)) {
          case TAG_HLocal: {
            heff_take_n(v_v1_24702, 0ULL, 1);
            heff_drop(v_sp_24703);
            v_t_24714 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HGlobal: {
            heff_take_n(v_v1_24702, 0ULL, 1);
            heff_drop(v_sp_24703);
            v_t_24714 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HMeta: {
            V v_m_24709 = heff_field(v_v1_24702, 0);
            V v_ru_24v1_24702_24HMeta = heff_take_reuse_n(v_v1_24702, 1ULL, 1);
            v_t_24714 = heff_tag_at_n(v_ru_24v1_24702_24HMeta, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_m_24709, v_sp_24703})});
            break;
          }
          case TAG_HError: {
            heff_drop(v_sp_24703);
            v_t_24714 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_v1_24702);
          }
          break;
        }
        case TAG_VCode: {
          v_t_24714 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VLam: {
          v_t_24714 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VCons: {
          v_t_24714 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VOpaque: {
          v_t_24714 = NTAG(TAG_Nothing);
          break;
        }
        default: heff_nomatch(v_x_2412);
        }
        switch (heff_tag_of(v_t_24714)) {
        case TAG_Nothing: {
          V v_t_24727;
          switch (heff_tag_of(v_x_2415)) {
          case TAG_VNeu: {
            V v_v1_24715 = heff_dup(heff_field(v_x_2415, 0));
            V v_sp_24716 = heff_dup(heff_field(v_x_2415, 1));
            switch (heff_tag_of(v_v1_24715)) {
            case TAG_HLocal: {
              heff_take_n(v_v1_24715, 0ULL, 1);
              heff_drop(v_sp_24716);
              v_t_24727 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HGlobal: {
              heff_take_n(v_v1_24715, 0ULL, 1);
              heff_drop(v_sp_24716);
              v_t_24727 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HMeta: {
              V v_m_24722 = heff_field(v_v1_24715, 0);
              V v_ru_24v1_24715_24HMeta = heff_take_reuse_n(v_v1_24715, 1ULL, 1);
              v_t_24727 = heff_tag_at_n(v_ru_24v1_24715_24HMeta, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_m_24722, v_sp_24716})});
              break;
            }
            case TAG_HError: {
              heff_drop(v_sp_24716);
              v_t_24727 = NTAG(TAG_Nothing);
              break;
            }
            default: heff_nomatch(v_v1_24715);
            }
            break;
          }
          case TAG_VCode: {
            v_t_24727 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VLam: {
            v_t_24727 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VCons: {
            v_t_24727 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VOpaque: {
            v_t_24727 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_x_2415);
          }
          switch (heff_tag_of(v_t_24727)) {
          case TAG_Nothing: {
            V v_t_24740;
            switch (heff_tag_of(v_x_2412)) {
            case TAG_VNeu: {
              V v_v1_24728 = heff_dup(heff_field(v_x_2412, 0));
              switch (heff_tag_of(v_v1_24728)) {
              case TAG_HLocal: {
                V v_ru_24v1_24728_24HLocal = heff_take_reuse_n(v_v1_24728, 0ULL, 1);
                v_t_24740 = (g_heff_2eelab_2econversion_2ecanon_24tok1(v_ru_24v1_24728_24HLocal, heff_dup(v_x_2412)));
                break;
              }
              case TAG_HGlobal: {
                V v_ru_24v1_24728_24HGlobal = heff_take_reuse_n(v_v1_24728, 0ULL, 1);
                v_t_24740 = (g_heff_2eelab_2econversion_2ecanon_24tok1(v_ru_24v1_24728_24HGlobal, heff_dup(v_x_2412)));
                break;
              }
              case TAG_HMeta: {
                heff_take_n(v_v1_24728, 0ULL, 1);
                v_t_24740 = heff_dup(v_x_2412);
                break;
              }
              case TAG_HError: {
                v_t_24740 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
                break;
              }
              default: heff_nomatch(v_v1_24728);
              }
              break;
            }
            case TAG_VCode: {
              v_t_24740 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
              break;
            }
            case TAG_VLam: {
              v_t_24740 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
              break;
            }
            case TAG_VCons: {
              v_t_24740 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
              break;
            }
            case TAG_VOpaque: {
              v_t_24740 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
              break;
            }
            default: heff_nomatch(v_x_2412);
            }
            V v_t_24753;
            switch (heff_tag_of(v_x_2415)) {
            case TAG_VNeu: {
              V v_v1_24741 = heff_dup(heff_field(v_x_2415, 0));
              switch (heff_tag_of(v_v1_24741)) {
              case TAG_HLocal: {
                V v_ru_24v1_24741_24HLocal = heff_take_reuse_n(v_v1_24741, 0ULL, 1);
                v_t_24753 = (g_heff_2eelab_2econversion_2ecanon_24tok1(v_ru_24v1_24741_24HLocal, heff_dup(v_x_2415)));
                break;
              }
              case TAG_HGlobal: {
                V v_ru_24v1_24741_24HGlobal = heff_take_reuse_n(v_v1_24741, 0ULL, 1);
                v_t_24753 = (g_heff_2eelab_2econversion_2ecanon_24tok1(v_ru_24v1_24741_24HGlobal, heff_dup(v_x_2415)));
                break;
              }
              case TAG_HMeta: {
                heff_take_n(v_v1_24741, 0ULL, 1);
                v_t_24753 = heff_dup(v_x_2415);
                break;
              }
              case TAG_HError: {
                v_t_24753 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
                break;
              }
              default: heff_nomatch(v_v1_24741);
              }
              break;
            }
            case TAG_VCode: {
              v_t_24753 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
              break;
            }
            case TAG_VLam: {
              v_t_24753 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
              break;
            }
            case TAG_VCons: {
              v_t_24753 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
              break;
            }
            case TAG_VOpaque: {
              v_t_24753 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
              break;
            }
            default: heff_nomatch(v_x_2415);
            }
            return ({ V a_0 = v_w_240; V a_1 = v_ms_241; V a_2 = v_uf_242; V a_3 = v_r_243; V a_4 = v_g_244; V a_5 = v_cs_245; V a_6 = v_t_24740; V a_7 = v_t_24753; V a_8 = v_x_2412; V a_9 = v_x_2415; V a_10 = v_hd_2410; V a_11 = v_k_2411; V r_ = (g_heff_2eelab_2eunify_2euElRigid(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9, a_10, a_11)); heff_drop(v_ms_241); r_; });
          }
          case TAG_Just: {
            V v_it1_24754 = heff_field(v_t_24727, 0);
            heff_take_n(v_t_24727, 1ULL, 1);
            heff_drop(v_ms_241);
            heff_drop(v_w_240);
            heff_drop(v_uf_242);
            switch (heff_tag_of(v_it1_24754)) {
            case TAG_MkPair: {
              V v_m_24755 = heff_field(v_it1_24754, 0);
              V v_sp_24756 = heff_field(v_it1_24754, 1);
              heff_take_n(v_it1_24754, 3ULL, 2);
              return heff_tail(heff_get_n(v_r_243, 3, 9), 8, (V[]){v_g_244, v_cs_245, v_m_24755, v_sp_24756, v_x_2412, v_x_2415, v_hd_2410, v_k_2411});
            }
            default: return heff_nomatch(v_it1_24754);
            }
          }
          default: return heff_nomatch(v_t_24727);
          }
        }
        case TAG_Just: {
          V v_it1_24757 = heff_field(v_t_24714, 0);
          heff_take_n(v_t_24714, 1ULL, 1);
          heff_drop(v_ms_241);
          heff_drop(v_w_240);
          heff_drop(v_uf_242);
          switch (heff_tag_of(v_it1_24757)) {
          case TAG_MkPair: {
            V v_m_24758 = heff_field(v_it1_24757, 0);
            V v_sp_24759 = heff_field(v_it1_24757, 1);
            heff_take_n(v_it1_24757, 3ULL, 2);
            return heff_tail(heff_get_n(v_r_243, 3, 9), 8, (V[]){v_g_244, v_cs_245, v_m_24758, v_sp_24759, v_x_2415, v_x_2412, v_hd_2410, v_k_2411});
          }
          default: return heff_nomatch(v_it1_24757);
          }
        }
        default: return heff_nomatch(v_t_24714);
        }
      }
      case TAG_VOpaque: {
        heff_drop_tag(v_x_2412, 2);
        heff_drop(v_ms_241);
        heff_drop(v_w_240);
        heff_drop(v_hd_2410);
        heff_drop_rec(v_cs_245, 2);
        heff_drop(v_uf_242);
        heff_drop_rec(v_r_243, 9);
        heff_drop(v_g_244);
        V f_ = v_k_2411;
        args[0] = NTAG(TAG_MkUnit);
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      }
      default: return heff_nomatch(v_x_2415);
      }
    }
    case TAG_VCons: {
      switch (heff_tag_of(v_x_2415)) {
      case TAG_VNeu: {
        V v_t_24778;
        switch (heff_tag_of(v_x_2412)) {
        case TAG_VNeu: {
          V v_v1_24766 = heff_dup(heff_field(v_x_2412, 0));
          V v_sp_24767 = heff_dup(heff_field(v_x_2412, 1));
          switch (heff_tag_of(v_v1_24766)) {
          case TAG_HLocal: {
            heff_take_n(v_v1_24766, 0ULL, 1);
            heff_drop(v_sp_24767);
            v_t_24778 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HGlobal: {
            heff_take_n(v_v1_24766, 0ULL, 1);
            heff_drop(v_sp_24767);
            v_t_24778 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HMeta: {
            V v_m_24773 = heff_field(v_v1_24766, 0);
            V v_ru_24v1_24766_24HMeta = heff_take_reuse_n(v_v1_24766, 1ULL, 1);
            v_t_24778 = heff_tag_at_n(v_ru_24v1_24766_24HMeta, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_m_24773, v_sp_24767})});
            break;
          }
          case TAG_HError: {
            heff_drop(v_sp_24767);
            v_t_24778 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_v1_24766);
          }
          break;
        }
        case TAG_VCode: {
          v_t_24778 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VLam: {
          v_t_24778 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VCons: {
          v_t_24778 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VOpaque: {
          v_t_24778 = NTAG(TAG_Nothing);
          break;
        }
        default: heff_nomatch(v_x_2412);
        }
        switch (heff_tag_of(v_t_24778)) {
        case TAG_Nothing: {
          V v_t_24791;
          switch (heff_tag_of(v_x_2415)) {
          case TAG_VNeu: {
            V v_v1_24779 = heff_dup(heff_field(v_x_2415, 0));
            V v_sp_24780 = heff_dup(heff_field(v_x_2415, 1));
            switch (heff_tag_of(v_v1_24779)) {
            case TAG_HLocal: {
              heff_take_n(v_v1_24779, 0ULL, 1);
              heff_drop(v_sp_24780);
              v_t_24791 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HGlobal: {
              heff_take_n(v_v1_24779, 0ULL, 1);
              heff_drop(v_sp_24780);
              v_t_24791 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HMeta: {
              V v_m_24786 = heff_field(v_v1_24779, 0);
              V v_ru_24v1_24779_24HMeta = heff_take_reuse_n(v_v1_24779, 1ULL, 1);
              v_t_24791 = heff_tag_at_n(v_ru_24v1_24779_24HMeta, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_m_24786, v_sp_24780})});
              break;
            }
            case TAG_HError: {
              heff_drop(v_sp_24780);
              v_t_24791 = NTAG(TAG_Nothing);
              break;
            }
            default: heff_nomatch(v_v1_24779);
            }
            break;
          }
          case TAG_VCode: {
            v_t_24791 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VLam: {
            v_t_24791 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VCons: {
            v_t_24791 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VOpaque: {
            v_t_24791 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_x_2415);
          }
          switch (heff_tag_of(v_t_24791)) {
          case TAG_Nothing: {
            V v_t_24804;
            switch (heff_tag_of(v_x_2412)) {
            case TAG_VNeu: {
              V v_v1_24792 = heff_dup(heff_field(v_x_2412, 0));
              switch (heff_tag_of(v_v1_24792)) {
              case TAG_HLocal: {
                V v_ru_24v1_24792_24HLocal = heff_take_reuse_n(v_v1_24792, 0ULL, 1);
                v_t_24804 = (g_heff_2eelab_2econversion_2ecanon_24tok1(v_ru_24v1_24792_24HLocal, heff_dup(v_x_2412)));
                break;
              }
              case TAG_HGlobal: {
                V v_ru_24v1_24792_24HGlobal = heff_take_reuse_n(v_v1_24792, 0ULL, 1);
                v_t_24804 = (g_heff_2eelab_2econversion_2ecanon_24tok1(v_ru_24v1_24792_24HGlobal, heff_dup(v_x_2412)));
                break;
              }
              case TAG_HMeta: {
                heff_take_n(v_v1_24792, 0ULL, 1);
                v_t_24804 = heff_dup(v_x_2412);
                break;
              }
              case TAG_HError: {
                v_t_24804 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
                break;
              }
              default: heff_nomatch(v_v1_24792);
              }
              break;
            }
            case TAG_VCode: {
              v_t_24804 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
              break;
            }
            case TAG_VLam: {
              v_t_24804 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
              break;
            }
            case TAG_VCons: {
              v_t_24804 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
              break;
            }
            case TAG_VOpaque: {
              v_t_24804 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
              break;
            }
            default: heff_nomatch(v_x_2412);
            }
            V v_t_24817;
            switch (heff_tag_of(v_x_2415)) {
            case TAG_VNeu: {
              V v_v1_24805 = heff_dup(heff_field(v_x_2415, 0));
              switch (heff_tag_of(v_v1_24805)) {
              case TAG_HLocal: {
                V v_ru_24v1_24805_24HLocal = heff_take_reuse_n(v_v1_24805, 0ULL, 1);
                v_t_24817 = (g_heff_2eelab_2econversion_2ecanon_24tok1(v_ru_24v1_24805_24HLocal, heff_dup(v_x_2415)));
                break;
              }
              case TAG_HGlobal: {
                V v_ru_24v1_24805_24HGlobal = heff_take_reuse_n(v_v1_24805, 0ULL, 1);
                v_t_24817 = (g_heff_2eelab_2econversion_2ecanon_24tok1(v_ru_24v1_24805_24HGlobal, heff_dup(v_x_2415)));
                break;
              }
              case TAG_HMeta: {
                heff_take_n(v_v1_24805, 0ULL, 1);
                v_t_24817 = heff_dup(v_x_2415);
                break;
              }
              case TAG_HError: {
                v_t_24817 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
                break;
              }
              default: heff_nomatch(v_v1_24805);
              }
              break;
            }
            case TAG_VCode: {
              v_t_24817 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
              break;
            }
            case TAG_VLam: {
              v_t_24817 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
              break;
            }
            case TAG_VCons: {
              v_t_24817 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
              break;
            }
            case TAG_VOpaque: {
              v_t_24817 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
              break;
            }
            default: heff_nomatch(v_x_2415);
            }
            return ({ V a_0 = v_w_240; V a_1 = v_ms_241; V a_2 = v_uf_242; V a_3 = v_r_243; V a_4 = v_g_244; V a_5 = v_cs_245; V a_6 = v_t_24804; V a_7 = v_t_24817; V a_8 = v_x_2412; V a_9 = v_x_2415; V a_10 = v_hd_2410; V a_11 = v_k_2411; V r_ = (g_heff_2eelab_2eunify_2euElRigid(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9, a_10, a_11)); heff_drop(v_ms_241); r_; });
          }
          case TAG_Just: {
            V v_it1_24818 = heff_field(v_t_24791, 0);
            heff_take_n(v_t_24791, 1ULL, 1);
            heff_drop(v_ms_241);
            heff_drop(v_w_240);
            heff_drop(v_uf_242);
            switch (heff_tag_of(v_it1_24818)) {
            case TAG_MkPair: {
              V v_m_24819 = heff_field(v_it1_24818, 0);
              V v_sp_24820 = heff_field(v_it1_24818, 1);
              heff_take_n(v_it1_24818, 3ULL, 2);
              return heff_tail(heff_get_n(v_r_243, 3, 9), 8, (V[]){v_g_244, v_cs_245, v_m_24819, v_sp_24820, v_x_2412, v_x_2415, v_hd_2410, v_k_2411});
            }
            default: return heff_nomatch(v_it1_24818);
            }
          }
          default: return heff_nomatch(v_t_24791);
          }
        }
        case TAG_Just: {
          V v_it1_24821 = heff_field(v_t_24778, 0);
          heff_take_n(v_t_24778, 1ULL, 1);
          heff_drop(v_ms_241);
          heff_drop(v_w_240);
          heff_drop(v_uf_242);
          switch (heff_tag_of(v_it1_24821)) {
          case TAG_MkPair: {
            V v_m_24822 = heff_field(v_it1_24821, 0);
            V v_sp_24823 = heff_field(v_it1_24821, 1);
            heff_take_n(v_it1_24821, 3ULL, 2);
            return heff_tail(heff_get_n(v_r_243, 3, 9), 8, (V[]){v_g_244, v_cs_245, v_m_24822, v_sp_24823, v_x_2415, v_x_2412, v_hd_2410, v_k_2411});
          }
          default: return heff_nomatch(v_it1_24821);
          }
        }
        default: return heff_nomatch(v_t_24778);
        }
      }
      case TAG_VCode: {
        V v_t_24837;
        switch (heff_tag_of(v_x_2412)) {
        case TAG_VNeu: {
          V v_v1_24825 = heff_dup(heff_field(v_x_2412, 0));
          V v_sp_24826 = heff_dup(heff_field(v_x_2412, 1));
          switch (heff_tag_of(v_v1_24825)) {
          case TAG_HLocal: {
            heff_take_n(v_v1_24825, 0ULL, 1);
            heff_drop(v_sp_24826);
            v_t_24837 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HGlobal: {
            heff_take_n(v_v1_24825, 0ULL, 1);
            heff_drop(v_sp_24826);
            v_t_24837 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HMeta: {
            V v_m_24832 = heff_field(v_v1_24825, 0);
            V v_ru_24v1_24825_24HMeta = heff_take_reuse_n(v_v1_24825, 1ULL, 1);
            v_t_24837 = heff_tag_at_n(v_ru_24v1_24825_24HMeta, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_m_24832, v_sp_24826})});
            break;
          }
          case TAG_HError: {
            heff_drop(v_sp_24826);
            v_t_24837 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_v1_24825);
          }
          break;
        }
        case TAG_VCode: {
          v_t_24837 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VLam: {
          v_t_24837 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VCons: {
          v_t_24837 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VOpaque: {
          v_t_24837 = NTAG(TAG_Nothing);
          break;
        }
        default: heff_nomatch(v_x_2412);
        }
        switch (heff_tag_of(v_t_24837)) {
        case TAG_Nothing: {
          V v_t_24850;
          switch (heff_tag_of(v_x_2415)) {
          case TAG_VNeu: {
            V v_v1_24838 = heff_dup(heff_field(v_x_2415, 0));
            V v_sp_24839 = heff_dup(heff_field(v_x_2415, 1));
            switch (heff_tag_of(v_v1_24838)) {
            case TAG_HLocal: {
              heff_take_n(v_v1_24838, 0ULL, 1);
              heff_drop(v_sp_24839);
              v_t_24850 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HGlobal: {
              heff_take_n(v_v1_24838, 0ULL, 1);
              heff_drop(v_sp_24839);
              v_t_24850 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HMeta: {
              V v_m_24845 = heff_field(v_v1_24838, 0);
              V v_ru_24v1_24838_24HMeta = heff_take_reuse_n(v_v1_24838, 1ULL, 1);
              v_t_24850 = heff_tag_at_n(v_ru_24v1_24838_24HMeta, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_m_24845, v_sp_24839})});
              break;
            }
            case TAG_HError: {
              heff_drop(v_sp_24839);
              v_t_24850 = NTAG(TAG_Nothing);
              break;
            }
            default: heff_nomatch(v_v1_24838);
            }
            break;
          }
          case TAG_VCode: {
            v_t_24850 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VLam: {
            v_t_24850 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VCons: {
            v_t_24850 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VOpaque: {
            v_t_24850 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_x_2415);
          }
          switch (heff_tag_of(v_t_24850)) {
          case TAG_Nothing: {
            V v_t_24863;
            switch (heff_tag_of(v_x_2412)) {
            case TAG_VNeu: {
              V v_v1_24851 = heff_dup(heff_field(v_x_2412, 0));
              switch (heff_tag_of(v_v1_24851)) {
              case TAG_HLocal: {
                V v_ru_24v1_24851_24HLocal = heff_take_reuse_n(v_v1_24851, 0ULL, 1);
                v_t_24863 = (g_heff_2eelab_2econversion_2ecanon_24tok1(v_ru_24v1_24851_24HLocal, heff_dup(v_x_2412)));
                break;
              }
              case TAG_HGlobal: {
                V v_ru_24v1_24851_24HGlobal = heff_take_reuse_n(v_v1_24851, 0ULL, 1);
                v_t_24863 = (g_heff_2eelab_2econversion_2ecanon_24tok1(v_ru_24v1_24851_24HGlobal, heff_dup(v_x_2412)));
                break;
              }
              case TAG_HMeta: {
                heff_take_n(v_v1_24851, 0ULL, 1);
                v_t_24863 = heff_dup(v_x_2412);
                break;
              }
              case TAG_HError: {
                v_t_24863 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
                break;
              }
              default: heff_nomatch(v_v1_24851);
              }
              break;
            }
            case TAG_VCode: {
              v_t_24863 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
              break;
            }
            case TAG_VLam: {
              v_t_24863 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
              break;
            }
            case TAG_VCons: {
              v_t_24863 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
              break;
            }
            case TAG_VOpaque: {
              v_t_24863 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
              break;
            }
            default: heff_nomatch(v_x_2412);
            }
            V v_t_24876;
            switch (heff_tag_of(v_x_2415)) {
            case TAG_VNeu: {
              V v_v1_24864 = heff_dup(heff_field(v_x_2415, 0));
              switch (heff_tag_of(v_v1_24864)) {
              case TAG_HLocal: {
                V v_ru_24v1_24864_24HLocal = heff_take_reuse_n(v_v1_24864, 0ULL, 1);
                v_t_24876 = (g_heff_2eelab_2econversion_2ecanon_24tok1(v_ru_24v1_24864_24HLocal, heff_dup(v_x_2415)));
                break;
              }
              case TAG_HGlobal: {
                V v_ru_24v1_24864_24HGlobal = heff_take_reuse_n(v_v1_24864, 0ULL, 1);
                v_t_24876 = (g_heff_2eelab_2econversion_2ecanon_24tok1(v_ru_24v1_24864_24HGlobal, heff_dup(v_x_2415)));
                break;
              }
              case TAG_HMeta: {
                heff_take_n(v_v1_24864, 0ULL, 1);
                v_t_24876 = heff_dup(v_x_2415);
                break;
              }
              case TAG_HError: {
                v_t_24876 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
                break;
              }
              default: heff_nomatch(v_v1_24864);
              }
              break;
            }
            case TAG_VCode: {
              v_t_24876 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
              break;
            }
            case TAG_VLam: {
              v_t_24876 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
              break;
            }
            case TAG_VCons: {
              v_t_24876 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
              break;
            }
            case TAG_VOpaque: {
              v_t_24876 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
              break;
            }
            default: heff_nomatch(v_x_2415);
            }
            return ({ V a_0 = v_w_240; V a_1 = v_ms_241; V a_2 = v_uf_242; V a_3 = v_r_243; V a_4 = v_g_244; V a_5 = v_cs_245; V a_6 = v_t_24863; V a_7 = v_t_24876; V a_8 = v_x_2412; V a_9 = v_x_2415; V a_10 = v_hd_2410; V a_11 = v_k_2411; V r_ = (g_heff_2eelab_2eunify_2euElRigid(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9, a_10, a_11)); heff_drop(v_ms_241); r_; });
          }
          case TAG_Just: {
            V v_it1_24877 = heff_field(v_t_24850, 0);
            heff_take_n(v_t_24850, 1ULL, 1);
            heff_drop(v_ms_241);
            heff_drop(v_w_240);
            heff_drop(v_uf_242);
            switch (heff_tag_of(v_it1_24877)) {
            case TAG_MkPair: {
              V v_m_24878 = heff_field(v_it1_24877, 0);
              V v_sp_24879 = heff_field(v_it1_24877, 1);
              heff_take_n(v_it1_24877, 3ULL, 2);
              return heff_tail(heff_get_n(v_r_243, 3, 9), 8, (V[]){v_g_244, v_cs_245, v_m_24878, v_sp_24879, v_x_2412, v_x_2415, v_hd_2410, v_k_2411});
            }
            default: return heff_nomatch(v_it1_24877);
            }
          }
          default: return heff_nomatch(v_t_24850);
          }
        }
        case TAG_Just: {
          V v_it1_24880 = heff_field(v_t_24837, 0);
          heff_take_n(v_t_24837, 1ULL, 1);
          heff_drop(v_ms_241);
          heff_drop(v_w_240);
          heff_drop(v_uf_242);
          switch (heff_tag_of(v_it1_24880)) {
          case TAG_MkPair: {
            V v_m_24881 = heff_field(v_it1_24880, 0);
            V v_sp_24882 = heff_field(v_it1_24880, 1);
            heff_take_n(v_it1_24880, 3ULL, 2);
            return heff_tail(heff_get_n(v_r_243, 3, 9), 8, (V[]){v_g_244, v_cs_245, v_m_24881, v_sp_24882, v_x_2415, v_x_2412, v_hd_2410, v_k_2411});
          }
          default: return heff_nomatch(v_it1_24880);
          }
        }
        default: return heff_nomatch(v_t_24837);
        }
      }
      case TAG_VLam: {
        V v_t_24897;
        switch (heff_tag_of(v_x_2412)) {
        case TAG_VNeu: {
          V v_v1_24885 = heff_dup(heff_field(v_x_2412, 0));
          V v_sp_24886 = heff_dup(heff_field(v_x_2412, 1));
          switch (heff_tag_of(v_v1_24885)) {
          case TAG_HLocal: {
            heff_take_n(v_v1_24885, 0ULL, 1);
            heff_drop(v_sp_24886);
            v_t_24897 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HGlobal: {
            heff_take_n(v_v1_24885, 0ULL, 1);
            heff_drop(v_sp_24886);
            v_t_24897 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HMeta: {
            V v_m_24892 = heff_field(v_v1_24885, 0);
            V v_ru_24v1_24885_24HMeta = heff_take_reuse_n(v_v1_24885, 1ULL, 1);
            v_t_24897 = heff_tag_at_n(v_ru_24v1_24885_24HMeta, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_m_24892, v_sp_24886})});
            break;
          }
          case TAG_HError: {
            heff_drop(v_sp_24886);
            v_t_24897 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_v1_24885);
          }
          break;
        }
        case TAG_VCode: {
          v_t_24897 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VLam: {
          v_t_24897 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VCons: {
          v_t_24897 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VOpaque: {
          v_t_24897 = NTAG(TAG_Nothing);
          break;
        }
        default: heff_nomatch(v_x_2412);
        }
        switch (heff_tag_of(v_t_24897)) {
        case TAG_Nothing: {
          V v_t_24910;
          switch (heff_tag_of(v_x_2415)) {
          case TAG_VNeu: {
            V v_v1_24898 = heff_dup(heff_field(v_x_2415, 0));
            V v_sp_24899 = heff_dup(heff_field(v_x_2415, 1));
            switch (heff_tag_of(v_v1_24898)) {
            case TAG_HLocal: {
              heff_take_n(v_v1_24898, 0ULL, 1);
              heff_drop(v_sp_24899);
              v_t_24910 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HGlobal: {
              heff_take_n(v_v1_24898, 0ULL, 1);
              heff_drop(v_sp_24899);
              v_t_24910 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HMeta: {
              V v_m_24905 = heff_field(v_v1_24898, 0);
              V v_ru_24v1_24898_24HMeta = heff_take_reuse_n(v_v1_24898, 1ULL, 1);
              v_t_24910 = heff_tag_at_n(v_ru_24v1_24898_24HMeta, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_m_24905, v_sp_24899})});
              break;
            }
            case TAG_HError: {
              heff_drop(v_sp_24899);
              v_t_24910 = NTAG(TAG_Nothing);
              break;
            }
            default: heff_nomatch(v_v1_24898);
            }
            break;
          }
          case TAG_VCode: {
            v_t_24910 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VLam: {
            v_t_24910 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VCons: {
            v_t_24910 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VOpaque: {
            v_t_24910 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_x_2415);
          }
          switch (heff_tag_of(v_t_24910)) {
          case TAG_Nothing: {
            V v_t_24923;
            switch (heff_tag_of(v_x_2412)) {
            case TAG_VNeu: {
              V v_v1_24911 = heff_dup(heff_field(v_x_2412, 0));
              switch (heff_tag_of(v_v1_24911)) {
              case TAG_HLocal: {
                V v_ru_24v1_24911_24HLocal = heff_take_reuse_n(v_v1_24911, 0ULL, 1);
                v_t_24923 = (g_heff_2eelab_2econversion_2ecanon_24tok1(v_ru_24v1_24911_24HLocal, heff_dup(v_x_2412)));
                break;
              }
              case TAG_HGlobal: {
                V v_ru_24v1_24911_24HGlobal = heff_take_reuse_n(v_v1_24911, 0ULL, 1);
                v_t_24923 = (g_heff_2eelab_2econversion_2ecanon_24tok1(v_ru_24v1_24911_24HGlobal, heff_dup(v_x_2412)));
                break;
              }
              case TAG_HMeta: {
                heff_take_n(v_v1_24911, 0ULL, 1);
                v_t_24923 = heff_dup(v_x_2412);
                break;
              }
              case TAG_HError: {
                v_t_24923 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
                break;
              }
              default: heff_nomatch(v_v1_24911);
              }
              break;
            }
            case TAG_VCode: {
              v_t_24923 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
              break;
            }
            case TAG_VLam: {
              v_t_24923 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
              break;
            }
            case TAG_VCons: {
              v_t_24923 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
              break;
            }
            case TAG_VOpaque: {
              v_t_24923 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
              break;
            }
            default: heff_nomatch(v_x_2412);
            }
            V v_t_24936;
            switch (heff_tag_of(v_x_2415)) {
            case TAG_VNeu: {
              V v_v1_24924 = heff_dup(heff_field(v_x_2415, 0));
              switch (heff_tag_of(v_v1_24924)) {
              case TAG_HLocal: {
                V v_ru_24v1_24924_24HLocal = heff_take_reuse_n(v_v1_24924, 0ULL, 1);
                v_t_24936 = (g_heff_2eelab_2econversion_2ecanon_24tok1(v_ru_24v1_24924_24HLocal, heff_dup(v_x_2415)));
                break;
              }
              case TAG_HGlobal: {
                V v_ru_24v1_24924_24HGlobal = heff_take_reuse_n(v_v1_24924, 0ULL, 1);
                v_t_24936 = (g_heff_2eelab_2econversion_2ecanon_24tok1(v_ru_24v1_24924_24HGlobal, heff_dup(v_x_2415)));
                break;
              }
              case TAG_HMeta: {
                heff_take_n(v_v1_24924, 0ULL, 1);
                v_t_24936 = heff_dup(v_x_2415);
                break;
              }
              case TAG_HError: {
                v_t_24936 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
                break;
              }
              default: heff_nomatch(v_v1_24924);
              }
              break;
            }
            case TAG_VCode: {
              v_t_24936 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
              break;
            }
            case TAG_VLam: {
              v_t_24936 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
              break;
            }
            case TAG_VCons: {
              v_t_24936 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
              break;
            }
            case TAG_VOpaque: {
              v_t_24936 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
              break;
            }
            default: heff_nomatch(v_x_2415);
            }
            return ({ V a_0 = v_w_240; V a_1 = v_ms_241; V a_2 = v_uf_242; V a_3 = v_r_243; V a_4 = v_g_244; V a_5 = v_cs_245; V a_6 = v_t_24923; V a_7 = v_t_24936; V a_8 = v_x_2412; V a_9 = v_x_2415; V a_10 = v_hd_2410; V a_11 = v_k_2411; V r_ = (g_heff_2eelab_2eunify_2euElRigid(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9, a_10, a_11)); heff_drop(v_ms_241); r_; });
          }
          case TAG_Just: {
            V v_it1_24937 = heff_field(v_t_24910, 0);
            heff_take_n(v_t_24910, 1ULL, 1);
            heff_drop(v_ms_241);
            heff_drop(v_w_240);
            heff_drop(v_uf_242);
            switch (heff_tag_of(v_it1_24937)) {
            case TAG_MkPair: {
              V v_m_24938 = heff_field(v_it1_24937, 0);
              V v_sp_24939 = heff_field(v_it1_24937, 1);
              heff_take_n(v_it1_24937, 3ULL, 2);
              return heff_tail(heff_get_n(v_r_243, 3, 9), 8, (V[]){v_g_244, v_cs_245, v_m_24938, v_sp_24939, v_x_2412, v_x_2415, v_hd_2410, v_k_2411});
            }
            default: return heff_nomatch(v_it1_24937);
            }
          }
          default: return heff_nomatch(v_t_24910);
          }
        }
        case TAG_Just: {
          V v_it1_24940 = heff_field(v_t_24897, 0);
          heff_take_n(v_t_24897, 1ULL, 1);
          heff_drop(v_ms_241);
          heff_drop(v_w_240);
          heff_drop(v_uf_242);
          switch (heff_tag_of(v_it1_24940)) {
          case TAG_MkPair: {
            V v_m_24941 = heff_field(v_it1_24940, 0);
            V v_sp_24942 = heff_field(v_it1_24940, 1);
            heff_take_n(v_it1_24940, 3ULL, 2);
            return heff_tail(heff_get_n(v_r_243, 3, 9), 8, (V[]){v_g_244, v_cs_245, v_m_24941, v_sp_24942, v_x_2415, v_x_2412, v_hd_2410, v_k_2411});
          }
          default: return heff_nomatch(v_it1_24940);
          }
        }
        default: return heff_nomatch(v_t_24897);
        }
      }
      case TAG_VCons: {
        V v_t_24956;
        switch (heff_tag_of(v_x_2412)) {
        case TAG_VNeu: {
          V v_v1_24944 = heff_dup(heff_field(v_x_2412, 0));
          V v_sp_24945 = heff_dup(heff_field(v_x_2412, 1));
          switch (heff_tag_of(v_v1_24944)) {
          case TAG_HLocal: {
            heff_take_n(v_v1_24944, 0ULL, 1);
            heff_drop(v_sp_24945);
            v_t_24956 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HGlobal: {
            heff_take_n(v_v1_24944, 0ULL, 1);
            heff_drop(v_sp_24945);
            v_t_24956 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_HMeta: {
            V v_m_24951 = heff_field(v_v1_24944, 0);
            V v_ru_24v1_24944_24HMeta = heff_take_reuse_n(v_v1_24944, 1ULL, 1);
            v_t_24956 = heff_tag_at_n(v_ru_24v1_24944_24HMeta, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_m_24951, v_sp_24945})});
            break;
          }
          case TAG_HError: {
            heff_drop(v_sp_24945);
            v_t_24956 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_v1_24944);
          }
          break;
        }
        case TAG_VCode: {
          v_t_24956 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VLam: {
          v_t_24956 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VCons: {
          v_t_24956 = NTAG(TAG_Nothing);
          break;
        }
        case TAG_VOpaque: {
          v_t_24956 = NTAG(TAG_Nothing);
          break;
        }
        default: heff_nomatch(v_x_2412);
        }
        switch (heff_tag_of(v_t_24956)) {
        case TAG_Nothing: {
          V v_t_24969;
          switch (heff_tag_of(v_x_2415)) {
          case TAG_VNeu: {
            V v_v1_24957 = heff_dup(heff_field(v_x_2415, 0));
            V v_sp_24958 = heff_dup(heff_field(v_x_2415, 1));
            switch (heff_tag_of(v_v1_24957)) {
            case TAG_HLocal: {
              heff_take_n(v_v1_24957, 0ULL, 1);
              heff_drop(v_sp_24958);
              v_t_24969 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HGlobal: {
              heff_take_n(v_v1_24957, 0ULL, 1);
              heff_drop(v_sp_24958);
              v_t_24969 = NTAG(TAG_Nothing);
              break;
            }
            case TAG_HMeta: {
              V v_m_24964 = heff_field(v_v1_24957, 0);
              V v_ru_24v1_24957_24HMeta = heff_take_reuse_n(v_v1_24957, 1ULL, 1);
              v_t_24969 = heff_tag_at_n(v_ru_24v1_24957_24HMeta, TAG_Just, 1, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_m_24964, v_sp_24958})});
              break;
            }
            case TAG_HError: {
              heff_drop(v_sp_24958);
              v_t_24969 = NTAG(TAG_Nothing);
              break;
            }
            default: heff_nomatch(v_v1_24957);
            }
            break;
          }
          case TAG_VCode: {
            v_t_24969 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VLam: {
            v_t_24969 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VCons: {
            v_t_24969 = NTAG(TAG_Nothing);
            break;
          }
          case TAG_VOpaque: {
            v_t_24969 = NTAG(TAG_Nothing);
            break;
          }
          default: heff_nomatch(v_x_2415);
          }
          switch (heff_tag_of(v_t_24969)) {
          case TAG_Nothing: {
            V v_t_24982;
            switch (heff_tag_of(v_x_2412)) {
            case TAG_VNeu: {
              V v_v1_24970 = heff_dup(heff_field(v_x_2412, 0));
              switch (heff_tag_of(v_v1_24970)) {
              case TAG_HLocal: {
                V v_ru_24v1_24970_24HLocal = heff_take_reuse_n(v_v1_24970, 0ULL, 1);
                v_t_24982 = (g_heff_2eelab_2econversion_2ecanon_24tok1(v_ru_24v1_24970_24HLocal, heff_dup(v_x_2412)));
                break;
              }
              case TAG_HGlobal: {
                V v_ru_24v1_24970_24HGlobal = heff_take_reuse_n(v_v1_24970, 0ULL, 1);
                v_t_24982 = (g_heff_2eelab_2econversion_2ecanon_24tok1(v_ru_24v1_24970_24HGlobal, heff_dup(v_x_2412)));
                break;
              }
              case TAG_HMeta: {
                heff_take_n(v_v1_24970, 0ULL, 1);
                v_t_24982 = heff_dup(v_x_2412);
                break;
              }
              case TAG_HError: {
                v_t_24982 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
                break;
              }
              default: heff_nomatch(v_v1_24970);
              }
              break;
            }
            case TAG_VCode: {
              v_t_24982 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
              break;
            }
            case TAG_VLam: {
              v_t_24982 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
              break;
            }
            case TAG_VCons: {
              v_t_24982 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
              break;
            }
            case TAG_VOpaque: {
              v_t_24982 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2412)));
              break;
            }
            default: heff_nomatch(v_x_2412);
            }
            V v_t_24995;
            switch (heff_tag_of(v_x_2415)) {
            case TAG_VNeu: {
              V v_v1_24983 = heff_dup(heff_field(v_x_2415, 0));
              switch (heff_tag_of(v_v1_24983)) {
              case TAG_HLocal: {
                V v_ru_24v1_24983_24HLocal = heff_take_reuse_n(v_v1_24983, 0ULL, 1);
                v_t_24995 = (g_heff_2eelab_2econversion_2ecanon_24tok1(v_ru_24v1_24983_24HLocal, heff_dup(v_x_2415)));
                break;
              }
              case TAG_HGlobal: {
                V v_ru_24v1_24983_24HGlobal = heff_take_reuse_n(v_v1_24983, 0ULL, 1);
                v_t_24995 = (g_heff_2eelab_2econversion_2ecanon_24tok1(v_ru_24v1_24983_24HGlobal, heff_dup(v_x_2415)));
                break;
              }
              case TAG_HMeta: {
                heff_take_n(v_v1_24983, 0ULL, 1);
                v_t_24995 = heff_dup(v_x_2415);
                break;
              }
              case TAG_HError: {
                v_t_24995 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
                break;
              }
              default: heff_nomatch(v_v1_24983);
              }
              break;
            }
            case TAG_VCode: {
              v_t_24995 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
              break;
            }
            case TAG_VLam: {
              v_t_24995 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
              break;
            }
            case TAG_VCons: {
              v_t_24995 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
              break;
            }
            case TAG_VOpaque: {
              v_t_24995 = (g_heff_2eelab_2econversion_2ecanon(heff_dup(v_x_2415)));
              break;
            }
            default: heff_nomatch(v_x_2415);
            }
            return ({ V a_0 = v_w_240; V a_1 = v_ms_241; V a_2 = v_uf_242; V a_3 = v_r_243; V a_4 = v_g_244; V a_5 = v_cs_245; V a_6 = v_t_24982; V a_7 = v_t_24995; V a_8 = v_x_2412; V a_9 = v_x_2415; V a_10 = v_hd_2410; V a_11 = v_k_2411; V r_ = (g_heff_2eelab_2eunify_2euElRigid(a_0, a_1, a_2, a_3, a_4, a_5, a_6, a_7, a_8, a_9, a_10, a_11)); heff_drop(v_ms_241); r_; });
          }
          case TAG_Just: {
            V v_it1_24996 = heff_field(v_t_24969, 0);
            heff_take_n(v_t_24969, 1ULL, 1);
            heff_drop(v_ms_241);
            heff_drop(v_w_240);
            heff_drop(v_uf_242);
            switch (heff_tag_of(v_it1_24996)) {
            case TAG_MkPair: {
              V v_m_24997 = heff_field(v_it1_24996, 0);
              V v_sp_24998 = heff_field(v_it1_24996, 1);
              heff_take_n(v_it1_24996, 3ULL, 2);
              return heff_tail(heff_get_n(v_r_243, 3, 9), 8, (V[]){v_g_244, v_cs_245, v_m_24997, v_sp_24998, v_x_2412, v_x_2415, v_hd_2410, v_k_2411});
            }
            default: return heff_nomatch(v_it1_24996);
            }
          }
          default: return heff_nomatch(v_t_24969);
          }
        }
        case TAG_Just: {
          V v_it1_24999 = heff_field(v_t_24956, 0);
          heff_take_n(v_t_24956, 1ULL, 1);
          heff_drop(v_ms_241);
          heff_drop(v_w_240);
          heff_drop(v_uf_242);
          switch (heff_tag_of(v_it1_24999)) {
          case TAG_MkPair: {
            V v_m_241000 = heff_field(v_it1_24999, 0);
            V v_sp_241001 = heff_field(v_it1_24999, 1);
            heff_take_n(v_it1_24999, 3ULL, 2);
            return heff_tail(heff_get_n(v_r_243, 3, 9), 8, (V[]){v_g_244, v_cs_245, v_m_241000, v_sp_241001, v_x_2415, v_x_2412, v_hd_2410, v_k_2411});
          }
          default: return heff_nomatch(v_it1_24999);
          }
        }
        default: return heff_nomatch(v_t_24956);
        }
      }
      case TAG_VOpaque: {
        heff_drop_tag(v_x_2412, 1);
        heff_drop(v_ms_241);
        heff_drop(v_w_240);
        heff_drop(v_hd_2410);
        heff_drop_rec(v_cs_245, 2);
        heff_drop(v_uf_242);
        heff_drop_rec(v_r_243, 9);
        heff_drop(v_g_244);
        V f_ = v_k_2411;
        args[0] = NTAG(TAG_MkUnit);
        if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
        return heff_tail(f_, 1, args);
      }
      default: return heff_nomatch(v_x_2415);
      }
    }
    case TAG_VOpaque: {
      heff_drop(v_x_2415);
      heff_drop(v_ms_241);
      heff_drop(v_w_240);
      heff_drop(v_hd_2410);
      heff_drop_rec(v_cs_245, 2);
      heff_drop(v_uf_242);
      heff_drop_rec(v_r_243, 9);
      heff_drop(v_g_244);
      V f_ = v_k_2411;
      args[0] = NTAG(TAG_MkUnit);
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    }
    default: return heff_nomatch(v_x_2412);
    }
  }
}
V g_heff_2eelab_2eunify_2euTermF_lam2(V self, V *args) {
  V v_x_2412 = args[0];
  V v_ms_241 = heff_env(self)[0];
  V v_b0_247 = heff_env(self)[1];
  V v_w_240 = heff_env(self)[2];
  V v_hd_2410 = heff_env(self)[3];
  V v_cs_245 = heff_env(self)[4];
  V v_uf_242 = heff_env(self)[5];
  V v_k_2411 = heff_env(self)[6];
  V v_r_243 = heff_env(self)[7];
  V v_g_244 = heff_env(self)[8];
  heff_clo_take(self, 9);
  V v_t_2414 = heff_tr(heff_call(heff_dup(v_ms_241), 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){heff_clo_n(g_heff_2eelab_2eunify_2euTermF_lam3, 1, 1, (V[]){v_b0_247})})}));
  return (g_co_2eop_24s310169282x2049378029(heff_dup(v_w_240), v_t_2414, heff_dup(v_hd_2410), heff_clo_n(g_heff_2eelab_2eunify_2euTermF_lam4, 1, 9, (V[]){v_x_2412, v_ms_241, v_w_240, v_hd_2410, v_cs_245, v_uf_242, v_k_2411, v_r_243, v_g_244})));
}
V g_heff_2eelab_2eunify_2euTermF_lam1(V self, V *args) {
  V v_hd_2410 = args[0];
  V v_k_2411 = args[1];
  V v_w_240 = heff_env(self)[0];
  V v_t_249 = heff_env(self)[1];
  V v_ms_241 = heff_env(self)[2];
  V v_b0_247 = heff_env(self)[3];
  V v_cs_245 = heff_env(self)[4];
  V v_uf_242 = heff_env(self)[5];
  V v_r_243 = heff_env(self)[6];
  V v_g_244 = heff_env(self)[7];
  heff_clo_take(self, 8);
  return (g_co_2eop_24s310169282x2049378029(heff_dup(v_w_240), v_t_249, heff_dup(v_hd_2410), heff_clo_n(g_heff_2eelab_2eunify_2euTermF_lam2, 1, 9, (V[]){v_ms_241, v_b0_247, v_w_240, v_hd_2410, v_cs_245, v_uf_242, v_k_2411, v_r_243, v_g_244})));
}
Clo g_heff_2eelab_2eunify_2eufEv_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2eufEv_entry, 1, 0};

V g_heff_2eelab_2eunify_2eufEv(V v_p_240) {
top: ;
  return heff_tag_n(TAG_InR, 1, (V[]){v_p_240});
}
V g_heff_2eelab_2eunify_2eufEv_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2eufEv(a[0]);
}
V g_heff_2eelab_2eunify_2erenameSpine_24s1736623419x1918172804_lam0(V self, V *args);
V g_heff_2eelab_2eunify_2erenameSpine_24s1736623419x1918172804_lam3(V self, V *args);
V g_heff_2eelab_2eunify_2erenameSpine_24s1736623419x1918172804_lam2(V self, V *args);
V g_heff_2eelab_2eunify_2erenameSpine_24s1736623419x1918172804_lam1(V self, V *args);
V g_heff_2eelab_2eunify_2erenameSpine_24s1736623419x1918172804_lam5(V self, V *args);
V g_heff_2eelab_2eunify_2erenameSpine_24s1736623419x1918172804_lam4(V self, V *args);
V g_heff_2eelab_2eunify_2erenameSpine_24s1736623419x1918172804_lam8(V self, V *args);
V g_heff_2eelab_2eunify_2erenameSpine_24s1736623419x1918172804_lam7(V self, V *args);
V g_heff_2eelab_2eunify_2erenameSpine_24s1736623419x1918172804_lam6(V self, V *args);
Clo g_heff_2eelab_2eunify_2erenameSpine_24s1736623419x1918172804_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2erenameSpine_24s1736623419x1918172804_entry, 5, 0};

V g_heff_2eelab_2eunify_2erenameSpine_24s1736623419x1918172804(V v_g_240, V v_m_241, V v_pr_242, V v_x5_243, V v_h_244) {
top: ;
  switch (heff_tag_of(v_x5_243)) {
  case TAG_SpId: {
    heff_drop(v_g_240);
    heff_drop(v_m_241);
    heff_drop(v_pr_242);
    return heff_clo_n(g_heff_2eelab_2eunify_2erenameSpine_24s1736623419x1918172804_lam0, 2, 1, (V[]){v_h_244});
  }
  case TAG_SpApp: {
    V v_s_247 = heff_field(v_x5_243, 0);
    V v_a_248 = heff_field(v_x5_243, 1);
    heff_take_n(v_x5_243, 3ULL, 2);
    V v_c_249 = (g_heff_2eelab_2eunify_2erenameSpine_24s1736623419x1918172804(heff_dup(v_g_240), heff_dup(v_m_241), heff_dup(v_pr_242), v_s_247, v_h_244));
    return heff_clo_n(g_heff_2eelab_2eunify_2erenameSpine_24s1736623419x1918172804_lam1, 2, 5, (V[]){v_c_249, v_g_240, v_m_241, v_pr_242, v_a_248});
  }
  case TAG_SpProj: {
    V v_s_2414 = heff_field(v_x5_243, 0);
    V v_l_2415 = heff_field(v_x5_243, 1);
    heff_take_n(v_x5_243, 3ULL, 2);
    V v_c_2416 = (g_heff_2eelab_2eunify_2erenameSpine_24s1736623419x1918172804(v_g_240, v_m_241, v_pr_242, v_s_2414, v_h_244));
    return heff_clo_n(g_heff_2eelab_2eunify_2erenameSpine_24s1736623419x1918172804_lam4, 2, 2, (V[]){v_c_2416, v_l_2415});
  }
  case TAG_SpSpec: {
    V v_s_2420 = heff_field(v_x5_243, 0);
    V v_l_2421 = heff_field(v_x5_243, 1);
    V v_a_2422 = heff_field(v_x5_243, 2);
    heff_take_n(v_x5_243, 7ULL, 3);
    V v_c_2423 = (g_heff_2eelab_2eunify_2erenameSpine_24s1736623419x1918172804(heff_dup(v_g_240), heff_dup(v_m_241), heff_dup(v_pr_242), v_s_2420, v_h_244));
    return heff_clo_n(g_heff_2eelab_2eunify_2erenameSpine_24s1736623419x1918172804_lam6, 2, 6, (V[]){v_c_2423, v_g_240, v_m_241, v_pr_242, v_a_2422, v_l_2421});
  }
  default: return heff_nomatch(v_x5_243);
  }
}
V g_heff_2eelab_2eunify_2erenameSpine_24s1736623419x1918172804_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2erenameSpine_24s1736623419x1918172804(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2eelab_2eunify_2erenameSpine_24s1736623419x1918172804_lam0(V self, V *args) {
  V v_hd_245 = args[0];
  V v_k_246 = args[1];
  V v_h_244 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_hd_245);
  V f_ = v_k_246;
  args[0] = v_h_244;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameSpine_24s1736623419x1918172804_lam3(V self, V *args) {
  V v_x_2413 = args[0];
  V v_k_2411 = heff_env(self)[0];
  V v_x_2412 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_2411;
  args[0] = heff_tag_n(TAG_SApp, 2, (V[]){v_x_2412, v_x_2413});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameSpine_24s1736623419x1918172804_lam2(V self, V *args) {
  V v_x_2412 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  V v_pr_242 = heff_env(self)[2];
  V v_a_248 = heff_env(self)[3];
  V v_hd_2410 = heff_env(self)[4];
  V v_k_2411 = heff_env(self)[5];
  heff_clo_take(self, 6);
  return (g_heff_2eelab_2eunify_2erenameF_24s1267840119x771576902(v_g_240, v_m_241, v_pr_242, v_a_248, v_hd_2410, heff_clo_n(g_heff_2eelab_2eunify_2erenameSpine_24s1736623419x1918172804_lam3, 1, 2, (V[]){v_k_2411, v_x_2412})));
}
V g_heff_2eelab_2eunify_2erenameSpine_24s1736623419x1918172804_lam1(V self, V *args) {
  V v_hd_2410 = args[0];
  V v_k_2411 = args[1];
  V v_c_249 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_m_241 = heff_env(self)[2];
  V v_pr_242 = heff_env(self)[3];
  V v_a_248 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V f_ = v_c_249;
  args[0] = heff_dup(v_hd_2410);
  args[1] = heff_clo_n(g_heff_2eelab_2eunify_2erenameSpine_24s1736623419x1918172804_lam2, 1, 6, (V[]){v_g_240, v_m_241, v_pr_242, v_a_248, v_hd_2410, v_k_2411});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2erenameSpine_24s1736623419x1918172804_lam5(V self, V *args) {
  V v_x_2419 = args[0];
  V v_k_2418 = heff_env(self)[0];
  V v_l_2415 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_2418;
  args[0] = heff_tag_n(TAG_SProj, 2, (V[]){v_x_2419, v_l_2415});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameSpine_24s1736623419x1918172804_lam4(V self, V *args) {
  V v_hd_2417 = args[0];
  V v_k_2418 = args[1];
  V v_c_2416 = heff_env(self)[0];
  V v_l_2415 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_c_2416;
  args[0] = v_hd_2417;
  args[1] = heff_clo_n(g_heff_2eelab_2eunify_2erenameSpine_24s1736623419x1918172804_lam5, 1, 2, (V[]){v_k_2418, v_l_2415});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2erenameSpine_24s1736623419x1918172804_lam8(V self, V *args) {
  V v_x_2427 = args[0];
  V v_k_2425 = heff_env(self)[0];
  V v_x_2426 = heff_env(self)[1];
  V v_l_2421 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V f_ = v_k_2425;
  args[0] = heff_tag_n(TAG_SSpecialize, 3, (V[]){v_x_2426, v_l_2421, v_x_2427});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameSpine_24s1736623419x1918172804_lam7(V self, V *args) {
  V v_x_2426 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  V v_pr_242 = heff_env(self)[2];
  V v_a_2422 = heff_env(self)[3];
  V v_hd_2424 = heff_env(self)[4];
  V v_k_2425 = heff_env(self)[5];
  V v_l_2421 = heff_env(self)[6];
  heff_clo_take(self, 7);
  return (g_heff_2eelab_2eunify_2erenameF_24s1267840119x771576902(v_g_240, v_m_241, v_pr_242, v_a_2422, v_hd_2424, heff_clo_n(g_heff_2eelab_2eunify_2erenameSpine_24s1736623419x1918172804_lam8, 1, 3, (V[]){v_k_2425, v_x_2426, v_l_2421})));
}
V g_heff_2eelab_2eunify_2erenameSpine_24s1736623419x1918172804_lam6(V self, V *args) {
  V v_hd_2424 = args[0];
  V v_k_2425 = args[1];
  V v_c_2423 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_m_241 = heff_env(self)[2];
  V v_pr_242 = heff_env(self)[3];
  V v_a_2422 = heff_env(self)[4];
  V v_l_2421 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V f_ = v_c_2423;
  args[0] = heff_dup(v_hd_2424);
  args[1] = heff_clo_n(g_heff_2eelab_2eunify_2erenameSpine_24s1736623419x1918172804_lam7, 1, 7, (V[]){v_g_240, v_m_241, v_pr_242, v_a_2422, v_hd_2424, v_k_2425, v_l_2421});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2erenameFlexF_24s1334562537x508738869_lam0(V self, V *args); static Clo g_heff_2eelab_2eunify_2erenameFlexF_24s1334562537x508738869_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2erenameFlexF_24s1334562537x508738869_lam0, 1, 0};
V g_heff_2eelab_2eunify_2erenameFlexF_24s1334562537x508738869_lam2(V self, V *args); static Clo g_heff_2eelab_2eunify_2erenameFlexF_24s1334562537x508738869_lam2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2erenameFlexF_24s1334562537x508738869_lam2, 1, 0};
V g_heff_2eelab_2eunify_2erenameFlexF_24s1334562537x508738869_lam4(V self, V *args);
V g_heff_2eelab_2eunify_2erenameFlexF_24s1334562537x508738869_lam6(V self, V *args);
V g_heff_2eelab_2eunify_2erenameFlexF_24s1334562537x508738869_lam7(V self, V *args);
V g_heff_2eelab_2eunify_2erenameFlexF_24s1334562537x508738869_lam5(V self, V *args);
V g_heff_2eelab_2eunify_2erenameFlexF_24s1334562537x508738869_lam8(V self, V *args); static Clo g_heff_2eelab_2eunify_2erenameFlexF_24s1334562537x508738869_lam8_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2erenameFlexF_24s1334562537x508738869_lam8, 1, 0};
V g_heff_2eelab_2eunify_2erenameFlexF_24s1334562537x508738869_lam9(V self, V *args);
V g_heff_2eelab_2eunify_2erenameFlexF_24s1334562537x508738869_lam13(V self, V *args);
V g_heff_2eelab_2eunify_2erenameFlexF_24s1334562537x508738869_lam14(V self, V *args); static Clo g_heff_2eelab_2eunify_2erenameFlexF_24s1334562537x508738869_lam14_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2erenameFlexF_24s1334562537x508738869_lam14, 2, 0};
V g_heff_2eelab_2eunify_2erenameFlexF_24s1334562537x508738869_lam15(V self, V *args); static Clo g_heff_2eelab_2eunify_2erenameFlexF_24s1334562537x508738869_lam15_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2erenameFlexF_24s1334562537x508738869_lam15, 2, 0};
V g_heff_2eelab_2eunify_2erenameFlexF_24s1334562537x508738869_lam12(V self, V *args);
V g_heff_2eelab_2eunify_2erenameFlexF_24s1334562537x508738869_lam16(V self, V *args);
V g_heff_2eelab_2eunify_2erenameFlexF_24s1334562537x508738869_lam11(V self, V *args);
V g_heff_2eelab_2eunify_2erenameFlexF_24s1334562537x508738869_lam10(V self, V *args);
V g_heff_2eelab_2eunify_2erenameFlexF_24s1334562537x508738869_lam17(V self, V *args); static Clo g_heff_2eelab_2eunify_2erenameFlexF_24s1334562537x508738869_lam17_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2erenameFlexF_24s1334562537x508738869_lam17, 1, 0};
V g_heff_2eelab_2eunify_2erenameFlexF_24s1334562537x508738869_lam18(V self, V *args);
V g_heff_2eelab_2eunify_2erenameFlexF_24s1334562537x508738869_lam3(V self, V *args);
V g_heff_2eelab_2eunify_2erenameFlexF_24s1334562537x508738869_lam1(V self, V *args);
Clo g_heff_2eelab_2eunify_2erenameFlexF_24s1334562537x508738869_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2erenameFlexF_24s1334562537x508738869_entry, 7, 0};

V g_heff_2eelab_2eunify_2erenameFlexF_24s1334562537x508738869(V v_g_240, V v_m_241, V v_pr_242, V v_m_27_243, V v_sp_244, V v_hd_245, V v_k_246) {
top: ;
  V v_t_248 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2eunify_2erenameFlexF_24s1334562537x508738869_lam0_clo)})});
  V v_t_249 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_245, 2)), 1, (V[]){v_t_248}));
  return heff_tail(heff_dup(heff_rfield(v_hd_245, 1)), 2, (V[]){v_t_249, heff_clo_n(g_heff_2eelab_2eunify_2erenameFlexF_24s1334562537x508738869_lam1, 1, 7, (V[]){v_hd_245, v_sp_244, v_pr_242, v_g_240, v_m_241, v_m_27_243, v_k_246})});
}
V g_heff_2eelab_2eunify_2erenameFlexF_24s1334562537x508738869_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2erenameFlexF_24s1334562537x508738869(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
V g_heff_2eelab_2eunify_2erenameFlexF_24s1334562537x508738869_lam0(V self, V *args) {
  V v_c_247 = args[0];
  return heff_get_n(v_c_247, 3, 8);
}
V g_heff_2eelab_2eunify_2erenameFlexF_24s1334562537x508738869_lam2(V self, V *args) {
  V v_c_2411 = args[0];
  return heff_get_n(v_c_2411, 7, 8);
}
V g_heff_2eelab_2eunify_2erenameFlexF_24s1334562537x508738869_lam4(V self, V *args) {
  V v_a_2422 = args[0];
  V v_pr_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_a_2422)) {
  case TAG_PVar: {
    V v_l_2423 = heff_field(v_a_2422, 0);
    heff_take_n(v_a_2422, 1ULL, 1);
    HeffT2 v_t_2424 = ({ V b_0 = heff_get_n(v_pr_242, 2, 3); V a_1 = v_l_2423; HeffT2 r_ = (g_std_2emap_2elookup_24s1576363199x1121931492_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
    {
      V v_field_2426 = v_t_2424.f[1];
      int64_t v_tag_2425 = ((int64_t)v_t_2424.f[0]);
      V v_ret_24bool = heff_bool(((v_tag_2425 == ((int64_t)0ULL)) ? ({ V v_x_2427 = heff_dup(v_field_2426); int c_ = 0; heff_drop(v_x_2427); c_; }) : 1));
      heff_drop(v_field_2426);
      return v_ret_24bool;
    }
  }
  case TAG_PSelf: {
    heff_drop_rec(v_pr_242, 3);
    return NTAG(TAG_True);
  }
  default: return heff_nomatch(v_a_2422);
  }
}
V g_heff_2eelab_2eunify_2erenameFlexF_24s1334562537x508738869_lam6(V self, V *args) {
  V v_i_2431 = args[0];
  V v_a_2432 = args[1];
  V v_pr_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_a_2432)) {
  case TAG_PVar: {
    V v_l_2433 = heff_field(v_a_2432, 0);
    V v_ru_24a_2432_24PVar = heff_take_reuse_n(v_a_2432, 1ULL, 1);
    HeffT2 v_t_2434 = ({ V b_0 = heff_get_n(v_pr_242, 2, 3); V a_1 = v_l_2433; HeffT2 r_ = (g_std_2emap_2elookup_24s1576363199x1121931492_24cpr(b_0, a_1)); heff_drop(b_0); r_; });
    {
      V v_field_2436 = v_t_2434.f[1];
      int64_t v_tag_2435 = ((int64_t)v_t_2434.f[0]);
      if ((v_tag_2435 == ((int64_t)0ULL))) {
        V v_x_2437 = v_field_2436;
        heff_drop(v_x_2437);
        return heff_tag_at_n(v_ru_24a_2432_24PVar, TAG_Just, 1, (V[]){v_i_2431});
      } else {
        heff_drop(v_i_2431);
        heff_drop_cell(v_ru_24a_2432_24PVar, 1);
        heff_drop(v_field_2436);
        return NTAG(TAG_Nothing);
      }
    }
  }
  case TAG_PSelf: {
    heff_drop(v_i_2431);
    heff_drop_rec(v_pr_242, 3);
    return NTAG(TAG_Nothing);
  }
  default: return heff_nomatch(v_a_2432);
  }
}
V g_heff_2eelab_2eunify_2erenameFlexF_24s1334562537x508738869_lam7(V self, V *args) {
  V v_x_2440 = args[0];
  V v_sp_244 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_m_241 = heff_env(self)[2];
  V v_pr_242 = heff_env(self)[3];
  V v_hd_245 = heff_env(self)[4];
  V v_k_246 = heff_env(self)[5];
  heff_clo_take(self, 6);
  V v_v_2441 = ({ V a_0 = v_x_2440; V a_1 = v_sp_244; V r_ = (g_heff_2eelab_2evalue_2ereplay(a_0, a_1)); heff_drop(v_sp_244); r_; });
  return (g_heff_2eelab_2eunify_2erenameF_24s1267840119x771576902(v_g_240, v_m_241, v_pr_242, v_v_2441, v_hd_245, v_k_246));
}
V g_heff_2eelab_2eunify_2erenameFlexF_24s1334562537x508738869_lam5(V self, V *args) {
  V v_x_2429 = args[0];
  V v_args_2421 = heff_env(self)[0];
  V v_pr_242 = heff_env(self)[1];
  V v_g_240 = heff_env(self)[2];
  V v_m_241 = heff_env(self)[3];
  V v_m_27_243 = heff_env(self)[4];
  V v_hd_245 = heff_env(self)[5];
  V v_sp_244 = heff_env(self)[6];
  V v_k_246 = heff_env(self)[7];
  heff_clo_take(self, 8);
  V v_t_2430 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_args_2421));
  V v_t_2438 = (g_heff_2eelab_2eunify_2emapWithIndexL(MK_INT(0LL), heff_clo_n(g_heff_2eelab_2eunify_2erenameFlexF_24s1334562537x508738869_lam6, 2, 1, (V[]){heff_dup(v_pr_242)}), v_args_2421));
  V v_t_2439 = (g_heff_2eelab_2eunify_2ecatMaybes(v_t_2438));
  return (g_heff_2eelab_2eunify_2esolveWithPruned_24s1929340871x768895529(heff_dup(v_g_240), heff_dup(v_m_241), v_m_27_243, v_x_2429, v_t_2430, v_t_2439, heff_dup(v_hd_245), heff_clo_n(g_heff_2eelab_2eunify_2erenameFlexF_24s1334562537x508738869_lam7, 1, 6, (V[]){v_sp_244, v_g_240, v_m_241, v_pr_242, v_hd_245, v_k_246})));
}
V g_heff_2eelab_2eunify_2erenameFlexF_24s1334562537x508738869_lam8(V self, V *args) {
  V v_c_2443 = args[0];
  return heff_get_n(v_c_2443, 3, 8);
}
V g_heff_2eelab_2eunify_2erenameFlexF_24s1334562537x508738869_lam9(V self, V *args) {
  V v_x_2446 = args[0];
  V v_m_27_243 = heff_env(self)[0];
  V v_k_2442 = heff_env(self)[1];
  V v_hd_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  HeffT2 v_t_2447 = ({ V a_0 = v_x_2446; V a_1 = v_m_27_243; HeffT2 r_ = (g_std_2emap_2elookup_24s1702756637x1169753568_24cpr(a_0, a_1)); heff_drop(v_x_2446); r_; });
  {
    V v_field_2449 = v_t_2447.f[1];
    int64_t v_tag_2448 = ((int64_t)v_t_2447.f[0]);
    if ((v_tag_2448 == ((int64_t)0ULL))) {
      heff_drop_rec(v_hd_245, 3);
      V v_e_2450 = v_field_2449;
      V f_ = v_k_2442;
      args[0] = v_e_2450;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    } else {
      heff_drop(v_field_2449);
      V v_t_2451 = heff_tag_n(TAG_UnequalEls, 3, (V[]){heff_dup(g_heff_2eelab_2eparams_2eemptyShape_get()), NTAG(TAG_VOpaque), NTAG(TAG_VOpaque)});
      V v_t_2452 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2451})});
      V v_t_2453 = heff_tr(heff_call(heff_take_field(v_hd_245, 2), 1, (V[]){v_t_2452}));
      V f_ = heff_get_n(v_hd_245, 1, 3);
      heff_room[0] = v_t_2453;
      heff_room[1] = v_k_2442;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
  }
}
V g_heff_2eelab_2eunify_2erenameFlexF_24s1334562537x508738869_lam13(V self, V *args) {
  V v_hd_2462 = args[0];
  V v_k_2463 = args[1];
  V v_pr_242 = heff_env(self)[0];
  V v_l_27_2461 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_hd_2462);
  V v_t_2464 = heff_intSub(heff_get_n(v_pr_242, 1, 3), v_l_27_2461);
  V f_ = v_k_2463;
  args[0] = heff_intSub(v_t_2464, MK_INT(1LL));
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameFlexF_24s1334562537x508738869_lam14(V self, V *args) {
  V v_hd_2465 = args[0];
  V v_k2_2466 = args[1];
  V v_bind_2467 = heff_take_field(v_hd_2465, 1);
  V v_malg_2468 = heff_get_n(v_hd_2465, 2, 3);
  V v_t_2469 = heff_tag_n(TAG_UnequalEls, 3, (V[]){heff_dup(g_heff_2eelab_2eparams_2eemptyShape_get()), NTAG(TAG_VOpaque), NTAG(TAG_VOpaque)});
  V v_t_2470 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2469})});
  V v_t_2471 = heff_tr(heff_call(v_malg_2468, 1, (V[]){v_t_2470}));
  V f_ = v_bind_2467;
  args[0] = v_t_2471;
  args[1] = v_k2_2466;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2erenameFlexF_24s1334562537x508738869_lam15(V self, V *args) {
  V v_hd_2472 = args[0];
  V v_k2_2473 = args[1];
  V v_bind_2474 = heff_take_field(v_hd_2472, 1);
  V v_malg_2475 = heff_get_n(v_hd_2472, 2, 3);
  V v_t_2476 = heff_tag_n(TAG_UnequalEls, 3, (V[]){heff_dup(g_heff_2eelab_2eparams_2eemptyShape_get()), NTAG(TAG_VOpaque), NTAG(TAG_VOpaque)});
  V v_t_2477 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2476})});
  V v_t_2478 = heff_tr(heff_call(v_malg_2475, 1, (V[]){v_t_2477}));
  V f_ = v_bind_2474;
  args[0] = v_t_2478;
  args[1] = v_k2_2473;
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2erenameFlexF_24s1334562537x508738869_lam12(V self, V *args) {
  V v_a_2456 = args[0];
  V v_pr_242 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_a_2456)) {
  case TAG_PVar: {
    V v_l_2457 = heff_field(v_a_2456, 0);
    heff_take_n(v_a_2456, 1ULL, 1);
    HeffT2 v_t_2458 = (g_std_2emap_2elookup_24s1702756637x1169753568_24cpr(heff_rfield(v_pr_242, 2), v_l_2457));
    {
      V v_field_2460 = v_t_2458.f[1];
      int64_t v_tag_2459 = ((int64_t)v_t_2458.f[0]);
      if ((v_tag_2459 == ((int64_t)0ULL))) {
        V v_l_27_2461 = v_field_2460;
        return heff_clo_n(g_heff_2eelab_2eunify_2erenameFlexF_24s1334562537x508738869_lam13, 2, 2, (V[]){v_pr_242, v_l_27_2461});
      } else {
        heff_drop_rec(v_pr_242, 3);
        heff_drop(v_field_2460);
        return ((V)&g_heff_2eelab_2eunify_2erenameFlexF_24s1334562537x508738869_lam14_clo);
      }
    }
  }
  case TAG_PSelf: {
    heff_drop_rec(v_pr_242, 3);
    return ((V)&g_heff_2eelab_2eunify_2erenameFlexF_24s1334562537x508738869_lam15_clo);
  }
  default: return heff_nomatch(v_a_2456);
  }
}
V g_heff_2eelab_2eunify_2erenameFlexF_24s1334562537x508738869_lam16(V self, V *args) {
  V v_x_2480 = args[0];
  V v_m_27_243 = heff_env(self)[0];
  V v_x_2455 = heff_env(self)[1];
  V v_k_246 = heff_env(self)[2];
  heff_clo_take(self, 3);
  V v_t_2481 = heff_tag_n(TAG_SMetaApp, 3, (V[]){v_m_27_243, heff_arrayFromList(v_x_2480), v_x_2455});
  V f_ = v_k_246;
  args[0] = v_t_2481;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameFlexF_24s1334562537x508738869_lam11(V self, V *args) {
  V v_x_2455 = args[0];
  V v_pr_242 = heff_env(self)[0];
  V v_args_2421 = heff_env(self)[1];
  V v_hd_245 = heff_env(self)[2];
  V v_m_27_243 = heff_env(self)[3];
  V v_k_246 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_c_2479 = (g_prelude_2etraverse_24s1934076392x614790049(heff_clo_n(g_heff_2eelab_2eunify_2erenameFlexF_24s1334562537x508738869_lam12, 1, 1, (V[]){v_pr_242}), v_args_2421));
  V f_ = v_c_2479;
  heff_room[0] = v_hd_245;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2eunify_2erenameFlexF_24s1334562537x508738869_lam16, 1, 3, (V[]){v_m_27_243, v_x_2455, v_k_246});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2eunify_2erenameFlexF_24s1334562537x508738869_lam10(V self, V *args) {
  V v_x_2454 = args[0];
  V v_g_240 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  V v_pr_242 = heff_env(self)[2];
  V v_hd_245 = heff_env(self)[3];
  V v_args_2421 = heff_env(self)[4];
  V v_m_27_243 = heff_env(self)[5];
  V v_k_246 = heff_env(self)[6];
  heff_clo_take(self, 7);
  return (g_heff_2eelab_2eunify_2erenameTypeF_24s337291609x1265825591(v_g_240, v_m_241, heff_dup(v_pr_242), heff_get_n(v_x_2454, 0, 6), heff_dup(v_hd_245), heff_clo_n(g_heff_2eelab_2eunify_2erenameFlexF_24s1334562537x508738869_lam11, 1, 5, (V[]){v_pr_242, v_args_2421, v_hd_245, v_m_27_243, v_k_246})));
}
V g_heff_2eelab_2eunify_2erenameFlexF_24s1334562537x508738869_lam17(V self, V *args) {
  V v_c_2483 = args[0];
  return heff_get_n(v_c_2483, 3, 8);
}
V g_heff_2eelab_2eunify_2erenameFlexF_24s1334562537x508738869_lam18(V self, V *args) {
  V v_x_2486 = args[0];
  V v_m_27_243 = heff_env(self)[0];
  V v_k_2482 = heff_env(self)[1];
  V v_hd_245 = heff_env(self)[2];
  heff_clo_take(self, 3);
  HeffT2 v_t_2487 = ({ V a_0 = v_x_2486; V a_1 = v_m_27_243; HeffT2 r_ = (g_std_2emap_2elookup_24s1702756637x1169753568_24cpr(a_0, a_1)); heff_drop(v_x_2486); r_; });
  {
    V v_field_2489 = v_t_2487.f[1];
    int64_t v_tag_2488 = ((int64_t)v_t_2487.f[0]);
    if ((v_tag_2488 == ((int64_t)0ULL))) {
      heff_drop_rec(v_hd_245, 3);
      V v_e_2490 = v_field_2489;
      V f_ = v_k_2482;
      args[0] = v_e_2490;
      if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
      return heff_tail(f_, 1, args);
    } else {
      heff_drop(v_field_2489);
      V v_t_2491 = heff_tag_n(TAG_UnequalEls, 3, (V[]){heff_dup(g_heff_2eelab_2eparams_2eemptyShape_get()), NTAG(TAG_VOpaque), NTAG(TAG_VOpaque)});
      V v_t_2492 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2491})});
      V v_t_2493 = heff_tr(heff_call(heff_take_field(v_hd_245, 2), 1, (V[]){v_t_2492}));
      V f_ = heff_get_n(v_hd_245, 1, 3);
      heff_room[0] = v_t_2493;
      heff_room[1] = v_k_2482;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
  }
}
V g_heff_2eelab_2eunify_2erenameFlexF_24s1334562537x508738869_lam3(V self, V *args) {
  V v_x_2414 = args[0];
  V v_x_2410 = heff_env(self)[0];
  V v_sp_244 = heff_env(self)[1];
  V v_pr_242 = heff_env(self)[2];
  V v_g_240 = heff_env(self)[3];
  V v_m_241 = heff_env(self)[4];
  V v_m_27_243 = heff_env(self)[5];
  V v_hd_245 = heff_env(self)[6];
  V v_k_246 = heff_env(self)[7];
  heff_clo_take(self, 8);
  HeffT2 v_t_2415 = ({ V a_0 = v_x_2414; V a_1 = v_x_2410; V a_2 = heff_dup(v_sp_244); HeffT2 r_ = (g_heff_2eelab_2eunify_2epatSpine_24cpr(a_0, a_1, a_2)); heff_drop(v_x_2414); heff_drop(v_x_2410); r_; });
  {
    V v_field_2417 = v_t_2415.f[1];
    int64_t v_tag_2416 = ((int64_t)v_t_2415.f[0]);
    if ((v_tag_2416 == ((int64_t)0ULL))) {
      V v_items_2418 = v_field_2417;
      V v_t_2419 = (g_heff_2eelab_2eunify_2epatVarsOf(heff_dup(v_items_2418)));
      V v_t_2420 = ({ V a_0 = v_t_2419; V r_ = (g_heff_2eelab_2eunify_2edistinct(a_0)); heff_drop(v_t_2419); r_; });
      if ((heff_dup(v_t_2420) == NTAG(TAG_True))) {
        heff_drop(v_t_2420);
        V v_args_2421 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_items_2418));
        V v_t_2428 = (g_heff_2eelab_2eunify_2eanyL(heff_clo_n(g_heff_2eelab_2eunify_2erenameFlexF_24s1334562537x508738869_lam4, 1, 1, (V[]){heff_dup(v_pr_242)}), v_args_2421));
        if ((heff_dup(v_t_2428) == NTAG(TAG_True))) {
          heff_drop(v_t_2428);
          V v_k_2442 = heff_clo_n(g_heff_2eelab_2eunify_2erenameFlexF_24s1334562537x508738869_lam5, 1, 8, (V[]){v_args_2421, v_pr_242, v_g_240, v_m_241, heff_dup(v_m_27_243), heff_dup(v_hd_245), v_sp_244, v_k_246});
          V v_t_2444 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2eunify_2erenameFlexF_24s1334562537x508738869_lam8_clo)})});
          V v_t_2445 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_245, 2)), 1, (V[]){v_t_2444}));
          V f_ = heff_dup(heff_rfield(v_hd_245, 1));
          heff_room[0] = v_t_2445;
          heff_room[1] = heff_clo_n(g_heff_2eelab_2eunify_2erenameFlexF_24s1334562537x508738869_lam9, 1, 3, (V[]){v_m_27_243, v_k_2442, v_hd_245});
          if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
          return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
        } else {
          heff_drop(v_sp_244);
          heff_drop(v_t_2428);
          V v_k_2482 = heff_clo_n(g_heff_2eelab_2eunify_2erenameFlexF_24s1334562537x508738869_lam10, 1, 7, (V[]){v_g_240, v_m_241, v_pr_242, heff_dup(v_hd_245), v_args_2421, heff_dup(v_m_27_243), v_k_246});
          V v_t_2484 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2eunify_2erenameFlexF_24s1334562537x508738869_lam17_clo)})});
          V v_t_2485 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_245, 2)), 1, (V[]){v_t_2484}));
          V f_ = heff_dup(heff_rfield(v_hd_245, 1));
          heff_room[0] = v_t_2485;
          heff_room[1] = heff_clo_n(g_heff_2eelab_2eunify_2erenameFlexF_24s1334562537x508738869_lam18, 1, 3, (V[]){v_m_27_243, v_k_2482, v_hd_245});
          if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
          return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
        }
      } else {
        heff_drop(v_sp_244);
        heff_drop_rec(v_pr_242, 3);
        heff_drop(v_g_240);
        heff_drop(v_m_241);
        heff_drop(v_m_27_243);
        heff_drop(v_items_2418);
        heff_drop(v_t_2420);
        V v_t_2494 = heff_tag_n(TAG_UnequalEls, 3, (V[]){heff_dup(g_heff_2eelab_2eparams_2eemptyShape_get()), NTAG(TAG_VOpaque), NTAG(TAG_VOpaque)});
        V v_t_2495 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2494})});
        V v_t_2496 = heff_tr(heff_call(heff_take_field(v_hd_245, 2), 1, (V[]){v_t_2495}));
        V f_ = heff_get_n(v_hd_245, 1, 3);
        heff_room[0] = v_t_2496;
        heff_room[1] = v_k_246;
        if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
        return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
      }
    } else {
      heff_drop(v_sp_244);
      heff_drop_rec(v_pr_242, 3);
      heff_drop(v_g_240);
      heff_drop(v_m_241);
      heff_drop(v_m_27_243);
      heff_drop(v_field_2417);
      V v_t_2497 = heff_tag_n(TAG_UnequalEls, 3, (V[]){heff_dup(g_heff_2eelab_2eparams_2eemptyShape_get()), NTAG(TAG_VOpaque), NTAG(TAG_VOpaque)});
      V v_t_2498 = heff_tag_n(TAG_InR, 1, (V[]){heff_tag_n(TAG_Throw, 1, (V[]){v_t_2497})});
      V v_t_2499 = heff_tr(heff_call(heff_take_field(v_hd_245, 2), 1, (V[]){v_t_2498}));
      V f_ = heff_get_n(v_hd_245, 1, 3);
      heff_room[0] = v_t_2499;
      heff_room[1] = v_k_246;
      if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
      return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
    }
  }
}
V g_heff_2eelab_2eunify_2erenameFlexF_24s1334562537x508738869_lam1(V self, V *args) {
  V v_x_2410 = args[0];
  V v_hd_245 = heff_env(self)[0];
  V v_sp_244 = heff_env(self)[1];
  V v_pr_242 = heff_env(self)[2];
  V v_g_240 = heff_env(self)[3];
  V v_m_241 = heff_env(self)[4];
  V v_m_27_243 = heff_env(self)[5];
  V v_k_246 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2412 = heff_tag_n(TAG_InL, 1, (V[]){heff_tag_n(TAG_Get, 1, (V[]){((V)&g_heff_2eelab_2eunify_2erenameFlexF_24s1334562537x508738869_lam2_clo)})});
  V v_t_2413 = heff_tr(heff_call(heff_dup(heff_rfield(v_hd_245, 2)), 1, (V[]){v_t_2412}));
  V f_ = heff_dup(heff_rfield(v_hd_245, 1));
  heff_room[0] = v_t_2413;
  heff_room[1] = heff_clo_n(g_heff_2eelab_2eunify_2erenameFlexF_24s1334562537x508738869_lam3, 1, 8, (V[]){v_x_2410, v_sp_244, v_pr_242, v_g_240, v_m_241, v_m_27_243, v_hd_245, v_k_246});
  if (heff_exact(f_, 2, heff_room)) HEFF_LAST return ((Clo *)f_)->fn(f_, heff_room);
  return heff_tail(f_, 2, (V[]){heff_room[0], heff_room[1]});
}
V g_heff_2eelab_2eunify_2euk_24s212540630x1708219650_lam0(V self, V *args); static Clo g_heff_2eelab_2eunify_2euk_24s212540630x1708219650_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2euk_24s212540630x1708219650_lam0, 4, 0};
V g_heff_2eelab_2eunify_2euk_24s212540630x1708219650_lam3(V self, V *args);
V g_heff_2eelab_2eunify_2euk_24s212540630x1708219650_lam2(V self, V *args);
V g_heff_2eelab_2eunify_2euk_24s212540630x1708219650_lam1(V self, V *args); static Clo g_heff_2eelab_2eunify_2euk_24s212540630x1708219650_lam1_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2euk_24s212540630x1708219650_lam1, 4, 0};
V g_heff_2eelab_2eunify_2euk_24s212540630x1708219650_lam6(V self, V *args);
V g_heff_2eelab_2eunify_2euk_24s212540630x1708219650_lam5(V self, V *args);
V g_heff_2eelab_2eunify_2euk_24s212540630x1708219650_lam4(V self, V *args); static Clo g_heff_2eelab_2eunify_2euk_24s212540630x1708219650_lam4_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2euk_24s212540630x1708219650_lam4, 4, 0};

static V g_heff_2eelab_2eunify_2euk_24s212540630x1708219650_val;
static HEFF_ONCE g_heff_2eelab_2eunify_2euk_24s212540630x1708219650_st;
static V g_heff_2eelab_2eunify_2euk_24s212540630x1708219650_init(void) {
  return heff_rec_n(9, shape_uty__uel__ubare__solve__ren__renEv__renTy__renEvTy__renFlex, (V[]){((V)&g_heff_2eelab_2eunify_2euTypeF_24s584682120x2121508022_clo), ((V)&g_heff_2eelab_2eunify_2euk_24s212540630x1708219650_lam0_clo), ((V)&g_heff_2eelab_2eunify_2euBareF_24s1751326806x1297454095_clo), ((V)&g_heff_2eelab_2eunify_2esolveF_24s2118323613x521151929_clo), ((V)&g_heff_2eelab_2eunify_2erenameF_24s1267840119x771576902_clo), ((V)&g_heff_2eelab_2eunify_2euk_24s212540630x1708219650_lam1_clo), ((V)&g_heff_2eelab_2eunify_2erenameTypeF_24s337291609x1265825591_clo), ((V)&g_heff_2eelab_2eunify_2euk_24s212540630x1708219650_lam4_clo), ((V)&g_heff_2eelab_2eunify_2erenameFlexF_24s1334562537x508738869_clo)});
}
V g_heff_2eelab_2eunify_2euk_24s212540630x1708219650_get(void) {
  if (HEFF_DONE(g_heff_2eelab_2eunify_2euk_24s212540630x1708219650_st)) return g_heff_2eelab_2eunify_2euk_24s212540630x1708219650_val;
  return heff_global(&g_heff_2eelab_2eunify_2euk_24s212540630x1708219650_val, &g_heff_2eelab_2eunify_2euk_24s212540630x1708219650_st, g_heff_2eelab_2eunify_2euk_24s212540630x1708219650_init);
}
V g_heff_2eelab_2eunify_2euk_24s212540630x1708219650_lam0(V self, V *args) {
  V v_g_240 = args[0];
  V v_cs_241 = args[1];
  V v_a_242 = args[2];
  V v_b_243 = args[3];
  return (g_heff_2eelab_2eunify_2euTermF(heff_dup(g_co_2e_3c_2b_3e_24s419270740x1449981722_get()), ((V)&g_heff_2eelab_2eunify_2emsEv_clo), ((V)&g_heff_2eelab_2eunify_2eufEv_clo), heff_dup(g_heff_2eelab_2eunify_2euk_24s212540630x1708219650_get()), v_g_240, v_cs_241, v_a_242, v_b_243));
}
V g_heff_2eelab_2eunify_2euk_24s212540630x1708219650_lam3(V self, V *args) {
  V v_x_2413 = args[0];
  V v_k_2412 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_2412;
  args[0] = heff_tag_n(TAG_SIs, 1, (V[]){v_x_2413});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2euk_24s212540630x1708219650_lam2(V self, V *args) {
  V v_hd_2411 = args[0];
  V v_k_2412 = args[1];
  V v_g_244 = heff_env(self)[0];
  V v_m_245 = heff_env(self)[1];
  V v_pr_246 = heff_env(self)[2];
  V v_v_2410 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2eelab_2eunify_2erenameF_24s1267840119x771576902(v_g_244, v_m_245, v_pr_246, v_v_2410, v_hd_2411, heff_clo_n(g_heff_2eelab_2eunify_2euk_24s212540630x1708219650_lam3, 1, 1, (V[]){v_k_2412})));
}
V g_heff_2eelab_2eunify_2euk_24s212540630x1708219650_lam1(V self, V *args) {
  V v_g_244 = args[0];
  V v_m_245 = args[1];
  V v_pr_246 = args[2];
  V v_v_247 = args[3];
  switch (heff_tag_of(v_v_247)) {
  case TAG_Nom: {
    V v_v_248 = heff_field(v_v_247, 0);
    heff_take_n(v_v_247, 1ULL, 1);
    V f_ = ((V)&g_heff_2eelab_2eunify_2erenameF_24s1267840119x771576902_clo);
    args[0] = v_g_244;
    args[1] = v_m_245;
    args[2] = v_pr_246;
    args[3] = v_v_248;
    if (heff_exact(f_, 4, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 4, args);
  }
  case TAG_Describe: {
    V v_v_249 = heff_field(v_v_247, 0);
    heff_take_n(v_v_247, 1ULL, 1);
    V f_ = ((V)&g_heff_2eelab_2eunify_2erenameF_24s1267840119x771576902_clo);
    args[0] = v_g_244;
    args[1] = v_m_245;
    args[2] = v_pr_246;
    args[3] = v_v_249;
    if (heff_exact(f_, 4, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 4, args);
  }
  case TAG_Become: {
    V v_v_2410 = heff_field(v_v_247, 0);
    heff_take_n(v_v_247, 1ULL, 1);
    return heff_clo_n(g_heff_2eelab_2eunify_2euk_24s212540630x1708219650_lam2, 2, 4, (V[]){v_g_244, v_m_245, v_pr_246, v_v_2410});
  }
  default: return heff_nomatch(v_v_247);
  }
}
V g_heff_2eelab_2eunify_2euk_24s212540630x1708219650_lam6(V self, V *args) {
  V v_x_2423 = args[0];
  V v_k_2422 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_2422;
  args[0] = heff_tag_n(TAG_SIsTy, 1, (V[]){v_x_2423});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2euk_24s212540630x1708219650_lam5(V self, V *args) {
  V v_hd_2421 = args[0];
  V v_k_2422 = args[1];
  V v_g_2414 = heff_env(self)[0];
  V v_m_2415 = heff_env(self)[1];
  V v_pr_2416 = heff_env(self)[2];
  V v_a_2420 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2eelab_2eunify_2erenameTypeF_24s337291609x1265825591(v_g_2414, v_m_2415, v_pr_2416, v_a_2420, v_hd_2421, heff_clo_n(g_heff_2eelab_2eunify_2euk_24s212540630x1708219650_lam6, 1, 1, (V[]){v_k_2422})));
}
V g_heff_2eelab_2eunify_2euk_24s212540630x1708219650_lam4(V self, V *args) {
  V v_g_2414 = args[0];
  V v_m_2415 = args[1];
  V v_pr_2416 = args[2];
  V v_t_2417 = args[3];
  switch (heff_tag_of(v_t_2417)) {
  case TAG_Nom: {
    V v_a_2418 = heff_field(v_t_2417, 0);
    heff_take_n(v_t_2417, 1ULL, 1);
    V f_ = ((V)&g_heff_2eelab_2eunify_2erenameTypeF_24s337291609x1265825591_clo);
    args[0] = v_g_2414;
    args[1] = v_m_2415;
    args[2] = v_pr_2416;
    args[3] = v_a_2418;
    if (heff_exact(f_, 4, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 4, args);
  }
  case TAG_Describe: {
    V v_a_2419 = heff_field(v_t_2417, 0);
    heff_take_n(v_t_2417, 1ULL, 1);
    V f_ = ((V)&g_heff_2eelab_2eunify_2erenameTypeF_24s337291609x1265825591_clo);
    args[0] = v_g_2414;
    args[1] = v_m_2415;
    args[2] = v_pr_2416;
    args[3] = v_a_2419;
    if (heff_exact(f_, 4, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
    return heff_tail(f_, 4, args);
  }
  case TAG_Become: {
    V v_a_2420 = heff_field(v_t_2417, 0);
    heff_take_n(v_t_2417, 1ULL, 1);
    return heff_clo_n(g_heff_2eelab_2eunify_2euk_24s212540630x1708219650_lam5, 2, 4, (V[]){v_g_2414, v_m_2415, v_pr_2416, v_a_2420});
  }
  default: return heff_nomatch(v_t_2417);
  }
}
V g_heff_2eelab_2eunify_2esolveWithPruned_24s223240292x504960050_lam3(V self, V *args);
V g_heff_2eelab_2eunify_2esolveWithPruned_24s223240292x504960050_lam2(V self, V *args);
V g_heff_2eelab_2eunify_2esolveWithPruned_24s223240292x504960050_lam1(V self, V *args);
V g_heff_2eelab_2eunify_2esolveWithPruned_24s223240292x504960050_lam0(V self, V *args);
Clo g_heff_2eelab_2eunify_2esolveWithPruned_24s223240292x504960050_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2esolveWithPruned_24s223240292x504960050_entry, 8, 0};

V g_heff_2eelab_2eunify_2esolveWithPruned_24s223240292x504960050(V v_g_240, V v_occursM_241, V v_storeM_242, V v_entry_243, V v_n_244, V v_kept_245, V v_hd_246, V v_k_247) {
top: ;
  V v_t_248 = heff_rec_n(3, shape_dom__cod__ren, (V[]){heff_dup(heff_rfield(v_entry_243, 3)), MK_INT(0LL), heff_dup(g_std_2emap_2eempty_get())});
  return (g_heff_2eelab_2eunify_2erenameTypeF_24s1456990367x163293889(heff_dup(v_g_240), v_occursM_241, v_t_248, heff_dup(heff_rfield(v_entry_243, 0)), heff_dup(v_hd_246), heff_clo_n(g_heff_2eelab_2eunify_2esolveWithPruned_24s223240292x504960050_lam0, 1, 7, (V[]){v_kept_245, v_g_240, v_entry_243, v_hd_246, v_n_244, v_storeM_242, v_k_247})));
}
V g_heff_2eelab_2eunify_2esolveWithPruned_24s223240292x504960050_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2esolveWithPruned_24s223240292x504960050(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
}
V g_heff_2eelab_2eunify_2esolveWithPruned_24s223240292x504960050_lam3(V self, V *args) {
  V v_x_2428 = args[0];
  V v_k_247 = heff_env(self)[0];
  V v_v_2426 = heff_env(self)[1];
  heff_clo_take(self, 2);
  heff_drop(v_x_2428);
  V f_ = v_k_247;
  args[0] = v_v_2426;
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2esolveWithPruned_24s223240292x504960050_lam2(V self, V *args) {
  V v_x_2427 = args[0];
  V v_storeM_242 = heff_env(self)[0];
  V v_t_2421 = heff_env(self)[1];
  V v_hd_246 = heff_env(self)[2];
  V v_k_247 = heff_env(self)[3];
  V v_v_2426 = heff_env(self)[4];
  heff_clo_take(self, 5);
  heff_drop(v_x_2427);
  return (g_heff_2eelab_2eunify_2etraceSolve_24s1295917126x1338807046(v_storeM_242, v_t_2421, v_hd_246, heff_clo_n(g_heff_2eelab_2eunify_2esolveWithPruned_24s223240292x504960050_lam3, 1, 2, (V[]){v_k_247, v_v_2426})));
}
V g_heff_2eelab_2eunify_2esolveWithPruned_24s223240292x504960050_lam1(V self, V *args) {
  V v_x_2418 = args[0];
  V v_n_244 = heff_env(self)[0];
  V v_kept_245 = heff_env(self)[1];
  V v_x_249 = heff_env(self)[2];
  V v_g_240 = heff_env(self)[3];
  V v_storeM_242 = heff_env(self)[4];
  V v_hd_246 = heff_env(self)[5];
  V v_k_247 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2419 = (g_list_2emap_24s1947501783x1475115781(heff_dup(v_n_244), MK_INT(1LL), v_kept_245));
  V v_t_2420 = heff_tag_n(TAG_SMetaApp, 3, (V[]){v_x_2418, heff_arrayFromList(v_t_2419), v_x_249});
  V v_t_2421 = (g_heff_2eelab_2eunify_2elamsU(v_n_244, v_t_2420));
  V v_x1_2422 = heff_tr(g_heff_2eelab_2eeval_2eevalTermF(heff_dup(g_heff_2eelab_2eeval_2eevaluator_get()), v_g_240, NTAG(TAG_N), heff_dup(v_t_2421), NTAG(TAG_LNil)));
  V v_v_2426;
  switch (heff_tag_of(v_x1_2422)) {
  case TAG_Nom: {
    V v_x_2423 = heff_field(v_x1_2422, 0);
    heff_take_n(v_x1_2422, 1ULL, 1);
    v_v_2426 = v_x_2423;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_2422, 0ULL, 1);
    v_v_2426 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_2425 = heff_field(v_x1_2422, 0);
    heff_take_n(v_x1_2422, 1ULL, 1);
    v_v_2426 = v_x_2425;
    break;
  }
  default: heff_nomatch(v_x1_2422);
  }
  return (g_heff_2eelab_2eunify_2estoreSol_24s491818833x937743531(heff_dup(v_storeM_242), heff_dup(v_v_2426), heff_dup(v_t_2421), heff_dup(v_hd_246), heff_clo_n(g_heff_2eelab_2eunify_2esolveWithPruned_24s223240292x504960050_lam2, 1, 5, (V[]){v_storeM_242, v_t_2421, v_hd_246, v_k_247, v_v_2426})));
}
V g_heff_2eelab_2eunify_2esolveWithPruned_24s223240292x504960050_lam0(V self, V *args) {
  V v_x_249 = args[0];
  V v_kept_245 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_entry_243 = heff_env(self)[2];
  V v_hd_246 = heff_env(self)[3];
  V v_n_244 = heff_env(self)[4];
  V v_storeM_242 = heff_env(self)[5];
  V v_k_247 = heff_env(self)[6];
  heff_clo_take(self, 7);
  V v_t_2410 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_kept_245));
  HeffT2 v_t_2411 = (g_heff_2eelab_2eeval_2eevalTypeF_24s2027165288x718423980_24cpr(heff_dup(v_g_240), NTAG(TAG_N), heff_dup(v_x_249), NTAG(TAG_LNil)));
  {
    V v_field_2413 = v_t_2411.f[1];
    int64_t v_tag_2412 = ((int64_t)v_t_2411.f[0]);
    V v_t_2417;
    if ((v_tag_2412 == ((int64_t)0ULL))) {
      V v_x_2414 = v_field_2413;
      v_t_2417 = v_x_2414;
    } else {
      if ((v_tag_2412 == ((int64_t)1ULL))) {
        V v_x11_2415 = v_field_2413;
        heff_drop(v_x11_2415);
        v_t_2417 = heff_abandon();
      } else {
        V v_x_2416 = v_field_2413;
        v_t_2417 = v_x_2416;
      }
    }
    return (g_heff_2eelab_2eunify_2enewMetaFrom_24s2099433266x859676608(v_entry_243, v_t_2410, v_t_2417, heff_dup(v_hd_246), heff_clo_n(g_heff_2eelab_2eunify_2esolveWithPruned_24s223240292x504960050_lam1, 1, 7, (V[]){v_n_244, v_kept_245, v_x_249, v_g_240, v_storeM_242, v_hd_246, v_k_247})));
  }
}
V g_heff_2eelab_2eunify_2erenameCloTy_24s319279822x1150937735_lam0(V self, V *args);
V g_heff_2eelab_2eunify_2erenameCloTy_24s319279822x1150937735_lam1(V self, V *args);
V g_heff_2eelab_2eunify_2erenameCloTy_24s319279822x1150937735_lam4(V self, V *args);
V g_heff_2eelab_2eunify_2erenameCloTy_24s319279822x1150937735_lam3(V self, V *args);
V g_heff_2eelab_2eunify_2erenameCloTy_24s319279822x1150937735_lam5(V self, V *args);
V g_heff_2eelab_2eunify_2erenameCloTy_24s319279822x1150937735_lam2(V self, V *args);
V g_heff_2eelab_2eunify_2erenameCloTy_24s319279822x1150937735_lam8(V self, V *args);
V g_heff_2eelab_2eunify_2erenameCloTy_24s319279822x1150937735_lam7(V self, V *args);
V g_heff_2eelab_2eunify_2erenameCloTy_24s319279822x1150937735_lam9(V self, V *args);
V g_heff_2eelab_2eunify_2erenameCloTy_24s319279822x1150937735_lam6(V self, V *args);
Clo g_heff_2eelab_2eunify_2erenameCloTy_24s319279822x1150937735_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2erenameCloTy_24s319279822x1150937735_entry, 5, 0};

V g_heff_2eelab_2eunify_2erenameCloTy_24s319279822x1150937735(V v_g_240, V v_m_241, V v_pr_242, V v_dom_243, V v_x6_244) {
top: ;
  switch (heff_tag_of(v_x6_244)) {
  case TAG_MkClo: {
    V v_x_245 = heff_field(v_x6_244, 0);
    V v_l_246 = heff_field(v_x6_244, 1);
    V v_f_247 = heff_field(v_x6_244, 2);
    heff_take_n(v_x6_244, 7ULL, 3);
    V v_t_248 = heff_intAdd(heff_dup(heff_rfield(v_pr_242, 0)), MK_INT(1LL));
    V v_t_249 = heff_intAdd(heff_dup(heff_rfield(v_pr_242, 1)), MK_INT(1LL));
    V v_t_2410 = (g_std_2emap_2einsert_24s170109517x1206653089(heff_take_field(v_pr_242, 2), heff_dup(heff_rfield(v_pr_242, 0)), heff_take_field(v_pr_242, 1)));
    V v_pr_2411 = heff_rec_n(3, shape_dom__cod__ren, (V[]){v_t_248, v_t_249, v_t_2410});
    V v_t_2412 = heff_tag_n(TAG_HLocal, 1, (V[]){heff_get_n(v_pr_242, 0, 3)});
    V v_v_2414 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(v_t_2412, NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2eunify_2erenameCloTy_24s319279822x1150937735_lam0, 1, 1, (V[]){v_dom_243}), NTAG(TAG_Nothing)));
    V v_t_2416 = heff_tr(heff_call(v_f_247, 1, (V[]){heff_tag_n(TAG_LSnoc, 2, (V[]){v_l_246, heff_clo_n(g_heff_2eelab_2eunify_2erenameCloTy_24s319279822x1150937735_lam1, 1, 1, (V[]){v_v_2414})})}));
    return heff_clo_n(g_heff_2eelab_2eunify_2erenameCloTy_24s319279822x1150937735_lam2, 2, 5, (V[]){v_t_2416, v_g_240, v_m_241, v_pr_2411, v_x_245});
  }
  case TAG_CloConst: {
    V v_t_2427 = heff_field(v_x6_244, 0);
    heff_take_n(v_x6_244, 1ULL, 1);
    heff_drop(v_dom_243);
    return heff_clo_n(g_heff_2eelab_2eunify_2erenameCloTy_24s319279822x1150937735_lam6, 2, 4, (V[]){v_t_2427, v_g_240, v_m_241, v_pr_242});
  }
  default: return heff_nomatch(v_x6_244);
  }
}
V g_heff_2eelab_2eunify_2erenameCloTy_24s319279822x1150937735_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2erenameCloTy_24s319279822x1150937735(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2eelab_2eunify_2erenameCloTy_24s319279822x1150937735_lam0(V self, V *args) {
  V v_u_2413 = args[0];
  V v_dom_243 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2413);
  return v_dom_243;
}
V g_heff_2eelab_2eunify_2erenameCloTy_24s319279822x1150937735_lam1(V self, V *args) {
  V v_u_2415 = args[0];
  V v_v_2414 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_2415);
  return v_v_2414;
}
V g_heff_2eelab_2eunify_2erenameCloTy_24s319279822x1150937735_lam4(V self, V *args) {
  V v_x_2424 = args[0];
  V v_k_2423 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_2423;
  args[0] = heff_tag_n(TAG_SIsTy, 1, (V[]){v_x_2424});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameCloTy_24s319279822x1150937735_lam3(V self, V *args) {
  V v_hd_2422 = args[0];
  V v_k_2423 = args[1];
  V v_g_240 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  V v_pr_2411 = heff_env(self)[2];
  V v_a_2421 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2eelab_2eunify_2erenameTypeF_24s1456990367x163293889(v_g_240, v_m_241, v_pr_2411, v_a_2421, v_hd_2422, heff_clo_n(g_heff_2eelab_2eunify_2erenameCloTy_24s319279822x1150937735_lam4, 1, 1, (V[]){v_k_2423})));
}
V g_heff_2eelab_2eunify_2erenameCloTy_24s319279822x1150937735_lam5(V self, V *args) {
  V v_x_2426 = args[0];
  V v_k_2418 = heff_env(self)[0];
  V v_x_245 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V f_ = v_k_2418;
  args[0] = heff_tag_n(TAG_MkAbs, 2, (V[]){v_x_245, v_x_2426});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameCloTy_24s319279822x1150937735_lam2(V self, V *args) {
  V v_hd_2417 = args[0];
  V v_k_2418 = args[1];
  V v_t_2416 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_m_241 = heff_env(self)[2];
  V v_pr_2411 = heff_env(self)[3];
  V v_x_245 = heff_env(self)[4];
  heff_clo_take(self, 5);
  V v_t_2425;
  switch (heff_tag_of(v_t_2416)) {
  case TAG_Nom: {
    V v_a_2419 = heff_field(v_t_2416, 0);
    heff_take_n(v_t_2416, 1ULL, 1);
    v_t_2425 = heff_tr(heff_call(((V)&g_heff_2eelab_2eunify_2erenameTypeF_24s1456990367x163293889_clo), 4, (V[]){v_g_240, v_m_241, v_pr_2411, v_a_2419}));
    break;
  }
  case TAG_Describe: {
    V v_a_2420 = heff_field(v_t_2416, 0);
    heff_take_n(v_t_2416, 1ULL, 1);
    v_t_2425 = heff_tr(heff_call(((V)&g_heff_2eelab_2eunify_2erenameTypeF_24s1456990367x163293889_clo), 4, (V[]){v_g_240, v_m_241, v_pr_2411, v_a_2420}));
    break;
  }
  case TAG_Become: {
    V v_a_2421 = heff_field(v_t_2416, 0);
    heff_take_n(v_t_2416, 1ULL, 1);
    v_t_2425 = heff_clo_n(g_heff_2eelab_2eunify_2erenameCloTy_24s319279822x1150937735_lam3, 2, 4, (V[]){v_g_240, v_m_241, v_pr_2411, v_a_2421});
    break;
  }
  default: heff_nomatch(v_t_2416);
  }
  V f_ = v_t_2425;
  args[0] = v_hd_2417;
  args[1] = heff_clo_n(g_heff_2eelab_2eunify_2erenameCloTy_24s319279822x1150937735_lam5, 1, 2, (V[]){v_k_2418, v_x_245});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
V g_heff_2eelab_2eunify_2erenameCloTy_24s319279822x1150937735_lam8(V self, V *args) {
  V v_x_2435 = args[0];
  V v_k_2434 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_2434;
  args[0] = heff_tag_n(TAG_SIsTy, 1, (V[]){v_x_2435});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameCloTy_24s319279822x1150937735_lam7(V self, V *args) {
  V v_hd_2433 = args[0];
  V v_k_2434 = args[1];
  V v_g_240 = heff_env(self)[0];
  V v_m_241 = heff_env(self)[1];
  V v_pr_242 = heff_env(self)[2];
  V v_a_2432 = heff_env(self)[3];
  heff_clo_take(self, 4);
  return (g_heff_2eelab_2eunify_2erenameTypeF_24s1456990367x163293889(v_g_240, v_m_241, v_pr_242, v_a_2432, v_hd_2433, heff_clo_n(g_heff_2eelab_2eunify_2erenameCloTy_24s319279822x1150937735_lam8, 1, 1, (V[]){v_k_2434})));
}
V g_heff_2eelab_2eunify_2erenameCloTy_24s319279822x1150937735_lam9(V self, V *args) {
  V v_x_2437 = args[0];
  V v_k_2429 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V f_ = v_k_2429;
  args[0] = heff_tag_n(TAG_AbsConst, 1, (V[]){v_x_2437});
  if (heff_exact(f_, 1, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 1, args);
}
V g_heff_2eelab_2eunify_2erenameCloTy_24s319279822x1150937735_lam6(V self, V *args) {
  V v_hd_2428 = args[0];
  V v_k_2429 = args[1];
  V v_t_2427 = heff_env(self)[0];
  V v_g_240 = heff_env(self)[1];
  V v_m_241 = heff_env(self)[2];
  V v_pr_242 = heff_env(self)[3];
  heff_clo_take(self, 4);
  V v_t_2436;
  switch (heff_tag_of(v_t_2427)) {
  case TAG_Nom: {
    V v_a_2430 = heff_field(v_t_2427, 0);
    heff_take_n(v_t_2427, 1ULL, 1);
    v_t_2436 = heff_tr(heff_call(((V)&g_heff_2eelab_2eunify_2erenameTypeF_24s1456990367x163293889_clo), 4, (V[]){v_g_240, v_m_241, v_pr_242, v_a_2430}));
    break;
  }
  case TAG_Describe: {
    V v_a_2431 = heff_field(v_t_2427, 0);
    heff_take_n(v_t_2427, 1ULL, 1);
    v_t_2436 = heff_tr(heff_call(((V)&g_heff_2eelab_2eunify_2erenameTypeF_24s1456990367x163293889_clo), 4, (V[]){v_g_240, v_m_241, v_pr_242, v_a_2431}));
    break;
  }
  case TAG_Become: {
    V v_a_2432 = heff_field(v_t_2427, 0);
    heff_take_n(v_t_2427, 1ULL, 1);
    v_t_2436 = heff_clo_n(g_heff_2eelab_2eunify_2erenameCloTy_24s319279822x1150937735_lam7, 2, 4, (V[]){v_g_240, v_m_241, v_pr_242, v_a_2432});
    break;
  }
  default: heff_nomatch(v_t_2427);
  }
  V f_ = v_t_2436;
  args[0] = v_hd_2428;
  args[1] = heff_clo_n(g_heff_2eelab_2eunify_2erenameCloTy_24s319279822x1150937735_lam9, 1, 1, (V[]){v_k_2429});
  if (heff_exact(f_, 2, args)) HEFF_LAST return ((Clo *)f_)->fn(f_, args);
  return heff_tail(f_, 2, args);
}
HEFF_LIT(g_heff_2eelab_2eunify_2euTyRigid_24s1811274681x437693457_str0, 1, "x");
V g_heff_2eelab_2eunify_2euTyRigid_24s1811274681x437693457_lam1(V self, V *args);
V g_heff_2eelab_2eunify_2euTyRigid_24s1811274681x437693457_lam2(V self, V *args);
V g_heff_2eelab_2eunify_2euTyRigid_24s1811274681x437693457_lam3(V self, V *args);
V g_heff_2eelab_2eunify_2euTyRigid_24s1811274681x437693457_lam0(V self, V *args);
Clo g_heff_2eelab_2eunify_2euTyRigid_24s1811274681x437693457_clo = {{0x80000000u, K_CLO, 0}, g_heff_2eelab_2eunify_2euTyRigid_24s1811274681x437693457_entry, 6, 0};

V g_heff_2eelab_2eunify_2euTyRigid_24s1811274681x437693457(V v_g_240, V v_cs_241, V v_a_242, V v_b_243, V v_z_244, V v_z_245) {
top: ;
  switch (heff_tag_of(v_a_242)) {
  case TAG_VU: {
    V v_u_246 = heff_dup(heff_field(v_a_242, 0));
    heff_drop(v_g_240);
    switch (heff_tag_of(v_b_243)) {
    case TAG_VU: {
      V v_u_27_247 = heff_dup(heff_field(v_b_243, 0));
      switch (heff_tag_of(v_u_246)) {
      case TAG_SmallU: {
        switch (heff_tag_of(v_u_27_247)) {
        case TAG_SmallU: {
          heff_drop_rec(v_cs_241, 2);
          heff_drop_tag(v_a_242, 1);
          heff_drop_tag(v_b_243, 1);
          heff_drop_rec(v_z_244, 3);
          return heff_tail(v_z_245, 1, (V[]){NTAG(TAG_MkUnit)});
        }
        case TAG_LargeU: {
          V v_t_248 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
          V v_t_249 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_248})}));
          return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_249, v_z_245});
        }
        default: return heff_nomatch(v_u_27_247);
        }
      }
      case TAG_LargeU: {
        switch (heff_tag_of(v_u_27_247)) {
        case TAG_SmallU: {
          V v_t_2410 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
          V v_t_2411 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2410})}));
          return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_2411, v_z_245});
        }
        case TAG_LargeU: {
          heff_drop_rec(v_cs_241, 2);
          heff_drop_tag(v_a_242, 1);
          heff_drop_tag(v_b_243, 1);
          heff_drop_rec(v_z_244, 3);
          return heff_tail(v_z_245, 1, (V[]){NTAG(TAG_MkUnit)});
        }
        default: return heff_nomatch(v_u_27_247);
        }
      }
      default: return heff_nomatch(v_u_246);
      }
    }
    case TAG_VDecode: {
      heff_drop(v_u_246);
      V v_t_2417 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_2418 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2417})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_2418, v_z_245});
    }
    case TAG_VFunction: {
      heff_drop(v_u_246);
      V v_t_2425 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_2426 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2425})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_2426, v_z_245});
    }
    case TAG_VRecord: {
      heff_drop(v_u_246);
      V v_t_2431 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_2432 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2431})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_2432, v_z_245});
    }
    case TAG_VSum: {
      heff_drop(v_u_246);
      V v_t_2434 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_2435 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2434})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_2435, v_z_245});
    }
    case TAG_VPrimInt: {
      heff_drop(v_u_246);
      V v_t_2436 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_2437 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2436})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_2437, v_z_245});
    }
    case TAG_VPrimFloat: {
      heff_drop(v_u_246);
      V v_t_2438 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_2439 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2438})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_2439, v_z_245});
    }
    case TAG_VPrimString: {
      heff_drop(v_u_246);
      V v_t_2440 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_2441 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2440})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_2441, v_z_245});
    }
    case TAG_VPrimRune: {
      heff_drop(v_u_246);
      V v_t_2442 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_2443 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2442})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_2443, v_z_245});
    }
    case TAG_VPrimArray: {
      heff_drop(v_u_246);
      V v_t_2445 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_2446 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2445})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_2446, v_z_245});
    }
    case TAG_VFixed: {
      heff_drop(v_u_246);
      V v_t_2448 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_2449 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2448})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_2449, v_z_245});
    }
    default: return heff_nomatch(v_b_243);
    }
  }
  case TAG_VDecode: {
    V v_h_2450 = heff_dup(heff_field(v_a_242, 0));
    V v_sp_2451 = heff_dup(heff_field(v_a_242, 1));
    switch (heff_tag_of(v_b_243)) {
    case TAG_VU: {
      heff_drop(v_g_240);
      heff_drop(v_h_2450);
      heff_drop(v_sp_2451);
      V v_t_2456 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_2457 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2456})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_2457, v_z_245});
    }
    case TAG_VDecode: {
      V v_h_27_2458 = heff_field(v_b_243, 0);
      V v_sp_27_2459 = heff_field(v_b_243, 1);
      heff_take_n(v_b_243, 3ULL, 5);
      heff_drop_tag(v_a_242, 5);
      V v_t_2463 = (g_heff_2eelab_2eunify_2euBareF_24s1281116162x677276803(v_g_240, v_cs_241, v_h_2450, v_sp_2451, v_h_27_2458, v_sp_27_2459));
      return heff_tail(v_t_2463, 2, (V[]){v_z_244, v_z_245});
    }
    case TAG_VFunction: {
      heff_drop(v_g_240);
      heff_drop(v_h_2450);
      heff_drop(v_sp_2451);
      V v_t_2470 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_2471 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2470})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_2471, v_z_245});
    }
    case TAG_VRecord: {
      heff_drop(v_g_240);
      heff_drop(v_h_2450);
      heff_drop(v_sp_2451);
      V v_t_2476 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_2477 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2476})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_2477, v_z_245});
    }
    case TAG_VSum: {
      heff_drop(v_g_240);
      heff_drop(v_h_2450);
      heff_drop(v_sp_2451);
      V v_t_2479 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_2480 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2479})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_2480, v_z_245});
    }
    case TAG_VPrimInt: {
      heff_drop(v_g_240);
      heff_drop(v_h_2450);
      heff_drop(v_sp_2451);
      V v_t_2481 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_2482 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2481})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_2482, v_z_245});
    }
    case TAG_VPrimFloat: {
      heff_drop(v_g_240);
      heff_drop(v_h_2450);
      heff_drop(v_sp_2451);
      V v_t_2483 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_2484 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2483})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_2484, v_z_245});
    }
    case TAG_VPrimString: {
      heff_drop(v_g_240);
      heff_drop(v_h_2450);
      heff_drop(v_sp_2451);
      V v_t_2485 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_2486 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2485})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_2486, v_z_245});
    }
    case TAG_VPrimRune: {
      heff_drop(v_g_240);
      heff_drop(v_h_2450);
      heff_drop(v_sp_2451);
      V v_t_2487 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_2488 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2487})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_2488, v_z_245});
    }
    case TAG_VPrimArray: {
      heff_drop(v_g_240);
      heff_drop(v_h_2450);
      heff_drop(v_sp_2451);
      V v_t_2490 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_2491 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2490})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_2491, v_z_245});
    }
    case TAG_VFixed: {
      heff_drop(v_g_240);
      heff_drop(v_h_2450);
      heff_drop(v_sp_2451);
      V v_t_2493 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_2494 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_2493})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_2494, v_z_245});
    }
    default: return heff_nomatch(v_b_243);
    }
  }
  case TAG_VFunction: {
    V v_level_2495 = heff_dup(heff_field(v_a_242, 0));
    V v_dom_2496 = heff_dup(heff_field(v_a_242, 1));
    V v_cod_2497 = heff_dup(heff_field(v_a_242, 2));
    V v_implicit_2498 = heff_dup(heff_field(v_a_242, 3));
    switch (heff_tag_of(v_b_243)) {
    case TAG_VU: {
      heff_drop(v_g_240);
      heff_drop(v_level_2495);
      heff_drop(v_dom_2496);
      heff_drop(v_cod_2497);
      heff_drop(v_implicit_2498);
      V v_t_24102 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24103 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24102})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24103, v_z_245});
    }
    case TAG_VDecode: {
      heff_drop(v_g_240);
      heff_drop(v_level_2495);
      heff_drop(v_dom_2496);
      heff_drop(v_cod_2497);
      heff_drop(v_implicit_2498);
      V v_t_24109 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24110 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24109})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24110, v_z_245});
    }
    case TAG_VFunction: {
      V v_level_27_24111 = heff_dup(heff_field(v_b_243, 0));
      V v_dom_27_24112 = heff_dup(heff_field(v_b_243, 1));
      V v_cod_27_24113 = heff_dup(heff_field(v_b_243, 2));
      V v_implicit_27_24114 = heff_dup(heff_field(v_b_243, 3));
      V v_t_24117 = ({ V a_0 = v_level_2495; V a_1 = v_level_27_24111; V r_ = (g_heff_2eelab_2eparams_2eeqLevel(a_0, a_1)); heff_drop(v_level_2495); heff_drop(v_level_27_24111); r_; });
      V v_t_24118;
      if ((heff_dup(v_t_24117) == NTAG(TAG_True))) {
        heff_drop(v_t_24117);
        switch (heff_tag_of(v_implicit_2498)) {
        case TAG_Expl: {
          switch (heff_tag_of(v_implicit_27_24114)) {
          case TAG_Expl: {
            v_t_24118 = NTAG(TAG_True);
            break;
          }
          case TAG_Impl: {
            v_t_24118 = NTAG(TAG_False);
            break;
          }
          case TAG_Inst: {
            v_t_24118 = NTAG(TAG_False);
            break;
          }
          default: heff_nomatch(v_implicit_27_24114);
          }
          break;
        }
        case TAG_Impl: {
          switch (heff_tag_of(v_implicit_27_24114)) {
          case TAG_Expl: {
            v_t_24118 = NTAG(TAG_False);
            break;
          }
          case TAG_Impl: {
            v_t_24118 = NTAG(TAG_True);
            break;
          }
          case TAG_Inst: {
            v_t_24118 = NTAG(TAG_False);
            break;
          }
          default: heff_nomatch(v_implicit_27_24114);
          }
          break;
        }
        case TAG_Inst: {
          switch (heff_tag_of(v_implicit_27_24114)) {
          case TAG_Expl: {
            v_t_24118 = NTAG(TAG_False);
            break;
          }
          case TAG_Impl: {
            v_t_24118 = NTAG(TAG_False);
            break;
          }
          case TAG_Inst: {
            v_t_24118 = NTAG(TAG_True);
            break;
          }
          default: heff_nomatch(v_implicit_27_24114);
          }
          break;
        }
        default: heff_nomatch(v_implicit_2498);
        }
      } else {
        heff_drop(v_implicit_2498);
        heff_drop(v_implicit_27_24114);
        heff_drop(v_t_24117);
        v_t_24118 = NTAG(TAG_False);
      }
      if ((heff_dup(v_t_24118) == NTAG(TAG_True))) {
        heff_drop_tag(v_a_242, 6);
        heff_drop_tag(v_b_243, 6);
        heff_drop(v_t_24118);
        HEFF_LAST return g_heff_2eelab_2eunify_2euTypeF_24s446543853x1048233883(heff_dup(v_g_240), heff_dup(v_cs_241), heff_dup(v_dom_2496), v_dom_27_24112, heff_dup(v_z_244), heff_clo_n(g_heff_2eelab_2eunify_2euTyRigid_24s1811274681x437693457_lam0, 1, 7, (V[]){v_cs_241, v_dom_2496, v_cod_2497, v_cod_27_24113, v_g_240, v_z_244, v_z_245}));
      } else {
        heff_drop(v_g_240);
        heff_drop(v_dom_2496);
        heff_drop(v_cod_2497);
        heff_drop(v_dom_27_24112);
        heff_drop(v_cod_27_24113);
        heff_drop(v_t_24118);
        V v_t_24150 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
        V v_t_24151 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24150})}));
        return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24151, v_z_245});
      }
    }
    case TAG_VRecord: {
      heff_drop(v_g_240);
      heff_drop(v_level_2495);
      heff_drop(v_dom_2496);
      heff_drop(v_cod_2497);
      heff_drop(v_implicit_2498);
      V v_t_24156 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24157 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24156})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24157, v_z_245});
    }
    case TAG_VSum: {
      heff_drop(v_g_240);
      heff_drop(v_level_2495);
      heff_drop(v_dom_2496);
      heff_drop(v_cod_2497);
      heff_drop(v_implicit_2498);
      V v_t_24159 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24160 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24159})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24160, v_z_245});
    }
    case TAG_VPrimInt: {
      heff_drop(v_g_240);
      heff_drop(v_level_2495);
      heff_drop(v_dom_2496);
      heff_drop(v_cod_2497);
      heff_drop(v_implicit_2498);
      V v_t_24161 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24162 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24161})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24162, v_z_245});
    }
    case TAG_VPrimFloat: {
      heff_drop(v_g_240);
      heff_drop(v_level_2495);
      heff_drop(v_dom_2496);
      heff_drop(v_cod_2497);
      heff_drop(v_implicit_2498);
      V v_t_24163 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24164 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24163})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24164, v_z_245});
    }
    case TAG_VPrimString: {
      heff_drop(v_g_240);
      heff_drop(v_level_2495);
      heff_drop(v_dom_2496);
      heff_drop(v_cod_2497);
      heff_drop(v_implicit_2498);
      V v_t_24165 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24166 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24165})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24166, v_z_245});
    }
    case TAG_VPrimRune: {
      heff_drop(v_g_240);
      heff_drop(v_level_2495);
      heff_drop(v_dom_2496);
      heff_drop(v_cod_2497);
      heff_drop(v_implicit_2498);
      V v_t_24167 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24168 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24167})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24168, v_z_245});
    }
    case TAG_VPrimArray: {
      heff_drop(v_g_240);
      heff_drop(v_level_2495);
      heff_drop(v_dom_2496);
      heff_drop(v_cod_2497);
      heff_drop(v_implicit_2498);
      V v_t_24170 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24171 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24170})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24171, v_z_245});
    }
    case TAG_VFixed: {
      heff_drop(v_g_240);
      heff_drop(v_level_2495);
      heff_drop(v_dom_2496);
      heff_drop(v_cod_2497);
      heff_drop(v_implicit_2498);
      V v_t_24173 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24174 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24173})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24174, v_z_245});
    }
    default: return heff_nomatch(v_b_243);
    }
  }
  case TAG_VRecord: {
    heff_drop(v_g_240);
    V v_t_24179 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
    V v_t_24180 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24179})}));
    return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24180, v_z_245});
  }
  case TAG_VSum: {
    heff_drop(v_g_240);
    V v_t_24182 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
    V v_t_24183 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24182})}));
    return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24183, v_z_245});
  }
  case TAG_VPrimInt: {
    heff_drop(v_g_240);
    switch (heff_tag_of(v_b_243)) {
    case TAG_VU: {
      V v_t_24185 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24186 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24185})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24186, v_z_245});
    }
    case TAG_VDecode: {
      V v_t_24192 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24193 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24192})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24193, v_z_245});
    }
    case TAG_VFunction: {
      V v_t_24200 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24201 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24200})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24201, v_z_245});
    }
    case TAG_VRecord: {
      V v_t_24206 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24207 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24206})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24207, v_z_245});
    }
    case TAG_VSum: {
      V v_t_24209 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24210 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24209})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24210, v_z_245});
    }
    case TAG_VPrimInt: {
      heff_drop_rec(v_cs_241, 2);
      heff_drop_rec(v_z_244, 3);
      return heff_tail(v_z_245, 1, (V[]){NTAG(TAG_MkUnit)});
    }
    case TAG_VPrimFloat: {
      V v_t_24211 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24212 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24211})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24212, v_z_245});
    }
    case TAG_VPrimString: {
      V v_t_24213 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24214 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24213})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24214, v_z_245});
    }
    case TAG_VPrimRune: {
      V v_t_24215 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24216 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24215})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24216, v_z_245});
    }
    case TAG_VPrimArray: {
      V v_t_24218 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24219 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24218})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24219, v_z_245});
    }
    case TAG_VFixed: {
      V v_t_24221 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24222 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24221})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24222, v_z_245});
    }
    default: return heff_nomatch(v_b_243);
    }
  }
  case TAG_VPrimFloat: {
    heff_drop(v_g_240);
    switch (heff_tag_of(v_b_243)) {
    case TAG_VU: {
      V v_t_24224 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24225 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24224})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24225, v_z_245});
    }
    case TAG_VDecode: {
      V v_t_24231 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24232 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24231})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24232, v_z_245});
    }
    case TAG_VFunction: {
      V v_t_24239 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24240 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24239})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24240, v_z_245});
    }
    case TAG_VRecord: {
      V v_t_24245 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24246 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24245})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24246, v_z_245});
    }
    case TAG_VSum: {
      V v_t_24248 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24249 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24248})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24249, v_z_245});
    }
    case TAG_VPrimInt: {
      V v_t_24250 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24251 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24250})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24251, v_z_245});
    }
    case TAG_VPrimFloat: {
      heff_drop_rec(v_cs_241, 2);
      heff_drop_rec(v_z_244, 3);
      return heff_tail(v_z_245, 1, (V[]){NTAG(TAG_MkUnit)});
    }
    case TAG_VPrimString: {
      V v_t_24252 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24253 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24252})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24253, v_z_245});
    }
    case TAG_VPrimRune: {
      V v_t_24254 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24255 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24254})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24255, v_z_245});
    }
    case TAG_VPrimArray: {
      V v_t_24257 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24258 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24257})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24258, v_z_245});
    }
    case TAG_VFixed: {
      V v_t_24260 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24261 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24260})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24261, v_z_245});
    }
    default: return heff_nomatch(v_b_243);
    }
  }
  case TAG_VPrimString: {
    heff_drop(v_g_240);
    switch (heff_tag_of(v_b_243)) {
    case TAG_VU: {
      V v_t_24263 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24264 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24263})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24264, v_z_245});
    }
    case TAG_VDecode: {
      V v_t_24270 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24271 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24270})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24271, v_z_245});
    }
    case TAG_VFunction: {
      V v_t_24278 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24279 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24278})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24279, v_z_245});
    }
    case TAG_VRecord: {
      V v_t_24284 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24285 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24284})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24285, v_z_245});
    }
    case TAG_VSum: {
      V v_t_24287 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24288 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24287})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24288, v_z_245});
    }
    case TAG_VPrimInt: {
      V v_t_24289 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24290 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24289})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24290, v_z_245});
    }
    case TAG_VPrimFloat: {
      V v_t_24291 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24292 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24291})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24292, v_z_245});
    }
    case TAG_VPrimString: {
      heff_drop_rec(v_cs_241, 2);
      heff_drop_rec(v_z_244, 3);
      return heff_tail(v_z_245, 1, (V[]){NTAG(TAG_MkUnit)});
    }
    case TAG_VPrimRune: {
      V v_t_24293 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24294 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24293})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24294, v_z_245});
    }
    case TAG_VPrimArray: {
      V v_t_24296 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24297 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24296})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24297, v_z_245});
    }
    case TAG_VFixed: {
      V v_t_24299 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24300 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24299})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24300, v_z_245});
    }
    default: return heff_nomatch(v_b_243);
    }
  }
  case TAG_VPrimRune: {
    heff_drop(v_g_240);
    V v_t_24320;
    switch (heff_tag_of(v_b_243)) {
    case TAG_VU: {
      v_t_24320 = NTAG(TAG_False);
      break;
    }
    case TAG_VDecode: {
      v_t_24320 = NTAG(TAG_False);
      break;
    }
    case TAG_VFunction: {
      v_t_24320 = NTAG(TAG_False);
      break;
    }
    case TAG_VRecord: {
      v_t_24320 = NTAG(TAG_False);
      break;
    }
    case TAG_VSum: {
      v_t_24320 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimInt: {
      v_t_24320 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimFloat: {
      v_t_24320 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimString: {
      v_t_24320 = NTAG(TAG_False);
      break;
    }
    case TAG_VPrimRune: {
      v_t_24320 = NTAG(TAG_True);
      break;
    }
    case TAG_VPrimArray: {
      v_t_24320 = NTAG(TAG_False);
      break;
    }
    case TAG_VFixed: {
      v_t_24320 = NTAG(TAG_False);
      break;
    }
    default: heff_nomatch(v_b_243);
    }
    if ((heff_dup(v_t_24320) == NTAG(TAG_True))) {
      heff_drop_rec(v_cs_241, 2);
      heff_drop(v_b_243);
      heff_drop_rec(v_z_244, 3);
      heff_drop(v_t_24320);
      return heff_tail(v_z_245, 1, (V[]){NTAG(TAG_MkUnit)});
    } else {
      heff_drop(v_t_24320);
      V v_t_24321 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24322 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24321})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24322, v_z_245});
    }
  }
  case TAG_VPrimArray: {
    V v_x_24323 = heff_dup(heff_field(v_a_242, 0));
    switch (heff_tag_of(v_b_243)) {
    case TAG_VU: {
      heff_drop(v_g_240);
      heff_drop(v_x_24323);
      V v_t_24325 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24326 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24325})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24326, v_z_245});
    }
    case TAG_VDecode: {
      heff_drop(v_g_240);
      heff_drop(v_x_24323);
      V v_t_24332 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24333 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24332})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24333, v_z_245});
    }
    case TAG_VFunction: {
      heff_drop(v_g_240);
      heff_drop(v_x_24323);
      V v_t_24340 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24341 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24340})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24341, v_z_245});
    }
    case TAG_VRecord: {
      heff_drop(v_g_240);
      heff_drop(v_x_24323);
      V v_t_24346 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24347 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24346})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24347, v_z_245});
    }
    case TAG_VSum: {
      heff_drop(v_g_240);
      heff_drop(v_x_24323);
      V v_t_24349 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24350 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24349})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24350, v_z_245});
    }
    case TAG_VPrimInt: {
      heff_drop(v_g_240);
      heff_drop(v_x_24323);
      V v_t_24351 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24352 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24351})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24352, v_z_245});
    }
    case TAG_VPrimFloat: {
      heff_drop(v_g_240);
      heff_drop(v_x_24323);
      V v_t_24353 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24354 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24353})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24354, v_z_245});
    }
    case TAG_VPrimString: {
      heff_drop(v_g_240);
      heff_drop(v_x_24323);
      V v_t_24355 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24356 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24355})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24356, v_z_245});
    }
    case TAG_VPrimRune: {
      heff_drop(v_g_240);
      heff_drop(v_x_24323);
      V v_t_24357 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24358 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24357})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24358, v_z_245});
    }
    case TAG_VPrimArray: {
      V v_y_24359 = heff_field(v_b_243, 0);
      heff_take_n(v_b_243, 1ULL, 1);
      heff_drop_tag(v_a_242, 1);
      HEFF_LAST return g_heff_2eelab_2eunify_2euTypeF_24s446543853x1048233883(v_g_240, v_cs_241, v_x_24323, v_y_24359, v_z_244, v_z_245);
    }
    case TAG_VFixed: {
      heff_drop(v_g_240);
      heff_drop(v_x_24323);
      V v_t_24361 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24362 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24361})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24362, v_z_245});
    }
    default: return heff_nomatch(v_b_243);
    }
  }
  case TAG_VFixed: {
    V v_w_24363 = heff_dup(heff_field(v_a_242, 0));
    heff_drop(v_g_240);
    V v_t_24364 = ({ V a_0 = v_w_24363; V a_1 = v_b_243; V r_ = (g_heff_2eelab_2evalue_2eisFixed(a_0, a_1)); heff_drop(v_w_24363); r_; });
    if ((heff_dup(v_t_24364) == NTAG(TAG_True))) {
      heff_drop_rec(v_cs_241, 2);
      heff_drop_tag(v_a_242, 1);
      heff_drop(v_b_243);
      heff_drop_rec(v_z_244, 3);
      heff_drop(v_t_24364);
      return heff_tail(v_z_245, 1, (V[]){NTAG(TAG_MkUnit)});
    } else {
      heff_drop(v_t_24364);
      V v_t_24365 = heff_tag_n(TAG_Throw, 1, (V[]){heff_tag_n(TAG_UnequalTys, 3, (V[]){v_cs_241, v_a_242, v_b_243})});
      V v_t_24366 = heff_tr(heff_call(heff_take_field(v_z_244, 2), 1, (V[]){heff_tag_n(TAG_InR, 1, (V[]){v_t_24365})}));
      return heff_tail(heff_get_n(v_z_244, 1, 3), 2, (V[]){v_t_24366, v_z_245});
    }
  }
  default: return heff_nomatch(v_a_242);
  }
}
V g_heff_2eelab_2eunify_2euTyRigid_24s1811274681x437693457_entry(V self, V *a) {
  (void)self;
  return g_heff_2eelab_2eunify_2euTyRigid_24s1811274681x437693457(a[0], a[1], a[2], a[3], a[4], a[5]);
}
V g_heff_2eelab_2eunify_2euTyRigid_24s1811274681x437693457_lam1(V self, V *args) {
  V v_u_24121 = args[0];
  V v_dom_2496 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_u_24121);
  return v_dom_2496;
}
V g_heff_2eelab_2eunify_2euTyRigid_24s1811274681x437693457_lam2(V self, V *args) {
  V v_w_24126 = args[0];
  V v_v_24122 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_w_24126);
  return v_v_24122;
}
V g_heff_2eelab_2eunify_2euTyRigid_24s1811274681x437693457_lam3(V self, V *args) {
  V v_w_24136 = args[0];
  V v_v_24122 = heff_env(self)[0];
  heff_clo_take(self, 1);
  heff_drop(v_w_24136);
  return v_v_24122;
}
V g_heff_2eelab_2eunify_2euTyRigid_24s1811274681x437693457_lam0(V self, V *args) {
  V v_x_24119 = args[0];
  V v_cs_241 = heff_env(self)[0];
  V v_dom_2496 = heff_env(self)[1];
  V v_cod_2497 = heff_env(self)[2];
  V v_cod_27_24113 = heff_env(self)[3];
  V v_g_240 = heff_env(self)[4];
  V v_z_244 = heff_env(self)[5];
  V v_z_245 = heff_env(self)[6];
  heff_clo_take(self, 7);
  heff_drop(v_x_24119);
  V v_t_24120 = heff_tag_n(TAG_HLocal, 1, (V[]){heff_dup(heff_rfield(v_cs_241, 0))});
  V v_v_24122 = (g_heff_2eelab_2evalue_2emkNeu_24s920535508x681463190(v_t_24120, NTAG(TAG_SpId), heff_clo_n(g_heff_2eelab_2eunify_2euTyRigid_24s1811274681x437693457_lam1, 1, 1, (V[]){v_dom_2496}), NTAG(TAG_Nothing)));
  V v_x1_24128;
  switch (heff_tag_of(v_cod_2497)) {
  case TAG_MkClo: {
    V v_vs_24124 = heff_dup(heff_field(v_cod_2497, 1));
    V v_body_24125 = heff_dup(heff_field(v_cod_2497, 2));
    v_x1_24128 = heff_tr(heff_call(v_body_24125, 1, (V[]){heff_tag_n(TAG_LSnoc, 2, (V[]){v_vs_24124, heff_clo_n(g_heff_2eelab_2eunify_2euTyRigid_24s1811274681x437693457_lam2, 1, 1, (V[]){heff_dup(v_v_24122)})})}));
    break;
  }
  case TAG_CloConst: {
    V v_body_24127 = heff_dup(heff_field(v_cod_2497, 0));
    v_x1_24128 = v_body_24127;
    break;
  }
  default: heff_nomatch(v_cod_2497);
  }
  V v_a_24132;
  switch (heff_tag_of(v_x1_24128)) {
  case TAG_Nom: {
    V v_x_24129 = heff_field(v_x1_24128, 0);
    heff_take_n(v_x1_24128, 1ULL, 1);
    v_a_24132 = v_x_24129;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_24128, 0ULL, 1);
    v_a_24132 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_24131 = heff_field(v_x1_24128, 0);
    heff_take_n(v_x1_24128, 1ULL, 1);
    v_a_24132 = v_x_24131;
    break;
  }
  default: heff_nomatch(v_x1_24128);
  }
  V v_x1_24138;
  switch (heff_tag_of(v_cod_27_24113)) {
  case TAG_MkClo: {
    V v_vs_24134 = heff_field(v_cod_27_24113, 1);
    V v_body_24135 = heff_field(v_cod_27_24113, 2);
    heff_take_n(v_cod_27_24113, 6ULL, 3);
    v_x1_24138 = heff_tr(heff_call(v_body_24135, 1, (V[]){heff_tag_n(TAG_LSnoc, 2, (V[]){v_vs_24134, heff_clo_n(g_heff_2eelab_2eunify_2euTyRigid_24s1811274681x437693457_lam3, 1, 1, (V[]){v_v_24122})})}));
    break;
  }
  case TAG_CloConst: {
    V v_body_24137 = heff_field(v_cod_27_24113, 0);
    heff_take_n(v_cod_27_24113, 1ULL, 1);
    heff_drop(v_v_24122);
    v_x1_24138 = v_body_24137;
    break;
  }
  default: heff_nomatch(v_cod_27_24113);
  }
  V v_b_24142;
  switch (heff_tag_of(v_x1_24138)) {
  case TAG_Nom: {
    V v_x_24139 = heff_field(v_x1_24138, 0);
    heff_take_n(v_x1_24138, 1ULL, 1);
    v_b_24142 = v_x_24139;
    break;
  }
  case TAG_Describe: {
    heff_take_n(v_x1_24138, 0ULL, 1);
    v_b_24142 = heff_abandon();
    break;
  }
  case TAG_Become: {
    V v_x_24141 = heff_field(v_x1_24138, 0);
    heff_take_n(v_x1_24138, 1ULL, 1);
    v_b_24142 = v_x_24141;
    break;
  }
  default: heff_nomatch(v_x1_24138);
  }
  V v_t_24143 = heff_intAdd(heff_take_field(v_cs_241, 0), MK_INT(1LL));
  V v_t_24148;
  switch (heff_tag_of(v_cod_2497)) {
  case TAG_MkClo: {
    V v_n_24144 = heff_field(v_cod_2497, 0);
    heff_take_n(v_cod_2497, 1ULL, 3);
    v_t_24148 = v_n_24144;
    break;
  }
  case TAG_CloConst: {
    heff_take_n(v_cod_2497, 0ULL, 1);
    v_t_24148 = ((V)&g_heff_2eelab_2eunify_2euTyRigid_24s1811274681x437693457_str0);
    break;
  }
  default: heff_nomatch(v_cod_2497);
  }
  V v_t_24149 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_24148, heff_get_n(v_cs_241, 1, 2)});
  return (g_heff_2eelab_2eunify_2euTypeF_24s446543853x1048233883(v_g_240, heff_rec_n(2, shape_len__names, (V[]){v_t_24143, v_t_24149}), v_a_24132, v_b_24142, v_z_244, v_z_245));
}