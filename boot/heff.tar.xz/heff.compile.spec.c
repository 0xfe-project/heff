// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EVar 52881
#define TAG_F32 16337
#define TAG_FtAny 18156
#define TAG_FtFixed 23584
#define TAG_FtFloat 38674
#define TAG_FtOther 63706
#define TAG_I16 19162
#define TAG_I32 19220
#define TAG_I64 19315
#define TAG_I8 9088
#define TAG_MkArm 55352
#define TAG_U16 30694
#define TAG_U32 30752
#define TAG_U64 30847
#define TAG_U8 9460
#define LBL_holes 300818381
#define LBL_n 328
#define LBL_ren 322325
#define LBL_vars 10107635
static uint32_t shape_ren__vars__holes__n[] = {LBL_ren, LBL_vars, LBL_holes, LBL_n};
V g_heff_2ecompile_2espec_2eallS(V, V);
V g_heff_2ecompile_2espec_2eallS_entry(V self, V *a);
extern Clo g_heff_2ecompile_2espec_2eallS_clo;
V g_heff_2ecompile_2espec_2eappendS(V, V);
V g_heff_2ecompile_2espec_2eappendS_entry(V self, V *a);
extern Clo g_heff_2ecompile_2espec_2eappendS_clo;
V g_heff_2ecompile_2espec_2eappendS_24dps(V, V, V);
V g_heff_2ecompile_2espec_2eappendS_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2espec_2eappendS_24dps_clo;
V g_heff_2ecompile_2espec_2ebindOne(V, V);
V g_heff_2ecompile_2espec_2ebindOne_entry(V self, V *a);
extern Clo g_heff_2ecompile_2espec_2ebindOne_clo;
V g_heff_2ecompile_2espec_2ecallUse(V, V, V);
V g_heff_2ecompile_2espec_2ecallUse_entry(V self, V *a);
extern Clo g_heff_2ecompile_2espec_2ecallUse_clo;
V g_heff_2ecompile_2espec_2eclosedIn(V, V);
V g_heff_2ecompile_2espec_2eclosedIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2espec_2eclosedIn_clo;
V g_heff_2ecompile_2espec_2edropAt(V, V);
V g_heff_2ecompile_2espec_2edropAt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2espec_2edropAt_clo;
V g_heff_2ecompile_2espec_2edropAt_24dps(V, V, V);
V g_heff_2ecompile_2espec_2edropAt_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2espec_2edropAt_24dps_clo;
V g_heff_2ecompile_2espec_2eelemS(V, V);
V g_heff_2ecompile_2espec_2eelemS_entry(V self, V *a);
extern Clo g_heff_2ecompile_2espec_2eelemS_clo;
V g_heff_2ecompile_2espec_2ehashGo(V, V, V, V);
V g_heff_2ecompile_2espec_2ehashGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2espec_2ehashGo_clo;
V g_heff_2ecompile_2espec_2eheadUses(V, V);
V g_heff_2ecompile_2espec_2eheadUses_entry(V self, V *a);
extern Clo g_heff_2ecompile_2espec_2eheadUses_clo;
V g_heff_2ecompile_2espec_2eisVarOf(V, V);
V g_heff_2ecompile_2espec_2eisVarOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2espec_2eisVarOf_clo;
V g_heff_2ecompile_2espec_2ekeyGo(V, V);
V g_heff_2ecompile_2espec_2ekeyGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2espec_2ekeyGo_clo;
V g_heff_2ecompile_2espec_2elabelsTo(V, V);
V g_heff_2ecompile_2espec_2elabelsTo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2espec_2elabelsTo_clo;
V g_heff_2ecompile_2espec_2elabelsTo_24dps(V, V, V);
V g_heff_2ecompile_2espec_2elabelsTo_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2espec_2elabelsTo_24dps_clo;
V g_heff_2ecompile_2espec_2eletThen(V, V, V, V);
V g_heff_2ecompile_2espec_2eletThen_entry(V self, V *a);
extern Clo g_heff_2ecompile_2espec_2eletThen_clo;
V g_heff_2ecompile_2espec_2enthS(V, V);
V g_heff_2ecompile_2espec_2enthS_entry(V self, V *a);
extern Clo g_heff_2ecompile_2espec_2enthS_clo;
V g_heff_2ecompile_2espec_2eposGo(V, V, V);
V g_heff_2ecompile_2espec_2eposGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2espec_2eposGo_clo;
V g_heff_2ecompile_2espec_2eselfArgs(V, V, V, V, V);
V g_heff_2ecompile_2espec_2eselfArgs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2espec_2eselfArgs_clo;
V g_heff_2ecompile_2espec_2eselfHead(V, V, V, V);
V g_heff_2ecompile_2espec_2eselfHead_entry(V self, V *a);
extern Clo g_heff_2ecompile_2espec_2eselfHead_clo;
V g_heff_2ecompile_2espec_2eselfTo(V, V, V, V, V);
V g_heff_2ecompile_2espec_2eselfTo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2espec_2eselfTo_clo;
V g_heff_2ecompile_2espec_2eselfTo_24dps(V, V, V, V, V, V, V);
V g_heff_2ecompile_2espec_2eselfTo_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2espec_2eselfTo_24dps_clo;
V g_heff_2ecompile_2espec_2eshapeArms(V, V, V);
V g_heff_2ecompile_2espec_2eshapeArms_entry(V self, V *a);
extern Clo g_heff_2ecompile_2espec_2eshapeArms_clo;
V g_heff_2ecompile_2espec_2eshapeGo(V, V);
V g_heff_2ecompile_2espec_2eshapeGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2espec_2eshapeGo_clo;
V g_heff_2ecompile_2espec_2eshapeMany(V, V, V);
V g_heff_2ecompile_2espec_2eshapeMany_entry(V self, V *a);
extern Clo g_heff_2ecompile_2espec_2eshapeMany_clo;
V g_heff_2ecompile_2espec_2estaticGo(V, V, V);
V g_heff_2ecompile_2espec_2estaticGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2espec_2estaticGo_clo;
V g_heff_2ecompile_2espec_2estaticGo_24dps(V, V, V, V);
V g_heff_2ecompile_2espec_2estaticGo_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2espec_2estaticGo_24dps_clo;
V g_heff_2ecompile_2espec_2eusesOf(V, V);
V g_heff_2ecompile_2espec_2eusesOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2espec_2eusesOf_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24f1645967390x252727070(V, V);
V g_list_2efoldl_24f1645967390x252727070_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1645967390x252727070_clo;
V g_list_2efoldl_24f836170601x1639498774(V, V);
V g_list_2efoldl_24f836170601x1639498774_entry(V self, V *a);
extern Clo g_list_2efoldl_24f836170601x1639498774_clo;
V g_list_2efoldl_24s1048046132x95752937(V, V);
V g_list_2efoldl_24s1048046132x95752937_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1048046132x95752937_clo;
V g_list_2efoldl_24s1116451536x2100070357(V, V, V);
V g_list_2efoldl_24s1116451536x2100070357_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1116451536x2100070357_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1173914895x100384474(V);
V g_list_2emap_24s1173914895x100384474_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_clo;
V g_list_2emap_24s143096761x246530315(V);
V g_list_2emap_24s143096761x246530315_entry(V self, V *a);
extern Clo g_list_2emap_24s143096761x246530315_clo;
V g_map_2einsert_24s1341440536x470972936(V, V, V);
V g_map_2einsert_24s1341440536x470972936_entry(V self, V *a);
extern Clo g_map_2einsert_24s1341440536x470972936_clo;
V g_map_2elookup_24s1546226666x2146984184(V, V);
V g_map_2elookup_24s1546226666x2146984184_entry(V self, V *a);
extern Clo g_map_2elookup_24s1546226666x2146984184_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
Clo g_heff_2ecompile_2espec_2eelemS_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2espec_2eelemS_entry, 2, 0};

V g_heff_2ecompile_2espec_2eelemS(V v_x_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_x_240);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_y_242 = heff_field(v_x2_241, 0);
    V v_ys_243 = heff_field(v_x2_241, 1);
    if (heff_strEq_c(heff_dup(v_x_240), heff_dup(v_y_242))) {
      heff_drop(v_x_240);
      return NTAG(TAG_True);
    } else {
      V t_0 = v_x_240;
      V t_1 = v_ys_243;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2espec_2eelemS_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2espec_2eelemS(a[0], a1); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2espec_2eappendS_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2espec_2eappendS_entry, 2, 0};

V g_heff_2ecompile_2espec_2eappendS(V v_x1_240, V v_ys_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return v_ys_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
    V v_u_245 = (g_heff_2ecompile_2espec_2eappendS_24dps(v_xs_243, v_ys_241, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2espec_2eappendS_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2espec_2eappendS(a[0], a[1]);
}
Clo g_heff_2ecompile_2espec_2eappendS_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2espec_2eappendS_24dps_entry, 3, 0};

V g_heff_2ecompile_2espec_2eappendS_24dps(V v_x1_240, V v_ys_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_242, MK_INT(1LL), v_ys_241);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x1_240, 0);
    V v_xs_244 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_cell_245 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
    V v_u_246 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_245));
    heff_drop(v_u_246);
    V t_0 = v_xs_244;
    V t_1 = v_ys_241;
    V t_2 = v_cell_245;
    v_x1_240 = t_0;
    v_ys_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2espec_2eappendS_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2espec_2eappendS_24dps(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2espec_2eallS_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2espec_2eallS_entry, 2, 0};

V g_heff_2ecompile_2espec_2eallS(V v_p_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_p_240);
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_t_244 = heff_tr(heff_call(heff_dup(v_p_240), 1, (V[]){heff_dup(v_x_242)}));
    if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
      heff_drop(v_t_244);
      V t_0 = v_p_240;
      V t_1 = v_xs_243;
      v_p_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    } else {
      heff_drop(v_p_240);
      heff_drop(v_t_244);
      return NTAG(TAG_False);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2espec_2eallS_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2espec_2eallS(a[0], a1); heff_drop(a1); return r;
}
V g_heff_2ecompile_2espec_2eclosedIn_lam0(V self, V *args);
Clo g_heff_2ecompile_2espec_2eclosedIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2espec_2eclosedIn_entry, 2, 0};

V g_heff_2ecompile_2espec_2eclosedIn(V v_env_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_EVar: {
    V v_x_242 = heff_field(v_x2_241, 0);
    return ({ V a_0 = heff_dup(v_x_242); V a_1 = v_env_240; V r_ = (g_heff_2ecompile_2espec_2eelemS(a_0, a_1)); heff_drop(v_env_240); r_; });
  }
  case TAG_EGlobal: {
    heff_drop(v_env_240);
    return NTAG(TAG_True);
  }
  case TAG_ELam: {
    V v_xs_244 = heff_field(v_x2_241, 0);
    V v_b_245 = heff_field(v_x2_241, 1);
    V v_t_246 = (g_heff_2ecompile_2espec_2eappendS(heff_dup(v_xs_244), v_env_240));
    V t_0 = v_t_246;
    V t_1 = v_b_245;
    v_env_240 = t_0;
    v_x2_241 = t_1;
    goto top;
  }
  case TAG_EApp: {
    V v_f_247 = heff_field(v_x2_241, 0);
    V v_as_248 = heff_field(v_x2_241, 1);
    V v_t_249 = (g_heff_2ecompile_2espec_2eclosedIn(heff_dup(v_env_240), v_f_247));
    if ((heff_dup(v_t_249) == NTAG(TAG_True))) {
      heff_drop(v_t_249);
      V v_t_2410 = heff_tr(heff_call(((V)&g_heff_2ecompile_2espec_2eclosedIn_clo), 1, (V[]){v_env_240}));
      HEFF_LAST return g_heff_2ecompile_2espec_2eallS(v_t_2410, v_as_248);
    } else {
      heff_drop(v_env_240);
      heff_drop(v_t_249);
      return NTAG(TAG_False);
    }
  }
  case TAG_ELet: {
    V v_x_2411 = heff_field(v_x2_241, 0);
    V v_a_2412 = heff_field(v_x2_241, 1);
    V v_b_2413 = heff_field(v_x2_241, 2);
    V v_t_2414 = (g_heff_2ecompile_2espec_2eclosedIn(heff_dup(v_env_240), v_a_2412));
    if ((heff_dup(v_t_2414) == NTAG(TAG_True))) {
      heff_drop(v_t_2414);
      V t_0 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_x_2411), v_env_240});
      V t_1 = v_b_2413;
      v_env_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    } else {
      heff_drop(v_env_240);
      heff_drop(v_t_2414);
      return NTAG(TAG_False);
    }
  }
  case TAG_ERecord: {
    V v_fs_2415 = heff_field(v_x2_241, 0);
    V v_t_2417 = heff_tr(heff_call(((V)&g_heff_2ecompile_2espec_2eclosedIn_clo), 1, (V[]){v_env_240}));
    V v_t_2418 = (g_list_2emap_24s1173914895x100384474(heff_dup(v_fs_2415)));
    return ({ V a_0 = v_t_2417; V a_1 = v_t_2418; V r_ = (g_heff_2ecompile_2espec_2eallS(a_0, a_1)); heff_drop(v_t_2418); r_; });
  }
  case TAG_EProj: {
    V v_e_2419 = heff_field(v_x2_241, 0);
    V t_0 = v_env_240;
    V t_1 = v_e_2419;
    v_env_240 = t_0;
    v_x2_241 = t_1;
    goto top;
  }
  case TAG_ETag: {
    V v_as_2424 = heff_field(v_x2_241, 1);
    V v_t_2425 = heff_tr(heff_call(((V)&g_heff_2ecompile_2espec_2eclosedIn_clo), 1, (V[]){v_env_240}));
    HEFF_LAST return g_heff_2ecompile_2espec_2eallS(v_t_2425, v_as_2424);
  }
  case TAG_EMatch: {
    V v_s_2426 = heff_field(v_x2_241, 0);
    V v_arms_2427 = heff_field(v_x2_241, 1);
    V v_t_2428 = (g_heff_2ecompile_2espec_2eclosedIn(heff_dup(v_env_240), v_s_2426));
    if ((heff_dup(v_t_2428) == NTAG(TAG_True))) {
      heff_drop(v_t_2428);
      HEFF_LAST return g_heff_2ecompile_2espec_2eallS(heff_clo_n(g_heff_2ecompile_2espec_2eclosedIn_lam0, 1, 1, (V[]){v_env_240}), v_arms_2427);
    } else {
      heff_drop(v_env_240);
      heff_drop(v_t_2428);
      return NTAG(TAG_False);
    }
  }
  case TAG_EPrim: {
    heff_drop(v_env_240);
    return NTAG(TAG_True);
  }
  case TAG_EPrimCall: {
    V v_as_2436 = heff_field(v_x2_241, 1);
    V v_t_2437 = heff_tr(heff_call(((V)&g_heff_2ecompile_2espec_2eclosedIn_clo), 1, (V[]){v_env_240}));
    HEFF_LAST return g_heff_2ecompile_2espec_2eallS(v_t_2437, v_as_2436);
  }
  case TAG_ECall: {
    V v_as_2439 = heff_field(v_x2_241, 1);
    V v_t_2440 = heff_tr(heff_call(((V)&g_heff_2ecompile_2espec_2eclosedIn_clo), 1, (V[]){v_env_240}));
    HEFF_LAST return g_heff_2ecompile_2espec_2eallS(v_t_2440, v_as_2439);
  }
  case TAG_EInt: {
    heff_drop(v_env_240);
    return NTAG(TAG_True);
  }
  case TAG_EFloat: {
    heff_drop(v_env_240);
    return NTAG(TAG_True);
  }
  case TAG_EStr: {
    heff_drop(v_env_240);
    return NTAG(TAG_True);
  }
  case TAG_EBytes: {
    heff_drop(v_env_240);
    return NTAG(TAG_True);
  }
  case TAG_EFixed: {
    heff_drop(v_env_240);
    return NTAG(TAG_True);
  }
  case TAG_EFloat32: {
    heff_drop(v_env_240);
    return NTAG(TAG_True);
  }
  case TAG_EAbandon: {
    heff_drop(v_env_240);
    return NTAG(TAG_True);
  }
  case TAG_EFix: {
    heff_drop(v_env_240);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2espec_2eclosedIn_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2espec_2eclosedIn(a[0], a1); heff_drop(a1); return r;
}
V g_heff_2ecompile_2espec_2eclosedIn_lam0(V self, V *args) {
  V v_x3_2429 = args[0];
  V v_env_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x3_2429)) {
  case TAG_MkArm: {
    V v_vs_2431 = heff_field(v_x3_2429, 1);
    V v_b_2432 = heff_field(v_x3_2429, 2);
    heff_take_n(v_x3_2429, 6ULL, 3);
    V v_t_2433 = (g_heff_2ecompile_2espec_2eappendS(v_vs_2431, v_env_240));
    return ({ V a_0 = v_t_2433; V a_1 = v_b_2432; V r_ = (g_heff_2ecompile_2espec_2eclosedIn(a_0, a_1)); heff_drop(v_b_2432); r_; });
  }
  default: return heff_nomatch(v_x3_2429);
  }
}
Clo g_heff_2ecompile_2espec_2eposGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2espec_2eposGo_entry, 3, 0};

V g_heff_2ecompile_2espec_2eposGo(V v_x_240, V v_x2_241, V v_i_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_x_240);
    heff_drop(v_i_242);
    return MK_INT(-1LL);
  }
  case TAG_Cons: {
    V v_y_243 = heff_field(v_x2_241, 0);
    V v_ys_244 = heff_field(v_x2_241, 1);
    if (heff_strEq_c(heff_dup(v_x_240), heff_dup(v_y_243))) {
      heff_drop(v_x_240);
      return v_i_242;
    } else {
      V t_0 = v_x_240;
      V t_1 = v_ys_244;
      V t_2 = heff_intAdd(v_i_242, MK_INT(1LL));
      v_x_240 = t_0;
      v_x2_241 = t_1;
      v_i_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2espec_2eposGo_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2espec_2eposGo(a[0], a1, a[2]); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str0, 1, "v");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str1, 1, "g");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str2, 1, ";");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str3, 1, "(");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str4, 1, ")");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str5, 1, "L");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str6, 0, "");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str7, 1, ",");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str8, 1, ":");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str9, 1, ")");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str10, 2, "A(");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str11, 1, ":");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str12, 1, ")");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str13, 2, "T(");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str14, 1, "=");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str15, 0, "");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str16, 1, ",");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str17, 0, "");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str18, 1, ",");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str19, 1, ":");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str20, 1, ")");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str21, 2, "R(");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str22, 0, "");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str23, 1, ",");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str24, 7, "Float64");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str25, 4, "Int8");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str26, 5, "Int16");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str27, 5, "Int32");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str28, 5, "Int64");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str29, 5, "UInt8");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str30, 6, "UInt16");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str31, 6, "UInt32");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str32, 6, "UInt64");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str33, 7, "Float32");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str34, 1, "_");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str35, 1, "\?");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str36, 1, ":");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str37, 1, ")");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str38, 1, "/");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str39, 1, ".");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str40, 2, "P(");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str41, 0, "");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str42, 1, ",");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str43, 1, "(");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str44, 1, ")");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str45, 1, "C");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str46, 1, ":");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str47, 1, "|");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str48, 0, "");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str49, 0, "");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str50, 1, ")");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str51, 2, "M(");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str52, 1, "p");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str53, 1, ";");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str54, 0, "");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str55, 1, ",");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str56, 1, "(");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str57, 1, ")");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str58, 1, "Q");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str59, 0, "");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str60, 1, ",");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str61, 1, "(");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str62, 1, ")");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str63, 1, "K");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str64, 1, "i");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str65, 1, "f");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str66, 1, ":");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str67, 1, "s");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str68, 1, ":");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str69, 1, "b");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str70, 2, "I8");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str71, 3, "I16");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str72, 3, "I32");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str73, 3, "I64");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str74, 2, "U8");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str75, 3, "U16");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str76, 3, "U32");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str77, 3, "U64");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str78, 3, "F32");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str79, 1, ":");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str80, 1, "x");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str81, 1, "y");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str82, 1, "X");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str83, 1, "F");
V g_heff_2ecompile_2espec_2ekeyGo_lam0(V self, V *args);
V g_heff_2ecompile_2espec_2ekeyGo_lam1(V self, V *args);
Clo g_heff_2ecompile_2espec_2ekeyGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2espec_2ekeyGo_entry, 2, 0};

V g_heff_2ecompile_2espec_2ekeyGo(V v_env_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_EVar: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_t_243 = ({ V a_0 = heff_dup(v_x_242); V a_1 = v_env_240; V a_2 = MK_INT(0LL); V r_ = (g_heff_2ecompile_2espec_2eposGo(a_0, a_1, a_2)); heff_drop(v_env_240); r_; });
    return heff_strAppend(((V)&g_heff_2ecompile_2espec_2ekeyGo_str0), heff_intShow(v_t_243));
  }
  case TAG_EGlobal: {
    V v_g_244 = heff_field(v_x2_241, 0);
    heff_drop(v_env_240);
    return heff_strAppend(((V)&g_heff_2ecompile_2espec_2ekeyGo_str1), heff_strAppend(heff_dup(v_g_244), ((V)&g_heff_2ecompile_2espec_2ekeyGo_str2)));
  }
  case TAG_ELam: {
    V v_xs_245 = heff_field(v_x2_241, 0);
    V v_b_246 = heff_field(v_x2_241, 1);
    V v_t_247 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_xs_245));
    V v_t_248 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_xs_245)));
    V v_t_249 = (g_heff_2ecompile_2espec_2eappendS(v_t_248, v_env_240));
    V v_t_2410 = (g_heff_2ecompile_2espec_2ekeyGo(v_t_249, v_b_246));
    V v_t_2411 = heff_strAppend(((V)&g_heff_2ecompile_2espec_2ekeyGo_str3), heff_strAppend(v_t_2410, ((V)&g_heff_2ecompile_2espec_2ekeyGo_str4)));
    V v_t_2412 = heff_strAppend(heff_intShow(v_t_247), v_t_2411);
    return heff_strAppend(((V)&g_heff_2ecompile_2espec_2ekeyGo_str5), v_t_2412);
  }
  case TAG_EApp: {
    V v_f_2413 = heff_field(v_x2_241, 0);
    V v_as_2414 = heff_field(v_x2_241, 1);
    V v_t_2415 = (g_heff_2ecompile_2espec_2ekeyGo(heff_dup(v_env_240), v_f_2413));
    V v_go_2416 = heff_tr(heff_call(((V)&g_heff_2ecompile_2espec_2ekeyGo_clo), 1, (V[]){v_env_240}));
    V v_x2_2417 = (g_list_2emap(v_go_2416, heff_dup(v_as_2414)));
    V v_t_2420;
    switch (heff_tag_of(v_x2_2417)) {
    case TAG_Nil: {
      v_t_2420 = ((V)&g_heff_2ecompile_2espec_2ekeyGo_str6);
      break;
    }
    case TAG_Cons: {
      V v_x_2418 = heff_field(v_x2_2417, 0);
      V v_xs_2419 = heff_field(v_x2_2417, 1);
      heff_take_n(v_x2_2417, 3ULL, 2);
      v_t_2420 = ({ V a_0 = ((V)&g_heff_2ecompile_2espec_2ekeyGo_str7); V a_1 = v_x_2418; V a_2 = v_xs_2419; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2419); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2417);
    }
    V v_t_2421 = heff_strAppend(((V)&g_heff_2ecompile_2espec_2ekeyGo_str8), heff_strAppend(v_t_2420, ((V)&g_heff_2ecompile_2espec_2ekeyGo_str9)));
    return heff_strAppend(((V)&g_heff_2ecompile_2espec_2ekeyGo_str10), heff_strAppend(v_t_2415, v_t_2421));
  }
  case TAG_ELet: {
    V v_x_2422 = heff_field(v_x2_241, 0);
    V v_a_2423 = heff_field(v_x2_241, 1);
    V v_b_2424 = heff_field(v_x2_241, 2);
    V v_t_2425 = (g_heff_2ecompile_2espec_2ekeyGo(heff_dup(v_env_240), v_a_2423));
    V v_t_2426 = (g_heff_2ecompile_2espec_2ekeyGo(heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_x_2422), v_env_240}), v_b_2424));
    V v_t_2427 = heff_strAppend(((V)&g_heff_2ecompile_2espec_2ekeyGo_str11), heff_strAppend(v_t_2426, ((V)&g_heff_2ecompile_2espec_2ekeyGo_str12)));
    return heff_strAppend(((V)&g_heff_2ecompile_2espec_2ekeyGo_str13), heff_strAppend(v_t_2425, v_t_2427));
  }
  case TAG_ERecord: {
    V v_fs_2428 = heff_field(v_x2_241, 0);
    V v_ts_2429 = heff_field(v_x2_241, 1);
    V v_go_2430 = heff_tr(heff_call(((V)&g_heff_2ecompile_2espec_2ekeyGo_clo), 1, (V[]){v_env_240}));
    V v_x2_2435 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2espec_2ekeyGo_lam0, 1, 1, (V[]){v_go_2430}), heff_dup(v_fs_2428)));
    V v_t_2438;
    switch (heff_tag_of(v_x2_2435)) {
    case TAG_Nil: {
      v_t_2438 = ((V)&g_heff_2ecompile_2espec_2ekeyGo_str15);
      break;
    }
    case TAG_Cons: {
      V v_x_2436 = heff_field(v_x2_2435, 0);
      V v_xs_2437 = heff_field(v_x2_2435, 1);
      heff_take_n(v_x2_2435, 3ULL, 2);
      v_t_2438 = ({ V a_0 = ((V)&g_heff_2ecompile_2espec_2ekeyGo_str16); V a_1 = v_x_2436; V a_2 = v_xs_2437; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2437); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2435);
    }
    V v_x2_2439 = (g_list_2emap_24s143096761x246530315(heff_dup(v_ts_2429)));
    V v_t_2442;
    switch (heff_tag_of(v_x2_2439)) {
    case TAG_Nil: {
      v_t_2442 = ((V)&g_heff_2ecompile_2espec_2ekeyGo_str17);
      break;
    }
    case TAG_Cons: {
      V v_x_2440 = heff_field(v_x2_2439, 0);
      V v_xs_2441 = heff_field(v_x2_2439, 1);
      heff_take_n(v_x2_2439, 3ULL, 2);
      v_t_2442 = ({ V a_0 = ((V)&g_heff_2ecompile_2espec_2ekeyGo_str18); V a_1 = v_x_2440; V a_2 = v_xs_2441; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2441); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2439);
    }
    V v_t_2443 = heff_strAppend(((V)&g_heff_2ecompile_2espec_2ekeyGo_str19), heff_strAppend(v_t_2442, ((V)&g_heff_2ecompile_2espec_2ekeyGo_str20)));
    return heff_strAppend(((V)&g_heff_2ecompile_2espec_2ekeyGo_str21), heff_strAppend(v_t_2438, v_t_2443));
  }
  case TAG_EProj: {
    V v_e_2444 = heff_field(v_x2_241, 0);
    V v_l_2445 = heff_field(v_x2_241, 1);
    V v_sh_2446 = heff_field(v_x2_241, 2);
    V v_t_2447 = heff_field(v_x2_241, 3);
    V v_t_2448 = (g_heff_2ecompile_2espec_2ekeyGo(v_env_240, v_e_2444));
    V v_t_2451;
    switch (heff_tag_of(v_sh_2446)) {
    case TAG_Nil: {
      v_t_2451 = ((V)&g_heff_2ecompile_2espec_2ekeyGo_str22);
      break;
    }
    case TAG_Cons: {
      V v_x_2449 = heff_field(v_sh_2446, 0);
      V v_xs_2450 = heff_field(v_sh_2446, 1);
      v_t_2451 = (g_prelude_2ejoinWith_2eafter_240(((V)&g_heff_2ecompile_2espec_2ekeyGo_str23), heff_dup(v_x_2449), v_xs_2450));
      break;
    }
    default: heff_nomatch(v_sh_2446);
    }
    V v_t_2453;
    switch (heff_tag_of(v_t_2447)) {
    case TAG_FtFloat: {
      v_t_2453 = ((V)&g_heff_2ecompile_2espec_2ekeyGo_str24);
      break;
    }
    case TAG_FtFixed: {
      V v_w_2452 = heff_field(v_t_2447, 0);
      switch (heff_tag_of(v_w_2452)) {
      case TAG_I8: {
        v_t_2453 = ((V)&g_heff_2ecompile_2espec_2ekeyGo_str25);
        break;
      }
      case TAG_I16: {
        v_t_2453 = ((V)&g_heff_2ecompile_2espec_2ekeyGo_str26);
        break;
      }
      case TAG_I32: {
        v_t_2453 = ((V)&g_heff_2ecompile_2espec_2ekeyGo_str27);
        break;
      }
      case TAG_I64: {
        v_t_2453 = ((V)&g_heff_2ecompile_2espec_2ekeyGo_str28);
        break;
      }
      case TAG_U8: {
        v_t_2453 = ((V)&g_heff_2ecompile_2espec_2ekeyGo_str29);
        break;
      }
      case TAG_U16: {
        v_t_2453 = ((V)&g_heff_2ecompile_2espec_2ekeyGo_str30);
        break;
      }
      case TAG_U32: {
        v_t_2453 = ((V)&g_heff_2ecompile_2espec_2ekeyGo_str31);
        break;
      }
      case TAG_U64: {
        v_t_2453 = ((V)&g_heff_2ecompile_2espec_2ekeyGo_str32);
        break;
      }
      case TAG_F32: {
        v_t_2453 = ((V)&g_heff_2ecompile_2espec_2ekeyGo_str33);
        break;
      }
      default: heff_nomatch(v_w_2452);
      }
      break;
    }
    case TAG_FtOther: {
      v_t_2453 = ((V)&g_heff_2ecompile_2espec_2ekeyGo_str34);
      break;
    }
    case TAG_FtAny: {
      v_t_2453 = ((V)&g_heff_2ecompile_2espec_2ekeyGo_str35);
      break;
    }
    default: heff_nomatch(v_t_2447);
    }
    V v_t_2454 = heff_strAppend(((V)&g_heff_2ecompile_2espec_2ekeyGo_str36), heff_strAppend(v_t_2453, ((V)&g_heff_2ecompile_2espec_2ekeyGo_str37)));
    V v_t_2455 = heff_strAppend(((V)&g_heff_2ecompile_2espec_2ekeyGo_str38), heff_strAppend(v_t_2451, v_t_2454));
    V v_t_2456 = heff_strAppend(((V)&g_heff_2ecompile_2espec_2ekeyGo_str39), heff_strAppend(heff_dup(v_l_2445), v_t_2455));
    return heff_strAppend(((V)&g_heff_2ecompile_2espec_2ekeyGo_str40), heff_strAppend(v_t_2448, v_t_2456));
  }
  case TAG_ETag: {
    V v_t_2457 = heff_field(v_x2_241, 0);
    V v_as_2458 = heff_field(v_x2_241, 1);
    V v_go_2459 = heff_tr(heff_call(((V)&g_heff_2ecompile_2espec_2ekeyGo_clo), 1, (V[]){v_env_240}));
    V v_x2_2460 = (g_list_2emap(v_go_2459, heff_dup(v_as_2458)));
    V v_t_2463;
    switch (heff_tag_of(v_x2_2460)) {
    case TAG_Nil: {
      v_t_2463 = ((V)&g_heff_2ecompile_2espec_2ekeyGo_str41);
      break;
    }
    case TAG_Cons: {
      V v_x_2461 = heff_field(v_x2_2460, 0);
      V v_xs_2462 = heff_field(v_x2_2460, 1);
      heff_take_n(v_x2_2460, 3ULL, 2);
      v_t_2463 = ({ V a_0 = ((V)&g_heff_2ecompile_2espec_2ekeyGo_str42); V a_1 = v_x_2461; V a_2 = v_xs_2462; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2462); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2460);
    }
    V v_t_2464 = heff_strAppend(((V)&g_heff_2ecompile_2espec_2ekeyGo_str43), heff_strAppend(v_t_2463, ((V)&g_heff_2ecompile_2espec_2ekeyGo_str44)));
    return heff_strAppend(((V)&g_heff_2ecompile_2espec_2ekeyGo_str45), heff_strAppend(heff_dup(v_t_2457), v_t_2464));
  }
  case TAG_EMatch: {
    V v_s_2465 = heff_field(v_x2_241, 0);
    V v_arms_2466 = heff_field(v_x2_241, 1);
    V v_t_2467 = (g_heff_2ecompile_2espec_2ekeyGo(heff_dup(v_env_240), v_s_2465));
    V v_x2_2477 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2espec_2ekeyGo_lam1, 1, 1, (V[]){v_env_240}), heff_dup(v_arms_2466)));
    V v_t_2480;
    switch (heff_tag_of(v_x2_2477)) {
    case TAG_Nil: {
      v_t_2480 = ((V)&g_heff_2ecompile_2espec_2ekeyGo_str48);
      break;
    }
    case TAG_Cons: {
      V v_x_2478 = heff_field(v_x2_2477, 0);
      V v_xs_2479 = heff_field(v_x2_2477, 1);
      heff_take_n(v_x2_2477, 3ULL, 2);
      v_t_2480 = ({ V a_0 = ((V)&g_heff_2ecompile_2espec_2ekeyGo_str49); V a_1 = v_x_2478; V a_2 = v_xs_2479; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2479); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2477);
    }
    V v_t_2481 = heff_strAppend(v_t_2467, heff_strAppend(v_t_2480, ((V)&g_heff_2ecompile_2espec_2ekeyGo_str50)));
    return heff_strAppend(((V)&g_heff_2ecompile_2espec_2ekeyGo_str51), v_t_2481);
  }
  case TAG_EPrim: {
    V v_p_2482 = heff_field(v_x2_241, 0);
    heff_drop(v_env_240);
    return heff_strAppend(((V)&g_heff_2ecompile_2espec_2ekeyGo_str52), heff_strAppend(heff_dup(v_p_2482), ((V)&g_heff_2ecompile_2espec_2ekeyGo_str53)));
  }
  case TAG_EPrimCall: {
    V v_p_2483 = heff_field(v_x2_241, 0);
    V v_as_2484 = heff_field(v_x2_241, 1);
    V v_go_2485 = heff_tr(heff_call(((V)&g_heff_2ecompile_2espec_2ekeyGo_clo), 1, (V[]){v_env_240}));
    V v_x2_2486 = (g_list_2emap(v_go_2485, heff_dup(v_as_2484)));
    V v_t_2489;
    switch (heff_tag_of(v_x2_2486)) {
    case TAG_Nil: {
      v_t_2489 = ((V)&g_heff_2ecompile_2espec_2ekeyGo_str54);
      break;
    }
    case TAG_Cons: {
      V v_x_2487 = heff_field(v_x2_2486, 0);
      V v_xs_2488 = heff_field(v_x2_2486, 1);
      heff_take_n(v_x2_2486, 3ULL, 2);
      v_t_2489 = ({ V a_0 = ((V)&g_heff_2ecompile_2espec_2ekeyGo_str55); V a_1 = v_x_2487; V a_2 = v_xs_2488; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2488); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2486);
    }
    V v_t_2490 = heff_strAppend(((V)&g_heff_2ecompile_2espec_2ekeyGo_str56), heff_strAppend(v_t_2489, ((V)&g_heff_2ecompile_2espec_2ekeyGo_str57)));
    return heff_strAppend(((V)&g_heff_2ecompile_2espec_2ekeyGo_str58), heff_strAppend(heff_dup(v_p_2483), v_t_2490));
  }
  case TAG_ECall: {
    V v_g_2491 = heff_field(v_x2_241, 0);
    V v_as_2492 = heff_field(v_x2_241, 1);
    V v_go_2493 = heff_tr(heff_call(((V)&g_heff_2ecompile_2espec_2ekeyGo_clo), 1, (V[]){v_env_240}));
    V v_x2_2494 = (g_list_2emap(v_go_2493, heff_dup(v_as_2492)));
    V v_t_2497;
    switch (heff_tag_of(v_x2_2494)) {
    case TAG_Nil: {
      v_t_2497 = ((V)&g_heff_2ecompile_2espec_2ekeyGo_str59);
      break;
    }
    case TAG_Cons: {
      V v_x_2495 = heff_field(v_x2_2494, 0);
      V v_xs_2496 = heff_field(v_x2_2494, 1);
      heff_take_n(v_x2_2494, 3ULL, 2);
      v_t_2497 = ({ V a_0 = ((V)&g_heff_2ecompile_2espec_2ekeyGo_str60); V a_1 = v_x_2495; V a_2 = v_xs_2496; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2496); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2494);
    }
    V v_t_2498 = heff_strAppend(((V)&g_heff_2ecompile_2espec_2ekeyGo_str61), heff_strAppend(v_t_2497, ((V)&g_heff_2ecompile_2espec_2ekeyGo_str62)));
    return heff_strAppend(((V)&g_heff_2ecompile_2espec_2ekeyGo_str63), heff_strAppend(heff_dup(v_g_2491), v_t_2498));
  }
  case TAG_EInt: {
    V v_i_2499 = heff_field(v_x2_241, 0);
    heff_drop(v_env_240);
    return heff_strAppend(((V)&g_heff_2ecompile_2espec_2ekeyGo_str64), heff_intShow(heff_dup(v_i_2499)));
  }
  case TAG_EFloat: {
    V v_x_24100 = heff_field(v_x2_241, 0);
    heff_drop(v_env_240);
    return heff_strAppend(((V)&g_heff_2ecompile_2espec_2ekeyGo_str65), heff_floatShow(heff_dup(v_x_24100)));
  }
  case TAG_EStr: {
    V v_s_24101 = heff_field(v_x2_241, 0);
    heff_drop(v_env_240);
    V v_t_24102 = heff_intShow(heff_strLength(heff_dup(v_s_24101)));
    V v_t_24103 = heff_strAppend(v_t_24102, heff_strAppend(((V)&g_heff_2ecompile_2espec_2ekeyGo_str66), heff_dup(v_s_24101)));
    return heff_strAppend(((V)&g_heff_2ecompile_2espec_2ekeyGo_str67), v_t_24103);
  }
  case TAG_EBytes: {
    V v_s_24104 = heff_field(v_x2_241, 0);
    heff_drop(v_env_240);
    V v_t_24105 = heff_intShow(heff_strLength(heff_dup(v_s_24104)));
    V v_t_24106 = heff_strAppend(v_t_24105, heff_strAppend(((V)&g_heff_2ecompile_2espec_2ekeyGo_str68), heff_dup(v_s_24104)));
    return heff_strAppend(((V)&g_heff_2ecompile_2espec_2ekeyGo_str69), v_t_24106);
  }
  case TAG_EFixed: {
    V v_w_24107 = heff_field(v_x2_241, 0);
    V v_n_24108 = heff_field(v_x2_241, 1);
    heff_drop(v_env_240);
    V v_t_24109;
    switch (heff_tag_of(v_w_24107)) {
    case TAG_I8: {
      v_t_24109 = ((V)&g_heff_2ecompile_2espec_2ekeyGo_str70);
      break;
    }
    case TAG_I16: {
      v_t_24109 = ((V)&g_heff_2ecompile_2espec_2ekeyGo_str71);
      break;
    }
    case TAG_I32: {
      v_t_24109 = ((V)&g_heff_2ecompile_2espec_2ekeyGo_str72);
      break;
    }
    case TAG_I64: {
      v_t_24109 = ((V)&g_heff_2ecompile_2espec_2ekeyGo_str73);
      break;
    }
    case TAG_U8: {
      v_t_24109 = ((V)&g_heff_2ecompile_2espec_2ekeyGo_str74);
      break;
    }
    case TAG_U16: {
      v_t_24109 = ((V)&g_heff_2ecompile_2espec_2ekeyGo_str75);
      break;
    }
    case TAG_U32: {
      v_t_24109 = ((V)&g_heff_2ecompile_2espec_2ekeyGo_str76);
      break;
    }
    case TAG_U64: {
      v_t_24109 = ((V)&g_heff_2ecompile_2espec_2ekeyGo_str77);
      break;
    }
    case TAG_F32: {
      v_t_24109 = ((V)&g_heff_2ecompile_2espec_2ekeyGo_str78);
      break;
    }
    default: heff_nomatch(v_w_24107);
    }
    V v_t_24110 = heff_strAppend(((V)&g_heff_2ecompile_2espec_2ekeyGo_str79), heff_intShow(heff_dup(v_n_24108)));
    return heff_strAppend(((V)&g_heff_2ecompile_2espec_2ekeyGo_str80), heff_strAppend(v_t_24109, v_t_24110));
  }
  case TAG_EFloat32: {
    V v_x_24111 = heff_field(v_x2_241, 0);
    heff_drop(v_env_240);
    return heff_strAppend(((V)&g_heff_2ecompile_2espec_2ekeyGo_str81), heff_floatShow(heff_dup(v_x_24111)));
  }
  case TAG_EAbandon: {
    heff_drop(v_env_240);
    return ((V)&g_heff_2ecompile_2espec_2ekeyGo_str82);
  }
  case TAG_EFix: {
    heff_drop(v_env_240);
    return ((V)&g_heff_2ecompile_2espec_2ekeyGo_str83);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2espec_2ekeyGo_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2espec_2ekeyGo(a[0], a1); heff_drop(a1); return r;
}
V g_heff_2ecompile_2espec_2ekeyGo_lam0(V self, V *args) {
  V v_x2_2431 = args[0];
  V v_go_2430 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x2_2431)) {
  case TAG_MkPair: {
    V v_l_2432 = heff_field(v_x2_2431, 0);
    V v_v_2433 = heff_field(v_x2_2431, 1);
    heff_take_n(v_x2_2431, 3ULL, 2);
    V v_t_2434 = heff_tr(heff_call(v_go_2430, 1, (V[]){v_v_2433}));
    return heff_strAppend(v_l_2432, heff_strAppend(((V)&g_heff_2ecompile_2espec_2ekeyGo_str14), v_t_2434));
  }
  default: return heff_nomatch(v_x2_2431);
  }
}
V g_heff_2ecompile_2espec_2ekeyGo_lam1(V self, V *args) {
  V v_x3_2468 = args[0];
  V v_env_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x3_2468)) {
  case TAG_MkArm: {
    V v_t_2469 = heff_field(v_x3_2468, 0);
    V v_vs_2470 = heff_field(v_x3_2468, 1);
    V v_b_2471 = heff_field(v_x3_2468, 2);
    heff_take_n(v_x3_2468, 7ULL, 3);
    V v_t_2472 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_vs_2470));
    V v_t_2473 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_vs_2470));
    V v_t_2474 = (g_heff_2ecompile_2espec_2eappendS(v_t_2473, v_env_240));
    V v_t_2475 = ({ V a_0 = v_t_2474; V a_1 = v_b_2471; V r_ = (g_heff_2ecompile_2espec_2ekeyGo(a_0, a_1)); heff_drop(v_b_2471); r_; });
    V v_t_2476 = heff_strAppend(heff_intShow(v_t_2472), heff_strAppend(((V)&g_heff_2ecompile_2espec_2ekeyGo_str46), v_t_2475));
    return heff_strAppend(((V)&g_heff_2ecompile_2espec_2ekeyGo_str47), heff_strAppend(v_t_2469, v_t_2476));
  }
  default: return heff_nomatch(v_x3_2468);
  }
}
HEFF_LIT(g_heff_2ecompile_2espec_2ehashGo_str0, 1, "x");
Clo g_heff_2ecompile_2espec_2ehashGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2espec_2ehashGo_entry, 4, 0};

V g_heff_2ecompile_2espec_2ehashGo(V v_s_240, V v_i_241, V v_a_242, V v_b_243) {
top: ;
  if (heff_intLe_c(heff_strLength(heff_dup(v_s_240)), heff_dup(v_i_241))) {
    heff_drop(v_s_240);
    heff_drop(v_i_241);
    V v_t_245 = heff_strAppend(((V)&g_heff_2ecompile_2espec_2ehashGo_str0), heff_intShow(v_b_243));
    return heff_strAppend(heff_intShow(v_a_242), v_t_245);
  } else {
    V v_t_246 = heff_intAdd(heff_intMul(v_a_242, MK_INT(1000003LL)), heff_strByteAt(heff_dup(v_s_240), heff_dup(v_i_241)));
    V v_t_247 = heff_intMod(heff_intAdd(v_t_246, MK_INT(1LL)), MK_INT(2147483647LL));
    V v_t_248 = heff_intAdd(heff_intMul(v_b_243, MK_INT(999983LL)), heff_strByteAt(heff_dup(v_s_240), heff_dup(v_i_241)));
    V v_t_249 = heff_intMod(heff_intAdd(v_t_248, MK_INT(1LL)), MK_INT(2147483629LL));
    V t_0 = v_s_240;
    V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
    V t_2 = v_t_247;
    V t_3 = v_t_249;
    v_s_240 = t_0;
    v_i_241 = t_1;
    v_a_242 = t_2;
    v_b_243 = t_3;
    goto top;
  }
}
V g_heff_2ecompile_2espec_2ehashGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2espec_2ehashGo(a[0], a[1], a[2], a[3]);
}
HEFF_LIT(g_heff_2ecompile_2espec_2ebindOne_str0, 2, "a$");
HEFF_LIT(g_heff_2ecompile_2espec_2ebindOne_str1, 2, "a$");
Clo g_heff_2ecompile_2espec_2ebindOne_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2espec_2ebindOne_entry, 2, 0};

V g_heff_2ecompile_2espec_2ebindOne(V v_x1_240, V v_x_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_MkPair: {
    V v_xs_242 = heff_field(v_x1_240, 0);
    V v_st_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24MkPair = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_244 = heff_intShow(heff_dup(heff_rfield(v_st_243, 3)));
    V v_t_245 = heff_tag_at_n(v_ru_24x1_240_24MkPair, TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2espec_2ebindOne_str0), v_t_244), v_xs_242});
    V v_t_246 = heff_intShow(heff_dup(heff_rfield(v_st_243, 3)));
    V v_t_247 = (g_map_2einsert_24s1341440536x470972936(v_x_241, heff_strAppend(((V)&g_heff_2ecompile_2espec_2ebindOne_str1), v_t_246), heff_take_field(v_st_243, 0)));
    V v_t_248 = heff_intAdd(heff_take_field(v_st_243, 3), MK_INT(1LL));
    V v_t_249 = ({ V rv_0 = v_t_247; V rv_3 = v_t_248; V rr_ = heff_rec_reuse_nf(v_st_243, 6ULL, 4, shape_ren__vars__holes__n, 60u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 3) = rv_3; rr_; });
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_245, v_t_249});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2espec_2ebindOne_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2espec_2ebindOne(a[0], a[1]);
}
Clo g_heff_2ecompile_2espec_2eshapeMany_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2espec_2eshapeMany_entry, 3, 0};

V g_heff_2ecompile_2espec_2eshapeMany(V v_go_240, V v_x2_241, V v_st_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_go_240);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_st_242});
  }
  case TAG_Cons: {
    V v_e_243 = heff_field(v_x2_241, 0);
    V v_rest_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_more_245 = heff_tr(heff_call(((V)&g_heff_2ecompile_2espec_2eshapeMany_clo), 2, (V[]){heff_dup(v_go_240), v_rest_244}));
    V v_x2_246 = heff_tr(heff_call(v_go_240, 2, (V[]){v_e_243, v_st_242}));
    switch (heff_tag_of(v_x2_246)) {
    case TAG_MkPair: {
      V v_e_247 = heff_field(v_x2_246, 0);
      V v_st_248 = heff_field(v_x2_246, 1);
      heff_take_n(v_x2_246, 3ULL, 2);
      V v_x2_249 = heff_tr(heff_call(v_more_245, 1, (V[]){v_st_248}));
      switch (heff_tag_of(v_x2_249)) {
      case TAG_MkPair: {
        V v_es_2410 = heff_field(v_x2_249, 0);
        V v_st_2411 = heff_field(v_x2_249, 1);
        heff_take_n(v_x2_249, 3ULL, 2);
        return heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_e_247, v_es_2410}), v_st_2411});
      }
      default: return heff_nomatch(v_x2_249);
      }
    }
    default: return heff_nomatch(v_x2_246);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2espec_2eshapeMany_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2espec_2eshapeMany(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2espec_2eletThen_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2espec_2eletThen_entry, 4, 0};

V g_heff_2ecompile_2espec_2eletThen(V v_go_240, V v_x_241, V v_b_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_MkPair: {
    V v_a_244 = heff_field(v_x4_243, 0);
    V v_st_245 = heff_field(v_x4_243, 1);
    V v_ru_24x4_243_24MkPair = heff_take_reuse_n(v_x4_243, 3ULL, 2);
    V v_t_246 = heff_tag_at_n(v_ru_24x4_243_24MkPair, TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_st_245});
    V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_x_241), NTAG(TAG_Nil)});
    V v_t_248 = ({ V a_0 = v_t_246; V a_1 = v_t_247; V r_ = (g_list_2efoldl_24s1048046132x95752937(a_0, a_1)); heff_drop_tag(v_t_247, 2); r_; });
    V v_x4_2412;
    switch (heff_tag_of(v_t_248)) {
    case TAG_MkPair: {
      V v_ys_249 = heff_field(v_t_248, 0);
      V v_st2_2410 = heff_field(v_t_248, 1);
      V v_ru_24t_248_24MkPair = heff_take_reuse_n(v_t_248, 3ULL, 2);
      V v_t_2411 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ys_249));
      v_x4_2412 = heff_tag_at_n(v_ru_24t_248_24MkPair, TAG_MkPair, 2, (V[]){v_t_2411, v_st2_2410});
      break;
    }
    default: heff_nomatch(v_t_248);
    }
    switch (heff_tag_of(v_x4_2412)) {
    case TAG_MkPair: {
      V v_ys_2413 = heff_field(v_x4_2412, 0);
      V v_st_2414 = heff_field(v_x4_2412, 1);
      V v_ru_24x4_2412_24MkPair = heff_take_reuse_n(v_x4_2412, 3ULL, 2);
      V v_x2_2415 = heff_tr(heff_call(v_go_240, 2, (V[]){v_b_242, v_st_2414}));
      switch (heff_tag_of(v_x2_2415)) {
      case TAG_MkPair: {
        V v_e_2416 = heff_field(v_x2_2415, 0);
        V v_st_2417 = heff_field(v_x2_2415, 1);
        heff_take_n(v_x2_2415, 3ULL, 2);
        V v_t_2420;
        switch (heff_tag_of(v_ys_2413)) {
        case TAG_Nil: {
          v_t_2420 = v_x_241;
          break;
        }
        case TAG_Cons: {
          V v_y_2418 = heff_field(v_ys_2413, 0);
          heff_take_n(v_ys_2413, 1ULL, 2);
          heff_drop(v_x_241);
          v_t_2420 = v_y_2418;
          break;
        }
        default: heff_nomatch(v_ys_2413);
        }
        return heff_tag_at_n(v_ru_24x4_2412_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_t_2420, v_a_244, v_e_2416}), v_st_2417});
      }
      default: return heff_nomatch(v_x2_2415);
      }
    }
    default: return heff_nomatch(v_x4_2412);
    }
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2ecompile_2espec_2eletThen_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2espec_2eletThen(a[0], a[1], a[2], a[3]);
}
Clo g_heff_2ecompile_2espec_2elabelsTo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2espec_2elabelsTo_entry, 2, 0};

V g_heff_2ecompile_2espec_2elabelsTo(V v_x1_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_x2_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x11_242 = heff_field(v_x1_240, 0);
    V v_fs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_MkPair: {
      V v_l_244 = heff_field(v_x11_242, 0);
      heff_take_n(v_x11_242, 1ULL, 2);
      switch (heff_tag_of(v_x2_241)) {
      case TAG_Nil: {
        heff_drop(v_fs_243);
        heff_drop_cell(v_ru_24x1_240_24Cons, 2);
        heff_drop(v_l_244);
        return NTAG(TAG_Nil);
      }
      case TAG_Cons: {
        V v_e_246 = heff_field(v_x2_241, 0);
        V v_es_247 = heff_field(v_x2_241, 1);
        heff_take_n(v_x2_241, 3ULL, 2);
        V v_cell_248 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_l_244, v_e_246}), heff_hole()});
        V v_u_249 = (g_heff_2ecompile_2espec_2elabelsTo_24dps(v_fs_243, v_es_247, heff_dup(v_cell_248)));
        heff_drop(v_u_249);
        return v_cell_248;
      }
      default: return heff_nomatch(v_x2_241);
      }
    }
    default: return heff_nomatch(v_x11_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2espec_2elabelsTo_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2espec_2elabelsTo(a[0], a[1]);
}
Clo g_heff_2ecompile_2espec_2elabelsTo_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2espec_2elabelsTo_24dps_entry, 3, 0};

V g_heff_2ecompile_2espec_2elabelsTo_24dps(V v_x1_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_x2_241);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x11_243 = heff_field(v_x1_240, 0);
    V v_fs_244 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_243)) {
    case TAG_MkPair: {
      V v_l_245 = heff_field(v_x11_243, 0);
      heff_take_n(v_x11_243, 1ULL, 2);
      switch (heff_tag_of(v_x2_241)) {
      case TAG_Nil: {
        heff_drop(v_fs_244);
        heff_drop_cell(v_ru_24x1_240_24Cons, 2);
        heff_drop(v_l_245);
        return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
      }
      case TAG_Cons: {
        V v_e_247 = heff_field(v_x2_241, 0);
        V v_es_248 = heff_field(v_x2_241, 1);
        heff_take_n(v_x2_241, 3ULL, 2);
        V v_cell_249 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_l_245, v_e_247}), heff_hole()});
        V v_u_2410 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_249));
        heff_drop(v_u_2410);
        V t_0 = v_fs_244;
        V t_1 = v_es_248;
        V t_2 = v_cell_249;
        v_x1_240 = t_0;
        v_x2_241 = t_1;
        v_d_242 = t_2;
        goto top;
      }
      default: return heff_nomatch(v_x2_241);
      }
    }
    default: return heff_nomatch(v_x11_243);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2espec_2elabelsTo_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2espec_2elabelsTo_24dps(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2espec_2eshapeArms_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2espec_2eshapeArms_entry, 3, 0};

V g_heff_2ecompile_2espec_2eshapeArms(V v_go_240, V v_x2_241, V v_st_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_go_240);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_st_242});
  }
  case TAG_Cons: {
    V v_x21_243 = heff_field(v_x2_241, 0);
    V v_rest_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_243)) {
    case TAG_MkArm: {
      V v_t_245 = heff_field(v_x21_243, 0);
      V v_vs_246 = heff_field(v_x21_243, 1);
      V v_b_247 = heff_field(v_x21_243, 2);
      V v_ru_24x21_243_24MkArm = heff_take_reuse_n(v_x21_243, 7ULL, 3);
      V v_more_248 = heff_tr(heff_call(((V)&g_heff_2ecompile_2espec_2eshapeArms_clo), 2, (V[]){heff_dup(v_go_240), v_rest_244}));
      V v_t_249 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_st_242});
      V v_t_2410 = ({ V a_0 = v_t_249; V a_1 = v_vs_246; V r_ = (g_list_2efoldl_24s1048046132x95752937(a_0, a_1)); heff_drop(v_vs_246); r_; });
      V v_x3_2414;
      switch (heff_tag_of(v_t_2410)) {
      case TAG_MkPair: {
        V v_ys_2411 = heff_field(v_t_2410, 0);
        V v_st2_2412 = heff_field(v_t_2410, 1);
        V v_ru_24t_2410_24MkPair = heff_take_reuse_n(v_t_2410, 3ULL, 2);
        V v_t_2413 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ys_2411));
        v_x3_2414 = heff_tag_at_n(v_ru_24t_2410_24MkPair, TAG_MkPair, 2, (V[]){v_t_2413, v_st2_2412});
        break;
      }
      default: heff_nomatch(v_t_2410);
      }
      V v_x3_2418;
      switch (heff_tag_of(v_x3_2414)) {
      case TAG_MkPair: {
        V v_vs_2415 = heff_field(v_x3_2414, 0);
        V v_st_2416 = heff_field(v_x3_2414, 1);
        V v_ru_24x3_2414_24MkPair = heff_take_reuse_n(v_x3_2414, 3ULL, 2);
        V v_t_2417 = heff_tr(heff_call(v_go_240, 2, (V[]){v_b_247, v_st_2416}));
        v_x3_2418 = heff_tag_at_n(v_ru_24x3_2414_24MkPair, TAG_MkPair, 2, (V[]){v_vs_2415, v_t_2417});
        break;
      }
      default: heff_nomatch(v_x3_2414);
      }
      switch (heff_tag_of(v_x3_2418)) {
      case TAG_MkPair: {
        V v_vs_2419 = heff_field(v_x3_2418, 0);
        V v_x32_2420 = heff_field(v_x3_2418, 1);
        V v_ru_24x3_2418_24MkPair = heff_take_reuse_n(v_x3_2418, 3ULL, 2);
        switch (heff_tag_of(v_x32_2420)) {
        case TAG_MkPair: {
          V v_b_2421 = heff_field(v_x32_2420, 0);
          V v_st_2422 = heff_field(v_x32_2420, 1);
          V v_ru_24x32_2420_24MkPair = heff_take_reuse_n(v_x32_2420, 3ULL, 2);
          V v_x2_2423 = heff_tr(heff_call(v_more_248, 1, (V[]){v_st_2422}));
          switch (heff_tag_of(v_x2_2423)) {
          case TAG_MkPair: {
            V v_as_2424 = heff_field(v_x2_2423, 0);
            V v_st_2425 = heff_field(v_x2_2423, 1);
            heff_take_n(v_x2_2423, 3ULL, 2);
            V v_t_2426 = heff_tag_at_n(v_ru_24x3_2418_24MkPair, TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x21_243_24MkArm, TAG_MkArm, 3, (V[]){v_t_245, v_vs_2419, v_b_2421}), v_as_2424});
            return heff_tag_at_n(v_ru_24x32_2420_24MkPair, TAG_MkPair, 2, (V[]){v_t_2426, v_st_2425});
          }
          default: return heff_nomatch(v_x2_2423);
          }
        }
        default: return heff_nomatch(v_x32_2420);
        }
      }
      default: return heff_nomatch(v_x3_2418);
      }
    }
    default: return heff_nomatch(v_x21_243);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2espec_2eshapeArms_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2espec_2eshapeArms(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ecompile_2espec_2eshapeGo_str0, 4, "lit$");
HEFF_LIT(g_heff_2ecompile_2espec_2eshapeGo_str1, 4, "lit$");
HEFF_LIT(g_heff_2ecompile_2espec_2eshapeGo_str2, 4, "lit$");
HEFF_LIT(g_heff_2ecompile_2espec_2eshapeGo_str3, 4, "lit$");
HEFF_LIT(g_heff_2ecompile_2espec_2eshapeGo_str4, 4, "lit$");
HEFF_LIT(g_heff_2ecompile_2espec_2eshapeGo_str5, 4, "lit$");
Clo g_heff_2ecompile_2espec_2eshapeGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2espec_2eshapeGo_entry, 2, 0};

V g_heff_2ecompile_2espec_2eshapeGo(V v_e_240, V v_st_241) {
top: ;
  switch (heff_tag_of(v_e_240)) {
  case TAG_EVar: {
    V v_x_242 = heff_field(v_e_240, 0);
    V v_ru_24e_240_24EVar = heff_take_reuse_n(v_e_240, 1ULL, 1);
    V v_x2_243 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(v_x_242), heff_rfield(v_st_241, 0)));
    V v_t_245;
    switch (heff_tag_of(v_x2_243)) {
    case TAG_Nothing: {
      v_t_245 = v_x_242;
      break;
    }
    case TAG_Just: {
      V v_x_244 = heff_field(v_x2_243, 0);
      heff_take_n(v_x2_243, 1ULL, 1);
      heff_drop(v_x_242);
      v_t_245 = v_x_244;
      break;
    }
    default: heff_nomatch(v_x2_243);
    }
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24e_240_24EVar, TAG_EVar, 1, (V[]){v_t_245}), v_st_241});
  }
  case TAG_EGlobal: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_240, v_st_241});
  }
  case TAG_ELam: {
    V v_xs_247 = heff_field(v_e_240, 0);
    V v_b_248 = heff_field(v_e_240, 1);
    V v_ru_24e_240_24ELam = heff_take_reuse_n(v_e_240, 3ULL, 2);
    V v_t_249 = heff_tag_at_n(v_ru_24e_240_24ELam, TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_st_241});
    V v_t_2410 = ({ V a_0 = v_t_249; V a_1 = v_xs_247; V r_ = (g_list_2efoldl_24s1048046132x95752937(a_0, a_1)); heff_drop(v_xs_247); r_; });
    V v_x4_2414;
    switch (heff_tag_of(v_t_2410)) {
    case TAG_MkPair: {
      V v_ys_2411 = heff_field(v_t_2410, 0);
      V v_st2_2412 = heff_field(v_t_2410, 1);
      V v_ru_24t_2410_24MkPair = heff_take_reuse_n(v_t_2410, 3ULL, 2);
      V v_t_2413 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ys_2411));
      v_x4_2414 = heff_tag_at_n(v_ru_24t_2410_24MkPair, TAG_MkPair, 2, (V[]){v_t_2413, v_st2_2412});
      break;
    }
    default: heff_nomatch(v_t_2410);
    }
    switch (heff_tag_of(v_x4_2414)) {
    case TAG_MkPair: {
      V v_ys_2415 = heff_field(v_x4_2414, 0);
      V v_st_2416 = heff_field(v_x4_2414, 1);
      V v_ru_24x4_2414_24MkPair = heff_take_reuse_n(v_x4_2414, 3ULL, 2);
      V v_x2_2417 = (g_heff_2ecompile_2espec_2eshapeGo(v_b_248, v_st_2416));
      switch (heff_tag_of(v_x2_2417)) {
      case TAG_MkPair: {
        V v_e_2418 = heff_field(v_x2_2417, 0);
        V v_st_2419 = heff_field(v_x2_2417, 1);
        heff_take_n(v_x2_2417, 3ULL, 2);
        return heff_tag_at_n(v_ru_24x4_2414_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELam, 2, (V[]){v_ys_2415, v_e_2418}), v_st_2419});
      }
      default: return heff_nomatch(v_x2_2417);
      }
    }
    default: return heff_nomatch(v_x4_2414);
    }
  }
  case TAG_EApp: {
    V v_f_2420 = heff_field(v_e_240, 0);
    V v_as_2421 = heff_field(v_e_240, 1);
    V v_ru_24e_240_24EApp = heff_take_reuse_n(v_e_240, 3ULL, 2);
    V v_x3_2422 = (g_heff_2ecompile_2espec_2eshapeGo(v_f_2420, v_st_241));
    switch (heff_tag_of(v_x3_2422)) {
    case TAG_MkPair: {
      V v_f_2423 = heff_field(v_x3_2422, 0);
      V v_st_2424 = heff_field(v_x3_2422, 1);
      heff_take_n(v_x3_2422, 3ULL, 2);
      V v_x2_2425 = (g_heff_2ecompile_2espec_2eshapeMany(((V)&g_heff_2ecompile_2espec_2eshapeGo_clo), v_as_2421, v_st_2424));
      switch (heff_tag_of(v_x2_2425)) {
      case TAG_MkPair: {
        V v_es_2426 = heff_field(v_x2_2425, 0);
        V v_st_2427 = heff_field(v_x2_2425, 1);
        heff_take_n(v_x2_2425, 3ULL, 2);
        return heff_tag_at_n(v_ru_24e_240_24EApp, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_f_2423, v_es_2426}), v_st_2427});
      }
      default: return heff_nomatch(v_x2_2425);
      }
    }
    default: return heff_nomatch(v_x3_2422);
    }
  }
  case TAG_ELet: {
    V v_x_2428 = heff_field(v_e_240, 0);
    V v_a_2429 = heff_field(v_e_240, 1);
    V v_b_2430 = heff_field(v_e_240, 2);
    heff_take_n(v_e_240, 7ULL, 3);
    V v_t_2431 = (g_heff_2ecompile_2espec_2eshapeGo(v_a_2429, v_st_241));
    return (g_heff_2ecompile_2espec_2eletThen(((V)&g_heff_2ecompile_2espec_2eshapeGo_clo), v_x_2428, v_b_2430, v_t_2431));
  }
  case TAG_ERecord: {
    V v_fs_2432 = heff_field(v_e_240, 0);
    V v_ts_2433 = heff_field(v_e_240, 1);
    V v_ru_24e_240_24ERecord = heff_take_reuse_n(v_e_240, 3ULL, 2);
    V v_t_2434 = (g_list_2emap_24s1173914895x100384474(heff_dup(v_fs_2432)));
    V v_x2_2435 = (g_heff_2ecompile_2espec_2eshapeMany(((V)&g_heff_2ecompile_2espec_2eshapeGo_clo), v_t_2434, v_st_241));
    switch (heff_tag_of(v_x2_2435)) {
    case TAG_MkPair: {
      V v_es_2436 = heff_field(v_x2_2435, 0);
      V v_st_2437 = heff_field(v_x2_2435, 1);
      heff_take_n(v_x2_2435, 3ULL, 2);
      V v_t_2438 = (g_heff_2ecompile_2espec_2elabelsTo(v_fs_2432, v_es_2436));
      return heff_tag_at_n(v_ru_24e_240_24ERecord, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ERecord, 2, (V[]){v_t_2438, v_ts_2433}), v_st_2437});
    }
    default: return heff_nomatch(v_x2_2435);
    }
  }
  case TAG_EProj: {
    V v_e1_2439 = heff_field(v_e_240, 0);
    V v_l_2440 = heff_field(v_e_240, 1);
    V v_sh_2441 = heff_field(v_e_240, 2);
    V v_t_2442 = heff_field(v_e_240, 3);
    V v_ru_24e_240_24EProj = heff_take_reuse_n(v_e_240, 15ULL, 4);
    V v_x2_2443 = (g_heff_2ecompile_2espec_2eshapeGo(v_e1_2439, v_st_241));
    switch (heff_tag_of(v_x2_2443)) {
    case TAG_MkPair: {
      V v_e_2444 = heff_field(v_x2_2443, 0);
      V v_st_2445 = heff_field(v_x2_2443, 1);
      V v_ru_24x2_2443_24MkPair = heff_take_reuse_n(v_x2_2443, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2443_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24e_240_24EProj, TAG_EProj, 4, (V[]){v_e_2444, v_l_2440, v_sh_2441, v_t_2442}), v_st_2445});
    }
    default: return heff_nomatch(v_x2_2443);
    }
  }
  case TAG_ETag: {
    V v_t_2446 = heff_field(v_e_240, 0);
    V v_as_2447 = heff_field(v_e_240, 1);
    V v_ru_24e_240_24ETag = heff_take_reuse_n(v_e_240, 3ULL, 2);
    V v_x2_2448 = (g_heff_2ecompile_2espec_2eshapeMany(((V)&g_heff_2ecompile_2espec_2eshapeGo_clo), v_as_2447, v_st_241));
    switch (heff_tag_of(v_x2_2448)) {
    case TAG_MkPair: {
      V v_es_2449 = heff_field(v_x2_2448, 0);
      V v_st_2450 = heff_field(v_x2_2448, 1);
      heff_take_n(v_x2_2448, 3ULL, 2);
      return heff_tag_at_n(v_ru_24e_240_24ETag, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ETag, 2, (V[]){v_t_2446, v_es_2449}), v_st_2450});
    }
    default: return heff_nomatch(v_x2_2448);
    }
  }
  case TAG_EMatch: {
    V v_sc_2451 = heff_field(v_e_240, 0);
    V v_arms_2452 = heff_field(v_e_240, 1);
    V v_ru_24e_240_24EMatch = heff_take_reuse_n(v_e_240, 3ULL, 2);
    V v_x3_2453 = (g_heff_2ecompile_2espec_2eshapeGo(v_sc_2451, v_st_241));
    switch (heff_tag_of(v_x3_2453)) {
    case TAG_MkPair: {
      V v_sc_2454 = heff_field(v_x3_2453, 0);
      V v_st_2455 = heff_field(v_x3_2453, 1);
      heff_take_n(v_x3_2453, 3ULL, 2);
      V v_t_2456 = (g_heff_2ecompile_2espec_2eshapeArms(((V)&g_heff_2ecompile_2espec_2eshapeGo_clo), v_arms_2452, v_st_2455));
      switch (heff_tag_of(v_t_2456)) {
      case TAG_MkPair: {
        V v_arms2_2457 = heff_field(v_t_2456, 0);
        V v_st2_2458 = heff_field(v_t_2456, 1);
        heff_take_n(v_t_2456, 3ULL, 2);
        return heff_tag_at_n(v_ru_24e_240_24EMatch, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_sc_2454, v_arms2_2457}), v_st2_2458});
      }
      default: return heff_nomatch(v_t_2456);
      }
    }
    default: return heff_nomatch(v_x3_2453);
    }
  }
  case TAG_EPrim: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_240, v_st_241});
  }
  case TAG_EPrimCall: {
    V v_p_2460 = heff_field(v_e_240, 0);
    V v_as_2461 = heff_field(v_e_240, 1);
    V v_ru_24e_240_24EPrimCall = heff_take_reuse_n(v_e_240, 3ULL, 2);
    V v_x2_2462 = (g_heff_2ecompile_2espec_2eshapeMany(((V)&g_heff_2ecompile_2espec_2eshapeGo_clo), v_as_2461, v_st_241));
    switch (heff_tag_of(v_x2_2462)) {
    case TAG_MkPair: {
      V v_es_2463 = heff_field(v_x2_2462, 0);
      V v_st_2464 = heff_field(v_x2_2462, 1);
      heff_take_n(v_x2_2462, 3ULL, 2);
      return heff_tag_at_n(v_ru_24e_240_24EPrimCall, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EPrimCall, 2, (V[]){v_p_2460, v_es_2463}), v_st_2464});
    }
    default: return heff_nomatch(v_x2_2462);
    }
  }
  case TAG_ECall: {
    V v_g_2465 = heff_field(v_e_240, 0);
    V v_as_2466 = heff_field(v_e_240, 1);
    V v_ru_24e_240_24ECall = heff_take_reuse_n(v_e_240, 3ULL, 2);
    V v_x2_2467 = (g_heff_2ecompile_2espec_2eshapeMany(((V)&g_heff_2ecompile_2espec_2eshapeGo_clo), v_as_2466, v_st_241));
    switch (heff_tag_of(v_x2_2467)) {
    case TAG_MkPair: {
      V v_es_2468 = heff_field(v_x2_2467, 0);
      V v_st_2469 = heff_field(v_x2_2467, 1);
      heff_take_n(v_x2_2467, 3ULL, 2);
      return heff_tag_at_n(v_ru_24e_240_24ECall, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ECall, 2, (V[]){v_g_2465, v_es_2468}), v_st_2469});
    }
    default: return heff_nomatch(v_x2_2467);
    }
  }
  case TAG_EInt: {
    V v_i_2470 = heff_field(v_e_240, 0);
    V v_ru_24e_240_24EInt = heff_take_reuse_n(v_e_240, 1ULL, 1);
    V v_t_2471 = heff_intShow(heff_dup(heff_rfield(v_st_241, 3)));
    V v_t_2472 = heff_tag_at_n(v_ru_24e_240_24EInt, TAG_EVar, 1, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2espec_2eshapeGo_str0), v_t_2471)});
    V v_t_2473 = heff_intShow(heff_dup(heff_rfield(v_st_241, 3)));
    V v_t_2474 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2espec_2eshapeGo_str1), v_t_2473), heff_take_field(v_st_241, 1)});
    V v_t_2475 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_EInt, 1, (V[]){v_i_2470}), heff_take_field(v_st_241, 2)});
    V v_t_2476 = heff_intAdd(heff_take_field(v_st_241, 3), MK_INT(1LL));
    V v_t_2477 = ({ V rv_1 = v_t_2474; V rv_2 = v_t_2475; V rv_3 = v_t_2476; V rr_ = heff_rec_reuse_nf(v_st_241, 1ULL, 4, shape_ren__vars__holes__n, 3u, 0u); heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; rr_; });
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2472, v_t_2477});
  }
  case TAG_EFloat: {
    V v_x_2478 = heff_field(v_e_240, 0);
    V v_ru_24e_240_24EFloat = heff_take_reuse_n(v_e_240, 1ULL, 1);
    V v_t_2479 = heff_intShow(heff_dup(heff_rfield(v_st_241, 3)));
    V v_t_2480 = heff_tag_at_n(v_ru_24e_240_24EFloat, TAG_EVar, 1, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2espec_2eshapeGo_str2), v_t_2479)});
    V v_t_2481 = heff_intShow(heff_dup(heff_rfield(v_st_241, 3)));
    V v_t_2482 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2espec_2eshapeGo_str3), v_t_2481), heff_take_field(v_st_241, 1)});
    V v_t_2483 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_EFloat, 1, (V[]){v_x_2478}), heff_take_field(v_st_241, 2)});
    V v_t_2484 = heff_intAdd(heff_take_field(v_st_241, 3), MK_INT(1LL));
    V v_t_2485 = ({ V rv_1 = v_t_2482; V rv_2 = v_t_2483; V rv_3 = v_t_2484; V rr_ = heff_rec_reuse_nf(v_st_241, 1ULL, 4, shape_ren__vars__holes__n, 3u, 0u); heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; rr_; });
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2480, v_t_2485});
  }
  case TAG_EStr: {
    V v_t_2486 = heff_field(v_e_240, 0);
    V v_ru_24e_240_24EStr = heff_take_reuse_n(v_e_240, 1ULL, 1);
    V v_t_2487 = heff_intShow(heff_dup(heff_rfield(v_st_241, 3)));
    V v_t_2488 = heff_tag_at_n(v_ru_24e_240_24EStr, TAG_EVar, 1, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2espec_2eshapeGo_str4), v_t_2487)});
    V v_t_2489 = heff_intShow(heff_dup(heff_rfield(v_st_241, 3)));
    V v_t_2490 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2espec_2eshapeGo_str5), v_t_2489), heff_take_field(v_st_241, 1)});
    V v_t_2491 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_EStr, 1, (V[]){v_t_2486}), heff_take_field(v_st_241, 2)});
    V v_t_2492 = heff_intAdd(heff_take_field(v_st_241, 3), MK_INT(1LL));
    V v_t_2493 = ({ V rv_1 = v_t_2490; V rv_2 = v_t_2491; V rv_3 = v_t_2492; V rr_ = heff_rec_reuse_nf(v_st_241, 1ULL, 4, shape_ren__vars__holes__n, 3u, 0u); heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; rr_; });
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2488, v_t_2493});
  }
  case TAG_EBytes: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_240, v_st_241});
  }
  case TAG_EFixed: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_240, v_st_241});
  }
  case TAG_EFloat32: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_240, v_st_241});
  }
  case TAG_EAbandon: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_240, v_st_241});
  }
  case TAG_EFix: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_240, v_st_241});
  }
  default: return heff_nomatch(v_e_240);
  }
}
V g_heff_2ecompile_2espec_2eshapeGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2espec_2eshapeGo(a[0], a[1]);
}
Clo g_heff_2ecompile_2espec_2ecallUse_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2espec_2ecallUse_entry, 3, 0};

V g_heff_2ecompile_2espec_2ecallUse(V v_g_240, V v_x2_241, V v_as_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_EVar: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_g_240);
    heff_drop(v_as_242);
    return NTAG(TAG_Nil);
  }
  case TAG_EGlobal: {
    V v_h_244 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24EGlobal = heff_take_reuse_n(v_x2_241, 1ULL, 1);
    if (heff_strEq_c(v_h_244, v_g_240)) {
      return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x2_241_24EGlobal, TAG_Just, 1, (V[]){v_as_242}), NTAG(TAG_Nil)});
    } else {
      heff_drop(v_as_242);
      heff_drop_cell(v_ru_24x2_241_24EGlobal, 1);
      return NTAG(TAG_Nil);
    }
  }
  case TAG_ELam: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_g_240);
    heff_drop(v_as_242);
    return NTAG(TAG_Nil);
  }
  case TAG_EApp: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_g_240);
    heff_drop(v_as_242);
    return NTAG(TAG_Nil);
  }
  case TAG_ELet: {
    heff_take_n(v_x2_241, 0ULL, 3);
    heff_drop(v_g_240);
    heff_drop(v_as_242);
    return NTAG(TAG_Nil);
  }
  case TAG_ERecord: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_g_240);
    heff_drop(v_as_242);
    return NTAG(TAG_Nil);
  }
  case TAG_EProj: {
    heff_take_n(v_x2_241, 0ULL, 4);
    heff_drop(v_g_240);
    heff_drop(v_as_242);
    return NTAG(TAG_Nil);
  }
  case TAG_ETag: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_g_240);
    heff_drop(v_as_242);
    return NTAG(TAG_Nil);
  }
  case TAG_EMatch: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_g_240);
    heff_drop(v_as_242);
    return NTAG(TAG_Nil);
  }
  case TAG_EPrim: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_g_240);
    heff_drop(v_as_242);
    return NTAG(TAG_Nil);
  }
  case TAG_EPrimCall: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_g_240);
    heff_drop(v_as_242);
    return NTAG(TAG_Nil);
  }
  case TAG_ECall: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_g_240);
    heff_drop(v_as_242);
    return NTAG(TAG_Nil);
  }
  case TAG_EInt: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_g_240);
    heff_drop(v_as_242);
    return NTAG(TAG_Nil);
  }
  case TAG_EFloat: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_g_240);
    heff_drop(v_as_242);
    return NTAG(TAG_Nil);
  }
  case TAG_EStr: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_g_240);
    heff_drop(v_as_242);
    return NTAG(TAG_Nil);
  }
  case TAG_EBytes: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_g_240);
    heff_drop(v_as_242);
    return NTAG(TAG_Nil);
  }
  case TAG_EFixed: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_g_240);
    heff_drop(v_as_242);
    return NTAG(TAG_Nil);
  }
  case TAG_EFloat32: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_g_240);
    heff_drop(v_as_242);
    return NTAG(TAG_Nil);
  }
  case TAG_EAbandon: {
    heff_drop(v_g_240);
    heff_drop(v_as_242);
    return NTAG(TAG_Nil);
  }
  case TAG_EFix: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_g_240);
    heff_drop(v_as_242);
    return NTAG(TAG_Nil);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2espec_2ecallUse_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2espec_2ecallUse(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2espec_2eheadUses_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2espec_2eheadUses_entry, 2, 0};

V g_heff_2ecompile_2espec_2eheadUses(V v_go_240, V v_f_241) {
top: ;
  switch (heff_tag_of(v_f_241)) {
  case TAG_EVar: {
    return heff_tail(v_go_240, 1, (V[]){v_f_241});
  }
  case TAG_EGlobal: {
    heff_take_n(v_f_241, 0ULL, 1);
    heff_drop(v_go_240);
    return NTAG(TAG_Nil);
  }
  case TAG_ELam: {
    return heff_tail(v_go_240, 1, (V[]){v_f_241});
  }
  case TAG_EApp: {
    return heff_tail(v_go_240, 1, (V[]){v_f_241});
  }
  case TAG_ELet: {
    return heff_tail(v_go_240, 1, (V[]){v_f_241});
  }
  case TAG_ERecord: {
    return heff_tail(v_go_240, 1, (V[]){v_f_241});
  }
  case TAG_EProj: {
    return heff_tail(v_go_240, 1, (V[]){v_f_241});
  }
  case TAG_ETag: {
    return heff_tail(v_go_240, 1, (V[]){v_f_241});
  }
  case TAG_EMatch: {
    return heff_tail(v_go_240, 1, (V[]){v_f_241});
  }
  case TAG_EPrim: {
    return heff_tail(v_go_240, 1, (V[]){v_f_241});
  }
  case TAG_EPrimCall: {
    return heff_tail(v_go_240, 1, (V[]){v_f_241});
  }
  case TAG_ECall: {
    return heff_tail(v_go_240, 1, (V[]){v_f_241});
  }
  case TAG_EInt: {
    return heff_tail(v_go_240, 1, (V[]){v_f_241});
  }
  case TAG_EFloat: {
    return heff_tail(v_go_240, 1, (V[]){v_f_241});
  }
  case TAG_EStr: {
    return heff_tail(v_go_240, 1, (V[]){v_f_241});
  }
  case TAG_EBytes: {
    return heff_tail(v_go_240, 1, (V[]){v_f_241});
  }
  case TAG_EFixed: {
    return heff_tail(v_go_240, 1, (V[]){v_f_241});
  }
  case TAG_EFloat32: {
    return heff_tail(v_go_240, 1, (V[]){v_f_241});
  }
  case TAG_EAbandon: {
    return heff_tail(v_go_240, 1, (V[]){v_f_241});
  }
  case TAG_EFix: {
    return heff_tail(v_go_240, 1, (V[]){v_f_241});
  }
  default: return heff_nomatch(v_f_241);
  }
}
V g_heff_2ecompile_2espec_2eheadUses_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2espec_2eheadUses(a[0], a[1]);
}
V g_heff_2ecompile_2espec_2eusesOf_lam0(V self, V *args);
V g_heff_2ecompile_2espec_2eusesOf_lam1(V self, V *args);
V g_heff_2ecompile_2espec_2eusesOf_lam2(V self, V *args);
V g_heff_2ecompile_2espec_2eusesOf_lam3(V self, V *args);
V g_heff_2ecompile_2espec_2eusesOf_lam4(V self, V *args);
V g_heff_2ecompile_2espec_2eusesOf_lam5(V self, V *args);
Clo g_heff_2ecompile_2espec_2eusesOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2espec_2eusesOf_entry, 2, 0};

V g_heff_2ecompile_2espec_2eusesOf(V v_g_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_EVar: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_g_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EGlobal: {
    V v_h_243 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    if (heff_strEq_c(v_h_243, v_g_240)) {
      return heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_Nothing), NTAG(TAG_Nil)});
    } else {
      return NTAG(TAG_Nil);
    }
  }
  case TAG_ELam: {
    V v_b_246 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 2ULL, 2);
    V t_0 = v_g_240;
    V t_1 = v_b_246;
    v_g_240 = t_0;
    v_x2_241 = t_1;
    goto top;
  }
  case TAG_EApp: {
    V v_f_247 = heff_field(v_x2_241, 0);
    V v_as_248 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_t_249 = (g_heff_2ecompile_2espec_2ecallUse(heff_dup(v_g_240), heff_dup(v_f_247), heff_dup(v_as_248)));
    V v_t_2410 = heff_tr(heff_call(((V)&g_heff_2ecompile_2espec_2eusesOf_clo), 1, (V[]){heff_dup(v_g_240)}));
    V v_t_2411 = heff_tr(g_heff_2ecompile_2espec_2eheadUses(v_t_2410, v_f_247));
    V v_f_2412 = heff_tr(heff_call(((V)&g_heff_2ecompile_2espec_2eusesOf_clo), 1, (V[]){v_g_240}));
    V v_t_2413 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_as_248));
    V v_t_2417 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2espec_2eusesOf_lam0, 2, 1, (V[]){v_f_2412}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_2413; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2413); r_; });
    V v_t_2418 = (g_heff_2ecompile_2espec_2eappendS(v_t_2411, v_t_2417));
    HEFF_LAST return g_heff_2ecompile_2espec_2eappendS(v_t_249, v_t_2418);
  }
  case TAG_ELet: {
    V v_a_2420 = heff_field(v_x2_241, 1);
    V v_b_2421 = heff_field(v_x2_241, 2);
    heff_take_n(v_x2_241, 6ULL, 3);
    V v_t_2422 = (g_heff_2ecompile_2espec_2eusesOf(heff_dup(v_g_240), v_a_2420));
    V v_t_2423 = (g_heff_2ecompile_2espec_2eusesOf(v_g_240, v_b_2421));
    HEFF_LAST return g_heff_2ecompile_2espec_2eappendS(v_t_2422, v_t_2423);
  }
  case TAG_ERecord: {
    V v_fs_2424 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 2);
    V v_f_2426 = heff_tr(heff_call(((V)&g_heff_2ecompile_2espec_2eusesOf_clo), 1, (V[]){v_g_240}));
    V v_t_2427 = (g_list_2efoldl_24f1645967390x252727070(NTAG(TAG_Nil), v_fs_2424));
    return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2espec_2eusesOf_lam1, 2, 1, (V[]){v_f_2426}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_2427; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2427); r_; });
  }
  case TAG_EProj: {
    V v_e_2431 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 4);
    V t_0 = v_g_240;
    V t_1 = v_e_2431;
    v_g_240 = t_0;
    v_x2_241 = t_1;
    goto top;
  }
  case TAG_ETag: {
    V v_as_2436 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 2ULL, 2);
    V v_f_2437 = heff_tr(heff_call(((V)&g_heff_2ecompile_2espec_2eusesOf_clo), 1, (V[]){v_g_240}));
    V v_t_2438 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_as_2436));
    return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2espec_2eusesOf_lam2, 2, 1, (V[]){v_f_2437}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_2438; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2438); r_; });
  }
  case TAG_EMatch: {
    V v_s_2442 = heff_field(v_x2_241, 0);
    V v_arms_2443 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_t_2444 = (g_heff_2ecompile_2espec_2eusesOf(heff_dup(v_g_240), v_s_2442));
    V v_f_2445 = heff_tr(heff_call(((V)&g_heff_2ecompile_2espec_2eusesOf_clo), 1, (V[]){v_g_240}));
    V v_t_2446 = (g_list_2efoldl_24f836170601x1639498774(NTAG(TAG_Nil), v_arms_2443));
    V v_t_2450 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2espec_2eusesOf_lam3, 2, 1, (V[]){v_f_2445}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_2446; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2446); r_; });
    HEFF_LAST return g_heff_2ecompile_2espec_2eappendS(v_t_2444, v_t_2450);
  }
  case TAG_EPrim: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_g_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EPrimCall: {
    V v_as_2453 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 2ULL, 2);
    V v_f_2454 = heff_tr(heff_call(((V)&g_heff_2ecompile_2espec_2eusesOf_clo), 1, (V[]){v_g_240}));
    V v_t_2455 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_as_2453));
    return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2espec_2eusesOf_lam4, 2, 1, (V[]){v_f_2454}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_2455; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2455); r_; });
  }
  case TAG_ECall: {
    V v_h_2459 = heff_field(v_x2_241, 0);
    V v_as_2460 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24ECall = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_2462;
    if (heff_strEq_c(v_h_2459, heff_dup(v_g_240))) {
      v_t_2462 = heff_tag_at_n(v_ru_24x2_241_24ECall, TAG_Cons, 2, (V[]){heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_as_2460)}), NTAG(TAG_Nil)});
    } else {
      heff_drop_cell(v_ru_24x2_241_24ECall, 2);
      v_t_2462 = NTAG(TAG_Nil);
    }
    V v_f_2463 = heff_tr(heff_call(((V)&g_heff_2ecompile_2espec_2eusesOf_clo), 1, (V[]){v_g_240}));
    V v_t_2464 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_as_2460));
    V v_t_2468 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2espec_2eusesOf_lam5, 2, 1, (V[]){v_f_2463}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_2464; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2464); r_; });
    HEFF_LAST return g_heff_2ecompile_2espec_2eappendS(v_t_2462, v_t_2468);
  }
  case TAG_EInt: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_g_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EFloat: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_g_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EStr: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_g_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EBytes: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_g_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EFixed: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_g_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EFloat32: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_g_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EAbandon: {
    heff_drop(v_g_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EFix: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_g_240);
    return NTAG(TAG_Nil);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2espec_2eusesOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2espec_2eusesOf(a[0], a[1]);
}
V g_heff_2ecompile_2espec_2eusesOf_lam0(V self, V *args) {
  V v_acc_2414 = args[0];
  V v_x_2415 = args[1];
  V v_f_2412 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2416 = heff_tr(heff_call(v_f_2412, 1, (V[]){v_x_2415}));
  return (g_prelude_2e_2b_2b(v_t_2416, v_acc_2414));
}
V g_heff_2ecompile_2espec_2eusesOf_lam1(V self, V *args) {
  V v_acc_2428 = args[0];
  V v_x_2429 = args[1];
  V v_f_2426 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2430 = heff_tr(heff_call(v_f_2426, 1, (V[]){v_x_2429}));
  return (g_prelude_2e_2b_2b(v_t_2430, v_acc_2428));
}
V g_heff_2ecompile_2espec_2eusesOf_lam2(V self, V *args) {
  V v_acc_2439 = args[0];
  V v_x_2440 = args[1];
  V v_f_2437 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2441 = heff_tr(heff_call(v_f_2437, 1, (V[]){v_x_2440}));
  return (g_prelude_2e_2b_2b(v_t_2441, v_acc_2439));
}
V g_heff_2ecompile_2espec_2eusesOf_lam3(V self, V *args) {
  V v_acc_2447 = args[0];
  V v_x_2448 = args[1];
  V v_f_2445 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2449 = heff_tr(heff_call(v_f_2445, 1, (V[]){v_x_2448}));
  return (g_prelude_2e_2b_2b(v_t_2449, v_acc_2447));
}
V g_heff_2ecompile_2espec_2eusesOf_lam4(V self, V *args) {
  V v_acc_2456 = args[0];
  V v_x_2457 = args[1];
  V v_f_2454 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2458 = heff_tr(heff_call(v_f_2454, 1, (V[]){v_x_2457}));
  return (g_prelude_2e_2b_2b(v_t_2458, v_acc_2456));
}
V g_heff_2ecompile_2espec_2eusesOf_lam5(V self, V *args) {
  V v_acc_2465 = args[0];
  V v_x_2466 = args[1];
  V v_f_2463 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2467 = heff_tr(heff_call(v_f_2463, 1, (V[]){v_x_2466}));
  return (g_prelude_2e_2b_2b(v_t_2467, v_acc_2465));
}
Clo g_heff_2ecompile_2espec_2enthS_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2espec_2enthS_entry, 2, 0};

V g_heff_2ecompile_2espec_2enthS(V v_i_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_i_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    if (heff_intEq_c(heff_dup(v_i_240), MK_INT(0LL))) {
      heff_drop(v_i_240);
      return heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_x_242)});
    } else {
      V t_0 = heff_intSub(v_i_240, MK_INT(1LL));
      V t_1 = v_xs_243;
      v_i_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2espec_2enthS_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2espec_2enthS(a[0], a1); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2espec_2eisVarOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2espec_2eisVarOf_entry, 2, 0};

V g_heff_2ecompile_2espec_2eisVarOf(V v_x_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nothing: {
    heff_drop(v_x_240);
    return NTAG(TAG_False);
  }
  case TAG_Just: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_EVar: {
      V v_y_243 = heff_field(v_x21_242, 0);
      return heff_strEq(v_x_240, heff_dup(v_y_243));
    }
    case TAG_EGlobal: {
      heff_drop(v_x_240);
      return NTAG(TAG_False);
    }
    case TAG_ELam: {
      heff_drop(v_x_240);
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      heff_drop(v_x_240);
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      heff_drop(v_x_240);
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      heff_drop(v_x_240);
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      heff_drop(v_x_240);
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      heff_drop(v_x_240);
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      heff_drop(v_x_240);
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      heff_drop(v_x_240);
      return NTAG(TAG_False);
    }
    case TAG_EPrimCall: {
      heff_drop(v_x_240);
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      heff_drop(v_x_240);
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      heff_drop(v_x_240);
      return NTAG(TAG_False);
    }
    case TAG_EFloat: {
      heff_drop(v_x_240);
      return NTAG(TAG_False);
    }
    case TAG_EStr: {
      heff_drop(v_x_240);
      return NTAG(TAG_False);
    }
    case TAG_EBytes: {
      heff_drop(v_x_240);
      return NTAG(TAG_False);
    }
    case TAG_EFixed: {
      heff_drop(v_x_240);
      return NTAG(TAG_False);
    }
    case TAG_EFloat32: {
      heff_drop(v_x_240);
      return NTAG(TAG_False);
    }
    case TAG_EAbandon: {
      heff_drop(v_x_240);
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      heff_drop(v_x_240);
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2espec_2eisVarOf_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2espec_2eisVarOf(a[0], a1); heff_drop(a1); return r;
}
V g_heff_2ecompile_2espec_2estaticGo_lam0(V self, V *args);
Clo g_heff_2ecompile_2espec_2estaticGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2espec_2estaticGo_entry, 3, 0};

V g_heff_2ecompile_2espec_2estaticGo(V v_uses_240, V v_x2_241, V v_i_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_i_242);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_248 = (g_heff_2ecompile_2espec_2eallS(heff_clo_n(g_heff_2ecompile_2espec_2estaticGo_lam0, 1, 2, (V[]){heff_dup(v_i_242), v_x_243}), v_uses_240));
    V v_cell_249 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_248, heff_hole()});
    V v_u_2410 = (g_heff_2ecompile_2espec_2estaticGo_24dps(v_uses_240, v_xs_244, heff_intAdd(v_i_242, MK_INT(1LL)), heff_dup(v_cell_249)));
    heff_drop(v_u_2410);
    return v_cell_249;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2espec_2estaticGo_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2espec_2estaticGo(a0, a[1], a[2]); heff_drop(a0); return r;
}
V g_heff_2ecompile_2espec_2estaticGo_lam0(V self, V *args) {
  V v_x3_245 = args[0];
  V v_i_242 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_x3_245)) {
  case TAG_Nothing: {
    heff_drop(v_i_242);
    heff_drop(v_x_243);
    return NTAG(TAG_False);
  }
  case TAG_Just: {
    V v_as_246 = heff_field(v_x3_245, 0);
    heff_take_n(v_x3_245, 1ULL, 1);
    V v_t_247 = ({ V a_0 = v_i_242; V a_1 = v_as_246; V r_ = (g_heff_2ecompile_2espec_2enthS(a_0, a_1)); heff_drop(v_as_246); r_; });
    return ({ V a_0 = v_x_243; V a_1 = v_t_247; V r_ = (g_heff_2ecompile_2espec_2eisVarOf(a_0, a_1)); heff_drop(v_t_247); r_; });
  }
  default: return heff_nomatch(v_x3_245);
  }
}
V g_heff_2ecompile_2espec_2estaticGo_24dps_lam0(V self, V *args);
Clo g_heff_2ecompile_2espec_2estaticGo_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2espec_2estaticGo_24dps_entry, 4, 0};

V g_heff_2ecompile_2espec_2estaticGo_24dps(V v_uses_240, V v_x2_241, V v_i_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_i_242);
    return heff_setField(v_d_243, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_241, 0);
    V v_xs_245 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_249 = (g_heff_2ecompile_2espec_2eallS(heff_clo_n(g_heff_2ecompile_2espec_2estaticGo_24dps_lam0, 1, 2, (V[]){heff_dup(v_i_242), v_x_244}), v_uses_240));
    V v_cell_2410 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_249, heff_hole()});
    V v_u_2411 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_2410));
    heff_drop(v_u_2411);
    V t_0 = v_uses_240;
    V t_1 = v_xs_245;
    V t_2 = heff_intAdd(v_i_242, MK_INT(1LL));
    V t_3 = v_cell_2410;
    v_uses_240 = t_0;
    v_x2_241 = t_1;
    v_i_242 = t_2;
    v_d_243 = t_3;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2espec_2estaticGo_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2espec_2estaticGo_24dps(a0, a[1], a[2], a[3]); heff_drop(a0); return r;
}
V g_heff_2ecompile_2espec_2estaticGo_24dps_lam0(V self, V *args) {
  V v_x3_246 = args[0];
  V v_i_242 = heff_env(self)[0];
  V v_x_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_x3_246)) {
  case TAG_Nothing: {
    heff_drop(v_i_242);
    heff_drop(v_x_244);
    return NTAG(TAG_False);
  }
  case TAG_Just: {
    V v_as_247 = heff_field(v_x3_246, 0);
    heff_take_n(v_x3_246, 1ULL, 1);
    V v_t_248 = ({ V a_0 = v_i_242; V a_1 = v_as_247; V r_ = (g_heff_2ecompile_2espec_2enthS(a_0, a_1)); heff_drop(v_as_247); r_; });
    return ({ V a_0 = v_x_244; V a_1 = v_t_248; V r_ = (g_heff_2ecompile_2espec_2eisVarOf(a_0, a_1)); heff_drop(v_t_248); r_; });
  }
  default: return heff_nomatch(v_x3_246);
  }
}
Clo g_heff_2ecompile_2espec_2edropAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2espec_2edropAt_entry, 2, 0};

V g_heff_2ecompile_2espec_2edropAt(V v_x1_240, V v_as_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return v_as_241;
  }
  case TAG_Cons: {
    V v_d_242 = heff_field(v_x1_240, 0);
    V v_ds_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_as_241)) {
    case TAG_Nil: {
      heff_drop(v_d_242);
      heff_drop(v_ds_243);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_a_244 = heff_field(v_as_241, 0);
      V v_as2_245 = heff_field(v_as_241, 1);
      heff_take_n(v_as_241, 3ULL, 2);
      if ((heff_dup(v_d_242) == NTAG(TAG_True))) {
        heff_drop(v_d_242);
        heff_drop_cell(v_ru_24x1_240_24Cons, 2);
        heff_drop(v_a_244);
        V t_0 = v_ds_243;
        V t_1 = v_as2_245;
        v_x1_240 = t_0;
        v_as_241 = t_1;
        goto top;
      } else {
        heff_drop(v_d_242);
        V v_cell_246 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_a_244, heff_hole()});
        V v_u_247 = (g_heff_2ecompile_2espec_2edropAt_24dps(v_ds_243, v_as2_245, heff_dup(v_cell_246)));
        heff_drop(v_u_247);
        return v_cell_246;
      }
    }
    default: return heff_nomatch(v_as_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2espec_2edropAt_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2espec_2edropAt(a[0], a[1]);
}
Clo g_heff_2ecompile_2espec_2edropAt_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2espec_2edropAt_24dps_entry, 3, 0};

V g_heff_2ecompile_2espec_2edropAt_24dps(V v_x1_240, V v_as_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_242, MK_INT(1LL), v_as_241);
  }
  case TAG_Cons: {
    V v_d_243 = heff_field(v_x1_240, 0);
    V v_ds_244 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_as_241)) {
    case TAG_Nil: {
      heff_drop(v_d_243);
      heff_drop(v_ds_244);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_Cons: {
      V v_a_245 = heff_field(v_as_241, 0);
      V v_as2_246 = heff_field(v_as_241, 1);
      heff_take_n(v_as_241, 3ULL, 2);
      if ((heff_dup(v_d_243) == NTAG(TAG_True))) {
        heff_drop(v_d_243);
        heff_drop_cell(v_ru_24x1_240_24Cons, 2);
        heff_drop(v_a_245);
        V t_0 = v_ds_244;
        V t_1 = v_as2_246;
        V t_2 = v_d_242;
        v_x1_240 = t_0;
        v_as_241 = t_1;
        v_d_242 = t_2;
        goto top;
      } else {
        heff_drop(v_d_243);
        V v_cell_247 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_a_245, heff_hole()});
        V v_u_248 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_247));
        heff_drop(v_u_248);
        V t_0 = v_ds_244;
        V t_1 = v_as2_246;
        V t_2 = v_cell_247;
        v_x1_240 = t_0;
        v_as_241 = t_1;
        v_d_242 = t_2;
        goto top;
      }
    }
    default: return heff_nomatch(v_as_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2espec_2edropAt_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2espec_2edropAt_24dps(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2espec_2eselfHead_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2espec_2eselfHead_entry, 4, 0};

V g_heff_2ecompile_2espec_2eselfHead(V v_go_240, V v_g_241, V v_h_242, V v_f_243) {
top: ;
  switch (heff_tag_of(v_f_243)) {
  case TAG_EVar: {
    heff_drop(v_g_241);
    heff_drop(v_h_242);
    return heff_tail(v_go_240, 1, (V[]){v_f_243});
  }
  case TAG_EGlobal: {
    V v_k_245 = heff_field(v_f_243, 0);
    V v_ru_24f_243_24EGlobal = heff_take_reuse_n(v_f_243, 1ULL, 1);
    heff_drop(v_go_240);
    V v_t_247;
    if (heff_strEq_c(heff_dup(v_k_245), v_g_241)) {
      heff_drop(v_k_245);
      v_t_247 = v_h_242;
    } else {
      heff_drop(v_h_242);
      v_t_247 = v_k_245;
    }
    return heff_tag_at_n(v_ru_24f_243_24EGlobal, TAG_EGlobal, 1, (V[]){v_t_247});
  }
  case TAG_ELam: {
    heff_drop(v_g_241);
    heff_drop(v_h_242);
    return heff_tail(v_go_240, 1, (V[]){v_f_243});
  }
  case TAG_EApp: {
    heff_drop(v_g_241);
    heff_drop(v_h_242);
    return heff_tail(v_go_240, 1, (V[]){v_f_243});
  }
  case TAG_ELet: {
    heff_drop(v_g_241);
    heff_drop(v_h_242);
    return heff_tail(v_go_240, 1, (V[]){v_f_243});
  }
  case TAG_ERecord: {
    heff_drop(v_g_241);
    heff_drop(v_h_242);
    return heff_tail(v_go_240, 1, (V[]){v_f_243});
  }
  case TAG_EProj: {
    heff_drop(v_g_241);
    heff_drop(v_h_242);
    return heff_tail(v_go_240, 1, (V[]){v_f_243});
  }
  case TAG_ETag: {
    heff_drop(v_g_241);
    heff_drop(v_h_242);
    return heff_tail(v_go_240, 1, (V[]){v_f_243});
  }
  case TAG_EMatch: {
    heff_drop(v_g_241);
    heff_drop(v_h_242);
    return heff_tail(v_go_240, 1, (V[]){v_f_243});
  }
  case TAG_EPrim: {
    heff_drop(v_g_241);
    heff_drop(v_h_242);
    return heff_tail(v_go_240, 1, (V[]){v_f_243});
  }
  case TAG_EPrimCall: {
    heff_drop(v_g_241);
    heff_drop(v_h_242);
    return heff_tail(v_go_240, 1, (V[]){v_f_243});
  }
  case TAG_ECall: {
    heff_drop(v_g_241);
    heff_drop(v_h_242);
    return heff_tail(v_go_240, 1, (V[]){v_f_243});
  }
  case TAG_EInt: {
    heff_drop(v_g_241);
    heff_drop(v_h_242);
    return heff_tail(v_go_240, 1, (V[]){v_f_243});
  }
  case TAG_EFloat: {
    heff_drop(v_g_241);
    heff_drop(v_h_242);
    return heff_tail(v_go_240, 1, (V[]){v_f_243});
  }
  case TAG_EStr: {
    heff_drop(v_g_241);
    heff_drop(v_h_242);
    return heff_tail(v_go_240, 1, (V[]){v_f_243});
  }
  case TAG_EBytes: {
    heff_drop(v_g_241);
    heff_drop(v_h_242);
    return heff_tail(v_go_240, 1, (V[]){v_f_243});
  }
  case TAG_EFixed: {
    heff_drop(v_g_241);
    heff_drop(v_h_242);
    return heff_tail(v_go_240, 1, (V[]){v_f_243});
  }
  case TAG_EFloat32: {
    heff_drop(v_g_241);
    heff_drop(v_h_242);
    return heff_tail(v_go_240, 1, (V[]){v_f_243});
  }
  case TAG_EAbandon: {
    heff_drop(v_g_241);
    heff_drop(v_h_242);
    return heff_tail(v_go_240, 1, (V[]){v_f_243});
  }
  case TAG_EFix: {
    heff_drop(v_g_241);
    heff_drop(v_h_242);
    return heff_tail(v_go_240, 1, (V[]){v_f_243});
  }
  default: return heff_nomatch(v_f_243);
  }
}
V g_heff_2ecompile_2espec_2eselfHead_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2espec_2eselfHead(a[0], a[1], a[2], a[3]);
}
Clo g_heff_2ecompile_2espec_2eselfArgs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2espec_2eselfArgs_entry, 5, 0};

V g_heff_2ecompile_2espec_2eselfArgs(V v_g_240, V v_pre_241, V v_ds_242, V v_f_243, V v_as_244) {
top: ;
  switch (heff_tag_of(v_f_243)) {
  case TAG_EVar: {
    heff_drop(v_g_240);
    heff_drop(v_pre_241);
    heff_drop(v_ds_242);
    return v_as_244;
  }
  case TAG_EGlobal: {
    V v_k_246 = heff_field(v_f_243, 0);
    if (heff_strEq_c(heff_dup(v_k_246), v_g_240)) {
      V v_t_248 = (g_heff_2ecompile_2espec_2edropAt(v_ds_242, v_as_244));
      return (g_heff_2ecompile_2espec_2eappendS(v_pre_241, v_t_248));
    } else {
      heff_drop(v_pre_241);
      heff_drop(v_ds_242);
      return v_as_244;
    }
  }
  case TAG_ELam: {
    heff_drop(v_g_240);
    heff_drop(v_pre_241);
    heff_drop(v_ds_242);
    return v_as_244;
  }
  case TAG_EApp: {
    heff_drop(v_g_240);
    heff_drop(v_pre_241);
    heff_drop(v_ds_242);
    return v_as_244;
  }
  case TAG_ELet: {
    heff_drop(v_g_240);
    heff_drop(v_pre_241);
    heff_drop(v_ds_242);
    return v_as_244;
  }
  case TAG_ERecord: {
    heff_drop(v_g_240);
    heff_drop(v_pre_241);
    heff_drop(v_ds_242);
    return v_as_244;
  }
  case TAG_EProj: {
    heff_drop(v_g_240);
    heff_drop(v_pre_241);
    heff_drop(v_ds_242);
    return v_as_244;
  }
  case TAG_ETag: {
    heff_drop(v_g_240);
    heff_drop(v_pre_241);
    heff_drop(v_ds_242);
    return v_as_244;
  }
  case TAG_EMatch: {
    heff_drop(v_g_240);
    heff_drop(v_pre_241);
    heff_drop(v_ds_242);
    return v_as_244;
  }
  case TAG_EPrim: {
    heff_drop(v_g_240);
    heff_drop(v_pre_241);
    heff_drop(v_ds_242);
    return v_as_244;
  }
  case TAG_EPrimCall: {
    heff_drop(v_g_240);
    heff_drop(v_pre_241);
    heff_drop(v_ds_242);
    return v_as_244;
  }
  case TAG_ECall: {
    heff_drop(v_g_240);
    heff_drop(v_pre_241);
    heff_drop(v_ds_242);
    return v_as_244;
  }
  case TAG_EInt: {
    heff_drop(v_g_240);
    heff_drop(v_pre_241);
    heff_drop(v_ds_242);
    return v_as_244;
  }
  case TAG_EFloat: {
    heff_drop(v_g_240);
    heff_drop(v_pre_241);
    heff_drop(v_ds_242);
    return v_as_244;
  }
  case TAG_EStr: {
    heff_drop(v_g_240);
    heff_drop(v_pre_241);
    heff_drop(v_ds_242);
    return v_as_244;
  }
  case TAG_EBytes: {
    heff_drop(v_g_240);
    heff_drop(v_pre_241);
    heff_drop(v_ds_242);
    return v_as_244;
  }
  case TAG_EFixed: {
    heff_drop(v_g_240);
    heff_drop(v_pre_241);
    heff_drop(v_ds_242);
    return v_as_244;
  }
  case TAG_EFloat32: {
    heff_drop(v_g_240);
    heff_drop(v_pre_241);
    heff_drop(v_ds_242);
    return v_as_244;
  }
  case TAG_EAbandon: {
    heff_drop(v_g_240);
    heff_drop(v_pre_241);
    heff_drop(v_ds_242);
    return v_as_244;
  }
  case TAG_EFix: {
    heff_drop(v_g_240);
    heff_drop(v_pre_241);
    heff_drop(v_ds_242);
    return v_as_244;
  }
  default: return heff_nomatch(v_f_243);
  }
}
V g_heff_2ecompile_2espec_2eselfArgs_entry(V self, V *a) {
  (void)self;
  V a3 = a[3]; V r = g_heff_2ecompile_2espec_2eselfArgs(a[0], a[1], a[2], a3, a[4]); heff_drop(a3); return r;
}
V g_heff_2ecompile_2espec_2eselfTo_lam0(V self, V *args);
V g_heff_2ecompile_2espec_2eselfTo_lam1(V self, V *args);
Clo g_heff_2ecompile_2espec_2eselfTo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2espec_2eselfTo_entry, 5, 0};

V g_heff_2ecompile_2espec_2eselfTo(V v_g_240, V v_h_241, V v_pre_242, V v_ds_243, V v_e_244) {
top: ;
  switch (heff_tag_of(v_e_244)) {
  case TAG_EVar: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_pre_242);
    heff_drop(v_ds_243);
    return v_e_244;
  }
  case TAG_EGlobal: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_pre_242);
    heff_drop(v_ds_243);
    return v_e_244;
  }
  case TAG_ELam: {
    V v_xs_247 = heff_field(v_e_244, 0);
    V v_b_248 = heff_field(v_e_244, 1);
    V v_ru_24e_244_24ELam = heff_take_reuse_n(v_e_244, 3ULL, 2);
    V v_cell_249 = heff_tag_at_n(v_ru_24e_244_24ELam, TAG_ELam, 2, (V[]){v_xs_247, heff_hole()});
    V v_u_2410 = (g_heff_2ecompile_2espec_2eselfTo_24dps(v_g_240, v_h_241, v_pre_242, v_ds_243, v_b_248, heff_dup(v_cell_249), MK_INT(1LL)));
    heff_drop(v_u_2410);
    return v_cell_249;
  }
  case TAG_EApp: {
    V v_f_2411 = heff_field(v_e_244, 0);
    V v_as_2412 = heff_field(v_e_244, 1);
    V v_ru_24e_244_24EApp = heff_take_reuse_n(v_e_244, 3ULL, 2);
    V v_t_2413 = heff_tr(heff_call(((V)&g_heff_2ecompile_2espec_2eselfTo_clo), 4, (V[]){heff_dup(v_g_240), heff_dup(v_h_241), heff_dup(v_pre_242), heff_dup(v_ds_243)}));
    V v_t_2414 = heff_tr(g_heff_2ecompile_2espec_2eselfHead(v_t_2413, heff_dup(v_g_240), heff_dup(v_h_241), heff_dup(v_f_2411)));
    V v_t_2415 = heff_tr(heff_call(((V)&g_heff_2ecompile_2espec_2eselfTo_clo), 4, (V[]){heff_dup(v_g_240), v_h_241, heff_dup(v_pre_242), heff_dup(v_ds_243)}));
    V v_t_2416 = ({ V a_0 = v_g_240; V a_1 = v_pre_242; V a_2 = v_ds_243; V a_3 = v_f_2411; V a_4 = v_as_2412; V r_ = (g_heff_2ecompile_2espec_2eselfArgs(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_f_2411); r_; });
    V v_t_2417 = (g_list_2emap(v_t_2415, v_t_2416));
    return heff_tag_at_n(v_ru_24e_244_24EApp, TAG_EApp, 2, (V[]){v_t_2414, v_t_2417});
  }
  case TAG_ELet: {
    V v_x_2418 = heff_field(v_e_244, 0);
    V v_a_2419 = heff_field(v_e_244, 1);
    V v_b_2420 = heff_field(v_e_244, 2);
    V v_ru_24e_244_24ELet = heff_take_reuse_n(v_e_244, 7ULL, 3);
    V v_t_2421 = (g_heff_2ecompile_2espec_2eselfTo(heff_dup(v_g_240), heff_dup(v_h_241), heff_dup(v_pre_242), heff_dup(v_ds_243), v_a_2419));
    V v_cell_2422 = heff_tag_at_n(v_ru_24e_244_24ELet, TAG_ELet, 3, (V[]){v_x_2418, v_t_2421, heff_hole()});
    V v_u_2423 = (g_heff_2ecompile_2espec_2eselfTo_24dps(v_g_240, v_h_241, v_pre_242, v_ds_243, v_b_2420, heff_dup(v_cell_2422), MK_INT(2LL)));
    heff_drop(v_u_2423);
    return v_cell_2422;
  }
  case TAG_ERecord: {
    V v_fs_2424 = heff_field(v_e_244, 0);
    V v_ts_2425 = heff_field(v_e_244, 1);
    V v_ru_24e_244_24ERecord = heff_take_reuse_n(v_e_244, 3ULL, 2);
    V v_go_2426 = heff_tr(heff_call(((V)&g_heff_2ecompile_2espec_2eselfTo_clo), 4, (V[]){v_g_240, v_h_241, v_pre_242, v_ds_243}));
    V v_t_2431 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2espec_2eselfTo_lam0, 1, 1, (V[]){v_go_2426}), v_fs_2424));
    return heff_tag_at_n(v_ru_24e_244_24ERecord, TAG_ERecord, 2, (V[]){v_t_2431, v_ts_2425});
  }
  case TAG_EProj: {
    V v_e1_2432 = heff_field(v_e_244, 0);
    V v_l_2433 = heff_field(v_e_244, 1);
    V v_sh_2434 = heff_field(v_e_244, 2);
    V v_t_2435 = heff_field(v_e_244, 3);
    V v_ru_24e_244_24EProj = heff_take_reuse_n(v_e_244, 15ULL, 4);
    V v_t_2436 = (g_heff_2ecompile_2espec_2eselfTo(v_g_240, v_h_241, v_pre_242, v_ds_243, v_e1_2432));
    return heff_tag_at_n(v_ru_24e_244_24EProj, TAG_EProj, 4, (V[]){v_t_2436, v_l_2433, v_sh_2434, v_t_2435});
  }
  case TAG_ETag: {
    V v_t_2437 = heff_field(v_e_244, 0);
    V v_as_2438 = heff_field(v_e_244, 1);
    V v_ru_24e_244_24ETag = heff_take_reuse_n(v_e_244, 3ULL, 2);
    V v_t_2439 = heff_tr(heff_call(((V)&g_heff_2ecompile_2espec_2eselfTo_clo), 4, (V[]){v_g_240, v_h_241, v_pre_242, v_ds_243}));
    V v_t_2440 = (g_list_2emap(v_t_2439, v_as_2438));
    return heff_tag_at_n(v_ru_24e_244_24ETag, TAG_ETag, 2, (V[]){v_t_2437, v_t_2440});
  }
  case TAG_EMatch: {
    V v_s_2441 = heff_field(v_e_244, 0);
    V v_arms_2442 = heff_field(v_e_244, 1);
    V v_ru_24e_244_24EMatch = heff_take_reuse_n(v_e_244, 3ULL, 2);
    V v_t_2443 = (g_heff_2ecompile_2espec_2eselfTo(heff_dup(v_g_240), heff_dup(v_h_241), heff_dup(v_pre_242), heff_dup(v_ds_243), v_s_2441));
    V v_go_2444 = heff_tr(heff_call(((V)&g_heff_2ecompile_2espec_2eselfTo_clo), 4, (V[]){v_g_240, v_h_241, v_pre_242, v_ds_243}));
    V v_t_2450 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2espec_2eselfTo_lam1, 1, 1, (V[]){v_go_2444}), v_arms_2442));
    return heff_tag_at_n(v_ru_24e_244_24EMatch, TAG_EMatch, 2, (V[]){v_t_2443, v_t_2450});
  }
  case TAG_EPrim: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_pre_242);
    heff_drop(v_ds_243);
    return v_e_244;
  }
  case TAG_EPrimCall: {
    V v_p_2452 = heff_field(v_e_244, 0);
    V v_as_2453 = heff_field(v_e_244, 1);
    V v_ru_24e_244_24EPrimCall = heff_take_reuse_n(v_e_244, 3ULL, 2);
    V v_t_2454 = heff_tr(heff_call(((V)&g_heff_2ecompile_2espec_2eselfTo_clo), 4, (V[]){v_g_240, v_h_241, v_pre_242, v_ds_243}));
    V v_t_2455 = (g_list_2emap(v_t_2454, v_as_2453));
    return heff_tag_at_n(v_ru_24e_244_24EPrimCall, TAG_EPrimCall, 2, (V[]){v_p_2452, v_t_2455});
  }
  case TAG_ECall: {
    V v_k_2456 = heff_field(v_e_244, 0);
    V v_as_2457 = heff_field(v_e_244, 1);
    V v_ru_24e_244_24ECall = heff_take_reuse_n(v_e_244, 3ULL, 2);
    V v_t_2458 = heff_tr(heff_call(((V)&g_heff_2ecompile_2espec_2eselfTo_clo), 4, (V[]){v_g_240, v_h_241, v_pre_242, v_ds_243}));
    V v_t_2459 = (g_list_2emap(v_t_2458, v_as_2457));
    return heff_tag_at_n(v_ru_24e_244_24ECall, TAG_ECall, 2, (V[]){v_k_2456, v_t_2459});
  }
  case TAG_EInt: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_pre_242);
    heff_drop(v_ds_243);
    return v_e_244;
  }
  case TAG_EFloat: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_pre_242);
    heff_drop(v_ds_243);
    return v_e_244;
  }
  case TAG_EStr: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_pre_242);
    heff_drop(v_ds_243);
    return v_e_244;
  }
  case TAG_EBytes: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_pre_242);
    heff_drop(v_ds_243);
    return v_e_244;
  }
  case TAG_EFixed: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_pre_242);
    heff_drop(v_ds_243);
    return v_e_244;
  }
  case TAG_EFloat32: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_pre_242);
    heff_drop(v_ds_243);
    return v_e_244;
  }
  case TAG_EAbandon: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_pre_242);
    heff_drop(v_ds_243);
    return v_e_244;
  }
  case TAG_EFix: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_pre_242);
    heff_drop(v_ds_243);
    return v_e_244;
  }
  default: return heff_nomatch(v_e_244);
  }
}
V g_heff_2ecompile_2espec_2eselfTo_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2espec_2eselfTo(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ecompile_2espec_2eselfTo_lam0(V self, V *args) {
  V v_x2_2427 = args[0];
  V v_go_2426 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x2_2427)) {
  case TAG_MkPair: {
    V v_l_2428 = heff_field(v_x2_2427, 0);
    V v_v_2429 = heff_field(v_x2_2427, 1);
    V v_ru_24x2_2427_24MkPair = heff_take_reuse_n(v_x2_2427, 3ULL, 2);
    V v_t_2430 = heff_tr(heff_call(v_go_2426, 1, (V[]){v_v_2429}));
    return heff_tag_at_n(v_ru_24x2_2427_24MkPair, TAG_MkPair, 2, (V[]){v_l_2428, v_t_2430});
  }
  default: return heff_nomatch(v_x2_2427);
  }
}
V g_heff_2ecompile_2espec_2eselfTo_lam1(V self, V *args) {
  V v_x2_2445 = args[0];
  V v_go_2444 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x2_2445)) {
  case TAG_MkArm: {
    V v_t_2446 = heff_field(v_x2_2445, 0);
    V v_vs_2447 = heff_field(v_x2_2445, 1);
    V v_b_2448 = heff_field(v_x2_2445, 2);
    V v_ru_24x2_2445_24MkArm = heff_take_reuse_n(v_x2_2445, 7ULL, 3);
    V v_t_2449 = heff_tr(heff_call(v_go_2444, 1, (V[]){v_b_2448}));
    return heff_tag_at_n(v_ru_24x2_2445_24MkArm, TAG_MkArm, 3, (V[]){v_t_2446, v_vs_2447, v_t_2449});
  }
  default: return heff_nomatch(v_x2_2445);
  }
}
V g_heff_2ecompile_2espec_2eselfTo_24dps_lam0(V self, V *args);
V g_heff_2ecompile_2espec_2eselfTo_24dps_lam1(V self, V *args);
Clo g_heff_2ecompile_2espec_2eselfTo_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2espec_2eselfTo_24dps_entry, 7, 0};

V g_heff_2ecompile_2espec_2eselfTo_24dps(V v_g_240, V v_h_241, V v_pre_242, V v_ds_243, V v_e_244, V v_d_245, V v_i_246) {
top: ;
  switch (heff_tag_of(v_e_244)) {
  case TAG_EVar: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_pre_242);
    heff_drop(v_ds_243);
    return heff_setField(v_d_245, v_i_246, v_e_244);
  }
  case TAG_EGlobal: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_pre_242);
    heff_drop(v_ds_243);
    return heff_setField(v_d_245, v_i_246, v_e_244);
  }
  case TAG_ELam: {
    V v_xs_249 = heff_field(v_e_244, 0);
    V v_b_2410 = heff_field(v_e_244, 1);
    V v_ru_24e_244_24ELam = heff_take_reuse_n(v_e_244, 3ULL, 2);
    V v_cell_2411 = heff_tag_at_n(v_ru_24e_244_24ELam, TAG_ELam, 2, (V[]){v_xs_249, heff_hole()});
    V v_u_2412 = heff_setField(v_d_245, v_i_246, heff_dup(v_cell_2411));
    heff_drop(v_u_2412);
    V t_0 = v_g_240;
    V t_1 = v_h_241;
    V t_2 = v_pre_242;
    V t_3 = v_ds_243;
    V t_4 = v_b_2410;
    V t_5 = v_cell_2411;
    V t_6 = MK_INT(1LL);
    v_g_240 = t_0;
    v_h_241 = t_1;
    v_pre_242 = t_2;
    v_ds_243 = t_3;
    v_e_244 = t_4;
    v_d_245 = t_5;
    v_i_246 = t_6;
    goto top;
  }
  case TAG_EApp: {
    V v_f_2413 = heff_field(v_e_244, 0);
    V v_as_2414 = heff_field(v_e_244, 1);
    heff_take_n(v_e_244, 3ULL, 2);
    V v_t_2415 = heff_tr(heff_call(((V)&g_heff_2ecompile_2espec_2eselfTo_clo), 4, (V[]){heff_dup(v_g_240), heff_dup(v_h_241), heff_dup(v_pre_242), heff_dup(v_ds_243)}));
    V v_t_2416 = heff_tr(g_heff_2ecompile_2espec_2eselfHead(v_t_2415, heff_dup(v_g_240), heff_dup(v_h_241), heff_dup(v_f_2413)));
    V v_t_2417 = heff_tr(heff_call(((V)&g_heff_2ecompile_2espec_2eselfTo_clo), 4, (V[]){heff_dup(v_g_240), v_h_241, heff_dup(v_pre_242), heff_dup(v_ds_243)}));
    V v_t_2418 = ({ V a_0 = v_g_240; V a_1 = v_pre_242; V a_2 = v_ds_243; V a_3 = v_f_2413; V a_4 = v_as_2414; V r_ = (g_heff_2ecompile_2espec_2eselfArgs(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_f_2413); r_; });
    V v_t_2419 = (g_list_2emap(v_t_2417, v_t_2418));
    return heff_setField(v_d_245, v_i_246, heff_tag_n(TAG_EApp, 2, (V[]){v_t_2416, v_t_2419}));
  }
  case TAG_ELet: {
    V v_x_2420 = heff_field(v_e_244, 0);
    V v_a_2421 = heff_field(v_e_244, 1);
    V v_b_2422 = heff_field(v_e_244, 2);
    V v_ru_24e_244_24ELet = heff_take_reuse_n(v_e_244, 7ULL, 3);
    V v_t_2423 = (g_heff_2ecompile_2espec_2eselfTo(heff_dup(v_g_240), heff_dup(v_h_241), heff_dup(v_pre_242), heff_dup(v_ds_243), v_a_2421));
    V v_cell_2424 = heff_tag_at_n(v_ru_24e_244_24ELet, TAG_ELet, 3, (V[]){v_x_2420, v_t_2423, heff_hole()});
    V v_u_2425 = heff_setField(v_d_245, v_i_246, heff_dup(v_cell_2424));
    heff_drop(v_u_2425);
    V t_0 = v_g_240;
    V t_1 = v_h_241;
    V t_2 = v_pre_242;
    V t_3 = v_ds_243;
    V t_4 = v_b_2422;
    V t_5 = v_cell_2424;
    V t_6 = MK_INT(2LL);
    v_g_240 = t_0;
    v_h_241 = t_1;
    v_pre_242 = t_2;
    v_ds_243 = t_3;
    v_e_244 = t_4;
    v_d_245 = t_5;
    v_i_246 = t_6;
    goto top;
  }
  case TAG_ERecord: {
    V v_fs_2426 = heff_field(v_e_244, 0);
    V v_ts_2427 = heff_field(v_e_244, 1);
    heff_take_n(v_e_244, 3ULL, 2);
    V v_go_2428 = heff_tr(heff_call(((V)&g_heff_2ecompile_2espec_2eselfTo_clo), 4, (V[]){v_g_240, v_h_241, v_pre_242, v_ds_243}));
    V v_t_2433 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2espec_2eselfTo_24dps_lam0, 1, 1, (V[]){v_go_2428}), v_fs_2426));
    return heff_setField(v_d_245, v_i_246, heff_tag_n(TAG_ERecord, 2, (V[]){v_t_2433, v_ts_2427}));
  }
  case TAG_EProj: {
    V v_e1_2434 = heff_field(v_e_244, 0);
    V v_l_2435 = heff_field(v_e_244, 1);
    V v_sh_2436 = heff_field(v_e_244, 2);
    V v_t_2437 = heff_field(v_e_244, 3);
    heff_take_n(v_e_244, 15ULL, 4);
    V v_t_2438 = (g_heff_2ecompile_2espec_2eselfTo(v_g_240, v_h_241, v_pre_242, v_ds_243, v_e1_2434));
    return heff_setField(v_d_245, v_i_246, heff_tag_n(TAG_EProj, 4, (V[]){v_t_2438, v_l_2435, v_sh_2436, v_t_2437}));
  }
  case TAG_ETag: {
    V v_t_2439 = heff_field(v_e_244, 0);
    V v_as_2440 = heff_field(v_e_244, 1);
    heff_take_n(v_e_244, 3ULL, 2);
    V v_t_2441 = heff_tr(heff_call(((V)&g_heff_2ecompile_2espec_2eselfTo_clo), 4, (V[]){v_g_240, v_h_241, v_pre_242, v_ds_243}));
    V v_t_2442 = (g_list_2emap(v_t_2441, v_as_2440));
    return heff_setField(v_d_245, v_i_246, heff_tag_n(TAG_ETag, 2, (V[]){v_t_2439, v_t_2442}));
  }
  case TAG_EMatch: {
    V v_s_2443 = heff_field(v_e_244, 0);
    V v_arms_2444 = heff_field(v_e_244, 1);
    heff_take_n(v_e_244, 3ULL, 2);
    V v_t_2445 = (g_heff_2ecompile_2espec_2eselfTo(heff_dup(v_g_240), heff_dup(v_h_241), heff_dup(v_pre_242), heff_dup(v_ds_243), v_s_2443));
    V v_go_2446 = heff_tr(heff_call(((V)&g_heff_2ecompile_2espec_2eselfTo_clo), 4, (V[]){v_g_240, v_h_241, v_pre_242, v_ds_243}));
    V v_t_2452 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2espec_2eselfTo_24dps_lam1, 1, 1, (V[]){v_go_2446}), v_arms_2444));
    return heff_setField(v_d_245, v_i_246, heff_tag_n(TAG_EMatch, 2, (V[]){v_t_2445, v_t_2452}));
  }
  case TAG_EPrim: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_pre_242);
    heff_drop(v_ds_243);
    return heff_setField(v_d_245, v_i_246, v_e_244);
  }
  case TAG_EPrimCall: {
    V v_p_2454 = heff_field(v_e_244, 0);
    V v_as_2455 = heff_field(v_e_244, 1);
    heff_take_n(v_e_244, 3ULL, 2);
    V v_t_2456 = heff_tr(heff_call(((V)&g_heff_2ecompile_2espec_2eselfTo_clo), 4, (V[]){v_g_240, v_h_241, v_pre_242, v_ds_243}));
    V v_t_2457 = (g_list_2emap(v_t_2456, v_as_2455));
    return heff_setField(v_d_245, v_i_246, heff_tag_n(TAG_EPrimCall, 2, (V[]){v_p_2454, v_t_2457}));
  }
  case TAG_ECall: {
    V v_k_2458 = heff_field(v_e_244, 0);
    V v_as_2459 = heff_field(v_e_244, 1);
    heff_take_n(v_e_244, 3ULL, 2);
    V v_t_2460 = heff_tr(heff_call(((V)&g_heff_2ecompile_2espec_2eselfTo_clo), 4, (V[]){v_g_240, v_h_241, v_pre_242, v_ds_243}));
    V v_t_2461 = (g_list_2emap(v_t_2460, v_as_2459));
    return heff_setField(v_d_245, v_i_246, heff_tag_n(TAG_ECall, 2, (V[]){v_k_2458, v_t_2461}));
  }
  case TAG_EInt: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_pre_242);
    heff_drop(v_ds_243);
    return heff_setField(v_d_245, v_i_246, v_e_244);
  }
  case TAG_EFloat: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_pre_242);
    heff_drop(v_ds_243);
    return heff_setField(v_d_245, v_i_246, v_e_244);
  }
  case TAG_EStr: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_pre_242);
    heff_drop(v_ds_243);
    return heff_setField(v_d_245, v_i_246, v_e_244);
  }
  case TAG_EBytes: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_pre_242);
    heff_drop(v_ds_243);
    return heff_setField(v_d_245, v_i_246, v_e_244);
  }
  case TAG_EFixed: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_pre_242);
    heff_drop(v_ds_243);
    return heff_setField(v_d_245, v_i_246, v_e_244);
  }
  case TAG_EFloat32: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_pre_242);
    heff_drop(v_ds_243);
    return heff_setField(v_d_245, v_i_246, v_e_244);
  }
  case TAG_EAbandon: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_pre_242);
    heff_drop(v_ds_243);
    return heff_setField(v_d_245, v_i_246, v_e_244);
  }
  case TAG_EFix: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_pre_242);
    heff_drop(v_ds_243);
    return heff_setField(v_d_245, v_i_246, v_e_244);
  }
  default: return heff_nomatch(v_e_244);
  }
}
V g_heff_2ecompile_2espec_2eselfTo_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2espec_2eselfTo_24dps(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
V g_heff_2ecompile_2espec_2eselfTo_24dps_lam0(V self, V *args) {
  V v_x2_2429 = args[0];
  V v_go_2428 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x2_2429)) {
  case TAG_MkPair: {
    V v_l_2430 = heff_field(v_x2_2429, 0);
    V v_v_2431 = heff_field(v_x2_2429, 1);
    V v_ru_24x2_2429_24MkPair = heff_take_reuse_n(v_x2_2429, 3ULL, 2);
    V v_t_2432 = heff_tr(heff_call(v_go_2428, 1, (V[]){v_v_2431}));
    return heff_tag_at_n(v_ru_24x2_2429_24MkPair, TAG_MkPair, 2, (V[]){v_l_2430, v_t_2432});
  }
  default: return heff_nomatch(v_x2_2429);
  }
}
V g_heff_2ecompile_2espec_2eselfTo_24dps_lam1(V self, V *args) {
  V v_x2_2447 = args[0];
  V v_go_2446 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x2_2447)) {
  case TAG_MkArm: {
    V v_t_2448 = heff_field(v_x2_2447, 0);
    V v_vs_2449 = heff_field(v_x2_2447, 1);
    V v_b_2450 = heff_field(v_x2_2447, 2);
    V v_ru_24x2_2447_24MkArm = heff_take_reuse_n(v_x2_2447, 7ULL, 3);
    V v_t_2451 = heff_tr(heff_call(v_go_2446, 1, (V[]){v_b_2450}));
    return heff_tag_at_n(v_ru_24x2_2447_24MkArm, TAG_MkArm, 3, (V[]){v_t_2448, v_vs_2449, v_t_2451});
  }
  default: return heff_nomatch(v_x2_2447);
  }
}