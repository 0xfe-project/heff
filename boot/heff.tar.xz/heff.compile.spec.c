// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EVar 52881
#define TAG_F32 16337
#define TAG_I16 19162
#define TAG_I32 19220
#define TAG_I64 19315
#define TAG_I8 9088
#define TAG_MkArm 55352
#define TAG_U16 30694
#define TAG_U32 30752
#define TAG_U64 30847
#define TAG_U8 9460
#define LBL_holes 300818381
#define LBL_n 328
#define LBL_ren 322325
#define LBL_vars 10107635
static uint32_t shape_ren__vars__holes__n[] = {LBL_ren, LBL_vars, LBL_holes, LBL_n};
V g_heff_2ecompile_2espec_2eallS(V, V);
V g_heff_2ecompile_2espec_2eallS_entry(V self, V *a);
extern Clo g_heff_2ecompile_2espec_2eallS_clo;
V g_heff_2ecompile_2espec_2eappendS(V, V);
V g_heff_2ecompile_2espec_2eappendS_entry(V self, V *a);
extern Clo g_heff_2ecompile_2espec_2eappendS_clo;
V g_heff_2ecompile_2espec_2ebindOne(V, V);
V g_heff_2ecompile_2espec_2ebindOne_entry(V self, V *a);
extern Clo g_heff_2ecompile_2espec_2ebindOne_clo;
V g_heff_2ecompile_2espec_2eclosedIn(V, V);
V g_heff_2ecompile_2espec_2eclosedIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2espec_2eclosedIn_clo;
V g_heff_2ecompile_2espec_2edropAt(V, V);
V g_heff_2ecompile_2espec_2edropAt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2espec_2edropAt_clo;
V g_heff_2ecompile_2espec_2eelemS(V, V);
V g_heff_2ecompile_2espec_2eelemS_entry(V self, V *a);
extern Clo g_heff_2ecompile_2espec_2eelemS_clo;
V g_heff_2ecompile_2espec_2ehandsOn(V, V, V);
V g_heff_2ecompile_2espec_2ehandsOn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2espec_2ehandsOn_clo;
V g_heff_2ecompile_2espec_2ehashGo(V, V, V, V);
V g_heff_2ecompile_2espec_2ehashGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2espec_2ehashGo_clo;
V g_heff_2ecompile_2espec_2eheadUses(V, V);
V g_heff_2ecompile_2espec_2eheadUses_entry(V self, V *a);
extern Clo g_heff_2ecompile_2espec_2eheadUses_clo;
V g_heff_2ecompile_2espec_2ekeyGo(V, V);
V g_heff_2ecompile_2espec_2ekeyGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2espec_2ekeyGo_clo;
V g_heff_2ecompile_2espec_2elabelsTo(V, V);
V g_heff_2ecompile_2espec_2elabelsTo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2espec_2elabelsTo_clo;
V g_heff_2ecompile_2espec_2eletThen(V, V, V, V);
V g_heff_2ecompile_2espec_2eletThen_entry(V self, V *a);
extern Clo g_heff_2ecompile_2espec_2eletThen_clo;
V g_heff_2ecompile_2espec_2enthS(V, V);
V g_heff_2ecompile_2espec_2enthS_entry(V self, V *a);
extern Clo g_heff_2ecompile_2espec_2enthS_clo;
V g_heff_2ecompile_2espec_2eposGo(V, V, V);
V g_heff_2ecompile_2espec_2eposGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2espec_2eposGo_clo;
V g_heff_2ecompile_2espec_2eselfArgs(V, V, V, V, V);
V g_heff_2ecompile_2espec_2eselfArgs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2espec_2eselfArgs_clo;
V g_heff_2ecompile_2espec_2eselfHead(V, V, V, V);
V g_heff_2ecompile_2espec_2eselfHead_entry(V self, V *a);
extern Clo g_heff_2ecompile_2espec_2eselfHead_clo;
V g_heff_2ecompile_2espec_2eselfTo(V, V, V, V, V);
V g_heff_2ecompile_2espec_2eselfTo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2espec_2eselfTo_clo;
V g_heff_2ecompile_2espec_2eshapeArms(V, V, V);
V g_heff_2ecompile_2espec_2eshapeArms_entry(V self, V *a);
extern Clo g_heff_2ecompile_2espec_2eshapeArms_clo;
V g_heff_2ecompile_2espec_2eshapeGo(V, V);
V g_heff_2ecompile_2espec_2eshapeGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2espec_2eshapeGo_clo;
V g_heff_2ecompile_2espec_2eshapeMany(V, V, V);
V g_heff_2ecompile_2espec_2eshapeMany_entry(V self, V *a);
extern Clo g_heff_2ecompile_2espec_2eshapeMany_clo;
V g_heff_2ecompile_2espec_2estaticGo(V, V, V);
V g_heff_2ecompile_2espec_2estaticGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2espec_2estaticGo_clo;
V g_heff_2ecompile_2espec_2eusesOf(V, V);
V g_heff_2ecompile_2espec_2eusesOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2espec_2eusesOf_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24s1048046132x95752937(V, V);
V g_list_2efoldl_24s1048046132x95752937_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1048046132x95752937_clo;
V g_list_2efoldl_24s1116451536x2100070357(V, V, V);
V g_list_2efoldl_24s1116451536x2100070357_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1116451536x2100070357_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1173914895x100384474(V);
V g_list_2emap_24s1173914895x100384474_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_clo;
V g_list_2emap_24s60612435x257154841(V);
V g_list_2emap_24s60612435x257154841_entry(V self, V *a);
extern Clo g_list_2emap_24s60612435x257154841_clo;
V g_map_2einsert_24s1341440536x470972936(V, V, V);
V g_map_2einsert_24s1341440536x470972936_entry(V self, V *a);
extern Clo g_map_2einsert_24s1341440536x470972936_clo;
V g_map_2elookup_24s1546226666x2146984184(V, V);
V g_map_2elookup_24s1546226666x2146984184_entry(V self, V *a);
extern Clo g_map_2elookup_24s1546226666x2146984184_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
Clo g_heff_2ecompile_2espec_2eelemS_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2espec_2eelemS_entry, 2, 0};

V g_heff_2ecompile_2espec_2eelemS(V v_x_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_x_240);
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_y_242 = heff_field(v_x2_241, 0);
    V v_ys_243 = heff_field(v_x2_241, 1);
    if (heff_strEq_c(heff_dup(v_x_240), heff_dup(v_y_242))) {
      heff_drop(v_x_240);
      return NTAG(TAG_True);
    } else {
      V t_0 = v_x_240;
      V t_1 = v_ys_243;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2espec_2eelemS_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecompile_2espec_2eelemS(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_heff_2ecompile_2espec_2eappendS_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2espec_2eappendS_entry, 2, 0};

V g_heff_2ecompile_2espec_2eappendS(V v_x1_240, V v_ys_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return v_ys_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    return heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_242, (g_heff_2ecompile_2espec_2eappendS(v_xs_243, v_ys_241))});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2espec_2eappendS_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2espec_2eappendS(a[0], a[1]);
}
Clo g_heff_2ecompile_2espec_2eallS_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2espec_2eallS_entry, 2, 0};

V g_heff_2ecompile_2espec_2eallS(V v_p_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_p_240);
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_t_244 = heff_tr(heff_apply(heff_dup(v_p_240), 1, (V[]){heff_dup(v_x_242)}));
    switch (heff_tag_of(v_t_244)) {
    case TAG_True: {
      V t_0 = v_p_240;
      V t_1 = v_xs_243;
      v_p_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_False: {
      heff_drop(v_p_240);
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2espec_2eallS_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecompile_2espec_2eallS(a[0], a[1]); heff_drop(a[1]); return r;
}
V g_heff_2ecompile_2espec_2eclosedIn_lam0(V self, V *args);
Clo g_heff_2ecompile_2espec_2eclosedIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2espec_2eclosedIn_entry, 2, 0};

V g_heff_2ecompile_2espec_2eclosedIn(V v_env_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_EVar: {
    V v_x_242 = heff_field(v_x2_241, 0);
    return ({ V a_0 = heff_dup(v_x_242); V a_1 = v_env_240; V r_ = (g_heff_2ecompile_2espec_2eelemS(a_0, a_1)); heff_drop(v_env_240); r_; });
  }
  case TAG_EGlobal: {
    heff_drop(v_env_240);
    return NTAG(TAG_True);
  }
  case TAG_ELam: {
    V v_xs_244 = heff_field(v_x2_241, 0);
    V v_b_245 = heff_field(v_x2_241, 1);
    V v_t_246 = (g_heff_2ecompile_2espec_2eappendS(heff_dup(v_xs_244), v_env_240));
    V t_0 = v_t_246;
    V t_1 = v_b_245;
    v_env_240 = t_0;
    v_x2_241 = t_1;
    goto top;
  }
  case TAG_EApp: {
    V v_f_247 = heff_field(v_x2_241, 0);
    V v_as_248 = heff_field(v_x2_241, 1);
    V v_t_249 = (g_heff_2ecompile_2espec_2eclosedIn(heff_dup(v_env_240), v_f_247));
    switch (heff_tag_of(v_t_249)) {
    case TAG_True: {
      V v_t_2410 = heff_tr(heff_apply(((V)&g_heff_2ecompile_2espec_2eclosedIn_clo), 1, (V[]){v_env_240}));
      HEFF_LAST return g_heff_2ecompile_2espec_2eallS(v_t_2410, v_as_248);
    }
    case TAG_False: {
      heff_drop(v_env_240);
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_t_249);
    }
  }
  case TAG_ELet: {
    V v_x_2411 = heff_field(v_x2_241, 0);
    V v_a_2412 = heff_field(v_x2_241, 1);
    V v_b_2413 = heff_field(v_x2_241, 2);
    V v_t_2414 = (g_heff_2ecompile_2espec_2eclosedIn(heff_dup(v_env_240), v_a_2412));
    switch (heff_tag_of(v_t_2414)) {
    case TAG_True: {
      V t_0 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_x_2411), v_env_240});
      V t_1 = v_b_2413;
      v_env_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
    case TAG_False: {
      heff_drop(v_env_240);
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_t_2414);
    }
  }
  case TAG_ERecord: {
    V v_fs_2415 = heff_field(v_x2_241, 0);
    V v_t_2416 = heff_tr(heff_apply(((V)&g_heff_2ecompile_2espec_2eclosedIn_clo), 1, (V[]){v_env_240}));
    V v_t_2417 = (g_list_2emap_24s1173914895x100384474(heff_dup(v_fs_2415)));
    return ({ V a_0 = v_t_2416; V a_1 = v_t_2417; V r_ = (g_heff_2ecompile_2espec_2eallS(a_0, a_1)); heff_drop(v_t_2417); r_; });
  }
  case TAG_EProj: {
    V v_e_2418 = heff_field(v_x2_241, 0);
    V t_0 = v_env_240;
    V t_1 = v_e_2418;
    v_env_240 = t_0;
    v_x2_241 = t_1;
    goto top;
  }
  case TAG_ETag: {
    V v_as_2422 = heff_field(v_x2_241, 1);
    V v_t_2423 = heff_tr(heff_apply(((V)&g_heff_2ecompile_2espec_2eclosedIn_clo), 1, (V[]){v_env_240}));
    HEFF_LAST return g_heff_2ecompile_2espec_2eallS(v_t_2423, v_as_2422);
  }
  case TAG_EMatch: {
    V v_s_2424 = heff_field(v_x2_241, 0);
    V v_arms_2425 = heff_field(v_x2_241, 1);
    V v_t_2426 = (g_heff_2ecompile_2espec_2eclosedIn(heff_dup(v_env_240), v_s_2424));
    switch (heff_tag_of(v_t_2426)) {
    case TAG_True: {
      HEFF_LAST return g_heff_2ecompile_2espec_2eallS(heff_clo_n(g_heff_2ecompile_2espec_2eclosedIn_lam0, 1, 1, (V[]){v_env_240}), v_arms_2425);
    }
    case TAG_False: {
      heff_drop(v_env_240);
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_t_2426);
    }
  }
  case TAG_EPrim: {
    heff_drop(v_env_240);
    return NTAG(TAG_True);
  }
  case TAG_EPrimCall: {
    V v_as_2434 = heff_field(v_x2_241, 1);
    V v_t_2435 = heff_tr(heff_apply(((V)&g_heff_2ecompile_2espec_2eclosedIn_clo), 1, (V[]){v_env_240}));
    HEFF_LAST return g_heff_2ecompile_2espec_2eallS(v_t_2435, v_as_2434);
  }
  case TAG_ECall: {
    V v_as_2437 = heff_field(v_x2_241, 1);
    V v_t_2438 = heff_tr(heff_apply(((V)&g_heff_2ecompile_2espec_2eclosedIn_clo), 1, (V[]){v_env_240}));
    HEFF_LAST return g_heff_2ecompile_2espec_2eallS(v_t_2438, v_as_2437);
  }
  case TAG_EInt: {
    heff_drop(v_env_240);
    return NTAG(TAG_True);
  }
  case TAG_EFloat: {
    heff_drop(v_env_240);
    return NTAG(TAG_True);
  }
  case TAG_EStr: {
    heff_drop(v_env_240);
    return NTAG(TAG_True);
  }
  case TAG_EFixed: {
    heff_drop(v_env_240);
    return NTAG(TAG_True);
  }
  case TAG_EFloat32: {
    heff_drop(v_env_240);
    return NTAG(TAG_True);
  }
  case TAG_EAbandon: {
    heff_drop(v_env_240);
    return NTAG(TAG_True);
  }
  case TAG_EFix: {
    heff_drop(v_env_240);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2espec_2eclosedIn_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecompile_2espec_2eclosedIn(a[0], a[1]); heff_drop(a[1]); return r;
}
V g_heff_2ecompile_2espec_2eclosedIn_lam0(V self, V *args) {
  V v_x3_2427 = args[0];
  V v_env_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x3_2427)) {
  case TAG_MkArm: {
    V v_vs_2429 = heff_field(v_x3_2427, 1);
    V v_b_2430 = heff_field(v_x3_2427, 2);
    heff_take_n(v_x3_2427, 6ULL, 3);
    V v_t_2431 = (g_heff_2ecompile_2espec_2eappendS(v_vs_2429, v_env_240));
    return ({ V a_0 = v_t_2431; V a_1 = v_b_2430; V r_ = (g_heff_2ecompile_2espec_2eclosedIn(a_0, a_1)); heff_drop(v_b_2430); r_; });
  }
  default: return heff_nomatch(v_x3_2427);
  }
}
Clo g_heff_2ecompile_2espec_2eposGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2espec_2eposGo_entry, 3, 0};

V g_heff_2ecompile_2espec_2eposGo(V v_x_240, V v_x2_241, V v_i_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_x_240);
    heff_drop(v_i_242);
    return MK_INT(-1LL);
  }
  case TAG_Cons: {
    V v_y_243 = heff_field(v_x2_241, 0);
    V v_ys_244 = heff_field(v_x2_241, 1);
    if (heff_strEq_c(heff_dup(v_x_240), heff_dup(v_y_243))) {
      heff_drop(v_x_240);
      return v_i_242;
    } else {
      V t_0 = v_x_240;
      V t_1 = v_ys_244;
      V t_2 = heff_intAdd(v_i_242, MK_INT(1LL));
      v_x_240 = t_0;
      v_x2_241 = t_1;
      v_i_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2espec_2eposGo_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecompile_2espec_2eposGo(a[0], a[1], a[2]); heff_drop(a[1]); return r;
}
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str0, 1, "v");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str1, 1, "g");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str2, 1, ";");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str3, 1, "L");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str4, 1, "(");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str5, 1, ")");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str6, 0, "");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str7, 1, ",");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str8, 2, "A(");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str9, 1, ":");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str10, 1, ")");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str11, 2, "T(");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str12, 1, ":");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str13, 1, ")");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str14, 1, "=");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str15, 0, "");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str16, 1, ",");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str17, 2, "R(");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str18, 1, ")");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str19, 0, "");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str20, 1, ",");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str21, 2, "P(");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str22, 1, ".");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str23, 1, "/");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str24, 1, ")");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str25, 0, "");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str26, 1, ",");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str27, 1, "C");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str28, 1, "(");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str29, 1, ")");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str30, 1, "|");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str31, 1, ":");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str32, 0, "");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str33, 0, "");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str34, 2, "M(");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str35, 1, ")");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str36, 1, "p");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str37, 1, ";");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str38, 0, "");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str39, 1, ",");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str40, 1, "Q");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str41, 1, "(");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str42, 1, ")");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str43, 0, "");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str44, 1, ",");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str45, 1, "K");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str46, 1, "(");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str47, 1, ")");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str48, 1, "i");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str49, 1, "f");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str50, 1, "s");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str51, 1, ":");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str52, 2, "I8");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str53, 3, "I16");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str54, 3, "I32");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str55, 3, "I64");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str56, 2, "U8");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str57, 3, "U16");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str58, 3, "U32");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str59, 3, "U64");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str60, 3, "F32");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str61, 1, "x");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str62, 1, ":");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str63, 1, "y");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str64, 1, "X");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str65, 1, "F");
V g_heff_2ecompile_2espec_2ekeyGo_lam0(V self, V *args);
V g_heff_2ecompile_2espec_2ekeyGo_lam1(V self, V *args);
Clo g_heff_2ecompile_2espec_2ekeyGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2espec_2ekeyGo_entry, 2, 0};

V g_heff_2ecompile_2espec_2ekeyGo(V v_env_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_EVar: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_t_243 = ({ V a_0 = heff_dup(v_x_242); V a_1 = v_env_240; V a_2 = MK_INT(0LL); V r_ = (g_heff_2ecompile_2espec_2eposGo(a_0, a_1, a_2)); heff_drop(v_env_240); r_; });
    return heff_strAppend(((V)&g_heff_2ecompile_2espec_2ekeyGo_str0), heff_intShow(v_t_243));
  }
  case TAG_EGlobal: {
    V v_g_244 = heff_field(v_x2_241, 0);
    heff_drop(v_env_240);
    return heff_strAppend(((V)&g_heff_2ecompile_2espec_2ekeyGo_str1), heff_strAppend(heff_dup(v_g_244), ((V)&g_heff_2ecompile_2espec_2ekeyGo_str2)));
  }
  case TAG_ELam: {
    V v_xs_245 = heff_field(v_x2_241, 0);
    V v_b_246 = heff_field(v_x2_241, 1);
    V v_t_247 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_xs_245));
    V v_t_248 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_xs_245)));
    V v_t_249 = (g_heff_2ecompile_2espec_2eappendS(v_t_248, v_env_240));
    V v_t_2410 = (g_heff_2ecompile_2espec_2ekeyGo(v_t_249, v_b_246));
    return heff_strAppend(((V)&g_heff_2ecompile_2espec_2ekeyGo_str3), heff_strAppend(heff_intShow(v_t_247), heff_strAppend(((V)&g_heff_2ecompile_2espec_2ekeyGo_str4), heff_strAppend(v_t_2410, ((V)&g_heff_2ecompile_2espec_2ekeyGo_str5)))));
  }
  case TAG_EApp: {
    V v_f_2411 = heff_field(v_x2_241, 0);
    V v_as_2412 = heff_field(v_x2_241, 1);
    V v_t_2413 = (g_heff_2ecompile_2espec_2ekeyGo(heff_dup(v_env_240), v_f_2411));
    V v_go_2414 = heff_tr(heff_apply(((V)&g_heff_2ecompile_2espec_2ekeyGo_clo), 1, (V[]){v_env_240}));
    V v_x2_2415 = (g_list_2emap(v_go_2414, heff_dup(v_as_2412)));
    V v_t_2418;
    switch (heff_tag_of(v_x2_2415)) {
    case TAG_Nil: {
      v_t_2418 = ((V)&g_heff_2ecompile_2espec_2ekeyGo_str6);
      break;
    }
    case TAG_Cons: {
      V v_x_2416 = heff_field(v_x2_2415, 0);
      V v_xs_2417 = heff_field(v_x2_2415, 1);
      heff_take_n(v_x2_2415, 3ULL, 2);
      v_t_2418 = ({ V a_0 = ((V)&g_heff_2ecompile_2espec_2ekeyGo_str7); V a_1 = v_x_2416; V a_2 = v_xs_2417; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2417); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2415);
    }
    return heff_strAppend(((V)&g_heff_2ecompile_2espec_2ekeyGo_str8), heff_strAppend(v_t_2413, heff_strAppend(((V)&g_heff_2ecompile_2espec_2ekeyGo_str9), heff_strAppend(v_t_2418, ((V)&g_heff_2ecompile_2espec_2ekeyGo_str10)))));
  }
  case TAG_ELet: {
    V v_x_2419 = heff_field(v_x2_241, 0);
    V v_a_2420 = heff_field(v_x2_241, 1);
    V v_b_2421 = heff_field(v_x2_241, 2);
    V v_t_2422 = (g_heff_2ecompile_2espec_2ekeyGo(heff_dup(v_env_240), v_a_2420));
    V v_t_2423 = (g_heff_2ecompile_2espec_2ekeyGo(heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_x_2419), v_env_240}), v_b_2421));
    return heff_strAppend(((V)&g_heff_2ecompile_2espec_2ekeyGo_str11), heff_strAppend(v_t_2422, heff_strAppend(((V)&g_heff_2ecompile_2espec_2ekeyGo_str12), heff_strAppend(v_t_2423, ((V)&g_heff_2ecompile_2espec_2ekeyGo_str13)))));
  }
  case TAG_ERecord: {
    V v_fs_2424 = heff_field(v_x2_241, 0);
    V v_go_2425 = heff_tr(heff_apply(((V)&g_heff_2ecompile_2espec_2ekeyGo_clo), 1, (V[]){v_env_240}));
    V v_x2_2430 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2espec_2ekeyGo_lam0, 1, 1, (V[]){v_go_2425}), heff_dup(v_fs_2424)));
    V v_t_2433;
    switch (heff_tag_of(v_x2_2430)) {
    case TAG_Nil: {
      v_t_2433 = ((V)&g_heff_2ecompile_2espec_2ekeyGo_str15);
      break;
    }
    case TAG_Cons: {
      V v_x_2431 = heff_field(v_x2_2430, 0);
      V v_xs_2432 = heff_field(v_x2_2430, 1);
      heff_take_n(v_x2_2430, 3ULL, 2);
      v_t_2433 = ({ V a_0 = ((V)&g_heff_2ecompile_2espec_2ekeyGo_str16); V a_1 = v_x_2431; V a_2 = v_xs_2432; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2432); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2430);
    }
    return heff_strAppend(((V)&g_heff_2ecompile_2espec_2ekeyGo_str17), heff_strAppend(v_t_2433, ((V)&g_heff_2ecompile_2espec_2ekeyGo_str18)));
  }
  case TAG_EProj: {
    V v_e_2434 = heff_field(v_x2_241, 0);
    V v_l_2435 = heff_field(v_x2_241, 1);
    V v_sh_2436 = heff_field(v_x2_241, 2);
    V v_t_2437 = (g_heff_2ecompile_2espec_2ekeyGo(v_env_240, v_e_2434));
    V v_t_2440;
    switch (heff_tag_of(v_sh_2436)) {
    case TAG_Nil: {
      v_t_2440 = ((V)&g_heff_2ecompile_2espec_2ekeyGo_str19);
      break;
    }
    case TAG_Cons: {
      V v_x_2438 = heff_field(v_sh_2436, 0);
      V v_xs_2439 = heff_field(v_sh_2436, 1);
      v_t_2440 = (g_prelude_2ejoinWith_2eafter_240(((V)&g_heff_2ecompile_2espec_2ekeyGo_str20), heff_dup(v_x_2438), v_xs_2439));
      break;
    }
    default: heff_nomatch(v_sh_2436);
    }
    return heff_strAppend(((V)&g_heff_2ecompile_2espec_2ekeyGo_str21), heff_strAppend(v_t_2437, heff_strAppend(((V)&g_heff_2ecompile_2espec_2ekeyGo_str22), heff_strAppend(heff_dup(v_l_2435), heff_strAppend(((V)&g_heff_2ecompile_2espec_2ekeyGo_str23), heff_strAppend(v_t_2440, ((V)&g_heff_2ecompile_2espec_2ekeyGo_str24)))))));
  }
  case TAG_ETag: {
    V v_t_2441 = heff_field(v_x2_241, 0);
    V v_as_2442 = heff_field(v_x2_241, 1);
    V v_go_2443 = heff_tr(heff_apply(((V)&g_heff_2ecompile_2espec_2ekeyGo_clo), 1, (V[]){v_env_240}));
    V v_x2_2444 = (g_list_2emap(v_go_2443, heff_dup(v_as_2442)));
    V v_t_2447;
    switch (heff_tag_of(v_x2_2444)) {
    case TAG_Nil: {
      v_t_2447 = ((V)&g_heff_2ecompile_2espec_2ekeyGo_str25);
      break;
    }
    case TAG_Cons: {
      V v_x_2445 = heff_field(v_x2_2444, 0);
      V v_xs_2446 = heff_field(v_x2_2444, 1);
      heff_take_n(v_x2_2444, 3ULL, 2);
      v_t_2447 = ({ V a_0 = ((V)&g_heff_2ecompile_2espec_2ekeyGo_str26); V a_1 = v_x_2445; V a_2 = v_xs_2446; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2446); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2444);
    }
    return heff_strAppend(((V)&g_heff_2ecompile_2espec_2ekeyGo_str27), heff_strAppend(heff_dup(v_t_2441), heff_strAppend(((V)&g_heff_2ecompile_2espec_2ekeyGo_str28), heff_strAppend(v_t_2447, ((V)&g_heff_2ecompile_2espec_2ekeyGo_str29)))));
  }
  case TAG_EMatch: {
    V v_s_2448 = heff_field(v_x2_241, 0);
    V v_arms_2449 = heff_field(v_x2_241, 1);
    V v_t_2450 = (g_heff_2ecompile_2espec_2ekeyGo(heff_dup(v_env_240), v_s_2448));
    V v_x2_2458 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2espec_2ekeyGo_lam1, 1, 1, (V[]){v_env_240}), heff_dup(v_arms_2449)));
    V v_t_2461;
    switch (heff_tag_of(v_x2_2458)) {
    case TAG_Nil: {
      v_t_2461 = ((V)&g_heff_2ecompile_2espec_2ekeyGo_str32);
      break;
    }
    case TAG_Cons: {
      V v_x_2459 = heff_field(v_x2_2458, 0);
      V v_xs_2460 = heff_field(v_x2_2458, 1);
      heff_take_n(v_x2_2458, 3ULL, 2);
      v_t_2461 = ({ V a_0 = ((V)&g_heff_2ecompile_2espec_2ekeyGo_str33); V a_1 = v_x_2459; V a_2 = v_xs_2460; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2460); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2458);
    }
    return heff_strAppend(((V)&g_heff_2ecompile_2espec_2ekeyGo_str34), heff_strAppend(v_t_2450, heff_strAppend(v_t_2461, ((V)&g_heff_2ecompile_2espec_2ekeyGo_str35))));
  }
  case TAG_EPrim: {
    V v_p_2462 = heff_field(v_x2_241, 0);
    heff_drop(v_env_240);
    return heff_strAppend(((V)&g_heff_2ecompile_2espec_2ekeyGo_str36), heff_strAppend(heff_dup(v_p_2462), ((V)&g_heff_2ecompile_2espec_2ekeyGo_str37)));
  }
  case TAG_EPrimCall: {
    V v_p_2463 = heff_field(v_x2_241, 0);
    V v_as_2464 = heff_field(v_x2_241, 1);
    V v_go_2465 = heff_tr(heff_apply(((V)&g_heff_2ecompile_2espec_2ekeyGo_clo), 1, (V[]){v_env_240}));
    V v_x2_2466 = (g_list_2emap(v_go_2465, heff_dup(v_as_2464)));
    V v_t_2469;
    switch (heff_tag_of(v_x2_2466)) {
    case TAG_Nil: {
      v_t_2469 = ((V)&g_heff_2ecompile_2espec_2ekeyGo_str38);
      break;
    }
    case TAG_Cons: {
      V v_x_2467 = heff_field(v_x2_2466, 0);
      V v_xs_2468 = heff_field(v_x2_2466, 1);
      heff_take_n(v_x2_2466, 3ULL, 2);
      v_t_2469 = ({ V a_0 = ((V)&g_heff_2ecompile_2espec_2ekeyGo_str39); V a_1 = v_x_2467; V a_2 = v_xs_2468; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2468); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2466);
    }
    return heff_strAppend(((V)&g_heff_2ecompile_2espec_2ekeyGo_str40), heff_strAppend(heff_dup(v_p_2463), heff_strAppend(((V)&g_heff_2ecompile_2espec_2ekeyGo_str41), heff_strAppend(v_t_2469, ((V)&g_heff_2ecompile_2espec_2ekeyGo_str42)))));
  }
  case TAG_ECall: {
    V v_g_2470 = heff_field(v_x2_241, 0);
    V v_as_2471 = heff_field(v_x2_241, 1);
    V v_go_2472 = heff_tr(heff_apply(((V)&g_heff_2ecompile_2espec_2ekeyGo_clo), 1, (V[]){v_env_240}));
    V v_x2_2473 = (g_list_2emap(v_go_2472, heff_dup(v_as_2471)));
    V v_t_2476;
    switch (heff_tag_of(v_x2_2473)) {
    case TAG_Nil: {
      v_t_2476 = ((V)&g_heff_2ecompile_2espec_2ekeyGo_str43);
      break;
    }
    case TAG_Cons: {
      V v_x_2474 = heff_field(v_x2_2473, 0);
      V v_xs_2475 = heff_field(v_x2_2473, 1);
      heff_take_n(v_x2_2473, 3ULL, 2);
      v_t_2476 = ({ V a_0 = ((V)&g_heff_2ecompile_2espec_2ekeyGo_str44); V a_1 = v_x_2474; V a_2 = v_xs_2475; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2475); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2473);
    }
    return heff_strAppend(((V)&g_heff_2ecompile_2espec_2ekeyGo_str45), heff_strAppend(heff_dup(v_g_2470), heff_strAppend(((V)&g_heff_2ecompile_2espec_2ekeyGo_str46), heff_strAppend(v_t_2476, ((V)&g_heff_2ecompile_2espec_2ekeyGo_str47)))));
  }
  case TAG_EInt: {
    V v_i_2477 = heff_field(v_x2_241, 0);
    heff_drop(v_env_240);
    return heff_strAppend(((V)&g_heff_2ecompile_2espec_2ekeyGo_str48), heff_intShow(heff_dup(v_i_2477)));
  }
  case TAG_EFloat: {
    V v_x_2478 = heff_field(v_x2_241, 0);
    heff_drop(v_env_240);
    return heff_strAppend(((V)&g_heff_2ecompile_2espec_2ekeyGo_str49), heff_floatShow(heff_dup(v_x_2478)));
  }
  case TAG_EStr: {
    V v_s_2479 = heff_field(v_x2_241, 0);
    heff_drop(v_env_240);
    V v_t_2480 = heff_intShow(heff_strLength(heff_dup(v_s_2479)));
    return heff_strAppend(((V)&g_heff_2ecompile_2espec_2ekeyGo_str50), heff_strAppend(v_t_2480, heff_strAppend(((V)&g_heff_2ecompile_2espec_2ekeyGo_str51), heff_dup(v_s_2479))));
  }
  case TAG_EFixed: {
    V v_w_2481 = heff_field(v_x2_241, 0);
    V v_n_2482 = heff_field(v_x2_241, 1);
    heff_drop(v_env_240);
    V v_t_2483;
    switch (heff_tag_of(v_w_2481)) {
    case TAG_I8: {
      v_t_2483 = ((V)&g_heff_2ecompile_2espec_2ekeyGo_str52);
      break;
    }
    case TAG_I16: {
      v_t_2483 = ((V)&g_heff_2ecompile_2espec_2ekeyGo_str53);
      break;
    }
    case TAG_I32: {
      v_t_2483 = ((V)&g_heff_2ecompile_2espec_2ekeyGo_str54);
      break;
    }
    case TAG_I64: {
      v_t_2483 = ((V)&g_heff_2ecompile_2espec_2ekeyGo_str55);
      break;
    }
    case TAG_U8: {
      v_t_2483 = ((V)&g_heff_2ecompile_2espec_2ekeyGo_str56);
      break;
    }
    case TAG_U16: {
      v_t_2483 = ((V)&g_heff_2ecompile_2espec_2ekeyGo_str57);
      break;
    }
    case TAG_U32: {
      v_t_2483 = ((V)&g_heff_2ecompile_2espec_2ekeyGo_str58);
      break;
    }
    case TAG_U64: {
      v_t_2483 = ((V)&g_heff_2ecompile_2espec_2ekeyGo_str59);
      break;
    }
    case TAG_F32: {
      v_t_2483 = ((V)&g_heff_2ecompile_2espec_2ekeyGo_str60);
      break;
    }
    default: heff_nomatch(v_w_2481);
    }
    return heff_strAppend(((V)&g_heff_2ecompile_2espec_2ekeyGo_str61), heff_strAppend(v_t_2483, heff_strAppend(((V)&g_heff_2ecompile_2espec_2ekeyGo_str62), heff_intShow(heff_dup(v_n_2482)))));
  }
  case TAG_EFloat32: {
    V v_x_2484 = heff_field(v_x2_241, 0);
    heff_drop(v_env_240);
    return heff_strAppend(((V)&g_heff_2ecompile_2espec_2ekeyGo_str63), heff_floatShow(heff_dup(v_x_2484)));
  }
  case TAG_EAbandon: {
    heff_drop(v_env_240);
    return ((V)&g_heff_2ecompile_2espec_2ekeyGo_str64);
  }
  case TAG_EFix: {
    heff_drop(v_env_240);
    return ((V)&g_heff_2ecompile_2espec_2ekeyGo_str65);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2espec_2ekeyGo_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecompile_2espec_2ekeyGo(a[0], a[1]); heff_drop(a[1]); return r;
}
V g_heff_2ecompile_2espec_2ekeyGo_lam0(V self, V *args) {
  V v_x2_2426 = args[0];
  V v_go_2425 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x2_2426)) {
  case TAG_MkPair: {
    V v_l_2427 = heff_field(v_x2_2426, 0);
    V v_v_2428 = heff_field(v_x2_2426, 1);
    heff_take_n(v_x2_2426, 3ULL, 2);
    V v_t_2429 = heff_tr(heff_apply(v_go_2425, 1, (V[]){v_v_2428}));
    return heff_strAppend(v_l_2427, heff_strAppend(((V)&g_heff_2ecompile_2espec_2ekeyGo_str14), v_t_2429));
  }
  default: return heff_nomatch(v_x2_2426);
  }
}
V g_heff_2ecompile_2espec_2ekeyGo_lam1(V self, V *args) {
  V v_x3_2451 = args[0];
  V v_env_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x3_2451)) {
  case TAG_MkArm: {
    V v_t_2452 = heff_field(v_x3_2451, 0);
    V v_vs_2453 = heff_field(v_x3_2451, 1);
    V v_b_2454 = heff_field(v_x3_2451, 2);
    heff_take_n(v_x3_2451, 7ULL, 3);
    V v_t_2455 = (g_list_2efoldl_24s1116451536x2100070357(MK_INT(1LL), MK_INT(0LL), v_vs_2453));
    V v_t_2456 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_vs_2453));
    V v_t_2457 = (g_heff_2ecompile_2espec_2eappendS(v_t_2456, v_env_240));
    return heff_strAppend(((V)&g_heff_2ecompile_2espec_2ekeyGo_str30), heff_strAppend(v_t_2452, heff_strAppend(heff_intShow(v_t_2455), heff_strAppend(((V)&g_heff_2ecompile_2espec_2ekeyGo_str31), ({ V a_0 = v_t_2457; V a_1 = v_b_2454; V r_ = (g_heff_2ecompile_2espec_2ekeyGo(a_0, a_1)); heff_drop(v_b_2454); r_; })))));
  }
  default: return heff_nomatch(v_x3_2451);
  }
}
HEFF_LIT(g_heff_2ecompile_2espec_2ehashGo_str0, 1, "x");
Clo g_heff_2ecompile_2espec_2ehashGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2espec_2ehashGo_entry, 4, 0};

V g_heff_2ecompile_2espec_2ehashGo(V v_s_240, V v_i_241, V v_a_242, V v_b_243) {
top: ;
  if (heff_intLe_c(heff_strLength(heff_dup(v_s_240)), heff_dup(v_i_241))) {
    heff_drop(v_s_240);
    heff_drop(v_i_241);
    return heff_strAppend(heff_intShow(v_a_242), heff_strAppend(((V)&g_heff_2ecompile_2espec_2ehashGo_str0), heff_intShow(v_b_243)));
  } else {
    V v_t_245 = heff_intAdd(heff_intMul(v_a_242, MK_INT(1000003LL)), heff_strByteAt(heff_dup(v_s_240), heff_dup(v_i_241)));
    V v_t_246 = heff_intMod(heff_intAdd(v_t_245, MK_INT(1LL)), MK_INT(2147483647LL));
    V v_t_247 = heff_intAdd(heff_intMul(v_b_243, MK_INT(999983LL)), heff_strByteAt(heff_dup(v_s_240), heff_dup(v_i_241)));
    V v_t_248 = heff_intMod(heff_intAdd(v_t_247, MK_INT(1LL)), MK_INT(2147483629LL));
    V t_0 = v_s_240;
    V t_1 = heff_intAdd(v_i_241, MK_INT(1LL));
    V t_2 = v_t_246;
    V t_3 = v_t_248;
    v_s_240 = t_0;
    v_i_241 = t_1;
    v_a_242 = t_2;
    v_b_243 = t_3;
    goto top;
  }
}
V g_heff_2ecompile_2espec_2ehashGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2espec_2ehashGo(a[0], a[1], a[2], a[3]);
}
HEFF_LIT(g_heff_2ecompile_2espec_2ebindOne_str0, 2, "a$");
HEFF_LIT(g_heff_2ecompile_2espec_2ebindOne_str1, 2, "a$");
Clo g_heff_2ecompile_2espec_2ebindOne_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2espec_2ebindOne_entry, 2, 0};

V g_heff_2ecompile_2espec_2ebindOne(V v_x1_240, V v_x_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_MkPair: {
    V v_xs_242 = heff_field(v_x1_240, 0);
    V v_st_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24MkPair = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_244 = heff_intShow(heff_dup(heff_rfield(v_st_243, 3)));
    V v_t_245 = heff_tag_at_n(v_ru_24x1_240_24MkPair, TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2espec_2ebindOne_str0), v_t_244), v_xs_242});
    V v_t_246 = heff_intShow(heff_dup(heff_rfield(v_st_243, 3)));
    V v_t_247 = (g_map_2einsert_24s1341440536x470972936(v_x_241, heff_strAppend(((V)&g_heff_2ecompile_2espec_2ebindOne_str1), v_t_246), heff_take_field(v_st_243, 0)));
    V v_t_248 = heff_intAdd(heff_take_field(v_st_243, 3), MK_INT(1LL));
    V v_t_249 = ({ V rv_0 = v_t_247; V rv_3 = v_t_248; V rr_ = heff_rec_reuse_n(v_st_243, 6ULL, 4, shape_ren__vars__holes__n); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 3) = rv_3; rr_; });
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_245, v_t_249});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2espec_2ebindOne_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2espec_2ebindOne(a[0], a[1]);
}
Clo g_heff_2ecompile_2espec_2eshapeMany_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2espec_2eshapeMany_entry, 3, 0};

V g_heff_2ecompile_2espec_2eshapeMany(V v_go_240, V v_x2_241, V v_st_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_go_240);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_st_242});
  }
  case TAG_Cons: {
    V v_e_243 = heff_field(v_x2_241, 0);
    V v_rest_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_more_245 = heff_tr(heff_apply(((V)&g_heff_2ecompile_2espec_2eshapeMany_clo), 2, (V[]){heff_dup(v_go_240), v_rest_244}));
    V v_x2_246 = heff_tr(heff_apply(v_go_240, 2, (V[]){v_e_243, v_st_242}));
    switch (heff_tag_of(v_x2_246)) {
    case TAG_MkPair: {
      V v_e_247 = heff_field(v_x2_246, 0);
      V v_st_248 = heff_field(v_x2_246, 1);
      heff_take_n(v_x2_246, 3ULL, 2);
      V v_x2_249 = heff_tr(heff_apply(v_more_245, 1, (V[]){v_st_248}));
      switch (heff_tag_of(v_x2_249)) {
      case TAG_MkPair: {
        V v_es_2410 = heff_field(v_x2_249, 0);
        V v_st_2411 = heff_field(v_x2_249, 1);
        heff_take_n(v_x2_249, 3ULL, 2);
        return heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_e_247, v_es_2410}), v_st_2411});
      }
      default: return heff_nomatch(v_x2_249);
      }
    }
    default: return heff_nomatch(v_x2_246);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2espec_2eshapeMany_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2espec_2eshapeMany(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2espec_2eletThen_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2espec_2eletThen_entry, 4, 0};

V g_heff_2ecompile_2espec_2eletThen(V v_go_240, V v_x_241, V v_b_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_MkPair: {
    V v_a_244 = heff_field(v_x4_243, 0);
    V v_st_245 = heff_field(v_x4_243, 1);
    V v_ru_24x4_243_24MkPair = heff_take_reuse_n(v_x4_243, 3ULL, 2);
    V v_t_246 = heff_tag_at_n(v_ru_24x4_243_24MkPair, TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_st_245});
    V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_x_241), NTAG(TAG_Nil)});
    V v_t_248 = ({ V a_0 = v_t_246; V a_1 = v_t_247; V r_ = (g_list_2efoldl_24s1048046132x95752937(a_0, a_1)); heff_drop_tag(v_t_247, 2); r_; });
    V v_x4_2412;
    switch (heff_tag_of(v_t_248)) {
    case TAG_MkPair: {
      V v_ys_249 = heff_field(v_t_248, 0);
      V v_st2_2410 = heff_field(v_t_248, 1);
      V v_ru_24t_248_24MkPair = heff_take_reuse_n(v_t_248, 3ULL, 2);
      V v_t_2411 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ys_249));
      v_x4_2412 = heff_tag_at_n(v_ru_24t_248_24MkPair, TAG_MkPair, 2, (V[]){v_t_2411, v_st2_2410});
      break;
    }
    default: heff_nomatch(v_t_248);
    }
    switch (heff_tag_of(v_x4_2412)) {
    case TAG_MkPair: {
      V v_ys_2413 = heff_field(v_x4_2412, 0);
      V v_st_2414 = heff_field(v_x4_2412, 1);
      V v_ru_24x4_2412_24MkPair = heff_take_reuse_n(v_x4_2412, 3ULL, 2);
      V v_x2_2415 = heff_tr(heff_apply(v_go_240, 2, (V[]){v_b_242, v_st_2414}));
      switch (heff_tag_of(v_x2_2415)) {
      case TAG_MkPair: {
        V v_e_2416 = heff_field(v_x2_2415, 0);
        V v_st_2417 = heff_field(v_x2_2415, 1);
        heff_take_n(v_x2_2415, 3ULL, 2);
        V v_t_2420;
        switch (heff_tag_of(v_ys_2413)) {
        case TAG_Nil: {
          v_t_2420 = v_x_241;
          break;
        }
        case TAG_Cons: {
          V v_y_2418 = heff_field(v_ys_2413, 0);
          heff_take_n(v_ys_2413, 1ULL, 2);
          heff_drop(v_x_241);
          v_t_2420 = v_y_2418;
          break;
        }
        default: heff_nomatch(v_ys_2413);
        }
        return heff_tag_at_n(v_ru_24x4_2412_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELet, 3, (V[]){v_t_2420, v_a_244, v_e_2416}), v_st_2417});
      }
      default: return heff_nomatch(v_x2_2415);
      }
    }
    default: return heff_nomatch(v_x4_2412);
    }
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2ecompile_2espec_2eletThen_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2espec_2eletThen(a[0], a[1], a[2], a[3]);
}
Clo g_heff_2ecompile_2espec_2elabelsTo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2espec_2elabelsTo_entry, 2, 0};

V g_heff_2ecompile_2espec_2elabelsTo(V v_x1_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_x2_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x11_242 = heff_field(v_x1_240, 0);
    V v_fs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_MkPair: {
      V v_l_244 = heff_field(v_x11_242, 0);
      heff_take_n(v_x11_242, 1ULL, 2);
      switch (heff_tag_of(v_x2_241)) {
      case TAG_Nil: {
        heff_drop(v_fs_243);
        heff_drop_cell(v_ru_24x1_240_24Cons, 2);
        heff_drop(v_l_244);
        return NTAG(TAG_Nil);
      }
      case TAG_Cons: {
        V v_e_246 = heff_field(v_x2_241, 0);
        V v_es_247 = heff_field(v_x2_241, 1);
        heff_take_n(v_x2_241, 3ULL, 2);
        return heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_l_244, v_e_246}), (g_heff_2ecompile_2espec_2elabelsTo(v_fs_243, v_es_247))});
      }
      default: return heff_nomatch(v_x2_241);
      }
    }
    default: return heff_nomatch(v_x11_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2espec_2elabelsTo_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2espec_2elabelsTo(a[0], a[1]);
}
Clo g_heff_2ecompile_2espec_2eshapeArms_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2espec_2eshapeArms_entry, 3, 0};

V g_heff_2ecompile_2espec_2eshapeArms(V v_go_240, V v_x2_241, V v_st_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_go_240);
    return heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_st_242});
  }
  case TAG_Cons: {
    V v_x21_243 = heff_field(v_x2_241, 0);
    V v_rest_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_243)) {
    case TAG_MkArm: {
      V v_t_245 = heff_field(v_x21_243, 0);
      V v_vs_246 = heff_field(v_x21_243, 1);
      V v_b_247 = heff_field(v_x21_243, 2);
      V v_ru_24x21_243_24MkArm = heff_take_reuse_n(v_x21_243, 7ULL, 3);
      V v_more_248 = heff_tr(heff_apply(((V)&g_heff_2ecompile_2espec_2eshapeArms_clo), 2, (V[]){heff_dup(v_go_240), v_rest_244}));
      V v_t_249 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_st_242});
      V v_t_2410 = ({ V a_0 = v_t_249; V a_1 = v_vs_246; V r_ = (g_list_2efoldl_24s1048046132x95752937(a_0, a_1)); heff_drop(v_vs_246); r_; });
      V v_x3_2414;
      switch (heff_tag_of(v_t_2410)) {
      case TAG_MkPair: {
        V v_ys_2411 = heff_field(v_t_2410, 0);
        V v_st2_2412 = heff_field(v_t_2410, 1);
        V v_ru_24t_2410_24MkPair = heff_take_reuse_n(v_t_2410, 3ULL, 2);
        V v_t_2413 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ys_2411));
        v_x3_2414 = heff_tag_at_n(v_ru_24t_2410_24MkPair, TAG_MkPair, 2, (V[]){v_t_2413, v_st2_2412});
        break;
      }
      default: heff_nomatch(v_t_2410);
      }
      V v_x3_2418;
      switch (heff_tag_of(v_x3_2414)) {
      case TAG_MkPair: {
        V v_vs_2415 = heff_field(v_x3_2414, 0);
        V v_st_2416 = heff_field(v_x3_2414, 1);
        V v_ru_24x3_2414_24MkPair = heff_take_reuse_n(v_x3_2414, 3ULL, 2);
        V v_t_2417 = heff_tr(heff_apply(v_go_240, 2, (V[]){v_b_247, v_st_2416}));
        v_x3_2418 = heff_tag_at_n(v_ru_24x3_2414_24MkPair, TAG_MkPair, 2, (V[]){v_vs_2415, v_t_2417});
        break;
      }
      default: heff_nomatch(v_x3_2414);
      }
      switch (heff_tag_of(v_x3_2418)) {
      case TAG_MkPair: {
        V v_vs_2419 = heff_field(v_x3_2418, 0);
        V v_x32_2420 = heff_field(v_x3_2418, 1);
        V v_ru_24x3_2418_24MkPair = heff_take_reuse_n(v_x3_2418, 3ULL, 2);
        switch (heff_tag_of(v_x32_2420)) {
        case TAG_MkPair: {
          V v_b_2421 = heff_field(v_x32_2420, 0);
          V v_st_2422 = heff_field(v_x32_2420, 1);
          V v_ru_24x32_2420_24MkPair = heff_take_reuse_n(v_x32_2420, 3ULL, 2);
          V v_x2_2423 = heff_tr(heff_apply(v_more_248, 1, (V[]){v_st_2422}));
          switch (heff_tag_of(v_x2_2423)) {
          case TAG_MkPair: {
            V v_as_2424 = heff_field(v_x2_2423, 0);
            V v_st_2425 = heff_field(v_x2_2423, 1);
            heff_take_n(v_x2_2423, 3ULL, 2);
            V v_t_2426 = heff_tag_at_n(v_ru_24x3_2418_24MkPair, TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x21_243_24MkArm, TAG_MkArm, 3, (V[]){v_t_245, v_vs_2419, v_b_2421}), v_as_2424});
            return heff_tag_at_n(v_ru_24x32_2420_24MkPair, TAG_MkPair, 2, (V[]){v_t_2426, v_st_2425});
          }
          default: return heff_nomatch(v_x2_2423);
          }
        }
        default: return heff_nomatch(v_x32_2420);
        }
      }
      default: return heff_nomatch(v_x3_2418);
      }
    }
    default: return heff_nomatch(v_x21_243);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2espec_2eshapeArms_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2espec_2eshapeArms(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ecompile_2espec_2eshapeGo_str0, 4, "lit$");
HEFF_LIT(g_heff_2ecompile_2espec_2eshapeGo_str1, 4, "lit$");
HEFF_LIT(g_heff_2ecompile_2espec_2eshapeGo_str2, 4, "lit$");
HEFF_LIT(g_heff_2ecompile_2espec_2eshapeGo_str3, 4, "lit$");
HEFF_LIT(g_heff_2ecompile_2espec_2eshapeGo_str4, 4, "lit$");
HEFF_LIT(g_heff_2ecompile_2espec_2eshapeGo_str5, 4, "lit$");
Clo g_heff_2ecompile_2espec_2eshapeGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2espec_2eshapeGo_entry, 2, 0};

V g_heff_2ecompile_2espec_2eshapeGo(V v_e_240, V v_st_241) {
top: ;
  switch (heff_tag_of(v_e_240)) {
  case TAG_EVar: {
    V v_x_242 = heff_field(v_e_240, 0);
    V v_ru_24e_240_24EVar = heff_take_reuse_n(v_e_240, 1ULL, 1);
    V v_x2_243 = (g_map_2elookup_24s1546226666x2146984184(heff_dup(v_x_242), heff_rfield(v_st_241, 0)));
    V v_t_245;
    switch (heff_tag_of(v_x2_243)) {
    case TAG_Nothing: {
      v_t_245 = v_x_242;
      break;
    }
    case TAG_Just: {
      V v_x_244 = heff_field(v_x2_243, 0);
      heff_take_n(v_x2_243, 1ULL, 1);
      heff_drop(v_x_242);
      v_t_245 = v_x_244;
      break;
    }
    default: heff_nomatch(v_x2_243);
    }
    return heff_tag_n(TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24e_240_24EVar, TAG_EVar, 1, (V[]){v_t_245}), v_st_241});
  }
  case TAG_EGlobal: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_240, v_st_241});
  }
  case TAG_ELam: {
    V v_xs_247 = heff_field(v_e_240, 0);
    V v_b_248 = heff_field(v_e_240, 1);
    V v_ru_24e_240_24ELam = heff_take_reuse_n(v_e_240, 3ULL, 2);
    V v_t_249 = heff_tag_at_n(v_ru_24e_240_24ELam, TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_st_241});
    V v_t_2410 = ({ V a_0 = v_t_249; V a_1 = v_xs_247; V r_ = (g_list_2efoldl_24s1048046132x95752937(a_0, a_1)); heff_drop(v_xs_247); r_; });
    V v_x4_2414;
    switch (heff_tag_of(v_t_2410)) {
    case TAG_MkPair: {
      V v_ys_2411 = heff_field(v_t_2410, 0);
      V v_st2_2412 = heff_field(v_t_2410, 1);
      V v_ru_24t_2410_24MkPair = heff_take_reuse_n(v_t_2410, 3ULL, 2);
      V v_t_2413 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ys_2411));
      v_x4_2414 = heff_tag_at_n(v_ru_24t_2410_24MkPair, TAG_MkPair, 2, (V[]){v_t_2413, v_st2_2412});
      break;
    }
    default: heff_nomatch(v_t_2410);
    }
    switch (heff_tag_of(v_x4_2414)) {
    case TAG_MkPair: {
      V v_ys_2415 = heff_field(v_x4_2414, 0);
      V v_st_2416 = heff_field(v_x4_2414, 1);
      V v_ru_24x4_2414_24MkPair = heff_take_reuse_n(v_x4_2414, 3ULL, 2);
      V v_x2_2417 = (g_heff_2ecompile_2espec_2eshapeGo(v_b_248, v_st_2416));
      switch (heff_tag_of(v_x2_2417)) {
      case TAG_MkPair: {
        V v_e_2418 = heff_field(v_x2_2417, 0);
        V v_st_2419 = heff_field(v_x2_2417, 1);
        heff_take_n(v_x2_2417, 3ULL, 2);
        return heff_tag_at_n(v_ru_24x4_2414_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ELam, 2, (V[]){v_ys_2415, v_e_2418}), v_st_2419});
      }
      default: return heff_nomatch(v_x2_2417);
      }
    }
    default: return heff_nomatch(v_x4_2414);
    }
  }
  case TAG_EApp: {
    V v_f_2420 = heff_field(v_e_240, 0);
    V v_as_2421 = heff_field(v_e_240, 1);
    V v_ru_24e_240_24EApp = heff_take_reuse_n(v_e_240, 3ULL, 2);
    V v_x3_2422 = (g_heff_2ecompile_2espec_2eshapeGo(v_f_2420, v_st_241));
    switch (heff_tag_of(v_x3_2422)) {
    case TAG_MkPair: {
      V v_f_2423 = heff_field(v_x3_2422, 0);
      V v_st_2424 = heff_field(v_x3_2422, 1);
      heff_take_n(v_x3_2422, 3ULL, 2);
      V v_x2_2425 = (g_heff_2ecompile_2espec_2eshapeMany(((V)&g_heff_2ecompile_2espec_2eshapeGo_clo), v_as_2421, v_st_2424));
      switch (heff_tag_of(v_x2_2425)) {
      case TAG_MkPair: {
        V v_es_2426 = heff_field(v_x2_2425, 0);
        V v_st_2427 = heff_field(v_x2_2425, 1);
        heff_take_n(v_x2_2425, 3ULL, 2);
        return heff_tag_at_n(v_ru_24e_240_24EApp, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EApp, 2, (V[]){v_f_2423, v_es_2426}), v_st_2427});
      }
      default: return heff_nomatch(v_x2_2425);
      }
    }
    default: return heff_nomatch(v_x3_2422);
    }
  }
  case TAG_ELet: {
    V v_x_2428 = heff_field(v_e_240, 0);
    V v_a_2429 = heff_field(v_e_240, 1);
    V v_b_2430 = heff_field(v_e_240, 2);
    heff_take_n(v_e_240, 7ULL, 3);
    V v_t_2431 = (g_heff_2ecompile_2espec_2eshapeGo(v_a_2429, v_st_241));
    return (g_heff_2ecompile_2espec_2eletThen(((V)&g_heff_2ecompile_2espec_2eshapeGo_clo), v_x_2428, v_b_2430, v_t_2431));
  }
  case TAG_ERecord: {
    V v_fs_2432 = heff_field(v_e_240, 0);
    V v_ru_24e_240_24ERecord = heff_take_reuse_n(v_e_240, 1ULL, 1);
    V v_t_2433 = (g_list_2emap_24s1173914895x100384474(heff_dup(v_fs_2432)));
    V v_x2_2434 = (g_heff_2ecompile_2espec_2eshapeMany(((V)&g_heff_2ecompile_2espec_2eshapeGo_clo), v_t_2433, v_st_241));
    switch (heff_tag_of(v_x2_2434)) {
    case TAG_MkPair: {
      V v_es_2435 = heff_field(v_x2_2434, 0);
      V v_st_2436 = heff_field(v_x2_2434, 1);
      V v_ru_24x2_2434_24MkPair = heff_take_reuse_n(v_x2_2434, 3ULL, 2);
      V v_t_2437 = heff_tag_at_n(v_ru_24e_240_24ERecord, TAG_ERecord, 1, (V[]){(g_heff_2ecompile_2espec_2elabelsTo(v_fs_2432, v_es_2435))});
      return heff_tag_at_n(v_ru_24x2_2434_24MkPair, TAG_MkPair, 2, (V[]){v_t_2437, v_st_2436});
    }
    default: return heff_nomatch(v_x2_2434);
    }
  }
  case TAG_EProj: {
    V v_e1_2438 = heff_field(v_e_240, 0);
    V v_l_2439 = heff_field(v_e_240, 1);
    V v_sh_2440 = heff_field(v_e_240, 2);
    V v_ru_24e_240_24EProj = heff_take_reuse_n(v_e_240, 7ULL, 3);
    V v_x2_2441 = (g_heff_2ecompile_2espec_2eshapeGo(v_e1_2438, v_st_241));
    switch (heff_tag_of(v_x2_2441)) {
    case TAG_MkPair: {
      V v_e_2442 = heff_field(v_x2_2441, 0);
      V v_st_2443 = heff_field(v_x2_2441, 1);
      V v_ru_24x2_2441_24MkPair = heff_take_reuse_n(v_x2_2441, 3ULL, 2);
      return heff_tag_at_n(v_ru_24x2_2441_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at_n(v_ru_24e_240_24EProj, TAG_EProj, 3, (V[]){v_e_2442, v_l_2439, v_sh_2440}), v_st_2443});
    }
    default: return heff_nomatch(v_x2_2441);
    }
  }
  case TAG_ETag: {
    V v_t_2444 = heff_field(v_e_240, 0);
    V v_as_2445 = heff_field(v_e_240, 1);
    V v_ru_24e_240_24ETag = heff_take_reuse_n(v_e_240, 3ULL, 2);
    V v_x2_2446 = (g_heff_2ecompile_2espec_2eshapeMany(((V)&g_heff_2ecompile_2espec_2eshapeGo_clo), v_as_2445, v_st_241));
    switch (heff_tag_of(v_x2_2446)) {
    case TAG_MkPair: {
      V v_es_2447 = heff_field(v_x2_2446, 0);
      V v_st_2448 = heff_field(v_x2_2446, 1);
      heff_take_n(v_x2_2446, 3ULL, 2);
      return heff_tag_at_n(v_ru_24e_240_24ETag, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ETag, 2, (V[]){v_t_2444, v_es_2447}), v_st_2448});
    }
    default: return heff_nomatch(v_x2_2446);
    }
  }
  case TAG_EMatch: {
    V v_sc_2449 = heff_field(v_e_240, 0);
    V v_arms_2450 = heff_field(v_e_240, 1);
    V v_ru_24e_240_24EMatch = heff_take_reuse_n(v_e_240, 3ULL, 2);
    V v_x3_2451 = (g_heff_2ecompile_2espec_2eshapeGo(v_sc_2449, v_st_241));
    switch (heff_tag_of(v_x3_2451)) {
    case TAG_MkPair: {
      V v_sc_2452 = heff_field(v_x3_2451, 0);
      V v_st_2453 = heff_field(v_x3_2451, 1);
      heff_take_n(v_x3_2451, 3ULL, 2);
      V v_t_2454 = (g_heff_2ecompile_2espec_2eshapeArms(((V)&g_heff_2ecompile_2espec_2eshapeGo_clo), v_arms_2450, v_st_2453));
      switch (heff_tag_of(v_t_2454)) {
      case TAG_MkPair: {
        V v_arms2_2455 = heff_field(v_t_2454, 0);
        V v_st2_2456 = heff_field(v_t_2454, 1);
        heff_take_n(v_t_2454, 3ULL, 2);
        return heff_tag_at_n(v_ru_24e_240_24EMatch, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EMatch, 2, (V[]){v_sc_2452, v_arms2_2455}), v_st2_2456});
      }
      default: return heff_nomatch(v_t_2454);
      }
    }
    default: return heff_nomatch(v_x3_2451);
    }
  }
  case TAG_EPrim: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_240, v_st_241});
  }
  case TAG_EPrimCall: {
    V v_p_2458 = heff_field(v_e_240, 0);
    V v_as_2459 = heff_field(v_e_240, 1);
    V v_ru_24e_240_24EPrimCall = heff_take_reuse_n(v_e_240, 3ULL, 2);
    V v_x2_2460 = (g_heff_2ecompile_2espec_2eshapeMany(((V)&g_heff_2ecompile_2espec_2eshapeGo_clo), v_as_2459, v_st_241));
    switch (heff_tag_of(v_x2_2460)) {
    case TAG_MkPair: {
      V v_es_2461 = heff_field(v_x2_2460, 0);
      V v_st_2462 = heff_field(v_x2_2460, 1);
      heff_take_n(v_x2_2460, 3ULL, 2);
      return heff_tag_at_n(v_ru_24e_240_24EPrimCall, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_EPrimCall, 2, (V[]){v_p_2458, v_es_2461}), v_st_2462});
    }
    default: return heff_nomatch(v_x2_2460);
    }
  }
  case TAG_ECall: {
    V v_g_2463 = heff_field(v_e_240, 0);
    V v_as_2464 = heff_field(v_e_240, 1);
    V v_ru_24e_240_24ECall = heff_take_reuse_n(v_e_240, 3ULL, 2);
    V v_x2_2465 = (g_heff_2ecompile_2espec_2eshapeMany(((V)&g_heff_2ecompile_2espec_2eshapeGo_clo), v_as_2464, v_st_241));
    switch (heff_tag_of(v_x2_2465)) {
    case TAG_MkPair: {
      V v_es_2466 = heff_field(v_x2_2465, 0);
      V v_st_2467 = heff_field(v_x2_2465, 1);
      heff_take_n(v_x2_2465, 3ULL, 2);
      return heff_tag_at_n(v_ru_24e_240_24ECall, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_ECall, 2, (V[]){v_g_2463, v_es_2466}), v_st_2467});
    }
    default: return heff_nomatch(v_x2_2465);
    }
  }
  case TAG_EInt: {
    V v_i_2468 = heff_field(v_e_240, 0);
    V v_ru_24e_240_24EInt = heff_take_reuse_n(v_e_240, 1ULL, 1);
    V v_t_2469 = heff_intShow(heff_dup(heff_rfield(v_st_241, 3)));
    V v_t_2470 = heff_tag_at_n(v_ru_24e_240_24EInt, TAG_EVar, 1, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2espec_2eshapeGo_str0), v_t_2469)});
    V v_t_2471 = heff_intShow(heff_dup(heff_rfield(v_st_241, 3)));
    V v_t_2472 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2espec_2eshapeGo_str1), v_t_2471), heff_take_field(v_st_241, 1)});
    V v_t_2473 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_EInt, 1, (V[]){v_i_2468}), heff_take_field(v_st_241, 2)});
    V v_t_2474 = heff_intAdd(heff_take_field(v_st_241, 3), MK_INT(1LL));
    V v_t_2475 = ({ V rv_1 = v_t_2472; V rv_2 = v_t_2473; V rv_3 = v_t_2474; V rr_ = heff_rec_reuse_n(v_st_241, 1ULL, 4, shape_ren__vars__holes__n); heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; rr_; });
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2470, v_t_2475});
  }
  case TAG_EFloat: {
    V v_x_2476 = heff_field(v_e_240, 0);
    V v_ru_24e_240_24EFloat = heff_take_reuse_n(v_e_240, 1ULL, 1);
    V v_t_2477 = heff_intShow(heff_dup(heff_rfield(v_st_241, 3)));
    V v_t_2478 = heff_tag_at_n(v_ru_24e_240_24EFloat, TAG_EVar, 1, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2espec_2eshapeGo_str2), v_t_2477)});
    V v_t_2479 = heff_intShow(heff_dup(heff_rfield(v_st_241, 3)));
    V v_t_2480 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2espec_2eshapeGo_str3), v_t_2479), heff_take_field(v_st_241, 1)});
    V v_t_2481 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_EFloat, 1, (V[]){v_x_2476}), heff_take_field(v_st_241, 2)});
    V v_t_2482 = heff_intAdd(heff_take_field(v_st_241, 3), MK_INT(1LL));
    V v_t_2483 = ({ V rv_1 = v_t_2480; V rv_2 = v_t_2481; V rv_3 = v_t_2482; V rr_ = heff_rec_reuse_n(v_st_241, 1ULL, 4, shape_ren__vars__holes__n); heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; rr_; });
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2478, v_t_2483});
  }
  case TAG_EStr: {
    V v_t_2484 = heff_field(v_e_240, 0);
    V v_ru_24e_240_24EStr = heff_take_reuse_n(v_e_240, 1ULL, 1);
    V v_t_2485 = heff_intShow(heff_dup(heff_rfield(v_st_241, 3)));
    V v_t_2486 = heff_tag_at_n(v_ru_24e_240_24EStr, TAG_EVar, 1, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2espec_2eshapeGo_str4), v_t_2485)});
    V v_t_2487 = heff_intShow(heff_dup(heff_rfield(v_st_241, 3)));
    V v_t_2488 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2espec_2eshapeGo_str5), v_t_2487), heff_take_field(v_st_241, 1)});
    V v_t_2489 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_EStr, 1, (V[]){v_t_2484}), heff_take_field(v_st_241, 2)});
    V v_t_2490 = heff_intAdd(heff_take_field(v_st_241, 3), MK_INT(1LL));
    V v_t_2491 = ({ V rv_1 = v_t_2488; V rv_2 = v_t_2489; V rv_3 = v_t_2490; V rr_ = heff_rec_reuse_n(v_st_241, 1ULL, 4, shape_ren__vars__holes__n); heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; rr_; });
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2486, v_t_2491});
  }
  case TAG_EFixed: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_240, v_st_241});
  }
  case TAG_EFloat32: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_240, v_st_241});
  }
  case TAG_EAbandon: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_240, v_st_241});
  }
  case TAG_EFix: {
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_e_240, v_st_241});
  }
  default: return heff_nomatch(v_e_240);
  }
}
V g_heff_2ecompile_2espec_2eshapeGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2espec_2eshapeGo(a[0], a[1]);
}
Clo g_heff_2ecompile_2espec_2eheadUses_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2espec_2eheadUses_entry, 2, 0};

V g_heff_2ecompile_2espec_2eheadUses(V v_go_240, V v_f_241) {
top: ;
  switch (heff_tag_of(v_f_241)) {
  case TAG_EVar: {
    return heff_tail(v_go_240, 1, (V[]){v_f_241});
  }
  case TAG_EGlobal: {
    heff_take_n(v_f_241, 0ULL, 1);
    heff_drop(v_go_240);
    return NTAG(TAG_Nil);
  }
  case TAG_ELam: {
    return heff_tail(v_go_240, 1, (V[]){v_f_241});
  }
  case TAG_EApp: {
    return heff_tail(v_go_240, 1, (V[]){v_f_241});
  }
  case TAG_ELet: {
    return heff_tail(v_go_240, 1, (V[]){v_f_241});
  }
  case TAG_ERecord: {
    return heff_tail(v_go_240, 1, (V[]){v_f_241});
  }
  case TAG_EProj: {
    return heff_tail(v_go_240, 1, (V[]){v_f_241});
  }
  case TAG_ETag: {
    return heff_tail(v_go_240, 1, (V[]){v_f_241});
  }
  case TAG_EMatch: {
    return heff_tail(v_go_240, 1, (V[]){v_f_241});
  }
  case TAG_EPrim: {
    return heff_tail(v_go_240, 1, (V[]){v_f_241});
  }
  case TAG_EPrimCall: {
    return heff_tail(v_go_240, 1, (V[]){v_f_241});
  }
  case TAG_ECall: {
    return heff_tail(v_go_240, 1, (V[]){v_f_241});
  }
  case TAG_EInt: {
    return heff_tail(v_go_240, 1, (V[]){v_f_241});
  }
  case TAG_EFloat: {
    return heff_tail(v_go_240, 1, (V[]){v_f_241});
  }
  case TAG_EStr: {
    return heff_tail(v_go_240, 1, (V[]){v_f_241});
  }
  case TAG_EFixed: {
    return heff_tail(v_go_240, 1, (V[]){v_f_241});
  }
  case TAG_EFloat32: {
    return heff_tail(v_go_240, 1, (V[]){v_f_241});
  }
  case TAG_EAbandon: {
    return heff_tail(v_go_240, 1, (V[]){v_f_241});
  }
  case TAG_EFix: {
    return heff_tail(v_go_240, 1, (V[]){v_f_241});
  }
  default: return heff_nomatch(v_f_241);
  }
}
V g_heff_2ecompile_2espec_2eheadUses_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2espec_2eheadUses(a[0], a[1]);
}
V g_heff_2ecompile_2espec_2eusesOf_lam0(V self, V *args);
V g_heff_2ecompile_2espec_2eusesOf_lam1(V self, V *args);
V g_heff_2ecompile_2espec_2eusesOf_lam2(V self, V *args);
V g_heff_2ecompile_2espec_2eusesOf_lam3(V self, V *args);
V g_heff_2ecompile_2espec_2eusesOf_lam4(V self, V *args);
V g_heff_2ecompile_2espec_2eusesOf_lam5(V self, V *args);
Clo g_heff_2ecompile_2espec_2eusesOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2espec_2eusesOf_entry, 2, 0};

V g_heff_2ecompile_2espec_2eusesOf(V v_g_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_EVar: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_g_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EGlobal: {
    V v_h_243 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    if (heff_strEq_c(v_h_243, v_g_240)) {
      return heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_Nothing), NTAG(TAG_Nil)});
    } else {
      return NTAG(TAG_Nil);
    }
  }
  case TAG_ELam: {
    V v_b_246 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 2ULL, 2);
    V t_0 = v_g_240;
    V t_1 = v_b_246;
    v_g_240 = t_0;
    v_x2_241 = t_1;
    goto top;
  }
  case TAG_EApp: {
    V v_f_247 = heff_field(v_x2_241, 0);
    V v_as_248 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24EApp = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_2440;
    switch (heff_tag_of(v_f_247)) {
    case TAG_EVar: {
      heff_drop_cell(v_ru_24x2_241_24EApp, 2);
      v_t_2440 = NTAG(TAG_Nil);
      break;
    }
    case TAG_EGlobal: {
      V v_h_2410 = heff_dup(heff_field(v_f_247, 0));
      if (heff_strEq_c(v_h_2410, heff_dup(v_g_240))) {
        v_t_2440 = heff_tag_at_n(v_ru_24x2_241_24EApp, TAG_Cons, 2, (V[]){heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_as_248)}), NTAG(TAG_Nil)});
      } else {
        heff_drop_cell(v_ru_24x2_241_24EApp, 2);
        v_t_2440 = NTAG(TAG_Nil);
      }
      break;
    }
    case TAG_ELam: {
      heff_drop_cell(v_ru_24x2_241_24EApp, 2);
      v_t_2440 = NTAG(TAG_Nil);
      break;
    }
    case TAG_EApp: {
      heff_drop_cell(v_ru_24x2_241_24EApp, 2);
      v_t_2440 = NTAG(TAG_Nil);
      break;
    }
    case TAG_ELet: {
      heff_drop_cell(v_ru_24x2_241_24EApp, 2);
      v_t_2440 = NTAG(TAG_Nil);
      break;
    }
    case TAG_ERecord: {
      heff_drop_cell(v_ru_24x2_241_24EApp, 2);
      v_t_2440 = NTAG(TAG_Nil);
      break;
    }
    case TAG_EProj: {
      heff_drop_cell(v_ru_24x2_241_24EApp, 2);
      v_t_2440 = NTAG(TAG_Nil);
      break;
    }
    case TAG_ETag: {
      heff_drop_cell(v_ru_24x2_241_24EApp, 2);
      v_t_2440 = NTAG(TAG_Nil);
      break;
    }
    case TAG_EMatch: {
      heff_drop_cell(v_ru_24x2_241_24EApp, 2);
      v_t_2440 = NTAG(TAG_Nil);
      break;
    }
    case TAG_EPrim: {
      heff_drop_cell(v_ru_24x2_241_24EApp, 2);
      v_t_2440 = NTAG(TAG_Nil);
      break;
    }
    case TAG_EPrimCall: {
      heff_drop_cell(v_ru_24x2_241_24EApp, 2);
      v_t_2440 = NTAG(TAG_Nil);
      break;
    }
    case TAG_ECall: {
      heff_drop_cell(v_ru_24x2_241_24EApp, 2);
      v_t_2440 = NTAG(TAG_Nil);
      break;
    }
    case TAG_EInt: {
      heff_drop_cell(v_ru_24x2_241_24EApp, 2);
      v_t_2440 = NTAG(TAG_Nil);
      break;
    }
    case TAG_EFloat: {
      heff_drop_cell(v_ru_24x2_241_24EApp, 2);
      v_t_2440 = NTAG(TAG_Nil);
      break;
    }
    case TAG_EStr: {
      heff_drop_cell(v_ru_24x2_241_24EApp, 2);
      v_t_2440 = NTAG(TAG_Nil);
      break;
    }
    case TAG_EFixed: {
      heff_drop_cell(v_ru_24x2_241_24EApp, 2);
      v_t_2440 = NTAG(TAG_Nil);
      break;
    }
    case TAG_EFloat32: {
      heff_drop_cell(v_ru_24x2_241_24EApp, 2);
      v_t_2440 = NTAG(TAG_Nil);
      break;
    }
    case TAG_EAbandon: {
      heff_drop_cell(v_ru_24x2_241_24EApp, 2);
      v_t_2440 = NTAG(TAG_Nil);
      break;
    }
    case TAG_EFix: {
      heff_drop_cell(v_ru_24x2_241_24EApp, 2);
      v_t_2440 = NTAG(TAG_Nil);
      break;
    }
    default: heff_nomatch(v_f_247);
    }
    V v_t_2441 = heff_tr(heff_apply(((V)&g_heff_2ecompile_2espec_2eusesOf_clo), 1, (V[]){heff_dup(v_g_240)}));
    V v_t_2442 = heff_tr(g_heff_2ecompile_2espec_2eheadUses(v_t_2441, v_f_247));
    V v_f_2443 = heff_tr(heff_apply(((V)&g_heff_2ecompile_2espec_2eusesOf_clo), 1, (V[]){v_g_240}));
    V v_t_2444 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_as_248));
    V v_t_2448 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2espec_2eusesOf_lam0, 2, 1, (V[]){v_f_2443}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_2444; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2444); r_; });
    V v_t_2449 = (g_heff_2ecompile_2espec_2eappendS(v_t_2442, v_t_2448));
    HEFF_LAST return g_heff_2ecompile_2espec_2eappendS(v_t_2440, v_t_2449);
  }
  case TAG_ELet: {
    V v_a_2451 = heff_field(v_x2_241, 1);
    V v_b_2452 = heff_field(v_x2_241, 2);
    heff_take_n(v_x2_241, 6ULL, 3);
    V v_t_2453 = (g_heff_2ecompile_2espec_2eusesOf(heff_dup(v_g_240), v_a_2451));
    V v_t_2454 = (g_heff_2ecompile_2espec_2eusesOf(v_g_240, v_b_2452));
    HEFF_LAST return g_heff_2ecompile_2espec_2eappendS(v_t_2453, v_t_2454);
  }
  case TAG_ERecord: {
    V v_fs_2455 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    V v_f_2456 = heff_tr(heff_apply(((V)&g_heff_2ecompile_2espec_2eusesOf_clo), 1, (V[]){v_g_240}));
    V v_xs_2457 = (g_list_2emap_24s1173914895x100384474(v_fs_2455));
    V v_t_2458 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2457));
    return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2espec_2eusesOf_lam1, 2, 1, (V[]){v_f_2456}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_2458; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2458); r_; });
  }
  case TAG_EProj: {
    V v_e_2462 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 3);
    V t_0 = v_g_240;
    V t_1 = v_e_2462;
    v_g_240 = t_0;
    v_x2_241 = t_1;
    goto top;
  }
  case TAG_ETag: {
    V v_as_2466 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 2ULL, 2);
    V v_f_2467 = heff_tr(heff_apply(((V)&g_heff_2ecompile_2espec_2eusesOf_clo), 1, (V[]){v_g_240}));
    V v_t_2468 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_as_2466));
    return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2espec_2eusesOf_lam2, 2, 1, (V[]){v_f_2467}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_2468; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2468); r_; });
  }
  case TAG_EMatch: {
    V v_s_2472 = heff_field(v_x2_241, 0);
    V v_arms_2473 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 3ULL, 2);
    V v_t_2474 = (g_heff_2ecompile_2espec_2eusesOf(heff_dup(v_g_240), v_s_2472));
    V v_f_2475 = heff_tr(heff_apply(((V)&g_heff_2ecompile_2espec_2eusesOf_clo), 1, (V[]){v_g_240}));
    V v_xs_2476 = (g_list_2emap_24s60612435x257154841(v_arms_2473));
    V v_t_2477 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2476));
    V v_t_2481 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2espec_2eusesOf_lam3, 2, 1, (V[]){v_f_2475}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_2477; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2477); r_; });
    HEFF_LAST return g_heff_2ecompile_2espec_2eappendS(v_t_2474, v_t_2481);
  }
  case TAG_EPrim: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_g_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EPrimCall: {
    V v_as_2484 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 2ULL, 2);
    V v_f_2485 = heff_tr(heff_apply(((V)&g_heff_2ecompile_2espec_2eusesOf_clo), 1, (V[]){v_g_240}));
    V v_t_2486 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_as_2484));
    return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2espec_2eusesOf_lam4, 2, 1, (V[]){v_f_2485}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_2486; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2486); r_; });
  }
  case TAG_ECall: {
    V v_h_2490 = heff_field(v_x2_241, 0);
    V v_as_2491 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24ECall = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_2493;
    if (heff_strEq_c(v_h_2490, heff_dup(v_g_240))) {
      v_t_2493 = heff_tag_at_n(v_ru_24x2_241_24ECall, TAG_Cons, 2, (V[]){heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_as_2491)}), NTAG(TAG_Nil)});
    } else {
      heff_drop_cell(v_ru_24x2_241_24ECall, 2);
      v_t_2493 = NTAG(TAG_Nil);
    }
    V v_f_2494 = heff_tr(heff_apply(((V)&g_heff_2ecompile_2espec_2eusesOf_clo), 1, (V[]){v_g_240}));
    V v_t_2495 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_as_2491));
    V v_t_2499 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2espec_2eusesOf_lam5, 2, 1, (V[]){v_f_2494}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_2495; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2495); r_; });
    HEFF_LAST return g_heff_2ecompile_2espec_2eappendS(v_t_2493, v_t_2499);
  }
  case TAG_EInt: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_g_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EFloat: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_g_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EStr: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_g_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EFixed: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_g_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EFloat32: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_g_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EAbandon: {
    heff_drop(v_g_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EFix: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_g_240);
    return NTAG(TAG_Nil);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2espec_2eusesOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2espec_2eusesOf(a[0], a[1]);
}
V g_heff_2ecompile_2espec_2eusesOf_lam0(V self, V *args) {
  V v_acc_2445 = args[0];
  V v_x_2446 = args[1];
  V v_f_2443 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2447 = heff_tr(heff_apply(v_f_2443, 1, (V[]){v_x_2446}));
  return (g_prelude_2e_2b_2b(v_t_2447, v_acc_2445));
}
V g_heff_2ecompile_2espec_2eusesOf_lam1(V self, V *args) {
  V v_acc_2459 = args[0];
  V v_x_2460 = args[1];
  V v_f_2456 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2461 = heff_tr(heff_apply(v_f_2456, 1, (V[]){v_x_2460}));
  return (g_prelude_2e_2b_2b(v_t_2461, v_acc_2459));
}
V g_heff_2ecompile_2espec_2eusesOf_lam2(V self, V *args) {
  V v_acc_2469 = args[0];
  V v_x_2470 = args[1];
  V v_f_2467 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2471 = heff_tr(heff_apply(v_f_2467, 1, (V[]){v_x_2470}));
  return (g_prelude_2e_2b_2b(v_t_2471, v_acc_2469));
}
V g_heff_2ecompile_2espec_2eusesOf_lam3(V self, V *args) {
  V v_acc_2478 = args[0];
  V v_x_2479 = args[1];
  V v_f_2475 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2480 = heff_tr(heff_apply(v_f_2475, 1, (V[]){v_x_2479}));
  return (g_prelude_2e_2b_2b(v_t_2480, v_acc_2478));
}
V g_heff_2ecompile_2espec_2eusesOf_lam4(V self, V *args) {
  V v_acc_2487 = args[0];
  V v_x_2488 = args[1];
  V v_f_2485 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2489 = heff_tr(heff_apply(v_f_2485, 1, (V[]){v_x_2488}));
  return (g_prelude_2e_2b_2b(v_t_2489, v_acc_2487));
}
V g_heff_2ecompile_2espec_2eusesOf_lam5(V self, V *args) {
  V v_acc_2496 = args[0];
  V v_x_2497 = args[1];
  V v_f_2494 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2498 = heff_tr(heff_apply(v_f_2494, 1, (V[]){v_x_2497}));
  return (g_prelude_2e_2b_2b(v_t_2498, v_acc_2496));
}
Clo g_heff_2ecompile_2espec_2enthS_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2espec_2enthS_entry, 2, 0};

V g_heff_2ecompile_2espec_2enthS(V v_i_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_i_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    if (heff_intEq_c(heff_dup(v_i_240), MK_INT(0LL))) {
      heff_drop(v_i_240);
      return heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_x_242)});
    } else {
      V t_0 = heff_intSub(v_i_240, MK_INT(1LL));
      V t_1 = v_xs_243;
      v_i_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2espec_2enthS_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecompile_2espec_2enthS(a[0], a[1]); heff_drop(a[1]); return r;
}
Clo g_heff_2ecompile_2espec_2ehandsOn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2espec_2ehandsOn_entry, 3, 0};

V g_heff_2ecompile_2espec_2ehandsOn(V v_x_240, V v_i_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_Nothing: {
    heff_drop(v_x_240);
    heff_drop(v_i_241);
    return NTAG(TAG_False);
  }
  case TAG_Just: {
    V v_as_243 = heff_field(v_x3_242, 0);
    V v_x2_244 = (g_heff_2ecompile_2espec_2enthS(v_i_241, v_as_243));
    switch (heff_tag_of(v_x2_244)) {
    case TAG_Nothing: {
      heff_drop(v_x_240);
      return NTAG(TAG_False);
    }
    case TAG_Just: {
      V v_x21_245 = heff_field(v_x2_244, 0);
      heff_take_n(v_x2_244, 1ULL, 1);
      switch (heff_tag_of(v_x21_245)) {
      case TAG_EVar: {
        V v_y_246 = heff_field(v_x21_245, 0);
        heff_take_n(v_x21_245, 1ULL, 1);
        return heff_strEq(v_x_240, v_y_246);
      }
      case TAG_EGlobal: {
        heff_take_n(v_x21_245, 0ULL, 1);
        heff_drop(v_x_240);
        return NTAG(TAG_False);
      }
      case TAG_ELam: {
        heff_take_n(v_x21_245, 0ULL, 2);
        heff_drop(v_x_240);
        return NTAG(TAG_False);
      }
      case TAG_EApp: {
        heff_take_n(v_x21_245, 0ULL, 2);
        heff_drop(v_x_240);
        return NTAG(TAG_False);
      }
      case TAG_ELet: {
        heff_take_n(v_x21_245, 0ULL, 3);
        heff_drop(v_x_240);
        return NTAG(TAG_False);
      }
      case TAG_ERecord: {
        heff_take_n(v_x21_245, 0ULL, 1);
        heff_drop(v_x_240);
        return NTAG(TAG_False);
      }
      case TAG_EProj: {
        heff_take_n(v_x21_245, 0ULL, 3);
        heff_drop(v_x_240);
        return NTAG(TAG_False);
      }
      case TAG_ETag: {
        heff_take_n(v_x21_245, 0ULL, 2);
        heff_drop(v_x_240);
        return NTAG(TAG_False);
      }
      case TAG_EMatch: {
        heff_take_n(v_x21_245, 0ULL, 2);
        heff_drop(v_x_240);
        return NTAG(TAG_False);
      }
      case TAG_EPrim: {
        heff_take_n(v_x21_245, 0ULL, 1);
        heff_drop(v_x_240);
        return NTAG(TAG_False);
      }
      case TAG_EPrimCall: {
        heff_take_n(v_x21_245, 0ULL, 2);
        heff_drop(v_x_240);
        return NTAG(TAG_False);
      }
      case TAG_ECall: {
        heff_take_n(v_x21_245, 0ULL, 2);
        heff_drop(v_x_240);
        return NTAG(TAG_False);
      }
      case TAG_EInt: {
        heff_take_n(v_x21_245, 0ULL, 1);
        heff_drop(v_x_240);
        return NTAG(TAG_False);
      }
      case TAG_EFloat: {
        heff_take_n(v_x21_245, 0ULL, 1);
        heff_drop(v_x_240);
        return NTAG(TAG_False);
      }
      case TAG_EStr: {
        heff_take_n(v_x21_245, 0ULL, 1);
        heff_drop(v_x_240);
        return NTAG(TAG_False);
      }
      case TAG_EFixed: {
        heff_take_n(v_x21_245, 0ULL, 2);
        heff_drop(v_x_240);
        return NTAG(TAG_False);
      }
      case TAG_EFloat32: {
        heff_take_n(v_x21_245, 0ULL, 1);
        heff_drop(v_x_240);
        return NTAG(TAG_False);
      }
      case TAG_EAbandon: {
        heff_drop(v_x_240);
        return NTAG(TAG_False);
      }
      case TAG_EFix: {
        heff_take_n(v_x21_245, 0ULL, 2);
        heff_drop(v_x_240);
        return NTAG(TAG_False);
      }
      default: return heff_nomatch(v_x21_245);
      }
    }
    default: return heff_nomatch(v_x2_244);
    }
  }
  default: return heff_nomatch(v_x3_242);
  }
}
V g_heff_2ecompile_2espec_2ehandsOn_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecompile_2espec_2ehandsOn(a[0], a[1], a[2]); heff_drop(a[2]); return r;
}
Clo g_heff_2ecompile_2espec_2estaticGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2espec_2estaticGo_entry, 3, 0};

V g_heff_2ecompile_2espec_2estaticGo(V v_uses_240, V v_x2_241, V v_i_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_i_242);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_245 = heff_tr(heff_apply(((V)&g_heff_2ecompile_2espec_2ehandsOn_clo), 2, (V[]){v_x_243, heff_dup(v_i_242)}));
    V v_t_246 = (g_heff_2ecompile_2espec_2eallS(v_t_245, v_uses_240));
    return heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_246, (g_heff_2ecompile_2espec_2estaticGo(v_uses_240, v_xs_244, heff_intAdd(v_i_242, MK_INT(1LL))))});
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2espec_2estaticGo_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecompile_2espec_2estaticGo(a[0], a[1], a[2]); heff_drop(a[0]); return r;
}
Clo g_heff_2ecompile_2espec_2edropAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2espec_2edropAt_entry, 2, 0};

V g_heff_2ecompile_2espec_2edropAt(V v_x1_240, V v_as_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return v_as_241;
  }
  case TAG_Cons: {
    V v_d_242 = heff_field(v_x1_240, 0);
    V v_ds_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_as_241)) {
    case TAG_Nil: {
      heff_drop(v_d_242);
      heff_drop(v_ds_243);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_a_244 = heff_field(v_as_241, 0);
      V v_as2_245 = heff_field(v_as_241, 1);
      heff_take_n(v_as_241, 3ULL, 2);
      switch (heff_tag_of(v_d_242)) {
      case TAG_True: {
        heff_drop_cell(v_ru_24x1_240_24Cons, 2);
        heff_drop(v_a_244);
        V t_0 = v_ds_243;
        V t_1 = v_as2_245;
        v_x1_240 = t_0;
        v_as_241 = t_1;
        goto top;
      }
      case TAG_False: {
        return heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_a_244, (g_heff_2ecompile_2espec_2edropAt(v_ds_243, v_as2_245))});
      }
      default: return heff_nomatch(v_d_242);
      }
    }
    default: return heff_nomatch(v_as_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2espec_2edropAt_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2espec_2edropAt(a[0], a[1]);
}
Clo g_heff_2ecompile_2espec_2eselfHead_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2espec_2eselfHead_entry, 4, 0};

V g_heff_2ecompile_2espec_2eselfHead(V v_go_240, V v_g_241, V v_h_242, V v_f_243) {
top: ;
  switch (heff_tag_of(v_f_243)) {
  case TAG_EVar: {
    heff_drop(v_g_241);
    heff_drop(v_h_242);
    return heff_tail(v_go_240, 1, (V[]){v_f_243});
  }
  case TAG_EGlobal: {
    V v_k_245 = heff_field(v_f_243, 0);
    V v_ru_24f_243_24EGlobal = heff_take_reuse_n(v_f_243, 1ULL, 1);
    heff_drop(v_go_240);
    V v_t_247;
    if (heff_strEq_c(heff_dup(v_k_245), v_g_241)) {
      heff_drop(v_k_245);
      v_t_247 = v_h_242;
    } else {
      heff_drop(v_h_242);
      v_t_247 = v_k_245;
    }
    return heff_tag_at_n(v_ru_24f_243_24EGlobal, TAG_EGlobal, 1, (V[]){v_t_247});
  }
  case TAG_ELam: {
    heff_drop(v_g_241);
    heff_drop(v_h_242);
    return heff_tail(v_go_240, 1, (V[]){v_f_243});
  }
  case TAG_EApp: {
    heff_drop(v_g_241);
    heff_drop(v_h_242);
    return heff_tail(v_go_240, 1, (V[]){v_f_243});
  }
  case TAG_ELet: {
    heff_drop(v_g_241);
    heff_drop(v_h_242);
    return heff_tail(v_go_240, 1, (V[]){v_f_243});
  }
  case TAG_ERecord: {
    heff_drop(v_g_241);
    heff_drop(v_h_242);
    return heff_tail(v_go_240, 1, (V[]){v_f_243});
  }
  case TAG_EProj: {
    heff_drop(v_g_241);
    heff_drop(v_h_242);
    return heff_tail(v_go_240, 1, (V[]){v_f_243});
  }
  case TAG_ETag: {
    heff_drop(v_g_241);
    heff_drop(v_h_242);
    return heff_tail(v_go_240, 1, (V[]){v_f_243});
  }
  case TAG_EMatch: {
    heff_drop(v_g_241);
    heff_drop(v_h_242);
    return heff_tail(v_go_240, 1, (V[]){v_f_243});
  }
  case TAG_EPrim: {
    heff_drop(v_g_241);
    heff_drop(v_h_242);
    return heff_tail(v_go_240, 1, (V[]){v_f_243});
  }
  case TAG_EPrimCall: {
    heff_drop(v_g_241);
    heff_drop(v_h_242);
    return heff_tail(v_go_240, 1, (V[]){v_f_243});
  }
  case TAG_ECall: {
    heff_drop(v_g_241);
    heff_drop(v_h_242);
    return heff_tail(v_go_240, 1, (V[]){v_f_243});
  }
  case TAG_EInt: {
    heff_drop(v_g_241);
    heff_drop(v_h_242);
    return heff_tail(v_go_240, 1, (V[]){v_f_243});
  }
  case TAG_EFloat: {
    heff_drop(v_g_241);
    heff_drop(v_h_242);
    return heff_tail(v_go_240, 1, (V[]){v_f_243});
  }
  case TAG_EStr: {
    heff_drop(v_g_241);
    heff_drop(v_h_242);
    return heff_tail(v_go_240, 1, (V[]){v_f_243});
  }
  case TAG_EFixed: {
    heff_drop(v_g_241);
    heff_drop(v_h_242);
    return heff_tail(v_go_240, 1, (V[]){v_f_243});
  }
  case TAG_EFloat32: {
    heff_drop(v_g_241);
    heff_drop(v_h_242);
    return heff_tail(v_go_240, 1, (V[]){v_f_243});
  }
  case TAG_EAbandon: {
    heff_drop(v_g_241);
    heff_drop(v_h_242);
    return heff_tail(v_go_240, 1, (V[]){v_f_243});
  }
  case TAG_EFix: {
    heff_drop(v_g_241);
    heff_drop(v_h_242);
    return heff_tail(v_go_240, 1, (V[]){v_f_243});
  }
  default: return heff_nomatch(v_f_243);
  }
}
V g_heff_2ecompile_2espec_2eselfHead_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2espec_2eselfHead(a[0], a[1], a[2], a[3]);
}
Clo g_heff_2ecompile_2espec_2eselfArgs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2espec_2eselfArgs_entry, 5, 0};

V g_heff_2ecompile_2espec_2eselfArgs(V v_g_240, V v_pre_241, V v_ds_242, V v_f_243, V v_as_244) {
top: ;
  switch (heff_tag_of(v_f_243)) {
  case TAG_EVar: {
    heff_drop(v_g_240);
    heff_drop(v_pre_241);
    heff_drop(v_ds_242);
    return v_as_244;
  }
  case TAG_EGlobal: {
    V v_k_246 = heff_field(v_f_243, 0);
    if (heff_strEq_c(heff_dup(v_k_246), v_g_240)) {
      V v_t_248 = (g_heff_2ecompile_2espec_2edropAt(v_ds_242, v_as_244));
      return (g_heff_2ecompile_2espec_2eappendS(v_pre_241, v_t_248));
    } else {
      heff_drop(v_pre_241);
      heff_drop(v_ds_242);
      return v_as_244;
    }
  }
  case TAG_ELam: {
    heff_drop(v_g_240);
    heff_drop(v_pre_241);
    heff_drop(v_ds_242);
    return v_as_244;
  }
  case TAG_EApp: {
    heff_drop(v_g_240);
    heff_drop(v_pre_241);
    heff_drop(v_ds_242);
    return v_as_244;
  }
  case TAG_ELet: {
    heff_drop(v_g_240);
    heff_drop(v_pre_241);
    heff_drop(v_ds_242);
    return v_as_244;
  }
  case TAG_ERecord: {
    heff_drop(v_g_240);
    heff_drop(v_pre_241);
    heff_drop(v_ds_242);
    return v_as_244;
  }
  case TAG_EProj: {
    heff_drop(v_g_240);
    heff_drop(v_pre_241);
    heff_drop(v_ds_242);
    return v_as_244;
  }
  case TAG_ETag: {
    heff_drop(v_g_240);
    heff_drop(v_pre_241);
    heff_drop(v_ds_242);
    return v_as_244;
  }
  case TAG_EMatch: {
    heff_drop(v_g_240);
    heff_drop(v_pre_241);
    heff_drop(v_ds_242);
    return v_as_244;
  }
  case TAG_EPrim: {
    heff_drop(v_g_240);
    heff_drop(v_pre_241);
    heff_drop(v_ds_242);
    return v_as_244;
  }
  case TAG_EPrimCall: {
    heff_drop(v_g_240);
    heff_drop(v_pre_241);
    heff_drop(v_ds_242);
    return v_as_244;
  }
  case TAG_ECall: {
    heff_drop(v_g_240);
    heff_drop(v_pre_241);
    heff_drop(v_ds_242);
    return v_as_244;
  }
  case TAG_EInt: {
    heff_drop(v_g_240);
    heff_drop(v_pre_241);
    heff_drop(v_ds_242);
    return v_as_244;
  }
  case TAG_EFloat: {
    heff_drop(v_g_240);
    heff_drop(v_pre_241);
    heff_drop(v_ds_242);
    return v_as_244;
  }
  case TAG_EStr: {
    heff_drop(v_g_240);
    heff_drop(v_pre_241);
    heff_drop(v_ds_242);
    return v_as_244;
  }
  case TAG_EFixed: {
    heff_drop(v_g_240);
    heff_drop(v_pre_241);
    heff_drop(v_ds_242);
    return v_as_244;
  }
  case TAG_EFloat32: {
    heff_drop(v_g_240);
    heff_drop(v_pre_241);
    heff_drop(v_ds_242);
    return v_as_244;
  }
  case TAG_EAbandon: {
    heff_drop(v_g_240);
    heff_drop(v_pre_241);
    heff_drop(v_ds_242);
    return v_as_244;
  }
  case TAG_EFix: {
    heff_drop(v_g_240);
    heff_drop(v_pre_241);
    heff_drop(v_ds_242);
    return v_as_244;
  }
  default: return heff_nomatch(v_f_243);
  }
}
V g_heff_2ecompile_2espec_2eselfArgs_entry(V self, V *a) {
  (void)self;
  V r = g_heff_2ecompile_2espec_2eselfArgs(a[0], a[1], a[2], a[3], a[4]); heff_drop(a[3]); return r;
}
V g_heff_2ecompile_2espec_2eselfTo_lam0(V self, V *args);
V g_heff_2ecompile_2espec_2eselfTo_lam1(V self, V *args);
Clo g_heff_2ecompile_2espec_2eselfTo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2espec_2eselfTo_entry, 5, 0};

V g_heff_2ecompile_2espec_2eselfTo(V v_g_240, V v_h_241, V v_pre_242, V v_ds_243, V v_e_244) {
top: ;
  switch (heff_tag_of(v_e_244)) {
  case TAG_EVar: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_pre_242);
    heff_drop(v_ds_243);
    return v_e_244;
  }
  case TAG_EGlobal: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_pre_242);
    heff_drop(v_ds_243);
    return v_e_244;
  }
  case TAG_ELam: {
    V v_xs_247 = heff_field(v_e_244, 0);
    V v_b_248 = heff_field(v_e_244, 1);
    V v_ru_24e_244_24ELam = heff_take_reuse_n(v_e_244, 3ULL, 2);
    return heff_tag_at_n(v_ru_24e_244_24ELam, TAG_ELam, 2, (V[]){v_xs_247, (g_heff_2ecompile_2espec_2eselfTo(v_g_240, v_h_241, v_pre_242, v_ds_243, v_b_248))});
  }
  case TAG_EApp: {
    V v_f_249 = heff_field(v_e_244, 0);
    V v_as_2410 = heff_field(v_e_244, 1);
    V v_ru_24e_244_24EApp = heff_take_reuse_n(v_e_244, 3ULL, 2);
    V v_t_2411 = heff_tr(heff_apply(((V)&g_heff_2ecompile_2espec_2eselfTo_clo), 4, (V[]){heff_dup(v_g_240), heff_dup(v_h_241), heff_dup(v_pre_242), heff_dup(v_ds_243)}));
    V v_t_2412 = heff_tr(g_heff_2ecompile_2espec_2eselfHead(v_t_2411, heff_dup(v_g_240), heff_dup(v_h_241), heff_dup(v_f_249)));
    V v_t_2413 = heff_tr(heff_apply(((V)&g_heff_2ecompile_2espec_2eselfTo_clo), 4, (V[]){heff_dup(v_g_240), v_h_241, heff_dup(v_pre_242), heff_dup(v_ds_243)}));
    V v_t_2414 = ({ V a_0 = v_g_240; V a_1 = v_pre_242; V a_2 = v_ds_243; V a_3 = v_f_249; V a_4 = v_as_2410; V r_ = (g_heff_2ecompile_2espec_2eselfArgs(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_f_249); r_; });
    return heff_tag_at_n(v_ru_24e_244_24EApp, TAG_EApp, 2, (V[]){v_t_2412, (g_list_2emap(v_t_2413, v_t_2414))});
  }
  case TAG_ELet: {
    V v_x_2415 = heff_field(v_e_244, 0);
    V v_a_2416 = heff_field(v_e_244, 1);
    V v_b_2417 = heff_field(v_e_244, 2);
    V v_ru_24e_244_24ELet = heff_take_reuse_n(v_e_244, 7ULL, 3);
    V v_t_2418 = (g_heff_2ecompile_2espec_2eselfTo(heff_dup(v_g_240), heff_dup(v_h_241), heff_dup(v_pre_242), heff_dup(v_ds_243), v_a_2416));
    return heff_tag_at_n(v_ru_24e_244_24ELet, TAG_ELet, 3, (V[]){v_x_2415, v_t_2418, (g_heff_2ecompile_2espec_2eselfTo(v_g_240, v_h_241, v_pre_242, v_ds_243, v_b_2417))});
  }
  case TAG_ERecord: {
    V v_fs_2419 = heff_field(v_e_244, 0);
    V v_ru_24e_244_24ERecord = heff_take_reuse_n(v_e_244, 1ULL, 1);
    V v_go_2420 = heff_tr(heff_apply(((V)&g_heff_2ecompile_2espec_2eselfTo_clo), 4, (V[]){v_g_240, v_h_241, v_pre_242, v_ds_243}));
    return heff_tag_at_n(v_ru_24e_244_24ERecord, TAG_ERecord, 1, (V[]){(g_list_2emap(heff_clo_n(g_heff_2ecompile_2espec_2eselfTo_lam0, 1, 1, (V[]){v_go_2420}), v_fs_2419))});
  }
  case TAG_EProj: {
    V v_e1_2425 = heff_field(v_e_244, 0);
    V v_l_2426 = heff_field(v_e_244, 1);
    V v_sh_2427 = heff_field(v_e_244, 2);
    V v_ru_24e_244_24EProj = heff_take_reuse_n(v_e_244, 7ULL, 3);
    V v_t_2428 = (g_heff_2ecompile_2espec_2eselfTo(v_g_240, v_h_241, v_pre_242, v_ds_243, v_e1_2425));
    return heff_tag_at_n(v_ru_24e_244_24EProj, TAG_EProj, 3, (V[]){v_t_2428, v_l_2426, v_sh_2427});
  }
  case TAG_ETag: {
    V v_t_2429 = heff_field(v_e_244, 0);
    V v_as_2430 = heff_field(v_e_244, 1);
    V v_ru_24e_244_24ETag = heff_take_reuse_n(v_e_244, 3ULL, 2);
    V v_t_2431 = heff_tr(heff_apply(((V)&g_heff_2ecompile_2espec_2eselfTo_clo), 4, (V[]){v_g_240, v_h_241, v_pre_242, v_ds_243}));
    return heff_tag_at_n(v_ru_24e_244_24ETag, TAG_ETag, 2, (V[]){v_t_2429, (g_list_2emap(v_t_2431, v_as_2430))});
  }
  case TAG_EMatch: {
    V v_s_2432 = heff_field(v_e_244, 0);
    V v_arms_2433 = heff_field(v_e_244, 1);
    V v_ru_24e_244_24EMatch = heff_take_reuse_n(v_e_244, 3ULL, 2);
    V v_t_2434 = (g_heff_2ecompile_2espec_2eselfTo(heff_dup(v_g_240), heff_dup(v_h_241), heff_dup(v_pre_242), heff_dup(v_ds_243), v_s_2432));
    V v_go_2435 = heff_tr(heff_apply(((V)&g_heff_2ecompile_2espec_2eselfTo_clo), 4, (V[]){v_g_240, v_h_241, v_pre_242, v_ds_243}));
    return heff_tag_at_n(v_ru_24e_244_24EMatch, TAG_EMatch, 2, (V[]){v_t_2434, (g_list_2emap(heff_clo_n(g_heff_2ecompile_2espec_2eselfTo_lam1, 1, 1, (V[]){v_go_2435}), v_arms_2433))});
  }
  case TAG_EPrim: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_pre_242);
    heff_drop(v_ds_243);
    return v_e_244;
  }
  case TAG_EPrimCall: {
    V v_p_2442 = heff_field(v_e_244, 0);
    V v_as_2443 = heff_field(v_e_244, 1);
    V v_ru_24e_244_24EPrimCall = heff_take_reuse_n(v_e_244, 3ULL, 2);
    V v_t_2444 = heff_tr(heff_apply(((V)&g_heff_2ecompile_2espec_2eselfTo_clo), 4, (V[]){v_g_240, v_h_241, v_pre_242, v_ds_243}));
    return heff_tag_at_n(v_ru_24e_244_24EPrimCall, TAG_EPrimCall, 2, (V[]){v_p_2442, (g_list_2emap(v_t_2444, v_as_2443))});
  }
  case TAG_ECall: {
    V v_k_2445 = heff_field(v_e_244, 0);
    V v_as_2446 = heff_field(v_e_244, 1);
    V v_ru_24e_244_24ECall = heff_take_reuse_n(v_e_244, 3ULL, 2);
    V v_t_2447 = heff_tr(heff_apply(((V)&g_heff_2ecompile_2espec_2eselfTo_clo), 4, (V[]){v_g_240, v_h_241, v_pre_242, v_ds_243}));
    return heff_tag_at_n(v_ru_24e_244_24ECall, TAG_ECall, 2, (V[]){v_k_2445, (g_list_2emap(v_t_2447, v_as_2446))});
  }
  case TAG_EInt: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_pre_242);
    heff_drop(v_ds_243);
    return v_e_244;
  }
  case TAG_EFloat: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_pre_242);
    heff_drop(v_ds_243);
    return v_e_244;
  }
  case TAG_EStr: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_pre_242);
    heff_drop(v_ds_243);
    return v_e_244;
  }
  case TAG_EFixed: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_pre_242);
    heff_drop(v_ds_243);
    return v_e_244;
  }
  case TAG_EFloat32: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_pre_242);
    heff_drop(v_ds_243);
    return v_e_244;
  }
  case TAG_EAbandon: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_pre_242);
    heff_drop(v_ds_243);
    return v_e_244;
  }
  case TAG_EFix: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_pre_242);
    heff_drop(v_ds_243);
    return v_e_244;
  }
  default: return heff_nomatch(v_e_244);
  }
}
V g_heff_2ecompile_2espec_2eselfTo_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2espec_2eselfTo(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ecompile_2espec_2eselfTo_lam0(V self, V *args) {
  V v_x2_2421 = args[0];
  V v_go_2420 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x2_2421)) {
  case TAG_MkPair: {
    V v_l_2422 = heff_field(v_x2_2421, 0);
    V v_v_2423 = heff_field(v_x2_2421, 1);
    V v_ru_24x2_2421_24MkPair = heff_take_reuse_n(v_x2_2421, 3ULL, 2);
    V v_t_2424 = heff_tr(heff_apply(v_go_2420, 1, (V[]){v_v_2423}));
    return heff_tag_at_n(v_ru_24x2_2421_24MkPair, TAG_MkPair, 2, (V[]){v_l_2422, v_t_2424});
  }
  default: return heff_nomatch(v_x2_2421);
  }
}
V g_heff_2ecompile_2espec_2eselfTo_lam1(V self, V *args) {
  V v_x2_2436 = args[0];
  V v_go_2435 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x2_2436)) {
  case TAG_MkArm: {
    V v_t_2437 = heff_field(v_x2_2436, 0);
    V v_vs_2438 = heff_field(v_x2_2436, 1);
    V v_b_2439 = heff_field(v_x2_2436, 2);
    V v_ru_24x2_2436_24MkArm = heff_take_reuse_n(v_x2_2436, 7ULL, 3);
    V v_t_2440 = heff_tr(heff_apply(v_go_2435, 1, (V[]){v_b_2439}));
    return heff_tag_at_n(v_ru_24x2_2436_24MkArm, TAG_MkArm, 3, (V[]){v_t_2437, v_vs_2438, v_t_2440});
  }
  default: return heff_nomatch(v_x2_2436);
  }
}