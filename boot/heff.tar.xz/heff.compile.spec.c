// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_CFalse 2759
#define TAG_CIf 14188
#define TAG_CNot 51573
#define TAG_CRel 55099
#define TAG_CTest 64009
#define TAG_CTrue 11023
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBool 8245
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_ESet 50124
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EValues 34965
#define TAG_EVar 52881
#define TAG_F32 16337
#define TAG_FtAny 18156
#define TAG_FtFixed 23584
#define TAG_FtFloat 38674
#define TAG_FtOther 63706
#define TAG_I16 19162
#define TAG_I32 19220
#define TAG_I64 19315
#define TAG_I8 9088
#define TAG_MkArm 55352
#define TAG_U16 30694
#define TAG_U32 30752
#define TAG_U64 30847
#define TAG_U8 9460
#define LBL_caps 9541544
#define LBL_holes 300818381
#define LBL_n 328
#define LBL_ren 322325
#define LBL_vars 10107635
static uint32_t shape_ren__caps__vars__holes__n[] = {LBL_ren, LBL_caps, LBL_vars, LBL_holes, LBL_n};
V g_heff_2ecompile_2eir_2econdMap(V, V);
V g_heff_2ecompile_2eir_2econdMap_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2econdMap_clo;
V g_heff_2ecompile_2eir_2econdOnto(V, V);
V g_heff_2ecompile_2eir_2econdOnto_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2econdOnto_clo;
V g_heff_2ecompile_2espec_2eallS(V, V);
V g_heff_2ecompile_2espec_2eallS_entry(V self, V *a);
extern Clo g_heff_2ecompile_2espec_2eallS_clo;
V g_heff_2ecompile_2espec_2eallS_24s513857012x1399359699(V);
V g_heff_2ecompile_2espec_2eallS_24s513857012x1399359699_entry(V self, V *a);
extern Clo g_heff_2ecompile_2espec_2eallS_24s513857012x1399359699_clo;
V g_heff_2ecompile_2espec_2eappendS(V, V);
V g_heff_2ecompile_2espec_2eappendS_entry(V self, V *a);
extern Clo g_heff_2ecompile_2espec_2eappendS_clo;
V g_heff_2ecompile_2espec_2eappendS_24dps(V, V, V);
V g_heff_2ecompile_2espec_2eappendS_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2espec_2eappendS_24dps_clo;
V g_heff_2ecompile_2espec_2eappendS_24tok2(V, V, V);
V g_heff_2ecompile_2espec_2eappendS_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2espec_2eappendS_24tok2_clo;
V g_heff_2ecompile_2espec_2ebindOne(V, V);
V g_heff_2ecompile_2espec_2ebindOne_entry(V self, V *a);
extern Clo g_heff_2ecompile_2espec_2ebindOne_clo;
V g_heff_2ecompile_2espec_2ecallUse(V, V, V);
V g_heff_2ecompile_2espec_2ecallUse_entry(V self, V *a);
extern Clo g_heff_2ecompile_2espec_2ecallUse_clo;
V g_heff_2ecompile_2espec_2ecallsNothing(V);
V g_heff_2ecompile_2espec_2ecallsNothing_entry(V self, V *a);
extern Clo g_heff_2ecompile_2espec_2ecallsNothing_clo;
V g_heff_2ecompile_2espec_2ecallsOnce(V);
V g_heff_2ecompile_2espec_2ecallsOnce_entry(V self, V *a);
extern Clo g_heff_2ecompile_2espec_2ecallsOnce_clo;
HeffT2 g_heff_2ecompile_2espec_2ecapOf_24cpr(V, V);
V g_heff_2ecompile_2espec_2eclosedIn(V, V);
V g_heff_2ecompile_2espec_2eclosedIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2espec_2eclosedIn_clo;
V g_heff_2ecompile_2espec_2econdKey(V, V);
V g_heff_2ecompile_2espec_2econdKey_entry(V self, V *a);
extern Clo g_heff_2ecompile_2espec_2econdKey_clo;
V g_heff_2ecompile_2espec_2edropAt(V, V);
V g_heff_2ecompile_2espec_2edropAt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2espec_2edropAt_clo;
V g_heff_2ecompile_2espec_2edropAt_24dps(V, V, V);
V g_heff_2ecompile_2espec_2edropAt_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2espec_2edropAt_24dps_clo;
V g_heff_2ecompile_2espec_2eelemS(V, V);
V g_heff_2ecompile_2espec_2eelemS_entry(V self, V *a);
extern Clo g_heff_2ecompile_2espec_2eelemS_clo;
V g_heff_2ecompile_2espec_2ehashGo(V, V, V, V);
V g_heff_2ecompile_2espec_2ehashGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2espec_2ehashGo_clo;
V g_heff_2ecompile_2espec_2eheadUses(V, V);
V g_heff_2ecompile_2espec_2eheadUses_entry(V self, V *a);
extern Clo g_heff_2ecompile_2espec_2eheadUses_clo;
V g_heff_2ecompile_2espec_2eisVarOf(V, V);
V g_heff_2ecompile_2espec_2eisVarOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2espec_2eisVarOf_clo;
V g_heff_2ecompile_2espec_2ekeyGo(V, V);
V g_heff_2ecompile_2espec_2ekeyGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2espec_2ekeyGo_clo;
V g_heff_2ecompile_2espec_2elabelsTo(V, V);
V g_heff_2ecompile_2espec_2elabelsTo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2espec_2elabelsTo_clo;
V g_heff_2ecompile_2espec_2elabelsTo_24dps(V, V, V);
V g_heff_2ecompile_2espec_2elabelsTo_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2espec_2elabelsTo_24dps_clo;
HeffT2 g_heff_2ecompile_2espec_2eletThen_24cpr(V, V, V, V);
V g_heff_2ecompile_2espec_2enthS(V, V);
V g_heff_2ecompile_2espec_2enthS_entry(V self, V *a);
extern Clo g_heff_2ecompile_2espec_2enthS_clo;
V g_heff_2ecompile_2espec_2eposGo(V, V, V);
V g_heff_2ecompile_2espec_2eposGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2espec_2eposGo_clo;
V g_heff_2ecompile_2espec_2eselfArgs(V, V, V, V, V);
V g_heff_2ecompile_2espec_2eselfArgs_entry(V self, V *a);
extern Clo g_heff_2ecompile_2espec_2eselfArgs_clo;
V g_heff_2ecompile_2espec_2eselfHead(V, V, V, V);
V g_heff_2ecompile_2espec_2eselfHead_entry(V self, V *a);
extern Clo g_heff_2ecompile_2espec_2eselfHead_clo;
V g_heff_2ecompile_2espec_2eselfTo(V, V, V, V, V);
V g_heff_2ecompile_2espec_2eselfTo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2espec_2eselfTo_clo;
V g_heff_2ecompile_2espec_2eselfTo_24dps(V, V, V, V, V, V, V);
V g_heff_2ecompile_2espec_2eselfTo_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2espec_2eselfTo_24dps_clo;
HeffT2 g_heff_2ecompile_2espec_2esetThen_24cpr(V, V, V, V);
V g_heff_2ecompile_2espec_2eshapeArms(V, V, V);
V g_heff_2ecompile_2espec_2eshapeArms_entry(V self, V *a);
extern Clo g_heff_2ecompile_2espec_2eshapeArms_clo;
HeffT2 g_heff_2ecompile_2espec_2eshapeArms_24cpr(V, V, V);
HeffT2 g_heff_2ecompile_2espec_2eshapeCond_24cpr(V, V, V);
V g_heff_2ecompile_2espec_2eshapeGo(V, V);
V g_heff_2ecompile_2espec_2eshapeGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2espec_2eshapeGo_clo;
HeffT2 g_heff_2ecompile_2espec_2eshapeGo_24cpr(V, V);
V g_heff_2ecompile_2espec_2eshapeMany(V, V, V);
V g_heff_2ecompile_2espec_2eshapeMany_entry(V self, V *a);
extern Clo g_heff_2ecompile_2espec_2eshapeMany_clo;
HeffT2 g_heff_2ecompile_2espec_2eshapeMany_24cpr(V, V, V);
V g_heff_2ecompile_2espec_2estaticGo(V, V, V);
V g_heff_2ecompile_2espec_2estaticGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2espec_2estaticGo_clo;
V g_heff_2ecompile_2espec_2estaticGo_24dps(V, V, V, V);
V g_heff_2ecompile_2espec_2estaticGo_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2espec_2estaticGo_24dps_clo;
V g_heff_2ecompile_2espec_2eusesOf(V, V);
V g_heff_2ecompile_2espec_2eusesOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2espec_2eusesOf_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24f1645967390x252727070(V, V);
V g_list_2efoldl_24f1645967390x252727070_entry(V self, V *a);
extern Clo g_list_2efoldl_24f1645967390x252727070_clo;
V g_list_2efoldl_24f836170601x1639498774(V, V);
V g_list_2efoldl_24f836170601x1639498774_entry(V self, V *a);
extern Clo g_list_2efoldl_24f836170601x1639498774_clo;
V g_list_2efoldl_24s1048046132x95752937(V, V);
V g_list_2efoldl_24s1048046132x95752937_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1048046132x95752937_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1173914895x100384474(V);
V g_list_2emap_24s1173914895x100384474_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_clo;
V g_list_2emap_24s1173914895x100384474_24tok2(V, V);
V g_list_2emap_24s1173914895x100384474_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_24tok2_clo;
V g_list_2emap_24s143096761x246530315(V);
V g_list_2emap_24s143096761x246530315_entry(V self, V *a);
extern Clo g_list_2emap_24s143096761x246530315_clo;
V g_list_2emap_24s60612435x257154841(V);
V g_list_2emap_24s60612435x257154841_entry(V self, V *a);
extern Clo g_list_2emap_24s60612435x257154841_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_std_2emap_2einsert_24s93785294x875597928(V, V, V);
V g_std_2emap_2einsert_24s93785294x875597928_entry(V self, V *a);
extern Clo g_std_2emap_2einsert_24s93785294x875597928_clo;
HeffT2 g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(V, V);
Clo g_heff_2ecompile_2espec_2eelemS_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2espec_2eelemS_entry, 2, 0};

V g_heff_2ecompile_2espec_2eelemS(V v_x_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    return NTAG(TAG_False);
  }
  case TAG_Cons: {
    V v_y_242 = heff_field(v_x2_241, 0);
    V v_ys_243 = heff_field(v_x2_241, 1);
    if (heff_strEq_c_lent(v_x_240, v_y_242, 0)) {
      return NTAG(TAG_True);
    } else {
      V t_0 = v_x_240;
      V t_1 = v_ys_243;
      v_x_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2espec_2eelemS_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2espec_2eelemS(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2espec_2eappendS_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2espec_2eappendS_entry, 2, 0};

V g_heff_2ecompile_2espec_2eappendS(V v_x1_240, V v_ys_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return v_ys_241;
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_xs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_cell_244 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_242, heff_hole()});
    V v_u_245 = (g_heff_2ecompile_2espec_2eappendS_24dps(v_xs_243, v_ys_241, heff_dup(v_cell_244)));
    heff_drop(v_u_245);
    return v_cell_244;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2espec_2eappendS_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2espec_2eappendS(a[0], a[1]);
}
Clo g_heff_2ecompile_2espec_2eappendS_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2espec_2eappendS_24dps_entry, 3, 0};

V g_heff_2ecompile_2espec_2eappendS_24dps(V v_x1_240, V v_ys_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_242, MK_INT(1LL), v_ys_241);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x1_240, 0);
    V v_xs_244 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_cell_245 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
    V v_u_246 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_245));
    heff_drop(v_u_246);
    V t_0 = v_xs_244;
    V t_1 = v_ys_241;
    V t_2 = v_cell_245;
    v_x1_240 = t_0;
    v_ys_241 = t_1;
    v_d_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2espec_2eappendS_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2espec_2eappendS_24dps(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2espec_2eallS_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2espec_2eallS_entry, 2, 0};

V g_heff_2ecompile_2espec_2eallS(V v_p_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_p_240);
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    V v_t_244 = heff_tr(heff_call(heff_dup(v_p_240), 1, (V[]){heff_dup(v_x_242)}));
    if ((heff_dup(v_t_244) == NTAG(TAG_True))) {
      heff_drop(v_t_244);
      V t_0 = v_p_240;
      V t_1 = v_xs_243;
      v_p_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    } else {
      heff_drop(v_p_240);
      heff_drop(v_t_244);
      return NTAG(TAG_False);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2espec_2eallS_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2espec_2eallS(a[0], a1); heff_drop(a1); return r;
}
V g_heff_2ecompile_2espec_2eclosedIn_lam0(V self, V *args);
Clo g_heff_2ecompile_2espec_2eclosedIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2espec_2eclosedIn_entry, 2, 0};

V g_heff_2ecompile_2espec_2eclosedIn(V v_env_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_EVar: {
    V v_x_242 = heff_field(v_x2_241, 0);
    return ({ V a_0 = v_x_242; V a_1 = v_env_240; V r_ = (g_heff_2ecompile_2espec_2eelemS(a_0, a_1)); heff_drop(v_env_240); r_; });
  }
  case TAG_EGlobal: {
    heff_drop(v_env_240);
    return NTAG(TAG_True);
  }
  case TAG_ELam: {
    V v_xs_244 = heff_field(v_x2_241, 0);
    V v_b_245 = heff_field(v_x2_241, 1);
    V v_t_246 = (g_heff_2ecompile_2espec_2eappendS(heff_dup(v_xs_244), v_env_240));
    V t_0 = v_t_246;
    V t_1 = v_b_245;
    v_env_240 = t_0;
    v_x2_241 = t_1;
    goto top;
  }
  case TAG_EApp: {
    V v_f_247 = heff_field(v_x2_241, 0);
    V v_args_248 = heff_field(v_x2_241, 1);
    V v_t_249 = (g_heff_2ecompile_2espec_2eclosedIn(heff_dup(v_env_240), v_f_247));
    if ((heff_dup(v_t_249) == NTAG(TAG_True))) {
      heff_drop(v_t_249);
      V v_t_2410 = heff_tr(heff_call(((V)&g_heff_2ecompile_2espec_2eclosedIn_clo), 1, (V[]){v_env_240}));
      HEFF_LAST return g_heff_2ecompile_2espec_2eallS(v_t_2410, v_args_248);
    } else {
      heff_drop(v_env_240);
      heff_drop(v_t_249);
      return NTAG(TAG_False);
    }
  }
  case TAG_ELet: {
    V v_x_2411 = heff_field(v_x2_241, 0);
    V v_a_2412 = heff_field(v_x2_241, 1);
    V v_b_2413 = heff_field(v_x2_241, 2);
    V v_t_2414 = (g_heff_2ecompile_2espec_2eclosedIn(heff_dup(v_env_240), v_a_2412));
    if ((heff_dup(v_t_2414) == NTAG(TAG_True))) {
      heff_drop(v_t_2414);
      V t_0 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_x_2411), v_env_240});
      V t_1 = v_b_2413;
      v_env_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    } else {
      heff_drop(v_env_240);
      heff_drop(v_t_2414);
      return NTAG(TAG_False);
    }
  }
  case TAG_ERecord: {
    V v_fs_2415 = heff_field(v_x2_241, 0);
    V v_t_2417 = heff_tr(heff_call(((V)&g_heff_2ecompile_2espec_2eclosedIn_clo), 1, (V[]){v_env_240}));
    V v_t_2418 = (g_list_2emap_24s1173914895x100384474(heff_dup(v_fs_2415)));
    return ({ V a_0 = v_t_2417; V a_1 = v_t_2418; V r_ = (g_heff_2ecompile_2espec_2eallS(a_0, a_1)); heff_drop(v_t_2418); r_; });
  }
  case TAG_EProj: {
    V v_e_2419 = heff_field(v_x2_241, 0);
    V t_0 = v_env_240;
    V t_1 = v_e_2419;
    v_env_240 = t_0;
    v_x2_241 = t_1;
    goto top;
  }
  case TAG_ETag: {
    V v_args_2424 = heff_field(v_x2_241, 1);
    V v_t_2426 = heff_tr(heff_call(((V)&g_heff_2ecompile_2espec_2eclosedIn_clo), 1, (V[]){v_env_240}));
    HEFF_LAST return g_heff_2ecompile_2espec_2eallS(v_t_2426, v_args_2424);
  }
  case TAG_EMatch: {
    V v_s_2427 = heff_field(v_x2_241, 0);
    V v_arms_2428 = heff_field(v_x2_241, 1);
    V v_t_2429 = (g_heff_2ecompile_2espec_2eclosedIn(heff_dup(v_env_240), v_s_2427));
    if ((heff_dup(v_t_2429) == NTAG(TAG_True))) {
      heff_drop(v_t_2429);
      HEFF_LAST return g_heff_2ecompile_2espec_2eallS(heff_clo_n(g_heff_2ecompile_2espec_2eclosedIn_lam0, 1, 1, (V[]){v_env_240}), v_arms_2428);
    } else {
      heff_drop(v_env_240);
      heff_drop(v_t_2429);
      return NTAG(TAG_False);
    }
  }
  case TAG_EPrim: {
    heff_drop(v_env_240);
    return NTAG(TAG_True);
  }
  case TAG_EPrimCall: {
    V v_args_2437 = heff_field(v_x2_241, 1);
    V v_t_2438 = heff_tr(heff_call(((V)&g_heff_2ecompile_2espec_2eclosedIn_clo), 1, (V[]){v_env_240}));
    HEFF_LAST return g_heff_2ecompile_2espec_2eallS(v_t_2438, v_args_2437);
  }
  case TAG_ECall: {
    V v_args_2440 = heff_field(v_x2_241, 1);
    V v_t_2441 = heff_tr(heff_call(((V)&g_heff_2ecompile_2espec_2eclosedIn_clo), 1, (V[]){v_env_240}));
    HEFF_LAST return g_heff_2ecompile_2espec_2eallS(v_t_2441, v_args_2440);
  }
  case TAG_EInt: {
    heff_drop(v_env_240);
    return NTAG(TAG_True);
  }
  case TAG_EFloat: {
    heff_drop(v_env_240);
    return NTAG(TAG_True);
  }
  case TAG_EStr: {
    heff_drop(v_env_240);
    return NTAG(TAG_True);
  }
  case TAG_EBytes: {
    heff_drop(v_env_240);
    return NTAG(TAG_True);
  }
  case TAG_EFixed: {
    heff_drop(v_env_240);
    return NTAG(TAG_True);
  }
  case TAG_EFloat32: {
    heff_drop(v_env_240);
    return NTAG(TAG_True);
  }
  case TAG_EAbandon: {
    heff_drop(v_env_240);
    return NTAG(TAG_True);
  }
  case TAG_EBool: {
    V v_c_2449 = heff_field(v_x2_241, 0);
    V v_t_2450 = heff_tr(heff_call(((V)&g_heff_2ecompile_2espec_2eclosedIn_clo), 1, (V[]){v_env_240}));
    V v_t_2451 = (g_heff_2ecompile_2eir_2econdOnto(v_c_2449, NTAG(TAG_Nil)));
    return ({ V a_0 = v_t_2450; V a_1 = v_t_2451; V r_ = (g_heff_2ecompile_2espec_2eallS(a_0, a_1)); heff_drop(v_t_2451); r_; });
  }
  case TAG_ESet: {
    V v_xs_2452 = heff_field(v_x2_241, 0);
    V v_a_2453 = heff_field(v_x2_241, 1);
    V v_b_2454 = heff_field(v_x2_241, 2);
    V v_t_2455 = (g_heff_2ecompile_2espec_2eclosedIn(heff_dup(v_env_240), v_a_2453));
    if ((heff_dup(v_t_2455) == NTAG(TAG_True))) {
      heff_drop(v_t_2455);
      V v_t_2456 = (g_heff_2ecompile_2espec_2eappendS(heff_dup(v_xs_2452), v_env_240));
      V t_0 = v_t_2456;
      V t_1 = v_b_2454;
      v_env_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    } else {
      heff_drop(v_env_240);
      heff_drop(v_t_2455);
      return NTAG(TAG_False);
    }
  }
  case TAG_EValues: {
    V v_es_2457 = heff_field(v_x2_241, 0);
    V v_t_2458 = heff_tr(heff_call(((V)&g_heff_2ecompile_2espec_2eclosedIn_clo), 1, (V[]){v_env_240}));
    HEFF_LAST return g_heff_2ecompile_2espec_2eallS(v_t_2458, v_es_2457);
  }
  case TAG_EFix: {
    heff_drop(v_env_240);
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2espec_2eclosedIn_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2espec_2eclosedIn(a[0], a1); heff_drop(a1); return r;
}
V g_heff_2ecompile_2espec_2eclosedIn_lam0(V self, V *args) {
  V v_x3_2430 = args[0];
  V v_env_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x3_2430)) {
  case TAG_MkArm: {
    V v_vs_2432 = heff_field(v_x3_2430, 1);
    V v_b_2433 = heff_field(v_x3_2430, 2);
    heff_take_n(v_x3_2430, 6ULL, 3);
    V v_t_2434 = (g_heff_2ecompile_2espec_2eappendS(v_vs_2432, v_env_240));
    return ({ V a_0 = v_t_2434; V a_1 = v_b_2433; V r_ = (g_heff_2ecompile_2espec_2eclosedIn(a_0, a_1)); heff_drop(v_b_2433); r_; });
  }
  default: return heff_nomatch(v_x3_2430);
  }
}
Clo g_heff_2ecompile_2espec_2ecallsNothing_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2espec_2ecallsNothing_entry, 1, 0};

V g_heff_2ecompile_2espec_2ecallsNothing(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_EVar: {
    return NTAG(TAG_True);
  }
  case TAG_EGlobal: {
    return NTAG(TAG_True);
  }
  case TAG_ELam: {
    V v_b_244 = heff_field(v_x1_240, 1);
    V t_0 = v_b_244;
    v_x1_240 = t_0;
    goto top;
  }
  case TAG_EApp: {
    return NTAG(TAG_False);
  }
  case TAG_ELet: {
    V v_a_248 = heff_field(v_x1_240, 1);
    V v_b_249 = heff_field(v_x1_240, 2);
    V v_t_2410 = (g_heff_2ecompile_2espec_2ecallsNothing(v_a_248));
    if ((heff_dup(v_t_2410) == NTAG(TAG_True))) {
      heff_drop(v_t_2410);
      V t_0 = v_b_249;
      v_x1_240 = t_0;
      goto top;
    } else {
      heff_drop(v_t_2410);
      return NTAG(TAG_False);
    }
  }
  case TAG_ERecord: {
    V v_fs_2411 = heff_field(v_x1_240, 0);
    V v_t_2413 = (g_list_2emap_24s1173914895x100384474(heff_dup(v_fs_2411)));
    return ({ V a_0 = ((V)&g_heff_2ecompile_2espec_2ecallsNothing_clo); V a_1 = v_t_2413; V r_ = (g_heff_2ecompile_2espec_2eallS(a_0, a_1)); heff_drop(v_t_2413); r_; });
  }
  case TAG_EProj: {
    V v_e_2414 = heff_field(v_x1_240, 0);
    V t_0 = v_e_2414;
    v_x1_240 = t_0;
    goto top;
  }
  case TAG_ETag: {
    V v_args_2419 = heff_field(v_x1_240, 1);
    return (g_heff_2ecompile_2espec_2eallS(((V)&g_heff_2ecompile_2espec_2ecallsNothing_clo), v_args_2419));
  }
  case TAG_EMatch: {
    V v_s_2421 = heff_field(v_x1_240, 0);
    V v_arms_2422 = heff_field(v_x1_240, 1);
    V v_t_2423 = (g_heff_2ecompile_2espec_2ecallsNothing(v_s_2421));
    if ((heff_dup(v_t_2423) == NTAG(TAG_True))) {
      heff_drop(v_t_2423);
      V v_t_2424 = (g_list_2emap_24s60612435x257154841(heff_dup(v_arms_2422)));
      return ({ V a_0 = ((V)&g_heff_2ecompile_2espec_2ecallsNothing_clo); V a_1 = v_t_2424; V r_ = (g_heff_2ecompile_2espec_2eallS(a_0, a_1)); heff_drop(v_t_2424); r_; });
    } else {
      heff_drop(v_t_2423);
      return NTAG(TAG_False);
    }
  }
  case TAG_EPrim: {
    return NTAG(TAG_True);
  }
  case TAG_EPrimCall: {
    V v_args_2427 = heff_field(v_x1_240, 1);
    return (g_heff_2ecompile_2espec_2eallS(((V)&g_heff_2ecompile_2espec_2ecallsNothing_clo), v_args_2427));
  }
  case TAG_ECall: {
    return NTAG(TAG_False);
  }
  case TAG_EInt: {
    return NTAG(TAG_True);
  }
  case TAG_EFloat: {
    return NTAG(TAG_True);
  }
  case TAG_EStr: {
    return NTAG(TAG_True);
  }
  case TAG_EBytes: {
    return NTAG(TAG_True);
  }
  case TAG_EFixed: {
    return NTAG(TAG_True);
  }
  case TAG_EFloat32: {
    return NTAG(TAG_True);
  }
  case TAG_EAbandon: {
    return NTAG(TAG_True);
  }
  case TAG_EBool: {
    V v_c_2437 = heff_field(v_x1_240, 0);
    V v_t_2438 = (g_heff_2ecompile_2eir_2econdOnto(v_c_2437, NTAG(TAG_Nil)));
    return ({ V a_0 = ((V)&g_heff_2ecompile_2espec_2ecallsNothing_clo); V a_1 = v_t_2438; V r_ = (g_heff_2ecompile_2espec_2eallS(a_0, a_1)); heff_drop(v_t_2438); r_; });
  }
  case TAG_ESet: {
    V v_a_2440 = heff_field(v_x1_240, 1);
    V v_b_2441 = heff_field(v_x1_240, 2);
    V v_t_2442 = (g_heff_2ecompile_2espec_2ecallsNothing(v_a_2440));
    if ((heff_dup(v_t_2442) == NTAG(TAG_True))) {
      heff_drop(v_t_2442);
      V t_0 = v_b_2441;
      v_x1_240 = t_0;
      goto top;
    } else {
      heff_drop(v_t_2442);
      return NTAG(TAG_False);
    }
  }
  case TAG_EValues: {
    V v_es_2443 = heff_field(v_x1_240, 0);
    return (g_heff_2ecompile_2espec_2eallS(((V)&g_heff_2ecompile_2espec_2ecallsNothing_clo), v_es_2443));
  }
  case TAG_EFix: {
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2espec_2ecallsNothing_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2espec_2ecallsNothing(a0); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2espec_2eallS_24s513857012x1399359699_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2espec_2eallS_24s513857012x1399359699_entry, 1, 0};

V g_heff_2ecompile_2espec_2eallS_24s513857012x1399359699(V v_x2_240) {
top: ;
  switch (heff_tag_of(v_x2_240)) {
  case TAG_Nil: {
    return NTAG(TAG_True);
  }
  case TAG_Cons: {
    V v_x_241 = heff_field(v_x2_240, 0);
    V v_xs_242 = heff_field(v_x2_240, 1);
    V v_t_243 = (g_heff_2ecompile_2espec_2ecallsNothing(v_x_241));
    if ((heff_dup(v_t_243) == NTAG(TAG_True))) {
      heff_drop(v_t_243);
      V t_0 = v_xs_242;
      v_x2_240 = t_0;
      goto top;
    } else {
      heff_drop(v_t_243);
      return NTAG(TAG_False);
    }
  }
  default: return heff_nomatch(v_x2_240);
  }
}
V g_heff_2ecompile_2espec_2eallS_24s513857012x1399359699_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2espec_2eallS_24s513857012x1399359699(a0); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2espec_2ecallsOnce_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2espec_2ecallsOnce_entry, 1, 0};

V g_heff_2ecompile_2espec_2ecallsOnce(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_EVar: {
    return NTAG(TAG_False);
  }
  case TAG_EGlobal: {
    return NTAG(TAG_False);
  }
  case TAG_ELam: {
    V v_b_244 = heff_field(v_x1_240, 1);
    V t_0 = v_b_244;
    v_x1_240 = t_0;
    goto top;
  }
  case TAG_EApp: {
    V v_x11_245 = heff_field(v_x1_240, 0);
    V v_args_246 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x11_245)) {
    case TAG_EVar: {
      return NTAG(TAG_False);
    }
    case TAG_EGlobal: {
      HEFF_LAST return g_heff_2ecompile_2espec_2eallS_24s513857012x1399359699(v_args_246);
    }
    case TAG_ELam: {
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      return NTAG(TAG_False);
    }
    case TAG_EPrimCall: {
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      return NTAG(TAG_False);
    }
    case TAG_EFloat: {
      return NTAG(TAG_False);
    }
    case TAG_EStr: {
      return NTAG(TAG_False);
    }
    case TAG_EBytes: {
      return NTAG(TAG_False);
    }
    case TAG_EFixed: {
      return NTAG(TAG_False);
    }
    case TAG_EFloat32: {
      return NTAG(TAG_False);
    }
    case TAG_EAbandon: {
      return NTAG(TAG_False);
    }
    case TAG_EBool: {
      return NTAG(TAG_False);
    }
    case TAG_ESet: {
      return NTAG(TAG_False);
    }
    case TAG_EValues: {
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x11_245);
    }
  }
  case TAG_ELet: {
    return NTAG(TAG_False);
  }
  case TAG_ERecord: {
    return NTAG(TAG_False);
  }
  case TAG_EProj: {
    return NTAG(TAG_False);
  }
  case TAG_ETag: {
    return NTAG(TAG_False);
  }
  case TAG_EMatch: {
    return NTAG(TAG_False);
  }
  case TAG_EPrim: {
    return NTAG(TAG_False);
  }
  case TAG_EPrimCall: {
    return NTAG(TAG_False);
  }
  case TAG_ECall: {
    return NTAG(TAG_False);
  }
  case TAG_EInt: {
    return NTAG(TAG_False);
  }
  case TAG_EFloat: {
    return NTAG(TAG_False);
  }
  case TAG_EStr: {
    return NTAG(TAG_False);
  }
  case TAG_EBytes: {
    return NTAG(TAG_False);
  }
  case TAG_EFixed: {
    return NTAG(TAG_False);
  }
  case TAG_EFloat32: {
    return NTAG(TAG_False);
  }
  case TAG_EAbandon: {
    return NTAG(TAG_False);
  }
  case TAG_EBool: {
    return NTAG(TAG_False);
  }
  case TAG_ESet: {
    return NTAG(TAG_False);
  }
  case TAG_EValues: {
    return NTAG(TAG_False);
  }
  case TAG_EFix: {
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2espec_2ecallsOnce_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2espec_2ecallsOnce(a0); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2espec_2eposGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2espec_2eposGo_entry, 3, 0};

V g_heff_2ecompile_2espec_2eposGo(V v_x_240, V v_x2_241, V v_i_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_i_242);
    return MK_INT(-1LL);
  }
  case TAG_Cons: {
    V v_y_243 = heff_field(v_x2_241, 0);
    V v_ys_244 = heff_field(v_x2_241, 1);
    if (heff_strEq_c_lent(v_x_240, v_y_243, 0)) {
      return v_i_242;
    } else {
      V t_0 = v_x_240;
      V t_1 = v_ys_244;
      V t_2 = heff_intAdd(v_i_242, MK_INT(1LL));
      v_x_240 = t_0;
      v_x2_241 = t_1;
      v_i_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2espec_2eposGo_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2espec_2eposGo(a0, a1, a[2]); heff_drop(a0); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ecompile_2espec_2econdKey_str0, 1, "T");
HEFF_LIT(g_heff_2ecompile_2espec_2econdKey_str1, 1, "F");
HEFF_LIT(g_heff_2ecompile_2espec_2econdKey_str2, 1, ",");
HEFF_LIT(g_heff_2ecompile_2espec_2econdKey_str3, 1, ")");
HEFF_LIT(g_heff_2ecompile_2espec_2econdKey_str4, 1, "(");
HEFF_LIT(g_heff_2ecompile_2espec_2econdKey_str5, 1, "R");
HEFF_LIT(g_heff_2ecompile_2espec_2econdKey_str6, 2, "S(");
HEFF_LIT(g_heff_2ecompile_2espec_2econdKey_str7, 1, ")");
HEFF_LIT(g_heff_2ecompile_2espec_2econdKey_str8, 2, "N(");
HEFF_LIT(g_heff_2ecompile_2espec_2econdKey_str9, 1, ")");
HEFF_LIT(g_heff_2ecompile_2espec_2econdKey_str10, 1, ",");
HEFF_LIT(g_heff_2ecompile_2espec_2econdKey_str11, 1, ")");
HEFF_LIT(g_heff_2ecompile_2espec_2econdKey_str12, 1, ",");
HEFF_LIT(g_heff_2ecompile_2espec_2econdKey_str13, 2, "I(");
Clo g_heff_2ecompile_2espec_2econdKey_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2espec_2econdKey_entry, 2, 0};

V g_heff_2ecompile_2espec_2econdKey(V v_go_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_CTrue: {
    heff_drop(v_go_240);
    return ((V)&g_heff_2ecompile_2espec_2econdKey_str0);
  }
  case TAG_CFalse: {
    heff_drop(v_go_240);
    return ((V)&g_heff_2ecompile_2espec_2econdKey_str1);
  }
  case TAG_CRel: {
    V v_p_242 = heff_field(v_x2_241, 0);
    V v_a_243 = heff_field(v_x2_241, 1);
    V v_b_244 = heff_field(v_x2_241, 2);
    V v_t_245 = heff_tr(heff_call(heff_dup(v_go_240), 1, (V[]){heff_dup(v_a_243)}));
    V v_t_246 = heff_tr(heff_call(v_go_240, 1, (V[]){heff_dup(v_b_244)}));
    V v_t_247 = heff_strAppend(((V)&g_heff_2ecompile_2espec_2econdKey_str2), heff_strAppend(v_t_246, ((V)&g_heff_2ecompile_2espec_2econdKey_str3)));
    V v_t_248 = heff_strAppend(((V)&g_heff_2ecompile_2espec_2econdKey_str4), heff_strAppend(v_t_245, v_t_247));
    return heff_strAppend(((V)&g_heff_2ecompile_2espec_2econdKey_str5), heff_strAppend(heff_dup(v_p_242), v_t_248));
  }
  case TAG_CTest: {
    V v_e_249 = heff_field(v_x2_241, 0);
    V v_t_2410 = heff_tr(heff_call(v_go_240, 1, (V[]){heff_dup(v_e_249)}));
    return heff_strAppend(((V)&g_heff_2ecompile_2espec_2econdKey_str6), heff_strAppend(v_t_2410, ((V)&g_heff_2ecompile_2espec_2econdKey_str7)));
  }
  case TAG_CNot: {
    V v_c_2411 = heff_field(v_x2_241, 0);
    V v_t_2412 = (g_heff_2ecompile_2espec_2econdKey(v_go_240, v_c_2411));
    return heff_strAppend(((V)&g_heff_2ecompile_2espec_2econdKey_str8), heff_strAppend(v_t_2412, ((V)&g_heff_2ecompile_2espec_2econdKey_str9)));
  }
  case TAG_CIf: {
    V v_a_2413 = heff_field(v_x2_241, 0);
    V v_b_2414 = heff_field(v_x2_241, 1);
    V v_c_2415 = heff_field(v_x2_241, 2);
    V v_t_2416 = (g_heff_2ecompile_2espec_2econdKey(heff_dup(v_go_240), v_a_2413));
    V v_t_2417 = (g_heff_2ecompile_2espec_2econdKey(heff_dup(v_go_240), v_b_2414));
    V v_t_2418 = (g_heff_2ecompile_2espec_2econdKey(v_go_240, v_c_2415));
    V v_t_2419 = heff_strAppend(((V)&g_heff_2ecompile_2espec_2econdKey_str10), heff_strAppend(v_t_2418, ((V)&g_heff_2ecompile_2espec_2econdKey_str11)));
    V v_t_2420 = heff_strAppend(((V)&g_heff_2ecompile_2espec_2econdKey_str12), heff_strAppend(v_t_2417, v_t_2419));
    return heff_strAppend(((V)&g_heff_2ecompile_2espec_2econdKey_str13), heff_strAppend(v_t_2416, v_t_2420));
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2espec_2econdKey_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2espec_2econdKey(a[0], a1); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str0, 1, "v");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str1, 1, "g");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str2, 1, ";");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str3, 1, "(");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str4, 1, ")");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str5, 1, "L");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str6, 0, "");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str7, 1, ",");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str8, 1, ":");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str9, 1, ")");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str10, 2, "A(");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str11, 1, ":");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str12, 1, ")");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str13, 2, "T(");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str14, 1, "=");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str15, 0, "");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str16, 1, ",");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str17, 0, "");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str18, 1, ",");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str19, 1, ":");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str20, 1, ")");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str21, 2, "R(");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str22, 0, "");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str23, 1, ",");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str24, 7, "Float64");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str25, 4, "Int8");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str26, 5, "Int16");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str27, 5, "Int32");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str28, 5, "Int64");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str29, 5, "UInt8");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str30, 6, "UInt16");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str31, 6, "UInt32");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str32, 6, "UInt64");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str33, 7, "Float32");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str34, 1, "_");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str35, 1, "\?");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str36, 1, ":");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str37, 1, ")");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str38, 1, "/");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str39, 1, ".");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str40, 2, "P(");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str41, 0, "");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str42, 1, ",");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str43, 1, "(");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str44, 1, ")");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str45, 1, "C");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str46, 1, ":");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str47, 1, "|");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str48, 0, "");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str49, 0, "");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str50, 1, ")");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str51, 2, "M(");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str52, 1, "p");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str53, 1, ";");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str54, 0, "");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str55, 1, ",");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str56, 1, "(");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str57, 1, ")");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str58, 1, "Q");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str59, 0, "");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str60, 1, ",");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str61, 1, "(");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str62, 1, ")");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str63, 1, "K");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str64, 1, "i");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str65, 1, "f");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str66, 1, ":");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str67, 1, "s");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str68, 1, ":");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str69, 1, "b");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str70, 2, "I8");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str71, 3, "I16");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str72, 3, "I32");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str73, 3, "I64");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str74, 2, "U8");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str75, 3, "U16");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str76, 3, "U32");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str77, 3, "U64");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str78, 3, "F32");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str79, 1, ":");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str80, 1, "x");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str81, 1, "y");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str82, 1, "X");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str83, 2, "o(");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str84, 1, ")");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str85, 1, ":");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str86, 1, ")");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str87, 1, "(");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str88, 1, "E");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str89, 0, "");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str90, 1, ",");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str91, 2, "W(");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str92, 1, ")");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str93, 1, "F");
V g_heff_2ecompile_2espec_2ekeyGo_lam0(V self, V *args);
V g_heff_2ecompile_2espec_2ekeyGo_lam1(V self, V *args);
Clo g_heff_2ecompile_2espec_2ekeyGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2espec_2ekeyGo_entry, 2, 0};

V g_heff_2ecompile_2espec_2ekeyGo(V v_env_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_EVar: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_t_243 = ({ V a_0 = v_x_242; V a_1 = v_env_240; V a_2 = MK_INT(0LL); V r_ = (g_heff_2ecompile_2espec_2eposGo(a_0, a_1, a_2)); heff_drop(v_env_240); r_; });
    return heff_strAppend(((V)&g_heff_2ecompile_2espec_2ekeyGo_str0), heff_intShow(v_t_243));
  }
  case TAG_EGlobal: {
    V v_g_244 = heff_field(v_x2_241, 0);
    heff_drop(v_env_240);
    return heff_strAppend(((V)&g_heff_2ecompile_2espec_2ekeyGo_str1), heff_strAppend(heff_dup(v_g_244), ((V)&g_heff_2ecompile_2espec_2ekeyGo_str2)));
  }
  case TAG_ELam: {
    V v_xs_245 = heff_field(v_x2_241, 0);
    V v_b_246 = heff_field(v_x2_241, 1);
    V v_t_247 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_245));
    V v_t_248 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_xs_245)));
    V v_t_249 = (g_heff_2ecompile_2espec_2eappendS(v_t_248, v_env_240));
    V v_t_2410 = (g_heff_2ecompile_2espec_2ekeyGo(v_t_249, v_b_246));
    V v_t_2411 = heff_strAppend(((V)&g_heff_2ecompile_2espec_2ekeyGo_str3), heff_strAppend(v_t_2410, ((V)&g_heff_2ecompile_2espec_2ekeyGo_str4)));
    V v_t_2412 = heff_strAppend(heff_intShow(v_t_247), v_t_2411);
    return heff_strAppend(((V)&g_heff_2ecompile_2espec_2ekeyGo_str5), v_t_2412);
  }
  case TAG_EApp: {
    V v_f_2413 = heff_field(v_x2_241, 0);
    V v_args_2414 = heff_field(v_x2_241, 1);
    V v_t_2415 = (g_heff_2ecompile_2espec_2ekeyGo(heff_dup(v_env_240), v_f_2413));
    V v_go_2416 = heff_tr(heff_call(((V)&g_heff_2ecompile_2espec_2ekeyGo_clo), 1, (V[]){v_env_240}));
    V v_x2_2417 = (g_list_2emap(v_go_2416, heff_dup(v_args_2414)));
    V v_t_2420;
    switch (heff_tag_of(v_x2_2417)) {
    case TAG_Nil: {
      v_t_2420 = ((V)&g_heff_2ecompile_2espec_2ekeyGo_str6);
      break;
    }
    case TAG_Cons: {
      V v_x_2418 = heff_field(v_x2_2417, 0);
      V v_xs_2419 = heff_field(v_x2_2417, 1);
      heff_take_n(v_x2_2417, 3ULL, 2);
      v_t_2420 = ({ V a_0 = ((V)&g_heff_2ecompile_2espec_2ekeyGo_str7); V a_1 = v_x_2418; V a_2 = v_xs_2419; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2419); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2417);
    }
    V v_t_2421 = heff_strAppend(((V)&g_heff_2ecompile_2espec_2ekeyGo_str8), heff_strAppend(v_t_2420, ((V)&g_heff_2ecompile_2espec_2ekeyGo_str9)));
    return heff_strAppend(((V)&g_heff_2ecompile_2espec_2ekeyGo_str10), heff_strAppend(v_t_2415, v_t_2421));
  }
  case TAG_ELet: {
    V v_x_2422 = heff_field(v_x2_241, 0);
    V v_a_2423 = heff_field(v_x2_241, 1);
    V v_b_2424 = heff_field(v_x2_241, 2);
    V v_t_2425 = (g_heff_2ecompile_2espec_2ekeyGo(heff_dup(v_env_240), v_a_2423));
    V v_t_2426 = (g_heff_2ecompile_2espec_2ekeyGo(heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_x_2422), v_env_240}), v_b_2424));
    V v_t_2427 = heff_strAppend(((V)&g_heff_2ecompile_2espec_2ekeyGo_str11), heff_strAppend(v_t_2426, ((V)&g_heff_2ecompile_2espec_2ekeyGo_str12)));
    return heff_strAppend(((V)&g_heff_2ecompile_2espec_2ekeyGo_str13), heff_strAppend(v_t_2425, v_t_2427));
  }
  case TAG_ERecord: {
    V v_fs_2428 = heff_field(v_x2_241, 0);
    V v_ts_2429 = heff_field(v_x2_241, 1);
    V v_go_2430 = heff_tr(heff_call(((V)&g_heff_2ecompile_2espec_2ekeyGo_clo), 1, (V[]){v_env_240}));
    V v_x2_2435 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2espec_2ekeyGo_lam0, 1, 1, (V[]){v_go_2430}), heff_dup(v_fs_2428)));
    V v_t_2438;
    switch (heff_tag_of(v_x2_2435)) {
    case TAG_Nil: {
      v_t_2438 = ((V)&g_heff_2ecompile_2espec_2ekeyGo_str15);
      break;
    }
    case TAG_Cons: {
      V v_x_2436 = heff_field(v_x2_2435, 0);
      V v_xs_2437 = heff_field(v_x2_2435, 1);
      heff_take_n(v_x2_2435, 3ULL, 2);
      v_t_2438 = ({ V a_0 = ((V)&g_heff_2ecompile_2espec_2ekeyGo_str16); V a_1 = v_x_2436; V a_2 = v_xs_2437; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2437); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2435);
    }
    V v_x2_2439 = (g_list_2emap_24s143096761x246530315(heff_dup(v_ts_2429)));
    V v_t_2442;
    switch (heff_tag_of(v_x2_2439)) {
    case TAG_Nil: {
      v_t_2442 = ((V)&g_heff_2ecompile_2espec_2ekeyGo_str17);
      break;
    }
    case TAG_Cons: {
      V v_x_2440 = heff_field(v_x2_2439, 0);
      V v_xs_2441 = heff_field(v_x2_2439, 1);
      heff_take_n(v_x2_2439, 3ULL, 2);
      v_t_2442 = ({ V a_0 = ((V)&g_heff_2ecompile_2espec_2ekeyGo_str18); V a_1 = v_x_2440; V a_2 = v_xs_2441; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2441); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2439);
    }
    V v_t_2443 = heff_strAppend(((V)&g_heff_2ecompile_2espec_2ekeyGo_str19), heff_strAppend(v_t_2442, ((V)&g_heff_2ecompile_2espec_2ekeyGo_str20)));
    return heff_strAppend(((V)&g_heff_2ecompile_2espec_2ekeyGo_str21), heff_strAppend(v_t_2438, v_t_2443));
  }
  case TAG_EProj: {
    V v_e_2444 = heff_field(v_x2_241, 0);
    V v_l_2445 = heff_field(v_x2_241, 1);
    V v_sh_2446 = heff_field(v_x2_241, 2);
    V v_t_2447 = heff_field(v_x2_241, 3);
    V v_t_2448 = (g_heff_2ecompile_2espec_2ekeyGo(v_env_240, v_e_2444));
    V v_t_2451;
    switch (heff_tag_of(v_sh_2446)) {
    case TAG_Nil: {
      v_t_2451 = ((V)&g_heff_2ecompile_2espec_2ekeyGo_str22);
      break;
    }
    case TAG_Cons: {
      V v_x_2449 = heff_field(v_sh_2446, 0);
      V v_xs_2450 = heff_field(v_sh_2446, 1);
      v_t_2451 = (g_prelude_2ejoinWith_2eafter_240(((V)&g_heff_2ecompile_2espec_2ekeyGo_str23), heff_dup(v_x_2449), v_xs_2450));
      break;
    }
    default: heff_nomatch(v_sh_2446);
    }
    V v_t_2453;
    switch (heff_tag_of(v_t_2447)) {
    case TAG_FtFloat: {
      v_t_2453 = ((V)&g_heff_2ecompile_2espec_2ekeyGo_str24);
      break;
    }
    case TAG_FtFixed: {
      V v_w_2452 = heff_field(v_t_2447, 0);
      switch (heff_tag_of(v_w_2452)) {
      case TAG_I8: {
        v_t_2453 = ((V)&g_heff_2ecompile_2espec_2ekeyGo_str25);
        break;
      }
      case TAG_I16: {
        v_t_2453 = ((V)&g_heff_2ecompile_2espec_2ekeyGo_str26);
        break;
      }
      case TAG_I32: {
        v_t_2453 = ((V)&g_heff_2ecompile_2espec_2ekeyGo_str27);
        break;
      }
      case TAG_I64: {
        v_t_2453 = ((V)&g_heff_2ecompile_2espec_2ekeyGo_str28);
        break;
      }
      case TAG_U8: {
        v_t_2453 = ((V)&g_heff_2ecompile_2espec_2ekeyGo_str29);
        break;
      }
      case TAG_U16: {
        v_t_2453 = ((V)&g_heff_2ecompile_2espec_2ekeyGo_str30);
        break;
      }
      case TAG_U32: {
        v_t_2453 = ((V)&g_heff_2ecompile_2espec_2ekeyGo_str31);
        break;
      }
      case TAG_U64: {
        v_t_2453 = ((V)&g_heff_2ecompile_2espec_2ekeyGo_str32);
        break;
      }
      case TAG_F32: {
        v_t_2453 = ((V)&g_heff_2ecompile_2espec_2ekeyGo_str33);
        break;
      }
      default: heff_nomatch(v_w_2452);
      }
      break;
    }
    case TAG_FtOther: {
      v_t_2453 = ((V)&g_heff_2ecompile_2espec_2ekeyGo_str34);
      break;
    }
    case TAG_FtAny: {
      v_t_2453 = ((V)&g_heff_2ecompile_2espec_2ekeyGo_str35);
      break;
    }
    default: heff_nomatch(v_t_2447);
    }
    V v_t_2454 = heff_strAppend(((V)&g_heff_2ecompile_2espec_2ekeyGo_str36), heff_strAppend(v_t_2453, ((V)&g_heff_2ecompile_2espec_2ekeyGo_str37)));
    V v_t_2455 = heff_strAppend(((V)&g_heff_2ecompile_2espec_2ekeyGo_str38), heff_strAppend(v_t_2451, v_t_2454));
    V v_t_2456 = heff_strAppend(((V)&g_heff_2ecompile_2espec_2ekeyGo_str39), heff_strAppend(heff_dup(v_l_2445), v_t_2455));
    return heff_strAppend(((V)&g_heff_2ecompile_2espec_2ekeyGo_str40), heff_strAppend(v_t_2448, v_t_2456));
  }
  case TAG_ETag: {
    V v_t_2457 = heff_field(v_x2_241, 0);
    V v_args_2458 = heff_field(v_x2_241, 1);
    V v_go_2460 = heff_tr(heff_call(((V)&g_heff_2ecompile_2espec_2ekeyGo_clo), 1, (V[]){v_env_240}));
    V v_x2_2461 = (g_list_2emap(v_go_2460, heff_dup(v_args_2458)));
    V v_t_2464;
    switch (heff_tag_of(v_x2_2461)) {
    case TAG_Nil: {
      v_t_2464 = ((V)&g_heff_2ecompile_2espec_2ekeyGo_str41);
      break;
    }
    case TAG_Cons: {
      V v_x_2462 = heff_field(v_x2_2461, 0);
      V v_xs_2463 = heff_field(v_x2_2461, 1);
      heff_take_n(v_x2_2461, 3ULL, 2);
      v_t_2464 = ({ V a_0 = ((V)&g_heff_2ecompile_2espec_2ekeyGo_str42); V a_1 = v_x_2462; V a_2 = v_xs_2463; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2463); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2461);
    }
    V v_t_2465 = heff_strAppend(((V)&g_heff_2ecompile_2espec_2ekeyGo_str43), heff_strAppend(v_t_2464, ((V)&g_heff_2ecompile_2espec_2ekeyGo_str44)));
    return heff_strAppend(((V)&g_heff_2ecompile_2espec_2ekeyGo_str45), heff_strAppend(heff_dup(v_t_2457), v_t_2465));
  }
  case TAG_EMatch: {
    V v_s_2466 = heff_field(v_x2_241, 0);
    V v_arms_2467 = heff_field(v_x2_241, 1);
    V v_t_2468 = (g_heff_2ecompile_2espec_2ekeyGo(heff_dup(v_env_240), v_s_2466));
    V v_x2_2478 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2espec_2ekeyGo_lam1, 1, 1, (V[]){v_env_240}), heff_dup(v_arms_2467)));
    V v_t_2481;
    switch (heff_tag_of(v_x2_2478)) {
    case TAG_Nil: {
      v_t_2481 = ((V)&g_heff_2ecompile_2espec_2ekeyGo_str48);
      break;
    }
    case TAG_Cons: {
      V v_x_2479 = heff_field(v_x2_2478, 0);
      V v_xs_2480 = heff_field(v_x2_2478, 1);
      heff_take_n(v_x2_2478, 3ULL, 2);
      v_t_2481 = ({ V a_0 = ((V)&g_heff_2ecompile_2espec_2ekeyGo_str49); V a_1 = v_x_2479; V a_2 = v_xs_2480; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2480); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2478);
    }
    V v_t_2482 = heff_strAppend(v_t_2468, heff_strAppend(v_t_2481, ((V)&g_heff_2ecompile_2espec_2ekeyGo_str50)));
    return heff_strAppend(((V)&g_heff_2ecompile_2espec_2ekeyGo_str51), v_t_2482);
  }
  case TAG_EPrim: {
    V v_p_2483 = heff_field(v_x2_241, 0);
    heff_drop(v_env_240);
    return heff_strAppend(((V)&g_heff_2ecompile_2espec_2ekeyGo_str52), heff_strAppend(heff_dup(v_p_2483), ((V)&g_heff_2ecompile_2espec_2ekeyGo_str53)));
  }
  case TAG_EPrimCall: {
    V v_p_2484 = heff_field(v_x2_241, 0);
    V v_args_2485 = heff_field(v_x2_241, 1);
    V v_go_2486 = heff_tr(heff_call(((V)&g_heff_2ecompile_2espec_2ekeyGo_clo), 1, (V[]){v_env_240}));
    V v_x2_2487 = (g_list_2emap(v_go_2486, heff_dup(v_args_2485)));
    V v_t_2490;
    switch (heff_tag_of(v_x2_2487)) {
    case TAG_Nil: {
      v_t_2490 = ((V)&g_heff_2ecompile_2espec_2ekeyGo_str54);
      break;
    }
    case TAG_Cons: {
      V v_x_2488 = heff_field(v_x2_2487, 0);
      V v_xs_2489 = heff_field(v_x2_2487, 1);
      heff_take_n(v_x2_2487, 3ULL, 2);
      v_t_2490 = ({ V a_0 = ((V)&g_heff_2ecompile_2espec_2ekeyGo_str55); V a_1 = v_x_2488; V a_2 = v_xs_2489; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2489); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2487);
    }
    V v_t_2491 = heff_strAppend(((V)&g_heff_2ecompile_2espec_2ekeyGo_str56), heff_strAppend(v_t_2490, ((V)&g_heff_2ecompile_2espec_2ekeyGo_str57)));
    return heff_strAppend(((V)&g_heff_2ecompile_2espec_2ekeyGo_str58), heff_strAppend(heff_dup(v_p_2484), v_t_2491));
  }
  case TAG_ECall: {
    V v_g_2492 = heff_field(v_x2_241, 0);
    V v_args_2493 = heff_field(v_x2_241, 1);
    V v_go_2494 = heff_tr(heff_call(((V)&g_heff_2ecompile_2espec_2ekeyGo_clo), 1, (V[]){v_env_240}));
    V v_x2_2495 = (g_list_2emap(v_go_2494, heff_dup(v_args_2493)));
    V v_t_2498;
    switch (heff_tag_of(v_x2_2495)) {
    case TAG_Nil: {
      v_t_2498 = ((V)&g_heff_2ecompile_2espec_2ekeyGo_str59);
      break;
    }
    case TAG_Cons: {
      V v_x_2496 = heff_field(v_x2_2495, 0);
      V v_xs_2497 = heff_field(v_x2_2495, 1);
      heff_take_n(v_x2_2495, 3ULL, 2);
      v_t_2498 = ({ V a_0 = ((V)&g_heff_2ecompile_2espec_2ekeyGo_str60); V a_1 = v_x_2496; V a_2 = v_xs_2497; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2497); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2495);
    }
    V v_t_2499 = heff_strAppend(((V)&g_heff_2ecompile_2espec_2ekeyGo_str61), heff_strAppend(v_t_2498, ((V)&g_heff_2ecompile_2espec_2ekeyGo_str62)));
    return heff_strAppend(((V)&g_heff_2ecompile_2espec_2ekeyGo_str63), heff_strAppend(heff_dup(v_g_2492), v_t_2499));
  }
  case TAG_EInt: {
    V v_i_24100 = heff_field(v_x2_241, 0);
    heff_drop(v_env_240);
    return heff_strAppend(((V)&g_heff_2ecompile_2espec_2ekeyGo_str64), heff_intShow(heff_dup(v_i_24100)));
  }
  case TAG_EFloat: {
    V v_x_24101 = heff_tget_v(v_x2_241, 0);
    heff_drop(v_env_240);
    return heff_strAppend(((V)&g_heff_2ecompile_2espec_2ekeyGo_str65), heff_floatShow(v_x_24101));
  }
  case TAG_EStr: {
    V v_s_24102 = heff_field(v_x2_241, 0);
    heff_drop(v_env_240);
    V v_t_24103 = heff_intShow(heff_strLength_lent(v_s_24102, 0));
    V v_t_24104 = heff_strAppend(v_t_24103, heff_strAppend(((V)&g_heff_2ecompile_2espec_2ekeyGo_str66), heff_dup(v_s_24102)));
    return heff_strAppend(((V)&g_heff_2ecompile_2espec_2ekeyGo_str67), v_t_24104);
  }
  case TAG_EBytes: {
    V v_s_24105 = heff_field(v_x2_241, 0);
    heff_drop(v_env_240);
    V v_t_24106 = heff_intShow(heff_strLength_lent(v_s_24105, 0));
    V v_t_24107 = heff_strAppend(v_t_24106, heff_strAppend(((V)&g_heff_2ecompile_2espec_2ekeyGo_str68), heff_dup(v_s_24105)));
    return heff_strAppend(((V)&g_heff_2ecompile_2espec_2ekeyGo_str69), v_t_24107);
  }
  case TAG_EFixed: {
    V v_w_24108 = heff_field(v_x2_241, 0);
    V v_n_24109 = heff_field(v_x2_241, 1);
    heff_drop(v_env_240);
    V v_t_24110;
    switch (heff_tag_of(v_w_24108)) {
    case TAG_I8: {
      v_t_24110 = ((V)&g_heff_2ecompile_2espec_2ekeyGo_str70);
      break;
    }
    case TAG_I16: {
      v_t_24110 = ((V)&g_heff_2ecompile_2espec_2ekeyGo_str71);
      break;
    }
    case TAG_I32: {
      v_t_24110 = ((V)&g_heff_2ecompile_2espec_2ekeyGo_str72);
      break;
    }
    case TAG_I64: {
      v_t_24110 = ((V)&g_heff_2ecompile_2espec_2ekeyGo_str73);
      break;
    }
    case TAG_U8: {
      v_t_24110 = ((V)&g_heff_2ecompile_2espec_2ekeyGo_str74);
      break;
    }
    case TAG_U16: {
      v_t_24110 = ((V)&g_heff_2ecompile_2espec_2ekeyGo_str75);
      break;
    }
    case TAG_U32: {
      v_t_24110 = ((V)&g_heff_2ecompile_2espec_2ekeyGo_str76);
      break;
    }
    case TAG_U64: {
      v_t_24110 = ((V)&g_heff_2ecompile_2espec_2ekeyGo_str77);
      break;
    }
    case TAG_F32: {
      v_t_24110 = ((V)&g_heff_2ecompile_2espec_2ekeyGo_str78);
      break;
    }
    default: heff_nomatch(v_w_24108);
    }
    V v_t_24111 = heff_strAppend(((V)&g_heff_2ecompile_2espec_2ekeyGo_str79), heff_intShow(heff_dup(v_n_24109)));
    return heff_strAppend(((V)&g_heff_2ecompile_2espec_2ekeyGo_str80), heff_strAppend(v_t_24110, v_t_24111));
  }
  case TAG_EFloat32: {
    V v_x_24112 = heff_tget_v(v_x2_241, 0);
    heff_drop(v_env_240);
    return heff_strAppend(((V)&g_heff_2ecompile_2espec_2ekeyGo_str81), heff_floatShow(v_x_24112));
  }
  case TAG_EAbandon: {
    heff_drop(v_env_240);
    return ((V)&g_heff_2ecompile_2espec_2ekeyGo_str82);
  }
  case TAG_EBool: {
    V v_c_24113 = heff_field(v_x2_241, 0);
    V v_t_24114 = heff_tr(heff_call(((V)&g_heff_2ecompile_2espec_2ekeyGo_clo), 1, (V[]){v_env_240}));
    V v_t_24115 = (g_heff_2ecompile_2espec_2econdKey(v_t_24114, v_c_24113));
    return heff_strAppend(((V)&g_heff_2ecompile_2espec_2ekeyGo_str83), heff_strAppend(v_t_24115, ((V)&g_heff_2ecompile_2espec_2ekeyGo_str84)));
  }
  case TAG_ESet: {
    V v_xs_24116 = heff_field(v_x2_241, 0);
    V v_a_24117 = heff_field(v_x2_241, 1);
    V v_b_24118 = heff_field(v_x2_241, 2);
    V v_t_24119 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_24116));
    V v_t_24120 = (g_heff_2ecompile_2espec_2ekeyGo(heff_dup(v_env_240), v_a_24117));
    V v_t_24121 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_xs_24116)));
    V v_t_24122 = (g_heff_2ecompile_2espec_2eappendS(v_t_24121, v_env_240));
    V v_t_24123 = (g_heff_2ecompile_2espec_2ekeyGo(v_t_24122, v_b_24118));
    V v_t_24124 = heff_strAppend(((V)&g_heff_2ecompile_2espec_2ekeyGo_str85), heff_strAppend(v_t_24123, ((V)&g_heff_2ecompile_2espec_2ekeyGo_str86)));
    V v_t_24125 = heff_strAppend(((V)&g_heff_2ecompile_2espec_2ekeyGo_str87), heff_strAppend(v_t_24120, v_t_24124));
    V v_t_24126 = heff_strAppend(heff_intShow(v_t_24119), v_t_24125);
    return heff_strAppend(((V)&g_heff_2ecompile_2espec_2ekeyGo_str88), v_t_24126);
  }
  case TAG_EValues: {
    V v_es_24127 = heff_field(v_x2_241, 0);
    V v_go_24128 = heff_tr(heff_call(((V)&g_heff_2ecompile_2espec_2ekeyGo_clo), 1, (V[]){v_env_240}));
    V v_x2_24129 = (g_list_2emap(v_go_24128, heff_dup(v_es_24127)));
    V v_t_24132;
    switch (heff_tag_of(v_x2_24129)) {
    case TAG_Nil: {
      v_t_24132 = ((V)&g_heff_2ecompile_2espec_2ekeyGo_str89);
      break;
    }
    case TAG_Cons: {
      V v_x_24130 = heff_field(v_x2_24129, 0);
      V v_xs_24131 = heff_field(v_x2_24129, 1);
      heff_take_n(v_x2_24129, 3ULL, 2);
      v_t_24132 = ({ V a_0 = ((V)&g_heff_2ecompile_2espec_2ekeyGo_str90); V a_1 = v_x_24130; V a_2 = v_xs_24131; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24131); r_; });
      break;
    }
    default: heff_nomatch(v_x2_24129);
    }
    return heff_strAppend(((V)&g_heff_2ecompile_2espec_2ekeyGo_str91), heff_strAppend(v_t_24132, ((V)&g_heff_2ecompile_2espec_2ekeyGo_str92)));
  }
  case TAG_EFix: {
    heff_drop(v_env_240);
    return ((V)&g_heff_2ecompile_2espec_2ekeyGo_str93);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2espec_2ekeyGo_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2espec_2ekeyGo(a[0], a1); heff_drop(a1); return r;
}
V g_heff_2ecompile_2espec_2ekeyGo_lam0(V self, V *args) {
  V v_x2_2431 = args[0];
  V v_go_2430 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x2_2431)) {
  case TAG_MkPair: {
    V v_l_2432 = heff_field(v_x2_2431, 0);
    V v_v_2433 = heff_field(v_x2_2431, 1);
    heff_take_n(v_x2_2431, 3ULL, 2);
    V v_t_2434 = heff_tr(heff_call(v_go_2430, 1, (V[]){v_v_2433}));
    return heff_strAppend(v_l_2432, heff_strAppend(((V)&g_heff_2ecompile_2espec_2ekeyGo_str14), v_t_2434));
  }
  default: return heff_nomatch(v_x2_2431);
  }
}
V g_heff_2ecompile_2espec_2ekeyGo_lam1(V self, V *args) {
  V v_x3_2469 = args[0];
  V v_env_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x3_2469)) {
  case TAG_MkArm: {
    V v_t_2470 = heff_field(v_x3_2469, 0);
    V v_vs_2471 = heff_field(v_x3_2469, 1);
    V v_b_2472 = heff_field(v_x3_2469, 2);
    heff_take_n(v_x3_2469, 7ULL, 3);
    V v_t_2473 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_vs_2471));
    V v_t_2474 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_vs_2471));
    V v_t_2475 = (g_heff_2ecompile_2espec_2eappendS(v_t_2474, v_env_240));
    V v_t_2476 = ({ V a_0 = v_t_2475; V a_1 = v_b_2472; V r_ = (g_heff_2ecompile_2espec_2ekeyGo(a_0, a_1)); heff_drop(v_b_2472); r_; });
    V v_t_2477 = heff_strAppend(heff_intShow(v_t_2473), heff_strAppend(((V)&g_heff_2ecompile_2espec_2ekeyGo_str46), v_t_2476));
    return heff_strAppend(((V)&g_heff_2ecompile_2espec_2ekeyGo_str47), heff_strAppend(v_t_2470, v_t_2477));
  }
  default: return heff_nomatch(v_x3_2469);
  }
}
HEFF_LIT(g_heff_2ecompile_2espec_2ehashGo_str0, 1, "x");
Clo g_heff_2ecompile_2espec_2ehashGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2espec_2ehashGo_entry, 4, 0};

V g_heff_2ecompile_2espec_2ehashGo(V v_s_240, V v_box_24i_241, V v_box_24a_242, V v_box_24b_243) {
  int64_t v_i_241 = heff_unbox_word(v_box_24i_241);
  int64_t v_a_242 = heff_unbox_word(v_box_24a_242);
  int64_t v_b_243 = heff_unbox_word(v_box_24b_243);
top: ;
  if ((heff_unbox_word(heff_strLength_lent(v_s_240, 0)) <= v_i_241)) {
    V v_t_244 = heff_strAppend(((V)&g_heff_2ecompile_2espec_2ehashGo_str0), heff_intShow(heff_box_word(v_b_243)));
    return heff_strAppend(heff_intShow(heff_box_word(v_a_242)), v_t_244);
  } else {
    int64_t v_t_245 = ((v_a_242 * ((int64_t)1000003ULL)) + heff_unbox_word(heff_strByteAt_lent(v_s_240, heff_box_word(v_i_241), 2)));
    int64_t v_t_246 = ((v_t_245 + ((int64_t)1ULL)) % ((int64_t)2147483647ULL));
    int64_t v_t_247 = ((v_b_243 * ((int64_t)999983ULL)) + heff_unbox_word(heff_strByteAt_lent(v_s_240, heff_box_word(v_i_241), 2)));
    int64_t v_t_248 = ((v_t_247 + ((int64_t)1ULL)) % ((int64_t)2147483629ULL));
    V t_0 = v_s_240;
    int64_t t_1 = (v_i_241 + ((int64_t)1ULL));
    int64_t t_2 = v_t_246;
    int64_t t_3 = v_t_248;
    v_s_240 = t_0;
    v_i_241 = t_1;
    v_a_242 = t_2;
    v_b_243 = t_3;
    goto top;
  }
}
V g_heff_2ecompile_2espec_2ehashGo_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2espec_2ehashGo(a0, a[1], a[2], a[3]); heff_drop(a0); return r;
}
HEFF_LIT(g_heff_2ecompile_2espec_2ebindOne_str0, 2, "a$");
HEFF_LIT(g_heff_2ecompile_2espec_2ebindOne_str1, 2, "a$");
Clo g_heff_2ecompile_2espec_2ebindOne_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2espec_2ebindOne_entry, 2, 0};

V g_heff_2ecompile_2espec_2ebindOne(V v_x1_240, V v_x_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_MkPair: {
    V v_xs_242 = heff_field(v_x1_240, 0);
    V v_st_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24MkPair = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_n_244 = heff_take_field(v_st_243, 4);
    V v_ren_245 = heff_take_field(v_st_243, 0);
    V v_caps_246 = heff_take_field(v_st_243, 1);
    V v_vars_247 = heff_take_field(v_st_243, 2);
    V v_holes_248 = heff_get_n(v_st_243, 3, 5);
    V v_t_249 = heff_strAppend(((V)&g_heff_2ecompile_2espec_2ebindOne_str0), heff_intShow(heff_dup(v_n_244)));
    V v_t_2410 = heff_strAppend(((V)&g_heff_2ecompile_2espec_2ebindOne_str1), heff_intShow(heff_dup(v_n_244)));
    V v_t_2411 = (g_std_2emap_2einsert_24s93785294x875597928(v_ren_245, v_x_241, v_t_2410));
    V v_t_2412 = heff_rec_n(5, shape_ren__caps__vars__holes__n, (V[]){v_t_2411, v_caps_246, v_vars_247, v_holes_248, heff_intAdd(v_n_244, MK_INT(1LL))});
    return heff_tag_at_n(v_ru_24x1_240_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_n(TAG_Cons, 2, (V[]){v_t_249, v_xs_242}), v_t_2412});
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2espec_2ebindOne_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2espec_2ebindOne(a[0], a[1]);
}
HEFF_LIT(g_heff_2ecompile_2espec_2ecapOf_24cpr_str0, 4, "lit$");
HEFF_LIT(g_heff_2ecompile_2espec_2ecapOf_24cpr_str1, 4, "lit$");
HEFF_LIT(g_heff_2ecompile_2espec_2ecapOf_24cpr_str2, 4, "lit$");

HeffT2 g_heff_2ecompile_2espec_2ecapOf_24cpr(V v_x_240, V v_st_241) {
top: ;
  V v_n_242 = heff_take_field(v_st_241, 4);
  V v_ren_243 = heff_take_field(v_st_241, 0);
  V v_caps_244 = heff_take_field(v_st_241, 1);
  V v_vars_245 = heff_take_field(v_st_241, 2);
  V v_holes_246 = heff_get_n(v_st_241, 3, 5);
  V v_t_247 = heff_strAppend(((V)&g_heff_2ecompile_2espec_2ecapOf_24cpr_str0), heff_intShow(heff_dup(v_n_242)));
  V v_f_248 = heff_tag_n(TAG_EVar, 1, (V[]){v_t_247});
  V v_t_249 = heff_strAppend(((V)&g_heff_2ecompile_2espec_2ecapOf_24cpr_str1), heff_intShow(heff_dup(v_n_242)));
  V v_t_2410 = (g_std_2emap_2einsert_24s93785294x875597928(v_caps_244, heff_dup(v_x_240), v_t_249));
  V v_t_2411 = heff_strAppend(((V)&g_heff_2ecompile_2espec_2ecapOf_24cpr_str2), heff_intShow(heff_dup(v_n_242)));
  V v_t_2412 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_x_240}), v_holes_246});
  V v_f_2413 = heff_rec_n(5, shape_ren__caps__vars__holes__n, (V[]){v_ren_243, v_t_2410, heff_tag_n(TAG_Cons, 2, (V[]){v_t_2411, v_vars_245}), v_t_2412, heff_intAdd(v_n_242, MK_INT(1LL))});
  return ((HeffT2){{v_f_248, v_f_2413}});
}

HeffT2 g_heff_2ecompile_2espec_2eshapeMany_24cpr(V v_go_240, V v_x2_241, V v_st_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_go_240);
    return ((HeffT2){{NTAG(TAG_Nil), v_st_242}});
  }
  case TAG_Cons: {
    V v_e_243 = heff_field(v_x2_241, 0);
    V v_rest_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_more_245 = heff_tr(heff_call(((V)&g_heff_2ecompile_2espec_2eshapeMany_clo), 2, (V[]){heff_dup(v_go_240), v_rest_244}));
    V v_x2_246 = heff_tr(heff_call(v_go_240, 2, (V[]){v_e_243, v_st_242}));
    switch (heff_tag_of(v_x2_246)) {
    case TAG_MkPair: {
      V v_e_247 = heff_field(v_x2_246, 0);
      V v_st_248 = heff_field(v_x2_246, 1);
      heff_take_n(v_x2_246, 3ULL, 2);
      V v_x2_249 = heff_tr(heff_call(v_more_245, 1, (V[]){v_st_248}));
      switch (heff_tag_of(v_x2_249)) {
      case TAG_MkPair: {
        V v_es_2410 = heff_field(v_x2_249, 0);
        V v_st_2411 = heff_field(v_x2_249, 1);
        heff_take_n(v_x2_249, 3ULL, 2);
        return ((HeffT2){{heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_e_247, v_es_2410}), v_st_2411}});
      }
      default: return ((HeffT2){{heff_nomatch(v_x2_249)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x2_246)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
Clo g_heff_2ecompile_2espec_2eshapeMany_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2espec_2eshapeMany_entry, 3, 0};

V g_heff_2ecompile_2espec_2eshapeMany(V v_go_240, V v_x2_241, V v_st_242) {
top: ;
  HeffT2 v_t_243 = (g_heff_2ecompile_2espec_2eshapeMany_24cpr(v_go_240, v_x2_241, v_st_242));
  {
    V v_field_244 = v_t_243.f[0];
    V v_field_245 = v_t_243.f[1];
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_field_244, v_field_245});
  }
}
V g_heff_2ecompile_2espec_2eshapeMany_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2espec_2eshapeMany(a[0], a[1], a[2]);
}

HeffT2 g_heff_2ecompile_2espec_2eletThen_24cpr(V v_go_240, V v_x_241, V v_b_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_MkPair: {
    V v_a_244 = heff_field(v_x4_243, 0);
    V v_st_245 = heff_field(v_x4_243, 1);
    V v_ru_24x4_243_24MkPair = heff_take_reuse_n(v_x4_243, 3ULL, 2);
    V v_t_246 = heff_tag_at_n(v_ru_24x4_243_24MkPair, TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), heff_dup(v_st_245)});
    V v_t_247 = heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_x_241), NTAG(TAG_Nil)});
    V v_t_248 = ({ V a_0 = v_t_246; V a_1 = v_t_247; V r_ = (g_list_2efoldl_24s1048046132x95752937(a_0, a_1)); heff_drop_tag(v_t_247, 2); r_; });
    switch (heff_tag_of(v_t_248)) {
    case TAG_MkPair: {
      V v_ys_249 = heff_field(v_t_248, 0);
      V v_st2_2410 = heff_field(v_t_248, 1);
      heff_take_n(v_t_248, 3ULL, 2);
      V v_t_2411 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ys_249));
      V v_x2_2412 = heff_tr(heff_call(v_go_240, 2, (V[]){v_b_242, v_st2_2410}));
      switch (heff_tag_of(v_x2_2412)) {
      case TAG_MkPair: {
        V v_e_2413 = heff_field(v_x2_2412, 0);
        V v_st_2414 = heff_field(v_x2_2412, 1);
        heff_take_n(v_x2_2412, 3ULL, 2);
        V v_caps_2415 = heff_take_field(v_st_2414, 1);
        V v_vars_2416 = heff_take_field(v_st_2414, 2);
        V v_holes_2417 = heff_take_field(v_st_2414, 3);
        V v_n_2418 = heff_get_n(v_st_2414, 4, 5);
        V v_t_2421;
        switch (heff_tag_of(v_t_2411)) {
        case TAG_Nil: {
          v_t_2421 = v_x_241;
          break;
        }
        case TAG_Cons: {
          V v_y_2419 = heff_field(v_t_2411, 0);
          heff_take_n(v_t_2411, 1ULL, 2);
          heff_drop(v_x_241);
          v_t_2421 = v_y_2419;
          break;
        }
        default: heff_nomatch(v_t_2411);
        }
        V v_f_2422 = heff_tag_n(TAG_ELet, 3, (V[]){v_t_2421, v_a_244, v_e_2413});
        V v_f_2423 = ({ V rv_1 = v_caps_2415; V rv_2 = v_vars_2416; V rv_3 = v_holes_2417; V rv_4 = v_n_2418; V rr_ = heff_rec_reuse_nf(v_st_245, 1ULL, 5, shape_ren__caps__vars__holes__n, 3u, 0u); heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; rr_; });
        return ((HeffT2){{v_f_2422, v_f_2423}});
      }
      default: return ((HeffT2){{heff_nomatch(v_x2_2412)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_t_248)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x4_243)}});
  }
}

HeffT2 g_heff_2ecompile_2espec_2esetThen_24cpr(V v_go_240, V v_xs_241, V v_b_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_MkPair: {
    V v_a_244 = heff_field(v_x4_243, 0);
    V v_st_245 = heff_field(v_x4_243, 1);
    V v_ru_24x4_243_24MkPair = heff_take_reuse_n(v_x4_243, 3ULL, 2);
    V v_t_246 = heff_tag_at_n(v_ru_24x4_243_24MkPair, TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), heff_dup(v_st_245)});
    V v_t_247 = (g_list_2efoldl_24s1048046132x95752937(v_t_246, v_xs_241));
    switch (heff_tag_of(v_t_247)) {
    case TAG_MkPair: {
      V v_ys_248 = heff_field(v_t_247, 0);
      V v_st2_249 = heff_field(v_t_247, 1);
      heff_take_n(v_t_247, 3ULL, 2);
      V v_t_2410 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ys_248));
      V v_x2_2411 = heff_tr(heff_call(v_go_240, 2, (V[]){v_b_242, v_st2_249}));
      switch (heff_tag_of(v_x2_2411)) {
      case TAG_MkPair: {
        V v_e_2412 = heff_field(v_x2_2411, 0);
        V v_st_2413 = heff_field(v_x2_2411, 1);
        heff_take_n(v_x2_2411, 3ULL, 2);
        V v_caps_2414 = heff_take_field(v_st_2413, 1);
        V v_vars_2415 = heff_take_field(v_st_2413, 2);
        V v_holes_2416 = heff_take_field(v_st_2413, 3);
        V v_n_2417 = heff_get_n(v_st_2413, 4, 5);
        V v_f_2418 = ({ V rv_1 = v_caps_2414; V rv_2 = v_vars_2415; V rv_3 = v_holes_2416; V rv_4 = v_n_2417; V rr_ = heff_rec_reuse_nf(v_st_245, 1ULL, 5, shape_ren__caps__vars__holes__n, 3u, 0u); heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; rr_; });
        return ((HeffT2){{heff_tag_n(TAG_ESet, 3, (V[]){v_t_2410, v_a_244, v_e_2412}), v_f_2418}});
      }
      default: return ((HeffT2){{heff_nomatch(v_x2_2411)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_t_247)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x4_243)}});
  }
}
Clo g_heff_2ecompile_2espec_2elabelsTo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2espec_2elabelsTo_entry, 2, 0};

V g_heff_2ecompile_2espec_2elabelsTo(V v_x1_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_x2_241);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x11_242 = heff_field(v_x1_240, 0);
    V v_fs_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_242)) {
    case TAG_MkPair: {
      V v_l_244 = heff_field(v_x11_242, 0);
      heff_take_n(v_x11_242, 1ULL, 2);
      switch (heff_tag_of(v_x2_241)) {
      case TAG_Nil: {
        heff_drop(v_fs_243);
        heff_drop_cell(v_ru_24x1_240_24Cons, 2);
        heff_drop(v_l_244);
        return NTAG(TAG_Nil);
      }
      case TAG_Cons: {
        V v_e_246 = heff_field(v_x2_241, 0);
        V v_es_247 = heff_field(v_x2_241, 1);
        heff_take_n(v_x2_241, 3ULL, 2);
        V v_cell_248 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_l_244, v_e_246}), heff_hole()});
        V v_u_249 = (g_heff_2ecompile_2espec_2elabelsTo_24dps(v_fs_243, v_es_247, heff_dup(v_cell_248)));
        heff_drop(v_u_249);
        return v_cell_248;
      }
      default: return heff_nomatch(v_x2_241);
      }
    }
    default: return heff_nomatch(v_x11_242);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2espec_2elabelsTo_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2espec_2elabelsTo(a[0], a[1]);
}
Clo g_heff_2ecompile_2espec_2elabelsTo_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2espec_2elabelsTo_24dps_entry, 3, 0};

V g_heff_2ecompile_2espec_2elabelsTo_24dps(V v_x1_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    heff_drop(v_x2_241);
    return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x11_243 = heff_field(v_x1_240, 0);
    V v_fs_244 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x11_243)) {
    case TAG_MkPair: {
      V v_l_245 = heff_field(v_x11_243, 0);
      heff_take_n(v_x11_243, 1ULL, 2);
      switch (heff_tag_of(v_x2_241)) {
      case TAG_Nil: {
        heff_drop(v_fs_244);
        heff_drop_cell(v_ru_24x1_240_24Cons, 2);
        heff_drop(v_l_245);
        return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
      }
      case TAG_Cons: {
        V v_e_247 = heff_field(v_x2_241, 0);
        V v_es_248 = heff_field(v_x2_241, 1);
        heff_take_n(v_x2_241, 3ULL, 2);
        V v_cell_249 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkPair, 2, (V[]){v_l_245, v_e_247}), heff_hole()});
        V v_u_2410 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_249));
        heff_drop(v_u_2410);
        V t_0 = v_fs_244;
        V t_1 = v_es_248;
        V t_2 = v_cell_249;
        v_x1_240 = t_0;
        v_x2_241 = t_1;
        v_d_242 = t_2;
        goto top;
      }
      default: return heff_nomatch(v_x2_241);
      }
    }
    default: return heff_nomatch(v_x11_243);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2espec_2elabelsTo_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2espec_2elabelsTo_24dps(a[0], a[1], a[2]);
}

HeffT2 g_heff_2ecompile_2espec_2eshapeArms_24cpr(V v_go_240, V v_x2_241, V v_st_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_go_240);
    return ((HeffT2){{NTAG(TAG_Nil), v_st_242}});
  }
  case TAG_Cons: {
    V v_x21_243 = heff_field(v_x2_241, 0);
    V v_rest_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_243)) {
    case TAG_MkArm: {
      V v_t_245 = heff_field(v_x21_243, 0);
      V v_vs_246 = heff_field(v_x21_243, 1);
      V v_b_247 = heff_field(v_x21_243, 2);
      heff_take_n(v_x21_243, 7ULL, 3);
      V v_more_248 = heff_tr(heff_call(((V)&g_heff_2ecompile_2espec_2eshapeArms_clo), 2, (V[]){heff_dup(v_go_240), v_rest_244}));
      V v_t_249 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), heff_dup(v_st_242)});
      V v_t_2410 = ({ V a_0 = v_t_249; V a_1 = v_vs_246; V r_ = (g_list_2efoldl_24s1048046132x95752937(a_0, a_1)); heff_drop(v_vs_246); r_; });
      switch (heff_tag_of(v_t_2410)) {
      case TAG_MkPair: {
        V v_ys_2411 = heff_field(v_t_2410, 0);
        V v_st2_2412 = heff_field(v_t_2410, 1);
        heff_take_n(v_t_2410, 3ULL, 2);
        V v_t_2413 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ys_2411));
        V v_x2_2414 = heff_tr(heff_call(v_go_240, 2, (V[]){v_b_247, v_st2_2412}));
        switch (heff_tag_of(v_x2_2414)) {
        case TAG_MkPair: {
          V v_e_2415 = heff_field(v_x2_2414, 0);
          V v_st_2416 = heff_field(v_x2_2414, 1);
          heff_take_n(v_x2_2414, 3ULL, 2);
          V v_caps_2417 = heff_take_field(v_st_2416, 1);
          V v_vars_2418 = heff_take_field(v_st_2416, 2);
          V v_holes_2419 = heff_take_field(v_st_2416, 3);
          V v_n_2420 = heff_get_n(v_st_2416, 4, 5);
          V v_t_2421 = ({ V rv_1 = v_caps_2417; V rv_2 = v_vars_2418; V rv_3 = v_holes_2419; V rv_4 = v_n_2420; V rr_ = heff_rec_reuse_nf(v_st_242, 1ULL, 5, shape_ren__caps__vars__holes__n, 3u, 0u); heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; rr_; });
          V v_b_2422 = v_e_2415;
          V v_st_2423 = v_t_2421;
          V v_x2_2424 = heff_tr(heff_call(v_more_248, 1, (V[]){v_st_2423}));
          switch (heff_tag_of(v_x2_2424)) {
          case TAG_MkPair: {
            V v_args_2425 = heff_field(v_x2_2424, 0);
            V v_st_2426 = heff_field(v_x2_2424, 1);
            heff_take_n(v_x2_2424, 3ULL, 2);
            V v_t_2427 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_tag_n(TAG_MkArm, 3, (V[]){v_t_245, v_t_2413, v_b_2422}), v_args_2425});
            return ((HeffT2){{v_t_2427, v_st_2426}});
          }
          default: return ((HeffT2){{heff_nomatch(v_x2_2424)}});
          }
        }
        default: return ((HeffT2){{heff_nomatch(v_x2_2414)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_t_2410)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x21_243)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
Clo g_heff_2ecompile_2espec_2eshapeArms_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2espec_2eshapeArms_entry, 3, 0};

V g_heff_2ecompile_2espec_2eshapeArms(V v_go_240, V v_x2_241, V v_st_242) {
top: ;
  HeffT2 v_t_243 = (g_heff_2ecompile_2espec_2eshapeArms_24cpr(v_go_240, v_x2_241, v_st_242));
  {
    V v_field_244 = v_t_243.f[0];
    V v_field_245 = v_t_243.f[1];
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_field_244, v_field_245});
  }
}
V g_heff_2ecompile_2espec_2eshapeArms_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2espec_2eshapeArms(a[0], a[1], a[2]);
}

HeffT2 g_heff_2ecompile_2espec_2eshapeCond_24cpr(V v_go_240, V v_x2_241, V v_st_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_CTrue: {
    heff_drop(v_go_240);
    return ((HeffT2){{NTAG(TAG_CTrue), v_st_242}});
  }
  case TAG_CFalse: {
    heff_drop(v_go_240);
    return ((HeffT2){{NTAG(TAG_CFalse), v_st_242}});
  }
  case TAG_CRel: {
    V v_p_243 = heff_field(v_x2_241, 0);
    V v_a_244 = heff_field(v_x2_241, 1);
    V v_b_245 = heff_field(v_x2_241, 2);
    V v_ru_24x2_241_24CRel = heff_take_reuse_n(v_x2_241, 7ULL, 3);
    V v_t_246 = heff_tr(heff_call(heff_dup(v_go_240), 2, (V[]){v_a_244, v_st_242}));
    switch (heff_tag_of(v_t_246)) {
    case TAG_MkPair: {
      V v_a2_247 = heff_field(v_t_246, 0);
      V v_st1_248 = heff_field(v_t_246, 1);
      heff_take_n(v_t_246, 3ULL, 2);
      V v_t_249 = heff_tr(heff_call(v_go_240, 2, (V[]){v_b_245, v_st1_248}));
      switch (heff_tag_of(v_t_249)) {
      case TAG_MkPair: {
        V v_b2_2410 = heff_field(v_t_249, 0);
        V v_st2_2411 = heff_field(v_t_249, 1);
        heff_take_n(v_t_249, 3ULL, 2);
        return ((HeffT2){{heff_tag_at_n(v_ru_24x2_241_24CRel, TAG_CRel, 3, (V[]){v_p_243, v_a2_247, v_b2_2410}), v_st2_2411}});
      }
      default: return ((HeffT2){{heff_nomatch(v_t_249)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_t_246)}});
    }
  }
  case TAG_CTest: {
    V v_e_2412 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24CTest = heff_take_reuse_n(v_x2_241, 1ULL, 1);
    V v_t_2413 = heff_tr(heff_call(v_go_240, 2, (V[]){v_e_2412, v_st_242}));
    switch (heff_tag_of(v_t_2413)) {
    case TAG_MkPair: {
      V v_e2_2414 = heff_field(v_t_2413, 0);
      V v_st1_2415 = heff_field(v_t_2413, 1);
      heff_take_n(v_t_2413, 3ULL, 2);
      return ((HeffT2){{heff_tag_at_n(v_ru_24x2_241_24CTest, TAG_CTest, 1, (V[]){v_e2_2414}), v_st1_2415}});
    }
    default: return ((HeffT2){{heff_nomatch(v_t_2413)}});
    }
  }
  case TAG_CNot: {
    V v_c_2416 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24CNot = heff_take_reuse_n(v_x2_241, 1ULL, 1);
    HeffT2 v_t_2417 = (g_heff_2ecompile_2espec_2eshapeCond_24cpr(v_go_240, v_c_2416, v_st_242));
    {
      V v_field_2418 = v_t_2417.f[0];
      V v_field_2419 = v_t_2417.f[1];
      V v_c_2420 = v_field_2418;
      V v_st_2421 = v_field_2419;
      return ((HeffT2){{heff_tag_at_n(v_ru_24x2_241_24CNot, TAG_CNot, 1, (V[]){v_c_2420}), v_st_2421}});
    }
  }
  case TAG_CIf: {
    V v_a_2422 = heff_field(v_x2_241, 0);
    V v_b_2423 = heff_field(v_x2_241, 1);
    V v_c_2424 = heff_field(v_x2_241, 2);
    V v_ru_24x2_241_24CIf = heff_take_reuse_n(v_x2_241, 7ULL, 3);
    HeffT2 v_t_2425 = (g_heff_2ecompile_2espec_2eshapeCond_24cpr(heff_dup(v_go_240), v_a_2422, v_st_242));
    {
      V v_field_2426 = v_t_2425.f[0];
      V v_field_2427 = v_t_2425.f[1];
      V v_c_2428 = v_field_2426;
      V v_st_2429 = v_field_2427;
      HeffT2 v_t_2430 = (g_heff_2ecompile_2espec_2eshapeCond_24cpr(heff_dup(v_go_240), v_b_2423, v_st_2429));
      {
        V v_field_2431 = v_t_2430.f[0];
        V v_field_2432 = v_t_2430.f[1];
        V v_c_2433 = v_field_2431;
        V v_st_2434 = v_field_2432;
        HeffT2 v_t_2435 = (g_heff_2ecompile_2espec_2eshapeCond_24cpr(v_go_240, v_c_2424, v_st_2434));
        {
          V v_field_2436 = v_t_2435.f[0];
          V v_field_2437 = v_t_2435.f[1];
          V v_c_2438 = v_field_2436;
          V v_st_2439 = v_field_2437;
          return ((HeffT2){{heff_tag_at_n(v_ru_24x2_241_24CIf, TAG_CIf, 3, (V[]){v_c_2428, v_c_2433, v_c_2438}), v_st_2439}});
        }
      }
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
HEFF_LIT(g_heff_2ecompile_2espec_2eshapeGo_24cpr_str0, 4, "lit$");
HEFF_LIT(g_heff_2ecompile_2espec_2eshapeGo_24cpr_str1, 4, "lit$");
HEFF_LIT(g_heff_2ecompile_2espec_2eshapeGo_24cpr_str2, 4, "lit$");
HEFF_LIT(g_heff_2ecompile_2espec_2eshapeGo_24cpr_str3, 4, "lit$");
HEFF_LIT(g_heff_2ecompile_2espec_2eshapeGo_24cpr_str4, 4, "lit$");
HEFF_LIT(g_heff_2ecompile_2espec_2eshapeGo_24cpr_str5, 4, "lit$");

HeffT2 g_heff_2ecompile_2espec_2eshapeGo_24cpr(V v_x1_240, V v_st_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_EVar: {
    V v_x_242 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24EVar = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    HeffT2 v_t_243 = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(heff_rfield(v_st_241, 0), v_x_242));
    {
      V v_field_245 = v_t_243.f[1];
      int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
      HeffT2 v_t_246 = (g_std_2emap_2elookup_24s1930949324x2078207031_24cpr(heff_rfield(v_st_241, 1), v_x_242));
      {
        V v_field_248 = v_t_246.f[1];
        int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
        if ((v_tag_244 == ((int64_t)0ULL))) {
          heff_drop(v_x_242);
          heff_drop(v_field_248);
          V v_y_249 = v_field_245;
          return ((HeffT2){{heff_tag_at_n(v_ru_24x1_240_24EVar, TAG_EVar, 1, (V[]){v_y_249}), v_st_241}});
        } else {
          heff_drop(v_field_245);
          if ((v_tag_247 == ((int64_t)0ULL))) {
            heff_drop(v_x_242);
            V v_h_2410 = v_field_248;
            return ((HeffT2){{heff_tag_at_n(v_ru_24x1_240_24EVar, TAG_EVar, 1, (V[]){v_h_2410}), v_st_241}});
          } else {
            heff_drop_cell(v_ru_24x1_240_24EVar, 1);
            heff_drop(v_field_248);
            HEFF_LAST return g_heff_2ecompile_2espec_2ecapOf_24cpr(v_x_242, v_st_241);
          }
        }
      }
    }
  }
  case TAG_EGlobal: {
    return ((HeffT2){{v_x1_240, v_st_241}});
  }
  case TAG_ELam: {
    V v_xs_2412 = heff_field(v_x1_240, 0);
    V v_b_2413 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24ELam = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_2414 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), heff_dup(v_st_241)});
    V v_t_2415 = ({ V a_0 = v_t_2414; V a_1 = v_xs_2412; V r_ = (g_list_2efoldl_24s1048046132x95752937(a_0, a_1)); heff_drop(v_xs_2412); r_; });
    switch (heff_tag_of(v_t_2415)) {
    case TAG_MkPair: {
      V v_ys_2416 = heff_field(v_t_2415, 0);
      V v_st2_2417 = heff_field(v_t_2415, 1);
      heff_take_n(v_t_2415, 3ULL, 2);
      V v_t_2418 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ys_2416));
      HeffT2 v_t_2419 = (g_heff_2ecompile_2espec_2eshapeGo_24cpr(v_b_2413, v_st2_2417));
      {
        V v_field_2420 = v_t_2419.f[0];
        V v_field_2421 = v_t_2419.f[1];
        V v_e_2422 = v_field_2420;
        V v_st_2423 = v_field_2421;
        V v_caps_2424 = heff_take_field(v_st_2423, 1);
        V v_vars_2425 = heff_take_field(v_st_2423, 2);
        V v_holes_2426 = heff_take_field(v_st_2423, 3);
        V v_n_2427 = heff_get_n(v_st_2423, 4, 5);
        V v_f_2428 = ({ V rv_1 = v_caps_2424; V rv_2 = v_vars_2425; V rv_3 = v_holes_2426; V rv_4 = v_n_2427; V rr_ = heff_rec_reuse_nf(v_st_241, 1ULL, 5, shape_ren__caps__vars__holes__n, 3u, 0u); heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; rr_; });
        return ((HeffT2){{heff_tag_at_n(v_ru_24x1_240_24ELam, TAG_ELam, 2, (V[]){v_t_2418, v_e_2422}), v_f_2428}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_t_2415)}});
    }
  }
  case TAG_EApp: {
    V v_f_2429 = heff_field(v_x1_240, 0);
    V v_args_2430 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24EApp = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    HeffT2 v_t_2431 = (g_heff_2ecompile_2espec_2eshapeGo_24cpr(v_f_2429, v_st_241));
    {
      V v_field_2432 = v_t_2431.f[0];
      V v_field_2433 = v_t_2431.f[1];
      V v_f_2434 = v_field_2432;
      V v_st_2435 = v_field_2433;
      HeffT2 v_t_2436 = (g_heff_2ecompile_2espec_2eshapeMany_24cpr(((V)&g_heff_2ecompile_2espec_2eshapeGo_clo), v_args_2430, v_st_2435));
      {
        V v_field_2437 = v_t_2436.f[0];
        V v_field_2438 = v_t_2436.f[1];
        V v_es_2439 = v_field_2437;
        V v_st_2440 = v_field_2438;
        return ((HeffT2){{heff_tag_at_n(v_ru_24x1_240_24EApp, TAG_EApp, 2, (V[]){v_f_2434, v_es_2439}), v_st_2440}});
      }
    }
  }
  case TAG_ELet: {
    V v_x_2441 = heff_field(v_x1_240, 0);
    V v_a_2442 = heff_field(v_x1_240, 1);
    V v_b_2443 = heff_field(v_x1_240, 2);
    heff_take_n(v_x1_240, 7ULL, 3);
    V v_t_2444 = (g_heff_2ecompile_2espec_2eshapeGo(v_a_2442, v_st_241));
    return (g_heff_2ecompile_2espec_2eletThen_24cpr(((V)&g_heff_2ecompile_2espec_2eshapeGo_clo), v_x_2441, v_b_2443, v_t_2444));
  }
  case TAG_ERecord: {
    V v_fs_2445 = heff_field(v_x1_240, 0);
    V v_ts_2446 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24ERecord = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    V v_t_2447 = (g_list_2emap_24s1173914895x100384474(heff_dup(v_fs_2445)));
    HeffT2 v_t_2448 = (g_heff_2ecompile_2espec_2eshapeMany_24cpr(((V)&g_heff_2ecompile_2espec_2eshapeGo_clo), v_t_2447, v_st_241));
    {
      V v_field_2449 = v_t_2448.f[0];
      V v_field_2450 = v_t_2448.f[1];
      V v_es_2451 = v_field_2449;
      V v_st_2452 = v_field_2450;
      V v_t_2453 = (g_heff_2ecompile_2espec_2elabelsTo(v_fs_2445, v_es_2451));
      V v_f_2454 = heff_tag_at_n(v_ru_24x1_240_24ERecord, TAG_ERecord, 2, (V[]){v_t_2453, v_ts_2446});
      return ((HeffT2){{v_f_2454, v_st_2452}});
    }
  }
  case TAG_EProj: {
    V v_e_2455 = heff_field(v_x1_240, 0);
    V v_l_2456 = heff_field(v_x1_240, 1);
    V v_sh_2457 = heff_field(v_x1_240, 2);
    V v_t_2458 = heff_field(v_x1_240, 3);
    V v_ru_24x1_240_24EProj = heff_take_reuse_n(v_x1_240, 15ULL, 4);
    HeffT2 v_t_2459 = (g_heff_2ecompile_2espec_2eshapeGo_24cpr(v_e_2455, v_st_241));
    {
      V v_field_2460 = v_t_2459.f[0];
      V v_field_2461 = v_t_2459.f[1];
      V v_e_2462 = v_field_2460;
      V v_st_2463 = v_field_2461;
      return ((HeffT2){{heff_tag_at_n(v_ru_24x1_240_24EProj, TAG_EProj, 4, (V[]){v_e_2462, v_l_2456, v_sh_2457, v_t_2458}), v_st_2463}});
    }
  }
  case TAG_ETag: {
    V v_t_2464 = heff_field(v_x1_240, 0);
    V v_args_2465 = heff_field(v_x1_240, 1);
    V v_ts_2466 = heff_field(v_x1_240, 2);
    V v_ru_24x1_240_24ETag = heff_take_reuse_n(v_x1_240, 7ULL, 3);
    HeffT2 v_t_2467 = (g_heff_2ecompile_2espec_2eshapeMany_24cpr(((V)&g_heff_2ecompile_2espec_2eshapeGo_clo), v_args_2465, v_st_241));
    {
      V v_field_2468 = v_t_2467.f[0];
      V v_field_2469 = v_t_2467.f[1];
      V v_es_2470 = v_field_2468;
      V v_st_2471 = v_field_2469;
      return ((HeffT2){{heff_tag_at_n(v_ru_24x1_240_24ETag, TAG_ETag, 3, (V[]){v_t_2464, v_es_2470, v_ts_2466}), v_st_2471}});
    }
  }
  case TAG_EMatch: {
    V v_sc_2472 = heff_field(v_x1_240, 0);
    V v_arms_2473 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24EMatch = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    HeffT2 v_t_2474 = (g_heff_2ecompile_2espec_2eshapeGo_24cpr(v_sc_2472, v_st_241));
    {
      V v_field_2475 = v_t_2474.f[0];
      V v_field_2476 = v_t_2474.f[1];
      V v_sc_2477 = v_field_2475;
      V v_st_2478 = v_field_2476;
      HeffT2 v_t_2479 = (g_heff_2ecompile_2espec_2eshapeArms_24cpr(((V)&g_heff_2ecompile_2espec_2eshapeGo_clo), v_arms_2473, v_st_2478));
      {
        V v_field_2480 = v_t_2479.f[0];
        V v_field_2481 = v_t_2479.f[1];
        V v_arms2_2482 = v_field_2480;
        V v_st2_2483 = v_field_2481;
        return ((HeffT2){{heff_tag_at_n(v_ru_24x1_240_24EMatch, TAG_EMatch, 2, (V[]){v_sc_2477, v_arms2_2482}), v_st2_2483}});
      }
    }
  }
  case TAG_EPrim: {
    return ((HeffT2){{v_x1_240, v_st_241}});
  }
  case TAG_EPrimCall: {
    V v_p_2485 = heff_field(v_x1_240, 0);
    V v_args_2486 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24EPrimCall = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    HeffT2 v_t_2487 = (g_heff_2ecompile_2espec_2eshapeMany_24cpr(((V)&g_heff_2ecompile_2espec_2eshapeGo_clo), v_args_2486, v_st_241));
    {
      V v_field_2488 = v_t_2487.f[0];
      V v_field_2489 = v_t_2487.f[1];
      V v_es_2490 = v_field_2488;
      V v_st_2491 = v_field_2489;
      return ((HeffT2){{heff_tag_at_n(v_ru_24x1_240_24EPrimCall, TAG_EPrimCall, 2, (V[]){v_p_2485, v_es_2490}), v_st_2491}});
    }
  }
  case TAG_ECall: {
    V v_g_2492 = heff_field(v_x1_240, 0);
    V v_args_2493 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24ECall = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    HeffT2 v_t_2494 = (g_heff_2ecompile_2espec_2eshapeMany_24cpr(((V)&g_heff_2ecompile_2espec_2eshapeGo_clo), v_args_2493, v_st_241));
    {
      V v_field_2495 = v_t_2494.f[0];
      V v_field_2496 = v_t_2494.f[1];
      V v_es_2497 = v_field_2495;
      V v_st_2498 = v_field_2496;
      return ((HeffT2){{heff_tag_at_n(v_ru_24x1_240_24ECall, TAG_ECall, 2, (V[]){v_g_2492, v_es_2497}), v_st_2498}});
    }
  }
  case TAG_EInt: {
    V v_i_2499 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24EInt = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    V v_t_24100 = heff_intShow(heff_dup(heff_rfield(v_st_241, 4)));
    V v_f_24101 = heff_tag_n(TAG_EVar, 1, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2espec_2eshapeGo_24cpr_str0), v_t_24100)});
    V v_t_24102 = heff_intShow(heff_dup(heff_rfield(v_st_241, 4)));
    V v_t_24103 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2espec_2eshapeGo_24cpr_str1), v_t_24102), heff_take_field(v_st_241, 2)});
    V v_t_24104 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24EInt, TAG_EInt, 1, (V[]){v_i_2499}), heff_take_field(v_st_241, 3)});
    V v_t_24105 = heff_intAdd(heff_take_field(v_st_241, 4), MK_INT(1LL));
    V v_f_24106 = ({ V rv_2 = v_t_24103; V rv_3 = v_t_24104; V rv_4 = v_t_24105; V rr_ = heff_rec_reuse_nf(v_st_241, 3ULL, 5, shape_ren__caps__vars__holes__n, 15u, 0u); heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; rr_; });
    return ((HeffT2){{v_f_24101, v_f_24106}});
  }
  case TAG_EFloat: {
    double v_x_24107 = heff_tflat_f64(v_x1_240, 0);
    V v_ru_24x1_240_24EFloat = heff_take_reuse_na(v_x1_240, 0ULL, 1);
    V v_t_24108 = heff_intShow(heff_dup(heff_rfield(v_st_241, 4)));
    V v_f_24109 = heff_tag_n(TAG_EVar, 1, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2espec_2eshapeGo_24cpr_str2), v_t_24108)});
    V v_t_24110 = heff_intShow(heff_dup(heff_rfield(v_st_241, 4)));
    V v_t_24111 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2espec_2eshapeGo_24cpr_str3), v_t_24110), heff_take_field(v_st_241, 2)});
    V v_t_24112 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_nf(v_ru_24x1_240_24EFloat, TAG_EFloat, 1, 1u, (V[]){heff_word_f64(v_x_24107)}), heff_take_field(v_st_241, 3)});
    V v_t_24113 = heff_intAdd(heff_take_field(v_st_241, 4), MK_INT(1LL));
    V v_f_24114 = ({ V rv_2 = v_t_24111; V rv_3 = v_t_24112; V rv_4 = v_t_24113; V rr_ = heff_rec_reuse_nf(v_st_241, 3ULL, 5, shape_ren__caps__vars__holes__n, 15u, 0u); heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; rr_; });
    return ((HeffT2){{v_f_24109, v_f_24114}});
  }
  case TAG_EStr: {
    V v_t_24115 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24EStr = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    V v_t_24116 = heff_intShow(heff_dup(heff_rfield(v_st_241, 4)));
    V v_f_24117 = heff_tag_n(TAG_EVar, 1, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2espec_2eshapeGo_24cpr_str4), v_t_24116)});
    V v_t_24118 = heff_intShow(heff_dup(heff_rfield(v_st_241, 4)));
    V v_t_24119 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2espec_2eshapeGo_24cpr_str5), v_t_24118), heff_take_field(v_st_241, 2)});
    V v_t_24120 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x1_240_24EStr, TAG_EStr, 1, (V[]){v_t_24115}), heff_take_field(v_st_241, 3)});
    V v_t_24121 = heff_intAdd(heff_take_field(v_st_241, 4), MK_INT(1LL));
    V v_f_24122 = ({ V rv_2 = v_t_24119; V rv_3 = v_t_24120; V rv_4 = v_t_24121; V rr_ = heff_rec_reuse_nf(v_st_241, 3ULL, 5, shape_ren__caps__vars__holes__n, 15u, 0u); heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; rr_; });
    return ((HeffT2){{v_f_24117, v_f_24122}});
  }
  case TAG_EBytes: {
    return ((HeffT2){{v_x1_240, v_st_241}});
  }
  case TAG_EFixed: {
    return ((HeffT2){{v_x1_240, v_st_241}});
  }
  case TAG_EFloat32: {
    return ((HeffT2){{v_x1_240, v_st_241}});
  }
  case TAG_EAbandon: {
    return ((HeffT2){{v_x1_240, v_st_241}});
  }
  case TAG_EBool: {
    V v_c_24127 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24EBool = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    HeffT2 v_t_24128 = (g_heff_2ecompile_2espec_2eshapeCond_24cpr(((V)&g_heff_2ecompile_2espec_2eshapeGo_clo), v_c_24127, v_st_241));
    {
      V v_field_24129 = v_t_24128.f[0];
      V v_field_24130 = v_t_24128.f[1];
      V v_c_24131 = v_field_24129;
      V v_st_24132 = v_field_24130;
      return ((HeffT2){{heff_tag_at_n(v_ru_24x1_240_24EBool, TAG_EBool, 1, (V[]){v_c_24131}), v_st_24132}});
    }
  }
  case TAG_ESet: {
    V v_xs_24133 = heff_field(v_x1_240, 0);
    V v_a_24134 = heff_field(v_x1_240, 1);
    V v_b_24135 = heff_field(v_x1_240, 2);
    heff_take_n(v_x1_240, 7ULL, 3);
    V v_t_24136 = (g_heff_2ecompile_2espec_2eshapeGo(v_a_24134, v_st_241));
    return ({ V a_0 = ((V)&g_heff_2ecompile_2espec_2eshapeGo_clo); V a_1 = v_xs_24133; V a_2 = v_b_24135; V a_3 = v_t_24136; HeffT2 r_ = (g_heff_2ecompile_2espec_2esetThen_24cpr(a_0, a_1, a_2, a_3)); heff_drop(v_xs_24133); r_; });
  }
  case TAG_EValues: {
    V v_es_24137 = heff_field(v_x1_240, 0);
    V v_ru_24x1_240_24EValues = heff_take_reuse_n(v_x1_240, 1ULL, 1);
    HeffT2 v_t_24138 = (g_heff_2ecompile_2espec_2eshapeMany_24cpr(((V)&g_heff_2ecompile_2espec_2eshapeGo_clo), v_es_24137, v_st_241));
    {
      V v_field_24139 = v_t_24138.f[0];
      V v_field_24140 = v_t_24138.f[1];
      V v_es_24141 = v_field_24139;
      V v_st_24142 = v_field_24140;
      return ((HeffT2){{heff_tag_at_n(v_ru_24x1_240_24EValues, TAG_EValues, 1, (V[]){v_es_24141}), v_st_24142}});
    }
  }
  case TAG_EFix: {
    return ((HeffT2){{v_x1_240, v_st_241}});
  }
  default: return ((HeffT2){{heff_nomatch(v_x1_240)}});
  }
}
Clo g_heff_2ecompile_2espec_2eshapeGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2espec_2eshapeGo_entry, 2, 0};

V g_heff_2ecompile_2espec_2eshapeGo(V v_x1_240, V v_st_241) {
top: ;
  HeffT2 v_t_242 = (g_heff_2ecompile_2espec_2eshapeGo_24cpr(v_x1_240, v_st_241));
  {
    V v_field_243 = v_t_242.f[0];
    V v_field_244 = v_t_242.f[1];
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_field_243, v_field_244});
  }
}
V g_heff_2ecompile_2espec_2eshapeGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2espec_2eshapeGo(a[0], a[1]);
}
Clo g_heff_2ecompile_2espec_2ecallUse_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2espec_2ecallUse_entry, 3, 0};

V g_heff_2ecompile_2espec_2ecallUse(V v_g_240, V v_x2_241, V v_args_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_EVar: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_args_242);
    return NTAG(TAG_Nil);
  }
  case TAG_EGlobal: {
    V v_h_244 = heff_field(v_x2_241, 0);
    V v_ru_24x2_241_24EGlobal = heff_take_reuse_n(v_x2_241, 1ULL, 1);
    if (heff_strEq_c_lent(v_h_244, v_g_240, 1)) {
      return heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x2_241_24EGlobal, TAG_Just, 1, (V[]){v_args_242}), NTAG(TAG_Nil)});
    } else {
      heff_drop(v_args_242);
      heff_drop_cell(v_ru_24x2_241_24EGlobal, 1);
      return NTAG(TAG_Nil);
    }
  }
  case TAG_ELam: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_args_242);
    return NTAG(TAG_Nil);
  }
  case TAG_EApp: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_args_242);
    return NTAG(TAG_Nil);
  }
  case TAG_ELet: {
    heff_take_n(v_x2_241, 0ULL, 3);
    heff_drop(v_args_242);
    return NTAG(TAG_Nil);
  }
  case TAG_ERecord: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_args_242);
    return NTAG(TAG_Nil);
  }
  case TAG_EProj: {
    heff_take_n(v_x2_241, 0ULL, 4);
    heff_drop(v_args_242);
    return NTAG(TAG_Nil);
  }
  case TAG_ETag: {
    heff_take_n(v_x2_241, 0ULL, 3);
    heff_drop(v_args_242);
    return NTAG(TAG_Nil);
  }
  case TAG_EMatch: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_args_242);
    return NTAG(TAG_Nil);
  }
  case TAG_EPrim: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_args_242);
    return NTAG(TAG_Nil);
  }
  case TAG_EPrimCall: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_args_242);
    return NTAG(TAG_Nil);
  }
  case TAG_ECall: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_args_242);
    return NTAG(TAG_Nil);
  }
  case TAG_EInt: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_args_242);
    return NTAG(TAG_Nil);
  }
  case TAG_EFloat: {
    heff_take_na(v_x2_241, 0ULL, 1);
    heff_drop(v_args_242);
    return NTAG(TAG_Nil);
  }
  case TAG_EStr: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_args_242);
    return NTAG(TAG_Nil);
  }
  case TAG_EBytes: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_args_242);
    return NTAG(TAG_Nil);
  }
  case TAG_EFixed: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_args_242);
    return NTAG(TAG_Nil);
  }
  case TAG_EFloat32: {
    heff_take_na(v_x2_241, 0ULL, 1);
    heff_drop(v_args_242);
    return NTAG(TAG_Nil);
  }
  case TAG_EAbandon: {
    heff_drop(v_args_242);
    return NTAG(TAG_Nil);
  }
  case TAG_EBool: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_args_242);
    return NTAG(TAG_Nil);
  }
  case TAG_ESet: {
    heff_take_n(v_x2_241, 0ULL, 3);
    heff_drop(v_args_242);
    return NTAG(TAG_Nil);
  }
  case TAG_EValues: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_args_242);
    return NTAG(TAG_Nil);
  }
  case TAG_EFix: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_args_242);
    return NTAG(TAG_Nil);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2espec_2ecallUse_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2espec_2ecallUse(a0, a[1], a[2]); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2espec_2eheadUses_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2espec_2eheadUses_entry, 2, 0};

V g_heff_2ecompile_2espec_2eheadUses(V v_go_240, V v_f_241) {
top: ;
  switch (heff_tag_of(v_f_241)) {
  case TAG_EVar: {
    return heff_tail(v_go_240, 1, (V[]){v_f_241});
  }
  case TAG_EGlobal: {
    heff_take_n(v_f_241, 0ULL, 1);
    heff_drop(v_go_240);
    return NTAG(TAG_Nil);
  }
  case TAG_ELam: {
    return heff_tail(v_go_240, 1, (V[]){v_f_241});
  }
  case TAG_EApp: {
    return heff_tail(v_go_240, 1, (V[]){v_f_241});
  }
  case TAG_ELet: {
    return heff_tail(v_go_240, 1, (V[]){v_f_241});
  }
  case TAG_ERecord: {
    return heff_tail(v_go_240, 1, (V[]){v_f_241});
  }
  case TAG_EProj: {
    return heff_tail(v_go_240, 1, (V[]){v_f_241});
  }
  case TAG_ETag: {
    return heff_tail(v_go_240, 1, (V[]){v_f_241});
  }
  case TAG_EMatch: {
    return heff_tail(v_go_240, 1, (V[]){v_f_241});
  }
  case TAG_EPrim: {
    return heff_tail(v_go_240, 1, (V[]){v_f_241});
  }
  case TAG_EPrimCall: {
    return heff_tail(v_go_240, 1, (V[]){v_f_241});
  }
  case TAG_ECall: {
    return heff_tail(v_go_240, 1, (V[]){v_f_241});
  }
  case TAG_EInt: {
    return heff_tail(v_go_240, 1, (V[]){v_f_241});
  }
  case TAG_EFloat: {
    return heff_tail(v_go_240, 1, (V[]){v_f_241});
  }
  case TAG_EStr: {
    return heff_tail(v_go_240, 1, (V[]){v_f_241});
  }
  case TAG_EBytes: {
    return heff_tail(v_go_240, 1, (V[]){v_f_241});
  }
  case TAG_EFixed: {
    return heff_tail(v_go_240, 1, (V[]){v_f_241});
  }
  case TAG_EFloat32: {
    return heff_tail(v_go_240, 1, (V[]){v_f_241});
  }
  case TAG_EAbandon: {
    return heff_tail(v_go_240, 1, (V[]){v_f_241});
  }
  case TAG_EBool: {
    return heff_tail(v_go_240, 1, (V[]){v_f_241});
  }
  case TAG_ESet: {
    return heff_tail(v_go_240, 1, (V[]){v_f_241});
  }
  case TAG_EValues: {
    return heff_tail(v_go_240, 1, (V[]){v_f_241});
  }
  case TAG_EFix: {
    return heff_tail(v_go_240, 1, (V[]){v_f_241});
  }
  default: return heff_nomatch(v_f_241);
  }
}
V g_heff_2ecompile_2espec_2eheadUses_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2espec_2eheadUses(a[0], a[1]);
}
V g_heff_2ecompile_2espec_2eusesOf_lam0(V self, V *args);
V g_heff_2ecompile_2espec_2eusesOf_lam1(V self, V *args);
V g_heff_2ecompile_2espec_2eusesOf_lam2(V self, V *args);
V g_heff_2ecompile_2espec_2eusesOf_lam3(V self, V *args);
V g_heff_2ecompile_2espec_2eusesOf_lam4(V self, V *args);
V g_heff_2ecompile_2espec_2eusesOf_lam5(V self, V *args);
V g_heff_2ecompile_2espec_2eusesOf_lam6(V self, V *args);
V g_heff_2ecompile_2espec_2eusesOf_lam7(V self, V *args);
Clo g_heff_2ecompile_2espec_2eusesOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2espec_2eusesOf_entry, 2, 0};

V g_heff_2ecompile_2espec_2eusesOf(V v_g_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_EVar: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_g_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EGlobal: {
    V v_h_243 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    if (heff_strEq_c(v_h_243, v_g_240)) {
      return heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_Nothing), NTAG(TAG_Nil)});
    } else {
      return NTAG(TAG_Nil);
    }
  }
  case TAG_ELam: {
    V v_b_245 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 2ULL, 2);
    V t_0 = v_g_240;
    V t_1 = v_b_245;
    v_g_240 = t_0;
    v_x2_241 = t_1;
    goto top;
  }
  case TAG_EApp: {
    V v_f_246 = heff_field(v_x2_241, 0);
    V v_args_247 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24EApp = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_248 = (g_heff_2ecompile_2espec_2ecallUse(v_g_240, heff_dup(v_f_246), heff_dup(v_args_247)));
    V v_t_249 = heff_tr(heff_call(((V)&g_heff_2ecompile_2espec_2eusesOf_clo), 1, (V[]){heff_dup(v_g_240)}));
    V v_t_2410 = heff_tr(g_heff_2ecompile_2espec_2eheadUses(v_t_249, v_f_246));
    V v_f_2411 = heff_tr(heff_call(((V)&g_heff_2ecompile_2espec_2eusesOf_clo), 1, (V[]){v_g_240}));
    V v_t_2412 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_args_247));
    V v_t_2416 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2espec_2eusesOf_lam0, 2, 1, (V[]){v_f_2411}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_2412; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2412); r_; });
    V v_t_2417 = (g_heff_2ecompile_2espec_2eappendS_24tok2(v_ru_24x2_241_24EApp, v_t_2410, v_t_2416));
    HEFF_LAST return g_heff_2ecompile_2espec_2eappendS(v_t_248, v_t_2417);
  }
  case TAG_ELet: {
    V v_a_2419 = heff_field(v_x2_241, 1);
    V v_b_2420 = heff_field(v_x2_241, 2);
    heff_take_n(v_x2_241, 6ULL, 3);
    V v_t_2421 = (g_heff_2ecompile_2espec_2eusesOf(heff_dup(v_g_240), v_a_2419));
    V v_t_2422 = (g_heff_2ecompile_2espec_2eusesOf(v_g_240, v_b_2420));
    HEFF_LAST return g_heff_2ecompile_2espec_2eappendS(v_t_2421, v_t_2422);
  }
  case TAG_ERecord: {
    V v_fs_2423 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 2);
    V v_f_2425 = heff_tr(heff_call(((V)&g_heff_2ecompile_2espec_2eusesOf_clo), 1, (V[]){v_g_240}));
    V v_t_2426 = (g_list_2efoldl_24f1645967390x252727070(NTAG(TAG_Nil), v_fs_2423));
    return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2espec_2eusesOf_lam1, 2, 1, (V[]){v_f_2425}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_2426; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2426); r_; });
  }
  case TAG_EProj: {
    V v_e_2430 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 4);
    V t_0 = v_g_240;
    V t_1 = v_e_2430;
    v_g_240 = t_0;
    v_x2_241 = t_1;
    goto top;
  }
  case TAG_ETag: {
    V v_args_2435 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 2ULL, 3);
    V v_f_2437 = heff_tr(heff_call(((V)&g_heff_2ecompile_2espec_2eusesOf_clo), 1, (V[]){v_g_240}));
    V v_t_2438 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_args_2435));
    return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2espec_2eusesOf_lam2, 2, 1, (V[]){v_f_2437}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_2438; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2438); r_; });
  }
  case TAG_EMatch: {
    V v_s_2442 = heff_field(v_x2_241, 0);
    V v_arms_2443 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24EMatch = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_2444 = (g_heff_2ecompile_2espec_2eusesOf(heff_dup(v_g_240), v_s_2442));
    V v_f_2445 = heff_tr(heff_call(((V)&g_heff_2ecompile_2espec_2eusesOf_clo), 1, (V[]){v_g_240}));
    V v_t_2446 = (g_list_2efoldl_24f836170601x1639498774(NTAG(TAG_Nil), v_arms_2443));
    V v_t_2450 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2espec_2eusesOf_lam3, 2, 1, (V[]){v_f_2445}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_2446; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2446); r_; });
    return (g_heff_2ecompile_2espec_2eappendS_24tok2(v_ru_24x2_241_24EMatch, v_t_2444, v_t_2450));
  }
  case TAG_EPrim: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_g_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EPrimCall: {
    V v_args_2453 = heff_field(v_x2_241, 1);
    heff_take_n(v_x2_241, 2ULL, 2);
    V v_f_2454 = heff_tr(heff_call(((V)&g_heff_2ecompile_2espec_2eusesOf_clo), 1, (V[]){v_g_240}));
    V v_t_2455 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_args_2453));
    return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2espec_2eusesOf_lam4, 2, 1, (V[]){v_f_2454}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_2455; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2455); r_; });
  }
  case TAG_ECall: {
    V v_h_2459 = heff_field(v_x2_241, 0);
    V v_args_2460 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24ECall = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_2461;
    if (heff_strEq_c_lent(v_h_2459, v_g_240, 1)) {
      v_t_2461 = heff_tag_at_n(v_ru_24x2_241_24ECall, TAG_Cons, 2, (V[]){heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_args_2460)}), NTAG(TAG_Nil)});
    } else {
      heff_drop_cell(v_ru_24x2_241_24ECall, 2);
      v_t_2461 = NTAG(TAG_Nil);
    }
    V v_f_2462 = heff_tr(heff_call(((V)&g_heff_2ecompile_2espec_2eusesOf_clo), 1, (V[]){v_g_240}));
    V v_t_2463 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_args_2460));
    V v_t_2467 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2espec_2eusesOf_lam5, 2, 1, (V[]){v_f_2462}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_2463; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2463); r_; });
    HEFF_LAST return g_heff_2ecompile_2espec_2eappendS(v_t_2461, v_t_2467);
  }
  case TAG_EInt: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_g_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EFloat: {
    heff_take_na(v_x2_241, 0ULL, 1);
    heff_drop(v_g_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EStr: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_g_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EBytes: {
    heff_take_n(v_x2_241, 0ULL, 1);
    heff_drop(v_g_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EFixed: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_g_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EFloat32: {
    heff_take_na(v_x2_241, 0ULL, 1);
    heff_drop(v_g_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EAbandon: {
    heff_drop(v_g_240);
    return NTAG(TAG_Nil);
  }
  case TAG_EBool: {
    V v_c_2475 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    V v_f_2476 = heff_tr(heff_call(((V)&g_heff_2ecompile_2espec_2eusesOf_clo), 1, (V[]){v_g_240}));
    V v_xs_2477 = ({ V a_0 = v_c_2475; V a_1 = NTAG(TAG_Nil); V r_ = (g_heff_2ecompile_2eir_2econdOnto(a_0, a_1)); heff_drop(v_c_2475); r_; });
    V v_t_2478 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_2477));
    return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2espec_2eusesOf_lam6, 2, 1, (V[]){v_f_2476}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_2478; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2478); r_; });
  }
  case TAG_ESet: {
    V v_a_2483 = heff_field(v_x2_241, 1);
    V v_b_2484 = heff_field(v_x2_241, 2);
    heff_take_n(v_x2_241, 6ULL, 3);
    V v_t_2485 = (g_heff_2ecompile_2espec_2eusesOf(heff_dup(v_g_240), v_a_2483));
    V v_t_2486 = (g_heff_2ecompile_2espec_2eusesOf(v_g_240, v_b_2484));
    HEFF_LAST return g_heff_2ecompile_2espec_2eappendS(v_t_2485, v_t_2486);
  }
  case TAG_EValues: {
    V v_es_2487 = heff_field(v_x2_241, 0);
    heff_take_n(v_x2_241, 1ULL, 1);
    V v_f_2488 = heff_tr(heff_call(((V)&g_heff_2ecompile_2espec_2eusesOf_clo), 1, (V[]){v_g_240}));
    V v_t_2489 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_es_2487));
    return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2espec_2eusesOf_lam7, 2, 1, (V[]){v_f_2488}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_2489; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2489); r_; });
  }
  case TAG_EFix: {
    heff_take_n(v_x2_241, 0ULL, 2);
    heff_drop(v_g_240);
    return NTAG(TAG_Nil);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2espec_2eusesOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2espec_2eusesOf(a[0], a[1]);
}
V g_heff_2ecompile_2espec_2eusesOf_lam0(V self, V *args) {
  V v_acc_2413 = args[0];
  V v_x_2414 = args[1];
  V v_f_2411 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2415 = heff_tr(heff_call(v_f_2411, 1, (V[]){v_x_2414}));
  return (g_prelude_2e_2b_2b(v_t_2415, v_acc_2413));
}
V g_heff_2ecompile_2espec_2eusesOf_lam1(V self, V *args) {
  V v_acc_2427 = args[0];
  V v_x_2428 = args[1];
  V v_f_2425 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2429 = heff_tr(heff_call(v_f_2425, 1, (V[]){v_x_2428}));
  return (g_prelude_2e_2b_2b(v_t_2429, v_acc_2427));
}
V g_heff_2ecompile_2espec_2eusesOf_lam2(V self, V *args) {
  V v_acc_2439 = args[0];
  V v_x_2440 = args[1];
  V v_f_2437 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2441 = heff_tr(heff_call(v_f_2437, 1, (V[]){v_x_2440}));
  return (g_prelude_2e_2b_2b(v_t_2441, v_acc_2439));
}
V g_heff_2ecompile_2espec_2eusesOf_lam3(V self, V *args) {
  V v_acc_2447 = args[0];
  V v_x_2448 = args[1];
  V v_f_2445 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2449 = heff_tr(heff_call(v_f_2445, 1, (V[]){v_x_2448}));
  return (g_prelude_2e_2b_2b(v_t_2449, v_acc_2447));
}
V g_heff_2ecompile_2espec_2eusesOf_lam4(V self, V *args) {
  V v_acc_2456 = args[0];
  V v_x_2457 = args[1];
  V v_f_2454 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2458 = heff_tr(heff_call(v_f_2454, 1, (V[]){v_x_2457}));
  return (g_prelude_2e_2b_2b(v_t_2458, v_acc_2456));
}
V g_heff_2ecompile_2espec_2eusesOf_lam5(V self, V *args) {
  V v_acc_2464 = args[0];
  V v_x_2465 = args[1];
  V v_f_2462 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2466 = heff_tr(heff_call(v_f_2462, 1, (V[]){v_x_2465}));
  return (g_prelude_2e_2b_2b(v_t_2466, v_acc_2464));
}
V g_heff_2ecompile_2espec_2eusesOf_lam6(V self, V *args) {
  V v_acc_2479 = args[0];
  V v_x_2480 = args[1];
  V v_f_2476 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2481 = heff_tr(heff_call(v_f_2476, 1, (V[]){v_x_2480}));
  return (g_prelude_2e_2b_2b(v_t_2481, v_acc_2479));
}
V g_heff_2ecompile_2espec_2eusesOf_lam7(V self, V *args) {
  V v_acc_2490 = args[0];
  V v_x_2491 = args[1];
  V v_f_2488 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2492 = heff_tr(heff_call(v_f_2488, 1, (V[]){v_x_2491}));
  return (g_prelude_2e_2b_2b(v_t_2492, v_acc_2490));
}
Clo g_heff_2ecompile_2espec_2enthS_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2espec_2enthS_entry, 2, 0};

V g_heff_2ecompile_2espec_2enthS(V v_i_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_i_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    if (heff_intEq_c_lent(v_i_240, MK_INT(0LL), 2)) {
      heff_drop(v_i_240);
      return heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_x_242)});
    } else {
      V t_0 = heff_intSub(v_i_240, MK_INT(1LL));
      V t_1 = v_xs_243;
      v_i_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2espec_2enthS_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2espec_2enthS(a[0], a1); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2espec_2eisVarOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2espec_2eisVarOf_entry, 2, 0};

V g_heff_2ecompile_2espec_2eisVarOf(V v_x_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nothing: {
    return NTAG(TAG_False);
  }
  case TAG_Just: {
    V v_x21_242 = heff_field(v_x2_241, 0);
    switch (heff_tag_of(v_x21_242)) {
    case TAG_EVar: {
      V v_y_243 = heff_field(v_x21_242, 0);
      V v_ret_24bool = heff_bool(heff_strEq_c_lent(v_x_240, v_y_243, 0));
      return v_ret_24bool;
    }
    case TAG_EGlobal: {
      return NTAG(TAG_False);
    }
    case TAG_ELam: {
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      return NTAG(TAG_False);
    }
    case TAG_EPrimCall: {
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      return NTAG(TAG_False);
    }
    case TAG_EFloat: {
      return NTAG(TAG_False);
    }
    case TAG_EStr: {
      return NTAG(TAG_False);
    }
    case TAG_EBytes: {
      return NTAG(TAG_False);
    }
    case TAG_EFixed: {
      return NTAG(TAG_False);
    }
    case TAG_EFloat32: {
      return NTAG(TAG_False);
    }
    case TAG_EAbandon: {
      return NTAG(TAG_False);
    }
    case TAG_EBool: {
      return NTAG(TAG_False);
    }
    case TAG_ESet: {
      return NTAG(TAG_False);
    }
    case TAG_EValues: {
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x21_242);
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2espec_2eisVarOf_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2espec_2eisVarOf(a0, a1); heff_drop(a0); heff_drop(a1); return r;
}
V g_heff_2ecompile_2espec_2estaticGo_lam0(V self, V *args);
Clo g_heff_2ecompile_2espec_2estaticGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2espec_2estaticGo_entry, 3, 0};

V g_heff_2ecompile_2espec_2estaticGo(V v_uses_240, V v_x2_241, V v_i_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_i_242);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_248 = (g_heff_2ecompile_2espec_2eallS(heff_clo_n(g_heff_2ecompile_2espec_2estaticGo_lam0, 1, 2, (V[]){heff_dup(v_i_242), v_x_243}), v_uses_240));
    V v_cell_249 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_248, heff_hole()});
    V v_u_2410 = (g_heff_2ecompile_2espec_2estaticGo_24dps(v_uses_240, v_xs_244, heff_box_word((heff_unbox_word(v_i_242) + ((int64_t)1ULL))), heff_dup(v_cell_249)));
    heff_drop(v_u_2410);
    return v_cell_249;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2espec_2estaticGo_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2espec_2estaticGo(a0, a[1], a[2]); heff_drop(a0); return r;
}
V g_heff_2ecompile_2espec_2estaticGo_lam0(V self, V *args) {
  V v_x3_245 = args[0];
  V v_i_242 = heff_env(self)[0];
  V v_x_243 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_x3_245)) {
  case TAG_Nothing: {
    heff_drop(v_i_242);
    heff_drop(v_x_243);
    return NTAG(TAG_False);
  }
  case TAG_Just: {
    V v_args_246 = heff_field(v_x3_245, 0);
    heff_take_n(v_x3_245, 1ULL, 1);
    V v_t_247 = ({ V a_0 = v_i_242; V a_1 = v_args_246; V r_ = (g_heff_2ecompile_2espec_2enthS(a_0, a_1)); heff_drop(v_args_246); r_; });
    return ({ V a_0 = v_x_243; V a_1 = v_t_247; V r_ = (g_heff_2ecompile_2espec_2eisVarOf(a_0, a_1)); heff_drop(v_x_243); heff_drop(v_t_247); r_; });
  }
  default: return heff_nomatch(v_x3_245);
  }
}
V g_heff_2ecompile_2espec_2estaticGo_24dps_lam0(V self, V *args);
Clo g_heff_2ecompile_2espec_2estaticGo_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2espec_2estaticGo_24dps_entry, 4, 0};

V g_heff_2ecompile_2espec_2estaticGo_24dps(V v_uses_240, V v_x2_241, V v_i_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_i_242);
    return heff_setField(v_d_243, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_241, 0);
    V v_xs_245 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_249 = (g_heff_2ecompile_2espec_2eallS(heff_clo_n(g_heff_2ecompile_2espec_2estaticGo_24dps_lam0, 1, 2, (V[]){heff_dup(v_i_242), v_x_244}), v_uses_240));
    V v_cell_2410 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_249, heff_hole()});
    V v_u_2411 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_2410));
    heff_drop(v_u_2411);
    V t_0 = v_uses_240;
    V t_1 = v_xs_245;
    V t_2 = heff_intAdd(v_i_242, MK_INT(1LL));
    V t_3 = v_cell_2410;
    v_uses_240 = t_0;
    v_x2_241 = t_1;
    v_i_242 = t_2;
    v_d_243 = t_3;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2espec_2estaticGo_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2espec_2estaticGo_24dps(a0, a[1], a[2], a[3]); heff_drop(a0); return r;
}
V g_heff_2ecompile_2espec_2estaticGo_24dps_lam0(V self, V *args) {
  V v_x3_246 = args[0];
  V v_i_242 = heff_env(self)[0];
  V v_x_244 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_x3_246)) {
  case TAG_Nothing: {
    heff_drop(v_i_242);
    heff_drop(v_x_244);
    return NTAG(TAG_False);
  }
  case TAG_Just: {
    V v_args_247 = heff_field(v_x3_246, 0);
    heff_take_n(v_x3_246, 1ULL, 1);
    V v_t_248 = ({ V a_0 = v_i_242; V a_1 = v_args_247; V r_ = (g_heff_2ecompile_2espec_2enthS(a_0, a_1)); heff_drop(v_args_247); r_; });
    return ({ V a_0 = v_x_244; V a_1 = v_t_248; V r_ = (g_heff_2ecompile_2espec_2eisVarOf(a_0, a_1)); heff_drop(v_x_244); heff_drop(v_t_248); r_; });
  }
  default: return heff_nomatch(v_x3_246);
  }
}
Clo g_heff_2ecompile_2espec_2edropAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2espec_2edropAt_entry, 2, 0};

V g_heff_2ecompile_2espec_2edropAt(V v_x1_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return v_x2_241;
  }
  case TAG_Cons: {
    V v_d_242 = heff_field(v_x1_240, 0);
    V v_ds_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      heff_drop(v_d_242);
      heff_drop(v_ds_243);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_a_244 = heff_field(v_x2_241, 0);
      V v_args_245 = heff_field(v_x2_241, 1);
      heff_take_n(v_x2_241, 3ULL, 2);
      if ((heff_dup(v_d_242) == NTAG(TAG_True))) {
        heff_drop(v_d_242);
        heff_drop_cell(v_ru_24x1_240_24Cons, 2);
        heff_drop(v_a_244);
        V t_0 = v_ds_243;
        V t_1 = v_args_245;
        v_x1_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      } else {
        heff_drop(v_d_242);
        V v_cell_246 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_a_244, heff_hole()});
        V v_u_247 = (g_heff_2ecompile_2espec_2edropAt_24dps(v_ds_243, v_args_245, heff_dup(v_cell_246)));
        heff_drop(v_u_247);
        return v_cell_246;
      }
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2espec_2edropAt_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2espec_2edropAt(a[0], a[1]);
}
Clo g_heff_2ecompile_2espec_2edropAt_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2espec_2edropAt_24dps_entry, 3, 0};

V g_heff_2ecompile_2espec_2edropAt_24dps(V v_x1_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_242, MK_INT(1LL), v_x2_241);
  }
  case TAG_Cons: {
    V v_d_243 = heff_field(v_x1_240, 0);
    V v_ds_244 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      heff_drop(v_d_243);
      heff_drop(v_ds_244);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_Cons: {
      V v_a_245 = heff_field(v_x2_241, 0);
      V v_args_246 = heff_field(v_x2_241, 1);
      heff_take_n(v_x2_241, 3ULL, 2);
      if ((heff_dup(v_d_243) == NTAG(TAG_True))) {
        heff_drop(v_d_243);
        heff_drop_cell(v_ru_24x1_240_24Cons, 2);
        heff_drop(v_a_245);
        V t_0 = v_ds_244;
        V t_1 = v_args_246;
        V t_2 = v_d_242;
        v_x1_240 = t_0;
        v_x2_241 = t_1;
        v_d_242 = t_2;
        goto top;
      } else {
        heff_drop(v_d_243);
        V v_cell_247 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_a_245, heff_hole()});
        V v_u_248 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_247));
        heff_drop(v_u_248);
        V t_0 = v_ds_244;
        V t_1 = v_args_246;
        V t_2 = v_cell_247;
        v_x1_240 = t_0;
        v_x2_241 = t_1;
        v_d_242 = t_2;
        goto top;
      }
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2espec_2edropAt_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2espec_2edropAt_24dps(a[0], a[1], a[2]);
}
Clo g_heff_2ecompile_2espec_2eselfHead_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2espec_2eselfHead_entry, 4, 0};

V g_heff_2ecompile_2espec_2eselfHead(V v_go_240, V v_g_241, V v_h_242, V v_f_243) {
top: ;
  switch (heff_tag_of(v_f_243)) {
  case TAG_EVar: {
    heff_drop(v_h_242);
    return heff_tail(v_go_240, 1, (V[]){v_f_243});
  }
  case TAG_EGlobal: {
    V v_k_245 = heff_field(v_f_243, 0);
    V v_ru_24f_243_24EGlobal = heff_take_reuse_n(v_f_243, 1ULL, 1);
    heff_drop(v_go_240);
    V v_t_246;
    if (heff_strEq_c_lent(v_k_245, v_g_241, 0)) {
      heff_drop(v_k_245);
      v_t_246 = v_h_242;
    } else {
      heff_drop(v_h_242);
      v_t_246 = v_k_245;
    }
    return heff_tag_at_n(v_ru_24f_243_24EGlobal, TAG_EGlobal, 1, (V[]){v_t_246});
  }
  case TAG_ELam: {
    heff_drop(v_h_242);
    return heff_tail(v_go_240, 1, (V[]){v_f_243});
  }
  case TAG_EApp: {
    heff_drop(v_h_242);
    return heff_tail(v_go_240, 1, (V[]){v_f_243});
  }
  case TAG_ELet: {
    heff_drop(v_h_242);
    return heff_tail(v_go_240, 1, (V[]){v_f_243});
  }
  case TAG_ERecord: {
    heff_drop(v_h_242);
    return heff_tail(v_go_240, 1, (V[]){v_f_243});
  }
  case TAG_EProj: {
    heff_drop(v_h_242);
    return heff_tail(v_go_240, 1, (V[]){v_f_243});
  }
  case TAG_ETag: {
    heff_drop(v_h_242);
    return heff_tail(v_go_240, 1, (V[]){v_f_243});
  }
  case TAG_EMatch: {
    heff_drop(v_h_242);
    return heff_tail(v_go_240, 1, (V[]){v_f_243});
  }
  case TAG_EPrim: {
    heff_drop(v_h_242);
    return heff_tail(v_go_240, 1, (V[]){v_f_243});
  }
  case TAG_EPrimCall: {
    heff_drop(v_h_242);
    return heff_tail(v_go_240, 1, (V[]){v_f_243});
  }
  case TAG_ECall: {
    heff_drop(v_h_242);
    return heff_tail(v_go_240, 1, (V[]){v_f_243});
  }
  case TAG_EInt: {
    heff_drop(v_h_242);
    return heff_tail(v_go_240, 1, (V[]){v_f_243});
  }
  case TAG_EFloat: {
    heff_drop(v_h_242);
    return heff_tail(v_go_240, 1, (V[]){v_f_243});
  }
  case TAG_EStr: {
    heff_drop(v_h_242);
    return heff_tail(v_go_240, 1, (V[]){v_f_243});
  }
  case TAG_EBytes: {
    heff_drop(v_h_242);
    return heff_tail(v_go_240, 1, (V[]){v_f_243});
  }
  case TAG_EFixed: {
    heff_drop(v_h_242);
    return heff_tail(v_go_240, 1, (V[]){v_f_243});
  }
  case TAG_EFloat32: {
    heff_drop(v_h_242);
    return heff_tail(v_go_240, 1, (V[]){v_f_243});
  }
  case TAG_EAbandon: {
    heff_drop(v_h_242);
    return heff_tail(v_go_240, 1, (V[]){v_f_243});
  }
  case TAG_EBool: {
    heff_drop(v_h_242);
    return heff_tail(v_go_240, 1, (V[]){v_f_243});
  }
  case TAG_ESet: {
    heff_drop(v_h_242);
    return heff_tail(v_go_240, 1, (V[]){v_f_243});
  }
  case TAG_EValues: {
    heff_drop(v_h_242);
    return heff_tail(v_go_240, 1, (V[]){v_f_243});
  }
  case TAG_EFix: {
    heff_drop(v_h_242);
    return heff_tail(v_go_240, 1, (V[]){v_f_243});
  }
  default: return heff_nomatch(v_f_243);
  }
}
V g_heff_2ecompile_2espec_2eselfHead_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2espec_2eselfHead(a[0], a1, a[2], a[3]); heff_drop(a1); return r;
}
Clo g_heff_2ecompile_2espec_2eselfArgs_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2espec_2eselfArgs_entry, 5, 0};

V g_heff_2ecompile_2espec_2eselfArgs(V v_g_240, V v_pre_241, V v_ds_242, V v_f_243, V v_args_244) {
top: ;
  switch (heff_tag_of(v_f_243)) {
  case TAG_EVar: {
    heff_drop(v_pre_241);
    heff_drop(v_ds_242);
    return v_args_244;
  }
  case TAG_EGlobal: {
    V v_k_246 = heff_field(v_f_243, 0);
    if (heff_strEq_c_lent(v_k_246, v_g_240, 0)) {
      V v_t_247 = (g_heff_2ecompile_2espec_2edropAt(v_ds_242, v_args_244));
      return (g_heff_2ecompile_2espec_2eappendS(v_pre_241, v_t_247));
    } else {
      heff_drop(v_pre_241);
      heff_drop(v_ds_242);
      return v_args_244;
    }
  }
  case TAG_ELam: {
    heff_drop(v_pre_241);
    heff_drop(v_ds_242);
    return v_args_244;
  }
  case TAG_EApp: {
    heff_drop(v_pre_241);
    heff_drop(v_ds_242);
    return v_args_244;
  }
  case TAG_ELet: {
    heff_drop(v_pre_241);
    heff_drop(v_ds_242);
    return v_args_244;
  }
  case TAG_ERecord: {
    heff_drop(v_pre_241);
    heff_drop(v_ds_242);
    return v_args_244;
  }
  case TAG_EProj: {
    heff_drop(v_pre_241);
    heff_drop(v_ds_242);
    return v_args_244;
  }
  case TAG_ETag: {
    heff_drop(v_pre_241);
    heff_drop(v_ds_242);
    return v_args_244;
  }
  case TAG_EMatch: {
    heff_drop(v_pre_241);
    heff_drop(v_ds_242);
    return v_args_244;
  }
  case TAG_EPrim: {
    heff_drop(v_pre_241);
    heff_drop(v_ds_242);
    return v_args_244;
  }
  case TAG_EPrimCall: {
    heff_drop(v_pre_241);
    heff_drop(v_ds_242);
    return v_args_244;
  }
  case TAG_ECall: {
    heff_drop(v_pre_241);
    heff_drop(v_ds_242);
    return v_args_244;
  }
  case TAG_EInt: {
    heff_drop(v_pre_241);
    heff_drop(v_ds_242);
    return v_args_244;
  }
  case TAG_EFloat: {
    heff_drop(v_pre_241);
    heff_drop(v_ds_242);
    return v_args_244;
  }
  case TAG_EStr: {
    heff_drop(v_pre_241);
    heff_drop(v_ds_242);
    return v_args_244;
  }
  case TAG_EBytes: {
    heff_drop(v_pre_241);
    heff_drop(v_ds_242);
    return v_args_244;
  }
  case TAG_EFixed: {
    heff_drop(v_pre_241);
    heff_drop(v_ds_242);
    return v_args_244;
  }
  case TAG_EFloat32: {
    heff_drop(v_pre_241);
    heff_drop(v_ds_242);
    return v_args_244;
  }
  case TAG_EAbandon: {
    heff_drop(v_pre_241);
    heff_drop(v_ds_242);
    return v_args_244;
  }
  case TAG_EBool: {
    heff_drop(v_pre_241);
    heff_drop(v_ds_242);
    return v_args_244;
  }
  case TAG_ESet: {
    heff_drop(v_pre_241);
    heff_drop(v_ds_242);
    return v_args_244;
  }
  case TAG_EValues: {
    heff_drop(v_pre_241);
    heff_drop(v_ds_242);
    return v_args_244;
  }
  case TAG_EFix: {
    heff_drop(v_pre_241);
    heff_drop(v_ds_242);
    return v_args_244;
  }
  default: return heff_nomatch(v_f_243);
  }
}
V g_heff_2ecompile_2espec_2eselfArgs_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a3 = a[3]; V r = g_heff_2ecompile_2espec_2eselfArgs(a0, a[1], a[2], a3, a[4]); heff_drop(a0); heff_drop(a3); return r;
}
V g_heff_2ecompile_2espec_2eselfTo_lam0(V self, V *args);
V g_heff_2ecompile_2espec_2eselfTo_lam1(V self, V *args);
Clo g_heff_2ecompile_2espec_2eselfTo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2espec_2eselfTo_entry, 5, 0};

V g_heff_2ecompile_2espec_2eselfTo(V v_g_240, V v_h_241, V v_pre_242, V v_ds_243, V v_x5_244) {
top: ;
  switch (heff_tag_of(v_x5_244)) {
  case TAG_EVar: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_pre_242);
    heff_drop(v_ds_243);
    return v_x5_244;
  }
  case TAG_EGlobal: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_pre_242);
    heff_drop(v_ds_243);
    return v_x5_244;
  }
  case TAG_ELam: {
    V v_xs_247 = heff_field(v_x5_244, 0);
    V v_b_248 = heff_field(v_x5_244, 1);
    V v_ru_24x5_244_24ELam = heff_take_reuse_n(v_x5_244, 3ULL, 2);
    V v_cell_249 = heff_tag_at_n(v_ru_24x5_244_24ELam, TAG_ELam, 2, (V[]){v_xs_247, heff_hole()});
    V v_u_2410 = (g_heff_2ecompile_2espec_2eselfTo_24dps(v_g_240, v_h_241, v_pre_242, v_ds_243, v_b_248, heff_dup(v_cell_249), MK_INT(1LL)));
    heff_drop(v_u_2410);
    return v_cell_249;
  }
  case TAG_EApp: {
    V v_f_2411 = heff_field(v_x5_244, 0);
    V v_args_2412 = heff_field(v_x5_244, 1);
    V v_ru_24x5_244_24EApp = heff_take_reuse_n(v_x5_244, 3ULL, 2);
    V v_t_2413 = heff_tr(heff_call(((V)&g_heff_2ecompile_2espec_2eselfTo_clo), 4, (V[]){heff_dup(v_g_240), heff_dup(v_h_241), heff_dup(v_pre_242), heff_dup(v_ds_243)}));
    V v_t_2414 = heff_tr(g_heff_2ecompile_2espec_2eselfHead(v_t_2413, v_g_240, heff_dup(v_h_241), heff_dup(v_f_2411)));
    V v_t_2415 = heff_tr(heff_call(((V)&g_heff_2ecompile_2espec_2eselfTo_clo), 4, (V[]){heff_dup(v_g_240), v_h_241, heff_dup(v_pre_242), heff_dup(v_ds_243)}));
    V v_t_2416 = ({ V a_0 = v_g_240; V a_1 = v_pre_242; V a_2 = v_ds_243; V a_3 = v_f_2411; V a_4 = v_args_2412; V r_ = (g_heff_2ecompile_2espec_2eselfArgs(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_g_240); heff_drop(v_f_2411); r_; });
    V v_t_2417 = (g_list_2emap(v_t_2415, v_t_2416));
    return heff_tag_at_n(v_ru_24x5_244_24EApp, TAG_EApp, 2, (V[]){v_t_2414, v_t_2417});
  }
  case TAG_ELet: {
    V v_x_2418 = heff_field(v_x5_244, 0);
    V v_a_2419 = heff_field(v_x5_244, 1);
    V v_b_2420 = heff_field(v_x5_244, 2);
    V v_ru_24x5_244_24ELet = heff_take_reuse_n(v_x5_244, 7ULL, 3);
    V v_t_2421 = (g_heff_2ecompile_2espec_2eselfTo(heff_dup(v_g_240), heff_dup(v_h_241), heff_dup(v_pre_242), heff_dup(v_ds_243), v_a_2419));
    V v_cell_2422 = heff_tag_at_n(v_ru_24x5_244_24ELet, TAG_ELet, 3, (V[]){v_x_2418, v_t_2421, heff_hole()});
    V v_u_2423 = (g_heff_2ecompile_2espec_2eselfTo_24dps(v_g_240, v_h_241, v_pre_242, v_ds_243, v_b_2420, heff_dup(v_cell_2422), MK_INT(2LL)));
    heff_drop(v_u_2423);
    return v_cell_2422;
  }
  case TAG_ERecord: {
    V v_fs_2424 = heff_field(v_x5_244, 0);
    V v_ts_2425 = heff_field(v_x5_244, 1);
    V v_ru_24x5_244_24ERecord = heff_take_reuse_n(v_x5_244, 3ULL, 2);
    V v_go_2426 = heff_tr(heff_call(((V)&g_heff_2ecompile_2espec_2eselfTo_clo), 4, (V[]){v_g_240, v_h_241, v_pre_242, v_ds_243}));
    V v_t_2431 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2espec_2eselfTo_lam0, 1, 1, (V[]){v_go_2426}), v_fs_2424));
    return heff_tag_at_n(v_ru_24x5_244_24ERecord, TAG_ERecord, 2, (V[]){v_t_2431, v_ts_2425});
  }
  case TAG_EProj: {
    V v_e_2432 = heff_field(v_x5_244, 0);
    V v_l_2433 = heff_field(v_x5_244, 1);
    V v_sh_2434 = heff_field(v_x5_244, 2);
    V v_t_2435 = heff_field(v_x5_244, 3);
    V v_ru_24x5_244_24EProj = heff_take_reuse_n(v_x5_244, 15ULL, 4);
    V v_t_2436 = (g_heff_2ecompile_2espec_2eselfTo(v_g_240, v_h_241, v_pre_242, v_ds_243, v_e_2432));
    return heff_tag_at_n(v_ru_24x5_244_24EProj, TAG_EProj, 4, (V[]){v_t_2436, v_l_2433, v_sh_2434, v_t_2435});
  }
  case TAG_ETag: {
    V v_t_2437 = heff_field(v_x5_244, 0);
    V v_args_2438 = heff_field(v_x5_244, 1);
    V v_ts_2439 = heff_field(v_x5_244, 2);
    V v_ru_24x5_244_24ETag = heff_take_reuse_n(v_x5_244, 7ULL, 3);
    V v_t_2440 = heff_tr(heff_call(((V)&g_heff_2ecompile_2espec_2eselfTo_clo), 4, (V[]){v_g_240, v_h_241, v_pre_242, v_ds_243}));
    V v_t_2441 = (g_list_2emap(v_t_2440, v_args_2438));
    return heff_tag_at_n(v_ru_24x5_244_24ETag, TAG_ETag, 3, (V[]){v_t_2437, v_t_2441, v_ts_2439});
  }
  case TAG_EMatch: {
    V v_s_2442 = heff_field(v_x5_244, 0);
    V v_arms_2443 = heff_field(v_x5_244, 1);
    V v_ru_24x5_244_24EMatch = heff_take_reuse_n(v_x5_244, 3ULL, 2);
    V v_t_2444 = (g_heff_2ecompile_2espec_2eselfTo(heff_dup(v_g_240), heff_dup(v_h_241), heff_dup(v_pre_242), heff_dup(v_ds_243), v_s_2442));
    V v_go_2445 = heff_tr(heff_call(((V)&g_heff_2ecompile_2espec_2eselfTo_clo), 4, (V[]){v_g_240, v_h_241, v_pre_242, v_ds_243}));
    V v_t_2451 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2espec_2eselfTo_lam1, 1, 1, (V[]){v_go_2445}), v_arms_2443));
    return heff_tag_at_n(v_ru_24x5_244_24EMatch, TAG_EMatch, 2, (V[]){v_t_2444, v_t_2451});
  }
  case TAG_EPrim: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_pre_242);
    heff_drop(v_ds_243);
    return v_x5_244;
  }
  case TAG_EPrimCall: {
    V v_p_2453 = heff_field(v_x5_244, 0);
    V v_args_2454 = heff_field(v_x5_244, 1);
    V v_ru_24x5_244_24EPrimCall = heff_take_reuse_n(v_x5_244, 3ULL, 2);
    V v_t_2455 = heff_tr(heff_call(((V)&g_heff_2ecompile_2espec_2eselfTo_clo), 4, (V[]){v_g_240, v_h_241, v_pre_242, v_ds_243}));
    V v_t_2456 = (g_list_2emap(v_t_2455, v_args_2454));
    return heff_tag_at_n(v_ru_24x5_244_24EPrimCall, TAG_EPrimCall, 2, (V[]){v_p_2453, v_t_2456});
  }
  case TAG_ECall: {
    V v_k_2457 = heff_field(v_x5_244, 0);
    V v_args_2458 = heff_field(v_x5_244, 1);
    V v_ru_24x5_244_24ECall = heff_take_reuse_n(v_x5_244, 3ULL, 2);
    V v_t_2459 = heff_tr(heff_call(((V)&g_heff_2ecompile_2espec_2eselfTo_clo), 4, (V[]){v_g_240, v_h_241, v_pre_242, v_ds_243}));
    V v_t_2460 = (g_list_2emap(v_t_2459, v_args_2458));
    return heff_tag_at_n(v_ru_24x5_244_24ECall, TAG_ECall, 2, (V[]){v_k_2457, v_t_2460});
  }
  case TAG_EInt: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_pre_242);
    heff_drop(v_ds_243);
    return v_x5_244;
  }
  case TAG_EFloat: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_pre_242);
    heff_drop(v_ds_243);
    return v_x5_244;
  }
  case TAG_EStr: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_pre_242);
    heff_drop(v_ds_243);
    return v_x5_244;
  }
  case TAG_EBytes: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_pre_242);
    heff_drop(v_ds_243);
    return v_x5_244;
  }
  case TAG_EFixed: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_pre_242);
    heff_drop(v_ds_243);
    return v_x5_244;
  }
  case TAG_EFloat32: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_pre_242);
    heff_drop(v_ds_243);
    return v_x5_244;
  }
  case TAG_EAbandon: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_pre_242);
    heff_drop(v_ds_243);
    return v_x5_244;
  }
  case TAG_EBool: {
    V v_c_2468 = heff_field(v_x5_244, 0);
    V v_ru_24x5_244_24EBool = heff_take_reuse_n(v_x5_244, 1ULL, 1);
    V v_t_2469 = heff_tr(heff_call(((V)&g_heff_2ecompile_2espec_2eselfTo_clo), 4, (V[]){v_g_240, v_h_241, v_pre_242, v_ds_243}));
    V v_t_2470 = (g_heff_2ecompile_2eir_2econdMap(v_t_2469, v_c_2468));
    return heff_tag_at_n(v_ru_24x5_244_24EBool, TAG_EBool, 1, (V[]){v_t_2470});
  }
  case TAG_ESet: {
    V v_xs_2471 = heff_field(v_x5_244, 0);
    V v_a_2472 = heff_field(v_x5_244, 1);
    V v_b_2473 = heff_field(v_x5_244, 2);
    V v_ru_24x5_244_24ESet = heff_take_reuse_n(v_x5_244, 7ULL, 3);
    V v_t_2474 = (g_heff_2ecompile_2espec_2eselfTo(heff_dup(v_g_240), heff_dup(v_h_241), heff_dup(v_pre_242), heff_dup(v_ds_243), v_a_2472));
    V v_cell_2475 = heff_tag_at_n(v_ru_24x5_244_24ESet, TAG_ESet, 3, (V[]){v_xs_2471, v_t_2474, heff_hole()});
    V v_u_2476 = (g_heff_2ecompile_2espec_2eselfTo_24dps(v_g_240, v_h_241, v_pre_242, v_ds_243, v_b_2473, heff_dup(v_cell_2475), MK_INT(2LL)));
    heff_drop(v_u_2476);
    return v_cell_2475;
  }
  case TAG_EValues: {
    V v_es_2477 = heff_field(v_x5_244, 0);
    V v_ru_24x5_244_24EValues = heff_take_reuse_n(v_x5_244, 1ULL, 1);
    V v_t_2478 = heff_tr(heff_call(((V)&g_heff_2ecompile_2espec_2eselfTo_clo), 4, (V[]){v_g_240, v_h_241, v_pre_242, v_ds_243}));
    V v_t_2479 = (g_list_2emap(v_t_2478, v_es_2477));
    return heff_tag_at_n(v_ru_24x5_244_24EValues, TAG_EValues, 1, (V[]){v_t_2479});
  }
  case TAG_EFix: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_pre_242);
    heff_drop(v_ds_243);
    return v_x5_244;
  }
  default: return heff_nomatch(v_x5_244);
  }
}
V g_heff_2ecompile_2espec_2eselfTo_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2espec_2eselfTo(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ecompile_2espec_2eselfTo_lam0(V self, V *args) {
  V v_x2_2427 = args[0];
  V v_go_2426 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x2_2427)) {
  case TAG_MkPair: {
    V v_l_2428 = heff_field(v_x2_2427, 0);
    V v_v_2429 = heff_field(v_x2_2427, 1);
    V v_ru_24x2_2427_24MkPair = heff_take_reuse_n(v_x2_2427, 3ULL, 2);
    V v_t_2430 = heff_tr(heff_call(v_go_2426, 1, (V[]){v_v_2429}));
    return heff_tag_at_n(v_ru_24x2_2427_24MkPair, TAG_MkPair, 2, (V[]){v_l_2428, v_t_2430});
  }
  default: return heff_nomatch(v_x2_2427);
  }
}
V g_heff_2ecompile_2espec_2eselfTo_lam1(V self, V *args) {
  V v_x2_2446 = args[0];
  V v_go_2445 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x2_2446)) {
  case TAG_MkArm: {
    V v_t_2447 = heff_field(v_x2_2446, 0);
    V v_vs_2448 = heff_field(v_x2_2446, 1);
    V v_b_2449 = heff_field(v_x2_2446, 2);
    V v_ru_24x2_2446_24MkArm = heff_take_reuse_n(v_x2_2446, 7ULL, 3);
    V v_t_2450 = heff_tr(heff_call(v_go_2445, 1, (V[]){v_b_2449}));
    return heff_tag_at_n(v_ru_24x2_2446_24MkArm, TAG_MkArm, 3, (V[]){v_t_2447, v_vs_2448, v_t_2450});
  }
  default: return heff_nomatch(v_x2_2446);
  }
}
V g_heff_2ecompile_2espec_2eselfTo_24dps_lam0(V self, V *args);
V g_heff_2ecompile_2espec_2eselfTo_24dps_lam1(V self, V *args);
Clo g_heff_2ecompile_2espec_2eselfTo_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2espec_2eselfTo_24dps_entry, 7, 0};

V g_heff_2ecompile_2espec_2eselfTo_24dps(V v_g_240, V v_h_241, V v_pre_242, V v_ds_243, V v_x5_244, V v_d_245, V v_i_246) {
top: ;
  switch (heff_tag_of(v_x5_244)) {
  case TAG_EVar: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_pre_242);
    heff_drop(v_ds_243);
    return heff_setField(v_d_245, v_i_246, v_x5_244);
  }
  case TAG_EGlobal: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_pre_242);
    heff_drop(v_ds_243);
    return heff_setField(v_d_245, v_i_246, v_x5_244);
  }
  case TAG_ELam: {
    V v_xs_249 = heff_field(v_x5_244, 0);
    V v_b_2410 = heff_field(v_x5_244, 1);
    V v_ru_24x5_244_24ELam = heff_take_reuse_n(v_x5_244, 3ULL, 2);
    V v_cell_2411 = heff_tag_at_n(v_ru_24x5_244_24ELam, TAG_ELam, 2, (V[]){v_xs_249, heff_hole()});
    V v_u_2412 = heff_setField(v_d_245, v_i_246, heff_dup(v_cell_2411));
    heff_drop(v_u_2412);
    V t_0 = v_g_240;
    V t_1 = v_h_241;
    V t_2 = v_pre_242;
    V t_3 = v_ds_243;
    V t_4 = v_b_2410;
    V t_5 = v_cell_2411;
    V t_6 = MK_INT(1LL);
    v_g_240 = t_0;
    v_h_241 = t_1;
    v_pre_242 = t_2;
    v_ds_243 = t_3;
    v_x5_244 = t_4;
    v_d_245 = t_5;
    v_i_246 = t_6;
    goto top;
  }
  case TAG_EApp: {
    V v_f_2413 = heff_field(v_x5_244, 0);
    V v_args_2414 = heff_field(v_x5_244, 1);
    V v_ru_24x5_244_24EApp = heff_take_reuse_n(v_x5_244, 3ULL, 2);
    V v_t_2415 = heff_tr(heff_call(((V)&g_heff_2ecompile_2espec_2eselfTo_clo), 4, (V[]){heff_dup(v_g_240), heff_dup(v_h_241), heff_dup(v_pre_242), heff_dup(v_ds_243)}));
    V v_t_2416 = heff_tr(g_heff_2ecompile_2espec_2eselfHead(v_t_2415, v_g_240, heff_dup(v_h_241), heff_dup(v_f_2413)));
    V v_t_2417 = heff_tr(heff_call(((V)&g_heff_2ecompile_2espec_2eselfTo_clo), 4, (V[]){heff_dup(v_g_240), v_h_241, heff_dup(v_pre_242), heff_dup(v_ds_243)}));
    V v_t_2418 = ({ V a_0 = v_g_240; V a_1 = v_pre_242; V a_2 = v_ds_243; V a_3 = v_f_2413; V a_4 = v_args_2414; V r_ = (g_heff_2ecompile_2espec_2eselfArgs(a_0, a_1, a_2, a_3, a_4)); heff_drop(v_g_240); heff_drop(v_f_2413); r_; });
    V v_t_2419 = (g_list_2emap_24tok2(v_ru_24x5_244_24EApp, v_t_2417, v_t_2418));
    return heff_setField(v_d_245, v_i_246, heff_tag_n(TAG_EApp, 2, (V[]){v_t_2416, v_t_2419}));
  }
  case TAG_ELet: {
    V v_x_2420 = heff_field(v_x5_244, 0);
    V v_a_2421 = heff_field(v_x5_244, 1);
    V v_b_2422 = heff_field(v_x5_244, 2);
    V v_ru_24x5_244_24ELet = heff_take_reuse_n(v_x5_244, 7ULL, 3);
    V v_t_2423 = (g_heff_2ecompile_2espec_2eselfTo(heff_dup(v_g_240), heff_dup(v_h_241), heff_dup(v_pre_242), heff_dup(v_ds_243), v_a_2421));
    V v_cell_2424 = heff_tag_at_n(v_ru_24x5_244_24ELet, TAG_ELet, 3, (V[]){v_x_2420, v_t_2423, heff_hole()});
    V v_u_2425 = heff_setField(v_d_245, v_i_246, heff_dup(v_cell_2424));
    heff_drop(v_u_2425);
    V t_0 = v_g_240;
    V t_1 = v_h_241;
    V t_2 = v_pre_242;
    V t_3 = v_ds_243;
    V t_4 = v_b_2422;
    V t_5 = v_cell_2424;
    V t_6 = MK_INT(2LL);
    v_g_240 = t_0;
    v_h_241 = t_1;
    v_pre_242 = t_2;
    v_ds_243 = t_3;
    v_x5_244 = t_4;
    v_d_245 = t_5;
    v_i_246 = t_6;
    goto top;
  }
  case TAG_ERecord: {
    V v_fs_2426 = heff_field(v_x5_244, 0);
    V v_ts_2427 = heff_field(v_x5_244, 1);
    V v_ru_24x5_244_24ERecord = heff_take_reuse_n(v_x5_244, 3ULL, 2);
    V v_go_2428 = heff_tr(heff_call(((V)&g_heff_2ecompile_2espec_2eselfTo_clo), 4, (V[]){v_g_240, v_h_241, v_pre_242, v_ds_243}));
    V v_t_2433 = (g_list_2emap_24tok2(v_ru_24x5_244_24ERecord, heff_clo_n(g_heff_2ecompile_2espec_2eselfTo_24dps_lam0, 1, 1, (V[]){v_go_2428}), v_fs_2426));
    return heff_setField(v_d_245, v_i_246, heff_tag_n(TAG_ERecord, 2, (V[]){v_t_2433, v_ts_2427}));
  }
  case TAG_EProj: {
    V v_e_2434 = heff_field(v_x5_244, 0);
    V v_l_2435 = heff_field(v_x5_244, 1);
    V v_sh_2436 = heff_field(v_x5_244, 2);
    V v_t_2437 = heff_field(v_x5_244, 3);
    heff_take_n(v_x5_244, 15ULL, 4);
    V v_t_2438 = (g_heff_2ecompile_2espec_2eselfTo(v_g_240, v_h_241, v_pre_242, v_ds_243, v_e_2434));
    return heff_setField(v_d_245, v_i_246, heff_tag_n(TAG_EProj, 4, (V[]){v_t_2438, v_l_2435, v_sh_2436, v_t_2437}));
  }
  case TAG_ETag: {
    V v_t_2439 = heff_field(v_x5_244, 0);
    V v_args_2440 = heff_field(v_x5_244, 1);
    V v_ts_2441 = heff_field(v_x5_244, 2);
    heff_take_n(v_x5_244, 7ULL, 3);
    V v_t_2442 = heff_tr(heff_call(((V)&g_heff_2ecompile_2espec_2eselfTo_clo), 4, (V[]){v_g_240, v_h_241, v_pre_242, v_ds_243}));
    V v_t_2443 = (g_list_2emap(v_t_2442, v_args_2440));
    return heff_setField(v_d_245, v_i_246, heff_tag_n(TAG_ETag, 3, (V[]){v_t_2439, v_t_2443, v_ts_2441}));
  }
  case TAG_EMatch: {
    V v_s_2444 = heff_field(v_x5_244, 0);
    V v_arms_2445 = heff_field(v_x5_244, 1);
    V v_ru_24x5_244_24EMatch = heff_take_reuse_n(v_x5_244, 3ULL, 2);
    V v_t_2446 = (g_heff_2ecompile_2espec_2eselfTo(heff_dup(v_g_240), heff_dup(v_h_241), heff_dup(v_pre_242), heff_dup(v_ds_243), v_s_2444));
    V v_go_2447 = heff_tr(heff_call(((V)&g_heff_2ecompile_2espec_2eselfTo_clo), 4, (V[]){v_g_240, v_h_241, v_pre_242, v_ds_243}));
    V v_t_2453 = (g_list_2emap_24tok2(v_ru_24x5_244_24EMatch, heff_clo_n(g_heff_2ecompile_2espec_2eselfTo_24dps_lam1, 1, 1, (V[]){v_go_2447}), v_arms_2445));
    return heff_setField(v_d_245, v_i_246, heff_tag_n(TAG_EMatch, 2, (V[]){v_t_2446, v_t_2453}));
  }
  case TAG_EPrim: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_pre_242);
    heff_drop(v_ds_243);
    return heff_setField(v_d_245, v_i_246, v_x5_244);
  }
  case TAG_EPrimCall: {
    V v_p_2455 = heff_field(v_x5_244, 0);
    V v_args_2456 = heff_field(v_x5_244, 1);
    V v_ru_24x5_244_24EPrimCall = heff_take_reuse_n(v_x5_244, 3ULL, 2);
    V v_t_2457 = heff_tr(heff_call(((V)&g_heff_2ecompile_2espec_2eselfTo_clo), 4, (V[]){v_g_240, v_h_241, v_pre_242, v_ds_243}));
    V v_t_2458 = (g_list_2emap_24tok2(v_ru_24x5_244_24EPrimCall, v_t_2457, v_args_2456));
    return heff_setField(v_d_245, v_i_246, heff_tag_n(TAG_EPrimCall, 2, (V[]){v_p_2455, v_t_2458}));
  }
  case TAG_ECall: {
    V v_k_2459 = heff_field(v_x5_244, 0);
    V v_args_2460 = heff_field(v_x5_244, 1);
    V v_ru_24x5_244_24ECall = heff_take_reuse_n(v_x5_244, 3ULL, 2);
    V v_t_2461 = heff_tr(heff_call(((V)&g_heff_2ecompile_2espec_2eselfTo_clo), 4, (V[]){v_g_240, v_h_241, v_pre_242, v_ds_243}));
    V v_t_2462 = (g_list_2emap_24tok2(v_ru_24x5_244_24ECall, v_t_2461, v_args_2460));
    return heff_setField(v_d_245, v_i_246, heff_tag_n(TAG_ECall, 2, (V[]){v_k_2459, v_t_2462}));
  }
  case TAG_EInt: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_pre_242);
    heff_drop(v_ds_243);
    return heff_setField(v_d_245, v_i_246, v_x5_244);
  }
  case TAG_EFloat: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_pre_242);
    heff_drop(v_ds_243);
    return heff_setField(v_d_245, v_i_246, v_x5_244);
  }
  case TAG_EStr: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_pre_242);
    heff_drop(v_ds_243);
    return heff_setField(v_d_245, v_i_246, v_x5_244);
  }
  case TAG_EBytes: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_pre_242);
    heff_drop(v_ds_243);
    return heff_setField(v_d_245, v_i_246, v_x5_244);
  }
  case TAG_EFixed: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_pre_242);
    heff_drop(v_ds_243);
    return heff_setField(v_d_245, v_i_246, v_x5_244);
  }
  case TAG_EFloat32: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_pre_242);
    heff_drop(v_ds_243);
    return heff_setField(v_d_245, v_i_246, v_x5_244);
  }
  case TAG_EAbandon: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_pre_242);
    heff_drop(v_ds_243);
    return heff_setField(v_d_245, v_i_246, v_x5_244);
  }
  case TAG_EBool: {
    V v_c_2470 = heff_field(v_x5_244, 0);
    heff_take_n(v_x5_244, 1ULL, 1);
    V v_t_2471 = heff_tr(heff_call(((V)&g_heff_2ecompile_2espec_2eselfTo_clo), 4, (V[]){v_g_240, v_h_241, v_pre_242, v_ds_243}));
    V v_t_2472 = (g_heff_2ecompile_2eir_2econdMap(v_t_2471, v_c_2470));
    return heff_setField(v_d_245, v_i_246, heff_tag_n(TAG_EBool, 1, (V[]){v_t_2472}));
  }
  case TAG_ESet: {
    V v_xs_2473 = heff_field(v_x5_244, 0);
    V v_a_2474 = heff_field(v_x5_244, 1);
    V v_b_2475 = heff_field(v_x5_244, 2);
    V v_ru_24x5_244_24ESet = heff_take_reuse_n(v_x5_244, 7ULL, 3);
    V v_t_2476 = (g_heff_2ecompile_2espec_2eselfTo(heff_dup(v_g_240), heff_dup(v_h_241), heff_dup(v_pre_242), heff_dup(v_ds_243), v_a_2474));
    V v_cell_2477 = heff_tag_at_n(v_ru_24x5_244_24ESet, TAG_ESet, 3, (V[]){v_xs_2473, v_t_2476, heff_hole()});
    V v_u_2478 = heff_setField(v_d_245, v_i_246, heff_dup(v_cell_2477));
    heff_drop(v_u_2478);
    V t_0 = v_g_240;
    V t_1 = v_h_241;
    V t_2 = v_pre_242;
    V t_3 = v_ds_243;
    V t_4 = v_b_2475;
    V t_5 = v_cell_2477;
    V t_6 = MK_INT(2LL);
    v_g_240 = t_0;
    v_h_241 = t_1;
    v_pre_242 = t_2;
    v_ds_243 = t_3;
    v_x5_244 = t_4;
    v_d_245 = t_5;
    v_i_246 = t_6;
    goto top;
  }
  case TAG_EValues: {
    V v_es_2479 = heff_field(v_x5_244, 0);
    heff_take_n(v_x5_244, 1ULL, 1);
    V v_t_2480 = heff_tr(heff_call(((V)&g_heff_2ecompile_2espec_2eselfTo_clo), 4, (V[]){v_g_240, v_h_241, v_pre_242, v_ds_243}));
    V v_t_2481 = (g_list_2emap(v_t_2480, v_es_2479));
    return heff_setField(v_d_245, v_i_246, heff_tag_n(TAG_EValues, 1, (V[]){v_t_2481}));
  }
  case TAG_EFix: {
    heff_drop(v_g_240);
    heff_drop(v_h_241);
    heff_drop(v_pre_242);
    heff_drop(v_ds_243);
    return heff_setField(v_d_245, v_i_246, v_x5_244);
  }
  default: return heff_nomatch(v_x5_244);
  }
}
V g_heff_2ecompile_2espec_2eselfTo_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2espec_2eselfTo_24dps(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
}
V g_heff_2ecompile_2espec_2eselfTo_24dps_lam0(V self, V *args) {
  V v_x2_2429 = args[0];
  V v_go_2428 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x2_2429)) {
  case TAG_MkPair: {
    V v_l_2430 = heff_field(v_x2_2429, 0);
    V v_v_2431 = heff_field(v_x2_2429, 1);
    V v_ru_24x2_2429_24MkPair = heff_take_reuse_n(v_x2_2429, 3ULL, 2);
    V v_t_2432 = heff_tr(heff_call(v_go_2428, 1, (V[]){v_v_2431}));
    return heff_tag_at_n(v_ru_24x2_2429_24MkPair, TAG_MkPair, 2, (V[]){v_l_2430, v_t_2432});
  }
  default: return heff_nomatch(v_x2_2429);
  }
}
V g_heff_2ecompile_2espec_2eselfTo_24dps_lam1(V self, V *args) {
  V v_x2_2448 = args[0];
  V v_go_2447 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x2_2448)) {
  case TAG_MkArm: {
    V v_t_2449 = heff_field(v_x2_2448, 0);
    V v_vs_2450 = heff_field(v_x2_2448, 1);
    V v_b_2451 = heff_field(v_x2_2448, 2);
    V v_ru_24x2_2448_24MkArm = heff_take_reuse_n(v_x2_2448, 7ULL, 3);
    V v_t_2452 = heff_tr(heff_call(v_go_2447, 1, (V[]){v_b_2451}));
    return heff_tag_at_n(v_ru_24x2_2448_24MkArm, TAG_MkArm, 3, (V[]){v_t_2449, v_vs_2450, v_t_2452});
  }
  default: return heff_nomatch(v_x2_2448);
  }
}
Clo g_heff_2ecompile_2espec_2eappendS_24tok2_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2espec_2eappendS_24tok2_entry, 3, 0};

V g_heff_2ecompile_2espec_2eappendS_24tok2(V v_tok_240, V v_x1_241, V v_ys_242) {
top: ;
  switch (heff_tag_of(v_x1_241)) {
  case TAG_Nil: {
    heff_drop_cell(v_tok_240, 2);
    return v_ys_242;
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x1_241, 0);
    V v_xs_244 = heff_field(v_x1_241, 1);
    heff_take_n(v_x1_241, 3ULL, 2);
    V v_cell_245 = heff_tag_at_n(v_tok_240, TAG_Cons, 2, (V[]){v_x_243, heff_hole()});
    V v_u_246 = (g_heff_2ecompile_2espec_2eappendS_24dps(v_xs_244, v_ys_242, heff_dup(v_cell_245)));
    heff_drop(v_u_246);
    return v_cell_245;
  }
  default: return heff_nomatch(v_x1_241);
  }
}
V g_heff_2ecompile_2espec_2eappendS_24tok2_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2espec_2eappendS_24tok2(a[0], a[1], a[2]);
}