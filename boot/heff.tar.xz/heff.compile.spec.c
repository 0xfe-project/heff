// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_CFalse 2759
#define TAG_CIf 14188
#define TAG_CNot 51573
#define TAG_CRel 55099
#define TAG_CTest 64009
#define TAG_CTrue 11023
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_EBool 8245
#define TAG_EBytes 33701
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_ESet 50124
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EValues 34965
#define TAG_EVar 52881
#define TAG_F32 16337
#define TAG_FtAny 18156
#define TAG_FtFixed 23584
#define TAG_FtFloat 38674
#define TAG_FtOther 63706
#define TAG_I16 19162
#define TAG_I32 19220
#define TAG_I64 19315
#define TAG_I8 9088
#define TAG_MkArm 55352
#define TAG_U16 30694
#define TAG_U32 30752
#define TAG_U64 30847
#define TAG_U8 9460
#define LBL_caps 9541544
#define LBL_holes 300818381
#define LBL_n 328
#define LBL_ren 322325
#define LBL_vars 10107635
static uint32_t shape_ren__caps__vars__holes__n[] = {LBL_ren, LBL_caps, LBL_vars, LBL_holes, LBL_n};
static V prim_strEq_entry(V self, V *a) { (void)self; return heff_strEq(a[0], a[1]); }
static Clo prim_strEq_clo = {{0x80000000u, K_CLO, 0}, prim_strEq_entry, 2, 0};
V g_heff_2ecompile_2eir_2eallParts(V, V);
V g_heff_2ecompile_2eir_2eallParts_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eallParts_clo;
V g_heff_2ecompile_2eir_2eappendI(V, V);
V g_heff_2ecompile_2eir_2eappendI_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eappendI_clo;
V g_heff_2ecompile_2eir_2eappendI_24tok2(V, V, V);
V g_heff_2ecompile_2eir_2eappendI_24tok2_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2eappendI_24tok2_clo;
V g_heff_2ecompile_2eir_2emapParts(V, V);
V g_heff_2ecompile_2eir_2emapParts_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2emapParts_clo;
V g_heff_2ecompile_2eir_2emapParts_24tok1(V, V, V);
V g_heff_2ecompile_2eir_2emapParts_24tok1_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2emapParts_24tok1_clo;
V g_heff_2ecompile_2eir_2emapParts_24tok3(V, V, V);
V g_heff_2ecompile_2eir_2emapParts_24tok3_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2emapParts_24tok3_clo;
V g_heff_2ecompile_2eir_2epartsOnto(V, V);
V g_heff_2ecompile_2eir_2epartsOnto_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2epartsOnto_clo;
V g_heff_2ecompile_2eir_2esubstGo(V, V);
V g_heff_2ecompile_2eir_2esubstGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2eir_2esubstGo_clo;
HeffT2 g_heff_2ecompile_2eir_2etraversePartsM_24s1049679562x279661776_24cpr(V, V);
V g_heff_2ecompile_2espec_2ecallsNothing(V);
V g_heff_2ecompile_2espec_2ecallsNothing_entry(V self, V *a);
extern Clo g_heff_2ecompile_2espec_2ecallsNothing_clo;
V g_heff_2ecompile_2espec_2ecallsOnce(V);
V g_heff_2ecompile_2espec_2ecallsOnce_entry(V self, V *a);
extern Clo g_heff_2ecompile_2espec_2ecallsOnce_clo;
V g_heff_2ecompile_2espec_2eclosedIn(V, V);
V g_heff_2ecompile_2espec_2eclosedIn_entry(V self, V *a);
extern Clo g_heff_2ecompile_2espec_2eclosedIn_clo;
V g_heff_2ecompile_2espec_2econdKey(V, V);
V g_heff_2ecompile_2espec_2econdKey_entry(V self, V *a);
extern Clo g_heff_2ecompile_2espec_2econdKey_clo;
HeffT2 g_heff_2ecompile_2espec_2edictGo_24cpr(V, V, V);
V g_heff_2ecompile_2espec_2edropAt(V, V);
V g_heff_2ecompile_2espec_2edropAt_entry(V self, V *a);
extern Clo g_heff_2ecompile_2espec_2edropAt_clo;
V g_heff_2ecompile_2espec_2edropAt_24dps(V, V, V);
V g_heff_2ecompile_2espec_2edropAt_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2espec_2edropAt_24dps_clo;
V g_heff_2ecompile_2espec_2ehashGo(V, V, V, V);
V g_heff_2ecompile_2espec_2ehashGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2espec_2ehashGo_clo;
V g_heff_2ecompile_2espec_2ekeyGo(V, V);
V g_heff_2ecompile_2espec_2ekeyGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2espec_2ekeyGo_clo;
HeffT2 g_heff_2ecompile_2espec_2enthS_24cpr(V, V);
V g_heff_2ecompile_2espec_2eposGo(V, V, V);
V g_heff_2ecompile_2espec_2eposGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2espec_2eposGo_clo;
V g_heff_2ecompile_2espec_2eselfTo(V, V, V, V, V);
V g_heff_2ecompile_2espec_2eselfTo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2espec_2eselfTo_clo;
V g_heff_2ecompile_2espec_2eshapeArms(V, V, V);
V g_heff_2ecompile_2espec_2eshapeArms_entry(V self, V *a);
extern Clo g_heff_2ecompile_2espec_2eshapeArms_clo;
HeffT2 g_heff_2ecompile_2espec_2eshapeArms_24cpr(V, V, V);
V g_heff_2ecompile_2espec_2eshapeGo(V, V);
V g_heff_2ecompile_2espec_2eshapeGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2espec_2eshapeGo_clo;
HeffT2 g_heff_2ecompile_2espec_2eshapeGo_24cpr(V, V);
V g_heff_2ecompile_2espec_2estaticGo(V, V, V);
V g_heff_2ecompile_2espec_2estaticGo_entry(V self, V *a);
extern Clo g_heff_2ecompile_2espec_2estaticGo_clo;
V g_heff_2ecompile_2espec_2estaticGo_24dps(V, V, V, V);
V g_heff_2ecompile_2espec_2estaticGo_24dps_entry(V self, V *a);
extern Clo g_heff_2ecompile_2espec_2estaticGo_24dps_clo;
V g_heff_2ecompile_2espec_2eusesOf(V, V);
V g_heff_2ecompile_2espec_2eusesOf_entry(V self, V *a);
extern Clo g_heff_2ecompile_2espec_2eusesOf_clo;
V g_heff_2eelab_2eprimitive_2eprimName(V);
V g_heff_2eelab_2eprimitive_2eprimName_entry(V self, V *a);
extern Clo g_heff_2eelab_2eprimitive_2eprimName_clo;
V g_list_2eall(V, V);
V g_list_2eall_entry(V self, V *a);
extern Clo g_list_2eall_clo;
V g_list_2eall_24s1859111141x1565023045(V);
V g_list_2eall_24s1859111141x1565023045_entry(V self, V *a);
extern Clo g_list_2eall_24s1859111141x1565023045_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24s1048046132x95752937(V, V);
V g_list_2efoldl_24s1048046132x95752937_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1048046132x95752937_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2efoldl_24s65689923x209800052(V, V, V);
V g_list_2efoldl_24s65689923x209800052_entry(V self, V *a);
extern Clo g_list_2efoldl_24s65689923x209800052_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s143096761x246530315(V);
V g_list_2emap_24s143096761x246530315_entry(V self, V *a);
extern Clo g_list_2emap_24s143096761x246530315_clo;
V g_list_2emap_24tok2(V, V, V);
V g_list_2emap_24tok2_entry(V self, V *a);
extern Clo g_list_2emap_24tok2_clo;
V g_prelude_2e_2b_2b(V, V);
V g_prelude_2e_2b_2b_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_clo;
V g_prelude_2e_2b_2b_24tok2(V, V, V);
V g_prelude_2e_2b_2b_24tok2_entry(V self, V *a);
extern Clo g_prelude_2e_2b_2b_24tok2_clo;
V g_prelude_2ejoinWith_2eafter_240(V, V, V);
V g_prelude_2ejoinWith_2eafter_240_entry(V self, V *a);
extern Clo g_prelude_2ejoinWith_2eafter_240_clo;
V g_std_2eordmap_2einsert_24s615484302x989744458(V, V, V);
V g_std_2eordmap_2einsert_24s615484302x989744458_entry(V self, V *a);
extern Clo g_std_2eordmap_2einsert_24s615484302x989744458_clo;
HeffT2 g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(V, V);
V g_std_2eordmap_2esize(V);
V g_std_2eordmap_2esize_entry(V self, V *a);
extern Clo g_std_2eordmap_2esize_clo;
V g_heff_2ecompile_2espec_2eclosedIn_lam0(V self, V *args);
Clo g_heff_2ecompile_2espec_2eclosedIn_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2espec_2eclosedIn_entry, 2, 0};

V g_heff_2ecompile_2espec_2eclosedIn(V v_env_240, V v_e_241) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_EVar: {
    V v_x_242 = heff_field(v_e_241, 0);
    heff_take_n(v_e_241, 1ULL, 1);
    V v_t_243 = heff_tr(heff_call(((V)&prim_strEq_clo), 1, (V[]){v_x_242}));
    return ({ V a_0 = v_t_243; V a_1 = v_env_240; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_env_240); r_; });
  }
  case TAG_EFix: {
    heff_take_n(v_e_241, 0ULL, 2);
    heff_drop(v_env_240);
    return NTAG(TAG_False);
  }
  default: {
    HEFF_LAST return g_heff_2ecompile_2eir_2eallParts(heff_clo_n(g_heff_2ecompile_2espec_2eclosedIn_lam0, 2, 1, (V[]){v_env_240}), v_e_241);
  }
  }
}
V g_heff_2ecompile_2espec_2eclosedIn_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2espec_2eclosedIn(a[0], a[1]);
}
V g_heff_2ecompile_2espec_2eclosedIn_lam0(V self, V *args) {
  V v_xs_246 = args[0];
  V v_p_247 = args[1];
  V v_env_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_248 = (g_heff_2ecompile_2eir_2eappendI(v_xs_246, v_env_240));
  return (g_heff_2ecompile_2espec_2eclosedIn(v_t_248, v_p_247));
}
Clo g_heff_2ecompile_2espec_2ecallsNothing_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2espec_2ecallsNothing_entry, 1, 0};

V g_heff_2ecompile_2espec_2ecallsNothing(V v_e_240) {
top: ;
  switch (heff_tag_of(v_e_240)) {
  case TAG_EApp: {
    heff_take_n(v_e_240, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_ECall: {
    heff_take_n(v_e_240, 0ULL, 2);
    return NTAG(TAG_False);
  }
  case TAG_EFix: {
    heff_take_n(v_e_240, 0ULL, 2);
    return NTAG(TAG_False);
  }
  default: {
    V v_t_247 = (g_heff_2ecompile_2eir_2epartsOnto(v_e_240, NTAG(TAG_Nil)));
    return ({ V a_0 = ((V)&g_heff_2ecompile_2espec_2ecallsNothing_clo); V a_1 = v_t_247; V r_ = (g_list_2eall(a_0, a_1)); heff_drop(v_t_247); r_; });
  }
  }
}
V g_heff_2ecompile_2espec_2ecallsNothing_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2espec_2ecallsNothing(a[0]);
}
Clo g_heff_2ecompile_2espec_2ecallsOnce_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2espec_2ecallsOnce_entry, 1, 0};

V g_heff_2ecompile_2espec_2ecallsOnce(V v_x1_240) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_EVar: {
    return NTAG(TAG_False);
  }
  case TAG_EGlobal: {
    return NTAG(TAG_False);
  }
  case TAG_ELam: {
    V v_b_244 = heff_field(v_x1_240, 1);
    V t_0 = v_b_244;
    v_x1_240 = t_0;
    goto top;
  }
  case TAG_EApp: {
    V v_x11_245 = heff_field(v_x1_240, 0);
    V v_args_246 = heff_field(v_x1_240, 1);
    switch (heff_tag_of(v_x11_245)) {
    case TAG_EVar: {
      return NTAG(TAG_False);
    }
    case TAG_EGlobal: {
      HEFF_LAST return g_list_2eall_24s1859111141x1565023045(v_args_246);
    }
    case TAG_ELam: {
      return NTAG(TAG_False);
    }
    case TAG_EApp: {
      return NTAG(TAG_False);
    }
    case TAG_ELet: {
      return NTAG(TAG_False);
    }
    case TAG_ERecord: {
      return NTAG(TAG_False);
    }
    case TAG_EProj: {
      return NTAG(TAG_False);
    }
    case TAG_ETag: {
      return NTAG(TAG_False);
    }
    case TAG_EMatch: {
      return NTAG(TAG_False);
    }
    case TAG_EPrim: {
      return NTAG(TAG_False);
    }
    case TAG_EPrimCall: {
      return NTAG(TAG_False);
    }
    case TAG_ECall: {
      return NTAG(TAG_False);
    }
    case TAG_EInt: {
      return NTAG(TAG_False);
    }
    case TAG_EFloat: {
      return NTAG(TAG_False);
    }
    case TAG_EStr: {
      return NTAG(TAG_False);
    }
    case TAG_EBytes: {
      return NTAG(TAG_False);
    }
    case TAG_EFixed: {
      return NTAG(TAG_False);
    }
    case TAG_EFloat32: {
      return NTAG(TAG_False);
    }
    case TAG_EAbandon: {
      return NTAG(TAG_False);
    }
    case TAG_EBool: {
      return NTAG(TAG_False);
    }
    case TAG_ESet: {
      return NTAG(TAG_False);
    }
    case TAG_EValues: {
      return NTAG(TAG_False);
    }
    case TAG_EFix: {
      return NTAG(TAG_False);
    }
    default: return heff_nomatch(v_x11_245);
    }
  }
  case TAG_ELet: {
    return NTAG(TAG_False);
  }
  case TAG_ERecord: {
    return NTAG(TAG_False);
  }
  case TAG_EProj: {
    return NTAG(TAG_False);
  }
  case TAG_ETag: {
    return NTAG(TAG_False);
  }
  case TAG_EMatch: {
    return NTAG(TAG_False);
  }
  case TAG_EPrim: {
    return NTAG(TAG_False);
  }
  case TAG_EPrimCall: {
    return NTAG(TAG_False);
  }
  case TAG_ECall: {
    return NTAG(TAG_False);
  }
  case TAG_EInt: {
    return NTAG(TAG_False);
  }
  case TAG_EFloat: {
    return NTAG(TAG_False);
  }
  case TAG_EStr: {
    return NTAG(TAG_False);
  }
  case TAG_EBytes: {
    return NTAG(TAG_False);
  }
  case TAG_EFixed: {
    return NTAG(TAG_False);
  }
  case TAG_EFloat32: {
    return NTAG(TAG_False);
  }
  case TAG_EAbandon: {
    return NTAG(TAG_False);
  }
  case TAG_EBool: {
    return NTAG(TAG_False);
  }
  case TAG_ESet: {
    return NTAG(TAG_False);
  }
  case TAG_EValues: {
    return NTAG(TAG_False);
  }
  case TAG_EFix: {
    return NTAG(TAG_False);
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2espec_2ecallsOnce_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2espec_2ecallsOnce(a0); heff_drop(a0); return r;
}
Clo g_heff_2ecompile_2espec_2eposGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2espec_2eposGo_entry, 3, 0};

V g_heff_2ecompile_2espec_2eposGo(V v_x_240, V v_x2_241, V v_i_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_i_242);
    return MK_INT(-1LL);
  }
  case TAG_Cons: {
    V v_y_243 = heff_field(v_x2_241, 0);
    V v_ys_244 = heff_field(v_x2_241, 1);
    if (heff_strEq_c_lent(v_x_240, v_y_243, 0)) {
      return v_i_242;
    } else {
      V t_0 = v_x_240;
      V t_1 = v_ys_244;
      V t_2 = heff_intAdd(v_i_242, MK_INT(1LL));
      v_x_240 = t_0;
      v_x2_241 = t_1;
      v_i_242 = t_2;
      goto top;
    }
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2espec_2eposGo_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V a1 = a[1]; V r = g_heff_2ecompile_2espec_2eposGo(a0, a1, a[2]); heff_drop(a0); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ecompile_2espec_2econdKey_str0, 1, "T");
HEFF_LIT(g_heff_2ecompile_2espec_2econdKey_str1, 1, "F");
HEFF_LIT(g_heff_2ecompile_2espec_2econdKey_str2, 1, "R");
HEFF_LIT(g_heff_2ecompile_2espec_2econdKey_str3, 1, "(");
HEFF_LIT(g_heff_2ecompile_2espec_2econdKey_str4, 1, ",");
HEFF_LIT(g_heff_2ecompile_2espec_2econdKey_str5, 1, ")");
HEFF_LIT(g_heff_2ecompile_2espec_2econdKey_str6, 2, "S(");
HEFF_LIT(g_heff_2ecompile_2espec_2econdKey_str7, 1, ")");
HEFF_LIT(g_heff_2ecompile_2espec_2econdKey_str8, 2, "N(");
HEFF_LIT(g_heff_2ecompile_2espec_2econdKey_str9, 1, ")");
HEFF_LIT(g_heff_2ecompile_2espec_2econdKey_str10, 2, "I(");
HEFF_LIT(g_heff_2ecompile_2espec_2econdKey_str11, 1, ",");
HEFF_LIT(g_heff_2ecompile_2espec_2econdKey_str12, 1, ",");
HEFF_LIT(g_heff_2ecompile_2espec_2econdKey_str13, 1, ")");
Clo g_heff_2ecompile_2espec_2econdKey_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2espec_2econdKey_entry, 2, 0};

V g_heff_2ecompile_2espec_2econdKey(V v_go_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_CTrue: {
    heff_drop(v_go_240);
    return ((V)&g_heff_2ecompile_2espec_2econdKey_str0);
  }
  case TAG_CFalse: {
    heff_drop(v_go_240);
    return ((V)&g_heff_2ecompile_2espec_2econdKey_str1);
  }
  case TAG_CRel: {
    V v_p_242 = heff_field(v_x2_241, 0);
    V v_a_243 = heff_field(v_x2_241, 1);
    V v_b_244 = heff_field(v_x2_241, 2);
    V v_t_245 = (g_heff_2eelab_2eprimitive_2eprimName(v_p_242));
    V v_t_246 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2espec_2econdKey_str2), v_t_245), ((V)&g_heff_2ecompile_2espec_2econdKey_str3));
    V v_t_247 = heff_tr(heff_call(heff_dup(v_go_240), 1, (V[]){heff_dup(v_a_243)}));
    V v_t_248 = heff_strAppend(heff_strAppend(v_t_246, v_t_247), ((V)&g_heff_2ecompile_2espec_2econdKey_str4));
    V v_t_249 = heff_tr(heff_call(v_go_240, 1, (V[]){heff_dup(v_b_244)}));
    return heff_strAppend(heff_strAppend(v_t_248, v_t_249), ((V)&g_heff_2ecompile_2espec_2econdKey_str5));
  }
  case TAG_CTest: {
    V v_e_2410 = heff_field(v_x2_241, 0);
    V v_t_2411 = heff_tr(heff_call(v_go_240, 1, (V[]){heff_dup(v_e_2410)}));
    return heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2espec_2econdKey_str6), v_t_2411), ((V)&g_heff_2ecompile_2espec_2econdKey_str7));
  }
  case TAG_CNot: {
    V v_c_2412 = heff_field(v_x2_241, 0);
    V v_t_2413 = (g_heff_2ecompile_2espec_2econdKey(v_go_240, v_c_2412));
    return heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2espec_2econdKey_str8), v_t_2413), ((V)&g_heff_2ecompile_2espec_2econdKey_str9));
  }
  case TAG_CIf: {
    V v_a_2414 = heff_field(v_x2_241, 0);
    V v_b_2415 = heff_field(v_x2_241, 1);
    V v_c_2416 = heff_field(v_x2_241, 2);
    V v_t_2417 = (g_heff_2ecompile_2espec_2econdKey(heff_dup(v_go_240), v_a_2414));
    V v_t_2418 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2espec_2econdKey_str10), v_t_2417), ((V)&g_heff_2ecompile_2espec_2econdKey_str11));
    V v_t_2419 = (g_heff_2ecompile_2espec_2econdKey(heff_dup(v_go_240), v_b_2415));
    V v_t_2420 = heff_strAppend(heff_strAppend(v_t_2418, v_t_2419), ((V)&g_heff_2ecompile_2espec_2econdKey_str12));
    V v_t_2421 = (g_heff_2ecompile_2espec_2econdKey(v_go_240, v_c_2416));
    return heff_strAppend(heff_strAppend(v_t_2420, v_t_2421), ((V)&g_heff_2ecompile_2espec_2econdKey_str13));
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2espec_2econdKey_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2espec_2econdKey(a[0], a1); heff_drop(a1); return r;
}
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str0, 1, "v");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str1, 1, "g");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str2, 1, ";");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str3, 1, "L");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str4, 1, "(");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str5, 1, ")");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str6, 2, "A(");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str7, 1, ":");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str8, 0, "");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str9, 1, ",");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str10, 1, ")");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str11, 2, "T(");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str12, 1, ":");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str13, 1, ")");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str14, 1, "=");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str15, 0, "");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str16, 1, ",");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str17, 2, "R(");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str18, 1, ":");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str19, 0, "");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str20, 1, ",");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str21, 1, ")");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str22, 2, "P(");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str23, 1, ".");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str24, 1, "/");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str25, 0, "");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str26, 1, ",");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str27, 1, ":");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str28, 7, "Float64");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str29, 4, "Int8");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str30, 5, "Int16");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str31, 5, "Int32");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str32, 5, "Int64");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str33, 5, "UInt8");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str34, 6, "UInt16");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str35, 6, "UInt32");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str36, 6, "UInt64");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str37, 7, "Float32");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str38, 1, "_");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str39, 1, "\?");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str40, 1, ")");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str41, 1, "C");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str42, 1, "(");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str43, 0, "");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str44, 1, ",");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str45, 1, ")");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str46, 1, "|");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str47, 1, ":");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str48, 0, "");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str49, 0, "");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str50, 2, "M(");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str51, 1, ")");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str52, 1, "p");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str53, 1, ";");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str54, 1, "Q");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str55, 1, "(");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str56, 0, "");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str57, 1, ",");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str58, 1, ")");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str59, 1, "K");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str60, 1, "(");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str61, 0, "");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str62, 1, ",");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str63, 1, ")");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str64, 1, "i");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str65, 1, "f");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str66, 1, "s");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str67, 1, ":");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str68, 1, "b");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str69, 1, ":");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str70, 2, "I8");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str71, 3, "I16");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str72, 3, "I32");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str73, 3, "I64");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str74, 2, "U8");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str75, 3, "U16");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str76, 3, "U32");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str77, 3, "U64");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str78, 3, "F32");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str79, 1, "x");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str80, 1, ":");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str81, 1, "y");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str82, 1, "X");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str83, 2, "o(");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str84, 1, ")");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str85, 1, "E");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str86, 1, "(");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str87, 1, ":");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str88, 1, ")");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str89, 0, "");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str90, 1, ",");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str91, 2, "W(");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str92, 1, ")");
HEFF_LIT(g_heff_2ecompile_2espec_2ekeyGo_str93, 1, "F");
V g_heff_2ecompile_2espec_2ekeyGo_lam0(V self, V *args);
V g_heff_2ecompile_2espec_2ekeyGo_lam1(V self, V *args);
Clo g_heff_2ecompile_2espec_2ekeyGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2espec_2ekeyGo_entry, 2, 0};

V g_heff_2ecompile_2espec_2ekeyGo(V v_env_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_EVar: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_t_243 = ({ V a_0 = v_x_242; V a_1 = v_env_240; V a_2 = MK_INT(0LL); V r_ = (g_heff_2ecompile_2espec_2eposGo(a_0, a_1, a_2)); heff_drop(v_env_240); r_; });
    return heff_strAppend(((V)&g_heff_2ecompile_2espec_2ekeyGo_str0), heff_intShow(v_t_243));
  }
  case TAG_EGlobal: {
    V v_g_244 = heff_field(v_x2_241, 0);
    heff_drop(v_env_240);
    return heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2espec_2ekeyGo_str1), heff_dup(v_g_244)), ((V)&g_heff_2ecompile_2espec_2ekeyGo_str2));
  }
  case TAG_ELam: {
    V v_xs_245 = heff_field(v_x2_241, 0);
    V v_b_246 = heff_field(v_x2_241, 1);
    V v_t_247 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_245));
    V v_t_248 = heff_strAppend(((V)&g_heff_2ecompile_2espec_2ekeyGo_str3), heff_intShow(v_t_247));
    V v_t_249 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_xs_245)));
    V v_t_2410 = (g_prelude_2e_2b_2b(v_t_249, v_env_240));
    V v_t_2411 = (g_heff_2ecompile_2espec_2ekeyGo(v_t_2410, v_b_246));
    V v_t_2412 = heff_strAppend(heff_strAppend(v_t_248, ((V)&g_heff_2ecompile_2espec_2ekeyGo_str4)), v_t_2411);
    return heff_strAppend(v_t_2412, ((V)&g_heff_2ecompile_2espec_2ekeyGo_str5));
  }
  case TAG_EApp: {
    V v_f_2413 = heff_field(v_x2_241, 0);
    V v_args_2414 = heff_field(v_x2_241, 1);
    V v_t_2415 = (g_heff_2ecompile_2espec_2ekeyGo(heff_dup(v_env_240), v_f_2413));
    V v_t_2416 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2espec_2ekeyGo_str6), v_t_2415), ((V)&g_heff_2ecompile_2espec_2ekeyGo_str7));
    V v_go_2417 = heff_tr(heff_call(((V)&g_heff_2ecompile_2espec_2ekeyGo_clo), 1, (V[]){v_env_240}));
    V v_x2_2418 = (g_list_2emap(v_go_2417, heff_dup(v_args_2414)));
    V v_t_2421;
    switch (heff_tag_of(v_x2_2418)) {
    case TAG_Nil: {
      v_t_2421 = ((V)&g_heff_2ecompile_2espec_2ekeyGo_str8);
      break;
    }
    case TAG_Cons: {
      V v_x_2419 = heff_field(v_x2_2418, 0);
      V v_xs_2420 = heff_field(v_x2_2418, 1);
      heff_take_n(v_x2_2418, 3ULL, 2);
      v_t_2421 = ({ V a_0 = ((V)&g_heff_2ecompile_2espec_2ekeyGo_str9); V a_1 = v_x_2419; V a_2 = v_xs_2420; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2420); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2418);
    }
    return heff_strAppend(heff_strAppend(v_t_2416, v_t_2421), ((V)&g_heff_2ecompile_2espec_2ekeyGo_str10));
  }
  case TAG_ELet: {
    V v_x_2422 = heff_field(v_x2_241, 0);
    V v_a_2423 = heff_field(v_x2_241, 1);
    V v_b_2424 = heff_field(v_x2_241, 2);
    V v_t_2425 = (g_heff_2ecompile_2espec_2ekeyGo(heff_dup(v_env_240), v_a_2423));
    V v_t_2426 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2espec_2ekeyGo_str11), v_t_2425), ((V)&g_heff_2ecompile_2espec_2ekeyGo_str12));
    V v_t_2427 = (g_heff_2ecompile_2espec_2ekeyGo(heff_tag_n(TAG_Cons, 2, (V[]){heff_dup(v_x_2422), v_env_240}), v_b_2424));
    return heff_strAppend(heff_strAppend(v_t_2426, v_t_2427), ((V)&g_heff_2ecompile_2espec_2ekeyGo_str13));
  }
  case TAG_ERecord: {
    V v_fs_2428 = heff_field(v_x2_241, 0);
    V v_ts_2429 = heff_field(v_x2_241, 1);
    V v_go_2430 = heff_tr(heff_call(((V)&g_heff_2ecompile_2espec_2ekeyGo_clo), 1, (V[]){v_env_240}));
    V v_x2_2435 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2espec_2ekeyGo_lam0, 1, 1, (V[]){v_go_2430}), heff_dup(v_fs_2428)));
    V v_t_2438;
    switch (heff_tag_of(v_x2_2435)) {
    case TAG_Nil: {
      v_t_2438 = ((V)&g_heff_2ecompile_2espec_2ekeyGo_str15);
      break;
    }
    case TAG_Cons: {
      V v_x_2436 = heff_field(v_x2_2435, 0);
      V v_xs_2437 = heff_field(v_x2_2435, 1);
      heff_take_n(v_x2_2435, 3ULL, 2);
      v_t_2438 = ({ V a_0 = ((V)&g_heff_2ecompile_2espec_2ekeyGo_str16); V a_1 = v_x_2436; V a_2 = v_xs_2437; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2437); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2435);
    }
    V v_t_2439 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2espec_2ekeyGo_str17), v_t_2438), ((V)&g_heff_2ecompile_2espec_2ekeyGo_str18));
    V v_x2_2440 = (g_list_2emap_24s143096761x246530315(heff_dup(v_ts_2429)));
    V v_t_2443;
    switch (heff_tag_of(v_x2_2440)) {
    case TAG_Nil: {
      v_t_2443 = ((V)&g_heff_2ecompile_2espec_2ekeyGo_str19);
      break;
    }
    case TAG_Cons: {
      V v_x_2441 = heff_field(v_x2_2440, 0);
      V v_xs_2442 = heff_field(v_x2_2440, 1);
      heff_take_n(v_x2_2440, 3ULL, 2);
      v_t_2443 = ({ V a_0 = ((V)&g_heff_2ecompile_2espec_2ekeyGo_str20); V a_1 = v_x_2441; V a_2 = v_xs_2442; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2442); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2440);
    }
    return heff_strAppend(heff_strAppend(v_t_2439, v_t_2443), ((V)&g_heff_2ecompile_2espec_2ekeyGo_str21));
  }
  case TAG_EProj: {
    V v_e_2444 = heff_field(v_x2_241, 0);
    V v_l_2445 = heff_field(v_x2_241, 1);
    V v_sh_2446 = heff_field(v_x2_241, 2);
    V v_t_2447 = heff_field(v_x2_241, 3);
    V v_t_2448 = (g_heff_2ecompile_2espec_2ekeyGo(v_env_240, v_e_2444));
    V v_t_2449 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2espec_2ekeyGo_str22), v_t_2448), ((V)&g_heff_2ecompile_2espec_2ekeyGo_str23));
    V v_t_2450 = heff_strAppend(heff_strAppend(v_t_2449, heff_dup(v_l_2445)), ((V)&g_heff_2ecompile_2espec_2ekeyGo_str24));
    V v_t_2453;
    switch (heff_tag_of(v_sh_2446)) {
    case TAG_Nil: {
      v_t_2453 = ((V)&g_heff_2ecompile_2espec_2ekeyGo_str25);
      break;
    }
    case TAG_Cons: {
      V v_x_2451 = heff_field(v_sh_2446, 0);
      V v_xs_2452 = heff_field(v_sh_2446, 1);
      v_t_2453 = (g_prelude_2ejoinWith_2eafter_240(((V)&g_heff_2ecompile_2espec_2ekeyGo_str26), heff_dup(v_x_2451), v_xs_2452));
      break;
    }
    default: heff_nomatch(v_sh_2446);
    }
    V v_t_2454 = heff_strAppend(heff_strAppend(v_t_2450, v_t_2453), ((V)&g_heff_2ecompile_2espec_2ekeyGo_str27));
    V v_t_2456;
    switch (heff_tag_of(v_t_2447)) {
    case TAG_FtFloat: {
      v_t_2456 = ((V)&g_heff_2ecompile_2espec_2ekeyGo_str28);
      break;
    }
    case TAG_FtFixed: {
      V v_w_2455 = heff_field(v_t_2447, 0);
      switch (heff_tag_of(v_w_2455)) {
      case TAG_I8: {
        v_t_2456 = ((V)&g_heff_2ecompile_2espec_2ekeyGo_str29);
        break;
      }
      case TAG_I16: {
        v_t_2456 = ((V)&g_heff_2ecompile_2espec_2ekeyGo_str30);
        break;
      }
      case TAG_I32: {
        v_t_2456 = ((V)&g_heff_2ecompile_2espec_2ekeyGo_str31);
        break;
      }
      case TAG_I64: {
        v_t_2456 = ((V)&g_heff_2ecompile_2espec_2ekeyGo_str32);
        break;
      }
      case TAG_U8: {
        v_t_2456 = ((V)&g_heff_2ecompile_2espec_2ekeyGo_str33);
        break;
      }
      case TAG_U16: {
        v_t_2456 = ((V)&g_heff_2ecompile_2espec_2ekeyGo_str34);
        break;
      }
      case TAG_U32: {
        v_t_2456 = ((V)&g_heff_2ecompile_2espec_2ekeyGo_str35);
        break;
      }
      case TAG_U64: {
        v_t_2456 = ((V)&g_heff_2ecompile_2espec_2ekeyGo_str36);
        break;
      }
      case TAG_F32: {
        v_t_2456 = ((V)&g_heff_2ecompile_2espec_2ekeyGo_str37);
        break;
      }
      default: heff_nomatch(v_w_2455);
      }
      break;
    }
    case TAG_FtOther: {
      v_t_2456 = ((V)&g_heff_2ecompile_2espec_2ekeyGo_str38);
      break;
    }
    case TAG_FtAny: {
      v_t_2456 = ((V)&g_heff_2ecompile_2espec_2ekeyGo_str39);
      break;
    }
    default: heff_nomatch(v_t_2447);
    }
    return heff_strAppend(heff_strAppend(v_t_2454, v_t_2456), ((V)&g_heff_2ecompile_2espec_2ekeyGo_str40));
  }
  case TAG_ETag: {
    V v_t_2457 = heff_field(v_x2_241, 0);
    V v_args_2458 = heff_field(v_x2_241, 1);
    V v_t_2460 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2espec_2ekeyGo_str41), heff_dup(v_t_2457)), ((V)&g_heff_2ecompile_2espec_2ekeyGo_str42));
    V v_go_2461 = heff_tr(heff_call(((V)&g_heff_2ecompile_2espec_2ekeyGo_clo), 1, (V[]){v_env_240}));
    V v_x2_2462 = (g_list_2emap(v_go_2461, heff_dup(v_args_2458)));
    V v_t_2465;
    switch (heff_tag_of(v_x2_2462)) {
    case TAG_Nil: {
      v_t_2465 = ((V)&g_heff_2ecompile_2espec_2ekeyGo_str43);
      break;
    }
    case TAG_Cons: {
      V v_x_2463 = heff_field(v_x2_2462, 0);
      V v_xs_2464 = heff_field(v_x2_2462, 1);
      heff_take_n(v_x2_2462, 3ULL, 2);
      v_t_2465 = ({ V a_0 = ((V)&g_heff_2ecompile_2espec_2ekeyGo_str44); V a_1 = v_x_2463; V a_2 = v_xs_2464; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2464); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2462);
    }
    return heff_strAppend(heff_strAppend(v_t_2460, v_t_2465), ((V)&g_heff_2ecompile_2espec_2ekeyGo_str45));
  }
  case TAG_EMatch: {
    V v_s_2466 = heff_field(v_x2_241, 0);
    V v_arms_2467 = heff_field(v_x2_241, 1);
    V v_t_2468 = (g_heff_2ecompile_2espec_2ekeyGo(heff_dup(v_env_240), v_s_2466));
    V v_x2_2478 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2espec_2ekeyGo_lam1, 1, 1, (V[]){v_env_240}), heff_dup(v_arms_2467)));
    V v_t_2481;
    switch (heff_tag_of(v_x2_2478)) {
    case TAG_Nil: {
      v_t_2481 = ((V)&g_heff_2ecompile_2espec_2ekeyGo_str48);
      break;
    }
    case TAG_Cons: {
      V v_x_2479 = heff_field(v_x2_2478, 0);
      V v_xs_2480 = heff_field(v_x2_2478, 1);
      heff_take_n(v_x2_2478, 3ULL, 2);
      v_t_2481 = ({ V a_0 = ((V)&g_heff_2ecompile_2espec_2ekeyGo_str49); V a_1 = v_x_2479; V a_2 = v_xs_2480; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2480); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2478);
    }
    V v_t_2482 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2espec_2ekeyGo_str50), v_t_2468), v_t_2481);
    return heff_strAppend(v_t_2482, ((V)&g_heff_2ecompile_2espec_2ekeyGo_str51));
  }
  case TAG_EPrim: {
    V v_p_2483 = heff_field(v_x2_241, 0);
    heff_drop(v_env_240);
    V v_t_2484 = (g_heff_2eelab_2eprimitive_2eprimName(v_p_2483));
    return heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2espec_2ekeyGo_str52), v_t_2484), ((V)&g_heff_2ecompile_2espec_2ekeyGo_str53));
  }
  case TAG_EPrimCall: {
    V v_p_2485 = heff_field(v_x2_241, 0);
    V v_args_2486 = heff_field(v_x2_241, 1);
    V v_t_2487 = (g_heff_2eelab_2eprimitive_2eprimName(v_p_2485));
    V v_t_2488 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2espec_2ekeyGo_str54), v_t_2487), ((V)&g_heff_2ecompile_2espec_2ekeyGo_str55));
    V v_go_2489 = heff_tr(heff_call(((V)&g_heff_2ecompile_2espec_2ekeyGo_clo), 1, (V[]){v_env_240}));
    V v_x2_2490 = (g_list_2emap(v_go_2489, heff_dup(v_args_2486)));
    V v_t_2493;
    switch (heff_tag_of(v_x2_2490)) {
    case TAG_Nil: {
      v_t_2493 = ((V)&g_heff_2ecompile_2espec_2ekeyGo_str56);
      break;
    }
    case TAG_Cons: {
      V v_x_2491 = heff_field(v_x2_2490, 0);
      V v_xs_2492 = heff_field(v_x2_2490, 1);
      heff_take_n(v_x2_2490, 3ULL, 2);
      v_t_2493 = ({ V a_0 = ((V)&g_heff_2ecompile_2espec_2ekeyGo_str57); V a_1 = v_x_2491; V a_2 = v_xs_2492; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_2492); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2490);
    }
    return heff_strAppend(heff_strAppend(v_t_2488, v_t_2493), ((V)&g_heff_2ecompile_2espec_2ekeyGo_str58));
  }
  case TAG_ECall: {
    V v_g_2494 = heff_field(v_x2_241, 0);
    V v_args_2495 = heff_field(v_x2_241, 1);
    V v_t_2496 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2espec_2ekeyGo_str59), heff_dup(v_g_2494)), ((V)&g_heff_2ecompile_2espec_2ekeyGo_str60));
    V v_go_2497 = heff_tr(heff_call(((V)&g_heff_2ecompile_2espec_2ekeyGo_clo), 1, (V[]){v_env_240}));
    V v_x2_2498 = (g_list_2emap(v_go_2497, heff_dup(v_args_2495)));
    V v_t_24101;
    switch (heff_tag_of(v_x2_2498)) {
    case TAG_Nil: {
      v_t_24101 = ((V)&g_heff_2ecompile_2espec_2ekeyGo_str61);
      break;
    }
    case TAG_Cons: {
      V v_x_2499 = heff_field(v_x2_2498, 0);
      V v_xs_24100 = heff_field(v_x2_2498, 1);
      heff_take_n(v_x2_2498, 3ULL, 2);
      v_t_24101 = ({ V a_0 = ((V)&g_heff_2ecompile_2espec_2ekeyGo_str62); V a_1 = v_x_2499; V a_2 = v_xs_24100; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24100); r_; });
      break;
    }
    default: heff_nomatch(v_x2_2498);
    }
    return heff_strAppend(heff_strAppend(v_t_2496, v_t_24101), ((V)&g_heff_2ecompile_2espec_2ekeyGo_str63));
  }
  case TAG_EInt: {
    V v_i_24102 = heff_field(v_x2_241, 0);
    heff_drop(v_env_240);
    return heff_strAppend(((V)&g_heff_2ecompile_2espec_2ekeyGo_str64), heff_intShow(heff_dup(v_i_24102)));
  }
  case TAG_EFloat: {
    V v_x_24103 = heff_tget_v(v_x2_241, 0);
    heff_drop(v_env_240);
    return heff_strAppend(((V)&g_heff_2ecompile_2espec_2ekeyGo_str65), heff_floatShow(v_x_24103));
  }
  case TAG_EStr: {
    V v_s_24104 = heff_field(v_x2_241, 0);
    heff_drop(v_env_240);
    V v_t_24105 = heff_intShow(heff_strLength_lent(v_s_24104, 0));
    V v_t_24106 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2espec_2ekeyGo_str66), v_t_24105), ((V)&g_heff_2ecompile_2espec_2ekeyGo_str67));
    return heff_strAppend(v_t_24106, heff_dup(v_s_24104));
  }
  case TAG_EBytes: {
    V v_s_24107 = heff_field(v_x2_241, 0);
    heff_drop(v_env_240);
    V v_t_24108 = heff_intShow(heff_strLength_lent(v_s_24107, 0));
    V v_t_24109 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2espec_2ekeyGo_str68), v_t_24108), ((V)&g_heff_2ecompile_2espec_2ekeyGo_str69));
    return heff_strAppend(v_t_24109, heff_dup(v_s_24107));
  }
  case TAG_EFixed: {
    V v_w_24110 = heff_field(v_x2_241, 0);
    V v_n_24111 = heff_field(v_x2_241, 1);
    heff_drop(v_env_240);
    V v_t_24112;
    switch (heff_tag_of(v_w_24110)) {
    case TAG_I8: {
      v_t_24112 = ((V)&g_heff_2ecompile_2espec_2ekeyGo_str70);
      break;
    }
    case TAG_I16: {
      v_t_24112 = ((V)&g_heff_2ecompile_2espec_2ekeyGo_str71);
      break;
    }
    case TAG_I32: {
      v_t_24112 = ((V)&g_heff_2ecompile_2espec_2ekeyGo_str72);
      break;
    }
    case TAG_I64: {
      v_t_24112 = ((V)&g_heff_2ecompile_2espec_2ekeyGo_str73);
      break;
    }
    case TAG_U8: {
      v_t_24112 = ((V)&g_heff_2ecompile_2espec_2ekeyGo_str74);
      break;
    }
    case TAG_U16: {
      v_t_24112 = ((V)&g_heff_2ecompile_2espec_2ekeyGo_str75);
      break;
    }
    case TAG_U32: {
      v_t_24112 = ((V)&g_heff_2ecompile_2espec_2ekeyGo_str76);
      break;
    }
    case TAG_U64: {
      v_t_24112 = ((V)&g_heff_2ecompile_2espec_2ekeyGo_str77);
      break;
    }
    case TAG_F32: {
      v_t_24112 = ((V)&g_heff_2ecompile_2espec_2ekeyGo_str78);
      break;
    }
    default: heff_nomatch(v_w_24110);
    }
    V v_t_24113 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2espec_2ekeyGo_str79), v_t_24112), ((V)&g_heff_2ecompile_2espec_2ekeyGo_str80));
    return heff_strAppend(v_t_24113, heff_intShow(heff_dup(v_n_24111)));
  }
  case TAG_EFloat32: {
    V v_x_24114 = heff_tget_v(v_x2_241, 0);
    heff_drop(v_env_240);
    return heff_strAppend(((V)&g_heff_2ecompile_2espec_2ekeyGo_str81), heff_floatShow(v_x_24114));
  }
  case TAG_EAbandon: {
    heff_drop(v_env_240);
    return ((V)&g_heff_2ecompile_2espec_2ekeyGo_str82);
  }
  case TAG_EBool: {
    V v_c_24115 = heff_field(v_x2_241, 0);
    V v_t_24116 = heff_tr(heff_call(((V)&g_heff_2ecompile_2espec_2ekeyGo_clo), 1, (V[]){v_env_240}));
    V v_t_24117 = (g_heff_2ecompile_2espec_2econdKey(v_t_24116, v_c_24115));
    return heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2espec_2ekeyGo_str83), v_t_24117), ((V)&g_heff_2ecompile_2espec_2ekeyGo_str84));
  }
  case TAG_ESet: {
    V v_xs_24118 = heff_field(v_x2_241, 0);
    V v_a_24119 = heff_field(v_x2_241, 1);
    V v_b_24120 = heff_field(v_x2_241, 2);
    V v_t_24121 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_xs_24118));
    V v_t_24122 = heff_strAppend(((V)&g_heff_2ecompile_2espec_2ekeyGo_str85), heff_intShow(v_t_24121));
    V v_t_24123 = (g_heff_2ecompile_2espec_2ekeyGo(heff_dup(v_env_240), v_a_24119));
    V v_t_24124 = heff_strAppend(heff_strAppend(v_t_24122, ((V)&g_heff_2ecompile_2espec_2ekeyGo_str86)), v_t_24123);
    V v_t_24125 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), heff_dup(v_xs_24118)));
    V v_t_24126 = (g_prelude_2e_2b_2b(v_t_24125, v_env_240));
    V v_t_24127 = (g_heff_2ecompile_2espec_2ekeyGo(v_t_24126, v_b_24120));
    V v_t_24128 = heff_strAppend(heff_strAppend(v_t_24124, ((V)&g_heff_2ecompile_2espec_2ekeyGo_str87)), v_t_24127);
    return heff_strAppend(v_t_24128, ((V)&g_heff_2ecompile_2espec_2ekeyGo_str88));
  }
  case TAG_EValues: {
    V v_es_24129 = heff_field(v_x2_241, 0);
    V v_go_24130 = heff_tr(heff_call(((V)&g_heff_2ecompile_2espec_2ekeyGo_clo), 1, (V[]){v_env_240}));
    V v_x2_24131 = (g_list_2emap(v_go_24130, heff_dup(v_es_24129)));
    V v_t_24134;
    switch (heff_tag_of(v_x2_24131)) {
    case TAG_Nil: {
      v_t_24134 = ((V)&g_heff_2ecompile_2espec_2ekeyGo_str89);
      break;
    }
    case TAG_Cons: {
      V v_x_24132 = heff_field(v_x2_24131, 0);
      V v_xs_24133 = heff_field(v_x2_24131, 1);
      heff_take_n(v_x2_24131, 3ULL, 2);
      v_t_24134 = ({ V a_0 = ((V)&g_heff_2ecompile_2espec_2ekeyGo_str90); V a_1 = v_x_24132; V a_2 = v_xs_24133; V r_ = (g_prelude_2ejoinWith_2eafter_240(a_0, a_1, a_2)); heff_drop(v_xs_24133); r_; });
      break;
    }
    default: heff_nomatch(v_x2_24131);
    }
    return heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2espec_2ekeyGo_str91), v_t_24134), ((V)&g_heff_2ecompile_2espec_2ekeyGo_str92));
  }
  case TAG_EFix: {
    heff_drop(v_env_240);
    return ((V)&g_heff_2ecompile_2espec_2ekeyGo_str93);
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2espec_2ekeyGo_entry(V self, V *a) {
  (void)self;
  V a1 = a[1]; V r = g_heff_2ecompile_2espec_2ekeyGo(a[0], a1); heff_drop(a1); return r;
}
V g_heff_2ecompile_2espec_2ekeyGo_lam0(V self, V *args) {
  V v_x2_2431 = args[0];
  V v_go_2430 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x2_2431)) {
  case TAG_MkPair: {
    V v_l_2432 = heff_field(v_x2_2431, 0);
    V v_v_2433 = heff_field(v_x2_2431, 1);
    heff_take_n(v_x2_2431, 3ULL, 2);
    V v_t_2434 = heff_tr(heff_call(v_go_2430, 1, (V[]){v_v_2433}));
    return heff_strAppend(heff_strAppend(v_l_2432, ((V)&g_heff_2ecompile_2espec_2ekeyGo_str14)), v_t_2434);
  }
  default: return heff_nomatch(v_x2_2431);
  }
}
V g_heff_2ecompile_2espec_2ekeyGo_lam1(V self, V *args) {
  V v_x3_2469 = args[0];
  V v_env_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_x3_2469)) {
  case TAG_MkArm: {
    V v_t_2470 = heff_field(v_x3_2469, 0);
    V v_vs_2471 = heff_field(v_x3_2469, 1);
    V v_b_2472 = heff_field(v_x3_2469, 2);
    heff_take_n(v_x3_2469, 7ULL, 3);
    V v_t_2473 = (g_list_2efoldl_24s65689923x209800052(MK_INT(1LL), MK_INT(0LL), v_vs_2471));
    V v_t_2474 = heff_strAppend(heff_strAppend(((V)&g_heff_2ecompile_2espec_2ekeyGo_str46), v_t_2470), heff_intShow(v_t_2473));
    V v_t_2475 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_vs_2471));
    V v_t_2476 = (g_prelude_2e_2b_2b(v_t_2475, v_env_240));
    V v_t_2477 = ({ V a_0 = v_t_2476; V a_1 = v_b_2472; V r_ = (g_heff_2ecompile_2espec_2ekeyGo(a_0, a_1)); heff_drop(v_b_2472); r_; });
    return heff_strAppend(heff_strAppend(v_t_2474, ((V)&g_heff_2ecompile_2espec_2ekeyGo_str47)), v_t_2477);
  }
  default: return heff_nomatch(v_x3_2469);
  }
}
HEFF_LIT(g_heff_2ecompile_2espec_2ehashGo_str0, 1, "x");
Clo g_heff_2ecompile_2espec_2ehashGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2espec_2ehashGo_entry, 4, 0};

V g_heff_2ecompile_2espec_2ehashGo(V v_s_240, V v_box_24i_241, V v_box_24a_242, V v_box_24b_243) {
  int64_t v_i_241 = heff_unbox_word(v_box_24i_241);
  int64_t v_a_242 = heff_unbox_word(v_box_24a_242);
  int64_t v_b_243 = heff_unbox_word(v_box_24b_243);
top: ;
  if ((heff_unbox_word(heff_strLength_lent(v_s_240, 0)) <= v_i_241)) {
    V v_t_244 = heff_strAppend(heff_intShow(heff_box_word(v_a_242)), ((V)&g_heff_2ecompile_2espec_2ehashGo_str0));
    return heff_strAppend(v_t_244, heff_intShow(heff_box_word(v_b_243)));
  } else {
    int64_t v_t_245 = ((v_a_242 * ((int64_t)1000003ULL)) + heff_unbox_word(heff_strByteAt_lent(v_s_240, heff_box_word(v_i_241), 2)));
    int64_t v_t_246 = ((v_t_245 + ((int64_t)1ULL)) % ((int64_t)2147483647ULL));
    int64_t v_t_247 = ((v_b_243 * ((int64_t)999983ULL)) + heff_unbox_word(heff_strByteAt_lent(v_s_240, heff_box_word(v_i_241), 2)));
    int64_t v_t_248 = ((v_t_247 + ((int64_t)1ULL)) % ((int64_t)2147483629ULL));
    V t_0 = v_s_240;
    int64_t t_1 = (v_i_241 + ((int64_t)1ULL));
    int64_t t_2 = v_t_246;
    int64_t t_3 = v_t_248;
    v_s_240 = t_0;
    v_i_241 = t_1;
    v_a_242 = t_2;
    v_b_243 = t_3;
    goto top;
  }
}
V g_heff_2ecompile_2espec_2ehashGo_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2espec_2ehashGo(a0, a[1], a[2], a[3]); heff_drop(a0); return r;
}

HeffT2 g_heff_2ecompile_2espec_2eshapeArms_24cpr(V v_go_240, V v_x2_241, V v_st_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_go_240);
    return ((HeffT2){{NTAG(TAG_Nil), v_st_242}});
  }
  case TAG_Cons: {
    V v_x21_243 = heff_field(v_x2_241, 0);
    V v_rest_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    switch (heff_tag_of(v_x21_243)) {
    case TAG_MkArm: {
      V v_t_245 = heff_field(v_x21_243, 0);
      V v_vs_246 = heff_field(v_x21_243, 1);
      V v_b_247 = heff_field(v_x21_243, 2);
      V v_ru_24x21_243_24MkArm = heff_take_reuse_n(v_x21_243, 7ULL, 3);
      V v_more_248 = heff_tr(heff_call(((V)&g_heff_2ecompile_2espec_2eshapeArms_clo), 2, (V[]){heff_dup(v_go_240), v_rest_244}));
      V v_t_249 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), heff_dup(v_st_242)});
      V v_t_2410 = (g_list_2efoldl_24s1048046132x95752937(v_t_249, v_vs_246));
      switch (heff_tag_of(v_t_2410)) {
      case TAG_MkPair: {
        V v_ys_2411 = heff_field(v_t_2410, 0);
        V v_st2_2412 = heff_field(v_t_2410, 1);
        heff_take_n(v_t_2410, 3ULL, 2);
        V v_t_2413 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ys_2411));
        V v_x2_2414 = heff_tr(heff_call(v_go_240, 2, (V[]){v_b_247, v_st2_2412}));
        switch (heff_tag_of(v_x2_2414)) {
        case TAG_MkPair: {
          V v_e_2415 = heff_field(v_x2_2414, 0);
          V v_st_2416 = heff_field(v_x2_2414, 1);
          heff_take_n(v_x2_2414, 3ULL, 2);
          V v_t_2417 = ({ V rv_1 = heff_take_field(v_st_2416, 1); V rv_2 = heff_take_field(v_st_2416, 2); V rv_3 = heff_take_field(v_st_2416, 3); V rv_4 = heff_get_n(v_st_2416, 4, 5); V rr_ = heff_rec_reuse_nf(v_st_242, 1ULL, 5, shape_ren__caps__vars__holes__n, 3u, 0u); heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; rr_; });
          V v_b_2418 = v_e_2415;
          V v_st_2419 = v_t_2417;
          V v_x2_2420 = heff_tr(heff_call(v_more_248, 1, (V[]){v_st_2419}));
          switch (heff_tag_of(v_x2_2420)) {
          case TAG_MkPair: {
            V v_args_2421 = heff_field(v_x2_2420, 0);
            V v_st_2422 = heff_field(v_x2_2420, 1);
            heff_take_n(v_x2_2420, 3ULL, 2);
            V v_t_2423 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x21_243_24MkArm, TAG_MkArm, 3, (V[]){v_t_245, v_t_2413, v_b_2418}), v_args_2421});
            return ((HeffT2){{v_t_2423, v_st_2422}});
          }
          default: return ((HeffT2){{heff_nomatch(v_x2_2420)}});
          }
        }
        default: return ((HeffT2){{heff_nomatch(v_x2_2414)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_t_2410)}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_x21_243)}});
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
Clo g_heff_2ecompile_2espec_2eshapeArms_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2espec_2eshapeArms_entry, 3, 0};

V g_heff_2ecompile_2espec_2eshapeArms(V v_go_240, V v_x2_241, V v_st_242) {
top: ;
  HeffT2 v_t_243 = (g_heff_2ecompile_2espec_2eshapeArms_24cpr(v_go_240, v_x2_241, v_st_242));
  {
    V v_field_244 = v_t_243.f[0];
    V v_field_245 = v_t_243.f[1];
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_field_244, v_field_245});
  }
}
V g_heff_2ecompile_2espec_2eshapeArms_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2espec_2eshapeArms(a[0], a[1], a[2]);
}
HEFF_LIT(g_heff_2ecompile_2espec_2eshapeGo_24cpr_str0, 4, "lit$");
HEFF_LIT(g_heff_2ecompile_2espec_2eshapeGo_24cpr_str1, 4, "lit$");
HEFF_LIT(g_heff_2ecompile_2espec_2eshapeGo_24cpr_str2, 4, "lit$");
HEFF_LIT(g_heff_2ecompile_2espec_2eshapeGo_24cpr_str3, 2, "a$");
HEFF_LIT(g_heff_2ecompile_2espec_2eshapeGo_24cpr_str4, 2, "a$");
HEFF_LIT(g_heff_2ecompile_2espec_2eshapeGo_24cpr_str5, 4, "lit$");
HEFF_LIT(g_heff_2ecompile_2espec_2eshapeGo_24cpr_str6, 4, "lit$");
HEFF_LIT(g_heff_2ecompile_2espec_2eshapeGo_24cpr_str7, 4, "lit$");
HEFF_LIT(g_heff_2ecompile_2espec_2eshapeGo_24cpr_str8, 4, "lit$");
HEFF_LIT(g_heff_2ecompile_2espec_2eshapeGo_24cpr_str9, 4, "lit$");
HEFF_LIT(g_heff_2ecompile_2espec_2eshapeGo_24cpr_str10, 4, "lit$");

HeffT2 g_heff_2ecompile_2espec_2eshapeGo_24cpr(V v_e_240, V v_st_241) {
top: ;
  switch (heff_tag_of(v_e_240)) {
  case TAG_EVar: {
    V v_x_242 = heff_field(v_e_240, 0);
    V v_ru_24e_240_24EVar = heff_take_reuse_n(v_e_240, 1ULL, 1);
    HeffT2 v_t_243 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(heff_rfield(v_st_241, 0), v_x_242));
    {
      V v_field_245 = v_t_243.f[1];
      int64_t v_tag_244 = ((int64_t)v_t_243.f[0]);
      HeffT2 v_t_246 = (g_std_2eordmap_2elookup_24s305164685x44869932_24cpr(heff_rfield(v_st_241, 1), v_x_242));
      {
        V v_field_248 = v_t_246.f[1];
        int64_t v_tag_247 = ((int64_t)v_t_246.f[0]);
        if ((v_tag_244 == ((int64_t)0ULL))) {
          heff_drop(v_x_242);
          heff_drop(v_field_248);
          V v_y_249 = v_field_245;
          return ((HeffT2){{heff_tag_at_n(v_ru_24e_240_24EVar, TAG_EVar, 1, (V[]){v_y_249}), v_st_241}});
        } else {
          heff_drop(v_field_245);
          if ((v_tag_247 == ((int64_t)0ULL))) {
            heff_drop(v_x_242);
            V v_h_2410 = v_field_248;
            return ((HeffT2){{heff_tag_at_n(v_ru_24e_240_24EVar, TAG_EVar, 1, (V[]){v_h_2410}), v_st_241}});
          } else {
            heff_drop(v_field_248);
            V v_x_2411 = v_x_242;
            V v_st_2412 = v_st_241;
            V v_t_2413 = heff_intShow(heff_dup(heff_rfield(v_st_2412, 4)));
            V v_f_2414 = heff_tag_at_n(v_ru_24e_240_24EVar, TAG_EVar, 1, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2espec_2eshapeGo_24cpr_str0), v_t_2413)});
            V v_t_2415 = heff_intShow(heff_dup(heff_rfield(v_st_2412, 4)));
            V v_t_2416 = (g_std_2eordmap_2einsert_24s615484302x989744458(heff_take_field(v_st_2412, 1), heff_dup(v_x_2411), heff_strAppend(((V)&g_heff_2ecompile_2espec_2eshapeGo_24cpr_str1), v_t_2415)));
            V v_t_2417 = heff_intShow(heff_dup(heff_rfield(v_st_2412, 4)));
            V v_t_2418 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2espec_2eshapeGo_24cpr_str2), v_t_2417), heff_take_field(v_st_2412, 2)});
            V v_t_2419 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_n(TAG_EVar, 1, (V[]){v_x_2411}), heff_take_field(v_st_2412, 3)});
            V v_t_2420 = heff_intAdd(heff_take_field(v_st_2412, 4), MK_INT(1LL));
            V v_f_2421 = ({ V rv_1 = v_t_2416; V rv_2 = v_t_2418; V rv_3 = v_t_2419; V rv_4 = v_t_2420; V rr_ = heff_rec_reuse_nf(v_st_2412, 1ULL, 5, shape_ren__caps__vars__holes__n, 3u, 0u); heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; rr_; });
            return ((HeffT2){{v_f_2414, v_f_2421}});
          }
        }
      }
    }
  }
  case TAG_ELam: {
    V v_xs_2422 = heff_field(v_e_240, 0);
    V v_b_2423 = heff_field(v_e_240, 1);
    V v_ru_24e_240_24ELam = heff_take_reuse_n(v_e_240, 3ULL, 2);
    V v_t_2424 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), heff_dup(v_st_241)});
    V v_t_2425 = (g_list_2efoldl_24s1048046132x95752937(v_t_2424, v_xs_2422));
    switch (heff_tag_of(v_t_2425)) {
    case TAG_MkPair: {
      V v_ys_2426 = heff_field(v_t_2425, 0);
      V v_st2_2427 = heff_field(v_t_2425, 1);
      heff_take_n(v_t_2425, 3ULL, 2);
      V v_t_2428 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ys_2426));
      HeffT2 v_t_2429 = (g_heff_2ecompile_2espec_2eshapeGo_24cpr(v_b_2423, v_st2_2427));
      {
        V v_field_2430 = v_t_2429.f[0];
        V v_field_2431 = v_t_2429.f[1];
        V v_e_2432 = v_field_2430;
        V v_st_2433 = v_field_2431;
        V v_f_2434 = ({ V rv_1 = heff_take_field(v_st_2433, 1); V rv_2 = heff_take_field(v_st_2433, 2); V rv_3 = heff_take_field(v_st_2433, 3); V rv_4 = heff_get_n(v_st_2433, 4, 5); V rr_ = heff_rec_reuse_nf(v_st_241, 1ULL, 5, shape_ren__caps__vars__holes__n, 3u, 0u); heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; rr_; });
        return ((HeffT2){{heff_tag_at_n(v_ru_24e_240_24ELam, TAG_ELam, 2, (V[]){v_t_2428, v_e_2432}), v_f_2434}});
      }
    }
    default: return ((HeffT2){{heff_nomatch(v_t_2425)}});
    }
  }
  case TAG_ELet: {
    V v_x_2435 = heff_field(v_e_240, 0);
    V v_a_2436 = heff_field(v_e_240, 1);
    V v_b_2437 = heff_field(v_e_240, 2);
    V v_ru_24e_240_24ELet = heff_take_reuse_n(v_e_240, 7ULL, 3);
    V v_go_2438 = ((V)&g_heff_2ecompile_2espec_2eshapeGo_clo);
    V v_x_2439 = v_x_2435;
    V v_b_2440 = v_b_2437;
    HeffT2 v_t_2441 = (g_heff_2ecompile_2espec_2eshapeGo_24cpr(v_a_2436, v_st_241));
    {
      V v_field_2442 = v_t_2441.f[0];
      V v_field_2443 = v_t_2441.f[1];
      V v_a_2444 = v_field_2442;
      V v_st_2445 = v_field_2443;
      V v_lit_2446 = heff_dup(v_x_2439);
      V v_st_2447 = heff_dup(v_st_2445);
      V v_t_2448 = heff_intShow(heff_dup(heff_rfield(v_st_2447, 4)));
      V v_t_2449 = heff_strAppend(((V)&g_heff_2ecompile_2espec_2eshapeGo_24cpr_str3), v_t_2448);
      V v_t_2450 = heff_intShow(heff_dup(heff_rfield(v_st_2447, 4)));
      V v_t_2451 = (g_std_2eordmap_2einsert_24s615484302x989744458(heff_take_field(v_st_2447, 0), v_lit_2446, heff_strAppend(((V)&g_heff_2ecompile_2espec_2eshapeGo_24cpr_str4), v_t_2450)));
      V v_t_2452 = heff_intAdd(heff_take_field(v_st_2447, 4), MK_INT(1LL));
      V v_st2_2453 = ({ V rv_0 = v_t_2451; V rv_4 = v_t_2452; V rr_ = heff_rec_reuse_nf(v_st_2447, 14ULL, 5, shape_ren__caps__vars__holes__n, 252u, 0u); heff_rfield(rr_, 0) = rv_0; heff_rfield(rr_, 4) = rv_4; rr_; });
      V v_t_2454 = heff_tag_n(TAG_Cons, 2, (V[]){v_t_2449, NTAG(TAG_Nil)});
      V v_x5_2455 = heff_tag_n(TAG_MkPair, 2, (V[]){v_t_2454, v_st2_2453});
      switch (heff_tag_of(v_x5_2455)) {
      case TAG_MkPair: {
        V v_ys_2456 = heff_field(v_x5_2455, 0);
        V v_st_2457 = heff_field(v_x5_2455, 1);
        heff_take_n(v_x5_2455, 3ULL, 2);
        V v_x2_2458 = heff_tr(heff_call(v_go_2438, 2, (V[]){v_b_2440, v_st_2457}));
        switch (heff_tag_of(v_x2_2458)) {
        case TAG_MkPair: {
          V v_e_2459 = heff_field(v_x2_2458, 0);
          V v_st_2460 = heff_field(v_x2_2458, 1);
          heff_take_n(v_x2_2458, 3ULL, 2);
          V v_t_2463;
          switch (heff_tag_of(v_ys_2456)) {
          case TAG_Nil: {
            v_t_2463 = v_x_2439;
            break;
          }
          case TAG_Cons: {
            V v_y_2461 = heff_field(v_ys_2456, 0);
            heff_take_n(v_ys_2456, 1ULL, 2);
            heff_drop(v_x_2439);
            v_t_2463 = v_y_2461;
            break;
          }
          default: heff_nomatch(v_ys_2456);
          }
          V v_f_2464 = heff_tag_at_n(v_ru_24e_240_24ELet, TAG_ELet, 3, (V[]){v_t_2463, v_a_2444, v_e_2459});
          V v_f_2465 = ({ V rv_1 = heff_take_field(v_st_2460, 1); V rv_2 = heff_take_field(v_st_2460, 2); V rv_3 = heff_take_field(v_st_2460, 3); V rv_4 = heff_get_n(v_st_2460, 4, 5); V rr_ = heff_rec_reuse_nf(v_st_2445, 1ULL, 5, shape_ren__caps__vars__holes__n, 3u, 0u); heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; rr_; });
          return ((HeffT2){{v_f_2464, v_f_2465}});
        }
        default: return ((HeffT2){{heff_nomatch(v_x2_2458)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_x5_2455)}});
      }
    }
  }
  case TAG_EMatch: {
    V v_sc_2466 = heff_field(v_e_240, 0);
    V v_arms_2467 = heff_field(v_e_240, 1);
    V v_ru_24e_240_24EMatch = heff_take_reuse_n(v_e_240, 3ULL, 2);
    HeffT2 v_t_2468 = (g_heff_2ecompile_2espec_2eshapeGo_24cpr(v_sc_2466, v_st_241));
    {
      V v_field_2469 = v_t_2468.f[0];
      V v_field_2470 = v_t_2468.f[1];
      V v_sc_2471 = v_field_2469;
      V v_st_2472 = v_field_2470;
      HeffT2 v_t_2473 = (g_heff_2ecompile_2espec_2eshapeArms_24cpr(((V)&g_heff_2ecompile_2espec_2eshapeGo_clo), v_arms_2467, v_st_2472));
      {
        V v_field_2474 = v_t_2473.f[0];
        V v_field_2475 = v_t_2473.f[1];
        V v_arms2_2476 = v_field_2474;
        V v_st2_2477 = v_field_2475;
        return ((HeffT2){{heff_tag_at_n(v_ru_24e_240_24EMatch, TAG_EMatch, 2, (V[]){v_sc_2471, v_arms2_2476}), v_st2_2477}});
      }
    }
  }
  case TAG_EInt: {
    V v_i_2478 = heff_field(v_e_240, 0);
    V v_ru_24e_240_24EInt = heff_take_reuse_n(v_e_240, 1ULL, 1);
    V v_t_2479 = heff_intShow(heff_dup(heff_rfield(v_st_241, 4)));
    V v_f_2480 = heff_tag_n(TAG_EVar, 1, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2espec_2eshapeGo_24cpr_str5), v_t_2479)});
    V v_t_2481 = heff_intShow(heff_dup(heff_rfield(v_st_241, 4)));
    V v_t_2482 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2espec_2eshapeGo_24cpr_str6), v_t_2481), heff_take_field(v_st_241, 2)});
    V v_t_2483 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24e_240_24EInt, TAG_EInt, 1, (V[]){v_i_2478}), heff_take_field(v_st_241, 3)});
    V v_t_2484 = heff_intAdd(heff_take_field(v_st_241, 4), MK_INT(1LL));
    V v_f_2485 = ({ V rv_2 = v_t_2482; V rv_3 = v_t_2483; V rv_4 = v_t_2484; V rr_ = heff_rec_reuse_nf(v_st_241, 3ULL, 5, shape_ren__caps__vars__holes__n, 15u, 0u); heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; rr_; });
    return ((HeffT2){{v_f_2480, v_f_2485}});
  }
  case TAG_EFloat: {
    double v_x_2486 = heff_tget_f64(v_e_240, 0);
    V v_ru_24e_240_24EFloat = heff_take_reuse_nf(v_e_240, 0ULL, 1);
    V v_t_2487 = heff_intShow(heff_dup(heff_rfield(v_st_241, 4)));
    V v_f_2488 = heff_tag_n(TAG_EVar, 1, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2espec_2eshapeGo_24cpr_str7), v_t_2487)});
    V v_t_2489 = heff_intShow(heff_dup(heff_rfield(v_st_241, 4)));
    V v_t_2490 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2espec_2eshapeGo_24cpr_str8), v_t_2489), heff_take_field(v_st_241, 2)});
    V v_t_2491 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_nf(v_ru_24e_240_24EFloat, TAG_EFloat, 1, 1u, (V[]){heff_word_f64(v_x_2486)}), heff_take_field(v_st_241, 3)});
    V v_t_2492 = heff_intAdd(heff_take_field(v_st_241, 4), MK_INT(1LL));
    V v_f_2493 = ({ V rv_2 = v_t_2490; V rv_3 = v_t_2491; V rv_4 = v_t_2492; V rr_ = heff_rec_reuse_nf(v_st_241, 3ULL, 5, shape_ren__caps__vars__holes__n, 15u, 0u); heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; rr_; });
    return ((HeffT2){{v_f_2488, v_f_2493}});
  }
  case TAG_EStr: {
    V v_t_2494 = heff_field(v_e_240, 0);
    V v_ru_24e_240_24EStr = heff_take_reuse_n(v_e_240, 1ULL, 1);
    V v_t_2495 = heff_intShow(heff_dup(heff_rfield(v_st_241, 4)));
    V v_f_2496 = heff_tag_n(TAG_EVar, 1, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2espec_2eshapeGo_24cpr_str9), v_t_2495)});
    V v_t_2497 = heff_intShow(heff_dup(heff_rfield(v_st_241, 4)));
    V v_t_2498 = heff_tag_n(TAG_Cons, 2, (V[]){heff_strAppend(((V)&g_heff_2ecompile_2espec_2eshapeGo_24cpr_str10), v_t_2497), heff_take_field(v_st_241, 2)});
    V v_t_2499 = heff_tag_n(TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24e_240_24EStr, TAG_EStr, 1, (V[]){v_t_2494}), heff_take_field(v_st_241, 3)});
    V v_t_24100 = heff_intAdd(heff_take_field(v_st_241, 4), MK_INT(1LL));
    V v_f_24101 = ({ V rv_2 = v_t_2498; V rv_3 = v_t_2499; V rv_4 = v_t_24100; V rr_ = heff_rec_reuse_nf(v_st_241, 3ULL, 5, shape_ren__caps__vars__holes__n, 15u, 0u); heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; rr_; });
    return ((HeffT2){{v_f_2496, v_f_24101}});
  }
  case TAG_ESet: {
    V v_xs_24102 = heff_field(v_e_240, 0);
    V v_a_24103 = heff_field(v_e_240, 1);
    V v_b_24104 = heff_field(v_e_240, 2);
    V v_ru_24e_240_24ESet = heff_take_reuse_n(v_e_240, 7ULL, 3);
    V v_go_24105 = ((V)&g_heff_2ecompile_2espec_2eshapeGo_clo);
    V v_xs_24106 = v_xs_24102;
    V v_b_24107 = v_b_24104;
    HeffT2 v_t_24108 = (g_heff_2ecompile_2espec_2eshapeGo_24cpr(v_a_24103, v_st_241));
    {
      V v_field_24109 = v_t_24108.f[0];
      V v_field_24110 = v_t_24108.f[1];
      V v_a_24111 = v_field_24109;
      V v_st_24112 = v_field_24110;
      V v_t_24113 = heff_tag_n(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), heff_dup(v_st_24112)});
      V v_t_24114 = (g_list_2efoldl_24s1048046132x95752937(v_t_24113, v_xs_24106));
      switch (heff_tag_of(v_t_24114)) {
      case TAG_MkPair: {
        V v_ys_24115 = heff_field(v_t_24114, 0);
        V v_st2_24116 = heff_field(v_t_24114, 1);
        heff_take_n(v_t_24114, 3ULL, 2);
        V v_t_24117 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_ys_24115));
        V v_x2_24118 = heff_tr(heff_call(v_go_24105, 2, (V[]){v_b_24107, v_st2_24116}));
        switch (heff_tag_of(v_x2_24118)) {
        case TAG_MkPair: {
          V v_e_24119 = heff_field(v_x2_24118, 0);
          V v_st_24120 = heff_field(v_x2_24118, 1);
          heff_take_n(v_x2_24118, 3ULL, 2);
          V v_f_24121 = ({ V rv_1 = heff_take_field(v_st_24120, 1); V rv_2 = heff_take_field(v_st_24120, 2); V rv_3 = heff_take_field(v_st_24120, 3); V rv_4 = heff_get_n(v_st_24120, 4, 5); V rr_ = heff_rec_reuse_nf(v_st_24112, 1ULL, 5, shape_ren__caps__vars__holes__n, 3u, 0u); heff_rfield(rr_, 1) = rv_1; heff_rfield(rr_, 2) = rv_2; heff_rfield(rr_, 3) = rv_3; heff_rfield(rr_, 4) = rv_4; rr_; });
          return ((HeffT2){{heff_tag_at_n(v_ru_24e_240_24ESet, TAG_ESet, 3, (V[]){v_t_24117, v_a_24111, v_e_24119}), v_f_24121}});
        }
        default: return ((HeffT2){{heff_nomatch(v_x2_24118)}});
        }
      }
      default: return ((HeffT2){{heff_nomatch(v_t_24114)}});
      }
    }
  }
  default: {
    HEFF_LAST return g_heff_2ecompile_2eir_2etraversePartsM_24s1049679562x279661776_24cpr(v_e_240, v_st_241);
  }
  }
}
Clo g_heff_2ecompile_2espec_2eshapeGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2espec_2eshapeGo_entry, 2, 0};

V g_heff_2ecompile_2espec_2eshapeGo(V v_e_240, V v_st_241) {
top: ;
  HeffT2 v_t_242 = (g_heff_2ecompile_2espec_2eshapeGo_24cpr(v_e_240, v_st_241));
  {
    V v_field_243 = v_t_242.f[0];
    V v_field_244 = v_t_242.f[1];
    return heff_tag_n(TAG_MkPair, 2, (V[]){v_field_243, v_field_244});
  }
}
V g_heff_2ecompile_2espec_2eshapeGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2espec_2eshapeGo(a[0], a[1]);
}
V g_heff_2ecompile_2espec_2eusesOf_lam0(V self, V *args);
V g_heff_2ecompile_2espec_2eusesOf_lam1(V self, V *args);
V g_heff_2ecompile_2espec_2eusesOf_lam2(V self, V *args);
Clo g_heff_2ecompile_2espec_2eusesOf_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2espec_2eusesOf_entry, 2, 0};

V g_heff_2ecompile_2espec_2eusesOf(V v_g_240, V v_e_241) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_EGlobal: {
    V v_h_242 = heff_field(v_e_241, 0);
    heff_take_n(v_e_241, 1ULL, 1);
    if (heff_strEq_c(v_h_242, v_g_240)) {
      return heff_tag_n(TAG_Cons, 2, (V[]){NTAG(TAG_Nothing), NTAG(TAG_Nil)});
    } else {
      return NTAG(TAG_Nil);
    }
  }
  case TAG_EApp: {
    V v_f_243 = heff_field(v_e_241, 0);
    V v_args_244 = heff_field(v_e_241, 1);
    V v_ru_24e_241_24EApp = heff_take_reuse_n(v_e_241, 3ULL, 2);
    V v_g_245 = heff_dup(v_g_240);
    V v_x2_246 = heff_dup(v_f_243);
    V v_args_247 = heff_dup(v_args_244);
    V v_t_2447;
    switch (heff_tag_of(v_x2_246)) {
    case TAG_EVar: {
      heff_take_n(v_x2_246, 0ULL, 1);
      heff_drop_cell(v_ru_24e_241_24EApp, 2);
      heff_drop(v_g_245);
      heff_drop(v_args_247);
      v_t_2447 = NTAG(TAG_Nil);
      break;
    }
    case TAG_EGlobal: {
      V v_h_249 = heff_field(v_x2_246, 0);
      V v_ru_24x2_246_24EGlobal = heff_take_reuse_n(v_x2_246, 1ULL, 1);
      if (heff_strEq_c(v_h_249, v_g_245)) {
        v_t_2447 = heff_tag_at_n(v_ru_24e_241_24EApp, TAG_Cons, 2, (V[]){heff_tag_at_n(v_ru_24x2_246_24EGlobal, TAG_Just, 1, (V[]){v_args_247}), NTAG(TAG_Nil)});
      } else {
        heff_drop_cell(v_ru_24e_241_24EApp, 2);
        heff_drop(v_args_247);
        heff_drop_cell(v_ru_24x2_246_24EGlobal, 1);
        v_t_2447 = NTAG(TAG_Nil);
      }
      break;
    }
    case TAG_ELam: {
      heff_take_n(v_x2_246, 0ULL, 2);
      heff_drop_cell(v_ru_24e_241_24EApp, 2);
      heff_drop(v_g_245);
      heff_drop(v_args_247);
      v_t_2447 = NTAG(TAG_Nil);
      break;
    }
    case TAG_EApp: {
      heff_take_n(v_x2_246, 0ULL, 2);
      heff_drop_cell(v_ru_24e_241_24EApp, 2);
      heff_drop(v_g_245);
      heff_drop(v_args_247);
      v_t_2447 = NTAG(TAG_Nil);
      break;
    }
    case TAG_ELet: {
      heff_take_n(v_x2_246, 0ULL, 3);
      heff_drop_cell(v_ru_24e_241_24EApp, 2);
      heff_drop(v_g_245);
      heff_drop(v_args_247);
      v_t_2447 = NTAG(TAG_Nil);
      break;
    }
    case TAG_ERecord: {
      heff_take_n(v_x2_246, 0ULL, 2);
      heff_drop_cell(v_ru_24e_241_24EApp, 2);
      heff_drop(v_g_245);
      heff_drop(v_args_247);
      v_t_2447 = NTAG(TAG_Nil);
      break;
    }
    case TAG_EProj: {
      heff_take_n(v_x2_246, 0ULL, 4);
      heff_drop_cell(v_ru_24e_241_24EApp, 2);
      heff_drop(v_g_245);
      heff_drop(v_args_247);
      v_t_2447 = NTAG(TAG_Nil);
      break;
    }
    case TAG_ETag: {
      heff_take_n(v_x2_246, 0ULL, 3);
      heff_drop_cell(v_ru_24e_241_24EApp, 2);
      heff_drop(v_g_245);
      heff_drop(v_args_247);
      v_t_2447 = NTAG(TAG_Nil);
      break;
    }
    case TAG_EMatch: {
      heff_take_n(v_x2_246, 0ULL, 2);
      heff_drop_cell(v_ru_24e_241_24EApp, 2);
      heff_drop(v_g_245);
      heff_drop(v_args_247);
      v_t_2447 = NTAG(TAG_Nil);
      break;
    }
    case TAG_EPrim: {
      heff_take_n(v_x2_246, 0ULL, 1);
      heff_drop_cell(v_ru_24e_241_24EApp, 2);
      heff_drop(v_g_245);
      heff_drop(v_args_247);
      v_t_2447 = NTAG(TAG_Nil);
      break;
    }
    case TAG_EPrimCall: {
      heff_take_n(v_x2_246, 0ULL, 2);
      heff_drop_cell(v_ru_24e_241_24EApp, 2);
      heff_drop(v_g_245);
      heff_drop(v_args_247);
      v_t_2447 = NTAG(TAG_Nil);
      break;
    }
    case TAG_ECall: {
      heff_take_n(v_x2_246, 0ULL, 2);
      heff_drop_cell(v_ru_24e_241_24EApp, 2);
      heff_drop(v_g_245);
      heff_drop(v_args_247);
      v_t_2447 = NTAG(TAG_Nil);
      break;
    }
    case TAG_EInt: {
      heff_take_n(v_x2_246, 0ULL, 1);
      heff_drop_cell(v_ru_24e_241_24EApp, 2);
      heff_drop(v_g_245);
      heff_drop(v_args_247);
      v_t_2447 = NTAG(TAG_Nil);
      break;
    }
    case TAG_EFloat: {
      heff_take_nf(v_x2_246, 0ULL, 1);
      heff_drop_cell(v_ru_24e_241_24EApp, 2);
      heff_drop(v_g_245);
      heff_drop(v_args_247);
      v_t_2447 = NTAG(TAG_Nil);
      break;
    }
    case TAG_EStr: {
      heff_take_n(v_x2_246, 0ULL, 1);
      heff_drop_cell(v_ru_24e_241_24EApp, 2);
      heff_drop(v_g_245);
      heff_drop(v_args_247);
      v_t_2447 = NTAG(TAG_Nil);
      break;
    }
    case TAG_EBytes: {
      heff_take_n(v_x2_246, 0ULL, 1);
      heff_drop_cell(v_ru_24e_241_24EApp, 2);
      heff_drop(v_g_245);
      heff_drop(v_args_247);
      v_t_2447 = NTAG(TAG_Nil);
      break;
    }
    case TAG_EFixed: {
      heff_take_n(v_x2_246, 0ULL, 2);
      heff_drop_cell(v_ru_24e_241_24EApp, 2);
      heff_drop(v_g_245);
      heff_drop(v_args_247);
      v_t_2447 = NTAG(TAG_Nil);
      break;
    }
    case TAG_EFloat32: {
      heff_take_na(v_x2_246, 0ULL, 1);
      heff_drop_cell(v_ru_24e_241_24EApp, 2);
      heff_drop(v_g_245);
      heff_drop(v_args_247);
      v_t_2447 = NTAG(TAG_Nil);
      break;
    }
    case TAG_EAbandon: {
      heff_drop_cell(v_ru_24e_241_24EApp, 2);
      heff_drop(v_g_245);
      heff_drop(v_args_247);
      v_t_2447 = NTAG(TAG_Nil);
      break;
    }
    case TAG_EBool: {
      heff_take_n(v_x2_246, 0ULL, 1);
      heff_drop_cell(v_ru_24e_241_24EApp, 2);
      heff_drop(v_g_245);
      heff_drop(v_args_247);
      v_t_2447 = NTAG(TAG_Nil);
      break;
    }
    case TAG_ESet: {
      heff_take_n(v_x2_246, 0ULL, 3);
      heff_drop_cell(v_ru_24e_241_24EApp, 2);
      heff_drop(v_g_245);
      heff_drop(v_args_247);
      v_t_2447 = NTAG(TAG_Nil);
      break;
    }
    case TAG_EValues: {
      heff_take_n(v_x2_246, 0ULL, 1);
      heff_drop_cell(v_ru_24e_241_24EApp, 2);
      heff_drop(v_g_245);
      heff_drop(v_args_247);
      v_t_2447 = NTAG(TAG_Nil);
      break;
    }
    case TAG_EFix: {
      heff_take_n(v_x2_246, 0ULL, 2);
      heff_drop_cell(v_ru_24e_241_24EApp, 2);
      heff_drop(v_g_245);
      heff_drop(v_args_247);
      v_t_2447 = NTAG(TAG_Nil);
      break;
    }
    default: heff_nomatch(v_x2_246);
    }
    V v_go_2448 = heff_tr(heff_call(((V)&g_heff_2ecompile_2espec_2eusesOf_clo), 1, (V[]){heff_dup(v_g_240)}));
    V v_f_2449 = v_f_243;
    V v_t_2489;
    switch (heff_tag_of(v_f_2449)) {
    case TAG_EVar: {
      v_t_2489 = heff_tr(heff_call(v_go_2448, 1, (V[]){v_f_2449}));
      break;
    }
    case TAG_EGlobal: {
      heff_take_n(v_f_2449, 0ULL, 1);
      heff_drop(v_go_2448);
      v_t_2489 = NTAG(TAG_Nil);
      break;
    }
    case TAG_ELam: {
      v_t_2489 = heff_tr(heff_call(v_go_2448, 1, (V[]){v_f_2449}));
      break;
    }
    case TAG_EApp: {
      v_t_2489 = heff_tr(heff_call(v_go_2448, 1, (V[]){v_f_2449}));
      break;
    }
    case TAG_ELet: {
      v_t_2489 = heff_tr(heff_call(v_go_2448, 1, (V[]){v_f_2449}));
      break;
    }
    case TAG_ERecord: {
      v_t_2489 = heff_tr(heff_call(v_go_2448, 1, (V[]){v_f_2449}));
      break;
    }
    case TAG_EProj: {
      v_t_2489 = heff_tr(heff_call(v_go_2448, 1, (V[]){v_f_2449}));
      break;
    }
    case TAG_ETag: {
      v_t_2489 = heff_tr(heff_call(v_go_2448, 1, (V[]){v_f_2449}));
      break;
    }
    case TAG_EMatch: {
      v_t_2489 = heff_tr(heff_call(v_go_2448, 1, (V[]){v_f_2449}));
      break;
    }
    case TAG_EPrim: {
      v_t_2489 = heff_tr(heff_call(v_go_2448, 1, (V[]){v_f_2449}));
      break;
    }
    case TAG_EPrimCall: {
      v_t_2489 = heff_tr(heff_call(v_go_2448, 1, (V[]){v_f_2449}));
      break;
    }
    case TAG_ECall: {
      v_t_2489 = heff_tr(heff_call(v_go_2448, 1, (V[]){v_f_2449}));
      break;
    }
    case TAG_EInt: {
      v_t_2489 = heff_tr(heff_call(v_go_2448, 1, (V[]){v_f_2449}));
      break;
    }
    case TAG_EFloat: {
      v_t_2489 = heff_tr(heff_call(v_go_2448, 1, (V[]){v_f_2449}));
      break;
    }
    case TAG_EStr: {
      v_t_2489 = heff_tr(heff_call(v_go_2448, 1, (V[]){v_f_2449}));
      break;
    }
    case TAG_EBytes: {
      v_t_2489 = heff_tr(heff_call(v_go_2448, 1, (V[]){v_f_2449}));
      break;
    }
    case TAG_EFixed: {
      v_t_2489 = heff_tr(heff_call(v_go_2448, 1, (V[]){v_f_2449}));
      break;
    }
    case TAG_EFloat32: {
      v_t_2489 = heff_tr(heff_call(v_go_2448, 1, (V[]){v_f_2449}));
      break;
    }
    case TAG_EAbandon: {
      v_t_2489 = heff_tr(heff_call(v_go_2448, 1, (V[]){v_f_2449}));
      break;
    }
    case TAG_EBool: {
      v_t_2489 = heff_tr(heff_call(v_go_2448, 1, (V[]){v_f_2449}));
      break;
    }
    case TAG_ESet: {
      v_t_2489 = heff_tr(heff_call(v_go_2448, 1, (V[]){v_f_2449}));
      break;
    }
    case TAG_EValues: {
      v_t_2489 = heff_tr(heff_call(v_go_2448, 1, (V[]){v_f_2449}));
      break;
    }
    case TAG_EFix: {
      v_t_2489 = heff_tr(heff_call(v_go_2448, 1, (V[]){v_f_2449}));
      break;
    }
    default: heff_nomatch(v_f_2449);
    }
    V v_f_2490 = heff_tr(heff_call(((V)&g_heff_2ecompile_2espec_2eusesOf_clo), 1, (V[]){v_g_240}));
    V v_t_2491 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_args_244));
    V v_t_2495 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2espec_2eusesOf_lam0, 2, 1, (V[]){v_f_2490}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_2491; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_2491); r_; });
    V v_t_2496 = (g_prelude_2e_2b_2b(v_t_2489, v_t_2495));
    HEFF_LAST return g_prelude_2e_2b_2b(v_t_2447, v_t_2496);
  }
  case TAG_ECall: {
    V v_h_2497 = heff_field(v_e_241, 0);
    V v_args_2498 = heff_field(v_e_241, 1);
    V v_ru_24e_241_24ECall = heff_take_reuse_n(v_e_241, 3ULL, 2);
    V v_t_2499;
    if (heff_strEq_c_lent(v_h_2497, v_g_240, 1)) {
      v_t_2499 = heff_tag_at_n(v_ru_24e_241_24ECall, TAG_Cons, 2, (V[]){heff_tag_n(TAG_Just, 1, (V[]){heff_dup(v_args_2498)}), NTAG(TAG_Nil)});
    } else {
      heff_drop_cell(v_ru_24e_241_24ECall, 2);
      v_t_2499 = NTAG(TAG_Nil);
    }
    V v_f_24100 = heff_tr(heff_call(((V)&g_heff_2ecompile_2espec_2eusesOf_clo), 1, (V[]){v_g_240}));
    V v_t_24101 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_args_2498));
    V v_t_24105 = ({ V a_0 = heff_clo_n(g_heff_2ecompile_2espec_2eusesOf_lam1, 2, 1, (V[]){v_f_24100}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_24101; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_24101); r_; });
    HEFF_LAST return g_prelude_2e_2b_2b(v_t_2499, v_t_24105);
  }
  default: {
    V v_f_24106 = heff_tr(heff_call(((V)&g_heff_2ecompile_2espec_2eusesOf_clo), 1, (V[]){v_g_240}));
    V v_xs_24107 = (g_heff_2ecompile_2eir_2epartsOnto(v_e_241, NTAG(TAG_Nil)));
    V v_t_24108 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_24107));
    return ({ V a_0 = heff_clo_n(g_heff_2ecompile_2espec_2eusesOf_lam2, 2, 1, (V[]){v_f_24106}); V a_1 = NTAG(TAG_Nil); V a_2 = v_t_24108; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_t_24108); r_; });
  }
  }
}
V g_heff_2ecompile_2espec_2eusesOf_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2espec_2eusesOf(a[0], a[1]);
}
V g_heff_2ecompile_2espec_2eusesOf_lam0(V self, V *args) {
  V v_acc_2492 = args[0];
  V v_x_2493 = args[1];
  V v_f_2490 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2494 = heff_tr(heff_call(v_f_2490, 1, (V[]){v_x_2493}));
  return (g_prelude_2e_2b_2b(v_t_2494, v_acc_2492));
}
V g_heff_2ecompile_2espec_2eusesOf_lam1(V self, V *args) {
  V v_acc_24102 = args[0];
  V v_x_24103 = args[1];
  V v_f_24100 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24104 = heff_tr(heff_call(v_f_24100, 1, (V[]){v_x_24103}));
  return (g_prelude_2e_2b_2b(v_t_24104, v_acc_24102));
}
V g_heff_2ecompile_2espec_2eusesOf_lam2(V self, V *args) {
  V v_acc_24109 = args[0];
  V v_x_24110 = args[1];
  V v_f_24106 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_24111 = heff_tr(heff_call(v_f_24106, 1, (V[]){v_x_24110}));
  return (g_prelude_2e_2b_2b(v_t_24111, v_acc_24109));
}

HeffT2 g_heff_2ecompile_2espec_2enthS_24cpr(V v_i_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_i_240);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_Cons: {
    V v_x_242 = heff_field(v_x2_241, 0);
    V v_xs_243 = heff_field(v_x2_241, 1);
    if (heff_intEq_c_lent(v_i_240, MK_INT(0LL), 2)) {
      heff_drop(v_i_240);
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), heff_dup(v_x_242)}});
    } else {
      V t_0 = heff_intSub(v_i_240, MK_INT(1LL));
      V t_1 = v_xs_243;
      v_i_240 = t_0;
      v_x2_241 = t_1;
      goto top;
    }
  }
  default: return ((HeffT2){{heff_nomatch(v_x2_241)}});
  }
}
V g_heff_2ecompile_2espec_2estaticGo_lam0(V self, V *args);
Clo g_heff_2ecompile_2espec_2estaticGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2espec_2estaticGo_entry, 3, 0};

V g_heff_2ecompile_2espec_2estaticGo(V v_uses_240, V v_x2_241, V v_i_242) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_i_242);
    return NTAG(TAG_Nil);
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x2_241, 0);
    V v_xs_244 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_2451 = (g_list_2eall(heff_clo_n(g_heff_2ecompile_2espec_2estaticGo_lam0, 1, 2, (V[]){v_x_243, heff_dup(v_i_242)}), v_uses_240));
    V v_cell_2452 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_2451, heff_hole()});
    V v_u_2453 = (g_heff_2ecompile_2espec_2estaticGo_24dps(v_uses_240, v_xs_244, heff_box_word((heff_unbox_word(v_i_242) + ((int64_t)1ULL))), heff_dup(v_cell_2452)));
    heff_drop(v_u_2453);
    return v_cell_2452;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2espec_2estaticGo_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2espec_2estaticGo(a0, a[1], a[2]); heff_drop(a0); return r;
}
V g_heff_2ecompile_2espec_2estaticGo_lam0(V self, V *args) {
  V v_x3_245 = args[0];
  V v_x_243 = heff_env(self)[0];
  V v_i_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_x3_245)) {
  case TAG_Nothing: {
    heff_drop(v_x_243);
    heff_drop(v_i_242);
    return NTAG(TAG_False);
  }
  case TAG_Just: {
    V v_args_246 = heff_field(v_x3_245, 0);
    heff_take_n(v_x3_245, 1ULL, 1);
    V v_x_247 = v_x_243;
    HeffT2 v_t_248 = ({ V a_0 = v_i_242; V a_1 = v_args_246; HeffT2 r_ = (g_heff_2ecompile_2espec_2enthS_24cpr(a_0, a_1)); heff_drop(v_args_246); r_; });
    {
      V v_field_2410 = v_t_248.f[1];
      int64_t v_tag_249 = ((int64_t)v_t_248.f[0]);
      if ((v_tag_249 == ((int64_t)0ULL))) {
        V v_x21_2411 = v_field_2410;
        switch (heff_tag_of(v_x21_2411)) {
        case TAG_EVar: {
          V v_y_2412 = heff_field(v_x21_2411, 0);
          heff_take_n(v_x21_2411, 1ULL, 1);
          V v_ret_24bool = heff_bool(heff_strEq_c_lent(v_x_247, v_y_2412, 0));
          heff_drop(v_x_247);
          heff_drop(v_y_2412);
          return v_ret_24bool;
        }
        case TAG_EGlobal: {
          heff_take_n(v_x21_2411, 0ULL, 1);
          heff_drop(v_x_247);
          return NTAG(TAG_False);
        }
        case TAG_ELam: {
          heff_take_n(v_x21_2411, 0ULL, 2);
          heff_drop(v_x_247);
          return NTAG(TAG_False);
        }
        case TAG_EApp: {
          heff_take_n(v_x21_2411, 0ULL, 2);
          heff_drop(v_x_247);
          return NTAG(TAG_False);
        }
        case TAG_ELet: {
          heff_take_n(v_x21_2411, 0ULL, 3);
          heff_drop(v_x_247);
          return NTAG(TAG_False);
        }
        case TAG_ERecord: {
          heff_take_n(v_x21_2411, 0ULL, 2);
          heff_drop(v_x_247);
          return NTAG(TAG_False);
        }
        case TAG_EProj: {
          heff_take_n(v_x21_2411, 0ULL, 4);
          heff_drop(v_x_247);
          return NTAG(TAG_False);
        }
        case TAG_ETag: {
          heff_take_n(v_x21_2411, 0ULL, 3);
          heff_drop(v_x_247);
          return NTAG(TAG_False);
        }
        case TAG_EMatch: {
          heff_take_n(v_x21_2411, 0ULL, 2);
          heff_drop(v_x_247);
          return NTAG(TAG_False);
        }
        case TAG_EPrim: {
          heff_take_n(v_x21_2411, 0ULL, 1);
          heff_drop(v_x_247);
          return NTAG(TAG_False);
        }
        case TAG_EPrimCall: {
          heff_take_n(v_x21_2411, 0ULL, 2);
          heff_drop(v_x_247);
          return NTAG(TAG_False);
        }
        case TAG_ECall: {
          heff_take_n(v_x21_2411, 0ULL, 2);
          heff_drop(v_x_247);
          return NTAG(TAG_False);
        }
        case TAG_EInt: {
          heff_take_n(v_x21_2411, 0ULL, 1);
          heff_drop(v_x_247);
          return NTAG(TAG_False);
        }
        case TAG_EFloat: {
          heff_take_nf(v_x21_2411, 0ULL, 1);
          heff_drop(v_x_247);
          return NTAG(TAG_False);
        }
        case TAG_EStr: {
          heff_take_n(v_x21_2411, 0ULL, 1);
          heff_drop(v_x_247);
          return NTAG(TAG_False);
        }
        case TAG_EBytes: {
          heff_take_n(v_x21_2411, 0ULL, 1);
          heff_drop(v_x_247);
          return NTAG(TAG_False);
        }
        case TAG_EFixed: {
          heff_take_n(v_x21_2411, 0ULL, 2);
          heff_drop(v_x_247);
          return NTAG(TAG_False);
        }
        case TAG_EFloat32: {
          heff_take_na(v_x21_2411, 0ULL, 1);
          heff_drop(v_x_247);
          return NTAG(TAG_False);
        }
        case TAG_EAbandon: {
          heff_drop(v_x_247);
          return NTAG(TAG_False);
        }
        case TAG_EBool: {
          heff_take_n(v_x21_2411, 0ULL, 1);
          heff_drop(v_x_247);
          return NTAG(TAG_False);
        }
        case TAG_ESet: {
          heff_take_n(v_x21_2411, 0ULL, 3);
          heff_drop(v_x_247);
          return NTAG(TAG_False);
        }
        case TAG_EValues: {
          heff_take_n(v_x21_2411, 0ULL, 1);
          heff_drop(v_x_247);
          return NTAG(TAG_False);
        }
        case TAG_EFix: {
          heff_take_n(v_x21_2411, 0ULL, 2);
          heff_drop(v_x_247);
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_x21_2411);
        }
      } else {
        heff_drop(v_x_247);
        heff_drop(v_field_2410);
        return NTAG(TAG_False);
      }
    }
  }
  default: return heff_nomatch(v_x3_245);
  }
}
V g_heff_2ecompile_2espec_2estaticGo_24dps_lam0(V self, V *args);
Clo g_heff_2ecompile_2espec_2estaticGo_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2espec_2estaticGo_24dps_entry, 4, 0};

V g_heff_2ecompile_2espec_2estaticGo_24dps(V v_uses_240, V v_x2_241, V v_i_242, V v_d_243) {
top: ;
  switch (heff_tag_of(v_x2_241)) {
  case TAG_Nil: {
    heff_drop(v_i_242);
    return heff_setField(v_d_243, MK_INT(1LL), NTAG(TAG_Nil));
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x2_241, 0);
    V v_xs_245 = heff_field(v_x2_241, 1);
    V v_ru_24x2_241_24Cons = heff_take_reuse_n(v_x2_241, 3ULL, 2);
    V v_t_2452 = (g_list_2eall(heff_clo_n(g_heff_2ecompile_2espec_2estaticGo_24dps_lam0, 1, 2, (V[]){v_x_244, heff_dup(v_i_242)}), v_uses_240));
    V v_cell_2453 = heff_tag_at_n(v_ru_24x2_241_24Cons, TAG_Cons, 2, (V[]){v_t_2452, heff_hole()});
    V v_u_2454 = heff_setField(v_d_243, MK_INT(1LL), heff_dup(v_cell_2453));
    heff_drop(v_u_2454);
    V t_0 = v_uses_240;
    V t_1 = v_xs_245;
    V t_2 = heff_intAdd(v_i_242, MK_INT(1LL));
    V t_3 = v_cell_2453;
    v_uses_240 = t_0;
    v_x2_241 = t_1;
    v_i_242 = t_2;
    v_d_243 = t_3;
    goto top;
  }
  default: return heff_nomatch(v_x2_241);
  }
}
V g_heff_2ecompile_2espec_2estaticGo_24dps_entry(V self, V *a) {
  (void)self;
  V a0 = a[0]; V r = g_heff_2ecompile_2espec_2estaticGo_24dps(a0, a[1], a[2], a[3]); heff_drop(a0); return r;
}
V g_heff_2ecompile_2espec_2estaticGo_24dps_lam0(V self, V *args) {
  V v_x3_246 = args[0];
  V v_x_244 = heff_env(self)[0];
  V v_i_242 = heff_env(self)[1];
  heff_clo_take(self, 2);
  switch (heff_tag_of(v_x3_246)) {
  case TAG_Nothing: {
    heff_drop(v_x_244);
    heff_drop(v_i_242);
    return NTAG(TAG_False);
  }
  case TAG_Just: {
    V v_args_247 = heff_field(v_x3_246, 0);
    heff_take_n(v_x3_246, 1ULL, 1);
    V v_x_248 = v_x_244;
    HeffT2 v_t_249 = ({ V a_0 = v_i_242; V a_1 = v_args_247; HeffT2 r_ = (g_heff_2ecompile_2espec_2enthS_24cpr(a_0, a_1)); heff_drop(v_args_247); r_; });
    {
      V v_field_2411 = v_t_249.f[1];
      int64_t v_tag_2410 = ((int64_t)v_t_249.f[0]);
      if ((v_tag_2410 == ((int64_t)0ULL))) {
        V v_x21_2412 = v_field_2411;
        switch (heff_tag_of(v_x21_2412)) {
        case TAG_EVar: {
          V v_y_2413 = heff_field(v_x21_2412, 0);
          heff_take_n(v_x21_2412, 1ULL, 1);
          V v_ret_24bool = heff_bool(heff_strEq_c_lent(v_x_248, v_y_2413, 0));
          heff_drop(v_x_248);
          heff_drop(v_y_2413);
          return v_ret_24bool;
        }
        case TAG_EGlobal: {
          heff_take_n(v_x21_2412, 0ULL, 1);
          heff_drop(v_x_248);
          return NTAG(TAG_False);
        }
        case TAG_ELam: {
          heff_take_n(v_x21_2412, 0ULL, 2);
          heff_drop(v_x_248);
          return NTAG(TAG_False);
        }
        case TAG_EApp: {
          heff_take_n(v_x21_2412, 0ULL, 2);
          heff_drop(v_x_248);
          return NTAG(TAG_False);
        }
        case TAG_ELet: {
          heff_take_n(v_x21_2412, 0ULL, 3);
          heff_drop(v_x_248);
          return NTAG(TAG_False);
        }
        case TAG_ERecord: {
          heff_take_n(v_x21_2412, 0ULL, 2);
          heff_drop(v_x_248);
          return NTAG(TAG_False);
        }
        case TAG_EProj: {
          heff_take_n(v_x21_2412, 0ULL, 4);
          heff_drop(v_x_248);
          return NTAG(TAG_False);
        }
        case TAG_ETag: {
          heff_take_n(v_x21_2412, 0ULL, 3);
          heff_drop(v_x_248);
          return NTAG(TAG_False);
        }
        case TAG_EMatch: {
          heff_take_n(v_x21_2412, 0ULL, 2);
          heff_drop(v_x_248);
          return NTAG(TAG_False);
        }
        case TAG_EPrim: {
          heff_take_n(v_x21_2412, 0ULL, 1);
          heff_drop(v_x_248);
          return NTAG(TAG_False);
        }
        case TAG_EPrimCall: {
          heff_take_n(v_x21_2412, 0ULL, 2);
          heff_drop(v_x_248);
          return NTAG(TAG_False);
        }
        case TAG_ECall: {
          heff_take_n(v_x21_2412, 0ULL, 2);
          heff_drop(v_x_248);
          return NTAG(TAG_False);
        }
        case TAG_EInt: {
          heff_take_n(v_x21_2412, 0ULL, 1);
          heff_drop(v_x_248);
          return NTAG(TAG_False);
        }
        case TAG_EFloat: {
          heff_take_nf(v_x21_2412, 0ULL, 1);
          heff_drop(v_x_248);
          return NTAG(TAG_False);
        }
        case TAG_EStr: {
          heff_take_n(v_x21_2412, 0ULL, 1);
          heff_drop(v_x_248);
          return NTAG(TAG_False);
        }
        case TAG_EBytes: {
          heff_take_n(v_x21_2412, 0ULL, 1);
          heff_drop(v_x_248);
          return NTAG(TAG_False);
        }
        case TAG_EFixed: {
          heff_take_n(v_x21_2412, 0ULL, 2);
          heff_drop(v_x_248);
          return NTAG(TAG_False);
        }
        case TAG_EFloat32: {
          heff_take_na(v_x21_2412, 0ULL, 1);
          heff_drop(v_x_248);
          return NTAG(TAG_False);
        }
        case TAG_EAbandon: {
          heff_drop(v_x_248);
          return NTAG(TAG_False);
        }
        case TAG_EBool: {
          heff_take_n(v_x21_2412, 0ULL, 1);
          heff_drop(v_x_248);
          return NTAG(TAG_False);
        }
        case TAG_ESet: {
          heff_take_n(v_x21_2412, 0ULL, 3);
          heff_drop(v_x_248);
          return NTAG(TAG_False);
        }
        case TAG_EValues: {
          heff_take_n(v_x21_2412, 0ULL, 1);
          heff_drop(v_x_248);
          return NTAG(TAG_False);
        }
        case TAG_EFix: {
          heff_take_n(v_x21_2412, 0ULL, 2);
          heff_drop(v_x_248);
          return NTAG(TAG_False);
        }
        default: return heff_nomatch(v_x21_2412);
        }
      } else {
        heff_drop(v_x_248);
        heff_drop(v_field_2411);
        return NTAG(TAG_False);
      }
    }
  }
  default: return heff_nomatch(v_x3_246);
  }
}
Clo g_heff_2ecompile_2espec_2edropAt_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2espec_2edropAt_entry, 2, 0};

V g_heff_2ecompile_2espec_2edropAt(V v_x1_240, V v_x2_241) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return v_x2_241;
  }
  case TAG_Cons: {
    V v_d_242 = heff_field(v_x1_240, 0);
    V v_ds_243 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      heff_drop(v_d_242);
      heff_drop(v_ds_243);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      return NTAG(TAG_Nil);
    }
    case TAG_Cons: {
      V v_a_244 = heff_field(v_x2_241, 0);
      V v_args_245 = heff_field(v_x2_241, 1);
      heff_take_n(v_x2_241, 3ULL, 2);
      if ((heff_dup(v_d_242) == NTAG(TAG_True))) {
        heff_drop(v_d_242);
        heff_drop_cell(v_ru_24x1_240_24Cons, 2);
        heff_drop(v_a_244);
        V t_0 = v_ds_243;
        V t_1 = v_args_245;
        v_x1_240 = t_0;
        v_x2_241 = t_1;
        goto top;
      } else {
        heff_drop(v_d_242);
        V v_cell_246 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_a_244, heff_hole()});
        V v_u_247 = (g_heff_2ecompile_2espec_2edropAt_24dps(v_ds_243, v_args_245, heff_dup(v_cell_246)));
        heff_drop(v_u_247);
        return v_cell_246;
      }
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2espec_2edropAt_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2espec_2edropAt(a[0], a[1]);
}
Clo g_heff_2ecompile_2espec_2edropAt_24dps_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2espec_2edropAt_24dps_entry, 3, 0};

V g_heff_2ecompile_2espec_2edropAt_24dps(V v_x1_240, V v_x2_241, V v_d_242) {
top: ;
  switch (heff_tag_of(v_x1_240)) {
  case TAG_Nil: {
    return heff_setField(v_d_242, MK_INT(1LL), v_x2_241);
  }
  case TAG_Cons: {
    V v_d_243 = heff_field(v_x1_240, 0);
    V v_ds_244 = heff_field(v_x1_240, 1);
    V v_ru_24x1_240_24Cons = heff_take_reuse_n(v_x1_240, 3ULL, 2);
    switch (heff_tag_of(v_x2_241)) {
    case TAG_Nil: {
      heff_drop(v_d_243);
      heff_drop(v_ds_244);
      heff_drop_cell(v_ru_24x1_240_24Cons, 2);
      return heff_setField(v_d_242, MK_INT(1LL), NTAG(TAG_Nil));
    }
    case TAG_Cons: {
      V v_a_245 = heff_field(v_x2_241, 0);
      V v_args_246 = heff_field(v_x2_241, 1);
      heff_take_n(v_x2_241, 3ULL, 2);
      if ((heff_dup(v_d_243) == NTAG(TAG_True))) {
        heff_drop(v_d_243);
        heff_drop_cell(v_ru_24x1_240_24Cons, 2);
        heff_drop(v_a_245);
        V t_0 = v_ds_244;
        V t_1 = v_args_246;
        V t_2 = v_d_242;
        v_x1_240 = t_0;
        v_x2_241 = t_1;
        v_d_242 = t_2;
        goto top;
      } else {
        heff_drop(v_d_243);
        V v_cell_247 = heff_tag_at_n(v_ru_24x1_240_24Cons, TAG_Cons, 2, (V[]){v_a_245, heff_hole()});
        V v_u_248 = heff_setField(v_d_242, MK_INT(1LL), heff_dup(v_cell_247));
        heff_drop(v_u_248);
        V t_0 = v_ds_244;
        V t_1 = v_args_246;
        V t_2 = v_cell_247;
        v_x1_240 = t_0;
        v_x2_241 = t_1;
        v_d_242 = t_2;
        goto top;
      }
    }
    default: return heff_nomatch(v_x2_241);
    }
  }
  default: return heff_nomatch(v_x1_240);
  }
}
V g_heff_2ecompile_2espec_2edropAt_24dps_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2espec_2edropAt_24dps(a[0], a[1], a[2]);
}
V g_heff_2ecompile_2espec_2eselfTo_lam0(V self, V *args);
Clo g_heff_2ecompile_2espec_2eselfTo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2ecompile_2espec_2eselfTo_entry, 5, 0};

V g_heff_2ecompile_2espec_2eselfTo(V v_g_240, V v_h_241, V v_pre_242, V v_ds_243, V v_e_244) {
top: ;
  switch (heff_tag_of(v_e_244)) {
  case TAG_EApp: {
    V v_f_245 = heff_field(v_e_244, 0);
    V v_args_246 = heff_field(v_e_244, 1);
    V v_ru_24e_244_24EApp = heff_take_reuse_n(v_e_244, 3ULL, 2);
    V v_go_247 = heff_tr(heff_call(((V)&g_heff_2ecompile_2espec_2eselfTo_clo), 4, (V[]){heff_dup(v_g_240), heff_dup(v_h_241), heff_dup(v_pre_242), heff_dup(v_ds_243)}));
    V v_g_248 = heff_dup(v_g_240);
    V v_h_249 = heff_dup(v_h_241);
    V v_f_2410 = heff_dup(v_f_245);
    V v_t_2451;
    switch (heff_tag_of(v_f_2410)) {
    case TAG_EVar: {
      heff_drop(v_g_248);
      heff_drop(v_h_249);
      v_t_2451 = heff_tr(heff_call(v_go_247, 1, (V[]){v_f_2410}));
      break;
    }
    case TAG_EGlobal: {
      V v_k_2412 = heff_field(v_f_2410, 0);
      V v_ru_24f_2410_24EGlobal = heff_take_reuse_n(v_f_2410, 1ULL, 1);
      heff_drop(v_go_247);
      V v_t_2413;
      if (heff_strEq_c_lent(v_k_2412, v_g_248, 2)) {
        heff_drop(v_k_2412);
        v_t_2413 = v_h_249;
      } else {
        heff_drop(v_h_249);
        v_t_2413 = v_k_2412;
      }
      v_t_2451 = heff_tag_at_n(v_ru_24f_2410_24EGlobal, TAG_EGlobal, 1, (V[]){v_t_2413});
      break;
    }
    case TAG_ELam: {
      heff_drop(v_g_248);
      heff_drop(v_h_249);
      v_t_2451 = heff_tr(heff_call(v_go_247, 1, (V[]){v_f_2410}));
      break;
    }
    case TAG_EApp: {
      heff_drop(v_g_248);
      heff_drop(v_h_249);
      v_t_2451 = heff_tr(heff_call(v_go_247, 1, (V[]){v_f_2410}));
      break;
    }
    case TAG_ELet: {
      heff_drop(v_g_248);
      heff_drop(v_h_249);
      v_t_2451 = heff_tr(heff_call(v_go_247, 1, (V[]){v_f_2410}));
      break;
    }
    case TAG_ERecord: {
      heff_drop(v_g_248);
      heff_drop(v_h_249);
      v_t_2451 = heff_tr(heff_call(v_go_247, 1, (V[]){v_f_2410}));
      break;
    }
    case TAG_EProj: {
      heff_drop(v_g_248);
      heff_drop(v_h_249);
      v_t_2451 = heff_tr(heff_call(v_go_247, 1, (V[]){v_f_2410}));
      break;
    }
    case TAG_ETag: {
      heff_drop(v_g_248);
      heff_drop(v_h_249);
      v_t_2451 = heff_tr(heff_call(v_go_247, 1, (V[]){v_f_2410}));
      break;
    }
    case TAG_EMatch: {
      heff_drop(v_g_248);
      heff_drop(v_h_249);
      v_t_2451 = heff_tr(heff_call(v_go_247, 1, (V[]){v_f_2410}));
      break;
    }
    case TAG_EPrim: {
      heff_drop(v_g_248);
      heff_drop(v_h_249);
      v_t_2451 = heff_tr(heff_call(v_go_247, 1, (V[]){v_f_2410}));
      break;
    }
    case TAG_EPrimCall: {
      heff_drop(v_g_248);
      heff_drop(v_h_249);
      v_t_2451 = heff_tr(heff_call(v_go_247, 1, (V[]){v_f_2410}));
      break;
    }
    case TAG_ECall: {
      heff_drop(v_g_248);
      heff_drop(v_h_249);
      v_t_2451 = heff_tr(heff_call(v_go_247, 1, (V[]){v_f_2410}));
      break;
    }
    case TAG_EInt: {
      heff_drop(v_g_248);
      heff_drop(v_h_249);
      v_t_2451 = heff_tr(heff_call(v_go_247, 1, (V[]){v_f_2410}));
      break;
    }
    case TAG_EFloat: {
      heff_drop(v_g_248);
      heff_drop(v_h_249);
      v_t_2451 = heff_tr(heff_call(v_go_247, 1, (V[]){v_f_2410}));
      break;
    }
    case TAG_EStr: {
      heff_drop(v_g_248);
      heff_drop(v_h_249);
      v_t_2451 = heff_tr(heff_call(v_go_247, 1, (V[]){v_f_2410}));
      break;
    }
    case TAG_EBytes: {
      heff_drop(v_g_248);
      heff_drop(v_h_249);
      v_t_2451 = heff_tr(heff_call(v_go_247, 1, (V[]){v_f_2410}));
      break;
    }
    case TAG_EFixed: {
      heff_drop(v_g_248);
      heff_drop(v_h_249);
      v_t_2451 = heff_tr(heff_call(v_go_247, 1, (V[]){v_f_2410}));
      break;
    }
    case TAG_EFloat32: {
      heff_drop(v_g_248);
      heff_drop(v_h_249);
      v_t_2451 = heff_tr(heff_call(v_go_247, 1, (V[]){v_f_2410}));
      break;
    }
    case TAG_EAbandon: {
      heff_drop(v_g_248);
      heff_drop(v_h_249);
      v_t_2451 = heff_tr(heff_call(v_go_247, 1, (V[]){v_f_2410}));
      break;
    }
    case TAG_EBool: {
      heff_drop(v_g_248);
      heff_drop(v_h_249);
      v_t_2451 = heff_tr(heff_call(v_go_247, 1, (V[]){v_f_2410}));
      break;
    }
    case TAG_ESet: {
      heff_drop(v_g_248);
      heff_drop(v_h_249);
      v_t_2451 = heff_tr(heff_call(v_go_247, 1, (V[]){v_f_2410}));
      break;
    }
    case TAG_EValues: {
      heff_drop(v_g_248);
      heff_drop(v_h_249);
      v_t_2451 = heff_tr(heff_call(v_go_247, 1, (V[]){v_f_2410}));
      break;
    }
    case TAG_EFix: {
      heff_drop(v_g_248);
      heff_drop(v_h_249);
      v_t_2451 = heff_tr(heff_call(v_go_247, 1, (V[]){v_f_2410}));
      break;
    }
    default: heff_nomatch(v_f_2410);
    }
    V v_t_2452 = heff_tr(heff_call(((V)&g_heff_2ecompile_2espec_2eselfTo_clo), 4, (V[]){heff_dup(v_g_240), v_h_241, heff_dup(v_pre_242), heff_dup(v_ds_243)}));
    V v_g_2453 = v_g_240;
    V v_pre_2454 = v_pre_242;
    V v_ds_2455 = v_ds_243;
    V v_f_2456 = v_f_245;
    V v_args_2457 = v_args_246;
    V v_t_2498;
    switch (heff_tag_of(v_f_2456)) {
    case TAG_EVar: {
      heff_take_n(v_f_2456, 0ULL, 1);
      heff_drop(v_g_2453);
      heff_drop(v_pre_2454);
      heff_drop(v_ds_2455);
      v_t_2498 = v_args_2457;
      break;
    }
    case TAG_EGlobal: {
      V v_k_2459 = heff_field(v_f_2456, 0);
      heff_take_n(v_f_2456, 1ULL, 1);
      if (heff_strEq_c(v_k_2459, v_g_2453)) {
        V v_t_2460 = (g_heff_2ecompile_2espec_2edropAt(v_ds_2455, v_args_2457));
        v_t_2498 = (g_prelude_2e_2b_2b(v_pre_2454, v_t_2460));
      } else {
        heff_drop(v_pre_2454);
        heff_drop(v_ds_2455);
        v_t_2498 = v_args_2457;
      }
      break;
    }
    case TAG_ELam: {
      heff_take_n(v_f_2456, 0ULL, 2);
      heff_drop(v_g_2453);
      heff_drop(v_pre_2454);
      heff_drop(v_ds_2455);
      v_t_2498 = v_args_2457;
      break;
    }
    case TAG_EApp: {
      heff_take_n(v_f_2456, 0ULL, 2);
      heff_drop(v_g_2453);
      heff_drop(v_pre_2454);
      heff_drop(v_ds_2455);
      v_t_2498 = v_args_2457;
      break;
    }
    case TAG_ELet: {
      heff_take_n(v_f_2456, 0ULL, 3);
      heff_drop(v_g_2453);
      heff_drop(v_pre_2454);
      heff_drop(v_ds_2455);
      v_t_2498 = v_args_2457;
      break;
    }
    case TAG_ERecord: {
      heff_take_n(v_f_2456, 0ULL, 2);
      heff_drop(v_g_2453);
      heff_drop(v_pre_2454);
      heff_drop(v_ds_2455);
      v_t_2498 = v_args_2457;
      break;
    }
    case TAG_EProj: {
      heff_take_n(v_f_2456, 0ULL, 4);
      heff_drop(v_g_2453);
      heff_drop(v_pre_2454);
      heff_drop(v_ds_2455);
      v_t_2498 = v_args_2457;
      break;
    }
    case TAG_ETag: {
      heff_take_n(v_f_2456, 0ULL, 3);
      heff_drop(v_g_2453);
      heff_drop(v_pre_2454);
      heff_drop(v_ds_2455);
      v_t_2498 = v_args_2457;
      break;
    }
    case TAG_EMatch: {
      heff_take_n(v_f_2456, 0ULL, 2);
      heff_drop(v_g_2453);
      heff_drop(v_pre_2454);
      heff_drop(v_ds_2455);
      v_t_2498 = v_args_2457;
      break;
    }
    case TAG_EPrim: {
      heff_take_n(v_f_2456, 0ULL, 1);
      heff_drop(v_g_2453);
      heff_drop(v_pre_2454);
      heff_drop(v_ds_2455);
      v_t_2498 = v_args_2457;
      break;
    }
    case TAG_EPrimCall: {
      heff_take_n(v_f_2456, 0ULL, 2);
      heff_drop(v_g_2453);
      heff_drop(v_pre_2454);
      heff_drop(v_ds_2455);
      v_t_2498 = v_args_2457;
      break;
    }
    case TAG_ECall: {
      heff_take_n(v_f_2456, 0ULL, 2);
      heff_drop(v_g_2453);
      heff_drop(v_pre_2454);
      heff_drop(v_ds_2455);
      v_t_2498 = v_args_2457;
      break;
    }
    case TAG_EInt: {
      heff_take_n(v_f_2456, 0ULL, 1);
      heff_drop(v_g_2453);
      heff_drop(v_pre_2454);
      heff_drop(v_ds_2455);
      v_t_2498 = v_args_2457;
      break;
    }
    case TAG_EFloat: {
      heff_take_nf(v_f_2456, 0ULL, 1);
      heff_drop(v_g_2453);
      heff_drop(v_pre_2454);
      heff_drop(v_ds_2455);
      v_t_2498 = v_args_2457;
      break;
    }
    case TAG_EStr: {
      heff_take_n(v_f_2456, 0ULL, 1);
      heff_drop(v_g_2453);
      heff_drop(v_pre_2454);
      heff_drop(v_ds_2455);
      v_t_2498 = v_args_2457;
      break;
    }
    case TAG_EBytes: {
      heff_take_n(v_f_2456, 0ULL, 1);
      heff_drop(v_g_2453);
      heff_drop(v_pre_2454);
      heff_drop(v_ds_2455);
      v_t_2498 = v_args_2457;
      break;
    }
    case TAG_EFixed: {
      heff_take_n(v_f_2456, 0ULL, 2);
      heff_drop(v_g_2453);
      heff_drop(v_pre_2454);
      heff_drop(v_ds_2455);
      v_t_2498 = v_args_2457;
      break;
    }
    case TAG_EFloat32: {
      heff_take_na(v_f_2456, 0ULL, 1);
      heff_drop(v_g_2453);
      heff_drop(v_pre_2454);
      heff_drop(v_ds_2455);
      v_t_2498 = v_args_2457;
      break;
    }
    case TAG_EAbandon: {
      heff_drop(v_g_2453);
      heff_drop(v_pre_2454);
      heff_drop(v_ds_2455);
      v_t_2498 = v_args_2457;
      break;
    }
    case TAG_EBool: {
      heff_take_n(v_f_2456, 0ULL, 1);
      heff_drop(v_g_2453);
      heff_drop(v_pre_2454);
      heff_drop(v_ds_2455);
      v_t_2498 = v_args_2457;
      break;
    }
    case TAG_ESet: {
      heff_take_n(v_f_2456, 0ULL, 3);
      heff_drop(v_g_2453);
      heff_drop(v_pre_2454);
      heff_drop(v_ds_2455);
      v_t_2498 = v_args_2457;
      break;
    }
    case TAG_EValues: {
      heff_take_n(v_f_2456, 0ULL, 1);
      heff_drop(v_g_2453);
      heff_drop(v_pre_2454);
      heff_drop(v_ds_2455);
      v_t_2498 = v_args_2457;
      break;
    }
    case TAG_EFix: {
      heff_take_n(v_f_2456, 0ULL, 2);
      heff_drop(v_g_2453);
      heff_drop(v_pre_2454);
      heff_drop(v_ds_2455);
      v_t_2498 = v_args_2457;
      break;
    }
    default: heff_nomatch(v_f_2456);
    }
    V v_t_2499 = (g_list_2emap(v_t_2452, v_t_2498));
    return heff_tag_at_n(v_ru_24e_244_24EApp, TAG_EApp, 2, (V[]){v_t_2451, v_t_2499});
  }
  default: {
    return (g_heff_2ecompile_2eir_2emapParts(heff_clo_n(g_heff_2ecompile_2espec_2eselfTo_lam0, 2, 4, (V[]){v_g_240, v_h_241, v_pre_242, v_ds_243}), v_e_244));
  }
  }
}
V g_heff_2ecompile_2espec_2eselfTo_entry(V self, V *a) {
  (void)self;
  return g_heff_2ecompile_2espec_2eselfTo(a[0], a[1], a[2], a[3], a[4]);
}
V g_heff_2ecompile_2espec_2eselfTo_lam0(V self, V *args) {
  V v_x_24100 = args[0];
  V v_p_24101 = args[1];
  V v_g_240 = heff_env(self)[0];
  V v_h_241 = heff_env(self)[1];
  V v_pre_242 = heff_env(self)[2];
  V v_ds_243 = heff_env(self)[3];
  heff_clo_take(self, 4);
  heff_drop(v_x_24100);
  return (g_heff_2ecompile_2espec_2eselfTo(v_g_240, v_h_241, v_pre_242, v_ds_243, v_p_24101));
}
V g_heff_2ecompile_2espec_2edictGo_24cpr_lam0(V self, V *args);

HeffT2 g_heff_2ecompile_2espec_2edictGo_24cpr(V v_ok_240, V v_m_241, V v_x3_242) {
top: ;
  switch (heff_tag_of(v_x3_242)) {
  case TAG_EVar: {
    heff_take_n(v_x3_242, 0ULL, 1);
    heff_drop(v_ok_240);
    heff_drop(v_m_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EGlobal: {
    heff_take_n(v_x3_242, 0ULL, 1);
    heff_drop(v_ok_240);
    heff_drop(v_m_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ELam: {
    heff_take_n(v_x3_242, 0ULL, 2);
    heff_drop(v_ok_240);
    heff_drop(v_m_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EApp: {
    heff_take_n(v_x3_242, 0ULL, 2);
    heff_drop(v_ok_240);
    heff_drop(v_m_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ELet: {
    V v_x_249 = heff_field(v_x3_242, 0);
    V v_a_2410 = heff_field(v_x3_242, 1);
    V v_b_2411 = heff_field(v_x3_242, 2);
    heff_take_n(v_x3_242, 7ULL, 3);
    V v_t_2412 = (g_std_2eordmap_2esize(v_m_241));
    V v_t_2413;
    if (heff_intEq_c(v_t_2412, MK_INT(0LL))) {
      v_t_2413 = heff_dup(v_a_2410);
    } else {
      v_t_2413 = (g_heff_2ecompile_2eir_2esubstGo(v_m_241, heff_dup(v_a_2410)));
    }
    V v_t_2414 = heff_tr(heff_call(heff_dup(v_ok_240), 1, (V[]){v_t_2413}));
    if ((heff_dup(v_t_2414) == NTAG(TAG_True))) {
      heff_drop(v_t_2414);
      V v_t_2415 = (g_std_2eordmap_2esize(v_m_241));
      V v_t_2416;
      if (heff_intEq_c(v_t_2415, MK_INT(0LL))) {
        v_t_2416 = v_a_2410;
      } else {
        v_t_2416 = (g_heff_2ecompile_2eir_2esubstGo(v_m_241, v_a_2410));
      }
      V v_t_2417 = (g_std_2eordmap_2einsert_24s615484302x989744458(v_m_241, v_x_249, v_t_2416));
      V t_0 = v_ok_240;
      V t_1 = v_t_2417;
      V t_2 = v_b_2411;
      v_ok_240 = t_0;
      v_m_241 = t_1;
      v_x3_242 = t_2;
      goto top;
    } else {
      heff_drop(v_ok_240);
      heff_drop(v_m_241);
      heff_drop(v_x_249);
      heff_drop(v_a_2410);
      heff_drop(v_b_2411);
      heff_drop(v_t_2414);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
  }
  case TAG_ERecord: {
    V v_fs_2418 = heff_field(v_x3_242, 0);
    V v_ts_2419 = heff_field(v_x3_242, 1);
    V v_ru_24x3_242_24ERecord = heff_take_reuse_n(v_x3_242, 3ULL, 2);
    heff_drop(v_ok_240);
    switch (heff_tag_of(v_fs_2418)) {
    case TAG_Nil: {
      heff_drop(v_m_241);
      heff_drop(v_ts_2419);
      heff_drop_cell(v_ru_24x3_242_24ERecord, 2);
      return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
    }
    case TAG_Cons: {
      V v_t_2422 = (g_std_2eordmap_2esize(v_m_241));
      V v_f_2428;
      if (heff_intEq_c(v_t_2422, MK_INT(0LL))) {
        heff_drop(v_m_241);
        v_f_2428 = heff_tag_at_n(v_ru_24x3_242_24ERecord, TAG_ERecord, 2, (V[]){v_fs_2418, v_ts_2419});
      } else {
        V v_t_2427 = (g_list_2emap(heff_clo_n(g_heff_2ecompile_2espec_2edictGo_24cpr_lam0, 1, 1, (V[]){v_m_241}), v_fs_2418));
        v_f_2428 = heff_tag_at_n(v_ru_24x3_242_24ERecord, TAG_ERecord, 2, (V[]){v_t_2427, v_ts_2419});
      }
      return ((HeffT2){{heff_word_i64(((int64_t)0ULL)), v_f_2428}});
    }
    default: return ((HeffT2){{heff_nomatch(v_fs_2418)}});
    }
  }
  case TAG_EProj: {
    heff_take_n(v_x3_242, 0ULL, 4);
    heff_drop(v_ok_240);
    heff_drop(v_m_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ETag: {
    heff_take_n(v_x3_242, 0ULL, 3);
    heff_drop(v_ok_240);
    heff_drop(v_m_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EMatch: {
    heff_take_n(v_x3_242, 0ULL, 2);
    heff_drop(v_ok_240);
    heff_drop(v_m_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EPrim: {
    heff_take_n(v_x3_242, 0ULL, 1);
    heff_drop(v_ok_240);
    heff_drop(v_m_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EPrimCall: {
    heff_take_n(v_x3_242, 0ULL, 2);
    heff_drop(v_ok_240);
    heff_drop(v_m_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ECall: {
    heff_take_n(v_x3_242, 0ULL, 2);
    heff_drop(v_ok_240);
    heff_drop(v_m_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EInt: {
    heff_take_n(v_x3_242, 0ULL, 1);
    heff_drop(v_ok_240);
    heff_drop(v_m_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EFloat: {
    heff_take_nf(v_x3_242, 0ULL, 1);
    heff_drop(v_ok_240);
    heff_drop(v_m_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EStr: {
    heff_take_n(v_x3_242, 0ULL, 1);
    heff_drop(v_ok_240);
    heff_drop(v_m_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EBytes: {
    heff_take_n(v_x3_242, 0ULL, 1);
    heff_drop(v_ok_240);
    heff_drop(v_m_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EFixed: {
    heff_take_n(v_x3_242, 0ULL, 2);
    heff_drop(v_ok_240);
    heff_drop(v_m_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EFloat32: {
    heff_take_na(v_x3_242, 0ULL, 1);
    heff_drop(v_ok_240);
    heff_drop(v_m_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EAbandon: {
    heff_drop(v_ok_240);
    heff_drop(v_m_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EBool: {
    heff_take_n(v_x3_242, 0ULL, 1);
    heff_drop(v_ok_240);
    heff_drop(v_m_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_ESet: {
    heff_take_n(v_x3_242, 0ULL, 3);
    heff_drop(v_ok_240);
    heff_drop(v_m_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EValues: {
    heff_take_n(v_x3_242, 0ULL, 1);
    heff_drop(v_ok_240);
    heff_drop(v_m_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  case TAG_EFix: {
    heff_take_n(v_x3_242, 0ULL, 2);
    heff_drop(v_ok_240);
    heff_drop(v_m_241);
    return ((HeffT2){{heff_word_i64(((int64_t)1ULL)), MK_INT(0LL)}});
  }
  default: return ((HeffT2){{heff_nomatch(v_x3_242)}});
  }
}
V g_heff_2ecompile_2espec_2edictGo_24cpr_lam0(V self, V *args) {
  V v_p_2423 = args[0];
  V v_m_241 = heff_env(self)[0];
  heff_clo_take(self, 1);
  switch (heff_tag_of(v_p_2423)) {
  case TAG_MkPair: {
    V v_l_2424 = heff_field(v_p_2423, 0);
    V v_e2_2425 = heff_field(v_p_2423, 1);
    V v_ru_24p_2423_24MkPair = heff_take_reuse_n(v_p_2423, 3ULL, 2);
    V v_t_2426 = ({ V a_0 = v_m_241; V a_1 = v_e2_2425; V r_ = (g_heff_2ecompile_2eir_2esubstGo(a_0, a_1)); heff_drop(v_m_241); r_; });
    return heff_tag_at_n(v_ru_24p_2423_24MkPair, TAG_MkPair, 2, (V[]){v_l_2424, v_t_2426});
  }
  default: return heff_nomatch(v_p_2423);
  }
}