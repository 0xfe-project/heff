// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
#define TAG_EAbandon 62759
#define TAG_EApp 33163
#define TAG_ECall 24489
#define TAG_EFix 37759
#define TAG_EFixed 44184
#define TAG_EFloat 59274
#define TAG_EFloat32 12283
#define TAG_EGlobal 62762
#define TAG_EInt 40793
#define TAG_ELam 43266
#define TAG_ELet 43397
#define TAG_EMatch 41631
#define TAG_EPrim 34861
#define TAG_EPrimCall 6589
#define TAG_EProj 35044
#define TAG_ERecord 5518
#define TAG_EStr 50587
#define TAG_ETag 50948
#define TAG_EVar 52881
#define TAG_MkArm 55352
#define LBL_body 9524841
#define LBL_key 315609
#define LBL_n 328
#define LBL_name 9869138
#define LBL_out 319944
static uint32_t shape_key__name__body[] = {LBL_key, LBL_name, LBL_body};
static uint32_t shape_out__n[] = {LBL_out, LBL_n};
static V prim_strEq_entry(V self, V *a) { (void)self; return heff_strEq(a[0], a[1]); }
static Clo prim_strEq_clo = {{0x80000000u, K_CLO, 0}, prim_strEq_entry, 2, 0};
V g_heff_2eir_2eappendI(V, V);
V g_heff_2eir_2eappendI_entry(V self, V *a);
extern Clo g_heff_2eir_2eappendI_clo;
V g_heff_2eir_2ebaseGo(V, V);
V g_heff_2eir_2ebaseGo_entry(V self, V *a);
extern Clo g_heff_2eir_2ebaseGo_clo;
V g_heff_2elift_2efreeGo(V, V, V);
V g_heff_2elift_2efreeGo_entry(V self, V *a);
extern Clo g_heff_2elift_2efreeGo_clo;
V g_heff_2elift_2eliftApp_24s2432925x2084037232(V, V, V, V);
V g_heff_2elift_2eliftApp_24s2432925x2084037232_entry(V self, V *a);
extern Clo g_heff_2elift_2eliftApp_24s2432925x2084037232_clo;
V g_heff_2elift_2eliftFix_24s1233964062x730417183(V, V, V, V);
V g_heff_2elift_2eliftFix_24s1233964062x730417183_entry(V self, V *a);
extern Clo g_heff_2elift_2eliftFix_24s1233964062x730417183_clo;
V g_heff_2elift_2eliftFixDef_24s621078245x1616660209(V, V, V);
V g_heff_2elift_2eliftFixDef_24s621078245x1616660209_entry(V self, V *a);
extern Clo g_heff_2elift_2eliftFixDef_24s621078245x1616660209_clo;
V g_heff_2elift_2eliftGo_24s104003089x2047780485(V, V, V);
V g_heff_2elift_2eliftGo_24s104003089x2047780485_entry(V self, V *a);
extern Clo g_heff_2elift_2eliftGo_24s104003089x2047780485_clo;
V g_heff_2elift_2eliftGo_24s1262932354x2044031683(V, V, V);
V g_heff_2elift_2eliftGo_24s1262932354x2044031683_entry(V self, V *a);
extern Clo g_heff_2elift_2eliftGo_24s1262932354x2044031683_clo;
V g_heff_2elift_2eliftMany_24s2129644851x1119046535(V, V, V);
V g_heff_2elift_2eliftMany_24s2129644851x1119046535_entry(V self, V *a);
extern Clo g_heff_2elift_2eliftMany_24s2129644851x1119046535_clo;
V g_heff_2elift_2eliftRedex_24s2095000274x602849629(V, V, V, V, V);
V g_heff_2elift_2eliftRedex_24s2095000274x602849629_entry(V self, V *a);
extern Clo g_heff_2elift_2eliftRedex_24s2095000274x602849629_clo;
V g_heff_2elift_2eliftedDef(V, V, V, V, V);
V g_heff_2elift_2eliftedDef_entry(V self, V *a);
extern Clo g_heff_2elift_2eliftedDef_clo;
V g_heff_2elift_2eoneParam(V);
V g_heff_2elift_2eoneParam_entry(V self, V *a);
extern Clo g_heff_2elift_2eoneParam_clo;
V g_heff_2elift_2ereplaceGo(V, V, V);
V g_heff_2elift_2ereplaceGo_entry(V self, V *a);
extern Clo g_heff_2elift_2ereplaceGo_clo;
V g_heff_2elift_2ewithParams(V, V);
V g_heff_2elift_2ewithParams_entry(V self, V *a);
extern Clo g_heff_2elift_2ewithParams_clo;
V g_list_2eany(V, V);
V g_list_2eany_entry(V self, V *a);
extern Clo g_list_2eany_clo;
V g_list_2efoldl(V, V, V);
V g_list_2efoldl_entry(V self, V *a);
extern Clo g_list_2efoldl_clo;
V g_list_2efoldl_24s1370882877x364361272(V, V);
V g_list_2efoldl_24s1370882877x364361272_entry(V self, V *a);
extern Clo g_list_2efoldl_24s1370882877x364361272_clo;
V g_list_2emap(V, V);
V g_list_2emap_entry(V self, V *a);
extern Clo g_list_2emap_clo;
V g_list_2emap_24s1173914895x100384474(V);
V g_list_2emap_24s1173914895x100384474_entry(V self, V *a);
extern Clo g_list_2emap_24s1173914895x100384474_clo;
V g_list_2emap_24s1809017761x1063871171(V);
V g_list_2emap_24s1809017761x1063871171_entry(V self, V *a);
extern Clo g_list_2emap_24s1809017761x1063871171_clo;
V g_list_2emap_24s2006210321x387008715(V);
V g_list_2emap_24s2006210321x387008715_entry(V self, V *a);
extern Clo g_list_2emap_24s2006210321x387008715_clo;
V g_list_2ezipWith_24s1029292936x211450510(V, V);
V g_list_2ezipWith_24s1029292936x211450510_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s1029292936x211450510_clo;
V g_list_2ezipWith_24s738847920x410598254(V, V);
V g_list_2ezipWith_24s738847920x410598254_entry(V self, V *a);
extern Clo g_list_2ezipWith_24s738847920x410598254_clo;
V g_heff_2elift_2efreeGo_lam0(V self, V *args);
V g_heff_2elift_2efreeGo_lam1(V self, V *args);
V g_heff_2elift_2efreeGo_lam2(V self, V *args);
V g_heff_2elift_2efreeGo_lam3(V self, V *args);
V g_heff_2elift_2efreeGo_lam4(V self, V *args);
V g_heff_2elift_2efreeGo_lam5(V self, V *args);
Clo g_heff_2elift_2efreeGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elift_2efreeGo_entry, 3, 0};

V g_heff_2elift_2efreeGo(V v_bound_240, V v_e_241, V v_acc_242) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_EVar: {
    V v_x_243 = heff_field(v_e_241, 0);
    heff_take_n(v_e_241, 1ULL, 1);
    V v_t_244 = heff_tr(heff_apply(((V)&prim_strEq_clo), 1, (V[]){heff_dup(v_x_243)}));
    V v_t_245 = ({ V a_0 = v_t_244; V a_1 = v_bound_240; V r_ = (g_list_2eany(a_0, a_1)); heff_drop(v_bound_240); r_; });
    switch (heff_tag_of(v_t_245)) {
    case TAG_True: {
      heff_drop(v_x_243);
      return v_acc_242;
    }
    case TAG_False: {
      V v_t_246 = heff_tr(heff_apply(((V)&prim_strEq_clo), 1, (V[]){heff_dup(v_x_243)}));
      V v_t_247 = (g_list_2eany(v_t_246, v_acc_242));
      switch (heff_tag_of(v_t_247)) {
      case TAG_True: {
        heff_drop(v_x_243);
        return v_acc_242;
      }
      case TAG_False: {
        return heff_tag(TAG_Cons, 2, (V[]){v_x_243, v_acc_242});
      }
      default: return heff_nomatch(v_t_247);
      }
    }
    default: return heff_nomatch(v_t_245);
    }
  }
  case TAG_EGlobal: {
    heff_take_n(v_e_241, 0ULL, 1);
    heff_drop(v_bound_240);
    return v_acc_242;
  }
  case TAG_ELam: {
    V v_xs_249 = heff_field(v_e_241, 0);
    V v_b_2410 = heff_field(v_e_241, 1);
    heff_take_n(v_e_241, 3ULL, 2);
    V v_t_2411 = (g_heff_2eir_2eappendI(v_xs_249, v_bound_240));
    V t_0 = v_t_2411;
    V t_1 = v_b_2410;
    V t_2 = v_acc_242;
    v_bound_240 = t_0;
    v_e_241 = t_1;
    v_acc_242 = t_2;
    goto top;
  }
  case TAG_EApp: {
    V v_f_2412 = heff_field(v_e_241, 0);
    V v_as_2413 = heff_field(v_e_241, 1);
    heff_take_n(v_e_241, 3ULL, 2);
    V v_t_2414 = (g_heff_2elift_2efreeGo(heff_dup(v_bound_240), v_f_2412, v_acc_242));
    return ({ V a_0 = heff_clo(g_heff_2elift_2efreeGo_lam0, 2, 1, (V[]){v_bound_240}); V a_1 = v_t_2414; V a_2 = v_as_2413; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_as_2413); r_; });
  }
  case TAG_ELet: {
    V v_x_2417 = heff_field(v_e_241, 0);
    V v_a_2418 = heff_field(v_e_241, 1);
    V v_b_2419 = heff_field(v_e_241, 2);
    heff_take_n(v_e_241, 7ULL, 3);
    V v_t_2420 = (g_heff_2elift_2efreeGo(heff_dup(v_bound_240), v_a_2418, v_acc_242));
    V t_0 = heff_tag(TAG_Cons, 2, (V[]){v_x_2417, v_bound_240});
    V t_1 = v_b_2419;
    V t_2 = v_t_2420;
    v_bound_240 = t_0;
    v_e_241 = t_1;
    v_acc_242 = t_2;
    goto top;
  }
  case TAG_ERecord: {
    V v_fs_2421 = heff_field(v_e_241, 0);
    heff_take_n(v_e_241, 1ULL, 1);
    return ({ V a_0 = heff_clo(g_heff_2elift_2efreeGo_lam1, 2, 1, (V[]){v_bound_240}); V a_1 = v_acc_242; V a_2 = v_fs_2421; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_fs_2421); r_; });
  }
  case TAG_EProj: {
    V v_x_2427 = heff_field(v_e_241, 0);
    heff_take_n(v_e_241, 1ULL, 2);
    V t_0 = v_bound_240;
    V t_1 = v_x_2427;
    V t_2 = v_acc_242;
    v_bound_240 = t_0;
    v_e_241 = t_1;
    v_acc_242 = t_2;
    goto top;
  }
  case TAG_ETag: {
    V v_es_2430 = heff_field(v_e_241, 1);
    heff_take_n(v_e_241, 2ULL, 2);
    return ({ V a_0 = heff_clo(g_heff_2elift_2efreeGo_lam2, 2, 1, (V[]){v_bound_240}); V a_1 = v_acc_242; V a_2 = v_es_2430; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_es_2430); r_; });
  }
  case TAG_EMatch: {
    V v_x_2433 = heff_field(v_e_241, 0);
    V v_arms_2434 = heff_field(v_e_241, 1);
    heff_take_n(v_e_241, 3ULL, 2);
    V v_t_2435 = (g_heff_2elift_2efreeGo(heff_dup(v_bound_240), v_x_2433, v_acc_242));
    return ({ V a_0 = heff_clo(g_heff_2elift_2efreeGo_lam3, 2, 1, (V[]){v_bound_240}); V a_1 = v_t_2435; V a_2 = v_arms_2434; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_arms_2434); r_; });
  }
  case TAG_EPrim: {
    heff_take_n(v_e_241, 0ULL, 1);
    heff_drop(v_bound_240);
    return v_acc_242;
  }
  case TAG_EPrimCall: {
    V v_es_2449 = heff_field(v_e_241, 1);
    heff_take_n(v_e_241, 2ULL, 2);
    return ({ V a_0 = heff_clo(g_heff_2elift_2efreeGo_lam4, 2, 1, (V[]){v_bound_240}); V a_1 = v_acc_242; V a_2 = v_es_2449; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_es_2449); r_; });
  }
  case TAG_ECall: {
    V v_es_2453 = heff_field(v_e_241, 1);
    heff_take_n(v_e_241, 2ULL, 2);
    return ({ V a_0 = heff_clo(g_heff_2elift_2efreeGo_lam5, 2, 1, (V[]){v_bound_240}); V a_1 = v_acc_242; V a_2 = v_es_2453; V r_ = (g_list_2efoldl(a_0, a_1, a_2)); heff_drop(v_es_2453); r_; });
  }
  case TAG_EInt: {
    heff_take_n(v_e_241, 0ULL, 1);
    heff_drop(v_bound_240);
    return v_acc_242;
  }
  case TAG_EFloat: {
    heff_take_n(v_e_241, 0ULL, 1);
    heff_drop(v_bound_240);
    return v_acc_242;
  }
  case TAG_EStr: {
    heff_take_n(v_e_241, 0ULL, 1);
    heff_drop(v_bound_240);
    return v_acc_242;
  }
  case TAG_EFixed: {
    heff_take_n(v_e_241, 0ULL, 2);
    heff_drop(v_bound_240);
    return v_acc_242;
  }
  case TAG_EFloat32: {
    heff_take_n(v_e_241, 0ULL, 1);
    heff_drop(v_bound_240);
    return v_acc_242;
  }
  case TAG_EAbandon: {
    heff_drop(v_bound_240);
    return v_acc_242;
  }
  case TAG_EFix: {
    V v_f_2462 = heff_field(v_e_241, 0);
    V v_b_2463 = heff_field(v_e_241, 1);
    V v_ru_24e_241_24EFix = heff_take_reuse_n(v_e_241, 3ULL, 2);
    V t_0 = heff_tag_at(v_ru_24e_241_24EFix, TAG_Cons, 2, (V[]){v_f_2462, v_bound_240});
    V t_1 = v_b_2463;
    V t_2 = v_acc_242;
    v_bound_240 = t_0;
    v_e_241 = t_1;
    v_acc_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_e_241);
  }
}
V g_heff_2elift_2efreeGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2elift_2efreeGo(a[0], a[1], a[2]);
}
V g_heff_2elift_2efreeGo_lam0(V self, V *args) {
  V v_a_2415 = args[0];
  V v_x_2416 = args[1];
  V v_bound_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2elift_2efreeGo(v_bound_240, v_x_2416, v_a_2415));
}
V g_heff_2elift_2efreeGo_lam1(V self, V *args) {
  V v_a_2422 = args[0];
  V v_f_2423 = args[1];
  V v_bound_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2426;
  switch (heff_tag_of(v_f_2423)) {
  case TAG_MkPair: {
    V v_y_2425 = heff_field(v_f_2423, 1);
    heff_take_n(v_f_2423, 2ULL, 2);
    v_t_2426 = v_y_2425;
    break;
  }
  default: heff_nomatch(v_f_2423);
  }
  return (g_heff_2elift_2efreeGo(v_bound_240, v_t_2426, v_a_2422));
}
V g_heff_2elift_2efreeGo_lam2(V self, V *args) {
  V v_a_2431 = args[0];
  V v_x_2432 = args[1];
  V v_bound_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2elift_2efreeGo(v_bound_240, v_x_2432, v_a_2431));
}
V g_heff_2elift_2efreeGo_lam3(V self, V *args) {
  V v_a_2436 = args[0];
  V v_arm_2437 = args[1];
  V v_bound_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  V v_t_2441;
  switch (heff_tag_of(v_arm_2437)) {
  case TAG_MkArm: {
    V v_vs_2439 = heff_dup(heff_field(v_arm_2437, 1));
    v_t_2441 = v_vs_2439;
    break;
  }
  default: heff_nomatch(v_arm_2437);
  }
  V v_t_2442 = (g_heff_2eir_2eappendI(v_t_2441, v_bound_240));
  V v_t_2446;
  switch (heff_tag_of(v_arm_2437)) {
  case TAG_MkArm: {
    V v_b_2445 = heff_field(v_arm_2437, 2);
    heff_take_n(v_arm_2437, 4ULL, 3);
    v_t_2446 = v_b_2445;
    break;
  }
  default: heff_nomatch(v_arm_2437);
  }
  return (g_heff_2elift_2efreeGo(v_t_2442, v_t_2446, v_a_2436));
}
V g_heff_2elift_2efreeGo_lam4(V self, V *args) {
  V v_a_2450 = args[0];
  V v_x_2451 = args[1];
  V v_bound_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2elift_2efreeGo(v_bound_240, v_x_2451, v_a_2450));
}
V g_heff_2elift_2efreeGo_lam5(V self, V *args) {
  V v_a_2454 = args[0];
  V v_x_2455 = args[1];
  V v_bound_240 = heff_env(self)[0];
  heff_clo_take(self, 1);
  return (g_heff_2elift_2efreeGo(v_bound_240, v_x_2455, v_a_2454));
}
V g_heff_2elift_2ereplaceGo_lam0(V self, V *args);
V g_heff_2elift_2ereplaceGo_lam1(V self, V *args);
Clo g_heff_2elift_2ereplaceGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elift_2ereplaceGo_entry, 3, 0};

V g_heff_2elift_2ereplaceGo(V v_x_240, V v_r_241, V v_e_242) {
top: ;
  switch (heff_tag_of(v_e_242)) {
  case TAG_EVar: {
    V v_y_243 = heff_dup(heff_field(v_e_242, 0));
    if (heff_strEq_c(v_y_243, v_x_240)) {
      heff_drop_tag(v_e_242, 1);
      return v_r_241;
    } else {
      heff_drop(v_r_241);
      return v_e_242;
    }
  }
  case TAG_EGlobal: {
    heff_drop(v_x_240);
    heff_drop(v_r_241);
    return v_e_242;
  }
  case TAG_ELam: {
    V v_xs_246 = heff_field(v_e_242, 0);
    V v_b_247 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24ELam = heff_take_reuse_n(v_e_242, 3ULL, 2);
    return heff_tag_at(v_ru_24e_242_24ELam, TAG_ELam, 2, (V[]){v_xs_246, (g_heff_2elift_2ereplaceGo(v_x_240, v_r_241, v_b_247))});
  }
  case TAG_EApp: {
    V v_f_248 = heff_field(v_e_242, 0);
    V v_as_249 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24EApp = heff_take_reuse_n(v_e_242, 3ULL, 2);
    V v_t_2410 = (g_heff_2elift_2ereplaceGo(heff_dup(v_x_240), heff_dup(v_r_241), v_f_248));
    V v_t_2411 = heff_tr(heff_apply(((V)&g_heff_2elift_2ereplaceGo_clo), 2, (V[]){v_x_240, v_r_241}));
    return heff_tag_at(v_ru_24e_242_24EApp, TAG_EApp, 2, (V[]){v_t_2410, (g_list_2emap(v_t_2411, v_as_249))});
  }
  case TAG_ELet: {
    V v_y_2412 = heff_field(v_e_242, 0);
    V v_a_2413 = heff_field(v_e_242, 1);
    V v_b_2414 = heff_field(v_e_242, 2);
    V v_ru_24e_242_24ELet = heff_take_reuse_n(v_e_242, 7ULL, 3);
    V v_t_2415 = (g_heff_2elift_2ereplaceGo(heff_dup(v_x_240), heff_dup(v_r_241), v_a_2413));
    return heff_tag_at(v_ru_24e_242_24ELet, TAG_ELet, 3, (V[]){v_y_2412, v_t_2415, (g_heff_2elift_2ereplaceGo(v_x_240, v_r_241, v_b_2414))});
  }
  case TAG_ERecord: {
    V v_fs_2416 = heff_field(v_e_242, 0);
    V v_ru_24e_242_24ERecord = heff_take_reuse_n(v_e_242, 1ULL, 1);
    return heff_tag_at(v_ru_24e_242_24ERecord, TAG_ERecord, 1, (V[]){(g_list_2emap(heff_clo(g_heff_2elift_2ereplaceGo_lam0, 1, 2, (V[]){v_x_240, v_r_241}), v_fs_2416))});
  }
  case TAG_EProj: {
    V v_y_2424 = heff_field(v_e_242, 0);
    V v_l_2425 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24EProj = heff_take_reuse_n(v_e_242, 3ULL, 2);
    V v_t_2426 = (g_heff_2elift_2ereplaceGo(v_x_240, v_r_241, v_y_2424));
    return heff_tag_at(v_ru_24e_242_24EProj, TAG_EProj, 2, (V[]){v_t_2426, v_l_2425});
  }
  case TAG_ETag: {
    V v_t_2427 = heff_field(v_e_242, 0);
    V v_es_2428 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24ETag = heff_take_reuse_n(v_e_242, 3ULL, 2);
    V v_t_2429 = heff_tr(heff_apply(((V)&g_heff_2elift_2ereplaceGo_clo), 2, (V[]){v_x_240, v_r_241}));
    return heff_tag_at(v_ru_24e_242_24ETag, TAG_ETag, 2, (V[]){v_t_2427, (g_list_2emap(v_t_2429, v_es_2428))});
  }
  case TAG_EMatch: {
    V v_y_2430 = heff_field(v_e_242, 0);
    V v_arms_2431 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24EMatch = heff_take_reuse_n(v_e_242, 3ULL, 2);
    V v_t_2432 = (g_heff_2elift_2ereplaceGo(heff_dup(v_x_240), heff_dup(v_r_241), v_y_2430));
    return heff_tag_at(v_ru_24e_242_24EMatch, TAG_EMatch, 2, (V[]){v_t_2432, (g_list_2emap(heff_clo(g_heff_2elift_2ereplaceGo_lam1, 1, 2, (V[]){v_x_240, v_r_241}), v_arms_2431))});
  }
  case TAG_EPrim: {
    heff_drop(v_x_240);
    heff_drop(v_r_241);
    return v_e_242;
  }
  case TAG_EPrimCall: {
    V v_p_2447 = heff_field(v_e_242, 0);
    V v_es_2448 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24EPrimCall = heff_take_reuse_n(v_e_242, 3ULL, 2);
    V v_t_2449 = heff_tr(heff_apply(((V)&g_heff_2elift_2ereplaceGo_clo), 2, (V[]){v_x_240, v_r_241}));
    return heff_tag_at(v_ru_24e_242_24EPrimCall, TAG_EPrimCall, 2, (V[]){v_p_2447, (g_list_2emap(v_t_2449, v_es_2448))});
  }
  case TAG_ECall: {
    V v_k_2450 = heff_field(v_e_242, 0);
    V v_es_2451 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24ECall = heff_take_reuse_n(v_e_242, 3ULL, 2);
    V v_t_2452 = heff_tr(heff_apply(((V)&g_heff_2elift_2ereplaceGo_clo), 2, (V[]){v_x_240, v_r_241}));
    return heff_tag_at(v_ru_24e_242_24ECall, TAG_ECall, 2, (V[]){v_k_2450, (g_list_2emap(v_t_2452, v_es_2451))});
  }
  case TAG_EInt: {
    heff_drop(v_x_240);
    heff_drop(v_r_241);
    return v_e_242;
  }
  case TAG_EFloat: {
    heff_drop(v_x_240);
    heff_drop(v_r_241);
    return v_e_242;
  }
  case TAG_EStr: {
    heff_drop(v_x_240);
    heff_drop(v_r_241);
    return v_e_242;
  }
  case TAG_EFixed: {
    heff_drop(v_x_240);
    heff_drop(v_r_241);
    return v_e_242;
  }
  case TAG_EFloat32: {
    heff_drop(v_x_240);
    heff_drop(v_r_241);
    return v_e_242;
  }
  case TAG_EAbandon: {
    heff_drop(v_x_240);
    heff_drop(v_r_241);
    return v_e_242;
  }
  case TAG_EFix: {
    V v_f_2459 = heff_field(v_e_242, 0);
    V v_b_2460 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24EFix = heff_take_reuse_n(v_e_242, 3ULL, 2);
    return heff_tag_at(v_ru_24e_242_24EFix, TAG_EFix, 2, (V[]){v_f_2459, (g_heff_2elift_2ereplaceGo(v_x_240, v_r_241, v_b_2460))});
  }
  default: return heff_nomatch(v_e_242);
  }
}
V g_heff_2elift_2ereplaceGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2elift_2ereplaceGo(a[0], a[1], a[2]);
}
V g_heff_2elift_2ereplaceGo_lam0(V self, V *args) {
  V v_f_2417 = args[0];
  V v_x_240 = heff_env(self)[0];
  V v_r_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2420;
  switch (heff_tag_of(v_f_2417)) {
  case TAG_MkPair: {
    V v_x_2418 = heff_dup(heff_field(v_f_2417, 0));
    v_t_2420 = v_x_2418;
    break;
  }
  default: heff_nomatch(v_f_2417);
  }
  V v_t_2423;
  switch (heff_tag_of(v_f_2417)) {
  case TAG_MkPair: {
    V v_y_2422 = heff_field(v_f_2417, 1);
    heff_take_n(v_f_2417, 2ULL, 2);
    v_t_2423 = v_y_2422;
    break;
  }
  default: heff_nomatch(v_f_2417);
  }
  return heff_tag(TAG_MkPair, 2, (V[]){v_t_2420, (g_heff_2elift_2ereplaceGo(v_x_240, v_r_241, v_t_2423))});
}
V g_heff_2elift_2ereplaceGo_lam1(V self, V *args) {
  V v_arm_2433 = args[0];
  V v_x_240 = heff_env(self)[0];
  V v_r_241 = heff_env(self)[1];
  heff_clo_take(self, 2);
  V v_t_2437;
  switch (heff_tag_of(v_arm_2433)) {
  case TAG_MkArm: {
    V v_t_2434 = heff_dup(heff_field(v_arm_2433, 0));
    v_t_2437 = v_t_2434;
    break;
  }
  default: heff_nomatch(v_arm_2433);
  }
  V v_t_2441;
  switch (heff_tag_of(v_arm_2433)) {
  case TAG_MkArm: {
    V v_vs_2439 = heff_dup(heff_field(v_arm_2433, 1));
    v_t_2441 = v_vs_2439;
    break;
  }
  default: heff_nomatch(v_arm_2433);
  }
  V v_t_2445;
  switch (heff_tag_of(v_arm_2433)) {
  case TAG_MkArm: {
    V v_b_2444 = heff_field(v_arm_2433, 2);
    heff_take_n(v_arm_2433, 4ULL, 3);
    v_t_2445 = v_b_2444;
    break;
  }
  default: heff_nomatch(v_arm_2433);
  }
  return heff_tag(TAG_MkArm, 3, (V[]){v_t_2437, v_t_2441, (g_heff_2elift_2ereplaceGo(v_x_240, v_r_241, v_t_2445))});
}
Clo g_heff_2elift_2ewithParams_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elift_2ewithParams_entry, 2, 0};

V g_heff_2elift_2ewithParams(V v_fvs_240, V v_b_241) {
top: ;
  switch (heff_tag_of(v_fvs_240)) {
  case TAG_Nil: {
    return v_b_241;
  }
  case TAG_Cons: {
    switch (heff_tag_of(v_b_241)) {
    case TAG_EVar: {
      return heff_tag(TAG_ELam, 2, (V[]){v_fvs_240, v_b_241});
    }
    case TAG_EGlobal: {
      return heff_tag(TAG_ELam, 2, (V[]){v_fvs_240, v_b_241});
    }
    case TAG_ELam: {
      V v_xs_246 = heff_field(v_b_241, 0);
      V v_b2_247 = heff_field(v_b_241, 1);
      V v_ru_24b_241_24ELam = heff_take_reuse_n(v_b_241, 3ULL, 2);
      V v_t_248 = (g_heff_2eir_2eappendI(v_fvs_240, v_xs_246));
      return heff_tag_at(v_ru_24b_241_24ELam, TAG_ELam, 2, (V[]){v_t_248, v_b2_247});
    }
    case TAG_EApp: {
      return heff_tag(TAG_ELam, 2, (V[]){v_fvs_240, v_b_241});
    }
    case TAG_ELet: {
      return heff_tag(TAG_ELam, 2, (V[]){v_fvs_240, v_b_241});
    }
    case TAG_ERecord: {
      return heff_tag(TAG_ELam, 2, (V[]){v_fvs_240, v_b_241});
    }
    case TAG_EProj: {
      return heff_tag(TAG_ELam, 2, (V[]){v_fvs_240, v_b_241});
    }
    case TAG_ETag: {
      return heff_tag(TAG_ELam, 2, (V[]){v_fvs_240, v_b_241});
    }
    case TAG_EMatch: {
      return heff_tag(TAG_ELam, 2, (V[]){v_fvs_240, v_b_241});
    }
    case TAG_EPrim: {
      return heff_tag(TAG_ELam, 2, (V[]){v_fvs_240, v_b_241});
    }
    case TAG_EPrimCall: {
      return heff_tag(TAG_ELam, 2, (V[]){v_fvs_240, v_b_241});
    }
    case TAG_ECall: {
      return heff_tag(TAG_ELam, 2, (V[]){v_fvs_240, v_b_241});
    }
    case TAG_EInt: {
      return heff_tag(TAG_ELam, 2, (V[]){v_fvs_240, v_b_241});
    }
    case TAG_EFloat: {
      return heff_tag(TAG_ELam, 2, (V[]){v_fvs_240, v_b_241});
    }
    case TAG_EStr: {
      return heff_tag(TAG_ELam, 2, (V[]){v_fvs_240, v_b_241});
    }
    case TAG_EFixed: {
      return heff_tag(TAG_ELam, 2, (V[]){v_fvs_240, v_b_241});
    }
    case TAG_EFloat32: {
      return heff_tag(TAG_ELam, 2, (V[]){v_fvs_240, v_b_241});
    }
    case TAG_EAbandon: {
      return heff_tag(TAG_ELam, 2, (V[]){v_fvs_240, v_b_241});
    }
    case TAG_EFix: {
      return heff_tag(TAG_ELam, 2, (V[]){v_fvs_240, v_b_241});
    }
    default: return heff_nomatch(v_b_241);
    }
  }
  default: return heff_nomatch(v_fvs_240);
  }
}
V g_heff_2elift_2ewithParams_entry(V self, V *a) {
  (void)self;
  return g_heff_2elift_2ewithParams(a[0], a[1]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2elift_2eliftedDef_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {46}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2elift_2eliftedDef_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {36}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2elift_2eliftedDef_str2 = {{0x80000000u, K_STR, 0}, 1, 1, {46}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2elift_2eliftedDef_str3 = {{0x80000000u, K_STR, 0}, 1, 1, {46}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2elift_2eliftedDef_str4 = {{0x80000000u, K_STR, 0}, 1, 1, {36}};
Clo g_heff_2elift_2eliftedDef_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elift_2eliftedDef_entry, 5, 0};

V g_heff_2elift_2eliftedDef(V v_d_240, V v_n_241, V v_f_242, V v_fvs_243, V v_body_244) {
top: ;
  V v_t_245 = (g_heff_2eir_2ebaseGo(heff_dup(v_f_242), MK_INT(0LL)));
  V v_key_246 = heff_strAppend(heff_get(heff_dup(v_d_240), LBL_key), heff_strAppend(((V)&g_heff_2elift_2eliftedDef_str0), heff_strAppend(v_t_245, heff_strAppend(((V)&g_heff_2elift_2eliftedDef_str1), heff_intShow(heff_dup(v_n_241))))));
  V v_name_247 = heff_strAppend(heff_get(heff_dup(v_d_240), LBL_name), heff_strAppend(((V)&g_heff_2elift_2eliftedDef_str2), (g_heff_2eir_2ebaseGo(heff_dup(v_f_242), MK_INT(0LL)))));
  V v_t_248 = (g_heff_2eir_2ebaseGo(heff_dup(v_f_242), MK_INT(0LL)));
  V v_key_249 = heff_strAppend(heff_get(v_d_240, LBL_key), heff_strAppend(((V)&g_heff_2elift_2eliftedDef_str3), heff_strAppend(v_t_248, heff_strAppend(((V)&g_heff_2elift_2eliftedDef_str4), heff_intShow(v_n_241)))));
  V v_t_2412;
  switch (heff_tag_of(v_fvs_243)) {
  case TAG_Nil: {
    v_t_2412 = heff_tag(TAG_EGlobal, 1, (V[]){v_key_249});
    break;
  }
  case TAG_Cons: {
    v_t_2412 = heff_tag(TAG_EApp, 2, (V[]){heff_tag(TAG_EGlobal, 1, (V[]){v_key_249}), (g_list_2emap_24s1809017761x1063871171(heff_dup(v_fvs_243)))});
    break;
  }
  default: heff_nomatch(v_fvs_243);
  }
  V v_t_2413 = (g_heff_2elift_2ereplaceGo(v_f_242, v_t_2412, v_body_244));
  V v_body_2414 = (g_heff_2elift_2ewithParams(v_fvs_243, v_t_2413));
  return heff_rec(3, shape_key__name__body, (V[]){v_key_246, v_name_247, v_body_2414});
}
V g_heff_2elift_2eliftedDef_entry(V self, V *a) {
  (void)self;
  return g_heff_2elift_2eliftedDef(a[0], a[1], a[2], a[3], a[4]);
}
Clo g_heff_2elift_2eoneParam_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elift_2eoneParam_entry, 1, 0};

V g_heff_2elift_2eoneParam(V v_e_240) {
top: ;
  switch (heff_tag_of(v_e_240)) {
  case TAG_EVar: {
    heff_take_n(v_e_240, 0ULL, 1);
    return NTAG(TAG_Nothing);
  }
  case TAG_EGlobal: {
    heff_take_n(v_e_240, 0ULL, 1);
    return NTAG(TAG_Nothing);
  }
  case TAG_ELam: {
    V v_xs_243 = heff_field(v_e_240, 0);
    V v_b_244 = heff_field(v_e_240, 1);
    V v_ru_24e_240_24ELam = heff_take_reuse_n(v_e_240, 3ULL, 2);
    switch (heff_tag_of(v_xs_243)) {
    case TAG_Nil: {
      heff_drop(v_b_244);
      heff_drop_cell(v_ru_24e_240_24ELam, 2);
      return NTAG(TAG_Nothing);
    }
    case TAG_Cons: {
      V v_x_245 = heff_field(v_xs_243, 0);
      V v_it2_246 = heff_field(v_xs_243, 1);
      heff_take_n(v_xs_243, 3ULL, 2);
      switch (heff_tag_of(v_it2_246)) {
      case TAG_Nil: {
        return heff_tag(TAG_Just, 1, (V[]){heff_tag_at(v_ru_24e_240_24ELam, TAG_MkPair, 2, (V[]){v_x_245, v_b_244})});
      }
      case TAG_Cons: {
        heff_take_n(v_it2_246, 0ULL, 2);
        heff_drop(v_b_244);
        heff_drop_cell(v_ru_24e_240_24ELam, 2);
        heff_drop(v_x_245);
        return NTAG(TAG_Nothing);
      }
      default: return heff_nomatch(v_it2_246);
      }
    }
    default: return heff_nomatch(v_xs_243);
    }
  }
  case TAG_EApp: {
    heff_take_n(v_e_240, 0ULL, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_ELet: {
    heff_take_n(v_e_240, 0ULL, 3);
    return NTAG(TAG_Nothing);
  }
  case TAG_ERecord: {
    heff_take_n(v_e_240, 0ULL, 1);
    return NTAG(TAG_Nothing);
  }
  case TAG_EProj: {
    heff_take_n(v_e_240, 0ULL, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_ETag: {
    heff_take_n(v_e_240, 0ULL, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_EMatch: {
    heff_take_n(v_e_240, 0ULL, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_EPrim: {
    heff_take_n(v_e_240, 0ULL, 1);
    return NTAG(TAG_Nothing);
  }
  case TAG_EPrimCall: {
    heff_take_n(v_e_240, 0ULL, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_ECall: {
    heff_take_n(v_e_240, 0ULL, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_EInt: {
    heff_take_n(v_e_240, 0ULL, 1);
    return NTAG(TAG_Nothing);
  }
  case TAG_EFloat: {
    heff_take_n(v_e_240, 0ULL, 1);
    return NTAG(TAG_Nothing);
  }
  case TAG_EStr: {
    heff_take_n(v_e_240, 0ULL, 1);
    return NTAG(TAG_Nothing);
  }
  case TAG_EFixed: {
    heff_take_n(v_e_240, 0ULL, 2);
    return NTAG(TAG_Nothing);
  }
  case TAG_EFloat32: {
    heff_take_n(v_e_240, 0ULL, 1);
    return NTAG(TAG_Nothing);
  }
  case TAG_EAbandon: {
    return NTAG(TAG_Nothing);
  }
  case TAG_EFix: {
    heff_take_n(v_e_240, 0ULL, 2);
    return NTAG(TAG_Nothing);
  }
  default: return heff_nomatch(v_e_240);
  }
}
V g_heff_2elift_2eoneParam_entry(V self, V *a) {
  (void)self;
  return g_heff_2elift_2eoneParam(a[0]);
}
Clo g_heff_2elift_2eliftMany_24s2129644851x1119046535_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elift_2eliftMany_24s2129644851x1119046535_entry, 3, 0};

V g_heff_2elift_2eliftMany_24s2129644851x1119046535(V v_d_240, V v_acc_241, V v_x4_242) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_Nil: {
    heff_drop(v_d_240);
    return heff_tag(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_acc_241});
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x4_242, 0);
    V v_xs_244 = heff_field(v_x4_242, 1);
    V v_ru_24x4_242_24Cons = heff_take_reuse_n(v_x4_242, 3ULL, 2);
    V v_t_245 = (g_heff_2elift_2eliftGo_24s1262932354x2044031683(heff_dup(v_d_240), v_acc_241, v_x_243));
    switch (heff_tag_of(v_t_245)) {
    case TAG_MkPair: {
      V v_x2_246 = heff_field(v_t_245, 0);
      V v_acc2_247 = heff_field(v_t_245, 1);
      heff_take_n(v_t_245, 3ULL, 2);
      V v_x2_248 = (g_heff_2elift_2eliftMany_24s2129644851x1119046535(v_d_240, v_acc2_247, v_xs_244));
      switch (heff_tag_of(v_x2_248)) {
      case TAG_MkPair: {
        V v_xs_249 = heff_field(v_x2_248, 0);
        V v_acc_2410 = heff_field(v_x2_248, 1);
        heff_take_n(v_x2_248, 3ULL, 2);
        return heff_tag_at(v_ru_24x4_242_24Cons, TAG_MkPair, 2, (V[]){heff_tag(TAG_Cons, 2, (V[]){v_x2_246, v_xs_249}), v_acc_2410});
      }
      default: return heff_nomatch(v_x2_248);
      }
    }
    default: return heff_nomatch(v_t_245);
    }
  }
  default: return heff_nomatch(v_x4_242);
  }
}
V g_heff_2elift_2eliftMany_24s2129644851x1119046535_entry(V self, V *a) {
  (void)self;
  return g_heff_2elift_2eliftMany_24s2129644851x1119046535(a[0], a[1], a[2]);
}
Clo g_heff_2elift_2eliftFixDef_24s621078245x1616660209_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elift_2eliftFixDef_24s621078245x1616660209_entry, 3, 0};

V g_heff_2elift_2eliftFixDef_24s621078245x1616660209(V v_acc_240, V v_fvs_241, V v_ld_242) {
top: ;
  V v_t_243 = heff_intAdd(heff_get(heff_dup(v_acc_240), LBL_n), MK_INT(1LL));
  V v_t_244 = heff_rec(2, shape_out__n, (V[]){heff_get(v_acc_240, LBL_out), v_t_243});
  V v_t_245 = (g_heff_2elift_2eliftGo_24s1262932354x2044031683(heff_dup(v_ld_242), v_t_244, heff_get(heff_dup(v_ld_242), LBL_body)));
  switch (heff_tag_of(v_t_245)) {
  case TAG_MkPair: {
    V v_b2_246 = heff_field(v_t_245, 0);
    V v_acc2_247 = heff_field(v_t_245, 1);
    V v_ru_24t_245_24MkPair = heff_take_reuse_n(v_t_245, 3ULL, 2);
    V v_key_248 = heff_get(heff_dup(v_ld_242), LBL_key);
    V v_t_2411;
    switch (heff_tag_of(v_fvs_241)) {
    case TAG_Nil: {
      heff_drop_cell(v_ru_24t_245_24MkPair, 2);
      v_t_2411 = heff_tag(TAG_EGlobal, 1, (V[]){v_key_248});
      break;
    }
    case TAG_Cons: {
      v_t_2411 = heff_tag_at(v_ru_24t_245_24MkPair, TAG_EApp, 2, (V[]){heff_tag(TAG_EGlobal, 1, (V[]){v_key_248}), (g_list_2emap_24s1809017761x1063871171(v_fvs_241))});
      break;
    }
    default: heff_nomatch(v_fvs_241);
    }
    V v_t_2412 = heff_rec(3, shape_key__name__body, (V[]){heff_get(heff_dup(v_ld_242), LBL_key), heff_get(v_ld_242, LBL_name), v_b2_246});
    V v_t_2413 = heff_tag(TAG_Cons, 2, (V[]){v_t_2412, heff_get(heff_dup(v_acc2_247), LBL_out)});
    V v_t_2414 = heff_rec(2, shape_out__n, (V[]){v_t_2413, heff_get(v_acc2_247, LBL_n)});
    return heff_tag(TAG_MkPair, 2, (V[]){v_t_2411, v_t_2414});
  }
  default: return heff_nomatch(v_t_245);
  }
}
V g_heff_2elift_2eliftFixDef_24s621078245x1616660209_entry(V self, V *a) {
  (void)self;
  return g_heff_2elift_2eliftFixDef_24s621078245x1616660209(a[0], a[1], a[2]);
}
Clo g_heff_2elift_2eliftFix_24s1233964062x730417183_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elift_2eliftFix_24s1233964062x730417183_entry, 4, 0};

V g_heff_2elift_2eliftFix_24s1233964062x730417183(V v_d_240, V v_acc_241, V v_f_242, V v_body_243) {
top: ;
  V v_t_244 = heff_tag(TAG_Cons, 2, (V[]){heff_dup(v_f_242), NTAG(TAG_Nil)});
  V v_xs_245 = (g_heff_2elift_2efreeGo(v_t_244, heff_dup(v_body_243), NTAG(TAG_Nil)));
  V v_t_246 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_245));
  V v_t_247 = heff_tag(TAG_Cons, 2, (V[]){heff_dup(v_f_242), NTAG(TAG_Nil)});
  V v_xs_248 = (g_heff_2elift_2efreeGo(v_t_247, heff_dup(v_body_243), NTAG(TAG_Nil)));
  V v_t_249 = (g_list_2efoldl_24s1370882877x364361272(NTAG(TAG_Nil), v_xs_248));
  V v_t_2410 = (g_heff_2elift_2eliftedDef(v_d_240, heff_get(heff_dup(v_acc_241), LBL_n), v_f_242, v_t_249, v_body_243));
  return (g_heff_2elift_2eliftFixDef_24s621078245x1616660209(v_acc_241, v_t_246, v_t_2410));
}
V g_heff_2elift_2eliftFix_24s1233964062x730417183_entry(V self, V *a) {
  (void)self;
  return g_heff_2elift_2eliftFix_24s1233964062x730417183(a[0], a[1], a[2], a[3]);
}
Clo g_heff_2elift_2eliftRedex_24s2095000274x602849629_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elift_2eliftRedex_24s2095000274x602849629_entry, 5, 0};

V g_heff_2elift_2eliftRedex_24s2095000274x602849629(V v_d_240, V v_acc_241, V v_x_242, V v_b_243, V v_a_244) {
top: ;
  V v_it_2434;
  switch (heff_tag_of(v_a_244)) {
  case TAG_EVar: {
    v_it_2434 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EGlobal: {
    v_it_2434 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_ELam: {
    v_it_2434 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EApp: {
    v_it_2434 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_ELet: {
    v_it_2434 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_ERecord: {
    v_it_2434 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EProj: {
    v_it_2434 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_ETag: {
    v_it_2434 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EMatch: {
    v_it_2434 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EPrim: {
    v_it_2434 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EPrimCall: {
    v_it_2434 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_ECall: {
    v_it_2434 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EInt: {
    v_it_2434 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EFloat: {
    v_it_2434 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EStr: {
    v_it_2434 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EFixed: {
    v_it_2434 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EFloat32: {
    v_it_2434 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EAbandon: {
    v_it_2434 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EFix: {
    V v_f_2432 = heff_dup(heff_field(v_a_244, 0));
    V v_b_2433 = heff_dup(heff_field(v_a_244, 1));
    v_it_2434 = heff_tag(TAG_Just, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_f_2432, v_b_2433})});
    break;
  }
  default: heff_nomatch(v_a_244);
  }
  switch (heff_tag_of(v_it_2434)) {
  case TAG_Nothing: {
    V v_t_2435 = heff_tag(TAG_Cons, 2, (V[]){heff_dup(v_x_242), NTAG(TAG_Nil)});
    V v_t_2436 = heff_tag(TAG_Cons, 2, (V[]){heff_dup(v_a_244), NTAG(TAG_Nil)});
    V v_t_2437 = heff_tag(TAG_Cons, 2, (V[]){heff_tag(TAG_ELam, 2, (V[]){v_t_2435, heff_dup(v_b_243)}), v_t_2436});
    V v_it_2438 = (g_heff_2elift_2eliftMany_24s2129644851x1119046535(v_d_240, v_acc_241, v_t_2437));
    switch (heff_tag_of(v_it_2438)) {
    case TAG_MkPair: {
      V v_it1_2439 = heff_field(v_it_2438, 0);
      V v_acc2_2440 = heff_field(v_it_2438, 1);
      V v_ru_24it_2438_24MkPair = heff_take_reuse_n(v_it_2438, 3ULL, 2);
      switch (heff_tag_of(v_it1_2439)) {
      case TAG_Nil: {
        V v_t_2441 = heff_tag_at(v_ru_24it_2438_24MkPair, TAG_Cons, 2, (V[]){v_x_242, NTAG(TAG_Nil)});
        V v_t_2442 = heff_tag(TAG_Cons, 2, (V[]){v_a_244, NTAG(TAG_Nil)});
        V v_t_2443 = heff_tag(TAG_EApp, 2, (V[]){heff_tag(TAG_ELam, 2, (V[]){v_t_2441, v_b_243}), v_t_2442});
        return heff_tag(TAG_MkPair, 2, (V[]){v_t_2443, v_acc2_2440});
      }
      case TAG_Cons: {
        V v_f2_2444 = heff_field(v_it1_2439, 0);
        V v_as2_2445 = heff_field(v_it1_2439, 1);
        heff_take_n(v_it1_2439, 3ULL, 2);
        heff_drop(v_x_242);
        heff_drop(v_b_243);
        heff_drop(v_a_244);
        return heff_tag_at(v_ru_24it_2438_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_EApp, 2, (V[]){v_f2_2444, v_as2_2445}), v_acc2_2440});
      }
      default: return heff_nomatch(v_it1_2439);
      }
    }
    default: return heff_nomatch(v_it_2438);
    }
  }
  case TAG_Just: {
    V v_it1_2446 = heff_field(v_it_2434, 0);
    heff_take_n(v_it_2434, 1ULL, 1);
    heff_drop(v_a_244);
    switch (heff_tag_of(v_it1_2446)) {
    case TAG_MkPair: {
      V v_f_2447 = heff_field(v_it1_2446, 0);
      V v_fb_2448 = heff_field(v_it1_2446, 1);
      heff_take_n(v_it1_2446, 3ULL, 2);
      V v_t_2449 = (g_heff_2elift_2eliftFix_24s1233964062x730417183(heff_dup(v_d_240), v_acc_241, v_f_2447, v_fb_2448));
      switch (heff_tag_of(v_t_2449)) {
      case TAG_MkPair: {
        V v_call_2450 = heff_field(v_t_2449, 0);
        V v_acc2_2451 = heff_field(v_t_2449, 1);
        heff_take_n(v_t_2449, 3ULL, 2);
        V v_e_2452 = (g_heff_2elift_2ereplaceGo(v_x_242, v_call_2450, v_b_243));
        return (g_heff_2elift_2eliftGo_24s1262932354x2044031683(v_d_240, v_acc2_2451, v_e_2452));
      }
      default: return heff_nomatch(v_t_2449);
      }
    }
    default: return heff_nomatch(v_it1_2446);
    }
  }
  default: return heff_nomatch(v_it_2434);
  }
}
V g_heff_2elift_2eliftRedex_24s2095000274x602849629_entry(V self, V *a) {
  (void)self;
  return g_heff_2elift_2eliftRedex_24s2095000274x602849629(a[0], a[1], a[2], a[3], a[4]);
}
Clo g_heff_2elift_2eliftApp_24s2432925x2084037232_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elift_2eliftApp_24s2432925x2084037232_entry, 4, 0};

V g_heff_2elift_2eliftApp_24s2432925x2084037232(V v_d_240, V v_acc_241, V v_f_242, V v_as_243) {
top: ;
  V v_it_244 = (g_heff_2elift_2eoneParam(heff_dup(v_f_242)));
  switch (heff_tag_of(v_it_244)) {
  case TAG_Nothing: {
    V v_it_245 = (g_heff_2elift_2eliftMany_24s2129644851x1119046535(v_d_240, v_acc_241, heff_tag(TAG_Cons, 2, (V[]){heff_dup(v_f_242), heff_dup(v_as_243)})));
    switch (heff_tag_of(v_it_245)) {
    case TAG_MkPair: {
      V v_it1_246 = heff_field(v_it_245, 0);
      V v_acc2_247 = heff_field(v_it_245, 1);
      V v_ru_24it_245_24MkPair = heff_take_reuse_n(v_it_245, 3ULL, 2);
      switch (heff_tag_of(v_it1_246)) {
      case TAG_Nil: {
        return heff_tag_at(v_ru_24it_245_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_EApp, 2, (V[]){v_f_242, v_as_243}), v_acc2_247});
      }
      case TAG_Cons: {
        V v_f2_248 = heff_field(v_it1_246, 0);
        V v_as2_249 = heff_field(v_it1_246, 1);
        heff_take_n(v_it1_246, 3ULL, 2);
        heff_drop(v_f_242);
        heff_drop(v_as_243);
        return heff_tag_at(v_ru_24it_245_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_EApp, 2, (V[]){v_f2_248, v_as2_249}), v_acc2_247});
      }
      default: return heff_nomatch(v_it1_246);
      }
    }
    default: return heff_nomatch(v_it_245);
    }
  }
  case TAG_Just: {
    V v_it1_2410 = heff_field(v_it_244, 0);
    heff_take_n(v_it_244, 1ULL, 1);
    switch (heff_tag_of(v_it1_2410)) {
    case TAG_MkPair: {
      V v_x_2411 = heff_field(v_it1_2410, 0);
      V v_b_2412 = heff_field(v_it1_2410, 1);
      V v_ru_24it1_2410_24MkPair = heff_take_reuse_n(v_it1_2410, 3ULL, 2);
      switch (heff_tag_of(v_as_243)) {
      case TAG_Nil: {
        heff_drop(v_x_2411);
        heff_drop(v_b_2412);
        V v_it_2413 = (g_heff_2elift_2eliftMany_24s2129644851x1119046535(v_d_240, v_acc_241, heff_tag_at(v_ru_24it1_2410_24MkPair, TAG_Cons, 2, (V[]){heff_dup(v_f_242), heff_dup(v_as_243)})));
        switch (heff_tag_of(v_it_2413)) {
        case TAG_MkPair: {
          V v_it1_2414 = heff_field(v_it_2413, 0);
          V v_acc2_2415 = heff_field(v_it_2413, 1);
          V v_ru_24it_2413_24MkPair = heff_take_reuse_n(v_it_2413, 3ULL, 2);
          switch (heff_tag_of(v_it1_2414)) {
          case TAG_Nil: {
            return heff_tag_at(v_ru_24it_2413_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_EApp, 2, (V[]){v_f_242, v_as_243}), v_acc2_2415});
          }
          case TAG_Cons: {
            V v_f2_2416 = heff_field(v_it1_2414, 0);
            V v_as2_2417 = heff_field(v_it1_2414, 1);
            heff_take_n(v_it1_2414, 3ULL, 2);
            heff_drop(v_f_242);
            return heff_tag_at(v_ru_24it_2413_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_EApp, 2, (V[]){v_f2_2416, v_as2_2417}), v_acc2_2415});
          }
          default: return heff_nomatch(v_it1_2414);
          }
        }
        default: return heff_nomatch(v_it_2413);
        }
      }
      case TAG_Cons: {
        V v_a_2418 = heff_dup(heff_field(v_as_243, 0));
        V v_it2_2419 = heff_dup(heff_field(v_as_243, 1));
        switch (heff_tag_of(v_it2_2419)) {
        case TAG_Nil: {
          heff_drop(v_f_242);
          heff_drop_tag(v_as_243, 2);
          heff_drop_cell(v_ru_24it1_2410_24MkPair, 2);
          return (g_heff_2elift_2eliftRedex_24s2095000274x602849629(v_d_240, v_acc_241, v_x_2411, v_b_2412, v_a_2418));
        }
        case TAG_Cons: {
          V v_ru_24it2_2419_24Cons = heff_take_reuse_n(v_it2_2419, 0ULL, 2);
          heff_drop(v_x_2411);
          heff_drop(v_b_2412);
          heff_drop(v_a_2418);
          V v_it_2422 = (g_heff_2elift_2eliftMany_24s2129644851x1119046535(v_d_240, v_acc_241, heff_tag_at(v_ru_24it1_2410_24MkPair, TAG_Cons, 2, (V[]){heff_dup(v_f_242), heff_dup(v_as_243)})));
          switch (heff_tag_of(v_it_2422)) {
          case TAG_MkPair: {
            V v_it1_2423 = heff_field(v_it_2422, 0);
            V v_acc2_2424 = heff_field(v_it_2422, 1);
            heff_take_n(v_it_2422, 3ULL, 2);
            switch (heff_tag_of(v_it1_2423)) {
            case TAG_Nil: {
              return heff_tag_at(v_ru_24it2_2419_24Cons, TAG_MkPair, 2, (V[]){heff_tag(TAG_EApp, 2, (V[]){v_f_242, v_as_243}), v_acc2_2424});
            }
            case TAG_Cons: {
              V v_f2_2425 = heff_field(v_it1_2423, 0);
              V v_as2_2426 = heff_field(v_it1_2423, 1);
              heff_take_n(v_it1_2423, 3ULL, 2);
              heff_drop(v_f_242);
              heff_drop_tag(v_as_243, 2);
              return heff_tag_at(v_ru_24it2_2419_24Cons, TAG_MkPair, 2, (V[]){heff_tag(TAG_EApp, 2, (V[]){v_f2_2425, v_as2_2426}), v_acc2_2424});
            }
            default: return heff_nomatch(v_it1_2423);
            }
          }
          default: return heff_nomatch(v_it_2422);
          }
        }
        default: return heff_nomatch(v_it2_2419);
        }
      }
      default: return heff_nomatch(v_as_243);
      }
    }
    default: return heff_nomatch(v_it1_2410);
    }
  }
  default: return heff_nomatch(v_it_244);
  }
}
V g_heff_2elift_2eliftApp_24s2432925x2084037232_entry(V self, V *a) {
  (void)self;
  return g_heff_2elift_2eliftApp_24s2432925x2084037232(a[0], a[1], a[2], a[3]);
}
Clo g_heff_2elift_2eliftGo_24s1262932354x2044031683_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elift_2eliftGo_24s1262932354x2044031683_entry, 3, 0};

V g_heff_2elift_2eliftGo_24s1262932354x2044031683(V v_d_240, V v_acc_241, V v_e_242) {
top: ;
  switch (heff_tag_of(v_e_242)) {
  case TAG_EVar: {
    heff_drop(v_d_240);
    return heff_tag(TAG_MkPair, 2, (V[]){v_e_242, v_acc_241});
  }
  case TAG_EGlobal: {
    heff_drop(v_d_240);
    return heff_tag(TAG_MkPair, 2, (V[]){v_e_242, v_acc_241});
  }
  case TAG_ELam: {
    V v_xs_245 = heff_field(v_e_242, 0);
    V v_b_246 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24ELam = heff_take_reuse_n(v_e_242, 3ULL, 2);
    V v_t_247 = (g_heff_2elift_2eliftGo_24s1262932354x2044031683(v_d_240, v_acc_241, v_b_246));
    switch (heff_tag_of(v_t_247)) {
    case TAG_MkPair: {
      V v_b2_248 = heff_field(v_t_247, 0);
      V v_acc2_249 = heff_field(v_t_247, 1);
      heff_take_n(v_t_247, 3ULL, 2);
      return heff_tag_at(v_ru_24e_242_24ELam, TAG_MkPair, 2, (V[]){heff_tag(TAG_ELam, 2, (V[]){v_xs_245, v_b2_248}), v_acc2_249});
    }
    default: return heff_nomatch(v_t_247);
    }
  }
  case TAG_EApp: {
    V v_f_2410 = heff_field(v_e_242, 0);
    V v_as_2411 = heff_field(v_e_242, 1);
    heff_take_n(v_e_242, 3ULL, 2);
    return (g_heff_2elift_2eliftApp_24s2432925x2084037232(v_d_240, v_acc_241, v_f_2410, v_as_2411));
  }
  case TAG_ELet: {
    V v_x_2412 = heff_dup(heff_field(v_e_242, 0));
    V v_a_2413 = heff_dup(heff_field(v_e_242, 1));
    V v_b_2414 = heff_dup(heff_field(v_e_242, 2));
    V v_t_2415 = heff_tag(TAG_Cons, 2, (V[]){v_b_2414, NTAG(TAG_Nil)});
    V v_it_2416 = (g_heff_2elift_2eliftMany_24s2129644851x1119046535(v_d_240, v_acc_241, heff_tag(TAG_Cons, 2, (V[]){v_a_2413, v_t_2415})));
    switch (heff_tag_of(v_it_2416)) {
    case TAG_MkPair: {
      V v_it1_2417 = heff_field(v_it_2416, 0);
      V v_acc2_2418 = heff_field(v_it_2416, 1);
      V v_ru_24it_2416_24MkPair = heff_take_reuse_n(v_it_2416, 3ULL, 2);
      switch (heff_tag_of(v_it1_2417)) {
      case TAG_Nil: {
        heff_drop(v_x_2412);
        return heff_tag_at(v_ru_24it_2416_24MkPair, TAG_MkPair, 2, (V[]){v_e_242, v_acc2_2418});
      }
      case TAG_Cons: {
        V v_a2_2419 = heff_field(v_it1_2417, 0);
        V v_it12_2420 = heff_field(v_it1_2417, 1);
        heff_take_n(v_it1_2417, 3ULL, 2);
        switch (heff_tag_of(v_it12_2420)) {
        case TAG_Nil: {
          heff_drop(v_x_2412);
          heff_drop(v_a2_2419);
          return heff_tag_at(v_ru_24it_2416_24MkPair, TAG_MkPair, 2, (V[]){v_e_242, v_acc2_2418});
        }
        case TAG_Cons: {
          V v_b2_2421 = heff_field(v_it12_2420, 0);
          V v_it122_2422 = heff_field(v_it12_2420, 1);
          heff_take_n(v_it12_2420, 3ULL, 2);
          switch (heff_tag_of(v_it122_2422)) {
          case TAG_Nil: {
            heff_drop_tag(v_e_242, 3);
            return heff_tag_at(v_ru_24it_2416_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_ELet, 3, (V[]){v_x_2412, v_a2_2419, v_b2_2421}), v_acc2_2418});
          }
          case TAG_Cons: {
            heff_take_n(v_it122_2422, 0ULL, 2);
            heff_drop(v_x_2412);
            heff_drop(v_a2_2419);
            heff_drop(v_b2_2421);
            return heff_tag_at(v_ru_24it_2416_24MkPair, TAG_MkPair, 2, (V[]){v_e_242, v_acc2_2418});
          }
          default: return heff_nomatch(v_it122_2422);
          }
        }
        default: return heff_nomatch(v_it12_2420);
        }
      }
      default: return heff_nomatch(v_it1_2417);
      }
    }
    default: return heff_nomatch(v_it_2416);
    }
  }
  case TAG_ERecord: {
    V v_fs_2425 = heff_field(v_e_242, 0);
    V v_ru_24e_242_24ERecord = heff_take_reuse_n(v_e_242, 1ULL, 1);
    V v_t_2426 = (g_list_2emap_24s1173914895x100384474(heff_dup(v_fs_2425)));
    V v_t_2427 = (g_heff_2elift_2eliftMany_24s2129644851x1119046535(v_d_240, v_acc_241, v_t_2426));
    switch (heff_tag_of(v_t_2427)) {
    case TAG_MkPair: {
      V v_es_2428 = heff_field(v_t_2427, 0);
      V v_acc2_2429 = heff_field(v_t_2427, 1);
      V v_ru_24t_2427_24MkPair = heff_take_reuse_n(v_t_2427, 3ULL, 2);
      V v_fs2_2430 = (g_list_2ezipWith_24s1029292936x211450510(v_fs_2425, v_es_2428));
      return heff_tag_at(v_ru_24t_2427_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at(v_ru_24e_242_24ERecord, TAG_ERecord, 1, (V[]){v_fs2_2430}), v_acc2_2429});
    }
    default: return heff_nomatch(v_t_2427);
    }
  }
  case TAG_EProj: {
    V v_x_2431 = heff_field(v_e_242, 0);
    V v_l_2432 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24EProj = heff_take_reuse_n(v_e_242, 3ULL, 2);
    V v_t_2433 = (g_heff_2elift_2eliftGo_24s1262932354x2044031683(v_d_240, v_acc_241, v_x_2431));
    switch (heff_tag_of(v_t_2433)) {
    case TAG_MkPair: {
      V v_x2_2434 = heff_field(v_t_2433, 0);
      V v_acc2_2435 = heff_field(v_t_2433, 1);
      heff_take_n(v_t_2433, 3ULL, 2);
      return heff_tag_at(v_ru_24e_242_24EProj, TAG_MkPair, 2, (V[]){heff_tag(TAG_EProj, 2, (V[]){v_x2_2434, v_l_2432}), v_acc2_2435});
    }
    default: return heff_nomatch(v_t_2433);
    }
  }
  case TAG_ETag: {
    V v_t_2436 = heff_field(v_e_242, 0);
    V v_es_2437 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24ETag = heff_take_reuse_n(v_e_242, 3ULL, 2);
    V v_t_2438 = (g_heff_2elift_2eliftMany_24s2129644851x1119046535(v_d_240, v_acc_241, v_es_2437));
    switch (heff_tag_of(v_t_2438)) {
    case TAG_MkPair: {
      V v_es2_2439 = heff_field(v_t_2438, 0);
      V v_acc2_2440 = heff_field(v_t_2438, 1);
      heff_take_n(v_t_2438, 3ULL, 2);
      return heff_tag_at(v_ru_24e_242_24ETag, TAG_MkPair, 2, (V[]){heff_tag(TAG_ETag, 2, (V[]){v_t_2436, v_es2_2439}), v_acc2_2440});
    }
    default: return heff_nomatch(v_t_2438);
    }
  }
  case TAG_EMatch: {
    V v_x_2441 = heff_field(v_e_242, 0);
    V v_arms_2442 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24EMatch = heff_take_reuse_n(v_e_242, 3ULL, 2);
    V v_t_2443 = (g_heff_2elift_2eliftGo_24s1262932354x2044031683(heff_dup(v_d_240), v_acc_241, v_x_2441));
    switch (heff_tag_of(v_t_2443)) {
    case TAG_MkPair: {
      V v_x2_2444 = heff_field(v_t_2443, 0);
      V v_acc2_2445 = heff_field(v_t_2443, 1);
      heff_take_n(v_t_2443, 3ULL, 2);
      V v_t_2446 = (g_list_2emap_24s2006210321x387008715(heff_dup(v_arms_2442)));
      V v_t_2447 = (g_heff_2elift_2eliftMany_24s2129644851x1119046535(v_d_240, v_acc2_2445, v_t_2446));
      switch (heff_tag_of(v_t_2447)) {
      case TAG_MkPair: {
        V v_bs_2448 = heff_field(v_t_2447, 0);
        V v_acc2_2449 = heff_field(v_t_2447, 1);
        heff_take_n(v_t_2447, 3ULL, 2);
        V v_arms2_2450 = (g_list_2ezipWith_24s738847920x410598254(v_arms_2442, v_bs_2448));
        return heff_tag_at(v_ru_24e_242_24EMatch, TAG_MkPair, 2, (V[]){heff_tag(TAG_EMatch, 2, (V[]){v_x2_2444, v_arms2_2450}), v_acc2_2449});
      }
      default: return heff_nomatch(v_t_2447);
      }
    }
    default: return heff_nomatch(v_t_2443);
    }
  }
  case TAG_EPrim: {
    heff_drop(v_d_240);
    return heff_tag(TAG_MkPair, 2, (V[]){v_e_242, v_acc_241});
  }
  case TAG_EPrimCall: {
    V v_p_2452 = heff_field(v_e_242, 0);
    V v_es_2453 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24EPrimCall = heff_take_reuse_n(v_e_242, 3ULL, 2);
    V v_t_2454 = (g_heff_2elift_2eliftMany_24s2129644851x1119046535(v_d_240, v_acc_241, v_es_2453));
    switch (heff_tag_of(v_t_2454)) {
    case TAG_MkPair: {
      V v_es2_2455 = heff_field(v_t_2454, 0);
      V v_acc2_2456 = heff_field(v_t_2454, 1);
      heff_take_n(v_t_2454, 3ULL, 2);
      return heff_tag_at(v_ru_24e_242_24EPrimCall, TAG_MkPair, 2, (V[]){heff_tag(TAG_EPrimCall, 2, (V[]){v_p_2452, v_es2_2455}), v_acc2_2456});
    }
    default: return heff_nomatch(v_t_2454);
    }
  }
  case TAG_ECall: {
    V v_c_2457 = heff_field(v_e_242, 0);
    V v_es_2458 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24ECall = heff_take_reuse_n(v_e_242, 3ULL, 2);
    V v_t_2459 = (g_heff_2elift_2eliftMany_24s2129644851x1119046535(v_d_240, v_acc_241, v_es_2458));
    switch (heff_tag_of(v_t_2459)) {
    case TAG_MkPair: {
      V v_es2_2460 = heff_field(v_t_2459, 0);
      V v_acc2_2461 = heff_field(v_t_2459, 1);
      heff_take_n(v_t_2459, 3ULL, 2);
      return heff_tag_at(v_ru_24e_242_24ECall, TAG_MkPair, 2, (V[]){heff_tag(TAG_ECall, 2, (V[]){v_c_2457, v_es2_2460}), v_acc2_2461});
    }
    default: return heff_nomatch(v_t_2459);
    }
  }
  case TAG_EInt: {
    heff_drop(v_d_240);
    return heff_tag(TAG_MkPair, 2, (V[]){v_e_242, v_acc_241});
  }
  case TAG_EFloat: {
    heff_drop(v_d_240);
    return heff_tag(TAG_MkPair, 2, (V[]){v_e_242, v_acc_241});
  }
  case TAG_EStr: {
    heff_drop(v_d_240);
    return heff_tag(TAG_MkPair, 2, (V[]){v_e_242, v_acc_241});
  }
  case TAG_EFixed: {
    heff_drop(v_d_240);
    return heff_tag(TAG_MkPair, 2, (V[]){v_e_242, v_acc_241});
  }
  case TAG_EFloat32: {
    heff_drop(v_d_240);
    return heff_tag(TAG_MkPair, 2, (V[]){v_e_242, v_acc_241});
  }
  case TAG_EAbandon: {
    heff_drop(v_d_240);
    return heff_tag(TAG_MkPair, 2, (V[]){v_e_242, v_acc_241});
  }
  case TAG_EFix: {
    V v_f_2468 = heff_field(v_e_242, 0);
    V v_b_2469 = heff_field(v_e_242, 1);
    heff_take_n(v_e_242, 3ULL, 2);
    return (g_heff_2elift_2eliftFix_24s1233964062x730417183(v_d_240, v_acc_241, v_f_2468, v_b_2469));
  }
  default: return heff_nomatch(v_e_242);
  }
}
V g_heff_2elift_2eliftGo_24s1262932354x2044031683_entry(V self, V *a) {
  (void)self;
  return g_heff_2elift_2eliftGo_24s1262932354x2044031683(a[0], a[1], a[2]);
}
Clo g_heff_2elift_2eliftGo_24s104003089x2047780485_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elift_2eliftGo_24s104003089x2047780485_entry, 3, 0};

V g_heff_2elift_2eliftGo_24s104003089x2047780485(V v_lit_240, V v_d_241, V v_e_242) {
top: ;
  switch (heff_tag_of(v_e_242)) {
  case TAG_EVar: {
    heff_drop(v_d_241);
    V v_t_244 = heff_rec(2, shape_out__n, (V[]){NTAG(TAG_Nil), v_lit_240});
    return heff_tag(TAG_MkPair, 2, (V[]){v_e_242, v_t_244});
  }
  case TAG_EGlobal: {
    heff_drop(v_d_241);
    V v_t_246 = heff_rec(2, shape_out__n, (V[]){NTAG(TAG_Nil), v_lit_240});
    return heff_tag(TAG_MkPair, 2, (V[]){v_e_242, v_t_246});
  }
  case TAG_ELam: {
    V v_xs_247 = heff_field(v_e_242, 0);
    V v_b_248 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24ELam = heff_take_reuse_n(v_e_242, 3ULL, 2);
    V v_t_249 = heff_rec(2, shape_out__n, (V[]){NTAG(TAG_Nil), v_lit_240});
    V v_t_2410 = (g_heff_2elift_2eliftGo_24s1262932354x2044031683(v_d_241, v_t_249, v_b_248));
    switch (heff_tag_of(v_t_2410)) {
    case TAG_MkPair: {
      V v_b2_2411 = heff_field(v_t_2410, 0);
      V v_acc2_2412 = heff_field(v_t_2410, 1);
      heff_take_n(v_t_2410, 3ULL, 2);
      return heff_tag_at(v_ru_24e_242_24ELam, TAG_MkPair, 2, (V[]){heff_tag(TAG_ELam, 2, (V[]){v_xs_247, v_b2_2411}), v_acc2_2412});
    }
    default: return heff_nomatch(v_t_2410);
    }
  }
  case TAG_EApp: {
    V v_f_2413 = heff_field(v_e_242, 0);
    V v_as_2414 = heff_field(v_e_242, 1);
    heff_take_n(v_e_242, 3ULL, 2);
    V v_t_2415 = heff_rec(2, shape_out__n, (V[]){NTAG(TAG_Nil), v_lit_240});
    return (g_heff_2elift_2eliftApp_24s2432925x2084037232(v_d_241, v_t_2415, v_f_2413, v_as_2414));
  }
  case TAG_ELet: {
    V v_x_2416 = heff_dup(heff_field(v_e_242, 0));
    V v_a_2417 = heff_dup(heff_field(v_e_242, 1));
    V v_b_2418 = heff_dup(heff_field(v_e_242, 2));
    V v_t_2419 = heff_rec(2, shape_out__n, (V[]){NTAG(TAG_Nil), v_lit_240});
    V v_t_2420 = heff_tag(TAG_Cons, 2, (V[]){v_b_2418, NTAG(TAG_Nil)});
    V v_it_2421 = (g_heff_2elift_2eliftMany_24s2129644851x1119046535(v_d_241, v_t_2419, heff_tag(TAG_Cons, 2, (V[]){v_a_2417, v_t_2420})));
    switch (heff_tag_of(v_it_2421)) {
    case TAG_MkPair: {
      V v_it1_2422 = heff_field(v_it_2421, 0);
      V v_acc2_2423 = heff_field(v_it_2421, 1);
      V v_ru_24it_2421_24MkPair = heff_take_reuse_n(v_it_2421, 3ULL, 2);
      switch (heff_tag_of(v_it1_2422)) {
      case TAG_Nil: {
        heff_drop(v_x_2416);
        return heff_tag_at(v_ru_24it_2421_24MkPair, TAG_MkPair, 2, (V[]){v_e_242, v_acc2_2423});
      }
      case TAG_Cons: {
        V v_a2_2424 = heff_field(v_it1_2422, 0);
        V v_it12_2425 = heff_field(v_it1_2422, 1);
        heff_take_n(v_it1_2422, 3ULL, 2);
        switch (heff_tag_of(v_it12_2425)) {
        case TAG_Nil: {
          heff_drop(v_x_2416);
          heff_drop(v_a2_2424);
          return heff_tag_at(v_ru_24it_2421_24MkPair, TAG_MkPair, 2, (V[]){v_e_242, v_acc2_2423});
        }
        case TAG_Cons: {
          V v_b2_2426 = heff_field(v_it12_2425, 0);
          V v_it122_2427 = heff_field(v_it12_2425, 1);
          heff_take_n(v_it12_2425, 3ULL, 2);
          switch (heff_tag_of(v_it122_2427)) {
          case TAG_Nil: {
            heff_drop_tag(v_e_242, 3);
            return heff_tag_at(v_ru_24it_2421_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_ELet, 3, (V[]){v_x_2416, v_a2_2424, v_b2_2426}), v_acc2_2423});
          }
          case TAG_Cons: {
            heff_take_n(v_it122_2427, 0ULL, 2);
            heff_drop(v_x_2416);
            heff_drop(v_a2_2424);
            heff_drop(v_b2_2426);
            return heff_tag_at(v_ru_24it_2421_24MkPair, TAG_MkPair, 2, (V[]){v_e_242, v_acc2_2423});
          }
          default: return heff_nomatch(v_it122_2427);
          }
        }
        default: return heff_nomatch(v_it12_2425);
        }
      }
      default: return heff_nomatch(v_it1_2422);
      }
    }
    default: return heff_nomatch(v_it_2421);
    }
  }
  case TAG_ERecord: {
    V v_fs_2430 = heff_field(v_e_242, 0);
    V v_ru_24e_242_24ERecord = heff_take_reuse_n(v_e_242, 1ULL, 1);
    V v_t_2431 = heff_rec(2, shape_out__n, (V[]){NTAG(TAG_Nil), v_lit_240});
    V v_t_2432 = (g_list_2emap_24s1173914895x100384474(heff_dup(v_fs_2430)));
    V v_t_2433 = (g_heff_2elift_2eliftMany_24s2129644851x1119046535(v_d_241, v_t_2431, v_t_2432));
    switch (heff_tag_of(v_t_2433)) {
    case TAG_MkPair: {
      V v_es_2434 = heff_field(v_t_2433, 0);
      V v_acc2_2435 = heff_field(v_t_2433, 1);
      V v_ru_24t_2433_24MkPair = heff_take_reuse_n(v_t_2433, 3ULL, 2);
      V v_fs2_2436 = (g_list_2ezipWith_24s1029292936x211450510(v_fs_2430, v_es_2434));
      return heff_tag_at(v_ru_24t_2433_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at(v_ru_24e_242_24ERecord, TAG_ERecord, 1, (V[]){v_fs2_2436}), v_acc2_2435});
    }
    default: return heff_nomatch(v_t_2433);
    }
  }
  case TAG_EProj: {
    V v_x_2437 = heff_field(v_e_242, 0);
    V v_l_2438 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24EProj = heff_take_reuse_n(v_e_242, 3ULL, 2);
    V v_t_2439 = heff_rec(2, shape_out__n, (V[]){NTAG(TAG_Nil), v_lit_240});
    V v_t_2440 = (g_heff_2elift_2eliftGo_24s1262932354x2044031683(v_d_241, v_t_2439, v_x_2437));
    switch (heff_tag_of(v_t_2440)) {
    case TAG_MkPair: {
      V v_x2_2441 = heff_field(v_t_2440, 0);
      V v_acc2_2442 = heff_field(v_t_2440, 1);
      heff_take_n(v_t_2440, 3ULL, 2);
      return heff_tag_at(v_ru_24e_242_24EProj, TAG_MkPair, 2, (V[]){heff_tag(TAG_EProj, 2, (V[]){v_x2_2441, v_l_2438}), v_acc2_2442});
    }
    default: return heff_nomatch(v_t_2440);
    }
  }
  case TAG_ETag: {
    V v_t_2443 = heff_field(v_e_242, 0);
    V v_es_2444 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24ETag = heff_take_reuse_n(v_e_242, 3ULL, 2);
    V v_t_2445 = heff_rec(2, shape_out__n, (V[]){NTAG(TAG_Nil), v_lit_240});
    V v_t_2446 = (g_heff_2elift_2eliftMany_24s2129644851x1119046535(v_d_241, v_t_2445, v_es_2444));
    switch (heff_tag_of(v_t_2446)) {
    case TAG_MkPair: {
      V v_es2_2447 = heff_field(v_t_2446, 0);
      V v_acc2_2448 = heff_field(v_t_2446, 1);
      heff_take_n(v_t_2446, 3ULL, 2);
      return heff_tag_at(v_ru_24e_242_24ETag, TAG_MkPair, 2, (V[]){heff_tag(TAG_ETag, 2, (V[]){v_t_2443, v_es2_2447}), v_acc2_2448});
    }
    default: return heff_nomatch(v_t_2446);
    }
  }
  case TAG_EMatch: {
    V v_x_2449 = heff_field(v_e_242, 0);
    V v_arms_2450 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24EMatch = heff_take_reuse_n(v_e_242, 3ULL, 2);
    V v_t_2451 = heff_rec(2, shape_out__n, (V[]){NTAG(TAG_Nil), v_lit_240});
    V v_t_2452 = (g_heff_2elift_2eliftGo_24s1262932354x2044031683(heff_dup(v_d_241), v_t_2451, v_x_2449));
    switch (heff_tag_of(v_t_2452)) {
    case TAG_MkPair: {
      V v_x2_2453 = heff_field(v_t_2452, 0);
      V v_acc2_2454 = heff_field(v_t_2452, 1);
      heff_take_n(v_t_2452, 3ULL, 2);
      V v_t_2455 = (g_list_2emap_24s2006210321x387008715(heff_dup(v_arms_2450)));
      V v_t_2456 = (g_heff_2elift_2eliftMany_24s2129644851x1119046535(v_d_241, v_acc2_2454, v_t_2455));
      switch (heff_tag_of(v_t_2456)) {
      case TAG_MkPair: {
        V v_bs_2457 = heff_field(v_t_2456, 0);
        V v_acc2_2458 = heff_field(v_t_2456, 1);
        heff_take_n(v_t_2456, 3ULL, 2);
        V v_arms2_2459 = (g_list_2ezipWith_24s738847920x410598254(v_arms_2450, v_bs_2457));
        return heff_tag_at(v_ru_24e_242_24EMatch, TAG_MkPair, 2, (V[]){heff_tag(TAG_EMatch, 2, (V[]){v_x2_2453, v_arms2_2459}), v_acc2_2458});
      }
      default: return heff_nomatch(v_t_2456);
      }
    }
    default: return heff_nomatch(v_t_2452);
    }
  }
  case TAG_EPrim: {
    heff_drop(v_d_241);
    V v_t_2461 = heff_rec(2, shape_out__n, (V[]){NTAG(TAG_Nil), v_lit_240});
    return heff_tag(TAG_MkPair, 2, (V[]){v_e_242, v_t_2461});
  }
  case TAG_EPrimCall: {
    V v_p_2462 = heff_field(v_e_242, 0);
    V v_es_2463 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24EPrimCall = heff_take_reuse_n(v_e_242, 3ULL, 2);
    V v_t_2464 = heff_rec(2, shape_out__n, (V[]){NTAG(TAG_Nil), v_lit_240});
    V v_t_2465 = (g_heff_2elift_2eliftMany_24s2129644851x1119046535(v_d_241, v_t_2464, v_es_2463));
    switch (heff_tag_of(v_t_2465)) {
    case TAG_MkPair: {
      V v_es2_2466 = heff_field(v_t_2465, 0);
      V v_acc2_2467 = heff_field(v_t_2465, 1);
      heff_take_n(v_t_2465, 3ULL, 2);
      return heff_tag_at(v_ru_24e_242_24EPrimCall, TAG_MkPair, 2, (V[]){heff_tag(TAG_EPrimCall, 2, (V[]){v_p_2462, v_es2_2466}), v_acc2_2467});
    }
    default: return heff_nomatch(v_t_2465);
    }
  }
  case TAG_ECall: {
    V v_c_2468 = heff_field(v_e_242, 0);
    V v_es_2469 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24ECall = heff_take_reuse_n(v_e_242, 3ULL, 2);
    V v_t_2470 = heff_rec(2, shape_out__n, (V[]){NTAG(TAG_Nil), v_lit_240});
    V v_t_2471 = (g_heff_2elift_2eliftMany_24s2129644851x1119046535(v_d_241, v_t_2470, v_es_2469));
    switch (heff_tag_of(v_t_2471)) {
    case TAG_MkPair: {
      V v_es2_2472 = heff_field(v_t_2471, 0);
      V v_acc2_2473 = heff_field(v_t_2471, 1);
      heff_take_n(v_t_2471, 3ULL, 2);
      return heff_tag_at(v_ru_24e_242_24ECall, TAG_MkPair, 2, (V[]){heff_tag(TAG_ECall, 2, (V[]){v_c_2468, v_es2_2472}), v_acc2_2473});
    }
    default: return heff_nomatch(v_t_2471);
    }
  }
  case TAG_EInt: {
    heff_drop(v_d_241);
    V v_t_2475 = heff_rec(2, shape_out__n, (V[]){NTAG(TAG_Nil), v_lit_240});
    return heff_tag(TAG_MkPair, 2, (V[]){v_e_242, v_t_2475});
  }
  case TAG_EFloat: {
    heff_drop(v_d_241);
    V v_t_2477 = heff_rec(2, shape_out__n, (V[]){NTAG(TAG_Nil), v_lit_240});
    return heff_tag(TAG_MkPair, 2, (V[]){v_e_242, v_t_2477});
  }
  case TAG_EStr: {
    heff_drop(v_d_241);
    V v_t_2479 = heff_rec(2, shape_out__n, (V[]){NTAG(TAG_Nil), v_lit_240});
    return heff_tag(TAG_MkPair, 2, (V[]){v_e_242, v_t_2479});
  }
  case TAG_EFixed: {
    heff_drop(v_d_241);
    V v_t_2482 = heff_rec(2, shape_out__n, (V[]){NTAG(TAG_Nil), v_lit_240});
    return heff_tag(TAG_MkPair, 2, (V[]){v_e_242, v_t_2482});
  }
  case TAG_EFloat32: {
    heff_drop(v_d_241);
    V v_t_2484 = heff_rec(2, shape_out__n, (V[]){NTAG(TAG_Nil), v_lit_240});
    return heff_tag(TAG_MkPair, 2, (V[]){v_e_242, v_t_2484});
  }
  case TAG_EAbandon: {
    heff_drop(v_d_241);
    V v_t_2485 = heff_rec(2, shape_out__n, (V[]){NTAG(TAG_Nil), v_lit_240});
    return heff_tag(TAG_MkPair, 2, (V[]){v_e_242, v_t_2485});
  }
  case TAG_EFix: {
    V v_f_2486 = heff_field(v_e_242, 0);
    V v_b_2487 = heff_field(v_e_242, 1);
    heff_take_n(v_e_242, 3ULL, 2);
    V v_t_2488 = heff_rec(2, shape_out__n, (V[]){NTAG(TAG_Nil), v_lit_240});
    return (g_heff_2elift_2eliftFix_24s1233964062x730417183(v_d_241, v_t_2488, v_f_2486, v_b_2487));
  }
  default: return heff_nomatch(v_e_242);
  }
}
V g_heff_2elift_2eliftGo_24s104003089x2047780485_entry(V self, V *a) {
  (void)self;
  return g_heff_2elift_2eliftGo_24s104003089x2047780485(a[0], a[1], a[2]);
}