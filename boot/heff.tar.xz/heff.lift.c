// Generated from Hippogriff; do not edit.
#define HEFF_PART
#include "heff.h"
V g_heff_2elift_2efreeGo_lam0(V self, V *args);
V g_heff_2elift_2efreeGo_lam1(V self, V *args);
V g_heff_2elift_2efreeGo_lam2(V self, V *args);
V g_heff_2elift_2efreeGo_lam3(V self, V *args);
V g_heff_2elift_2efreeGo_lam4(V self, V *args);
V g_heff_2elift_2efreeGo_lam5(V self, V *args);
Clo g_heff_2elift_2efreeGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elift_2efreeGo_entry, 3, 0};

V g_heff_2elift_2efreeGo(V v_bound_240, V v_e_241, V v_acc_242) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_EVar: {
    V v_x_243 = heff_field(v_e_241, 0);
    heff_take(v_e_241, 1ULL);
    V v_t_244 = heff_tr(heff_apply(((V)&prim_strEq_clo), 1, (V[]){heff_dup(v_x_243)}));
    V v_t_245 = ({ V a_0 = v_t_244; V a_1 = v_bound_240; V r_ = (g_prelude_2eany(a_0, a_1)); heff_drop(v_bound_240); r_; });
    switch (heff_tag_of(v_t_245)) {
    case TAG_True: {
      heff_drop(v_x_243);
      heff_drop(v_t_245);
      return v_acc_242;
    }
    case TAG_False: {
      heff_drop(v_t_245);
      V v_t_246 = heff_tr(heff_apply(((V)&prim_strEq_clo), 1, (V[]){heff_dup(v_x_243)}));
      V v_t_247 = (g_prelude_2eany(v_t_246, v_acc_242));
      switch (heff_tag_of(v_t_247)) {
      case TAG_True: {
        heff_drop(v_x_243);
        heff_drop(v_t_247);
        return v_acc_242;
      }
      case TAG_False: {
        heff_drop(v_t_247);
        return heff_tag(TAG_Cons, 2, (V[]){v_x_243, v_acc_242});
      }
      default: return heff_nomatch(v_t_247);
      }
    }
    default: return heff_nomatch(v_t_245);
    }
  }
  case TAG_EGlobal: {
    heff_take(v_e_241, 0ULL);
    heff_drop(v_bound_240);
    return v_acc_242;
  }
  case TAG_ELam: {
    V v_xs_249 = heff_field(v_e_241, 0);
    V v_b_2410 = heff_field(v_e_241, 1);
    heff_take(v_e_241, 3ULL);
    V v_t_2411 = (g_heff_2eir_2eappendI(v_xs_249, v_bound_240));
    V t_0 = v_t_2411;
    V t_1 = v_b_2410;
    V t_2 = v_acc_242;
    v_bound_240 = t_0;
    v_e_241 = t_1;
    v_acc_242 = t_2;
    goto top;
  }
  case TAG_EApp: {
    V v_f_2412 = heff_field(v_e_241, 0);
    V v_as_2413 = heff_field(v_e_241, 1);
    heff_take(v_e_241, 3ULL);
    V v_t_2414 = (g_heff_2elift_2efreeGo(heff_dup(v_bound_240), v_f_2412, v_acc_242));
    return ({ V a_0 = heff_clo(g_heff_2elift_2efreeGo_lam0, 2, 1, (V[]){v_bound_240}); V a_1 = v_t_2414; V a_2 = v_as_2413; V r_ = (g_prelude_2efoldl(a_0, a_1, a_2)); heff_drop(v_as_2413); r_; });
  }
  case TAG_ELet: {
    V v_x_2417 = heff_field(v_e_241, 0);
    V v_a_2418 = heff_field(v_e_241, 1);
    V v_b_2419 = heff_field(v_e_241, 2);
    heff_take(v_e_241, 7ULL);
    V v_t_2420 = (g_heff_2elift_2efreeGo(heff_dup(v_bound_240), v_a_2418, v_acc_242));
    V t_0 = heff_tag(TAG_Cons, 2, (V[]){v_x_2417, v_bound_240});
    V t_1 = v_b_2419;
    V t_2 = v_t_2420;
    v_bound_240 = t_0;
    v_e_241 = t_1;
    v_acc_242 = t_2;
    goto top;
  }
  case TAG_ERecord: {
    V v_fs_2421 = heff_field(v_e_241, 0);
    heff_take(v_e_241, 1ULL);
    return ({ V a_0 = heff_clo(g_heff_2elift_2efreeGo_lam1, 2, 1, (V[]){v_bound_240}); V a_1 = v_acc_242; V a_2 = v_fs_2421; V r_ = (g_prelude_2efoldl(a_0, a_1, a_2)); heff_drop(v_fs_2421); r_; });
  }
  case TAG_EProj: {
    V v_x_2427 = heff_field(v_e_241, 0);
    heff_take(v_e_241, 1ULL);
    V t_0 = v_bound_240;
    V t_1 = v_x_2427;
    V t_2 = v_acc_242;
    v_bound_240 = t_0;
    v_e_241 = t_1;
    v_acc_242 = t_2;
    goto top;
  }
  case TAG_ETag: {
    V v_es_2430 = heff_field(v_e_241, 1);
    heff_take(v_e_241, 2ULL);
    return ({ V a_0 = heff_clo(g_heff_2elift_2efreeGo_lam2, 2, 1, (V[]){v_bound_240}); V a_1 = v_acc_242; V a_2 = v_es_2430; V r_ = (g_prelude_2efoldl(a_0, a_1, a_2)); heff_drop(v_es_2430); r_; });
  }
  case TAG_EMatch: {
    V v_x_2433 = heff_field(v_e_241, 0);
    V v_arms_2434 = heff_field(v_e_241, 1);
    heff_take(v_e_241, 3ULL);
    V v_t_2435 = (g_heff_2elift_2efreeGo(heff_dup(v_bound_240), v_x_2433, v_acc_242));
    return ({ V a_0 = heff_clo(g_heff_2elift_2efreeGo_lam3, 2, 1, (V[]){v_bound_240}); V a_1 = v_t_2435; V a_2 = v_arms_2434; V r_ = (g_prelude_2efoldl(a_0, a_1, a_2)); heff_drop(v_arms_2434); r_; });
  }
  case TAG_EPrim: {
    heff_take(v_e_241, 0ULL);
    heff_drop(v_bound_240);
    return v_acc_242;
  }
  case TAG_EPrimCall: {
    V v_es_2449 = heff_field(v_e_241, 1);
    heff_take(v_e_241, 2ULL);
    return ({ V a_0 = heff_clo(g_heff_2elift_2efreeGo_lam4, 2, 1, (V[]){v_bound_240}); V a_1 = v_acc_242; V a_2 = v_es_2449; V r_ = (g_prelude_2efoldl(a_0, a_1, a_2)); heff_drop(v_es_2449); r_; });
  }
  case TAG_ECall: {
    V v_es_2453 = heff_field(v_e_241, 1);
    heff_take(v_e_241, 2ULL);
    return ({ V a_0 = heff_clo(g_heff_2elift_2efreeGo_lam5, 2, 1, (V[]){v_bound_240}); V a_1 = v_acc_242; V a_2 = v_es_2453; V r_ = (g_prelude_2efoldl(a_0, a_1, a_2)); heff_drop(v_es_2453); r_; });
  }
  case TAG_EInt: {
    heff_take(v_e_241, 0ULL);
    heff_drop(v_bound_240);
    return v_acc_242;
  }
  case TAG_EFloat: {
    heff_take(v_e_241, 0ULL);
    heff_drop(v_bound_240);
    return v_acc_242;
  }
  case TAG_EStr: {
    heff_take(v_e_241, 0ULL);
    heff_drop(v_bound_240);
    return v_acc_242;
  }
  case TAG_EAbandon: {
    heff_drop(v_bound_240);
    heff_drop(v_e_241);
    return v_acc_242;
  }
  case TAG_EFix: {
    V v_f_2459 = heff_field(v_e_241, 0);
    V v_b_2460 = heff_field(v_e_241, 1);
    V v_ru_24e_241_24EFix = heff_take_reuse(v_e_241, 3ULL);
    V t_0 = heff_tag_at(v_ru_24e_241_24EFix, TAG_Cons, 2, (V[]){v_f_2459, v_bound_240});
    V t_1 = v_b_2460;
    V t_2 = v_acc_242;
    v_bound_240 = t_0;
    v_e_241 = t_1;
    v_acc_242 = t_2;
    goto top;
  }
  default: return heff_nomatch(v_e_241);
  }
}
V g_heff_2elift_2efreeGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2elift_2efreeGo(a[0], a[1], a[2]);
}
V g_heff_2elift_2efreeGo_lam0(V self, V *args) {
  V v_a_2415 = args[0];
  V v_x_2416 = args[1];
  V v_bound_240 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  return (g_heff_2elift_2efreeGo(v_bound_240, v_x_2416, v_a_2415));
}
V g_heff_2elift_2efreeGo_lam1(V self, V *args) {
  V v_a_2422 = args[0];
  V v_f_2423 = args[1];
  V v_bound_240 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_t_2426;
  switch (heff_tag_of(v_f_2423)) {
  case TAG_MkPair: {
    V v_y_2425 = heff_field(v_f_2423, 1);
    heff_take(v_f_2423, 2ULL);
    v_t_2426 = v_y_2425;
    break;
  }
  default: heff_nomatch(v_f_2423);
  }
  return (g_heff_2elift_2efreeGo(v_bound_240, v_t_2426, v_a_2422));
}
V g_heff_2elift_2efreeGo_lam2(V self, V *args) {
  V v_a_2431 = args[0];
  V v_x_2432 = args[1];
  V v_bound_240 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  return (g_heff_2elift_2efreeGo(v_bound_240, v_x_2432, v_a_2431));
}
V g_heff_2elift_2efreeGo_lam3(V self, V *args) {
  V v_a_2436 = args[0];
  V v_arm_2437 = args[1];
  V v_bound_240 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  V v_t_2441;
  switch (heff_tag_of(v_arm_2437)) {
  case TAG_MkArm: {
    V v_vs_2439 = heff_dup(heff_field(v_arm_2437, 1));
    v_t_2441 = v_vs_2439;
    break;
  }
  default: heff_nomatch(v_arm_2437);
  }
  V v_t_2442 = (g_heff_2eir_2eappendI(v_t_2441, v_bound_240));
  V v_t_2446;
  switch (heff_tag_of(v_arm_2437)) {
  case TAG_MkArm: {
    V v_b_2445 = heff_field(v_arm_2437, 2);
    heff_take(v_arm_2437, 4ULL);
    v_t_2446 = v_b_2445;
    break;
  }
  default: heff_nomatch(v_arm_2437);
  }
  return (g_heff_2elift_2efreeGo(v_t_2442, v_t_2446, v_a_2436));
}
V g_heff_2elift_2efreeGo_lam4(V self, V *args) {
  V v_a_2450 = args[0];
  V v_x_2451 = args[1];
  V v_bound_240 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  return (g_heff_2elift_2efreeGo(v_bound_240, v_x_2451, v_a_2450));
}
V g_heff_2elift_2efreeGo_lam5(V self, V *args) {
  V v_a_2454 = args[0];
  V v_x_2455 = args[1];
  V v_bound_240 = heff_dup(heff_env(self)[0]);
  heff_drop(self);
  return (g_heff_2elift_2efreeGo(v_bound_240, v_x_2455, v_a_2454));
}
V g_heff_2elift_2ereplaceGo_lam0(V self, V *args);
V g_heff_2elift_2ereplaceGo_lam1(V self, V *args);
Clo g_heff_2elift_2ereplaceGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elift_2ereplaceGo_entry, 3, 0};

V g_heff_2elift_2ereplaceGo(V v_x_240, V v_r_241, V v_e_242) {
top: ;
  switch (heff_tag_of(v_e_242)) {
  case TAG_EVar: {
    V v_y_243 = heff_dup(heff_field(v_e_242, 0));
    V v_t_244 = heff_strEq(v_y_243, v_x_240);
    switch (heff_tag_of(v_t_244)) {
    case TAG_True: {
      heff_drop(v_e_242);
      heff_drop(v_t_244);
      return v_r_241;
    }
    case TAG_False: {
      heff_drop(v_r_241);
      heff_drop(v_t_244);
      return v_e_242;
    }
    default: return heff_nomatch(v_t_244);
    }
  }
  case TAG_EGlobal: {
    heff_drop(v_x_240);
    heff_drop(v_r_241);
    return v_e_242;
  }
  case TAG_ELam: {
    V v_xs_246 = heff_field(v_e_242, 0);
    V v_b_247 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24ELam = heff_take_reuse(v_e_242, 3ULL);
    return heff_tag_at(v_ru_24e_242_24ELam, TAG_ELam, 2, (V[]){v_xs_246, (g_heff_2elift_2ereplaceGo(v_x_240, v_r_241, v_b_247))});
  }
  case TAG_EApp: {
    V v_f_248 = heff_field(v_e_242, 0);
    V v_as_249 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24EApp = heff_take_reuse(v_e_242, 3ULL);
    V v_t_2410 = (g_heff_2elift_2ereplaceGo(heff_dup(v_x_240), heff_dup(v_r_241), v_f_248));
    V v_t_2411 = heff_tr(heff_apply(((V)&g_heff_2elift_2ereplaceGo_clo), 2, (V[]){v_x_240, v_r_241}));
    return heff_tag_at(v_ru_24e_242_24EApp, TAG_EApp, 2, (V[]){v_t_2410, (g_prelude_2emap(v_t_2411, v_as_249))});
  }
  case TAG_ELet: {
    V v_y_2412 = heff_field(v_e_242, 0);
    V v_a_2413 = heff_field(v_e_242, 1);
    V v_b_2414 = heff_field(v_e_242, 2);
    V v_ru_24e_242_24ELet = heff_take_reuse(v_e_242, 7ULL);
    V v_t_2415 = (g_heff_2elift_2ereplaceGo(heff_dup(v_x_240), heff_dup(v_r_241), v_a_2413));
    return heff_tag_at(v_ru_24e_242_24ELet, TAG_ELet, 3, (V[]){v_y_2412, v_t_2415, (g_heff_2elift_2ereplaceGo(v_x_240, v_r_241, v_b_2414))});
  }
  case TAG_ERecord: {
    V v_fs_2416 = heff_field(v_e_242, 0);
    V v_ru_24e_242_24ERecord = heff_take_reuse(v_e_242, 1ULL);
    return heff_tag_at(v_ru_24e_242_24ERecord, TAG_ERecord, 1, (V[]){(g_prelude_2emap(heff_clo(g_heff_2elift_2ereplaceGo_lam0, 1, 2, (V[]){v_x_240, v_r_241}), v_fs_2416))});
  }
  case TAG_EProj: {
    V v_y_2424 = heff_field(v_e_242, 0);
    V v_l_2425 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24EProj = heff_take_reuse(v_e_242, 3ULL);
    V v_t_2426 = (g_heff_2elift_2ereplaceGo(v_x_240, v_r_241, v_y_2424));
    return heff_tag_at(v_ru_24e_242_24EProj, TAG_EProj, 2, (V[]){v_t_2426, v_l_2425});
  }
  case TAG_ETag: {
    V v_t_2427 = heff_field(v_e_242, 0);
    V v_es_2428 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24ETag = heff_take_reuse(v_e_242, 3ULL);
    V v_t_2429 = heff_tr(heff_apply(((V)&g_heff_2elift_2ereplaceGo_clo), 2, (V[]){v_x_240, v_r_241}));
    return heff_tag_at(v_ru_24e_242_24ETag, TAG_ETag, 2, (V[]){v_t_2427, (g_prelude_2emap(v_t_2429, v_es_2428))});
  }
  case TAG_EMatch: {
    V v_y_2430 = heff_field(v_e_242, 0);
    V v_arms_2431 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24EMatch = heff_take_reuse(v_e_242, 3ULL);
    V v_t_2432 = (g_heff_2elift_2ereplaceGo(heff_dup(v_x_240), heff_dup(v_r_241), v_y_2430));
    return heff_tag_at(v_ru_24e_242_24EMatch, TAG_EMatch, 2, (V[]){v_t_2432, (g_prelude_2emap(heff_clo(g_heff_2elift_2ereplaceGo_lam1, 1, 2, (V[]){v_x_240, v_r_241}), v_arms_2431))});
  }
  case TAG_EPrim: {
    heff_drop(v_x_240);
    heff_drop(v_r_241);
    return v_e_242;
  }
  case TAG_EPrimCall: {
    V v_p_2447 = heff_field(v_e_242, 0);
    V v_es_2448 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24EPrimCall = heff_take_reuse(v_e_242, 3ULL);
    V v_t_2449 = heff_tr(heff_apply(((V)&g_heff_2elift_2ereplaceGo_clo), 2, (V[]){v_x_240, v_r_241}));
    return heff_tag_at(v_ru_24e_242_24EPrimCall, TAG_EPrimCall, 2, (V[]){v_p_2447, (g_prelude_2emap(v_t_2449, v_es_2448))});
  }
  case TAG_ECall: {
    V v_k_2450 = heff_field(v_e_242, 0);
    V v_es_2451 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24ECall = heff_take_reuse(v_e_242, 3ULL);
    V v_t_2452 = heff_tr(heff_apply(((V)&g_heff_2elift_2ereplaceGo_clo), 2, (V[]){v_x_240, v_r_241}));
    return heff_tag_at(v_ru_24e_242_24ECall, TAG_ECall, 2, (V[]){v_k_2450, (g_prelude_2emap(v_t_2452, v_es_2451))});
  }
  case TAG_EInt: {
    heff_drop(v_x_240);
    heff_drop(v_r_241);
    return v_e_242;
  }
  case TAG_EFloat: {
    heff_drop(v_x_240);
    heff_drop(v_r_241);
    return v_e_242;
  }
  case TAG_EStr: {
    heff_drop(v_x_240);
    heff_drop(v_r_241);
    return v_e_242;
  }
  case TAG_EAbandon: {
    heff_drop(v_x_240);
    heff_drop(v_r_241);
    return v_e_242;
  }
  case TAG_EFix: {
    V v_f_2456 = heff_field(v_e_242, 0);
    V v_b_2457 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24EFix = heff_take_reuse(v_e_242, 3ULL);
    return heff_tag_at(v_ru_24e_242_24EFix, TAG_EFix, 2, (V[]){v_f_2456, (g_heff_2elift_2ereplaceGo(v_x_240, v_r_241, v_b_2457))});
  }
  default: return heff_nomatch(v_e_242);
  }
}
V g_heff_2elift_2ereplaceGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2elift_2ereplaceGo(a[0], a[1], a[2]);
}
V g_heff_2elift_2ereplaceGo_lam0(V self, V *args) {
  V v_f_2417 = args[0];
  V v_x_240 = heff_dup(heff_env(self)[0]);
  V v_r_241 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  V v_t_2420;
  switch (heff_tag_of(v_f_2417)) {
  case TAG_MkPair: {
    V v_x_2418 = heff_dup(heff_field(v_f_2417, 0));
    v_t_2420 = v_x_2418;
    break;
  }
  default: heff_nomatch(v_f_2417);
  }
  V v_t_2423;
  switch (heff_tag_of(v_f_2417)) {
  case TAG_MkPair: {
    V v_y_2422 = heff_field(v_f_2417, 1);
    heff_take(v_f_2417, 2ULL);
    v_t_2423 = v_y_2422;
    break;
  }
  default: heff_nomatch(v_f_2417);
  }
  return heff_tag(TAG_MkPair, 2, (V[]){v_t_2420, (g_heff_2elift_2ereplaceGo(v_x_240, v_r_241, v_t_2423))});
}
V g_heff_2elift_2ereplaceGo_lam1(V self, V *args) {
  V v_arm_2433 = args[0];
  V v_x_240 = heff_dup(heff_env(self)[0]);
  V v_r_241 = heff_dup(heff_env(self)[1]);
  heff_drop(self);
  V v_t_2437;
  switch (heff_tag_of(v_arm_2433)) {
  case TAG_MkArm: {
    V v_t_2434 = heff_dup(heff_field(v_arm_2433, 0));
    v_t_2437 = v_t_2434;
    break;
  }
  default: heff_nomatch(v_arm_2433);
  }
  V v_t_2441;
  switch (heff_tag_of(v_arm_2433)) {
  case TAG_MkArm: {
    V v_vs_2439 = heff_dup(heff_field(v_arm_2433, 1));
    v_t_2441 = v_vs_2439;
    break;
  }
  default: heff_nomatch(v_arm_2433);
  }
  V v_t_2445;
  switch (heff_tag_of(v_arm_2433)) {
  case TAG_MkArm: {
    V v_b_2444 = heff_field(v_arm_2433, 2);
    heff_take(v_arm_2433, 4ULL);
    v_t_2445 = v_b_2444;
    break;
  }
  default: heff_nomatch(v_arm_2433);
  }
  return heff_tag(TAG_MkArm, 3, (V[]){v_t_2437, v_t_2441, (g_heff_2elift_2ereplaceGo(v_x_240, v_r_241, v_t_2445))});
}
Clo g_heff_2elift_2eliftMany_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elift_2eliftMany_entry, 4, 0};

V g_heff_2elift_2eliftMany(V v_k_240, V v_d_241, V v_acc_242, V v_x4_243) {
top: ;
  switch (heff_tag_of(v_x4_243)) {
  case TAG_Nil: {
    heff_drop(v_k_240);
    heff_drop(v_d_241);
    heff_drop(v_x4_243);
    return heff_tag(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_acc_242});
  }
  case TAG_Cons: {
    V v_x_244 = heff_field(v_x4_243, 0);
    V v_xs_245 = heff_field(v_x4_243, 1);
    V v_ru_24x4_243_24Cons = heff_take_reuse(v_x4_243, 3ULL);
    V v_t_246 = heff_tr(heff_apply(heff_get(heff_dup(v_k_240), LBL_go), 3, (V[]){heff_dup(v_d_241), v_acc_242, v_x_244}));
    switch (heff_tag_of(v_t_246)) {
    case TAG_MkPair: {
      V v_x2_247 = heff_field(v_t_246, 0);
      V v_acc2_248 = heff_field(v_t_246, 1);
      heff_take(v_t_246, 3ULL);
      V v_x2_249 = (g_heff_2elift_2eliftMany(v_k_240, v_d_241, v_acc2_248, v_xs_245));
      switch (heff_tag_of(v_x2_249)) {
      case TAG_MkPair: {
        V v_xs_2410 = heff_field(v_x2_249, 0);
        V v_acc_2411 = heff_field(v_x2_249, 1);
        heff_take(v_x2_249, 3ULL);
        return heff_tag_at(v_ru_24x4_243_24Cons, TAG_MkPair, 2, (V[]){heff_tag(TAG_Cons, 2, (V[]){v_x2_247, v_xs_2410}), v_acc_2411});
      }
      default: return heff_nomatch(v_x2_249);
      }
    }
    default: return heff_nomatch(v_t_246);
    }
  }
  default: return heff_nomatch(v_x4_243);
  }
}
V g_heff_2elift_2eliftMany_entry(V self, V *a) {
  (void)self;
  return g_heff_2elift_2eliftMany(a[0], a[1], a[2], a[3]);
}
Clo g_heff_2elift_2ewithParams_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elift_2ewithParams_entry, 2, 0};

V g_heff_2elift_2ewithParams(V v_fvs_240, V v_b_241) {
top: ;
  switch (heff_tag_of(v_fvs_240)) {
  case TAG_Nil: {
    heff_drop(v_fvs_240);
    return v_b_241;
  }
  case TAG_Cons: {
    switch (heff_tag_of(v_b_241)) {
    case TAG_EVar: {
      return heff_tag(TAG_ELam, 2, (V[]){v_fvs_240, v_b_241});
    }
    case TAG_EGlobal: {
      return heff_tag(TAG_ELam, 2, (V[]){v_fvs_240, v_b_241});
    }
    case TAG_ELam: {
      V v_xs_246 = heff_field(v_b_241, 0);
      V v_b2_247 = heff_field(v_b_241, 1);
      V v_ru_24b_241_24ELam = heff_take_reuse(v_b_241, 3ULL);
      V v_t_248 = (g_heff_2eir_2eappendI(v_fvs_240, v_xs_246));
      return heff_tag_at(v_ru_24b_241_24ELam, TAG_ELam, 2, (V[]){v_t_248, v_b2_247});
    }
    case TAG_EApp: {
      return heff_tag(TAG_ELam, 2, (V[]){v_fvs_240, v_b_241});
    }
    case TAG_ELet: {
      return heff_tag(TAG_ELam, 2, (V[]){v_fvs_240, v_b_241});
    }
    case TAG_ERecord: {
      return heff_tag(TAG_ELam, 2, (V[]){v_fvs_240, v_b_241});
    }
    case TAG_EProj: {
      return heff_tag(TAG_ELam, 2, (V[]){v_fvs_240, v_b_241});
    }
    case TAG_ETag: {
      return heff_tag(TAG_ELam, 2, (V[]){v_fvs_240, v_b_241});
    }
    case TAG_EMatch: {
      return heff_tag(TAG_ELam, 2, (V[]){v_fvs_240, v_b_241});
    }
    case TAG_EPrim: {
      return heff_tag(TAG_ELam, 2, (V[]){v_fvs_240, v_b_241});
    }
    case TAG_EPrimCall: {
      return heff_tag(TAG_ELam, 2, (V[]){v_fvs_240, v_b_241});
    }
    case TAG_ECall: {
      return heff_tag(TAG_ELam, 2, (V[]){v_fvs_240, v_b_241});
    }
    case TAG_EInt: {
      return heff_tag(TAG_ELam, 2, (V[]){v_fvs_240, v_b_241});
    }
    case TAG_EFloat: {
      return heff_tag(TAG_ELam, 2, (V[]){v_fvs_240, v_b_241});
    }
    case TAG_EStr: {
      return heff_tag(TAG_ELam, 2, (V[]){v_fvs_240, v_b_241});
    }
    case TAG_EAbandon: {
      return heff_tag(TAG_ELam, 2, (V[]){v_fvs_240, v_b_241});
    }
    case TAG_EFix: {
      return heff_tag(TAG_ELam, 2, (V[]){v_fvs_240, v_b_241});
    }
    default: return heff_nomatch(v_b_241);
    }
  }
  default: return heff_nomatch(v_fvs_240);
  }
}
V g_heff_2elift_2ewithParams_entry(V self, V *a) {
  (void)self;
  return g_heff_2elift_2ewithParams(a[0], a[1]);
}
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2elift_2eliftedDef_str0 = {{0x80000000u, K_STR, 0}, 1, 1, {46}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2elift_2eliftedDef_str1 = {{0x80000000u, K_STR, 0}, 1, 1, {36}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2elift_2eliftedDef_str2 = {{0x80000000u, K_STR, 0}, 1, 1, {46}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2elift_2eliftedDef_str3 = {{0x80000000u, K_STR, 0}, 1, 1, {46}};
static struct { Obj h; int64_t len; int64_t cap; uint16_t s[1]; } g_heff_2elift_2eliftedDef_str4 = {{0x80000000u, K_STR, 0}, 1, 1, {36}};
Clo g_heff_2elift_2eliftedDef_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elift_2eliftedDef_entry, 5, 0};

V g_heff_2elift_2eliftedDef(V v_d_240, V v_n_241, V v_f_242, V v_fvs_243, V v_body_244) {
top: ;
  V v_t_245 = (g_heff_2eir_2ebaseGo(heff_dup(v_f_242), MK_INT(0LL)));
  V v_key_246 = heff_strAppend(heff_get(heff_dup(v_d_240), LBL_key), heff_strAppend(((V)&g_heff_2elift_2eliftedDef_str0), heff_strAppend(v_t_245, heff_strAppend(((V)&g_heff_2elift_2eliftedDef_str1), heff_intShow(heff_dup(v_n_241))))));
  V v_name_247 = heff_strAppend(heff_get(heff_dup(v_d_240), LBL_name), heff_strAppend(((V)&g_heff_2elift_2eliftedDef_str2), (g_heff_2eir_2ebaseGo(heff_dup(v_f_242), MK_INT(0LL)))));
  V v_t_248 = (g_heff_2eir_2ebaseGo(heff_dup(v_f_242), MK_INT(0LL)));
  V v_key_249 = heff_strAppend(heff_get(v_d_240, LBL_key), heff_strAppend(((V)&g_heff_2elift_2eliftedDef_str3), heff_strAppend(v_t_248, heff_strAppend(((V)&g_heff_2elift_2eliftedDef_str4), heff_intShow(v_n_241)))));
  V v_t_2412;
  switch (heff_tag_of(v_fvs_243)) {
  case TAG_Nil: {
    v_t_2412 = heff_tag(TAG_EGlobal, 1, (V[]){v_key_249});
    break;
  }
  case TAG_Cons: {
    v_t_2412 = heff_tag(TAG_EApp, 2, (V[]){heff_tag(TAG_EGlobal, 1, (V[]){v_key_249}), (g_prelude_2emap_24s547(heff_dup(v_fvs_243)))});
    break;
  }
  default: heff_nomatch(v_fvs_243);
  }
  V v_t_2413 = (g_heff_2elift_2ereplaceGo(v_f_242, v_t_2412, v_body_244));
  V v_body_2414 = (g_heff_2elift_2ewithParams(v_fvs_243, v_t_2413));
  return heff_rec(3, shape_145_190_25, (V[]){v_key_246, v_name_247, v_body_2414});
}
V g_heff_2elift_2eliftedDef_entry(V self, V *a) {
  (void)self;
  return g_heff_2elift_2eliftedDef(a[0], a[1], a[2], a[3], a[4]);
}
Clo g_heff_2elift_2eliftFixDef_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elift_2eliftFixDef_entry, 4, 0};

V g_heff_2elift_2eliftFixDef(V v_k_240, V v_acc_241, V v_fvs_242, V v_ld_243) {
top: ;
  V v_t_244 = heff_intAdd(heff_get(heff_dup(v_acc_241), LBL_n), MK_INT(1LL));
  V v_t_245 = heff_rec(2, shape_214_189, (V[]){heff_get(v_acc_241, LBL_out), v_t_244});
  V v_t_246 = heff_tr(heff_apply(heff_get(v_k_240, LBL_go), 3, (V[]){heff_dup(v_ld_243), v_t_245, heff_get(heff_dup(v_ld_243), LBL_body)}));
  switch (heff_tag_of(v_t_246)) {
  case TAG_MkPair: {
    V v_b2_247 = heff_field(v_t_246, 0);
    V v_acc2_248 = heff_field(v_t_246, 1);
    V v_ru_24t_246_24MkPair = heff_take_reuse(v_t_246, 3ULL);
    V v_key_249 = heff_get(heff_dup(v_ld_243), LBL_key);
    V v_t_2412;
    switch (heff_tag_of(v_fvs_242)) {
    case TAG_Nil: {
      heff_drop(v_fvs_242);
      heff_drop(v_ru_24t_246_24MkPair);
      v_t_2412 = heff_tag(TAG_EGlobal, 1, (V[]){v_key_249});
      break;
    }
    case TAG_Cons: {
      v_t_2412 = heff_tag_at(v_ru_24t_246_24MkPair, TAG_EApp, 2, (V[]){heff_tag(TAG_EGlobal, 1, (V[]){v_key_249}), (g_prelude_2emap_24s547(v_fvs_242))});
      break;
    }
    default: heff_nomatch(v_fvs_242);
    }
    V v_t_2413 = heff_rec(3, shape_145_190_25, (V[]){heff_get(heff_dup(v_ld_243), LBL_key), heff_get(v_ld_243, LBL_name), v_b2_247});
    V v_t_2414 = heff_tag(TAG_Cons, 2, (V[]){v_t_2413, heff_get(heff_dup(v_acc2_248), LBL_out)});
    V v_t_2415 = heff_rec(2, shape_214_189, (V[]){v_t_2414, heff_get(v_acc2_248, LBL_n)});
    return heff_tag(TAG_MkPair, 2, (V[]){v_t_2412, v_t_2415});
  }
  default: return heff_nomatch(v_t_246);
  }
}
V g_heff_2elift_2eliftFixDef_entry(V self, V *a) {
  (void)self;
  return g_heff_2elift_2eliftFixDef(a[0], a[1], a[2], a[3]);
}
Clo g_heff_2elift_2eliftFix_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elift_2eliftFix_entry, 5, 0};

V g_heff_2elift_2eliftFix(V v_k_240, V v_d_241, V v_acc_242, V v_f_243, V v_body_244) {
top: ;
  V v_t_245 = heff_tag(TAG_Cons, 2, (V[]){heff_dup(v_f_243), NTAG(TAG_Nil)});
  V v_xs_246 = (g_heff_2elift_2efreeGo(v_t_245, heff_dup(v_body_244), NTAG(TAG_Nil)));
  V v_t_247 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), v_xs_246));
  V v_t_248 = heff_tag(TAG_Cons, 2, (V[]){heff_dup(v_f_243), NTAG(TAG_Nil)});
  V v_xs_249 = (g_heff_2elift_2efreeGo(v_t_248, heff_dup(v_body_244), NTAG(TAG_Nil)));
  V v_t_2410 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), v_xs_249));
  V v_t_2411 = (g_heff_2elift_2eliftedDef(v_d_241, heff_get(heff_dup(v_acc_242), LBL_n), v_f_243, v_t_2410, v_body_244));
  return (g_heff_2elift_2eliftFixDef(v_k_240, v_acc_242, v_t_247, v_t_2411));
}
V g_heff_2elift_2eliftFix_entry(V self, V *a) {
  (void)self;
  return g_heff_2elift_2eliftFix(a[0], a[1], a[2], a[3], a[4]);
}
Clo g_heff_2elift_2eoneParam_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elift_2eoneParam_entry, 1, 0};

V g_heff_2elift_2eoneParam(V v_e_240) {
top: ;
  switch (heff_tag_of(v_e_240)) {
  case TAG_EVar: {
    heff_take(v_e_240, 0ULL);
    return NTAG(TAG_Nothing);
  }
  case TAG_EGlobal: {
    heff_take(v_e_240, 0ULL);
    return NTAG(TAG_Nothing);
  }
  case TAG_ELam: {
    V v_xs_243 = heff_field(v_e_240, 0);
    V v_b_244 = heff_field(v_e_240, 1);
    V v_ru_24e_240_24ELam = heff_take_reuse(v_e_240, 3ULL);
    switch (heff_tag_of(v_xs_243)) {
    case TAG_Nil: {
      heff_drop(v_xs_243);
      heff_drop(v_b_244);
      heff_drop(v_ru_24e_240_24ELam);
      return NTAG(TAG_Nothing);
    }
    case TAG_Cons: {
      V v_x_245 = heff_field(v_xs_243, 0);
      V v_it2_246 = heff_field(v_xs_243, 1);
      heff_take(v_xs_243, 3ULL);
      switch (heff_tag_of(v_it2_246)) {
      case TAG_Nil: {
        heff_drop(v_it2_246);
        return heff_tag(TAG_Just, 1, (V[]){heff_tag_at(v_ru_24e_240_24ELam, TAG_MkPair, 2, (V[]){v_x_245, v_b_244})});
      }
      case TAG_Cons: {
        heff_take(v_it2_246, 0ULL);
        heff_drop(v_b_244);
        heff_drop(v_ru_24e_240_24ELam);
        heff_drop(v_x_245);
        return NTAG(TAG_Nothing);
      }
      default: return heff_nomatch(v_it2_246);
      }
    }
    default: return heff_nomatch(v_xs_243);
    }
  }
  case TAG_EApp: {
    heff_take(v_e_240, 0ULL);
    return NTAG(TAG_Nothing);
  }
  case TAG_ELet: {
    heff_take(v_e_240, 0ULL);
    return NTAG(TAG_Nothing);
  }
  case TAG_ERecord: {
    heff_take(v_e_240, 0ULL);
    return NTAG(TAG_Nothing);
  }
  case TAG_EProj: {
    heff_take(v_e_240, 0ULL);
    return NTAG(TAG_Nothing);
  }
  case TAG_ETag: {
    heff_take(v_e_240, 0ULL);
    return NTAG(TAG_Nothing);
  }
  case TAG_EMatch: {
    heff_take(v_e_240, 0ULL);
    return NTAG(TAG_Nothing);
  }
  case TAG_EPrim: {
    heff_take(v_e_240, 0ULL);
    return NTAG(TAG_Nothing);
  }
  case TAG_EPrimCall: {
    heff_take(v_e_240, 0ULL);
    return NTAG(TAG_Nothing);
  }
  case TAG_ECall: {
    heff_take(v_e_240, 0ULL);
    return NTAG(TAG_Nothing);
  }
  case TAG_EInt: {
    heff_take(v_e_240, 0ULL);
    return NTAG(TAG_Nothing);
  }
  case TAG_EFloat: {
    heff_take(v_e_240, 0ULL);
    return NTAG(TAG_Nothing);
  }
  case TAG_EStr: {
    heff_take(v_e_240, 0ULL);
    return NTAG(TAG_Nothing);
  }
  case TAG_EAbandon: {
    heff_drop(v_e_240);
    return NTAG(TAG_Nothing);
  }
  case TAG_EFix: {
    heff_take(v_e_240, 0ULL);
    return NTAG(TAG_Nothing);
  }
  default: return heff_nomatch(v_e_240);
  }
}
V g_heff_2elift_2eoneParam_entry(V self, V *a) {
  (void)self;
  return g_heff_2elift_2eoneParam(a[0]);
}
Clo g_heff_2elift_2eliftRedex_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elift_2eliftRedex_entry, 6, 0};

V g_heff_2elift_2eliftRedex(V v_k_240, V v_d_241, V v_acc_242, V v_x_243, V v_b_244, V v_a_245) {
top: ;
  V v_it_2432;
  switch (heff_tag_of(v_a_245)) {
  case TAG_EVar: {
    v_it_2432 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EGlobal: {
    v_it_2432 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_ELam: {
    v_it_2432 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EApp: {
    v_it_2432 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_ELet: {
    v_it_2432 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_ERecord: {
    v_it_2432 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EProj: {
    v_it_2432 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_ETag: {
    v_it_2432 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EMatch: {
    v_it_2432 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EPrim: {
    v_it_2432 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EPrimCall: {
    v_it_2432 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_ECall: {
    v_it_2432 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EInt: {
    v_it_2432 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EFloat: {
    v_it_2432 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EStr: {
    v_it_2432 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EAbandon: {
    v_it_2432 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EFix: {
    V v_f_2430 = heff_dup(heff_field(v_a_245, 0));
    V v_b_2431 = heff_dup(heff_field(v_a_245, 1));
    v_it_2432 = heff_tag(TAG_Just, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_f_2430, v_b_2431})});
    break;
  }
  default: heff_nomatch(v_a_245);
  }
  switch (heff_tag_of(v_it_2432)) {
  case TAG_Nothing: {
    heff_drop(v_it_2432);
    V v_t_2433 = heff_tag(TAG_Cons, 2, (V[]){heff_dup(v_x_243), NTAG(TAG_Nil)});
    V v_t_2434 = heff_tag(TAG_Cons, 2, (V[]){heff_dup(v_a_245), NTAG(TAG_Nil)});
    V v_t_2435 = heff_tag(TAG_Cons, 2, (V[]){heff_tag(TAG_ELam, 2, (V[]){v_t_2433, heff_dup(v_b_244)}), v_t_2434});
    V v_it_2436 = (g_heff_2elift_2eliftMany(v_k_240, v_d_241, v_acc_242, v_t_2435));
    switch (heff_tag_of(v_it_2436)) {
    case TAG_MkPair: {
      V v_it1_2437 = heff_field(v_it_2436, 0);
      V v_acc2_2438 = heff_field(v_it_2436, 1);
      V v_ru_24it_2436_24MkPair = heff_take_reuse(v_it_2436, 3ULL);
      switch (heff_tag_of(v_it1_2437)) {
      case TAG_Nil: {
        heff_drop(v_it1_2437);
        V v_t_2439 = heff_tag_at(v_ru_24it_2436_24MkPair, TAG_Cons, 2, (V[]){v_x_243, NTAG(TAG_Nil)});
        V v_t_2440 = heff_tag(TAG_Cons, 2, (V[]){v_a_245, NTAG(TAG_Nil)});
        V v_t_2441 = heff_tag(TAG_EApp, 2, (V[]){heff_tag(TAG_ELam, 2, (V[]){v_t_2439, v_b_244}), v_t_2440});
        return heff_tag(TAG_MkPair, 2, (V[]){v_t_2441, v_acc2_2438});
      }
      case TAG_Cons: {
        V v_f2_2442 = heff_field(v_it1_2437, 0);
        V v_as2_2443 = heff_field(v_it1_2437, 1);
        heff_take(v_it1_2437, 3ULL);
        heff_drop(v_x_243);
        heff_drop(v_b_244);
        heff_drop(v_a_245);
        return heff_tag_at(v_ru_24it_2436_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_EApp, 2, (V[]){v_f2_2442, v_as2_2443}), v_acc2_2438});
      }
      default: return heff_nomatch(v_it1_2437);
      }
    }
    default: return heff_nomatch(v_it_2436);
    }
  }
  case TAG_Just: {
    V v_it1_2444 = heff_field(v_it_2432, 0);
    heff_take(v_it_2432, 1ULL);
    heff_drop(v_a_245);
    switch (heff_tag_of(v_it1_2444)) {
    case TAG_MkPair: {
      V v_f_2445 = heff_field(v_it1_2444, 0);
      V v_fb_2446 = heff_field(v_it1_2444, 1);
      heff_take(v_it1_2444, 3ULL);
      V v_t_2447 = (g_heff_2elift_2eliftFix(heff_dup(v_k_240), heff_dup(v_d_241), v_acc_242, v_f_2445, v_fb_2446));
      switch (heff_tag_of(v_t_2447)) {
      case TAG_MkPair: {
        V v_call_2448 = heff_field(v_t_2447, 0);
        V v_acc2_2449 = heff_field(v_t_2447, 1);
        heff_take(v_t_2447, 3ULL);
        V v_t_2450 = (g_heff_2elift_2ereplaceGo(v_x_243, v_call_2448, v_b_244));
        return heff_tail(heff_get(v_k_240, LBL_go), 3, (V[]){v_d_241, v_acc2_2449, v_t_2450});
      }
      default: return heff_nomatch(v_t_2447);
      }
    }
    default: return heff_nomatch(v_it1_2444);
    }
  }
  default: return heff_nomatch(v_it_2432);
  }
}
V g_heff_2elift_2eliftRedex_entry(V self, V *a) {
  (void)self;
  return g_heff_2elift_2eliftRedex(a[0], a[1], a[2], a[3], a[4], a[5]);
}
Clo g_heff_2elift_2eliftApp_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elift_2eliftApp_entry, 5, 0};

V g_heff_2elift_2eliftApp(V v_k_240, V v_d_241, V v_acc_242, V v_f_243, V v_as_244) {
top: ;
  V v_it_245 = (g_heff_2elift_2eoneParam(heff_dup(v_f_243)));
  switch (heff_tag_of(v_it_245)) {
  case TAG_Nothing: {
    heff_drop(v_it_245);
    V v_it_246 = (g_heff_2elift_2eliftMany(v_k_240, v_d_241, v_acc_242, heff_tag(TAG_Cons, 2, (V[]){heff_dup(v_f_243), heff_dup(v_as_244)})));
    switch (heff_tag_of(v_it_246)) {
    case TAG_MkPair: {
      V v_it1_247 = heff_field(v_it_246, 0);
      V v_acc2_248 = heff_field(v_it_246, 1);
      V v_ru_24it_246_24MkPair = heff_take_reuse(v_it_246, 3ULL);
      switch (heff_tag_of(v_it1_247)) {
      case TAG_Nil: {
        heff_drop(v_it1_247);
        return heff_tag_at(v_ru_24it_246_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_EApp, 2, (V[]){v_f_243, v_as_244}), v_acc2_248});
      }
      case TAG_Cons: {
        V v_f2_249 = heff_field(v_it1_247, 0);
        V v_as2_2410 = heff_field(v_it1_247, 1);
        heff_take(v_it1_247, 3ULL);
        heff_drop(v_f_243);
        heff_drop(v_as_244);
        return heff_tag_at(v_ru_24it_246_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_EApp, 2, (V[]){v_f2_249, v_as2_2410}), v_acc2_248});
      }
      default: return heff_nomatch(v_it1_247);
      }
    }
    default: return heff_nomatch(v_it_246);
    }
  }
  case TAG_Just: {
    V v_it1_2411 = heff_field(v_it_245, 0);
    heff_take(v_it_245, 1ULL);
    switch (heff_tag_of(v_it1_2411)) {
    case TAG_MkPair: {
      V v_x_2412 = heff_field(v_it1_2411, 0);
      V v_b_2413 = heff_field(v_it1_2411, 1);
      V v_ru_24it1_2411_24MkPair = heff_take_reuse(v_it1_2411, 3ULL);
      switch (heff_tag_of(v_as_244)) {
      case TAG_Nil: {
        heff_drop(v_x_2412);
        heff_drop(v_b_2413);
        V v_it_2414 = (g_heff_2elift_2eliftMany(v_k_240, v_d_241, v_acc_242, heff_tag_at(v_ru_24it1_2411_24MkPair, TAG_Cons, 2, (V[]){heff_dup(v_f_243), heff_dup(v_as_244)})));
        switch (heff_tag_of(v_it_2414)) {
        case TAG_MkPair: {
          V v_it1_2415 = heff_field(v_it_2414, 0);
          V v_acc2_2416 = heff_field(v_it_2414, 1);
          V v_ru_24it_2414_24MkPair = heff_take_reuse(v_it_2414, 3ULL);
          switch (heff_tag_of(v_it1_2415)) {
          case TAG_Nil: {
            heff_drop(v_it1_2415);
            return heff_tag_at(v_ru_24it_2414_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_EApp, 2, (V[]){v_f_243, v_as_244}), v_acc2_2416});
          }
          case TAG_Cons: {
            V v_f2_2417 = heff_field(v_it1_2415, 0);
            V v_as2_2418 = heff_field(v_it1_2415, 1);
            heff_take(v_it1_2415, 3ULL);
            heff_drop(v_f_243);
            heff_drop(v_as_244);
            return heff_tag_at(v_ru_24it_2414_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_EApp, 2, (V[]){v_f2_2417, v_as2_2418}), v_acc2_2416});
          }
          default: return heff_nomatch(v_it1_2415);
          }
        }
        default: return heff_nomatch(v_it_2414);
        }
      }
      case TAG_Cons: {
        V v_a_2419 = heff_dup(heff_field(v_as_244, 0));
        V v_it2_2420 = heff_dup(heff_field(v_as_244, 1));
        switch (heff_tag_of(v_it2_2420)) {
        case TAG_Nil: {
          heff_drop(v_f_243);
          heff_drop(v_as_244);
          heff_drop(v_ru_24it1_2411_24MkPair);
          heff_drop(v_it2_2420);
          return (g_heff_2elift_2eliftRedex(v_k_240, v_d_241, v_acc_242, v_x_2412, v_b_2413, v_a_2419));
        }
        case TAG_Cons: {
          V v_ru_24it2_2420_24Cons = heff_take_reuse(v_it2_2420, 0ULL);
          heff_drop(v_x_2412);
          heff_drop(v_b_2413);
          heff_drop(v_a_2419);
          V v_it_2423 = (g_heff_2elift_2eliftMany(v_k_240, v_d_241, v_acc_242, heff_tag_at(v_ru_24it1_2411_24MkPair, TAG_Cons, 2, (V[]){heff_dup(v_f_243), heff_dup(v_as_244)})));
          switch (heff_tag_of(v_it_2423)) {
          case TAG_MkPair: {
            V v_it1_2424 = heff_field(v_it_2423, 0);
            V v_acc2_2425 = heff_field(v_it_2423, 1);
            heff_take(v_it_2423, 3ULL);
            switch (heff_tag_of(v_it1_2424)) {
            case TAG_Nil: {
              heff_drop(v_it1_2424);
              return heff_tag_at(v_ru_24it2_2420_24Cons, TAG_MkPair, 2, (V[]){heff_tag(TAG_EApp, 2, (V[]){v_f_243, v_as_244}), v_acc2_2425});
            }
            case TAG_Cons: {
              V v_f2_2426 = heff_field(v_it1_2424, 0);
              V v_as2_2427 = heff_field(v_it1_2424, 1);
              heff_take(v_it1_2424, 3ULL);
              heff_drop(v_f_243);
              heff_drop(v_as_244);
              return heff_tag_at(v_ru_24it2_2420_24Cons, TAG_MkPair, 2, (V[]){heff_tag(TAG_EApp, 2, (V[]){v_f2_2426, v_as2_2427}), v_acc2_2425});
            }
            default: return heff_nomatch(v_it1_2424);
            }
          }
          default: return heff_nomatch(v_it_2423);
          }
        }
        default: return heff_nomatch(v_it2_2420);
        }
      }
      default: return heff_nomatch(v_as_244);
      }
    }
    default: return heff_nomatch(v_it1_2411);
    }
  }
  default: return heff_nomatch(v_it_245);
  }
}
V g_heff_2elift_2eliftApp_entry(V self, V *a) {
  (void)self;
  return g_heff_2elift_2eliftApp(a[0], a[1], a[2], a[3], a[4]);
}
Clo g_heff_2elift_2eliftGo_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elift_2eliftGo_entry, 4, 0};

V g_heff_2elift_2eliftGo(V v_k_240, V v_d_241, V v_acc_242, V v_e_243) {
top: ;
  switch (heff_tag_of(v_e_243)) {
  case TAG_EVar: {
    heff_drop(v_k_240);
    heff_drop(v_d_241);
    return heff_tag(TAG_MkPair, 2, (V[]){v_e_243, v_acc_242});
  }
  case TAG_EGlobal: {
    heff_drop(v_k_240);
    heff_drop(v_d_241);
    return heff_tag(TAG_MkPair, 2, (V[]){v_e_243, v_acc_242});
  }
  case TAG_ELam: {
    V v_xs_246 = heff_field(v_e_243, 0);
    V v_b_247 = heff_field(v_e_243, 1);
    V v_ru_24e_243_24ELam = heff_take_reuse(v_e_243, 3ULL);
    V v_t_248 = heff_tr(heff_apply(heff_get(v_k_240, LBL_go), 3, (V[]){v_d_241, v_acc_242, v_b_247}));
    switch (heff_tag_of(v_t_248)) {
    case TAG_MkPair: {
      V v_b2_249 = heff_field(v_t_248, 0);
      V v_acc2_2410 = heff_field(v_t_248, 1);
      heff_take(v_t_248, 3ULL);
      return heff_tag_at(v_ru_24e_243_24ELam, TAG_MkPair, 2, (V[]){heff_tag(TAG_ELam, 2, (V[]){v_xs_246, v_b2_249}), v_acc2_2410});
    }
    default: return heff_nomatch(v_t_248);
    }
  }
  case TAG_EApp: {
    V v_f_2411 = heff_field(v_e_243, 0);
    V v_as_2412 = heff_field(v_e_243, 1);
    heff_take(v_e_243, 3ULL);
    return (g_heff_2elift_2eliftApp(v_k_240, v_d_241, v_acc_242, v_f_2411, v_as_2412));
  }
  case TAG_ELet: {
    V v_x_2413 = heff_dup(heff_field(v_e_243, 0));
    V v_a_2414 = heff_dup(heff_field(v_e_243, 1));
    V v_b_2415 = heff_dup(heff_field(v_e_243, 2));
    V v_t_2416 = heff_tag(TAG_Cons, 2, (V[]){v_b_2415, NTAG(TAG_Nil)});
    V v_it_2417 = (g_heff_2elift_2eliftMany(v_k_240, v_d_241, v_acc_242, heff_tag(TAG_Cons, 2, (V[]){v_a_2414, v_t_2416})));
    switch (heff_tag_of(v_it_2417)) {
    case TAG_MkPair: {
      V v_it1_2418 = heff_field(v_it_2417, 0);
      V v_acc2_2419 = heff_field(v_it_2417, 1);
      V v_ru_24it_2417_24MkPair = heff_take_reuse(v_it_2417, 3ULL);
      switch (heff_tag_of(v_it1_2418)) {
      case TAG_Nil: {
        heff_drop(v_x_2413);
        heff_drop(v_it1_2418);
        return heff_tag_at(v_ru_24it_2417_24MkPair, TAG_MkPair, 2, (V[]){v_e_243, v_acc2_2419});
      }
      case TAG_Cons: {
        V v_a2_2420 = heff_field(v_it1_2418, 0);
        V v_it12_2421 = heff_field(v_it1_2418, 1);
        heff_take(v_it1_2418, 3ULL);
        switch (heff_tag_of(v_it12_2421)) {
        case TAG_Nil: {
          heff_drop(v_x_2413);
          heff_drop(v_a2_2420);
          heff_drop(v_it12_2421);
          return heff_tag_at(v_ru_24it_2417_24MkPair, TAG_MkPair, 2, (V[]){v_e_243, v_acc2_2419});
        }
        case TAG_Cons: {
          V v_b2_2422 = heff_field(v_it12_2421, 0);
          V v_it122_2423 = heff_field(v_it12_2421, 1);
          heff_take(v_it12_2421, 3ULL);
          switch (heff_tag_of(v_it122_2423)) {
          case TAG_Nil: {
            heff_drop(v_e_243);
            heff_drop(v_it122_2423);
            return heff_tag_at(v_ru_24it_2417_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_ELet, 3, (V[]){v_x_2413, v_a2_2420, v_b2_2422}), v_acc2_2419});
          }
          case TAG_Cons: {
            heff_take(v_it122_2423, 0ULL);
            heff_drop(v_x_2413);
            heff_drop(v_a2_2420);
            heff_drop(v_b2_2422);
            return heff_tag_at(v_ru_24it_2417_24MkPair, TAG_MkPair, 2, (V[]){v_e_243, v_acc2_2419});
          }
          default: return heff_nomatch(v_it122_2423);
          }
        }
        default: return heff_nomatch(v_it12_2421);
        }
      }
      default: return heff_nomatch(v_it1_2418);
      }
    }
    default: return heff_nomatch(v_it_2417);
    }
  }
  case TAG_ERecord: {
    V v_fs_2426 = heff_field(v_e_243, 0);
    V v_ru_24e_243_24ERecord = heff_take_reuse(v_e_243, 1ULL);
    V v_t_2427 = (g_prelude_2emap_24s539(heff_dup(v_fs_2426)));
    V v_t_2428 = (g_heff_2elift_2eliftMany(v_k_240, v_d_241, v_acc_242, v_t_2427));
    switch (heff_tag_of(v_t_2428)) {
    case TAG_MkPair: {
      V v_es_2429 = heff_field(v_t_2428, 0);
      V v_acc2_2430 = heff_field(v_t_2428, 1);
      V v_ru_24t_2428_24MkPair = heff_take_reuse(v_t_2428, 3ULL);
      V v_fs2_2431 = (g_prelude_2ezipWith_24s556(v_fs_2426, v_es_2429));
      return heff_tag_at(v_ru_24t_2428_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at(v_ru_24e_243_24ERecord, TAG_ERecord, 1, (V[]){v_fs2_2431}), v_acc2_2430});
    }
    default: return heff_nomatch(v_t_2428);
    }
  }
  case TAG_EProj: {
    V v_x_2432 = heff_field(v_e_243, 0);
    V v_l_2433 = heff_field(v_e_243, 1);
    V v_ru_24e_243_24EProj = heff_take_reuse(v_e_243, 3ULL);
    V v_t_2434 = heff_tr(heff_apply(heff_get(v_k_240, LBL_go), 3, (V[]){v_d_241, v_acc_242, v_x_2432}));
    switch (heff_tag_of(v_t_2434)) {
    case TAG_MkPair: {
      V v_x2_2435 = heff_field(v_t_2434, 0);
      V v_acc2_2436 = heff_field(v_t_2434, 1);
      heff_take(v_t_2434, 3ULL);
      return heff_tag_at(v_ru_24e_243_24EProj, TAG_MkPair, 2, (V[]){heff_tag(TAG_EProj, 2, (V[]){v_x2_2435, v_l_2433}), v_acc2_2436});
    }
    default: return heff_nomatch(v_t_2434);
    }
  }
  case TAG_ETag: {
    V v_t_2437 = heff_field(v_e_243, 0);
    V v_es_2438 = heff_field(v_e_243, 1);
    V v_ru_24e_243_24ETag = heff_take_reuse(v_e_243, 3ULL);
    V v_t_2439 = (g_heff_2elift_2eliftMany(v_k_240, v_d_241, v_acc_242, v_es_2438));
    switch (heff_tag_of(v_t_2439)) {
    case TAG_MkPair: {
      V v_es2_2440 = heff_field(v_t_2439, 0);
      V v_acc2_2441 = heff_field(v_t_2439, 1);
      heff_take(v_t_2439, 3ULL);
      return heff_tag_at(v_ru_24e_243_24ETag, TAG_MkPair, 2, (V[]){heff_tag(TAG_ETag, 2, (V[]){v_t_2437, v_es2_2440}), v_acc2_2441});
    }
    default: return heff_nomatch(v_t_2439);
    }
  }
  case TAG_EMatch: {
    V v_x_2442 = heff_field(v_e_243, 0);
    V v_arms_2443 = heff_field(v_e_243, 1);
    V v_ru_24e_243_24EMatch = heff_take_reuse(v_e_243, 3ULL);
    V v_t_2444 = heff_tr(heff_apply(heff_get(heff_dup(v_k_240), LBL_go), 3, (V[]){heff_dup(v_d_241), v_acc_242, v_x_2442}));
    switch (heff_tag_of(v_t_2444)) {
    case TAG_MkPair: {
      V v_x2_2445 = heff_field(v_t_2444, 0);
      V v_acc2_2446 = heff_field(v_t_2444, 1);
      heff_take(v_t_2444, 3ULL);
      V v_t_2447 = (g_prelude_2emap_24s541(heff_dup(v_arms_2443)));
      V v_t_2448 = (g_heff_2elift_2eliftMany(v_k_240, v_d_241, v_acc2_2446, v_t_2447));
      switch (heff_tag_of(v_t_2448)) {
      case TAG_MkPair: {
        V v_bs_2449 = heff_field(v_t_2448, 0);
        V v_acc2_2450 = heff_field(v_t_2448, 1);
        heff_take(v_t_2448, 3ULL);
        V v_arms2_2451 = (g_prelude_2ezipWith_24s570(v_arms_2443, v_bs_2449));
        return heff_tag_at(v_ru_24e_243_24EMatch, TAG_MkPair, 2, (V[]){heff_tag(TAG_EMatch, 2, (V[]){v_x2_2445, v_arms2_2451}), v_acc2_2450});
      }
      default: return heff_nomatch(v_t_2448);
      }
    }
    default: return heff_nomatch(v_t_2444);
    }
  }
  case TAG_EPrim: {
    heff_drop(v_k_240);
    heff_drop(v_d_241);
    return heff_tag(TAG_MkPair, 2, (V[]){v_e_243, v_acc_242});
  }
  case TAG_EPrimCall: {
    V v_p_2453 = heff_field(v_e_243, 0);
    V v_es_2454 = heff_field(v_e_243, 1);
    V v_ru_24e_243_24EPrimCall = heff_take_reuse(v_e_243, 3ULL);
    V v_t_2455 = (g_heff_2elift_2eliftMany(v_k_240, v_d_241, v_acc_242, v_es_2454));
    switch (heff_tag_of(v_t_2455)) {
    case TAG_MkPair: {
      V v_es2_2456 = heff_field(v_t_2455, 0);
      V v_acc2_2457 = heff_field(v_t_2455, 1);
      heff_take(v_t_2455, 3ULL);
      return heff_tag_at(v_ru_24e_243_24EPrimCall, TAG_MkPair, 2, (V[]){heff_tag(TAG_EPrimCall, 2, (V[]){v_p_2453, v_es2_2456}), v_acc2_2457});
    }
    default: return heff_nomatch(v_t_2455);
    }
  }
  case TAG_ECall: {
    V v_c_2458 = heff_field(v_e_243, 0);
    V v_es_2459 = heff_field(v_e_243, 1);
    V v_ru_24e_243_24ECall = heff_take_reuse(v_e_243, 3ULL);
    V v_t_2460 = (g_heff_2elift_2eliftMany(v_k_240, v_d_241, v_acc_242, v_es_2459));
    switch (heff_tag_of(v_t_2460)) {
    case TAG_MkPair: {
      V v_es2_2461 = heff_field(v_t_2460, 0);
      V v_acc2_2462 = heff_field(v_t_2460, 1);
      heff_take(v_t_2460, 3ULL);
      return heff_tag_at(v_ru_24e_243_24ECall, TAG_MkPair, 2, (V[]){heff_tag(TAG_ECall, 2, (V[]){v_c_2458, v_es2_2461}), v_acc2_2462});
    }
    default: return heff_nomatch(v_t_2460);
    }
  }
  case TAG_EInt: {
    heff_drop(v_k_240);
    heff_drop(v_d_241);
    return heff_tag(TAG_MkPair, 2, (V[]){v_e_243, v_acc_242});
  }
  case TAG_EFloat: {
    heff_drop(v_k_240);
    heff_drop(v_d_241);
    return heff_tag(TAG_MkPair, 2, (V[]){v_e_243, v_acc_242});
  }
  case TAG_EStr: {
    heff_drop(v_k_240);
    heff_drop(v_d_241);
    return heff_tag(TAG_MkPair, 2, (V[]){v_e_243, v_acc_242});
  }
  case TAG_EAbandon: {
    heff_drop(v_k_240);
    heff_drop(v_d_241);
    return heff_tag(TAG_MkPair, 2, (V[]){v_e_243, v_acc_242});
  }
  case TAG_EFix: {
    V v_f_2466 = heff_field(v_e_243, 0);
    V v_b_2467 = heff_field(v_e_243, 1);
    heff_take(v_e_243, 3ULL);
    return (g_heff_2elift_2eliftFix(v_k_240, v_d_241, v_acc_242, v_f_2466, v_b_2467));
  }
  default: return heff_nomatch(v_e_243);
  }
}
V g_heff_2elift_2eliftGo_entry(V self, V *a) {
  (void)self;
  return g_heff_2elift_2eliftGo(a[0], a[1], a[2], a[3]);
}
V g_heff_2elift_2elk_lam0(V self, V *args); static Clo g_heff_2elift_2elk_lam0_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elift_2elk_lam0, 3, 0};

static V g_heff_2elift_2elk_val;
static int g_heff_2elift_2elk_st;
static V g_heff_2elift_2elk_init(void) {
  return heff_rec(1, shape_111, (V[]){((V)&g_heff_2elift_2elk_lam0_clo)});
}
V g_heff_2elift_2elk_get(void) {
  if (g_heff_2elift_2elk_st == 2) return g_heff_2elift_2elk_val;
  if (g_heff_2elift_2elk_st == 1) heff_fail("defined by itself");
  g_heff_2elift_2elk_st = 1;
  g_heff_2elift_2elk_val = heff_tr(g_heff_2elift_2elk_init());
  g_heff_2elift_2elk_st = 2;
  return g_heff_2elift_2elk_val;
}
V g_heff_2elift_2elk_lam0(V self, V *args) {
  V v_d_240 = args[0];
  V v_acc_241 = args[1];
  V v_e_242 = args[2];
  heff_drop(self);
  return (g_heff_2elift_2eliftGo(heff_dup(g_heff_2elift_2elk_get()), v_d_240, v_acc_241, v_e_242));
}
Clo g_heff_2elift_2eliftFixDef_24s578_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elift_2eliftFixDef_24s578_entry, 3, 0};

V g_heff_2elift_2eliftFixDef_24s578(V v_acc_240, V v_fvs_241, V v_ld_242) {
top: ;
  V v_t_243 = heff_intAdd(heff_get(heff_dup(v_acc_240), LBL_n), MK_INT(1LL));
  V v_t_244 = heff_rec(2, shape_214_189, (V[]){heff_get(v_acc_240, LBL_out), v_t_243});
  V v_t_245 = (g_heff_2elift_2eliftGo_24s574(heff_dup(v_ld_242), v_t_244, heff_get(heff_dup(v_ld_242), LBL_body)));
  switch (heff_tag_of(v_t_245)) {
  case TAG_MkPair: {
    V v_b2_246 = heff_field(v_t_245, 0);
    V v_acc2_247 = heff_field(v_t_245, 1);
    V v_ru_24t_245_24MkPair = heff_take_reuse(v_t_245, 3ULL);
    V v_key_248 = heff_get(heff_dup(v_ld_242), LBL_key);
    V v_t_2411;
    switch (heff_tag_of(v_fvs_241)) {
    case TAG_Nil: {
      heff_drop(v_fvs_241);
      heff_drop(v_ru_24t_245_24MkPair);
      v_t_2411 = heff_tag(TAG_EGlobal, 1, (V[]){v_key_248});
      break;
    }
    case TAG_Cons: {
      v_t_2411 = heff_tag_at(v_ru_24t_245_24MkPair, TAG_EApp, 2, (V[]){heff_tag(TAG_EGlobal, 1, (V[]){v_key_248}), (g_prelude_2emap_24s547(v_fvs_241))});
      break;
    }
    default: heff_nomatch(v_fvs_241);
    }
    V v_t_2412 = heff_rec(3, shape_145_190_25, (V[]){heff_get(heff_dup(v_ld_242), LBL_key), heff_get(v_ld_242, LBL_name), v_b2_246});
    V v_t_2413 = heff_tag(TAG_Cons, 2, (V[]){v_t_2412, heff_get(heff_dup(v_acc2_247), LBL_out)});
    V v_t_2414 = heff_rec(2, shape_214_189, (V[]){v_t_2413, heff_get(v_acc2_247, LBL_n)});
    return heff_tag(TAG_MkPair, 2, (V[]){v_t_2411, v_t_2414});
  }
  default: return heff_nomatch(v_t_245);
  }
}
V g_heff_2elift_2eliftFixDef_24s578_entry(V self, V *a) {
  (void)self;
  return g_heff_2elift_2eliftFixDef_24s578(a[0], a[1], a[2]);
}
Clo g_heff_2elift_2eliftFix_24s577_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elift_2eliftFix_24s577_entry, 4, 0};

V g_heff_2elift_2eliftFix_24s577(V v_d_240, V v_acc_241, V v_f_242, V v_body_243) {
top: ;
  V v_t_244 = heff_tag(TAG_Cons, 2, (V[]){heff_dup(v_f_242), NTAG(TAG_Nil)});
  V v_xs_245 = (g_heff_2elift_2efreeGo(v_t_244, heff_dup(v_body_243), NTAG(TAG_Nil)));
  V v_t_246 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), v_xs_245));
  V v_t_247 = heff_tag(TAG_Cons, 2, (V[]){heff_dup(v_f_242), NTAG(TAG_Nil)});
  V v_xs_248 = (g_heff_2elift_2efreeGo(v_t_247, heff_dup(v_body_243), NTAG(TAG_Nil)));
  V v_t_249 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), v_xs_248));
  V v_t_2410 = (g_heff_2elift_2eliftedDef(v_d_240, heff_get(heff_dup(v_acc_241), LBL_n), v_f_242, v_t_249, v_body_243));
  return (g_heff_2elift_2eliftFixDef_24s578(v_acc_241, v_t_246, v_t_2410));
}
V g_heff_2elift_2eliftFix_24s577_entry(V self, V *a) {
  (void)self;
  return g_heff_2elift_2eliftFix_24s577(a[0], a[1], a[2], a[3]);
}
Clo g_heff_2elift_2eliftRedex_24s576_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elift_2eliftRedex_24s576_entry, 5, 0};

V g_heff_2elift_2eliftRedex_24s576(V v_d_240, V v_acc_241, V v_x_242, V v_b_243, V v_a_244) {
top: ;
  V v_it_2431;
  switch (heff_tag_of(v_a_244)) {
  case TAG_EVar: {
    v_it_2431 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EGlobal: {
    v_it_2431 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_ELam: {
    v_it_2431 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EApp: {
    v_it_2431 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_ELet: {
    v_it_2431 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_ERecord: {
    v_it_2431 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EProj: {
    v_it_2431 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_ETag: {
    v_it_2431 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EMatch: {
    v_it_2431 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EPrim: {
    v_it_2431 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EPrimCall: {
    v_it_2431 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_ECall: {
    v_it_2431 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EInt: {
    v_it_2431 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EFloat: {
    v_it_2431 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EStr: {
    v_it_2431 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EAbandon: {
    v_it_2431 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EFix: {
    V v_f_2429 = heff_dup(heff_field(v_a_244, 0));
    V v_b_2430 = heff_dup(heff_field(v_a_244, 1));
    v_it_2431 = heff_tag(TAG_Just, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_f_2429, v_b_2430})});
    break;
  }
  default: heff_nomatch(v_a_244);
  }
  switch (heff_tag_of(v_it_2431)) {
  case TAG_Nothing: {
    heff_drop(v_it_2431);
    V v_t_2432 = heff_tag(TAG_Cons, 2, (V[]){heff_dup(v_x_242), NTAG(TAG_Nil)});
    V v_t_2433 = heff_tag(TAG_Cons, 2, (V[]){heff_dup(v_a_244), NTAG(TAG_Nil)});
    V v_t_2434 = heff_tag(TAG_Cons, 2, (V[]){heff_tag(TAG_ELam, 2, (V[]){v_t_2432, heff_dup(v_b_243)}), v_t_2433});
    V v_it_2435 = (g_heff_2elift_2eliftMany_24s573(v_d_240, v_acc_241, v_t_2434));
    switch (heff_tag_of(v_it_2435)) {
    case TAG_MkPair: {
      V v_it1_2436 = heff_field(v_it_2435, 0);
      V v_acc2_2437 = heff_field(v_it_2435, 1);
      V v_ru_24it_2435_24MkPair = heff_take_reuse(v_it_2435, 3ULL);
      switch (heff_tag_of(v_it1_2436)) {
      case TAG_Nil: {
        heff_drop(v_it1_2436);
        V v_t_2438 = heff_tag_at(v_ru_24it_2435_24MkPair, TAG_Cons, 2, (V[]){v_x_242, NTAG(TAG_Nil)});
        V v_t_2439 = heff_tag(TAG_Cons, 2, (V[]){v_a_244, NTAG(TAG_Nil)});
        V v_t_2440 = heff_tag(TAG_EApp, 2, (V[]){heff_tag(TAG_ELam, 2, (V[]){v_t_2438, v_b_243}), v_t_2439});
        return heff_tag(TAG_MkPair, 2, (V[]){v_t_2440, v_acc2_2437});
      }
      case TAG_Cons: {
        V v_f2_2441 = heff_field(v_it1_2436, 0);
        V v_as2_2442 = heff_field(v_it1_2436, 1);
        heff_take(v_it1_2436, 3ULL);
        heff_drop(v_x_242);
        heff_drop(v_b_243);
        heff_drop(v_a_244);
        return heff_tag_at(v_ru_24it_2435_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_EApp, 2, (V[]){v_f2_2441, v_as2_2442}), v_acc2_2437});
      }
      default: return heff_nomatch(v_it1_2436);
      }
    }
    default: return heff_nomatch(v_it_2435);
    }
  }
  case TAG_Just: {
    V v_it1_2443 = heff_field(v_it_2431, 0);
    heff_take(v_it_2431, 1ULL);
    heff_drop(v_a_244);
    switch (heff_tag_of(v_it1_2443)) {
    case TAG_MkPair: {
      V v_f_2444 = heff_field(v_it1_2443, 0);
      V v_fb_2445 = heff_field(v_it1_2443, 1);
      heff_take(v_it1_2443, 3ULL);
      V v_t_2446 = (g_heff_2elift_2eliftFix_24s577(heff_dup(v_d_240), v_acc_241, v_f_2444, v_fb_2445));
      switch (heff_tag_of(v_t_2446)) {
      case TAG_MkPair: {
        V v_call_2447 = heff_field(v_t_2446, 0);
        V v_acc2_2448 = heff_field(v_t_2446, 1);
        heff_take(v_t_2446, 3ULL);
        V v_e_2449 = (g_heff_2elift_2ereplaceGo(v_x_242, v_call_2447, v_b_243));
        return (g_heff_2elift_2eliftGo_24s574(v_d_240, v_acc2_2448, v_e_2449));
      }
      default: return heff_nomatch(v_t_2446);
      }
    }
    default: return heff_nomatch(v_it1_2443);
    }
  }
  default: return heff_nomatch(v_it_2431);
  }
}
V g_heff_2elift_2eliftRedex_24s576_entry(V self, V *a) {
  (void)self;
  return g_heff_2elift_2eliftRedex_24s576(a[0], a[1], a[2], a[3], a[4]);
}
Clo g_heff_2elift_2eliftApp_24s575_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elift_2eliftApp_24s575_entry, 4, 0};

V g_heff_2elift_2eliftApp_24s575(V v_d_240, V v_acc_241, V v_f_242, V v_as_243) {
top: ;
  V v_it_244 = (g_heff_2elift_2eoneParam(heff_dup(v_f_242)));
  switch (heff_tag_of(v_it_244)) {
  case TAG_Nothing: {
    heff_drop(v_it_244);
    V v_it_245 = (g_heff_2elift_2eliftMany_24s573(v_d_240, v_acc_241, heff_tag(TAG_Cons, 2, (V[]){heff_dup(v_f_242), heff_dup(v_as_243)})));
    switch (heff_tag_of(v_it_245)) {
    case TAG_MkPair: {
      V v_it1_246 = heff_field(v_it_245, 0);
      V v_acc2_247 = heff_field(v_it_245, 1);
      V v_ru_24it_245_24MkPair = heff_take_reuse(v_it_245, 3ULL);
      switch (heff_tag_of(v_it1_246)) {
      case TAG_Nil: {
        heff_drop(v_it1_246);
        return heff_tag_at(v_ru_24it_245_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_EApp, 2, (V[]){v_f_242, v_as_243}), v_acc2_247});
      }
      case TAG_Cons: {
        V v_f2_248 = heff_field(v_it1_246, 0);
        V v_as2_249 = heff_field(v_it1_246, 1);
        heff_take(v_it1_246, 3ULL);
        heff_drop(v_f_242);
        heff_drop(v_as_243);
        return heff_tag_at(v_ru_24it_245_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_EApp, 2, (V[]){v_f2_248, v_as2_249}), v_acc2_247});
      }
      default: return heff_nomatch(v_it1_246);
      }
    }
    default: return heff_nomatch(v_it_245);
    }
  }
  case TAG_Just: {
    V v_it1_2410 = heff_field(v_it_244, 0);
    heff_take(v_it_244, 1ULL);
    switch (heff_tag_of(v_it1_2410)) {
    case TAG_MkPair: {
      V v_x_2411 = heff_field(v_it1_2410, 0);
      V v_b_2412 = heff_field(v_it1_2410, 1);
      V v_ru_24it1_2410_24MkPair = heff_take_reuse(v_it1_2410, 3ULL);
      switch (heff_tag_of(v_as_243)) {
      case TAG_Nil: {
        heff_drop(v_x_2411);
        heff_drop(v_b_2412);
        V v_it_2413 = (g_heff_2elift_2eliftMany_24s573(v_d_240, v_acc_241, heff_tag_at(v_ru_24it1_2410_24MkPair, TAG_Cons, 2, (V[]){heff_dup(v_f_242), heff_dup(v_as_243)})));
        switch (heff_tag_of(v_it_2413)) {
        case TAG_MkPair: {
          V v_it1_2414 = heff_field(v_it_2413, 0);
          V v_acc2_2415 = heff_field(v_it_2413, 1);
          V v_ru_24it_2413_24MkPair = heff_take_reuse(v_it_2413, 3ULL);
          switch (heff_tag_of(v_it1_2414)) {
          case TAG_Nil: {
            heff_drop(v_it1_2414);
            return heff_tag_at(v_ru_24it_2413_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_EApp, 2, (V[]){v_f_242, v_as_243}), v_acc2_2415});
          }
          case TAG_Cons: {
            V v_f2_2416 = heff_field(v_it1_2414, 0);
            V v_as2_2417 = heff_field(v_it1_2414, 1);
            heff_take(v_it1_2414, 3ULL);
            heff_drop(v_f_242);
            heff_drop(v_as_243);
            return heff_tag_at(v_ru_24it_2413_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_EApp, 2, (V[]){v_f2_2416, v_as2_2417}), v_acc2_2415});
          }
          default: return heff_nomatch(v_it1_2414);
          }
        }
        default: return heff_nomatch(v_it_2413);
        }
      }
      case TAG_Cons: {
        V v_a_2418 = heff_dup(heff_field(v_as_243, 0));
        V v_it2_2419 = heff_dup(heff_field(v_as_243, 1));
        switch (heff_tag_of(v_it2_2419)) {
        case TAG_Nil: {
          heff_drop(v_f_242);
          heff_drop(v_as_243);
          heff_drop(v_ru_24it1_2410_24MkPair);
          heff_drop(v_it2_2419);
          return (g_heff_2elift_2eliftRedex_24s576(v_d_240, v_acc_241, v_x_2411, v_b_2412, v_a_2418));
        }
        case TAG_Cons: {
          V v_ru_24it2_2419_24Cons = heff_take_reuse(v_it2_2419, 0ULL);
          heff_drop(v_x_2411);
          heff_drop(v_b_2412);
          heff_drop(v_a_2418);
          V v_it_2422 = (g_heff_2elift_2eliftMany_24s573(v_d_240, v_acc_241, heff_tag_at(v_ru_24it1_2410_24MkPair, TAG_Cons, 2, (V[]){heff_dup(v_f_242), heff_dup(v_as_243)})));
          switch (heff_tag_of(v_it_2422)) {
          case TAG_MkPair: {
            V v_it1_2423 = heff_field(v_it_2422, 0);
            V v_acc2_2424 = heff_field(v_it_2422, 1);
            heff_take(v_it_2422, 3ULL);
            switch (heff_tag_of(v_it1_2423)) {
            case TAG_Nil: {
              heff_drop(v_it1_2423);
              return heff_tag_at(v_ru_24it2_2419_24Cons, TAG_MkPair, 2, (V[]){heff_tag(TAG_EApp, 2, (V[]){v_f_242, v_as_243}), v_acc2_2424});
            }
            case TAG_Cons: {
              V v_f2_2425 = heff_field(v_it1_2423, 0);
              V v_as2_2426 = heff_field(v_it1_2423, 1);
              heff_take(v_it1_2423, 3ULL);
              heff_drop(v_f_242);
              heff_drop(v_as_243);
              return heff_tag_at(v_ru_24it2_2419_24Cons, TAG_MkPair, 2, (V[]){heff_tag(TAG_EApp, 2, (V[]){v_f2_2425, v_as2_2426}), v_acc2_2424});
            }
            default: return heff_nomatch(v_it1_2423);
            }
          }
          default: return heff_nomatch(v_it_2422);
          }
        }
        default: return heff_nomatch(v_it2_2419);
        }
      }
      default: return heff_nomatch(v_as_243);
      }
    }
    default: return heff_nomatch(v_it1_2410);
    }
  }
  default: return heff_nomatch(v_it_244);
  }
}
V g_heff_2elift_2eliftApp_24s575_entry(V self, V *a) {
  (void)self;
  return g_heff_2elift_2eliftApp_24s575(a[0], a[1], a[2], a[3]);
}
Clo g_heff_2elift_2eliftGo_24s574_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elift_2eliftGo_24s574_entry, 3, 0};

V g_heff_2elift_2eliftGo_24s574(V v_d_240, V v_acc_241, V v_e_242) {
top: ;
  switch (heff_tag_of(v_e_242)) {
  case TAG_EVar: {
    heff_drop(v_d_240);
    return heff_tag(TAG_MkPair, 2, (V[]){v_e_242, v_acc_241});
  }
  case TAG_EGlobal: {
    heff_drop(v_d_240);
    return heff_tag(TAG_MkPair, 2, (V[]){v_e_242, v_acc_241});
  }
  case TAG_ELam: {
    V v_xs_245 = heff_field(v_e_242, 0);
    V v_b_246 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24ELam = heff_take_reuse(v_e_242, 3ULL);
    V v_t_247 = (g_heff_2elift_2eliftGo_24s574(v_d_240, v_acc_241, v_b_246));
    switch (heff_tag_of(v_t_247)) {
    case TAG_MkPair: {
      V v_b2_248 = heff_field(v_t_247, 0);
      V v_acc2_249 = heff_field(v_t_247, 1);
      heff_take(v_t_247, 3ULL);
      return heff_tag_at(v_ru_24e_242_24ELam, TAG_MkPair, 2, (V[]){heff_tag(TAG_ELam, 2, (V[]){v_xs_245, v_b2_248}), v_acc2_249});
    }
    default: return heff_nomatch(v_t_247);
    }
  }
  case TAG_EApp: {
    V v_f_2410 = heff_field(v_e_242, 0);
    V v_as_2411 = heff_field(v_e_242, 1);
    heff_take(v_e_242, 3ULL);
    return (g_heff_2elift_2eliftApp_24s575(v_d_240, v_acc_241, v_f_2410, v_as_2411));
  }
  case TAG_ELet: {
    V v_x_2412 = heff_dup(heff_field(v_e_242, 0));
    V v_a_2413 = heff_dup(heff_field(v_e_242, 1));
    V v_b_2414 = heff_dup(heff_field(v_e_242, 2));
    V v_t_2415 = heff_tag(TAG_Cons, 2, (V[]){v_b_2414, NTAG(TAG_Nil)});
    V v_it_2416 = (g_heff_2elift_2eliftMany_24s573(v_d_240, v_acc_241, heff_tag(TAG_Cons, 2, (V[]){v_a_2413, v_t_2415})));
    switch (heff_tag_of(v_it_2416)) {
    case TAG_MkPair: {
      V v_it1_2417 = heff_field(v_it_2416, 0);
      V v_acc2_2418 = heff_field(v_it_2416, 1);
      V v_ru_24it_2416_24MkPair = heff_take_reuse(v_it_2416, 3ULL);
      switch (heff_tag_of(v_it1_2417)) {
      case TAG_Nil: {
        heff_drop(v_x_2412);
        heff_drop(v_it1_2417);
        return heff_tag_at(v_ru_24it_2416_24MkPair, TAG_MkPair, 2, (V[]){v_e_242, v_acc2_2418});
      }
      case TAG_Cons: {
        V v_a2_2419 = heff_field(v_it1_2417, 0);
        V v_it12_2420 = heff_field(v_it1_2417, 1);
        heff_take(v_it1_2417, 3ULL);
        switch (heff_tag_of(v_it12_2420)) {
        case TAG_Nil: {
          heff_drop(v_x_2412);
          heff_drop(v_a2_2419);
          heff_drop(v_it12_2420);
          return heff_tag_at(v_ru_24it_2416_24MkPair, TAG_MkPair, 2, (V[]){v_e_242, v_acc2_2418});
        }
        case TAG_Cons: {
          V v_b2_2421 = heff_field(v_it12_2420, 0);
          V v_it122_2422 = heff_field(v_it12_2420, 1);
          heff_take(v_it12_2420, 3ULL);
          switch (heff_tag_of(v_it122_2422)) {
          case TAG_Nil: {
            heff_drop(v_e_242);
            heff_drop(v_it122_2422);
            return heff_tag_at(v_ru_24it_2416_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_ELet, 3, (V[]){v_x_2412, v_a2_2419, v_b2_2421}), v_acc2_2418});
          }
          case TAG_Cons: {
            heff_take(v_it122_2422, 0ULL);
            heff_drop(v_x_2412);
            heff_drop(v_a2_2419);
            heff_drop(v_b2_2421);
            return heff_tag_at(v_ru_24it_2416_24MkPair, TAG_MkPair, 2, (V[]){v_e_242, v_acc2_2418});
          }
          default: return heff_nomatch(v_it122_2422);
          }
        }
        default: return heff_nomatch(v_it12_2420);
        }
      }
      default: return heff_nomatch(v_it1_2417);
      }
    }
    default: return heff_nomatch(v_it_2416);
    }
  }
  case TAG_ERecord: {
    V v_fs_2425 = heff_field(v_e_242, 0);
    V v_ru_24e_242_24ERecord = heff_take_reuse(v_e_242, 1ULL);
    V v_t_2426 = (g_prelude_2emap_24s539(heff_dup(v_fs_2425)));
    V v_t_2427 = (g_heff_2elift_2eliftMany_24s573(v_d_240, v_acc_241, v_t_2426));
    switch (heff_tag_of(v_t_2427)) {
    case TAG_MkPair: {
      V v_es_2428 = heff_field(v_t_2427, 0);
      V v_acc2_2429 = heff_field(v_t_2427, 1);
      V v_ru_24t_2427_24MkPair = heff_take_reuse(v_t_2427, 3ULL);
      V v_fs2_2430 = (g_prelude_2ezipWith_24s556(v_fs_2425, v_es_2428));
      return heff_tag_at(v_ru_24t_2427_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at(v_ru_24e_242_24ERecord, TAG_ERecord, 1, (V[]){v_fs2_2430}), v_acc2_2429});
    }
    default: return heff_nomatch(v_t_2427);
    }
  }
  case TAG_EProj: {
    V v_x_2431 = heff_field(v_e_242, 0);
    V v_l_2432 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24EProj = heff_take_reuse(v_e_242, 3ULL);
    V v_t_2433 = (g_heff_2elift_2eliftGo_24s574(v_d_240, v_acc_241, v_x_2431));
    switch (heff_tag_of(v_t_2433)) {
    case TAG_MkPair: {
      V v_x2_2434 = heff_field(v_t_2433, 0);
      V v_acc2_2435 = heff_field(v_t_2433, 1);
      heff_take(v_t_2433, 3ULL);
      return heff_tag_at(v_ru_24e_242_24EProj, TAG_MkPair, 2, (V[]){heff_tag(TAG_EProj, 2, (V[]){v_x2_2434, v_l_2432}), v_acc2_2435});
    }
    default: return heff_nomatch(v_t_2433);
    }
  }
  case TAG_ETag: {
    V v_t_2436 = heff_field(v_e_242, 0);
    V v_es_2437 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24ETag = heff_take_reuse(v_e_242, 3ULL);
    V v_t_2438 = (g_heff_2elift_2eliftMany_24s573(v_d_240, v_acc_241, v_es_2437));
    switch (heff_tag_of(v_t_2438)) {
    case TAG_MkPair: {
      V v_es2_2439 = heff_field(v_t_2438, 0);
      V v_acc2_2440 = heff_field(v_t_2438, 1);
      heff_take(v_t_2438, 3ULL);
      return heff_tag_at(v_ru_24e_242_24ETag, TAG_MkPair, 2, (V[]){heff_tag(TAG_ETag, 2, (V[]){v_t_2436, v_es2_2439}), v_acc2_2440});
    }
    default: return heff_nomatch(v_t_2438);
    }
  }
  case TAG_EMatch: {
    V v_x_2441 = heff_field(v_e_242, 0);
    V v_arms_2442 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24EMatch = heff_take_reuse(v_e_242, 3ULL);
    V v_t_2443 = (g_heff_2elift_2eliftGo_24s574(heff_dup(v_d_240), v_acc_241, v_x_2441));
    switch (heff_tag_of(v_t_2443)) {
    case TAG_MkPair: {
      V v_x2_2444 = heff_field(v_t_2443, 0);
      V v_acc2_2445 = heff_field(v_t_2443, 1);
      heff_take(v_t_2443, 3ULL);
      V v_t_2446 = (g_prelude_2emap_24s541(heff_dup(v_arms_2442)));
      V v_t_2447 = (g_heff_2elift_2eliftMany_24s573(v_d_240, v_acc2_2445, v_t_2446));
      switch (heff_tag_of(v_t_2447)) {
      case TAG_MkPair: {
        V v_bs_2448 = heff_field(v_t_2447, 0);
        V v_acc2_2449 = heff_field(v_t_2447, 1);
        heff_take(v_t_2447, 3ULL);
        V v_arms2_2450 = (g_prelude_2ezipWith_24s570(v_arms_2442, v_bs_2448));
        return heff_tag_at(v_ru_24e_242_24EMatch, TAG_MkPair, 2, (V[]){heff_tag(TAG_EMatch, 2, (V[]){v_x2_2444, v_arms2_2450}), v_acc2_2449});
      }
      default: return heff_nomatch(v_t_2447);
      }
    }
    default: return heff_nomatch(v_t_2443);
    }
  }
  case TAG_EPrim: {
    heff_drop(v_d_240);
    return heff_tag(TAG_MkPair, 2, (V[]){v_e_242, v_acc_241});
  }
  case TAG_EPrimCall: {
    V v_p_2452 = heff_field(v_e_242, 0);
    V v_es_2453 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24EPrimCall = heff_take_reuse(v_e_242, 3ULL);
    V v_t_2454 = (g_heff_2elift_2eliftMany_24s573(v_d_240, v_acc_241, v_es_2453));
    switch (heff_tag_of(v_t_2454)) {
    case TAG_MkPair: {
      V v_es2_2455 = heff_field(v_t_2454, 0);
      V v_acc2_2456 = heff_field(v_t_2454, 1);
      heff_take(v_t_2454, 3ULL);
      return heff_tag_at(v_ru_24e_242_24EPrimCall, TAG_MkPair, 2, (V[]){heff_tag(TAG_EPrimCall, 2, (V[]){v_p_2452, v_es2_2455}), v_acc2_2456});
    }
    default: return heff_nomatch(v_t_2454);
    }
  }
  case TAG_ECall: {
    V v_c_2457 = heff_field(v_e_242, 0);
    V v_es_2458 = heff_field(v_e_242, 1);
    V v_ru_24e_242_24ECall = heff_take_reuse(v_e_242, 3ULL);
    V v_t_2459 = (g_heff_2elift_2eliftMany_24s573(v_d_240, v_acc_241, v_es_2458));
    switch (heff_tag_of(v_t_2459)) {
    case TAG_MkPair: {
      V v_es2_2460 = heff_field(v_t_2459, 0);
      V v_acc2_2461 = heff_field(v_t_2459, 1);
      heff_take(v_t_2459, 3ULL);
      return heff_tag_at(v_ru_24e_242_24ECall, TAG_MkPair, 2, (V[]){heff_tag(TAG_ECall, 2, (V[]){v_c_2457, v_es2_2460}), v_acc2_2461});
    }
    default: return heff_nomatch(v_t_2459);
    }
  }
  case TAG_EInt: {
    heff_drop(v_d_240);
    return heff_tag(TAG_MkPair, 2, (V[]){v_e_242, v_acc_241});
  }
  case TAG_EFloat: {
    heff_drop(v_d_240);
    return heff_tag(TAG_MkPair, 2, (V[]){v_e_242, v_acc_241});
  }
  case TAG_EStr: {
    heff_drop(v_d_240);
    return heff_tag(TAG_MkPair, 2, (V[]){v_e_242, v_acc_241});
  }
  case TAG_EAbandon: {
    heff_drop(v_d_240);
    return heff_tag(TAG_MkPair, 2, (V[]){v_e_242, v_acc_241});
  }
  case TAG_EFix: {
    V v_f_2465 = heff_field(v_e_242, 0);
    V v_b_2466 = heff_field(v_e_242, 1);
    heff_take(v_e_242, 3ULL);
    return (g_heff_2elift_2eliftFix_24s577(v_d_240, v_acc_241, v_f_2465, v_b_2466));
  }
  default: return heff_nomatch(v_e_242);
  }
}
V g_heff_2elift_2eliftGo_24s574_entry(V self, V *a) {
  (void)self;
  return g_heff_2elift_2eliftGo_24s574(a[0], a[1], a[2]);
}
Clo g_heff_2elift_2eliftMany_24s573_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elift_2eliftMany_24s573_entry, 3, 0};

V g_heff_2elift_2eliftMany_24s573(V v_d_240, V v_acc_241, V v_x4_242) {
top: ;
  switch (heff_tag_of(v_x4_242)) {
  case TAG_Nil: {
    heff_drop(v_d_240);
    heff_drop(v_x4_242);
    return heff_tag(TAG_MkPair, 2, (V[]){NTAG(TAG_Nil), v_acc_241});
  }
  case TAG_Cons: {
    V v_x_243 = heff_field(v_x4_242, 0);
    V v_xs_244 = heff_field(v_x4_242, 1);
    V v_ru_24x4_242_24Cons = heff_take_reuse(v_x4_242, 3ULL);
    V v_t_245 = (g_heff_2elift_2eliftGo_24s574(heff_dup(v_d_240), v_acc_241, v_x_243));
    switch (heff_tag_of(v_t_245)) {
    case TAG_MkPair: {
      V v_x2_246 = heff_field(v_t_245, 0);
      V v_acc2_247 = heff_field(v_t_245, 1);
      heff_take(v_t_245, 3ULL);
      V v_x2_248 = (g_heff_2elift_2eliftMany_24s573(v_d_240, v_acc2_247, v_xs_244));
      switch (heff_tag_of(v_x2_248)) {
      case TAG_MkPair: {
        V v_xs_249 = heff_field(v_x2_248, 0);
        V v_acc_2410 = heff_field(v_x2_248, 1);
        heff_take(v_x2_248, 3ULL);
        return heff_tag_at(v_ru_24x4_242_24Cons, TAG_MkPair, 2, (V[]){heff_tag(TAG_Cons, 2, (V[]){v_x2_246, v_xs_249}), v_acc_2410});
      }
      default: return heff_nomatch(v_x2_248);
      }
    }
    default: return heff_nomatch(v_t_245);
    }
  }
  default: return heff_nomatch(v_x4_242);
  }
}
V g_heff_2elift_2eliftMany_24s573_entry(V self, V *a) {
  (void)self;
  return g_heff_2elift_2eliftMany_24s573(a[0], a[1], a[2]);
}
Clo g_heff_2elift_2eliftGo_24s592_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elift_2eliftGo_24s592_entry, 2, 0};

V g_heff_2elift_2eliftGo_24s592(V v_d_240, V v_e_241) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_EVar: {
    heff_drop(v_d_240);
    V v_t_243 = heff_rec(2, shape_214_189, (V[]){NTAG(TAG_Nil), MK_INT(3LL)});
    return heff_tag(TAG_MkPair, 2, (V[]){v_e_241, v_t_243});
  }
  case TAG_EGlobal: {
    heff_drop(v_d_240);
    V v_t_245 = heff_rec(2, shape_214_189, (V[]){NTAG(TAG_Nil), MK_INT(3LL)});
    return heff_tag(TAG_MkPair, 2, (V[]){v_e_241, v_t_245});
  }
  case TAG_ELam: {
    V v_xs_246 = heff_field(v_e_241, 0);
    V v_b_247 = heff_field(v_e_241, 1);
    V v_ru_24e_241_24ELam = heff_take_reuse(v_e_241, 3ULL);
    V v_t_248 = heff_rec(2, shape_214_189, (V[]){NTAG(TAG_Nil), MK_INT(3LL)});
    V v_t_249 = heff_tr(g_heff_2elift_2eliftGo(heff_dup(g_heff_2elift_2elk_get()), v_d_240, v_t_248, v_b_247));
    switch (heff_tag_of(v_t_249)) {
    case TAG_MkPair: {
      V v_b2_2410 = heff_field(v_t_249, 0);
      V v_acc2_2411 = heff_field(v_t_249, 1);
      heff_take(v_t_249, 3ULL);
      return heff_tag_at(v_ru_24e_241_24ELam, TAG_MkPair, 2, (V[]){heff_tag(TAG_ELam, 2, (V[]){v_xs_246, v_b2_2410}), v_acc2_2411});
    }
    default: return heff_nomatch(v_t_249);
    }
  }
  case TAG_EApp: {
    V v_f_2412 = heff_field(v_e_241, 0);
    V v_as_2413 = heff_field(v_e_241, 1);
    heff_take(v_e_241, 3ULL);
    V v_t_2414 = heff_rec(2, shape_214_189, (V[]){NTAG(TAG_Nil), MK_INT(3LL)});
    return (g_heff_2elift_2eliftApp(heff_dup(g_heff_2elift_2elk_get()), v_d_240, v_t_2414, v_f_2412, v_as_2413));
  }
  case TAG_ELet: {
    V v_x_2415 = heff_dup(heff_field(v_e_241, 0));
    V v_a_2416 = heff_dup(heff_field(v_e_241, 1));
    V v_b_2417 = heff_dup(heff_field(v_e_241, 2));
    V v_t_2418 = heff_rec(2, shape_214_189, (V[]){NTAG(TAG_Nil), MK_INT(3LL)});
    V v_t_2419 = heff_tag(TAG_Cons, 2, (V[]){v_b_2417, NTAG(TAG_Nil)});
    V v_it_2420 = (g_heff_2elift_2eliftMany(heff_dup(g_heff_2elift_2elk_get()), v_d_240, v_t_2418, heff_tag(TAG_Cons, 2, (V[]){v_a_2416, v_t_2419})));
    switch (heff_tag_of(v_it_2420)) {
    case TAG_MkPair: {
      V v_it1_2421 = heff_field(v_it_2420, 0);
      V v_acc2_2422 = heff_field(v_it_2420, 1);
      V v_ru_24it_2420_24MkPair = heff_take_reuse(v_it_2420, 3ULL);
      switch (heff_tag_of(v_it1_2421)) {
      case TAG_Nil: {
        heff_drop(v_x_2415);
        heff_drop(v_it1_2421);
        return heff_tag_at(v_ru_24it_2420_24MkPair, TAG_MkPair, 2, (V[]){v_e_241, v_acc2_2422});
      }
      case TAG_Cons: {
        V v_a2_2423 = heff_field(v_it1_2421, 0);
        V v_it12_2424 = heff_field(v_it1_2421, 1);
        heff_take(v_it1_2421, 3ULL);
        switch (heff_tag_of(v_it12_2424)) {
        case TAG_Nil: {
          heff_drop(v_x_2415);
          heff_drop(v_a2_2423);
          heff_drop(v_it12_2424);
          return heff_tag_at(v_ru_24it_2420_24MkPair, TAG_MkPair, 2, (V[]){v_e_241, v_acc2_2422});
        }
        case TAG_Cons: {
          V v_b2_2425 = heff_field(v_it12_2424, 0);
          V v_it122_2426 = heff_field(v_it12_2424, 1);
          heff_take(v_it12_2424, 3ULL);
          switch (heff_tag_of(v_it122_2426)) {
          case TAG_Nil: {
            heff_drop(v_e_241);
            heff_drop(v_it122_2426);
            return heff_tag_at(v_ru_24it_2420_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_ELet, 3, (V[]){v_x_2415, v_a2_2423, v_b2_2425}), v_acc2_2422});
          }
          case TAG_Cons: {
            heff_take(v_it122_2426, 0ULL);
            heff_drop(v_x_2415);
            heff_drop(v_a2_2423);
            heff_drop(v_b2_2425);
            return heff_tag_at(v_ru_24it_2420_24MkPair, TAG_MkPair, 2, (V[]){v_e_241, v_acc2_2422});
          }
          default: return heff_nomatch(v_it122_2426);
          }
        }
        default: return heff_nomatch(v_it12_2424);
        }
      }
      default: return heff_nomatch(v_it1_2421);
      }
    }
    default: return heff_nomatch(v_it_2420);
    }
  }
  case TAG_ERecord: {
    V v_fs_2429 = heff_field(v_e_241, 0);
    V v_ru_24e_241_24ERecord = heff_take_reuse(v_e_241, 1ULL);
    V v_t_2430 = heff_rec(2, shape_214_189, (V[]){NTAG(TAG_Nil), MK_INT(3LL)});
    V v_t_2431 = (g_prelude_2emap_24s539(heff_dup(v_fs_2429)));
    V v_t_2432 = (g_heff_2elift_2eliftMany(heff_dup(g_heff_2elift_2elk_get()), v_d_240, v_t_2430, v_t_2431));
    switch (heff_tag_of(v_t_2432)) {
    case TAG_MkPair: {
      V v_es_2433 = heff_field(v_t_2432, 0);
      V v_acc2_2434 = heff_field(v_t_2432, 1);
      V v_ru_24t_2432_24MkPair = heff_take_reuse(v_t_2432, 3ULL);
      V v_fs2_2435 = (g_prelude_2ezipWith_24s556(v_fs_2429, v_es_2433));
      return heff_tag_at(v_ru_24t_2432_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at(v_ru_24e_241_24ERecord, TAG_ERecord, 1, (V[]){v_fs2_2435}), v_acc2_2434});
    }
    default: return heff_nomatch(v_t_2432);
    }
  }
  case TAG_EProj: {
    V v_x_2436 = heff_field(v_e_241, 0);
    V v_l_2437 = heff_field(v_e_241, 1);
    V v_ru_24e_241_24EProj = heff_take_reuse(v_e_241, 3ULL);
    V v_t_2438 = heff_rec(2, shape_214_189, (V[]){NTAG(TAG_Nil), MK_INT(3LL)});
    V v_t_2439 = heff_tr(g_heff_2elift_2eliftGo(heff_dup(g_heff_2elift_2elk_get()), v_d_240, v_t_2438, v_x_2436));
    switch (heff_tag_of(v_t_2439)) {
    case TAG_MkPair: {
      V v_x2_2440 = heff_field(v_t_2439, 0);
      V v_acc2_2441 = heff_field(v_t_2439, 1);
      heff_take(v_t_2439, 3ULL);
      return heff_tag_at(v_ru_24e_241_24EProj, TAG_MkPair, 2, (V[]){heff_tag(TAG_EProj, 2, (V[]){v_x2_2440, v_l_2437}), v_acc2_2441});
    }
    default: return heff_nomatch(v_t_2439);
    }
  }
  case TAG_ETag: {
    V v_t_2442 = heff_field(v_e_241, 0);
    V v_es_2443 = heff_field(v_e_241, 1);
    V v_ru_24e_241_24ETag = heff_take_reuse(v_e_241, 3ULL);
    V v_t_2444 = heff_rec(2, shape_214_189, (V[]){NTAG(TAG_Nil), MK_INT(3LL)});
    V v_t_2445 = (g_heff_2elift_2eliftMany(heff_dup(g_heff_2elift_2elk_get()), v_d_240, v_t_2444, v_es_2443));
    switch (heff_tag_of(v_t_2445)) {
    case TAG_MkPair: {
      V v_es2_2446 = heff_field(v_t_2445, 0);
      V v_acc2_2447 = heff_field(v_t_2445, 1);
      heff_take(v_t_2445, 3ULL);
      return heff_tag_at(v_ru_24e_241_24ETag, TAG_MkPair, 2, (V[]){heff_tag(TAG_ETag, 2, (V[]){v_t_2442, v_es2_2446}), v_acc2_2447});
    }
    default: return heff_nomatch(v_t_2445);
    }
  }
  case TAG_EMatch: {
    V v_x_2448 = heff_field(v_e_241, 0);
    V v_arms_2449 = heff_field(v_e_241, 1);
    V v_ru_24e_241_24EMatch = heff_take_reuse(v_e_241, 3ULL);
    V v_t_2450 = heff_rec(2, shape_214_189, (V[]){NTAG(TAG_Nil), MK_INT(3LL)});
    V v_t_2451 = heff_tr(g_heff_2elift_2eliftGo(heff_dup(g_heff_2elift_2elk_get()), heff_dup(v_d_240), v_t_2450, v_x_2448));
    switch (heff_tag_of(v_t_2451)) {
    case TAG_MkPair: {
      V v_x2_2452 = heff_field(v_t_2451, 0);
      V v_acc2_2453 = heff_field(v_t_2451, 1);
      heff_take(v_t_2451, 3ULL);
      V v_t_2454 = (g_prelude_2emap_24s541(heff_dup(v_arms_2449)));
      V v_t_2455 = (g_heff_2elift_2eliftMany(heff_dup(g_heff_2elift_2elk_get()), v_d_240, v_acc2_2453, v_t_2454));
      switch (heff_tag_of(v_t_2455)) {
      case TAG_MkPair: {
        V v_bs_2456 = heff_field(v_t_2455, 0);
        V v_acc2_2457 = heff_field(v_t_2455, 1);
        heff_take(v_t_2455, 3ULL);
        V v_arms2_2458 = (g_prelude_2ezipWith_24s570(v_arms_2449, v_bs_2456));
        return heff_tag_at(v_ru_24e_241_24EMatch, TAG_MkPair, 2, (V[]){heff_tag(TAG_EMatch, 2, (V[]){v_x2_2452, v_arms2_2458}), v_acc2_2457});
      }
      default: return heff_nomatch(v_t_2455);
      }
    }
    default: return heff_nomatch(v_t_2451);
    }
  }
  case TAG_EPrim: {
    heff_drop(v_d_240);
    V v_t_2460 = heff_rec(2, shape_214_189, (V[]){NTAG(TAG_Nil), MK_INT(3LL)});
    return heff_tag(TAG_MkPair, 2, (V[]){v_e_241, v_t_2460});
  }
  case TAG_EPrimCall: {
    V v_p_2461 = heff_field(v_e_241, 0);
    V v_es_2462 = heff_field(v_e_241, 1);
    V v_ru_24e_241_24EPrimCall = heff_take_reuse(v_e_241, 3ULL);
    V v_t_2463 = heff_rec(2, shape_214_189, (V[]){NTAG(TAG_Nil), MK_INT(3LL)});
    V v_t_2464 = (g_heff_2elift_2eliftMany(heff_dup(g_heff_2elift_2elk_get()), v_d_240, v_t_2463, v_es_2462));
    switch (heff_tag_of(v_t_2464)) {
    case TAG_MkPair: {
      V v_es2_2465 = heff_field(v_t_2464, 0);
      V v_acc2_2466 = heff_field(v_t_2464, 1);
      heff_take(v_t_2464, 3ULL);
      return heff_tag_at(v_ru_24e_241_24EPrimCall, TAG_MkPair, 2, (V[]){heff_tag(TAG_EPrimCall, 2, (V[]){v_p_2461, v_es2_2465}), v_acc2_2466});
    }
    default: return heff_nomatch(v_t_2464);
    }
  }
  case TAG_ECall: {
    V v_c_2467 = heff_field(v_e_241, 0);
    V v_es_2468 = heff_field(v_e_241, 1);
    V v_ru_24e_241_24ECall = heff_take_reuse(v_e_241, 3ULL);
    V v_t_2469 = heff_rec(2, shape_214_189, (V[]){NTAG(TAG_Nil), MK_INT(3LL)});
    V v_t_2470 = (g_heff_2elift_2eliftMany(heff_dup(g_heff_2elift_2elk_get()), v_d_240, v_t_2469, v_es_2468));
    switch (heff_tag_of(v_t_2470)) {
    case TAG_MkPair: {
      V v_es2_2471 = heff_field(v_t_2470, 0);
      V v_acc2_2472 = heff_field(v_t_2470, 1);
      heff_take(v_t_2470, 3ULL);
      return heff_tag_at(v_ru_24e_241_24ECall, TAG_MkPair, 2, (V[]){heff_tag(TAG_ECall, 2, (V[]){v_c_2467, v_es2_2471}), v_acc2_2472});
    }
    default: return heff_nomatch(v_t_2470);
    }
  }
  case TAG_EInt: {
    heff_drop(v_d_240);
    V v_t_2474 = heff_rec(2, shape_214_189, (V[]){NTAG(TAG_Nil), MK_INT(3LL)});
    return heff_tag(TAG_MkPair, 2, (V[]){v_e_241, v_t_2474});
  }
  case TAG_EFloat: {
    heff_drop(v_d_240);
    V v_t_2476 = heff_rec(2, shape_214_189, (V[]){NTAG(TAG_Nil), MK_INT(3LL)});
    return heff_tag(TAG_MkPair, 2, (V[]){v_e_241, v_t_2476});
  }
  case TAG_EStr: {
    heff_drop(v_d_240);
    V v_t_2478 = heff_rec(2, shape_214_189, (V[]){NTAG(TAG_Nil), MK_INT(3LL)});
    return heff_tag(TAG_MkPair, 2, (V[]){v_e_241, v_t_2478});
  }
  case TAG_EAbandon: {
    heff_drop(v_d_240);
    V v_t_2479 = heff_rec(2, shape_214_189, (V[]){NTAG(TAG_Nil), MK_INT(3LL)});
    return heff_tag(TAG_MkPair, 2, (V[]){v_e_241, v_t_2479});
  }
  case TAG_EFix: {
    V v_f_2480 = heff_field(v_e_241, 0);
    V v_b_2481 = heff_field(v_e_241, 1);
    heff_take(v_e_241, 3ULL);
    V v_t_2482 = heff_rec(2, shape_214_189, (V[]){NTAG(TAG_Nil), MK_INT(3LL)});
    return (g_heff_2elift_2eliftFix(heff_dup(g_heff_2elift_2elk_get()), v_d_240, v_t_2482, v_f_2480, v_b_2481));
  }
  default: return heff_nomatch(v_e_241);
  }
}
V g_heff_2elift_2eliftGo_24s592_entry(V self, V *a) {
  (void)self;
  return g_heff_2elift_2eliftGo_24s592(a[0], a[1]);
}
Clo g_heff_2elift_2eliftFixDef_24s591_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elift_2eliftFixDef_24s591_entry, 2, 0};

V g_heff_2elift_2eliftFixDef_24s591(V v_fvs_240, V v_ld_241) {
top: ;
  V v_t_242 = heff_tr(g_heff_2elift_2eliftGo_24s592(heff_dup(v_ld_241), heff_get(heff_dup(v_ld_241), LBL_body)));
  switch (heff_tag_of(v_t_242)) {
  case TAG_MkPair: {
    V v_b2_243 = heff_field(v_t_242, 0);
    V v_acc2_244 = heff_field(v_t_242, 1);
    V v_ru_24t_242_24MkPair = heff_take_reuse(v_t_242, 3ULL);
    V v_key_245 = heff_get(heff_dup(v_ld_241), LBL_key);
    V v_t_248;
    switch (heff_tag_of(v_fvs_240)) {
    case TAG_Nil: {
      heff_drop(v_fvs_240);
      heff_drop(v_ru_24t_242_24MkPair);
      v_t_248 = heff_tag(TAG_EGlobal, 1, (V[]){v_key_245});
      break;
    }
    case TAG_Cons: {
      v_t_248 = heff_tag_at(v_ru_24t_242_24MkPair, TAG_EApp, 2, (V[]){heff_tag(TAG_EGlobal, 1, (V[]){v_key_245}), (g_prelude_2emap_24s547(v_fvs_240))});
      break;
    }
    default: heff_nomatch(v_fvs_240);
    }
    V v_t_249 = heff_rec(3, shape_145_190_25, (V[]){heff_get(heff_dup(v_ld_241), LBL_key), heff_get(v_ld_241, LBL_name), v_b2_243});
    V v_t_2410 = heff_tag(TAG_Cons, 2, (V[]){v_t_249, heff_get(heff_dup(v_acc2_244), LBL_out)});
    V v_t_2411 = heff_rec(2, shape_214_189, (V[]){v_t_2410, heff_get(v_acc2_244, LBL_n)});
    return heff_tag(TAG_MkPair, 2, (V[]){v_t_248, v_t_2411});
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2elift_2eliftFixDef_24s591_entry(V self, V *a) {
  (void)self;
  return g_heff_2elift_2eliftFixDef_24s591(a[0], a[1]);
}
Clo g_heff_2elift_2eliftFix_24s590_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elift_2eliftFix_24s590_entry, 3, 0};

V g_heff_2elift_2eliftFix_24s590(V v_d_240, V v_f_241, V v_body_242) {
top: ;
  V v_t_243 = heff_tag(TAG_Cons, 2, (V[]){heff_dup(v_f_241), NTAG(TAG_Nil)});
  V v_xs_244 = (g_heff_2elift_2efreeGo(v_t_243, heff_dup(v_body_242), NTAG(TAG_Nil)));
  V v_t_245 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), v_xs_244));
  V v_t_246 = heff_tag(TAG_Cons, 2, (V[]){heff_dup(v_f_241), NTAG(TAG_Nil)});
  V v_xs_247 = (g_heff_2elift_2efreeGo(v_t_246, heff_dup(v_body_242), NTAG(TAG_Nil)));
  V v_t_248 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), v_xs_247));
  V v_t_249 = (g_heff_2elift_2eliftedDef(v_d_240, MK_INT(2LL), v_f_241, v_t_248, v_body_242));
  return (g_heff_2elift_2eliftFixDef_24s591(v_t_245, v_t_249));
}
V g_heff_2elift_2eliftFix_24s590_entry(V self, V *a) {
  (void)self;
  return g_heff_2elift_2eliftFix_24s590(a[0], a[1], a[2]);
}
Clo g_heff_2elift_2eliftRedex_24s589_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elift_2eliftRedex_24s589_entry, 4, 0};

V g_heff_2elift_2eliftRedex_24s589(V v_d_240, V v_x_241, V v_b_242, V v_a_243) {
top: ;
  V v_it_2430;
  switch (heff_tag_of(v_a_243)) {
  case TAG_EVar: {
    v_it_2430 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EGlobal: {
    v_it_2430 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_ELam: {
    v_it_2430 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EApp: {
    v_it_2430 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_ELet: {
    v_it_2430 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_ERecord: {
    v_it_2430 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EProj: {
    v_it_2430 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_ETag: {
    v_it_2430 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EMatch: {
    v_it_2430 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EPrim: {
    v_it_2430 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EPrimCall: {
    v_it_2430 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_ECall: {
    v_it_2430 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EInt: {
    v_it_2430 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EFloat: {
    v_it_2430 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EStr: {
    v_it_2430 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EAbandon: {
    v_it_2430 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EFix: {
    V v_f_2428 = heff_dup(heff_field(v_a_243, 0));
    V v_b_2429 = heff_dup(heff_field(v_a_243, 1));
    v_it_2430 = heff_tag(TAG_Just, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_f_2428, v_b_2429})});
    break;
  }
  default: heff_nomatch(v_a_243);
  }
  switch (heff_tag_of(v_it_2430)) {
  case TAG_Nothing: {
    heff_drop(v_it_2430);
    V v_t_2431 = heff_rec(2, shape_214_189, (V[]){NTAG(TAG_Nil), MK_INT(2LL)});
    V v_t_2432 = heff_tag(TAG_Cons, 2, (V[]){heff_dup(v_x_241), NTAG(TAG_Nil)});
    V v_t_2433 = heff_tag(TAG_Cons, 2, (V[]){heff_dup(v_a_243), NTAG(TAG_Nil)});
    V v_t_2434 = heff_tag(TAG_Cons, 2, (V[]){heff_tag(TAG_ELam, 2, (V[]){v_t_2432, heff_dup(v_b_242)}), v_t_2433});
    V v_it_2435 = (g_heff_2elift_2eliftMany_24s573(v_d_240, v_t_2431, v_t_2434));
    switch (heff_tag_of(v_it_2435)) {
    case TAG_MkPair: {
      V v_it1_2436 = heff_field(v_it_2435, 0);
      V v_acc2_2437 = heff_field(v_it_2435, 1);
      V v_ru_24it_2435_24MkPair = heff_take_reuse(v_it_2435, 3ULL);
      switch (heff_tag_of(v_it1_2436)) {
      case TAG_Nil: {
        heff_drop(v_it1_2436);
        V v_t_2438 = heff_tag_at(v_ru_24it_2435_24MkPair, TAG_Cons, 2, (V[]){v_x_241, NTAG(TAG_Nil)});
        V v_t_2439 = heff_tag(TAG_Cons, 2, (V[]){v_a_243, NTAG(TAG_Nil)});
        V v_t_2440 = heff_tag(TAG_EApp, 2, (V[]){heff_tag(TAG_ELam, 2, (V[]){v_t_2438, v_b_242}), v_t_2439});
        return heff_tag(TAG_MkPair, 2, (V[]){v_t_2440, v_acc2_2437});
      }
      case TAG_Cons: {
        V v_f2_2441 = heff_field(v_it1_2436, 0);
        V v_as2_2442 = heff_field(v_it1_2436, 1);
        heff_take(v_it1_2436, 3ULL);
        heff_drop(v_x_241);
        heff_drop(v_b_242);
        heff_drop(v_a_243);
        return heff_tag_at(v_ru_24it_2435_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_EApp, 2, (V[]){v_f2_2441, v_as2_2442}), v_acc2_2437});
      }
      default: return heff_nomatch(v_it1_2436);
      }
    }
    default: return heff_nomatch(v_it_2435);
    }
  }
  case TAG_Just: {
    V v_it1_2443 = heff_field(v_it_2430, 0);
    heff_take(v_it_2430, 1ULL);
    heff_drop(v_a_243);
    switch (heff_tag_of(v_it1_2443)) {
    case TAG_MkPair: {
      V v_f_2444 = heff_field(v_it1_2443, 0);
      V v_fb_2445 = heff_field(v_it1_2443, 1);
      heff_take(v_it1_2443, 3ULL);
      V v_t_2446 = (g_heff_2elift_2eliftFix_24s590(heff_dup(v_d_240), v_f_2444, v_fb_2445));
      switch (heff_tag_of(v_t_2446)) {
      case TAG_MkPair: {
        V v_call_2447 = heff_field(v_t_2446, 0);
        V v_acc2_2448 = heff_field(v_t_2446, 1);
        heff_take(v_t_2446, 3ULL);
        V v_e_2449 = (g_heff_2elift_2ereplaceGo(v_x_241, v_call_2447, v_b_242));
        return (g_heff_2elift_2eliftGo_24s574(v_d_240, v_acc2_2448, v_e_2449));
      }
      default: return heff_nomatch(v_t_2446);
      }
    }
    default: return heff_nomatch(v_it1_2443);
    }
  }
  default: return heff_nomatch(v_it_2430);
  }
}
V g_heff_2elift_2eliftRedex_24s589_entry(V self, V *a) {
  (void)self;
  return g_heff_2elift_2eliftRedex_24s589(a[0], a[1], a[2], a[3]);
}
Clo g_heff_2elift_2eliftApp_24s588_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elift_2eliftApp_24s588_entry, 3, 0};

V g_heff_2elift_2eliftApp_24s588(V v_d_240, V v_f_241, V v_as_242) {
top: ;
  V v_it_243 = (g_heff_2elift_2eoneParam(heff_dup(v_f_241)));
  switch (heff_tag_of(v_it_243)) {
  case TAG_Nothing: {
    heff_drop(v_it_243);
    V v_t_244 = heff_rec(2, shape_214_189, (V[]){NTAG(TAG_Nil), MK_INT(2LL)});
    V v_it_245 = (g_heff_2elift_2eliftMany_24s573(v_d_240, v_t_244, heff_tag(TAG_Cons, 2, (V[]){heff_dup(v_f_241), heff_dup(v_as_242)})));
    switch (heff_tag_of(v_it_245)) {
    case TAG_MkPair: {
      V v_it1_246 = heff_field(v_it_245, 0);
      V v_acc2_247 = heff_field(v_it_245, 1);
      V v_ru_24it_245_24MkPair = heff_take_reuse(v_it_245, 3ULL);
      switch (heff_tag_of(v_it1_246)) {
      case TAG_Nil: {
        heff_drop(v_it1_246);
        return heff_tag_at(v_ru_24it_245_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_EApp, 2, (V[]){v_f_241, v_as_242}), v_acc2_247});
      }
      case TAG_Cons: {
        V v_f2_248 = heff_field(v_it1_246, 0);
        V v_as2_249 = heff_field(v_it1_246, 1);
        heff_take(v_it1_246, 3ULL);
        heff_drop(v_f_241);
        heff_drop(v_as_242);
        return heff_tag_at(v_ru_24it_245_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_EApp, 2, (V[]){v_f2_248, v_as2_249}), v_acc2_247});
      }
      default: return heff_nomatch(v_it1_246);
      }
    }
    default: return heff_nomatch(v_it_245);
    }
  }
  case TAG_Just: {
    V v_it1_2410 = heff_field(v_it_243, 0);
    heff_take(v_it_243, 1ULL);
    switch (heff_tag_of(v_it1_2410)) {
    case TAG_MkPair: {
      V v_x_2411 = heff_field(v_it1_2410, 0);
      V v_b_2412 = heff_field(v_it1_2410, 1);
      V v_ru_24it1_2410_24MkPair = heff_take_reuse(v_it1_2410, 3ULL);
      switch (heff_tag_of(v_as_242)) {
      case TAG_Nil: {
        heff_drop(v_x_2411);
        heff_drop(v_b_2412);
        V v_t_2413 = heff_rec(2, shape_214_189, (V[]){NTAG(TAG_Nil), MK_INT(2LL)});
        V v_it_2414 = (g_heff_2elift_2eliftMany_24s573(v_d_240, v_t_2413, heff_tag_at(v_ru_24it1_2410_24MkPair, TAG_Cons, 2, (V[]){heff_dup(v_f_241), heff_dup(v_as_242)})));
        switch (heff_tag_of(v_it_2414)) {
        case TAG_MkPair: {
          V v_it1_2415 = heff_field(v_it_2414, 0);
          V v_acc2_2416 = heff_field(v_it_2414, 1);
          V v_ru_24it_2414_24MkPair = heff_take_reuse(v_it_2414, 3ULL);
          switch (heff_tag_of(v_it1_2415)) {
          case TAG_Nil: {
            heff_drop(v_it1_2415);
            return heff_tag_at(v_ru_24it_2414_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_EApp, 2, (V[]){v_f_241, v_as_242}), v_acc2_2416});
          }
          case TAG_Cons: {
            V v_f2_2417 = heff_field(v_it1_2415, 0);
            V v_as2_2418 = heff_field(v_it1_2415, 1);
            heff_take(v_it1_2415, 3ULL);
            heff_drop(v_f_241);
            heff_drop(v_as_242);
            return heff_tag_at(v_ru_24it_2414_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_EApp, 2, (V[]){v_f2_2417, v_as2_2418}), v_acc2_2416});
          }
          default: return heff_nomatch(v_it1_2415);
          }
        }
        default: return heff_nomatch(v_it_2414);
        }
      }
      case TAG_Cons: {
        V v_a_2419 = heff_dup(heff_field(v_as_242, 0));
        V v_it2_2420 = heff_dup(heff_field(v_as_242, 1));
        switch (heff_tag_of(v_it2_2420)) {
        case TAG_Nil: {
          heff_drop(v_f_241);
          heff_drop(v_as_242);
          heff_drop(v_ru_24it1_2410_24MkPair);
          heff_drop(v_it2_2420);
          return (g_heff_2elift_2eliftRedex_24s589(v_d_240, v_x_2411, v_b_2412, v_a_2419));
        }
        case TAG_Cons: {
          V v_ru_24it2_2420_24Cons = heff_take_reuse(v_it2_2420, 0ULL);
          heff_drop(v_x_2411);
          heff_drop(v_b_2412);
          heff_drop(v_a_2419);
          V v_t_2423 = heff_rec(2, shape_214_189, (V[]){NTAG(TAG_Nil), MK_INT(2LL)});
          V v_it_2424 = (g_heff_2elift_2eliftMany_24s573(v_d_240, v_t_2423, heff_tag_at(v_ru_24it1_2410_24MkPair, TAG_Cons, 2, (V[]){heff_dup(v_f_241), heff_dup(v_as_242)})));
          switch (heff_tag_of(v_it_2424)) {
          case TAG_MkPair: {
            V v_it1_2425 = heff_field(v_it_2424, 0);
            V v_acc2_2426 = heff_field(v_it_2424, 1);
            heff_take(v_it_2424, 3ULL);
            switch (heff_tag_of(v_it1_2425)) {
            case TAG_Nil: {
              heff_drop(v_it1_2425);
              return heff_tag_at(v_ru_24it2_2420_24Cons, TAG_MkPair, 2, (V[]){heff_tag(TAG_EApp, 2, (V[]){v_f_241, v_as_242}), v_acc2_2426});
            }
            case TAG_Cons: {
              V v_f2_2427 = heff_field(v_it1_2425, 0);
              V v_as2_2428 = heff_field(v_it1_2425, 1);
              heff_take(v_it1_2425, 3ULL);
              heff_drop(v_f_241);
              heff_drop(v_as_242);
              return heff_tag_at(v_ru_24it2_2420_24Cons, TAG_MkPair, 2, (V[]){heff_tag(TAG_EApp, 2, (V[]){v_f2_2427, v_as2_2428}), v_acc2_2426});
            }
            default: return heff_nomatch(v_it1_2425);
            }
          }
          default: return heff_nomatch(v_it_2424);
          }
        }
        default: return heff_nomatch(v_it2_2420);
        }
      }
      default: return heff_nomatch(v_as_242);
      }
    }
    default: return heff_nomatch(v_it1_2410);
    }
  }
  default: return heff_nomatch(v_it_243);
  }
}
V g_heff_2elift_2eliftApp_24s588_entry(V self, V *a) {
  (void)self;
  return g_heff_2elift_2eliftApp_24s588(a[0], a[1], a[2]);
}
Clo g_heff_2elift_2eliftGo_24s587_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elift_2eliftGo_24s587_entry, 2, 0};

V g_heff_2elift_2eliftGo_24s587(V v_d_240, V v_e_241) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_EVar: {
    heff_drop(v_d_240);
    V v_t_243 = heff_rec(2, shape_214_189, (V[]){NTAG(TAG_Nil), MK_INT(2LL)});
    return heff_tag(TAG_MkPair, 2, (V[]){v_e_241, v_t_243});
  }
  case TAG_EGlobal: {
    heff_drop(v_d_240);
    V v_t_245 = heff_rec(2, shape_214_189, (V[]){NTAG(TAG_Nil), MK_INT(2LL)});
    return heff_tag(TAG_MkPair, 2, (V[]){v_e_241, v_t_245});
  }
  case TAG_ELam: {
    V v_xs_246 = heff_field(v_e_241, 0);
    V v_b_247 = heff_field(v_e_241, 1);
    V v_ru_24e_241_24ELam = heff_take_reuse(v_e_241, 3ULL);
    V v_t_248 = (g_heff_2elift_2eliftGo_24s587(v_d_240, v_b_247));
    switch (heff_tag_of(v_t_248)) {
    case TAG_MkPair: {
      V v_b2_249 = heff_field(v_t_248, 0);
      V v_acc2_2410 = heff_field(v_t_248, 1);
      heff_take(v_t_248, 3ULL);
      return heff_tag_at(v_ru_24e_241_24ELam, TAG_MkPair, 2, (V[]){heff_tag(TAG_ELam, 2, (V[]){v_xs_246, v_b2_249}), v_acc2_2410});
    }
    default: return heff_nomatch(v_t_248);
    }
  }
  case TAG_EApp: {
    V v_f_2411 = heff_field(v_e_241, 0);
    V v_as_2412 = heff_field(v_e_241, 1);
    heff_take(v_e_241, 3ULL);
    return (g_heff_2elift_2eliftApp_24s588(v_d_240, v_f_2411, v_as_2412));
  }
  case TAG_ELet: {
    V v_x_2413 = heff_dup(heff_field(v_e_241, 0));
    V v_a_2414 = heff_dup(heff_field(v_e_241, 1));
    V v_b_2415 = heff_dup(heff_field(v_e_241, 2));
    V v_t_2416 = heff_rec(2, shape_214_189, (V[]){NTAG(TAG_Nil), MK_INT(2LL)});
    V v_t_2417 = heff_tag(TAG_Cons, 2, (V[]){v_b_2415, NTAG(TAG_Nil)});
    V v_it_2418 = (g_heff_2elift_2eliftMany_24s573(v_d_240, v_t_2416, heff_tag(TAG_Cons, 2, (V[]){v_a_2414, v_t_2417})));
    switch (heff_tag_of(v_it_2418)) {
    case TAG_MkPair: {
      V v_it1_2419 = heff_field(v_it_2418, 0);
      V v_acc2_2420 = heff_field(v_it_2418, 1);
      V v_ru_24it_2418_24MkPair = heff_take_reuse(v_it_2418, 3ULL);
      switch (heff_tag_of(v_it1_2419)) {
      case TAG_Nil: {
        heff_drop(v_x_2413);
        heff_drop(v_it1_2419);
        return heff_tag_at(v_ru_24it_2418_24MkPair, TAG_MkPair, 2, (V[]){v_e_241, v_acc2_2420});
      }
      case TAG_Cons: {
        V v_a2_2421 = heff_field(v_it1_2419, 0);
        V v_it12_2422 = heff_field(v_it1_2419, 1);
        heff_take(v_it1_2419, 3ULL);
        switch (heff_tag_of(v_it12_2422)) {
        case TAG_Nil: {
          heff_drop(v_x_2413);
          heff_drop(v_a2_2421);
          heff_drop(v_it12_2422);
          return heff_tag_at(v_ru_24it_2418_24MkPair, TAG_MkPair, 2, (V[]){v_e_241, v_acc2_2420});
        }
        case TAG_Cons: {
          V v_b2_2423 = heff_field(v_it12_2422, 0);
          V v_it122_2424 = heff_field(v_it12_2422, 1);
          heff_take(v_it12_2422, 3ULL);
          switch (heff_tag_of(v_it122_2424)) {
          case TAG_Nil: {
            heff_drop(v_e_241);
            heff_drop(v_it122_2424);
            return heff_tag_at(v_ru_24it_2418_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_ELet, 3, (V[]){v_x_2413, v_a2_2421, v_b2_2423}), v_acc2_2420});
          }
          case TAG_Cons: {
            heff_take(v_it122_2424, 0ULL);
            heff_drop(v_x_2413);
            heff_drop(v_a2_2421);
            heff_drop(v_b2_2423);
            return heff_tag_at(v_ru_24it_2418_24MkPair, TAG_MkPair, 2, (V[]){v_e_241, v_acc2_2420});
          }
          default: return heff_nomatch(v_it122_2424);
          }
        }
        default: return heff_nomatch(v_it12_2422);
        }
      }
      default: return heff_nomatch(v_it1_2419);
      }
    }
    default: return heff_nomatch(v_it_2418);
    }
  }
  case TAG_ERecord: {
    V v_fs_2427 = heff_field(v_e_241, 0);
    V v_ru_24e_241_24ERecord = heff_take_reuse(v_e_241, 1ULL);
    V v_t_2428 = heff_rec(2, shape_214_189, (V[]){NTAG(TAG_Nil), MK_INT(2LL)});
    V v_t_2429 = (g_prelude_2emap_24s539(heff_dup(v_fs_2427)));
    V v_t_2430 = (g_heff_2elift_2eliftMany_24s573(v_d_240, v_t_2428, v_t_2429));
    switch (heff_tag_of(v_t_2430)) {
    case TAG_MkPair: {
      V v_es_2431 = heff_field(v_t_2430, 0);
      V v_acc2_2432 = heff_field(v_t_2430, 1);
      V v_ru_24t_2430_24MkPair = heff_take_reuse(v_t_2430, 3ULL);
      V v_fs2_2433 = (g_prelude_2ezipWith_24s556(v_fs_2427, v_es_2431));
      return heff_tag_at(v_ru_24t_2430_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at(v_ru_24e_241_24ERecord, TAG_ERecord, 1, (V[]){v_fs2_2433}), v_acc2_2432});
    }
    default: return heff_nomatch(v_t_2430);
    }
  }
  case TAG_EProj: {
    V v_x_2434 = heff_field(v_e_241, 0);
    V v_l_2435 = heff_field(v_e_241, 1);
    V v_ru_24e_241_24EProj = heff_take_reuse(v_e_241, 3ULL);
    V v_t_2436 = (g_heff_2elift_2eliftGo_24s587(v_d_240, v_x_2434));
    switch (heff_tag_of(v_t_2436)) {
    case TAG_MkPair: {
      V v_x2_2437 = heff_field(v_t_2436, 0);
      V v_acc2_2438 = heff_field(v_t_2436, 1);
      heff_take(v_t_2436, 3ULL);
      return heff_tag_at(v_ru_24e_241_24EProj, TAG_MkPair, 2, (V[]){heff_tag(TAG_EProj, 2, (V[]){v_x2_2437, v_l_2435}), v_acc2_2438});
    }
    default: return heff_nomatch(v_t_2436);
    }
  }
  case TAG_ETag: {
    V v_t_2439 = heff_field(v_e_241, 0);
    V v_es_2440 = heff_field(v_e_241, 1);
    V v_ru_24e_241_24ETag = heff_take_reuse(v_e_241, 3ULL);
    V v_t_2441 = heff_rec(2, shape_214_189, (V[]){NTAG(TAG_Nil), MK_INT(2LL)});
    V v_t_2442 = (g_heff_2elift_2eliftMany_24s573(v_d_240, v_t_2441, v_es_2440));
    switch (heff_tag_of(v_t_2442)) {
    case TAG_MkPair: {
      V v_es2_2443 = heff_field(v_t_2442, 0);
      V v_acc2_2444 = heff_field(v_t_2442, 1);
      heff_take(v_t_2442, 3ULL);
      return heff_tag_at(v_ru_24e_241_24ETag, TAG_MkPair, 2, (V[]){heff_tag(TAG_ETag, 2, (V[]){v_t_2439, v_es2_2443}), v_acc2_2444});
    }
    default: return heff_nomatch(v_t_2442);
    }
  }
  case TAG_EMatch: {
    V v_x_2445 = heff_field(v_e_241, 0);
    V v_arms_2446 = heff_field(v_e_241, 1);
    V v_ru_24e_241_24EMatch = heff_take_reuse(v_e_241, 3ULL);
    V v_t_2447 = (g_heff_2elift_2eliftGo_24s587(heff_dup(v_d_240), v_x_2445));
    switch (heff_tag_of(v_t_2447)) {
    case TAG_MkPair: {
      V v_x2_2448 = heff_field(v_t_2447, 0);
      V v_acc2_2449 = heff_field(v_t_2447, 1);
      heff_take(v_t_2447, 3ULL);
      V v_t_2450 = (g_prelude_2emap_24s541(heff_dup(v_arms_2446)));
      V v_t_2451 = (g_heff_2elift_2eliftMany_24s573(v_d_240, v_acc2_2449, v_t_2450));
      switch (heff_tag_of(v_t_2451)) {
      case TAG_MkPair: {
        V v_bs_2452 = heff_field(v_t_2451, 0);
        V v_acc2_2453 = heff_field(v_t_2451, 1);
        heff_take(v_t_2451, 3ULL);
        V v_arms2_2454 = (g_prelude_2ezipWith_24s570(v_arms_2446, v_bs_2452));
        return heff_tag_at(v_ru_24e_241_24EMatch, TAG_MkPair, 2, (V[]){heff_tag(TAG_EMatch, 2, (V[]){v_x2_2448, v_arms2_2454}), v_acc2_2453});
      }
      default: return heff_nomatch(v_t_2451);
      }
    }
    default: return heff_nomatch(v_t_2447);
    }
  }
  case TAG_EPrim: {
    heff_drop(v_d_240);
    V v_t_2456 = heff_rec(2, shape_214_189, (V[]){NTAG(TAG_Nil), MK_INT(2LL)});
    return heff_tag(TAG_MkPair, 2, (V[]){v_e_241, v_t_2456});
  }
  case TAG_EPrimCall: {
    V v_p_2457 = heff_field(v_e_241, 0);
    V v_es_2458 = heff_field(v_e_241, 1);
    V v_ru_24e_241_24EPrimCall = heff_take_reuse(v_e_241, 3ULL);
    V v_t_2459 = heff_rec(2, shape_214_189, (V[]){NTAG(TAG_Nil), MK_INT(2LL)});
    V v_t_2460 = (g_heff_2elift_2eliftMany_24s573(v_d_240, v_t_2459, v_es_2458));
    switch (heff_tag_of(v_t_2460)) {
    case TAG_MkPair: {
      V v_es2_2461 = heff_field(v_t_2460, 0);
      V v_acc2_2462 = heff_field(v_t_2460, 1);
      heff_take(v_t_2460, 3ULL);
      return heff_tag_at(v_ru_24e_241_24EPrimCall, TAG_MkPair, 2, (V[]){heff_tag(TAG_EPrimCall, 2, (V[]){v_p_2457, v_es2_2461}), v_acc2_2462});
    }
    default: return heff_nomatch(v_t_2460);
    }
  }
  case TAG_ECall: {
    V v_c_2463 = heff_field(v_e_241, 0);
    V v_es_2464 = heff_field(v_e_241, 1);
    V v_ru_24e_241_24ECall = heff_take_reuse(v_e_241, 3ULL);
    V v_t_2465 = heff_rec(2, shape_214_189, (V[]){NTAG(TAG_Nil), MK_INT(2LL)});
    V v_t_2466 = (g_heff_2elift_2eliftMany_24s573(v_d_240, v_t_2465, v_es_2464));
    switch (heff_tag_of(v_t_2466)) {
    case TAG_MkPair: {
      V v_es2_2467 = heff_field(v_t_2466, 0);
      V v_acc2_2468 = heff_field(v_t_2466, 1);
      heff_take(v_t_2466, 3ULL);
      return heff_tag_at(v_ru_24e_241_24ECall, TAG_MkPair, 2, (V[]){heff_tag(TAG_ECall, 2, (V[]){v_c_2463, v_es2_2467}), v_acc2_2468});
    }
    default: return heff_nomatch(v_t_2466);
    }
  }
  case TAG_EInt: {
    heff_drop(v_d_240);
    V v_t_2470 = heff_rec(2, shape_214_189, (V[]){NTAG(TAG_Nil), MK_INT(2LL)});
    return heff_tag(TAG_MkPair, 2, (V[]){v_e_241, v_t_2470});
  }
  case TAG_EFloat: {
    heff_drop(v_d_240);
    V v_t_2472 = heff_rec(2, shape_214_189, (V[]){NTAG(TAG_Nil), MK_INT(2LL)});
    return heff_tag(TAG_MkPair, 2, (V[]){v_e_241, v_t_2472});
  }
  case TAG_EStr: {
    heff_drop(v_d_240);
    V v_t_2474 = heff_rec(2, shape_214_189, (V[]){NTAG(TAG_Nil), MK_INT(2LL)});
    return heff_tag(TAG_MkPair, 2, (V[]){v_e_241, v_t_2474});
  }
  case TAG_EAbandon: {
    heff_drop(v_d_240);
    V v_t_2475 = heff_rec(2, shape_214_189, (V[]){NTAG(TAG_Nil), MK_INT(2LL)});
    return heff_tag(TAG_MkPair, 2, (V[]){v_e_241, v_t_2475});
  }
  case TAG_EFix: {
    V v_f_2476 = heff_field(v_e_241, 0);
    V v_b_2477 = heff_field(v_e_241, 1);
    V v_ru_24e_241_24EFix = heff_take_reuse(v_e_241, 3ULL);
    V v_t_2478 = heff_tag_at(v_ru_24e_241_24EFix, TAG_Cons, 2, (V[]){heff_dup(v_f_2476), NTAG(TAG_Nil)});
    V v_xs_2479 = (g_heff_2elift_2efreeGo(v_t_2478, heff_dup(v_b_2477), NTAG(TAG_Nil)));
    V v_t_2480 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), v_xs_2479));
    V v_t_2481 = heff_tag(TAG_Cons, 2, (V[]){heff_dup(v_f_2476), NTAG(TAG_Nil)});
    V v_xs_2482 = (g_heff_2elift_2efreeGo(v_t_2481, heff_dup(v_b_2477), NTAG(TAG_Nil)));
    V v_t_2483 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), v_xs_2482));
    V v_t_2484 = (g_heff_2elift_2eliftedDef(v_d_240, MK_INT(2LL), v_f_2476, v_t_2483, v_b_2477));
    return (g_heff_2elift_2eliftFixDef_24s591(v_t_2480, v_t_2484));
  }
  default: return heff_nomatch(v_e_241);
  }
}
V g_heff_2elift_2eliftGo_24s587_entry(V self, V *a) {
  (void)self;
  return g_heff_2elift_2eliftGo_24s587(a[0], a[1]);
}
Clo g_heff_2elift_2eliftFixDef_24s586_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elift_2eliftFixDef_24s586_entry, 2, 0};

V g_heff_2elift_2eliftFixDef_24s586(V v_fvs_240, V v_ld_241) {
top: ;
  V v_t_242 = (g_heff_2elift_2eliftGo_24s587(heff_dup(v_ld_241), heff_get(heff_dup(v_ld_241), LBL_body)));
  switch (heff_tag_of(v_t_242)) {
  case TAG_MkPair: {
    V v_b2_243 = heff_field(v_t_242, 0);
    V v_acc2_244 = heff_field(v_t_242, 1);
    V v_ru_24t_242_24MkPair = heff_take_reuse(v_t_242, 3ULL);
    V v_key_245 = heff_get(heff_dup(v_ld_241), LBL_key);
    V v_t_248;
    switch (heff_tag_of(v_fvs_240)) {
    case TAG_Nil: {
      heff_drop(v_fvs_240);
      heff_drop(v_ru_24t_242_24MkPair);
      v_t_248 = heff_tag(TAG_EGlobal, 1, (V[]){v_key_245});
      break;
    }
    case TAG_Cons: {
      v_t_248 = heff_tag_at(v_ru_24t_242_24MkPair, TAG_EApp, 2, (V[]){heff_tag(TAG_EGlobal, 1, (V[]){v_key_245}), (g_prelude_2emap_24s547(v_fvs_240))});
      break;
    }
    default: heff_nomatch(v_fvs_240);
    }
    V v_t_249 = heff_rec(3, shape_145_190_25, (V[]){heff_get(heff_dup(v_ld_241), LBL_key), heff_get(v_ld_241, LBL_name), v_b2_243});
    V v_t_2410 = heff_tag(TAG_Cons, 2, (V[]){v_t_249, heff_get(heff_dup(v_acc2_244), LBL_out)});
    V v_t_2411 = heff_rec(2, shape_214_189, (V[]){v_t_2410, heff_get(v_acc2_244, LBL_n)});
    return heff_tag(TAG_MkPair, 2, (V[]){v_t_248, v_t_2411});
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2elift_2eliftFixDef_24s586_entry(V self, V *a) {
  (void)self;
  return g_heff_2elift_2eliftFixDef_24s586(a[0], a[1]);
}
Clo g_heff_2elift_2eliftFix_24s585_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elift_2eliftFix_24s585_entry, 3, 0};

V g_heff_2elift_2eliftFix_24s585(V v_d_240, V v_f_241, V v_body_242) {
top: ;
  V v_t_243 = heff_tag(TAG_Cons, 2, (V[]){heff_dup(v_f_241), NTAG(TAG_Nil)});
  V v_xs_244 = (g_heff_2elift_2efreeGo(v_t_243, heff_dup(v_body_242), NTAG(TAG_Nil)));
  V v_t_245 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), v_xs_244));
  V v_t_246 = heff_tag(TAG_Cons, 2, (V[]){heff_dup(v_f_241), NTAG(TAG_Nil)});
  V v_xs_247 = (g_heff_2elift_2efreeGo(v_t_246, heff_dup(v_body_242), NTAG(TAG_Nil)));
  V v_t_248 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), v_xs_247));
  V v_t_249 = (g_heff_2elift_2eliftedDef(v_d_240, MK_INT(1LL), v_f_241, v_t_248, v_body_242));
  return (g_heff_2elift_2eliftFixDef_24s586(v_t_245, v_t_249));
}
V g_heff_2elift_2eliftFix_24s585_entry(V self, V *a) {
  (void)self;
  return g_heff_2elift_2eliftFix_24s585(a[0], a[1], a[2]);
}
Clo g_heff_2elift_2eliftRedex_24s584_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elift_2eliftRedex_24s584_entry, 4, 0};

V g_heff_2elift_2eliftRedex_24s584(V v_d_240, V v_x_241, V v_b_242, V v_a_243) {
top: ;
  V v_it_2430;
  switch (heff_tag_of(v_a_243)) {
  case TAG_EVar: {
    v_it_2430 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EGlobal: {
    v_it_2430 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_ELam: {
    v_it_2430 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EApp: {
    v_it_2430 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_ELet: {
    v_it_2430 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_ERecord: {
    v_it_2430 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EProj: {
    v_it_2430 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_ETag: {
    v_it_2430 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EMatch: {
    v_it_2430 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EPrim: {
    v_it_2430 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EPrimCall: {
    v_it_2430 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_ECall: {
    v_it_2430 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EInt: {
    v_it_2430 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EFloat: {
    v_it_2430 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EStr: {
    v_it_2430 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EAbandon: {
    v_it_2430 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EFix: {
    V v_f_2428 = heff_dup(heff_field(v_a_243, 0));
    V v_b_2429 = heff_dup(heff_field(v_a_243, 1));
    v_it_2430 = heff_tag(TAG_Just, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_f_2428, v_b_2429})});
    break;
  }
  default: heff_nomatch(v_a_243);
  }
  switch (heff_tag_of(v_it_2430)) {
  case TAG_Nothing: {
    heff_drop(v_it_2430);
    V v_t_2431 = heff_rec(2, shape_214_189, (V[]){NTAG(TAG_Nil), MK_INT(1LL)});
    V v_t_2432 = heff_tag(TAG_Cons, 2, (V[]){heff_dup(v_x_241), NTAG(TAG_Nil)});
    V v_t_2433 = heff_tag(TAG_Cons, 2, (V[]){heff_dup(v_a_243), NTAG(TAG_Nil)});
    V v_t_2434 = heff_tag(TAG_Cons, 2, (V[]){heff_tag(TAG_ELam, 2, (V[]){v_t_2432, heff_dup(v_b_242)}), v_t_2433});
    V v_it_2435 = (g_heff_2elift_2eliftMany_24s573(v_d_240, v_t_2431, v_t_2434));
    switch (heff_tag_of(v_it_2435)) {
    case TAG_MkPair: {
      V v_it1_2436 = heff_field(v_it_2435, 0);
      V v_acc2_2437 = heff_field(v_it_2435, 1);
      V v_ru_24it_2435_24MkPair = heff_take_reuse(v_it_2435, 3ULL);
      switch (heff_tag_of(v_it1_2436)) {
      case TAG_Nil: {
        heff_drop(v_it1_2436);
        V v_t_2438 = heff_tag_at(v_ru_24it_2435_24MkPair, TAG_Cons, 2, (V[]){v_x_241, NTAG(TAG_Nil)});
        V v_t_2439 = heff_tag(TAG_Cons, 2, (V[]){v_a_243, NTAG(TAG_Nil)});
        V v_t_2440 = heff_tag(TAG_EApp, 2, (V[]){heff_tag(TAG_ELam, 2, (V[]){v_t_2438, v_b_242}), v_t_2439});
        return heff_tag(TAG_MkPair, 2, (V[]){v_t_2440, v_acc2_2437});
      }
      case TAG_Cons: {
        V v_f2_2441 = heff_field(v_it1_2436, 0);
        V v_as2_2442 = heff_field(v_it1_2436, 1);
        heff_take(v_it1_2436, 3ULL);
        heff_drop(v_x_241);
        heff_drop(v_b_242);
        heff_drop(v_a_243);
        return heff_tag_at(v_ru_24it_2435_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_EApp, 2, (V[]){v_f2_2441, v_as2_2442}), v_acc2_2437});
      }
      default: return heff_nomatch(v_it1_2436);
      }
    }
    default: return heff_nomatch(v_it_2435);
    }
  }
  case TAG_Just: {
    V v_it1_2443 = heff_field(v_it_2430, 0);
    heff_take(v_it_2430, 1ULL);
    heff_drop(v_a_243);
    switch (heff_tag_of(v_it1_2443)) {
    case TAG_MkPair: {
      V v_f_2444 = heff_field(v_it1_2443, 0);
      V v_fb_2445 = heff_field(v_it1_2443, 1);
      heff_take(v_it1_2443, 3ULL);
      V v_t_2446 = (g_heff_2elift_2eliftFix_24s585(heff_dup(v_d_240), v_f_2444, v_fb_2445));
      switch (heff_tag_of(v_t_2446)) {
      case TAG_MkPair: {
        V v_call_2447 = heff_field(v_t_2446, 0);
        V v_acc2_2448 = heff_field(v_t_2446, 1);
        heff_take(v_t_2446, 3ULL);
        V v_e_2449 = (g_heff_2elift_2ereplaceGo(v_x_241, v_call_2447, v_b_242));
        return (g_heff_2elift_2eliftGo_24s574(v_d_240, v_acc2_2448, v_e_2449));
      }
      default: return heff_nomatch(v_t_2446);
      }
    }
    default: return heff_nomatch(v_it1_2443);
    }
  }
  default: return heff_nomatch(v_it_2430);
  }
}
V g_heff_2elift_2eliftRedex_24s584_entry(V self, V *a) {
  (void)self;
  return g_heff_2elift_2eliftRedex_24s584(a[0], a[1], a[2], a[3]);
}
Clo g_heff_2elift_2eliftApp_24s583_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elift_2eliftApp_24s583_entry, 3, 0};

V g_heff_2elift_2eliftApp_24s583(V v_d_240, V v_f_241, V v_as_242) {
top: ;
  V v_it_243 = (g_heff_2elift_2eoneParam(heff_dup(v_f_241)));
  switch (heff_tag_of(v_it_243)) {
  case TAG_Nothing: {
    heff_drop(v_it_243);
    V v_t_244 = heff_rec(2, shape_214_189, (V[]){NTAG(TAG_Nil), MK_INT(1LL)});
    V v_it_245 = (g_heff_2elift_2eliftMany_24s573(v_d_240, v_t_244, heff_tag(TAG_Cons, 2, (V[]){heff_dup(v_f_241), heff_dup(v_as_242)})));
    switch (heff_tag_of(v_it_245)) {
    case TAG_MkPair: {
      V v_it1_246 = heff_field(v_it_245, 0);
      V v_acc2_247 = heff_field(v_it_245, 1);
      V v_ru_24it_245_24MkPair = heff_take_reuse(v_it_245, 3ULL);
      switch (heff_tag_of(v_it1_246)) {
      case TAG_Nil: {
        heff_drop(v_it1_246);
        return heff_tag_at(v_ru_24it_245_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_EApp, 2, (V[]){v_f_241, v_as_242}), v_acc2_247});
      }
      case TAG_Cons: {
        V v_f2_248 = heff_field(v_it1_246, 0);
        V v_as2_249 = heff_field(v_it1_246, 1);
        heff_take(v_it1_246, 3ULL);
        heff_drop(v_f_241);
        heff_drop(v_as_242);
        return heff_tag_at(v_ru_24it_245_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_EApp, 2, (V[]){v_f2_248, v_as2_249}), v_acc2_247});
      }
      default: return heff_nomatch(v_it1_246);
      }
    }
    default: return heff_nomatch(v_it_245);
    }
  }
  case TAG_Just: {
    V v_it1_2410 = heff_field(v_it_243, 0);
    heff_take(v_it_243, 1ULL);
    switch (heff_tag_of(v_it1_2410)) {
    case TAG_MkPair: {
      V v_x_2411 = heff_field(v_it1_2410, 0);
      V v_b_2412 = heff_field(v_it1_2410, 1);
      V v_ru_24it1_2410_24MkPair = heff_take_reuse(v_it1_2410, 3ULL);
      switch (heff_tag_of(v_as_242)) {
      case TAG_Nil: {
        heff_drop(v_x_2411);
        heff_drop(v_b_2412);
        V v_t_2413 = heff_rec(2, shape_214_189, (V[]){NTAG(TAG_Nil), MK_INT(1LL)});
        V v_it_2414 = (g_heff_2elift_2eliftMany_24s573(v_d_240, v_t_2413, heff_tag_at(v_ru_24it1_2410_24MkPair, TAG_Cons, 2, (V[]){heff_dup(v_f_241), heff_dup(v_as_242)})));
        switch (heff_tag_of(v_it_2414)) {
        case TAG_MkPair: {
          V v_it1_2415 = heff_field(v_it_2414, 0);
          V v_acc2_2416 = heff_field(v_it_2414, 1);
          V v_ru_24it_2414_24MkPair = heff_take_reuse(v_it_2414, 3ULL);
          switch (heff_tag_of(v_it1_2415)) {
          case TAG_Nil: {
            heff_drop(v_it1_2415);
            return heff_tag_at(v_ru_24it_2414_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_EApp, 2, (V[]){v_f_241, v_as_242}), v_acc2_2416});
          }
          case TAG_Cons: {
            V v_f2_2417 = heff_field(v_it1_2415, 0);
            V v_as2_2418 = heff_field(v_it1_2415, 1);
            heff_take(v_it1_2415, 3ULL);
            heff_drop(v_f_241);
            heff_drop(v_as_242);
            return heff_tag_at(v_ru_24it_2414_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_EApp, 2, (V[]){v_f2_2417, v_as2_2418}), v_acc2_2416});
          }
          default: return heff_nomatch(v_it1_2415);
          }
        }
        default: return heff_nomatch(v_it_2414);
        }
      }
      case TAG_Cons: {
        V v_a_2419 = heff_dup(heff_field(v_as_242, 0));
        V v_it2_2420 = heff_dup(heff_field(v_as_242, 1));
        switch (heff_tag_of(v_it2_2420)) {
        case TAG_Nil: {
          heff_drop(v_f_241);
          heff_drop(v_as_242);
          heff_drop(v_ru_24it1_2410_24MkPair);
          heff_drop(v_it2_2420);
          return (g_heff_2elift_2eliftRedex_24s584(v_d_240, v_x_2411, v_b_2412, v_a_2419));
        }
        case TAG_Cons: {
          V v_ru_24it2_2420_24Cons = heff_take_reuse(v_it2_2420, 0ULL);
          heff_drop(v_x_2411);
          heff_drop(v_b_2412);
          heff_drop(v_a_2419);
          V v_t_2423 = heff_rec(2, shape_214_189, (V[]){NTAG(TAG_Nil), MK_INT(1LL)});
          V v_it_2424 = (g_heff_2elift_2eliftMany_24s573(v_d_240, v_t_2423, heff_tag_at(v_ru_24it1_2410_24MkPair, TAG_Cons, 2, (V[]){heff_dup(v_f_241), heff_dup(v_as_242)})));
          switch (heff_tag_of(v_it_2424)) {
          case TAG_MkPair: {
            V v_it1_2425 = heff_field(v_it_2424, 0);
            V v_acc2_2426 = heff_field(v_it_2424, 1);
            heff_take(v_it_2424, 3ULL);
            switch (heff_tag_of(v_it1_2425)) {
            case TAG_Nil: {
              heff_drop(v_it1_2425);
              return heff_tag_at(v_ru_24it2_2420_24Cons, TAG_MkPair, 2, (V[]){heff_tag(TAG_EApp, 2, (V[]){v_f_241, v_as_242}), v_acc2_2426});
            }
            case TAG_Cons: {
              V v_f2_2427 = heff_field(v_it1_2425, 0);
              V v_as2_2428 = heff_field(v_it1_2425, 1);
              heff_take(v_it1_2425, 3ULL);
              heff_drop(v_f_241);
              heff_drop(v_as_242);
              return heff_tag_at(v_ru_24it2_2420_24Cons, TAG_MkPair, 2, (V[]){heff_tag(TAG_EApp, 2, (V[]){v_f2_2427, v_as2_2428}), v_acc2_2426});
            }
            default: return heff_nomatch(v_it1_2425);
            }
          }
          default: return heff_nomatch(v_it_2424);
          }
        }
        default: return heff_nomatch(v_it2_2420);
        }
      }
      default: return heff_nomatch(v_as_242);
      }
    }
    default: return heff_nomatch(v_it1_2410);
    }
  }
  default: return heff_nomatch(v_it_243);
  }
}
V g_heff_2elift_2eliftApp_24s583_entry(V self, V *a) {
  (void)self;
  return g_heff_2elift_2eliftApp_24s583(a[0], a[1], a[2]);
}
Clo g_heff_2elift_2eliftGo_24s582_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elift_2eliftGo_24s582_entry, 2, 0};

V g_heff_2elift_2eliftGo_24s582(V v_d_240, V v_e_241) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_EVar: {
    heff_drop(v_d_240);
    V v_t_243 = heff_rec(2, shape_214_189, (V[]){NTAG(TAG_Nil), MK_INT(1LL)});
    return heff_tag(TAG_MkPair, 2, (V[]){v_e_241, v_t_243});
  }
  case TAG_EGlobal: {
    heff_drop(v_d_240);
    V v_t_245 = heff_rec(2, shape_214_189, (V[]){NTAG(TAG_Nil), MK_INT(1LL)});
    return heff_tag(TAG_MkPair, 2, (V[]){v_e_241, v_t_245});
  }
  case TAG_ELam: {
    V v_xs_246 = heff_field(v_e_241, 0);
    V v_b_247 = heff_field(v_e_241, 1);
    V v_ru_24e_241_24ELam = heff_take_reuse(v_e_241, 3ULL);
    V v_t_248 = (g_heff_2elift_2eliftGo_24s582(v_d_240, v_b_247));
    switch (heff_tag_of(v_t_248)) {
    case TAG_MkPair: {
      V v_b2_249 = heff_field(v_t_248, 0);
      V v_acc2_2410 = heff_field(v_t_248, 1);
      heff_take(v_t_248, 3ULL);
      return heff_tag_at(v_ru_24e_241_24ELam, TAG_MkPair, 2, (V[]){heff_tag(TAG_ELam, 2, (V[]){v_xs_246, v_b2_249}), v_acc2_2410});
    }
    default: return heff_nomatch(v_t_248);
    }
  }
  case TAG_EApp: {
    V v_f_2411 = heff_field(v_e_241, 0);
    V v_as_2412 = heff_field(v_e_241, 1);
    heff_take(v_e_241, 3ULL);
    return (g_heff_2elift_2eliftApp_24s583(v_d_240, v_f_2411, v_as_2412));
  }
  case TAG_ELet: {
    V v_x_2413 = heff_dup(heff_field(v_e_241, 0));
    V v_a_2414 = heff_dup(heff_field(v_e_241, 1));
    V v_b_2415 = heff_dup(heff_field(v_e_241, 2));
    V v_t_2416 = heff_rec(2, shape_214_189, (V[]){NTAG(TAG_Nil), MK_INT(1LL)});
    V v_t_2417 = heff_tag(TAG_Cons, 2, (V[]){v_b_2415, NTAG(TAG_Nil)});
    V v_it_2418 = (g_heff_2elift_2eliftMany_24s573(v_d_240, v_t_2416, heff_tag(TAG_Cons, 2, (V[]){v_a_2414, v_t_2417})));
    switch (heff_tag_of(v_it_2418)) {
    case TAG_MkPair: {
      V v_it1_2419 = heff_field(v_it_2418, 0);
      V v_acc2_2420 = heff_field(v_it_2418, 1);
      V v_ru_24it_2418_24MkPair = heff_take_reuse(v_it_2418, 3ULL);
      switch (heff_tag_of(v_it1_2419)) {
      case TAG_Nil: {
        heff_drop(v_x_2413);
        heff_drop(v_it1_2419);
        return heff_tag_at(v_ru_24it_2418_24MkPair, TAG_MkPair, 2, (V[]){v_e_241, v_acc2_2420});
      }
      case TAG_Cons: {
        V v_a2_2421 = heff_field(v_it1_2419, 0);
        V v_it12_2422 = heff_field(v_it1_2419, 1);
        heff_take(v_it1_2419, 3ULL);
        switch (heff_tag_of(v_it12_2422)) {
        case TAG_Nil: {
          heff_drop(v_x_2413);
          heff_drop(v_a2_2421);
          heff_drop(v_it12_2422);
          return heff_tag_at(v_ru_24it_2418_24MkPair, TAG_MkPair, 2, (V[]){v_e_241, v_acc2_2420});
        }
        case TAG_Cons: {
          V v_b2_2423 = heff_field(v_it12_2422, 0);
          V v_it122_2424 = heff_field(v_it12_2422, 1);
          heff_take(v_it12_2422, 3ULL);
          switch (heff_tag_of(v_it122_2424)) {
          case TAG_Nil: {
            heff_drop(v_e_241);
            heff_drop(v_it122_2424);
            return heff_tag_at(v_ru_24it_2418_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_ELet, 3, (V[]){v_x_2413, v_a2_2421, v_b2_2423}), v_acc2_2420});
          }
          case TAG_Cons: {
            heff_take(v_it122_2424, 0ULL);
            heff_drop(v_x_2413);
            heff_drop(v_a2_2421);
            heff_drop(v_b2_2423);
            return heff_tag_at(v_ru_24it_2418_24MkPair, TAG_MkPair, 2, (V[]){v_e_241, v_acc2_2420});
          }
          default: return heff_nomatch(v_it122_2424);
          }
        }
        default: return heff_nomatch(v_it12_2422);
        }
      }
      default: return heff_nomatch(v_it1_2419);
      }
    }
    default: return heff_nomatch(v_it_2418);
    }
  }
  case TAG_ERecord: {
    V v_fs_2427 = heff_field(v_e_241, 0);
    V v_ru_24e_241_24ERecord = heff_take_reuse(v_e_241, 1ULL);
    V v_t_2428 = heff_rec(2, shape_214_189, (V[]){NTAG(TAG_Nil), MK_INT(1LL)});
    V v_t_2429 = (g_prelude_2emap_24s539(heff_dup(v_fs_2427)));
    V v_t_2430 = (g_heff_2elift_2eliftMany_24s573(v_d_240, v_t_2428, v_t_2429));
    switch (heff_tag_of(v_t_2430)) {
    case TAG_MkPair: {
      V v_es_2431 = heff_field(v_t_2430, 0);
      V v_acc2_2432 = heff_field(v_t_2430, 1);
      V v_ru_24t_2430_24MkPair = heff_take_reuse(v_t_2430, 3ULL);
      V v_fs2_2433 = (g_prelude_2ezipWith_24s556(v_fs_2427, v_es_2431));
      return heff_tag_at(v_ru_24t_2430_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at(v_ru_24e_241_24ERecord, TAG_ERecord, 1, (V[]){v_fs2_2433}), v_acc2_2432});
    }
    default: return heff_nomatch(v_t_2430);
    }
  }
  case TAG_EProj: {
    V v_x_2434 = heff_field(v_e_241, 0);
    V v_l_2435 = heff_field(v_e_241, 1);
    V v_ru_24e_241_24EProj = heff_take_reuse(v_e_241, 3ULL);
    V v_t_2436 = (g_heff_2elift_2eliftGo_24s582(v_d_240, v_x_2434));
    switch (heff_tag_of(v_t_2436)) {
    case TAG_MkPair: {
      V v_x2_2437 = heff_field(v_t_2436, 0);
      V v_acc2_2438 = heff_field(v_t_2436, 1);
      heff_take(v_t_2436, 3ULL);
      return heff_tag_at(v_ru_24e_241_24EProj, TAG_MkPair, 2, (V[]){heff_tag(TAG_EProj, 2, (V[]){v_x2_2437, v_l_2435}), v_acc2_2438});
    }
    default: return heff_nomatch(v_t_2436);
    }
  }
  case TAG_ETag: {
    V v_t_2439 = heff_field(v_e_241, 0);
    V v_es_2440 = heff_field(v_e_241, 1);
    V v_ru_24e_241_24ETag = heff_take_reuse(v_e_241, 3ULL);
    V v_t_2441 = heff_rec(2, shape_214_189, (V[]){NTAG(TAG_Nil), MK_INT(1LL)});
    V v_t_2442 = (g_heff_2elift_2eliftMany_24s573(v_d_240, v_t_2441, v_es_2440));
    switch (heff_tag_of(v_t_2442)) {
    case TAG_MkPair: {
      V v_es2_2443 = heff_field(v_t_2442, 0);
      V v_acc2_2444 = heff_field(v_t_2442, 1);
      heff_take(v_t_2442, 3ULL);
      return heff_tag_at(v_ru_24e_241_24ETag, TAG_MkPair, 2, (V[]){heff_tag(TAG_ETag, 2, (V[]){v_t_2439, v_es2_2443}), v_acc2_2444});
    }
    default: return heff_nomatch(v_t_2442);
    }
  }
  case TAG_EMatch: {
    V v_x_2445 = heff_field(v_e_241, 0);
    V v_arms_2446 = heff_field(v_e_241, 1);
    V v_ru_24e_241_24EMatch = heff_take_reuse(v_e_241, 3ULL);
    V v_t_2447 = (g_heff_2elift_2eliftGo_24s582(heff_dup(v_d_240), v_x_2445));
    switch (heff_tag_of(v_t_2447)) {
    case TAG_MkPair: {
      V v_x2_2448 = heff_field(v_t_2447, 0);
      V v_acc2_2449 = heff_field(v_t_2447, 1);
      heff_take(v_t_2447, 3ULL);
      V v_t_2450 = (g_prelude_2emap_24s541(heff_dup(v_arms_2446)));
      V v_t_2451 = (g_heff_2elift_2eliftMany_24s573(v_d_240, v_acc2_2449, v_t_2450));
      switch (heff_tag_of(v_t_2451)) {
      case TAG_MkPair: {
        V v_bs_2452 = heff_field(v_t_2451, 0);
        V v_acc2_2453 = heff_field(v_t_2451, 1);
        heff_take(v_t_2451, 3ULL);
        V v_arms2_2454 = (g_prelude_2ezipWith_24s570(v_arms_2446, v_bs_2452));
        return heff_tag_at(v_ru_24e_241_24EMatch, TAG_MkPair, 2, (V[]){heff_tag(TAG_EMatch, 2, (V[]){v_x2_2448, v_arms2_2454}), v_acc2_2453});
      }
      default: return heff_nomatch(v_t_2451);
      }
    }
    default: return heff_nomatch(v_t_2447);
    }
  }
  case TAG_EPrim: {
    heff_drop(v_d_240);
    V v_t_2456 = heff_rec(2, shape_214_189, (V[]){NTAG(TAG_Nil), MK_INT(1LL)});
    return heff_tag(TAG_MkPair, 2, (V[]){v_e_241, v_t_2456});
  }
  case TAG_EPrimCall: {
    V v_p_2457 = heff_field(v_e_241, 0);
    V v_es_2458 = heff_field(v_e_241, 1);
    V v_ru_24e_241_24EPrimCall = heff_take_reuse(v_e_241, 3ULL);
    V v_t_2459 = heff_rec(2, shape_214_189, (V[]){NTAG(TAG_Nil), MK_INT(1LL)});
    V v_t_2460 = (g_heff_2elift_2eliftMany_24s573(v_d_240, v_t_2459, v_es_2458));
    switch (heff_tag_of(v_t_2460)) {
    case TAG_MkPair: {
      V v_es2_2461 = heff_field(v_t_2460, 0);
      V v_acc2_2462 = heff_field(v_t_2460, 1);
      heff_take(v_t_2460, 3ULL);
      return heff_tag_at(v_ru_24e_241_24EPrimCall, TAG_MkPair, 2, (V[]){heff_tag(TAG_EPrimCall, 2, (V[]){v_p_2457, v_es2_2461}), v_acc2_2462});
    }
    default: return heff_nomatch(v_t_2460);
    }
  }
  case TAG_ECall: {
    V v_c_2463 = heff_field(v_e_241, 0);
    V v_es_2464 = heff_field(v_e_241, 1);
    V v_ru_24e_241_24ECall = heff_take_reuse(v_e_241, 3ULL);
    V v_t_2465 = heff_rec(2, shape_214_189, (V[]){NTAG(TAG_Nil), MK_INT(1LL)});
    V v_t_2466 = (g_heff_2elift_2eliftMany_24s573(v_d_240, v_t_2465, v_es_2464));
    switch (heff_tag_of(v_t_2466)) {
    case TAG_MkPair: {
      V v_es2_2467 = heff_field(v_t_2466, 0);
      V v_acc2_2468 = heff_field(v_t_2466, 1);
      heff_take(v_t_2466, 3ULL);
      return heff_tag_at(v_ru_24e_241_24ECall, TAG_MkPair, 2, (V[]){heff_tag(TAG_ECall, 2, (V[]){v_c_2463, v_es2_2467}), v_acc2_2468});
    }
    default: return heff_nomatch(v_t_2466);
    }
  }
  case TAG_EInt: {
    heff_drop(v_d_240);
    V v_t_2470 = heff_rec(2, shape_214_189, (V[]){NTAG(TAG_Nil), MK_INT(1LL)});
    return heff_tag(TAG_MkPair, 2, (V[]){v_e_241, v_t_2470});
  }
  case TAG_EFloat: {
    heff_drop(v_d_240);
    V v_t_2472 = heff_rec(2, shape_214_189, (V[]){NTAG(TAG_Nil), MK_INT(1LL)});
    return heff_tag(TAG_MkPair, 2, (V[]){v_e_241, v_t_2472});
  }
  case TAG_EStr: {
    heff_drop(v_d_240);
    V v_t_2474 = heff_rec(2, shape_214_189, (V[]){NTAG(TAG_Nil), MK_INT(1LL)});
    return heff_tag(TAG_MkPair, 2, (V[]){v_e_241, v_t_2474});
  }
  case TAG_EAbandon: {
    heff_drop(v_d_240);
    V v_t_2475 = heff_rec(2, shape_214_189, (V[]){NTAG(TAG_Nil), MK_INT(1LL)});
    return heff_tag(TAG_MkPair, 2, (V[]){v_e_241, v_t_2475});
  }
  case TAG_EFix: {
    V v_f_2476 = heff_field(v_e_241, 0);
    V v_b_2477 = heff_field(v_e_241, 1);
    V v_ru_24e_241_24EFix = heff_take_reuse(v_e_241, 3ULL);
    V v_t_2478 = heff_tag_at(v_ru_24e_241_24EFix, TAG_Cons, 2, (V[]){heff_dup(v_f_2476), NTAG(TAG_Nil)});
    V v_xs_2479 = (g_heff_2elift_2efreeGo(v_t_2478, heff_dup(v_b_2477), NTAG(TAG_Nil)));
    V v_t_2480 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), v_xs_2479));
    V v_t_2481 = heff_tag(TAG_Cons, 2, (V[]){heff_dup(v_f_2476), NTAG(TAG_Nil)});
    V v_xs_2482 = (g_heff_2elift_2efreeGo(v_t_2481, heff_dup(v_b_2477), NTAG(TAG_Nil)));
    V v_t_2483 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), v_xs_2482));
    V v_t_2484 = (g_heff_2elift_2eliftedDef(v_d_240, MK_INT(1LL), v_f_2476, v_t_2483, v_b_2477));
    return (g_heff_2elift_2eliftFixDef_24s586(v_t_2480, v_t_2484));
  }
  default: return heff_nomatch(v_e_241);
  }
}
V g_heff_2elift_2eliftGo_24s582_entry(V self, V *a) {
  (void)self;
  return g_heff_2elift_2eliftGo_24s582(a[0], a[1]);
}
Clo g_heff_2elift_2eliftFixDef_24s581_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elift_2eliftFixDef_24s581_entry, 2, 0};

V g_heff_2elift_2eliftFixDef_24s581(V v_fvs_240, V v_ld_241) {
top: ;
  V v_t_242 = (g_heff_2elift_2eliftGo_24s582(heff_dup(v_ld_241), heff_get(heff_dup(v_ld_241), LBL_body)));
  switch (heff_tag_of(v_t_242)) {
  case TAG_MkPair: {
    V v_b2_243 = heff_field(v_t_242, 0);
    V v_acc2_244 = heff_field(v_t_242, 1);
    V v_ru_24t_242_24MkPair = heff_take_reuse(v_t_242, 3ULL);
    V v_key_245 = heff_get(heff_dup(v_ld_241), LBL_key);
    V v_t_248;
    switch (heff_tag_of(v_fvs_240)) {
    case TAG_Nil: {
      heff_drop(v_fvs_240);
      heff_drop(v_ru_24t_242_24MkPair);
      v_t_248 = heff_tag(TAG_EGlobal, 1, (V[]){v_key_245});
      break;
    }
    case TAG_Cons: {
      v_t_248 = heff_tag_at(v_ru_24t_242_24MkPair, TAG_EApp, 2, (V[]){heff_tag(TAG_EGlobal, 1, (V[]){v_key_245}), (g_prelude_2emap_24s547(v_fvs_240))});
      break;
    }
    default: heff_nomatch(v_fvs_240);
    }
    V v_t_249 = heff_rec(3, shape_145_190_25, (V[]){heff_get(heff_dup(v_ld_241), LBL_key), heff_get(v_ld_241, LBL_name), v_b2_243});
    V v_t_2410 = heff_tag(TAG_Cons, 2, (V[]){v_t_249, heff_get(heff_dup(v_acc2_244), LBL_out)});
    V v_t_2411 = heff_rec(2, shape_214_189, (V[]){v_t_2410, heff_get(v_acc2_244, LBL_n)});
    return heff_tag(TAG_MkPair, 2, (V[]){v_t_248, v_t_2411});
  }
  default: return heff_nomatch(v_t_242);
  }
}
V g_heff_2elift_2eliftFixDef_24s581_entry(V self, V *a) {
  (void)self;
  return g_heff_2elift_2eliftFixDef_24s581(a[0], a[1]);
}
Clo g_heff_2elift_2eliftFix_24s580_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elift_2eliftFix_24s580_entry, 3, 0};

V g_heff_2elift_2eliftFix_24s580(V v_d_240, V v_f_241, V v_body_242) {
top: ;
  V v_t_243 = heff_tag(TAG_Cons, 2, (V[]){heff_dup(v_f_241), NTAG(TAG_Nil)});
  V v_xs_244 = (g_heff_2elift_2efreeGo(v_t_243, heff_dup(v_body_242), NTAG(TAG_Nil)));
  V v_t_245 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), v_xs_244));
  V v_t_246 = heff_tag(TAG_Cons, 2, (V[]){heff_dup(v_f_241), NTAG(TAG_Nil)});
  V v_xs_247 = (g_heff_2elift_2efreeGo(v_t_246, heff_dup(v_body_242), NTAG(TAG_Nil)));
  V v_t_248 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), v_xs_247));
  V v_t_249 = (g_heff_2elift_2eliftedDef(v_d_240, MK_INT(0LL), v_f_241, v_t_248, v_body_242));
  return (g_heff_2elift_2eliftFixDef_24s581(v_t_245, v_t_249));
}
V g_heff_2elift_2eliftFix_24s580_entry(V self, V *a) {
  (void)self;
  return g_heff_2elift_2eliftFix_24s580(a[0], a[1], a[2]);
}
Clo g_heff_2elift_2eliftRedex_24s579_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elift_2eliftRedex_24s579_entry, 4, 0};

V g_heff_2elift_2eliftRedex_24s579(V v_d_240, V v_x_241, V v_b_242, V v_a_243) {
top: ;
  V v_it_2430;
  switch (heff_tag_of(v_a_243)) {
  case TAG_EVar: {
    v_it_2430 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EGlobal: {
    v_it_2430 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_ELam: {
    v_it_2430 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EApp: {
    v_it_2430 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_ELet: {
    v_it_2430 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_ERecord: {
    v_it_2430 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EProj: {
    v_it_2430 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_ETag: {
    v_it_2430 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EMatch: {
    v_it_2430 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EPrim: {
    v_it_2430 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EPrimCall: {
    v_it_2430 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_ECall: {
    v_it_2430 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EInt: {
    v_it_2430 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EFloat: {
    v_it_2430 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EStr: {
    v_it_2430 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EAbandon: {
    v_it_2430 = NTAG(TAG_Nothing);
    break;
  }
  case TAG_EFix: {
    V v_f_2428 = heff_dup(heff_field(v_a_243, 0));
    V v_b_2429 = heff_dup(heff_field(v_a_243, 1));
    v_it_2430 = heff_tag(TAG_Just, 1, (V[]){heff_tag(TAG_MkPair, 2, (V[]){v_f_2428, v_b_2429})});
    break;
  }
  default: heff_nomatch(v_a_243);
  }
  switch (heff_tag_of(v_it_2430)) {
  case TAG_Nothing: {
    heff_drop(v_it_2430);
    V v_t_2431 = heff_rec(2, shape_214_189, (V[]){NTAG(TAG_Nil), MK_INT(0LL)});
    V v_t_2432 = heff_tag(TAG_Cons, 2, (V[]){heff_dup(v_x_241), NTAG(TAG_Nil)});
    V v_t_2433 = heff_tag(TAG_Cons, 2, (V[]){heff_dup(v_a_243), NTAG(TAG_Nil)});
    V v_t_2434 = heff_tag(TAG_Cons, 2, (V[]){heff_tag(TAG_ELam, 2, (V[]){v_t_2432, heff_dup(v_b_242)}), v_t_2433});
    V v_it_2435 = (g_heff_2elift_2eliftMany_24s573(v_d_240, v_t_2431, v_t_2434));
    switch (heff_tag_of(v_it_2435)) {
    case TAG_MkPair: {
      V v_it1_2436 = heff_field(v_it_2435, 0);
      V v_acc2_2437 = heff_field(v_it_2435, 1);
      V v_ru_24it_2435_24MkPair = heff_take_reuse(v_it_2435, 3ULL);
      switch (heff_tag_of(v_it1_2436)) {
      case TAG_Nil: {
        heff_drop(v_it1_2436);
        V v_t_2438 = heff_tag_at(v_ru_24it_2435_24MkPair, TAG_Cons, 2, (V[]){v_x_241, NTAG(TAG_Nil)});
        V v_t_2439 = heff_tag(TAG_Cons, 2, (V[]){v_a_243, NTAG(TAG_Nil)});
        V v_t_2440 = heff_tag(TAG_EApp, 2, (V[]){heff_tag(TAG_ELam, 2, (V[]){v_t_2438, v_b_242}), v_t_2439});
        return heff_tag(TAG_MkPair, 2, (V[]){v_t_2440, v_acc2_2437});
      }
      case TAG_Cons: {
        V v_f2_2441 = heff_field(v_it1_2436, 0);
        V v_as2_2442 = heff_field(v_it1_2436, 1);
        heff_take(v_it1_2436, 3ULL);
        heff_drop(v_x_241);
        heff_drop(v_b_242);
        heff_drop(v_a_243);
        return heff_tag_at(v_ru_24it_2435_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_EApp, 2, (V[]){v_f2_2441, v_as2_2442}), v_acc2_2437});
      }
      default: return heff_nomatch(v_it1_2436);
      }
    }
    default: return heff_nomatch(v_it_2435);
    }
  }
  case TAG_Just: {
    V v_it1_2443 = heff_field(v_it_2430, 0);
    heff_take(v_it_2430, 1ULL);
    heff_drop(v_a_243);
    switch (heff_tag_of(v_it1_2443)) {
    case TAG_MkPair: {
      V v_f_2444 = heff_field(v_it1_2443, 0);
      V v_fb_2445 = heff_field(v_it1_2443, 1);
      heff_take(v_it1_2443, 3ULL);
      V v_t_2446 = (g_heff_2elift_2eliftFix_24s580(heff_dup(v_d_240), v_f_2444, v_fb_2445));
      switch (heff_tag_of(v_t_2446)) {
      case TAG_MkPair: {
        V v_call_2447 = heff_field(v_t_2446, 0);
        V v_acc2_2448 = heff_field(v_t_2446, 1);
        heff_take(v_t_2446, 3ULL);
        V v_e_2449 = (g_heff_2elift_2ereplaceGo(v_x_241, v_call_2447, v_b_242));
        return (g_heff_2elift_2eliftGo_24s574(v_d_240, v_acc2_2448, v_e_2449));
      }
      default: return heff_nomatch(v_t_2446);
      }
    }
    default: return heff_nomatch(v_it1_2443);
    }
  }
  default: return heff_nomatch(v_it_2430);
  }
}
V g_heff_2elift_2eliftRedex_24s579_entry(V self, V *a) {
  (void)self;
  return g_heff_2elift_2eliftRedex_24s579(a[0], a[1], a[2], a[3]);
}
Clo g_heff_2elift_2eliftApp_24s572_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elift_2eliftApp_24s572_entry, 3, 0};

V g_heff_2elift_2eliftApp_24s572(V v_d_240, V v_f_241, V v_as_242) {
top: ;
  V v_it_243 = (g_heff_2elift_2eoneParam(heff_dup(v_f_241)));
  switch (heff_tag_of(v_it_243)) {
  case TAG_Nothing: {
    heff_drop(v_it_243);
    V v_t_244 = heff_rec(2, shape_214_189, (V[]){NTAG(TAG_Nil), MK_INT(0LL)});
    V v_it_245 = (g_heff_2elift_2eliftMany_24s573(v_d_240, v_t_244, heff_tag(TAG_Cons, 2, (V[]){heff_dup(v_f_241), heff_dup(v_as_242)})));
    switch (heff_tag_of(v_it_245)) {
    case TAG_MkPair: {
      V v_it1_246 = heff_field(v_it_245, 0);
      V v_acc2_247 = heff_field(v_it_245, 1);
      V v_ru_24it_245_24MkPair = heff_take_reuse(v_it_245, 3ULL);
      switch (heff_tag_of(v_it1_246)) {
      case TAG_Nil: {
        heff_drop(v_it1_246);
        return heff_tag_at(v_ru_24it_245_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_EApp, 2, (V[]){v_f_241, v_as_242}), v_acc2_247});
      }
      case TAG_Cons: {
        V v_f2_248 = heff_field(v_it1_246, 0);
        V v_as2_249 = heff_field(v_it1_246, 1);
        heff_take(v_it1_246, 3ULL);
        heff_drop(v_f_241);
        heff_drop(v_as_242);
        return heff_tag_at(v_ru_24it_245_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_EApp, 2, (V[]){v_f2_248, v_as2_249}), v_acc2_247});
      }
      default: return heff_nomatch(v_it1_246);
      }
    }
    default: return heff_nomatch(v_it_245);
    }
  }
  case TAG_Just: {
    V v_it1_2410 = heff_field(v_it_243, 0);
    heff_take(v_it_243, 1ULL);
    switch (heff_tag_of(v_it1_2410)) {
    case TAG_MkPair: {
      V v_x_2411 = heff_field(v_it1_2410, 0);
      V v_b_2412 = heff_field(v_it1_2410, 1);
      V v_ru_24it1_2410_24MkPair = heff_take_reuse(v_it1_2410, 3ULL);
      switch (heff_tag_of(v_as_242)) {
      case TAG_Nil: {
        heff_drop(v_x_2411);
        heff_drop(v_b_2412);
        V v_t_2413 = heff_rec(2, shape_214_189, (V[]){NTAG(TAG_Nil), MK_INT(0LL)});
        V v_it_2414 = (g_heff_2elift_2eliftMany_24s573(v_d_240, v_t_2413, heff_tag_at(v_ru_24it1_2410_24MkPair, TAG_Cons, 2, (V[]){heff_dup(v_f_241), heff_dup(v_as_242)})));
        switch (heff_tag_of(v_it_2414)) {
        case TAG_MkPair: {
          V v_it1_2415 = heff_field(v_it_2414, 0);
          V v_acc2_2416 = heff_field(v_it_2414, 1);
          V v_ru_24it_2414_24MkPair = heff_take_reuse(v_it_2414, 3ULL);
          switch (heff_tag_of(v_it1_2415)) {
          case TAG_Nil: {
            heff_drop(v_it1_2415);
            return heff_tag_at(v_ru_24it_2414_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_EApp, 2, (V[]){v_f_241, v_as_242}), v_acc2_2416});
          }
          case TAG_Cons: {
            V v_f2_2417 = heff_field(v_it1_2415, 0);
            V v_as2_2418 = heff_field(v_it1_2415, 1);
            heff_take(v_it1_2415, 3ULL);
            heff_drop(v_f_241);
            heff_drop(v_as_242);
            return heff_tag_at(v_ru_24it_2414_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_EApp, 2, (V[]){v_f2_2417, v_as2_2418}), v_acc2_2416});
          }
          default: return heff_nomatch(v_it1_2415);
          }
        }
        default: return heff_nomatch(v_it_2414);
        }
      }
      case TAG_Cons: {
        V v_a_2419 = heff_dup(heff_field(v_as_242, 0));
        V v_it2_2420 = heff_dup(heff_field(v_as_242, 1));
        switch (heff_tag_of(v_it2_2420)) {
        case TAG_Nil: {
          heff_drop(v_f_241);
          heff_drop(v_as_242);
          heff_drop(v_ru_24it1_2410_24MkPair);
          heff_drop(v_it2_2420);
          return (g_heff_2elift_2eliftRedex_24s579(v_d_240, v_x_2411, v_b_2412, v_a_2419));
        }
        case TAG_Cons: {
          V v_ru_24it2_2420_24Cons = heff_take_reuse(v_it2_2420, 0ULL);
          heff_drop(v_x_2411);
          heff_drop(v_b_2412);
          heff_drop(v_a_2419);
          V v_t_2423 = heff_rec(2, shape_214_189, (V[]){NTAG(TAG_Nil), MK_INT(0LL)});
          V v_it_2424 = (g_heff_2elift_2eliftMany_24s573(v_d_240, v_t_2423, heff_tag_at(v_ru_24it1_2410_24MkPair, TAG_Cons, 2, (V[]){heff_dup(v_f_241), heff_dup(v_as_242)})));
          switch (heff_tag_of(v_it_2424)) {
          case TAG_MkPair: {
            V v_it1_2425 = heff_field(v_it_2424, 0);
            V v_acc2_2426 = heff_field(v_it_2424, 1);
            heff_take(v_it_2424, 3ULL);
            switch (heff_tag_of(v_it1_2425)) {
            case TAG_Nil: {
              heff_drop(v_it1_2425);
              return heff_tag_at(v_ru_24it2_2420_24Cons, TAG_MkPair, 2, (V[]){heff_tag(TAG_EApp, 2, (V[]){v_f_241, v_as_242}), v_acc2_2426});
            }
            case TAG_Cons: {
              V v_f2_2427 = heff_field(v_it1_2425, 0);
              V v_as2_2428 = heff_field(v_it1_2425, 1);
              heff_take(v_it1_2425, 3ULL);
              heff_drop(v_f_241);
              heff_drop(v_as_242);
              return heff_tag_at(v_ru_24it2_2420_24Cons, TAG_MkPair, 2, (V[]){heff_tag(TAG_EApp, 2, (V[]){v_f2_2427, v_as2_2428}), v_acc2_2426});
            }
            default: return heff_nomatch(v_it1_2425);
            }
          }
          default: return heff_nomatch(v_it_2424);
          }
        }
        default: return heff_nomatch(v_it2_2420);
        }
      }
      default: return heff_nomatch(v_as_242);
      }
    }
    default: return heff_nomatch(v_it1_2410);
    }
  }
  default: return heff_nomatch(v_it_243);
  }
}
V g_heff_2elift_2eliftApp_24s572_entry(V self, V *a) {
  (void)self;
  return g_heff_2elift_2eliftApp_24s572(a[0], a[1], a[2]);
}
Clo g_heff_2elift_2eliftGo_24s571_clo = {{0x80000000u, K_CLO, 0}, g_heff_2elift_2eliftGo_24s571_entry, 2, 0};

V g_heff_2elift_2eliftGo_24s571(V v_d_240, V v_e_241) {
top: ;
  switch (heff_tag_of(v_e_241)) {
  case TAG_EVar: {
    heff_drop(v_d_240);
    V v_t_243 = heff_rec(2, shape_214_189, (V[]){NTAG(TAG_Nil), MK_INT(0LL)});
    return heff_tag(TAG_MkPair, 2, (V[]){v_e_241, v_t_243});
  }
  case TAG_EGlobal: {
    heff_drop(v_d_240);
    V v_t_245 = heff_rec(2, shape_214_189, (V[]){NTAG(TAG_Nil), MK_INT(0LL)});
    return heff_tag(TAG_MkPair, 2, (V[]){v_e_241, v_t_245});
  }
  case TAG_ELam: {
    V v_xs_246 = heff_field(v_e_241, 0);
    V v_b_247 = heff_field(v_e_241, 1);
    V v_ru_24e_241_24ELam = heff_take_reuse(v_e_241, 3ULL);
    V v_t_248 = (g_heff_2elift_2eliftGo_24s571(v_d_240, v_b_247));
    switch (heff_tag_of(v_t_248)) {
    case TAG_MkPair: {
      V v_b2_249 = heff_field(v_t_248, 0);
      V v_acc2_2410 = heff_field(v_t_248, 1);
      heff_take(v_t_248, 3ULL);
      return heff_tag_at(v_ru_24e_241_24ELam, TAG_MkPair, 2, (V[]){heff_tag(TAG_ELam, 2, (V[]){v_xs_246, v_b2_249}), v_acc2_2410});
    }
    default: return heff_nomatch(v_t_248);
    }
  }
  case TAG_EApp: {
    V v_f_2411 = heff_field(v_e_241, 0);
    V v_as_2412 = heff_field(v_e_241, 1);
    heff_take(v_e_241, 3ULL);
    return (g_heff_2elift_2eliftApp_24s572(v_d_240, v_f_2411, v_as_2412));
  }
  case TAG_ELet: {
    V v_x_2413 = heff_dup(heff_field(v_e_241, 0));
    V v_a_2414 = heff_dup(heff_field(v_e_241, 1));
    V v_b_2415 = heff_dup(heff_field(v_e_241, 2));
    V v_t_2416 = heff_rec(2, shape_214_189, (V[]){NTAG(TAG_Nil), MK_INT(0LL)});
    V v_t_2417 = heff_tag(TAG_Cons, 2, (V[]){v_b_2415, NTAG(TAG_Nil)});
    V v_it_2418 = (g_heff_2elift_2eliftMany_24s573(v_d_240, v_t_2416, heff_tag(TAG_Cons, 2, (V[]){v_a_2414, v_t_2417})));
    switch (heff_tag_of(v_it_2418)) {
    case TAG_MkPair: {
      V v_it1_2419 = heff_field(v_it_2418, 0);
      V v_acc2_2420 = heff_field(v_it_2418, 1);
      V v_ru_24it_2418_24MkPair = heff_take_reuse(v_it_2418, 3ULL);
      switch (heff_tag_of(v_it1_2419)) {
      case TAG_Nil: {
        heff_drop(v_x_2413);
        heff_drop(v_it1_2419);
        return heff_tag_at(v_ru_24it_2418_24MkPair, TAG_MkPair, 2, (V[]){v_e_241, v_acc2_2420});
      }
      case TAG_Cons: {
        V v_a2_2421 = heff_field(v_it1_2419, 0);
        V v_it12_2422 = heff_field(v_it1_2419, 1);
        heff_take(v_it1_2419, 3ULL);
        switch (heff_tag_of(v_it12_2422)) {
        case TAG_Nil: {
          heff_drop(v_x_2413);
          heff_drop(v_a2_2421);
          heff_drop(v_it12_2422);
          return heff_tag_at(v_ru_24it_2418_24MkPair, TAG_MkPair, 2, (V[]){v_e_241, v_acc2_2420});
        }
        case TAG_Cons: {
          V v_b2_2423 = heff_field(v_it12_2422, 0);
          V v_it122_2424 = heff_field(v_it12_2422, 1);
          heff_take(v_it12_2422, 3ULL);
          switch (heff_tag_of(v_it122_2424)) {
          case TAG_Nil: {
            heff_drop(v_e_241);
            heff_drop(v_it122_2424);
            return heff_tag_at(v_ru_24it_2418_24MkPair, TAG_MkPair, 2, (V[]){heff_tag(TAG_ELet, 3, (V[]){v_x_2413, v_a2_2421, v_b2_2423}), v_acc2_2420});
          }
          case TAG_Cons: {
            heff_take(v_it122_2424, 0ULL);
            heff_drop(v_x_2413);
            heff_drop(v_a2_2421);
            heff_drop(v_b2_2423);
            return heff_tag_at(v_ru_24it_2418_24MkPair, TAG_MkPair, 2, (V[]){v_e_241, v_acc2_2420});
          }
          default: return heff_nomatch(v_it122_2424);
          }
        }
        default: return heff_nomatch(v_it12_2422);
        }
      }
      default: return heff_nomatch(v_it1_2419);
      }
    }
    default: return heff_nomatch(v_it_2418);
    }
  }
  case TAG_ERecord: {
    V v_fs_2427 = heff_field(v_e_241, 0);
    V v_ru_24e_241_24ERecord = heff_take_reuse(v_e_241, 1ULL);
    V v_t_2428 = heff_rec(2, shape_214_189, (V[]){NTAG(TAG_Nil), MK_INT(0LL)});
    V v_t_2429 = (g_prelude_2emap_24s539(heff_dup(v_fs_2427)));
    V v_t_2430 = (g_heff_2elift_2eliftMany_24s573(v_d_240, v_t_2428, v_t_2429));
    switch (heff_tag_of(v_t_2430)) {
    case TAG_MkPair: {
      V v_es_2431 = heff_field(v_t_2430, 0);
      V v_acc2_2432 = heff_field(v_t_2430, 1);
      V v_ru_24t_2430_24MkPair = heff_take_reuse(v_t_2430, 3ULL);
      V v_fs2_2433 = (g_prelude_2ezipWith_24s556(v_fs_2427, v_es_2431));
      return heff_tag_at(v_ru_24t_2430_24MkPair, TAG_MkPair, 2, (V[]){heff_tag_at(v_ru_24e_241_24ERecord, TAG_ERecord, 1, (V[]){v_fs2_2433}), v_acc2_2432});
    }
    default: return heff_nomatch(v_t_2430);
    }
  }
  case TAG_EProj: {
    V v_x_2434 = heff_field(v_e_241, 0);
    V v_l_2435 = heff_field(v_e_241, 1);
    V v_ru_24e_241_24EProj = heff_take_reuse(v_e_241, 3ULL);
    V v_t_2436 = (g_heff_2elift_2eliftGo_24s571(v_d_240, v_x_2434));
    switch (heff_tag_of(v_t_2436)) {
    case TAG_MkPair: {
      V v_x2_2437 = heff_field(v_t_2436, 0);
      V v_acc2_2438 = heff_field(v_t_2436, 1);
      heff_take(v_t_2436, 3ULL);
      return heff_tag_at(v_ru_24e_241_24EProj, TAG_MkPair, 2, (V[]){heff_tag(TAG_EProj, 2, (V[]){v_x2_2437, v_l_2435}), v_acc2_2438});
    }
    default: return heff_nomatch(v_t_2436);
    }
  }
  case TAG_ETag: {
    V v_t_2439 = heff_field(v_e_241, 0);
    V v_es_2440 = heff_field(v_e_241, 1);
    V v_ru_24e_241_24ETag = heff_take_reuse(v_e_241, 3ULL);
    V v_t_2441 = heff_rec(2, shape_214_189, (V[]){NTAG(TAG_Nil), MK_INT(0LL)});
    V v_t_2442 = (g_heff_2elift_2eliftMany_24s573(v_d_240, v_t_2441, v_es_2440));
    switch (heff_tag_of(v_t_2442)) {
    case TAG_MkPair: {
      V v_es2_2443 = heff_field(v_t_2442, 0);
      V v_acc2_2444 = heff_field(v_t_2442, 1);
      heff_take(v_t_2442, 3ULL);
      return heff_tag_at(v_ru_24e_241_24ETag, TAG_MkPair, 2, (V[]){heff_tag(TAG_ETag, 2, (V[]){v_t_2439, v_es2_2443}), v_acc2_2444});
    }
    default: return heff_nomatch(v_t_2442);
    }
  }
  case TAG_EMatch: {
    V v_x_2445 = heff_field(v_e_241, 0);
    V v_arms_2446 = heff_field(v_e_241, 1);
    V v_ru_24e_241_24EMatch = heff_take_reuse(v_e_241, 3ULL);
    V v_t_2447 = (g_heff_2elift_2eliftGo_24s571(heff_dup(v_d_240), v_x_2445));
    switch (heff_tag_of(v_t_2447)) {
    case TAG_MkPair: {
      V v_x2_2448 = heff_field(v_t_2447, 0);
      V v_acc2_2449 = heff_field(v_t_2447, 1);
      heff_take(v_t_2447, 3ULL);
      V v_t_2450 = (g_prelude_2emap_24s541(heff_dup(v_arms_2446)));
      V v_t_2451 = (g_heff_2elift_2eliftMany_24s573(v_d_240, v_acc2_2449, v_t_2450));
      switch (heff_tag_of(v_t_2451)) {
      case TAG_MkPair: {
        V v_bs_2452 = heff_field(v_t_2451, 0);
        V v_acc2_2453 = heff_field(v_t_2451, 1);
        heff_take(v_t_2451, 3ULL);
        V v_arms2_2454 = (g_prelude_2ezipWith_24s570(v_arms_2446, v_bs_2452));
        return heff_tag_at(v_ru_24e_241_24EMatch, TAG_MkPair, 2, (V[]){heff_tag(TAG_EMatch, 2, (V[]){v_x2_2448, v_arms2_2454}), v_acc2_2453});
      }
      default: return heff_nomatch(v_t_2451);
      }
    }
    default: return heff_nomatch(v_t_2447);
    }
  }
  case TAG_EPrim: {
    heff_drop(v_d_240);
    V v_t_2456 = heff_rec(2, shape_214_189, (V[]){NTAG(TAG_Nil), MK_INT(0LL)});
    return heff_tag(TAG_MkPair, 2, (V[]){v_e_241, v_t_2456});
  }
  case TAG_EPrimCall: {
    V v_p_2457 = heff_field(v_e_241, 0);
    V v_es_2458 = heff_field(v_e_241, 1);
    V v_ru_24e_241_24EPrimCall = heff_take_reuse(v_e_241, 3ULL);
    V v_t_2459 = heff_rec(2, shape_214_189, (V[]){NTAG(TAG_Nil), MK_INT(0LL)});
    V v_t_2460 = (g_heff_2elift_2eliftMany_24s573(v_d_240, v_t_2459, v_es_2458));
    switch (heff_tag_of(v_t_2460)) {
    case TAG_MkPair: {
      V v_es2_2461 = heff_field(v_t_2460, 0);
      V v_acc2_2462 = heff_field(v_t_2460, 1);
      heff_take(v_t_2460, 3ULL);
      return heff_tag_at(v_ru_24e_241_24EPrimCall, TAG_MkPair, 2, (V[]){heff_tag(TAG_EPrimCall, 2, (V[]){v_p_2457, v_es2_2461}), v_acc2_2462});
    }
    default: return heff_nomatch(v_t_2460);
    }
  }
  case TAG_ECall: {
    V v_c_2463 = heff_field(v_e_241, 0);
    V v_es_2464 = heff_field(v_e_241, 1);
    V v_ru_24e_241_24ECall = heff_take_reuse(v_e_241, 3ULL);
    V v_t_2465 = heff_rec(2, shape_214_189, (V[]){NTAG(TAG_Nil), MK_INT(0LL)});
    V v_t_2466 = (g_heff_2elift_2eliftMany_24s573(v_d_240, v_t_2465, v_es_2464));
    switch (heff_tag_of(v_t_2466)) {
    case TAG_MkPair: {
      V v_es2_2467 = heff_field(v_t_2466, 0);
      V v_acc2_2468 = heff_field(v_t_2466, 1);
      heff_take(v_t_2466, 3ULL);
      return heff_tag_at(v_ru_24e_241_24ECall, TAG_MkPair, 2, (V[]){heff_tag(TAG_ECall, 2, (V[]){v_c_2463, v_es2_2467}), v_acc2_2468});
    }
    default: return heff_nomatch(v_t_2466);
    }
  }
  case TAG_EInt: {
    heff_drop(v_d_240);
    V v_t_2470 = heff_rec(2, shape_214_189, (V[]){NTAG(TAG_Nil), MK_INT(0LL)});
    return heff_tag(TAG_MkPair, 2, (V[]){v_e_241, v_t_2470});
  }
  case TAG_EFloat: {
    heff_drop(v_d_240);
    V v_t_2472 = heff_rec(2, shape_214_189, (V[]){NTAG(TAG_Nil), MK_INT(0LL)});
    return heff_tag(TAG_MkPair, 2, (V[]){v_e_241, v_t_2472});
  }
  case TAG_EStr: {
    heff_drop(v_d_240);
    V v_t_2474 = heff_rec(2, shape_214_189, (V[]){NTAG(TAG_Nil), MK_INT(0LL)});
    return heff_tag(TAG_MkPair, 2, (V[]){v_e_241, v_t_2474});
  }
  case TAG_EAbandon: {
    heff_drop(v_d_240);
    V v_t_2475 = heff_rec(2, shape_214_189, (V[]){NTAG(TAG_Nil), MK_INT(0LL)});
    return heff_tag(TAG_MkPair, 2, (V[]){v_e_241, v_t_2475});
  }
  case TAG_EFix: {
    V v_f_2476 = heff_field(v_e_241, 0);
    V v_b_2477 = heff_field(v_e_241, 1);
    V v_ru_24e_241_24EFix = heff_take_reuse(v_e_241, 3ULL);
    V v_t_2478 = heff_tag_at(v_ru_24e_241_24EFix, TAG_Cons, 2, (V[]){heff_dup(v_f_2476), NTAG(TAG_Nil)});
    V v_xs_2479 = (g_heff_2elift_2efreeGo(v_t_2478, heff_dup(v_b_2477), NTAG(TAG_Nil)));
    V v_t_2480 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), v_xs_2479));
    V v_t_2481 = heff_tag(TAG_Cons, 2, (V[]){heff_dup(v_f_2476), NTAG(TAG_Nil)});
    V v_xs_2482 = (g_heff_2elift_2efreeGo(v_t_2481, heff_dup(v_b_2477), NTAG(TAG_Nil)));
    V v_t_2483 = (g_prelude_2efoldl_24s0(NTAG(TAG_Nil), v_xs_2482));
    V v_t_2484 = (g_heff_2elift_2eliftedDef(v_d_240, MK_INT(0LL), v_f_2476, v_t_2483, v_b_2477));
    return (g_heff_2elift_2eliftFixDef_24s581(v_t_2480, v_t_2484));
  }
  default: return heff_nomatch(v_e_241);
  }
}
V g_heff_2elift_2eliftGo_24s571_entry(V self, V *a) {
  (void)self;
  return g_heff_2elift_2eliftGo_24s571(a[0], a[1]);
}